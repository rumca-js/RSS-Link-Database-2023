# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## Designing the Space Marines – Warhammer 40,000
 - [https://www.youtube.com/watch?v=zso_dAs3ynQ](https://www.youtube.com/watch?v=zso_dAs3ynQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-09-25T15:01:00+00:00

Unfortunately, we weren’t able to get a meeting with the Emperor, so we had to settle for the Warhammer 40,000 studio.

Read what they had to say about creating the new range of Space Marines: https://ow.ly/S2ba50PPe1g

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/ 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

