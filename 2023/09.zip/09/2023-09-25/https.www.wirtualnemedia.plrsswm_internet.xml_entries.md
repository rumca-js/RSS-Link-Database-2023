# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Netflix szykuje polski serial dla nastolatków "Absolutni debiutanci". Premiera w październiku
 - [https://www.wirtualnemedia.pl/artykul/netflix-absolutni-debiutanci-premiera-w-pazdzierniku](https://www.wirtualnemedia.pl/artykul/netflix-absolutni-debiutanci-premiera-w-pazdzierniku)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-09-25T10:15:51.204885+00:00

25 października na Netfliksie pojawi się nowy, sześcioodcinkowy serial dla nastolatków “Absolutni debiutanci”

## Zarzuty wobec youtubera Stuu. Chodzi o „pikantne zdjęcia” od 13-latki
 - [https://www.wirtualnemedia.pl/artykul/stuu-youtuber-pikantne-zdjecia-olciak93](https://www.wirtualnemedia.pl/artykul/stuu-youtuber-pikantne-zdjecia-olciak93)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-09-25T09:10:51.793052+00:00

Influencerka Olciak93 twierdzi, że gdy miała 13-14 lat, youtuber Stuu (Stuart Kluz-Burton), wówczas jeden z najpopularniejszych twórców internetowych w Polsce, zachęcał, żeby wysłała mu swoje „miłe zdjęcia” i robił aluzje seksualne.

## Nike uruchomił internetową sprzedaż używanych sneakersów
 - [https://www.wirtualnemedia.pl/artykul/nike-jak-kupic-uzywane-buty-sneakersy](https://www.wirtualnemedia.pl/artykul/nike-jak-kupic-uzywane-buty-sneakersy)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-09-25T06:16:30.107940+00:00

Firma Nike rozpoczęła sprzedaż używanych sneakersów przez internet. Używane buty sprzedawane są w ramach inicjatywy proekologicznej firmy.

## Gazeta.pl walczy z adblockami. Wyświetla internautom komunikat
 - [https://www.wirtualnemedia.pl/artykul/gazeta-pl-walczy-z-adblockami-wyswietla-internautom-komunikat](https://www.wirtualnemedia.pl/artykul/gazeta-pl-walczy-z-adblockami-wyswietla-internautom-komunikat)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-09-25T05:11:59.761837+00:00

Portal Gazeta.pl (Agora) zaczął wyświetlać użytkownikom korzystającym z adblocków komunikat zachęcający do wyłączenia takich narzędzi. - Stosowanie rozwiązań mających na celu przekonanie użytkowników do dezaktywacji programów blokujących reklamy lub do wyświetlania reklam z programu Acceptable Ads, to jeden z wielu sposobów na efektywniejszą monetyzację naszych stron - mówi Paweł Dubiel, dyrektor ds. innowacji adtech i programmatic w Gazeta.pl.

## Onet rozpoczął współpracę z portalem Sestry.eu. „Perspektywa ukraińskich dziennikarek jest dla nas unikalna”
 - [https://www.wirtualnemedia.pl/artykul/onet-sestry](https://www.wirtualnemedia.pl/artykul/onet-sestry)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-09-25T04:07:08.384698+00:00

Działający od kilku tygodniu portal Sestry nawiązał dziennikarską współpracę z portalem Onet.pl polegającą na wymianie tekstów. - Perspektywa ukraińskich dziennikarek pracujących w Sestrach jest dla nas unikalna – wyjaśnia w rozmowie z portalem Wirtualnemedia.pl Bartosz Węglarczyk, redaktor naczelny Onetu.

## Catch up TV alternatywą dla dekoderów z twardym dyskiem, ale wielu kanałów brakuje
 - [https://www.wirtualnemedia.pl/artykul/jak-jak-cofnac-kanal-jak-dziala-catch-up-tv-dekoder-pvr-canal-polsat-box-go-tvp-go-player-upc-play-vectra-orange-tvn-polsat-tvp](https://www.wirtualnemedia.pl/artykul/jak-jak-cofnac-kanal-jak-dziala-catch-up-tv-dekoder-pvr-canal-polsat-box-go-tvp-go-player-upc-play-vectra-orange-tvn-polsat-tvp)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-09-25T04:07:08.379949+00:00

Obecnie większość serwisów streamingowych z kanałami linearnymi, a także sieci kablowe i platformy cyfrowe oferują funkcję catch up TV. Dzięki niej można cofnąć poszczególne stacje nawet do tygodnia. Nie jest to możliwe w przypadku wszystkich kanałów, co dostawcy usług w rozmowie z Wirtualnemedia.pl najczęściej tłumaczą „względami licencyjnymi”.

## Amazon Prime Video z reklamami. Za dopłatą będzie można je wyłączyć
 - [https://www.wirtualnemedia.pl/artykul/amazon-prime-video-pakiet-reklamy-tanszy-plan-netflix-disney-jak-ogladac](https://www.wirtualnemedia.pl/artykul/amazon-prime-video-pakiet-reklamy-tanszy-plan-netflix-disney-jak-ogladac)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-09-25T04:07:08.377470+00:00

Amazon Prime Video dołącza do Netfliksa i Disney+. Firma poinformowała, że w 2024 roku w wybranych krajach subskrybentom serwisu streamingowego będą wyświetlane reklamy. Chyba, że zapłacą więcej za plan bez nich. Zmiany na razie nie obejmą Polski.

