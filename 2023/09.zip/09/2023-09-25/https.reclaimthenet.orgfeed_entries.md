# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Media and Architects of Online Censorship Law Heap Pressure on Rumble After it Defends Principle of Neutrality
 - [https://reclaimthenet.org/media-online-safety-bill-rumble](https://reclaimthenet.org/media-online-safety-bill-rumble)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-25T20:27:36+00:00

<a href="https://reclaimthenet.org/media-online-safety-bill-rumble" rel="nofollow" title="Media and Architects of Online Censorship Law Heap Pressure on Rumble After it Defends Principle of Neutrality"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/media-online-safety-bill-rumble.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The knives have come out after Rumble rejected UK Parliamentary pressure to punish Russell Brand.</p>
<p>The post <a href="https://reclaimthenet.org/media-online-safety-bill-rumble" rel="nofollow">Media and Architects of Online Censorship Law Heap Pressure on Rumble After it Defends Principle of Neutrality</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## USA v. Google – Week 2
 - [https://reclaimthenet.org/usa-v-google-week-2](https://reclaimthenet.org/usa-v-google-week-2)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-25T17:46:55+00:00

<a href="https://reclaimthenet.org/usa-v-google-week-2" rel="nofollow" title="USA v. Google &#8211; Week 2"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/usa-v-google.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The trial that could change the internet forever.</p>
<p>The post <a href="https://reclaimthenet.org/usa-v-google-week-2" rel="nofollow">USA v. Google &#8211; Week 2</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## TV Networks Join The Pushback Against Australia’s Proposed Anti-“Misinformation” Law
 - [https://reclaimthenet.org/tv-networks-join-the-pushback-against-australias-proposed-anti-misinformation-law](https://reclaimthenet.org/tv-networks-join-the-pushback-against-australias-proposed-anti-misinformation-law)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-25T17:24:16+00:00

<a href="https://reclaimthenet.org/tv-networks-join-the-pushback-against-australias-proposed-anti-misinformation-law" rel="nofollow" title="TV Networks Join The Pushback Against Australia&#8217;s Proposed Anti-&#8220;Misinformation&#8221; Law"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/australis-eepc.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>If you're tired of censorship and dystopian threats against civil liberties, subscribe to Reclaim The Net. In a bid to stand up for freedom of speech, Australian free-to-air broadcast networks have raised criticisms about a proposed legislation aimed at combating so-called “misinformation.” The targets of controversy are the bill&#8217;s nebulous definitions of harm, potential violations [&#8230;]</p>
<p>The post <a href="https://reclaimthenet.org/tv-networks-join-the-pushback-against-australias-proposed-anti-misinforma

## British Army Doctor Punished For Agreeing With The Idea That Men Can’t Be Women Is Cleared
 - [https://reclaimthenet.org/doctor-punished-men-cant-be-women-cleared](https://reclaimthenet.org/doctor-punished-men-cant-be-women-cleared)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-25T17:17:43+00:00

<a href="https://reclaimthenet.org/doctor-punished-men-cant-be-women-cleared" rel="nofollow" title="British Army Doctor Punished For Agreeing With The Idea That Men Can&#8217;t Be Women Is Cleared"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/wright.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>If you're tired of censorship and dystopian threats against civil liberties, subscribe to Reclaim The Net. The cold grip of censorship threat has finally lost its hold on military hero and doctor, Colonel Dr. Kelvin Wright, vindicating his freedom to express deeply held beliefs about gender. The esteemed Army veteran, known for his life saving [&#8230;]</p>
<p>The post <a href="https://reclaimthenet.org/doctor-punished-men-cant-be-women-cleared" rel="nofollow">British Army Doctor Punished For Agreeing With The Idea That Men Can&#8217;t Be Women Is Cleared</a> appeared firs

## Scotland To Set Up New Police Unit To Tackle “Hate” and “Misgendering,” Ignites Free Speech Concerns
 - [https://reclaimthenet.org/scotland-new-police-unit-to-tackle-hate-and-misgendering](https://reclaimthenet.org/scotland-new-police-unit-to-tackle-hate-and-misgendering)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-25T16:55:27+00:00

<a href="https://reclaimthenet.org/scotland-new-police-unit-to-tackle-hate-and-misgendering" rel="nofollow" title="Scotland To Set Up New Police Unit To Tackle &#8220;Hate&#8221; and &#8220;Misgendering,&#8221; Ignites Free Speech Concerns"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/scotland-speech0bill.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>If you're tired of censorship and dystopian threats against civil liberties, subscribe to Reclaim The Net. On the brink of implementing Humza Yousaf&#8217;s highly contentious legislation early next year, a specialized hate crime unit has been announced by Police Scotland. With the unit scheduled to be operational by November, a comprehensive training of about 16,400 [&#8230;]</p>
<p>The post <a href="https://reclaimthenet.org/scotland-new-police-unit-to-tackle-hate-and-misgendering" rel="nofollow">Scotland To Set Up

## China: MeToo Journalist Is On Trial For “Subversion”
 - [https://reclaimthenet.org/china-metoo-journalist-is-on-trial-for-subversion](https://reclaimthenet.org/china-metoo-journalist-is-on-trial-for-subversion)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-25T16:44:32+00:00

<a href="https://reclaimthenet.org/china-metoo-journalist-is-on-trial-for-subversion" rel="nofollow" title="China: MeToo Journalist Is On Trial For &#8220;Subversion&#8221;"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/china-me-too.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>If you're tired of censorship and dystopian threats against civil liberties, subscribe to Reclaim The Net. The trial of a Chinese journalist and her labor rights activist ally is again laying bare China&#8217;s increasingly oppressive statute on civil society. Huang Xueqin, at one time an influential figure in the Chinese #MeToo movement, and Wang Jianbing, [&#8230;]</p>
<p>The post <a href="https://reclaimthenet.org/china-metoo-journalist-is-on-trial-for-subversion" rel="nofollow">China: MeToo Journalist Is On Trial For &#8220;Subversion&#8221;</a> appeared first on <a href="https://reclai

## Republicans and Democrats Clash on CBDC Plans
 - [https://reclaimthenet.org/republicans-and-democrats-clash-on-cbdc-plans](https://reclaimthenet.org/republicans-and-democrats-clash-on-cbdc-plans)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-25T15:49:05+00:00

<a href="https://reclaimthenet.org/republicans-and-democrats-clash-on-cbdc-plans" rel="nofollow" title="Republicans and Democrats Clash on CBDC Plans"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/rvb-r.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>If you're tired of censorship and dystopian threats against civil liberties, subscribe to Reclaim The Net. In a clash of political parties and ideologies, US lawmakers are gearing up for a major debate over the concept of a Central Bank Digital Currency (CBDC). The Democratic and Republican factions are wrestling over several bills, each aiming [&#8230;]</p>
<p>The post <a href="https://reclaimthenet.org/republicans-and-democrats-clash-on-cbdc-plans" rel="nofollow">Republicans and Democrats Clash on CBDC Plans</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

