# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## These houses are spheres
 - [https://www.youtube.com/watch?v=3kwDVw0u4Kw](https://www.youtube.com/watch?v=3kwDVw0u4Kw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2023-09-25T15:00:06+00:00

The Bolwoningen, in Den Bosch, in the Netherlands, are experimental architecture: the surprising part is that people still live there.

Local producer: Jasper Deelen
Camera: Jeroen Simons

Thanks to @NotJustBikes for the Rotterdam cube house footage

A lot of my history research from video is based on 2019 book "Experimentele Woningbouw in Nederland 1968-1980: 64 Gerealiseerde Woonbeloften", by Barzilay, Ferwerda and Blom: https://experimentelewoningbouw.nl/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

