# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Polska ma wzmocnić kolejną granicę. Chodzi o południe kraju
 - [https://wydarzenia.interia.pl/kraj/news-polska-ma-wzmocnic-kolejna-granice-chodzi-o-poludnie-kraju,nId,7048441](https://wydarzenia.interia.pl/kraj/news-polska-ma-wzmocnic-kolejna-granice-chodzi-o-poludnie-kraju,nId,7048441)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-09-25T11:47:34+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polska-ma-wzmocnic-kolejna-granice-chodzi-o-poludnie-kraju,nId,7048441"><img align="left" alt="Polska ma wzmocnić kolejną granicę. Chodzi o południe kraju " src="https://i.iplsc.com/polska-ma-wzmocnic-kolejna-granice-chodzi-o-poludnie-kraju/000HPETMHYE394PB-C321.jpg" /></a>Polska może wzmocnić kontrole na granicy ze Słowacją. Jak podała rzeczniczka SG, od kilku tygodni służby obserwują wzrost napływu nielegalnych imigrantów przybywających do Polski z tego kraju. Polsat News nieoficjalnie dowiedział się, że decyzję o wzmocnieniu kontroli ma ogłosić w najbliższym czasie szef MSWiA Mariusz Kamiński.
</p><br clear="all" />

## Polska wzmacnia kontrole na kolejnej granicy. Chodzi o południe kraju
 - [https://wydarzenia.interia.pl/kraj/news-polska-wzmacnia-kontrole-na-kolejnej-granicy-chodzi-o-poludn,nId,7048441](https://wydarzenia.interia.pl/kraj/news-polska-wzmacnia-kontrole-na-kolejnej-granicy-chodzi-o-poludn,nId,7048441)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-09-25T11:47:34+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polska-wzmacnia-kontrole-na-kolejnej-granicy-chodzi-o-poludn,nId,7048441"><img align="left" alt="Polska wzmacnia kontrole na kolejnej granicy. Chodzi o południe kraju " src="https://i.iplsc.com/polska-wzmacnia-kontrole-na-kolejnej-granicy-chodzi-o-poludn/000HPETMHYE394PB-C321.jpg" /></a>- Poleciłem szefowi MSWiA, aby wprowadzać kontrolę na granicy polsko-słowackiej m.in. busów - przekazał w poniedziałek podczas spotkania z mieszkańcami Kraśnika premier Mateusz Morawiecki. Potwierdził tym samym wcześniejsze informacje Polsat News w tej spawie. 
</p><br clear="all" />

