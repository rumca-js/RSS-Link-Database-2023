# Source:Matt Rickard, URL:https://matt-rickard.com/rss, language:en-US

## Observer-Expectancy at Scale
 - [https://matt-rickard.com/observer-expectancy-at-scale](https://matt-rickard.com/observer-expectancy-at-scale)
 - RSS feed: https://matt-rickard.com/rss
 - date published: 2023-09-25T13:30:27+00:00

In 1968, a group of teachers and students participated in a psychology study. The students were given an IQ test by the researchers. The results were not disclosed to the teachers. The researchers shared with the teachers that five students exhibited unusually high IQ scores and could be expected to outperform that year. The twist: those five students weren’t the highest scorers but rather entirely chosen at random.

At the end of the year, the group of students that were selected at random to h

