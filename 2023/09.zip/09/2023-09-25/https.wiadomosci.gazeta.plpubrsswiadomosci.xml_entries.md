# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Żaryn twierdzi, że TVN "wyolbrzymia temat" afery wizowej. "Nie ma żadnego wątku afrykańskiego"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30229391,zaryn-twierdzi-ze-tvn-wyolbrzymia-temat-afery-wizowej-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30229391,zaryn-twierdzi-ze-tvn-wyolbrzymia-temat-afery-wizowej-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T21:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/d4/1c/z30229393M.jpg" vspace="2" />W tak zwanej aferze wizowej nie ma żadnego "wątku afrykańskiego" - stwierdził Stanisław Żaryn, pełnomocnik rządu ds. bezpieczeństwa przestrzeni informacyjnej RP na antenie Polskiego Radia 24.

## Suchańska do Koboski o "kolesiostwie" i "epoce nepotyzmu". "Jakie gwarancje daje pan wyborcom?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229219,suchanska-do-koboski-o-kolesiostwie-i-epoce-nepotyzmu-jakie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229219,suchanska-do-koboski-o-kolesiostwie-i-epoce-nepotyzmu-jakie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T20:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/21/d4/1c/z30229281M.jpg" vspace="2" />- PSL było królem nepotyzmu, PiS prawdopodobnie je teraz zdetronizował. Pytanie do pana, jakie gwarancje daje pan wyborcom, że PSL zamknęło niechlubną epokę nepotyzmu i kolesiostwa? - pytała Katarzyna Suchańska z Bezpartyjnych Samorządowców przedstawiciela Trzeciej Drogi Michała Kobosko podczas debaty w Gazeta.pl.

## Lubnauer do przedstawicielki Bezpartyjnych Samorządowców: Dlaczego oszukujecie społeczeństwo?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229139,debata-gazeta-pl-lubnauer-do-przedstawicielki-bezpartyjnych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229139,debata-gazeta-pl-lubnauer-do-przedstawicielki-bezpartyjnych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T19:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cf/d4/1c/z30229199M.jpg" vspace="2" />Podczas debaty wyborczej w Gazeta.pl Katarzyna Lubnauer zapytała przedstawicielkę Bezpartyjnych Samorządowców o nazwę ugrupowania, które reprezentuje, wskazując, że może mylić wyborców. - Dlaczego państwo w pewnym stopniu oszukujecie społeczeństwo? - pytała posłanka Koalicji Obywatelskiej.

## Morawiecki grzmi na Zełenskiego: "Niech pan nie waży się!". Oberwał też Scholz: "Lepiej zobacz swoją!"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229193,morawiecki-grzmi-na-zelenskiego-niech-pan-nie-wazy-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229193,morawiecki-grzmi-na-zelenskiego-niech-pan-nie-wazy-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T19:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/73/d4/1c/z30228851M,Krasnik--Wiec-wyborczy-PiS-z-udzialem-premiera-Mat.jpg" vspace="2" />Mateusz Morawiecki w poniedziałek gościł w Kraśniku. Premier tradycyjnie zaatakował Donalda Tuska. Krytycznych słów nie szczędził także wobec Agnieszki Holland, Wołodymyra Zełenskiego i Olafa Scholza. Co mówił podczas wiecu?

## Debata Gazeta.pl. Padło pytanie o obowiązkowe wybory. Biejat o walkach w kisielu, Suchańska zmieniła temat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229117,debata-gazeta-pl-padlo-pytanie-o-obowiazkowe-wybory-biejat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229117,debata-gazeta-pl-padlo-pytanie-o-obowiazkowe-wybory-biejat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T19:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c4/d4/1c/z30229188M,Magdalena-Biejat.jpg" vspace="2" />W poniedziałek przedstawiciele niemal wszystkich ugrupowań, które biorą udział w wyborach parlamentarnych w 2023 roku, wzięli udział w debacie wyborczej Gazeta.pl. Politycy zmierzyli się m.in. z pytaniem o obowiązkowy udział w wyborach. To jedna z niewielu kwestii, w których byli zgodni.

## Po fazie zmiękczania jest faza uderzenia. Ukraińcy ewidentnie mają plan na Krym
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30227608,po-fazie-zmiekczania-jest-faza-uderzenia-ukraincy-ewidentnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30227608,po-fazie-zmiekczania-jest-faza-uderzenia-ukraincy-ewidentnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T18:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ac/d3/1c/z30227884M,Dym-unoszacy-sie-po-ukrainskim-ataku-na-sztab-Flot.jpg" vspace="2" />Krym miał być fortecą osłoniętą przed atakiem z powietrza przez szczelną bańkę tworzoną przez systemy przeciwlotnicze. Sami Rosjanie najwyraźniej w to wierzyli. Ukraińcy zdołali jednak brutalnie wyprowadzić ich z błędu. Nie ma wątpliwości, że ich przygotowania dały efekt.

## Bezpartyjni Samorządowcy w koalicji z PiS? "Jeśli ktoś miał wątpliwości, to usłyszał"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229119,bezpartyjni-samorzadowcy-przestana-wspoldzialac-z-pis-jesli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229119,bezpartyjni-samorzadowcy-przestana-wspoldzialac-z-pis-jesli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T18:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b8/d4/1c/z30229176M,Katarzyna-Suchanska-reprezentujaca-Bezpartyjnych-S.jpg" vspace="2" />Michał Kobosko z Polski 2050, który reprezentował Trzecią Drogę w debacie przeprowadzonej przez Gazeta.pl, zadał pytanie do przedstawicielki Bezpartyjnych Samorządowców. Polityk chciał wiedzieć, czy ugrupowanie to zamierza "zerwać" koalicję z Prawem i Sprawiedliwością w województwie dolnośląskim.

## Tragedia w Czernikach. Paulina G. ma bronić ojca "za wszelką cenę". Nie okazuje żadnej skruchy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30228983,tragedia-w-czernikach-paulina-g-ma-bronic-ojca-za-wszelka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30228983,tragedia-w-czernikach-paulina-g-ma-bronic-ojca-za-wszelka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T18:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a9/d3/1c/z30226601M,Czerniki--Dom--w-ktorym-doszlo-do-tragedii.jpg" vspace="2" />W piwnicy domu w Czernikach odkryto ciała trzech noworodków. O zbrodnię podejrzany jest ojciec oraz jego 20-letnia córka Paulina. Dziennikarze "Faktu" dotarli teraz do osoby, która zna ustalenia śledczych w tej sprawie. - To jest szokujące i wręcz straszne, ta kobieta broni ojca za wszelką cenę, twierdzi, że wszystko jest w porządku - powiedział informator.

## Władimir Putin na unikatowym nagraniu z lat 90. Tajne wakacje, dres i "kiepska fryzura" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30228756,wladimir-putin-na-unikatowym-nagraniu-z-lat-90-tajne-wakacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30228756,wladimir-putin-na-unikatowym-nagraniu-z-lat-90-tajne-wakacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T17:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0c/d4/1c/z30229004M,Finska-telewizja-opublikowala-nieznane-nagrania-z-.jpg" vspace="2" />Fińska telewizja opublikowała nieznane dotąd nagrania z Władimirem Putinem. Przekazano, że materiały zostały nakręcone podczas wakacji spędzanych przez Putina w Finlandii w latach 90. Filmy pokazują, jak prezydent Rosji "wyglądał, zanim się wzbogacił".

## Debata Gaztea.pl. Ochrona zdrowia - jak ją poprawić? "Nie da się nic", "PiS nie wyciągnął wniosków"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229010,ochrona-zdrowia-w-debacie-gazeta-pl-jak-ja-poprawic-nie-da.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30229010,ochrona-zdrowia-w-debacie-gazeta-pl-jak-ja-poprawic-nie-da.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T17:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/39/d4/1c/z30229049M,Politycy-KO--Konfederacji--Bezpartyjnych-Samorzado.jpg" vspace="2" />W poniedziałek przedstawiciele niemal wszystkich ugrupowań, które biorą udział w wyborach parlamentarnych w 2023 roku, wzięli udział w debacie wyborczej Gazeta.pl. Jak z pytaniem o ochronę zdrowia poradzili sobie politycy z Koalicji Obywatelskiej, Konfederacji, Bezpartyjnych Samorządowców, Lewicy i Trzeciej Drogi?

## Sekielscy zapowiedzieli dwa filmy. Długo oczekiwany dokument o aferze SKOK jeszcze przed wyborami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30228763,dwa-filmy-bra.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30228763,dwa-filmy-bra.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T17:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2a/d4/1c/z30228778M.jpg" vspace="2" />Dokument o aferze SKOK zostanie wyemitowany przed nadchodzącymi wyborami parlamentarnymi - zapowiedział Tomasz Sekielski w swoim programie "Studio wyborcze" w serwisie YouTube.

## Niemcy. Prasa o sporze migracyjnym między Warszawą a Berlinem: Ton staje się coraz ostrzejszy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30228952,niemcy-prasa-o-sporze-migracyjnym-miedzy-warszawa-a-berlinem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30228952,niemcy-prasa-o-sporze-migracyjnym-miedzy-warszawa-a-berlinem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T17:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/21/d1/1c/z30218017M,Zbigniew-Rau.jpg" vspace="2" />Prasa w Niemczech komentuje plany niemieckiego rządu dotyczący kontroli granic z Polską i Czechami. Eksperci różnie je oceniają.

## Debata wyborcza w Gazeta.pl. PiS nie odpowiedział na zaproszenie. Reszta polityków w komplecie [NA ŻYWO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228608,debata-wyborcza-w-gazeta-pl-pis-nie-odpowiedzial-na-zaproszenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228608,debata-wyborcza-w-gazeta-pl-pis-nie-odpowiedzial-na-zaproszenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T17:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/d1/1c/z30219296M,Debata-wyborcza-Gazeta-pl.jpg" vspace="2" />W poniedziałek o 19 rozpoczęła się wyjątkowa debata wyborcza w Gazeta.pl. Porozmawiamy z politykami na tematy, które dla naszych Czytelniczek i Czytelników są najistotniejsze: ochrona zdrowia, edukacja i inflacja. W debacie uczestniczą przedstawiciele wszystkich komitetów wyborczych poza Prawem i Sprawiedliwością - nasza redakcja nie otrzymała od ugrupowania Jarosława Kaczyńskiego odpowiedzi na zaproszenie.

## Krzyczała na Tuska. "Wyobraża sobie pani, żeby ktoś mógł stanąć tak blisko i wygrażać Kaczyńskiemu?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228905,krzyczala-na-tuska-wyobraza-sobie-pani-zeby-ktos-mogl-stanac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228905,krzyczala-na-tuska-wyobraza-sobie-pani-zeby-ktos-mogl-stanac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T16:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e8/d4/1c/z30228968M,Donald-Tusk-i-Rafal-Trzaskowski-na-wiecu-w-Otwocku.jpg" vspace="2" />Przemówienie Donalda Tuska w Otwocku zostało przerwane przez jedną z kobiet, która zaczęła krzyczeć na lidera PO. Polityk zaproponował jej wówczas, by się zastanowiła nad tym, czy do podobnej sytuacji i wygrażania mogłoby dojść na wiecu z udziałem Jarosława Kaczyńskiego. - Spójrzcie na nas, policja nie grodzi nas (...), ale nie zobaczycie tego w TVP - zauważył Tusk. Były premier ubolewał też nad tym, że Kaczyński nie chce zdecydować się na debatę. - To nie jest MMA, ja bym mu krzywdy nie zrobił - stwierdził przewodniczący PO.

## O imprezie księży w Dąbrowie Górniczej piszą media od Czech po Kolumbię. "Orgia w Polsce"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30228625,seksskandal-z-udzialem-ksiezy-w-dabrowie-gorniczej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30228625,seksskandal-z-udzialem-ksiezy-w-dabrowie-gorniczej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T16:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b6/d4/1c/z30228662M.jpg" vspace="2" />Nie milkną echa imprezy z udziałem księży i sexworkera na plebanii w Dąbrowie Górniczej. O sprawie rozpisują się zagraniczne media - od czeskich po kolumbijskie. "Tuż przed wyborami parlamentarnymi gejowska orgia wstrząsa wizerunkiem Kościoła" - pisze na przykład niemiecki T-online.

## Cała rodzina zginęła w wypadku na A1. Na nowych nagraniach mowa jest o bmw. Co na to policja?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30228682,cala-rodzina-zginela-w-wypadku-na-a1-wolali-o-pomoc-na-nagraniach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30228682,cala-rodzina-zginela-w-wypadku-na-a1-wolali-o-pomoc-na-nagraniach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T16:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/41/d1/1c/z30217281M,BMW-zniszczone-w-wyniku-wypadku-na-autostradzie-A1.jpg" vspace="2" />Martyna, Patryk i ich pięcioletni syn Oliwier zginęli w wypadku na autostradzie A1. Od tego momentu w mediach społecznościowych publikowane są nagrania, na których ma być widać, że w zdarzeniu uczestniczył także inny pojazd, o którym nie wspominała policja. Chodzi o bmw, które miało z ogromną prędkością zajechać drogę osobówce. Teraz prokuratura podaje, że pojawił się wątek dwóch innych, rannych w zdarzeniu osób. Okoliczności nadal są jednak ustalane.

## Łukasz Mejza ma dziesiątki plakatów na wsiach, chociaż wyborcy go nie znają. "Powiesili, to niech wisi"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228540,lukasz-mejza-ma-dziesiatki-plakatow-w-lubuskich-wsiach-wyborcy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228540,lukasz-mejza-ma-dziesiatki-plakatow-w-lubuskich-wsiach-wyborcy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T15:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ee/d4/1c/z30228718M,Plakat-Lukasza-Mejzy-w-Krosnie-Odrzanskim--10-07-2.jpg" vspace="2" />Łukasz Mejza prowadzi przedwyborczą ofensywę w województwie lubuskim. W tamtejszych wsiach można zobaczyć liczne plakaty kandydata Prawa i Sprawiedliwości do Sejmu, a w niektórych miejscowościach wiszą wyłącznie banery z Mejzą. Wielu mieszkańców nie wie jednak zbyt dużo o Łukaszu Mejzie ani aferach, w które był zamieszany. Przyznają też, że jest im wszystko jedno, jaki polityk reklamuje się na ich płotach.

## Zełenski w Kanadzie oklaskiwał 98-letnigo imigranta. Okazało się, że służył w SS. Polska żąda przeprosin
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30228422,zelenski-w-kanadzie-oklaskiwal-98-letnigo-imigranta-okazalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30228422,zelenski-w-kanadzie-oklaskiwal-98-letnigo-imigranta-okazalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T15:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/00/d4/1c/z30228480M,Wolodymyr-Zelenski-w-Toronto.jpg" vspace="2" />Podczas wizyty Wołodymyra Zełenskiego w kanadyjskim parlamencie doszło do skandalu. Uhonorowano i wiwatowano na cześć ukraińsko-kanadyjskiego zbrodniarza wojennego. Polska ambasada stanowczo zareagowała, domagając się przeprosin.

## Prorządowy portal ujawnił nagrania z ataku na Budkę. "Kolejny raz wyciekają informacje z postępowania"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228454,prorzadowy-portal-ujawnil-nagrania-z-ataku-na-budke-kolejny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228454,prorzadowy-portal-ujawnil-nagrania-z-ataku-na-budke-kolejny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T14:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b1/d2/1c/z30221489M,Borys-Budka.jpg" vspace="2" />Prorządowy portal opublikował nagranie z kamery monitoringu, która znajduje się w galerii handlowej, gdzie napadnięty został poseł KO Borys Budka oraz ujawnili to, co miał zeznać podejrzany w sprawie mężczyzna. - Bulwersujące jest to, że kolejny raz wyciekają informacje z postępowania. Jako pokrzywdzony będę reprezentowany przez profesjonalnego pełnomocnika, a sąd - nie propagandyści - zdecyduje jaką karę wymierzy sprawcy - skomentował to wydarzenie Borys Budka, który jest pokrzywdzonym w tej sprawie.

## Liczba ofiar ataku na Sewastopol wzrosła. Kijów potwierdza: Nie żyje rosyjski dowódca Wiktor Sokołow
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30228045,liczba-ofiar-ataku-na-sewastopol-wzrosla-kijow-potwierdza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30228045,liczba-ofiar-ataku-na-sewastopol-wzrosla-kijow-potwierdza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T14:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a4/d3/1c/z30228132M,Piatkowy-atak-na-Sewastopol--25-09-2023-.jpg" vspace="2" />W wyniku piątkowego ataku na Sewastopol zginęło 34 oficerów oraz dowódca - przekazało Dowództwo Sił Operacji Specjalnych Sił Zbrojnych Ukrainy. Tym samym potwierdzono śmierć admirała Wiktora Sokołowa.

## "Panowie z PiS-u" unikają debat, ale chętnie przerywają konferencje opozycji. "Próbują kręcić aferę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228126,panowie-z-pis-u-unikaja-debat-ale-chetnie-przerywaja-konferencje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30228126,panowie-z-pis-u-unikaja-debat-ale-chetnie-przerywaja-konferencje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T14:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c3/d3/1c/z30228419M,Politycy-PiS-probowali-przerwac-konferencje-opozyc.jpg" vspace="2" />Rzecznicy klubu PiS i rządu próbowali przerwać konferencję prasową posłów PO na temat afery dwóch wież i afery związanej z "kopertą Kaczyńskiego". W pewnym momencie Piotr Muller odpowiedział politykom opozycji, że "zaraz oddadzą im briefing", a następnie jak gdyby nigdy nic zaprosił dziennikarzy do zadawania pytań. Mówił m.in. o zbożu z Ukrainy i Olafie Scholzu, próbując odwrócić uwagę od polityków PO, którzy zdaniem rzeczników PiS "próbują kręcić kolejną aferę".

## Jacek Bartosiak może stracić doktorat. Dr Piegzik: Zasygnalizowałem wątpliwości PAN
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30227036,jacek-bartosiak-moze-stracic-doktorat-dr-piegzik-zasygnalizowalem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30227036,jacek-bartosiak-moze-stracic-doktorat-dr-piegzik-zasygnalizowalem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T13:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/69/d1/1c/z30217065M,Jacek-Bartosiak.jpg" vspace="2" />Doktor Jacek Bartosiak, popularny w Polsce specjalista od geopolityki, może przestać być doktorem. Z ustaleń Gazeta.pl wynika, że jego praca doktorska i kluczowa książka mają być w istotnej części plagiatami. W poniedziałek oświadczenie wydał Michał A. Piegzik, który jako pierwszy zgłosił wątpliwości do wspomnianej rozprawy naukowej.

## Lublin. 17-latek może iść do więzienia na 12 lat. "Nazbierał" całą listę zarzutów, w tym gwałt
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30227398,lublin-17-latek-trafil-do-aresztu-za-rozboje-i-gwalt-moze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30227398,lublin-17-latek-trafil-do-aresztu-za-rozboje-i-gwalt-moze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T13:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/84/d3/1c/z30227588M,Lublin--17-latek-trafil-do-aresztu--za-rozboje-i-g.jpg" vspace="2" />Trzy miesiące aresztu dla 17-latka z Lublina, który jest podejrzany o gwałt, usiłowanie rozboju, rozbój, nakłanianie do zażycia narkotyków oraz zmuszenie do innej czynności seksualnej. Młody mężczyzna za wszystkie te przestępstwa może trafić do więzienia na 12 lat.

## Politycy PiS rozdają komputery w szkołach w czasie kampanii. W swoich okręgach wyborczych
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30227576,politycy-pis-rozdaja-komputery-w-szkolach-w-czasie-kampanii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30227576,politycy-pis-rozdaja-komputery-w-szkolach-w-czasie-kampanii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T13:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a5/d3/1c/z30228133M,Anna-Krupka-rozdaje-laptopy.jpg" vspace="2" />Politycy PiS z okręgu świętokrzyskiego rozdają uczniom laptopy z rządowego programu "Laptop dla ucznia" w swoich okręgach wyborczych. Wcześniej zarzekali się, że nie będą traktować tego projektu jako tzw. kiełbasy wyborczej - informuje "Dziennik Gazeta Prawna".

## Wojskowe myśliwce wylądowały na drodze w Polsce. Piloci ćwiczą procedurę "touch-and-go" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30227602,wojskowe-mysliwce-wyladowaly-na-drodze-publicznej-w-polsce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30227602,wojskowe-mysliwce-wyladowaly-na-drodze-publicznej-w-polsce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T13:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/88/d3/1c/z30228104M,Procedura--touch-and-go--podczas-cwiczen-polskiego.jpg" vspace="2" />W województwie warmińsko-mazurskim trwa szkolenie polskiego lotnictwa. W ramach ćwiczeń na zamkniętej drodze publicznej między Nidzicą a Wielbarkiem lądowały wojskowe myśliwce. Na pokładzie jednego z nich znajdował się Inspektor Sił Powietrznych.

## Kreml pracuje nad reelekcją Władimira Putina. W wygraniu wyborów ma mu pomóc "demokratyczny rywal"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30227318,kreml-pracuje-nad-reelekcja-wladimira-putina-w-zdobyciu-wladzy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30227318,kreml-pracuje-nad-reelekcja-wladimira-putina-w-zdobyciu-wladzy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T13:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/d3/1c/z30227861M,Wladimir-Putin.jpg" vspace="2" />W przyszłym roku w Rosji odbędą się wybory prezydenckie. W związku z tym Kreml już opracowuje strategię, dzięki której Władimir Putin będzie mógł je wygrać. Wśród pomysłów ma być m.in. udział "demokratycznego rywala".

## Bukmacherzy obstawiają wyniki wyborów. Ile procent zbierze PiS? Konfederacja czy Trzecia Droga?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30227365,bukmacherzy-obstawiaja-wyniki-wyborow-ile-procent-zbierze-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30227365,bukmacherzy-obstawiaja-wyniki-wyborow-ile-procent-zbierze-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T13:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e9/d3/1c/z30227689M,Wybory-2023--zdjecie-ilustracyjne-.jpg" vspace="2" />Zbliżające się wybory parlamentarne są tematem wielu przewidywań, spekulacji. Bukmacherzy też opublikowali swoje: obstawili kwestie dotyczące frekwencji i poparcia dla poszczególnych partii.

## Impreza księży w Dąbrowie Górniczej. O. Gużyński: Rozpusta, rozpasanie, bezrozum. Czubek góry lodowej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226872,impreza-ksiezy-w-dabrowie-gorniczej-o-guzynski-rozpusta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226872,impreza-ksiezy-w-dabrowie-gorniczej-o-guzynski-rozpusta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T12:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/40/d3/1c/z30227264M,Msza--zdjecie-ilustracyjne-.jpg" vspace="2" />Podczas audycji w radiu TOK FM dominikanin o. Paweł Gużyński odniósł się do imprezy z udziałem pracownika seksualnego, którą zorganizowali księża z parafii w Dąbrowie Górniczej. Duchowny podkreślił, że sytuacja ta, to wierzchołek góry lodowej i skrytykował władze kościelne za brak zdecydowanej reakcji na tego typu skandale.

## Zabójstwo noworodków w Czernikach. Piotr G. miał znęcać się nad swoją żoną. "On ją wykończył"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226293,zabojstwo-noworodkow-w-czernikach-piotr-g-mial-znecac-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226293,zabojstwo-noworodkow-w-czernikach-piotr-g-mial-znecac-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T12:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a9/d3/1c/z30226601M,Czerniki--Dom--w-ktorym-doszlo-do-tragedii.jpg" vspace="2" />- Kiedyś zwierzyła mi się, że Piotr wchodzi w nocy do łóżka ich córkom. Mówiłam, by to zgłosiła, ale ona się bała. Mówiła nawet, że on może ją wtedy zabić - opowiedziała "Faktowi" o zmarłej 15-lat temu Hannie G. sąsiadka rodziny z miejscowości Czerniki (woj. pomorskie). Makabryczne odkrycie zwłok trojga noworodków w domu rodziny G. rozwiązało sąsiadom języki i odświeżyło ich pamięć.

## Posłanka KO Marta Wcisło zaatakowana. "Zaczął mnie szarpać, grozić i wyzywać"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30227497,poslanka-ko-marta-wcislo-zaatakowana-zaczal-mnie-szarpac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30227497,poslanka-ko-marta-wcislo-zaatakowana-zaczal-mnie-szarpac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T11:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/53/c8/1c/z30182227M,Poslanka-PO-Marta-Wcislo.jpg" vspace="2" />"Zostałam zaatakowana na targu w Opolu Lubelskim. Nieznany mężczyzna zaczął mnie szarpać, grozić i wyzywać" - pisze Marta Wcisło w mediach społecznościowych i publikuje nagranie. To kolejna polityczka Koalicji Obywatelskiej, która została zaatakowana przez wyborcę. Podobna sytuacja przytrafiła się ostatnio także Borysowi Budce.

## Obywatele Ugandy protestowali przed polskim konsulatem. "Chcemy dostać to, za co zapłaciliśmy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30226556,obywatele-ugandy-protestowali-przed-polskim-konsulatem-chcemy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30226556,obywatele-ugandy-protestowali-przed-polskim-konsulatem-chcemy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T11:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/00/d3/1c/z30227200M,Afrykanczycy-protestuja-z-powodu-polskich-wiz--kto.jpg" vspace="2" />Obywatele Ugandy organizują protesty przed polskim konsulatem w Kampali. Twierdzą, że zapłacili, by dostać polskie wizy i pozwolenie na pracę. - Oczekujemy sprawiedliwości. Chcemy dostać to, za co zapłaciliśmy - mówią Ugandyjczycy.

## Impreza na plebanii. Proboszcz ujawnił na mszy dane księdza organizatora. Parafianie: Przystojny mężczyzna
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226798,impreza-na-plebanii-proboszcz-ujawnil-na-mszy-dane-ksiedza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226798,impreza-na-plebanii-proboszcz-ujawnil-na-mszy-dane-ksiedza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T11:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/d0/1c/z30214203M,Kosciol--Ksiadz-wyprosil-rodzine-podczas-mszy--pon.jpg" vspace="2" />Proboszcz parafii w Dąbrowie Górniczej ujawnił podczas mszy dane księdza, w którego mieszkaniu odbyła się impreza duchownych z udziałem pracownika seksualnego. Parafianie określili głównego bohatera skandalu jako "przystojnego mężczyznę". - Znałem księdza Tomasza bardzo dobrze, w życiu nigdy bym nic takiego nie przypuszczał - komentował pan Stanisław.

## Bosak o "Zielonej granicy": "To gra PiS-u i PO". Padły też szokujące słowa o strzelaniu do migrantów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225753,bosak-o-zielonej-granicy-to-gra-pis-u-i-po-padly-tez-szokujace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225753,bosak-o-zielonej-granicy-to-gra-pis-u-i-po-padly-tez-szokujace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T11:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8a/d3/1c/z30226314M,Krzysztof-Bosak.jpg" vspace="2" />- Obrażanie osób, które chcą zobaczyć głośny i kontrowersyjny film jest dla mnie osobiście niedorzeczne - podkreślił Krzysztof Bosak na temat używania hasła "Tylko świnie siedzą w kinie" w kontekście filmu "Zielona granica". Równocześnie z ust polityka Konfederacji padły szokujące słowa na temat możliwości strzelania strażników granicznych do migrantów. - Żołnierze i funkcjonariusze mają broń, żeby jej czasami używać - stwierdził.

## Debata wyborcza w Gazeta.pl. PiS nie odpowie na problemy Czytelniczek i Czytelników. Reszta polityków w komplecie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30226243,debata-wyborcza-w-gazeta-pl-pis-nie-odpowie-na-problemy-czytelniczek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30226243,debata-wyborcza-w-gazeta-pl-pis-nie-odpowie-na-problemy-czytelniczek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T10:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/d1/1c/z30219296M,Debata-wyborcza-Gazeta-pl.jpg" vspace="2" />W poniedziałek o 19 rozpocznie się wyjątkowa debata wyborcza w Gazeta.pl. Porozmawiamy z politykami na tematy, które dla naszych Czytelniczek i Czytelników są najistotniejsze: ochrona zdrowia, edukacja i inflacja. W debacie będą uczestniczyć przedstawiciele wszystkich komitetów wyborczych poza Prawem i Sprawiedliwością - nasza redakcja nie otrzymała od ugrupowania Jarosława Kaczyńskiego odpowiedzi na zaproszenie.

## Piloci myśliwców wylądują na Mazurach na drodze publicznej. Rozpoczęły się ćwiczenia lotnictwa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226182,piloci-mysliwcow-wyladuja-na-mazurach-na-drodze-publicznej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226182,piloci-mysliwcow-wyladuja-na-mazurach-na-drodze-publicznej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T10:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/93/d3/1c/z30226579M,Cwiczenia-lotnicze-na-drodze-wojewodzkiej-nr-604.jpg" vspace="2" />Szkolenie polskiego lotnictwa pod kryptonimem ROUTE 604 rozpoczęło się w woj. warmińsko-mazurskim. Podczas ćwiczeń piloci trenować będą lądowanie i startowanie ze specjalnie przystosowanego odcinka drogi publicznej. Na potrzeby wojskowych szkoleń zamknięty został trzykilometrowy fragment drogi wojewódzkiej nr 604 biegnącej między Nidzicą a Wielbarkiem.

## Polak na liście poszukiwanych przez Rosję. To prezes Międzynarodowego Trybunału Karnego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30226963,polak-na-liscie-poszukiwanych-przez-rosje-to-preze-miedzynarodowego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30226963,polak-na-liscie-poszukiwanych-przez-rosje-to-preze-miedzynarodowego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T10:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/17/a1/19/z26874647M,Polak-prezydentem-Miedzynarodowego-Trybunalu-Karne.jpg" vspace="2" />Rosyjski MSZ umieścił na liście poszukiwanych polskiego prawnika. To prof. Piotr Hofmański, prezes Międzynarodowego Trybunału Sprawiedliwości - informuje rosyjska agencja TASS.

## Ten polityczny nie należy do najłatwiejszych! Komplet punktów jest nieosiągalny
 - [https://wiadomosci.gazeta.pl/wiadomosci/13,129662,18757,ten-polityczny-nie-nalezy-do-najlatwiejszych-komplet.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/13,129662,18757,ten-polityczny-nie-nalezy-do-najlatwiejszych-komplet.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T10:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d5/5a/1c/z29729749M,Grafika-do-quizu-politycznego.jpg" vspace="2" />8/10 to już niezły wyczyn!

## Sondaż zaufania: Powrót Szydło i spadek Trzaskowskiego. "Jeśli KO nie wygra, to będzie przyczyna porażki"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30226322,sondaz-zaufania-powrot-szydlo-i-spadek-trzaskowskiego-jesli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30226322,sondaz-zaufania-powrot-szydlo-i-spadek-trzaskowskiego-jesli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T09:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a0/d2/1c/z30223520M.jpg" vspace="2" />Rafał Trzaskowski stracił pozycję lidera w najnowszym sondażu IBRIS dla Onetu. Zaufaniem Polaków cieszy się przede wszystkim Andrzej Duda, a na podium pojawił się również Mateusz Morawiecki. Dużym zaskoczeniem jest również wzrost zaufania do Beaty Szydło i Mariusza Błaszczaka.

## Awantura podczas debaty w TVN24. Polityczka Konfederacji: Tak się rozmawia z blondynką
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225811,polityczka-partii-konfederacja-nazwala-uczestniczke-debaty-blondynka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225811,polityczka-partii-konfederacja-nazwala-uczestniczke-debaty-blondynka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T09:21:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4c/d3/1c/z30226252M,Awantura-podczas-debaty--Polityczka-z-partii-Konfe.jpg" vspace="2" />- Tak się rozmawia z blondynką - stwierdziła Ewa Zajączkowska-Hernik z Konfederacji podczas debaty w TVN24. Jej słowa spotkały się z błyskawicznym sprzeciwem polityczek w studiu oraz internautów w mediach społecznościowych. Ale jej partyjny kolega stwierdził, że "Zajączkowska pozamiatała".

## Grzegorz zaginął w Tatrach w sobotę. Żona prosi o pomoc: Mógł złamać nogę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226139,grzegorz-zaginal-w-tatrach-w-sobote-zona-prosi-o-pomoc-mogl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30226139,grzegorz-zaginal-w-tatrach-w-sobote-zona-prosi-o-pomoc-mogl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T09:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/04/d3/1c/z30226180M,Grzegorz-zaginal-w-Tatrach-Slowackich.jpg" vspace="2" />Od rana ratownicy prowadzą poszukiwania polskiego turysty, który zaginął w sobotę w rejonie Lodowego Szczytu w Słowackich Tatrach. O pomoc w mediach apeluje jego żona. Z jej relacji wynika, że ma on prawdopodobnie złamaną nogę.

## Cypr. Zginął Polak, który szedł pieszo po autostradzie oraz policjant, który starał się mu pomóc
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30225665,cypr-zginal-polak-ktory-szedl-pieszo-po-autostradzie-oraz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30225665,cypr-zginal-polak-ktory-szedl-pieszo-po-autostradzie-oraz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T08:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/60/d3/1c/z30226016M,Radiowoz-cypryjskiej-policji--zdjecie-ilustracyjne.jpg" vspace="2" />Mężczyźnie z Polski, który na Cyprze szedł pieszo po autostradzie, próbował pomóc cypryjski policjant - usiłował go nakłonić, by zszedł z drogi. Podczas tej interwencji obaj zostali potrąceni przez jadący samochód. 50-letni policjant zginął na miejscu, 48-letni Piotr W. zmarł po przewiezieniu do szpitala. Policja prowadzi śledztwo w sprawie wypadku. Na Cyprze ogłoszono trzydniową żałobę.

## Sophia Loren w szpitalu. Aktorka przeszła poważną operację po wypadku w swoim domu w Szwajcarii
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30225959,sophia-loren-w-szpitalu-aktorka-przeszla-powazna-operacje-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30225959,sophia-loren-w-szpitalu-aktorka-przeszla-powazna-operacje-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T08:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fa/d3/1c/z30225658M,Sophia-Loren.jpg" vspace="2" />Sophia Loren trafiła do szpitala po wypadku, do którego doszło w jej domu w Genewie. 89-letnia aktorka doznała poważnych obrażeń. Przeszła już pilną operację i przebywa w szpitalu w Szwajcarii.

## Po napaści na Borysa Budkę zarzuty może usłyszeć sam polityk? Ziobro: Prokurator będzie musiał to rozważyć
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225896,po-napasci-na-borysa-budke-zarzuty-moze-uslyszec-sam-polityk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225896,po-napasci-na-borysa-budke-zarzuty-moze-uslyszec-sam-polityk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T08:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dc/d3/1c/z30226140M,Po-napasci-na-Borysa-Budke-zarzuty-moze-uslyszec-s.jpg" vspace="2" />Prokurator generalny Zbigniew Ziobro nie wykluczył, że w sprawie piątkowej napaści na Borysa Budkę postawione zostaną nowe zarzuty. I to samemu politykowi, który był ofiarą ataku. - Mamy już nagrania z monitoringu, które wskazują, że pan Borys Budka mijał się z prawdą - stwierdził szef resortu sprawiedliwości. I dodał, że prokurator "będzie musiał rozważyć" ewentualne zarzuty w sprawie składania fałszywych zeznań.

## Antycyklon Rosi zatrzyma lato na dłużej, ale synoptycy zapowiadają stopniowe nadejście ochłodzenia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30225547,antycyklon-rosi-zatrzyma-lato-na-dluzej-ale-synoptycy-zapowiadaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30225547,antycyklon-rosi-zatrzyma-lato-na-dluzej-ale-synoptycy-zapowiadaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T07:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f5/d3/1c/z30225653M,Pogoda--zdjecie-ilustracyjne-.jpg" vspace="2" />Pogoda w nadchodzącym tygodniu zaskoczy ciepłą temperaturą i słonecznymi dniami. To nadejście antycyklonu Rosi sprawi, że lato będzie trwało dłużej. Zmiana może nastąpić na przełomie września i października. Synoptycy ustalili, kiedy może pojawić się stopniowe ochłodzenie zapowiadające jesień.

## "GW": Ziobro ma kwity na Kaczyńskiego. Może chodzić o kopertę z pieniędzmi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225586,gw-ziobro-ma-kwity-na-kaczynskiego-moze-chodzic-o-koperte.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225586,gw-ziobro-ma-kwity-na-kaczynskiego-moze-chodzic-o-koperte.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T07:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7a/d3/1c/z30225786M,-GW---Ziobro-ma-kwity-na-Kaczynskiego--Moze-chodzi.jpg" vspace="2" />Koperta z 50 tysiącami złotych może być "hakiem", który Zbigniew Ziobro ma na Jarosława Kaczyńskiego - pisze Wojciech Czuchnowski z "Gazety Wyborczej". Dziennikarz ujawnił nagrania z przesłuchania austriackiego biznesmena zaangażowanego w budowę dwóch luksusowych biurowców w Warszawie na działce spółki Srebrna. Gerald Birgfellner miał wręczyć pieniądze za pośrednictwem Kaczyńskiego.

## Śmierć "ostatniego ojca chrzestnego". Włoski mafioso przez 30 lat ukrywał się przed śledczymi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30225452,smierc-ostatniego-ojca-chrzestnego-wloski-mafioso-przez-30.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30225452,smierc-ostatniego-ojca-chrzestnego-wloski-mafioso-przez-30.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T07:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c4/d3/1c/z30225604M,Matteo-Messina-Denaro.jpg" vspace="2" />Matteo Messina Denaro, jeden z najwyżej postawionych włoskich mafiosów, zmarł w poniedziałek w oddziale więziennym szpitala. Kryminalista, który od ponad 30 lat poszukiwany był w związku z licznymi morderstwami, cierpiał na raka jelit. To właśnie choroba przestępcy pomogła służbom w ujęciu go w styczniu tego roku.

## Absurdalny spór w "Sprawie dla reportera". Ciapunio zjadł 100 główek kapusty? "Policja siedzi mu na ogonie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30225449,podejrzewaja-ciapunia-o-zjedzenie-100-glowek-kapusty-chciala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30225449,podejrzewaja-ciapunia-o-zjedzenie-100-glowek-kapusty-chciala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T07:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6d/d3/1c/z30225517M,Sprawa-dla-reportera-w-TVP--Pies-Ciapunio-zjadl-10.jpg" vspace="2" />Konflikt sąsiedzki w miejscowości Janiszów (woj. lubelskie) przybrał niespodziewany obrót, kiedy z pola jednej ze stron rzekomo zniknęło 100 główek kapusty. Podejrzanym stał się pies Ciapunio, czyli kundelek niewielkich rozmiarów, który poruszył serca internautów, gdy padło na niego podejrzenie. W sieci pojawiło się mnóstwo dowodów wsparcia i teorii na temat psa, który był jednym z bohaterów programu TVP "Sprawa dla reportera".

## Liczba migrantów w Niemczech gwałtownie rośnie. Przez Polskę wiodą dwa szlaki przerzutowe
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30225460,liczba-nielegalnych-migrantow-w-niemczech-gwaltownie-rosnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30225460,liczba-nielegalnych-migrantow-w-niemczech-gwaltownie-rosnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T06:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ae/d3/1c/z30225582M,Liczba-nielegalnych-migrantow-w-Niemczech-gwaltown.jpg" vspace="2" />Ponad 100 osób dziennie zatrzymuje niemiecka policja tuż przy granicy w Polską. Większość z nich to migranci, którzy przedostali się z Białorusi lub wybrali szlak bałkański. Czasem funkcjonariusze zatrzymują także przemytników. Niemieckie władze nie mają wątpliwości, że migrantów będzie przybywać, a kanclerz Niemiec mówi o konkretnych działaniach, które trzeba podjąć.

## Duda o tym, co po wyborach: Chciałbym, żeby to był taki rząd, z którym będziemy jednak mieli wspólną wizję
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225463,duda-o-tym-co-po-wyborach-chcialbym-zeby-to-byl-taki-rzad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225463,duda-o-tym-co-po-wyborach-chcialbym-zeby-to-byl-taki-rzad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T06:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/da/d0/1c/z30214362M,Andrzej-Duda.jpg" vspace="2" />- Prezydent nie jest samotną wyspą w Polsce, tylko musi współdziałać z władzą wykonawczą. Konstytucja też go do tego zobowiązuje, więc trzeba będzie współdziałać z rządem. Nie ukrywam, że chciałbym, żeby to był taki rząd, z którym będziemy jednak mieli wspólną wizję - mówił w wywiadzie dla "Super Expressu'' Andrzej Duda. Prezydent odniósł się również do słów Wołodymyra Zełenskiego, krytykujących Polskę, a także swoich planów po zakończeniu prezydentury.

## Szymon Hołownia chce "zmieniać Polskę na pokolenia". Dlaczego "czuje się jak mąż Merkel"?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30177763,kim-jest-szymon-holownia-lider-polski-2050-chce-zmieniac-polske.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30177763,kim-jest-szymon-holownia-lider-polski-2050-chce-zmieniac-polske.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T06:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/69/db/18/z26064745M.jpg" vspace="2" />Szymon Hołownia zyskał popularność jako prezenter telewizyjny i katolicki publicysta, zanim rozpoczął swoją karierę polityczną. W 2020 roku przewodniczący Polski 2050 zajął trzecie miejsce w wyborach prezydenckich. Teraz Hołownia tworzy koalicję z Polskim Stronnictwem Ludowym i ubiega się o mandat poselski z podlaskiej listy Trzeciej Drogi, aby "budować Polskę demokratyczną, zieloną, różnorodną, solidarną i gospodarną".

## Dr Paweł Kubicki ocenia obietnice wyborcze: Konfederacja ma najsłabiej napisany program
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225233,poranna-rozmowa-gazeta-pl-gosciem-socjolog-dr-hab-pawel.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30225233,poranna-rozmowa-gazeta-pl-gosciem-socjolog-dr-hab-pawel.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T06:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5c/d3/1c/z30225244M,Poranna-rozmowa-Gazeta-pl.jpg" vspace="2" />- W nadchodzących wyborach kluczowe dla seniorów są kwestie dostępu do służby zdrowia, a także ich sytuacja ekonomiczna - wysokość emerytury, świadczeń - mówił w "Porannej rozmowie Gazeta.pl" socjolog dr hab. Paweł Kubicki z Katedry Polityki Społecznej Szkoły Głównej Handlowej. Następnie ekspert ocenił programy wyborcze. Najsurowsze słowa padły pod adresem Konfederacji.

## "Zielona granica" a kampania wyborcza. Jak film Agnieszki Holland wpłynie na wybory? [SONDAŻ]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30225421,zielona-granica-a-kampania-wyborcza-jak-film-agnieszki-holland.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30225421,zielona-granica-a-kampania-wyborcza-jak-film-agnieszki-holland.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T05:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/d3/1c/z30225442M,-Zielona-granica--a-kampania-wyborcza--Jak-film-Ag.jpg" vspace="2" />Prawo i Sprawiedliwość z filmu Agnieszki Holland "Zielona granica" próbuje zrobić temat przewodni trwającej kampanii wyborczej. Zwracają uwagę na to liderzy opozycji, którzy przestrzegają, że to odwracanie uwagi od afery wizowej i grożących w związku z nią konsekwencji dla Polski i wszystkich jej obywateli. Czy film fabularny o kryzysie uchodźczym rzeczywiście wpłynie na wybory w Polsce? Niemal połowa uczestników sondażu IBRiS dla RMF FM i "Rzeczpospolitej" uważa, że nie.

## Horoskop dzienny - poniedziałek 25 września [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30224499,horoskop-dzienny-poniedzialek-25-wrzesnia-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30224499,horoskop-dzienny-poniedzialek-25-wrzesnia-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-25T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c9/ba/1c/z30124489M,Horoskop-dzienny---poniedzialek.jpg" vspace="2" />Horoskop dzienny - poniedziałek 25 września dla wszystkich znaków zodiaku. Co cię czeka? Nie zwlekaj sprawdź.

