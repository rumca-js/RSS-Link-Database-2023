# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## NewsFlash 3.0: The Big Upgrade Gets a New Look and Features
 - [https://news.itsfoss.com/newsflash-3-0-release/](https://news.itsfoss.com/newsflash-3-0-release/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-09-25T10:41:23+00:00

The modern newsreader app for Linux gets a super upgrade.

