# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## She Doesn't Believe in Glasses
 - [https://www.youtube.com/watch?v=-TbthLpfTBc](https://www.youtube.com/watch?v=-TbthLpfTBc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-09-25T18:00:00+00:00

This is the greatest glasses rant of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/?ref=moist

