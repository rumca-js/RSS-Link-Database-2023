# Source:Austin Evans, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg, language:en-US

## I bought the "CHEAPEST" iPhone 15
 - [https://www.youtube.com/watch?v=ScAO8meSKm8](https://www.youtube.com/watch?v=ScAO8meSKm8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg
 - date published: 2023-09-25T15:02:52+00:00

Is the 128GB pink iPhone 15 base model ACTUALLY worth it?

Subscribe for more! https://www.youtube.com/austinevans
TikTok: https://www.tiktok.com/@austintechtips
Instagram: https://instagram.com/austinnotduncan
Twitter: https://twitter.com/austinnotduncan
Threads: https://www.threads.net/@austinnotduncan

Chapter Titles:
0:00 The "Cheap" iPhone 15
0:37 Design & USB-C
1:50 RIP iPhone Mini
3:15 Camera & Video
6:00 Display
7:39 iPhone 15 vs iPhone 15 Pro
8:34 Is the iPhone 15 Worth It?

