# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## Why The Lego Movie 2 Wasn't As Awesome
 - [https://www.youtube.com/watch?v=WuRx1_KQ7cQ](https://www.youtube.com/watch?v=WuRx1_KQ7cQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-09-25T17:00:25+00:00

When the first LEGO Movie was announced, it seemed like an obvious marketing campaign for the LEGO brand to sell more toys.  What we got however, was a truly unique story and next level animation from a team that revolutionized the way real world toys could be animated.  But for it's sequel, The LEGO Movie 2 The Second Part, it seemed audiences were not as amazed at the little innovation that transpired between films.  So what made The LEGO Movie 2 such a disappointment? 

#lego #legomovie #legobatman #nerdstalgic 

SOURCES
https://www.forbes.com/sites/scottmendelson/2019/02/11/why-the-lego-movie-2-was-such-a-huge-box-office-disappointment/?sh=66bdfc055d69
https://www.brickfanatics.com/lego-batman-plot-cancelled-sequel
https://animallogic.com/portfolio/projects/the-lego-movie-2/
https://www.hollywoodreporter.com/movies/movie-news/box-office-why-lego-movie-2-collapsed-1185084/
https://www.forbes.com/sites/scottmendelson/2019/03/11/lego-movie-fantastic-beasts-dc-films-shazam-godzilla-c

