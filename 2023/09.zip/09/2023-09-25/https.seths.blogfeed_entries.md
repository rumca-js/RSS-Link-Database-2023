# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## More vs. better
 - [https://seths.blog/2023/09/more-vs-better/](https://seths.blog/2023/09/more-vs-better/)
 - RSS feed: https://seths.blog/feed
 - date published: 2023-09-25T08:39:00+00:00

If every building in the shopping district in a big city was owned by one landlord, rents would go up. So would the prices of everything sold. The landlord would keep a significant percentage of each store&#8217;s profits and innovation would suffer as well. Google&#8217;s monopoly is real. They pay Apple more than a million [&#8230;]

