# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## CEO of Jeff Bezos’s Blue Origin rocket company resigns
 - [https://www.washingtonpost.com/technology/2023/09/25/blue-origin-space-ceo-resigns/](https://www.washingtonpost.com/technology/2023/09/25/blue-origin-space-ceo-resigns/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-09-25T20:57:45+00:00

Bob Smith, the chief executive of Jeff Bezos’ Blue Origin, announced to staff in an email that he was resigning Monday.

## ChatGPT can talk now, threatening Alexa and Siri
 - [https://www.washingtonpost.com/technology/2023/09/25/chatgpt-voice-talk-assistant/](https://www.washingtonpost.com/technology/2023/09/25/chatgpt-voice-talk-assistant/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-09-25T20:36:22+00:00

OpenAI’s ChatGPT is now able to speak back to users, putting it on a collision course with Google, Apple and Amazon in the battle to create smarter voice assistants.

## The new phone call etiquette: Text first and never leave a voice mail
 - [https://www.washingtonpost.com/technology/2023/09/25/cell-phone-etiquette-call-voicemail/](https://www.washingtonpost.com/technology/2023/09/25/cell-phone-etiquette-call-voicemail/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-09-25T10:00:00+00:00

The rules for phone calls have changed. Here are the basics on when and how to make a phone call, and why you should think twice before leaving that voice mail.

