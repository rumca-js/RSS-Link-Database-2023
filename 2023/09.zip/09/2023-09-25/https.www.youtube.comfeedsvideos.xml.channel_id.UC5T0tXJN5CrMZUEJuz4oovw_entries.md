# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## Woke Hollywood's Biggest LOSER | Disney Admits FAILURE
 - [https://www.youtube.com/watch?v=M_sYAW9oAO8](https://www.youtube.com/watch?v=M_sYAW9oAO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2023-09-25T18:00:36+00:00

Disney's Bob Iger wants to 'quiet the noise' in a culture war they helped create.
#hollywood #disney #marvel

Subscribe to The Nerdrotic Network:@nerdrotic @NerdroticLive @NerdroticDaily 

Edited by @QTRBlackGarrett 
Special thanks to @PierryChan 

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsored by MetaPCs!
Click here to get a discount on a PC: http://Metapcs.com/Nerdrotic/ref

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/products/...

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/...

