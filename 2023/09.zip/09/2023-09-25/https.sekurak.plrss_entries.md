# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Jak w praktyce przełamać dwuczynnikowe uwierzytelnienie? Zobaczcie tę prawdziwą historię włamania, która obfituje w… pomysłowość atakujących.
 - [https://sekurak.pl/jak-w-praktyce-przelamac-dwuczynnikowe-uwierzytelnienie-zobaczcie-te-prawdziwa-historie-wlamania-ktora-obfituje-w-pomyslowosc-atakujacych/](https://sekurak.pl/jak-w-praktyce-przelamac-dwuczynnikowe-uwierzytelnienie-zobaczcie-te-prawdziwa-historie-wlamania-ktora-obfituje-w-pomyslowosc-atakujacych/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-09-25T17:28:11+00:00

<p>Żeby nie przedłużać, przejdźmy od razu do rzeczy. Ciekawą historię włamania do swojej infrastruktury IT opisuje firma Retool. Zaczęło się od kampanii celowanych SMSów, w których atakujący podszywali się pod pracowników IT &#8211; &#8222;ten tego, coś jest nie tak z Twoim kontem, co może wpłynąć na dostępność Twojego ubezpieczenia zdrowotnego&#8221;:...</p>
<p>Artykuł <a href="https://sekurak.pl/jak-w-praktyce-przelamac-dwuczynnikowe-uwierzytelnienie-zobaczcie-te-prawdziwa-historie-wlamania-ktora-obfituje-w-pomyslowosc-atakujacych/" rel="nofollow">Jak w praktyce przełamać dwuczynnikowe uwierzytelnienie? Zobaczcie tę prawdziwą historię włamania, która obfituje w&#8230; pomysłowość atakujących.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Zapraszamy na unikalne wydarzenie. My hackujemy sieć na żywo, druga ekipa ją chroni. Wstęp bezpłatny.
 - [https://sekurak.pl/zapraszamy-na-unikalne-wydarzenie-my-hackujemy-siec-na-zywo-druga-ekipa-ja-chroni-wstep-bezplatny/](https://sekurak.pl/zapraszamy-na-unikalne-wydarzenie-my-hackujemy-siec-na-zywo-druga-ekipa-ja-chroni-wstep-bezplatny/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-09-25T07:25:47+00:00

<p>TLDR: zapisy tutaj, wydarzenie, on-line, a dostępne będzie również nagranie (organizatorzy proszą o podatnie emaili firmowych) W trakcie około 1.5h sesji, będziemy starali się upiec dwie pieczenie przy jednym ogniu: W planach mamy zaprezentowanie: Z naszej strony po stronie hackerskiej zobaczycie Tomka Turbę oraz Marka Rzepeckiego. Wydarzenie organizowane jest we...</p>
<p>Artykuł <a href="https://sekurak.pl/zapraszamy-na-unikalne-wydarzenie-my-hackujemy-siec-na-zywo-druga-ekipa-ja-chroni-wstep-bezplatny/" rel="nofollow">Zapraszamy na unikalne wydarzenie. My hackujemy sieć na żywo, druga ekipa ją chroni. Wstęp bezpłatny.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

