# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## Deadly avian flu reaches Galápagos Islands
 - [https://www.science.org/content/article/deadly-avian-flu-reaches-galapagos-islands](https://www.science.org/content/article/deadly-avian-flu-reaches-galapagos-islands)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2023-09-25T21:02:39.851653+00:00

Concerns rise for boobies, finches, and other endemic species

## Anthony Fauci on becoming the ‘devil’ and a warning for his successor
 - [https://www.science.org/content/article/anthony-fauci-becoming-devil-and-warning-his-successor](https://www.science.org/content/article/anthony-fauci-becoming-devil-and-warning-his-successor)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2023-09-25T17:44:07.604293+00:00

After a frenetic 38 years, former U.S. infectious disease chief discusses his quieter new life, working for Trump, and what’s next for HIV and coronavirus prevention

## Fleeting form of nitrogen stretches nuclear theory to its limits
 - [https://www.science.org/content/article/fleeting-form-nitrogen-stretches-nuclear-theory-its-limits](https://www.science.org/content/article/fleeting-form-nitrogen-stretches-nuclear-theory-its-limits)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2023-09-25T16:42:59.490647+00:00

Unstable nitrogen-9 is the first nucleus known to decay by spitting out five protons

## Earth’s future supercontinent may be too hot for most mammals
 - [https://www.science.org/content/article/earth-s-future-supercontinent-may-be-too-hot-most-mammals](https://www.science.org/content/article/earth-s-future-supercontinent-may-be-too-hot-most-mammals)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2023-09-25T15:41:57.145908+00:00

More than three-quarters of the planet’s land might be uninhabitable for mammals when continents coalesce in 250 million years

