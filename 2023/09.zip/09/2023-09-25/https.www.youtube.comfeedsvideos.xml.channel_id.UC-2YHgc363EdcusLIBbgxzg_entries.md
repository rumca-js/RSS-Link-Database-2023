# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The MANY Times The US Tried To Go Metric
 - [https://www.youtube.com/watch?v=LqnViQPd8mo](https://www.youtube.com/watch?v=LqnViQPd8mo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2023-09-25T13:59:08+00:00

Compare news coverage. Spot media bias. Avoid algorithms. Try Ground News today and get 30% off your subscription by going to https://ground.news/joescott

Over here in the US, we catch a lot of grief for having never switched to the metric system, but the fact of the matter is, we tried several times. So today let’s talk about the history of metric in the US, all the times that we tried to make the switch, and why each one failed.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcas

