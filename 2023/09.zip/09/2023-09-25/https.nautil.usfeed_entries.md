# Source:Nautilus, URL:https://nautil.us/feed/, language:en-US

## A New Way to Make Cells from Scratch
 - [https://nautil.us/a-new-way-to-make-cells-from-scratch-396785/](https://nautil.us/a-new-way-to-make-cells-from-scratch-396785/)
 - RSS feed: https://nautil.us/feed/
 - date published: 2023-09-25T20:58:10+00:00

<p>How scientists are engineering synthetic cells to be more life-like. </p>
<p>The post <a href="https://nautil.us/a-new-way-to-make-cells-from-scratch-396785/" rel="nofollow">A New Way to Make Cells from Scratch</a> appeared first on <a href="https://nautil.us" rel="nofollow">Nautilus</a>.</p>

