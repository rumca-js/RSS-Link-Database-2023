# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Przedsiębiorco, zajmuj się swoimi finansami przez Internet!
 - [https://www.wirtualnemedia.pl/artykul/przedsiebiorco-zajmuj-sie-swoimi-finansami-przez-internet](https://www.wirtualnemedia.pl/artykul/przedsiebiorco-zajmuj-sie-swoimi-finansami-przez-internet)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-09-25T11:21:30.907381+00:00

Z danych Związku Banków Polskich wynika, że w 2022 roku około 70% przedsiębiorców z sektora małych i średnich firm korzystało aktywnie z bankowości internetowej.  Jak można zarządzać firmowymi finansami z domu? Poznaj najnowsze możliwości.

## Coraz tańsza produkcja mięsa komórkowego
 - [https://www.wirtualnemedia.pl/artykul/coraz-tansza-produkcja-miesa-komorkowego](https://www.wirtualnemedia.pl/artykul/coraz-tansza-produkcja-miesa-komorkowego)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-09-25T06:16:29.653577+00:00

Pierwszy "sztuczny" burger wytworzony 10 lat temu, kosztował 250 tys. dolarów, obecnie szaszłyk z kurczaka można kupić już za 14 dolarów. Na całym świecie coraz więcej firm angażuje się w produkcję mięsa komórkowego. W tym wyścigu bierze udział też polska firma LabFarm.

## Altavia Kamikaze za 22 mln zł kupuje agencji K2 Create i K2 Precise
 - [https://www.wirtualnemedia.pl/artykul/altavia-kamikaze-nowym-wlascicielem-agencji-k2-create-i-k2-precise](https://www.wirtualnemedia.pl/artykul/altavia-kamikaze-nowym-wlascicielem-agencji-k2-create-i-k2-precise)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-09-25T04:07:07.948460+00:00

Altavia Kamikaze przejęła od Fabrity Holding SA 100 proc. udziałów w agencjach K2 Create i K2 Precise. Na czele połączonych firm staną Joanna Dering i Michał Ryszkiewicz.

