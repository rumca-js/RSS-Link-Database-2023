# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Nie żyje aktor David McCallum, gwiazdor serialu "Agenci NCIS"
 - [https://www.rp.pl/film/art39165841-nie-zyje-aktor-david-mccallum-gwiazdor-serialu-agenci-ncis](https://www.rp.pl/film/art39165841-nie-zyje-aktor-david-mccallum-gwiazdor-serialu-agenci-ncis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T23:51:11+00:00

Zmarł David McCallum, urodzony w Szkocji aktor telewizyjny i filmowy, który zyskał popularność dzięki roli w serialu "The Man from U.N.C.L.E." czy filmie "Wielka ucieczka". W ostatnich latach wystąpił w ponad 400 odcinkach serialu "Agenci NCIS".

## Unimot chce kupić od Shella udziały w PCK Schwedt
 - [https://energia.rp.pl/energetyka-zawodowa/art39165631-unimot-chce-kupic-od-shella-udzialy-w-pck-schwedt](https://energia.rp.pl/energetyka-zawodowa/art39165631-unimot-chce-kupic-od-shella-udzialy-w-pck-schwedt)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T20:57:00+00:00

Polski Unimot jest jednym z potencjalnych nabywców 37,5 proc. udziałów Shella w niemieckiej rafinerii PCK Schwedt, kontrolowanej jeszcze do niedawna przez rosyjski Rosnieft. - poinformował Reuters

## Sondaż: Kto najlepszym kandydatem na premiera? Wygrywa Rafał Trzaskowski, Kaczyński ostatni
 - [https://www.rp.pl/wybory/art39165541-sondaz-kto-najlepszym-kandydatem-na-premiera-wygrywa-rafal-trzaskowski-kaczynski-ostatni](https://www.rp.pl/wybory/art39165541-sondaz-kto-najlepszym-kandydatem-na-premiera-wygrywa-rafal-trzaskowski-kaczynski-ostatni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T20:32:49+00:00

"Który z poniższych polityków byłby Pani/Pana zdaniem najlepszym kandydatem na premiera?" - takie pytanie zadaliśmy uczestnikom sondażu SW Research dla rp.pl.

## Cel: stabilne prawo dla zdrowia
 - [https://www.rp.pl/rynek-zdrowia/art39165401-cel-stabilne-prawo-dla-zdrowia](https://www.rp.pl/rynek-zdrowia/art39165401-cel-stabilne-prawo-dla-zdrowia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T19:00:00+00:00

Legislacja w ochronie zdrowia w Polsce w dalszym ciągu wymaga działań na rzecz jej usprawnienia – wynika z najnowszego raportu „Zdrowa legislacja”.

## Jak dochodzić alimentów i od czego zależy ich wysokość
 - [https://www.rp.pl/prawo-rodzinne/art39161311-jak-dochodzic-alimentow-i-od-czego-zalezy-ich-wysokosc](https://www.rp.pl/prawo-rodzinne/art39161311-jak-dochodzic-alimentow-i-od-czego-zalezy-ich-wysokosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T18:43:21+00:00

Rodzice zobowiązani są do zaspokajania potrzeb dziecka, które nie jest jeszcze w stanie utrzymać się samodzielnie, chyba że dochody z majątku dziecka wystarczają na pokrycie kosztów jego utrzymania i wychowania. Alimentów można dochodzić albo w takcie postępowania rozwodowego albo w drodze oddzielnego powództwa wytoczonego przed Sądem Rejonowym.

## Mateusz Morawiecki zapowiada kontrole na granicy ze Słowacją
 - [https://www.rp.pl/polityka/art39164301-mateusz-morawiecki-zapowiada-kontrole-na-granicy-ze-slowacja](https://www.rp.pl/polityka/art39164301-mateusz-morawiecki-zapowiada-kontrole-na-granicy-ze-slowacja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T18:17:21+00:00

Premier Mateusz Morawiecki ogłosił, iż polecił szefowi MSWiA Mariuszowi Kamińskiemu, aby na granicy Polski ze Słowacją wprowadzać kontrole "tych busików, busów, samochodów, autobusów, które można podejrzewać o to, że tamtędy migrują nielegalni imigranci". Morawiecki zaapelował też do kanclerza Niemiec Olafa Scholza, aby ten nie wtrącał się w polskie sprawy.

## Jedźcie i jedzcie! Polska na wysokim miejscu w ważnym rankingu dla miłośników dobrej kuchni
 - [https://kobieta.rp.pl/styl-zycia/art39161901-najtansze-destynacje-europejskie-dla-milosnikow-kulinariow-polska-wysoko-w-rankingu](https://kobieta.rp.pl/styl-zycia/art39161901-najtansze-destynacje-europejskie-dla-milosnikow-kulinariow-polska-wysoko-w-rankingu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T17:40:14+00:00

Gdzie najlepiej wybrać się na wyjazd w Europie, aby dobrze i smacznie zjeść, ale nie wydać przy tym majątku? Na czele zestawienia znalazł się Budapeszt, ale tuż za nim, bo na miejscu drugim, jest także Warszawa.

## "Zielona granica" Agnieszki Holland - w weekend film ustanowił rekord
 - [https://www.rp.pl/film/art39163531-zielona-granica-agnieszki-holland-w-weekend-film-ustanowil-rekord](https://www.rp.pl/film/art39163531-zielona-granica-agnieszki-holland-w-weekend-film-ustanowil-rekord)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T16:45:00+00:00

"Zielona granica", film w reżyserii Agnieszki Holland, w pierwszy weekend od premiery odnotował najlepszy pod względem liczby widzów wynik polskiego filmu w tym roku - wynika z danych dystrybutora.

## Nowe ubezpieczenia mogą pomóc przy atakach hakerów
 - [https://firma.rp.pl/finanse/art39162531-nowe-ubezpieczenia-moga-pomoc-przy-atakach-hakerow](https://firma.rp.pl/finanse/art39162531-nowe-ubezpieczenia-moga-pomoc-przy-atakach-hakerow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T16:36:40+00:00

Na rynku funkcjonuje coraz więcej firm narażonych na ataki hakerskie, a co za tym idzie także tych, których bezpieczeństwo zostało w ten sposób naruszone. Jak przedsiębiorcy mogą zapobiegać cyberatakom?

## To nie ma być walka płci. Dyrektor Biura Stowarzyszenia Filmowców Polskich o Festiwalu w Gdyni
 - [https://kobieta.rp.pl/kultura/art39162361-to-nie-ma-byc-walka-plci-dyrektor-biura-stowarzyszenia-filmowcow-polskich-o-festiwalu-w-gdyni](https://kobieta.rp.pl/kultura/art39162361-to-nie-ma-byc-walka-plci-dyrektor-biura-stowarzyszenia-filmowcow-polskich-o-festiwalu-w-gdyni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T16:32:43+00:00

48. Festiwal Filmowy w Gdyni dobiegł końca. Wszystkich laureatów ubiegających się o statuetki ogłoszono wieczorem 23 września. O emocjach towarzyszących wydarzeniu oraz "kobiece wątki" w wydarzeniu zapytaliśmy Adriannę Pierścionek-Podogrodzką, Dyrektor Biura Stowarzyszenia Filmowców Polskich.

## Orlen zrywa umowę z Deloitte Audyt. Potwierdzają się informacje "Rzeczpospolitej"
 - [https://www.rp.pl/finanse/art39163671-orlen-zrywa-umowe-z-deloitte-audyt-potwierdzaja-sie-informacje-rzeczpospolitej](https://www.rp.pl/finanse/art39163671-orlen-zrywa-umowe-z-deloitte-audyt-potwierdzaja-sie-informacje-rzeczpospolitej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T16:16:00+00:00

Informację o tym, że Deloitte Audyt - spółka pracująca kiedyś dla GetBack - dostał zakaz działalności w Polsce podaliśmy jako pierwsi w ubiegłym tygodniu. Wskazując jednocześnie, że Orlen - jeden z największych klientów tej firmy - szuka nowego audytora.

## Jędrzej Bielecki: Pakt Donalda Tuska z Konfederacją nie musi się źle skończyć dla Polski
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39161451-jedrzej-bielecki-pakt-donalda-tuska-z-konfederacja-nie-musi-sie-zle-skonczyc-dla-polski](https://www.rp.pl/opinie-polityczno-spoleczne/art39161451-jedrzej-bielecki-pakt-donalda-tuska-z-konfederacja-nie-musi-sie-zle-skonczyc-dla-polski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T16:08:00+00:00

Donald Tusk jako lider opozycji po wyborach zapewne stanie przed dylematem, czy wejść w alians ze skrajnie prawicową Konfederacją, aby odsunąć PiS, czy poświęcić władzę dla wierności swoim przekonaniom. Doświadczenia Europy sugerowałyby wybór tego pierwszego.

## Jak głosować w referendum. Objaśniamy formalności
 - [https://www.rp.pl/prawo-dla-ciebie/art39152181-jak-glosowac-w-referendum-objasniamy-formalnosci](https://www.rp.pl/prawo-dla-ciebie/art39152181-jak-glosowac-w-referendum-objasniamy-formalnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T16:07:00+00:00

Jednocześnie z wyborami do Sejmu i Senatu odbędzie się referendum ogólnokrajowe. Tłumaczymy jak oddać głos w referendum i jak zagłosować w wyborach parlamentarnych, nie biorąc udziału w referendum. Wyjaśniamy czy można zniszczyć kartę referendalną.

## Europejski trybunał odrzucił skargę polskich maturzystów
 - [https://www.rp.pl/w-sadzie-i-w-urzedzie/art39162891-europejski-trybunal-odrzucil-skarge-polskich-maturzystow](https://www.rp.pl/w-sadzie-i-w-urzedzie/art39162891-europejski-trybunal-odrzucil-skarge-polskich-maturzystow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T16:02:33+00:00

Trybunał w Strasburgu uznał, że nie ma właściwości, by rozpatrzyć skargę maturzystów z Ostrowca Świętokrzyskiego, którym unieważniono wyniki egzaminów dojrzałości w 2011 r.

## „Chłopi” polskim kandydatem do Oscara
 - [https://www.rp.pl/film/art39162851-chlopi-polskim-kandydatem-do-oscara](https://www.rp.pl/film/art39162851-chlopi-polskim-kandydatem-do-oscara)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T16:00:00+00:00

W bardzo niespokojnym czasie, jaki przetacza się nad światem, Polskę będzie reprezentować animowana ekranizacja „Chłopów” Reymonta

## Założenia polityki pieniężnej NBP bez zmian. I bez znaczenia?
 - [https://www.rp.pl/gospodarka/art39163111-zalozenia-polityki-pienieznej-nbp-bez-zmian-i-bez-znaczenia](https://www.rp.pl/gospodarka/art39163111-zalozenia-polityki-pienieznej-nbp-bez-zmian-i-bez-znaczenia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:57:00+00:00

Narodowy Bank Polski opublikował założenia polityki pieniężnej na 2024 r. Wielu ekonomistów uważa jednak, że ten dokument w ostatnim czasie stracił znaczenie.

## Protest wyborczy – kto, gdzie, jak? Zgłaszanie protestu wyborczego
 - [https://www.rp.pl/prawo-dla-ciebie/art39162521-protest-wyborczy-kto-gdzie-jak-zglaszanie-protestu-wyborczego](https://www.rp.pl/prawo-dla-ciebie/art39162521-protest-wyborczy-kto-gdzie-jak-zglaszanie-protestu-wyborczego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:48:00+00:00

Protesty wyborcze – jak je zgłosić? Gdzie i w jakim terminie można złożyć swój protest tak, by było to skuteczne? Odpowiadamy na pytania nurtujące wyborców i wyjaśniamy.

## Od jutra pojedziemy nową drogą ekspresową prowadząca nad morze
 - [https://moto.rp.pl/tu-i-teraz/art39162791-od-jutra-pojedziemy-nowa-droga-ekspresowa-prowadzaca-nad-morze](https://moto.rp.pl/tu-i-teraz/art39162791-od-jutra-pojedziemy-nowa-droga-ekspresowa-prowadzaca-nad-morze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:43:42+00:00

Już po raz kolejny w tym roku ma się wydłużyć sieć szybkich dróg. Od wtorku nową ekspresówką pojedziemy tym razem nad Bałtyk. Do ruchu włączone zostaną bowiem trzy odcinki trasy S11 pomiędzy Koszalinem a Bobolicami, których budowa rozpoczęła się w 2021 r.

## Prywatna służba zdrowia tonie w długach
 - [https://www.rp.pl/nowoczesna-klinika/art39162821-prywatna-sluzba-zdrowia-tonie-w-dlugach](https://www.rp.pl/nowoczesna-klinika/art39162821-prywatna-sluzba-zdrowia-tonie-w-dlugach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:35:42+00:00

Choć z prywatnej opieki medycznej korzysta coraz więcej Polaków płacąc za te usługi krocie, prywatne gabinety wcale nie prosperują tak dobrze, jakby się to mogło wydawać.

## Prywatna służba zdrowia tonie w długach. Kto jest najbardziej zadłużony?
 - [https://www.rp.pl/nowoczesna-klinika/art39162821-prywatna-sluzba-zdrowia-tonie-w-dlugach-kto-jest-najbardziej-zadluzony](https://www.rp.pl/nowoczesna-klinika/art39162821-prywatna-sluzba-zdrowia-tonie-w-dlugach-kto-jest-najbardziej-zadluzony)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:35:42+00:00

Choć z prywatnej opieki medycznej korzysta coraz więcej Polaków płacąc za te usługi krocie, prywatne gabinety wcale nie prosperują tak dobrze, jakby się to mogło wydawać.

## Dziennik Ustaw z 25 września 2023 (1972-1999))
 - [https://www.rp.pl/akty-prawne/art39162811-dziennik-ustaw-z-25-wrzesnia-2023-1972-1999](https://www.rp.pl/akty-prawne/art39162811-dziennik-ustaw-z-25-wrzesnia-2023-1972-1999)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:31:49+00:00



## Cukier krzepi. Krajowa Grupa Spożywcza sponsorem Polskiego Komitetu Olimpijskiego
 - [https://www.rp.pl/sport/art39162641-cukier-krzepi-krajowa-grupa-spozywcza-sponsorem-polskiego-komitetu-olimpijskiego](https://www.rp.pl/sport/art39162641-cukier-krzepi-krajowa-grupa-spozywcza-sponsorem-polskiego-komitetu-olimpijskiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:28:22+00:00

Krajowa Grupa Spożywcza S.A. z marką Polski Cukier została Sponsorem Polskiego Komitetu Olimpijskiego (PKOl) i Olimpijskiej Reprezentacji Polski. Beneficjentami porozumienia będzie także pięć polskich związków sportowych.

## Monitor Polski z 25 września 2023 (1032-1035)
 - [https://www.rp.pl/akty-prawne/art39162801-monitor-polski-z-25-wrzesnia-2023-1032-1035](https://www.rp.pl/akty-prawne/art39162801-monitor-polski-z-25-wrzesnia-2023-1032-1035)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:24:20+00:00



## Rząd broni się przed skutkami obniżki stóp. Resort finansów podnosi marże obligacji
 - [https://www.rp.pl/finanse/art39162771-rzad-broni-sie-przed-skutkami-obnizki-stop-resort-finansow-podnosi-marze-obligacji](https://www.rp.pl/finanse/art39162771-rzad-broni-sie-przed-skutkami-obnizki-stop-resort-finansow-podnosi-marze-obligacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:18:00+00:00

Ministerstwo Finansów poprawiło ofertę obligacji detalicznych, aby pozostały atrakcyjne dla inwestorów pomimo gwałtownej obniżki stóp procentowych.

## Kursy walut znów w górę. Siłę pokazał dolar, złoty w dół
 - [https://www.rp.pl/waluty/art39162731-kursy-walut-znow-w-gore-sile-pokazal-dolar-zloty-w-dol](https://www.rp.pl/waluty/art39162731-kursy-walut-znow-w-gore-sile-pokazal-dolar-zloty-w-dol)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:10:00+00:00

Z porannego umocnienia złotego późnym popołudniem niewiele zostało, o czym zdecydowały w dużej mierze czynniki globalne. Siłę znów pokazał dolar, co przekreśliło szansę na kontynuację zeszłotygodniowego odbicia notowań krajowej waluty.

## Aresztowanie Prymasa Polski. W środku nocy na Miodowej zapalono wszystkie światła
 - [https://www.rp.pl/kosciol/art39162721-aresztowanie-prymasa-polski-w-srodku-nocy-na-miodowej-zapalono-wszystkie-swiatla](https://www.rp.pl/kosciol/art39162721-aresztowanie-prymasa-polski-w-srodku-nocy-na-miodowej-zapalono-wszystkie-swiatla)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T15:07:28+00:00

Dokładnie 70 lat temu - 25 września 1953 komunistyczne władze Polski zdecydowały się na ruch nieznany w dziejach Kościoła. Aresztowały Prymasa Polski Kardynała Stefana Wyszyńskiego.

## Dostaniemy dwa miliardy dolarów pożyczki od USA na wzmocnienie polskiej armii
 - [https://radar.rp.pl/modernizacja-sil-zbrojnych/art39162581-dostaniemy-dwa-miliardy-dolarow-pozyczki-od-usa-na-wzmocnienie-polskiej-armii](https://radar.rp.pl/modernizacja-sil-zbrojnych/art39162581-dostaniemy-dwa-miliardy-dolarow-pozyczki-od-usa-na-wzmocnienie-polskiej-armii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T14:47:05+00:00

Departament Stanu USA poinformował o podpisaniu z Polską umowy w ramach Zagranicznego Programu Finansowania (FMF).

## Polską ze wsparciem w ramach FMF. 2 mld dol. na modernizację
 - [https://radar.rp.pl/modernizacja-sil-zbrojnych/art39162581-polska-ze-wsparciem-w-ramach-fmf-2-mld-dol-na-modernizacje](https://radar.rp.pl/modernizacja-sil-zbrojnych/art39162581-polska-ze-wsparciem-w-ramach-fmf-2-mld-dol-na-modernizacje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T14:47:05+00:00

Departament Stanu USA poinformował o podpisaniu z Polską umowy w ramach Zagranicznego Programu Finansowania (FMF).

## Wiadomości TVP pokazały fragmenty "Zielonej granicy". Czy to legalne?
 - [https://www.rp.pl/prawo-dla-ciebie/art39162551-wiadomosci-tvp-pokazaly-fragmenty-zielonej-granicy-czy-to-legalne](https://www.rp.pl/prawo-dla-ciebie/art39162551-wiadomosci-tvp-pokazaly-fragmenty-zielonej-granicy-czy-to-legalne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T14:43:00+00:00

„Wiadomości” TVP pokazały fragmenty filmu „Zielona granica” Agnieszki Holland bez zgody producenta i dystrybutora oraz przed oficjalną premierą. Prawo autorskie nie daje podstaw do takiego działania.

## Dlaczego PiS robi sojuszników Władimira Putina z tych, którzy idą na "Zieloną granicę"?
 - [https://www.rp.pl/wybory/art39162561-dlaczego-pis-robi-sojusznikow-wladimira-putina-z-tych-ktorzy-ida-na-zielona-granice](https://www.rp.pl/wybory/art39162561-dlaczego-pis-robi-sojusznikow-wladimira-putina-z-tych-ktorzy-ida-na-zielona-granice)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T14:42:22+00:00

Dlaczego z Agnieszki Holland i wszystkich osób, które chcą iść na jej film, "Zielona granica" robi się wrogów publicznych, sprzymierzeńców Putina, ojkofobów, siły antypolskie; dlaczego Lewica wyjechała aż do Wiednia na konwencję programową i dlaczego PO stawia wszystko na marsz 1 października - o tym m.in. rozmawiali w programie "Polityczne Michałki" Michał Szułdrzyński i Michał Kolanko.

## PiS tnie logo Platformy na pół. „Chcą zmobilizować wschodnią Polskę”
 - [https://www.rp.pl/wybory/art39162561-pis-tnie-logo-platformy-na-pol-chca-zmobilizowac-wschodnia-polske](https://www.rp.pl/wybory/art39162561-pis-tnie-logo-platformy-na-pol-chca-zmobilizowac-wschodnia-polske)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T14:42:22+00:00

- PiS działa według schematu, w którym w każdy poniedziałek musi pojawić się coś, co przyciągnie uwagę w kampanii internetowej – mówił o nowym spocie partii Jarosława Kaczyńskiego Michał Kolanko w nowym odcinku podcastu „Polityczne Michałki”. – Drugim elementem tego przesłania jest mobilizacja wyborców Polski Wschodniej – dodał.

## Longines DolceVita x YVY: zegarkowa klasyka podczas zawodów Warsaw Jumping 4*
 - [https://sukces.rp.pl/zegarki/art39162321-longines-dolcevita-x-yvy-zegarkowa-klasyka-podczas-zawodow-warsaw-jumping-4](https://sukces.rp.pl/zegarki/art39162321-longines-dolcevita-x-yvy-zegarkowa-klasyka-podczas-zawodow-warsaw-jumping-4)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T14:35:58+00:00

Jeździectwo na najwyższym poziomie – tak prezentowały się zawody Warsaw Jumping 4*, część drużynowego cyklu Longines EEF Series. To był weekend sportowych zmagań i emocji na najwyższym poziomie.

## Wielki skok umiejętności ChatGPT. Będzie teraz słyszał, widział i mówił
 - [https://cyfrowa.rp.pl/technologie/art39162541-wielki-skok-umiejetnosci-chatgpt-bedzie-teraz-slyszal-widzial-i-mowil](https://cyfrowa.rp.pl/technologie/art39162541-wielki-skok-umiejetnosci-chatgpt-bedzie-teraz-slyszal-widzial-i-mowil)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T14:31:00+00:00

Chatbot od OpenAI, który zapoczątkował rewolucję w zakresie konwersacyjnej sztucznej inteligencji, dokonuje kolejnego przełomu.

## Aleksiej Wieniediktow: Prezydent Polski jeszcze przyjedzie do Moskwy
 - [https://www.rp.pl/polityka/art39162061-aleksiej-wieniediktow-prezydent-polski-jeszcze-przyjedzie-do-moskwy](https://www.rp.pl/polityka/art39162061-aleksiej-wieniediktow-prezydent-polski-jeszcze-przyjedzie-do-moskwy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T14:29:50+00:00

Antypolskość w rosyjskich elitach utrwaliła się z czasów przegranej Bitwy Warszawskiej - mówi „Rzeczpospolitej” Aleksiej Wieniediktow, przebywający w Moskwie redaktor naczelny zlikwidowanego przez władze radia Echo Moskwy, uznawany w Rosji za „agenta zagranicznego”.

## Brazylia planuje podwoić posiadaną flotę Gripenów
 - [https://radar.rp.pl/przemysl-obronny/art39039901-brazylia-planuje-podwoic-posiadana-flote-gripenow](https://radar.rp.pl/przemysl-obronny/art39039901-brazylia-planuje-podwoic-posiadana-flote-gripenow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T14:11:00+00:00

Władze Brazylii przedstawiły plany zwiększenia wydatków obronnych. Zakładają m.in. podwojenie liczby posiadanych samolotów bojowych Gripen.

## Jerzy Surdykowski: Aferą wizową PiS przekroczył ostatnią granicę bezczelności
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39162041-jerzy-surdykowski-afera-wizowa-pis-przekroczyl-ostatnia-granice-bezczelnosci](https://www.rp.pl/opinie-polityczno-spoleczne/art39162041-jerzy-surdykowski-afera-wizowa-pis-przekroczyl-ostatnia-granice-bezczelnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T13:53:35+00:00

Wpuszczając bliżej nieokreśloną liczbę ludzi bez ich sprawdzenia, napluto w twarz pogranicznikom strzegącym płotu na wschodniej granicy, oszukano wyborców PiS, którzy uwierzyli w hasło Jarosława Kaczyńskiego o „bezpiecznej Polsce”, wystawiono do wiatru sojuszników z NATO.

## Udana, kryształowa edycja TRAKO
 - [https://logistyka.rp.pl/trako/art39162351-udana-krysztalowa-edycja-trako](https://logistyka.rp.pl/trako/art39162351-udana-krysztalowa-edycja-trako)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T13:49:23+00:00

Dyrektor projektu TRAKO w Międzynarodowych Targach Ggdańskich Dorota Daszkowska-Kosewska podsumowuje w rozmowie z Marcinem Piaseckim udane, 15 targi TRAKO i zaprasza za dwa lata na kolejną edycję.

## Dlaczego opozycja ma większe szanse wygrać wybory i komu pomoże marsz miliona?
 - [https://www.rp.pl/polityka/art39161681-dlaczego-opozycja-ma-wieksze-szanse-wygrac-wybory-i-komu-pomoze-marsz-miliona](https://www.rp.pl/polityka/art39161681-dlaczego-opozycja-ma-wieksze-szanse-wygrac-wybory-i-komu-pomoze-marsz-miliona)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T13:40:36+00:00

Na spotkanie z Jarosławem Kaczyńskim w Szczecinie nie zostali wpuszczeni między innymi przedstawiciele rolników.

## Trwa wyścig w wodowaniu coraz większych wycieczkowców. Gigantomania się opłaca
 - [https://turystyka.rp.pl/promy-i-statki/art39162281-trwa-wyscig-w-wodowaniu-coraz-wiekszych-wycieczkowcow-gigantomania-sie-oplaca](https://turystyka.rp.pl/promy-i-statki/art39162281-trwa-wyscig-w-wodowaniu-coraz-wiekszych-wycieczkowcow-gigantomania-sie-oplaca)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T13:29:17+00:00

W stoczniach powstają kolejne, coraz większe, statki wycieczkowe. Będą zabierać na pokłady już nie trzy czy pięć tysięcy, ale siedem tysięcy pasażerów. Dlaczego są tak ogromne? To się po prostu opłaca.

## Rynek kolejowy będzie rósł
 - [https://logistyka.rp.pl/trako/art39162271-rynek-kolejowy-bedzie-rosl](https://logistyka.rp.pl/trako/art39162271-rynek-kolejowy-bedzie-rosl)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T13:26:11+00:00

Wiceprezes Międzynarodowych Targów Gdańskich Paweł Orłowski mówi o przyszłości targów TRAKO oraz rozbudowie Amber Expo.

## Oscary 2024. Polskim kandydatem do Oscara będzie film "Chłopi"
 - [https://www.rp.pl/film/art39162231-oscary-2024-polskim-kandydatem-do-oscara-bedzie-film-chlopi](https://www.rp.pl/film/art39162231-oscary-2024-polskim-kandydatem-do-oscara-bedzie-film-chlopi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T13:20:16+00:00

Film "Chłopi" w reżyserii DK Welchman i Hugh Welchmana będzie polskim kandydatem do Oscara. O decyzji poinformowała komisja oscarowa.

## Lawina pozwów przeciwko fast foodom. Bo dania są inne niż na zdjęciach
 - [https://www.rp.pl/gastronomia/art39161751-lawina-pozwow-przeciwko-fast-foodom-bo-dania-sa-inne-niz-na-zdjeciach](https://www.rp.pl/gastronomia/art39161751-lawina-pozwow-przeciwko-fast-foodom-bo-dania-sa-inne-niz-na-zdjeciach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T13:14:00+00:00

W reklamach burgery zawsze wyglądają pięknie i soczyście, w rzeczywistości już niekoniecznie. Sieci fast food muszą przez to walczyć z licznymi pozwami.

## Posłanka KO zaatakowana. Nieznany sprawca szarpał ją i groził
 - [https://www.rp.pl/polityka/art39162131-poslanka-ko-zaatakowana-nieznany-sprawca-szarpal-ja-i-grozil](https://www.rp.pl/polityka/art39162131-poslanka-ko-zaatakowana-nieznany-sprawca-szarpal-ja-i-grozil)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T13:06:45+00:00

Marta Wcisło, posłanka Koalicji Obywatelskiej, została zaatakowana w Opolu Lubelskim. To drugi w ostatnich dniach przypadek ataku na polityka KO, po tym jak w piątek ofiarą ataku w Katowicach padł szef klubu PO, Borys Budka.

## Rosja umieściła Polaka, prezesa Międzynarodowego Trybunału Karnego na liście poszukiwanych
 - [https://www.rp.pl/konflikty-zbrojne/art39161811-rosja-umiescila-polaka-prezesa-miedzynarodowego-trybunalu-karnego-na-liscie-poszukiwanych](https://www.rp.pl/konflikty-zbrojne/art39161811-rosja-umiescila-polaka-prezesa-miedzynarodowego-trybunalu-karnego-na-liscie-poszukiwanych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:57:22+00:00

Rosyjskie MSW umieściły Piotra Hofmańskiego, polskiego prawnika, prezesa Międzynarodowego Trybunału Karnego, na liście osób poszukiwanych.

## Niewielka wyspa zbiera na ochronę przyrody. Oferuje "kawałki" oceanu za 640 zł
 - [https://klimat.rp.pl/klimat/art39161411-niewielka-wyspa-zbiera-na-ochrone-przyrody-oferuje-kawalki-oceanu-za-640-zl](https://klimat.rp.pl/klimat/art39161411-niewielka-wyspa-zbiera-na-ochrone-przyrody-oferuje-kawalki-oceanu-za-640-zl)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:55:25+00:00

Władze Niue, znajdującego się na Oceanie Spokojnym państwa wyspiarskiego, chcąc chronić lokalną przyrodę, zaproponowały zaskakujące rozwiązanie. Oferują „kupno” kawałka oceanu.

## W tych powiatach Polacy toną w długach
 - [https://pieniadze.rp.pl/budzet-rodzinny/art39162051-w-tych-powiatach-polacy-tona-w-dlugach](https://pieniadze.rp.pl/budzet-rodzinny/art39162051-w-tych-powiatach-polacy-tona-w-dlugach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:51:34+00:00

Średnie zadłużenie Polaków, według danych Krajowego Rejestru Długów, wynosi 20 tys. zł. Ale nie w każdym regionie kraju jest ono takie samo.

## Węgrzy sprowadzają cudzoziemców. Zarabiają pośrednicy związani z partią Orbana
 - [https://www.rp.pl/rynek-pracy/art39161691-wegrzy-sprowadzaja-cudzoziemcow-zarabiaja-posrednicy-zwiazani-z-partia-orbana](https://www.rp.pl/rynek-pracy/art39161691-wegrzy-sprowadzaja-cudzoziemcow-zarabiaja-posrednicy-zwiazani-z-partia-orbana)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:48:58+00:00

Węgrzy walczą o każdą inwestycję zagraniczną, chociaż nie są w stanie zapewnić siły roboczej — alarmuje portal atlatszo.hu. Ten problem rozwiązują agencje pracy związane z rządzącą partią Fidesz.

## Opuszczone więzienie zmieni się w luksusowy hotel. Cele pełne przepychu
 - [https://sukces.rp.pl/hotele/art39160631-opuszczone-wiezienie-zmieni-sie-w-luksusowy-hotel-cele-pelne-przepychu](https://sukces.rp.pl/hotele/art39160631-opuszczone-wiezienie-zmieni-sie-w-luksusowy-hotel-cele-pelne-przepychu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:48:12+00:00

Nnajstarsze więzienie w Japonii, zmieni się w luksusowy hotel. Trwa właśnie renowacja stuletniego obiektu, w którym jeszcze kilkanaście lat temu wyroki odsiadywali przestępcy.

## Są pieniądze na rozwój czytelnictwa. Samorządy mogą o nie wnioskować
 - [https://regiony.rp.pl/finanse-w-regionach/art39161991-sa-pieniadze-na-rozwoj-czytelnictwa-samorzady-moga-o-nie-wnioskowac](https://regiony.rp.pl/finanse-w-regionach/art39161991-sa-pieniadze-na-rozwoj-czytelnictwa-samorzady-moga-o-nie-wnioskowac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:46:35+00:00

Do końca października przedszkola i szkoły mogą wnioskować o pieniądze na rozwój czytelnictwa.

## Na świeżym powietrzu głowa lepiej pracuje
 - [https://regiony.rp.pl/sport/art39161961-na-swiezym-powietrzu-glowa-lepiej-pracuje](https://regiony.rp.pl/sport/art39161961-na-swiezym-powietrzu-glowa-lepiej-pracuje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:44:01+00:00

Marcin Lewandowski brązowy medalista MŚ na 1500 m, zachęca do wzięcia udziału w trekkingu pod Monte Cassino. Na imprezę Biegnij Warszawo przyleci delegacja z Włoch.

## Zachęcamy Polaków, żeby się ruszali
 - [https://regiony.rp.pl/sport/art39161951-zachecamy-polakow-zeby-sie-ruszali](https://regiony.rp.pl/sport/art39161951-zachecamy-polakow-zeby-sie-ruszali)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:43:00+00:00

Po pandemii nasi rodacy są w gorszej formie. Warto, żeby zaczęli się ruszać, a bieganie to najłatwiejsza forma aktywności fizycznej. O imprezie Biegnij Warszawo opowiada jej organizator Bogusław Mamiński, wicemistrz świata w biegu na 3000 metrów z przeszkodami z 1983 r.

## Włochy znów łagodzą podatek bankowy
 - [https://www.rp.pl/banki/art39161871-wlochy-znow-lagodza-podatek-bankowy](https://www.rp.pl/banki/art39161871-wlochy-znow-lagodza-podatek-bankowy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:40:22+00:00

Włoskie banki zyskają szansę na uniknięcie podatku od zysków nadzwyczajnych.

## Viktor Orbán: Nie chcemy, aby chleb wypiekano z ukraińskiego zboża niepewnej jakości, a nie z dobrego, węgierskiego
 - [https://www.rp.pl/dyplomacja/art39161741-viktor-orban-nie-chcemy-aby-chleb-wypiekano-z-ukrainskiego-zboza-niepewnej-jakosci-a-nie-z-dobrego-wegierskiego](https://www.rp.pl/dyplomacja/art39161741-viktor-orban-nie-chcemy-aby-chleb-wypiekano-z-ukrainskiego-zboza-niepewnej-jakosci-a-nie-z-dobrego-wegierskiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:33:10+00:00

Premier Węgier zapowiedział, że nie będzie popierał stanowiska Ukrainy „w żadnej kwestii w polityce międzynarodowej” do czasu przywrócenia praw przysługujących - jego zdaniem - Węgrom z Zakarpacia.

## Joanna Senyszyn przed sądem za wpisy o Żołnierzach Wyklętych
 - [https://www.rp.pl/dobra-osobiste/art39161701-joanna-senyszyn-przed-sadem-za-wpisy-o-zolnierzach-wykletych](https://www.rp.pl/dobra-osobiste/art39161701-joanna-senyszyn-przed-sadem-za-wpisy-o-zolnierzach-wykletych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:27:08+00:00

W Sądzie Okręgowym w Gdańsku rozpoczął się zdalny proces przeciwko posłance prof. Joannie Senyszyn za zamieszczone przez nią na Twitterze opinie na temat Żołnierzy Wyklętych. Pozew wniosły w 2019 r. dwa stowarzyszenia: Rodzin Żołnierzy Wyklętych oraz Członków Rodzin Żołnierzy Niezłomnych.

## Po zakupowe okazje do internetu. Zwyczaje zakupowe na trudne czasy
 - [https://www.rp.pl/handel/art39161661-po-zakupowe-okazje-do-internetu-zwyczaje-zakupowe-na-trudne-czasy](https://www.rp.pl/handel/art39161661-po-zakupowe-okazje-do-internetu-zwyczaje-zakupowe-na-trudne-czasy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:26:23+00:00

Co drugi Polak kupuje online częściej niż rok temu. To najpopularniejsza strategia na trudne czasy. Zmieniają się też inne zwyczaje zakupowe.

## Olchowy Park po raz szósty
 - [https://www.rp.pl/nieruchomosci/art39161721-olchowy-park-po-raz-szosty](https://www.rp.pl/nieruchomosci/art39161721-olchowy-park-po-raz-szosty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:17:39+00:00

Kolejny etap osiedla na warszawskiej Białołęce wprowadza do oferty Victoria Dom. Ta część inwestycji ma być gotowa w IV kw. 2024 roku.

## Technika Pomodoro. Częste przerwy rewolucjonizują produktywność w pracy. Jak to działa?
 - [https://kobieta.rp.pl/psychologia/art39160871-technika-pomodoro-czeste-przerwy-rewolucjonizuja-produktywnosc-w-pracy-jak-to-dziala](https://kobieta.rp.pl/psychologia/art39160871-technika-pomodoro-czeste-przerwy-rewolucjonizuja-produktywnosc-w-pracy-jak-to-dziala)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:12:53+00:00

Współczesne tempo pracy często wymaga maksymalnego skupienia, a jednocześnie bycia wielozdaniowym. Czy da się działać tak, żeby zoptymalizować czas wykonywanej pracy, a jednocześnie utrzymać jej wysoką jakość? Tak. Może w tym pomóc technika Pomodoro.

## Bruksela: 11 mld euro na chipy.  Europa ma stać się centrum innowacji
 - [https://www.rp.pl/biznes/art39161381-bruksela-11-mld-euro-na-chipy-europa-ma-stac-sie-centrum-innowacji](https://www.rp.pl/biznes/art39161381-bruksela-11-mld-euro-na-chipy-europa-ma-stac-sie-centrum-innowacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:12:48+00:00

Komisja Europejska wprowadziła w życie akt w sprawie chipów. System programów uruchomi 11 mld euro na podwojenie produkcji chipów w Europie i przejęcie 20 proc. udziału w światowym rynku do 2030 r.

## Do końca 2023 r. nie będzie kar za brak lekarza w karetce
 - [https://www.rp.pl/zdrowie/art39161081-do-konca-2023-r-nie-bedzie-kar-za-brak-lekarza-w-karetce](https://www.rp.pl/zdrowie/art39161081-do-konca-2023-r-nie-bedzie-kar-za-brak-lekarza-w-karetce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T12:03:48+00:00

Resort zdrowia chce przedłużyć wyłączenie sankcji za brak medyka w karetce. NFZ do końca 2023 r. nie będzie mógł karać za niezapewnienie lekarza w specjalistycznym Zespole Ratownictwa Medycznego.

## Nowojorska policja sięga po „robocopa”. Ma patrolować kluczowe miejsce w mieście
 - [https://cyfrowa.rp.pl/technologie/art39161551-nowojorska-policja-siega-po-robocopa-ma-patrolowac-kluczowe-miejsce-w-miescie](https://cyfrowa.rp.pl/technologie/art39161551-nowojorska-policja-siega-po-robocopa-ma-patrolowac-kluczowe-miejsce-w-miescie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:57:00+00:00

Jedno z najbardziej rozpoznawalnych miejsc na Manhattanie będzie pilnie strzeżone przez robota. Pierwszy robo-policjant właśnie rusza na służbę, ma patrolować stację metra na Times Square.

## Sondaż: PiS i Koalicja Obywatelska na plusie. Spadło poparcie dla Lewicy i Trzeciej Drogi
 - [https://www.rp.pl/wybory/art39161391-sondaz-pis-i-koalicja-obywatelska-na-plusie-spadlo-poparcie-dla-lewicy-i-trzeciej-drogi](https://www.rp.pl/wybory/art39161391-sondaz-pis-i-koalicja-obywatelska-na-plusie-spadlo-poparcie-dla-lewicy-i-trzeciej-drogi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:50:32+00:00

W ciągu ostatniego tygodnia najwięcej poparcia zyskała Koalicja Obywatelska, a najwięcej straciły Trzecia Droga i Lewica - wynika z najnowszego sondażu United Surveys.

## Marcin Bułka. Rozbił Lamborghini i bawił się z Neymarem, dziś mówi o nim Francja
 - [https://www.rp.pl/pilka-nozna/art39161211-marcin-bulka-rozbil-lamborghini-i-bawil-sie-z-neymarem-dzis-mowi-o-nim-francja](https://www.rp.pl/pilka-nozna/art39161211-marcin-bulka-rozbil-lamborghini-i-bawil-sie-z-neymarem-dzis-mowi-o-nim-francja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:50:31+00:00

Marcin Bułka broni rzuty karne, a jego OGC Nice jest wiceliderem francuskiej Ligue 1. 23-latek staje się kimś więcej niż kolegą Neymara i dzieciakiem, który rozbił Lamborghini.

## Jest prawomocny wyrok ws. dezubekizacji bohatera operacji "Samum"
 - [https://www.rp.pl/mundurowi/art39161481-jest-prawomocny-wyrok-ws-dezubekizacji-bohatera-operacji-samum](https://www.rp.pl/mundurowi/art39161481-jest-prawomocny-wyrok-ws-dezubekizacji-bohatera-operacji-samum)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:50:15+00:00

Sąd prawomocnie przywrócił emeryturę pułkownikowi Andrzejowi Maronde. Był jednym z dwóch oficerów, którzy kierowali słynną operacją Samum i których objęła tzw. ustawa dezubekizacyjna.

## Emerytury stażowe to psucie systemu? Oceny ekonomistów.
 - [https://klubekspertow.rp.pl/panel-ekonomistow/art39160701-emerytury-stazowe-to-psucie-systemu-oceny-ekonomistow](https://klubekspertow.rp.pl/panel-ekonomistow/art39160701-emerytury-stazowe-to-psucie-systemu-oceny-ekonomistow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:36:39+00:00

PiS wraca do pomysłu tzw. emerytur stażowych, które miałyby przysługiwać kobietom po 38 latach pracy, a mężczyznom po 43 latach pracy. Ekonomiści w większości uważają, że taka reforma oznaczałaby w praktyce obniżkę wieku emerytalnego.

## Popyt uwolniony, ceny mieszkań wystrzeliły. Są rekordy
 - [https://www.rp.pl/nieruchomosci/art39161401-popyt-uwolniony-ceny-mieszkan-wystrzelily-sa-rekordy](https://www.rp.pl/nieruchomosci/art39161401-popyt-uwolniony-ceny-mieszkan-wystrzelily-sa-rekordy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:32:36+00:00

Średnie ofertowe ceny lokali w ciągu miesiąca wzrosły o niemal 2 proc., a od początku roku – o 9 proc. – wynika z raportu Expandera i Rentier.io.

## Droższy frank - większe szanse frankowicza na wstrzymanie spłaty
 - [https://www.rp.pl/konsumenci/art39161221-drozszy-frank-wieksze-szanse-frankowicza-na-wstrzymanie-splaty](https://www.rp.pl/konsumenci/art39161221-drozszy-frank-wieksze-szanse-frankowicza-na-wstrzymanie-splaty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:23:00+00:00

Rosnący kurs franka powoduje na szczęście dla frankowczów większe szanse na uzyskanie sądowego zabezpieczenia przez wstrzymanie obowiązku spłaty rat na czas trwania procesu.

## Narasta problem z płaceniem alimentów. Jest niepokojący raport
 - [https://www.rp.pl/prawo-rodzinne/art39161281-narasta-problem-z-placeniem-alimentow-jest-niepokojacy-raport](https://www.rp.pl/prawo-rodzinne/art39161281-narasta-problem-z-placeniem-alimentow-jest-niepokojacy-raport)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:12:56+00:00

W Polsce 292 tys. osób, głównie mężczyzn, uchyla się od obowiązków alimentacyjnych i ma łącznie ponad 14,5 mld zł długów z tego tytułu - wynika z najnowszego raportu Krajowego Rejestru Długów. Z raportu można się także dowiedzieć kim są najczęściej dłużnicy alimentacyjni w Polsce oraz gdzie jest ich najwięcej.

## Pierwsze amerykańskie czołgi Abrams trafiły na Ukrainę. Zdążą wziąć udział w kontrofensywie?
 - [https://www.rp.pl/konflikty-zbrojne/art39161291-pierwsze-amerykanskie-czolgi-abrams-trafily-na-ukraine-zdaza-wziac-udzial-w-kontrofensywie](https://www.rp.pl/konflikty-zbrojne/art39161291-pierwsze-amerykanskie-czolgi-abrams-trafily-na-ukraine-zdaza-wziac-udzial-w-kontrofensywie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:11:00+00:00

Pierwsze amerykańskie czołgi Abrams zostały w sobotę dostarczone na Ukrainę - przekazali w rozmowie z „The New York Times” dwaj przedstawiciele Departamentu Obrony. Podkreślili, że maszyny trafiły na Ukrainę kilka miesięcy przed czasem.

## Ukraińcy: W ataku na Sewastopol zginął dowódca Floty Czarnomorskiej
 - [https://www.rp.pl/konflikty-zbrojne/art39161331-ukraincy-w-ataku-na-sewastopol-zginal-dowodca-floty-czarnomorskiej](https://www.rp.pl/konflikty-zbrojne/art39161331-ukraincy-w-ataku-na-sewastopol-zginal-dowodca-floty-czarnomorskiej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T11:09:00+00:00

Siły Specjalne Sił Zbrojnych Ukrainy podały na swoim kanale w serwisie Telegram, że w piątkowym ataku na Dowództwo Floty Czarnomorskiej w Sewastopolu zginęło 34 rosyjskich oficerów, w tym dowódca Floty Czarnomorskiej.

## Ziobro o słowach Scholza ws. afery wizowej: Jest wyjątkowo bezczelny
 - [https://www.rp.pl/polityka/art39161231-ziobro-o-slowach-scholza-ws-afery-wizowej-jest-wyjatkowo-bezczelny](https://www.rp.pl/polityka/art39161231-ziobro-o-slowach-scholza-ws-afery-wizowej-jest-wyjatkowo-bezczelny)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:51:00+00:00

Scholz jest na tyle bezczelny, że przy okazji rocznicy zakończenia II wojny światowej oświadczył, że Niemcy były okupowane przez nazistów. Przecież jego poprzedniczka, pani kanclerz Niemiec Angela Merkel łamiąc prawo wizowe, europejskie traktaty, doprowadziła do ściągnięcia tutaj ponad 1,5 mln, a nawet więcej nieznanych z tożsamości imigrantów - powiedział w rozmowie z Polsat News Zbigniew Ziobro.

## Kreml twierdzi, że dziennikarze z USA chcą rozmawiać z Władimirem Putinem. A co na to Putin?
 - [https://www.rp.pl/konflikty-zbrojne/art39161171-kreml-twierdzi-ze-dziennikarze-z-usa-chca-rozmawiac-z-wladimirem-putinem-a-co-na-to-putin](https://www.rp.pl/konflikty-zbrojne/art39161171-kreml-twierdzi-ze-dziennikarze-z-usa-chca-rozmawiac-z-wladimirem-putinem-a-co-na-to-putin)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:49:59+00:00

Amerykański dziennikarz, Tucker Carlson, były prezenter Fox News, w rozmowie z szwajcarską gazetą "Die Weltwoche" powiedział, że chciał porozmawiać z Władimirem Putinem, ale amerykańskie władze mu na to nie pozwalały. Komentarz w tej sprawie wygłosił rzecznik Kremla, Dmitrij Pieskow.

## Złoty odrabia straty. Polska waluta wróciła do łask po załamaniu
 - [https://www.rp.pl/finanse/art39161201-zloty-odrabia-straty-polska-waluta-wrocila-do-lask-po-zalamaniu](https://www.rp.pl/finanse/art39161201-zloty-odrabia-straty-polska-waluta-wrocila-do-lask-po-zalamaniu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:44:48+00:00

Z początkiem nowego tygodnia inwestorzy nieco łaskawiej spojrzeli na złotego, który umacnia się względem najważniejszych walut kontynuując pozytywny trend z zeszłego tygodnia. Ok godz. 9.00 za euro płacono ok. 4,59 zł, frank szwajcarski kosztował  nieco ponad 4,75 zł, a dolar ok. 4,31 zł.

## Złoty odrabia straty. Polska waluta wróciła do łask po załamaniu
 - [https://www.rp.pl/waluty/art39161201-zloty-odrabia-straty-polska-waluta-wrocila-do-lask-po-zalamaniu](https://www.rp.pl/waluty/art39161201-zloty-odrabia-straty-polska-waluta-wrocila-do-lask-po-zalamaniu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:44:00+00:00

Z początkiem nowego tygodnia inwestorzy nieco łaskawiej spojrzeli na złotego, który umacnia się względem najważniejszych walut kontynuując pozytywny trend z zeszłego tygodnia. Ok godz. 9.00 za euro płacono ok. 4,59 zł, frank szwajcarski kosztował  nieco ponad 4,75 zł, a dolar ok. 4,31 zł.

## Kobiety na wybory? Nie tędy droga...
 - [https://kobieta.rp.pl/opinie/art39160641-kobiety-na-wybory-nie-tedy-droga](https://kobieta.rp.pl/opinie/art39160641-kobiety-na-wybory-nie-tedy-droga)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:35:00+00:00

Nie sposób nie zauważyć, że temat kobiet zajmuje ważne miejsce w trwającej obecnie kampanii wyborczej. Pytanie, co z tego wynika...

## Kobiecość w biurowym wydaniu. Bogna Sworowska twarzą kampanii ubrań dla kobiet biznesu
 - [https://kobieta.rp.pl/jak%20si%C4%99%20ubra%C4%87%20do%20biura](https://kobieta.rp.pl/jak%20si%C4%99%20ubra%C4%87%20do%20biura)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:30:35+00:00

Czy przestrzeganie zasad biurowego dress code'u musi oznaczać rezygnację z kobiecego stylu? Nie! Coraz więcej marek odzieżowych ma swojej ofercie ubrania, które łączą zmysłową elegancję z elementami, które sprawdzą się też na spotkaniach biznesowych.

## Czym różni się celiakia od nieceliakalnej nadwrażliwości na gluten? Podobieństwa, diagnostyka, dieta
 - [https://www.rp.pl/zdrowie/art39161151-czym-rozni-sie-celiakia-od-nieceliakalnej-nadwrazliwosci-na-gluten-podobienstwa-diagnostyka-dieta](https://www.rp.pl/zdrowie/art39161151-czym-rozni-sie-celiakia-od-nieceliakalnej-nadwrazliwosci-na-gluten-podobienstwa-diagnostyka-dieta)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:30:00+00:00

Nietolerancje i alergie pokarmowe mogą dotyczyć osób w różnym wieku. W ostatnim czasie coraz więcej mówi się o nietolerancji glutenu - mieszaniny białek znajdującej się w pszenicy, orkiszu, jęczmieniu i życie. Czym różni się celiakia od nieceliakalnej nadwrażliwości na gluten? W jaki sposób zdiagnozować i leczyć te jednostki chorobowe?

## Lekarze: szkoła nie ma prawa żądać od uczniów zwolnień lekarskich
 - [https://edukacja.rp.pl/prawo-oswiatowe/art39160821-lekarze-szkola-nie-ma-prawa-zadac-od-uczniow-zwolnien-lekarskich](https://edukacja.rp.pl/prawo-oswiatowe/art39160821-lekarze-szkola-nie-ma-prawa-zadac-od-uczniow-zwolnien-lekarskich)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:23:00+00:00

Lekarze rodzinni podkreślają, że placówki edukacyjne nie powinny wymagać, by rodzice dostarczali do szkół zwolnienia wystawione przez lekarza. Wystarczy usprawiedliwienie rodzica lub pełnoletniego ucznia.

## Nowy spot PiS: Zamiast logo PO kontury Polski oparte od wschodu na linii Wisły
 - [https://www.rp.pl/wybory/art39161091-nowy-spot-pis-zamiast-logo-po-kontury-polski-oparte-od-wschodu-na-linii-wisly](https://www.rp.pl/wybory/art39161091-nowy-spot-pis-zamiast-logo-po-kontury-polski-oparte-od-wschodu-na-linii-wisly)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:23:00+00:00

"Jak powinno wyglądać logo partii Donalda Tuska po odkryciu planów Platformy Obywatelskiej?" - pyta w nowym spocie Prawa i Sprawiedliwości premier Mateusz Morawiecki. W klipie pojawia się następnie zmienione logo PO, przedstawiające kontury Polski oparte od wschodu na linii Wisły.

## Lot odwołany, bądź opóźniony? Pasażer płacze i płaci
 - [https://www.rp.pl/transport/art39160801-lot-odwolany-badz-opozniony-pasazer-placze-i-placi](https://www.rp.pl/transport/art39160801-lot-odwolany-badz-opozniony-pasazer-placze-i-placi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:22:54+00:00

AirHelp, największa na świecie kancelaria prawna wyspecjalizowana w odzyskiwaniu odszkodowań od linii lotniczych wyliczyła, że nieplanowane wydatki pasażerów, którzy nie dotarli na czas z winy przewoźnika, to 362 euro na osobę.

## Jakub Ekier: Niebezpieczna przyszłość nie-Polaków. „Zielona granica” w deszczu upokorzeń
 - [https://www.rp.pl/publicystyka/art39160981-jakub-ekier-niebezpieczna-przyszlosc-nie-polakow-zielona-granica-w-deszczu-upokorzen](https://www.rp.pl/publicystyka/art39160981-jakub-ekier-niebezpieczna-przyszlosc-nie-polakow-zielona-granica-w-deszczu-upokorzen)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:20:58+00:00

Słuszne komentarze mówią, że ofensywa rządzących przeciw „Zielonej granicy” Agnieszki Holland ma przed wyborami przyćmić aferę wizową i sterować emocjami. Oraz że podjudza i świadczy o braku hamulców. Trzeba dodać, jak liczne przeinaczenia tkwią w jej retoryce. I jak groźne niesie ona wykluczenie.

## Dlaczego wybuchł kryzys zbożowy? Rosyjska agencja cytuje prezydenckiego ministra
 - [https://www.rp.pl/dyplomacja/art39160771-dlaczego-wybuchl-kryzys-zbozowy-rosyjska-agencja-cytuje-prezydenckiego-ministra](https://www.rp.pl/dyplomacja/art39160771-dlaczego-wybuchl-kryzys-zbozowy-rosyjska-agencja-cytuje-prezydenckiego-ministra)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:19:41+00:00

W Polsce kryzys zbożowy między Polską a Ukrainą tłumaczy się naciskami na prezydenta Ukrainy Wołodymyra Zełenskiego - napisała rosyjska agencja RIA Nowosti, cytując wypowiedź Marcina Przydacza, szefa Biura Polityki Międzynarodowej Kancelarii Prezydenta RP.

## Sezon (bez)infekcyjny - wzmocnij odporność na jesień i zimę
 - [https://www.rp.pl/zdrowie/art39161111-sezon-bez-infekcyjny-wzmocnij-odpornosc-na-jesien-i-zime](https://www.rp.pl/zdrowie/art39161111-sezon-bez-infekcyjny-wzmocnij-odpornosc-na-jesien-i-zime)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:18:00+00:00

Kiedy temperatury spadają, a dni stają się krótsze, nasz organizm jest bardziej narażony na różnego rodzaju infekcje. Jak więc zadbać o naszą odporność w te chłodniejsze miesiące?

## Analitycy PKO BP: ceny mieszkań pójdą w górę
 - [https://www.rp.pl/nieruchomosci/art39161061-analitycy-pko-bp-ceny-mieszkan-pojda-w-gore](https://www.rp.pl/nieruchomosci/art39161061-analitycy-pko-bp-ceny-mieszkan-pojda-w-gore)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:11:34+00:00

Do końca I połowy 2024 roku lokale podrożeją nominalnie o 10-15 proc.  rocznie.

## Dzieła sztuki zaginione w czasie wojny przez Austrię i USA wrócą do Polski
 - [https://www.rp.pl/historia-polski/art39160891-dziela-sztuki-zaginione-w-czasie-wojny-przez-austrie-i-usa-wroca-do-polski](https://www.rp.pl/historia-polski/art39160891-dziela-sztuki-zaginione-w-czasie-wojny-przez-austrie-i-usa-wroca-do-polski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:09:58+00:00

Prywatny kolekcjoner z USA o polskich korzeniach zdecydował się przekazać do polskich zbiorów muzealnych zaginione w czasie wojny akwarele Zygmunta Vogla – ulubionego artysty króla Stanisława Augusta Poniatowskiego.

## Podatnicy na to czekali. Jest nowa usługa w e-Urzędzie Skarbowym
 - [https://www.rp.pl/podatki/art39160911-podatnicy-na-to-czekali-jest-nowa-usluga-w-e-urzedzie-skarbowym](https://www.rp.pl/podatki/art39160911-podatnicy-na-to-czekali-jest-nowa-usluga-w-e-urzedzie-skarbowym)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T10:01:22+00:00

Ministerstwo Finansów poinformowało, że oczekiwana przez użytkowników e-Urzędu Skarbowego usługa „Rozliczenia” jest już dostępna.

## Policyjne narkotesty dają fałszywe wyniki? Z analiz wynika, że dzieje się to często
 - [https://www.rp.pl/spoleczenstwo/art39160841-policyjne-narkotesty-daja-falszywe-wyniki-z-analiz-wynika-ze-dzieje-sie-to-czesto](https://www.rp.pl/spoleczenstwo/art39160841-policyjne-narkotesty-daja-falszywe-wyniki-z-analiz-wynika-ze-dzieje-sie-to-czesto)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T09:57:00+00:00

Urządzenia weryfikujące, czy kierowca jest pod wpływem narkotyków, które wykorzystuje polska policja, mają fałszować wyniki – sugerują dokumenty, do których dotarł Onet. W niektórych komendach błędne odczyty wykazano w ponad 80 proc. badań.

## Lego nie przejdzie na ekologiczny plastik, wcale nie jest taki eko
 - [https://www.rp.pl/biznes/art39160881-lego-nie-przejdzie-na-ekologiczny-plastik-wcale-nie-jest-taki-eko](https://www.rp.pl/biznes/art39160881-lego-nie-przejdzie-na-ekologiczny-plastik-wcale-nie-jest-taki-eko)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T09:53:57+00:00

Duński producent zabawek Lego zakończył program tworzenia nowej, ekologicznej wersji swoich plastikowych klocków. Okazało się, że nowy ekologiczny materiał ma większy ślad węglowy niż plastikowe klocki produkowane na bazie ropy naftowej – poinformował „Financial Times”.

## Silna przecena chińskich deweloperów
 - [https://www.rp.pl/rynek-nieruchomosci/art39160831-silna-przecena-chinskich-deweloperow](https://www.rp.pl/rynek-nieruchomosci/art39160831-silna-przecena-chinskich-deweloperow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T09:36:56+00:00

Poniedziałkowa sesja przyniosła silną wyprzedaż akcji chińskich firm deweloperskich. Papiery China Evergrande Group traciły nawet 25 procent.

## Ukraińcy: Henry Kissinger całkowicie zmienił zdanie w sprawie Ukrainy w NATO
 - [https://www.rp.pl/konflikty-zbrojne/art39160561-ukraincy-henry-kissinger-calkowicie-zmienil-zdanie-w-sprawie-ukrainy-w-nato](https://www.rp.pl/konflikty-zbrojne/art39160561-ukraincy-henry-kissinger-calkowicie-zmienil-zdanie-w-sprawie-ukrainy-w-nato)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T09:28:14+00:00

W czasie wizyty w USA prezydent Ukrainy, Wołodymyr Zełenski, spotkał się z Henrym Kissingerem, byłym sekretarzem stanu i doradcą ds. bezpieczeństwa narodowego prezydenta USA - poinformował szef kancelarii Zełenskiego, Andrij Jermak.

## Perspektywy rozwoju towarowych przewozów kolejowych w obszarze Trójmorza
 - [https://logistyka.rp.pl/szynowy/art39160731-perspektywy-rozwoju-towarowych-przewozow-kolejowych-w-obszarze-trojmorza](https://logistyka.rp.pl/szynowy/art39160731-perspektywy-rozwoju-towarowych-przewozow-kolejowych-w-obszarze-trojmorza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T09:10:04+00:00

Polska ma unikalną okazję rozwinięcia szlaków transportowych w kierunku północ-południe, co jest wielką szansą dla kolei.

## Hollywood: Koniec strajku scenarzystów, ale nie aktorów
 - [https://www.rp.pl/film/art39160291-hollywood-koniec-strajku-scenarzystow-ale-nie-aktorow](https://www.rp.pl/film/art39160291-hollywood-koniec-strajku-scenarzystow-ale-nie-aktorow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:59:00+00:00

Po pięciu miesiącach strajku Gildia Scenarzystów Amerykańskich osiągnęła wstępne porozumienie ze Stowarzyszeniem Producentów Filmowych. Aktorzy wciąż negocjują.

## Koniec strajku pisarzy
 - [https://www.rp.pl/film/art39160291-koniec-strajku-pisarzy](https://www.rp.pl/film/art39160291-koniec-strajku-pisarzy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:59:00+00:00

Po pięciu miesiącach strajku Gildia Scenarzystów Amerykańskich osiągnęła wstępne porozumienie ze Stowarzyszeniem Producentów Filmowych. Aktorzy wciąż negocjują.

## Michał Wypij: Powiedzmy wprost – w polskim rządzie pracował przemytnik
 - [https://www.rp.pl/polityka/art39160621-michal-wypij-powiedzmy-wprost-w-polskim-rzadzie-pracowal-przemytnik](https://www.rp.pl/polityka/art39160621-michal-wypij-powiedzmy-wprost-w-polskim-rzadzie-pracowal-przemytnik)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:49:00+00:00

Cały świat i cała Europa wiedzą, że w polskim rządzie, którego wicepremierem jest Jarosław Kaczyński, funkcjonował przemytnik. Zarabiał pieniądze i stworzył cały system wizowy – są na to dowody. To jest niespotykany skandal w skali świata - powiedział w programie #RZECZoPOLITYCE Michał Wypij, poseł, startujący z list Koalicji Obywatelskiej.

## Skandal z udziałem Zełenskiego w Kanadzie. Jest reakcja polskiej ambasady
 - [https://www.rp.pl/swiat/art39160591-skandal-z-udzialem-zelenskiego-w-kanadzie-jest-reakcja-polskiej-ambasady](https://www.rp.pl/swiat/art39160591-skandal-z-udzialem-zelenskiego-w-kanadzie-jest-reakcja-polskiej-ambasady)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:47:05+00:00

„Oczekuję przeprosin” - napisał Witold Dzielski, ambasador RP w Kanadzie, komentując uhonorowanie w czasie wizyty Wołodymyra Zełenskiego w Ottawie 98-letniego ukraińskiego emigranta Jarosława Hunki, który służył w nazistowskiej dywizji SS Galizien.

## Pomaska zapowiada pozwy wobec polityków PiS. Poszło o napis na szybie
 - [https://www.rp.pl/dobra-osobiste/art39160571-pomaska-zapowiada-pozwy-wobec-politykow-pis-poszlo-o-napis-na-szybie](https://www.rp.pl/dobra-osobiste/art39160571-pomaska-zapowiada-pozwy-wobec-politykow-pis-poszlo-o-napis-na-szybie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:43:57+00:00

Posłanka PO Agnieszka Pomaska zapowiada pozwy w trybie wyborczym wobec polityków Prawa i Sprawiedliwości. Powodem są wpisy, w których sugerują, że jechała samochodem, na którym był napis obraźliwy wobec wyborców PiS.

## ChatGPT i Bard mają rywala. Za sztuczną inteligencję bierze się gigant z USA
 - [https://cyfrowa.rp.pl/globalne-interesy/art39160611-chatgpt-i-bard-maja-rywala-za-sztuczna-inteligencje-bierze-sie-gigant-z-usa](https://cyfrowa.rp.pl/globalne-interesy/art39160611-chatgpt-i-bard-maja-rywala-za-sztuczna-inteligencje-bierze-sie-gigant-z-usa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:43:00+00:00

Branżę AI zdominowało dwóch graczy – Microsoft, finansujący tworzonego przez OpenAI bota ChatGPT, oraz Google, który uruchomił zaawansowanego chatbota o nazwie Bard. Teraz do tego wyścigu na zaawansowane algorytmy dołącza kolejny gigant – Amazon.

## ChatGPT ma rywala. Gigant z USA zainwestuje miliardy w sztuczną inteligencję
 - [https://cyfrowa.rp.pl/globalne-interesy/art39160611-chatgpt-ma-rywala-gigant-z-usa-zainwestuje-miliardy-w-sztuczna-inteligencje](https://cyfrowa.rp.pl/globalne-interesy/art39160611-chatgpt-ma-rywala-gigant-z-usa-zainwestuje-miliardy-w-sztuczna-inteligencje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:43:00+00:00

Branżę AI zdominowało dwóch graczy – Microsoft, finansujący tworzonego przez OpenAI bota ChatGPT, oraz Google, który uruchomił zaawansowanego chatbota o nazwie Bard. Teraz do tego wyścigu na zaawansowane algorytmy dołącza kolejny gigant – Amazon.

## Dawid Pałka: Czy bimber będzie technologiczną przyszłością Polski?
 - [https://www.rp.pl/opinie-ekonomiczne/art39160601-dawid-palka-czy-bimber-bedzie-technologiczna-przyszloscia-polski](https://www.rp.pl/opinie-ekonomiczne/art39160601-dawid-palka-czy-bimber-bedzie-technologiczna-przyszloscia-polski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:37:39+00:00

Z niepokojem patrzę na to, jakich umiejętności nabywają studenci prestiżowych uczelni w Polsce. To właśnie oni, będą tworzyć światłą elitę naszego narodu. Czy ich topowym osiągnięcie będzie bimber o mocy wystarczającej do napędzenia Izery?

## Dom Development i Echo odpalają głośne projekty
 - [https://www.rp.pl/nieruchomosci/art39160521-dom-development-i-echo-odpalaja-glosne-projekty](https://www.rp.pl/nieruchomosci/art39160521-dom-development-i-echo-odpalaja-glosne-projekty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:28:01+00:00

Deweloperzy ruszają ze sprzedażą mieszkań na odzyskanych dla Warszawy terenach. Za metr lokalu chcą prawie 19 tys. zł

## Od dzisiaj nowe ceny paliw. Eksperci prognozują zmiany
 - [https://moto.rp.pl/tu-i-teraz/art39160471-od-dzisiaj-nowe-ceny-paliw-eksperci-prognozuja-zmiany](https://moto.rp.pl/tu-i-teraz/art39160471-od-dzisiaj-nowe-ceny-paliw-eksperci-prognozuja-zmiany)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:18:04+00:00

Ceny paliwa na polskich stacjach paliw wciąż zadziwiają i spowodowały nawet uprawianie turystyki paliwowej naszych południowych i zachodnich sąsiadów. Wbrew rynkowym trendom płacimy za paliwo mniej. Teraz prognozowane są kolejne spadki cen benzyny i diesla.

## Pacjentkom po zabiegach w Turcji nie da się pomóc. Adwokatka o tym, na co mogą liczyć ofiary błędów lekarskich
 - [https://kobieta.rp.pl/b%C5%82%C4%85d%20lekarski%20jak%20dosta%C4%87%20odszkodowanie](https://kobieta.rp.pl/b%C5%82%C4%85d%20lekarski%20jak%20dosta%C4%87%20odszkodowanie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:12:59+00:00

Pacjentkom, które poddały się nieudanym operacjom plastycznym w Turcji, polskie prawo nie pomoże – mówi adwokat Ewelina Miller z kancelarii E & M MILLER Adwokaci Sp. P.

## Pacjentkom po zabiegach w Turcji nie da się pomóc. Adwokatka o tym, na co mogą liczyć ofiary błędów lekarskich
 - [https://kobieta.rp.pl/prawo/art39160231-pacjentkom-po-zabiegach-w-turcji-nie-da-sie-pomoc-adwokatka-o-tym-na-co-moga-liczyc-ofiary-bledow-lekarskich](https://kobieta.rp.pl/prawo/art39160231-pacjentkom-po-zabiegach-w-turcji-nie-da-sie-pomoc-adwokatka-o-tym-na-co-moga-liczyc-ofiary-bledow-lekarskich)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:12:00+00:00

Pacjentkom, które poddały się nieudanym operacjom plastycznym w Turcji, polskie prawo nie pomoże – mówi adwokat Ewelina Miller z kancelarii E & M MILLER Adwokaci Sp. P.

## Jak oddać głos w wyborach do Sejmu i Senatu oraz w referendum. Objaśniamy
 - [https://www.rp.pl/prawo-dla-ciebie/art39159431-jak-oddac-glos-w-wyborach-do-sejmu-i-senatu-oraz-w-referendum-objasniamy](https://www.rp.pl/prawo-dla-ciebie/art39159431-jak-oddac-glos-w-wyborach-do-sejmu-i-senatu-oraz-w-referendum-objasniamy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:06:00+00:00

Wybory do Sejmu i Senatu oraz referendum już 15 października. Tłumaczymy, ile kart do głosowania będzie czekało na wyborców w lokalu wyborczym, jak prawidłowo je wypełnić oraz jak oddać ważny głos poza miejscem zameldowania.

## GUS podał najnowsze dane o bezrobociu
 - [https://www.rp.pl/dane-gospodarcze/art39160491-gus-podal-najnowsze-dane-o-bezrobociu](https://www.rp.pl/dane-gospodarcze/art39160491-gus-podal-najnowsze-dane-o-bezrobociu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:04:00+00:00

W sierpniu w urzędach pracy zarejestrowano 103,3 tys. nowych bezrobotnych, o 1,2 proc. więcej mdm - podał Główny Urząd Statystyczny.

## Nocny atak na Odessę. Poważne uszkodzenia w porcie
 - [https://www.rp.pl/konflikty-zbrojne/art39160301-nocny-atak-na-odesse-powazne-uszkodzenia-w-porcie](https://www.rp.pl/konflikty-zbrojne/art39160301-nocny-atak-na-odesse-powazne-uszkodzenia-w-porcie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T08:00:55+00:00

Jedna osoba została ranna, a infrastruktura portowa została poważnie uszkodzona w wyniku nocnego ataku rakietowego oraz z użyciem dronów Rosjan na Odessę - podała ukraińska armia.

## Polacy nie wierzą w niską inflację GUS. Nawet wyborcy PiS
 - [https://www.rp.pl/dane-gospodarcze/art39160421-polacy-nie-wierza-w-niska-inflacje-gus-nawet-wyborcy-pis](https://www.rp.pl/dane-gospodarcze/art39160421-polacy-nie-wierza-w-niska-inflacje-gus-nawet-wyborcy-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T07:51:00+00:00

Polacy uważają, że ceny towarów i usług w ciągu ostatniego roku wzrosły średnio o 33 proc. - wynika z najnowszego sondażu United Surveys. Tymczasem, jak w połowie września podał Główny Urząd Statystyczny, inflacja w sierpniu wyniosła 10,1 procent.

## Krzysztof Brejza przerwał kampanię. „Dotarły do mnie szokujące informacje”
 - [https://www.rp.pl/polityka/art39160281-krzysztof-brejza-przerwal-kampanie-dotarly-do-mnie-szokujace-informacje](https://www.rp.pl/polityka/art39160281-krzysztof-brejza-przerwal-kampanie-dotarly-do-mnie-szokujace-informacje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T07:43:00+00:00

„Dotarły do mnie szokujące informacje. Zmuszony jestem zawiesić kampanię na najbliższych kilkanaście godzin” - poinformował na Twitterze w niedzielny wieczór Krzysztof Brejza, senator Koalicji Obywatelskiej.

## Niemcy odrabiają straty w turystyce. Goście z Polski ustanowili nowy rekord
 - [https://turystyka.rp.pl/popularne-trendy/art39160241-niemcy-odrabiaja-straty-w-turystyce-goscie-z-polski-ustanowili-nowy-rekord](https://turystyka.rp.pl/popularne-trendy/art39160241-niemcy-odrabiaja-straty-w-turystyce-goscie-z-polski-ustanowili-nowy-rekord)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T07:39:12+00:00

Zmniejsza się dystans do wyników z najlepszego dotąd roku 2019, w pierwszym półroczu tego roku liczba noclegów wykupionych przez turystów w Niemczech osiągnęła 87,9 procent tamtego poziomu - informuje Niemiecka Centrala Turystyki. Szczególnie dynamicznie przybywa gości z Polski.

## Czym się różni chemex od dripa? Te metody parzenia kawy robią furorę
 - [https://kobieta.rp.pl/kuchnia/art39156231-czym-sie-rozni-chemex-od-dripa-te-metody-parzenia-kawy-robia-furore](https://kobieta.rp.pl/kuchnia/art39156231-czym-sie-rozni-chemex-od-dripa-te-metody-parzenia-kawy-robia-furore)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T07:36:47+00:00

Co drugi Polak rozpoczyna dzień pracy od filiżanki kawy – tak wskazują analizy Food Research Institute. 45 proc. badanych uważa, że to właśnie kawa zapewnia im większą produktywność. A gdyby tak pójść o krok dalej i zadbać o to, aby smakowała jeszcze lepiej, a jej przygotowywanie stało się pasją?

## Szef Gabinetu Prezydenta zawyrokował, komu może się podobać „Zielona Granica”
 - [https://www.rp.pl/polityka/art39160211-szef-gabinetu-prezydenta-zawyrokowal-komu-moze-sie-podobac-zielona-granica](https://www.rp.pl/polityka/art39160211-szef-gabinetu-prezydenta-zawyrokowal-komu-moze-sie-podobac-zielona-granica)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T07:11:40+00:00

„Zielona granica”, najnowszy film Agnieszki Holland, „może się podobać tylko zamkniętej, hermetycznej, niewielkiej banieczce warszawskich lewicowo-liberalnych środowisk” - ocenił Paweł Szrot, szef Gabinetu Prezydenta RP, kandydat PiS w wyborach do Sejmu.

## Nowy sondaż: Konfederacja spadła na piąte miejsce. „Taktyka PiS okazała się skuteczna”
 - [https://www.rp.pl/wybory/art39160051-nowy-sondaz-konfederacja-spadla-na-piate-miejsce-taktyka-pis-okazala-sie-skuteczna](https://www.rp.pl/wybory/art39160051-nowy-sondaz-konfederacja-spadla-na-piate-miejsce-taktyka-pis-okazala-sie-skuteczna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T06:33:12+00:00

Poparcie dla Prawa i Sprawiedliwości rośnie, podczas gdy dla Koalicji Obywatelskiej stoi w miejscu - wynika z sondażu, przeprowadzonego przez instytut Pollster dla „Super Expressu”.

## Polskie działo neutronowe. Niezwykły wynalazek zneutralizuje zagrożenie Bałtyku
 - [https://cyfrowa.rp.pl/technologie/art39158921-polskie-dzialo-neutronowe-niezwykly-wynalazek-zneutralizuje-zagrozenie-baltyku](https://cyfrowa.rp.pl/technologie/art39158921-polskie-dzialo-neutronowe-niezwykly-wynalazek-zneutralizuje-zagrozenie-baltyku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T06:33:00+00:00

Naukowcy opracowali nietypowe narzędzie do rozpoznawania materiałów niebezpiecznych – działo, które zdalnie rozpozna substancje zatopione w morzu.

## Fiasko komunikacyjnej rewolucji. Śląsk rezygnuje z autobusów na wodór
 - [https://regiony.rp.pl/transport/art39160021-fiasko-komunikacyjnej-rewolucji-slask-rezygnuje-z-autobusow-na-wodor](https://regiony.rp.pl/transport/art39160021-fiasko-komunikacyjnej-rewolucji-slask-rezygnuje-z-autobusow-na-wodor)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T06:14:22+00:00

Aglomeracja śląska rezygnuje z wodorowych autobusów przez wysoką cenę paliwa.

## Kosiniak-Kamysz: Dlaczego rząd nie wystąpił o 1 000 euro na każdego uchodźcę w Polsce?
 - [https://www.rp.pl/wybory/art39159911-kosiniak-kamysz-dlaczego-rzad-nie-wystapil-o-1-000-euro-na-kazdego-uchodzce-w-polsce](https://www.rp.pl/wybory/art39159911-kosiniak-kamysz-dlaczego-rzad-nie-wystapil-o-1-000-euro-na-kazdego-uchodzce-w-polsce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T05:56:05+00:00

Dlaczego w Kijowie nie potrafili załatwić sprawy zboża i powiedzieć: tyle pomogliśmy, ale to jest bezpieczeństwo żywnościowe Polski, nie możemy się na to zgodzić - mówił w rozmowie z TVN24 prezes PSL, Władysław Kosiniak-Kamysz.

## Sondaż: Rafał Trzaskowski nie jest już liderem rankingu zaufania do polityków. Nowy lider rankingu nieufności
 - [https://www.rp.pl/wybory/art39159891-sondaz-rafal-trzaskowski-nie-jest-juz-liderem-rankingu-zaufania-do-politykow-nowy-lider-rankingu-nieufnosci](https://www.rp.pl/wybory/art39159891-sondaz-rafal-trzaskowski-nie-jest-juz-liderem-rankingu-zaufania-do-politykow-nowy-lider-rankingu-nieufnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T05:06:23+00:00

Andrzej Duda wyprzedził Rafała Trzaskowskiego w rankingu zaufania do polityków - wynika z najnowszego sondażu IBRIS dla Onetu. Prezydentowi ufa 44,1 proc. Polaków, o 5,6 punktu procentowego więcej, niż w sierpniu.

## Sondaż: Co drugi wyborca KO uważa, że wybory wygra PiS
 - [https://www.rp.pl/wybory/art39159871-sondaz-co-drugi-wyborca-ko-uwaza-ze-wybory-wygra-pis](https://www.rp.pl/wybory/art39159871-sondaz-co-drugi-wyborca-ko-uwaza-ze-wybory-wygra-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T04:46:30+00:00

57,7 proc. badanych uważa, że wybory parlamentarne wygra Zjednoczona Prawica. Jednocześnie - zdaniem uczestników sondażu United Surveys dla Wirtualnej Polski - jest mało prawdopodobne, by Zjednoczona Prawica po wygraniu wyborów była w stanie utworzyć rząd bez koalicjanta.

## Sondaż: Czy „Zielona granica” Agnieszki Holland będzie miała wpływ na wynik wyborów?
 - [https://www.rp.pl/wybory/art39159031-sondaz-czy-zielona-granica-agnieszki-holland-bedzie-miala-wplyw-na-wynik-wyborow](https://www.rp.pl/wybory/art39159031-sondaz-czy-zielona-granica-agnieszki-holland-bedzie-miala-wplyw-na-wynik-wyborow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T04:00:00+00:00

Najwięcej ankietowanych w sondażu IBRiS dla "Rzeczpospolitej", w tym głosujących na PiS, uważa że „Zielona granica” Agnieszki Holland nie wpłynie na wynik wyborów parlamentarnych.

## Sondaż: Film „Zielona granica” Agnieszki Holland nie będzie miał wpływu na wynik wyborów
 - [https://www.rp.pl/wybory/art39159031-sondaz-film-zielona-granica-agnieszki-holland-nie-bedzie-mial-wplywu-na-wynik-wyborow](https://www.rp.pl/wybory/art39159031-sondaz-film-zielona-granica-agnieszki-holland-nie-bedzie-mial-wplywu-na-wynik-wyborow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T04:00:00+00:00

Najwięcej ankietowanych w sondażu IBRiS dla "Rzeczpospolitej", w tym głosujących na PiS, uważa że „Zielona granica” Agnieszki Holland nie wpłynie na wynik wyborów parlamentarnych.

## Zuzanna Dąbrowska: PiS nie udała się nagonka na Agnieszkę Holland
 - [https://www.rp.pl/komentarze/art39158961-zuzanna-dabrowska-pis-nie-udala-sie-nagonka-na-agnieszke-holland](https://www.rp.pl/komentarze/art39158961-zuzanna-dabrowska-pis-nie-udala-sie-nagonka-na-agnieszke-holland)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T04:00:00+00:00

PiS zapędziło się aż pod Moskwę w krucjacie przeciw Agnieszce Holland. Ale wyborcy nie dali się porwać kampanii nienawiści.

## Ukraiński żołnierz nazistowskiej dywizji SS nazwany bohaterem w Kanadzie. Są przeprosiny
 - [https://www.rp.pl/dyplomacja/art39159851-ukrainski-zolnierz-nazistowskiej-dywizji-ss-nazwany-bohaterem-w-kanadzie-sa-przeprosiny](https://www.rp.pl/dyplomacja/art39159851-ukrainski-zolnierz-nazistowskiej-dywizji-ss-nazwany-bohaterem-w-kanadzie-sa-przeprosiny)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T03:46:19+00:00

Spiker Izby Gmin kanadyjskiego parlamentu, Anthony Rota, przeprosił w niedzielę za chwalenie na forum parlamentu weterana z Ukrainy, który w czasie II wojny światowej walczył w 14. Dywizji Grenadierów Waffen SS (14 Dywizji Waffen SS-Galizien).

## Włochy: Zmarł "ostatni Ojciec Chrzestny". Mafioso ukrywał się 30 lat przed policją
 - [https://www.rp.pl/przestepczosc/art39159821-wlochy-zmarl-ostatni-ojciec-chrzestny-mafioso-ukrywal-sie-30-lat-przed-policja](https://www.rp.pl/przestepczosc/art39159821-wlochy-zmarl-ostatni-ojciec-chrzestny-mafioso-ukrywal-sie-30-lat-przed-policja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T03:18:56+00:00

W wieku 61 lat w areszcie zmarł Matteo Messina Denaro, domniemany szef sycylijskiej mafii, który w styczniu został aresztowany przez policję, która poszukiwała go od 30 lat.

## Znów gorąco w Kosowie. Serbowie szturmowali wieś na północy kraju
 - [https://www.rp.pl/konflikty-zbrojne/art39159801-znow-goraco-w-kosowie-serbowie-szturmowali-wies-na-polnocy-kraju](https://www.rp.pl/konflikty-zbrojne/art39159801-znow-goraco-w-kosowie-serbowie-szturmowali-wies-na-polnocy-kraju)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T03:02:15+00:00

Uzbrojeni Serbowie zaatakowali wieś w północnym Kosowie, ścierając się z policjantami i barykadując w klasztorze. W walkach zginęły cztery osoby - podaje agencja Reutera.

## Wojna Rosji z Ukrainą. Dzień 579
 - [https://www.rp.pl/swiat/art39159781-wojna-rosji-z-ukraina-dzien-579](https://www.rp.pl/swiat/art39159781-wojna-rosji-z-ukraina-dzien-579)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T02:37:23+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. Wołodymyr Zełenski mówił o historycznym znaczeniu porozumienia z USA ws. wspólnej produkcji broni przez Stany Zjednoczone i Ukrainę.

## Emerytury stażowe? Eksperci: To pomysł rodem z czasów pańszczyźnianych
 - [https://www.rp.pl/finanse/art39159351-emerytury-stazowe-eksperci-to-pomysl-rodem-z-czasow-panszczyznianych](https://www.rp.pl/finanse/art39159351-emerytury-stazowe-eksperci-to-pomysl-rodem-z-czasow-panszczyznianych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:10:00+00:00

Wprowadzenie emerytur stażowych w formie, którą proponuje PiS, oznaczałoby w praktyce obniżenie wieku emerytalnego, podczas gdy ten powinien rosnąć.

## Adwokaci i radcowie sprzeciwiają się pomysłowi PiS o łączeniu ich samorządów
 - [https://www.rp.pl/zawody-prawnicze/art39158821-adwokaci-i-radcowie-sprzeciwiaja-sie-pomyslowi-pis-o-laczeniu-ich-samorzadow](https://www.rp.pl/zawody-prawnicze/art39158821-adwokaci-i-radcowie-sprzeciwiaja-sie-pomyslowi-pis-o-laczeniu-ich-samorzadow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Nie ma zgody przedstawicieli władz największych samorządów prawniczych na fuzję. To główny wniosek z debaty, która odbyła się w redakcji „Rzeczpospolitej”.

## Afera wizowa skończy się na Edgarze K.? Nowe informacje w sprawie
 - [https://www.rp.pl/przestepczosc/art39159051-afera-wizowa-skonczy-sie-na-edgarze-k-nowe-informacje-w-sprawie](https://www.rp.pl/przestepczosc/art39159051-afera-wizowa-skonczy-sie-na-edgarze-k-nowe-informacje-w-sprawie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Prokuratura uważa, że 25-latek sam wymyślił „interes wizowy”. Mężczyzna zaprzecza, by dzielił się łapówkami z wiceministrem.

## Coraz szybsze tempo przygotowań do budowy CPK
 - [https://www.rp.pl/transport/art39159651-coraz-szybsze-tempo-przygotowan-do-budowy-cpk](https://www.rp.pl/transport/art39159651-coraz-szybsze-tempo-przygotowan-do-budowy-cpk)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Jest decyzja środowiskowa, plan generalny, promesa lotnicza, projekt terminala i dworca.

## Czy ESG zredefiniuje ład korporacyjny?
 - [https://www.rp.pl/forum-esg/art39159671-czy-esg-zredefiniuje-lad-korporacyjny](https://www.rp.pl/forum-esg/art39159671-czy-esg-zredefiniuje-lad-korporacyjny)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Rozwój firmy w sposób zrównoważony umożliwia przyjęcie długoterminowej perspektywy tego rozwoju, napędza innowacje i minimalizuje ryzyko.

## Czy Ukraińcy stracą świadczenia socjalne w Polsce - 500+, "Dobry start"?
 - [https://www.rp.pl/spoleczenstwo/art39159061-czy-ukraincy-straca-swiadczenia-socjalne-w-polsce-500-dobry-start](https://www.rp.pl/spoleczenstwo/art39159061-czy-ukraincy-straca-swiadczenia-socjalne-w-polsce-500-dobry-start)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

O przedłużeniu lub likwidacji przywilejów socjalnych dla Ukraińców, takich jak świadczenie 500+ i "Dobry start" - zdecyduje już nowy parlament, a nie obecny rząd Prawa i Sprawiedliwości.

## Czy Ukraińcy stracą świadczenia socjalne w Polsce?
 - [https://www.rp.pl/spoleczenstwo/art39159061-czy-ukraincy-straca-swiadczenia-socjalne-w-polsce](https://www.rp.pl/spoleczenstwo/art39159061-czy-ukraincy-straca-swiadczenia-socjalne-w-polsce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

O przedłużeniu lub likwidacji przywilejów dla Ukraińców zdecyduje już nowy parlament, a nie obecny rząd Prawa i Sprawiedliwości.

## KO stawia na marsz 1 października. Co zrobi reszta opozycji?
 - [https://www.rp.pl/wybory/art39159081-ko-stawia-na-marsz-1-pazdziernika-co-zrobi-reszta-opozycji](https://www.rp.pl/wybory/art39159081-ko-stawia-na-marsz-1-pazdziernika-co-zrobi-reszta-opozycji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Marsz 1 października dla KO ma być jednym z najważniejszych momentów jesiennej kampanii. Co zrobią inne partie opozycyjne?

## Kreml szuka Władimirowi Putinowi „demokratycznego” rywala
 - [https://www.rp.pl/polityka/art39159111-kreml-szuka-wladimirowi-putinowi-demokratycznego-rywala](https://www.rp.pl/polityka/art39159111-kreml-szuka-wladimirowi-putinowi-demokratycznego-rywala)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Gospodarzowi Kremla zależy, by świat zachodni uznał wynik przyszłorocznych wyborów prezydenckich w Rosji.

## Latynosi i Afroamerykanie - nowy elektorat Donalda Trumpa
 - [https://www.rp.pl/polityka/art39159101-latynosi-i-afroamerykanie-nowy-elektorat-donalda-trumpa](https://www.rp.pl/polityka/art39159101-latynosi-i-afroamerykanie-nowy-elektorat-donalda-trumpa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Były prezydent, który ubiega się o kolejną kadencję, bije rekordy popularności wśród Latynosów oraz czarnych wyborców.

## Latynosi i czarni - nowy elektorat Donalda Trumpa
 - [https://www.rp.pl/polityka/art39159101-latynosi-i-czarni-nowy-elektorat-donalda-trumpa](https://www.rp.pl/polityka/art39159101-latynosi-i-czarni-nowy-elektorat-donalda-trumpa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Były prezydent, który ubiega się o kolejną kadencję, bije rekordy popularności wśród Latynosów oraz czarnych wyborców.

## Marcin Wasilewski, EIT InnoEnergy: Rynek potrzebuje transformacji
 - [https://energia.rp.pl/transformacja-energetyczna/art39159601-marcin-wasilewski-eit-innoenergy-rynek-potrzebuje-transformacji](https://energia.rp.pl/transformacja-energetyczna/art39159601-marcin-wasilewski-eit-innoenergy-rynek-potrzebuje-transformacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Nie stworzyliśmy energetyki, która byłaby naszą przewagą rynkową. Polska może przegrywać pod tym względem z krajami, które szybciej realizują transformację energetyczną – mówi Marcin Wasilewski, prezes funduszu EIT InnoEnergy.

## Marek A. Cichocki: Polityka zagraniczna w cieniu narodowej katastrofy
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39159001-marek-a-cichocki-polityka-zagraniczna-w-cieniu-narodowej-katastrofy](https://www.rp.pl/opinie-polityczno-spoleczne/art39159001-marek-a-cichocki-polityka-zagraniczna-w-cieniu-narodowej-katastrofy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Ostatnie dni stanowią doskonałą ilustrację naszej dziedziczonej przez pokolenia wewnętrznej słabości w relacjach z innymi państwami i narodami.

## Michał Michalak: Każdy z nas staje nad urwiskiem
 - [https://www.rp.pl/koszykowka/art39159131-michal-michalak-kazdy-z-nas-staje-nad-urwiskiem](https://www.rp.pl/koszykowka/art39159131-michal-michalak-kazdy-z-nas-staje-nad-urwiskiem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

O problemach krajowej koszykówki, ściganiu europejskich standardów, planach na sportowe życie po życiu oraz o tym, dlaczego Marcin Gortat ma na emeryturze łatwiej niż inni – mówi Michał Michalak, reprezentant Polski.

## Paweł Rożyński: Niedźwiedzia przysługa dla wałęsów
 - [https://www.rp.pl/opinie-ekonomiczne/art39159341-pawel-rozynski-niedzwiedzia-przysluga-dla-walesow](https://www.rp.pl/opinie-ekonomiczne/art39159341-pawel-rozynski-niedzwiedzia-przysluga-dla-walesow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Zbyt gorliwe regulowanie platform cyfrowych może zarżnąć wiele innowacyjnych biznesów i być kolejnym ciosem w słabnącą gospodarczą pozycję Europy.

## Pizzerie i fast-foody mocno obrywają. Straciły w wakacje mnóstwo klientów
 - [https://www.rp.pl/gastronomia/art39159311-pizzerie-i-fast-foody-mocno-obrywaja-stracily-w-wakacje-mnostwo-klientow](https://www.rp.pl/gastronomia/art39159311-pizzerie-i-fast-foody-mocno-obrywaja-stracily-w-wakacje-mnostwo-klientow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

W sumie w 1,8 tys. placówek największych sieci tego typu na rynku, od początku czerwca do końca sierpnia, łącznie liczba wizyt klientów spadła aż o 14,1 proc.

## Początek końca złotej ery rekordowych zysków banków
 - [https://www.rp.pl/banki/art39159371-poczatek-konca-zlotej-ery-rekordowych-zyskow-bankow](https://www.rp.pl/banki/art39159371-poczatek-konca-zlotej-ery-rekordowych-zyskow-bankow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Spadające stopy procentowe i wakacje kredytowe to widmo słabszych wyników sektora finansowego. W tle wciąż czai się duże ryzyko kredytów frankowych. Ale zarobki nadal mogą być liczone w miliardach.

## Początek wielkiej ucieczki. Gdzie trafią uchodźcy z Karabachu?
 - [https://www.rp.pl/konflikty-zbrojne/art39159121-poczatek-wielkiej-ucieczki-gdzie-trafia-uchodzcy-z-karabachu](https://www.rp.pl/konflikty-zbrojne/art39159121-poczatek-wielkiej-ucieczki-gdzie-trafia-uchodzcy-z-karabachu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Pierwsze samochody Ormian mieszkających w eksklawie, która skapitulowała przed Azerbejdżanem, dotarły do Armenii.

## Przedsiębiorcy mierzą się z wieloma problemami, niekiedy z winy rządzących
 - [https://www.rp.pl/prawo-pracy/art39158841-przedsiebiorcy-mierza-sie-z-wieloma-problemami-niekiedy-z-winy-rzadzacych](https://www.rp.pl/prawo-pracy/art39158841-przedsiebiorcy-mierza-sie-z-wieloma-problemami-niekiedy-z-winy-rzadzacych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Zastanówmy się nad rozróżnieniem obowiązków małych i średnich firm względem dużych biznesów. Często zadania nakładane na przedsiębiorstwa z sektora MŚP są dla nich trudne do udźwignięcia, podczas gdy większe podmioty nie mają z nimi problemów – mówi dr Barbara Godlewska-Bujok.

## Przybywa kampusowych sieci 5G od Orange
 - [https://www.rp.pl/biznes/art39159661-przybywa-kampusowych-sieci-5g-od-orange](https://www.rp.pl/biznes/art39159661-przybywa-kampusowych-sieci-5g-od-orange)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Po Miele, Nokii i Łódzkiej Specjalnej Strefie Ekonomicznej teraz Politechnika Śląska wykorzysta technologię 5G w zbudowanej dla niej sieci.

## Studenci otwarci na sztuczną inteligencję i networking z apki
 - [https://www.rp.pl/poszukiwanie-pracy/art39159611-studenci-otwarci-na-sztuczna-inteligencje-i-networking-z-apki](https://www.rp.pl/poszukiwanie-pracy/art39159611-studenci-otwarci-na-sztuczna-inteligencje-i-networking-z-apki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Wprawdzie Polacy studiujący na najlepszych uczelniach Europy uczestniczyli w tegorocznym Poland 2.0 Summit na żywo, ale w konferencyjnym networkingu wspierała ich aplikacja.

## Szpitale mogą nagrywać operacje pacjentów, ale nie wiedzą jak to robić
 - [https://www.rp.pl/zdrowie/art39157761-szpitale-moga-nagrywac-operacje-pacjentow-ale-nie-wiedza-jak-to-robic](https://www.rp.pl/zdrowie/art39157761-szpitale-moga-nagrywac-operacje-pacjentow-ale-nie-wiedza-jak-to-robic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Brakuje jasnych wytycznych, jak zabezpieczać dane z monitoringu i kto ma mieć do nich dostęp.

## Tenisistki po dwóch latach wróciły do Chin. Iga Świątek zaczyna dwa tygodnie gry w Azji
 - [https://www.rp.pl/tenis/art39159141-tenisistki-po-dwoch-latach-wrocily-do-chin-iga-swiatek-zaczyna-dwa-tygodnie-gry-w-azji](https://www.rp.pl/tenis/art39159141-tenisistki-po-dwoch-latach-wrocily-do-chin-iga-swiatek-zaczyna-dwa-tygodnie-gry-w-azji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Turniej w Kantonie był pierwszym rozegranym w Chinach od grudnia 2021 roku, czyli chwili, gdy władze WTA ogłosiły bojkot kraju w trosce o losy zaginionej Shuai Peng.

## Trudny powrót Kamila Glika do Ekstraklasy. Cracovia rozgromiona
 - [https://www.rp.pl/pilka-nozna/art39159151-trudny-powrot-kamila-glika-do-ekstraklasy-cracovia-rozgromiona](https://www.rp.pl/pilka-nozna/art39159151-trudny-powrot-kamila-glika-do-ekstraklasy-cracovia-rozgromiona)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Obrońca reprezentacji Polski po 13 latach znów zagrał w Ekstraklasie, ale o powrocie powinien jak najszybciej zapomnieć. Cracovia uległa Pogoni Szczecin aż 1:5.

## Trzecia Droga nie tak wyboista. Program gospodarczy "należy do rozsądniejszych"
 - [https://www.rp.pl/gospodarka/art39159641-trzecia-droga-nie-tak-wyboista-program-gospodarczy-nalezy-do-rozsadniejszych](https://www.rp.pl/gospodarka/art39159641-trzecia-droga-nie-tak-wyboista-program-gospodarczy-nalezy-do-rozsadniejszych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Mimo szeregu uwag i zastrzeżeń eksperci, z którymi rozmawialiśmy, raczej dobrze oceniają program gospodarczy Trzeciej Drogi.

## UE może sprawić, że z polskich miast będą znikać dostawy jedzenia i przewóz osób
 - [https://www.rp.pl/praca/art39159281-ue-moze-sprawic-ze-z-polskich-miast-beda-znikac-dostawy-jedzenia-i-przewoz-osob](https://www.rp.pl/praca/art39159281-ue-moze-sprawic-ze-z-polskich-miast-beda-znikac-dostawy-jedzenia-i-przewoz-osob)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Nawet 70 proc. pracowników świadczących przez aplikację usługi taksówkowe oraz dowozu zakupów i posiłków może zrezygnować z pracy – dowiedziała się „Rzeczpospolita”.

## Usługi przez apkę będą droższe i trudno dostępne
 - [https://www.rp.pl/uslugi/art39159291-uslugi-przez-apke-beda-drozsze-i-trudno-dostepne](https://www.rp.pl/uslugi/art39159291-uslugi-przez-apke-beda-drozsze-i-trudno-dostepne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Bruksela bierze się za pracę platformową. Zmiany mają być korzystne dla pracowników, ale firmy z branży dostawczej i przewozowej straszą poważnymi konsekwencjami dla klientów końcowych.

## Z polskich miast będą znikać dostawy jedzenia i przewóz osób?
 - [https://www.rp.pl/praca/art39159281-z-polskich-miast-beda-znikac-dostawy-jedzenia-i-przewoz-osob](https://www.rp.pl/praca/art39159281-z-polskich-miast-beda-znikac-dostawy-jedzenia-i-przewoz-osob)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Nawet 70 proc. pracowników świadczących przez aplikację usługi taksówkowe oraz dowozu zakupów i posiłków może zrezygnować z pracy – dowiedziała się „Rzeczpospolita”.

## Zabezpieczyliśmy węgiel dla gospodarstw domowych
 - [https://www.rp.pl/biznes/art39159701-zabezpieczylismy-wegiel-dla-gospodarstw-domowych](https://www.rp.pl/biznes/art39159701-zabezpieczylismy-wegiel-dla-gospodarstw-domowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T01:00:00+00:00

Węgla dla domów i mieszkań w Polsce będzie pod dostatkiem. Zabezpieczyliśmy rezerwy, uruchomiliśmy odpowiednie mechanizmy, aby pilnować cen za pośrednictwem naszych spółek – mówi Marek Wesoły, sekretarz stanu w Ministerstwie Aktywów Państwowych.

## Mapa cen wycieczek czerwona od podwyżek. A najbardziej Portugalia i Albania
 - [https://turystyka.rp.pl/biura-podrozy/art39159711-mapa-cen-wycieczek-czerwona-od-podwyzek-a-najbardziej-portugalia-i-albania](https://turystyka.rp.pl/biura-podrozy/art39159711-mapa-cen-wycieczek-czerwona-od-podwyzek-a-najbardziej-portugalia-i-albania)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:38:19+00:00

370 złotych więcej za Portugalię, 368 złotych za Albanię, 159 złotych za Egipt i 107 złotych za Wyspy Kanaryjskie - to tyko niektóre przykłady podwyżek w biurach podróży z tych, które odnotowuje w najnowszym raporcie Traveldata.

## (Nie)jednokrotna neutralność transakcji restrukturyzacyjnych
 - [https://www.rp.pl/podatki/art39150281-nie-jednokrotna-neutralnosc-transakcji-restrukturyzacyjnych](https://www.rp.pl/podatki/art39150281-nie-jednokrotna-neutralnosc-transakcji-restrukturyzacyjnych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:00:00+00:00

Sądy administracyjne zwracają uwagę, że wprowadzone Polskim Ładem przepisy ograniczające neutralność podatkową tylko do pierwszej restrukturyzacji nie mogą być stosowane do zdarzeń przeszłych.

## Działalność fundacji może być opodatkowana VAT
 - [https://www.rp.pl/podatki/art39150311-dzialalnosc-fundacji-moze-byc-opodatkowana-vat](https://www.rp.pl/podatki/art39150311-dzialalnosc-fundacji-moze-byc-opodatkowana-vat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:00:00+00:00

To czy fundacja działa jako podatnik podatku od towarów i usług, zależy w znacznej mierze od charakteru czynności, które wykonuje, a zwłaszcza od tego czy dana czynność dokonywana jest odpłatnie.

## Jak traktować koszty rozliczane w czasie na potrzeby estońskiego CIT
 - [https://www.rp.pl/podatki/art39150291-jak-traktowac-koszty-rozliczane-w-czasie-na-potrzeby-estonskiego-cit](https://www.rp.pl/podatki/art39150291-jak-traktowac-koszty-rozliczane-w-czasie-na-potrzeby-estonskiego-cit)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:00:00+00:00

Estoński CIT odracza moment powstania obowiązku podatkowego do chwili dystrybucji zysku do wspólników. Jednocześnie do podstawy opodatkowania zalicza się też świadczenia powstałe w sposób inny niż przez wypłatę dywidendy.

## Jakie elementy analiz porównawczych są najczęściej kwestionowane
 - [https://www.rp.pl/podatki/art39150271-jakie-elementy-analiz-porownawczych-sa-najczesciej-kwestionowane](https://www.rp.pl/podatki/art39150271-jakie-elementy-analiz-porownawczych-sa-najczesciej-kwestionowane)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:00:00+00:00

Dzięki analizie podmioty powiązane są w stanie udowadniać, że ich transakcje zostały zawarte na warunkach, jakie stosowałyby pomiędzy sobą podmioty niepowiązane. Dlatego muszą to być dokumenty najwyższej jakości.

## Kiedy kara umowna jest kosztem
 - [https://www.rp.pl/podatki/art39150301-kiedy-kara-umowna-jest-kosztem](https://www.rp.pl/podatki/art39150301-kiedy-kara-umowna-jest-kosztem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:00:00+00:00

Nie wszystkie kary umowne, które nie zostały wymienione w negatywnym ustawowym katalogu, mogą być rozliczone przez podatnika. Istotne jest, aby obowiązek zapłaty kary nie był spowodowany jego zawinionym działaniem.

## Odsetki od fiskusa mają związek z zachowaniem źródła przychodów
 - [https://www.rp.pl/podatki/art39150251-odsetki-od-fiskusa-maja-zwiazek-z-zachowaniem-zrodla-przychodow](https://www.rp.pl/podatki/art39150251-odsetki-od-fiskusa-maja-zwiazek-z-zachowaniem-zrodla-przychodow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:00:00+00:00

Wydatek poniesiony przez spółkę na wypłatę kwoty odpowiadającej kwocie odsetek otrzymanych przez nią od organu podatkowego w związku ze zwrotem nadpłaconego podatku akcyzowego, dokonany na rzecz kontrahenta, stanowi koszt uzyskania przychodów.

## Udostępnianie do zwiedzania nie jest działalnością gospodarczą
 - [https://www.rp.pl/podatki-ksiegowosc-i-rachunkowosc/art39150241-udostepnianie-do-zwiedzania-nie-jest-dzialalnoscia-gospodarcza](https://www.rp.pl/podatki-ksiegowosc-i-rachunkowosc/art39150241-udostepnianie-do-zwiedzania-nie-jest-dzialalnoscia-gospodarcza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:00:00+00:00

Spółka jest zwolniona z podatku od nieruchomości, jeśli użytkowany przez nią budynek wpisany do rejestru zabytków jest utrzymywany i konserwowany zgodnie przepisami o ochronie zabytków i żadna z jego części nie jest zajęta na prowadzenie działalności gospodarczej.

## Wynajem pracowników z 23-proc. stawką VAT
 - [https://www.rp.pl/podatki/art39150261-wynajem-pracownikow-z-23-proc-stawka-vat](https://www.rp.pl/podatki/art39150261-wynajem-pracownikow-z-23-proc-stawka-vat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:00:00+00:00

Wypożyczanie pracowników między firmami jest dopuszczalne, jednak wymaga porozumienia między pracodawcami i zgody osób zatrudnionych.

## Zaliczka bez faktury
 - [https://www.rp.pl/podatki/art39150321-zaliczka-bez-faktury](https://www.rp.pl/podatki/art39150321-zaliczka-bez-faktury)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-25T00:00:00+00:00

Podatnik nie musi już wystawiać faktur zaliczkowych, jeżeli otrzyma całość lub część zapłaty w tym samym miesiącu, w którym dokonał dostawy towarów lub wykonał usługę.

