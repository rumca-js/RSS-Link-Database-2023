# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Red Dead Redemption 2 zmierza na Nintendo Switch? Brazylijczycy ocenili grę
 - [https://ithardware.pl/aktualnosci/red_dead_redemption_2_zmierza_na_nintendo_switch_brazylijczycy_ocenili_gre-29445.html](https://ithardware.pl/aktualnosci/red_dead_redemption_2_zmierza_na_nintendo_switch_brazylijczycy_ocenili_gre-29445.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T21:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/29445_1.jpg" />            Red Dead Redemption 2 może wreszcie trafić na Nintendo Switch, czego dowodzi klasyfikacja wiekowa, kt&oacute;rej dokonano w Brazylii. Czyżby Rockstar Games szykował port&nbsp;na nową platformę sprzętową?

Red Dead Redemption 2 podobno zmierza...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/red_dead_redemption_2_zmierza_na_nintendo_switch_brazylijczycy_ocenili_gre-29445.html">https://ithardware.pl/aktualnosci/red_dead_redemption_2_zmierza_na_nintendo_switch_brazylijczycy_ocenili_gre-29445.html</a></p>

## Sony i PlayStation zaatakowane przez cyberprzestępców? W ich ręce mogły wpaść wrażliwe dane
 - [https://ithardware.pl/aktualnosci/sony_i_playstation_zaatakowane_przez_cyberprzestepcow_w_ich_rece_mogly_wpasc_wrazliwe_dane-29443.html](https://ithardware.pl/aktualnosci/sony_i_playstation_zaatakowane_przez_cyberprzestepcow_w_ich_rece_mogly_wpasc_wrazliwe_dane-29443.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T19:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/29443_1.jpg" />            Sony i PlayStation mogą mieć problem. Jedna z grup hakerskich podaje, że ominęła zabezpieczenia firmy i uzyskała dostęp do system&oacute;w. Jakby tego było mało, cyberprzestępcy mają dane japońskiej korporacji i zamierzają je...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sony_i_playstation_zaatakowane_przez_cyberprzestepcow_w_ich_rece_mogly_wpasc_wrazliwe_dane-29443.html">https://ithardware.pl/aktualnosci/sony_i_playstation_zaatakowane_przez_cyberprzestepcow_w_ich_rece_mogly_wpasc_wrazliwe_dane-29443.html</a></p>

## Szef Sony krytykuje Xbox Game Pass. Gry single player nadal są fundamendem dla PlayStation
 - [https://ithardware.pl/aktualnosci/szef_sony_krytykuje_xbox_game_pass_gry_single_player_nadal_sa_fundamendem_dla_playstation-29442.html](https://ithardware.pl/aktualnosci/szef_sony_krytykuje_xbox_game_pass_gry_single_player_nadal_sa_fundamendem_dla_playstation-29442.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T16:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/29442_1.jpg" />            Do sieci trafił wywiad, kt&oacute;ry przeprowadzono z szefem Sony Jimem Ryanem. CEO korporacji odnosi się w nim do usługi Game Pass i plan&oacute;w odnośnie gier na PlayStation. Rozmowę przeprowadzono jednak w 2022 roku i od tamtej pory sporo mogło...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/szef_sony_krytykuje_xbox_game_pass_gry_single_player_nadal_sa_fundamendem_dla_playstation-29442.html">https://ithardware.pl/aktualnosci/szef_sony_krytykuje_xbox_game_pass_gry_single_player_nadal_sa_fundamendem_dla_playstation-29442.html</a></p>

## Game Pass zdrożeje w przyszłości? Według Phila Spencera jest to "nieuniknione"
 - [https://ithardware.pl/aktualnosci/game_pass_zdrozeje_w_przyszlosci_wedlug_phila_spencera_jest_to_nieuniknione-29441.html](https://ithardware.pl/aktualnosci/game_pass_zdrozeje_w_przyszlosci_wedlug_phila_spencera_jest_to_nieuniknione-29441.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T15:23:00+00:00

<img src="https://ithardware.pl/artykuly/min/29441_1.jpg" />            Game Pass podrożał w tym roku o około 2 USD i na tym podwyżki mogą się nie skończyć, o czym informuje szef marki Xbox Phil Spencer. Przedstawiciel Microsoftu przyznał, iż za usługę użytkownicy mogą w przyszłości zapłacić więcej niż...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/game_pass_zdrozeje_w_przyszlosci_wedlug_phila_spencera_jest_to_nieuniknione-29441.html">https://ithardware.pl/aktualnosci/game_pass_zdrozeje_w_przyszlosci_wedlug_phila_spencera_jest_to_nieuniknione-29441.html</a></p>

## MSI ogłasza pierwszy produkt w ramach „The Limited Series”. To karta graficzna GeForce RTX GAMING X
 - [https://ithardware.pl/aktualnosci/msi_oglasza_pierwszy_produkt_w_ramach_the_limited_series_to_karta_graficzna_geforce_rtx_gaming_x-29440.html](https://ithardware.pl/aktualnosci/msi_oglasza_pierwszy_produkt_w_ramach_the_limited_series_to_karta_graficzna_geforce_rtx_gaming_x-29440.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T14:08:30+00:00

<img src="https://ithardware.pl/artykuly/min/29440_1.jpg" />            MSI ogłasza pierwszy &bdquo;zrzut&rdquo; w ramach &bdquo;The Limited Series&rdquo;: kartę graficzną MSI GeForce RTX 4060 GAMING X 8G NV EDITION. Produkt wyznacza narodziny ekskluzywnej kolekcji, kt&oacute;ra wprowadza na rynek specjalne edycje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/msi_oglasza_pierwszy_produkt_w_ramach_the_limited_series_to_karta_graficzna_geforce_rtx_gaming_x-29440.html">https://ithardware.pl/aktualnosci/msi_oglasza_pierwszy_produkt_w_ramach_the_limited_series_to_karta_graficzna_geforce_rtx_gaming_x-29440.html</a></p>

## Resident Evil 4 na iPhony pojawił się w App Store. Są wymagania i data premiery
 - [https://ithardware.pl/aktualnosci/resident_evil_4_na_iphony_pojawil_sie_w_app_store_sa_wymagania_i_data_premiery-29439.html](https://ithardware.pl/aktualnosci/resident_evil_4_na_iphony_pojawil_sie_w_app_store_sa_wymagania_i_data_premiery-29439.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T13:31:40+00:00

<img src="https://ithardware.pl/artykuly/min/29439_1.jpg" />            Wychodzi na to, że jesteśmy coraz bliżej wejścia w nowym etap mobilnego gamingu. Podczas ostatniej konferencji, Apple pochwaliło się, że ich chip A17 Pro, w kt&oacute;ry wyposażone są iPhone 15 Pro i iPhone 15 Pro Max, jest w stanie poradzić...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/resident_evil_4_na_iphony_pojawil_sie_w_app_store_sa_wymagania_i_data_premiery-29439.html">https://ithardware.pl/aktualnosci/resident_evil_4_na_iphony_pojawil_sie_w_app_store_sa_wymagania_i_data_premiery-29439.html</a></p>

## Zwykły "androidowy" kabel USB-C może przegrzać nowego iPhone'a 15 Pro. Apple zaleca taki za 169 zł
 - [https://ithardware.pl/aktualnosci/zwykly_androidowy_kabel_usb_c_moze_przegrzac_nowego_iphone_a_15_pro_apple_zaleca_taki_a_169_zl-29438.html](https://ithardware.pl/aktualnosci/zwykly_androidowy_kabel_usb_c_moze_przegrzac_nowego_iphone_a_15_pro_apple_zaleca_taki_a_169_zl-29438.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T12:37:30+00:00

<img src="https://ithardware.pl/artykuly/min/29438_1.jpg" />            Apple podobno wprowadza podział kabli USB-C. Tych zwykłych nie można używać z iPhone'ami.&nbsp;

Apple znane jest z produkowania dużej ilości dodatk&oacute;w do swoich produkt&oacute;w oraz dość wysokich cen, kt&oacute;re trzeba za te...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/zwykly_androidowy_kabel_usb_c_moze_przegrzac_nowego_iphone_a_15_pro_apple_zaleca_taki_a_169_zl-29438.html">https://ithardware.pl/aktualnosci/zwykly_androidowy_kabel_usb_c_moze_przegrzac_nowego_iphone_a_15_pro_apple_zaleca_taki_a_169_zl-29438.html</a></p>

## Cyberpunk 2077 2.0 - Test kart graficznych. Starsze Radeony wciąż ubite?
 - [https://ithardware.pl/testyirecenzje/cyberpunk_2077_phantom_liberty_test_kart_graficznych-29427.html](https://ithardware.pl/testyirecenzje/cyberpunk_2077_phantom_liberty_test_kart_graficznych-29427.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T12:36:00+00:00

<img src="https://ithardware.pl/artykuly/min/29427_1.jpg" />            Cyberpunk 2077 z patchem 2.0 - test kart graficznych

Kilka dni temu zadebiutowała aktualizacja 2.0 do gry Cyberpunk 2077, a lada moment pojawi się także dodatek Phantom Liberty i z tego powodu przygotowałem test kart graficznych w odświeżonej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/cyberpunk_2077_phantom_liberty_test_kart_graficznych-29427.html">https://ithardware.pl/testyirecenzje/cyberpunk_2077_phantom_liberty_test_kart_graficznych-29427.html</a></p>

## Smartfony Galaxy S24 już w styczniu? Samsung ma przyspieszyć premierę
 - [https://ithardware.pl/aktualnosci/smartfony_galaxy_s24_juz_w_styczniu_samsung_ma_przyspieszyc_premiere-29437.html](https://ithardware.pl/aktualnosci/smartfony_galaxy_s24_juz_w_styczniu_samsung_ma_przyspieszyc_premiere-29437.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T12:24:00+00:00

<img src="https://ithardware.pl/artykuly/min/29437_1.jpg" />            Samsung może chcieć jak najszybciej rozpocząć rywalizację z niedawno wprowadzonymi iPhonami 15. Według nowych doniesień, produkcja części dla urządzeń z linii Galaxy S24 rozpocznie się już w przyszłym miesiącu. Co więcej, źr&oacute;dło...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/smartfony_galaxy_s24_juz_w_styczniu_samsung_ma_przyspieszyc_premiere-29437.html">https://ithardware.pl/aktualnosci/smartfony_galaxy_s24_juz_w_styczniu_samsung_ma_przyspieszyc_premiere-29437.html</a></p>

## iPhone'y 15 Pro docierają porysowane i z kurzem w aparacie. Co z kontrolą jakości?
 - [https://ithardware.pl/aktualnosci/iphone_y_15_pro_docieraja_porysowane_i_z_kurzem_w_aparacie_co_z_kontrola_jakosci-29436.html](https://ithardware.pl/aktualnosci/iphone_y_15_pro_docieraja_porysowane_i_z_kurzem_w_aparacie_co_z_kontrola_jakosci-29436.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T11:41:30+00:00

<img src="https://ithardware.pl/artykuly/min/29436_1.jpg" />            Niekt&oacute;rzy z pierwszych posiadaczy iPhone'a 15 Pro skarżą się na stan urządzeń. Część smartfon&oacute;w dotarła do klient&oacute;w z fabrycznymi defektami.

Klienci, kt&oacute;rzy kupili iPhone'a 15 Pro i iPhone'a 15 Pro Max...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/iphone_y_15_pro_docieraja_porysowane_i_z_kurzem_w_aparacie_co_z_kontrola_jakosci-29436.html">https://ithardware.pl/aktualnosci/iphone_y_15_pro_docieraja_porysowane_i_z_kurzem_w_aparacie_co_z_kontrola_jakosci-29436.html</a></p>

## Tecno Phantom V Flip - składany smartfon z klapką w przystępnej cenie
 - [https://ithardware.pl/aktualnosci/tecno_phantom_v_flip_skladany_smartfon_z_klapka_w_przystepnej_cenie-29433.html](https://ithardware.pl/aktualnosci/tecno_phantom_v_flip_skladany_smartfon_z_klapka_w_przystepnej_cenie-29433.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T11:21:01+00:00

<img src="https://ithardware.pl/artykuly/min/29433_1.jpg" />            Tecno mniej znana w naszym kraju chińska marka smartfon&oacute;w, kt&oacute;ra dopiero kilka miesięcy temu weszła na polski rynek. Ta zdaje się stosować dobrze sprawdzoną strategię, oferują solidne, ale przede wszystkim przystępne cenowo...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tecno_phantom_v_flip_skladany_smartfon_z_klapka_w_przystepnej_cenie-29433.html">https://ithardware.pl/aktualnosci/tecno_phantom_v_flip_skladany_smartfon_z_klapka_w_przystepnej_cenie-29433.html</a></p>

## Panos Panay - kulisy odejścia z Microsoftu
 - [https://ithardware.pl/aktualnosci/panos_panay_mial_odejsc_z_microsoftu_z_powodu_ciec_budzetowych-29432.html](https://ithardware.pl/aktualnosci/panos_panay_mial_odejsc_z_microsoftu_z_powodu_ciec_budzetowych-29432.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T10:42:01+00:00

<img src="https://ithardware.pl/artykuly/min/29432_1.jpg" />            Panos Panay nie był obecny na zeszłotygodniowym wydarzeniu Microsoftu w Nowym Jorku, ponieważ 18 września ogłoszono jego odejście z giganta z Redmond, a więc zaledwie trzy dni przed oficjalną prezentacją nowych produkt&oacute;w Surface. Powoli...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/panos_panay_mial_odejsc_z_microsoftu_z_powodu_ciec_budzetowych-29432.html">https://ithardware.pl/aktualnosci/panos_panay_mial_odejsc_z_microsoftu_z_powodu_ciec_budzetowych-29432.html</a></p>

## Microsoft wykorzysta modułowe reaktory jądrowe do zasilania swoich centrów danych
 - [https://ithardware.pl/aktualnosci/microsoft_wykorzysta_reaktory_jadrowe_do_zasilania_swoich_centrow_danych-29435.html](https://ithardware.pl/aktualnosci/microsoft_wykorzysta_reaktory_jadrowe_do_zasilania_swoich_centrow_danych-29435.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T10:31:30+00:00

<img src="https://ithardware.pl/artykuly/min/29435_1.jpg" />            Microsoft przygotowuje się do rewolucyjnych zmian w zakresie źr&oacute;dła zasilania swoich centr&oacute;w danych. Gigant technologiczny planuje wykorzystanie energii jądrowej w celu zminimalizowania zależności swoich centr&oacute;w danych od...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_wykorzysta_reaktory_jadrowe_do_zasilania_swoich_centrow_danych-29435.html">https://ithardware.pl/aktualnosci/microsoft_wykorzysta_reaktory_jadrowe_do_zasilania_swoich_centrow_danych-29435.html</a></p>

## SpaceX przeprowadza test silnika w ekstremalnie niskiej temperaturze. Astronauci wrócą na Księżyc
 - [https://ithardware.pl/aktualnosci/spacex_przeprowadza_test_silnika_w_ekstremalnie_niskiej_temperaturze_astronauci_wroca_na_ksiezyc-29434.html](https://ithardware.pl/aktualnosci/spacex_przeprowadza_test_silnika_w_ekstremalnie_niskiej_temperaturze_astronauci_wroca_na_ksiezyc-29434.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T09:05:40+00:00

<img src="https://ithardware.pl/artykuly/min/29434_1.jpg" />            Lądowanie człowieka na Księżycu jest planowane w ramach misji Artemis III. W tym celu wykorzystywana będzie zmodyfikowana wersja statku kosmicznego Starship (wariant HLS). Dlatego też w firmie SpaceX obecnie trwają prace rozwojowe i testy. Jednym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/spacex_przeprowadza_test_silnika_w_ekstremalnie_niskiej_temperaturze_astronauci_wroca_na_ksiezyc-29434.html">https://ithardware.pl/aktualnosci/spacex_przeprowadza_test_silnika_w_ekstremalnie_niskiej_temperaturze_astronauci_wroca_na_ksiezyc-29434.html</a></p>

## Masowe wymieranie na rynku smartfonów. Dramatyczne statystyki
 - [https://ithardware.pl/aktualnosci/masowe_wymieranie_na_rynku_smartfonow_dramatyczne_statystyki-29430.html](https://ithardware.pl/aktualnosci/masowe_wymieranie_na_rynku_smartfonow_dramatyczne_statystyki-29430.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T09:05:02+00:00

<img src="https://ithardware.pl/artykuly/min/29430_1.jpg" />            Od 2017 roku rynek smartfon&oacute;w opuściło kilka naprawdę znaczących firm i wystarczy tylko wspomnieć o LG. Mało kto zdaje sobie jednak sprawę, że łącznie było ich blisko 500!

Dramatyczny spadek

Z analizy Counterpoint Research wynika,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/masowe_wymieranie_na_rynku_smartfonow_dramatyczne_statystyki-29430.html">https://ithardware.pl/aktualnosci/masowe_wymieranie_na_rynku_smartfonow_dramatyczne_statystyki-29430.html</a></p>

## Samsung przypadkiem ujawnia Galaxy S23 FE, Tab S9 FE i Buds FE
 - [https://ithardware.pl/aktualnosci/samsung_przypadkiem_ujawnia_galaxy_s23_fe_tab_s9_fe_i_buds_fe-29429.html](https://ithardware.pl/aktualnosci/samsung_przypadkiem_ujawnia_galaxy_s23_fe_tab_s9_fe_i_buds_fe-29429.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T08:10:01+00:00

<img src="https://ithardware.pl/artykuly/min/29429_1.jpg" />            Odwiedzający argentyńską stronę Samsunga dostrzegli coś nieco nieoczekiwanego &mdash; stronę produktową nowych słuchawek dousznych Galaxy Buds FE wraz ze zdjęciami smartfona Galaxy S23 FE i tabletu Galaxy Tab S9 FE.&nbsp;

Nowe urządzenia Fan...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_przypadkiem_ujawnia_galaxy_s23_fe_tab_s9_fe_i_buds_fe-29429.html">https://ithardware.pl/aktualnosci/samsung_przypadkiem_ujawnia_galaxy_s23_fe_tab_s9_fe_i_buds_fe-29429.html</a></p>

## Intel zmienia zdanie? Meteor Lake potwierdzony dla desktopów
 - [https://ithardware.pl/aktualnosci/intel_zmienia_zdanie_meteor_lake_potwierdzony_dla_desktopow-29428.html](https://ithardware.pl/aktualnosci/intel_zmienia_zdanie_meteor_lake_potwierdzony_dla_desktopow-29428.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T07:40:40+00:00

<img src="https://ithardware.pl/artykuly/min/29428_1.jpg" />            Od miesięcy docierają do nas r&oacute;żne, często sprzeczne informacje na temat procesor&oacute;w Intel Meteor Lake dla komputer&oacute;w stacjonarnych. Najczęściej słyszeliśmy, że te CPU zostały skasowane, ale gigant z Santa Clara postanowił...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_zmienia_zdanie_meteor_lake_potwierdzony_dla_desktopow-29428.html">https://ithardware.pl/aktualnosci/intel_zmienia_zdanie_meteor_lake_potwierdzony_dla_desktopow-29428.html</a></p>

## Te promocje wymiatają! Do 44% rabatu na sprzęty podczas Wyprzedaży kwartalnej w x-komie
 - [https://ithardware.pl/aktualnosci/te_promocje_wymiataja_do_44_rabatu_na_sprzety_podczas_wyprzedazy_kwartalnej_w_x_komie-29426.html](https://ithardware.pl/aktualnosci/te_promocje_wymiataja_do_44_rabatu_na_sprzety_podczas_wyprzedazy_kwartalnej_w_x_komie-29426.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-25T05:30:02+00:00

<img src="https://ithardware.pl/artykuly/min/29426_1.jpg" />            Na brak dobrych promocji w x-komie nigdy nie można narzekać. Właśnie ruszyła Wyprzedaż kwartalna, w kt&oacute;rej zebrano produkty z r&oacute;żnych kategorii, a ich ceny zostały obniżone nawet do 44%. Opr&oacute;cz tego można złapać rabaty na...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/te_promocje_wymiataja_do_44_rabatu_na_sprzety_podczas_wyprzedazy_kwartalnej_w_x_komie-29426.html">https://ithardware.pl/aktualnosci/te_promocje_wymiataja_do_44_rabatu_na_sprzety_podczas_wyprzedazy_kwartalnej_w_x_komie-29426.html</a></p>

