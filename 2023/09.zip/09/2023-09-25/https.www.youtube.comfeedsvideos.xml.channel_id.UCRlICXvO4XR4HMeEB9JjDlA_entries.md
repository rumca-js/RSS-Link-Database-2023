# Source:Thoughty2, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA, language:en-US

## This Strange Creature Lives Forever
 - [https://www.youtube.com/watch?v=jbqs_GUU-Fs](https://www.youtube.com/watch?v=jbqs_GUU-Fs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA
 - date published: 2023-09-25T15:02:18+00:00

Get an exclusive Surfshark deal! Enter promo code THOUGHTY2 for an extra 3 months free at https://surfshark.deals/THOUGHTY2

Thoughty2 Audiobook: https://geni.us/t2audio
Thoughty2 Book: https://geni.us/t2book
Support Me & Get Early Access: http://bit.ly/t2club
Thoughty2 Merchandise: https://bit.ly/t2merch

Follow Thoughty2
Facebook: https://facebook.com/thoughty2
Instagram: https://instagram.com/thoughty2
Website: http://thoughty2.com

About Thoughty2
Thoughty2 (Arran) is a British YouTuber and gatekeeper of useless facts. Thoughty2 creates mind-blowing factual videos about science, tech, history, opinion and just about everything else.
#Thoughty2

Editing: Jack Stevens

