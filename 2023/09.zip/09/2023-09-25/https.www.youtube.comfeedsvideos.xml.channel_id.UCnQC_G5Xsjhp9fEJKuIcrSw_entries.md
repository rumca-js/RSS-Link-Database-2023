# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## 2005 Domino's Pizza Commercial With Donald Trump
 - [https://www.youtube.com/watch?v=QJKtg6EkKg0](https://www.youtube.com/watch?v=QJKtg6EkKg0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-25T23:00:11+00:00



## Doug Brunt: The Mysterious Case of Rudolf Diesel
 - [https://www.youtube.com/watch?v=3Uu3jmD8kwE](https://www.youtube.com/watch?v=3Uu3jmD8kwE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-25T21:00:01+00:00

My interview with author and historian, Doug Brunt. His new book, "The Mysterious Case of Rudolf Diesel", goes through the hidden history of one of the world’s greatest inventors, a man who disrupted the status quo and then disappeared into thin air on the eve of World War I. This book answers the hundred-year-old mystery of what really became of Rudolf Diesel.

https://douglasbrunt-author.com/

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1811 - https://youtu.be/lz99fXDsL8g

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Go to https://expressvpn.com/benYT and find out how you can get 3 months of ExpressVPN free!

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #DouglasBrunt #Interview #Interviews

## Oracle Violating Civil Rights
 - [https://www.youtube.com/watch?v=p-6L83p1hGI](https://www.youtube.com/watch?v=p-6L83p1hGI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-25T19:00:31+00:00



## Best Of Ben Shapiro's Woke TikTok Reactions
 - [https://www.youtube.com/watch?v=n4JXO6EGh9c](https://www.youtube.com/watch?v=n4JXO6EGh9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-25T17:00:35+00:00

The cringiest segments from my Woke TikTok series. Watch at your own risk. 

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Exclusive discount for my listeners! https://genucel.com/Shapiro 

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire

