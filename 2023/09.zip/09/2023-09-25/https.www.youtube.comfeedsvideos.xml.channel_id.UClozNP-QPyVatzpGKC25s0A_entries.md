# Source:Brad Colbow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A, language:en-US

## Wacom One 13 Touch Review
 - [https://www.youtube.com/watch?v=VXtQvhrV6WY](https://www.youtube.com/watch?v=VXtQvhrV6WY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A
 - date published: 2023-09-25T13:38:31+00:00

NEW COURSES: http://bradsartschool.com

Wacom released several new products over the last month or so. This is the 4th and final one, it's positioned to be a budget priced touch tablet. 

Wacom One Pressure Breakdown: https://www.youtube.com/watch?v=415ngQOHiME

Email Newsletter: http://brad.site/signup/

-----------------------------------------------------

Twitter: 
https://twitter.com/bradcolbow

Instagram:
https://www.instagram.com/brad.colbow/

Drawing Tech Top 10 lists:
http://brad.site/

My Drawing and video gear: 
http://brad.site/mygear/

