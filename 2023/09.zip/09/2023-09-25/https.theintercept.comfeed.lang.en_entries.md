# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Washington Post Completely Botches Chaturbate Rules in Virginia Candidate Takedown
 - [https://theintercept.com/2023/09/25/chaturbate-susanna-gibson-washington-post/](https://theintercept.com/2023/09/25/chaturbate-susanna-gibson-washington-post/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-09-25T18:05:55+00:00

<p>The article about Susanna Gibson, a Democrat running in a crucial legislative district, bore the telltale signs of an opposition research dump.</p>
<p>The post <a href="https://theintercept.com/2023/09/25/chaturbate-susanna-gibson-washington-post/" rel="nofollow">Washington Post Completely Botches Chaturbate Rules in Virginia Candidate Takedown</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## NYPD “Transparency” Site Leaves Out Misconduct Lawsuits Settled for Millions
 - [https://theintercept.com/2023/09/25/nypd-misconduct-lawsuits-settlements/](https://theintercept.com/2023/09/25/nypd-misconduct-lawsuits-settlements/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-09-25T10:00:00+00:00

<p>The New York Police Department touts the “transparency” of its officer database, but you’d never know about cops who rack up dozens of lawsuits and millions in payouts.</p>
<p>The post <a href="https://theintercept.com/2023/09/25/nypd-misconduct-lawsuits-settlements/" rel="nofollow">NYPD “Transparency” Site Leaves Out Misconduct Lawsuits Settled for Millions</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

