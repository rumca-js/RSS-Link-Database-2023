# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## This Is Important
 - [https://www.youtube.com/watch?v=SyMhBeV4lg8](https://www.youtube.com/watch?v=SyMhBeV4lg8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-09-25T17:32:26+00:00

The State and legacy media war on free speech is in full swing.

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

Support Me Directly HERE: https://rb.rumble.com

## ARE WE BEING SILENCED!? The Battle For Free Speech! Plus, Jimmy Dore - Stay Free #209 PREVIEW
 - [https://www.youtube.com/watch?v=tu-7_NfXl-I](https://www.youtube.com/watch?v=tu-7_NfXl-I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-09-25T15:02:14+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me live and exclusively over on RUMBLE:
https://bit.ly/Stay-Free-209-Free-Speech

TODAY - Did NATO’s expansion play a pivotal role in triggering Russia’s invasion of Ukraine? Plus, Biden’s disapproval rating hits its highest mark of his presidency, why was Rumble’s live stream of the Republican Debate buried in a Google search? And our special guest is investigative journalist Aaron Maté from The Grayzone.

--------------------------------------------------------------------------------------------------------------------------

FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand
5:00PM BST | 12:00 PM EDT | 9:00AM PDT

Support this channel directly here: https://rb.rumble.com/

