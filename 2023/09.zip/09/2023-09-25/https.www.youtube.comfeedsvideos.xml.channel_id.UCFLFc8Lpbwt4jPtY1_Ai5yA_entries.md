# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## Xbox Leaks Everything
 - [https://www.youtube.com/watch?v=kQMBi6trfmc](https://www.youtube.com/watch?v=kQMBi6trfmc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-09-25T23:21:12+00:00

There’s been a massive leak of internal Xbox documents, including potential games and hardware and fantasies of future business acquisitions like Valve and Nintendo. 

Watch the full WAN Show: https://www.youtube.com/watch?v=EreRkDMIn6A&amp;list=PL8mG-RkN2uTw7PhlnAr4pZZz2QubIbujH&amp;index=1

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## Native Res Gaming is Dead
 - [https://www.youtube.com/watch?v=11QM14ICuPU](https://www.youtube.com/watch?v=11QM14ICuPU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-09-25T23:21:07+00:00

Nvidia releases DLSS 3.5 -- and says that native resolution is out, AI-upscaling is in. 

Watch the full WAN Show: https://www.youtube.com/watch?v=EreRkDMIn6A&amp;list=PL8mG-RkN2uTw7PhlnAr4pZZz2QubIbujH&amp;index=1

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

