# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Ford pausing construction of Michigan battery plant amid contract talks with auto workers union
 - [https://abcnews.go.com/Business/wireStory/ford-pausing-construction-michigan-battery-plant-amid-contract-103478356](https://abcnews.go.com/Business/wireStory/ford-pausing-construction-michigan-battery-plant-amid-contract-103478356)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T23:02:27+00:00

Construction paused until Ford is sure it can run the factory competitively.

## Video shows California deputy slamming 16-year-old girl to the ground
 - [https://abcnews.go.com/US/wireStory/video-shows-california-deputy-slamming-16-year-girl-103476778](https://abcnews.go.com/US/wireStory/video-shows-california-deputy-slamming-16-year-girl-103476778)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T21:01:43+00:00

A video shows a Southern California sheriff&rsquo;s deputy slamming a teenage girl to the ground during a fight outside a Friday night high school football game

## Manslaughter charges thrown out in Michigan prisoner's death
 - [https://abcnews.go.com/US/wireStory/manslaughter-charges-thrown-michigan-prisoners-death-103475247](https://abcnews.go.com/US/wireStory/manslaughter-charges-thrown-michigan-prisoners-death-103475247)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T21:01:21+00:00

A judge has dismissed charges against six people in the death of a Michigan prisoner who lost 50 pounds over two weeks and died of dehydration while being restrained

## US military captures key Islamic State militant during helicopter raid in Syria
 - [https://abcnews.go.com/US/wireStory/us-military-captures-key-islamic-state-militant-helicopter-103475795](https://abcnews.go.com/US/wireStory/us-military-captures-key-islamic-state-militant-helicopter-103475795)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T20:55:18+00:00

The U.S. military says it has captured an operator for the Islamic State extremist group during a helicopter raid in northern Syria

## Firefighter's 3-year-old son struck, killed at memorial walk for slain firefighters
 - [https://abcnews.go.com/US/wireStory/firefighters-3-year-son-struck-killed-memorial-walk-103476247](https://abcnews.go.com/US/wireStory/firefighters-3-year-son-struck-killed-memorial-walk-103476247)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T20:50:34+00:00

Authorities say the 3-year-old son of a firefighter was struck and killed in Delaware over the weekend shortly before a memorial walk was to begin to honor three firefighters killed in a blaze seven years ago

## Uber Eats to accept SNAP benefits for groceries following announcement from Instacart
 - [https://abcnews.go.com/GMA/Food/uber-eats-accept-snap-benefits-groceries-announcement-instacart/story?id=103461506](https://abcnews.go.com/GMA/Food/uber-eats-accept-snap-benefits-groceries-announcement-instacart/story?id=103461506)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T20:35:14+00:00

Grocers and shoppers who rely on the Supplemental Nutrition Assistance Program, or SNAP, will soon be able to access benefits using more online grocery services.

## 3rd person arrested in fentanyl day care case, search continues for owner's husband
 - [https://abcnews.go.com/US/3rd-person-arrested-bronx-fentanyl-day-care-case/story?id=103475902](https://abcnews.go.com/US/3rd-person-arrested-bronx-fentanyl-day-care-case/story?id=103475902)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T20:21:13+00:00

A third person has been arrested in connection with the New York City day care drug operation that resulted in the death of a 1-year-old boy.

## 17-year-old allegedly shoots, kills 3 other teens
 - [https://abcnews.go.com/US/17-year-gunman-allegedly-kills-3-teens-injures/story?id=103471309](https://abcnews.go.com/US/17-year-gunman-allegedly-kills-3-teens-injures/story?id=103471309)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T19:38:17+00:00

A South Carolina community is reeling in the wake of a shooting that killed three teenagers and injured a fourth.

## 8 hospitalized after JetBlue flight experiences 'sudden severe turbulence'
 - [https://abcnews.go.com/US/8-hospitalized-after-jetblue-flight-experiences-sudden-severe/story?id=103469035](https://abcnews.go.com/US/8-hospitalized-after-jetblue-flight-experiences-sudden-severe/story?id=103469035)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T19:20:43+00:00

8 hospitalized after JetBlue flight experiences "sudden severe turbulence"

## Raiders' Garoppolo is in concussion protocol, putting his start for game in question
 - [https://abcnews.go.com/Sports/wireStory/raiders-garoppolo-concussion-protocol-putting-start-chargers-game-103473347](https://abcnews.go.com/Sports/wireStory/raiders-garoppolo-concussion-protocol-putting-start-chargers-game-103473347)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T18:57:59+00:00

Las Vegas Raiders quarterback Jimmy Garoppolo is in concussion protocol

## Journalist killed in attack aimed at police in northern Mexico border town
 - [https://abcnews.go.com/International/wireStory/journalist-killed-attack-aimed-police-northern-mexico-border-103471460](https://abcnews.go.com/International/wireStory/journalist-killed-attack-aimed-police-northern-mexico-border-103471460)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T18:54:56+00:00

A journalist who ran a community Facebook news page has been killed in the northern Mexico border town of San Luis Rio Colorado, when he was apparently caught in the cross-fire of an attack aimed at police

## Large explosion as thousands of ethnic Armenians flee disputed enclave
 - [https://abcnews.go.com/International/thousands-flee-disputed-enclave-azerbaijan-after-ethnic-armenians/story?id=103459172](https://abcnews.go.com/International/thousands-flee-disputed-enclave-azerbaijan-after-ethnic-armenians/story?id=103459172)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T18:52:58+00:00

Armenian authorities say they are prepared for tens of thousands of families to flee.

## Megan Rapinoe plays final US Women's National Team game
 - [https://abcnews.go.com/GMA/Living/megan-rapinoe-bids-farewell-international-soccer-final-uswnt/story?id=103466717](https://abcnews.go.com/GMA/Living/megan-rapinoe-bids-farewell-international-soccer-final-uswnt/story?id=103466717)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T18:30:38+00:00

Team USA scored a victory against South Africa in Rapinoe's final game.

## Bill would criminalize 'extremely harmful' online 'deepfakes’
 - [https://abcnews.go.com/Politics/bill-criminalize-extremely-harmful-online-deepfakes/story?id=103286802](https://abcnews.go.com/Politics/bill-criminalize-extremely-harmful-online-deepfakes/story?id=103286802)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T18:22:09+00:00

Deepfake legislation from Rep. Yvette Clarke seeks to protect individuals nationwide from being misrepresented by certain kinds of digital content

## What you need to know about California's CARE Court program
 - [https://abcnews.go.com/Health/californias-care-court-program-tackle-mental-illness-starts/story?id=103461370](https://abcnews.go.com/Health/californias-care-court-program-tackle-mental-illness-starts/story?id=103461370)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T18:15:06+00:00

California's new CARE Court program to help those with serous, untreated mental health issues starts next month -- and is mired in controversy. Here's what to know.

## Sen. Bob Menendez, facing corruption charges, rebuffs calls for his resignation
 - [https://abcnews.go.com/Politics/sen-bob-menendez-facing-corruption-charges-rebuffs-calls/story?id=103463381](https://abcnews.go.com/Politics/sen-bob-menendez-facing-corruption-charges-rebuffs-calls/story?id=103463381)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T16:06:03+00:00

Sen. Bob Menendez on Monday delivered his first public remarks after being indicted on corruption charges.

## Driver pleads not guilty in Vermont crash that killed actor Treat Williams
 - [https://abcnews.go.com/Entertainment/wireStory/driver-pleads-guilty-vermont-crash-killed-actor-treat-103465783](https://abcnews.go.com/Entertainment/wireStory/driver-pleads-guilty-vermont-crash-killed-actor-treat-103465783)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T15:25:58+00:00

A Vermont driver has pleaded not guilty to a charge in the June crash that killed actor Treat Williams

## FDA skeptical of experimental ALS treatment pushed by patient advocates
 - [https://abcnews.go.com/US/wireStory/fda-skeptical-experimental-als-treatment-pushed-patient-advocates-103464288](https://abcnews.go.com/US/wireStory/fda-skeptical-experimental-als-treatment-pushed-patient-advocates-103464288)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T15:10:09+00:00

The Food and Drug Administration meets this week to consider a much-debated treatment for Lou Gehrig&rsquo;s disease

## Biden administration announces $1.4 billion to improve rail safety and boost capacity
 - [https://abcnews.go.com/US/wireStory/biden-administration-announces-14-billion-improve-rail-safety-103458058](https://abcnews.go.com/US/wireStory/biden-administration-announces-14-billion-improve-rail-safety-103458058)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T14:38:17+00:00

The Biden administration has awarded $1.4 billion to projects improving railway safety and boosting rail capacity

## Monday night's $785M Powerball jackpot is 9th largest lottery prize
 - [https://abcnews.go.com/Entertainment/wireStory/monday-nights-785m-powerball-jackpot-9th-largest-lottery-103463370](https://abcnews.go.com/Entertainment/wireStory/monday-nights-785m-powerball-jackpot-9th-largest-lottery-103463370)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T13:31:56+00:00

The ninth-largest lottery jackpot will be on the line when numbers are drawn for a $785 million Powerball prize

## Former UK nurse will be retried on charge she tried to murder baby girl at hospital
 - [https://abcnews.go.com/International/wireStory/former-uk-nurse-retried-charge-murder-baby-girl-103462368](https://abcnews.go.com/International/wireStory/former-uk-nurse-retried-charge-murder-baby-girl-103462368)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T13:28:58+00:00

A former neonatal nurse who was sentenced to life in prison for the murder of seven babies in her care and trying to kill six others at a U.K. hospital will face a retrial on a charge of attempting to murder a newborn baby girl

## Steelers' team plane makes emergency landing in Kansas City
 - [https://abcnews.go.com/Sports/wireStory/steelers-team-plane-makes-emergency-landing-kansas-city-103461366](https://abcnews.go.com/Sports/wireStory/steelers-team-plane-makes-emergency-landing-kansas-city-103461366)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T12:29:12+00:00

The Pittsburgh Steelers&rsquo; charter flight home following a Sunday night win in Las Vegas made an emergency landing in Kansas City early Monday

## Film legend Sophia Loren has successful surgery after fracturing a leg in a fall
 - [https://abcnews.go.com/Entertainment/wireStory/film-legend-sophia-loren-successful-surgery-after-fracturing-103460634](https://abcnews.go.com/Entertainment/wireStory/film-legend-sophia-loren-successful-surgery-after-fracturing-103460634)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T12:06:18+00:00

The Italian actor is recovering from successful surgery.

## London's armed officers protest murder charge for colleague
 - [https://abcnews.go.com/International/wireStory/londons-top-cop-seeks-protections-police-armed-officers-103458939](https://abcnews.go.com/International/wireStory/londons-top-cop-seeks-protections-police-armed-officers-103458939)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T12:01:36+00:00

The head of London&rsquo;s police force is calling for increased legal protections for officers who use force in the line of duty after more than 100 officers refused to carry guns to protest murder charges filed against one of their colleagues

## Macron to unveil latest plan for meeting climate-related goals in the coming years
 - [https://abcnews.go.com/International/wireStory/frances-macron-unveil-latest-plan-meeting-climate-related-103459755](https://abcnews.go.com/International/wireStory/frances-macron-unveil-latest-plan-meeting-climate-related-103459755)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T11:58:27+00:00

President Emmanuel Macron is preparing to reveal how France plans to reduce greenhouse gas emissions and meet the country&rsquo;s climate-related commitments within the next seven years

## 'Just in shock': Dock worker assaulted in Alabama brawl speaks out in 'GMA' exclusive
 - [https://abcnews.go.com/GMA/News/dock-worker-assaulted-montgomery-brawl-speaks-gma-exclusive/story?id=103410127](https://abcnews.go.com/GMA/News/dock-worker-assaulted-montgomery-brawl-speaks-gma-exclusive/story?id=103410127)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T11:48:47+00:00

After a brawl at Riverfront Park in Montgomery, Alabama went viral, Dameion Pickett, who was at the center of the incident, is speaking out in an interview with "GMA."

## US border agency chief meets with authorities in Mexico over migrant surge
 - [https://abcnews.go.com/International/us-mexico-border-cbp-meeting-migrant-surge/story?id=103456837](https://abcnews.go.com/International/us-mexico-border-cbp-meeting-migrant-surge/story?id=103456837)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T11:29:12+00:00

Acting CBP Commissioner Troy Miller traveled to Ciudad Juarez, Mexico, on Friday, where he met with Mexican officials and railway industry leaders.

## WATCH:  Riders get stuck upside down on broken fairground ride
 - [https://abcnews.go.com/International/video/riders-stuck-upside-broken-fairground-ride-103459554](https://abcnews.go.com/International/video/riders-stuck-upside-broken-fairground-ride-103459554)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T11:06:25+00:00

Riders at a Canadian amusement park got stuck upside down on a ride for nearly 30 minutes on Saturday.

## A statue of late cardinal accused of abuse removed from outside a German cathedral
 - [https://abcnews.go.com/International/wireStory/statue-late-cardinal-accused-sexual-abuse-removed-german-103457430](https://abcnews.go.com/International/wireStory/statue-late-cardinal-accused-sexual-abuse-removed-german-103457430)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T09:31:00+00:00

A statue of a deceased German cardinal has been removed from its perch outside Essen Cathedral in western Germany, days after allegations of sexual abuse decades ago became public

## On the run for decades, convicted Mafia boss Messina Denaro dies in hospital
 - [https://abcnews.go.com/International/wireStory/run-decades-convicted-mafia-boss-messina-denaro-dies-103456836](https://abcnews.go.com/International/wireStory/run-decades-convicted-mafia-boss-messina-denaro-dies-103456836)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T09:02:32+00:00

Italian prosecutors say that Matteo Messina Denaro, a convicted mastermind of some of the Sicilian Mafia&rsquo;s most heinous slayings, has died in a hospital prison ward, months after being captured

## Molotov cocktails tossed at Cuban Embassy in Washington, minister says
 - [https://abcnews.go.com/International/molotov-cocktails-tossed-cuban-embassy-washington-minister/story?id=103457331](https://abcnews.go.com/International/molotov-cocktails-tossed-cuban-embassy-washington-minister/story?id=103457331)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T08:52:47+00:00

The Cuban embassy staff "suffered no harm," and "details are being worked out," Foreign Affairs Minister Bruno Rodríguez Parrilla said.

## Megan Rapinoe gets triumphant send-off as United States beats South Africa 2-0
 - [https://abcnews.go.com/Sports/wireStory/megan-rapinoe-gets-triumphant-send-off-united-states-103453987](https://abcnews.go.com/Sports/wireStory/megan-rapinoe-gets-triumphant-send-off-united-states-103453987)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T07:00:58+00:00

Megan Rapinoe got a triumphant send-off, and the United States beat South Africa 2-0

## North Korea calls South's leader a 'guy with a trash-like brain' as it slams his UN speech
 - [https://abcnews.go.com/International/wireStory/north-korea-calls-souths-leader-guy-trash-brain-103455135](https://abcnews.go.com/International/wireStory/north-korea-calls-souths-leader-guy-trash-brain-103455135)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T06:57:23+00:00

North Korea calls South Korean president &ldquo;a guy with a trash-like brain.&quot;

## Hollywood writers reach 'tentative' deal with studios, end monthslong strike
 - [https://abcnews.go.com/Business/hollywood-writers-reach-deal-studios-end-monthslong-strike/story?id=103374383](https://abcnews.go.com/Business/hollywood-writers-reach-deal-studios-end-monthslong-strike/story?id=103374383)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T02:49:13+00:00

The strike spanned 146 days and brought pickets to productions nationwide.

## Kidnapped teen rescued from Southern California motel room after 4 days of being held hostage
 - [https://abcnews.go.com/US/wireStory/kidnapped-teen-rescued-southern-california-motel-room-after-103453603](https://abcnews.go.com/US/wireStory/kidnapped-teen-rescued-southern-california-motel-room-after-103453603)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-09-25T00:16:28+00:00

He was held hostage for four days by captors who demanded a $500,000 ransom.

