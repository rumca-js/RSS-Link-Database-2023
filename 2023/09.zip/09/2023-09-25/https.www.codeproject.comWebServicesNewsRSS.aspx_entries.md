# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## Announcing the GitHub Innovation Graph
 - [https://github.blog/2023-09-21-announcing-the-github-innovation-graph/](https://github.blog/2023-09-21-announcing-the-github-innovation-graph/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

Why do work when you can just look to see how everyone else is working?

## Back away
 - [https://www.smbc-comics.com/comic/back-away](https://www.smbc-comics.com/comic/back-away)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00



## Bowing to pressure, Unity announces the terms of its surrender
 - [https://www.engadget.com/bowing-to-pressure-unity-announces-the-terms-of-its-surrender-193422770.html](https://www.engadget.com/bowing-to-pressure-unity-announces-the-terms-of-its-surrender-193422770.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

"Sorry seems to be the hardest word"

## Devs demand Visual Studio 2022 ditch old .NET Framework dependencies
 - [https://visualstudiomagazine.com/articles/2023/09/22/vs-2022-net-framework.aspx](https://visualstudiomagazine.com/articles/2023/09/22/vs-2022-net-framework.aspx)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

Upgrade for thee, but not for me

## GitHub CEO: Despite AI gains, demand for software developers will still outweigh supply
 - [https://techcrunch.com/2023/09/20/github-ceo-despite-ai-gains-demand-for-software-developers-will-still-outweigh-supply/](https://techcrunch.com/2023/09/20/github-ceo-despite-ai-gains-demand-for-software-developers-will-still-outweigh-supply/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

"You never get away, everybody wants you"

## How to diagnose hardware issues?
 - [https://www.codeproject.com/Messages/5963927/How-to-diagnose-hardware-issues](https://www.codeproject.com/Messages/5963927/How-to-diagnose-hardware-issues)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

It's just the universe telling you to buy a new machine

## Looking for a free screenshot software
 - [https://www.codeproject.com/Messages/5963925/look-for-a-free-screenshot-software](https://www.codeproject.com/Messages/5963925/look-for-a-free-screenshot-software)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

"Could you wanna take my picture? 'Cause I won't remember"

## Mathematicians find 12,000 new solutions to 'unsolvable' 3-body problem
 - [https://www.space.com/mathematicians-unsolvable-3-body-problem-12000-solutions](https://www.space.com/mathematicians-unsolvable-3-body-problem-12000-solutions)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

I guess they'll have to rename the book?

## Microsoft aims on ‘building the passwordless future’
 - [https://www.onmsft.com/news/the-passwordless-future/](https://www.onmsft.com/news/the-passwordless-future/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

So now what? I write my fingerprints and iris scan on a yellow stickie on the machine?

## Orgs now getting the new Outlook for Windows
 - [https://rcpmag.com/articles/2023/09/22/new-outlook-for-windows-ga-preview.aspx](https://rcpmag.com/articles/2023/09/22/new-outlook-for-windows-ga-preview.aspx)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

The outlook is for more Outlook

## Tune into the C# Certification Training Series
 - [https://devblogs.microsoft.com/dotnet/csharp-certification-training-series/](https://devblogs.microsoft.com/dotnet/csharp-certification-training-series/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-09-25T04:00:00+00:00

I hear it's all the rage

