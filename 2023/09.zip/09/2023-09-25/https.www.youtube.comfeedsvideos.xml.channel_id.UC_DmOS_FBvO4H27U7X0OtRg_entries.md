# Source:Fearless & Far, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_DmOS_FBvO4H27U7X0OtRg, language:en-US

## Hunting With The Hadza Tribe!
 - [https://www.youtube.com/watch?v=FpXkGWH-O1E](https://www.youtube.com/watch?v=FpXkGWH-O1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_DmOS_FBvO4H27U7X0OtRg
 - date published: 2023-09-25T15:00:14+00:00

Watch the Full Video: https://youtu.be/U2Szbfq9IA4

The Hadza Tribe or Hadzabe are a remote African Tribe of Hunter-Gatherers in Tanzania.
They live off a diet of plants and animals, eating only what they catch. There are only about 1200 left in existence, and of those, only 400 live traditionally. The Hadza tribe we hunt with are of this small group.

