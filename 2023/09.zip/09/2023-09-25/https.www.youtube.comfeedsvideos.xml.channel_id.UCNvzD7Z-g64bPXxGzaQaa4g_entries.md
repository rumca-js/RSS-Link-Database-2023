# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Cyberpunk 2077 Phantom Liberty - Before You Buy
 - [https://www.youtube.com/watch?v=7FA6nSb1DJQ](https://www.youtube.com/watch?v=7FA6nSb1DJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-09-25T19:59:04+00:00

Cyberpunk 2077 2.0 and DLC expansion Phantom Liberty are now releasing for PC, PS5 and Xbox Series X/S. How is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼

Buy Cyberpunk 2077: https://amzn.to/3EPALdN
 

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#phantomliberty

