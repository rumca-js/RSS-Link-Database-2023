# Source:Drew Gooden, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTSRIY3GLFYIpkR2QwyeklA, language:en-US

## I bought the shoes that make you walk faster
 - [https://www.youtube.com/watch?v=_9Z05Ik5r2U](https://www.youtube.com/watch?v=_9Z05Ik5r2U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTSRIY3GLFYIpkR2QwyeklA
 - date published: 2023-09-25T18:16:05+00:00

Sponsored by HelloFresh. For 50% off with HelloFresh PLUS free shipping, use code 50IMALITTLESTINKER at https://bit.ly/456xnqo

thanks so much to @jarvis, @JordanAdika, and @EddyBurback for helping me out with this and being guinea pigs for content.

merch:
https://www.drewgoodenshop.com/

follow me:
twitter - https://www.twitter.com/drewisgooden
instagram - https://www.instagram.com/drewisgooden

