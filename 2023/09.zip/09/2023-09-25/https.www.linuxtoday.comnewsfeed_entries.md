# Source:Linux Today News, URL:https://www.linuxtoday.com/news/feed, language:en-US

## KaOS Linux 2023.09 Adds KDE Gear 23.08, Focus to Shift on KDE Plasma 6 ISO
 - [https://www.linuxtoday.com/news/kaos-linux-2023-09-adds-kde-gear-23-08-focus-to-shift-on-kde-plasma-6-iso/](https://www.linuxtoday.com/news/kaos-linux-2023-09-adds-kde-gear-23-08-focus-to-shift-on-kde-plasma-6-iso/)
 - RSS feed: https://www.linuxtoday.com/news/feed
 - date published: 2023-09-25T13:00:20+00:00

<p>Powered by Linux kernel 6.4, KaOS 2023.09 includes the latest KDE Gear 23.08 software suite alongside the KDE Plasma 5.27.8 and KDE Frameworks 5.110 updates.</p>
<p>The post <a href="https://www.linuxtoday.com/news/kaos-linux-2023-09-adds-kde-gear-23-08-focus-to-shift-on-kde-plasma-6-iso/" rel="nofollow">KaOS Linux 2023.09 Adds KDE Gear 23.08, Focus to Shift on KDE Plasma 6 ISO</a> appeared first on <a href="https://www.linuxtoday.com" rel="nofollow">Linux Today</a>.</p>

