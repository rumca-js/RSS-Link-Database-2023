# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## The Red Pill View On Marriage Is Just As Toxic As Feminism
 - [https://www.youtube.com/watch?v=p8cZgCZhxKw](https://www.youtube.com/watch?v=p8cZgCZhxKw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-09-25T22:30:10+00:00

Switch to PureTalk and get 50% off your first month! Promo code WALSH https://bit.ly/42PmqaX

So called "red pilled" conservative influencers are attempting to destroy marriage.

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1229 - https://bit.ly/466bTKw 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## I Had "Enough" Of This Dumb Anti-Gun Song
 - [https://www.youtube.com/watch?v=tod1XF-dZJU](https://www.youtube.com/watch?v=tod1XF-dZJU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-09-25T15:00:43+00:00

Get a FREE Jumpstart Trial Bag http://www.RuffGreens.com/Matt
Or call 844-RUFF-700

Awkward anti-gun song performed on The View.

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1228 -https://bit.ly/464JAw8 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

