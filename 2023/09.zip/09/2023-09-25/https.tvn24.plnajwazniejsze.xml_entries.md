# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Prezes klubu zastrzelony po przegranym meczu
 - [https://eurosport.tvn24.pl/pilka-nozna/edgar-paez-nie-zyje.-prezes-tigres-fc-zastrzelony-po-meczu_sto9812205/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/edgar-paez-nie-zyje.-prezes-tigres-fc-zastrzelony-po-meczu_sto9812205/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T21:19:00+00:00

<img alt="Prezes klubu zastrzelony po przegranym meczu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g5qwk0-edgar-paez-7361172/alternates/LANDSCAPE_1280" />
    Szokująca wiadomość ze świata piłki nożnej.

## Mata na meczu Barcelony. Raper był w dwóch miejscach równocześnie
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/mata-na-trybunach-i-bandach-reklamowych-podczas-meczu-barcelona-celta-vigo_sto9811153/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/mata-na-trybunach-i-bandach-reklamowych-podczas-meczu-barcelona-celta-vigo_sto9811153/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T20:40:00+00:00

<img alt="Mata na meczu Barcelony. Raper był w dwóch miejscach równocześnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2coacc-robert-lewandowski-bohaterem-meczu-barcelona-celta-7361155/alternates/LANDSCAPE_1280" />
    Michał Matczak oglądał na żywo Roberta Lewandowskiego.

## Eksplozja na stacji benzynowej. Ponad 200 rannych
 - [https://tvn24.pl/swiat/gorski-karabach-eksplozja-na-stacji-benzynowej-w-miescie-stepanakert-wielu-rannych-7361150?source=rss](https://tvn24.pl/swiat/gorski-karabach-eksplozja-na-stacji-benzynowej-w-miescie-stepanakert-wielu-rannych-7361150?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T20:31:11+00:00

<img alt="Eksplozja na stacji benzynowej. Ponad 200 rannych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kenii8-stepanakert-7361149/alternates/LANDSCAPE_1280" />
    Donoszą lokalne media w Górskim Karabachu.

## Polonia wciąż się obawia o swoje głosy. "Nadal jest wielkie ryzyko"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/wybory-2023-polonia-wywalczyla-wiecej-komisji-za-granica-ale-wciaz-sie-obawia-o-swoje-glosy-7361140?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/wybory-2023-polonia-wywalczyla-wiecej-komisji-za-granica-ale-wciaz-sie-obawia-o-swoje-glosy-7361140?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T20:22:49+00:00

<img alt="Polonia wciąż się obawia o swoje głosy. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-yuybpw-zuber-7361142/alternates/LANDSCAPE_1280" />
    Polonia od dawna - wspólnie z przychylnymi sobie aktywistami - zabiega o jak najlepsze warunki do głosowania i pewność, że jej głosy będą policzone.

## Prezydent Zełenski o sytuacji wokół zboża. "Stopniowo pozbywamy się emocji"
 - [https://tvn24.pl/biznes/ze-swiata/ukraina-prezydent-wolodymyr-zelenski-o-imporcie-zboz-stopniowo-pozbywamy-sie-emocji-7361116?source=rss](https://tvn24.pl/biznes/ze-swiata/ukraina-prezydent-wolodymyr-zelenski-o-imporcie-zboz-stopniowo-pozbywamy-sie-emocji-7361116?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T20:13:42+00:00

<img alt="Prezydent Zełenski o sytuacji wokół zboża. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ng49s4-ukraina-zboze-zboze-z-ukrainy-kryzys-zbozowy-kijow-7279490/alternates/LANDSCAPE_1280" />
    Prezydent Ukrainy w opublikowanym nagraniu.

## Świątek po japońsku. Aplauz w Tokio
 - [https://eurosport.tvn24.pl/tenis/wta-tokyo/2023/iga-swiatek-przed-startem-turnieju-wta-w-tokio_sto9812046/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-tokyo/2023/iga-swiatek-przed-startem-turnieju-wta-w-tokio_sto9812046/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T20:01:00+00:00

<img alt="Świątek po japońsku. Aplauz w Tokio" src="https://tvn24.pl/najnowsze/cdn-zdjecie-55tkhu-iga-swiatek-7361126/alternates/LANDSCAPE_1280" />
    Druga rakieta świata wraca do gry.

## "Bardzo trudno jest nam zrozumieć stanowisko Chin"
 - [https://tvn24.pl/biznes/ze-swiata/chiny-unia-europejska-unijny-komisarz-valdis-dombrovskis-o-handlu-z-chinami-i-stanowisku-chin-w-sprawie-wojny-w-ukrainie-7361078?source=rss](https://tvn24.pl/biznes/ze-swiata/chiny-unia-europejska-unijny-komisarz-valdis-dombrovskis-o-handlu-z-chinami-i-stanowisku-chin-w-sprawie-wojny-w-ukrainie-7361078?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T19:56:02+00:00

Unijny komisarz w Pekinie.

## "Nie przestraszą mnie ani hejtem, mailami, ani zrywaniem plakatów"
 - [https://fakty.tvn24.pl/zobacz-fakty/kinga-gajewska-wrocila-do-otwocka-donald-tusk-zdradzil-co-mu-mowia-policjanci-na-ucho-7361076?source=rss](https://fakty.tvn24.pl/zobacz-fakty/kinga-gajewska-wrocila-do-otwocka-donald-tusk-zdradzil-co-mu-mowia-policjanci-na-ucho-7361076?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T19:39:35+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-46kvbp-zalewska-7361083/alternates/LANDSCAPE_1280" />
    Kinga Gajewska wróciła do Otwocka.

## Afera wizowa w Afryce. "Szukający pracy ludzie płacili ogromne łapówki, by dostać polskie wizy"
 - [https://fakty.tvn24.pl/zobacz-fakty/zorganizowana-grupa-przestepcza-ktora-dzialala-pod-skrzydlami-ministra-raua-reakcje-po-materiale-faktow-7361010?source=rss](https://fakty.tvn24.pl/zobacz-fakty/zorganizowana-grupa-przestepcza-ktora-dzialala-pod-skrzydlami-ministra-raua-reakcje-po-materiale-faktow-7361010?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T19:24:39+00:00

Doniesienia z Ugandy i Zimbabwe, i reakcje po materiale "Faktów".

## Afera na szczytach. Messner wykreślony z Księgi Rekordów Guinnessa
 - [https://eurosport.tvn24.pl/hill-climbing/reinhold-messner-wykreslony-z-ksiegi-rekordow-guinnessa.-dlaczego_sto9812025/story.shtml?source=rss](https://eurosport.tvn24.pl/hill-climbing/reinhold-messner-wykreslony-z-ksiegi-rekordow-guinnessa.-dlaczego_sto9812025/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T18:59:00+00:00

<img alt="Afera na szczytach. Messner wykreślony z Księgi Rekordów Guinnessa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8xdybd-reinhold-messner-jest-w-szoku-7361042/alternates/LANDSCAPE_1280" />
    Spór trwa.

## Ryczące czterdziestki, wyjące pięćdziesiątki – na jakiej lekcji się tego uczymy?
 - [https://tvn24.pl/toteraz/milionerzy-ryczace-czterdziestki-i-wyjace-piecdziesiatki-pytanie-i-odpowiedz-7360685?source=rss](https://tvn24.pl/toteraz/milionerzy-ryczace-czterdziestki-i-wyjace-piecdziesiatki-pytanie-i-odpowiedz-7360685?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T18:56:00+00:00

<img alt="Ryczące czterdziestki, wyjące pięćdziesiątki – na jakiej lekcji się tego uczymy?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yz9wfk-ryczace-czterdziestki-i-wyjace-piecdziesiatki-w-pytaniu-z-milionerow-za-piec-tysiecy-zlotych-7360671/alternates/LANDSCAPE_1280" />
    Pytanie z "Milionerów" za pięć tysięcy złotych.

## "Zrobiłam go z miłości do Polski"
 - [https://tvn24.pl/polska/zielona-granica-agnieszka-holland-o-filmie-zrobilam-go-z-milosci-do-polski-7360904?source=rss](https://tvn24.pl/polska/zielona-granica-agnieszka-holland-o-filmie-zrobilam-go-z-milosci-do-polski-7360904?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T18:50:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g9yzvi-kropka-agnieszka-holland-7360985/alternates/LANDSCAPE_1280" />
    Agnieszka Holland o filmie "Zielona granica".

## Ansa: włoskie F-35A stacjonujące w Polsce poderwane z powodu rosyjskich samolotów
 - [https://tvn24.pl/swiat/wloskie-f-35a-stacjonujace-w-polsce-poderwane-z-powodu-rosyjskich-samolotow-donosi-ansa-7361006?source=rss](https://tvn24.pl/swiat/wloskie-f-35a-stacjonujace-w-polsce-poderwane-z-powodu-rosyjskich-samolotow-donosi-ansa-7361006?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T18:48:44+00:00

<img alt="Ansa: włoskie F-35A stacjonujące w Polsce poderwane z powodu rosyjskich samolotów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-repw2p-pap_20220627_1px-1-7361022/alternates/LANDSCAPE_1280" />
    Obce maszyny eskortowano poza obszar powietrzny NATO.

## Wielki występ 18-latka w ekstraklasie. Sięgnął czasów Wilimowskiego
 - [https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/dawid-drachal-bohaterem-meczu-ruch-chorzow-rakow-czestochowa.-kim-jest-18-latek_sto9811728/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/dawid-drachal-bohaterem-meczu-ruch-chorzow-rakow-czestochowa.-kim-jest-18-latek_sto9811728/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T18:10:00+00:00

<img alt="Wielki występ 18-latka w ekstraklasie. Sięgnął czasów Wilimowskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dgnbd8-dawid-drachal-zakonczyl-mecz-z-ruchem-z-hat-trickiem-7361002/alternates/LANDSCAPE_1280" />
    Od niedzieli jest na ustach całej piłkarskiej Polski.

## Zaplanowano ewakuację części mieszkańców Zielonej Góry. Pojawią się saperzy
 - [https://tvn24.pl/lubuskie/zielona-gora-we-wtorek-planowa-ewakuacjamieszkancow-w-rejonie-ul-dzikiej-saperzy-beda-usuwac-niewybuchy-7360909?source=rss](https://tvn24.pl/lubuskie/zielona-gora-we-wtorek-planowa-ewakuacjamieszkancow-w-rejonie-ul-dzikiej-saperzy-beda-usuwac-niewybuchy-7360909?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T17:57:35+00:00

<img alt="Zaplanowano ewakuację części mieszkańców Zielonej Góry. Pojawią się saperzy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bjwx96-dzika-2-7360950/alternates/LANDSCAPE_1280" />
    Ewakuację zaplanowano na wtorek rano w okolicach ul. Dzikiej.

## Budowa kopalni w Ukrainie. Jest oświadczenie polskiego giganta
 - [https://tvn24.pl/biznes/z-kraju/ukrainie-kopalnia-w-ukrainie-jastrzebska-spolka-weglowa-wyjasnia-7360910?source=rss](https://tvn24.pl/biznes/z-kraju/ukrainie-kopalnia-w-ukrainie-jastrzebska-spolka-weglowa-wyjasnia-7360910?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T17:52:04+00:00

<img alt="Budowa kopalni w Ukrainie. Jest oświadczenie polskiego giganta " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-4o2icz-biuro-zarzadu-jsw-6626934/alternates/LANDSCAPE_1280" />
    Zarząd JSW wyjaśnia.

## Ikonowicz i Dziambor o swoich propozycjach dla Pomorza
 - [https://tvn24.pl/go/programy,7/czas-decyzji-ring--odcinki,1154347/odcinek-3467,S00E3467,1169472?source=rss](https://tvn24.pl/go/programy,7/czas-decyzji-ring--odcinki,1154347/odcinek-3467,S00E3467,1169472?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T17:31:27+00:00

<img alt="Ikonowicz i Dziambor o swoich propozycjach dla Pomorza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nc1aby-dziambor-i-ikonowicz-7360979/alternates/LANDSCAPE_1280" />
    Kandydaci w "Czasie decyzji".

## W sprawie Kurka spełniło się najgorsze
 - [https://eurosport.tvn24.pl/siatkowka/polscy-siatkarze-w-turnieju-eliminacyjnym-do-igrzysk-w-paryzu-wystapia-bez-bartosza-kurka_sto9811957/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/polscy-siatkarze-w-turnieju-eliminacyjnym-do-igrzysk-w-paryzu-wystapia-bez-bartosza-kurka_sto9811957/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T17:29:00+00:00

<img alt="W sprawie Kurka spełniło się najgorsze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f82u3l-bartosz-kurek-obejrzy-final-z-lawki-7344579/alternates/LANDSCAPE_1280" />
    Fatalna wiadomość dla kibiców siatkówki.

## Polska gospodarka na hamulcu. "Do 2025 roku dynamika PKB pozostanie niższa"
 - [https://tvn24.pl/biznes/z-kraju/rada-polityki-pienieznej-inflacja-stopy-procentowe-wzrost-pkb-opublikowano-zalozenia-polityki-pienieznej-na-rok-2024-7360769?source=rss](https://tvn24.pl/biznes/z-kraju/rada-polityki-pienieznej-inflacja-stopy-procentowe-wzrost-pkb-opublikowano-zalozenia-polityki-pienieznej-na-rok-2024-7360769?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T17:27:31+00:00

<img alt="Polska gospodarka na hamulcu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rn08h9-nbp-rpp-glapinski-7199459/alternates/LANDSCAPE_1280" />
    Opublikowano "Założenia Polityki Pieniężnej na rok 2024".

## USA uznały dwa nowe państwa
 - [https://tvn24.pl/swiat/wyspy-cooka-i-niue-uznane-przez-stany-zjednoczone-za-suwerenne-i-niepodlegle-panstwa-7360840?source=rss](https://tvn24.pl/swiat/wyspy-cooka-i-niue-uznane-przez-stany-zjednoczone-za-suwerenne-i-niepodlegle-panstwa-7360840?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T17:16:35+00:00

<img alt="USA uznały dwa nowe państwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p7e5c9-wyspa-niue-7352459/alternates/LANDSCAPE_1280" />
    Według komentatorów to próba wzmocnienia pozycji USA na Oceanie Spokojnym względem Chin.

## Reprezentant Anglii rozbił rolls-royce'a. Na trening przyjechał drugim
 - [https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/marcus-rashford-rozbil-auto-warte-fortune_sto9810527/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/marcus-rashford-rozbil-auto-warte-fortune_sto9810527/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T17:13:00+00:00

<img alt="Reprezentant Anglii rozbił rolls-royce'a. Na trening przyjechał drugim" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8247ip-marcus-rashford-rozbil-swoje-auto-7360894/alternates/LANDSCAPE_1280" />
    Wypadek Marcusa Rashforda.

## Pogoda w Hiszpanii cofa się o miesiąc
 - [https://tvn24.pl/tvnmeteo/swiat/upaly-w-hiszpanii-goraco-jak-w-sierpniu-moga-pasc-rekordy-7360757?source=rss](https://tvn24.pl/tvnmeteo/swiat/upaly-w-hiszpanii-goraco-jak-w-sierpniu-moga-pasc-rekordy-7360757?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T16:59:05+00:00

<img alt="Pogoda w Hiszpanii cofa się o miesiąc" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vw54f6-upaly-na-poludniu-hiszpanii-7360869/alternates/LANDSCAPE_1280" />
    Mogą paść rekordy ciepła.

## "Rozstrzyga się znowu los Polski w tej części świata"
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-donald-tusk-w-otwocku-jestesmy-dzisiaj-w-momencie-zwrotnym-rozstrzyga-sie-znowu-los-polski-w-tej-czesci-swiata-7360700?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-donald-tusk-w-otwocku-jestesmy-dzisiaj-w-momencie-zwrotnym-rozstrzyga-sie-znowu-los-polski-w-tej-czesci-swiata-7360700?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T16:30:08+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dmlhka-25-1650-tusk-0029-7360719/alternates/LANDSCAPE_1280" />
    Lider PO Donald Tusk i wiceszef PO Rafał Trzaskowski wystąpili razem na wiecu w Otwocku.

## "Sytuacja jest dramatyczna, nie mamy innego wyboru"
 - [https://tvn24.pl/swiat/polska-niemcy-plany-kontroli-na-granicach-premier-saksonii-sytuacja-jest-dramatyczna-jak-moga-wygladac-kontrole-i-co-sadza-niemcy-7360572?source=rss](https://tvn24.pl/swiat/polska-niemcy-plany-kontroli-na-granicach-premier-saksonii-sytuacja-jest-dramatyczna-jak-moga-wygladac-kontrole-i-co-sadza-niemcy-7360572?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T16:24:26+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5ugeqm-przejscie-graniczne-polska-niemcy-7360687/alternates/LANDSCAPE_1280" />
    Debata na temat napływu nielegalnych migrantów do Niemiec przybiera na sile w tym kraju.

## Kontrole na granicy ze Słowacją. Zapowiedź premiera
 - [https://tvn24.pl/biznes/z-kraju/kontrole-na-granicy-polsko-slowackiej-jest-zapowiedz-premiera-mateusza-morawieckiego-7360775?source=rss](https://tvn24.pl/biznes/z-kraju/kontrole-na-granicy-polsko-slowackiej-jest-zapowiedz-premiera-mateusza-morawieckiego-7360775?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T16:03:11+00:00

<img alt="Kontrole na granicy ze Słowacją. Zapowiedź premiera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4ro4t8-shutterstock_1653505462-7360776/alternates/LANDSCAPE_1280" />
    Wydał polecenie szefowie MSWiA.

## Libacja syna marszałka z PiS i urzędników w miejscu kaźni. Sejmik przyjął uchwałę
 - [https://tvn24.pl/kielce/michniow-libacja-radnego-z-pis-i-urzednikow-w-mauzoleum-martyrologii-wsi-polskich-stanowisku-sejmiku-wojewodztwa-swietokrzyskiego-7360755?source=rss](https://tvn24.pl/kielce/michniow-libacja-radnego-z-pis-i-urzednikow-w-mauzoleum-martyrologii-wsi-polskich-stanowisku-sejmiku-wojewodztwa-swietokrzyskiego-7360755?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T16:02:58+00:00

<img alt="Libacja syna marszałka z PiS i urzędników w miejscu kaźni. Sejmik przyjął uchwałę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-usd60d-wars-7333644/alternates/LANDSCAPE_1280" />
    Marszałek poinformował, ze dyrektor placówki zrezygnował z pracy.

## Orlen rozwiązał umowę ze znaną firmą. Jest porozumienie
 - [https://tvn24.pl/biznes/z-kraju/orlen-rozwiazuje-umowe-z-deloitte-audyt-jest-porozumienie-7360723?source=rss](https://tvn24.pl/biznes/z-kraju/orlen-rozwiazuje-umowe-z-deloitte-audyt-jest-porozumienie-7360723?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T15:51:18+00:00

<img alt="Orlen rozwiązał umowę ze znaną firmą. Jest porozumienie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xwyp4g-shutterstock2152259391-6775314/alternates/LANDSCAPE_1280" />
    Komunikat giełdowy.

## Premia dla siatkarek. Ważna deklaracja prezesa
 - [https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/prezes-pzps-sebastian-swiderski-po-awansie-polskich-siatkarek-na-igrzyska-olimpijskie-w-paryzu_sto9811906/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/prezes-pzps-sebastian-swiderski-po-awansie-polskich-siatkarek-na-igrzyska-olimpijskie-w-paryzu_sto9811906/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T15:43:00+00:00

<img alt="Premia dla siatkarek. Ważna deklaracja prezesa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jturp9-sebastian-swiderski-7360747/alternates/LANDSCAPE_1280" />
    Nagroda za awans na igrzyska.

## Śmiertelne potrącenie 24-latki na Ochocie
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-smiertelne-potracenie-24-latki-na-ochocie-7360708?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-smiertelne-potracenie-24-latki-na-ochocie-7360708?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T15:41:50+00:00

<img alt="Śmiertelne potrącenie 24-latki na Ochocie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9x4tr7-smiertelne-potracenie-na-ochocie-zdjecie-ilustracyjne-7360712/alternates/LANDSCAPE_1280" />
    Kobieta zmarła mimo reanimacji.

## Wassermann o wnioskach o podsłuchy: sąd wie, na co się zgadza. Nie do końca
 - [https://konkret24.tvn24.pl/polska/malgorzata-wassermann-o-wnioskach-o-podsluchy-sad-wie-na-co-sie-zgadza-nie-do-konca-st7359607?source=rss](https://konkret24.tvn24.pl/polska/malgorzata-wassermann-o-wnioskach-o-podsluchy-sad-wie-na-co-sie-zgadza-nie-do-konca-st7359607?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T15:39:28+00:00

<img alt="Wassermann o wnioskach o podsłuchy: sąd wie, na co się zgadza. Nie do końca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cp9hyp-wasserman-o-wnioskach-o-podsluchy-sad-wie-na-co-sie-zgadza-sedziowie-zaprzeczaja-7359818/alternates/LANDSCAPE_1280" />
    Wydając zgodę na inwigilację, sąd nie wie, że może zostać użyty szpiegowski program Pegasus.

## Pielęgniarkę skazaną za zabójstwo noworodków czeka powtórny proces
 - [https://tvn24.pl/swiat/wielka-brytania-lucy-letby-pielegniarka-skazana-za-zabojstwo-noworodkow-ma-ponownie-stanac-przed-sadem-7360457?source=rss](https://tvn24.pl/swiat/wielka-brytania-lucy-letby-pielegniarka-skazana-za-zabojstwo-noworodkow-ma-ponownie-stanac-przed-sadem-7360457?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T15:31:03+00:00

<img alt="Pielęgniarkę skazaną za zabójstwo noworodków czeka powtórny proces" src="https://tvn24.pl/najnowsze/cdn-zdjecie-duzbr5-lucy-letby-7297716/alternates/LANDSCAPE_1280" />
    Prokuratorzy o "trudnych decyzjach".

## Dwa miliardy dolarów pożyczki dla Polski. "Stany Zjednoczone z dumą ogłaszają podpisanie ważnej umowy"
 - [https://tvn24.pl/swiat/usa-pozyczka-dla-polski-o-wartosci-2-miliardow-dolarow-na-zbrojenia-7360645?source=rss](https://tvn24.pl/swiat/usa-pozyczka-dla-polski-o-wartosci-2-miliardow-dolarow-na-zbrojenia-7360645?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:48:15+00:00

<img alt="Dwa miliardy dolarów pożyczki dla Polski. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-eipt6j-czolgi-abrams-na-wyposazeniu-polskiej-armii-7360641/alternates/LANDSCAPE_1280" />
    Napisał w mediach społecznościowych ambasador USA w Polsce Mark Brzezinski.

## "W niektórych przypadkach tortury były tak brutalne, że powodowały śmierć"
 - [https://tvn24.pl/swiat/komisja-sledcza-onz-ds-ukrainy-czesc-ukrainskich-ofiar-wojny-zostala-przez-rosjan-zameczona-na-smierc-w-wyniku-tortur-7360638?source=rss](https://tvn24.pl/swiat/komisja-sledcza-onz-ds-ukrainy-czesc-ukrainskich-ofiar-wojny-zostala-przez-rosjan-zameczona-na-smierc-w-wyniku-tortur-7360638?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:47:35+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-reqdtj-pap_20221208_2tq-7360634/alternates/LANDSCAPE_1280" />
    Rosyjskie kaźnie w Ukrainie.

## Dwucyfrowe wzrosty cen na horyzoncie
 - [https://tvn24.pl/biznes/nieruchomosci/mieszkania-w-polsce-ceny-analitycy-prognozuja-dwucyfrowe-wzrosty-cen-transakcyjnych-mieszkan-7360560?source=rss](https://tvn24.pl/biznes/nieruchomosci/mieszkania-w-polsce-ceny-analitycy-prognozuja-dwucyfrowe-wzrosty-cen-transakcyjnych-mieszkan-7360560?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:46:19+00:00

<img alt="Dwucyfrowe wzrosty cen na horyzoncie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bdxnqc-zakup-mieszkania-7243844/alternates/LANDSCAPE_1280" />
    Prognozy analityków największego banku w Polsce.

## W niedzielę Marsz Miliona Serc w Warszawie. Jaką trasą pójdzie?
 - [https://tvn24.pl/tvnwarszawa/ulice/1-pazdziernika-marsza-miliona-serc-w-warszawie-trasa-7360542?source=rss](https://tvn24.pl/tvnwarszawa/ulice/1-pazdziernika-marsza-miliona-serc-w-warszawie-trasa-7360542?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:40:53+00:00

<img alt="W niedzielę Marsz Miliona Serc w Warszawie. Jaką trasą pójdzie?" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ms85ub-1-pazdziernika-odbedzie-sie-marsz-miliona-serc-7360549/alternates/LANDSCAPE_1280" />
    Start w południe.

## Wojskowe samoloty startują i lądują na drodze pod Olsztynem
 - [https://tvn24.pl/olsztyn/ruskowo-przezdziek-wielki-cwiczenia-route-604-wojskowe-samoloty-na-drodze-wojewodzkiej-nr-604-7360534?source=rss](https://tvn24.pl/olsztyn/ruskowo-przezdziek-wielki-cwiczenia-route-604-wojskowe-samoloty-na-drodze-wojewodzkiej-nr-604-7360534?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:37:42+00:00

<img alt="Wojskowe samoloty startują i lądują na drodze pod Olsztynem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1suqri-cwiczenia-route-604-na-mazurach-7360627/alternates/LANDSCAPE_1280" />
    Rozpoczęły się ćwiczenia ROUTE 604.

## Vingegaard i Evenepoel w jednym teamie? Pachnie wielką fuzją
 - [https://eurosport.tvn24.pl/kolarstwo/jumbo-visma-oraz-soudal-quick-step-coraz-blizej-fuzji.-dlaczego_sto9811680/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/jumbo-visma-oraz-soudal-quick-step-coraz-blizej-fuzji.-dlaczego_sto9811680/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:27:06+00:00

<img alt="Vingegaard i Evenepoel w jednym teamie? Pachnie wielką fuzją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nr9u05-evenepoel-i-vingegaard-to-dwaj-wielcy-rywale-w-tourze-7360749/alternates/LANDSCAPE_1280" />
    Sensacyjne wieści ze świata kolarstwa. Jak informują media, coraz więcej wskazuje na połączenie grup Jumbo-Visma z Holandii i Soudal Quick-Step z Belgii. Gdyby faktycznie doszło do fuzji, kolegami z zespołu staliby się jedni z najlepszych obecnie zawodników na świecie - Duńczyk Jonas Vingegaard oraz Belg Remco Evenepoel.

## "Nie zgadzamy się, aby politycy ograniczali naszą twórczą wolność"
 - [https://tvn24.pl/najnowsze/zielona-granica-ewa-puszczynska-o-atakach-na-tworcow-nie-zgadzamy-sie-aby-politycy-ograniczali-nasza-tworcza-wolnosc-7360579?source=rss](https://tvn24.pl/najnowsze/zielona-granica-ewa-puszczynska-o-atakach-na-tworcow-nie-zgadzamy-sie-aby-politycy-ograniczali-nasza-tworcza-wolnosc-7360579?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:16:17+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qbw4p8-kadr-z-filmu-agnieszki-holland-zielona-granica-7301650/alternates/LANDSCAPE_1280" />
    Ewa Puszczyńska, tegoroczna przewodnicząca komisji oscarowej, o atakach polityków na film "Zielona granica".

## "Pułapka na kraby". Kijów: zginęło 34 rosyjskich oficerów, w tym admirał
 - [https://tvn24.pl/swiat/ukraina-po-ataku-na-sztab-rosyjskiej-floty-czarnomorskiej-w-sewastopolu-zginelo-34-oficerow-w-tym-dowodca-7360299?source=rss](https://tvn24.pl/swiat/ukraina-po-ataku-na-sztab-rosyjskiej-floty-czarnomorskiej-w-sewastopolu-zginelo-34-oficerow-w-tym-dowodca-7360299?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:13:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5agzyg-wybuch-7360197/alternates/LANDSCAPE_1280" />
    Siły Operacji Specjalnych Ukrainy ujawniły szczegóły ataku na sztab rosyjskiej Floty Czarnomorskiej.

## Ziobro poparł Bąkiewicza. Padły pytania o nakaz wszczęcia śledztw wobec kandydata Suwerennej Polski
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-zbigniew-ziobro-poparl-roberta-bakiewicza-minister-byl-pytany-o-nakazane-przez-sad-sledztwa-w-sprawie-bakiewicza-7360379?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-zbigniew-ziobro-poparl-roberta-bakiewicza-minister-byl-pytany-o-nakazane-przez-sad-sledztwa-w-sprawie-bakiewicza-7360379?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:09:55+00:00

<img alt="Ziobro poparł Bąkiewicza. Padły pytania o nakaz wszczęcia śledztw wobec kandydata Suwerennej Polski " src="https://tvn24.pl/polska/cdn-zdjecie-9y4ojs-ziobro-i-bakiewicz-7360438/alternates/LANDSCAPE_1280" />
    Szef MS i prokurator generalny wystąpił z Robertem Bąkiewiczem na wspólnej konferencji w Radomiu.

## Alerty IMGW dla pięciu województw
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-gesta-mgla-pogoda-na-poniedzialek-i-wtorek-7360550?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-gesta-mgla-pogoda-na-poniedzialek-i-wtorek-7360550?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T14:09:24+00:00

<img alt="Alerty IMGW dla pięciu województw" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vglmpv-mgly-6165662/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie aura okaże się niebezpieczna.

## Bank w Polsce na sprzedaż. Wpłynęły "niewiążące oferty"
 - [https://tvn24.pl/biznes/z-kraju/velobank-na-sprzedaz-bankowy-fundusz-gwarancyjny-o-niewiazacych-ofertach-7360409?source=rss](https://tvn24.pl/biznes/z-kraju/velobank-na-sprzedaz-bankowy-fundusz-gwarancyjny-o-niewiazacych-ofertach-7360409?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T13:40:58+00:00

<img alt="Bank w Polsce na sprzedaż. Wpłynęły " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bwubzq-velobank-7360481/alternates/LANDSCAPE_1280" />
    Poinformował Bankowy Fundusz Gwarancyjny.

## Konserwator zawiadamia prokuraturę w sprawie rozbiórki modernistycznego budynku na Bielanach
 - [https://tvn24.pl/tvnwarszawa/bielany/warszawa-nielegalna-rozbiorka-budynku-na-bielanach-konserwator-zawiadamia-prokurature-7360427?source=rss](https://tvn24.pl/tvnwarszawa/bielany/warszawa-nielegalna-rozbiorka-budynku-na-bielanach-konserwator-zawiadamia-prokurature-7360427?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T13:36:13+00:00

<img alt="Konserwator zawiadamia prokuraturę w sprawie rozbiórki modernistycznego budynku na Bielanach " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-f0mr70-rozbiorka-budynku-przy-ul-grebalowskiej-11-7360421/alternates/LANDSCAPE_1280" />
    Nieruchomość jest w wojewódzkiej ewidencji zabytków.

## Seksafera w parafii. Biskup prosi o modlitwę za księży. O mężczyźnie, który stracił przytomność, nie wspomina
 - [https://tvn24.pl/katowice/dabrowa-gornicza-seksafera-w-parafii-biskup-prosi-o-modlitwe-za-ksiezy-o-mezczyznie-ktory-stracil-przytomnosc-na-plebanii-nie-wspomina-7359926?source=rss](https://tvn24.pl/katowice/dabrowa-gornicza-seksafera-w-parafii-biskup-prosi-o-modlitwe-za-ksiezy-o-mezczyznie-ktory-stracil-przytomnosc-na-plebanii-nie-wspomina-7359926?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T13:08:58+00:00

<img alt="Seksafera w parafii. Biskup prosi o modlitwę za księży. O mężczyźnie, który stracił przytomność, nie wspomina" src="https://tvn24.pl/najnowsze/cdn-zdjecie-26iv6p-do-zdarzenia-mialo-dojsc-w-budynku-nalezacym-do-parafii-pw-nmp-anielskiej-w-dabrowie-gorniczej-7352977/alternates/LANDSCAPE_1280" />
    Prokuratura mówi o pokrzywdzonym, Kościół o nim zapomina.

## Jest polski kandydat do Oscara
 - [https://tvn24.pl/kultura-i-styl/oscary-2024-chlopi-polskim-kandydatem-do-oscara-w-kategorii-najlepszy-film-miedzynarodowy-7359870?source=rss](https://tvn24.pl/kultura-i-styl/oscary-2024-chlopi-polskim-kandydatem-do-oscara-w-kategorii-najlepszy-film-miedzynarodowy-7359870?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T13:02:58+00:00

<img alt="Jest polski kandydat do Oscara" src="https://tvn24.pl/najnowsze/cdn-zdjecie-poyd9k-kadr-z-filmu-chlopi-7269091/alternates/LANDSCAPE_1280" />
    Poinformowała w poniedziałek komisja oscarowa.

## Politycy PiS zakłócili konferencję posłów KO. Dziennikarze zapytali ich o przesłuchanie Jarosława Kaczyńskiego
 - [https://tvn24.pl/polska/afera-srebrnej-poslowie-ko-pytaja-o-przesluchanie-jaroslawa-kaczynskiego-politycy-partii-rzadzacej-zaklocili-konferencje-7360322?source=rss](https://tvn24.pl/polska/afera-srebrnej-poslowie-ko-pytaja-o-przesluchanie-jaroslawa-kaczynskiego-politycy-partii-rzadzacej-zaklocili-konferencje-7360322?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T12:39:43+00:00

<img alt="Politycy PiS zakłócili konferencję posłów KO. Dziennikarze zapytali ich o przesłuchanie Jarosława Kaczyńskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9wjgdu-25-1200-kropiwnicki-0012-7360336/alternates/LANDSCAPE_1280" />
    Dzisiaj powraca z dużym echem afera pod nazwą "Koperta Kaczyńskiego" - mówił na konferencji poseł KO Arkadiusz Myrcha.

## Kierowca wjechał w rowerzystkę. Siła uderzenia wyrzuciła ją w górę
 - [https://tvn24.pl/bialystok/bialystok-kierowca-wjechal-w-rowerzystke-sila-uderzenia-wyrzucila-ja-w-gore-nagranie-7360051?source=rss](https://tvn24.pl/bialystok/bialystok-kierowca-wjechal-w-rowerzystke-sila-uderzenia-wyrzucila-ja-w-gore-nagranie-7360051?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T12:33:45+00:00

<img alt="Kierowca wjechał w rowerzystkę. Siła uderzenia wyrzuciła ją w górę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xrofn-kobieta-momentalnie-znalazla-sie-w-powietrzu-7359900/alternates/LANDSCAPE_1280" />
    Była na przejeździe dla rowerzystów.

## Świątek poznała pierwszą rywalkę w Tokio
 - [https://eurosport.tvn24.pl/tenis/wta-tokyo/2023/iga-swiatek-poznala-pierwsza-rywalke-w-turnieju-wta-500-w-tokio-2023.-z-kim-zagra_sto9811760/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-tokyo/2023/iga-swiatek-poznala-pierwsza-rywalke-w-turnieju-wta-500-w-tokio-2023.-z-kim-zagra_sto9811760/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T12:33:37+00:00

<img alt="Świątek poznała pierwszą rywalkę w Tokio" src="https://tvn24.pl/najnowsze/cdn-zdjecie-isssl9-iga-swiatek-szykuje-sie-do-wystepu-w-tokio-7354466/alternates/LANDSCAPE_1280" />
    W pierwszej rundzie wiceliderka światowego rankingu miała wolny los.

## Wysoka wygrana w Eurojackpot w Polsce. Podano, gdzie padła
 - [https://tvn24.pl/biznes/pieniadze/rzeszow-eurojackpot-wysoka-wygrana-w-loterii-w-polsce-wyniki-losowania-220923-7360352?source=rss](https://tvn24.pl/biznes/pieniadze/rzeszow-eurojackpot-wysoka-wygrana-w-loterii-w-polsce-wyniki-losowania-220923-7360352?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T12:30:14+00:00

<img alt="Wysoka wygrana w Eurojackpot w Polsce. Podano, gdzie padła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pifgpo-rzeszow-droga-ulica-samochody-7360368/alternates/LANDSCAPE_1280" />
    Jest komunikat.

## Hiphopowe korzenie, zmieniona perspektywa. Recenzja nowej płyty Taco Hemingwaya
 - [https://tvn24.pl/kultura-i-styl/taco-hemingway-wrocil-nowa-plyta-1-800-oswiecenie-recenzja-7360041?source=rss](https://tvn24.pl/kultura-i-styl/taco-hemingway-wrocil-nowa-plyta-1-800-oswiecenie-recenzja-7360041?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T11:58:02+00:00

<img alt="Hiphopowe korzenie, zmieniona perspektywa. Recenzja nowej płyty Taco Hemingwaya" src="https://tvn24.pl/najnowsze/cdn-zdjecie-idaicf-taco-hemingway-7360201/alternates/LANDSCAPE_1280" />
    Warszawski raper wrócił po trzyletniej przerwie.

## "Naszą uwagę zwróciło pędzące z ogromną prędkością auto". Tajemnica wypadku na A1
 - [https://tvn24.pl/lodz/sieroslaw-autostrada-a1-rodzina-splonela-w-aucie-policja-potwierdza-udzial-drugiego-samochodu-nowe-nagranie-7360019?source=rss](https://tvn24.pl/lodz/sieroslaw-autostrada-a1-rodzina-splonela-w-aucie-policja-potwierdza-udzial-drugiego-samochodu-nowe-nagranie-7360019?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T11:54:22+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-90nv8p-tragiczny-wypadek-na-autostradzie-a1-kolo-piotrkowa-trybunalskiego-7352238/alternates/LANDSCAPE_1280" />
    Do zdarzenia doszło na autostradzie A1 koło Piotrkowa Trybunalskiego.

## Rodzina spłonęła w aucie. Policja potwierdza udział drugiego samochodu
 - [https://tvn24.pl/lodz/sieroslawice-autostrada-a1-rodzina-splonela-w-aucie-policja-potwierdza-udzial-drugiego-samochodu-nowe-nagranie-7360019?source=rss](https://tvn24.pl/lodz/sieroslawice-autostrada-a1-rodzina-splonela-w-aucie-policja-potwierdza-udzial-drugiego-samochodu-nowe-nagranie-7360019?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T11:54:22+00:00

<img alt="Rodzina spłonęła w aucie. Policja potwierdza udział drugiego samochodu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-90nv8p-tragiczny-wypadek-na-autostradzie-a1-kolo-piotrkowa-trybunalskiego-7352238/alternates/LANDSCAPE_1280" />
    Do zdarzenia doszło na autostradzie A1 koło Piotrkowa Trybunalskiego.

## Księża spytali młodych o lekcje religii. W odpowiedziach "przynudzanie", "bezsensowne rozmowy"
 - [https://tvn24.pl/krakow/krakow-ksieza-spytali-mlodych-o-lekcje-religii-mlodzi-krytykuja-katechezy-za-monotonie-i-przynudzanie-katecheci-odpowiadaja-7359836?source=rss](https://tvn24.pl/krakow/krakow-ksieza-spytali-mlodych-o-lekcje-religii-mlodzi-krytykuja-katechezy-za-monotonie-i-przynudzanie-katecheci-odpowiadaja-7359836?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T11:44:58+00:00

<img alt="Księża spytali młodych o lekcje religii. W odpowiedziach " src="https://tvn24.pl/najnowsze/cdn-zdjecie-i17fc9-religia-6240449/alternates/LANDSCAPE_1280" />
    Katecheci odpowiadają.

## "Amerykańscy inwestorzy chcą i potrzebują przewidywalnego prawa"
 - [https://tvn24.pl/biznes/najnowsze/mark-brzezinski-ambasador-usa-w-polsce-podczas-kongresu-federacji-przedsiebiorcow-polskich-od-dyrektorow-amerykanskich-firm-slysze-ze-uwielbiaja-pracowac-w-polsce-7359996?source=rss](https://tvn24.pl/biznes/najnowsze/mark-brzezinski-ambasador-usa-w-polsce-podczas-kongresu-federacji-przedsiebiorcow-polskich-od-dyrektorow-amerykanskich-firm-slysze-ze-uwielbiaja-pracowac-w-polsce-7359996?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T11:41:05+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ad12am-brzezinski-7360271/alternates/LANDSCAPE_1280" />
    Powiedział Mark Brzezinski, ambasador USA w Polsce.

## Kandydat Łukasz Mejza u boku prezesa PiS. "Symbol upadku moralnego w parlamencie"
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-lukasz-mejza-startuje-z-list-prawa-i-sprawiedliwosci-politycy-komentuja-7359984?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-lukasz-mejza-startuje-z-list-prawa-i-sprawiedliwosci-politycy-komentuja-7359984?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T11:37:35+00:00

<img alt="Kandydat Łukasz Mejza u boku prezesa PiS. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qth6j7-lukasz-mejza-7360218/alternates/LANDSCAPE_1280" />
    Politycy komentują start Łukasza Mejzy z list Prawa i Sprawiedliwości.

## Lewandowski już na czele
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/klasyfikacja-strzelcow-laliga-2023-24-ktore-miejsce-zajmuje-robert-lewandowski-ile-ma-goli-pilka-noz_sto9811564/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/klasyfikacja-strzelcow-laliga-2023-24-ktore-miejsce-zajmuje-robert-lewandowski-ile-ma-goli-pilka-noz_sto9811564/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T11:24:14+00:00

<img alt="Lewandowski już na czele" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8lb91k-ile-goli-lewandowski-strzeli-w-tym-sezonie-7360225/alternates/LANDSCAPE_1280" />
    Zobacz klasyfikację strzelców w Hiszpanii.

## PiS bez większości, nawet w koalicji z Konfederacją
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-najnowszy-sondaz-partyjny-pis-bez-wiekszosci-nawet-w-koalicji-z-konfederacja-7359953?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-najnowszy-sondaz-partyjny-pis-bez-wiekszosci-nawet-w-koalicji-z-konfederacja-7359953?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T11:05:08+00:00

<img alt="PiS bez większości, nawet w koalicji z Konfederacją" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-h11jl1-sejm-sondaz-7163863/alternates/LANDSCAPE_1280" />
    Najnowszy sondaż United Surveys dla Wirtualnej Polski.

## Ceny "eksplodowały", padają rekordy
 - [https://tvn24.pl/biznes/z-kraju/ceny-mieszkan-eksplodowaly-dane-za-wrzesien-2023-analiza-7359890?source=rss](https://tvn24.pl/biznes/z-kraju/ceny-mieszkan-eksplodowaly-dane-za-wrzesien-2023-analiza-7359890?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T10:45:43+00:00

<img alt="Ceny " src="https://tvn24.pl/najnowsze/cdn-zdjecie-12kbz8-ceny-ofertowe-mieszkan-wzrosly-4576882/alternates/LANDSCAPE_1280" />
    Analiza.

## W poszukiwaniu lepszego życia zaciągają się do rosyjskiej armii. "Podpisaliśmy pakt z diabłem"
 - [https://tvn24.pl/swiat/kuba-politico-mlodzi-kubanczycy-zaciagaja-sie-do-rosyjskiej-armii-7359885?source=rss](https://tvn24.pl/swiat/kuba-politico-mlodzi-kubanczycy-zaciagaja-sie-do-rosyjskiej-armii-7359885?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T10:42:20+00:00

<img alt="W poszukiwaniu lepszego życia zaciągają się do rosyjskiej armii. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cgj4tm-kubanczycy-7359886/alternates/LANDSCAPE_1280" />
    Przekazał brukselski portal Politico.

## Awans Linette w rankingu WTA
 - [https://eurosport.tvn24.pl/tenis/ranking-wta-z-25-wrzesnia.-kto-liderem-ktora-jest-iga-swiatek-a-ktore-miejsce-zajmuje-magda-linette_sto9811578/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/ranking-wta-z-25-wrzesnia.-kto-liderem-ktora-jest-iga-swiatek-a-ktore-miejsce-zajmuje-magda-linette_sto9811578/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T10:25:39+00:00

<img alt="Awans Linette w rankingu WTA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-imufjf-magda-linette-zanotowala-awans-w-rankingu-wta-7360008/alternates/LANDSCAPE_1280" />
    Świątek wciąż za Sabalenką.

## Klępa i łoszaki wolnym krokiem pokonały ruchliwą ulicę
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-losie-przeszly-przez-modlinska-nagranie-7359696?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-losie-przeszly-przez-modlinska-nagranie-7359696?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T10:20:14+00:00

<img alt="Klępa i łoszaki wolnym krokiem pokonały ruchliwą ulicę" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-13ul9-losie-widziane-na-ulicy-modlinskiej-7359778/alternates/LANDSCAPE_1280" />
    Na czerwonym świetle.

## Najstarsza ryba żyjąca w akwarium kocha figi i głaskanie. Nie zgadniecie, ile ma lat
 - [https://tvn24.pl/tvnmeteo/nauka/matuzalem-najstarsza-ryba-akwariowa-na-swiecie-moze-miec-o-wiele-lat-wiecej-niz-myslelismy-7359862?source=rss](https://tvn24.pl/tvnmeteo/nauka/matuzalem-najstarsza-ryba-akwariowa-na-swiecie-moze-miec-o-wiele-lat-wiecej-niz-myslelismy-7359862?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T10:19:56+00:00

<img alt="Najstarsza ryba żyjąca w akwarium kocha figi i głaskanie. Nie zgadniecie, ile ma lat" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9nk1i-ryba-matuzalem-w-akwarium-steinhart-7359911/alternates/LANDSCAPE_1280" />
    Oto Matuzalem.

## Przez pół godziny wisieli do góry nogami
 - [https://tvn24.pl/swiat/kanada-awaria-w-parku-rozrywki-canadas-wonderland-przez-30-minut-wisieli-nogami-do-gory-7359872?source=rss](https://tvn24.pl/swiat/kanada-awaria-w-parku-rozrywki-canadas-wonderland-przez-30-minut-wisieli-nogami-do-gory-7359872?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T09:58:13+00:00

<img alt="Przez pół godziny wisieli do góry nogami " src="https://tvn24.pl/najnowsze/cdn-zdjecie-js0gsq-canadas-wonderland-pasazerowie-kolejki-zawisli-nogami-do-gory-na-30-minut-7359952/alternates/LANDSCAPE_1280" />
    Awaria karuzeli w parku rozrywki.

## Potrąciła matkę z dzieckiem. Byli na przejściu dla pieszych
 - [https://tvn24.pl/wroclaw/olawa-potracenie-kobiety-z-dzieckiem-na-przejsciu-dla-pieszych-7359671?source=rss](https://tvn24.pl/wroclaw/olawa-potracenie-kobiety-z-dzieckiem-na-przejsciu-dla-pieszych-7359671?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T09:44:59+00:00

<img alt="Potrąciła matkę z dzieckiem. Byli na przejściu dla pieszych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sslkh3-do-zdarzenia-doszlo-na-oznakowanym-przejsciu-dla-pieszych-7359644/alternates/LANDSCAPE_1280" />
    W Oławie (woj. dolnośląskie).

## Gotują się. "Nie mamy żadnej kontroli nad tym absurdalnym gorącem"
 - [https://tvn24.pl/tvnmeteo/swiat/brazylia-upal-masa-ludzi-w-basenach-w-brazylii-zar-leje-sie-z-nieba-7359781?source=rss](https://tvn24.pl/tvnmeteo/swiat/brazylia-upal-masa-ludzi-w-basenach-w-brazylii-zar-leje-sie-z-nieba-7359781?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T09:43:23+00:00

<img alt="Gotują się. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-fuwmng-2023-09-24t214930z_1_lwd453524092023rp1_rtrwnev_c_4535-brazil-weather-1-0003-7359864/alternates/LANDSCAPE_1280" />
    W Brazylii trwają upały.

## "Wyborcza" publikuje zapis z przesłuchania Birgfellnera. "Przekazałem kopertę i pan Kaczyński poszedł do pokoju"
 - [https://tvn24.pl/polska/afera-srebrnej-wiez-kaczynskiego-wyborcza-publikuje-zapis-z-przesluchania-geralda-birgfellnera-7359530?source=rss](https://tvn24.pl/polska/afera-srebrnej-wiez-kaczynskiego-wyborcza-publikuje-zapis-z-przesluchania-geralda-birgfellnera-7359530?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T09:42:49+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6yq83o-pap_20220625_0dq-7353014/alternates/LANDSCAPE_1280" />
    Austriacki biznesmen mówił o kopercie z 50 tysiącami złotych.

## Legenda skoków narciarskich zakończyła karierę
 - [https://eurosport.tvn24.pl/skoki-narciarskie/daniela-iraschko-stolz-zakonczyla-kariere.-jakie-sukcesy-miala-austriaczka_sto9811498/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/daniela-iraschko-stolz-zakonczyla-kariere.-jakie-sukcesy-miala-austriaczka_sto9811498/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T09:32:01+00:00

<img alt="Legenda skoków narciarskich zakończyła karierę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rafpxw-daniela-iraschko-stolz-to-wielokrotna-medalistka-ms-7359901/alternates/LANDSCAPE_1280" />
    Poinformował Austriacki Związek Narciarski.

## Weteran nazistowskiej dywizji uhonorowany. Przewodniczący parlamentu przeprasza
 - [https://tvn24.pl/swiat/kanada-skandal-w-parlamencie-ukrainski-weteran-dywizji-nazistowskiej-uznany-za-bohatera-spiker-przeprasza-7359569?source=rss](https://tvn24.pl/swiat/kanada-skandal-w-parlamencie-ukrainski-weteran-dywizji-nazistowskiej-uznany-za-bohatera-spiker-przeprasza-7359569?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T09:27:43+00:00

<img alt="Weteran nazistowskiej dywizji uhonorowany. Przewodniczący parlamentu przeprasza " src="https://tvn24.pl/najnowsze/cdn-zdjecie-orp7ei-wolodymyr-zelenski-przed-izba-gmin-kanady-7359880/alternates/LANDSCAPE_1280" />
    W kanadyjskim parlamencie.

## Podatek od smartfonów? Zapadł ważny wyrok
 - [https://tvn24.pl/biznes/z-kraju/podatek-od-smartfonow-oplata-reprograficzna-zapadl-wazny-wyrok-producent-zapowiada-odwolanie-7359666?source=rss](https://tvn24.pl/biznes/z-kraju/podatek-od-smartfonow-oplata-reprograficzna-zapadl-wazny-wyrok-producent-zapowiada-odwolanie-7359666?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T09:23:10+00:00

<img alt="Podatek od smartfonów? Zapadł ważny wyrok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x03bqy-smartfon-smartfony-sklep-shutterstock_1051250048-7323725/alternates/LANDSCAPE_1280" />
    Producent zapowiada jednak odwołanie od decyzji sądu.

## Sophia Loren w szpitalu, miała wypadek
 - [https://tvn24.pl/kultura-i-styl/sophia-loren-w-szpitalu-miala-wypadek-7359632?source=rss](https://tvn24.pl/kultura-i-styl/sophia-loren-w-szpitalu-miala-wypadek-7359632?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T09:10:36+00:00

<img alt="Sophia Loren w szpitalu, miała wypadek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gilhh4-sophia-loren-7359673/alternates/LANDSCAPE_1280" />
    Czuwają przy niej synowie.

## "O tym się nie mówi". Wstrząsające zdjęcia, historie kobiet i ich rodzin, głosy lekarzy
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1259,S00E1259,1168801?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1259,S00E1259,1168801?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T08:44:45+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z706o1-o-tym-sie-nie-mowi-film-dokumentalny-marka-osiecimskiego-o-aborcji-w-polsce-7359706/alternates/LANDSCAPE_1280" />
    Film Marka Osiecimskiego.

## Są nowe dane o bezrobociu w Polsce
 - [https://tvn24.pl/biznes/dla-pracownika/bezrobocie-w-polsce-sierpien-2023-gus-podal-nowe-dane-7359576?source=rss](https://tvn24.pl/biznes/dla-pracownika/bezrobocie-w-polsce-sierpien-2023-gus-podal-nowe-dane-7359576?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T08:01:47+00:00

<img alt="Są nowe dane o bezrobociu w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gvzi95-pilne-5496805/alternates/LANDSCAPE_1280" />
    Komunikat GUS.

## Modelki znalezione martwe w pobliskich budynkach, z obiema kontakt urwał się tego samego dnia
 - [https://tvn24.pl/swiat/los-angeles-modelki-znalezione-martwe-w-pobliskich-budynkach-z-obiema-kontakt-urwal-sie-tego-samego-dnia-7359533?source=rss](https://tvn24.pl/swiat/los-angeles-modelki-znalezione-martwe-w-pobliskich-budynkach-z-obiema-kontakt-urwal-sie-tego-samego-dnia-7359533?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T07:40:39+00:00

<img alt="Modelki znalezione martwe w pobliskich budynkach, z obiema kontakt urwał się tego samego dnia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-13to6j-samochod-policyjny-los-angeles-6884187/alternates/LANDSCAPE_1280" />
    "Jeśli gdzieś tam czai się drapieżca, musi zostać schwytany".

## Polki nie dowierzały
 - [https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/agnieszka-korneluk-i-kamila-witkowska-po-meczu-polska-wlochy_sto9811424/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/agnieszka-korneluk-i-kamila-witkowska-po-meczu-polska-wlochy_sto9811424/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T07:24:46+00:00

<img alt="Polki nie dowierzały" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qeh5he-polki-niedowierzaly-7359584/alternates/LANDSCAPE_1280" />
    "Już chyba nawet nie miałam siły na płacz".

## Pomnik zniknął spod Petersburga. Władze "nie wiedzą, co się stało"
 - [https://tvn24.pl/swiat/rosja-pod-petersburgiem-zniknal-pomnik-upamietniajacy-poleglych-zolnierzy-finskich-7359372?source=rss](https://tvn24.pl/swiat/rosja-pod-petersburgiem-zniknal-pomnik-upamietniajacy-poleglych-zolnierzy-finskich-7359372?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T07:01:22+00:00

<img alt="Pomnik zniknął spod Petersburga. Władze " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6a48r0-pomnik-7359497/alternates/LANDSCAPE_1280" />
    Stał w rosyjskim Prioziorsku od 2019 roku.

## Branża alarmuje: to może spowodować odejście nawet 70 procent pracowników
 - [https://tvn24.pl/biznes/najnowsze/pe-szykuje-zmiane-przepisow-branza-alarmuje-uber-glovo-bolt-moga-byc-drozsze-7359498?source=rss](https://tvn24.pl/biznes/najnowsze/pe-szykuje-zmiane-przepisow-branza-alarmuje-uber-glovo-bolt-moga-byc-drozsze-7359498?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T06:36:47+00:00

<img alt="Branża alarmuje: to może spowodować odejście nawet 70 procent pracowników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8q41g9-warszawa-korek-grand-warszawski-shutterstock_2273334983-7359515/alternates/LANDSCAPE_1280" />
    O sprawie pisze "Rzeczpospolita".

## "Pedagogika dumy zamiast pedagogiki wstydu". Czarnek zapowiada bony na wycieczki, nauczyciele mają dość
 - [https://tvn24.pl/premium/edukacja-szkola-minister-przemyslaw-czarnek-i-program-poznaj-polske-nauczyciele-maja-dosc-wycieczek-i-pracy-24-godziny-na-dobe-7353577?source=rss](https://tvn24.pl/premium/edukacja-szkola-minister-przemyslaw-czarnek-i-program-poznaj-polske-nauczyciele-maja-dosc-wycieczek-i-pracy-24-godziny-na-dobe-7353577?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T06:31:35+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e44g2a-morskie-oko-7353318/alternates/LANDSCAPE_1280" />
    Przemysław Czarnek zapowiedział poszerzenie programu "Poznaj Polskę". Wycieczki, które dofinansowuje Ministerstwo Edukacji i Nauki, mają teraz trwać już nie jeden, ale dwa dni. Problem w tym, że propozycja ministra, delikatnie mówiąc, sfrustrowała nauczycieli. - Wycieczka to praca całą dobę - mówi tvn24.pl nauczycielka Maria Kowalewska. Za tę pracę nikt dodatkowo nie płaci.

## Policyjny snajper oskarżony o morderstwo. Funkcjonariusze składają broń
 - [https://tvn24.pl/swiat/wielka-brytania-ponad-100-policjantow-zlozylo-bron-po-oskarzeniu-policyjnego-snajpera-o-morderstwo-7359379?source=rss](https://tvn24.pl/swiat/wielka-brytania-ponad-100-policjantow-zlozylo-bron-po-oskarzeniu-policyjnego-snajpera-o-morderstwo-7359379?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T06:24:02+00:00

<img alt="Policyjny snajper oskarżony o morderstwo. Funkcjonariusze składają broń" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cr1xfv-policja-wielka-brytania-5778181/alternates/LANDSCAPE_1280" />
    Stacja BBC, powołując się na źródła, podała, że funkcjonariuszy, którzy złożyli broń, jest ponad stu.

## Hurkacz nie pomógł Europie
 - [https://eurosport.tvn24.pl/tenis/puchar-lavera-debel/2023/hubert-hurkacz-andriej-rublow-ben-shelton-frances-tiafoe-wynik-i-relacja-z-meczu-laver-cup-2023_sto9811418/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/puchar-lavera-debel/2023/hubert-hurkacz-andriej-rublow-ben-shelton-frances-tiafoe-wynik-i-relacja-z-meczu-laver-cup-2023_sto9811418/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T06:07:32+00:00

<img alt="Hurkacz nie pomógł Europie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mt7xz4-reszta-swiata-pokonala-europe-w-laver-cup-2023-7359490/alternates/LANDSCAPE_1280" />
    Reszta Świata z kolejnym tytułem w Laver Cup.

## Trener chciał go rozszarpać, a jemu trzęsła się ręka. Kluczowy moment meczu z Włoszkami
 - [https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-kluczowy-moment-meczu-polska-wlochy.-kto-wzial-challenge-siatkowk_sto9811370/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-kluczowy-moment-meczu-polska-wlochy.-kto-wzial-challenge-siatkowk_sto9811370/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T05:46:52+00:00

<img alt="Trener chciał go rozszarpać, a jemu trzęsła się ręka. Kluczowy moment meczu z Włoszkami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eglm45-siatkarki-i-sztab-po-awansie-na-igrzyska-7359478/alternates/LANDSCAPE_1280" />
    Wydarzenia z końcówki drugiej odsłony przejdą do historii polskiej siatkówki.

## Zorza polarna rozświetliła niebo nad Polską
 - [https://tvn24.pl/tvnmeteo/polska/zorza-polarna-rozswietlila-niebo-nad-polska-7359424?source=rss](https://tvn24.pl/tvnmeteo/polska/zorza-polarna-rozswietlila-niebo-nad-polska-7359424?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T05:36:30+00:00

<img alt="Zorza polarna rozświetliła niebo nad Polską" src="https://tvn24.pl/tvnmeteo/polska/cdn-zdjecie-3tiic2-zorza-polarna-kolo-pucka-2425-7359436/alternates/LANDSCAPE_1280" />
    Zdjęcia otrzymaliśmy na Kontakt 24.

## Urodzona pod bombami
 - [https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-grazyna-zielinska-urodzila-sie-w-piwnicy-podczas-powstania-warszawskiego-7357621?source=rss](https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-grazyna-zielinska-urodzila-sie-w-piwnicy-podczas-powstania-warszawskiego-7357621?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T05:13:34+00:00

<img alt="Urodzona pod bombami" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-m38132-urodzila-sie-w-piwnicy-w-czasie-powstania-warszawskiego-7357679/alternates/LANDSCAPE_1280" />
    Przyszła na świat w piwnicy podczas Powstania Warszawskiego.

## Sędzia zakończył mecz po godzinie i wtedy się zaczęło
 - [https://eurosport.tvn24.pl/pilka-nozna/eredivisie/2023-2024/ajax-feyenoord.-race-zamieszki-i-przerwany-mecz.-policja-uzyla-gazu_sto9811063/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/eredivisie/2023-2024/ajax-feyenoord.-race-zamieszki-i-przerwany-mecz.-policja-uzyla-gazu_sto9811063/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T04:52:00+00:00

<img alt="Sędzia zakończył mecz po godzinie i wtedy się zaczęło" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rfkdn1-mecz-ajax-feyenoord-zostal-przerwany-7359425/alternates/LANDSCAPE_1280" />
    Skandalem zakończył się szlagierowy mecz holenderskiej ligi pomiędzy Ajaksem Amsterdam a mistrzem kraju Feyenoordem.

## Zmarł mężczyzna ugodzony przez byka w czasie gonitwy
 - [https://tvn24.pl/swiat/hiszpania-mezczyzna-ugodzony-przez-byka-podczas-gonitwy-zmarl-po-operacji-7359403?source=rss](https://tvn24.pl/swiat/hiszpania-mezczyzna-ugodzony-przez-byka-podczas-gonitwy-zmarl-po-operacji-7359403?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T04:46:14+00:00

<img alt="Zmarł mężczyzna ugodzony przez byka w czasie gonitwy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-17cgh9-byki-6142821/alternates/LANDSCAPE_1280" />
    61-latek nie przeżył mimo szybko udzielonej pomocy.

## Motor Lublin żużlowym mistrzem Polski
 - [https://eurosport.tvn24.pl/zuzel/motor-lublin-zuzlowym-mistrzem-polski_sto9811185/story.shtml?source=rss](https://eurosport.tvn24.pl/zuzel/motor-lublin-zuzlowym-mistrzem-polski_sto9811185/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T04:31:00+00:00

<img alt="Motor Lublin żużlowym mistrzem Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vuvs7q-platinum-motor-lublin-7359432/alternates/LANDSCAPE_1280" />
    Rewanż finałowego meczu żużlowej ekstraligi należał do zawodników Platinum Motoru Lublin. Ekipa z Lubelszczyzny pokonała na wyjeździe Betard Spartę Wrocław 55:35 i zdobyła drugie w swojej historii mistrzostwo kraju.

## Jej punkt dał Polkom zwycięstwo
 - [https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-kluczowy-moment-meczu-polska-wlochy.-kto-wzial-challenge-siatkowk_sto9811372/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-kluczowy-moment-meczu-polska-wlochy.-kto-wzial-challenge-siatkowk_sto9811372/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T04:05:30+00:00

<img alt="Jej punkt dał Polkom zwycięstwo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-87hhho-radosc-lukasik-w-meczu-z-wloszkami-7359410/alternates/LANDSCAPE_1280" />
    Martyna Łukasik przez cały turniej kwalifikacyjny do igrzysk w Paryżu była podstawową przyjmującą kadry.

## Matteo Messina Denaro nie żyje
 - [https://tvn24.pl/swiat/matteo-messina-denaro-nie-zyje-szef-sycylijskiej-mafii-mial-61-lat-7359407?source=rss](https://tvn24.pl/swiat/matteo-messina-denaro-nie-zyje-szef-sycylijskiej-mafii-mial-61-lat-7359407?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-25T04:01:56+00:00

<img alt="Matteo Messina Denaro nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pmy7ay-matteo-messina-denaro-obecnie-6641312/alternates/LANDSCAPE_1280" />
    Mafioso zmarł w szpitalu w środkowych Włoszech.

