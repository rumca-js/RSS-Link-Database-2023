# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## China's food safety is at risk as bad weather strikes frequently Hailstones cancel out efforts
 - [https://www.youtube.com/watch?v=vZIPBwumxfs](https://www.youtube.com/watch?v=vZIPBwumxfs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-09-25T17:17:36+00:00

#Chinainsights#chinanews 
Recently, extreme weather has been raging in China. Hailstorms ravaged the northeastern provinces, damaging crops and vegetables and causing widespread devastation in major food-producing regions. The people lamented the hard times and worried about a future food crisis in China. Let's take a look at how the hailstorm hit each province. Here hail storms hit many parts of Jilin province. Currently, it's the fall season, the harvest time! The hailstorms have destroyed the peasants' hard-earned harvests, leaving them in tears as the government will provide no assistance.

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.


Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will 

