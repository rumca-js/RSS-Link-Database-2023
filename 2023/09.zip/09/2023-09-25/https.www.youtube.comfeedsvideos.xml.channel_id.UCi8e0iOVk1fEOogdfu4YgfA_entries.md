# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## The Exorcist: Believer - Body and the Blood (2023)
 - [https://www.youtube.com/watch?v=NY0hsgP5j40](https://www.youtube.com/watch?v=NY0hsgP5j40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-09-25T20:05:15+00:00

Check out the official movie clip for The Exorcist: Believer starring Lidya Jewett and Olivia Marcum! 
► Sign up for a Fandango FanAlert for The Exorcist: Believer: https://www.fandango.com/the-exorcist-believer-2023-231976/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: October 13, 2023
Starring: Leslie Odom Jr., Lidya Jewett, Olivia Marcum
Director: David Gordon Green
Synopsis: Two parents seek help when their respective daughters show signs of demonic possession.
► Learn more: https://www.rottentomatoes.com/m/the_exorcist_believer?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trail

## Killers of the Flower Moon Exclusive Featurette - An Inside Look (2023)
 - [https://www.youtube.com/watch?v=AXJtnoZiy0s](https://www.youtube.com/watch?v=AXJtnoZiy0s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-09-25T13:00:12+00:00

Check out a Behind the Scenes Featurette for Killers of the Flower Moon starring Leonardo DiCaprio and Lily Gladstone! 

► Buy Tickets on Fandango: https://www.fandango.com/killers-of-the-flower-moon-2023-232014/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: October 20, 2023
Starring: Brendan Fraser, Jesse Plemons, Leonardo DiCaprio, Lily Gladstone, Robert De Niro, Tantoo Cardinal
Director: Martin Scorsese
Synopsis: Members of the oil-wealthy Osage Nation are murdered under mysterious circumstances in the 1920s.
► Learn more: https://www.rottentomatoes.com/m/killers_of_the_flower_moon?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w

