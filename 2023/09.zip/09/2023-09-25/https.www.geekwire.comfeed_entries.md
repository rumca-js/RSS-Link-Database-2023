# Source:GeekWire, URL:https://www.geekwire.com/feed/, language:en-US

## Uber inks first-in-the-nation deal with Washington state for driver appeal process
 - [https://www.geekwire.com/2023/uber-inks-first-in-the-nation-deal-with-washington-state-for-driver-appeal-process/](https://www.geekwire.com/2023/uber-inks-first-in-the-nation-deal-with-washington-state-for-driver-appeal-process/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-09-25T21:50:11+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="623" src="https://cdn.geekwire.com/wp-content/uploads/2020/12/bigstock-Uber-Driver-Holding-Smartphone-345479947.jpg" width="900" /><br />A new agreement between Uber and the state of Washington creates a formal appeals process for drivers who were suspended or removed from the ride-hailing platform.

## Departing Amazon exec Dave Limp will become CEO at Jeff Bezos’ Blue Origin space venture
 - [https://www.geekwire.com/2023/departing-amazon-exec-dave-limp-will-take-over-from-blue-origin-ceo-bob-smith/](https://www.geekwire.com/2023/departing-amazon-exec-dave-limp-will-take-over-from-blue-origin-ceo-bob-smith/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-09-25T21:21:50+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="840" src="https://cdn.geekwire.com/wp-content/uploads/2019/10/1355-Summit-20191009-DD-1260x840.jpg" width="1260" /><br />Blue Origin has confirmed that Dave Limp, who is leaving his post as Amazon&#8217;s senior vice president of devices and services, will take over as the CEO of Jeff Bezos&#8217; privately held space venture. The current CEO, longtime aerospace executive Bob Smith, is retiring from the post but will stay on with Blue Origin until January to help with the transition, a company spokesperson told GeekWire in an email. Limp presided over Amazon&#8217;s Echo hardware line and its Alexa voice assistant business, among other initiatives. The most relevant initiative for Blue Origin would be his oversight of Amazon&#8217;s Project Kuiper&#8230; <a href="https://www.geekwire.com/2023/departing-amazon-exec-dave-limp-will-take-over-from-blue-origin-ceo-bob-smith/">Read More</a>

## Fire resistant, quake safe, climate friendly: Mass timber is on the rise as a construction alternative
 - [https://www.geekwire.com/2023/fire-resistant-quake-safe-climate-friendly-mass-timber-is-on-the-rise-as-a-construction-alternative/](https://www.geekwire.com/2023/fire-resistant-quake-safe-climate-friendly-mass-timber-is-on-the-rise-as-a-construction-alternative/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-09-25T19:00:00+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="799" src="https://cdn.geekwire.com/wp-content/uploads/2023/09/Heartwood-Apartments-one-bedroom-interior.png" width="1067" /><br />When Seattle&#8217;s eight-story Heartwood Apartments opens to residents this fall, it will be Washington’s tallest timber building and the first in the U.S. permitted under a set of new construction codes that allow for wooden high-rises up to 18 stories. It&#8217;s a significant milestone in America&#8217;s shift toward mass timber as a lower-carbon alternative to concrete and steel, and the Pacific Northwest is helping lead the way. Seattle architect Susan Jones is a pioneer of the U.S. movement, spearheading the creation of the new codes and demonstrating the technology&#8217;s potential. &#8220;There&#8217;s so much room for innovation and design with this&#8230; <a href="https://www.geekwire.com/2023/fire-resistant-quake-safe-climate-friendly-mass-timber-is-on-the-rise-as-a-construction

## Costco to offer healthcare services through partnership with New York startup
 - [https://www.geekwire.com/2023/costco-to-offer-healthcare-services-through-partnership-with-new-york-startup/](https://www.geekwire.com/2023/costco-to-offer-healthcare-services-through-partnership-with-new-york-startup/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-09-25T17:10:56+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="600" src="https://cdn.geekwire.com/wp-content/uploads/2023/09/bigstock-Costco-Wholesale-Location-Cos-474610949.jpg" width="900" /><br />Costco is broadening its reach into healthcare through a partnership with Sesame, a New York-based medical care marketplace startup that connects consumers directly with primary care and mental health clinicians for appointments online without insurance. Sesame announced Monday that Costco members will receive primary care visits starting at $29 and other discounts. The startup, which does not accept insurance, aims to accommodate individuals who are uninsured, have a high deductible insurance, or want to pay-per-visit. Sesame, which raised $27 million last year, has more than 3,500 clinicians on the platform who set their own price and typically work from their&#8230; <a href="https://www.geekwire.com/2023/costco-to-offer-healthcare-services-through-partnership-with-new-york-startup/">

## Hydrogen fuel startup spins out of Bill Gates-backed R&D effort, lands $7.8M
 - [https://www.geekwire.com/2023/hydrogen-fuel-startup-spins-out-of-bill-gates-backed-rd-effort-lands-7-8m/](https://www.geekwire.com/2023/hydrogen-fuel-startup-spins-out-of-bill-gates-backed-rd-effort-lands-7-8m/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-09-25T16:52:22+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="333" src="https://cdn.geekwire.com/wp-content/uploads/2023/09/Peregrine-Hydrogen-team-photo.png" width="1014" /><br />Peregrine Hydrogen, a Santa Cruz, Calif., startup developing technology for producing clean hydrogen fuel, raised $7.8 million in seed financing. The company is aiming to manufacture climate friendly hydrogen that is cost competitive with dirtier fuel made from methane. Its strategy includes using electrolyzing technology to produce valuable industrial chemicals alongside hydrogen. Bill Gates connection: Peregrine spun out of Orca Sciences, a climate-focused R&#38;D incubator funded by Bill Gates and now affiliated with his Breakthrough Energy organization. Gates Frontier, the Microsoft co-founder&#8217;s investment firm, contributed to the seed round. The team: Peregrine&#8217;s CEO and co-founder is Friðrik Lárusson, a Seattle-based&#8230; <a href="https://www.geekwire.com/2023/hydrogen-fuel-startup-sp

## Fuse raises $250M for its second fund to supercharge more Pacific Northwest startups
 - [https://www.geekwire.com/2023/fuse-raises-250m-for-its-second-fund-to-supercharge-more-pacific-northwest-startups/](https://www.geekwire.com/2023/fuse-raises-250m-for-its-second-fund-to-supercharge-more-pacific-northwest-startups/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-09-25T16:03:06+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="840" src="https://cdn.geekwire.com/wp-content/uploads/2023/09/processed-F451461A-1536-45DE-A31F-7FA29BE6C9E1-0CC97E63-56E1-494C-8CCE-C79CE26564EF-1260x840.jpeg" width="1260" /><br />Fuse is pouring more fuel on its fire. The Seattle-area venture capital firm raised $250 million for its second fund, a major swath of cash that will support early stage enterprise software startups across the Pacific Northwest. GeekWire previously reported on the fund last year. It&#8217;s one of the largest funds ever raised by a venture capital firm in the Seattle region, where Fuse plans to double down on its investments. &#8220;We&#8217;re super fired up about the density of talent here and the resulting entrepreneurs starting companies here,&#8221; Kellan Carter, general partner at Fuse, said in an interview with GeekWire.&#8230; <a href="https://www.geekwire.com/2023/fuse-raises-250m-for-its-second-fund-to-supercharge-more-pacific-nor

## Meet the Seattle-area startups that just graduated from Y Combinator
 - [https://www.geekwire.com/2023/meet-3-seattle-startups-that-just-graduated-from-y-combinator/](https://www.geekwire.com/2023/meet-3-seattle-startups-that-just-graduated-from-y-combinator/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-09-25T15:24:54+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="840" src="https://cdn.geekwire.com/wp-content/uploads/2023/09/S23-Event-Brian-Chesky_19-1260x840.jpg" width="1260" /><br />Seattle-area startups that just graduated from Y Combinator&#8217;s summer 2023 batch are tackling a wide range of problems — with plenty of help from artificial intelligence. The companies include: Founded in 2005, YC is one of the leading startup accelerators. Airbnb, Stripe, DoorDash, Instacart, Reddit, Twitch, and many others went through the program. More than 90 of its graduates are now valued at more than $1 billion. Seattle startups to graduate from YC include LifeAt, ShelfEngine, Strac, Needl, Humanly, and others. YC received more than 24,000 applications for this year&#8217;s summer batch. It funded 229 companies, down from last year&#8217;s 240.&#8230; <a href="https://www.geekwire.com/2023/meet-3-seattle-startups-that-just-graduated-from-y-combinator/">Read More</a>

## Amazon pours up to $4B into AI startup Anthropic, escalating rivalry with Microsoft and Google
 - [https://www.geekwire.com/2023/amazon-pours-up-to-4b-into-ai-startup-anthropic-boosting-rivalry-with-microsoft-and-google/](https://www.geekwire.com/2023/amazon-pours-up-to-4b-into-ai-startup-anthropic-boosting-rivalry-with-microsoft-and-google/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-09-25T11:17:21+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="533" src="https://cdn.geekwire.com/wp-content/uploads/2023/09/anthropic.jpg" width="799" /><br />Amazon will invest up to $4 billion and take a minority stake in Anthropic, the San Francisco-based artificial intelligence company founded two years ago by former OpenAI executives and considered one of the world&#8217;s top AI labs. Anthropic makes large-scale AI models and a chatbot called Claude. The company&#8217;s founders split from OpenAI after becoming concerned that the ChatGPT maker was becoming too commercial. Its founders include siblings Dario Amodei and Daniela Amodei, who led OpenAI&#8217;s engineering and policy/safety teams, respectively. The investment and expanded partnership includes a commitment by Anthropic to make Amazon Web Services its main cloud provider.&#8230; <a href="https://www.geekwire.com/2023/amazon-pours-up-to-4b-into-ai-startup-anthropic-boosting-rivalry-with-microsoft-and-google/">Read M

