# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## A US gov’t shutdown could negatively affect its credit, Moody’s warns
 - [https://www.aljazeera.com/economy/2023/9/25/a-us-govt-shutdown-could-negatively-affect-its-credit-moodys-warns?traffic_source=rss](https://www.aljazeera.com/economy/2023/9/25/a-us-govt-shutdown-could-negatively-affect-its-credit-moodys-warns?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T22:18:20+00:00

A shutdown is possible if Congress fails to provide funding for the fiscal year starting October 1.

## Six dead, 12 missing in Guatemala landslides after heavy rain
 - [https://www.aljazeera.com/news/2023/9/25/three-dead-15-missing-in-guatemala-landslides-after-heavy-rain?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/three-dead-15-missing-in-guatemala-landslides-after-heavy-rain?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T22:09:21+00:00

Six homes have been swept away by the swollen Naranjo River in Guatemala City, with eight children among the missing.

## Texas cities struggle to address influx of arrivals along US-Mexico border
 - [https://www.aljazeera.com/news/2023/9/25/texas-cities-struggle-to-address-influx-of-arrivals-along-us-mexico-border?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/texas-cities-struggle-to-address-influx-of-arrivals-along-us-mexico-border?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T22:06:22+00:00

The administration of US President Joe Biden has reached out to Mexico for help confronting the spike in migration.

## Four tombs unearthed at Roman-era cemetery in Gaza
 - [https://www.aljazeera.com/news/2023/9/25/four-tombs-unearthed-at-roman-era-cemetery-in-gaza?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/four-tombs-unearthed-at-roman-era-cemetery-in-gaza?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T20:57:29+00:00

The discovery represents the first fully unearthed and complete Roman necropolis in Gaza.

## Israel foreign minister says US will allow visa-free travel for Israelis
 - [https://www.aljazeera.com/news/2023/9/25/israel-foreign-minister-says-us-will-allow-visa-free-travel-for-israelis?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/israel-foreign-minister-says-us-will-allow-visa-free-travel-for-israelis?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T20:10:40+00:00

US rights advocates oppose Israel&#039;s entry into Visa Waiver Program because of its treatment of Arab Americans.

## US and Kenya sign defence deal ahead of possible Haiti mission
 - [https://www.aljazeera.com/news/2023/9/25/us-and-kenya-sign-defence-deal-ahead-of-possible-haiti-mission?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/us-and-kenya-sign-defence-deal-ahead-of-possible-haiti-mission?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T19:59:29+00:00

Kenyan Defence Minister Aden Duale says country ready to deploy to Haiti to help tackle gang violence.

## Kosovo demands Serbia hand over escaped Serb gunmen after deadly shootout
 - [https://www.aljazeera.com/news/2023/9/25/kosovo-demands-serbia-hand-over-escaped-serb-gunmen?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/kosovo-demands-serbia-hand-over-escaped-serb-gunmen?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T19:50:22+00:00

One police officer and three attackers were killed after gunmen stormed the village of Banjska in northern Kosovo.

## Does the latest violence in Kosovo pose a risk to peace efforts?
 - [https://www.aljazeera.com/program/inside-story/2023/9/25/does-the-latest-violence-in-kosovo-pose-a-risk-to-peace-efforts?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2023/9/25/does-the-latest-violence-in-kosovo-pose-a-risk-to-peace-efforts?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T18:46:27+00:00

The shooting of a police officer leads to a siege at a monastery where three attackers are killed.

## Sex assault claims against Russell Brand being investigated, UK police says
 - [https://www.aljazeera.com/news/2023/9/25/sex-assault-claims-against-russell-brand-being-investigated-uk-police-says?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/sex-assault-claims-against-russell-brand-being-investigated-uk-police-says?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T18:45:55+00:00

London&#039;s Metropolitan Police says they are investigating allegations made in London and other parts of the country.

## Libya’s top prosecutor orders eight officials arrested after flood disaster
 - [https://www.aljazeera.com/news/2023/9/25/libyas-top-prosecutor-orders-eight-officials-arrested-after-flood-disaster?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/libyas-top-prosecutor-orders-eight-officials-arrested-after-flood-disaster?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T18:21:39+00:00

Mayor of Derna and officials from the Water Resources Authority and Dams Management Authority are ordered to barrested.

## Gymnastics Ireland ‘deeply sorry’ to Black girl ignored at medal ceremony
 - [https://www.aljazeera.com/sports/2023/9/25/gymnastics-ireland-apologises-to-black-girl-ignored-at-medal-ceremony?traffic_source=rss](https://www.aljazeera.com/sports/2023/9/25/gymnastics-ireland-apologises-to-black-girl-ignored-at-medal-ceremony?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T16:41:14+00:00

Footage showed the official appearing to snub the girl, the only Black gymnast in a medal lineup.

## US Senator Menendez says he will be exonerated in bribery indictment
 - [https://www.aljazeera.com/news/2023/9/25/us-senator-menendez-says-he-will-be-exonerated-in-bribery-indictment?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/us-senator-menendez-says-he-will-be-exonerated-in-bribery-indictment?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T16:40:39+00:00

Bob Menendez faces calls to step down amid allegations he took bribes, used influence on behalf of Egyptian government.

## Egypt to hold presidential vote in December as economic crisis worsens
 - [https://www.aljazeera.com/news/2023/9/25/egypt-to-hold-presidential-vote-in-december-as-economic-crisis-worsens?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/egypt-to-hold-presidential-vote-in-december-as-economic-crisis-worsens?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T16:20:25+00:00

Incumbent President Abdel Fattah el-Sisi is widely expected to win despite dire economic situation facing the country.

## Unpacking India-Canada tensions amid Trudeau’s bombshell allegations
 - [https://www.aljazeera.com/news/2023/9/25/unpacking-india-canada-tensions-amid-trudeaus-bombshell-allegations?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/unpacking-india-canada-tensions-amid-trudeaus-bombshell-allegations?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T15:47:39+00:00

A week after Canada accused India of being tied to Sikh leader&#039;s killing, fears over safety and polarisation grow.

## US recognises Cook Islands, Niue as Biden hosts Pacific Island leaders
 - [https://www.aljazeera.com/news/2023/9/25/us-recognises-cook-islands-niue-as-biden-hosts-pacific-island-leaders?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/us-recognises-cook-islands-niue-as-biden-hosts-pacific-island-leaders?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T14:45:33+00:00

US president is hosting Pacific Island leaders for two-day summit amid intensifying competition with China in region.

## Russian media rhetoric could be ‘incitement to genocide in Ukraine’: UN
 - [https://www.aljazeera.com/news/2023/9/25/russian-media-rhetoric-could-be-incitement-to-genocide-in-ukraine-un?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/russian-media-rhetoric-could-be-incitement-to-genocide-in-ukraine-un?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T14:34:49+00:00

Some rhetoric disseminated by Russian media could amount to incitement to genocide, the Human Rights Council probe says.

## History Illustrated: Barbarossa and the Battle of Preveza
 - [https://www.aljazeera.com/gallery/2023/9/25/history-illustrated-barbarossa-and-the-battle-of-preveza?traffic_source=rss](https://www.aljazeera.com/gallery/2023/9/25/history-illustrated-barbarossa-and-the-battle-of-preveza?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T14:07:39+00:00

The red-bearded admiral proved invaluable to the Ottomans in the Mediterranean battle between Muslims and Christians.

## The West has a moral responsibility to help build peace in Nagorno-Karabakh
 - [https://www.aljazeera.com/opinions/2023/9/25/the-west-has-a-moral-responsibility-to-help-build-peace-in-nagorno-karabakh?traffic_source=rss](https://www.aljazeera.com/opinions/2023/9/25/the-west-has-a-moral-responsibility-to-help-build-peace-in-nagorno-karabakh?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T13:58:20+00:00

International inaction has allowed for a tragic cycle of violence and displacement. It is high time to change course.

## India beat Sri Lanka to win maiden women’s cricket gold at Asian Games
 - [https://www.aljazeera.com/sports/2023/9/25/india-beat-sri-lanka-to-win-womens-cricket-gold-at-asian-games?traffic_source=rss](https://www.aljazeera.com/sports/2023/9/25/india-beat-sri-lanka-to-win-womens-cricket-gold-at-asian-games?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T13:35:36+00:00

Indian women&#039;s team beat in-form Sri Lanka by 19 runs, while Bangladesh beat Pakistan by five wickets for bronze.

## In Tunisia, a dance show celebrates ‘people with all types of differences’
 - [https://www.aljazeera.com/features/2023/9/25/in-tunisia-a-dance-show-celebrates-people-with-all-types-of-differences?traffic_source=rss](https://www.aljazeera.com/features/2023/9/25/in-tunisia-a-dance-show-celebrates-people-with-all-types-of-differences?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T13:20:01+00:00

A new dance show in Tunisia is seeking to celebrate diversity by breaking stereotypes surrounding marginalised people.

## Mali postpones February presidential election due to ‘technical issues’
 - [https://www.aljazeera.com/news/2023/9/25/mali-postpones-february-presidential-election-due-to-technical-issues?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/mali-postpones-february-presidential-election-due-to-technical-issues?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T13:13:09+00:00

Government spokesman cites technical reasons linked to the adoption of a new constitution in a June 18 referendum.

## Hollywood writers near end of months-long strike. What happens next?
 - [https://www.aljazeera.com/news/2023/9/25/hollywood-writers-near-end-of-months-long-strike-what-happens-next?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/hollywood-writers-near-end-of-months-long-strike-what-happens-next?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T13:10:05+00:00

If writers approve tentative deal, work on some Hollywood shows could resume quickly. Here&#039;s all you need to know.

## All you need to know about the ICC Cricket World Cup 2023
 - [https://www.aljazeera.com/sports/2023/9/25/icc-cricket-world-cup-2023-india-all-you-need-to-know-preview?traffic_source=rss](https://www.aljazeera.com/sports/2023/9/25/icc-cricket-world-cup-2023-india-all-you-need-to-know-preview?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T13:03:14+00:00

Ten teams vie for the 2023 ICC Cricket World Cup, hosted by India from October 5 to November 19.

## Erdogan meeting Azerbaijan’s Aliyev as thousands flee Nagorno-Karabakh
 - [https://www.aljazeera.com/news/2023/9/25/erdogan-meeting-azerbaijans-aliyev-as-thousands-flee-karabakh?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/erdogan-meeting-azerbaijans-aliyev-as-thousands-flee-karabakh?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T12:02:55+00:00

Turkish president will visit Azerbaijan&#039;s autonomous Nakhchivan exclave in a show of solidarity with his ally.

## ‘Climate change killed my family’: Unusual monsoon hammers India’s Himachal
 - [https://www.aljazeera.com/news/2023/9/25/climate-change-killed-my-family-unusual-monsoon-hammers-indias-himachal?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/climate-change-killed-my-family-unusual-monsoon-hammers-indias-himachal?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T11:43:38+00:00

Record-breaking torrential rain leaves trail of unprecedented devastation in northern India&#039;s Himachal Pradesh state.

## Report says Antarctica witnessed world’s most intense heatwave in 2022
 - [https://www.aljazeera.com/news/2023/9/25/report-says-antarctica-witnessed-worlds-most-intense-heatwave-in-2022?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/report-says-antarctica-witnessed-worlds-most-intense-heatwave-in-2022?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T11:43:17+00:00

Scientists recorded the world&#039;s most intense heatwave in Antarctica, with a record spike last year.

## Tourism’s dark side: Are those who love Greece killing it?
 - [https://www.aljazeera.com/features/2023/9/25/tourisms-dark-side-are-those-who-love-greece-killing-it?traffic_source=rss](https://www.aljazeera.com/features/2023/9/25/tourisms-dark-side-are-those-who-love-greece-killing-it?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T11:21:51+00:00

Greece’s population is shrinking, and tourism - its biggest economic success story - is making matters worse.

## US has failed to compensate tortured victims of its Iraq prisons: HRW
 - [https://www.aljazeera.com/news/2023/9/25/us-has-failed-to-compensate-tortured-victims-of-its-iraq-prisons-hrw?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/us-has-failed-to-compensate-tortured-victims-of-its-iraq-prisons-hrw?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T10:26:15+00:00

The US has failed to redress Iraqis who suffered from systemic torture and abuse in its prisons during the invasion.

## Kasselakis, a political unknown and ex-banker, wins race to lead Greek left
 - [https://www.aljazeera.com/news/2023/9/25/kasselakis-a-political-unknown-and-ex-banker-wins-race-to-lead-greek-left?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/kasselakis-a-political-unknown-and-ex-banker-wins-race-to-lead-greek-left?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T10:13:11+00:00

At 35, Stefanos Kasselakis, who is openly gay, campaigned heavily on social media to win the Syriza vote.

## Somaliland rejects talk of unification with Somalia after Museveni comment
 - [https://www.aljazeera.com/news/2023/9/25/somaliland-rejects-talk-of-unification-with-somalia-after-museveni-comment?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/somaliland-rejects-talk-of-unification-with-somalia-after-museveni-comment?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T10:02:36+00:00

Sonaliland said it has no plans to discuss unity with Somalia despite Uganda&#039;s talk of acting as &#039;unification mediator&#039;.

## NASA’s OSIRIS-REx has delivered an asteroid sample on Earth. What next?
 - [https://www.aljazeera.com/news/2023/9/25/nasas-osiris-rex-has-delivered-an-asteroid-sample-on-earth-what-next?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/nasas-osiris-rex-has-delivered-an-asteroid-sample-on-earth-what-next?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T10:01:59+00:00

Scientists will analyse the asteroid sample to investigate the origins of life on Earth.

## Dozens of migrants and refugees arrive at US-Mexico border
 - [https://www.aljazeera.com/gallery/2023/9/25/dozens-of-migrants-and-refugees-arrive-at-us-mexico-border?traffic_source=rss](https://www.aljazeera.com/gallery/2023/9/25/dozens-of-migrants-and-refugees-arrive-at-us-mexico-border?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T09:16:36+00:00

People crossed the Rio Grande River to encounter an almost impassable wall of razor-sharp barbed wire.

## China defends South China Sea ‘floating barrier’ as Manila eyes its removal
 - [https://www.aljazeera.com/news/2023/9/25/china-defends-south-china-sea-floating-barrier-as-manila-vows-to-remove?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/china-defends-south-china-sea-floating-barrier-as-manila-vows-to-remove?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T09:07:11+00:00

Beijing says its coastguard took necessary measures in accordance with law to drive away a Philippine vessel.

## Second round of negotiations on Ethiopia’s mega-dam wrap up
 - [https://www.aljazeera.com/news/2023/9/25/second-round-of-negotiations-on-ethiopias-mega-dam-wrap-up?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/second-round-of-negotiations-on-ethiopias-mega-dam-wrap-up?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T08:56:04+00:00

Protracted negotiations over the dam have so far failed to bring about an agreement between Ethiopia, Sudan and Egypt.

## Missing Pakistani journalist Imran Riaz Khan returns home after four months
 - [https://www.aljazeera.com/news/2023/9/25/missing-pakistani-journalist-imran-riaz-khan-returns-home-after-four-months?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/missing-pakistani-journalist-imran-riaz-khan-returns-home-after-four-months?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T08:54:32+00:00

The former TV anchor with more than three million followers on YouTube was arrested in May while on his way to Oman.

## Hundreds of refugees from Nagorno-Karabakh flee to Armenia
 - [https://www.aljazeera.com/gallery/2023/9/25/hundreds-of-refugees-from-nagorno-karabakh-flee-to-armenia?traffic_source=rss](https://www.aljazeera.com/gallery/2023/9/25/hundreds-of-refugees-from-nagorno-karabakh-flee-to-armenia?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T08:41:52+00:00

Ethnic Armenians begin an exodus in the South Caucasus after Azerbaijan defeats the breakaway region&#039;s fighters.

## India visa delay disrupts Pakistan’s Cricket World Cup 2023 preparations
 - [https://www.aljazeera.com/news/2023/9/25/india-visa-delay-disrupts-pakistans-cricket-world-cup-2023-preparations?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/india-visa-delay-disrupts-pakistans-cricket-world-cup-2023-preparations?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T08:22:17+00:00

Pakistan Cricket Board cancels team bonding session in Dubai as it awaits Indian visa 10 days before the tournament.

## Ajax vs Feyenoord abandoned after flares thrown, rioting outside stadium
 - [https://www.aljazeera.com/sports/2023/9/25/ajax-vs-feyenoord-abandoned-after-flares-thrown-rioting-outside-stadium?traffic_source=rss](https://www.aljazeera.com/sports/2023/9/25/ajax-vs-feyenoord-abandoned-after-flares-thrown-rioting-outside-stadium?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T08:15:31+00:00

Ajax were trailing 3-0 in their home Eredivisie game against the defending champions when it was suspended.

## Major asteroid sample brought to Earth in NASA first
 - [https://www.aljazeera.com/gallery/2023/9/25/major-asteroid-sample-brought-to-earth-in-nasa-first?traffic_source=rss](https://www.aljazeera.com/gallery/2023/9/25/major-asteroid-sample-brought-to-earth-in-nasa-first?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T07:43:04+00:00

NASA’s first asteroid sample from deep space parachutes into the Utah desert to cap a seven-year journey.

## ‘Deepest apologies’: Canada official backtracks after Ukraine Nazi honoured
 - [https://www.aljazeera.com/news/2023/9/25/canada-house-speaker-apologises-for-recognition-of-veteran-linked-to?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/canada-house-speaker-apologises-for-recognition-of-veteran-linked-to?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T07:40:09+00:00

Yaroslav Hunka, 98, was honoured as a &#039;Ukrainian hero&#039; at Canada&#039;s Parliament, with Zelenskyy and Trudeau attending.

## Trudeau’s India crisis shows he has lost control of Canada’s spies
 - [https://www.aljazeera.com/opinions/2023/9/25/trudeaus-india-crisis-shows-he-has-lost-control-of-canadas-spies?traffic_source=rss](https://www.aljazeera.com/opinions/2023/9/25/trudeaus-india-crisis-shows-he-has-lost-control-of-canadas-spies?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T06:42:52+00:00

Anonymous spooks are getting their way, whatever the consequences, when Trudeau should be investigating their failures.

## Jailed Italian Mafia boss Matteo Messina Denaro is dead: Reports
 - [https://www.aljazeera.com/news/2023/9/25/jailed-italian-mafia-boss-matteo-messina-denaro-is-dead-reports?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/jailed-italian-mafia-boss-matteo-messina-denaro-is-dead-reports?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T05:03:25+00:00

Ex-head of Cosa Nostra mob died in hospital in central Italy after slipping into an &#039;irreversible coma&#039;, report says.

## ‘Rock bottom’: Australia faces exit after Rugby World Cup defeat to Wales
 - [https://www.aljazeera.com/sports/2023/9/25/rock-bottom-australia-faces-exit-after-rugby-world-cup-defeat-to-wales?traffic_source=rss](https://www.aljazeera.com/sports/2023/9/25/rock-bottom-australia-faces-exit-after-rugby-world-cup-defeat-to-wales?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T04:53:15+00:00

Despair as Wallabies look set to exit tournament at the pool stage for the first tine after humiliating 40-6 rout.

## Hollywood writers reach tentative deal with studios to end strike
 - [https://www.aljazeera.com/news/2023/9/25/hollywood-writers-reach-tentative-deal-with-studios-to-end-strike?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/hollywood-writers-reach-tentative-deal-with-studios-to-end-strike?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T04:15:23+00:00

Writers union says the new deal is &#039;exceptional&#039; with &#039;meaningful gains and protections for writers&#039;.

## ‘Baby steps’ for ASEAN as it wraps up first-ever joint military drills
 - [https://www.aljazeera.com/news/2023/9/25/baby-steps-for-asean-as-it-wraps-up-first-ever-joint-military-drills?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/baby-steps-for-asean-as-it-wraps-up-first-ever-joint-military-drills?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T04:14:04+00:00

The exercise focused on humanitarian relief as the regional grouping makes tentative steps towards military cooperation.

## US to open embassies in the Cook Islands, Niue
 - [https://www.aljazeera.com/news/2023/9/25/us-to-open-embassies-in-the-cook-islands-niue?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/us-to-open-embassies-in-the-cook-islands-niue?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T02:50:14+00:00

Announcement comes as US President Joe Biden prepares to host a second summit with Pacific Island leaders in Washington

## Russia-Ukraine war: List of key events, day 579
 - [https://www.aljazeera.com/news/2023/9/25/russia-ukraine-war-list-of-key-events-day-579?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/russia-ukraine-war-list-of-key-events-day-579?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T01:33:30+00:00

As the war enters its 579th day, these are the main developments.

## ‘Still my people’: Myanmar diaspora supports democracy struggle back home
 - [https://www.aljazeera.com/news/2023/9/25/still-my-people-myanmar-diaspora-supports-democracy-struggle-back-home?traffic_source=rss](https://www.aljazeera.com/news/2023/9/25/still-my-people-myanmar-diaspora-supports-democracy-struggle-back-home?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-25T00:29:33+00:00

Spurred to action by the 2021 coup, Myanmar nationals overseas are helping sustain the movement to restore democracy.

