# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Amerykańskie obligacje najtańsze od 16 lat. Wall Street nie reaguje
 - [https://www.bankier.pl/wiadomosc/Amerykanskie-obligacje-najtansze-od-16-lat-8617490.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amerykanskie-obligacje-najtansze-od-16-lat-8617490.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T20:56:51.153343+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/8/59e07a74d17eb3-948-568-225-112-2775-1664.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rentowność 10-letnich Treasuries
osiągnęła poziom widziany po raz ostatni w roku 2007. Tak rynek „trawi” nowe fedowskie
motto: „wyżej na dłużej”.</p>

## Premier: Za 4-8 lat będziemy mogli żyć na poziomie państw Zachodu, ale bez ich błędów
 - [https://www.bankier.pl/wiadomosc/Premier-Za-4-8-lat-bedziemy-mogli-zyc-na-poziomie-panstw-Zachodu-ale-bez-ich-bledow-8617426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-Za-4-8-lat-bedziemy-mogli-zyc-na-poziomie-panstw-Zachodu-ale-bez-ich-bledow-8617426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T17:41:52.160731+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/55fcce023e5daf-948-568-11-286-4390-2634.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Za 4-8 lat będziemy mogli żyć na poziomie państw Zachodu, ale bez koszmarnych błędów, bez hord muzułmańskich migrantów, bez rewolucji światopoglądowych - zapowiedział premier Mateusz Morawiecki w Kraśniku. Zauważył, że w czasach rządów PiS, pierwszy raz od 200 lat Polacy wracają masowo z emigracji.</p>

## Premier do kanclerza Niemiec: niech się pan nie wtrąca w polskie sprawy
 - [https://www.bankier.pl/wiadomosc/Premier-do-kanclerza-Niemiec-niech-sie-pan-nie-wtraca-w-polskie-sprawy-8617411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-do-kanclerza-Niemiec-niech-sie-pan-nie-wtraca-w-polskie-sprawy-8617411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T17:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/53bc218b80e558-948-568-0-30-3970-2381.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To, co teraz mówi kanclerz Niemiec, być może jest przygotowaniem pod scenariusz zamknięcia granicy; niech pan dowie się, jaka jest faktyczna sytuacja i nie wtrąca w polskie sprawy - powiedział w Kraśniku (Lubelskie) premier Mateusz Morawiecki.</p>

## Kontrole na granicy polsko-słowackiej. Premier wydał polecenie
 - [https://www.bankier.pl/wiadomosc/Kontrole-na-granicy-polsko-slowackiej-Premier-wydal-polecenie-8617403.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kontrole-na-granicy-polsko-slowackiej-Premier-wydal-polecenie-8617403.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T16:36:51.474673+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/c8ad16b415e22b-948-568-0-44-1600-959.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poleciłem ministrowi spraw wewnętrznych i administracji, aby wprowadzać kontrole na granicy polsko-słowackiej busików, busów, samochodów, autobusów, które można podejrzewać o to, że tamtędy migrują nielegalni imigranci - powiedział w poniedziałek w Kraśniku (woj. lubelskie) premier Mateusz Morawiecki.</p>

## Spadki na otwarciu tygodnia. Honor WIG20 uratowały 3 spółki
 - [https://www.bankier.pl/wiadomosc/Sesja-na-GPW-25-09-Na-plusie-tylko-3-spolki-z-WIG20-8617336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sesja-na-GPW-25-09-Na-plusie-tylko-3-spolki-z-WIG20-8617336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T16:36:51.439121+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/0749cea39a84a6-945-560-0-0-3100-1859.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gdyby nie 3 spółki, poniedziałek na czerwono zakończyłby cały WIG20. Indeks blue chipów GPW "zachował twarz" dzięki LPP, CD Projekt oraz Dino Polska. Po drugiej stronie znalazło się Allegro, którego akcje są w tej chwili na największej "promocji" od 6 miesięcy.</p>

## Media: Firma powiązana z szefem wywiadu SWR handluje z USA, Kanadą i krajami UE
 - [https://www.bankier.pl/wiadomosc/Media-Firma-powiazana-z-szefem-wywiadu-SWR-handluje-z-USA-Kanada-i-krajami-UE-8617315.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-Firma-powiazana-z-szefem-wywiadu-SWR-handluje-z-USA-Kanada-i-krajami-UE-8617315.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T15:31:49.940058+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/dfa639595ddf16-948-568-0-113-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Firma powiązana z szefem rosyjskiego wywiadu zagranicznego (SWR) Siergiejem Naryszkinem handluje na dużą skalę produktami spożywczymi z krajami UE, Kanadą i USA - poinformował portal Insider.</p>

## USA udzielą pożyczki na wsparcie modernizacji obronności Polski
 - [https://www.bankier.pl/wiadomosc/USA-udziela-pozyczki-na-wsparcie-modernizacji-obronnosci-Polski-8617310.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-udziela-pozyczki-na-wsparcie-modernizacji-obronnosci-Polski-8617310.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T15:31:49.923348+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/e/9922e6658e642b-948-568-0-55-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stany Zjednoczone z dumą ogłaszają podpisanie ważnej umowy pożyczki o wartości 2 miliardów dolarów w ramach Zagranicznego Finansowania Wojskowego (FMF), w celu wsparcia modernizacji obronności Polski - przekazał w poniedziałek ambasador USA w Polsce Mark Brzezinski.</p>

## NBP opublikował założenia polityki pieniężnej na rok 2024. Cel inflacyjny na poziomie 2,5 proc.
 - [https://www.bankier.pl/wiadomosc/NBP-opublikowal-zalozenia-polityki-pienieznej-na-rok-2024-8617292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-opublikowal-zalozenia-polityki-pienieznej-na-rok-2024-8617292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T15:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/a/2e2828daff0496-948-568-0-645-4608-2764.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />RPP podtrzymuje strategię średniookresowego celu inflacyjnego na poziomie 2,5 proc. z symetrycznym przedziałem odchyleń +/- 1 pkt. proc. - wynika z opublikowanych przez NBP "Założeń polityki pieniężnej" na 2024 r.</p>

## Resort finansów podnosi preferencyjną marżę obligacji 2-letnich
 - [https://www.bankier.pl/wiadomosc/Resort-finansow-podnosi-preferencyjna-marze-obligacji-2-letnich-8617280.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Resort-finansow-podnosi-preferencyjna-marze-obligacji-2-letnich-8617280.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T14:26:46.858057+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/8/7a3cbd471dacc1-948-568-0-6-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Finansów podniosło preferencyjną marżę październikowych obligacji 2-letnich, których oprocentowanie wynika ze stopy referencyjnej NBP i marże dla obligacji 4-, 6-, 10 i 12-letnich, których oprocentowanie uzależnione jest od inflacji - poinformował w poniedziałek resort.</p>

## Analitycy PKO BP: Ceny mieszkań w perspektywie roku mogą wzrosnąć o 10-15 proc.
 - [https://www.bankier.pl/wiadomosc/Analitycy-PKO-BP-Ceny-mieszkan-w-perspektywie-roku-moga-wzrosnac-o-10-15-proc-8617099.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Analitycy-PKO-BP-Ceny-mieszkan-w-perspektywie-roku-moga-wzrosnac-o-10-15-proc-8617099.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T14:26:46.848026+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/06b8e7bceb1f45-948-568-0-264-4608-2764.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Średnie ceny transakcyjne mieszkań w perspektywie roku, czyli w okresie od trzeciego kwartału tego roku do końca drugiego kwartału 2024 r., mogą wzrosnąć o 10-15 proc. - ocenili w raporcie analitycy PKO BP.</p>

## Prokuratura wyjaśnia sprawę napaści na posłankę KO
 - [https://www.bankier.pl/wiadomosc/Prokuratura-wyjasnia-sprawe-napasci-na-poslanke-KO-8617207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prokuratura-wyjasnia-sprawe-napasci-na-poslanke-KO-8617207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T13:24:36.349690+00:00

<p>Prokuratura bada sprawę napaści na posłankę KO Martę Wcisło na targu w Opolu Lubelskim. W poniedziałek posłanka poinformowała, że nieznany mężczyzna zaczął ją szarpać, wyzywać i grozić jej.</p>

## Jeszcze kilka dni z 10 proc. na koncie oszczędnościowym. Kolejna stawka też jest atrakcyjna
 - [https://www.bankier.pl/wiadomosc/10-proc-na-koncie-oszczednosciowym-Raiffeisen-Digital-Banku-jeszcze-przez-kilka-dni-8615789.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/10-proc-na-koncie-oszczednosciowym-Raiffeisen-Digital-Banku-jeszcze-przez-kilka-dni-8615789.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T13:24:36.322285+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/2/12f2e682f99e2b-948-568-0-0-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spadające stawki na kontach oszczędnościowych i lokatach zachęcają do poszukiwania okazji. Jedną z nich jest Konto Oszczędnościowe Start w Raiffeisen Digital Banku, które jeszcze przez kilka dni ma stawkę w wysokości 10 proc. w skali roku. Bank zakładającym teraz rachunek obiecuje jednak jeszcze kilka miesięcy z atrakcyjnym oprocentowaniem.</p>

## BFG otrzymał niewiążące oferty kupna VeloBanku
 - [https://www.bankier.pl/wiadomosc/BFG-otrzymal-niewiazace-oferty-kupna-VeloBanku-8617132.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/BFG-otrzymal-niewiazace-oferty-kupna-VeloBanku-8617132.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T12:19:40.466779+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/a/7be27c788055ca-948-568-100-110-3900-2339.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bankowy Fundusz Gwarancyjny otrzymał niewiążące oferty kupna VeloBanku - wynika z poniedziałkowego komunikatu BFG.</p>

## 10 najlepszych kont firmowych dla nowoczesnego biznesu – wrzesień 2023 r.
 - [https://www.bankier.pl/wiadomosc/10-najlepszych-kont-firmowych-dla-nowoczesnego-biznesu-wrzesien-2023-r-8617049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/10-najlepszych-kont-firmowych-dla-nowoczesnego-biznesu-wrzesien-2023-r-8617049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T12:19:40.450315+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/3477b033ddc0c2-948-568-0-226-4772-2863.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Konto firmowe z niskimi opłatami jest pożądanym produktem. Przedsiębiorcy zwracają również uwagę na dostęp do nowoczesnych rozwiązań umożliwiających m.in. płatności telefonem. Przeanalizowaliśmy oferty kont dla osób prowadzących działalność, które poszukują jak najniższych kosztów za podstawowe usługi oraz dostępu do dodatkowych rozwiązań.</p>

## Wieże Kaczyńskiego i 50 tys. złotych w kopercie. Oto zeznania austriackiego biznesmena
 - [https://www.bankier.pl/wiadomosc/Wieze-Kaczynskiego-i-50-tys-zlotych-w-kopercie-Oto-zeznania-austriackiego-biznesmena-8617151.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wieze-Kaczynskiego-i-50-tys-zlotych-w-kopercie-Oto-zeznania-austriackiego-biznesmena-8617151.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T12:19:40.443489+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/0/1f23be34d70fb0-945-567-11-67-1488-893.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prokuratura robiła wszystko, by sprawę ws. "wież Kaczyńskiego" szybko umorzyć. Jarosława Kaczyńskiego w tej sprawie nigdy nie przesłuchała, nawet jako świadka - informuje "Gazeta Wyborcza". Portal publikuje przy okazji stenogramy z zeznań Geralda Birgfellnera, austriackiego biznesmena, który tą miał przygotować budowę wież.</p>

## Pokoje drogie, a akademików brak. Włoscy studenci wracają do protestu
 - [https://www.bankier.pl/wiadomosc/Pokoje-drogie-a-akademikow-brak-Wloscy-studenci-wracaja-do-protestu-8617071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pokoje-drogie-a-akademikow-brak-Wloscy-studenci-wracaja-do-protestu-8617071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T11:14:32.226460+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/4/5a384683e25a85-948-568-0-101-3679-2207.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Studenci w Rzymie i Mediolanie ponownie rozbili namioty przed siedzibami uniwersytetów na znak protestu przeciwko brakowi miejsc w akademikach i wysokim cenom wynajmu pokojów. Tym samym wznowili akcję z wiosny, po której rząd Włoch obiecał wyasygnować środki z budżetu na utworzenie bazy noclegowej i przeznaczenie na akademiki nieużytkowanych budynków, na przykład dawnych koszar.</p>

## Booking musi obejść się smakiem. KE zablokowała przejęcie internetowego biura podróży eTraveli
 - [https://www.bankier.pl/wiadomosc/Booking-nie-przejmie-internetowego-biura-podrozy-eTraveli-KE-nie-dala-zgody-8617078.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Booking-nie-przejmie-internetowego-biura-podrozy-eTraveli-KE-nie-dala-zgody-8617078.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T11:14:32.210179+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/670be58fa8f703-948-568-0-116-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska zablokowała w poniedziałek planowane przejęcie Flugo Group Holdings AB (eTraveli) przez Booking Holdings (Booking). Przejęcie umożliwiłoby spółce Booking wzmocnienie jej dominującej pozycji na rynku internetowych biur podróży zajmujących się hotelami - argumentowała KE.</p>

## "Bezpieczny kredyt 2 proc." dostępny w kolejnym banku
 - [https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-dostepny-w-kolejnym-banku-8617077.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-dostepny-w-kolejnym-banku-8617077.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T11:14:32.198158+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/37b87470913537-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już 12 banków oferuje kredyty mieszkaniowe w ramach programu "Bezpieczny kredyt" - podał w poniedziałek Bank Gospodarstwa Krajowego na swoich stronach. Do listy banków, które podpisały z BGK umowy ws. programu, dołączył Wschodni Bank Spółdzielczy w Chełmie.</p>

## Gorąco w Kosowie. Opancerzone pojazdy policji wkroczyły do wioski, w której doszło do starcia zbrojnego z Serbami
 - [https://www.bankier.pl/wiadomosc/Goraco-w-Kosowie-Wkroczyly-opancerzone-pojazdy-policji-8617062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Goraco-w-Kosowie-Wkroczyly-opancerzone-pojazdy-policji-8617062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T11:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/3229cd5f61fb5d-948-568-0-52-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jednostki kosowskiej policji wkroczyły w poniedziałek w pojazdach opancerzonych do wioski na północy kraju, w której w strzelaninie pomiędzy siłami z Kosowa a etnicznymi Serbami zginęły cztery osoby - podała agencja Reutera za źródłem w kosowskiej policji.</p>

## Większość emerytów otrzymała "czternastkę" na konto bankowe
 - [https://www.bankier.pl/wiadomosc/Wiekszosc-emerytow-otrzymala-czternastke-na-konto-bankowe-8617053.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiekszosc-emerytow-otrzymala-czternastke-na-konto-bankowe-8617053.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T10:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/0e40fec346888c-948-568-0-23-3067-1840.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Około 80 proc. emerytów i rencistów pobiera swoje świadczenia, w tym 14. emeryturę, na konto w banku - wynika z najnowszych danych Zakładu Ubezpieczeń Społecznych. Tzw. wskaźnik ubankowienia emerytów cały czas rośnie i obecnie wynosi 80,6 proc. - wskazuje szefowa ZUS prof. Gertruda Uścińska.</p>

## Rada UE zdecydowała ws. normy Euro 7. "Celem jest zmniejszenie zanieczyszczeń"
 - [https://www.bankier.pl/wiadomosc/Rada-UE-zdecydowala-ws-normy-Euro-7-Celem-jest-zmniejszenie-zanieczyszczen-8617052.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rada-UE-zdecydowala-ws-normy-Euro-7-Celem-jest-zmniejszenie-zanieczyszczen-8617052.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T10:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/36bd4cb5136050-948-568-5-0-2029-1217.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada UE (państwa członkowskie) przyjęła w poniedziałek swoje stanowisko negocjacyjne w sprawie projektu rozporządzenia dotyczącego homologacji pojazdów i silników. Chodzi o wprowadzenie normy Euro 7. Celem projektu jest obniżenie emisji substancji zanieczyszczających powietrze w transporcie drogowym.</p>

## Kosmetyki ekologiczne są już passé? Wartość sektora spada
 - [https://www.bankier.pl/wiadomosc/Kosmetyki-ekologiczne-sa-juz-passe-Wartosc-sektora-spada-8617051.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kosmetyki-ekologiczne-sa-juz-passe-Wartosc-sektora-spada-8617051.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T10:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/e4a509edcd1347-948-568-0-225-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wartość sektora kosmetyków ekologicznych, organicznych i bio wynosi 224 mln zł, co oznacza spadek o 9 proc. rdr. - wynika z badania firmy GfK. Natomiast wartość całego rynku kosmetyków rośnie; najlepiej sprzedają się marki własne i oferowane w promocji - dodano.</p>

## UE uniezależniła się od Rosji? Import ropy ze Wschodu szoruje po dnie
 - [https://www.bankier.pl/wiadomosc/UE-uniezaleznila-sie-od-Rosji-Import-ropy-ze-Wschodu-szoruje-po-dnie-8617038.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UE-uniezaleznila-sie-od-Rosji-Import-ropy-ze-Wschodu-szoruje-po-dnie-8617038.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T10:09:30.295450+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/6c00a161a91181-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Udział Rosji w imporcie ropy naftowej do UE w II kw. spadł o 13,2 pkt. proc. rdr - podał Eurostat.</p>

## Stopa bezrobocia w sierpniu bez zmian. Co będzie dalej?
 - [https://www.bankier.pl/wiadomosc/Stopa-bezrobocia-w-sierpniu-bez-zmian-Co-bedzie-dalej-8617015.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stopa-bezrobocia-w-sierpniu-bez-zmian-Co-bedzie-dalej-8617015.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T09:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/60c40bc1f77fcd-948-568-0-78-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stopa bezrobocia do listopada powinna się wahać w niewielkim stopniu - ocenił Polski Instytut Ekonomiczny w komentarzu do poniedziałkowych danych Głównego Urzędu Statystycznego. Według PIE bezrobocie na początku przyszłego roku może wzrosnąć do 5,5 proc.</p>

## Politico: Rosja werbuje na Kubie. Rekruci trafią na ukraiński front
 - [https://www.bankier.pl/wiadomosc/Politico-Rosja-werbuje-na-Kubie-Rekruci-trafia-na-ukrainski-front-8617012.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Politico-Rosja-werbuje-na-Kubie-Rekruci-trafia-na-ukrainski-front-8617012.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T09:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/99fdbeaedd61b2-948-568-100-160-3900-2339.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brukselski portal Politico opisuje w poniedziałek, jak Rosja próbuje werbować na Kubie najemników na wojnę przeciwko Ukrainie. Desperacja młodych Kubańczyków jest tak duża, że decydują się na służbę w rosyjskiej armii - czytamy w artykule.</p>

## Cudzoziemcy chętniej wydają pieniądze w Polsce. Porównano ich z Polakami za granicą
 - [https://www.bankier.pl/wiadomosc/Cudzoziemcy-chetniej-wydaja-pieniadze-w-Polsce-Porownano-ich-z-Polakami-za-granica-8616995.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cudzoziemcy-chetniej-wydaja-pieniadze-w-Polsce-Porownano-ich-z-Polakami-za-granica-8616995.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T09:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/1/0b25b3d3884624-948-568-0-270-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Główny Urząd Statystyczny opublikował dane związane z wydatkami cudzoziemców w Polsce i Polaków za granicą. Porównując wyniki z poprzednich okresów, w obu przypadkach doszło do wzrostu.</p>

## Inflacja jest wyższa, niż wskazuje GUS? Tak twierdzą Polacy
 - [https://www.bankier.pl/wiadomosc/Inflacja-jest-wyzsza-niz-wskazuje-GUS-Tak-twierdza-Polacy-8616979.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-jest-wyzsza-niz-wskazuje-GUS-Tak-twierdza-Polacy-8616979.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T09:04:28.592884+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/6/22e7781fed5bd5-948-568-230-0-3312-1987.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Opublikowano wyniki najnowszego sondażu United Surveys dla RMF FM i “Dziennika Gazety Prawnej”, z którego wynika, że Polacy odczuwają wzrost cen towarów i usług zdecydowanie dotkliwiej, niż sugerowałyby najnowsze dane opublikowane przez Główny Urząd Statystyczny.
</p>

## „Wiadomości” TVP zostaną ukarane za manipulacje?
 - [https://www.bankier.pl/wiadomosc/Wiadomosci-TVP-zostana-ukarane-za-manipulacje-8616982.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiadomosci-TVP-zostana-ukarane-za-manipulacje-8616982.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T09:04:28.584766+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/b/3277cbf6b07cf5-948-568-0-35-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Opozycyjny członek Krajowej Rady Radiofonii i Telewizji,
Tadeusz Kowalski, skierował skargę do przewodniczącego tej instytucji na
wydania „Wiadomości” TVP1 z 15, 16 i 17 września br. Uważa, że konieczne jest wszczęcie
postępowania przeciwko temu serwisowi informacyjnemu za manipulacje,
wprowadzenie w błąd widzów i ich straszenie, milczenie na temat afery wizowej,
opieranie tezy materiału na spocie PiS i niedozwoloną autopromocję – podał
portal Wirtualnemedia.pl.</p>

## Kurs euro spadł poniżej 4,60 zł. Dolar trzyma się mocno
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-spadl-ponizej-4-60-zl-Dolar-trzyma-sie-mocno-8616955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-spadl-ponizej-4-60-zl-Dolar-trzyma-sie-mocno-8616955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T08:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/4/ea1d5e565158ef-948-568-40-190-3640-2183.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs
euro znalazł się poniżej linii 4,60 zł, lecz wciąż znajduje się znacznie wyżej
niż na początku miesiąca.</p>

## Rosjanie bronią każdego metra ziemi. Część kontrataków była bezsensowna
 - [https://www.bankier.pl/wiadomosc/Rosjanie-bronia-kazdego-metra-ziemi-Czesc-kontratakow-byla-bezsensowna-8616935.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosjanie-bronia-kazdego-metra-ziemi-Czesc-kontratakow-byla-bezsensowna-8616935.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T08:03:32.927249+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/68c4abeb29f1a6-948-568-0-80-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władimir Putin miał dać ministrowi obrony Rosji Siergiejowi Szojgu czas do początku października na zatrzymanie ukraińskiej kontrofensywy i przejęcie inicjatywy na froncie – pisze w najnowszej analizie amerykański Instytut Studiów nad Wojną (ISW).</p>

## W. Kosiniak-Kamysz proponuje rodzinny PIT. Co z 800 plus?
 - [https://www.bankier.pl/wiadomosc/W-Kosiniak-Kamysz-proponuje-rodzinny-PIT-Co-z-800-plus-8616953.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-Kosiniak-Kamysz-proponuje-rodzinny-PIT-Co-z-800-plus-8616953.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T08:03:32.920024+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/5/6161dc0be71f9a-948-568-7-31-3144-1886.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Propozycja rodzinnego PIT-u nie wyklucza kontynuacji programu socjalnego, jakim jest 500 plus, czy jego waloryzacja na 800 plus - powiedział w poniedziałek prezes PSL i jeden z liderów Trzeciej Drogi Władysław Kosiniak-Kamysz.</p>

## Sony ma zapłacić 576 tys. zł. Zapadł przełomowy wyrok
 - [https://www.bankier.pl/wiadomosc/Sony-ma-zaplacic-576-tys-zl-Zapadl-przelomowy-wyrok-8616905.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sony-ma-zaplacic-576-tys-zl-Zapadl-przelomowy-wyrok-8616905.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T08:03:32.903519+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/a8cbc899dee089-948-567-5-62-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd potwierdził, że od smartfonów, tabletów i notebooków należy zapłacić opłatę reprograficzną. Są to urządzenia zdolne do pozyskiwania kopii utworów na własny użytek. Przełomowy wyrok zapadł w sprawie Sony. Firma ma zapłacić 576 tys. zł.</p>

## Polskie magazyny gazu niemal pewne. Oto najnowsze dane
 - [https://www.bankier.pl/wiadomosc/Wypelnienie-magazynow-gazu-wg-stanu-na-24-wrzesnia-wzroslo-do-99-proc-GSP-8616922.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wypelnienie-magazynow-gazu-wg-stanu-na-24-wrzesnia-wzroslo-do-99-proc-GSP-8616922.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T07:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/9fed73ab8bd7e1-948-568-0-0-2904-1742.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wypełnienie magazynów gazu w Polsce, według stanu na 24 września, wzrosło do 99 proc. - poinformował Gas Storage Poland, spółka celowa PGNiG.</p>

## Kolejna spółka zniknie z GPW? Jest wezwanie do sprzedaży akcji
 - [https://www.bankier.pl/wiadomosc/iCotton-wzywa-do-sprzedazy-2-164-887-akcji-Harper-Hygienics-po-5-25-zl-szt-BM-mBanku-8616912.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/iCotton-wzywa-do-sprzedazy-2-164-887-akcji-Harper-Hygienics-po-5-25-zl-szt-BM-mBanku-8616912.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T07:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/2/efc49de9eb561d-948-568-0-255-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />iCotton wzywa do sprzedaży 2.164.887 akcji Harper Hygienics, po 5,25 zł za akcję - poinformowało Biuro Maklerskie mBanku w komunikacie.</p>

## Ceny ropy dalej rosną. "Arabia Saudyjska kontynuuje cięcia dostaw"
 - [https://www.bankier.pl/wiadomosc/Ceny-ropy-dalej-rosna-Arabia-Saudyjska-kontynuuje-ciecia-dostaw-8616902.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ropy-dalej-rosna-Arabia-Saudyjska-kontynuuje-ciecia-dostaw-8616902.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T07:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/8/f8ac472a237b25-948-568-0-144-1700-1020.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną w poniedziałek po zaliczeniu spadków w ub. tygodniu. Surowiec kosztuje ponad 90 USD za baryłkę  - podają maklerzy.</p>

## Inflacja i alimenty w nowym roku szkolnym. "Paragon to mało wiarygodny dowód"
 - [https://www.bankier.pl/wiadomosc/Inflacja-i-alimenty-w-nowym-roku-szkolnym-Zbieraj-dowody-paragon-to-za-malo-8611685.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-i-alimenty-w-nowym-roku-szkolnym-Zbieraj-dowody-paragon-to-za-malo-8611685.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/b/ab1d809182dd05-948-568-17-17-3482-2089.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Droższy nowy rok szkolny może mieć wpływ na wysokość alimentów. Rodzice dziecka uczącego się, na rzecz którego jest lub będzie wypłacane takie świadczenie, powinni dokumentować istotne w ich odczuciu wydatki szkolne. Nie wystarczą do tego same paragony.</p>

## Promyk nadziei w Hollywood? Strajkujący scenarzyści doszli do wstępnego porozumienia
 - [https://www.bankier.pl/wiadomosc/Promyk-nadziei-w-Hollywood-Strajkujacy-scenarzysci-doszli-do-wstepnego-porozumienia-8616886.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Promyk-nadziei-w-Hollywood-Strajkujacy-scenarzysci-doszli-do-wstepnego-porozumienia-8616886.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T06:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/cf0da3f700abdc-948-568-0-17-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykańska Gildia Scenarzystów (WGA) doszła w niedzielę do wstępnego porozumienia z głównymi wytwórniami filmowymi. Umowa ma zakończyć trwający od 2 maja strajk scenarzystów, który doprowadził do wstrzymania wielu produkcji i miliardowych strat amerykańskiego przemysłu filmowego.</p>

## Tym politykom ufamy najbardziej. Jest zmiana lidera
 - [https://www.bankier.pl/wiadomosc/Tym-politykom-ufamy-najbardziej-Jest-zmiana-lidera-8616884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-politykom-ufamy-najbardziej-Jest-zmiana-lidera-8616884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T06:06:35.085676+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/d/1b1c67ff04cb8b-948-568-108-0-1331-798.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Andrzej Duda wyprzedził Rafała Trzaskowskiego i powrócił na pierwsze miejsce w rankingu zaufania do osób publicznych. Swoje notowania poprawili premier Mateusz Morawiecki i lider Platformy Obywatelskiej Donald Tusk, kolejny raz walcząc o ostatnie miejsce na podium — wynika z najnowszego sondażu IBRiS dla Onetu.</p>

## Dwa razy po 700 zł od Nest Banku. Promocja dla firm
 - [https://www.bankier.pl/wiadomosc/Dwa-razy-po-700-zl-od-Nest-Banku-Promocja-dla-firm-8615878.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dwa-razy-po-700-zl-od-Nest-Banku-Promocja-dla-firm-8615878.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T06:06:35.068366+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/ae861513e71214-948-568-0-154-4128-2476.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przedsiębiorcy w promocjach Nest Banku mogą otrzymać 1400 zł. Połowa nagrody wypłacana jest w formie premii pieniężnej, a druga część jako voucher do wykorzystania na zakupy za pośrednictwem Allegro.</p>

## Rząd kusi wyborców. Darmowe muzea okażą się hitem?
 - [https://www.bankier.pl/wiadomosc/Jest-kolejna-kielbasa-wyborcza-Darmowe-muzea-dla-mlodziezy-i-seniorow-8616880.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jest-kolejna-kielbasa-wyborcza-Darmowe-muzea-dla-mlodziezy-i-seniorow-8616880.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T06:06:35.058177+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/2/0cac5df3c78c6e-945-560-0-52-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chcemy np. wprowadzić darmowe bilety do narodowych instytucji kultury i muzeów, dla młodzieży i dla osób starszych – przekazał w wywiadzie dla i.pl minister kultury i dziedzictwa narodowego Piotr Gliński. W jego ocenie, trzeba uporządkować i wzmocnić system promocji polskiej kultury za granicą.</p>

## Koniec z zamawianiem Ubera i jedzenia na dowóz? Powodem unijne regulacje
 - [https://www.bankier.pl/wiadomosc/Koniec-z-zamawianiem-Ubera-i-jedzenia-na-dowoz-Powodem-unijne-regulacje-8616889.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-z-zamawianiem-Ubera-i-jedzenia-na-dowoz-Powodem-unijne-regulacje-8616889.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T06:06:35.055901+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/e45ea2897b6815-948-568-0-229-3397-2038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />“Rzeczpospolita” podała, że nawet 70 proc. osób zatrudnionych w branży transportu osób i dowozu posiłków może niedługo zrezygnować ze swojej pracy. Wiąże się to z przepisami, nad którymi pracuje obecnie Parlament Europejski.</p>

## PiS wciąż na czele. Poza liderami walka "łeb w łeb"
 - [https://www.bankier.pl/wiadomosc/PiS-wciaz-na-czele-Poza-liderami-walka-leb-w-leb-8616871.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PiS-wciaz-na-czele-Poza-liderami-walka-leb-w-leb-8616871.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T05:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/e928d557b3a9d9-945-567-0-103-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W najnowszym sondażu wyborczym Instytutu Badań Pollster, wykonanym dla "Super Expressu”, liderem pozostaje Zjednoczona Prawica (36,76 proc. głosów), a na drugim miejscu utrzymuje się Koalicja Obywatelska (30,44 proc.).</p>

## Afera wizowa i po aferze? Prokuratura chce ukręcić "łeb" sprawie
 - [https://www.bankier.pl/wiadomosc/Afera-wizowa-i-po-aferze-Prokuratura-chce-ukrecic-leb-sprawie-8616866.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Afera-wizowa-i-po-aferze-Prokuratura-chce-ukrecic-leb-sprawie-8616866.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T05:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/d55db709a8352d-945-560-267-4-1163-697.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prokuratura uważa, że 25-latek sam wymyślił "interes wizowy”. Mężczyzna zaprzecza, by dzielił się łapówkami z wiceministrem – informuje poniedziałkowa "Rzeczpospolita”.</p>

## Polskie projekty jądrowe nabierają tempa. "Wydaje się, że jesteśmy skazani na atom"
 - [https://www.bankier.pl/wiadomosc/Polskie-projekty-jadrowe-nabieraja-tempa-Wydaje-sie-ze-jestesmy-skazani-na-atom-8616857.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-projekty-jadrowe-nabieraja-tempa-Wydaje-sie-ze-jestesmy-skazani-na-atom-8616857.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/2edc5cdb7609ff-948-568-0-431-2974-1784.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ciągu najbliższych 17 lat atom ma odpowiadać za mniej więcej jedną czwartą produkcji energii elektrycznej w Polsce. Projekty dotyczące zarówno pierwszej elektrowni jądrowej na Pomorzu, jak i drugiej w Wielkopolsce nabierają tempa, a poparcie społeczne dla tych inwestycji jest na bardzo wysokim poziomie. Zwolennicy zwiększania udziału atomu w miksie energetycznym podkreślają, że to nie tylko tania energia i bezpieczeństwo energetyczne, ale też większa niezależność. - W polskich warunkach geograficznych wydaje się, że jesteśmy skazani na atom - mówi ekspert tego rynku Adam Rajewski.
</p>

## Producenci jabłek: rosnące koszty działalności są problemem
 - [https://www.bankier.pl/wiadomosc/Producenci-jablek-rosnace-koszty-dzialalnosci-sa-problemem-8616847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Producenci-jablek-rosnace-koszty-dzialalnosci-sa-problemem-8616847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T05:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/17ff6bd8e3b4b7-945-567-11-7-1488-893.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosnące koszty produkcji, brak pracowników sezonowych czy nowe regulacje UE w zakresie Zielonego  Ładu i zrównoważonego rozwoju - to największe wyzwania stojące obecnie przed producentami jabłek - wynika ze strategii Unii Owocowej „Jabłkowa Perspektywa 2030”</p>

## Najem małych mieszkań coraz droższy. W tych miastach najmocniej drenuje portfele
 - [https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-wrzesien-2023-Raport-Bankier-pl-8615921.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-wrzesien-2023-Raport-Bankier-pl-8615921.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/44b95e1fc9a6b5-948-568-0-371-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sierpień był czwartym miesiącem z rzędu z podwyżkami średnich cen ofertowych najmu małych mieszkań – wynika z danych Otodom Analytics. Rosnące stawki w ogłoszeniach dominują pomimo większej o 80 proc. niż przed rokiem liczby ofert mieszkań na wynajem.
</p>

## Najlepsze konta oszczędnościowe na 200 000 zł – wrzesień 2023 r.
 - [https://www.bankier.pl/wiadomosc/Ranking-kont-oszczednosciowych-wrzesien-2023-Najlepsze-konto-oszczednosciowe-8616083.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kont-oszczednosciowych-wrzesien-2023-Najlepsze-konto-oszczednosciowe-8616083.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/a45b8e2d3b739a-945-560-0-0-2832-1699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Konta oszczędnościowe to alternatywa dla lokat. W przeciwieństwie do depozytów tutaj stawki spadają w nieco wolniejszym tempie. Wpłacając kapitał w wysokości 200 000 zł, wciąż można liczyć na stawkę w wysokości 10 proc. rocznie.</p>

## Zysk netto i gigantyczne pożyczki. Spółka Palikota pokazała zaległe sprawozdanie
 - [https://www.bankier.pl/wiadomosc/Zalegly-raport-spolki-Palikota-Zysk-i-pozyczki-8616062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zalegly-raport-spolki-Palikota-Zysk-i-pozyczki-8616062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/2/4af5a94d07d634-948-568-277-210-2722-1633.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Manufaktura Piwa Wódki i Wina przedstawiła długo oczekiwane sprawozdanie finansowe, które pokazuje sytuację w jakiej spółka Palikota znajdowała się prawie 10 miesięcy temu, czyli na długo przed wybuchem medialnej afery.</p>

## Fermy drobiu zadłużone na ponad 200 mln zł. A długi rosną
 - [https://www.bankier.pl/wiadomosc/Eksperci-dlugi-branzy-drobiarskiej-o-12-proc-wyzsze-niz-przed-rokiem-8616845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Eksperci-dlugi-branzy-drobiarskiej-o-12-proc-wyzsze-niz-przed-rokiem-8616845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T04:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/4dd5dca8e0e758-945-560-0-39-1735-1040.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kwota nieuregulowanych rat i faktur branży drobiarskiej jest o 12 proc. wyższa niż przed rokiem i wynosi niemal 213 mln zł - wynika z raportu Rejestru Dłużników BIG InfoMonitor. Wśród przetwórców mięsa drobiowego kontrahentom nie płaci w terminie co ósma firma - podano.</p>

## Nie żyje szef sycylijskiej mafii. Wcześniej ukrywał się 30 lat
 - [https://www.bankier.pl/wiadomosc/Nie-zyje-szef-sycylijskiej-mafii-Wczesniej-ukrywal-sie-30-lat-8616839.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-zyje-szef-sycylijskiej-mafii-Wczesniej-ukrywal-sie-30-lat-8616839.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-25T03:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/3c8649f231af72-945-560-0-118-1632-979.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Słynny sycylijski mafioso i przywódca cosa nostry Matteo Messina Denaro zmarł w szpitalu w środkowych Włoszech - podała w poniedziałek agencja prasowa ANSA.</p>

