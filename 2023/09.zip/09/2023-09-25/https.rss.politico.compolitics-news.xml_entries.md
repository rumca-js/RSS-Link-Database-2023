# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Newsom and DeSantis to debate in November
 - [https://www.politico.com/news/2023/09/25/newsom-desantis-debate-fox-00117959](https://www.politico.com/news/2023/09/25/newsom-desantis-debate-fox-00117959)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-09-25T12:26:54+00:00

Fox News anchor Sean Hannity will moderate.

