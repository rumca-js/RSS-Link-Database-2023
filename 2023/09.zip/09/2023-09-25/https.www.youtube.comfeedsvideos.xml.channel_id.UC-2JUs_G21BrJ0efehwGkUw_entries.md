# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Can't Take My Eyes Off You | funk cover ft. Lucy Schwartz
 - [https://www.youtube.com/watch?v=Zb-gzKDQnq8](https://www.youtube.com/watch?v=Zb-gzKDQnq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2023-09-25T13:00:21+00:00

Get tickets to see us on tour (NEW DATES added in Europe!): https://www.scarypocketsfunk.com
Join the vinyl club by Sept. 30 to get "Jeff" on vinyl: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Frankie Valli's "Can't Take My Eyes Off You" by Scary Pockets & Lucy Schwartz.

MUSICIAN CREDITS
Lead vocal: Lucy Schwartz
Drums: Lemar Carter
Bass: Sebastian Steinberg
Keys: Jack Conte
Guitar: Ryan Lerman
Additional Production: Likeminds

AUDIO CREDITS
Recording Engineer: Chad Gordon
Asst Engineer: Zack Zajdel
Mix/Master: Craig Polasko

VIDEO CREDITS
Director: Dom Fera
DP: Ricky Chavez
ACs: Merlin Showalter, Alejandro Echevarria
Camera Operator: Chad Carlstone


