# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## Indicted US Senator Robert Menendez ignores calls to resign
 - [https://www.ft.com/content/b8340863-98b8-4a1e-83bb-8ee453637340](https://www.ft.com/content/b8340863-98b8-4a1e-83bb-8ee453637340)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T22:54:45+00:00



## Coty pushes ahead with plans for dual Paris listing
 - [https://www.ft.com/content/6b118633-f464-4022-94be-15c9c4998426](https://www.ft.com/content/6b118633-f464-4022-94be-15c9c4998426)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T22:36:01+00:00

Beauty company’s return to city of its founding seen as a vote of confidence in leadership of Sue Nabi

## FirstFT: Top Nomura banker banned from leaving mainland China
 - [https://www.ft.com/content/d2644e5f-dba8-4e58-aeff-6f4a1cd9c315](https://www.ft.com/content/d2644e5f-dba8-4e58-aeff-6f4a1cd9c315)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T21:41:08+00:00

Also in today’s newsletter, Russian oligarch ‘surprised’ at economic resilience and China and the EU agree export controls ‘mechanism’

## Lib Dems vow to knock down Tory ‘blue wall’ in south of England
 - [https://www.ft.com/content/afb42ecf-a3f4-4a85-a9df-846cc199e0fd](https://www.ft.com/content/afb42ecf-a3f4-4a85-a9df-846cc199e0fd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T21:30:57+00:00

Ed Davey’s party accused of watering down policies to pander to Conservative voters

## Houthis blamed for Bahraini soldiers’ deaths on Yemen border
 - [https://www.ft.com/content/f5ca12f2-647f-4e6d-bfa0-701c48af0a14](https://www.ft.com/content/f5ca12f2-647f-4e6d-bfa0-701c48af0a14)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T20:29:12+00:00

Drone strike comes despite efforts to secure long-term peace with Saudi-led coalition

## Scrapping HS2 will damage trust in Britain, warn US buyers of Birmingham City
 - [https://www.ft.com/content/c4d68338-fa60-43c8-b9db-de4edc9cb520](https://www.ft.com/content/c4d68338-fa60-43c8-b9db-de4edc9cb520)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T20:15:52+00:00

Owners of Tom Brady-backed football club say truncating rail line will shake investor confidence

## Russia has proved resilience to western sanctions, says Deripaska
 - [https://www.ft.com/content/3652bbb5-a0f9-4d54-adc6-03b645a44306](https://www.ft.com/content/3652bbb5-a0f9-4d54-adc6-03b645a44306)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T20:00:52+00:00

Metals oligarch tells FT of his ‘surprise’ at performance of economy in wake of invasion of Ukraine

## Moody’s warns federal shutdown would be ‘negative’ for US debt rating
 - [https://www.ft.com/content/6dafa393-fdb0-447c-9d22-b530bfa2ba17](https://www.ft.com/content/6dafa393-fdb0-447c-9d22-b530bfa2ba17)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T19:45:31+00:00

Report comes as hopes for congressional deal to avert crisis fade

## Macron walks tightrope with green policy ‘à la française’
 - [https://www.ft.com/content/a59c2cd9-3607-420f-a978-8feb503698ab](https://www.ft.com/content/a59c2cd9-3607-420f-a978-8feb503698ab)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T19:04:07+00:00

French president rules out ban on gas boilers

## Germany leads push to delay electric vehicle tariffs between EU and UK
 - [https://www.ft.com/content/5305ab3e-6f54-4a70-945b-c3f3c78f5fa6](https://www.ft.com/content/5305ab3e-6f54-4a70-945b-c3f3c78f5fa6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T18:14:34+00:00

Berlin and carmakers back UK call for three-year pause on requirement for batteries to be produced locally

## Gatwick cancels more than 160 flights because of ATC staff shortages
 - [https://www.ft.com/content/5cfb8899-a649-4bc3-8a31-4a31eba24cc6](https://www.ft.com/content/5cfb8899-a649-4bc3-8a31-4a31eba24cc6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T18:11:49+00:00

London’s second-busiest airport to impose cap on departures and arrivals for rest of week

## The Indian dilemma for America and its allies
 - [https://www.ft.com/content/95a2074f-8491-41d4-9d8b-68b3124723a9](https://www.ft.com/content/95a2074f-8491-41d4-9d8b-68b3124723a9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T17:54:17+00:00

New Delhi’s alleged role in a murder on Canadian soil requires due legal process

## Bank of England studies sweeping reform of forecasting
 - [https://www.ft.com/content/cb797992-1a2b-4d6f-94d5-3acf6cb8a8f7](https://www.ft.com/content/cb797992-1a2b-4d6f-94d5-3acf6cb8a8f7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T17:37:19+00:00

UK central bank indicates review by Ben Bernanke could result in process similar to that used by US Fed

## Business and trade tensions with China back in the spotlight
 - [https://www.ft.com/content/fb1ac890-d83b-4af7-a3e5-3343f714967a](https://www.ft.com/content/fb1ac890-d83b-4af7-a3e5-3343f714967a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T17:15:52+00:00

Also in this newsletter: Nissan chief on the end of the combustion engine, Hollywood hopes, robot security guards

## Global trade falls at fastest pace since pandemic
 - [https://www.ft.com/content/36982601-b799-4166-9e6b-39533efbdfdf](https://www.ft.com/content/36982601-b799-4166-9e6b-39533efbdfdf)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T16:50:50+00:00

Demand for goods exports weakens on the back of higher inflation, rate rises and spending on services

## US Treasuries sell off as investors fret over lengthy period of high rates
 - [https://www.ft.com/content/4f6cd8b6-5325-461e-b926-fd4da3839aa0](https://www.ft.com/content/4f6cd8b6-5325-461e-b926-fd4da3839aa0)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T16:50:00+00:00

Long-term yields rise to fresh 16-year high and dollar hits strongest level in 10 months

## Sharing trade secrets is key to the pandemic agreements
 - [https://www.ft.com/content/c76d6f5a-0d82-493c-8d8a-5cdf8cf4a1d4](https://www.ft.com/content/c76d6f5a-0d82-493c-8d8a-5cdf8cf4a1d4)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T16:27:36+00:00

Addressing this IP issue is crucial to ensuring pharmaceutical products are available in future emergencies

## UK banks/Basel 3.1: locals rule on international regulation
 - [https://www.ft.com/content/92635e40-917d-4e63-8c82-5bf715bea2bc](https://www.ft.com/content/92635e40-917d-4e63-8c82-5bf715bea2bc)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T16:06:49+00:00

BoE postpones implementation of new rules by six months to July 2025

## Vivendi’s Canal+ attacks French football body over rights
 - [https://www.ft.com/content/570ae441-02ae-4a7a-a2b7-50c0f2a7c46d](https://www.ft.com/content/570ae441-02ae-4a7a-a2b7-50c0f2a7c46d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T15:38:52+00:00

Pay-TV channel claims it would be at a disadvantage in upcoming broadcasting auction

## Chinese government probe casts new doubt over Evergrande restructuring
 - [https://www.ft.com/content/df85137b-bfbb-4fb1-a33c-90dae6ebae7d](https://www.ft.com/content/df85137b-bfbb-4fb1-a33c-90dae6ebae7d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T14:54:49+00:00

World’s most indebted developer says it cannot issue new debt because its mainland business is ‘being investigated’

## Common global rules needed ahead of ‘flying taxi’ boom, UK regulator says
 - [https://www.ft.com/content/c0e00052-8a91-48fc-88a0-d26a4f1e4df2](https://www.ft.com/content/c0e00052-8a91-48fc-88a0-d26a4f1e4df2)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T14:50:29+00:00

Civil Aviation Authority head forecasts that air travel is on the brink of ‘new revolution’

## English cricket to gain own regulator in push to combat racism and sexism
 - [https://www.ft.com/content/717f0efe-8fbf-4ef2-bcc5-8adad4647803](https://www.ft.com/content/717f0efe-8fbf-4ef2-bcc5-8adad4647803)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T14:47:29+00:00

Package of measures, including higher fees for female international players, comes after damning report

## Gig economy: blurred lines need to be recognised in new labour laws
 - [https://www.ft.com/content/65f4d284-235e-4c7f-93de-a9e98045bbdd](https://www.ft.com/content/65f4d284-235e-4c7f-93de-a9e98045bbdd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T14:16:43+00:00

Italy has shown it is possible to give workers a measure of protection without destroying the platform model

## US Republicans could finally win the argument on immigration
 - [https://www.ft.com/content/de7fcbee-1c4e-4124-9787-3d23f1965efb](https://www.ft.com/content/de7fcbee-1c4e-4124-9787-3d23f1965efb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T13:43:43+00:00

Illegal border crossings have quadrupled since Joe Biden became president

## McDonald’s: fast-food fight looms over franchisee fees
 - [https://www.ft.com/content/10fb90d1-5d40-4019-865b-b69b56d0dbea](https://www.ft.com/content/10fb90d1-5d40-4019-865b-b69b56d0dbea)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T13:34:30+00:00

Company needs to tread carefully over plan to raise royalty charges for new franchises in US and Canada

## China property: accelerating meltdown threatens other markets
 - [https://www.ft.com/content/790ceab3-3169-445f-aade-733daa50bb07](https://www.ft.com/content/790ceab3-3169-445f-aade-733daa50bb07)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T13:27:53+00:00

Nervousness over the risk of contagion could spread into commodities

## Nissan boss says world must ‘move on’ from combustion engine
 - [https://www.ft.com/content/e3758732-c057-40bb-9963-b265f577a097](https://www.ft.com/content/e3758732-c057-40bb-9963-b265f577a097)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T13:25:02+00:00

Makoto Uchida’s intervention comes after UK pushed back dates for ban on sale of new petrol and diesel cars

## What city dress codes tell us about culture and politics
 - [https://www.ft.com/content/24953d7c-61ef-457d-97a9-7674875fd865](https://www.ft.com/content/24953d7c-61ef-457d-97a9-7674875fd865)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T13:00:52+00:00

Washington is going through a bit of a sea change on this score

## Met Police still providing ‘vast majority’ of armed services despite officers handing in guns
 - [https://www.ft.com/content/15420db3-4793-4fc0-ae8b-b0e3284fa845](https://www.ft.com/content/15420db3-4793-4fc0-ae8b-b0e3284fa845)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T12:08:29+00:00

London force asks army for support after colleague’s murder charge leads some staff to down weapons

## EU fails big test on geopolitics of trade
 - [https://www.ft.com/content/f67e2698-f88e-4ed6-a3dd-e447b7443bb7](https://www.ft.com/content/f67e2698-f88e-4ed6-a3dd-e447b7443bb7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T11:31:52+00:00

Row over Ukrainian grain imports shows how the interests of member states sabotage Europe’s common goals

## Shoppers still struggling with food bills despite inflation waning, says Aldi
 - [https://www.ft.com/content/4065460b-5d5b-47bc-9969-066b9c4352e1](https://www.ft.com/content/4065460b-5d5b-47bc-9969-066b9c4352e1)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T11:29:45+00:00

Discount supermarket to increase investment in UK as it targets expansion of store network

## And the winner is . . .
 - [https://www.ft.com/content/f8f996fa-26e1-4d2e-9de3-b9e30ea8090a](https://www.ft.com/content/f8f996fa-26e1-4d2e-9de3-b9e30ea8090a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T11:14:39+00:00

Drumroll

## Lib Dems receive £1mn donation in boost to election war chest
 - [https://www.ft.com/content/56cd26df-d61e-42c1-a54c-b7dd07d51ce9](https://www.ft.com/content/56cd26df-d61e-42c1-a54c-b7dd07d51ce9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T11:01:02+00:00

Funding comes as party targets rural Conservative seats in next year’s polls

## Why has Leeds, birthplace of the tram, ground to a halt?
 - [https://www.ft.com/content/b2313433-e02b-4937-8501-b33f5b399c3f](https://www.ft.com/content/b2313433-e02b-4937-8501-b33f5b399c3f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T11:00:14+00:00

For decades, the council has failed to return light rail to the largest city in western Europe without a mass transit system

## Strike pay soars as UK union leader focuses on industrial action
 - [https://www.ft.com/content/adcda879-cf0f-4b75-a39d-2d623a002463](https://www.ft.com/content/adcda879-cf0f-4b75-a39d-2d623a002463)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T10:52:37+00:00

Unite has been involved in 950 disputes since Sharon Graham took over two years ago and has handed £30mn to striking members

## Italian mafia boss Messina Denaro dies less than a year after his arrest
 - [https://www.ft.com/content/cc52c3d9-5b2f-4880-9a6b-25b746c077a9](https://www.ft.com/content/cc52c3d9-5b2f-4880-9a6b-25b746c077a9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T09:54:11+00:00

Sicilian Cosa Nostra group waged war against state but has since been overshadowed by newer rivals

## Greek leftists elect former Goldman associate as leader
 - [https://www.ft.com/content/e2f5c074-7579-4182-a4c9-44cd92dc9839](https://www.ft.com/content/e2f5c074-7579-4182-a4c9-44cd92dc9839)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T09:45:07+00:00

Miami-based Stefanos Kasselakis takes helm of Syriza party that ruled country at height of debt crisis

## Russia pounds port of Odesa in latest air strikes against Ukraine
 - [https://www.ft.com/content/f0885eee-86e1-4da2-8933-d7c78d3868d7](https://www.ft.com/content/f0885eee-86e1-4da2-8933-d7c78d3868d7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T08:56:28+00:00

Moscow continues attacks aimed at hobbling Kyiv’s grain exports

## Why the Liberal Democrats are worth watching
 - [https://www.ft.com/content/2ed75f69-88a7-4ce3-8529-bb6cbf67fb95](https://www.ft.com/content/2ed75f69-88a7-4ce3-8529-bb6cbf67fb95)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T08:30:35+00:00

Also in this newsletter, controversy after Chris Kaba shooting investigation has provoked questionable responses from Scotland Yard and Home Office

## EU countries set to water down car emission rules
 - [https://www.ft.com/content/c2e998f4-7643-4f7c-b375-b497f1a4681c](https://www.ft.com/content/c2e998f4-7643-4f7c-b375-b497f1a4681c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T05:00:35+00:00

Also in this newsletter: why the Netherlands might back Vestager’s bid for EIB president

## Hollywood writers reach tentative deal with studios
 - [https://www.ft.com/content/f165fbad-56ee-40c3-b8c7-3edc372066a9](https://www.ft.com/content/f165fbad-56ee-40c3-b8c7-3edc372066a9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:22:16+00:00

Breakthrough could pave way for agreement with striking actors’ union

## As Milan Fashion Week looks inwards, Bottega Veneta strides ahead
 - [https://www.ft.com/content/2d92dc09-5630-4bb5-9c27-5e31a7c09e14](https://www.ft.com/content/2d92dc09-5630-4bb5-9c27-5e31a7c09e14)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

A slick showing at Ferragamo and a surprisingly good debut from Bally’s Simone Bellotti were among the week’s highlights

## Big Four shed UK staff after pandemic hiring boom
 - [https://www.ft.com/content/b87ae4a4-5d90-464d-8826-b9c839481bed](https://www.ft.com/content/b87ae4a4-5d90-464d-8826-b9c839481bed)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

‘Overhiring’ in some areas has led consultancies to make job cuts, recruiters and analysts say

## Bundesbank faces job cuts as consultants plot ‘modernisation’
 - [https://www.ft.com/content/342f6a2f-15f5-44e3-8e86-8ac6c2173d31](https://www.ft.com/content/342f6a2f-15f5-44e3-8e86-8ac6c2173d31)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Germany’s central bankers up in arms over Boston Consulting Group’s recommended efficiency drive

## FT readers: your favourite bars in Milan
 - [https://www.ft.com/content/1015f70f-2fba-448c-9b69-457ac724e8da](https://www.ft.com/content/1015f70f-2fba-448c-9b69-457ac724e8da)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Top spots for an aperitivo, from a rooftop eyrie to a secret speakeasy and a flower shop that moonlights as a watering hole. Cin cin!

## India’s dream of green energy runs into the reality of coal
 - [https://www.ft.com/content/fa254791-4034-4258-a12e-9b8b94edadd1](https://www.ft.com/content/fa254791-4034-4258-a12e-9b8b94edadd1)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

The fossil fuel accounts for around three-quarters of power generation and demand is expected to grow, despite an ambitious renewables plan

## Labour vows to push through UK audit and corporate governance reforms
 - [https://www.ft.com/content/3e9f075f-884d-4276-8a8c-9b0a02e7a3e8](https://www.ft.com/content/3e9f075f-884d-4276-8a8c-9b0a02e7a3e8)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Pledge by shadow business secretary follows legislative delays and rash of company scandals

## Models can mislead us on the impact of global trade
 - [https://www.ft.com/content/a39c1726-c468-4a0d-b06f-ea311b96cf73](https://www.ft.com/content/a39c1726-c468-4a0d-b06f-ea311b96cf73)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Predictions are only as good as the assumptions on which they depend

## Nato’s €1bn venture fund offers defence start-ups an alternative to China
 - [https://www.ft.com/content/2a41355b-e0bb-425b-b49c-3864cb48bf26](https://www.ft.com/content/2a41355b-e0bb-425b-b49c-3864cb48bf26)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

US-led military alliance to boost financial clout for companies from ‘multi-sovereign’ VC investors

## Solar supply chains must diversify away from China, warns EDP
 - [https://www.ft.com/content/6ecee5d2-e86b-49d3-9b7f-da937bf8b993](https://www.ft.com/content/6ecee5d2-e86b-49d3-9b7f-da937bf8b993)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Energy company turns to alternative supply sources after US import legislation causes delays

## South American leaders issue ultimatum on EU trade pact
 - [https://www.ft.com/content/26ab22e1-ecc4-43ae-9d96-7054f343e140](https://www.ft.com/content/26ab22e1-ecc4-43ae-9d96-7054f343e140)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Paraguay’s president says Mercosur will end talks with Brussels if deal is not finalised by December 6

## The US is on the brink of a new growth cycle
 - [https://www.ft.com/content/8774542d-6631-46cf-b8b0-059c821b751d](https://www.ft.com/content/8774542d-6631-46cf-b8b0-059c821b751d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

There are reasons to believe the economy is primed to deliver robust and durable expansion over the longer term

## The government must not make the Pension Regulator a lame duck
 - [https://www.ft.com/content/97b9419e-4721-450f-8d13-82d8cb5d3d7b](https://www.ft.com/content/97b9419e-4721-450f-8d13-82d8cb5d3d7b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Politicians should not forget that we all have a stake in a functioning pensions market

## UK councils missing energy efficiency targets for social housing, charity says
 - [https://www.ft.com/content/95090fd2-6a61-41b3-887a-b58fa898859d](https://www.ft.com/content/95090fd2-6a61-41b3-887a-b58fa898859d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Findings come days after ministers scrapped plans to force private landlords to upgrade their properties by 2028

## UK to delay implementing global banking reforms
 - [https://www.ft.com/content/27bf366a-c922-45da-8e92-70597a43427e](https://www.ft.com/content/27bf366a-c922-45da-8e92-70597a43427e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Bank of England will set back some Basel III reform rules but disappoint banks by reducing phase-in period

## Ukraine’s democracy is facing a wartime election test
 - [https://www.ft.com/content/86b2c1bc-fed9-483b-b737-33e6dd850acd](https://www.ft.com/content/86b2c1bc-fed9-483b-b737-33e6dd850acd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Zelenskyy has hinted presidential vote may still be possible next year, alarming civil society groups

## VanEck commodities ETF highlights complexities of investing
 - [https://www.ft.com/content/474eb434-c6fc-4869-8b65-15bfbc8e965b](https://www.ft.com/content/474eb434-c6fc-4869-8b65-15bfbc8e965b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

CMCI investors have to take views on inflation expectations, the transition economy and how long they plan to hold it

## Western companies take slow steps towards China ‘de-risking’
 - [https://www.ft.com/content/6e903c40-a024-4299-9025-f358882813bb](https://www.ft.com/content/6e903c40-a024-4299-9025-f358882813bb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:36+00:00

Most strategies are focusing on ways to insulate China operations rather than reduce them

## Poland’s complicated relationship with Ukraine
 - [https://www.ft.com/content/7358c754-aad4-4dfb-9485-ad711ec77d3e](https://www.ft.com/content/7358c754-aad4-4dfb-9485-ad711ec77d3e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T04:00:22+00:00

The FT has found that Russia has succeeded in avoiding G7 sanctions on most of its oil exports

## Brussels trade chief says China-EU ties ‘at a crossroads’
 - [https://www.ft.com/content/c336f9e7-3867-469b-8cc8-5cd32faee722](https://www.ft.com/content/c336f9e7-3867-469b-8cc8-5cd32faee722)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T01:45:35+00:00

Valdis Dombrovskis tells Chinese audience the two sides could ‘drift apart’ and Beijing must change its ways

## Senior Nomura banker barred from leaving mainland China
 - [https://www.ft.com/content/115b87c9-532d-468d-903c-127f8f31667b](https://www.ft.com/content/115b87c9-532d-468d-903c-127f8f31667b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-25T01:32:21+00:00

Exit ban on Charles Wang Zhonghe will send chill through foreign business circles

