# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Policjantka będąc na wakacjach usłyszała wołanie o pomoc. Uratowała życie 1,5-rocznemu dziecku
 - [https://epoznan.pl/news-news-143412-policjantka_bedac_na_wakacjach_uslyszala_wolanie_o_pomoc_uratowala_zycie_15_rocznemu_dziecku?rss=1](https://epoznan.pl/news-news-143412-policjantka_bedac_na_wakacjach_uslyszala_wolanie_o_pomoc_uratowala_zycie_15_rocznemu_dziecku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T20:53:00+00:00

To podkom. Marzena Kwaśna z Zespołu ds. Nieletnich i Patologii Wydziału Prewencji Komendy Powiatowej Policji w Turku.

## Włoch był zachwycony wizytą w Poznaniu. Nagrał uroczy film z Poznania na Instagramie. &quot;Kozy wychodzą o 12:00 i 15:00. Wystarczy ominąć remonty&quot;
 - [https://epoznan.pl/news-news-143411-wloch_byl_zachwycony_wizyta_w_poznaniu_nagral_uroczy_film_z_poznania_na_instagramie_kozy_wychodza_o_1200_i_1500_wystarczy_ominac_remonty?rss=1](https://epoznan.pl/news-news-143411-wloch_byl_zachwycony_wizyta_w_poznaniu_nagral_uroczy_film_z_poznania_na_instagramie_kozy_wychodza_o_1200_i_1500_wystarczy_ominac_remonty?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T19:07:00+00:00

Vloger Andrea Petroni opublikował na Instagramie podsumowanie pobytu.

## Młodociani wandale zniszczyli fontannę przy użyciu petardy. Nie wiedzieli, że całe zdarzenie rejestruje kamera
 - [https://epoznan.pl/news-news-143410-mlodociani_wandale_zniszczyli_fontanne_przy_uzyciu_petardy_nie_wiedzieli_ze_cale_zdarzenie_rejestruje_kamera?rss=1](https://epoznan.pl/news-news-143410-mlodociani_wandale_zniszczyli_fontanne_przy_uzyciu_petardy_nie_wiedzieli_ze_cale_zdarzenie_rejestruje_kamera?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T18:27:00+00:00

Do aktu wandalizmu doszło w niedzielę w Wilczynie (powiat koniński).

## Nauczyciele w Poznaniu mogą dostać podwyżkę, ale jest potrzebna zgoda rady miasta
 - [https://epoznan.pl/news-news-143409-nauczyciele_w_poznaniu_moga_dostac_podwyzke_ale_jest_potrzebna_zgoda_rady_miasta?rss=1](https://epoznan.pl/news-news-143409-nauczyciele_w_poznaniu_moga_dostac_podwyzke_ale_jest_potrzebna_zgoda_rady_miasta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T17:54:00+00:00

Pensje nauczycielskie są powodem manifestów od wielu lat, nie tylko w Poznaniu.

## Wozy strażackie przy ul. Jeleniogórskiej. &quot;Co się stało?&quot;
 - [https://epoznan.pl/news-news-143408-wozy_strazackie_przy_ul_jeleniogorskiej_co_sie_stalo?rss=1](https://epoznan.pl/news-news-143408-wozy_strazackie_przy_ul_jeleniogorskiej_co_sie_stalo?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T17:12:00+00:00

Czytelnik poinformował o akcji straży pożarnej.

## Do mieszkańców Poznania ma trafić ekologiczna energia. Wraca temat bloków gazowych
 - [https://epoznan.pl/news-news-143407-do_mieszkancow_poznania_ma_trafic_ekologiczna_energia_wraca_temat_blokow_gazowych?rss=1](https://epoznan.pl/news-news-143407-do_mieszkancow_poznania_ma_trafic_ekologiczna_energia_wraca_temat_blokow_gazowych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T15:54:00+00:00

Redakcja epoznan.pl już dwa lata temu informowała o tym, że mają one powstać.

## Znęcał się nad nieporadnymi życiowo rodzicami. Został aresztowany
 - [https://epoznan.pl/news-news-143404-znecal_sie_nad_nieporadnymi_zyciowo_rodzicami_zostal_aresztowany?rss=1](https://epoznan.pl/news-news-143404-znecal_sie_nad_nieporadnymi_zyciowo_rodzicami_zostal_aresztowany?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T15:23:00+00:00

W jednym z gnieźnieńskich domów, rodzice 39-letniego mężczyzny przeżyli dramat.

## Podczas szkolenia znaleźli 59 niewybuchów w lesie
 - [https://epoznan.pl/news-news-143401-podczas_szkolenia_znalezli_59_niewybuchow_w_lesie?rss=1](https://epoznan.pl/news-news-143401-podczas_szkolenia_znalezli_59_niewybuchow_w_lesie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T14:44:00+00:00

Policyjni pirotechnicy prowadzili działania w lasach gminy Opatówek.

## Policja szuka mężczyzny ze zdjęć. Rozpoznajesz go?
 - [https://epoznan.pl/news-news-143393-policja_szuka_mezczyzny_ze_zdjec_rozpoznajesz_go?rss=1](https://epoznan.pl/news-news-143393-policja_szuka_mezczyzny_ze_zdjec_rozpoznajesz_go?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T12:55:00+00:00

Chodzi o kradzież telefonu.

## Znowu armagedon w rejonie Bukowska / Przybyszewskiego. Kiedy przywrócą ruch w pełnym zakresie?
 - [https://epoznan.pl/news-news-143400-znowu_armagedon_w_rejonie_bukowska_przybyszewskiego_kiedy_przywroca_ruch_w_pelnym_zakresie?rss=1](https://epoznan.pl/news-news-143400-znowu_armagedon_w_rejonie_bukowska_przybyszewskiego_kiedy_przywroca_ruch_w_pelnym_zakresie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T12:43:00+00:00

Rano było tu bardzo źle i mamy powtórkę z rozrywki.

## Śmiertelne potrącenie przez pociąg na przejeździe z rogatkami. Pociągi kursowały objazdem
 - [https://epoznan.pl/news-news-143399-smiertelne_potracenie_przez_pociag_na_przejezdzie_z_rogatkami_pociagi_kursowaly_objazdem?rss=1](https://epoznan.pl/news-news-143399-smiertelne_potracenie_przez_pociag_na_przejezdzie_z_rogatkami_pociagi_kursowaly_objazdem?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T12:33:00+00:00

Do zdarzenia doszło w Kole na linii kolejowej Poznań - Warszawa.

## Spadochroniarz runął na ziemię z wysokości 2000 metrów. Prokuratura wyjaśnia okoliczności jego śmierci
 - [https://epoznan.pl/news-news-143395-spadochroniarz_runal_na_ziemie_z_wysokosci_2000_metrow_prokuratura_wyjasnia_okolicznosci_jego_smierci?rss=1](https://epoznan.pl/news-news-143395-spadochroniarz_runal_na_ziemie_z_wysokosci_2000_metrow_prokuratura_wyjasnia_okolicznosci_jego_smierci?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T12:30:00+00:00

Do tragicznego wypadku doszło w niedzielę na pilskim lotnisku.

## Winogrady: żona ugodziła nożem męża. Usłyszała zarzut usiłowania zabójstwa i znęcania się
 - [https://epoznan.pl/news-news-143398-winogrady_zona_ugodzila_nozem_meza_uslyszala_zarzut_usilowania_zabojstwa_i_znecania_sie?rss=1](https://epoznan.pl/news-news-143398-winogrady_zona_ugodzila_nozem_meza_uslyszala_zarzut_usilowania_zabojstwa_i_znecania_sie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T12:20:00+00:00

O sprawie pisaliśmy na epoznan.pl już w piątek.

## 102-latka poleciała motoparalotnią. &quot;Planuje kolejne loty&quot;
 - [https://epoznan.pl/news-news-143392-102_latka_poleciala_motoparalotnia_planuje_kolejne_loty?rss=1](https://epoznan.pl/news-news-143392-102_latka_poleciala_motoparalotnia_planuje_kolejne_loty?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T12:10:00+00:00

Pani Wiktoria Holajda jest jedną z najstarszych mieszkanek naszego województwa.

## Poznańska fundacja oszukiwała rodziców chorych dzieci? Do dziś niektórzy nie zobaczyli grosza ze zbiórek na leczenie
 - [https://epoznan.pl/news-news-143397-poznanska_fundacja_oszukiwala_rodzicow_chorych_dzieci_do_dzis_niektorzy_nie_zobaczyli_grosza_ze_zbiorek_na_leczenie?rss=1](https://epoznan.pl/news-news-143397-poznanska_fundacja_oszukiwala_rodzicow_chorych_dzieci_do_dzis_niektorzy_nie_zobaczyli_grosza_ze_zbiorek_na_leczenie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T12:00:00+00:00

Chodzi o fundację Szlachetny Bohater.

## Działali przy placu Wolności 34 lata, w weekend ostatecznie się zamykają. &quot;Dziękuję, że przedostawałyście się po dziurawym centrum&quot;
 - [https://epoznan.pl/news-news-143391-dzialali_przy_placu_wolnosci_34_lata_w_weekend_ostatecznie_sie_zamykaja_dziekuje_ze_przedostawalyscie_sie_po_dziurawym_centrum?rss=1](https://epoznan.pl/news-news-143391-dzialali_przy_placu_wolnosci_34_lata_w_weekend_ostatecznie_sie_zamykaja_dziekuje_ze_przedostawalyscie_sie_po_dziurawym_centrum?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T11:40:00+00:00

Sklep odzieżowy La Cara działa do soboty.

## W Wielkopolsce otwarto gigantyczną farmę fotowoltaiczną. Jedną z największych w Europie
 - [https://epoznan.pl/news-news-143383-w_wielkopolsce_otwarto_gigantyczna_farme_fotowoltaiczna_jedna_z_najwiekszych_w_europie?rss=1](https://epoznan.pl/news-news-143383-w_wielkopolsce_otwarto_gigantyczna_farme_fotowoltaiczna_jedna_z_najwiekszych_w_europie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T11:30:00+00:00

Powstała w gminie Przykona na terenie powiatu tureckiego.

## Na chodniku znaleziono węża. Właściciel poszukiwany
 - [https://epoznan.pl/news-news-143394-na_chodniku_znaleziono_weza_wlasciciel_poszukiwany?rss=1](https://epoznan.pl/news-news-143394-na_chodniku_znaleziono_weza_wlasciciel_poszukiwany?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T11:29:00+00:00

W Czarnkowie.

## Agresywny kierowca najpierw doprowadził do kolizji i uciekł, a chwilę później pobił innego kierowcę, bo ten zwrócił mu uwagę
 - [https://epoznan.pl/news-news-143388-agresywny_kierowca_najpierw_doprowadzil_do_kolizji_i_uciekl_a_chwile_pozniej_pobil_innego_kierowce_bo_ten_zwrocil_mu_uwage?rss=1](https://epoznan.pl/news-news-143388-agresywny_kierowca_najpierw_doprowadzil_do_kolizji_i_uciekl_a_chwile_pozniej_pobil_innego_kierowce_bo_ten_zwrocil_mu_uwage?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T11:00:00+00:00

Do zdarzenia doszło w powiecie jarocińskim.

## Coraz bliżej ogólnodostępnej stacji wodorowej w Poznaniu! Pierwsza taka w Polsce
 - [https://epoznan.pl/news-news-143386-coraz_blizej_ogolnodostepnej_stacji_wodorowej_w_poznaniu_pierwsza_taka_w_polsce?rss=1](https://epoznan.pl/news-news-143386-coraz_blizej_ogolnodostepnej_stacji_wodorowej_w_poznaniu_pierwsza_taka_w_polsce?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T10:20:00+00:00

Tankowanie wodoru będzie możliwe na stacji ORLEN przy ulicy Warszawskiej.

## Wyszła z domu zaprowadzić dziecko do szkoły i nie wróciła. &quot;Jej życie i zdrowie mogą być zagrożone&quot;
 - [https://epoznan.pl/news-news-143390-wyszla_z_domu_zaprowadzic_dziecko_do_szkoly_i_nie_wrocila_jej_zycie_i_zdrowie_moga_byc_zagrozone?rss=1](https://epoznan.pl/news-news-143390-wyszla_z_domu_zaprowadzic_dziecko_do_szkoly_i_nie_wrocila_jej_zycie_i_zdrowie_moga_byc_zagrozone?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T09:50:00+00:00

O pomoc apeluje gnieźnieńska policja.

## W sobotę zorganizowano dla niego festyn, w poniedziałek poinformowano o jego śmierci. Zmarł poznański strażak
 - [https://epoznan.pl/news-news-143389-w_sobote_zorganizowano_dla_niego_festyn_w_poniedzialek_poinformowano_o_jego_smierci_zmarl_poznanski_strazak?rss=1](https://epoznan.pl/news-news-143389-w_sobote_zorganizowano_dla_niego_festyn_w_poniedzialek_poinformowano_o_jego_smierci_zmarl_poznanski_strazak?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T09:18:00+00:00

Marcin Ratajczak nie żyje.

## 8 zastępów strażaków na Starym Rynku
 - [https://epoznan.pl/news-news-143387-8_zastepow_strazakow_na_starym_rynku?rss=1](https://epoznan.pl/news-news-143387-8_zastepow_strazakow_na_starym_rynku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T08:41:00+00:00

Zgłoszenie wpłynęło do służb około 10.00.

## Rusza proces byłego burmistrza Murowanej Gośliny. Grozi mu 10 lat więzienia
 - [https://epoznan.pl/news-news-143382-rusza_proces_bylego_burmistrza_murowanej_gosliny_grozi_mu_10_lat_wiezienia?rss=1](https://epoznan.pl/news-news-143382-rusza_proces_bylego_burmistrza_murowanej_gosliny_grozi_mu_10_lat_wiezienia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T08:35:00+00:00

Dariusz U. wciąż jest w areszcie.

## Wojskowe atrakcje dla wszystkich już w piątek w Poznaniu. Zaprezentują nowe czołgi
 - [https://epoznan.pl/news-news-143381-wojskowe_atrakcje_dla_wszystkich_juz_w_piatek_w_poznaniu_zaprezentuja_nowe_czolgi?rss=1](https://epoznan.pl/news-news-143381-wojskowe_atrakcje_dla_wszystkich_juz_w_piatek_w_poznaniu_zaprezentuja_nowe_czolgi?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T08:00:00+00:00

Na terenie Muzeum Broni Pancernej odbędzie się święto Centrum Szkolenia Wojsk Lądowych.

## Poznańska szkoła dla psów maltretowała czworonoga? Szkoła jest innego zdania
 - [https://epoznan.pl/news-news-143380-poznanska_szkola_dla_psow_maltretowala_czworonoga_szkola_jest_innego_zdania?rss=1](https://epoznan.pl/news-news-143380-poznanska_szkola_dla_psow_maltretowala_czworonoga_szkola_jest_innego_zdania?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T07:20:00+00:00

Sprawę nagłośniła właścicielka, ale do zarzutów odniosła się już szkoła, w której przebywał pies.

## Poznańscy urzędnicy chcą 700 zł podwyżki. Pikieta przed magistratem
 - [https://epoznan.pl/news-news-143377-poznanscy_urzednicy_chca_700_zl_podwyzki_pikieta_przed_magistratem?rss=1](https://epoznan.pl/news-news-143377-poznanscy_urzednicy_chca_700_zl_podwyzki_pikieta_przed_magistratem?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T06:40:00+00:00

Pikieta ma się rozpocząć we wtorek o 9.00.

## Duży korek na trasie S11 Kórnik - Poznań!
 - [https://epoznan.pl/news-news-143379-duzy_korek_na_trasie_s11_kornik_poznan?rss=1](https://epoznan.pl/news-news-143379-duzy_korek_na_trasie_s11_kornik_poznan?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T06:05:00+00:00

Doszło tam do awarii pojazdu.

## Armagedon komunikacyjny w Poznaniu. Przez utrudnienia na ważnym skrzyżowaniu
 - [https://epoznan.pl/news-news-143378-armagedon_komunikacyjny_w_poznaniu_przez_utrudnienia_na_waznym_skrzyzowaniu?rss=1](https://epoznan.pl/news-news-143378-armagedon_komunikacyjny_w_poznaniu_przez_utrudnienia_na_waznym_skrzyzowaniu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T05:52:00+00:00

Zgodnie z zapowiedziami, w poniedziałek wciąż trwają prace na skrzyżowaniu ulic Bukowskiej i Przybyszewskiego.

## &quot;Jeb** PiS&quot; znowu na betonowym brzegu Warty w Poznaniu
 - [https://epoznan.pl/news-news-143376-jeb_pis_znowu_na_betonowym_brzegu_warty_w_poznaniu?rss=1](https://epoznan.pl/news-news-143376-jeb_pis_znowu_na_betonowym_brzegu_warty_w_poznaniu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-09-25T05:30:00+00:00

O sprawie poinformował nas Czytelnik.

