# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## He is Guilty Until Proven Innocent!
 - [https://www.youtube.com/watch?v=fx_gOa8f0GM](https://www.youtube.com/watch?v=fx_gOa8f0GM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-09-25T23:00:18+00:00

Get your EMF Blocking Products at https://boncharge.com/jp 
Use Code "JP" For 15% Off!

Get your Freedom Merch Here - https://bit.ly/3SqObSZ

Upcoming LIVE shows - https://awakenwithjp.com/pages/tour

Get updates from me via email here: https://awakenwithjp.com/joinme

Russell Brand is GUILTY until proven innocent!!!

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
https://rumble.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## You'll Own Nothing and Be Happy About It! - LIES Ep. 8
 - [https://www.youtube.com/watch?v=ZkQszEu5nsE](https://www.youtube.com/watch?v=ZkQszEu5nsE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-09-25T20:06:35+00:00

Welcome to LIES You Can Trust Episode 8!

We will be streaming for 30 minutes or so here on YouTube and then the stream will move over to my Rumble Channel so be sure to tune in there!

## You'll Own Nothing and Be Happy About It! - LIES Ep. 8
 - [https://www.youtube.com/watch?v=T89_oeBv1Pg](https://www.youtube.com/watch?v=T89_oeBv1Pg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-09-25T19:57:53+00:00

Welcome to LIES You Can Trust Episode 8!

We will be streaming for 30 minutes or so here on YouTube and then the stream will move over to my Rumble Channel so be sure to tune in there!

## They Control The Weather Now!
 - [https://www.youtube.com/watch?v=489wqRTNpGc](https://www.youtube.com/watch?v=489wqRTNpGc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-09-25T12:43:51+00:00

#shorts #climatechange

