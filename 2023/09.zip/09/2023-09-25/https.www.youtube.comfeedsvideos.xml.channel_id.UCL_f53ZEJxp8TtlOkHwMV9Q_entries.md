# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## What Is A Woman? The Bible Has the Answer | Exodus: Episode 11
 - [https://www.youtube.com/watch?v=djP330OAthU](https://www.youtube.com/watch?v=djP330OAthU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2023-09-25T21:03:18+00:00

Thank you for joining us as we journey through the great book of Exodus. And thank you very much to the DailyWire+ crew for having the vision and generosity of spirit to make this Exodus seminar freely available to all who are interested. Perhaps you might consider a Daily Wire+ subscription; it's a bastion of free speech. We have great content there with much more to come. Click here to learn more: https://bit.ly/3Q0lXj7 

Jordan and Douglas Hadley unpack the significance of God’s laws in Exodus 21-24, discussing how they established a moral order and binary boundaries to prevent mankind from becoming like a God or reverting to an animal state with no morals.

Episode One will be available on YouTube indefinitely, serving as the gateway to this enlightening exploration. Episodes 2 through 17 will be available for a limited time, so be sure to watch as they release each Monday.


- Sponsors -

Try Hallow for 3 months FREE: https://hallow.com/EXODUS


- Chapters -

(0:00) Coming up
(0

