# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## How ITV portrayed Yorkshire Ripper victim Emily Jackson's final moments: New drama The Long Shadow shows part-time sex worker dancing at bar with man who looks like Peter Sutcliffe before being driven off in depraved serial killer's car
 - [https://www.dailymail.co.uk/news/article-12559679/How-ITV-portrayed-Yorkshire-Ripper-victim-Emily-Jacksons-final-moments-New-drama-Long-Shadow-shows-time-sex-worker-dancing-bar-man-looks-like-Peter-Sutcliffe-driven-depraved-serial-killers-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559679/How-ITV-portrayed-Yorkshire-Ripper-victim-Emily-Jacksons-final-moments-New-drama-Long-Shadow-shows-time-sex-worker-dancing-bar-man-looks-like-Peter-Sutcliffe-driven-depraved-serial-killers-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T23:00:53+00:00

The series, which details the police investigation into the 13 murders carried out by Peter Sutcliffe in his campaign of terror between 1975 and 1980, focuses on the victims of his heinous crimes.

## The SNP promised to protect the NHS - but now cancer patients are paying for their own chemotherapy, writes GRAHAM GRANT
 - [https://www.dailymail.co.uk/news/article-12559463/The-SNP-promised-protect-NHS-cancer-patients-paying-chemotherapy-writes-GRAHAM-GRANT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559463/The-SNP-promised-protect-NHS-cancer-patients-paying-chemotherapy-writes-GRAHAM-GRANT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T22:54:20+00:00

Welcome to Scotland in 2023, where heroin is 'free' on the NHS for the worst addicts but you might have to shell out for your own chemotherapy.

## 'Drug-smugglers' chased by Irish Navy in fishing trawler carrying up to '£100MILLION worth of cocaine' run stricken vessel aground on beach in Ireland amid stormy weather - sparking major security operation
 - [https://www.dailymail.co.uk/news/article-12559595/Drug-smugglers-chased-Irish-Navy-fishing-trawler-carrying-120MILLION-worth-cocaine-run-stricken-vessel-aground-beach-Ireland-amid-stormy-weather-sparking-major-security-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559595/Drug-smugglers-chased-Irish-Navy-fishing-trawler-carrying-120MILLION-worth-cocaine-run-stricken-vessel-aground-beach-Ireland-amid-stormy-weather-sparking-major-security-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T22:52:02+00:00

Tonight the Defence Forces, gardaí and the Irish Coast Guard were seen searching the waters near to Wexford, with the garda drugs unit also being involved in the 'live operation'.

## Party leaders haven't even spoken to 'ostracised' MP Cameron after her claims about treatment by colleagues
 - [https://www.dailymail.co.uk/news/article-12559349/Party-leaders-havent-spoken-ostracised-MP-Cameron-claims-treatment-colleagues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559349/Party-leaders-havent-spoken-ostracised-MP-Cameron-claims-treatment-colleagues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T22:50:59+00:00

The SNP 's leader at Westminster has been accused of 'abject failure' after he dismissed concerns by one of his MPs about 'hostile' colleagues.

## Trump says poll showing him 10 points up on Biden 'doesn't matter' because Joe 'may not make it' and Democrats have NO replacement: Rips into 'corrupt' Washington Post and ABC for calling results an 'outlier'
 - [https://www.dailymail.co.uk/news/article-12559789/Trump-says-poll-showing-10-points-Biden-doesnt-matter-Joe-not-make-Democrats-NO-replacement-Rips-corrupt-Washington-Post-ABC-calling-results-outlier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559789/Trump-says-poll-showing-10-points-Biden-doesnt-matter-Joe-not-make-Democrats-NO-replacement-Rips-corrupt-Washington-Post-ABC-calling-results-outlier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T22:48:35+00:00

Donald Trump both touted a poll that showed him 10 points ahead of President Joe Biden but also said the survey didn't matter because Democrats have no replacement for the low-polling president.

## Humza Yousaf WON'T row back on SNP's net zero boiler plans - despite Rishi Sunak watering down his own eco-pledges
 - [https://www.dailymail.co.uk/news/article-12559263/Humza-Yousaf-WONT-row-SNPs-net-zero-boiler-plans-despite-Rishi-Sunak-watering-eco-pledges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559263/Humza-Yousaf-WONT-row-SNPs-net-zero-boiler-plans-despite-Rishi-Sunak-watering-eco-pledges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T22:47:30+00:00

Humza Yousaf yesterday sparked anger within his own party after insisting he will not 'row back' on plans to ban gas boilers in Scotland.

## Michelle Obama to get a check for more than $700,000 for a one-hour speech about 'Diversity and Inclusion' at Munich conference
 - [https://www.dailymail.co.uk/news/article-12559675/michelle-obama-pay-munich-conference-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559675/michelle-obama-pay-munich-conference-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T22:38:13+00:00

According to the event's webpage, the ex-attorney was set to speak to some 5,000 attendees on how to 'push past self-doubt while discussing the importance of inclusivity and diversity.'

## Terrifying moment firefighters rescue a claustrophobic man after he gets TRAPPED inside his electric Corvette when the power doors stop working
 - [https://www.dailymail.co.uk/news/article-12559519/Terrifying-moment-firefighters-rescue-claustrophobic-man-gets-TRAPPED-inside-electric-Corvette-power-doors-stop-working.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559519/Terrifying-moment-firefighters-rescue-claustrophobic-man-gets-TRAPPED-inside-electric-Corvette-power-doors-stop-working.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T22:22:30+00:00

A TikTok video showed the scary moment firefighters had to rescue a man who was trapped inside his Corvette when the vehicle's electric doors stopped working.

## Colombian president's son Nicolas Petro to go on trial for laundering money that was donated to his father's presidential campaign
 - [https://www.dailymail.co.uk/news/article-12559571/Colombian-presidents-son-Nicolas-Petro-trial-laundering-money-donated-fathers-presidential-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559571/Colombian-presidents-son-Nicolas-Petro-trial-laundering-money-donated-fathers-presidential-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T22:06:23+00:00

Nicolás Petro, the son of Colombian President Gustavo Petro, is set to go on trial for money laundering and illicit enrichment. He's accused of accepting $259,000 in campaign donations.

## Lib Dems shoot down Ed Davey's bid to woo Tory voters by dropping the party's annual housebuilding pledge
 - [https://www.dailymail.co.uk/news/article-12559747/Lib-Dems-shoot-Ed-Daveys-bid-woo-Tory-voters-dropping-partys-annual-housebuilding-pledge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559747/Lib-Dems-shoot-Ed-Daveys-bid-woo-Tory-voters-dropping-partys-annual-housebuilding-pledge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:57:19+00:00

Sir Davey wanted to drop the pledge to build 380,000 homes each year and replace it with a target of 150,000 council houses. But his plans were rejected at the party conference yesterday.

## Rail passengers are hit with three years worth of delays in just 12 months due to faulty trains with 760,000 journeys delayed since 2020, figures reveal
 - [https://www.dailymail.co.uk/news/article-12559749/Rail-passengers-hit-three-years-worth-delays-just-12-months-faulty-trains-760-000-journeys-delayed-2020-figures-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559749/Rail-passengers-hit-three-years-worth-delays-just-12-months-faulty-trains-760-000-journeys-delayed-2020-figures-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:56:28+00:00

Between April and August this year, delays cost passengers 711,397 minutes due to almost 100,000 incidents, according to data obtained via Freedom of Information requests

## Rollercoaster victim's living hell: Tragic update on Shylah Rodden after recovering from injuries in accident that shocked Australia
 - [https://www.dailymail.co.uk/news/article-12559761/Rollercoaster-victims-living-hell-Tragic-update-Shylah-Rodden-recovering-injuries-accident-shocked-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559761/Rollercoaster-victims-living-hell-Tragic-update-Shylah-Rodden-recovering-injuries-accident-shocked-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:55:36+00:00

One year after a terrifying incident in which she was struck by a moving rollercoaster, a woman from Melbourne who was initially in critical condition and fighting for her life is now not only walking but also able to speak again.

## Labour by-election candidate owns a home in a leafy suburb 25 miles from the constituency despite claiming she lives locally
 - [https://www.dailymail.co.uk/news/article-12559763/Labour-election-candidate-owns-home-leafy-suburb-25-miles-constituency-despite-claiming-lives-locally.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559763/Labour-election-candidate-owns-home-leafy-suburb-25-miles-constituency-despite-claiming-lives-locally.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:50:47+00:00

Labour's Sarah Edwards has only just started renting out a flat in Tamworth, despite putting the address on her nomination form and telling voters she is based in the Staffordshire constituency.

## Monthly average payments for homeowners stand at $2,161 - an increase of $1,000 since before the pandemic - as Fed Chair Powell continues to hike rates in struggle to tamp down inflation
 - [https://www.dailymail.co.uk/news/article-12558981/mortgages-bills-double-bank-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558981/mortgages-bills-double-bank-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:50:18+00:00

The average monthly mortgage payment on an American home has soared from $1,191 in January 2020 to $2,161 in July this year according to the Mortgage Brokers Association.

## Biden says Americans should 'stop electing Republicans' if they shut down the government: White House ramps up criticism as Kevin McCarthy and GOP try to break stalemate with five days until deadline
 - [https://www.dailymail.co.uk/news/article-12559625/Biden-says-Americans-stop-electing-Republicans-shut-government-White-House-ramps-criticism-Kevin-McCarthy-GOP-try-break-stalemate-five-days-deadline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559625/Biden-says-Americans-stop-electing-Republicans-shut-government-White-House-ramps-criticism-Kevin-McCarthy-GOP-try-break-stalemate-five-days-deadline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:41:18+00:00

'If Republicans in the House don't start doing their job, we should stop electing them,' Biden said

## Channel boat migrants should not be treated as refugees and international asylum laws create 'huge incentives for illegal migration', Suella Braverman to say in major speech
 - [https://www.dailymail.co.uk/news/article-12559701/Channel-boat-migrants-not-treated-refugees-international-asylum-laws-create-huge-incentives-illegal-migration-Suella-Braverman-say-major-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559701/Channel-boat-migrants-not-treated-refugees-international-asylum-laws-create-huge-incentives-illegal-migration-Suella-Braverman-say-major-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:40:44+00:00

In a hard-hitting speech, the Home Secretary will claim international asylum laws are creating an 'absurd and unsustainable' system with 'huge incentives for illegal migration'.

## Gordon Brown says countries which made 'staggering' profits from soaring oil prices should pay a climate change levy
 - [https://www.dailymail.co.uk/news/article-12559713/Gordon-Brown-says-countries-staggering-profits-soaring-oil-prices-pay-climate-change-levy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559713/Gordon-Brown-says-countries-staggering-profits-soaring-oil-prices-pay-climate-change-levy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:40:26+00:00

Saudi Arabia, the UAE, Qatar and Norway and others benefited from a 'lottery-style bonanza' after their profits more than doubled in 2022, the former prime minister claimed.

## DAVID JONES: The Mafia's last Godfather who boasted he 'filled a graveyard all by myself'... He dissolved one child victim in acid but also loved women and high culture. Now he's died after 30 years on the run
 - [https://www.dailymail.co.uk/news/article-12559699/DAVID-JONES-Mafias-Godfather-boasted-filled-graveyard-dissolved-one-child-victim-acid-loved-women-high-culture-hes-died-30-years-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559699/DAVID-JONES-Mafias-Godfather-boasted-filled-graveyard-dissolved-one-child-victim-acid-loved-women-high-culture-hes-died-30-years-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:39:37+00:00

DAVID JONES: Suffering from incurable colon cancer, Matteo Messina Denaro - the last all-powerful Mafia godfather - scrawled his funeral instructions on a scrap of paper.

## 'Victoria Secret Karen' seen in 2021 viral 'race-based' meltdown in which she slapped a black customer on camera blames disability for her actions and 'feared being filmed would cost her job and apartment'
 - [https://www.dailymail.co.uk/news/article-12559355/Victoria-Secret-Karen-abigail-elphick-meltdown-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559355/Victoria-Secret-Karen-abigail-elphick-meltdown-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:30:10+00:00

Ijeoma Ukenta, the woman who recorded the 2021 viral 'Victoria's Secret Karen' has filed a civil lawsuit. Filings show the 'Karen', Abigail Elphick is disabled and has a history of mental illness.

## Don't scatter your loved one's ashes on a mountain top (and don't leave plaques in their memory either!)
 - [https://www.dailymail.co.uk/news/article-12559417/Dont-scatter-loved-ones-ashes-mountain-dont-leave-plaques-memory-either.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559417/Dont-scatter-loved-ones-ashes-mountain-dont-leave-plaques-memory-either.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:25:12+00:00

Guidance has been issued by Mountaineering Scotland amid a rise in people wanting their remains scattered in the country's hillsides.

## Huge clash erupts on Q+A over The Voice to Parliament: 'Corrupt'
 - [https://www.dailymail.co.uk/news/article-12558179/Huge-clash-erupts-Q-Voice-Parliament-Corrupt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558179/Huge-clash-erupts-Q-Voice-Parliament-Corrupt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:19:56+00:00

Two opposing Voice to Parliament advocates have squabbled over the upcoming referendum and its comparisons to a now defunct Indigenous advisory body.

## Ministers have known the business case for HS2 does not stack up for nearly two years, sources claim - prompting anger as critics claim the project will not deliver its promised boost
 - [https://www.dailymail.co.uk/news/article-12559659/Ministers-known-business-case-HS2-does-not-stack-nearly-two-years-sources-claim-prompting-anger-critics-claim-project-not-deliver-promised-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559659/Ministers-known-business-case-HS2-does-not-stack-nearly-two-years-sources-claim-prompting-anger-critics-claim-project-not-deliver-promised-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:18:03+00:00

EXCLUSIVE: Sources involved with the beleaguered project said officials were aware in the winter of 2021 that they would get as little as 90p of benefit for each pound of public money spent.

## Labour is accused of 'recklessly' eroding civil service impartiality by hiring host of Whitehall officials
 - [https://www.dailymail.co.uk/news/article-12559635/Labour-accused-recklessly-eroding-civil-service-impartiality-hiring-host-Whitehall-officials.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559635/Labour-accused-recklessly-eroding-civil-service-impartiality-hiring-host-Whitehall-officials.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:17:41+00:00

In the latest sign of 'the Blob' moving to the opposition party, it emerged that Sir Keir Starmer has recruited civil servants from No 10, the Treasury and other departments

## Justin Trudeau says 'it's important to push back against Russian propaganda' as he is grilled over Nazi in Canadian parliament
 - [https://www.dailymail.co.uk/news/article-12559497/Justin-Trudeau-nazi-parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559497/Justin-Trudeau-nazi-parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:17:26+00:00

Justin Trudeau has said it's important to push back against Russian propaganda when grilled about the blunder that saw  parliament honor a Nazi.

## Charlamagne tha God slams Biden for calling LL Cool J 'boy' and says the president used a 'white racist word'
 - [https://www.dailymail.co.uk/news/article-12559373/Charlamagne-tha-God-Biden-LL-Cool-J-boy-racist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559373/Charlamagne-tha-God-Biden-LL-Cool-J-boy-racist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:16:22+00:00

The Breakfast Club host Charlamagne tha God blasted the president for  botching LL Cool J's name and using a 'racist' term to refer to him at a Congressional Black Caucus Foundation event.

## EXCLUSIVE: Superintendent of Kansas school district where Jaylee Chillson, 14, shot herself in front of cops was 'mercilessly bullied' says her death is a 'tragic loss' - and does not deny allegations that she was tormented
 - [https://www.dailymail.co.uk/news/article-12559443/Superintendent-kansas-jaylee-chillson-dead-shot-school-bullied.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559443/Superintendent-kansas-jaylee-chillson-dead-shot-school-bullied.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:08:35+00:00

Jaylee Chillson, 14, left her family home to attend the gathering in a field in Aurora, Kansas, after being told she wasn't allowed to go.

## Firefighters battle huge blaze as Ayr's historic Victorian railway hotel goes up in flames
 - [https://www.dailymail.co.uk/news/article-12559487/Firefighters-battle-huge-blaze-Ayrs-historic-Victorian-railway-hotel-goes-flames.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559487/Firefighters-battle-huge-blaze-Ayrs-historic-Victorian-railway-hotel-goes-flames.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T21:06:00+00:00

Engulfed in flames, these were the scenes as firefighters tackled a blaze at a once grand Victorian railway hotel.

## Winter weather report: Warmer, drier winter is predicted for the north - and wetter than normal across the southern states as forecasters make El Niño readings
 - [https://www.dailymail.co.uk/news/article-12559187/Warmer-winter-predicted-El-Nino-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559187/Warmer-winter-predicted-El-Nino-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:55:09+00:00

People living in the northern parts of the US may experience a warmer, drier winter - while the southern states may get more rain and snow as forecasters continue to track 'El Niño.'

## Black Lives Matter organiser behind the protest which toppled Edward Colston's statue in Bristol admits fraud after £30,000 raised from donors goes missing
 - [https://www.dailymail.co.uk/news/article-12559507/Black-Lives-Matter-organiser-protest-Edward-Colston-Bristol-admits-fraud.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559507/Black-Lives-Matter-organiser-protest-Edward-Colston-Bristol-admits-fraud.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:53:47+00:00

Xahra Saleem, 23, pleaded guilty to one count of fraud by abuse of position following an investigation by police into a GoFundMe page set up ahead of the protest in Bristol in June 2020.

## You've heard of the Bermuda Triangle, now meet the 'Alaska Triangle' where 20,000 people have vanished since 1970 and UFOs appear
 - [https://www.dailymail.co.uk/news/article-12559077/alaska-triangle-missing-persons-ufo-sasquatch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559077/alaska-triangle-missing-persons-ufo-sasquatch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:52:40+00:00

The Alaska Triangle is at the center of thousands of disappearances, twice the national missing person rate, which have been blamed on mysterious phenomena in the area.

## Canterbury Rd fire, Sydney: Huge blaze breaks out, traffic delays expected
 - [https://www.dailymail.co.uk/news/article-12559503/Canterbury-Rd-fire-Sydney-Huge-blaze-breaks-traffic-delays-expected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559503/Canterbury-Rd-fire-Sydney-Huge-blaze-breaks-traffic-delays-expected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:49:46+00:00

Part of Canterbury Road remains closed on Tuesday morning after dozens of firefighters spent the night battling the ferocious blaze.

## 'Thinking of you Mum, more than ever': Son of Yorkshire Ripper's first victim Wilma McCann pays tribute to mother-of-four as ITV drama The Long Shadow about hunt for depraved serial killer Peter Sutcliffe is aired
 - [https://www.dailymail.co.uk/news/article-12559511/Thinking-Mum-Son-Yorkshire-Rippers-victim-Wilma-McCann-pays-tribute-mother-four-ITV-drama-Long-Shadow-hunt-depraved-serial-killer-Peter-Sutcliffe-aired.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559511/Thinking-Mum-Son-Yorkshire-Rippers-victim-Wilma-McCann-pays-tribute-mother-four-ITV-drama-Long-Shadow-hunt-depraved-serial-killer-Peter-Sutcliffe-aired.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:49:17+00:00

The tragic final days of Wilma, 28, and Sutcliffe's second victim Emily Jackson, 42, will be re-told tonight in The Long Shadow which is airing across seven episodes, starting this evening.

## Police marksmen ousted for sharing pictures of a hand puppet named 'Swoop' at their sniper post lose sexism appeal
 - [https://www.dailymail.co.uk/news/article-12559553/Police-snipers-hand-puppet-lose-sexism-appeal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559553/Police-snipers-hand-puppet-lose-sexism-appeal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:47:46+00:00

Marksmen Sergeant Richard Lovelock and PC Jonathan Sayers were sent back to London during COP26 in Glasgow in 2021 after a light-hearted post featuring the stuffed toy called 'Swoop'.

## Third person Renny Antonio Parra Paredes charged with drug distribution after Nicholas Feliz Dominici, one, died at Bronx day care after ingesting fentanyl - as cops expand manhunt to Dominican Republic for owner's husband
 - [https://www.dailymail.co.uk/news/article-12559317/Bronx-day-care-charges-drugs-fentanyl-kids-died-dominican-republic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559317/Bronx-day-care-charges-drugs-fentanyl-kids-died-dominican-republic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:44:17+00:00

Renny Antonio Parra Paredes, 38, has been charged with drug distribution linked to the death of Nicholas Feliz Dominici, 1, who died at Divino Niño Daycare.

## The horror of Putin's war laid bare: Wounded Ukrainian soldiers are brutalised in counter-offensive to claw back captured Bakhmut from Russia - as barbaric invasion grinds on
 - [https://www.dailymail.co.uk/news/article-12559379/The-horror-Putins-war-laid-bare-Wounded-Ukrainian-soldiers-brutalised-counter-offensive-claw-captured-Bakhmut-Russia-barbaric-invasion-grinds-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559379/The-horror-Putins-war-laid-bare-Wounded-Ukrainian-soldiers-brutalised-counter-offensive-claw-captured-Bakhmut-Russia-barbaric-invasion-grinds-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:39:20+00:00

WARNING - GRAPHIC CONTENT: Wounded soldiers from the 10th Mountain Assault Bridage were seen barely patched and still covered in the dirt from the counteroffensive push for Bakhmut

## Pennsylvania cop's mistress spent THREE DAYS in a mental hospital after he had her involuntarily committed when they broke up as he is suspended without pay and charged over horrifying arrest video
 - [https://www.dailymail.co.uk/news/article-12559385/Pennsylvania-cops-mistress-spent-THREE-DAYS-mental-hospital-involuntarily-committed-broke-suspended-without-pay-charged-horrifying-arrest-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559385/Pennsylvania-cops-mistress-spent-THREE-DAYS-mental-hospital-involuntarily-committed-broke-suspended-without-pay-charged-horrifying-arrest-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:27:11+00:00

Ronald K. Davis, 37, is now facing charges for abusing his power and authority to convince peers to issue a mental health evaluation and section his girlfriend, Michelle Perfanov, in August.

## The Office reboot: Greg Daniels will reportedly lead reboot of NBC sitcom after Hollywood strikes end
 - [https://www.dailymail.co.uk/news/article-12559179/office-reboot-cast-release-date-details.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559179/office-reboot-cast-release-date-details.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:13:12+00:00

A new report indicates that a reboot of the American version of 'The Office' is in the works at NBC and will be announced once the WGA and SAG-AFTRA strikes end.

## 'Babies old enough to feel pain will be aborted': Tim Scott accuses some Republicans of 'retreating on life' as he gets aggressive ahead of the second GOP debate
 - [https://www.dailymail.co.uk/news/article-12559091/Babies-old-feel-pain-aborted-Tim-Scott-accuses-Republicans-retreating-life-gets-aggressive-ahead-second-GOP-debate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559091/Babies-old-feel-pain-aborted-Tim-Scott-accuses-Republicans-retreating-life-gets-aggressive-ahead-second-GOP-debate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:13:05+00:00

Republican presidential hopeful Tim Scott wagged his finger at his fellow GOP hopefuls, accusing them Monday of waffling on the issue of abortion.

## The grass is always greener! Residents succeed in bid to get narrow strip of grass opposite their houses classified as a village green to stop developers building on it
 - [https://www.dailymail.co.uk/news/article-12559173/Residents-Ashford-Kent-succeed-bid-village-green-stop-developers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559173/Residents-Ashford-Kent-succeed-bid-village-green-stop-developers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T20:03:46+00:00

People living in Quantock Drive estate, in Ashford, Kent, applied for the strip of land to become a village green after it was sold to developers last year.

## Fourteen-year-old is charged with terroristic threats for multiple bomb threats on Kentucky Bridge which shut vital link across Ohio River for hours
 - [https://www.dailymail.co.uk/news/article-12559319/boy-charged-Kentucky-bridge-bomb-threats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559319/boy-charged-Kentucky-bridge-bomb-threats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:58:49+00:00

A 14-year-old boy has been charged over a number of hoax phone calls which threatened to blow up the John A. Roebling Suspension Bridge.

## Teenage motorcyclist, 18, is killed after crashing into taxi and a bin during police-chase through London - as 'machete-wielding' passenger, 17, is arrested by Met officers
 - [https://www.dailymail.co.uk/news/article-12559335/Teenage-motorcyclist-killed-crashing-taxi-police-chase-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559335/Teenage-motorcyclist-killed-crashing-taxi-police-chase-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:58:32+00:00

The 18-year-old suffered fatal injuries after crashing in Tottenham Court Road close to Warren Street tube station at around 6.45am.

## BBC presenter Ray Clark quits Radio Essex after claiming he'd been treated 'cruelly' by bosses who 'kept him in the dark' for a year about the future of his show - after Sophie Little blasted 'ageist' local radio cuts in last episode of cancelled programme
 - [https://www.dailymail.co.uk/news/article-12559257/BBC-presenter-Ray-Clark-quits-Radio-Essex-claiming-hed-treated-cruelly-bosses-kept-dark-year-future-Sophie-Little-blasted-ageist-local-radio-cuts-episode-cancelled-programme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559257/BBC-presenter-Ray-Clark-quits-Radio-Essex-claiming-hed-treated-cruelly-bosses-kept-dark-year-future-Sophie-Little-blasted-ageist-local-radio-cuts-episode-cancelled-programme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:50:36+00:00

Ray Clark shared the news on X, formerly known as Twitter, claiming that after a year of uncertainty about the future of Radio Essex he has had enough.

## Karine Jean-Pierre REFUSES to say if 'Union Joe' backs UAW workers' demands for a four-day week and 40% pay hike during grilling on where he stands as he prepares to visit Detroit picket line
 - [https://www.dailymail.co.uk/news/article-12559219/Karine-Jean-Pierre-REFUSES-say-Union-Joe-backs-UAW-workers-demands-four-day-week-40-pay-hike-grilling-stands-prepares-visit-Detroit-picket-line.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559219/Karine-Jean-Pierre-REFUSES-say-Union-Joe-backs-UAW-workers-demands-four-day-week-40-pay-hike-grilling-stands-prepares-visit-Detroit-picket-line.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:47:03+00:00

President Biden 'stands with the workers' he will visit when he meets with striking UAW members in Detroit Tuesday. But the White House wouldn't speak to proposals they 'put on the table.'

## Venezuelan flag planted on Texas island by brazen migrants is taken down by DPS Tactical Marine unit as United Nations intervenes in crisis with program to pre-screen 40,000 asylum seekers in Mexico
 - [https://www.dailymail.co.uk/news/article-12559165/Venezuela-flag-rio-grande.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559165/Venezuela-flag-rio-grande.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:35:06+00:00

A Venezuelan flag was planted in the middle of the Rio Grande at the US-Mexico border at Eagle Pass before it was promptly taken down by Texas officials over the weekend.

## Shocking moment ruthless teenage son of Putin's Chechen warlord Ramzan Kadyrov brutally beats Ukrainian being held on suspicion of burning the Koran
 - [https://www.dailymail.co.uk/news/article-12559079/Shocking-moment-ruthless-teenage-son-Putins-Chechen-warlord-Ramzan-Kadyrov-brutally-beats-Ukrainian-held-suspicion-burning-Koran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559079/Shocking-moment-ruthless-teenage-son-Putins-Chechen-warlord-Ramzan-Kadyrov-brutally-beats-Ukrainian-held-suspicion-burning-Koran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:32:28+00:00

Adam Kadyrov, 15, was caught on tape pulverising Nikita Zhuravel, 19, a native Ukrainian, who was held in a detention cell for allegedly burning a copy of Islam's holy book

## DAVID MARCUS: A catastrophic Washington Post poll so awful for Biden that editors buried it. But don't they and the Deluded Dems realize that every day Joe clings on, Don inches closer to the White House?
 - [https://www.dailymail.co.uk/news/article-12559205/DAVID-MARCUS-catastrophic-Washington-Post-poll-Biden-Trump-10-points-White-House.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559205/DAVID-MARCUS-catastrophic-Washington-Post-poll-Biden-Trump-10-points-White-House.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:26:43+00:00

This weekend, a poll by the Lefty DC newspaper showed Trump to be absolutely spanking the current commander in chief by 10 points among registered voters.

## Moment glamorous Spanish influencer Isabella Gonzalez berates 'Brit tourist' in Benidorm pub after he 'touches her bottom during live Twitch broadcast' - as she reveals she's reported incident to police in Costa Blanca resort
 - [https://www.dailymail.co.uk/news/article-12559171/Moment-glamorous-Spanish-influencer-Isabella-Gonzalez-berates-Brit-tourist-Benidorm-pub-touches-bottom-live-Twitch-broadcast-reveals-shes-reported-incident-police-Costa-Blanca-resort.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559171/Moment-glamorous-Spanish-influencer-Isabella-Gonzalez-berates-Brit-tourist-Benidorm-pub-touches-bottom-live-Twitch-broadcast-reveals-shes-reported-incident-police-Costa-Blanca-resort.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:26:04+00:00

Isabella Gonzalez, who is better known by her social media name Gonsabellla, turned around and repeatedly warned the man not to touch her during a livestream in a Benidorm pub.

## Ethnic cleansing fears as thousands flee Nagorno-Karabakh into Armenia after Azerbaijan seized the disputed enclave
 - [https://www.dailymail.co.uk/news/article-12559105/Ethnic-cleansing-fears-thousands-flee-Nagorno-Karabakh-Armenia-Azerbaijan-seized-disputed-enclave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559105/Ethnic-cleansing-fears-thousands-flee-Nagorno-Karabakh-Armenia-Azerbaijan-seized-disputed-enclave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:08:50+00:00

Armenia's prime minister said that the country has plans to look after up to 40,000 refugees, but said he expects up to 120,000 people to leave the region due to the 'danger of ethnic cleansing'

## Painting by famed female artist that was owned by King Charles I and thought to have been lost following his execution in 1649 undergoes restoration after being re-discovered in poor condition in the Royal Collection
 - [https://www.dailymail.co.uk/news/article-12549805/Painting-famed-female-artist-owned-King-Charles-thought-lost-following-execution-1649-undergoes-restoration-discovered-poor-condition-Royal-Collection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12549805/Painting-famed-female-artist-owned-King-Charles-thought-lost-following-execution-1649-undergoes-restoration-discovered-poor-condition-Royal-Collection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T19:07:35+00:00

A 'lost' painting by famed female artist Artemisia Gentileschi has been re-discovered in the Royal Collection after being misattributed to an unknown artist two centuries ago.

## Trump goes GUN shopping with Marjorie Taylor Greene: Former president buys a $829.99 9MM GLOCK with his face on the butt in armory tour
 - [https://www.dailymail.co.uk/news/article-12559135/Trump-GUN-shopping-Marjorie-Taylor-Greene-829-99-9MM-GLOCK-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559135/Trump-GUN-shopping-Marjorie-Taylor-Greene-829-99-9MM-GLOCK-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T18:43:24+00:00

Donald Trump bought a glock with his face on it during a visit to South Carolina on Monday, stopping at the Palmetto State Armory with Rep. Marjorie Taylor Greene to purchase the pistol.

## Albanian man, 42, appears in court charged over £1.9m cannabis farm that was discovered above town centre Job Centre Plus building
 - [https://www.dailymail.co.uk/news/article-12558839/Albanian-man-42-appears-court-charged-1-9m-cannabis-farm-discovered-town-centre-Job-Centre-Plus-building.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558839/Albanian-man-42-appears-court-charged-1-9m-cannabis-farm-discovered-town-centre-Job-Centre-Plus-building.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T18:43:20+00:00

Police officers raided the upper floors of the employment centre in August, where they found 2,300 cannabis plants growing across 16 different vacant floors.

## Canadian twins 'pretended to be Inuit to receive more than $10,000 in college scholarships and grants for their facemask business'
 - [https://www.dailymail.co.uk/news/article-12558675/Canadian-twins-pretended-Inuit-receive-10-000-college-scholarships-grants-facemask-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558675/Canadian-twins-pretended-Inuit-receive-10-000-college-scholarships-grants-facemask-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T18:40:57+00:00

Amira and Nadya Gill, 25, were charged along with their mother, Karima Manji, with fraud of over $5,000 each.

## 'Craziest s*** I EVER watched on TV': Infamous UK dating show Naked Attraction featuring full frontal nudity makes its US debut on HBO Max causing outrage over 'horrible' premise
 - [https://www.dailymail.co.uk/news/article-12558999/Naked-Attraction-Max-UK-dating-outrage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558999/Naked-Attraction-Max-UK-dating-outrage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T18:38:37+00:00

Naked Attraction, which has graced screens in the UK for years, showcases six naked people to one contestant, who gets to whittle down their choices and eventually go on a date with their favorite.

## Eight JetBlue passengers are rushed to hospital after sudden turbulence batters flight from Ecuador to Florida
 - [https://www.dailymail.co.uk/news/article-12559143/JetBlue-passengers-hospitalized-turbulence-Ecuador-Florida.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559143/JetBlue-passengers-hospitalized-turbulence-Ecuador-Florida.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T18:37:13+00:00

Seven customers and one crew member from JetBlue flight 1256 were hospitalized after experiencing severe turbulence. The flight was from Ecuador to Fort Lauderdale.

## White neighbor and German-shepherd owning woman hose down prominent black doctor and their dinner party guests in plush NYC suburb 'because they were too loud'
 - [https://www.dailymail.co.uk/news/article-12558707/black-doctor-hosed-white-neighbor-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558707/black-doctor-hosed-white-neighbor-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T18:31:15+00:00

A leading doctor who threw a backyard party for his sister's birthday in Queens claims their group was 'hosed' with water by a 'racist' white neighbor during a noise dispute, according to a lawsuit.

## NY Gov. Kathy Hochul deploys another 150 National Guardsmen as migrant crisis turns lawless: Two asylum seekers are arrested at the Roosevelt Hotel after 'beating up girlfriends'
 - [https://www.dailymail.co.uk/news/article-12558793/nyc-migrants-arrested-National-Guard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558793/nyc-migrants-arrested-National-Guard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T18:13:38+00:00

Kathy Hochul has asked the national guard to assist during the asylum seeker crisis in NYC.

## Sex addict doctor threatened to reveal affair to his lover's partner - but was relieved when the 'taller, more muscular' love rival was not there when he arrived for a meeting, tribunal hears
 - [https://www.dailymail.co.uk/news/article-12559053/Sex-addict-doctor-threatened-reveal-affair-tribunal-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559053/Sex-addict-doctor-threatened-reveal-affair-tribunal-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T18:08:14+00:00

Tom Plimmer, 40, accused of liaisons with multiple women at his surgery, allegedly threatened to disclose information to the woman's partner, a tribunal heard today.

## Turkish radio DJ 'who was kidnapped and tortured to death' told his sobbing girlfriend 'be quiet my love' before she was beaten unconscious by gang, court hears
 - [https://www.dailymail.co.uk/news/article-12558831/Turkish-radio-DJ-kidnapped-tortured-death-told-sobbing-girlfriend-quiet-love-beaten-unconscious-gang-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558831/Turkish-radio-DJ-kidnapped-tortured-death-told-sobbing-girlfriend-quiet-love-beaten-unconscious-gang-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:47:33+00:00

Murdered Turkish radio DJ Koray Alpergin, 43, told his sobbing girlfriend 'be quiet my love' before she was beaten unconscious by a gang of kidnappers who went on to hill him, a court heard.

## Minnesota's newly-appointed marijuana chief Erin Dupree is forced to resign over claims she sold edibles double the strength of legal limit
 - [https://www.dailymail.co.uk/news/article-12558331/Minnesota-marijuana-chief-Erin-Dupree-resigns-illegal-edibles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558331/Minnesota-marijuana-chief-Erin-Dupree-resigns-illegal-edibles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:46:59+00:00

Minnesota's new head of marijuana regulation Erin Dupree, 43, stepped down from her $151,505-a-year post amid the claims she broke the marijuana regulations she was hired to oversee.

## Now Gatwick bosses impose limit on number of daily flights out of London airport for the WHOLE week as coronavirus outbreak among air traffic control staff sparks travel chaos for thousands of passengers
 - [https://www.dailymail.co.uk/news/article-12558869/Now-Gatwick-bosses-impose-limit-number-daily-flights-London-airport-week-coronavirus-outbreak-air-traffic-control-staff-sparks-travel-chaos-thousands-passengers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558869/Now-Gatwick-bosses-impose-limit-number-daily-flights-London-airport-week-coronavirus-outbreak-air-traffic-control-staff-sparks-travel-chaos-thousands-passengers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:36:59+00:00

The airport will be limited to 800 movements a day, starting today and remaining in place until Sunday, October 1.

## Martin Scorsese slams Marvel movies AGAIN and says audiences must 'fight back' against comic book culture by supporting directors like Oppenheimer's Christopher Nolan instead
 - [https://www.dailymail.co.uk/news/article-12558653/Martin-Scorsese-slams-Marvel-movies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558653/Martin-Scorsese-slams-Marvel-movies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:35:33+00:00

In an interview with GQ magazine, director Martin Scorsese criticized ratings obsessed franchise films. He said they are a danger to our culture and that directors like Christopher Nolan have to save film.

## Ex-deputy head of boarding at £36,000-a-year public school Queen Ethelburga's, 47, is jailed for string of sex offences including molesting girl aged eight
 - [https://www.dailymail.co.uk/news/article-12558493/Ex-deputy-head-boarding-36-000-year-public-school-Queen-Ethelburgas-47-jailed-string-sex-offences-including-molesting-girl-aged-eight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558493/Ex-deputy-head-boarding-36-000-year-public-school-Queen-Ethelburgas-47-jailed-string-sex-offences-including-molesting-girl-aged-eight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:35:01+00:00

Alexander Ralls, 47, who was deputy head of boarding at £36,000-a-year Queen Ethelburga's public school near York, molested 20 girls in his care.

## Rishi Sunak gets a boost before Tory conference as polls show Conservatives clawing back ground on Labour following Net Zero U-turn - while PM's personal ratings also rise
 - [https://www.dailymail.co.uk/news/article-12559003/Rishi-Sunak-gets-boost-Tory-conference-polls-Conservatives-clawing-ground-Labour-following-Net-Zero-U-turn-PMs-personal-ratings-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12559003/Rishi-Sunak-gets-boost-Tory-conference-polls-Conservatives-clawing-ground-Labour-following-Net-Zero-U-turn-PMs-personal-ratings-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:34:05+00:00

The latest Deltapoll research showed the Conservatives 16 points behind Sir Keir Statmer's party, which is eight points closer than 10 days ago.

## Hillary Clinton warns Joe Biden in private meeting that third-party candidates could prove disastrous for him as White House insider calls situation 'pretty f***ing concerning'
 - [https://www.dailymail.co.uk/news/article-12558453/Hillary-Clinton-warns-Joe-Biden-private-meeting-party-candidates-prove-disastrous-White-House-official-calls-situation-pretty-f-ing-concerning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558453/Hillary-Clinton-warns-Joe-Biden-private-meeting-party-candidates-prove-disastrous-White-House-official-calls-situation-pretty-f-ing-concerning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:33:45+00:00

Hillary Clinton warned President Joe Biden in a private meeting that he needed to take the threat of a third-party challenger seriously.

## NYC teens are going to school STONED 'every day' as drug use rockets by 17% in the last year after marijuana is decriminalized in the city
 - [https://www.dailymail.co.uk/news/article-12558245/nyc-teens-smoke-marijuana-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558245/nyc-teens-smoke-marijuana-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:28:37+00:00

More than 2,000 unlicensed dispensaries have sprung up across the city since legalization in 2021 selling strains three times as powerful as those illegally available 25 years ago.

## Buffy reunion: Sarah Michelle Gellar, Seth Green and Emma Caulfield reunite at Ed Sheeran concert in Los Angeles
 - [https://www.dailymail.co.uk/news/article-12558655/buffy-vampire-slayer-actress-actor-reunion-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558655/buffy-vampire-slayer-actress-actor-reunion-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:28:05+00:00

'Buffy the Vampire Slayer' cast members Sarah Michelle Gellar, Seth Green and Emma Caulfield reunited at Ed Sheeran's tour in Los Angeles Sunday night.

## SNP's deputy first minister Shona Robison accused of 'disgraceful' disrespect after arriving 40 minutes late for an event with Princess Anne
 - [https://www.dailymail.co.uk/news/article-12558897/SNPs-deputy-minister-Shona-Robison-accused-disgraceful-disrespect-arriving-40-minutes-late-event-Princess-Anne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558897/SNPs-deputy-minister-Shona-Robison-accused-disgraceful-disrespect-arriving-40-minutes-late-event-Princess-Anne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:27:41+00:00

Humza Yousaf's second-in-command attended the Royal opening of Aberdeen South Harbour on behalf of the Scottish Government but angered many of the 350 guests by keeping them waiting.

## Not again! Biden gives up after botching acronym and says it 'doesn't matter what we call it' as he hosts Pacific Island forum amid rising China threat
 - [https://www.dailymail.co.uk/news/article-12558725/Biden-gives-botching-acronym-says-doesnt-matter-call-hosts-Pacific-Island-forum-amid-rising-China-threat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558725/Biden-gives-botching-acronym-says-doesnt-matter-call-hosts-Pacific-Island-forum-amid-rising-China-threat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:24:55+00:00

President Biden didn't let a little acronym get in the way of stalling his remarks Monday. 'Doesn't matter what we call it, but that's what it is,' Biden said, skipping over the shorthand for an initiative.

## Moment Mexico residents hold parade for Sinaloa Cartel for rescuing them from the shackles of rival Jalisco New Generation cartel that extorted and killed business owners and civilians
 - [https://www.dailymail.co.uk/news/article-12558301/Mexico-drug-cartel-parade-rescue-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558301/Mexico-drug-cartel-parade-rescue-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:21:05+00:00

Video emerged Saturday of the moment Sinaloa Cartel members armed and dressed in military gear were cheered during a parade in the southern Mexico state of Chiapas across from Guatemala.

## Murderer, 20, is jailed for 20 years for stabbing to death homeless man, 45, who was once hailed a hero for pulling dying stranger from a river
 - [https://www.dailymail.co.uk/news/article-12558887/Murderer-20-jailed-20-years-stabbing-death-homeless-man-45-hailed-hero-pulling-dying-stranger-river.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558887/Murderer-20-jailed-20-years-stabbing-death-homeless-man-45-hailed-hero-pulling-dying-stranger-river.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:12:51+00:00

Brian Jewell, 20, stabbed Stephen Cook, 45, in the chest following an argument in Exeter, Devon. Mr Cook died from a single stab wound to his chest after a fight on Saturday 28 January.

## PCSO and her husband are jailed for three months after they pretended their Range Rover had been stolen so he could claim on the insurance
 - [https://www.dailymail.co.uk/news/article-12558817/PCSO-husband-Range-Rover-stolen-insurance-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558817/PCSO-husband-Range-Rover-stolen-insurance-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:02:11+00:00

Fiona, 33, and Darren, 37, Price have both been locked up after conning insurers to pay out. The mother of three was training in Leeds to become a Criminal Investigation Dept officer.

## How homes in Yorkshire's most northern village are 'going to ruin' as second home-owners snap up properties but 'never ever come and leave them empty for most of the year'
 - [https://www.dailymail.co.uk/news/article-12558703/How-homes-Yorkshires-northern-village-going-ruin-second-home-owners-snap-properties-never-come-leave-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558703/How-homes-Yorkshires-northern-village-going-ruin-second-home-owners-snap-properties-never-come-leave-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:01:52+00:00

Residents of Staithes have said that second-home owners have priced out people who have lived in the village for decade by converting the diminishing housing stock to holiday lets

## Why was Peter Sutcliffe known as the Yorkshire Ripper? The true meaning behind the chilling name
 - [https://www.dailymail.co.uk/news/article-12545701/yorkshire-ripper-meaning-peter-sutcliffe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12545701/yorkshire-ripper-meaning-peter-sutcliffe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T17:00:46+00:00

ITVX's new true crime docuseries, The Long Shadow, will give voice to the victims of one of Britain's most notorious serial killers, Peter Sutcliffe.

## Tourist, 25, 'climbed over wall of Buckingham Palace and began filming before being discovered hiding in a stable', court hears
 - [https://www.dailymail.co.uk/news/article-12558705/Tourist-25-climbed-wall-Buckingham-Palace-began-filming-discovered-hiding-stable-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558705/Tourist-25-climbed-wall-Buckingham-Palace-began-filming-discovered-hiding-stable-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:42:08+00:00

Awad Mustafa, 25, was on a 10-day trip to the UK when he was arrested after allegedly breaking into the King's official residence in the early hours of September 16.

## What about the $100K in gold bars, Bob? Senator Menendez insists he'll be EXONERATED on bribery charges, calls allegations 'salacious', defends ties to Egypt and claims cash stuffed in his jacket was from his SAVINGS
 - [https://www.dailymail.co.uk/news/article-12558533/Menendez-defends-bribery-corruption-cash-gold-bars-exonerated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558533/Menendez-defends-bribery-corruption-cash-gold-bars-exonerated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:32:01+00:00

Democratic Senator Bob Menendez says piles of cash found in his home during his bribery probe were withdrawn from his personal savings in an incredible press conference on Monday.

## Hollywood writers will now VOTE on whether to accept 'tentative' deal to end 146 day strike that has crippled Hollywood and the entertainment industry: Biden 'applauds' the decision
 - [https://www.dailymail.co.uk/news/article-12558605/writers-strike-2023-vote-steps-Biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558605/writers-strike-2023-vote-steps-Biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:29:39+00:00

Hollywood writers will now vote on whether to accept the 'tentative' deal to end the 146-day strike that has crippled Hollywood and the entertainment industry - as Biden showed his support for the agreement.

## Met Police says it has received 'a number of allegations of sexual assault in London and across the country' in wake of Channel 4's Dispatches investigation into Russell Brand
 - [https://www.dailymail.co.uk/news/article-12558689/Met-Police-says-received-number-allegations-sexual-assault-London-country-wake-Channel-4s-Dispatches-investigation-Russell-Brand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558689/Met-Police-says-received-number-allegations-sexual-assault-London-country-wake-Channel-4s-Dispatches-investigation-Russell-Brand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:27:03+00:00

Detectives at the Met Police have officially launched an investigation into Russell Brand after receiving a number of allegations of sexual offences from across the UK.

## Russell Brand releases new video on Rumble after revealing in his last social media post how he had suffered an 'extraordinary and distressing week' in wake of rape, sexual assault and emotional abuse allegations
 - [https://www.dailymail.co.uk/news/article-12558529/Russell-Brand-releases-new-video-Rumble-revealing-social-media-post-suffered-extraordinary-distressing-week-wake-rape-sexual-assault-emotional-abuse-allegations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558529/Russell-Brand-releases-new-video-Rumble-revealing-social-media-post-suffered-extraordinary-distressing-week-wake-rape-sexual-assault-emotional-abuse-allegations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:25:25+00:00

Russell Brand this evening returned to his Rumble show, posting a new near-hour long video on the web-based platform.

## Double amputee migrant is ferried across the Rio Grande in an inflatable donut in harrowing image laying bare the border crisis as up to 11,000 enter the US each day
 - [https://www.dailymail.co.uk/news/article-12558295/Rio-Grande-crossings-eagle-pass.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558295/Rio-Grande-crossings-eagle-pass.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:22:56+00:00

A double amputee migrant was seen being carried across the Rio Grande in an inflatable donut.

## Family of tragic 19-year-old who was banned from speaking about end-of-life battle with doctors who wanted to withdraw life-preserving treatment  reveal their heartbreak that she passed away just days before court order was lifted
 - [https://www.dailymail.co.uk/news/article-12558697/Family-tragic-19-year-old-banned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558697/Family-tragic-19-year-old-banned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:16:32+00:00

Sudiksha Thirumalesh, 19, who suffered from a rare degenerative disease, died of a cardiac arrest as she fought an NHS Trust's attempts to withdraw her life-preserving treatment.

## How Wilma McCann and Emily Jackson were the first two women to be murdered by the Yorkshire Ripper… as ITV drama The Long Shadow depicts their final moments
 - [https://www.dailymail.co.uk/news/article-12557707/Wilma-McCann-Emily-Jackson-Yorkshire-Ripper-ITV-Long-Shadow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557707/Wilma-McCann-Emily-Jackson-Yorkshire-Ripper-ITV-Long-Shadow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:16:14+00:00

Wilma McCann (above, portrayed by Gemma Laurie), 28, and Emily Jackson, 42 were the first two victims of Peter Sutcliffe, the monster who became known as the Yorkshire Ripper.

## Horrifying moment rat scurries onto table and starts eating leftovers at riverside pub
 - [https://www.dailymail.co.uk/news/article-12558455/Horrifying-rat-table-leftovers-pub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558455/Horrifying-rat-table-leftovers-pub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:12:17+00:00

Mark Baker, who filmed the video, was at the Mill on the Exe two weeks ago when he saw a rat eating from a plate at one of the pub's outdoor tables.

## Nineties pop star Finley Quaye is hit with 12 month supervision order for smashing up ex-girlfriend's cafe
 - [https://www.dailymail.co.uk/news/article-12558119/Nineties-pop-star-Finley-Quaye-hit-12-month-supervision-order-smashing-ex-girlfriends-cafe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558119/Nineties-pop-star-Finley-Quaye-hit-12-month-supervision-order-smashing-ex-girlfriends-cafe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:11:15+00:00

Quaye broke open the front door of ex-lover Rena Gawa's business in Edinburgh and threw chairs and flowers before breaking a number of glasses.

## Fury as Republican Rep. Paul Gosar calls for Joint Chiefs Chairman Mark Milley to be 'HUNG' because he is a 'traitor' and 'sodomy-promoting'
 - [https://www.dailymail.co.uk/news/article-12558209/Fury-Republican-Rep-Paul-Gosar-calls-Joint-Chiefs-Chairman-Mark-Milley-HUNG-traitor-sodomy-promoting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558209/Fury-Republican-Rep-Paul-Gosar-calls-Joint-Chiefs-Chairman-Mark-Milley-HUNG-traitor-sodomy-promoting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:10:27+00:00

Arizona Rep. Paul Gosar said in a 'better society' people like retiring Gen. Milley would be 'hung.' He accused Milley in his official newsletter of coordinating to delay the response to Jan. 6.

## How anti-mafia cops finally snared 'The Devil': Inside 30-year manhunt for Sicilian Godfather Matteo Messina Denaro which ended when cops swooped on his cancer clinic eight months before his death
 - [https://www.dailymail.co.uk/news/article-12558239/How-anti-mafia-cops-finally-snared-Devil-Inside-30-year-manhunt-Sicilian-Godfather-Matteo-Messina-Denaro-ended-cops-swooped-cancer-clinic-eight-months-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558239/How-anti-mafia-cops-finally-snared-Devil-Inside-30-year-manhunt-Sicilian-Godfather-Matteo-Messina-Denaro-ended-cops-swooped-cancer-clinic-eight-months-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:08:51+00:00

Reputed by investigators to be one of the Italian Mafia's most powerful bosses, Denaro vanished in the summer of 1993 and spent the next 30 years on the run, wanted for numerous, heinous crimes.

## American husband is arrested for 'beheading his father-in-law' in Indonesia after their joint business venture began to fail
 - [https://www.dailymail.co.uk/news/article-12558393/American-husband-arrested-beheading-father-law-Indonesia-joint-business-venture-began-fail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558393/American-husband-arrested-beheading-father-law-Indonesia-joint-business-venture-began-fail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:04:57+00:00

Arthur Leigh Welohr, 35, had been running a business with his Indonesian wife's dad Agus Sopiyan, 58, but their relationship allegedly soured as the venture began to fail.

## Who was the Yorkshire Ripper and how did Peter Sutcliffe die?
 - [https://www.dailymail.co.uk/news/article-12536127/who-yorkshire-ripped-peter-sutcliffe-die.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12536127/who-yorkshire-ripped-peter-sutcliffe-die.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:00:46+00:00

ITVX's new true crime documentary will delve into the horrific crimes of one of Britain's most notorious serial killer's, Peter Sutcliffe.

## Mother Nature puts on a show: Dazzling moment lightning strikes an erupting volcano sending bolts streaking across the night sky
 - [https://www.dailymail.co.uk/news/article-12558437/Mother-Nature-puts-Dazzling-moment-lightning-strikes-erupting-volcano-sending-bolts-streaking-night-sky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558437/Mother-Nature-puts-Dazzling-moment-lightning-strikes-erupting-volcano-sending-bolts-streaking-night-sky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T16:00:00+00:00

The incredible moment when a bolt of lightening struck an erupting volcano in Guatemala was caught on camera.

## Evangelical Christian family begs Biden administration to stop their deportation back to Germany where it's illegal to homeschool their kids - while MILLIONS pour across open US border
 - [https://www.dailymail.co.uk/news/article-12558131/Germany-family-home-school-aslyum-deportation-Uwe-Hannelore-Romeike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558131/Germany-family-home-school-aslyum-deportation-Uwe-Hannelore-Romeike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:57:12+00:00

Uwe and Hannelore Romeike fled Germany in 2008 after being threatened with prosecution for homeschooling their five children.

## Bruce Willis' wife Emma Heming fights back TEARS as she opens up about the actor's brutal struggle with dementia - admitting it's 'hard to know' if he's even aware of what's happening to him
 - [https://www.dailymail.co.uk/tvshowbiz/article-12557925/Bruce-Willis-Emma-Heming-update-health-brain-dementia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12557925/Bruce-Willis-Emma-Heming-update-health-brain-dementia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:38:15+00:00

Earlier this year, Bruce, 68, was diagnosed with frontotemporal dementia (FTD) - an uncommon type of the disease that causes a deterioration in behavior, personality and language.

## Moment screaming motorist bangs on female driver's windscreen he hurls vile abuse calling her a 's**g' in 'road rage' incident sparking massive traffic queue outside petrol station
 - [https://www.dailymail.co.uk/news/article-12558111/Moment-screaming-motorist-bangs-female-drivers-windscreen-hurls-vile-abuse-calling-s-g-road-rage-incident-sparking-massive-traffic-queue-outside-petrol-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558111/Moment-screaming-motorist-bangs-female-drivers-windscreen-hurls-vile-abuse-calling-s-g-road-rage-incident-sparking-massive-traffic-queue-outside-petrol-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:28:43+00:00

The video, filmed in Bournemouth on August 25, shows an extremely angry motorist snarl and shout at a woman in her car, calling her a 'F***ing s**g' and a 'F***ing bloody annoying woman'.

## Met Office storm names: How weather events get their titles - and what next season's tempests will be called
 - [https://www.dailymail.co.uk/news/article-12558125/Met-Office-storms-named.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558125/Met-Office-storms-named.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:28:29+00:00

Britain's first named storm of the season is expected to hit the UK this Wednesday, bringing up to 80mph winds which could cause disruption and damage.

## DEMOCRAT demands Biden get tough at the border as crossings surge: Texas Rep. calls for images showing migrants deported and more 'repercussions'
 - [https://www.dailymail.co.uk/news/article-12558421/DEMOCRAT-demands-Biden-tough-border-crossings-surge-Texas-Rep-calls-images-showing-migrants-deported-repercussions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558421/DEMOCRAT-demands-Biden-tough-border-crossings-surge-Texas-Rep-calls-images-showing-migrants-deported-repercussions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:27:01+00:00

Texas Democratic Rep. Henry Cuellar demanded 'repercussions' for illegal migrants on Sunday amid a fresh surge of border crossings.

## Tories face 'Blue Wall' threat as Lib Dems pocket £1MILLION bequest from activist's will - while Ed Davey woos voters by playing down EU ambitions and dropping plan to hike income tax
 - [https://www.dailymail.co.uk/news/article-12558423/Tories-face-Blue-Wall-threat-Lib-Dems-pocket-1MILLION-bequest-activists-Ed-Davey-woos-voters-playing-EU-ambitions-dropping-plan-hike-income-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558423/Tories-face-Blue-Wall-threat-Lib-Dems-pocket-1MILLION-bequest-activists-Ed-Davey-woos-voters-playing-EU-ambitions-dropping-plan-hike-income-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:25:46+00:00

Ed Davey's party was given the cash injection in the will of a wealthy activist - and pledged to use it to target Conservative heartlands.

## Migrant surge sparks spending spree as Chicago and NYC dish out eye-watering contracts: Windy city shelter nurse rakes in $20,000 in a WEEK
 - [https://www.dailymail.co.uk/news/article-12558109/Migrant-spending-Chicago-New-york.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558109/Migrant-spending-Chicago-New-york.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:25:08+00:00

As buses of asylum seekers keep arriving in New York City and Chicago, the two cities continue to hemorrhage money.

## Investigators looking at 'new persons of interest' in JonBenét Ramsey murder case after finishing up analyzing nearly 1,000 DNA samples and speaking to more than 1,000 people across 19 states
 - [https://www.dailymail.co.uk/news/article-12558279/JonBenet-Ramsey-suspect-DNA-test-colorado-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558279/JonBenet-Ramsey-suspect-DNA-test-colorado-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:24:00+00:00

Investigators are believed to be looking into new people of interest in the murder case of a six-year-old Colorado beauty pageant contestant after analyzing nearly 1,000 DNA samples.

## Which industries are hiring the most people? Here's a country-by-country breakdown
 - [https://www.dailymail.co.uk/news/article-12557941/industries-hiring-people-countries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557941/industries-hiring-people-countries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:22:01+00:00

An analysis conducted by Resume.io revealed which industries were hiring in each country. The US had the most vacancies in the restaurant industry. In the UK, the construction industry is hiring the most.

## 'World's oldest time capsule' - dating back to 1726 - is found in Polish church spire, containing 300-year-old coins, Latin documents and a lead bullet
 - [https://www.dailymail.co.uk/news/article-12558325/Worlds-oldest-time-capsule-dating-1726-Polish-church-spire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558325/Worlds-oldest-time-capsule-dating-1726-Polish-church-spire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:21:44+00:00

The capsule allegedly dates back to 1726 and contains documents, a bullet as well as 300-year-old coins. It was found at the Church of St. Stanislaus in the western  town of Wschowa.

## Real copycats! Rare Siberian Tiger twins play with their mom Talya days after she gave birth to them at Toledo Zoo
 - [https://www.dailymail.co.uk/news/article-12558327/Real-copycats-Rare-Siberian-Tiger-twins-play-mom-Talya-days-gave-birth-Toledo-Zoo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558327/Real-copycats-Rare-Siberian-Tiger-twins-play-mom-Talya-days-gave-birth-Toledo-Zoo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:16:37+00:00

An Ohio zoo is celebrating after twin tiger cubs were born in July weighing at a meaty 15 and 16 pounds respectively.

## What does a government shutdown mean for YOU? All your questions about who gets paid and which services will shut - with just FIVE DAYS for Congress to strike a deal
 - [https://www.dailymail.co.uk/news/article-12550413/Government-shutdown-affect-services-Congress.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12550413/Government-shutdown-affect-services-Congress.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:16:20+00:00

Despite the decision being in their hands, members of Congress will still get paid during a shutdown, as will federal judges and the president. Their staff, however, do not.

## Autistic boy with 'uncontrollable behaviour' is pinned down for seven minutes while in disability care funded by the NDIS
 - [https://www.dailymail.co.uk/news/article-12558173/Autistic-boy-pinned-NDIS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558173/Autistic-boy-pinned-NDIS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:14:28+00:00

A therapy funded by the National Disability Insurance Scheme has been exposed as being used to pin children with severe disabilities facedown to the ground.

## Alabama riverboat brawl deckhand says he was just 'trying to do his job' when crew of four jumped him
 - [https://www.dailymail.co.uk/news/article-12557981/Alabama-riverboat-brawl-deckhand-says-just-trying-job-crew-four-jumped-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557981/Alabama-riverboat-brawl-deckhand-says-just-trying-job-crew-four-jumped-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:08:08+00:00

Dameion Pickett, 43, was attacked on August 5th while trying to dock Harriott II, a riverboat in Montgomery, Alabama.

## Joe Biden is bankrolling Ukraine's 57,000 first responders - and even funding fashion stores, schools and farms - in $10bn aid package
 - [https://www.dailymail.co.uk/news/article-12558067/US-Ukraine-aid-farmers-businesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558067/US-Ukraine-aid-farmers-businesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:02:51+00:00

The US has given Ukraine close to $100 billion in aid since it was invaded by Russia in February 2022 - but the money has not only been used to fund its military.

## Britain's oldest casino set up in the heart of Mayfair in 1828 by a working-class fishmonger who went on to become one of Britain's richest men may close for good as it fails to attract wealthy tourists
 - [https://www.dailymail.co.uk/news/article-12558299/britains-oldest-casino-mayfair-close.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558299/britains-oldest-casino-mayfair-close.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T15:02:38+00:00

Crockfords Casino - best known for its exclusive clientele of aristocracy and royalty - has kicked off a 30-day consultation process with its staff as it decides on the future of its £80m site.

## Tapping, Perth crash: Six-year-old boy orphaned after both his parents are killed in horror motorcycle smash
 - [https://www.dailymail.co.uk/news/article-12558355/Tapping-Perth-crash-Six-year-old-boy-orphaned-parents-killed-horror-motorcycle-smash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558355/Tapping-Perth-crash-Six-year-old-boy-orphaned-parents-killed-horror-motorcycle-smash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:57:49+00:00

Lynette Reader, 35, and Paul Pearce, 39, both died after the motorcycle they were riding on collided with a Toyota Aurion in the Perth suburb of Tapping on Sunday night.

## Serving police officer, 46, 'revelled in behaving like an animal' as he repeatedly raped and sexually assaulted a female friend, court hears
 - [https://www.dailymail.co.uk/news/article-12558389/Serving-police-officer-46-revelled-behaving-like-animal-repeatedly-raped-sexually-assaulted-female-friend-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558389/Serving-police-officer-46-revelled-behaving-like-animal-repeatedly-raped-sexually-assaulted-female-friend-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:53:48+00:00

A police officer 'revelled in behaving like an animal' as he repeatedly raped and sexually assaulted a female friend, court heard today.

## Man, 33, denies murdering millionaire shower mat tycoon couple found dead with synthetic opioid fentanyl in their bodies
 - [https://www.dailymail.co.uk/news/article-12558319/Man-denies-murdering-millionaire-shower-tycoon-couple-opioid-fentanyl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558319/Man-denies-murdering-millionaire-shower-tycoon-couple-opioid-fentanyl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:47:59+00:00

Luke D'Wit, 33, has pleaded not guilty after being charged with the murders of Stephen, 61, and Carol Baxter, 64, (pictured) at their home in West Mersea, Essex, on Easter Sunday.

## Kate Middleton has been 'hurt and insulted' by Harry and Meghan and she and Prince William have 'closed their minds' to mending family rift, royal expert claims
 - [https://www.dailymail.co.uk/femail/article-12557209/Kate-Middleton-hurt-insulted-Harry-Meghan-Prince-William-closed-minds-mending-family-rift-royal-expert-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12557209/Kate-Middleton-hurt-insulted-Harry-Meghan-Prince-William-closed-minds-mending-family-rift-royal-expert-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:47:17+00:00

Jennie Bond, the former BBC royal correspondent, told OK! that Kate Middleton and Prince William had attempted to heal the rift within the Royal Family in 2021.

## How WFH is making you fatter: Brits consume nearly 800 extra calories when hybrid working and take 3,500 fewer steps, survey finds
 - [https://www.dailymail.co.uk/health/article-12557577/How-WFH-making-fatter-Brits-consume-nearly-800-extra-calories-hybrid-working-3-500-fewer-steps-survey-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-12557577/How-WFH-making-fatter-Brits-consume-nearly-800-extra-calories-hybrid-working-3-500-fewer-steps-survey-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:47:00+00:00

Sixty per cent of UK respondents admitted they are unhealthier in their own homes. Many cited having fewer temptations as the main reason they are healthier on days when they are in the office.

## Kidney transplant: Adelaide parents' incredible sacrifice for their desperately ill daughters
 - [https://www.dailymail.co.uk/news/article-12558127/Kidney-transplant-Adelaide-parents-donors-daughters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558127/Kidney-transplant-Adelaide-parents-donors-daughters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:42:31+00:00

Two parents are set to donate their kidneys to their daughters in a remarkable act of sacrifice.

## Small village is left in disarray after explosive row erupts between councillors over who controls the parish website - sparking mass resignations, more than £100,000 of community funds on hold and a police probe
 - [https://www.dailymail.co.uk/news/article-12558189/Small-village-left-disarray-explosive-row-erupts-councillors-controls-parish-website-sparking-mass-resignations-100-000-community-funds-hold-police-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558189/Small-village-left-disarray-explosive-row-erupts-councillors-controls-parish-website-sparking-mass-resignations-100-000-community-funds-hold-police-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:16:12+00:00

The extraordinary dispute in idyllic Spooner Row in Norfolk has triggered mass resignations by councillors, a bitter leaflet campaign, and even a police investigation.

## Mother of autistic boy, 13, who died after falling from a cliff during the first lockdown when his school had closed slams the government for 'refuting' coroner's report into his death
 - [https://www.dailymail.co.uk/news/article-12558013/mother-autistic-boy-died-lockdown-slams-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558013/mother-autistic-boy-died-lockdown-slams-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:16:08+00:00

Patricia Alban's son Sammy Alban-Stanley (pictured), 13, fell after climbing over the railings on a cliff at Ramsgate, Kent in April 2020, at the start of the Covid-19 pandemic.

## Girlfriend of Aussie bloke caught stealing Viagra from a humble Bali shop reveals why he REALLY needed the erectile dysfunction drug... and what she thought of his wild trip
 - [https://www.dailymail.co.uk/news/article-12556769/Girlfriend-Aussie-bloke-caught-stealing-Viagra-humble-Bali-shop-reveals-REALLY-needed-erectile-dysfunction-drug-thought-wild-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556769/Girlfriend-Aussie-bloke-caught-stealing-Viagra-humble-Bali-shop-reveals-REALLY-needed-erectile-dysfunction-drug-thought-wild-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:14:58+00:00

The girlfriend of an Australian man caught stealing viagra from an unsuspecting pharmacist in Bali has jumped to the defense of men using erectile enhancing stimulants.

## Ex-CIA officer Brian Raymond accused of drugging and sexually assaulting 25 women hires celebrity memory experts who testified for Harvey Weinstein, Ghislaine Maxwell and Bill Cosby for defense
 - [https://www.dailymail.co.uk/news/article-12557903/Celebrity-expert-CIA-rape-trial-Brian-Raymond-alcohol-memory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557903/Celebrity-expert-CIA-rape-trial-Brian-Raymond-alcohol-memory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T14:09:18+00:00

A former CIA officer who is accused of drugging and sexually assaulting 25 women has hired celebrity memory experts who testified for Harvey Weinstein , Ghislaine Maxwell and Bill Cosby .

## Shirtless man wanted for assault with a deadly weapon leads Los Angeles police on a chase in a GOLF CART with a dog in his lap before he's pulled over and arrested
 - [https://www.dailymail.co.uk/news/article-12557963/los-angeles-man-police-chase-golf-cart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557963/los-angeles-man-police-chase-golf-cart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:58:29+00:00

The shirtless and shoeless LA man reportedly stole the golf cart at knife point before leading police on an ambling chase, avoiding spike strips and multiple officers, all while carrying a dog on his lap.

## Aimee Marsh: Real estate agent sacked for mocking struggling renters and boasting she pays 'twice their wages in tax' cruises into a new job - and says she's 'an inspiration'
 - [https://www.dailymail.co.uk/news/article-12557801/Real-estate-agent-sacked-mocking-renters-new-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557801/Real-estate-agent-sacked-mocking-renters-new-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:45:56+00:00

Aimee Marsh, 30, was fired from Ray White Aspley, near Griffin in Brisbane 's north, after she mocked tenants in a local Facebook group - using her professional profile.

## Meghan Markle cheers and glances around VIP box as Beyoncé shouts out her Destiny's Child co-stars in unseen concert clip
 - [https://www.dailymail.co.uk/femail/article-12557443/Meghan-Markle-cheers-glances-VIP-box-Beyonc-shouts-Destinys-Child-stars-unseen-concert-clip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12557443/Meghan-Markle-cheers-glances-VIP-box-Beyonc-shouts-Destinys-Child-stars-unseen-concert-clip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:34:39+00:00

Meghan Markle, 41, can be seen cheering and glancing around her VIP box while attending a Beyoncé concert alongside Tyler Perry in Los Angeles in a previously unseen clip.

## 'World's oldest living woman' celebrates her 117th birthday with her 107-year-old sister in Brazil
 - [https://www.dailymail.co.uk/news/article-12557949/Worlds-oldest-living-woman-celebrates-117th-birthday-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557949/Worlds-oldest-living-woman-celebrates-117th-birthday-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:33:12+00:00

Cicera Maria dos Santos (pictured) was reportedly born in 1906, making her 117. If her date of birth is confirmed, it would make her one year older than the current Guiness World Record holder.

## Heartbroken father of murdered clubber Melanie Hall reveals how he 'wished he didn't wake up in the morning' following her 1996 disappearance - as new documentary explores the cold case with killer still at large
 - [https://www.dailymail.co.uk/news/article-12557823/murdered-Melanie-Hall-father-1996-documentary-cold-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557823/murdered-Melanie-Hall-father-1996-documentary-cold-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:32:04+00:00

The 25-year-old, who was a clerical worker at the Royal United Hospital in Bath, was last seen on Sunday 9 June, 1996, at Cadillacs nightclub in Bath city centre at about 1.45am.

## Teenager, 18, died after his moped collided with a taxi in central London while he and passenger were being chased by police after running a red light
 - [https://www.dailymail.co.uk/news/article-12558035/Teenager-18-died-moped-collided-taxi-central-London-passenger-chased-police-running-red-light.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558035/Teenager-18-died-moped-collided-taxi-central-London-passenger-chased-police-running-red-light.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:19:04+00:00

A teenager has been killed after crashing his moped during a pursuit by police who saw him run a red light.

## Democrat Rep. says he IS considering a run against Biden after disastrous poll had him 10 points behind Trump
 - [https://www.dailymail.co.uk/news/article-12557907/Democrat-Rep-says-considering-run-against-Biden-disastrous-poll-10-points-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557907/Democrat-Rep-says-considering-run-against-Biden-disastrous-poll-10-points-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:12:57+00:00

Democratic Rep. Dean Phillips is 'thinking' about launching a primary challenge against Joe Biden, 80 - following a disastrous poll that had the President 10 points behind Donald Trump.

## Met Police tells Army to stand down in firearms revolt: Force says enough armed officers have returned to duty that they now don't need military help - after the SAS were put on standby following mass walkout over colleague's murder charge
 - [https://www.dailymail.co.uk/news/article-12558021/Police-wont-need-Army-amid-firearms-revolt-Chris-Kaba-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12558021/Police-wont-need-Army-amid-firearms-revolt-Chris-Kaba-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:11:33+00:00

Members of the SAS and regular soldiers had been poised to fill in on the capital's streets for the first time in over a century following a revolt by armed police within Scotland Yard.

## Is America about to send special forces into Mexico? Growing calls for US military to tackle migrant crisis and cartels amid chaos at border
 - [https://www.dailymail.co.uk/news/article-12557325/America-special-forces-Mexico-border-cartels.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557325/America-special-forces-Mexico-border-cartels.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:10:47+00:00

Migrants from across the world continue to flood into the US through its southern border creating more headaches for the Biden administration.

## Felicidades! Count of Osorno, the grandson of Spain's richest woman, is expecting his first child with his real estate heiress wife Belén Corsini
 - [https://www.dailymail.co.uk/femail/article-12557699/Felicidades-Count-Osorno-grandson-Spains-richest-woman-expecting-child-real-estate-heiress-wife-Bel-n-Corsini.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12557699/Felicidades-Count-Osorno-grandson-Spains-richest-woman-expecting-child-real-estate-heiress-wife-Bel-n-Corsini.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:08:22+00:00

The Count of Osorno is expecting his first child with his real estate heiress wife Belén Corsini. The couple come from two of Spain's wealthiest families.

## 'Crooked' Bob Menendez set to announce re-election bid TODAY as Democrats demand he resign over gold bar bribery charges - which he claims are part of a racist witch hunt
 - [https://www.dailymail.co.uk/news/article-12557911/Crooked-Bob-Menendez-election-bid-Democrats-resign-bribery-gold-bars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557911/Crooked-Bob-Menendez-election-bid-Democrats-resign-bribery-gold-bars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:06:11+00:00

Senator Bob Menendez is set to announce his re-election bid on Monday, doubling down as fellow Democrats are calling on him to resign after charges he accepted gold bars as bribes from businessman.

## Thousands of students face disruption as university staff begin five-day freshers' week strike
 - [https://www.dailymail.co.uk/news/article-12557767/Students-disruption-university-staff-freshers-week-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557767/Students-disruption-university-staff-freshers-week-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:05:55+00:00

Staff will walk out for five consecutive days at 42 universities and for at least one day at a further 10. It is part of a long-running dispute over pay and working conditions.

## Nightclub boss is jailed for four years for paying bribes to corrupt Met Police officer 'Sheriff of Soho' who turned a blind eye to crime by accepting free holidays, nights with call girls and whipping sessions with a dominatrix
 - [https://www.dailymail.co.uk/news/article-12557755/Nightclub-boss-jailed-four-years-paying-bribes-corrupt-Met-Police-officer-Sheriff-Soho-turned-blind-eye-crime-accepting-free-holidays-nights-call-girls-whipping-sessions-dominatrix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557755/Nightclub-boss-jailed-four-years-paying-bribes-corrupt-Met-Police-officer-Sheriff-Soho-turned-blind-eye-crime-accepting-free-holidays-nights-call-girls-whipping-sessions-dominatrix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T13:02:56+00:00

Entrepreneur Ryan Bishti provided bent cop Frank Partridge with hotel stays, fine dining, nights with call girls and even whipping sessions with a dominatrix describing the police officer as 'his ace.'

## 'Big win for you...we're all behind you': Derby County players dedicate 2-0 victory over Carlisle to goalkeeper Josh Vickers after he revealed his wife died of cancer three months after their wedding day
 - [https://www.dailymail.co.uk/news/article-12557967/Big-win-Derby-County-players-dedicate-2-0-victory-Carlisle-goalkeeper-Josh-Vickers-revealed-wife-died-cancer-three-months-wedding-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557967/Big-win-Derby-County-players-dedicate-2-0-victory-Carlisle-goalkeeper-Josh-Vickers-revealed-wife-died-cancer-three-months-wedding-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:55:23+00:00

Derby County stars dedicated their win at the weekend to Josh Vickers after the grieving goalkeeper revealed his wife died of cancer three months after their wedding.

## Marcus Rashford arrives at Man United training in his spare £600,000 Rolls-Royce after crashing his other one into car being driven by a 74-year-old grandmother after winning at Burnley on Saturday night
 - [https://www.dailymail.co.uk/sport/football/article-12557899/Marcus-Rashford-arrives-Man-United-training-spare-600-000-Rolls-Royce-crashing-one-car-driven-74-year-old-grandmother-winning-Burnley-Saturday-night.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-12557899/Marcus-Rashford-arrives-Man-United-training-spare-600-000-Rolls-Royce-crashing-one-car-driven-74-year-old-grandmother-winning-Burnley-Saturday-night.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:51:43+00:00

The England forward damaged his £700,000 Rolls-Royce after the collision with a 74-year-old grandmother's vehicle following United's win at Burnley.

## Adam Britton: NT zoologist raped dozens of puppies and tortured 39 dogs to death before telling owners their pets were 'settling in well' at his shelter
 - [https://www.dailymail.co.uk/news/article-12557821/Adam-Britton-NT-zoologist-raped-dozens-puppies-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557821/Adam-Britton-NT-zoologist-raped-dozens-puppies-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:33:43+00:00

Adam Robert Corden Britton, 51, began his offending in 2014 torturing and sexually exploiting more than 42 dogs until his arrest in April 2022.

## 'Our silent thoughts are nobody's business': Catholic woman who was twice arrested for silently praying near abortion clinic says she fears police are becoming 'ideologically driven' - as she vows to carry on doing it on a weekly basis
 - [https://www.dailymail.co.uk/news/article-12557713/Our-silent-thoughts-nobodys-business-Catholic-woman-twice-arrested-silently-praying-near-abortion-clinic-says-fears-police-ideologically-driven-vows-carry-doing-weekly-basis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557713/Our-silent-thoughts-nobodys-business-Catholic-woman-twice-arrested-silently-praying-near-abortion-clinic-says-fears-police-ideologically-driven-vows-carry-doing-weekly-basis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:31:33+00:00

Isabel Vaughan-Spruce, who is the director of anti-abortion group March for Life UK, said she is 'appalled' her situation took so long to end - and will not be deterred.

## Horrifying moment woman gets hair caught in Ferris wheel leaving her trapped and in agony 25ft up at Indian amusement park
 - [https://www.dailymail.co.uk/news/article-12557595/Horrifying-moment-woman-gets-hair-caught-Ferris-wheel-leaving-trapped-agony-25ft-Indian-amusement-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557595/Horrifying-moment-woman-gets-hair-caught-Ferris-wheel-leaving-trapped-agony-25ft-Indian-amusement-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:27:31+00:00

Video shows a group of men balancing on the ride's metal frame and frantically trying to free the woman's locks from the Ferris wheel in the northern Indian town of Dwarka.

## Fears Sheffield could be next council to go 'bust' as it faces massive equal pay claim over 'truly scandalous' underpayment of female-dominated roles
 - [https://www.dailymail.co.uk/news/article-12557921/Fears-Sheffield-council-bust-faces-massive-equal-pay-claim-truly-scandalous-underpayment-female-dominated-roles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557921/Fears-Sheffield-council-bust-faces-massive-equal-pay-claim-truly-scandalous-underpayment-female-dominated-roles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:26:44+00:00

The GMB union launched a claim against the council today as it alleged some female workers have been underpaid by up to £11,000 a year.

## Who Killed Jill Dando? The main theories behind Britain's biggest unsolved murder
 - [https://www.dailymail.co.uk/news/article-12557429/who-killed-jill-dando-main-theories-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557429/who-killed-jill-dando-main-theories-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:17:21+00:00

Netflix's upcoming documentary 'Who Killed Jill Dando' has sparked speculation about her death. Here, MailOnline explores the main theories behind the death of TV's 'golden girl', Jill Dando.

## Moment rats scurry outside infested block of flats as 'petrified' tenants claim they can't leave their homes when it gets dark
 - [https://www.dailymail.co.uk/news/article-12557623/Moment-rats-scurry-infested-flats-petrified-tenants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557623/Moment-rats-scurry-infested-flats-petrified-tenants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:14:10+00:00

Tenants Eve Bradley and Eireann Dobbins say they can't go outside in the dark without rats running over their feet. The pair moved into the flat, on Vine Street, Liverpool city centre, five months ago.

## Melanie Sykes claims she 'cried all night' after Keith Lemon humiliated her in front of a live audience - before being told she was the 'first person to ever complain about him' by production company boss
 - [https://www.dailymail.co.uk/news/article-12557353/melanie-sykes-cried-keith-lemon-humiliated-live-audience-complaint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557353/melanie-sykes-cried-keith-lemon-humiliated-live-audience-complaint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:13:42+00:00

Melanie Sykes also said the TV production company Talkback, founded by the comedy duo Mel Smith and Griff Rhys Jones, ignored her when she complained.

## Huge piles of rubbish are overflowing on the streets of east London as council workers go on two week-long bin strike
 - [https://www.dailymail.co.uk/news/article-12557649/London-council-bin-strike-rubbish-piles-streets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557649/London-council-bin-strike-rubbish-piles-streets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:13:12+00:00

Photos show mounds of uncollected black bin bags, cardboard boxes, and empty black plastic crates discarded by market stall holders in Whitechapel Road, Tower Hamlets.

## How much has HS2 cost so far and what are the consequences of scrapping it?
 - [https://www.dailymail.co.uk/news/article-12557193/HS2-cost-scrapping-consequences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557193/HS2-cost-scrapping-consequences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:13:03+00:00

Rishi Sunak is reportedly considering scrapping plans for HS2 high speed rail link extension from Birmingham to Manchester, due to soaring costs.

## Police say death of Sheffield United star Maddy Cusack is not being treated as suspicious after her body was found at a house - as 'devastated' players and fans pay tribute to 27-year-old vice captain
 - [https://www.dailymail.co.uk/news/article-12557837/Police-say-death-Sheffield-United-star-Maddy-Cusack-not-treated-suspicious-body-house-devastated-players-fans-pay-tribute-27-year-old-vice-captain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557837/Police-say-death-Sheffield-United-star-Maddy-Cusack-not-treated-suspicious-body-house-devastated-players-fans-pay-tribute-27-year-old-vice-captain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:12:18+00:00

Police say the sudden death of Sheffield United star Maddy Cusack is not being treated as suspicious.

## Who was Wearside Jack John Humble and what happened to the Yorkshire Ripper's imposter?
 - [https://www.dailymail.co.uk/news/article-12545645/Who-Wearside-Jack-John-Humble-happened-Yorkshire-Rippers-imposter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12545645/Who-Wearside-Jack-John-Humble-happened-Yorkshire-Rippers-imposter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T12:00:46+00:00

ITVX's new true crime series, The Long Shadow, delves into the five-year manhunt for one of Britain's most notorious serial killers which was derailed for two years by a hoax confession.

## Air traffic control chaos hits Gatwick for FOURTH time in a month... and this time they've blamed Covid: More than sixty flights are cancelled and 8,000 passengers face delays as bosses say staff sickness in control tower reduced runway 'flow rate'
 - [https://www.dailymail.co.uk/news/article-12557675/air-traffic-control-chaos-gatwick-covid-staff-sicknesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557675/air-traffic-control-chaos-gatwick-covid-staff-sicknesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:57:42+00:00

Some 8,000 passengers were said to have been left out of position after a total of 64 flights arriving or leaving London Gatwick Airport were cancelled today and yesterday.

## Eco-activist who stormed Lord's cricket ground and was carried off by Jonny Bairstow leads Just Stop Oil's new drive to recruit 500 students to get themselves arrested during protests
 - [https://www.dailymail.co.uk/news/article-12557751/Eco-activist-stormed-Lords-cricket-ground-carried-Jonny-Bairstow-leads-Just-Stop-Oils-new-drive-recruit-500-students-arrested-protests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557751/Eco-activist-stormed-Lords-cricket-ground-carried-Jonny-Bairstow-leads-Just-Stop-Oils-new-drive-recruit-500-students-arrested-protests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:52:05+00:00

Daniel Knorr, 21, a notorious eco-activist who stormed Lord's cricket ground is leading Just Stop Oil's new student recruitment drive.

## Italian diners leave scathing review after ice cream parlour charges them €1 for an extra SPOON to share their dessert in latest row over 'rip off' restaurants in the country
 - [https://www.dailymail.co.uk/news/article-12557419/Italian-diners-leave-scathing-review-ice-cream-parlour-charges-1-extra-SPOON.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557419/Italian-diners-leave-scathing-review-ice-cream-parlour-charges-1-extra-SPOON.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:43:22+00:00

A customer said she asked for a second spoon to share her tub of ice cream with her husband at the Gelateria Serafini in the town of Lavis in northern Italy.

## Kate Middleton is spotted looking sporty as she watches Prince George play football
 - [https://www.dailymail.co.uk/femail/article-12557469/Kate-Middleton-spotted-looking-sporty-watches-Prince-George-play-football.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12557469/Kate-Middleton-spotted-looking-sporty-watches-Prince-George-play-football.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:40:31+00:00

In a snap which was shared on social media, the Princess of Wales, 41, beamed with joy as she watched her eldest son play in a match alongside her husband Prince William, 41.

## Dog killed with bolt gun 'by mistake' in a horror mix-up by New Zealand council - as family left 'heartbroken and shocked'
 - [https://www.dailymail.co.uk/news/article-12557379/Dog-killed-mistake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557379/Dog-killed-mistake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:39:46+00:00

A couple has been left 'heartbroken and in shock' after their beloved dog Sarge was taken in and killed by mistake by a local council, despite being microchipped.

## Rare pair of theatre tickets that gave 'harrowing' front row view of Abraham Lincoln's assassination sell at auction for $262,500
 - [https://www.dailymail.co.uk/news/article-12557651/Rare-pair-theatre-tickets-gave-harrowing-row-view-Abraham-Lincolns-assassination-sell-262-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557651/Rare-pair-theatre-tickets-gave-harrowing-row-view-Abraham-Lincolns-assassination-sell-262-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:30:34+00:00

An extremely rare pair of theatre tickets which provided a 'harrowing' front row view of Abraham Lincoln's assassination have sold for a staggering $262,500.

## Germany's 'bleak' economy is now 'treading water' with key business confidence barometer sliding for the fifth time in a row - days after country's production fell for third straight month
 - [https://www.dailymail.co.uk/news/article-12557613/Germanys-bleak-economy-treading-water.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557613/Germanys-bleak-economy-treading-water.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:30:22+00:00

While business sentiment in Germany fell less than expected in September, a key survey on Monday showed a fifth consecutive decline in the metric - down to 85.7 points from 85.8 the previous month.

## Horrifying moment thrill-seekers are stuck upside down for half an hour when Wonderland's lumberjack ride malfunctions
 - [https://www.dailymail.co.uk/news/article-12557607/Horrifying-moment-thrill-seekers-stuck-upside-half-hour-Wonderlands-lumberjack-ride-malfunctions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557607/Horrifying-moment-thrill-seekers-stuck-upside-half-hour-Wonderlands-lumberjack-ride-malfunctions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:13:54+00:00

The Lumberjack, a swinging axe ride located at the thrill-packed amusement haven in Vaughn, Ontario, suddenly ground to a halt in a terrifying blunder at around 10:30pm on Saturday

## Drone pilot watches in disbelief as person shoots his device out of the sky when it accidentally strayed into a no-fly zone - as police probe 'criminal damage' in first UK case of its kind
 - [https://www.dailymail.co.uk/news/article-12557597/drone-pilot-disbelief-device-shot-no-fly-zone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557597/drone-pilot-disbelief-device-shot-no-fly-zone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:12:04+00:00

The incident happened when the drone was being inadvertently flown illegally in a no-fly zone close to Walney Aerodrome, in Barrow-in-Furness, Cumbria, where drones are banned.

## Brain cancer: 'Perfectly healthy' Evie Poolman woke up one day with a bizarre symptom after doctors told her parents there was nothing to worry about… then the nine-year-old was dealt a devastating diagnosis and died six months later
 - [https://www.dailymail.co.uk/news/article-12557381/Evie-Poolman-brain-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557381/Evie-Poolman-brain-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:08:46+00:00

The parents of a nine-year-old girl who tragically died from the deadliest form of brain cancer are campaigning for more research into the disease.

## How many people are killed by alligators in the US each year and how can you avoid an attack?
 - [https://www.dailymail.co.uk/news/article-12557333/How-people-killed-alligators-year-avoid-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557333/How-people-killed-alligators-year-avoid-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:08:42+00:00

The death of homeless Florida woman Sabrina Peckham is the latest in a string of alligator attacks across the US this year. How often are attacks fatal? And how can you avoid being victim of one?

## Army chiefs refuse to back down after coroner warned them to stop giving ceremonial daggers to retiring soldiers in wake of double-murder - with MoD saying more knives are sold on Amazon
 - [https://www.dailymail.co.uk/news/article-12557367/Army-coroner-ceremonial-daggers-soldiers-murder-MoD-knives-Amazon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557367/Army-coroner-ceremonial-daggers-soldiers-murder-MoD-knives-Amazon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:07:01+00:00

The MoD has ignored a coroner's warning to stop giving retiring soldiers ceremonial daggers following a double murder, saying that more knives are sold on Amazon.

## Inside Pete Doherty party which ended in 'murder' of Cambridge graduate 'thrown off a first-floor balcony': Guest recalls 'sinister' atmosphere as she is adamant 'something horrid went on'
 - [https://www.dailymail.co.uk/news/article-12554563/inside-pete-doherty-party-murder-cambridge-graduate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12554563/inside-pete-doherty-party-murder-cambridge-graduate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:04:43+00:00

A guest at a party attended by Pete Doherty where a man died says there was a 'sinister' atmosphere and believes 'something horrid went on'.

## Furious builder puts giant stone gargoyle sculpt of a council leader on his roof amid bitter row over his rejected plan to convert pizza takeaway into seven-bed house
 - [https://www.dailymail.co.uk/news/article-12557523/Builder-gargoyle-councillor-bitter-planning-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557523/Builder-gargoyle-councillor-bitter-planning-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T11:03:19+00:00

Michael Thomas, 71, erected the unusual statues after his plan to convert an old pizza takeaway was rejected. The targeted councilor said it was 'amusing'.

## Shocking moment lion suddenly flips and attacks a circus tamer as audience screams in China
 - [https://www.dailymail.co.uk/news/article-12557423/Shocking-moment-lion-suddenly-flips-attacks-circus-tamer-audience-screams-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557423/Shocking-moment-lion-suddenly-flips-attacks-circus-tamer-audience-screams-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:57:56+00:00

Shocking footage shows the dangerous stand-off between two lions and their tamer on a caged circus stage in Dongning City in northern China during a performance last week.

## Ukrainian troops 'break through Russian defences in key battleground' days after Kyiv 'used Brit-made Storm Shadow missiles' to strike Putin's Black Sea fleet headquarters
 - [https://www.dailymail.co.uk/news/article-12557267/Ukrainian-troops-break-Russian-defences-key-battleground-days-Kyiv-used-Brit-Storm-Shadow-missiles-strike-Putins-Black-Sea-fleet-headquarters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557267/Ukrainian-troops-break-Russian-defences-key-battleground-days-Kyiv-used-Brit-Storm-Shadow-missiles-strike-Putins-Black-Sea-fleet-headquarters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:52:44+00:00

Oleksandr Tarnavskiy told US media that the advance was still underway, in the latest indication that Ukraine is making in-roads on the southern front.

## Biden is trolled by dumbfounded observers after getting LL Cool J's name wrong and calling him 'boy' before correcting his mistake
 - [https://www.dailymail.co.uk/news/article-12557237/Biden-trolled-dumbfounded-observers-getting-LL-Cool-Js-wrong-calling-boy-correcting-mistake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557237/Biden-trolled-dumbfounded-observers-getting-LL-Cool-Js-wrong-calling-boy-correcting-mistake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:52:00+00:00

Footage of the blunder immediately drew a torrent of criticism on social media, with former Fox host Trish Regan slamming Biden for referring to LL Cool J as 'boy'

## Former Olympic rower James Cracknell chosen as Tory election candidate in Colchester
 - [https://www.dailymail.co.uk/news/article-12557491/Former-Olympic-rower-James-Cracknell-chosen-Tory-election-candidate-Colchester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557491/Former-Olympic-rower-James-Cracknell-chosen-Tory-election-candidate-Colchester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:21:20+00:00

The double gold medallist will be standing to replace outgoing MP Will Quince in the Essex city.

## Rishi Sunak refuses to rule out slashing inheritance tax in pre-election boost - but warns inflation MUST come down first
 - [https://www.dailymail.co.uk/news/article-12557343/Rishi-Sunak-refuses-rule-slashing-inheritance-tax-pre-election-boost-warns-inflation-come-first.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557343/Rishi-Sunak-refuses-rule-slashing-inheritance-tax-pre-election-boost-warns-inflation-come-first.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:15:09+00:00

Rishi Sunak insisted he would not comment on fevered speculation about a dramatic pledge to scrap inheritance tax.

## Father, 42, threatened to slit his wife and three children's throats after they confronted him about going on a 12-hour cocaine and drink binge when he said he was only popping out to buy cigarettes
 - [https://www.dailymail.co.uk/news/article-12557459/Father-42-threatened-slit-wife-three-childrens-throats-confronted-going-12-hour-cocaine-drink-binge-said-popping-buy-cigarettes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557459/Father-42-threatened-slit-wife-three-childrens-throats-confronted-going-12-hour-cocaine-drink-binge-said-popping-buy-cigarettes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:13:31+00:00

Lee Wright (pictured) took his wife Jodie and their three children aged, 13, 11 and 3 hostage at knifepoint and shouted 'I am going to kill you all' after he arrived home late in Weaste, Salford.

## The break-up of one of comedy's greatest double acts: Adrian Edmondson reveals how fame, alcohol and a quad bike accident changed Rik Mayall and contributed to the end of their famous partnership
 - [https://www.dailymail.co.uk/news/article-12557395/Adrian-Edmondson-reveals-split-comedy-partner-Rik-Mayall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557395/Adrian-Edmondson-reveals-split-comedy-partner-Rik-Mayall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:04:59+00:00

Adrian Edmondson shot to fame thanks to his work with Rik Mayall on TV's The Young Ones in the 80s and Bottom in the 90s, but decided by the end of their tour in 2003 that he did not want to carry on.

## I'm a nutrition expert - here are 5 foods you should avoid eating before bed if you want to get a good night's sleep
 - [https://www.dailymail.co.uk/femail/article-12554669/Im-nutrition-expert-5-foods-avoid-eating-bed-want-good-nights-sleep.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12554669/Im-nutrition-expert-5-foods-avoid-eating-bed-want-good-nights-sleep.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:04:28+00:00

British nutrition expert Cheryl Lythgoe, from Benenden Health, shared the  worst foods to consume at night if you're struggling to get a good night's sleep with the Huffington Post.

## Jill Dando's murder WAS a 'professional hit' but person responsible is 'not who you would think', ex-career criminal claims
 - [https://www.dailymail.co.uk/news/article-12557411/Jill-Dandos-murder-professional-hit-person-responsible-not-think-ex-career-criminal-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557411/Jill-Dandos-murder-professional-hit-person-responsible-not-think-ex-career-criminal-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:03:54+00:00

Noel 'Razor' Smith, who has 58 convictions and spent 32 years in some of Britain's toughest jails, was speaking in new Netflix series Who Shot Jill Dando, which was released today.

## Parents' warning after toddler, two, 'almost dies' from swallowing six magnetic 'fidget' balls which started burning holes in her bowel
 - [https://www.dailymail.co.uk/news/article-12557359/parents-warn-toddler-dies-swallowed-magnetic-fidget-balls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557359/parents-warn-toddler-dies-swallowed-magnetic-fidget-balls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:03:28+00:00

Jade Berriman, 31, from Hull, Yorkshire, said her toddler Meliyah-Jayd had to undergo emergency surgery when her body began to poison itself after ingesting the 4mm magnetic 'fidget' balls.

## A woman who feared she had been spiked on a hen night tells of her shock after discovering she had actually had a stroke
 - [https://www.dailymail.co.uk/news/article-12557445/Woman-feared-spiked-hen-night-tells-shock-discovering-actually-stroke.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557445/Woman-feared-spiked-hen-night-tells-shock-discovering-actually-stroke.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T10:02:12+00:00

Joanna Whitelaw, 27, was celebrating her friend's upcoming nuptials in Edinburgh, when her body 'suddenly went numb' and her vision blurred.

## Chicken row mein! Father 'absolutely disgusted' after Chinese buffet bosses charged 5ft boy, 11, an extra £12 for an adult meal because he was 'too tall'
 - [https://www.dailymail.co.uk/news/article-12557323/Chicken-row-mein-Father-absolutely-disgusted-Chinese-buffet-bosses-charged-5ft-boy-11-extra-12-adult-meal-tall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557323/Chicken-row-mein-Father-absolutely-disgusted-Chinese-buffet-bosses-charged-5ft-boy-11-extra-12-adult-meal-tall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:53:09+00:00

Craig Cantrill's evening at the Wong Ting in Sheffield, South Yorkshire, was ruined when he was told to pay an extra £12 for his 11-year-old son's dinner.

## Pittsburgh Steelers' flight makes emergency landing in Kansas City due to engine issues en route home from Las Vegas
 - [https://www.dailymail.co.uk/news/article-12557463/Pittsburgh-Steelers-flight-makes-emergency-landing-Kansas-City-engine-issues-en-route-home-Las-Vegas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557463/Pittsburgh-Steelers-flight-makes-emergency-landing-Kansas-City-engine-issues-en-route-home-Las-Vegas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:52:10+00:00

The team's charter flight, an Airbus A330-900, took off from Sin City at 9pm last night but at 5am suffered an oil pressure failure.

## The name's Bond... RODNEY Bond! How 007 could have had a starkly different first name by author Ian Fleming who took inspiration from real life WW2 intelligence hero
 - [https://www.dailymail.co.uk/news/article-12557239/Bond-RODNEY-Bond-007-author-Ian-Fleming-real-WW2-intelligence-hero.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557239/Bond-RODNEY-Bond-007-author-Ian-Fleming-real-WW2-intelligence-hero.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:45:53+00:00

Ian Fleming was looking for a name for his main character when his brother Peter - a lieutenant colonel in charge of 'military deception' in Southeast Asia during WWII - suggested 'Bond'.

## This Morning dental expert Dr Uchenna Okoye's cause of death is revealed as her grieving family say they are 'devastated her beautiful, full life has been cut so short'
 - [https://www.dailymail.co.uk/news/article-12557211/this-morning-dr-uchenna-okoye-died-brain-aneurysm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557211/this-morning-dr-uchenna-okoye-died-brain-aneurysm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:40:18+00:00

The 53-year-old's grieving family say they are 'devastated her beautiful, full life has been cut so short'. The 10 Years Younger in 10 Days star died after collapsing at her London home.

## Woolworths' new warning to anyone who places drinks on its checkout conveyor belts
 - [https://www.dailymail.co.uk/news/article-12557115/Woolworths-drinks-conveyor-belts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557115/Woolworths-drinks-conveyor-belts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:38:23+00:00

The announcement on the supermarket giant's TikTok account told shoppers there is a right way and a wrong way to put cans and bottles on the checkout conveyor belt.

## Never-ending NHS strikes force hospitals to cancel 'more than a MILLION appointments'
 - [https://www.dailymail.co.uk/health/article-12557005/NHS-strikes-MILLION-appointments-cancelled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-12557005/NHS-strikes-MILLION-appointments-cancelled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:34:07+00:00

A walk-out by junior doctors and consultants in England last week is thought to have seen around 100,000 consultations postponed.

## The slow death of driving: How 20mph zones are part of a far bigger plot to ban cars from UK towns and cities and restrict private ownership of vehicles
 - [https://www.dailymail.co.uk/news/article-12536263/Eco-zealots-want-car-free-cities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12536263/Eco-zealots-want-car-free-cities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:31:55+00:00

EXCLUSIVE: Pro-slow campaigners who have been defending controversial new 20mph speed limits actually want 'car free cities' and an end to private vehicle ownership, plans suggest.

## French family planning association turns to Netflix's Sex Education to teach youth due to chronic lack of uptake in schools with only 20% offering lessons
 - [https://www.dailymail.co.uk/news/article-12557093/netflix-sex-education-taught-french-schools.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557093/netflix-sex-education-taught-french-schools.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:31:15+00:00

A French family planning agency has collaborated with the hit Netflix series Sex Education to teach teenagers due to a chronic lack of uptake in the curriculum in schools.

## John Farnham: Research reveals what the impact hit song has really had on voters - as support for the Voice plummets to record low
 - [https://www.dailymail.co.uk/news/article-12557127/John-Farnham-Voice-song-backfires.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557127/John-Farnham-Voice-song-backfires.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:19:35+00:00

John Farnham's official backing of the Yes campaign has backfired with voters, according to new polling.

## Donald Trump hails Rishi Sunak's 'smart' decision to water down Net Zero plans
 - [https://www.dailymail.co.uk/news/article-12557263/Donald-Trump-hails-Rishi-Sunaks-smart-decision-water-Net-Zero-plans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557263/Donald-Trump-hails-Rishi-Sunaks-smart-decision-water-Net-Zero-plans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:15:57+00:00

The former US president praised Mr Sunak for having 'substantially rolled back' climate action.

## Horrifying moment father-of-two, 61, is gored to death by rampaging bull at Spanish festival as he frantically tried to escape through railings
 - [https://www.dailymail.co.uk/news/article-12557233/Moment-father-gored-death-rampaging-bull-Spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557233/Moment-father-gored-death-rampaging-bull-Spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T09:03:07+00:00

Jose Antonio Subies, 61, died at a hospital in Valencia on Saturday night after suffering gore injuries which affected his liver and one of his lungs.

## Marcus Rashford crash: Man United officials paid for 'very shaken' grandmother's taxi home after 74-year-old was involved in collision with the football stars £700k Rolls-Royce
 - [https://www.dailymail.co.uk/news/article-12557199/Man-United-grandmother-taxi-crash-Marcus-Rashford-Rolls-Royce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557199/Man-United-grandmother-taxi-crash-Marcus-Rashford-Rolls-Royce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:58:45+00:00

The football (pictured) star crashed his car outside the club's Carrington training ground at around midnight last Saturday, damaging both cars and mowing down a traffic light camera post.

## A landscape scarred forever: Drone footage of HS2 construction work tearing across England's countryside reveals just how much work is left to be done with northern section of high speed rail line 'set to be scrapped in days'
 - [https://www.dailymail.co.uk/news/article-12557169/hs2-drone-footage-damaged-countryside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557169/hs2-drone-footage-damaged-countryside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:58:38+00:00

Drone footage taken from points on Britain's faltering High Speed Rail 2 project has revealed the enormous scars ripped into the countryside across the route.

## British man, 35, is stabbed to death in woodland in Portugal 'while playing Blue Whale suicide game' as 'second UK citizen, 26, hands himself and cops question five'
 - [https://www.dailymail.co.uk/news/article-12557133/British-man-35-stabbed-death-woodland-Portugal-playing-Blue-Whale-suicide-game-second-UK-citizen-26-hands-cops-question-five.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557133/British-man-35-stabbed-death-woodland-Portugal-playing-Blue-Whale-suicide-game-second-UK-citizen-26-hands-cops-question-five.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:56:43+00:00

A British man has been stabbed to death in woodland in Portugal while playing the Blue Whale suicide game, it has been claimed.

## Shocking moment sheriff's deputy violently body slams teen girl, 16, to the floor after cops are called to a brawl in a high school car park
 - [https://www.dailymail.co.uk/news/article-12557041/Shocking-moment-sheriffs-deputy-violently-body-slams-teen-girl-16-floor-cops-called-brawl-high-school-car-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557041/Shocking-moment-sheriffs-deputy-violently-body-slams-teen-girl-16-floor-cops-called-brawl-high-school-car-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:56:28+00:00

A 16-year-old California girl is recovering in a trauma unit after suffering spinal injuries when a sheriff's deputy slammed her to the ground during a brawl.

## Moment cunning fox evades homeowners in their dressing gowns before 'flying out' of their bathroom window
 - [https://www.dailymail.co.uk/news/article-12556943/Fox-homeowners-dressing-gowns-flying-bathroom-window.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556943/Fox-homeowners-dressing-gowns-flying-bathroom-window.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:54:58+00:00

Dave Masters, 55, and his wife Sarah, 48, (pictured) captured the unbelievable feat on camera after a curious visitor wandered into their garden in Luton last week.

## Ex-accountant who waged bizarre YouTube hate campaign against her neighbours amid feuds over littering, Brexit and pet turkeys at the home she called 'Cluckingham Palace' is convicted of harassment
 - [https://www.dailymail.co.uk/news/article-12557171/Ex-accountant-waged-bizarre-YouTube-hate-campaign-against-neighbours-amid-feuds-littering-Brexit-pet-turkeys-home-called-Cluckingham-Palace-convicted-harassment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557171/Ex-accountant-waged-bizarre-YouTube-hate-campaign-against-neighbours-amid-feuds-littering-Brexit-pet-turkeys-home-called-Cluckingham-Palace-convicted-harassment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:42:09+00:00

A retired accountant was facing jail today over a YouTube hate campaign against her neighbours sparked by parking, littering, Brexit - and her own pet turkeys.

## Moment Pope Francis, 86, slaps his hand down and glares at an empty chair beside him after being made to wait for a meeting with French President Emmanuel Macron
 - [https://www.dailymail.co.uk/news/article-12557025/Moment-Pope-Francis-86-slaps-hand-glares-chair-wait-meeting-French-President-Emmanuel-Macron.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557025/Moment-Pope-Francis-86-slaps-hand-glares-chair-wait-meeting-French-President-Emmanuel-Macron.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:41:59+00:00

Footage aired on Italian television showed the pontiff sitting by himself in a chair in Marseille's Palais du Pharo ahead of a meeting between Francis and Macron.

## Don't mention Brexit! Lib Dem leader Ed Davey desperately fends off activists' demands to be up-front about EU hopes as he targets Tory heartlands
 - [https://www.dailymail.co.uk/news/article-12557043/Dont-mention-Brexit-Lib-Dem-leader-Ed-Davey-desperately-fends-activists-demands-EU-hopes-targets-Tory-heartlands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557043/Dont-mention-Brexit-Lib-Dem-leader-Ed-Davey-desperately-fends-activists-demands-EU-hopes-targets-Tory-heartlands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:37:53+00:00

Ed Davey has been forced on to the defensive after being heckled by activists over EU policy at the Lib Dem conference in Bournemouth.

## Fifteen migrants posing as children are 'found to be adults' by Kent officials after having their ages reassessed - as people smugglers 'actively brief them to say they are under 16'
 - [https://www.dailymail.co.uk/news/article-12557001/Fifteen-migrants-posing-children-adults-Kent-officials-ages-reassessed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557001/Fifteen-migrants-posing-children-adults-Kent-officials-ages-reassessed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:36:04+00:00

The ages of 23 migrants claiming to be children were assessed - and of these 15 were found to actually be adults. MP for Dover Natalie Elphicke warned urgent action is needed for age checks.

## Police launch criminal probe after human placenta discovered in a city centre park
 - [https://www.dailymail.co.uk/news/article-12557217/police-probe-human-placenta-discovered-city-centre-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557217/police-probe-human-placenta-discovered-city-centre-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:34:09+00:00

Police have launched a criminal probe after a human placenta was found in Southampton in June. A woman was arrested on suspicion of concealment of the birth of a child but released after DNA tests.

## Brit, 57, dies in horror motorbike crash in Spanish mountains
 - [https://www.dailymail.co.uk/news/article-12557089/Brit-dies-horror-motorbike-crash-Spain-Cantabria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12557089/Brit-dies-horror-motorbike-crash-Spain-Cantabria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:24:04+00:00

The 57-year-old suffered his fatal accident near the village of San Pedro del Romeral in the northern Spanish region of Cantabria.

## New Zealand Cops left red-faced after officer breath-tests passenger and not the driver at a checkpoint
 - [https://www.dailymail.co.uk/news/article-12556925/Cops-breath-test-passenger-not-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556925/Cops-breath-test-passenger-not-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T08:15:18+00:00

A police officer has been left red-faced after she breath-tested the passenger and not the driver of a car at a drink-driving checkpoint.

## KPMG offered free vegan meals and fish and chips Fridays in bid to lure workers back to the office - as M&G boss orders staff back in three days a week as 'the City's too empty on Fridays'
 - [https://www.dailymail.co.uk/news/article-12556887/KPMG-working-home-free-meals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556887/KPMG-working-home-free-meals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T07:59:28+00:00

Big Four accounting firm KPMG gave the freebie to workers to try and coax people back after the coronavirus pandemic forced employees to be rooted to their desks at home.

## Rishi Sunak ducks over plan to scrap HS2 Manchester leg but says he IS still committed to 'Levelling Up' the North - as Tories voice alarm at axing rail project days before party's pre-election conference in city
 - [https://www.dailymail.co.uk/news/article-12556941/Rishi-Sunak-HS2-Manchester-Tory-conference-donors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556941/Rishi-Sunak-HS2-Manchester-Tory-conference-donors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T07:57:59+00:00

Rishi Sunak is facing a mounting backlash amid signs that the government is on the cusp of downgrading the project again over spiralling costs.

## Hilarious moment BBC Breakfast presenter Jon Kay spots his doppelganger next to King Charles in France
 - [https://www.dailymail.co.uk/news/article-12556905/Moment-BBC-Breakfast-presenter-Jon-Kay-doppelganger-King-Charles-France.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556905/Moment-BBC-Breakfast-presenter-Jon-Kay-doppelganger-King-Charles-France.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T07:57:35+00:00

After a clip from the King's France meeting with Macron surfaced showing a man who looked very much like BBC Breakfast presenter Jon Kay, he was forced to dispel rumours he been across the pond.

## War within the ranks of Scotland Yard: 'SAS on standby' over fears Met Police armed policing revolt will spread across country as officers demand a 'period to reflect' - but are 'warned they can be still forced to carry out duties'
 - [https://www.dailymail.co.uk/news/article-12556847/Met-Police-chief-wants-legal-protections-Chris-Kaba-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556847/Met-Police-chief-wants-legal-protections-Chris-Kaba-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T07:54:34+00:00

Soldiers are on standby after scores of Metropolitan Police officers stood down from firearms duties following a murder charge against one of their colleagues over the death of Chris Kaba last year.

## Westfield stabbing: Woman knifed at Belconnen shopping centre
 - [https://www.dailymail.co.uk/news/article-12556857/Westfield-stabbing-Woman-knifed-Belconnen-shopping-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556857/Westfield-stabbing-Woman-knifed-Belconnen-shopping-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T07:52:18+00:00

Trong Nguyen, 26, was refused bail after he allegedly lunged at a woman with a knife, cutting her arm, before stealing her ute from Westfield Belconnen, in the ACT on Sunday.

## Calm before the storm: Britain braces for Storm Agnes as map shows where heavy rain and 80mph gale force winds will lash the country this week
 - [https://www.dailymail.co.uk/news/article-12556893/storm-agnes-map-britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556893/storm-agnes-map-britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T07:50:08+00:00

Much of the UK is on alert over the incoming low pressure system, which is expected to be named Storm Agnes and could lead to 'flying debris and damage to buildings'.

## Cops issue an urgent arrest warrant for a high-flying businesswoman and accused fraudster Shayhe Lowery. There's just one problem
 - [https://www.dailymail.co.uk/news/article-12556767/Cops-issue-urgent-arrest-warrant-high-flying-businesswoman-accused-fraudster-Shayhe-Lowery-Theres-just-one-problem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556767/Cops-issue-urgent-arrest-warrant-high-flying-businesswoman-accused-fraudster-Shayhe-Lowery-Theres-just-one-problem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T07:49:51+00:00

Burwood Police Area Command issued an urgent plea on Monday afternoon asking the community to help track down 36-year-old Shayhe Lowery.

## Successful businesswoman and influencer Steph Claire Smith relives horrifying moment her nude photos were leaked
 - [https://www.dailymail.co.uk/news/article-12556947/Businesswoman-leaked-nudes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556947/Businesswoman-leaked-nudes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T07:47:21+00:00

An Australian model and influencer has revealed she had nude photos leaked while at school.

## Britain's 'soft justice': Shoplifters, drug users and even sex offenders given a 'slap on the wrist' for nearly a  MILLION crimes - how many out-of-court deals does YOUR police force hand out?
 - [https://www.dailymail.co.uk/news/article-12539913/community-resolutions-lawless-Britain-shoplifters-drug-SEX-OFFENDERS-police-crimes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12539913/community-resolutions-lawless-Britain-shoplifters-drug-SEX-OFFENDERS-police-crimes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T07:32:47+00:00

EXCLUSIVE: The number of 'soft justice' community resolutions handed out by British police has increased by 40 per cent in the last six years.

## Married Pennsylvania cop faces false imprisonment charges for 'improperly committing his ex to a mental health facility' after shocking 12-minute arrest video and allegedly saying: 'I'll paint you as crazy'
 - [https://www.dailymail.co.uk/news/article-12556677/Married-Pennsylvania-cop-faces-false-imprisonment-charges-improperly-committing-ex-mental-health-facility-shocking-12-minute-arrest-video-allegedly-saying-Ill-paint-crazy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556677/Married-Pennsylvania-cop-faces-false-imprisonment-charges-improperly-committing-ex-mental-health-facility-shocking-12-minute-arrest-video-allegedly-saying-Ill-paint-crazy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T06:59:58+00:00

Pennsylvania State Police trooper Ronald Davis, 37, is facing a slew of charges after he allegedly detained his ex-girlfriend committed her to a mental health facility under phony claims.

## 'She'll have to compete': Democrat leader dodges a direct answer when asked if Kamala Harris is the future of the party
 - [https://www.dailymail.co.uk/news/article-12556703/Shell-compete-Democrat-leader-dodges-direct-answer-asked-Kamala-Harris-future-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556703/Shell-compete-Democrat-leader-dodges-direct-answer-asked-Kamala-Harris-future-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T06:53:47+00:00

Democrat Jim Clyburn of South Carolina, key to Biden's successful 2020 presidential win is refraining from explicitly endorsing Vice President Kamala Harris as the future face of the party.

## NYC residents urged to FLEE basement apartments as post-Tropical Storm Ophelia sends life-threatening rainwater down on the city
 - [https://www.dailymail.co.uk/news/article-12556595/NYC-residents-urged-FLEE-basement-apartments-post-Tropical-Storm-Ophelia-sends-life-threatening-rainwater-city.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556595/NYC-residents-urged-FLEE-basement-apartments-post-Tropical-Storm-Ophelia-sends-life-threatening-rainwater-city.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T06:50:02+00:00

New Yorkers were warned to leave their basement apartments and prepare to seek higher ground as post-tropical cyclone Ophelia continued to hammer the East Coast.

## Qantas warns airfares could increase as fuel prices soar
 - [https://www.dailymail.co.uk/news/article-12556791/Qantas-warns-airfares-increase-fuel-prices-soar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556791/Qantas-warns-airfares-increase-fuel-prices-soar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T06:46:48+00:00

Just three days after new Qantas boss Vanessa Hudson vowed to win back customers' trust, the airlines is set to lift the cost of flying due to a rise in the price of jet fuel.

## Leader of Canada's House of Commons is forced to apologize after honoring a NAZI in the public gallery who fought in WWII - as 98-year-old is given round of applause by Justin Trudeau and visiting Zelensky
 - [https://www.dailymail.co.uk/news/article-12556763/Leader-Canadas-House-Commons-forced-apologize-honoring-NAZI-public-gallery-fought-WWII-98-year-old-given-round-applause-Justin-Trudeau-Volodymyr-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556763/Leader-Canadas-House-Commons-forced-apologize-honoring-NAZI-public-gallery-fought-WWII-98-year-old-given-round-applause-Justin-Trudeau-Volodymyr-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T06:42:15+00:00

Aired in a statement Sunday from Anthony Rota, the apology saw the speaker insist he had just became aware that the man he celebrated just days earlier served in a Nazi unit during WWII.

## Teens allegedly steal Mercedes-Benz before arrest at Logan
 - [https://www.dailymail.co.uk/news/article-12556687/Teens-allegedly-steal-Mercedes-Benz-arrest-Logan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556687/Teens-allegedly-steal-Mercedes-Benz-arrest-Logan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T06:13:44+00:00

Stunned motorists took footage of teenagers brazenly hanging out the windows of an allegedly stolen Mercedes-Benz as it roared along a highway between cities in south east Queensland.

## Mushroom poisoning: Secret plan for 'death cap' lunch sole survivor to honour wife in Leongatha, Victoria
 - [https://www.dailymail.co.uk/news/melbourne/article-12556491/Mushroom-poisoning-Secret-plan-death-cap-lunch-sole-survivor-honour-wife-Leongatha-Victoria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/melbourne/article-12556491/Mushroom-poisoning-Secret-plan-death-cap-lunch-sole-survivor-honour-wife-Leongatha-Victoria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T06:07:44+00:00

Plans are underway to allow pastor Ian Wilkinson to honour his wife Heather after her death at the deadly Leongatha lunch.

## Brutal Britain: UK's downcast urban landscapes of the 1960s are revealed in architectural magazine photos which feature in new exhibition
 - [https://www.dailymail.co.uk/news/article-12548583/UKs-urban-landscapes-1960s-revealed-new-exhibition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12548583/UKs-urban-landscapes-1960s-revealed-new-exhibition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T06:00:46+00:00

The image of three children playing with a toy gun was taken on the Pepys Estate in Deptford, East London, more than five decades ago.

## McDonald's customer hurled burger at staff at Sydney restaurant
 - [https://www.dailymail.co.uk/news/article-12556531/McDonalds-customer-hurled-burger-staff-Sydney-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556531/McDonalds-customer-hurled-burger-staff-Sydney-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T06:00:07+00:00

McDonalds crew members are again in the firing line, with a new video emerging online of an enraged customer firing a McChicken missile at a stunned staff member at a Sydney store.

## Body of British hiker, 29, found near mountain trail in the Swiss Alps three months after he went missing
 - [https://www.dailymail.co.uk/news/article-12556753/British-hiker-mountain-trail-Swiss-Alps-three-months-missing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556753/British-hiker-mountain-trail-Swiss-Alps-three-months-missing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T05:57:43+00:00

Aidan Roche (pictured), 29, was hiking on his own in the Grindelwald area of Switzerland when he was last heard from on June 22, two days before he was due to fly back to the UK.

## Horrifying images show a bloodied Border Patrol agent after brawl with a migrant as more than 5,000 asylum seekers pack onto a crowded freight train dubbed 'The Beast' headed for America
 - [https://www.dailymail.co.uk/news/article-12556519/Migrants-train-hopping-border-patrol-agents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556519/Migrants-train-hopping-border-patrol-agents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T05:49:40+00:00

Mexican-born Republican Maya Flores shared the shocking graphic images of a bloodied federal agent after an alleged altercation with an uncooperative migrant near McAllen, Texas.

## Mark Bouris breaks his silence about his company's share price bloodbath - as he reveals his secret plan to change Aussie mortgages forever
 - [https://www.dailymail.co.uk/news/article-12556399/Mark-Bouris-breaks-silence-companys-share-price-blood-bath-reveals-secret-plan-change-Aussie-mortgages-forever.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556399/Mark-Bouris-breaks-silence-companys-share-price-blood-bath-reveals-secret-plan-change-Aussie-mortgages-forever.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T05:44:13+00:00

Mortgage broking tycoon Mark Bouris has broken his silence on the plunge in Yellow Brick Road's share price - now worth five cents. He has revealed his plans to emerge stronger.

## Vile voice messages left for No campaigner Jacinta Price as she fights Indigenous Voice
 - [https://www.dailymail.co.uk/news/article-12556561/Jacinta-Price-racist-voicemail-voice-referendum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556561/Jacinta-Price-racist-voicemail-voice-referendum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T05:29:27+00:00

Senator Jacinta Price has been leading the Opposition's No vote campaign but it has made her a magnet for vicious personal attacks after her mobile phone number was leaked on social media.

## The two sides of Ingham Chicken riches: Battler poultry worker's powerful speech about the cost of living goes viral... as uber-wealthy heirs to business fortune party in Europe
 - [https://www.dailymail.co.uk/news/article-12556091/ingham-chicken-strike-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556091/ingham-chicken-strike-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T05:09:41+00:00

Workers at a major Australian poultry company has launched strike action amid a pay dispute in the wake of the wealthy owners' overseas celebrations.

## Outrage as several KFC stores go cashless in Australia
 - [https://www.dailymail.co.uk/news/article-12556675/Outrage-KFC-stores-cashless-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556675/Outrage-KFC-stores-cashless-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T05:03:23+00:00

A rising number of KFC stores are no longer accepting cash, sparking outrage from customers who share concerns that the country is going cashless.

## Australia is set to produce its lowest amount of milk in 30 years: Here's what it means for Coles shoppers
 - [https://www.dailymail.co.uk/news/article-12556191/Australia-set-produce-lowest-milk-30-years-Heres-means-Coles-Woolies-shoppers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556191/Australia-set-produce-lowest-milk-30-years-Heres-means-Coles-Woolies-shoppers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T04:56:52+00:00

The Australian dairy industry is set to produce its lowest amount of milk in 30 years, causing milk prices to skyrocket with shoppers forced to buy cheaper, imported produce.

## Florida grandmother finally forced to tear down the Miami treehouse she had lived in for 17 YEARS after being fined $40k over 'unsafe' construction
 - [https://www.dailymail.co.uk/news/article-12556541/Florida-grandmother-finally-forced-tear-Miami-treehouse-lived-17-YEARS-fined-40k-unsafe-construction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556541/Florida-grandmother-finally-forced-tear-Miami-treehouse-lived-17-YEARS-fined-40k-unsafe-construction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T04:50:00+00:00

Shawnee Chasser, 72, has been forced to comply with Miami-Dade County building and knocked down her treehouse home. Over the course of eight years she racked up $40,000 in fines for the 'unsafe' house

## Yes campaigner to the Voice addresses vicious rumours about his family: 'Really crazy'
 - [https://www.dailymail.co.uk/news/article-12556237/thomas-mayo-voice-rumours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556237/thomas-mayo-voice-rumours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T04:47:14+00:00

The one-time wharfie has become a household name ahead of the referendum, working closely with the government to help promote a Yes vote.

## The words about the Voice to Parliament that have come back to haunt Peter FitzSimons
 - [https://www.dailymail.co.uk/news/article-12556529/peterfitzsimons-kamahl-voice-indigenous-referendum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556529/peterfitzsimons-kamahl-voice-indigenous-referendum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T04:46:14+00:00

A social media post from Peter FitzSimons praising Kamahl's support for the Voice to Parliament has come back to haunt him after the entertainer spectacularly backflipped again on his stance.

## Huge problem that's pushing many Aussies over the edge: 'Something has to give'
 - [https://www.dailymail.co.uk/news/article-12555877/Huge-problem-thats-pushing-Aussies-edge-give.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12555877/Huge-problem-thats-pushing-Aussies-edge-give.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T04:30:45+00:00

A perfect storm of rising costs that's threatening to shatter the lives of everyday Aussies.

## Worker killed on site at Victoria Point near Brisbane
 - [https://www.dailymail.co.uk/news/article-12556623/Worker-killed-site-Victoria-Point-Brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556623/Worker-killed-site-Victoria-Point-Brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T04:29:42+00:00

The 56-year-old man died at the workplace in Victoria Point, near Brisbane, at 1pm on Saturday.

## Balmoral Beach P-plate car crash: Wild scenes at one of Sydney's most popular beaches
 - [https://www.dailymail.co.uk/news/article-12556571/Balmoral-Beach-car-crash-Wild-scenes-one-Sydneys-popular-beaches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556571/Balmoral-Beach-car-crash-Wild-scenes-one-Sydneys-popular-beaches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T03:56:05+00:00

At out of control driver has plunged off a footpath and flipped their vehicle directly onto a packed Balmoral Beach - narrowly avoiding beachgoers.

## Oregon man, 19, caught on camera threatening to rape and kill his terrified black neighbors before stabbing their door with a knife and saying he wants them to be WHIPPED
 - [https://www.dailymail.co.uk/news/article-12556255/Oregon-man-19-caught-camera-threatening-rape-kill-terrified-black-neighbors-stabbing-door-knife-saying-wants-WHIPPED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556255/Oregon-man-19-caught-camera-threatening-rape-kill-terrified-black-neighbors-stabbing-door-knife-saying-wants-WHIPPED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T03:51:43+00:00

Shirtless Dominic Austin, 19, is seen pounding on the door as he makes the sinister threats, pacing menacingly in front of the mother and daughters' doorstep.

## Freepour Espresso cafe criticised over female-only job ad in Marrickville
 - [https://www.dailymail.co.uk/news/article-12556331/Freepour-EspresFreepour-Espresso-cafe-criticised-female-job-ad-Marrickvilleso-cafe-outrage-sex-discrimination.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556331/Freepour-EspresFreepour-Espresso-cafe-criticised-female-job-ad-Marrickvilleso-cafe-outrage-sex-discrimination.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T03:50:43+00:00

Freepour Espresso at Marrickville, in Sydney 's inner west, posted the ad for a 'female fulltime barista/allrounder' to a jobs board on Facebook .

## Dr Kerry Chant refuses to rule out lockdowns if Australia is hit by another pandemic
 - [https://www.dailymail.co.uk/news/article-12556225/Kerry-Chant-NSW-Covid-lockdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556225/Kerry-Chant-NSW-Covid-lockdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T03:37:29+00:00

A top health official has refused to state whether lockdowns and curfews are the best way to tackle a pandemic as controversy continues to swirl around a federal inquiry into Covid responses.

## Coles new feature angers Aussies: 'Feels really invasive'
 - [https://www.dailymail.co.uk/news/article-12556153/Coles-new-feature-angers-Aussies-Feels-really-invasive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556153/Coles-new-feature-angers-Aussies-Feels-really-invasive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T03:25:20+00:00

The Aussie shopper was scanning her groceries at a self-serve check-out on the weekend when she noticed an image of herself had popped up in a small square in the top right corner of the screen.

## Jacinta Price opens up on missing aunt and her fears for Australia after the Indigenous Voice to Parliament
 - [https://www.dailymail.co.uk/news/article-12555991/Jacinta-Price-Marion-Nelson-Indigenous-children-Voice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12555991/Jacinta-Price-Marion-Nelson-Indigenous-children-Voice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T03:21:04+00:00

Marion Nabarula Nelson, 14, vanished on January 10, 1982, and her disappearance has haunted her family for more than 40 years.

## 'Homeless-looking' pensioner's stunning final act of kindness as he leaves every cent of his $4.5million Clovelly home to charity
 - [https://www.dailymail.co.uk/news/article-12556033/bill-crews-clovelly-pensioner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556033/bill-crews-clovelly-pensioner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T02:50:48+00:00

An unassuming Aussie public servant who lived in a run-down Sydney semi and ate baked beans for dinner has stunned and delighted a homelessness charity with a massive $4.5million bequest.

## Writers Guild of America and Alliance of Motion Picture and Television Producers reach a tentative deal to end their strike after nearly 5 months
 - [https://www.dailymail.co.uk/news/article-12556477/Writers-Guild-America-Alliance-Motion-Picture-Television-Producers-reach-tentative-deal-end-strike-nearly-5-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556477/Writers-Guild-America-Alliance-Motion-Picture-Television-Producers-reach-tentative-deal-end-strike-nearly-5-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T02:50:12+00:00

Following five months of deliberation, the Writers Guild of America has struck a tentative deal with the Alliance of Motion Picture and Television Producers.

## Melbourne mum Taylor Johnston from Mornington Peninsula tragically dies after IVF battle
 - [https://www.dailymail.co.uk/news/article-12556301/mum-cancer-baby-melbourne-gofundme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556301/mum-cancer-baby-melbourne-gofundme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T02:44:02+00:00

A young mother whose world turned upside down when the birth of her newborn led to her discovering she had terminal cancer has died.

## American musician Marc Rebillet is pelted with bottles and abused by crowds at the Listen Out festival in Adelaide
 - [https://www.dailymail.co.uk/news/article-12556355/American-musician-Marc-Rebillet-pelted-bottles-abused-crowds-Listen-festival-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556355/American-musician-Marc-Rebillet-pelted-bottles-abused-crowds-Listen-festival-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T02:41:47+00:00

Marc Rebillet was performing at the Listen Out festival in Adelaide on Friday night when he was pelted with abuse and projectiles by attendees waiting for US rapper Ice Spice to take to the stage.

## The many faces of Taylor Swift at the Kansas City Chiefs game: Singer jumps for joy, shakes her hair and shares a sweet bonding moment with Travis Kelce's mom
 - [https://www.dailymail.co.uk/news/article-12556143/The-faces-Taylor-Swift-Kansas-City-Chiefs-game-Singer-jumps-joy-shakes-hair-shares-sweet-bonding-moment-Travis-Kelces-mom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556143/The-faces-Taylor-Swift-Kansas-City-Chiefs-game-Singer-jumps-joy-shakes-hair-shares-sweet-bonding-moment-Travis-Kelces-mom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T02:29:18+00:00

Taylor Swift had a share of meme-able moments as she reacted to rumored beau Travis Kelce's touchdown during the Kansas City Chiefs game against the Chicago Bears on September 24.

## Mom of Idaho murders victim Ethan Chapin shocks Crimecon audience by making an emotional appearance during Q&A after expert's talk on the killings
 - [https://www.dailymail.co.uk/news/article-12556305/Mom-Idaho-murders-victim-Ethan-Chapin-shocks-Crimecon-audience-making-emotional-appearance-Q-experts-talk-killings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556305/Mom-Idaho-murders-victim-Ethan-Chapin-shocks-Crimecon-audience-making-emotional-appearance-Q-experts-talk-killings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T02:05:42+00:00

Stacy Chapin, the mother of Ethan Chapin, one of the victims in the Idaho murders that occurred last November, appeared at a true crime conference. Chapin introduced herself as Ethan's mother.

## Lidia Thorpe exposes why she thinks Anthony Albanese's Voice to Parliament is hurting Aboriginal people
 - [https://www.dailymail.co.uk/news/article-12556115/Lidiathorpe-voice-albanese-government-indigenous.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556115/Lidiathorpe-voice-albanese-government-indigenous.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T01:43:04+00:00

Lidia Thorpe says the Indigenous Voice to Parliament referendum is doing more harm to the lives of Aboriginal and Torres Strait Islander people by tearing communities apart.

## Jetstar flight forced to return to Perth Airport because of unruly passenger
 - [https://www.dailymail.co.uk/news/article-12556377/Jetstar-forced-return-Perth-Airport-unruly-passenger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556377/Jetstar-forced-return-Perth-Airport-unruly-passenger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T01:36:51+00:00

A Jetstar flight was forced to turn back after a passenger allegedly became unruly on the flight.

## Putin rains down hell on Ukraine's Odessa in terrifying overnight blitz on Jewish holy day of Yom Kippur - as Russian warmonger's lawless invasion grinds into its 20th month
 - [https://www.dailymail.co.uk/news/article-12556251/Putin-rains-hell-Ukraines-Odessa-terrifying-overnight-blitz-Jewish-holy-day-Yom-Kippur-Russian-warmongers-lawless-invasion-grinds-20th-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556251/Putin-rains-hell-Ukraines-Odessa-terrifying-overnight-blitz-Jewish-holy-day-Yom-Kippur-Russian-warmongers-lawless-invasion-grinds-20th-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T01:16:22+00:00

Vladimir Putin has rained down hell on Ukraine's port city of Odessa with a powerful missile strike - just as the city's large Jewish population marks the holy day of Yom Kippur.

## 'We're all with you mate': Derby County stars rally around Josh Vickers after grieving goalkeeper revealed his wife died of cancer three months after their wedding following years-long battle against the disease
 - [https://www.dailymail.co.uk/news/article-12556333/Were-mate-Derby-County-stars-rally-Josh-Vickers-grieving-goalkeeper-revealed-wife-died-cancer-three-months-wedding-following-years-long-battle-against-disease.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556333/Were-mate-Derby-County-stars-rally-Josh-Vickers-grieving-goalkeeper-revealed-wife-died-cancer-three-months-wedding-following-years-long-battle-against-disease.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T01:11:38+00:00

Josh Vickers, 27, (right) documented his wife Laura's (left) struggle on Instagram which included numerous rounds of chemotherapy.

## Taylor Swift's romance touchdown with Travis Kelce! Singer's fans go wild with hilarious memes as they react to her cheering on her new lover at game with his mom
 - [https://www.dailymail.co.uk/tvshowbiz/article-12555937/Taylor-Swift-fans-hilarious-memes-dating-rumors-Kansas-City-Chiefs-game.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12555937/Taylor-Swift-fans-hilarious-memes-dating-rumors-Kansas-City-Chiefs-game.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T01:09:52+00:00

Taylor Swift left her legion of fans buzzing when she attended Travis Kelce's Kansas City Chief's game against the Chicago Bears on Sunday.

## Watch where you're going! Moment lorry is driven down the wrong side of the M1... forcing motorway to shut and sparking travel chaos
 - [https://www.dailymail.co.uk/news/article-12556097/Watch-youre-going-Moment-lorry-driven-wrong-M1-forcing-motorway-shut-sparking-travel-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556097/Watch-youre-going-Moment-lorry-driven-wrong-M1-forcing-motorway-shut-sparking-travel-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T01:08:50+00:00

Traffic was built up on the M1 near Wakefield on Sunday after lanes two lanes were closed, causing delays of at least 15 minutes for frustrated drivers.

## Backlog of paramedics waiting to complete driver training could be fuelling 'fatal delays' in ambulance waiting times
 - [https://www.dailymail.co.uk/news/article-12556311/NHS-Paramedic-delays-ambulance-waiting-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556311/NHS-Paramedic-delays-ambulance-waiting-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:58:37+00:00

New figures show that more than 700 ambulance staff in England are waiting to take the C1 driving test required to jump behind the wheel of a vehicle up to 7.5 tonnes.

## Mushroom chef Erin Patterson lashes out at media with three frustrated words - as scrutiny mounts over 'death cap' lunch
 - [https://www.dailymail.co.uk/news/article-12556015/Mushroom-chef-Erin-Patterson-lashes-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556015/Mushroom-chef-Erin-Patterson-lashes-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:50:35+00:00

The woman at the centre of the fatal mushroom poisoned lunch has vented her frustration at the ever present media with Erin Patterson telling media camped outside her house to go away.

## Hardworking Aussie bloke wakes up wife to let her know they'd just won $1.7million in TattsLotto
 - [https://www.dailymail.co.uk/news/article-12556319/Hardworking-Aussie-bloke-wakes-wife-let-know-theyd-just-won-1-7million-TattsLotto.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556319/Hardworking-Aussie-bloke-wakes-wife-let-know-theyd-just-won-1-7million-TattsLotto.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:43:21+00:00

A Victoria man has admitted to waking his wife up from a peaceful slumber in the early hours of the morning to reveal their life-changing $1.7 million win in the weekend's TattsLotto.

## New development after Northern Territory leader was allegedly pied in the face with a cream pancake
 - [https://www.dailymail.co.uk/news/article-12556245/Northern-Territory-Natasha-Fyles-cream-pie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556245/Northern-Territory-Natasha-Fyles-cream-pie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:42:40+00:00

A woman has been charged over the alleged cream pie attack on  Northern Territory Chief Minister Natasha Fyles.

## Septembare! 1,300 naked swimmers brave chilly North Sea at sunrise for the 11th annual North East Skinny Dip to mark the Autumn Equinox
 - [https://www.dailymail.co.uk/news/article-12556127/11th-annual-North-East-Skinny-Dip-Autumn-Equinox.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556127/11th-annual-North-East-Skinny-Dip-Autumn-Equinox.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:41:32+00:00

Naked participants of all ages could be seen frolicking on the beach on Sunday in Druridge Bay for the popular event organised by mental health charity, Mind.

## Burger Head closes: Owners of Sydney chain make shock announcement
 - [https://www.dailymail.co.uk/news/article-12556283/Burger-Head-closes-Owners-Sydney-chain-make-shock-announcement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556283/Burger-Head-closes-Owners-Sydney-chain-make-shock-announcement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:40:05+00:00

Sydney-based chain Burger Head will will close its remaining restaurants in Penrith and Botany on October 29.

## Revealed: Marcus Rashford crashed his £700k Range Rover into car being driven by 74-year-old grandmother - who he 'immediately checked was okay before swapping details'
 - [https://www.dailymail.co.uk/news/article-12555975/Marcus-Rashford-crashed-Range-Rover-driven-grandmother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12555975/Marcus-Rashford-crashed-Range-Rover-driven-grandmother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:39:11+00:00

The football star crashed his swanky car outside Manchester United's Carrington training ground at around midnight last Saturday. It his a 74-year-old woman's car.

## Pictured: King's College gynaecologist who died on BA flight from London to Nice 'in her sleep' next to her husband - as 73-year-old's family lead tributes to 'pioneer' and 'popular' academic
 - [https://www.dailymail.co.uk/news/article-12556133/Pictured-Kings-College-gynaecologist-Linda-Cardozo-died-BA-flight-London-Nice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556133/Pictured-Kings-College-gynaecologist-Linda-Cardozo-died-BA-flight-London-Nice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:38:29+00:00

Professor Linda Cardozo tragically passed away while on a flight from London to Nice on Thursday night, just a week after celebrating her 73rd birthday.

## Daughter of homeless Florida woman eaten by 14-foot alligator insists she 'did not TAUNT' the beast before it dragged her into a canal - and says it attacked her from the creek when she was walking to her camp in the dark
 - [https://www.dailymail.co.uk/news/article-12556141/Daughter-homeless-Florida-woman-eaten-14-foot-alligator-insists-did-not-TAUNT-beast-dragged-canal-says-attacked-creek-walking-camp-dark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556141/Daughter-homeless-Florida-woman-eaten-14-foot-alligator-insists-did-not-TAUNT-beast-dragged-canal-says-attacked-creek-walking-camp-dark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:32:46+00:00

Sabrina Peckham, 41, was eaten by the alligator after being dragged around by the 14-foot beast into a canal on Friday in Largo, Clearwater, Florida.

## Scottish Greens co-leader Patrick Harvie refuses to condemn extremist climate protesters who break the law when causing disruption
 - [https://www.dailymail.co.uk/news/article-12556291/Scottish-Greens-leader-Patrick-Harvie-refuses-condemn-extremist-climate-protesters-break-law-causing-disruption.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556291/Scottish-Greens-leader-Patrick-Harvie-refuses-condemn-extremist-climate-protesters-break-law-causing-disruption.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:30:41+00:00

Patrick Harvie, the Scottish Greens co-leader and Minister for Zero Carbon Buildings, came under fire for 'disgraceful' comments after he refused to urge activists not to break the law.

## Buying ready meals is more expensive than cooking the same thing at home, study finds
 - [https://www.dailymail.co.uk/news/article-12556281/Buying-ready-meals-expensive-cooking-thing-home-study-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556281/Buying-ready-meals-expensive-cooking-thing-home-study-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:27:40+00:00

Ready meals from all leading supermarkets were 30 pence more expensive per 100 grams on average - which works out as about £1 more expensive per person for a meal portion.

## Dad's heartbreak after little boy's tragic death when mum initially blamed him: 'I gave him life and I took it'
 - [https://www.dailymail.co.uk/news/article-12555953/Dads-heartbreak-little-boys-tragic-death-mum-initially-blamed-gave-life-took-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12555953/Dads-heartbreak-little-boys-tragic-death-mum-initially-blamed-gave-life-took-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:23:20+00:00

Mum's young son tragically lost his life in a horrifying accident. Initially, she found herself pointing the finger at her partner as the cause.

## Questions over Gary Lineker's future with Walkers Crisps after Match of the Day star did NOT star in latest TV ad
 - [https://www.dailymail.co.uk/news/article-12556077/Gary-Linekers-future-Walkers-Crisps-NOT-star-latest-TV-ad.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556077/Gary-Linekers-future-Walkers-Crisps-NOT-star-latest-TV-ad.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:23:17+00:00

The 62-year-old, who first appeared in commercials for the Leicester-based company in 1995, was nowhere to be seen in its latest advertisement which was released this month.

## One million crimes go unsolved in 'Blue Wall' constituencies in southern England with no suspect identified in half of recorded crimes in some areas
 - [https://www.dailymail.co.uk/news/article-12556201/One-million-crimes-unsolved-Blue-Wall-constituencies-southern-England-no-suspect-identified-half-recorded-crimes-areas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556201/One-million-crimes-unsolved-Blue-Wall-constituencies-southern-England-no-suspect-identified-half-recorded-crimes-areas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:22:02+00:00

Four of the five worst-performing police forces for attending car thefts are in the Blue Wall, defined as 14 constituencies in the south of England traditionally held by the Conservatives.

## Rishi Sunak to use his 60-seat majority in Parliament to scrap green planning rules in a bid to build 100,000 new homes despite being blocked by the House of Lords
 - [https://www.dailymail.co.uk/news/article-12556181/Rishi-Sunak-parliament-housing-supply-green-planning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556181/Rishi-Sunak-parliament-housing-supply-green-planning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:20:04+00:00

The Prime Minister is 'absolutely determined' to scrap the 'nutrient neutrality' regulations, which officials say are blocking crucial construction during a housing supply crisis.

## More than one million NHS appointments are cancelled because of strikes in England in 'damaging and demoralising' milestone
 - [https://www.dailymail.co.uk/news/article-12556081/More-one-million-NHS-appointments-cancelled-strikes-England-damaging-demoralising-milestone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556081/More-one-million-NHS-appointments-cancelled-strikes-England-damaging-demoralising-milestone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:19:12+00:00

The number of NHS appointments cancelled because of strikes in England is expected to surpass one million today, with health bosses warning of the 'distress' caused to patients.

## My secret to looking this good at 47? Marry a younger man - and ditch the make-up! TV presenter EMMA WILLIS opens up on beating perimenopausal brain fog and the daily challenge of being married to a pop star former addict
 - [https://www.dailymail.co.uk/femail/article-12545909/My-secret-looking-good-47-Marry-younger-man-ditch-make-TV-presenter-EMMA-WILLIS-opens-beating-perimenopausal-brain-fog-daily-challenge-married-pop-star-former-addict.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12545909/My-secret-looking-good-47-Marry-younger-man-ditch-make-TV-presenter-EMMA-WILLIS-opens-beating-perimenopausal-brain-fog-daily-challenge-married-pop-star-former-addict.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:18:13+00:00

Emma Willis thinks she may have cracked the secret to looking (and feeling) youthful, even when you're peri-menopausal. The answer? Marry someone seven years your junior.

## DR MAX PEMBERTON: Sometimes a stiff upper lip IS better than raking up the past
 - [https://www.dailymail.co.uk/femail/article-12555265/DR-MAX-PEMBERTON-stiff-upper-lip-better-raking-past.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12555265/DR-MAX-PEMBERTON-stiff-upper-lip-better-raking-past.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:14:51+00:00

DR MAX PEMBERTON: These days everyone is encouraged to talk about their problems. But it's a balancing act between being open and honest about your feelings and yet not giving in to them.

## The seven mid-life sex questions you don't dare ask... answered by a top therapist
 - [https://www.dailymail.co.uk/femail/article-12555271/The-seven-mid-life-sex-questions-dont-dare-ask-answered-therapist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12555271/The-seven-mid-life-sex-questions-dont-dare-ask-answered-therapist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:13:18+00:00

Kate Moyle has helped hundreds of couples to improve their sex lives - most often through better communication. Here, she reveals tried and tested solutions to the most common difficulties.

## The one lesson Gyles Brandreth has learned from life: Busy people are happy people
 - [https://www.dailymail.co.uk/femail/article-12555255/The-one-lesson-Gyles-Brandreth-learned-life-Busy-people-happy-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12555255/The-one-lesson-Gyles-Brandreth-learned-life-Busy-people-happy-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:12:05+00:00

Broadcaster, writer and former politician Gyles Brandreth, 75, is a regular on Radio 4's Just A Minute and famed for his colourful sweaters on TV. He is currently touring his one-man show.

## Michael Pezzullo's texts about Julie Bishop and Marise Payne exposed
 - [https://www.dailymail.co.uk/news/article-12556125/Michael-Pezzullos-texts-Julie-Bishop-Marise-Payne-exposed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12556125/Michael-Pezzullos-texts-Julie-Bishop-Marise-Payne-exposed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:11:06+00:00

Mike Pezzullo has been referred to the Australian Public Service Commissioner, accused of inappropriately trying to influence the Liberal Party.

## Can Boots No.7's new super serum cure my problem skin? We test the latest long-awaited range ahead of this week's launch...
 - [https://www.dailymail.co.uk/femail/article-12555259/Can-Boots-No-7s-new-super-serum-cure-problem-skin-test-latest-long-awaited-range-ahead-weeks-launch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12555259/Can-Boots-No-7s-new-super-serum-cure-problem-skin-test-latest-long-awaited-range-ahead-weeks-launch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:10:46+00:00

Launching on Wednesday, the long-awaited No. 7 Derm Solutions range by Boots consists of six core 'cosmetic' products which, No.7 claims, can repair and maintain the skin's barrier in four weeks.

## ANDREW PIERCE: Tree-hugger tycoon who lambasted Rishi Sunak over his rethink of Net Zero pledges 'flew 125 flights in a year'
 - [https://www.dailymail.co.uk/debate/article-12555743/ANDREW-PIERCE-Tree-hugger-tycoon-Rishi-Sunak-rethink-Net-Zero-flew-125-flights-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-12555743/ANDREW-PIERCE-Tree-hugger-tycoon-Rishi-Sunak-rethink-Net-Zero-flew-125-flights-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-09-25T00:05:08+00:00

ANDREW PIERCE: Among the eco-zealots who lambasted Rishi Sunak last week over his welcome rethink of net-zero pledges was City tycoon Peter Hughes (pictured).

