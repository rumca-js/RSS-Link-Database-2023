# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Rich Sutton joins John Carmack's Keen Technologies
 - [https://twitter.com/ID_AA_Carmack/status/1706420064956661867](https://twitter.com/ID_AA_Carmack/status/1706420064956661867)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T22:23:23+00:00

<p>Article URL: <a href="https://twitter.com/ID_AA_Carmack/status/1706420064956661867">https://twitter.com/ID_AA_Carmack/status/1706420064956661867</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37651548">https://news.ycombinator.com/item?id=37651548</a></p>
<p>Points: 34</p>
<p># Comments: 7</p>

## Is Math Real?
 - [https://maa.org/press/maa-reviews/is-math-real](https://maa.org/press/maa-reviews/is-math-real)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T21:55:07+00:00

<p>Article URL: <a href="https://maa.org/press/maa-reviews/is-math-real">https://maa.org/press/maa-reviews/is-math-real</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37651260">https://news.ycombinator.com/item?id=37651260</a></p>
<p>Points: 17</p>
<p># Comments: 14</p>

## The SR-71 Blackbird Astro-Nav System worked by tracking the stars
 - [https://theaviationgeekclub.com/the-sr-71-blackbird-astro-nav-system-aka-r2-d2-worked-by-tracking-the-stars-and-was-so-powerful-that-it-could-see-the-stars-even-in-daylight/](https://theaviationgeekclub.com/the-sr-71-blackbird-astro-nav-system-aka-r2-d2-worked-by-tracking-the-stars-and-was-so-powerful-that-it-could-see-the-stars-even-in-daylight/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T21:47:42+00:00

<p>Article URL: <a href="https://theaviationgeekclub.com/the-sr-71-blackbird-astro-nav-system-aka-r2-d2-worked-by-tracking-the-stars-and-was-so-powerful-that-it-could-see-the-stars-even-in-daylight/">https://theaviationgeekclub.com/the-sr-71-blackbird-astro-nav-system-aka-r2-d2-worked-by-tracking-the-stars-and-was-so-powerful-that-it-could-see-the-stars-even-in-daylight/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37651171">https://news.ycombinator.com/item?id=37651171</a></p>
<p>Points: 67</p>
<p># Comments: 44</p>

## Fat Men's Clubs (2016)
 - [https://www.npr.org/sections/thesalt/2016/03/07/469571114/the-forgotten-history-of-fat-men-s-clubs](https://www.npr.org/sections/thesalt/2016/03/07/469571114/the-forgotten-history-of-fat-men-s-clubs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T21:37:41+00:00

<p>Article URL: <a href="https://www.npr.org/sections/thesalt/2016/03/07/469571114/the-forgotten-history-of-fat-men-s-clubs">https://www.npr.org/sections/thesalt/2016/03/07/469571114/the-forgotten-history-of-fat-men-s-clubs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37651048">https://news.ycombinator.com/item?id=37651048</a></p>
<p>Points: 19</p>
<p># Comments: 3</p>

## How Much Does It Take to Be the Top% in Each U.S. State?
 - [https://www.visualcapitalist.com/mapped-the-top-1-percent-in-each-u-s-state/](https://www.visualcapitalist.com/mapped-the-top-1-percent-in-each-u-s-state/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T20:58:42+00:00

<p>Article URL: <a href="https://www.visualcapitalist.com/mapped-the-top-1-percent-in-each-u-s-state/">https://www.visualcapitalist.com/mapped-the-top-1-percent-in-each-u-s-state/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37650509">https://news.ycombinator.com/item?id=37650509</a></p>
<p>Points: 10</p>
<p># Comments: 4</p>

## PostScript’s sudden death in Sonoma
 - [https://eclecticlight.co/2023/09/25/postscripts-sudden-death-in-sonoma/](https://eclecticlight.co/2023/09/25/postscripts-sudden-death-in-sonoma/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T20:20:55+00:00

<p>Article URL: <a href="https://eclecticlight.co/2023/09/25/postscripts-sudden-death-in-sonoma/">https://eclecticlight.co/2023/09/25/postscripts-sudden-death-in-sonoma/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37650040">https://news.ycombinator.com/item?id=37650040</a></p>
<p>Points: 34</p>
<p># Comments: 2</p>

## Study links blue light from smartphones or tablets to early puberty
 - [https://medicalxpress.com/news/2023-09-links-blue-smartphones-tablets-early.html](https://medicalxpress.com/news/2023-09-links-blue-smartphones-tablets-early.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T20:20:22+00:00

<p>Article URL: <a href="https://medicalxpress.com/news/2023-09-links-blue-smartphones-tablets-early.html">https://medicalxpress.com/news/2023-09-links-blue-smartphones-tablets-early.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37650032">https://news.ycombinator.com/item?id=37650032</a></p>
<p>Points: 19</p>
<p># Comments: 12</p>

## Pixel 8 leak promises 7 years of OS updates
 - [https://arstechnica.com/gadgets/2023/09/pixel-8-leak-promises-7-years-of-os-updates-even-more-than-an-iphone/](https://arstechnica.com/gadgets/2023/09/pixel-8-leak-promises-7-years-of-os-updates-even-more-than-an-iphone/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T20:07:43+00:00

<p>Article URL: <a href="https://arstechnica.com/gadgets/2023/09/pixel-8-leak-promises-7-years-of-os-updates-even-more-than-an-iphone/">https://arstechnica.com/gadgets/2023/09/pixel-8-leak-promises-7-years-of-os-updates-even-more-than-an-iphone/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37649841">https://news.ycombinator.com/item?id=37649841</a></p>
<p>Points: 19</p>
<p># Comments: 6</p>

## Show HN: Bigcapital - A open-source alternative to QuickBooks
 - [https://github.com/bigcapitalhq/bigcapital](https://github.com/bigcapitalhq/bigcapital)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T20:05:45+00:00

<p>Article URL: <a href="https://github.com/bigcapitalhq/bigcapital">https://github.com/bigcapitalhq/bigcapital</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37649811">https://news.ycombinator.com/item?id=37649811</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## John Romero on his book “Doom Guy” and developing games at a small scale
 - [https://howtomarketagame.com/2023/09/25/john-romero-on-his-book-doom-guy-and-developing-games-at-a-small-scale/](https://howtomarketagame.com/2023/09/25/john-romero-on-his-book-doom-guy-and-developing-games-at-a-small-scale/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T19:50:03+00:00

<p>Article URL: <a href="https://howtomarketagame.com/2023/09/25/john-romero-on-his-book-doom-guy-and-developing-games-at-a-small-scale/">https://howtomarketagame.com/2023/09/25/john-romero-on-his-book-doom-guy-and-developing-games-at-a-small-scale/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37649594">https://news.ycombinator.com/item?id=37649594</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Customization for the Forensic Police (2018)
 - [http://www.sweethome3d.com/blog/2018/12/10/customization_for_the_forensic_police.html](http://www.sweethome3d.com/blog/2018/12/10/customization_for_the_forensic_police.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T19:42:53+00:00

<p>Article URL: <a href="http://www.sweethome3d.com/blog/2018/12/10/customization_for_the_forensic_police.html">http://www.sweethome3d.com/blog/2018/12/10/customization_for_the_forensic_police.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37649477">https://news.ycombinator.com/item?id=37649477</a></p>
<p>Points: 28</p>
<p># Comments: 1</p>

## DJI Mini 4 Pro
 - [https://www.dji.com/mini-4-pro](https://www.dji.com/mini-4-pro)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T19:40:54+00:00

<p>Article URL: <a href="https://www.dji.com/mini-4-pro">https://www.dji.com/mini-4-pro</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37649448">https://news.ycombinator.com/item?id=37649448</a></p>
<p>Points: 43</p>
<p># Comments: 38</p>

## F-35A has flown from a highway for the first time
 - [https://www.thedrive.com/the-war-zone/f-35a-has-flown-from-a-highway-for-the-first-time](https://www.thedrive.com/the-war-zone/f-35a-has-flown-from-a-highway-for-the-first-time)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T19:34:11+00:00

<p>Article URL: <a href="https://www.thedrive.com/the-war-zone/f-35a-has-flown-from-a-highway-for-the-first-time">https://www.thedrive.com/the-war-zone/f-35a-has-flown-from-a-highway-for-the-first-time</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37649353">https://news.ycombinator.com/item?id=37649353</a></p>
<p>Points: 21</p>
<p># Comments: 31</p>

## Mixin suspends deposits and withdrawals after $200M cryptocurrency heist
 - [https://www.theregister.com/2023/09/25/mixin_200m_heist/](https://www.theregister.com/2023/09/25/mixin_200m_heist/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T19:31:23+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/09/25/mixin_200m_heist/">https://www.theregister.com/2023/09/25/mixin_200m_heist/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37649307">https://news.ycombinator.com/item?id=37649307</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## US Government IT contractor could face death penalty over espionage charges
 - [https://www.itpro.com/security/us-government-it-contractor-could-face-death-penalty-over-espionage-charges](https://www.itpro.com/security/us-government-it-contractor-could-face-death-penalty-over-espionage-charges)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T19:18:24+00:00

<p>Article URL: <a href="https://www.itpro.com/security/us-government-it-contractor-could-face-death-penalty-over-espionage-charges">https://www.itpro.com/security/us-government-it-contractor-could-face-death-penalty-over-espionage-charges</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37649114">https://news.ycombinator.com/item?id=37649114</a></p>
<p>Points: 46</p>
<p># Comments: 36</p>

## Reclaim the Internet with Mozilla
 - [https://blog.mozilla.org/en/mozilla/reclaim-the-internet/](https://blog.mozilla.org/en/mozilla/reclaim-the-internet/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T18:58:44+00:00

<p>Article URL: <a href="https://blog.mozilla.org/en/mozilla/reclaim-the-internet/">https://blog.mozilla.org/en/mozilla/reclaim-the-internet/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37648833">https://news.ycombinator.com/item?id=37648833</a></p>
<p>Points: 29</p>
<p># Comments: 23</p>

## Linux from Scratch Version 12.0
 - [https://www.linuxfromscratch.org/lfs/view/stable/](https://www.linuxfromscratch.org/lfs/view/stable/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T18:56:58+00:00

<p>Article URL: <a href="https://www.linuxfromscratch.org/lfs/view/stable/">https://www.linuxfromscratch.org/lfs/view/stable/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37648808">https://news.ycombinator.com/item?id=37648808</a></p>
<p>Points: 54</p>
<p># Comments: 9</p>

## Another Text to Speech API
 - [https://www.fluxon.ai/](https://www.fluxon.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T18:38:08+00:00

<p>Article URL: <a href="https://www.fluxon.ai/">https://www.fluxon.ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37648548">https://news.ycombinator.com/item?id=37648548</a></p>
<p>Points: 14</p>
<p># Comments: 7</p>

## Show HN: A Highly Configurable Linux-Based Desktop Notifier for RSS/Atom Feeds
 - [https://github.com/EscherMoore/DitchTheBell](https://github.com/EscherMoore/DitchTheBell)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T18:28:13+00:00

<p>Ditch The Bell is a desktop notifier for RSS/Atom feeds that lets you closely configure features of the freedesktop notification specification to unlock the most customizable feed notification experience possible on Linux.<p>I developed this program because I wanted a single, centralized location to easily manage my desktop notifications for all of the various websites I want to get updates from. Before creating this application, I found existing solutions unsatisfactory due to the following reasons:<p>- Built-In Notification Services: Some websites offer built-in desktop notification services, but these often require an account, staying signed in, and running a browser service worker continuously on your PC.<p>- RSS Readers: While existing RSS readers with notification support provide a simple solution, these project balance numerous aspects of reader development. Notifications and their configurations are usually not the priority in these projects.<p>- Custom Scripting: Implemen

## California governor vetoes bill to require human operators in autonomous trucks
 - [https://www.engadget.com/california-governor-vetoes-bill-for-obligatory-human-operators-in-autonomous-trucks-170051289.html](https://www.engadget.com/california-governor-vetoes-bill-for-obligatory-human-operators-in-autonomous-trucks-170051289.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T18:20:22+00:00

<p>Article URL: <a href="https://www.engadget.com/california-governor-vetoes-bill-for-obligatory-human-operators-in-autonomous-trucks-170051289.html">https://www.engadget.com/california-governor-vetoes-bill-for-obligatory-human-operators-in-autonomous-trucks-170051289.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37648288">https://news.ycombinator.com/item?id=37648288</a></p>
<p>Points: 33</p>
<p># Comments: 37</p>

## Show HN: Minum – A minimal Java web framework
 - [https://github.com/byronka/minum](https://github.com/byronka/minum)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T18:07:24+00:00

<p>I am happy to announce my minimalist zero-dependency web framework, Minum, is out of beta.<p><a href="http://github.com/byronka/minum">http://github.com/byronka/minum</a><p>You will be hard-pressed to find another modern project as obsessively minimalistic.  Other frameworks will claim simplicity and minimalism and then, casually, mention they are built on a multitude of libraries. This follows self-imposed constraints, predicated on a belief that smaller and lighter is long-term better.<p>Caveat emptor: This is a project by and for developers who know and like programming (rather than, let us say, configuring).  It is written in Java, and presumes familiarity with the HTTP/HTML paradigm.<p>Driving paradigms of this project:<p>* ease of use
* maintainability / sustainability
* simplicity
* performance
* good documentation
* good testing<p>It requires Java 21, for its virtual threads (Project Loom)</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37648098">

## Unity's oldest community announces dissolution
 - [https://bostonunitygroup.s3.us-east-1.amazonaws.com/index.html](https://bostonunitygroup.s3.us-east-1.amazonaws.com/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T18:05:07+00:00

<p>Article URL: <a href="https://bostonunitygroup.s3.us-east-1.amazonaws.com/index.html">https://bostonunitygroup.s3.us-east-1.amazonaws.com/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37648068">https://news.ycombinator.com/item?id=37648068</a></p>
<p>Points: 17</p>
<p># Comments: 0</p>

## Unity's oldest community announces dissolution
 - [http://farewell.bostonunitygroup.com/](http://farewell.bostonunitygroup.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T18:05:07+00:00

<p>Article URL: <a href="http://farewell.bostonunitygroup.com/">http://farewell.bostonunitygroup.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37648068">https://news.ycombinator.com/item?id=37648068</a></p>
<p>Points: 153</p>
<p># Comments: 97</p>

## Intel Axes Data Center GPU Max 1350, Preps New Max 1450 for 'Different Markets'
 - [https://www.tomshardware.com/news/intel-axes-data-center-gpu-max-1350-preps-max-1450-for-different-markets](https://www.tomshardware.com/news/intel-axes-data-center-gpu-max-1350-preps-max-1450-for-different-markets)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T17:38:46+00:00

<p>Article URL: <a href="https://www.tomshardware.com/news/intel-axes-data-center-gpu-max-1350-preps-max-1450-for-different-markets">https://www.tomshardware.com/news/intel-axes-data-center-gpu-max-1350-preps-max-1450-for-different-markets</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37647677">https://news.ycombinator.com/item?id=37647677</a></p>
<p>Points: 7</p>
<p># Comments: 3</p>

## Dots (YC S21) Is Hiring for Founding Full-Stack Eningeers
 - [https://www.ycombinator.com/companies/dots-2/jobs](https://www.ycombinator.com/companies/dots-2/jobs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T17:00:43+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/dots-2/jobs">https://www.ycombinator.com/companies/dots-2/jobs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37647053">https://news.ycombinator.com/item?id=37647053</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Ian's Shoelace Site
 - [https://www.fieggen.com/shoelace/](https://www.fieggen.com/shoelace/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T16:55:54+00:00

<p>Article URL: <a href="https://www.fieggen.com/shoelace/">https://www.fieggen.com/shoelace/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37646964">https://news.ycombinator.com/item?id=37646964</a></p>
<p>Points: 28</p>
<p># Comments: 2</p>

## Elicit – LLMs to Accelerate Research
 - [https://substack.fiftyyears.com/p/elicit](https://substack.fiftyyears.com/p/elicit)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T16:29:19+00:00

<p>Article URL: <a href="https://substack.fiftyyears.com/p/elicit">https://substack.fiftyyears.com/p/elicit</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37646508">https://news.ycombinator.com/item?id=37646508</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## How We Made PostgreSQL a Better Vector Database
 - [https://www.timescale.com/blog/how-we-made-postgresql-the-best-vector-database/](https://www.timescale.com/blog/how-we-made-postgresql-the-best-vector-database/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T16:27:29+00:00

<p>Article URL: <a href="https://www.timescale.com/blog/how-we-made-postgresql-the-best-vector-database/">https://www.timescale.com/blog/how-we-made-postgresql-the-best-vector-database/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37646472">https://news.ycombinator.com/item?id=37646472</a></p>
<p>Points: 33</p>
<p># Comments: 3</p>

## Show HN: Generate a concatenated file of all CSS used on a given website
 - [https://mikaei.github.io/mouthful/](https://mikaei.github.io/mouthful/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T16:14:10+00:00

<p>Article URL: <a href="https://mikaei.github.io/mouthful/">https://mikaei.github.io/mouthful/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37646257">https://news.ycombinator.com/item?id=37646257</a></p>
<p>Points: 11</p>
<p># Comments: 4</p>

## Copyright liability for generative AI pivots on fair use doctrine
 - [https://news.bloomberglaw.com/us-law-week/copyright-liability-for-generative-ai-pivots-on-fair-use-doctrine](https://news.bloomberglaw.com/us-law-week/copyright-liability-for-generative-ai-pivots-on-fair-use-doctrine)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T15:57:24+00:00

<p>Article URL: <a href="https://news.bloomberglaw.com/us-law-week/copyright-liability-for-generative-ai-pivots-on-fair-use-doctrine">https://news.bloomberglaw.com/us-law-week/copyright-liability-for-generative-ai-pivots-on-fair-use-doctrine</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37645974">https://news.ycombinator.com/item?id=37645974</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Saint Helena Island Communications
 - [http://sainthelenaisland.info/communications.htm](http://sainthelenaisland.info/communications.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T15:55:44+00:00

<p>Article URL: <a href="http://sainthelenaisland.info/communications.htm">http://sainthelenaisland.info/communications.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37645945">https://news.ycombinator.com/item?id=37645945</a></p>
<p>Points: 13</p>
<p># Comments: 5</p>

## GitHub Passkeys are generally available
 - [https://github.blog/2023-09-21-passkeys-are-generally-available/](https://github.blog/2023-09-21-passkeys-are-generally-available/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T15:53:11+00:00

<p>Article URL: <a href="https://github.blog/2023-09-21-passkeys-are-generally-available/">https://github.blog/2023-09-21-passkeys-are-generally-available/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37645896">https://news.ycombinator.com/item?id=37645896</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## California workers who cut countertops are dying of an incurable disease
 - [https://www.latimes.com/california/story/2023-09-24/silicosis-countertop-workers-engineered-stone](https://www.latimes.com/california/story/2023-09-24/silicosis-countertop-workers-engineered-stone)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T15:50:00+00:00

<p>Article URL: <a href="https://www.latimes.com/california/story/2023-09-24/silicosis-countertop-workers-engineered-stone">https://www.latimes.com/california/story/2023-09-24/silicosis-countertop-workers-engineered-stone</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37645829">https://news.ycombinator.com/item?id=37645829</a></p>
<p>Points: 29</p>
<p># Comments: 3</p>

## JDK 21 Security Enhancements
 - [https://seanjmullan.org/blog/2023/09/22/jdk21](https://seanjmullan.org/blog/2023/09/22/jdk21)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T15:35:41+00:00

<p>Article URL: <a href="https://seanjmullan.org/blog/2023/09/22/jdk21">https://seanjmullan.org/blog/2023/09/22/jdk21</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37645550">https://news.ycombinator.com/item?id=37645550</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## It's time to let go, Apache Software Foundation
 - [https://rocket9labs.com/post/its-time-to-let-go-apache-software-foundation/](https://rocket9labs.com/post/its-time-to-let-go-apache-software-foundation/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T15:12:26+00:00

<p>Article URL: <a href="https://rocket9labs.com/post/its-time-to-let-go-apache-software-foundation/">https://rocket9labs.com/post/its-time-to-let-go-apache-software-foundation/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37645160">https://news.ycombinator.com/item?id=37645160</a></p>
<p>Points: 110</p>
<p># Comments: 42</p>

## KSP2 is spamming the Windows Registry until the game stops working permanently
 - [https://forum.kerbalspaceprogram.com/topic/219607-ksp2-is-spamming-the-windows-registry-over-weeksmonths-until-the-game-will-stop-working-permanently/](https://forum.kerbalspaceprogram.com/topic/219607-ksp2-is-spamming-the-windows-registry-over-weeksmonths-until-the-game-will-stop-working-permanently/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T15:00:33+00:00

<p>Article URL: <a href="https://forum.kerbalspaceprogram.com/topic/219607-ksp2-is-spamming-the-windows-registry-over-weeksmonths-until-the-game-will-stop-working-permanently/">https://forum.kerbalspaceprogram.com/topic/219607-ksp2-is-spamming-the-windows-registry-over-weeksmonths-until-the-game-will-stop-working-permanently/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37644952">https://news.ycombinator.com/item?id=37644952</a></p>
<p>Points: 120</p>
<p># Comments: 65</p>

## Meta and Salesforce are looking to re-hire some workers they just laid off
 - [https://www.businessinsider.com/salesforce-meta-big-tech-companies-rehire-workers-employees-laid-off-2023-9](https://www.businessinsider.com/salesforce-meta-big-tech-companies-rehire-workers-employees-laid-off-2023-9)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T14:53:39+00:00

<p>Article URL: <a href="https://www.businessinsider.com/salesforce-meta-big-tech-companies-rehire-workers-employees-laid-off-2023-9">https://www.businessinsider.com/salesforce-meta-big-tech-companies-rehire-workers-employees-laid-off-2023-9</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37644831">https://news.ycombinator.com/item?id=37644831</a></p>
<p>Points: 37</p>
<p># Comments: 36</p>

## Review of MDMA and the Quest for Connection in a Fractured World
 - [https://undark.org/2023/09/22/book-review-the-long-strange-history-of-mdma/](https://undark.org/2023/09/22/book-review-the-long-strange-history-of-mdma/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T14:36:11+00:00

<p>Article URL: <a href="https://undark.org/2023/09/22/book-review-the-long-strange-history-of-mdma/">https://undark.org/2023/09/22/book-review-the-long-strange-history-of-mdma/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37644506">https://news.ycombinator.com/item?id=37644506</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Minecraft Wiki has forked from Fandom
 - [https://minecraft.wiki/w/Minecraft_Wiki:Moving_from_Fandom](https://minecraft.wiki/w/Minecraft_Wiki:Moving_from_Fandom)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T14:10:15+00:00

<p>Article URL: <a href="https://minecraft.wiki/w/Minecraft_Wiki:Moving_from_Fandom">https://minecraft.wiki/w/Minecraft_Wiki:Moving_from_Fandom</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37644047">https://news.ycombinator.com/item?id=37644047</a></p>
<p>Points: 48</p>
<p># Comments: 14</p>

## What was behind Microsoft's layoffs of over 20k people in the last year?
 - [https://twitter.com/TeamBlind/status/1706266044871086271](https://twitter.com/TeamBlind/status/1706266044871086271)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T13:38:30+00:00

<p>Article URL: <a href="https://twitter.com/TeamBlind/status/1706266044871086271">https://twitter.com/TeamBlind/status/1706266044871086271</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37643608">https://news.ycombinator.com/item?id=37643608</a></p>
<p>Points: 26</p>
<p># Comments: 10</p>

## Car industry pleads for delay to post-Brexit tariffs on EVs
 - [https://www.theregister.com/2023/09/25/car_industry_brexit_tariff/](https://www.theregister.com/2023/09/25/car_industry_brexit_tariff/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T13:26:15+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/09/25/car_industry_brexit_tariff/">https://www.theregister.com/2023/09/25/car_industry_brexit_tariff/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37643414">https://news.ycombinator.com/item?id=37643414</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## 2024 Nissan Kicks Is the Kind of Car We Need More Of: Affordable
 - [https://www.thedrive.com/news/2024-nissan-kicks-is-the-kind-of-car-we-need-more-of-affordable](https://www.thedrive.com/news/2024-nissan-kicks-is-the-kind-of-car-we-need-more-of-affordable)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T13:06:44+00:00

<p>Article URL: <a href="https://www.thedrive.com/news/2024-nissan-kicks-is-the-kind-of-car-we-need-more-of-affordable">https://www.thedrive.com/news/2024-nissan-kicks-is-the-kind-of-car-we-need-more-of-affordable</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37643139">https://news.ycombinator.com/item?id=37643139</a></p>
<p>Points: 34</p>
<p># Comments: 24</p>

## Show HN: KitForStartups – The Open Source SvelteKit SaaS Boilerplate
 - [https://github.com/okupter/kitforstartups](https://github.com/okupter/kitforstartups)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T12:51:24+00:00

<p>This is a project I’ve been working on for a couple of weeks now, and I feel it’s now in a state I can share it with the community here on Discord.<p>It all started when I saw Marc Lou launched ShipFast (a paid Next.js startup boilerplate). I wanted to build something similar for SvelteKit. I was planning to make it a paid product, but ended up open sourcing it.<p>You can see KitForStartups as a toolkit you can use to prototype and ship faster your MVPs, web applications, etc.<p>It comes with support for many databases (SQLite w/Turso, MySQL and Postgres), authentication (email + password, OAuth with Google and GitHub), email sending with Resend (local emails are configured to be sent with MailHog for faster debugging), toast notifications with Melt UI, etc…<p>I’m still actively working on the project and on things like support for Supabase, magic link authentication, MailGun, a CLI, etc…<p>Give a look at the repo here <a href="https://github.com/okupter/kitforstartups">https://gi

## GPT-4V(ision) system card [pdf]
 - [https://cdn.openai.com/papers/GPTV_System_Card.pdf](https://cdn.openai.com/papers/GPTV_System_Card.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T12:35:12+00:00

<p>Article URL: <a href="https://cdn.openai.com/papers/GPTV_System_Card.pdf">https://cdn.openai.com/papers/GPTV_System_Card.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37642712">https://news.ycombinator.com/item?id=37642712</a></p>
<p>Points: 25</p>
<p># Comments: 5</p>

## Show HN: E-Ink Day Schedule
 - [https://github.com/davidhampgonsalves/life-dashboard](https://github.com/davidhampgonsalves/life-dashboard)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T12:31:07+00:00

<p>Article URL: <a href="https://github.com/davidhampgonsalves/life-dashboard">https://github.com/davidhampgonsalves/life-dashboard</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37642671">https://news.ycombinator.com/item?id=37642671</a></p>
<p>Points: 22</p>
<p># Comments: 6</p>

## Rhythm 0
 - [https://en.wikipedia.org/wiki/Rhythm_0](https://en.wikipedia.org/wiki/Rhythm_0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T12:26:24+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Rhythm_0">https://en.wikipedia.org/wiki/Rhythm_0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37642610">https://news.ycombinator.com/item?id=37642610</a></p>
<p>Points: 61</p>
<p># Comments: 23</p>

## Optery (YC W22) – Full Stack Developer with Node.js Experience (Remote and Israel)
 - [https://optery.breezy.hr/p/a95772ba7d2b-full-stack-developer-nodejs](https://optery.breezy.hr/p/a95772ba7d2b-full-stack-developer-nodejs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T12:00:22+00:00

<p>Article URL: <a href="https://optery.breezy.hr/p/a95772ba7d2b-full-stack-developer-nodejs">https://optery.breezy.hr/p/a95772ba7d2b-full-stack-developer-nodejs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37642361">https://news.ycombinator.com/item?id=37642361</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## ChatGPT can now see, hear, and speak – openai.com
 - [https://openai.com/blog/chatgpt-can-now-see-hear-and-speak](https://openai.com/blog/chatgpt-can-now-see-hear-and-speak)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T11:57:28+00:00

<p>Article URL: <a href="https://openai.com/blog/chatgpt-can-now-see-hear-and-speak">https://openai.com/blog/chatgpt-can-now-see-hear-and-speak</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37642335">https://news.ycombinator.com/item?id=37642335</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Lego axes plan to make bricks from recycled bottles
 - [https://www.bbc.com/news/business-66910573](https://www.bbc.com/news/business-66910573)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T11:28:20+00:00

<p>Article URL: <a href="https://www.bbc.com/news/business-66910573">https://www.bbc.com/news/business-66910573</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37642110">https://news.ycombinator.com/item?id=37642110</a></p>
<p>Points: 14</p>
<p># Comments: 18</p>

## Running_page
 - [https://github.com/yihong0618/running_page](https://github.com/yihong0618/running_page)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T11:18:19+00:00

<p>Article URL: <a href="https://github.com/yihong0618/running_page">https://github.com/yihong0618/running_page</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37642032">https://news.ycombinator.com/item?id=37642032</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Show HN: Netmaker – Netmaker Goes Open Source
 - [https://github.com/gravitl/netmaker/blob/master/LICENSE.md](https://github.com/gravitl/netmaker/blob/master/LICENSE.md)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T11:16:09+00:00

<p>Article URL: <a href="https://github.com/gravitl/netmaker/blob/master/LICENSE.md">https://github.com/gravitl/netmaker/blob/master/LICENSE.md</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37642011">https://news.ycombinator.com/item?id=37642011</a></p>
<p>Points: 50</p>
<p># Comments: 0</p>

## ‘Who Benefits?’ Inside the EU’s Fight over Scanning for Child Sex Content
 - [https://balkaninsight.com/2023/09/25/who-benefits-inside-the-eus-fight-over-scanning-for-child-sex-content/](https://balkaninsight.com/2023/09/25/who-benefits-inside-the-eus-fight-over-scanning-for-child-sex-content/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T11:12:05+00:00

<p>Article URL: <a href="https://balkaninsight.com/2023/09/25/who-benefits-inside-the-eus-fight-over-scanning-for-child-sex-content/">https://balkaninsight.com/2023/09/25/who-benefits-inside-the-eus-fight-over-scanning-for-child-sex-content/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641974">https://news.ycombinator.com/item?id=37641974</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## Apple will charge you way less to fix cracked back glass on an iPhone 15 Pro
 - [https://arstechnica.com/gadgets/2023/09/apple-will-charge-you-way-less-to-fix-cracked-back-glass-on-an-iphone-15-pro/](https://arstechnica.com/gadgets/2023/09/apple-will-charge-you-way-less-to-fix-cracked-back-glass-on-an-iphone-15-pro/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T11:05:57+00:00

<p>Article URL: <a href="https://arstechnica.com/gadgets/2023/09/apple-will-charge-you-way-less-to-fix-cracked-back-glass-on-an-iphone-15-pro/">https://arstechnica.com/gadgets/2023/09/apple-will-charge-you-way-less-to-fix-cracked-back-glass-on-an-iphone-15-pro/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641921">https://news.ycombinator.com/item?id=37641921</a></p>
<p>Points: 14</p>
<p># Comments: 12</p>

## The home Wi-Fi upgrade we never asked for is coming. The one we need is not
 - [https://www.theregister.com/2023/09/25/wifi_7_ee_qualcomm/](https://www.theregister.com/2023/09/25/wifi_7_ee_qualcomm/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T10:53:40+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/09/25/wifi_7_ee_qualcomm/">https://www.theregister.com/2023/09/25/wifi_7_ee_qualcomm/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641812">https://news.ycombinator.com/item?id=37641812</a></p>
<p>Points: 25</p>
<p># Comments: 15</p>

## Making Military Service More Attractive for Modern Spouses
 - [https://warontherocks.com/2023/09/making-military-service-more-attractive-for-modern-spouses/](https://warontherocks.com/2023/09/making-military-service-more-attractive-for-modern-spouses/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T10:48:47+00:00

<p>Article URL: <a href="https://warontherocks.com/2023/09/making-military-service-more-attractive-for-modern-spouses/">https://warontherocks.com/2023/09/making-military-service-more-attractive-for-modern-spouses/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641769">https://news.ycombinator.com/item?id=37641769</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## OnlyFans
 - [https://onlyfans.web.cern.ch/](https://onlyfans.web.cern.ch/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T10:41:31+00:00

<p>Article URL: <a href="https://onlyfans.web.cern.ch/">https://onlyfans.web.cern.ch/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641706">https://news.ycombinator.com/item?id=37641706</a></p>
<p>Points: 112</p>
<p># Comments: 17</p>

## I Quit My Job at Amazon Rather Than Return to the Office 3 Days a Week
 - [https://www.businessinsider.com/i-quit-return-to-office-order-amazon-rto-2023-9](https://www.businessinsider.com/i-quit-return-to-office-order-amazon-rto-2023-9)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T10:36:20+00:00

<p>Article URL: <a href="https://www.businessinsider.com/i-quit-return-to-office-order-amazon-rto-2023-9">https://www.businessinsider.com/i-quit-return-to-office-order-amazon-rto-2023-9</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641660">https://news.ycombinator.com/item?id=37641660</a></p>
<p>Points: 35</p>
<p># Comments: 12</p>

## Upsert in SQL
 - [https://antonz.org/sql-upsert/](https://antonz.org/sql-upsert/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T10:29:35+00:00

<p>Article URL: <a href="https://antonz.org/sql-upsert/">https://antonz.org/sql-upsert/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641628">https://news.ycombinator.com/item?id=37641628</a></p>
<p>Points: 24</p>
<p># Comments: 6</p>

## Nuvem: Cable to connect Portugal, Bermuda, and the U.S.
 - [https://cloud.google.com/blog/products/infrastructure/introducing-the-nuvem-subsea-cable/](https://cloud.google.com/blog/products/infrastructure/introducing-the-nuvem-subsea-cable/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T10:21:12+00:00

<p>Article URL: <a href="https://cloud.google.com/blog/products/infrastructure/introducing-the-nuvem-subsea-cable/">https://cloud.google.com/blog/products/infrastructure/introducing-the-nuvem-subsea-cable/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641590">https://news.ycombinator.com/item?id=37641590</a></p>
<p>Points: 22</p>
<p># Comments: 0</p>

## New York employers must include pay rates in job ads under new state law
 - [https://english.elpais.com/economy-and-business/2023-09-17/new-york-employers-must-include-pay-rates-in-job-ads-under-new-state-law.html](https://english.elpais.com/economy-and-business/2023-09-17/new-york-employers-must-include-pay-rates-in-job-ads-under-new-state-law.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T10:19:40+00:00

<p>Article URL: <a href="https://english.elpais.com/economy-and-business/2023-09-17/new-york-employers-must-include-pay-rates-in-job-ads-under-new-state-law.html">https://english.elpais.com/economy-and-business/2023-09-17/new-york-employers-must-include-pay-rates-in-job-ads-under-new-state-law.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641583">https://news.ycombinator.com/item?id=37641583</a></p>
<p>Points: 24</p>
<p># Comments: 1</p>

## Baby boomers are becoming homeless at a rate not seen since the Great Depression
 - [https://moneywise.com/news/economy/rate-of-homeless-baby-boomers-increasing](https://moneywise.com/news/economy/rate-of-homeless-baby-boomers-increasing)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T09:58:23+00:00

<p>Article URL: <a href="https://moneywise.com/news/economy/rate-of-homeless-baby-boomers-increasing">https://moneywise.com/news/economy/rate-of-homeless-baby-boomers-increasing</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641471">https://news.ycombinator.com/item?id=37641471</a></p>
<p>Points: 56</p>
<p># Comments: 38</p>

## Intel Meteor Lake Architecture
 - [https://hothardware.com/reviews/intel-meteor-lake-architecture](https://hothardware.com/reviews/intel-meteor-lake-architecture)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T09:49:15+00:00

<p>Article URL: <a href="https://hothardware.com/reviews/intel-meteor-lake-architecture">https://hothardware.com/reviews/intel-meteor-lake-architecture</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641416">https://news.ycombinator.com/item?id=37641416</a></p>
<p>Points: 11</p>
<p># Comments: 4</p>

## How to Hide a $2T Trial
 - [https://www.thebignewsletter.com/p/how-to-hide-a-2-trillion-antitrust](https://www.thebignewsletter.com/p/how-to-hide-a-2-trillion-antitrust)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T09:44:19+00:00

<p>Article URL: <a href="https://www.thebignewsletter.com/p/how-to-hide-a-2-trillion-antitrust">https://www.thebignewsletter.com/p/how-to-hide-a-2-trillion-antitrust</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37641393">https://news.ycombinator.com/item?id=37641393</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Google killing Basic HTML version of Gmail In January 2024
 - [https://www.theregister.com/2023/09/25/gmail_basic_html_discontinued/](https://www.theregister.com/2023/09/25/gmail_basic_html_discontinued/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T08:36:07+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/09/25/gmail_basic_html_discontinued/">https://www.theregister.com/2023/09/25/gmail_basic_html_discontinued/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37640940">https://news.ycombinator.com/item?id=37640940</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Bitwarden: Free, open-source password manager
 - [https://bitwarden.com/](https://bitwarden.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T08:11:30+00:00

<p>Article URL: <a href="https://bitwarden.com/">https://bitwarden.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37640816">https://news.ycombinator.com/item?id=37640816</a></p>
<p>Points: 35</p>
<p># Comments: 19</p>

## Amazon will invest up to $4B in Anthropic
 - [https://www.anthropic.com/index/anthropic-amazon](https://www.anthropic.com/index/anthropic-amazon)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T07:07:44+00:00

<p>Article URL: <a href="https://www.anthropic.com/index/anthropic-amazon">https://www.anthropic.com/index/anthropic-amazon</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37640466">https://news.ycombinator.com/item?id=37640466</a></p>
<p>Points: 77</p>
<p># Comments: 29</p>

## Meticulous (YC S21) Is Hiring #3 Engineer to Build AI for Testing
 - [https://news.ycombinator.com/item?id=37640442](https://news.ycombinator.com/item?id=37640442)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T07:01:19+00:00

<p>Hey HN!<p>I'm Gabriel, CEO and co-founder of Meticulous.<p>Our mission is to radically accelerate the pace of software development for every company in the world. We're starting with a tool to catch UI bugs in web applications with zero-effort from developers.<p>How it works: Insert a single line of JavaScript onto your site, and we record thousands of real user sessions. We then replay these sessions on head and base commits of PRs, take screenshots at key points, and diff those screenshots to catch visual regressions before they hit production. We employ novel techniques to eliminate flakes. You can watch a 60-second demo at [meticulous.ai](<a href="https://meticulous.ai/">https://meticulous.ai/</a>).<p>We are a London-based YC company. Our engineering team previously worked at Dropbox, Opendoor, Palantir and Google, and have previously led 100+ engineer organizations at these companies. We raised $4m and are backed by some of the best founders and technical leaders in Silicon V

## LaLiga “Talks to Google” About Deleting Piracy Apps from a Million Phones
 - [https://torrentfreak.com/laliga-talks-to-google-about-piracy-apps-from-a-million-phones-230924/](https://torrentfreak.com/laliga-talks-to-google-about-piracy-apps-from-a-million-phones-230924/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T06:48:25+00:00

<p>Article URL: <a href="https://torrentfreak.com/laliga-talks-to-google-about-piracy-apps-from-a-million-phones-230924/">https://torrentfreak.com/laliga-talks-to-google-about-piracy-apps-from-a-million-phones-230924/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37640363">https://news.ycombinator.com/item?id=37640363</a></p>
<p>Points: 7</p>
<p># Comments: 7</p>

## Hello, World Part One: Eliza (2022)
 - [https://www.theparisreview.org/blog/2022/11/14/hello-world-part-one-eliza/](https://www.theparisreview.org/blog/2022/11/14/hello-world-part-one-eliza/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T06:08:31+00:00

<p>Article URL: <a href="https://www.theparisreview.org/blog/2022/11/14/hello-world-part-one-eliza/">https://www.theparisreview.org/blog/2022/11/14/hello-world-part-one-eliza/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37640137">https://news.ycombinator.com/item?id=37640137</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## The State of Async Rust
 - [https://corrode.dev/blog/async/](https://corrode.dev/blog/async/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T05:20:13+00:00

<p>Article URL: <a href="https://corrode.dev/blog/async/">https://corrode.dev/blog/async/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37639896">https://news.ycombinator.com/item?id=37639896</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Ken Follett Says Readers Still Like Epic Books
 - [https://www.wsj.com/arts-culture/ken-follett-says-readers-still-like-epic-books-39695bc6](https://www.wsj.com/arts-culture/ken-follett-says-readers-still-like-epic-books-39695bc6)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T05:10:27+00:00

<p>Article URL: <a href="https://www.wsj.com/arts-culture/ken-follett-says-readers-still-like-epic-books-39695bc6">https://www.wsj.com/arts-culture/ken-follett-says-readers-still-like-epic-books-39695bc6</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37639849">https://news.ycombinator.com/item?id=37639849</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Flameshow: A terminal flamegraph viewer
 - [https://github.com/laixintao/flameshow](https://github.com/laixintao/flameshow)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T04:34:07+00:00

<p>Article URL: <a href="https://github.com/laixintao/flameshow">https://github.com/laixintao/flameshow</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37639702">https://news.ycombinator.com/item?id=37639702</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## 20 Years of Grml.org
 - [https://blog.grml.org/archives/411-20-years-of-grml.org.html](https://blog.grml.org/archives/411-20-years-of-grml.org.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T04:06:57+00:00

<p>Article URL: <a href="https://blog.grml.org/archives/411-20-years-of-grml.org.html">https://blog.grml.org/archives/411-20-years-of-grml.org.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37639590">https://news.ycombinator.com/item?id=37639590</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## WGA and the studios reach tentative deal to end writers' strike
 - [https://www.latimes.com/entertainment-arts/business/story/2023-09-24/writers-strike-over-wga-studios-reach-deal-actors](https://www.latimes.com/entertainment-arts/business/story/2023-09-24/writers-strike-over-wga-studios-reach-deal-actors)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T02:41:37+00:00

<p>Article URL: <a href="https://www.latimes.com/entertainment-arts/business/story/2023-09-24/writers-strike-over-wga-studios-reach-deal-actors">https://www.latimes.com/entertainment-arts/business/story/2023-09-24/writers-strike-over-wga-studios-reach-deal-actors</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37639134">https://news.ycombinator.com/item?id=37639134</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## Tell HN: There is a highlights page on HN
 - [https://news.ycombinator.com/item?id=37639010](https://news.ycombinator.com/item?id=37639010)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T02:17:39+00:00

<p>Just went onto /lists, and saw the new highlights link. It seems to be about interesting comments that is user curated.<p><a href="https://news.ycombinator.com/highlights">https://news.ycombinator.com/highlights</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37639010">https://news.ycombinator.com/item?id=37639010</a></p>
<p>Points: 35</p>
<p># Comments: 2</p>

## Japan pharma startup to begin human trials of tooth regrowth drug in 2024
 - [https://english.kyodonews.net/news/2023/09/d56fb464a52b-japan-pharma-startup-developing-world-first-drug-to-grow-new-teeth.html](https://english.kyodonews.net/news/2023/09/d56fb464a52b-japan-pharma-startup-developing-world-first-drug-to-grow-new-teeth.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T02:05:34+00:00

<p>Article URL: <a href="https://english.kyodonews.net/news/2023/09/d56fb464a52b-japan-pharma-startup-developing-world-first-drug-to-grow-new-teeth.html">https://english.kyodonews.net/news/2023/09/d56fb464a52b-japan-pharma-startup-developing-world-first-drug-to-grow-new-teeth.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37638956">https://news.ycombinator.com/item?id=37638956</a></p>
<p>Points: 59</p>
<p># Comments: 11</p>

## Show HN: Crystaldoc.info – Crystal Shards API Documentation Hosting
 - [https://crystaldoc.info/](https://crystaldoc.info/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T02:00:06+00:00

<p>This is a website I developed in Crystal for hosting API documentation for Crystal shards (aka gems, crates, libraries, etc). It's built in Crystal itself and is using Postgres, Kemal, the built-in doc generation tooling, and Lexbor. I've been working on this for a number of months and I'm proud of where it's gotten. All feedback welcome!<p>Repo: <a href="https://github.com/nobodywasishere/crystaldoc.info">https://github.com/nobodywasishere/crystaldoc.info</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37638928">https://news.ycombinator.com/item?id=37638928</a></p>
<p>Points: 6</p>
<p># Comments: 4</p>

## (Erlang) Why do we need modules at all?
 - [http://erlang.org/pipermail/erlang-questions/2011-May/058768.html](http://erlang.org/pipermail/erlang-questions/2011-May/058768.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T01:53:28+00:00

<p>Article URL: <a href="http://erlang.org/pipermail/erlang-questions/2011-May/058768.html">http://erlang.org/pipermail/erlang-questions/2011-May/058768.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37638894">https://news.ycombinator.com/item?id=37638894</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Type 2 diabetes rates in US youth rose 62% after Covid pandemic began
 - [https://www.cidrap.umn.edu/covid-19/type-2-diabetes-rates-us-youth-rose-62-after-covid-pandemic-began-study-suggests](https://www.cidrap.umn.edu/covid-19/type-2-diabetes-rates-us-youth-rose-62-after-covid-pandemic-began-study-suggests)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T01:44:22+00:00

<p>Article URL: <a href="https://www.cidrap.umn.edu/covid-19/type-2-diabetes-rates-us-youth-rose-62-after-covid-pandemic-began-study-suggests">https://www.cidrap.umn.edu/covid-19/type-2-diabetes-rates-us-youth-rose-62-after-covid-pandemic-began-study-suggests</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37638840">https://news.ycombinator.com/item?id=37638840</a></p>
<p>Points: 46</p>
<p># Comments: 7</p>

## Game of Thrones creator and other authors sue ChatGPT-maker for ‘theft’
 - [https://www.aljazeera.com/news/2023/9/21/openai-sued](https://www.aljazeera.com/news/2023/9/21/openai-sued)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T01:41:07+00:00

<p>Article URL: <a href="https://www.aljazeera.com/news/2023/9/21/openai-sued">https://www.aljazeera.com/news/2023/9/21/openai-sued</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37638817">https://news.ycombinator.com/item?id=37638817</a></p>
<p>Points: 14</p>
<p># Comments: 4</p>

## Minecraft Wiki moves off of Fandom
 - [https://wikis.world/@MinecraftWikiEN/111121512237906439](https://wikis.world/@MinecraftWikiEN/111121512237906439)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T01:21:12+00:00

<p>Article URL: <a href="https://wikis.world/@MinecraftWikiEN/111121512237906439">https://wikis.world/@MinecraftWikiEN/111121512237906439</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37638682">https://news.ycombinator.com/item?id=37638682</a></p>
<p>Points: 34</p>
<p># Comments: 3</p>

## $700 a Month for a Bed-Sized “Pod” in Downtown SF? Techies Are Renting Them
 - [https://sfstandard.com/2023/09/23/san-francisco-pod-house-mint-plaza/](https://sfstandard.com/2023/09/23/san-francisco-pod-house-mint-plaza/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-09-25T00:51:25+00:00

<p>Article URL: <a href="https://sfstandard.com/2023/09/23/san-francisco-pod-house-mint-plaza/">https://sfstandard.com/2023/09/23/san-francisco-pod-house-mint-plaza/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37638563">https://news.ycombinator.com/item?id=37638563</a></p>
<p>Points: 26</p>
<p># Comments: 33</p>

