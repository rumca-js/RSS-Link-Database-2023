# Source:Jeff Kaufmann, URL:https://www.jefftk.com/news.rss, language:en-US

## Feedly Breaks MathML
 - [https://www.jefftk.com/p/feedly-breaks-mathml](https://www.jefftk.com/p/feedly-breaks-mathml)
 - RSS feed: https://www.jefftk.com/news.rss
 - date published: 2023-09-25T08:00:00+00:00

<p><span>

A few days ago I wrote about </span>

<a href="https://www.jefftk.com/p/hand-writing-mathml">my
experience with MathML</a>, and despite being somewhat positive on it
in that post I've decided to stop using it for now. The problem is, it
doesn't display for people who follow my blog through RSS on (I'm
guessing) most popular RSS system.



<p>

Here's a screenshot from my most recent MathML-containing post, on my
website:

</p>

<p>

<a href="https://www.jefftk.com/raw-html-mathml-working-big.png"><img border="1" class="mobile-fullwidth" height="115" src="https://www.jefftk.com/raw-html-mathml-working.png" width="550" /><div class="image-vertical-spacer"></div></a>

</p>

<p>

And here's the same portion of that post running in the web version of
Feedly on the same browser:

</p>

<p>

<a href="https://www.jefftk.com/feedly-missing-mathml-big.png"><img border="1" class="mobile-fullwidth" height="147" src="https://www.jefftk.com/feedly-missing-mathml.png" width="550" /><div 

