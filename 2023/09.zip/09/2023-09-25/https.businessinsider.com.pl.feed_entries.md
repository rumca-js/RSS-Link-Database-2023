# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Zełenski: stopniowo pozbywamy się emocji wokół tematu zboża
 - [https://businessinsider.com.pl/gospodarka/zelenski-stopniowo-pozbywamy-sie-emocji-wokol-tematu-zboza/xzm0gmk](https://businessinsider.com.pl/gospodarka/zelenski-stopniowo-pozbywamy-sie-emocji-wokol-tematu-zboza/xzm0gmk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T19:40:20+00:00

Stopniowo pozbywamy się emocji wokół tematu zboża— oświadczył w poniedziałek ukraiński prezydent Wołodymyr Zełenski. Jednocześnie wyraził nadzieję, że współpraca Ukrainy z sąsiadami będzie równie konstruktywna jak z Rumunią i Bułgarią.

## Wyścig z czasem w Starbucksie. Miliardy możliwości
 - [https://businessinsider.com.pl/lifestyle/jedzenie/dlaczego-coraz-dluzej-czekamy-na-kawe-380-mld-mozliwosci/7v5p3xd](https://businessinsider.com.pl/lifestyle/jedzenie/dlaczego-coraz-dluzej-czekamy-na-kawe-380-mld-mozliwosci/7v5p3xd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T19:22:19+00:00

Co powstrzymuje ludzi przed zamówieniem kawy w Starbucksie? Wcale nie fakt, że waniliowa latte kosztuje 7 dol., tylko czekanie — pisze Bloomberg. A wszystko przez spersonalizowane napoje z coraz większą liczbą dostępnych dodatków, których przygotowanie przytłacza obsługę i zajmuje więcej czasu. Sieć zapowiada zmiany.

## Czy można samodzielnie wyliczyć zdolność kredytową? Wszystko, co musisz wiedzieć
 - [https://businessinsider.com.pl/gospodarka/zdolnosc-kredytowa-czy-mozna-samodzielnie-ja-wyliczyc/stwt9fh](https://businessinsider.com.pl/gospodarka/zdolnosc-kredytowa-czy-mozna-samodzielnie-ja-wyliczyc/stwt9fh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T18:41:56+00:00

Zdolność kredytowa to kluczowy czynnik, który decyduje o przyznaniu kredytu. Nie tylko hipotecznego, ale także pozostałych pożyczek. Na zdolność kredytową składa się wiele elementów, które ostatecznie rozstrzygają, czy możemy wnioskować o interesujące nas wsparcie. Wyliczenie tego podstawowego wskaźnika nie zawsze wymaga kontaktu z bankiem.

## Niemcy już nie lubią elektryków? Oto dlaczego coraz częściej żałują zakupu
 - [https://businessinsider.com.pl/motoryzacja/niemcy-juz-nie-lubia-elektrykow-oto-dlaczego-coraz-czesciej-zaluja-zakupu/8qzmxvb](https://businessinsider.com.pl/motoryzacja/niemcy-juz-nie-lubia-elektrykow-oto-dlaczego-coraz-czesciej-zaluja-zakupu/8qzmxvb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T18:33:54+00:00

W Europie wystrzeliła sprzedaż elektryków. W czołówce są nasi zachodni sąsiedzi. Jednak, jak się okazuje, ponad połowa Niemców, żałuje zakupu auta elektrycznego. Nasi zachodni sąsiedzi podają przy tym jeden powód.

## Morawiecki do kanclerza Niemiec: niech się pan nie wtrąca w polskie sprawy
 - [https://businessinsider.com.pl/wiadomosci/morawiecki-do-kanclerza-niemiec-niech-sie-pan-nie-wtraca-w-polskie-sprawy/c2vq9b6](https://businessinsider.com.pl/wiadomosci/morawiecki-do-kanclerza-niemiec-niech-sie-pan-nie-wtraca-w-polskie-sprawy/c2vq9b6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T18:19:47+00:00

To, co teraz mówi kanclerz Niemiec, być może jest przygotowaniem pod scenariusz zamknięcia granicy; niech pan dowie się, jaka jest faktyczna sytuacja i nie wtrąca w polskie sprawy — powiedział w Kraśniku (Lubelskie) premier Mateusz Morawiecki.

## Polska przywraca kontrole graniczne. Tłumaczymy, co mówią przepisy
 - [https://businessinsider.com.pl/gospodarka/jak-przywraca-sie-kontrole-graniczne-w-strefie-schengen/hyk8msp](https://businessinsider.com.pl/gospodarka/jak-przywraca-sie-kontrole-graniczne-w-strefie-schengen/hyk8msp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T17:43:24+00:00

Mateusz Morawiecki polecił szefowi MSWiA wprowadzenie kontroli na granicy polsko-słowackiej. Premier przyznał, że to odpowiedź na pojawiające się informacje, jakoby "tamtędy migrowali nielegalni imigranci". Czy Polska mogła wprowadzić kontrole graniczne? Jak odbywa się przywracanie kontroli na granicach wewnętrznych strefy Schengen? Wyjaśniamy to krok po kroku.

## NBP na inflacyjnym froncie. Kluczowy dokument opublikowany
 - [https://businessinsider.com.pl/gospodarka/nbp-na-inflacyjnym-froncie-kluczowy-dokument-opublikowany/72n5z2m](https://businessinsider.com.pl/gospodarka/nbp-na-inflacyjnym-froncie-kluczowy-dokument-opublikowany/72n5z2m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T17:38:07+00:00

Narodowy Bank Polski opublikował "Założenia polityki pieniężnej" na przyszły rok. Cel inflacyjny, czyli 2,5 proc. z możliwymi odchyleniami o 1 pp. pozostał bez zmian, choć równocześnie bank centralny przyznał, że dochodzenie do niego będzie odbywać się stopniowo.

## Booking zablokowany. Nie przejmie biura podróży
 - [https://businessinsider.com.pl/wiadomosci/booking-zablokowany-nie-przejmie-biura-podrozy-powodem-obawa-o-ceny/wlmlw0d](https://businessinsider.com.pl/wiadomosci/booking-zablokowany-nie-przejmie-biura-podrozy-powodem-obawa-o-ceny/wlmlw0d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T17:34:04+00:00

Komisja Europejska zablokowała w poniedziałek planowane przejęcie internetowego biura podróży eTraveli przez Booking. Powodem decyzji była obawa, że przejęcie wzmocni dominującą pozycję Booking na rynku usług hotelowych, ograniczy konkurencję i podniesie ceny dla hoteli i konsumentów.

## Nieoficjalnie: Korea Północna otwiera granice po trzech latach izolacji
 - [https://businessinsider.com.pl/wiadomosci/korea-polnocna-otwiera-granice-po-trzech-latach-izolacji-podaja-chinskie-media/kq5j5l9](https://businessinsider.com.pl/wiadomosci/korea-polnocna-otwiera-granice-po-trzech-latach-izolacji-podaja-chinskie-media/kq5j5l9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T17:32:55+00:00

Korea Północna zdecydowała się otworzyć swoje granice po trzech latach izolacji kraju, spowodowanej pandemią – podała w poniedziałek chińska telewizja państwowa CCTV.

## Tyle wynosi przeciętna emerytura. Rośnie siła nabywcza seniorów
 - [https://businessinsider.com.pl/gospodarka/tyle-wynosi-przecietna-emerytura-rosnie-sila-nabywcza-seniorow/40wc4h4](https://businessinsider.com.pl/gospodarka/tyle-wynosi-przecietna-emerytura-rosnie-sila-nabywcza-seniorow/40wc4h4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T17:05:34+00:00

Nominalne oraz realne emerytury i renty znacząco wzrosły w porównaniu do ubiegłego roku — wynika z danych GUS. Rośnie też siła nabywcza emerytów.

## Mateusz Morawiecki zapowiada nową ulgę podatkową. "Jeśli będziemy rządzić"
 - [https://businessinsider.com.pl/biznes/mateusz-morawiecki-zapowiada-nowa-ulge-podatkowa-jesli-bedziemy-rzadzic/f6fnk1x](https://businessinsider.com.pl/biznes/mateusz-morawiecki-zapowiada-nowa-ulge-podatkowa-jesli-bedziemy-rzadzic/f6fnk1x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T17:00:00+00:00

Premier podczas kolejnego kampanijnego spotkania zapowiedział stworzenie nowego systemu wsparcia dla przedsiębiorstw, które chciałyby inwestować w miastach średniej wielkości. Jak przyznał, system ma zakładać m.in. nowe ulgi podatkowe.

## Dzwonią do ciebie lub wysyłają link. Uważaj na nich
 - [https://businessinsider.com.pl/technologie/dzwonia-do-ciebie-lub-wysylaja-link-uwazaj-na-nich/rhefq5x](https://businessinsider.com.pl/technologie/dzwonia-do-ciebie-lub-wysylaja-link-uwazaj-na-nich/rhefq5x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T16:43:23+00:00

33 proc. Polaków spotkała się w ciągu ostatniego roku z próbą wyłudzenia ich danych osobowych poprzez fałszywy telefon, link bądź e-mail. 12 proc. padło ofiarą takiego oszustwa. Przestępcy stosują coraz nowsze sposoby.

## Przejęli 70-metrowy jacht bliskiego człowieka Putina. To był początek problemów
 - [https://businessinsider.com.pl/wiadomosci/utrzymanie-rosyjskiego-jachtu-kosztuje-krocie-caly-kraj-ma-dosc/sdm2bpb](https://businessinsider.com.pl/wiadomosci/utrzymanie-rosyjskiego-jachtu-kosztuje-krocie-caly-kraj-ma-dosc/sdm2bpb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T16:20:58+00:00

70-metrowy jacht należący do bliskiego współpracownika Władimira Putina, który 19 miesięcy temu został zacumowany na Karaibach, stał się kulą u nogi rządu Antigui i Barbudy. Jego utrzymanie kosztuje władze 28 tys. dolarów, czyli 121 tys. złotych tygodniowo. Najwięcej pieniędzy pochłania ochrona przed pleśnią.

## Wracają kontrole na polskiej granicy. Na razie z jednym państwem
 - [https://businessinsider.com.pl/wiadomosci/wracaja-kontrole-na-polskiej-granicy-na-razie-z-jednym-panstwem/cdxd597](https://businessinsider.com.pl/wiadomosci/wracaja-kontrole-na-polskiej-granicy-na-razie-z-jednym-panstwem/cdxd597)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T16:16:09+00:00

Premier Mateusz Morawiecki poinformował, że wydał polecenie szefowi Ministerstwa Spraw Wewnętrznych i Administracji, by wprowadzić kontrole na polsko-słowackiej granicy.

## Polskie firmy działające w Ukrainie się nie poddają. Niektóre nawet zwiększają inwestycje
 - [https://businessinsider.com.pl/biznes/polskie-firmy-dzialajace-w-ukrainie-sie-nie-poddaja-niektore-nawet-zwiekszaja/cwgefky](https://businessinsider.com.pl/biznes/polskie-firmy-dzialajace-w-ukrainie-sie-nie-poddaja-niektore-nawet-zwiekszaja/cwgefky)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T15:40:29+00:00

Wojna w Ukrainie, jak pokazał niedawny przypadek Fakro, oznacza podwyższone ryzyko działania na tym rynku. Jednak polski biznes nie przestraszył się, wierzy w pozytywny dla Ukrainy wynik wojny i kontynuuje działalność. Oto główne biznesy polskich przedsiębiorców za Bugiem.

## Są ją uniewinnił, ale fiskus nie odpuszcza. Żąda 20 mln zł
 - [https://businessinsider.com.pl/firmy/przepisy/sad-uniewinnil-fiskus-chce-20-mln-zl-rujnuje-moje-finanse-zdrowie-i-zycie/bjkt5jy](https://businessinsider.com.pl/firmy/przepisy/sad-uniewinnil-fiskus-chce-20-mln-zl-rujnuje-moje-finanse-zdrowie-i-zycie/bjkt5jy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T15:34:12+00:00

— Niestety organy skarbowe nie zauważają, że zostałam uniewinniona przez sąd — żali się przedsiębiorczyni, od której fiskus żąda 20 mln zł. Batalia trwa 15 lat.

## Jest umowa z Lockheed Martin. Polska będzie mieć największą flotę Apachy poza USA
 - [https://businessinsider.com.pl/wiadomosci/jest-umowa-z-lockheed-martin-polska-bedzie-miec-najwieksza-flote-apachy-poza-usa/ke2fjvx](https://businessinsider.com.pl/wiadomosci/jest-umowa-z-lockheed-martin-polska-bedzie-miec-najwieksza-flote-apachy-poza-usa/ke2fjvx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T15:33:04+00:00

Minister obrony Mariusz Błaszczak podpisał w poniedziałek w Mesie w stanie Arizona umowę offsetową z koncernem Lockheed Martin, związaną z zakupem śmigłowców Apache. Umowa zakłada powstanie centrum serwisowego śmigłowców w Bydgoszczy.

## Pierwsze takie manewry polskiego wojska od 20 lat. MON przejął drogę
 - [https://businessinsider.com.pl/wiadomosci/pierwsze-takie-manewry-polskiego-wojska-od-20-lat-mon-przejal-droge/3l8nfjj](https://businessinsider.com.pl/wiadomosci/pierwsze-takie-manewry-polskiego-wojska-od-20-lat-mon-przejal-droge/3l8nfjj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T15:25:18+00:00

Wojsko przejęło tymczasowo odcinek drogi wojewódzkiej nr 604 pomiędzy Wielbarkiem i Nidzicą w woj. warmińsko-mazurskim. W ramach ćwiczeń Route 604 droga jest wykorzystywana jako miejsce lądowania samolotów wojskowych. To pierwsze od 20 lat ćwiczenia polskich lotników z użyciem dróg publicznych.

## Zabezpieczenia przed kradzieżą nawet na dwóch plasterkach szynki. Tak sklepy walczą ze złodziejami
 - [https://businessinsider.com.pl/gospodarka/zabezpieczenia-przed-kradzieza-nawet-na-plasterku-szynki/xzqrq0f](https://businessinsider.com.pl/gospodarka/zabezpieczenia-przed-kradzieza-nawet-na-plasterku-szynki/xzqrq0f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T15:22:10+00:00

Do zabezpieczeń antykradzieżowych na ubraniach, kosmetykach czy lekach jesteśmy już przyzwyczajeni. Sprzedawcy zostali jednak zmuszeni, żeby chronić nawet produkty spożywcze, które sprzedawane są na wagę. Kolejna sieć wprowadziła właśnie stosowne zabezpieczenia na swoich produktach.

## Ekonomiści: inflacja we wrześniu znacząco spadnie. Pomógł "cud na stacjach"
 - [https://businessinsider.com.pl/gospodarka/ekonomisci-inflacja-we-wrzesniu-znaczaco-spadnie-pomogl-cud-na-stacjach/mfpz10r](https://businessinsider.com.pl/gospodarka/ekonomisci-inflacja-we-wrzesniu-znaczaco-spadnie-pomogl-cud-na-stacjach/mfpz10r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T15:10:22+00:00

Inflacja konsumencka CPI w Polsce spadnie do 8,1 proc. r/r we wrześniu br., prognozuje Citi Handlowy. Czynniki obniżające dynamikę cen to ceny paliw oraz niższe ceny energii elektrycznej.

## USA pożyczyły Polsce 2 mld dol. na obronność
 - [https://businessinsider.com.pl/gospodarka/usa-pozyczyly-polsce-2-mld-dol-na-obronnosc/4tlt3tk](https://businessinsider.com.pl/gospodarka/usa-pozyczyly-polsce-2-mld-dol-na-obronnosc/4tlt3tk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T14:39:08+00:00

Stany Zjednoczone udzieliły w poniedziałek Polsce pożyczki bezpośredniej o wartości 2 miliardów dolarów w ramach zagranicznego finansowania wojskowego (FMF) w celu wsparcia modernizacji polskiej obronności — poinformował Departament Stanu USA.

## Odbicie w IT. Najpierw zwalniali, teraz przyjmują na nowo
 - [https://businessinsider.com.pl/twoje-pieniadze/praca/big-tech-budzi-sie-po-pandemii-ruszaja-rekrutacje-w-firmach-it/4l57srn](https://businessinsider.com.pl/twoje-pieniadze/praca/big-tech-budzi-sie-po-pandemii-ruszaja-rekrutacje-w-firmach-it/4l57srn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T14:38:27+00:00

W tym roku ponad tysiąc firm z sektora technologicznego zwolniło niespełna 240 tys. ludzi. Rok wcześniej było tylko nieznacznie "lepiej", bo na całym świecie pracę w IT straciło ponad 164 tys., a zwolnienia były przeprowadzane w podobnej liczbie firm. Rekordziści pożegnali nawet 10 tys. osób i więcej. Google, Microsoft, Meta, Amazon czy Salesforce — wszyscy zwalniali. Teraz sytuacja zaczyna się zmieniać i Big Tech budzi się po pandemii.

## Chiny mają 1 mld 400 mln mieszkańców. To za mało, by zapełnić puste nieruchomości w kraju
 - [https://businessinsider.com.pl/gospodarka/chiny-maja-1-mld-400-mln-mieszkancow-to-za-malo-by-zapelnic-puste-nieruchomosci-w/tqnrv37](https://businessinsider.com.pl/gospodarka/chiny-maja-1-mld-400-mln-mieszkancow-to-za-malo-by-zapelnic-puste-nieruchomosci-w/tqnrv37)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T14:36:59+00:00

Były chiński urzędnik rządowy ocenił, że nawet cała populacja kraju, czyli ponad 1 mld 4 mln ludzi, nie wystarczyłaby do zapełnienia wszystkich pustych domów. Informację podał Reuters, powołując się na nagranie państwowej agencji informacyjnej China News Service.

## Długi Polaków. Windykatorzy mają pełne ręce roboty
 - [https://businessinsider.com.pl/firmy/windykatorzy-maja-pelne-rece-roboty-polacy-nie-placa-dlugow/5sd8pkw](https://businessinsider.com.pl/firmy/windykatorzy-maja-pelne-rece-roboty-polacy-nie-placa-dlugow/5sd8pkw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T14:27:12+00:00

Firmy windykacyjne mają pełne ręce roboty. Pogarsza się sytuacja osób zadłużonych, co wynika m.in. z wysokiego poziomu inflacji. Jednocześnie wiodący na rynku windykatorzy podają, że rosną wpłaty od dłużników.

## Im więcej dzieci, tym lepsze auto służbowe. Ta firma wie, jak docenić pracowników
 - [https://businessinsider.com.pl/praca/im-wiecej-dzieci-tym-lepsze-auto-sluzbowe-ta-firma-wie-jak-docenic-pracownikow/6jgn42c](https://businessinsider.com.pl/praca/im-wiecej-dzieci-tym-lepsze-auto-sluzbowe-ta-firma-wie-jak-docenic-pracownikow/6jgn42c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T14:18:53+00:00

Minęły czasy, kiedy benefity dla pracowników były niemal identyczne we wszystkich organizacjach. Pracodawcy stosują coraz bardziej kreatywne rozwiązania, by przyciągać najlepszych. Jedna z firm zastosowała wyjątkowo oryginalną metodę na wyróżnienie zatrudnionych.

## Horror cenowy już za nami? Decyzja o budowie domu może być strzałem w dziesiątkę
 - [https://businessinsider.com.pl/nieruchomosci/budowa-domu-horror-cenowy-juz-za-nami-to-moze-byc-strzal-w-dziesiatke/vwft027](https://businessinsider.com.pl/nieruchomosci/budowa-domu-horror-cenowy-juz-za-nami-to-moze-byc-strzal-w-dziesiatke/vwft027)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T14:09:07+00:00

Ostatnie zmiany cen materiałów budowlanych dają nadzieję na to, że pierwszy raz od dawna ze spokojną głową będzie można rozpocząć budowę własnego domu. Ekspert rynkowy sugeruje, że w najbliższych miesiącach utrzyma się raczej spadkowa tendencja cen w budownictwie jednorodzinnym.

## Znana firma uzupełni strategiczne rezerwy żywnościowe Polski
 - [https://businessinsider.com.pl/biznes/znana-firma-uzupelni-strategiczne-rezerwy-zywnosciowe-polski/34cpg1g](https://businessinsider.com.pl/biznes/znana-firma-uzupelni-strategiczne-rezerwy-zywnosciowe-polski/34cpg1g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T14:05:05+00:00

Rządowa Agencja Rezerw Strategicznych podpisała umowę ze spółdzielnią mleczarską Mlekovita na dostawę produktów żywnościowych w ramach rezerw strategicznych — poinformowała w poniedziałek RARS. Chodzi o masło i mleko odtłuszczone w proszku.

## Złota polska jesień w Jurze Krakowsko-Częstochowskiej. Pięć idealnych miejsc na weekend
 - [https://businessinsider.com.pl/lifestyle/podroze/zlota-polska-jesien-w-jurze-krakowsko-czestochowskiej/zvgvd0d](https://businessinsider.com.pl/lifestyle/podroze/zlota-polska-jesien-w-jurze-krakowsko-czestochowskiej/zvgvd0d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T14:00:13+00:00

Jesień w Polsce to czas, kiedy natura urzeka swoją kolorystyką, a ciepłe dni w październiku i listopadzie pozwalają na chwile wytchnienia przed zimą. Jeśli marzysz o weekendzie w otoczeniu złotych liści, skalistych formacji i historycznych zamków, Jura Krakowsko-Częstochowska jest miejscem, które musisz odwiedzić. W tym artykule przedstawiamy pięć hoteli, które oferują nie tylko komfortowe warunki, ale również rozbudowaną strefę SPA i atrakcje dla całej rodziny. Na stronie serwisu Triverna.pl jest możliwość dokonania rezerwacji ze specjalną zniżką. Zapraszamy!

## Amator uchwycił jedną z najjaśniejszych kul ognia, jakie zaobserwowano na Jowiszu
 - [https://businessinsider.com.pl/technologie/nauka/amator-uchwycil-jedna-z-najjasniejszych-kul-ognia-jakie-zaobserwowano-na-jowiszu/vyjhks0](https://businessinsider.com.pl/technologie/nauka/amator-uchwycil-jedna-z-najjasniejszych-kul-ognia-jakie-zaobserwowano-na-jowiszu/vyjhks0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T13:30:33+00:00

Jowisz chroni resztę Układu Słonecznego, przyjmując na siebie wiele uderzeń. Nowe nagranie pokazuje jedno z największych, jakie kiedykolwiek dostrzegli astronomowie.

## Warszawa będzie miała jedno z największych muzeów w Europie. Cytadela Warszawska znów tętni życiem
 - [https://businessinsider.com.pl/gospodarka/muzeum-historii-polski-w-warszawie-to-jedno-z-najwiekszych-muzeow-w-europie/me7c6mp](https://businessinsider.com.pl/gospodarka/muzeum-historii-polski-w-warszawie-to-jedno-z-najwiekszych-muzeow-w-europie/me7c6mp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T13:25:44+00:00

Dobiegły końca rozległe prace w Cytadeli Warszawskiej. 28 września oficjalnie otwarte zostanie Muzeum Historii Polski, które tchnie życie w teren, który do tej pory był niedostępny dla turystów. To jeden z najnowocześniejszych obiektów muzealnych w Europie, a na dodatek również jeden z największych.

## "To się w głowie nie mieści". Rozmawiamy z Niemcami o polskich cenach paliw
 - [https://businessinsider.com.pl/gospodarka/to-sie-w-glowie-nie-miesci-niemcy-o-polskich-paliwach/cblnrjm](https://businessinsider.com.pl/gospodarka/to-sie-w-glowie-nie-miesci-niemcy-o-polskich-paliwach/cblnrjm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T13:25:04+00:00

Niemcy długo jeździli do Polski tylko po to, by zatankować. W ostatnich latach jednak takie podróże, jak sami mówią, "stawały się coraz mniej opłacalne". Przed wyborami to się znów zmieniło. "Paliwowi turyści" znowu przekraczają granicę – i wręcz nie mogą uwierzyć w nasze stawki.

## Znamy polskiego kandydata do Oscara
 - [https://businessinsider.com.pl/wiadomosci/znamy-polskiego-kandydata-do-oscara/zgqp4ny](https://businessinsider.com.pl/wiadomosci/znamy-polskiego-kandydata-do-oscara/zgqp4ny)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T13:13:11+00:00

Znamy polskiego kandydata do Oscara. O tytuł najlepszego filmu międzynarodowego powalczą "Chłopi".

## Niemcy chcą kontroli na granicy z Polską. Mogą dotknąć milionów ludzi
 - [https://businessinsider.com.pl/gospodarka/niemcy-chca-kontroli-na-granicy-moga-dotknac-milionow-ludzi-i-duzych-pieniedzy/r1nt4nv](https://businessinsider.com.pl/gospodarka/niemcy-chca-kontroli-na-granicy-moga-dotknac-milionow-ludzi-i-duzych-pieniedzy/r1nt4nv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T13:01:20+00:00

W rok mocno zwiększył się ruch na granicach z Polską. Kluczowy jest odcinek z Niemcami, gdzie w ciągu trzech miesięcy odnotowano ponad 30 mln osób. W kontekście gróźb dotyczących powrotu kontroli na granicy warto pamiętać, że swoboda przepływu osób przyczynia się do wydatków liczonych w miliardach złotych.

## MF zmienia stawki obligacji. Jest zaskoczenie
 - [https://businessinsider.com.pl/gospodarka/mf-zmienia-stawki-obligacji-jest-zaskoczenie/tjnxxks](https://businessinsider.com.pl/gospodarka/mf-zmienia-stawki-obligacji-jest-zaskoczenie/tjnxxks)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T12:52:13+00:00

Ministerstwo Finansów pokazało oprocentowanie obligacji skarbowych w październiku. Nie spadnie ono jednak tak, jak powinno po ostatniej obniżce stóp procentowych. Będzie znacznie wyższe od stopy referencyjnej.

## Skandal w Czechach. Rosyjski agent płacił za szerzenie kremlowskiej propagandy
 - [https://businessinsider.com.pl/wiadomosci/skandal-w-czechach-rosyjski-agent-placil-za-szerzenie-kremlowskiej-propagandy/rldhxf7](https://businessinsider.com.pl/wiadomosci/skandal-w-czechach-rosyjski-agent-placil-za-szerzenie-kremlowskiej-propagandy/rldhxf7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T12:43:43+00:00

Rosyjski agent w Czechach płacił osobom publicznym za rozpowszechnianie rosyjskiej propagandy dotyczącej wojny rosyjsko-ukraińskiej — ujawniła Informacyjna Służba Bezpieczeństwa (BIS). Jak powiedział w poniedziałek szef BIS Michal Kudelka, chodziło o kilka tysięcy euro.

## Kolejny taki głos z Niemiec. Wrócą kontrole na granicy z Polską
 - [https://businessinsider.com.pl/gospodarka/kolejny-taki-glos-z-niemiec-wroca-kontrole-na-granicy-z-polska/00cy6s8](https://businessinsider.com.pl/gospodarka/kolejny-taki-glos-z-niemiec-wroca-kontrole-na-granicy-z-polska/00cy6s8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T12:32:26+00:00

W debacie na temat polityki migracyjnej premier Saksonii Michael Kretschmer opowiedział się za szybkimi i zdecydowanymi środkami. Podkreślił, że "sytuacja jest dramatyczna", a stacjonarne kontrole na granicach z Polską i Czechami są koniecznie, by opanować sytuację – informuje portal Tagesschau.

## Zełenski powalczy o drugą kadencję? Jego żona ma wątpliwości
 - [https://businessinsider.com.pl/wiadomosci/zelenski-powalczy-o-druga-kadencje-jego-zona-ma-watpliwosci/9e15sn1](https://businessinsider.com.pl/wiadomosci/zelenski-powalczy-o-druga-kadencje-jego-zona-ma-watpliwosci/9e15sn1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T12:27:37+00:00

W czasie gdy Ukraina zastanawia się, czy przeprowadzić kolejne wybory prezydenckie w warunkach przedłużającej się rosyjskiej inwazji, ukraińska pierwsza dama Ołena Zełenska wyznała w rozmowie z CBS, że ma wątpliwości, czy jej mąż będzie ubiegał się o drugą kadencję w 2024 r.

## Ukraina zyskała potężną broń. "Abramsy już w Ukrainie"
 - [https://businessinsider.com.pl/wiadomosci/ukraina-zyskala-potezna-bron-abramsy-juz-w-ukrainie/m7qwfdf](https://businessinsider.com.pl/wiadomosci/ukraina-zyskala-potezna-bron-abramsy-juz-w-ukrainie/m7qwfdf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T12:23:53+00:00

Pierwsze z obiecanych 31 czołgów Abrams z USA dotarły do Ukrainy. Poinformował o tym prezydent Wołodymyr Zełenski. Jak dodał, maszyny maszyny "są przygotowywane do wzmocnienia" brygad na froncie.

## Siedzieli w samolocie obok śliniącego się psa. Jest finał batalii z liniami lotniczymi
 - [https://businessinsider.com.pl/lifestyle/podroze/siedzieli-w-samolocie-obok-sliniacego-sie-psa-dostali-za-to-6-tys-zl/2qzrzmp](https://businessinsider.com.pl/lifestyle/podroze/siedzieli-w-samolocie-obok-sliniacego-sie-psa-dostali-za-to-6-tys-zl/2qzrzmp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T11:43:16+00:00

Przeprosiny i dwa bony upominkowe o wartości 300 zł. Tyle początkowo otrzymała para podróżników za 13-godzinny lot obok śliniącego się i puszczającego gazy psa. Po kilku miesiącach wymieniania pism i prób dodzwonienia się na infolinię przewoźnik uznał, że parze należy się zwrot kosztów w wysokości 1,4 tys. dol. A ponieważ historia stała się głośna, małżeństwo postanowiło przekazać pieniądze na cele charytatywne.

## Nie żyje szef cosa nostry. Mafioso był poszukiwany przez 30 lat
 - [https://businessinsider.com.pl/wiadomosci/prawie-sie-nie-ukrywal-a-szukali-go-30-lat-nie-zyje-szef-wloskiej-mafii/v2e650q](https://businessinsider.com.pl/wiadomosci/prawie-sie-nie-ukrywal-a-szukali-go-30-lat-nie-zyje-szef-wloskiej-mafii/v2e650q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T11:32:50+00:00

Zmarł Matteo Messina Denaro, słynny sycylijski mafioso i przywódca cosa nostry. Denaro znany także jako "Diabolik" został skazany na dożywocie za dziesiątki zabójstw. Był poszukiwany przez 30 lat, podczas których prowadził normalne życie i praktycznie się nie ukrywał. Choroba sprawiła, że na początku tego roku został aresztowany.

## Rosja dużo straciła na unijnych sankcjach dotyczących paliw. Te kraje zyskały najwięcej
 - [https://businessinsider.com.pl/gospodarka/rosja-stracila-na-unijnych-sankcjach-dotyczacych-paliw-te-kraje-zyskaly-najwiecej/x662mdg](https://businessinsider.com.pl/gospodarka/rosja-stracila-na-unijnych-sankcjach-dotyczacych-paliw-te-kraje-zyskaly-najwiecej/x662mdg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T11:24:36+00:00

Rosja z największego dostawcy produktów naftowych do UE stała się po roku mało znaczącym graczem na rynku. Eurostat podsumował najważniejsze statystyki dotyczące importu. Najwięcej kosztem Rosji zyskała Norwegia, ale lista beneficjentów jest dłuższa.

## Najbogatszy Polak kupi VeloBank? Bankowy Fundusz Gwarancyjny zabrał głos
 - [https://businessinsider.com.pl/gospodarka/solowow-kupi-velobank-bankowy-fundusz-gwarancyjny-zabral-glos/2xjllc8](https://businessinsider.com.pl/gospodarka/solowow-kupi-velobank-bankowy-fundusz-gwarancyjny-zabral-glos/2xjllc8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T11:18:26+00:00

Bankowy Fundusz Gwarancyjny informuje, że otrzymał niewiążące oferty na kupno VeloBanku i jest w trakcie ich oceny. Nie zdradza, kto je złożył. Jak informowaliśmy w Business Insider Polska jako pierwsi, wstępne zainteresowanie transakcją wyrażał m.in. najbogatszy Polak Michał Sołowow.

## Planujesz kupić mieszkanie? Państwowy bank ma złe wiadomości
 - [https://businessinsider.com.pl/poradnik-finansowy/kredyty/mieszkania-jeszcze-mniej-dostepne-pko-w-rok-zdrozeja-o-10-15-proc/tr97tgz](https://businessinsider.com.pl/poradnik-finansowy/kredyty/mieszkania-jeszcze-mniej-dostepne-pko-w-rok-zdrozeja-o-10-15-proc/tr97tgz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T11:14:45+00:00

Jeśli planujesz kupić mieszkanie, lepiej się pospieszyć. PKO BP prognozuje, że w ciągu najbliższego roku ceny transakcyjne — realne kwoty, które klienci ostatecznie płacą za zakup — wzrosną o 10-15 proc.

## Futurolożka doradza największym firmom. Przewiduje kres szefów w stylu Elona Muska
 - [https://businessinsider.com.pl/wiadomosci/futurolozka-doradza-najwiekszym-firmom-jako-negatywny-przyklad-wskazuje-elona-muska/jflydj9](https://businessinsider.com.pl/wiadomosci/futurolozka-doradza-najwiekszym-firmom-jako-negatywny-przyklad-wskazuje-elona-muska/jflydj9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T10:50:53+00:00

Dla futurolożki Oony Horx-Strathern Elon Musk uosabia "szczyt nieprzyjazności". Według niej świat zmierza w odwrotnym kierunku nowej "ekonomii życzliwości". Praca, społeczeństwo i miasta zmieniają się dramatycznie.

## Czy to praca marzeń? Zapłacą 2,5 tys. dol. za oglądanie Netfliksa
 - [https://businessinsider.com.pl/technologie/zaplaca-25-tys-dol-za-ogladanie-seriali-netfliksa-ciurkiem/25b10ex](https://businessinsider.com.pl/technologie/zaplaca-25-tys-dol-za-ogladanie-seriali-netfliksa-ciurkiem/25b10ex)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T10:35:44+00:00

Lubisz zarwać noc, żeby obejrzeć na raz cały sezon ulubionego serialu? Masz szansę, żeby ci za to zapłacili. Trwają właśnie poszukiwania ochotnika, który raz na zawsze rozstrzygnie, który serial wyprodukowany przez Netfliksa najmocniej wciąga. Dostanie za to 2,5 tys. dol.

## Ceny ropy zbliżają się do 100 dol. za baryłkę. To dobra wiadomość dla Rosji
 - [https://businessinsider.com.pl/gospodarka/ceny-ropy-zblizaja-sie-do-100-dol-za-barylke-to-dobra-wiadomosc-dla-rosji/thg6n4c](https://businessinsider.com.pl/gospodarka/ceny-ropy-zblizaja-sie-do-100-dol-za-barylke-to-dobra-wiadomosc-dla-rosji/thg6n4c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T10:31:01+00:00

Ceny ropy naftowej zbliżają się do 100 dol. za baryłkę, co utrudnia amerykańskiej Rezerwie Federalnej walkę z inflacją. Zadowolone z tego może być co najmniej jedno państwo: Rosja.

## Kulczyk i jego Ciech wchodzą w zupełnie nowy segment. Chcą sprawić, żeby lepiej nam się spało
 - [https://businessinsider.com.pl/gielda/wiadomosci/sebastian-kulczyk-i-jego-ciech-maja-nowy-biznes-pierwszy-tego-typu/n3h4z78](https://businessinsider.com.pl/gielda/wiadomosci/sebastian-kulczyk-i-jego-ciech-maja-nowy-biznes-pierwszy-tego-typu/n3h4z78)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T10:27:34+00:00

Jeden z najbogatszych biznesmenów zdecydował, że jego firma zadba o dobry sen Polaków. Ciech wprowadził do sprzedaży internetowej nową markę materacy Snoovio. Zakład dysponuje mocami produkcyjnymi na poziomie około 30 tys. ton pianek rocznie.

## Zadłużony jak mieszkaniec Wałbrzycha. Nowy ranking
 - [https://businessinsider.com.pl/wiadomosci/zadluzony-jak-mieszkaniec-walbrzycha-nowy-ranking/4cqht41](https://businessinsider.com.pl/wiadomosci/zadluzony-jak-mieszkaniec-walbrzycha-nowy-ranking/4cqht41)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T09:58:00+00:00

Wałbrzych — mieszkańcy tego miasta znaleźli się na pierwszej pozycji w rankingu najbardziej zadłużonych — wynika z raportu KRD. Wałbrzyszanie mają największe długi w przeliczeniu na mieszkańca, tysiąc mieszkańców. Największy jest także odsetek dłużników wśród wszystkich mieszkańców.

## Polski flagowy produkt eksportowy ma poważne kłopoty. "Jest nadwyżka produkcji"
 - [https://businessinsider.com.pl/gospodarka/polski-flagowy-produkt-eksportowy-ma-powazne-klopoty-jest-nadwyzka-produkcji/vctdxh9](https://businessinsider.com.pl/gospodarka/polski-flagowy-produkt-eksportowy-ma-powazne-klopoty-jest-nadwyzka-produkcji/vctdxh9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T09:57:44+00:00

Rosnące koszty produkcji, brak pracowników sezonowych czy nowe regulacje UE w zakresie Zielonego Ładu i zrównoważonego rozwoju — to największe wyzwania stojące obecnie przed producentami jabłek — wynika ze strategii Unii Owocowej "Jabłkowa Perspektywa 2030".

## Znany producent aut kończy z silnikami Diesla. Lada moment będzie wypuszczał tylko elektryki
 - [https://businessinsider.com.pl/motoryzacja/volvo-konczy-z-silnikami-diesla-lada-moment-bedzie-wypuszczal-tylko-elektryki/hgjjpef](https://businessinsider.com.pl/motoryzacja/volvo-konczy-z-silnikami-diesla-lada-moment-bedzie-wypuszczal-tylko-elektryki/hgjjpef)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T09:48:32+00:00

Volvo zakończy produkcję wszystkich swoich modeli z silnikiem Diesla na początku 2024 r. Producent samochodów ma już też konkretną datę pełnej elektryfikacji.

## Kolejne złe wieści z kluczowego sektora polskiej gospodarki. Brakuje zamówień
 - [https://businessinsider.com.pl/gospodarka/zle-sie-dzieje-w-polskim-przemysle-potezny-spadek-zamowien/46y4s4z](https://businessinsider.com.pl/gospodarka/zle-sie-dzieje-w-polskim-przemysle-potezny-spadek-zamowien/46y4s4z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T09:42:04+00:00

Już 2-proc. spadek produkcji przemysłowej powinien martwić. A okazuje się, że zamówienia w rok zmniejszyły się w tempie dziesięciokrotnie większym. Z najnowszych danych GUS wynika, że o ponad połowę niższa niż przed rokiem była wartość nowych zamówień otrzymanych w produkcji odzieży.

## Sklepy tną liczbę gazetek, stron i promocji. Tylko dyskonty się trzymają
 - [https://businessinsider.com.pl/wiadomosci/sklepy-tna-liczbe-gazetek-stron-i-promocji-tylko-dyskonty-sie-trzymaja/39gvfm2](https://businessinsider.com.pl/wiadomosci/sklepy-tna-liczbe-gazetek-stron-i-promocji-tylko-dyskonty-sie-trzymaja/39gvfm2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T09:07:26+00:00

W I półroczu największe na rynku formaty handlowe ograniczyły liczbę gazetek w porównaniu z analogicznym okresem 2022 r. – o blisko 7 proc., ich stron – o ponad 4 proc., a także powierzchnię – o niecałe 7 proc. Do tego ubyło przeszło 12 proc. promocji. Cięcia są widoczne praktycznie we wszystkich analizowanych formatach, poza małymi wyjątkami.

## Poczta Polska przejmuje drukarnię. "Ma przestarzały park maszynowy"
 - [https://businessinsider.com.pl/gospodarka/poczta-polska-przejmuje-drukarnie-ma-przestarzaly-park-maszynowy/qtgl6bt](https://businessinsider.com.pl/gospodarka/poczta-polska-przejmuje-drukarnie-ma-przestarzaly-park-maszynowy/qtgl6bt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T09:04:44+00:00

Operator pocztowy stał się właścicielem Wojskowych Zakładów Kartograficznych, których zarząd niedawno sygnalizował możliwość utraty płynności – informuje w poniedziałek "Puls Biznesu". Gazeta wskazuje, że przejęcie przedsiębiorstwa, akurat przez Pocztę Polską, która zamykała małe drukarnie, jest sporym zaskoczeniem.

## Jesień rodzi pytania o sezon grzewczy. Tak wygląda stan polskich magazynów gazu
 - [https://businessinsider.com.pl/gospodarka/ile-jest-gazu-w-polskich-magazynach-jesien-rodzi-pytania-o-sezon-grzewczy/jl3fnlj](https://businessinsider.com.pl/gospodarka/ile-jest-gazu-w-polskich-magazynach-jesien-rodzi-pytania-o-sezon-grzewczy/jl3fnlj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T08:56:59+00:00

Weszliśmy już w astronomiczną jesień, a to pora roku, która wiąże się z inauguracją sezonu grzewczego. Jak w tym roku wygląda wypełnienie polskich magazynów gazu? Zajmująca się nimi spółka właśnie zabrała głos.

## Kolejny kraj przyjmie euro. Jest data
 - [https://businessinsider.com.pl/wiadomosci/bulgaria-w-koncu-przyjmie-euro-jest-nowa-data/55ek1x0](https://businessinsider.com.pl/wiadomosci/bulgaria-w-koncu-przyjmie-euro-jest-nowa-data/55ek1x0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T08:41:11+00:00

Bułgaria planowała wejście do strefy euro wraz z Chorwacją na początku tego roku. To się jednak nie udało, nie uda się też od stycznia 2024 r. Jest jednak nowa data.

## Na sprzęt wydajemy miliardy, ale inwestujemy niewiele. Tak wyglądają wydatki na wojsko
 - [https://businessinsider.com.pl/gospodarka/na-sprzet-wydajemy-miliardy-ale-inwestujemy-niewiele-oto-wydatki-na-wojsko/evsy4vt](https://businessinsider.com.pl/gospodarka/na-sprzet-wydajemy-miliardy-ale-inwestujemy-niewiele-oto-wydatki-na-wojsko/evsy4vt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T08:32:44+00:00

Choć Polska wydaje na zbrojenia rekordowe kwoty, to na inwestycje w rodzima zbrojeniówkę wciąż stosunkowo niewiele. Przy setkach miliardów na sprzęt z zagranicy, krajowe zakłady mogą liczyć na ok. 2 mld zł.

## Planowanie przestrzenne. Rząd ogranicza samorządy [OPINIA]
 - [https://businessinsider.com.pl/prawo/opinie/planowanie-przestrzenne-rzad-zamiast-porzadkowac-miesza/mdrsgqh](https://businessinsider.com.pl/prawo/opinie/planowanie-przestrzenne-rzad-zamiast-porzadkowac-miesza/mdrsgqh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T08:26:29+00:00

Choć prowadzenie polityki przestrzennej to tzw. zadania własne każdej z gmin, to rząd i ustawodawca lubią się do niego wtrącać. Z jednej strony twierdzą, że wprowadzają rozwiązania, które usprawnią planowanie, z drugiej ingerują w działania samorządów. I nie chodzi tylko o możliwość budowy domów bez pozwolenia, ale też dużych inwestycji. Dlaczego wyjaśnia radca prawny Wojciech Opiła.

## Co Trzecia Droga zrobi z 800 plus? Kosiniak-Kamysz stanowczy
 - [https://businessinsider.com.pl/wiadomosci/co-trzecia-droga-zrobi-z-800-plus-kosiniak-kamysz-stanowczy/e99z8xr](https://businessinsider.com.pl/wiadomosci/co-trzecia-droga-zrobi-z-800-plus-kosiniak-kamysz-stanowczy/e99z8xr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T08:11:41+00:00

"To, co zostało dane, nie zostanie odebrane" — deklaruje prezes PSL i jeden z liderów Trzeciej Drogi Władysław Kosiniak-Kamysz w kontekście 800 plus. Skomentował przy okazji także słowa Szymona Hołowni, który aż tak przekonany do świadczenia nie był.

## Licznik stopy bezrobocia się zatrzymał, ale osób bez pracy przybyło
 - [https://businessinsider.com.pl/gospodarka/bezrobocie-w-polsce-w-sierpniu-2023-ile-osob-nie-ma-pracy/gmfb1ns](https://businessinsider.com.pl/gospodarka/bezrobocie-w-polsce-w-sierpniu-2023-ile-osob-nie-ma-pracy/gmfb1ns)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T08:00:41+00:00

Bezrobocie w Polsce na koniec sierpnia wyniosło 5 proc. — wynika z najnowszych danych Głównego Urzędu Statystycznego. To trzeci miesiąc z rzędu, gdy wskaźnik przyjmuje tę samą wartość. Wygląda na to, że potencjał do dalszego śrubowania rekordów na rynku pracy się wyczerpał. Tym bardziej że w ciągu miesiąca lekko przybyło osób bez pracy.

## PiS prezentuje nowy spot. "Dwie zagadki" i zmienione logo PO
 - [https://businessinsider.com.pl/gospodarka/pis-prezentuje-nowy-spot-dwie-zagadki-i-zmienione-logo-po/v2j9zpm](https://businessinsider.com.pl/gospodarka/pis-prezentuje-nowy-spot-dwie-zagadki-i-zmienione-logo-po/v2j9zpm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T07:57:19+00:00

W poniedziałek rano Prawo i Sprawiedliwość zamieściło w mediach społecznościowych kolejny spot wyborczy. PiS zarzuciło szefowi PO Donaldowi Tuskowi, że "nie szanuje Polski Wschodniej i nie szanuje ludzi, którzy nie głosują na Platformę Obywatelską".

## Fundacja milionera chce postawić schronisko w górach. Rozmach wzbudza kontrowersje
 - [https://businessinsider.com.pl/wiadomosci/fundacja-milionera-chce-postawic-schronisko-w-gorach-rozmach-wzbudza-kontrowersje/p44n0nz](https://businessinsider.com.pl/wiadomosci/fundacja-milionera-chce-postawic-schronisko-w-gorach-rozmach-wzbudza-kontrowersje/p44n0nz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T07:51:55+00:00

Fundacja Ideanova, której założycielem i prezesem jest milioner Wiesław Cholewa, przymierza się do budowy schroniska w Beskidzie Wyspowym. Inwestycja wzbudza kontrowersje, a jej przeciwnicy wytykają, że to hotel pod przykrywką schroniska.

## "Sztuczne" mięso tanieje. Polska firma wie, jak na tym zarobić
 - [https://businessinsider.com.pl/gospodarka/sztuczne-mieso-tanieje-polska-firma-wie-jak-na-tym-zarobic/b9zrsmz](https://businessinsider.com.pl/gospodarka/sztuczne-mieso-tanieje-polska-firma-wie-jak-na-tym-zarobic/b9zrsmz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T07:39:16+00:00

Pierwszy "sztuczny" burger wytworzony 10 lat temu, kosztował 250 tys. dolarów, obecnie szaszłyk z kurczaka można kupić już za 14 dolarów. Na całym świecie coraz więcej firm angażuje się w produkcję mięsa komórkowego. W tym wyścigu bierze udział też polska firma LabFarm.

## Firma Palikota ujawniła w końcu zaległe sprawozdanie finansowe
 - [https://businessinsider.com.pl/biznes/ile-palikot-zarabia-na-alkoholu-firma-ujawnila-zalegle-sprawozdanie-finansowe/j5mb97z](https://businessinsider.com.pl/biznes/ile-palikot-zarabia-na-alkoholu-firma-ujawnila-zalegle-sprawozdanie-finansowe/j5mb97z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T07:38:33+00:00

Ile Janusz Palikot zarabia na alkoholu? Jego firma Manufaktura Piwa Wódki i Wina ujawniła zaległe sprawozdanie finansowe za 2022 r. Koszty sprzedaży przekroczyły przychody, ale dzięki jednej pozycji, ostatecznie może się pochwalić zyskiem.

## Dorabianie do emerytury. Od czerwca zmiana dla niektórych emerytów
 - [https://businessinsider.com.pl/twoje-pieniadze/dorabianie-do-emerytury-od-czerwca-zmiana-dla-niektorych-emerytow/djphq2f](https://businessinsider.com.pl/twoje-pieniadze/dorabianie-do-emerytury-od-czerwca-zmiana-dla-niektorych-emerytow/djphq2f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T07:30:00+00:00

Od czerwca wprowadzono wyższe limity zarobków dla osób pobierających rentę oraz dla emerytów, którzy przeszli na emeryturę wcześniej - informuje ZUS, jednocześnie wyjaśniając, kiedy świadczenie może zostać tymczasowo wstrzymane.

## W Berlinie, Hamburgu i Monachium ceny mieszkań mocno spadły. Tego wcześniej nie było
 - [https://businessinsider.com.pl/nieruchomosci/mieszkania-w-polsce-coraz-drozsze-moze-zamiast-tego-m3-w-niemczech/08440pc](https://businessinsider.com.pl/nieruchomosci/mieszkania-w-polsce-coraz-drozsze-moze-zamiast-tego-m3-w-niemczech/08440pc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T07:30:00+00:00

Niemiecka gospodarka boryka się z poważnymi problemami, które mają bezpośredni wpływ na tamtejszy rynek nieruchomości. Najświeższe dane dotyczące cen mieszkań wskazują na największy spadek od przynajmniej roku 2000.

## Polska pnie się w "złotym rankingu". NBP wyprzedził już Wielką Brytanię
 - [https://businessinsider.com.pl/wiadomosci/ile-zlota-ma-polska-nbp-wyprzedzil-juz-wielka-brytanie/klvj533](https://businessinsider.com.pl/wiadomosci/ile-zlota-ma-polska-nbp-wyprzedzil-juz-wielka-brytanie/klvj533)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T07:12:53+00:00

Narodowy Bank Polski od miesięcy skupuje złoto. Jak zauważa interia.pl, pod względem posiadanych rezerw kruszcu Polska wyprzedziła już Wielką Brytanię i zbliża się do Arabii Saudyjskiej.

## Kurs franka 25 września poniżej 4,8 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-25-wrzesnia-2023/de47vxd](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-25-wrzesnia-2023/de47vxd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T06:59:24+00:00

Frank szwajcarski poniżej 4,8 zł. W poniedziałek 25 września 2023 r. kurs tej waluty wobec polskiego złotego wynosi 4,7556.

## Kurs dolara 25 września powyżej 4,3 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-25-wrzesnia-2023/eb7ty2x](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-25-wrzesnia-2023/eb7ty2x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T06:58:01+00:00

Kurs dolara w okolicy 4,3 zł. W poniedziałek 25 września 2023 r. rano kurs USD/PLN wynosi 4,3158.

## Chińska bomba zegarowa wciąż tyka. Deweloperski gigant ma ogromne kłopoty
 - [https://businessinsider.com.pl/gospodarka/chinska-bomba-zegarowa-wciaz-tyka-deweloperski-gigant-ma-ogromne-klopoty/h3lptbr](https://businessinsider.com.pl/gospodarka/chinska-bomba-zegarowa-wciaz-tyka-deweloperski-gigant-ma-ogromne-klopoty/h3lptbr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T06:33:23+00:00

Niegdyś najpotężniejszy deweloper świata, a dziś bankrutujący gigant, wciąż ma kłopoty. Chińska firma Evergrande znów notuje giełdową czarną serię, po tym jak poinformowano, że nie jest w stanie emitować nowego długu.

## COVID-19 atakuje Rumunię. Rośnie liczba zakażeń i zgonów
 - [https://businessinsider.com.pl/gospodarka/pandemia-atakuje-rumunie-rosnie-liczba-zakazen-covid-19-i-zgonow/0sjhbwv](https://businessinsider.com.pl/gospodarka/pandemia-atakuje-rumunie-rosnie-liczba-zakazen-covid-19-i-zgonow/0sjhbwv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T06:20:20+00:00

W ciągu minionych dwóch miesięcy w Rumunii liczba tygodniowych potwierdzonych zakażeń COVID-19 wzrosła ponad 25-krotnie – informuje portal Digi24.ro, analizując dane ministerstwa zdrowia. Najnowsze statystyki mówią o ponad 11,2 tys. potwierdzonych przypadkach w ciągu tygodnia.

## Koniec strajku w Hollywood. Netflix i Disney porozumieli się ze scenarzystami
 - [https://businessinsider.com.pl/lifestyle/rozrywka/koniec-strajku-w-hollywood-netflix-i-disney-porozumieli-sie-ze-scenarzystami/6e6zbm6](https://businessinsider.com.pl/lifestyle/rozrywka/koniec-strajku-w-hollywood-netflix-i-disney-porozumieli-sie-ze-scenarzystami/6e6zbm6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T05:52:56+00:00

Strajkujący hollywoodzcy scenarzyści osiągnęli wstępne nowe porozumienie pracownicze ze studiami filmowymi takimi jak Walt Disney. i Netflix. Oznacza to rozstrzygnięcie strajku, który wstrzymał produkcję filmową i telewizyjną.

## Podatek Belki wciąż drenuje kieszenie oszczędnych Polaków. W pół roku fiskus zabrał miliardy
 - [https://businessinsider.com.pl/wiadomosci/podatek-belki-wciaz-drenuje-kieszenie-oszczednych-polakow-w-pol-roku-fiskus-zabral/8x64ppm](https://businessinsider.com.pl/wiadomosci/podatek-belki-wciaz-drenuje-kieszenie-oszczednych-polakow-w-pol-roku-fiskus-zabral/8x64ppm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T05:50:15+00:00

W pierwszej połowie roku wpływy z tzw. podatku Belki wyniosły 5,39 mld zł. To o 28,7 proc. więcej niż w analogicznym okresie 2022 r. A w porównaniu do pierwszego półrocza 2021 r. ostatnio nastąpił wzrost aż o 68,9 proc. Eksperci komentujący ww. dane twierdzą, że podatek ten jest szkodliwy zarówno dla społeczeństwa, jak i dla gospodarki. Jednocześnie dodają, że w kolejnych miesiącach wpływy z tego podatku raczej będą w dalszym ciągu rosły.

## Oto najbogatsza kobieta na świecie. Kim jest Françoise Bettencourt Meyers?
 - [https://businessinsider.com.pl/wiadomosci/francoise-bettencourt-meyers-wnuczka-zalozyciela-loreal-najbogatsza-kobieta/wk23rvn](https://businessinsider.com.pl/wiadomosci/francoise-bettencourt-meyers-wnuczka-zalozyciela-loreal-najbogatsza-kobieta/wk23rvn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T05:27:54+00:00

Françoise Bettencourt Meyers, 70-letnia wnuczka założyciela L'Oreal Eugène'a Schuellera, jest najbogatszą kobietą na świecie według indeksu miliarderów Bloomberga. Oprócz zaangażowania w firmę dziadka, ma swoim koncie ma m.in. kilka książek dotyczących religii czy mitologii. Przez lata nie dogadywała się z matką. Ich złe relacje osiągnęły apogeum, gdy Bettencourt Meyers zainicjowała trwającą dekadę rodzinną kłótnię o spadek.

## Niemcy o polskim wojsku: mają szansę stać się najsilniejszą armią w Europie
 - [https://businessinsider.com.pl/gospodarka/niemcy-o-polskim-wojsku-maja-szanse-stac-sie-najsilniejsza-armia-w-europie/hs9p447](https://businessinsider.com.pl/gospodarka/niemcy-o-polskim-wojsku-maja-szanse-stac-sie-najsilniejsza-armia-w-europie/hs9p447)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T05:21:17+00:00

Jak opisuje niemiecki "Handelsblatt", polska armia ma potencjał, by już wkrótce stać się najsilniejszą w Europie. Choć zauważa też, że potężna modernizacja sił zbrojnych wiąże się z ogromnymi wydatkami z budżetu państwa.

## Afera wizowa. Z kim współpracował Edgar K? Oto ustalenia śledczych
 - [https://businessinsider.com.pl/wiadomosci/afera-wizowa-z-kim-wspolpracowal-edgar-k-oto-ustalenia-sledczych/5flsj3y](https://businessinsider.com.pl/wiadomosci/afera-wizowa-z-kim-wspolpracowal-edgar-k-oto-ustalenia-sledczych/5flsj3y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T05:04:15+00:00

"Rzeczpospolita" odkrywa ustalenia śledczych w sprawie afery wizowej. Dziennik opisuje, kto wymyślił "interes wizowy" według prokuratury.

## Kurs EUR/PLN 25 września 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-25-wrzesnia-2023-r/x1j1ssh](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-25-wrzesnia-2023-r/x1j1ssh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T05:00:01+00:00

Przedstawiamy notowania aktualnego kursu waluty euro z dnia 25 września 2023.  Wczoraj wynosił on: 4,60795 zł. Od kursu uzależnione są ceny importowanych towarów oraz usług. Obecnie euro jest walutą obowiązującą w 20 państwach członkowskich Unii Europejskiej, a także kilku, które nie są jej członkami.

## Strefa euro jest w recesji — dane PMI nie pozostawiają złudzeń
 - [https://businessinsider.com.pl/gospodarka/strefa-euro-jest-w-recesji-dane-pmi-nie-pozostawiaja-zludzen/7ps3r1e](https://businessinsider.com.pl/gospodarka/strefa-euro-jest-w-recesji-dane-pmi-nie-pozostawiaja-zludzen/7ps3r1e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T04:58:19+00:00

Strefa euro wpada w recesję – sugerują to nowe publikacje wskaźników PMI w Europie. U nas za to pojawiają się sygnały ożywienia, na przykład te dotyczące obiegu pieniądza. Ożywieniu powinny też sprzyjać niskie ceny paliw, które jednocześnie powinny przyczynić się do znacznego spadku inflacji we wrześniu. Ze Stanów Zjednoczonych nadeszła z kolei wyczekiwana przez miłośników kina i seriali wiadomość o tym, że strajk scenarzystów wkrótce się zakończy. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Opłata reprograficzna dopadła smartfony. Przełomowy wyrok sądu
 - [https://businessinsider.com.pl/gospodarka/oplata-reprograficzna-dopadla-smartfony-przelomowy-wyrok-sadu/d77dzd1](https://businessinsider.com.pl/gospodarka/oplata-reprograficzna-dopadla-smartfony-przelomowy-wyrok-sadu/d77dzd1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T04:41:37+00:00

Jak opisuje "Dziennik Gazeta Prawna", właśnie zakończył się trwający 13 lat proces w sprawie opłaty reprograficznej. Firmy technologiczne mogą nie być zadowolone. Precedensowy wyrok pozwala organizacjom zbiorowego zarządzania domagać się miliardów złotych do dziesięciu lat wstecz — wskazuje gazeta.

## Ruszyła duża reforma. Czy warunki zabudowy stracą ważność? Sprawdź, co się zmieni
 - [https://businessinsider.com.pl/prawo/ruszyla-wielka-reforma-planowania-przestrzennego-co-sie-stanie-z-warunkami-zabudowy/fql0dbg](https://businessinsider.com.pl/prawo/ruszyla-wielka-reforma-planowania-przestrzennego-co-sie-stanie-z-warunkami-zabudowy/fql0dbg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T04:33:00+00:00

W niedzielę 24 września ruszyła reforma planowania przestrzennego. Do grudnia 2025 r. każda gmina powinna mieć uchwalony plan ogólny, który określi, co i gdzie można budować. Jeśli go nie uchwali, nie będzie mogła wydawać decyzji o warunkach zabudowy. Co stanie się z już wydanymi tzw. wuzetkami?

## Od niedzieli rewolucja w przepisach. Budujesz? Sprawdź, co się zmieni
 - [https://businessinsider.com.pl/prawo/rewolucja-w-planowaniu-przestrzennym-sprawdz-co-sie-zmienilo/k72lk6e](https://businessinsider.com.pl/prawo/rewolucja-w-planowaniu-przestrzennym-sprawdz-co-sie-zmienilo/k72lk6e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T04:27:00+00:00

Eksperci nie mają wątpliwości. W niedzielę 24 września ruszyła największa reforma planowania przestrzennego od lat. Za jej sprawą do stycznia 2026 r. każda gmina ma mieć uchwalony plan ogólny. To będzie e-dokument, który określi, co i gdzie można budować. Tam, gdzie go nie będzie, nie będą wydawane warunki zabudowy. Zmian jest o wiele więcej i dotkną one nie tylko gminy, ale również zwykłego Kowalskiego.

## KSeF dla zwolnionych z VAT jednak wcześniej? Wyjaśniamy
 - [https://businessinsider.com.pl/prawo/podatki/od-kiedy-ksef-dla-podatnikow-zwolnionych-z-vat-wyjasniamy/qv7t4mn](https://businessinsider.com.pl/prawo/podatki/od-kiedy-ksef-dla-podatnikow-zwolnionych-z-vat-wyjasniamy/qv7t4mn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T04:25:36+00:00

Podatnicy zwolnieni z VAT będą musieli przystąpić do obowiązkowego Krajowego Systemu e-Faktur od 2025 r. Tak wynika z przepisów. Eksperci tłumaczą jednak, że stanie się to wcześniej. Wszyscy będą stosować obowiązkowy KSeF już od 1 lipca 2024 r. Dlaczego?

## Nie zamówisz jedzenia online ani nie weźmiesz Ubera? Zbliża się rewolucja w prawie
 - [https://businessinsider.com.pl/gospodarka/nie-zamowisz-jedzenia-online-nie-wezmiesz-ubera-zbliza-sie-rewolucja-w-prawie/h6z3jz6](https://businessinsider.com.pl/gospodarka/nie-zamowisz-jedzenia-online-nie-wezmiesz-ubera-zbliza-sie-rewolucja-w-prawie/h6z3jz6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T04:22:57+00:00

Jak donosi "Rzeczpospolita", już wkrótce z branży transportu osób i dowozu posiłków, może odejść nawet 70 proc. pracujących tam osób. Wszystko z powodu planowanych unijnych regulacji.

## Tak prezesi państwowych spółek płacą na PiS. Kwoty idą już w miliony
 - [https://businessinsider.com.pl/wiadomosci/miliony-ze-spolek-na-partyjne-konta-pis-tak-placa-prezesi-panstwowych-firm/h4td31b](https://businessinsider.com.pl/wiadomosci/miliony-ze-spolek-na-partyjne-konta-pis-tak-placa-prezesi-panstwowych-firm/h4td31b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T04:19:30+00:00

W nieco ponad rok prezesi oraz członkowie zarządów i rad nadzorczych spółek Skarbu Państwa przelali na konta Prawa i Sprawiedliwości prawie 2,5 mln zł. Business Insider Polska przeanalizował rejestr wpłat na rzecz partii rządzącej. Najhojniej konta obozu władzy zasilali menedżerowie z sektora energetycznego. Duże przelewy szły też od ludzi z PZU i spółek zależnych państwowego ubezpieczyciela.

## Biedronka nie Orlen, ceny nie chcą spadać [Koszyk zakupowy Business Insidera i aplikacji PanParagon]
 - [https://businessinsider.com.pl/poradnik-finansowy/biedronka-nie-orlen-ceny-nie-chca-spadac/2hr2lyt](https://businessinsider.com.pl/poradnik-finansowy/biedronka-nie-orlen-ceny-nie-chca-spadac/2hr2lyt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T04:07:00+00:00

Gdy kierowcy tankują paliwo, doświadczają "cudu" przy dystrybutorze. Niestety, gdy pojadą na zakupy do dyskontu czy supermarketu, magii już nie doświadczą. Podstawowe produkty żywnościowe są tylko minimalnie tańsze niż przed tygodniem.

## Konkrety? Jakie konkrety? Oto lista tego, co partie przed nami ukrywają [OPINIA]
 - [https://businessinsider.com.pl/wiadomosci/oto-lista-tego-co-partie-przed-nami-ukrywaja-opinia/w6xzfhe](https://businessinsider.com.pl/wiadomosci/oto-lista-tego-co-partie-przed-nami-ukrywaja-opinia/w6xzfhe)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-09-25T04:04:00+00:00

Czuję się trochę jak na rozmowie kwalifikacyjnej, gdy mój rozmówca opowiada mi o fantastycznych wizjach mojej kariery i o tym, co wspaniałego mogę zrobić w firmie. Ja się pytam z kolei, ile będę zarabiał, jaka będzie forma mojego zatrudnienia i kto będzie moim szefem. I nastaje cisza.

