# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Astronauts Need a Better Sunscreen
 - [https://www.youtube.com/watch?v=va9zF9KdxXg](https://www.youtube.com/watch?v=va9zF9KdxXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2023-09-25T21:00:24+00:00

Space is a dangerous place. One of the many dangers comes in the form of radiation. On Earth, sunscreen helps shield our bodies. But astronauts on the ISS, or eventually on the Moon/Mars/etc., will have to be rocking some suped-up sunblock.

Head over to https://store.dftba.com/collections/scishow to check out our space balloon stickers and monthly space pins!

Hosted by: Hank Green (he/him)
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Adam Brainard, Alex Hackman, Ash, Bryan Cloer, charles george, Chris Mackey, Chris Peters, Christoph Schwanke, Christopher R Boucher, Dr. Melvin Sanicas, Harrison Mills, Jaap Westera, Jason A Saslow, Jeffrey Mckishen, Jeremy Mattern, Kevin Bealer, Matt Curls, Michelle Dove, Piya Shedden, Rizwan Kassim, Sam Lutfi
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podca

