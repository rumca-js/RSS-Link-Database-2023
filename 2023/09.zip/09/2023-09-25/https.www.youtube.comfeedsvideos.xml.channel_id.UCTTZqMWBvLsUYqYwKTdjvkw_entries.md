# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 💬 Odpowiedź TikToka na karę
 - [https://www.youtube.com/watch?v=aPaAECUDgHY](https://www.youtube.com/watch?v=aPaAECUDgHY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-09-25T04:30:00+00:00

TikTok postanowił odpowiedzieć na nałożoną przez UE karę.
 
Źródła:
https://tinyurl.com/4u3mcdep
 
#TikTok #prywatność #kara #Unia

