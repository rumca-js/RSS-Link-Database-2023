# Source:Techdirt, URL:https://www.techdirt.com/feed/, language:en-US

## Co-Sponsor Of Unconstitutional AADC Law Completely Misrepresents Court’s Ruling, Showing His Lack Of Attention To Detail
 - [https://www.techdirt.com/2023/09/25/co-sponsor-of-unconstitutional-aadc-law-completely-misrepresents-courts-ruling-showing-his-lack-of-attention-to-detail/](https://www.techdirt.com/2023/09/25/co-sponsor-of-unconstitutional-aadc-law-completely-misrepresents-courts-ruling-showing-his-lack-of-attention-to-detail/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-09-25T22:37:20+00:00

Last week, we wrote about a federal district judge in California, Beth Labson Freeman, tossing out California’s Age Appropriate Design Code (AB 2273) as unconstitutional under the 1st Amendment. The ruling was careful and thorough, which did not surprise me, having sat through the oral arguments on the matter, where it seemed that the judge [&#8230;]

## After Passing Online Safety Bill, UK Government Gets Back To Harassing Meta About Its End-To-End Encryption
 - [https://www.techdirt.com/2023/09/25/after-passing-online-safety-bill-uk-government-gets-back-to-harassing-meta-about-its-end-to-end-encryption/](https://www.techdirt.com/2023/09/25/after-passing-online-safety-bill-uk-government-gets-back-to-harassing-meta-about-its-end-to-end-encryption/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-09-25T20:31:10+00:00

Last week, it appeared ever so briefly, the UK government might be finally giving up on its desires to legislate at least one end of messaging services&#8217; end-to-end encryption. Having faced resistance from nearly every encrypted service (all of which threatened to exit the UK if anti-encryption mandates were put in place) as well as [&#8230;]

## With Basically Zero Press Coverage At All, California Assembly Passes Its Own Version Of FOSTA
 - [https://www.techdirt.com/2023/09/25/with-basically-zero-press-coverage-at-all-california-assembly-passes-its-own-version-of-fosta/](https://www.techdirt.com/2023/09/25/with-basically-zero-press-coverage-at-all-california-assembly-passes-its-own-version-of-fosta/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-09-25T19:01:01+00:00

It is quite incredible to me how, over the last five years or so, the California legislature has pushed over a dozen absolutely horrific, dangerous (and often unconstitutional) laws to completely undermine the very principles of an open internet… and it gets basically no attention at all. Last year, it felt like we at Techdirt [&#8230;]

## Federal Judge Says Fuck The 1st Amendment While Upholding Public University’s Drag Show Ban
 - [https://www.techdirt.com/2023/09/25/federal-judge-says-fuck-the-1st-amendment-while-upholding-public-universitys-drag-show-ban/](https://www.techdirt.com/2023/09/25/federal-judge-says-fuck-the-1st-amendment-while-upholding-public-universitys-drag-show-ban/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-09-25T17:56:11+00:00

Most laws and policies banning drag shows are experiencing swift judicial blowback thanks to their obvious regulation of expressive speech. Some legislators have attempted to work around this expected roadblock to oppression by avoiding any mention of drag shows or drag performers when crafting unconstitutional laws, instead pretending they&#8217;re simply strengthening existing obscenity laws. None [&#8230;]

## Daily Deal: The Big Data And Analytics Master Toolkit
 - [https://www.techdirt.com/2023/09/25/daily-deal-the-big-data-and-analytics-master-toolkit/](https://www.techdirt.com/2023/09/25/daily-deal-the-big-data-and-analytics-master-toolkit/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-09-25T17:51:11+00:00

Most modern companies put a lot of stock into data when making crucial business decisions. As such, they require employees who understand how to work with mass amounts of data, and effectively analyze it to get a holistic view of the company. These skills aren&#8217;t just reserved for analysts, they&#8217;re valuable for professionals in any [&#8230;]

## Can Google Be Held Liable For Man Who Died Following Google Maps Over A Collapsed Bridge?
 - [https://www.techdirt.com/2023/09/25/can-google-be-held-liable-for-man-who-died-following-google-maps-over-a-collapsed-bridge/](https://www.techdirt.com/2023/09/25/can-google-be-held-liable-for-man-who-died-following-google-maps-over-a-collapsed-bridge/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-09-25T16:26:00+00:00

There’s a pretty well known scene from The Office, when Michael Scott (played by Steve Carrell) follows his GPS device’s instructions (incorrectly, obviously) and drives into a lake: The writer of that scene says the inspiration was a number of stories of people doing exactly that. In fact, in the earlier days of Techdirt, we [&#8230;]

## Activists Say California Is Backtracking On Plan For Statewide Affordable Broadband
 - [https://www.techdirt.com/2023/09/25/activists-get-california-to-backtrack-on-plan-to-cut-broadband-funding-for-low-income-minority-neighborhoods/](https://www.techdirt.com/2023/09/25/activists-get-california-to-backtrack-on-plan-to-cut-broadband-funding-for-low-income-minority-neighborhoods/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-09-25T12:20:00+00:00

While the California legislature often screws up tech policy, they&#8217;ve generally been pretty good on broadband. At least in relation to most U.S. states. California was among the first in the country to pass a net neutrality law after the telecom industry got Trumpists to dismantle federal rules. The state also unveiled a major broadband [&#8230;]

