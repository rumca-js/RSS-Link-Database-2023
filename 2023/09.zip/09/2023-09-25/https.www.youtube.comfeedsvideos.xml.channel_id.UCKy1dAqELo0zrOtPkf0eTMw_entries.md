# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Rick and Morty Season 7 Trailer Reveals New Voices For The Duo - IGN The Fix: Entertainment
 - [https://www.youtube.com/watch?v=H2H1kwE_WoE](https://www.youtube.com/watch?v=H2H1kwE_WoE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T23:14:05+00:00

In the new trailer for Rick and Morty season 7, the two titular characters’ new voices have finally spoken - and so have the fans. The reception? Mixed. But I’ll let you be the judge! We confirmed here at IGN that Adult Swim has no plans of releasing the names of the actors who are now playing #RickandMorty. According to sources they, “...want the show to speak for itself. We believe in the strength of the season and our new voices and we want to preserve the viewing experience for fans.” So fans will find out who the voices are behind the titular heroes during the show’s premiere come October 15th on #AdultSwim. The WGA might’ve just struck a deal to end the ongoing writer’s strike, and Martin Scorcese is yelling at the clouds yet again - find out why in today’s fix.

#IGN

## Sony Hack: Hackers Claim They’ve Breached All Systems - IGN Daily Fix
 - [https://www.youtube.com/watch?v=mc5vt2-h8i4](https://www.youtube.com/watch?v=mc5vt2-h8i4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T23:06:05+00:00

A relatively new hacking group claims to have breached all of Sony's systems and is selling the data, in a move reminiscent of the 2011 Sony hack that compromised millions of  users' data. And there was also the 2014 hack of Sony Pictures, which leaked info that made North Korea mad. Sony can't catch a break, huh? In related Sony news, new PS5 owners can download a free Sony-published game. Might not be a bad time to grab Spider-Man Remastered or Miles Morales before Spider-Man 2 drops next month. In Star Wars news, fans of Knights of the Old Republic 2: The Sith Lords are suing the developer and publisher of the Switch port.  The port was released last year, and though it's a competent and well-made port, it's missing DLC that the publisher promised would make it's way to the game. Well it didn't, and KOTOR fans are big mad. And finally, game developer Hideki Kamiya, probably most famous for the Bayonetta series and Devil May Cry, is leaving PlatinumGames. The split apparently is mu

## The new voices of Rick and Morty have finally been revealed! #rickandmorty #adultswim
 - [https://www.youtube.com/watch?v=Z_kC_dmb-P8](https://www.youtube.com/watch?v=Z_kC_dmb-P8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T22:57:52+00:00



## Yuri Lowenthal on IGN’s 30-second show! #gaming #spiderman2ps5 #spiderman #yurilowenthal #superman
 - [https://www.youtube.com/watch?v=eZ7zRmp5NAg](https://www.youtube.com/watch?v=eZ7zRmp5NAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T22:04:38+00:00



## Mortal Kombat 1 - Johnny Cage Starter Guide
 - [https://www.youtube.com/watch?v=l5BmH3BR-V8](https://www.youtube.com/watch?v=l5BmH3BR-V8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T21:52:50+00:00

Wanna learn how to do 50% damage combos with Johnny Cage? What Kameo to pair with his playstyle? We've got you covered in this starter guide for Johnny Cage illustrating his best normals, classic Mortal Kombat 1 Johnny Cage combos, and much more. Starter guide courtesy of De'Angelo Epps.

#IGN #Gaming #MortalKombat

## Mortal Kombat 1 - Scorpion Starter Guide
 - [https://www.youtube.com/watch?v=srteO5hY9Zs](https://www.youtube.com/watch?v=srteO5hY9Zs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T21:15:14+00:00

Scorpion is one of the most iconic characters in Mortal Kombat history, but his MK1 iteration is actually fairly different from any of his prior appearances. Check out our guide from Michael Townsend on how to properly use Scorpion's unique tools, how to perform some bread and butter combos, and what Kameos pair well with him.

#IGN #Gaming #MortalKombat

## FPS: First Person Shooter - Special Duke Nukem Preview (2023) FPS Documentary
 - [https://www.youtube.com/watch?v=Tn39VXApNcU](https://www.youtube.com/watch?v=Tn39VXApNcU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T19:00:26+00:00

Get the rest of the documentary here: https://store.ign.com/products/fps-documentary-extra

The full documentary film + extras is for sale DRM-free at the IGN Store for a limited time only: https://store.ign.com/products/fps-documentary-extra

#IGN

## Cyberpunk 2077 2.0 - 11 Tips for Rusty and Returning Players
 - [https://www.youtube.com/watch?v=ydBd5GOciBs](https://www.youtube.com/watch?v=ydBd5GOciBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T18:13:19+00:00

It’s been nearly three years since we first entered Cyberpunk 2077’s Night City, and a LOT has changed. Over the years, CD Projekt Red has continued to make huge updates and improvements to shape Night City into what it is today. And now it’s received its biggest overhaul yet with the free Cyberpunk 2.0 update and the $30 Phantom Liberty expansion. If its been a while since you cruised the neon-dripped streets of Night City, here’s a handy refresher. In this video, we’ll rehash some of the basic mechanics of Cyberpunk 2077, and clue you in on some of the best features that have been released since you’ve been away.

#IGN

## Marvel Studios’ Loki Season 2 - Official Behind the Scenes (2023) Tom Hiddleston, Kevin Fiege
 - [https://www.youtube.com/watch?v=uKLDMSZgzgE](https://www.youtube.com/watch?v=uKLDMSZgzgE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T17:00:38+00:00

Join Tom Hiddleston, Kevin Fiege, and Kevin R Wright as they reminisce on Loki's role in the Marvel Cinematic Universe. This featurette briefly recaps the God of Mischief's journey from 2011 with Thor to 2023 with Season 2 of Loki. 

Loki Season 2 stars Tom Hiddleston (Loki), Owen Wilson (Mobius), Sophia Di Martino (Sylvie), Ke Huy Quan, Gugu Mbatha-Raw (Ravonna Renslayer), Tara Strong (Miss Minutes), Wunmi Mosaku (Hunter B-15) and more. The series was created by Michael Waldron with Kevin R. Wright and Tom Hiddleston as executive producers. 

Loki Season 2 will now start streaming on Disney Plus on October 5 at 6 PM PT.

#IGN #Marvel #Loki

## Mineko's Night Market Review
 - [https://www.youtube.com/watch?v=n4dhFisfTjg](https://www.youtube.com/watch?v=n4dhFisfTjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T16:00:41+00:00

Mineko's Night Market reviewed on PC by Carli Velocci; narrated by Seth G Macy. Also available on Nintendo Switch.

Disclosure: Humble Bundle is owned by Ziff Davis, the parent company of IGN. Humble Bundle and IGN operate completely independently, and no special consideration is given to Humble Bundle products for coverage.

Mineko’s Night Market is an adorable little sim that could’ve been cozy, but is mostly just boring chores that don’t reward you in the kinds of satisfying ways we see in other popular games in this relaxed genre. After putting you to work, it doesn’t let up, trapping you in a grind of gathering resources and making crafts for lifeless NPCs. Beyond some purring cats, gorgeous artwork, and a handful of legitimately funny bits, it doesn’t provide anything to make all your work worth it.

#MinekosNightMarket #IGN #Review

## Scooby-Doo! and Krypto, Too! Exclusive Clip (2023) Frank Welker, Charles Halford
 - [https://www.youtube.com/watch?v=Be-D0l2dJrA](https://www.youtube.com/watch?v=Be-D0l2dJrA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T16:00:18+00:00

The Mystery Inc. gang encounters DC supervillain Lex Luthor in this scene from the animated movie Scooby-Doo! and Krypto, Too!.

The world's greatest heroes, DC’s Justice League, have mysteriously vanished and a terrifying phantom has taken up residence in The Hall of Justice. Now it's up to the world's greatest super sleuths, Scooby and the gang, to solve the mystery and save our heroes...with a little help from their new pal Krypto the Superdog!

Returning as the voices of the Scooby gang are Frank Welker as Scooby-Doo and Fred Jones, Matthew Lillard as Shaggy Rogers, Kate Micucci as Velma Dinkley and Grey Delisle as Daphne Blake as well as Wonder Woman. Also featured in the voice cast are P.J. Byrne as J.B., Victoria Grace as Mercy, Charles Halford as Lex Luthor, Nolan North as the Joker and Superman, Tara Strong as Helen, Lois Lane and Harley Quinn, Fred Tatasciore as Solomon Grundy and Perry White, James Arnold Taylor as Jimmy Olsen and Rex Ruthor and Niccole Thurman as Mayor Fl

## Alan Wake 2: Building The Remedy Connected Universe - IGN First
 - [https://www.youtube.com/watch?v=2VxT1TwWI0E](https://www.youtube.com/watch?v=2VxT1TwWI0E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T15:44:25+00:00

Alan Wake 2's creative director, Sam Lake, explains how the upcoming survival horror connects to previous Remedy games, from Control to (sort of) Max Payne.

Join us on September 26 at 9am PT/ 12pm ET/ 5pm UK/ September 27 at 2am AEST to learn more. Stick with IGN for more Alan Wake 2 gameplay, interviews, and more.

#IGN #Gaming #AlanWake

## Can We Smoke Smoke in MK1? - Yuri Lowenthal Interview & Gameplay Session
 - [https://www.youtube.com/watch?v=wfHctYJ_UkI](https://www.youtube.com/watch?v=wfHctYJ_UkI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T15:00:52+00:00

Smoke from Mortal Kombat 1, Yuri Lowenthal, joins Akeem in the IGN studio for an MK 1 gameplay session. Yuri Lowenthal has voiced many animated and video game characters, with his latest being Smoke from the Mortal Kombat video game series. Smoke makes his return in #MortalKombatOne, although he's been part of the Mortal Kombat franchise for many years, even decades. Does he have what it takes to deliver a Fatality to his #MK1 'Kombatant? We put his fighting video game skills to the test in #MortalKombat1.

## The Top 100 TV Shows of All Time | State of Streaming
 - [https://www.youtube.com/watch?v=OJP0BP0JRO4](https://www.youtube.com/watch?v=OJP0BP0JRO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T15:00:30+00:00

How do you break down what makes the ideal television show? It’s not easy, given the fact that each person has their own individual taste. We reached out to our entertainment-centric staffers and critics from across the industry to vote on our Top 100 TV Shows of all time. You can check out  ign.com for the full list of criteria. Whether you spend all your time bingeing I Love Lucy reruns or you can't stop rewatching Breaking Bad, you're guaranteed to find something on our list for you.

But was it The Simpsons, The Wire, Game of Thrones, The Sopranos, or something else entirely that made our number 1 slot? Did a sitcom like Parks and Recreation or Friends sneak in there? Or did the crown go to one of the animated gems like Avatar: The Last Airbender or Batman: The Original series? Maybe the highest honors even went to a procedural like Law & Order! You'll just have to tune in to see.

#Top100TVShowsOfAllTime #Top100 #TVShows #StateOfStreaming

## Cyberpunk 2077: Phantom Liberty - Official Launch Trailer
 - [https://www.youtube.com/watch?v=yz3EIdaPbss](https://www.youtube.com/watch?v=yz3EIdaPbss)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T13:27:41+00:00

Cyberpunk 2077: Phantom Liberty is the latest and last expansion for the first-person open-world RPG developed by CD Project Red. Players will return as the mercenary V to take on a special mission to save the NUSA President. This spy-thriller expansion takes players to the new Dogtown where players must make risky alliances within the network of characters wrapped in nefarious political situations. Cyberpunk 2077: Phantom Liberty is available now on PlayStation 5, Xbox Series S|X, and PC.

#IGN #Gaming #Cyberpunk2077

## Cyberpunk 2077 2.0 - How to Start the Phantom Liberty Expansion
 - [https://www.youtube.com/watch?v=simdusxzHwA](https://www.youtube.com/watch?v=simdusxzHwA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T11:00:50+00:00

Cyberpunk 2077’s Phantom Liberty expansion is finally here! You’ll be exploring the lawless district of Dogtown in Night City and making new friends and enemies. Whether you’re a returning player or a new one looking to dive into Dogtown, we’ve got you covered on how to find and enter Dogtown to start Phantom Liberty.

#Cyberpunk2077PhantomLiberty #DLC

## Cyberpunk 2077: Phantom Liberty Review
 - [https://www.youtube.com/watch?v=ZXYn-Fn9w48](https://www.youtube.com/watch?v=ZXYn-Fn9w48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T11:00:35+00:00

Cyberpunk 2077: Phantom Liberty reviewed by Matt Kim on PC. Also available on PlayStation 5, Xbox Series X|S.

Last year, I said in my review of Cyberpunk Edgerunners that CDPR now has a blueprint for where to go with Cyberpunk 2077, and Phantom Liberty shows the studio already had exactly that in mind. Between a more sophisticated level of storytelling with excellent performances, smarter insights on the cyberpunk genre and its dystopian themes, and landing on top of a much-improved gameplay experience thanks to its fresh 2.0 update, Phantom Liberty marks a new chapter for Cyberpunk 2077 and is finally close to what I’d hoped it would be when I first sat down to play three years ago.

#Cyberpunk2077PhantomLiberty #Review

## The First 19 Minutes of Cyberpunk 2077 Phantom Liberty
 - [https://www.youtube.com/watch?v=Y8J0TX5iWaA](https://www.youtube.com/watch?v=Y8J0TX5iWaA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T11:00:24+00:00

The first 19 minutes of Cyberpunk 2077 Phantom Liberty in 4K 60FPS with max settings on PC. The game is running at 4K with DLSS set to performance with a target of 60fps. The Cyberpunk 2077 2.0 update has already had many interested in the expansion, and now it is here. Running on a 4.2 GHz AMD Ryzen 9 7950X3D, 64 GB DDR5-6600 CL32 Memory, and the Gigabyte RTX 4090 24 GB Video Card, this is the first 21 minutes of Cyberpunk 2077 Phantom Liberty.

Subscribe to IGN for more!
http://www.youtube.com/user/IGNentertainment?sub_confirmation=1

------------------------------ ----
Watch more on IGN here!
------------------------------ ----

DAILY FIX: https://www.youtube.com/watch?v=-_e1aXYckPE&amp;list=PLraFbwCoisJCYFqFP7e7UQnHHZL05LooZ&amp;index=2&amp;t=0s
GAME REVIEWS: https://www.youtube.com/watch?v=pCJmeQyJk1E&amp;list=PLraFbwCoisJBTl0oXn8UoUam5HXWUZ7ES&amp;t=0s&amp;index=2
MOVIE REVIEWS: https://www.youtube.com/watch?v=pCJmeQyJk1E&amp;list=PLraFbwCoisJBTl0oXn8UoUam5HXWUZ7ES&amp;t=0s&amp

## Temtem - Official Season 5: Endless Night Overview Trailer
 - [https://www.youtube.com/watch?v=NvG60SslCSw](https://www.youtube.com/watch?v=NvG60SslCSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T07:00:14+00:00

Watch the trailer for a deep dive into what you can expect in Temtem's Season 5: Endless Night. Season 5 of Temtem brings a new route, lair multiplayer and trading updates, casual dojo rematches, a new randomized challenge, Freetem updates, and more to the massively multiplayer creature collection game.

Feel the heat of a brand-new Route in Temtem Season 5: Endless Night. Gather up your party to brave a new Mythical Lair. And are you ready for a mysterious new kind of Temtem?

Temtem's Season 5: Endless Night is available now.

#Temtem #Season5 #EndlessNight

## FPS: First Person Shooter - Special Doom Preview (2023) FPS Documentary
 - [https://www.youtube.com/watch?v=HlclPSqaU0Y](https://www.youtube.com/watch?v=HlclPSqaU0Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-09-25T04:30:11+00:00

Get the rest of the documentary here: https://store.ign.com/products/fps-documentary-extra

The full documentary film + extras is for sale DRM-free at the IGN Store for a limited time only: https://store.ign.com/products/fps-documentary-extra

#IGN

