# Source:SAMTIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw, language:en-US

## If Steve Jobs Designed the iPhone 15
 - [https://www.youtube.com/watch?v=0ArgicRt_BQ](https://www.youtube.com/watch?v=0ArgicRt_BQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw
 - date published: 2023-09-25T16:00:00+00:00

How would Steve Jobs have designed the iPhone 15? Let’s find out!

iPhone 15 Pro PARODY: https://youtu.be/egIrNbkb3sc

SUPPORT: https://funkytime.tv/patriot-signup/
MERCH: https://funkytime.tv/shop/
FUNKY TIME WEBSITE: https://funkytime.tv

FACEBOOK: http://www.facebook.com/SamtimeNews
TWITTER: http://twitter.com/SamtimeNews
INSTAGRAM: http://instagram.com/samtimenews

-----------------------------------

'Escape the ordinary. Embrace the FUNKY!'

-----------------------------------

For sponsorship enquiries: samtime@bossmgmtgrp.com
For other business enquiries: business@funkytime.tv
Copyright FUNKY TIME PRODUCTIONS 2023

