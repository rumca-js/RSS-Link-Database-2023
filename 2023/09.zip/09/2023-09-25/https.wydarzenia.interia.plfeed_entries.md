# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Akcja saperów w Zielonej Górze. Mieszkańcom zagrażają bomby lotnicze
 - [https://wydarzenia.interia.pl/lubuskie/news-akcja-saperow-w-zielonej-gorze-mieszkancom-zagrazaja-bomby-l,nId,7048890](https://wydarzenia.interia.pl/lubuskie/news-akcja-saperow-w-zielonej-gorze-mieszkancom-zagrazaja-bomby-l,nId,7048890)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T20:31:31+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-akcja-saperow-w-zielonej-gorze-mieszkancom-zagrazaja-bomby-l,nId,7048890"><img align="left" alt="Akcja saperów w Zielonej Górze. Mieszkańcom zagrażają bomby lotnicze" src="https://i.iplsc.com/akcja-saperow-w-zielonej-gorze-mieszkancom-zagrazaja-bomby-l/000HPGW4TLK1E1UB-C321.jpg" /></a>Już we wtorek rano do akcji w Zielonej Górze wkroczą saperzy, a wszystko przez bomby lotnicze z czasów II wojny światowej, które odnaleziono przy jednej z zielonogórskich ulic. Z uwagi na zagrożenie wyznaczono specjalną strefę i zarządzono ewakuację mieszkańców. Ta rozpocznie się o godzinie 7:30. Służby apelują o stosowanie się do wydawanych w komunikatach poleceń. Ile potrwa akcja usuwania zlokalizowanych w mieście niewybuchów? Obecnie nie wiadomo.</p><br clear="all" />

## Zełenski zaskoczył w sprawie zboża. Możliwy przełom?
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-zaskoczyl-w-sprawie-zboza-mozliwy-przelom,nId,7048893](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-zaskoczyl-w-sprawie-zboza-mozliwy-przelom,nId,7048893)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T20:21:51+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-zaskoczyl-w-sprawie-zboza-mozliwy-przelom,nId,7048893"><img align="left" alt="Zełenski zaskoczył w sprawie zboża. Możliwy przełom?" src="https://i.iplsc.com/zelenski-zaskoczyl-w-sprawie-zboza-mozliwy-przelom/000H397S5QBDXK4S-C321.jpg" /></a>Wołodymyr Zełenski podsumował naradę z członkami rządu. Poruszono m.in. temat napiętych stosunków z sąsiadami w związku z kryzysem zbożowym. - Stopniowo pozbywamy się emocji wokół tematu zboża, praca z sąsiadami musi stać się konstruktywna - oświadczył. Jak zaznaczył, proces postępuje &quot;stopniowo&quot;, a Ukraina &quot;robi w tym celu wszystko&quot;.</p><br clear="all" />

## Wyjątkowa narośl na drzewach. Leśnicy pokazali zdjęcie
 - [https://wydarzenia.interia.pl/malopolskie/news-wyjatkowa-narosl-na-drzewach-lesnicy-pokazali-zdjecie,nId,7048881](https://wydarzenia.interia.pl/malopolskie/news-wyjatkowa-narosl-na-drzewach-lesnicy-pokazali-zdjecie,nId,7048881)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T20:07:57+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-wyjatkowa-narosl-na-drzewach-lesnicy-pokazali-zdjecie,nId,7048881"><img align="left" alt="Wyjątkowa narośl na drzewach. Leśnicy pokazali zdjęcie" src="https://i.iplsc.com/wyjatkowa-narosl-na-drzewach-lesnicy-pokazali-zdjecie/000HPGTISW66DABP-C321.jpg" /></a>Tatrzański Park Narodowy udostępnił zdjęcie porostów, które pokryły drzewa na terenie parku. Tajemnicza narośl to &quot;brodaczka o krzaczkowatym kształcie&quot;. Jej obecność świadczy o bardzo czystym powietrzu. &quot;Szkoda jednak, że wciąż tak rzadko można je dostrzec&quot; - skomentowała jedna z internautek. </p><br clear="all" />

## Łukaszenka zawłaszcza niebo, uderzając w zwykłych ludzi. Mają pół roku
 - [https://wydarzenia.interia.pl/zagranica/news-lukaszenka-zawlaszcza-niebo-uderzajac-w-zwyklych-ludzi-maja-,nId,7048848](https://wydarzenia.interia.pl/zagranica/news-lukaszenka-zawlaszcza-niebo-uderzajac-w-zwyklych-ludzi-maja-,nId,7048848)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T19:19:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lukaszenka-zawlaszcza-niebo-uderzajac-w-zwyklych-ludzi-maja-,nId,7048848"><img align="left" alt="Łukaszenka zawłaszcza niebo, uderzając w zwykłych ludzi. Mają pół roku" src="https://i.iplsc.com/lukaszenka-zawlaszcza-niebo-uderzajac-w-zwyklych-ludzi-maja/000HPGOL2CKTEKNJ-C321.jpg" /></a>Samozwańczy prezydent Białorusi Alaksandr Łukaszenka podpisał nowy dekret, nakładając na osoby fizyczne zakaz przechowywania, obrotu, eksploatacji i produkcji dronów. Teraz dozwolone będzie to jedynie w przypadku organizacji i osób, które uzyskają specjalne zezwolenie. Ustawa traktuje także o stworzeniu specjalnego rejestru. Zwykłym obywatelom pozostało sprzedać lub oddać swoje bezzałogowe statki powietrzne &quot;na przechowanie&quot; wskazanym przez rząd podmiotom - mają na to sześć miesięcy.</p><br clear="all" />

## Ukraińcy potwierdzają. Zginął dowódca Floty Czarnomorskiej
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraincy-potwierdzaja-zginal-dowodca-floty-czarnomorskiej,nId,7048833](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraincy-potwierdzaja-zginal-dowodca-floty-czarnomorskiej,nId,7048833)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T18:51:48+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraincy-potwierdzaja-zginal-dowodca-floty-czarnomorskiej,nId,7048833"><img align="left" alt="Ukraińcy potwierdzają. Zginął dowódca Floty Czarnomorskiej" src="https://i.iplsc.com/ukraincy-potwierdzaja-zginal-dowodca-floty-czarnomorskiej/000HPGMAX3LQWD5L-C321.jpg" /></a>Ukraińskie siły zbrojne potwierdziły śmierć rosyjskiego admirała Wiktora Sokołowa. Wojskowy zginął w wyniku ataku przeprowadzonego na dowództwo Floty Czarnomorskiej w Sewastopolu. Liczba zabitych wyniosła łącznie 35 osób. &quot;Mamy do czynienia z jednym z pięciu najlepszych ataków na rosyjskie sztaby w tej wojnie&quot; - ocenił komentator Jarosław Wolski.  </p><br clear="all" />

## Kadyrow zamieścił w sieci nagranie z synem. Nawet w Rosji oburzenie
 - [https://wydarzenia.interia.pl/zagranica/news-kadyrow-zamiescil-w-sieci-nagranie-z-synem-nawet-w-rosji-obu,nId,7048814](https://wydarzenia.interia.pl/zagranica/news-kadyrow-zamiescil-w-sieci-nagranie-z-synem-nawet-w-rosji-obu,nId,7048814)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T18:01:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kadyrow-zamiescil-w-sieci-nagranie-z-synem-nawet-w-rosji-obu,nId,7048814"><img align="left" alt="Kadyrow zamieścił w sieci nagranie z synem. Nawet w Rosji oburzenie" src="https://i.iplsc.com/kadyrow-zamiescil-w-sieci-nagranie-z-synem-nawet-w-rosji-obu/000HPGHE0JTH0KTE-C321.jpg" /></a>W sieci pojawiło się nagranie, na którym widać, jak syn czeczeńskiego przywódcy Adam Kadyrow atakuje 19-letniego aktywistę oskarżonego o spalenie Koranu. &quot;Pobił i postąpił słusznie&quot; - ocenił sytuację Ramzan Kadyrow, powołując się na &quot;wyjątkową ustawę&quot; Władimira Putina. W Rosji ujawnione nagranie wywołało jednak oburzenie bliskich rosyjskiemu dyktatorowi dziennikarzy czy urzędników. &quot;Niezwłocznie wysyłam wniosek o wszczęcie śledztwa w tej sprawie&quot; - grzmi członkini Rady Praw Człowieka przy prezydencie Federacji Rosyjskiej Ewa Merkaczowa.</p><br clear="all" />

## Włosi w pilnym trybie poderwali myśliwce. Latały nad Polską
 - [https://wydarzenia.interia.pl/kraj/news-wlosi-w-pilnym-trybie-poderwali-mysliwce-lataly-nad-polska,nId,7048822](https://wydarzenia.interia.pl/kraj/news-wlosi-w-pilnym-trybie-poderwali-mysliwce-lataly-nad-polska,nId,7048822)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T17:46:43+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wlosi-w-pilnym-trybie-poderwali-mysliwce-lataly-nad-polska,nId,7048822"><img align="left" alt="Włosi w pilnym trybie poderwali myśliwce. Latały nad Polską" src="https://i.iplsc.com/wlosi-w-pilnym-trybie-poderwali-mysliwce-lataly-nad-polska/000HPGLEO295YE39-C321.jpg" /></a>Dwa włoskie myśliwce F-35 miały zostać wysłane do przechwycenia niezidentyfikowanych, najprawdopodobniej rosyjskich samolotów. Jak poinformowała agencja Ansa do zdarzenia doszło 21 września. Włoskie siły powietrzne w ramach prowadzonej przez NATO operacji zabezpieczają wschodnią flankę sojuszu, a wykorzystane do akcji myśliwce przybyły do Malborka we wrześniu.</p><br clear="all" />

## Masowo opuszczają region. W tle billboard "sił pokojowych" Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-masowo-opuszczaja-region-w-tle-billboard-sil-pokojowych-rosj,nId,7048802](https://wydarzenia.interia.pl/zagranica/news-masowo-opuszczaja-region-w-tle-billboard-sil-pokojowych-rosj,nId,7048802)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T17:41:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-masowo-opuszczaja-region-w-tle-billboard-sil-pokojowych-rosj,nId,7048802"><img align="left" alt="Masowo opuszczają region. W tle billboard &quot;sił pokojowych&quot; Rosji " src="https://i.iplsc.com/masowo-opuszczaja-region-w-tle-billboard-sil-pokojowych-rosj/000HPGIJISH41U8M-C321.jpg" /></a>Mieszkańcy Górskiego Karabachu wciąż nie mogą żyć w spokoju. W poniedziałek doszło do wybuchu na stacji benzynowej w stolicy spornego regionu Stepanakert. W tym samym czasie tysiące etnicznych Ormian wyjeżdża do Armenii. Na drogach tworzą się ogromne korki. Użytkownicy mediów społecznościowych wskazują na billboard, który pojawił się przy jednej z takich zatłoczonych dróg. Widnieje na nim Władimir Putin, a baner został postawiony przez rosyjskie siły pokojowe, stacjonujące na tym obszarze. &quot;Rosja przynosi tyle 'pokoju', co huragan&quot; - napisał...</p><br clear="all" />

## Potężne korki i masowa ucieczka. Ormianie opuszczają Górski Karabach
 - [https://wydarzenia.interia.pl/zagranica/news-potezne-korki-i-masowa-ucieczka-ormianie-opuszczaja-gorski-k,nId,7048802](https://wydarzenia.interia.pl/zagranica/news-potezne-korki-i-masowa-ucieczka-ormianie-opuszczaja-gorski-k,nId,7048802)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T17:41:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-potezne-korki-i-masowa-ucieczka-ormianie-opuszczaja-gorski-k,nId,7048802"><img align="left" alt="Potężne korki i masowa ucieczka. Ormianie opuszczają Górski Karabach" src="https://i.iplsc.com/potezne-korki-i-masowa-ucieczka-ormianie-opuszczaja-gorski-k/000HPGIJISH41U8M-C321.jpg" /></a>Mieszkańcy Górskiego Karabachu wciąż nie mogą żyć w spokoju. W poniedziałek doszło do wybuchu na stacji benzynowej w stolicy spornego regionu Stepanakert. W tym samym czasie tysiące etnicznych Ormian wyjeżdża do Armenii. Na drogach tworzą się korki. Użytkownicy mediów społecznościowych wskazują na billboard, który pojawił się przy jednej z dróg. Widnieje na nim Władimir Putin, a baner został postawiony przez rosyjskie siły pokojowe, stacjonujące na tym obszarze. &quot;Rosja przynosi tyle 'pokoju', co huragan&quot; - napisał jeden z korespondentów.</p><br clear="all" />

## Premier chce kontroli na granicy ze Słowacją. Chodzi o "szlak bałkański"
 - [https://wydarzenia.interia.pl/kraj/news-premier-chce-kontroli-na-granicy-ze-slowacja-chodzi-o-szlak-,nId,7048804](https://wydarzenia.interia.pl/kraj/news-premier-chce-kontroli-na-granicy-ze-slowacja-chodzi-o-szlak-,nId,7048804)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T16:45:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-chce-kontroli-na-granicy-ze-slowacja-chodzi-o-szlak-,nId,7048804"><img align="left" alt="Premier chce kontroli na granicy ze Słowacją. Chodzi o &quot;szlak bałkański&quot;" src="https://i.iplsc.com/premier-chce-kontroli-na-granicy-ze-slowacja-chodzi-o-szlak/000GLO5NA768ORRK-C321.jpg" /></a>- Poleciłem ministrowi spraw wewnętrznych i administracji, aby wprowadzać kontrole na granicy polsko-słowackiej - powiedział Mateusz Morawiecki na spotkaniu z mieszkańcami Kraśnika. Według premiera samochody i autobusy wjeżdżające na terytorium naszego kraju z południa przewożą nielegalnych imigrantów. Potwierdził tym samym wcześniejsze, nieoficjalne doniesienia Polsat News.</p><br clear="all" />

## Morawiecki do Scholza: Nie wtrącaj się w nie swoje sprawy
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-morawiecki-do-scholza-nie-wtracaj-sie-w-nie-swoje-sprawy,nId,7048628](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-morawiecki-do-scholza-nie-wtracaj-sie-w-nie-swoje-sprawy,nId,7048628)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T16:00:10+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-morawiecki-do-scholza-nie-wtracaj-sie-w-nie-swoje-sprawy,nId,7048628"><img align="left" alt="Morawiecki do Scholza: Nie wtrącaj się w nie swoje sprawy" src="https://i.iplsc.com/morawiecki-do-scholza-nie-wtracaj-sie-w-nie-swoje-sprawy/000HPGB7HOXPRO6U-C321.jpg" /></a>Mateusz Morawiecki przemawiał w Kraśniku (woj. lubelskie). Odniósł się do kontrowersyjnych wypowiedzi Wołodymyra Zełenskiego. - Panie prezydencie, niech pan nie waży się obrażać Polaków. Będziemy zawsze bronić naszego interesu i naszego dobrego imienia - ostrzegał. Mówił także o twórcach filmu &quot;Zielona granica&quot;. Premier wskazywał, że &quot;tam nasi żołnierze przedstawiani są jak zwyrodnialcy, kanalie, mordercy&quot;. Przekonywał, że &quot;widział znaczne fragmenty filmu&quot;. Morawiecki skomentował także ostatnie słowa kanclerza Olafa Scholza, który wspominał...</p><br clear="all" />

## Tusk: PiS odebrało pieniądze z UE, za chwilę zamknie nam granicę
 - [https://wydarzenia.interia.pl/kraj/news-tusk-pis-odebralo-pieniadze-z-ue-za-chwile-zamknie-nam-grani,nId,7048606](https://wydarzenia.interia.pl/kraj/news-tusk-pis-odebralo-pieniadze-z-ue-za-chwile-zamknie-nam-grani,nId,7048606)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T15:49:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-pis-odebralo-pieniadze-z-ue-za-chwile-zamknie-nam-grani,nId,7048606"><img align="left" alt="Tusk: PiS odebrało pieniądze z UE, za chwilę zamknie nam granicę" src="https://i.iplsc.com/tusk-pis-odebralo-pieniadze-z-ue-za-chwile-zamknie-nam-grani/000HPFYB02BBPN5Q-C321.jpg" /></a>- Formalnie niby jesteśmy w Unii Europejskiej, ale politycy PiS pozbawili nas pieniędzy, za chwilę nam mogą zamknąć granicę i będziemy izolowani, de facto zabrali nam już tę Europę - mówił na wiecu wyborczym w Otwocku Donald Tusk. Wskazywał przy tym, że celem Koalicji Obywatelskiej jest powrót do wielkiej wspólnoty europejskiej i odbudowanie pozycji Polski. Z kolei Rafał Trzaskowski zwrócił uwagę na różnice w kampaniach prowadzonych przez PiS i Koalicję Obywatelską. - PiS budzi najgorsze emocje i tylko szczuje - ocenił prezydent Warszawy....</p><br clear="all" />

## Tusk: PiS odebrało pieniądze z UE, za chwilę zamknie nam granicę
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tusk-pis-odebralo-pieniadze-z-ue-za-chwile-zamknie-nam-grani,nId,7048606](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tusk-pis-odebralo-pieniadze-z-ue-za-chwile-zamknie-nam-grani,nId,7048606)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T15:49:01+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tusk-pis-odebralo-pieniadze-z-ue-za-chwile-zamknie-nam-grani,nId,7048606"><img align="left" alt="Tusk: PiS odebrało pieniądze z UE, za chwilę zamknie nam granicę" src="https://i.iplsc.com/tusk-pis-odebralo-pieniadze-z-ue-za-chwile-zamknie-nam-grani/000HPGE9OPLTEIDB-C321.jpg" /></a>- Formalnie niby jesteśmy w Unii Europejskiej, ale politycy PiS pozbawili nas pieniędzy, za chwilę nam mogą zamknąć granicę i będziemy izolowani, de facto zabrali nam już tę Europę - mówił na wiecu wyborczym w Otwocku Donald Tusk. Wskazywał przy tym, że celem Koalicji Obywatelskiej jest powrót do wielkiej wspólnoty europejskiej i odbudowanie pozycji Polski. Z kolei Rafał Trzaskowski zwrócił uwagę na różnice w kampaniach prowadzonych przez PiS i Koalicję Obywatelską. - PiS budzi najgorsze emocje i tylko szczuje - ocenił prezydent Warszawy....</p><br clear="all" />

## Kiedy obchodzimy Dzień Chłopaka? Aktualna data ma krótką historię
 - [https://wydarzenia.interia.pl/ciekawostki/news-kiedy-obchodzimy-dzien-chlopaka-aktualna-data-ma-krotka-hist,nId,7048347](https://wydarzenia.interia.pl/ciekawostki/news-kiedy-obchodzimy-dzien-chlopaka-aktualna-data-ma-krotka-hist,nId,7048347)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T15:42:10+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-kiedy-obchodzimy-dzien-chlopaka-aktualna-data-ma-krotka-hist,nId,7048347"><img align="left" alt="Kiedy obchodzimy Dzień Chłopaka? Aktualna data ma krótką historię" src="https://i.iplsc.com/kiedy-obchodzimy-dzien-chlopaka-aktualna-data-ma-krotka-hist/000G4C9VYOLWR49Y-C321.jpg" /></a>30 września obchodzimy w Polsce Dzień Chłopaka. Święto i data głęboko zakorzeniły się już w naszym społeczeństwie, mimo że obchodzimy je stosunkowo od niedawna. Przynajmniej tego dnia. Historia święta jest skomplikowana do tego stopnia, że trudno nawet jednoznacznie określić, kto powinien świętować tego dnia. Od kiedy Dzień Chłopaka wypada we wrześniu? Kiedy mężczyźni obchodzili swoje święto w PRL-u? Czy Dzień Chłopaka i Dzień Mężczyzny to te same święta? </p><br clear="all" />

## Błaszczak podpisał umowę. "Największa flota śmigłowców poza USA"
 - [https://wydarzenia.interia.pl/zagranica/news-blaszczak-podpisal-umowe-najwieksza-flota-smiglowcow-poza-us,nId,7048627](https://wydarzenia.interia.pl/zagranica/news-blaszczak-podpisal-umowe-najwieksza-flota-smiglowcow-poza-us,nId,7048627)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T15:39:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-blaszczak-podpisal-umowe-najwieksza-flota-smiglowcow-poza-us,nId,7048627"><img align="left" alt="Błaszczak podpisał umowę. &quot;Największa flota śmigłowców poza USA&quot;" src="https://i.iplsc.com/blaszczak-podpisal-umowe-najwieksza-flota-smiglowcow-poza-us/000HPGCILWQYPM2D-C321.jpg" /></a>Szef Ministerstwa Obrony Narodowej podpisał umowę na zakup śmigłowców Apache od amerykańskiego koncernu zbrojeniowego. Do polskiej armii ma trafić 96 tych maszyn, a centrum serwisowe powstanie w Bydgoszczy. - To będzie największa flota tych śmigłowców poza Stanami Zjednoczonymi - powiedział Mariusz Błaszczak w trakcie uroczystego zawierania negocjowanego od dawna kontraktu.</p><br clear="all" />

## Wypadek awionetki. Zrzucała szczepionkę dla lisów
 - [https://wydarzenia.interia.pl/lodzkie/news-wypadek-awionetki-zrzucala-szczepionke-dla-lisow,nId,7048608](https://wydarzenia.interia.pl/lodzkie/news-wypadek-awionetki-zrzucala-szczepionke-dla-lisow,nId,7048608)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T15:03:04+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-wypadek-awionetki-zrzucala-szczepionke-dla-lisow,nId,7048608"><img align="left" alt="Wypadek awionetki. Zrzucała szczepionkę dla lisów" src="https://i.iplsc.com/wypadek-awionetki-zrzucala-szczepionke-dla-lisow/000HPFSUDG8TFN18-C321.jpg" /></a>Niebezpieczny wypadek awionetki w miejscowości Jamno (woj. łódzkie). Samolot wylądował kołami do góry podczas rozprowadzania szczepionki dla lisów przeciwko wściekliźnie. - Dwie osoby zostały poszkodowane, nie odniosły poważnych obrażeń - potwierdził w rozmowie z Interią mł. bryg. mgr inż. Tomasz Ledzion z KP PSP w Łowiczu. </p><br clear="all" />

## Zareagowała na słowa J. Kowalskiego. "Rodzice powinni się za pana wstydzić"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zareagowala-na-slowa-j-kowalskiego-rodzice-powinni-sie-za-pa,nId,7048546](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zareagowala-na-slowa-j-kowalskiego-rodzice-powinni-sie-za-pa,nId,7048546)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T14:36:28+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zareagowala-na-slowa-j-kowalskiego-rodzice-powinni-sie-za-pa,nId,7048546"><img align="left" alt="Zareagowała na słowa J. Kowalskiego. &quot;Rodzice powinni się za pana wstydzić&quot;" src="https://i.iplsc.com/zareagowala-na-slowa-j-kowalskiego-rodzice-powinni-sie-za-pa/000HPFNWH6B4NXS7-C321.jpg" /></a>Poseł Suwerennej Polski Janusz Kowalski zapowiedział &quot;likwidację przywilejów mniejszości narodowych&quot;, ogłaszając swoje plany przed siedzibą Towarzystwa Społeczno-Kulturalnego Niemców na Śląsku Opolskim. Wyraził też nadzieję, że mijająca kadencja jest ostatnią, gdy Mniejszość Niemiecka ma w Sejmie przedstawiciela. Podczas konferencji doszło do słownego starcia między Kowalskim a przedstawicielką mniejszości. Ta mówiła, by Kowalski &quot;się wstydził, zostawił tych ludzi i nauczył historii&quot;. </p><br clear="all" />

## Dwa miliardy dolarów pożyczki dla Polski. USA wspiera modernizację armii
 - [https://wydarzenia.interia.pl/zagranica/news-dwa-miliardy-dolarow-pozyczki-dla-polski-usa-wspiera-moderni,nId,7048585](https://wydarzenia.interia.pl/zagranica/news-dwa-miliardy-dolarow-pozyczki-dla-polski-usa-wspiera-moderni,nId,7048585)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T14:25:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-dwa-miliardy-dolarow-pozyczki-dla-polski-usa-wspiera-moderni,nId,7048585"><img align="left" alt="Dwa miliardy dolarów pożyczki dla Polski. USA wspiera modernizację armii" src="https://i.iplsc.com/dwa-miliardy-dolarow-pozyczki-dla-polski-usa-wspiera-moderni/000G87D762U532YS-C321.jpg" /></a>Departament Stanu USA ogłosił podpisanie z Polską nowej umowy na pożyczkę bezpośrednią w wysokości dwóch miliardów dolarów. Środki mają służyć modernizacji polskiej armii i wzmocnić bezpieczeństwo wschodniej flanki NATO i przekazane zostaną w ramach zagranicznego finansowania wojskowego. </p><br clear="all" />

## Ogromna kwota na wzmocnienie polskiej armii. Przełomowa umowa z USA
 - [https://wydarzenia.interia.pl/zagranica/news-ogromna-kwota-na-wzmocnienie-polskiej-armii-przelomowa-umowa,nId,7048585](https://wydarzenia.interia.pl/zagranica/news-ogromna-kwota-na-wzmocnienie-polskiej-armii-przelomowa-umowa,nId,7048585)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T14:25:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ogromna-kwota-na-wzmocnienie-polskiej-armii-przelomowa-umowa,nId,7048585"><img align="left" alt="Ogromna kwota na wzmocnienie polskiej armii. Przełomowa umowa z USA" src="https://i.iplsc.com/ogromna-kwota-na-wzmocnienie-polskiej-armii-przelomowa-umowa/000GFTTVWVR6LFEQ-C321.jpg" /></a>Departament Stanu USA ogłosił podpisanie z Polską nowej umowy na pożyczkę bezpośrednią w wysokości dwóch miliardów dolarów. Środki mają służyć modernizacji polskiej armii i wzmocnić bezpieczeństwo wschodniej flanki NATO.</p><br clear="all" />

## Zaskakująca strategia PiS w Olsztynie. Skorzysta opozycja?
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zaskakujaca-strategia-pis-w-olsztynie-skorzysta-opozycja,nId,7048544](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zaskakujaca-strategia-pis-w-olsztynie-skorzysta-opozycja,nId,7048544)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T14:21:22+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zaskakujaca-strategia-pis-w-olsztynie-skorzysta-opozycja,nId,7048544"><img align="left" alt="Zaskakująca strategia PiS w Olsztynie. Skorzysta opozycja?" src="https://i.iplsc.com/zaskakujaca-strategia-pis-w-olsztynie-skorzysta-opozycja/000HPFNCQO977HVW-C321.jpg" /></a>PiS wystawiło w Olsztynie konkurenta swojej byłej kandydatce na rzecznika praw obywatelskich - senator Lidii Staroń. Na ich rywalizacji może skorzystać kandydatka opozycyjnego &quot;paktu senackiego&quot;. - Lidia Staroń nie spełniła pokładanych w niej nadziei - przekazał Interii kandydujący z Olsztyna do Sejmu minister cyfryzacji Janusz Cieszyński. - Działania ugrupowań to ich sprawa. Robię swoje - powiedziała nam z kolei sama Staroń.</p><br clear="all" />

## Wybory 2023. Do lokalu bez dokumentów, tylko z telefonem
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-2023-do-lokalu-bez-dokumentow-tylko-z-telefonem,nId,7048299](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-2023-do-lokalu-bez-dokumentow-tylko-z-telefonem,nId,7048299)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T13:52:53+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-2023-do-lokalu-bez-dokumentow-tylko-z-telefonem,nId,7048299"><img align="left" alt="Wybory 2023. Do lokalu bez dokumentów, tylko z telefonem" src="https://i.iplsc.com/wybory-2023-do-lokalu-bez-dokumentow-tylko-z-telefonem/000H185ITQ92JHUU-C321.jpg" /></a>15 października w Polsce odbędą się wybory parlamentarne. Obywatele oddadzą swoje głosy w obecności komisji, która przed wydaniem kart sprawdzi tożsamość każdego głosującego. Jaki dokument trzeba okazać komisji wyborczej? To pierwsze wybory do Sejmu i Senatu, w których potwierdzimy swoją tożsamość cyfrowo.</p><br clear="all" />

## Tego nie było od lat. Żołnierz lądował F-16 na zwykłej drodze
 - [https://wydarzenia.interia.pl/kraj/news-tego-nie-bylo-od-lat-zolnierz-ladowal-f-16-na-zwyklej-drodze,nId,7048554](https://wydarzenia.interia.pl/kraj/news-tego-nie-bylo-od-lat-zolnierz-ladowal-f-16-na-zwyklej-drodze,nId,7048554)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T13:41:14+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tego-nie-bylo-od-lat-zolnierz-ladowal-f-16-na-zwyklej-drodze,nId,7048554"><img align="left" alt="Tego nie było od lat. Żołnierz lądował F-16 na zwykłej drodze" src="https://i.iplsc.com/tego-nie-bylo-od-lat-zolnierz-ladowal-f-16-na-zwyklej-drodze/000HPFOYLMBRXD28-C321.jpg" /></a>To pierwsze takie wydarzenie od 20 lat. Tyle minęło od ostatnich poćwiczeń, podczas których polscy piloci lądowali na drogach publicznych. Wykorzystują do tego tzw. Drogowe Odcinki Lotniskowe, które w krytycznych sytuacjach mają pomóc w rozproszeniu sił lotniczych. Pierwszy myśliwiec F-16 sterowany przez inspektora sił powietrznych wylądował w poniedziałek na odcinku drogi wojewódzkiej nr 604 w woj. warmińsko-mazurskim. Ćwiczenia wojskowe Route 604 mają potrwać do piątku, a dwukilometrowy odcinek drogi został wyłączony z ruchu. </p><br clear="all" />

## Zełenski potwierdził. Ukraina zyskała potężną broń z USA
 - [https://wydarzenia.interia.pl/zagranica/news-zelenski-potwierdzil-ukraina-zyskala-potezna-bron-z-usa,nId,7048530](https://wydarzenia.interia.pl/zagranica/news-zelenski-potwierdzil-ukraina-zyskala-potezna-bron-z-usa,nId,7048530)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T13:40:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zelenski-potwierdzil-ukraina-zyskala-potezna-bron-z-usa,nId,7048530"><img align="left" alt="Zełenski potwierdził. Ukraina zyskała potężną broń z USA " src="https://i.iplsc.com/zelenski-potwierdzil-ukraina-zyskala-potezna-bron-z-usa/000HPEWRP126P38W-C321.jpg" /></a>Prezydent Ukrainy poinformował, że Ukraina otrzymała czołgi M1 Abrams. Stany Zjednoczone zapowiedziały przekazanie 31 czołgów Kijowowi w styczniu. Na razie nie podano, ile maszyn odebrali Ukraińcy.</p><br clear="all" />

## Nietypowa oferta dla pielęgniarek. "Może któraś znajdzie męża"
 - [https://wydarzenia.interia.pl/podkarpackie/news-nietypowa-oferta-dla-pielegniarek-moze-ktoras-znajdzie-meza,nId,7048427](https://wydarzenia.interia.pl/podkarpackie/news-nietypowa-oferta-dla-pielegniarek-moze-ktoras-znajdzie-meza,nId,7048427)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T13:14:45+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-nietypowa-oferta-dla-pielegniarek-moze-ktoras-znajdzie-meza,nId,7048427"><img align="left" alt="Nietypowa oferta dla pielęgniarek. &quot;Może któraś znajdzie męża&quot;" src="https://i.iplsc.com/nietypowa-oferta-dla-pielegniarek-moze-ktoras-znajdzie-meza/000HPEL16547MJTI-C321.jpg" /></a>Stanisław Mazur, szef Centrum Medycznego &quot;Medyk&quot; w Rzeszowie, zaproponował pielęgniarkom pracę w charakterze kelnerek po godzinach. Impreza, na której panie miały pracować, organizowana była dla 140 świeżo upieczonych lekarzy. &quot;Może któraś znajdzie sobie męża&quot; - napisał im szef placówki. - Pan doktor pokazał, za kogo nas uważa - komentuje jedna z pielęgniarek. Teraz autor wiadomości przeprasza kobiety, które &quot;poczuły się urażone&quot;. &quot;Komentarz o szukaniu męża był niestosowny i niewłaściwy&quot; - dodaje w oświadczeniu przesłanym Interii. </p><br clear="all" />

## Polski kandydat do Oscara ogłoszony
 - [https://wydarzenia.interia.pl/kraj/news-polski-kandydat-do-oscara-ogloszony,nId,7048393](https://wydarzenia.interia.pl/kraj/news-polski-kandydat-do-oscara-ogloszony,nId,7048393)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T13:00:10+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polski-kandydat-do-oscara-ogloszony,nId,7048393"><img align="left" alt="Polski kandydat do Oscara ogłoszony" src="https://i.iplsc.com/polski-kandydat-do-oscara-ogloszony/000HPEW81N5SMPN8-C321.jpg" /></a>Polski Instytut Sztuki Filmowej ogłosił polskiego kandydata do Oscara. Polskę na gali w Los Angeles ma szansę reprezentować film &quot;Chłopi&quot;  - poinformowała w Warszawie Komisja Oscarowa pod przewodnictwem producentki Ewy Puszczyńskiej.</p><br clear="all" />

## Ukraina woli Niemcy od Polski. "Chce grać na różnych fortepianach"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-woli-niemcy-od-polski-chce-grac-na-roznych-fortepian,nId,7048316](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-woli-niemcy-od-polski-chce-grac-na-roznych-fortepian,nId,7048316)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T12:38:52+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-woli-niemcy-od-polski-chce-grac-na-roznych-fortepian,nId,7048316"><img align="left" alt="Ukraina woli Niemcy od Polski. &quot;Chce grać na różnych fortepianach&quot;" src="https://i.iplsc.com/ukraina-woli-niemcy-od-polski-chce-grac-na-roznych-fortepian/000HPEH640PJNL2J-C321.jpg" /></a>Berlin w początkach wojny był oskarżany o gotowość przehandlowania ukraińskiej suwerenności przez wzgląd na wieloletnie dobre relacje z Kremlem. Ale ostatnie dni pokazały, że Ukraina wybiera bliższe relacje z rządem Olafa Scholza kosztem dobrych stosunków z Polską. - Orientowanie się Kijowa na Berlin nie powinno nas dziwić. Główną rolę odgrywa gra interesów - mówi prof. Tomasz Grzegorz Grosse z Uniwersytetu Warszawskiego. - Było jasne, że może dojść do zmiany frontu przez Ukrainę. Nikt nie miał wątpliwości, że Berlin będzie dążył do odbudowy...</p><br clear="all" />

## Magiczny materiał nie istnieje: Lego się poddaje
 - [https://wydarzenia.interia.pl/zagranica/news-magiczny-material-nie-istnieje-lego-sie-poddaje,nId,7048449](https://wydarzenia.interia.pl/zagranica/news-magiczny-material-nie-istnieje-lego-sie-poddaje,nId,7048449)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T12:17:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-magiczny-material-nie-istnieje-lego-sie-poddaje,nId,7048449"><img align="left" alt="Magiczny materiał nie istnieje: Lego się poddaje" src="https://i.iplsc.com/magiczny-material-nie-istnieje-lego-sie-poddaje/000HPEIURFRKK7BX-C321.jpg" /></a>Tradycyjny plastik okazał się niezastąpiony? Firmie Lego nie udało się znaleźć bardziej ekologicznego zamiennika do produkcji słynnych klocków. Próby z materiałem pochodzącym z recyklingu okazały się nieudane, więc firma oficjalnie ogłosiła, że porzuca ten pomysł. Jednocześnie Lego zapewnia, że dalej będzie szukać sposobów na bardziej ekologiczną produkcję tak, by do konkretnej daty osiągnąć zeroemisyjność.</p><br clear="all" />

## Tragiczny wypadek na autostradzie A1. Internauci na tropie kierowcy bmw
 - [https://wydarzenia.interia.pl/kraj/news-tragiczny-wypadek-na-autostradzie-a1-internauci-na-tropie-ki,nId,7048355](https://wydarzenia.interia.pl/kraj/news-tragiczny-wypadek-na-autostradzie-a1-internauci-na-tropie-ki,nId,7048355)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T12:05:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tragiczny-wypadek-na-autostradzie-a1-internauci-na-tropie-ki,nId,7048355"><img align="left" alt="Tragiczny wypadek na autostradzie A1. Internauci na tropie kierowcy bmw" src="https://i.iplsc.com/tragiczny-wypadek-na-autostradzie-a1-internauci-na-tropie-ki/000HPEIREJK8FH7H-C321.jpg" /></a>Nie milkną echa po sobotnim wypadku do jakiego doszło na autostradzie A1. W tragicznym zdarzeniu zginęła trzyosobowa rodzina. Policja zapewnia, że sprawa będzie dokładnie wyjaśniona, jednak już na wstępie ustaleń nie wzięto pod uwagę współuczestnictwa w wypadku kierowcy bmw. Internauci dotarli do nazwiska prawdopodobnego właściciela auta.</p><br clear="all" />

## Posłanka PO zaatakowana. Mężczyzna trząsł i krzyczał: Takich jak wy trzeba wybić
 - [https://wydarzenia.interia.pl/kraj/news-poslanka-po-zaatakowana-mezczyzna-trzasl-i-krzyczal-takich-j,nId,7048461](https://wydarzenia.interia.pl/kraj/news-poslanka-po-zaatakowana-mezczyzna-trzasl-i-krzyczal-takich-j,nId,7048461)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T11:59:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-poslanka-po-zaatakowana-mezczyzna-trzasl-i-krzyczal-takich-j,nId,7048461"><img align="left" alt="Posłanka PO zaatakowana. Mężczyzna trząsł i krzyczał: Takich jak wy trzeba wybić" src="https://i.iplsc.com/poslanka-po-zaatakowana-mezczyzna-trzasl-i-krzyczal-takich-j/000G87D762U532YS-C321.jpg" /></a>Kolejny atak na polityka Koalicji Obywatelskiej, tym razem na targu w Opolu Lubelskim zaatakowana została Marta Wcisło. Nieznany mężczyzna trząsł kobietą i krzyczał.</p><br clear="all" />

## Joanna Senyszyn przed sądem. Chodzi o wpisy o Żołnierzach Wyklętych
 - [https://wydarzenia.interia.pl/kraj/news-joanna-senyszyn-przed-sadem-chodzi-o-wpisy-o-zolnierzach-wyk,nId,7048406](https://wydarzenia.interia.pl/kraj/news-joanna-senyszyn-przed-sadem-chodzi-o-wpisy-o-zolnierzach-wyk,nId,7048406)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T11:57:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-joanna-senyszyn-przed-sadem-chodzi-o-wpisy-o-zolnierzach-wyk,nId,7048406"><img align="left" alt="Joanna Senyszyn przed sądem. Chodzi o wpisy o Żołnierzach Wyklętych" src="https://i.iplsc.com/joanna-senyszyn-przed-sadem-chodzi-o-wpisy-o-zolnierzach-wyk/000GX7C1OCQN17Y7-C321.jpg" /></a>W Sądzie Okręgowym w Gdańsku rozpoczął się zdalny proces z powództwa Stowarzyszenia Rodzin Żołnierzy Wyklętych oraz członków rodzin Żołnierzy Niezłomnych przeciwko prof. Joannie Senyszyn. Dotyczy on wpisów na temat Żołnierzy Wyklętych zamieszczanych przez posłankę w mediach społecznościowych.</p><br clear="all" />

## Premier Morawiecki: Linia Wisły była linią śmierci w czasach Tuska
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-morawiecki-linia-wisly-byla-linia-smierci-w-czasach-,nId,7048439](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-morawiecki-linia-wisly-byla-linia-smierci-w-czasach-,nId,7048439)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T11:44:13+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-morawiecki-linia-wisly-byla-linia-smierci-w-czasach-,nId,7048439"><img align="left" alt="Premier Morawiecki: Linia Wisły była linią śmierci w czasach Tuska" src="https://i.iplsc.com/premier-morawiecki-linia-wisly-byla-linia-smierci-w-czasach/000HPEFHO13FTUSF-C321.jpg" /></a>- Rząd PO-PSL nie wierzył w polską armię, dlatego linia Wisły była linią śmierci w czasach Donalda Tuska - mówił w Dęblinie premier Mateusz Morawiecki. Szef rządu dodawał, że &quot;była to jedyna doktryna w historii świata od razu zakładająca kapitulację&quot;.</p><br clear="all" />

## Ślub jesienią. Na co zwrócić uwagę?
 - [https://wydarzenia.interia.pl/news-slub-jesienia-na-co-zwrocic-uwage,nId,7048423](https://wydarzenia.interia.pl/news-slub-jesienia-na-co-zwrocic-uwage,nId,7048423)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T11:31:52+00:00

<p><a href="https://wydarzenia.interia.pl/news-slub-jesienia-na-co-zwrocic-uwage,nId,7048423"><img align="left" alt="Ślub jesienią. Na co zwrócić uwagę? " src="https://i.iplsc.com/slub-jesienia-na-co-zwrocic-uwage/00042ERZDF0QSP8Y-C321.jpg" /></a>Ślub jesienią to marzenie wielu par. Pełnia kolorów, klimat, a przede wszystkim sprzyjająca pogoda to tylko kilka powodów, dla których małżeństwa zawierane są coraz częściej o tej porze roku. Dlaczego warto i na co zwrócić uwagę przy organizacji? Przekonajmy się! </p><br clear="all" />

## SBU rozbiło siatkę agentów. Zbierali informacje o ruchach wojsk
 - [https://wydarzenia.interia.pl/zagranica/news-sbu-rozbilo-siatke-agentow-zbierali-informacje-o-ruchach-woj,nId,7048371](https://wydarzenia.interia.pl/zagranica/news-sbu-rozbilo-siatke-agentow-zbierali-informacje-o-ruchach-woj,nId,7048371)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T11:19:22+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sbu-rozbilo-siatke-agentow-zbierali-informacje-o-ruchach-woj,nId,7048371"><img align="left" alt="SBU rozbiło siatkę agentów. Zbierali informacje o ruchach wojsk" src="https://i.iplsc.com/sbu-rozbilo-siatke-agentow-zbierali-informacje-o-ruchach-woj/000HPEDBB1977DDO-C321.jpg" /></a>Służba Bezpieczeństwa Ukrainy zneutralizowała siatkę agentów pracujących dla rosyjskiego GRU. Szpiedzy zbierali informacje na temat lokalizacji ukraińskich umocnień, tras przemieszczania kolumn wojskowych. Podczas ich zatrzymania znaleziono między innymi granaty. </p><br clear="all" />

## Kandydat PiS z wyrokiem. Miał znieważyć kobietę
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-kandydat-pis-z-wyrokiem-mial-zniewazyc-kobiete,nId,7048265](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-kandydat-pis-z-wyrokiem-mial-zniewazyc-kobiete,nId,7048265)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T11:06:36+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-kandydat-pis-z-wyrokiem-mial-zniewazyc-kobiete,nId,7048265"><img align="left" alt="Kandydat PiS z wyrokiem. Miał znieważyć kobietę" src="https://i.iplsc.com/kandydat-pis-z-wyrokiem-mial-zniewazyc-kobiete/000HPDSI6QA89L8D-C321.jpg" /></a>Stanisław P. ma wyrok sądu pierwszej instancji za znieważenie kobiety. Jako burmistrz Działoszyc publicznie nazwał kobietę &quot;lochą&quot;. Jako kandydat OdNowy RP ma też miejsce na świętokrzyskiej liście PiS. Sam nie komentuje sprawy. Nie robi tego też lider OdNowy - Marcin Ociepa. O sytuacji opowiedziała nam natomiast adresatka obelgi. Krystyna Gałczyńska podkreśla, że w ślad za burmistrzem poszły inne osoby, które myślą, że &quot;jeżeli włodarz może, to teraz każdy może&quot; ją obrażać.</p><br clear="all" />

## Rosja straciła w Ukrainie więcej generałów niż całe NATO przez ponad 70 lat
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-stracila-w-ukrainie-wiecej-generalow-niz-cale-nato-prz,nId,7048320](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-stracila-w-ukrainie-wiecej-generalow-niz-cale-nato-prz,nId,7048320)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T10:39:08+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-stracila-w-ukrainie-wiecej-generalow-niz-cale-nato-prz,nId,7048320"><img align="left" alt="Rosja straciła w Ukrainie więcej generałów niż całe NATO przez ponad 70 lat" src="https://i.iplsc.com/rosja-stracila-w-ukrainie-wiecej-generalow-niz-cale-nato-prz/000HPE57YK0852U5-C321.jpg" /></a>Sądząc po reakcjach rosyjskich blogerów militarnych oraz wszelkiej maści celebryckich propagandystów, zeszłotygodniowy ukraiński atak rakietowy na dowództwo Floty Czarnomorskiej wywołał w Rosji szok. Moskwa przyznaje się do jednego zabitego, ale w wersję ministerstwa obrony nie wierzą sami Rosjanie. Ukraińcy twierdzą, że zabili dziewięciu wyższych rangą oficerów, a co najmniej 16 ranili. Być może pośród ofiar jest sam dowódca czarnomorskiego zgrupowania morskiego, adm. Wiktor Sokołow.</p><br clear="all" />

## Prezes Trybunału na liście poszukiwanych MSZ Rosji. To polski prawnik
 - [https://wydarzenia.interia.pl/zagranica/news-prezes-miedzynarodowego-trybunalu-karnego-na-liscie-poszukiw,nId,7048370](https://wydarzenia.interia.pl/zagranica/news-prezes-miedzynarodowego-trybunalu-karnego-na-liscie-poszukiw,nId,7048370)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T10:35:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prezes-miedzynarodowego-trybunalu-karnego-na-liscie-poszukiw,nId,7048370"><img align="left" alt="Prezes Trybunału na liście poszukiwanych MSZ Rosji. To polski prawnik" src="https://i.iplsc.com/prezes-trybunalu-na-liscie-poszukiwanych-msz-rosji-to-polski/000HPE63UQ8XY1BG-C321.jpg" /></a>Piotr Hofmański, polski prawnik działający przy Międzynarodowym Trybunale Karnym został wpisany jako poszukiwany przez rosyjskie MSZ. Jego nazwisko figuruje już w ministerialnej bazie danych.</p><br clear="all" />

## Skandal z udziałem Zełenskiego. Organizacja oburzona, są przeprosiny
 - [https://wydarzenia.interia.pl/zagranica/news-skandal-z-udzialem-zelenskiego-organizacja-oburzona-sa-przep,nId,7048313](https://wydarzenia.interia.pl/zagranica/news-skandal-z-udzialem-zelenskiego-organizacja-oburzona-sa-przep,nId,7048313)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T10:04:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-skandal-z-udzialem-zelenskiego-organizacja-oburzona-sa-przep,nId,7048313"><img align="left" alt="Skandal z udziałem Zełenskiego. Organizacja oburzona, są przeprosiny" src="https://i.iplsc.com/skandal-z-udzialem-zelenskiego-organizacja-oburzona-sa-przep/000HPE0FA2ETYF7P-C321.jpg" /></a>Wołodymyr Zełenski złożył niezapowiedzianą wizytą w Kanadzie. Prezydent Ukrainy spotkał się wówczas z członkami kanadyjskiego rządu oraz przemawiał w tamtejszym parlamencie. W akcie solidarności z Ukrainą, podczas wizyty w Izbie Gmin marszałek Anthony Rota uhonorował 98-letniego ukraińskiego emigranta Jarosława Hunkę. Eksperci po wydarzeniu zwrócili uwagę na mroczną przeszłość Ukraińca. Członkowie parlamentu musieli się tłumaczyć.</p><br clear="all" />

## Żadnych mrzonek!
 - [https://wydarzenia.interia.pl/felietony/news-zadnych-mrzonek,nId,7048333](https://wydarzenia.interia.pl/felietony/news-zadnych-mrzonek,nId,7048333)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T10:04:23+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/news-zadnych-mrzonek,nId,7048333"><img align="left" alt="Żadnych mrzonek!" src="https://i.iplsc.com/zadnych-mrzonek/000HPE0W11126RA6-C321.jpg" /></a>Przerażona aferą wizową władza postanowiła zaatakować film, którego nie widziała, i ustami swych najwyższych przedstawicieli - prezesa, premiera, prezydenta - zmieszała z błotem Agnieszkę Holland, jej &quot;Zieloną granicę&quot; i obywateli, którzy poszli lub pójdą do kina, a potem różnie ocenią ten głośny już obraz. Ów paniczny i wulgarny atak na dzieło filmowe - przywoływanie wymierzonego w kolaborantów hasła z czasów hitlerowskich &quot;Tylko świnie siedzą w kinie&quot; to pierwszy z brzegu przykład - pokazuje, że polskie życie polityczne zabrnęło w rejony...</p><br clear="all" />

## 19 państw rozwija tarczę antyrakietową. Bez Polski
 - [https://wydarzenia.interia.pl/zagranica/news-19-panstw-rozwija-tarcze-antyrakietowa-bez-polski,nId,7048324](https://wydarzenia.interia.pl/zagranica/news-19-panstw-rozwija-tarcze-antyrakietowa-bez-polski,nId,7048324)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T10:02:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-19-panstw-rozwija-tarcze-antyrakietowa-bez-polski,nId,7048324"><img align="left" alt="19 państw rozwija tarczę antyrakietową. Bez Polski" src="https://i.iplsc.com/19-panstw-rozwija-tarcze-antyrakietowa-bez-polski/000HPDZYGQFYIP11-C321.jpg" /></a>Zagrożenie ze strony Rosji po jej inwazji na Ukrainę sprawiło, że Europa chce wzmocnić swoją obronę powietrzną. Nad wspólną tarczą pracuje 19 państw. Są to m.in. Bułgaria, Estonia, Łotwa, Litwa, Rumunia oraz Słowacja, Słowenia, Czechy i Węgry. </p><br clear="all" />

## Nowa Zelandia ratuje swoje pingwiny. Szalona operacja
 - [https://wydarzenia.interia.pl/zagranica/news-nowa-zelandia-ratuje-swoje-pingwiny-szalona-operacja,nId,7048325](https://wydarzenia.interia.pl/zagranica/news-nowa-zelandia-ratuje-swoje-pingwiny-szalona-operacja,nId,7048325)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T09:42:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowa-zelandia-ratuje-swoje-pingwiny-szalona-operacja,nId,7048325"><img align="left" alt="Nowa Zelandia ratuje swoje pingwiny. Szalona operacja" src="https://i.iplsc.com/nowa-zelandia-ratuje-swoje-pingwiny-szalona-operacja/000HPE0LA4MVJ0HC-C321.jpg" /></a>Niepokojące wieści z Nowej Zelandii. Tajemnicza choroba dotyka tamtejsze endemiczne pingwiny żółtookie. Naukowcy robią wszystko, żeby dowiedzieć się, co to za schorzenie i jak można ptaki przed nim obronić. Udało się zidentyfikować dwa wirusy, które mogą być przyczyną zjawiska, jednak potrzebne są dalsze badania. W gigantyczną akcję pomocy zagrożonym pingwinom zaangażowali się ludzie z całego kraju. Dowiedz się więcej o niezwykłej walce o ocalenie jedynego w swoim rodzaju gatunku.</p><br clear="all" />

## Groźny wypadek w Oławie. Kobieta i dziecko potrąceni na pasach
 - [https://wydarzenia.interia.pl/kraj/news-grozny-wypadek-w-olawie-kobieta-i-dziecko-potraceni-na-pasac,nId,7048307](https://wydarzenia.interia.pl/kraj/news-grozny-wypadek-w-olawie-kobieta-i-dziecko-potraceni-na-pasac,nId,7048307)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T09:39:48+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-grozny-wypadek-w-olawie-kobieta-i-dziecko-potraceni-na-pasac,nId,7048307"><img align="left" alt="Groźny wypadek w Oławie. Kobieta i dziecko potrąceni na pasach" src="https://i.iplsc.com/grozny-wypadek-w-olawie-kobieta-i-dziecko-potraceni-na-pasac/000E4TWEMCWITNS2-C321.jpg" /></a>Do groźnie wyglądającego wypadku doszło w Oławie, gdzie doszło do potrącenia 46-letniej kobiety i pięcioletniego dziecka. Do wypadku doszło na oznakowanym przejściu dla pieszych.</p><br clear="all" />

## WHO ostrzega przed epidemią cholery. Dwukrotny wzrost zachorowań
 - [https://wydarzenia.interia.pl/zagranica/news-who-ostrzega-przed-epidemia-cholery-dwukrotny-wzrost-zachoro,nId,7048287](https://wydarzenia.interia.pl/zagranica/news-who-ostrzega-przed-epidemia-cholery-dwukrotny-wzrost-zachoro,nId,7048287)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T09:26:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-who-ostrzega-przed-epidemia-cholery-dwukrotny-wzrost-zachoro,nId,7048287"><img align="left" alt="WHO ostrzega przed epidemią cholery. Dwukrotny wzrost zachorowań" src="https://i.iplsc.com/who-ostrzega-przed-epidemia-cholery-dwukrotny-wzrost-zachoro/000HPDV0OLWUJ41S-C321.jpg" /></a>Światowa Organizacja Zdrowia poinformowała o dwukrotnym wzroście przypadków cholery na świecie. Zdaniem ekspertów sytuacja w kilku regionach na świecie zaczyna wymykać się spod kontroli, co grozi wybuchem epidemii.</p><br clear="all" />

## Stanisław wyskoczył z samolotu ostatni. Nowe ustalenia po tragedii w Pile
 - [https://wydarzenia.interia.pl/wielkopolskie/news-stanislaw-wyskoczyl-z-samolotu-ostatni-nowe-ustalenia-po-tra,nId,7048251](https://wydarzenia.interia.pl/wielkopolskie/news-stanislaw-wyskoczyl-z-samolotu-ostatni-nowe-ustalenia-po-tra,nId,7048251)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T08:45:56+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-stanislaw-wyskoczyl-z-samolotu-ostatni-nowe-ustalenia-po-tra,nId,7048251"><img align="left" alt="Stanisław wyskoczył z samolotu ostatni. Nowe ustalenia po tragedii w Pile " src="https://i.iplsc.com/stanislaw-wyskoczyl-z-samolotu-ostatni-nowe-ustalenia-po-tra/000HPD7NFQG46J7F-C321.jpg" /></a>Stanisław wyskoczył z samolotu jako ostatni. Z kolegą wykonał jeszcze tzw. zejście, w trakcie odejścia najprawdopodobniej stracił przytomność i z dużą siłą uderzył w ziemię. Jak ustaliła Interia, skoczek nie podjął próby otwarcia żadnego z dwóch spadochronów. W poniedziałek ma odbyć się sekcja zwłok 50-letniego mężczyzny, który podczas niedzielnego skoku w Pile stracił życie. </p><br clear="all" />

## Niemcy mierzą się z kryzysem. Deweloperzy wstrzymują budowy
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-mierza-sie-z-kryzysem-deweloperzy-wstrzymuja-budowy,nId,7048258](https://wydarzenia.interia.pl/zagranica/news-niemcy-mierza-sie-z-kryzysem-deweloperzy-wstrzymuja-budowy,nId,7048258)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T08:42:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-mierza-sie-z-kryzysem-deweloperzy-wstrzymuja-budowy,nId,7048258"><img align="left" alt="Niemcy mierzą się z kryzysem. Deweloperzy wstrzymują budowy " src="https://i.iplsc.com/niemcy-mierza-sie-z-kryzysem-deweloperzy-wstrzymuja-budowy/000HPDH03N2AAL60-C321.jpg" /></a>Na rynku mieszkaniowym w Niemczech trwa kryzys, a w ciągu ostatnich dwunastu miesięcy wnioski o upadłość złożyło dwukrotnie więcej deweloperów niż rok wcześniej. Kanclerz Olaf Scholz zapowiedział rozmowy na ten temat sytuacji w branży, ale deweloperzy oceniają działania rządu jako niewystarczające. </p><br clear="all" />

## Niemcy: Kierowcy polskiej firmy strajkują. Nie wiedzieli pensji od miesięcy
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-kierowcy-polskiej-firmy-strajkuja-nie-wiedzieli-pensj,nId,7048246](https://wydarzenia.interia.pl/zagranica/news-niemcy-kierowcy-polskiej-firmy-strajkuja-nie-wiedzieli-pensj,nId,7048246)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T08:30:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-kierowcy-polskiej-firmy-strajkuja-nie-wiedzieli-pensj,nId,7048246"><img align="left" alt="Niemcy: Kierowcy polskiej firmy strajkują. Nie wiedzieli pensji od miesięcy" src="https://i.iplsc.com/niemcy-kierowcy-polskiej-firmy-strajkuja-nie-wiedzieli-pensj/000HPDFJ3O70CT2U-C321.jpg" /></a>Strajk na niemieckim parkingu trwa już dziesięć tygodni. Pracownicy - kierowcy - domagają się od polskiej grupy spedycyjnej wypłaty zaległych pensji. Poszkodowani prowadzą strajk głodowy, skarżą się na zimno i zmęczenie. Podkreślają jednak: - Zostaniemy do końca.</p><br clear="all" />

## Skazańcy stworzyli "luksusowe" więzienie. W środku basen, restauracje i zoo
 - [https://wydarzenia.interia.pl/zagranica/news-skazancy-stworzyli-luksusowe-wiezienie-w-srodku-basen-restau,nId,7046791](https://wydarzenia.interia.pl/zagranica/news-skazancy-stworzyli-luksusowe-wiezienie-w-srodku-basen-restau,nId,7046791)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T08:23:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-skazancy-stworzyli-luksusowe-wiezienie-w-srodku-basen-restau,nId,7046791"><img align="left" alt="Skazańcy stworzyli &quot;luksusowe&quot; więzienie. W środku basen, restauracje i zoo" src="https://i.iplsc.com/skazancy-stworzyli-luksusowe-wiezienie-w-srodku-basen-restau/000HPBCGTW2IGP83-C321.jpg" /></a>Władze Wenezueli odzyskały kontrolę nad zakładem karnym, który przez wiele lat znajdował się pod kontrolą gangów. Skazańcy stworzyli w nim swoiste &quot;mini-miasto&quot; z restauracjami, klubem nocnym, basenem, zoo, a nawet placem zabaw dla dzieci. W specjalnej operacji uczestniczyło ponad 11 tys. funkcjonariuszy wenezuelskich sił bezpieczeństwa.</p><br clear="all" />

## Putin wydał nowy rozkaz. Rosjanie mają czas do października
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-wydal-nowy-rozkaz-rosjanie-maja-czas-do-pazdziernika,nId,7048243](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-wydal-nowy-rozkaz-rosjanie-maja-czas-do-pazdziernika,nId,7048243)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T07:59:29+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-wydal-nowy-rozkaz-rosjanie-maja-czas-do-pazdziernika,nId,7048243"><img align="left" alt="Putin wydał nowy rozkaz. Rosjanie mają czas do października" src="https://i.iplsc.com/putin-wydal-nowy-rozkaz-rosjanie-maja-czas-do-pazdziernika/000HPDBSLJVTJ6AY-C321.jpg" /></a>Prezydent Władimir Putin nakazał ministrowi obrony Siergiejowi Szojgu powstrzymanie ukraińskiej kontrofensywy i przejęcie inicjatywy - informuje ISW. Zdaniem analityków, to reakcja na sukcesy Sił Zbrojnych Ukrainy na kierunku zaporoskim.</p><br clear="all" />

## Ryś w "leśnym szpitalu". Leśników zaalarmowali mieszkańcy
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-rys-w-lesnym-szpitalu-lesnikow-zaalarmowali-mieszkancy,nId,7048207](https://wydarzenia.interia.pl/warminsko-mazurskie/news-rys-w-lesnym-szpitalu-lesnikow-zaalarmowali-mieszkancy,nId,7048207)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T07:23:40+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-rys-w-lesnym-szpitalu-lesnikow-zaalarmowali-mieszkancy,nId,7048207"><img align="left" alt="Ryś w &quot;leśnym szpitalu&quot;. Leśników zaalarmowali mieszkańcy" src="https://i.iplsc.com/rys-w-lesnym-szpitalu-lesnikow-zaalarmowali-mieszkancy/000HPD0NOPF34CDV-C321.jpg" /></a>Wiadomo, co z rysiem, który w zeszłym tygodniu trafił pod opiekę leśników z Nadleśnictwa Olsztynek. Lasy Państwowe udostępniły zdjęcia uratowanego kota i podkreślają, że jego stan cały czas się jeszcze stabilizuje. </p><br clear="all" />

## PiSbus ruszył w Polskę. M. Morawiecki podał cel objazdu
 - [https://wydarzenia.interia.pl/kraj/news-pisbus-rusza-w-polske-premier-morawiecki-podal-cel-objazdu,nId,7048197](https://wydarzenia.interia.pl/kraj/news-pisbus-rusza-w-polske-premier-morawiecki-podal-cel-objazdu,nId,7048197)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T07:05:24+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pisbus-rusza-w-polske-premier-morawiecki-podal-cel-objazdu,nId,7048197"><img align="left" alt="PiSbus ruszył w Polskę. M. Morawiecki podał cel objazdu" src="https://i.iplsc.com/pisbus-ruszyl-w-polske-m-morawiecki-podal-cel-objazdu/000HPCRN1LXVOSU0-C321.jpg" /></a>- Nadchodzące wybory mogą zadecydować o kształcie Polski na mapie - mówił Mateusz Morawiecki. Szef rządu oficjalnie zainaugurował objazd kraju PiSbusem pod hasłem &quot;Bezpieczna przyszłość&quot;.</p><br clear="all" />

## Zmasowany atak Rosjan na Odessę. Użyli Oniksów
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zmasowany-atak-rosjan-na-odesse-uzyli-oniksow,nId,7048193](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zmasowany-atak-rosjan-na-odesse-uzyli-oniksow,nId,7048193)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T06:49:58+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zmasowany-atak-rosjan-na-odesse-uzyli-oniksow,nId,7048193"><img align="left" alt="Zmasowany atak Rosjan na Odessę. Użyli Oniksów" src="https://i.iplsc.com/zmasowany-atak-rosjan-na-odesse-uzyli-oniksow/000HPD1B1BJSB87C-C321.jpg" /></a>Rosyjscy okupanci atakowali minionej nocy port w Odessie, gdzie rakiety zniszczyły magazyny zboża. Zmasowany ostrzał odbył się również dzień wcześniej w obwodzie chersońskim - Rosjanie ostrzelali go 87 razy, zginęły dwie osoby. Z kolei ukraińskie drony uszkodziły kilka domów oraz budynek administracji publicznej w obwodzie kurskim, a dwa kolejne drony zostały zestrzelone nad Biełgorodem - podały rosyjskie władze.</p><br clear="all" />

## Zmiana lidera w rankingu zaufania. Najnowszy sondaż
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zmiana-lidera-w-rankingu-zaufania-najnowszy-sondaz,nId,7048181](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zmiana-lidera-w-rankingu-zaufania-najnowszy-sondaz,nId,7048181)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T06:08:46+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zmiana-lidera-w-rankingu-zaufania-najnowszy-sondaz,nId,7048181"><img align="left" alt="Zmiana lidera w rankingu zaufania. Najnowszy sondaż" src="https://i.iplsc.com/zmiana-lidera-w-rankingu-zaufania-najnowszy-sondaz/000HPCQSEIB4MS30-C321.jpg" /></a>Andrzej Duda wyprzedził Rafała Trzaskowskiego i powrócił na pierwsze miejsce w rankingu zaufania do osób publicznych. Swoje notowania poprawili premier Mateusz Morawiecki i lider Platformy Obywatelskiej Donald Tusk, kolejny raz walcząc o ostatnie miejsce na podium - wynika z najnowszego sondażu IBRiS.</p><br clear="all" />

## Wybory 2023. Kampania nabiera tempa. Premier w trasie, opozycja walczy o głosy
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/na-zywo-wybory-2023-kampania-nabiera-tempa-premier-w-trasie-opozycja,nzId,4769](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/na-zywo-wybory-2023-kampania-nabiera-tempa-premier-w-trasie-opozycja,nzId,4769)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T06:08:25+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/na-zywo-wybory-2023-kampania-nabiera-tempa-premier-w-trasie-opozycja,nzId,4769"><img align="left" alt="Wybory 2023. Kampania nabiera tempa. Premier w trasie, opozycja walczy o głosy" src="https://i.iplsc.com/wybory-2023-kampania-nabiera-tempa-premier-w-trasie-opozycja/000HPCQ7QSSLL8BV-C321.jpg" /></a>Wybory parlamentarne coraz bliżej. W poniedziałek premier Mateusz Morawiecki wyruszył w Polskę PiSBusem, z kolei opozycja zaplanowała konferencje prasowe. Śledź relację na żywo.</p><br clear="all" />

## Nowy kierunek ofensywy. Ukraińcy ujawniają plany
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowy-kierunek-ofensywy-ukraincy-ujawniaja-plany,nId,7048172](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowy-kierunek-ofensywy-ukraincy-ujawniaja-plany,nId,7048172)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T05:17:40+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowy-kierunek-ofensywy-ukraincy-ujawniaja-plany,nId,7048172"><img align="left" alt="Nowy kierunek ofensywy. Ukraińcy ujawniają plany" src="https://i.iplsc.com/nowy-kierunek-ofensywy-ukraincy-ujawniaja-plany/000HPCN9XNHELQ0R-C321.jpg" /></a>Krym stał się kolejnym kierunkiem, na którym prowadzona jest ukraińska ofensywa - podał ekspert wojskowy Oleg Żdanow. Ocenił przy tym, że podczas działań Sił Zbrojnych Ukrainy nie ucierpi ludność cywilna, a obiekty wojskowe niszczone są &quot;jeden po drugim&quot;. W ostatnich dniach przeprowadzono ataki na Krymie, wymierzone w okupantów.</p><br clear="all" />

## Matteo Messina Denaro nie żyje. Słynny mafiozo był nieuchwytny przez 30 lat
 - [https://wydarzenia.interia.pl/zagranica/news-matteo-messina-denaro-nie-zyje-slynny-mafiozo-byl-nieuchwytn,nId,7048170](https://wydarzenia.interia.pl/zagranica/news-matteo-messina-denaro-nie-zyje-slynny-mafiozo-byl-nieuchwytn,nId,7048170)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T04:48:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-matteo-messina-denaro-nie-zyje-slynny-mafiozo-byl-nieuchwytn,nId,7048170"><img align="left" alt="Matteo Messina Denaro nie żyje. Słynny mafiozo był nieuchwytny przez 30 lat" src="https://i.iplsc.com/matteo-messina-denaro-nie-zyje-slynny-mafiozo-byl-nieuchwytn/000HPCMQ8658PWFD-C321.jpg" /></a>Matteo Messina Denaro, słynny mafiozo i przywódca Cosa Nostry, zmarł w szpitalu w środkowych Włoszech - informuje włoska agencja prasowa ANSA. &quot;Ostatni Ojciec Chrzestny&quot; ukrywał się 30 lat przed wymiarem sprawiedliwości. Wpadł z powodu choroby.
</p><br clear="all" />

## Premier o "Zielonej granicy". "Robi z Polaków bandę prymitywów"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-o-zielonej-granicy-robi-z-polakow-bande-prymitywow,nId,7048162](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-o-zielonej-granicy-robi-z-polakow-bande-prymitywow,nId,7048162)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-25T04:25:02+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-o-zielonej-granicy-robi-z-polakow-bande-prymitywow,nId,7048162"><img align="left" alt="Premier o &quot;Zielonej granicy&quot;. &quot;Robi z Polaków bandę prymitywów&quot;" src="https://i.iplsc.com/premier-o-zielonej-granicy-robi-z-polakow-bande-prymitywow/000HPCMEFMUGNYXT-C321.jpg" /></a>- Film &quot;Zielona granica” Agnieszki Holland robi z Polaków bandę ciemniaków, prymitywów, ludzi, którzy nie zasługują na szacunek. To apogeum pedagogiki wstydu, tego wszystkiego, co było haniebne i hańbiące w działaniach mediów i pseudoelit III RP - ocenił w niedzielę premier Mateusz Morawiecki. Dodał, że Polska jest wspaniałym narodem, który zasługuje na &quot;najwyższy medal&quot;.</p><br clear="all" />

