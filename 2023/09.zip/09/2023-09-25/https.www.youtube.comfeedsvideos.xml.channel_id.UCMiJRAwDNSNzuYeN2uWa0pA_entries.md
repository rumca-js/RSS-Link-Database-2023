# Source:Mrwhosetheboss, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCMiJRAwDNSNzuYeN2uWa0pA, language:en-US

## iPhone 15 / 15 Plus Review - Suspiciously Good!
 - [https://www.youtube.com/watch?v=s1XVb4mdELc](https://www.youtube.com/watch?v=s1XVb4mdELc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCMiJRAwDNSNzuYeN2uWa0pA
 - date published: 2023-09-25T14:23:18+00:00

My Apple iPhone 15 / 15 Plus review, including camera, battery, and more! For the latest iPhone 15 cases from TORRAS, including the MagStand case, Airbag case and Magnetic case for your phone, go to Amazon US https://amzn.to/46hutiC with code 20whoseboss to get 20% OFF today!

Official website with code 20whoseboss: https://torraslife.com/collections/boss-case
Amazon UK with code 20whoseboss: https://amzn.to/3PusKzT
#TORRAS #Ostandcase #Airbag case #TORRAScase

I spend a LOT of time trying to make my videos as concise, polished and useful as possible for you - if you would like to support me on that mission then consider subscribing to the channel - you'd make my day 😁

For my tech hot takes: http://twitter.com/Mrwhosetheboss
For my Personal Posts: http://instagram.com/mrwhosetheboss
Does anyone still use this anymore?: https://facebook.com/mrwhosetheboss

Amazon Affiliate links (if you buy anything through these it will support the channel and allow us to buy better gear!):
Amazon U

