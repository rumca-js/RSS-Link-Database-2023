# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Philips changes terms AFTER the sale: requires data-sharing account to use a light bulb...
 - [https://www.youtube.com/watch?v=vR2j-r3pmng](https://www.youtube.com/watch?v=vR2j-r3pmng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-09-25T16:11:43+00:00

https://www.home-assistant.io/blog/2023/09/22/philips-hue-force-users-upload-data-to-cloud/
https://amzn.to/3ER3tuJ 

👉 Merchandise: https://store.rossmanngroup.com/memes-dreams.html
🔵 Cheesy mugs & t-shirts: https://bit.ly/rossmannstore

👉 Rossmann chat: https://matrix.to/#/#rossmannrepair:matrix.org

👉 Equipment used:
🔵 Chair: https://ebay.us/uYLTzn
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av 
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit ca

