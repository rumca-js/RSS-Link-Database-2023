# Source:Neowin, URL:https://www.neowin.net/news/rss/, language:en-us

## 12V-2×6 power connector won't burn or melt your RTX 4090/4080 even if not inserted properly
 - [https://www.neowin.net/news/12v-26-power-connector-wont-burn-or-melt-your-rtx-40904080-even-if-not-inserted-properly/](https://www.neowin.net/news/12v-26-power-connector-wont-burn-or-melt-your-rtx-40904080-even-if-not-inserted-properly/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T21:48:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/10/1667204077_4090_broken_12-pin_(via_reddit)_medium.jpg" /></div>Remember the RTX 4090/4080 melting and burning power connectors? It looks like there is finally a viable alternative solution so that users won&#039;t need second-guessing if their GPUs will burn or not. <a href="https://www.neowin.net/news/12v-26-power-connector-wont-burn-or-melt-your-rtx-40904080-even-if-not-inserted-properly">Read more...</a>

## AMD's Graphics Business Unit head Scott Herkelman will depart the company by the end of 2023
 - [https://www.neowin.net/news/amds-graphics-business-unit-head-scott-herkelman-will-depart-the-company-by-the-end-of-2023/](https://www.neowin.net/news/amds-graphics-business-unit-head-scott-herkelman-will-depart-the-company-by-the-end-of-2023/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T21:18:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/07/1594144508_amd_radeon_medium.jpg" /></div>Scott Herkelman, who has been with AMD as the General Manager of its Graphics Business Unit, revealed today he will depart the company. No specific reason was given for his decision. <a href="https://www.neowin.net/news/amds-graphics-business-unit-head-scott-herkelman-will-depart-the-company-by-the-end-of-2023">Read more...</a>

## The upcoming Microsoft Bing Chat "No Search" feature will now be a plugin
 - [https://www.neowin.net/news/the-upcoming-microsoft-bing-chat-no-search-feature-will-now-be-a-plugin/](https://www.neowin.net/news/the-upcoming-microsoft-bing-chat-no-search-feature-will-now-be-a-plugin/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T20:44:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/08/1692809197_f4oihn3x0aewpkp_medium.jpg" /></div>Microsoft&#039;s Mikhail Parakhin revealed the &quot;No Search feature that was in testing with a small number of Bing Chat users has now turned into a plugin, and will be a part of the general plugin launch. <a href="https://www.neowin.net/news/the-upcoming-microsoft-bing-chat-no-search-feature-will-now-be-a-plugin">Read more...</a>

## Microsoft offers more info on the upcoming Age of Empires IV Variant Civilizations feature
 - [https://www.neowin.net/news/microsoft-offers-more-info-on-the-upcoming-age-of-empires-iv-variant-civilizations-feature/](https://www.neowin.net/news/microsoft-offers-more-info-on-the-upcoming-age-of-empires-iv-variant-civilizations-feature/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T20:12:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695671028_jeanne_blog_banner_1920x1080_medium.jpg" /></div>Age of Empires IV will soon add the The Sultans Ascend expansion pack, which will include an all-new feature called Variant Civilizations that will provide more variety to the RTS game. <a href="https://www.neowin.net/news/microsoft-offers-more-info-on-the-upcoming-age-of-empires-iv-variant-civilizations-feature">Read more...</a>

## Mastering Microsoft Outlook: 20 Expert Tips & Tricks Guide Download
 - [https://www.neowin.net/sponsored/mastering-microsoft-outlook-20-expert-tips--tricks-guide-download/](https://www.neowin.net/sponsored/mastering-microsoft-outlook-20-expert-tips--tricks-guide-download/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T20:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/07/1690455270_test_3_medium.jpg" /></div>This guide will provide 20 expert tips and tricks to help you increase your productivity, save time, and optimize your Outlook experience every day to manage emails, appointments, tasks, and contacts. <a href="https://www.neowin.net/sponsored/mastering-microsoft-outlook-20-expert-tips--tricks-guide-download">Read more...</a>

## Microsoft is seeking a nuclear power manager as AI consumes too much energy
 - [https://www.neowin.net/news/microsoft-is-seeking-a-nuclear-power-manager-as-ai-consumes-too-much-energy/](https://www.neowin.net/news/microsoft-is-seeking-a-nuclear-power-manager-as-ai-consumes-too-much-energy/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T19:26:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/07/1564533528_azuresolar_medium.jpg" /></div>Microsoft wants to use small modular nuclear reactors to power data centers that house AI tools. It is hiring for a principal program manager for nuclear technology to develop a strategy. <a href="https://www.neowin.net/news/microsoft-is-seeking-a-nuclear-power-manager-as-ai-consumes-too-much-energy">Read more...</a>

## Reddit announces Contributor Program, making karma actually mean something
 - [https://www.neowin.net/news/reddit-announces-contributor-program-making-karma-actually-mean-something/](https://www.neowin.net/news/reddit-announces-contributor-program-making-karma-actually-mean-something/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T18:54:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/08/1596832132_reddit_red_medium.jpg" /></div>Reddit has announced a new Contributor Program today, which awards cash to users who post quality content on the platform based on the amount of karma and gold that a user earns from their posts. <a href="https://www.neowin.net/news/reddit-announces-contributor-program-making-karma-actually-mean-something">Read more...</a>

## You will be able to unlock the Rivian EV truck and SUV soon in Forza Horizon 5
 - [https://www.neowin.net/news/you-will-be-able-to-unlock-the-rivian-ev-truck-and-suv-soon-in-forza-horizon-5/](https://www.neowin.net/news/you-will-be-able-to-unlock-the-rivian-ev-truck-and-suv-soon-in-forza-horizon-5/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T18:42:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695663264_fh5_series25_rivian_02_16x9_1920x1080-a660765ab34be520e876_medium.jpg" /></div>The  2022 Rivian R1T EV truck and the 2022  2022 Rivian R1T can be unlocked soon in the PC and Xbox racing game Forza Horizon 5 if you complete some upcoming specific EventLab races. <a href="https://www.neowin.net/news/you-will-be-able-to-unlock-the-rivian-ev-truck-and-suv-soon-in-forza-horizon-5">Read more...</a>

## Starfield update improves performance, fixes loot puddles, and adds suns to AMD users
 - [https://www.neowin.net/news/starfield-update-improves-performance-fixes-loot-puddles-and-adds-suns-to-amd-users/](https://www.neowin.net/news/starfield-update-improves-performance-fixes-loot-puddles-and-adds-suns-to-amd-users/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T18:12:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695663677_photo_2023-09-20-195535_medium.jpg" /></div>A second update has hit Bethesda and Xbox&#039;s sci-fi RPG Starfield. It fixes a popular puddle looting bug, brings the sun back to planets for users of AMD Radeon graphics cards, and more issues. <a href="https://www.neowin.net/news/starfield-update-improves-performance-fixes-loot-puddles-and-adds-suns-to-amd-users">Read more...</a>

## Microsoft Office Pro Plus 2021 + Microsoft Training Bundle: ZERO to ADVANCED now 79% off
 - [https://www.neowin.net/deals/microsoft-office-pro-plus-2021--microsoft-training-bundle-zero-to-advanced-now-79-off/](https://www.neowin.net/deals/microsoft-office-pro-plus-2021--microsoft-training-bundle-zero-to-advanced-now-79-off/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T18:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1681987131_1655982433_office-2021-win_medium.jpg" /></div>Be an Microsoft Power User with this lifetime license PLUS 6 courses on Excel, PowerPoint, Word and more along with a lifetime of Office Pro Plus with today&#039;s highlighted deal via Neowin Deals. <a href="https://www.neowin.net/deals/microsoft-office-pro-plus-2021--microsoft-training-bundle-zero-to-advanced-now-79-off">Read more...</a>

## You could win a black 1TB Xbox Series S in a new interactive Saw X livestream Sept. 27
 - [https://www.neowin.net/news/you-could-win-a-black-1tb-xbox-series-s-in-a-new-interactive-saw-x-livestream-sept-27/](https://www.neowin.net/news/you-could-win-a-black-1tb-xbox-series-s-in-a-new-interactive-saw-x-livestream-sept-27/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T16:32:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695658650_xbox-saw-x_medium.jpg" /></div>Microsoft is teaming up with Lionsgate to promote the upcoming release of Saw X with a Twitch interactive live event where people could win a black 1TV Xbox Series S console among other prizes. <a href="https://www.neowin.net/news/you-could-win-a-black-1tb-xbox-series-s-in-a-new-interactive-saw-x-livestream-sept-27">Read more...</a>

## Spotify is adding a new AI feature to translate podcast host voices in different languages
 - [https://www.neowin.net/news/spotify-is-adding-a-new-ai-feature-to-translate-podcast-host-voices-in-different-languages/](https://www.neowin.net/news/spotify-is-adding-a-new-ai-feature-to-translate-podcast-host-voices-in-different-languages/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T16:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1693835182_spotifyforpodcasters_medium.jpg" /></div>Spotify is starting to use a Voice Translation feature in some of its podcasts that will turn the voices of the podcast hosts so they sound like they are native speakers in different languages. <a href="https://www.neowin.net/news/spotify-is-adding-a-new-ai-feature-to-translate-podcast-host-voices-in-different-languages">Read more...</a>

## Leaked code from X app suggests that calls will be exclusively for Premium subscribers only
 - [https://www.neowin.net/news/leaked-code-from-x-app-suggests-that-calls-will-be-exclusively-for-premium-subscribers-only/](https://www.neowin.net/news/leaked-code-from-x-app-suggests-that-calls-will-be-exclusively-for-premium-subscribers-only/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T15:40:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695099508_x_logo_2023_medium.jpg" /></div>Code within the X app suggests that the platform will be adding both audio and video call functionality in the future, but this will be restricted to premium subscribers only as a paid feature. <a href="https://www.neowin.net/news/leaked-code-from-x-app-suggests-that-calls-will-be-exclusively-for-premium-subscribers-only">Read more...</a>

## GEEKNUC are discounting the Intel NUC 12 Enthusiast and Intel Nuc 13 Pro by $120
 - [https://www.neowin.net/deals/geeknuc-are-discounting-the-intel-nuc-12-enthusiast-and-intel-nuc-13-pro-by-120/](https://www.neowin.net/deals/geeknuc-are-discounting-the-intel-nuc-12-enthusiast-and-intel-nuc-13-pro-by-120/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T15:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695302406_image2_medium.jpg" /></div>You can score one of three options for the Intel NUC 13 Pro Arena Canyon, but also on the NUC 12 Enthusiast Serpent Canyon. Profit from the lowest prices anywhere in the United States this summer. <a href="https://www.neowin.net/deals/geeknuc-are-discounting-the-intel-nuc-12-enthusiast-and-intel-nuc-13-pro-by-120">Read more...</a>

## Check out this SteelSeries gaming mouse with 256 weight options for its lowest price ever
 - [https://www.neowin.net/deals/check-out-this-steelseries-gaming-mouse-with-256-weight-options-for-its-lowest-price-ever/](https://www.neowin.net/deals/check-out-this-steelseries-gaming-mouse-with-256-weight-options-for-its-lowest-price-ever/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T14:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695651481_steel-series-650-mouse_medium.jpg" /></div>The SteelSeries Rival 650 wireless gaming mouse also includes removable sides that can handle up to 256 different options for weight, and it&#039;s priced at just $59.95 right now at Amazon. <a href="https://www.neowin.net/deals/check-out-this-steelseries-gaming-mouse-with-256-weight-options-for-its-lowest-price-ever">Read more...</a>

## ChatGPT is rolling out new voice and image features for the chatbot on its mobile apps
 - [https://www.neowin.net/news/chatgpt-is-rolling-out-new-voice-and-image-features-for-the-chatbot-on-its-mobile-apps/](https://www.neowin.net/news/chatgpt-is-rolling-out-new-voice-and-image-features-for-the-chatbot-on-its-mobile-apps/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T14:04:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/06/1687928718_chatgpt_on_iphone_medium.jpg" /></div>OpenAI has announced it is adding more voice and image features to its ChatGPT chatbot. It will allow users to speak with the chatbot in a conversation and images can be uploaded for analysis. <a href="https://www.neowin.net/news/chatgpt-is-rolling-out-new-voice-and-image-features-for-the-chatbot-on-its-mobile-apps">Read more...</a>

## Intel confirms Meteor Lake CPUs are coming to the desktop in 2024
 - [https://www.neowin.net/news/intel-confirms-meteor-lake-cpus-are-coming-to-the-desktop-in-2024/](https://www.neowin.net/news/intel-confirms-meteor-lake-cpus-are-coming-to-the-desktop-in-2024/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T13:34:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695138447_intel-core-ultra_medium.jpg" /></div>Intel VP  Michelle Johnston Holthaus confirmed that desktop PCs will be sold with the company&#039;s upcoming Meteor Lake CPUs sometime in 2024, after debuting in laptop PCs in December. <a href="https://www.neowin.net/news/intel-confirms-meteor-lake-cpus-are-coming-to-the-desktop-in-2024">Read more...</a>

## LG Gram Fold is the latest Windows 11 foldable laptop, and it's also very expensive
 - [https://www.neowin.net/news/lg-gram-fold-is-the-latest-windows-11-foldable-laptop-and-its-also-very-expensive/](https://www.neowin.net/news/lg-gram-fold-is-the-latest-windows-11-foldable-laptop-and-its-also-very-expensive/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T13:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695644049_1.lg_-19_medium.jpg" /></div>The LG Gram Fold is a Windows 11 laptop with a 17-inch screen that can be folded into a 12-inch notebook. It&#039;s only on sale in South Korea for now, and it&#039;s priced at 4.99 million won ($3,728.75) <a href="https://www.neowin.net/news/lg-gram-fold-is-the-latest-windows-11-foldable-laptop-and-its-also-very-expensive">Read more...</a>

## Capcom would gracefully decline any acquisition offer from Microsoft, says COO
 - [https://www.neowin.net/news/capcom-would-gracefully-decline-any-acquisition-offer-from-microsoft-says-coo/](https://www.neowin.net/news/capcom-would-gracefully-decline-any-acquisition-offer-from-microsoft-says-coo/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T11:36:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695635100_capcom-1_medium.jpg" /></div>Capcom&#039;s COO says that the company will &quot;never&quot; be acquired and that it prefers organic growth to mergers and acquisitions. The studio wants to remain an equal partner and not be bought. <a href="https://www.neowin.net/news/capcom-would-gracefully-decline-any-acquisition-offer-from-microsoft-says-coo">Read more...</a>

## Amazon invests $5 billion in Anthropic to compete with Microsoft's OpenAI investments
 - [https://www.neowin.net/news/amazon-invests-5-billion-in-anthropic-to-compete-with-microsofts-openai-investments/](https://www.neowin.net/news/amazon-invests-5-billion-in-anthropic-to-compete-with-microsofts-openai-investments/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T11:24:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695632766_amazonanthropic_blog_v1_2023-09-23-001347_uaqw_medium.jpg" /></div>Amazon has made a major investment in Anthropic, taking a minority stake for $1.25 billion with an option for a total of $4 billion. Anthropic will use AWS as its primary cloud provider. <a href="https://www.neowin.net/news/amazon-invests-5-billion-in-anthropic-to-compete-with-microsofts-openai-investments">Read more...</a>

## ExplorerPatcher fixes new File Explorer crashes, never combine taskbar bug on Windows 11
 - [https://www.neowin.net/news/explorerpatcher-fixes-new-file-explorer-crashes-never-combine-taskbar-bug-on-windows-11/](https://www.neowin.net/news/explorerpatcher-fixes-new-file-explorer-crashes-never-combine-taskbar-bug-on-windows-11/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T11:12:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/12/1671191247_windows_11_22h2_(11)_medium.jpg" /></div>ExplorerPatcher was having several issues with Windows 10 as well as on 11. These bugs mainly pertained to File Explorer and Taskbar crashing, among others. The latest releases fix several of these. <a href="https://www.neowin.net/news/explorerpatcher-fixes-new-file-explorer-crashes-never-combine-taskbar-bug-on-windows-11">Read more...</a>

## Google to discontinue the Basic HTML version of Gmail next year
 - [https://www.neowin.net/news/google-to-discontinue-the-basic-html-version-of-gmail-next-year/](https://www.neowin.net/news/google-to-discontinue-the-basic-html-version-of-gmail-next-year/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T10:58:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/06/1624381091_google_self_destruct_medium.jpg" /></div>An update to Google&#039;s support page confirms that the company will discontinue the Basic HTML version of Gmail intended for devices with slower internet connections in January 2024. <a href="https://www.neowin.net/news/google-to-discontinue-the-basic-html-version-of-gmail-next-year">Read more...</a>

## WingetUI gets custom sources, filtering, performance boost, Defender block prevention
 - [https://www.neowin.net/news/wingetui-gets-custom-sources-filtering-performance-boost-defender-block-prevention/](https://www.neowin.net/news/wingetui-gets-custom-sources-filtering-performance-boost-defender-block-prevention/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T08:04:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695627603_wingetui_banner_medium.jpg" /></div>WingetUI has received a multitude of upgrades with its latest update. The new release brings performance boosts related to packages and CLI, new special icons, digital signing, and more. <a href="https://www.neowin.net/news/wingetui-gets-custom-sources-filtering-performance-boost-defender-block-prevention">Read more...</a>

## NVIDIA envisions DLSS 10 as a full neural rendering system interfaced with game engines
 - [https://www.neowin.net/news/nvidia-envisions-dlss-10-as-a-full-neural-rendering-system-interfaced-with-game-engines/](https://www.neowin.net/news/nvidia-envisions-dlss-10-as-a-full-neural-rendering-system-interfaced-with-game-engines/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T07:48:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/07/1690480952_nvidia_logo_in_black_and_green_medium.jpg" /></div>NVIDIA&#039;s VP of Applied Deep Learning Research, Bryan Catanzaro said DLSS 10 in the far future is going to be a completely neural rendering system that interfaces with a game engine in different ways. <a href="https://www.neowin.net/news/nvidia-envisions-dlss-10-as-a-full-neural-rendering-system-interfaced-with-game-engines">Read more...</a>

## After server outages, Payday 3 devs looking into being "less dependent on online services"
 - [https://www.neowin.net/news/after-server-outages-payday-3-devs-looking-into-being-less-dependent-on-online-services/](https://www.neowin.net/news/after-server-outages-payday-3-devs-looking-into-being-less-dependent-on-online-services/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-25T07:06:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/07/1690476877_ss_c751853378d528dd15c075465d29c99acee5db4a.1920x1080_medium.jpg" /></div>Despite gaining over a million unique players, the release of Payday 3 has been marred significantly by ongoing server issues. Developer Starbreeze has announced what solutions are being worked on. <a href="https://www.neowin.net/news/after-server-outages-payday-3-devs-looking-into-being-less-dependent-on-online-services">Read more...</a>

