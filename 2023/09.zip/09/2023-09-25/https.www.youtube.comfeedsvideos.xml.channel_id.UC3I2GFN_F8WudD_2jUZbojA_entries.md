# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Carolina Durante - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=F0b59vopL0c](https://www.youtube.com/watch?v=F0b59vopL0c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-25T15:00:11+00:00

http://KEXP.ORG presents Carolina Durante performing live in the KEXP studio. Recorded July 20, 2023

Songs:
Aaaaaa#$!&
La Noche De Los Muertos Vivientes
Las Canciones De Juanita
Casa Kira

Diego Ibañez - Vocals
Mario del Valle - Guitar, Vocals
Martin Vallhonrat - Bass, Vocals
Juan Pedrayes - Drums

Host: Albina Cabrera
Audio Engineers: Julian Martlew, Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Alaia D’Alessandro

https://carolinadurante.com
http://kexp.org

## Carolina Durante - Las Canciones De Juanita (Live on KEXP)
 - [https://www.youtube.com/watch?v=s2PUIfVD1yY](https://www.youtube.com/watch?v=s2PUIfVD1yY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-25T11:00:44+00:00

http://KEXP.ORG presents Carolina Durante performing “Las Canciones De Juanita” live in the KEXP studio. Recorded July 20, 2023

Diego Ibañez - Vocals
Mario del Valle - Guitar, Vocals
Martin Vallhonrat - Bass, Vocals
Juan Pedrayes - Drums

Host: Albina Cabrera
Audio Engineers: Julian Martlew, Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Alaia D’Alessandro

https://carolinadurante.com
http://kexp.org

## Carolina Durante - La Noche De Los Muertos Vivientes (Live on KEXP)
 - [https://www.youtube.com/watch?v=el8P_-JNMHo](https://www.youtube.com/watch?v=el8P_-JNMHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-25T11:00:34+00:00

http://KEXP.ORG presents Carolina Durante performing “La Noche De Los Muertos Vivientes” live in the KEXP studio. Recorded July 20, 2023

Diego Ibañez - Vocals
Mario del Valle - Guitar, Vocals
Martin Vallhonrat - Bass, Vocals
Juan Pedrayes - Drums

Host: Albina Cabrera
Audio Engineers: Julian Martlew, Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Alaia D’Alessandro

https://carolinadurante.com
http://kexp.org

## Carolina Durante - Aaaaaa#$!& (Live on KEXP)
 - [https://www.youtube.com/watch?v=9E9ByFG6C08](https://www.youtube.com/watch?v=9E9ByFG6C08)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-25T11:00:08+00:00

http://KEXP.ORG presents Carolina Durante performing “Aaaaaa#$!&” live in the KEXP studio. Recorded July 20, 2023

Diego Ibañez - Vocals
Mario del Valle - Guitar, Vocals
Martin Vallhonrat - Bass, Vocals
Juan Pedrayes - Drums

Host: Albina Cabrera
Audio Engineers: Julian Martlew, Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Alaia D’Alessandro

https://carolinadurante.com
http://kexp.org

## Carolina Durante - Casa Kira (Live on KEXP)
 - [https://www.youtube.com/watch?v=-8faANPXPys](https://www.youtube.com/watch?v=-8faANPXPys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-25T11:00:00+00:00

http://KEXP.ORG presents Carolina Durante performing "Casa Kira" live in the KEXP studio. Recorded July 20, 2023

Diego Ibañez - Vocals
Mario del Valle - Guitar, Vocals
Martin Vallhonrat - Bass, Vocals
Juan Pedrayes - Drums

Host: Albina Cabrera
Audio Engineers: Julian Martlew, Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Alaia D’Alessandro

https://carolinadurante.com
http://kexp.org

