# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Hołownia: zadanie Trzeciej Drogi to mobilizacja wszystkich tych, którzy w zmianę jeszcze nie uwierzyli
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-szymon-holownia-zadanie-trzeciej-drogi-to-mobilizacja-wszystkich-tych-ktorzy-w-zmiane-jeszcze-nie-uwierzyli-7361153?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-szymon-holownia-zadanie-trzeciej-drogi-to-mobilizacja-wszystkich-tych-ktorzy-w-zmiane-jeszcze-nie-uwierzyli-7361153?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T21:01:23+00:00

<img alt="Hołownia: zadanie Trzeciej Drogi to mobilizacja wszystkich tych, którzy w zmianę jeszcze nie uwierzyli" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a787r1-holownia-i-kosiniak-kamysz-7361154/alternates/LANDSCAPE_1280" />
    Z Trzecią Drogą 16 października obudzicie się w bezpiecznej przyszłości. Obudzicie się w domu, w tych miejscach, w których żyjecie i odetchniecie głęboko z ulgą, że możliwa jest polityka bez kłótni - mówił w poniedziałek lider Polski 2050 Szymon Hołownia. Prezes PSL Władysław Kosiniak-Kamysz przekonywał, że Trzecia Droga idzie ścieżką, która "prowadzi do normalności, rozwiązywania problemów, a nie ich tworzenia".

## Jedenaście nowych towarów na cenzurowanym. Ministerstwo o "problemie porzucania odpadów"
 - [https://tvn24.pl/biznes/z-kraju/sent-system-ma-objac-11-nowych-rodzajow-odpadow-projekt-ministerstwa-finansow-7361036?source=rss](https://tvn24.pl/biznes/z-kraju/sent-system-ma-objac-11-nowych-rodzajow-odpadow-projekt-ministerstwa-finansow-7361036?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T19:31:28+00:00

<img alt="Jedenaście nowych towarów na cenzurowanym. Ministerstwo o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nng1if-odpady-wysypiska_01-7321036/alternates/LANDSCAPE_1280" />
    System Elektronicznego Nadzoru Transportu (SENT) ma zostać rozszerzony o 11 rodzajów odpadów, takich jak farby, lakiery czy kleje. W poniedziałek opublikowano projekt rozporządzenia w tej sprawie, przygotowany przez Ministerstwo Finansów. Rozszerzenie SENT ma ograniczyć szarą strefę w gospodarce odpadowej.

## Deszcz odciął miasto od reszty świata
 - [https://tvn24.pl/tvnmeteo/swiat/rpa-ulewny-deszcz-odcial-miasto-od-reszty-swiata-7360997?source=rss](https://tvn24.pl/tvnmeteo/swiat/rpa-ulewny-deszcz-odcial-miasto-od-reszty-swiata-7360997?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T18:57:30+00:00

<img alt="Deszcz odciął miasto od reszty świata" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6ghj31-skutki-burzy-w-republice-poludniowej-afryki-7360993/alternates/LANDSCAPE_1280" />
    Gwałtowna burza przeszła nad Republiką Południowej Afryki. Ulewy odcięły miasto Bredasdorp od reszty świata, a silny wiatr spowodował przerwanie dostaw prądu do dziesiątek tysięcy domów. W regionie trwają poszukiwania zaginionych osób.

## Ruszyło głosowanie na Warszawiankę Roku
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-lista-nominowanych-do-tytulu-warszawianka-roku-ruszylo-glosowanie-7360947?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-lista-nominowanych-do-tytulu-warszawianka-roku-ruszylo-glosowanie-7360947?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T18:52:13+00:00

<img alt="Ruszyło głosowanie na Warszawiankę Roku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-38xjcn-nominowane-do-tytulu-warszawianka-roku-2023-7360942/alternates/LANDSCAPE_1280" />
    Kapituła wybrała spośród ponad 300 zgłoszonych kandydatek 10 kobiet, jedna z nich zostanie Warszawianką Roku 2023. Głosowanie potrwa do 10 listopada.

## Alarmujące dane GUS. "Depresja demograficzna tylko się pogłębia"
 - [https://tvn24.pl/biznes/z-kraju/polska-kryzys-demograficzny-gus-podal-dane-za-lipiec-2023-ekonomista-rafal-mundry-komentuje-7360973?source=rss](https://tvn24.pl/biznes/z-kraju/polska-kryzys-demograficzny-gus-podal-dane-za-lipiec-2023-ekonomista-rafal-mundry-komentuje-7360973?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T18:42:09+00:00

<img alt="Alarmujące dane GUS. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gmtxtr-warszawa-ludzie-ulica-6098791/alternates/LANDSCAPE_1280" />
    W Polsce w lipcu 2023 roku odnotowano 24 tysiące urodzeń. W tym czasie zmarło 31 tysięcy osób - wynika z najnowszych danych Głównego Urzędu Statystycznego (GUS). "Depresja demograficzna tylko się pogłębia" - napisał w mediach społecznościowych ekonomista Rafał Mundry.

## "Z lekceważenia kwestii ochrony granicy będą kłopoty dla wszystkich. To będzie sprawa wielu przywódców europejskich"
 - [https://tvn24.pl/wybory-parlamentarne-2023/afera-wizowa-pawel-kowal-koalicja-obywatelska-i-krzysztof-smiszek-lewica-komentuja-7361007?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/afera-wizowa-pawel-kowal-koalicja-obywatelska-i-krzysztof-smiszek-lewica-komentuja-7361007?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T18:42:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u90xsl-krzysztof-smiszek-i-pawel-kowal-w-faktach-po-faktach-7360955/alternates/LANDSCAPE_1280" />
    Im bardziej Prawo i Sprawiedliwość próbuje zamieść pod dywan, im bardziej próbuje dezawuować tę gigantyczną aferę, tym bardziej Polacy są ciekawi - ocenił w dyskusji o aferze wizowej w programie "Fakty po Faktach" Krzysztof Śmiszek (Lewica). - Naszym zadaniem w sprawie afery wizowej i nie tylko jest przebić mur kłamstwa - zwracał natomiast uwagę Paweł Kowal (Koalicja Obywatelska). W programie dyskutowano także o niemieckiej odpowiedzi na wspomnianą aferę.

## Lewica wymienia "pięć lekcji cynizmu" PiS
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-lewica-wymienia-piec-lekcji-cynizmu-pis-w-kontekscie-afery-wizowej-7360881?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-lewica-wymienia-piec-lekcji-cynizmu-pis-w-kontekscie-afery-wizowej-7360881?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T17:35:51+00:00

<img alt="Lewica wymienia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bhhsns-czarzasty-7360883/alternates/LANDSCAPE_1280" />
    Współprzewodniczący Nowej Lewicy Włodzimierz Czarzasty na spotkaniu z mieszkańcami Pabianic mówił o "lekcjach cynizmu" na podstawie działań polityków Prawa i Sprawiedliwości oraz prezydenta. To w kontekście ostatnich ustaleń wokół afery wizowej.

## Pogoda na jutro - wtorek 26.09. Mglista noc, w dzień do 27 stopni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-2609mglista-noc-w-dzien-do-27-stopni-7360879?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-2609mglista-noc-w-dzien-do-27-stopni-7360879?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T17:30:21+00:00

<img alt="Pogoda na jutro - wtorek 26.09. Mglista noc, w dzień do 27 stopni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-q5p6lg-mgly-6127434/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na wtorek 26.09. Nocne godziny przyniosą nam na ogół pochmurne niebo, jednak chmur nie będzie dużo. Lokalnie widzialność mogą ograniczać mgły. W dzień w całym kraju zapanuje korzystny biomet, a na termometrach zobaczymy od 22 do 27 stopni Celsjusza.

## Kierowca autobusu musiał gwałtownie zahamować. Poszkodowanych kilkoro pasażerów
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-kierowca-autobusu-musial-gwaltownie-zahamowac-poszkodowanych-kilkoro-pasazerow-7360885?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-kierowca-autobusu-musial-gwaltownie-zahamowac-poszkodowanych-kilkoro-pasazerow-7360885?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T17:23:08+00:00

<img alt="Kierowca autobusu musiał gwałtownie zahamować. Poszkodowanych kilkoro pasażerów " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6vuuag-do-zdarzenia-doszlo-na-ochocie-7360846/alternates/LANDSCAPE_1280" />
    Na skrzyżowaniu Racławickiej ze Żwirki i Wigury kierowca autobusu gwałtownie zahamował, by uniknąć zderzenia z autem. Kilkoro pasażerów było badanych w karetce.

## "Nie będziemy wspierać Ukrainy w żadnej sprawie". Kijów usłyszał warunek od Orbana
 - [https://tvn24.pl/swiat/viktor-orban-nie-bedziemy-wspierac-ukrainy-dopoki-kijow-nie-przywroci-praw-wegrow-na-zakarpaciu-7360766?source=rss](https://tvn24.pl/swiat/viktor-orban-nie-bedziemy-wspierac-ukrainy-dopoki-kijow-nie-przywroci-praw-wegrow-na-zakarpaciu-7360766?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T16:22:45+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nx244s-przemowienie-viktora-orbana-w-wegierskim-parlamencie-7360764/alternates/LANDSCAPE_1280" />
    Premier Viktor Orban oświadczył w poniedziałek, że jego kraj nie będzie wspierać Ukrainy w żadnej sprawie na arenie międzynarodowej, dopóki rząd w Kijowie nie przywróci praw mniejszości węgierskiej na Zakarpaciu.

## Porwali 17-latka dla okupu i grozili, że go okaleczą. Wpadli przez ogłoszenie o sprzedaży auta
 - [https://tvn24.pl/swiat/usa-17-latek-uprowadzony-dla-okupu-porywaczy-aresztowano-w-motelu-w-santa-maria-7360722?source=rss](https://tvn24.pl/swiat/usa-17-latek-uprowadzony-dla-okupu-porywaczy-aresztowano-w-motelu-w-santa-maria-7360722?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T16:01:17+00:00

<img alt="Porwali 17-latka dla okupu i grozili, że go okaleczą. Wpadli przez ogłoszenie o sprzedaży auta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w30e0x-fbi622639580-5001760/alternates/LANDSCAPE_1280" />
    W poniedziałek 18 września trójka napastników porwała 17-letniego mieszkańca Kalifornii. Mężczyźni chcieli od matki chłopaka 500 tysięcy dolarów okupu. Grozili, że w przypadku odmowy, zaczną mu obcinać "części ciała". W piątek zostali zatrzymani przez agentów FBI w motelu, a chłopaka uwolniono - informuje biuro prokuratora USA dla Centralnego Dystryktu Kalifornii.

## Manifest klimatyczny, wizyta w Dęblinie, walka o głosy kobiet. Aktywny poniedziałek polityków
 - [https://fakty.tvn24.pl/fakty-po-poludniu/manifest-klimatyczny-wizyta-w-deblinie-walka-o-glosy-kobiet-aktywny-poniedzialek-politykow-7360591?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/manifest-klimatyczny-wizyta-w-deblinie-walka-o-glosy-kobiet-aktywny-poniedzialek-politykow-7360591?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T15:53:41+00:00

<img alt="Manifest klimatyczny, wizyta w Dęblinie, walka o głosy kobiet. Aktywny poniedziałek polityków" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-shfiqb-warchol-7360648/alternates/LANDSCAPE_1280" />
    Politycy nie tracą czasu przed wyborami. W poniedziałek Lewica wzywała do walki ze zmianami klimatycznymi. Członkowie partii mówili też o aferach PiS-u i przykrywaniu ich przez polityczną nienawiść, która prowadzi do przemocy. Z kolei bus Prawa i Sprawiedliwości w poniedziałek  wyruszył z Warszawy, a partia zapewnia, że tylko ona jest w stanie zagwarantować Polsce bezpieczeństwo.

## Gigantyczne "trupie kwiaty" są na skraju wyginięcia
 - [https://tvn24.pl/tvnmeteo/nauka/raflezje-w-niebezpieczenstwie-gigantyczne-trupie-kwiaty-sa-na-skraju-wyginiecia-7360620?source=rss](https://tvn24.pl/tvnmeteo/nauka/raflezje-w-niebezpieczenstwie-gigantyczne-trupie-kwiaty-sa-na-skraju-wyginiecia-7360620?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T15:40:12+00:00

<img alt="Gigantyczne " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qgam78-bukietnica-arnolda-rafflesia-arnoldii-zdj-ilustracyjne-7360595/alternates/LANDSCAPE_1280" />
    Bukietnice, gigantyczne kwiaty roztaczające woń gnijącego mięsa, są zagrożone wyginięciem. Jak pokazuje najnowsze badanie, dotyczy to wszystkich spośród 42 znanych gatunków, a w szczególnym niebezpieczeństwie znajduje się 25 z nich. Naukowcy podkreślają, że jeśli nie uda nam się opracować planów ochrony, te piękne rośliny znikną na zawsze.

## "Grali jeżem w piłkę", a potem go "uśmiercili". Dwóch 14-latków odpowie przed sądem
 - [https://tvn24.pl/kujawsko-pomorskie/brodnica-grali-jezem-w-pilke-zwierze-nie-przezylo-14-latkowie-odpowiedza-przed-sadem-7360668?source=rss](https://tvn24.pl/kujawsko-pomorskie/brodnica-grali-jezem-w-pilke-zwierze-nie-przezylo-14-latkowie-odpowiedza-przed-sadem-7360668?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T15:34:15+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dpmeh9-jez-europejski-6779941/alternates/LANDSCAPE_1280" />
    Najpierw mieli podpalić przenośną toaletę, a później grać jeżem w piłkę i go uśmiercić - dwóch 14-latków z Brodnicy (woj. kujawsko-pomorskie) odpowie przed sądem rodzinnym. Zachowanie chłopców nagrały kamery monitoringu.

## Pielęgniarkę skazaną za zabójstwo noworodków czeka powtórny proces. Prokuratorzy o "trudnych decyzjach"
 - [https://tvn24.pl/najnowsze/wielka-brytania-lucy-letby-pielegniarka-skazana-za-zabojstwo-noworodkow-ma-ponownie-stanac-przed-sadem-7360457?source=rss](https://tvn24.pl/najnowsze/wielka-brytania-lucy-letby-pielegniarka-skazana-za-zabojstwo-noworodkow-ma-ponownie-stanac-przed-sadem-7360457?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T15:31:03+00:00

<img alt="Pielęgniarkę skazaną za zabójstwo noworodków czeka powtórny proces. Prokuratorzy o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-duzbr5-lucy-letby-7297716/alternates/LANDSCAPE_1280" />
    Lucy Letby, była pielęgniarka skazana na dożywocie za zabójstwo siedmiorga noworodków w szpitalu, w którym pracowała, może ponownie stanąć przed sądem. Jak informuje prokuratura chodzi o usiłowanie zabójstwa kolejnego dziecka.

## Nowe obowiązki dla operatorów. Przepisy weszły w życie
 - [https://tvn24.pl/biznes/z-kraju/oszustwa-internetowe-nowe-obowiazki-dla-operatorow-ustawa-o-zwalczaniu-naduzyc-w-komunikacji-elektronicznej-weszla-w-zycie-7360649?source=rss](https://tvn24.pl/biznes/z-kraju/oszustwa-internetowe-nowe-obowiazki-dla-operatorow-ustawa-o-zwalczaniu-naduzyc-w-komunikacji-elektronicznej-weszla-w-zycie-7360649?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T15:30:04+00:00

<img alt="Nowe obowiązki dla operatorów. Przepisy weszły w życie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8xm8ux-haker-5542943/alternates/LANDSCAPE_1280" />
    W poniedziałek weszła w życie ustawa o zwalczaniu nadużyć w komunikacji elektronicznej. Nowe przepisy mają się przyczynić do ograniczenia fałszywych połączeń, SMS-ów oraz domen internetowych.

## Pielęgniarka jak kelnerka? Dyrektor kusił pieniędzmi i "mężem lekarzem", teraz przeprasza
 - [https://tvn24.pl/rzeszow/rzeszow-dyrektor-medyka-zaproponowal-pielegniarkom-dodatkowe-zajecie-teraz-przeprasza-7359711?source=rss](https://tvn24.pl/rzeszow/rzeszow-dyrektor-medyka-zaproponowal-pielegniarkom-dodatkowe-zajecie-teraz-przeprasza-7359711?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T15:26:29+00:00

<img alt="Pielęgniarka jak kelnerka? Dyrektor kusił pieniędzmi i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-g0dpg9-dyrektor-medyka-kusil-pracowniczki-pieniedzmi-i-mezem-lekarzem-7360273/alternates/LANDSCAPE_1280" />
    Do sieci wyciekła wiadomość, jaką szef Centrum Medycznego "Medyk" w Rzeszowie wysłał do swoich pracowniczek. Pielęgniarkom, laborantkom i rejestratorkom zaoferował pracę kelnerek podczas bankietu absolwentów medycyny Uniwersytetu Rzeszowskiego. "Może któraś znajdzie sobie wśród młodych lekarzy męża" - kusił. Szefowa Naczelnej Rady Pielęgniarek i Położnych zachowanie prezesa nazywa seksizmem i zapowiada zgłoszenie sprawy do Komisji Etyki Lekarskiej. On sam opublikował oświadczenie, w którym przeprosił "panie, które poczuły się urażone treścią i formą komunikatu".

## Coraz więcej szkół przechodzi na cztery dni nauki w tygodniu. Szczególnie na terenach wiejskich
 - [https://tvn24.pl/swiat/edukacja-cztery-dni-nauki-w-tygodniu-w-szkolach-w-usa-i-europie-korzysci-i-zagrozenia-z-czterodniowego-systemu-nauki-7360540?source=rss](https://tvn24.pl/swiat/edukacja-cztery-dni-nauki-w-tygodniu-w-szkolach-w-usa-i-europie-korzysci-i-zagrozenia-z-czterodniowego-systemu-nauki-7360540?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T14:27:28+00:00

<img alt="Coraz więcej szkół przechodzi na cztery dni nauki w tygodniu. Szczególnie na terenach wiejskich" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-c07749-uczniowie-maja-wrocic-do-szkol-4229956/alternates/LANDSCAPE_1280" />
    Już w ponad 2100 szkół na terenie Stanów Zjednoczonych zdecydowano się na wprowadzenie 4-dniowego tygodnia nauczania – wynika z badania Paula Thompsona, profesora nadzwyczajnego Uniwersytetu Stanu Oregon. W ostatnich latach liczba placówek w USA decydujących się na podobne rozwiązania rośnie - szczególnie na terenach wiejskich. Potencjalne korzyści oraz zagrożenia płynące z takich zmian opisał w poniedziałek portal Independent.

## Będzie aż 28 stopni w cieniu. Na horyzoncie widać ochłodzenie - i to znaczne
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-5-dni-bedzie-prawie-30-stopni-jak-dlugo-potrwa-fala-goraca-7360516?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-5-dni-bedzie-prawie-30-stopni-jak-dlugo-potrwa-fala-goraca-7360516?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T14:27:14+00:00

<img alt="Będzie aż 28 stopni w cieniu. Na horyzoncie widać ochłodzenie - i to znaczne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cz8t6l-goraco-upal-slonce-7360587/alternates/LANDSCAPE_1280" />
    Na horyzoncie widać ochłodzenie, ale zanim ono nastąpi, przed nami wyjątkowo gorące dni. W środku tygodnia w najcieplejszych miejscach w Polsce zrobi się niemal upalnie, a najniższe wartości wskazywane przez termometry też będą niezwykle wysokie jak na koniec września.

## Ugodziła męża nożem w brzuch. "Już wcześniej znęcała się"
 - [https://tvn24.pl/poznan/poznan-32-latek-ugodzila-meza-nozem-w-brzuch-odpowie-za-usilowanie-zabojstwa-7360593?source=rss](https://tvn24.pl/poznan/poznan-32-latek-ugodzila-meza-nozem-w-brzuch-odpowie-za-usilowanie-zabojstwa-7360593?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T14:23:50+00:00

<img alt="Ugodziła męża nożem w brzuch. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-erhixn-zaklad-karny-4689671/alternates/LANDSCAPE_1280" />
    32-letnia mieszkanka Poznania usłyszała zarzut usiłowania zabójstwa swojego męża, którego ugodziła nożem w brzuch. 37-latek trafił do szpitala. Kobieta odpowie też za znęcanie się nad mężczyzną. Jak ustalili śledczy, do znęcania się dochodziło "już wcześniej".

## Samolot wylądował w polu kołami do góry, dwie osoby w szpitalu
 - [https://tvn24.pl/lodz/jamno-awaryjne-ladowanie-samolotu-dwie-osoby-w-szpitalu-7360578?source=rss](https://tvn24.pl/lodz/jamno-awaryjne-ladowanie-samolotu-dwie-osoby-w-szpitalu-7360578?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T14:14:40+00:00

<img alt="Samolot wylądował w polu kołami do góry, dwie osoby w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c9g4qy-awaryjne-ladowanie-samolotu-7360530/alternates/LANDSCAPE_1280" />
    Dwie osoby trafiły do szpitala po awaryjnym lądowaniu samolotu rozprowadzającego szczepionki przeciwko wściekliźnie dla lisów w miejscowości Jamno (woj. łódzkie). Maszyna wylądowała na dachu, kołami do góry. Jak wynika z ustaleń policjantów, przyczyną zdarzenia była awaria silnika.

## W pozaziemskim oceanie mogą kryć się życiodajne cząsteczki
 - [https://tvn24.pl/tvnmeteo/nauka/europa-w-pozaziemskim-oceanie-moga-kryc-sie-zyciodajne-czasteczki-7360428?source=rss](https://tvn24.pl/tvnmeteo/nauka/europa-w-pozaziemskim-oceanie-moga-kryc-sie-zyciodajne-czasteczki-7360428?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T14:04:52+00:00

<img alt="W pozaziemskim oceanie mogą kryć się życiodajne cząsteczki" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ixtoww-europa-ksiezyc-jowisza-z-dobrze-widocznymi-czerwonymi-pregami-6871498/alternates/LANDSCAPE_1280" />
    Europa, księżyc Jowisza, może skrywać w sobie ocean bogaty w związki węgla. Kosmiczny Teleskop Jamesa Webba zaobserwował na powierzchni ciała niebieskiego zmrożony dwutlenek węgla, który prawdopodobnie pochodzi z podpowierzchniowych głębin. Odkrycie to jest o tyle istotne, że Europa jest jednym z najbardziej "przyjaznych życiu" światów.

## Niejedna para się pod nim zaręczyła. Zwęglone drzewo zaczęło wypuszczać nowe liście
 - [https://tvn24.pl/tvnmeteo/swiat/pozar-na-hawajach-lahaina-figowiec-bengalski-wypuszcza-nowe-liscie-ludzie-postrzegaja-to-jako-znak-nadziei-7360221?source=rss](https://tvn24.pl/tvnmeteo/swiat/pozar-na-hawajach-lahaina-figowiec-bengalski-wypuszcza-nowe-liscie-ludzie-postrzegaja-to-jako-znak-nadziei-7360221?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T13:30:07+00:00

<img alt="Niejedna para się pod nim zaręczyła. Zwęglone drzewo zaczęło wypuszczać nowe liście" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-hdlysj-drzewo-wypuszcza-nowe-liscie-7360308/alternates/LANDSCAPE_1280" />
    Stanowił atrakcję turystyczną, a niejedna para się pod nim zaręczyła. Na 150-letnim ogromny figowcu bengalskim, zwęglonym podczas sierpniowego pożaru w mieście Lahaina na Hawajach, zaczęły pojawiać się nowe liście.

## Prokuratura bada sprawę napaści na posłankę Koalicji Obywatelskiej
 - [https://tvn24.pl/lublin/opole-lubelskie-prokuratura-bada-sprawe-napasci-na-poslanke-marte-wcislo-7360475?source=rss](https://tvn24.pl/lublin/opole-lubelskie-prokuratura-bada-sprawe-napasci-na-poslanke-marte-wcislo-7360475?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T13:27:59+00:00

<img alt="Prokuratura bada sprawę napaści na posłankę Koalicji Obywatelskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-23ahch-marta-wcislo-o-napasci-na-targowisku-w-opolu-lubelskim-7360465/alternates/LANDSCAPE_1280" />
    Prokuratura bada sprawę napaści na posłankę Koalicji Obywatelskiej Martę Wcisło. Jak przekazała parlamentarzystka w mediach społecznościowych, do ataku doszło na targu w Opolu Lubelskim. Nieznany mężczyzna miał ją szarpać, wyzywać i grozić jej. - Nie dam się zastraszyć - podkreśliła Wcisło.

## Chciał skorzystać z lex deweloper. Urząd miasta ujawnił jego dane osobowe. Sąd przyznał mu 20 tys. zł
 - [https://tvn24.pl/bialystok/bialystok-chcial-skorzystac-z-lex-deweloper-urzad-miasta-ujawnil-jego-dane-osobowe-sad-przyznal-mu-20-tys-zl-7360350?source=rss](https://tvn24.pl/bialystok/bialystok-chcial-skorzystac-z-lex-deweloper-urzad-miasta-ujawnil-jego-dane-osobowe-sad-przyznal-mu-20-tys-zl-7360350?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T13:19:30+00:00

<img alt="Chciał skorzystać z lex deweloper. Urząd miasta ujawnił jego dane osobowe. Sąd przyznał mu 20 tys. zł  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-f3muyb-to-tutaj-inwestor-chcial-stawiac-blok-7360391/alternates/LANDSCAPE_1280" />
    Adres zamieszkania, a poprzez podanie numeru księgi wieczystej - również PESEL oraz imiona rodziców. Takie dane z wniosku o ustalenie lokalizacji inwestycji mieszkaniowej ujawnił urząd miasta w Białymstoku. Przedsiębiorca zorientował się, że coś jest nie tak, gdy dostał list od nieznanej mu osoby z pytaniem, czy sprzedałby mieszkanie w bloku, który dopiero zamierzał zbudować. Sąd Okręgowy zasądził na rzecz powoda 20 tys. zł. Ten będzie się odwoływał. Żąda 10 razy tyle.

## Niemowlę trafiło do szpitala z ponad 50 ranami zadanymi przez szczury. Policja zatrzymała rodziców i ciotkę
 - [https://tvn24.pl/swiat/usa-niemowle-z-ponad-50-ranami-zadanymi-przez-szczury-policja-zatrzymala-trzy-osoby-7360101?source=rss](https://tvn24.pl/swiat/usa-niemowle-z-ponad-50-ranami-zadanymi-przez-szczury-policja-zatrzymala-trzy-osoby-7360101?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T13:17:07+00:00

<img alt="Niemowlę trafiło do szpitala z ponad 50 ranami zadanymi przez szczury. Policja zatrzymała rodziców i ciotkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-czywc2-dziecko-szpital-6644903/alternates/LANDSCAPE_1280" />
    Policja zatrzymała rodziców oraz ciotkę półrocznego chłopca ze stanu Indiana (USA), który trafił do szpitala z ponad pięćdziesięcioma ranami po ugryzieniach szczurów. Lokalne organy ścigania twierdzą, że nie miały wcześniej do czynienia z podobnym przypadkiem. Tymczasem pracownicy socjalni już przed kilkoma miesiącami alarmowali o sytuacji w domu rodziców poszkodowanego dziecka.

## "To wywróciło mój świat". Kerry Washington o tym, jak dowiedziała się, że jej tata nie jest jej biologicznym ojcem
 - [https://tvn24.pl/kultura-i-styl/kerry-washington-o-tym-jak-dowiedziala-sie-ze-jej-tata-nie-jest-jej-biologicznym-ojcem-to-wywrocilo-moj-swiat-7360121?source=rss](https://tvn24.pl/kultura-i-styl/kerry-washington-o-tym-jak-dowiedziala-sie-ze-jej-tata-nie-jest-jej-biologicznym-ojcem-to-wywrocilo-moj-swiat-7360121?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T12:53:11+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3puc19-kerry-washington-7359495/alternates/LANDSCAPE_1280" />
    Kerry Washington opowiedziała w wywiadzie dla magazynu "People" o okolicznościach, w jakich pięć lat temu dowiedziała się, że jej tata nie jest jej biologicznym ojcem. Znana między innymi z "Django" aktorka wyznała, że stara się zrozumieć rodziców, którzy przez lata skrywali przed nią prawdę.

## Białystok jedynym miastem wojewódzkim bez nocnych autobusów. Władze: nie ma pieniędzy przez Polski Ład
 - [https://tvn24.pl/bialystok/bialystok-radni-chca-przywrocenia-nocnej-komunikacji-miejskiej-miasto-nie-ma-na-to-pieniedzy-7360280?source=rss](https://tvn24.pl/bialystok/bialystok-radni-chca-przywrocenia-nocnej-komunikacji-miejskiej-miasto-nie-ma-na-to-pieniedzy-7360280?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T12:40:40+00:00

<img alt="Białystok jedynym miastem wojewódzkim bez nocnych autobusów. Władze: nie ma pieniędzy przez Polski Ład" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yxwmoc-w-bialymstoku-nie-ma-nocnej-komunikacji-miejskiej-7359857/alternates/LANDSCAPE_1280" />
    Radni miejscy Polski 2050, a ostatnio także radni PiS, proszą prezydenta Białegostoku o przywrócenie nocnych kursów autobusów, które nie funkcjonują od wybuchu pandemii. Prezydent tego nie wyklucza, ale stawia warunek: rząd musi zrekompensować samorządowi dochody utracone przez zmiany podatkowe w ramach Polskiego Ładu.

## Rowerzysta wjechał na pasy, "kierująca tramwajem nie miała szansy wyhamować"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-tramwaj-uderzyl-w-rowerzyste-mial-rozbita-glowe-byl-w-szoku-7360151?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-tramwaj-uderzyl-w-rowerzyste-mial-rozbita-glowe-byl-w-szoku-7360151?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T12:40:06+00:00

<img alt="Rowerzysta wjechał na pasy, " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vkaxih-wypadek-z-udzialem-rowerzysty-7360374/alternates/LANDSCAPE_1280" />
    Na Starym Mieście tramwaj linii 20 uderzył w przejeżdżającego przez przejście dla pieszych rowerzystę. Mężczyzna z urazem głowy został zabrany do szpitala.

## Po zmroku pije się rzadziej, za dnia jednak częściej. Kraków o pierwszych efektach nocnej prohibicji
 - [https://tvn24.pl/krakow/krakow-pierwsze-efekty-zakazu-sprzedazy-alkoholu-noca-miasto-mowi-o-sukcesie-nocnej-prohibicji-7360330?source=rss](https://tvn24.pl/krakow/krakow-pierwsze-efekty-zakazu-sprzedazy-alkoholu-noca-miasto-mowi-o-sukcesie-nocnej-prohibicji-7360330?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T12:39:14+00:00

<img alt="Po zmroku pije się rzadziej, za dnia jednak częściej. Kraków o pierwszych efektach nocnej prohibicji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4a0a1o-alkohol-6228870/alternates/LANDSCAPE_1280" />
    Średnio o połowę mniej nocnych interwencji niż przed rokiem odnotowali w wakacje policjanci i strażnicy miejscy po wprowadzeniu w Krakowie zakazu sprzedaży alkoholu od północy do godziny 5.30. O ile w nocy jest spokojniej, o tyle w ciągu całej doby - na co wskazują dane straży miejskiej - odnotowano o niecałe 10 procent więcej wykroczeń związanych ze spożyciem alkoholu.

## Obserwatorzy OBWE niewpuszczeni na spotkanie z Kaczyńskim. Rządzący "zupełnie nie znają sprawy"
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-obserwatorzy-obwe-niewpuszczeni-na-spotkanie-z-jaroslawem-kaczynskim-komentarze-politykow-7360254?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-obserwatorzy-obwe-niewpuszczeni-na-spotkanie-z-jaroslawem-kaczynskim-komentarze-politykow-7360254?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T12:18:36+00:00

<img alt="Obserwatorzy OBWE niewpuszczeni na spotkanie z Kaczyńskim. Rządzący " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z9s56-na-spotkanie-z-kaczynskim-nie-wpuszczono-obserwatorow-z-obwe-7358278/alternates/LANDSCAPE_1280" />
    Na spotkanie z prezesem PiS Jarosławem Kaczyńskim nie zostali wpuszczeni obserwatorzy OBWE. Przedstawiciele obozu rządzącego nie chcą komentować tej sytuacji. Twierdzą, że "zupełnie nie znają sprawy". - PiS się zamyka, chowa przed opinią publiczną, przed wyborcami. To jest sugestia dla Europy, dla wolnego świata, że PiS chce coś ukryć przed okiem obserwatorów - ocenił Grzegorz Schetyna z Koalicji Obywatelskiej.

## Martyna Wojciechowska czekała na to spotkanie kilka lat. "Zaczęłam twierdzić, że naprawdę ją lubię"
 - [https://tvn24.pl/kultura-i-styl/martyna-wojciechowska-kobieta-na-krancu-swiata-gosciem-sophia-najbardziej-rozpoznawalna-robotka-humanoidalna-7360056?source=rss](https://tvn24.pl/kultura-i-styl/martyna-wojciechowska-kobieta-na-krancu-swiata-gosciem-sophia-najbardziej-rozpoznawalna-robotka-humanoidalna-7360056?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T12:15:56+00:00

<img alt="Martyna Wojciechowska czekała na to spotkanie kilka lat. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8cz9vt-martyna-wojciechowska-i-sophia-kobieta-na-krancu-swiata-7360104/alternates/LANDSCAPE_1280" />
    - Ten odcinek "Kobiety na krańcu świata" jeszcze przed emisją wzbudził bardzo dużo emocji - przyznaje Martyna Wojciechowska. Podróżniczka pojechała z kamerą do Hongkongu, by spotkać się z Sophią, najbardziej rozpoznawalną robotką humanoidalną na świecie. Odcinek, który miał premierę na antenie TVN w niedzielę, można obejrzeć w Playerze.

## Burmistrz Derny aresztowany w związku z zawaleniem się tam
 - [https://tvn24.pl/tvnmeteo/swiat/burmistrz-derny-aresztowany-w-zwiazku-z-zawaleniem-sie-tam-7360208?source=rss](https://tvn24.pl/tvnmeteo/swiat/burmistrz-derny-aresztowany-w-zwiazku-z-zawaleniem-sie-tam-7360208?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T12:02:50+00:00

<img alt="Burmistrz Derny aresztowany w związku z zawaleniem się tam" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-nb70wf-zniszczone-miasto-derna-7346721/alternates/LANDSCAPE_1280" />
    Burmistrz Derny Abdulmenam al-Gaiti, wraz z innymi przedstawicielami władz, został aresztowany pod zarzutem zaniedbań w związku z zawaleniem się tam - poinformowało w poniedziałek biuro prokuratora generalnego Libii z siedzibą w Trypolisie. Dodało, że na skutek przerwania się tam doszło do potężnej powodzi, w której zginęło ponad 11 tysięcy osób.

## Trzeci dzień poszukiwań 50-latka w Tatrach. Przez telefon powiedział ratownikom, że jest ranny
 - [https://tvn24.pl/krakow/tatry-slowacja-trzeci-dzien-poszukiwan-polskiego-turysty-przez-telefon-powiedzial-ratownikom-ze-jest-ranny-7360189?source=rss](https://tvn24.pl/krakow/tatry-slowacja-trzeci-dzien-poszukiwan-polskiego-turysty-przez-telefon-powiedzial-ratownikom-ze-jest-ranny-7360189?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T12:00:12+00:00

<img alt="Trzeci dzień poszukiwań 50-latka w Tatrach. Przez telefon powiedział ratownikom, że jest ranny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8grv1d-poszukiwania-polaka-w-tatrach-na-slowacji-7360139/alternates/LANDSCAPE_1280" />
    Ratownicy wciąż nie znaleźli 50-latka, który w sobotę zaginął w słowackich Tatrach po tym, jak wybrał się na samotną wycieczkę na Lodowy Szczyt. Zanim kontakt z turystą się urwał, mężczyzna zdążył poinformować telefonicznie ratowników Tatrzańskiego Ochotniczego Pogotowia Ratunkowego, że jest ranny w nogę. Nie był jednak w stanie określić, gdzie się znajduje.

## Wypadek z udziałem motocyklisty na Woli
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-samochod-i-motocykl-zderzyly-sie-w-alei-prymasa-tysiaclecia-7360224?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-samochod-i-motocykl-zderzyly-sie-w-alei-prymasa-tysiaclecia-7360224?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T11:51:13+00:00

<img alt="Wypadek z udziałem motocyklisty na Woli" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-zg22x7-zderzenie-w-alei-prymasa-tysiaclecia-7360239/alternates/LANDSCAPE_1280" />
    Zderzenia motocyklisty i kierowcy auta osobowego w alei Prymasa Tysiąclecia. Pojazdy blokują dwa pasy ruchu. Jedna osoba jest poszkodowana.

## "Trzymajcie się z dala od okien!". Grad wielkości piłek do baseballa wybijał szyby w autach
 - [https://tvn24.pl/tvnmeteo/swiat/usa-teksas-grad-wielkosci-pilek-do-baseballa-spadl-w-teksasie-wybite-szyby-7359948?source=rss](https://tvn24.pl/tvnmeteo/swiat/usa-teksas-grad-wielkosci-pilek-do-baseballa-spadl-w-teksasie-wybite-szyby-7359948?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T11:42:30+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-v9sczd-grad-7360154/alternates/LANDSCAPE_1280" />
    Gwałtowna burza nawiedziła środkową część stanu Teksas w USA. Podczas wyładowań sypnęło gradem. Lodowe kule były wielkości piłek baseballowych i spowodowały poważne szkody materialne.

## Zjechał z drogi i uderzył w drzewo, 16-latka trafiła do szpitala. Egzamin na prawo jazdy zdał kilka dni wcześniej
 - [https://tvn24.pl/trojmiasto/lesniewo-zjechal-z-drogi-i-uderzyl-w-drzewo-kilka-dni-wczesniej-19-latek-zdal-egzamin-na-prawo-jazdy-7359992?source=rss](https://tvn24.pl/trojmiasto/lesniewo-zjechal-z-drogi-i-uderzyl-w-drzewo-kilka-dni-wczesniej-19-latek-zdal-egzamin-na-prawo-jazdy-7359992?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T11:35:34+00:00

<img alt="Zjechał z drogi i uderzył w drzewo, 16-latka trafiła do szpitala. Egzamin na prawo jazdy zdał kilka dni wcześniej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lmhqc4-wypadl-z-drogi-i-uderzyl-w-drzewo-ranna-16-latka-7359994/alternates/LANDSCAPE_1280" />
    16-latka została ranna i trafiła do szpitala w wyniku wypadku, do którego doszło w miejscowości Leśniewo (woj. pomorskie). 19-latek jadący bmw wypadł z drogi i uderzył w drzewo. Jak informuje policja, egzamin na prawo jazdy zdał zaledwie kilka dni wcześniej.

## Biblioteka Uniwersytecka będzie czynna przez całą dobę już na stałe
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-biblioteka-uniwersytecka-bedzie-czynna-przez-cala-dobe-juz-na-stale-7359989?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-biblioteka-uniwersytecka-bedzie-czynna-przez-cala-dobe-juz-na-stale-7359989?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T11:15:43+00:00

<img alt="Biblioteka Uniwersytecka będzie czynna przez całą dobę już na stałe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vd9lyc-biblioteka-uniwersytetu-warszawskiego-7360181/alternates/LANDSCAPE_1280" />
    Władze Uniwersytetu Warszawskiego podjęły decyzję o tym, że gmach biblioteki będzie czynny na stałe przez całą dobę. Rozporządzenie wejdzie w życie 2 października, czyli od rozpoczęcia nowego roku akademickiego.

## Oblężenie ośrodków po zmianie przepisów. "Kompletnie nie rozumiem tego ruchu"
 - [https://tvn24.pl/biznes/moto/motoryzacja-kursy-kasujace-punkty-karne-komentuja-leszek-plawiak-dariusz-galik-7359908?source=rss](https://tvn24.pl/biznes/moto/motoryzacja-kursy-kasujace-punkty-karne-komentuja-leszek-plawiak-dariusz-galik-7359908?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T11:14:01+00:00

<img alt="Oblężenie ośrodków po zmianie przepisów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pzpny2-warszawa-samochody-auta-ulica-5108660/alternates/LANDSCAPE_1280" />
    Kompletnie nie rozumiem tego ruchu - stwierdził w rozmowie z TVN24 Leszek Pławiak ze szkoły jazdy "Autko", odnosząc się do przywrócenia kursów, które powalają kierowcom zredukować o 6 liczbę posiadanych punktów karnych. Obecnie większość ośrodków ruchu drogowego w Polsce przeżywa oblężenie w związku ze zmianą przepisów w tej sprawie.

## Cztero- i siedmiolatek zamknięci w domu, "wołali o pomoc". Matka wyszła na piwo. Wróciła dzień po interwencji służb
 - [https://tvn24.pl/trojmiasto/chojnice-mali-chlopcy-czterolatek-i-siedmiolatek-zamknieci-w-domu-wolali-o-pomoc-matka-wyszla-na-piwo-7360190?source=rss](https://tvn24.pl/trojmiasto/chojnice-mali-chlopcy-czterolatek-i-siedmiolatek-zamknieci-w-domu-wolali-o-pomoc-matka-wyszla-na-piwo-7360190?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T11:12:36+00:00

<img alt="Cztero- i siedmiolatek zamknięci w domu, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fqfxz-cztero-i-siedmiolatek-zamknieci-w-domu-wolali-o-pomoc-matka-wyszla-na-piwo-7360120/alternates/LANDSCAPE_1280" />
    Mieszkańcy Chojnic (woj. pomorskie) poinformowali policję, że w jednym z mieszkań przebywa dwóch małych chłopców, którzy "wołają o pomoc". Cztero- i siedmiolatek byli zamknięci w domu, nie było z nimi dorosłych. Jak informuje policja, matka dzieci wróciła do mieszkania następnego dnia. Przyznała, że wyszła do znajomego na piwo. Nie wiadomo dokładnie, jak długo dzieci były same w mieszkaniu. - Prowadzimy czynności, by wyjaśnić jak faktycznie było - podkreślają mundurowi.

## Aligator trzymał w pysku "dolną część ludzkiego tułowia". Ujawniono, kim była ofiara
 - [https://tvn24.pl/tvnmeteo/swiat/usa-aligator-trzymal-w-pysku-dolna-czesc-ludzkiego-tulowia-ujawniono-kim-byla-ofiara-7359777?source=rss](https://tvn24.pl/tvnmeteo/swiat/usa-aligator-trzymal-w-pysku-dolna-czesc-ludzkiego-tulowia-ujawniono-kim-byla-ofiara-7359777?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T10:56:03+00:00

<img alt="Aligator trzymał w pysku " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mhfo0s-aligator-7141897/alternates/LANDSCAPE_1280" />
    Ponadczterometrowy aligator z ludzkimi szczątkami w pysku został zauważony w kanale miejskim na Florydzie w okolicy miasta Largo. Zwierzę zostało uśpione przez służby, które wyłowiły zwłoki z wody i ustaliły tożsamość zmarłej kobiety. Córka 41-letniej ofiary zabrała głos. Okoliczni mieszkańcy mówią w mediach, że boją się o swoje bezpieczeństwo.

## Zadał kilkanaście ciosów nożem. Zabił ciotkę i jej ojca. Usłyszał wyrok
 - [https://tvn24.pl/kujawsko-pomorskie/wloclawek-zadal-kilkanascie-ciosow-nozem-zabil-ciotke-i-jej-ojca-sad-utrzymal-dozywocie-7359955?source=rss](https://tvn24.pl/kujawsko-pomorskie/wloclawek-zadal-kilkanascie-ciosow-nozem-zabil-ciotke-i-jej-ojca-sad-utrzymal-dozywocie-7359955?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T10:48:38+00:00

<img alt="Zadał kilkanaście ciosów nożem. Zabił ciotkę i jej ojca. Usłyszał wyrok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c03st-sad-zdecydowal-ze-z-warunkowego-przedterminowego-zwolnienia-mezczyzna-bedzie-mogl-skorzystac-nie-wczesniej-niz-po-odbyciu-25-lat-kary-7359960/alternates/LANDSCAPE_1280" />
    Motywem tej zbrodni miało być to, że 59-letnia ciotka odmówiła mu wynajmu mieszkania w centrum Włocławka (woj. kujawsko-pomorskie). Łukasz P. zabił ją oraz jej 84-letniego ojca, zadając ofiarom kilkadziesiąt ciosów nożem w głowę i klatkę piersiową. Sąd Apelacyjny w Gdańsku wydał prawomocny wyrok dożywotniego pozbawienia wolności.

## Kosowo. Policja wkroczyła do wioski Banjska, szuka osób zaangażowanych w strzelaninę
 - [https://tvn24.pl/swiat/kosowo-policja-wkroczyla-do-wioski-banjska-w-ktorej-doszlo-do-strzelaniny-7359965?source=rss](https://tvn24.pl/swiat/kosowo-policja-wkroczyla-do-wioski-banjska-w-ktorej-doszlo-do-strzelaniny-7359965?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T10:47:08+00:00

<img alt="Kosowo. Policja wkroczyła do wioski Banjska, szuka osób zaangażowanych w strzelaninę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ptpul2-kosowska-policja-na-drodze-w-poblizu-wsi-banjska-7359998/alternates/LANDSCAPE_1280" />
    Jednostki kosowskiej policji w pojazdach opancerzonych wkroczyły do wioski Banjska na północy kraju. Wcześniej w tym miejscu doszło do strzelaniny pomiędzy siłami z Kosowa a etnicznymi Serbami, w której zginęły cztery osoby - podała agencja Reutera.

## Jon Bon Jovi nie zaśpiewa na ślubie syna z Millie Bobby Brown. "Potrzebuje przerwy"
 - [https://tvn24.pl/kultura-i-styl/muzyka-jon-bon-jovi-nie-zaspiewa-na-slubie-syna-jake-bongiovi-z-millie-bobby-brown-7359824?source=rss](https://tvn24.pl/kultura-i-styl/muzyka-jon-bon-jovi-nie-zaspiewa-na-slubie-syna-jake-bongiovi-z-millie-bobby-brown-7359824?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T10:42:07+00:00

<img alt="Jon Bon Jovi nie zaśpiewa na ślubie syna z Millie Bobby Brown. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wyoacg-jon-bon-jovi-7062870/alternates/LANDSCAPE_1280" />
    Jon Bon Jovi nie wystąpi na ślubie swojego syna Jake'a Bongioviego i aktorki Millie Bobby Brown. Myślę, że potrzebuje przerwy – powiedziała 19-letnia gwiazda "The Stranger Things" w wywiadzie dla "Today". Wokalista grupy Bon Jovi w przeszłości zaskoczył gości weselnych, spontanicznie wykonując przebój "Livin’ on a Prayer" podczas uroczystości na Florydzie.

## Bez prędkościomierza i wskaźników paliwa, ostatnie badanie techniczne sprzed siedmiu lat. I tak ruszył w drogę
 - [https://tvn24.pl/wroclaw/lubin-motocykl-bez-predkosciomierza-i-wskaznikow-paliwa-ostatnie-badanie-techniczne-sprzed-siedmiu-lat-i-tak-ruszyl-w-droge-7360004?source=rss](https://tvn24.pl/wroclaw/lubin-motocykl-bez-predkosciomierza-i-wskaznikow-paliwa-ostatnie-badanie-techniczne-sprzed-siedmiu-lat-i-tak-ruszyl-w-droge-7360004?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T10:29:00+00:00

<img alt="Bez prędkościomierza i wskaźników paliwa, ostatnie badanie techniczne sprzed siedmiu lat. I tak ruszył w drogę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t4hjap-bez-predkosciomierza-i-wskaznikow-paliwa-ostatnie-badanie-techniczne-sprzed-siedmiu-lat-7359974/alternates/LANDSCAPE_1280" />
    Policjanci z Lubina (woj. dolnośląskie) zauważyli motocyklistę, który na ich widok nagle przyspieszył. Postanowili sprawdzić mężczyznę. Okazało się, że jego pojazd nie miał ani prędkościomierza, ani drogomierza i wskaźnika paliwa. Co więcej, ostatnie badanie techniczne motocykl przeszedł siedem lat wcześniej.

## Plany podatkowej rewolucji. Co nam szykują partie
 - [https://tvn24.pl/biznes/pieniadze/wybory-2023-programy-wyborcze-podatki-jakie-zmiany-proponuja-pis-ko-trzecia-droga-lewica-konfederacja-i-bezpartyjni-samorzadowcy-7358495?source=rss](https://tvn24.pl/biznes/pieniadze/wybory-2023-programy-wyborcze-podatki-jakie-zmiany-proponuja-pis-ko-trzecia-droga-lewica-konfederacja-i-bezpartyjni-samorzadowcy-7358495?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T10:08:39+00:00

<img alt="Plany podatkowej rewolucji. Co nam szykują partie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dedkg4-zloty-pieniadze-shutterstock2202709927-6720439/alternates/LANDSCAPE_1280" />
    Skokowy wzrost kwoty wolnej od podatku, zmiany w stawkach PIT oraz VAT, a także nowe ulgi - proponują ugrupowania startujące w zbliżających się wyborach parlamentarnych. Sprawdzamy, proponują PiS, KO, Trzecia Droga, Lewica, Konfederacja i Bezpartyjni Samorządowcy.

## Minister mówi o "przełomowym momencie" na rynku. Branża reaguje
 - [https://tvn24.pl/biznes/nieruchomosci/patodeweloperka-apel-polskiego-zwiazku-firm-deweloperskich-do-ministra-waldemara-budy-7359742?source=rss](https://tvn24.pl/biznes/nieruchomosci/patodeweloperka-apel-polskiego-zwiazku-firm-deweloperskich-do-ministra-waldemara-budy-7359742?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T09:55:07+00:00

<img alt="Minister mówi o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8syf5t-mieszkanie-osiedle-blok-shutterstock_1950869113-7359936/alternates/LANDSCAPE_1280" />
    Polski Związek Firm Deweloperskich apeluje do ministra rozwoju i technologii Waldemara Budy o przesunięcie w czasie wejścia w życie przepisów, które mają walczyć z patologiami na rynku nieruchomości. "Podstawą powinno być stabilne, przewidywalne prawo" - napisano.

## "Bitwa o gości". Kiedy pierwszy odcinek?
 - [https://tvn24.pl/kultura-i-styl/bitwa-o-gosci-kiedy-pierwszy-odcinek-nowego-programu-tvn-7359723?source=rss](https://tvn24.pl/kultura-i-styl/bitwa-o-gosci-kiedy-pierwszy-odcinek-nowego-programu-tvn-7359723?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T09:49:42+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hnbeos-bitwa-o-gosci-7359774/alternates/LANDSCAPE_1280" />
    Na co warto zwracać uwagę w hotelu? Czy nocleg na glampingu jest wart swojej ceny? Na te i wiele innych pytań odpowiedzą uczestnicy nowego programu "Bitwa o gości". - Będzie iskrzyć! - zapowiadają producenci. Program będzie emitowany w TVN w każdą niedzielę o godz. 17.30 oraz w Playerze. Premiera 1 października.

## Dziesiątki tysięcy osób demonstrowało przeciwko amnestii dla katalońskich separatystów
 - [https://tvn24.pl/swiat/hiszpania-dziesiatki-tysiecy-osob-demonstrowalo-w-madrycie-przeciwko-amnestii-dla-katalonskich-separatystow-7359382?source=rss](https://tvn24.pl/swiat/hiszpania-dziesiatki-tysiecy-osob-demonstrowalo-w-madrycie-przeciwko-amnestii-dla-katalonskich-separatystow-7359382?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T09:49:15+00:00

<img alt="Dziesiątki tysięcy osób demonstrowało przeciwko amnestii dla katalońskich separatystów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8so2cl-dziesiatki-tysiecy-osob-demonstrowalo-przeciwko-amnestii-dla-katalonskich-separatystow-7359385/alternates/LANDSCAPE_1280" />
    65 tysięcy osób według organizatorów, a 40 tysięcy według delegatury rządu centralnego manifestowało w niedzielę na ulicach Madrytu przeciwko amnestii dla katalońskich separatystów. Protesty zorganizowała opozycyjna centroprawicowa Partia Ludowa na czele z liderem i kandydatem na premiera po lipcowych wyborach Albertem Nunezem Feijoo.

## Były policjant podejrzany o zabójstwo podwładnego i dziennikarza. Jest opinia o poczytalności
 - [https://tvn24.pl/rzeszow/sanok-krosno-krakow-byly-policjant-tadeusz-p-podejrzany-o-zabojstwo-podwladnego-i-dziennikarza-prokuratura-o-poczytalnosci-7293837?source=rss](https://tvn24.pl/rzeszow/sanok-krosno-krakow-byly-policjant-tadeusz-p-podejrzany-o-zabojstwo-podwladnego-i-dziennikarza-prokuratura-o-poczytalnosci-7293837?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T09:27:50+00:00

<img alt="Były policjant podejrzany o zabójstwo podwładnego i dziennikarza. Jest opinia o poczytalności" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s2ebew-prokuratura-okregowa-w-krakowie-7359892/alternates/LANDSCAPE_1280" />
    Tadeusz P., były milicjant, a później także policjant, któremu prokuratura postawiła zarzuty zabójstwa swojego podwładnego - milicjanta Krzysztofa Pyki i sanockiego dziennikarza Marka Pomykały oraz usiłowania zabójstwa swojej byłej żony jest w pełni poczytalny i może za zarzucane czyny odpowiadać przed sądem. Mężczyźnie grozi dożywocie.

## Nocny pożar hali produkcyjnej. W akcji ponad stu strażaków
 - [https://tvn24.pl/rzeszow/cmolas-nocny-pozar-hali-produkcyjnej-w-akcji-ponad-stu-strazakow-7359740?source=rss](https://tvn24.pl/rzeszow/cmolas-nocny-pozar-hali-produkcyjnej-w-akcji-ponad-stu-strazakow-7359740?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T09:07:16+00:00

<img alt="Nocny pożar hali produkcyjnej. W akcji ponad stu strażaków " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6v69y6-w-cmolasie-splonela-hala-produkcyjna-7359743/alternates/LANDSCAPE_1280" />
    Ponad 100 strażaków w Cmolasie (woj. podkarpackie) gasiło pożar hali produkcyjnej, gdzie przetwarzano tworzywa sztuczne. Nikt nie ucierpiał. Przyczyny pojawienia się ognia na razie nie są znane.

## Potrzeby młodego pokolenia oczami wyborczych debiutantów
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-co-dla-mlodych-debiutanci-o-potrzebach-mlodego-pokolenia-7359674?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-co-dla-mlodych-debiutanci-o-potrzebach-mlodego-pokolenia-7359674?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T08:52:22+00:00

<img alt="Potrzeby młodego pokolenia oczami wyborczych debiutantów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wadav2-25-0920-debiuty-0011-7359629/alternates/LANDSCAPE_1280" />
    Młodzi politycy i działacze w programie "Czas Decyzji: debiuty" mówią o swoich pomysłach na Polskę i postulatach, z jakimi startują do Sejmu. W poniedziałkowym wydaniu Jakub Nowicki z Koalicji Obywatelskiej i Jakub Marciniak (Trzecia Droga) poruszyli między innymi temat klimatu i zdrowia psychicznego.

## Wielki producent kończy z silnikami Diesla
 - [https://tvn24.pl/biznes/moto/volvo-konczy-z-silnikami-diesla-padla-data-7359542?source=rss](https://tvn24.pl/biznes/moto/volvo-konczy-z-silnikami-diesla-padla-data-7359542?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T08:51:44+00:00

<img alt="Wielki producent kończy z silnikami Diesla" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m1li79-ulica-korek-volvo-c30-shutterstock_1930675556-7359654/alternates/LANDSCAPE_1280" />
    Volvo ogłosiło, że na początku 2024 roku zaprzestanie produkcji aut z silnikiem Diesla. Firma już wcześniej zobowiązała się, że od 2030 roku będzie produkować wyłącznie pojazdy elektryczne. Volvo jest kolejnym dużym producentem aut, który zapowiada wycofanie silników spalinowych.

## 23-latek "staranowany, pobity i dźgnięty nożem". Raper MHD usłyszał wyrok
 - [https://tvn24.pl/swiat/francja-23-latek-staranowany-pobity-i-dzgniety-nozem-raper-mhd-uslyszal-wyrok-7359501?source=rss](https://tvn24.pl/swiat/francja-23-latek-staranowany-pobity-i-dzgniety-nozem-raper-mhd-uslyszal-wyrok-7359501?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T08:32:18+00:00

<img alt="23-latek " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5eze9o-mhd-7359488/alternates/LANDSCAPE_1280" />
    23 września znany francuski raper MHD został skazany na 12 lat więzienia za morderstwo młodego mężczyzny w Paryżu w 2018 roku. Muzyk w trakcie całego procesu nie przyznawał się do winy. Zidentyfikowali go jednak świadkowie zabójstwa, a całe zdarzenie zostało nagrane z okna mieszkania.

## Z Villarriki wydobywają się gazy wulkaniczne. Może dojść do erupcji
 - [https://tvn24.pl/tvnmeteo/swiat/chile-z-wulkanu-villarrica-wydobywa-sie-dym-moze-dojsc-do-erupcji-7359577?source=rss](https://tvn24.pl/tvnmeteo/swiat/chile-z-wulkanu-villarrica-wydobywa-sie-dym-moze-dojsc-do-erupcji-7359577?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T08:14:35+00:00

<img alt="Z Villarriki wydobywają się gazy wulkaniczne. Może dojść do erupcji " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-bqfnll-wulkan-7359649/alternates/LANDSCAPE_1280" />
    Z wnętrza wulkanu Villarrica, który położony jest na południu Chile, wydobywają się gazy wulkaniczne. Na dnie krateru widać też lawę. Zdaniem ekspertów może dość do erupcji wulkanu.

## Ogromny pożar stodoły i garażu. Trzy osoby poszkodowane. "Ogień było widać z kilku kilometrów"
 - [https://tvn24.pl/lodz/orla-zgierz-ogromny-pozar-stodoly-i-garazu-trzy-osoby-poszkodowane-ogien-bylo-widac-z-kilku-kilometrow-7359570?source=rss](https://tvn24.pl/lodz/orla-zgierz-ogromny-pozar-stodoly-i-garazu-trzy-osoby-poszkodowane-ogien-bylo-widac-z-kilku-kilometrow-7359570?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T07:48:51+00:00

<img alt="Ogromny pożar stodoły i garażu. Trzy osoby poszkodowane. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qdmoeo-akcja-strazakow-trwala-ponad-trzy-godziny-7359554/alternates/LANDSCAPE_1280" />
    Trzy osoby zostały poszkodowane w pożarze garażu i stodoły w miejscowości Orla pod Zgierzem (woj. łódzkie). - Dwóch mężczyzn zostało poparzonych, trzeci zasłabł pod wpływem zdarzenia - informuje straż pożarna. Ogień było widać z kilku kilometrów, służby otrzymywały informację o zdarzeniu między innymi od kierowców jadących autostradą A2.

## Motocyklem uciekał po chodniku i pod prąd. "Doprowadził do zderzenia i upadku policjanta"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/radom-poscig-za-motocyklista-w-radomiu-7359481?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/radom-poscig-za-motocyklista-w-radomiu-7359481?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T07:35:19+00:00

<img alt="Motocyklem uciekał po chodniku i pod prąd. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hwg09j-motocykle-policyjne-7359524/alternates/LANDSCAPE_1280" />
    Policjanci z Radomia prowadzili pościg za 18-latkiem na motocyklu, który który nie zatrzymał się do kontroli. Po drodze popełnił szereg wykroczeń i doprowadził do kolizji z policyjnym jednośladem. Młody mężczyzna został zatrzymany dopiero w miejscu zamieszkania.

## Kampania wyborcza na ostatniej prostej. Ekspertka: warunki jej prowadzenia nie są uczciwe
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-kampania-wyborcza-ekspertka-komentuje-7359561?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-kampania-wyborcza-ekspertka-komentuje-7359561?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T07:25:56+00:00

<img alt="Kampania wyborcza na ostatniej prostej. Ekspertka: warunki jej prowadzenia nie są uczciwe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s8ocqp-barbara-brodzinska-mirowska-7359526/alternates/LANDSCAPE_1280" />
    Warunki prowadzenia tej kampanii nie są uczciwe. Zjednoczona Prawica ma równolegle kampanię referendalną, która nie podlega limitom, czyli mamy sytuację, gdzie finansowo jest to zupełnie inny level - powiedziała w "Rozmowie Piaseckiego: czas decyzji" doktor Barbara Brodzińska-Mirowska, politolożka z Uniwersytetu Mikołaja Kopernika w Toruniu.

## Fragmenty asteroidy Bennu na Ziemi. "Może gdy zbadamy te próbki, zrozumiemy nasze pochodzenie"
 - [https://tvn24.pl/tvnmeteo/nauka/asteroidabennu-nasa-moze-gdy-zbadamy-te-probki-to-zrozumiemy-nasze-pochodzenie-7359487?source=rss](https://tvn24.pl/tvnmeteo/nauka/asteroidabennu-nasa-moze-gdy-zbadamy-te-probki-to-zrozumiemy-nasze-pochodzenie-7359487?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T07:23:48+00:00

<img alt="Fragmenty asteroidy Bennu na Ziemi. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-r0c8fr-kapsula-z-probka-asteroidy-bennu-wyladowala-na-pustyni-w-utah-7359306/alternates/LANDSCAPE_1280" />
    Po siedmiu latach i przebyciu 6,21 miliarda kilometrów należąca do NASA sonda OSIRIS-REx dostarczyła na Ziemię próbkę asteroidy Bennu. - To osiągnięcie to kamień milowy nie tylko dla zespołu, ale dla całej nauki - powiedział Dante Lauretta z Uniwersytetu w Arizonie, który był zaangażowany w tę misję.

## Zderzenie na trasie S2. Rozbite auta blokowały dwa pasy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-na-trasie-s2-korek-7359546?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-na-trasie-s2-korek-7359546?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T07:08:02+00:00

<img alt="Zderzenie na trasie S2. Rozbite auta blokowały dwa pasy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-98ollx-kolizja-na-s2-7359612/alternates/LANDSCAPE_1280" />
    W porannym szczycie warszawscy kierowcy utknęli w 10-kilometrowym korku na trasie S2. To efekt kolizji dwóch samochodów osobowych.

## Spłonął dom jednorodzinny. W zgliszczach znaleziono ciało
 - [https://tvn24.pl/rzeszow/mrzyglod-palil-sie-dom-jednorodzinny-w-zgliszczach-znaleziono-cialo-mezczyzny-7359504?source=rss](https://tvn24.pl/rzeszow/mrzyglod-palil-sie-dom-jednorodzinny-w-zgliszczach-znaleziono-cialo-mezczyzny-7359504?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T06:36:05+00:00

<img alt="Spłonął dom jednorodzinny. W zgliszczach znaleziono ciało" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q1t3n0-mrzyglod-palil-sie-dom-jednorodzinny-7359502/alternates/LANDSCAPE_1280" />
    Ponad 40 strażaków brało udział w akcji w miejscowości Mrzygłód (woj. podkarpackie), gdzie w płomieniach stanął dom jednorodzinny. Nie żyje mężczyzna, którego ciało znaleziono w zgliszczach. Informację i zdjęcie otrzymaliśmy na Kontakt 24.

## Kosiniak-Kamysz: Chcemy prostego mechanizmu. Pracujesz, zasuwasz, nie leżysz na kanapie - państwo cię docenia
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-wladyslaw-kosiniak-kamysz-chcemy-protego-mechanizmu-pracujesz-zasuwasz-nie-lezysz-na-kanapie-panstwo-cie-docenia-7359477?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-wladyslaw-kosiniak-kamysz-chcemy-protego-mechanizmu-pracujesz-zasuwasz-nie-lezysz-na-kanapie-panstwo-cie-docenia-7359477?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T06:05:27+00:00

<img alt="Kosiniak-Kamysz: Chcemy prostego mechanizmu. Pracujesz, zasuwasz, nie leżysz na kanapie - państwo cię docenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xoe5cb-wladyslaw-kosiniak-kamysz-7359464/alternates/LANDSCAPE_1280" />
    Ludzie nam mówili: "Nie możemy na to patrzeć. Dwójka młodych ludzi, dwoje dzieci w domu i nikt tam nie idzie do pracy". My wskazujemy prosty, jasny mechanizm. Pracujesz, zasuwasz, nie leżysz na kanapie, państwo cię docenia - mówił w TVN24 Władysław Kosiniak-Kamysz, prezes PSL, jeden z liderów Trzeciej Drogi.

## "Pływająca bariera" na Morzu Południowochińskim. Filipiny oskarżają Chiny o blokowanie dostępu do łowisk
 - [https://tvn24.pl/swiat/filipiny-oskarzaja-chiny-o-blokowanie-dostepu-do-lowisk-7359374?source=rss](https://tvn24.pl/swiat/filipiny-oskarzaja-chiny-o-blokowanie-dostepu-do-lowisk-7359374?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T05:51:52+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-epy49s-plywajaca-bariera-na-morzu-poludniowochinskim-7359466/alternates/LANDSCAPE_1280" />
    Chiny stworzyły na spornym Morzu Południowochińskim "pływającą barierę", która uniemożliwia filipińskim rybakom dostęp do łowisk, pozbawiając ich źródła utrzymania - oświadczył w niedzielę rzecznik filipińskiej straży przybrzeżnej komandor Jay Tarriela.

## Auto stało na cegłach, obok lewarek i klucz. 32-latek ukrył się w krzakach
 - [https://tvn24.pl/tvnwarszawa/najnowsze/kobylka-auto-bez-kol-zatrzymano-podejrzanego-7359430?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/kobylka-auto-bez-kol-zatrzymano-podejrzanego-7359430?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T05:49:28+00:00

<img alt="Auto stało na cegłach, obok lewarek i klucz. 32-latek ukrył się w krzakach" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-j1bil5-policjanci-zatrzymali-32-latka-podejrzanego-o-kradziez-kol-samochodowych-7359450/alternates/LANDSCAPE_1280" />
    Policjanci z Wołomina prowadzili pościg za mężczyzną podejrzanym o przywłaszczenie kół samochodowych. 32-latek został zatrzymany, przedstawiono mu zarzuty.

## Wrześniowa inflacja, wyniki spółek i dane z USA
 - [https://tvn24.pl/biznes/z-kraju/inflacja-we-wrzesniu-w-polsce-inflacja-w-strefie-euro-wyniki-pge-i-allegro-najwazniejsze-wydarzenia-w-tym-tygodniu-7359434?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-we-wrzesniu-w-polsce-inflacja-w-strefie-euro-wyniki-pge-i-allegro-najwazniejsze-wydarzenia-w-tym-tygodniu-7359434?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T05:07:46+00:00

<img alt="Wrześniowa inflacja, wyniki spółek i dane z USA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gw2n0a-koszyk-sklep-zakupy-inflacja-adobestock_493101486-6627379/alternates/LANDSCAPE_1280" />
    Wśród najważniejszych wydarzeń z kraju w tym tygodniu jest piątkowa publikacja wstępnego odczytu inflacji za wrzesień. Inwestorów zainteresują także raporty finansowe spółek z warszawskiej giełdy - w tym PGE i Allegro. W przypadku informacji zza granicy istotne będą między innymi odczyty o inflacji ze strefy euro oraz dane z USA na temat zatrudnienia.

## Polska pod wpływem pogodnego wyżu Rosi
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-w-polsce-poniedzialek-2509-wyz-rosi-polska-pod-wplywem-pogodnego-wyzu-rosi-7359415?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-w-polsce-poniedzialek-2509-wyz-rosi-polska-pod-wplywem-pogodnego-wyzu-rosi-7359415?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T04:37:06+00:00

<img alt="Polska pod wpływem pogodnego wyżu Rosi" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-e8i9yw-pogodnie-7359420/alternates/LANDSCAPE_1280" />
    Aurę w Polsce kształtuje rozległy wyż Rosi. Sprawia, że do Polski napływa chłodne powietrze polarne. Miejscami występują również mgły ograniczające widzialność do kilkuset metrów.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-25-wrzesnia-2023-7359391?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-25-wrzesnia-2023-7359391?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T03:57:43+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bixuyn-wolodymyr-zelenski-7359392/alternates/LANDSCAPE_1280" />
    Rosyjska pełnoskalowa inwazja na Ukrainę trwa od 579 dni. Liczba rannych w rosyjskim ataku na Krzemieńczuk wzrosła do 55. Nowe pakiety pomocy wojskowej i szereg ustaleń w sprawie wsparcia dla Ukrainy to wynik wizyt i spotkań w USA i w Kanadzie - oświadczył prezydent Wołodymyr Zełenski. Oto najważniejsze wydarzenia ostatnich godzin.

## Uchodźcy z Górskiego Karabachu przybywają do Armenii. "Nie ma słów do opisania. Wieś została mocno ostrzelana"
 - [https://tvn24.pl/swiat/uchodzcy-z-gorskiego-karabachu-przybywaja-do-armenii-po-przejeciu-kontroli-nad-regionem-przez-azerbejdzan-7359394?source=rss](https://tvn24.pl/swiat/uchodzcy-z-gorskiego-karabachu-przybywaja-do-armenii-po-przejeciu-kontroli-nad-regionem-przez-azerbejdzan-7359394?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T03:50:21+00:00

<img alt="Uchodźcy z Górskiego Karabachu przybywają do Armenii. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1ydhl7-uchodzcy-z-gorskiego-karabachu-przybywaja-do-armenii-7359395/alternates/LANDSCAPE_1280" />
    Pierwsi uchodźcy z Górskiego Karabachu przybyli do Armenii - poinformowały w niedzielę lokalne władze po tym, jak Azerbejdżan przeprowadził tam błyskawiczną ofensywę wojskową, odzyskując pełną kontrolę nad regionem.

## Niger zamknął przestrzeń powietrzną dla Francji. Emmanuel Macron ogłosił zakończenie wojskowej współpracy
 - [https://tvn24.pl/swiat/niger-zamknal-swoja-przestrzen-powietrzna-przed-samolotami-z-francji-7359367?source=rss](https://tvn24.pl/swiat/niger-zamknal-swoja-przestrzen-powietrzna-przed-samolotami-z-francji-7359367?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T03:41:41+00:00

<img alt="Niger zamknął przestrzeń powietrzną dla Francji. Emmanuel Macron ogłosił zakończenie wojskowej współpracy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h63jjd-emmanuel-macron-7329482/alternates/LANDSCAPE_1280" />
    Reżim wojskowy rządzący w Nigrze zamknął przestrzeń powietrzną kraju przed samolotami z Francji - poinformowała w niedzielę Agencja Bezpieczeństwa Żeglugi Powietrznej w Afryce (Asecna). Prezydent Emmanuel Macron ujawnił, że Francja podjęła decyzję o wycofaniu swojego ambasadora z Nigru i zakończenia współpracy wojskowej z tym krajem.

## Pięć rzeczy, które warto wiedzieć 25 września
 - [https://tvn24.pl/polska/piec-rzeczy-ktore-warto-wiedziec-25-wrzesnia-2023-7359387?source=rss](https://tvn24.pl/polska/piec-rzeczy-ktore-warto-wiedziec-25-wrzesnia-2023-7359387?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T03:32:16+00:00

<img alt="Pięć rzeczy, które warto wiedzieć 25 września" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uvyo3f-reprezentacja-polski-siatkarek-wystapi-na-przyszlorocznych-igrzyskach-7359388/alternates/LANDSCAPE_1280" />
    Awans polskich siatkarek na igrzyska olimpijskie. Minister spraw zagranicznych Zbigniew Rau "apeluje" do kanclerza Niemiec. Tigist Assefa pobiła rekord świata w maratonie kobiet. Oto pięć rzeczy, które warto dziś wiedzieć.

## Nocny atak na Odessę. Uszkodzona infrastruktura portowa
 - [https://tvn24.pl/swiat/ukraina-relacja-na-zywo-poniedzialek-25-wrzesnia-2023-7359361?source=rss](https://tvn24.pl/swiat/ukraina-relacja-na-zywo-poniedzialek-25-wrzesnia-2023-7359361?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T03:21:27+00:00

<img alt="Nocny atak na Odessę. Uszkodzona infrastruktura portowa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qq7lye-odessa-ukraina-24052022-5729808/alternates/LANDSCAPE_1280" />
    Rosyjska pełnoskalowa inwazja na Ukrainę trwa od 579 dni. Rosjanie przeprowadzili w nocy atak przy pomocy dronów na Odessę. Jak przekazał szef administracji obwodu Ołeh Kiper, jedna kobieta została ranna, a infrastruktura portowa została uszkodzona. W tvn24.pl relacjonujemy najważniejsze wydarzenia z i wokół Ukrainy.

## Pogoda na dziś - poniedziałek 25.09. Dużo słońca, od 18 do 23 stopni
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-poniedzialek-2509-duzo-slonca-od-18-do-23-stopni-7359280?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-poniedzialek-2509-duzo-slonca-od-18-do-23-stopni-7359280?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-25T00:00:00+00:00

<img alt="Pogoda na dziś - poniedziałek 25.09. Dużo słońca, od 18 do 23 stopni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-baf0wz-slonecznie-7359302/alternates/LANDSCAPE_1280" />
    Pierwszy dzień tygodnia będzie słoneczny. Termometry wskażą maksymalnie 23 stopnie. Aura korzystnie wpłynie na nasze samopoczucie.

