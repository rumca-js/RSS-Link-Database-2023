# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## 7 Linux Distros Before Slackware & Debian Existed
 - [https://www.youtube.com/watch?v=JSda6hsjpWQ](https://www.youtube.com/watch?v=JSda6hsjpWQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2023-09-25T21:00:15+00:00

Slackware and Debian Linux have been around for a very long time but they are by no definition of the term the very first linux distros, in fact there are 7 others projects that existed in the few years prior to these.

==========Support The Channel==========
► $100 Linode Credit: https://brodierobertson.xyz/linode
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Linux 0.10: https://git.kernel.org/pub/scm/linux/kernel/git/nico/archive.git/commit/?id=be068f1a017608faa9b4a0652686426df2e87689
Linux 0.95a: https://mirrors.edge.kernel.org/pub/linux/kernel/Historic/old-versions/RELNOTES-0.95a
DLD German Wikipedia: https://de.wikipedia.org/wiki/Deutsche_Linux-Distribution
HJ Lu Bootable Rootdisk: https://www.kclug.org/old_archives/linux-activists/1992/sep/3/0266.shtml
HJ Lu Base System: https://www.kclug.org/old_arch

