# Source:Chris Ray Gun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA, language:en-US

## The McDonalds Ad that Pissed Everyone Off
 - [https://www.youtube.com/watch?v=XXcWZj7IhyU](https://www.youtube.com/watch?v=XXcWZj7IhyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA
 - date published: 2023-09-25T20:41:28+00:00

“Thanks to HelloFresh for sponsoring today's video. Go to https://strms.net/hellofresh_chrisraygun and use code POGRAYGUNSEP50 for 50% off plus Free Shipping!” 

This McDonald's Ad infuriated millions of people ... wait ... did it? I'm confused, hold on. Tabitha?! Hold all my calls. I need to solve this mystery with the help of my disabled talking dog Winstopher. We're solving this caper once and for all on this episode of Twitter Culture War V: The Phantom Rage

Social Media!
TWITTER ► https://twitter.com/ChrisRGun
INSTAGRAM ► https://www.instagram.com/chris_ray_gun/
TWITCH ► https://www.twitch.tv/chrisraygun
TIKTOK ► https://www.tiktok.com/@chrisraygun
SUBREDDIT ► https://www.reddit.com/r/ChrisRayGun/

Support Me Over Here!
MERCH ► https://teespring.com/stores/chris-ray-gun
PATREON ► https://www.patreon.com/ChrisRay

Podcasts!
SACRED SYMBOLS : A PLAYSTATION PODCAST ► https://apple.co/2Rqmklc
SNARK TANK ► https://www.youtube.com/c/TheSnarkTank

