# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Metaverse: What happened to Mark Zuckerberg's next big thing?
 - [https://www.bbc.co.uk/news/technology-66913551?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-66913551?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-09-25T16:02:36+00:00

Two years ago, the metaverse was billed as the next big thing - but many in the tech world have already moved on.

