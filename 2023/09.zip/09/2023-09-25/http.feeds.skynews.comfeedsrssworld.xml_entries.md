# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Senator accused of bribery says $480,000 in cash found at home was from his personal savings
 - [https://news.sky.com/story/bob-menendez-democrat-senator-accused-of-bribery-says-cash-found-at-home-was-from-his-personal-savings-12970006](https://news.sky.com/story/bob-menendez-democrat-senator-accused-of-bribery-says-cash-found-at-home-was-from-his-personal-savings-12970006)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T18:44:00+00:00

A US senator facing corruption charges says nearly half a million dollars in cash which authorities discovered in his home was from his personal savings - and not from bribes.

## Human extinction and 70C heatwaves - supercomputer climate models warn of apocalyptic future
 - [https://news.sky.com/story/extreme-global-warming-could-eventually-wipe-out-humans-first-ever-supercomputer-climate-models-warn-12969718](https://news.sky.com/story/extreme-global-warming-could-eventually-wipe-out-humans-first-ever-supercomputer-climate-models-warn-12969718)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T14:59:00+00:00

Extreme global warming will likely wipe all mammals - including humans - off the face of the Earth in 250 million years, according to a new scientific study.

## 'No turning back now': Nissan commits to 2030 electric car deadline
 - [https://news.sky.com/story/nissan-commits-to-2030-electric-car-deadline-despite-delay-to-uk-petrol-diesel-ban-12969873](https://news.sky.com/story/nissan-commits-to-2030-electric-car-deadline-despite-delay-to-uk-petrol-diesel-ban-12969873)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T14:21:00+00:00

Nissan has committed itself to the sale of only electric cars across Europe from 2030, the year when the UK was supposed to have banned new vehicles powered by petrol and diesel.

## COVID drug linked to mutations that could 'spread the illness', scientists say
 - [https://news.sky.com/story/molnupiravir-covid-drug-linked-to-mutations-that-could-spread-the-illness-scientists-say-12969805](https://news.sky.com/story/molnupiravir-covid-drug-linked-to-mutations-that-could-spread-the-illness-scientists-say-12969805)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T13:06:00+00:00

A drug used to treat COVID-19 may, in fact, be helping spread the illness, scientists have said.

## Herd of sheep eats 100kg of cannabis in Greece
 - [https://news.sky.com/story/herd-of-sheep-eats-100kg-of-cannabis-in-greece-after-storm-daniel-floods-12969680](https://news.sky.com/story/herd-of-sheep-eats-100kg-of-cannabis-in-greece-after-storm-daniel-floods-12969680)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T12:29:00+00:00

A herd of sheep struggling to find fresh grass for food due to extreme flooding started behaving strangely after eating large parts of a cannabis crop, according to reports.

## British man 'stabbed to death during online challenge' in Portugal
 - [https://news.sky.com/story/british-man-stabbed-to-death-during-online-challenge-in-portugal-12969763](https://news.sky.com/story/british-man-stabbed-to-death-during-online-challenge-in-portugal-12969763)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T12:13:00+00:00

A British man has reportedly been stabbed to death in Portugal while taking part in an online challenge.

## Gymnastics Ireland 'deeply sorry' after Simone Biles criticism over black girl snubbed at medal ceremony
 - [https://news.sky.com/story/gymnastics-ireland-deeply-sorry-after-simone-biles-criticises-young-black-gymnast-being-denied-medal-12969684](https://news.sky.com/story/gymnastics-ireland-deeply-sorry-after-simone-biles-criticises-young-black-gymnast-being-denied-medal-12969684)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T10:23:00+00:00

Gymnastics Ireland has issued an apology after a video of a black girl being passed over for a medal at a ceremony went viral.

## Secrets of our solar system will be revealed from 250g of dust
 - [https://news.sky.com/story/secrets-of-our-solar-system-will-be-revealed-from-osiris-rex-asteroid-sample-12969667](https://news.sky.com/story/secrets-of-our-solar-system-will-be-revealed-from-osiris-rex-asteroid-sample-12969667)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T09:53:00+00:00

It will make the most incredible unboxing video.

## Hollywood star Sophia Loren has emergency surgery
 - [https://news.sky.com/story/sophia-loren-hollywood-star-has-emergency-surgery-after-falling-at-home-12969657](https://news.sky.com/story/sophia-loren-hollywood-star-has-emergency-surgery-after-falling-at-home-12969657)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T09:34:00+00:00

Oscar-winning actress Sophia Loren has had emergency surgery following a fall at her home.

## Thousands of ethnic Armenians flee disputed territory after Azerbaijan regains control
 - [https://news.sky.com/story/thousands-of-ethnic-armenians-flee-disputed-nagorno-karabakh-territory-after-azerbaijan-regains-control-12969651](https://news.sky.com/story/thousands-of-ethnic-armenians-flee-disputed-nagorno-karabakh-territory-after-azerbaijan-regains-control-12969651)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T09:21:00+00:00

At least 4,850 ethnic Armenians have fled the territory of Nagorno-Karabakh, the Armenian government has said.

## Cause of Antarctica heatwave revealed - after temperatures soared 39C above normal
 - [https://news.sky.com/story/cause-of-antarctica-heatwave-revealed-after-temperatures-soared-39c-above-normal-12969629](https://news.sky.com/story/cause-of-antarctica-heatwave-revealed-after-temperatures-soared-39c-above-normal-12969629)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T08:32:00+00:00

Scientists have uncovered the link between a world-record heatwave in Antarctica and climate change.

## Police identify woman's body found in alligator's mouth
 - [https://news.sky.com/story/florida-woman-whose-remains-were-found-in-alligators-mouth-identified-by-police-12969555](https://news.sky.com/story/florida-woman-whose-remains-were-found-in-alligators-mouth-identified-by-police-12969555)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T06:07:00+00:00

Police have identified a woman whose remains were found in the mouth of a 13ft alligator in Florida.

## Sicilian mafia boss Matteo Messina Denaro has died
 - [https://news.sky.com/story/sicilian-mafia-boss-messina-denaro-has-died-12969519](https://news.sky.com/story/sicilian-mafia-boss-messina-denaro-has-died-12969519)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-25T01:55:00+00:00

Sicilian mafia boss Matteo Messina Denaro, who was arrested in January after spending 30 years on the run, according to Italian media reports.

