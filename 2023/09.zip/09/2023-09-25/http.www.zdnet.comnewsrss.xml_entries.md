# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## Getty Images launches its own 'commercially safe' AI image generator
 - [https://www.zdnet.com/article/getty-images-launches-its-own-commercialy-safe-ai-image-generator/#ftag=RSSbaffb68](https://www.zdnet.com/article/getty-images-launches-its-own-commercialy-safe-ai-image-generator/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T21:09:16+00:00

Using Getty Images' expansive image library, customers will soon be able to create their own images.

## This VR headset gave me productivity bliss when I had no furniture at home
 - [https://www.zdnet.com/article/this-vr-headset-gave-me-productivity-bliss-when-i-had-no-furniture-at-home/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-vr-headset-gave-me-productivity-bliss-when-i-had-no-furniture-at-home/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T21:03:48+00:00

When paired with my MacBook, the HTC Vive XR Elite made working from a new home a lot easier.

## Kick off a career in IT with this cybersecurity training bundle
 - [https://www.zdnet.com/article/kick-off-a-career-in-it-with-this-cybersecurity-training-bundle/#ftag=RSSbaffb68](https://www.zdnet.com/article/kick-off-a-career-in-it-with-this-cybersecurity-training-bundle/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T20:47:40+00:00

This $46 course gives you 114 hours of ethical hacking, penetration testing, and more.

## Alexa's new Emergency Assist could save your life and protect your peace of mind
 - [https://www.zdnet.com/home-and-office/smart-home/alexas-new-emergency-assist-could-save-your-life-and-protect-your-peace-of-mind/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/alexas-new-emergency-assist-could-save-your-life-and-protect-your-peace-of-mind/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T20:33:00+00:00

With Amazon's new service, all you have to do to summon first responders in an emergency is say 'Alexa, call for help'.

## USB-C charger for your iPhone 15? Anker's $30 power bank is just the thing
 - [https://www.zdnet.com/article/usb-c-charger-for-your-iphone-15-ankers-30-power-bank-is-just-the-thing/#ftag=RSSbaffb68](https://www.zdnet.com/article/usb-c-charger-for-your-iphone-15-ankers-30-power-bank-is-just-the-thing/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T20:02:18+00:00

No bigger than a lipstick case, the Nano 22.5W Power Bank delivers an emergency charge whenever your phone battery needs it.

## Gmail's basic HTML view will disappear in January 2024
 - [https://www.zdnet.com/home-and-office/work-life/gmails-basic-html-view-will-disappear-in-january-2024/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/gmails-basic-html-view-will-disappear-in-january-2024/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T20:01:04+00:00

Google hasn't made any public announcement of this change, instead quietly adding a disclaimer on its support page.

## I challenge you to find a better-looking laptop for under $1,000 than this
 - [https://www.zdnet.com/article/i-challenge-you-to-find-a-better-looking-laptop-for-under-1000-than-this/#ftag=RSSbaffb68](https://www.zdnet.com/article/i-challenge-you-to-find-a-better-looking-laptop-for-under-1000-than-this/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T20:01:00+00:00

The Asus Zenbook 14 Flip OLED has one of the nicest screens I've seen on a laptop, and there's more to love underneath the hood.

## This $250 Motorola is my sleeper pick for best budget phone of 2023
 - [https://www.zdnet.com/article/this-250-motorola-is-my-sleeper-pick-for-best-budget-phone-of-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-250-motorola-is-my-sleeper-pick-for-best-budget-phone-of-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T20:01:00+00:00

The Moto G Power 5G provides multiple days of battery life, an improved display, and 5G support at a price many can afford.

## How to run Firefox in Ubuntu's Wayland mode (and why you should)
 - [https://www.zdnet.com/article/how-to-run-firefox-in-ubuntus-wayland-mode-and-why-you-should/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-run-firefox-in-ubuntus-wayland-mode-and-why-you-should/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T20:00:17+00:00

With the soon-to-be-released Ubuntu 23.10, Firefox will default to Wayland mode. Here's how you can gain the benefits of Wayland mode on Ubuntu and other distributions.

## The AirPods Pro 2 got a huge upgrade, and they're on sale right now
 - [https://www.zdnet.com/article/the-airpods-pro-2-got-a-huge-upgrade-and-theyre-on-sale-right-now/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-airpods-pro-2-got-a-huge-upgrade-and-theyre-on-sale-right-now/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T19:13:58+00:00

Apple and Sony are consistently neck-and-neck in the earbuds and over-ear headphones race. But Apple's new software update (and lower price) is closing on Sony's lead. Here's why.

## These $350 headphones allowed me to hear things I'd never heard before
 - [https://www.zdnet.com/article/these-350-headphones-allowed-me-to-hear-things-id-never-heard-before/#ftag=RSSbaffb68](https://www.zdnet.com/article/these-350-headphones-allowed-me-to-hear-things-id-never-heard-before/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T18:59:00+00:00

Sennheiser's Momentum 4 may be the best headphones for people who want to hear the finest details in their music.

## Why iPhone 15 isn't as repairable as Apple wants you to believe
 - [https://www.zdnet.com/article/why-iphone-15-isnt-as-repairable-as-apple-wants-you-to-believe/#ftag=RSSbaffb68](https://www.zdnet.com/article/why-iphone-15-isnt-as-repairable-as-apple-wants-you-to-believe/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T17:39:06+00:00

Apple wants you to repair your iPhone, right? Well, iFixit took a look at the iPhone 15 and discovered a few problems with the new device's design.

## Google Pixel 8 leaks reveal AI-powered camera features and major software update policy
 - [https://www.zdnet.com/article/google-pixel-8-leaks-reveal-ai-powered-camera-features-and-major-software-update-policy/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-pixel-8-leaks-reveal-ai-powered-camera-features-and-major-software-update-policy/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T16:33:00+00:00

A series of Pixel 8 leaks over the weekend is leaving little to the imagination ahead of Google's hardware event next week.

## Microsoft's SwiftKey keyboard brings more AI-infused superpowers to iOS and Android
 - [https://www.zdnet.com/article/microsofts-swiftkey-keyboard-brings-more-ai-infused-superpowers-to-ios-and-android/#ftag=RSSbaffb68](https://www.zdnet.com/article/microsofts-swiftkey-keyboard-brings-more-ai-infused-superpowers-to-ios-and-android/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T16:17:54+00:00

With the latest update, SwiftKey will help you generate images with Bing AI, use AI-based camera lenses, and create stickers from your photos.

## Roku's soundbar sounded better than expected, and it fixed a big problem I have
 - [https://www.zdnet.com/home-and-office/home-entertainment/rokus-soundbar-sounded-better-than-expected-and-it-fixed-a-big-problem-i-have/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/rokus-soundbar-sounded-better-than-expected-and-it-fixed-a-big-problem-i-have/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T16:16:10+00:00

I was impressed with the Roku TV Wireless SoundBar, but this affordable option only works with a certain type of TV.

## You can have voice chats with ChatGPT now. Here's how
 - [https://www.zdnet.com/article/you-can-have-voice-chats-with-chatgpt-now-heres-how/#ftag=RSSbaffb68](https://www.zdnet.com/article/you-can-have-voice-chats-with-chatgpt-now-heres-how/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T16:04:10+00:00

OpenAI says 'ChatGPT can now see, hear, and speak'. What could go wrong?

## Pronoun support comes to iOS 17 Contacts app. Here's how to use it
 - [https://www.zdnet.com/article/pronoun-support-comes-to-ios-17-contacts-app-heres-how-to-use-it/#ftag=RSSbaffb68](https://www.zdnet.com/article/pronoun-support-comes-to-ios-17-contacts-app-heres-how-to-use-it/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T15:38:25+00:00

iPhone's Contacts app just got a much-requested addition, and it comes with its own privacy policy.

## Roku's first-ever TV is shockingly capable for the price you pay
 - [https://www.zdnet.com/home-and-office/home-entertainment/rokus-first-ever-tv-is-shockingly-capable-for-the-price-you-pay/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/rokus-first-ever-tv-is-shockingly-capable-for-the-price-you-pay/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T14:57:00+00:00

You won't find some of the features you see on more expensive sets, but the Plus Series is a very solid mid-range television.

## How to leave a FaceTime voice or video message when your call goes unanswered
 - [https://www.zdnet.com/article/how-to-leave-a-facetime-voice-or-video-message-when-your-call-goes-unanswered/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-leave-a-facetime-voice-or-video-message-when-your-call-goes-unanswered/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T14:42:21+00:00

You can now leave someone a message if they don't pick up your FaceTime call. Here's how.

## Why IT growth is only leading to more burnout, and what should be done about it
 - [https://www.zdnet.com/article/why-it-growth-is-only-leading-to-more-burnout-and-what-should-be-done-about-it/#ftag=RSSbaffb68](https://www.zdnet.com/article/why-it-growth-is-only-leading-to-more-burnout-and-what-should-be-done-about-it/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T14:30:32+00:00

Nine in ten IT managers agree that companies with a high degree of automation have the most effective incident response.

## DJI gives its smallest drone a big upgrade
 - [https://www.zdnet.com/home-and-office/dji-gives-its-smallest-drone-a-big-upgrade/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/dji-gives-its-smallest-drone-a-big-upgrade/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T14:19:00+00:00

Omni-directional sensors come to the sub-250g DJI Mini 4 Pro. Here's why that's a big deal.

## Fedora 39 beta offers one of the best-performing Linux distributions I've seen in a long time
 - [https://www.zdnet.com/article/fedora-39-beta-offers-one-of-the-best-performing-linux-distributions-ive-seen-in-a-long-time/#ftag=RSSbaffb68](https://www.zdnet.com/article/fedora-39-beta-offers-one-of-the-best-performing-linux-distributions-ive-seen-in-a-long-time/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T14:04:40+00:00

Even in beta, Fedora 39 is buttery smooth and lightning quick.

## Amazon ups generative AI ante with $4B investment in Anthropic
 - [https://www.zdnet.com/article/amazon-ups-generative-ai-ante-with-4b-investment-in-anthropic/#ftag=RSSbaffb68](https://www.zdnet.com/article/amazon-ups-generative-ai-ante-with-4b-investment-in-anthropic/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T14:00:56+00:00

The AI race is heating up again, as Amazon assumes minority ownership of Anthropic.

## 3 new WhatsApp features businesses need to know about
 - [https://www.zdnet.com/article/3-new-whatsapp-features-businesses-need-to-know-about/#ftag=RSSbaffb68](https://www.zdnet.com/article/3-new-whatsapp-features-businesses-need-to-know-about/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-09-25T07:15:41+00:00

Each update makes Mark Zuckerberg's WhatsApp look more like the X app that Elon Musk wanted Twitter to be.

