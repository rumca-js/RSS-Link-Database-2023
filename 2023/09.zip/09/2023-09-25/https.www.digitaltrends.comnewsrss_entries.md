# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## iPhone 15 Pro Max durability test ends with big surprise
 - [https://www.digitaltrends.com/mobile/iphone-15-pro-max-durability-tests-ends-with-big-surprise/](https://www.digitaltrends.com/mobile/iphone-15-pro-max-durability-tests-ends-with-big-surprise/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2023-09-25T11:14:51.011471+00:00

Zack Nelson's smartphone durability tests are legendary. And this one on the new iPhone 15 Pro Max ends in an unexpected way.

## Watch NASA’s capsule with asteroid samples hurtling to Earth
 - [https://www.digitaltrends.com/space/watch-nasa-capsule-with-asteroid-samples-hurtling-to-earth/](https://www.digitaltrends.com/space/watch-nasa-capsule-with-asteroid-samples-hurtling-to-earth/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2023-09-25T11:14:51.009842+00:00

Watch the key moments from NASA's first-ever sample return mission, from spotting the capsule streaking across the sky to its arrival in a clean room.

## Chocolate mousse in space is more important than you think
 - [https://www.digitaltrends.com/space/chocolate-mousse-in-space-is-more-important-than-you-think/](https://www.digitaltrends.com/space/chocolate-mousse-in-space-is-more-important-than-you-think/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2023-09-25T11:14:51.008029+00:00

An astronaut aboard the ISS has just used a purpose-built machine to make chocolate mousse, a creation that could prove vital for future space voyages.

