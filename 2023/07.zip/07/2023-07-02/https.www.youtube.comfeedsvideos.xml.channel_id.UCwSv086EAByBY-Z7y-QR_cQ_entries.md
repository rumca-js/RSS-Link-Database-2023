# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Zamieszki we Francji - wszystkiemu się winne gry komputerowe i media społecznościowe!
 - [https://www.youtube.com/watch?v=9XiJPbaGy4w](https://www.youtube.com/watch?v=9XiJPbaGy4w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2023-07-02T21:58:07+00:00



