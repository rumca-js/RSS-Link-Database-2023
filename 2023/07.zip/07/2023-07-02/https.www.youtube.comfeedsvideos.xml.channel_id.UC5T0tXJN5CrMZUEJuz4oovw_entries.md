# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## Indiana Jones 5 is AWFUL | A Massive Disney FLOP
 - [https://www.youtube.com/watch?v=ShGdukU50UU](https://www.youtube.com/watch?v=ShGdukU50UU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2023-07-02T18:32:17+00:00

Kathleen Kennedy and Disney/Lucasfilm have completed the destruction of George Lucas' legacy.
Indiana Jones and the Dial of Destiny Spoiler REVIEW
#disney #Lucasfilm #IndianaJones
Become a Nerdrotic Channel Member: youtube.com/c/sutrowatchtower/join

Subscribe to The Nerdrotic Network: @nerdrotic @NerdroticLive @NerdroticDaily 

Edited by @QTRBlackGarrett 

Special thanks to @JarJarAbrams 

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsored by MetaPCs!
Click here to get a discount on a PC: http://Metapcs.com/Nerdrotic/ref

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/products/...

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/...

