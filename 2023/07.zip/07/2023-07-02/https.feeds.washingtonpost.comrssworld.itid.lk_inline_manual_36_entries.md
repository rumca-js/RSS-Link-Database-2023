# Source:The Washington Post - World, URL:https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36, language:en-US

## Twitter sued Indian government for ‘arbitrarily’ silencing critics. It lost.
 - [https://www.washingtonpost.com/world/2023/07/02/twitter-india-censorship-lawsuit-dismissed/](https://www.washingtonpost.com/world/2023/07/02/twitter-india-censorship-lawsuit-dismissed/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-07-02T17:10:03+00:00

A judge in the Karnataka High Court dismissed Twitter’s lawsuit and ordered the company to pay a fine for taking up the court's time.

## South Korea’s biggest Pride parade was blocked. It came back stronger.
 - [https://www.washingtonpost.com/world/2023/07/02/seoul-pride-parade-2023-queer/](https://www.washingtonpost.com/world/2023/07/02/seoul-pride-parade-2023-queer/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-07-02T15:54:49+00:00

When Seoul's Pride organizers were denied a permit, they found an alternate venue and route as a reminder that they "are living, working and loving alongside you.”

## Chinese tour bus, mayor’s home attacked as protests roil France
 - [https://www.washingtonpost.com/world/2023/07/02/france-protests-nahel-m-shooting/](https://www.washingtonpost.com/world/2023/07/02/france-protests-nahel-m-shooting/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-07-02T14:13:31+00:00

Vincent Jeanbrun said his family was sleeping as protesters attacked his house with a burning vehicle. The police killing of Nahel M. sparked protests nationwide.

## Dutch king apologizes for monarchy’s role in colonial slave trade
 - [https://www.washingtonpost.com/world/2023/07/02/netherlands-king-apology-slave-trade/](https://www.washingtonpost.com/world/2023/07/02/netherlands-king-apology-slave-trade/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-07-02T07:55:10+00:00

King Willem-Alexander apologized as the Netherlands marked 150 years since the practical abolition of slavery in Suriname and the former Dutch Caribbean.

## Ukraine live briefing: Zelensky says Spanish leader’s trip on first day heading E.U. council marks ‘new reality’
 - [https://www.washingtonpost.com/world/2023/07/02/russia-ukraine-war-news/](https://www.washingtonpost.com/world/2023/07/02/russia-ukraine-war-news/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-07-02T06:42:16+00:00

The Ukrainian president said the visit to Kyiv was “symbolic” and underscored the “priorities of the Spanish presidency and our cooperation.”

## Ukraine says Putin is planning a nuclear disaster. These people live nearby.
 - [https://www.washingtonpost.com/world/2023/07/02/zaporizhzhia-nuclear-meltdown-inhabitants/](https://www.washingtonpost.com/world/2023/07/02/zaporizhzhia-nuclear-meltdown-inhabitants/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-07-02T05:00:06+00:00

The Zaporizhzhia nuclear plant has been in danger throughout the conflict, but the risks of a meltdown rose sharply with the destruction of the Kakhovka dam.

## Carlos Alberto Montaner, Cuban exile writer who battled Castro, dies at 80
 - [https://www.washingtonpost.com/obituaries/2023/07/01/carlos-montaner-cuba-writer-dies/](https://www.washingtonpost.com/obituaries/2023/07/01/carlos-montaner-cuba-writer-dies/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-07-02T02:05:16+00:00

Mr. Montaner initially celebrated Fidel Castro's takeover of Cuba but quickly turned into a fierce critic.

