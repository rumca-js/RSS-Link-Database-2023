# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Holding medialny Prigożyna poinformował o swoim zamknięciu
 - [https://www.bankier.pl/wiadomosc/Holding-medialny-Prigozyna-poinformowal-o-swoim-zamknieciu-8572181.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Holding-medialny-Prigozyna-poinformowal-o-swoim-zamknieciu-8572181.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T17:17:50.285044+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/7/410b0da2ae4a43-948-568-0-47-2739-1643.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Holding medialny Patriot należący do Jewgienija Prigożyna poinformował o swoim zamknięciu - podała w niedzielę agencja Reutera. Ma być to efekt buntu Prigożyna i jego Grupy Wagnera przeciwko ministerstwu obrony Rosji.</p>

## Fotoradar rekordzista w Belgii przyniósł budżetowi 7,5 mln euro w ciągu roku
 - [https://www.bankier.pl/wiadomosc/Fotoradar-rekordzista-w-Belgii-przyniosl-budzetowi-7-5-mln-euro-w-ciagu-roku-8568055.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fotoradar-rekordzista-w-Belgii-przyniosl-budzetowi-7-5-mln-euro-w-ciagu-roku-8568055.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T15:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/5a402431b594cf-948-568-0-0-3600-2159.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najbardziej skuteczny fotoradar w Belgii znajduje się
 w Antwerpii w północnej części kraju, poinformował dziennik „Het 
Nieuwsblad”. Tylko w 2022 r. złapał na przekroczeniu prędkości 120 tys. 
kierowców i przyniósł budżetowi 7,5 mln euro.</p>

## Albo otwierasz drzwi auta w konkretny sposób, albo grozi ci mandat. Belgia chce chronić rowerzystów na drogach
 - [https://www.bankier.pl/wiadomosc/Albo-otwierasz-drzwi-auta-w-konkretny-sposob-albo-grozi-ci-mandat-Belgia-chce-chronic-rowerzystow-na-drogach-8567593.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Albo-otwierasz-drzwi-auta-w-konkretny-sposob-albo-grozi-ci-mandat-Belgia-chce-chronic-rowerzystow-na-drogach-8567593.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/0/ea681f5f11dbc8-948-568-0-120-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Flamandzcy socjaldemokraci (Vooruit) złożyli w izbie niższej belgijskiego parlamentu projekt ustawy o wprowadzeniu obowiązku tzw. holenderskiego sposobu otwierania drzwi samochodu. Ma to doprowadzić do zmniejszenia liczby wypadków z udziałem rowerzystów, którzy trafiają do szpitali w wyniku nagłego otwarcia drzwi auta.</p>

## Świadomość ekologiczna Polaków rośnie. Większość chciałaby kupować produkty, które nie szkodzą roślinom i zwierzętom
 - [https://www.bankier.pl/wiadomosc/Swiadomosc-ekologiczna-Polakow-rosnie-Wiekszosc-chcialaby-kupowac-produkty-ktore-nie-szkodza-roslinom-i-zwierzetom-8562849.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Swiadomosc-ekologiczna-Polakow-rosnie-Wiekszosc-chcialaby-kupowac-produkty-ktore-nie-szkodza-roslinom-i-zwierzetom-8562849.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/3/91603a1750da3c-948-568-0-180-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ok. 63 badanych chciałoby kupować produkty, które nie
 szkodzą roślinom i zwierzętom ani nie przyczyniają się do zmiany 
klimatu  - wynika z globalnego sondażu przeprowadzonego przez Ipsos.</p>

## Pożegnanie z rosyjskim gazem? Niemcy nie są ku temu chętne
 - [https://www.bankier.pl/wiadomosc/Pozegnanie-z-rosyjskim-gazem-Niemcy-nie-sa-ku-temu-chetne-8572129.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pozegnanie-z-rosyjskim-gazem-Niemcy-nie-sa-ku-temu-chetne-8572129.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T12:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/8/dec4024815ec8f-750-450-0-97-750-450.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Reforma energetyczna w Niemczech nie powiodła się - tak uważa premier Saksonii Michael Kretschmer (CDU). Naciska więc na rozwiązania dyplomatyczne wobec Ukrainy, ponieważ nie chce, aby „droga do rosyjskiego gazu została zablokowana na dłuższą metę” – informuje w niedzielę portal „Tagesschau”.</p>

## Siły lotnicze Izraela wzmocni kolejne 25 myśliwców F-35
 - [https://www.bankier.pl/wiadomosc/Sily-lotnicze-Izraela-wzmocni-kolejne-25-mysliwcow-F-35-8572114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sily-lotnicze-Izraela-wzmocni-kolejne-25-mysliwcow-F-35-8572114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T11:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/2f6a7e21d5d7bc-948-568-0-120-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izrael kupi 25 amerykańskich myśliwców typu stealth F-35, zwiększając swoją flotę tych maszyn do 75 - poinformowało w niedzielę izraelski resort obrony i wojsko. Wartość transakcji szacuje się na 3 miliardy dolarów i jest ona finansowana z funduszy pomocy wojskowej USA dla Izraela.</p>

## Prezes PiS: jesteśmy władzą nieuwikłaną w wielkie złodziejstwo
 - [https://www.bankier.pl/wiadomosc/Kaczynski-o-zlodziejstwie-zbrojeniach-i-dobrym-czasie-w-Polsce-8572107.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-o-zlodziejstwie-zbrojeniach-i-dobrym-czasie-w-Polsce-8572107.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T11:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/c/3661c7c644f300-948-568-0-15-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezesowi PiS dopisuje poczucie humoru. W czasie rządów PO-PSL była wielka zgoda na rabunek; my jesteśmy władzą nieuwikłaną w całe to wielkie złodziejstwo - powiedział w niedzielę prezes PiS Jarosław Kaczyński. Zdołaliśmy w ciągu 8 lat zmienić w Polsce ustrój społeczno-gospodarczy - dodał.</p>

## Przestępczość w Europie. Ten kraj ma najwięcej przetrzymywanych więźniów
 - [https://www.bankier.pl/wiadomosc/W-Europie-najwiecej-wiezniow-przetrzymywanych-jest-w-Turcji-8568585.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-Europie-najwiecej-wiezniow-przetrzymywanych-jest-w-Turcji-8568585.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/0/46fba4db567ce1-948-568-0-160-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wyłączając Rosję, Turcja ma największą w Europie populację więźniów - ponad 300 tys. Ankara kontynuuje rozbudowę infrastruktury więziennej - wynika z raportu Rady Europy.</p>

## Wielka Brytania zmaga się z napływem uchodźców. Rząd stawia na deportację mimo wyższych kosztów niż utrzymywanie ich w kraju
 - [https://www.bankier.pl/wiadomosc/Wielka-Brytania-zmaga-sie-z-naplywem-uchodzcow-Rzad-stawia-na-deportacje-mimo-wyzszych-kosztow-niz-utrzymywanie-ich-w-kraju-8568257.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wielka-Brytania-zmaga-sie-z-naplywem-uchodzcow-Rzad-stawia-na-deportacje-mimo-wyzszych-kosztow-niz-utrzymywanie-ich-w-kraju-8568257.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/1/0a3e6a2e643c78-948-568-194-0-2912-1747.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć koszt deportacji pojedynczego nielegalnego imigranta do Rwandy jest znacząco wyższy niż utrzymywania go w Wielkiej Brytanii, rząd liczy, iż perspektywa deportacji będzie na tyle silnym czynnikiem zniechęcającym, że w ogólnym rozrachunku to się opłaci - piszą brytyjskie media, w tym "The Times".</p>

## Polska chce atomu. "Kwestie Nuclear Sharing będą omawiane na szczycie NATO"
 - [https://www.bankier.pl/wiadomosc/Polska-chce-atomu-Kwestie-Nuclear-Sharing-beda-omawiane-na-szczycie-NATO-8572105.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-chce-atomu-Kwestie-Nuclear-Sharing-beda-omawiane-na-szczycie-NATO-8572105.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T10:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/1087173c3636e7-945-560-12-80-2467-1480.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kwestie udziału Polski w Nuclear Sharing będą podnoszone na szczycie NATO w Wilnie – poinformował w niedzielę doradca prezydenta Andrzeja Dudy, Paweł Sałek. W piątek Biały Dom poinformował, że nie ma nic do powiedzenia w tej sprawie.</p>

## Kamiński: 500 policjantów wesprze SG na granicy z Białorusią
 - [https://www.bankier.pl/wiadomosc/Kaminski-500-policjantow-wesprze-SG-na-granicy-z-Bialorusia-8572095.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaminski-500-policjantow-wesprze-SG-na-granicy-z-Bialorusia-8572095.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T09:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/f/b1c4024a61697a-948-568-4-0-1765-1059.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podjąłem decyzję o wzmocnieniu naszych sił na granicy z Białorusią grupą 500 funkcjonariuszy policji z oddziałów prewencji i kontrterrorystami - poinformował w niedzielę minister spraw wewnętrznych i administracji Mariusz Kamiński. Ma to związek z ciągle napiętą sytuacją na tym odcinku granicy państwa.</p>

## Polska liderem transportu międzynarodowego w UE. Czy Europejski Zielony Ład nam zagraża?
 - [https://www.bankier.pl/wiadomosc/Polska-liderem-transportu-miedzynarodowego-w-UE-Czy-Europejski-Zielony-Lad-nam-zagraza-8569831.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-liderem-transportu-miedzynarodowego-w-UE-Czy-Europejski-Zielony-Lad-nam-zagraza-8569831.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/8/5c999a076a38ad-948-568-1212-0-2331-1399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W długoterminowym ujęciu rola transportu drogowego pozostanie stabilna – w 2050 r. w Polsce ma on odpowiadać za ok. 75,5 proc. całkowitego transportu towarowego, czyli podobnie jak obecnie - ocenia się w raporcie EFL Leasing Credit Agricole.</p>

## Atak rakietowy na Kijów. Obrona powietrzna zestrzeliła trzy rakiety Kalibr
 - [https://www.bankier.pl/wiadomosc/Atak-rakietowy-na-Kijow-Obrona-powietrzna-zestrzelila-trzy-rakiety-Kalibr-8572080.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Atak-rakietowy-na-Kijow-Obrona-powietrzna-zestrzelila-trzy-rakiety-Kalibr-8572080.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T07:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/5/00c0a4a9dbbd3f-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W nocy miał miejsce pierwszy od 12 dni atak rakietowy na Kijów. Siły powietrzne Ukrainy zestrzeliły podczas nocnego ataku wojsk rosyjskich osiem irańskich dronów uderzeniowych typu Shahed oraz trzy rakiety manewrujące Kalibr – podało w niedzielę rano dowództwo wojsk lotniczych w Kijowie.</p>

## Branża IT chce ograniczyć swój ślad węglowy. Rośnie zapotrzebowanie na tych programistów
 - [https://www.bankier.pl/wiadomosc/Branza-IT-chce-ograniczyc-swoj-slad-weglowy-Rosnie-zapotrzebowanie-na-tych-programistow-8565781.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branza-IT-chce-ograniczyc-swoj-slad-weglowy-Rosnie-zapotrzebowanie-na-tych-programistow-8565781.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/7/fc525b03fcab46-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Branża IT, która generuje kilka procent globalnych 
emisji gazów cieplarnianych, przykłada coraz większą wagę do 
efektywności energetycznej. Jednym z wiodących trendów staje się green 
coding, czyli podejście do programowania skupiające się na tworzeniu 
aplikacji i systemów informatycznych, które minimalizują  ich negatywny 
wpływ na środowisko naturalne. Dlatego rośnie zapotrzebowanie na 
programistów, którzy będą uwzględniać cele prośrodowiskowe.</p>

## Coraz więcej europejskich lotnisk zwiększa limity płynów, które turyści mogą wnosić na pokład
 - [https://www.bankier.pl/wiadomosc/Coraz-wiecej-europejskich-lotnisk-zwieksza-limity-plynow-ktore-turysci-moga-wnosic-na-poklad-8568936.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-wiecej-europejskich-lotnisk-zwieksza-limity-plynow-ktore-turysci-moga-wnosic-na-poklad-8568936.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/ae980f74fe9d2c-948-568-0-110-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podróżni wylatujący z Helsinek mogą od środy znów zabierać na pokład samolotu do 2 litrów płynów - poinformował portal lotniczy Avia News. Takie ułatwienia wprowadziły wcześniej między innymi lotniska w Londynie, Amsterdamie i Mediolanie, a wkrótce dołączą do nich czeski port w Pradze oraz lotniska w Szwecji i Hiszpanii.</p>

## Imponujące tempo robotyzacji przemysłu w Polsce, ale to nie rozwiązanie wszystkich bolączek firm
 - [https://www.bankier.pl/wiadomosc/Imponujace-tempo-robotyzacji-przemyslu-w-Polsce-ale-to-nie-rozwiazanie-wszystkich-bolaczek-firm-8558935.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Imponujace-tempo-robotyzacji-przemyslu-w-Polsce-ale-to-nie-rozwiazanie-wszystkich-bolaczek-firm-8558935.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/c8cdb3730d95b7-948-568-0-20-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Globalne dane IFR wskazują, że rynek robotyki dynamicznie przyspieszył. W 2021 roku liczba nowych instalacji robotów przemysłowych wzrosła o ponad 30 proc., a Polska była jednym z liderów wzrostu - odnotowała...</p>

## Netflix chce przebić "Grę o tron" HBO i "Mandaloriana" Disneya. Tworzy serial z większym budżetem
 - [https://www.bankier.pl/wiadomosc/Netflix-i-nowy-serial-One-Piece-Chce-przebic-HBO-i-Disney-budzetem-8567192.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Netflix-i-nowy-serial-One-Piece-Chce-przebic-HBO-i-Disney-budzetem-8567192.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/b/3aa797f0ba42ad-948-568-9-21-953-572.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Piraci z Karaibów" pokazali, że można zrobić dobry film o mijających się z prawem wilkach morskich i nieźle na tym zarobić. Netflix więc sięga do tej widowni, jednocześnie mrugając okiem ku wielbicieli... mangi. Czy przygody Monkey D. Luffy'ego przypadną obu grupom do gustu? Netflix twierdzi, że muszą, bo na produkcję wydał horrendalne pieniądze. </p>

## Wakacje za granicą to nie zawsze tylko dobra zbawa. W razie wypadku koszty leczenia mogą być ogromne. Jak temu zapobiec?
 - [https://www.bankier.pl/wiadomosc/Wakacje-za-granica-W-razie-wypadku-koszty-leczenia-moga-byc-ogromne-Jak-temu-zapobiec-8567012.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wakacje-za-granica-W-razie-wypadku-koszty-leczenia-moga-byc-ogromne-Jak-temu-zapobiec-8567012.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/a/d656911a91e8d8-948-568-0-161-4612-2767.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polacy intensywnie przygotowują się do sezonu letniego. Mimo wyższych cen wycieczek i biletów lotniczych nie rezygnują z planów wyjazdowych i - co istotne - kupują zawczasu odpowiednie ubezpieczenie....</p>

## Włoska żywność fałszowana na potęgę. Wartość podróbek to 120 mld euro rocznie
 - [https://www.bankier.pl/wiadomosc/Wloska-zywnosc-falszowana-na-potege-Wartosc-podrobek-to-120-mld-euro-rocznie-8567468.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wloska-zywnosc-falszowana-na-potege-Wartosc-podrobek-to-120-mld-euro-rocznie-8567468.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/ee5c0169e7ed11-948-568-0-120-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na 120 miliardów euro rocznie oszacowano wartość fałszowanej co roku na świecie włoskiej żywności. Związek rolników Coldiretti podał, że jedną trzecią podróbek parmezanu, mozzarelli i innych specjałów wyprodukowano w USA. Dwie trzecie produktów sprzedawanych za granicą jako włoskie nie pochodzi z Italii.</p>

## Amerykanie biją rekord podróży w weekend Dnia Niepodległości
 - [https://www.bankier.pl/wiadomosc/Amerykanie-bija-rekord-podrozy-w-weekend-Dnia-Niepodleglosci-8572030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amerykanie-bija-rekord-podrozy-w-weekend-Dnia-Niepodleglosci-8572030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T00:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/3aa5c1288f7341-945-567-27-210-2690-1614.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W długi weekend z okazji Dnia Niepodległości, od piątku 30 czerwca do wtorku 4 lipca, ponad 50 mln Amerykanów wybiera się w podróż przekraczającą 80 km. "Ludzie wciąż mają ochotę wyrwać się z miasta i zrobić coś fajnego" - powiedział rzeczniczka AAA Aixa Diaz. 4 lipca 1776 roku Kongres Kontynentalny uchwalił Deklarację Niepodległości USA.</p>

## Izraelski atak rakietowy na Syrię. "Straty jedynie materialne"
 - [https://www.bankier.pl/wiadomosc/Izraelski-atak-rakietowy-na-Syrie-Straty-jedynie-materialne-8572029.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Izraelski-atak-rakietowy-na-Syrie-Straty-jedynie-materialne-8572029.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-02T00:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/7/1ee530feac819c-945-560-0-129-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obrona powietrzna Syrii odparła w niedzielę nad ranem izraelski atak rakietowy na centralne rejony kraju zestrzeliwując większość pocisków - poinformowały syryjskie media państwowe powołując się na syryjskiego rzecznika wojskowego. Strona izraelska nie potwierdziła tych informacji.</p>

