# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## A video about forced arbitration, sponsored by ZOOM! 😀
 - [https://www.youtube.com/watch?v=Nzt0tzsaWDE](https://www.youtube.com/watch?v=Nzt0tzsaWDE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-07-02T15:51:01+00:00

Zoom: https://explore.zoom.us/en/terms/
Jitsi: https://jitsi.org/meet-jit-si-terms-of-service/

Which would you trust more with your communications?

