# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## W pokoleniu Z dokonała się gwałtowna laicyzacja. "Tąpnięcie"
 - [https://www.wirtualnemedia.pl/artykul/w-pokoleniu-z-dokonala-sie-gwaltowna-laicyzacja-tapniecie](https://www.wirtualnemedia.pl/artykul/w-pokoleniu-z-dokonala-sie-gwaltowna-laicyzacja-tapniecie)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-02T07:05:52.282695+00:00

W Polsce gwałtowną laicyzację widać najmocniej w pokoleniu Z, w którym została przekroczona masa krytyczna. To tąpnięcie dokonało się w okresie ostatnich 5 lat - powiedział socjolog z UW prof. Krzysztof Koseła. Dodał, że na Zachodzie miejsce chrześcijaństwa zajmuje świat okultyzmu, magii i czarów.

## Żabka wprowadzi abonamenty na posiłki
 - [https://www.wirtualnemedia.pl/artykul/zabka-abonamenty-na-posilki-cena-oferta-jakosc](https://www.wirtualnemedia.pl/artykul/zabka-abonamenty-na-posilki-cena-oferta-jakosc)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-02T07:05:52.279804+00:00

Sieć sklepów Żabka pracuje nad nową usługą - subskrypcją posiłków od śniadań, przez obiady po kolacje.

