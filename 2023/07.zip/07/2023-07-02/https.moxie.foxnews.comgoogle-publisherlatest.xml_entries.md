# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Prince William and Prince George spend day father-son bonding at cricket match
 - [https://www.foxnews.com/entertainment/prince-william-prince-george-spend-day-father-son-bonding-cricket-match](https://www.foxnews.com/entertainment/prince-william-prince-george-spend-day-father-son-bonding-cricket-match)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T19:06:22+00:00

Prince William and his eldest son, Prince George, attended a cricket match together over the weekend, sharing some father-son bonding time.

## Glass bottling plants forced to shut down, leaving 600 employees jobless amid Bud Light controversy
 - [https://www.foxnews.com/media/glass-bottling-plants-forced-shut-down-600-employees-jobless-amid-bud-light-controversy](https://www.foxnews.com/media/glass-bottling-plants-forced-shut-down-600-employees-jobless-amid-bud-light-controversy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T18:00:15+00:00

Two glass bottling plants hurt by Bud Light&apos;s controversial promotion with transgender influencer Dylan Mulvaney will close down in July, causing 600 lost jobs.

## Nick Kyrgios withdraws from Wimbledon over wrist injury: 'I'll be back'
 - [https://www.foxnews.com/sports/nick-kyrgios-withdraws-wimbledon-wrist-injury-back](https://www.foxnews.com/sports/nick-kyrgios-withdraws-wimbledon-wrist-injury-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T17:57:51+00:00

Nick Kyrgios announced Sunday he will miss the 2023 Wimbledon tournament due to a torn ligament in his wrist. He lost to Novak Djokovic in last year&apos;s finals.

## Maryland woman killed by stolen forklift, suspect at large: police
 - [https://www.foxnews.com/us/maryland-woman-killed-stolen-forklift-suspect-large-police](https://www.foxnews.com/us/maryland-woman-killed-stolen-forklift-suspect-large-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T17:42:32+00:00

A suspect is on the run after stealing a forklift from a Maryland business early Sunday and killing a woman before stealing her car, authorities said.

## Twins' Carlos Correa unbothered by offseason drama: 'You’ve got to move on and look ahead'
 - [https://www.foxnews.com/sports/twins-carlos-correa-unbothered-offseason-drama-got-move-on-look-ahead](https://www.foxnews.com/sports/twins-carlos-correa-unbothered-offseason-drama-got-move-on-look-ahead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T17:40:48+00:00

Minnesota Twins shortstop Carlos Correa opened up about the failed contract agreements with the San Francisco Giants and New York Mets in the offseason.

## Chinese tourists visiting France hurt in riots, officials say
 - [https://www.foxnews.com/world/chinese-tourists-visiting-france-hurt-riots-officials-say](https://www.foxnews.com/world/chinese-tourists-visiting-france-hurt-riots-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T17:34:49+00:00

Chinese tourists in Marseille were injured Thursday after the windows of the bus they were riding in were smashed during riots that have swept France in recent days.

## 2024 GOP candidates call last week's Supreme Court decisions a win for 'freedom'
 - [https://www.foxnews.com/politics/2024-gop-candidates-say-last-weeks-supreme-court-decisions-win-freedom](https://www.foxnews.com/politics/2024-gop-candidates-say-last-weeks-supreme-court-decisions-win-freedom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T17:28:14+00:00

Multiple Republican presidential candidates expressed support Sunday for the Supreme Court&apos;s decisions last week on free speech, affirmative action and student loans.

## Digital Detox: How to put your phone down this summer
 - [https://www.foxnews.com/tech/digital-detox-how-put-phone-down-summer](https://www.foxnews.com/tech/digital-detox-how-put-phone-down-summer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T17:17:27+00:00

A tech expert gives her tips on how to save your summer, learn how to stay present and digitally detox during the day instead of glued to your smartphone.

## Baltimore mayor calls Sunday's mass shooting 'reckless' and 'cowardly' act of violence
 - [https://www.foxnews.com/us/baltimore-mayor-calls-sundays-mass-shooting-reckless-cowardly-act-violence](https://www.foxnews.com/us/baltimore-mayor-calls-sundays-mass-shooting-reckless-cowardly-act-violence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T17:13:27+00:00

Baltimore, Maryland police chief and mayor urge community to come forward with any information that could lead to arrest of suspects in mass shooting that killed 2 and injured 28.

## Jemele Hill accuses Asians of 'carrying the water for white supremacy' for backing affirmative action decision
 - [https://www.foxnews.com/media/jemele-hill-accuses-asians-carrying-water-white-supremacy-backing-affirmative-actiondcision](https://www.foxnews.com/media/jemele-hill-accuses-asians-carrying-water-white-supremacy-backing-affirmative-actiondcision)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T17:00:04+00:00

The Atlantic writer Jemele Hill accused Asian Americans of “carrying water&quot; for White supremacy by celebrating the Supreme Court decision against affirmative action.

## Biden admin gets burned after considering study to 'block the sun'
 - [https://www.foxnews.com/us/biden-admin-gets-burned-after-considering-study-block-sun](https://www.foxnews.com/us/biden-admin-gets-burned-after-considering-study-block-sun)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T15:54:11+00:00

Twitter users expressed confusion over a released document revealing that the Biden administration is studying how to block sunlight to prevent climate change.

## Max Homa nails hole-in-one at Rocket Mortgage Classic
 - [https://www.foxnews.com/sports/max-homa-nails-hole-in-one-rocket-mortgage-classic](https://www.foxnews.com/sports/max-homa-nails-hole-in-one-rocket-mortgage-classic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T15:52:01+00:00

Max Homa sunk a hole-in-one at the Rocket Mortgage Classic in Detroit Sunday, and he finished with a 67 in the final round. He finished the tournament tied for 21st.

## South Carolina plane crash near golf course leaves at least one dead, others injured
 - [https://www.foxnews.com/us/south-carolina-plane-crash-golf-course-leaves-least-one-dead-others-injured](https://www.foxnews.com/us/south-carolina-plane-crash-golf-course-leaves-least-one-dead-others-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T15:50:38+00:00

At least one person is dead and several others are injured after a single-engine Piper PA-32 crashed in North Myrtle Beach, South Carolina, Sunday morning.

## Buttigieg claims Lorie Smith 'went into wedding business' only to provoke 'case like this' after SCOTUS ruling
 - [https://www.foxnews.com/media/buttigieg-claims-lorie-smith-wedding-business-provoke-case-scotus-ruling](https://www.foxnews.com/media/buttigieg-claims-lorie-smith-wedding-business-provoke-case-scotus-ruling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T15:40:52+00:00

Pete Buttigieg told CNN on Sunday that Lorie Smith, the graphic designer who sued Colorado over their anti-discrimination law, just wanted to provoke &quot;cases like this.&quot;

## ‘The Flash’ star Ezra Miller releases statement regarding lifting of temporary harassment order
 - [https://www.foxnews.com/entertainment/flash-star-ezra-miller-releases-statement-regarding-lifting-temporary-harassment-order](https://www.foxnews.com/entertainment/flash-star-ezra-miller-releases-statement-regarding-lifting-temporary-harassment-order)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T15:40:33+00:00

Ezra Miller released a statement regarding the recent expiration of a temporary harassment order against &quot;The Flash&quot; star. It was filed by a parent on behalf of their 12-year-old child.

## Rickie Fowler captures first PGA Tour win since 2019 at Rocket Mortgage Classic
 - [https://www.foxnews.com/sports/rickie-fowler-captures-first-pga-tour-win-2019-rocket-mortgage-classic](https://www.foxnews.com/sports/rickie-fowler-captures-first-pga-tour-win-2019-rocket-mortgage-classic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T15:36:38+00:00

Rickie Fowler has finally captured his first PGA Tour win since 2019, beating Adam Hadwin and Collin Morikawa in a playoff hole to win the Rocket Mortgage Classic.

## Enough! French police unions condemn 'savage hordes,' forcing Macron into action
 - [https://www.foxnews.com/world/enough-french-police-unions-condemn-savage-hordes-forcing-macron-action](https://www.foxnews.com/world/enough-french-police-unions-condemn-savage-hordes-forcing-macron-action)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T15:25:08+00:00

Defying all odds against overwhelming numbers of rioters, French police officers are curtailing the violence and have compelled the French political establishment to stand behind them.

## Joe Biden takes Hunter to Camp David two weekends in a row amid scandal
 - [https://www.foxnews.com/politics/joe-biden-takes-hunter-camp-david-two-weekends-row-amid-scandal](https://www.foxnews.com/politics/joe-biden-takes-hunter-camp-david-two-weekends-row-amid-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T15:14:55+00:00

President Biden traveled with Hunter Biden to Camp David for the second weekend in a row Friday, just days after the DOJ announced a tentative plea agreement for the first son.

## Former Director of National Intelligence warns there's a 'cultural problem' within the DOJ
 - [https://www.foxnews.com/media/former-director-national-intelligence-warns-cultural-problem-within-doj](https://www.foxnews.com/media/former-director-national-intelligence-warns-cultural-problem-within-doj)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T15:06:54+00:00

Former Director of National Intelligence John Ratcliffe discusses the latest on the &quot;disparity in treatment&quot; by the Department of Justice.

## Tom Brady sticks to strict diet regimen even after retirement
 - [https://www.foxnews.com/sports/tom-brady-sticks-strict-diet-regimen-even-retirement](https://www.foxnews.com/sports/tom-brady-sticks-strict-diet-regimen-even-retirement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T14:52:22+00:00

Tom Brady revealed in a recent interview he is sticking to the strict diet that helped him stay healthy through most of his career. He retired in February.

## Human remains found in barrel floating on South Carolina lake: police
 - [https://www.foxnews.com/us/human-remains-found-barrel-floating-south-carolina-lake-police](https://www.foxnews.com/us/human-remains-found-barrel-floating-south-carolina-lake-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T14:49:02+00:00

South Carolina man Eric Fetzer was arrested after human remains were found in a barrel floating on Lake Thicketty in upstate South Carolina, police said.

## Should I leave my VPN on 24/7?
 - [https://www.foxnews.com/tech/should-leave-vpn-24/7](https://www.foxnews.com/tech/should-leave-vpn-24/7)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T14:45:03+00:00

VPNs can be a great service to protecting your private info when traveling or using public Wi-Fi. Kurt &quot;Cyberguy&quot; Knutsson lays his out his best practices.

## South Korea draws hard line on North Korean aid, no longer a 'support department' for dictatorship
 - [https://www.foxnews.com/world/south-korea-draws-hard-line-north-korean-aid-no-longer-support-department-dictatorship](https://www.foxnews.com/world/south-korea-draws-hard-line-north-korean-aid-no-longer-support-department-dictatorship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T14:27:04+00:00

South Korea ordered its Unification Ministry to shift its directives away from &quot;support&quot; for North Korea toward combatting its human rights abuses.

## US Army soldiers deployed to Middle East save mama dog and 8 newborn pups
 - [https://www.foxnews.com/lifestyle/us-army-soldiers-deployed-middle-east-save-mama-dog-8-newborn-pups](https://www.foxnews.com/lifestyle/us-army-soldiers-deployed-middle-east-save-mama-dog-8-newborn-pups)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T14:19:47+00:00

U.S. Army soldiers are caring for a mama dog and her eight pups who were saved from a rare ice storm in the Middle East. Nonprofit Paws of War is working to bring the dogs to America.

## Syria claims to shoot down Israeli missile strike as anti-aircraft debris lands in Israeli town
 - [https://www.foxnews.com/world/syria-claims-shoot-israeli-missile-strike-anti-aircraft-debris-lands-israeli-town](https://www.foxnews.com/world/syria-claims-shoot-israeli-missile-strike-anti-aircraft-debris-lands-israeli-town)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T14:17:35+00:00

Syria claims to have shot down Israeli missiles targeting air defense batteries near the city of Hom, with Israel saying no warplanes were damaged.

## NASCAR contractor dies of electrocution setting up Chicago Street Race
 - [https://www.foxnews.com/sports/nascar-contractor-dies-electrocution-setting-up-chicago-street-race](https://www.foxnews.com/sports/nascar-contractor-dies-electrocution-setting-up-chicago-street-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T14:08:18+00:00

A 53-year-old man who was hired as a contractor to set up audio equipment for the NASCAR Cup Series&apos; Chicago Street Race on Sunday, has died after being electrocuted.

## Ukrainian officials report drone strikes shot down over Kyiv
 - [https://www.foxnews.com/world/ukrainian-officials-report-drone-strikes-shot-down-over-kyiv](https://www.foxnews.com/world/ukrainian-officials-report-drone-strikes-shot-down-over-kyiv)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T14:08:07+00:00

Officials in Kyiv, Ukraine, reported a wave of drone strikes against the city late Saturday into Sunday that were intercepted and failed to hit the city.

## Mets' Luke Voit rocks sleeveless jersey in minors to fans' delight
 - [https://www.foxnews.com/sports/mets-luke-voit-rocks-sleeveless-jersey-minors-fans-delight](https://www.foxnews.com/sports/mets-luke-voit-rocks-sleeveless-jersey-minors-fans-delight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T14:00:37+00:00

Luke Voit has been known to rock his jerseys with the buttons undone, but thanks to the Syracuse Mets&apos; sleeveless look, he took it to a different level in his recent minor league game.

## Obama's AG weighs in on whether Biden should pardon Trump
 - [https://www.foxnews.com/politics/obamas-ag-weighs-whether-biden-should-pardon-trump](https://www.foxnews.com/politics/obamas-ag-weighs-whether-biden-should-pardon-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T13:53:33+00:00

Former Attorney General Eric Holder joined CBS News&apos; &quot;Face the Nation&quot; and discussed if President Biden or the 2024 White House winner should potentially pardon Donald Trump.

## Biden to meet with King Charles and UK PM Rishi Sunak ahead of NATO summit, White House announces
 - [https://www.foxnews.com/politics/biden-meet-king-charles-uk-pm-rishi-sunak-ahead-nato-summit-white-house-announces](https://www.foxnews.com/politics/biden-meet-king-charles-uk-pm-rishi-sunak-ahead-nato-summit-white-house-announces)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T13:44:29+00:00

President Biden is scheduled to meet with King Charles and U.K. Prime Minister Rishi Sunak to &quot;further strengthen&quot; the countries&apos; relationship before attending the NATO summit.

## New laws: Here are some of the most impactful bills that took effect across the US on July 1
 - [https://www.foxnews.com/politics/here-all-major-laws-took-effect-us-july-1](https://www.foxnews.com/politics/here-all-major-laws-took-effect-us-july-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T13:33:54+00:00

From limits on abortion and transgender services to sealing criminal records in California, several major pieces of legislation went into effect on July 1.

## ABC host presses Dem rep on student loan ruling: SCOTUS 'quoted' Nancy Pelosi
 - [https://www.foxnews.com/media/abc-host-presses-dem-rep-student-loan-ruling-scotus-quoted-nancy-pelosi](https://www.foxnews.com/media/abc-host-presses-dem-rep-student-loan-ruling-scotus-quoted-nancy-pelosi)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T13:32:46+00:00

ABC&apos;s Jonathan Karl referenced Nancy Pelosi&apos;s position on student loans while pressing Rep. Ro Khanna on the Supreme Court&apos;s decision to strike down Biden&apos;s plans.

## New York cop allegedly sent herself menacing texts, then blamed colleagues: prosecutor
 - [https://www.foxnews.com/us/new-york-cop-allegedly-sent-herself-menacing-texts-then-blamed-colleagues-prosecutor](https://www.foxnews.com/us/new-york-cop-allegedly-sent-herself-menacing-texts-then-blamed-colleagues-prosecutor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T13:20:10+00:00

Ossining, New York, police officer Emily Hirshowitz was arrested on criminal charges after allegedly sending herself menacing texts she said were from colleagues.

## Comedian Gabriel Iglesias' private jet makes emergency landing: ‘Happy to be alive’
 - [https://www.foxnews.com/entertainment/comedian-gabriel-iglesias-private-jet-makes-emergency-landing-happy-alive](https://www.foxnews.com/entertainment/comedian-gabriel-iglesias-private-jet-makes-emergency-landing-happy-alive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T13:07:37+00:00

Gabriel Iglesias revealed on his social media that a private jet he was on had to make an emergency landing in North Carolina and skidded off the runway.

## Charles Barkley amends will to donate millions to Auburn following Supreme Court's affirmative action ruling
 - [https://www.foxnews.com/sports/charles-barkley-amends-will-donate-millions-auburn-following-supreme-courts-affirmative-action-ruling](https://www.foxnews.com/sports/charles-barkley-amends-will-donate-millions-auburn-following-supreme-courts-affirmative-action-ruling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T12:44:48+00:00

Following the Supreme Court&apos;s ruling to outlaw affirmative action in college admissions, NBA legend Charles Barkley amended his will to leave money to his alma mater.

## AOC proposes subpoenas and impeachment to limit SCOTUS justices’ power following landmark decisions
 - [https://www.foxnews.com/politics/aoc-proposes-subpoenas-impeachment-limit-scotus-justices-power-following-landmark-decisions](https://www.foxnews.com/politics/aoc-proposes-subpoenas-impeachment-limit-scotus-justices-power-following-landmark-decisions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T12:36:59+00:00

Rep. Alexandria Ocasio-Cortez reacted to the Supreme Court&apos;s landmark decisions this past week, proposing impeachment, subpoeanas and investigations to limit the justices&apos; power.

## Trevor Bauer freaks out on Japanese teammates after pickle play leads to bases-loaded blunder
 - [https://www.foxnews.com/sports/trevor-bauer-freaks-out-japanese-teammates-pickle-play-leads-bases-loaded-blunder](https://www.foxnews.com/sports/trevor-bauer-freaks-out-japanese-teammates-pickle-play-leads-bases-loaded-blunder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T12:17:44+00:00

Trevor Bauer, pitching for the Yokohama DeNA Baystars, was enraged after watching a pickle play go awry and his teammates failed to record an out.

## Biden slammed after report reveals number of grandchildren his aides instructed to say publicly: 'Monster'
 - [https://www.foxnews.com/politics/biden-slammed-report-reveals-grandchildren-aides-instructed-say-monsters](https://www.foxnews.com/politics/biden-slammed-report-reveals-grandchildren-aides-instructed-say-monsters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T12:07:17+00:00

White House aides have been told in strategy meetings that President Biden and the first lady only have six grandchildren, not seven, according to a new report.

## Nikki Haley sounds the alarm on China's military growth, blasts Pentagon for 'gender pronoun classes'
 - [https://www.foxnews.com/politics/nikki-haley-sounds-the-alarm-chinas-military-growth-blasts-pentagon-gender-pronoun-classes](https://www.foxnews.com/politics/nikki-haley-sounds-the-alarm-chinas-military-growth-blasts-pentagon-gender-pronoun-classes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T11:54:00+00:00

Republican presidential candidate Nikki Haley is warning that the U.S. needs to take China&apos;s military threat seriously as they are &quot;preparing for war.&quot;

## One of largest Christian churches in US departs Southern Baptists following vote to ban women from pulpit
 - [https://www.foxnews.com/us/one-largest-christian-churches-us-departs-southern-baptists-following-vote-ban-women-pulpit](https://www.foxnews.com/us/one-largest-christian-churches-us-departs-southern-baptists-following-vote-ban-women-pulpit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T11:42:37+00:00

The North Carolina-based Elevation Church disaffiliated from the Southern Baptist Convention last week after the denomination banned women from teaching.

## Fourth of July weekend sky to boast 'full buck moon,' first supermoon of 2023
 - [https://www.foxnews.com/science/fourth-july-weekend-sky-boast-full-buck-moon-first-supermoon-2023](https://www.foxnews.com/science/fourth-july-weekend-sky-boast-full-buck-moon-first-supermoon-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T11:34:06+00:00

The sky during the Fourth of July weekend is scheduled to boast the first supermoon of 2023, also known as the full buck moon, according to NASA.

## Communist China survivor warns Americans affirmative action mimics Maoist system: 'No strangers' to it
 - [https://www.foxnews.com/media/communist-china-survivor-americans-affirmative-action-maoist-system](https://www.foxnews.com/media/communist-china-survivor-americans-affirmative-action-maoist-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T11:30:17+00:00

Xi Van Fleet, a Virginia mom who fled communist China, drew parallels between affirmative action and practices from Mao Zedong&apos;s revolution.

## Shaquil Barrett's wife, Jordanna, reveals family expecting baby girl months after 2-year-old's tragic death
 - [https://www.foxnews.com/sports/shaquil-barretts-wife-jordanna-reveals-family-expecting-baby-girl-months-after-2-year-olds-tragic-death](https://www.foxnews.com/sports/shaquil-barretts-wife-jordanna-reveals-family-expecting-baby-girl-months-after-2-year-olds-tragic-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T11:25:26+00:00

Tampa Bay Buccaneers star linebacker Shaquil Barrett&apos;s wife, Jordanna, revealed she is expecting another baby girl months after their 2-year-old, Arrayah, tragically drowned.

## Adopted girl accused of 'masquerading' as 6-year-old spotted with new dad selling fireworks on parking lot
 - [https://www.foxnews.com/us/adopted-girl-accused-masquerading-6-year-old-spotted-new-dad-selling-fireworks-parking-lot](https://www.foxnews.com/us/adopted-girl-accused-masquerading-6-year-old-spotted-new-dad-selling-fireworks-parking-lot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T11:14:20+00:00

Adopted girl Natalia Grace, who was accused by her former family of pretending to be a child while allegedly a grown woman, was spotted selling fireworks with new family.

## Live snake found in bag of broccoli: 'Pretty frightening,' says grandfather
 - [https://www.foxnews.com/lifestyle/live-snake-found-bag-broccoli-pretty-frightening-says-grandfather](https://www.foxnews.com/lifestyle/live-snake-found-bag-broccoli-pretty-frightening-says-grandfather)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T11:05:35+00:00

A man opened a bag of broccoli in his kitchen — and found a live snake inside, tucked between the stems. He and his family drove it back to the grocery store where he bought it.

## 'Sopranos' actor thanks SCOTUS for 'allowing' him to 'discriminate,' makes announcement about his work
 - [https://www.foxnews.com/media/sopranos-actor-thanks-scotus-allowing-discriminate-makes-announcement-work](https://www.foxnews.com/media/sopranos-actor-thanks-scotus-allowing-discriminate-makes-announcement-work)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T10:29:39+00:00

Michael Imperioli thanked the Supreme Court on Saturday for &quot;allowing&quot; him to discriminate and said he decided to &quot;forbid bigots and homophobes&quot; from watching his work.

## Olivia Dunne reveals biggest check she's ever received from single sponsorship post
 - [https://www.foxnews.com/sports/olivia-dunne-reveals-biggest-check-shes-ever-received-single-sponsorship-post](https://www.foxnews.com/sports/olivia-dunne-reveals-biggest-check-shes-ever-received-single-sponsorship-post)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T10:20:49+00:00

It&apos;s well known that Olivia Dunne has multiple sponsorships as part of various NIL deals as an LSU Tigers gymnast. She revealed the biggest check she&apos;s ever received from one.

## Your ChatGPT account and conversations could be for sale on the dark web
 - [https://www.foxnews.com/tech/chatgpt-account-conversations-sale-dark-web](https://www.foxnews.com/tech/chatgpt-account-conversations-sale-dark-web)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T10:04:04+00:00

Hackers are using malware to steal your ChatGPT conversations and sell them on the dark web. Kurt &quot;CyberGuy&quot; Knutsson explains how this happened.

## Actor Gary Sinese addresses current US military recruiting crisis: Afghanistan withdrawal was 'harmful'
 - [https://www.foxnews.com/media/actor-gary-sinese-us-military-recruiting-crisis-afghanistan-withdrawal-harmful](https://www.foxnews.com/media/actor-gary-sinese-us-military-recruiting-crisis-afghanistan-withdrawal-harmful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T10:00:52+00:00

Humanitarian and actor Gary Sinise alleged the chaotic withdrawal from Afghanistan could be behind low morale and recruiting problems across all military branches.

## The war in corporate America between faithful investing and woke investing
 - [https://www.foxnews.com/opinion/war-corporate-america-between-faithful-investing-woke-investing](https://www.foxnews.com/opinion/war-corporate-america-between-faithful-investing-woke-investing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T10:00:42+00:00

For the first time in decades the growth of ESG investing is slowing, but criticisms of the strategy shouldn&apos;t deter others from their own faith-based investing.

## ‘Indiana Jones’ stars Harrison Ford, Karen Allen, Ke Huy Quan: Where iconic cast is now
 - [https://www.foxnews.com/entertainment/indiana-jones-stars-harrison-ford-karen-allen-ke-huy-quan-iconic-cast-now](https://www.foxnews.com/entertainment/indiana-jones-stars-harrison-ford-karen-allen-ke-huy-quan-iconic-cast-now)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T10:00:25+00:00

&quot;Indiana Jones and the Dial of Destiny&quot; is out now and is star Harrison Ford&apos;s final film of the franchise. Here&apos;s what the original cast members are up to now.

## Mexican government laments DeSantis immigration laws, warns of 'discrimination' and 'racial profiling'
 - [https://www.foxnews.com/world/mexican-government-laments-desantis-immigration-laws-warns-discrimination-racial-profiling](https://www.foxnews.com/world/mexican-government-laments-desantis-immigration-laws-warns-discrimination-racial-profiling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T09:42:10+00:00

The Mexican government released a statement Saturday harshly criticizing Florida Gov. Ron DeSantis&apos;s latest immigration bill, which went into effect Friday.

## Independence Day: Fourth of July facts you may not know
 - [https://www.foxnews.com/politics/declaration-of-independence-facts-you-may-not-know](https://www.foxnews.com/politics/declaration-of-independence-facts-you-may-not-know)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T09:39:35+00:00

Each year, Americans celebrate the Fourth of July. The occasion is in honor of the adoption of the Declaration of Independence by Congress.

## World's largest croc still growing as it hits stunning age milestone: experts
 - [https://www.foxnews.com/world/worlds-largest-croc-still-growing-stunning-age-milestone-experts](https://www.foxnews.com/world/worlds-largest-croc-still-growing-stunning-age-milestone-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T09:27:12+00:00

Cassius was captured near the city of Darwin in 1984 and three years later transferred to the Green Island croc park, where he&apos;s remained happy and healthy for decades.

## Surprise letter written by Abraham Lincoln during Civil War is recovered for first time, up for sale
 - [https://www.foxnews.com/lifestyle/surprise-letter-written-abraham-lincoln-civil-war-recovered-first-time-sale](https://www.foxnews.com/lifestyle/surprise-letter-written-abraham-lincoln-civil-war-recovered-first-time-sale)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T09:19:00+00:00

A previously unknown and unpublished Civil War-era letter from President Abraham Lincoln has been acquired by the Raab Collection — and is being sold for $85,000. Here are details.

## France protests show first signs of subsiding after tens of thousands of police confront 5th night of violence
 - [https://www.foxnews.com/world/france-protests-show-first-signs-subsiding-tens-thousands-police-confront-5th-night-violence](https://www.foxnews.com/world/france-protests-show-first-signs-subsiding-tens-thousands-police-confront-5th-night-violence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T08:33:28+00:00

Violent protests continued in France, as thousands of police officials worked to contain demonstrations that finally began to subside after nearly a week.

## Hollywood fairy tales: Tom Hanks and Rita Wilson, Michael J Fox and Tracy Pollan have decades-long marriages
 - [https://www.foxnews.com/entertainment/hollywood-fairytales-tom-hanks-rita-wilson-michael-j-fox-tracy-pollan-embrace-decades-long-marriages](https://www.foxnews.com/entertainment/hollywood-fairytales-tom-hanks-rita-wilson-michael-j-fox-tracy-pollan-embrace-decades-long-marriages)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T08:30:46+00:00

Hollywood&apos;s biggest couples, from Tom Hanks and Rita Wilson to Michael J. Fox and Tracy Pollan, are celebrating big milestone anniversaries in 2023.

## Religion can survive culture wars but here's what the faith community must do
 - [https://www.foxnews.com/opinion/religion-survive-culture-wars-heres-faith-community-must-do](https://www.foxnews.com/opinion/religion-survive-culture-wars-heres-faith-community-must-do)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T08:00:54+00:00

Some argue that according religion any recognition is nothing short of an unconstitutional establishment or discrimination against the non-religious.

## Human rights advocates raise alarm over persecution of Indian Christians amid Modi's US visit
 - [https://www.foxnews.com/world/human-rights-advocates-raise-alarm-persecution-indian-christians-modis-us-visit](https://www.foxnews.com/world/human-rights-advocates-raise-alarm-persecution-indian-christians-modis-us-visit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T08:00:07+00:00

Human rights advocates are raising the alarm about the rising persecution of Christians in India amid Indian Prime Minister Narendra Modi&apos;s recent visit to the United States.

## NYC Mayor Adams roasted for 'mindful breathing' mandate amid poor learning scores, crime: 'Pet project'
 - [https://www.foxnews.com/media/nyc-mayor-adams-roasted-mindful-breathing-mandate-poor-learning-scores-crime-pet-project](https://www.foxnews.com/media/nyc-mayor-adams-roasted-mindful-breathing-mandate-poor-learning-scores-crime-pet-project)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T08:00:06+00:00

New York City Mayor Eric Adams announced a new requirement for the city&apos;s schools: carrying out &apos;mindful breathing&apos; exercises to help students cope with stress.

## Youngest Titanic wreck voyager recounts frightening dive experience: 'Fell unconscious'
 - [https://www.foxnews.com/media/youngest-titanic-wreck-voyager-recounts-frightening-dive-experience](https://www.foxnews.com/media/youngest-titanic-wreck-voyager-recounts-frightening-dive-experience)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T07:00:05+00:00

Sebastian Harris, then 13, was the youngest explorer to travel to the shipwreck of the RMS Titanic, which sank after hitting an iceberg late in the evening on April 14, 1912.

## God has 'extraordinary and omnipotent mercy' toward penitent sinners, Minnesota priest says
 - [https://www.foxnews.com/lifestyle/god-extraordinary-omnipotent-mercy-penitent-sinners-minnesota-priest](https://www.foxnews.com/lifestyle/god-extraordinary-omnipotent-mercy-penitent-sinners-minnesota-priest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T06:30:40+00:00

Fr. Andrew Jaspers, a priest in the Archdiocese of St. Paul and Minneapolis, shared with Fox News Digital a story about God&apos;s mercy during the COVID pandemic.

## Investigation finds college professor subjected his entire class to sexual harassment over 'shameful' exercise
 - [https://www.foxnews.com/media/investigation-finds-college-professor-subjected-entire-class-sexual-harassment-shameful-exercise](https://www.foxnews.com/media/investigation-finds-college-professor-subjected-entire-class-sexual-harassment-shameful-exercise)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T06:00:30+00:00

The U.S. Department of Education&apos;s Office for Civil Rights concluded an investigation involving a professor requiring female students to take off their shirts in class.

## Texas sends another migrant bus to Los Angeles church ahead of July 4th
 - [https://www.foxnews.com/us/texas-sends-another-migrant-bus-los-angeles-church-ahead-july-4th](https://www.foxnews.com/us/texas-sends-another-migrant-bus-los-angeles-church-ahead-july-4th)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T05:10:43+00:00

A second bus carrying migrants from Texas arrived at a church in Los Angeles on Saturday. The first bus arrived at the same church less than three weeks ago.

## Shooting in Baltimore leaves dozens wounded, multiple dead: reports
 - [https://www.foxnews.com/us/shooting-baltimore-leaves-dozens-wounded-multiple-dead-reports](https://www.foxnews.com/us/shooting-baltimore-leaves-dozens-wounded-multiple-dead-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T03:14:36+00:00

Dozens of people were shot, including four who were killed, during a gathering in the Brooklyn Homes section of Baltimore, Maryland, early Sunday morning.

## Maryland law allowing recreational marijuana takes effect
 - [https://www.foxnews.com/politics/maryland-law-allowing-recreational-marijuana-takes-effect](https://www.foxnews.com/politics/maryland-law-allowing-recreational-marijuana-takes-effect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T02:15:20+00:00

Recreational marijuana use in Maryland became legal for adults on Saturday after Governor Wes Moore signed the Cannabis Reform Act into law in May.

## On this day in history, July 2, 1964, President Johnson signs 'sweeping' Civil Rights Act
 - [https://www.foxnews.com/lifestyle/this-day-history-july-2-1964-president-johnson-signs-sweeping-civil-rights-act](https://www.foxnews.com/lifestyle/this-day-history-july-2-1964-president-johnson-signs-sweeping-civil-rights-act)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T00:02:13+00:00

The Civil Rights Act of 1964 was signed into law on this day in history, July 2, 1964, by President Lyndon B. Johnson. It forbade discrimination in public spaces, among other steps.

## Cheeseburger salad? Try this healthy take on the classic meal
 - [https://www.foxnews.com/lifestyle/cheeseburger-salad-try-healthy-take-classic-meal](https://www.foxnews.com/lifestyle/cheeseburger-salad-try-healthy-take-classic-meal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-02T00:00:19+00:00

Have you ever wanted a juicy cheeseburger but opted for a salad instead? Try this yummy alternative — a cheeseburger salad. This recipe is simple and enjoyable for summer and beyond.

