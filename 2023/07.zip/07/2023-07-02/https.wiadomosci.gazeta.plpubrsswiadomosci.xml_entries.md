# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Niecodzienne znalezisko pod Kijowem. Odkryto szczątki brytyjskich samolotów z II wojny światowej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932562,niecodzienne-znalezisko-pod-kijowem-odkryto-szczatki-brytyjskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932562,niecodzienne-znalezisko-pod-kijowem-odkryto-szczatki-brytyjskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T20:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/8b/1c/z29932576M,Pod-Kijowem-odkryto-szczatki-brytyjskich-samolotow.jpg" vspace="2" />W lesie pod Kijowem znalezione zostały szczątki ośmiu brytyjskich myśliwców Hurricane - podaje BBC. Maszyny te pochodzą z czasów II wojny światowej.

## Burza po słowach Tuska dot. migrantów. "Politycznie to jest strzał kulą w płot"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29932358,burza-po-slowach-tuska-dot-migrantow-politycznie-to-jest.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29932358,burza-po-slowach-tuska-dot-migrantow-politycznie-to-jest.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T19:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/60/8b/1c/z29932384M,Donald-Tusk.jpg" vspace="2" />"Platforma Obywatelska to partia bez żadnego kręgosłupa moralnego - ksenofobia jest dla nich jak widać ok, jeśli służy do walki politycznej" - stwierdził aktywista Jan Mencwel, odnosząc się do nagrania nt. migracji, które w niedziele opublikował Donald Tusk. "Politycznie to jest strzał kulą w płot. PO nigdy nie przelicytuje PiS-u na ksenofobię i nacjonalizm" - podkreślił z kolei Łukasz Rogojsz, dziennikarz Interii.

## Posłanka Lewicy o słowach Tuska nt. migracji: Moglibyśmy tam wstawić Mentzena i byłby przekaz Konfederacji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29932299,poslanka-lewicy-o-slowach-tuska-nt-migracji-moglibysmy-tam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29932299,poslanka-lewicy-o-slowach-tuska-nt-migracji-moglibysmy-tam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T18:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/76/58/1c/z29722998M,Joanna-Scheuring-Wielgus.jpg" vspace="2" />- Uważam, że te wypowiedzi w tym filmiku są rasistowskie. Jestem naprawdę zszokowana tą retoryką - powiedziała Joanna Scheuring-Wielgus, pytana o nagranie, na którym Donald Tusk mówi o polityce migracyjnej rządu PiS. - Moglibyśmy tam wstawić Mentzena, Bosaka, być może pana Tyszkę i to byłby przekaz Konfederacji - stwierdziła posłanka Lewicy.

## Małopolska. Auto wjechało w motocykle. Nie żyje emerytowana policjantka, jej 9-letni syn walczy o życie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29932282,malopolska-auto-wjechalo-w-motocykle-nie-zyje-emerytowana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29932282,malopolska-auto-wjechalo-w-motocykle-nie-zyje-emerytowana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T16:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/60/1c/z29756871M,Smiertelny-wypadek---zdjecie-ilustracyjne.jpg" vspace="2" />W powiecie limanowskim doszło do tragicznego wypadku. Samochód osobowy zderzył się z dwoma motocyklami. Zginęła kierująca jednym z nich 51-letnia emerytowana policjantka. Dziewięcioletni syn kobiety został przetransportowany do szpitala. Jego stan jest bardzo ciężki.

## Tragedia na promie. "Partner zauważył kartkę papieru w wodzie. Od razu zapytał mnie, czy to może list"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932228,tragedia-na-promie-partner-zauwazyl-kartke-papieru-w-wodzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932228,tragedia-na-promie-partner-zauwazyl-kartke-papieru-w-wodzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T16:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a1/8a/1c/z29926817M.jpg" vspace="2" />- Ona siedziała na ławce przy ścianie, w cieniu, tylko stopy dziecka były w słońcu. Chłopiec się nie ruszał, był w pozycji półleżącej, może spał, nie wiem - powiedziała w rozmowie z "Faktem" kobieta, która płynęła promem razem z 36-latką i jej synem.

## 14 rzeczy z ostatnich 50 lat historii Polski, które zna każda wykształcona osoba
 - [https://wiadomosci.gazeta.pl/wiadomosci/13,129662,12303,14-rzeczy-z-ostatnich-50-lat-historii-polski-ktore-zna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/13,129662,12303,14-rzeczy-z-ostatnich-50-lat-historii-polski-ktore-zna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T16:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6e/a4/16/z23741038M,Jan-Pawel-II.jpg" vspace="2" />.

## Za kilka dni Joe Biden przyleci do Europy. Prezydent USA odwiedzi trzy państwa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932189,za-kilka-dni-joe-biden-przyleci-do-europy-prezydent-usa-odwiedzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932189,za-kilka-dni-joe-biden-przyleci-do-europy-prezydent-usa-odwiedzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T15:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a6/8b/1c/z29932198M,Joe-Biden.jpg" vspace="2" />Biały Dom poinformował o zbliżającej się wizycie Joe Bidena w Europie. Prezydent USA weźmie udział w szczycie NATO na Litwie, a także odwiedzi dwa inne państwa.

## Zamieszki we Francji. Babcia zabitego przez policję 17-latka apeluje o spokój. "Przestańcie!"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932201,zamieszki-we-francji-babcia-zabitego-przez-policje-17-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932201,zamieszki-we-francji-babcia-zabitego-przez-policje-17-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T15:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/70/8a/1c/z29928048M,Francja--zdjecie-ilustracyjne-.jpg" vspace="2" />Nadia, babcia 17-latka zabitego podczas kontroli policyjnej w Nanterre - zaapelowała do uczestników rozruchów o spokój. Podkreśliła, że chce, aby rozruchy zakończyły się we wszystkich miastach, a sytuacja na ulicach uspokoiła się.

## Awantura w TVN z ministrem z PiS w roli głównej. "To jest ostatnie ostrzeżenie. Wyłączę panu mikrofon"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29932047,awantura-w-tvn-z-ministrem-z-pis-w-roli-glownej-to-jest-ostatnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29932047,awantura-w-tvn-z-ministrem-z-pis-w-roli-glownej-to-jest-ostatnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T15:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6a/8b/1c/z29932138M,Awantura-w-TVN24.jpg" vspace="2" />- To jest ostatnie ostrzeżenie. Wyłączę panu mikrofon - powiedział Konrad Piasecki do Błażeja Pobożego na antenie TVN24. Wiceszef MSWiA wielokrotnie przerywał bowiem innym politykom, którzy brali udział w dyskusji nt. migracji. - Nie może pan przerywać wszystkim łącznie z prowadzącym, bo fatalne świadectwo to wystawia pana kulturze osobistej i pańskiej formacji politycznej - podkreślił dziennikarz.

## Szwajcaria. Sześć osób aresztowanych po zamieszkach w Lozannie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932160,szwajcaria-szesc-osob-aresztowanych-po-zamieszkach-w-lozannie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29932160,szwajcaria-szesc-osob-aresztowanych-po-zamieszkach-w-lozannie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T15:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9a/8b/1c/z29932186M,Lozanna--zdjecie-ilustracyjne-.jpg" vspace="2" />Sześciu nastolatków i jedną osobę dorosłą zatrzymała szwajcarska policja po zamieszkach, do których doszło w Lozannie. W trakcie rozruchów, inspirowanych protestami we Francji, grupa kilkudziesięciu młodych ludzi demolowała i okradała sklepy w centrum miasta.

## Wypadek samochodowy z udziałem radiowozu w Giżycku. Nie żyje 25-latek
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29932102,wypadek-samochodowy-z-udzialem-radiowozu-w-gizycku-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29932102,wypadek-samochodowy-z-udzialem-radiowozu-w-gizycku-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T14:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/82/8a/1c/z29925506M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />W Giżycku 25-letni mężczyzna zjechał na przeciwny pas ruchu i uderzył w oznakowany radiowóz. Zginął na miejscu. Śledczy wyjaśniają okoliczności wypadku.

## Awantura w TVP Info. "Pani coś sugeruje? To brzmi jak groźby"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931981,awantura-w-tvp-info-pani-cos-sugeruje-to-brzmi-jak-grozby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931981,awantura-w-tvp-info-pani-cos-sugeruje-to-brzmi-jak-grozby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T14:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/74/8b/1c/z29932148M,Poslanka-Karolina-Pawliczak.jpg" vspace="2" />W programie publicystycznym na antenie TVP Info doszło do ostrej wymiany zdań. Prowadzący Adrian Klarenbach kilkukrotnie nawiązywał do "politycznych barw" posłanki Karoliny Pawliczak. - Jest pan dziś wyjątkowo złośliwy. Ja pana nie pytam, gdzie pan pójdzie po przegranych wyborach PiS-u - skomentowała. Na tym się jednak nie skończyło.

## Zenek Martyniuk obrzucony jajkami. "I co, mamy tego pana? Zapraszam chojraka na scenę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29932011,zenek-martyniuk-obrzucony-jajkami-i-co-mamy-tego-pana-zapraszam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29932011,zenek-martyniuk-obrzucony-jajkami-i-co-mamy-tego-pana-zapraszam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T14:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bf/fb/1b/z29343423M,Zenek-Martyniuk.jpg" vspace="2" />Podczas koncertu Zenona Martyniuka we Włodawie doszło do nieprzyjemnego incydentu. - Jeszcze nigdy wcześniej nie spotkałem się z takim czymś, a zagrałem chyba kilkanaście tysięcy koncertów - skomentował lider zespołu Akcent, który został obrzucony jajkami.

## Kaczyński tworzy korpus ochrony wyborów. "To muszą być dziesiątki tysięcy ludzi"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29932006,kaczynski-tworzy-korpus-ochrony-wyborow-to-musza-byc-dziesiatki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29932006,kaczynski-tworzy-korpus-ochrony-wyborow-to-musza-byc-dziesiatki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T13:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0a/8b/1c/z29931786M,Jaroslaw-Kaczynski-na-spotkaniu-Klubow--Gazety-Pol.jpg" vspace="2" />Prawo i Sprawiedliwość chce zaangażować w monitoring wyborczy dziesiątki tysięcy osób. O takiej liczebności "korpusu ochrony wyborów" mówił w Spale szef PiS i wicepremier Jarosław Kaczyński. Polityk wziął udział w Zjeździe Klubów "Gazety Polskiej".

## Abp Polak kategorycznie o komisji ds. pedofilii. "Być może owocem będzie odzyskanie wiarygodności"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931708,abp-polak-kategorycznie-o-komisji-ds-pedofilii-byc-moze-owocem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931708,abp-polak-kategorycznie-o-komisji-ds-pedofilii-byc-moze-owocem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T13:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f6/66/19/z26634230M,Arcybiskup-Wojciech-Polak.jpg" vspace="2" />- Komisja badająca pedofilię w Kościele będzie niezależna. Musimy działać razem i przebadać trudną dla Kościoła przeszłość - zapewnił abp Wojciech Polak w wywiadzie dla "Rzeczpospolitej". Hierarcha zaznaczył, że ofiar nie interesuje, kto je skrzywdził - ksiądz, zakonnica czy zakonnik. - Ważne, że zrobił to przedstawiciel Kościoła - dodał.

## Tragedia pod Białą Podlaską. Wnuczek miał zaatakować dziadków nożem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29931831,tragedia-pod-biala-podlaska-wnuczek-mial-zaatakowac-dziadkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29931831,tragedia-pod-biala-podlaska-wnuczek-mial-zaatakowac-dziadkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T13:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a7/8b/1c/z29931943M,Smiglowiec-Lotniczego-Pogotowia-Ratunkowego--zdjec.jpg" vspace="2" />W piątek w Dubowie (woj. lubelskie) znaleziono ciało starszego mężczyzny z ranami kłutymi. Jego żona z obrażeniami trafiła do szpitala. Z ustaleń policji i prokuratury wynika, że ataku miał się dopuścić wnuczek małżeństwa.

## Morawiecki znów atakuje media: TVN jak Czarnobyl w 1986 roku. "Jedyne słuszne porównanie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29931864,morawiecki-znow-atakuje-media-tvn-jak-czarnobyl-w-1986-roku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29931864,morawiecki-znow-atakuje-media-tvn-jak-czarnobyl-w-1986-roku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T13:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ac/8b/1c/z29931948M,Mateusz-Morawiecki.jpg" vspace="2" />Mateusz Morawiecki przekonywał, że TVN nie pokazuje wydarzeń z Francji, tak jak Telewizja Polska w 1986 roku nie informowała o awarii elektrowni w Czarnobylu. - Porównanie do PZPR-owskiej telewizji z czasów Czarnobyla jest jedynym słusznym porównaniem - mówił. Stworzył też inne porównanie - "grupy Webera", czyli szefa Europejskiej Partii Ludowej i Donalda Tuska do Grupy Wagnera.

## Nowe nagranie z promu. Dziennikarze o tym, co działo się tuż przed tragedią na Bałtyku
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931758,nowe-nagranie-z-promu-dziennikarze-o-tym-co-dzialo-sie-tuz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931758,nowe-nagranie-z-promu-dziennikarze-o-tym-co-dzialo-sie-tuz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T12:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f5/63/1c/z29767669M,Morze-Baltyckie--zdjecie-ilustracyjne-.jpg" vspace="2" />Polska i szwedzka prokuratura prowadzi śledztwo w sprawie śmierci 36-letniej kobiety i jej syna na promie. Kamery monitoringu zarejestrowały chwile przed tragedią.

## Kaczyński apeluje, by "gryźć trawę". Deklaruje: Jesteśmy władzą nieuwikłaną w całe to złodziejstwo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29931705,kaczynski-apeluje-by-gryzc-trawe-deklaruje-jestesmy-wladza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29931705,kaczynski-apeluje-by-gryzc-trawe-deklaruje-jestesmy-wladza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T12:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/09/8b/1c/z29931785M,Jaroslaw-Kaczynski-na-spotkaniu-Klubow--Gazety-Pol.jpg" vspace="2" />Wicepremier, prezes PiS Jarosław Kaczyński mówił na spotkaniu z klubami Gazety Polskiej w Spale, że kampania prowadzona przez przeciwników politycznych opiera się na kłamstwie. Stwierdził również, że rząd PiS odnosi sukcesy, bo "jest władzą nieuwikłaną w całe to wielkie złodziejstwo".

## Tusk straszy Kaczyńskim, który straszy imigrantami. Nagranie zirytowało i prawicę, i lewicę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29931453,tusk-straszy-kaczynskim-ktory-straszy-imigrantami-nowe-nagranie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29931453,tusk-straszy-kaczynskim-ktory-straszy-imigrantami-nowe-nagranie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T11:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b5/8b/1c/z29931701M,Tusk-straszy-Kaczynskim--ktory-straszy-imigrantami.jpg" vspace="2" />Arabia Saudyjska, Indie, Iran, Pakistan - między innymi z tych państw rząd PiS-u ma "ściągnąć" do Polski imigrantów. Mówi o tym w krótkim filmiku Donald Tusk i stwierdza, że Jarosław Kaczyński - jednocześnie strasząc migracją - chce doprowadzić do "wewnętrznej wojny". Słowa szefa Platformy Obywatelskiej wprawiły w zdumienie polityków zarówno prawicy, jak i lewicy.

## Matka 27-letniej Anastazji krytykuje grecką policję. "Zmarnowali cenny czas". Mówi o wspólnikach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931448,matka-27-letniej-anastazji-krytykuje-grecka-policje-zmarnowali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931448,matka-27-letniej-anastazji-krytykuje-grecka-policje-zmarnowali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T11:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/16/85/1c/z29906966M,Zamordowana-Anastazja.jpg" vspace="2" />Mama 27-letniej Anastazji krytykowała grecką policję. Zarzuciła im brak zaangażowania. - Wszystko, czego teraz chcę, to znaleźć tych, którzy skrzywdzili moją córkę - dodała.

## Kadyrow w złym stanie? Wpis syna podsyca podejrzenia. "Niech Wszechmogący cię chroni"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931296,kadyrow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931296,kadyrow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T10:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c4/8b/1c/z29931460M,Ramzan-Kadyrow-z-synem.jpg" vspace="2" />Przywódca Czeczenów i najwierniejszy sojusznik Władimira Putina Ramzan Kadyrow jest w ciężkim stanie - takie informacje podaje rosyjski kanał na Telegramie, który uchodzi za dobrze poinformowany. Podejrzenia podsyca też wpis syna czeczeńskiego lidera. Kadyrowa po raz ostatni widziano pod koniec czerwca, kiedy potępił marsz na Moskwę Prigożyna i wagnerowców.

## Kolizja skutera z samolotem? Pod Radomiem to możliwe. Straty to nawet 150 tys. zł
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29931361,kolizja-skutera-z-samolotem-pod-radomiem-to-mozliwe-straty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29931361,kolizja-skutera-z-samolotem-pod-radomiem-to-mozliwe-straty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T10:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/83/8b/1c/z29931395M,Piastow--Kolizja-skutera-z-samolotem.jpg" vspace="2" />W Piastowie kobieta chciała zaparkować skuter. Nieświadomie docisnęła manetkę gazu i uderzyła w samolot. Koszty naprawy zniszczonego kadłuba maszyny mogą wynieść nawet 150 tys. zł - ocenił pilot.

## Sądzisz, że dobrze znasz historię? Zweryfikuje to ten quiz kalendarzowy
 - [https://wiadomosci.gazeta.pl/wiadomosci/13,129662,17538,sadzisz-ze-dobrze-znasz-historie-zweryfikuje-to-ten-quiz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/13,129662,17538,sadzisz-ze-dobrze-znasz-historie-zweryfikuje-to-ten-quiz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T10:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d8/ae/1b/z29024472M,Grafika-do-quizu-kalendarzowego.jpg" vspace="2" />7 pytań o ciekawe rocznice i wydarzenia. Zdołasz zdobyć 7 punktów?

## Belgia. Pędził autostradą 388 km/h i uniknie kary? To możliwe
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931312,belgia-pedzil-autostrada-388-km-h-i-uniknie-kary-to-mozliwe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931312,belgia-pedzil-autostrada-388-km-h-i-uniknie-kary-to-mozliwe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T09:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a8/8b/1c/z29931432M,Belgijska-policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Kierowca we Flamanfii (północna część Belgii) miał pędzić autostradą z prędkością 388 kilometrów na godzinę. Policja ma jednak wątpliwości w sprawie, a eksperci wskazują, że kierowca może uniknąć kary. Jak to możliwe?

## Szef akcji poszukiwawczej Titana opowiedział o jej szczegółach. Nie krył łez. "Krótko po dotarciu na dno..."
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931238,szef-akcji-poszukiwawczej-titana-opowiedzial-o-szczegolach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931238,szef-akcji-poszukiwawczej-titana-opowiedzial-o-szczegolach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T09:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/47/88/1c/z29920583M,28-06-2023--St--John-s--Nowa-Fundlandia--Kanada--w.jpg" vspace="2" />Edward Cassano, który dowodził akcją poszukiwawczą Titana, wyznał, że zarówno on, jak i jego zespół, nie mogą pogodzić się z tym, co się stało. - Scenariusz, którego chcieliśmy, to Titan lekko spoczywający na dnie oceanu, z nienaruszoną załogą, nienaruszonym zbiornikiem ciśnieniowym - dodał.

## Masowa strzelanina w Baltimore. Zaatakowano podczas święta dzielnicy. Są zabici i ranni
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931320,masowa-strzelanina-w-baltimore-zaatakowano-podczas-swieta-dzielnicy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931320,masowa-strzelanina-w-baltimore-zaatakowano-podczas-swieta-dzielnicy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T08:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/39/8b/1c/z29931321M,Strzelanina-w-Baltimore.jpg" vspace="2" />Co najmniej dwie osoby zginęły, a 30 zostało rannych w masowej strzelaninie w Baltimore, w stanie Maryland - podała policja. Do ataku doszło podczas święta dzielnicy. Sprawca nie został dotychczas zidentyfikowany.

## Do Polski dotrze afrykański upał? Nawet 35 stopni Celsjusza, później wrócą nawałnice
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931162,do-polski-dotrze-afrykanski-upal-nawet-35-stopni-celsjusza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931162,do-polski-dotrze-afrykanski-upal-nawet-35-stopni-celsjusza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T08:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/8b/1c/z29931282M,Plaza--upal--zdjecie-ilustracyjne-.jpg" vspace="2" />Jaka będzie pogoda w wakacje? Zgodnie z prognozami prawdopodobnie zbliża się do nas afrykański upał, w związku z którym temperatura podskoczy nawet do 35 stopni Celsjusza. Potem jednak mogą wrócić nawałnice.

## Gwizdy i emocje na spotkaniu z Morawieckim w Kościerzynie. Wypomniał premierowi "miskę ryżu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29931165,gwizdy-i-emocje-na-spotkaniu-z-morawieckim-w-koscierzynie-wypomnial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29931165,gwizdy-i-emocje-na-spotkaniu-z-morawieckim-w-koscierzynie-wypomnial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T08:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4e/8b/1c/z29930062M,Spotkanie-premiera-Mateusza-Morawieckiego-z-mieszk.jpg" vspace="2" />- Gdzie są obiecane 770 mld zł? Czy ludzie mają pracować za miskę ryżu? - zapytał Mateusza Morawieckiego mieszkaniec Kościerzyny podczas wyborczego spotkania. Na sali zawrzało, a premier zaczął mówić o opozycji.

## Alarm przeciwlotniczy w Kijowie po 12 dniach przerwy. "Nie fotografuj ani nie filmuj pracy obrońców"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931107,alarm-przeciwlotniczy-w-kijowie-po-12-dniach-przerwy-dowodztwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931107,alarm-przeciwlotniczy-w-kijowie-po-12-dniach-przerwy-dowodztwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T07:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/98/8b/1c/z29931160M,Wojna-w-Ukrainie--Alarm-przeciwlotniczy-w-Kijowie-.jpg" vspace="2" />Po niemal dwóch tygodniach przerwy Rosjanie nocą z soboty na niedzielę zaatakowali Kijów. Ukraińskie dowództwo poinformowało, że wszystkie drony agresora zniszczyła obrona przeciwlotnicza. Alarmy przeciwlotnicze uruchomiono również w innych obwodach atakowanej przez Rosję Ukrainy.

## Zna go każdy, wciąż dochodzi do poparzeń. Leśnicy ostrzegają: Objawy nawet po kilkunastu minutach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29930221,zna-go-kazdy-wciaz-dochodzi-do-poparzen-lesnicy-ostrzegaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29930221,zna-go-kazdy-wciaz-dochodzi-do-poparzen-lesnicy-ostrzegaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T06:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e5/78/1c/z29852901M,Barszcz-Sosnowskiego--zdjecie-ilustracyjne-.jpg" vspace="2" />Latem dochodzi do największej ilości poparzeń. Zagrożeniem nie są jedynie promienie słonczene. "Przypominamy o barszczu Sosnowskiego" - ostrzegają Lasy Państwowe. Roślina jest bardzo inwazyjna, a przede wszystkim trudna do zwalczenia.

## Pół tysiąca osób zatrzymanych we Francji. Pod Paryżem zaatakowano dom mera. Piąta noc zamieszek
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931087,pol-tysiaca-osob-zatrzymanych-we-francji-piata-noc-zamieszek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29931087,pol-tysiaca-osob-zatrzymanych-we-francji-piata-noc-zamieszek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T06:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/8b/1c/z29931097M,Pol-tysiaca-osob-zatrzymanych-we-Francji--Piata-no.jpg" vspace="2" />Paryż i Marsylia - w tych dwóch miastach Francji w nocy z sobotę na niedzielę doszło do najbrutalniejszych starć między demonstrantami i policją. Francuskie ministerstwo spraw wewnętrznych podało, że do godz. 3:30 aresztowano 486 osób. To piąta z kolei noc rozruchów po śmierci 17-letniego Nahela.

## Szef CIA: Bunt Prigożyna stwarza szansę, która zdarza się raz na pokolenie. Nie zmarnujemy jej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29930796,szef-cia-bunt-prigozyna-stwarza-szanse-ktora-zdarza-sie-raz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29930796,szef-cia-bunt-prigozyna-stwarza-szanse-ktora-zdarza-sie-raz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T05:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/63/8b/1c/z29930851M,Jewgienij-Prigozyn.jpg" vspace="2" />- To żywe przypomnienie destrukcyjnego działania wojny Władimira Putina na rosyjskie społeczeństwo i własny reżim - powiedział szef CIA o buncie Jewgienija Prigożyna. William Burns stwierdził również, że niezadowolenie Rosjan z przebiegu wojny stwarza dla Amerykanów "szansę, która zdarza się raz na pokolenie".

## Kiedy wybory parlamentarne? Duda: Bardzo ładna data
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29930143,kiedy-wybory-parlamentarne-duda-bardzo-ladna-data.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29930143,kiedy-wybory-parlamentarne-duda-bardzo-ladna-data.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T05:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/8b/1c/z29930258M,Sejm--zdjecie-ilustracyjne-.jpg" vspace="2" />Kiedy odbędą się wybory parlamentarne? W mediach od dawna pojawia się data 15 października, czyli Dzień Papieski. Według Andrzeja Dudy to "bardzo ładna data".

## Horoskop dzienny - niedziela 2 lipca [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,29930157,horoskop-dzienny-niedziela-2-lipca-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,29930157,horoskop-dzienny-niedziela-2-lipca-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-02T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c3/01/1b/z28319683M,Horoskop-na-niedziele.jpg" vspace="2" />Horoskop dzienny dla wszystkich znaków zodiaku. Co przyniesie niedziela 2 lipca? Nie zwlekaj, sprawdź.

