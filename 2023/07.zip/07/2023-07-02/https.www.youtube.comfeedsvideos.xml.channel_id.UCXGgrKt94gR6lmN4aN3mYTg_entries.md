# Source:Austin Evans, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg, language:en-US

## I bought the WEIRDEST Gadgets on Temu...
 - [https://www.youtube.com/watch?v=LfSwArdTlLQ](https://www.youtube.com/watch?v=LfSwArdTlLQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg
 - date published: 2023-07-02T15:01:56+00:00

https://www.youtube.com/watch?v=VHjA_Z2jJqw on @thisis 
https://www.youtube.com/watch?v=EVrWKhivZtY on @DNKI 

Subscribe for more! http://www.youtube.com/austinevans
TikTok: https://www.tiktok.com/@austintechtips
Instagram: http://instagram.com/austinnotduncan
Twitter: http://twitter.com/austinnotduncan

Chapter Titles:
0:00 Ordering
2:09 The Domineering Headset
3:47 Claw of Doom
4:48 Padlock of Deceit
5:58 Photo Madness
9:11 What's an F Scope?
10:28 I Need Adult Supervision
12:11 Shockingly Stupid
13:06 Hello World
14:06 I Don't Know What I Expected

