# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Xbox vs FTC: 12 Surprising Reveals From the Trial
 - [https://www.youtube.com/watch?v=2t2SYZ5PN1U](https://www.youtube.com/watch?v=2t2SYZ5PN1U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-07-02T13:15:00+00:00

With the FTC Trial against Xbox wrapped up and deliberations still pending, here are the biggest surprises and reveals we’ve learned from Xbox’s strategy in the console wars to potential acquisition targets like Sega and Bungie.

#Xbox #FTC #Sega #Bungie

## Naruto X Boruto Ultimate Ninja Storm Connections - Official Story Mode Trailer
 - [https://www.youtube.com/watch?v=Ka1alO3MuUw](https://www.youtube.com/watch?v=Ka1alO3MuUw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-07-02T02:28:04+00:00

Naruto X Boruto Ultimate Ninja Storm Connections is a 3D action fighting game developed by CyberConnect2. As the game marks the 20th anniversary of the Naruto anime, the game is packed with the largest roster in the entire Naruto Ultimate Ninja Storm series. Take a look at the trailer to see what the Story Mode has to offer in Naruto X Boruto Ultimate Ninja Storm Connections launching on PlayStation 4, PlayStation 5, Xbox One, Xbox Series S|X, Nintendo Switch, and PC in 2023.

#NarutoXBorutoUltimateNinjaStormConnections #StoryMode #BandiNamcoSummerShowcase2023

## Jujustu Kaisen Cursed Clash - Official Announcement Trailer | Bandi Namco Summer Showcase 2023
 - [https://www.youtube.com/watch?v=Kqro-TFhLNg](https://www.youtube.com/watch?v=Kqro-TFhLNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-07-02T02:04:58+00:00

Jujustu Kaisen Cursed Clash is a 2 vs. 2 action game developed by Byking Inc. Players will choose their partner, create unique combinations, and strengthen their cursed techniques through exhilarating battles and defeating their opponents. Jujustu Kaisen Cursed Clash is launching on PlayStation 4, PlayStation 5, Xbox, and PC.

#JujustuKaisenCursedClash #BandiNamcoSummerShowcase2023

## Sword Art Online: Last Recollection - Official Characters Trailer | Bandi Namco Summer Showcase 2023
 - [https://www.youtube.com/watch?v=tVM2_3rVu1A](https://www.youtube.com/watch?v=tVM2_3rVu1A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-07-02T00:23:08+00:00

Sword Art Online: Last Recollection is an action RPG adventure game developed by Aquaria. Take a look at the latest trailer showcasing the original characters in the game. Sword Art Online: Last Recollection is launching on October 6 for PlayStation 4, PlayStation 5, Xbox, and PC.

#SwordArtOnlineLastRecollection #BandiNamcoSummerShowcase2023

