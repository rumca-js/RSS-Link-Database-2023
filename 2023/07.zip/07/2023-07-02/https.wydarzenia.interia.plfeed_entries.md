# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Wysłannik papieża po powrocie z Moskwy. "Nie mamy planu pokojowego"
 - [https://wydarzenia.interia.pl/zagranica/news-wyslannik-papieza-po-powrocie-z-moskwy-nie-mamy-planu-pokojo,nId,6878124](https://wydarzenia.interia.pl/zagranica/news-wyslannik-papieza-po-powrocie-z-moskwy-nie-mamy-planu-pokojo,nId,6878124)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T21:47:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wyslannik-papieza-po-powrocie-z-moskwy-nie-mamy-planu-pokojo,nId,6878124"><img align="left" alt="Wysłannik papieża po powrocie z Moskwy. &quot;Nie mamy planu pokojowego&quot;" src="https://i.iplsc.com/wyslannik-papieza-po-powrocie-z-moskwy-nie-mamy-planu-pokojo/000HCSN1VFH5B71J-C321.jpg" /></a>Nie mamy planu pokojowego ani sposobu na mediacje, ale panuje wielkie pragnienie, by przemoc w Ukrainie się zakończyła - powiedział wysłannik papieża Franciszka, kardynał Matteo Zuppi, który w piątek powrócił z Moskwy. Duchowny stwierdził, że w centrum jego misji były &quot;kwestie humanitarne&quot; i &quot;obrona niewinnych osób&quot;. </p><br clear="all" />

## Tragedia koło Lubomierza. Na miejscu zginęła 51-letnia policjantka
 - [https://wydarzenia.interia.pl/malopolskie/news-tragedia-kolo-lubomierza-na-miejscu-zginela-51-letnia-policj,nId,6878109](https://wydarzenia.interia.pl/malopolskie/news-tragedia-kolo-lubomierza-na-miejscu-zginela-51-letnia-policj,nId,6878109)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T20:26:46+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-tragedia-kolo-lubomierza-na-miejscu-zginela-51-letnia-policj,nId,6878109"><img align="left" alt="Tragedia koło Lubomierza. Na miejscu zginęła 51-letnia policjantka" src="https://i.iplsc.com/tragedia-kolo-lubomierza-na-miejscu-zginela-51-letnia-policj/000HCSFBWWTEIEG5-C321.jpg" /></a>51-letnia emerytowana policjantka zginęła w tragicznym wypadku między Mszaną Dolną a Lubomierzem - powiedziała st. asp. Joanna Batko z Komendy Powiatowej Policji w Limanowej. W zderzeniu ucierpiały także trzy inne osoby, w tym dziewięcioletni syn kobiety, który w stanie krytycznym został przetransportowany śmigłowcem LPR do Krakowa. Droga była zablokowana przez osiem godzin.</p><br clear="all" />

## Szokujące odkrycie w amerykańskim parku rozrywki. "Niemal odcięło filar"
 - [https://wydarzenia.interia.pl/zagranica/news-szokujace-odkrycie-w-amerykanskim-parku-rozrywki-niemal-odci,nId,6878099](https://wydarzenia.interia.pl/zagranica/news-szokujace-odkrycie-w-amerykanskim-parku-rozrywki-niemal-odci,nId,6878099)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T20:14:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szokujace-odkrycie-w-amerykanskim-parku-rozrywki-niemal-odci,nId,6878099"><img align="left" alt="Szokujące odkrycie w amerykańskim parku rozrywki. &quot;Niemal odcięło filar&quot;" src="https://i.iplsc.com/szokujace-odkrycie-w-amerykanskim-parku-rozrywki-niemal-odci/000HCS82WHQ8Y74Y-C321.jpg" /></a>W internecie wybuchła dyskusja na temat bezpieczeństwa korzystania z kolejki górskiej w jednym z parków rozrywki w USA. Rodzice zauważyli, że na filarze popularnej atrakcji - Carowinds Fury 325, pojawiło się pęknięcie. Dopiero po nagłośnieniu sprawy maszyna została wyłączona z użytku. 
</p><br clear="all" />

## Nowe informacje ws. uprowadzenia Madeleine McCann. To obala główną teorię
 - [https://wydarzenia.interia.pl/zagranica/news-nowe-informacje-ws-uprowadzenia-madeleine-mccann-to-obala-gl,nId,6878087](https://wydarzenia.interia.pl/zagranica/news-nowe-informacje-ws-uprowadzenia-madeleine-mccann-to-obala-gl,nId,6878087)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T19:49:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowe-informacje-ws-uprowadzenia-madeleine-mccann-to-obala-gl,nId,6878087"><img align="left" alt="Nowe informacje ws. uprowadzenia Madeleine McCann. To obala główną teorię" src="https://i.iplsc.com/nowe-informacje-ws-uprowadzenia-madeleine-mccann-to-obala-gl/000A6HE7WBUDA9IT-C321.jpg" /></a>Nowe informacje ws. śledztwa dotyczącego zniknięcia Madeleine McCann. Według jednego ze świadków główny podejrzany miał zestaw do otwierania zamków w drzwiach antywłamaniowych.</p><br clear="all" />

## Dramat na jeziorze Śniardwy. Zapłonął jacht z ludźmi na pokładzie
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-dramat-na-jeziorze-sniardwy-zaplonal-jacht-z-ludzmi-na-pokla,nId,6878085](https://wydarzenia.interia.pl/warminsko-mazurskie/news-dramat-na-jeziorze-sniardwy-zaplonal-jacht-z-ludzmi-na-pokla,nId,6878085)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T19:29:28+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-dramat-na-jeziorze-sniardwy-zaplonal-jacht-z-ludzmi-na-pokla,nId,6878085"><img align="left" alt="Dramat na jeziorze Śniardwy. Zapłonął jacht z ludźmi na pokładzie" src="https://i.iplsc.com/dramat-na-jeziorze-sniardwy-zaplonal-jacht-z-ludzmi-na-pokla/000HCSB9S334DJK8-C321.jpg" /></a>Nad jeziorem Śniardwy doszło do groźnego zdarzenia. Zapalił się jacht, na którym przebywały dwie osoby. Żeglarze musieli skoczyć do wody, aby ratować swoje życie. Łódka spłonęła doszczętnie. </p><br clear="all" />

## Akcja na autostradzie A2. Śmigłowiec LPR zabrał półtoraroczne dziecko
 - [https://wydarzenia.interia.pl/lodzkie/news-akcja-na-autostradzie-a2-smiglowiec-lpr-zabral-poltoraroczne,nId,6878098](https://wydarzenia.interia.pl/lodzkie/news-akcja-na-autostradzie-a2-smiglowiec-lpr-zabral-poltoraroczne,nId,6878098)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T19:06:44+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-akcja-na-autostradzie-a2-smiglowiec-lpr-zabral-poltoraroczne,nId,6878098"><img align="left" alt="Akcja na autostradzie A2. Śmigłowiec LPR zabrał półtoraroczne dziecko" src="https://i.iplsc.com/akcja-na-autostradzie-a2-smiglowiec-lpr-zabral-poltoraroczne/000H9I7VXHLITKGJ-C321.jpg" /></a>Półtoraroczne dziecko dostało napadu drgawek, gdy jechało ze swoimi rodzicami autostradą A2 między węzłami Łódź Północ a Łowicz w kierunku Warszawy - poinformowała w rozmowie z Interią rzeczniczka Lotniczego Pogotowania Ratunkowego Justyna Sochacka. Konieczne było lądowanie helikoptera LPR, przez co droga była zablokowana przez godzinę.</p><br clear="all" />

## Niebezpieczna pogoda nad Bałtykiem. Wydano ostrzeżenia dla turystów
 - [https://wydarzenia.interia.pl/kraj/news-niebezpieczna-pogoda-nad-baltykiem-wydano-ostrzezenia-dla-tu,nId,6878073](https://wydarzenia.interia.pl/kraj/news-niebezpieczna-pogoda-nad-baltykiem-wydano-ostrzezenia-dla-tu,nId,6878073)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T18:44:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niebezpieczna-pogoda-nad-baltykiem-wydano-ostrzezenia-dla-tu,nId,6878073"><img align="left" alt="Niebezpieczna pogoda nad Bałtykiem. Wydano ostrzeżenia dla turystów" src="https://i.iplsc.com/niebezpieczna-pogoda-nad-baltykiem-wydano-ostrzezenia-dla-tu/000HCRYMPWGJD6SJ-C321.jpg" /></a>Brzydka pogoda daje o sobie znać przez cały weekend. Na polskim wybrzeżu spodziewany jest silny wiatr z porywami nawet do 80 km/h - ostrzega Instytut Meteorologii i Gospodarki Wodnej, który wydał specjalne alerty pogodowe. W poniedziałek aura również nie będzie rozpieszczać urlopowiczów, którzy wybrali się nad Bałtyk. Słoneczne plażowanie będzie musiało poczekać na inny dzień.</p><br clear="all" />

## Protesty we Francji. Babcia zamordowanego apeluje do manifestantów
 - [https://wydarzenia.interia.pl/zagranica/news-protesty-we-francji-babcia-zamordowanego-apeluje-do-manifest,nId,6878075](https://wydarzenia.interia.pl/zagranica/news-protesty-we-francji-babcia-zamordowanego-apeluje-do-manifest,nId,6878075)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T18:14:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-protesty-we-francji-babcia-zamordowanego-apeluje-do-manifest,nId,6878075"><img align="left" alt="Protesty we Francji. Babcia zamordowanego apeluje do manifestantów" src="https://i.iplsc.com/protesty-we-francji-babcia-zamordowanego-apeluje-do-manifest/000HCRZ4FKMD25MM-C321.jpg" /></a>Babcia Nahela M., śmiertelnie postrzelonego przez policjanta 17-latka, zaapelowała do protestujących o zachowanie spokoju i powstrzymanie przemocy. Jednocześnie policja ogłosiła kolejne przygotowania do manifestacji. Wcześniej prezydent Francji Emmanuel Macron w ostrych słowach wezwał rodziców do wzięcia odpowiedzialności za swoje dzieci i ich zachowanie.</p><br clear="all" />

## Niemcy z dużym problemem. Ekspert wskazuje na Rosję
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-z-duzym-problemem-ekspert-wskazuje-na-rosje,nId,6878070](https://wydarzenia.interia.pl/zagranica/news-niemcy-z-duzym-problemem-ekspert-wskazuje-na-rosje,nId,6878070)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T17:58:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-z-duzym-problemem-ekspert-wskazuje-na-rosje,nId,6878070"><img align="left" alt="Niemcy z dużym problemem. Ekspert wskazuje na Rosję" src="https://i.iplsc.com/niemcy-z-duzym-problemem-ekspert-wskazuje-na-rosje/000FFWV8HSH44A07-C321.jpg" /></a>- Co czwarty Niemiec ma prorosyjskie nastawienie. To ogromny problem - mówi Matthew Karnitschnig, korespondent &quot;Politico&quot;. W rozmowie z &quot;Deusche Welle&quot; ekspert ocenia nastroje, które panują wśród niemieckiego społeczeństwa w dobie recesji. Komentuje również kwestię potencjalnego powrotu Donalda Trumpa na fotel prezydenta Stanów Zjednoczonych w kontekście trwającej wojny w Ukrainie. </p><br clear="all" />

## 37-latek wybił szybę po zerwaniu z dziewczyną. "Kopnął w nerwach"
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-37-latek-wybil-szybe-po-zerwaniu-z-dziewczyna-kopnal-w-nerwa,nId,6878058](https://wydarzenia.interia.pl/dolnoslaskie/news-37-latek-wybil-szybe-po-zerwaniu-z-dziewczyna-kopnal-w-nerwa,nId,6878058)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T17:20:07+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-37-latek-wybil-szybe-po-zerwaniu-z-dziewczyna-kopnal-w-nerwa,nId,6878058"><img align="left" alt="37-latek wybił szybę po zerwaniu z dziewczyną. &quot;Kopnął w nerwach&quot;" src="https://i.iplsc.com/37-latek-wybil-szybe-po-zerwaniu-z-dziewczyna-kopnal-w-nerwa/000HCRNS7AUEG5DD-C321.jpg" /></a>Policja zatrzymała podejrzanego o wybicie szyby w jednym z salonów fryzjerskich w Jaworze. Zatrzymany 37-latek tłumaczył, że był zdenerwowany, bo wcześniej tego dnia rozstał się ze swoją dziewczyną. Kopnięcie w witrynę, miało pomóc mu &quot;rozładować napięcie&quot;. Teraz grozi mu do 7,5 roku pozbawienia wolności. 

</p><br clear="all" />

## "Łuka-terrorysta! Niech żyje Białoruś!". Atak na ambasadę Białorusi w Hadze
 - [https://wydarzenia.interia.pl/zagranica/news-luka-terrorysta-niech-zyje-bialorus-atak-na-ambasade-bialoru,nId,6878049](https://wydarzenia.interia.pl/zagranica/news-luka-terrorysta-niech-zyje-bialorus-atak-na-ambasade-bialoru,nId,6878049)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T17:05:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-luka-terrorysta-niech-zyje-bialorus-atak-na-ambasade-bialoru,nId,6878049"><img align="left" alt="&quot;Łuka-terrorysta! Niech żyje Białoruś!&quot;. Atak na ambasadę Białorusi w Hadze" src="https://i.iplsc.com/luka-terrorysta-niech-zyje-bialorus-atak-na-ambasade-bialoru/000HCRLJATA02DPF-C321.jpg" /></a>Budynek ambasady Białorusi w Hadze został zaatakowany w nocy z sobotę na niedzielę. Na miejscu zatrzymany został 31-letni mężczyzna, który pomazał fasadę wypisując m.in. &quot;Łuka-terrorysta&quot; i &quot;Niech żyje Białoruś!&quot;.</p><br clear="all" />

## Kilkaset osób świętowało na ulicy, gdy wybuchała strzelanina. Są ofiary
 - [https://wydarzenia.interia.pl/zagranica/news-kilkaset-osob-swietowalo-na-ulicy-gdy-wybuchala-strzelanina-,nId,6878050](https://wydarzenia.interia.pl/zagranica/news-kilkaset-osob-swietowalo-na-ulicy-gdy-wybuchala-strzelanina-,nId,6878050)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T16:52:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kilkaset-osob-swietowalo-na-ulicy-gdy-wybuchala-strzelanina-,nId,6878050"><img align="left" alt="Kilkaset osób świętowało na ulicy, gdy wybuchała strzelanina. Są ofiary" src="https://i.iplsc.com/kilkaset-osob-swietowalo-na-ulicy-gdy-wybuchala-strzelanina/000HCRQ1JSGU0F37-C321.jpg" /></a>Dwie osoby zginęły, a 28 zostało rannych w strzelaninie, do jakiej doszło w Baltimore w stanie Maryland na wschodnim wybrzeżu USA. Według lokalnych mediów na miejscu mogło być nawet kilkaset osób, a świadkowie słyszeli od 20 do 30 strzałów. Władze miasta i służby apelują do mieszkańców o wsparcie w poszukiwaniu sprawców, ponieważ ci wciąż są na wolności.</p><br clear="all" />

## Rosja: Wybuch blisko lotniska wojskowego. To miejsce startu "Szahidów"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wybuch-blisko-lotniska-wojskowego-to-miejsce-startu-sz,nId,6878059](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wybuch-blisko-lotniska-wojskowego-to-miejsce-startu-sz,nId,6878059)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T16:45:07+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wybuch-blisko-lotniska-wojskowego-to-miejsce-startu-sz,nId,6878059"><img align="left" alt="Rosja: Wybuch blisko lotniska wojskowego. To miejsce startu &quot;Szahidów&quot;" src="https://i.iplsc.com/rosja-wybuch-blisko-lotniska-wojskowego-to-miejsce-startu-sz/000HCRQR8IW0COG7-C321.jpg" /></a>Ogromny krater pojawił się w miejscu wybuchu, do jakiego doszło w pobliżu lotniska wojskowego w Primorsko-Achtarsku w obwodzie krasnodarskim w Rosji. Z bazy wystrzeliwano &quot;szahidy&quot; atakujące cele w Ukrainie.</p><br clear="all" />

## 52 godziny w dziczy. 16-latki szukało kilkanaście jednostek
 - [https://wydarzenia.interia.pl/zagranica/news-52-godziny-w-dziczy-16-latki-szukalo-kilkanascie-jednostek,nId,6878027](https://wydarzenia.interia.pl/zagranica/news-52-godziny-w-dziczy-16-latki-szukalo-kilkanascie-jednostek,nId,6878027)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T16:10:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-52-godziny-w-dziczy-16-latki-szukalo-kilkanascie-jednostek,nId,6878027"><img align="left" alt="52 godziny w dziczy. 16-latki szukało kilkanaście jednostek" src="https://i.iplsc.com/52-godziny-w-dziczy-16-latki-szukalo-kilkanascie-jednostek/000HCRHKJMINRYHK-C321.jpg" /></a>Podczas wycieczki w Golden Ears Park w Kanadzie zaginęła 16-letnia Esther Wang. Jak podaje CNN, dziewczyna spędziła sama w kanadyjskiej dziczy ponad dwa dni. Policja poinformowała, że nastolatka odnalazła się cała i zdrowa. - Była zmęczona, ale bez obrażeń - podano. </p><br clear="all" />

## Wypadek na Bałtyku. Media dotarły do świadka i zapisu monitoringu
 - [https://wydarzenia.interia.pl/kraj/news-wypadek-na-baltyku-media-dotarly-do-swiadka-i-zapisu-monitor,nId,6878036](https://wydarzenia.interia.pl/kraj/news-wypadek-na-baltyku-media-dotarly-do-swiadka-i-zapisu-monitor,nId,6878036)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T15:45:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wypadek-na-baltyku-media-dotarly-do-swiadka-i-zapisu-monitor,nId,6878036"><img align="left" alt="Wypadek na Bałtyku. Media dotarły do świadka i zapisu monitoringu" src="https://i.iplsc.com/wypadek-na-baltyku-media-dotarly-do-swiadka-i-zapisu-monitor/000HCGRR4MRYL2JI-C321.jpg" /></a>&quot;Na pokładzie było zimno, a w cieniu siedziała kobieta z dużym wózkiem dla dzieci. Miała opuszczoną głowę, a dziecko prawdopodobnie było niepełnosprawne. To oni byli ofiarami tragedii&quot; - twierdzi pasażerka promu Stena Spirit, która miała widzieć 36-latkę i jej syna na około dwie godziny przez tym, jak wpadli do Bałtyku. Z nieoficjalnych ustaleń mediów wynika, że - jak pokazują nagrania monitoringu - na krótko przed zdarzeniem dziecko trzymało się bioder matki.</p><br clear="all" />

## Sensacyjne odkrycie w Ukrainie. Służyły w trakcie II wojny światowej
 - [https://wydarzenia.interia.pl/zagranica/news-sensacyjne-odkrycie-w-ukrainie-sluzyly-w-trakcie-ii-wojny-sw,nId,6878033](https://wydarzenia.interia.pl/zagranica/news-sensacyjne-odkrycie-w-ukrainie-sluzyly-w-trakcie-ii-wojny-sw,nId,6878033)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T15:26:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sensacyjne-odkrycie-w-ukrainie-sluzyly-w-trakcie-ii-wojny-sw,nId,6878033"><img align="left" alt="Sensacyjne odkrycie w Ukrainie. Służyły w trakcie II wojny światowej" src="https://i.iplsc.com/sensacyjne-odkrycie-w-ukrainie-sluzyly-w-trakcie-ii-wojny-sw/000HCRBXL4P81HB7-C321.jpg" /></a>W trakcie prac przy niewybuchu z II wojny światowej odkryto szczątki samolotów Hurricane przekazanych w latach 1941-44 ZSRR z Wielkiej Brytanii. Fragmenty maszyn znaleziono pod Kijowem.</p><br clear="all" />

## Z rury w ziemi wydobywały się piski. Błyskawiczna reakcja policjanta
 - [https://wydarzenia.interia.pl/zagranica/news-z-rury-w-ziemi-wydobywaly-sie-piski-blyskawiczna-reakcja-pol,nId,6878012](https://wydarzenia.interia.pl/zagranica/news-z-rury-w-ziemi-wydobywaly-sie-piski-blyskawiczna-reakcja-pol,nId,6878012)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T14:54:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-z-rury-w-ziemi-wydobywaly-sie-piski-blyskawiczna-reakcja-pol,nId,6878012"><img align="left" alt="Z rury w ziemi wydobywały się piski. Błyskawiczna reakcja policjanta" src="https://i.iplsc.com/z-rury-w-ziemi-wydobywaly-sie-piski-blyskawiczna-reakcja-pol/000HCRDPK8GLNJPX-C321.jpg" /></a>Jeden z mieszkańców Citrus Hill w północno-zachodniej Florydzie w USA podczas porannego spaceru usłyszał &quot;piski&quot;, które wydobywały się z odkrytej rury w ziemi. Okazało się, że w otworze utknął mały kotek. Na miejsce przybył zastępca szeryfa z lokalnego posterunku, który przeprowadził błyskawiczną akcję ratunkową, z której relację zamieszczono na Facebooku.  </p><br clear="all" />

## Francuski polityk bije na alarm. Mówi o "wojnie domowej"
 - [https://wydarzenia.interia.pl/zagranica/news-francuski-polityk-bije-na-alarm-mowi-o-wojnie-domowej,nId,6878023](https://wydarzenia.interia.pl/zagranica/news-francuski-polityk-bije-na-alarm-mowi-o-wojnie-domowej,nId,6878023)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T14:35:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-francuski-polityk-bije-na-alarm-mowi-o-wojnie-domowej,nId,6878023"><img align="left" alt="Francuski polityk bije na alarm. Mówi o &quot;wojnie domowej&quot;" src="https://i.iplsc.com/francuski-polityk-bije-na-alarm-mowi-o-wojnie-domowej/000HCR9832YOKQ4B-C321.jpg" /></a>- Jesteśmy między zamieszkami a wojną domową - twierdzi Eric Zemmour, prezes francuskiej partii Reconquest. Bilans rannych i zatrzymanych w trakcie zamieszek w miastach całej Francji stale rośnie.</p><br clear="all" />

## Ośrodek z migrantami przepełniony. Władze musiały działać
 - [https://wydarzenia.interia.pl/zagranica/news-osrodek-z-migrantami-przepelniony-wladze-musialy-dzialac,nId,6878000](https://wydarzenia.interia.pl/zagranica/news-osrodek-z-migrantami-przepelniony-wladze-musialy-dzialac,nId,6878000)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T14:14:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-osrodek-z-migrantami-przepelniony-wladze-musialy-dzialac,nId,6878000"><img align="left" alt="Ośrodek z migrantami przepełniony. Władze musiały działać " src="https://i.iplsc.com/osrodek-z-migrantami-przepelniony-wladze-musialy-dzialac/000HCQFQ5KFI9S7K-C321.jpg" /></a>Włoski ośrodek na Lampdusie, przyjmujący migrantów z wybrzeży Afryki, był znacznie przepełniony. Przebywało w nim ponad 3300 osób, czyli osiem razy więcej, niż było miejsc. Tamtejsze władze zorganizowały więc błyskawiczne transfery do innych włoskich miejscowości. </p><br clear="all" />

## "Tusk to patron Ochojskiej". Mateusz Morawiecki o nagraniu lidera PO
 - [https://wydarzenia.interia.pl/kraj/news-tusk-to-patron-ochojskiej-mateusz-morawiecki-o-nagraniu-lide,nId,6878018](https://wydarzenia.interia.pl/kraj/news-tusk-to-patron-ochojskiej-mateusz-morawiecki-o-nagraniu-lide,nId,6878018)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T13:46:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-to-patron-ochojskiej-mateusz-morawiecki-o-nagraniu-lide,nId,6878018"><img align="left" alt="&quot;Tusk to patron Ochojskiej&quot;. Mateusz Morawiecki o nagraniu lidera PO" src="https://i.iplsc.com/tusk-to-patron-ochojskiej-mateusz-morawiecki-o-nagraniu-lide/000HCQTIIOXPPF34-C321.jpg" /></a>Premier Mateusz Morawiecki zareagował na nagranie umieszczone na Twitterze Donalda Tuska. Były premier przestrzegał w nim przed polityką migracyjną Jarosława Kaczyńskiego. Jak ocenił szef polskiego rządu, Tusk &quot;to patron posłów PO biegających z reklamówkami i wzywających do wpuszczenia nielegalnych imigrantów&quot;. Słowa lidera PO skrytykował także minister sprawiedliwości Zbigniew Ziobro.</p><br clear="all" />

## Ogromne pieniądze dla Jewgienija Prigożyna. Putin płacił mu miliardy dolarów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ogromne-pieniadze-dla-jewgienija-prigozyna-putin-placil-mu-m,nId,6878006](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ogromne-pieniadze-dla-jewgienija-prigozyna-putin-placil-mu-m,nId,6878006)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T13:22:03+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ogromne-pieniadze-dla-jewgienija-prigozyna-putin-placil-mu-m,nId,6878006"><img align="left" alt="Ogromne pieniądze dla Jewgienija Prigożyna. Putin płacił mu miliardy dolarów" src="https://i.iplsc.com/ogromne-pieniadze-dla-jewgienija-prigozyna-putin-placil-mu-m/000HCQHILPSV3QG5-C321.jpg" /></a>Ponad 18 miliardów dolarów miał zarobić Jewgienij Prigożyn na kontraktach z instytucjami państwowymi. Informacje o rzeczywistej skali finansowania podał propagandysta Dmytro Kiselyov.</p><br clear="all" />

## Niemiecki europoseł chce porażki PiS w wyborach. Mówi o "powstaniu nowego rządu"
 - [https://wydarzenia.interia.pl/zagranica/news-niemiecki-europosel-chce-porazki-pis-w-wyborach-mowi-o-powst,nId,6877995](https://wydarzenia.interia.pl/zagranica/news-niemiecki-europosel-chce-porazki-pis-w-wyborach-mowi-o-powst,nId,6877995)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T12:25:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemiecki-europosel-chce-porazki-pis-w-wyborach-mowi-o-powst,nId,6877995"><img align="left" alt="Niemiecki europoseł chce porażki PiS w wyborach. Mówi o &quot;powstaniu nowego rządu&quot;" src="https://i.iplsc.com/niemiecki-europosel-chce-porazki-pis-w-wyborach-mowi-o-powst/000HCQAJYVJ4U2OA-C321.jpg" /></a>- Możliwe, że w październiku w Polsce powstanie nowy rząd. Mam nadzieję, że moi polityczni przyjaciele wraz z koalicjantami będą prowadzić odmienną politykę - powiedział niemiecki europoseł Michael Gahler. Polityk jest przekonany, że nowe władze w Warszawie będą przychylniej patrzeć na pomysły płynące z Brukseli.</p><br clear="all" />

## Spekulacje na temat stanu Kadyrowa. Wpis jego syna wywołał burzę
 - [https://wydarzenia.interia.pl/zagranica/news-spekulacje-na-temat-stanu-kadyrowa-wpis-jego-syna-wywolal-bu,nId,6877989](https://wydarzenia.interia.pl/zagranica/news-spekulacje-na-temat-stanu-kadyrowa-wpis-jego-syna-wywolal-bu,nId,6877989)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T12:04:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-spekulacje-na-temat-stanu-kadyrowa-wpis-jego-syna-wywolal-bu,nId,6877989"><img align="left" alt="Spekulacje na temat stanu Kadyrowa. Wpis jego syna wywołał burzę" src="https://i.iplsc.com/spekulacje-na-temat-stanu-kadyrowa-wpis-jego-syna-wywolal-bu/000F1VP8H0KULFEQ-C321.jpg" /></a>Mnożą się spekulacje na temat stanu zdrowia Ramzana Kadyrowa. Ukraińskie media i komentatorzy w swoich analizach powołują się m.in. na dodany przez jego syna wpis w mediach społecznościowych, w którym chłopak mówi o &quot;bezgranicznym szczęściu&quot;, którym jest posiadanie &quot;przewodnika i mentora&quot;, a także zanosi prośbę: &quot;Niech Wszechmogący cię chroni, drogi Ramzanie Achmatowiczu!&quot;. Rosyjskie media zaprzeczają doniesieniom, jakoby z przywódcą Czeczenii miało dziać się coś złego i zapewniają, że jest on &quot;w doskonałej formie fizycznej i we wspaniałym...</p><br clear="all" />

## Niedźwiedź w okolicach Sztokholmu. "Nigdy tak szybko nie biegałem"
 - [https://wydarzenia.interia.pl/zagranica/news-niedzwiedz-w-okolicach-sztokholmu-nigdy-tak-szybko-nie-biega,nId,6877988](https://wydarzenia.interia.pl/zagranica/news-niedzwiedz-w-okolicach-sztokholmu-nigdy-tak-szybko-nie-biega,nId,6877988)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T11:48:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niedzwiedz-w-okolicach-sztokholmu-nigdy-tak-szybko-nie-biega,nId,6877988"><img align="left" alt="Niedźwiedź w okolicach Sztokholmu. &quot;Nigdy tak szybko nie biegałem&quot;" src="https://i.iplsc.com/niedzwiedz-w-okolicach-sztokholmu-nigdy-tak-szybko-nie-biega/000HCQ2YQ4FQH8OS-C321.jpg" /></a>Nieoczekiwany gość na jednej z wysp Archipelagu Sztokholmskiego. Jak informuje lokalna policja na miejscu zauważono niedźwiedzia. - Nigdy tak szybko nie biegałem - powiedział mężczyzna, który widział zwierzę. </p><br clear="all" />

## Ciężkie walki na wschodnim brzegu Dniepru
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ciezkie-walki-na-wschodnim-brzegu-dniepru,nId,6877983](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ciezkie-walki-na-wschodnim-brzegu-dniepru,nId,6877983)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T11:26:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ciezkie-walki-na-wschodnim-brzegu-dniepru,nId,6877983"><img align="left" alt="Ciężkie walki na wschodnim brzegu Dniepru" src="https://i.iplsc.com/ciezkie-walki-na-wschodnim-brzegu-dniepru/000HCQ5I3RO15MR0-C321.jpg" /></a>- W pobliżu mostu Antonowskiego nad Dnieprem, położonego w okolicy Chersonia, trwają ciężkie walki - oświadczyła rzeczniczka ukraińskich wojsk na południu kraju Natalia Humeniuk. Sytuacja jest trudna, ale ukraińskie siły zbrojne się nie poddają.</p><br clear="all" />

## Afera w Hanowerze. Przedszkolaki miały odkrywać swoje ciało
 - [https://wydarzenia.interia.pl/zagranica/news-afera-w-hanowerze-przedszkolaki-mialy-odkrywac-swoje-cialo,nId,6877980](https://wydarzenia.interia.pl/zagranica/news-afera-w-hanowerze-przedszkolaki-mialy-odkrywac-swoje-cialo,nId,6877980)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T11:17:23+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-afera-w-hanowerze-przedszkolaki-mialy-odkrywac-swoje-cialo,nId,6877980"><img align="left" alt="Afera w Hanowerze. Przedszkolaki miały odkrywać swoje ciało" src="https://i.iplsc.com/afera-w-hanowerze-przedszkolaki-mialy-odkrywac-swoje-cialo/000HCPY3FIDDOCQL-C321.jpg" /></a>Jedno z przedszkoli w Hanowerze chciało stworzyć &quot;pokój do odkrywania ciała&quot;. Zareagował urząd ds. młodzieży. Na plany zareagował urząd ds. młodzieży (niem. Jugendamt). Zdaniem urzędu koncepcja pedagogiczna w tej formie zagraża dobru dziecka.</p><br clear="all" />

## Śmiertelny wypadek pod Giżyckiem. 25-latek w skodzie zderzył się czołowo z radiowozem
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-smiertelny-wypadek-pod-gizyckiem-25-latek-w-skodzie-zderzyl-,nId,6877953](https://wydarzenia.interia.pl/warminsko-mazurskie/news-smiertelny-wypadek-pod-gizyckiem-25-latek-w-skodzie-zderzyl-,nId,6877953)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T09:54:03+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-smiertelny-wypadek-pod-gizyckiem-25-latek-w-skodzie-zderzyl-,nId,6877953"><img align="left" alt="Śmiertelny wypadek pod Giżyckiem. 25-latek w skodzie zderzył się czołowo z radiowozem" src="https://i.iplsc.com/smiertelny-wypadek-pod-gizyckiem-25-latek-w-skodzie-zderzyl/000HCPR2PT1PG48T-C321.jpg" /></a>Do śmiertelnego wypadku doszło w niedzielę rano na trasie Ryn-Giżycko (woj. warmińsko-mazurskie). Kierowca skody zjechał tam na przeciwległy pas ruchu i zderzył się czołowo z policyjnym radiowozem. - W wyniku tego zdarzenia 25-latek zginął, dwaj policjanci odnieśli obrażenia, na szczęście niezagrażające ich życiu - przekazał Interii st. asp. Rafał Jackowski z Komendy Wojewódzkiej Policji w Olsztynie. Obecnie droga cały czas jest zablokowana.</p><br clear="all" />

## J. Kaczyński w Spale: Donald Tusk przeżył w nocy przemianę
 - [https://wydarzenia.interia.pl/lodzkie/news-j-kaczynski-w-spale-donald-tusk-przezyl-w-nocy-przemiane,nId,6877927](https://wydarzenia.interia.pl/lodzkie/news-j-kaczynski-w-spale-donald-tusk-przezyl-w-nocy-przemiane,nId,6877927)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T09:16:38+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-j-kaczynski-w-spale-donald-tusk-przezyl-w-nocy-przemiane,nId,6877927"><img align="left" alt="J. Kaczyński w Spale: Donald Tusk przeżył w nocy przemianę " src="https://i.iplsc.com/j-kaczynski-w-spale-donald-tusk-przezyl-w-nocy-przemiane/000HCPOE03G2VAR1-C321.jpg" /></a>- Spotykamy się w szczególnym dniu, w którym polityka Polska osiągnęła nowy poziom. Kłamstwo kampanii naszych przeciwników szalało od miesięcy, od lat. Dziś mamy jednak coś zupełnie nowego. O ósmej rano został opublikowany wpis Donalda Tuska, w którym okazuje się, że przeżył on w nocy kolejną przemianę duchową - mówił wicepremier Jarosław Kaczyński w Spale. Odniósł się tym samym do nagrania lidera PiS, w którym mówił, że &quot;Polacy muszą odzyskać kontrolę nad państwem i jego granicami&quot;.</p><br clear="all" />

## Jarosław Kaczyński w Spale: Donald Tusk przeżył w nocy przemianę
 - [https://wydarzenia.interia.pl/lodzkie/news-jaroslaw-kaczynski-w-spale-donald-tusk-przezyl-w-nocy-przemi,nId,6877927](https://wydarzenia.interia.pl/lodzkie/news-jaroslaw-kaczynski-w-spale-donald-tusk-przezyl-w-nocy-przemi,nId,6877927)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T09:16:38+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-jaroslaw-kaczynski-w-spale-donald-tusk-przezyl-w-nocy-przemi,nId,6877927"><img align="left" alt="Jarosław Kaczyński w Spale: Donald Tusk przeżył w nocy przemianę " src="https://i.iplsc.com/jaroslaw-kaczynski-w-spale-donald-tusk-przezyl-w-nocy-przemi/000HCPOE03G2VAR1-C321.jpg" /></a>- Spotykamy się w szczególnym dniu, w którym polityka polska osiągnęła nowy poziom. Kłamstwo kampanii naszych przeciwników szalało od miesięcy, od lat. Dziś mamy jednak coś zupełnie nowego. O ósmej rano został opublikowany wpis Donalda Tuska, w którym okazuje się, że przeżył on w nocy kolejną przemianę duchową - mówił wicepremier Jarosław Kaczyński w Spale. Odniósł się tym samym do nagrania lidera PO, w którym powiedział, że &quot;Polacy muszą odzyskać kontrolę nad państwem i jego granicami&quot;.</p><br clear="all" />

## Patryk Jaki o Donaldzie Tusku: Bezczelny kłamca
 - [https://wydarzenia.interia.pl/kraj/news-patryk-jaki-o-donaldzie-tusku-bezczelny-klamca,nId,6877943](https://wydarzenia.interia.pl/kraj/news-patryk-jaki-o-donaldzie-tusku-bezczelny-klamca,nId,6877943)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T08:56:44+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-patryk-jaki-o-donaldzie-tusku-bezczelny-klamca,nId,6877943"><img align="left" alt="Patryk Jaki o Donaldzie Tusku: Bezczelny kłamca " src="https://i.iplsc.com/patryk-jaki-o-donaldzie-tusku-bezczelny-klamca/000HCPOKHB70E39Y-C321.jpg" /></a>- Bezczelny kłamca. PO w PE głosowała za projektem, w którym KE co roku ustali liczbę imigrantów do przymusowej relokacji - oświadczył europoseł PiS Patryk Jaki w reakcji na słowa szefa PO Donalda Tuska, który zamieścił nagranie na Twitterze. Lider PO mówił w nim, że &quot;Kaczyński przygotowuje dokument, dzięki któremu do Polski przyjdzie jeszcze więcej imigrantów m.in. z Iranu, Kataru i Nigerii&quot;. 
</p><br clear="all" />

## Rozruchy we Francji. Mer podparyskiego miasta: Moja rodzina jest ranna
 - [https://wydarzenia.interia.pl/zagranica/news-rozruchy-we-francji-mer-podparyskiego-miasta-moja-rodzina-je,nId,6877926](https://wydarzenia.interia.pl/zagranica/news-rozruchy-we-francji-mer-podparyskiego-miasta-moja-rodzina-je,nId,6877926)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T08:23:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rozruchy-we-francji-mer-podparyskiego-miasta-moja-rodzina-je,nId,6877926"><img align="left" alt="Rozruchy we Francji. Mer podparyskiego miasta: Moja rodzina jest ranna" src="https://i.iplsc.com/rozruchy-we-francji-mer-podparyskiego-miasta-moja-rodzina-je/000HCPHAAE3A62ST-C321.jpg" /></a>We Francji wciąż trwają zamieszki po śmierci 17-letniego Nahela, zastrzelonego przez funkcjonariusza policji. &quot;Ta noc była szczytem hańby&quot; - napisał na Twitterze Vincent Jeanbrun, mer podparyskiego miasta L'Hay-les-Roses w departamencie Dolina Marny. Jak wyjaśnił, podczas rozruchów zaatakowany został jego dom, a &quot;żona i jedno z małych dzieci zostali ranni podczas ucieczki&quot;. Prokuratura wszczęła śledztwo w sprawie usiłowania zabójstwa.</p><br clear="all" />

## Zełenski "o ogromnych stratach" Grupy Wagnera: 21 tys. najemników nie żyje
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-o-ogromnych-stratach-grupy-wagnera-21-tys-najemniko,nId,6877898](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-o-ogromnych-stratach-grupy-wagnera-21-tys-najemniko,nId,6877898)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T08:12:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-o-ogromnych-stratach-grupy-wagnera-21-tys-najemniko,nId,6877898"><img align="left" alt="Zełenski &quot;o ogromnych stratach&quot; Grupy Wagnera: 21 tys. najemników nie żyje" src="https://i.iplsc.com/zelenski-o-ogromnych-stratach-grupy-wagnera-21-tys-najemniko/000H7LUWLAJX5SOY-C321.jpg" /></a>Co najmniej 21 tys. najemników z Grupy Wagnera miało zginąć w walkach w Ukrainie, a kolejnych 80 tys. zostało rannych - takie dane podał podczas sobotniej konferencji prasowej Wołodymyr Zełenski. Ukraiński prezydent dodał także, że prywatna firma wojskowa poniosła &quot;ogromne straty&quot;, szczególnie na wschodzie Ukrainy, gdzie walczyła jej &quot;najsilniejsza grupa&quot;.</p><br clear="all" />

## Zderzenie dwóch samolotów wojskowych. Zginął jeden z pilotów
 - [https://wydarzenia.interia.pl/zagranica/news-zderzenie-dwoch-samolotow-wojskowych-zginal-jeden-z-pilotow,nId,6877912](https://wydarzenia.interia.pl/zagranica/news-zderzenie-dwoch-samolotow-wojskowych-zginal-jeden-z-pilotow,nId,6877912)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T07:56:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zderzenie-dwoch-samolotow-wojskowych-zginal-jeden-z-pilotow,nId,6877912"><img align="left" alt="Zderzenie dwóch samolotów wojskowych. Zginął jeden z pilotów" src="https://i.iplsc.com/zderzenie-dwoch-samolotow-wojskowych-zginal-jeden-z-pilotow/000HCPF4M2EU4XFC-C321.jpg" /></a>Podczas ćwiczeń wojskowych w Kolumbii zderzyły się dwa samoloty. Zginął pułkownik sił powietrznych Mario Andres Espinosa Gonzalez, który leciał jedną z maszyn. Drugi pilot przebywa ranny w szpitalu. </p><br clear="all" />

## Sondaż: Główny temat kampanii wyborczej? Walka z inflacją
 - [https://wydarzenia.interia.pl/kraj/news-sondaz-glowny-temat-kampanii-wyborczej-walka-z-inflacja,nId,6877910](https://wydarzenia.interia.pl/kraj/news-sondaz-glowny-temat-kampanii-wyborczej-walka-z-inflacja,nId,6877910)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T07:23:23+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sondaz-glowny-temat-kampanii-wyborczej-walka-z-inflacja,nId,6877910"><img align="left" alt="Sondaż: Główny temat kampanii wyborczej? Walka z inflacją" src="https://i.iplsc.com/sondaz-glowny-temat-kampanii-wyborczej-walka-z-inflacja/000FSO7FF7NPM181-C321.jpg" /></a>To walka z inflacją powinna być tematem kampanii wyborczej przed wyborami do Sejmu - uważa 37 proc. uczestników najnowszego sondażu. Oprócz tego dla ankietowanych ważna jest także kwestia kondycji gospodarki, stanu praworządności w Polsce, jak również reformy systemu ochrony zdrowia. </p><br clear="all" />

## Nowe nagranie D. Tuska o imigrantach. Mówi o dokumencie prezesa PiS
 - [https://wydarzenia.interia.pl/kraj/news-d-tusk-i-b-szydlo-przerzucaja-sie-oskarzeniami-paryz-w-warsz,nId,6877901](https://wydarzenia.interia.pl/kraj/news-d-tusk-i-b-szydlo-przerzucaja-sie-oskarzeniami-paryz-w-warsz,nId,6877901)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T07:10:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-d-tusk-i-b-szydlo-przerzucaja-sie-oskarzeniami-paryz-w-warsz,nId,6877901"><img align="left" alt="Nowe nagranie D. Tuska o imigrantach. Mówi o dokumencie prezesa PiS" src="https://i.iplsc.com/nowe-nagranie-d-tuska-o-imigrantach-mowi-o-dokumencie-prezes/000HCPBB79NJRA3K-C321.jpg" /></a> - Oglądamy wstrząśnięci sceny z brutalnych zamieszek we Francji. Teraz (Jarosław - red.) Kaczyński przygotowuje dokument, dzięki któremu do Polski przyjdzie jeszcze więcej obywateli z państw, takich jak: Arabia Saudyjska, Indie, Islamska Republika Iranu, Katar, Emiraty Arabskie, Nigeria czy Islamska Republika Pakistanu - powiedział lider PO Donald Tusk na nagraniu. Opowiedział tym samym na zarzuty Beaty Szydło, która stwierdziła, że na widok zamieszek we Francji &quot;Donald Tusk i reszta polityków Platformy się gdzieś pochowała&quot;. - Jak się...</p><br clear="all" />

## 187 osób próbowało dostać się nielegalnie z Białorusi do Polski
 - [https://wydarzenia.interia.pl/kraj/news-187-osob-probowalo-dostac-sie-nielegalnie-z-bialorusi-do-pol,nId,6877904](https://wydarzenia.interia.pl/kraj/news-187-osob-probowalo-dostac-sie-nielegalnie-z-bialorusi-do-pol,nId,6877904)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T06:52:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-187-osob-probowalo-dostac-sie-nielegalnie-z-bialorusi-do-pol,nId,6877904"><img align="left" alt="187 osób próbowało dostać się nielegalnie z Białorusi do Polski" src="https://i.iplsc.com/187-osob-probowalo-dostac-sie-nielegalnie-z-bialorusi-do-pol/000HCPAJ07X63U2R-C321.jpg" /></a>Dwóch Sudańczyków przeprawiło się przez rzekę Wołkuszankę, a w sumie 187 cudzoziemców próbowało dostać się nielegalnie z Białorusi do Polski, to m.in. obywatele Somalii i Iranu. 45 z tych osób na widok polskich patroli zawróciło na Białoruś - podała Straż Graniczna w raporcie z minionej doby. </p><br clear="all" />

## Średnio 13 gwałtownych zjawisk dziennie. "Włoski klimat staje się tropikalny"
 - [https://wydarzenia.interia.pl/zagranica/news-srednio-13-gwaltownych-zjawisk-dziennie-wloski-klimat-staje-,nId,6876555](https://wydarzenia.interia.pl/zagranica/news-srednio-13-gwaltownych-zjawisk-dziennie-wloski-klimat-staje-,nId,6876555)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T06:16:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-srednio-13-gwaltownych-zjawisk-dziennie-wloski-klimat-staje-,nId,6876555"><img align="left" alt="Średnio 13 gwałtownych zjawisk dziennie. &quot;Włoski klimat staje się tropikalny&quot;" src="https://i.iplsc.com/srednio-13-gwaltownych-zjawisk-dziennie-wloski-klimat-staje/000HCOACW9K63YJV-C321.jpg" /></a>Średnio 13 gwałtownych zjawisk dziennie - szacują eksperci, którzy podsumowali anomalie pogodowe na terenie Włoch. Burze, bomby wodne, trąby powietrzne - wyliczają, informując o pogodowej pladze. 
</p><br clear="all" />

## Setki aresztowanych, płonące auta, użyto gazu łzawiącego. "Noc była spokojniejsza"
 - [https://wydarzenia.interia.pl/zagranica/news-blisko-500-aresztowanych-we-francji-noc-byla-spokojniejsza-a,nId,6877889](https://wydarzenia.interia.pl/zagranica/news-blisko-500-aresztowanych-we-francji-noc-byla-spokojniejsza-a,nId,6877889)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T06:03:18+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-blisko-500-aresztowanych-we-francji-noc-byla-spokojniejsza-a,nId,6877889"><img align="left" alt="Setki aresztowanych, płonące auta, użyto gazu łzawiącego. &quot;Noc była spokojniejsza&quot;" src="https://i.iplsc.com/setki-aresztowanych-plonace-auta-uzyto-gazu-lzawiacego-noc-b/000HCP6YLAMCRXBT-C321.jpg" /></a>Do godziny 3:30 we Francji aresztowano 486 osób. &quot;Ta noc była spokojniejsza dzięki zdecydowanej akcji policji&quot; - napisał na Twitterze minister spraw wewnętrznych Gerald Darmanin. Szczególnie niepokojąco było w Marsylii, w której policja użyła wobec protestujących gazu łzawiącego.  </p><br clear="all" />

## Setki aresztowanych, płonące auta, użyto gazu łzawiącego. "Noc była spokojniejsza"
 - [https://wydarzenia.interia.pl/zagranica/news-setki-aresztowanych-we-francji-577-spalonych-aut-i-74-budynk,nId,6877889](https://wydarzenia.interia.pl/zagranica/news-setki-aresztowanych-we-francji-577-spalonych-aut-i-74-budynk,nId,6877889)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T06:03:18+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-setki-aresztowanych-we-francji-577-spalonych-aut-i-74-budynk,nId,6877889"><img align="left" alt="Setki aresztowanych, płonące auta, użyto gazu łzawiącego. &quot;Noc była spokojniejsza&quot;" src="https://i.iplsc.com/setki-aresztowanych-plonace-auta-uzyto-gazu-lzawiacego-noc-b/000HCP6YLAMCRXBT-C321.jpg" /></a>&quot;Ta noc była spokojniejsza dzięki zdecydowanej akcji policji&quot; - napisał na Twitterze minister spraw wewnętrznych Gerald Darmanin. Szczególnie niepokojąco było w Marsylii, w której policja użyła wobec protestujących gazu łzawiącego. MSW w niedzielę rano podało, że w nocy aresztowano 719 osób. </p><br clear="all" />

## Królowa wysp Jońskich. Dlaczego warto jechać na Korfu?
 - [https://wydarzenia.interia.pl/ciekawostki/news-krolowa-wysp-jonskich-dlaczego-warto-jechac-na-korfu,nId,6874173](https://wydarzenia.interia.pl/ciekawostki/news-krolowa-wysp-jonskich-dlaczego-warto-jechac-na-korfu,nId,6874173)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T05:14:00+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-krolowa-wysp-jonskich-dlaczego-warto-jechac-na-korfu,nId,6874173"><img align="left" alt="Królowa wysp Jońskich. Dlaczego warto jechać na Korfu?" src="https://i.iplsc.com/krolowa-wysp-jonskich-dlaczego-warto-jechac-na-korfu/000HCI40ANGB9BUC-C321.jpg" /></a>Porośnięta bujną roślinnością, otoczona turkusową wodą, z malowniczym wybrzeżem - nie bez powodu Korfu, a właściwie Kerkyra, nazywana jest &quot;królową Wysp Jońskich&quot;. Swoim urokiem i różnorodnością co roku przyciąga wielu turystów. To bez wątpienia jedna z najpiękniejszych greckich wysp, którą warto odwiedzić tego lata.</p><br clear="all" />

## Wypadek na skuterze wodnym. Nie żyje sześciolatka
 - [https://wydarzenia.interia.pl/zagranica/news-wypadek-na-skuterze-wodnym-nie-zyje-szesciolatka,nId,6876550](https://wydarzenia.interia.pl/zagranica/news-wypadek-na-skuterze-wodnym-nie-zyje-szesciolatka,nId,6876550)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T05:07:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wypadek-na-skuterze-wodnym-nie-zyje-szesciolatka,nId,6876550"><img align="left" alt="Wypadek na skuterze wodnym. Nie żyje sześciolatka " src="https://i.iplsc.com/wypadek-na-skuterze-wodnym-nie-zyje-szesciolatka/000HCO6VH1PF35I5-C321.jpg" /></a>Nie żyje sześciolatka z Ukrainy, która uczestniczyła w zderzeniu skuterów wodnych. Po wyciągnięciu z morza dziewczynka została przetransportowana karetką do szpitala. Powodem śmierci było zatrzymanie akcji serca. </p><br clear="all" />

## Rumunia: 40 pracowników rosyjskiej ambasady opuściło Bukareszt
 - [https://wydarzenia.interia.pl/zagranica/news-rumunia-40-pracownikow-rosyjskiej-ambasady-opuscilo-bukaresz,nId,6877888](https://wydarzenia.interia.pl/zagranica/news-rumunia-40-pracownikow-rosyjskiej-ambasady-opuscilo-bukaresz,nId,6877888)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T05:03:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rumunia-40-pracownikow-rosyjskiej-ambasady-opuscilo-bukaresz,nId,6877888"><img align="left" alt="Rumunia: 40 pracowników rosyjskiej ambasady opuściło Bukareszt" src="https://i.iplsc.com/rumunia-40-pracownikow-rosyjskiej-ambasady-opuscilo-bukaresz/000HCP54E11294TR-C321.jpg" /></a>Po decyzji rumuńskich władz 40 pracowników ambasady Federacji Rosyjskiej opuściło Bukareszt, odlatując w sobotę wieczorem do Moskwy. To efekt redukcji personelu tej placówki dyplomatycznej w związku z rosyjską inwazją na Ukrainę i pogorszeniem relacji bilateralnych.</p><br clear="all" />

## Kolejny nocny atak rakietowy na Kijów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kolejny-nocny-atak-rakietowy-na-kijow,nId,6877885](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kolejny-nocny-atak-rakietowy-na-kijow,nId,6877885)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-07-02T04:25:07+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kolejny-nocny-atak-rakietowy-na-kijow,nId,6877885"><img align="left" alt="Kolejny nocny atak rakietowy na Kijów" src="https://i.iplsc.com/kolejny-nocny-atak-rakietowy-na-kijow/000H7HP3TEG6FN2C-C321.jpg" /></a>W nocy z soboty na niedzielę doszło do rosyjskiego ataku rakietowego na Kijów. W obwodzie kijowskim i kilku innych obwodach środkowej i wschodniej Ukrainy ogłoszone zostały ok. 2 nad ranem czasu lokalnego alarmy przeciwlotnicze. To pierwszy od 12 dni atak przy użyciu dronów na ukraińską stolicę. </p><br clear="all" />

