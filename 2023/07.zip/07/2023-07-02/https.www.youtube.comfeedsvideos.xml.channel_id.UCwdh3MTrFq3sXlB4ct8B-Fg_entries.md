# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## This Week in Warhammer – The Lion Returns! Again!
 - [https://www.youtube.com/watch?v=MUEK7uc-ZDg](https://www.youtube.com/watch?v=MUEK7uc-ZDg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-02T17:00:09+00:00

Legendary characters prepare to re-enter the fray – check out this week's Warhammer highlights. https://bit.ly/3XvD2Da

