# Source:The Wall Street Journal, URL:https://feeds.a.dj.com/rss/RSSWorldNews.xml, language:en-US

## More &raquo;
 - [https://www.wsj.com/articles/more-amp-raquo-a4ecc9ab](https://www.wsj.com/articles/more-amp-raquo-a4ecc9ab)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T23:07:00+00:00

The mysteriously financed group that could upend a Biden-Trump rematch

## More &raquo;
 - [https://www.wsj.com/articles/more-amp-raquo-8e84d8e2](https://www.wsj.com/articles/more-amp-raquo-8e84d8e2)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T21:02:00+00:00

Putin is now trying to take control of a corporate monster he helped create

## Pepper...and Salt
 - [https://www.wsj.com/articles/pepper-and-salt-bfce7a77](https://www.wsj.com/articles/pepper-and-salt-bfce7a77)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T20:25:00+00:00

Pepper...and Salt

## Will Donald Trump Duck the GOP Debates?
 - [https://www.wsj.com/articles/will-donald-trump-duck-the-gop-debates-2024-rnc-public-opinion-rival-desantis-261b70aa](https://www.wsj.com/articles/will-donald-trump-duck-the-gop-debates-2024-rnc-public-opinion-rival-desantis-261b70aa)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T20:04:00+00:00

If he refuses to meet his rivals on stage, voters will be entitled to wonder what he’s afraid of.

## The Next Supreme Court Landmark
 - [https://www.wsj.com/articles/the-next-supreme-court-landmark-sec-jarkesy-separation-of-powers-bb7ff634](https://www.wsj.com/articles/the-next-supreme-court-landmark-sec-jarkesy-separation-of-powers-bb7ff634)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T20:02:00+00:00

The Justices agree to hear a case challenging the constitutionality of SEC administrative law judges.

## Khan Rewrites the Merger Rulebook
 - [https://www.wsj.com/articles/lina-khan-federal-trade-commission-antitrust-merger-filing-requirements-8eaaec94](https://www.wsj.com/articles/lina-khan-federal-trade-commission-antitrust-merger-filing-requirements-8eaaec94)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:59:00+00:00

The FTC’s new filing demands will give the agency more time and ammunition to block tie-ups.

## 'The Bathysphere Book' Review: The Descent of William Beebe
 - [https://www.wsj.com/articles/the-bathysphere-book-review-the-descent-of-william-beebe-4833d4ae](https://www.wsj.com/articles/the-bathysphere-book-review-the-descent-of-william-beebe-4833d4ae)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:43:00+00:00

Nearly a century before the Titan implosion, the American naturalist traveled half a mile under the sea in a steel orb.

## Volodymyr Zelensky: Happy Birthday, America
 - [https://www.wsj.com/articles/volodymyr-zelensky-happy-birthday-america-ukraine-freedom-fourth-of-july-24bafddf](https://www.wsj.com/articles/volodymyr-zelensky-happy-birthday-america-ukraine-freedom-fourth-of-july-24bafddf)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:42:00+00:00

Ukraine is grateful to the U.S. for providing both support for and an example of liberty.

## Bruen Transforms the Gun Debate
 - [https://www.wsj.com/articles/bruen-transforms-the-gun-debate-thomas-second-amendment-restrictions-text-history-b50104f6](https://www.wsj.com/articles/bruen-transforms-the-gun-debate-thomas-second-amendment-restrictions-text-history-b50104f6)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:41:00+00:00

The case established a constitutional right to carry pistols in public for self-defense.

## Russia's Many Spies in Mexico
 - [https://www.wsj.com/articles/russias-many-spies-in-mexico-war-global-power-network-putin-south-america-b4b3659f](https://www.wsj.com/articles/russias-many-spies-in-mexico-war-global-power-network-putin-south-america-b4b3659f)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:40:00+00:00

Team Putin is quietly fueling antidemocratic ideology in the region.

## Hunter Biden and the Media's Terms of Evasion
 - [https://www.wsj.com/articles/the-media-is-covering-for-hunter-biden-nyt-bias-tax-investigation-justice-irs-5ea08c29](https://www.wsj.com/articles/the-media-is-covering-for-hunter-biden-nyt-bias-tax-investigation-justice-irs-5ea08c29)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:39:00+00:00

What’s going on is ‘unclear,’ but ‘Republicans pounce’ anyway.

## Biden and the OECD's Taxation Without Representation
 - [https://www.wsj.com/articles/biden-and-the-oecds-taxation-without-representation-pillar-2-oecd-congress-670cd2fa](https://www.wsj.com/articles/biden-and-the-oecds-taxation-without-representation-pillar-2-oecd-congress-670cd2fa)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:38:00+00:00

Congress refused to enact the Pillar 2 agreement that requires all countries to tax large corporations.

## Notable & Quotable: Harvard and Asian Americans
 - [https://www.wsj.com/articles/notable-quotable-harvard-and-asian-americans-diversity-affirmative-action-race-a5e30c3f](https://www.wsj.com/articles/notable-quotable-harvard-and-asian-americans-diversity-affirmative-action-race-a5e30c3f)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:35:00+00:00

‘It’s hard not to read [Justice Sotomayor’s opinion] as a premise for Asian American teen-agers to essentially dance for acceptance.’

## Dividend-Paying Stocks Spurned as AI Booms
 - [https://www.wsj.com/articles/dividend-paying-stocks-spurned-as-ai-booms-15a8996e](https://www.wsj.com/articles/dividend-paying-stocks-spurned-as-ai-booms-15a8996e)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:30:00+00:00

The shares have suffered their worst first-half performance relative to nonpayers since 2009, as investors now see greater promise in growth-focused tech stocks that don’t typically pay dividends.

## Putin's Corporate Takeover of Wagner Has Begun
 - [https://www.wsj.com/articles/putin-russia-wagner-prigozhin-cc5da1b0](https://www.wsj.com/articles/putin-russia-wagner-prigozhin-cc5da1b0)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T19:20:00+00:00

In the wake of a mutiny that almost reached Moscow, Vladimir Putin is facing a new test—managing one of the most complex corporate takeovers in history.

## It's Old Man Summer in Hollywood
 - [https://www.wsj.com/articles/its-old-man-summer-in-hollywood-900e33ba](https://www.wsj.com/articles/its-old-man-summer-in-hollywood-900e33ba)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T17:32:00+00:00

Harrison Ford, Tom Cruise, Denzel Washington and other actors of a certain age will be in theaters near you this summer—again.

## Southern California Hotel Workers Strike Ahead of Fourth of July
 - [https://www.wsj.com/articles/southern-california-hotel-workers-strike-ahead-of-fourth-of-july-963fd4e6](https://www.wsj.com/articles/southern-california-hotel-workers-strike-ahead-of-fourth-of-july-963fd4e6)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T17:16:00+00:00

Thousands of hotel employees walked off the job Sunday demanding better pay and benefits, and less burdensome workloads.

## Calling Hunter Prosecutor David Weiss
 - [https://www.wsj.com/articles/calling-hunter-prosecutor-david-weiss-shapley-biden-irs-justice-tax-4d500805](https://www.wsj.com/articles/calling-hunter-prosecutor-david-weiss-shapley-biden-irs-justice-tax-4d500805)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T17:02:00+00:00

House investigators have some questions for the U.S. Attorney, who so far isn’t cooperating.

## Is Your Company's DEI Program Lawful?
 - [https://www.wsj.com/articles/is-your-companys-dei-program-lawful-business-title-vii-race-affirmative-action-harvard-cd4d9582](https://www.wsj.com/articles/is-your-companys-dei-program-lawful-business-title-vii-race-affirmative-action-harvard-cd4d9582)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T16:23:00+00:00

The Supreme Court’s ruling against affirmative action has implications beyond the ivory tower.

## What Biden's 'Invest in America' Tour Leaves Out
 - [https://www.wsj.com/articles/what-bidens-invest-in-america-tour-leaves-out-ohio-midwest-subsidies-green-energy-d7c21d9](https://www.wsj.com/articles/what-bidens-invest-in-america-tour-leaves-out-ohio-midwest-subsidies-green-energy-d7c21d9)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T16:22:00+00:00

His policies have destroyed many good jobs while ensuring that industries need welfare to survive.

## A Child-Trafficking Thriller Is Taking on Hollywood. Who's Behind It?
 - [https://www.wsj.com/articles/sound-of-freedom-jim-caviezel-857639bf](https://www.wsj.com/articles/sound-of-freedom-jim-caviezel-857639bf)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T15:00:00+00:00

In ‘Sound of Freedom’ Jim Caviezel is an ex-agent on the hunt for missing children. It’s the first crime thriller for Angel Studios, which made its reputation with biblical stories.

## Leveraged-Loan Logjam Eases After Banks Unload Tens of Billions of Debt
 - [https://www.wsj.com/articles/leveraged-loan-logjam-eases-after-banks-unload-tens-of-billions-of-debt-122e652b](https://www.wsj.com/articles/leveraged-loan-logjam-eases-after-banks-unload-tens-of-billions-of-debt-122e652b)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T15:00:00+00:00

Banks have sold off tens of billions of leveraged-buyout debt that was gumming up their lending operations, raising hopes that a critical business on Wall Street is returning to normal.

## Tyson Foods to Drop 'No Antibiotics Ever' Label on Some Chicken Products
 - [https://www.wsj.com/articles/tyson-foods-to-drop-no-antibiotics-ever-label-on-some-chicken-products-13f417cf](https://www.wsj.com/articles/tyson-foods-to-drop-no-antibiotics-ever-label-on-some-chicken-products-13f417cf)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T15:00:00+00:00

The move will involve drugs that aren’t important to human health and will apply to all fresh, frozen and ready-made products under the Tyson brand.

## No More Racial Discrimination in College Admissions
 - [https://www.wsj.com/articles/affirmative-action-supreme-court-college-admissions-race-22a7e993](https://www.wsj.com/articles/affirmative-action-supreme-court-college-admissions-race-22a7e993)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:49:00+00:00

Universities shouldn’t have to use race to cover for the failures of K-12 schools.

## What the Israeli Left Would Rather Forget
 - [https://www.wsj.com/articles/simcha-rothman-israel-judicial-reform-religious-right-left-c7798407](https://www.wsj.com/articles/simcha-rothman-israel-judicial-reform-religious-right-left-c7798407)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:48:00+00:00

It has abandoned its prior proposals for judicial reform because the religious right now proposes them.

## Build Up the Merchant Marine Before It's Too Late
 - [https://www.wsj.com/articles/us-merchant-marine-china-naval-maritime-build-up-2616e5ef](https://www.wsj.com/articles/us-merchant-marine-china-naval-maritime-build-up-2616e5ef)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:47:00+00:00

China is taking its naval and maritime fleet seriously.

## No Defense for How Trump Stored and Shared Documents
 - [https://www.wsj.com/articles/trump-indictment-classified-documents-boxes-80a10334](https://www.wsj.com/articles/trump-indictment-classified-documents-boxes-80a10334)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:46:00+00:00

Even if the former president had a right to keep some of them.

## Once the Dust Settles, the Majority Will Get Its Way on Abortion
 - [https://www.wsj.com/articles/abortion-law-polls-pro-life-choice-weeks-89a46119](https://www.wsj.com/articles/abortion-law-polls-pro-life-choice-weeks-89a46119)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:45:00+00:00

Most Americans believe it should be legal but with specified limits.

## Playing the Gentleman's Game
 - [https://www.wsj.com/articles/golf-the-gentlemans-game-grass-water-11e864](https://www.wsj.com/articles/golf-the-gentlemans-game-grass-water-11e864)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:44:00+00:00

Golf is about working with the land? News to me.

## Behind French Riots Lie Years of Anger Over Police Conduct
 - [https://www.wsj.com/articles/behind-french-riots-lie-years-of-anger-over-police-conduct-95df6c4d](https://www.wsj.com/articles/behind-french-riots-lie-years-of-anger-over-police-conduct-95df6c4d)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:39:00+00:00

Law-enforcement tactics that once remained in the shadows are now surfacing in videos, prompting investigations and inflaming the public.

## Two Killed, Dozens Injured in Baltimore Block Party Shooting
 - [https://www.wsj.com/articles/two-killed-dozens-injured-in-baltimore-block-party-shooting-df365422](https://www.wsj.com/articles/two-killed-dozens-injured-in-baltimore-block-party-shooting-df365422)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:39:00+00:00

The mass shooting early Sunday left 28 people injured, police said.

## These Two Americans Cracked Wimbledon's Top 10. Could Either Be a Djokovic Spoiler?
 - [https://www.wsj.com/articles/wimbledon-taylor-fritz-frances-tiafoe-djokovic-cf5df6f2](https://www.wsj.com/articles/wimbledon-taylor-fritz-frances-tiafoe-djokovic-cf5df6f2)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:18:00+00:00

Taylor Fritz and Frances Tiafoe are longtime friends and supportive rivals chasing the same goal. A breakthrough awaits.

## Departing CDC Director Warns of Politicized Science
 - [https://www.wsj.com/articles/cdc-director-rochelle-walensky-politicization-science-9c291c7e](https://www.wsj.com/articles/cdc-director-rochelle-walensky-politicization-science-9c291c7e)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:00:00+00:00

Stepping down after 2 1/2 years, Dr. Rochelle Walensky says that public health shouldn’t fall along partisan lines and that the public should be wary of misinformation.

## Missouri Parents Can Be Jailed if Their Kids Aren't in School Regularly
 - [https://www.wsj.com/articles/missouri-parents-can-be-jailed-if-their-kids-arent-in-school-regularly-3b4588b1](https://www.wsj.com/articles/missouri-parents-can-be-jailed-if-their-kids-arent-in-school-regularly-3b4588b1)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T14:00:00+00:00

Two moms question what “regularly” means in a case before the state’s Supreme Court.

## More &raquo;
 - [https://www.wsj.com/articles/more-amp-raquo-47972215](https://www.wsj.com/articles/more-amp-raquo-47972215)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T13:17:00+00:00

There&amp;#x27;s a new $699 machine for those in search of the perfect cup of coffee

## Big Banks Stay Cautious as Stress Doesn't End With a Test
 - [https://www.wsj.com/articles/big-banks-stay-cautious-as-stress-doesnt-end-with-a-test-b19ad0f1](https://www.wsj.com/articles/big-banks-stay-cautious-as-stress-doesnt-end-with-a-test-b19ad0f1)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T13:00:00+00:00

The largest banks fared relatively well in the Federal Reserve’s stress scenarios, but they are still being conservative with buybacks.

## Crypto Miners Seek a New Life in AI Boom After an Implosion in Mining
 - [https://www.wsj.com/articles/crypto-miners-seek-a-new-life-in-ai-boom-after-an-implosion-in-mining-92a181fd](https://www.wsj.com/articles/crypto-miners-seek-a-new-life-in-ai-boom-after-an-implosion-in-mining-92a181fd)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T13:00:00+00:00

Demand for high-end chips allows cryptocurrency companies to repurpose idle equipment.

## Who Should Buy a Folding Phone
 - [https://www.wsj.com/articles/who-should-buy-a-folding-phone-2f658969](https://www.wsj.com/articles/who-should-buy-a-folding-phone-2f658969)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T13:00:00+00:00

Google’s new Pixel Fold and Samsung’s Galaxy Fold are video-streaming machines for long-haul commuters.

## Widespread Drought Creates Winners and Losers in U.S. Agriculture
 - [https://www.wsj.com/articles/widespread-drought-creates-winners-and-losers-in-u-s-agriculture-3c0834ed](https://www.wsj.com/articles/widespread-drought-creates-winners-and-losers-in-u-s-agriculture-3c0834ed)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T13:00:00+00:00

Meat and dairy companies could face higher feed costs, while grain shippers and farm suppliers might reap gains.

## Recent Deals Fail to Spark Lackluster IPO Market
 - [https://www.wsj.com/articles/recent-deals-fail-to-spark-lackluster-ipo-market-580e9b1c](https://www.wsj.com/articles/recent-deals-fail-to-spark-lackluster-ipo-market-580e9b1c)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T12:00:00+00:00

The new-issue market is still in recovery mode, as shaky receptions for three initial public offerings last week showed.

## Student Borrowers Must Now Pay After Three-Year Reprieve
 - [https://www.wsj.com/articles/student-borrowers-after-three-year-reprieve-must-now-pay-be6ddb2d](https://www.wsj.com/articles/student-borrowers-after-three-year-reprieve-must-now-pay-be6ddb2d)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T11:00:00+00:00

Changes in the loan system may complicate repayment efforts following last week’s Supreme Court ruling.

## A Vampire Creature in the Great Lakes Is Scaring Fishermen and Tourists---'Like Science Fiction'
 - [https://www.wsj.com/articles/great-lakes-fishing-lamprey-invasive-science-fiction-d3992c77](https://www.wsj.com/articles/great-lakes-fishing-lamprey-invasive-science-fiction-d3992c77)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T10:58:00+00:00

Bloodsucking sea lampreys, with creepy teeth, make a comeback. ‘People just freak.’

## Heavy Police Presence in Paris Amid Protests
 - [https://www.wsj.com/articles/heavy-police-presence-in-paris-amid-protests-e8ab5e1b](https://www.wsj.com/articles/heavy-police-presence-in-paris-amid-protests-e8ab5e1b)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T10:12:00+00:00

Tens of thousands of police were deployed in cities across France Saturday night as unrest continued over the fatal police shooting of a teenager. Officials said law enforcement action led to a “calmer night” with 719 arrests nationwide.

## Mark Cavendish Returns for a Last Tour---and Maybe an Untouchable Record
 - [https://www.wsj.com/articles/mark-cavendish-tour-de-france-eddy-merckx-record-614ee84e](https://www.wsj.com/articles/mark-cavendish-tour-de-france-eddy-merckx-record-614ee84e)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T10:00:00+00:00

The British rider is tied with cycling legend Eddy Merckx for the race’s record for stage wins at 34. He has three weeks to find No. 35.

## Investors Spurn Dividend-Paying Stocks as AI Booms
 - [https://www.wsj.com/articles/investors-spurn-dividend-paying-stocks-as-ai-booms-344f431d](https://www.wsj.com/articles/investors-spurn-dividend-paying-stocks-as-ai-booms-344f431d)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T09:30:00+00:00

The shares have suffered their worst first-half performance relative to nonpayers since 2009.

## Tesla Deliveries to Show Whether Price Cuts Are Paying Off
 - [https://www.wsj.com/articles/tesla-deliveries-to-show-whether-price-cuts-are-paying-off-2f2aac93](https://www.wsj.com/articles/tesla-deliveries-to-show-whether-price-cuts-are-paying-off-2f2aac93)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T09:30:00+00:00

The electric-car maker is expected to release second-quarter global deliveries amid stiffening EV competition.

## The European Hot Spots Struggling With the Tourist Masses
 - [https://www.wsj.com/articles/theeuropean-hot-spots-struggling-with-the-tourist-masses-c40cc8a3](https://www.wsj.com/articles/theeuropean-hot-spots-struggling-with-the-tourist-masses-c40cc8a3)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T09:30:00+00:00

Booming tourist numbers are giving a welcome boost to Southern Europe’s economies but locals are increasingly asking how much their popular destinations can take.

## A Mysteriously Financed Group That Could Upend a Biden-Trump Rematch
 - [https://www.wsj.com/articles/a-mysteriously-financed-group-that-could-upend-a-biden-trump-rematch-d34ebaea](https://www.wsj.com/articles/a-mysteriously-financed-group-that-could-upend-a-biden-trump-rematch-d34ebaea)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T09:00:00+00:00

The centrist nonprofit group No Labels says voters want an alternative, but some say its efforts could hand the 2024 election to former President Donald Trump.

## Arts Calendar: Happenings for the Week of July 2
 - [https://www.wsj.com/articles/arts-calendar-happenings-for-the-week-of-july-2-airdigital-892281a4](https://www.wsj.com/articles/arts-calendar-happenings-for-the-week-of-july-2-airdigital-892281a4)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T09:00:00+00:00

Taylor Swift drops an album mid-tour, young adults go for a Chinese ‘Joy Ride,’ a doc tells the story of ’80s band Wham! and more.

## Brazil Worries It Has Become a Haven for Russian Spies Infiltrating the West
 - [https://www.wsj.com/articles/brazil-worries-it-has-become-a-haven-for-russian-spies-infiltrating-the-west-525021ba](https://www.wsj.com/articles/brazil-worries-it-has-become-a-haven-for-russian-spies-infiltrating-the-west-525021ba)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T04:01:00+00:00

Alleged agents posing as Brazilians have caught the eye of the U.S. and Norway—and could also be candidates in any prisoner exchange.

## How to Retire Better, From Retirees Who Learned the Hard Way
 - [https://www.wsj.com/articles/retirement-regrets-investments-relationships-b67a1080](https://www.wsj.com/articles/retirement-regrets-investments-relationships-b67a1080)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T04:01:00+00:00

Regrets offer insights that can help people think and plan better at every life stage.

## Market Bets on Cheaper Oil, Dashing Saudi Hopes for a Price Rebound
 - [https://www.wsj.com/articles/market-bets-on-cheaper-oil-dashing-saudi-hopes-for-a-price-rebound-b500ad72](https://www.wsj.com/articles/market-bets-on-cheaper-oil-dashing-saudi-hopes-for-a-price-rebound-b500ad72)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T04:01:00+00:00

The oil market has flashed a warning to Saudi Arabia: The world economy is weakening, and the kingdom’s efforts to boost prices have run into a wall of excess supply.

## Ukraine's Zelensky Seeks to Stay Strong---and Human
 - [https://www.wsj.com/articles/ukraines-zelensky-seeks-to-stay-strongand-human-5b2608e](https://www.wsj.com/articles/ukraines-zelensky-seeks-to-stay-strongand-human-5b2608e)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T04:01:00+00:00

In a few hours the Journal spent with him, the president spoke about remaining grounded, projecting strength and rejecting talks with Russia.

## More &raquo;
 - [https://www.wsj.com/articles/more-amp-raquo-f888f7f](https://www.wsj.com/articles/more-amp-raquo-f888f7f)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2023-07-02T01:05:00+00:00

People have figured out a way to torture telemarketers

