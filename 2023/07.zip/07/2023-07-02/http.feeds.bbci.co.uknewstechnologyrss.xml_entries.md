# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## How AI can help process waste and increase recycling
 - [https://www.bbc.co.uk/news/business-66042169?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66042169?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-07-02T23:12:17+00:00

Video cameras powered by AI are analysing work at waste processing and recycling facilities.

