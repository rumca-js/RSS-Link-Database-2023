# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## A Crypto Micronation’s Future Hangs on a Border Dispute
 - [https://www.wired.com/story/liberland-crypto-micronation-border-dispute/](https://www.wired.com/story/liberland-crypto-micronation-border-dispute/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-07-02T06:00:00+00:00

An ultra-libertarian Balkan “country” called Liberland celebrated its eighth anniversary with a boat party and a barbecue, but no one lives there.

