# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Indiana Jones & the Dial of Destiny Whips Up a Muted Box Office
 - [https://gizmodo.com/indiana-jones-dial-of-destiny-box-office-1850600198](https://gizmodo.com/indiana-jones-dial-of-destiny-box-office-1850600198)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-07-02T19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--10XR24S6--/c_fit,fl_progressive,q_80,w_636/4b49135b2bbeb3d91c7ca8428e788365.jpg" /><p>The month of June has been pretty crowded with one blockbuster (or <a href="https://gizmodo.com/open-channel-june-16-movie-weekend-1850551813">more</a>) releasing each week. Closing out June is Disney’s <a href="https://gizmodo.com/indiana-jones-5-review-harrison-ford-dial-of-destiny-1850518708"><em>Indiana Jones &amp; the Dial of Destiny</em></a><em>,</em> Harrison Ford’s first lead blockbuster role in years and his final portrayal of the role he’s inhabited since <em>Raiders of the Lost Ark </em>back in 1981. And for a…</p><p><a href="https://gizmodo.com/indiana-jones-dial-of-destiny-box-office-1850600198">Read more...</a></p>

## Back to the Future's Musical Has Warped to Broadway
 - [https://gizmodo.com/back-to-the-future-musical-broadway-previews-1850600111](https://gizmodo.com/back-to-the-future-musical-broadway-previews-1850600111)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-07-02T18:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ZXUHLQ3Q--/c_fit,fl_progressive,q_80,w_636/6af0d69e54d8da35b1b7b0031121ac49.jpg" /><p><a href="https://gizmodo.com/back-to-the-future-the-musical-original-soundtrack-hist-1848643490"><em>Back to the Future: The Musical</em></a><em> </em>is back...to the stage.</p><p><a href="https://gizmodo.com/back-to-the-future-musical-broadway-previews-1850600111">Read more...</a></p>

## Open Channel: Tell Us Your Thoughts on Indiana Jones & the Dial of Destiny
 - [https://gizmodo.com/open-channel-indiana-jones-dial-of-destiny-1850599999](https://gizmodo.com/open-channel-indiana-jones-dial-of-destiny-1850599999)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-07-02T17:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s---CIJiI4q--/c_fit,fl_progressive,q_80,w_636/1a04da5abf4f6ac26cc660e763e6cd91.jpg" /><p>The <a href="https://gizmodo.com/raiders-of-the-lost-ark-indiana-jones-harrison-ford-1850470399"><em>Indiana Jones </em>movies</a> are a deep part of the popular culture in a number of ways, from its fellow treasure hunter imitators <em>Tomb Raider </em>and <em>Uncharted </em>to how they’re partly responsible for Harrison Ford’s decades-long star power. While the first three movies are liked to varying degrees, 2008's <a href="https://gizmodo.com/indiana-jones-crystal-skull-rewatch-ford-spielberg-1850556502"><em>Indiana Jones &amp; the</em>…</a></p><p><a href="https://gizmodo.com/open-channel-indiana-jones-dial-of-destiny-1850599999">Read more...</a></p>

## One Piece's Japanese Cast Will Dub One Piece's Netflix Series
 - [https://gizmodo.com/one-piece-japanese-dub-netflix-series-1850599952](https://gizmodo.com/one-piece-japanese-dub-netflix-series-1850599952)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-07-02T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--FCGTgKOL--/c_fit,fl_progressive,q_80,w_636/beb6c4fd7cfb4eed08ebbd5959d3478f.jpg" /><p>The anime adaptation of <a href="https://gizmodo.com/one-piece-live-action-series-netflix-release-date-1850404038">Eiichiro Oda’s</a> <em>One Piece </em>has been going on for nearly 25 years, and is still finding ways to impress longtime fans of the franchise. With Netflix’s upcoming take, the aim is to recapture some of the magic that enchanted viewers back in 1999, but <a href="https://gizmodo.com/netflix-tudum-2023-nerdy-announcements-1850551016/slides/3">via live-action</a>  for new audiences. Those who’ve…</p><p><a href="https://gizmodo.com/one-piece-japanese-dub-netflix-series-1850599952">Read more...</a></p>

## Soft Robo-Glove Can Help Stroke Patients Relearn to Play Music
 - [https://gizmodo.com/soft-robo-glove-can-help-stroke-patients-relearn-to-pla-1850590832](https://gizmodo.com/soft-robo-glove-can-help-stroke-patients-relearn-to-pla-1850590832)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-07-02T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--9xtNobzC--/c_fit,fl_progressive,q_80,w_636/87886c4fe8f520ebbf208a580fbb53e2.jpg" /><p>Researchers have developed the prototype of a comfortable and flexible “soft smart hand exoskeleton,” or robo-glove, which gives feedback to wearers who need to relearn tasks that require manual dexterity and coordination, for example after suffering a stroke. The present study focused on patients who need to relearn…</p><p><a href="https://gizmodo.com/soft-robo-glove-can-help-stroke-patients-relearn-to-pla-1850590832">Read more...</a></p>

## Netflix's Pokémon Concierge Looks Like Well Worth the Visit
 - [https://gizmodo.com/pokemon-concierge-anime-dwarf-studios-netflix-1850599418](https://gizmodo.com/pokemon-concierge-anime-dwarf-studios-netflix-1850599418)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-07-02T14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Qt9ZNv2b--/c_fit,fl_progressive,q_80,w_636/4d8fc9cca90e7f0523ba9c3a98cfced7.png" /><p>Throughout the decades, Nintendo’s <a href="https://gizmodo.com/pokemon-new-anime-title-release-date-trailer-horizons-1850261543">Pokémon franchise</a> has portrayed the titular pocket monsters in one of three typical ways: they’re either pets, natural extensions of every day life, or forces of nature whose existence can sometimes be <a href="https://gizmodo.com/pokemon-legends-arceus-newest-monsters-might-be-killer-1847908573">a little messed up</a>. And when they aren’t one of those, they’re off doing their own…</p><p><a href="https://gizmodo.com/pokemon-concierge-anime-dwarf-studios-netflix-1850599418">Read more...</a></p>

## Ibai Slams Twitch for Outages During His Record-Breaking 3.4 Million Viewer Stream
 - [https://gizmodo.com/ibai-twitch-outages-la-velada-del-ano-3-boxing-1850599861](https://gizmodo.com/ibai-twitch-outages-la-velada-del-ano-3-boxing-1850599861)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-07-02T13:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--EOQ2c0RI--/c_fit,fl_progressive,q_80,w_636/efe78e1a785515845fe56f3a0621d08c.jpg" /><p>Twitch megastar <a href="https://gizmodo.com/ibai-sells-out-la-velada-del-ano-iii-twitch-boxing-1850407725">Ibai Llanos</a> slammed the platform for outages during his annual streamer vs. streamer boxing match, which broke Twitch’s world viewing records three times in a single stream on Saturday. At one point, Llanos’ channel reached a peak of nearly 3.45 million concurrent viewers. </p><p><a href="https://gizmodo.com/ibai-twitch-outages-la-velada-del-ano-3-boxing-1850599861">Read more...</a></p>

## AI Fatalism Won't Help Us Deal With Its Actual Risks
 - [https://gizmodo.com/ai-chatgpt-fatalism-wont-help-us-with-its-actual-risks-1850585699](https://gizmodo.com/ai-chatgpt-fatalism-wont-help-us-with-its-actual-risks-1850585699)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-07-02T13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--aJKBfZeO--/c_fit,fl_progressive,q_80,w_636/18bbbad9fcd320563439e16c0595ecab.jpg" /><p>Over the past few months, artificial intelligence (AI) has entered the global conversation as a result of the widespread adoption of generative AI-based tools such as chatbots and automatic image generation programs. Prominent AI scientists and technologists have raised concerns about the <a href="https://www.technologyreview.com/2023/06/19/1075140/how-existential-risk-became-biggest-meme-in-ai/" rel="noopener noreferrer" target="_blank">hypothetical existential risks</a></p><p><a href="https://gizmodo.com/ai-chatgpt-fatalism-wont-help-us-with-its-actual-risks-1850585699">Read more...</a></p>

