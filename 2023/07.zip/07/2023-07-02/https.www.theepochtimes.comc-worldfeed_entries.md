# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## Ottawa Protest Organizer Previously Met With United Front Official in China
 - [https://www.theepochtimes.com/ottawa-protest-organizer-previously-met-with-united-front-official-in-china_5364668.html](https://www.theepochtimes.com/ottawa-protest-organizer-previously-met-with-united-front-official-in-china_5364668.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T23:28:19+00:00

Zhang Jian (8th L) was seen among the key organizers of a protest on Parliament Hill in Ottawa on June 24, 2023. Zhang is a director of the "Commission of Marking the 100th Anniversary of Chinese Exclusion Act" that held the protest. (The Epoch Times)

## 11 Million Low- or Modest-Income Canadians to Receive One-Time Grocery Rebate on July 5
 - [https://www.theepochtimes.com/11-million-low-or-modest-income-canadians-to-receive-one-time-grocery-rebate-on-july-5-post_5370308.html](https://www.theepochtimes.com/11-million-low-or-modest-income-canadians-to-receive-one-time-grocery-rebate-on-july-5-post_5370308.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T22:42:15+00:00

Grocery prices have been rising significantly in Canada, largely due to inflation. (The Canadian Press/Nathan Denette)

## Feds Issued Security Bulletin Falsely Claiming Freedom Convoy Protesters Raiding Gov’t Buildings: Documents
 - [https://www.theepochtimes.com/feds-issued-security-bulletin-falsely-claiming-freedom-convoy-protesters-raiding-govt-buildings-documents_5370203.html](https://www.theepochtimes.com/feds-issued-security-bulletin-falsely-claiming-freedom-convoy-protesters-raiding-govt-buildings-documents_5370203.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T21:48:00+00:00

Protesters mark the first anniversary of police removal of Freedom Convoy protesters from downtown Ottawa, in Ottawa on Feb. 18, 2023. (Jonathan Ren/The Epoch Times)

## Michael Taube: Why Is It So Difficult for a Conservative to Be Elected Mayor in Canada?
 - [https://www.theepochtimes.com/michael-taube-why-is-it-so-difficult-for-a-conservative-to-be-elected-mayor-in-canada_5370068.html](https://www.theepochtimes.com/michael-taube-why-is-it-so-difficult-for-a-conservative-to-be-elected-mayor-in-canada_5370068.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T20:32:51+00:00

Newly elected Toronto Mayor Olivia Chow speaks to media outside city hall in Toronto on June 27, 2023. (The Canadian Press/Arlyn McAdorey)

## Canada to Deploy Two More Warships to Search for Mines in European Waters
 - [https://www.theepochtimes.com/canada-to-deploy-two-more-warships-to-search-for-mines-in-european-waters_5370136.html](https://www.theepochtimes.com/canada-to-deploy-two-more-warships-to-search-for-mines-in-european-waters_5370136.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T19:43:58+00:00

HMCS Fredericton is on manoeuvres in Frobisher Bay at the southern tip of Baffin Island, taking part in a sovereignty exercise in a file photo. (Michel Comte/AFP via Getty Images)

## ANALYSIS: Chinese Premier’s Europe Trip Exposes His Weak Position in CCP
 - [https://www.theepochtimes.com/analysis-chinese-premiers-europe-trip-exposes-his-weak-position-in-ccp_5362137.html](https://www.theepochtimes.com/analysis-chinese-premiers-europe-trip-exposes-his-weak-position-in-ccp_5362137.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T19:16:26+00:00

Chinese Premiere Li Qiang arrives at the Munich Residence on June 20, 2023 in Munich, Germany.  (Johannes Simon/Getty Images)

## Perks for Federal Staff Included $400–$500 Home Office Expense Tax Credit: CRA
 - [https://www.theepochtimes.com/perks-for-federal-staff-included-400-500-home-office-expense-tax-credit-cra_5370028.html](https://www.theepochtimes.com/perks-for-federal-staff-included-400-500-home-office-expense-tax-credit-cra_5370028.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T17:11:22+00:00

The Canada Revenue Agency (CRA) headquarters Connaught Building is pictured in Ottawa on Aug. 17, 2020. (Sean Kilpatrick/The Canadian Press)

## NHS England Sets up 7 More Gambling Addition Clinics Amid Steep Rise in Demand
 - [https://www.theepochtimes.com/nhs-england-sets-up-7-more-gambling-addition-clinics-amid-steep-rise-in-demand_5369981.html](https://www.theepochtimes.com/nhs-england-sets-up-7-more-gambling-addition-clinics-amid-steep-rise-in-demand_5369981.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T16:03:19+00:00

A man poses for a photograph with the logo for online gambling website Bet365 displayed on a smartphone, in London, UK, on Dec. 18, 2019. (Paul Ellis/AFP via Getty Images)

## French Mayor Alleges Rioters Tried to Assassinate Him in Fifth Night of Violence
 - [https://www.theepochtimes.com/mayor-alleges-rioters-tried-to-assassinate-him-in-fifth-night-of-violence_5369928.html](https://www.theepochtimes.com/mayor-alleges-rioters-tried-to-assassinate-him-in-fifth-night-of-violence_5369928.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T14:56:23+00:00

French Prime Minister Elisabeth Borne (R), and Interior Minister Gerald Darmanin (C) talks to Vincent Jeanbrun, the Mayor of L'Hay-les-Roses (L) as they meet with municipal police, after rioters rammed a vehicle into the mayor's house overnight, in L'Hay-les-Roses, south of Paris, on July 2, 2023. (Charly Triballeau/Pool/AFP via Getty Images)

## Woman Sacked for Saying ‘Biological Sex Is Real’ Wins £100,000 Compensation
 - [https://www.theepochtimes.com/woman-sacked-for-saying-biological-sex-is-real-wins-100000-compensation_5369906.html](https://www.theepochtimes.com/woman-sacked-for-saying-biological-sex-is-real-wins-100000-compensation_5369906.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T14:36:46+00:00

Undated handout photo of Maya Forstater, issued on  April 27, 2021. (PA Media)

## Russian Media Watchdog Blacklists Outlets Linked to Wagner Mercenary Chief
 - [https://www.theepochtimes.com/russian-media-watchdog-blacklists-outlets-linked-to-wagner-mercenary-chief_5369319.html](https://www.theepochtimes.com/russian-media-watchdog-blacklists-outlets-linked-to-wagner-mercenary-chief_5369319.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T11:44:01+00:00

Yevgeny Prigozhin, the owner of the Wagner Group military company, records his video addresses in Rostov-on-Don, Russia, on June 24, 2023. (Prigozhin Press Service via AP)

## Kidnapped Mexican Security Staff Freed After 3-Day Search
 - [https://www.theepochtimes.com/kidnapped-mexican-security-staff-freed-after-3-day-search_5369360.html](https://www.theepochtimes.com/kidnapped-mexican-security-staff-freed-after-3-day-search_5369360.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T11:35:43+00:00

State security ministry employees, who were kidnapped by members of an armed group days ago, react after meeting their relatives after being freed, outside the Secretary of Public Security and Citizen Protection of Chiapas, in Tuxtla Gutierrez building, Mexico, on June 30, 2023. (Jacob Garcia/Reuters)

## Australia Sees First Budget Surplus in 15 Years; $19 Billion Boost From Soaring Commodities
 - [https://www.theepochtimes.com/australia-sees-first-budget-surplus-in-15-years-19-billion-boost-from-soaring-commodities_5369769.html](https://www.theepochtimes.com/australia-sees-first-budget-surplus-in-15-years-19-billion-boost-from-soaring-commodities_5369769.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T07:58:43+00:00

Haulage truck at the Rio Tinto West Angelas iron ore mine in the Pilbara region of West Australia, on July 9, 2014. (AAP Image/Alan Porritt)

## Russia Launches First Overnight Drone Attack on Kyiv in 12 Days: Ukrainian Military
 - [https://www.theepochtimes.com/russia-launches-first-overnight-drone-attack-on-kyiv-in-12-days-ukrainian-military_5369780.html](https://www.theepochtimes.com/russia-launches-first-overnight-drone-attack-on-kyiv-in-12-days-ukrainian-military_5369780.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T07:34:46+00:00

An explosion of a drone in the sky over the city during a Russian drone strike, amid Russia's attack on Ukraine, in Kyiv, Ukraine, on June 20, 2023. (Gleb Garanich/Reuters)

## ‘Lack Backbone’: Liberal Leader on Corporates Backing ‘Yes’ Vote
 - [https://www.theepochtimes.com/lack-backbone-liberal-leader-on-corporates-backing-yes-vote_5369753.html](https://www.theepochtimes.com/lack-backbone-liberal-leader-on-corporates-backing-yes-vote_5369753.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T05:23:56+00:00

Australian Opposition Leader Peter Dutton (C) speaks to media during a press conference alongside Indigenous Senators Kerrynne Liddle (L) and Jacinta Price (R) in Adelaide, Australia on April 18, 2023. (AAP Image/Michael Errey)

## Borrowers Cross Fingers Ahead of Live Cash Rate Call
 - [https://www.theepochtimes.com/borrowers-cross-fingers-ahead-of-live-cash-rate-call_5369749.html](https://www.theepochtimes.com/borrowers-cross-fingers-ahead-of-live-cash-rate-call_5369749.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T05:16:33+00:00

A man and a women walk into the Reserve Bank of Australia headquarters in Sydney, Australia, on May 5, 2015. (Mark Metcalfe/Getty Images)

## Large Tornado in Central Alberta Damages Homes, but No Serious Injuries Reported
 - [https://www.theepochtimes.com/large-tornado-in-central-alberta-damages-homes-but-no-serious-injuries-reported_5369733.html](https://www.theepochtimes.com/large-tornado-in-central-alberta-damages-homes-but-no-serious-injuries-reported_5369733.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T04:19:01+00:00

People embrace after a tornado damaged homes near Carstairs, Alta., July 1, 2023. (The Canadian Press/Jeff McIntosh)

## EU Offer on Trade Deal ‘Not Good Enough’: Australian Agriculture Minister
 - [https://www.theepochtimes.com/eu-offer-on-trade-deal-not-good-enough-australian-agriculture-minister_5369717.html](https://www.theepochtimes.com/eu-offer-on-trade-deal-not-good-enough-australian-agriculture-minister_5369717.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T03:32:19+00:00

Agriculture Minister Murray Watt speaks during a press conference in Brisbane, Australia, on July 22, 2022. (Dan Peled/Getty Images)

## ANALYSIS: China’s Economy Stuck in Deeper Crisis Due to More State Interventions
 - [https://www.theepochtimes.com/analysis-chinas-economy-stuck-in-deeper-crisis-due-to-more-state-interventions_5369145.html](https://www.theepochtimes.com/analysis-chinas-economy-stuck-in-deeper-crisis-due-to-more-state-interventions_5369145.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T02:35:59+00:00

A staff member counts money at a branch of the Bank of China in Lianyungang, Jiangsu Province of China, on Aug. 10, 2011. (VCG/VCG via Getty Images)

## Two South Australian Universities to Tie the Knot
 - [https://www.theepochtimes.com/two-south-australian-universities-to-tie-the-knot_5369670.html](https://www.theepochtimes.com/two-south-australian-universities-to-tie-the-knot_5369670.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T02:27:53+00:00

A general view of University of Adelaide in Adelaide, May 3, 2017. (AAP Image/David Mariuz)

## Expert Calls for Uniform Plastic Recycling Rules Across Australia
 - [https://www.theepochtimes.com/expert-calls-for-uniform-plastic-recycling-rules-across-australia_5368914.html](https://www.theepochtimes.com/expert-calls-for-uniform-plastic-recycling-rules-across-australia_5368914.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T01:04:08+00:00

A container is filled with plastic waste from Australia, in Port Klang, Malaysia, on May 28, 2019.  (Vincent Thian/AP Photo )

## Calmer Conditions After Windy Airport Flight Chaos
 - [https://www.theepochtimes.com/calmer-conditions-after-windy-airport-flight-chaos_5369635.html](https://www.theepochtimes.com/calmer-conditions-after-windy-airport-flight-chaos_5369635.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-07-02T00:36:53+00:00

Travelers wait in line to verify their Covid-19 vaccination status as they check-in for a flight to Sydney, Australia at Los Angeles International Airport in Los Angeles, California, on Nov. 1, 2021. (Patrick T. Fallon/ AFP via Getty Images)

