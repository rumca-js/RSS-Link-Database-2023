# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Pożar jachtu na jeziorze Śniardwy
 - [https://tvn24.pl/polska/jezioro-sniardwy-pozar-jachtu-na-pokladzie-znajdowaly-sie-dwie-osoby-7199699?source=rss](https://tvn24.pl/polska/jezioro-sniardwy-pozar-jachtu-na-pokladzie-znajdowaly-sie-dwie-osoby-7199699?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T20:03:26+00:00

<img alt="Pożar jachtu na jeziorze Śniardwy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z5bda8-pozar-jachtu-na-jeziorze-sniardwy-7199673/alternates/LANDSCAPE_1280" />
    Na pokładzie były dwie osoby.

## Sędziowie nagle zeszli z boiska. Kuriozalny mecz mistrzów Polski
 - [https://eurosport.tvn24.pl/pilka-nozna/rakow-czestochowa-slavia-praga-sedzia-obrazil-sie-na-pilkarzy-i-opuscil-boisko-relacja_sto9682795/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/rakow-czestochowa-slavia-praga-sedzia-obrazil-sie-na-pilkarzy-i-opuscil-boisko-relacja_sto9682795/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T18:37:00+00:00

<img alt="Sędziowie nagle zeszli z boiska. Kuriozalny mecz mistrzów Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5kkrjb-rakow-czestochowa-slavia-praga-7199695/alternates/LANDSCAPE_1280" />
    Trener i piłkarze byli w szoku.

## "Morawiecki wypełniał misję z Żoliborza, by paliwem tej kampanii było straszenie Polaków"
 - [https://tvn24.pl/polska/szczyt-unii-europejskiej-bez-porozumienia-w-sprawie-migracji-sprzeciw-polski-i-wegier-janusz-lewandowski-komentuje-7199660?source=rss](https://tvn24.pl/polska/szczyt-unii-europejskiej-bez-porozumienia-w-sprawie-migracji-sprzeciw-polski-i-wegier-janusz-lewandowski-komentuje-7199660?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T18:25:19+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-y6zaps-unijny-szczyt-poswiecony-migracji-zakonczony-bez-konkluzji-to-nie-zatrzyma-jednak-unijnego-prawodawstwa-7197862/alternates/LANDSCAPE_1280" />
    Europoseł PO Janusz Lewandowski w "Faktach po Faktach".

## "To jest szczególnie obrzydliwa gra wyborcza PiS-u"
 - [https://fakty.tvn24.pl/zobacz-fakty/mateusz-morawiecki-straszy-przymusem-przyjmowania-uchodzcow-premier-polskiego-rzadu-jest-klamca-7199604?source=rss](https://fakty.tvn24.pl/zobacz-fakty/mateusz-morawiecki-straszy-przymusem-przyjmowania-uchodzcow-premier-polskiego-rzadu-jest-klamca-7199604?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T17:40:02+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-woopf8-premier-rp-mateusz-morawiecki-podczas-konferencji-prasowej-po-spotkaniu-szefow-rzadow-panstw-grupy-wyszehradzkiej-w-bratyslawie-7195340/alternates/LANDSCAPE_1280" />
    Polski rząd przyjmuje rekordowe liczby uchodźców i imigrantów, ale i tak nimi straszy.

## Końcowa klasyfikacja medalowa Igrzysk Europejskich
 - [https://eurosport.tvn24.pl/igrzyska/igrzyska-europejskie-2023-krakow-i-malopolska/2023/igrzyska-europejskie-krakow-malopolska-2023-klasyfikacja-medalowa.-ile-krazkow-maja-polacy-tabela_sto9682628/story.shtml?source=rss](https://eurosport.tvn24.pl/igrzyska/igrzyska-europejskie-2023-krakow-i-malopolska/2023/igrzyska-europejskie-krakow-malopolska-2023-klasyfikacja-medalowa.-ile-krazkow-maja-polacy-tabela_sto9682628/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T17:10:00+00:00

<img alt="Końcowa klasyfikacja medalowa Igrzysk Europejskich" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rdo265-w-krakowie-odbyla-sie-ceremonia-otwarcia-igrzysk-europejskich-7199605/alternates/LANDSCAPE_1280" />
    Wysokie miejsce Polski.

## Rosjanie skrytykowali słowa Świątek
 - [https://eurosport.tvn24.pl/tenis/wimbledon/2023/rosyjski-sport-express-krytykuje-ige-swiatek-za-stosunek-do-rosyjskich-i-bialoruskich-sportowcow-prz_sto9682472/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon/2023/rosyjski-sport-express-krytykuje-ige-swiatek-za-stosunek-do-rosyjskich-i-bialoruskich-sportowcow-prz_sto9682472/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T16:23:00+00:00

<img alt="Rosjanie skrytykowali słowa Świątek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tmpzt9-iga-swiatek-wspiera-ukraine-7199589/alternates/LANDSCAPE_1280" />
    Odniesiono się do apelu Polki.

## "WSJ": ten kraj ma być rajem dla rosyjskich szpiegów
 - [https://tvn24.pl/swiat/wsj-o-raju-dla-rosyjskich-szpiegow-7199441?source=rss](https://tvn24.pl/swiat/wsj-o-raju-dla-rosyjskich-szpiegow-7199441?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T15:56:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mpcotb-shutterstock_792043942-7199453/alternates/LANDSCAPE_1280" />
    Władze badają, czy Moskwa wykorzystuje go jako inkubator dla tajnych agentów, którzy będą infiltrować Zachód.

## Podmuch wiatru porwał namiot podczas zawodów
 - [https://tvn24.pl/tvnmeteo/polska/krakow-igrzyska-europejskie-2023-podmuch-wiatru-porwal-namiot-podczas-zawodow-nagranie-7199555?source=rss](https://tvn24.pl/tvnmeteo/polska/krakow-igrzyska-europejskie-2023-podmuch-wiatru-porwal-namiot-podczas-zawodow-nagranie-7199555?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T15:37:51+00:00

<img alt="Podmuch wiatru porwał namiot podczas zawodów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ej0dct-do-zdarzenia-doszlo-w-krakowie-7199581/alternates/LANDSCAPE_1280" />
    Nagranie otrzymaliśmy na Kontakt 24.

## Stracił panowanie nad sprzętem. Niebezpieczne zdarzenie na pokazach
 - [https://eurosport.tvn24.pl/formula-1/grand-prix-austrii-formuly-1.-upadek-pilota-przed-startem-wyscigu-na-torze-formuly-1_sto9682119/story.shtml?source=rss](https://eurosport.tvn24.pl/formula-1/grand-prix-austrii-formuly-1.-upadek-pilota-przed-startem-wyscigu-na-torze-formuly-1_sto9682119/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T15:13:00+00:00

<img alt="Stracił panowanie nad sprzętem. Niebezpieczne zdarzenie na pokazach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dgzo34-piloci-z-plecakami-odrzutowymi-na-torze-red-bull-7199567/alternates/LANDSCAPE_1280" />
    Incydent miał miejsce przy okazji Grand Prix Formuły 1 w Austrii.

## Odpoczynek od burz będzie chwilowy. Miejscami możliwe podtopienia
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-niz-otto-przyniesie-upal-burze-i-ulewy-miejscami-mozliwe-podtopienia-7199512?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-niz-otto-przyniesie-upal-burze-i-ulewy-miejscami-mozliwe-podtopienia-7199512?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T15:07:29+00:00

<img alt="Odpoczynek od burz będzie chwilowy. Miejscami możliwe podtopienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l8tkb8-deszczowo-ryzyko-podtopien-7199524/alternates/LANDSCAPE_1280" />
    Sprawdź prognozę pogody na pięć dni.

## Otwarcie parku jej imienia i niezwykła konstrukcja z klocków. Hołd "dla Mozarta poezji"
 - [https://tvn24.pl/krakow/setna-rocznica-urodzin-wislawy-szymborskiej-otwarcie-parku-w-krakowie-i-makieta-z-klockow-lego-7199522?source=rss](https://tvn24.pl/krakow/setna-rocznica-urodzin-wislawy-szymborskiej-otwarcie-parku-w-krakowie-i-makieta-z-klockow-lego-7199522?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T14:57:26+00:00

<img alt="Otwarcie parku jej imienia i niezwykła konstrukcja z klocków. Hołd " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bjxgjx-hold-dla-wislawy-szymborskiej-z-klockow-lego-7199530/alternates/LANDSCAPE_1280" />
    Sto lat temu na świat przyszła Wisława Szymborska.

## Szczątki samolotów z czasów II wojny światowej w lesie pod Kijowem
 - [https://tvn24.pl/swiat/ukraina-bbc-pod-kijowem-znaleziono-szczatki-osmiu-samolotow-hurricane-z-czasow-ii-wojny-swiatowej-7199479?source=rss](https://tvn24.pl/swiat/ukraina-bbc-pod-kijowem-znaleziono-szczatki-osmiu-samolotow-hurricane-z-czasow-ii-wojny-swiatowej-7199479?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T14:50:35+00:00

<img alt="Szczątki samolotów z czasów II wojny światowej w lesie pod Kijowem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-esk4gk-samolot-hawker-hurricane-7199485/alternates/LANDSCAPE_1280" />
    Były częścią pakietu sojuszniczego wsparcia militarnego dla ZSRR.

## 49 osób utonęło w Polsce od początku czerwca
 - [https://fakty.tvn24.pl/fakty-po-poludniu/49-osob-utonelo-w-polsce-od-poczatku-czerwca-jak-zadbac-o-bezpieczenstwo-nad-woda-7199529?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/49-osob-utonelo-w-polsce-od-poczatku-czerwca-jak-zadbac-o-bezpieczenstwo-nad-woda-7199529?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T14:49:05+00:00

<img alt="49 osób utonęło w Polsce od początku czerwca" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-y0xh0d-49-osob-utonelo-w-polsce-od-poczatku-czerwca-ratownicy-apeluja-do-urlopowiczow-7199507/alternates/LANDSCAPE_1280" />
    Jak zadbać o bezpieczeństwo nad wodą.

## Dom "doszczętnie zniszczony" po eksplozji, ranna kobieta w szpitalu
 - [https://tvn24.pl/lodz/kielchinow-gm-belchatow-woj-lodzkie-wybuch-butli-z-gazem-jedna-osoba-ranna-dom-zostal-zniszczony-7199487?source=rss](https://tvn24.pl/lodz/kielchinow-gm-belchatow-woj-lodzkie-wybuch-butli-z-gazem-jedna-osoba-ranna-dom-zostal-zniszczony-7199487?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T14:01:36+00:00

<img alt="Dom " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2665mt-budynek-zostal-zniszczony-7199473/alternates/LANDSCAPE_1280" />
    W miejscowości Kielchinów pod Bełchatowem.

## Polskie siatkarki poznały ćwierćfinałowe rywalki w Lidze Narodów
 - [https://eurosport.tvn24.pl/siatkowka/polskie-siatkarki-poznaly-cwiercfinalowe-rywalki-w-lidze-narodow-2023.-kto-to-bedzie_sto9681825/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/polskie-siatkarki-poznaly-cwiercfinalowe-rywalki-w-lidze-narodow-2023.-kto-to-bedzie_sto9681825/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T13:00:33+00:00

<img alt="Polskie siatkarki poznały ćwierćfinałowe rywalki w Lidze Narodów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-frgdva-polskie-siatkarki-graja-bardzo-dobrze-volleyballworld-7199443/alternates/LANDSCAPE_1280" />
    Biało-Czerwone wygrały fazę grupową.

## Zniszczone domy, "drzewa przewracały się jak zapałki"
 - [https://tvn24.pl/tvnmeteo/swiat/kanada-tornado-przetoczylo-sie-przez-alberte-zniszczone-domy-drzewa-przewracaly-sie-jak-zapalki-7199327?source=rss](https://tvn24.pl/tvnmeteo/swiat/kanada-tornado-przetoczylo-sie-przez-alberte-zniszczone-domy-drzewa-przewracaly-sie-jak-zapalki-7199327?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T12:54:38+00:00

<img alt="Zniszczone domy, " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-cd5grt-tornado-7199351/alternates/LANDSCAPE_1280" />
    Skutki tornada.

## Tusk: Kaczyński szczuje na imigrantów, a chce ich wpuścić setki tysięcy. Prezes PiS odpowiada
 - [https://tvn24.pl/polska/donald-tusk-na-twitterze-o-polityce-migracyjnej-pis-u-reakcja-jaroslawa-kaczynskiego-politycy-komentuja-nagranie-lidera-po-7199402?source=rss](https://tvn24.pl/polska/donald-tusk-na-twitterze-o-polityce-migracyjnej-pis-u-reakcja-jaroslawa-kaczynskiego-politycy-komentuja-nagranie-lidera-po-7199402?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T12:37:11+00:00

<img alt="Tusk: Kaczyński szczuje na imigrantów, a chce ich wpuścić setki tysięcy. Prezes PiS odpowiada" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4j8ss2-tusk-twitter-7199394/alternates/LANDSCAPE_1280" />
    Niedzielny wpis szefa PO w mediach społecznościowy jest szeroko komentowany przez obóz rządowy.

## FIFA rozważa rewolucyjną zmianę przepisu o spalonym
 - [https://eurosport.tvn24.pl/pilka-nozna/fifa-rozwaza-rewolucyjna-zmiane-przepisu-o-spalonym_sto9681656/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/fifa-rozwaza-rewolucyjna-zmiane-przepisu-o-spalonym_sto9681656/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T12:23:38+00:00

<img alt="FIFA rozważa rewolucyjną zmianę przepisu o spalonym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xy1iti-fifa-rozwaza-zmiane-odnosnie-spalonego-7199398/alternates/LANDSCAPE_1280" />
    Pomysłodawcą jest były menedżer Arsenalu Arsene Wenger.

## Titanica podmieniono w celu wyłudzenia ubezpieczenia? To teoria spiskowa
 - [https://konkret24.tvn24.pl/swiat/titanic-zostal-podmieniony-w-celu-wyludzenia-ubezpieczenia-to-teoria-spiskowa-7194662?source=rss](https://konkret24.tvn24.pl/swiat/titanic-zostal-podmieniony-w-celu-wyludzenia-ubezpieczenia-to-teoria-spiskowa-7194662?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T12:19:24+00:00

<img alt="Titanica podmieniono w celu wyłudzenia ubezpieczenia? To teoria spiskowa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qddkb5-titanic-zostal-podmieniony-w-celu-wyludzenia-ubezpieczenia-to-teoria-spiskowa-7194732/alternates/LANDSCAPE_1280" />
    Titanic nie zatonął, bo został podmieniony na inny statek - przekonuje anonimowy twitterowicz. Brak na to wiarygodnych dowodów.

## Trudna rywalka na drodze 43-letniej Williams
 - [https://eurosport.tvn24.pl/tenis/wimbledon/2023/venus-williams-zagra-w-wimbledonie-2023_sto9681270/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon/2023/venus-williams-zagra-w-wimbledonie-2023_sto9681270/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T11:37:24+00:00

<img alt="Trudna rywalka na drodze 43-letniej Williams" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yk2mn-venus-williams-celebrates-winning-wimbledon-in-2008-7199359/alternates/LANDSCAPE_1280" />
    W pierwszej rundzie Wimbledonu.

## Cios dla firmy Prigożyna, ministerstwo unieważniło wielomiliardowy kontrakt
 - [https://tvn24.pl/swiat/rosja-media-firma-jewgienija-prigozyna-przestanie-karmic-rosyjskich-zolnierzy-7199238?source=rss](https://tvn24.pl/swiat/rosja-media-firma-jewgienija-prigozyna-przestanie-karmic-rosyjskich-zolnierzy-7199238?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T11:12:43+00:00

<img alt="Cios dla firmy Prigożyna, ministerstwo unieważniło wielomiliardowy kontrakt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jckd1j-zolnierze-7199239/alternates/LANDSCAPE_1280" />
    Pracę ma stracić kilka tysięcy osób.

## Wściekły ryś rzucił się na śpiącego biwakowicza
 - [https://tvn24.pl/tvnmeteo/swiat/usa-wsciekly-rys-rzucil-sie-na-spiacego-biwakowicza-7199154?source=rss](https://tvn24.pl/tvnmeteo/swiat/usa-wsciekly-rys-rzucil-sie-na-spiacego-biwakowicza-7199154?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T11:12:39+00:00

<img alt="Wściekły ryś rzucił się na śpiącego biwakowicza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-futww6-rys-rudy-lynx-rufus-7199272/alternates/LANDSCAPE_1280" />
    Do zdarzenia doszło w amerykańskim stanie Connecticut.

## Polak obronił tytuł. Nikt przed nim nie wykonał tego triku
 - [https://eurosport.tvn24.pl/bmx/dawid-godziek-mistrzem-red-bull-roof-ride.-jako-pierwszy-wykonal-trik-cashroll-z-16-metrowego-zeskok_sto9681427/story.shtml?source=rss](https://eurosport.tvn24.pl/bmx/dawid-godziek-mistrzem-red-bull-roof-ride.-jako-pierwszy-wykonal-trik-cashroll-z-16-metrowego-zeskok_sto9681427/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T10:23:26+00:00

<img alt="Polak obronił tytuł. Nikt przed nim nie wykonał tego triku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sn0jqd-dawid-godziek-wykonal-trik-cashroll-z-16-metrowego-zeskoku-7199290/alternates/LANDSCAPE_1280" />
    Jako pierwszy na świecie wykonał trik cashroll z 16-metrowego zeskoku.

## Tajemnicza skrzynia przed domem dziecka. W środku 100 tysięcy złotych
 - [https://tvn24.pl/polska/tajemnicza-skrzynia-przed-domem-dziecka-w-srodku-100-tysiecy-zlotych-7198899?source=rss](https://tvn24.pl/polska/tajemnicza-skrzynia-przed-domem-dziecka-w-srodku-100-tysiecy-zlotych-7198899?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T10:21:39+00:00

<img alt="Tajemnicza skrzynia przed domem dziecka. W środku 100 tysięcy złotych" src="https://tvn24.pl/krakow/cdn-zdjecie-ei5bjv-skrzynia-podrzucona-pod-drzwi-domu-dziecka-w-dlugiem-7199260/alternates/LANDSCAPE_1280" />
    Władze placówki wezwały policję.

## Świątek i Djoković faworytami bukmacherów
 - [https://eurosport.tvn24.pl/tenis/wimbledon/2023/wimbledon-2023.-iga-swiatek-i-novak-djokovic-faworytami-bukmacherow_sto9681361/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon/2023/wimbledon-2023.-iga-swiatek-i-novak-djokovic-faworytami-bukmacherow_sto9681361/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T10:11:29+00:00

<img alt="Świątek i Djoković faworytami bukmacherów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-slphf-iga-swiatek-and-novak-djokovic-7199282/alternates/LANDSCAPE_1280" />
    Mają największe szanse na zwycięstwo w Wimbledonie.

## Rosja odwołała targi lotniczo-kosmiczne. Po raz pierwszy w historii
 - [https://tvn24.pl/biznes/ze-swiata/rosja-odwolala-najwazniejszej-targi-lotniczo-kosmiczne-maks-po-raz-pierwszy-w-historii-7199114?source=rss](https://tvn24.pl/biznes/ze-swiata/rosja-odwolala-najwazniejszej-targi-lotniczo-kosmiczne-maks-po-raz-pierwszy-w-historii-7199114?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T10:06:48+00:00

<img alt="Rosja odwołała targi lotniczo-kosmiczne. Po raz pierwszy w historii" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-6ntv14-moskwa-rosja-7198551/alternates/LANDSCAPE_1280" />
    Brytyjskie ministerstwo obrony podało możliwe przyczyny.

## Harry Styles w Warszawie. Fani zbierają się przed stadionem. Jak dojechać na koncert?
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-harry-styles-wystapi-na-stadionie-narodowym-jak-dojechac-na-koncert-utrudnienia-7199048?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-harry-styles-wystapi-na-stadionie-narodowym-jak-dojechac-na-koncert-utrudnienia-7199048?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T09:58:35+00:00

<img alt="Harry Styles w Warszawie. Fani zbierają się przed stadionem. Jak dojechać na koncert?" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-xlhiv0-fani-zbieraja-sie-przed-stadionem-narodowym-7199176/alternates/LANDSCAPE_1280" />
    Zarząd Transportu Miejskiego zachęca do podróży komunikacją miejską.

## Przed nami dwa uderzenia gorąca. Jedno będzie mocne. Pogoda na 16 dni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-16-dni-pogoda-na-lipiec-dlugoterminowa-prognoza-tomasza-wasilewskiego-beda-dwa-uderzenia-goraca-7199193?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-16-dni-pogoda-na-lipiec-dlugoterminowa-prognoza-tomasza-wasilewskiego-beda-dwa-uderzenia-goraca-7199193?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T09:56:00+00:00

<img alt="Przed nami dwa uderzenia gorąca. Jedno będzie mocne. Pogoda na 16 dni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bdwnqj-pogoda-drv-7199235/alternates/LANDSCAPE_1280" />
    Sprawdź prognozę przygotowaną przez Tomasza Wasilewskiego.

## "Miała dar wychwytywania". Spektakl z okazji setnej rocznicy urodzin Wisławy Szymborskiej
 - [https://tvn24.pl/polska/setna-rocznica-urodzin-wislawy-szymborskiej-spektakl-jubileuszowy-na-deskach-sceny-relax-wystapila-min-grazyna-szapolowska-7199157?source=rss](https://tvn24.pl/polska/setna-rocznica-urodzin-wislawy-szymborskiej-spektakl-jubileuszowy-na-deskach-sceny-relax-wystapila-min-grazyna-szapolowska-7199157?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T09:26:23+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rqtjww-wislawa-szymborska-urodzila-sie-2-lipca-2023-roku-7199198/alternates/LANDSCAPE_1280" />
    Na premierze, która odbyła się w warszawskim teatrze Scena Relax, byliśmy z kamerą.

## Zjechał na przeciwległy pas ruchu i zderzył się z radiowozem. Kierowca nie żyje
 - [https://tvn24.pl/pomorze/gizycko-zderzenie-samochodu-z-radiowozem-kierowca-nie-zyje-7199100?source=rss](https://tvn24.pl/pomorze/gizycko-zderzenie-samochodu-z-radiowozem-kierowca-nie-zyje-7199100?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T08:59:48+00:00

<img alt="Zjechał na przeciwległy pas ruchu i zderzył się z radiowozem. Kierowca nie żyje" src="https://tvn24.pl/pomorze/cdn-zdjecie-caxjm4-do-wypadku-doszlo-pomiedzy-gizyckiem-a-rynem-7199150/alternates/LANDSCAPE_1280" />
    Do wypadku doszło pod Giżyckiem.

## Minister spraw wewnętrznych: na granicę z Białorusią pojedzie 500 policjantów
 - [https://tvn24.pl/polska/bialorus-granica-minister-spraw-wewnetrznych-na-granice-pojedzie-500-policjantow-7199140?source=rss](https://tvn24.pl/polska/bialorus-granica-minister-spraw-wewnetrznych-na-granice-pojedzie-500-policjantow-7199140?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T08:57:55+00:00

<img alt="Minister spraw wewnętrznych: na granicę z Białorusią pojedzie 500 policjantów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vty2st-kamery-i-czujniki-ruchu-zamontowane-sa-juz-na-calej-dlugosci-zapory-elektronicznej-czyli-na-206-kilometrach-7156276/alternates/LANDSCAPE_1280" />
    "W związku z napiętą sytuacją na granicy z Białorusią".

## Cztery dni, 110 tysięcy uczestników i plejada gwiazd na scenach
 - [https://tvn24.pl/pomorze/opener-2023-zakonczony-podsumowanie-20-edycji-festiwalu-7199089?source=rss](https://tvn24.pl/pomorze/opener-2023-zakonczony-podsumowanie-20-edycji-festiwalu-7199089?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T08:45:24+00:00

<img alt="Cztery dni, 110 tysięcy uczestników i plejada gwiazd na scenach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3asawq-opener-2023-zakonczony-7199120/alternates/LANDSCAPE_1280" />
    Jubileuszowy Open'er zakończony.

## "Nie mamy żadnych zakładów przemysłowych, ani sklepu, a będziemy mieli krematorium"
 - [https://tvn24.pl/bialystok/bartosze-mieszkancy-wsi-zyjacej-z-turystyki-sa-przeciw-krematorium-zamierzaja-blokowac-droge-krajowa-7197542?source=rss](https://tvn24.pl/bialystok/bartosze-mieszkancy-wsi-zyjacej-z-turystyki-sa-przeciw-krematorium-zamierzaja-blokowac-droge-krajowa-7197542?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T08:29:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h0l2vq-na-jednym-z-ogrodzen-we-wsi-wisi-taki-baner-7197573/alternates/LANDSCAPE_1280" />
    Mieszkańcy wsi żyjącej z turystyki protestują przeciwko budowie spopielarni zwłok.

## Oznaczenia Grupy Wagnera znikają z głównej siedziby najemników
 - [https://tvn24.pl/najnowsze/rosja-petersburg-oznaczenia-grupy-wagnera-znikaja-z-glownej-siedziby-najemnikow-7199088?source=rss](https://tvn24.pl/najnowsze/rosja-petersburg-oznaczenia-grupy-wagnera-znikaja-z-glownej-siedziby-najemnikow-7199088?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T08:24:51+00:00

<img alt="Oznaczenia Grupy Wagnera znikają z głównej siedziby najemników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-40dqv4-siedziba-grupy-wagnera-w-rosji-w-petersburgu-7189407/alternates/LANDSCAPE_1280" />
    Z biurowca Wagner Center w Petersburgu.

## Oznaczenia Grupy Wagnera znikają z głównej siedziby najemników
 - [https://tvn24.pl/swiat/rosja-petersburg-oznaczenia-grupy-wagnera-znikaja-z-glownej-siedziby-najemnikow-7199088?source=rss](https://tvn24.pl/swiat/rosja-petersburg-oznaczenia-grupy-wagnera-znikaja-z-glownej-siedziby-najemnikow-7199088?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T08:24:51+00:00

<img alt="Oznaczenia Grupy Wagnera znikają z głównej siedziby najemników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-40dqv4-siedziba-grupy-wagnera-w-rosji-w-petersburgu-7189407/alternates/LANDSCAPE_1280" />
    Z biurowca Wagner Center w Petersburgu.

## Popularny kierunek na wakacje wśród Polaków. Ekspert o "genialnym stosunku jakości do ceny"
 - [https://tvn24.pl/biznes/turystyka/wakacje-2023-najpopularniejsze-kierunki-wyjazdow-polakow-pawel-kunz-o-inflacji-i-kierunkach-7199047?source=rss](https://tvn24.pl/biznes/turystyka/wakacje-2023-najpopularniejsze-kierunki-wyjazdow-polakow-pawel-kunz-o-inflacji-i-kierunkach-7199047?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T08:11:18+00:00

<img alt="Popularny kierunek na wakacje wśród Polaków. Ekspert o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9k2abd-burgas-bulgaria-5675743/alternates/LANDSCAPE_1280" />
    Gościem "Wstajesz i weekend" w TVN24 był Paweł Kunz, ekspert branży turystycznej.

## Jasna deklaracja Sabalenki
 - [https://eurosport.tvn24.pl/tenis/wimbledon-gra-pojedyncza-kobiet/2023/wimbledon-2023.-aryna-sabalenka-nie-zamierza-rozmawiac-o-polityce-podczas-turnieju-tenis_sto9680802/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon-gra-pojedyncza-kobiet/2023/wimbledon-2023.-aryna-sabalenka-nie-zamierza-rozmawiac-o-polityce-podczas-turnieju-tenis_sto9680802/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T08:02:15+00:00

<img alt="Jasna deklaracja Sabalenki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-su8t6y-aryna-sabalenka-to-aktualna-wiceliderka-rankingu-wta-7199102/alternates/LANDSCAPE_1280" />
    "Jestem tu po to, by rozmawiać wyłącznie o tenisie".

## Bastion PiS? To nie tu. "Tęczowy Sanok" przejdzie ulicami miasta
 - [https://tvn24.pl/krakow/sanok-ulicami-miasta-przejdzie-ii-marsz-rownosci-7191956?source=rss](https://tvn24.pl/krakow/sanok-ulicami-miasta-przejdzie-ii-marsz-rownosci-7191956?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T07:51:59+00:00

<img alt="Bastion PiS? To nie tu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gq88wh-i-marsz-rownosci-w-sanoku-2022-rok-7191978/alternates/LANDSCAPE_1280" />
    22 lipca.

## Samochód jako taran. "Moja żona i jedno z dzieci zostali ranni"
 - [https://tvn24.pl/swiat/paryz-zamieszki-we-francji-mer-podparyskiej-miejscowosci-napadnieto-na-moj-dom-zona-i-dziecko-zostali-ranni-7199057?source=rss](https://tvn24.pl/swiat/paryz-zamieszki-we-francji-mer-podparyskiej-miejscowosci-napadnieto-na-moj-dom-zona-i-dziecko-zostali-ranni-7199057?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T07:50:00+00:00

<img alt="Samochód jako taran. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c4a8xu-plonacy-samochod-w-podparyskim-nanterre-7199080/alternates/LANDSCAPE_1280" />
    Atak na dom mera.

## Hulajnogą na przejście dla pieszych, tuż przed auto. "Kompletnie nas zignorował"
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-wjechal-hulajnoga-na-przejscie-dla-pieszych-tuz-przed-maska-auta-nagranie-7198453?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-wjechal-hulajnoga-na-przejscie-dla-pieszych-tuz-przed-maska-auta-nagranie-7198453?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T07:44:19+00:00

<img alt="Hulajnogą na przejście dla pieszych, tuż przed auto. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6ch7f2-mezczyzna-na-hulajnodze-wjechal-na-przejscie-dla-pieszych-7198492/alternates/LANDSCAPE_1280" />
    Nagranie otrzymaliśmy na Kontakt 24.

## Ewakuacja polskich siatkarzy
 - [https://eurosport.tvn24.pl/siatkowka/nations-league-league-round/2023/liga-narodow.-polscy-siatkarze-ewakuowani-z-hotelu-na-filipinach_sto9681147/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/nations-league-league-round/2023/liga-narodow.-polscy-siatkarze-ewakuowani-z-hotelu-na-filipinach_sto9681147/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T06:46:49+00:00

<img alt="Ewakuacja polskich siatkarzy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jr0hrm-polscy-siatkarze-7199037/alternates/LANDSCAPE_1280" />
    Pożar w hotelu.

## Kumulacja w Lotto dalej rośnie
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia010723-liczby-z-ostatniego-losowania-7199021?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia010723-liczby-z-ostatniego-losowania-7199021?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T06:31:24+00:00

<img alt="Kumulacja w Lotto dalej rośnie" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie63e089d459976179939fb237bec19518-wyniki-losowania-lotto-4430595/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## Polki nie dały szans Koreankom. Znów prowadzą w Lidze Narodów
 - [https://eurosport.tvn24.pl/siatkowka/nations-league-league-round-1/2023/polska-korea-poludniowa-wynik-meczu-na-zywo-i-relacja-live-liga-narodow-siatkarek-2023_sto9681044/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/nations-league-league-round-1/2023/polska-korea-poludniowa-wynik-meczu-na-zywo-i-relacja-live-liga-narodow-siatkarek-2023_sto9681044/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T06:26:00+00:00

<img alt="Polki nie dały szans Koreankom. Znów prowadzą w Lidze Narodów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cimrsc-polskie-siatkarki-w-lidze-narodow-7199018/alternates/LANDSCAPE_1280" />
    Biało-Czerwone ciągle mają szansę na zajęcie pierwszego miejsca. Wynik i relacja w eurosport.pl.

## Poranek głośny od grzmotów. Gdzie jest burza
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-0207-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-7199024?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-0207-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-7199024?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T06:20:58+00:00

<img alt="Poranek głośny od grzmotów. Gdzie jest burza" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-wq23br-wyladowania-atmosferyczne-nad-polska-7199028/alternates/LANDSCAPE_1280" />
    Śledź aktualną sytuację pogodową w kraju na tvnmeteo.pl.

## Były mistrz świata zakończył karierę
 - [https://eurosport.tvn24.pl/pilka-nozna/cesc-fabregas-oglosil-zakonczenie-pilkarskiej-kariery_sto9680876/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/cesc-fabregas-oglosil-zakonczenie-pilkarskiej-kariery_sto9680876/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T06:20:44+00:00

<img alt="Były mistrz świata zakończył karierę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uv6kln-fabregas-champion-du-monde-en-2010-7199029/alternates/LANDSCAPE_1280" />
    Ogłosił dalsze plany.

## "Ta noc była spokojniejsza". Zatrzymano kilkaset osób
 - [https://tvn24.pl/swiat/francja-zamieszki-kilkuset-zatrzymanych-ostatniej-nocy-7199019?source=rss](https://tvn24.pl/swiat/francja-zamieszki-kilkuset-zatrzymanych-ostatniej-nocy-7199019?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T06:17:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vx4ocs-policja-na-ulicach-paryza-7199025/alternates/LANDSCAPE_1280" />
    Przekazał szef resortu spraw wewnętrznych Francji.

## Zakopane płakało. Siostry odpadły od ściany, jedna pociągnęła w przepaść drugą
 - [https://tvn24.pl/premium/tatry-zakopane-marzena-skotnicowna-i-jej-siostra-lida-tragiczna-smierc-nastolatek-w-gorach-7157005?source=rss](https://tvn24.pl/premium/tatry-zakopane-marzena-skotnicowna-i-jej-siostra-lida-tragiczna-smierc-nastolatek-w-gorach-7157005?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T05:42:42+00:00

<img alt="Zakopane płakało. Siostry odpadły od ściany, jedna pociągnęła w przepaść drugą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-663q95-lida-od-lewej-i-marzena-skotnicowny-kochaly-gory-7163360/alternates/LANDSCAPE_1280" />
    W Zakopanem znał je każdy. Na pogrzeb, by te młodziutkie siostry pożegnać, przyszły tłumy. Ich matka wpadła w rozpacz tak ogromną, że organizacją pochówku zajął się początkujący poeta Julian Przyboś, w jednej z dziewczyn zakochany po uszy. Marzena i Lida Skotnicówny - należące do wąskiego grona pionierek kobiecego taternictwa - runęły w przepaść na oczach przyjaciół, mierząc się z górą, przed którą każdy wtedy drżał.

## Burze z gradem w części kraju. IMGW ostrzega
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-prognoza-zagrozen-na-kolejne-dni-7198988?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-prognoza-zagrozen-na-kolejne-dni-7198988?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T05:30:46+00:00

<img alt="Burze z gradem w części kraju. IMGW ostrzega" src="https://tvn24.pl/najnowsze/cdn-zdjecie-usq7g0-moga-pojawic-sie-burze-7177077/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie aura będzie groźna.

## Kolejne alerty IMGW. Niebezpiecznie będzie do poniedziałku
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-silny-wiatr-prognoza-zagrozen-na-kolejne-dni-7198988?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-silny-wiatr-prognoza-zagrozen-na-kolejne-dni-7198988?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T05:30:46+00:00

<img alt="Kolejne alerty IMGW. Niebezpiecznie będzie do poniedziałku" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-mrl6jq-silny-wiatr-sztorm-wichura-6762998/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie należy uważać.

## Powrócą gwałtowne zjawiska. Gdzie IMGW może wydać alerty
 - [https://tvn24.pl/tvnmeteo/pogoda/prognoza-zagrozen-imgw-powroca-gwaltownej-zjawiska-przewidywania-imgw-7198988?source=rss](https://tvn24.pl/tvnmeteo/pogoda/prognoza-zagrozen-imgw-powroca-gwaltownej-zjawiska-przewidywania-imgw-7198988?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T05:30:46+00:00

<img alt="Powrócą gwałtowne zjawiska. Gdzie IMGW może wydać alerty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iebqk2-burze-7186949/alternates/LANDSCAPE_1280" />
    IMGW wydał prognozę zagrożeń.

## Zawalił się budynek. Zginęło siedmiu robotników
 - [https://tvn24.pl/swiat/abidzan-katastrofa-budowlana-zginelo-siedmiu-robotnikow-7198965?source=rss](https://tvn24.pl/swiat/abidzan-katastrofa-budowlana-zginelo-siedmiu-robotnikow-7198965?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T05:08:51+00:00

<img alt="Zawalił się budynek. Zginęło siedmiu robotników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-35l4kf-katastrofa-budowalna-w-abidzanie-7198992/alternates/LANDSCAPE_1280" />
    W Abidżanie, stolicy Wybrzeża Kości Słoniowej.

## Pogrzeb 17-letniego Nahela, 19. Marsz Równości w Poznaniu
 - [https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-2-lipca-7198926?source=rss](https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-2-lipca-7198926?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T04:55:06+00:00

<img alt="Pogrzeb 17-letniego Nahela, 19. Marsz Równości w Poznaniu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5e028r-protesty-we-francji-7198987/alternates/LANDSCAPE_1280" />
    Pięć rzeczy, które warto wiedzieć 2 lipca

## Klejnoty na ślub arystokratki nie dojechały
 - [https://tvn24.pl/swiat/hiszpania-zrabowali-klejnoty-przewozone-na-slub-arystokratki-przebrali-sie-za-zandarmow-7198956?source=rss](https://tvn24.pl/swiat/hiszpania-zrabowali-klejnoty-przewozone-na-slub-arystokratki-przebrali-sie-za-zandarmow-7198956?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T04:35:14+00:00

<img alt="Klejnoty na ślub arystokratki nie dojechały" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oshga-tamara-falco-7198982/alternates/LANDSCAPE_1280" />
    Do napadu doszło w Hiszpanii, na jednej z autostrad w środkowej części kraju.

## "Medal dedykuję lekarzom"
 - [https://eurosport.tvn24.pl/igrzyska/igrzyska-europejskie-2023/2024/dawid-kubacki-po-zdobyciu-zlotego-medalu-igrzysk-europejskich-na-wielkiej-krokwi_sto9680933/story.shtml?source=rss](https://eurosport.tvn24.pl/igrzyska/igrzyska-europejskie-2023/2024/dawid-kubacki-po-zdobyciu-zlotego-medalu-igrzysk-europejskich-na-wielkiej-krokwi_sto9680933/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T04:09:04+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qysacj-dawid-kubacki-ze-zlotym-medalem-igrzysk-europejskich-7198974/alternates/LANDSCAPE_1280" />
    Kubacki odzyskał blask po rodzinnym dramacie.

## Andrzej Poczobut trafił do Nowopołocka. "To ciężka kolonia"
 - [https://tvn24.pl/swiat/bialorus-andrzej-poczobut-trafil-do-kolonii-karnej-w-nowopolocku-to-ciezka-kolonia-7198954?source=rss](https://tvn24.pl/swiat/bialorus-andrzej-poczobut-trafil-do-kolonii-karnej-w-nowopolocku-to-ciezka-kolonia-7198954?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T04:01:52+00:00

<img alt="Andrzej Poczobut trafił do Nowopołocka. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4or1s9-andrzej-poczobut-6900975/alternates/LANDSCAPE_1280" />
    Aktywista i dziennikarz został skazany na osiem lat kolonii karnej.

## 40 pracowników rosyjskiej ambasady wydalonych
 - [https://tvn24.pl/swiat/rumunia-bukareszt-40-pracownikow-rosyjskiej-ambasady-wydalonych-z-kraju-zostali-odeslani-do-moskwy-7198966?source=rss](https://tvn24.pl/swiat/rumunia-bukareszt-40-pracownikow-rosyjskiej-ambasady-wydalonych-z-kraju-zostali-odeslani-do-moskwy-7198966?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T03:43:01+00:00

<img alt="40 pracowników rosyjskiej ambasady wydalonych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v1xg5t-ambasada-federacji-rosyjskiej-w-bukareszcie-7198967/alternates/LANDSCAPE_1280" />
    Odlecieli do Moskwy.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-7198969?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-7198969?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T03:34:37+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rhqppe-grupa-wagnera-w-rostowie-nad-donem-zdjecie-z-24-czerwca-7192222/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 494 dni.

## Jechał 388 km/h, może uniknąć kary
 - [https://tvn24.pl/swiat/belgia-jechal-388-kmh-na-autostradzie-moze-uniknac-kary-7198949?source=rss](https://tvn24.pl/swiat/belgia-jechal-388-kmh-na-autostradzie-moze-uniknac-kary-7198949?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T03:29:52+00:00

<img alt="Jechał 388 km/h, może uniknąć kary" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gbrn9f-belgia-autostrada-shutterstock431896885-6069697/alternates/LANDSCAPE_1280" />
    Zdarzenie na autostradzie w północnej Belgii.

## "Mogę sobie wyobrazić, że za 30 lat będziemy mówić o parytetach dla mężczyzn"
 - [https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-139,S00E139,1104194?source=rss](https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-139,S00E139,1104194?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T03:15:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kg25fa-aleksander-kwasniewski-piotr-jacon-7198720/alternates/LANDSCAPE_1280" />
    Były prezydent Aleksander Kwaśniewski w rozmowie z Piotrem Jaconiem.

## Kijów zaatakowany dronami. Rano alarm z powodu bombowców
 - [https://tvn24.pl/swiat/ukraina-walczy-atak-rosji-relacja-na-zywo-niedziela-2-lipca-7198973?source=rss](https://tvn24.pl/swiat/ukraina-walczy-atak-rosji-relacja-na-zywo-niedziela-2-lipca-7198973?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-02T03:13:55+00:00

<img alt="Kijów zaatakowany dronami. Rano alarm z powodu bombowców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-86xcfa-kijow-6881928/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy oraz sytuację w Rosji.

