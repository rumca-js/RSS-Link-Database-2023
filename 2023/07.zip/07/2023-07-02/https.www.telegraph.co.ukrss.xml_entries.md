# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Proud Boys ordered to pay over $1m for vandalising church's BLM sign
 - [https://www.telegraph.co.uk/world-news/2023/07/02/proud-boys-ordered-to-pay-over-1m-for-vandalising-church/](https://www.telegraph.co.uk/world-news/2023/07/02/proud-boys-ordered-to-pay-over-1m-for-vandalising-church/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T22:27:09+00:00



## Evacuation, Channel 4, review: a heartbreaking account of awful choices and a Kabul in turmoil
 - [https://www.telegraph.co.uk/tv/2023/07/02/evacuation-channel-4-review-devastating-chaos-in-kabul/](https://www.telegraph.co.uk/tv/2023/07/02/evacuation-channel-4-review-devastating-chaos-in-kabul/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T21:00:00+00:00



## How to watch the Women's World Cup on TV in the UK and US
 - [https://www.telegraph.co.uk/football/2023/07/02/womens-world-cup-2023-how-to-watch-tv-uk-us-et-pt/](https://www.telegraph.co.uk/football/2023/07/02/womens-world-cup-2023-how-to-watch-tv-uk-us-et-pt/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T20:34:48+00:00



## Women’s World Cup 2023: Fixtures and full match schedule
 - [https://www.telegraph.co.uk/football/2023/07/02/womens-world-cup-2023-fixtures-when-where-host-tickets/](https://www.telegraph.co.uk/football/2023/07/02/womens-world-cup-2023-fixtures-when-where-host-tickets/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T20:32:55+00:00



## Women’s Ashes 2023: England vs Australia fixtures, format and TV channel for next match
 - [https://www.telegraph.co.uk/cricket/2023/07/02/womens-ashes-2023-england-australia-fixtures-format-tv/](https://www.telegraph.co.uk/cricket/2023/07/02/womens-ashes-2023-england-australia-fixtures-format-tv/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T20:31:53+00:00



## Wimbledon 2023: Dates, draw, full schedule and how to watch on TV
 - [https://www.telegraph.co.uk/tennis/2023/07/02/wimbledon-2023-dates-full-schedule-and-how-to-watch-on-tv/](https://www.telegraph.co.uk/tennis/2023/07/02/wimbledon-2023-dates-full-schedule-and-how-to-watch-on-tv/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T20:30:16+00:00



## Ashes 2023: England vs Australia fixtures, start times and TV channel for Test series
 - [https://www.telegraph.co.uk/cricket/2023/07/02/ashes-2023-england-vs-australia-fixtures-start-times-tv-channel-watch/](https://www.telegraph.co.uk/cricket/2023/07/02/ashes-2023-england-vs-australia-fixtures-start-times-tv-channel-watch/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T20:26:35+00:00



## Tour de France 2023 route, teams and how to watch on TV
 - [https://www.telegraph.co.uk/cycling/2023/07/02/tour-de-france-2023-route-teams-and-how-to-watch-on-tv/](https://www.telegraph.co.uk/cycling/2023/07/02/tour-de-france-2023-route-teams-and-how-to-watch-on-tv/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T20:26:23+00:00



## Poland strengthens border with Belarus to curb migrant and Wagner threats
 - [https://www.telegraph.co.uk/world-news/2023/07/02/poland-sends-officers-border-crisis-belarus-wagner-migrants/](https://www.telegraph.co.uk/world-news/2023/07/02/poland-sends-officers-border-crisis-belarus-wagner-migrants/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T18:19:03+00:00



## Second Ashes Test player ratings: Ben Stokes plays one of England's greatest Test innings in defeat
 - [https://www.telegraph.co.uk/cricket/2023/07/02/ashes-player-ratings-england-australia-second-test-lords/](https://www.telegraph.co.uk/cricket/2023/07/02/ashes-player-ratings-england-australia-second-test-lords/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T15:15:55+00:00



## Joe Biden to visit UK a month after meeting Rishi Sunak in Washington
 - [https://www.telegraph.co.uk/politics/2023/07/02/joe-biden-visit-uk-rishi-sunak/](https://www.telegraph.co.uk/politics/2023/07/02/joe-biden-visit-uk-rishi-sunak/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T14:53:07+00:00



## 'Same old Aussies, always cheating': Jonny Bairstow stumped in controversial manner
 - [https://www.telegraph.co.uk/cricket/2023/07/02/jonny-bairstow-stumped-alex-carey-ashes-second-test-lords/](https://www.telegraph.co.uk/cricket/2023/07/02/jonny-bairstow-stumped-alex-carey-ashes-second-test-lords/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T13:04:07+00:00



## 'Same old Aussies, always cheating': Jonny Bairstow stumped in controversial manner
 - [https://www.telegraph.co.uk/cricket/2023/07/02/jonny-bairstow-run-out-alex-carey-ashes-second-test-lords/](https://www.telegraph.co.uk/cricket/2023/07/02/jonny-bairstow-run-out-alex-carey-ashes-second-test-lords/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T12:14:00+00:00



## Lord Kerslake dies, aged 68
 - [https://www.telegraph.co.uk/politics/2023/07/02/lord-bob-kerslake-dies-dead-cancer-civil-service/](https://www.telegraph.co.uk/politics/2023/07/02/lord-bob-kerslake-dies-dead-cancer-civil-service/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T11:38:46+00:00



## Austrian Grand Prix live: Latest F1 updates from the Red Bull Ring
 - [https://www.telegraph.co.uk/formula-1/2023/07/02/austrian-grand-prix-f1-live-latest-updates-red-bull-ring/](https://www.telegraph.co.uk/formula-1/2023/07/02/austrian-grand-prix-f1-live-latest-updates-red-bull-ring/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T11:37:23+00:00



## 'Multiple people' killed in mass shooting in Baltimore
 - [https://www.telegraph.co.uk/world-news/2023/07/02/south-baltimore-mass-shooting-multiple-dead/](https://www.telegraph.co.uk/world-news/2023/07/02/south-baltimore-mass-shooting-multiple-dead/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T10:58:58+00:00



## Tour de France stage two live: Latest updates from the second day
 - [https://www.telegraph.co.uk/cycling/2023/07/02/tour-de-france-stage-2-live-latest-updates/](https://www.telegraph.co.uk/cycling/2023/07/02/tour-de-france-stage-2-live-latest-updates/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T10:57:06+00:00



## Why British homeowners will carry the can for our troubled water companies
 - [https://www.telegraph.co.uk/money/consumer-affairs/why-homeowners-pay-price-britains-water-companies/](https://www.telegraph.co.uk/money/consumer-affairs/why-homeowners-pay-price-britains-water-companies/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T10:00:00+00:00



## England vs Australia, Ashes second Test day five live: Latest updates from Lord's
 - [https://www.telegraph.co.uk/cricket/2023/07/02/england-vs-australia-ashes-second-test-day-5-lords-live/](https://www.telegraph.co.uk/cricket/2023/07/02/england-vs-australia-ashes-second-test-day-5-lords-live/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T09:01:55+00:00



## You’d have to be mad to buy a beach hut – and not just because they cost a small fortune
 - [https://www.telegraph.co.uk/property/buy/beach-hut-site-licence-fee-council-buyer-beware/](https://www.telegraph.co.uk/property/buy/beach-hut-site-licence-fee-council-buyer-beware/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T09:00:00+00:00



## Russia-Ukraine war: CIA seizing 'opportunity' to recruit spies in Russia
 - [https://www.telegraph.co.uk/world-news/2023/07/02/ukraine-russia-war-latest-cia-recruit-spies/](https://www.telegraph.co.uk/world-news/2023/07/02/ukraine-russia-war-latest-cia-recruit-spies/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T08:38:27+00:00



## Cream horns recipe
 - [https://www.telegraph.co.uk/recipes/0/cream-horns-recipe-mark-hix-dessert/](https://www.telegraph.co.uk/recipes/0/cream-horns-recipe-mark-hix-dessert/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T07:00:00+00:00



## Rump of lamb with summer pea salad recipe
 - [https://www.telegraph.co.uk/recipes/0/rump-of-lamb-with-summer-pea-salad-recipe/](https://www.telegraph.co.uk/recipes/0/rump-of-lamb-with-summer-pea-salad-recipe/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T07:00:00+00:00



## ‘A diamond fell out of my £20k ring and my insurer refuses to pay’
 - [https://www.telegraph.co.uk/money/katie-investigates/diamond-20k-ring-insurer-refuses-pay/](https://www.telegraph.co.uk/money/katie-investigates/diamond-20k-ring-insurer-refuses-pay/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T07:00:00+00:00



## ‘My dad made a fortune from Polly Pocket and sent me to Eton’
 - [https://www.telegraph.co.uk/money/fame-fortune/jesse-norman-polly-pocket-upbringing-privilege-conservative/](https://www.telegraph.co.uk/money/fame-fortune/jesse-norman-polly-pocket-upbringing-privilege-conservative/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-02T05:00:00+00:00



