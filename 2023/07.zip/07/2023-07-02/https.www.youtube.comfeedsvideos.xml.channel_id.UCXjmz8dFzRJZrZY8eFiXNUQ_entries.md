# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## why parks and rec fired this character #shorts
 - [https://www.youtube.com/watch?v=xT8Ni1AWMBQ](https://www.youtube.com/watch?v=xT8Ni1AWMBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-07-02T15:00:43+00:00

Check Out the Full Video: https://youtu.be/V-kM7L8kdSM

Subscribe to Nerdstalgic! https://www.youtube.com/@UCXjmz8dFzRJZrZY8eFiXNUQ 

#parksandrec #parksandrecreation #leslieknope #ronswanson #sitcom #tv #whytheyfired

