# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## "Te naciski są od dawna, to nie były pierwsze, ani ostatnie też nie będą"
 - [https://tvn24.pl/polska/te-naciski-sa-od-dawna-to-nie-byly-pierwsze-ani-ostatnie-tez-nie-beda-7199628?source=rss](https://tvn24.pl/polska/te-naciski-sa-od-dawna-to-nie-byly-pierwsze-ani-ostatnie-tez-nie-beda-7199628?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T19:24:04+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-atx01v-lozafoto2-7199661/alternates/LANDSCAPE_1280" />
    Redaktorki i redaktorzy naczelni polskich mediów rozmawiali w specjalnym wydaniu "Loży Prasowej" na temat nacisków rządzących na wolne media w Polsce. - Jest duża nerwówka i obawa przed utratą władzy - mówił Tomasz Sekielski, "Newsweek". - To ciśnienie jest ogromne i coraz większe z każdym rokiem - stwierdziła Agnieszka Szymkiewicz, Świdnica24. - To jest działanie autorytarnej władzy - mówił zastępca redaktora naczelnego "Gazety Wyborczej" Piotr Stasiński. - Naciski są od dawna, to nie były pierwsze, ani ostatnie też nie będą - powiedział Bartosz Węglarczyk, Onet. - Niestety tak jest, jak po prostu politycy za długo rządzą - stwierdził Daniel Długosz z "Nowej Gazety Trzebnickiej". Magda Jethon, redaktorka naczelna Radia Nowy Świat, opowiedziała o stosunku polityków oraz osób związanych z obozem rządzącym do niezależnych mediów.

## Błyszczące pierścienie i malutkie księżyce. Saturn w obiektywie Teleskopu Webba
 - [https://tvn24.pl/tvnmeteo/nauka/saturn-w-obiektywie-teleskopu-webba-7199676?source=rss](https://tvn24.pl/tvnmeteo/nauka/saturn-w-obiektywie-teleskopu-webba-7199676?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T19:17:07+00:00

<img alt="Błyszczące pierścienie i malutkie księżyce. Saturn w obiektywie Teleskopu Webba" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-k3u6j9-saturn-w-obiektywie-teleskopu-webba-7199700/alternates/LANDSCAPE_1280" />
    Kosmiczny Teleskop Jamesa Webba wykonał pierwsze zdjęcia Saturna. Szósta planeta od Słońca została uwieczniona w podczerwieni, w której jej pierścienie wyglądają na wyjątkowo jasne. Naukowcy mają nadzieję, że obserwacje gazowego olbrzyma pozwolą na lepsze poznanie jego licznych księżyców.

## W Polsce masowo amputuje się palce i stopy cukrzykom, a można byłoby tego uniknąć
 - [https://fakty.tvn24.pl/zobacz-fakty/w-polsce-masowo-amputuje-sie-palce-i-stopy-cukrzykom-a-mozna-byloby-tego-uniknac-7199593?source=rss](https://fakty.tvn24.pl/zobacz-fakty/w-polsce-masowo-amputuje-sie-palce-i-stopy-cukrzykom-a-mozna-byloby-tego-uniknac-7199593?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T18:08:38+00:00

<img alt="W Polsce masowo amputuje się palce i stopy cukrzykom, a można byłoby tego uniknąć " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-ehjpsq-w-polsce-masowo-amputuje-sie-palce-i-stopy-cukrzykom-a-mozna-byloby-tego-uniknac-7199597/alternates/LANDSCAPE_1280" />
    7000 chorych rocznie jest skazanych na amputację z powodu cukrzycy. Stopa cukrzycowa to przewlekłe powikłanie tej choroby, ale można je leczyć. Dlaczego w Polsce się to nie opłaca?

## Pogoda na jutro - poniedziałek 03.07. Noc miejscami mglista, pochmurny dzień
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-poniedzialek-0307-noc-miejscami-mglista-pochmurny-dzien-7199594?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-poniedzialek-0307-noc-miejscami-mglista-pochmurny-dzien-7199594?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T17:21:17+00:00

<img alt="Pogoda na jutro - poniedziałek 03.07. Noc miejscami mglista, pochmurny dzień" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vetqls-pochmurny-letni-dzien-5773890/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na poniedziałek 03.07. Kolejne godziny przyniosą nam pochmurne niebo, które w ciągu nocy będzie się rozpogadzać. Nad ranem lokalnie prognozowane są mgły. Początek tygodnia zapowiada się natomiast pochmurno, a na termometrach zobaczymy od 21 do 27 stopni Celsjusza.

## Przed nami Pełnia Koźlego Księżyca. Zapowiada się szczególnie efektownie
 - [https://tvn24.pl/tvnmeteo/ciekawostki/superpelnia-ksiezyca-kozli-ksiezyc-2023-kiedy-pelnia-w-lipcu-7199546?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/superpelnia-ksiezyca-kozli-ksiezyc-2023-kiedy-pelnia-w-lipcu-7199546?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T16:31:31+00:00

<img alt="Przed nami Pełnia Koźlego Księżyca. Zapowiada się szczególnie efektownie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecieb7fa578894e2460be980b812203cec55-przed-nami-pelnia-ksiezyca-5220532/alternates/LANDSCAPE_1280" />
    Lipcowa pełnia Księżyca, zwana także Koźlim lub Burzowym Księżycem, zbliża się wielkimi krokami. W tym roku będzie ona wyjątkowo efektowna, ponieważ zbiegnie się w czasie ze zjawiskiem superpełni - nasz naturalny satelita znajdzie się bliżej Ziemi niż zwykle.

## Joe Biden uda się do Europy. Głównym celem szczyt NATO w Wilnie
 - [https://tvn24.pl/swiat/joe-biden-uda-sie-do-europy-glownym-celem-szczyt-nato-w-wilnie-7199577?source=rss](https://tvn24.pl/swiat/joe-biden-uda-sie-do-europy-glownym-celem-szczyt-nato-w-wilnie-7199577?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T15:58:34+00:00

<img alt="Joe Biden uda się do Europy. Głównym celem szczyt NATO w Wilnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fru8bs-prezydent-usa-joe-biden-7196568/alternates/LANDSCAPE_1280" />
    Prezydent USA Joe Biden rozpocznie pod koniec następnego tygodnia wizytę w Europie. Głównym celem jego podróży będzie szczyt NATO w Wilnie. Amerykański przywódca odwiedzi także Finlandię, aby upamiętnić jej wstąpienie do sojuszu, oraz Wielką Brytanię - ogłosił w niedzielę Biały Dom.

## "WSJ": Brazylia może być rajem dla rosyjskich szpiegów
 - [https://tvn24.pl/swiat/wsj-brazylia-moze-byc-rajem-dla-rosyjskich-szpiegow-7199441?source=rss](https://tvn24.pl/swiat/wsj-brazylia-moze-byc-rajem-dla-rosyjskich-szpiegow-7199441?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T15:56:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mpcotb-shutterstock_792043942-7199453/alternates/LANDSCAPE_1280" />
    Rosyjscy szpiedzy działający między innymi w Stanach Zjednoczonych i Norwegii posługują się nielegalnie zdobytymi paszportami brazylijskimi. W Brazylii władze badają, czy Moskwa wykorzystuje ten kraj jako inkubator dla tajnych agentów, którzy będą infiltrować Zachód - pisze w niedzielę "Wall Street Journal".

## ISW: operacje Ukraińców są zagrożeniem, Rosjanie ściągają na kierunek bachmucki dodatkowe siły
 - [https://tvn24.pl/swiat/instytut-badan-nad-wojna-w-odpowiedzi-na-ukrainskie-operacje-wokol-bachmutu-rosjanie-wycofuja-sily-z-innych-regionow-ukrainy-7199323?source=rss](https://tvn24.pl/swiat/instytut-badan-nad-wojna-w-odpowiedzi-na-ukrainskie-operacje-wokol-bachmutu-rosjanie-wycofuja-sily-z-innych-regionow-ukrainy-7199323?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T14:59:56+00:00

<img alt="ISW: operacje Ukraińców są zagrożeniem, Rosjanie ściągają na kierunek bachmucki dodatkowe siły  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m7gv3j-ukraina-wojsko-7175213/alternates/LANDSCAPE_1280" />
    Operacje Ukraińców wokół Bachmutu mogą być zagrożeniem dla rosyjskiego dowództwa w obwodach chersońskim i ługańskim - ocenia w najnowszym raporcie amerykański Instytut Badań nad Wojną (ISW). Siły rosyjskie prawdopodobnie wycofują swoje wojska z innych regionów Ukrainy i przerzucają je na ten odcinek – analizują eksperci.

## Strzelanina podczas wydarzenia sąsiedzkiego w USA. Są ranni i zabici, trwa policyjna obława
 - [https://tvn24.pl/swiat/strzelanina-podczas-wydarzenia-sasiedzkiego-w-usa-sa-ranni-i-zabici-trwa-policyjna-oblawa-7199461?source=rss](https://tvn24.pl/swiat/strzelanina-podczas-wydarzenia-sasiedzkiego-w-usa-sa-ranni-i-zabici-trwa-policyjna-oblawa-7199461?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T14:21:25+00:00

<img alt="Strzelanina podczas wydarzenia sąsiedzkiego w USA. Są ranni i zabici, trwa policyjna obława" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dqokzt-pap_20230702_0c1-7199460/alternates/LANDSCAPE_1280" />
    Dwie osoby zginęły, a 28 zostało rannych w strzelaninie, do której doszło w nocy z soboty na niedzielę w Baltimore w USA - przekazała policja. Dziewięciu rannych hospitalizowano, troje z nich jest w stanie krytycznym - poinformowała stacja CNN.

## Takich ulew nie zanotowano tam nigdy. Nie żyje jedna osoba
 - [https://tvn24.pl/tvnmeteo/swiat/japonia-takich-ulew-nie-zanotowano-tam-nigdy-nie-zyje-jedna-osoba-7199440?source=rss](https://tvn24.pl/tvnmeteo/swiat/japonia-takich-ulew-nie-zanotowano-tam-nigdy-nie-zyje-jedna-osoba-7199440?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T13:50:18+00:00

<img alt="Takich ulew nie zanotowano tam nigdy. Nie żyje jedna osoba" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-emalbf-miasto-sanyo-onoda-po-rekordowych-ulewach-7199427/alternates/LANDSCAPE_1280" />
    Część Japonii zmaga się ze skutkami rekordowych ulew. Najtrudniejsza sytuacja panuje w południowo-zachodniej części kraju, gdzie obowiązują ostrzeżenia przed podtopieniami i osuwiskami. Jak podały lokalne media, na skutek żywiołu zginęła co najmniej jedna osoba.

## Kiedy pierwsza obniżka stóp procentowych? Dwa terminy
 - [https://tvn24.pl/biznes/pieniadze/stopy-procentowe-2023-kiedy-pierwsza-obnizka-stop-procentowych-przez-rpp-dwa-terminy-7199408?source=rss](https://tvn24.pl/biznes/pieniadze/stopy-procentowe-2023-kiedy-pierwsza-obnizka-stop-procentowych-przez-rpp-dwa-terminy-7199408?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T13:48:42+00:00

<img alt="Kiedy pierwsza obniżka stóp procentowych? Dwa terminy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rn08h9-nbp-rpp-glapinski-7199459/alternates/LANDSCAPE_1280" />
    Stopy procentowe NBP pozostają na tym samym poziomie od września 2022 roku. Choć Rada Polityki Pieniężnej nie zakończyła formalnie cyklu zacieśniania polityki pieniężnej, to coraz częściej padają terminy, kiedy może dojść do pierwszej obniżki stóp procentowych. W ostatnich dniach takie prognozy zaprezentowali przedstawiciele państwowego Banku Gospodarstwa Krajowego oraz ING Banku Śląskiego.

## Gorąca debata w Chinach o małżeństwach młodych osób. W tle brutalne zabójstwo
 - [https://tvn24.pl/swiat/chiny-brutalne-zabojstwo-w-bialy-dzien-mezczyzna-rozjechal-samochodem-swoja-zone-7198958?source=rss](https://tvn24.pl/swiat/chiny-brutalne-zabojstwo-w-bialy-dzien-mezczyzna-rozjechal-samochodem-swoja-zone-7198958?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T13:45:01+00:00

<img alt="Gorąca debata w Chinach o małżeństwach młodych osób. W tle brutalne zabójstwo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qp2uyx-w-chinach-rosnie-liczba-przypadkow-przemocy-domowej-wsrod-kobiet-7198941/alternates/LANDSCAPE_1280" />
    Chińskie media społecznościowe obiegł film, na którym widać, jak mąż w biały dzień w brutalny sposób rozjeżdża samochodem swoją żonę. Sprawa wywołała oburzenie w Chinach i rozpaliła debatę wśród młodych Chińczyków, którzy coraz rzadziej decydują się na wejście w związek małżeński. W kraju dochodzi bowiem do coraz większej liczby przypadków przemocy domowej wobec kobiet, a droga do rozwodu jest często bardzo kręta i długa.

## Masowy transfer migrantów z ośrodka na Lampedusie
 - [https://tvn24.pl/swiat/wlochy-masowy-transfer-migrantow-z-osrodka-na-lampedusie-7199422?source=rss](https://tvn24.pl/swiat/wlochy-masowy-transfer-migrantow-z-osrodka-na-lampedusie-7199422?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T13:08:26+00:00

<img alt="Masowy transfer migrantów z ośrodka na Lampedusie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i093y1-pap_20230614_3ht-1-7199430/alternates/LANDSCAPE_1280" />
    W ośrodku rejestracji i identyfikacji migrantów na włoskiej Lampedusie jeszcze w piątek przebywało ponad 3300 osób, ośmiokrotnie więcej, niż jest miejsc. Obecnie pozostało tam ośmiuset migrantów. Pozostali zostali wywiezieni do innych ośrodków.

## Ceny ofertowe mieszkań rozpoczęły marsz w górę. Jedno miasto z dwucyfrowym wzrostem
 - [https://tvn24.pl/biznes/nieruchomosci/mieszkania-na-sprzedaz-ceny-ofertowe-maj-2023-katowice-liderem-wzrostow-raport-7199349?source=rss](https://tvn24.pl/biznes/nieruchomosci/mieszkania-na-sprzedaz-ceny-ofertowe-maj-2023-katowice-liderem-wzrostow-raport-7199349?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T13:06:59+00:00

<img alt="Ceny ofertowe mieszkań rozpoczęły marsz w górę. Jedno miasto z dwucyfrowym wzrostem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eaygt4-katowice-7199379/alternates/LANDSCAPE_1280" />
    Mieszkania powoli drożeją. Tak przynajmniej wynika z analizy cen ofertowych, które wzrosły przeciętnie o 4 procent od początku roku - wynika z raportu Expandera i Rentier.io. W ocenie ekspertów przyczyną poprawy nastrojów na rynku jest start programu Bezpieczny Kredyt 2 procent. Wyraźnym liderem wzrostów cen są Katowice.

## "Sytuacja rozdmuchana jako paliwo polityczne przez Morawieckiego jest ogromną zmarnowaną szansą"
 - [https://tvn24.pl/polska/unijna-polityka-migracyjna-i-stanowisko-rzadu-komentarze-w-kawie-na-lawe-7199273?source=rss](https://tvn24.pl/polska/unijna-polityka-migracyjna-i-stanowisko-rzadu-komentarze-w-kawie-na-lawe-7199273?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T12:05:16+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-exh7vs-02-1055-kawa-cl-0002-7199168/alternates/LANDSCAPE_1280" />
    Przez trzy i pół roku przedstawiciele rządu PiS nie zrobili nic, ponieważ wiedzieli, że będą wykorzystywać tę sprawę do polityki wewnętrznej - ocenił w "Kawie na ławę" w TVN24 europoseł PSL Krzysztof Hetman, odnosząc się do unijnego paktu migracyjnego i stanowiska polskiego rządu w tej kwestii. Posłanka Lewicy Agnieszka Dziemianowicz-Bąk podkreślała, że "państwo przyfrontowe nie powinno myśleć, że z presją migracyjną będzie sobie w stanie poradzić samodzielnie". - Nie możemy się na to zgodzić i to jest sprzeczne z polską racją stanu, żeby przyjmować do Polski niezweryfikowanych ludzi, którzy trafili do Europy w sposób nielegalny - mówił wiceszef MSWiA Błażej Poboży.

## 23-latek rozbił auto na drzewie. Policjanci wyczuli od niego alkohol
 - [https://tvn24.pl/pomorze/23-latek-rozbil-auto-na-drzewie-policjanci-wyczuli-od-niego-alkohol-7199331?source=rss](https://tvn24.pl/pomorze/23-latek-rozbil-auto-na-drzewie-policjanci-wyczuli-od-niego-alkohol-7199331?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T11:59:36+00:00

<img alt="23-latek rozbił auto na drzewie. Policjanci wyczuli od niego alkohol" src="https://tvn24.pl/pomorze/cdn-zdjecie-dpzeaq-23-latek-rozbil-auto-na-drzewie-policjanci-wyczuli-od-niego-alkohol-7199347/alternates/LANDSCAPE_1280" />
    W nocy z soboty na niedzielę doszło do poważnego wypadku na trasie Pisz -Turośl w województwie warmińsko-mazurskim. Z nieznanych jak dotąd przyczyn kierowca stracił panowanie nad autem i uderzył w drzewo.

## Ewa Ewart: trzeba położyć kres sposobowi, w jaki zarządzamy rzekami
 - [https://tvn24.pl/polska/ewa-ewart-i-film-do-ostatniej-kropli-z-nagroda-us-international-awards-los-angeles-2023-rezyserka-o-zlym-zarzadzaniu-rzekami-7199316?source=rss](https://tvn24.pl/polska/ewa-ewart-i-film-do-ostatniej-kropli-z-nagroda-us-international-awards-los-angeles-2023-rezyserka-o-zlym-zarzadzaniu-rzekami-7199316?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T11:56:17+00:00

<img alt="Ewa Ewart: trzeba położyć kres sposobowi, w jaki zarządzamy rzekami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rsnyzs-ewa-ewart-w-studiu-tvn24-7199361/alternates/LANDSCAPE_1280" />
    Dokument "Do ostatniej kropli" Ewy Ewart został nagodzony podczas US International Awards 2023 w podkategorii Środowisko, Ekologia i Zrównoważony rozwój. - Z całą pewnością członkowie jury musieli docenić fantastyczne zdjęcia, piękną muzykę i mistrzowski montaż. Myślę jednak, że przede wszystkim doceniono przekaz, jaki ten film niesie - mówiła Ewa Ewart podczas wizyty w studiu TVN24. Podkreślała, że "rzeki są wspólnym dobrem" i czas uniemożliwić ich dalszą dewastację.

## Rusza remont ronda "Radosława", będzie węziej
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-remont-ronda-radoslawa-beda-utrudnienia-7199318?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-remont-ronda-radoslawa-beda-utrudnienia-7199318?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T11:47:44+00:00

<img alt="Rusza remont ronda " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2k42m6-rondo-radoslawa-do-remontu-6783157/alternates/LANDSCAPE_1280" />
    Trzeciego lipca drogowcy rozpoczną remont ronda "Radosława". Prace będą podzielone na kilka etapów. Najpierw robotnicy zajmą się wyspą na środku. Kierowcy będą mieli wtedy jeden pas mniej, utrudnienia czekają też rowerzystów i pieszych.

## Rozpoczęta budowa, udziały, rozdzielność majątkowa. Ekspert odpowiada na pytania o kredyty z dopłatą
 - [https://tvn24.pl/biznes/nieruchomosci/bezpieczny-kredyt-2-procent-kredyty-hipoteczne-rozpoczeta-budowa-udzialy-rozdzielnosc-majatkowa-bartosz-turek-odpowiada-na-pytania-przeslane-na-kontakt-24-7199194?source=rss](https://tvn24.pl/biznes/nieruchomosci/bezpieczny-kredyt-2-procent-kredyty-hipoteczne-rozpoczeta-budowa-udzialy-rozdzielnosc-majatkowa-bartosz-turek-odpowiada-na-pytania-przeslane-na-kontakt-24-7199194?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T10:39:30+00:00

<img alt="Rozpoczęta budowa, udziały, rozdzielność majątkowa. Ekspert odpowiada na pytania o kredyty z dopłatą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-txddio-kredyt-umowa-podpis-dokument-7199281/alternates/LANDSCAPE_1280" />
    W poniedziałek ruszy możliwość składania wniosków o Bezpieczny Kredyt 2 procent. Czy można wziąć kredyt na zakup rozpoczętej budowy domu albo budowę całorocznego domu rekreacyjnego? Co w sytuacji małżeństw, które mają rozdzielność majątkową? To tylko część pytań związanych z nowym programem mieszkaniowym, przesłanych na Kontakt 24, na które odpowiedział Bartosz Turek, główny analityk HREIT.

## Prezes Tramwajów Warszawskich we władzach międzynarodowego stowarzyszenia
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-prezes-tramwajow-warszawskich-wojciech-bartelski-zostal-wybrany-na-czlonka-zarzadu-uitp-7199243?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-prezes-tramwajow-warszawskich-wojciech-bartelski-zostal-wybrany-na-czlonka-zarzadu-uitp-7199243?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T10:34:23+00:00

<img alt="Prezes Tramwajów Warszawskich we władzach międzynarodowego stowarzyszenia " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hwd420-wojciech-bartelski-zostal-czlonkiem-zarzadu-uitp-7199276/alternates/LANDSCAPE_1280" />
    Prezes Tramwajów Warszawskich Wojciech Bartelski został członkiem zarządu UITP, czyli Międzynarodowego Stowarzyszenia Transportu Publicznego oraz szefem dywizji tramwajowej. Jego kadencja będzie trwała dwa lata.

## Lotnisko w Radomiu budzi wątpliwości polskiej linii. "Nie wiadomo, jak długo będzie działało"
 - [https://tvn24.pl/biznes/turystyka/lotnisko-warszawa-radom-enter-air-o-funkcjonowaniu-lotniska-grzegorz-polaniecki-komentuje-7199081?source=rss](https://tvn24.pl/biznes/turystyka/lotnisko-warszawa-radom-enter-air-o-funkcjonowaniu-lotniska-grzegorz-polaniecki-komentuje-7199081?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T09:25:28+00:00

<img alt="Lotnisko w Radomiu budzi wątpliwości polskiej linii. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jhst80-pustki-na-lotnisku-warszawa-radom-7082516/alternates/LANDSCAPE_1280" />
    Enter Air, polska linia czarterowa, nie planuje inwestować w hangar na lotnisku Warszawa-Radom. - Nie wiadomo, jak długo to lotnisko będzie działało. Jeśli na lotnisku nie ląduje lub startuje samolot co najmniej co kilkadziesiąt minut, to taki port lotniczy nie będzie rentowny - powiedział dyrektor generalny Grzegorz Polaniecki. - Chociaż z władzami portu współpracuje się dobrze, to nie możemy ryzykować - dodał. Lotniskiem zarządza spółka Polskie Porty Lotnicze (PPL).

## Policja: strzelał z wiatrówki do sąsiadów i samochodów, w domu miał broń pneumatyczną
 - [https://tvn24.pl/tvnwarszawa/najnowsze/myszyniec-ostroleka-policjanci-zatrzymali-mezczyzne-ktory-strzelal-do-sasiadow-i-ich-okien-7199143?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/myszyniec-ostroleka-policjanci-zatrzymali-mezczyzne-ktory-strzelal-do-sasiadow-i-ich-okien-7199143?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T09:10:13+00:00

<img alt="Policja: strzelał z wiatrówki do sąsiadów i samochodów, w domu miał broń pneumatyczną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-awwz5c-policja-zatrzymala-mezczyzne-zdjecie-ilustracyjne-7194206/alternates/LANDSCAPE_1280" />
    34-latek z pow. ostrołęckiego (Mazowieckie), który, jak podaje policja, strzelał z wiatrówki do zaparkowanych samochodów oraz sąsiadów, trafił do aresztu. W jego domu policjanci znaleźli broń pneumatyczną, noże taktyczne, gaz pieprzowy oraz pałkę teleskopową.

## Urwane koło, zniszczony bok. Zderzenie dwóch samochodów na Czerniakowskiej
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dwa-samochody-osobowe-zderzyly-sie-na-czerniakowskiej-7199105?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dwa-samochody-osobowe-zderzyly-sie-na-czerniakowskiej-7199105?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T08:52:08+00:00

<img alt="Urwane koło, zniszczony bok. Zderzenie dwóch samochodów na Czerniakowskiej " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-r4wgf7-zderzenie-dwoch-samochodow-przy-czerniakowskiej-7199133/alternates/LANDSCAPE_1280" />
    Toyota i audi zderzyły się na ulicy Czerniakowskiej. Pojazdy są zniszczone, uszkodzony jest też znak drogowy.

## Zamieszki we Francji. "Nastąpiła poważna radykalizacja opinii publicznej. Władze muszą się z tym liczyć"
 - [https://tvn24.pl/swiat/zamieszki-we-francji-dziennikarz-piotr-moszynski-nastapila-powazna-radykalizacja-opinii-publicznej-zada-przywrocenia-porzadku-7199084?source=rss](https://tvn24.pl/swiat/zamieszki-we-francji-dziennikarz-piotr-moszynski-nastapila-powazna-radykalizacja-opinii-publicznej-zada-przywrocenia-porzadku-7199084?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T08:38:45+00:00

<img alt="Zamieszki we Francji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-p7onlt-kolejna-noc-zamieszek-i-starc-z-policja-w-paryzu-7199107/alternates/LANDSCAPE_1280" />
    W ciągu ostatnich dni aresztowano we Francji kilka tysięcy osób, więc nastąpiło w pewnym sensie osłabienie zasobów ludzkich tych najradykalniejszych grup - mówił w TVN24 Piotr Moszyński, korespondent "Gazety Wyborczej" odnosząc się do informacji władz, że ostatnia noc w kraju, gdzie trwają zamieszki po śmierci nastolatka zastrzelonego w czasie policyjnej interwencji, była spokojniejsza. Dziennikarz zauważył także, że w odpowiedzi na działania uczestników zamieszek, "nastąpiła też z drugiej strony naprawdę poważna radykalizacja opinii publicznej", która "żąda" przywrócenia porządku. - Władze muszą się z tym liczyć i ostatniej nocy najwyraźniej się już z tym liczyły - dodał.

## Z półkuli północnej znika śnieg. "Klimatolodzy to przewidzieli"
 - [https://tvn24.pl/tvnmeteo/nauka/z-polkuli-polnocnej-znika-pokrywa-sniezna-zmiany-klimatu-klimatolodzy-to-przewidzieli-7199010?source=rss](https://tvn24.pl/tvnmeteo/nauka/z-polkuli-polnocnej-znika-pokrywa-sniezna-zmiany-klimatu-klimatolodzy-to-przewidzieli-7199010?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T07:28:32+00:00

<img alt="Z półkuli północnej znika śnieg. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tw926i-arktyka-6142762/alternates/LANDSCAPE_1280" />
    W wyniku zmian klimatu doszło do znaczącego zaniku pokrywy śnieżnej na półkuli północnej - donoszą naukowcy na łamach "Journal of Hydrometeorology". Do takich wniosków doszli na podstawie analizy danych z lat 1967-2021.

## Podczas niemieckiej okupacji była miejscem tajnych spotkań. Nauczycielska willa została zabytkiem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/halinow-podczas-niemieckiej-okupacji-byla-miejscem-tajnych-spotkan-willa-wanda-zostala-zabytkiem-7196413?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/halinow-podczas-niemieckiej-okupacji-byla-miejscem-tajnych-spotkan-willa-wanda-zostala-zabytkiem-7196413?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T07:07:26+00:00

<img alt="Podczas niemieckiej okupacji była miejscem tajnych spotkań. Nauczycielska willa została zabytkiem " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-y169wl-willa-wanda-w-halinowie-7196489/alternates/LANDSCAPE_1280" />
    Wybudowana w dwudziestoleciu międzywojennym w podwarszawskim Halinowie (powiat miński) willa "Wanda" trafiła do rejestru zabytków. W czasie drugiej wojny światowej okazały dom był miejscem tajnych spotkań członków podziemnych organizacji oraz punktem sanitarnym.

## Gdzie jest burza? Znów słychać grzmoty
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-207-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-7199024?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-207-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-7199024?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T06:20:58+00:00

<img alt="Gdzie jest burza? Znów słychać grzmoty" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dyjs5c-wyladowania-po-godzinie-14-7199383/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W niedzielę po południu nad częścią Polski pojawiają się wyładowania atmosferyczne. Zjawiskom towarzyszą porywy wiatru osiągające prędkość do 70 kilometrów na godzinę. Sprawdź, gdzie jest burza, i śledź aktualną sytuację pogodową w kraju na tvnmeteo.pl.

## Stery w pogodzie przejmuje niż Otto. Nad Polską przesuwa się chłodny front
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-w-polsce-niedziela-207-niz-otto-stery-w-pogodzie-przejmuje-niz-otto-nad-polska-przesuwa-sie-chlodny-front-7198979?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-w-polsce-niedziela-207-niz-otto-stery-w-pogodzie-przejmuje-niz-otto-nad-polska-przesuwa-sie-chlodny-front-7198979?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T04:48:21+00:00

<img alt="Stery w pogodzie przejmuje niż Otto. Nad Polską przesuwa się chłodny front" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-oqzrvj-stery-w-pogodzie-przejmuje-niz-otto-7198984/alternates/LANDSCAPE_1280" />
    Jak poinformowała w niedzielę synoptyk tvnmeteo.pl Arleta Unton-Pyziołek, nad Polską przesuwa się chłodny front atmosferyczny. Ściąga on z północnego zachodu chłodniejsze masy powietrza polarnego, wypychającego ciepłe na wschód.

## Pogoda na dziś - niedziela, 2.07. W wielu miejscach przydadzą się parasole
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-niedziela-207-w-wielu-miejscach-przydadza-sie-parasole-7198879?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-niedziela-207-w-wielu-miejscach-przydadza-sie-parasole-7198879?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-02T00:00:00+00:00

<img alt="Pogoda na dziś - niedziela, 2.07. W wielu miejscach przydadzą się parasole" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i18gaa-spadnie-deszcz-5778694/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Niedziela 2.07 przyniesie przelotne opady deszczu. W ciągu dnia nieco się rozpogodzi. Na termometrach zobaczymy maksymalnie 25 stopni Celsjusza.

