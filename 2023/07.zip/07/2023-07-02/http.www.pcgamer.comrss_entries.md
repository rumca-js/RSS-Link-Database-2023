# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Revived mecha RPG classic Front Mission 1st: Remake comes to PC
 - [https://www.pcgamer.com/revived-mecha-rpg-classic-front-mission-1st-remake-comes-to-pc](https://www.pcgamer.com/revived-mecha-rpg-classic-front-mission-1st-remake-comes-to-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-02T22:22:51+00:00

I'm writing this because I like to say the word Wanzers.

## BattleBit devs fought constant DDoS attacks, but the blocky shooter has a big future
 - [https://www.pcgamer.com/battlebit-devs-fought-constant-ddos-attacks-but-the-blocky-shooter-has-a-big-future](https://www.pcgamer.com/battlebit-devs-fought-constant-ddos-attacks-but-the-blocky-shooter-has-a-big-future)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-02T21:44:07+00:00

The hot new Steam FPS' developers break down weeks of battles against bad actors.

## Build and defend a cool castle, block by block, in the Cataclismo demo
 - [https://www.pcgamer.com/build-and-defend-a-cool-castle-block-by-block-in-the-cataclismo-demo](https://www.pcgamer.com/build-and-defend-a-cool-castle-block-by-block-in-the-cataclismo-demo)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-02T20:53:25+00:00

Horrors emerge from the mist, and you must end them.

## There's a new Resident Evil 4 mod that brings the remake's best addition back in time to the original game
 - [https://www.pcgamer.com/theres-a-new-resident-evil-4-mod-that-brings-the-remakes-best-addition-back-in-time-to-the-original-game](https://www.pcgamer.com/theres-a-new-resident-evil-4-mod-that-brings-the-remakes-best-addition-back-in-time-to-the-original-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-02T19:22:17+00:00

Sekiro-style parrying with an '05 flair.

## Valve is scrutinizing games with AI assets on Steam, says avoiding copyright violation 'is the developer's responsibility'
 - [https://www.pcgamer.com/valve-is-scrutinizing-games-with-ai-assets-on-steam-says-avoiding-copyright-violation-is-the-developers-responsibility](https://www.pcgamer.com/valve-is-scrutinizing-games-with-ai-assets-on-steam-says-avoiding-copyright-violation-is-the-developers-responsibility)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-02T16:23:13+00:00

There's no full, formal policy as of yet, but Steam's boundaries are starting to materialize.

## CS:GO ban wave results in over $2 million worth of skins and other items being lost
 - [https://www.pcgamer.com/csgo-ban-wave-results-in-over-dollar2-million-worth-of-skins-and-other-items-being-lost](https://www.pcgamer.com/csgo-ban-wave-results-in-over-dollar2-million-worth-of-skins-and-other-items-being-lost)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-02T03:52:45+00:00

A skin gambling site has taken this as proof of victory over its rival, who it accused of crypto money laundering.

## Today's Wordle hint and answer #743: Sunday, July 2
 - [https://www.pcgamer.com/wordle-answer-today-hint-743-july-2](https://www.pcgamer.com/wordle-answer-today-hint-743-july-2)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-02T03:07:44+00:00

A hint to help you out and today's Wordle answer if you need it.

## Prepare to bow to Sauron, the One Ring has been found (as a unique Magic card worth a million bucks)
 - [https://www.pcgamer.com/prepare-to-bow-to-sauron-the-one-ring-has-been-found-as-a-unique-magic-card-worth-a-million-bucks](https://www.pcgamer.com/prepare-to-bow-to-sauron-the-one-ring-has-been-found-as-a-unique-magic-card-worth-a-million-bucks)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-02T01:10:35+00:00

The one-of-a-kind Magic: The Gathering card was authenticated by PSA, who gave it a 9 out of 10.

