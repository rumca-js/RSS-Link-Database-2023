# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Bud Light Pitch Meeting!
 - [https://www.youtube.com/watch?v=1m4mqh2AX4o](https://www.youtube.com/watch?v=1m4mqh2AX4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-07-02T15:45:55+00:00

#shorts  Featuring @ChandlerJuliet

