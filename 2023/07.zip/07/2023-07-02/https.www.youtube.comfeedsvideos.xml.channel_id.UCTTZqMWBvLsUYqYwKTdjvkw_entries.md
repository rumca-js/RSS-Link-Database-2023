# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Oszustwa w grach
 - [https://www.youtube.com/watch?v=2Zjld_nVBLk](https://www.youtube.com/watch?v=2Zjld_nVBLk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-07-02T16:00:02+00:00

🕹️ Pewnie wielu z Was, tak jak ja, lubi grać w różne gry. No ale przecież nie po to, żeby ciągle przegrywać. O ile w takiego tenisa czy innego squasha trzeba się solidnie napocić, żeby stać się nieco lepszym, to w wielu przypadkach istnieją pewne drogi na skróty. Opowiem Wam dzisiaj o tym jak działają różne oszustwa w grach. Jakie metody stosuje się, żeby zdobyć nieuczciwie przewagę? Czy zawsze trzeba wykorzystywać do tego dodatkowe oprogramowanie? A przede wszystkim - dlaczego w ogóle nie warto tego robić?
 
Źródła:
🎮 Comparative Study of Anti-cheat Methods in Video Games, S. Lehtonen
https://tinyurl.com/332zsyfy

💰 Full list of all Twitch payouts (Twitch leaks)
https://tinyurl.com/5d9ytjdk

🏝️ Pwn Adventure 3: Pwnie Island
https://www.pwnadventure.com

💀 Malware hidden in Call of Duty cheat software proves that cheaters never prosper
https://tinyurl.com/2s48pu5h
 
Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly/tinyurl dokąd prowadzą.
 
Relevant xkcd: https://xkcd.com/606/
 
© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.
❤️ Dziękuję za Waszą uwagę.
 
Znajdziecie mnie również na:
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/ 
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok 
Mastodonie https://infosec.exchange/@mateuszchrobok 
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/ 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok
Podcasty na: 
Anchor https://anchor.fm/mateusz-chrobok 
Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR 
Apple Podcasts https://apple.co/3OwjvOh
 
Rozdziały:
00:00 Intro
01:27 Oszukiwanie
06:39 Grind
09:09 Czas
12:43 Boty
14:56 Wygrana
16:58 Co Robić i Jak Żyć?
 
#cheater #oszustwo #gry #multiplayer #cheat

