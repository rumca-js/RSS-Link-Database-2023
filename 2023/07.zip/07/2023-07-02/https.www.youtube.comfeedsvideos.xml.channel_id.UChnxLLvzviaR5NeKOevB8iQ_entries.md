# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## VCV for Sleep Stream (Ambient Music Live Patching)
 - [https://www.youtube.com/watch?v=hI5exFsxnQ4](https://www.youtube.com/watch?v=hI5exFsxnQ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2023-07-02T21:00:33+00:00

Making ambient music in VCV Rack

