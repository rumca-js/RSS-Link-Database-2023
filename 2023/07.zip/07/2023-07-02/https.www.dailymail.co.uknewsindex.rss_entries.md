# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Passengers on Titan sub likely spent final moments in darkness looking at bioluminescent creatures
 - [https://www.dailymail.co.uk/news/article-12256961/Passengers-Titan-sub-likely-spent-final-moments-darkness-looking-bioluminescent-creatures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256961/Passengers-Titan-sub-likely-spent-final-moments-darkness-looking-bioluminescent-creatures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T23:27:35+00:00

The five people on board the Titan sub, which was lost on June 18, spent their last minutes in total darkness, as the lights were switched off to save battery power, and playing music on Bluetooth.

## Hawaiian Airlines flight from hell photos show moment after plane nosedived on way to Sydney Airport
 - [https://www.dailymail.co.uk/news/article-12256987/Hawaiian-Airlines-flight-hell-photos-moment-plane-nosedived-way-Sydney-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256987/Hawaiian-Airlines-flight-hell-photos-moment-plane-nosedived-way-Sydney-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T23:25:52+00:00

A passenger onboard the Hawaii Airlines flight that hit 'unexpected severe turbulence' while bound for Sydney has shared pictures of the damaged cabin after travellers were thrown from their seats.

## Sydney Airport flights cancelled as disruptions continue for fourth day in a row
 - [https://www.dailymail.co.uk/news/article-12257203/Sydney-Airport-flights-cancelled-disruptions-continue-fourth-day-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12257203/Sydney-Airport-flights-cancelled-disruptions-continue-fourth-day-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T23:24:59+00:00

Sydney Airport has been plagued with more disruptions for a fourth day in a row after more flights were cancelled.

## Wagner warlord Prigozhin has vanished days after mutiny as Kremlin cracks down on business empire
 - [https://www.dailymail.co.uk/news/article-12257107/Wagner-warlord-Prigozhin-vanished-days-mutiny-Kremlin-cracks-business-empire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12257107/Wagner-warlord-Prigozhin-vanished-days-mutiny-Kremlin-cracks-business-empire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T23:24:09+00:00

Yevgeny Prigozhin (pictured) has not been seen since shortly after the collapse of a mutiny by his Wagner Group fighters that rocked Vladimir Putin's regime eight days ago.

## Moment two Colombian Air Force planes crash during a training exercise leaving one pilot dead:
 - [https://www.dailymail.co.uk/news/article-12256945/Moment-two-Colombian-Air-Force-planes-crash-training-exercise-leaving-one-pilot-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256945/Moment-two-Colombian-Air-Force-planes-crash-training-exercise-leaving-one-pilot-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T23:22:57+00:00

Lieutenant Colonel Mario Andres Espinosa lost his life in the incident - which happened just outside the capital Saturday - while the other is now receiving medical attention.

## Mount Tamborine wife Edwina Berry plea to find killer of Matthew Berry on Queensland's Gold Coast
 - [https://www.dailymail.co.uk/news/article-12255547/Mount-Tamborine-wife-Edwina-Berry-plea-killer-Matthew-Berry-Queenslands-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255547/Mount-Tamborine-wife-Edwina-Berry-plea-killer-Matthew-Berry-Queenslands-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T23:20:49+00:00

A homicide investigation is underway after Matthew Berry, 37, was found in his Mount Tamborine home, west of the Gold Coast, just after midday on Thursday.

## Tories urge Rishi Sunak to slash migration by two-thirds in plan to cut figures by 400,000 a year
 - [https://www.dailymail.co.uk/news/article-12256979/Tories-urge-Rishi-Sunak-slash-migration-two-thirds-plan-cut-figures-400-000-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256979/Tories-urge-Rishi-Sunak-slash-migration-two-thirds-plan-cut-figures-400-000-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T23:17:54+00:00

The New Conservatives lobby group will tell the Prime Minister the party must 'honour the promise' made in the 2019 manifesto to cut net immigration to below the level at the time.

## How long will Canada burn? Smoke will choke NYC and the east coast throughout summer
 - [https://www.dailymail.co.uk/news/article-12256991/How-long-Canada-burn-Smoke-choke-NYC-east-coast-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256991/How-long-Canada-burn-Smoke-choke-NYC-east-coast-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T23:00:57+00:00

Canadian fires continue to burn and will send smoke over New York City and the east coast throughout the summer - as experts warn firefighting operations could last until September.

## China been preparing for war with US for DECADES racing ahead while Army takes gender pronoun class
 - [https://www.dailymail.co.uk/news/article-12256939/China-preparing-war-DECADES-racing-ahead-Army-takes-gender-pronoun-class.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256939/China-preparing-war-DECADES-racing-ahead-Army-takes-gender-pronoun-class.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T22:46:01+00:00

Republican presidential hopeful Nikki Haley shared concerns about China's military emphasizing that the country has been preparing for war for years. Haley is a former US ambassador to the UN.

## Children rescued after car veers off road at Harrietville, Victoria, on Sunday
 - [https://www.dailymail.co.uk/news/article-12257049/Children-rescued-car-veers-road-Harrietville-Victoria-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12257049/Children-rescued-car-veers-road-Harrietville-Victoria-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T22:15:10+00:00

Police were called to Great Apline Rd at Harrietville in northwest Victoria shortly after 6pm on Sunday.

## Keir Starmer accused of 'double standards' as it emerges he will hire Sue Grey as his chief of staff
 - [https://www.dailymail.co.uk/news/article-12257015/Keir-Starmer-accused-double-standards-emerges-hire-Sue-Grey-chief-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12257015/Keir-Starmer-accused-double-standards-emerges-hire-Sue-Grey-chief-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T22:14:22+00:00

Sir Keir Starmer was yesterday accused of 'double standards' as it emerged he will still hire Sue Gray despite an inquiry expected tomorrow to find her guilty of breaking civil service rules.

## Q1 tower Gold Coast evacuated after fire erupts
 - [https://www.dailymail.co.uk/news/article-12257039/Q1-tower-Gold-Coast-evacuated-fire-erupts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12257039/Q1-tower-Gold-Coast-evacuated-fire-erupts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T22:11:56+00:00

A fire has erupted at the Q1 Tower in the Gold Coast.

## RMT union leaders are branded 'hypocritical' as they try to slash jobs and pay among their own staff
 - [https://www.dailymail.co.uk/news/article-12256933/RMT-union-leaders-branded-hypocritical-try-slash-jobs-pay-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256933/RMT-union-leaders-branded-hypocritical-try-slash-jobs-pay-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T22:09:40+00:00

The Daily Mail can reveal the strike-backing rail union is facing a revolt from catering and office staff at its National Education Centre in Doncaster.

## Sydney, Melbourne, Brisbane weather: Cold blast and rain this week
 - [https://www.dailymail.co.uk/news/article-12256829/Sydney-Melbourne-Brisbane-weather-Cold-blast-rain-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256829/Sydney-Melbourne-Brisbane-weather-Cold-blast-rain-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T22:07:39+00:00

A cold blast will strike most of Australia as temperatures plunge to record lows and an entire state braces for a week of heavy rain.

## The ex-mayor trapped face-down for FIVE DAYS behind a football club pavilion
 - [https://www.dailymail.co.uk/news/article-12256831/The-ex-mayor-trapped-face-FIVE-DAYS-football-club-pavilion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256831/The-ex-mayor-trapped-face-FIVE-DAYS-football-club-pavilion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T22:01:45+00:00

Former Mayor Chris Cummins, 75, was wedged face down on the ground at the back on Redbridge FC's Oakside Stadium for five days after attempting to take a shortcut on his walk to the train station

## US expert on Titanic wreck believes tourist visits will resume despite tragic deaths of five
 - [https://www.dailymail.co.uk/news/article-12256543/US-expert-Titanic-wreck-believes-tourist-visits-resume-despite-tragic-deaths-five.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256543/US-expert-Titanic-wreck-believes-tourist-visits-resume-despite-tragic-deaths-five.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:57:30+00:00

A US expert on the Titanic wreck believes tourists visits will resume despite the  tragic deaths of five on the OceanGate Titan.

## Geelong, Newtown: Woman's body found after home bursts into flames
 - [https://www.dailymail.co.uk/news/article-12256923/Geelong-Newtown-Womans-body-home-bursts-flames.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256923/Geelong-Newtown-Womans-body-home-bursts-flames.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:54:25+00:00

A woman's dead body has been found after a house fire in Geelong.

## 'Boil in a bag' funerals to become available in Britain after catching on around the world
 - [https://www.dailymail.co.uk/news/article-12256875/Boil-bag-funerals-available-Britain-catching-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256875/Boil-bag-funerals-available-Britain-catching-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:50:31+00:00

Co-op Funeralcare will offer the service known as resomation, later this year, after working with sustainability experts to confirm research. The practice is increasingly popular in the US

## Ministers to tackle rip-off fuel prices at pumps with a petrol price comparison site
 - [https://www.dailymail.co.uk/news/article-12256779/Ministers-tackle-rip-fuel-prices-pumps-petrol-price-comparison-site.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256779/Ministers-tackle-rip-fuel-prices-pumps-petrol-price-comparison-site.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:49:14+00:00

Energy Secretary Grant Shapps is expected to back a new 'Pump Watch' site following a report in the discrepancy in forecourt prices to allow the Government to monitor fuel prices

## Living the high life back in the UK: The Albanian burglar who has already been deported TWICE
 - [https://www.dailymail.co.uk/news/article-12256827/Living-high-life-UK-Albanian-burglar-deported-TWICE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256827/Living-high-life-UK-Albanian-burglar-deported-TWICE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:47:25+00:00

Standing on a luxury Cornish spa hotel's golf course dressed in a scruffy animal print shirt, cargo shorts and sandals, Dorian Puka strikes an incongruous figure.

## Video shows mother bear helping cub climb over fence in northern Los Angeles neighborhood
 - [https://www.dailymail.co.uk/news/article-12256745/Video-shows-mother-bear-helping-cub-climb-fence-northern-Los-Angeles-neighborhood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256745/Video-shows-mother-bear-helping-cub-climb-fence-northern-Los-Angeles-neighborhood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:42:47+00:00

Adorable video out of Los Angeles shows a mama bear looking out for her cub by grabbing the animal with her teeth and pulling the baby over a fence.

## Conservatives slam Biden and his family as 'monsters'
 - [https://www.dailymail.co.uk/news/article-12256777/Conservatives-slam-Biden-family-monsters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256777/Conservatives-slam-Biden-family-monsters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:42:31+00:00

The New York Times reported on Saturday that the White House is refusing to acknowledge Hunter Biden's 4-year-old daughter ahead of the election.

## Banks are to be warned they must protect free speech as Jeremy Hunt is said to be 'deeply concerned'
 - [https://www.dailymail.co.uk/news/article-12256949/Banks-warned-protect-free-speech-Jeremy-Hunt-said-deeply-concerned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256949/Banks-warned-protect-free-speech-Jeremy-Hunt-said-deeply-concerned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:40:56+00:00

The Chancellor Jeremy Hunt (pictured) is reportedly 'deeply concerned' that lenders are blacklisting customers they are deemed to hold contrary political beliefs and social values.

## William Tyrrell: How poor 'bogans' got treated as criminals when rich foster couple lost their son
 - [https://www.dailymail.co.uk/news/article-12245783/William-Tyrrell-poor-bogans-got-treated-criminals-rich-foster-couple-lost-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12245783/William-Tyrrell-poor-bogans-got-treated-criminals-rich-foster-couple-lost-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:36:43+00:00

The problems that beset the William Tyrrell case go to the heart of the foster parent system.
On one side, there's a wealthy, couple in a $4m home, on the other side a 'bogan' couple.

## Guy Ritchie wins planning battle to erect luxury wooden cabins for wealthy clients at country estate
 - [https://www.dailymail.co.uk/news/article-12256619/Guy-Ritchie-wins-planning-battle-erect-luxury-wooden-cabins-wealthy-clients-country-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256619/Guy-Ritchie-wins-planning-battle-erect-luxury-wooden-cabins-wealthy-clients-country-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:22:39+00:00

Film-making legend Guy Ritchie has won a planning battle to allow him to erect luxury holiday cabins at his £9million country estate in Ashcombe Estate, Wiltshire

## Labour and SNP accused of hypocrisy over asylum seekers as Scotland and Wales not housing enough
 - [https://www.dailymail.co.uk/news/article-12256931/Labour-SNP-accused-hypocrisy-asylum-seekers-Scotland-Wales-not-housing-enough.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256931/Labour-SNP-accused-hypocrisy-asylum-seekers-Scotland-Wales-not-housing-enough.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:18:04+00:00

Data shows Scotland is housing just 5,086 asylum seekers out of a total of 112,294. This amounts to 4.5 per cent despite Scotland making up 8.1 per cent of the UK population.

## Peers party with Putin's man in London at a reception at the Russian Embassy
 - [https://www.dailymail.co.uk/news/article-12256821/Peers-party-Putins-man-London-reception-Russian-Embassy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256821/Peers-party-Putins-man-London-reception-Russian-Embassy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:11:34+00:00

Historian and crossbench peer Lord Skidelsky (pictured) and Tory Lord Balfe were among around 50 guests at the 'Russia Day' event on June 12.

## Why electric cars are NOT green machines: The environmental benefit of EVs may never be felt
 - [https://www.dailymail.co.uk/news/article-12256823/Why-electric-cars-NOT-green-machines-environmental-benefit-EVs-never-felt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256823/Why-electric-cars-NOT-green-machines-environmental-benefit-EVs-never-felt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:08:18+00:00

Electric cars need to be used for tens of thousands of miles before they offset the higher releases, with VW's e-Golf becoming more environmentally friendly after 77,000 miles, according to new figures.

## Put brakes on drive to ban petrol and diesel cars by 2030, MPs and industry leaders tell ministers
 - [https://www.dailymail.co.uk/news/article-12256847/Put-brakes-drive-ban-petrol-diesel-cars-2030-MPs-industry-leaders-tell-ministers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256847/Put-brakes-drive-ban-petrol-diesel-cars-2030-MPs-industry-leaders-tell-ministers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T21:08:03+00:00

Exclusive polling for the Daily Mail found that only a quarter of the public agree with the Government's deadline. More than half disagree with the rush to switch to electric cars.

## Sopranos star Michael Imperioli sarcastically thanks Supreme Court for allowing him to discriminate
 - [https://www.dailymail.co.uk/news/article-12256685/Sopranos-star-Michael-Imperioli-sarcastically-thanks-Supreme-Court-allowing-discriminate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256685/Sopranos-star-Michael-Imperioli-sarcastically-thanks-Supreme-Court-allowing-discriminate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T20:41:35+00:00

Sopranos star Michael Imperioli sarcastically thanked the Supreme Court for 'allowing' him to discriminate as he banned 'bigots' and 'homophobes' in an Instagram post Saturday.

## AOC says Supreme Court rulings are 'authoritarian' - but most Americans agree with SCOTUS
 - [https://www.dailymail.co.uk/news/article-12256671/AOC-says-Supreme-Court-rulings-authoritarian-Americans-agree-SCOTUS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256671/AOC-says-Supreme-Court-rulings-authoritarian-Americans-agree-SCOTUS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T20:38:37+00:00

AOC said the trio of recent Supreme Court rulings brings into question the 'legitimacy' of the bench's politicalization - and a new poll shows more than half of Americans agree but most approve of decisions.

## Hero drowns saving two children in lake at Pennsylvania State Park
 - [https://www.dailymail.co.uk/news/article-12256759/Hero-drowns-saving-two-children-lake-Pennsylvania-State-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256759/Hero-drowns-saving-two-children-lake-Pennsylvania-State-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T20:32:16+00:00

Marvin Alexan Fernandez Chicas, 37, drowned after rescuing two children who were swimming at the Tohickon Creek at Nockamixon State Park in Pennsylvania on Thursday.

## Billionaire cowboys snap up America's sprawling ranches, like $350m Yellowstone estate
 - [https://www.dailymail.co.uk/news/article-12238433/Billionaire-cowboys-snap-Americas-sprawling-ranches-like-350m-Yellowstone-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12238433/Billionaire-cowboys-snap-Americas-sprawling-ranches-like-350m-Yellowstone-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T20:31:16+00:00

Ranches across the West are rapidly being bought up by wealthy Americans looking for somewhere to park their cash.

## This quirky lock keeper's cottage on the Oxford Canal has gone on sale for £400,000
 - [https://www.dailymail.co.uk/news/article-12256705/This-quirky-lock-keepers-cottage-Oxford-Canal-gone-sale-400-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256705/This-quirky-lock-keepers-cottage-Oxford-Canal-gone-sale-400-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T19:43:36+00:00

The Grade II listed Deep Lock Cottage, near the village of Somerton, comes complete with the current owner's 33ft narrowboat, and boasts stunning views of the countryside

## 'Much loved' father, 37, dies and another man, 35, fighting for life after horror crash
 - [https://www.dailymail.co.uk/news/article-12256749/Much-loved-father-37-dies-man-35-fighting-life-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256749/Much-loved-father-37-dies-man-35-fighting-life-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T19:38:17+00:00

A 'much loved' father has been killed an another man is fighting for his life after a horrific car crash in Guisborough, North Yorkshire . Kellam Hodgson, 37, died at the scene.

## Care home nurse is struck off after lying to a grandmother's grieving family over circumstances
 - [https://www.dailymail.co.uk/news/article-12256771/Care-home-nurse-struck-lying-grandmothers-grieving-family-circumstances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256771/Care-home-nurse-struck-lying-grandmothers-grieving-family-circumstances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T19:29:59+00:00

A care home nurse has been struck off after he lied to a grieving family that a grandmother died in her sleep - when she had actually choked to death on a sandwich.

## Wife of California sheriff charged with DUI following collision where her Tesla went into a home
 - [https://www.dailymail.co.uk/news/article-12256537/Wife-California-sheriff-charged-DUI-following-collision-Tesla-went-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256537/Wife-California-sheriff-charged-DUI-following-collision-Tesla-went-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T19:23:32+00:00

The wife of a Northern California sheriff has been charged with driving under the influence following a May crash where her Tesla struck a home and injured a person.

## Bombs, molotov cocktail explode outside Nike store, Truist ATM and Safeway in Washington DC
 - [https://www.dailymail.co.uk/news/article-12256669/Bombs-molotov-cocktail-explode-outside-Nike-store-Truist-ATM-Safeway-Washington-DC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256669/Bombs-molotov-cocktail-explode-outside-Nike-store-Truist-ATM-Safeway-Washington-DC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T19:13:37+00:00

A search is underway for the person who targeted Truist Bank, Nike store, and Safeway in Northeast Washington, D.C. with explosive devices and 'Molotov cocktail style object.'

## Cops arrest 2 of 3 glam squad robbers who hit stores in Chicago, California and Colorado
 - [https://www.dailymail.co.uk/news/article-12256373/Cops-arrest-2-3-glam-squad-robbers-hit-stores-Chicago-California-Colorado.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256373/Cops-arrest-2-3-glam-squad-robbers-hit-stores-Chicago-California-Colorado.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T18:50:30+00:00

Colorado cops have nabbed two of the three glam squad robbery trio but are still on the hunt for one of the bandits who already hit stores in Chicago, California and Colorado.

## Multi-millionaire Just Stop Oil supporter Dale Vince defends climate activists disrupting the Ashes
 - [https://www.dailymail.co.uk/news/article-12256025/Labour-Just-Stop-Oil-donor-defends-climate-disruption-political-donations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256025/Labour-Just-Stop-Oil-donor-defends-climate-disruption-political-donations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T18:27:25+00:00

Dale Vince (pictured) was questioned today on Sky News' Sophy Ridge on Sunday about the £1.5million donations he has made to the Labour party over the decade.

## Russia 'fears Wagner fighters are plotting attack on £3billion Crimean Bridge'
 - [https://www.dailymail.co.uk/news/article-12256645/Russia-fears-Wagner-fighters-plotting-attack-3billion-Crimean-Bridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256645/Russia-fears-Wagner-fighters-plotting-attack-3billion-Crimean-Bridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T18:24:57+00:00

The Kremlin is understood to be on high alert amid fears that disgruntled Wagner rebels could plot an attack after their mercenary army was axed by Vladimir Putin in the wake of their mutiny.

## Buttigieg excoriates DeSantis for 'competing' with Trump to 'make life harder' for LGBTQ community
 - [https://www.dailymail.co.uk/news/article-12256431/Buttigieg-excoriates-DeSantis-competing-Trump-make-life-harder-LGBTQ-community.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256431/Buttigieg-excoriates-DeSantis-competing-Trump-make-life-harder-LGBTQ-community.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T18:24:16+00:00

Pete Buttigieg accused Ron DeSantis of 'competing' with Trump over who can hurt the LGBTQ community more while torching his campaign video marking the end of Pride Month.

## Police name mother and her daughter, eight, and son, four, who died in house fire
 - [https://www.dailymail.co.uk/news/article-12256523/Police-mother-daughter-eight-son-four-died-house-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256523/Police-mother-daughter-eight-son-four-died-house-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T18:10:10+00:00

Cambridgeshire Police have named the three victims of the blaze which killed a mother and her two children, while leaving a man fighting for his life. The tragedy occurred in a property in Cambridge.

## Aldi customer horrified after discovering a young ladder snake in his bag of broccoli
 - [https://www.dailymail.co.uk/news/article-12256495/Aldi-customer-horrified-discovering-young-ladder-snake-bag-broccoli.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256495/Aldi-customer-horrified-discovering-young-ladder-snake-bag-broccoli.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T18:07:57+00:00

Neville Linton, 63, said discovering the young ladder snake in the vegetable - which is capable of a nasty bite - was a 'frightening' experience.

## Motorists stuck in queues for hours after tanker carrying 20,000 litres of milk overturned
 - [https://www.dailymail.co.uk/news/article-12256579/Motorists-stuck-queues-hours-tanker-carrying-20-000-litres-milk-overturned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256579/Motorists-stuck-queues-hours-tanker-carrying-20-000-litres-milk-overturned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T18:06:51+00:00

Thousands of litres of produce and diesel were spilled onto the M6 between junctions 31 and 32 near Preston after the crash, which led to two people being treated in hospital

## Minnesota murder suspect accused of chopping up woman now tied to case of missing woman
 - [https://www.dailymail.co.uk/news/article-12256271/Minnesota-murder-suspect-accused-chopping-woman-tied-case-missing-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256271/Minnesota-murder-suspect-accused-chopping-woman-tied-case-missing-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T17:41:22+00:00

Joseph Jorgenson, 40, of Maplewood, Minnesota, who is accused of killing and dismembering Manjieh 'Mani' Starren, is now tied to missing Fanta Xayavong, 33, who vanished in 2021.

## Teenage girl dies and two passengers fighting for their lives in hospital after horror crash
 - [https://www.dailymail.co.uk/news/article-12256481/Teenage-girl-dies-two-passengers-fighting-lives-hospital-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256481/Teenage-girl-dies-two-passengers-fighting-lives-hospital-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T17:34:11+00:00

A teenage girl has sadly passed away while two passengers are fighting for their lives in hospital after a horrific crash on a dual carriageway on the Pistea Flyover, Basildon, Essex.

## CCTV captures armed robbers with boxes full of cash after assaulting drivers who top up ATM machines
 - [https://www.dailymail.co.uk/news/article-12256465/CCTV-captures-armed-robbers-boxes-cash-assaulting-drivers-ATM-machines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256465/CCTV-captures-armed-robbers-boxes-cash-assaulting-drivers-ATM-machines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T17:23:13+00:00

The three men, Paul Dunn, Nathan Kennedy and Liam McCloy stole a total of £260,000 from cash-in-transit delivery drivers and convenience stores and have been jailed for a total of 27 years between them

## Bud Light sales have plummeted so far that two glass bottling plants are FORCED to cut production
 - [https://www.dailymail.co.uk/news/article-12256297/Bud-Light-sales-plummeted-far-two-glass-bottling-plants-FORCED-cut-production.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256297/Bud-Light-sales-plummeted-far-two-glass-bottling-plants-FORCED-cut-production.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T17:14:38+00:00

The Ardagh Group announced last week it was shuttering its Wilson, North Carolina and Simsboro, Louisiana plants amid an ongoing boycott of Bud Light.

## Three killed, one injured in South Carolina small plane crash
 - [https://www.dailymail.co.uk/news/article-12256479/Three-killed-one-injured-South-Carolina-small-plane-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256479/Three-killed-one-injured-South-Carolina-small-plane-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T17:11:54+00:00

Three people have been killed, and one person was injured when a small plane crashed in North Myrtle Beach, South Carolina on Sunday.

## Thieves steal over $700K worth of rare wines in daring break-in at Southern California store
 - [https://www.dailymail.co.uk/news/article-12256345/Thieves-steal-700K-worth-rare-wines-daring-break-Southern-California-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256345/Thieves-steal-700K-worth-rare-wines-daring-break-Southern-California-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T17:00:11+00:00

Thieves got away with over $700,000 in rare wines imported from France and Italy during a break in at a Los Angeles area wine shop over the weekend.

## Prince Harry and Meghan Markle hold hands and share a laugh and joke together in Santa Barbara
 - [https://www.dailymail.co.uk/news/article-12256397/Prince-Harry-Meghan-Markle-hold-hands-share-laugh-joke-Santa-Barbara.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256397/Prince-Harry-Meghan-Markle-hold-hands-share-laugh-joke-Santa-Barbara.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T16:52:14+00:00

Harry and Meghan were spotted holding hands, smiling and laughing as they left an office building in Santa Barbara, California on Friday. It is unknown what business they had visited

## Buttigieg warns of even more 'severe weather' delays to come over July 4 holiday
 - [https://www.dailymail.co.uk/news/article-12256327/Buttigieg-warns-severe-weather-delays-come-July-4-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256327/Buttigieg-warns-severe-weather-delays-come-July-4-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T16:24:46+00:00

Transportation Secretary Pete Buttigieg warned of more massive delays from 'severe weather' over July 4 holiday - but doesn't appear worried with how United plans to deal with embattled CEO.

## Five Just Stop Oil activists who halted annual London Pride parade are charged
 - [https://www.dailymail.co.uk/news/article-12256351/Five-Just-Stop-Oil-activists-halted-annual-London-Pride-parade-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256351/Five-Just-Stop-Oil-activists-halted-annual-London-Pride-parade-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T16:24:19+00:00

Five people have been charged following a Just Stop Oil stunt on Saturday. The eco group sat down in the road at London Pride to protest the Coca-Cola companies use of plastic.

## Tensions grow in Skegness after 'migrant' charged with raping woman in park
 - [https://www.dailymail.co.uk/news/article-12251981/Tensions-grow-Skegness-migrant-charged-raping-woman-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12251981/Tensions-grow-Skegness-migrant-charged-raping-woman-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T16:22:37+00:00

MailOnline can reveal that four of Skegness's hotels which previously provided beds for holidaymakers are currently accommodating an estimated 250 migrants.

## 60 Minutes reporter Amelia Adams uses AI technology to replicate her voice and 'scam' her colleague
 - [https://www.dailymail.co.uk/news/article-12256185/60-Minutes-reporter-Amelia-Adams-uses-AI-technology-replicate-voice-scam-colleague.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256185/60-Minutes-reporter-Amelia-Adams-uses-AI-technology-replicate-voice-scam-colleague.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T16:06:49+00:00

Scammers are starting to implement artificially intelligent technology to trick Australians into giving away their personal information and hard-earned money.

## One-in-four 40-year-olds in the US has never been married, researchers say
 - [https://www.dailymail.co.uk/news/article-12256173/New-study-reveals-record-high-number-40-year-olds-never-married.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256173/New-study-reveals-record-high-number-40-year-olds-never-married.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:52:41+00:00

New study reveals that one-in-four 40-year-olds in the United States have never been married, as four-decade trend of people delaying nuptials continues to skyrocket.

## Secretive Manhattan cult is blamed for iconic artist Jackson Pollock's death
 - [https://www.dailymail.co.uk/news/article-12248077/Secretive-Manhattan-cult-blamed-iconic-artist-Jackson-Pollocks-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12248077/Secretive-Manhattan-cult-blamed-iconic-artist-Jackson-Pollocks-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:47:14+00:00

The Sullivan Institute, a cult based in the Upper West Side of Manhattan, has been accused of contributing towards Jackson Pollock's death.

## He was America's favorite child star in the 1950s, but can YOU guess who the actor is?
 - [https://www.dailymail.co.uk/news/article-12251999/He-Americas-favorite-child-star-1950s-guess-actor-is.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12251999/He-Americas-favorite-child-star-1950s-guess-actor-is.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:47:04+00:00

Exclusive DailyMail.com photos show a beloved child actor of the 1950s running errands with his wife in Los Angeles.

## Military readiness will continue to 'bleed and decay,' say unjustly fired service members
 - [https://www.dailymail.co.uk/news/article-12242969/Military-readiness-continue-bleed-decay-say-unjustly-fired-service-members.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12242969/Military-readiness-continue-bleed-decay-say-unjustly-fired-service-members.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:46:52+00:00

Over 8,000 service members - many who sought religious exemptions - were fired for refusing to comply with the Pentagon's COVID-19 vaccine mandate.

## Britain's first 24-hour Greggs near Canterbury Cathedral in Kent awaits council approval
 - [https://www.dailymail.co.uk/news/article-12256085/Britains-24-hour-Greggs-near-Canterbury-Cathedral-Kent-awaits-council-approval.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256085/Britains-24-hour-Greggs-near-Canterbury-Cathedral-Kent-awaits-council-approval.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:43:46+00:00

The popular bakery chain has applied for a round-the-clock licence to serve sausage rolls, steak bakes and other favourites at its outlet near Canterbury Cathedral in Kent.

## Hunt for mystery vigilante daubing giant penises on potholes
 - [https://www.dailymail.co.uk/news/article-12250319/Hunt-mystery-vigilante-daubing-giant-penises-potholes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12250319/Hunt-mystery-vigilante-daubing-giant-penises-potholes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:42:51+00:00

More than a dozen large potholes on a road leading to Cobham in Surrey have been sprayed with white paint in a phallic shape.

## Plant potted in Gloucester office 14 years ago grows into 600ft monster that has taken over walls
 - [https://www.dailymail.co.uk/news/article-12256115/Plant-potted-Gloucester-office-14-years-ago-grows-600ft-monster-taken-walls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256115/Plant-potted-Gloucester-office-14-years-ago-grows-600ft-monster-taken-walls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:40:30+00:00

A Gloucestershire office is home to an ivy that has grown to a 600ft monster. The plant was just a small cutting in 2009 but now spans all around the office and even has its own sponsorship deal.

## Scenic Pools goes under leaving Sydney families with holes in their backyards
 - [https://www.dailymail.co.uk/news/article-12225771/Scenic-Pools-goes-leaving-Sydney-families-holes-backyards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12225771/Scenic-Pools-goes-leaving-Sydney-families-holes-backyards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:35:31+00:00

Scenic Pools, based in Sydney, describes itself as a fibreglass pool building company that is about 'complete transparency'. The company went into receivership last week.

## Voice to Parliament: Warren Mundine rips into Yes campaign backflip after celebrities ditched
 - [https://www.dailymail.co.uk/news/exclusive/article-12255619/Voice-Parliament-Warren-Mundine-rips-Yes-campaign-backflip-celebrities-ditched.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/exclusive/article-12255619/Voice-Parliament-Warren-Mundine-rips-Yes-campaign-backflip-celebrities-ditched.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:24:40+00:00

The pivot by the Voice Yes campaign away from star endorsements and towards scripted conversations with 'ordinary voters' has been slammed as 'pathetic' by a leading No advocate.

## Providence Church Jung Myung Seok: Australian women 'brainwashed' and lured to South Korean sex cult
 - [https://www.dailymail.co.uk/news/article-12256011/Providence-Church-Jung-Myung-Seok-Australian-women-brainwashed-lured-South-Korean-sex-cult.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256011/Providence-Church-Jung-Myung-Seok-Australian-women-brainwashed-lured-South-Korean-sex-cult.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:17:58+00:00

A South Korean religious cult has been accused of recruiting vulnerable young Australian women at shopping centres to be brainwashed and then sent abroad.

## Joe Biden will finally meet King Charles on UK visit after sending his wife Jill to the Coronation
 - [https://www.dailymail.co.uk/news/article-12256257/Joe-Biden-finally-meet-King-Charles-UK-visit-sending-wife-Jill-Coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256257/Joe-Biden-finally-meet-King-Charles-UK-visit-sending-wife-Jill-Coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:14:38+00:00

The US president will arrive in Britain on July 9 before heading to the Baltic two days later for talks likely to focus on Russia and the Ukraine war.

## Woman is raped near pier in popular Devon tourist resort as police issue CCTV of suspect
 - [https://www.dailymail.co.uk/news/article-12256229/Woman-raped-near-pier-popular-Devon-tourist-resort-police-issue-CCTV-suspect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256229/Woman-raped-near-pier-popular-Devon-tourist-resort-police-issue-CCTV-suspect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T15:11:36+00:00

The rape is reported to have taken place near the Devon seaside town's Paignton Pier between 10.30pm and 11.30pm on 29 June.

## Soros Foundation cuts nearly HALF its workforce after George cedes control to his 37-year-old son
 - [https://www.dailymail.co.uk/news/article-12256167/Soros-Foundation-cuts-nearly-HALF-workforce-George-cedes-control-37-year-old-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256167/Soros-Foundation-cuts-nearly-HALF-workforce-George-cedes-control-37-year-old-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T14:41:42+00:00

Open Society Foundations announced on Friday that it is laying off at least 40 percent off its 800-person-strong workforce.

## Holiday flightmare continues for tens of thousands as 1k flights are delayed already this morning
 - [https://www.dailymail.co.uk/news/article-12256117/Holiday-flightmare-continues-tens-thousands-1k-flights-delayed-morning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256117/Holiday-flightmare-continues-tens-thousands-1k-flights-delayed-morning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T14:39:06+00:00

Travel chaos continued for tens of thousands of people over the Forth of July weekend as hundreds of flights were canceled and 1k delayed already this morning - leaving holiday plans in tatters.

## Mike Pence insists there was 'no pressure involved' in calling governors after the 2020 election
 - [https://www.dailymail.co.uk/news/article-12256213/Mike-Pence-insists-no-pressure-involved-calling-governors-2020-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256213/Mike-Pence-insists-no-pressure-involved-calling-governors-2020-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T14:38:54+00:00

Mike Pence called then-Arizona Gov. Doug Ducey after the 2020 elections to talk about legal challenges to overturn the results - but insisted there was 'no pressure involved' in the call.

## Orkney Islands consider plans to leave UK and become a territory of Norway
 - [https://www.dailymail.co.uk/news/article-12256189/Orkney-Islands-consider-plans-leave-UK-territory-Norway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256189/Orkney-Islands-consider-plans-leave-UK-territory-Norway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T14:36:02+00:00

A motion to look at 'alternative forms of governance', including becoming a Crown Dependency like Guernsey or Jersey, or a territory of Norway, is to go before Orkney council.

## RIPTwitter begins to trend after Elon Musk announced limits on users
 - [https://www.dailymail.co.uk/news/article-12256099/RIPTwitter-begins-trend-Elon-Musk-announced-unverified-users-NOT-pay-look-600-tweets-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256099/RIPTwitter-begins-trend-Elon-Musk-announced-unverified-users-NOT-pay-look-600-tweets-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T14:00:18+00:00

Billionaire Twitter boss Elon Musk has placed new 'temporary' limits on users who refuse to pay him the monthly rate to become a verified user infuriating many users.

## Pro-Trump Ohio Sen. JD Vance backs Ron DeSantis' proposal to use deadly force at the border
 - [https://www.dailymail.co.uk/news/article-12256121/Pro-Trump-Ohio-Sen-JD-Vance-backs-Ron-DeSantis-proposal-use-deadly-force-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256121/Pro-Trump-Ohio-Sen-JD-Vance-backs-Ron-DeSantis-proposal-use-deadly-force-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T13:50:33+00:00

Pro-Trump Ohio Sen. J.D. Vance said he's on board with Florida Gov. Ron DeSantis' proposal to use Military forces against cartels and drug smugglers at the border.

## Hero mother threw herself in front of a car to save her 11-month-old daughter
 - [https://www.dailymail.co.uk/news/article-12256095/Hero-mother-threw-car-save-11-month-old-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256095/Hero-mother-threw-car-save-11-month-old-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T13:26:16+00:00

Becky Sharp, 34, suffered severe head injuries in April, earlier this year, when she was struck by a Toyota SUV as she made her way to Redhill Park in Bournemouth, Dorset, with her baby in a pram.

## Hunter Biden photographed himself smoking crack while DRIVING and speeding at 172mph
 - [https://www.dailymail.co.uk/news/article-12185871/Hunter-Biden-photographed-smoking-crack-DRIVING-speeding-172mph.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12185871/Hunter-Biden-photographed-smoking-crack-DRIVING-speeding-172mph.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T13:20:11+00:00

DailyMail.com can reveal Hunter Biden's reckless driving history through photos he took himself and uploaded to his abandoned laptop.

## Tory ministers at war over child sex abuse gangs
 - [https://www.dailymail.co.uk/news/article-12250723/Tory-ministers-war-child-sex-abuse-gangs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12250723/Tory-ministers-war-child-sex-abuse-gangs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T13:14:48+00:00

The Northern Ireland Minister is understood to have withdrawn his personal support for the Home Secretary in the wake of her much-criticised remarks in April.

## MAUREEN CALLAHAN: The coward Parkland deputy and why America is now devoid of valor
 - [https://www.dailymail.co.uk/news/article-12252577/MAUREEN-CALLAHAN-coward-Parkland-deputy-America-devoid-valor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12252577/MAUREEN-CALLAHAN-coward-Parkland-deputy-America-devoid-valor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T13:08:18+00:00

CALLAHAN: The not guilty verdict in Scot Peterson's case has made one thing clear: America has fully given up on protecting our children from school shooters.

## Mornington Peninsula cop Harry Baker dies suddenly in his sleep as cause remains a mystery
 - [https://www.dailymail.co.uk/news/article-12255913/Mornington-Peninsula-cop-Harry-Baker-dies-suddenly-sleep-cause-remains-mystery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255913/Mornington-Peninsula-cop-Harry-Baker-dies-suddenly-sleep-cause-remains-mystery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T12:50:34+00:00

Harry Baker, 29, and his partner Kate Osmond, had only just purchased a home together on Victoria's Mornington Peninsula. But on Thursday, she woke up to find him unresponsive.

## I mocked my dad's claim he was abducted by aliens. Now I'm not so sure...
 - [https://www.dailymail.co.uk/news/article-12244047/patrick-mcguire-ufo-wyoming-star-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12244047/patrick-mcguire-ufo-wyoming-star-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T12:33:51+00:00

Daniel Riedel says he now regrets joining in mockery of his father Patrick McGuire after he claimed to have endured numerous painful abductions by aliens he said visited the family's Wyoming farm.

## AI chatbots are being exploited by pedophiles to generate child-sex abuse material
 - [https://www.dailymail.co.uk/news/article-12242883/AI-chatbots-exploited-pedophiles-generate-child-sex-abuse-material.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12242883/AI-chatbots-exploited-pedophiles-generate-child-sex-abuse-material.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T12:31:24+00:00

Thousands of AI-generated child abuse images now litter dark web forums as predators take advantage of new, publicly available technology.

## Euthanasia tightens its grip on the West: Shocking rise in doctor-assisted suicides
 - [https://www.dailymail.co.uk/news/article-12248669/Euthanasia-tightens-grip-West-Shocking-rise-doctor-assisted-suicides.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12248669/Euthanasia-tightens-grip-West-Shocking-rise-doctor-assisted-suicides.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T12:31:03+00:00

Quadriplegic mom-of-two, Rose Finlay has become too sick to work. She shocked Canada by revealing that the government doles out lethal injections quicker than disability benefits.

## Virginia Woolf's 1927 novel To the Lighthouse is given a trigger warning by publishers
 - [https://www.dailymail.co.uk/news/article-12255959/Virginia-Woolfs-1927-novel-Lighthouse-given-trigger-warning-publishers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255959/Virginia-Woolfs-1927-novel-Lighthouse-given-trigger-warning-publishers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T12:09:41+00:00

The British author's novel 'To the Lighthouse' will include a disclaimer for American readers warning them about the contents of the book.

## Madeline McCann prime suspect 'had lock pick kit' that could be used on security door, witness says
 - [https://www.dailymail.co.uk/news/article-12255841/Madeline-McCann-prime-suspect-lock-pick-kit-used-security-door-witness-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255841/Madeline-McCann-prime-suspect-lock-pick-kit-used-security-door-witness-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T11:59:03+00:00

Christian Brueckner bragged about the burglary toolkit which he would use to 'break into holiday resorts, hotels and holiday homes to steal from tourists', his former friend has claimed.

## Police appeal to find girl, 14, who went missing from Gloucester two days ago
 - [https://www.dailymail.co.uk/news/article-12256019/Police-appeal-girl-14-went-missing-Gloucester-two-days-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12256019/Police-appeal-girl-14-went-missing-Gloucester-two-days-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T11:53:09+00:00

A 14-year-old girl from Gloucester, called Lexi, has been missing since last Friday. It is believed she may have travelled to Devon and police are appealing for information to help find her.

## Twitter sued for allegedly failing to pay $1million Sydney office fit-out after Elon Musk took over
 - [https://www.dailymail.co.uk/news/article-12255799/Twitter-sued-allegedly-failing-pay-1million-Sydney-office-fit-Elon-Musk-took-over.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255799/Twitter-sued-allegedly-failing-pay-1million-Sydney-office-fit-Elon-Musk-took-over.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T11:36:50+00:00

Sydney-based company Facilitate Corporation filed the claim in the US District Court in California, alleging it had stopped paying invoices for services across London, Dublin, Singapore, and Sydney.

## Campaigners call for community protection notices to be scrapped
 - [https://www.dailymail.co.uk/news/article-12255985/Campaigners-call-community-protection-notices-scrapped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255985/Campaigners-call-community-protection-notices-scrapped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T10:57:48+00:00

Campaign group, Manifesto Club, released a report which showed that those who'd been slapped with an order were left feeling 'powerless' with some saying it had 'ruined their lives'.

## Celine Cremer: Police use helicopters in search for missing Belgian backpacker
 - [https://www.dailymail.co.uk/news/article-12255867/Celine-Cremer-Police-use-helicopters-search-missing-Belgian-backpacker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255867/Celine-Cremer-Police-use-helicopters-search-missing-Belgian-backpacker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T10:55:01+00:00

Belgian backpacker Celine Cremer, 31, went missing in Tasmania on June 17, with concerned family and friends raising the alarm. Police now using new tactics to try and find her.

## I was raped by TV star, but police said there was no proof...this flawed law has to change
 - [https://www.dailymail.co.uk/news/article-12255845/I-raped-TV-star-police-said-no-proof-flawed-law-change.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255845/I-raped-TV-star-police-said-no-proof-flawed-law-change.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T10:54:53+00:00

Karen Devine (pictured) said the celebrity turned up at her home uninvited and forced her to have sex, leaving her profoundly traumatised.

## Four people are attacked by dog in west London cemetery next to Queen's Club tennis lawns
 - [https://www.dailymail.co.uk/news/article-12255827/Four-people-attacked-dog-west-London-cemetery-Queens-Club-tennis-lawns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255827/Four-people-attacked-dog-west-London-cemetery-Queens-Club-tennis-lawns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T10:47:22+00:00

At around 11.15am the victims were bitten by the dog at Margravine Cemetery near the Queen's Club. One woman was taken to hospital. A 48-year-old man was arrested.

## Mystery as man and woman are found dead in room at a Premier Inn along with an 'unknown substance'
 - [https://www.dailymail.co.uk/news/article-12255949/Mystery-man-woman-dead-room-Premier-Inn-unknown-substance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255949/Mystery-man-woman-dead-room-Premier-Inn-unknown-substance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T10:36:53+00:00

A man and a woman were pronounced dead after police attended the Premier Inn hotel in Mercury Gardens, Romford at 12.43pm on Saturday afternoon.

## Bodyboarder Mauricio Abrunhosa drowns at Curl Curl competition as haunting final post revealed
 - [https://www.dailymail.co.uk/news/article-12255805/Bodyboarder-Mauricio-Abrunhosa-drowns-Curl-Curl-competition-haunting-final-post-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255805/Bodyboarder-Mauricio-Abrunhosa-drowns-Curl-Curl-competition-haunting-final-post-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T10:30:31+00:00

Mauricio Abrunhosa, 48, was pulled unconscious from the water at Curl Curl about 11am on Sunday morning and despite desperate efforts to revive him, he could not be saved.

## Brisbane Fortitude Valley stabbings: Man rushed to hospital with knife still inside abdomen
 - [https://www.dailymail.co.uk/news/article-12255685/Brisbane-Fortitude-Valley-stabbings-Man-rushed-hospital-knife-inside-abdomen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255685/Brisbane-Fortitude-Valley-stabbings-Man-rushed-hospital-knife-inside-abdomen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T10:24:40+00:00

Police rushed to the corner of Ann and Constance street, in Brisbane's Fortitude Valley, about 3:30am on Sunday where they found the 21-year-old with the handle of the blade next to him.

## Wimbledon fans bask in sunshine as hundreds join line more than 24 hours before club opens its doors
 - [https://www.dailymail.co.uk/news/article-12255911/Wimbledon-fans-bask-sunshine-hundreds-join-line-24-hours-club-opens-doors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255911/Wimbledon-fans-bask-sunshine-hundreds-join-line-24-hours-club-opens-doors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T10:20:12+00:00

The All England Lawn Tennis Club (AELTC) posted to their social media earlier in the week that they will start accepting arrivals from 2pm today.

## Child dies and three more people are injured after fire at home in Swansea
 - [https://www.dailymail.co.uk/news/article-12255861/Child-dies-three-people-injured-fire-home-Swansea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255861/Child-dies-three-people-injured-fire-home-Swansea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T09:38:41+00:00

The fire broke out in West Cross around 1.20pm yesterday. A child has died and a man was taken to hospital in 'serious condition'. A woman and another child suffered smoke inhalation.

## Dangerous driver rams police car and leads cops on high-speed chase through York villages
 - [https://www.dailymail.co.uk/news/article-12255825/Dangerous-driver-rams-police-car-leads-cops-high-speed-chase-York-villages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255825/Dangerous-driver-rams-police-car-leads-cops-high-speed-chase-York-villages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T09:33:47+00:00

Mikey Lee Neasham, 27, of Wenham Road, York, was sentenced to 17 months imprisonment for dangerous driving. He tore through villages at over 100mph before crashing into a field.

## Moment university academic tears down anti-LTN petition poster from shop near her south London home
 - [https://www.dailymail.co.uk/news/article-12255731/Moment-university-academic-tears-anti-LTN-petition-poster-shop-near-south-London-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255731/Moment-university-academic-tears-anti-LTN-petition-poster-shop-near-south-London-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T09:21:46+00:00

Dr Anna Goodman was seen in a West Dulwich shop apparently sneakily looking around to check it is safe before peeling the anti-LTN poster off the door and making a getaway.

## Football clubs blasted by the head of the NHS over shirt sponsorship deals for betting firms
 - [https://www.dailymail.co.uk/news/article-12255857/Football-clubs-blasted-head-NHS-shirt-sponsorship-deals-betting-firms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255857/Football-clubs-blasted-head-NHS-shirt-sponsorship-deals-betting-firms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T09:19:04+00:00

She told the BBC that clubs should 'think seriously' about their responsibilities to fans with a blast at three firms who did deals last week.

## Mark Bouris forecasts RBA rate hike
 - [https://www.dailymail.co.uk/news/article-12255687/Mark-Bouris-forecasts-RBA-rate-hike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255687/Mark-Bouris-forecasts-RBA-rate-hike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T08:43:49+00:00

Financial expert Mark Bouris has made a grim prediction ahead of the Reserve Bank's decision on whether to raise the cash rate.

## BREAKING NEWS: Mass shooting in Baltimore leaves dozens wounded and multiple dead
 - [https://www.dailymail.co.uk/news/article-12255785/Mass-shooting-Baltimore-leaves-dozens-wounded-multiple-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255785/Mass-shooting-Baltimore-leaves-dozens-wounded-multiple-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T08:35:23+00:00

A shooting occurred in Baltimore, Maryland, early Sunday morning, leaving dozens of people wounded and multiple fatalities.

## Ripped apart by lions and falling foul to a CANNIBAL: The adventure trips that ended in death
 - [https://www.dailymail.co.uk/news/article-12243693/Ripped-apart-lions-falling-foul-CANNIBAL-adventure-trips-ended-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12243693/Ripped-apart-lions-falling-foul-CANNIBAL-adventure-trips-ended-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T08:28:40+00:00

From an adventurer eaten by the bears he loved to an intrepid kayaker killed by a remote tribe, here MailOnline looks at tragic deaths of adventurers over the years.

## Rishi Sunak faces more by-election misery with new vote in 'groping' row MP's seat
 - [https://www.dailymail.co.uk/news/article-12255759/Rishi-Sunak-faces-election-misery-new-vote-groping-row-MPs-seat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255759/Rishi-Sunak-faces-election-misery-new-vote-groping-row-MPs-seat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T08:21:07+00:00

A report into the behaviour of former Tory whip Chris Pincher is expected to recommend he be banned from the Commons for more than 10 days over claims he drunkenly groped a young man.

## Piccadilly Theatre launches £200,000 legal war against builders after ceiling collapsed
 - [https://www.dailymail.co.uk/news/article-12250541/Piccadilly-Theatre-launches-200-000-legal-war-against-builders-ceiling-collapsed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12250541/Piccadilly-Theatre-launches-200-000-legal-war-against-builders-ceiling-collapsed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T08:07:09+00:00

The case revolves around the Piccadilly Theatre in London's West End, where several audience members were injured when the ceiling partially collapsed during building works.

## Commuters face week of travel chaos due to train drivers' overtime ban
 - [https://www.dailymail.co.uk/news/article-12255727/Commuters-face-week-travel-chaos-train-drivers-overtime-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255727/Commuters-face-week-travel-chaos-train-drivers-overtime-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T07:50:28+00:00

Throughout England 16 train companies will refuse to work overtime from 3-8 July due to an ongoing national dispute over pay. Passengers are being urged to check timetables before they travel.

## Regulators set to introduce Pumpwatch site to prevent drivers being ripped off
 - [https://www.dailymail.co.uk/news/article-12255693/Regulators-set-introduce-Pumpwatch-site-prevent-drivers-ripped-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255693/Regulators-set-introduce-Pumpwatch-site-prevent-drivers-ripped-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T07:20:00+00:00

New rules could be announced as soon as tomorrow as the Government begins to clampdown on businesses unfairly hammering consumers by not passing on wholesale savings.

## Woman killed by SUV on Kwinana Freeway after running out of fuel was Ebony Storm-Somerville
 - [https://www.dailymail.co.uk/news/article-12255557/Woman-killed-SUV-Kwinana-Freeway-running-fuel-Ebony-Storm-Somerville.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255557/Woman-killed-SUV-Kwinana-Freeway-running-fuel-Ebony-Storm-Somerville.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:55:53+00:00

Heart-breaking tributes to Ebony Storm-Somerville, the young woman fatally struck on a WA freeway last week have flooded social media as her family battles to try and pay for her funeral and wake.

## Plan to build world's tallest flagpole with massive American flag divides tiny Maine town
 - [https://www.dailymail.co.uk/news/article-12255509/Plan-build-worlds-tallest-flagpole-massive-American-flag-divides-tiny-Maine-town.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255509/Plan-build-worlds-tallest-flagpole-massive-American-flag-divides-tiny-Maine-town.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:49:32+00:00

A Maine businessman has sparked controversy with his plan to build the world's tallest flagpole in a remote corner of his home state, as part of a $1 billion project he says aims to increase patriotism.

## Texas dad shares stark warning about the dangers of fireworks after son suffered horrific injuries
 - [https://www.dailymail.co.uk/news/article-12255449/Texas-dad-shares-stark-warning-dangers-fireworks-son-suffered-horrific-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255449/Texas-dad-shares-stark-warning-dangers-fireworks-son-suffered-horrific-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:33:17+00:00

A Texas family is trying to warn people about the dangers of fireworks ahead of the Fourth of July holiday after their teenage son received permanent damage just two years ago.

## Rightful winner of $3 million Mega Millions lottery ticket collects his prize after it was STOLEN
 - [https://www.dailymail.co.uk/news/article-12255083/Rightful-winner-3-million-Mega-Millions-lottery-ticket-collects-prize-STOLEN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255083/Rightful-winner-3-million-Mega-Millions-lottery-ticket-collects-prize-STOLEN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:30:51+00:00

A Massachusetts man was able to claim his $3million lottery ticket prize Friday after two convenience store workers stole it from him and tried to claim it months earlier.

## Voice to Parliament: Labor senator compares losing referendum to human rights abuses in China
 - [https://www.dailymail.co.uk/news/article-12255465/Voice-Parliament-Labor-senator-compares-losing-referendum-human-rights-abuses-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255465/Voice-Parliament-Labor-senator-compares-losing-referendum-human-rights-abuses-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:25:02+00:00

Aboriginal leader Patrick Dodson believes Australia would be in no place to criticise China over its human rights abuses if the Voice to Parliament referendum fails.

## Gunman accused of slaying five neighbors - including a nine-year-old boy - could face DEATH PENALTY
 - [https://www.dailymail.co.uk/news/article-12255555/Gunman-accused-slaying-five-neighbors-including-nine-year-old-boy-face-DEATH-PENALTY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255555/Gunman-accused-slaying-five-neighbors-including-nine-year-old-boy-face-DEATH-PENALTY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:10:25+00:00

The Texas gunman accused of killing five neighbors, including a nine-year-old boy, in San Jacinto County could face the death penalty after a grand jury indicted him for capital murder Friday.

## United Airlines offers passengers hit by cancelation chaos 30,000 free airmiles
 - [https://www.dailymail.co.uk/news/article-12255635/United-Airlines-offers-passengers-hit-cancelation-chaos-30-000-free-airmiles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255635/United-Airlines-offers-passengers-hit-cancelation-chaos-30-000-free-airmiles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:05:04+00:00

United has offered passengers air miles in a bid to try and keep them loyal after a chaotic week of cancelations. CEO Scott Kirby also said on Saturday the schedule was being revised.

## Allegedly stolen car smashes into eight parked vehicles in Melbourne's East as cops arrest one man
 - [https://www.dailymail.co.uk/news/article-12255571/Allegedly-stolen-car-smashes-eight-parked-vehicles-Melbournes-East-cops-arrest-one-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255571/Allegedly-stolen-car-smashes-eight-parked-vehicles-Melbournes-East-cops-arrest-one-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:03:22+00:00

A housewarming party turned sour after an allegedly stolen vehicle smashed into eight parked cars belonging to guests, causing 'absolute carnage'.

## Revealed: ITV bosses WERE warned of 'serious concerns' about ex-This Morning star Schofield's young lover
 - [https://www.dailymail.co.uk/tvshowbiz/article-12254791/ITV-bosses-warned-concerns-ex-Morning-star-Schofields-young-lover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12254791/ITV-bosses-warned-concerns-ex-Morning-star-Schofields-young-lover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:03:13+00:00

It is believed bosses, including managing director for entertainment Kevin Lygo, knew of an email that outlined worries about the wellbeing of the production assistant

## Units to buy Australia: Where you can buy an apartment near the beach for $90,000
 - [https://www.dailymail.co.uk/news/article-12249601/Units-buy-Australia-buy-apartment-near-beach-90-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12249601/Units-buy-Australia-buy-apartment-near-beach-90-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T06:01:53+00:00

Young people locked out of the housing market, who can work from home and don't want a big mortgage have options in Cairns in tropical far north Queensland where units are available for $90,000.

## Bizarre moment father SOBS as black man who brandished knife at his family is arrested
 - [https://www.dailymail.co.uk/news/article-12255395/Bizarre-moment-father-SOBS-black-man-brandished-knife-family-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255395/Bizarre-moment-father-SOBS-black-man-brandished-knife-family-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T05:56:52+00:00

Police had been called to Flowers Park in Doraville, Georgia, in May 2022 where a man was said to be brandishing a knife and threatening a man and his family.

## Man dies after he is pulled from the water at Curl Curl Beach on Sydney's northern beaches
 - [https://www.dailymail.co.uk/news/article-12255599/Man-dies-pulled-water-Curl-Curl-Beach-Sydneys-northern-beaches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255599/Man-dies-pulled-water-Curl-Curl-Beach-Sydneys-northern-beaches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T05:56:33+00:00

The man, aged in his 40s, had been swimming at Curl Curl Beach, on Sydney's northern beaches, on Sunday morning.

## Boston University law school students offered THERAPY in wake Supreme Court rulings
 - [https://www.dailymail.co.uk/news/article-12255533/Boston-University-law-school-students-offered-THERAPY-wake-Supreme-Court-rulings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255533/Boston-University-law-school-students-offered-THERAPY-wake-Supreme-Court-rulings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T05:55:11+00:00

The BU Law Student Government Association's statement was sent to law students on Friday denouncing three major Supreme Court decisions from this week and offering support to students.

## First black woman socialist elected to Boston City Council 'crashed car with her 7-year-old inside'
 - [https://www.dailymail.co.uk/news/article-12255153/First-black-woman-socialist-elected-Boston-City-Council-crashed-car-7-year-old-inside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255153/First-black-woman-socialist-elected-Boston-City-Council-crashed-car-7-year-old-inside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T05:07:21+00:00

Kendra Lara, 33, crashed her car on Friday afternoon while driving with a revoked license. Her seven-year-old son was injured. The car was unlicensed, and uninsured. She has been charged.

## 'Yes' Voice to Parliament campaigners rally around Australia as they show support
 - [https://www.dailymail.co.uk/news/article-12255401/Yes-Voice-Parliament-campaigners-rally-Australia-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255401/Yes-Voice-Parliament-campaigners-rally-Australia-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T05:07:10+00:00

Voice to parliament: Yes23 holds rally blitz to bolster support for referendum

## The mum of Caleb Pace, 20, who collapsed during Oztag game and later died, had heart problems
 - [https://www.dailymail.co.uk/news/article-12255263/The-mum-Caleb-Pace-20-collapsed-Oztag-game-later-died-heart-problems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255263/The-mum-Caleb-Pace-20-collapsed-Oztag-game-later-died-heart-problems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T04:54:55+00:00

Gold Coast apprentice electrician Caleb Pace, 20, who died on June 23 after he collapsed playing Oztag, may have had a hereditary heart condition.

## Shock breast cancer diagnoses for Brisbane's Emma Perkins while she was pregnant
 - [https://www.dailymail.co.uk/news/article-12255377/Shock-breast-cancer-diagnoses-Brisbanes-Emma-Perkins-pregnant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255377/Shock-breast-cancer-diagnoses-Brisbanes-Emma-Perkins-pregnant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T04:37:49+00:00

A Queensland mother wants to give back to the hospital for the medical miracle that saw both her and her unborn son survive a shock cancer diagnosis when she was 12 weeks pregnant.

## Mile wide tornado devastates rural Canadian town on Canada Day canceling celebration events
 - [https://www.dailymail.co.uk/news/article-12255029/Mile-wide-tornado-devastates-rural-Canadian-town-Canada-Day-canceling-celebration-events.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255029/Mile-wide-tornado-devastates-rural-Canadian-town-Canada-Day-canceling-celebration-events.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T04:13:16+00:00

Environment and Climate Change Canada issued alerts for the storm that they said was producing a tornado, damaging winds, large hail and intense rainfall. They said it could be life-threatening.

## Queensland youth crime crisis: Hawthorne family whose car was stolen are targeted by thieves again
 - [https://www.dailymail.co.uk/news/article-12254981/Queensland-youth-crime-crisis-Hawthorne-family-car-stolen-targeted-thieves-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12254981/Queensland-youth-crime-crisis-Hawthorne-family-car-stolen-targeted-thieves-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T03:59:44+00:00

A family who had their car stolen in broad daylight following a break-in have been targeted by thieves just three days later - as a youth crime crisis grips the state.

## Fyre restaurant vegan ban feud boils over as John Mountain takes swipe at Tash Peterson
 - [https://www.dailymail.co.uk/news/article-12255183/Fyre-restaurant-vegan-ban-feud-boils-John-Mountain-takes-swipe-Tash-Peterson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255183/Fyre-restaurant-vegan-ban-feud-boils-John-Mountain-takes-swipe-Tash-Peterson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T03:59:24+00:00

The Perth chef who banned vegans from his restaurant is not backing down after heated clashes with activists on Friday and has a provocative change to his Instagram profile picture.

## Atlanta mother, 34, shot and wounded her 17-year-old son in an argument about a video game console
 - [https://www.dailymail.co.uk/news/article-12255313/Atlanta-mother-34-shot-wounded-17-year-old-son-argument-video-game-console.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255313/Atlanta-mother-34-shot-wounded-17-year-old-son-argument-video-game-console.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T03:56:36+00:00

Jaquana Butler, 34, was arrested and charged with assault and cruelty to a child. She is well known to police, with arrests dating back to 2010 on charges including child abuse, forgery and armed robbery

## Dingo mauls young boy in his father's arms in Happy Valley, K'gari
 - [https://www.dailymail.co.uk/news/article-12255457/Dingo-bites-young-boy-fathers-arms-Happy-Valley-Kgari.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255457/Dingo-bites-young-boy-fathers-arms-Happy-Valley-Kgari.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T03:48:47+00:00

A young boy was savaged by a dingo while in his father's arms at a K'gari beach in the latest attack on the popular holiday island.

## Woolworths supply shortage after Minchinbury distribution centre worker dies
 - [https://www.dailymail.co.uk/news/article-12255291/Woolworths-supply-shortage-Minchinbury-distribution-centre-worker-dies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255291/Woolworths-supply-shortage-Minchinbury-distribution-centre-worker-dies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T03:27:30+00:00

The tragic death of a Woolworth's factory worker has triggered supply shortages at some of Sydney's busiest stores.

## Democrat slammed after complaining about her student debt - despite owning $1.14 million home
 - [https://www.dailymail.co.uk/news/article-12253451/Democrat-slammed-complaining-student-debt-despite-owning-1-14-million-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12253451/Democrat-slammed-complaining-student-debt-despite-owning-1-14-million-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T02:08:06+00:00

Biaggi had taken to social media on Friday to discuss the student loans she had amassed during law school - almost exactly a year since it was reported she had purchased a home worth $1.14 million.

## Airport chaos for travellers along Australia's east coast with flight delays and cancellations
 - [https://www.dailymail.co.uk/news/article-12255117/Airport-chaos-travellers-Australias-east-coast-flight-delays-cancellations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255117/Airport-chaos-travellers-Australias-east-coast-flight-delays-cancellations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T01:36:49+00:00

Mass cancellations and delays are expected for airports along Australia's east coast for a third day in a row - sparking another day of chaos for travellers.

## New Zealand mother whose son died when Honda Accord he drove crashed in Scarborough flies to Perth
 - [https://www.dailymail.co.uk/news/article-12254967/New-Zealand-mother-son-died-Honda-Accord-drove-crashed-Scarborough-flies-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12254967/New-Zealand-mother-son-died-Honda-Accord-drove-crashed-Scarborough-flies-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T01:35:41+00:00

WA police said the force of a tragic car accident in Perth was so extreme the engine block was forced into the passenger compartment. The driver, 19, died after being rushed to hospital critically injured.

## Shocking video shows GIGANTIC line of traffic waiting to enter Yosemite as tourists compare it to LA
 - [https://www.dailymail.co.uk/news/article-12254893/Shocking-video-shows-GIGANTIC-line-traffic-waiting-enter-Yosemite-tourists-compare-LA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12254893/Shocking-video-shows-GIGANTIC-line-traffic-waiting-enter-Yosemite-tourists-compare-LA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T01:12:32+00:00

Queues to enter the park are said to take multiple hours to navigate through and visitors who arrive later than 8am are being told there won't be space for them to park even when they do get inside.

## Gladys Berejiklian's ICAC corruption probe slammed by ex NSW treasurer Matt Kean
 - [https://www.dailymail.co.uk/news/article-12255261/Gladys-Berejiklians-ICAC-corruption-probe-slammed-ex-NSW-treasurer-Matt-Kean.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255261/Gladys-Berejiklians-ICAC-corruption-probe-slammed-ex-NSW-treasurer-Matt-Kean.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T01:12:10+00:00

Gladys Berejiklian was found to have engaged in serious corrupt conduct and to have breached the public's trust through her secret relationship with ex-MP Daryl Maguire.

## Hundreds of miles of overhead cables and pylons could be forced onto the British public
 - [https://www.dailymail.co.uk/news/article-12255181/Hundreds-miles-overhead-cables-pylons-forced-British-public.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255181/Hundreds-miles-overhead-cables-pylons-forced-British-public.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T01:01:33+00:00

As the demand for energy grows, minister are increasingly concerned it could outpace the capacity of the national grid in light of households switching to electric cars and heat pumps.

## Convicted rapist Jarryd Hayne at the centre of life-threatening prison emergency
 - [https://www.dailymail.co.uk/news/breaking_news/article-12255111/Convicted-rapist-Jarryd-Hayne-centre-life-threatening-prison-emergency.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/breaking_news/article-12255111/Convicted-rapist-Jarryd-Hayne-centre-life-threatening-prison-emergency.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:56:46+00:00

A jail footy match involving convicted rapist and former NRL star Jarryd Hayne ended in horror when a player collapsed and stopped breathing on the pitch.

## Stanley Tucci had fears over the 21-year age gap with future wife Felicity
 - [https://www.dailymail.co.uk/usshowbiz/article-12254685/Stanley-Tucci-fears-21-year-age-gap-future-wife-Felicity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/usshowbiz/article-12254685/Stanley-Tucci-fears-21-year-age-gap-future-wife-Felicity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:47:39+00:00

Stanley Tucci has revealed doubts over dating a much younger woman nearly wrecked his chance of happiness with future wife Felicity.

## Love Island's Kodie Murphy branded 'liar' by girlfriend after he claimed to be 'going on work trip'
 - [https://www.dailymail.co.uk/tvshowbiz/article-12254801/Love-Islands-Kodie-Murphy-branded-liar-girlfriend-claimed-going-work-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12254801/Love-Islands-Kodie-Murphy-branded-liar-girlfriend-claimed-going-work-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:42:18+00:00

Love Island's latest bombshell Kodie Murphy has been branded a liar by a girlfriend ahead of his appearance on the ITV2 show.

## Never mind the posh frocks... Now it's Phoebe Waller-Rotten!
 - [https://www.dailymail.co.uk/tvshowbiz/article-12254813/Never-mind-posh-frocks-Phoebe-Waller-Rotten.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12254813/Never-mind-posh-frocks-Phoebe-Waller-Rotten.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:38:03+00:00

The Fleabag creator was spotted in London last week in a black outfit with plenty of zips, similar to the sort that the Sex Pistols frontman wore in his wild 1970s heyday.

## Now health watchdog probes private gender clinic set up by staff from scandal-hit Tavistock unit
 - [https://www.dailymail.co.uk/news/article-12254933/Now-health-watchdog-probes-private-gender-clinic-set-staff-scandal-hit-Tavistock-unit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12254933/Now-health-watchdog-probes-private-gender-clinic-set-staff-scandal-hit-Tavistock-unit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:32:32+00:00

The new Gender Plus Clinic, set up by staff from the scandal-hit Tavistock unit, is being probed for failing to register with the Care Quality Commission, just one month after it opened its doors

## Police accused of sabotage after allowing sixth man in killing of Stephen Lawrence to evade justice
 - [https://www.dailymail.co.uk/news/article-12255021/Police-accused-sabotage-allowing-sixth-man-killing-Stephen-Lawrence-evade-justice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255021/Police-accused-sabotage-allowing-sixth-man-killing-Stephen-Lawrence-evade-justice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:31:14+00:00

Duwayne Brooks, Stephen's friend who survived the attack, said he could have identified Matthew White (pictured) - who was named as a suspect last week - had police put him in a line-up.

## Real estate agents offer tips on how to secure house during rental crisis in Australia
 - [https://www.dailymail.co.uk/news/article-12254965/Real-estate-agents-offer-tips-secure-house-rental-crisis-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12254965/Real-estate-agents-offer-tips-secure-house-rental-crisis-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:29:43+00:00

From writing a love letter to the property to penning a resume for your family pet, real estate agents have revealed their top tips for securing the rental home of your dreams.

## Rollercoaster at North Carolina theme park is closed after huge CRACK is spotted in support pillar
 - [https://www.dailymail.co.uk/news/article-12254903/Rollercoaster-North-Carolina-theme-park-closed-huge-CRACK-spotted-support-pillar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12254903/Rollercoaster-North-Carolina-theme-park-closed-huge-CRACK-spotted-support-pillar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:28:08+00:00

According to news reports, Carowinds shut down Fury 325 Friday evening after riders had been enjoying it on scheduled throughout the day.

## Church of England bishops blame Ministers rather than traffickers for fuelling small boats crisis
 - [https://www.dailymail.co.uk/news/article-12255237/Church-England-bishops-blame-Ministers-traffickers-fuelling-small-boats-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255237/Church-England-bishops-blame-Ministers-traffickers-fuelling-small-boats-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:26:55+00:00

In an astonishing criticism of efforts to cut illegal immigration, the bishops claim 'the increasing securitisation makes the routes by sea riskier, and the profits for traffickers correspondingly higher'.

## Half of the six billion takeaways ordered each year in Britain are delivered to your door cold
 - [https://www.dailymail.co.uk/news/article-12255221/Half-six-billion-takeaways-ordered-year-Britain-delivered-door-cold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255221/Half-six-billion-takeaways-ordered-year-Britain-delivered-door-cold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:22:47+00:00

Brits spend a massive £21 billion on takeaways each year, but a nationwide study has found nearly half arrive at their door cold or lukewarm, equating to a whopping 2.9 billion takeaways a year

## Britain's top military officer faces a grilling by MPs
 - [https://www.dailymail.co.uk/news/article-12255205/Britains-military-officer-faces-grilling-MPs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255205/Britains-military-officer-faces-grilling-MPs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:21:27+00:00

Admiral Sir Tony Radakin, will be questioned by the defence select committees on Tuesday about his working relationship with General Sir Patrick Sanders.

## DAN HODGES: Closer Starmer gets to No 10, more desperate he is to conceal what he'll do if elected
 - [https://www.dailymail.co.uk/debate/article-12255187/DAN-HODGES-Closer-Starmer-gets-No-10-desperate-conceal-hell-elected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-12255187/DAN-HODGES-Closer-Starmer-gets-No-10-desperate-conceal-hell-elected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:20:54+00:00

DAN HODGES: Starmer has decided his route to securing power lies in pulling the wool over the eyes of the electorate. The only question is which section of the electorate it is he's trying to dupe

## Boost for Conservative Mayor of London hopeful Moz as half of the capital voters turn fire on Sadiq
 - [https://www.dailymail.co.uk/news/article-12255109/Boost-Conservative-Mayor-London-hopeful-Moz-half-capital-voters-turn-fire-Sadiq.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255109/Boost-Conservative-Mayor-London-hopeful-Moz-half-capital-voters-turn-fire-Sadiq.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:20:05+00:00

Mozammel 'Moz' Hossain had a boost to his campaign to become London Mayor in the next election after a poll backed a lawyer like him as best placed to fight crime in the capital

## Classroom asbestos kills 10,000 pupils and teachers in four decades
 - [https://www.dailymail.co.uk/news/article-12255119/Classroom-asbestos-kills-10-000-pupils-teachers-four-decades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255119/Classroom-asbestos-kills-10-000-pupils-teachers-four-decades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:20:00+00:00

Figures produced by the Joint Union Asbestos Committee estimate a staggering number of deaths have been caused by the toxic material between 1980 and 2017.

## We'll use AI to thwart benefits fraud gangs who cost UK billions, says Mel Stride
 - [https://www.dailymail.co.uk/news/article-12255167/Well-use-AI-thwart-benefits-fraud-gangs-cost-UK-billions-says-Mel-Stride.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255167/Well-use-AI-thwart-benefits-fraud-gangs-cost-UK-billions-says-Mel-Stride.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:18:29+00:00

In an exclusive interview with The Mail on Sunday, the Cabinet Minister warned that authorities will 'catch up' with those who cheat the public purse.

## DeSantis accused of sharing 'homophobic' ad attacking Trump for promising to protect LGBTQ people
 - [https://www.dailymail.co.uk/news/article-12254865/DeSantis-accused-sharing-homophobic-ad-attacking-Trump-promising-protect-LGBTQ-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12254865/DeSantis-accused-sharing-homophobic-ad-attacking-Trump-promising-protect-LGBTQ-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:17:50+00:00

Ron DeSantis's campaign has been accused of homophobia for tweeting a video celebrating the end of Pride month and mocking Donald Trump for his support for the LGBTQ community.

## EMILY PRESCOTT: George Osborne and Thea Rogers to tie the knot in the 'Notting Hill of the West'
 - [https://www.dailymail.co.uk/tvshowbiz/article-12254985/EMILY-PRESCOTT-George-Osborne-Thea-Rogers-tie-knot-Notting-Hill-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12254985/EMILY-PRESCOTT-George-Osborne-Thea-Rogers-tie-knot-Notting-Hill-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:17:27+00:00

EMILY PRESCOTT: Ex-Chancellor George Osborne is to marry his former adviser Thea Rogers next Saturday, I can reveal.

## Soldier who saved lives in Afghanistan forced to quit the Army for agreeing that men can't be women
 - [https://www.dailymail.co.uk/news/article-12255015/Soldier-saved-lives-Afghanistan-forced-quit-Army-agreeing-men-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255015/Soldier-saved-lives-Afghanistan-forced-quit-Army-agreeing-men-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:16:18+00:00

EXCLUSIVE INTERVIEW:  The horrors of the battlefield are as fresh for Colonel Dr Kelvin Wright today as they were at the height of the Afghan conflict.

## Pony who took a bite out of the late Queen's sweet pea posy is handed key Charles escort role
 - [https://www.dailymail.co.uk/news/article-12255171/Pony-took-bite-late-Queens-sweet-pea-posy-handed-key-Charles-escort-role.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255171/Pony-took-bite-late-Queens-sweet-pea-posy-handed-key-Charles-escort-role.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:15:51+00:00

Corporal Cruachan IV, the mascot of the Royal Regiment of Scotland, will escort the People's Procession from Edinburgh Castle to St Giles Cathedral.

## Police are considering criminal charges over The Prince's Foundation 'cash-for-honours' scandal
 - [https://www.dailymail.co.uk/news/article-12255195/Police-considering-criminal-charges-Princes-Foundation-cash-honours-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255195/Police-considering-criminal-charges-Princes-Foundation-cash-honours-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:09:33+00:00

CPS has  analysed evidence into claims that foreign tycoons were being offered help to obtain honours in exchange for donations to King Charles's charity.

## NHS is rapidly expanding the opening of gambling addiction centres across the country this summer
 - [https://www.dailymail.co.uk/news/article-12255151/NHS-rapidly-expanding-opening-gambling-addiction-centres-country-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255151/NHS-rapidly-expanding-opening-gambling-addiction-centres-country-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:08:48+00:00

The seven new gambling addiction centres will be in Milton Keynes, Thurrock in Essex, Bristol, Derby, Liverpool, Blackpool and Sheffield.

## Madonna will scale back her seven-month-long world tour across 45 cities after her health scare
 - [https://www.dailymail.co.uk/news/article-12255143/Madonna-scale-seven-month-long-world-tour-45-cities-health-scare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255143/Madonna-scale-seven-month-long-world-tour-45-cities-health-scare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:08:27+00:00

The 64-year-old was due to play in 45 cities around the world but the plans are being changed after she was rushed into intensive care when she was found unresponsive in her New York apartment last week

## Starmer is mocked for a pathetic attempt to 'show solidarity' with mortgage holders
 - [https://www.dailymail.co.uk/news/article-12255141/Starmer-mocked-pathetic-attempt-solidarity-mortgage-holders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255141/Starmer-mocked-pathetic-attempt-solidarity-mortgage-holders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:07:54+00:00

The Labour leader is facing claims of trying to fool the public after saying that his own mortgage was becoming more expensive.

## Labour council 'considers spending taxpayer cash on 90 zero-emissions buses from China'
 - [https://www.dailymail.co.uk/news/article-12255135/Labour-council-considers-spending-taxpayer-cash-90-zero-emissions-buses-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12255135/Labour-council-considers-spending-taxpayer-cash-90-zero-emissions-buses-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-07-02T00:03:59+00:00

The move by Blackpool Transport Services - owned by Blackpool council - comes two years after Johnson pledged £3billion to buy British-built vehicles.

