# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Zamieszki we Francji. Kanclerz Scholz nie spodziewa się podobnej sytuacji w Niemczech
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8745230,zamieszki-we-francji-kanclerz-scholz-nie-spodziewa-sie-podobnej-sytua.html](https://forsal.pl/swiat/unia-europejska/artykuly/8745230,zamieszki-we-francji-kanclerz-scholz-nie-spodziewa-sie-podobnej-sytua.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T20:18:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RZJktkuTURBXy85Mzk2YWU1OS01ZWNlLTRkYjAtOWJlOC0wNWQ3YmNlMTkzNDkuanBlZ5GTBc0BHcyg" />Niemcom nie zagrażają takie zamieszki, jakie mają miejsce w ostatnich dniach we Francji – stwierdził w niedzielę podczas rozmowy z ARD kanclerz Olaf Scholz. Szef rządu wyraził przy tym zrozumienie dla decyzji prezydenta Emmanuel Macrona o odwołaniu wizyty państwowej w Niemczech.

## Brytyjska policja zyskała większe uprawnienia do pacyfikacji protestów aktywistów klimatycznych
 - [https://forsal.pl/swiat/brexit/artykuly/8745229,brytyjska-policja-zyskala-wieksze-uprawnienia-do-pacyfikacji-protestow.html](https://forsal.pl/swiat/brexit/artykuly/8745229,brytyjska-policja-zyskala-wieksze-uprawnienia-do-pacyfikacji-protestow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T20:09:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-d5ktkuTURBXy84ZjkyOTZhMS1iMjkyLTRhNTktYTQxZi02MWRhMzA5ZGI0YTkuanBlZ5GTBc0BHcyg" />Policja w Anglii i Walii zyskała w niedzielę nowe uprawnienia, które są wymierzone w niektóre z metod stosowanych podczas protestów, zwłaszcza przez aktywistów klimatycznych z takich grup jak Extinction Rebellion czy Just Stop Oil.

## Część pracowników Rosatomu wyjechała z miasta obok Zaporoskiej Elektrowni Atomowej
 - [https://forsal.pl/swiat/ukraina/artykuly/8745228,czesc-pracownikow-rosatomu-wyjechala-z-miasta-obok-zaporoskiej-elektro.html](https://forsal.pl/swiat/ukraina/artykuly/8745228,czesc-pracownikow-rosatomu-wyjechala-z-miasta-obok-zaporoskiej-elektro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T20:00:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mwXktkuTURBXy82ZGRjODU1YS02ZDZmLTRlZTktOTEyNS1hZTgxZTk1NjU2YjIuanBlZ5GTBc0BHcyg" />Z okupowanego miasta Enerhodar wyjechała część pracowników rosyjskiego koncernu Rosatom przywiezionych wcześniej do Zaporoskiej Elektrowni Atomowej, a także część ukraińskich pracowników, którzy kolaborowali z Rosjanami - powiadomił w niedzielę mer miasta Dmytro Orłow. Poprzedniego dnia prezydent Wołodymyr Zełenski ostrzegł, że Rosjanie mogą dokonać zdalnej detonacji w siłowni w momencie, gdy znajdzie się już ona w rękach ukraińskich.

## Zamieszki we Francji. Babcia zastrzelonego Nahela zaapelowała o zakończenie zamieszek
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8745225,zamieszki-we-francji-babcia-zastrzelonego-nahela-zaapelowala-o-zakonc.html](https://forsal.pl/swiat/unia-europejska/artykuly/8745225,zamieszki-we-francji-babcia-zastrzelonego-nahela-zaapelowala-o-zakonc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T19:51:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IqEktkuTURBXy81MTE3ZjZkYS1kMTFkLTRkOTQtODE0NS0wMTE4YjIxNzVjOTYuanBlZ5GTBc0BHcyg" />Chcę, żeby to się skończyło – mówi Nadia, babcia zastrzelonego przez policjanta we wtorek 17-latka. Kobieta wzywa wszystkich do zaprzestania zamieszek, które wstrząsają francuskimi przedmieściami od śmierci jej wnuka.

## Wielka Brytania: Mieszkańcy archipelagu Orkadów rozważają przejście pod zwierzchnictwo Norwegii
 - [https://forsal.pl/swiat/brexit/artykuly/8745223,wielka-brytania-mieszkancy-archipelagu-orkadow-rozwazaja-przejscie-po.html](https://forsal.pl/swiat/brexit/artykuly/8745223,wielka-brytania-mieszkancy-archipelagu-orkadow-rozwazaja-przejscie-po.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T19:47:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QECktkuTURBXy8zNzFhMzQxMS01NTljLTQ1YmMtYTI0Ni03M2ZkMzk2ZDY1YWYuanBlZ5GTBc0BHcyg" />Władze szkockiego archipelagu Orkadów będą we wtorek debatować nad wnioskiem o &quot;zbadanie alternatywnych form zarządzania&quot;, co może obejmować zmianę statusu w ramach Wielkiej Brytanii, a nawet przejście pod zwierzchnictwo Norwegii - podała w niedzielę stacja BBC,

## Zamieszki we Francji: Trzech funkcjonariuszy zostało zranionych. Wszczęto śledztwo ws. usiłowania zabójstwa
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8745136,zamieszki-we-francji-trzech-funkcjonariuszy-zostalo-zranionych-wszcz.html](https://forsal.pl/swiat/unia-europejska/artykuly/8745136,zamieszki-we-francji-trzech-funkcjonariuszy-zostalo-zranionych-wszcz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T18:23:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XtsktkuTURBXy8zNzYwZTUyMC0zODdkLTQxN2ItYWE2Yi1iYTI1ZTYwODI3YzEuanBlZ5GTBc0BHcyg" />Dwóch funkcjonariuszy Brygady do Zwalczania Przestępczości (BAC) zostało w Paryżu trafionych kulami ołowianymi – podała w niedzielę stacja CNews, powołując się na źródła w policji. Strzelano również do policjanta w Nimes. W niedzielę MSW ponownie zmobilizowało 45 tys. policjantów do tłumienia zamieszek.

## Zamieszki we Francji przeniosły się do Szwajcarii. Policja aresztowała siedem osób
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8745127,zamieszki-we-francji-przeniosly-sie-do-szwajcarii-policja-aresztowala.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8745127,zamieszki-we-francji-przeniosly-sie-do-szwajcarii-policja-aresztowala.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T17:48:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u59ktkuTURBXy83MjNkNDQ4Yi05MWRmLTQwM2MtYjYxMy03Mjc0ZmNmOWZlNGQuanBlZ5GTBc0BHcyg" />Sześcioro nastolatków i jedna osoba dorosła zostało aresztowanych po zniszczeniu sklepów w Lozannie inspirowanym zamieszkami we Francji. W burdach uczestniczyło około 100 osób - poinformowała w niedzielę szwajcarska policja.

## Joe Biden pojedzie na szczyt NATO do Wilna
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8745121,joe-biden-pojedzie-na-szczyt-nato-do-wilna.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8745121,joe-biden-pojedzie-na-szczyt-nato-do-wilna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T17:33:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qYBktkuTURBXy9lNmQxY2FkNS1hOWM2LTRkOGUtOWVkZi0yMDE1ZTAxMWE3NzYuanBlZ5GTBc0BHcyg" />Prezydent Joe Biden pod koniec tygodnia uda się do Europy; głównym celem jego podróży będzie szczyt NATO w Wilnie. Planowane są również wizyty prezydenta USA w Finlandii, aby upamiętnić jej wstąpienie do sojuszu, oraz w Wielkiej Brytanii - ogłosił w niedzielę Biały Dom.

## Psychodeliki na receptę. Australia jako pierwszy kraj zalegalizowała je do leczenia depresji
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8745119,psychodeliki-na-recepte-australia-jako-pierwszy-kraj-zalegalizowala-j.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8745119,psychodeliki-na-recepte-australia-jako-pierwszy-kraj-zalegalizowala-j.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T17:28:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lIVktkuTURBXy9lZWE2OGEwNC05Njg1LTQzMTQtYTQyMy02NzhkYWVlMmM3YTUuanBlZ5GTBc0BHcyg" />Australia staje się pierwszym krajem, który zalegalizował medyczne psychodeliki MDMA i psylocybinę; mogą one być teraz legalnie przepisywane w leczeniu niektórych uporczywych schorzeń psychicznych, m.in. depresji - poinformował w niedzielę Sky News.

## Reuters: Należący do Prigożyna holding medialny Patriot został zamknięty
 - [https://forsal.pl/swiat/rosja/artykuly/8745117,reuters-nalezacy-do-prigozyna-holding-medialny-patriot-zostal-zamknie.html](https://forsal.pl/swiat/rosja/artykuly/8745117,reuters-nalezacy-do-prigozyna-holding-medialny-patriot-zostal-zamknie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T17:18:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RmYktkuTURBXy8zOTQ2YWEzZC1lMDkzLTQ1NTctYTg1MS1lMTBjMTM4ZGZjMWMuanBlZ5GTBc0BHcyg" />Holding medialny Patriot należący do Jewgienija Prigożyna poinformował o swoim zamknięciu - podała w niedzielę agencja Reutera. Media tego holdingu zostały zablokowane przez władze po buncie Prigożyna i jego Grupy Wagnera przeciwko ministerstwu obrony Rosji.

## Zamieszki we Francji: Iran wzywa Francję do „zakończenia brutalnego traktowania” obywateli
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8745110,zamieszki-we-francji-iran-wzywa-francje-do-zakonczenia-brutalnego-tr.html](https://forsal.pl/swiat/unia-europejska/artykuly/8745110,zamieszki-we-francji-iran-wzywa-francje-do-zakonczenia-brutalnego-tr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T17:07:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/V2QktkuTURBXy83Nzg0NzM5My1iYmJiLTRjZDQtOWJhMy0yMTllZmQ3MTQ2ZWEuanBlZ5GTBc0BHcyg" />Władze Iranu, znane z bezwzględności w tłumieniu protestów, zaapelowały w niedzielę do francuskiego rządu o „zakończenie brutalnego traktowania” swojej ludności, „poszanowania zasad godności ludzkiej” i „okazania powściągliwości” w kryzysie wywołanym śmiercią zabitego przez policjanta młodego mężczyzny.

## Zamieszki we Francji: Ambasada RP we Francji zaleca ostrożność i unikanie miejsc protestów
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8745105,zamieszki-we-francji-ambasada-rp-we-francji-zaleca-ostroznosc-i-unika.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8745105,zamieszki-we-francji-ambasada-rp-we-francji-zaleca-ostroznosc-i-unika.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T17:00:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EVRktkuTURBXy8wMWY4YjhlMC0zZjVjLTRlMTItYjlhYy00ZTg5NzE1OTJjYzkuanBlZ5GTBc0BHcyg" />W związku z zamieszkami w aglomeracji paryskiej i większych miastach Francji ambasada RP w Paryżu zaleca zachowanie ostrożności, szczególnie wieczorem i nocą, unikanie miejsc protestów, stosowanie się do zaleceń służb i uwzględnienie możliwych przerw w działaniu komunikacji.

## "WSJ": Brazylijskie paszporty ułatwiają rosyjskim szpiegom działania na Zachodzie
 - [https://forsal.pl/swiat/rosja/artykuly/8745100,wsj-brazylijskie-paszporty-ulatwiaja-rosyjskim-szpiegom-dzialania-n.html](https://forsal.pl/swiat/rosja/artykuly/8745100,wsj-brazylijskie-paszporty-ulatwiaja-rosyjskim-szpiegom-dzialania-n.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T16:54:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/veEktkuTURBXy9lNDJkNDZlNC1iM2ViLTQ1ZDctODZhYy0xNzE1MzkxNDJkY2QuanBlZ5GTBc0BHcyg" />Rosyjscy szpiedzy działający m.in. w Stanach Zjednoczonych i Norwegii posługują się nielegalnie zdobytymi paszportami brazylijskimi. W Brazylii władze badają, czy Moskwa wykorzystuje ten kraj jako inkubator dla tajnych agentów, którzy będą infiltrować Zachód – pisze w niedzielę &quot;Wall Street Journal&quot;.

## Premier Saksonii sprzeciwił się całkowitemu zakazowi sprowadzania gazu z Rosji
 - [https://forsal.pl/biznes/energetyka/artykuly/8745008,premier-saksonii-sprzeciwil-sie-calkowitemu-zakazowi-sprowadzania-gazu.html](https://forsal.pl/biznes/energetyka/artykuly/8745008,premier-saksonii-sprzeciwil-sie-calkowitemu-zakazowi-sprowadzania-gazu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T16:36:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ypQktkuTURBXy85ZWYwN2Q0Ny1lMDhiLTQ3YTktOTBjOC1iNWUyNWMxYWI1OTguanBlZ5GTBc0BHcyg" />Premier Saksonii Michael Kretschmer (CDU) naciska na rozwiązania dyplomatyczne wobec Ukrainy, ponieważ nie chce, aby „droga do rosyjskiego gazu została zablokowana na dłuższą metę” – informuje w niedzielę portal „Tagesschau”. Jego zdaniem, reforma energetyczna w Niemczech nie powiodła się.

## Ukraińsko-litewska sztafeta niesie flagę z Bachmutu na szczyt NATO w Wilnie
 - [https://forsal.pl/swiat/ukraina/artykuly/8745004,ukrainsko-litewska-sztafeta-niesie-flage-z-bachmutu-na-szczyt-nato-w-w.html](https://forsal.pl/swiat/ukraina/artykuly/8745004,ukrainsko-litewska-sztafeta-niesie-flage-z-bachmutu-na-szczyt-nato-w-w.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T16:27:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tP3ktkuTURBXy83YzdkMmY2Zi04N2ZlLTRkMmMtYjE2Yy02MzA0YWFkMDZjYTUuanBlZ5GTBc0BHcyg" />Flaga Ukrainy, przekazana przez żołnierzy walczących z Rosjanami w Bachmucie na wschodzie kraju, niesiona przez biegaczy ukraińskich i litewskich zmierza do Wilna, gdzie 11 lipca rozpocznie się szczyt NATO.

## Izrael planuje zakup kolejnych 25 myśliwców F-35
 - [https://forsal.pl/swiat/artykuly/8744896,izrael-planuje-zakup-kolejnych-25-mysliwcow-f-35.html](https://forsal.pl/swiat/artykuly/8744896,izrael-planuje-zakup-kolejnych-25-mysliwcow-f-35.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T11:17:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vEUktkuTURBXy9hNzBjMTI4NS1lNGYyLTRkZWItYjYyNy1jOGJjMGMyMjBhZTEuanBlZ5GTBc0BHcyg" />Izrael kupi 25 amerykańskich myśliwców typu stealth F-35, zwiększając swoją flotę tych maszyn do 75 - poinformowało w niedzielę izraelski resort obrony i wojsko. Wartość transakcji szacuje się na 3 miliardy dolarów i jest ona finansowana z funduszy pomocy wojskowej USA dla Izraela.

## Wakacje to ciasny zakręt dla mężczyzn. Nie odmienią twojego życia [FELIETON]
 - [https://forsal.pl/lifestyle/psychologia/artykuly/8744347,wakacje-to-ciasny-zakret-dla-mezczyzn-nie-odmienia-twojego-zycia-fel.html](https://forsal.pl/lifestyle/psychologia/artykuly/8744347,wakacje-to-ciasny-zakret-dla-mezczyzn-nie-odmienia-twojego-zycia-fel.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T11:00:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LK4ktkuTURBXy84NmQ1YWM3MS1kOTI3LTRmMTktOGU4MC0zN2JhODVmNWQxZjYuanBlZ5GTBc0BHcyg" />Wakacje, wiadomo – ciasny zakręt dla mężczyzn. Chcecie trochę postmodernistycznej filozofii psychobehawioralnej? Proszę: nie jedź na wakacje, myśląc, że uciekniesz od minusów własnego życia. Minusy i pojadą z tobą, i wrócą – żal forsę wydawać.

## Czy polityki klimatyczne najmocniej uderzają w najsłabszych ekonomicznie?
 - [https://forsal.pl/gospodarka/artykuly/8744415,czy-polityki-klimatyczne-najmocniej-uderzaja-w-najslabszych-ekonomiczn.html](https://forsal.pl/gospodarka/artykuly/8744415,czy-polityki-klimatyczne-najmocniej-uderzaja-w-najslabszych-ekonomiczn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T11:00:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/N2BktkuTURBXy9hNTYwZmM5MS0wOGNkLTQ2OWItOTlmOC01MTdhNzdlZjg1ZmYuanBlZ5GTBc0BHcyg" />Czy twierdzenie, że polityki klimatyczne najmocniej uderzają w najsłabszych ekonomicznie, to demagogia? A może twardy fakt?

## Czy bunt Prigożina to początek zawirowań w Rosji podobnych do historii z 1917 roku?
 - [https://forsal.pl/swiat/rosja/artykuly/8744413,czy-bunt-prigozina-to-poczatek-zawirowan-w-rosji-podobnych-do-historii.html](https://forsal.pl/swiat/rosja/artykuly/8744413,czy-bunt-prigozina-to-poczatek-zawirowan-w-rosji-podobnych-do-historii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T10:59:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1xUktkuTURBXy9hN2RjMjhkYi04NTBhLTQ2NmYtOTc0NC1mYzQ5YjczZWFmNTUuanBlZ5GTBc0BHcyg" />Kiedy w Piotrogrodzie przewrót szykowali bolszewicy, rosyjscy patrioci uwierzyli, że imperium ocalić może tylko gen. Korniłow. Na próbę puczu zdobył się nie w porę i bez przygotowania

## Sałek: Kwestie Nuclear Sharing będą podnoszone na szczycie NATO w Wilnie
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8744893,salek-kwestie-nuclear-sharing-beda-podnoszone-na-szczycie-nato-w-wiln.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8744893,salek-kwestie-nuclear-sharing-beda-podnoszone-na-szczycie-nato-w-wiln.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T10:57:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sU0ktkuTURBXy8zN2NiNWM1YS0xMWU2LTRmN2YtYTJkZC02ZDFmNzJkZDk0ODguanBlZ5GTBc0BHcyg" />Kwestie udziału Polski w Nuclear Sharing będą podnoszone na szczycie NATO w Wilnie – poinformował w niedzielę doradca prezydenta Andrzeja Dudy Paweł Sałek.

## Kamiński: 500 policjantów z prewencji i kontrterroryści wesprą SG na granicy z Białorusią
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8744838,kaminski-500-policjantow-z-prewencji-i-kontrterrorysci-wespra-sg-na-g.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8744838,kaminski-500-policjantow-z-prewencji-i-kontrterrorysci-wespra-sg-na-g.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T09:18:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dU0ktktTURBXy8zMTc1N2Y1OC02NmJkLTQ0MmItYTJjNy0xOTY1MTI4NWIyMjUucG5nkZMFzQEdzKA" />W związku z napiętą sytuacją na granicy z Białorusią, podjąłem decyzję o wzmocnieniu naszych sił grupą 500 funkcjonariuszy policji z oddziałów prewencji i kontrterrorystami - poinformował w niedzielę minister spraw wewnętrznych i administracji Mariusz Kamiński.

## ISW: Rosjanie koncentrują swoje siły w okolicach Bachmutu kosztem obrony innych regionów Ukrainy
 - [https://forsal.pl/swiat/rosja/artykuly/8744836,isw-rosjanie-koncentruja-swoje-sily-w-okolicach-bachmutu-kosztem-obro.html](https://forsal.pl/swiat/rosja/artykuly/8744836,isw-rosjanie-koncentruja-swoje-sily-w-okolicach-bachmutu-kosztem-obro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T09:05:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZIlktkuTURBXy81ZDIyNGRjZS00MjFhLTRmM2YtYTAyMS0wY2JjY2M0NjNmNjkuanBlZ5GTBc0BHcyg" />Operacje ukraińskiego wojska wokół Bachmutu w obwodzie donieckim mogą być zagrożeniem dla rosyjskiego dowództwa w obwodzie chersońskim oraz ługańskim. Siły rosyjskie w odpowiedzi prawdopodobnie wycofują swoje wojska z innych regionów Ukrainy i przerzucają je na ten odcinek – czytamy w najnowszym raporcie amerykańskiego Instytutu Badań nad Wojną (ISW).

## Tusk o  Kaczyńskim: Wicepremier jednocześnie szczuje na migrantów i chce ich wpuścić setki tysięcy
 - [https://forsal.pl/praca/kariera/artykuly/8744832,tusk-o-kaczynskim-wicepremier-jednoczesnie-szczuje-na-migrantow-i-ch.html](https://forsal.pl/praca/kariera/artykuly/8744832,tusk-o-kaczynskim-wicepremier-jednoczesnie-szczuje-na-migrantow-i-ch.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T08:52:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/v3rktkuTURBXy83NWFiNjE0OS02MmE1LTQ1NjItYWVkYS1iNjM4YjIwZWJhMTYuanBlZ5GTBc0BHcyg" />Kaczyński jednocześnie szczuje na migrantów i chce ich wpuścić setki tysięcy; może potrzebny mu jest wewnętrzny konflikt i strach polskich obywateli, bo wtedy łatwiej mu rządzić i wygrać wybory; musimy uniknąć tego niebezpieczeństwa - ocenił w nagraniu zamieszczonym w internecie lider PO Donald Tusk.

## Amerykanie będą świętować Dzień Niepodległości. Rekordowa liczba ludzi ruszyła w podróż
 - [https://forsal.pl/swiat/usa/artykuly/8744826,amerykanie-beda-swietowac-dzien-niepodleglosci-rekordowa-liczba-ludzi.html](https://forsal.pl/swiat/usa/artykuly/8744826,amerykanie-beda-swietowac-dzien-niepodleglosci-rekordowa-liczba-ludzi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T08:33:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pMiktkuTURBXy9hMGU3MDg0NC1lNDY4LTQ0MDEtYmU4OS1lZDc4ZGM3OTY1ZjAuanBlZ5GTBc0BHcyg" />W długi weekend Dnia Niepodległości, który trwa od piątku 30 czerwca do wtorku 4 lipca, ponad 50 mln Amerykanów wybiera się w podróż przekraczającą 80 km. 4 lipca 1776 roku Kongres Kontynentalny uchwalił Deklarację Niepodległości USA.

## Zamieszki we Francji: W nocnych 45 policjantów zostało rannych; spalono 577 aut
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8744822,zamieszki-we-francji-w-nocnych-45-policjantow-zostalo-rannych-spalon.html](https://forsal.pl/swiat/unia-europejska/artykuly/8744822,zamieszki-we-francji-w-nocnych-45-policjantow-zostalo-rannych-spalon.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T08:19:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OQ6ktkuTURBXy9hOGZiZWUzNi0zZmRmLTRkNDUtYTU1OS01ZGIyNjgwZmJjZjIuanBlZ5GTBc0BHcyg" />Podczas piątej nocy trwających w całej Francji zamieszek i walk z policją aresztowano 719 osób, 45 policjantów i żandarmów zostało rannych, podpalono 577 pojazdów i 74 budynki - przekazało w niedzielę rano ministerstwo spraw wewnętrznych.

## Zamieszki we Francji: W nocy 45 policjantów zostało rannych; spalono 577 aut
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8744822,zamieszki-we-francji-w-nocy-45-policjantow-zostalo-rannych-spalono-5.html](https://forsal.pl/swiat/unia-europejska/artykuly/8744822,zamieszki-we-francji-w-nocy-45-policjantow-zostalo-rannych-spalono-5.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T08:19:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OQ6ktkuTURBXy9hOGZiZWUzNi0zZmRmLTRkNDUtYTU1OS01ZGIyNjgwZmJjZjIuanBlZ5GTBc0BHcyg" />Podczas piątej nocy trwających w całej Francji zamieszek i walk z policją aresztowano 719 osób, 45 policjantów i żandarmów zostało rannych, podpalono 577 pojazdów i 74 budynki - przekazało w niedzielę rano ministerstwo spraw wewnętrznych.

## Rosja odwołała najważniejszej targi lotniczo-kosmiczne
 - [https://forsal.pl/swiat/rosja/artykuly/8744817,rosja-odwolala-najwazniejszej-targi-lotniczo-kosmiczne.html](https://forsal.pl/swiat/rosja/artykuly/8744817,rosja-odwolala-najwazniejszej-targi-lotniczo-kosmiczne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T08:07:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zBQktkuTURBXy9lNjU2MTVkYS01N2QxLTRkNzEtOTNmYS00ZTYzMmEzNGIxYzMuanBlZ5GTBc0BHcyg" />Rosja odwołała tegoroczną edycję najważniejszych w tym kraju międzynarodowych targów lotniczo-kosmicznych - MAKS, co wpisuje się w szereg problemów, z jakimi zmaga się rosyjski sektor lotniczo-kosmiczny - przekazało w niedzielę brytyjskie ministerstwo obrony.

## Rumunia wydaliła 40 pracowników ambasady Rosji
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8744815,rumunia-wydalila-40-pracownikow-ambasady-rosji.html](https://forsal.pl/swiat/unia-europejska/artykuly/8744815,rumunia-wydalila-40-pracownikow-ambasady-rosji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T07:54:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ecmktkuTURBXy9hNmE2NDk4NS1iYjcyLTQ4YWQtYWRlZS0yMWQ5MGY1ZjJkN2EuanBlZ5GTBc0BHcyg" />40 pracowników ambasady Federacji Rosyjskiej w Bukareszcie odleciało w sobotę wieczorem do Moskwy po tym jak władze rumuńskie zażądały zredukowania personelu tej placówki dyplomatycznej w związku z rosyjską inwazją na Ukrainę i pogorszeniem relacji bilateralnych.

## Zamieszki we Francji. Klienci odwołują rezerwacje w hotelach i restauracjach w całym kraju
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8744813,zamieszki-we-francji-klienci-odwoluja-rezerwacje-w-hotelach-i-restaur.html](https://forsal.pl/swiat/unia-europejska/artykuly/8744813,zamieszki-we-francji-klienci-odwoluja-rezerwacje-w-hotelach-i-restaur.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T07:44:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/e2lktkuTURBXy9lYTZjNDQ0OS00ZGRjLTQ1MzItOTJlOC1kOThmNmI1Zjg1NmYuanBlZ5GTBc0BHcyg" />Francuscy hotelarze i restauratorzy skarżą się na „falę odwoływania rezerwacji” z powodu zamieszek w całym kraju oraz plądrowanie i dewastowanie restauracji, barów i hoteli.

## Francja: Kilka tysięcy osób uczestniczyło w pogrzebie zabitego przez policjanta 17-latka
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8744812,francja-kilka-tysiecy-osob-uczestniczylo-w-pogrzebie-zabitego-przez-p.html](https://forsal.pl/swiat/unia-europejska/artykuly/8744812,francja-kilka-tysiecy-osob-uczestniczylo-w-pogrzebie-zabitego-przez-p.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T07:33:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/khyktkuTURBXy8yN2QxNmEyMC05ODc3LTQ1OGEtOTA3MC01YjQ2ZjA0NjQ2MGUuanBlZ5GTBc0BHcyg" />Kilka tysięcy osób uczestniczyło w sobotę w pogrzebie zastrzelonego przez policjanta 17-letniego Nahela w Nanterre pod Paryżem. Rodzina nie dopuściła dziennikarzy do uroczystości, które odbyły się w meczecie i na lokalnym cmentarzu.

## Zamieszki we Francji. W Marsylii policja aresztuje ludzi rabujących sklepy
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8744810,zamieszki-we-francji-w-marsylii-policja-aresztuje-ludzi-rabujacych-sk.html](https://forsal.pl/swiat/unia-europejska/artykuly/8744810,zamieszki-we-francji-w-marsylii-policja-aresztuje-ludzi-rabujacych-sk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T07:23:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/N7vktkuTURBXy9jYzAwNzAxNS03MGVjLTQyMjItYjFiMi00OWJhYjU5OTJhNzMuanBlZ5GTBc0BHcyg" />Policja w sobotę wieczorem w Marsylii aresztowała 14 osób podejrzanych o rabowanie sklepów, informują lokalne media. Opisują rajdy grup ludzi wdzierających się do sklepów na Canebiere, jednej z głównych ulic handlowych Marsylii.

## Medycyna defensywna. Czy polscy ginekolodzy mają problem z etyką? [WYWIAD]
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8744393,medycyna-defensywna-czy-polscy-ginekolodzy-maja-problem-z-etyka-wyw.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8744393,medycyna-defensywna-czy-polscy-ginekolodzy-maja-problem-z-etyka-wyw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T07:16:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/F9tktkuTURBXy9hMzE5MmMyOC00Njg3LTQzNDctYTgxYi01Yzc0ZWQ1N2RiYzEuanBlZ5GTBc0BHcyg" />Gdy sytuacja prawna jest niepewna, lekarze zachowują się w sposób dla siebie najbezpieczniejszy. Zapominają, że interes pacjenta powinien być ich podstawową troską

## Wchodzimy w epokę narażoną na katastrofy większe i częstsze
 - [https://forsal.pl/gospodarka/artykuly/8744406,wchodzimy-w-epoke-narazona-na-katastrofy-wieksze-i-czestsze.html](https://forsal.pl/gospodarka/artykuly/8744406,wchodzimy-w-epoke-narazona-na-katastrofy-wieksze-i-czestsze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T07:16:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/i6zktkuTURBXy81N2M4ZjE3ZS0yZjY0LTQwYzUtOWJhMS05MjEwMzhiYzA3MGEuanBlZ5GTBc0BHcyg" />Niektóre katastrofy wydarzyły się po to, byśmy mogli uniknąć większych

## Co powinna zrobić Polska, by poprawić swoją pozycję w technologicznym wyścigu? [WYWIAD]
 - [https://forsal.pl/lifestyle/technologie/artykuly/8744397,co-powinna-zrobic-polska-by-poprawic-swoja-pozycje-w-technologicznym.html](https://forsal.pl/lifestyle/technologie/artykuly/8744397,co-powinna-zrobic-polska-by-poprawic-swoja-pozycje-w-technologicznym.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T07:15:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uDuktkuTURBXy85MmVjNTczYS0xNjk1LTRjNmItYmFhOS02NTg3NWExYjc5OGYuanBlZ5GTBc0BHcyg" />Wyścig o AI dopiero się zaczyna, a ten, kto za długo będzie na starcie, nie będzie się w nim liczył

## W jakiej sytuacji jest kremlowski reżim po buncie Prigożyna?
 - [https://forsal.pl/swiat/rosja/artykuly/8744386,w-jakiej-sytuacji-jest-kremlowski-rezim-po-buncie-prigozyna.html](https://forsal.pl/swiat/rosja/artykuly/8744386,w-jakiej-sytuacji-jest-kremlowski-rezim-po-buncie-prigozyna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T07:14:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GQgktkuTURBXy85YTY1NGI2Ni1jMmViLTQxM2ItOTQxMS0zYmU2ZmQzMzZhZTEuanBlZ5GTBc0BHcyg" />Kremlowski reżim ma po nieudanym buncie Jewgienija Prigożyna spore problemy, które w ostatecznym rozrachunku mogą zdecydować o jego losach

## Gdzie Polacy pojadą na wakacje? Tam, gdzie ich stać
 - [https://forsal.pl/lifestyle/rozrywka/artykuly/8744354,gdzie-polacy-pojada-na-wakacje-tam-gdzie-ich-stac.html](https://forsal.pl/lifestyle/rozrywka/artykuly/8744354,gdzie-polacy-pojada-na-wakacje-tam-gdzie-ich-stac.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T07:13:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KXSktkuTURBXy9kZTVkMDc4My1mYjVhLTRlM2EtYTEwNC1lYWQ0ODRkZGFlMDIuanBlZ5GTBc0BHcyg" />Na pytanie, dokąd pojadą Polacy, narzuca się jedna odpowiedź: tam, gdzie ich stać

## Rekordowy eksport samochodów z UE. Miażdżąca dominacja Niemiec
 - [https://forsal.pl/motoforsal/motobiznes/artykuly/8743766,rekordowy-eksport-samochodow-z-ue-miazdzaca-dominacja-niemiec.html](https://forsal.pl/motoforsal/motobiznes/artykuly/8743766,rekordowy-eksport-samochodow-z-ue-miazdzaca-dominacja-niemiec.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-02T04:30:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6_KktkuTURBXy80NjdiYTRjNC01MjlhLTRlYWYtODhhZC1mNjgzNzdiNTNhOTMuanBlZ5GTBc0BHcyg" />W 2022 r. z Unii Europejskiej wyeksportowane zostały samochody o wartości 158 mld euro, czyli o 8 mld euro wyższej niż w 2015 r., gdy został ustanowiony poprzedni rekord. W ubiegłym roku import wyniósł 62 mld euro, co dało UE nadwyżkę handlową w wysokości 96 mld euro — podał Eurostat.

