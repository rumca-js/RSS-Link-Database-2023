# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Google zablokuje lokalne wiadomości w Kanadzie. Efekt nowej ustawy
 - [https://www.wirtualnemedia.pl/artykul/google-zablokuje-lokalne-wiadomosci-kanada-discover](https://www.wirtualnemedia.pl/artykul/google-zablokuje-lokalne-wiadomosci-kanada-discover)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-02T19:49:53.575293+00:00

W Kanadzie Google usunie linki do lokalnych wiadomości w wyszukiwarce, wiadomościach i sekcji Discover po niedawnym przejściu ustawy o informacjach w internecie.

## Na Kwejk.pl sprostowanie ws. memów o Robercie Lewandowskim
 - [https://www.wirtualnemedia.pl/artykul/robert-lewandowski-sprostowanie-memy-na-kwejku](https://www.wirtualnemedia.pl/artykul/robert-lewandowski-sprostowanie-memy-na-kwejku)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-02T18:56:00+00:00

Administracja portalu humorystycznego Kwejk.pl zamieściła sprostowanie dotyczące memów z nieprawdziwą informacją, jakoby to producent napojów Oshee zdecydował o zakończeniu współpracy z Robertem Lewandowskim.

## W Wirtualnej Polsce pensje wzrosły o 3 proc. Zarząd zarobił 7,3 mln zł
 - [https://www.wirtualnemedia.pl/artykul/wirtualna-polska-praca-zarobki-pensje-podwyzki-2023-rok](https://www.wirtualnemedia.pl/artykul/wirtualna-polska-praca-zarobki-pensje-podwyzki-2023-rok)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-02T07:05:52.643388+00:00

Przeciętne wynagrodzenie brutto w grupie kapitałowej Wirtualna Polska Holding w ub.r. zwiększyło się o 3 proc. Cztery osoby z zarządu firmy zarobiły łącznie 7,3 mln zł, z czego 3,43 mln zł zainkasował prezes Jacek Świderski.

## Dziki Trener zamiast naukowca. Dlaczego media odpuściły naukę?
 - [https://www.wirtualnemedia.pl/artykul/kto-to-jest-dziki-trener-naukowiec-tomasz-rozek-media-nauka](https://www.wirtualnemedia.pl/artykul/kto-to-jest-dziki-trener-naukowiec-tomasz-rozek-media-nauka)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-02T07:05:52.640859+00:00

„Chłopie jaki Ty jesteś konkretny i logiczny!! Chętniej Ciebie słucham niż obecnych naukowców, lekarzy czy profesorów [pisownia oryginalna – red.]”. Taki komentarz pojawił się pod jednym z filmów Dzikiego Trenera, jednego z youtube'owych ekspertów od wszystkiego. „Doprowadziliśmy do przerwania łączności między społeczeństwem a naukowcami” - stwierdził Jakub Wiech, mając na myśli dziennikarzy. Dlaczego tak się stało?

