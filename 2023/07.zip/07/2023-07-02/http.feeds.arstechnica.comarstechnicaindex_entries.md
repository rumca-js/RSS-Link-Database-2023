# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Mars has liquid guts and strange insides, InSight suggests
 - [https://arstechnica.com/?p=1951385](https://arstechnica.com/?p=1951385)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-02T15:00:30+00:00

Wobbles in its rotation are difficult to explain without a liquid core.

