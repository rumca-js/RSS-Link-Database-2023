# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Apple oficjalnie uśmierca 12-calowego MacBooka z 2015 roku
 - [https://ithardware.pl/aktualnosci/apple_oficjalnie_usmierca_12_calowego_macbooka_z_2015_roku-28088.html](https://ithardware.pl/aktualnosci/apple_oficjalnie_usmierca_12_calowego_macbooka_z_2015_roku-28088.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-02T20:59:50+00:00

<img src="https://ithardware.pl/artykuly/min/28088_1.jpg" />            Apple uznaje za przestarzały technologicznie&nbsp;model laptopa MacBook z 2015 roku, kt&oacute;rego produkcja została zakończona już wcześniej. Teraz formalnie go uśmiercono,

12-calowy MacBook uznany przez Apple za przestarzały

12-calowy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_oficjalnie_usmierca_12_calowego_macbooka_z_2015_roku-28088.html">https://ithardware.pl/aktualnosci/apple_oficjalnie_usmierca_12_calowego_macbooka_z_2015_roku-28088.html</a></p>

## Steam zbanował konta z CS:GO, na których były skiny o ogromnej wartości
 - [https://ithardware.pl/aktualnosci/steam_zbanowal_konta_z_cs_go_na_ktorych_byly_skiny_o_ogromnej_wartosci-28087.html](https://ithardware.pl/aktualnosci/steam_zbanowal_konta_z_cs_go_na_ktorych_byly_skiny_o_ogromnej_wartosci-28087.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-02T18:40:00+00:00

<img src="https://ithardware.pl/artykuly/min/28087_1.jpg" />            Handel kontami czy skinami w Counter-Strike: Global Offensive to dochodowy interes. Valve uderzyło w&nbsp;jeden taki biznes, w wyniku czego utracono przedmioty warte parę milion&oacute;w dolar&oacute;w amerykańskich.

Steam zbanował 40 kont, na...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/steam_zbanowal_konta_z_cs_go_na_ktorych_byly_skiny_o_ogromnej_wartosci-28087.html">https://ithardware.pl/aktualnosci/steam_zbanowal_konta_z_cs_go_na_ktorych_byly_skiny_o_ogromnej_wartosci-28087.html</a></p>

## Gogle od Apple pokryte 18-karatowym złotem. Nawet nie pytajcie o cenę
 - [https://ithardware.pl/aktualnosci/gogle_od_apple_pokryte_18_karatowym_zlotem_nawet_nie_pytajcie_o_cene-28086.html](https://ithardware.pl/aktualnosci/gogle_od_apple_pokryte_18_karatowym_zlotem_nawet_nie_pytajcie_o_cene-28086.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-02T17:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/28086_1.jpg" />            Marka Caviar, znana z produkcji luksusowych smartfon&oacute;w oraz akcesori&oacute;w elektronicznych, przedstawiła sw&oacute;j nowy projekt. Ich ofertę rozszerzają gogle Apple Vision Pro, ale w wersji, kt&oacute;rą przyozdabia 18-karatowe złoto oraz...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gogle_od_apple_pokryte_18_karatowym_zlotem_nawet_nie_pytajcie_o_cene-28086.html">https://ithardware.pl/aktualnosci/gogle_od_apple_pokryte_18_karatowym_zlotem_nawet_nie_pytajcie_o_cene-28086.html</a></p>

## Tablet Xiaomi Pad 6 pojawi się w Europie. Poznaliśmy cenę
 - [https://ithardware.pl/aktualnosci/tablet_xiaomi_pad_6_pojawi_sie_w_europie_poznalismy_cene-28085.html](https://ithardware.pl/aktualnosci/tablet_xiaomi_pad_6_pojawi_sie_w_europie_poznalismy_cene-28085.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-02T16:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/28085_1.jpg" />            W kwietniu Xiaomi zaprezentowało tablety Pad 6 i Pad 6 Pro. Podstawowy model zmierza do Europy i wiemy w jakiej cenie pojawi się na Starym Kontynencie.

Xiaomi Tab 6 trafi do Europy. Znamy cenę

Xiaomi Tab 6 i Tab 6 Pro początkowo zadebiutowały...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tablet_xiaomi_pad_6_pojawi_sie_w_europie_poznalismy_cene-28085.html">https://ithardware.pl/aktualnosci/tablet_xiaomi_pad_6_pojawi_sie_w_europie_poznalismy_cene-28085.html</a></p>

## Chińskie procesory będą miały SMT. Wydajność na poziomie Zen 3?
 - [https://ithardware.pl/aktualnosci/chinskie_procesory_beda_mialy_smt_wydajnosc_na_poziomie_zen_3-28084.html](https://ithardware.pl/aktualnosci/chinskie_procesory_beda_mialy_smt_wydajnosc_na_poziomie_zen_3-28084.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-02T15:39:40+00:00

<img src="https://ithardware.pl/artykuly/min/28084_1.jpg" />            Według nowych doniesień, chińskie procesory Loongson 3A6000 mają wspierać technologię SMT. W ramach tej serii wypuszczony zostanie 4-rdzeniowy i 8-wątkowy model oraz mocniejszy CPU z 8 rdzeniami i 16 wątkami. Loongson planuje rywalizację z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chinskie_procesory_beda_mialy_smt_wydajnosc_na_poziomie_zen_3-28084.html">https://ithardware.pl/aktualnosci/chinskie_procesory_beda_mialy_smt_wydajnosc_na_poziomie_zen_3-28084.html</a></p>

## Aplikacje pobierzemy także z Facebooka. Meta testuje nową usługę
 - [https://ithardware.pl/aktualnosci/aplikacje_pobierzemy_takze_z_facebooka_meta_testuje_nowa_usluge-28082.html](https://ithardware.pl/aktualnosci/aplikacje_pobierzemy_takze_z_facebooka_meta_testuje_nowa_usluge-28082.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-02T14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/28082_1.jpg" />            Jak informuje serwis The Verge Meta zaoferuje&nbsp;użytkownikom pobieranie aplikacji z Facebooka, aczkolwiek całość nie będzie działać tak jak Google Play czy App Store.

Facebook będzie umożliwiał pobieranie aplikacji z reklam

Meta...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/aplikacje_pobierzemy_takze_z_facebooka_meta_testuje_nowa_usluge-28082.html">https://ithardware.pl/aktualnosci/aplikacje_pobierzemy_takze_z_facebooka_meta_testuje_nowa_usluge-28082.html</a></p>

## Elon Musk ogranicza liczbę tweetów, które można zobaczyć w ciągu dnia
 - [https://ithardware.pl/aktualnosci/elon_musk_ogranicza_liczbe_tweetow_ktore_mozna_zobaczyc_w_ciagu_dnia-28083.html](https://ithardware.pl/aktualnosci/elon_musk_ogranicza_liczbe_tweetow_ktore_mozna_zobaczyc_w_ciagu_dnia-28083.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-02T13:48:20+00:00

<img src="https://ithardware.pl/artykuly/min/28083_1.jpg" />            Użytkownicy Twittera nie mogą teraz wyświetlać tylu wpis&oacute;w w ciągu dnia, ile by tylko chcieli. Elon Musk postanowił ograniczyć liczbę tweet&oacute;w, kt&oacute;re można dziennie zobaczyć. Limity zależą od kategorii konta, kt&oacute;re...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elon_musk_ogranicza_liczbe_tweetow_ktore_mozna_zobaczyc_w_ciagu_dnia-28083.html">https://ithardware.pl/aktualnosci/elon_musk_ogranicza_liczbe_tweetow_ktore_mozna_zobaczyc_w_ciagu_dnia-28083.html</a></p>

## Ludzie płacą krocie za stare iPhony. Te 4 egzemplarze mogą być warte ponad 200 tys. dolarów
 - [https://ithardware.pl/aktualnosci/ludzie_placa_krocie_za_stare_iphony_te_4_egzemplarze_moga_byc_warte_ponad_200_tys_dolarow-28081.html](https://ithardware.pl/aktualnosci/ludzie_placa_krocie_za_stare_iphony_te_4_egzemplarze_moga_byc_warte_ponad_200_tys_dolarow-28081.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-02T12:29:20+00:00

<img src="https://ithardware.pl/artykuly/min/28081_1.jpg" />            Cztery fabrycznie zapakowane iPhony pierwszej generacji&nbsp;trafiły właśnie na aukcję. Co istotne, każdy z nich jest nieco inny, więc ich finalne ceny będą się od siebie r&oacute;żnić. Szacuje się, że smartfony zostaną wylicytowane nawet...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ludzie_placa_krocie_za_stare_iphony_te_4_egzemplarze_moga_byc_warte_ponad_200_tys_dolarow-28081.html">https://ithardware.pl/aktualnosci/ludzie_placa_krocie_za_stare_iphony_te_4_egzemplarze_moga_byc_warte_ponad_200_tys_dolarow-28081.html</a></p>

## AMD Phoenix 2 - wersja "Little" sfotografowana
 - [https://ithardware.pl/aktualnosci/amd_phoenix_2_wersja_little_sfotografowana-28080.html](https://ithardware.pl/aktualnosci/amd_phoenix_2_wersja_little_sfotografowana-28080.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-02T11:25:50+00:00

<img src="https://ithardware.pl/artykuly/min/28080_1.jpg" />            Mamy kolejne wieści o chipie Phoenix 2, określanym r&oacute;wnież mianem &quot;Little Phoenix&quot;. Ostatnio pisaliśmy o wymiarach tego rdzenia, kt&oacute;re pojawiły się na stronie AMD. Tym razem do sieci trafiło zdjęcie chipu Phoenix 2...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_phoenix_2_wersja_little_sfotografowana-28080.html">https://ithardware.pl/aktualnosci/amd_phoenix_2_wersja_little_sfotografowana-28080.html</a></p>

