# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## The Right’s Desperate Push to Tank ESG and Avoid Disclosing Climate Risks
 - [https://theintercept.com/2023/07/02/esg-investing-sec-climate/](https://theintercept.com/2023/07/02/esg-investing-sec-climate/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-07-02T10:00:00+00:00

<p>Pro-business politicians embraced the idea of so-called green investing — until the SEC suggested companies should report their full emissions.</p>
<p>The post <a href="https://theintercept.com/2023/07/02/esg-investing-sec-climate/" rel="nofollow">The Right’s Desperate Push to Tank ESG and Avoid Disclosing Climate Risks</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

