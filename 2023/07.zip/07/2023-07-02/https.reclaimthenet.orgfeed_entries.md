# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Terry Pratchett Audiobooks Are Hit With Trigger Warnings
 - [https://reclaimthenet.org/terry-pratchett-audiobooks-are-hit-with-trigger-warnings](https://reclaimthenet.org/terry-pratchett-audiobooks-are-hit-with-trigger-warnings)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-07-02T16:49:25+00:00

<a href="https://reclaimthenet.org/terry-pratchett-audiobooks-are-hit-with-trigger-warnings" rel="nofollow" title="Terry Pratchett Audiobooks Are Hit With Trigger Warnings"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/07/pratchett-audiobooks-trigger.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Alleged "outdated" attitudes.</p>
<p>The post <a href="https://reclaimthenet.org/terry-pratchett-audiobooks-are-hit-with-trigger-warnings" rel="nofollow">Terry Pratchett Audiobooks Are Hit With Trigger Warnings</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

