# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Uniforms? Check. Motto? Check. Now the Space Force needs an identity.
 - [https://www.washingtonpost.com/technology/2023/07/02/space-force-mission-defined/](https://www.washingtonpost.com/technology/2023/07/02/space-force-mission-defined/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-07-02T11:00:32+00:00

Three years after it was established as the sixth branch of the U.S. Armed Forces, the U.S. Space Force is working to define its mission.

