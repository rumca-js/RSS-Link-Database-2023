# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## 500 policjantów z prewencji i kontrterroryści jada na granicę z Białorusią
 - [https://wydarzenia.interia.pl/kraj/news-500-policjantow-z-prewencji-i-kontrterrorysci-jada-na-granic,nId,6877952](https://wydarzenia.interia.pl/kraj/news-500-policjantow-z-prewencji-i-kontrterrorysci-jada-na-granic,nId,6877952)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-07-02T09:35:06+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-500-policjantow-z-prewencji-i-kontrterrorysci-jada-na-granic,nId,6877952"><img align="left" alt="500 policjantów z prewencji i kontrterroryści jada na granicę z Białorusią" src="https://i.iplsc.com/500-policjantow-z-prewencji-i-kontrterrorysci-jada-na-granic/000HCPQZVFG31WHP-C321.jpg" /></a>&quot;W związku z napiętą sytuacją na granicy z Białorusią, podjąłem decyzję o wzmocnieniu naszych sił grupą 500 funkcjonariuszy policji z oddziałów prewencji i kontrterrorystami&quot; - oświadczył w niedzielę szef spraw wewnętrznych i administracji Mariusz Kamiński. Działania podejmowane są z uwagi na pojawienie się u sąsiad zza wschodniej granicy najemników   Grupy Wagnera oraz coraz liczniejsze próby nielegalnego przekraczania granicy polsko-białoruskiej. </p><br clear="all" />

