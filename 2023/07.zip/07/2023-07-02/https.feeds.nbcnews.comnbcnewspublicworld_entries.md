# Source:NBC world, URL:https://feeds.nbcnews.com/nbcnews/public/world, language:en-US

## Syria says it repelled Israeli strike, anti-aircraft missile fragments hit Israel
 - [https://www.nbcnews.com/news/world/syria-says-repelled-israeli-strike-anti-aircraft-missile-fragments-hit-rcna92229](https://www.nbcnews.com/news/world/syria-says-repelled-israeli-strike-anti-aircraft-missile-fragments-hit-rcna92229)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-07-02T13:38:59+00:00

Syria said it repelled a missile salvo on Sunday from Israel, where police reported that remnants of a Syrian anti-aircraft missile struck a remote town without causing injuries.

## French police arrest 700 protestors as mayor's family survives burning car 'assassination' attempt
 - [https://www.nbcnews.com/news/world/french-police-arrest-700-protestors-mayors-family-survives-burning-car-rcna92222](https://www.nbcnews.com/news/world/french-police-arrest-700-protestors-mayors-family-survives-burning-car-rcna92222)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-07-02T11:42:19+00:00

Rioters clashed with police Saturday night on the fifth day of unrest following the fatal police shooting of a 17-year-old boy in a Paris suburb, while a local mayor said he was the victim of an assassination attempt by protestors.

## She ditched her day job to pursue her art with a basic income grant from Ireland
 - [https://www.nbcnews.com/news/world/ireland-basic-income-artists-musicians-filmmakers-economy-pilot-scheme-rcna89707](https://www.nbcnews.com/news/world/ireland-basic-income-artists-musicians-filmmakers-economy-pilot-scheme-rcna89707)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-07-02T10:00:00+00:00

CORK, Ireland — Artist Elinor O’Donovan draws, sculpts and creates installations, and said she feels lucky that her passion is also her profession.

## How 'climate lockdowns' became the new battleground for conspiracy-driven protest movement
 - [https://www.nbcnews.com/news/world/climate-lockdowns-became-new-battleground-conspiracy-driven-protest-mo-rcna80370](https://www.nbcnews.com/news/world/climate-lockdowns-became-new-battleground-conspiracy-driven-protest-mo-rcna80370)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-07-02T09:16:12+00:00

A growing protest movement with roots in opposition to Covid lockdowns is railing against “15-minute cities,” an urban planning idea designed to reduce traffic.

