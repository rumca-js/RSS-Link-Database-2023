# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Apple's new Mac Pro can't do THIS!
 - [https://www.youtube.com/watch?v=yI7fV88T8A0](https://www.youtube.com/watch?v=yI7fV88T8A0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-07-02T17:43:18+00:00

You’ll be amazed at what you can do with GrammarlyGO. Sign up at https://grammarly.com/LTT07 and get 20% off Grammarly Premium.

Check out the Govee Curtain Light at the link below and use code LTT25OFF to get 25% off until June 23rd!
Amazon: https://amzn.to/3Xl1eby
Website: https://bit.ly/3CBv2qQ

Gaming on a Mac leaves something to be desired in 2023. But was it always so hard? Could Apple's final server ACTUALLY be a good gaming PC with the right tweaks?

Discuss on the forum: https://linustechtips.com/topic/1516934-apples-new-mac-pro-cant-do-this/

Buy an Intel Xeon E5520 Processor: https://geni.us/KeUPO
Buy Kingston 1x16GB DDR3 RAM: https://geni.us/Panpg
Buy an EVGA GeForce GTX TITAN X Graphics Card: https://geni.us/6pkI

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► EQUIPMENT WE USE TO FILM LTT: https://lmg.gg/LTTEquipment
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:03 Upgrade Path
5:50 Testing it all out
6:28 Why won't you work?
8:14 It works! But why?
10:45 It boots! Can we game?
12:30 Booting games by any means necessary
14:23 The games drive is dead
15:12 Gaming for real this time
17:48 Final Thoughts

