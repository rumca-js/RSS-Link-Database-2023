# Source:The Guardian - International, URL:https://www.theguardian.com/international/rss, language:en-US

## Patrick Vieira ‘excited to build’ after appointment as Strasbourg coach
 - [https://www.theguardian.com/sport/2023/jul/02/patrick-vieira-excited-to-build-after-appointment-as-strasbourg-coach](https://www.theguardian.com/sport/2023/jul/02/patrick-vieira-excited-to-build-after-appointment-as-strasbourg-coach)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-07-02T21:58:36+00:00

<ul><li>Former France midfielder sacked by Crystal Palace in March</li><li>Vieira: ‘I know the history and identity of this club’</li></ul><p>Strasbourg have appointed Patrick Vieira as their new manager on a three-year contract, the Ligue 1 club said on Sunday. The former France international coached Crystal Palace from 2021 to this year.</p><p>The 47-year-old guided Palace to a 12th-placed Premier League finish and an FA Cup semi-final in his first season in charge but was sacked mid-March after a 1-0 defeat at Brighton that left the south London club three points above the relegation zone.</p> <a href="https://www.theguardian.com/sport/2023/jul/02/patrick-vieira-excited-to-build-after-appointment-as-strasbourg-coach">Continue reading...</a>

## Nascar contractor dies after being electrocuted at Chicago Street Race
 - [https://www.theguardian.com/sport/2023/jul/02/nascar-contractor-dies-chicago-street-race](https://www.theguardian.com/sport/2023/jul/02/nascar-contractor-dies-chicago-street-race)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-07-02T17:25:40+00:00

<ul><li>Duane Tabinski, 53, dies while setting up for Chicago Street Race</li><li>Chicago event is first street race in Nascar Cup Series history</li></ul><p>A Nascar contractor has died after being electrocuted while setting up for the Chicago Street Race.</p><p>The Cook County Medical Examiner identified the man who died Friday as 53-year-old Duane Tabinski, the founder of an events company hired to install audio equipment for the race, local station <a href="https://abc7chicago.com/duane-tabinski-chicago-nascar-worker-dies-contractor/13450532/">WLS-TV</a> reported.</p> <a href="https://www.theguardian.com/sport/2023/jul/02/nascar-contractor-dies-chicago-street-race">Continue reading...</a>

## Australia keep cool after controversy to avoid Stokes’ Headingley Mach II | Geoff Lemon
 - [https://www.theguardian.com/sport/blog/2023/jul/02/australia-keep-calm-after-controversy-to-avoid-stokes-headingley-mach-ii-england-ashes](https://www.theguardian.com/sport/blog/2023/jul/02/australia-keep-calm-after-controversy-to-avoid-stokes-headingley-mach-ii-england-ashes)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-07-02T17:15:39+00:00

<p>Tourists steered clear of a repeat of 2019’s miracle defeat by finally ending England’s resistance after Bairstow drama</p><p>“The dream is always the same,” says Joel Goodsen at the start of Risky Business. And it is, even if everyone’s version is different. He dreams of missing an exam that will ruin his future. Others can’t find their batting kit when they’re due in the middle, or have to flee an enemy who is always right behind them. They wake, they stumble through their day, then back into the halls of sleep.</p><p>Australia’s <a href="https://www.theguardian.com/sport/2019/aug/25/australia-ashes-england-third-test-ben-stokes-sensational">class of Headingley 2019</a> would have had some dreams after Ben Stokes pulled off his last-day miracle. After one night’s sleep their head coach Justin Langer made them watch the whole innings again, the way they fell apart. Tim Paine, then the captain, spoke much later of how often it still came to mind. And then, at <a href="https://www.theguardian.com/sport/2023/jul/02/england-australia-cricket-ashes-second-test-day-five-report-ben-stokes">Lord’s in 2023</a>, there it is again.</p> <a href="https://www.theguardian.com/sport/blog/2023/jul/02/australia-keep-calm-after-controversy-to-avoid-stokes-headingley-mach-ii-england-ashes">Continue reading...</a>

## ‘Blessed’: United States star Tim Weah signs five-year contract with Juventus
 - [https://www.theguardian.com/football/2023/jul/02/tim-weah-juventus-transfer-lille-usmnt-star](https://www.theguardian.com/football/2023/jul/02/tim-weah-juventus-transfer-lille-usmnt-star)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-07-02T12:25:03+00:00

<ul><li>Weah, 23, completes transfer to Juventus from Lille</li><li>Winger has scored four goals in 31 appearances for USA</li></ul><p>United States winger Tim Weah completed a transfer to Juventus on Saturday, fulfilling a dream his father once had of playing for the storied Italian club.</p><p>The 23-year-old Weah, who is the son of former Fifa Player of the Year and current Liberian president George Weah, signed a five-year contract with Juventus on the day the transfer market opened in Italy.</p> <a href="https://www.theguardian.com/football/2023/jul/02/tim-weah-juventus-transfer-lille-usmnt-star">Continue reading...</a>

## The US supreme court has dismantled our rights but we still believe in them. Now we must fight | Rebecca Solnit
 - [https://www.theguardian.com/commentisfree/2023/jul/02/us-supreme-court-civil-rights-voting-fight](https://www.theguardian.com/commentisfree/2023/jul/02/us-supreme-court-civil-rights-voting-fight)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-07-02T08:00:36+00:00

<p>The court is part of a gang of reactionaries clawing back rights we already won, which means we can win them back</p><p>The first thing to remember about the damage done by the US supreme court this June and the June before is that each majority decision overturns a right that we had won. We had won a measure of student debt relief thanks to the heroic efforts of debt activists since 2011. We had won reproductive rights protection 50 years ago with Roe v Wade, and we won wetlands protection with the Clean Water Act around the same time. We had implemented affirmative action, AKA a redress of centuries of institutionalized inequality, step by step, in many ways over the past 60-plus years. We had won rights for same-sex couples and queer people in a series of laws and decisions.</p><p>What this means is that the right wing of the US supreme court is part of a gang of reactionaries engaging in backlash. It also means we can win these things back. It will not be easy, but difficult is not impossible. This does not mean that the decisions are not devastating, and that we should not feel the pain. The old saying “don’t mourn, organize” has always worked better for me as “mourn, but also organize”. Defeat is no reason to stop. Neither is victory a reason to stop when victory is partial or needs to be defended. You can celebrate victories, mourn defeats and keep going.</p> <a href="https://www.theguardian.com/commentisfree/2023/jul/02/us-supreme-court-civil-rights-voting-fight">Continue reading...</a>

## Remote working is like a dating app: isolating, joyless and bad for us. Yet still we stay home | Martha Gill
 - [https://www.theguardian.com/commentisfree/2023/jul/02/working-from-home-mental-health-society](https://www.theguardian.com/commentisfree/2023/jul/02/working-from-home-mental-health-society)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-07-02T07:01:35+00:00

We crave social connection but sit indoors typing and swiping. Is it time to prod us back into the office?<p>What happens when social creatures are deprived of social contact? For three years we have been conducting a very large experiment – of the sort, were it done to rhesus monkeys, that would get animal rights extremists in a lather. What if we took the main convener of community in the modern west, the workplace, and split up these communities, sequestering their members inside their homes?</p><p>At first the experiment was forced on us, but when the cage doors finally opened something strange happened: many of us simply chose to stay there. We refused to be released into the wild. In the year to December 2019, around 12% of working adults reported working from home at some point in the past seven days. Between January and February 2023 that figure was 40%. Some 16% of us, now, never go into the office. <a href="https://www.ons.gov.uk/employmentandlabourmarket/peopleinwork/employmentandemployeetypes/articles/characteristicsofhomeworkersgreatbritain/september2022tojanuary2023" title="">The experiment continues</a>.</p> <a href="https://www.theguardian.com/commentisfree/2023/jul/02/working-from-home-mental-health-society">Continue reading...</a>

