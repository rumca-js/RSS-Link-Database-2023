# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Zamieszki we Francji. Babcia zabitego przez policjanta 17-latka apeluje do protestujących
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/zamieszki-we-francji-babcia-zabitego-przez-policjanta-17-latka-apeluje-do-protestujacych/](https://www.polsatnews.pl/wiadomosc/2023-07-02/zamieszki-we-francji-babcia-zabitego-przez-policjanta-17-latka-apeluje-do-protestujacych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T16:32:00+00:00

Babcia zastrzelonego przez policjanta 17-latka w telewizji BFMTV zwróciła się do uczestników zamieszek we Francji. Kobieta uważa, że śmierć jej wnuka została wykorzystana przez protestujących jako pretekst do siania zniszczeń i zaapelowała, by zaprzestali swoich działań.

## USA. Strzelanina w Baltimore. Dwie osoby nie żyją, 28 rannych
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/usa-strzelanina-w-baltimore-dwie-osoby-nie-zyja-28-rannych/](https://www.polsatnews.pl/wiadomosc/2023-07-02/usa-strzelanina-w-baltimore-dwie-osoby-nie-zyja-28-rannych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T14:10:00+00:00

Dwie osoby zginęły, a 28 zostało rannych w strzelaninie na festynie w Baltimore w USA. Świadkowie opisali w rozmowie z lokalnymi mediami, że usłyszeli 20-30 strzałów. Mimo intensywnych poszukiwań, sprawca masakry cały czas pozostaje na wolności.

## Rishi Sunak przekazał miliony amerykańskim placówkom. Angielskiej szkole dał butelkę wina
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/r-sunak-przekazal-miliony-amerykanskim-placowkom-angielskiej-szkole-dal-butelke-wina-za-10-funtow/](https://www.polsatnews.pl/wiadomosc/2023-07-02/r-sunak-przekazal-miliony-amerykanskim-placowkom-angielskiej-szkole-dal-butelke-wina-za-10-funtow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T11:57:00+00:00

Brytyjski premier wystawił na szkolną aukcję butelkę wina za 10 funtów. Był to najtańszy trunek w sklepie Izby Gmin. Co ważniejsze stało się to po tym, jak wyszło na jaw, że Rishi Sunak przekazał około trzy miliony dolarów na amerykańskie uczelnie. Nie oczekujemy milionów, ale coś więcej niż 10 funtów, które moglibyśmy wylicytować, byłoby dobre - stwierdziła przewodniczącą rady rodziców.

## Cypr: Zabawa tragiczna w skutkach. Zginęła sześcioletnia dziewczynka
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/cypr-zabawa-tragiczna-w-skutkach-zginela-szescioletnia-dziewczynka/](https://www.polsatnews.pl/wiadomosc/2023-07-02/cypr-zabawa-tragiczna-w-skutkach-zginela-szescioletnia-dziewczynka/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T09:48:00+00:00

Zabawa, która przerodziła się w katastrofę. W sobotę na Cyprze doszło do wypadku dwóch skuterów wodnych. Rosyjscy turyści zderzyli się ze sobą podczas zabaw, przewożąc osoby nieletnie. Sześciolatka została ranna, jej stan był bardzo ciężki. Dziecko zmarło w szpitalu.

## Polak wspiął się na wieżowiec Montparnasse w Paryżu. Zrobił to bez zabezpieczeń
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/polak-wspial-sie-na-wiezowiec-w-paryzu-zrobil-to-bez-zabezpieczen/](https://www.polsatnews.pl/wiadomosc/2023-07-02/polak-wspial-sie-na-wiezowiec-w-paryzu-zrobil-to-bez-zabezpieczen/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T09:38:00+00:00

30 czerwca mieszkaniec Świętochłowic wspiął się na wieżowiec Montparnasse w Paryżu. Mężczyzna dokonał tego bez żadnych zabezpieczeń. To nie pierwszy taki wyczyn Polaka. Ma na swoim koncie wspinaczkę na warszawski Marriott oraz wieżę Eiffla

## USA: Setki burrito wylądowały na drodze. Skutek zderzenia dwóch ciężarówek
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/nebraska-setki-burrito-wyladowaly-na-drodze-skutek-zderzenia-dwoch-ciezarowek/](https://www.polsatnews.pl/wiadomosc/2023-07-02/nebraska-setki-burrito-wyladowaly-na-drodze-skutek-zderzenia-dwoch-ciezarowek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T08:56:00+00:00

W Nebrasce na autostradzie zderzyły się ze sobą dwie ciężarówki. Tir przewożący bydło uderzył w tył samochodu, który transportował burrito. Meksykańskie jedzenie wypadło na autostradę blokując przejazd.

## Włochy. Burze, bomby wodne, trąby powietrzne. "13 gwałtownych zjawisk dziennie"
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/wlochy-burze-bomby-wodne-traby-powietrzne/](https://www.polsatnews.pl/wiadomosc/2023-07-02/wlochy-burze-bomby-wodne-traby-powietrzne/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T07:38:00+00:00

We Włoszech od poczatku lata występuje średnio 13 gwałtownych zjawisk dziennie: burz, ulew nazywanych bombami wodnymi, trąb powietrznych i gradobić - podkreślili eksperci w raporcie opublikowanym przez krajowy związek rolników Coldiretti. Nasz klimat staje się tropikalny.

## B. Babuśka: Nie wierzę w atak ze strony Białorusi. Konsul honorowy komentuje sytuację na froncie
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/b-babuska-nie-wierze-w-atak-ze-strony-bialorusi-konsul-honorowy-komentuje-sytuacje-na-froncie/](https://www.polsatnews.pl/wiadomosc/2023-07-02/b-babuska-nie-wierze-w-atak-ze-strony-bialorusi-konsul-honorowy-komentuje-sytuacje-na-froncie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T06:46:00+00:00

Po 12 dniach Rosja znowu zaatakowała Kijów pociskami lotniczymi. - W tej chwili Ukraina cały czas potrzebuje artylerii szczególnie tej dalekiego zasięgu - zaznaczył Bartłomiej Babuśka w rozmowie z Polsat News. Dodał, że działania na froncie są precedensem w historii świata.

## Francja: Kolejna noc walk z policją i rozruchów. Setki aresztowanych
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/francja-kolejna-noc-walk-z-policja-i-rozruchow-setki-aresztowanych/](https://www.polsatnews.pl/wiadomosc/2023-07-02/francja-kolejna-noc-walk-z-policja-i-rozruchow-setki-aresztowanych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T06:14:00+00:00

Podczas kolejnej, piątej już nocy rozruchów i walk z policją we Francji aresztowano 486 osób - poinformowało w niedzielę nad ranem ministerstwo spraw wewnętrznych. W Marsylii policja użyła wobec protestujących gazu łzawiącego.

## Tajlandia zażądała zwrotu prezentu po dwóch dekadach. Spór dyplomatyczny o słonia
 - [https://www.polsatnews.pl/wiadomosc/2023-07-02/tajlandia-zazadala-zwrotu-prezentu-po-dwoch-dekadach-spor-dyplomatyczny-o-slonia/](https://www.polsatnews.pl/wiadomosc/2023-07-02/tajlandia-zazadala-zwrotu-prezentu-po-dwoch-dekadach-spor-dyplomatyczny-o-slonia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-02T05:32:00+00:00

Tajlandia zażądała zwrotu prezentu, który przekazała Sri Lance 20 lat temu. Słoń zwany Muthu Raja powróci w niedzielę do kraju urodzenia. Jego sytuacja wywołała spór dyplomatyczny między krajami, po tym, jak Tajlandia zarzuciła Sri Lance, że słoń był torturowany i zaniedbywany.

