# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## The Official Podcast Episode #343: Sealing Away the Ocean
 - [https://www.youtube.com/watch?v=jo2XauADeNY](https://www.youtube.com/watch?v=jo2XauADeNY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-07-02T16:00:21+00:00

Four close man friends gather around to talk about sealing away the ocean.

This is the Official Podcast. Every Monday at 7pm EST. Links Below.

---

Get additional episodes and bonus content with early access:
go to https://www.PATREON.com/THEOFFICIALPODCAST

Brought to you by the following sponsors:

GET 20% OFF YOUR FITBOD SUBSCRIPTION NOW:
go to https://www.FITBOD.me/OFFICIAL

GET MINT'S WIRELESS PLAN FOR JUST $15 A MONTH:
go to https://www.MINTMOBILE.com/OFFICIAL

GET GODSLAP AND PLAGUE SEEKER RIGHT NOW:
go to https://www.BADEGG.co

---

Timestamps:

00:00 Intro
00:30 Jackson Returns
02:14 The Titanic Submersible
09:10 Andrew Hates the Zoo
12:37 The Titanic Submersible (pt. 2)
22:12 Kaya wants to Delete the Ocean
24:48 Fitbod
27:01 Mint Mobile
28:38 The Orcas are Fighting Back
31:32 Hoarding Nuclear Waste
34:18 Cities on Top of Cities
38:41 Pixar’s Decline
50:49 Secret Invasion’s A.I. Intro
55:41 Twomad
58:05 Gamer Rage
01:07:11 Wrap

---

Hosts: 

Jackson: https://twitter.com/zealotonpc 
Andrew: https://twitter.com/huggbeestv 
Charlie: https://twitter.com/moistcr1tikal 
Kaya: https://twitter.com/kayaorsan

---

The Official Podcast Links: 

SubReddit: https://reddit.com/r/theofficialpodcast 
Google Play: https://play.google.com/music/m/Iv4af6j46ldkjja7vwnvljbyiw4?t=The_Official_Podcast 
Google Podcasts: https://www.google.com/podcasts?feed=aHR0cHM6Ly9mZWVkcy5tZWdhcGhvbmUuZm0vVE9QNzc4NDYyNTk4MA%3D%3D 
Spotify: https://open.spotify.com/show/6TXzjtMTEopiGjIsCfvv6W 
iTunes: https://itunes.apple.com/au/podcast/the-official-podcast/id1186089636 
Patreon: https://www.patreon.com/theofficialpodcast
Intro by: https://www.youtube.com/c/Derpmii
Music by: https://soundcloud.com/inst1nctive
Thumbnail by: https://www.instagram.com/nook_eilyk/
Edited by: https://www.instagram.com/00zaya

## Is Twitter Actually Dying
 - [https://www.youtube.com/watch?v=Gsg1Xjd9Xx0](https://www.youtube.com/watch?v=Gsg1Xjd9Xx0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-07-02T00:15:01+00:00

This is the greatest twitter limit of All Time
Merch https://moistglobal.com/

