# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## We MUST EXPOSE THIS Before It’s Too LATE!! | Matt Taibbi & Michael Shellenberger (LIVE EVENT)
 - [https://www.youtube.com/watch?v=pp5C5Qtdil4](https://www.youtube.com/watch?v=pp5C5Qtdil4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-07-02T17:00:28+00:00

Here is a sneak preview of the recent "Censorship Industrial Complex... Exposed!" event I hosted alongside Twitter Files journalists Matt Taibbi & Michael Shellenberger. In this preview you we discussed the Orwellian nature of the censorship currently occurring across media and tech spaces.
#tech #censorship #exposed 

Watch Part 1 of this event in full on Rumble: https://bit.ly/censorship-exposed-part-one

Read Matt Taibbi's work on his Substack channel at: https://www.racket.news/

Find Michael Shellenberger's work on his Substack channel at: https://public.substack.com/
--------------------------------------------------------------------------------------------------------------------------
My stand up is available for only 2 weeks! Get it before it's GONE FOREVER! Go to https://moment.co/russellbrand

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community

Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

