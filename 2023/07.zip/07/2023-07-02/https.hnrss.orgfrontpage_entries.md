# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Illegal Life Pro Tip: Want to ruin your competitors business?
 - [https://oppositeinvictus.com/illegal-life-pro-tip-want-to-ruin-your-competitors-business](https://oppositeinvictus.com/illegal-life-pro-tip-want-to-ruin-your-competitors-business)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T22:51:19+00:00

<p>Article URL: <a href="https://oppositeinvictus.com/illegal-life-pro-tip-want-to-ruin-your-competitors-business">https://oppositeinvictus.com/illegal-life-pro-tip-want-to-ruin-your-competitors-business</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36566634">https://news.ycombinator.com/item?id=36566634</a></p>
<p>Points: 76</p>
<p># Comments: 23</p>

## GitHub repository disabled at 22M commits
 - [https://programming.dev/post/355447](https://programming.dev/post/355447)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T21:15:48+00:00

<p>Article URL: <a href="https://programming.dev/post/355447">https://programming.dev/post/355447</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36565842">https://news.ycombinator.com/item?id=36565842</a></p>
<p>Points: 23</p>
<p># Comments: 12</p>

## Automated CPU Design with AI
 - [https://arxiv.org/abs/2306.12456](https://arxiv.org/abs/2306.12456)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T20:59:10+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2306.12456">https://arxiv.org/abs/2306.12456</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36565671">https://news.ycombinator.com/item?id=36565671</a></p>
<p>Points: 47</p>
<p># Comments: 7</p>

## AMD’s EPYC 7J13: Zen 3 Customized
 - [https://chipsandcheese.com/2023/06/27/amds-epyc-7j13-zen-3-customized/](https://chipsandcheese.com/2023/06/27/amds-epyc-7j13-zen-3-customized/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T20:52:37+00:00

<p>Article URL: <a href="https://chipsandcheese.com/2023/06/27/amds-epyc-7j13-zen-3-customized/">https://chipsandcheese.com/2023/06/27/amds-epyc-7j13-zen-3-customized/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36565604">https://news.ycombinator.com/item?id=36565604</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## WebAuthn Is Great and It Sucks
 - [https://sec.okta.com/articles/2020/04/webauthn-great-and-it-sucks/](https://sec.okta.com/articles/2020/04/webauthn-great-and-it-sucks/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T20:35:08+00:00

<p>Article URL: <a href="https://sec.okta.com/articles/2020/04/webauthn-great-and-it-sucks/">https://sec.okta.com/articles/2020/04/webauthn-great-and-it-sucks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36565405">https://news.ycombinator.com/item?id=36565405</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## 43% of white Harvard students are legacy, athlete, or donor/staff related (2019)
 - [https://www.nbcnews.com/news/us-news/study-harvard-finds-43-percent-white-students-are-legacy-athletes-n1060361](https://www.nbcnews.com/news/us-news/study-harvard-finds-43-percent-white-students-are-legacy-athletes-n1060361)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T20:32:25+00:00

<p>Article URL: <a href="https://www.nbcnews.com/news/us-news/study-harvard-finds-43-percent-white-students-are-legacy-athletes-n1060361">https://www.nbcnews.com/news/us-news/study-harvard-finds-43-percent-white-students-are-legacy-athletes-n1060361</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36565378">https://news.ycombinator.com/item?id=36565378</a></p>
<p>Points: 30</p>
<p># Comments: 21</p>

## Googling for answers costs you time
 - [https://prashanth.world/seo-ruining-programming-help/](https://prashanth.world/seo-ruining-programming-help/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T20:16:35+00:00

<p>Article URL: <a href="https://prashanth.world/seo-ruining-programming-help/">https://prashanth.world/seo-ruining-programming-help/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36565225">https://news.ycombinator.com/item?id=36565225</a></p>
<p>Points: 44</p>
<p># Comments: 60</p>

## Recession canceled? U.S. stock market 'frothy' after S&P 500's strong first half
 - [https://www.marketwatch.com/story/recession-canceled-u-s-stock-market-pretty-frothy-after-s-p-500s-strongest-first-half-since-2019-2b75f7a2](https://www.marketwatch.com/story/recession-canceled-u-s-stock-market-pretty-frothy-after-s-p-500s-strongest-first-half-since-2019-2b75f7a2)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T19:30:07+00:00

<p>Article URL: <a href="https://www.marketwatch.com/story/recession-canceled-u-s-stock-market-pretty-frothy-after-s-p-500s-strongest-first-half-since-2019-2b75f7a2">https://www.marketwatch.com/story/recession-canceled-u-s-stock-market-pretty-frothy-after-s-p-500s-strongest-first-half-since-2019-2b75f7a2</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36564810">https://news.ycombinator.com/item?id=36564810</a></p>
<p>Points: 36</p>
<p># Comments: 26</p>

## Forgotten Tragedy of Italian War Detainees
 - [https://www3.nhk.or.jp/nhkworld/en/news/backstories/816/](https://www3.nhk.or.jp/nhkworld/en/news/backstories/816/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T19:26:46+00:00

<p>Article URL: <a href="https://www3.nhk.or.jp/nhkworld/en/news/backstories/816/">https://www3.nhk.or.jp/nhkworld/en/news/backstories/816/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36564782">https://news.ycombinator.com/item?id=36564782</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

## Why Commuters Prefer Origin to Destination Transfers
 - [https://pedestrianobservations.com/2023/06/30/why-commuters-prefer-origin-to-destination-transfers/](https://pedestrianobservations.com/2023/06/30/why-commuters-prefer-origin-to-destination-transfers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T19:07:21+00:00

<p>Article URL: <a href="https://pedestrianobservations.com/2023/06/30/why-commuters-prefer-origin-to-destination-transfers/">https://pedestrianobservations.com/2023/06/30/why-commuters-prefer-origin-to-destination-transfers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36564608">https://news.ycombinator.com/item?id=36564608</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## C’s Biggest Mistake
 - [https://www.digitalmars.com/articles/C-biggest-mistake.html](https://www.digitalmars.com/articles/C-biggest-mistake.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T19:00:22+00:00

<p>Article URL: <a href="https://www.digitalmars.com/articles/C-biggest-mistake.html">https://www.digitalmars.com/articles/C-biggest-mistake.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36564535">https://news.ycombinator.com/item?id=36564535</a></p>
<p>Points: 23</p>
<p># Comments: 4</p>

## Relay Mining: Verifiable Multi-Tenant Distributed Rate Limiting
 - [https://arxiv.org/abs/2305.10672](https://arxiv.org/abs/2305.10672)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T18:41:41+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2305.10672">https://arxiv.org/abs/2305.10672</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36564350">https://news.ycombinator.com/item?id=36564350</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Google Search's Death by a Thousand Cuts
 - [https://matt-rickard.com/google-searchs-death-by-a-thousand-cuts](https://matt-rickard.com/google-searchs-death-by-a-thousand-cuts)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T18:14:13+00:00

<p>Article URL: <a href="https://matt-rickard.com/google-searchs-death-by-a-thousand-cuts">https://matt-rickard.com/google-searchs-death-by-a-thousand-cuts</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36564042">https://news.ycombinator.com/item?id=36564042</a></p>
<p>Points: 43</p>
<p># Comments: 19</p>

## JavaScript Gom Jabbar
 - [https://frantic.im/javascript-gom-jabbar/](https://frantic.im/javascript-gom-jabbar/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T18:12:09+00:00

<p>Article URL: <a href="https://frantic.im/javascript-gom-jabbar/">https://frantic.im/javascript-gom-jabbar/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36564010">https://news.ycombinator.com/item?id=36564010</a></p>
<p>Points: 34</p>
<p># Comments: 4</p>

## AMD CPU Use Among Linux Gamers Approaching 70% Marketshare
 - [https://www.phoronix.com/news/AMD-CPU-Linux-Gaming-67p](https://www.phoronix.com/news/AMD-CPU-Linux-Gaming-67p)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T18:09:29+00:00

<p>Article URL: <a href="https://www.phoronix.com/news/AMD-CPU-Linux-Gaming-67p">https://www.phoronix.com/news/AMD-CPU-Linux-Gaming-67p</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36563979">https://news.ycombinator.com/item?id=36563979</a></p>
<p>Points: 45</p>
<p># Comments: 29</p>

## Chinese Tech Terms Explained in English
 - [https://16x.engineer/2022/10/18/chinese-tech-terms.html](https://16x.engineer/2022/10/18/chinese-tech-terms.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T18:06:47+00:00

<p>Article URL: <a href="https://16x.engineer/2022/10/18/chinese-tech-terms.html">https://16x.engineer/2022/10/18/chinese-tech-terms.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36563956">https://news.ycombinator.com/item?id=36563956</a></p>
<p>Points: 34</p>
<p># Comments: 3</p>

## Economic inequality cannot be explained by individual bad choices, study finds
 - [https://phys.org/news/2023-06-economic-inequality-individual-bad-choices.html](https://phys.org/news/2023-06-economic-inequality-individual-bad-choices.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T17:53:44+00:00

<p>Article URL: <a href="https://phys.org/news/2023-06-economic-inequality-individual-bad-choices.html">https://phys.org/news/2023-06-economic-inequality-individual-bad-choices.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36563815">https://news.ycombinator.com/item?id=36563815</a></p>
<p>Points: 54</p>
<p># Comments: 32</p>

## AMIGAlive – Play Amiga games online with people across the world
 - [https://www.amigalive.com/](https://www.amigalive.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T17:50:52+00:00

<p>Article URL: <a href="https://www.amigalive.com/">https://www.amigalive.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36563780">https://news.ycombinator.com/item?id=36563780</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## First 'tooth regrowth' medicine moves toward clinical trials in Japan
 - [https://mainichi.jp/english/articles/20230609/p2a/00m/0sc/026000c](https://mainichi.jp/english/articles/20230609/p2a/00m/0sc/026000c)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T17:33:17+00:00

<p>Article URL: <a href="https://mainichi.jp/english/articles/20230609/p2a/00m/0sc/026000c">https://mainichi.jp/english/articles/20230609/p2a/00m/0sc/026000c</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36563590">https://news.ycombinator.com/item?id=36563590</a></p>
<p>Points: 108</p>
<p># Comments: 16</p>

## HockeyStack (YC S23) Is Hiring Founding Engineers
 - [https://www.ycombinator.com/companies/hockeystack/jobs/JehKPk7-founding-backend-engineer](https://www.ycombinator.com/companies/hockeystack/jobs/JehKPk7-founding-backend-engineer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T17:00:08+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/hockeystack/jobs/JehKPk7-founding-backend-engineer">https://www.ycombinator.com/companies/hockeystack/jobs/JehKPk7-founding-backend-engineer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36563303">https://news.ycombinator.com/item?id=36563303</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Show HN: Script – A text editor for digitally interconnected documents
 - [https://www.use-script.com](https://www.use-script.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T16:57:37+00:00

<p>script is a text editor powering truly digital documents recently launched. Feel free to play with and share your feedback.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36563284">https://news.ycombinator.com/item?id=36563284</a></p>
<p>Points: 24</p>
<p># Comments: 7</p>

## Are You Sure You Want to Use MMAP in Your Database Management System?
 - [https://db.cs.cmu.edu/mmap-cidr2022/](https://db.cs.cmu.edu/mmap-cidr2022/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T16:48:00+00:00

<p>Article URL: <a href="https://db.cs.cmu.edu/mmap-cidr2022/">https://db.cs.cmu.edu/mmap-cidr2022/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36563187">https://news.ycombinator.com/item?id=36563187</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Tesla Gives New UK Owners a ‘Reacher’ Stick to Deal with Left-Hand Drive Cars
 - [https://www.carscoops.com/2023/06/tesla-seriously-gives-uk-owners-reacher-stick-after-cancelling-right-hand-drive-cars/](https://www.carscoops.com/2023/06/tesla-seriously-gives-uk-owners-reacher-stick-after-cancelling-right-hand-drive-cars/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T16:43:00+00:00

<p>Article URL: <a href="https://www.carscoops.com/2023/06/tesla-seriously-gives-uk-owners-reacher-stick-after-cancelling-right-hand-drive-cars/">https://www.carscoops.com/2023/06/tesla-seriously-gives-uk-owners-reacher-stick-after-cancelling-right-hand-drive-cars/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36563130">https://news.ycombinator.com/item?id=36563130</a></p>
<p>Points: 53</p>
<p># Comments: 38</p>

## Designing the First Apple Macintosh: The Engineers’ Story
 - [https://spectrum.ieee.org/apple-macintosh](https://spectrum.ieee.org/apple-macintosh)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T16:25:47+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/apple-macintosh">https://spectrum.ieee.org/apple-macintosh</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562958">https://news.ycombinator.com/item?id=36562958</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## What Do We Owe Our Teams?
 - [https://www.mironov.com/owe/](https://www.mironov.com/owe/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T16:15:54+00:00

<p>Article URL: <a href="https://www.mironov.com/owe/">https://www.mironov.com/owe/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562868">https://news.ycombinator.com/item?id=36562868</a></p>
<p>Points: 19</p>
<p># Comments: 2</p>

## Make Your Renders Unnecessarily Complicated by Modeling a Film Camera in Blender [video]
 - [https://www.youtube.com/watch?v=YE9rEQAGpLw](https://www.youtube.com/watch?v=YE9rEQAGpLw)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T16:03:59+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=YE9rEQAGpLw">https://www.youtube.com/watch?v=YE9rEQAGpLw</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562757">https://news.ycombinator.com/item?id=36562757</a></p>
<p>Points: 43</p>
<p># Comments: 6</p>

## Aspartame: Once More Unto the Breach
 - [https://dynomight.net/aspartame/](https://dynomight.net/aspartame/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T16:02:36+00:00

<p>Article URL: <a href="https://dynomight.net/aspartame/">https://dynomight.net/aspartame/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562739">https://news.ycombinator.com/item?id=36562739</a></p>
<p>Points: 44</p>
<p># Comments: 11</p>

## It's 2023 and memory overwrite bugs are not just a thing theyre still number one
 - [https://www.theregister.com/2023/06/29/cwe_top_25_2023/](https://www.theregister.com/2023/06/29/cwe_top_25_2023/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T16:01:41+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/06/29/cwe_top_25_2023/">https://www.theregister.com/2023/06/29/cwe_top_25_2023/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562727">https://news.ycombinator.com/item?id=36562727</a></p>
<p>Points: 35</p>
<p># Comments: 7</p>

## The Mysterious Airships of 1896-97 (2014)
 - [https://www.readex.com/blog/ufo-fever-americas-historical-newspapers-mysterious-airships-1896-97](https://www.readex.com/blog/ufo-fever-americas-historical-newspapers-mysterious-airships-1896-97)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T15:46:13+00:00

<p>Article URL: <a href="https://www.readex.com/blog/ufo-fever-americas-historical-newspapers-mysterious-airships-1896-97">https://www.readex.com/blog/ufo-fever-americas-historical-newspapers-mysterious-airships-1896-97</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562561">https://news.ycombinator.com/item?id=36562561</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## Stanford A.I. Courses
 - [https://ai.stanford.edu/courses/](https://ai.stanford.edu/courses/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T15:40:53+00:00

<p>Article URL: <a href="https://ai.stanford.edu/courses/">https://ai.stanford.edu/courses/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562502">https://news.ycombinator.com/item?id=36562502</a></p>
<p>Points: 94</p>
<p># Comments: 19</p>

## Embattled physicist files patent for unprecedented ambient superconductor
 - [https://www.science.org/content/article/embattled-physicist-files-patent-unprecedented-ambient-superconductor](https://www.science.org/content/article/embattled-physicist-files-patent-unprecedented-ambient-superconductor)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T15:36:09+00:00

<p>Article URL: <a href="https://www.science.org/content/article/embattled-physicist-files-patent-unprecedented-ambient-superconductor">https://www.science.org/content/article/embattled-physicist-files-patent-unprecedented-ambient-superconductor</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562433">https://news.ycombinator.com/item?id=36562433</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## A toy programming language in 137 lines of Python code
 - [https://blog.miguelgrinberg.com/post/building-a-toy-programming-language-in-python](https://blog.miguelgrinberg.com/post/building-a-toy-programming-language-in-python)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T15:36:04+00:00

<p>Article URL: <a href="https://blog.miguelgrinberg.com/post/building-a-toy-programming-language-in-python">https://blog.miguelgrinberg.com/post/building-a-toy-programming-language-in-python</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562432">https://news.ycombinator.com/item?id=36562432</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Cyclorotor
 - [https://en.wikipedia.org/wiki/Cyclorotor](https://en.wikipedia.org/wiki/Cyclorotor)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T15:01:54+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Cyclorotor">https://en.wikipedia.org/wiki/Cyclorotor</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36562056">https://news.ycombinator.com/item?id=36562056</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## My Meeting with David Bohm, Tormented Quantum Visionary
 - [https://johnhorgan.org/cross-check/my-meeting-with-david-bohm-tormented-quantum-visionary](https://johnhorgan.org/cross-check/my-meeting-with-david-bohm-tormented-quantum-visionary)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T14:52:43+00:00

<p>Article URL: <a href="https://johnhorgan.org/cross-check/my-meeting-with-david-bohm-tormented-quantum-visionary">https://johnhorgan.org/cross-check/my-meeting-with-david-bohm-tormented-quantum-visionary</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36561991">https://news.ycombinator.com/item?id=36561991</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Parsing time stamps faster with SIMD instructions
 - [https://lemire.me/blog/2023/07/01/parsing-time-stamps-faster-with-simd-instructions/](https://lemire.me/blog/2023/07/01/parsing-time-stamps-faster-with-simd-instructions/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T14:50:46+00:00

<p>Article URL: <a href="https://lemire.me/blog/2023/07/01/parsing-time-stamps-faster-with-simd-instructions/">https://lemire.me/blog/2023/07/01/parsing-time-stamps-faster-with-simd-instructions/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36561974">https://news.ycombinator.com/item?id=36561974</a></p>
<p>Points: 49</p>
<p># Comments: 15</p>

## A curated list of Emacs Lisp development resources
 - [https://github.com/p3r7/awesome-elisp](https://github.com/p3r7/awesome-elisp)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T14:41:32+00:00

<p>Article URL: <a href="https://github.com/p3r7/awesome-elisp">https://github.com/p3r7/awesome-elisp</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36561897">https://news.ycombinator.com/item?id=36561897</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Show HN: bigwav.app – Transcription and Annotation using just a web browser
 - [https://bigwav.app](https://bigwav.app)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T14:37:29+00:00

<p>Hello,<p>I released this recently, take a look:<p><a href="https://bigwav.app" rel="nofollow noreferrer">https://bigwav.app</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36561867">https://news.ycombinator.com/item?id=36561867</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Alt-F4 #65 – Factorio visualizer in Unreal Engine 5
 - [https://alt-f4.blog/ALTF4-65/](https://alt-f4.blog/ALTF4-65/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T14:34:58+00:00

<p>Article URL: <a href="https://alt-f4.blog/ALTF4-65/">https://alt-f4.blog/ALTF4-65/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36561847">https://news.ycombinator.com/item?id=36561847</a></p>
<p>Points: 81</p>
<p># Comments: 14</p>

## Before Xerox, there was Addressograph
 - [https://pncnmnp.github.io/blogs/addressograph.html](https://pncnmnp.github.io/blogs/addressograph.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T14:32:04+00:00

<p>Article URL: <a href="https://pncnmnp.github.io/blogs/addressograph.html">https://pncnmnp.github.io/blogs/addressograph.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36561827">https://news.ycombinator.com/item?id=36561827</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## /u/spez is right about feudalism and that's why Reddit as we know it is doomed
 - [https://maya.land/monologues/2023/07/01/spez-feudalism-reddit.html](https://maya.land/monologues/2023/07/01/spez-feudalism-reddit.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T13:11:26+00:00

<p>Article URL: <a href="https://maya.land/monologues/2023/07/01/spez-feudalism-reddit.html">https://maya.land/monologues/2023/07/01/spez-feudalism-reddit.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36561166">https://news.ycombinator.com/item?id=36561166</a></p>
<p>Points: 50</p>
<p># Comments: 35</p>

## Google Sidewiki
 - [https://en.wikipedia.org/wiki/Google_Sidewiki](https://en.wikipedia.org/wiki/Google_Sidewiki)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T12:41:27+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Google_Sidewiki">https://en.wikipedia.org/wiki/Google_Sidewiki</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36560937">https://news.ycombinator.com/item?id=36560937</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Scope-based resource management for the Linux kernel
 - [https://lwn.net/Articles/934679/](https://lwn.net/Articles/934679/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T12:26:08+00:00

<p>Article URL: <a href="https://lwn.net/Articles/934679/">https://lwn.net/Articles/934679/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36560830">https://news.ycombinator.com/item?id=36560830</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Delve: A Solo Map Drawing Game
 - [https://blackwellwriter.itch.io/delve-a-solo-map-drawing-game](https://blackwellwriter.itch.io/delve-a-solo-map-drawing-game)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T12:24:15+00:00

<p>Article URL: <a href="https://blackwellwriter.itch.io/delve-a-solo-map-drawing-game">https://blackwellwriter.itch.io/delve-a-solo-map-drawing-game</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36560815">https://news.ycombinator.com/item?id=36560815</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## Bonilla hasn’t played for over 20 years. NY Mets pay him $1.2M a year until 2035
 - [https://www.cnn.com/2020/07/01/us/bobby-bonilla-day-mets-mlb-spt-trnd/index.html](https://www.cnn.com/2020/07/01/us/bobby-bonilla-day-mets-mlb-spt-trnd/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T11:07:36+00:00

<p>Article URL: <a href="https://www.cnn.com/2020/07/01/us/bobby-bonilla-day-mets-mlb-spt-trnd/index.html">https://www.cnn.com/2020/07/01/us/bobby-bonilla-day-mets-mlb-spt-trnd/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36560310">https://news.ycombinator.com/item?id=36560310</a></p>
<p>Points: 12</p>
<p># Comments: 7</p>

## Writing as a Form of Thinking
 - [https://lopespm.com/notes/2023/07/02/writing-as-a-form-of-thinking.html](https://lopespm.com/notes/2023/07/02/writing-as-a-form-of-thinking.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T10:56:43+00:00

<p>Article URL: <a href="https://lopespm.com/notes/2023/07/02/writing-as-a-form-of-thinking.html">https://lopespm.com/notes/2023/07/02/writing-as-a-form-of-thinking.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36560254">https://news.ycombinator.com/item?id=36560254</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Windows 10 on the Xiaomi PocoPhone F1
 - [https://virtuallyfun.com/2023/07/01/64bit-computing-on-a-budget/](https://virtuallyfun.com/2023/07/01/64bit-computing-on-a-budget/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T10:54:46+00:00

<p>Article URL: <a href="https://virtuallyfun.com/2023/07/01/64bit-computing-on-a-budget/">https://virtuallyfun.com/2023/07/01/64bit-computing-on-a-budget/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36560242">https://news.ycombinator.com/item?id=36560242</a></p>
<p>Points: 23</p>
<p># Comments: 2</p>

## Drastic increase in Tor clients from Germany
 - [https://metrics.torproject.org/userstats-relay-country.html?start=2019-01-01&end=2023-07-02&country=de&events=off](https://metrics.torproject.org/userstats-relay-country.html?start=2019-01-01&end=2023-07-02&country=de&events=off)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T10:29:55+00:00

<p>Article URL: <a href="https://metrics.torproject.org/userstats-relay-country.html?start=2019-01-01&amp;end=2023-07-02&amp;country=de&amp;events=off">https://metrics.torproject.org/userstats-relay-country.html?start=2019-01-01&amp;end=2023-07-02&amp;country=de&amp;events=off</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36560136">https://news.ycombinator.com/item?id=36560136</a></p>
<p>Points: 63</p>
<p># Comments: 44</p>

## Wayland on NixOS: Confusion, Conquest, Triumph
 - [https://drakerossman.com/blog/wayland-on-nixos-confusion-conquest-triumph](https://drakerossman.com/blog/wayland-on-nixos-confusion-conquest-triumph)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T09:48:02+00:00

<p>Article URL: <a href="https://drakerossman.com/blog/wayland-on-nixos-confusion-conquest-triumph">https://drakerossman.com/blog/wayland-on-nixos-confusion-conquest-triumph</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36559929">https://news.ycombinator.com/item?id=36559929</a></p>
<p>Points: 8</p>
<p># Comments: 7</p>

## Moneyball for Software Teams: Quantifying Dev Performance
 - [https://software.rajivprab.com/2023/07/01/moneyball-for-software-teams/](https://software.rajivprab.com/2023/07/01/moneyball-for-software-teams/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T08:53:29+00:00

<p>Article URL: <a href="https://software.rajivprab.com/2023/07/01/moneyball-for-software-teams/">https://software.rajivprab.com/2023/07/01/moneyball-for-software-teams/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36559630">https://news.ycombinator.com/item?id=36559630</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Neuronal wiring diagram of an adult brain
 - [https://www.biorxiv.org/content/10.1101/2023.06.27.546656v1](https://www.biorxiv.org/content/10.1101/2023.06.27.546656v1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T08:07:15+00:00

<p>Article URL: <a href="https://www.biorxiv.org/content/10.1101/2023.06.27.546656v1">https://www.biorxiv.org/content/10.1101/2023.06.27.546656v1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36559370">https://news.ycombinator.com/item?id=36559370</a></p>
<p>Points: 6</p>
<p># Comments: 3</p>

## Flattening ASTs (and Other Compiler Data Structures)
 - [https://www.cs.cornell.edu/~asampson/blog/flattening.html](https://www.cs.cornell.edu/~asampson/blog/flattening.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T08:03:13+00:00

<p>Article URL: <a href="https://www.cs.cornell.edu/~asampson/blog/flattening.html">https://www.cs.cornell.edu/~asampson/blog/flattening.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36559346">https://news.ycombinator.com/item?id=36559346</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Breaking Up with SVG-in-JS in 2023
 - [https://kurtextrem.de/posts/svg-in-js](https://kurtextrem.de/posts/svg-in-js)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T07:45:04+00:00

<p>Article URL: <a href="https://kurtextrem.de/posts/svg-in-js">https://kurtextrem.de/posts/svg-in-js</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36559254">https://news.ycombinator.com/item?id=36559254</a></p>
<p>Points: 16</p>
<p># Comments: 10</p>

## UK retail electricity prices hit -19p/kWh today
 - [https://github.com/jonatron/randomstuff/blob/main/agile_prices.png](https://github.com/jonatron/randomstuff/blob/main/agile_prices.png)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T07:31:55+00:00

<p>Article URL: <a href="https://github.com/jonatron/randomstuff/blob/main/agile_prices.png">https://github.com/jonatron/randomstuff/blob/main/agile_prices.png</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36559165">https://news.ycombinator.com/item?id=36559165</a></p>
<p>Points: 18</p>
<p># Comments: 18</p>

## The Mickey Mouse Copyright Runs Out in 2024 – What That Means for All of Us
 - [https://globaltoynews.com/2023/01/11/the-mickey-mouse-copyright-runs-out-in-2024-what-that-means-for-all-of-us/](https://globaltoynews.com/2023/01/11/the-mickey-mouse-copyright-runs-out-in-2024-what-that-means-for-all-of-us/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T07:06:21+00:00

<p>Article URL: <a href="https://globaltoynews.com/2023/01/11/the-mickey-mouse-copyright-runs-out-in-2024-what-that-means-for-all-of-us/">https://globaltoynews.com/2023/01/11/the-mickey-mouse-copyright-runs-out-in-2024-what-that-means-for-all-of-us/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36559037">https://news.ycombinator.com/item?id=36559037</a></p>
<p>Points: 10</p>
<p># Comments: 5</p>

## Tree-Structured Concurrency
 - [https://blog.yoshuawuyts.com/tree-structured-concurrency/](https://blog.yoshuawuyts.com/tree-structured-concurrency/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T07:04:25+00:00

<p>Article URL: <a href="https://blog.yoshuawuyts.com/tree-structured-concurrency/">https://blog.yoshuawuyts.com/tree-structured-concurrency/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36559030">https://news.ycombinator.com/item?id=36559030</a></p>
<p>Points: 19</p>
<p># Comments: 0</p>

## Ask HN: Why aren't modern programming languages, like Rust, more legible?
 - [https://news.ycombinator.com/item?id=36558794](https://news.ycombinator.com/item?id=36558794)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T06:21:05+00:00

<p>This is a question I've often wondered, and am perhaps asking now out of sheer frustration. I have ADHD, of which my particular 'mutation' of ADHD makes it difficult to read and absorb written text.<p>I'm not afraid of programming in general, being a data analyst by trade I often use Python and SQL in my day job. I've trained on Java, and C# (though admittedly with some difficulty) and had dabbled in Delphi (Object Pascal) and Visual Basic as a little girl so the concept of programming isn't new to me. Perhaps the 'low-level-nes' of Rust, a language I would love to learn, is new to me which is perhaps one of the reasons I'm having some trouble understanding it.<p>I'm struggling with heavy implementations of symbols, and perhaps 'shorthand' reserved keywords in languages like Rust, C++ and to some extent JavaScript; I find they aren't as readable as 'higher level' languages like Python.<p>Given that Rust is one of the newer languages on the block, Python is 21 years it's senior, was the syntax of Rust determined by performance factors or because of it's 'low-level-ness'? Are languages like Python and SQL more legible because they're interpreted and compiled into bytecode, rather than just compiled into specific machine code? Or is it purely a decision of the language's developer?<p>This question is focused on Rust specifically, given that's a newer language, perhaps wondering why it didn't adopt some of the design principles of easier to read languages, though I am certainly not singling it out. Are there ADHD friendly tutorials/books on Rust?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36558794">https://news.ycombinator.com/item?id=36558794</a></p>
<p>Points: 24</p>
<p># Comments: 19</p>

## Course Notes: A Functional Introduction to Computer Science (UWaterloo)
 - [https://cs.uwaterloo.ca/~plragde/flaneries/FICS/](https://cs.uwaterloo.ca/~plragde/flaneries/FICS/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T06:14:31+00:00

<p>Article URL: <a href="https://cs.uwaterloo.ca/~plragde/flaneries/FICS/">https://cs.uwaterloo.ca/~plragde/flaneries/FICS/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36558759">https://news.ycombinator.com/item?id=36558759</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Why do Ivy League students self-sabotage?
 - [https://movingthelimit.com/why-do-ivy-league-students-self-sabotage/](https://movingthelimit.com/why-do-ivy-league-students-self-sabotage/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T05:10:03+00:00

<p>Article URL: <a href="https://movingthelimit.com/why-do-ivy-league-students-self-sabotage/">https://movingthelimit.com/why-do-ivy-league-students-self-sabotage/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36558428">https://news.ycombinator.com/item?id=36558428</a></p>
<p>Points: 67</p>
<p># Comments: 57</p>

## GPT-Migrate converts repos from one lang/framework to another
 - [https://github.com/0xpayne/gpt-migrate](https://github.com/0xpayne/gpt-migrate)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T03:46:33+00:00

<p>Article URL: <a href="https://github.com/0xpayne/gpt-migrate">https://github.com/0xpayne/gpt-migrate</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36558032">https://news.ycombinator.com/item?id=36558032</a></p>
<p>Points: 41</p>
<p># Comments: 14</p>

## Safe Enough?
 - [https://astralcodexten.substack.com/p/your-book-review-safe-enough](https://astralcodexten.substack.com/p/your-book-review-safe-enough)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T03:05:19+00:00

<p>Article URL: <a href="https://astralcodexten.substack.com/p/your-book-review-safe-enough">https://astralcodexten.substack.com/p/your-book-review-safe-enough</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36557819">https://news.ycombinator.com/item?id=36557819</a></p>
<p>Points: 39</p>
<p># Comments: 4</p>

## The moral behavior of ethics professors: A replication-extension
 - [https://www.tandfonline.com/doi/full/10.1080/09515089.2019.1587912](https://www.tandfonline.com/doi/full/10.1080/09515089.2019.1587912)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T03:01:24+00:00

<p>Article URL: <a href="https://www.tandfonline.com/doi/full/10.1080/09515089.2019.1587912">https://www.tandfonline.com/doi/full/10.1080/09515089.2019.1587912</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36557790">https://news.ycombinator.com/item?id=36557790</a></p>
<p>Points: 17</p>
<p># Comments: 11</p>

## Salary Negotiation: Make More Money, Be More Valued
 - [https://www.kalzumeus.com/2012/01/23/salary-negotiation/](https://www.kalzumeus.com/2012/01/23/salary-negotiation/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T02:44:18+00:00

<p>Article URL: <a href="https://www.kalzumeus.com/2012/01/23/salary-negotiation/">https://www.kalzumeus.com/2012/01/23/salary-negotiation/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36557679">https://news.ycombinator.com/item?id=36557679</a></p>
<p>Points: 34</p>
<p># Comments: 3</p>

## A Look at Bluesky
 - [https://juliette.page/blog/bluesky.html](https://juliette.page/blog/bluesky.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T01:50:34+00:00

<p>Article URL: <a href="https://juliette.page/blog/bluesky.html">https://juliette.page/blog/bluesky.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36557378">https://news.ycombinator.com/item?id=36557378</a></p>
<p>Points: 38</p>
<p># Comments: 10</p>

## After September 1, 2023, all Gfycat content and data will be deleted
 - [https://gfycat.com/](https://gfycat.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T01:34:55+00:00

<p>Article URL: <a href="https://gfycat.com/">https://gfycat.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36557287">https://news.ycombinator.com/item?id=36557287</a></p>
<p>Points: 104</p>
<p># Comments: 27</p>

## China Has $3T of ‘Hidden’ Currency Reserves, Setser Says
 - [https://www.bloomberg.com/news/articles/2023-06-30/china-has-3-trillion-of-hidden-currency-reserves-setser-says](https://www.bloomberg.com/news/articles/2023-06-30/china-has-3-trillion-of-hidden-currency-reserves-setser-says)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T01:07:32+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-06-30/china-has-3-trillion-of-hidden-currency-reserves-setser-says">https://www.bloomberg.com/news/articles/2023-06-30/china-has-3-trillion-of-hidden-currency-reserves-setser-says</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36557122">https://news.ycombinator.com/item?id=36557122</a></p>
<p>Points: 79</p>
<p># Comments: 73</p>

## Intro to Cryptography [pdf] (2011)
 - [https://www.cs.umd.edu/~waa/414-F11/IntroToCrypto.pdf](https://www.cs.umd.edu/~waa/414-F11/IntroToCrypto.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T01:02:00+00:00

<p>Article URL: <a href="https://www.cs.umd.edu/~waa/414-F11/IntroToCrypto.pdf">https://www.cs.umd.edu/~waa/414-F11/IntroToCrypto.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36557077">https://news.ycombinator.com/item?id=36557077</a></p>
<p>Points: 65</p>
<p># Comments: 22</p>

## Oregon County Sues BP, Chevron, Shell, Exxon for $51B Climate Damages
 - [https://carboncredits.com/oregon-county-sues-oil-companies-shell-bp-exxon-chevron-for-51b-climate-damages/](https://carboncredits.com/oregon-county-sues-oil-companies-shell-bp-exxon-chevron-for-51b-climate-damages/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T00:28:03+00:00

<p>Article URL: <a href="https://carboncredits.com/oregon-county-sues-oil-companies-shell-bp-exxon-chevron-for-51b-climate-damages/">https://carboncredits.com/oregon-county-sues-oil-companies-shell-bp-exxon-chevron-for-51b-climate-damages/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36556844">https://news.ycombinator.com/item?id=36556844</a></p>
<p>Points: 89</p>
<p># Comments: 51</p>

## Using WebAssembly to turn Rust crates into fast TypeScript libraries
 - [https://rybicki.io/blog/2023/06/27/rust-crate-into-typescript-library.html](https://rybicki.io/blog/2023/06/27/rust-crate-into-typescript-library.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-02T00:03:53+00:00

<p>Article URL: <a href="https://rybicki.io/blog/2023/06/27/rust-crate-into-typescript-library.html">https://rybicki.io/blog/2023/06/27/rust-crate-into-typescript-library.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36556668">https://news.ycombinator.com/item?id=36556668</a></p>
<p>Points: 55</p>
<p># Comments: 12</p>

