# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## School's tribute after two teenagers die on Greek island of Ios
 - [https://news.sky.com/story/schools-tribute-after-two-irish-teenagers-die-on-greek-island-of-ios-12913686](https://news.sky.com/story/schools-tribute-after-two-irish-teenagers-die-on-greek-island-of-ios-12913686)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-02T18:44:00+00:00

Two teenage boys have died on the Greek island of Ios.

## 'More people than ever before' using fake passports and visas to get to UK
 - [https://news.sky.com/story/more-people-than-ever-before-using-fake-passports-and-visas-to-get-to-uk-iranian-asylum-seeker-says-12913614](https://news.sky.com/story/more-people-than-ever-before-using-fake-passports-and-visas-to-get-to-uk-iranian-asylum-seeker-says-12913614)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-02T16:30:00+00:00

More people from Iran than ever before are using fake passports or fake visas to get to the UK, an Iranian asylum seeker has told Sky News.

## The 'double discrimination' fuelling riots and widespread looting in France's second city
 - [https://news.sky.com/story/france-riots-the-double-discrimination-fuelling-and-widespread-looting-and-vandalism-12913545](https://news.sky.com/story/france-riots-the-double-discrimination-fuelling-and-widespread-looting-and-vandalism-12913545)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-02T15:08:00+00:00

Anger, resentment, grief - that is the message from Marseille.

## Grandmother of teenager shot by police in France calls on rioters to stop
 - [https://news.sky.com/story/france-riots-nahel-merzouks-grandmother-calls-for-rioters-to-stop-as-protests-continue-12913509](https://news.sky.com/story/france-riots-nahel-merzouks-grandmother-calls-for-rioters-to-stop-as-protests-continue-12913509)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-02T14:31:00+00:00

The grandmother of the French teenager shot by police has called for rioters to "stop" and says her "heart is in pain".

## 'We love each other': Mayor marries alligator-like reptile who he calls 'princess girl'
 - [https://news.sky.com/story/mexico-mayor-marries-alligator-like-reptile-who-he-calls-princess-girl-12913277](https://news.sky.com/story/mexico-mayor-marries-alligator-like-reptile-who-he-calls-princess-girl-12913277)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-02T07:27:00+00:00

A mayor in Mexico has married a female alligator-like animal in a traditional ceremony which is believed to bring good fortune to his people.

## At least two people killed and three critically injured in Baltimore shooting
 - [https://news.sky.com/story/at-least-two-killed-and-three-critically-injured-in-baltimore-shooting-12913243](https://news.sky.com/story/at-least-two-killed-and-three-critically-injured-in-baltimore-shooting-12913243)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-02T05:50:00+00:00

At least two people have been killed and three others have been critically injured after a mass shooting in Baltimore overnight.

## 'Putin's mistakes' giving US 'once-in-a-generation' chance to recruit Russian spies, says CIA director
 - [https://news.sky.com/story/putins-mistakes-giving-us-once-in-a-generation-chance-to-recruit-russian-spies-says-cia-director-12913242](https://news.sky.com/story/putins-mistakes-giving-us-once-in-a-generation-chance-to-recruit-russian-spies-says-cia-director-12913242)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-02T05:25:00+00:00

Dissatisfaction over Vladimir Putin's war in Ukraine, underlined by Wagner boss Yevgeny Prigozhin's armed mutiny, has created a "once-in-a-generation" opportunity for the US to recruit spies, the director of the CIA has said.

