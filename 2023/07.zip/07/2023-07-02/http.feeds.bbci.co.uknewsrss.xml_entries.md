# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Energy prices might spike this winter - IEA boss
 - [https://www.bbc.co.uk/news/business-66061853?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66061853?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T22:59:36+00:00

Governments may need to step in again and subsidise energy bills this winter says IEA boss.

## Wimbledon 2023: Brain games and conscious breathing - the secrets of Djokovic’s success
 - [https://www.bbc.co.uk/sport/tennis/66077815?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/66077815?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T22:31:40+00:00

Novak Djokovic is famous for his dedication and meticulous preparation, but he may let some of his strict routines slip as he tries to defend his Wimbledon title.

## Nick Kyrgios: Australian withdraws from Wimbledon 2023 with wrist injury
 - [https://www.bbc.co.uk/sport/tennis/66083104?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/66083104?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T22:11:39+00:00

Last year's men's singles runner-up Nick Kyrgios withdraws from Wimbledon 2023 with a wrist injury.

## Baltimore shooting: Two dead and 28 injured in mass casualty event, police say
 - [https://www.bbc.co.uk/news/world-us-canada-66079407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66079407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T21:36:14+00:00

More than a dozen of the injured were under 18, a senior city official said, as suspects remain at large.

## Wimbledon 2023: Djokovic, Swiatek, Williams in action - day one preview
 - [https://www.bbc.co.uk/sport/tennis/66075300?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/66075300?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T21:22:33+00:00

Novak Djokovic will open proceedings on Centre Court when Wimbledon 2023 gets under way on Monday.

## Neita beats Asher-Smith in Stockholm, protesters hit Warholm's race
 - [https://www.bbc.co.uk/sport/athletics/66080008?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/66080008?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T19:04:33+00:00

Daryll Neita wins the women's 200m ahead of fellow Briton Dina Asher-Smith at a rainy Diamond League meeting in Stockholm.

## The false French riot posts spreading online
 - [https://www.bbc.co.uk/news/world-europe-66081671?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66081671?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T19:03:56+00:00

A number of false and misleading claims about the French riots have been circulating on social media.

## Watch: Mexican mayor weds crocodile in harvest ritual
 - [https://www.bbc.co.uk/news/world-66082749?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-66082749?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T17:41:02+00:00

The ceremony is part of an age-old ritual in which the reptile represents mother earth.

## Joe Biden to meet King Charles and Rishi Sunak in UK visit
 - [https://www.bbc.co.uk/news/uk-66081123?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66081123?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T17:30:18+00:00

US President Joe Biden will meet King Charles at Windsor Castle on 10 July.

## The Ashes 2023: Ben Stokes says he would have withdrawn the appeal of Jonny Bairstow dismissal
 - [https://www.bbc.co.uk/sport/cricket/66082091?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/66082091?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T16:54:00+00:00

England captain Ben Stokes says he would not want to win with such a contentious dismissal as Jonny Bairstow's in the second Ashes Test.

## France teen's family tell BBC police use of lethal force must change
 - [https://www.bbc.co.uk/news/world-europe-66080505?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66080505?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T16:50:30+00:00

One of Nahel's relatives says the riots do not honour Nahel's death, and the family want them to stop.

## Jess Phillips not racist, Labour frontbencher says amid online row
 - [https://www.bbc.co.uk/news/uk-politics-66081242?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66081242?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T16:38:41+00:00

A senior headteacher accused Ms Phillips of racism and bullying following a Twitter row.

## The Ashes 2023: MCC apologises after Australia 'abused' by members in Long Room at Lord's
 - [https://www.bbc.co.uk/sport/cricket/66082409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/66082409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T16:32:40+00:00

The MCC apologises after exchanges between its members and the Australian team in the Long Room at Lord's.

## The Ashes: England v Australia - second Test, day five highlights
 - [https://www.bbc.co.uk/sport/av/cricket/66080466?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/66080466?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T15:56:39+00:00

Ben Stokes' brilliant 155 is not enough to carry England to a second-Test victory over Australia at Lord's in one of the most incredible and controversial finishes in the history of the game.

## Tour de France: Victor Lafay wins stage two as Adam Yates retains yellow jersey
 - [https://www.bbc.co.uk/sport/cycling/66082116?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/66082116?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T15:34:27+00:00

Frenchman Victor Lafay produces a terrific late attack to claim victory on the second stage of the Tour de France.

## Dominik Szoboszlai: Liverpool sign RB Leipzig midfielder for £60m
 - [https://www.bbc.co.uk/sport/football/66079379?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66079379?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T15:32:31+00:00

Liverpool sign RB Leipzig midfielder Dominik Szoboszlai for 70m euros (£60m), making the Hungary international their second major summer acquisition.

## The Ashes: Staggering Stokes century not enough to deny Australia
 - [https://www.bbc.co.uk/sport/cricket/66080512?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/66080512?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T15:20:28+00:00

Yet another sublime century from Ben Stokes cannot prevent Australia beating England at Lord's in one of the most incredible and controversial finishes ever.

## The Ashes: Watch all Ben Stokes' sixes for England as he falls on 155
 - [https://www.bbc.co.uk/sport/av/cricket/66081292?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/66081292?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T14:56:52+00:00

Watch all nine sixes hit by England captain Ben Stokes during a magnificent 155 during the second Ashes Test match at Lord's.

## Water cremation: Co-op Funeralcare to be first UK company to offer resomation
 - [https://www.bbc.co.uk/news/uk-66081058?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66081058?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T14:46:16+00:00

The process, used in the US and Canada, will be available later this year through Co-op Funeralcare.

## Wimbledon 2023: Novak Djokovic, Andy Murray, Elena Rybakina, Katie Boulter among stars
 - [https://www.bbc.co.uk/sport/tennis/66058784?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/66058784?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T14:35:09+00:00

With Wimbledon starting on Monday, BBC Sport looks at the key themes going into one of the highlights of the British sporting summer.

## Austrian Grand Prix: Max Verstappen takes fifth win in row for Red Bull
 - [https://www.bbc.co.uk/sport/formula1/66081048?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/66081048?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T14:34:58+00:00

Red Bull's Max Verstappen continues his imperious march towards a third world title with a dominant victory in the Austrian Grand Prix.

## Emmerdale and Coronation Street actress Meg Johnson dies
 - [https://www.bbc.co.uk/news/uk-england-manchester-66080549?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-66080549?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T13:17:22+00:00

The soap stalwart, who appeared in Coronation Street, Emmerdale and Brookside, has died aged 86.

## The Ashes: England captain Ben Stokes is dropped by Steve Smith on 114
 - [https://www.bbc.co.uk/sport/av/cricket/66081289?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/66081289?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T13:14:23+00:00

England captain Ben Stokes is dropped on 114 by Australia's Steve Smith on a thrilling day five of the second Ashes Test at Lord's.

## Cambridge flat fire: 'Nothing ruled out' in investigation
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-66080921?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-66080921?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T13:01:54+00:00

A man remains in a critical condition after a woman and two children died in a fire in Cambridge.

## Zulu King Misuzulu kaZwelithini treated for suspected poisoning - aide
 - [https://www.bbc.co.uk/news/world-africa-66079600?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-66079600?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T12:59:05+00:00

The king has sought treatment in Eswatini as he is uncomfortable being treated in South Africa.

## Austrian Grand Prix 2023: McLaren's Lando Norris safety car appeal rejected
 - [https://www.bbc.co.uk/sport/formula1/66075181?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/66075181?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T12:39:33+00:00

McLaren's request for a right to review Lando Norris' five-second penalty at the Canadian Grand Prix is rejected.

## Ashes: Ben Stokes hits three sixes in a row to reach 100
 - [https://www.bbc.co.uk/sport/av/cricket/66080464?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/66080464?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T12:34:37+00:00

England captain Ben Stokes hits three sixes to bring up a century against Australia on day five of the second Test at Lord's.

## The Ashes: England's Jonny Bairstow is run out by Alex Carey
 - [https://www.bbc.co.uk/sport/av/cricket/66080677?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/66080677?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T12:03:49+00:00

England's Jonny Bairstow is controversially run out by Australia's wicket-keeper Alex Carey on day five of the second Test at Lord's.

## Paris riots: Suburban mayor's wife hurt as rioters attack their home
 - [https://www.bbc.co.uk/news/world-europe-66079408?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66079408?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T11:57:56+00:00

Attackers tried to set the house on fire before firing rockets at the mayor's fleeing wife and children.

## Wagner: Russians reflect on group's advance towards Moscow
 - [https://www.bbc.co.uk/news/world-europe-66080682?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66080682?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T11:46:23+00:00

Russians have told the BBC they feared Wagner could unleash the violent tactics it uses in Ukraine on them.

## The Ashes: Australia's Josh Hazlewood removes England's Ben Duckett for 83
 - [https://www.bbc.co.uk/sport/av/cricket/66080673?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/66080673?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T11:35:30+00:00

England opener Ben Duckett is caught behind off the bowling of Australia's Josh Hazlewood for 83 on day five of the second Test at Lord's.

## London Pride: Five Just Stop Oil protesters charged
 - [https://www.bbc.co.uk/news/uk-england-london-66080222?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-66080222?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T11:34:46+00:00

Police removed protesters who briefly disrupted the annual Pride parade.

## The Ashes: Ben Stokes survives after LBW review at Lord's
 - [https://www.bbc.co.uk/sport/av/cricket/66080472?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/66080472?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T10:50:13+00:00

England captain Ben Stokes survives following a review after initially being given out LBW to Mitchell Starc on 39.

## Big Thames Water investor backs turnaround plans
 - [https://www.bbc.co.uk/news/business-66079676?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66079676?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T10:47:52+00:00

One of the UK's largest pension funds is the first investor to come out and support Thames Water.

## Lord Bob Kerslake: Former Civil Service head dies aged 68
 - [https://www.bbc.co.uk/news/uk-politics-66080174?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66080174?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T10:41:51+00:00

He was Cabinet Secretary between 2012 and 2014 during David Cameron's coalition government.

## Spilled milk closes the M6 motorway after tanker crash
 - [https://www.bbc.co.uk/news/uk-england-lancashire-66080113?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-66080113?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T10:31:13+00:00

The M6 near Preston could be closed for most of the day after milk spilled onto both carriageways.

## NHS England chief Amanda Pritchard says strike disruption will get worse
 - [https://www.bbc.co.uk/news/uk-66079976?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66079976?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T10:28:28+00:00

Amanda Pritchard told the BBC that "all sides" had failed to prevent further strike action.

## English Greyhound Derby: Racing disruption attempt sees 13 arrests
 - [https://www.bbc.co.uk/news/uk-england-northamptonshire-66080029?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-northamptonshire-66080029?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T10:22:10+00:00

Thirteen people were arrested over an attempt to disrupt the English Greyhound Derby, police say.

## Protests: Police powers to tackle tactics come into effect
 - [https://www.bbc.co.uk/news/uk-66079436?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66079436?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T09:38:47+00:00

Transport network disruption and tunnelling targeted under measures for police in England and Wales.

## Orkney council to look at proposals to become territory of Norway
 - [https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-66066448?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-66066448?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T08:36:19+00:00

The islands' councillors will consider a motion to investigate alternative forms of governance.

## Stephen Lawrence murder: Friend 'could have identified sixth suspect'
 - [https://www.bbc.co.uk/news/uk-66078894?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66078894?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T07:29:52+00:00

Duwayne Brooks, who witnessed the murder, says he could have picked a sixth suspect from a line-up.

## France shooting: Calmer night despite protests over Nahel M's murder, minister says
 - [https://www.bbc.co.uk/news/world-europe-66078723?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66078723?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T06:43:30+00:00

A total of 719 people were arrested as disturbances gripped Marseille and other cities with Paris quieter.

## Labour plan to give new teachers £2,400 to stay in job
 - [https://www.bbc.co.uk/news/uk-politics-66078820?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66078820?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T05:17:43+00:00

The party would also make it compulsory for new joiners to have a formal teaching qualification.

## Ukraine finds British WW2 Hurricane planes outside Kyiv
 - [https://www.bbc.co.uk/news/world-europe-65955365?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65955365?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T05:00:09+00:00

London sent the Hawker Hurricanes to the Soviet Union to help them fight against Nazi Germany.

## The Papers: Asbestos in schools and George's pizza at Lord's
 - [https://www.bbc.co.uk/news/blogs-the-papers-66078631?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-66078631?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T04:59:18+00:00

No one story dominates Sunday's papers, but many carry photos of Prince George eating pizza at the Ashes.

## Rail disruption warning due to six-day train drivers' overtime ban
 - [https://www.bbc.co.uk/news/business-66059122?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66059122?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T01:28:12+00:00

Sixteen train companies based in England will be hit from Monday until Saturday next week.

## More gambling clinics set up after record demand
 - [https://www.bbc.co.uk/news/health-66076015?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-66076015?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T01:07:33+00:00

Seven new addiction centres are opening in England over fears people are being "bombarded" with adverts.

## Manchester Collective: Award-winning group a mission to shake up classical music
 - [https://www.bbc.co.uk/news/entertainment-arts-65988406?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65988406?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T00:54:25+00:00

Manchester Collective are "transforming all our perceptions" of performance, one award's judges said.

## Prince Harry, Piers Morgan and hacking: What did the bosses know?
 - [https://www.bbc.co.uk/news/uk-66055386?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66055386?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-02T00:52:00+00:00

Did knowledge of phone hacking by Mirror Group Newspapers journalists go right to the top?

