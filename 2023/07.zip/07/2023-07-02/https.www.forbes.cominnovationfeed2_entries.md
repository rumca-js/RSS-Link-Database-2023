# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## ‘Buck Supermoon’ And Venus At Brilliant Best: The Night Sky This Week
 - [https://www.forbes.com/sites/jamiecartereurope/2023/07/02/buck-supermoon-and-venus-at-brilliant-best-the-night-sky-this-week/](https://www.forbes.com/sites/jamiecartereurope/2023/07/02/buck-supermoon-and-venus-at-brilliant-best-the-night-sky-this-week/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T23:15:00+00:00

The stargazing highlights for the week ahead include a larger-than-average full moon shining and Venus at peak brilliance.

## New Apple Leaks Reveal Disappointing MacBook Pro Delay
 - [https://www.forbes.com/sites/ewanspence/2023/07/02/apple-macbook-pro-m3-leak-macbook-air-m3-specs-release-date/](https://www.forbes.com/sites/ewanspence/2023/07/02/apple-macbook-pro-m3-leak-macbook-air-m3-specs-release-date/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T21:42:37+00:00

The latest MacBook Pro leaks reveal a curious choice from Tim Cook's team, and some disappointing news for those looking for a new macOS laptop.

## Apple AirPods Pro: Awesome Upgrade Coming, Insider Claims
 - [https://www.forbes.com/sites/davidphelan/2023/07/02/apple-airpods-pro-2023-awesome-upgrade-coming-insider-claims/](https://www.forbes.com/sites/davidphelan/2023/07/02/apple-airpods-pro-2023-awesome-upgrade-coming-insider-claims/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T21:38:09+00:00

New features coming to Apple’s in-ears could be stunning, according to a new report.

## ‘The Walking Dead: Dead City’ Episode 3 Review — Okay, You Have My Attention
 - [https://www.forbes.com/sites/erikkain/2023/07/02/the-walking-dead-dead-city-episode-3-review---okay-you-have-my-attention/](https://www.forbes.com/sites/erikkain/2023/07/02/the-walking-dead-dead-city-episode-3-review---okay-you-have-my-attention/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T20:54:11+00:00

Thanks in no small part to Negan, The Walking Dead: Dead City has my interest.

## ‘The Witcher’ Geralt’s Gold Beer Review: A Tasty Brew With A Twist
 - [https://www.forbes.com/sites/erikkain/2023/07/02/the-witcher-geralts-gold-beer-review-a-tasty-brew-with-a-twist/](https://www.forbes.com/sites/erikkain/2023/07/02/the-witcher-geralts-gold-beer-review-a-tasty-brew-with-a-twist/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T20:15:12+00:00

The Witcher’s third season is now streaming on Netflix.

## Viral Photo Of Stolen Police Van In France Actually From Netflix Movie
 - [https://www.forbes.com/sites/mattnovak/2023/07/02/viral-photo-of-stolen-police-van-in-france-actually-from-netflix-movie/](https://www.forbes.com/sites/mattnovak/2023/07/02/viral-photo-of-stolen-police-van-in-france-actually-from-netflix-movie/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T19:51:01+00:00

An image has gone viral on social media platforms like Twitter showing a stolen police van during the riots currently happening in France. It's actually a Netflix movie.

## Tesla Cybertruck Coming This Quarter: Musk
 - [https://www.forbes.com/sites/brookecrothers/2023/07/02/tesla-cybertruck-coming-this-quarter-musk/](https://www.forbes.com/sites/brookecrothers/2023/07/02/tesla-cybertruck-coming-this-quarter-musk/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T18:54:03+00:00

Tesla CEO Elon Musk is on the record saying the Cybertruck delivery event will happen this quarter. Signs point to the event actually taking place this time.

## ‘Baldur’s Gate 3’ Is So Long, You May Have To Quit Your Job And Leave Your Family
 - [https://www.forbes.com/sites/erikkain/2023/07/02/baldurs-gate-3-is-so-long-you-may-have-to-quit-your-job-and-leave-your-family/](https://www.forbes.com/sites/erikkain/2023/07/02/baldurs-gate-3-is-so-long-you-may-have-to-quit-your-job-and-leave-your-family/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T18:51:40+00:00

Baldur's Gate III is going to eat up all your time.

## The Best ‘Assassin’s Creed’ Game Is Reportedly Getting A Remake
 - [https://www.forbes.com/sites/erikkain/2023/07/02/the-best-assassins-creed-game-is-reportedly-getting-a-remake/](https://www.forbes.com/sites/erikkain/2023/07/02/the-best-assassins-creed-game-is-reportedly-getting-a-remake/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T18:31:54+00:00

Take to the high seas once again, but with much prettier graphics.

## ‘Gotham Knights’ Steam Summer Sale Price Says Everything
 - [https://www.forbes.com/sites/erikkain/2023/07/02/gotham-knights-steam-summer-sale-price-says-everything/](https://www.forbes.com/sites/erikkain/2023/07/02/gotham-knights-steam-summer-sale-price-says-everything/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T18:08:54+00:00

The latest DC superhero game is already on a massive sale.

## Morgan Wallen’s ‘One Thing At A Time,’ SZA’s ‘SOS’ Dominate 2023 Charts
 - [https://www.forbes.com/sites/ariannajohnson/2023/07/02/morgan-wallens-one-thing-at-a-time-szas-sos-dominate-2023-charts/](https://www.forbes.com/sites/ariannajohnson/2023/07/02/morgan-wallens-one-thing-at-a-time-szas-sos-dominate-2023-charts/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T18:00:00+00:00

Wallen and SZA’s albums collectively have spent 22 out of the 26 weeks this year at No. 1.

## Tesla Sets Quarterly Delivery Record, Aided By Price Cuts
 - [https://www.forbes.com/sites/alanohnsman/2023/07/02/tesla-sets-quarterly-delivery-record-aided-by-price-cuts/](https://www.forbes.com/sites/alanohnsman/2023/07/02/tesla-sets-quarterly-delivery-record-aided-by-price-cuts/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T17:40:07+00:00

The world’s best-selling electric vehicle brand topped analysts' expectations with 466,140 deliveries.

## Video Of 'Leopard 2A4U' Main Battle Tank In Ukraine Went Viral – Did It Reveal Too Much?
 - [https://www.forbes.com/sites/petersuciu/2023/07/02/video-of-leopard-2a4u-main-battle-tank-in-ukraine-went-viral--did-it-reveal-too-much/](https://www.forbes.com/sites/petersuciu/2023/07/02/video-of-leopard-2a4u-main-battle-tank-in-ukraine-went-viral--did-it-reveal-too-much/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T17:03:38+00:00

The Ukrainian military has continued to employ so-called "war porn" videos that highlight the exploits of its units on the front lines.

## Apple Leak Details All-New iPhone 15, iPhone 15 Pro Design Changes
 - [https://www.forbes.com/sites/gordonkelly/2023/07/02/apple-iphone-15-pro-max-design-colors-finishes-product-red-new-iphones/](https://www.forbes.com/sites/gordonkelly/2023/07/02/apple-iphone-15-pro-max-design-colors-finishes-product-red-new-iphones/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T15:58:01+00:00

The iPhone 15 range may not look like you expect...

## No One Believes Elon Musk’s Explanation For Breaking Twitter
 - [https://www.forbes.com/sites/paultassi/2023/07/02/no-one-believes-elon-musks-explanation-for-breaking-twitter/](https://www.forbes.com/sites/paultassi/2023/07/02/no-one-believes-elon-musks-explanation-for-breaking-twitter/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T15:54:22+00:00

Well, he finally did it. Elon Musk has broken Twitter so badly that it might as well be offline at this point.

## Final Decision On SEC’s Cybersecurity Disclosure Rules Pushed To October 2023
 - [https://www.forbes.com/sites/joetoscano1/2023/07/02/final-decision-on-secs-cybersecurity-disclosure-rules-pushed-to-october-2023/](https://www.forbes.com/sites/joetoscano1/2023/07/02/final-decision-on-secs-cybersecurity-disclosure-rules-pushed-to-october-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T15:27:50+00:00

By providing clear frameworks, the SEC can empower stakeholders to develop comprehensive cybersecurity strategies while aligning with industry best practices.

## CDC: Cyclosporiasis Has Left 210 Sick, 30 Hospitalized Across 22 States
 - [https://www.forbes.com/sites/brucelee/2023/07/02/cdc-cyclosporiasis-has-left-210-sick-30-hospitalized-across-22-states/](https://www.forbes.com/sites/brucelee/2023/07/02/cdc-cyclosporiasis-has-left-210-sick-30-hospitalized-across-22-states/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T15:06:46+00:00

The cause of cyclosporiasis is a parasite called Cyclospora cayetanensis. Here's how to prevent and treat this illness that can cause explosive diarrhea.

## Reflecting On The Least Amount Of ‘Destiny 2’ I’ve Played Since Curse Of Osiris
 - [https://www.forbes.com/sites/paultassi/2023/07/02/reflecting-on-the-least-amount-of-destiny-2-ive-played-since-curse-of-osiris/](https://www.forbes.com/sites/paultassi/2023/07/02/reflecting-on-the-least-amount-of-destiny-2-ive-played-since-curse-of-osiris/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T14:11:26+00:00

Everyone has their own story as to why Destiny 2 isn’t quite hooking them the way it use to, but I wanted to try to quantify it.

## Don’t Get Hacked. The Increased Risk Of Cyber-Threats And How Family Offices Can Protect Themselves
 - [https://www.forbes.com/sites/francoisbotha/2023/07/02/dont-get-hacked-the-increased-risk-of-cyber-threats-and-how-family-offices-can-protect-themselves/](https://www.forbes.com/sites/francoisbotha/2023/07/02/dont-get-hacked-the-increased-risk-of-cyber-threats-and-how-family-offices-can-protect-themselves/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T14:01:26+00:00

What are the common cybersecurity risks family offices should be aware of? Like any cyber attacks, the biggest threats posed to family offices aren’t that different.

## How Educators Can Use Multi-Tiered Systems Of Support (MTSS)
 - [https://www.forbes.com/sites/quora/2023/07/02/how-educators-can-use-multi-tiered-systems-of-support-mtss/](https://www.forbes.com/sites/quora/2023/07/02/how-educators-can-use-multi-tiered-systems-of-support-mtss/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T14:00:00+00:00

How can teachers best implement MTSS? Answer by Katie Novak, educator, researcher, author of 12 education books.

## 5 Steps For A Successful Breakup, According To A Psychologist
 - [https://www.forbes.com/sites/drariannabrandolini/2023/07/02/5-steps-for-a-successful-breakup-according-to-a-psychologist/](https://www.forbes.com/sites/drariannabrandolini/2023/07/02/5-steps-for-a-successful-breakup-according-to-a-psychologist/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T13:41:17+00:00

If you accept that it will be hard, but you can handle it, and everyone will be better off in the long run, you’re much more likely to navigate a breakup well.

## Canada’s Immigration Rules Boost Companies And H-1B Visa Holders
 - [https://www.forbes.com/sites/stuartanderson/2023/07/02/canadas-immigration-rules-boost-companies-and-h-1b-visa-holders/](https://www.forbes.com/sites/stuartanderson/2023/07/02/canadas-immigration-rules-boost-companies-and-h-1b-visa-holders/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T13:36:38+00:00

U.S. companies and H-1B visa holders can benefit from new rules Canada has announced to attract high-skilled professionals.

## ‘Secret Invasion’ Is Marvel’s Worst-Reviewed Series Since ‘Iron Fist’
 - [https://www.forbes.com/sites/paultassi/2023/07/02/secret-invasion-is-marvels-worst-reviewed-series-since-iron-fist/](https://www.forbes.com/sites/paultassi/2023/07/02/secret-invasion-is-marvels-worst-reviewed-series-since-iron-fist/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T13:35:43+00:00

Marvel is trying something new with Secret Invasion and it is just not working.

## Poll Suggests Limits To What Most Americans Are Willing To Spend On New Wave Of Obesity Drugs
 - [https://www.forbes.com/sites/joshuacohen/2023/07/02/poll-suggests-limits-to-what-most-americans-are-willing-to-spend-on-new-wave-of-obesity-drugs/](https://www.forbes.com/sites/joshuacohen/2023/07/02/poll-suggests-limits-to-what-most-americans-are-willing-to-spend-on-new-wave-of-obesity-drugs/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T13:25:58+00:00

The typical American’s willingness to pay amount for the new obesity drugs appears to be quite low in relation to the actual list prices, or even payer co-insurance.

## What On Earth Happened With ‘The Witcher’ Season 3, Episode 5?
 - [https://www.forbes.com/sites/paultassi/2023/07/02/what-on-earth-happened-with-the-witcher-season-3-episode-5/](https://www.forbes.com/sites/paultassi/2023/07/02/what-on-earth-happened-with-the-witcher-season-3-episode-5/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T13:15:11+00:00

Netflix has released the first part of season 3 of The Witcher, Henry Cavill’s last season as Geralt before the torch is thrown directly at Liam Hemsworth’s head.

## You Are Gearing Up Wrong In World Tier 4 In ‘Diablo 4’
 - [https://www.forbes.com/sites/paultassi/2023/07/02/you-are-gearing-up-wrong-in-world-tier-4-in-diablo-4/](https://www.forbes.com/sites/paultassi/2023/07/02/you-are-gearing-up-wrong-in-world-tier-4-in-diablo-4/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T12:32:01+00:00

I have seen a lot of people wondering why their Diablo 4 build is rapidly falling apart as they get even a little ways into World Tier 4, and complaining that the Ancestral Legendaries they’d assumed would start dropping are far too scarce.

## Batteries And Renewables Are Saving Texas During The Heat Wave
 - [https://www.forbes.com/sites/anandgopal/2023/07/02/batteries-and-renewables-are-saving-texas-in-the-heat-wave/](https://www.forbes.com/sites/anandgopal/2023/07/02/batteries-and-renewables-are-saving-texas-in-the-heat-wave/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T12:00:00+00:00

Renewables and storage are saving Texans money as temperatures soar and coal and natural gas power plants fail.

## Important Shark And Ray Areas Delineated In The Mediterranean And Black Seas
 - [https://www.forbes.com/sites/melissacristinamarquez/2023/07/02/important-shark-and-ray-areas-delineated-in-the-mediterranean-and-black-seas/](https://www.forbes.com/sites/melissacristinamarquez/2023/07/02/important-shark-and-ray-areas-delineated-in-the-mediterranean-and-black-seas/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T12:00:00+00:00

85 areas deemed important for the conservation of sharks and rays in the Mediterranean and Black Seas have been identified and delineated.

## ‘Valorant’ Needs To Change Its Boring Battle Pass
 - [https://www.forbes.com/sites/mikestubbs/2023/07/02/valorant-needs-to-change-its-boring-battle-pass/](https://www.forbes.com/sites/mikestubbs/2023/07/02/valorant-needs-to-change-its-boring-battle-pass/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T10:56:51+00:00

Valve is scrapping the Battle Pass from Dota 2 and Valorant should consider doing the same because the Episode 7 Act 1 Battle Pass is boring.

## ChatGPT And Generative AI: What To Do With All The Productivity?
 - [https://www.forbes.com/sites/glenngow/2023/07/02/chatgpt-and-generative-ai-what-to-do-with-all-the-productivity/](https://www.forbes.com/sites/glenngow/2023/07/02/chatgpt-and-generative-ai-what-to-do-with-all-the-productivity/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T10:00:00+00:00

Where are the biggest opportunities to do more with less, reduce costs, and boost profit?

## The RØDECaster Duo Is The Perfect Podcast Studio That Fits In A Backpack
 - [https://www.forbes.com/sites/marksparrow/2023/07/02/the-rdecaster-duo-is-the-perfect-podcast-studio-that-fits-in-a-backpack/](https://www.forbes.com/sites/marksparrow/2023/07/02/the-rdecaster-duo-is-the-perfect-podcast-studio-that-fits-in-a-backpack/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T10:00:00+00:00

The new RØDECaster Duo for recording podcasts on location but with all the functions you'd expect to find in a fully equipped studio

## Today’s ‘Quordle’ Answers And Clues For Sunday, July 2
 - [https://www.forbes.com/sites/krisholt/2023/07/02/todays-quordle-answers-and-clues-for-sunday-july-2/](https://www.forbes.com/sites/krisholt/2023/07/02/todays-quordle-answers-and-clues-for-sunday-july-2/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T04:00:34+00:00

Looking for some help with today's Quordle words? Some clues and the answers are coming right up.

## Today’s Wordle #743 Hints, Clues And Answer For Sunday, July 2nd
 - [https://www.forbes.com/sites/erikkain/2023/07/01/todays-wordle-743-hints-clues-and-answer-for-sunday-july-2nd/](https://www.forbes.com/sites/erikkain/2023/07/01/todays-wordle-743-hints-clues-and-answer-for-sunday-july-2nd/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-07-02T02:30:00+00:00

How to solve today's Wordle. Hints, clues and the daily Wordle answer. Also, play competitive Wordle and learn more about each day's word.

