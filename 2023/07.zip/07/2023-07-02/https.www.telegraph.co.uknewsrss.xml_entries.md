# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Office plant potted 14 years ago grows to 600ft
 - [https://www.telegraph.co.uk/news/2023/07/02/office-plant-potted-14-years-ago-grows-600ft/](https://www.telegraph.co.uk/news/2023/07/02/office-plant-potted-14-years-ago-grows-600ft/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-02T17:53:17+00:00



## Student ‘never seen in person’ by NHS staff took his own life
 - [https://www.telegraph.co.uk/news/2023/07/02/darragh-spelman-never-seen-in-person-by-nhs-commits-suicide/](https://www.telegraph.co.uk/news/2023/07/02/darragh-spelman-never-seen-in-person-by-nhs-commits-suicide/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-02T14:23:57+00:00



## Student ‘never seen in person’ by NHS staff took his own life
 - [https://www.telegraph.co.uk/news/2023/07/02/darragh-spelman-never-seen-in-person-by-nhs-suicide/](https://www.telegraph.co.uk/news/2023/07/02/darragh-spelman-never-seen-in-person-by-nhs-suicide/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-02T14:23:57+00:00



