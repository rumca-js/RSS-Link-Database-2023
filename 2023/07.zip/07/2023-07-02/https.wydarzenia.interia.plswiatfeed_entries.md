# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Nocny atak na Kijów. Siły powietrzne Ukrainy zestrzeliły drony i trzy Kalibry
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nocny-atak-na-kijow-sily-powietrzne-ukrainy-zestrzelily-dron,nId,6877885](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nocny-atak-na-kijow-sily-powietrzne-ukrainy-zestrzelily-dron,nId,6877885)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-07-02T04:25:07+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nocny-atak-na-kijow-sily-powietrzne-ukrainy-zestrzelily-dron,nId,6877885"><img align="left" alt="Nocny atak na Kijów. Siły powietrzne Ukrainy zestrzeliły drony i trzy Kalibry" src="https://i.iplsc.com/nocny-atak-na-kijow-sily-powietrzne-ukrainy-zestrzelily-dron/000H7HP3TEG6FN2C-C321.jpg" /></a>W nocy z soboty na niedzielę doszło do rosyjskiego ataku rakietowego na Kijów. Siły powietrzne Ukrainy zestrzeliły osiem dronów uderzeniowych produkcji irańskiej Shahed oraz trzy rakiety manewrujące Kalibr - poinformowało dowództwo wojsk lotniczych w Kijowie. To pierwszy od 12 dni atak przy użyciu dronów na ukraińską stolicę. W kilku obwodach są ranne osoby, w tym troje dzieci.</p><br clear="all" />

