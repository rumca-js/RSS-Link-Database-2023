# Source:CNBC, URL:https://www.cnbc.com/id/100727362/device/rss/rss.html, language:en-US

## The rise and fall of Skype
 - [https://www.cnbc.com/2023/07/02/the-rise-and-fall-of-skype.html](https://www.cnbc.com/2023/07/02/the-rise-and-fall-of-skype.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-07-02T17:08:50+00:00

Microsoft says Skype "remains a great option." But it has lost daily users in the past three years, while other services, including Microsoft Teams, have grown.

## Why the electric vehicle boom could put a major strain on the U.S. power grid
 - [https://www.cnbc.com/2023/07/01/why-the-ev-boom-could-put-a-major-strain-on-our-power-grid.html](https://www.cnbc.com/2023/07/01/why-the-ev-boom-could-put-a-major-strain-on-our-power-grid.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-07-02T16:59:00+00:00

The EV revolution could put a big strain on the nation's electric grid, an aging system built for a world that runs on fossil fuels.

## Tesla reported 466,140 deliveries for the second quarter, and production of 479,700 vehicles
 - [https://www.cnbc.com/2023/07/02/tesla-tsla-q2-2023-vehicle-delivery-and-production-numbers.html](https://www.cnbc.com/2023/07/02/tesla-tsla-q2-2023-vehicle-delivery-and-production-numbers.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-07-02T16:45:26+00:00

Tesla just posted its second-quarter vehicle production and deliveries report for 2023.

