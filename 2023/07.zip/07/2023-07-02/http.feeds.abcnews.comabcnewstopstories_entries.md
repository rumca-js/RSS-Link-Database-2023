# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Thousands of hotel workers in Southern California are on strike
 - [https://abcnews.go.com/US/wireStory/thousands-hotel-workers-southern-california-strike-demanding-pay-100598167](https://abcnews.go.com/US/wireStory/thousands-hotel-workers-southern-california-strike-demanding-pay-100598167)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T19:46:58+00:00

Thousands of hotel workers in Southern California walked off the job Sunday, demanding higher pay and better benefits in what the union is calling the largest strike in its history

## Pope’s pick to handle sex abuse allegations has refused to believe some victims, US group says
 - [https://abcnews.go.com/International/wireStory/us-group-decries-troubling-popes-pick-head-vatican-100594688](https://abcnews.go.com/International/wireStory/us-group-decries-troubling-popes-pick-head-vatican-100594688)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T19:23:17+00:00

The Argentine archbishop has refused to believe some victims, U.S. group says.

## Israel to buy more F-35 fighter jets from US
 - [https://abcnews.go.com/Business/wireStory/israel-buy-35-fighter-jets-us-deal-expands-100597449](https://abcnews.go.com/Business/wireStory/israel-buy-35-fighter-jets-us-deal-expands-100597449)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T18:32:07+00:00

Israel says it will buy 25 F-35 aircraft from the United States

## A tornado in the Alberta, Canada, has wrecked homes but caused no serious injuries
 - [https://abcnews.go.com/International/wireStory/tornado-canadian-province-alberta-wrecked-homes-caused-injuries-100597575](https://abcnews.go.com/International/wireStory/tornado-canadian-province-alberta-wrecked-homes-caused-injuries-100597575)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T18:31:31+00:00

A tornado that struck near a town in the Canadian province of Alberta has wrecked homes and killed livestock, but caused no serious injuries

## WATCH:  Robot takes stage to conduct orchestra in Seoul
 - [https://abcnews.go.com/Technology/video/robot-takes-stage-conduct-orchestra-seoul-100597116](https://abcnews.go.com/Technology/video/robot-takes-stage-conduct-orchestra-seoul-100597116)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T17:27:13+00:00

A two-armed android robot, EveR 6, took the conductor's podium in Seoul to lead a performance by South Korea's national orchestra.

## 3 of 9 enter pleas in burglary ring in theft of art, sports memorabilia
 - [https://abcnews.go.com/US/wireStory/3-9-enter-pleas-burglary-ring-theft-art-100596391](https://abcnews.go.com/US/wireStory/3-9-enter-pleas-burglary-ring-theft-art-100596391)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T17:16:51+00:00

Three of nine people have pleaded guilty to federal charges in a burglary ring that authorities in northeastern Pennsylvania say stole art, sports memorabilia and other items from museums and other institutions over two decades

## Atlanta rapper suspected of role in fatal shooting arrested, charged with murder
 - [https://abcnews.go.com/Entertainment/wireStory/atlanta-rapper-suspected-role-fatal-shooting-arrested-charged-100595942](https://abcnews.go.com/Entertainment/wireStory/atlanta-rapper-suspected-role-fatal-shooting-arrested-charged-100595942)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T15:55:55+00:00

An Atlanta rapper signed to Young Thug's record label has been arrested and charged with murder for his suspected role in the fatal shooting of a man outside an apartment complex

## Most Americans approve of SCOTUS ruling restricting use of race in college admissions
 - [https://abcnews.go.com/Politics/americans-approve-supreme-court-decision-restricting-race-college/story?id=100580375](https://abcnews.go.com/Politics/americans-approve-supreme-court-decision-restricting-race-college/story?id=100580375)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T13:28:45+00:00

A little more than half of Americans – 52% -- approve of the U.S. Supreme Court decision on affirmative action.

## 7 shot, 2 trampled in shooting at nightclub in Kansas
 - [https://abcnews.go.com/US/7-shot-2-trampled-shooting-nightclub-kansas/story?id=100593361](https://abcnews.go.com/US/7-shot-2-trampled-shooting-nightclub-kansas/story?id=100593361)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T09:36:14+00:00

Seven people were shot and two others have been trampled after a shooting inside a nightclub in Wichita, Kansas, early Sunday morning.

## 'Mass shooting incident' in Baltimore, police confirm multiple victims
 - [https://abcnews.go.com/US/mass-shooting-incident-baltimore-police-confirm-multiple-victims/story?id=100593352](https://abcnews.go.com/US/mass-shooting-incident-baltimore-police-confirm-multiple-victims/story?id=100593352)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T07:54:03+00:00

A "mass shooting incident" in Baltimore has left "multiple victims" in the Brooklyn Homes neighborhood in the southern district of the city, authorities said.

## Israel's air force attacks Syria and Syrian air defense missile explodes over northern Israel
 - [https://abcnews.go.com/International/wireStory/israels-air-force-attacks-syria-syrian-air-defense-100592700](https://abcnews.go.com/International/wireStory/israels-air-force-attacks-syria-syrian-air-defense-100592700)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T06:54:26+00:00

Israel carried out airstrikes on areas near the central Syrian city of Homs causing material damage but no casualties, the Syrian military said in a statement

## WATCH:  Officers rescue dog trapped in canal
 - [https://abcnews.go.com/US/video/officers-rescue-dog-trapped-canal-100591838](https://abcnews.go.com/US/video/officers-rescue-dog-trapped-canal-100591838)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T05:20:24+00:00

Quick-thinking officers helped get a dog out of an Arizona canal by tempting it with some baked goods.

## After several turbulent days, flight disruptions ease despite worries about 5G signals
 - [https://abcnews.go.com/Travel/wireStory/after-turbulent-days-flight-disruptions-ease-despite-worries-100581245](https://abcnews.go.com/Travel/wireStory/after-turbulent-days-flight-disruptions-ease-despite-worries-100581245)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T03:42:19+00:00

Passengers endured tens of thousands of weather-related flight delays this week.

## 2nd bus carrying asylum seekers from Texas arrives in Los Angeles
 - [https://abcnews.go.com/US/wireStory/2nd-bus-carrying-asylum-seekers-texas-arrives-los-100591641](https://abcnews.go.com/US/wireStory/2nd-bus-carrying-asylum-seekers-texas-arrives-los-100591641)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T03:26:33+00:00

It's the second time a bus arrived in less than three weeks.

## Ukraine prepares for possible nuclear attack with disaster drills
 - [https://abcnews.go.com/International/ukraine-holds-disaster-drills-amid-fears-russia-sabotage/story?id=100571038](https://abcnews.go.com/International/ukraine-holds-disaster-drills-amid-fears-russia-sabotage/story?id=100571038)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T03:03:04+00:00

ABC News was invited to the drills in the city of Zaporizhzhia this week, about 30 miles from the plant.

## Trump pressured former Arizona governor to flip 2020 election results: Sources
 - [https://abcnews.go.com/Politics/trump-pressured-former-arizona-governor-overturn-2020-election/story?id=100581345](https://abcnews.go.com/Politics/trump-pressured-former-arizona-governor-overturn-2020-election/story?id=100581345)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-07-02T00:43:12+00:00

Trump pressured former Arizona governor Doug Ducey to overturn the Arizona 2020 presidential election results, sources said.

