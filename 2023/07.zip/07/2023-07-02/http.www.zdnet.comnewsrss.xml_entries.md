# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## I made the switch to a smart litter box, and my cat approves
 - [https://www.zdnet.com/home-and-office/smart-home/i-made-the-switch-to-a-smart-litter-box-and-my-cat-approves/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/i-made-the-switch-to-a-smart-litter-box-and-my-cat-approves/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-07-02T12:00:24+00:00

The Whisker Litter-Robot 4 automates what's typically a messy job and even manages your cat's health.

## These bone-conduction headphones are 'swim-ready'. I put them to the test
 - [https://www.zdnet.com/article/these-bone-conduction-headphones-are-swim-ready-i-put-them-to-the-test/#ftag=RSSbaffb68](https://www.zdnet.com/article/these-bone-conduction-headphones-are-swim-ready-i-put-them-to-the-test/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-07-02T11:30:25+00:00

The H2O Audio Sonar Pro are water-resistant, bone-conduction headphones. I tested to see if it was all marketing or the real deal.

