# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Małopolska. Auto wjechało w motocykle. Nie żyje emerytowana policjantka, jej 9-letni syn walczy o życie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29932282,malopolska-auto-wjechalo-w-motocykle-nie-zyje-emerytowana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29932282,malopolska-auto-wjechalo-w-motocykle-nie-zyje-emerytowana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-02T16:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/60/1c/z29756871M,Smiertelny-wypadek---zdjecie-ilustracyjne.jpg" vspace="2" />W powiecie limanowskim doszło do tragicznego wypadku. Samochód osobowy zderzył się z dwoma motocyklami. Zginęła kierująca jednym z nich 51-letnia emerytowana policjantka. Dziewięcioletni syn kobiety został przetransportowany do szpitala. Jego stan jest bardzo ciężki.

## Awantura w TVP Info. "Pani coś sugeruje? To brzmi jak groźby"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931981,awantura-w-tvp-info-pani-cos-sugeruje-to-brzmi-jak-grozby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931981,awantura-w-tvp-info-pani-cos-sugeruje-to-brzmi-jak-grozby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-02T14:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/74/8b/1c/z29932148M,Poslanka-Karolina-Pawliczak.jpg" vspace="2" />W programie publicystycznym na antenie TVP Info doszło do ostrej wymiany zdań. Prowadzący Adrian Klarenbach kilkukrotnie nawiązywał do "politycznych barw" posłanki Karoliny Pawliczak. - Jest pan dziś wyjątkowo złośliwy. Ja pana nie pytam, gdzie pan pójdzie po przegranych wyborach PiS-u - skomentowała. Na tym się jednak nie skończyło.

## Abp Polak kategorycznie o komisji ds. pedofilii. "Być może owocem będzie odzyskanie wiarygodności"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931708,abp-polak-kategorycznie-o-komisji-ds-pedofilii-byc-moze-owocem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931708,abp-polak-kategorycznie-o-komisji-ds-pedofilii-byc-moze-owocem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-02T13:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f6/66/19/z26634230M,Arcybiskup-Wojciech-Polak.jpg" vspace="2" />- Komisja badająca pedofilię w Kościele będzie niezależna. Musimy działać razem i przebadać trudną dla Kościoła przeszłość - zapewnił abp Wojciech Polak w wywiadzie dla "Rzeczpospolitej". Hierarcha zaznaczył, że ofiar nie interesuje, kto je skrzywdził - ksiądz, zakonnica czy zakonnik. - Ważne, że zrobił to przedstawiciel Kościoła - dodał.

## Nowe nagranie z promu. Dziennikarze o tym, co działo się tuż przed tragedią na Bałtyku
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931758,nowe-nagranie-z-promu-dziennikarze-o-tym-co-dzialo-sie-tuz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931758,nowe-nagranie-z-promu-dziennikarze-o-tym-co-dzialo-sie-tuz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-02T12:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f5/63/1c/z29767669M,Morze-Baltyckie--zdjecie-ilustracyjne-.jpg" vspace="2" />Polska i szwedzka prokuratura prowadzi śledztwo w sprawie śmierci 36-letniej kobiety i jej syna na promie. Kamery monitoringu zarejestrowały chwile przed tragedią.

## Do Polski dotrze afrykański upał? Nawet 35 stopni Celsjusza, później wrócą nawałnice
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931162,do-polski-dotrze-afrykanski-upal-nawet-35-stopni-celsjusza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29931162,do-polski-dotrze-afrykanski-upal-nawet-35-stopni-celsjusza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-02T08:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/8b/1c/z29931282M,Plaza--upal--zdjecie-ilustracyjne-.jpg" vspace="2" />Jaka będzie pogoda w wakacje? Zgodnie z prognozami prawdopodobnie zbliża się do nas afrykański upał, w związku z którym temperatura podskoczy nawet do 35 stopni Celsjusza. Potem jednak mogą wrócić nawałnice.

## Zna go każdy, wciąż dochodzi do poparzeń. Leśnicy ostrzegają: Objawy nawet po kilkunastu minutach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29930221,zna-go-kazdy-wciaz-dochodzi-do-poparzen-lesnicy-ostrzegaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29930221,zna-go-kazdy-wciaz-dochodzi-do-poparzen-lesnicy-ostrzegaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-02T06:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e5/78/1c/z29852901M,Barszcz-Sosnowskiego--zdjecie-ilustracyjne-.jpg" vspace="2" />Latem dochodzi do największej ilości poparzeń. Zagrożeniem nie są jedynie promienie słonczene. "Przypominamy o barszczu Sosnowskiego" - ostrzegają Lasy Państwowe. Roślina jest bardzo inwazyjna, a przede wszystkim trudna do zwalczenia.

## Kiedy wybory parlamentarne? Duda: Bardzo ładna data
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29930143,kiedy-wybory-parlamentarne-duda-bardzo-ladna-data.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29930143,kiedy-wybory-parlamentarne-duda-bardzo-ladna-data.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-02T05:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/8b/1c/z29930258M,Sejm--zdjecie-ilustracyjne-.jpg" vspace="2" />Kiedy odbędą się wybory parlamentarne? W mediach od dawna pojawia się data 15 października, czyli Dzień Papieski. Według Andrzeja Dudy to "bardzo ładna data".

