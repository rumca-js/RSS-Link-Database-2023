# Source:Marc Brunet, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg, language:en-US

## 🧍 FULL BODY ANATOMY IN 10 MIN (for artists)
 - [https://www.youtube.com/watch?v=XP9d0_5HjyA](https://www.youtube.com/watch?v=XP9d0_5HjyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg
 - date published: 2023-07-02T12:30:11+00:00

🏝️ SUMMER SALE!! Get a MEGA 31% OFF ($179) the ART School for Digital Artists program  🎓 http://artschool.ai/ until July 31st 2023 ONLY!!  

Join our epic art community! WE JUST PASSED 18,000 ENROLLED STUDENTS! Nani?!

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

🖌 Get my brushes for FREE here: http://cbr.sh/befto
💻 HOW TO USE THE FREE BRUSHES: https://youtu.be/8EC1Ibda3BI
🖌 Clip Studio Paint MB LENGENDARY Lineart Brush: http://cbr.sh/vb2lt6
🖌 Get my advanced brush set here: http://cbr.sh/btml0

🚀 My Store: https://cubebrush.co/mb
🎨 Practice files download: http://cbr.sh/xsqi64

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

FOLLOW ME ON SOCIAL MEDIA:
✏ Twitter: https://twitter.com/bluefley
📷 Instagram: https://instagram.com/bluefley

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

#anatomy #anatomydrawing #artteacher

