# Source:Mental Outlaw, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA, language:en-US

## Twitter Has Become Paywalled
 - [https://www.youtube.com/watch?v=44z5oLKM5uE](https://www.youtube.com/watch?v=44z5oLKM5uE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA
 - date published: 2023-07-02T22:04:07+00:00

In this video I discuss how twitter has blocked all content from the site unless you are signed in and established a "view limit" of 600 posts for accounts without Twitter Blue and 6000 posts for accounts with Twitter Blue.

My merch is available at
https://based.win/

Subscribe to me on Odysee.com
https://odysee.com/@AlphaNerd:8

₿💰💵💲Help Support the Channel by Donating Crypto💲💵💰₿

Monero
45F2bNHVcRzXVBsvZ5giyvKGAgm6LFhMsjUUVPTEtdgJJ5SNyxzSNUmFSBR5qCCWLpjiUjYMkmZoX9b3cChNjvxR7kvh436

Bitcoin
3MMKHXPQrGHEsmdHaAGD59FWhKFGeUsAxV

Ethereum
0xeA4DA3F9BAb091Eb86921CA6E41712438f4E5079

Litecoin
MBfrxLJMuw26hbVi2MjCVDFkkExz8rYvUF

