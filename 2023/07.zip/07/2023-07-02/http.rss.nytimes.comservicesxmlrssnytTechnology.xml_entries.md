# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Tesla Sales Surge as Tax Credits Fuel Demand
 - [https://www.nytimes.com/2023/07/02/business/tesla-q2-sales-deliveries.html](https://www.nytimes.com/2023/07/02/business/tesla-q2-sales-deliveries.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-07-02T17:00:05+00:00

Incentives and price cuts made Tesla electric cars cheaper than comparable gasoline models. But the company faces growing competition in China, a key market.

## New Uncensored Chatbots Ignite a Free-Speech Fracas
 - [https://www.nytimes.com/2023/07/02/technology/ai-chatbots-misinformation-free-speech.html](https://www.nytimes.com/2023/07/02/technology/ai-chatbots-misinformation-free-speech.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-07-02T09:01:15+00:00

A new generation of chatbots doesn’t have many of the guardrails put in place by companies like Google and OpenAI, presenting new possibilities — and risks.

