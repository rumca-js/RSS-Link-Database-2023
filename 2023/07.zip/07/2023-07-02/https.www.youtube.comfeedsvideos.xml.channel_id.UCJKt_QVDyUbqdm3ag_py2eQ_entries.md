# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: Jammer - Cuts'n'Pieces (SIDFX 8580 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=TSe7zLT28h8](https://www.youtube.com/watch?v=TSe7zLT28h8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2023-07-02T22:07:51+00:00

"Cuts'n'Pieces" by Jammer/1mandivision^MultiStyle Labs^Protovision, CSDb Techno Compo 2023 entry.
Art from the music release by Jammer.

CSDb Techno Compo 2023 entry list:
https://csdb.dk/event/?id=3287

Made using real C64 audio in SIDFX dual mono config (identical audio for both chips):

Left channel: CSG 6582A 2792 25/Philippines NM235N18 1200T
Right channel: CSG 8580R5 0590 25/Hong Kong HH032232 HC-30

Project SIDFX:
http://www.sidfx.dk/

## SID music: Mythus - Figurehead 6x (SIDFX 8580 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=LJtiLX7UFTk](https://www.youtube.com/watch?v=LJtiLX7UFTk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2023-07-02T22:07:34+00:00

"Figurehead 6x" by Mythus/Delysid^Protovision, CSDb Techno Compo 2023 entry.
Art from the music release by Mythus.

CSDb Techno Compo 2023 entry list:
https://csdb.dk/event/?id=3287

Made using real C64 audio in SIDFX dual mono config (identical audio for both chips):

Left channel: CSG 6582A 2792 25/Philippines NM235N18 1200T
Right channel: CSG 8580R5 0590 25/Hong Kong HH032232 HC-30

Project SIDFX:
http://www.sidfx.dk/

## Amiga Paula does XM: Malmen - Acid Hallucination (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=gwsSQJVMFkE](https://www.youtube.com/watch?v=gwsSQJVMFkE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2023-07-02T10:25:43+00:00

"Acid Hallucination" (2001) by Malmen/Spirits^Newdeal^Silent World.
Art "Att Bortom Se (To See Beyond)" by Frost, 1st at Jamaica ROM Party 2007.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 32 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Psirius - Artificial (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=7BFPMwKOBDc](https://www.youtube.com/watch?v=7BFPMwKOBDc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2023-07-02T10:25:26+00:00

"Artificial" (2019) by Psirius.
Art "Out for a Date" by Tomek/Haujobb, 14th at Revision 2023.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 32 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

