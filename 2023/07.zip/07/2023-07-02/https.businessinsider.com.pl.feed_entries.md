# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Reddit walczy z cyberprzestępcami. Chcą 4,5 mln dolarów i zmiany w polityce cenowej serwisu
 - [https://businessinsider.com.pl/technologie/reddit-wprowadzil-zmiany-w-polityce-cenowej-api-duza-krytyka/rvpryy6](https://businessinsider.com.pl/technologie/reddit-wprowadzil-zmiany-w-polityce-cenowej-api-duza-krytyka/rvpryy6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T14:24:36+00:00

Cyberprzestępcy z gangu ransomware BlackCat, znanego również jako ALPHV, grożą wyciekiem 80 GB poufnych danych z Reddit. Ich warunki? Serwis ma zapłacić 4,5 mln dol., a dodatkowo wycofać kontrowersyjną politykę cenową, która wywołała protest niektórych najbardziej wpływowych użytkowników platformy.

## Zrobili bluzy dla klasy w liceum. Po dziesięciu latach ubierają największe firmy [WYWIAD]
 - [https://businessinsider.com.pl/gospodarka/zrobili-bluzy-dla-klasy-w-liceum-po-dziesieciu-latach-ubieraja-najwieksze-firmy/f4dy0xg](https://businessinsider.com.pl/gospodarka/zrobili-bluzy-dla-klasy-w-liceum-po-dziesieciu-latach-ubieraja-najwieksze-firmy/f4dy0xg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T13:24:05+00:00

Mniej więcej dekadę temu młodzi Polacy pomyśleli, że nie muszą mieć bluz z logo Yale, Oxfordu czy Harvarda. Woleli "nosić" ubrania z nazwami własnych szkół czy uczelni. Dwaj licealiści pomyśleli wtedy, że zrobią takie bluzy w swojej szkole. Minęło dziesięć lat. W ciągu tej dekady nie tylko "ubrali" tysiące uczniów i studentów. Zaczęli też ubierać wielkie korporacje.

## Ekonomista: trzeba się przygotować na twarde lądowanie
 - [https://businessinsider.com.pl/finanse/ekonomista-trzeba-sie-przygotowac-na-twarde-ladowanie/4pzmvtd](https://businessinsider.com.pl/finanse/ekonomista-trzeba-sie-przygotowac-na-twarde-ladowanie/4pzmvtd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T13:00:15+00:00

Daniel Ivascyn, dyrektor inwestycyjny w Pimco, które zarządza aktywami o wartości 1,8 bln dol., w rozmowie z "Finacial Time" powiedział, że przygotowuje się na "twardsze lądowanie" niż inni inwestorzy. Tymczasem szefowie banków centralnych przygotowują się do kontynuowania kampanii podwyżek stóp procentowych.

## Google pracuje nad nową usługą gamingową w chmurze. Wnioski po porażce platformy Stadia wyciągnięte?
 - [https://businessinsider.com.pl/technologie/google-playables-ma-byc-nowa-usluga-gamingowa-w-chmurze/d7z3nx1](https://businessinsider.com.pl/technologie/google-playables-ma-byc-nowa-usluga-gamingowa-w-chmurze/d7z3nx1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T12:35:51+00:00

Wygląda na to, że Google testuje wewnętrznie nową platformę do grania w chmurze. Nowa usługa, której nazwa to podobno Playables, pozwoli grać na urządzeniach mobilnych lub na komputerach. Co ciekawe, będzie powiązana z inną popularną platformą należącą do grupy Alphabet.

## Mieszkanie plus upadło, a ten program po cichu szybko rośnie [WYWIAD]
 - [https://businessinsider.com.pl/gospodarka/mieszkanie-plus-upadlo-a-ten-program-rosnie-po-cichu-druga-mlodosc-tbsow-wywiad/qdkt3x4](https://businessinsider.com.pl/gospodarka/mieszkanie-plus-upadlo-a-ten-program-rosnie-po-cichu-druga-mlodosc-tbsow-wywiad/qdkt3x4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T11:16:25+00:00

Rząd oficjalnie przyznał niedawno, że program Mieszkanie plus nie wypalił. W jego rynkowej części docelowo powstanie pięć tysięcy mieszkań i więcej nie będzie. Tymczasem po cichu rozkwita inny program. Rok w rok od 28 lat nowe mieszkania trafiają do osób, których nie stać na własne lokum na zasadach komercyjnych. TBS-y (Towarzystwo budownictwa społecznego) suchą nogą przeszły przez pandemię i podwyżki stóp procentowych i budują coraz więcej mieszkań. Z Dariuszem Stacherą, dyrektorem Banku Gospodarstwa Krajowego rozmawiamy o dalszych planach Towarzystwo budownictwa społecznego.

## Mieszkanie plus upadło, a ten program po cichu szybko rośnie [WYWIAD]
 - [https://businessinsider.com.pl/gospodarka/mieszkanie-plus-upadlo-a-ten-program-rosnie-po-cichu-druga-mlodosc-tbs-ow-wywiad/qdkt3x4](https://businessinsider.com.pl/gospodarka/mieszkanie-plus-upadlo-a-ten-program-rosnie-po-cichu-druga-mlodosc-tbs-ow-wywiad/qdkt3x4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T11:16:25+00:00

Rząd oficjalnie przyznał niedawno, że program Mieszkanie plus nie wypalił. W jego rynkowej części docelowo powstanie pięć tysięcy mieszkań i więcej nie będzie. Tymczasem po cichu rozkwita inny program. Rok w rok od 28 lat nowe mieszkania trafiają do osób, których nie stać na własne lokum na zasadach komercyjnych. TBS-y (Towarzystwo budownictwa społecznego) suchą nogą przeszły przez pandemię i podwyżki stóp procentowych i budują coraz więcej mieszkań. Z Dariuszem Stacherą, dyrektorem Banku Gospodarstwa Krajowego rozmawiamy o dalszych planach Towarzystwo budownictwa społecznego.

## Chiny werbują byłych pilotów NATO. Chodzi już nie tylko o kopiowanie technologii
 - [https://businessinsider.com.pl/wiadomosci/chiny-werbuja-bylych-pilotow-nato-chodzi-juz-nie-tylko-o-kopiowanie-technologii/352vyrs](https://businessinsider.com.pl/wiadomosci/chiny-werbuja-bylych-pilotow-nato-chodzi-juz-nie-tylko-o-kopiowanie-technologii/352vyrs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T11:06:07+00:00

Chiny od dawna słyną z kopiowania technologii. Teraz poszły o krok dalej, kopiując zachodnie taktyki walki powietrznej – a raczej płacąc ludziom z Zachodu za nauczenie ich tych taktyk.

## Kaczyński mówi o zwalczonej "ciężkiej chorobie" Polski i "nieuwikłaniu w złodziejstwo"
 - [https://businessinsider.com.pl/gospodarka/kaczynski-jestesmy-wladza-nieuwiklana-w-wielkie-zlodziejstwo/hqyhht4](https://businessinsider.com.pl/gospodarka/kaczynski-jestesmy-wladza-nieuwiklana-w-wielkie-zlodziejstwo/hqyhht4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T10:35:45+00:00

W czasie rządów PO-PSL była wielka zgoda na rabunek. My jesteśmy władzą nieuwikłaną w całe to wielkie złodziejstwo; zdołaliśmy w ciągu ośmiu lat zmienić w Polsce ustrój społeczno-gospodarczy — powiedział w niedzielę prezes PiS Jarosław Kaczyński.

## Co się stanie, jeśli pozostawisz drzazgę w skórze? Poważne konsekwencje
 - [https://businessinsider.com.pl/wideo/co-sie-stanie-jesli-pozostawisz-drzazge-w-skorze-powazne-konsekwencje/nd2v1ez](https://businessinsider.com.pl/wideo/co-sie-stanie-jesli-pozostawisz-drzazge-w-skorze-powazne-konsekwencje/nd2v1ez)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T10:10:00+00:00

Co się stanie, jeżeli przez dłuższy czas nie usuniesz drzazgi? Drzazgi sprawiają ogromny ból. Usunięcie ich jeszcze większy. Co jednak, jeśli nie usuniesz jej przez dłuższy czas? Ryzykujesz wystąpienie groźnej infekcji.

## Wypłyń w rejs po Karaibach, na Antarktydę, Kanałem Panamskim lub Nilem
 - [https://businessinsider.com.pl/lifestyle/podroze/wyplyn-w-rejs-po-karaibach-na-antarktyde-kanalem-panamskim-lub-nilem/05pm69k](https://businessinsider.com.pl/lifestyle/podroze/wyplyn-w-rejs-po-karaibach-na-antarktyde-kanalem-panamskim-lub-nilem/05pm69k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T10:00:00+00:00

Jeśli nie przepadasz za wakacjami spędzonymi na jednej plaży i uważasz, że świat jest piękny i pełen niesamowitych miejsc, które warto zobaczyć na własne oczy. To, odważ się na prawdziwą przygodę i wypłyń w jeden z niezapomnianych rejsów na drugi koniec świata. Rejs na Antarktydę lub z Miami do Los Angeles przez Kanał Panamski, rejs po Karaibach czy Nilu to kierunki, które żadnego podróżnika nie pozostawią obojętnym. W artykule polecamy cztery sprawdzone i docenione przez klientów rejsy od biura podróży Albatros, które to od wielu lat specjalizuje się w rejsach turystycznych w najdalsze zakątki globu. Zapraszamy!

## "Inkluzywna dywidenda". Firmy przyjazne LGBTQ+ mają wyższą rentowność
 - [https://businessinsider.com.pl/biznes/inkluzywna-dywidenda-firmy-przyjazne-lgbtq-maja-wyzsza-rentownosc/ble65np](https://businessinsider.com.pl/biznes/inkluzywna-dywidenda-firmy-przyjazne-lgbtq-maja-wyzsza-rentownosc/ble65np)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T09:59:47+00:00

Polska gospodarka traci nawet 9,5 mld zł rocznie na dyskryminacji społeczności LGBTQ+. Poszerzenie jej praw o zaledwie 10 proc. doprowadziłoby do wzrostu PKB na mieszkańca o 15 tys. 500 zł — wynika z danych Open for Business, koalicji firm działającej na rzecz osób LGBTQ+ w środowisku zawodowym. W rozmowie z Business Insider Polska CEO organizacji Dominic Arnall tłumaczy, co może zrobić biznes na rzecz pracowników reprezentujących aż 5 proc. populacji i opowiada, jak zmienia się sytuacja zawodowa osób LGBTQ+ w Polsce.

## Sztuczna inteligencja pomaga w randkowaniu. Nowe badania
 - [https://businessinsider.com.pl/technologie/sztuczna-inteligencja-pomaga-w-randkowaniu-nowe-badania/60924dz](https://businessinsider.com.pl/technologie/sztuczna-inteligencja-pomaga-w-randkowaniu-nowe-badania/60924dz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T09:11:00+00:00

Według badania, mężczyźni używają sztucznej inteligencji, aby umawiać się na więcej randek. Sztuczna inteligencja pomaga im tworzyć lepsze profile i spersonalizowane wiadomości, które wysyłają do potencjalnych partnerów i partnerek.

## Zostawcie Titanica. Oto najciekawsze wraki polskich wód
 - [https://businessinsider.com.pl/wiadomosci/zostawcie-titanica-oto-najciekawsze-wraki-polskich-wod/7cz845g](https://businessinsider.com.pl/wiadomosci/zostawcie-titanica-oto-najciekawsze-wraki-polskich-wod/7cz845g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T09:02:35+00:00

Wrak Titanica od dekad rozpala wyobraźnię poszukiwaczy przygód i miłośników statków. Ostatnia próba dopłynięcia do wraku skończyła się niestety tragicznie. Ale również w Polsce mamy wiele ciekawych wraków – jest wśród nich nawet nazistowski lotniskowiec! Dobrą wiadomością jest to, że aby obejrzeć wiele polskich pozostałości po znanych statkach, nie trzeba w ogóle ryzykować.

## Tyle jednostek przepłynęło przez Mierzeję
 - [https://businessinsider.com.pl/wiadomosci/tyle-jednostek-przeplynelo-przez-mierzeje/zkqjp67](https://businessinsider.com.pl/wiadomosci/tyle-jednostek-przeplynelo-przez-mierzeje/zkqjp67)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T08:52:47+00:00

Przez kanał żeglugowy przez Mierzeję Wiślaną przepłynęło od momentu otwarcia nowej drogi wodnej blisko tysiąc jednostek. Urząd Morski w Gdyni przypomina o zasadach bezpiecznej przeprawy.

## 1200 m kw. powierzchni. Latanie z banerem reklamowym wcale nie jest takie proste
 - [https://businessinsider.com.pl/wideo/latanie-z-banerem-reklamowym-wcale-nie-jest-takie-proste-1200-m-kw-powierzchni/c2wvfxc](https://businessinsider.com.pl/wideo/latanie-z-banerem-reklamowym-wcale-nie-jest-takie-proste-1200-m-kw-powierzchni/c2wvfxc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T08:21:00+00:00

Trudno nie obrócić głowy za samolotem, za którym przemieszcza się gigantyczny baner. A jak to wygląda od strony tych, którzy ciągną za sobą tę płachtę materiału?

## Finowie z przytupem weszli do NATO. Amerykańskie Zielone Berety już podają ich za przykład
 - [https://businessinsider.com.pl/wiadomosci/finowie-z-przytupem-weszli-do-nato-zielone-berety-juz-podaja-ich-na-przyklad/vhw6qxh](https://businessinsider.com.pl/wiadomosci/finowie-z-przytupem-weszli-do-nato-zielone-berety-juz-podaja-ich-na-przyklad/vhw6qxh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T08:17:45+00:00

Amerykańskie Zielone Berety uważają żołnierzy Finlandii, najnowszego kraju członkowskiego NATO, za "mentorów" w walce w trudnych zimowych warunkach. Przoduje tu pułk jegrów z garnizonu w Utti.

## Kolejne problemy Rosji. Najważniejszy targ odwołany
 - [https://businessinsider.com.pl/wiadomosci/kolejne-problemy-rosji-najwazniejszy-targ-odwolany/5hf92mt](https://businessinsider.com.pl/wiadomosci/kolejne-problemy-rosji-najwazniejszy-targ-odwolany/5hf92mt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T07:56:40+00:00

Rosja odwołała tegoroczną edycję najważniejszych w tym kraju międzynarodowych targów lotniczo-kosmicznych — MAKS, co wpisuje się w szereg problemów, z jakimi zmaga się rosyjski sektor lotniczo-kosmiczny — przekazało w niedzielę brytyjskie ministerstwo obrony.

## Zwierzak w cenie pokaźnej nieruchomości. Ceny psów i kotów zwalają z nóg
 - [https://businessinsider.com.pl/biznes/zwierzak-w-cenie-pokaznej-nieruchomosci-ceny-psow-i-kotow-zwalaja-z-nog/t5heqpz](https://businessinsider.com.pl/biznes/zwierzak-w-cenie-pokaznej-nieruchomosci-ceny-psow-i-kotow-zwalaja-z-nog/t5heqpz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T07:08:22+00:00

Pewien Chińczyk zapłacił za psa w 2014 r. rekordowe 2 mln dol. Rasa, którą wybrał, jest najdroższą rasą na świecie. Chiński nabywca pobił poprzedni rekord. Ten należał do mężczyzny, który zapłacił za szczeniaka 1,5 mln dol.

## Tych kredytów już nie ma, ale banki i tak się boją. Może ruszyć kolejna fala pozwów
 - [https://businessinsider.com.pl/finanse/tych-kredytow-juz-nie-ma-ale-banki-i-tak-sie-boja-kolejna-fala-pozwow/w23w01e](https://businessinsider.com.pl/finanse/tych-kredytow-juz-nie-ma-ale-banki-i-tak-sie-boja-kolejna-fala-pozwow/w23w01e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T07:03:48+00:00

Frankowicze podważają w sądach nie tylko czynne umowy kredytowe, ale także te spłacone. Na razie liczba takich spraw jest stosunkowo niewielka, ale korzystny dla kredytobiorców wyrok Trybunału Sprawiedliwości Unii Europejskiej najprawdopodobniej ją zwiększy. Pytanie tylko w jakim stopniu i jaki koszt poniosą banki.

## Zajrzyjcie do Wymarzonego Domu Barbie w Malibu – jest kiczowaty, wściekle różowy i dostępny do wynajęcia
 - [https://businessinsider.com.pl/wiadomosci/wymarzony-dom-barbie-w-malibu-jest-kiczowaty-wsciekle-rozowy-i-do-wynajecia/l82e5yx](https://businessinsider.com.pl/wiadomosci/wymarzony-dom-barbie-w-malibu-jest-kiczowaty-wsciekle-rozowy-i-do-wynajecia/l82e5yx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-02T06:59:00+00:00

Naturalnej wielkości replika willi najsławniejszej lalki pojawia się ponownie na Airbnb. Nocleg będzie bezpłatny.

