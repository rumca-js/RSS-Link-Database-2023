# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Limuzyna dla każdego z kierownictwa Kancelarii Premiera. Koszty mocno w górę
 - [https://www.money.pl/pieniadze/limuzyna-dla-kazdego-z-kierownictwa-kancelarii-premiera-koszty-mocno-w-gore-6915354631740128a.html](https://www.money.pl/pieniadze/limuzyna-dla-kazdego-z-kierownictwa-kancelarii-premiera-koszty-mocno-w-gore-6915354631740128a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-02T18:04:06+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/36e4acf4-4505-4691-b8aa-c0a40704fa8c" width="308" /> Każdy członek kierownictwa Kancelarii Prezesa Rady Ministrów ma do dyspozycji na stałe służbową limuzynę. Do końca kwietnia koszty obsługi tych aut sięgnęły już ponad 300 tys. zł - podaje ekonomista Rafał Mundry, powołując się na rządowe dane. To już blisko połowa tego, co przez cały ubiegły rok.

## Europejskie kraje chcą otworzyć się na konopie. Najpierw jednak muszą dogadać się z Brukselą
 - [https://www.money.pl/gospodarka/panstwa-europy-chca-otworzyc-sie-na-konopie-najpierw-jednak-musza-znalezc-porozumienie-6914894860741280a.html](https://www.money.pl/gospodarka/panstwa-europy-chca-otworzyc-sie-na-konopie-najpierw-jednak-musza-znalezc-porozumienie-6914894860741280a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-02T14:18:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f089ea43-b4fd-45fc-bd5a-9360c6cfe033" width="308" /> Europejskie państwa po kryzysach spowodowanych pandemią i wojną w Ukrainie poszukują dodatkowych pieniędzy zasilających ich budżety. Dlatego też coraz więcej krajów unijnych rozważa liberalizację prawa konopnego. Najpierw jednak będą musiały dogadać w tej sprawie z Brukselą.

## Protesty we Francji. Rabują sklepy. Nawet samochodem wjechali do Lidla
 - [https://www.money.pl/gospodarka/protesty-we-francji-rabuja-sklepy-nawet-samochodem-wjechali-do-lidla-6915241270483680a.html](https://www.money.pl/gospodarka/protesty-we-francji-rabuja-sklepy-nawet-samochodem-wjechali-do-lidla-6915241270483680a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-02T09:48:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0f6015ca-1425-43cc-836e-c1e21adcdd2f" width="308" /> We Francji trwają protesty, to efekt zastrzelenia przez policję w Nanterre pod Paryżem 17-letniego Nahela podczas kontroli drogowej. Policja w Marsylii aresztowała 14 osób podejrzanych o kradzieże. Lokalne media opisują rajdy grup ludzi wdzierających się do sklepów. Uczestnicy protestu wjechali nawet samochodem do Lidla.

## Rubel tonie. "Staje się pieniądzem Monopoly"
 - [https://www.money.pl/pieniadze/rubel-tonie-staje-sie-pieniadzem-monopoly-6915221821311648a.html](https://www.money.pl/pieniadze/rubel-tonie-staje-sie-pieniadzem-monopoly-6915221821311648a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-02T08:29:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/99526e6e-7a06-4d1f-8506-457b3384b843" width="308" /> Od tzw. buntu Prigożyna rosyjska waluta systematycznie słabnie. Dolar osiągnął już cenę w okolicach 90 rubli i wciąż utrzymuje się na tym samym poziomie, najwyższym od kilkunastu miesięcy.

## Rusza Bezpieczny Kredyt 2 proc. Szansa dla nielicznych i chwilowa sztuczka [OPINIA]
 - [https://www.money.pl/banki/rusza-bezpieczny-kredyt-2-proc-szansa-dla-nielicznych-i-chwilowa-sztuczka-opinia-6914955045092064a.html](https://www.money.pl/banki/rusza-bezpieczny-kredyt-2-proc-szansa-dla-nielicznych-i-chwilowa-sztuczka-opinia-6914955045092064a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-02T06:36:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f2091a02-a27d-4aed-a50d-3fd66a92a55a" width="308" /> Właśnie startuje program Bezpieczny Kredyt 2 proc. Czy są szanse na to, że zwiększy on dostępność mieszkań w Polsce? Tak, ale dla nielicznych, w krótkim horyzoncie czasowym - i w dalece niewystarczającym stopniu. Rządowy program to tylko chwilowa sztuczka, która na dłuższą metę nie zmieni zasadniczo sytuacji mieszkaniowej w Polsce.

## Przekop Mierzei Wiślanej. Pokazali liczby. Oto efekty sztandarowej inwestycji PiS
 - [https://www.money.pl/gospodarka/przekop-mierzei-wislanej-pokazali-liczby-oto-efekty-sztandarowej-inwestycji-pis-6915190056385184a.html](https://www.money.pl/gospodarka/przekop-mierzei-wislanej-pokazali-liczby-oto-efekty-sztandarowej-inwestycji-pis-6915190056385184a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-02T06:20:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ea856718-098a-4811-8c20-4d7f2935a248" width="308" /> Od 18 września 2022 r. do 22 czerwca tego roku przez kanał żeglugowy na Mierzei Wiślanej przepłynęło łącznie 991 jednostek - poinformowała rzeczniczka Urzędu Morskiego w Gdyni Magdalena Kierzkowska. Inwestycja kosztowała 2 mld zł.

## Stan epidemii odwołany. Oto konsekwencje dla pracodawców
 - [https://www.money.pl/gospodarka/stan-epidemii-odwolany-oto-konsekwencje-dla-pracodawcow-6915174445320864a.html](https://www.money.pl/gospodarka/stan-epidemii-odwolany-oto-konsekwencje-dla-pracodawcow-6915174445320864a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-02T05:16:46+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1c229d0d-b117-470a-b6a6-a0a6b70be975" width="308" /> 1 lipca nastąpiło odwołanie stanu zagrożenia epidemicznego,  co oznacza konsekwencje dla pracodawców. - Najpowszechniejszym powracającym obowiązkiem na pewno są kwestie badań i szkoleń BHP – powiedziała  radca prawny Monika Jurkiewicz.

