# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Crypto Miners Seek a New Life in AI Boom After an Implosion in Mining
 - [https://www.wsj.com/articles/crypto-miners-seek-a-new-life-in-ai-boom-after-an-implosion-in-mining-92a181fd?mod=rss_Technology](https://www.wsj.com/articles/crypto-miners-seek-a-new-life-in-ai-boom-after-an-implosion-in-mining-92a181fd?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-07-02T13:00:00+00:00

Demand for high-end chips allows cryptocurrency companies to repurpose idle equipment.

## Who Should Buy a Folding Phone
 - [https://www.wsj.com/articles/who-should-buy-a-folding-phone-2f658969?mod=rss_Technology](https://www.wsj.com/articles/who-should-buy-a-folding-phone-2f658969?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-07-02T13:00:00+00:00

Google’s new Pixel Fold and Samsung’s Galaxy Fold are video-streaming machines for long-haul commuters.

