# Source:Security Affairs, URL:https://securityaffairs.com/feed, language:en-US

## Security Affairs newsletter Round 426 by Pierluigi Paganini – International edition
 - [https://securityaffairs.com/148038/breaking-news/security-affairs-newsletter-round-426-by-pierluigi-paganini-international-edition.html](https://securityaffairs.com/148038/breaking-news/security-affairs-newsletter-round-426-by-pierluigi-paganini-international-edition.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-07-02T19:11:25+00:00

<p>A new round of the weekly SecurityAffairs newsletter arrived! Every week the best security articles from Security Affairs are free for you in your email box. Enjoy a new round of the weekly SecurityAffairs newsletter, including the international press. WordPress sites using the Ultimate Member plugin are under attack LockBit gang demands a $70 million [&#8230;]</p>
<p>The post <a href="https://securityaffairs.com/148038/breaking-news/security-affairs-newsletter-round-426-by-pierluigi-paganini-international-edition.html" rel="nofollow">Security Affairs newsletter Round 426 by Pierluigi Paganini – International edition</a> appeared first on <a href="https://securityaffairs.com" rel="nofollow">Security Affairs</a>.</p>

## WordPress sites using the Ultimate Member plugin are under attack
 - [https://securityaffairs.com/148030/hacking/wordpress-ultimate-member-plugin-attacks.html](https://securityaffairs.com/148030/hacking/wordpress-ultimate-member-plugin-attacks.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-07-02T06:36:18+00:00

<p>Threat actors are exploiting a critical WordPress zero-day in the Ultimate Member plugin to create secret admin accounts. Hackers are actively exploiting a critical unpatched WordPress Plugin flaw, tracked as CVE-2023-3460 (CVSS score: 9.8), to create secret admin accounts. Ultimate Member is a popular user profile and membership plugin for WordPress, it allows admins to [&#8230;]</p>
<p>The post <a href="https://securityaffairs.com/148030/hacking/wordpress-ultimate-member-plugin-attacks.html" rel="nofollow">WordPress sites using the Ultimate Member plugin are under attack</a> appeared first on <a href="https://securityaffairs.com" rel="nofollow">Security Affairs</a>.</p>

