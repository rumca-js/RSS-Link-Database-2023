# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## Dark Web Genesis Market for Sale: Operators Seek Buyers for Defunct Enterprise
 - [https://www.hackread.com/genesis-market-dark-net-for-sale/](https://www.hackread.com/genesis-market-dark-net-for-sale/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-07-11T18:48:11+00:00

<p>By <a href="https://www.hackread.com/author/habiba/" rel="nofollow">Habiba Rashid</a></p>
<p>Who would buy Genesis Market, which some speculate to be an FBI honeypot operation?</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/genesis-market-dark-net-for-sale/" rel="nofollow">Dark Web Genesis Market for Sale: Operators Seek Buyers for Defunct Enterprise</a></p>

## DDoS Attacks Soar by 168% on Government Services, StormWall Warns
 - [https://www.hackread.com/ddos-attacks-stormwall-q2-2023-report/](https://www.hackread.com/ddos-attacks-stormwall-q2-2023-report/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-07-11T17:10:33+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>The telecommunications sector also faced a significant onslaught in Q2 2023, becoming the second most targeted industry with an 83% YoY increase in DDoS attacks.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/ddos-attacks-stormwall-q2-2023-report/" rel="nofollow">DDoS Attacks Soar by 168% on Government Services, StormWall Warns</a></p>

## Apple Issues Device Updates to Patch Critical Vulnerability
 - [https://www.hackread.com/apple-device-updates-patch-vulnerability/](https://www.hackread.com/apple-device-updates-patch-vulnerability/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-07-11T11:52:21+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>The software vulnerability, identified as CVE-2023-37450, has raised concerns due to its potential for arbitrary code execution.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/apple-device-updates-patch-vulnerability/" rel="nofollow">Apple Issues Device Updates to Patch Critical Vulnerability</a></p>

