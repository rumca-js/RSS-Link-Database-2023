# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Szczyt NATO w Wilnie. Duda gotowy wysłać wojsko na Ukrainę! Zełenski rozczarowany postawą sojuszu!
 - [https://www.youtube.com/watch?v=Yv_v-QsEMbg](https://www.youtube.com/watch?v=Yv_v-QsEMbg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2023-07-11T21:13:17+00:00



