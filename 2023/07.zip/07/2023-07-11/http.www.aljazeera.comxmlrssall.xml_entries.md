# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Follower of US cult leader Charles Manson released from prison
 - [https://www.aljazeera.com/news/2023/7/11/follower-of-us-cult-leader-charles-manson-released-from-prison](https://www.aljazeera.com/news/2023/7/11/follower-of-us-cult-leader-charles-manson-released-from-prison)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T22:37:21+00:00

Leslie Van Houten, 73, was serving a sentence for fatally stabbing a store owner and his wife in Los Angeles in 1969.

## Jury declares pages from Aretha Franklin’s couch to be her will
 - [https://www.aljazeera.com/news/2023/7/11/jury-declares-pages-from-aretha-franklins-couch-to-be-her-will](https://www.aljazeera.com/news/2023/7/11/jury-declares-pages-from-aretha-franklins-couch-to-be-her-will)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T21:26:32+00:00

Franklin&#039;s sons have disputed which version of their mother&#039;s will is valid following the singer&#039;s 2018 death.

## NATO stops short of Ukraine invitation, angering Zelenskyy
 - [https://www.aljazeera.com/news/2023/7/11/nato-stops-short-of-ukraine-invitation-angering-zelenskyy](https://www.aljazeera.com/news/2023/7/11/nato-stops-short-of-ukraine-invitation-angering-zelenskyy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T21:20:26+00:00

Military alliance says it will invite Ukraine to become a member only when &#039;conditions are met&#039; but gives no timeline.

## Evidence in Canada lake indicates start of new Anthropocene epoch
 - [https://www.aljazeera.com/news/2023/7/11/evidence-in-canada-lake-indicates-start-of-new-anthropocene-epoch](https://www.aljazeera.com/news/2023/7/11/evidence-in-canada-lake-indicates-start-of-new-anthropocene-epoch)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T21:18:52+00:00

A group of scientists say human activity has fundamentally altered the geology, atmosphere and biology of the earth.

## Canada probes Nike, Dynasty Gold on forced Uighur labour in China
 - [https://www.aljazeera.com/economy/2023/7/11/canada-probes-nike-dynasty-gold-on-forced-uighur-labour-in-china](https://www.aljazeera.com/economy/2023/7/11/canada-probes-nike-dynasty-gold-on-forced-uighur-labour-in-china)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T21:06:35+00:00

Nike Canada and Dynasty Gold are alleged to have or have had supply chains or operations in China using forced labour.

## Bank of America fined $250m over junk fees, other issues
 - [https://www.aljazeera.com/economy/2023/7/11/bank-of-america-fined-250m-over-junk-fees-other-issues](https://www.aljazeera.com/economy/2023/7/11/bank-of-america-fined-250m-over-junk-fees-other-issues)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T21:04:44+00:00

CFPB has launched a crackdown on a range of so-called &#039;junk fees&#039; that it says lenders unfairly charge customers.

## Sudan rejects African peace bid and ‘enemy’ peacekeeping force
 - [https://www.aljazeera.com/news/2023/7/11/sudan-rejects-african-peace-bid-and-enemy-peacekeeping-force](https://www.aljazeera.com/news/2023/7/11/sudan-rejects-african-peace-bid-and-enemy-peacekeeping-force)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T20:50:05+00:00

Khartoum instead welcomes summit held by Egypt, widely seen as closer to the army than rival Rapid Support Forces.

## Why did Turkey change its mind on Sweden’s NATO membership?
 - [https://www.aljazeera.com/program/inside-story/2023/7/11/why-did-turkey-change-its-mind-on-swedens-nato-membership](https://www.aljazeera.com/program/inside-story/2023/7/11/why-did-turkey-change-its-mind-on-swedens-nato-membership)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T20:30:43+00:00

At its annual summit, the alliance is set to expand as it faces new security challenges.

## NGOs lose contact with Tunisian migrant group, bodies found
 - [https://www.aljazeera.com/news/2023/7/11/ngos-lose-contact-with-tunisian-migrant-group-bodies-found](https://www.aljazeera.com/news/2023/7/11/ngos-lose-contact-with-tunisian-migrant-group-bodies-found)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T19:59:42+00:00

Migrant rescue group says it has lost contact with a large group of Black African migrants expelled from Tunisia.

## Muslim nations demand action after ‘Islamophobic’ Quran burning
 - [https://www.aljazeera.com/news/2023/7/11/muslim-nations-demand-action-after-islamophobic-quran-burning](https://www.aljazeera.com/news/2023/7/11/muslim-nations-demand-action-after-islamophobic-quran-burning)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T19:38:55+00:00

Motion at UN Human Rights Council urges action over Quran burnings in Sweden that incite &#039;religious hatred&#039;.

## Cuba calls US nuclear submarine at Guantanamo Bay an ‘escalation’
 - [https://www.aljazeera.com/news/2023/7/11/cuba-calls-us-nuclear-submarine-at-guantanamo-bay-an-escalation](https://www.aljazeera.com/news/2023/7/11/cuba-calls-us-nuclear-submarine-at-guantanamo-bay-an-escalation)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T19:36:33+00:00

Havana says it &#039;strongly&#039; rejects the submarine&#039;s presence, describing it as a &#039;danger&#039; to sovereignty in the Caribbean.

## Thousands mourn Srebrenica victims as tensions mount in Bosnia
 - [https://www.aljazeera.com/news/2023/7/11/thousands-mourn-srebrenica-victims-as-tensions-mount-in-bosnia](https://www.aljazeera.com/news/2023/7/11/thousands-mourn-srebrenica-victims-as-tensions-mount-in-bosnia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T18:39:12+00:00

Dozens more victims of 1995 massacre buried after recently being identified through DNA analysis.

## Global shipping regulator underwhelms with new emissions targets
 - [https://www.aljazeera.com/economy/2023/7/11/global-shipping-regulator-underwhelms-with-new-emissions](https://www.aljazeera.com/economy/2023/7/11/global-shipping-regulator-underwhelms-with-new-emissions)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T18:17:24+00:00

New targets are to roll back emissions of freight ships that burn through millions of tonnes of dirty bunker fuel.

## Israeli protesters rally at airport to stop judicial overhaul
 - [https://www.aljazeera.com/news/2023/7/11/israeli-protesters-rally-at-airport-to-stop-judicial-overhaul](https://www.aljazeera.com/news/2023/7/11/israeli-protesters-rally-at-airport-to-stop-judicial-overhaul)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T18:11:38+00:00

Police arrest dozens in Tel Aviv as demonstrators mass at Ben Gurion Airport and in Jerusalem against gov&#039;t legislation.

## US judge turns down challenge to Microsoft merger with Activision
 - [https://www.aljazeera.com/news/2023/7/11/us-judge-turns-down-challenge-to-microsoft-merger-with-activision](https://www.aljazeera.com/news/2023/7/11/us-judge-turns-down-challenge-to-microsoft-merger-with-activision)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T17:29:21+00:00

Judge rejects challenge to $69bn acquisition in blow to efforts to crack down on economic consolidation in tech sector.

## Tyson Fury to face Francis Ngannou in boxing megafight
 - [https://www.aljazeera.com/sports/2023/7/11/tyson-fury-to-face-francis-ngannou-in-boxing-megafight](https://www.aljazeera.com/sports/2023/7/11/tyson-fury-to-face-francis-ngannou-in-boxing-megafight)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T17:07:56+00:00

Anticipated crossover bout to take place in Saudi Arabia&#039;s Riyadh on October 28.

## Ukraine’s Svitolina shocks Swiatek to reach Wimbledon semifinals
 - [https://www.aljazeera.com/news/2023/7/11/ukraines-svitolina-shocks-swiatek-to-reach-wimbledon-semifinals](https://www.aljazeera.com/news/2023/7/11/ukraines-svitolina-shocks-swiatek-to-reach-wimbledon-semifinals)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T17:00:10+00:00

Unseeded Ukrainian makes shock comeback over top seed to win 7-5, 6-7(5), 6-2 less than a year after giving birth.

## India hits online gaming with 28% tax
 - [https://www.aljazeera.com/economy/2023/7/11/india-hits-online-gaming-with-28-tax](https://www.aljazeera.com/economy/2023/7/11/india-hits-online-gaming-with-28-tax)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T16:46:25+00:00

Concerns have mounted over possible addiction to gaming apps and financial losses even as sector draws investors.

## Russia vetoes UN vote to extend key Syria aid route
 - [https://www.aljazeera.com/news/2023/7/11/russia-vetoes-un-vote-to-extend-key-syria-aid-route](https://www.aljazeera.com/news/2023/7/11/russia-vetoes-un-vote-to-extend-key-syria-aid-route)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T16:29:27+00:00

Russia proposes authorisation only be extended for six months rather than a nine-month compromise.

## Offensive defence: How Putin saved NATO
 - [https://www.aljazeera.com/opinions/2023/7/11/offensive-defence-how-putin-saved-nato](https://www.aljazeera.com/opinions/2023/7/11/offensive-defence-how-putin-saved-nato)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T16:21:39+00:00

In a period of great&nbsp;malaise&nbsp;in the West, the Russian president has given the alliance new meaning, mission and drive.

## What are France’s SCALP missiles, and how can they help Ukraine?
 - [https://www.aljazeera.com/news/2023/7/11/what-are-frances-scalp-missiles-and-how-can-they-help-ukraine](https://www.aljazeera.com/news/2023/7/11/what-are-frances-scalp-missiles-and-how-can-they-help-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T16:10:29+00:00

France to deliver deep-strike missiles to Ukraine as part of increased efforts to help its counteroffensive.

## Photos: Flash floods cause widespread damage in Northeast US
 - [https://www.aljazeera.com/gallery/2023/7/11/photos-flash-floods-cause-widespread-damage-in-northeast-us](https://www.aljazeera.com/gallery/2023/7/11/photos-flash-floods-cause-widespread-damage-in-northeast-us)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T16:09:17+00:00

Heavy rains washed out roads and forced evacuations in Vermont and other parts of the Northeast; more rains expected.

## Top Russian official says Poland wants to seize parts of Ukraine
 - [https://www.aljazeera.com/news/2023/7/11/top-russian-official-says-poland-wants-to-seize-parts-of-ukraine](https://www.aljazeera.com/news/2023/7/11/top-russian-official-says-poland-wants-to-seize-parts-of-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T15:42:41+00:00

Foreign ministry spokesperson Maria Zakharova touts theory often raised by Moscow without any evidence.

## Trump team asks to delay documents trial, citing election run-up
 - [https://www.aljazeera.com/news/2023/7/11/trump-team-asks-to-delay-documents-trial-citing-election-run-up](https://www.aljazeera.com/news/2023/7/11/trump-team-asks-to-delay-documents-trial-citing-election-run-up)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T15:00:27+00:00

Donald Trump is too busy campaigning for 2024 to prepare for US trial, lawyers say, asking for indefinite postponement.

## Why Turkey changed its stance on Sweden’s NATO membership
 - [https://www.aljazeera.com/news/2023/7/11/why-turkey-changed-its-stance-on-swedens-nato-membership-2](https://www.aljazeera.com/news/2023/7/11/why-turkey-changed-its-stance-on-swedens-nato-membership-2)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T14:04:15+00:00

Ankara supports Sweden&#039;s bid after it receives backing conditions from buying US F-16s to visa-free Schengen travel.

## China’s ‘wolf warrior’ foreign minister ill, to miss ASEAN summit
 - [https://www.aljazeera.com/news/2023/7/11/chinas-wolf-warrior-foreign-minister-ill-to-miss-asean-summit](https://www.aljazeera.com/news/2023/7/11/chinas-wolf-warrior-foreign-minister-ill-to-miss-asean-summit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T13:13:15+00:00

Wang Yi, the former foreign minister, will take his place at the summit in Indonesia, a spokesman said.

## Bat Couple: Nigeria’s bat researchers
 - [https://www.aljazeera.com/program/africa-direct/2023/7/11/bat-couple-nigerias-bat-researchers](https://www.aljazeera.com/program/africa-direct/2023/7/11/bat-couple-nigerias-bat-researchers)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T13:01:46+00:00

For the love of bats, and each other, one couple leads the way in bat conservation and research in Nigeria.

## As NATO meets on Ukraine, Russian officials fire warnings at West
 - [https://www.aljazeera.com/news/2023/7/11/russia-slams-nato-leaders-summit-in-vilnius](https://www.aljazeera.com/news/2023/7/11/russia-slams-nato-leaders-summit-in-vilnius)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T12:11:51+00:00

Russia has long objected to Ukrainian membership of the alliance. This week&#039;s meeting is stirring old arguments.

## Thailand PM Prayuth to retire from politics nine years after coup
 - [https://www.aljazeera.com/news/2023/7/11/thailand-pm-prayuth-to-retire-from-politics-nine-years-after-coup](https://www.aljazeera.com/news/2023/7/11/thailand-pm-prayuth-to-retire-from-politics-nine-years-after-coup)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T12:11:28+00:00

The former army chief&#039;s party lost May&#039;s election to a party challenging the royalist military establishment.

## Investments in private healthcare are not helping Africans
 - [https://www.aljazeera.com/opinions/2023/7/11/investments-in-private-healthcare-are-not-helping-africans](https://www.aljazeera.com/opinions/2023/7/11/investments-in-private-healthcare-are-not-helping-africans)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T11:48:55+00:00

Development finance institutions should use their funds to help improve universal public services across the continent.

## Olympic champion Caster Semenya wins testosterone ruling appeal
 - [https://www.aljazeera.com/news/2023/7/11/olympic-champion-caster-semenya-wins-testosterone-ruling-appeal](https://www.aljazeera.com/news/2023/7/11/olympic-champion-caster-semenya-wins-testosterone-ruling-appeal)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T10:57:25+00:00

Europe&#039;s top human rights court rules double Olympic champion can appeal testosterone limit for female athletes.

## Let’s talk about Jenin
 - [https://www.aljazeera.com/opinions/2023/7/11/lets-talk-about-jenin](https://www.aljazeera.com/opinions/2023/7/11/lets-talk-about-jenin)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T10:49:38+00:00

If we are to have sustainable peace in Palestine, we should set the record straight on what’s happening in Jenin.

## Pakistan gets $2bn from Saudi Arabia day before key IMF meeting
 - [https://www.aljazeera.com/news/2023/7/11/pakistan-gets-2bn-from-saudi-arabia-day-before-key-imf-meeting](https://www.aljazeera.com/news/2023/7/11/pakistan-gets-2bn-from-saudi-arabia-day-before-key-imf-meeting)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T10:34:36+00:00

Kingdom deposits money into Pakistan&#039;s central bank before critical meeting of global lender on $3bn bailout package.

## Australia ‘concerned’ by China-Solomon Islands policing deal
 - [https://www.aljazeera.com/news/2023/7/11/australia-concerned-by-china-solomon-islands-policing-deal](https://www.aljazeera.com/news/2023/7/11/australia-concerned-by-china-solomon-islands-policing-deal)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T10:31:58+00:00

Australia urges the nations to publish details of the police deal which it says will &#039;invite further regional contest&#039;.

## Azerbaijan accuses Red Cross of smuggling, shuts road to Karabakh
 - [https://www.aljazeera.com/news/2023/7/11/azerbaijan-accuses-red-cross-of-smuggling-shuts-road-to-karabakh](https://www.aljazeera.com/news/2023/7/11/azerbaijan-accuses-red-cross-of-smuggling-shuts-road-to-karabakh)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T10:01:46+00:00

Azerbaijan says the passage through Lachin checkpoint is closed due to a probe into smuggling by the Red Cross.

## India top court to hear pleas on Article 370 removal in Kashmir
 - [https://www.aljazeera.com/news/2023/7/11/india-top-court-to-hear-pleas-on-article-370-removal-in-kashmir](https://www.aljazeera.com/news/2023/7/11/india-top-court-to-hear-pleas-on-article-370-removal-in-kashmir)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T09:51:04+00:00

Supreme Court to begin hearing pleas challenging government&#039;s decision to revoke region&#039;s limited autonomy next month.

## Israel expels Sub Labans from their home in Jerusalem’s Old City
 - [https://www.aljazeera.com/news/2023/7/11/israel-expels-sub-labans-from-their-home-in-jerusalems-old-city](https://www.aljazeera.com/news/2023/7/11/israel-expels-sub-labans-from-their-home-in-jerusalems-old-city)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T09:43:54+00:00

The family fought settler attempts to take their home for about 45 years. On Monday night, security forces evicted them.

## Search under way for toddler missing for third day in French Alps
 - [https://www.aljazeera.com/news/2023/7/11/search-under-way-for-toddler-missing-for-third-day-in-french-alps](https://www.aljazeera.com/news/2023/7/11/search-under-way-for-toddler-missing-for-third-day-in-french-alps)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T09:34:19+00:00

Hundreds of volunteers are helping rescue services to look for a boy who went missing in the village of Haut-Vernet.

## What does Sudan’s crisis mean for the gum arabic industry?
 - [https://www.aljazeera.com/news/2023/7/11/what-does-sudan-crisis-mean-for-the-gum-arabic-industry](https://www.aljazeera.com/news/2023/7/11/what-does-sudan-crisis-mean-for-the-gum-arabic-industry)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T09:23:43+00:00

War between Sudanese army and paramilitary RSF threatens an industry that provides income for millions, analysts say.

## ‘I knew it was a risk’: A Nigerian migrant sex worker in Ghana
 - [https://www.aljazeera.com/features/2023/7/11/i-knew-it-was-a-risk-a-nigerian-migrant-sex-worker-in-ghana](https://www.aljazeera.com/features/2023/7/11/i-knew-it-was-a-risk-a-nigerian-migrant-sex-worker-in-ghana)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T09:09:54+00:00

How one woman made a desperate cross-border sacrifice to build a better life for her family and get them out of poverty.

## Five killed in Nepal tourist chopper crash near Mount Everest
 - [https://www.aljazeera.com/news/2023/7/11/five-killed-in-nepal-tourist-chopper-crash-near-mount-everest](https://www.aljazeera.com/news/2023/7/11/five-killed-in-nepal-tourist-chopper-crash-near-mount-everest)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T08:55:06+00:00

The chopper went missing in Solukhunvhu district, home to Mount Everest and other high mountain peaks, authorities say.

## Soaring demand for honey keeps Jordan’s beekeepers busy
 - [https://www.aljazeera.com/gallery/2023/7/11/soaring-demand-for-honey-keeps-jordans-beekeepers-busy](https://www.aljazeera.com/gallery/2023/7/11/soaring-demand-for-honey-keeps-jordans-beekeepers-busy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T08:46:51+00:00

Jordan prides itself on producing 19 different types of honey, including citrus, eucalyptus and maple.

## Daily life returns to Jenin camp after Israeli raid
 - [https://www.aljazeera.com/gallery/2023/7/11/daily-life-returns-to-jenin-camp-after-israeli-raid](https://www.aljazeera.com/gallery/2023/7/11/daily-life-returns-to-jenin-camp-after-israeli-raid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T08:19:00+00:00

A week from the Israeli offensive, residents are slowly going back to their lives, rebuilding what they can.

## Market for clean energy minerals surges to $320bn: IEA
 - [https://www.aljazeera.com/news/2023/7/11/market-for-clean-energy-minerals-surges-to-320bn-iea](https://www.aljazeera.com/news/2023/7/11/market-for-clean-energy-minerals-surges-to-320bn-iea)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T08:01:32+00:00

The market remains vulnerable to volatile prices, supply chain snarls and geopolitical tensions despite soaring demand.

## Volcano erupts near Iceland’s capital
 - [https://www.aljazeera.com/gallery/2023/7/11/volcano-erupts-near-icelands-capital](https://www.aljazeera.com/gallery/2023/7/11/volcano-erupts-near-icelands-capital)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T07:54:38+00:00

Iceland has 33 volcanic systems currently considered active, the highest number in Europe.

## Egyptians launch online campaign for Gamal Mubarak as president
 - [https://www.aljazeera.com/news/2023/7/11/egyptians-launch-online-campaign-for-gamal-mubarak-as-president](https://www.aljazeera.com/news/2023/7/11/egyptians-launch-online-campaign-for-gamal-mubarak-as-president)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T07:10:33+00:00

Campaigners launch Twitter hashtag and Facebook page, calling for Gamal Mubarak to run for president in April 2024.

## Can Putin recover from the Wagner mutiny?
 - [https://www.aljazeera.com/features/2023/7/11/can-putin-recover-from-the-wagner-mutiny](https://www.aljazeera.com/features/2023/7/11/can-putin-recover-from-the-wagner-mutiny)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T07:03:23+00:00

Russia&#039;s elites are distancing themselves from Putin, even if they won&#039;t revolt just yet, say analysts.

## New Zealand starts trial into 2019 White Island volcano disaster
 - [https://www.aljazeera.com/news/2023/7/11/new-zealand-starts-trial-into-2019-white-island-volcano-disaster](https://www.aljazeera.com/news/2023/7/11/new-zealand-starts-trial-into-2019-white-island-volcano-disaster)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T07:03:04+00:00

The owners of the island face charges over disaster that killed 22 people and seriously hurt dozens.

## ‘Continent of opportunities’: Iran’s Raisi kicks off Africa tour
 - [https://www.aljazeera.com/news/2023/7/11/continent-of-opportunities-irans-raisi-kicks-off-africa-tour](https://www.aljazeera.com/news/2023/7/11/continent-of-opportunities-irans-raisi-kicks-off-africa-tour)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T06:31:33+00:00

President is heading to Africa one month after a three-country trip to Latin America.

## World Population Day: What will the world look like in 2050?
 - [https://www.aljazeera.com/news/2023/7/11/world-population-day-what-will-the-world-look-like-in-2050](https://www.aljazeera.com/news/2023/7/11/world-population-day-what-will-the-world-look-like-in-2050)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T06:27:33+00:00

By 2050, after India and China, Nigeria is expected to become the world&#039;s third most populous nation.

## Vietnam officials go on trial over alleged COVID flight bribes
 - [https://www.aljazeera.com/economy/2023/7/11/vietnam-officials-go-on-trial-over-alleged-covid-flight-bribes](https://www.aljazeera.com/economy/2023/7/11/vietnam-officials-go-on-trial-over-alleged-covid-flight-bribes)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T06:27:25+00:00

More than 50 officials are accused of corruption over repatriation flights during the COVID-19 pandemic.

## Libya jails 38 over deaths in Mediterranean Sea smuggling case
 - [https://www.aljazeera.com/news/2023/7/11/libya-jails-38-over-deaths-in-mediterranean-sea-smuggling-case](https://www.aljazeera.com/news/2023/7/11/libya-jails-38-over-deaths-in-mediterranean-sea-smuggling-case)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T04:59:21+00:00

Five get life in jail over a trafficking case involving 11 people who died trying to cross the Mediterranean to Europe.

## Australian democracy activist freed from prison in Vietnam
 - [https://www.aljazeera.com/news/2023/7/11/australian-democracy-activist-freed-from-prison-in-vietnam](https://www.aljazeera.com/news/2023/7/11/australian-democracy-activist-freed-from-prison-in-vietnam)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T04:10:30+00:00

Chau Van Kham, who had been in jail for four years on national security charges, has returned home to Australia.

## Russian submarine commander killed by gunman on morning run
 - [https://www.aljazeera.com/news/2023/7/11/russian-submarine-commander-killed-by-gunman-on-morning-run](https://www.aljazeera.com/news/2023/7/11/russian-submarine-commander-killed-by-gunman-on-morning-run)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T04:07:01+00:00

Online news outlets claimed that Stanislav Rzhitsky was involved in a Russian missile attack on Ukraine that killed 23.

## Facebook owner Meta tells inquiry it will label state actors
 - [https://www.aljazeera.com/economy/2023/7/11/facebook-owner-meta-tells-inquiry-it-will-label-state-actors](https://www.aljazeera.com/economy/2023/7/11/facebook-owner-meta-tells-inquiry-it-will-label-state-actors)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T03:44:13+00:00

Executive tells Australian inquiry government-linked accounts will be identified on new Twitter-like platform Threads.

## Indonesia’s electric battery hub bid clouded by mining deaths
 - [https://www.aljazeera.com/economy/2023/7/11/indonesias-electric-battery-hub-bid-clouded-by-mining-deaths](https://www.aljazeera.com/economy/2023/7/11/indonesias-electric-battery-hub-bid-clouded-by-mining-deaths)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T03:41:11+00:00

Safety standards in Southeast Asian country&#039;s nickel mining industry are under scrutiny after spate of fatal accidents.

## Australia to deploy surveillance aircraft to assist Ukraine
 - [https://www.aljazeera.com/news/2023/7/11/australia-to-deploy-surveillance-aircraft-to-assist-ukraine](https://www.aljazeera.com/news/2023/7/11/australia-to-deploy-surveillance-aircraft-to-assist-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T03:25:56+00:00

The Wedgetail with as many as 100 crew and support staff will operate from Germany for at least six months.

## Russian attack on Ukrainian aid distribution point kills 7
 - [https://www.aljazeera.com/news/2023/7/11/russian-attack-on-ukrainian-aid-distribution-point-kills-7](https://www.aljazeera.com/news/2023/7/11/russian-attack-on-ukrainian-aid-distribution-point-kills-7)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T02:52:23+00:00

Zaporizhia Governor Yuriy Malashko says Russian attack on school where humanitarian aid distributed a &#039;war crime&#039;.

## Dubious digital banking in India’s Bank of Baroda
 - [https://www.aljazeera.com/economy/2023/7/11/dubious-digital-banking-in-indias-bank-of-baroda](https://www.aljazeera.com/economy/2023/7/11/dubious-digital-banking-in-indias-bank-of-baroda)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T02:36:53+00:00

Second-largest gov&#039;t-owned bank linked mobile numbers of strangers to boost app registrations, compromising security.

## India’s Bank of Baroda tampered with accounts to flog app
 - [https://www.aljazeera.com/economy/2023/7/11/indias-bank-of-baroda-misused-customer-data-to-flog-app](https://www.aljazeera.com/economy/2023/7/11/indias-bank-of-baroda-misused-customer-data-to-flog-app)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T02:36:53+00:00

Second-largest gov&#039;t-owned bank linked mobile numbers of strangers to boost app registrations, compromising security.

## US charges Israeli-US think tank head with being Chinese agent
 - [https://www.aljazeera.com/news/2023/7/11/us-charges-israeli-us-think-tank-head-with-being-chinese-agent](https://www.aljazeera.com/news/2023/7/11/us-charges-israeli-us-think-tank-head-with-being-chinese-agent)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T02:07:34+00:00

Gal Luft, who is a US and Israeli citizen, was arrested in Cyprus in February but fled after he was granted bail.

## UN told Israel turns Palestinian territory into outdoor prison
 - [https://www.aljazeera.com/news/2023/7/11/un-told-israel-turns-palestinian-territory-into-outdoor-prison](https://www.aljazeera.com/news/2023/7/11/un-told-israel-turns-palestinian-territory-into-outdoor-prison)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T01:59:02+00:00

UN expert says some 800,000 Palestinians, including children as young as 12, detained by Israel since 1967 occupation.

## What does hosting Miss World mean for India today?
 - [https://www.aljazeera.com/program/the-stream/2023/7/11/what-does-hosting-miss-world-mean-for-india-today](https://www.aljazeera.com/program/the-stream/2023/7/11/what-does-hosting-miss-world-mean-for-india-today)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T01:58:13+00:00

Notorious for sparking violent protests, an international beauty pageant returns to India.

## Russia-Ukraine war: List of key events, day 503
 - [https://www.aljazeera.com/news/2023/7/11/russia-ukraine-war-list-of-key-events-day-503](https://www.aljazeera.com/news/2023/7/11/russia-ukraine-war-list-of-key-events-day-503)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-11T00:46:45+00:00

As the conflict enters its 503rd day, these are the main developments.

