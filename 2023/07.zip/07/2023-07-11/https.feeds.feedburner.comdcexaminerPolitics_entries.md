# Source:Washington Examiner - politics, URL:https://feeds.feedburner.com/dcexaminer/Politics, language:en-US

## Georgia lawmaker announces departure from Democratic Party, describing it as 'moral' decision
 - [https://www.washingtonexaminer.com/news/georgia-lawmaker-departure-democratic-party-moral-decision](https://www.washingtonexaminer.com/news/georgia-lawmaker-departure-democratic-party-moral-decision)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-07-11T18:10:59+00:00

Rep. Mesha Mainor (D-GA) announced Tuesday that she is leaving the Democratic Party.

