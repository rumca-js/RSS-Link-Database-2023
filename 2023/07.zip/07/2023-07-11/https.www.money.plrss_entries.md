# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Pompy ciepła na zaciągniętym hamulcu ręcznym. Sprzedaż wyhamowała
 - [https://www.money.pl/gospodarka/pompy-ciepla-na-zaciagnietym-hamulcu-recznym-sprzedaz-wyhamowala-6918569611365312a.html](https://www.money.pl/gospodarka/pompy-ciepla-na-zaciagnietym-hamulcu-recznym-sprzedaz-wyhamowala-6918569611365312a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T19:31:42+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/87d66d7c-efe5-4d8d-99be-a7edcb705050" width="308" /> Jeszcze niedawno wszyscy obserwowali boom na rynku pomp ciepła. Tymczasem po tłustych latach nadszedł chudy okres i sprzedaż mocno wyhamowała. Sektor ten także odczuwa skutki inflacji na dwucyfrowym poziomie i wysokich stóp procentowych.

## Nowy trop w sprawie wysadzenia Nord Stream 2. Prowadzi do Rosjanki
 - [https://www.money.pl/gospodarka/nowy-trop-w-sprawie-wysadzenia-nord-stream-2-prowadzi-do-rosjanki-6918551193906016a.html](https://www.money.pl/gospodarka/nowy-trop-w-sprawie-wysadzenia-nord-stream-2-prowadzi-do-rosjanki-6918551193906016a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T18:16:42+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5f122c59-e5e3-47fc-bca5-24bb9cd5e20e" width="308" /> W wysadzenie gazociągów Nord Stream i Nord Steram 2 zamieszana jest obywatelka Rosji – podała niemiecka telewizja RTL. Jej firma miała wynająć w Polsce łódź, która później miała zostać wykorzystana w domniemanym sabotażu.

## Jedna decyzja PiS-u może kosztować pracę 40 tys. osób. Posypią się pozwy
 - [https://www.money.pl/gospodarka/jedna-decyzja-pis-u-moze-kosztowac-prace-40-tys-osob-posypia-sie-pozwy-6918535889394528a.html](https://www.money.pl/gospodarka/jedna-decyzja-pis-u-moze-kosztowac-prace-40-tys-osob-posypia-sie-pozwy-6918535889394528a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T17:14:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1a6b7126-2302-4166-b968-be51df3ff1cb" width="308" /> Nawet 40 tys. osób w Polsce może stracić pracę w instytucjach uznanych za "organy bezpieczeństwa PRL". Osoby te już piszą w tej sprawie do Rzecznika Praw Obywatelskich. A urzędnik podpowiada: mogą składać pozwy o przywrócenie do pracy lub odszkodowanie.

## "Urząd wie". Pracujący na czarno dostają pisma ze skarbówki
 - [https://www.money.pl/podatki/urzad-wie-pracujacy-na-czarno-dostaja-pisma-ze-skarbowki-6918522304146272a.html](https://www.money.pl/podatki/urzad-wie-pracujacy-na-czarno-dostaja-pisma-ze-skarbowki-6918522304146272a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T16:54:06+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d7f2affe-628c-401f-9bf1-39fa183215fd" width="308" /> Fiskus śle listy do osób pracujących na czarno, w których ostrzega, że wie o ich biznesie i wzywa do zarejestrowania działalności i płacenia podatków. Eksperci tłumaczą, że w dobie internetu i mediów społecznościowych bardzo łatwo jest namierzyć takie osoby.

## Wiaczesław Mosze Kantor ma udziały w Grupie Azoty. Polskie władze chcą go z niej usunąć
 - [https://www.money.pl/gospodarka/wiaczeslaw-mosze-kantor-ma-udzialy-w-grupie-azoty-polskie-wladze-chca-go-z-niej-usunac-6918502273387360a.html](https://www.money.pl/gospodarka/wiaczeslaw-mosze-kantor-ma-udzialy-w-grupie-azoty-polskie-wladze-chca-go-z-niej-usunac-6918502273387360a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T15:50:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c7cba473-651d-4c8b-9229-87dab85dbb9f" width="308" /> Udziały Wiaczesława Mosze Kantora w Azotach od lat są cierniem w oku kolejnych ekip rządzących. W 2012 r. należący do oligarchy Acron postawił Polskę w stan gotowości, gdy chciał dokonać wrogiego przejęcia w tarnowskiej spółce. Co wiemy o tym miliarderze?

## Wcześniejsze emerytury nauczycieli. Ważne zmiany w projekcie
 - [https://www.money.pl/emerytury/wczesniejsze-emerytury-nauczycieli-wazne-zmiany-w-projekcie-6918510812396480a.html](https://www.money.pl/emerytury/wczesniejsze-emerytury-nauczycieli-wazne-zmiany-w-projekcie-6918510812396480a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T15:32:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ff4435e3-b5a3-4c04-9b40-a189cdfd8ec6" width="308" /> Senacka Komisja Nauki, Edukacji i Sportu opowiedziała się za kilkunastoma poprawkami do nowelizacji ustawy Karta Nauczyciela oraz niektórych innych ustaw. Wśród poprawek popartych przez większość komisji są poprawki dotyczące emerytur stażowych i świadczeń kompensacyjnych.

## Rosyjski oligarcha traci majątek w Polsce. "Ruch wyprzedzający"
 - [https://www.money.pl/gospodarka/rosyjski-oligarcha-traci-majatek-w-polsce-ruch-wyprzedzajacy-6918456136788832a.html](https://www.money.pl/gospodarka/rosyjski-oligarcha-traci-majatek-w-polsce-ruch-wyprzedzajacy-6918456136788832a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T14:01:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/27cdba36-f105-4cfc-ab84-d718643331f7" width="308" /> Ministerstwo Rozwoju i Technologii ustanowiło tymczasowego zarządcę przymusowego na majątku rosyjskiego oligarchy Wiaczesława Kantora w Grupie Azoty. - Zakładam, że jest to ruch wyprzedzający, podjęty na podstawie informacji, a nie spóźnione działanie rządu - mówi Piotr Woźniak, były prezes PGNiG.

## Największy wycieczkowiec świata przechodzi testy. Jego pierwszy rejs już za pół roku
 - [https://www.money.pl/gospodarka/najwiekszy-wycieczkowiec-swiata-przechodzi-testy-jego-pierwszy-rejs-juz-za-pol-roku-6918480977722208a.html](https://www.money.pl/gospodarka/najwiekszy-wycieczkowiec-swiata-przechodzi-testy-jego-pierwszy-rejs-juz-za-pol-roku-6918480977722208a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T13:31:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/762b1338-046a-4f59-b8e6-65bd98f788fd" width="308" /> Icon of the Seas, największy statek wycieczkowy na świecie, wypłynął na otwarte wody – przekazało biuro prasowe Royal Caribbean International. Ta firma właśnie stoi za budową wycieczkowca. Za pół roku gigant ma wypłynąć w dziewiczy rejs.

## Karton pomidorów do tony węgla. Tak się chcą pozbyć zalegającego surowca
 - [https://www.money.pl/gospodarka/karton-pomidorow-do-tony-wegla-tak-sie-chca-pozbyc-zalegajacego-surowca-6918477761383360a.html](https://www.money.pl/gospodarka/karton-pomidorow-do-tony-wegla-tak-sie-chca-pozbyc-zalegajacego-surowca-6918477761383360a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T13:18:00+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5607cdbc-e189-4699-8d3d-b06022bcefba" width="308" /> Kiedy kończył się sezon grzewczy, na gminnych składowiskach zalegało prawie 100 ton niesprzedanego węgla - informuje portalsamorzadowy.pl. Choć sprzedaż  trwa, to w tym momencie nie ma kolejki chętnych, więc gminy szukają pomysłów, aby przyciągnąć klientów.

## Złoty w czołówce walut na świecie. Oto dlaczego tak się dzieje
 - [https://www.money.pl/pieniadze/euro-dolar-zloty-w-czolowce-walut-na-swiecie-oto-dlaczego-tak-sie-dzieje-6918393647995840a.html](https://www.money.pl/pieniadze/euro-dolar-zloty-w-czolowce-walut-na-swiecie-oto-dlaczego-tak-sie-dzieje-6918393647995840a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T08:40:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e8821263-8617-4369-9869-ac8a8b9ba951" width="308" /> Polski złoty umacnia się w tym roku w dosyć niespodziewany sposób. Jak zauważa Michał Stajniak z domu maklerskiego XTB, kurs złotego zyskał aż 20 proc. do dolara od dołka z października 2022 r., a w tym roku mocniejszy od naszej waluty w Europie jest tylko forint. Powodów jest co najmniej kilka.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 11.07.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-11-07-2023-6918356198792032a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-11-07-2023-6918356198792032a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T05:03:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 11.07.2023. We wtorek za jednego franka (CHF) trzeba zapłacić 4.5554 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 11.07.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-11-07-2023-6918356198652864a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-11-07-2023-6918356198652864a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T05:03:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 11.07.2023. We wtorek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.1887 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 11.07.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-11-07-2023-6918356195789664a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-11-07-2023-6918356195789664a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T05:03:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 11.07.2023. We wtorek za jednego dolara (USD) trzeba zapłacić 4.0283 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 11.07.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-11-07-2023-6918356195752896a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-11-07-2023-6918356195752896a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-11T05:03:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 11.07.2023. We wtorek za jedno euro (EUR) trzeba zapłacić 4.4394 zł.

