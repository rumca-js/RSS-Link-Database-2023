# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## The James Webb telescope's first photo of Saturn
 - [https://www.lemonde.fr/en/science/article/2023/07/11/the-james-webb-telescope-s-first-photo-of-saturn_6049236_10.html](https://www.lemonde.fr/en/science/article/2023/07/11/the-james-webb-telescope-s-first-photo-of-saturn_6049236_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-07-11T08:01:33+00:00

One year after its launch, the James Webb Space Telescope turned its attention to Saturn for the first time.

