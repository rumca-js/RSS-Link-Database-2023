# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## GPD G1 First Look, The Smallest eGPU With The Power You Want! Oculink & USB4
 - [https://www.youtube.com/watch?v=KuKKc66wrsc](https://www.youtube.com/watch?v=KuKKc66wrsc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-07-11T14:06:00+00:00

The all New GPD G1 eGPU Is the The Smallest Graphics Card Expansion Dock and it supports Oculink and USB4! The GPD G1 is a compact external graphics dock with an AMD Radeon RX 7600M XT discrete GPU. with 32 RDNA 3 compute units, 8GB of GDDR6 memory and 32MB of AMD Infinity Cache. It can deliver up to 21.4 TFLOPS of “peak single precision compute performance and it’s all packed into a super tiny ultra Portable eGPU. Perfect the for the New GPD Win Max 2 and Win4 with Oculink ports or any other device that supports USB4 or Thunderbolt 4 external graphics.

GPD G1 Indiegogo: https://www.indiegogo.com/projects/gpd-g1-the-smallest-graphics-card-expansion-dock/coming_soon

Learn More Here:: https://www.gpd.hk/gpdg1graphics
Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME
12400 Wake Union Church Rd PMB #239
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

00:00 Introduction
00:20 Unboxing GPD G1 eGPU
01:01 Overview GPD G1 eGPU
01:57 Oculink Graphics Card
03:03 Specs GPD G1 eGPU
03:50 Setup GPD G1 eGPU
06:09 Benchmark and Gaming Cyberpunk 2077 GPD G1 eGPU
07:26 USB4 Testing Mini PC GPD G1 eGPU
09:08 First Impressions

#GPD #eGPU #AMD #etaprime

## Best Amazon Prime Day Deals Under $100! 2023
 - [https://www.youtube.com/watch?v=swildoCRFC8](https://www.youtube.com/watch?v=swildoCRFC8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-07-11T12:00:50+00:00

In this video we take a look at some of the best Amazon Prime day Deals Ive found so far Under $100!
Fire TV’s Fir Sticks, Xbox and PS5 Controllers, Micro SD cards and More.

Silicon Power 1TB Superior Micro: https://amzn.to/44ueTiF
SanDisk 128GB Extreme microSDXC: https://amzn.to/3rfcOsN
2021 Fire 10 Tablet: https://amzn.to/3XAja1Y
WD_BLACK 1TB SN770: https://amzn.to/43ioath
SAMSUNG T7 1TB, Portable SSD: https://amzn.to/46K2b1p
Amazon Fire TV 43" Omni Series 4K UHD: https://amzn.to/3O4GOk2
Fire Sticks: https://amzn.to/43i29dV
Screwdriver Set: https://amzn.to/3D8saBO
Toshiba Canvio Advance 4TB: https://amzn.to/3O5NqOS
Xbox Controllers:https://amzn.to/3CVHbqC
Renewed Xbox S: https://amzn.to/43d2BtW
Logitech G435 LIGHTSPEED: https://amzn.to/3XFjfS7
SAMSUNG 980 PRO SSD 2TB: https://amzn.to/44wva6Y
Also Check Out Best Buy For Sales during Prime Day:https://howl.me/cj5SiSnLbgy

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME
12400 Wake Union Church Rd PMB #239
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#amazon #primedaydreamdeals #etaprime

