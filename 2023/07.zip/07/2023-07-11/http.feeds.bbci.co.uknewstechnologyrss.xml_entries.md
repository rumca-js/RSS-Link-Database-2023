# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Microsoft's deal to buy Call of Duty maker boosted by US judge
 - [https://www.bbc.co.uk/news/entertainment-arts-66099230?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66099230?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-07-11T17:24:22+00:00

The Federal Trade Commission in the US had sought to block the proposed merger on competition grounds.

## Universal Credit: Warnings over AI use to risk-score benefit claims
 - [https://www.bbc.co.uk/news/uk-politics-66133665?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66133665?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-07-11T16:17:56+00:00

Campaign groups say more transparency is needed to avoid potential bias over benefit investigations.

## Online Safety Bill: Algorithms that lead boys to Andrew Tate content targeted
 - [https://www.bbc.co.uk/news/technology-66164222?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-66164222?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-07-11T14:36:08+00:00

The government is defeated by peers who want to stop social media algorithms causing harm.

## Privacy activists slam EU-US pact on data sharing
 - [https://www.bbc.co.uk/news/world-us-canada-66161135?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66161135?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-07-11T03:00:48+00:00

The deal overcame objections about US intelligence agencies' level of access to European data.

