# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## The Best Chapter Books for Preschoolers, According to NYPL Librarians
 - [https://lifehacker.com/14-really-good-chapter-books-for-preschoolers-that-libr-1819312259](https://lifehacker.com/14-really-good-chapter-books-for-preschoolers-that-libr-1819312259)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T22:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--QxFgX_r3--/c_fit,fl_progressive,q_80,w_636/624909953f47ecb8e3abf47a43514eba.jpg" /><p>There comes a time when the long-suffering parent just <em>can’t</em> read <a href="https://zdcs.link/EvKvP" rel="noopener noreferrer" target="_blank"><em>The Little Blue Truck</em></a><em> </em>one more time. Or <a href="https://zdcs.link/JY7YD" rel="noopener noreferrer" target="_blank"><em>My First Farm Book</em></a>, with its disturbing implication that there will be more farm books to come. Or even <a href="https://zdcs.link/1qMqR" rel="noopener noreferrer" target="_blank"><em>Blueberries for Sal</em></a>, my favorite for the preschool crowd, but one I’ve now read so many times I want to rip…</p><p><a href="https://lifehacker.com/14-really-good-chapter-books-for-preschoolers-that-libr-1819312259">Read more...</a></p>

## Where to Watch 'What We Do in the Shadows' Season 5 (and What You Should Know About It)
 - [https://lifehacker.com/where-to-watch-what-we-do-in-the-shadows-season-5-and-1850671440](https://lifehacker.com/where-to-watch-what-we-do-in-the-shadows-season-5-and-1850671440)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T22:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--EMh1HyD5--/c_fit,fl_progressive,q_80,w_636/e3252b94bf4cc8b045ad8a79bf885096.jpg" /><p>The supernatural mockumentary <em>What We Do in the Shadows </em>follows the misadventures of four  vampire roommates living in Staten Island, New York. The laughs come from just how out of touch they are with the modern world, and how their human companion begrudgingly helps them navigate. The show is based a 2014 New Zealand…</p><p><a href="https://lifehacker.com/where-to-watch-what-we-do-in-the-shadows-season-5-and-1850671440">Read more...</a></p>

## Where to Watch 'Futurama' Season 11 (and What You Should Know About It)
 - [https://lifehacker.com/where-to-watch-futurama-season-11-and-what-you-should-1850672318](https://lifehacker.com/where-to-watch-futurama-season-11-and-what-you-should-1850672318)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--iJTuBckf--/c_fit,fl_progressive,q_80,w_636/f74c251531447f57f931c02a148640db.png" /><p>After a 10-year hiatus, <em>Futurama</em> is back once again, this time as a soft reboot. <em>Futurama</em> has been canceled and renewed several times before (and the show does a great job of making jokes about it), but this time we’ll get at least two more seasons out of the deal: It was ordered by Hulu for not only an 11th season,…</p><p><a href="https://lifehacker.com/where-to-watch-futurama-season-11-and-what-you-should-1850672318">Read more...</a></p>

## You Should Roast a Whole Head of Garlic
 - [https://lifehacker.com/how-to-roast-a-whole-head-of-garlic-1820407305](https://lifehacker.com/how-to-roast-a-whole-head-of-garlic-1820407305)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T21:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--td71Ph1o--/c_fit,fl_progressive,q_80,w_636/77f5d1b68a17d6c33164031d75e57114.jpg" /><p>Garlic is great in any of its many forms but, like most plant parts, it is at its absolute best when roasted. Roasting garlic  mellows its pungency and tempers its aggressive bite, but it also intensifies its sweetness and creates new, deeper flavors through caramelization and that lovely little <a href="https://en.wikipedia.org/wiki/Maillard_reaction" rel="noopener noreferrer" target="_blank">Maillard reaction</a>.…</p><p><a href="https://lifehacker.com/how-to-roast-a-whole-head-of-garlic-1820407305">Read more...</a></p>

## You Can Get a Lifetime of iBrave Cloud Web Hosting for $100
 - [https://lifehacker.com/you-can-get-a-lifetime-of-ibrave-cloud-web-hosting-for-1850665713](https://lifehacker.com/you-can-get-a-lifetime-of-ibrave-cloud-web-hosting-for-1850665713)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--dwxUXxET--/c_fit,fl_progressive,q_80,w_636/4a3e7ef132f2c9739b5b85ea5095c3b5.png" /><p>Many web hosting services are cheap but are based on monthly subscriptions. If you want a permanent option, <a href="https://shop.lifehacker.com/sales/ibrave-cloud-web-hosting-lifetime-subscription?utm_source=lifehacker.com&amp;utm_medium=referral&amp;utm_campaign=ibrave-cloud-web-hosting-lifetime-subscription&amp;utm_term=scsf-575442&amp;utm_content=a0x1P000004IvXTQA0&amp;scsonar=1">iBrave Cloud Web Hosting has a lifetime subscription for $99.99 right now</a>. It’s a higher initial price but cheaper in the long run if you keep your site long term.</p><p><a href="https://lifehacker.com/you-can-get-a-lifetime-of-ibrave-cloud-web-hosting-for-1850665713">Read more...</a></p>

## 'Trash' Your Next Batch of Wings
 - [https://lifehacker.com/trash-your-next-batch-of-wings-1850675472](https://lifehacker.com/trash-your-next-batch-of-wings-1850675472)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--TvH1-a4R--/c_fit,fl_progressive,q_80,w_636/c16adfc38c9a6ac4ac900e67ece14551.jpg" /><p>Whether they’re <a href="https://lifehacker.com/instant-pot-buffalo-wings-are-fast-easy-and-very-good-1822565911" target="_blank">steamed</a>, <a href="https://lifehacker.com/sous-vide-buffalo-wings-are-crispy-on-the-outside-and-t-1819914472" target="_blank">sous-vided</a>, or parboiled before frying, my favorite wings are usually cooked twice. Similar to pouring <a href="https://lifehacker.com/you-should-pour-boiling-water-on-your-chicken-thighs-1850280449" target="_blank">boiling water over chicken thighs</a>, par-cooking wings before a final fry renders out some of the fat and breaks down connective tissue, resulting in juicier meat and crispier skin. Most common…</p><p><a href="https://lifehacker.com/trash-your-next-batch-of-wings-1850675472">Read more...</a></p>

## The Best Tech Gadgets for Working on the Go
 - [https://lifehacker.com/the-best-tech-gadgets-for-working-on-the-go-1850674553](https://lifehacker.com/the-best-tech-gadgets-for-working-on-the-go-1850674553)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WbCMWdF5--/c_fit,fl_progressive,q_80,w_636/bdd0a7ee8ab9396c9062dac6d0c794c6.png" /><p>In the post-pandemic world, sometimes you work from an office. Sometimes you work from home. Sometimes you work from a mysterious third place, hopefully with a lot of sun (or at least good coffee). Whether that’s by the pool, on a plane, or from that cafe you love, there are gadgets that can help you be more…</p><p><a href="https://lifehacker.com/the-best-tech-gadgets-for-working-on-the-go-1850674553">Read more...</a></p>

## Make These Cheap and Healthy Meals With Stuff Already in Your Pantry
 - [https://lifehacker.com/make-these-cheap-and-healthy-meals-with-stuff-already-i-1850674725](https://lifehacker.com/make-these-cheap-and-healthy-meals-with-stuff-already-i-1850674725)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--BqOu0ZP1--/c_fit,fl_progressive,q_80,w_636/f6baff45781db5e630b42ad0c607b60c.jpg" /><p>I love a pantry meal. No worrying about whether you’ll get a chance to make it before the ingredients go bad, no making a special trip to the store for that one ingredient that you never seem to have on hand—just a quick bite that is ready to go at any moment. And those are the cheap and healthy meals we’re looking at…</p><p><a href="https://lifehacker.com/make-these-cheap-and-healthy-meals-with-stuff-already-i-1850674725">Read more...</a></p>

## The Easiest Ways to Cheat at a Step-Counting Challenge
 - [https://lifehacker.com/how-to-cheat-at-a-step-counting-challenge-1839476401](https://lifehacker.com/how-to-cheat-at-a-step-counting-challenge-1839476401)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T19:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--oIRuIyQs--/c_fit,fl_progressive,q_80,w_636/f7krufgvon3aq9unyluz.jpg" /><p>A Fitbit or other step-counting challenge can be a great way to inspire yourself to be active. But then again, it’s easier to just sit on the couch and <em>pretend</em> you’re logging tons of steps. Here are a few ways to game the system, even though ultimately you’re just cheating yourself.<br /></p><p><a href="https://lifehacker.com/how-to-cheat-at-a-step-counting-challenge-1839476401">Read more...</a></p>

## You Should Try Google Assistant's 'Bedtime' Routine
 - [https://lifehacker.com/you-should-try-google-assistants-bedtime-routine-1850672240](https://lifehacker.com/you-should-try-google-assistants-bedtime-routine-1850672240)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--c5peOrHj--/c_fit,fl_progressive,q_80,w_636/7826e27d916d7d64126dde95e1c1a9c3.jpg" /><p>If you tend to lie awake in bed, anxious about what you’ve forgotten to do today or prepare for tomorrow, it’s likely you’re not taking advantage of Google Assistant’s “Bedtime” routine. Once you’ve set it up, you can simply say “Goodnight” to Google through any device, and Assistant will execute an automated set of…</p><p><a href="https://lifehacker.com/you-should-try-google-assistants-bedtime-routine-1850672240">Read more...</a></p>

## Export Your Bookmarks So You Can Finally Quit Twitter
 - [https://lifehacker.com/export-your-bookmarks-so-you-can-finally-quit-twitter-1850674081](https://lifehacker.com/export-your-bookmarks-so-you-can-finally-quit-twitter-1850674081)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--GsDeaI8e--/c_fit,fl_progressive,q_80,w_636/27aab4cdd03c306a59cf72861a6a545f.png" /><p>It’s hard to quit something you actually find useful. Case in point: Twitter (<a href="https://lifehacker.com/how-to-delete-your-twitter-account-when-youve-had-enoug-1848798491" target="_blank">or maybe now “X</a>”?) Sure, the site has been actively on fire for the better part of a year, but there are still a lot of interesting and funny people tweeting away. You probably have a lot of those tweets saved to your Bookmarks, which…</p><p><a href="https://lifehacker.com/export-your-bookmarks-so-you-can-finally-quit-twitter-1850674081">Read more...</a></p>

## You Should Poach Your Next Chicken
 - [https://lifehacker.com/maximize-a-chickens-meal-potential-by-poaching-it-first-1822353539](https://lifehacker.com/maximize-a-chickens-meal-potential-by-poaching-it-first-1822353539)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T18:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--3bX9GaFG--/c_fit,fl_progressive,q_80,w_636/0ad143e7db548510bf10a00fde6fb1b6.jpg" /><p>If you read about cooking online, you’ve no doubt seen several listicles that tout the many uses of a single, humble chicken. At this point, you know what a chicken can do for you, so another overly-prescriptive, chicken-based meal plan seems unnecessary. My agenda here is very simple: The next time you buy a whole…</p><p><a href="https://lifehacker.com/maximize-a-chickens-meal-potential-by-poaching-it-first-1822353539">Read more...</a></p>

## Where to Watch 'The Witcher' Season 3, Part 2 (and What You Should Know About It)
 - [https://lifehacker.com/where-to-watch-the-witcher-season-3-part-2-and-what-y-1850671856](https://lifehacker.com/where-to-watch-the-witcher-season-3-part-2-and-what-y-1850671856)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s---t5W6fD_--/c_fit,fl_progressive,q_80,w_636/73a341e841066597017298916bcb2e11.png" /><p>After two and a half seasons, Geralt of Rivia (Henry Cavill) is returning for the second part of <em>The Witcher</em>’s third season. Season 3 of <em>The Witcher</em> had been broken into two parts: Part one included five episodes and aired on June 29, and part two will drop the season’s final three episodes on Thursday, July 27. Three…</p><p><a href="https://lifehacker.com/where-to-watch-the-witcher-season-3-part-2-and-what-y-1850671856">Read more...</a></p>

## This 6-in-1 Charging Cable Is $22 Right Now
 - [https://lifehacker.com/this-6-in-1-charging-cable-is-22-right-now-1850665758](https://lifehacker.com/this-6-in-1-charging-cable-is-22-right-now-1850665758)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Rityw6hk--/c_fit,fl_progressive,q_80,w_636/7d23c7295e2948135f933c85b98567ba.png" /><p>Carrying a separate cable for each of your smart devices is impractical, and cables that split into multiple connectors often get tangled just as easily. The InCharge X Max 100W 6-in-1 Charging Cable folds to reveal different types of connectors, so you can use one cable for USB-C, Micro, USB, and Lighting devices,…</p><p><a href="https://lifehacker.com/this-6-in-1-charging-cable-is-22-right-now-1850665758">Read more...</a></p>

## Here’s How Much Your Old Pokémon Cards Could Be Worth
 - [https://lifehacker.com/how-much-are-your-pokemon-cards-worth-lately-1846888650](https://lifehacker.com/how-much-are-your-pokemon-cards-worth-lately-1846888650)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T17:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ZTLKbNPk--/c_fit,fl_progressive,q_80,w_636/d76788ca1d96dba95b52393e2115e3e8.jpg" /><p>Some people let wine age in their basement cellars knowing every day gets them closer to a more desirable and higher-quality product. Others  do the same with their Pokémon cards, hoping their delayed gratification will help pay off their student loans some day. Knowing how much a card is worth is easy now, thanks to…</p><p><a href="https://lifehacker.com/how-much-are-your-pokemon-cards-worth-lately-1846888650">Read more...</a></p>

## How to Watch Every Christopher Nolan Film on Streaming
 - [https://lifehacker.com/how-to-watch-every-christopher-nolan-film-on-streaming-1850670190](https://lifehacker.com/how-to-watch-every-christopher-nolan-film-on-streaming-1850670190)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--S59BQn3z--/c_fit,fl_progressive,q_80,w_636/e705a5821ce256e562e01c9b21fbdf44.jpg" /><p>Last weekend was <a href="https://apnews.com/article/barbie-oppenheimer-barbenheimer-box-office-3ff25c0a3acf7b568866c2ff307d0108" rel="noopener noreferrer" target="_blank">a big one at the box office</a>, with director Greta Gerwig’s <em>Barbie</em> netting $155 million in North American ticket sales and Christopher Nolan’s three-hour <em>Oppenheimer</em> bringing in $80.5 million (and “Barbenheimer” making up the fourth-largest weekend in box office history). </p><p><a href="https://lifehacker.com/how-to-watch-every-christopher-nolan-film-on-streaming-1850670190">Read more...</a></p>

## Your ‘Dopamine Fast’ Could Backfire
 - [https://lifehacker.com/why-your-dopamine-fast-could-backfire-1850664408](https://lifehacker.com/why-your-dopamine-fast-could-backfire-1850664408)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--X1tAy2fZ--/c_fit,fl_progressive,q_80,w_636/7e6f9354a50580b8390aaf9acdea910b.jpg" /><p>In the same brand of pop culture shorthand that labels oxytocin the “love hormone” and cortisol the “stress hormone,” dopamine is classified as the “reward” chemical we deliver ourselves a dose of every time we experience something pleasurable. Of course, real life is never that simple.<br /></p><p><a href="https://lifehacker.com/why-your-dopamine-fast-could-backfire-1850664408">Read more...</a></p>

## Download Your Tweets Before Quitting Twitter
 - [https://lifehacker.com/download-your-tweets-before-quitting-twitter-1849778871](https://lifehacker.com/download-your-tweets-before-quitting-twitter-1849778871)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--08d791Ve--/c_fit,fl_progressive,q_80,w_636/391ac4885a20982fd0603342ab1bf4f9.jpg" /><p>Twitter’s days are numbered. That’s not a prediction, mind you, nor is the company officially going under: Elon Musk, rather, is  rebranding the company as “X,” starting with a <a href="https://lifehacker.com/how-to-delete-your-twitter-account-when-youve-had-enoug-1848798491" target="_blank">mediocre logo that replaces the iconic bird</a>. While there have been plenty of reasons to delete your account in the past year, perhaps no…</p><p><a href="https://lifehacker.com/download-your-tweets-before-quitting-twitter-1849778871">Read more...</a></p>

## What to Do When You Get Chills While Working Out
 - [https://lifehacker.com/what-to-do-when-you-get-chills-while-working-out-1850671737](https://lifehacker.com/what-to-do-when-you-get-chills-while-working-out-1850671737)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--QCMBLYnL--/c_fit,fl_progressive,q_80,w_636/70bb8911793e1097603a53f1ae53ee4d.jpg" /><p>Have you ever been in the middle of a run and gotten hit with a sudden wave of chills, goosebumps, or shivers, even though it’s hot as hades outside? Feeling cold and shivery when you’re working out isn’t uncommon, especially when it’s hot and humid, and isn’t harmful in itself—but it is an early warning of heat…</p><p><a href="https://lifehacker.com/what-to-do-when-you-get-chills-while-working-out-1850671737">Read more...</a></p>

## Thicken Your Salad Dressing With Cooked Egg Yolks
 - [https://lifehacker.com/thicken-your-salad-dressing-with-cooked-egg-yolks-1850671825](https://lifehacker.com/thicken-your-salad-dressing-with-cooked-egg-yolks-1850671825)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--mKltpGF---/c_fit,fl_progressive,q_80,w_636/eabcece199a190d21e12bbc072ec6254.jpg" /><p>I’m a huge fan of creamy salad dressings, but I almost never use them. The bottled stuff often has an overwhelming synthetic flavor, and a lot of homemade recipes are too mayonnaise-dominant for my taste. Fortunately, there’s a simple trick to add body and subtle richness to any liquid-y salad dressing: Add cooked egg…</p><p><a href="https://lifehacker.com/thicken-your-salad-dressing-with-cooked-egg-yolks-1850671825">Read more...</a></p>

## These Are the Cheapest Vacation Destinations in the U.S. Right Now
 - [https://lifehacker.com/these-are-the-cheapest-vacation-destinations-in-the-u-s-1850670621](https://lifehacker.com/these-are-the-cheapest-vacation-destinations-in-the-u-s-1850670621)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Au_3iQ49--/c_fit,fl_progressive,q_80,w_636/e1ae5c68a18c3dc8e3190d57d1b21871.jpg" /><p>It can be hard to relax and genuinely enjoy yourself on a vacation that you know you can’t afford. Splurging on a bucket list trip is one thing, but the costs of the average solo, family, or group getaway also add up quickly, and can end up being a source of stress both during the trip, and in the time it takes you to…</p><p><a href="https://lifehacker.com/these-are-the-cheapest-vacation-destinations-in-the-u-s-1850670621">Read more...</a></p>

## What an AI Girlfriend Can (and Can't) Do
 - [https://lifehacker.com/what-an-ai-girlfriend-can-and-cant-do-1850666245](https://lifehacker.com/what-an-ai-girlfriend-can-and-cant-do-1850666245)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WV2cqJcL--/c_fit,fl_progressive,q_80,w_636/b4392bbb45b12138cf48ff90bf14ec78.jpg" /><p>I’ve been trying to cheat on my wife with an artificial intelligence all week, and it’s proving so difficult I might have to resort to an affair with a human being.<br /></p><p><a href="https://lifehacker.com/what-an-ai-girlfriend-can-and-cant-do-1850666245">Read more...</a></p>

## Don't Use These Common, Bad Ways to Clean Your Glasses
 - [https://lifehacker.com/dont-do-these-things-when-you-clean-your-glasses-1849183886](https://lifehacker.com/dont-do-these-things-when-you-clean-your-glasses-1849183886)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T14:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--evlfmnh8--/c_fit,fl_progressive,q_80,w_636/3d8638d5c1ba9c896ab2c669d6a257cb.jpg" /><p>For the most part, people wear eyeglasses to improve their vision. They go through the whole “which is better, A or B?” routine with their optometrist to find the right prescription; pick out frames; end up being talked into multiple special coatings ... and then clean their smudged lenses with the bottom of their…</p><p><a href="https://lifehacker.com/dont-do-these-things-when-you-clean-your-glasses-1849183886">Read more...</a></p>

## This Refurbished MacBook Pro Is $470 Right Now
 - [https://lifehacker.com/this-refurbished-macbook-pro-is-470-right-now-1850665681](https://lifehacker.com/this-refurbished-macbook-pro-is-470-right-now-1850665681)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Qe3Yeq3u--/c_fit,fl_progressive,q_80,w_636/dca22db3f5d44edebb87f0a21bc7a70d.png" /><p>This <a href="https://shop.lifehacker.com/sales/apple-macbook-pro-mpxq2ll-a-2017-13-3-core-i5-8gb-ram-128gb-hdd-space-gray?utm_source=lifehacker.com&amp;utm_medium=referral&amp;utm_campaign=apple-macbook-pro-mpxq2ll-a-2017-13-3-core-i5-8gb-ram-128gb-hdd-space-gray&amp;utm_term=scsf-575441&amp;utm_content=a0x1P000004IvXSQA0&amp;scsonar=1" target="_blank">refurbished MacBook Pro is on sale for $469.99</a>. It was originally manufactured in 2017 and great for budget-conscious students or professionals. You won’t want to get this computer if you need a laptop that can run heavy art programs with all your Google Chrome tabs open, but it’s worth considering if you need a…</p><p><a href="https://lifehacker.com/this-refurbished-macbook-pro-is-470-right-now-1850665681">Read more...</a></p>

## Drizzle a Little Honey on Your Tomatoes
 - [https://lifehacker.com/drizzle-a-little-honey-on-your-tomatoes-1850671917](https://lifehacker.com/drizzle-a-little-honey-on-your-tomatoes-1850671917)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1oPpCPW8--/c_fit,fl_progressive,q_80,w_636/dddc52d83cfd468f9d6b4ce9f57a8ffb.jpg" /><p> One of my favorite sides is exceedingly simple: sliced, fresh tomatoes with a little salt (extra credit  if they’re served on <a href="https://www.tasteofhome.com/article/blue-willow-china/" rel="noopener noreferrer" target="_blank">Blue Willow</a> china). Ripe summer tomatoes don’t need much adornment, and I tend to be mulish about involving unnecessary ingredients, so when I saw a woman drizzling honey on her tomato toast,…</p><p><a href="https://lifehacker.com/drizzle-a-little-honey-on-your-tomatoes-1850671917">Read more...</a></p>

## My Favorite Ways to Get Kids Out the Door in the Morning
 - [https://lifehacker.com/get-kids-moving-in-the-morning-with-these-tricks-1831870445](https://lifehacker.com/get-kids-moving-in-the-morning-with-these-tricks-1831870445)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T13:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--X30PZJHB--/c_fit,fl_progressive,q_80,w_636/12bf93dc673eabf19f86107492a1ca0d.jpg" /><p>Back-to-school time is fast approaching, which means the struggle to get out the door <em>(on time)</em> is, once again, also upon us. As any veteran parent knows, successfully leaving the house<em> </em>in the morning <em>really</em> starts the night before. Packing up lunches, stuffing homework into backpacks, and having shoes ready and…</p><p><a href="https://lifehacker.com/get-kids-moving-in-the-morning-with-these-tricks-1831870445">Read more...</a></p>

## All the Credit Cards That Give You Free Checked Bags
 - [https://lifehacker.com/all-the-credit-cards-that-give-you-free-checked-bags-1850669786](https://lifehacker.com/all-the-credit-cards-that-give-you-free-checked-bags-1850669786)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--xBTgbrwa--/c_fit,fl_progressive,q_80,w_636/65fc1fb72d7f2b07e1832edc28e02315.jpg" /><p>As if airfare wasn’t costly enough on its own, these days you usually need to factor in at least $35 for dreaded checked bag fees. And that’s just one-way, so needless to say, the costs of checking your bags adds up quick. </p><p><a href="https://lifehacker.com/all-the-credit-cards-that-give-you-free-checked-bags-1850669786">Read more...</a></p>

## How to Break Out of Eggshell Parenting
 - [https://lifehacker.com/how-to-break-out-of-eggshell-parenting-1850670721](https://lifehacker.com/how-to-break-out-of-eggshell-parenting-1850670721)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T12:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--s7rRkmOG--/c_fit,fl_progressive,q_80,w_636/7a77d82bff6cd14322c4c06ebe2b53e7.jpg" /><p>If you’re reading this, we don’t have to tell you parenting is a roller coaster of emotion. One moment you’re frustrated trying to get your kids ready for school, and the next, you’re laughing over something cute or funny your kid said. But some parents wear their emotions on their sleeve <em>too </em>much, randomly crying…</p><p><a href="https://lifehacker.com/how-to-break-out-of-eggshell-parenting-1850670721">Read more...</a></p>

## How I Became a Board Game Writer
 - [https://lifehacker.com/how-i-became-a-board-game-writer-1850610140](https://lifehacker.com/how-i-became-a-board-game-writer-1850610140)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-07-25T12:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--rPi1IWYK--/c_fit,fl_progressive,q_80,w_636/ba31281ab6ba3ad09646f7e6c68310cc.jpg" /><p>Welcome to “How I Became,” a new Lifehacker series where I ask real people about how they <em>really</em> got their jobs. This week I had the pleasure of chatting with Devon Lara Lucas, freelance board game content developer. I met Lucas in 2016 when I was an intern at Hasbro; I was learning the ropes on the Monopoly team,…</p><p><a href="https://lifehacker.com/how-i-became-a-board-game-writer-1850610140">Read more...</a></p>

