# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## She Committed The Dumbest Crime...
 - [https://www.youtube.com/watch?v=_VLEWCNF9aU](https://www.youtube.com/watch?v=_VLEWCNF9aU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-07-25T22:43:21+00:00

Hello guys and gals, it's me Mutahar again! This time we finish our look into Carlee Russell and unsurprisingly she admitted to faking her disappearance. This puts to rest one of the weirdest stories of the year and take away here is to realize never to do this, not because you'll get caught eventually but it could seriously cost someone who actually needs help. Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the newest podcast episode: https://youtu.be/Xl2Mi1zPhRw

