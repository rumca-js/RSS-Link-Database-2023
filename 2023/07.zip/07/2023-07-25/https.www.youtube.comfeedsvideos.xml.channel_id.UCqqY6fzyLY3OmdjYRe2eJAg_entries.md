# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## Roosevelt - 'Paralyzed' (Official Video)
 - [https://www.youtube.com/watch?v=FiBiGNrZrsg](https://www.youtube.com/watch?v=FiBiGNrZrsg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2023-07-25T09:53:02+00:00

Subscribe: https://found.ee/rv-ys

Directed by Unlimited Time Only (https://unlimitedtimeonly.com)

Follow Roosevelt -
Spotify: https://found.ee/rv-sp
Apple Music: https://found.ee/rv-am
YouTube: https://found.ee/rv-yt
Bandcamp: https://found.ee/rv-bc
Soundcloud: https://found.ee/rv-sc
Instagram: https://found.ee/rv-ig
TikTok: https://found.ee/rv-tt
Facebook: https://found.ee/rv-fb
Twitter: https://found.ee/rv-tw

#Roosevelt #CounterRecords

