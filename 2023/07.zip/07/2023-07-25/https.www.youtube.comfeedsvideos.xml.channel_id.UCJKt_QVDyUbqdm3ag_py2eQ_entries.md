# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: JazzCat & Virgill - The Loop demo OST (A500r6a🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=5-M53T0BEvs](https://www.youtube.com/watch?v=5-M53T0BEvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2023-07-25T18:05:09+00:00

Soundtrack from "The Loop" demo (Ghostown & Haujobb) by JazzCat & Virgill. Demo ranked 5th at Revision 2023.
Art from the demo.

Watch the demo in action here:
https://www.youtube.com/watch?v=QlfDhb4YviI

Made using real A500r6a audio.

Visit my channel for more Amiga music.

