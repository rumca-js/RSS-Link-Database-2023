# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Judge Blocks Biden Administration Border Policy Limiting Access To Illegal Immigrants Seeking Asylum
 - [https://www.dailywire.com/news/judge-blocks-biden-administration-border-policy-limiting-access-to-illegal-immigrants-seeking-asylum](https://www.dailywire.com/news/judge-blocks-biden-administration-border-policy-limiting-access-to-illegal-immigrants-seeking-asylum)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T19:17:12+00:00

A Biden administration rule limiting immigrants other than Mexican nationals from seeking asylum in the United States was blocked Tuesday by a federal judge. U.S. District Judge Jon S. Tigar ruled against the Biden administration order, which mirrors the Trump-era &#8220;transit ban&#8221; policy requiring migrants entering through the southern border to apply online first for ...

## Rapid Reaction: Both Biden And His Pup Are In The Dog House
 - [https://www.dailywire.com/news/rapid-reaction-both-biden-and-his-pup-are-in-the-dog-house](https://www.dailywire.com/news/rapid-reaction-both-biden-and-his-pup-are-in-the-dog-house)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T18:24:37+00:00

Come for Morning Wire’s Afternoon Update’s straight news, but stay for the Rapid Reactions. The following five stories, and more, can be heard on today’s Morning Wire Afternoon Update podcast. Click here to listen.  1. House Speaker Raises Prospect Of Impeachment Inquiry House Speaker Kevin McCarthy (R-CA) doubled down on his claims on Tuesday that ...

## Smugglers Caught Using Fake Border Patrol Truck To Sneak In Migrants
 - [https://www.dailywire.com/news/smugglers-caught-using-fake-border-patrol-truck-to-sneak-in-migrants](https://www.dailywire.com/news/smugglers-caught-using-fake-border-patrol-truck-to-sneak-in-migrants)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T17:48:17+00:00

Smugglers were caught using a fake U.S. Customs and Border Protection (CBP) truck to try to sneak migrants over the U.S. border in California on Saturday. The truck, which was tricked out in Border Patrol decal stickers and fake Department of Homeland Security license plates to resemble a real CBP truck, was initially spotted by ...

## Woman Plunges To Death From 100-Foot Cliff After Marriage Proposal
 - [https://www.dailywire.com/news/woman-plunges-to-death-from-100-foot-cliff-after-marriage-proposal](https://www.dailywire.com/news/woman-plunges-to-death-from-100-foot-cliff-after-marriage-proposal)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T17:42:50+00:00

A newly engaged woman plunged to her death after she fell over the edge of a 100-foot scenic seaside cliff in Turkey only minutes after her boyfriend got down on one knee and proposed. Yesim Demir, 39, had gone to the romantic spot with the would-be-groom Nizamettin Gursu where the two were just about to ...

## Joe Biden Is A Liar. He Knew.
 - [https://www.dailywire.com/news/joe-biden-is-a-liar-he-knew](https://www.dailywire.com/news/joe-biden-is-a-liar-he-knew)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T17:38:20+00:00

Joe Biden is a liar.  We know for a fact that Joe Biden knew about his son&#8217;s businesses, despite the narrative pushed by Biden that their connection is purely on the up and up. Every single time, Joe Biden claimed he never knew a damn thing about his son&#8217;s business, that Joe Biden himself was ...

## Senior DHS Official: Cartel Smuggling Business Booming Under Biden
 - [https://www.dailywire.com/news/senior-dhs-official-cartel-smuggling-business-booming-under-biden](https://www.dailywire.com/news/senior-dhs-official-cartel-smuggling-business-booming-under-biden)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T17:02:50+00:00

The cartel human smuggling business is booming under President Joe Biden&#8217;s watch. Don&#8217;t take my word for it; listen to his Assistant Secretary for Border and Immigration Policy, Blas Nunez-Neto. On Tuesday, Breitbart reported that Nunez-Neto recently said, &#8220;We see migrants now routinely paying smuggling organizations vast sums of money — often more than $10,000 ...

## ‘It’s Egregious’: School Board Members Battle Gov. Newsom’s Personal Attacks, Threats Of Fines, Legal Action
 - [https://www.dailywire.com/news/its-egregious-school-board-members-battle-gov-newsoms-personal-attacks-threats-of-fines-legal-action](https://www.dailywire.com/news/its-egregious-school-board-members-battle-gov-newsoms-personal-attacks-threats-of-fines-legal-action)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T16:48:56+00:00

Following pressure from Governor Gavin Newsom (D-CA) &#8212; including the threat of a $1.5 million fine and legal “repercussions” &#8212; a Southern California school district has reversed course to adopt a state-approved curriculum the school board initially rejected. Three newly-elected board members for the Temecula Valley Unified School District &#8212; Joseph Komrosky, Jen Wiersma, and Danny Gonzalez ...

## You Do Not Need To Take A Picture Of Every Single Thing You Experience In Your Life
 - [https://www.dailywire.com/news/you-do-not-need-to-take-a-picture-of-every-single-thing-you-experience-in-your-life](https://www.dailywire.com/news/you-do-not-need-to-take-a-picture-of-every-single-thing-you-experience-in-your-life)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T16:47:24+00:00

A major controversy erupted last week involving a country singer. I’m not talking about Jason Aldean.  I’m talking about Miranda Lambert, who ignited a fierce and important debate when she made the decision to stop in the middle of her concert in Las Vegas to lecture some fans in the front row who were taking ...

## More Than 1,000 NYC Fare Beaters Had Active Arrest Warrants: Report
 - [https://www.dailywire.com/news/more-than-1000-nyc-fare-beaters-had-active-arrest-warrants-report](https://www.dailywire.com/news/more-than-1000-nyc-fare-beaters-had-active-arrest-warrants-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T16:46:07+00:00

More than 1,000 people who tried to skip out on paying to ride the New York City subway reportedly had active arrest warrants for other crimes, including one man who was accused of murder. Police were already looking to arrest about 1,136 of the 2,502 New Yorkers arrested for subway fare beating this year according ...

## Hillary Clinton Says MAGA Republicans Are The Reason Summer Is Hot
 - [https://www.dailywire.com/news/hillary-clinton-says-maga-republicans-are-the-reason-summer-is-hot](https://www.dailywire.com/news/hillary-clinton-says-maga-republicans-are-the-reason-summer-is-hot)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T16:31:50+00:00

Former Secretary of State Hillary Clinton has determined that this summer is excessively hot — and rather than the earth’s tilt coupled with the time of year, it’s “MAGA Republicans” who are at fault. Clinton shared a graphic from the Center for American Progress, which showed a series of headlines about heatwaves and record high ...

## House Committee Moves Forward With Plan To Hold Meta CEO Mark Zuckerberg In Contempt
 - [https://www.dailywire.com/news/house-committee-moves-forward-with-plan-to-hold-meta-ceo-mark-zuckerberg-in-contempt](https://www.dailywire.com/news/house-committee-moves-forward-with-plan-to-hold-meta-ceo-mark-zuckerberg-in-contempt)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T16:28:34+00:00

Months after subpoenaing Meta CEO Mark Zuckerberg as part of a censorship investigation, a GOP-led House panel announced on Tuesday a plan to move forward with trying to punish the Big Tech executive for allegedly not complying with its demands. The Judiciary Committee, led by Chairman Jim Jordan (R-OH), said a markup session is scheduled ...

## U.S. Failed To Track All Military Aid To Ukraine As Criminal Gangs Stole Guns, Ammo From Frontlines
 - [https://www.dailywire.com/news/u-s-failed-to-track-all-military-aid-to-ukraine-as-criminal-gangs-stole-guns-ammo-from-frontlines](https://www.dailywire.com/news/u-s-failed-to-track-all-military-aid-to-ukraine-as-criminal-gangs-stole-guns-ammo-from-frontlines)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T16:15:15+00:00

A report just made public from the inspector general for the Department of Defense shows that the U.S. could not track all of the weapons and military equipment it had sent to Ukraine even as criminal gangs in the country have illicitly obtained military weapons. The report, first filed in October 2022, was just released ...

## U.S. Marine Veteran Trevor Reed, Ex-Russian Prisoner Exchanged For Drug Trafficker, Injured While Fighting In Ukraine: Report
 - [https://www.dailywire.com/news/u-s-marine-veteran-trevor-reed-ex-russian-prisoner-exchanged-for-drug-trafficker-injured-while-fighting-in-ukraine-report](https://www.dailywire.com/news/u-s-marine-veteran-trevor-reed-ex-russian-prisoner-exchanged-for-drug-trafficker-injured-while-fighting-in-ukraine-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T16:02:32+00:00

U.S. Marine veteran Trevor Reed, who was released from a Russian prison in exchange for a convicted Russian drug trafficker, has been injured while fighting in Ukraine, the State Department reportedly said on Tuesday. &#8220;We&#8217;re aware that Trevor Reed was injured while participating in fighting in Ukraine,&#8221; a Biden administration official told The Messenger. State ...

## CNN Witnesses 3 People Stealing From Walgreens Over 30 Minutes In Democrat-Controlled City
 - [https://www.dailywire.com/news/cnn-witnesses-3-people-stealing-from-walgreens-over-30-minutes-in-democrat-controlled-city](https://www.dailywire.com/news/cnn-witnesses-3-people-stealing-from-walgreens-over-30-minutes-in-democrat-controlled-city)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T15:58:12+00:00

A CNN film crew witnesses three people stealing from inside a Walgreens in San Francisco this week in the span of just 30 minutes. The store, which is one of the most robbed Walgreens in the country, has had to resort to locking up most items in the store behind chains or plexiglass. CNN senior ...

## Russia Bans Transgender Medical Procedures, Changing Genders On Documents, Adoptions By Trans People
 - [https://www.dailywire.com/news/russia-bans-transgender-medical-procedures-changing-genders-on-documents-adoptions-by-trans-people](https://www.dailywire.com/news/russia-bans-transgender-medical-procedures-changing-genders-on-documents-adoptions-by-trans-people)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T15:44:41+00:00

Russian President Vladimir Putin signed new restrictions into law on Monday that dramatically clamp down on transgender individuals inside his country. The new federal law bans transgender surgeries, transgender hormone therapy, and the use of puberty blockers by transgender individuals, according to the Russian government. &#8220;The only exception to this rule will be medical interventions ...

## Aaron Hernandez’s Brother Arrested For Allegedly Planning School Shootings
 - [https://www.dailywire.com/news/aaron-hernandezs-brother-arrested-for-allegedly-planning-school-shootings](https://www.dailywire.com/news/aaron-hernandezs-brother-arrested-for-allegedly-planning-school-shootings)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T15:43:45+00:00

The brother of Aaron Hernandez, the former NFL player convicted of murder in 2015, was arrested last week for allegedly plotting shootings at two college campuses.  Dennis “DJ” Hernandez, 37, was arrested for the fourth time this year when police became concerned that he was planning shootings at the campuses of Brown University and the ...

## Denver’s Homeless Population Spiked Over 30% In One Year, Annual Count Finds
 - [https://www.dailywire.com/news/denvers-homeless-population-spiked-over-30-in-one-year-annual-count-finds](https://www.dailywire.com/news/denvers-homeless-population-spiked-over-30-in-one-year-annual-count-finds)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T15:42:47+00:00

Denver&#8217;s homeless population jumped more than 30% this year, the city&#8217;s annual count showed. Denver now has a total of 9,065 homeless people, up 31.7% over 2022, according to the Metro Denver Homeless Initiative&#8217;s 2023 &#8220;Point in Time&#8221; count, released Monday. The count was performed on January 30 and includes both people staying at shelters ...

## Pete Davidson Receives Sentence Following Reckless Driving Charge
 - [https://www.dailywire.com/news/pete-davidson-receives-sentence-following-reckless-driving-charge](https://www.dailywire.com/news/pete-davidson-receives-sentence-following-reckless-driving-charge)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T15:27:56+00:00

Pete Davidson was sentenced to 50 hours of community service after the comedian was charged with reckless driving. The 29-year-old comedian has reportedly agreed to enter an 18-month diversion program without having to enter a plea or no contest to the offense, TMZ reported. The &#8220;Saturday Night Live&#8221; star must attend 12 hours of traffic ...

## Bad Dog, Or Bad Owner? Biden’s Dog Can’t Stop Biting People, Records Show
 - [https://www.dailywire.com/news/bad-dog-or-bad-owner-bidens-dog-cant-stop-biting-people-records-show](https://www.dailywire.com/news/bad-dog-or-bad-owner-bidens-dog-cant-stop-biting-people-records-show)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T15:00:59+00:00

It was once said that there are no such things as bad dogs, only bad owners. That sentiment could help explain why President Joe Biden&#8217;s dogs can&#8217;t stop biting people. On Tuesday, The New York Post reported that Biden&#8217;s dog &#8220;Commander&#8221; went on a chomping spree and bit seven people in the four-month period from ...

## University Of Texas At Austin Hosts ‘LGBTQIA’ Allyship Training, Warns Of ‘Heterosexual Privilege’
 - [https://www.dailywire.com/news/university-of-texas-at-austin-hosts-lgbtqia-allyship-training-warns-of-heterosexual-privilege](https://www.dailywire.com/news/university-of-texas-at-austin-hosts-lgbtqia-allyship-training-warns-of-heterosexual-privilege)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T14:53:16+00:00

The University of Texas at Austin will host workshops on “affirming LGBTQIA+ people” and LGBT allyship, which warn of “heterosexual” and “monosexual” privilege. The university’s Gender and Sexuality Center hosts a number of different workshops for students, staff, faculty, and administrators, which “use an intersectional approach to foster and develop allyship practices that center affirming ...

## Colorado Summer Camp Will House Trans Adults In Kids’ Cabins Without Telling Parents If They Ask
 - [https://www.dailywire.com/news/colorado-summer-camp-will-house-trans-adults-in-kids-cabins-without-telling-parents-if-they-ask](https://www.dailywire.com/news/colorado-summer-camp-will-house-trans-adults-in-kids-cabins-without-telling-parents-if-they-ask)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T14:39:12+00:00

A Colorado summer camp for children has a stated policy of allowing transgender adults to sleep in the same cabins as children of the opposite biological sex, yet it refuses to disclose specific arrangements to inquiring parents. Colvig Silver Camps, located in Durango, has adopted several “gender inclusivity” policies, such as allowing adult men who ...

## GOP Congressman Makes Case For Why ‘We Should Not Fear A Government Shutdown’
 - [https://www.dailywire.com/news/gop-congressman-makes-case-for-why-we-should-not-fear-a-government-shutdown](https://www.dailywire.com/news/gop-congressman-makes-case-for-why-we-should-not-fear-a-government-shutdown)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T14:28:21+00:00

A Republican lawmaker argued on Tuesday in favor of making a play for spending cuts without &#8220;fear&#8221; of a government shutdown as the appropriations process ramps up. Appearing with colleagues in the conservative House Freedom Caucus outside the U.S. Capitol Building, Rep. Bob Good (R-VA) made a hardline case for demanding fiscal restraint ahead of ...

## Vermont State Police Joke About Statue Stolen From ‘Beetlejuice 2’ Set: ‘Tried Saying The Name Three Times… Didn’t Come Back!’
 - [https://www.dailywire.com/news/vermont-state-police-joke-about-statue-stolen-from-beetlejuice-2-set-tried-saying-the-name-three-times-didnt-come-back](https://www.dailywire.com/news/vermont-state-police-joke-about-statue-stolen-from-beetlejuice-2-set-tried-saying-the-name-three-times-didnt-come-back)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T14:23:03+00:00

The set of “Beetlejuice 2” was burglarized, but that didn’t stop law enforcement from cracking jokes about it. The Vermont State Police posted a photo on X, formerly known as Twitter, referencing Tim Burton’s original “Beetlejuice” film from 1988. “We tried saying the name of this stolen statue three times, but it didn’t come back!” ...

## Dwayne Johnson Makes ‘Historic’ Donation To SAG-AFTRA Foundation Relief Fund
 - [https://www.dailywire.com/news/dwayne-johnson-makes-historic-donation-to-sag-aftra-foundation-relief-fund](https://www.dailywire.com/news/dwayne-johnson-makes-historic-donation-to-sag-aftra-foundation-relief-fund)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T14:14:26+00:00

As the writers’ and actors’ strike in Hollywood drags on, actor Dwayne Johnson, also known as &#8220;The Rock,&#8221; showed his support for fellow Hollywood professionals by making a “historic” donation to the SAG-AFTRA Foundation Relief Fund. The 51-year-old “Black Adam” star made a significant payment to the non-profit organization, which is associated with the union but ...

## Jason Aldean Thanks Fans For Support Of ‘Try That In A Small Town,’ Says The ‘People Have Spoken’
 - [https://www.dailywire.com/news/jason-aldean-thanks-fans-for-support-of-try-that-in-a-small-town-says-the-people-have-spoken](https://www.dailywire.com/news/jason-aldean-thanks-fans-for-support-of-try-that-in-a-small-town-says-the-people-have-spoken)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T14:02:58+00:00

Jason Aldean sent a message to fans thanking them for their support of &#8220;Try That In A Small Town&#8221; amid backlash against the song. The 46-year-old country singer went viral after he took to Twitter on Monday and wrote to his 3.8 million followers, &#8220;Thank [you] guys. Ready to see [you] back out there this ...

## Singer Tori Kelly Hospitalized In ‘Serious’ Condition With Blood Clots: Report
 - [https://www.dailywire.com/news/singer-tori-kelly-hospitalized-in-serious-condition-with-blood-clots-report](https://www.dailywire.com/news/singer-tori-kelly-hospitalized-in-serious-condition-with-blood-clots-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T13:42:47+00:00

Country star Tori Kelly was hospitalized Sunday night and reportedly remains in &#8220;serious&#8221; condition after she collapsed while out to dinner with friends in Los Angeles. Sources told TMZ that the 30-year-old country singer said her heart was beating unusually fast before she collapsed and was &#8220;out for awhile.&#8221; She was then rushed to Cedars-Sinai ...

## The Ties That Blind: Biden Family Friend Reportedly Worked For Prosecutor When Hunter Probe Began
 - [https://www.dailywire.com/news/the-ties-that-blind-biden-family-friend-reportedly-worked-for-prosecutor-when-hunter-probe-began](https://www.dailywire.com/news/the-ties-that-blind-biden-family-friend-reportedly-worked-for-prosecutor-when-hunter-probe-began)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T13:33:37+00:00

A close friend of the Biden family — one who even referred to Hunter Biden, on occasion, as &#8220;brother&#8221; — appears to have worked in the Delaware U.S. Attorney&#8217;s office at the time that the probe into the president&#8217;s embattled son began. According to a new report published Tuesday by The Washington Examiner, Alexander Mackler ...

## Virgin Islands And JPMorgan Accuse Each Other Of Enabling Jeffrey Epstein In New Court Filings
 - [https://www.dailywire.com/news/virgin-islands-and-jpmorgan-accuse-each-other-of-enabling-jeffrey-epstein-in-new-court-filings](https://www.dailywire.com/news/virgin-islands-and-jpmorgan-accuse-each-other-of-enabling-jeffrey-epstein-in-new-court-filings)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T13:25:51+00:00

The U.S. Virgin Islands and banking giant JPMorgan Chase have accused each other of enabling Jeffrey Epstein, according to new court filings.  The filing from the Virgin Islands references alleged communications between a former and current JPMorgan executive which appears to show that they knew of Epstein’s ties to “nymphettes,” while the filing from JPMorgan ...

## Wisconsin School District Sued After Teacher’s Gender Transition Announcement
 - [https://www.dailywire.com/news/wisconsin-school-district-sued-after-teachers-gender-transition-announcement](https://www.dailywire.com/news/wisconsin-school-district-sued-after-teachers-gender-transition-announcement)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T13:20:04+00:00

A parent is suing a Wisconsin school district after school officials announced a teacher&#8217;s gender transition to students as young as in elementary school without parental notification. Leah Buchman, a mother in the Eau Claire Area School District in western Wisconsin, filed a complaint Monday accusing the district of violating open records law and keeping ...

## Her Remains Were Found In 1985. Now, She’s Finally Been Identified.
 - [https://www.dailywire.com/news/her-remains-were-found-in-1985-now-shes-finally-been-identified](https://www.dailywire.com/news/her-remains-were-found-in-1985-now-shes-finally-been-identified)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T12:58:53+00:00

In March 1985, a driver with vehicle trouble spotted the skeletal remains of a woman near a creek bank in Cheatham County, Tennessee. Now, nearly 40 years later, her remains have been identified. The woman is Michelle Lavone Inman, who would have been just shy of her 24th birthday when her remains were found. At ...

## Widow Of Obama Family Chef Speaks Out After Husband Found Dead
 - [https://www.dailywire.com/news/widow-of-obama-family-chef-speaks-out-after-husband-found-dead](https://www.dailywire.com/news/widow-of-obama-family-chef-speaks-out-after-husband-found-dead)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T12:35:48+00:00

The widow of former President Barack Obama&#8217;s personal chef sent out a tribute to her late husband after he was found dead on Monday in a pond near the Obama family estate in Martha&#8217;s Vineyard. Authorities said divers recovered the body of Tafari Campbell, 45, from the Edgartown Great Pond after a paddle boarding incident in ...

## How A COVID Origins Study Went From Conspiracy Theory Slayer To Just A ‘Point Of View’
 - [https://www.dailywire.com/news/how-a-covid-origins-study-went-from-conspiracy-theory-slayer-to-just-a-point-of-view](https://www.dailywire.com/news/how-a-covid-origins-study-went-from-conspiracy-theory-slayer-to-just-a-point-of-view)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T12:33:22+00:00

A controversial study credited with fueling the notion that COVID had natural origins was just a &#8220;point of view&#8221; rather than a research project, the medical journal that published the paper is now saying. Nature Medicine&#8217;s fresh characterization of the &#8220;Proximal Origin&#8221; report, as conveyed in a story from The Telegraph published over the weekend, stands ...

## LeBron James’ Son Suffers Cardiac Arrest During Basketball Workout
 - [https://www.dailywire.com/news/lebron-james-son-suffers-cardiac-arrest-during-basketball-workout](https://www.dailywire.com/news/lebron-james-son-suffers-cardiac-arrest-during-basketball-workout)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T12:17:19+00:00

NBA star LeBron James&#8217; 18-year-old son Bronny was rushed to the hospital Monday after suffering a cardiac arrest during a basketball workout at the University of Southern California (USC). A spokesperson for the James family confirmed Bronny&#8217;s medical scare and added that the incoming freshman at USC is now in stable condition and out of ...

## ‘Oppenheimer’ Viewers Point Out Historical Mistake, Fans Speculate On Whether It Was Intentional
 - [https://www.dailywire.com/news/oppenheimer-viewers-point-out-historical-mistake-fans-speculate-on-whether-it-was-intentional](https://www.dailywire.com/news/oppenheimer-viewers-point-out-historical-mistake-fans-speculate-on-whether-it-was-intentional)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T12:10:45+00:00

Reviews for Christopher Nolan’s historical drama “Oppenheimer” have been incredibly positive so far, but some viewers couldn’t help but point out what they’re calling a historical discrepancy in the film. The 3-hour movie details the life of nuclear physicist J. Robert Oppenheimer, the so-called “father of the atomic bomb.” Set designers took care to recreate ...

## Former Pastor Charged With Murdering Fellow Pastor’s 8-Year-Old Daughter Nearly 50 Years Ago
 - [https://www.dailywire.com/news/former-pastor-charged-with-murdering-fellow-pastors-8-year-old-daughter-nearly-50-years-ago](https://www.dailywire.com/news/former-pastor-charged-with-murdering-fellow-pastors-8-year-old-daughter-nearly-50-years-ago)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T12:07:27+00:00

An 83-year-old retired pastor was arrested and charged with the kidnapping and murder of a fellow pastor’s 8-year-old daughter in 1975, Pennsylvania officials announced Monday.  David Zandstra of Marietta, Georgia, was charged by Delaware County, Pennsylvania, District Attorney Jack Stollsteimer after he allegedly confessed to the slaying of Gretchen Harrington. The young girl’s remains were ...

## Idaho Murder Suspect Claims DNA May Have Been Planted At Crime Scene By Cops
 - [https://www.dailywire.com/news/idaho-murder-suspect-claims-dna-may-have-been-planted-at-crime-scene-by-cops](https://www.dailywire.com/news/idaho-murder-suspect-claims-dna-may-have-been-planted-at-crime-scene-by-cops)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T12:00:02+00:00

The man accused of killing four University of Idaho students claims that DNA found at the scene may have been planted by police. The 28-year-old suspect, who is not being named per Daily Wire policy, said in a recent court filing that police officers in Moscow, Idaho, could have placed the suspect’s DNA on the ...

## Two-Thirds Of Voters — And More Than Half Of Democrats — Say Biden Should Step Aside In ’24
 - [https://www.dailywire.com/news/two-thirds-of-voters-and-more-than-half-of-democrats-say-biden-should-step-aside-in-24](https://www.dailywire.com/news/two-thirds-of-voters-and-more-than-half-of-democrats-say-biden-should-step-aside-in-24)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T11:57:50+00:00

Two out of three U.S. voters have declared that President Joe Biden, 80, might be just a tad too mature to run in 2024. Americans think it&#8217;s high time he step aside and let younger Democrats fight it out for the nomination, according to a new poll. The DailyMail.com/Tipp poll shockingly discovered that a whopping ...

## Hunter Biden Prosecutor Will Be Allowed To Testify Before Congress After Republicans Slam Plea Deal
 - [https://www.dailywire.com/news/hunter-biden-prosecutor-will-be-allowed-to-testify-before-congress-after-republicans-slam-plea-deal](https://www.dailywire.com/news/hunter-biden-prosecutor-will-be-allowed-to-testify-before-congress-after-republicans-slam-plea-deal)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T10:50:29+00:00

Hunter Biden prosecutor and U.S. Attorney for the District of Delaware David Weiss will be allowed to testify before the House Judiciary Committee, according to a letter from the Department of Justice.  Weiss’ testimony would come after the announcement of a plea deal where Hunter would plead guilty to two tax misdemeanors and admit the ...

## Pro Golfer Confesses To Cheating To Make Tournament Cut
 - [https://www.dailywire.com/news/pro-golfer-confesses-to-cheating-to-make-tournament-cut](https://www.dailywire.com/news/pro-golfer-confesses-to-cheating-to-make-tournament-cut)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T09:58:12+00:00

A pro golfer admitted to making “the biggest mistake” of his life during a PGA Tour Canada tournament last weekend when he cheated to improve his score, ensuring he made the cut for the final round. Justin Doeden, a 28-year-old from Minnesota, confessed on Monday that he changed his score from a double bogey to ...

## ‘You Will Pass Out Before The Movie Ends’: Elon Musk Warns Moviegoers, Slams ‘Barbie’
 - [https://www.dailywire.com/news/you-will-pass-out-before-the-movie-ends-elon-musk-warns-moviegoers-slams-barbie](https://www.dailywire.com/news/you-will-pass-out-before-the-movie-ends-elon-musk-warns-moviegoers-slams-barbie)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T08:52:01+00:00

Twitter CEO Elon Musk joined the chorus of critics who have ripped into the “Barbie” movie, reacting to the movie’s incessant carping about the “patriarchy.” The movie has racked up enormous numbers at the box office, taking in $155 million domestically over its debut weekend. But its woke agenda has catalyzed harsh reaction from conservatives, ...

## Governor Abbott Fires Back After DOJ Demands He Remove Floating Barrier On Rio Grande
 - [https://www.dailywire.com/news/governor-abbott-fires-back-after-doj-demands-he-remove-floating-barrier-on-rio-grande](https://www.dailywire.com/news/governor-abbott-fires-back-after-doj-demands-he-remove-floating-barrier-on-rio-grande)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T08:24:31+00:00

Governor Greg Abbott (R-TX) said on Monday that he will see the Biden administration in court after the Department of Justice demanded that he remove a floating barrier that was recently erected in the Rio Grande to stem the tide of illegal aliens pouring into the U.S. from Mexico. The DOJ claims that the barrier ...

## Speaker McCarthy Indicates Republicans Are Moving Toward Impeachment Inquiry Of Biden
 - [https://www.dailywire.com/news/speaker-mccarthy-indicates-republicans-are-moving-toward-impeachment-inquiry-of-biden](https://www.dailywire.com/news/speaker-mccarthy-indicates-republicans-are-moving-toward-impeachment-inquiry-of-biden)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-07-25T07:28:17+00:00

House Speaker Kevin McCarthy (R-CA) said during an interview this week that the Republican-controlled chamber is moving closer toward an impeachment inquiry against President Joe Biden over allegations that he accepted millions of dollars in bribes from foreign countries. McCarthy&#8217;s remarks come after Sen. Chuck Grassley (R-IA) released an FBI-generated FD-1023 form last week in ...

