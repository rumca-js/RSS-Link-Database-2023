# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## The AI-Powered, Totally Autonomous Future of War Is Here
 - [https://www.wired.com/story/ai-powered-totally-autonomous-future-of-war-is-here/](https://www.wired.com/story/ai-powered-totally-autonomous-future-of-war-is-here/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-07-25T10:00:00+00:00

Ships without crews. Self-directed drone swarms. How a US Navy task force is using off-the-shelf robotics and artificial intelligence to prepare for the next age of conflict.

## Mykhailo Fedorov Is Running Ukraine’s War Against Russia Like a Startup
 - [https://www.wired.com/story/ukraine-runs-war-startup/](https://www.wired.com/story/ukraine-runs-war-startup/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-07-25T06:00:00+00:00

Ukraine's deputy prime minister has helped the country bootstrap and innovate its war effort, creating a defense industry from scratch, and using his Big Tech ties to cut Russia off from the world.

