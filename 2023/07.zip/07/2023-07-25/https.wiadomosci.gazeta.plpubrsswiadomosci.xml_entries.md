# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## W Turcji pożar to "no problem". Turysta o biurze podróży: Byliśmy skazani na informacje z Twittera
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009947,w-turcji-pozar-to-no-problem-a-ogien-idzie-dalej-skazani.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009947,w-turcji-pozar-to-no-problem-a-ogien-idzie-dalej-skazani.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T20:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/77/9e/1c/z30009975M,Pozar-w-Turcji-w-prowincji-Antalya---wtorek-25-lip.jpg" vspace="2" />Pan Dominik w rozmowie z Gazeta.pl przekazał, że około godziny 19 w hotelu przywrócone zostało normalne zasilanie. Nic jednak nie pozwala turystom zapomnieć o zagrożeniu, jakim jest pożar zlokalizowany około 10 kilometrów od hotelu. "Cały czas słychać i widać latające śmigłowce, które próbują opanować pożar, choć ten wydaje się pozostawać nieuchwytny" - napisał pan Dominik.

## Historia Joanny z Krakowa. Kobieta pojawiła się na proteście. "Byłam zaszczutym zwierzęciem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009800,historia-joanny-z-krakowa-kobieta-pojawila-sie-na-protescie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009800,historia-joanny-z-krakowa-kobieta-pojawila-sie-na-protescie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T19:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/9e/1c/z30009890M,Protest-solidarnosciowy-z-Joanna--Krakow--25-lipca.jpg" vspace="2" />Pani Joanna, wobec której policjanci przeprowadzili upokarzającą interwencję w szpitalu, przemawiała we wtorek przed krakowskim komisariatem. - Ja tam już nie byłam człowiekiem, ja tam już byłam zaszczutym zwierzęciem - wykrzyczała. Przed siedzibą policji stanęło pięcioro policjantów. - To ci sami, którzy interweniowali w mojej sprawie - mówiła Joanna, a tłum skandował "hańba!".

## Rosja zacznie strzelać do cywilnych statków na Morzu Czarnym? Wielka Brytania ostrzega
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009836,rosja-zacznie-strzelac-do-cywilnych-statkow-na-morzu-czarnym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009836,rosja-zacznie-strzelac-do-cywilnych-statkow-na-morzu-czarnym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T19:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f9/9e/1c/z30009849M,Statek-ze-zbozem.jpg" vspace="2" />Według informacji brytyjskiego wywiadu Rosja może zacząć atakować cywilne statki na Morzu Czarnym. Ukraina dostała ostrzeżenie od Wielkiej Brytanii.

## Siergiej Szojgu pojechał do Korei Północnej. "Ta wizyta zacieśni wojskowe więzi"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009834,siergiej-szojgu-pojechal-do-korei-polnocnej-ta-wizyta-zaciesni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009834,siergiej-szojgu-pojechal-do-korei-polnocnej-ta-wizyta-zaciesni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T19:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2b/9e/1c/z30009899M,Siergiej-Szojgu.jpg" vspace="2" />Rosyjska delegacja z Siergiejem Szojgu na czele przebywa w Korei Północnej - poinformowało Ministerstwo Obrony Rosji. Resort podkreślił, że "ta wizyta pomoże zacieśnić wojskowe więzi" między Moskwą a Pjongjangiem.

## "Chrońmy dzieci" czy "Lex Czarnek 3.0"? Projekt straszy "seksualizacją" i jest już w Sejmie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009524,chronmy-dzieci-czy-lex-czarnek-3-0-projekt-straszy-seksualizacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009524,chronmy-dzieci-czy-lex-czarnek-3-0-projekt-straszy-seksualizacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T18:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/68/9d/1c/z30004840M,Minister-edukacji-i-nauki-Przemyslaw-Czarnek.jpg" vspace="2" />Do Sejmu trafił obywatelski projekt "Chrońmy dzieci" i w błyskawicznym tempie został skierowany do pierwszego czytania. Autorzy projektu zainspirowali się zawetowanymi przez prezydenta postulatami Przemysława Czarnka. Przewidują m.in. zakaz działalności na terenie przedszkoli i szkół stowarzyszeń i organizacji promujących "zagadnienia związane z seksualizacją dzieci". Sławomir Broniarz przypomniał, że w parlamencie utknęły dwa projekty ZNP dotyczące wynagrodzeń nauczycieli. "Zapamiętajmy to!" - napisał.

## Szukał bezbronnych kobiet, jeździł ze specjalnym zestawem. Fałszywy taksówkarz z Brighton skazany
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009771,jezdzil-z-zestawem-do-gwaltu-i-szukal-bezbronnych-kobiet.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009771,jezdzil-z-zestawem-do-gwaltu-i-szukal-bezbronnych-kobiet.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T18:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f2/9e/1c/z30009842M,Graham-Head.jpg" vspace="2" />66-latek z Wielkiej Brytanii, który podszywał się pod kierowcę Ubera, został zatrzymany przez policję. Mężczyzna trafi do więzienia na 23 lata za próbę gwałtu i napaść na tle seksualnym.

## Nie żyje wójt gminy Firlej. Dawid Tarnowski miał 36 lat. "Marzyciel, perfekcjonista"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009367,dawid-tarnowski-nie-zyje-wojt-gminy-firlej-mial-36-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009367,dawid-tarnowski-nie-zyje-wojt-gminy-firlej-mial-36-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T17:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2c/9e/1c/z30009388M,Dawid-Tarnowski.jpg" vspace="2" />Nie żyje Dawid Tarnowski, wójt gminy Firlej w województwie lubelskim. Funkcję tę sprawował od 2018 roku. Miał 36 lat.

## 82-letni muzyk z Lublina oskarżony o pedofilię. Miał molestować dzieci na lekcjach pianina
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30009305,82-letni-muzyk-z-lublina-oskarzony-o-pedofilie-mial-molestowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30009305,82-letni-muzyk-z-lublina-oskarzony-o-pedofilie-mial-molestowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T17:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/71/9e/1c/z30009713M,82-letni-nauczyciel-muzyki-z-Lublina-oskarzony-o-p.jpg" vspace="2" />Jan K., 82-letni nauczyciel muzyki z Lublina, został oskarżony o pedofilię. Przez lata miał skrzywdzić co najmniej 16 dziewczynek. Mężczyźnie grozi do 12 lat więzienia.

## Turcja. Pożary w znanym kurorcie w Antalyi. "Jedyne, co usłyszeliśmy, to 'no problem'"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009220,pozary-w-znanym-tureckim-kurorcie-jedyne-co-uslyszelismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009220,pozary-w-znanym-tureckim-kurorcie-jedyne-co-uslyszelismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T17:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/9e/1c/z30009378M,Pozar---zdjecie-ilustracyjne.jpg" vspace="2" />W tureckim kurorcie Kemer, położonym w prowincji Antalya, trwa walka z ogniem. W gaszeniu tamtejszych pożarów bierze udział ponad 200 strażaków oraz samoloty, śmigłowce gaśnicze i maszyny budowlane. Ewakuowano szpital i mieszkańców zabudowań, które znalazły się najbliżej linii ognia.

## Marsz wagnerowców na Moskwę. Putin wiedział, ale nic nie zrobił. "Był sparaliżowany"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009191,marsz-wagnerowcow-na-moskwe-putin-wiedzial-ale-nic-nie-zrobil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009191,marsz-wagnerowcow-na-moskwe-putin-wiedzial-ale-nic-nie-zrobil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T17:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5a/9e/1c/z30009434M,Wladimir-Putin--zdj--ilustracyjne-.jpg" vspace="2" />"Marsz sprawiedliwości" na Moskwę obnażył słabość putinowskiego systemu zarządzania. Jak przekazali informatorzy "The Washington Post", dyktator wiedział o planowanym przez Jewgienija Prigożyna buncie już parę dni przed jego wybuchem. Nie zrobił nic. Zapanował chaos i "paraliż na wszystkich poziomach".

## Na południu Włoch 47,6 stopni i pożary. Na północy grad wielkości dłoni [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009024,niszczycielskie-pozary-na-sycylii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009024,niszczycielskie-pozary-na-sycylii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T17:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/15/9e/1c/z30009621M,Na-poludniu-Wloch-upaly-i-pozary--Polnoc-nawiedzil.jpg" vspace="2" />Włochy zostały sparaliżowane z powodu niszczycielskich żywiołów. Północne regiony opanowały gwałtowne burze, podczas gdy na południu rekordowe upały doprowadziły do wybuchu kilkudziesięciu groźnych pożarów. Około jedna trzecia z nich dotknęła rejon Palermo, z którego ewakuowano około 1500 osób.

## Pokazał, jak wygląda Bachmut po miesiącach walk. "Oto piekło rosyjskiego wyzwolenia" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30008498,pokazal-jak-wyglada-bachmut-po-miesiacach-walk-oto-pieklo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30008498,pokazal-jak-wyglada-bachmut-po-miesiacach-walk-oto-pieklo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T16:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c9/9e/1c/z30009289M,Pokazal--jak-wyglada-Bachmut-po-miesiacach-walk---.jpg" vspace="2" />Ukraiński dziennikarz Illia Ponomarenko pokazał, jak wygląda dziś Bachmut, o który przez długie miesiące toczono zaciekłą walkę. Po tętniącym życiem mieście zostały tylko zgliszcza. "Oto piekło rosyjskiego wyzwolenia" - napisał Ponomarenko.

## Rosyjski myśliwiec zaatakował drona sił USA. "Rażąca pogarda" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009086,rosyjski-mysliwiec-zaatakowal-drona-sil-usa-razaca-pogarda.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30009086,rosyjski-mysliwiec-zaatakowal-drona-sil-usa-razaca-pogarda.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T16:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4a/9e/1c/z30009162M,Rosyjski-mysliwiec-zaatakowal-amerykanskiego-drona.jpg" vspace="2" />Dowództwo Centralne Sił Powietrznych USA (AFCENT) poinformowało, że w Syrii doszło do zdarzenia z udziałem rosyjskiego myśliwca. Maszyna wystrzeliła w kierunku amerykańskiego drona MQ-9 flary. Jedna z nich uszkodziła bezzałogowca.

## Pożary w Grecji. Wskakują do łodzi i godzinami uciekają pieszo. "Córka krzyczała, że nie chce umierać"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30008636,pozary-w-grecji-wskakuja-do-lodzi-i-godzinami-uciekaja-pieszo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30008636,pozary-w-grecji-wskakuja-do-lodzi-i-godzinami-uciekaja-pieszo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T15:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c3/9e/1c/z30008771M,Strazacy-walcza-z-pozarami-na-greckiej-wyspie-Rodo.jpg" vspace="2" />W Grecji trwa walka z ogromnymi pożarami. Niszczycielski żywioł staje się przyczyną licznych ewakuacji turystów, którym nakazuje się ucieczkę nierzadko tuż po przybyciu do hotelu. Ludzie biegną do morza, odpływają na łódkach i maszerują w upale, by przedostać się w bezpieczne miejsce.

## Tajemnicze kosze na plażach. Lepiej ich nie dotykać. WWF apeluje: Zachowaj dystans!
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008878,tajemnicze-kosze-na-plazach-co-to-takiego-wwf-apeluje-zachowaj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008878,tajemnicze-kosze-na-plazach-co-to-takiego-wwf-apeluje-zachowaj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T15:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/55/9e/1c/z30009173M,Metalowe-klatki-na-polskich-plazach--zdj--ilustrac.jpg" vspace="2" />Na polskich plażach pojawiły się niewielkie, metalowe klatki. Co to takiego? Specjalne kosze, które pełnią ważną funkcje - informuje WWF Polska. Zachowaj od nich odpowiedni dystans.

## Trzy kobiety, w tym pasażerka w ciąży, nie mogły uniknąć czołówki. Kierowcy grozi 12 lat [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30008417,dobrzejowice-czolowe-zderzenie-dwoch-osobowek-nie-zyje-69-letnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30008417,dobrzejowice-czolowe-zderzenie-dwoch-osobowek-nie-zyje-69-letnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T15:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/9e/1c/z30008977M,Czolowe-zderzenie-osobowek-pod-Toruniem.jpg" vspace="2" />W Dobrzejowicach (woj. kujawsko-pomorskie) doszło do czołowego zderzenia dwóch samochodów osobowych, w wyniku którego śmierć poniosła 69-letnia kobieta. Badanie wykazało, że kierujący pojazdem, który najprawdopodobniej stracił panowanie nad samochodem i zjechał na przeciwległy pas ruchu, był pod wpływem narkotyków. Mężczyzna został zatrzymany. Usłyszał zarzut spowodowania wypadku ze skutkiem śmiertelnym.

## Holandia. Znaleziono ciało zaginionej 40-letniej Polki. Policja nie wyklucza morderstwa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30008585,holandia-znaleziono-cialo-zaginionej-40-letniej-polki-policja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30008585,holandia-znaleziono-cialo-zaginionej-40-letniej-polki-policja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T14:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/29/98/1c/z29986089M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />W Holandii zostało znalezione ciało 40-letniej Polki, Agnieszki B. z Biłgoraja. Okoliczności jej śmierci nie są znane. Służby rozpoczęły śledztwo i nie wykluczają, że do śmierci doszło w wyniku działania osób trzecich.

## Wściekłość w PO na Tomasza Grodzkiego. Zamiast pracować - miesiąc wakacji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30008072,wscieklosc-w-po-na-tomasza-grodzkiego-zamiast-pracowac-miesiac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30008072,wscieklosc-w-po-na-tomasza-grodzkiego-zamiast-pracowac-miesiac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T14:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/61/ce/1b/z29155425M,Donald-Tusk--Tomasz-Grodzki--Komentarze-politykow-.jpg" vspace="2" />Senat w tym tygodniu ma posiedzenie, a potem miesiąc wakacji - aż do 30 sierpnia. Wedle informacji Gazeta.pl wielu polityków Platformy Obywatelskiej, ale też i reszty opozycji, wściekło się na marszałka prof. Tomasza Grodzkiego. - Walczymy o wszystko w tej kampanii, a Tomek zarządza miesiąc laby - mówi jedna z ważnych w PO osób.

## Gdzie jest burza? Intensywne opady, silny wiatr, a nawet grad. Wydano alerty IMGW i RCB
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008324,gdzie-jest-burza-intensywne-opady-silny-wiatr-a-nawet-grad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008324,gdzie-jest-burza-intensywne-opady-silny-wiatr-a-nawet-grad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T13:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bb/84/1c/z29901499M,Wyladowania-atmosferyczne-podczas-burzy---zdjecie-.jpg" vspace="2" />Synoptycy Instytututu Meteorologii i Gospodarki Wodnej (IMGW) wydali ostrzeżenia I i II stopnia. Rządowe Centrum Bezpieczeństwa wysłało alerty mieszkańcom trzech województw. Wszystko za sprawą deszczowego frontu atmosferycznego, który nasuwa się nad południowo-wschodnią Polskę. Gdzie jest burza?

## Katastrofa samolotu gaśniczego w Grecji. Maszyna rozbiła się w trakcie gaszenia pożaru [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30008458,katastrofa-samolotu-gasniczego-w-grecji-maszyna-rozbila-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30008458,katastrofa-samolotu-gasniczego-w-grecji-maszyna-rozbila-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T13:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fb/9c/1c/z30003195M,Grecja--zdj--ilustracyjne-.jpg" vspace="2" />Samolot, który brał udział w akcji gaszenia pożarów w Grecji, rozbił się w okolicy miasta Karistos na wyspie Eubei. Greckie media poinformowały, że maszyna marki Canadair walczyła z żywiołem na trudno dostępnych obszarach. Na pokładzie samolotu znajdowały się co najmniej dwie osoby.

## Polacy chcą legalnej aborcji, ale władza wie lepiej. Nowy sondaż nie pozostawia wątpliwości
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008114,polacy-chca-legalnej-aborcji-ale-wladza-wie-lepiej-nowy-ondaz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008114,polacy-chca-legalnej-aborcji-ale-wladza-wie-lepiej-nowy-ondaz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T13:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/91/1c/z29957699M.jpg" vspace="2" />Niemal 57 proc. Polaków uważa, że niezależnie od przyczyny aborcja do 12. tygodnia ciąży powinna być legalna. Zgodni są zarówno mieszkańcy dużych miast, jak i wsi.

## Leszno. 19-latek uderzył w drzewo, pięć osób trafiło do szpitala. "Zakleszczeni we wraku"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30007960,leszno-19-latek-uderzyl-w-drzewo-piec-osob-trafilo-do-szpitala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30007960,leszno-19-latek-uderzyl-w-drzewo-piec-osob-trafilo-do-szpitala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T13:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/77/9e/1c/z30007415M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Pięcioro nastolatków trafiło do szpitala po wypadku, do którego doszło we wtorek w Lesznie (woj. wielkopolskie). 19-letni kierowca stracił panowanie nad pojazdem i uderzył w drzewo. Trwa policyjne dochodzenie.

## Lublin. Bohaterski 12-latek uratował babcię z płonącego budynku. Wrócił też po psa i papugę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30007962,lublin-bohaterski-12-latek-uratowal-babcie-z-plonacego-budynku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30007962,lublin-bohaterski-12-latek-uratowal-babcie-z-plonacego-budynku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T13:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4d/9e/1c/z30008397M,Pozar-w-Lublinie.jpg" vspace="2" />W Lublinie bohaterski 12-latek wyprowadził z pożaru swoją 83-letnią babcię. Według relacji policji po chwili chłopiec wrócił do płonącego budynku, aby uratować także psa i papugę. Dzięki jego szybkiej reakcji, nikt nie ucierpiał w zdarzeniu. Dokładne okoliczności i przyczyny pojawienia się ognia wyjaśnia policja.

## Tragedia w Tatrach. Turysta nie wrócił z Giewontu. Możliwe, że chciał skrócić sobie trasę podczas burzy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30007961,tragedia-w-tatrach-turysta-nie-wrocil-z-giewontu-mozliwe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30007961,tragedia-w-tatrach-turysta-nie-wrocil-z-giewontu-mozliwe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T12:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1a/f2/17/z25111834M,Giewont--Zdjecie-ilustracyjne.jpg" vspace="2" />Tatrzańskie Ochotnicze Pogotowie Ratunkowe poszukiwało turysty, który wybrał się na Giewont. Następnego dnia z pokładu śmigłowca wypatrzyli jego ciało. - Spadł prawdopodobnie ponad 100 metrów - ocenił Łukasz Zubek z TOPR. Okoliczności tragedii bada policja.

## Zielona Góra. Jest śledztwo w sprawie pożaru odpadów. Media ujawniają listę substancji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30007663,zielona-gora-jest-sledztwo-w-sprawie-pozaru-odpadow-media.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30007663,zielona-gora-jest-sledztwo-w-sprawie-pozaru-odpadow-media.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T12:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b1/9d/1c/z30006449M,Pozar-w-Zielonej-Gorze--22-07-2023-r-.jpg" vspace="2" />Prokuratura w Zielonej Górze rozpoczęła śledztwo w związku z pożarem oraz wybuchem substancji łatwopalnych. Śledztwo dotyczy sprowadzenia zagrożenia dla życia i zdrowia osób oraz mienia wielkiej wartości. Media opublikowały listę części substancji niebezpiecznych, które były składowane w hali w Przylepie.

## Prymas Polski uderzył w Rydzyka i polityków. "Kościół to nie miejsce na wiec polityczny"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30007465,prymas-polski-uderzyl-w-rydzyka-i-politykow-kosciol-to-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30007465,prymas-polski-uderzyl-w-rydzyka-i-politykow-kosciol-to-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T12:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b3/9e/1c/z30007731M,Prymas-Polski-zostal-zapytany-o-polityke-w-Kosciel.jpg" vspace="2" />- Kościół to nie miejsce na wiec polityczny - powiedział prymas Polski w odpowiedzi na pytanie co sądzi o udziale polityków PiS w pielgrzymce Radia Maryja na Jasnej Górze i słowach Tadeusza Rydzyka krytykującego Unię Europejską. Duchowny wyjaśnił, jaka jest rola i odpowiedzialność Kościoła w czasie zbliżających się wyborów.

## USA ujawniają możliwe plany Putina. Rosja ma planować operację "fałszywej flagi"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30007118,usa-ujawnia-mozliwe-plany-putina-rosja-ma-planowac-operacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30007118,usa-ujawnia-mozliwe-plany-putina-rosja-ma-planowac-operacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T12:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/73/9e/1c/z30007667M,Wladimir-Putin.jpg" vspace="2" />- Mamy informacje sugerujące, że Rosja może przygotowywać operację fałszywej flagi - powiedział na konferencji rzecznik Departamentu Stanu USA Matthew Miller. Przedstawiciel departamentu przekazał, że w najbliższym czasie Władimir Putin może szykować kolejne działania.

## Masowe protesty w Izraelu i brutalne starcia z policją. Kociszewski: Walczą po to, żeby wygrać
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30006708,masowe-protesty-w-izraelu-i-brutalne-starcia-z-policja-kociszewski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30006708,masowe-protesty-w-izraelu-i-brutalne-starcia-z-policja-kociszewski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T11:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/19/9e/1c/z30007577M,Izrael--Protesty-przeciw-reformie-sadownictwa-fors.jpg" vspace="2" />- W Izraelu protestuje nie tylko lewica. Protestuje umiarkowana prawica, ludzie w przeszłości związani z Netanjahu, niekiedy sympatycy Likudu, oficerowie i rezerwiści - wylicza Jarosław Kociszewski, redaktor naczelny portalu new.org.pl i ekspert fundacji Stratpoints w rozmowie z Gazeta.pl. Specjalista od spraw Bliskiego Wschodu podkreśla, że aby zrozumieć sprzeciw wobec reformy sądownictwa, którą forsuje izraelski rząd, trzeba spróbować zrozumieć podejście obywateli do państwa, różne od polskiego.

## Jacek Ozdoba usiłował storpedować konferencję PO, popchnął posła. Sienkiewicz pisze o "bandyterce"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30007319,jacek-ozdoba-usilowal-storpedowac-konferencje-platformy-obywatelskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30007319,jacek-ozdoba-usilowal-storpedowac-konferencje-platformy-obywatelskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T11:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/9e/1c/z30007816M.jpg" vspace="2" />Wiceminister Jacek Ozdoba pojawił się nieoczekiwanie na konferencji prasowej polityków Platformy Obywatelskiej. Podczas spotkania przerywał innym, przysuwał do siebie mikrofony i popchnął Jana Grabca.

## Chiński polityk zniknął miesiąc temu. Qin Gang odwołany z funkcji szefa MSZ
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30007710,odnalazl-sie-chinski-polityk-niewidziany-od-miesiaca-qin-gang.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30007710,odnalazl-sie-chinski-polityk-niewidziany-od-miesiaca-qin-gang.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T11:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/79/35/1c/z29578105M,WAZNE.jpg" vspace="2" />Qin Gang został zdymisjonowany przez chińskie władze ze stanowiska ministra spraw zagranicznych - podało we wtorek BBC.

## Ksiądz Piotr S. został aresztowany. Według mediów chodzi o handel narkotykami. Kuria wydała komunikat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30007087,ksiadz-piotr-s-zostal-aresztowany-wedlug-mediow-chodzi-o-handel.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30007087,ksiadz-piotr-s-zostal-aresztowany-wedlug-mediow-chodzi-o-handel.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T11:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5d/9e/1c/z30007389M,Ksiadz--zdjecie-ilustracyjne-.jpg" vspace="2" />Diecezja łowicka potwierdziła doniesienia mediów, które informowały, że ksiądz Piotr S. został aresztowany na polecenie prokuratury z Sochaczewa. Dziennikarze przekazali, że zatrzymanie miało związek ze śledztwem dotyczącym handlu narkotykami.

## "Solidarnie z Joanną". Protesty pod siedzibami policji w Polsce. Gdzie i o której? [LISTA MIAST]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006867,protesty-solidarnie-z-joanna-pod-siedzibami-policji-w-polsce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006867,protesty-solidarnie-z-joanna-pod-siedzibami-policji-w-polsce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T11:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/9e/1c/z30007304M,Protesty--solidarnie-z-Joanna--pod-siedzibami-poli.jpg" vspace="2" />"Dziękujemy za to, że zamiast nas bronić i dawać poczucie bezpieczeństwa, staliście się wrogami kobiet" - napisał Ogólnopolski Strajk Kobiet w zapowiedzi protestów, które przejdą we wtorek w wielu miastach w Polsce. Strajki odbędą się przed siedzibami policji.

## Strzały pod siedzibą TV Republika. Policja zatrzymała 15-latka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006795,strzaly-pod-siedziba-tv-republika-policja-zatrzymala-15-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006795,strzaly-pod-siedziba-tv-republika-policja-zatrzymala-15-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T10:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ec/9b/1c/z29997292M,Policja.jpg" vspace="2" />- Policjanci w tej sprawie [oddania strzałów pod redakcją TV Republika - red.] dalej wykonywali czynności i te czynności oraz zgromadzone informacje doprowadziły policjantów do młodego mężczyzny w wieku 15 lat - poinformowała we wtorek w rozmowie z PAP Marta Sulowska z komendy na warszawskiej Woli.

## Zapadła decyzja ws. nalotu CBA na gabinet ginekologiczny w Szczecinie. "Niedopuszczalne"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006532,jest-decyzja-sadu-w-sprawie-nalotu-cba-na-gabinet-ginekologiczny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006532,jest-decyzja-sadu-w-sprawie-nalotu-cba-na-gabinet-ginekologiczny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T10:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e4/1f/1c/z29490660M,Z-gabinetu-ginekologicznego-dr-Marii-Kubisy-agenci.jpg" vspace="2" />Sąd w Szczecinie wydał postanowienie w sprawie interwencji Centralnego Biura Antykorupcyjnego (CBA) w prywatnym gabinecie ginekolożki Marii Kubisy. Wynika z niego, że agenci, którzy zabrali całą dokumentację medyczną, nie mieli do tego prawa.

## Przecieki z pilnie strzeżonych planów PiS na referendum. Pytania mogą zaskoczyć
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30006753,przecieki-z-pilnie-strzezonych-planow-pis-na-referendum-pytania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30006753,przecieki-z-pilnie-strzezonych-planow-pis-na-referendum-pytania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T09:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/df/9c/1c/z30001119M,Jaroslaw-Kaczynski-w-Stawiskach--na-pikniku-od-has.jpg" vspace="2" />Obóz PiS za zamkniętym drzwiami, starając się uniknąć wszelkich przecieków, wypracowuje pytania do referendum. Ma się odbyć, wedle planów, razem z wyborami do Sejmu. Pytań prawdopodobnie będzie więcej niż jedno, już zapowiedziane, o migracje. Wedle informacji Gazeta.pl, mogą być też pytania o mur na granicy z Rosją i wiek emerytalny.

## Co dzieje się na Sycylii? Dziennikarka: Pożary, braki prądu i wiatr parzący skórę. Nie da się wytrzymać
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30006294,pozary-i-goracy-wiatr-na-sycylii-nie-da-sie-wytrzymac-tej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30006294,pozary-i-goracy-wiatr-na-sycylii-nie-da-sie-wytrzymac-tej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T09:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/df/9d/1c/z30006495M.jpg" vspace="2" />- Wczoraj siedzieliśmy dziesięć godzin w morzu. Woda nie jest bardzo ciepła. Jest słona, ale to lepsze niż gorący wiatr, którego podmuchy parzą skórę (...). Nie da się wytrzymać tej temperatury - relacjonuje w rozmowie z Gazeta.pl Katarzyna van Rooijen-Juszczak, korespondentka Jednego Newsa Dziennie, która przebywa obecnie na Sycylii.

## W Turcji doszło do trzęsienia ziemi. Są pierwsze nagrania [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30006487,w-turcji-doszlo-do-trzesienia-ziemi-internauci-zamiescili-nagrania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30006487,w-turcji-doszlo-do-trzesienia-ziemi-internauci-zamiescili-nagrania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T09:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2d/9d/1c/z30006829M,Turcja--Trzesienie-ziemi-bylo-widoczne-dla-wielu-m.jpg" vspace="2" />W Turcji doszło do trzęsienia ziemi. Mieszkańcy nagrali relację ze wstrząsów i opublikowali nagrania w sieci. Minister Spraw Wewnętrznych poinformował, czy Turcja obecnie jest bezpieczna.

## Andrzej Duda na Święcie Policji o zagrożeniu dla funkcjonariuszy. Było m.in. o "kobietach i dzieciach"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30006090,duda-na-swiecie-policji-mowil-o-zagrozeniu-dla-funkcjonariuszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30006090,duda-na-swiecie-policji-mowil-o-zagrozeniu-dla-funkcjonariuszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T09:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/35/9d/1c/z30006325M,Obchody-Swieta-Policji-na-placu-Zamkowym-w-Warszaw.jpg" vspace="2" />W czasie poniedziałkowej uroczystości z okazji Święta Policji na placu Zamkowym w Warszawie Andrzej Duda mówił m.in. o interwencjach, jakie podejmują funkcjonariusze i z czym muszą się podczas nich liczyć. Tu jako przykład prezydent Polski wymienił "drobną kobietę" i dziecko z odbezpieczonym pistoletem.

## Awantura o pożar w Zielonej Górze. Marszałkini złożyła zawiadomienie do prokuratury ws. prezydenta
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30006098,spor-o-pozar-w-zielonej-gorze-prezydent-popelnil-przestepstwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,30006098,spor-o-pozar-w-zielonej-gorze-prezydent-popelnil-przestepstwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T08:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c2/9d/1c/z30006466M,Marszalek-wojewodztwa-lubuskiego-sklada-zawiadomie.jpg" vspace="2" />Marszałek województwa lubuskiego złożyła do prokuratury zawiadomienie o możliwości popełnienia przestępstwa przez prezydenta Zielonej Góry w związku z pożarem składowiska odpadów w Przylepie. Do sprawy tej odnieśli się również m.in. Donald Tusk oraz Mateusz Morawiecki. Politycy PiS i PO przedstawiają całkowicie odmienną interpretację zdarzeń, do których doszło w Zielonej Górze.

## Kandydaci Konfederacji do Sejmu. Jednemu z nich policja zarekwirowała kubki z "piątką Mentzena"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30005903,kandydaci-konfederacji-do-sejmu-jednemu-z-nich-policja-zarekwirowala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30005903,kandydaci-konfederacji-do-sejmu-jednemu-z-nich-policja-zarekwirowala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T07:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a8/9d/1c/z30005928M,Tomasz-Grzegorz-Stala.jpg" vspace="2" />Na pierwszym miejscu na liście w okręgu częstochowskim Konfederacja wystawiła Tomasza Grzegorza Stalę. Polityk zasłynął antysemickimi publikacjami na targach książki w Warszawie oraz powiązaniami z ruchem, którego celem jest normalizacja stosunków z Rosją. Stala ma również księgarnię, w której sprzedawał kubki z "piątką Mentzena".

## Jest zawiadomienie ws. Stowarzyszenia Polska 2050. Chodzi o punkt pomocy dla zwierząt
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005874,jest-zawiadomienie-ws-stowarzyszenia-polska-2050-chodzi-o.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005874,jest-zawiadomienie-ws-stowarzyszenia-polska-2050-chodzi-o.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T07:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/38/83/1c/z29899576M,Pies-w-Schronisku-dla-Bezdomnych-Zwierzat-w-Szczec.jpg" vspace="2" />Część środków przeznaczonych na pomoc dla zwierząt uchodźców z Ukrainy, które także trafiły do Polski, miała do nich nie dotrzeć - wynika z zawiadomienia do prokuratury, o którym informuje "Rzeczpospolita". Chodzi o Centrum Pomocy Humanitarnej PTAK w Nadarzynie pod Warszawą i działający tam punkt pomocy dla zwierząt. Według organizacji, które złożyły zawiadomienie, pieniądze miało sprzeniewierzyć Stowarzyszenie Polska 2050 Szymona Hołowni.

## Grecja. Dzieci mówią o ewakuacji z Rodos. Zosia: Nie chciano nas zabrać, chociaż autobusy były puste
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005915,grecja-dzieci-mowia-o-ewakuacji-z-rodos-zosia-nie-chciano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005915,grecja-dzieci-mowia-o-ewakuacji-z-rodos-zosia-nie-chciano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T07:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2d/9d/1c/z30006061M,Turysci-podczas-ewakuacji-na-Rodos--22-07-2023-r-.jpg" vspace="2" />Trwa ewakuacja Polaków z Rodos. Wśród turystów przebywających w punktach pomocowych na terenie wyspy znajdują się dzieci. Opowiedziały one o momencie, w którym Polacy dowiedzieli się o pożarach w Grecji. Opisały również przebieg ewakuacji.

## "Ksiądz ze zwykłej parafii" oburzony w liście do Owsiaka. "Kościół musi się opamiętać, oprzytomnieć"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005945,ksiadz-ze-zwyklej-parafii-oburzony-w-liscie-do-owsiaka-kosciol.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005945,ksiadz-ze-zwyklej-parafii-oburzony-w-liscie-do-owsiaka-kosciol.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T07:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0f/9d/1c/z30006031M,Jerzy-Owsiak.jpg" vspace="2" />"Nie mogę już patrzeć na to, co dzieje się w naszym kraju - a chodzi o nieszczęsny sojusz tronu z ołtarzem - konkretnie rządu PiS z Kościołem katolickim (...). Trzeba iść do wyborów!" - napisał do Jerzego Owsiaka "ksiądz ze zwykłej parafii". "Podpisuję się pod tym obiema rękami" - przekazał szef Wielkiej Orkiestry Świątecznej Pomocy.

## Pogoda. Intensywne burze zbliżają się do Polski. Możliwy grad oraz trąba powietrzna [ALERTY IMGW]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005830,pogoda-intensywne-burze-zblizaja-sie-do-polski-mozliwy-grad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005830,pogoda-intensywne-burze-zblizaja-sie-do-polski-mozliwy-grad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T06:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ae/9d/1c/z30005934M,Kolejne-burze-zblizaja-sie-do-Polski.jpg" vspace="2" />Do Polski zbliża się kolejna strefa burz, choć wciąż widać skutki wczorajszych nawałnic. Instytut Meteorologii i Gospodarki Wodnej (IMGW) wydał ostrzeżenia I i II stopnia przed burzami z gradem. Możliwe są też opady nawalnego deszczu, a nawet trąba powietrzna.

## Grecja. Co dalej z pożarami? Wraca ekstremalny upał, piąty poziom alertu na Krecie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005825,grecja-pozary-na-wyspie-rodos-nadal-wymykaja-sie-spod-kontroli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005825,grecja-pozary-na-wyspie-rodos-nadal-wymykaja-sie-spod-kontroli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T06:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/87/9d/1c/z30005895M,Grecja--Pozary-na-wyspie-Rodos-nadal--wymykaja-sie.jpg" vspace="2" />Trwają pożary na wyspie Rodos, Grecja zmaga się z żywiołem również w innych regionach. Sytuacji nie poprawia fakt, że do kraju nadchodzą ekstremalne upały, w związku z którymi wydano ostrzeżenia.

## Stany Zjednoczone komentują "niefortunne" głosowanie w Izraelu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005835,usa-o-niefortunnym-glosowaniu-w-izraelu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005835,usa-o-niefortunnym-glosowaniu-w-izraelu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T06:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6b/9d/1c/z30005867M,Karine-Jean-Pierre.jpg" vspace="2" />- To niefortunne, że dzisiejsze głosowanie odbyło się przy najmniejszej możliwej większości - powiedziała w poniedziałek rzeczniczka prasowa Białego Domu Karine Jean-Pierre, po kontrowersyjnym głosowaniu w izraelskim parlamencie. Chodzi o zmiany dotyczące decyzji podejmowanych przez Sąd Najwyższy.

## USA odpowiadają na słowa Putina i Łukaszenki o Polsce: Będziemy bronić każdego cala terytorium NATO
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005819,usa-odpowiadaja-na-slowa-putina-i-lukaszenki-o-polsce-bedziemy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005819,usa-odpowiadaja-na-slowa-putina-i-lukaszenki-o-polsce-bedziemy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T06:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/9d/1c/z30004215M,Prezydent-Rosji-Wladimir-Putin--z-lewej--i-prezyde.jpg" vspace="2" />- To jest kolejny w serii nieodpowiedzialnych komentarzy Łukaszenki - tak słowa o "wycieczce wagnerowców do Polski" skomentował rzecznik Departamentu Stanu USA. Matthew Miller podkreślił, że "Stany Zjednoczone będą bronić każdego centymetra terytorium NATO".

## Grupa turystów z Rodos uciekła przed pożarami. "Bałem się paniki". Inni nadal czekają na powrót do Polski
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005785,grupa-turystow-z-rodos-przed-pozarami-wyladowala-w-polsce-balem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30005785,grupa-turystow-z-rodos-przed-pozarami-wyladowala-w-polsce-balem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T05:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/32/9d/1c/z30005810M,Grecja--Pozary-na-Rodos--22-lipca-2023-r-.jpg" vspace="2" />Ulga - to chyba najbardziej zwięzły opis odczuć grupy polskich turystów, którzy w poniedziałek przed północą wrócili z Rodos do Polski. - Uciekliśmy z piekła - przyznaje jedna z kobiet ewakuowanych z powodu pożarów na greckiej wyspie. Inna osoba przyznaje, że "bała się paniki". Fala upałów panuje w Grecji z niewielkimi przerwami od 12 lipca, a Służba Meteorologiczna Grecji ostrzega przed kolejną falą - temperatura ma przekroczyć 45 st. Celsjusza.

## Marcin Duma z IBRiS o górnym pułapie Konfederacji. "Wszystkie sondaże są dosyć zgodne"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30005705,marcin-duma-z-ibris-o-gornym-pulapie-konfederacji-wszystkie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30005705,marcin-duma-z-ibris-o-gornym-pulapie-konfederacji-wszystkie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T04:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/84/98/1c/z29985668M,Krzysztof-Bosak--Slawomir-Mentzen-i-Konrad-Berkowi.jpg" vspace="2" />- Wszystkie badania, do których mam dostęp, (...) są dosyć zgodne i pokazują, że Konfederacja ma swój górny pułap mniej więcej na poziomie 20 proc. - powiedział w rozmowie z Onetem Marcin Duma, prezes pracowni sondażowej IBRiS.

## Wrocław. Policja zatrzymała kierowcę taksówki. Miał zgwałcić i okraść 26-latkę. Uber wydał oświadczenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005627,wroclaw-policja-zatrzymala-kierowce-taksowki-mial-zgwalcic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005627,wroclaw-policja-zatrzymala-kierowce-taksowki-mial-zgwalcic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T04:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/94/9d/1c/z30005652M,Wroclaw--Policja-zatrzymala-mezczyzne-podejrzanego.jpg" vspace="2" />Policjanci zatrzymali kierowcę, który podejrzewany jest o to, że zgwałcił i okradł swoją pasażerkę. 26-latka miała być pod wpływem alkoholu. 28-letniemu mężczyźnie postawiono zarzuty. Zastosowano również wobec niego areszt tymczasowy.

## Horoskop dzienny na wtorek 25 lipca dla wszystkich znaków zodiaku [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30003207,horoskop-dzienny-na-wtorek-25-lipca-dla-wszystkich-znakow-zodiaku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30003207,horoskop-dzienny-na-wtorek-25-lipca-dla-wszystkich-znakow-zodiaku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-07-25T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3c/9d/1c/z30003260M,Horoskop-dzienny---zdjecie-ilustracyjne.jpg" vspace="2" />Horoskop dzienny na wtorek 25 lipca 2023 roku. Kto będzie dziś użerał się z gburowatymi ludźmi, a kogo czeka spokojny, relaksujący dzień? Nie czekaj, odnajdź swój znak zodiaku i dowiedz się, co cię czeka.

