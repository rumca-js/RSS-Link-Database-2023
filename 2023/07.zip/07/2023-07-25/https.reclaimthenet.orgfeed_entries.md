# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Government Censorship Leads To “Atrocity,” RFK Jr. Warns After Being Attacked By House Democrats
 - [https://reclaimthenet.org/government-censorship-leads-to-atrocity-rfk-jr-warns](https://reclaimthenet.org/government-censorship-leads-to-atrocity-rfk-jr-warns)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-07-25T21:46:18+00:00

<a href="https://reclaimthenet.org/government-censorship-leads-to-atrocity-rfk-jr-warns" rel="nofollow" title="Government Censorship Leads To &#8220;Atrocity,&#8221; RFK Jr. Warns After Being Attacked By House Democrats"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/07/kennedy-2e32r.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The presidential hopeful is finding himself at odds with his own party on the topic of free speech.</p>
<p>The post <a href="https://reclaimthenet.org/government-censorship-leads-to-atrocity-rfk-jr-warns" rel="nofollow">Government Censorship Leads To &#8220;Atrocity,&#8221; RFK Jr. Warns After Being Attacked By House Democrats</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## UK Ministry of Justice Invests in Social Listening Tool
 - [https://reclaimthenet.org/uk-ministry-of-justice-invests-in-social-listening-tool](https://reclaimthenet.org/uk-ministry-of-justice-invests-in-social-listening-tool)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-07-25T21:38:07+00:00

<a href="https://reclaimthenet.org/uk-ministry-of-justice-invests-in-social-listening-tool" rel="nofollow" title="UK Ministry of Justice Invests in Social Listening Tool"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/07/uk-23.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Monitoring online conversations.</p>
<p>The post <a href="https://reclaimthenet.org/uk-ministry-of-justice-invests-in-social-listening-tool" rel="nofollow">UK Ministry of Justice Invests in Social Listening Tool</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Did Their Social Media Posts Lead To Their Bank Account Being Shut Down?
 - [https://reclaimthenet.org/did-their-social-media-posts-lead-to-their-bank-account-being-shut-down](https://reclaimthenet.org/did-their-social-media-posts-lead-to-their-bank-account-being-shut-down)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-07-25T21:34:35+00:00

<a href="https://reclaimthenet.org/did-their-social-media-posts-lead-to-their-bank-account-being-shut-down" rel="nofollow" title="Did Their Social Media Posts Lead To Their Bank Account Being Shut Down?"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/07/uk-debanked.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>More stories from debanked individuals out of the UK.</p>
<p>The post <a href="https://reclaimthenet.org/did-their-social-media-posts-lead-to-their-bank-account-being-shut-down" rel="nofollow">Did Their Social Media Posts Lead To Their Bank Account Being Shut Down?</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Biden’s State Department Ignores Deadline For Handing Over Censorship Documents
 - [https://reclaimthenet.org/biden-ignores-deadline-censorship-documents](https://reclaimthenet.org/biden-ignores-deadline-censorship-documents)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-07-25T21:28:31+00:00

<a href="https://reclaimthenet.org/biden-ignores-deadline-censorship-documents" rel="nofollow" title="Biden&#8217;s State Department Ignores Deadline For Handing Over Censorship Documents"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/07/biden-23243.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Refusing to comply with censorship investigations.</p>
<p>The post <a href="https://reclaimthenet.org/biden-ignores-deadline-censorship-documents" rel="nofollow">Biden&#8217;s State Department Ignores Deadline For Handing Over Censorship Documents</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Russia’s CBDC, The Digital Ruble, To Begin in August
 - [https://reclaimthenet.org/russias-cbdc-the-digital-ruble-to-begin-in-august](https://reclaimthenet.org/russias-cbdc-the-digital-ruble-to-begin-in-august)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-07-25T21:20:53+00:00

<a href="https://reclaimthenet.org/russias-cbdc-the-digital-ruble-to-begin-in-august" rel="nofollow" title="Russia&#8217;s CBDC, The Digital Ruble, To Begin in August"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/07/russa-cbdc.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>A centralized power grab.</p>
<p>The post <a href="https://reclaimthenet.org/russias-cbdc-the-digital-ruble-to-begin-in-august" rel="nofollow">Russia&#8217;s CBDC, The Digital Ruble, To Begin in August</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Meta’s Nick Clegg Brags About Censoring “Election Misinformation”
 - [https://reclaimthenet.org/metas-nick-clegg-brags-about-censoring-election-misinformation](https://reclaimthenet.org/metas-nick-clegg-brags-about-censoring-election-misinformation)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-07-25T16:10:27+00:00

<a href="https://reclaimthenet.org/metas-nick-clegg-brags-about-censoring-election-misinformation" rel="nofollow" title="Meta&#8217;s Nick Clegg Brags About Censoring &#8220;Election Misinformation&#8221;"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/07/clegg-343.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Nick Clegg says Meta is getting "better" at censoring.</p>
<p>The post <a href="https://reclaimthenet.org/metas-nick-clegg-brags-about-censoring-election-misinformation" rel="nofollow">Meta&#8217;s Nick Clegg Brags About Censoring &#8220;Election Misinformation&#8221;</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

