# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 🪱 Malware pod przykrywką AI
 - [https://www.youtube.com/watch?v=9tpj8Q_66N8](https://www.youtube.com/watch?v=9tpj8Q_66N8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-07-25T04:00:09+00:00

Zainteresowanie tematami związanymi ze sztuczną inteligencją nie słabnie. Oznacza to też w konsekwencji, że wykorzystują to cyberprzestępcy. Jak?
 
Źródła:
https://tinyurl.com/2rutfsc3

 
#AI #malware #botnet #BundleBot

