# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Tottenham Hotspur owner Joe Lewis indicted over 'brazen' insider trading scheme
 - [https://www.telegraph.co.uk/football/2023/07/26/tottenham-hotspur-owner-joe-lewis-indicted/](https://www.telegraph.co.uk/football/2023/07/26/tottenham-hotspur-owner-joe-lewis-indicted/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T23:35:34+00:00



## West Ham plot move for £45m Scott McTominay
 - [https://www.telegraph.co.uk/football/2023/07/25/manchester-united-transfer-news-west-ham-mctominay-move/](https://www.telegraph.co.uk/football/2023/07/25/manchester-united-transfer-news-west-ham-mctominay-move/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T21:30:00+00:00



## The best ergonomic office chairs in 2023 for remote working in comfort
 - [https://www.telegraph.co.uk/education-and-careers/0/best-ergonomic-office-chair/](https://www.telegraph.co.uk/education-and-careers/0/best-ergonomic-office-chair/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T16:23:04+00:00



## The 50 best shows to see at the Edinburgh Festivals 2023
 - [https://www.telegraph.co.uk/theatre/what-to-see/edinburgh-festival-fringe-preview-comedy-theatre-film-books/](https://www.telegraph.co.uk/theatre/what-to-see/edinburgh-festival-fringe-preview-comedy-theatre-film-books/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T16:20:00+00:00



## The best inflatable paddle boards of 2023, tried and tested on rivers, lakes and sea
 - [https://www.telegraph.co.uk/recommended/leisure/best-inflatable-stand-up-paddle-boards/](https://www.telegraph.co.uk/recommended/leisure/best-inflatable-stand-up-paddle-boards/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T16:11:15+00:00



## Over 350,000 smart meters switched remotely to more expensive tariffs
 - [https://www.telegraph.co.uk/money/consumer-affairs/smart-meters-switched-remotely-more-expensive-tariffs/](https://www.telegraph.co.uk/money/consumer-affairs/smart-meters-switched-remotely-more-expensive-tariffs/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T16:08:28+00:00



## Liverpool in limbo as Fabinho's £40m Saudi move hits snag
 - [https://www.telegraph.co.uk/football/2023/07/25/liverpool-transfer-news-fabinho-saudi-move-snag-romeo-lavia/](https://www.telegraph.co.uk/football/2023/07/25/liverpool-transfer-news-fabinho-saudi-move-snag-romeo-lavia/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T14:37:46+00:00



## Man hospitalised with Middle East Respiratory Syndrome in Abu Dhabi
 - [https://www.telegraph.co.uk/global-health/science-and-disease/mers-outbreak-middle-east-respiratory-syndrome-abu-dhabi/](https://www.telegraph.co.uk/global-health/science-and-disease/mers-outbreak-middle-east-respiratory-syndrome-abu-dhabi/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T14:27:00+00:00



## How to spend a foodie weekend in San Sebastián
 - [https://www.telegraph.co.uk/travel/destinations/europe/spain/san-sebastian/articles/san-sebastian-travel-guide/](https://www.telegraph.co.uk/travel/destinations/europe/spain/san-sebastian/articles/san-sebastian-travel-guide/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T14:00:00+00:00



## I’m running out of days for a miracle cure – but existing drugs could give me more time with family
 - [https://www.telegraph.co.uk/global-health/science-and-disease/motor-neurone-disease-mnd-drugs-treatment-therapy/](https://www.telegraph.co.uk/global-health/science-and-disease/motor-neurone-disease-mnd-drugs-treatment-therapy/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T13:49:57+00:00



## Seeing double: 'Four-eyed' elk captured on camera
 - [https://www.telegraph.co.uk/world-news/2023/07/25/photographer-captures-mesmerising-four-eyed-elk/](https://www.telegraph.co.uk/world-news/2023/07/25/photographer-captures-mesmerising-four-eyed-elk/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T13:10:31+00:00



## Families using private school fee tax avoidance schemes face fines in crackdown
 - [https://www.telegraph.co.uk/tax/news/crackdown-private-school-fee-tax-avoidance-scheme-fines/](https://www.telegraph.co.uk/tax/news/crackdown-private-school-fee-tax-avoidance-scheme-fines/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T12:46:01+00:00



## Nottingham Forest buy Anthony Elanga from Manchester United for £15m
 - [https://www.telegraph.co.uk/football/2023/07/21/nottingham-forest-sign-anthony-elanga-manchester-united/](https://www.telegraph.co.uk/football/2023/07/21/nottingham-forest-sign-anthony-elanga-manchester-united/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T12:41:04+00:00



## HSBC first major lender to cut mortgage rates
 - [https://www.telegraph.co.uk/personal-banking/mortgages/hsbc-first-high-street-bank-to-cut-mortgage-rates-inflation/](https://www.telegraph.co.uk/personal-banking/mortgages/hsbc-first-high-street-bank-to-cut-mortgage-rates-inflation/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T11:59:52+00:00



## China's foreign minister Qin Gang ousted
 - [https://www.telegraph.co.uk/world-news/2023/07/25/qin-gang-removed-china-foreign-minister-xi-jinping/](https://www.telegraph.co.uk/world-news/2023/07/25/qin-gang-removed-china-foreign-minister-xi-jinping/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T11:58:46+00:00



## Pension funds not taking enough risk will face ‘robust’ action, new regulator warns
 - [https://www.telegraph.co.uk/pensions-retirement/news/pension-funds-risk-will-face-robust-action-regulator/](https://www.telegraph.co.uk/pensions-retirement/news/pension-funds-risk-will-face-robust-action-regulator/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T11:57:48+00:00



## Lionesses need Lauren Hemp to hit top gear at World Cup
 - [https://www.telegraph.co.uk/football/2023/07/25/lionesses-need-lauren-hemp-to-hit-top-gear-at-world-cup/](https://www.telegraph.co.uk/football/2023/07/25/lionesses-need-lauren-hemp-to-hit-top-gear-at-world-cup/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T11:42:25+00:00



## Exposure to elite environments will grow the number of female coaches
 - [https://www.telegraph.co.uk/football/2023/07/25/telegraph-womens-sport-podcast-willie-kirk-coaching/](https://www.telegraph.co.uk/football/2023/07/25/telegraph-womens-sport-podcast-willie-kirk-coaching/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T09:59:32+00:00



## How female-specific spikes could be a game-changer in cricket
 - [https://www.telegraph.co.uk/cricket/2023/07/25/female-specific-cricket-spikes-could-be-game-changer/](https://www.telegraph.co.uk/cricket/2023/07/25/female-specific-cricket-spikes-could-be-game-changer/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T09:00:00+00:00



## Greece wildfires latest: Crete on alert as British tourist evacuations continue
 - [https://www.telegraph.co.uk/world-news/2023/07/25/rhodes-wildfires-news-latest-crete-corfu-british-tourists/](https://www.telegraph.co.uk/world-news/2023/07/25/rhodes-wildfires-news-latest-crete-corfu-british-tourists/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T08:15:32+00:00



## I would go to Rhodes tomorrow, says Michael Gove
 - [https://www.telegraph.co.uk/politics/2023/07/25/rhodes-wild-fires-michael-gove-would-go-tomorrow-holiday/](https://www.telegraph.co.uk/politics/2023/07/25/rhodes-wild-fires-michael-gove-would-go-tomorrow-holiday/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T08:10:16+00:00



## Premier League 2023-24 fixtures released: Key matches and full schedule for season
 - [https://www.telegraph.co.uk/football/2023/07/25/premier-league-fixtures-2023-2024-season-schedule-in-full-derbys/](https://www.telegraph.co.uk/football/2023/07/25/premier-league-fixtures-2023-2024-season-schedule-in-full-derbys/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:49:19+00:00



## Rugby World Cup 2023: Match schedule, how to watch, latest news and odds
 - [https://www.telegraph.co.uk/rugby-union/2023/07/25/rugby-world-cup-2023-when-where-watch-tv-latest-odds/](https://www.telegraph.co.uk/rugby-union/2023/07/25/rugby-world-cup-2023-when-where-watch-tv-latest-odds/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:48:17+00:00



## Ireland v England, Rugby World Cup 2023 warm-up: When is it and how to watch on TV
 - [https://www.telegraph.co.uk/rugby-union/2023/07/25/ireland-v-england-rugby-world-cup-2023-warm-up-when-is-it/](https://www.telegraph.co.uk/rugby-union/2023/07/25/ireland-v-england-rugby-world-cup-2023-warm-up-when-is-it/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:47:14+00:00



## England v Wales, Rugby World Cup 2023 warm-up: When is it and how to watch on TV
 - [https://www.telegraph.co.uk/rugby-union/2023/07/25/england-vs-wales-rugby-world-cup-2023-warm-up-when-is-it/](https://www.telegraph.co.uk/rugby-union/2023/07/25/england-vs-wales-rugby-world-cup-2023-warm-up-when-is-it/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:45:51+00:00



## The Rugby Championship 2023: Fixtures, results, how to watch and latest odds
 - [https://www.telegraph.co.uk/rugby-union/2023/07/25/rugby-championship-2023-fixtures-results-how-watch-uk-odds/](https://www.telegraph.co.uk/rugby-union/2023/07/25/rugby-championship-2023-fixtures-results-how-watch-uk-odds/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:44:43+00:00



## Oleksandr Usyk vs Daniel Dubois: When is the fight, how to watch and the undercard line-up
 - [https://www.telegraph.co.uk/boxing/2023/07/25/oleksandr-usyk-vs-daniel-dubois-when-date-tv-undercard/](https://www.telegraph.co.uk/boxing/2023/07/25/oleksandr-usyk-vs-daniel-dubois-when-date-tv-undercard/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:40:33+00:00



## Tyson Fury vs Francis Ngannou: When is the fight, how to watch and undercard line-up
 - [https://www.telegraph.co.uk/boxing/2023/07/25/tyson-fury-vs-francis-ngannou-when-date-tv-undercard/](https://www.telegraph.co.uk/boxing/2023/07/25/tyson-fury-vs-francis-ngannou-when-date-tv-undercard/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:39:30+00:00



## Anthony Joshua vs Dillian Whyte: When is the fight, how to watch and undercard line-up
 - [https://www.telegraph.co.uk/boxing/2023/07/25/anthony-joshua-vs-dillian-whyte-when-date-tv-undercard/](https://www.telegraph.co.uk/boxing/2023/07/25/anthony-joshua-vs-dillian-whyte-when-date-tv-undercard/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:38:20+00:00



## Ukraine-Russia war live: Russia strikes Kyiv in retaliation for Moscow attack
 - [https://www.telegraph.co.uk/world-news/2023/07/25/russia-ukraine-war-latest-kyiv-strike-moscow-drone-attack/](https://www.telegraph.co.uk/world-news/2023/07/25/russia-ukraine-war-latest-kyiv-strike-moscow-drone-attack/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:38:11+00:00



## England’s squad for the 2023 Women’s Football World Cup
 - [https://www.telegraph.co.uk/football/2023/07/25/england-squad-womens-world-cup-2023-players-injuries/](https://www.telegraph.co.uk/football/2023/07/25/england-squad-womens-world-cup-2023-players-injuries/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:19:35+00:00



## How to watch the 2023 Women's World Cup on TV in the UK and US
 - [https://www.telegraph.co.uk/football/2023/07/25/womens-world-cup-2023-how-to-watch-tv-uk-us-et-pt/](https://www.telegraph.co.uk/football/2023/07/25/womens-world-cup-2023-how-to-watch-tv-uk-us-et-pt/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:17:32+00:00



## Women’s World Cup 2023: Fixtures, full match schedule and wallchart to download
 - [https://www.telegraph.co.uk/football/2023/07/25/womens-world-cup-2023-fixtures-when-where-host-tickets/](https://www.telegraph.co.uk/football/2023/07/25/womens-world-cup-2023-fixtures-when-where-host-tickets/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:16:14+00:00



## England vs China, Women’s World Cup 2023: When is it and how to watch on TV
 - [https://www.telegraph.co.uk/football/2023/07/25/england-vs-china-womens-world-cup-2023-when-to-watch-tv/](https://www.telegraph.co.uk/football/2023/07/25/england-vs-china-womens-world-cup-2023-when-to-watch-tv/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:13:06+00:00



## England vs Denmark, Women’s World Cup 2023: When is it and how to watch on TV
 - [https://www.telegraph.co.uk/football/2023/07/25/england-vs-denmark-womens-world-cup-2023-when-to-watch-tv/](https://www.telegraph.co.uk/football/2023/07/25/england-vs-denmark-womens-world-cup-2023-when-to-watch-tv/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:11:01+00:00



## Manchester United vs Ryan Reynolds’ Wrexham: When is pre-season friendly?
 - [https://www.telegraph.co.uk/football/2023/07/25/manchester-united-vs-wrexham-ryan-reynolds-time-kick-off/](https://www.telegraph.co.uk/football/2023/07/25/manchester-united-vs-wrexham-ryan-reynolds-time-kick-off/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:09:05+00:00



## Next Ashes Test: 2023 England vs Australia fixtures, start times and TV channel
 - [https://www.telegraph.co.uk/cricket/2023/07/25/ashes-2023-england-vs-australia-fixtures-start-times-tv-channel-watch/](https://www.telegraph.co.uk/cricket/2023/07/25/ashes-2023-england-vs-australia-fixtures-start-times-tv-channel-watch/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:07:12+00:00



## Boom in ultra-long mortgages that mean a £500k house costs £1m
 - [https://www.telegraph.co.uk/personal-banking/mortgages/desperate-homeowners-turn-to-ultra-long-mortgages/](https://www.telegraph.co.uk/personal-banking/mortgages/desperate-homeowners-turn-to-ultra-long-mortgages/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:00:00+00:00



## Famines, Ebola and killer celery: global health bids farewell to the man behind a billion vaccines
 - [https://www.telegraph.co.uk/global-health/science-and-disease/seth-berkley-interview-gavi-vaccine-alliance/](https://www.telegraph.co.uk/global-health/science-and-disease/seth-berkley-interview-gavi-vaccine-alliance/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:00:00+00:00



## Guide to student renting (and how to become a landlord while at university)
 - [https://www.telegraph.co.uk/property/renting/student-renting-how-to-become-landlord-while-at-university/](https://www.telegraph.co.uk/property/renting/student-renting-how-to-become-landlord-while-at-university/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:00:00+00:00



## Opening round proves Fifa was right to expand Women’s World Cup to 32 teams
 - [https://www.telegraph.co.uk/football/2023/07/25/opening-round-fifa-right-to-expand-womens-world-cup-32-team/](https://www.telegraph.co.uk/football/2023/07/25/opening-round-fifa-right-to-expand-womens-world-cup-32-team/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T06:00:00+00:00



## How to get financial advice – at half the price of St James's Place
 - [https://www.telegraph.co.uk/investing/news/financial-advice-cheaper-st-james-place/](https://www.telegraph.co.uk/investing/news/financial-advice-cheaper-st-james-place/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T05:00:00+00:00



## This nimble wholesaler can hold its own against large rivals
 - [https://www.telegraph.co.uk/investing/shares/kitwave-nimble-wholesaler-growth-potential/](https://www.telegraph.co.uk/investing/shares/kitwave-nimble-wholesaler-growth-potential/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T05:00:00+00:00



## ‘I'm 81 with three impoverished children – what’s the best way to set them up financially?’
 - [https://www.telegraph.co.uk/tax/tax-hacks/im-81-with-three-impoverished-children-whats-the-best-way/](https://www.telegraph.co.uk/tax/tax-hacks/im-81-with-three-impoverished-children-whats-the-best-way/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T05:00:00+00:00



## Chris Bart-Williams, ex-Sheffield Wednesday and Nottingham Forest midfielder, dies at 49
 - [https://www.telegraph.co.uk/football/2023/07/25/chris-bart-williams-dies-wednesday-forest-midfielder/](https://www.telegraph.co.uk/football/2023/07/25/chris-bart-williams-dies-wednesday-forest-midfielder/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-07-25T01:31:31+00:00



