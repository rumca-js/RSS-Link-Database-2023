# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## PLEASE Stop Buying These
 - [https://www.youtube.com/watch?v=QALLc1jQrOE](https://www.youtube.com/watch?v=QALLc1jQrOE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-07-25T18:26:39+00:00

Get 69% off any of XSplit’s video tools. Use code LINUS at https://lmg.gg/XSplit

Create your build at https://www.buildredux.com/linus

Why build a new machine when you can save some money and buy used, repurposed parts slapped into a case with RGB and a tempered glass side panel from Ebay? Well, big surprise, they're not as good as you might be led to believe.

Discuss on the forum: https://linustechtips.com/topic/1521754-please-stop-buying-these

Buy an Intel Core i3-12100F CPU: https://geni.us/vCm3
Buy an ASRock H610M-HVS Micro ATX LGA1700 Motherboard: https://lmg.gg/0bsrc
Buy Silicon Power 3200 CL16 2x8GB DDR4 RAM: https://geni.us/vY6RQ8s
Buy a Team Group T-Force Vulcan Z 1TB 2.5" SSD: https://lmg.gg/8Vk1M
Buy a PNY XLR8 GeForce GTX 970 Graphics Card: https://geni.us/MkDU4
Buy a Deepcool MATREXX 40 Micro ATX/Mini ITX Tower Case: https://lmg.gg/wpLnz
Buy an EVGA 700 BR 80+ Bronze 700W PSU: https://geni.us/R5GiJv

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► EQUIPMENT WE USE TO FILM LTT: https://lmg.gg/LTTEquipment
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:44 What's in the box
4:30 CPU Nomenclature
5:28 GPU Nomenclature
8:30 Hardware Support
9:30 The Price
11:50 Bad Marketing
13:15 Conclusion
15:32 Outro

