# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## The Truth About Butterfly Metamorphosis (It's VERY WEIRD)
 - [https://www.youtube.com/watch?v=4RaCURU6A2o](https://www.youtube.com/watch?v=4RaCURU6A2o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2023-07-25T15:53:18+00:00

Check out @crashcourse Botany! https://www.youtube.com/watch?v=2th5lAd-77A 
↓↓↓ More info and sources below ↓↓↓

Does any other creature on Earth undergo a life transformation as dramatic as the butterfly? I think not. Unfortunately, children's books about very hungry caterpillars skip all the COOL and WEIRD and GROSS stuff that happens along the way. It's time to dig into all the mind-blowing biology behind metamorphosis!

Filmed on location at the California Academy of Sciences

0:00 We were lied to as kids
1:48 Metamorphosis is more common than you think
3:36 It starts with an egg
4:46 Eat/Poop/Grow
6:05 Busting the biggest butterfly myth of all
7:23 Time to take your skin off
8:40 Inside the "sack of magic"
11:08 Metamorphosis,… metamorphosis everywhere
11:55 Why do butterflies do this?
13:42 Sign up for our Patreon!

High fives to all our Brain Trust Patrons:

Holly, Brett, and Ashe Bullion
Jaap Westera
Millennial Glacier
Mehdi Damou
Barbora Bei
Burt Humburg
dani bowman
David Johnston
Baerbel Winkler
Robert Young
Eric Meer
Dustin
Karen Haskell

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

