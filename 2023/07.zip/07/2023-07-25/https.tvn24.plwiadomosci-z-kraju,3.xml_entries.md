# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Pomorskie. Dwa ciała odnalezione przez jednego z domowników
 - [https://tvn24.pl/polska/kobylnica-pomorskie-dwa-ciala-odnalezione-przez-jednego-z-domownikow-7258390?source=rss](https://tvn24.pl/polska/kobylnica-pomorskie-dwa-ciala-odnalezione-przez-jednego-z-domownikow-7258390?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T20:23:38+00:00

<img alt="Pomorskie. Dwa ciała odnalezione przez jednego z domowników " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xj6zxw-na-miejscu-pracuj-epolicja-zdjecie-ilustracyjne-7257027/alternates/LANDSCAPE_1280" />
    W jednym z domów w Kobylnicy (województwo pomorskie) mieszkaniec odnalazł ciała dwóch osób - poinformowała we wtorek policja. Jak podają lokalne media, ofiary śmiertelne to kobieta i jej 8-letni syn.

## Chcą realizować inwestycje, ale nie mogą, bo nie mają środków z KPO. "Wołamy i prosimy o te pieniądze"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/chca-realizowac-inwestycje-ale-nie-moga-bo-nie-maja-srodkow-z-kpo-wolamy-i-prosimy-o-te-pieniadze-7258408?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/chca-realizowac-inwestycje-ale-nie-moga-bo-nie-maja-srodkow-z-kpo-wolamy-i-prosimy-o-te-pieniadze-7258408?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T20:23:29+00:00

<img alt="Chcą realizować inwestycje, ale nie mogą, bo nie mają środków z KPO. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-8lqjzu-zuber-7258417/alternates/LANDSCAPE_1280" />
    Plany są zatwierdzone, inwestorzy czekają, ale brakuje funduszy. Tam, gdzie ma stanąć szpital, prowadzić obwodnica, albo powstać park na osiedlu pogórniczym - sieje pustka. Puste okazały się też obietnice, że unijne miliardy polski rząd samorządom jakoś wynagrodzi.

## Wyniki Eurojackpot z 25 lipca 2023. Jakie liczby padły podczas ostatniego losowania?
 - [https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia-250723-liczby-z-ostatniego-losowania-7258420?source=rss](https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia-250723-liczby-z-ostatniego-losowania-7258420?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T19:50:28+00:00

<img alt="Wyniki Eurojackpot z 25 lipca 2023. Jakie liczby padły podczas ostatniego losowania?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m1rom0-eurojackpot-s-shutterstock_743570785-4780960/alternates/LANDSCAPE_1280" />
    We wtorkowym losowaniu Eurojackpot po raz kolejny nie padła główna wygrana. Najbliżej rozbicia kumulacji było w Niemczech, Danii, Islandii, Norwegii i na Słowacji. W Polsce odnotowano jedną nagrodę trzeciego stopnia. Kumulacja rośnie do 400 milionów złotych.

## Na filmiku pokazał, jak "gasi pożary w rolnictwie". Nagranie ministra Telusa hitem internetu
 - [https://fakty.tvn24.pl/zobacz-fakty/na-filmiku-pokazal-jak-gasi-pozary-w-rolnictwie-nagranie-ministra-telus-hitem-internetu-chociaz-z-jego-oficjalnego-7258359?source=rss](https://fakty.tvn24.pl/zobacz-fakty/na-filmiku-pokazal-jak-gasi-pozary-w-rolnictwie-nagranie-ministra-telus-hitem-internetu-chociaz-z-jego-oficjalnego-7258359?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T19:48:42+00:00

<img alt="Na filmiku pokazał, jak " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-ijljo5-na-filmiku-pokazal-jak-gasi-pozary-w-rolnictwie-nagranie-ministra-telusa-hitem-internetu-7258366/alternates/LANDSCAPE_1280" />
    Czy można jakoś połączyć Roberta Telusa, gaśnicę i wojnę w Ukrainie? Okazuje się, że dla ministra rolnictwa nie ma rzeczy niemożliwych, a jego filmik, chociaż już usunięty z oficjalnego profilu, robi furorę w sieci.

## Obawy przed zabudową "Psiej Górki". Radni chcą zmian w projekcie studium
 - [https://tvn24.pl/tvnwarszawa/ursynow/warszawa-czy-psia-gorka-bedzie-zabudowana-7258185?source=rss](https://tvn24.pl/tvnwarszawa/ursynow/warszawa-czy-psia-gorka-bedzie-zabudowana-7258185?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T19:40:20+00:00

<img alt="Obawy przed zabudową " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-f7fwwa-na-czesci-terenu-psiej-gorki-pojawilo-sie-ogrodzenie-7258272/alternates/LANDSCAPE_1280" />
    Mieszkańcy warszawskiego Ursynowa martwią się, że "Psia Górka" zostanie zabudowana. Ich niepokój wzbudziło ogrodzenie z napisem "tu powstaje nowa inwestycja". Lokalni radni zaapelowali domagają się od prezydenta Warszawy zmiany w zapisach studium zagospodarowania przestrzennego.

## Zaskakujące odkrycie w centrum Warszawy. Kiedyś była tu granica światów
 - [https://tvn24.pl/tvnwarszawa/najnowsze/zaskakujace-odkrycie-w-centrum-warszawy-kiedys-byla-tu-granica-swiatow-7258258?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/zaskakujace-odkrycie-w-centrum-warszawy-kiedys-byla-tu-granica-swiatow-7258258?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T19:15:09+00:00

<img alt="Zaskakujące odkrycie w centrum Warszawy. Kiedyś była tu granica światów" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-42qzth-znaleziska-na-przebudowie-marszalkowskiej-7258224/alternates/LANDSCAPE_1280" />
    Podczas pracach remontowych na Marszałkowskiej robotnicy dokopali się do fundamentów przedwojennych kamienic. Piwnice są jedynym reliktem budynków, które kiedyś stały na symbolicznej granicy salonu i handlu.

## Pakt senacki to "kwestia kilku najbliższych dni". Ma być wielu kandydatów spośród samorządowców
 - [https://fakty.tvn24.pl/zobacz-fakty/pakt-senacki-to-kwestia-kilku-najblizszych-dni-ma-byc-wielu-kandydatow-sposrod-samorzadowcow-7258340?source=rss](https://fakty.tvn24.pl/zobacz-fakty/pakt-senacki-to-kwestia-kilku-najblizszych-dni-ma-byc-wielu-kandydatow-sposrod-samorzadowcow-7258340?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T18:43:00+00:00

<img alt="Pakt senacki to " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-ar0ea1-kkz-7258342/alternates/LANDSCAPE_1280" />
    Coraz więcej wiadomo o porozumieniu opozycji w sprawie paktu senackiego. Liderzy - jak zapewniają - zbliżają się do końca ustaleń w sprawie kandydatów. Wśród nich może być wielu samorządowców, ale nie zabraknie też rozpoznawalnych nazwisk.

## 800 plus od czerwca? Senatorowie zgłosili poprawkę
 - [https://tvn24.pl/biznes/z-kraju/800-plus-7258338?source=rss](https://tvn24.pl/biznes/z-kraju/800-plus-7258338?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T18:40:05+00:00

<img alt="800 plus od czerwca? Senatorowie zgłosili poprawkę" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-5n4btr-od-soboty-mozna-korzystac-z-bonu-turystycznego-4653973/alternates/LANDSCAPE_1280" />
    Senacka komisja zaproponowała, by świadczenie 500 plus zostało zwiększone o 300 złotych z mocą od czerwca 2023 roku. Senatorowie zgłosili odpowiednią poprawkę do nowelizacji ustawy budżetowej na 2023 rok.

## W Singapurze ma dojść do pierwszej od prawie 20 lat egzekucji na kobiecie
 - [https://tvn24.pl/swiat/singapur-zaplanowano-pierwsza-od-20-lat-egzekucje-na-kobiecie-7258040?source=rss](https://tvn24.pl/swiat/singapur-zaplanowano-pierwsza-od-20-lat-egzekucje-na-kobiecie-7258040?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T18:06:03+00:00

<img alt="W Singapurze ma dojść do pierwszej od prawie 20 lat egzekucji na kobiecie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-idngea-changi-prison-7258314/alternates/LANDSCAPE_1280" />
    W Singapurze ma dojść do pierwszego od prawie 20 lat wykonania kary śmierci na kobiecie. Saridewi Djamani została skazana w 2018 roku po tym, jak uznano ją za winną posiadania około 30 gramów heroiny.

## Pogoda na jutro - środa. 26.07. Noc z pochmurnym niebem i deszczem, w dzień również popada
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-sroda-2607-noc-z-pochmurnym-niebem-i-deszczem-w-dzien-rowniez-popada-7257900?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-sroda-2607-noc-z-pochmurnym-niebem-i-deszczem-w-dzien-rowniez-popada-7257900?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T17:04:17+00:00

<img alt="Pogoda na jutro - środa. 26.07. Noc z pochmurnym niebem i deszczem, w dzień również popada " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-yov0jt-noca-popada-deszcz-6122333/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na środę 26.07. W nocy w wielu regionach kraju będzie padał deszcz. W dzień również pojawią się opady, lokalnie też zagrzmi. Termometry pokażą maksymalnie 22 stopnie Celsjusza.

## Mieszkańcy gminy Goleniów nie chcą spalarni odpadów medycznych i weterynaryjnych
 - [https://fakty.tvn24.pl/fakty-po-poludniu/mieszkancy-gminy-goleniow-nie-chca-spalarni-odpadow-medycznych-i-weterynaryjnych-7257992?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/mieszkancy-gminy-goleniow-nie-chca-spalarni-odpadow-medycznych-i-weterynaryjnych-7257992?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T16:39:27+00:00

<img alt="Mieszkańcy gminy Goleniów nie chcą spalarni odpadów medycznych i weterynaryjnych" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-15m1c0-mieszkancy-gminy-goleniow-nie-chca-spalarni-odpadow-medycznych-i-weterynaryjnych-7257993/alternates/LANDSCAPE_1280" />
    Mieszkańcy gminy Goleniów protestują przeciwko planom budowy zakładu utylizacji odpadów medycznych i weterynaryjnych, bo boją się o swoje zdrowie i środowisko. Działka, na której zakład miałby powstać, należy do Portu Lotniczego Szczecin-Goleniów.

## Powołano nowego prezesa Elektrociepłowni Będzin
 - [https://tvn24.pl/biznes/z-kraju/elektrocieplownia-bedzin-marcin-chodkowski-nowym-prezesem-7258034?source=rss](https://tvn24.pl/biznes/z-kraju/elektrocieplownia-bedzin-marcin-chodkowski-nowym-prezesem-7258034?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T15:43:33+00:00

<img alt="Powołano nowego prezesa Elektrociepłowni Będzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bqmfd5-elektrocieplownia-bedzin-7245340/alternates/LANDSCAPE_1280" />
    Marcin Chodkowski został powołany na stanowisko prezesa przez radę nadzorczą Elektrociepłowni Będzin - podano w komunikacie. Chodkowski pełnił funkcję wiceprezesa do spraw korporacyjnych, ze spółką związany jest od stycznia 2023 roku.

## Papież Franciszek do młodej transpłciowej Włoszki: Bóg kocha nas takimi, jakimi jesteśmy
 - [https://tvn24.pl/swiat/papiez-franciszek-do-mlodej-transplciowej-wloszki-bog-kocha-nas-takimi-jakimi-jestesmy-7257961?source=rss](https://tvn24.pl/swiat/papiez-franciszek-do-mlodej-transplciowej-wloszki-bog-kocha-nas-takimi-jakimi-jestesmy-7257961?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T15:26:00+00:00

<img alt="Papież Franciszek do młodej transpłciowej Włoszki: Bóg kocha nas takimi, jakimi jesteśmy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bhhom9-papiez-franciszek-7257989/alternates/LANDSCAPE_1280" />
    Bóg kocha nas takimi, jakimi jesteśmy - tak papież odpowiedział młodej transpłciowej osobie w opublikowanym podcaście watykańskich mediów z okazji zbliżających się Światowych Dni Młodzieży w Lizbonie. Reuters zauważa, że to kolejny gest papieża w kierunku społeczności LGBT.

## MSZ Mołdawii zapowiada wezwanie rosyjskiego ambasadora. Chodzi o podejrzenie szpiegostwa
 - [https://tvn24.pl/swiat/rosja-moldawia-msz-moldawii-zapowiada-wezwanie-rosyjskiego-ambasadora-w-kiszyniowie-chodzi-o-podejrzenie-szpiegostwa-7257873?source=rss](https://tvn24.pl/swiat/rosja-moldawia-msz-moldawii-zapowiada-wezwanie-rosyjskiego-ambasadora-w-kiszyniowie-chodzi-o-podejrzenie-szpiegostwa-7257873?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T15:18:29+00:00

<img alt="MSZ Mołdawii zapowiada wezwanie rosyjskiego ambasadora. Chodzi o podejrzenie szpiegostwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-38153t-ambasada-rosji-w-kiszyniowie-7257890/alternates/LANDSCAPE_1280" />
    MSZ Mołdawii zapowiedziało, że wezwie ambasadora Rosji Olega Wasniecowa w celu wyjaśnienia doniesień medialnych, że na dachu rosyjskiej ambasady w Kiszyniowie zainstalowano sprzęt, który może służyć do szpiegowania.

## To "pod wieloma względami tymczasowi uchodźcy klimatyczni"
 - [https://tvn24.pl/tvnmeteo/swiat/pozary-i-upaly-w-grecji-przyczyny-naukowcy-o-przytlaczajacej-roli-zmian-klimatu-raport-world-weather-attribution-7257268?source=rss](https://tvn24.pl/tvnmeteo/swiat/pozary-i-upaly-w-grecji-przyczyny-naukowcy-o-przytlaczajacej-roli-zmian-klimatu-raport-world-weather-attribution-7257268?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T14:56:37+00:00

<img alt="To " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ab7huh-pozary-na-polwyspie-peloponez-7257902/alternates/LANDSCAPE_1280" />
    Pożary na Rodos strawiły do tej pory około 10 procent powierzchni wyspy - podała publiczna grecka telewizja ERT. Prokuratura bada przyczyny pożarów, a także reakcję na nie krajowych władz. Według raportu naukowców z instytucji World Weather Attribution, który ukazał się we wtorek, negatywne zmiany klimatu wywołane przez człowieka odegrały "przytłaczającą rolę" w lipcowej fali upałów, która stworzyła korzystne warunki dla rozprzestrzeniania się ognia.

## Zjechał na pobocze i uderzył w przydrożne drzewo. 32-latek zginął
 - [https://tvn24.pl/tvnwarszawa/ulice/chotycze-dw-698-kierowca-bmw-uderzyl-w-drzewo-32-latek-nie-przezyl-7257928?source=rss](https://tvn24.pl/tvnwarszawa/ulice/chotycze-dw-698-kierowca-bmw-uderzyl-w-drzewo-32-latek-nie-przezyl-7257928?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T14:26:45+00:00

<img alt="Zjechał na pobocze i uderzył w przydrożne drzewo. 32-latek zginął" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-oaqew1-smiertelny-wypadek-w-miejscowosci-chotycze-7257895/alternates/LANDSCAPE_1280" />
    Tragiczny wypadek w miejscowości Chotycze w Mazowieckiem. Kierowca auta osobowego stracił panowanie nad autem i uderzył w drzewo. 32-latek nie przeżył.

## "Szybko żeśmy dojrzewali. Staraliśmy się zrozumieć, co to jest wolność"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-79-rocznica-powstania-warszawskiego-program-przeslanie-haslo-7257617?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-79-rocznica-powstania-warszawskiego-program-przeslanie-haslo-7257617?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T14:23:46+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-n9syds-79-rocznica-powstania-warszawskiego-7218565/alternates/LANDSCAPE_1280" />
    - Co roku spotykamy się w miejscach, które są ważne dla Powstania Warszawskiego - powiedział Rafał Trzaskowski na konferencji prasowej, poświęconej programowi obchodów 79. rocznicy wybuchu powstania. Zaznaczył, że takich miejsc będą dziesiątki, "o ile nie setki".

## Ważna zmiana dla kupujących pierwsze mieszkanie. "Oszczędność nawet kilkunastu tysięcy złotych"
 - [https://tvn24.pl/biznes/nieruchomosci/pcc-kupno-pierwszego-mieszkania-bedzie-zwolnione-z-podatku-7257872?source=rss](https://tvn24.pl/biznes/nieruchomosci/pcc-kupno-pierwszego-mieszkania-bedzie-zwolnione-z-podatku-7257872?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T14:09:07+00:00

<img alt="Ważna zmiana dla kupujących pierwsze mieszkanie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-h41y28-osiedle-dom-domy-mieszkanie-mieszkania-shutterstock_1723278520-7038203/alternates/LANDSCAPE_1280" />
    Nowela ustawy w sprawie między innymi likwidacji użytkowania wieczystego znosi podatek od czynności cywilnoprawnych przy zakupie pierwszego mieszkania na rynku wtórnym - podkreślił minister rozwoju i technologii Waldemar Buda. Dodał, że wprowadza ona natomiast 6 procent stawkę PCC od zakupu szóstego i kolejnego mieszkania.

## Zielona woda w rzece i "fetor nie do zniesienia". Powodem wymiana rur ciepłociągu
 - [https://tvn24.pl/krakow/krakow-zielona-woda-i-smrod-w-rzece-drwince-w-parku-jerzmanowskich-7257859?source=rss](https://tvn24.pl/krakow/krakow-zielona-woda-i-smrod-w-rzece-drwince-w-parku-jerzmanowskich-7257859?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T14:07:05+00:00

<img alt="Zielona woda w rzece i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6vq4y3-rzeka-drwinka-w-krakowie-7257704/alternates/LANDSCAPE_1280" />
    Rzeka Drwinka w Krakowie zmieniła kolor na zielony. We wtorek rano zaniepokojeni mieszkańcy zawiadomili o sprawie służby. Okazuje się, że za nietypowe zabarwienie wody odpowiadają pracownicy Miejskiego Przedsiębiorstwa Energetyki Cieplnej, wymieniający w okolicy fragment ciepłociągu. Jak wyjaśnia miasto, prawdopodobnie doszło do rozszczelnienia i do rzeki dostała się woda z barwnikiem. - Jest to substancja całkowicie bezpieczna dla ludzi i środowiska - zapewnia nas Renata Krężel z MPEC.

## Bocian wypadł z gniazda i zawisł na sznurku. Z pomocą ruszyli strażacy
 - [https://tvn24.pl/pomorze/przeczno-bocian-wypadl-z-gniazda-i-zawisl-na-sznurku-z-pomoca-ruszyli-strazacy-7257801?source=rss](https://tvn24.pl/pomorze/przeczno-bocian-wypadl-z-gniazda-i-zawisl-na-sznurku-z-pomoca-ruszyli-strazacy-7257801?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T13:20:10+00:00

<img alt="Bocian wypadł z gniazda i zawisł na sznurku. Z pomocą ruszyli strażacy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-os3dhv-strazacy-uratowali-bociana-7257781/alternates/LANDSCAPE_1280" />
    Strażacy z Brzewnika i Choszczna (woj. zachodniopomorskie) uratowali bociana, który wypadł z gniazda i zawisł na sznurku tuż obok linii energetycznej. Ptak nie mógł się uwolnić i każdy jego ruch mógł spowodować dotknięcie drutów, w których płynął prąd.

## Magazynował ponad 150 kilogramów narkotyków. W aucie miał skrytki sterowane pilotem
 - [https://tvn24.pl/pomorze/wloclawek-magazynowal-ponad-150-kilogramow-narkotykow-w-aucie-mial-skrytki-sterowane-pilotem-7257352?source=rss](https://tvn24.pl/pomorze/wloclawek-magazynowal-ponad-150-kilogramow-narkotykow-w-aucie-mial-skrytki-sterowane-pilotem-7257352?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T13:12:53+00:00

<img alt="Magazynował ponad 150 kilogramów narkotyków. W aucie miał skrytki sterowane pilotem" src="https://tvn24.pl/pomorze/cdn-zdjecie-7qlttn-magazynowal-ponad-150-kilogramow-narkotykow-w-aucie-mial-skrytki-sterowane-pilotem-7257768/alternates/LANDSCAPE_1280" />
    Ponad 150 kg różnego rodzaju narkotyków magazynował we Włocławku 32-letni mężczyzna. Został przyłapany przez policjantów podczas rozładunku nielegalnego towaru. Do jego przewożenia miał specjalnie przystosowany samochód ze skrytkami.

## Uczeń zawieszony za memy o dyrektorze. Władze szkoły pozwane
 - [https://tvn24.pl/swiat/usa-uczen-zawieszony-za-memy-pozywa-wladze-szkoly-w-stanie-tennessee-7257569?source=rss](https://tvn24.pl/swiat/usa-uczen-zawieszony-za-memy-pozywa-wladze-szkoly-w-stanie-tennessee-7257569?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T12:54:51+00:00

<img alt="Uczeń zawieszony za memy o dyrektorze. Władze szkoły pozwane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7cl4zs-syn-stracil-smartfona-ojciec-ruszyl-na-poszukiwania-zdj-ilustracyjne-6166991/alternates/LANDSCAPE_1280" />
    Siedemnastoletni uczeń szkoły średniej w amerykańskim stanie Tennessee przed rokiem został zawieszony na trzy dni po tym, jak opublikował w mediach społecznościowych memy przedstawiające dyrektora placówki. Teraz matka nastolatka pozywa władze szkoły w związku z "naruszeniem jego praw", gwarantowanych przez Pierwszą Poprawkę do Konstytucji USA.

## Samolot gaszący pożary rozbił się w Grecji
 - [https://tvn24.pl/swiat/grecja-pozary-samolot-gasniczy-rozbil-sie-w-miescie-karistos-7257716?source=rss](https://tvn24.pl/swiat/grecja-pozary-samolot-gasniczy-rozbil-sie-w-miescie-karistos-7257716?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T12:49:16+00:00

<img alt="Samolot gaszący pożary rozbił się w Grecji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1rwdd5-pozary-w-grecji-7257727/alternates/LANDSCAPE_1280" />
    Samolot walczący z pożarami w Grecji typu Canadair rozbił się we wtorek w mieście Karistos na wyspie Eubea - poinformowała straż pożarna, nie podając dalszych szczegółów.

## Gdzie jest burza? Grzmi i błyska się w dwóch regionach
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-we-wtorek-2507-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-7257615?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-we-wtorek-2507-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-7257615?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T11:47:04+00:00

<img alt="Gdzie jest burza? Grzmi i błyska się w dwóch regionach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-53rdnq-burze-7257701/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? We wtorek po południu w części kraju pojawiły się wyładowania atmosferyczne. Sprawdź, gdzie jest burza, i śledź aktualną sytuację pogodową na tvnmeteo.pl.

## Były pastor przyznał, że pięć dekad temu zamordował 8-latkę. Porwał ją w drodze na obóz biblijny
 - [https://tvn24.pl/swiat/usa-byly-pastor-przyznal-ze-50-lat-temu-zamordowal-8-latke-7257446?source=rss](https://tvn24.pl/swiat/usa-byly-pastor-przyznal-ze-50-lat-temu-zamordowal-8-latke-7257446?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T11:44:15+00:00

<img alt="Były pastor przyznał, że pięć dekad temu zamordował 8-latkę. Porwał ją w drodze na obóz biblijny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k6tmya-david-zandstra-i-gretchen-harrington-7257537/alternates/LANDSCAPE_1280" />
    David Zandstra, 83-letni były pastor z Pensylwanii, został oskarżony o porwanie i zamordowanie 8-letniej Gretchen Harrington. Ciało dziewczynki zostało znalezione w październiku 1975 roku. Mężczyzna przyznał się do winy. Porwał dziecko w drodze na obóz biblijny, w ramach którego prowadził zajęcia.

## Niebezpieczne odpady zalegają w Wołominie. Minister umywa ręce i zasłania się decyzją starosty sprzed ośmiu lat
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wolomin-odpady-zalegaja-na-dzialce-minister-umywa-rece-i-zaslania-sie-decyzja-starosty-sprzed-osmiu-lat-7257124?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wolomin-odpady-zalegaja-na-dzialce-minister-umywa-rece-i-zaslania-sie-decyzja-starosty-sprzed-osmiu-lat-7257124?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T11:38:19+00:00

<img alt="Niebezpieczne odpady zalegają w Wołominie. Minister umywa ręce i zasłania się decyzją starosty sprzed ośmiu lat " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-l0eif6-skladowisko-odpadow-w-wolominie-7257508/alternates/LANDSCAPE_1280" />
    Od 16 do 20 tysięcy litrów niebezpiecznych odpadów zalega na jednej z działek w Wołominie. Koszt ich usunięcia jest szacowany na 200 milionów złotych. Samorząd nie jest w stanie wygospodarować takiej kwoty i apeluje do władz centralnych o działanie w trybie "zarządzania kryzysowego". Wiceminister klimatu i środowiska Jacek Ozdoba uważa, że skoro składowisko mogło powstać na mocy decyzji starosty powiatowego sprzed ośmiu lat, jego utylizację powinien dofinansować urząd marszałkowski.

## Bili i kopali po całym ciele, a na koniec okradli. Tymczasowy areszt dla sprawców rozboju
 - [https://tvn24.pl/krakow/wadowice-swoja-ofiare-bili-i-kopali-po-calym-ciele-a-na-koniec-okradli-tymczasowy-areszt-dla-sprawcow-rozboju-7257585?source=rss](https://tvn24.pl/krakow/wadowice-swoja-ofiare-bili-i-kopali-po-calym-ciele-a-na-koniec-okradli-tymczasowy-areszt-dla-sprawcow-rozboju-7257585?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T11:37:56+00:00

<img alt="Bili i kopali po całym ciele, a na koniec okradli. Tymczasowy areszt dla sprawców rozboju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vyuqem-kopali-i-bili-mezczyzne-po-twarzy-i-calym-ciele-zostali-aresztowani-7257488/alternates/LANDSCAPE_1280" />
    Policjanci z Wadowic (woj. małopolskie) zatrzymali dwóch mężczyzn, podejrzanych o rozbój na 41-latku. Napastnicy bili i kopali swoją ofiarę po całym ciele i okradli. Obaj usłyszeli zarzuty i decyzją sądu zostali aresztowani na trzy miesiące.

## Protest koksowników przed Sejmem. "Przyjechaliśmy z jednym postulatem"
 - [https://tvn24.pl/polska/sejm-protest-koksownikow-przeciwko-planom-wdrozenia-skladki-solidarnosciowej-7257410?source=rss](https://tvn24.pl/polska/sejm-protest-koksownikow-przeciwko-planom-wdrozenia-skladki-solidarnosciowej-7257410?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T11:36:55+00:00

<img alt="Protest koksowników przed Sejmem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yk28et-protest-koksownikow-przed-sejmem-7257399/alternates/LANDSCAPE_1280" />
    We wtorek przed Sejmem odbywa się protest pracowników Koksowni Częstochowa Nowa, którzy opowiadają się przeciwko planom wdrożenia składki solidarnościowej dla dużych przedsiębiorstw z sektora węglowego. Jak przekazał przedstawiciel związków zawodowych Mariusz Ciupiński, koksownia "musi zapłacić kilkudziesięciomilionową składkę solidarnościową za to, że uzyskała zysk".

## Chciała dać łapówkę egzaminatorowi, wezwał policję
 - [https://tvn24.pl/tvnwarszawa/najnowsze/sochaczew-chciala-przekupic-egzaminatora-przyjechala-policja-7257462?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/sochaczew-chciala-przekupic-egzaminatora-przyjechala-policja-7257462?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T11:19:10+00:00

<img alt="Chciała dać łapówkę egzaminatorowi, wezwał policję" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bje0ea-kobieta-chciala-przekupic-egzaminatora-zdjecie-ilustracyjne-7257484/alternates/LANDSCAPE_1280" />
    W Sochaczewie 45-latka w zamian za pozytywny wynik testu chciała dać łapówkę egzaminatorowi. Oburzony mężczyzna zawiadomił policję.

## Grupa wytwarzała i wprowadzała na rynek "nowe substancje psychoaktywne". 11 osób aresztowanych
 - [https://tvn24.pl/lodz/lodz-grupa-wytwarzala-i-wprowadzala-na-rynek-nowe-substancje-psychoaktywne-11-osob-aresztowanych-7257466?source=rss](https://tvn24.pl/lodz/lodz-grupa-wytwarzala-i-wprowadzala-na-rynek-nowe-substancje-psychoaktywne-11-osob-aresztowanych-7257466?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T11:07:20+00:00

<img alt="Grupa wytwarzała i wprowadzała na rynek " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yjnnxx-11-osob-zostalo-tymczasowo-aresztowanych-7257459/alternates/LANDSCAPE_1280" />
    Policjanci z Łodzi zatrzymali 11 osób, które działały w zorganizowanej grupie przestępczej, zajmującej się wytwarzaniem i wprowadzaniem do obrotu narkotyków. Wszyscy usłyszeli zarzuty. Sąd na wniosek prokuratora aresztował zatrzymanych na trzy miesiące.

## Wirus dziesiątkuje hodowle. Potwierdzono cztery ogniska rzekomego pomoru drobiu
 - [https://tvn24.pl/bialystok/podlasie-wirus-dziesiatkuje-hodowle-potwierdzono-cztery-ogniska-rzekomego-pomoru-drobiu-7257469?source=rss](https://tvn24.pl/bialystok/podlasie-wirus-dziesiatkuje-hodowle-potwierdzono-cztery-ogniska-rzekomego-pomoru-drobiu-7257469?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T11:02:28+00:00

<img alt="Wirus dziesiątkuje hodowle. Potwierdzono cztery ogniska rzekomego pomoru drobiu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vowzi6-drob-zaatakowala-choroba-ktorej-ostatnie-przypadek-odnotowano-w-polsce-49-lat-temu-zdjecie-ilustracyjne-7224206/alternates/LANDSCAPE_1280" />
    Dotąd w województwie podlaskim potwierdzono cztery ogniska rzekomego pomoru drobiu, wszystkie znajdują się na terenie powiatu białostockiego - poinformował Wojewódzki Inspektorat Weterynarii. Wojewoda podlaski wydał nowe rozporządzenie w sprawie zwalczania choroby.

## Ubezpieczenie turystyczne. Ile kosztuje i na co zwracać uwagę przy zakupie?
 - [https://tvn24.pl/biznes/z-kraju/ubezpieczenie-turystyczne-ile-kosztuje-i-na-co-zwracac-uwage-przy-zakupie-7257295?source=rss](https://tvn24.pl/biznes/z-kraju/ubezpieczenie-turystyczne-ile-kosztuje-i-na-co-zwracac-uwage-przy-zakupie-7257295?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T11:00:53+00:00

<img alt="Ubezpieczenie turystyczne. Ile kosztuje i na co zwracać uwagę przy zakupie?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4b9er3-mykonos-grecja-wakacje-s-gimas-shutterstock_1761362066-5151708/alternates/LANDSCAPE_1280" />
    Wyjeżdżając na zagraniczne wakacje myślimy często już tylko o odpoczynku i relaksie, ale musimy pamiętać, że i w trakcie urlopu możemy zachorować lub ulec wypadkowi. I chociaż wolimy nie dopuszczać do siebie takiej myśli, to lepiej być przezornym i zakupić dodatkowe ubezpieczenie turystyczne. To stosunkowo niewielki koszt, a może uchronić nas przed dużymi wydatkami za świadczenia medyczne.

## Szymon Hołownia o pakcie senackim: Posunięto się o kilka kolejnych okręgów
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-pakt-senacki-szymon-holownia-posunieto-sie-o-kilka-kolejnych-okregow-dzisiaj-mozliwe-spotkanie-liderow-7257326?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-pakt-senacki-szymon-holownia-posunieto-sie-o-kilka-kolejnych-okregow-dzisiaj-mozliwe-spotkanie-liderow-7257326?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T10:09:43+00:00

<img alt="Szymon Hołownia o pakcie senackim: Posunięto się o kilka kolejnych okręgów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l37nlm-pap_20230721_1qr-1-7257363/alternates/LANDSCAPE_1280" />
    W najbliższych dniach pakt senacki może zostać dopięty - mówił lider Polski 2050 Szymon Hołownia. Odnosząc się w RMF FM do poniedziałkowych negocjacji, powiedział, że "posunięto się o kilka kolejnych okręgów". Przekazał, że być może we wtorek odbędzie się spotkanie liderów opozycji.

## 12-latek uratował babcię z pożaru. Po chwili wrócił po psa i papugę
 - [https://tvn24.pl/bialystok/lublin-12-latej-uratowal-babcie-z-pozaru-po-chwili-wrocil-po-psa-i-papuge-7257294?source=rss](https://tvn24.pl/bialystok/lublin-12-latej-uratowal-babcie-z-pozaru-po-chwili-wrocil-po-psa-i-papuge-7257294?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T09:56:16+00:00

<img alt="12-latek uratował babcię z pożaru. Po chwili wrócił po psa i papugę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ud0qdg-12-letni-chlopiec-uratowal-babcie-z-pozaru-7257306/alternates/LANDSCAPE_1280" />
    W Lublinie 12-letni chłopiec wyprowadził z pożaru 83-letnią babcię. Po chwili - jak przekazała policja - wrócił po psa i po papugę. Nikomu na szczęście nic się nie stało, strażacy szybko ugasili ogień.

## Jechał bez kasku i z promilami. Nie zatrzymał się do kontroli i uderzył w radiowóz
 - [https://tvn24.pl/lodz/huta-wieruszow-jechal-bez-kasku-i-z-promilami-nie-zatrzymal-sie-do-kontroli-i-uderzyl-w-radiowoz-7257350?source=rss](https://tvn24.pl/lodz/huta-wieruszow-jechal-bez-kasku-i-z-promilami-nie-zatrzymal-sie-do-kontroli-i-uderzyl-w-radiowoz-7257350?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T09:48:40+00:00

<img alt="Jechał bez kasku i z promilami. Nie zatrzymał się do kontroli i uderzył w radiowóz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0uolza-policja-upublicznila-wizerunek-chlopaka-5646508/alternates/LANDSCAPE_1280" />
    Kierujący motorowerem jechał bez kasku, nie reagował na znaki policjantów do zatrzymania się, przyspieszył i uderzył w radiowóz. Jak informuje policja z Wieruszowa (woj. łódzkie), 25-latek był nietrzeźwy, miał blisko półtora promila alkoholu w organizmie.

## Kolejny gigant komórkowy szykuje zmiany dla klientów. UKE o terminie
 - [https://tvn24.pl/biznes/z-kraju/orange-polska-wylaczy-siec-3g-wczesniej-zrobilo-to-t-mobile-polska-urzad-komunikacji-elektronicznej-uke-wyjasnia-7257299?source=rss](https://tvn24.pl/biznes/z-kraju/orange-polska-wylaczy-siec-3g-wczesniej-zrobilo-to-t-mobile-polska-urzad-komunikacji-elektronicznej-uke-wyjasnia-7257299?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T09:44:18+00:00

<img alt="Kolejny gigant komórkowy szykuje zmiany dla klientów. UKE o terminie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4yze3n-odebrala-telefon-od-kobiety-podajacej-sie-za-pracownice-banku-zostala-oszukana-zdj-ilustracyjne-7197958/alternates/LANDSCAPE_1280" />
    Orange Polska planuje rozpocząć wyłączanie sieci 3G w drugiej połowie września 2023 roku - podał Urząd Komunikacji Elektronicznej (UKE). Zmiany już wcześniej wprowadziło T-Mobile Polska. Różowy operator z końcem kwietnia wyłączył sieć 3G na terenie całego kraju, z wyjątkiem niewielkich obszarów. "Zmiana starej technologii na nowszą pozwoli zaoferować użytkownikom większą jakość usług mobilnych, czyli potocznie mówiąc szybszy mobilny internet" - wyjaśnił Paweł Staroń z Departamentu Częstotliwości UKE.

## Na posterunek policji wbiegła zakrwawiona kobieta. Uciekała przed mężczyzną
 - [https://tvn24.pl/tvnwarszawa/najnowsze/zelechow-garwolin-gonil-ja-mezczyzna-zakrwawiona-kobieta-wbiegla-na-posterunek-7257276?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/zelechow-garwolin-gonil-ja-mezczyzna-zakrwawiona-kobieta-wbiegla-na-posterunek-7257276?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T09:41:43+00:00

<img alt="Na posterunek policji wbiegła zakrwawiona kobieta. Uciekała przed mężczyzną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xuuqe2-kobieta-schronila-sie-na-posterunku-zdjecie-ilustracyjne-7257338/alternates/LANDSCAPE_1280" />
    47-latka uciekała przed goniącym ją mężczyzną. Schroniła się w budynku posterunku policji. Krwawiła. Policjanci udzielili jej pomocy. Potem zajęli się sprawcą.

## Szczątki kobiety w trzech walizkach. Policja apeluje o pomoc
 - [https://tvn24.pl/swiat/usa-floryda-szczatki-kobiety-w-trzech-walizkach-policja-apeluje-o-pomoc-7257088?source=rss](https://tvn24.pl/swiat/usa-floryda-szczatki-kobiety-w-trzech-walizkach-policja-apeluje-o-pomoc-7257088?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T09:39:42+00:00

<img alt="Szczątki kobiety w trzech walizkach. Policja apeluje o pomoc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iiyb1y-policja-w-delray-beach-na-florydzie-7257179/alternates/LANDSCAPE_1280" />
    Policja informuje o szczątkach niezidentyfikowanej kobiety, znalezionych w trzech walizkach na terenie miasta Delray na Florydzie. Służby podzieliły się w mediach społecznościowych informacjami, które mogą pomóc w zidentyfikowaniu kobiety, oraz zaapelowały o pomoc "w uzyskaniu informacji w związku z zabójstwem".

## Są wyniki kontroli w sprawie zmowy cenowej na rynku malin
 - [https://tvn24.pl/biznes/najnowsze/ceny-malin-urzad-ochrony-konkurencji-i-konsumentow-prezentuje-wyniki-kontroli-w-sprawie-zmowy-cenowej-7257190?source=rss](https://tvn24.pl/biznes/najnowsze/ceny-malin-urzad-ochrony-konkurencji-i-konsumentow-prezentuje-wyniki-kontroli-w-sprawie-zmowy-cenowej-7257190?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T09:31:27+00:00

<img alt="Są wyniki kontroli w sprawie zmowy cenowej na rynku malin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ba31kn-mrozone-maliny-shutterstock_1436260940-7224526/alternates/LANDSCAPE_1280" />
    Urząd Ochrony Konkurencji i Konsumentów zaprezentował pierwsze wyniki kontroli w blisko 60 skupach oraz u 5 największych przetwórców malin. UOKiK sprawdził jak kształtowane są ceny tych owoców i co ma wpływ na ich wysokość. "Zebrany materiał wskazuje na brak podstaw do twierdzeń, że trudna sytuacja na rynku malin może być wynikiem zmowy cenowej skupów lub przetwórców" - stwierdzono.

## Turysta nie wrócił z wycieczki na Giewont. Odnaleziono jego ciało
 - [https://tvn24.pl/krakow/tatry-zakopane-turysta-nie-wrocil-z-wycieczki-na-giewont-odnaleziono-jego-cialo-7257317?source=rss](https://tvn24.pl/krakow/tatry-zakopane-turysta-nie-wrocil-z-wycieczki-na-giewont-odnaleziono-jego-cialo-7257317?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T09:12:20+00:00

<img alt="Turysta nie wrócił z wycieczki na Giewont. Odnaleziono jego ciało" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t6cm7o-ewakuacja-turystki-po-upadku-spod-giewontu-6772883/alternates/LANDSCAPE_1280" />
    Ratownicy Ochotniczego Tatrzańskiego Pogotowia Ratunkowego odnaleźli ciało, poszukiwanego od wczorajszego wieczora turysty, który nie wrócił z wycieczki na Giewont. Jego ciało leżało w jednym ze żlebów w dolinie Małej Laki.

## 17-latek chodził po placu i wymachiwał nożem. Policjant interweniował, został ranny
 - [https://tvn24.pl/wroclaw/wroclaw-17-latek-chodzil-po-placu-i-wymachiwal-nozem-policjant-interweniowal-zostal-ranny-7257049?source=rss](https://tvn24.pl/wroclaw/wroclaw-17-latek-chodzil-po-placu-i-wymachiwal-nozem-policjant-interweniowal-zostal-ranny-7257049?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T09:09:26+00:00

<img alt="17-latek chodził po placu i wymachiwał nożem. Policjant interweniował, został ranny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pt5cpr-niespelna-18-letni-mezczyzna-aresztowany-za-napasc-na-policjanta-7257199/alternates/LANDSCAPE_1280" />
    Policjant zauważył z daleka mężczyznę, który mógł mieć w ręce niebezpieczny przedmiot. Na placu Wolności we Wrocławiu było dużo ludzi, kończyło się święto policji. Funkcjonariusz podszedł do mężczyzny i został raniony w rękę nożem. Trafił do szpitala. Podejrzany o napaść ma 17 lat, został aresztowany.

## Z namiotów znikały maliny, truskawki i czereśnie. 38-latek z zarzutem kradzieży owoców
 - [https://tvn24.pl/krakow/rzeszow-zarzuty-dla-38-latka-ktory-ukradl-prawie-150-kg-owocow-7257227?source=rss](https://tvn24.pl/krakow/rzeszow-zarzuty-dla-38-latka-ktory-ukradl-prawie-150-kg-owocow-7257227?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T08:59:38+00:00

<img alt="Z namiotów znikały maliny, truskawki i czereśnie. 38-latek z zarzutem kradzieży owoców " src="https://tvn24.pl/najnowsze/cdn-zdjecie-r0qqvn-mezczyzna-ukradl-prawie-150-kilo-owocow-uslyszal-juz-zarzuty-7257265/alternates/LANDSCAPE_1280" />
    38-letni mieszkaniec Rzeszowa (woj. podkarpackie) usłyszał zarzut kradzieży prawie 150 kilogramów owoców. Mężczyzna systematycznie podjeżdżał samochodem pod namioty plantatora, z których zabierał koszyki i skrzynki z truskawkami, malinami i czereśniami.

## Aktor Julian Sands zginął w górach. Biuro szeryfa o wynikach sekcji zwłok
 - [https://tvn24.pl/swiat/usa-aktor-julian-sands-zginal-w-gorach-biuro-szeryfa-o-wynikach-sekcji-zwlok-7256966?source=rss](https://tvn24.pl/swiat/usa-aktor-julian-sands-zginal-w-gorach-biuro-szeryfa-o-wynikach-sekcji-zwlok-7256966?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T08:27:45+00:00

<img alt="Aktor Julian Sands zginął w górach. Biuro szeryfa o wynikach sekcji zwłok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8zrxy4-julian-sands-6769899/alternates/LANDSCAPE_1280" />
    Julian Sands zaginął 13 stycznia, jego szczątki zostały znalezione w górach Kalifornii 24 czerwca. Po miesiącu biuro szeryfa wydało oświadczenie o wynikach sekcji zwłok. Jak podaje CNN, przyczyna śmierci 65-letniego aktora nie została określona ze względu na stan ciała. Jak dodano, "jest to powszechne w tego typu przypadkach".

## Po zderzeniu jedno z aut przewróciło się na bok, pasażerka w szpitalu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-po-zderzeniu-jedno-z-auto-przewrocilo-sie-na-bok-pasazerka-w-szpitalu-7256989?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-po-zderzeniu-jedno-z-auto-przewrocilo-sie-na-bok-pasazerka-w-szpitalu-7256989?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T07:48:34+00:00

<img alt="Po zderzeniu jedno z aut przewróciło się na bok, pasażerka w szpitalu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1jawv3-wypadek-przy-zwirki-i-wigury-7257072/alternates/LANDSCAPE_1280" />
    We wtorek rano przy Żwirki i Wigury zderzyły się dwa auta osobowe. Jedno z nich wylądowało na boku. Jedna osoba trafiła do szpitala.

## 71-latek utonął podczas nocnego wędkowania
 - [https://tvn24.pl/pomorze/wislinka-71-latek-utonal-podczas-nocnego-wedkowania-7257030?source=rss](https://tvn24.pl/pomorze/wislinka-71-latek-utonal-podczas-nocnego-wedkowania-7257030?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T07:42:51+00:00

<img alt="71-latek utonął podczas nocnego wędkowania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xj6zxw-na-miejscu-pracuj-epolicja-zdjecie-ilustracyjne-7257027/alternates/LANDSCAPE_1280" />
    Ciało 71-letniego wędkarza zostało wyłowione w rejonie Sobieszewa z Martwej Wisły. Do jego utonięcia doszło, gdy w poniedziałek, razem z dwoma kolegami, wędkował na pomoście.

## Gwałtowna nawałnica nad Gorzowem Wielkopolskim. Zalane ulice, piwnice i garaże
 - [https://tvn24.pl/poznan/gorzow-wielkopolski-gwaltowna-nawalnica-nad-gorzowem-wielkopolskim-zalane-ulice-piwnice-i-garaze-7257054?source=rss](https://tvn24.pl/poznan/gorzow-wielkopolski-gwaltowna-nawalnica-nad-gorzowem-wielkopolskim-zalane-ulice-piwnice-i-garaze-7257054?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T07:25:17+00:00

<img alt="Gwałtowna nawałnica nad Gorzowem Wielkopolskim. Zalane ulice, piwnice i garaże" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ep3esf-zalane-ulice-w-gorzowie-wielkopolskim-7257065/alternates/LANDSCAPE_1280" />
    Kilkadziesiąt razy interweniowali strażacy po ulewie, która w poniedziałek wieczorem przeszła nad Gorzowem Wielkopolskim (woj. lubuskie). Woda zalała ulice, piwnice i garaże.

## Czołowe zderzenie samochodu z autobusem miejskim. Pięć osób poszkodowanych
 - [https://tvn24.pl/lodz/lodz-czolowe-zderzenie-samochodu-z-autobusem-miejskim-piec-osob-poszkodowanych-7257069?source=rss](https://tvn24.pl/lodz/lodz-czolowe-zderzenie-samochodu-z-autobusem-miejskim-piec-osob-poszkodowanych-7257069?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T07:15:42+00:00

<img alt="Czołowe zderzenie samochodu z autobusem miejskim. Pięć osób poszkodowanych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wexyez-czolowe-zderzenie-autobusu-miejskiego-z-samochodem-w-lodzi-piec-osob-poszkodowanych-7257048/alternates/LANDSCAPE_1280" />
    Pięć osób zostało poszkodowanych w czołowym zderzeniu samochodu osobowego z autobusem miejskim na ulicy Chocianowickiej w Łodzi.  - Dodatkowo w oba pojazdy, uderzyły jeszcze dwa samochody. W sumie poszkodowanych jest pięć osób, cztery z autobusu i kierowca samochodu osobowego - informuje straż pożarna

## Auto w rowie, kierowca nie żyje
 - [https://tvn24.pl/tvnwarszawa/najnowsze/karolew-grojec-wjechal-do-rowu-auto-na-boku-sa-utrudnienia-na-drodze-krajowej-numer-50-7257016?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/karolew-grojec-wjechal-do-rowu-auto-na-boku-sa-utrudnienia-na-drodze-krajowej-numer-50-7257016?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T06:58:34+00:00

<img alt="Auto w rowie, kierowca nie żyje" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4pf9e8-smiertelny-wypadek-na-dk50-7257044/alternates/LANDSCAPE_1280" />
    Kierowca volkswagena wjechał do rowu na krajowej 50, pod Grójcem. 78-latek kierujący pojazdem, pomimo udzielonej pomocy medycznej, zmarł. Są utrudnienia.

## KNF ostrzega banki przed nowym ryzykiem. "Liczymy na odpowiedzialną postawę"
 - [https://tvn24.pl/biznes/pieniadze/stopy-procentowe-w-polsce-komisja-nadzoru-finansowego-knf-ostrzega-banki-przed-nowym-ryzykiem-alior-bank-i-mbank-wprowadzily-zmiany-7256928?source=rss](https://tvn24.pl/biznes/pieniadze/stopy-procentowe-w-polsce-komisja-nadzoru-finansowego-knf-ostrzega-banki-przed-nowym-ryzykiem-alior-bank-i-mbank-wprowadzily-zmiany-7256928?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T06:50:55+00:00

<img alt="KNF ostrzega banki przed nowym ryzykiem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qln0qd-ludzie-ulica-przechodnie-tlum-7257014/alternates/LANDSCAPE_1280" />
    Urząd Komisji Nadzoru Finansowego (UKNF) ostrzega banki przed wzrostem ryzyka przedpłaty w umowach o kredyt hipoteczny z okresowo stałą stopą procentową. - Ryzyko przedpłaty rośnie, gdy spadają rynkowe stopy procentowe - wyjaśnił TVN24 Biznes Jacek Barszczewski, dyrektor Departamentu Komunikacji Społecznej UKNF. Urząd przygotował zasady, których wdrożenie ma ograniczyć ryzyko. Alior Bank i mBank już wprowadziły zmiany w swojej ofercie, zgodnie ze stanowiskiem UKNF.

## Kolejna fala upałów zaleje Grecję. Ekstremalny poziom zagrożenia pożarowego na Krecie
 - [https://tvn24.pl/tvnmeteo/swiat/kolejna-fala-upalow-zaleje-grecje-ekstremalny-poziom-zagrozenia-pozarowego-na-krecie-7256915?source=rss](https://tvn24.pl/tvnmeteo/swiat/kolejna-fala-upalow-zaleje-grecje-ekstremalny-poziom-zagrozenia-pozarowego-na-krecie-7256915?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T06:00:02+00:00

<img alt="Kolejna fala upałów zaleje Grecję. Ekstremalny poziom zagrożenia pożarowego na Krecie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-emrczl-pozary-na-rodos-7256925/alternates/LANDSCAPE_1280" />
    Jest źle, ale może być jeszcze gorzej. Do Grecji zmierza kolejna w tym roku fala upałów. Niewykluczone, że w wielu miejscach na wschodzie kraju temperatura wyniesie 45 stopni Celsjusza. Wysoka temperatura potęguje ryzyko wybuchu pożarów. Na Krecie, której udało się na razie przed nimi uchronić, wszedł w życie piąty - ekstremalny poziom zagrożenia pożarowego.

## Pożary w Grecji. Ambasada RP uruchamia nowe linie telefoniczne
 - [https://tvn24.pl/tvnmeteo/swiat/pozary-w-grecji-ambasada-rp-uruchamia-dodatkowe-linie-telefoniczne-7256915?source=rss](https://tvn24.pl/tvnmeteo/swiat/pozary-w-grecji-ambasada-rp-uruchamia-dodatkowe-linie-telefoniczne-7256915?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T06:00:02+00:00

<img alt="Pożary w Grecji. Ambasada RP uruchamia nowe linie telefoniczne" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9s1pta-pozary-w-grecji-7257441/alternates/LANDSCAPE_1280" />
    Pożary w Grecji nie ustępują. Polska ambasada w Atenach uruchomiła nowe linie telefoniczne dla obywateli, chcących uzyskać informacje o zagrożeniu pożarowym. Do kraju nadciąga kolejna fala upałów, co dodatkowo może zwiększyć niebezpieczeństwo. - Jesteśmy w stanie wojny - mówił premier Grecji Kyriakos Micotakis.

## Niemal pół miliona ludzi wyjechało z Turcji
 - [https://tvn24.pl/biznes/ze-swiata/turcja-w-2022-roku-odnotowano-wzrost-emigracji-o-62-proc-7256899?source=rss](https://tvn24.pl/biznes/ze-swiata/turcja-w-2022-roku-odnotowano-wzrost-emigracji-o-62-proc-7256899?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T05:16:50+00:00

<img alt="Niemal pół miliona ludzi wyjechało z Turcji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5yp0bk-shutterstock_1918322669-7256897/alternates/LANDSCAPE_1280" />
    W 2022 roku odnotowano wzrost emigracji z Turcji o 62 procent w porównaniu z rokiem poprzednim. Rosjanie byli w ubiegłym roku najliczniejszym narodem imigrującym do Turcji - wynika z opublikowanych w poniedziałek danych Tureckiego Instytutu Statystycznego (TUIK).

## Jest decyzja w sprawie znanego browaru w Polsce. "Zakończenie produkcji zostało przesunięte"
 - [https://tvn24.pl/biznes/z-kraju/browar-lezajsk-dalej-dziala-grupa-zywiec-wyjasnia-7256892?source=rss](https://tvn24.pl/biznes/z-kraju/browar-lezajsk-dalej-dziala-grupa-zywiec-wyjasnia-7256892?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T05:07:23+00:00

<img alt="Jest decyzja w sprawie znanego browaru w Polsce. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m8wakn-piwo-5711866/alternates/LANDSCAPE_1280" />
    Grupa Żywiec ogłosiła plan zamknięcia browaru w Leżajsku w województwie podkarpackim. Miało to nastąpić w czerwcu, ale jak się okazuje browar nadal działa. Otrzymaliśmy odpowiedź w tej sprawie od Grupy Żywiec.

## Kłótnia podczas imprezy. 25-latek ugodził nożem w plecy kolegę, trafił do aresztu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/gmina-miastkow-koscielny-klotnia-podczas-imprezy-ugodzil-nozem-w-plecy-kolege-trafil-do-aresztu-7256896?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/gmina-miastkow-koscielny-klotnia-podczas-imprezy-ugodzil-nozem-w-plecy-kolege-trafil-do-aresztu-7256896?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-07-25T05:00:57+00:00

<img alt="Kłótnia podczas imprezy. 25-latek ugodził nożem w plecy kolegę, trafił do aresztu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-awwz5c-policja-zatrzymala-mezczyzne-zdjecie-ilustracyjne-7194206/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali 25-latka, który jest podejrzany o usiłowanie zabójstwa. Jak podają funkcjonariusze, miał ugodzić nożem w plecy 33-latka, z którym pił alkohol. Mężczyzna trafił do aresztu.

