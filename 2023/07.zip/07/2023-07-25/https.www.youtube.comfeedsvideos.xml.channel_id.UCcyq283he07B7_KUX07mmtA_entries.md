# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## Why Kamebishi 20-Year-Aged Soy Sauce Is So Expensive | So Expensive | Insider Business
 - [https://www.youtube.com/watch?v=57yJA0_XU_g](https://www.youtube.com/watch?v=57yJA0_XU_g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-07-25T23:29:59+00:00

Kamebishi's 20-year-aged soy sauce is the most expensive soy sauce in the world, sometimes selling for $125 for less than 4 tablespoons. The soy sauce has been made using the same family recipe since 1753 and follows the traditional mushiro koji method, in which each step takes years to complete. For comparison, most popular soy sauces can cost less than a bottle of water, and other aged artisanal soy sauces generally cost around $40. In 2001, Kaori Okada, the 18th-generation owner of Kamebishi, left her career in the travel industry to save her family's struggling company using a combination of traditional methods and new innovations. Here's why Kamebishi's 20-year-aged soy sauce is so expensive.

Why Grade A Maple Syrup Is So Expensive | So Expensive Food | Insider Business
https://www.youtube.com/watch?v=rCzx_MTtb_U
Why These $2,000 Japanese Hair Shears Are So Expensive | So Expensive | Insider Business
https://www.youtube.com/watch?v=vZaBeKdc4cs
Why Ayam Cemani Chickens Are So Expensive | So Expensive | Insider Business
https://www.youtube.com/watch?v=OsDuXBMOdNs

0:00 Intro 
1:14 Bean steaming 
3:29 Koji preparation
4:33 Mushiro koji method
6:25 Moromi aging
9:15 Pressing
10:40 Future of Kamebishi 

------------------------------------------------------

#soysauce #soexpensive #insiderbusiness 

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

Why Kamebishi 20-Year-Aged Soy Sauce Is So Expensive | So Expensive | Insider Business

## The Metaverse Explained – And What Comes Next | Insider Business
 - [https://www.youtube.com/watch?v=jFUVZDPrB7U](https://www.youtube.com/watch?v=jFUVZDPrB7U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-07-25T20:39:27+00:00

By now, you've probably heard of the "metaverse." But despite all the hype, the metaverse might still be a little confusing. So, what is the metaverse? And what type of impact could it have on our everyday lives? Insider spoke with Journey founder Cathy Hackl and Lego Group CMO Julia Goldin for their insights on the metaverse.

------------------------------------------------------

#metaverse #ai #insiderbusiness 

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

The Metaverse Explained – And What Comes Next | Insider Business

## Here's what happens to cruise ships after they are retired. 🛳️  #cruise #recycle #ship
 - [https://www.youtube.com/watch?v=QN4aTvaQVjE](https://www.youtube.com/watch?v=QN4aTvaQVjE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-07-25T19:53:04+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

## How lace related jobs have changed in France 🇫🇷 #lace #France #jobs #fashion
 - [https://www.youtube.com/watch?v=5OLudADwNZM](https://www.youtube.com/watch?v=5OLudADwNZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-07-25T17:38:27+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

