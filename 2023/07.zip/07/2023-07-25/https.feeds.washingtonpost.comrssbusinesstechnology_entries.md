# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## AI leaders warn Congress AI could be used to create bioweapons
 - [https://www.washingtonpost.com/technology/2023/07/25/ai-bengio-anthropic-senate-hearing/](https://www.washingtonpost.com/technology/2023/07/25/ai-bengio-anthropic-senate-hearing/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-07-25T21:42:07+00:00

Two AI researchers and the CEO of AI startup Anthropic testified about the long-term risks of AI and said Congress needs to institute rules to control it.

## NASA funds moon projects to help missions to ‘live off the land’
 - [https://www.washingtonpost.com/technology/2023/07/25/nasa-moon-artemis/](https://www.washingtonpost.com/technology/2023/07/25/nasa-moon-artemis/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-07-25T20:15:03+00:00

The space agency awarded contracts to develop technologies that would build habitats and power sources on the lunar surface as part of its Artemis program.

## Tired of proving you’re not a robot? Say goodbye to Captcha boxes.
 - [https://www.washingtonpost.com/technology/2023/07/25/captchas-hate-privacy-pass/](https://www.washingtonpost.com/technology/2023/07/25/captchas-hate-privacy-pass/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-07-25T16:30:00+00:00

Tired of diabolical puzzles to prove you're a human? Technology may finally kill the hated Captcha.

