# Source:Screen Junkies, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A, language:en-US

## Honest Trailers | Transformers: Rise of the Beasts
 - [https://www.youtube.com/watch?v=RzMTZ1vd2cE](https://www.youtube.com/watch?v=RzMTZ1vd2cE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A
 - date published: 2023-07-25T17:00:14+00:00

►►Watch the Honest Trailers Commentary with the Writers!► https://youtube.com/live/1UU62yERzS8

►►Subscribe to ScreenJunkies!► https://fandom.link/SJSubscribe

Honest Trailers | Transformers: Rise of the Beasts
Voice Narration: Jon Bailey aka Epic Voice Guy
Title Design: Robert Holtby
Written by: Spencer Gilbert, Danielle Radford, Lon Harris
Produced by: Spencer Gilbert
Edited by: Kevin Williamsen
Post-Production Manager: Emin Bassavand
Content Manager: Mikołaj Kossakowski
Post-Production Specialist: Rebecca Castaneda
Director of Video Production: Max Dionne

#honesttrailers #transformers

