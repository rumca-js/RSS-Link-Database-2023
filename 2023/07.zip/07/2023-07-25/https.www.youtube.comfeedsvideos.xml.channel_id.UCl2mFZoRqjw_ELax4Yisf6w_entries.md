# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Texas death star bill; my thoughts as a businessman & new Texan
 - [https://www.youtube.com/watch?v=MhyEFTwZPUo](https://www.youtube.com/watch?v=MhyEFTwZPUo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-07-25T16:40:35+00:00

https://www.expressnews.com/news/article/hb-2127-death-star-bill-san-antonio-files-lawsuit-18257218.php

