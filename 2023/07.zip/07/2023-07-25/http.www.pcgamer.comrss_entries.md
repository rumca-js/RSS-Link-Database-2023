# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Our favorite spy-themed extraction shooter is having a free weekend to launch its second season
 - [https://www.pcgamer.com/our-favorite-spy-themed-extraction-shooter-is-having-a-free-weekend-to-launch-its-second-season](https://www.pcgamer.com/our-favorite-spy-themed-extraction-shooter-is-having-a-free-weekend-to-launch-its-second-season)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T22:48:15+00:00

Deceive Inc will be free to play from July 27-30, and it's on sale too.

## Starfield persuasion guide: Talking your way out of a space jam
 - [https://www.pcgamer.com/starfield-dialogue-persuasion-guide](https://www.pcgamer.com/starfield-dialogue-persuasion-guide)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T22:39:42+00:00

Everything we know so far about Starfield's dialogue system, persuasion, speech challenges, and how they work.

## The protagonist of this ultra-bleak horror game fights with sadness and gets upgrades by having an avoidant personality
 - [https://www.pcgamer.com/unholy-game-impressions](https://www.pcgamer.com/unholy-game-impressions)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T22:11:01+00:00

Unholy is as sullen as it is janky.

## A year and a half later and the Steam Deck's trackpads are finally being copied in a new handheld PC
 - [https://www.pcgamer.com/a-year-and-a-half-later-and-the-steam-decks-trackpads-are-finally-being-copied-in-a-new-handheld-pc](https://www.pcgamer.com/a-year-and-a-half-later-and-the-steam-decks-trackpads-are-finally-being-copied-in-a-new-handheld-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T21:34:58+00:00

The Ayaneo Kun is the big boi handheld gaming PC, with a chonky battery, and an 8.4-inch 1600p screen for "semi-mobile scenarios."

## Sorry, Doom dreamers: John Carmack wishes John Romero 'the best' but they're not working on a secret new project together
 - [https://www.pcgamer.com/sorry-doom-dreamers-john-carmack-wishes-john-romero-the-best-but-theyre-not-working-on-a-secret-new-project-together](https://www.pcgamer.com/sorry-doom-dreamers-john-carmack-wishes-john-romero-the-best-but-theyre-not-working-on-a-secret-new-project-together)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T21:17:53+00:00

Carmack said Romero's new autobiography reminds him of the glory days when they were "the 3D game hackers."

## ESRB says proposed age verification scan is misunderstood: It doesn't 'confirm the identity of users' and is unrelated to videogame age ratings
 - [https://www.pcgamer.com/esrb-says-proposed-age-verification-scan-is-misunderstood-it-doesnt-confirm-the-identity-of-users-and-is-unrelated-to-videogame-age-ratings](https://www.pcgamer.com/esrb-says-proposed-age-verification-scan-is-misunderstood-it-doesnt-confirm-the-identity-of-users-and-is-unrelated-to-videogame-age-ratings)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T20:26:40+00:00

The ESRB's proposed Privacy-Protective Facial Age Estimation system came to light yesterday through an FTC filing.

## Dave the Diver was inspired by a real oceanside seafood restaurant… and Metal Gear Solid
 - [https://www.pcgamer.com/dave-the-diver-was-inspired-by-a-real-oceanside-seafood-restaurant-and-metal-gear-solid](https://www.pcgamer.com/dave-the-diver-was-inspired-by-a-real-oceanside-seafood-restaurant-and-metal-gear-solid)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T19:58:05+00:00

Game Director Jaeho Hwang tells us what games influenced Dave the Diver, which include Mystery Dungeon and Yakuza.

## The best thing about Diablo 4 is that it has stopped me from playing Destiny 2
 - [https://www.pcgamer.com/the-best-thing-about-diablo-4-is-that-it-has-stopped-me-from-playing-destiny-2](https://www.pcgamer.com/the-best-thing-about-diablo-4-is-that-it-has-stopped-me-from-playing-destiny-2)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T19:50:40+00:00

The only thing that can break the spell of one live service looter is another live service looter.

## Every Baldur's Gate 3 romance option: who you can pursue
 - [https://www.pcgamer.com/baldurs-gate-3-romance-options-guide](https://www.pcgamer.com/baldurs-gate-3-romance-options-guide)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T17:53:22+00:00

Unlock a romance with any of the main origin characters and some of your other party members, too.

## Armored Core 6 has a 120 fps option, a FromSoftware first on PC
 - [https://www.pcgamer.com/armored-core-6-has-a-120-fps-option-a-fromsoftware-first-on-pc](https://www.pcgamer.com/armored-core-6-has-a-120-fps-option-a-fromsoftware-first-on-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T17:18:21+00:00

Glorious mechs, glorious frames.

## This fan-made UE5 remake of The Simpsons: Hit & Run looks incredible, and we'll never, ever get to play it
 - [https://www.pcgamer.com/this-fan-made-ue5-remake-of-the-simpsons-hit-and-run-looks-incredible-and-well-never-ever-get-to-play-it](https://www.pcgamer.com/this-fan-made-ue5-remake-of-the-simpsons-hit-and-run-looks-incredible-and-well-never-ever-get-to-play-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T16:30:29+00:00

D'oh!

## FromSoftware made Elden Ring and Armored Core 6 with a staff of just 300 developers
 - [https://www.pcgamer.com/fromsoftware-made-elden-ring-and-armored-core-6-with-a-staff-of-just-300-developers](https://www.pcgamer.com/fromsoftware-made-elden-ring-and-armored-core-6-with-a-staff-of-just-300-developers)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T16:30:10+00:00

The maker of last year's biggest game remains modestly sized by triple-A standards.

## Drop Lord of the Rings Dwarvish ENTR
 - [https://www.pcgamer.com/drop-lord-of-the-rings-dwarvish-entr](https://www.pcgamer.com/drop-lord-of-the-rings-dwarvish-entr)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T16:26:58+00:00

Sturdy and gorgeously decorated, but a pretty basic feature set under all that finery.

## Starfield's surprise anime series features battling mechs and fans are hoping they'll be playable in the game
 - [https://www.pcgamer.com/starfields-surprise-anime-series-features-battling-mechs-and-fans-are-hoping-theyll-be-playable-in-the-game](https://www.pcgamer.com/starfields-surprise-anime-series-features-battling-mechs-and-fans-are-hoping-theyll-be-playable-in-the-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T16:23:48+00:00

The Settled Systems – A Starfield Animated Anthology is a series of three animated shorts that sets the mood for Bethesda's upcoming RPG.

## The Banished Vault trapped me in a logistics nightmare and made me hate space, but I still really want to like it
 - [https://www.pcgamer.com/the-banished-vault-trapped-me-in-a-logistics-nightmare-and-made-me-hate-space-but-i-still-really-want-to-like-it](https://www.pcgamer.com/the-banished-vault-trapped-me-in-a-logistics-nightmare-and-made-me-hate-space-but-i-still-really-want-to-like-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T16:00:54+00:00

Is this a turn-based space survival game or maths homework?

## How to complete A Prayer for Salvation in Diablo 4
 - [https://www.pcgamer.com/diablo-4-prayer-for-salvation-item-locations](https://www.pcgamer.com/diablo-4-prayer-for-salvation-item-locations)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T15:56:31+00:00

Help Cormond collect three mysterious objects from across Hawezar.

## Charisma reigns supreme in D&D—the golden child Paladin might just be the most popular class in Baldur's Gate 3
 - [https://www.pcgamer.com/charisma-reigns-supreme-in-danddthe-golden-child-paladin-might-just-be-the-most-popular-class-in-baldurs-gate-3](https://www.pcgamer.com/charisma-reigns-supreme-in-danddthe-golden-child-paladin-might-just-be-the-most-popular-class-in-baldurs-gate-3)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T15:41:37+00:00

A fan poll saw all four charisma-based classes hitting the top of the charts.

## Armored Core 6 is even more like classic Armored Core than I thought
 - [https://www.pcgamer.com/armored-core-6-is-even-more-like-classic-armored-core-than-i-thought](https://www.pcgamer.com/armored-core-6-is-even-more-like-classic-armored-core-than-i-thought)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T15:01:37+00:00

Short missions, tons of customization and a lock-on system that straddles the old and the new.

## Armored Core 6 will have 1v1 duels and 3v3 multiplayer that's like a 'mecha festival with metal flying everywhere'
 - [https://www.pcgamer.com/armored-core-6-pvp-multiplayer-1v1-3v3-details](https://www.pcgamer.com/armored-core-6-pvp-multiplayer-1v1-3v3-details)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T15:00:15+00:00

Despite focusing on singleplayer, FromSoftware still gave Armored Core PvP a bit of love.

## Armored Core 6 isn't Robot Souls, or Elden Mech, and now I'm fine with that
 - [https://www.pcgamer.com/armored-core-6-isnt-robot-souls-or-elden-mech-and-now-im-fine-with-that](https://www.pcgamer.com/armored-core-6-isnt-robot-souls-or-elden-mech-and-now-im-fine-with-that)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T15:00:01+00:00

FromSoftware's imminent mech fighter is its own unique, glorious thing.

## Where to find the laser crystal in The Expanse
 - [https://www.pcgamer.com/the-expanse-laser-crystal-location](https://www.pcgamer.com/the-expanse-laser-crystal-location)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T14:35:09+00:00

Surely this will come in handy in later episodes.

## Why does it seem like PC ports are getting worse?
 - [https://www.pcgamer.com/why-pc-ports-seem-to-be-getting-worse](https://www.pcgamer.com/why-pc-ports-seem-to-be-getting-worse)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T14:34:48+00:00

Developers tell us it isn't a PC port problem, it's a videogame development problem. Here's why b0rked releases keep happening.

## Call of Duty devs get cheeky after Modern Warfare 3 leaks via an energy drink promotion
 - [https://www.pcgamer.com/call-of-duty-devs-get-cheeky-after-modern-warfare-3-leaks-via-an-energy-drink-promotion](https://www.pcgamer.com/call-of-duty-devs-get-cheeky-after-modern-warfare-3-leaks-via-an-energy-drink-promotion)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T14:20:25+00:00

War makes Monsters of us all.

## The Expanse proves that Telltale is back, baby, and recapturing some of that Walking Dead magic
 - [https://www.pcgamer.com/the-expanse-proves-that-telltale-is-back-baby-and-recapturing-some-of-that-walking-dead-magic](https://www.pcgamer.com/the-expanse-proves-that-telltale-is-back-baby-and-recapturing-some-of-that-walking-dead-magic)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T14:00:00+00:00

It's like Telltale never went away.

## Nerfs aside, one of Diablo 4's strongest Necro builds is even better this season
 - [https://www.pcgamer.com/nerfs-aside-one-of-diablo-4s-strongest-necro-builds-is-even-better-this-season](https://www.pcgamer.com/nerfs-aside-one-of-diablo-4s-strongest-necro-builds-is-even-better-this-season)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T12:37:47+00:00

Bid farewell to Bone Spear and say hello to Infinimist.

## Yoshi-P speaks out on Final Fantasy 16 toxicity: 'There's a lot of people who just yell at you'
 - [https://www.pcgamer.com/yoshi-p-speaks-out-on-final-fantasy-16-toxicity-theres-a-lot-of-people-who-just-yell-at-you](https://www.pcgamer.com/yoshi-p-speaks-out-on-final-fantasy-16-toxicity-theres-a-lot-of-people-who-just-yell-at-you)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T11:59:51+00:00

A recent documentary went into the Final Fantasy 16 producer's life, work, and the difficulty in facing overly personal criticism.

## AMD's Zen 2 chips have a security bug that's getting patched between now and 2024
 - [https://www.pcgamer.com/amds-zen-2-chips-have-a-security-bug-thats-getting-patched-between-now-and-2024](https://www.pcgamer.com/amds-zen-2-chips-have-a-security-bug-thats-getting-patched-between-now-and-2024)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T11:56:02+00:00

Zenbleed shouldn't be left exposed for long, so you best keep an eye out for an upcoming AGESA fix for affected chips.

## Remnant 2 review
 - [https://www.pcgamer.com/remnant-2-review](https://www.pcgamer.com/remnant-2-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T11:26:07+00:00

This looter shooter sequel makes subverting expectations a habit.

## Cableless GPUs are a new step in graphics card evolution
 - [https://www.pcgamer.com/cableless-gpus-are-a-new-step-in-graphics-card-evolution](https://www.pcgamer.com/cableless-gpus-are-a-new-step-in-graphics-card-evolution)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T11:17:23+00:00

Asus' innovative cable-free graphics cards going into mass production before the end of the year.

## Your Diablo 4 stash is tiny because a bigger one would fry your PC: 'This isn't a storage concern, it's a performance concern'
 - [https://www.pcgamer.com/your-diablo-4-stash-is-tiny-because-a-bigger-one-would-fry-your-pc-this-isnt-a-storage-concern-its-a-performance-concern](https://www.pcgamer.com/your-diablo-4-stash-is-tiny-because-a-bigger-one-would-fry-your-pc-this-isnt-a-storage-concern-its-a-performance-concern)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T11:03:10+00:00

Unless you have a PC capable of loading in other players' infinite stashes, I guess.

## After 200 hours and 44 pages of speculation, one Starfield fan thinks they've found all there is to know about the game's abilities
 - [https://www.pcgamer.com/after-200-hours-and-44-pages-of-speculation-one-starfield-fan-thinks-theyve-found-all-there-is-to-know-about-the-games-abilities](https://www.pcgamer.com/after-200-hours-and-44-pages-of-speculation-one-starfield-fan-thinks-theyve-found-all-there-is-to-know-about-the-games-abilities)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T10:53:28+00:00

When Todd Howard is silent, the detectives come out to play.

## You can vote to get this massive song made with Counter Strike gunshots into CS:GO
 - [https://www.pcgamer.com/you-can-vote-to-get-this-massive-song-made-with-counter-strike-gunshots-into-csgo](https://www.pcgamer.com/you-can-vote-to-get-this-massive-song-made-with-counter-strike-gunshots-into-csgo)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T10:04:07+00:00

Made by music maker Vengent with little more than in-game samples.

## AMD's RX 7900 GRE is coming to China, but what's under the hood?
 - [https://www.pcgamer.com/amds-rx-7900-gre-is-coming-to-china-but-whats-under-the-hood](https://www.pcgamer.com/amds-rx-7900-gre-is-coming-to-china-but-whats-under-the-hood)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T09:51:12+00:00

The Golden Rabbit Edition is coming.

## Today's Wordle hint and answer #766: Tuesday, July 25
 - [https://www.pcgamer.com/wordle-answer-today-hint-766-july-25](https://www.pcgamer.com/wordle-answer-today-hint-766-july-25)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T03:10:43+00:00

Trouble solving today's Wordle? Here's the help you need.

## AMD 3D V-Cache CPUs are coming to laptops, and they'll contend for the gaming crown
 - [https://www.pcgamer.com/amd-3d-v-cache-cpus-are-coming-to-laptops-and-theyll-contend-for-the-gaming-crown](https://www.pcgamer.com/amd-3d-v-cache-cpus-are-coming-to-laptops-and-theyll-contend-for-the-gaming-crown)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T01:43:37+00:00

It's about time!

## One of Dave The Diver's boss monsters may return in a future update
 - [https://www.pcgamer.com/one-of-dave-the-divers-boss-monsters-may-return-in-a-future-update](https://www.pcgamer.com/one-of-dave-the-divers-boss-monsters-may-return-in-a-future-update)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-07-25T00:04:56+00:00

One of the undersea bosses you defeat slips away, but it may someday return to fight you again.

