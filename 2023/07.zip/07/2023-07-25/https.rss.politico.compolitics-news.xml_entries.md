# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## GOP wrestles with question of possible Trump indictment over Jan. 6
 - [https://www.politico.com/video/2023/07/25/gop-wrestles-with-question-of-possible-trump-indictment-over-jan-6-1011981](https://www.politico.com/video/2023/07/25/gop-wrestles-with-question-of-possible-trump-indictment-over-jan-6-1011981)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-07-25T12:33:57+00:00



