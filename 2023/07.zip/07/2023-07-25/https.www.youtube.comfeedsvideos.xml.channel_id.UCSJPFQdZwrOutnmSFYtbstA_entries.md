# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Oppenheimer - Explosive Historical Drama
 - [https://www.youtube.com/watch?v=9O2GXfiiNw4](https://www.youtube.com/watch?v=9O2GXfiiNw4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-07-25T17:27:35+00:00

Christopher Nolan's historical epic about the man behind the Manhattan Project, starring Emily Blunt, Cillian Murphy, Matt Damon, Robert Downey Jr, Florence Pugh and Kenneth Branagh is finally here. But does it fizzle out, or go off with a bang?

