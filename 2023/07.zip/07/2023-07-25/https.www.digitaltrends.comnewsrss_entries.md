# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## AMD might be about to launch the most powerful laptop of 2023
 - [https://www.digitaltrends.com/computing/amd-is-bringing-3d-v-cache-to-laptops/](https://www.digitaltrends.com/computing/amd-is-bringing-3d-v-cache-to-laptops/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2023-07-25T12:47:17.150713+00:00

AMD's 3D V-Cache tech seems to be on its way to laptops. Will it be a viable option for high-end devices?

## These Apple sneakers are rare and pricey, and very 1990s
 - [https://www.digitaltrends.com/news/these-apple-sneakers-are-rare-and-pricey-and-very-1990s/](https://www.digitaltrends.com/news/these-apple-sneakers-are-rare-and-pricey-and-very-1990s/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2023-07-25T12:47:17.148424+00:00

If you’re all-in on the Apple brand and walk the streets with an iPhone, Apple Watch, and AirPods, you can now finish the look with a pair of Apple sneakers.

