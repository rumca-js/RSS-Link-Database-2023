# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## “Not My Concern!” Tucker vs Pence On Ukraine War!!
 - [https://www.youtube.com/watch?v=RaiAcwm8BQU](https://www.youtube.com/watch?v=RaiAcwm8BQU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-07-25T23:00:21+00:00



## CNN Made A BIG MISTAKE Airing THIS!
 - [https://www.youtube.com/watch?v=_-JzZu76O-E](https://www.youtube.com/watch?v=_-JzZu76O-E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-07-25T17:00:31+00:00

https://www.bambee.com and type in BRAND under PODCAST when you sign up

As CNN anchor Anderson Cooper lectures Green Party presidential candidate Cornel West over America’s role in the Ukraine war, is West right that America is acting like an empire on the world stage? And what interest would CNN have in opposing that narrative? #CNN #politics #war 
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

## SHOCKING UFO Sightings SURGE! Pentagon Denies Truth - MUST WATCH! - Stay Free #175 PREVIEW
 - [https://www.youtube.com/watch?v=iX5cAP8-aPo](https://www.youtube.com/watch?v=iX5cAP8-aPo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-07-25T14:13:20+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me live and exclusively over on RUMBLE: 
https://bit.ly/stayfree-175-ufo-special

TODAY - we bring you our special on the recent surge of UFO sightings with extraterrestrial experts and journalists, Jeremy Corbell, Ross Coulthard & Saagar Enjeti. We unpack whether the Pentagon is hiding the truth, the world of alien technology and the global race for military dominance, and from the infamous Roswell incident to the most recent UFO encounters, what is the future of humanity!? Be prepared to have your beliefs challenged!

--------------------------------------------------------------------------------------------------------------------------

FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand
5:00PM BST | 12:00 PM EDT | 9:00AM PDT

Join The STAY FREE Community: https://russellbrand.locals.com/

NEW MERCH! https://stuff.russellbrand.com/

