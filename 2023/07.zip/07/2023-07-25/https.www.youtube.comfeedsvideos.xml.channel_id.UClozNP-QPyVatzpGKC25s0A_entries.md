# Source:Brad Colbow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A, language:en-US

## Procreate’s Little Secret is Still Surprising People
 - [https://www.youtube.com/watch?v=xPjNzG4DgoM](https://www.youtube.com/watch?v=xPjNzG4DgoM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A
 - date published: 2023-07-25T21:31:04+00:00



