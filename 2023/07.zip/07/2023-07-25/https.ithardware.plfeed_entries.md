# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Forspoken pozbawiony zabezpieczenia Denuvo
 - [https://ithardware.pl/aktualnosci/forspoken_pozbawiony_zabezpieczenia_denuvo-28485.html](https://ithardware.pl/aktualnosci/forspoken_pozbawiony_zabezpieczenia_denuvo-28485.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T21:13:27+00:00

Denuvo zyskało niesławę po tym jak zostało oskarżone o obniżanie wydajności osłanianych gier. Dodatkowo DRM wyr&oacute;żniał się niezbyt dobrym poziomem ochrony, bowiem produkcje padały nawet w tydzień od premiery. Teraz z tego narzędzia...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/forspoken_pozbawiony_zabezpieczenia_denuvo-28485.html">https://ithardware.pl/aktualnosci/forspoken_pozbawiony_zabezpieczenia_denuvo-28485.html</a></p>

## O takich zarobkach możemy tylko pomarzyć. CEO Microsoftu otrzymał fortunę
 - [https://ithardware.pl/aktualnosci/o_takich_zarobkach_mozemy_tylko_pomarzyc_ceo_microsoftu_otrzymal_fortune-28431.html](https://ithardware.pl/aktualnosci/o_takich_zarobkach_mozemy_tylko_pomarzyc_ceo_microsoftu_otrzymal_fortune-28431.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T19:48:00+00:00

<img src="https://ithardware.pl/artykuly/min/28431_1.jpg" />            Dyrektor generalny Microsoftu, Satya Nadella, może obecnie cieszyć się nie tylko z sukcesu swojej firmy, ale także z pokaźnych korzyści finansowych. Jego całkowite wynagrodzenie przekroczyło imponującą sumę 1 miliarda dolar&oacute;w, a to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/o_takich_zarobkach_mozemy_tylko_pomarzyc_ceo_microsoftu_otrzymal_fortune-28431.html">https://ithardware.pl/aktualnosci/o_takich_zarobkach_mozemy_tylko_pomarzyc_ceo_microsoftu_otrzymal_fortune-28431.html</a></p>

## Klienci uciekają od Oracle. Takie podwyżki cen Java to szok...
 - [https://ithardware.pl/aktualnosci/klienci_uciekaja_od_oracle_takie_podwyzki_cen_java_to_szok-28468.html](https://ithardware.pl/aktualnosci/klienci_uciekaja_od_oracle_takie_podwyzki_cen_java_to_szok-28468.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T19:39:20+00:00

<img src="https://ithardware.pl/artykuly/min/28468_1.jpg" />            Według analizy przeprowadzonej przez firmę Gartner, większość organizacji, kt&oacute;re adaptują się do nowych warunk&oacute;w licencjonowania oprogramowania Java ze strony firmy Oracle, spodziewa się znacznego wzrostu koszt&oacute;w. Prognozy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/klienci_uciekaja_od_oracle_takie_podwyzki_cen_java_to_szok-28468.html">https://ithardware.pl/aktualnosci/klienci_uciekaja_od_oracle_takie_podwyzki_cen_java_to_szok-28468.html</a></p>

## Spider-Man 2 może zostać zakazany na Bliskim Wschodzie
 - [https://ithardware.pl/aktualnosci/spider_man_2_moze_zostac_zakazany_na_bliskim_wschodzie-28484.html](https://ithardware.pl/aktualnosci/spider_man_2_moze_zostac_zakazany_na_bliskim_wschodzie-28484.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T19:26:20+00:00

<img src="https://ithardware.pl/artykuly/min/28484_1.jpg" />            Na grę Marvel's Spider-Man 2 czeka z pewnością wielu graczy. Jednak nie wszystkim będzie dane zagrać w nową produkcję, a na liście kraj&oacute;w są Zjednoczone Emiraty Arabskie, kt&oacute;re podobno zablokowały wydanie tytułu ze względu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/spider_man_2_moze_zostac_zakazany_na_bliskim_wschodzie-28484.html">https://ithardware.pl/aktualnosci/spider_man_2_moze_zostac_zakazany_na_bliskim_wschodzie-28484.html</a></p>

## Intel ogłosił Advanced Performance Extensions. Zaawansowane instrukcje także dla E-Core
 - [https://ithardware.pl/aktualnosci/intel_oglosil_advanced_performance_extensions_zaawansowane_instrukcje_takze_dla_e_core-28482.html](https://ithardware.pl/aktualnosci/intel_oglosil_advanced_performance_extensions_zaawansowane_instrukcje_takze_dla_e_core-28482.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T13:46:20+00:00

<img src="https://ithardware.pl/artykuly/min/28482_1.jpg" />            Intel przedstawił Advanced Performance Extensions (APX).&nbsp;Zaletami kodu APX mają być kr&oacute;tszy czas wykonywania oraz mniejsze zużycie mocy dynamicznej.&nbsp;Intel planuje dodać zaawansowane instrukcje także dla energooszczędnych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_oglosil_advanced_performance_extensions_zaawansowane_instrukcje_takze_dla_e_core-28482.html">https://ithardware.pl/aktualnosci/intel_oglosil_advanced_performance_extensions_zaawansowane_instrukcje_takze_dla_e_core-28482.html</a></p>

## MSI G272QPF - test szybkiego monitora Rapid IPS QHD w dobrej cenie
 - [https://ithardware.pl/testyirecenzje/msi_g272qpf-28461.html](https://ithardware.pl/testyirecenzje/msi_g272qpf-28461.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T12:34:10+00:00

<img src="https://ithardware.pl/artykuly/min/28461_1.jpg" />            MSI G272QPF - test szybkiego monitora Rapid IPS QHD w dobrej cenie

Choć monitory OLED są coraz powszechniejsze, a gamingowe modele 4K coraz tańsze, nie ma się co oszukiwać, to standardowe LDC-ki o rozdzielczości QHD uznawane są przez graczy za...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/msi_g272qpf-28461.html">https://ithardware.pl/testyirecenzje/msi_g272qpf-28461.html</a></p>

## Po blisko 10 latach, Android 4.4 KitKat traci wsparcie usług Google Play
 - [https://ithardware.pl/aktualnosci/po_blisko_10_latach_android_4_4_kitkat_traci_wsparcie_uslug_google_play-28480.html](https://ithardware.pl/aktualnosci/po_blisko_10_latach_android_4_4_kitkat_traci_wsparcie_uslug_google_play-28480.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T12:33:30+00:00

<img src="https://ithardware.pl/artykuly/min/28480_1.jpg" />            To już koniec dla Androida 4.4 KitKat. Koniec wsparcia usługami Google Play. Na ten krok zdecydowano się dopiero po 10 latach. Jakie konsekwencje dla użytkownik&oacute;w KitKata niesie ze sobą ta decyzja?

Usługi Google Play to preinstalowana...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/po_blisko_10_latach_android_4_4_kitkat_traci_wsparcie_uslug_google_play-28480.html">https://ithardware.pl/aktualnosci/po_blisko_10_latach_android_4_4_kitkat_traci_wsparcie_uslug_google_play-28480.html</a></p>

## Były dyrektor Google ostrzega, że roboty mogą zastąpić ludzi w seksie
 - [https://ithardware.pl/aktualnosci/byly_dyrketor_google_ostrzega_ze_roboty_moga_zastapic_ludzi_w_seksie-28475.html](https://ithardware.pl/aktualnosci/byly_dyrketor_google_ostrzega_ze_roboty_moga_zastapic_ludzi_w_seksie-28475.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T11:29:02+00:00

<img src="https://ithardware.pl/artykuly/min/28475_1.jpg" />            Były dyrektor Google ostrzegł podczas podcastu, że pojawienie się urządzeń napędzanych sztuczną inteligencją w połączeniu z możliwościami headset&oacute;w rozszerzonej/wirtualnej rzeczywistości spowoduje, że roboty zastąpią ludzi w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/byly_dyrketor_google_ostrzega_ze_roboty_moga_zastapic_ludzi_w_seksie-28475.html">https://ithardware.pl/aktualnosci/byly_dyrketor_google_ostrzega_ze_roboty_moga_zastapic_ludzi_w_seksie-28475.html</a></p>

## Japonia zakazuje wywozu zaawansowanych narzędzi półprzewodnikowych do Chin
 - [https://ithardware.pl/aktualnosci/japonia_zakazuje_wywozu_zaawansowanych_narzedzi_polprzewodnikowych_do_chin-28481.html](https://ithardware.pl/aktualnosci/japonia_zakazuje_wywozu_zaawansowanych_narzedzi_polprzewodnikowych_do_chin-28481.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T11:16:40+00:00

<img src="https://ithardware.pl/artykuly/min/28481_1.jpg" />            Nowe japońskie przepisy dotyczące eksportu wybranych narzędzi fabryk wafli krzemowych do Chin spotkały się z reakcją ze strony Republiki Ludowej.

Chiny reagują na japońską kontrolę eksportu.

Chiny wydały oświadczenie wyrażające...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/japonia_zakazuje_wywozu_zaawansowanych_narzedzi_polprzewodnikowych_do_chin-28481.html">https://ithardware.pl/aktualnosci/japonia_zakazuje_wywozu_zaawansowanych_narzedzi_polprzewodnikowych_do_chin-28481.html</a></p>

## TikTok chce być jak Twitter? W aplikacji pojawiły się posty tekstowe
 - [https://ithardware.pl/aktualnosci/tiktok_chce_byc_jak_twitter_w_aplikacji_pojawily_sie_posty_tekstowe-28478.html](https://ithardware.pl/aktualnosci/tiktok_chce_byc_jak_twitter_w_aplikacji_pojawily_sie_posty_tekstowe-28478.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T11:07:20+00:00

<img src="https://ithardware.pl/artykuly/min/28478_1.jpg" />            Wszyscy chcą być jak Twitter? Threads od Meta, a teraz TikTok. Popularna aplikacja z kr&oacute;tkimi filmikami ogłosiła właśnie dodanie nowej funkcji. Teraz zamiast nagrywać filmik można podzielić się informacjami za pomocą post&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tiktok_chce_byc_jak_twitter_w_aplikacji_pojawily_sie_posty_tekstowe-28478.html">https://ithardware.pl/aktualnosci/tiktok_chce_byc_jak_twitter_w_aplikacji_pojawily_sie_posty_tekstowe-28478.html</a></p>

## OpenAI może tworzyć zaawansowany model AI, który połączy 10 milionów GPU od NVIDII
 - [https://ithardware.pl/aktualnosci/openai_moze_tworzyc_zaawansowany_model_ai_ktory_polaczy_10_milionow_gpu_od_nvidii-28474.html](https://ithardware.pl/aktualnosci/openai_moze_tworzyc_zaawansowany_model_ai_ktory_polaczy_10_milionow_gpu_od_nvidii-28474.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T10:33:02+00:00

<img src="https://ithardware.pl/artykuly/min/28474_1.jpg" />            Sztuczna inteligencja to obecnie najgorętszy temat w branży technologicznej, a NVIDIA jest jedną firm, kt&oacute;re mocno postawiły na AI już jakiś czas temu, dzięki czemu teraz zbiera tego owoce. Niemniej jednak firmy produkujące oprogramowanie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/openai_moze_tworzyc_zaawansowany_model_ai_ktory_polaczy_10_milionow_gpu_od_nvidii-28474.html">https://ithardware.pl/aktualnosci/openai_moze_tworzyc_zaawansowany_model_ai_ktory_polaczy_10_milionow_gpu_od_nvidii-28474.html</a></p>

## Meta i Unia Europejska nie pomagają tylko inwigilują. Ofiara wykorzystywania wnosi pozew
 - [https://ithardware.pl/aktualnosci/ofiara_wykorzystywania_dzieci_pozywa_meta_i_krytykuje_ue_za_skanowanie_wiadomosci-28479.html](https://ithardware.pl/aktualnosci/ofiara_wykorzystywania_dzieci_pozywa_meta_i_krytykuje_ue_za_skanowanie_wiadomosci-28479.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T09:43:50+00:00

<img src="https://ithardware.pl/artykuly/min/28479_1.jpg" />            Ofiara wykorzystywania seksualnego dzieci z Bawarii postanowiła podjąć przełomowe wyzwanie prawne, łącząc siły z Niemieckim Towarzystwem Wolności Obywatelskich (GFF), aby zakwestionować kontrowersyjną politykę Meta dotyczącą skanowania...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ofiara_wykorzystywania_dzieci_pozywa_meta_i_krytykuje_ue_za_skanowanie_wiadomosci-28479.html">https://ithardware.pl/aktualnosci/ofiara_wykorzystywania_dzieci_pozywa_meta_i_krytykuje_ue_za_skanowanie_wiadomosci-28479.html</a></p>

## GeForce RTX 4060 Ti 16 GB już przeceniany w Europie. W Polsce ceny także poniżej sugerowanej kwoty
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_16_gb_juz_przeceniany_w_europie_w_polsce_ceny_takze_ponizej_sugerowanej_kwoty-28473.html](https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_16_gb_juz_przeceniany_w_europie_w_polsce_ceny_takze_ponizej_sugerowanej_kwoty-28473.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T09:09:02+00:00

<img src="https://ithardware.pl/artykuly/min/28473_1.jpg" />            Karta graficzna NVIDIA GeForce RTX 4060 Ti 16 GB od samego początku budzi sporo kontrowersji, choćby ze względu na swoją wysoką cenę. Zainteresowanie tym modelem zdaje się zaś tak małe, że jest on już przeceniony w Europie, niecały tydzień...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_16_gb_juz_przeceniany_w_europie_w_polsce_ceny_takze_ponizej_sugerowanej_kwoty-28473.html">https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_16_gb_juz_przeceniany_w_europie_w_polsce_ceny_takze_ponizej_sugerowanej_kwoty-28473.html</a></p>

## Japonia znów chce być gigantem półprzewodników. Rząd stawia na lokalną produkcję w procesie 2 nm
 - [https://ithardware.pl/aktualnosci/japonia_znow_chce_byc_gigantem_polprzewodnikow_rzad_stawia_na_lokalna_produkcje_w_procesie_2_nm-28477.html](https://ithardware.pl/aktualnosci/japonia_znow_chce_byc_gigantem_polprzewodnikow_rzad_stawia_na_lokalna_produkcje_w_procesie_2_nm-28477.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T09:00:40+00:00

<img src="https://ithardware.pl/artykuly/min/28477_1.jpg" />            Chipy 2 nm od&nbsp;Rapidus - japońskiego konsorcjum p&oacute;łprzewodnikowego wspieranego przez rząd, kt&oacute;re zamierza wyprzedzić światowych lider&oacute;w produkcji układ&oacute;w scalonych - mają kosztować nawet&nbsp;dziesięć razy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/japonia_znow_chce_byc_gigantem_polprzewodnikow_rzad_stawia_na_lokalna_produkcje_w_procesie_2_nm-28477.html">https://ithardware.pl/aktualnosci/japonia_znow_chce_byc_gigantem_polprzewodnikow_rzad_stawia_na_lokalna_produkcje_w_procesie_2_nm-28477.html</a></p>

## Jego samochód spadł z wysokości ponad 100 metrów. Uratowały go funkcje bezpieczeństwa z iPhona
 - [https://ithardware.pl/aktualnosci/jego_samochod_spadl_z_wysokosci_ponad_100_metrow_uratowaly_go_funkcje_bezpieczenstwa_z_iphona-28476.html](https://ithardware.pl/aktualnosci/jego_samochod_spadl_z_wysokosci_ponad_100_metrow_uratowaly_go_funkcje_bezpieczenstwa_z_iphona-28476.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T08:58:30+00:00

<img src="https://ithardware.pl/artykuly/min/28476_1.jpg" />            To kolejny przykład tego, jak dobrą decyzją ze strony Apple było wprowadzenie dw&oacute;ch kluczowych funkcji bezpieczeństwa w iPhone'ach. Tym razem smartfon uratował mężczyznę, kt&oacute;rego samoch&oacute;d spadł w głąb kanionu o ponad...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/jego_samochod_spadl_z_wysokosci_ponad_100_metrow_uratowaly_go_funkcje_bezpieczenstwa_z_iphona-28476.html">https://ithardware.pl/aktualnosci/jego_samochod_spadl_z_wysokosci_ponad_100_metrow_uratowaly_go_funkcje_bezpieczenstwa_z_iphona-28476.html</a></p>

## Intel Arrow Lake bez Hyper-Threadingu? Nowe plotki o 15. generacji CPU Intela
 - [https://ithardware.pl/aktualnosci/intel_arrow_lake_bez_hyper_threadingu_nowe_plotki_o_15_generacji_cpu_intela-28472.html](https://ithardware.pl/aktualnosci/intel_arrow_lake_bez_hyper_threadingu_nowe_plotki_o_15_generacji_cpu_intela-28472.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T08:12:00+00:00

<img src="https://ithardware.pl/artykuly/min/28472_1.jpg" />            Plotki na temat procesor&oacute;w Arrow Lake od Intela zaczynają wypływać do sieci, a najnowsza jest niezwykle interesująca, bo sugeruje, że chipy nowej generacji, kt&oacute;re pojawią się po Raptor Lake Refresh, nie będą obsługiwać...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_arrow_lake_bez_hyper_threadingu_nowe_plotki_o_15_generacji_cpu_intela-28472.html">https://ithardware.pl/aktualnosci/intel_arrow_lake_bez_hyper_threadingu_nowe_plotki_o_15_generacji_cpu_intela-28472.html</a></p>

## PlayStation 5 dostępne w niższej cenie. Sony wystartowało z promocją
 - [https://ithardware.pl/aktualnosci/playstation_5_dostepne_w_nizszej_cenie_sony_wystartowalo_z_promocja-28471.html](https://ithardware.pl/aktualnosci/playstation_5_dostepne_w_nizszej_cenie_sony_wystartowalo_z_promocja-28471.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T07:01:19+00:00

<img src="https://ithardware.pl/artykuly/min/28471_1.jpg" />            Chociaż niewystarczająca podaż nieco ograniczyła sprzedaż PlayStation 5, szczeg&oacute;lnie w pierwszym roku dostępności, konsola nadal sprzedaje się bardzo dobrze, a w tym roku podaż znacznie się poprawiła. Na potwierdzenie tych sł&oacute;w,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/playstation_5_dostepne_w_nizszej_cenie_sony_wystartowalo_z_promocja-28471.html">https://ithardware.pl/aktualnosci/playstation_5_dostepne_w_nizszej_cenie_sony_wystartowalo_z_promocja-28471.html</a></p>

## iPhone 15 Pro i Pro Max mogą być jeszcze droższe od poprzedników
 - [https://ithardware.pl/aktualnosci/iphone_15_pro_i_pro_max_moga_byc_jeszcze_drozsze_od_poprzednikow-28470.html](https://ithardware.pl/aktualnosci/iphone_15_pro_i_pro_max_moga_byc_jeszcze_drozsze_od_poprzednikow-28470.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T07:01:10+00:00

<img src="https://ithardware.pl/artykuly/min/28470_1.jpg" />            Globalny popyt na smartfony nadal spada, ale Apple zdaje się na to nie zważać. Nowa generacja iPhone'&oacute;w giganta technologicznego powinna zadebiutować za mniej niż dwa miesiące i najwyraźniej będzie jeszcze droższa od...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/iphone_15_pro_i_pro_max_moga_byc_jeszcze_drozsze_od_poprzednikow-28470.html">https://ithardware.pl/aktualnosci/iphone_15_pro_i_pro_max_moga_byc_jeszcze_drozsze_od_poprzednikow-28470.html</a></p>

## Ubisoft wyjaśnia zamieszanie w sprawie usuwania nieaktywnych kont graczy
 - [https://ithardware.pl/aktualnosci/ubisoft_wyjasnia_zamieszanie_w_sprawie_usuwania_nieaktywnych_kont_graczy-28469.html](https://ithardware.pl/aktualnosci/ubisoft_wyjasnia_zamieszanie_w_sprawie_usuwania_nieaktywnych_kont_graczy-28469.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T06:13:34+00:00

<img src="https://ithardware.pl/artykuly/min/28469_1.jpg" />            W miniony weekend internet obiegła informacja, że Ubisoft dezaktywuje nieużywane konta i usunie wszelkie gry na PC powiązane z tym kontem. Teraz firma, na skutek ostrej krytyki ze strony graczy, zmieniła zdanie i postanowiła, że nie usunie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ubisoft_wyjasnia_zamieszanie_w_sprawie_usuwania_nieaktywnych_kont_graczy-28469.html">https://ithardware.pl/aktualnosci/ubisoft_wyjasnia_zamieszanie_w_sprawie_usuwania_nieaktywnych_kont_graczy-28469.html</a></p>

## Ubisofto wyjaśnia zamieszanie w sprawie usuwania nieaktywnych kont graczy
 - [https://ithardware.pl/aktualnosci/ubisofto_wyjasnia_zamieszanie_w_sprawie_usuwania_nieaktywnych_kont_graczy-28469.html](https://ithardware.pl/aktualnosci/ubisofto_wyjasnia_zamieszanie_w_sprawie_usuwania_nieaktywnych_kont_graczy-28469.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-07-25T06:13:34+00:00

<img src="https://ithardware.pl/artykuly/min/28469_1.jpg" />            W miniony weekend internet obiegła informacja, że Ubisoft dezaktywuje nieużywane konta i usunie wszelkie gry na PC powiązane z tym kontem. Teraz firma, na skutek ostrej krytyki ze strony graczy, zmieniła zdanie i postanowiła, że nie usunie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ubisofto_wyjasnia_zamieszanie_w_sprawie_usuwania_nieaktywnych_kont_graczy-28469.html">https://ithardware.pl/aktualnosci/ubisofto_wyjasnia_zamieszanie_w_sprawie_usuwania_nieaktywnych_kont_graczy-28469.html</a></p>

