# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Elon Musk's Rebranded Twitter Cuts Ad Prices
 - [https://www.wsj.com/articles/elon-musks-rebranded-twitter-cuts-ad-prices-d2615d8f?mod=rss_Technology](https://www.wsj.com/articles/elon-musks-rebranded-twitter-cuts-ad-prices-d2615d8f?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-07-25T21:20:00+00:00

The social-media site X is offering hefty discounts to lure back ad dollars

## Snap Revenue Falls Amid Efforts to Retool Advertising Business
 - [https://www.wsj.com/articles/snap-q2-earnings-report-2023-98bf1c94?mod=rss_Technology](https://www.wsj.com/articles/snap-q2-earnings-report-2023-98bf1c94?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-07-25T20:20:00+00:00

The owner of Snapchat reports progress in the overhaul of its ads platform but offers a cloudy outlook for the current quarter.

## Google Is Expected to Post Accelerating Growth as Online Ads Recover
 - [https://www.wsj.com/articles/alphabet-google-googl-q2-earnings-report-2023-f3cb023?mod=rss_Technology](https://www.wsj.com/articles/alphabet-google-googl-q2-earnings-report-2023-f3cb023?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-07-25T16:00:00+00:00

That result would mark its second straight positive quarter following an extended slowdown coming out of the pandemic.

## Microsoft Earnings Have Been Hurt by Cooling Software Demand, Helped by AI
 - [https://www.wsj.com/articles/microsoft-msft-q4-earnings-report-2023-3d6ebe64?mod=rss_Technology](https://www.wsj.com/articles/microsoft-msft-q4-earnings-report-2023-3d6ebe64?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-07-25T16:00:00+00:00

The company has become a leader in generative AI technology thanks to its cloud infrastructure and relationship with OpenAI.

## TikTok Wants to Sell Made-in-China Goods to Americans
 - [https://www.wsj.com/articles/tiktoks-next-plan-for-u-s-dominance-selling-made-in-china-goods-44943693?mod=rss_Technology](https://www.wsj.com/articles/tiktoks-next-plan-for-u-s-dominance-selling-made-in-china-goods-44943693?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-07-25T11:38:00+00:00

Video-sharing platform TikTok wants to replicate the success of popular China-founded shopping platforms Shein and Temu.

