# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Joe Biden laughs, ignores questions about potential impeachment by House Republicans
 - [https://www.foxnews.com/politics/joe-biden-laughs-ignores-questions-potential-impeachment-house-republicans](https://www.foxnews.com/politics/joe-biden-laughs-ignores-questions-potential-impeachment-house-republicans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:37:17+00:00

President Biden ignored and smiled at reporters who peppered him with questions about a potential impeachment by Republicans in the House.

## Fox News’ primetime lineup of Laura Ingraham, Jesse Watters, Sean Hannity, and Greg Gutfeld sweeps cable news
 - [https://www.foxnews.com/media/fox-news-primetime-lineup-laura-ingraham-jesse-watters-sean-hannity-greg-gutfeld-sweeps-cable-news](https://www.foxnews.com/media/fox-news-primetime-lineup-laura-ingraham-jesse-watters-sean-hannity-greg-gutfeld-sweeps-cable-news)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:36:16+00:00

Fox News Channel’s revamped primetime lineup continued to dominate cable news, crushing MSNBC and CNN as Laura Ingraham, Jesse Watters, Sean Hannity, and Greg Gutfeld begin a new era.

## Missouri burglary suspect shot in both legs by armed homeowners: authorities
 - [https://www.foxnews.com/us/missouri-burglary-suspect-shot-both-legs-armed-homeowners-authorities](https://www.foxnews.com/us/missouri-burglary-suspect-shot-both-legs-armed-homeowners-authorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:34:41+00:00

A pair of Missouri homeowners shot an intruder who opened fire on them when they returned to their house, authorities said.

## Mexican military's role in disappearance of 43 students questioned following new report's release
 - [https://www.foxnews.com/world/mexican-militarys-role-disappearance-43-students-questioned-new-reports-release](https://www.foxnews.com/world/mexican-militarys-role-disappearance-43-students-questioned-new-reports-release)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:27:10+00:00

A report submitted by a panel of experts Tuesday further complicated questions about the Mexican military&apos;s involvement in the 2014 disappearance of 43 students.

## Witness to Malcolm X's assassination says he heard police ask 'Is he with us?' as they restrained killer
 - [https://www.foxnews.com/us/witness-malcolm-x-assassination-says-he-heard-police-ask-he-with-us-they-restrained-killer](https://www.foxnews.com/us/witness-malcolm-x-assassination-says-he-heard-police-ask-he-with-us-they-restrained-killer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:26:56+00:00

A witness to Malcolm X&apos;s assassination says he heard police officers say &quot;is he with us?&quot; as they restrained the alleged killer shortly after the civil rights leader was gunned down.

## Bruins captain Patrice Bergeron announces retirement after 19 seasons in Boston
 - [https://www.foxnews.com/sports/bruins-captain-patrice-bergeron-announces-retirement-19-seasons-boston](https://www.foxnews.com/sports/bruins-captain-patrice-bergeron-announces-retirement-19-seasons-boston)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:26:43+00:00

Boston Bruins captain Patrice Bergeron, likely to be a Hall of Famer, announced his retirement Wednesday after 19 NHL seasons, all with the same franchise.

## MA denies request to dump over 1M gallons of defunct nuclear plant's wastewater into Cape Cod Bay
 - [https://www.foxnews.com/us/ma-denies-request-dump-1m-gallons-defunct-nuclear-plants-wastewater-cape-cod-bay](https://www.foxnews.com/us/ma-denies-request-dump-1m-gallons-defunct-nuclear-plants-wastewater-cape-cod-bay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:25:26+00:00

Massachusetts regulators have denied a request by a company dismantling the former Pilgrim Nuclear Power Station in Plymouth to discharge wastewater into Cape Cod Bay.

## Recreational pot push falls less than 1,000 signatures short of making it onto Ohio ballot
 - [https://www.foxnews.com/politics/recreational-pot-push-falls-less-1000-signatures-short-making-ohio-ballot](https://www.foxnews.com/politics/recreational-pot-push-falls-less-1000-signatures-short-making-ohio-ballot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:24:06+00:00

Backers of a proposal to legalize recreational marijuana use in Ohio have been allotted 10 more days to gather enough signatures for a statewide, public vote.

## Jana Kramer calls Miranda Lambert ‘kind of rude’ over concert selfie incident
 - [https://www.foxnews.com/entertainment/jana-kramer-calls-miranda-lambert-kind-of-rude-concert-selfie-incident](https://www.foxnews.com/entertainment/jana-kramer-calls-miranda-lambert-kind-of-rude-concert-selfie-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:16:37+00:00

Jana Kramer weighed in on Miranda Lambert calling out concertgoers for taking selfies during her show a week ago, saying she thought it was &quot;kind of rude.&quot;

## Cowboys lock up star Trevon Diggs with lucrative five-year extension: reports
 - [https://www.foxnews.com/sports/cowboys-lock-up-star-trevon-diggs-lucrative-five-year-extension-reports](https://www.foxnews.com/sports/cowboys-lock-up-star-trevon-diggs-lucrative-five-year-extension-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:13:01+00:00

Trevon Diggs was drafted in the second round in 2020. He was about to enter the final year of his rookie deal that would have paid him an estimated base salary of $4.3 million.

## California sea lions charge toward startled beachgoers, emptying busy cove
 - [https://www.foxnews.com/us/california-sea-lions-charge-toward-startled-beachgoers-emptying-busy-cove](https://www.foxnews.com/us/california-sea-lions-charge-toward-startled-beachgoers-emptying-busy-cove)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:12:00+00:00

People at a cove in San Diego, California, were startled after two large sea lions charged towards the beach and began loudly barking at beachgoers.

## Justin Herbert, Chargers agree to massive five-year extension: reports
 - [https://www.foxnews.com/sports/justin-herbert-chargers-agree-massive-five-year-extension-reports](https://www.foxnews.com/sports/justin-herbert-chargers-agree-massive-five-year-extension-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T19:04:20+00:00

Justin Herbert and the Los Angeles Chargers reportedly agreed to a five-year contract extension Tuesday. His contract is worth $262.5 million, according to multiple reports.

## LSU's Olivia Dunne reveals she doesn't attend class in person over 'scares in the past'
 - [https://www.foxnews.com/sports/lsus-olivia-dunne-reveals-she-doesnt-attend-class-in-person-scares-past](https://www.foxnews.com/sports/lsus-olivia-dunne-reveals-she-doesnt-attend-class-in-person-scares-past)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:58:39+00:00

LSU star gymnast Olivia Dunne opened up about her life on campus as one of the most-followed collegiate athletes. She revealed she doesn&apos;t attend class in person.

## Angry climate change protestors force Commerce Secretary Gina Raimondo to flee talk at the Wilson Center
 - [https://www.foxnews.com/politics/angry-climate-change-protestors-force-commerce-secretary-gina-raimondo-flee-talk-wilson-center](https://www.foxnews.com/politics/angry-climate-change-protestors-force-commerce-secretary-gina-raimondo-flee-talk-wilson-center)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:58:23+00:00

A Wilson Center event featuring Commerce Secretary Gina Raimondo was cut short when a group of climate change protestors barged in and interrupted Raimondo, video shows.

## Matt Damon says kissing Scarlett Johansson 'was hell'
 - [https://www.foxnews.com/entertainment/matt-damon-kissing-scarlett-johansson-was-hell](https://www.foxnews.com/entertainment/matt-damon-kissing-scarlett-johansson-was-hell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:57:29+00:00

Matt Damon joked that filming a kissing scene with his co-star Scarlett Johansson was &quot;hell&quot; after she ate a onion sandwich.

## Biden skewered for claiming he effectively 'ended cancer as we know it:' 'Why haven't the adults intervened?'
 - [https://www.foxnews.com/media/biden-skewered-claiming-effectively-ended-cancer-know-why-havent-adults-intervened](https://www.foxnews.com/media/biden-skewered-claiming-effectively-ended-cancer-know-why-havent-adults-intervened)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:38:03+00:00

President Biden faced vicious online criticism after claiming during a White House address that his administration has effectively &apos;ended cancer as we know it.&apos;

## Texas school to fire teacher arrested in child prostitution sting
 - [https://www.foxnews.com/us/texas-school-fire-teacher-arrested-child-prostitution-sting](https://www.foxnews.com/us/texas-school-fire-teacher-arrested-child-prostitution-sting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:37:23+00:00

A Texas school district has begun the termination process for a teacher who was recently hired after he was arrested in a sex trafficking case

## Texas shooter with 'long gun' opens fire at medical building injuring physician, patient
 - [https://www.foxnews.com/us/texas-shooter-long-gun-opens-fire-medical-building-injuring-physician-patient](https://www.foxnews.com/us/texas-shooter-long-gun-opens-fire-medical-building-injuring-physician-patient)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:27:21+00:00

Police in Cedar Hill, Texas, said a gunman armed with a &quot;long gun&quot; opened fire inside a medical building, leaving a physician and a patient injured. The suspect was later arrested.

## McCarthy screens Sound of Freedom for members of Congress
 - [https://www.foxnews.com/politics/mccarthy-screens-sound-of-freedom-for-members-of-congress](https://www.foxnews.com/politics/mccarthy-screens-sound-of-freedom-for-members-of-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:25:19+00:00

Speaker McCarthy told reporters he was inviting lawmakers on both sides of the aisle to come to a screening of &apos;Sound of Freedom&apos; on Tuesday evening

## Rikers Island staffer slashed by inmate at troubled NYC jail complex
 - [https://www.foxnews.com/us/rikers-island-staffer-slashed-inmate-troubles-nyc-jail-complex](https://www.foxnews.com/us/rikers-island-staffer-slashed-inmate-troubles-nyc-jail-complex)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:13:37+00:00

A new York City correction officer was slashed by an inmate at the city&apos;s Rikers Island jail complex on Tuesday.

## WH denials of Joe Biden's knowledge of Hunter's business deals made 'significant shift': ex-prosecutor
 - [https://www.foxnews.com/media/wh-denials-joe-bidens-knowledge-hunters-business-deals-significant-shift-ex-prosecutor](https://www.foxnews.com/media/wh-denials-joe-bidens-knowledge-hunters-business-deals-significant-shift-ex-prosecutor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:12:24+00:00

Former New York federal prosecutor Andrew C. McCarthy told Fox News it is clear there has been a subtle yet important shift in White House rhetoric about Hunter Biden.

## Naomi Watts admits she was 'spiraling out of control' when she went through menopause at 36 years old
 - [https://www.foxnews.com/entertainment/naomi-watts-admits-spiraling-out-control-when-went-through-menopause-36-years-old](https://www.foxnews.com/entertainment/naomi-watts-admits-spiraling-out-control-when-went-through-menopause-36-years-old)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:10:24+00:00

Naomi Watts is sharing insight on what it was like to experience early menopause. The &quot;Watcher&quot; actress said it &quot;was not easy&quot; to go through menopause at 36.

## Maryland dad arrested after six-week-old baby found with broken bones: police
 - [https://www.foxnews.com/us/maryland-dad-arrested-six-week-old-baby-found-broken-bones-police](https://www.foxnews.com/us/maryland-dad-arrested-six-week-old-baby-found-broken-bones-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:08:04+00:00

Maryland father Keith Patrick Lewis was charged with first- and second-degree child abuse after his six-month-old infant was found with broken bones, Frederick police said.

## Hugh 'Sonny' Carter Jr., key figure in helping organize Jimmy Carter's 'Peanut Brigade,' has died
 - [https://www.foxnews.com/us/hugh-sonny-carter-jr-key-figure-helping-organize-jimmy-carters-peanut-brigade-died](https://www.foxnews.com/us/hugh-sonny-carter-jr-key-figure-helping-organize-jimmy-carters-peanut-brigade-died)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:04:51+00:00

Hugh &quot;Sonny&quot; Carter Jr., a key figure in helping elect his cousin Jimmy Carter to the White House and later implementing cost-saving measures in the president&apos;s administration, has died.

## Chicago teenage victim of serial killer Larry Eyler identified after 1983 murder
 - [https://www.foxnews.com/us/chicago-teenage-victim-serial-killer-larry-eyler-identified-1983-murder](https://www.foxnews.com/us/chicago-teenage-victim-serial-killer-larry-eyler-identified-1983-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:03:35+00:00

The body of Chicago teen Keith Lavell Bibbs was identified after he was murdered and found in 1984, officials say. Bibbs was killed by serial killer Larry Eyler.

## Boston-area man gets 10 years for ordering attempted hit on wife
 - [https://www.foxnews.com/us/boston-area-man-gets-10-years-ordering-attempted-hit-wife](https://www.foxnews.com/us/boston-area-man-gets-10-years-ordering-attempted-hit-wife)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:02:21+00:00

Massimo Marenghi, 57, of Malden, Massachusetts, has been sentenced to 10 years in prison after federal investigators thwarted his plan to have a hit man kill his wife.

## 49ers' Brock Purdy cleared to practice six months after elbow surgery
 - [https://www.foxnews.com/sports/49ers-brock-purdy-cleared-practice-six-months-elbow-surgery](https://www.foxnews.com/sports/49ers-brock-purdy-cleared-practice-six-months-elbow-surgery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:02:19+00:00

Brock Purdy led the San Francisco 49ers to the NFC championship after both Trey Lance and Jimmy Garoppolo suffered season-ending injuries.

## Enes Kanter Freedom eying congressional bid 'likely' in 2028
 - [https://www.foxnews.com/media/enes-kanter-freedom-eying-congressional-bid-likely-2028](https://www.foxnews.com/media/enes-kanter-freedom-eying-congressional-bid-likely-2028)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T18:00:44+00:00

In an interview with Fox News Digital, former NBA star Enes Kanter Freedom shared details about a potential run for office and what his priorities would be as a candidate.

## Indiana man shot, killed by police after pointing gun at them
 - [https://www.foxnews.com/us/indiana-man-shot-killed-police-pointing-gun](https://www.foxnews.com/us/indiana-man-shot-killed-police-pointing-gun)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:59:19+00:00

Police in Terre Haute, Indiana, shot and killed a suspect who pointed a firearm at them following a two-hour standoff at a landscaping business warehouse on Tuesday.

## Polish women protest outside police stations after controversial treatment of woman seeking abortion
 - [https://www.foxnews.com/world/polish-women-protest-police-stations-controversial-treatment-woman-seeking-abortion](https://www.foxnews.com/world/polish-women-protest-police-stations-controversial-treatment-woman-seeking-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:57:07+00:00

Hundreds of Polish women protested outside police stations, expressing their solidarity with a woman who was allegedly mistreated by officers after taking an abortion pill.

## World Aquatics announces 'open category' to include trans swimmers: 'Our sport must be for everyone'
 - [https://www.foxnews.com/sports/world-aquatics-announces-open-category-include-trans-swimmers-sport-must-be-everyone](https://www.foxnews.com/sports/world-aquatics-announces-open-category-include-trans-swimmers-sport-must-be-everyone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:55:35+00:00

World Aquatics president Husain Al-Musallam announced plans for an &quot;open category&quot; on Tuesday, more than a year after the sports governing body limited trans athletes participation.

## Clemson University fraternity receives 4-year suspension for hazing with salt-like materials causing burns
 - [https://www.foxnews.com/us/clemson-university-fraternity-receives-4-year-suspension-hazing-salt-materials-causing-burns](https://www.foxnews.com/us/clemson-university-fraternity-receives-4-year-suspension-hazing-salt-materials-causing-burns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:54:48+00:00

A Clemson University fraternity is facing a four-year suspension following a probe that revealed new members were subjected to hazing rituals involving materials that caused burns.

## Obamas' chef who drowned while paddleboarding wasn’t wearing life vest, no foul play suspected, police say
 - [https://www.foxnews.com/politics/obamas-chef-who-drowned-paddleboarding-wasnt-wearing-life-vest-no-foul-play-suspected-police-say](https://www.foxnews.com/politics/obamas-chef-who-drowned-paddleboarding-wasnt-wearing-life-vest-no-foul-play-suspected-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:44:03+00:00

Police say no foul play is suspected in the death of Tafari Campbell who drowned Sunday while paddleboarding without a life vest near the Obamas&apos; home on Martha&apos;s Vineyard.

## Being Barbie: Woman is self-proclaimed 'plus-sized' Barbie doll and proud of it
 - [https://www.foxnews.com/lifestyle/barbie-look-alike-woman-self-proclaimed-plus-sized-barbie-doll-proud](https://www.foxnews.com/lifestyle/barbie-look-alike-woman-self-proclaimed-plus-sized-barbie-doll-proud)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:43:49+00:00

A California woman calls herself a &quot;plus-sized&quot; Barbie. She said she&apos;s accepted her larger body size and is full of confidence, just as the popular toy doll is, she said.

## Texas Democrat begins 'thirst strike' to call for federally mandated water breaks
 - [https://www.foxnews.com/politics/texas-democrat-begins-thirst-strike-call-federally-mandated-water-breaks](https://www.foxnews.com/politics/texas-democrat-begins-thirst-strike-call-federally-mandated-water-breaks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:38:45+00:00

A Texas congressman planned to go on a thirst strike Tuesday to call for federal workplace heat rules in protest of a Texas law recently signed by Gov. Greg Abbott.

## Higher education has become a 'disservice' to students, 'not worthy of our trust': Peter Boghossian
 - [https://www.foxnews.com/us/higher-education-disservice-students-not-worthy-trust-peter-boghossian](https://www.foxnews.com/us/higher-education-disservice-students-not-worthy-trust-peter-boghossian)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:30:12+00:00

Peter Boghossian, a founding faculty member for University of Austin, shared why Americans&apos; confidence in higher education has reached record lows.

## Oklahoma police search for duo accused of killing several animals at pet store
 - [https://www.foxnews.com/us/oklahoma-police-search-duo-accused-killing-several-animals-pet-store](https://www.foxnews.com/us/oklahoma-police-search-duo-accused-killing-several-animals-pet-store)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:23:17+00:00

Oklahoma City police posted an image of a man and woman at a pet store who allegedly killed multiple animals, including a hamster that was stomped to death.

## Vulnerable Democrat senator served as president of synagogue that allowed drag queen to preside over services
 - [https://www.foxnews.com/politics/vulnerable-democrat-senator-served-president-synagogue-allowed-drag-queen-preside-over-services](https://www.foxnews.com/politics/vulnerable-democrat-senator-served-president-synagogue-allowed-drag-queen-preside-over-services)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:11:06+00:00

Vulnerable Democratic Sen. Jacky Rosen, D-Nev., previously served as the president of the Congregation Ner Tamid, a synagogue that invited a drag queen to preside over services.

## Former top Memphis police officer sues Nashville PD for job offer revocation due to HIV status
 - [https://www.foxnews.com/us/former-top-memphis-police-officer-sues-nashville-pd-job-offer-revocation-due-hiv-status](https://www.foxnews.com/us/former-top-memphis-police-officer-sues-nashville-pd-job-offer-revocation-due-hiv-status)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:10:22+00:00

A former police officer filed a lawsuit against the Nashville Police Department, claiming that it violated federal law by retracting a job offer after finding out he was HIV-positive.

## Kentucky crime statistics undercounted homicides in Jefferson County
 - [https://www.foxnews.com/us/kentucky-crime-statistics-undercounted-homicides-jefferson-county](https://www.foxnews.com/us/kentucky-crime-statistics-undercounted-homicides-jefferson-county)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:07:23+00:00

A recent report in Kentucky&apos;s Jefferson County, has been found to have undercounted homicides. Instead of the reported 64 homicides in the county, the actual number was 164.

## Ohio officer on paid leave after prompting K-9 attack on surrendering trucker
 - [https://www.foxnews.com/us/ohio-officer-paid-leave-prompting-k-9-attack-surrendering-trucker](https://www.foxnews.com/us/ohio-officer-paid-leave-prompting-k-9-attack-surrendering-trucker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:05:52+00:00

Circleville, Ohio police officer Ryan Speakman was placed on paid administrative leave after a police dog attack led to the hospitalization of a truck driver.

## Iowa Supreme Court says Gov. Reynolds can appeal block on strict abortion law
 - [https://www.foxnews.com/politics/iowa-supreme-court-says-gov-reynolds-appeal-block-strict-abortion-law](https://www.foxnews.com/politics/iowa-supreme-court-says-gov-reynolds-appeal-block-strict-abortion-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:03:59+00:00

The Iowa Supreme Court on Tuesday said Republican Gov. Kim Reynolds can appeal a temporary block on the state’s restrictive abortion law.

## Wisconsin pulls out of Trump-era border wall funding lawsuit
 - [https://www.foxnews.com/politics/wisconsin-pulls-trump-era-border-wall-funding-lawsuit](https://www.foxnews.com/politics/wisconsin-pulls-trump-era-border-wall-funding-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:02:08+00:00

Wisconsin on Tuesday successfully ended its legal challenge to a Trump-era plan to divert National Guard funding to the construction of a wall along the Mexican border.

## Greta Thunberg dragged out of oil facility by police, claims crime is self-defense from fossil fuels
 - [https://www.foxnews.com/media/greta-thunberg-dragged-out-oil-facility-police-claims-crime-self-defense-fossil-fuels](https://www.foxnews.com/media/greta-thunberg-dragged-out-oil-facility-police-claims-crime-self-defense-fossil-fuels)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:00:53+00:00

Greta Thunberg, a climate activist from Reclaim the Future, is dragged out of an oil facility hours after

## 4 dead, 4 injured after gunman opens fire at South African taxi stand
 - [https://www.foxnews.com/world/4-dead-4-injured-gunman-opens-fire-south-african-taxi-stand](https://www.foxnews.com/world/4-dead-4-injured-gunman-opens-fire-south-african-taxi-stand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T17:00:52+00:00

A gunman shot and killed four people and injured four others at a taxi stand in Port Shepstone, South Africa. The attacker&apos;s motive is unknown.

## Michigan man allegedly preyed on young girls on amusement park pool: police
 - [https://www.foxnews.com/us/michigan-man-allegedly-preyed-young-girls-amusement-park-pool-police](https://www.foxnews.com/us/michigan-man-allegedly-preyed-young-girls-amusement-park-pool-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T16:51:11+00:00

Michigan State Police are investigating after a 39-year-old man allegedly touched several young girls inappropriately at Michigan&apos;s Adventure amusement park on July 22.

## Damar Hamlin leads outpouring of support for Bronny James following cardiac arrest
 - [https://www.foxnews.com/sports/damar-hamlin-leads-outpouring-support-bronny-james-following-cardiac-arrest](https://www.foxnews.com/sports/damar-hamlin-leads-outpouring-support-bronny-james-following-cardiac-arrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T16:47:30+00:00

Buffalo Bills safety Damar Hamlin was one of many in the sports world to offer prayers for Bronny James after he suffered cardiac arrest on Monday.

## Aaron Hernandez's brother arrested amid concerns he was planning school shootings
 - [https://www.foxnews.com/sports/aaron-hernandezs-brother-arrested-concerns-planning-school-shootings](https://www.foxnews.com/sports/aaron-hernandezs-brother-arrested-concerns-planning-school-shootings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T16:36:50+00:00

Aaron Hernandez&apos;s brother was arrested on Wednesday for the fourth time this year after allegedly planning shootings on two college campuses.

## Los Angeles attorney jailed in Venezuela faces spy allegations as US government pressured to act
 - [https://www.foxnews.com/world/los-angeles-attorney-jailed-venezuela-faces-spy-allegations-us-government-pressured-act](https://www.foxnews.com/world/los-angeles-attorney-jailed-venezuela-faces-spy-allegations-us-government-pressured-act)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T16:29:41+00:00

Lawmakers in Washington are calling for the release OF a Los Angeles attorney being held in Venezuela.

## Debunked Bucks: Top House Democrat's claim of outraising GOP rival proven false
 - [https://www.foxnews.com/politics/debunked-bucks-top-house-democrats-claim-outraise-gop-rival-proven-false](https://www.foxnews.com/politics/debunked-bucks-top-house-democrats-claim-outraise-gop-rival-proven-false)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T16:13:37+00:00

The claim that House Minority Leader Hakeem Jeffries, D-N.Y., raised more money than House Speaker Kevin McCarthy, R-Calif., during the second quarter of 2023 is false.

## Austin police union launch podcast addressing the ongoing impact of the city council's 2020 defunding
 - [https://www.foxnews.com/us/austin-police-union-launch-podcast-addressing-ongoing-impact-city-council-defunding](https://www.foxnews.com/us/austin-police-union-launch-podcast-addressing-ongoing-impact-city-council-defunding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T16:09:05+00:00

Austin&apos;s police union has launched a new podcast series that will feature conversations with officers sharing their experiences of working in defunded or disbanded units.

## Be well: Stop ‘summer sadness’ with these expert tips
 - [https://www.foxnews.com/health/be-well-stop-summer-sadness-expert-tips](https://www.foxnews.com/health/be-well-stop-summer-sadness-expert-tips)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T16:04:53+00:00

Seasonal affective disorder (SAD) is often linked to the dark winter months, but it can rear its head any time of year. Experts offer tips on how to handle depressive symptoms in summer.

## Katie Ledecky ties Michael Phelps record at Worlds with gold medal finish in 1,500-meter freestyle
 - [https://www.foxnews.com/sports/katie-ledecky-ties-michael-phelps-record-worlds-gold-medal-finish-1500-meter-freestyle](https://www.foxnews.com/sports/katie-ledecky-ties-michael-phelps-record-worlds-gold-medal-finish-1500-meter-freestyle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T16:00:54+00:00

Katie Ledecky tied Michael Phelps for the most individual world titles on Tuesday with her first place finish in the women’s 1,500 meter freestyle at the World Aquatics Championships.

## New Jersey 6-year-old suffocated by seat belt while bus monitor stared at phone for 14 mins, police say
 - [https://www.foxnews.com/us/new-jersey-6-year-old-suffocated-seat-belt-bus-monitor-stared-phone-14-mins-police-say](https://www.foxnews.com/us/new-jersey-6-year-old-suffocated-seat-belt-bus-monitor-stared-phone-14-mins-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:58:40+00:00

A 6-year-old special needs student who died on a school bus &quot;struggled violently for her life&quot; while a bus monitor sat just feet away wearing earbuds and staring at her phone.

## Hillary Clinton shredded for tweet blaming 'MAGA Republicans' for heat wave: 'She's broken'
 - [https://www.foxnews.com/media/hillary-clinton-shredded-tweet-blaming-maga-republicans-heat-wave-shes-broken](https://www.foxnews.com/media/hillary-clinton-shredded-tweet-blaming-maga-republicans-heat-wave-shes-broken)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:49:52+00:00

Hillary Clinton&apos;s odd remark pinning the heat wave on &quot;MAGA&quot; Republicans only continues to erase her stateswoman legacy, &quot;Outnumbered&quot; panelists said Tuesday.

## Grandson of Bucks head coach Adrian Griffin dead at 2 from ‘natural causes’
 - [https://www.foxnews.com/sports/grandson-bucks-head-coach-adrian-griffin-dead-natural-causes](https://www.foxnews.com/sports/grandson-bucks-head-coach-adrian-griffin-dead-natural-causes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:46:14+00:00

Milwaukee Bucks head coach Adrian Griffin released a statement Monday after his 2-year-old grandson tragically died over the weekend.

## California expanding pilot program to fight meth addiction with gift cards, incentives
 - [https://www.foxnews.com/politics/california-expanding-pilot-program-fight-meth-addiction-gift-cards-incentives](https://www.foxnews.com/politics/california-expanding-pilot-program-fight-meth-addiction-gift-cards-incentives)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:40:30+00:00

California&apos;s Recovery Incentives Program is expanding to more counties after a federal waiver, encouraging drug users to stay sober by giving out gift cards.

## Kansas men arrested over human trafficking charges at Wichita hotel: police
 - [https://www.foxnews.com/us/kansas-men-arrested-human-trafficking-charges-wichita-hotel-police](https://www.foxnews.com/us/kansas-men-arrested-human-trafficking-charges-wichita-hotel-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:37:27+00:00

Wichita residents Sinora Wilson and Elijah McCray were arrested at a hotel Friday night over human trafficking charges. The victim, who is a minor, was taken to a children&apos;s shelter.

## Michigan's Jim Harbaugh facing 4-game suspension: report
 - [https://www.foxnews.com/sports/michigans-jim-harbaugh-facing-4-game-suspension-report](https://www.foxnews.com/sports/michigans-jim-harbaugh-facing-4-game-suspension-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:36:43+00:00

The NCAA and Michigan Wolverines head coach Jim Harbaugh are reportedly settling on a four-game suspension in connection with a recruiting investigation.

## Detransitioner files $1M lawsuit against doctors for botched mastectomy that left her 'permanently disfigured'
 - [https://www.foxnews.com/media/detransitioner-files-1m-lawsuit-against-doctors-botched-mastectomy-left-her-permanently-disfigured](https://www.foxnews.com/media/detransitioner-files-1m-lawsuit-against-doctors-botched-mastectomy-left-her-permanently-disfigured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:30:52+00:00

Soren Aldaco, a 21-year-old Texas woman who detransitioned, is suing her doctors for &quot;gross malpractice&quot; after pressuring her into a double mastectomy that she said resulted is permanent disfigurement.

## Conservative activist rejects Senate Dem demand for help in Supreme Court probe: ‘Political retaliation’
 - [https://www.foxnews.com/politics/conservative-activist-rejects-senate-dem-demand-help-supreme-court-probe-political-retaliation](https://www.foxnews.com/politics/conservative-activist-rejects-senate-dem-demand-help-supreme-court-probe-political-retaliation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:30:15+00:00

A conservative activist says he is declining to participate in an investigation launched by Senate Democrats attempting to investigate trips taken by conservative judges.

## Resurfaced video of 'Snow White' actress sparks controversy over changes in Disney remake: ‘No longer 1937'
 - [https://www.foxnews.com/media/resurfaced-video-snow-white-actress-sparks-controversy-changes-disney-remake-no-longer-1937](https://www.foxnews.com/media/resurfaced-video-snow-white-actress-sparks-controversy-changes-disney-remake-no-longer-1937)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:30:03+00:00

A resurfaced video of &quot;Snow White&quot; actress Rachel Zegler discusses how Disney&apos;s new film will offer a modern take, noting that it&apos;s &quot;no longer 1937.&quot;

## California beaver policy aims to tap ecological benefits, protect 'keystone species'
 - [https://www.foxnews.com/science/california-beaver-policy-aims-tap-ecological-benefits-protect-keystone-species](https://www.foxnews.com/science/california-beaver-policy-aims-tap-ecological-benefits-protect-keystone-species)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:26:56+00:00

A California policy has taken effect this summer that recognizes the ecological benefits of beavers and encourages agencies to first seek nonviolent solutions before killing them.

## Possible hate crime investigation after musician finds noose near Lyle Lovett's concert venue in Montana
 - [https://www.foxnews.com/us/possible-hate-crime-investigation-musician-finds-noose-near-lyle-lovetts-concert-venue-montana](https://www.foxnews.com/us/possible-hate-crime-investigation-musician-finds-noose-near-lyle-lovetts-concert-venue-montana)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:25:25+00:00

A trombone player performing with Lyle Lovett and His Large Band, discovered a noose hanging from a light pole near the band&apos;s tour bus in Billings, Montana, over the weekend.

## Bryan Kohberger might claim 'alibi' in Idaho murders case, court filing reveals
 - [https://www.foxnews.com/us/bryan-kohberger-might-claim-alibi-idaho-murders-case-court-filing-reveals](https://www.foxnews.com/us/bryan-kohberger-might-claim-alibi-idaho-murders-case-court-filing-reveals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:25:20+00:00

Bryan Kohberger &quot;might rely on an alibi&quot; in his upcoming quadruple murder trial in Idaho, according to a recent court filing and criminal defense attorney John Henry Browne.

## Kentucky-based indoor farming company AppHarvest files for bankruptcy amid financial struggles
 - [https://www.foxnews.com/us/kentucky-based-indoor-farming-company-appharvest-files-bankruptcy-amid-financial-struggles](https://www.foxnews.com/us/kentucky-based-indoor-farming-company-appharvest-files-bankruptcy-amid-financial-struggles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:23:46+00:00

AppHarvest, a Kentucky-headquartered indoor farming company, which gained attention with support from Martha Stewart and started tomato shipments in 2021, has filed for bankruptcy.

## Russian antiwar activist faces residency permit refusal in Serbia; authorities cite security risk
 - [https://www.foxnews.com/world/russian-antiwar-activist-faces-residency-permit-refusal-serbia-authorities-cite-security-risk](https://www.foxnews.com/world/russian-antiwar-activist-faces-residency-permit-refusal-serbia-authorities-cite-security-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:22:23+00:00

A Russian antiwar group, the Russian Democratic Society, has reported that Serbian authorities have denied extending the residence permit of one of its activists, Vladimir Volokhonski.

## Harris, Biden take veiled shots at DeSantis during Emmett Till national monument ceremony
 - [https://www.foxnews.com/politics/harris-biden-take-veiled-shots-desantis-emmett-till-national-monument-ceremony](https://www.foxnews.com/politics/harris-biden-take-veiled-shots-desantis-emmett-till-national-monument-ceremony)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:21:46+00:00

Without naming names, President Biden and Vice President Harris appeared to take swipes at Ron DeSantis at a ceremony for an Emmett Till national monument.

## Tennessee police fatally shoot armed man during welfare check following threats of self-harm
 - [https://www.foxnews.com/us/tennessee-police-fatally-shoot-armed-man-welfare-check-following-threats-self-harm](https://www.foxnews.com/us/tennessee-police-fatally-shoot-armed-man-welfare-check-following-threats-self-harm)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:18:22+00:00

During a welfare check in Franklin, Tennessee, a police officer fatally shot an armed man who was threatening to commit suicide, as reported by authorities.

## Defense pushes to exhume body of Pittsburgh synagogue shooter's father
 - [https://www.foxnews.com/us/defense-pushes-exhume-body-pittsburgh-synagogue-shooters-father](https://www.foxnews.com/us/defense-pushes-exhume-body-pittsburgh-synagogue-shooters-father)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:16:41+00:00

Lawyers for convicted Tree of Life synagogue shooter Robert Bowers are seeking to exhume his father&apos;s body to prove the possible heredity of his schizophrenia.

## Ecuador declares state of emergency amid prison violence surge
 - [https://www.foxnews.com/world/ecuador-declares-state-emergency-prison-violence-surge](https://www.foxnews.com/world/ecuador-declares-state-emergency-prison-violence-surge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:14:23+00:00

Ecuador on Tuesday declared a state of emergency after shootings and explosions were reported at Litoral Penitentiary in Guayaquil, one of the nation&apos;s most brutal prisons.

## Fox News Politics: Hunter Biden narrative buster
 - [https://www.foxnews.com/politics/fox-news-politics-hunter-biden-narrative-buster](https://www.foxnews.com/politics/fox-news-politics-hunter-biden-narrative-buster)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:12:25+00:00

Get the latest updates from the 2024 campaign trail, exclusive interviews and more Fox News politics content

## George Santos has ‘put a stain’ on us, says retired New York City cop taking on scandalized GOP congressman
 - [https://www.foxnews.com/politics/george-santos-stain-says-retired-new-york-city-cop-taking-scandalized-gop-congressman](https://www.foxnews.com/politics/george-santos-stain-says-retired-new-york-city-cop-taking-scandalized-gop-congressman)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:09:44+00:00

Retired New York City Police Department detective turned private security executive and Republican business leader Mike Sapraicone is aiming to oust embattled GOP Rep. George Santos.

## House conservatives hungry for Biden impeachment after McCarthy’s comments: ‘Ground shifted’
 - [https://www.foxnews.com/politics/house-conservatives-hungry-biden-impeachment-mccarthys-comments-ground-shifted](https://www.foxnews.com/politics/house-conservatives-hungry-biden-impeachment-mccarthys-comments-ground-shifted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:09:16+00:00

House Freedom Caucus members appeared enthused on Tuesday after Speaker McCarthy made his clearest impeachment threat against President Biden yet

## White House talking points about Hunter Biden’s pricey art sales turned out to be blatantly wrong
 - [https://www.foxnews.com/politics/white-house-talking-points-hunter-bidens-pricey-art-sales-turned-out-blatantly-wrong](https://www.foxnews.com/politics/white-house-talking-points-hunter-bidens-pricey-art-sales-turned-out-blatantly-wrong)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:00:35+00:00

The White House narrative that Hunter Biden’s art buyers will remain anonymous to prevent the appearance of any &quot;undue influence&quot; is beginning to crumble.

## Miranda Devine on David Weiss possibly testifying before House: 'Why did he let Hunter off the hook?'
 - [https://www.foxnews.com/media/miranda-devine-david-weiss-possibly-testifying-before-house-why-did-he-let-hunter-off-hook](https://www.foxnews.com/media/miranda-devine-david-weiss-possibly-testifying-before-house-why-did-he-let-hunter-off-hook)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T15:00:09+00:00

U.S. Attorney David Weiss, who led the Hunter Biden investigation, could be brought before the House Judiciary Committee for questioning in the fall.

## Chocolate 'lasagna' for a unique, delectable dessert: Try the recipe
 - [https://www.foxnews.com/lifestyle/chocolate-lasagna-unique-delectable-dessert-try-recipe](https://www.foxnews.com/lifestyle/chocolate-lasagna-unique-delectable-dessert-try-recipe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:57:39+00:00

This delicious chocolate &quot;lasagna&quot; takes only 30 minutes to prep and could be a &quot;make-ahead&quot; dessert for all your summer functions. The dish is made with Oreos, Cool Whip and more.

## Dating should be treated like 'job interview' for marriage rather than a lark, mother argues
 - [https://www.foxnews.com/media/dating-should-treated-job-interview-marriage-rather-lark-mother-argues](https://www.foxnews.com/media/dating-should-treated-job-interview-marriage-rather-lark-mother-argues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:57:39+00:00

A conservative author and mom has some advice for young people dating today: Don&apos;t treat it lightly and be upfront about your future goals.

## Cellphone data ties Kentucky man to teen mom's disappearance, death 13 years ago
 - [https://www.foxnews.com/us/cellphone-data-ties-kentucky-man-teen-moms-disappearance-death-13-years-ago](https://www.foxnews.com/us/cellphone-data-ties-kentucky-man-teen-moms-disappearance-death-13-years-ago)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:52:03+00:00

An Ohio jury on Monday found Jacob Bumpass, 35, guilty of abusing a corpse and tampering with evidence in connection with 17-year-old Paige Johnson&apos;s disappearance in 2010.

## DeSantis campaign cuts more staff as part of push to 'streamline' presidential bid
 - [https://www.foxnews.com/politics/desantis-campaign-cuts-more-staff-push-streamline-presidential-bid](https://www.foxnews.com/politics/desantis-campaign-cuts-more-staff-push-streamline-presidential-bid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:46:15+00:00

The Republican presidential campaign of Florida Gov. Ron DeSantis is cutting more staff as it attempts to &quot;streamline&quot; operations and get their White House bid back on track

## Pete Davidson ordered to do community service after crashing car into Beverly Hills home
 - [https://www.foxnews.com/entertainment/pete-davidson-ordered-community-service-after-crashing-car-beverly-hills-home](https://www.foxnews.com/entertainment/pete-davidson-ordered-community-service-after-crashing-car-beverly-hills-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:33:18+00:00

Pete Davidson was given community service after pleading not guilty to misdemeanor reckless driving following a Beverly Hills car crash, Fox News Digital can confirm.

## Three Marines found dead in a car near Camp Lejeune in North Carolina
 - [https://www.foxnews.com/us/three-marines-found-dead-car-camp-lejeune-north-carolina](https://www.foxnews.com/us/three-marines-found-dead-car-camp-lejeune-north-carolina)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:30:55+00:00

Three Marines were found dead Sunday morning in a privately-owned vehicle parked at a Speedway gas station near Camp Lejeune in North Carolina, according to officials.

## Verdict expected in Belgium's historic trial over 2016 Brussels terror attacks
 - [https://www.foxnews.com/world/verdict-expected-belgiums-historic-trial-2016-brussels-terror-attacks](https://www.foxnews.com/world/verdict-expected-belgiums-historic-trial-2016-brussels-terror-attacks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:30:51+00:00

Belgium&apos;s deadliest peacetime attack, the 2016 suicide bombings at Brussels Airport and a busy subway station that killed 32, is awaiting a verdict as the trial nears its conclusion.

## Typhoon Doksuri approaches northern Philippines, thousands evacuate, sea travel disrupted
 - [https://www.foxnews.com/world/typhoon-doksuri-approaches-northern-philippines-thousands-evacuate-sea-travel-disrupted](https://www.foxnews.com/world/typhoon-doksuri-approaches-northern-philippines-thousands-evacuate-sea-travel-disrupted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:29:07+00:00

A powerful typhoon is approaching the northern Philippines, prompting mass evacuations and suspending sea travel due to potential torrential rains and tidal surges.

## Judiciary Chair Jordan tells Mayorkas to 'be prepared' ahead of key hearing on border crisis
 - [https://www.foxnews.com/politics/judiciary-chair-jordan-tells-mayorkas-prepared-ahead-key-hearing-border-crisis](https://www.foxnews.com/politics/judiciary-chair-jordan-tells-mayorkas-prepared-ahead-key-hearing-border-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:26:25+00:00

House Judiciary Chairman Jim Jordan is warning Homeland Security Secretary Alejandro Mayorkas to bring a number of key data points to a hearing on Wednesday.

## Far-right activist Ammon Bundy ordered to pay millions in defamation lawsuit filed by Idaho hospital
 - [https://www.foxnews.com/us/far-right-activist-ammon-bundy-ordered-pay-millions-defamation-lawsuit-filed-idaho-hospital](https://www.foxnews.com/us/far-right-activist-ammon-bundy-ordered-pay-millions-defamation-lawsuit-filed-idaho-hospital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:25:13+00:00

A prominent far-right activist known for leading the takeover of a federal wildlife refuge in Oregon, has been ordered to pay millions in damages following a defamation lawsuit.

## Machete attack outside Sam’s Club in Georgia leaves 1 injured, police say
 - [https://www.foxnews.com/us/machete-attack-outside-sams-club-georgia-leaves-1-injured-police-say](https://www.foxnews.com/us/machete-attack-outside-sams-club-georgia-leaves-1-injured-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:24:22+00:00

Police in Savannah, Georgia, have a person in custody following a machete attack that happened outside a Sam’s Club store, according to reports.

## Trevor Reed, US Marine veteran released by Russia in prisoner swap, injured fighting in Ukraine: State Dept.
 - [https://www.foxnews.com/world/trevor-reed-us-marine-veteran-released-russia-prisoner-swap-injured-fighting-ukraine-state-dept](https://www.foxnews.com/world/trevor-reed-us-marine-veteran-released-russia-prisoner-swap-injured-fighting-ukraine-state-dept)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:23:58+00:00

Marine veteran Trevor Reed, who was detained in Russia and released in a prisoner swap, has been injured while fighting in Ukraine, according to the State Department

## Gas line explosion near Virginia highway causes alarm, no injuries reported
 - [https://www.foxnews.com/us/gas-line-explosion-near-virginia-highway-causes-alarm-injuries-reported](https://www.foxnews.com/us/gas-line-explosion-near-virginia-highway-causes-alarm-injuries-reported)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:23:13+00:00

A gas line explosion occurred near a highway in rural western Virginia on Tuesday, causing alarm but resulting in no injuries, as confirmed by local officials.

## Dodgers’ Mookie Betts says he 'wanted to stay in Boston my whole career'
 - [https://www.foxnews.com/sports/dodgers-mookie-betts-wanted-stay-boston-whole-career](https://www.foxnews.com/sports/dodgers-mookie-betts-wanted-stay-boston-whole-career)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:09:29+00:00

Los Angeles Dodgers All-Star Mookie Betts said he wanted to stay with the Boston Red Sox for his entire career before being traded in 2020.

## 'Full House' stars Jodie Sweetin, Andrea Barber not worried about Dave Coulier's competing podcast
 - [https://www.foxnews.com/entertainment/full-house-stars-jodie-sweetin-andrea-barber-not-worried-about-dave-couliers-competing-podcast](https://www.foxnews.com/entertainment/full-house-stars-jodie-sweetin-andrea-barber-not-worried-about-dave-couliers-competing-podcast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:09:11+00:00

&quot;Full House&quot; stars Jodie Sweetin and Andrea Barber are starting a podcast about the show, just one week after their co-star Dave Coulier released his rewatch podcast.

## Federal judge blocks Biden administration’s asylum policy for migrants
 - [https://www.foxnews.com/politics/federal-judge-blocks-biden-administrations-asylum-policy-migrants](https://www.foxnews.com/politics/federal-judge-blocks-biden-administrations-asylum-policy-migrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:05:51+00:00

A federal judge on Tuesday blocked a key enforcement tool set in place by the Biden administration to limit crossings at the U.S.-Mexico border.

## 'The View' co-host Joy Behar claims Gov. Greg Abbott is a 'sadist'
 - [https://www.foxnews.com/media/the-view-co-host-joy-behar-claims-gov-greg-abbott-sadist](https://www.foxnews.com/media/the-view-co-host-joy-behar-claims-gov-greg-abbott-sadist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:05:05+00:00

ABC&apos;s Joy Behar claimed Republican Texas Gov. Greg Abbott is a &quot;sadist&quot; during &quot;The View&quot; on Tuesday while discussing the state&apos;s border security measures.

## Poland's population shrinks despite returning emigrants, reaches 37.7 million in June: report
 - [https://www.foxnews.com/world/polands-population-shrinks-despite-returning-emigrants-reaches-37-7-million-june-report](https://www.foxnews.com/world/polands-population-shrinks-despite-returning-emigrants-reaches-37-7-million-june-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:03:30+00:00

Poland&apos;s population has experienced another decline, dropping to approximately 37.7 million in June, according to a preliminary report from Statistics Poland.

## Impeach Biden or Mayorkas? What it takes for 'impeachment' proceedings to succeed in the House
 - [https://www.foxnews.com/politics/impeach-biden-mayorkas-what-impeachment-proceedings-succeed-house](https://www.foxnews.com/politics/impeach-biden-mayorkas-what-impeachment-proceedings-succeed-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:03:07+00:00

The strongest case for impeachment appears to be against DHS Secretary Alejandro Mayorkas, but the alleged Hunter Biden scandals could lead to investigations of President Biden himself.

## Toronto police seek public's help in identifying suspects behind million-dollar luxury car heist
 - [https://www.foxnews.com/world/toronto-police-seek-publics-help-identifying-suspects-behind-million-dollar-luxury-car-heist](https://www.foxnews.com/world/toronto-police-seek-publics-help-identifying-suspects-behind-million-dollar-luxury-car-heist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:02:09+00:00

Toronto police are seeking assistance from the public in identifying three suspects involved in a high-value car theft at a dealership in the downtown area on Saturday afternoon.

## Third man sentenced for attempting to smuggle migrants into North Dakota from Canada
 - [https://www.foxnews.com/us/third-man-sentenced-attempting-smuggle-migrants-north-dakota-canada](https://www.foxnews.com/us/third-man-sentenced-attempting-smuggle-migrants-north-dakota-canada)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T14:00:04+00:00

Jose Gonzalez-Resendiz, 41, of New Jersey, has been sentenced to a year-and-a-half in federal prison for attempting to smuggle Mexican migrants into the U.S. across its northern border.

## Family forced to pay to ship body of Marine killed after Pentagon policy change: 'Egregious injustice'
 - [https://www.foxnews.com/us/family-forced-pay-ship-body-marine-killed-after-pentagon-policy-change-egregious-injustice](https://www.foxnews.com/us/family-forced-pay-ship-body-marine-killed-after-pentagon-policy-change-egregious-injustice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:59:05+00:00

Rep. Cory Mills said he learned that the family of Marine Corps Sgt. Nicole L. Gee, who died during the evacuation of Afghanistan, was forced to pay to move her body.

## Bear traps set up around Yellowstone National Park in effort to catch murderous bear that killed a woman
 - [https://www.foxnews.com/us/bear-traps-set-up-around-yellowstone-national-park-effort-catch-murderous-bear-killed-woman](https://www.foxnews.com/us/bear-traps-set-up-around-yellowstone-national-park-effort-catch-murderous-bear-killed-woman)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:53:47+00:00

Bear traps have been set up around Yellowstone National Park to catch a bear that killed a woman. The bear was possibly traveling with cubs at the time of the attack.

## Seattle woman occupies tree scheduled to be cut down for affordable housing units
 - [https://www.foxnews.com/us/seattle-woman-occupies-tree-scheduled-cut-down-affordable-housing-units](https://www.foxnews.com/us/seattle-woman-occupies-tree-scheduled-cut-down-affordable-housing-units)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:49:38+00:00

A Seattle woman is occupying a tree to prevent a developer from chopping it down and building affordable housing in the neighborhood, a report said.

## Wife of Obamas’ chef says her ‘heart is broken’ after husband dies paddleboarding at Martha’s Vineyard
 - [https://www.foxnews.com/us/wife-obamas-chef-says-her-heart-ibroken-husband-dies-paddleboarding-marthas-vineyard](https://www.foxnews.com/us/wife-obamas-chef-says-her-heart-ibroken-husband-dies-paddleboarding-marthas-vineyard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:37:21+00:00

The body of Tafari Campbell, 45, was recovered Monday morning, a day after he disappeared while paddleboarding on a pond in Martha&apos;s Vineyard.

## Colombia won their first game of Women's World Cup without head coach Nelson Abadía due to suspension
 - [https://www.foxnews.com/sports/colombia-won-first-game-womens-world-cup-without-head-coach-nelson-abadia-suspension](https://www.foxnews.com/sports/colombia-won-first-game-womens-world-cup-without-head-coach-nelson-abadia-suspension)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:36:49+00:00

Colombia&apos;s head coach Nelson Abadía served the first game of his two-game suspension in Colombia&apos;s win over South Korea due to receiving a red card for arguing with an official.

## Make the most of your summer with these 6 must-have apps
 - [https://www.foxnews.com/tech/make-most-summer-these-6-must-have-apps](https://www.foxnews.com/tech/make-most-summer-these-6-must-have-apps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:36:05+00:00

Choosing the right apps on your phone may be a difficult decision. Kurt &quot;CyberGuy&quot; Knutsson shares six must-have apps that every person should download.

## Drew Barrymore set to host 74th annual National Book Awards in New York City
 - [https://www.foxnews.com/entertainment/drew-barrymore-host-74th-annual-national-book-awards-new-york-city](https://www.foxnews.com/entertainment/drew-barrymore-host-74th-annual-national-book-awards-new-york-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:31:41+00:00

The 74th annual National Book Awards is set to take place in New York City on Nov. 15, 2023. The ceremony will be hosted by Drew Barrymore, and Oprah Winfrey will be a guest speaker.

## London mayor's 'Mate' campaign encouraging men to challenge sexist language scorched by critics
 - [https://www.foxnews.com/media/london-mayors-mate-campaign-encouraging-men-challenge-sexist-language-scorched-critics](https://www.foxnews.com/media/london-mayors-mate-campaign-encouraging-men-challenge-sexist-language-scorched-critics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:30:17+00:00

Sadiq Khan, the mayor of London, is facing mockery on Twitter after he flacked for a campaign targeted against &quot;sexist and misogynistic language&quot; in society.

## The must-try iPhone shortcut to help you remember everything
 - [https://www.foxnews.com/tech/must-try-iphone-shortcut-help-remember-everything](https://www.foxnews.com/tech/must-try-iphone-shortcut-help-remember-everything)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:29:30+00:00

Apple&apos;s &quot;Remember This&quot; shortcut helps you to keep a tracking of everything you do on a daily basis in order to prevent you from forgetting things to do.

## FBI investigates death of intellectually disabled VA prison inmate, identified as 'possible victim of a crime'
 - [https://www.foxnews.com/us/fbi-investigates-death-intellectually-disabled-prison-inmate-identified-possible-victim-crime](https://www.foxnews.com/us/fbi-investigates-death-intellectually-disabled-prison-inmate-identified-possible-victim-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:27:51+00:00

The 2022 death of Charles Givens, an intellectually disabled prison inmate, is being investigated by the FBI. He was identified as &quot;a possible victim of a crime.&quot;

## Suspended Nigerian Central Bank governor appears in court, pleads not guilty to firearm charges
 - [https://www.foxnews.com/world/suspended-nigerian-central-bank-governor-appears-court-pleads-guilty-firearm-charges](https://www.foxnews.com/world/suspended-nigerian-central-bank-governor-appears-court-pleads-guilty-firearm-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:17:14+00:00

Suspended Nigerian Central Bank governor, Godwin Emefiele, made a public appearance in a Lagos court on Tuesday to face charges of illegal possession of a firearm and live ammunition.

## Suicide bomber kills police officer inside mosque near Pakistan-Afghanistan border
 - [https://www.foxnews.com/world/suicide-bomber-kills-police-officer-mosque-near-pakistan-afghanistan-border](https://www.foxnews.com/world/suicide-bomber-kills-police-officer-mosque-near-pakistan-afghanistan-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:15:53+00:00

In northwestern Pakistan, near the border with Afghanistan, a tragic incident unfolded on Tuesday when a suicide bomber detonated explosives inside a roadside mosque.

## UN accuses Russia of 'escalation,' possible war crimes over destruction of Ukrainian cultural sites
 - [https://www.foxnews.com/world/un-accuses-russia-escalation-possible-war-crimes-destruction-ukrainian-cultural-sites](https://www.foxnews.com/world/un-accuses-russia-escalation-possible-war-crimes-destruction-ukrainian-cultural-sites)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:13:59+00:00

U.N.&apos;s Educational, Scientific and Cultural Organization is proposing that Russia may have committed a war crime by firing missiles into historic areas of the Ukrainian city of Odesa.

## Colorado reports its first West Nile virus case in humans this year
 - [https://www.foxnews.com/health/colorado-reports-its-first-west-nile-virus-case-humans-this-year](https://www.foxnews.com/health/colorado-reports-its-first-west-nile-virus-case-humans-this-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:04:43+00:00

Health officials in Colorado reported the first confirmed human case of West Nile virus on Monday after additional human cases were announced in California and Texas.

## Justice Department 'weaponized' bipartisan gun safety law to 'illegally fund' red flag laws, Republicans say
 - [https://www.foxnews.com/politics/justice-department-weaponized-bipartisan-gun-safety-law-illegally-fund-red-flag-laws-republicans-say](https://www.foxnews.com/politics/justice-department-weaponized-bipartisan-gun-safety-law-illegally-fund-red-flag-laws-republicans-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:02:58+00:00

Republicans are accusing the Biden administration&apos;s Justice Department of illegally using the Bipartisan Safer Communities Act to push states to adopt red flag laws.

## Violent clash in West Bank: 3 Palestinian gunmen killed amidst escalating Israeli-Palestinian conflict
 - [https://www.foxnews.com/world/violent-clash-west-bank-3-palestinian-gunmen-killed-amidst-escalating-israeli-palestinian-conflict](https://www.foxnews.com/world/violent-clash-west-bank-3-palestinian-gunmen-killed-amidst-escalating-israeli-palestinian-conflict)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:02:54+00:00

The Israeli military reported that they fatally shot three Palestinian gunmen in occupied West Bank on Tuesday, adding to the escalating violence in the Israeli-Palestinian conflict.

## BTK serial killer's daughter compares Gilgo Beach killer suspect to father: 'Very similar'
 - [https://www.foxnews.com/media/btk-serial-killers-daughter-compares-gilgo-beach-killer-suspect-father-very-similar](https://www.foxnews.com/media/btk-serial-killers-daughter-compares-gilgo-beach-killer-suspect-father-very-similar)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:01:14+00:00

The daughter of the BTK serial killer Kerri Rawson detailed how her father&apos;s case was &apos;very similar&apos; to the profile of suspected Gilgo Beach killer Rex Heuermann.

## A translator for your kids: How using AI as a 'parenting co-pilot' will help parents communicate better
 - [https://www.foxnews.com/us/translator-kids-using-ai-parenting-co-pilot-help-parents-communicate-better](https://www.foxnews.com/us/translator-kids-using-ai-parenting-co-pilot-help-parents-communicate-better)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:00:59+00:00

With ChatGPT and other artificial intelligence tools, mom and dad can now access massive amounts of parenting knowledge at their fingertips.

## Life sentence for South Dakota man who fatally shot 3 people, including 5-year-old girl
 - [https://www.foxnews.com/us/life-sentence-south-dakota-man-fatally-shot-3-people-including-5-year-old-girl](https://www.foxnews.com/us/life-sentence-south-dakota-man-fatally-shot-3-people-including-5-year-old-girl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T13:00:50+00:00

A South Dakota man has been sentenced to life in prison after killing three people and injuring two others, including a 5-year-old girl. He pleaded guilty but mentally ill.

## Mexican man charged in fatal border bar fire that killed 11
 - [https://www.foxnews.com/world/mexican-man-charged-fatal-border-bar-fire-killed-11](https://www.foxnews.com/world/mexican-man-charged-fatal-border-bar-fire-killed-11)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:59:12+00:00

Prosecutors in Mexico announced that a man will stand trial for allegedly causing a devastating fire at a bar near the border, in the city of San Luis Rio Colorado.

## US, South Korea to hold 1st-ever training in California after North detains American soldier
 - [https://www.foxnews.com/world/us-south-korea-hold-1st-training-california-north-detains-american-soldier](https://www.foxnews.com/world/us-south-korea-hold-1st-training-california-north-detains-american-soldier)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:56:21+00:00

South Korea&apos;s marine corps will conduct joint military exercises alongside U.S. Marines in California for the first time amid heightened tensions with North Korea.

## Woman inspired by hit TV show arrested after allegedly hiring snake charmer to kill her boyfriend
 - [https://www.foxnews.com/world/woman-arrested-after-allegedly-hiring-snake-charmer-kill-her-boyfriend](https://www.foxnews.com/world/woman-arrested-after-allegedly-hiring-snake-charmer-kill-her-boyfriend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:49:52+00:00

A woman in India is suspected of having hired the help of a snake charmer to bite and poison her boyfriend so that she could start a new life with her current lover.

## Tuberculosis at the border: Doctors issue warnings of ‘drug-resistant strains’
 - [https://www.foxnews.com/health/tuberculosis-border-doctors-issue-warnings-drug-resistant-strains](https://www.foxnews.com/health/tuberculosis-border-doctors-issue-warnings-drug-resistant-strains)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:47:13+00:00

Cases of tuberculosis, which kills more people than any other infectious disease, rose in the U.S. during 2022 — and some doctors are concerned that limitations of testing at the border could be partly to blame.

## House to consider bipartisan bill to crack down on Chinese opioid manufacturers
 - [https://www.foxnews.com/politics/house-consider-bipartisan-bill-cracking-down-chinese-opioid-manufacturers](https://www.foxnews.com/politics/house-consider-bipartisan-bill-cracking-down-chinese-opioid-manufacturers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:46:35+00:00

Republican Rep. Andy Barr&apos;s bipartisan bill to crack down on Chinese opioid manufacturers is expected to get a hearing on the House floor this week.

## Famous author predicted America's current crises, plus woman has odd medical scare
 - [https://www.foxnews.com/lifestyle/famous-author-predicted-americas-current-crises-plus-woman-odd-medical-scare](https://www.foxnews.com/lifestyle/famous-author-predicted-americas-current-crises-plus-woman-odd-medical-scare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:44:06+00:00

The Fox News Lifestyle Newsletter brings you trending stories on family, travel, food, neighbors helping neighbors, pets, autos, military veterans, heroes, faith and American values.

## Woman plunges to death from 100-foot cliff after marriage proposal mishap
 - [https://www.foxnews.com/world/woman-plunges-death-100-foot-cliff-marriage-proposal-mishap](https://www.foxnews.com/world/woman-plunges-death-100-foot-cliff-marriage-proposal-mishap)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:43:44+00:00

Yesim Demir&apos;s fiance Nizamettin Gursu said he picked out the romantic cliffside view for the sunset, and he had gone back to his car for picnic supplies when he heard a scream.

## Switzerland and Norway draw, leaving Group A in the Women's World Cup up for grabs
 - [https://www.foxnews.com/sports/switzerland-and-norway-draw-leaving-group-a-womens-world-cup](https://www.foxnews.com/sports/switzerland-and-norway-draw-leaving-group-a-womens-world-cup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:41:20+00:00

Norway and Switzerland drew in 0-0 game on Tuesday at the Women&apos;s World Cup leaving Group A up for grabs as all four teams in the group have registered a point.

## Cancer survivor Linda Caicedo scores goal in Colombia's win over South Korea in Women's World Cup
 - [https://www.foxnews.com/sports/cancer-survivor-linda-caicedo-scores-goal-colombias-win-south-korea-womens-world-cup](https://www.foxnews.com/sports/cancer-survivor-linda-caicedo-scores-goal-colombias-win-south-korea-womens-world-cup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:40:23+00:00

Colombia star Linda Caicedo scored a goal in the squad&apos;s 2-0 win over South Korea on Tuesday in the Women&apos;s World Cup as she continues to be an inspiration for many.

## 'All My Children' actress Pamela Blair dead at 73
 - [https://www.foxnews.com/entertainment/all-my-children-actress-pamela-blair-dead-73](https://www.foxnews.com/entertainment/all-my-children-actress-pamela-blair-dead-73)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:36:36+00:00

Pamela Blair, known for her roles in &quot;A Chorus Line&quot; and on &quot;All My Children,&quot; has died at the age of 73, Fox News Digital confirmed.

## Washington police find 2 teens fatally shot after being called to home to investigate suspicious circumstances
 - [https://www.foxnews.com/us/washington-police-find-2-teens-fatally-shot-being-called-home-investigate-suspicious-circumstances](https://www.foxnews.com/us/washington-police-find-2-teens-fatally-shot-being-called-home-investigate-suspicious-circumstances)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:33:54+00:00

Yakima police found two teens fatally shot at a home in central Washington state. The teens were described as being of high school age.

## Attorney creepily 'winks' at camera in secret sex tapes with woman he was prosecuting: court docs
 - [https://www.foxnews.com/us/attorney-creepily-winks-camera-secret-sex-tapes-woman-he-was-prosecuting-court-docs](https://www.foxnews.com/us/attorney-creepily-winks-camera-secret-sex-tapes-woman-he-was-prosecuting-court-docs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:32:31+00:00

A disgraced Wisconsin prosecutor &quot;winked several times&quot; during a secret recording of his sexual relations with a woman he was prosecuting, court records show.

## Dozen of Washington state counties declare drought emergency due to early snowmelt, lack of spring rain
 - [https://www.foxnews.com/weather/dozen-washington-state-counties-declare-drought-emergency-early-snowmelt-lack-spring-rain](https://www.foxnews.com/weather/dozen-washington-state-counties-declare-drought-emergency-early-snowmelt-lack-spring-rain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:30:30+00:00

A dozen counties across Washington state declared a drought emergency. The drought was caused by early snowmelt and a lack of spring rain.

## Ex-NYC gynecologist convicted of ‘unchecked, out-of-control’ patient sexual abuse awaits 20-year sentence
 - [https://www.foxnews.com/us/ex-nyc-gynecologist-convicted-unchecked-control-patient-sexual-abuse-awaits-20-year-sentence](https://www.foxnews.com/us/ex-nyc-gynecologist-convicted-unchecked-control-patient-sexual-abuse-awaits-20-year-sentence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:30:20+00:00

A federal judge is expected to sentence former New York City gynecologist Robert Hadden to 20 years behind bars for sexually abusing dozens of patients.

## Former USC dean sentenced to 1 1/2 years of home confinement for bribing LA County supervisor
 - [https://www.foxnews.com/us/former-usc-dean-sentenced-1-1-2-years-home-confinement-bribing-la-county-supervisor](https://www.foxnews.com/us/former-usc-dean-sentenced-1-1-2-years-home-confinement-bribing-la-county-supervisor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:29:54+00:00

Marilyn Flynn, the former dean of USC&apos;s School of Social Work, was sentenced to over a year of home confinement for bribing a Los Angeles County official in exchange for a new contract.

## Reporter comes under fire for asking Morocco captain ‘inappropriate’ question about teammates’ sexuality
 - [https://www.foxnews.com/sports/reporter-comes-under-fire-asking-morocco-captain-inappropriate-question-about-teammates-sexuality](https://www.foxnews.com/sports/reporter-comes-under-fire-asking-morocco-captain-inappropriate-question-about-teammates-sexuality)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:25:55+00:00

The BBC issued an apology after a reporter asked Morocco captain Ghizlane Chebbak about the her teammates&apos; sexuality as it relates to the country’s laws against same-sex relationships.

## Deer take refuge from Washington wildfires at base of massive turbines as blaze expands
 - [https://www.foxnews.com/us/deer-take-refuge-washington-wildfires-base-massive-turbines-blaze-expands](https://www.foxnews.com/us/deer-take-refuge-washington-wildfires-base-massive-turbines-blaze-expands)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:22:29+00:00

Wildfires are continuing to tear through Washington as dry conditions and wind persists. Deer on state lands are taking refuge on the gravel pads under the state&apos;s wind turbines.

## Temple U to host Philly 'FatCon' with queer sex therapist offering 'fat positive sexual healthcare'
 - [https://www.foxnews.com/media/temple-u-host-philly-fatcon-queer-sex-therapist-offering-fat-positive-sexual-healthcare](https://www.foxnews.com/media/temple-u-host-philly-fatcon-queer-sex-therapist-offering-fat-positive-sexual-healthcare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:19:47+00:00

Temple University is set to host a &quot;FatCon&quot; for plus-sized attendees this October, featuring keynote speaker &quot;Fat Sex Therapist&quot; Sonalee Rashatwar.

## Gilgo Beach search warrant announcement outside suspect Rex Heuermann's house
 - [https://www.foxnews.com/us/gilgo-beach-search-warrant-announcement-outside-suspect-rex-heuermann-house](https://www.foxnews.com/us/gilgo-beach-search-warrant-announcement-outside-suspect-rex-heuermann-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:05:10+00:00

Suffolk County District Attorney Ray Tierney visiting the home of suspected Gilgo Beach serial killer in Nassau County, where police executed a search warrant.

## Pro-life activist praises GOP's child tax credit plan as an answer to abortion rhetoric: 'Women's empowerment'
 - [https://www.foxnews.com/media/pro-life-activist-praises-gop-child-tax-credit-plan-answer-abortion-rhetoric-women-empowerment](https://www.foxnews.com/media/pro-life-activist-praises-gop-child-tax-credit-plan-answer-abortion-rhetoric-women-empowerment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:00:21+00:00

Pro-life activist Ryan Bomberger discussed Republicans&apos; efforts to revamp the family care system during his appearance on &apos;Fox &amp; Friends&apos; Tuesday.

## GOP bill lets Americans sue 'malicious' federal workers who conspire to censor social media posts
 - [https://www.foxnews.com/politics/gop-americans-sue-federal-workers-conspire-censor-social-media-posts](https://www.foxnews.com/politics/gop-americans-sue-federal-workers-conspire-censor-social-media-posts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T12:00:19+00:00

House Republicans are rolling out a new bill to let Americans sue federal employees for alleged censorship, including on social media

## Putin achieved Ukraine 'red line,' now aims to create 'as much suffering as possible' with grain strikes
 - [https://www.foxnews.com/world/putin-achieved-ukraine-red-line-aims-create-suffering-possible-grain-strikes](https://www.foxnews.com/world/putin-achieved-ukraine-red-line-aims-create-suffering-possible-grain-strikes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:54:33+00:00

Russian President Vladimir Putin appears intent on pressuring Western officials through rising food prices to drop their support of Ukraine and end sanctions on Russia.

## Biden's dog Commander terrorizes Secret Service in 'extremely aggressive' rampage: emails
 - [https://www.foxnews.com/politics/bidens-dog-commander-terrorizes-secret-service-extremely-aggressive-rampage-emails](https://www.foxnews.com/politics/bidens-dog-commander-terrorizes-secret-service-extremely-aggressive-rampage-emails)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:49:47+00:00

President Biden&apos;s dog Commander – the nearly two and a half year old German shepherd – bit seven people in a four-month period after replacing former first dog Major for similar behavior.

## Philippines stun New Zealand to notch first ever Women's World Cup victory
 - [https://www.foxnews.com/sports/philippines-stun-new-zealand-notch-first-ever-womens-world-cup-victory](https://www.foxnews.com/sports/philippines-stun-new-zealand-notch-first-ever-womens-world-cup-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:45:31+00:00

The Philippines made history in their stunning upset over New Zealand scoring their first-ever Women&apos;s World Cup goal and winning their first ever Women&apos;s World Cup game.

## Bald eagle rescued from New Jersey electrical tower after its wing was stuck for five hours
 - [https://www.foxnews.com/lifestyle/bald-eagle-rescued-new-jersey-electrical-tower-wing-stuck-five-hours](https://www.foxnews.com/lifestyle/bald-eagle-rescued-new-jersey-electrical-tower-wing-stuck-five-hours)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:44:21+00:00

A bald eagle was rescued five hours after getting it&apos;s left wing stuck in an ice shield on a public safety communications tower in Monmouth County, New Jersey.

## Zambia is already on their third-string goalkeeper of Women's World Cup despite only playing one game
 - [https://www.foxnews.com/sports/zambia-already-third-string-goalkeeper-womens-world-cup-despite-one-game](https://www.foxnews.com/sports/zambia-already-third-string-goalkeeper-womens-world-cup-despite-one-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:44:07+00:00

Zambia is already down to their third goalie in the Women&apos;s World Cup after their first goalie tore ACL days before the tournament started and the second one got disqualified.

## Retired pastor kidnapped, killed another pastor's young daughter on walk to Bible camp: DA
 - [https://www.foxnews.com/us/retired-pastor-kidnapped-killed-another-pastors-young-daughter-walk-bible-camp-da](https://www.foxnews.com/us/retired-pastor-kidnapped-killed-another-pastors-young-daughter-walk-bible-camp-da)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:43:40+00:00

David Zandstra, 83, of Marietta, Georgia, is charged with murder and kidnapping in connection with the 1975 disappearance and death of 8-year-old Gretchen Harrington.

## Brewers edge Reds in NL Central showdown with Christian Yelich's walk-off single
 - [https://www.foxnews.com/sports/brewers-edge-reds-nl-central-showdown-christian-yelichs-walk-off-single](https://www.foxnews.com/sports/brewers-edge-reds-nl-central-showdown-christian-yelichs-walk-off-single)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:42:15+00:00

The Milwaukee Brewers walked-off the Cincinnati Reds 3-2 on Monday to start a pivotal NL Central showdown behind Christian Yelich&apos;s walk-off single.

## Aces' forward Candace Parker underwent successful surgery on fracture in left foot
 - [https://www.foxnews.com/sports/aces-forward-candace-parker-underwent-successful-surgery-fracture-left-foot](https://www.foxnews.com/sports/aces-forward-candace-parker-underwent-successful-surgery-fracture-left-foot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:38:00+00:00

Las Vegas Aces announced on Monday that former MVP Candace Parker underwent successful surgery on a fracture in her left foot that she had been playing on all season.

## Twins take down Mariners for second straight extra-innings win behind Carlos Correa RBI single
 - [https://www.foxnews.com/sports/twins-take-down-mariners-second-straight-extra-innings-win-carlos-correa-rbi-single](https://www.foxnews.com/sports/twins-take-down-mariners-second-straight-extra-innings-win-carlos-correa-rbi-single)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:36:23+00:00

The Minnesota Twins continued their winning ways on Monday with a 4-3 victory over the Seattle Mariners as Carlos Correa walked-off the Mariners with an RBI single in the 10th inning.

## Country music is the new Bud Light, Harry & Meghan are box office poison and more Fox News Opinion
 - [https://www.foxnews.com/opinion/country-music-new-bud-light-harry-meghan-box-office-poison](https://www.foxnews.com/opinion/country-music-new-bud-light-harry-meghan-box-office-poison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:36:20+00:00

Read the latest Fox News Opinion columns and watch videos from Jesse Watters, Sean Hannity, Greg Gutfeld, Laura Ingraham and more.

## 'Jeopardy!' host Ken Jennings joins fans in disbelief as contestants fail to answer seemingly easy clue
 - [https://www.foxnews.com/entertainment/jeopardy-host-ken-jennings-joins-fans-disbelief-contestants-fail-answer-seemingly-easy-clue](https://www.foxnews.com/entertainment/jeopardy-host-ken-jennings-joins-fans-disbelief-contestants-fail-answer-seemingly-easy-clue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:33:59+00:00

&quot;Jeopardy!&quot; fans are often critical of contestants, but this time host Ken Jennings also seemed surprised when no one was able to answer a clue correctly.

## Royals' Salvador Perez hits 200th career home run in win over Guardians
 - [https://www.foxnews.com/sports/royals-salvador-perez-hits-200th-career-home-run-win-guardians](https://www.foxnews.com/sports/royals-salvador-perez-hits-200th-career-home-run-win-guardians)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:26:17+00:00

The Kansas City Royals beat the Cleveland Guardians 5-3 on Monday night as catcher Salvador Perez hit his 200th career home run in the victory.

## Jason Aldean reiterates love for America, Jackie Kennedy allegedly didn't enjoy Warren Beatty in the bedroom
 - [https://www.foxnews.com/entertainment/jason-aldean-reiterates-love-america-jackie-kennedy-allegedly-didnt-enjoy-warren-beatty-bedroom](https://www.foxnews.com/entertainment/jason-aldean-reiterates-love-america-jackie-kennedy-allegedly-didnt-enjoy-warren-beatty-bedroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:26:03+00:00

The Fox News Entertainment newsletter brings you the latest Hollywood headlines, celebrity interviews and stories from Los Angeles and beyond.

## Biden supporters disagree with president's refusal to acknowledge 7th grandkid: 'A bit hypocritical'
 - [https://www.foxnews.com/media/biden-supporters-disagree-presidents-refusal-acknowledge-7th-grandkid-bit-hypocritical](https://www.foxnews.com/media/biden-supporters-disagree-presidents-refusal-acknowledge-7th-grandkid-bit-hypocritical)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:22:17+00:00

Biden supporters from Philadelphia appear to disagree with the president&apos;s refusal to acknowledge his 7th grandchild, calling the situation a &quot;bit hypocritical.&quot;

## Ex-NYPD commissioner pardoned by Trump agrees to deal with Special Counsel Jack Smith in 2020 election probe
 - [https://www.foxnews.com/politics/ex-nypd-commissioner-pardoned-trump-agrees-deal-special-counsel-jack-smith-2020-election-probe](https://www.foxnews.com/politics/ex-nypd-commissioner-pardoned-trump-agrees-deal-special-counsel-jack-smith-2020-election-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:19:44+00:00

Former NYPD Commissioner Bernard Kerik&apos;s attorney reportedly said he handed over thousands of pages to Special Counsel Jack Smith related to former President Trump.

## 11 dead after middle school gym roof collapses onto volleyball practice in China, arrests made
 - [https://www.foxnews.com/world/11-dead-middle-school-gym-roof-collapses-volleyball-practice-china-arrests-made](https://www.foxnews.com/world/11-dead-middle-school-gym-roof-collapses-volleyball-practice-china-arrests-made)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:12:51+00:00

Eleven people are dead in China after a roof collapsed onto a female volleyball team during practice in an incident authorities say could have been a result of negligence.

## What a popular Republican governor in a key primary state wants to hear from the GOP presidential candidates
 - [https://www.foxnews.com/politics/what-popular-republican-governor-key-primary-state-wants-hear-from-gop-presidential-candidates](https://www.foxnews.com/politics/what-popular-republican-governor-key-primary-state-wants-hear-from-gop-presidential-candidates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:11:10+00:00

Fox News learns that Republican New Hampshire Gov. Chris Sununu will team up with the 2024 presidential candidates Friday at the Iowa GOP&apos;s annual fundraising gala.

## LeBron James' son, Bronny, suffers 'cardiac arrest,' family spokesperson says
 - [https://www.foxnews.com/sports/lebron-james-son-bronny-suffers-cardiac-arrest-family-spokesperson-says](https://www.foxnews.com/sports/lebron-james-son-bronny-suffers-cardiac-arrest-family-spokesperson-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:01:18+00:00

Bronny James, son of LeBron James, &quot;suffered a cardiac arrest&quot; on Monday, according to a family spokesperson. Bronny committed to USC in May.

## Hillary Clinton blames 'MAGA Republicans' for making it hot outside
 - [https://www.foxnews.com/politics/hillary-clinton-blames-maga-republicans-making-hot-outside](https://www.foxnews.com/politics/hillary-clinton-blames-maga-republicans-making-hot-outside)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:00:30+00:00

Former Secretary of State Hillary Clinton is blaming Republicans for the recent hot weather, pointing to their votes against the Inflation Reduction Act, which still passed.

## Minnesota small businesses bracing for cost of billion-dollar paid leave law: 'It's just crazy'
 - [https://www.foxnews.com/media/minnesota-small-businesses-bracing-cost-billion-dollar-paid-leave-law-crazy](https://www.foxnews.com/media/minnesota-small-businesses-bracing-cost-billion-dollar-paid-leave-law-crazy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T11:00:05+00:00

Small business owners in Minnesota are worried they might have to close their doors over cost concerns once a new billion-dollar paid leave takes effect in 2026.

## New Mexico wildfire started by Forest Service prescribed burn, agency says
 - [https://www.foxnews.com/us/new-mexico-wildfire-started-forest-service-prescribed-burn-agency-says](https://www.foxnews.com/us/new-mexico-wildfire-started-forest-service-prescribed-burn-agency-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:57:35+00:00

New Mexico lawmakers reacted on social media after the U.S. Forest Service found in a probe that its own prescribed burn started a wildfire last April that forced evacuation orders.

## Minnesota deputy escapes with 'minor injuries' after vehicle crash leaves police vehicle in flames: video
 - [https://www.foxnews.com/us/minnesota-deputy-escapes-with-minor-injuries-after-vehicle-crash-leaves-police-vehicle-flames-video](https://www.foxnews.com/us/minnesota-deputy-escapes-with-minor-injuries-after-vehicle-crash-leaves-police-vehicle-flames-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:52:13+00:00

A video captured a fire engulfing a Crow Wing County Sheriff’s Office police vehicle in Minnesota following a highway crash.

## MI Supreme Court expands parental rights for same-sex partners
 - [https://www.foxnews.com/politics/mi-supreme-court-expands-parental-rights-same-sex-partners](https://www.foxnews.com/politics/mi-supreme-court-expands-parental-rights-same-sex-partners)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:34:57+00:00

Parental rights are being expanded for same-sex partners in Michigan following a decision on July 24, 2023, by the state&apos;s Supreme Court.

## USC's Lincoln Riley gives Deion Sanders 'credit' for roster overhaul at Colorado
 - [https://www.foxnews.com/sports/uscs-lincoln-riley-deion-sanders-credit-roster-overhaul-colorado](https://www.foxnews.com/sports/uscs-lincoln-riley-deion-sanders-credit-roster-overhaul-colorado)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:33:15+00:00

USC head coach Lincoln Riley praised Colorado head coach Deion Sanders at Pac-12 Media Days, saying he gives the coaching staff credit for the roster overhaul.

## Former Wisconsin prosecutor sentenced to 18 months for secretly recording sexual encounters with 2 women
 - [https://www.foxnews.com/us/former-wisconsin-prosecutor-sentenced-18-months-secretly-recording-sexual-encounters-2-women](https://www.foxnews.com/us/former-wisconsin-prosecutor-sentenced-18-months-secretly-recording-sexual-encounters-2-women)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:31:45+00:00

Daniel Steffen, a former Wisconsin prosecutor, was sentenced to 18 months in prison for secretly recording sexual encounters with two women.

## Florida burglar thwarted by elderly homeowner who held him at gunpoint: cops
 - [https://www.foxnews.com/us/florida-burglar-thwarted-elderly-homeowner-held-him-gunpoint-cops](https://www.foxnews.com/us/florida-burglar-thwarted-elderly-homeowner-held-him-gunpoint-cops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:29:11+00:00

A Neptune Beach, Florida, homeowner turned the tables on suspect Antonio Grant after he allegedly broke into his house. The homeowner held Grant at gunpoint until police arrived.

## Shooting at Florida bar during party leaves 5 wounded, no arrests
 - [https://www.foxnews.com/us/shooting-florida-bar-party-leaves-5-wounded-no-arrests](https://www.foxnews.com/us/shooting-florida-bar-party-leaves-5-wounded-no-arrests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:25:11+00:00

Five victims suffered non-life-threatening gunshot wounds when at least one suspect opened fire at a bar in Tampa, Florida, over the weekend.

## News crew in San Francisco watches live as man brazenly steals from a Walgreens: 'Did that guy pay?'
 - [https://www.foxnews.com/media/reporter-san-francisco-watches-live-man-brazenly-steals-from-walgreens-did-guy-pay](https://www.foxnews.com/media/reporter-san-francisco-watches-live-man-brazenly-steals-from-walgreens-did-guy-pay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:06:35+00:00

A team of CNN reporters witnessed three thefts within a thirty-minute span while visiting a San Francisco Walgreens to cover the city&apos;s rise in crime.

## Air Force restarts bonuses less than 2 weeks after saying it was too low on cash
 - [https://www.foxnews.com/us/air-force-restarts-bonuses-less-than-two-weeks-after-saying-low-cash](https://www.foxnews.com/us/air-force-restarts-bonuses-less-than-two-weeks-after-saying-low-cash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:01:41+00:00

The Air Force is restarting bonuses and some personnel change-of-station moves, receiving additional funding and reversing the pause that was announced earlier this month.

## Republican sounds alarm on ‘militarization’ of IRS after it spent $10M on weapons, gear since 2020
 - [https://www.foxnews.com/politics/republican-militarization-irs-10-million-weapons-gear](https://www.foxnews.com/politics/republican-militarization-irs-10-million-weapons-gear)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:00:46+00:00

Rep. Stephanie Bice is demanding a full accounting of weapons and gear owned by the IRS after a report claimed the agency spent nearly $10 million on it since 2020.

## Harry and Meghan, once Tinseltown darlings, have become box office poison
 - [https://www.foxnews.com/opinion/harry-meghan-once-tinseltown-darlings-become-box-office-poison](https://www.foxnews.com/opinion/harry-meghan-once-tinseltown-darlings-become-box-office-poison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:00:06+00:00

Prince Harry and Meghan Markle seem to be in a downward spiral, sustaining blow after devastating blow in recent months. It couldn’t happen to a nicer couple.

## Twitter users roast Elon Musk's 'boring' platform rebrand to X: 'Sounds like a midlife crisis'
 - [https://www.foxnews.com/media/twitter-users-roast-elon-musks-boring-platform-rebrand-x-sounds-like-midlife-crisis](https://www.foxnews.com/media/twitter-users-roast-elon-musks-boring-platform-rebrand-x-sounds-like-midlife-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T10:00:01+00:00

Americans in the Big Apple revealed their thoughts on Elon Musk rebranding Twitter to &quot;X.&quot; Musk announced tweeted about the rebrand Sunday, just ahead of the change.

## Breastfeeding ban: Georgia mother is told she can’t nurse her baby at waterpark, sparking debate
 - [https://www.foxnews.com/health/breastfeeding-ban-georgia-mother-told-cant-nurse-baby-waterpark-sparking-debate](https://www.foxnews.com/health/breastfeeding-ban-georgia-mother-told-cant-nurse-baby-waterpark-sparking-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:54:20+00:00

A Georgia mother who was recently asked to leave a waterpark because she was breastfeeding her 11-month-old son shared her story with Fox News Digital. Experts shared insights.

## Disney star Raven-Symoné declares she has psychic abilities like famous character
 - [https://www.foxnews.com/entertainment/disney-star-raven-symone-declares-psychic-abilities-like-famous-character](https://www.foxnews.com/entertainment/disney-star-raven-symone-declares-psychic-abilities-like-famous-character)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:49:46+00:00

Raven-Symoné shared on her podcast that, similar to her character Raven Baxter from &quot;That&apos;s So Raven,&quot; she has her own visions into the future.

## Mayor assassinated in broad daylight as violent crime surges in South American nation
 - [https://www.foxnews.com/world/mayor-assassinated-in-broad-daylight-violent-crime-surges-south-american-nation](https://www.foxnews.com/world/mayor-assassinated-in-broad-daylight-violent-crime-surges-south-american-nation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:43:36+00:00

The 38-year-old mayor of an Ecuadorian town was assassinated over the weekend, and authorities say the gunman was able to escape but his driver was captured.

## North Korea issues rare invitation to Russian, Chinese delegations for anniversary of Korean War armistice
 - [https://www.foxnews.com/world/north-korea-issues-rare-invitation-russian-chinese-delegations-anniversary-korean-war-armistice](https://www.foxnews.com/world/north-korea-issues-rare-invitation-russian-chinese-delegations-anniversary-korean-war-armistice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:39:37+00:00

North Korea has issued a rare invitation for Russian and Chinese delegations to visit the hermit kingdom for the 70th anniversary of the Korean War&apos;s Armistice Day.

## Arizona man accused of killing his father, dismembering body; mother allegedly helped conceal evidence
 - [https://www.foxnews.com/us/arizona-man-accused-killing-father-dismembering-body-mother-allegedly-helped-conceal-evidence](https://www.foxnews.com/us/arizona-man-accused-killing-father-dismembering-body-mother-allegedly-helped-conceal-evidence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:34:36+00:00

Christopher Chase, 32, turned himself over to police in Casa Grande, Arizona, after allegedly setting his father&apos;s dismembered corpse on fire in a barrel.

## Rookie QBs CJ Stroud, Anthony Richardson both agree to fully guaranteed contracts on eve of training camp
 - [https://www.foxnews.com/sports/rookie-qbs-cj-stroud-anthony-richardson-both-agree-fully-guaranteed-contracts-eve-training-camp](https://www.foxnews.com/sports/rookie-qbs-cj-stroud-anthony-richardson-both-agree-fully-guaranteed-contracts-eve-training-camp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:33:14+00:00

Houston Texans rookie quarterback CJ Stroud and Indianapolis Colts rookie quarterback Anthony Richardson both agreed to fully guaranteed contracts on the eve of training camp.

## Former military pilot, permafrost expert among those killed in Alaskan helicopter crash
 - [https://www.foxnews.com/us/former-military-pilot-permafrost-expert-among-killed-alaskan-helicopter-crash](https://www.foxnews.com/us/former-military-pilot-permafrost-expert-among-killed-alaskan-helicopter-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:18:30+00:00

A permafrost expert and former military pilot were two of the four people who died in an Alaskan helicopter crash last week. The group was in a 1996 Bell 206 helicopter.

## Former North Carolina GOP Sen. Deanna Ballard announces candidacy for lieutenant governor
 - [https://www.foxnews.com/politics/former-north-carolina-gop-sen-deanna-ballard-announces-candidacy-lieutenant-governor](https://www.foxnews.com/politics/former-north-carolina-gop-sen-deanna-ballard-announces-candidacy-lieutenant-governor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:14:26+00:00

Former North Carolina state Sen. Deanna Ballard has announced her candidacy for lieutenant governor. Ballard served six years in the state Senate.

## NFL MVP Cam Newton performs lewd gesture as he zings heckling fans at football camp
 - [https://www.foxnews.com/sports/nfl-mvp-cam-newton-performs-lewd-gesture-zings-heckling-fans-football-camp](https://www.foxnews.com/sports/nfl-mvp-cam-newton-performs-lewd-gesture-zings-heckling-fans-football-camp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:07:23+00:00

Cam Newton appeared to use a lewd gesture as he clapped back at heckling fans at a camp in New Orleans over the weekend. Newton last played for the Carolina Panthers in 2021.

## Dolphins' Tyreek Hill resolves dispute with man he was accused of assaulting at marina
 - [https://www.foxnews.com/sports/dolphins-tyreek-hill-resolves-dispute-man-accused-assaulting-marina](https://www.foxnews.com/sports/dolphins-tyreek-hill-resolves-dispute-man-accused-assaulting-marina)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:07:13+00:00

Miami Dolphins star wide receiver Tyreek Hill announced via a statement on Monday that he had resolved the dispute with the man he had assaulted at the marina.

## Florida A&M AD says football team allowed to use facilities despite ongoing investigation about rap video
 - [https://www.foxnews.com/sports/florida-am-ad-football-team-allowed-use-facilities-despite-ongoing-investigation-rap-video](https://www.foxnews.com/sports/florida-am-ad-football-team-allowed-use-facilities-despite-ongoing-investigation-rap-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:06:03+00:00

Florida A&amp;M athletic director Tiffani-Dawn Sykes said on Monday that the football team will be able to use its facilities as the investigation into the rap video continues.

## University of Michigan's president condemns antisemitic vandalism at 2 off-campus fraternity houses
 - [https://www.foxnews.com/us/university-michigans-president-condemns-antisemitic-vandalism-2-campus-fraternity-houses](https://www.foxnews.com/us/university-michigans-president-condemns-antisemitic-vandalism-2-campus-fraternity-houses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:03:58+00:00

President Santa Ono, the University of Michigan&apos;s leader, condemned antisemitic vandalism that was found at two off-campus fraternity houses.

## Country music star Walker Hayes shares journey from 'alcoholic atheist' to life of faith and sobriety
 - [https://www.foxnews.com/entertainment/country-music-star-walker-hayes-shares-journey-alcoholic-atheist-life-faith-sobriety](https://www.foxnews.com/entertainment/country-music-star-walker-hayes-shares-journey-alcoholic-atheist-life-faith-sobriety)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:02:25+00:00

Walker Hayes opened up about his journey from being an &quot;alcoholic atheist&quot; to embracing his faith and sobriety. The country star says he found God through a special friendship.

## Russian aircraft damages US drone flying over Syria
 - [https://www.foxnews.com/world/russias-aircraft-damages-us-drone-flying-syria](https://www.foxnews.com/world/russias-aircraft-damages-us-drone-flying-syria)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:01:52+00:00

Russia&apos;s military targeted and damaged a U.S. aircraft that was flying over Syria, the U.S. military announced Tuesday.

## California state superintendent called out for 'dangerous and extreme' gender policy: 'Perversion of children'
 - [https://www.foxnews.com/media/california-state-superintendent-called-dangerous-extreme-gender-policy-perversion-children](https://www.foxnews.com/media/california-state-superintendent-called-dangerous-extreme-gender-policy-perversion-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T09:00:22+00:00

California state superintendent Tony Thurmond was accused of trying to &apos;pervert children&apos; by advocating against a gender policy that would require parental notification.

## DeSantis involved in 'car accident' on drive to Chattanooga; Florida governor unhurt
 - [https://www.foxnews.com/politics/desantis-involved-car-accident-drive-chattanooga-florida-governor-unhurt](https://www.foxnews.com/politics/desantis-involved-car-accident-drive-chattanooga-florida-governor-unhurt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:59:36+00:00

Ron DeSantis is unhurt, his spokesman says, following a &quot;car accident&quot; he was involved in this morning while traveling to an event in Chattanooga, Tennessee.

## Maine poised to launch offshore wind program to meet clean energy goals, produce power for around 900K homes
 - [https://www.foxnews.com/us/maine-poised-launch-offshore-wind-program-clean-energy-goals-produce-power-900k-homes](https://www.foxnews.com/us/maine-poised-launch-offshore-wind-program-clean-energy-goals-produce-power-900k-homes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:58:57+00:00

The state of Maine is expected to launch an offshore wind program that would produce enough power for around 900,000 homes and meet clean energy goals.

## Language regarding Maine's obligation to Native American tribes may be added back to state's constitution
 - [https://www.foxnews.com/politics/language-regarding-maines-obligation-native-american-tribes-added-back-states-constitution](https://www.foxnews.com/politics/language-regarding-maines-obligation-native-american-tribes-added-back-states-constitution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:55:59+00:00

Maine voters are set to decide whether to add language back to the constitution that highlights the state&apos;s obligation to Native American tribes.

## ESPN's Shaka Hislop to 'seek best medical opinion' after scary on-air collapse
 - [https://www.foxnews.com/sports/espns-shaka-hislop-seek-best-medical-opinion-scary-on-air-collapse](https://www.foxnews.com/sports/espns-shaka-hislop-seek-best-medical-opinion-scary-on-air-collapse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:49:27+00:00

ESPN broadcaster Shaka Hislop addressed his scary collapse in a video Monday. He suffered the incident while he was in the pre-match broadcast of Real Madrid and AC Milan.

## Netanyahu offers to negotiate judicial reforms through November, issues 'call for peace and mutual respect'
 - [https://www.foxnews.com/world/netanyahu-offers-negotiate-judicial-reforms-through-november-issues-call-peace-mutual-respect](https://www.foxnews.com/world/netanyahu-offers-negotiate-judicial-reforms-through-november-issues-call-peace-mutual-respect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:44:42+00:00

Israeli Prime Minister Benjamin Netanyahu offered to work with opposition on a &quot;comprehensive agreement&quot; on his judicial reform package amid protests.

## Braves acquire relievers Pierce Johnson, Taylor Hearn to bolster injury-plagued bullpen
 - [https://www.foxnews.com/sports/braves-acquire-relievers-pierce-johnson-taylor-hearn-bolster-injury-plagued-bullpen](https://www.foxnews.com/sports/braves-acquire-relievers-pierce-johnson-taylor-hearn-bolster-injury-plagued-bullpen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:40:26+00:00

The Atlanta Braves made a pair of moves to bolster their bullpen on Monday, acquiring RHP Pierce Johnson from the Rockies and LHP Taylor Hearn from the Rangers.

## Bizarre 'facekinis' fashion craze hits China beaches amid record heat
 - [https://www.foxnews.com/world/bizarre-facekinis-fashion-craze-hits-china-beaches-amid-record-heat](https://www.foxnews.com/world/bizarre-facekinis-fashion-craze-hits-china-beaches-amid-record-heat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:30:31+00:00

Residents of China are increasingly using &quot;facekinis&quot; to protect against a record-breaking heat wave that has been afflicting the country in recent weeks.

## Nike NFL athletes give stunning Colin Kaepernick endorsement in new ad: 'He got another good six years left'
 - [https://www.foxnews.com/sports/nike-nfl-athletes-give-stunning-colin-kaepernick-endorsement-new-ad-he-got-another-good-six-years-left](https://www.foxnews.com/sports/nike-nfl-athletes-give-stunning-colin-kaepernick-endorsement-new-ad-he-got-another-good-six-years-left)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:27:35+00:00

Colin Kaepernick posted a video of himself throwing to NFL targets on Monday as he looks to make a comeback into the league after more than six years.

## Putin signs ban on transgender surgery into law
 - [https://www.foxnews.com/world/putin-signs-ban-transgender-surgery-law](https://www.foxnews.com/world/putin-signs-ban-transgender-surgery-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:20:57+00:00

Russian President Vladimir Putin signed a piece of legislation into a law that bans sex reassignment surgery and child adoption by transgender people.

## Chicago police officer sustains non-life-threatening injury after getting shot in hand
 - [https://www.foxnews.com/us/chicago-police-officer-sustains-non-life-threatening-injury-getting-shot-hand](https://www.foxnews.com/us/chicago-police-officer-sustains-non-life-threatening-injury-getting-shot-hand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:13:46+00:00

A police officer was taken to the University of Chicago hospital after being shot in the hand. The officers&apos; injury is non-life-threatening.

## Biden administration announces $58 million in grants to help schools remove lead from drinking water
 - [https://www.foxnews.com/us/biden-administration-announces-58-million-grants-help-schools-remove-lead-drinking-water](https://www.foxnews.com/us/biden-administration-announces-58-million-grants-help-schools-remove-lead-drinking-water)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:11:49+00:00

During an event in Boston on July 24, 2023, the Biden administration announced $58 million in grants to help daycare centers and schools remove lead from drinking water.

## Golfer Justin Doeden admits to cheating at Canada event: 'I pray for your forgiveness'
 - [https://www.foxnews.com/sports/golfer-justin-doeden-admits-cheating-canada-event-pray-forgiveness](https://www.foxnews.com/sports/golfer-justin-doeden-admits-cheating-canada-event-pray-forgiveness)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:04:02+00:00

PGA Tour Canada golfer Justin Doeden admitted to cheating at an event over the weekend. The pro copped to the issue in a tweet on Monday.

## McCarthy: Biden case will 'rise to impeachment' as 16 Romanian payments allegedly went to 'shell companies'
 - [https://www.foxnews.com/media/mccarthy-biden-case-impeachment-16-romanian-payments-went-biden-shell-companies](https://www.foxnews.com/media/mccarthy-biden-case-impeachment-16-romanian-payments-went-biden-shell-companies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:00:38+00:00

House Speaker Kevin McCarthy of California joined &apos;Hannity&apos; to sound off on the latest revelations and allegations in the Biden family corruption probe.

## Wisconsin school district sued after teacher revealed gender transition without parental consent
 - [https://www.foxnews.com/media/wisconsin-school-district-sued-teacher-revealed-gender-transition-pronouns-without-parental-consent](https://www.foxnews.com/media/wisconsin-school-district-sued-teacher-revealed-gender-transition-pronouns-without-parental-consent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:00:16+00:00

A Wisconsin school district is being sued after a teacher allegedly announced a gender transition to elementary, middle, and high school students without parental consent.

## Father urges church to step in as religious school teaches kids they can be born into wrong body
 - [https://www.foxnews.com/world/father-urges-church-step-in-religious-school-teaches-kids-they-can-be-born-wrong-body](https://www.foxnews.com/world/father-urges-church-step-in-religious-school-teaches-kids-they-can-be-born-wrong-body)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T08:00:04+00:00

A concerned father is urging officials in the Church of England to take action against alleged curriculum in a church school that teaches that children can be born in the wrong body.

## Severe weather in eastern US, Plains could bring tornado, flash flooding threats
 - [https://www.foxnews.com/us/severe-weather-eastern-us-plains-tornado-flash-flooding-threats](https://www.foxnews.com/us/severe-weather-eastern-us-plains-tornado-flash-flooding-threats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:57:04+00:00

As the Plains, Midwest, Northeast and mid-Atlantic brace for severe weather, extreme heat is continuing to expand into the Northeast on by the end of the week.

## Civil rights activist Bob Woodson defends Jason Aldean against claims of racism: 'Must protect our community'
 - [https://www.foxnews.com/media/civil-rights-activist-bob-woodson-defends-jason-aldean-against-claims-racism-must-protect-community](https://www.foxnews.com/media/civil-rights-activist-bob-woodson-defends-jason-aldean-against-claims-racism-must-protect-community)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:54:25+00:00

Woodson Center founder and president Bob Woodson defended country singer Jason Aldean Monday as leftist media outlets continue to accuse the singer of racism.

## China ousts foreign minister who has been missing for a month
 - [https://www.foxnews.com/world/china-ousts-foreign-minister-who-missing-month](https://www.foxnews.com/world/china-ousts-foreign-minister-who-missing-month)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:50:45+00:00

Chinese state media reported that Beijing&apos;s foreign minister Qin Gang has been replaced by Wang Yi about a month after Qin has dropped out of public view.

## State Department says 'no new communications' between US, North Korea over soldier Travis King
 - [https://www.foxnews.com/world/state-department-says-no-new-communications-between-us-north-korea-over-soldier-travis-king](https://www.foxnews.com/world/state-department-says-no-new-communications-between-us-north-korea-over-soldier-travis-king)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:43:49+00:00

A State Department spokesperson says there have been “no new communications since last week&quot; with North Korea following the capture of an American soldier.

## Saquon Barkley agrees to deal with Giants: report
 - [https://www.foxnews.com/sports/saquon-barkley-agrees-deal-giants](https://www.foxnews.com/sports/saquon-barkley-agrees-deal-giants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:31:40+00:00

Saquon Barkley and the New York Giants reportedly agreed to a one-year deal on Tuesday, ending the running back&apos;s short-lived holdout.

## Rand Paul torches doctors warning of 's--- show' if China accused of COVID release: 'The business of science'
 - [https://www.foxnews.com/media/rand-paul-torches-doctors-warning-show-china-accused-covid-release-business-science](https://www.foxnews.com/media/rand-paul-torches-doctors-warning-show-china-accused-covid-release-business-science)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:30:34+00:00

Senator Rand Paul, R-Kentucky, slammed a Slack conversation between four biologists and virologists regarding the origins of the coronavirus in 2020.

## DeSantis, Scott, Haley, Pence, rest of 2024 field other than Trump to join Reynolds at Iowa State Fair
 - [https://www.foxnews.com/politics/desantis-scott-haley-pence-rest-2024-field-other-than-trump-join-reynolds-iowa-state-fair](https://www.foxnews.com/politics/desantis-scott-haley-pence-rest-2024-field-other-than-trump-join-reynolds-iowa-state-fair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:30:27+00:00

Ron DeSantis, Nikki Haley, Tim Scott, Mike Pence - but not Donald Trump - will join Republican Gov. Kim Reynolds for interviews in August at the Iowa State Fair.

## Teens make prom dress and tux out of duct tape, win $10K in scholarship prize money
 - [https://www.foxnews.com/lifestyle/teens-make-prom-dress-tux-duct-tape-win-10k-scholarship-prize-money](https://www.foxnews.com/lifestyle/teens-make-prom-dress-tux-duct-tape-win-10k-scholarship-prize-money)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:23:59+00:00

Teens created their prom outfits out of duct tape and won $10,000 in scholarship money from the Duck brand. See the unique creations that took hours to make.

## Biden’s narrative on never discussing business deals with Hunter continues to crumble
 - [https://www.foxnews.com/politics/bidens-narrative-never-discussing-business-deals-hunter-continues-crumble](https://www.foxnews.com/politics/bidens-narrative-never-discussing-business-deals-hunter-continues-crumble)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:18:38+00:00

President Biden’s repeated insistence that he had no knowledge of his son&apos;s business dealings continues to crumble as Congress awaits testimony from one of his son&apos;s former business partners.

## YouTubers disrupt Just Stop Oil meetings and protests: 'Just Stop P--sing Everyone Off'
 - [https://www.foxnews.com/media/youtubers-disrupt-just-stop-oil-meetings-protests-just-stop-p-sing-everyone-off](https://www.foxnews.com/media/youtubers-disrupt-just-stop-oil-meetings-protests-just-stop-p-sing-everyone-off)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:00:29+00:00

A British YouTube channel infiltrated a Just Stop Oil gathering and interrupted it in response to the climate organization’s ongoing disruptive protests.

## Florida Black history academic shreds Harris' 'categorically false' claims in unaired ABC News interview
 - [https://www.foxnews.com/media/florida-black-history-academic-shreds-harris-categorically-false-claims-unaired-abc-news-interview](https://www.foxnews.com/media/florida-black-history-academic-shreds-harris-categorically-false-claims-unaired-abc-news-interview)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:00:23+00:00

Dr. William Allen of Florida’s African American History Standards Workgroup, called out those who mischaracterized the state&apos;s educational materials about slavery.

## Illinois cash bail elimination built on ‘overdramatization' perpetuated by city leaders: former police chief
 - [https://www.foxnews.com/us/illinois-cash-bail-elimination-built-overdramatization-perpetuatedcity-leaders-former-police-chief](https://www.foxnews.com/us/illinois-cash-bail-elimination-built-overdramatization-perpetuatedcity-leaders-former-police-chief)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T07:00:00+00:00

Illinois will be the first state in the nation to eliminate cash bail as of Sept. 18, and the former police chief of Riverside, Illinois, says &quot;chaos&quot; will likely break out.

## Biden set to establish new national monument, mom accused of murdering kids in court and more top headlines
 - [https://www.foxnews.com/us/biden-establish-new-national-monument-mom-accused-murdering-kids-court](https://www.foxnews.com/us/biden-establish-new-national-monument-mom-accused-murdering-kids-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T06:36:54+00:00

Biden set to establish new national monument, mom accused of murdering kids in court and more top headlines

## Maryland woman wanted after allegedly stabbing man, 62, to death with butter knife
 - [https://www.foxnews.com/us/maryland-woman-wanted-allegedly-stabbing-man-death-butter-knife](https://www.foxnews.com/us/maryland-woman-wanted-allegedly-stabbing-man-death-butter-knife)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T06:17:26+00:00

Police are searching for a Maryland woman who allegedly stabbed and killed a man inside a restaurant with a butter knife. Another man is charged with accessory.

## Our ESG Act protects investors, limits your financial risks from left-wing activism
 - [https://www.foxnews.com/opinion/our-esg-act-protects-investors-limits-financial-risks-left-wing-activism](https://www.foxnews.com/opinion/our-esg-act-protects-investors-limits-financial-risks-left-wing-activism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T06:00:37+00:00

Because of environmental, social, and corporate governance (ESG), many Americans are quietly funding far-left priorities like climate alarmism and other Democratic hobby horses.

## Former Mumford and Sons founder defends Jason Aldean, 'Sound of Freedom' from media attacks: 'Diabolical'
 - [https://www.foxnews.com/media/former-mumford-and-sons-founder-defends-jason-aldean-sound-of-freedom-media-attacks-diabolic](https://www.foxnews.com/media/former-mumford-and-sons-founder-defends-jason-aldean-sound-of-freedom-media-attacks-diabolic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T06:00:01+00:00

Musician Winston Marshall defended Jason Aldean’s recent music video and praised the hit movie &quot;Sound of Freedom&quot; in an interview with Fox News Digital.

## Former Canadian principal dies by suicide after harassment for pushing back against anti-racism training
 - [https://www.foxnews.com/world/former-canadian-principal-commits-suicide-harassment-pushing-back-anti-racism-training](https://www.foxnews.com/world/former-canadian-principal-commits-suicide-harassment-pushing-back-anti-racism-training)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T05:05:27+00:00

A former Canadian principal died by suicide after being harassed for challenging an anti-racism instructor&apos;s claims that Canada was more racist than the U.S.

## Karine Jean-Pierre claims Biden 'was never in business' with Hunter: 'Goalposts shifted'
 - [https://www.foxnews.com/media/karine-jean-pierre-claims-biden-never-business-hunter-goalposts-shifted](https://www.foxnews.com/media/karine-jean-pierre-claims-biden-never-business-hunter-goalposts-shifted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T05:00:48+00:00

White House press secretary Karine Jean-Pierre claimed on Monday that President Biden &quot;was never in business with&quot; Hunter Biden despite new allegations.

## 6 woke Biden policies at Veterans Affairs that Republicans are moving to dismantle
 - [https://www.foxnews.com/politics/six-woke-biden-veterans-affairs-republicans](https://www.foxnews.com/politics/six-woke-biden-veterans-affairs-republicans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T05:00:01+00:00

House Republicans are likely to advance a spending bill for veterans funding this week and will have to decide which culture-war amendments will get a vote.

## Jamie Foxx's tight-knit family credited for saving actor's life: What to know about comedian's clan
 - [https://www.foxnews.com/entertainment/jamie-foxx-tight-knit-family-credited-saving-actors-life-what-to-know-comedians-clan](https://www.foxnews.com/entertainment/jamie-foxx-tight-knit-family-credited-saving-actors-life-what-to-know-comedians-clan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T04:00:57+00:00

Jamie Foxx thanked his family, particularly his sister and daughter, with helping him during his recovery from a health scare, and he has always been close with his family.

## I’m a New Democrat and we have the key to a strong economy
 - [https://www.foxnews.com/opinion/new-democrat-have-key-strong-economy](https://www.foxnews.com/opinion/new-democrat-have-key-strong-economy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T04:00:53+00:00

After 12 months of improvement on inflation, it&apos;s important to understand how New Democrats took decisive action on the economy to help hard-working Americans.

## New York Times' great cover up: How Gray Lady gets away with ignoring Joe Biden's corruption
 - [https://www.foxnews.com/opinion/new-york-times-great-cover-up-gray-lady-gets-away-ignoring-joe-biden-corruption](https://www.foxnews.com/opinion/new-york-times-great-cover-up-gray-lady-gets-away-ignoring-joe-biden-corruption)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T04:00:29+00:00

Americans are watching the unfolding evidence of corruption from the President Joe Biden and his family members. But readers of the New York Times are barely learning about it.

## Karl Rove: Do you think the Obama White House was unaware of the problem Hunter Biden posed?
 - [https://www.foxnews.com/media/karl-rove-think-obama-white-house-unaware-problem-hunter-biden-posed](https://www.foxnews.com/media/karl-rove-think-obama-white-house-unaware-problem-hunter-biden-posed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T04:00:28+00:00

Fox News contributor Karl Rove says &quot;all we need to know&quot; is if the Obama administration and VP, at the time, Joe Biden knew about Hunter&apos;s business dealings in Ukraine.

## Maskless churchgoer settles lawsuit over 2020 arrest, calls liberalism a 'modern-day cult'
 - [https://www.foxnews.com/media/maskless-churchgoer-settles-lawsuit-2020-arrest-calls-liberalism-modern-day-cult](https://www.foxnews.com/media/maskless-churchgoer-settles-lawsuit-2020-arrest-calls-liberalism-modern-day-cult)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T04:00:28+00:00

Gabriel Rench and two others were awarded $300,000 in a settlement with the city of Moscow over their arrests in 2020 for attending an outdoor worship service maskless.

## Whoopi Goldberg scolds co-host for saying Joy Behar was once 'fired' from 'The View,' something Behar admits
 - [https://www.foxnews.com/media/whoopi-goldberg-scolds-co-host-saying-joy-behar-fired-from-the-view](https://www.foxnews.com/media/whoopi-goldberg-scolds-co-host-saying-joy-behar-fired-from-the-view)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T04:00:20+00:00

Whoopi Goldberg scolded her &quot;View&quot; colleague Ana Navarro for saying Joy Behar was once &quot;fired&quot; from the show, something Behar has long been candid about.

## Alex Morgan embracing first World Cup as a mom: 'I'm playing two roles'
 - [https://www.foxnews.com/sports/alex-morgan-embracing-first-world-cup-as-a-mom-im-playing-two-roles](https://www.foxnews.com/sports/alex-morgan-embracing-first-world-cup-as-a-mom-im-playing-two-roles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T03:11:12+00:00

This is Alex Morgan&apos;s first World Cup as a mother, but she&apos;s in good company. Two other members of Vlatko Andonovski&apos;s 23-player roster, Crystal Dunn and Julie Ertz, are in the same boat.

## Elon Musk’s X-branded Twitter does nothing to solve his much bigger problems
 - [https://www.foxnews.com/shows/media-buzz/elon-musks-x-branded-twitter-does-nothing-solve-much-bigger-problems](https://www.foxnews.com/shows/media-buzz/elon-musks-x-branded-twitter-does-nothing-solve-much-bigger-problems)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T03:02:17+00:00

Users are up in arms about Elon Musk&apos;s most recent announcement to change Twitter&apos;s name and logo — does this make sense for the future of the tech giant?

## Five ways Ayn Rand predicted America's political crises, from parents spurned to the rise of cancel culture
 - [https://www.foxnews.com/lifestyle/five-ways-ayn-rand-predicted-americas-political-crises-parents-spurned-rise-cancel-culture](https://www.foxnews.com/lifestyle/five-ways-ayn-rand-predicted-americas-political-crises-parents-spurned-rise-cancel-culture)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T03:00:27+00:00

Author, philosopher and libertarian thinker Ayn Rand, writing mostly in post-war America, predicted with remarkable accuracy many of the social crises facing America today.

## Florida Uber driver accused of raping passenger celebrating 21st birthday had lengthy criminal past
 - [https://www.foxnews.com/us/florida-uber-driver-accused-raping-passenger-celebrating-21st-birthday-lengthy-criminal-past](https://www.foxnews.com/us/florida-uber-driver-accused-raping-passenger-celebrating-21st-birthday-lengthy-criminal-past)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T02:00:52+00:00

A 42-year-old Uber driver has been accused of raping his 20-year-old passenger while she was intoxicated on a ride from a Tampa, Florida, nightclub to her hotel.

## AI appears more human on social media than actual humans: study
 - [https://www.foxnews.com/tech/ai-appears-more-human-social-media-than-actual-humans-study](https://www.foxnews.com/tech/ai-appears-more-human-social-media-than-actual-humans-study)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T02:00:29+00:00

An artificial intelligence study published in Science Advances found that AI-generated text on social media can appear more human than human-generated content.

## AI on the front lines: Senate pushes Army to develop neural sensors to track soldiers’ fatigue, stress
 - [https://www.foxnews.com/politics/ai-frontlines-senate-army-neural-sensors-track-soldiers-fatigue-stress](https://www.foxnews.com/politics/ai-frontlines-senate-army-neural-sensors-track-soldiers-fatigue-stress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T02:00:28+00:00

Senators on the Armed Services Committee want the Pentagon to move quickly toward adopting AI-driven neural sensors for American warfighters.

## Our schools’ war on AI is a national security threat
 - [https://www.foxnews.com/opinion/our-schools-war-ai-national-security-threat](https://www.foxnews.com/opinion/our-schools-war-ai-national-security-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T02:00:13+00:00

America’s artificial intelligence superiority is at risk, and the key contributing factors are the broken U.S. education system and fear of job loss.

## Casey Phair, 16, becomes youngest to ever play in Women's World Cup
 - [https://www.foxnews.com/sports/casey-yu-jin-phair-16-becomes-youngest-to-ever-play-in-womens-world-cup](https://www.foxnews.com/sports/casey-yu-jin-phair-16-becomes-youngest-to-ever-play-in-womens-world-cup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T00:58:34+00:00

Casey Yu-jin Phair, just 16 years and 26 days, became the youngest player ever to play in the tournament, while Linda Caicedo, 18, became the current World Cup&apos;s youngest goalscorer.

## Phillies' Trea Turner ejected after nightmare fifth inning leads to boos from home crowd
 - [https://www.foxnews.com/sports/phillies-trea-turner-ejected-nightmare-fifth-inning-boos-home-crowd](https://www.foxnews.com/sports/phillies-trea-turner-ejected-nightmare-fifth-inning-boos-home-crowd)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T00:20:09+00:00

Philadelphia Phillies shortstop Trea Turner had a ghastly error and an argument with umpires which led to his ejection all in one inning against the Baltimore Orioles.

## On this day in history, July 25, 1976, NASA captures 'Face on Mars' photo
 - [https://www.foxnews.com/lifestyle/this-day-history-july-25-1976-nasa-captures-face-mars-photo](https://www.foxnews.com/lifestyle/this-day-history-july-25-1976-nasa-captures-face-mars-photo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-07-25T00:02:08+00:00

NASA&apos;s Viking 1 took the first images of the &quot;Face on Mars,&quot; a rock formation on the Red Planet that looked shockingly like a human face, on this day in history in 1976.

