# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Historia Joanny z Krakowa. Kobieta pojawiła się na proteście. "Byłam zaszczutym zwierzęciem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009800,historia-joanny-z-krakowa-kobieta-pojawila-sie-na-protescie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009800,historia-joanny-z-krakowa-kobieta-pojawila-sie-na-protescie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T19:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/9e/1c/z30009890M,Protest-solidarnosciowy-z-Joanna--Krakow--25-lipca.jpg" vspace="2" />Pani Joanna, wobec której policjanci przeprowadzili upokarzającą interwencję w szpitalu, przemawiała we wtorek przed krakowskim komisariatem. - Ja tam już nie byłam człowiekiem, ja tam już byłam zaszczutym zwierzęciem - wykrzyczała. Przed siedzibą policji stanęło pięcioro policjantów. - To ci sami, którzy interweniowali w mojej sprawie - mówiła Joanna, a tłum skandował "hańba!".

## "Chrońmy dzieci" czy "Lex Czarnek 3.0"? Projekt straszy "seksualizacją" i jest już w Sejmie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009524,chronmy-dzieci-czy-lex-czarnek-3-0-projekt-straszy-seksualizacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009524,chronmy-dzieci-czy-lex-czarnek-3-0-projekt-straszy-seksualizacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T18:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/68/9d/1c/z30004840M,Minister-edukacji-i-nauki-Przemyslaw-Czarnek.jpg" vspace="2" />Do Sejmu trafił obywatelski projekt "Chrońmy dzieci" i w błyskawicznym tempie został skierowany do pierwszego czytania. Autorzy projektu zainspirowali się zawetowanymi przez prezydenta postulatami Przemysława Czarnka. Przewidują m.in. zakaz działalności na terenie przedszkoli i szkół stowarzyszeń i organizacji promujących "zagadnienia związane z seksualizacją dzieci". Sławomir Broniarz przypomniał, że w parlamencie utknęły dwa projekty ZNP dotyczące wynagrodzeń nauczycieli. "Zapamiętajmy to!" - napisał.

## Nie żyje wójt gminy Firlej. Dawid Tarnowski miał 36 lat. "Marzyciel, perfekcjonista"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009367,dawid-tarnowski-nie-zyje-wojt-gminy-firlej-mial-36-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30009367,dawid-tarnowski-nie-zyje-wojt-gminy-firlej-mial-36-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T17:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2c/9e/1c/z30009388M,Dawid-Tarnowski.jpg" vspace="2" />Nie żyje Dawid Tarnowski, wójt gminy Firlej w województwie lubelskim. Funkcję tę sprawował od 2018 roku. Miał 36 lat.

## Tajemnicze kosze na plażach. Lepiej ich nie dotykać. WWF apeluje: Zachowaj dystans!
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008878,tajemnicze-kosze-na-plazach-co-to-takiego-wwf-apeluje-zachowaj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008878,tajemnicze-kosze-na-plazach-co-to-takiego-wwf-apeluje-zachowaj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T15:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/55/9e/1c/z30009173M,Metalowe-klatki-na-polskich-plazach--zdj--ilustrac.jpg" vspace="2" />Na polskich plażach pojawiły się niewielkie, metalowe klatki. Co to takiego? Specjalne kosze, które pełnią ważną funkcje - informuje WWF Polska. Zachowaj od nich odpowiedni dystans.

## Gdzie jest burza? Intensywne opady, silny wiatr, a nawet grad. Wydano alerty IMGW i RCB
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008324,gdzie-jest-burza-intensywne-opady-silny-wiatr-a-nawet-grad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008324,gdzie-jest-burza-intensywne-opady-silny-wiatr-a-nawet-grad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T13:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bb/84/1c/z29901499M,Wyladowania-atmosferyczne-podczas-burzy---zdjecie-.jpg" vspace="2" />Synoptycy Instytututu Meteorologii i Gospodarki Wodnej (IMGW) wydali ostrzeżenia I i II stopnia. Rządowe Centrum Bezpieczeństwa wysłało alerty mieszkańcom trzech województw. Wszystko za sprawą deszczowego frontu atmosferycznego, który nasuwa się nad południowo-wschodnią Polskę. Gdzie jest burza?

## Polacy chcą legalnej aborcji, ale władza wie lepiej. Nowy sondaż nie pozostawia wątpliwości
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008114,polacy-chca-legalnej-aborcji-ale-wladza-wie-lepiej-nowy-ondaz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30008114,polacy-chca-legalnej-aborcji-ale-wladza-wie-lepiej-nowy-ondaz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T13:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/91/1c/z29957699M.jpg" vspace="2" />Niemal 57 proc. Polaków uważa, że niezależnie od przyczyny aborcja do 12. tygodnia ciąży powinna być legalna. Zgodni są zarówno mieszkańcy dużych miast, jak i wsi.

## Prymas Polski uderzył w Rydzyka i polityków. "Kościół to nie miejsce na wiec polityczny"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30007465,prymas-polski-uderzyl-w-rydzyka-i-politykow-kosciol-to-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30007465,prymas-polski-uderzyl-w-rydzyka-i-politykow-kosciol-to-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T12:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b3/9e/1c/z30007731M,Prymas-Polski-zostal-zapytany-o-polityke-w-Kosciel.jpg" vspace="2" />- Kościół to nie miejsce na wiec polityczny - powiedział prymas Polski w odpowiedzi na pytanie co sądzi o udziale polityków PiS w pielgrzymce Radia Maryja na Jasnej Górze i słowach Tadeusza Rydzyka krytykującego Unię Europejską. Duchowny wyjaśnił, jaka jest rola i odpowiedzialność Kościoła w czasie zbliżających się wyborów.

## "Solidarnie z Joanną". Protesty pod siedzibami policji w Polsce. Gdzie i o której? [LISTA MIAST]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006867,protesty-solidarnie-z-joanna-pod-siedzibami-policji-w-polsce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006867,protesty-solidarnie-z-joanna-pod-siedzibami-policji-w-polsce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T11:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/9e/1c/z30007304M,Protesty--solidarnie-z-Joanna--pod-siedzibami-poli.jpg" vspace="2" />"Dziękujemy za to, że zamiast nas bronić i dawać poczucie bezpieczeństwa, staliście się wrogami kobiet" - napisał Ogólnopolski Strajk Kobiet w zapowiedzi protestów, które przejdą we wtorek w wielu miastach w Polsce. Strajki odbędą się przed siedzibami policji.

## Strzały pod siedzibą TV Republika. Policja zatrzymała 15-latka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006795,strzaly-pod-siedziba-tv-republika-policja-zatrzymala-15-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006795,strzaly-pod-siedziba-tv-republika-policja-zatrzymala-15-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T10:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ec/9b/1c/z29997292M,Policja.jpg" vspace="2" />- Policjanci w tej sprawie [oddania strzałów pod redakcją TV Republika - red.] dalej wykonywali czynności i te czynności oraz zgromadzone informacje doprowadziły policjantów do młodego mężczyzny w wieku 15 lat - poinformowała we wtorek w rozmowie z PAP Marta Sulowska z komendy na warszawskiej Woli.

## Zapadła decyzja ws. nalotu CBA na gabinet ginekologiczny w Szczecinie. "Niedopuszczalne"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006532,jest-decyzja-sadu-w-sprawie-nalotu-cba-na-gabinet-ginekologiczny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30006532,jest-decyzja-sadu-w-sprawie-nalotu-cba-na-gabinet-ginekologiczny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T10:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e4/1f/1c/z29490660M,Z-gabinetu-ginekologicznego-dr-Marii-Kubisy-agenci.jpg" vspace="2" />Sąd w Szczecinie wydał postanowienie w sprawie interwencji Centralnego Biura Antykorupcyjnego (CBA) w prywatnym gabinecie ginekolożki Marii Kubisy. Wynika z niego, że agenci, którzy zabrali całą dokumentację medyczną, nie mieli do tego prawa.

## Jest zawiadomienie ws. Stowarzyszenia Polska 2050. Chodzi o punkt pomocy dla zwierząt
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005874,jest-zawiadomienie-ws-stowarzyszenia-polska-2050-chodzi-o.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005874,jest-zawiadomienie-ws-stowarzyszenia-polska-2050-chodzi-o.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T07:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/38/83/1c/z29899576M,Pies-w-Schronisku-dla-Bezdomnych-Zwierzat-w-Szczec.jpg" vspace="2" />Część środków przeznaczonych na pomoc dla zwierząt uchodźców z Ukrainy, które także trafiły do Polski, miała do nich nie dotrzeć - wynika z zawiadomienia do prokuratury, o którym informuje "Rzeczpospolita". Chodzi o Centrum Pomocy Humanitarnej PTAK w Nadarzynie pod Warszawą i działający tam punkt pomocy dla zwierząt. Według organizacji, które złożyły zawiadomienie, pieniądze miało sprzeniewierzyć Stowarzyszenie Polska 2050 Szymona Hołowni.

## "Ksiądz ze zwykłej parafii" oburzony w liście do Owsiaka. "Kościół musi się opamiętać, oprzytomnieć"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005945,ksiadz-ze-zwyklej-parafii-oburzony-w-liscie-do-owsiaka-kosciol.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005945,ksiadz-ze-zwyklej-parafii-oburzony-w-liscie-do-owsiaka-kosciol.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T07:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0f/9d/1c/z30006031M,Jerzy-Owsiak.jpg" vspace="2" />"Nie mogę już patrzeć na to, co dzieje się w naszym kraju - a chodzi o nieszczęsny sojusz tronu z ołtarzem - konkretnie rządu PiS z Kościołem katolickim (...). Trzeba iść do wyborów!" - napisał do Jerzego Owsiaka "ksiądz ze zwykłej parafii". "Podpisuję się pod tym obiema rękami" - przekazał szef Wielkiej Orkiestry Świątecznej Pomocy.

## Pogoda. Intensywne burze zbliżają się do Polski. Możliwy grad oraz trąba powietrzna [ALERTY IMGW]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005830,pogoda-intensywne-burze-zblizaja-sie-do-polski-mozliwy-grad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005830,pogoda-intensywne-burze-zblizaja-sie-do-polski-mozliwy-grad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T06:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ae/9d/1c/z30005934M,Kolejne-burze-zblizaja-sie-do-Polski.jpg" vspace="2" />Do Polski zbliża się kolejna strefa burz, choć wciąż widać skutki wczorajszych nawałnic. Instytut Meteorologii i Gospodarki Wodnej (IMGW) wydał ostrzeżenia I i II stopnia przed burzami z gradem. Możliwe są też opady nawalnego deszczu, a nawet trąba powietrzna.

## Wrocław. Policja zatrzymała kierowcę taksówki. Miał zgwałcić i okraść 26-latkę. Uber wydał oświadczenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005627,wroclaw-policja-zatrzymala-kierowce-taksowki-mial-zgwalcic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30005627,wroclaw-policja-zatrzymala-kierowce-taksowki-mial-zgwalcic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-07-25T04:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/94/9d/1c/z30005652M,Wroclaw--Policja-zatrzymala-mezczyzne-podejrzanego.jpg" vspace="2" />Policjanci zatrzymali kierowcę, który podejrzewany jest o to, że zgwałcił i okradł swoją pasażerkę. 26-latka miała być pod wpływem alkoholu. 28-letniemu mężczyźnie postawiono zarzuty. Zastosowano również wobec niego areszt tymczasowy.

