# Source:John Harris, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw, language:en-US

## I’m starting a new channel
 - [https://www.youtube.com/watch?v=h3-gWNwEaYA](https://www.youtube.com/watch?v=h3-gWNwEaYA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw
 - date published: 2023-07-25T12:00:36+00:00

Subscribe to Search Party & watch the first video now: https://youtu.be/jBeXyKVvhb0

Search Party is a new, independent, video news show that combines experienced journalism and visual design to decode the most complex stories in international sports and geopolitics.

Get access to behind-the-scenes vlogs, my scripts, and extended interviews over at https://www.patreon.com/johnnyharris

Watch my new videos early on Nebula. Subscribe now: https://go.nebula.tv/johnnyharris

I made a poster about maps - check it out: https://store.dftba.com/products/all-maps-are-wrong-poster

Custom Presets & LUTs [what we use]: https://store.dftba.com/products/johnny-iz-luts-and-presets

About: 
Johnny Harris is an Emmy-winning independent journalist and contributor to the New York Times. Based in Washington, DC, Harris reports on interesting trends and stories domestically and around the globe, publishing to his audience of over 3.5 million on Youtube.  Harris produced and hosted the twice Emmy-nominated series Borders for Vox Media. His visual style blends motion graphics with cinematic videography to create content that explains complex issues in relatable ways.

- press - 
NYTimes: https://www.nytimes.com/2021/11/09/opinion/democrats-blue-states-legislation.html
NYTimes: https://www.nytimes.com/video/opinion/100000007358968/covid-pandemic-us-response.html
Vox Borders: https://www.youtube.com/watch?v=hLrFyjGZ9NU
NPR Planet Money: https://www.npr.org/transcripts/1072164745


- where to find me -
Instagram: https://www.instagram.com/johnny.harris/
Tiktok: https://www.tiktok.com/@johnny.harris
Facebook: https://www.facebook.com/JohnnyHarrisVox
Iz's (my wife’s) channel: https://www.youtube.com/iz-harris

- how i make my videos -
Tom Fox makes my music, work with him here: https://tfbeats.com/
I make maps using this AE Plugin: https://aescripts.com/geolayers/?aff=77
All the gear I use: https://www.izharris.com/gear-guide
 
- my courses - 
Learn a language: https://brighttrip.com/course/language/
Visual storytelling: https://www.brighttrip.com/courses/visual-storytelling

## Why Is the Titanic So Famous?
 - [https://www.youtube.com/watch?v=48iQJxiyzuo](https://www.youtube.com/watch?v=48iQJxiyzuo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw
 - date published: 2023-07-25T02:05:58+00:00

The Titanic isn’t the deadliest shipwreck, but it is the most memorable. There's a reason for that! 

Get access to behind-the-scenes vlogs, my scripts, and extended interviews over at https://www.patreon.com/johnnyharris

I made a poster about maps - check it out: https://store.dftba.com/products/all-maps-are-wrong-poster

Custom Presets & LUTs [what we use]: https://store.dftba.com/products/johnny-iz-luts-and-presets

The music for this video, created by our in house composer Tom Fox, is available on our music channel, The Music Room! Follow the link to hear this soundtrack and many more: [[[INSERT LINK]]]]

About: 
Johnny Harris is an Emmy-winning independent journalist and contributor to the New York Times. Based in Washington, DC, Harris reports on interesting trends and stories domestically and around the globe, publishing to his audience of over 3.5 million on Youtube.  Harris produced and hosted the twice Emmy-nominated series Borders for Vox Media. His visual style blends motion graphics with cinematic videography to create content that explains complex issues in relatable ways.

- press - 
NYTimes: https://www.nytimes.com/2021/11/09/opinion/democrats-blue-states-legislation.html
NYTimes: https://www.nytimes.com/video/opinion/100000007358968/covid-pandemic-us-response.html
Vox Borders: https://www.youtube.com/watch?v=hLrFyjGZ9NU
NPR Planet Money: https://www.npr.org/transcripts/1072164745


- where to find me -
Instagram: https://www.instagram.com/johnny.harris/
Tiktok: https://www.tiktok.com/@johnny.harris
Facebook: https://www.facebook.com/JohnnyHarrisVox
Iz's (my wife’s) channel: https://www.youtube.com/iz-harris

- how i make my videos -
Tom Fox makes my music, work with him here: https://tfbeats.com/
I make maps using this AE Plugin: https://aescripts.com/geolayers/?aff=77
All the gear I use: https://www.izharris.com/gear-guide
 
- my courses - 
Learn a language: https://brighttrip.com/course/language/
Visual storytelling: https://www.brighttrip.com/courses/visual-storytelling

