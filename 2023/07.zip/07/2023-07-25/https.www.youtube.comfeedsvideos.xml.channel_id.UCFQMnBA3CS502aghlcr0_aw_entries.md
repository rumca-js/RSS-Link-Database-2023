# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## He Stole $40 Million and Got Caught
 - [https://www.youtube.com/watch?v=-KrYohUJvYw](https://www.youtube.com/watch?v=-KrYohUJvYw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2023-07-25T20:27:11+00:00

Do not try this at home. Aiden Pleterski ran a $40 million dollar ponzi scheme, and after getting caught... one of the victims decided to take matters into their own hands. 

Support: 
► Patreon: https://patreon.com/coffeezilla

Follow: 
► Twitter: @coffeebreak_yt
► Instagram: @coffeebreak_yt

Credits:
3D Artist: Ed Leszczynski @LeszczynskiEd
Video Editor: Harry Bagg  @HarryRBagg
Virtual Production Software: Aximmetry

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

