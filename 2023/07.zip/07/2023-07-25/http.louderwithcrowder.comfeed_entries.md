# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Watch: Smug reporter attempts gotcha question at Kevin McCarthy on "moderates," gets earful on impeaching Biden instead
 - [https://www.louderwithcrowder.com/kevin-mccarthy-impeachment-biden](https://www.louderwithcrowder.com/kevin-mccarthy-impeachment-biden)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-07-25T20:40:03+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34667102&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C2" /><br /><br /><p>Devon Archer, Hunter Biden's former business partner, just yesterday testified they sold access to Joe Biden (the former vice president) <a href="https://www.louderwithcrowder.com/hunter-biden-business-partner-bombshell" target="_blank">over twenty-four times</a>. If you are a journalsimer looking to create political content and have the opportunity to ask a question of Speaker of the House Kevin McCarthy, that seems a decent topic.</p><p>Instead, a reporter asked what McCarthy says to alleged "moderates" in his party who don't want him doing anything about it. McCarthy was not amused. His response, on the other hand, I found very amusing.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/TPostMillennial/status/1683929710688886785"></a>
</blockquote>

<blockquote>"What do say to the moderates in your party who say you continue to side with and appease the right wing on many issues ... I’m talking about an impeachment inquiry of President Biden, on appropriations, on the long list of things."</blockquote><p>Ah, the "people say..." question. I've only ever heard this question answered correctly once, and it was a professional wrestling promo. The interviewer started to ask The Shield "Many people say that..." before Jon Moxley (then Dean Ambrose) interrupted "What people? Who are these people?" </p><p>One of these days a journalismer is going to be asked that and their head will explode. Speaker McCarthy came close, pointing out how she gave him no examples of what people. But since she wanted to discuss impeaching Biden and the discussion about impeaching Biden, McCarthy was happy to oblige.</p><p>Because if you'll allow me another wrestling reference, this is tribal combat now.</p><blockquote>You have a president who told you and every other American that he’s never talked to his family about business and they never got $1 from China. You now know that’s not true. You have a president while he was vice president that got 16 out of 17 payments from Romania.<br /><br />Congress has a responsibility for the investigation wing. You’ve got to get to the bottom of the truth. And the only way Congress can do that is to go to impeachment inquiry. That gives Republicans and Democrats the ability to get all the information.<br /></blockquote><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="d3f63" src="https://www.louderwithcrowder.com/media-library/image.gif?id=34667129&amp;width=980" />
</p>
<p>There are a lot of truths to get to the bottom of, like a confidential FBI source stepping forward to say <a href="https://dailycaller.com/2023/07/20/joe-biden-hunter-both-told-ukrainian-oligarch-burisma-board/" rel="noopener noreferrer" target="_blank">Joe and Hunter BOTH told the CEO of Burisma to retain the president’s son</a> and a whistleblower who worked on the Hunter Biden tax investigation, there were a lot of people in Joe Biden's government <a href="https://www.louderwithcrowder.com/whistleblower-x-testimony" target="_self">who didn't want anyone working on the Hunter Biden tax investigation</a>. An impeachment inquiry is an outstanding way to get to the bottom of it.</p><p>Democrats set the gold standard in impeaching the former president. It would be unpatriotic if the Republican-led Congress didn't meet their constitutionally elected duties exactly how the Democrats did before them. And the first journalismer who says "but the Senate will never convict" gets punched right in the weiner.</p><p>These are the new rules the Left and the media set. Time to play by them.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

## Jason Aldean makes progressives regret trying that in a small town, sees massive 999% increase in plays
 - [https://www.louderwithcrowder.com/jason-aldean-hot-100-sales](https://www.louderwithcrowder.com/jason-aldean-hot-100-sales)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-07-25T17:12:13+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=34663915&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Every Friday, I end the work day with a healthy glass of bourbon and that week's new music Friday playlist of country songs. As someone who routinely listens to country music, I didn't know "Try That in A Small Town" was a thing. Let alone, did Leftists who hate the part of the country that likes country music. Jason Aldean owes each of them a muffin basket. Their shakyfist, stabby outrage has done nothing but make it one of the top songs in America.</p><p>Though Gun Control Karen DID get it canceled from the <a href="https://www.louderwithcrowder.com/shannon-watts-jason-aldean" target="_blank">MTV-owned and NYC-based CMT</a>. Good for you, Skippy.</p><p>As for Aldean and his Middle-America anthem? Per <a href="https://www.hollywoodreporter.com/news/music-news/jason-aldean-try-that-in-a-small-town-streams-up-controversy-1235543896/" target="_blank">Hollywood Reporter</a> and <a href="https://www.nytimes.com/2023/07/24/arts/music/jason-aldean-small-town-billboard.html" target="_blank">Billboard</a>:</p><p>- Audio and video streams have increased by 999%. That's not a typo. Three 9's. It went from 987k streams to 11.7 million.</p><p>- Sales of the song jump from 1,000 units to 228,000 units.</p><p>- And it's #2 on the Billboard Hot 100.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/LWCnewswire/status/1682000124459843585"></a>
</blockquote>
<p>Aldean thanked fans for their support over the weekend, saying "One thing I saw this week was a bunch of country music fans that could see through a lot of the bullshit, alright. I saw country music fans rally as I’ve never seen before, and it was pretty badass to watch. I gotta say, thank you guys so much."</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/SweetPeaBell326/status/1682724611257933824"></a>
</blockquote>
<p>It is almost as if the vast majority of America is rejecting the hallway monitors and schoolmarms that control the media and decide what content you can enjoy. Either that or the elusive "silent majority" is growing increasingly more vocal. </p><p>If anything, the outrage proves the point of the song. The people who live on the coasts and in progressive-run cities are out of touch with how anyone outside of those cities think or live their lives. People who live in the cities enjoy the chaos. They must. They keep electing the same Democrats whose policies encourage the chaos.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

## Watch: Luke Combs invites a cancer-free boy to sing with him on stage and the crowd reaction will have you in tears
 - [https://www.louderwithcrowder.com/luke-combs-invites-kid-on-stage](https://www.louderwithcrowder.com/luke-combs-invites-kid-on-stage)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-07-25T16:52:19+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34663174&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>When you embrace the suck that is writing about politics and culture all day, you need the occasional palate cleanser to remind you that not everything is terrible. Things like seven-year-old Cooper who, to celebrate beating cancer, drove all the way from Georgia to Boston to see his favorite artist <a href="https://www.louderwithcrowder.com/luke-combs-vancouver-fight" target="_blank">Luke Combs</a>.</p><p>His journey didn't end there. The country icon invited him up to sing.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/ClayTravis/status/1683504612458786816"></a>
</blockquote>
<p>"Cooper came all the way here, just beat cancer, so he could sign his favorite song with me," <a href="https://www.whiskeyriff.com/2023/07/23/luke-combs-brings-little-boy-on-stage-to-sing-fast-car-with-him-at-gillette-stadium-to-celebrate-being-cancer-free/" target="_blank">Combs told the audience</a>. "So, what we’re gonna do Cooper, is we’re gonna sing the chorus of ‘Fast Car’ one time, and all these beautiful people, who are so happy that you’re cancer free, they’re gonna sing ‘Fast Car’ with us. And hey, they probably aren’t gonna be able to hear us anyways ‘cause  they’re gonna be singing so loud. I’m gonna help you.”</p><p>And the crowd erupted for him!</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="c15cd" src="https://www.louderwithcrowder.com/media-library/image.gif?id=34663253&amp;width=980" />
</p><p>Is there a WaPo editor somewhere who watched this video and said "<a href="https://www.louderwithcrowder.com/washington-post-tracy-chapman" target="_blank">Yeah, but he's a white boy</a>" and assigned a think piece to someone? Maybe. But to those of us with a soul, this was a direct hit right in the feels.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/losttriberoots/status/1683825954697646081"></a>
</blockquote>
<p><br /></p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/realdisplaced/status/1683844793678573568"></a>
</blockquote>
<p><br /></p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/LWCnewswire/status/1683824901373796352"></a>
</blockquote>
<p>Full disclosure. We needed the palate cleanser and I was deciding between Cooper and the girl who screwed up shotgunning a beer with Combs. Here's the other clip for reference.</p><p><br /></p><div class="rm-embed embed-media"><blockquote cite="https://www.tiktok.com/@tommy7110/video/7257147734371667246" class="tiktok-embed"> <section> <a href="https://www.tiktok.com/@tommy7110?refer=embed" target="_blank" title="@tommy7110">@tommy7110</a> When luke gives you a beer and you only have one job. <a href="https://www.tiktok.com/tag/lukecombs?refer=embed" target="_blank" title="lukecombs">#lukecombs</a> <a href="https://www.tiktok.com/tag/lukecombsconcert?refer=embed" target="_blank" title="lukecombsconcert">#lukecombsconcert</a> <a href="https://www.tiktok.com/tag/lukecombsworldstour2023?refer=embed" target="_blank" title="lukecombsworldstour2023">#lukecombsworldstour2023</a> <a href="https://www.tiktok.com/tag/lukecombscharlottenight1?refer=embed" target="_blank" title="lukecombscharlottenight1">#lukecombscharlottenight1</a> <a href="https://www.tiktok.com/tag/fyp?refer=embed" target="_blank" title="fyp">#fyp</a> <a href="https://www.tiktok.com/music/original-sound-7257147688045660971?refer=embed" target="_blank" title="♬ original sound - Tommy">♬ original sound - Tommy</a> </section> </blockquote> </div><p>I think I chose well.</p><p>On behalf of everyone here at the Louder with Crowder Dot Com website, prayers to Cooper for a continued bill of health. </p><p>Also, if you have the opportunity to catch Luke Combs live I can recommend doing so enough. I saw him play The Garden a few years ago and it's easily in my top five of concerts I've been to.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

## "Look, Fat" Revisited: Remember when Joe Biden lashed out at a voter for questioning Hunter's shady business dealings
 - [https://www.louderwithcrowder.com/joe-biden-iowa-voter](https://www.louderwithcrowder.com/joe-biden-iowa-voter)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-07-25T14:18:24+00:00

<img src="https://www.louderwithcrowder.com/media-library/look-fat-revisited-remember-when-joe-biden-lashed-out-at-a-voter-for-questioning-hunter-s-shady-business-dealings.png?id=34662850&amp;width=2000&amp;height=1500&amp;coordinates=320%2C0%2C0%2C0" /><br /><br /><p>As Hunter Biden's shady business dealings are back to dominating the news (except for CNN/MSNBC/NYT/WAPO/et al), let's take a look back at when Hunter's shady business dealing came up in 2019. It's the infamous "Look, Fat" video.</p><p>Critics say Joe called the voters challenging him "fat." But the Biden Campaign swears he said "look, facts." Therefore that's what the "independent" "fact" checkers say. Remember, this is 2019, the year before we learned a seventy-year-old career politician had a childhood stutter no one had ever heard of.</p><p>A voter was concerned about Hunter's business dealings in Ukraine. Again, this is 2019 before Zelenskyy became a global celebrity. The voter thought it was odd Ukraine energy company Burisam would pay Hunter $83,000 a month to be a director in an industry he has no experience. Unless... there was another reason. Like, say, Hunter's father.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/MollyNagle3/status/1202648690302869505"></a>
</blockquote>

<p><em>"The reason I'm running is because I've been around a long time and I know more than most people know and I can get things done... And if you want to check my shape, let's do push-ups together man, let's run, let's do whatever you want to do. Let's take an IQ test."</em></p><p>Oh yeah, that was the other thing. Joe Biden's age and IQ were challenged in 2019. Four years ago. Funny when you view the spry and coherent Biden of 2023.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/LWCnewswire/status/1664345425136984097"></a>
</blockquote>

<p>Maybe funny isn't the right word.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/RNCResearch/status/1681358659622780939"></a>
</blockquote>

<p>The reason for the trip down memory lane is a reminder that, yesterday, Devon Archer, Hunter Biden's former business partner, testified they sold access to Joe Biden (the former vice president) at least 24 times, including Burisma.</p><p>...which comes on the heels of a confidential FBI source stepping forward to say <a href="https://dailycaller.com/2023/07/20/joe-biden-hunter-both-told-ukrainian-oligarch-burisma-board/" rel="noopener noreferrer" target="_blank">Joe and Hunter BOTH told the CEO of Burisma to retain the president’s son</a>.</p><p>...which comes on the heels of confirmation <a href="https://www.washingtontimes.com/news/2023/jul/20/fbi-told-twitter-hunter-biden-laptop-was-real-soon/" rel="noopener noreferrer" target="_blank">the FBI knew that Hunter's laptop was real the entire time</a>.</p><p>...which comes on the heels of a whistleblower testifying before Congress that, as someone who worked on the Hunter Biden tax investigation, there were a lot of people in Joe Biden's government <a href="https://www.louderwithcrowder.com/whistleblower-x-testimony" target="_self">who didn't want anyone working on the Hunter Biden tax investigation</a>.</p><p>Oh, 2019. Such a quaint time. A bygone era, if you will.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

## CNN shocked how many people stole while reporting what a crime-infested suckhole San Francisco is: "Did that guy pay?"
 - [https://www.louderwithcrowder.com/cnn-san-francisco-shoplifting](https://www.louderwithcrowder.com/cnn-san-francisco-shoplifting)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-07-25T13:33:45+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=34662686&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>San Francisco has turned into such a sh*tstained crime incubator, CNN could not ignore the problem anymore. They saw the <a href="https://www.louderwithcrowder.com/san-francisco-ice-cream-pizza" target="_blank">viral video of ice cream and frozen pizzas padlocked</a> and said, "Well, this can't be right. Why would Nancy Pelosi let this happen to her city?" Senior correspondent Kyung Lah was sent to investigate.</p><p>Out of Walgeens' 9000 stores, that one San Francisco store has the highest crime rate out of all of them. Up to twelve times a day. It was so bad, CNN witnessed three thefts in the short time they were there.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/KyungLahCNN/status/1683632951488049152"></a>
</blockquote>
<p>One onlooker said seeing products, like $14 bags of coffee, locked behind plexiglass made it look like San Francisco was becoming a police state. Odd that rampant crime that is a result of progressive voters electing progressive politicians to enact progressive policies that lead to the crime would resemble a police state. It's also odd that CNN would allow that to be said on air. Their definition of police state tends to more resemble Ron DeSantis passing laws that say if parents want to expose their children to porn they can order it off Amazon, but it will no longer be available in public schools.</p><p>CNN reports the residents are beginning to get fed up, which is true-ish. Voters have recalled <a href="https://www.louderwithcrowder.com/school-board-recalled-san-francisco" target="_self">a school board</a> and <a href="https://www.louderwithcrowder.com/chesa-boudlin-lashes-out" target="_self">their District Attorney</a> because they had gone too woke even by San Francisco standards. Though instead of acknowledging the pushback, in both cases the influence of Republican billionaires was blamed for the recalls. </p><p>Yes. Republican influence... in San Francisco. Nothing is EVER the fault of progressive policies.</p><p>If I were a journalismer, I would sit down with Gavin Newsom and Nancy Pelosi and make them watch the Walgreens video. Also, this video.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/libsoftiktok/status/1545591855617695745"></a>
</blockquote>

<p>This video.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/jterrell/status/1568066894611226624"></a>
</blockquote>

<p>And especially this video. He's one of the few people who migrated from Texas TO California. It's because California makes it more lucrative to be homeless.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/shellenberger/status/1491418120086454278"></a>
</blockquote>

<p>Gov. Newsom? Speaker Pelosi? This is all happening in a major city in a state where your preferred ideological policies have taken full control and been allowed to flourish and metastasize. The American people want to know... how is this all Republicans' fault and does it upset you that they are seizing on the situation?</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

## As Bud Light continues to crumble, America's beer makes a play for the top spot
 - [https://www.louderwithcrowder.com/bud-light-versus-yuengling](https://www.louderwithcrowder.com/bud-light-versus-yuengling)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-07-25T12:44:25+00:00

<img src="https://www.louderwithcrowder.com/media-library/yuengling-makes-a-play-for-bud-light-s-market-share.jpg?id=34662460&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>As Bud Light sales continue to plummet and the beer continues to fall further from the top spot, Yuengling -- the oldest brewery in America -- is making a run at the title. Though, I guess in Bud Light's defense, Anheuser-Busch's Global CEO Michel Doukeris says the decline is 1% of the company's "<a href="https://www.louderwithcrowder.com/bud-light-bars-restaurants" target="_blank">global sales volume</a>." So it's not like AB cares about American beer drinkers.</p><p>The latest numbers show Bud Light tumbled once again, down 26.1% for the week ended July 15 (compared to the previous year). Modello, which had knocked Bud Light off as the #1 sold beer in America, was UP 13/2% from the previous year. Then there is Yunegling, up TWENTY-FIVE PERCENT over the previous year.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/yuenglingbeer/status/1682126668478005253"></a>
</blockquote>

<p>Bump Williams Consulting <a href="https://nypost.com/2023/07/24/modelo-yuengling-are-stealing-away-bud-lights-business/" target="_blank">says if trends continue</a>, expect Yuengling to continue its gain of market share.</p><blockquote>Pennsylvania-based Yuengling, known as “America’s Oldest Beer,” is having a moment, beer experts say. It’s distributed mainly in the eastern US, but has recently been expanding to more states, according to Bump Williams, head of the consultancy.</blockquote><p>There is a lesson to be learned here. Bud Light's downfall began when as part of their NCAA tournament coverage, and to appeal to people who don't like either for some reason, <a href="https://www.louderwithcrowder.com/captiv8-bud-light-dylan-mulvaney">they inked a deal with controversial titface performer Dylan Mulvaney</a>. They could have gone with any of a thousand real girls who are fans of college basketball. Instead, they went with a dude who portrayed a girl so vapid she doesn't know what a "March Madness" is. </p><p>Then to further show how little the company thinks of its fanbase, Melissa Weinerchild, the (now former) VP of Marketing responsible, made it clear on a podcast how much she hated Bud Light's customers, <a href="https://www.louderwithcrowder.com/bud-light-exec-bear-market" target="_self">lashing out at them as fratty and out of touch</a>.</p><p>Yuengling, which unlike the global-corporation-owned Bud Light is still owned by an American family, saw an opportunity. They <a href="https://www.louderwithcrowder.com/yuengling-beer-patriotic-can" target="_blank">promoted their independently owned, pro-America bonafides</a>. And when the Mulvaney BREWhaha started to engulf Bud Light, responded to it with the most perfectly crafted tweet in the history of perfectly crafted tweets.</p><p><br /></p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/yuenglingbeer/status/1646978863971590144"></a>
</blockquote>

<p>Even the two companies' responses to the "culture wars" show a stark contrast. June is when we are ordered to celebrate Ls, Gs, Bs, especially the Ts, Qs, As, and all the rest. Bud Light decided it would be a good idea <a href="https://www.louderwithcrowder.com/bud-light-pride-parade" target="_blank">to sponsor an event where naked men paraded around children</a>. Youngling, upon finding out a sexually-explicit cabaret show <a href="https://www.louderwithcrowder.com/yuengling-drag-show" target="_blank">was being performed for all ages at a venue their name is attached to</a>, got promoters to change the adult-themed show to where it was just for adults.</p><p>Bud Light cared more about pandering to progressive agendas to get some of that sweet ESG money. They are down 26%.</p><p>Yuengling made a play to earn American dollars from beer drinkers who wanted to enjoy beer without the Democrat Party thrusting their agenda on them. They are UP 25%.</p><p>But again, as we heard from Anheuser-Busch's Global CEO Michel Doukeris, they only care about the "global sales volume." It is refreshing to know where their values are.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

## Watch: 'Just Stop Oil' slacktivists finally get taste of their own medicine, trolled with balloons and rape whistles
 - [https://www.louderwithcrowder.com/just-stop-oil-trolled](https://www.louderwithcrowder.com/just-stop-oil-trolled)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-07-25T11:24:45+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=34661598&amp;width=2000&amp;height=1500&amp;coordinates=0%2C0%2C320%2C0" /><br /><br /><p>We here at the Louder with Crowder Dot Com website have become connoisseurs of <a href="https://www.louderwithcrowder.com/tall-female-german-protestors" target="_blank">European eco-zealotry</a> and <a href="https://www.louderwithcrowder.com/block-traffic-guy-drags-unit" target="_blank">schlimate slacktivism</a>. It hasn't popped off at the Waffle House lately, so watching what happens to idiots blocking traffic is the content we both need and deserve. While entertaining to us, people in the UK are sick and tired of "<a href="https://www.louderwithcrowder.com/just-stop-oil-stag-party" target="_blank">Just Stop Oil</a>." They're the people causing chaos as assets to society attempt to commute to work and be useful members of their community. So two YouTubers decided to give JSO a taste of their own medicine.</p><p><a href="https://youtu.be/y6flblkVh1I" target="_blank">Meet Josh & Archie.</a></p><p>This was more of a carefully planned operation than the one viral clip is letting on. They sent someone DEEP uncover on a recognizance mission. </p><blockquote>It turns out, [JSO meets] at Pret a Manager. Where they drink coffee flown in from Peru in single-use cups. We discovered that before ruining everyone's day, the privately educated protestors stand in a circle and teach each one another how to breathe... before deciding who amongst them will be arrested that day.</blockquote><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="0e2a1" src="https://www.louderwithcrowder.com/media-library/image.gif?id=34661631&amp;width=980" />
</p><p>During this undercover recognizance mission, it was discovered the JSO annual banquet was coming up. JSO's "Beyond F*cked Banquet." Get it? Because the planet is beyond f*cked or something.</p><p>The taste of comeuppance has never been so succulent.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/OldRowOfficial/status/1683557191922614276"></a>
</blockquote>
<p>The pranksters attached rape whistles to helium balloons and let the balloons loose in the cathedral ceilings. The ear-piercing alarms went off disrupting the fancy banquet and ruining the speeches. Not unlike how the slacktivists disrupt the daily lives of normal people.</p><p>The brilliance of using balloons is that they couldn't be reached once they hit the top of the vaulted ceilings. Hence the unintentionally hilarious scene of JSOers trying to figure out how ladders work.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="de0ac" src="https://www.louderwithcrowder.com/media-library/image.png?id=34661835&amp;width=980" />
</p><p>Sadly, like most left-wing performative slacktivists, the point will go over their head along with the rape whistles. JSO will continue its misguided crusade to convince people the planet is on fire by pissing off everyone around them to the point they hate JSO and everything the organization stands for. Case in point, Josh & Archie? They sound a lot more sympathetic to "the cause" than most of us reading this and reveling in the content.</p><p>The greatest disappointment is how <a href="https://www.louderwithcrowder.com/southampton-golf-club" target="_blank">low-energy eco-wackadoodles are in America</a>. Are they useless sacks of soy? No doubt. But they're 'Merican useless sacks of the soy so you still want to see them kick ass as the best useless sacks of soy. Compared to their UK counterparts, I don't believe any of them in this country are committed or all that concerned about the schlimate this week.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

