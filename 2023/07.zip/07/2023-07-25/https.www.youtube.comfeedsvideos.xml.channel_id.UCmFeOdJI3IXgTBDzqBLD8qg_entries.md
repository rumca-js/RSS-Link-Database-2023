# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## The Incredibly Satisfying Death of Disney
 - [https://www.youtube.com/watch?v=vu7AzvVWYuI](https://www.youtube.com/watch?v=vu7AzvVWYuI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2023-07-25T11:32:23+00:00

Skip the waitlist and invest in blue-chip art for the very first time by signing up for Masterworks: https://www.masterworks.art/moon

Purchase shares in great masterpieces from artists like Pablo Picasso, Banksy, Andy Warhol, and more. 
See important Masterworks disclosures: https://www.masterworks.com/cd

Title taken from Sunnyv2's great video here: https://www.youtube.com/watch?v=ik6FvS1kVCc

Free weekly essays written by Moon - https://mailchi.mp/3ded12821743/moon

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT

Disney's current state is more concerning than previously imagined. The corporation's business model is faltering, leading to questions about the sustainability of Disney's legacy. This ongoing downturn is the reason for the prevalent negative perceptions about Disney. The company is now facing financial difficulties, enduring a decrease in stock value and grappling to generate substantial profits. This downward spiral is primarily attributed to Disney's recent shift towards more socially progressive narratives.

We are witnessing an impending crisis within Disney's business sphere. This video will provide an in-depth examination of the plunge in Disney's stock value, future predictions for the stock market, and reasons behind Disney's faltering revenue stream.

