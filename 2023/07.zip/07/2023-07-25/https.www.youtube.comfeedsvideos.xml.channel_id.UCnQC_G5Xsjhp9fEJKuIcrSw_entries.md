# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## ESPN Host Goes OFF on Ron DeSantis
 - [https://www.youtube.com/watch?v=Xd7xtBEW5kQ](https://www.youtube.com/watch?v=Xd7xtBEW5kQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-07-25T21:30:04+00:00

Stephen A. Smith, ESPN host, has sounded off on Governor Ron DeSantis. According to Smith, his policies are racist. That is very interesting coming from a black ESPN host making $13,000,000 a year.

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣  Watch the full episode here: Ep. 1773 - https://youtu.be/Evfp5rHESNc

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Get up to 20% OFF + 2 FREE pillows with all mattress orders: https://helixsleep.com/BEN

Save 25% off your Emergency Food Supply at
http://www.preparewithBen.com/ 

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #espn #stephenasmith #sports #sportsnews #desantis #2024 #election

## The Barbie Debate | @TheCommentsSection
 - [https://www.youtube.com/watch?v=fVoiQa03ywg](https://www.youtube.com/watch?v=fVoiQa03ywg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-07-25T21:15:01+00:00

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

#shorts

## Ben & Brett DEBATE Barbie
 - [https://www.youtube.com/watch?v=aAm5I8i_n0w](https://www.youtube.com/watch?v=aAm5I8i_n0w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-07-25T20:14:39+00:00

Watch the full video here https://youtu.be/nEkyqtcXbyc

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

 #shorts @TheCommentsSection

## Ben Shapiro and Brett Brett Cooper Debate Barbie for 30 Minutes
 - [https://www.youtube.com/watch?v=nEkyqtcXbyc](https://www.youtube.com/watch?v=nEkyqtcXbyc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-07-25T20:00:13+00:00

Ben and Brett both saw Barbie...One of them liked it, and one of them hated it. Whose side are you taking?

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep. 1773 - https://youtu.be/Evfp5rHESNc

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Text "BEN" to 989898, or go to https://birchgold.com/ben, to claim your free infokit today!

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #barbie #barbiemovie #boxoffice #moviereview #brettcooper

## Biden Will Be Impeached
 - [https://www.youtube.com/watch?v=Evfp5rHESNc](https://www.youtube.com/watch?v=Evfp5rHESNc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-07-25T17:00:08+00:00

As Hunter Biden’s former business partner Devon Archer prepares to testify, the stage is set for Joe Biden’s possible impeachment; Republicans struggle to fill the stage for their first presidential debate; and Israel passes a judicial reform package, prompting spasms of apoplexy.

Ep.1773

1️⃣ Click here to join the member exclusive portion of my show:  https://bit.ly/41LQK62

2️⃣  Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Shop all Jeremy’s Razors products here: https://bit.ly/3xuFD43 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Helix - Get up to 20% OFF + 2 FREE pillows with all mattress orders: https://helixsleep.com/BEN

Birch Gold - Text "BEN" to 989898, or go to https://birchgold.com/ben, for your no-cost, no-obligation, FREE information kit.

My Patriot Supply - Save 25% off your Emergency Food Supply at http://www.preparewithBen.com/ 

- - -

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire

## Foreskin Is the Secret Ingredient?
 - [https://www.youtube.com/watch?v=bZ6ibUJvFXg](https://www.youtube.com/watch?v=bZ6ibUJvFXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-07-25T00:30:24+00:00

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

#shorts

