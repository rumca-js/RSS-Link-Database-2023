# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Wiceminister pochwalił się podatkami. Dostał mocną ripostę od eksperta
 - [https://www.money.pl/podatki/wiceminister-pochwalil-sie-podatkami-dostal-mocna-riposte-od-eksperta-6923528600365696a.html](https://www.money.pl/podatki/wiceminister-pochwalil-sie-podatkami-dostal-mocna-riposte-od-eksperta-6923528600365696a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T19:49:56+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7e39c21b-44a7-4b22-ab2c-00a7d512e954" width="308" /> "Można rozmawiać o niskich podatkach, a można też je realnie wprowadzić w życie. Tak trzeba żyć" – napisał na Twitterze Artur Soboń. Wiceminister pochwalił się efektywną średnią stawką PIT, jaką zapłacili Polacy. Na odpowiedź nie musiał długo czekać. Ekspert wytknął mu składkę zdrowotną.

## Trwa rozgrywka wokół ukraińskiego zboża. Pojawił się nowy pomysł
 - [https://www.money.pl/gospodarka/trwa-rozgrywka-wokol-ukrainskiego-zboza-pojawil-sie-nowy-pomysl-6923507860888192a.html](https://www.money.pl/gospodarka/trwa-rozgrywka-wokol-ukrainskiego-zboza-pojawil-sie-nowy-pomysl-6923507860888192a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T18:35:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/228f8826-87b6-4660-bc7f-7b2cc24d69b6" width="308" /> Unia Europejska mogłaby wyeksportować ukraińskie zboże "korytarzami solidarności". Bruksela partycypowałaby też w kosztach tego przedsięwzięcia – ogłosił unijny komisarz ds. rolnictwa Janusz Wojciechowski. Robert Telus natomiast powtórzył, że Polska jednostronnie zamknie granice w razie braku porozumienia.

## Kolejna grecka wyspa płonie. Pożary trawią też Korfu
 - [https://www.money.pl/gospodarka/kolejna-grecka-wyspa-plonie-pozary-trawia-tez-korfu-6923489016810464a.html](https://www.money.pl/gospodarka/kolejna-grecka-wyspa-plonie-pozary-trawia-tez-korfu-6923489016810464a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T17:08:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3b72c700-57f9-4479-b6b2-510e6a2280ba" width="308" /> Nie udało się służbom opanować pożaru lasu na greckiej wyspie Korfu. Tym samym ogień objął już domy w miejscowości Loutses – podał portal ekathimerini.com. Z żywiołem walczą ramię w ramię: straż pożarna, policja i wolontariusze. Do akcji dołączyły też trzy samoloty gaśnicze.

## Rekordowy kontrakt w NBA. Żaden koszykarz nie zarobił tyle, ile dostanie Jaylen Brown
 - [https://www.money.pl/gospodarka/rekordowy-kontrakt-w-nba-zaden-koszykarz-nie-zarobil-tyle-ile-dostanie-jaylen-brown-6923479718656992a.html](https://www.money.pl/gospodarka/rekordowy-kontrakt-w-nba-zaden-koszykarz-nie-zarobil-tyle-ile-dostanie-jaylen-brown-6923479718656992a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T16:31:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7d0360c2-2177-472e-affe-f074da3582b4" width="308" /> Jaylen Brown doszedł do porozumienia z Boston Celtics w sprawie nowej, pięcioletniej umowy. Koszykarz wkrótce podpisze kontrakt, który zapewni mu rekordową gażę w historii NBA

## Zniesienie podatku PCC. Kogo dotyczy zmiana, która wchodzi w życie?
 - [https://www.money.pl/podatki/zniesienie-podatku-pcc-kogo-dotyczy-zmiana-ktora-wchodzi-w-zycie-6923473888246752a.html](https://www.money.pl/podatki/zniesienie-podatku-pcc-kogo-dotyczy-zmiana-ktora-wchodzi-w-zycie-6923473888246752a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T16:07:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/034f8e0f-6ee8-4435-ba9e-cacdda0e5d0a" width="308" /> Zniesienie  podatku od czynności cywilnoprawnych wprowadzono nowelizacją ustawy, która została  podpisana przez prezydenta 25 lipca. Nowe przepisy znoszą  podatek od czynności cywilnoprawnych przy zakupie pierwszego mieszkania na rynku wtórnym.

## Stary spór Polski i Europy wkrótce odżyje. O zboże z Ukrainy
 - [https://www.money.pl/gospodarka/stary-spor-polski-i-europy-wkrotce-odzyje-o-zboze-z-ukrainy-6923453988092896a.html](https://www.money.pl/gospodarka/stary-spor-polski-i-europy-wkrotce-odzyje-o-zboze-z-ukrainy-6923453988092896a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T15:01:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/01afd824-e674-43a0-9509-5eefddb793f9" width="308" /> Francja i Niemcy nie chcą przedłużenia zakazu importu zbóż z Ukrainy, które obowiązuje do 15 września. To nie podoba się Polsce i innym państwom przyfrontowym. Przedstawiciel polskiej dyplomacji przestrzegł Brukselę, że nasi rolnicy mogą nie przetrwać.

## Lotnisko na Mazurach kolejny rok na minusie. Port jednak "realizuje misję publiczną"
 - [https://www.money.pl/gielda/lotnisko-na-mazurach-kolejny-rok-na-minusie-port-jednak-realizuje-misje-publiczna-6923444122888832a.html](https://www.money.pl/gielda/lotnisko-na-mazurach-kolejny-rok-na-minusie-port-jednak-realizuje-misje-publiczna-6923444122888832a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T14:06:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a8d752d9-d149-4411-8cb7-60bd9692f32b" width="308" /> Port Lotniczy Olsztyn-Mazury w 2022 r. zanotował stratę, zresztą już kolejny raz. Na Warmii i Mazurach trwa zresztą dyskusja nad sensem posiadania lotniska. Zwolennicy mówią, że to "okno na świat" regionu. Krytycy natomiast – że to skarbonka bez dna.

## Ogromna pomoc dla Ukrainy. Przekroczona kolejna granica
 - [https://www.money.pl/gospodarka/ogromna-pomoc-dla-ukrainy-przekroczona-kolejna-granica-6923438915271296a.html](https://www.money.pl/gospodarka/ogromna-pomoc-dla-ukrainy-przekroczona-kolejna-granica-6923438915271296a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T13:45:00+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6bec77a1-8e06-46ed-88d9-b8d5147bec56" width="308" /> Wartość polskiej pomocy wojskowej dla Ukrainy sięgnęła 3 miliardów euro, czyli ponad 13 miliardów złotych - informuje portal Defence24.pl, dodając, że nie wiadomo jednak, czy i w jakim stopniu kwota ta obejmuje możliwe dostawy transporterów opancerzonych Rosomak dla Kijowa.

## Jak prowadzić skuteczne negocjacje wynagrodzenia?
 - [https://www.money.pl/gospodarka/jak-prowadzic-skuteczne-negocjacje-wynagrodzenia-6923348819659744a.html](https://www.money.pl/gospodarka/jak-prowadzic-skuteczne-negocjacje-wynagrodzenia-6923348819659744a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T13:39:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cc4b17ff-2370-49f6-8f7d-de66bd135d42" width="308" /> Już na etapie prowadzenia rozmów kwalifikacyjnych z potencjalnym pracodawcą, można i warto negocjować wynagrodzenie, jakie firma jest w stanie zaproponować. Przy pokonywaniu kolejnych szczebli kariery zawodowej negocjacje pomagają zwiększyć zarobki. Jak rozmawiać z pracodawcom? Jak skutecznie negocjować wynagrodzenie?

## Refinansowanie kredytów opartych o stałą stopę. Jest ważne oświadczenie KNF
 - [https://www.money.pl/banki/kredyt-mieszkaniowy-refinansowanie-kredytow-opartych-o-stala-stope-jest-wazne-oswiadczenie-knf-6923426616654816a.html](https://www.money.pl/banki/kredyt-mieszkaniowy-refinansowanie-kredytow-opartych-o-stala-stope-jest-wazne-oswiadczenie-knf-6923426616654816a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T13:06:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d413e685-98e0-4995-a098-d32f57bffbeb" width="308" /> UKNF nie odbiera kredytobiorcom możliwości zrefinansowania kredytów mieszkaniowych zaciągniętych na okresowo stałą stopę procentową, w celu obniżenia kosztów w perspektywie potencjalnej obniżki stóp procentowych – poinformował PAP Biznes Jacek Jastrzębski, przewodniczący Komisji Nadzoru Finansowego.

## Szef MSZ Chin "zapadł się pod ziemię". Zdecydowano o jego karierze
 - [https://www.money.pl/gospodarka/szef-msz-chin-zapadl-sie-pod-ziemie-zdecydowano-o-jego-karierze-6923419591801472a.html](https://www.money.pl/gospodarka/szef-msz-chin-zapadl-sie-pod-ziemie-zdecydowano-o-jego-karierze-6923419591801472a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T12:26:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ae98e2ac-9821-4c27-b9d2-51d818c25f34" width="308" /> Minister spraw zagranicznych Chin Qin Gang nie był widziany publicznie od miesiąca. Chiński parlament ogłosił usunięcie 57-letniego Qin Gang ze stanowiska ministra spraw zagranicznych kraju - informuje rosyjski dziennik "Kommiersant".

## Koniec z patodeweloperką? Są ważne zmiany w przepisach
 - [https://www.money.pl/gospodarka/koniec-z-patodeweloperka-sa-wazne-zmiany-w-przepisach-6923411883174880a.html](https://www.money.pl/gospodarka/koniec-z-patodeweloperka-sa-wazne-zmiany-w-przepisach-6923411883174880a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T11:55:00+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3534585f-3abb-4c0b-93e9-c30d11efd144" width="308" /> Podpisana przez prezydenta nowela ws. planowania przestrzennego uprości przepisy tak, by gminy sprawniej uchwalały plany ogólne i miejscowe - podkreślił minister rozwoju i technologii Waldemar Buda. Dodał, że nowe prawo ma ograniczyć patodeweloperkę i tzw. rozlewanie się miast.

## Nadchodzi rewolucja w nieruchomościach. Prezydent podpisał ustawę
 - [https://www.money.pl/gospodarka/nadchodzi-rewolucja-w-nieruchomosciach-prezydent-podpisal-ustawe-6923406524643968a.html](https://www.money.pl/gospodarka/nadchodzi-rewolucja-w-nieruchomosciach-prezydent-podpisal-ustawe-6923406524643968a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T11:33:11+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cb470beb-6735-4b54-b3ee-15acfa3199a2" width="308" /> Prezydent Andrzej Duda podpisał ustawę ws. likwidacji użytkowania wieczystego, która umożliwi firmom, osobom fizycznym i spółdzielniom mieszkaniowym wykup gruntów. Regulacja przewiduje też, że nabycie pierwszego mieszkania będzie zwolnione z PCC, ale też PCC w wysokości 6 proc. ma objąć zakup co najmniej sześciu mieszkań w jednej inwestycji.

## Ceny produktów rolnych będą regulowane? Minister odpalił "bombę"
 - [https://www.money.pl/gospodarka/ceny-produktow-rolnych-beda-regulowane-minister-odpalil-bombe-6923153844980704a.html](https://www.money.pl/gospodarka/ceny-produktow-rolnych-beda-regulowane-minister-odpalil-bombe-6923153844980704a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T11:04:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2ff6b898-31e2-4211-a419-cc9dd67fd18e" width="308" /> – Zależy mi, by rolnik nie musiał, jak do tej pory, sprzedawać po cenie poniżej kosztów – powiedział Robert Telus. Zapowiedział ustawę, która ma to uregulować. Rolnicy się cieszą, eksperci ostrzegają.

## Książeczka mieszkaniowa po nowemu. Drugi bank ma w ofercie Konto Mieszkaniowe
 - [https://www.money.pl/banki/ksiazeczka-mieszkaniowa-po-nowemu-drugi-bank-ma-w-ofercie-konto-mieszkaniowe-6923386843880064a.html](https://www.money.pl/banki/ksiazeczka-mieszkaniowa-po-nowemu-drugi-bank-ma-w-ofercie-konto-mieszkaniowe-6923386843880064a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T10:13:08+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bb9c1b9a-245e-4794-9d0f-117dbf933b45" width="308" /> W ofercie Alior Banku dostępne jest już Konto Mieszkaniowe, będące elementem rządowego programu Pierwsze Mieszkanie. Konto ma umożliwić długoterminowe oszczędzanie na zakup mieszkanie oraz uzyskanie premii mieszkaniowej z Rządowego Funduszu Mieszkaniowego.

## Ukrainki kluczowe dla PKB. Kijów straci miliardy euro, jeśli nie wrócą do kraju po wojnie
 - [https://www.money.pl/gospodarka/ukrainki-kluczowe-dla-pkb-kijow-straci-miliardy-euro-jesli-nie-wroca-do-kraju-po-wojnie-6923347083254400a.html](https://www.money.pl/gospodarka/ukrainki-kluczowe-dla-pkb-kijow-straci-miliardy-euro-jesli-nie-wroca-do-kraju-po-wojnie-6923347083254400a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T08:09:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f2be84b2-68ed-4fa5-ab0a-95a575e5fb0a" width="308" /> Blisko 70 proc. uchodźców z Ukrainy to kobiety. Zdaniem analityka agencji Bloomberga Aleksandra Isakowa, jeśli 2,8 mln kobiet w wieku produkcyjnym, które opuściły Ukrainę, nie powróci do niej po wojnie, będzie to kosztować kraj 10 proc. przedwojennego PKB.

## Nastroje w gospodarce. GUS podał najnowsze dane
 - [https://www.money.pl/gospodarka/koniunktura-w-przetworstwie-przemyslowym-budownictwie-handlu-i-uslugach-lipiec-2023-r-6915652739029728a.html](https://www.money.pl/gospodarka/koniunktura-w-przetworstwie-przemyslowym-budownictwie-handlu-i-uslugach-lipiec-2023-r-6915652739029728a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T08:04:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1a575b42-e598-48f5-9e23-f63e36a38ce3" width="308" /> Poprawę koniunktury sygnalizuje 7,9 proc. przedsiębiorstw, a jej pogorszenie 21,9 proc. (przed miesiącem odpowiednio 8,6 proc. i 20,4 proc.) – podał GUS, który we wtorek opublikował szczegółowe dane dotyczące koniunktury gospodarczej w lipcu.

## Seniorzy zyskają. Nowość w 500 plus
 - [https://www.money.pl/emerytury/dobre-wiesci-dla-seniorow-szykuja-sie-duze-zmiany-w-500-plus-6923352310119040a.html](https://www.money.pl/emerytury/dobre-wiesci-dla-seniorow-szykuja-sie-duze-zmiany-w-500-plus-6923352310119040a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T07:52:36+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6012c0d5-40ae-4990-a0b3-819a46d535b2" width="308" /> W przyszłym roku podwyższone ma zostać kryterium uprawniające do pobierania 500 plus dla osób niezdolnych do samodzielnej egzystencji - donosi "Fakt". Seniorzy mogą sporo zyskać.

## Wypłata 14. emerytury jeszcze przed wyborami. Premier Morawiecki podał termin
 - [https://www.money.pl/emerytury/wyplata-14-emerytury-jeszcze-przed-wyborami-premier-morawiecki-podal-termin-6923336957258368a.html](https://www.money.pl/emerytury/wyplata-14-emerytury-jeszcze-przed-wyborami-premier-morawiecki-podal-termin-6923336957258368a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T07:14:51+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/623924fc-e072-40ba-ab57-90a6fe3dc03c" width="308" /> Czternasta emerytura będzie wypłacona na przełomie sierpnia i września - poinformował premier Mateusz Morawiecki. Dodatkowe pieniądze otrzymają miliony seniorów.

## Kursy walut 25.07.2023. Wtorkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-25-07-2023-wtorkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6923312877050496a.html](https://www.money.pl/pieniadze/kursy-walut-25-07-2023-wtorkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6923312877050496a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T05:12:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 25.07.2023. We wtorek za jednego dolara (USD) zapłacimy 4,02 zł. Cena jednego funta szterlinga (GBP) to 5,16 zł, a franka szwajcarskiego (CHF) 4,63 zł. Z kolei euro (EUR) możemy zakupić za 4,45 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 25.07.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-25-07-2023-6923310708386784a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-25-07-2023-6923310708386784a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T05:03:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 25.07.2023. We wtorek za jednego dolara (USD) trzeba zapłacić 4.0206 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 25.07.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-25-07-2023-6923310703577728a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-25-07-2023-6923310703577728a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T05:03:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 25.07.2023. We wtorek za jedno euro (EUR) trzeba zapłacić 4.4513 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 25.07.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-25-07-2023-6923310703746016a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-25-07-2023-6923310703746016a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T05:03:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 25.07.2023. We wtorek za jednego franka (CHF) trzeba zapłacić 4.6247 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 25.07.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-25-07-2023-6923310703819392a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-25-07-2023-6923310703819392a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T05:03:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 25.07.2023. We wtorek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.1596 zł.

## Darmowy kredyt nie tylko dla frankowiczów. Kolejni klienci upominają się o swoje
 - [https://www.money.pl/banki/darmowy-kredyt-nie-tylko-dla-frankowiczow-kolejni-klienci-upominaja-sie-o-swoje-6923131917499360a.html](https://www.money.pl/banki/darmowy-kredyt-nie-tylko-dla-frankowiczow-kolejni-klienci-upominaja-sie-o-swoje-6923131917499360a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-07-25T03:55:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2e776046-29de-4ebe-aa49-81d47f278c19" width="308" /> Na rynku finansowym tli się kolejny problem. Klienci banków i firm pożyczkowych sięgają po przepisy, które mogą pomóc im obniżyć comiesięczne raty. Skorzystać mogą też osoby, których umowy zostały zerwane za niespłacanie zobowiązań.

