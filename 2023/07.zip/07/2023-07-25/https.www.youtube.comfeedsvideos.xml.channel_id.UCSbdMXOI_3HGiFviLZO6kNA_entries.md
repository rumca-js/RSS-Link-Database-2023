# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## QUEST AND VR Full Body Tracking BOTH Get MASSIVE Updates!
 - [https://www.youtube.com/watch?v=1tQR1mhtyxA](https://www.youtube.com/watch?v=1tQR1mhtyxA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2023-07-25T21:26:04+00:00

Hello and welcome to TUESDAY NEWSDAY! WOW, we actually had a really exciting week this week... Feels so good! From Sony Mocopi getting SIGNIFICANTLY Better thanks to them listening to feedback to Quest 2 getting some great updates to Quest Pro and 3 getting multimodal support!
All that and so much more.. this was a good week :)

QUEST 3 GIVEAWAY: https://gleam.io/yfr80/amazevr-quest-3-giveaway
AMAZE VR: https://www.oculus.com/experiences/quest/6513803575318188/?utm_source=amazevr.com&amp;utm_medium=button&amp;utm_campaign=meta-quest-download-button


Join my discord!
Discord.gg/Thrill 
Patreon.com/thrillseeker
Twitch.tv/Thrilluwu
Outro music: https://www.youtube.com/watch?v=u6JwgNQDVfI&amp;pp=ygUMVGhyaWxsIG1hZ2lj

TIMESTAMPS:
00:00 Intro 
00:50 Amaze VR
01:41 v56
02:52 Multimodal support
04:57 Mocopi
07:55 Meme Break
08:45 Platform Integrity Attestation
09:58 Hades Widebody
10:33 Custom Mixed Reality headseT
10:44 BigScreen Beyond Flip Up Visor
11:06 QOTW
12:53 Outro

