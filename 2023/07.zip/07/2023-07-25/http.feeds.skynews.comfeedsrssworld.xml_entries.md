# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## 'Fire of the century' for Corfu as some locals suspect arsonists behind blazes
 - [https://news.sky.com/story/fire-of-the-century-for-corfu-as-some-locals-suspect-arsonists-behind-blazes-on-greek-island-12927447](https://news.sky.com/story/fire-of-the-century-for-corfu-as-some-locals-suspect-arsonists-behind-blazes-on-greek-island-12927447)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T19:18:00+00:00

I'm standing watching a helicopter scoop water out of the Ionian Sea and dump it onto flames being blown down the steep slopes of northeast Corfu towards a school and villas below.

## 'I have nothing left': Rhodes stable owner picks up the pieces after wildfire destroys livelihood
 - [https://news.sky.com/story/i-have-nothing-left-rhodes-stable-owner-picks-up-the-pieces-after-wildfire-destroys-livelihood-12927354](https://news.sky.com/story/i-have-nothing-left-rhodes-stable-owner-picks-up-the-pieces-after-wildfire-destroys-livelihood-12927354)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T16:30:00+00:00

Dimitris has lost everything.

## Trump's US presidential rival Ron DeSantis involved in car crash
 - [https://news.sky.com/story/us-presidential-hopeful-ron-desantis-involved-in-car-crash-12927232](https://news.sky.com/story/us-presidential-hopeful-ron-desantis-involved-in-car-crash-12927232)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T13:30:00+00:00

US presidential hopeful Ron DeSantis has been involved in a car crash.

## British family fleeing Rhodes face nightmare 'towering inferno compared with Titanic'
 - [https://news.sky.com/story/british-family-fleeing-rhodes-face-nightmare-scenario-of-towering-inferno-compared-with-titanic-12927199](https://news.sky.com/story/british-family-fleeing-rhodes-face-nightmare-scenario-of-towering-inferno-compared-with-titanic-12927199)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T13:04:00+00:00

A British holidaymaker has described the nightmare scenario he faced as he fled wildfire-ravaged Rhodes with his wife and two young children.

## China's outspoken foreign minister removed from office
 - [https://news.sky.com/story/qin-gang-chinas-outspoken-foreign-minister-removed-from-office-after-weeks-of-unexplained-absence-12927158](https://news.sky.com/story/qin-gang-chinas-outspoken-foreign-minister-removed-from-office-after-weeks-of-unexplained-absence-12927158)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T12:01:00+00:00

China's outspoken foreign minister - who has not been seen publicly for a month - has been removed from office and replaced by his predecessor.

## Will extreme weather change our summer holidays forever?
 - [https://news.sky.com/story/will-extreme-weather-change-our-summer-holidays-forever-12927117](https://news.sky.com/story/will-extreme-weather-change-our-summer-holidays-forever-12927117)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T10:35:00+00:00

Wildfires on the Greek islands of Rhodes and Corfu have seen hundreds of British holidaymakers evacuated.

## BBC admits asking 'inappropriate' question to player at Women's World Cup
 - [https://news.sky.com/story/bbc-admit-asking-inappropriate-question-to-morocco-captain-at-womens-world-cup-12927107](https://news.sky.com/story/bbc-admit-asking-inappropriate-question-to-morocco-captain-at-womens-world-cup-12927107)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T10:17:00+00:00

The BBC has admitted asking an "inappropriate" question about sexuality to the Moroccan captain at the Women's World Cup.

## Thousands of Britons flown from Rhodes to UK - as new evacuation order issued on island
 - [https://news.sky.com/story/rhodes-wildfires-thousands-of-britons-flown-back-to-uk-as-10-of-land-on-greek-island-burned-12927061](https://news.sky.com/story/rhodes-wildfires-thousands-of-britons-flown-back-to-uk-as-10-of-land-on-greek-island-burned-12927061)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T09:08:00+00:00

Thousands of Britons have been flown back from Rhodes - with new estimates suggesting 10% of land on the Greek island has been burned by wildfires.

## Crypto scheme that scans people's eyeballs being looked at by UK regulator
 - [https://news.sky.com/story/worldcoin-chatgpt-bosss-crypto-project-that-scans-peoples-eyeballs-being-looked-at-by-uk-regulator-12927038](https://news.sky.com/story/worldcoin-chatgpt-bosss-crypto-project-that-scans-peoples-eyeballs-being-looked-at-by-uk-regulator-12927038)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T08:39:00+00:00

The UK data watchdog is looking into a cryptocurrency scheme launched by OpenAI boss Sam Altman that offers digital coins in exchange for eyeball scans.

## What is the Fire Weather Index and how does it work?
 - [https://news.sky.com/story/what-is-the-fire-weather-index-and-how-does-it-work-12927035](https://news.sky.com/story/what-is-the-fire-weather-index-and-how-does-it-work-12927035)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T08:31:00+00:00

Thousands of tourists have had to escape to safety as huge wildfires continue to rage on the Greek islands of Rhodes and Corfu.

## Woman and parents arrested after headless body found in hotel bathtub
 - [https://news.sky.com/story/woman-and-parents-arrested-after-headless-body-found-in-bathtub-at-japan-love-hotel-12927019](https://news.sky.com/story/woman-and-parents-arrested-after-headless-body-found-in-bathtub-at-japan-love-hotel-12927019)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T08:00:00+00:00

A woman and her parents have been arrested after a headless body was discovered in a hotel bathtub in Japan.

## Six guilty over Brussels airport and train attack that killed 32
 - [https://news.sky.com/story/eight-men-convicted-over-2016-brussels-terror-attacks-that-left-32-people-dead-12926628](https://news.sky.com/story/eight-men-convicted-over-2016-brussels-terror-attacks-that-left-32-people-dead-12926628)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T07:00:00+00:00

Six men have been found guilty of murder over the 2016 Brussels terror attacks that left 32 people dead.

## Woman whose kidnapping sparked nationwide search admits she wasn't abducted
 - [https://news.sky.com/story/carlee-russell-woman-whose-kidnapping-sparked-nationwide-search-admits-she-wasnt-abducted-12926962](https://news.sky.com/story/carlee-russell-woman-whose-kidnapping-sparked-nationwide-search-admits-she-wasnt-abducted-12926962)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T06:16:00+00:00

A woman has admitted that she lied about being kidnapped in Alabama.

## Oppenheimer sex scene featuring sacred Hindu text sparks outrage in India
 - [https://news.sky.com/story/oppenheimer-sex-scene-featuring-sacred-hindu-text-bhagavad-gita-sparks-outrage-in-india-12926956](https://news.sky.com/story/oppenheimer-sex-scene-featuring-sacred-hindu-text-bhagavad-gita-sparks-outrage-in-india-12926956)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-07-25T06:08:00+00:00

A sex scene in box office smash hit Oppenheimer has sparked outrage in India with social media users threatening to boycott the nuclear arms biopic.

