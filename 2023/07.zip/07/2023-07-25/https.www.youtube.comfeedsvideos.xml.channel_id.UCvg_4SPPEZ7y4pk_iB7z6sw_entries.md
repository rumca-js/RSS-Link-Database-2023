# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Q&A
 - [https://www.youtube.com/watch?v=RkHoS7pcai0](https://www.youtube.com/watch?v=RkHoS7pcai0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2023-07-25T06:12:05+00:00

squee

