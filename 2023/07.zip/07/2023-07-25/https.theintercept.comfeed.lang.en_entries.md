# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## As Actors Strike for AI Protections, Netflix Lists $900,000 AI Job
 - [https://theintercept.com/2023/07/25/strike-hollywood-ai-disney-netflix/](https://theintercept.com/2023/07/25/strike-hollywood-ai-disney-netflix/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-07-25T16:32:38+00:00

<p>Rob Delaney said, “My melodious voice? My broad shoulders and dancer’s undulating buttocks? I decide how those are used!”</p>
<p>The post <a href="https://theintercept.com/2023/07/25/strike-hollywood-ai-disney-netflix/" rel="nofollow">As Actors Strike for AI Protections, Netflix Lists $900,000 AI Job</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

