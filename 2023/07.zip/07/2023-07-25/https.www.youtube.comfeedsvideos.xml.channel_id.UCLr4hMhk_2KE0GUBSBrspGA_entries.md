# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Umarł Twitter, niech żyje X
 - [https://www.youtube.com/watch?v=6As4dJZ3mTc](https://www.youtube.com/watch?v=6As4dJZ3mTc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2023-07-25T15:45:54+00:00



