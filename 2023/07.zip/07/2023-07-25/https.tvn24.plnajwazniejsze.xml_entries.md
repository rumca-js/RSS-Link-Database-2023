# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Bardzo niepokojące" wieści w sprawie Poczobuta. "Od 6 lipca Andrzej po prostu zniknął"
 - [https://tvn24.pl/polska/andrzej-poczobut-marek-zaniewski-wiceprezes-zwiazku-polakow-na-bialorusi-przekazal-nowe-informacje-w-sprawie-dziennikarza-i-aktywisty-polskiej-mniejszosci-7258382?source=rss](https://tvn24.pl/polska/andrzej-poczobut-marek-zaniewski-wiceprezes-zwiazku-polakow-na-bialorusi-przekazal-nowe-informacje-w-sprawie-dziennikarza-i-aktywisty-polskiej-mniejszosci-7258382?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T20:11:40+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kh5mr-andrzej-poczobut-7140639/alternates/LANDSCAPE_1280" />
    Przekazał wiceprezes Związku Polaków na Białorusi Marek Zaniewski.

## Trąba powietrzna na Podkarpaciu. Wiatr zrywał dachy
 - [https://tvn24.pl/tvnmeteo/polska/podkarpacie-traba-powietrzna-wiatr-zrywal-dachy-7258422?source=rss](https://tvn24.pl/tvnmeteo/polska/podkarpacie-traba-powietrzna-wiatr-zrywal-dachy-7258422?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T20:03:08+00:00

<img alt="Trąba powietrzna na Podkarpaciu. Wiatr zrywał dachy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8pyqg4-traba-drv-7258465/alternates/LANDSCAPE_1280" />
    Niebezpiecznie było w różnych częściach województwa.

## Ludzkie szczątki tuż pod oknami, "na współczesnym, pięknym osiedlu"
 - [https://tvn24.pl/tvnwarszawa/praga-polnoc/warszawa-badacze-odkryli-szczatki-ludzkie-na-terenie-dawnego-wiezienia-toledo-na-pradze-7258391?source=rss](https://tvn24.pl/tvnwarszawa/praga-polnoc/warszawa-badacze-odkryli-szczatki-ludzkie-na-terenie-dawnego-wiezienia-toledo-na-pradze-7258391?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T19:58:38+00:00

<img alt="Ludzkie szczątki tuż pod oknami, " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2wvyl5-specjalisci-ipn-odkryli-na-terenie-dawnego-aresztu-kolejne-szczatki-ludzkie-7258401/alternates/LANDSCAPE_1280" />
    Ofiary stalinowskich zbrodni.

## Ludzie uciekali przed ścianą ognia. Nie żyją 34 osoby
 - [https://tvn24.pl/tvnmeteo/swiat/ludzie-uciekali-przed-sciana-ognia-nie-zyja-34-osoby-7258188?source=rss](https://tvn24.pl/tvnmeteo/swiat/ludzie-uciekali-przed-sciana-ognia-nie-zyja-34-osoby-7258188?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T19:02:21+00:00

<img alt="Ludzie uciekali przed ścianą ognia. Nie żyją 34 osoby" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-s1hdbq-pozary-w-algierii-7258212/alternates/LANDSCAPE_1280" />
    Pożary trawią Algierię.

## Morawska-Stanecka: sprawa pani Joanny nie powinna być obojętna dla żadnego obywatela
 - [https://tvn24.pl/polska/sprawa-pani-joanny-morawska-stanecka-nie-powinna-byc-obojetna-dla-zadnego-obywatela-7258204?source=rss](https://tvn24.pl/polska/sprawa-pani-joanny-morawska-stanecka-nie-powinna-byc-obojetna-dla-zadnego-obywatela-7258204?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T18:58:39+00:00

<img alt="Morawska-Stanecka: sprawa pani Joanny nie powinna być obojętna dla żadnego obywatela" src="https://tvn24.pl/najnowsze/cdn-zdjecie-thkidp-25-1930-fpf-cl-0046-7258298/alternates/LANDSCAPE_1280" />
    Gabriela Morawska-Stanecka i Monika Wielichowska w "Faktach po Faktach".

## Kolejni rezerwiści chcą wstrzymania służby. Minister o "przyłożeniu pistoletu do głowy rządu"
 - [https://tvn24.pl/polska/izrael-parlament-poparl-ustawe-o-zmianach-w-sadownictwie-protestuja-rezerwisci-i-lekarze-7258318?source=rss](https://tvn24.pl/polska/izrael-parlament-poparl-ustawe-o-zmianach-w-sadownictwie-protestuja-rezerwisci-i-lekarze-7258318?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T18:46:27+00:00

<img alt="Kolejni rezerwiści chcą wstrzymania służby. Minister o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hivjg1-izraelska-armia-6899345/alternates/LANDSCAPE_1280" />
    Rząd Izraela forsuje kontrowersyjną reformę sądownictwa.

## Pakt senacki to "kwestia kilku najbliższych dni"
 - [https://fakty.tvn24.pl/zobacz-fakty/pakt-senacki-to-kwestia-kilku-najblizszych-dni-ma-byc-duzo-kandydatow-sposrod-samorzadowcow-7258340?source=rss](https://fakty.tvn24.pl/zobacz-fakty/pakt-senacki-to-kwestia-kilku-najblizszych-dni-ma-byc-duzo-kandydatow-sposrod-samorzadowcow-7258340?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T18:43:00+00:00

<img alt="Pakt senacki to " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-ar0ea1-kkz-7258342/alternates/LANDSCAPE_1280" />
    Liderzy opozycji - jak zapewniają - zbliżają się do końca ustaleń w sprawie kandydatów do Senatu. Wśród nich może być wielu samorządowców.

## "Bezpieczeństwo Polski jest zagwarantowane"
 - [https://tvn24.pl/polska/alaksandr-lukaszenka-o-grupie-wagnera-i-polsce-ambasador-usa-przy-obwe-michael-carpenter-bezpieczenstwo-polski-jest-zagwarantowane-7258238?source=rss](https://tvn24.pl/polska/alaksandr-lukaszenka-o-grupie-wagnera-i-polsce-ambasador-usa-przy-obwe-michael-carpenter-bezpieczenstwo-polski-jest-zagwarantowane-7258238?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T18:30:26+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uytzru-marcin-wrona-w-rozmowie-z-ambasadorem-usa-przy-obwe-michaelem-carpenterem-7258260/alternates/LANDSCAPE_1280" />
    Michael Carpenter, ambasador USA przy OBWE, w rozmowie z korespondentem "Faktów" TVN.

## Wiatr łamał drzewa, konary przygniatały samochody. Sześć osób rannych
 - [https://tvn24.pl/tvnmeteo/swiat/niemcy-wiatr-lamal-drzewa-konary-przygniataly-samochody-szesc-osob-rannych-7258065?source=rss](https://tvn24.pl/tvnmeteo/swiat/niemcy-wiatr-lamal-drzewa-konary-przygniataly-samochody-szesc-osob-rannych-7258065?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T17:58:53+00:00

<img alt="Wiatr łamał drzewa, konary przygniatały samochody. Sześć osób rannych" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-7r2zyo-po-burzach-w-berlinie-7258088/alternates/LANDSCAPE_1280" />
    Nawałnice przeszły przez wschodnie Niemcy.

## Pożary na Rodos. Jest oświadczenie polskiego przewoźnika
 - [https://tvn24.pl/biznes/ze-swiata/grecja-pozary-na-rodos-enter-air-zapewnia-ze-stara-sie-jak-najszybciej-sprowadzic-polakow-7258205?source=rss](https://tvn24.pl/biznes/ze-swiata/grecja-pozary-na-rodos-enter-air-zapewnia-ze-stara-sie-jak-najszybciej-sprowadzic-polakow-7258205?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T17:46:04+00:00

<img alt="Pożary na Rodos. Jest oświadczenie polskiego przewoźnika" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s0pdce-rodos-7256728/alternates/LANDSCAPE_1280" />
    "Sytuacja jest skomplikowana".

## Rossmann wycofuje partię produktu
 - [https://tvn24.pl/biznes/z-kraju/rossmann-wycofuje-chipsy-warzywne-ostrzezenie-gis-7258162?source=rss](https://tvn24.pl/biznes/z-kraju/rossmann-wycofuje-chipsy-warzywne-ostrzezenie-gis-7258162?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T17:21:43+00:00

<img alt="Rossmann wycofuje partię produktu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qqbpe7-30-osobowa-grupa-spladrowala-sklep-policja-szuka-swiadkow-6846092/alternates/LANDSCAPE_1280" />
    Ostrzeżenie GIS.

## Dobre przetarcie Świątek w Warszawie. Rywalka postawiła się
 - [https://eurosport.tvn24.pl/tenis/wta-warszawa/2023/iga-swiatek-nigina-abduraimowa-wynik-meczu-i-relacja-tenis_sto9717118/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-warszawa/2023/iga-swiatek-nigina-abduraimowa-wynik-meczu-i-relacja-tenis_sto9717118/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T17:19:00+00:00

<img alt="Dobre przetarcie Świątek w Warszawie. Rywalka postawiła się" src="https://tvn24.pl/najnowsze/cdn-zdjecie-875cne-swiatek-w-meczu-1-7258207/alternates/LANDSCAPE_1280" />
    Liderka światowego rankingu po rocznej przerwie zaprezentowała się przed stołeczną widownią.

## Ostrzeżenie z Londynu: Rosja może atakować cywilne statki
 - [https://tvn24.pl/swiat/umowa-zbozowa-morze-czarne-rosja-grozi-statkom-plynacych-do-ukrainy-brytyjska-ambasador-przy-onz-o-dzialaniach-rosjan-7258137?source=rss](https://tvn24.pl/swiat/umowa-zbozowa-morze-czarne-rosja-grozi-statkom-plynacych-do-ukrainy-brytyjska-ambasador-przy-onz-o-dzialaniach-rosjan-7258137?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T17:11:24+00:00

<img alt="Ostrzeżenie z Londynu: Rosja może atakować cywilne statki " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bpjzv4-port-w-odessie-na-zdjeciu-z-29-grudnia-2022-roku-7258163/alternates/LANDSCAPE_1280" />
    Nasze informacje wskazują również, że Rosja rozmieściła dodatkowe miny morskie na podejściach do ukraińskich portów - przekazała Barbara Woodward.

## Ciastko chronione prawem. "To słodki symbol Warszawy"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wuzetka-na-liscie-produktow-tradycyjnych-beda-rozdawac-wuzetki-gdzie-kiedy-7258067?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wuzetka-na-liscie-produktow-tradycyjnych-beda-rozdawac-wuzetki-gdzie-kiedy-7258067?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T17:10:29+00:00

<img alt="Ciastko chronione prawem. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-sahn24-wuzetka-na-trasie-w-z-7258068/alternates/LANDSCAPE_1280" />
    W sobotę rozdadzą tysiąc wuzetek.

## Demonstracje solidarnościowe z panią Joanną
 - [https://tvn24.pl/polska/sprawa-pani-joanny-demonstracje-solidarnosciowe-w-wielu-miastach-polski-miedzy-innymi-krakowie-7257976?source=rss](https://tvn24.pl/polska/sprawa-pani-joanny-demonstracje-solidarnosciowe-w-wielu-miastach-polski-miedzy-innymi-krakowie-7257976?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T16:58:46+00:00

<img alt="Demonstracje solidarnościowe z panią Joanną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m0ybi7-pani-joanna-podczas-manifestacji-w-krakowie-7258131/alternates/LANDSCAPE_1280" />
    Główny protest zorganizowano w Krakowie.

## Załamanie pogody, trzy fale ulew. "Sytuacja może być bardzo niebezpieczna"
 - [https://tvn24.pl/tvnmeteo/pogoda/zalamanie-pogody-ulewy-w-polsce-mozliwe-podtopienia-sytuacja-moze-byc-bardzo-niebezpieczna-pogoda-na-5-dni-7258009?source=rss](https://tvn24.pl/tvnmeteo/pogoda/zalamanie-pogody-ulewy-w-polsce-mozliwe-podtopienia-sytuacja-moze-byc-bardzo-niebezpieczna-pogoda-na-5-dni-7258009?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T16:09:47+00:00

<img alt="Załamanie pogody, trzy fale ulew. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-raw10c-pogoda-7258070/alternates/LANDSCAPE_1280" />
    Prognoza pogody na najbliższe dni.

## Świątek już w akcji. Pierwszy mecz w Warszawie
 - [https://eurosport.tvn24.pl/tenis/wta-warszawa/2023/live-iga-swiatek-nigina-abduraimova_mtc1455122/live.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-warszawa/2023/live-iga-swiatek-nigina-abduraimova_mtc1455122/live.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T16:04:00+00:00

<img alt="Świątek już w akcji. Pierwszy mecz w Warszawie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oojulw-iga-swiatek-7257951/alternates/LANDSCAPE_1280" />
    Relacja i wynik na żywo w eurosport.pl.

## Dramat podczas treningu. Syn LeBrona Jamesa doznał zawału serca
 - [https://eurosport.tvn24.pl/koszykowka/nba/2022-2023/bronny-james-syn-lebrona-jamesa-doznal-zawalu-serca-na-treningu_sto9716963/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/nba/2022-2023/bronny-james-syn-lebrona-jamesa-doznal-zawalu-serca-na-treningu_sto9716963/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T16:00:53+00:00

<img alt="Dramat podczas treningu. Syn LeBrona Jamesa doznał zawału serca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k5rigs-bronny-james-to-syn-lebrona-jamesa-7258092/alternates/LANDSCAPE_1280" />
    Niepokojące wieści nadeszły ze Stanów Zjednoczonych.

## Rok więzienia w zawieszeniu dla ginekologa za przyjęcie pieniędzy i pomoc w aborcji
 - [https://tvn24.pl/polska/radom-rok-wiezienia-w-zawieszeniu-dla-ginekologa-za-przyjecie-pieniedzy-i-pomoc-w-aborcji-do-zabiegu-nie-doszlo-7258030?source=rss](https://tvn24.pl/polska/radom-rok-wiezienia-w-zawieszeniu-dla-ginekologa-za-przyjecie-pieniedzy-i-pomoc-w-aborcji-do-zabiegu-nie-doszlo-7258030?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T15:43:38+00:00

<img alt="Rok więzienia w zawieszeniu dla ginekologa za przyjęcie pieniędzy i pomoc w aborcji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tzfgwf-shutterstock_513397180-7258037/alternates/LANDSCAPE_1280" />
    Do zabiegu ostatecznie nie doszło.

## Sejm nie planuje szybkiego uzupełnienia składu komisji ds. pedofilii. "Nie wiem, jak to skomentować"
 - [https://tvn24.pl/polska/komisja-do-spraw-pedofilii-marek-ast-uzupelnienie-skladu-komisji-raczej-w-kolejnej-kadencji-sejmu-blazej-kmieciak-nie-wiem-jak-to-skomentowac-7257996?source=rss](https://tvn24.pl/polska/komisja-do-spraw-pedofilii-marek-ast-uzupelnienie-skladu-komisji-raczej-w-kolejnej-kadencji-sejmu-blazej-kmieciak-nie-wiem-jak-to-skomentowac-7257996?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T15:42:14+00:00

<img alt="Sejm nie planuje szybkiego uzupełnienia składu komisji ds. pedofilii. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-l4o4uw-sejm-7222847/alternates/LANDSCAPE_1280" />
    Błażej Kmieciak odniósł się do słów szefa sejmowej komisji sprawiedliwości Marka Asta.

## Rosyjski myśliwiec uszkodził amerykańskiego drona. Nagranie
 - [https://tvn24.pl/swiat/sily-powietrzne-usa-rosyjski-mysliwiec-uszkodzil-amerykanskiego-drona-opublikowano-nagranie-7257972?source=rss](https://tvn24.pl/swiat/sily-powietrzne-usa-rosyjski-mysliwiec-uszkodzil-amerykanskiego-drona-opublikowano-nagranie-7257972?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T15:07:44+00:00

<img alt="Rosyjski myśliwiec uszkodził amerykańskiego drona. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-18ewux-usa-sily-powietrzne-rosyjski-mysliwiec-uszkodzil-amerykanskiego-drona-nad-syria-7257958/alternates/LANDSCAPE_1280" />
    Mimo uszkodzeń pilotom udało się ściągnąć maszynę do bazy.

## Delegacje Chin i Rosji jadą do Korei Północnej
 - [https://tvn24.pl/swiat/korea-polnocna-wizyta-delegacji-chin-i-rosji-z-okazji-70-rocznicy-wojny-koreanskiej-7257540?source=rss](https://tvn24.pl/swiat/korea-polnocna-wizyta-delegacji-chin-i-rosji-z-okazji-70-rocznicy-wojny-koreanskiej-7257540?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T15:03:46+00:00

<img alt="Delegacje Chin i Rosji jadą do Korei Północnej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yp3vtj-kim-dzong-un-7257876/alternates/LANDSCAPE_1280" />
    "W historycznym momencie".

## Po skandalu mówił o niej cały tenisowy świat
 - [https://eurosport.tvn24.pl/tenis/wta-warszawa/2023/shuai-zhang-tereza-martincova-wynik-meczu-i-relacja-tenis_sto9716923/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-warszawa/2023/shuai-zhang-tereza-martincova-wynik-meczu-i-relacja-tenis_sto9716923/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T14:59:50+00:00

<img alt="Po skandalu mówił o niej cały tenisowy świat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4129zr-shuai-zhang-odpadla-w-pierwszej-rundzie-7258001/alternates/LANDSCAPE_1280" />
    Chinka przegrała w Warszawie.

## "Jak oni tak ratują, to niech zajmą się już wystrzeliwaniem z granatników i cięciem konfetti"
 - [https://tvn24.pl/polska/sprawa-pani-joanny-szef-mswia-broni-interwencji-policji-komentarze-opozycji-7257584?source=rss](https://tvn24.pl/polska/sprawa-pani-joanny-szef-mswia-broni-interwencji-policji-komentarze-opozycji-7257584?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T14:40:39+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eypgm0-8-kijowska-0019-7246039/alternates/LANDSCAPE_1280" />
    Komentarze opozycji.

## Zastanawiające zachowanie norweskiej gwiazdy
 - [https://eurosport.tvn24.pl/pilka-nozna/mistrzostwa-swiata-kobiet/2023/zastanawiajace-zachowanie-norweskiej-gwiazdy.-zniknela-z-boiska-tuz-przed-meczem_sto9716746/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/mistrzostwa-swiata-kobiet/2023/zastanawiajace-zachowanie-norweskiej-gwiazdy.-zniknela-z-boiska-tuz-przed-meczem_sto9716746/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T14:24:00+00:00

<img alt="Zastanawiające zachowanie norweskiej gwiazdy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bg5wjk-ada-hegerberg-7257954/alternates/LANDSCAPE_1280" />
    Zniknęła z boiska tuż przed meczem.

## Rok marzeń. Warner Bros. Discovery świętuje specjalnymi programami
 - [https://eurosport.tvn24.pl/igrzyska/olympic-games-2024/2024/rok-marzen-warner-bros.-discovery-swietuje-rok-do-igrzysk-w-paryzu-specjalnymi-programami_sto9716887/story.shtml?source=rss](https://eurosport.tvn24.pl/igrzyska/olympic-games-2024/2024/rok-marzen-warner-bros.-discovery-swietuje-rok-do-igrzysk-w-paryzu-specjalnymi-programami_sto9716887/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T14:21:41+00:00

<img alt="Rok marzeń. Warner Bros. Discovery świętuje specjalnymi programami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3s0m13-rok-do-igrzysk-w-paryzu-7257953/alternates/LANDSCAPE_1280" />
    W środę 26 lipca WBD uczci rok do igrzysk specjalnymi programami na czele z wyjątkowym dokumentem "Paris, La Vie Sportive".

## Pocałował na scenie basistę. Odwołano festiwal, zespół z zakazem koncertowania
 - [https://tvn24.pl/swiat/malezja-zespol-the-1975-z-zakazem-koncertow-matty-healy-pocalowal-na-scenie-basiste-7255776?source=rss](https://tvn24.pl/swiat/malezja-zespol-the-1975-z-zakazem-koncertow-matty-healy-pocalowal-na-scenie-basiste-7255776?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T14:07:52+00:00

<img alt="Pocałował na scenie basistę. Odwołano festiwal, zespół z zakazem koncertowania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rzlwcy-zespol-the-1975-7255811/alternates/LANDSCAPE_1280" />
    Władze o "bardzo lekceważącym" zachowaniu.

## Prokuratura wszczyna śledztwo, WIOŚ potwierdza skażenie
 - [https://tvn24.pl/poznan/pozar-skladowiska-w-przylepie-prokuratura-wszczyna-sledztwo-wios-potwierdza-skazenie-7257836?source=rss](https://tvn24.pl/poznan/pozar-skladowiska-w-przylepie-prokuratura-wszczyna-sledztwo-wios-potwierdza-skazenie-7257836?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T14:03:48+00:00

<img alt="Prokuratura wszczyna śledztwo, WIOŚ potwierdza skażenie" src="https://tvn24.pl/polska/cdn-zdjecie-iskc62-zielona-gora-pozar-7254866/alternates/LANDSCAPE_1280" />
    Ekspert: gleba zanieczyszczona na kilka metrów w głąb.

## Koniec z użytkowaniem wieczystym. Jest podpis prezydenta
 - [https://tvn24.pl/biznes/nieruchomosci/likwidacja-uzytkowania-wieczystego-prezydent-andrzej-duda-podpisal-ustawe-7257897?source=rss](https://tvn24.pl/biznes/nieruchomosci/likwidacja-uzytkowania-wieczystego-prezydent-andrzej-duda-podpisal-ustawe-7257897?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T14:01:56+00:00

<img alt="Koniec z użytkowaniem wieczystym. Jest podpis prezydenta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k6frx1-nieruchomosci-mieszkania-deweloper-deweloperzy-kredyt-hipoteczny-budowa-7192354/alternates/LANDSCAPE_1280" />
    Poinformowała Kancelaria Prezydenta RP.

## Był "wschodzącą gwiazdą", nagle znikł
 - [https://tvn24.pl/swiat/chiny-minister-spraw-zagranicznych-qin-gang-dymisja-miesiac-po-tajemniczym-zniknieciu-7257655?source=rss](https://tvn24.pl/swiat/chiny-minister-spraw-zagranicznych-qin-gang-dymisja-miesiac-po-tajemniczym-zniknieciu-7257655?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T13:32:22+00:00

<img alt="Był " src="https://tvn24.pl/najnowsze/cdn-zdjecie-g4sfa3-byly-minister-spraw-zagranicznych-chin-qin-gang-7257732/alternates/LANDSCAPE_1280" />
    Zagadka dymisji szefa chińskiego MSZ.

## Tak wyglądały dzisiaj gazety w Izraelu
 - [https://tvn24.pl/swiat/izrael-czarne-plansze-na-pierwszych-stronach-izraelskich-gazet-7257396?source=rss](https://tvn24.pl/swiat/izrael-czarne-plansze-na-pierwszych-stronach-izraelskich-gazet-7257396?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T13:31:36+00:00

<img alt="Tak wyglądały dzisiaj gazety w Izraelu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-62qulj-czolowe-izraelskie-gazety-mialy-dzis-czarna-pierwsza-strone-7257811/alternates/LANDSCAPE_1280" />
    Odpowiedź na poniedziałkową decyzję izraelskiego parlamentu.

## To najczęściej wyszukiwana torebka. Jej cena przyprawia o zawrót głowy
 - [https://tvn24.pl/biznes/ze-swiata/hermes-birkin-najczesciej-wyszukiwana-torebka-na-swiecie-7257453?source=rss](https://tvn24.pl/biznes/ze-swiata/hermes-birkin-najczesciej-wyszukiwana-torebka-na-swiecie-7257453?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T13:29:49+00:00

<img alt="To najczęściej wyszukiwana torebka. Jej cena przyprawia o zawrót głowy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-64y54a-shutterstock_2334966263-7257541/alternates/LANDSCAPE_1280" />
    Zaprojektowana na cześć artystki.

## Tragiczny wypadek na budowie, nie żyje przygnieciony przez ścianę 17-latek
 - [https://tvn24.pl/bialystok/lublin-tragiczny-wypadek-na-budowie-nie-zyje-17-latek-7257743?source=rss](https://tvn24.pl/bialystok/lublin-tragiczny-wypadek-na-budowie-nie-zyje-17-latek-7257743?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T13:17:49+00:00

<img alt="Tragiczny wypadek na budowie, nie żyje przygnieciony przez ścianę 17-latek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xf5g1f-tragiczny-wypadek-na-budowie-nie-zyje-17-latek-7257756/alternates/LANDSCAPE_1280" />
    Do dramatu doszło w centrum Lublina.

## Politycy PiS: ubóstwo "udało się zlikwidować", "praktycznie zniknęło". Nie, nie zniknęło
 - [https://konkret24.tvn24.pl/polska/politycy-pis-ubostwo-udalo-sie-zlikwidowac-praktycznie-zniknelo-nie-nie-zniknelo-st7255078?source=rss](https://konkret24.tvn24.pl/polska/politycy-pis-ubostwo-udalo-sie-zlikwidowac-praktycznie-zniknelo-nie-nie-zniknelo-st7255078?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T13:12:43+00:00

<img alt="Politycy PiS: ubóstwo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uge72t-kowalczyk-ubostwo-dzieki-rzadowi-pis-praktycznie-zniknelo-nie-nie-zniknelo-7257680/alternates/LANDSCAPE_1280" />
    W Polsce wciąż miliony ludzi żyją w ubóstwie.

## W Chorwacji czerwony alert, we Włoszech w nawałnicach zginęły dwie osoby
 - [https://tvn24.pl/tvnmeteo/swiat/chorwacja-wlochy-burze-nawalnice-czerwony-alert-przed-burzami-we-wloszech-dwie-ofiary-smiertelne-7257527?source=rss](https://tvn24.pl/tvnmeteo/swiat/chorwacja-wlochy-burze-nawalnice-czerwony-alert-przed-burzami-we-wloszech-dwie-ofiary-smiertelne-7257527?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T13:09:37+00:00

<img alt="W Chorwacji czerwony alert, we Włoszech w nawałnicach zginęły dwie osoby" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-erab0q-meteo-7257738/alternates/LANDSCAPE_1280" />
    Południu Europy zagrażają nie tylko pożary.

## Kibice Puszczy poszli śladem Japończyków
 - [https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/kibice-puszczy-niepolomice-posprzatali-swoj-sektor-po-meczu-z-widzewa-lodz_sto9716584/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/kibice-puszczy-niepolomice-posprzatali-swoj-sektor-po-meczu-z-widzewa-lodz_sto9716584/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T13:05:12+00:00

<img alt="Kibice Puszczy poszli śladem Japończyków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jc2yv6-kibice-puszczy-niepolomice-po-meczu-z-widzewem-7257805/alternates/LANDSCAPE_1280" />
    Po ich wizycie na meczu nie ma śladu

## Samolot gaszący pożary rozbił się w Grecji
 - [https://tvn24.pl/swiat/grecja-pozary-samolot-gasniczy-rozbil-sie-w-miescie-platanistos-7257716?source=rss](https://tvn24.pl/swiat/grecja-pozary-samolot-gasniczy-rozbil-sie-w-miescie-platanistos-7257716?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T12:49:16+00:00

<img alt="Samolot gaszący pożary rozbił się w Grecji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1rwdd5-pozary-w-grecji-7257727/alternates/LANDSCAPE_1280" />
    W okolicach miejscowości Platanistos na wyspie Eubea.

## Samolot gaszący pożary rozbił się w Grecji. Piloci nie przeżyli
 - [https://tvn24.pl/swiat/grecja-pozary-samolot-gasniczy-rozbil-sie-w-miescie-platanistos-piloci-nie-zyja-7257716?source=rss](https://tvn24.pl/swiat/grecja-pozary-samolot-gasniczy-rozbil-sie-w-miescie-platanistos-piloci-nie-zyja-7257716?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T12:49:16+00:00

<img alt="Samolot gaszący pożary rozbił się w Grecji. Piloci nie przeżyli" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yixdvg-2023-07-25t135043z_1_lwd979225072023rp1_rtrwnev_c_9792-europe-weather-greece-wildfire-crash-0008-7257912/alternates/LANDSCAPE_1280" />
    Do katastrofy doszło w okolicach miejscowości Platanistos na wyspie Eubea.

## "Dyktatura? Tak, poproszę!" Czy Europejczykom znudziła się demokracja?
 - [https://tvn24.pl/premium/populizm-w-europie-dyktatura-tak-poprosze-czy-europejczykom-znudzila-sie-demokracja-7257242?source=rss](https://tvn24.pl/premium/populizm-w-europie-dyktatura-tak-poprosze-czy-europejczykom-znudzila-sie-demokracja-7257242?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T12:38:25+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-38jzy1-gettyimages-1523345761-7257180/alternates/LANDSCAPE_1280" />
    Winston Churchill, premier, który przeprowadził Wielką Brytanię przez wojenną zawieruchę, miał kiedyś stwierdzić z charakterystycznym dla siebie przekąsem, że demokracja jest najgorszym z możliwych ustrojów, ale dotychczas nie wynaleziono lepszego. W Europie coraz odważniej podnoszą głowę ci, którzy z demokracją chcieliby wziąć rozwód, a kolejne raporty organizacji międzynarodowych alarmują o postępującej erozji systemów demokratycznych i dalszym przesuwaniu granic w politycznej rywalizacji. Czy europejska demokracja jest w odwrocie?

## Nielegalne wysypisko odpadów płonęło już cztery razy. Dzierżawca terenu nie istnieje
 - [https://tvn24.pl/katowice/sosnowiec-nielegalne-wysypisko-odpadow-niebezpiecznych-plonelo-juz-cztery-razy-7257602?source=rss](https://tvn24.pl/katowice/sosnowiec-nielegalne-wysypisko-odpadow-niebezpiecznych-plonelo-juz-cztery-razy-7257602?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T12:26:47+00:00

<img alt="Nielegalne wysypisko odpadów płonęło już cztery razy. Dzierżawca terenu nie istnieje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w4k6xi-nielegalne-wysypisko-odpadow-niebezpiecznych-w-sosnowcu-7257497/alternates/LANDSCAPE_1280" />
    Odpady są w Sosnowcu, ale na terenie należącym do Skarbu Państwa i dzierżawionym przez prywatną firmę, z którą nie ma kontaktu.

## Saudyjska drużyna Ronaldo zatrzymała PSG
 - [https://eurosport.tvn24.pl/pilka-nozna/psg-al-nassr-wynik-meczu-i-relacja_sto9716798/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/psg-al-nassr-wynik-meczu-i-relacja_sto9716798/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T12:23:17+00:00

<img alt="Saudyjska drużyna Ronaldo zatrzymała PSG" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q6svb1-psg-mierzylo-sie-towarzysko-z-al-nassr-7257710/alternates/LANDSCAPE_1280" />
    Mistrzowie Francji PSG tylko zremisowali bezbramkowo z Al-Nassr w meczu towarzyskim w japońskiej Osace. Wśród paryżan zabrakło Kyliana Mbappe, który już wkrótce może przenieść się do Arabii Saudyjskiej.

## Agnieszka Holland, Małgorzata Szumowska i Michał Englert z szansą na Złotego Lwa w Wenecji
 - [https://tvn24.pl/kultura-i-styl/wenecja-2023-filmy-agnieszki-holland-malgorzaty-szumowskiej-michala-englerta-romana-polanskiego-w-oficjalnej-selekcj-7257516?source=rss](https://tvn24.pl/kultura-i-styl/wenecja-2023-filmy-agnieszki-holland-malgorzaty-szumowskiej-michala-englerta-romana-polanskiego-w-oficjalnej-selekcj-7257516?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T12:19:25+00:00

<img alt="Agnieszka Holland, Małgorzata Szumowska i Michał Englert z szansą na Złotego Lwa w Wenecji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jxdaye-kadr-z-filmu-zielona-granica-agnieszki-holland-7257651/alternates/LANDSCAPE_1280" />
    80. Międzynarodowy Festiwal Filmowy w Wenecji rozpocznie się 30 sierpnia.

## Ukradli setki luksusowych samochodów. Policjanci odzyskali siedem
 - [https://tvn24.pl/katowice/katowice-ukradli-setki-luksusowych-samochodow-policjanci-odzyskali-siedem-7257492?source=rss](https://tvn24.pl/katowice/katowice-ukradli-setki-luksusowych-samochodow-policjanci-odzyskali-siedem-7257492?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T12:08:51+00:00

<img alt="Ukradli setki luksusowych samochodów. Policjanci odzyskali siedem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tjayrm-zatrzymanie-oskarzonych-o-kradziez-luksusowych-aut-7257596/alternates/LANDSCAPE_1280" />
    Dziewięć kolejnych osób stanie przed sądem. W sumie w proceder zamieszanych było 27 osób.

## Setki tajemniczych paczek odbierane w całym kraju. Władze proszą o pomoc
 - [https://tvn24.pl/swiat/korea-poludniowa-setki-tajemniczych-paczek-w-calym-kraju-chiny-pomagaja-w-sledztwie-7257343?source=rss](https://tvn24.pl/swiat/korea-poludniowa-setki-tajemniczych-paczek-w-calym-kraju-chiny-pomagaja-w-sledztwie-7257343?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T12:03:32+00:00

<img alt="Setki tajemniczych paczek odbierane w całym kraju. Władze proszą o pomoc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4kc297-seul-korea-poludniowa-6798843/alternates/LANDSCAPE_1280" />
    Podejrzane przesyłki nadawane są z zagranicy.

## Emocje wokół nowej płacy minimalnej. "Dla wielu będzie to ciężar nie do udźwignięcia"
 - [https://tvn24.pl/biznes/dlafirm/placa-minimalna-2024-zwiazek-przedsiebiorcow-i-pracodawcow-chce-regionalizacji-minimalnych-wynagrodzen-jest-stanowisko-zpp-7257403?source=rss](https://tvn24.pl/biznes/dlafirm/placa-minimalna-2024-zwiazek-przedsiebiorcow-i-pracodawcow-chce-regionalizacji-minimalnych-wynagrodzen-jest-stanowisko-zpp-7257403?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T11:55:19+00:00

<img alt="Emocje wokół nowej płacy minimalnej. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8f2se4-shutterstock_702079657-7257653/alternates/LANDSCAPE_1280" />
    Jest stanowisko organizacji pracodawców.

## Trzy kobiety w fiacie, jedna w ciąży. Nie miały szans. Nagranie monitoringu
 - [https://tvn24.pl/pomorze/dobrzejewice-czolowe-zderzenie-pod-toruniem-nie-zyje-69-letnia-pasazerka-7257503?source=rss](https://tvn24.pl/pomorze/dobrzejewice-czolowe-zderzenie-pod-toruniem-nie-zyje-69-letnia-pasazerka-7257503?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T11:48:17+00:00

<img alt="Trzy kobiety w fiacie, jedna w ciąży. Nie miały szans. Nagranie monitoringu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-txop7m-wypadek-7257684/alternates/LANDSCAPE_1280" />
    Test wykazał, że kierowca był pod wpływem narkotyków. Będą przeprowadzone dodatkowe badania.

## "Tak poprowadziła go nawigacja"
 - [https://tvn24.pl/bialystok/pulawy-samochod-zawiesil-sie-na-torach-kierowca-tlumaczyl-ze-tak-poprowadzila-go-nawigacja-7257542?source=rss](https://tvn24.pl/bialystok/pulawy-samochod-zawiesil-sie-na-torach-kierowca-tlumaczyl-ze-tak-poprowadzila-go-nawigacja-7257542?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T11:35:28+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9k6j0w-kierowca-tlumaczyl-policjantom-ze-tak-poprowadzila-go-nawigacja-7257561/alternates/LANDSCAPE_1280" />
    Kierowca został ukarany mandatem karnym w wysokości 1500 złotych.

## Co się dzieje na Sycylii? "Naprawdę dramatyczny moment"
 - [https://tvn24.pl/tvnmeteo/swiat/wlochy-coraz-wiecej-pozarow-na-sycylii-to-naprawde-dramatyczny-moment-7257205?source=rss](https://tvn24.pl/tvnmeteo/swiat/wlochy-coraz-wiecej-pozarow-na-sycylii-to-naprawde-dramatyczny-moment-7257205?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T11:26:19+00:00

<img alt="Co się dzieje na Sycylii? " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-128ywg-pozary-w-rejonie-palermo-7258031/alternates/LANDSCAPE_1280" />
    Ewakuowano około 1500 mieszkańców.

## Pożary na Sycylii. Ewakuacje mieszkańców, sirocco utrudnia walkę z żywiołem
 - [https://tvn24.pl/tvnmeteo/swiat/pozary-na-sycylii-ewakuacje-mieszkancow-sirocco-utrudnia-walke-z-zywiolem-7257205?source=rss](https://tvn24.pl/tvnmeteo/swiat/pozary-na-sycylii-ewakuacje-mieszkancow-sirocco-utrudnia-walke-z-zywiolem-7257205?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T11:26:19+00:00

<img alt="Pożary na Sycylii. Ewakuacje mieszkańców, sirocco utrudnia walkę z żywiołem" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-aaq40w-pozary-na-sycylii-7257538/alternates/LANDSCAPE_1280" />
    Na wyspie temperatura sięgała 47 stopni.

## Między Bukaresztem a Wilnem
 - [https://tvn24.pl/opinie/felieton-macieja-wierzynskiego-miedzy-bukaresztem-a-wilnem-7257325?source=rss](https://tvn24.pl/opinie/felieton-macieja-wierzynskiego-miedzy-bukaresztem-a-wilnem-7257325?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T11:18:00+00:00

<img alt="Między Bukaresztem a Wilnem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-b7x9i4-maciej-wierzynski-4598975/alternates/LANDSCAPE_1280" />
    Felieton Macieja Wierzyńskiego.

## Były kucharz Białego Domu utonął w stawie. Policja prowadzi śledztwo
 - [https://tvn24.pl/swiat/usa-byly-kucharz-bialego-domu-utonal-w-stawie-policja-prowadzi-sledztwo-7257304?source=rss](https://tvn24.pl/swiat/usa-byly-kucharz-bialego-domu-utonal-w-stawie-policja-prowadzi-sledztwo-7257304?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T11:16:13+00:00

<img alt="Były kucharz Białego Domu utonął w stawie. Policja prowadzi śledztwo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bcp87f-edgartown-wyspa-marthas-vineyard-usa-massachusets-shutterstock_1152161891-7257378/alternates/LANDSCAPE_1280" />
    Michelle i Barack Obamowie wydali oświadczenie.

## Namierzyli transport nielegalnych, niebezpiecznych odpadów. Pięć osób zatrzymanych
 - [https://tvn24.pl/wroclaw/wolow-woj-dolnoslaskie-namierzyli-transport-nielegalnych-niebezpiecznych-odpadow-piec-osob-zatrzymanych-7257345?source=rss](https://tvn24.pl/wroclaw/wolow-woj-dolnoslaskie-namierzyli-transport-nielegalnych-niebezpiecznych-odpadow-piec-osob-zatrzymanych-7257345?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T11:12:42+00:00

<img alt="Namierzyli transport nielegalnych, niebezpiecznych odpadów. Pięć osób zatrzymanych" src="https://konkret24.tvn24.pl/najnowsze/cdn-zdjecie-17qgl-niebezpieczne-odpady-zalegaja-na-nielegalnych-wysypiskach-w-wielu-miejscach-w-polsce-7257530/alternates/LANDSCAPE_1280" />
    W gminie Wołów (woj. dolnośląskie)

## Trofeum warte prawie 180 tysięcy złotych zniszczone
 - [https://eurosport.tvn24.pl/formula-1/grand-prix-formuly-1-ile-kosztowal-zniszczony-puchar-maksa-verstappena_sto9716534/story.shtml?source=rss](https://eurosport.tvn24.pl/formula-1/grand-prix-formuly-1-ile-kosztowal-zniszczony-puchar-maksa-verstappena_sto9716534/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T10:55:00+00:00

<img alt="Trofeum warte prawie 180 tysięcy złotych zniszczone" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a91yfp-max-verstappen-broni-tytulu-mistrza-swiata-7257520/alternates/LANDSCAPE_1280" />
    Wystarczyła chwila nieuwagi.

## "Śmieci masowo sprowadzane". Import odpadów do Polski za rządów PO-PSL i PiS
 - [https://konkret24.tvn24.pl/polska/smieci-masowo-sprowadzane-import-odpadow-do-polski-za-rzadow-po-psl-i-pis-st7256313?source=rss](https://konkret24.tvn24.pl/polska/smieci-masowo-sprowadzane-import-odpadow-do-polski-za-rzadow-po-psl-i-pis-st7256313?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T10:25:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8a9qrb-smieciowa-konfrontacja-7256503/alternates/LANDSCAPE_1280" />
    Zarówno za rządów PO-PSL, jak i Zjednoczonej Prawicy import odpadów rósł. Ale trzeba uważać z porównywaniem danych.

## Wiceminister zakłócił konferencję opozycji. Pchnął posła KO
 - [https://tvn24.pl/polska/wybory-parlamentarne-2023-wiceminister-jacek-ozdoba-pchnal-posla-jana-grabca-zaklocal-konferencje-ko-w-wolominie-7257187?source=rss](https://tvn24.pl/polska/wybory-parlamentarne-2023-wiceminister-jacek-ozdoba-pchnal-posla-jana-grabca-zaklocal-konferencje-ko-w-wolominie-7257187?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T10:11:35+00:00

<img alt="Wiceminister zakłócił konferencję opozycji. Pchnął posła KO" src="https://tvn24.pl/najnowsze/cdn-zdjecie-htu8r9-wiceminister-jacek-ozdoba-popycha-posla-jana-grabca-7257146/alternates/LANDSCAPE_1280" />
    "Pan bierze pieniądze za to, żeby odpowiadać na pytania mieszkańców (...), a nie zakrzykiwać konferencje opozycji".

## Spada liczba ludności w Polsce
 - [https://tvn24.pl/biznes/z-kraju/polska-liczba-ludnosci-polski-spadla-gus-podal-wstepne-dane-na-koniec-czerwca-2023-7257344?source=rss](https://tvn24.pl/biznes/z-kraju/polska-liczba-ludnosci-polski-spadla-gus-podal-wstepne-dane-na-koniec-czerwca-2023-7257344?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T10:05:48+00:00

<img alt="Spada liczba ludności w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-97uum5-warszawa-park-konoplytska-shutterstock2155021477-1-5782702/alternates/LANDSCAPE_1280" />
    Wstępne dane na koniec czerwca 2023 roku.

## "Ziemia wręcz czarna, spopielona". Reporterka TVN24 na Rodos
 - [https://tvn24.pl/tvnmeteo/swiat/grecja-rodos-spustoszone-przez-pozary-na-miejscu-reporterka-tvn24-7257361?source=rss](https://tvn24.pl/tvnmeteo/swiat/grecja-rodos-spustoszone-przez-pozary-na-miejscu-reporterka-tvn24-7257361?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T10:02:06+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-tksl9d-skutki-pozaru-w-lardos-7257320/alternates/LANDSCAPE_1280" />
    Pożary w Grecji.

## W Chinach rozgorzała dyskusja o "Barbie"
 - [https://tvn24.pl/kultura-i-styl/barbie-wywolala-dyskusje-w-chinach-kobiety-maja-za-duza-wladze-czego-jeszcze-chca-7257165?source=rss](https://tvn24.pl/kultura-i-styl/barbie-wywolala-dyskusje-w-chinach-kobiety-maja-za-duza-wladze-czego-jeszcze-chca-7257165?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T09:57:15+00:00

<img alt="W Chinach rozgorzała dyskusja o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nj6x0r-barbie-w-rez-grety-gerwig-7246115/alternates/LANDSCAPE_1280" />
    "Kobiety mają za dużą władzę, czego jeszcze chcą?"

## "Jesteśmy blisko rozwiązania tej przerażającej zbrodni"
 - [https://tvn24.pl/swiat/brazylia-aresztowany-kolejny-podejrzany-w-zwiazku-ze-sprawa-morderstwa-radnej-marielle-franco-7256868?source=rss](https://tvn24.pl/swiat/brazylia-aresztowany-kolejny-podejrzany-w-zwiazku-ze-sprawa-morderstwa-radnej-marielle-franco-7256868?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T09:52:12+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wavdyf-shutterstock_1608799387-7257382/alternates/LANDSCAPE_1280" />
    Aresztowanie w związku ze sprawą morderstwa popularnej radnej Rio de Janeiro.

## Gwiazdy NBA zgłaszają się do Arabii zamiast Mbappe. "Możecie wziąć mnie, wyglądam jak on"
 - [https://eurosport.tvn24.pl/pilka-nozna/lebron-james-giannis-antetokounmpo-i-draymond-green-zareagowali-na-oferte-al-hilal-dla-kyliana-mbapp_sto9716486/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/lebron-james-giannis-antetokounmpo-i-draymond-green-zareagowali-na-oferte-al-hilal-dla-kyliana-mbapp_sto9716486/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T09:45:00+00:00

<img alt="Gwiazdy NBA zgłaszają się do Arabii zamiast Mbappe. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bf1w5g-kylian-mbappe-przeniesie-sie-do-arabii-saudyjskiej-7257385/alternates/LANDSCAPE_1280" />
    Karuzeli transferowej towarzyszy karuzela uśmiechu.

## Co łączy pożary w Grecji z dzikami na osiedlach?
 - [https://tvn24.pl/krakow/pozary-w-grecji-i-dziki-na-polskich-osiedlach-maja-wspolny-mianownik-to-agresywna-rozbudowa-miast-artykul-polskiego-naukowca-opublikowany-w-nature-7256454?source=rss](https://tvn24.pl/krakow/pozary-w-grecji-i-dziki-na-polskich-osiedlach-maja-wspolny-mianownik-to-agresywna-rozbudowa-miast-artykul-polskiego-naukowca-opublikowany-w-nature-7256454?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T09:41:02+00:00

<img alt="Co łączy pożary w Grecji z dzikami na osiedlach?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-13ksje-karpaty-7256558/alternates/LANDSCAPE_1280" />
     "Człowiek wchodzi z zabudową w naturę".

## Mężczyzna wpadł do zbiornika na deszczówkę. Nie żyje
 - [https://tvn24.pl/lodz/tomaszow-mazowiecki-mezczyzna-wpadl-do-zbiornika-na-deszczowke-nie-zyje-7257206?source=rss](https://tvn24.pl/lodz/tomaszow-mazowiecki-mezczyzna-wpadl-do-zbiornika-na-deszczowke-nie-zyje-7257206?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T09:13:50+00:00

<img alt="Mężczyzna wpadł do zbiornika na deszczówkę. Nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ocb0to-mezczyzna-wpadl-do-zbiornika-na-deszczowke-nie-zyje-7257159/alternates/LANDSCAPE_1280" />
    Do tragedii doszło w Tomaszowie Mazowieckim.

## "Tutaj uczymy się bardzo oszczędnie operować wodą"
 - [https://tvn24.pl/tvnmeteo/swiat/grecja-polscy-strazacy-pomagaja-gasic-pozary-tutaj-uczymy-sie-bardzo-oszczednie-operowac-woda-7257195?source=rss](https://tvn24.pl/tvnmeteo/swiat/grecja-polscy-strazacy-pomagaja-gasic-pozary-tutaj-uczymy-sie-bardzo-oszczednie-operowac-woda-7257195?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T09:10:30+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q5e25x-polscy-strazacy-w-grecji-7255003/alternates/LANDSCAPE_1280" />
    Żar lejący się z nieba, brak wody, szybko rozprzestrzeniający się ogień - z tym mierzą się polscy strażacy w Grecji.

## "Bardzo przykra sytuacja". Kuria po zatrzymaniu księdza
 - [https://tvn24.pl/lodz/sochaczew-ksiadz-piotr-s-aresztowany-diecezja-lowicka-w-komunikacie-o-bardzo-przykrej-sytuacji-7257270?source=rss](https://tvn24.pl/lodz/sochaczew-ksiadz-piotr-s-aresztowany-diecezja-lowicka-w-komunikacie-o-bardzo-przykrej-sytuacji-7257270?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:57:09+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2xxtkm-kuria-lowicka-o-przykrej-wiadomosci-7257213/alternates/LANDSCAPE_1280" />
    Media: chodzi o narkotyki.

## "Bardzo przykra sytuacja". Kuria potwierdza aresztowanie księdza
 - [https://tvn24.pl/lodz/sochaczew-zyrardow-ksiadz-piotr-s-aresztowany-diecezja-lowicka-w-komunikacie-o-bardzo-przykrej-sytuacji-7257270?source=rss](https://tvn24.pl/lodz/sochaczew-zyrardow-ksiadz-piotr-s-aresztowany-diecezja-lowicka-w-komunikacie-o-bardzo-przykrej-sytuacji-7257270?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:57:09+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2xxtkm-kuria-lowicka-o-przykrej-wiadomosci-7257213/alternates/LANDSCAPE_1280" />
    Prokuratura przekazuje, że chodzi o udzielanie narkotyków.

## "Istnieje 100 proc. szans, że Twitter zostanie przez kogoś pozwany"
 - [https://tvn24.pl/biznes/najnowsze/elon-musk-zmienia-nazwe-twittera-na-x-za-co-groza-mu-pozwy-7256971?source=rss](https://tvn24.pl/biznes/najnowsze/elon-musk-zmienia-nazwe-twittera-na-x-za-co-groza-mu-pozwy-7256971?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:56:29+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-sncec8-pracownicy-usuwaja-litery-z-pionowego-znaku-twittera-na-siedzibie-firmy-w-san-francisco-w-kalifornii-7257297/alternates/LANDSCAPE_1280" />
    Prawnicy nie mają wątpliwości.

## Xi Jinping: Zachód słabnie, Wschód przybiera na sile
 - [https://tvn24.pl/swiat/chiny-xi-jinping-w-2020-roku-wzywal-wojsko-do-przygotowania-sie-do-wojny-7256863?source=rss](https://tvn24.pl/swiat/chiny-xi-jinping-w-2020-roku-wzywal-wojsko-do-przygotowania-sie-do-wojny-7256863?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:53:28+00:00

<img alt="Xi Jinping: Zachód słabnie, Wschód przybiera na sile" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7em2av-xi-jinping-7163494/alternates/LANDSCAPE_1280" />
    Z ujawnionych dokumentów wynika, że w grudniu 2020 roku prezydent Chin wzywał wojsko do przygotowania się do wojny.

## Alert RCB dla części kraju. "Jeśli możesz, zostań w domu"
 - [https://tvn24.pl/tvnmeteo/pogoda/alert-rcb-burze-z-gradem-silny-wiatr-wtorek-2507-rzadowe-centrum-bezpieczenstwa-ostrzega-jesli-mozesz-zostan-w-domu-7257210?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alert-rcb-burze-z-gradem-silny-wiatr-wtorek-2507-rzadowe-centrum-bezpieczenstwa-ostrzega-jesli-mozesz-zostan-w-domu-7257210?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:40:46+00:00

<img alt="Alert RCB dla części kraju. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-4s5bic-rcb-burze-7257250/alternates/LANDSCAPE_1280" />
    Eksperci ostrzegają przed burzami z gradem i silnym wiatrem.

## Ciężkie chwile Polaków na lotnisku
 - [https://tvn24.pl/swiat/brak-dostepu-do-bagazy-i-lekow-ciezkie-chwile-polakow-na-lotnisku-na-rodos-7257157?source=rss](https://tvn24.pl/swiat/brak-dostepu-do-bagazy-i-lekow-ciezkie-chwile-polakow-na-lotnisku-na-rodos-7257157?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:40:35+00:00

W Grecji trwa największa w historii akcja ewakuacyjna.

## Biurowiec w Warszawie za ponad ćwierć miliarda złotych. Jest umowa sprzedaży
 - [https://tvn24.pl/biznes/nieruchomosci/warszawa-warta-tower-globalworth-sprzedaje-biurowiec-podano-kwote-7257143?source=rss](https://tvn24.pl/biznes/nieruchomosci/warszawa-warta-tower-globalworth-sprzedaje-biurowiec-podano-kwote-7257143?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:35:11+00:00

<img alt="Biurowiec w Warszawie za ponad ćwierć miliarda złotych. Jest umowa sprzedaży" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-90no7b-warta-tower-7257162/alternates/LANDSCAPE_1280" />
    "Duży sukces z uwagi na perturbacje na rynku biurowym".

## Tego ryzyka nie należy podejmować. "Konsekwencje mogą być naprawdę duże"
 - [https://tvn24.pl/go/programy,7/7-zyc-odcinki,629253/odcinek-4,S00E04,629251?source=rss](https://tvn24.pl/go/programy,7/7-zyc-odcinki,629253/odcinek-4,S00E04,629251?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:22:49+00:00

<img alt="Tego ryzyka nie należy podejmować. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ysxz0x-wypadek-nie-zdarza-sie-nam-odc-4-z-cyklu-7-zyc-7257194/alternates/LANDSCAPE_1280" />
    Dziś Dzień Bezpiecznego Kierowcy.

## Są nowe dane o bezrobociu w Polsce
 - [https://tvn24.pl/biznes/z-kraju/bezrobocie-w-polsce-czerwiec-2023-gus-podal-nowe-dane-7257181?source=rss](https://tvn24.pl/biznes/z-kraju/bezrobocie-w-polsce-czerwiec-2023-gus-podal-nowe-dane-7257181?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:10:44+00:00

<img alt="Są nowe dane o bezrobociu w Polsce" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-yzgdza-bezrobocie-urzad-pracy-5129728/alternates/LANDSCAPE_1280" />
    Najgorsza sytuacja w województwie podkarpackim.

## W środku pięć młodych osób
 - [https://tvn24.pl/poznan/leszno-na-ulicy-krasinskiego-auto-uderzylo-w-drzewo-ucierpialo-piec-mlodych-osob-wszyscy-maja-od-17-do-19-lat-7257153?source=rss](https://tvn24.pl/poznan/leszno-na-ulicy-krasinskiego-auto-uderzylo-w-drzewo-ucierpialo-piec-mlodych-osob-wszyscy-maja-od-17-do-19-lat-7257153?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:04:50+00:00

<img alt="W środku pięć młodych osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pzuuq8-piec-osob-trafilo-do-szpitala-7257125/alternates/LANDSCAPE_1280" />
    Kierowca był trzeźwy. Do wypadku doszło w Lesznie.

## Jechała z otwartymi drzwiami. Myślała, że zepsuło jej się lusterko
 - [https://tvn24.pl/bialystok/gora-pulawska-jechala-z-otwartymi-drzwiami-myslala-ze-zepsulo-jej-sie-lusterko-7257111?source=rss](https://tvn24.pl/bialystok/gora-pulawska-jechala-z-otwartymi-drzwiami-myslala-ze-zepsulo-jej-sie-lusterko-7257111?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T08:03:18+00:00

<img alt="Jechała z otwartymi drzwiami. Myślała, że zepsuło jej się lusterko " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bp96r-jechala-z-otwartymi-drzwiami-myslala-ze-zepsulo-sie-jej-luterko-7257112/alternates/LANDSCAPE_1280" />
    Kobieta została ukarana mandatem i punktami karnymi.

## Jest decyzja w sprawie występu Jokicia w mistrzostwach świata
 - [https://eurosport.tvn24.pl/koszykowka/world-cup/2023/mistrzostwa-swiata-2023.-nikola-jokic-podjal-decyzje-w-sprawie-wystepu.-czy-zagra-koszykowka_sto9716260/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/world-cup/2023/mistrzostwa-swiata-2023.-nikola-jokic-podjal-decyzje-w-sprawie-wystepu.-czy-zagra-koszykowka_sto9716260/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T07:32:50+00:00

<img alt="Jest decyzja w sprawie występu Jokicia w mistrzostwach świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dxz7kx-jokic-w-zeszlym-roku-gral-w-mistrzostwach-europy-7257126/alternates/LANDSCAPE_1280" />
    To najlepszy koszykarz minionego sezonu NBA i mistrz tej ligi w barwach Denver Nuggets.

## Piotr Jacoń poleca książki na wakacje. To tytuły, które "dają do myślenia"
 - [https://tvn24.pl/kultura-i-styl/piotr-jacon-poleca-ksiazki-na-wakacje-to-tytuly-ktore-daja-do-myslenia-7255772?source=rss](https://tvn24.pl/kultura-i-styl/piotr-jacon-poleca-ksiazki-na-wakacje-to-tytuly-ktore-daja-do-myslenia-7255772?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T07:30:28+00:00

<img alt="Piotr Jacoń poleca książki na wakacje. To tytuły, które " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1sthdi-piot-jacon-7257093/alternates/LANDSCAPE_1280" />
    - Moje wybory czytelnicze często kręcą się wokół bohaterów i bohaterek zapraszanych do programu - mówi Piotr Jacoń, autor cyklu "Bez polityki" w TVN24 GO.

## Johnny Depp miał zemdleć w hotelowym pokoju. Media o powodzie odwołania koncertów Hollywood Vampires
 - [https://tvn24.pl/kultura-i-styl/johnny-depp-mial-zemdlec-w-hotelowym-pokoju-media-o-powodzie-odwolania-koncertow-hollywood-vampires-7257000?source=rss](https://tvn24.pl/kultura-i-styl/johnny-depp-mial-zemdlec-w-hotelowym-pokoju-media-o-powodzie-odwolania-koncertow-hollywood-vampires-7257000?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T07:08:12+00:00

<img alt="Johnny Depp miał zemdleć w hotelowym pokoju. Media o powodzie odwołania koncertów Hollywood Vampires " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bzf095-johnny-depp-na-scenie-7257024/alternates/LANDSCAPE_1280" />
    Informację podał węgierski portal Daily News Hungary.

## Awaria urządzeń sterowania ruchem kolejowym. Opóźnione pociągi
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-awaria-urzadzen-sterowania-ruchem-kolejowym-opoznione-pociagi-7257017?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-awaria-urzadzen-sterowania-ruchem-kolejowym-opoznione-pociagi-7257017?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T07:02:38+00:00

<img alt="Awaria urządzeń sterowania ruchem kolejowym. Opóźnione pociągi" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ttdf4l-tory-kolejowe-5785405/alternates/LANDSCAPE_1280" />
    Informuje Szybka Kolej Miejska.

## Smród, strach o wodę i prusaki. Od lat mieszkają po sąsiedzku z gigantyczną hałdą śmieci
 - [https://tvn24.pl/poznan/sarbia-woj-wielkopolskie-od-lat-mieszkaja-po-sasiedzku-z-gigantycznym-nielegalnym-skladowiskiem-smieci-7256992?source=rss](https://tvn24.pl/poznan/sarbia-woj-wielkopolskie-od-lat-mieszkaja-po-sasiedzku-z-gigantycznym-nielegalnym-skladowiskiem-smieci-7256992?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T06:58:03+00:00

Eksperci i urzędnicy ostrzegają, że i na tym składowisku może wybuchnąć pożar.

## Nawałnica. Woda po kolana
 - [https://tvn24.pl/tvnmeteo/polska/woda-po-kolana-kilkadziesiat-interwencji-przez-gorzow-wielkopolski-przeszla-nawalnica-7256985?source=rss](https://tvn24.pl/tvnmeteo/polska/woda-po-kolana-kilkadziesiat-interwencji-przez-gorzow-wielkopolski-przeszla-nawalnica-7256985?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T06:53:53+00:00

<img alt="Nawałnica. Woda po kolana" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-lbtwyf-ulewa-w-gorzowie-wielkopolskim-7256944/alternates/LANDSCAPE_1280" />
    Mnóstwo dróg zostało zalanych w Gorzowie Wielkopolskim.

## Departament Stanu USA komentuje słowa Łukaszenki i Putina o Polsce
 - [https://tvn24.pl/swiat/alaksandr-lukaszenka-i-wladimir-putin-o-polsce-departament-stanu-usa-komentuje-7256869?source=rss](https://tvn24.pl/swiat/alaksandr-lukaszenka-i-wladimir-putin-o-polsce-departament-stanu-usa-komentuje-7256869?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T06:34:01+00:00

<img alt="Departament Stanu USA komentuje słowa Łukaszenki i Putina o Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gtkm9j-putin-lukaszenka-7167868/alternates/LANDSCAPE_1280" />
    Matthew Miller odniósł się m.in. do sugestii białoruskiego dyktatora o "wycieczce" wagnerowców do Polski.

## Tak zwana czternasta emerytura w 2023 roku. Wiemy, kiedy zostanie wypłacona
 - [https://tvn24.pl/biznes/z-kraju/czternasta-emerytura-w-2023-r-premier-mateusz-morawiecki-zapowiedzial-termin-wyplaty-czternastek-na-przelom-sierpnia-i-wrzesnia-7256984?source=rss](https://tvn24.pl/biznes/z-kraju/czternasta-emerytura-w-2023-r-premier-mateusz-morawiecki-zapowiedzial-termin-wyplaty-czternastek-na-przelom-sierpnia-i-wrzesnia-7256984?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T06:27:50+00:00

<img alt="Tak zwana czternasta emerytura w 2023 roku. Wiemy, kiedy zostanie wypłacona" src="https://tvn24.pl/najnowsze/cdn-zdjecie-riyt0m-emerytura-emeryt-emerytka-shutterstock1341384812s-5664702/alternates/LANDSCAPE_1280" />
    Zapowiedź premiera.

## Borussia Dortmund kupiła pomocnika Bayernu Monachium
 - [https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2023-2024/transfery.-marcel-sabitzer-przechodzi-z-bayernu-monachium-do-borussii-dortmund_sto9716426/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2023-2024/transfery.-marcel-sabitzer-przechodzi-z-bayernu-monachium-do-borussii-dortmund_sto9716426/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T06:26:07+00:00

<img alt="Borussia Dortmund kupiła pomocnika Bayernu Monachium" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7l6d06-marcel-sabitzer-gra-w-reprezentacji-austrii-7256998/alternates/LANDSCAPE_1280" />
    Marcel Sabitzer przeniósł się z Bayernu Monachium do Borussii Dortmund. 29-letni pomocnik, według różnych źródeł, miał kosztować 15-19 milionów euro.

## Po uderzeniu w bariery auto dachowało, kierowca uciekł
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-uderzyl-w-bariery-i-uciekl-zdarzenie-z-udzialem-pijanego-kierowcy-7256932?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-uderzyl-w-bariery-i-uciekl-zdarzenie-z-udzialem-pijanego-kierowcy-7256932?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T06:23:25+00:00

<img alt="Po uderzeniu w bariery auto dachowało, kierowca uciekł" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-af1wsu-zdarzenie-z-udzialem-pijanego-kierowcy-7256962/alternates/LANDSCAPE_1280" />
    "Miał ponad półtora promila".

## Sąsiedzi wyburzyli ścianę i ukradli im sypialnię
 - [https://tvn24.pl/swiat/wlochy-sardynia-kradziez-sypialni-trwa-dochodzenie-7256911?source=rss](https://tvn24.pl/swiat/wlochy-sardynia-kradziez-sypialni-trwa-dochodzenie-7256911?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T06:13:13+00:00

<img alt="Sąsiedzi wyburzyli ścianę i ukradli im sypialnię" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m19xia-olbia-na-sardynii-zdjecie-pogladowe-7256936/alternates/LANDSCAPE_1280" />
    Dochodzenie na Sardynii.

## 45 lat temu urodziło się pierwsze dziecko poczęte metodą in vitro. Jakie były dalsze losy Louise Brown
 - [https://tvn24.pl/swiat/louise-brown-45-lat-temu-urodzilo-sie-pierwsze-dziecko-poczete-metoda-in-vitro-jakie-byly-jego-dalsze-losy-7218409?source=rss](https://tvn24.pl/swiat/louise-brown-45-lat-temu-urodzilo-sie-pierwsze-dziecko-poczete-metoda-in-vitro-jakie-byly-jego-dalsze-losy-7218409?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T06:10:29+00:00

<img alt="45 lat temu urodziło się pierwsze dziecko poczęte metodą in vitro. Jakie były dalsze losy Louise Brown " src="https://tvn24.pl/najnowsze/cdn-zdjecie-odw0l3-to-byl-news-29-05-2023-7255977/alternates/LANDSCAPE_1280" />
    "Dorastała w centrum debaty o etyce zabiegu, będąc jednocześnie światełkiem nadziei dla milionów bezdzietnych par na całym świecie".

## Ile w karierze zarobiła Świątek? Do Radwańskiej trochę jeszcze brakuje
 - [https://eurosport.tvn24.pl/tenis/ile-zarobila-na-korcie-iga-swiatek_sto9716414/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/ile-zarobila-na-korcie-iga-swiatek_sto9716414/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T06:01:28+00:00

<img alt="Ile w karierze zarobiła Świątek? Do Radwańskiej trochę jeszcze brakuje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u91isx-iga-swiatek-ostatnio-po-raz-trzeci-wygrala-roland-garros-7177447/alternates/LANDSCAPE_1280" />
    Iga Świątek coraz bliżej magicznej granicy.

## "Czasami trzeba poświęcić swoje ojczyzny lokalne"
 - [https://tvn24.pl/polska/wybory-parlamentarne-2023-jacek-karnowski-wystartuje-do-sejmu-7256930?source=rss](https://tvn24.pl/polska/wybory-parlamentarne-2023-jacek-karnowski-wystartuje-do-sejmu-7256930?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T05:58:20+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-10zo2r-jacek-karnowski-7256916/alternates/LANDSCAPE_1280" />
    Jacek Karnowski w "Jeden na jeden".

## Dwa leki wycofane z obrotu powodu zanieczyszczeń
 - [https://tvn24.pl/biznes/z-kraju/gif-wycofuje-dwa-leki-tresuvi-oraz-andepin-z-obrotu-z-powodu-zanieczyszczen-7256927?source=rss](https://tvn24.pl/biznes/z-kraju/gif-wycofuje-dwa-leki-tresuvi-oraz-andepin-z-obrotu-z-powodu-zanieczyszczen-7256927?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T05:58:07+00:00

<img alt="Dwa leki wycofane z obrotu powodu zanieczyszczeń" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hqypr0-shutterstock_756231364-7256946/alternates/LANDSCAPE_1280" />
    Informuje GIF.

## Zmiany dla klientów dużego banku
 - [https://tvn24.pl/biznes/pieniadze/credit-agricole-nowy-cennik-od-wrzesnia-2023-zmiany-dla-posiadaczy-flagowego-konta-dla-ciebie-7256898?source=rss](https://tvn24.pl/biznes/pieniadze/credit-agricole-nowy-cennik-od-wrzesnia-2023-zmiany-dla-posiadaczy-flagowego-konta-dla-ciebie-7256898?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T05:45:22+00:00

<img alt="Zmiany dla klientów dużego banku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cesw8x-komputer-laptop-5786682/alternates/LANDSCAPE_1280" />
     "Podyktowane są rosnącą inflacją".

## "Tożsamość uśmiechniętego klienta nie jest jasna". Ale do Rosji trafiły kamizelki kuloodporne i hełmy
 - [https://tvn24.pl/swiat/politico-do-rosji-trafia-z-chin-sprzet-podwojnego-zastosowania-korzysta-rosyjska-armia-7256860?source=rss](https://tvn24.pl/swiat/politico-do-rosji-trafia-z-chin-sprzet-podwojnego-zastosowania-korzysta-rosyjska-armia-7256860?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T05:27:09+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-d8zj4e-transport-z-chin-4226793/alternates/LANDSCAPE_1280" />
    Politico: Chiny wysyłają do Rosji sprzęt, który jest wykorzystywany do wyposażania rosyjskiej armii.

## Nie dojdzie do wyczekiwanego powrotu. "Bardzo przez to cierpię"
 - [https://eurosport.tvn24.pl/lekkoatletyka/iga-baugmart-witan-kontuzjowana.-w-tym-sezonie-nie-wroci-do-biegania_sto9716404/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/iga-baugmart-witan-kontuzjowana.-w-tym-sezonie-nie-wroci-do-biegania_sto9716404/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T05:00:00+00:00

<img alt="Nie dojdzie do wyczekiwanego powrotu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z7q4le-iga-baugmart-witan-7256900/alternates/LANDSCAPE_1280" />
    Wielki pech medalistki z Tokio Igi Baumgart-Witan.

## Prezydent Inowrocławia o środkach z KPO: Potrzebujemy, wołamy i prosimy o te pieniądze
 - [https://tvn24.pl/biznes/z-kraju/kpo-brak-pieniedzy-wstrzymuje-wiele-inwestycji-w-inowroclawiu-gosc-tvn24-bis-prezydent-inowroclawia-ryszard-brejza-7256890?source=rss](https://tvn24.pl/biznes/z-kraju/kpo-brak-pieniedzy-wstrzymuje-wiele-inwestycji-w-inowroclawiu-gosc-tvn24-bis-prezydent-inowroclawia-ryszard-brejza-7256890?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T04:42:43+00:00

<img alt="Prezydent Inowrocławia o środkach z KPO: Potrzebujemy, wołamy i prosimy o te pieniądze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9qnuu3-shutterstock_2143041003-7256895/alternates/LANDSCAPE_1280" />
     "Co z KPO?" codziennie na antenie TVN24 BiS o godzinie 17:00.

## Pierwszego dnia pracy uratowała pięć osób
 - [https://tvn24.pl/swiat/wlochy-ratowniczka-pierwszego-dnia-pracy-uratowala-piec-osob-na-plazy-w-sabaudii-7256877?source=rss](https://tvn24.pl/swiat/wlochy-ratowniczka-pierwszego-dnia-pracy-uratowala-piec-osob-na-plazy-w-sabaudii-7256877?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T04:37:20+00:00

<img alt="Pierwszego dnia pracy uratowała pięć osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-82g7bl-sabaudia-7256881/alternates/LANDSCAPE_1280" />
    19-latka patrolowała jedną z włoskich plaż.

## "Jeśli ma w sobie borelie, to na pewno nam je przekaże"
 - [https://tvn24.pl/polska/jak-reagowac-na-ukaszenie-kleszcza-7256846?source=rss](https://tvn24.pl/polska/jak-reagowac-na-ukaszenie-kleszcza-7256846?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T04:33:00+00:00

<img alt="" src="https://tvn24.pl/toteraz/cdn-zdjecie-vc9n9z-fakty-i-mity-o-kleszczach-7178030/alternates/LANDSCAPE_1280" />
    Sezon w pełni, więc warto wiedzieć, co robić po kontakcie z kleszczami.

## Atak hakerski na "Politykę". "Kilkukrotnie silniejszy od poprzedniego"
 - [https://tvn24.pl/biznes/z-kraju/tygodnik-polityka-atak-hakerski-na-serwis-internetowy-polityki-7256879?source=rss](https://tvn24.pl/biznes/z-kraju/tygodnik-polityka-atak-hakerski-na-serwis-internetowy-polityki-7256879?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T04:29:40+00:00

<img alt="Atak hakerski na " src="https://tvn24.pl/najnowsze/cdn-zdjecie-w9qh92-polityka-7256891/alternates/LANDSCAPE_1280" />
    Poinformowała redakcja.

## W tych miejscach pogoda będzie zagrożeniem dla życia i zdrowia. Alerty IMGW
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-w-polsce-w-tych-miejscach-pogoda-bedzie-zagrozeniem-dla-zycia-i-zdrowia-pogoda-na-wtorek-2507-7256880?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-w-polsce-w-tych-miejscach-pogoda-bedzie-zagrozeniem-dla-zycia-i-zdrowia-pogoda-na-wtorek-2507-7256880?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T04:29:31+00:00

<img alt="W tych miejscach pogoda będzie zagrożeniem dla życia i zdrowia. Alerty IMGW" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kubair-burze-piorun-7198458/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie pogoda będzie niebezpieczna.

## "Na zabawie dla dzieci widać było popiół"
 - [https://tvn24.pl/swiat/grecja-rodos-pozary-i-ewakuacja-polakow-rozmowa-reporterki-tvn24-z-dziecmi-w-punkcie-pomocowym-7256857?source=rss](https://tvn24.pl/swiat/grecja-rodos-pozary-i-ewakuacja-polakow-rozmowa-reporterki-tvn24-z-dziecmi-w-punkcie-pomocowym-7256857?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T04:19:23+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vlg7j5-zdjecia-z-ogarnietego-pozarami-rodos-7256610/alternates/LANDSCAPE_1280" />
    Dzieci przebywające w punkcie pomocowym opowiedziały o ewakuacji na Rodos.

## Kryzys zdrowotny w Barcelonie zażegnany
 - [https://eurosport.tvn24.pl/pilka-nozna/barcelona-wznowila-treningi-kryzys-zdrowotny-zazegnany_sto9716330/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/barcelona-wznowila-treningi-kryzys-zdrowotny-zazegnany_sto9716330/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T04:14:00+00:00

<img alt="Kryzys zdrowotny w Barcelonie zażegnany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j516il-pilkarze-barcelony-wrocili-do-treningow-7256883/alternates/LANDSCAPE_1280" />
     Piłkarze wrócili do treningów.

## Orban nazwał Słowację "oderwanym terytorium". Ambasador wezwany do wyjaśnień
 - [https://tvn24.pl/swiat/wegry-viktor-orban-nazwal-slowacje-oderwanym-terytorium-bratyslawa-komentuje-i-wzywa-ambasadora-do-msz-7256864?source=rss](https://tvn24.pl/swiat/wegry-viktor-orban-nazwal-slowacje-oderwanym-terytorium-bratyslawa-komentuje-i-wzywa-ambasadora-do-msz-7256864?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T04:08:43+00:00

<img alt="Orban nazwał Słowację " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xccpbv-viktor-orban-7193652/alternates/LANDSCAPE_1280" />
    Orban uczestniczył w 32. letniej szkole Węgrów, którą zorganizowano w rumuńskiej Baile Tuszade.

## Skandal w policji, pożary, samochód wjechał w ludzi
 - [https://tvn24.pl/swiat/szesc-rzeczy-ktore-warto-wiedziec-25-lipca-7256870?source=rss](https://tvn24.pl/swiat/szesc-rzeczy-ktore-warto-wiedziec-25-lipca-7256870?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T03:58:20+00:00

<img alt="Skandal w policji, pożary, samochód wjechał w ludzi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6jud8f-grecja-7256878/alternates/LANDSCAPE_1280" />
    Sześć rzeczy, które warto wiedzieć 25 lipca.

## Ostatnie godziny w Ukrainie i wokół niej. Co się wydarzyło
 - [https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-7256871?source=rss](https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-7256871?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T03:35:26+00:00

<img alt="Ostatnie godziny w Ukrainie i wokół niej. Co się wydarzyło" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r97ik6-ukrainski-zolnierz-w-obwodzie-donieckim-7255247/alternates/LANDSCAPE_1280" />
    Rosyjska pełnoskalowa inwazja na Ukrainę trwa od 517 dni.

## Duszący dym, porzucone walizki. Część Polaków w kraju. Opowiadają o ucieczce przed ogniem
 - [https://tvn24.pl/swiat/pozary-w-grecji-turysci-z-rodos-opowiadaja-o-ucieczce-przed-pozarami-7256876?source=rss](https://tvn24.pl/swiat/pozary-w-grecji-turysci-z-rodos-opowiadaja-o-ucieczce-przed-pozarami-7256876?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T03:25:20+00:00

<img alt="Duszący dym, porzucone walizki. Część Polaków w kraju. Opowiadają o ucieczce przed ogniem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-acjvg5-narodowa-sluzba-meteorologiczna-grecji-ostrzega-przed-kolejna-fala-upalow-7256875/alternates/LANDSCAPE_1280" />
    Turyści ewakuowani z wyspy Rodos wylądowali na Okęciu.

## Niespokojna noc w Kijowie
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-wtorek-25-lipca-2023-7256872?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-wtorek-25-lipca-2023-7256872?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-07-25T03:17:01+00:00

<img alt="Niespokojna noc w Kijowie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3brxmu-kijow-ukraina-7219148/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

