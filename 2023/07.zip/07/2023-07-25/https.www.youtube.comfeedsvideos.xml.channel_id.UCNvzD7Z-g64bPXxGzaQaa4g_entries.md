# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Video Games That WANT YOU BACK
 - [https://www.youtube.com/watch?v=b_G7dsoL1aU](https://www.youtube.com/watch?v=b_G7dsoL1aU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-07-25T15:19:29+00:00

Some video game franchises REALLY want players to return. Here are some games doing good things.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:22 Assassin's Creed Mirage
2:45 Cyberpunk Phantom Liberty
5:18 Skull & Bones 
6:57 Stalker 2: Heart of Chornobyl
8:28 Test Drive unlimited solar crown
9:26 Armored Core 6
10:49 POP: The lost crown
12:09 Alan Wake 2
14:13 Silent Hill 2 Remake
16:12 Alone in the Dark

