# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Belgia. Sąd w Brukseli uznał sześciu mężczyzn winnych zamachom terrorystycznym z marca 2016 roku
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/belgia-sad-w-brukseli-uznal-szesciu-mezczyzn-winnych-zamachom-terrorystycznym-z-marca-2016-roku/](https://www.polsatnews.pl/wiadomosc/2023-07-25/belgia-sad-w-brukseli-uznal-szesciu-mezczyzn-winnych-zamachom-terrorystycznym-z-marca-2016-roku/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T20:36:00+00:00

Po siedmiu miesiącach procesu brukselski sąd uznał Salaha Abdeslama i Mohameda Abriniego za winnych morderstwa w kontekście terrorystycznym - podał we wtorek Le Figaro. Ten sam werdykt usłyszało jeszcze sześciu innych uczestników procesu.

## Ukraina: Poseł bawił się w pięciogwiazdkowym hotelu na Malediwach. Dobrowolnie złożył mandat
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/ukraina-posel-bawil-w-pieciogwiazdkowym-hotelu-dobrowolnie-zlozyl-mandat/](https://www.polsatnews.pl/wiadomosc/2023-07-25/ukraina-posel-bawil-w-pieciogwiazdkowym-hotelu-dobrowolnie-zlozyl-mandat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T19:44:00+00:00

Jurij Aristow, deputowany z partii Wołodymyra Zełenskiego, został przyłapany przez dziennikarzy na wakacjach na Malediwach. Gdy sytuacja wyszła na jaw, poseł zrezygnował ze swojego mandatu. Jego wniosek ma zostać rozpatrzony na najbliższym posiedzeniu Rady Najwyższej Ukrainy.

## "Interwencja": Kupiła auto w komisie. Przestało jeździć po miesiącu
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/interwencja-kupila-auto-w-komisie-przestalo-jezdzic-po-miesiacu/](https://www.polsatnews.pl/wiadomosc/2023-07-25/interwencja-kupila-auto-w-komisie-przestalo-jezdzic-po-miesiacu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T15:58:00+00:00

Agnieszka Popadeńczuk kupiła za 8 tys. zł w komisie w Zabrzu dwudziestoletniego opla. Miesiąc później auto… przestało jeździć. Do wymiany jest rozrząd i układ wydechowy. Kobieta twierdzi, że w komisie zapewniano ją, że auto jest w pełni sprawne. Za to protokole sprzedaży zapisano coś innego. Materiał Interwencji.

## Ibiza: Dwukrotnie próbował porwać dziecko na plaży. Wszedł z nim do wody
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/ibiza-dwukrotnie-probowal-porwac-dziecko-na-plazy-wszedl-z-nim-do-wody/](https://www.polsatnews.pl/wiadomosc/2023-07-25/ibiza-dwukrotnie-probowal-porwac-dziecko-na-plazy-wszedl-z-nim-do-wody/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T15:47:00+00:00

Obywatel Maroka dwukrotnie próbował porwać dziewczynkę, która była razem z matką na plaży na Ibizie. Mężczyzna miał całować dziecko po twarzy i wejść z nim do morza. Na krzyki matki zareagował policjant po służbie, który akurat odpoczywał nad wodą. Podejrzany został aresztowany - poinformowały hiszpańskie organy ścigania.

## Łotwa. Awaria oczyszczali ścieków w Lipawie. Zanieczyszczenia trafiły do Bałtyku
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/lotwa-awaria-oczyszczali-sciekow-w-lipawie-spowodowala-zanieczyszczenie-wody-w-baltyku/](https://www.polsatnews.pl/wiadomosc/2023-07-25/lotwa-awaria-oczyszczali-sciekow-w-lipawie-spowodowala-zanieczyszczenie-wody-w-baltyku/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T15:26:00+00:00

Nawet 1250 metrów sześciennych ścieków mogło trafić do Morza Bałtyckiego po awarii w oczyszczalni w Lipawie na Łotwie. Tamtejszy sanepid zamknął okoliczne plaże, a państwowa Służba Ochrony Środowiska rozpoczęła dochodzenie.

## Rosja. Władimir Putin był "sparaliżowany" po rozpoczęciu buntu wagnerowców
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/rosja-wladimir-putin-byl-sparalizowany-po-rozpoczeciu-buntu-wagnerowcow/](https://www.polsatnews.pl/wiadomosc/2023-07-25/rosja-wladimir-putin-byl-sparalizowany-po-rozpoczeciu-buntu-wagnerowcow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T14:16:00+00:00

Władimir Putin był sparaliżowany i niezdolny do podjęcia zdecydowanych działań - twierdzą informatorzy The Washington Post, którzy opisali nastroje panujące na Kremlu po rozpoczęciu buntu wagnerowców. Mimo, że prezydent Rosji od kilku dni wiedział o planowanych przez Jewgienija Prigożyna działaniach, to po wejściu do Rostowa i rozpoczęciu marszu na Moskwę, zapanował chaos.

## Niezwykłe zjawisko w Patagonii. Wszystko uchwycono na filmie
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/niezwykle-zjawisko-w-patagonii-wszystko-uchwycono-na-filmie/](https://www.polsatnews.pl/wiadomosc/2023-07-25/niezwykle-zjawisko-w-patagonii-wszystko-uchwycono-na-filmie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T13:54:00+00:00

Argentyńska fotograf uchwyciła niezwykłe zjawisko w Patagonii. Gaby Chavez zarejestrowała tajemniczy świetlisty krąg nad ośnieżonymi pagórkami. Okazuje się, że za wyjątkowy widok odpowiadają unoszące się w powietrzu kryształki lodu.

## Malta: Z powodu upałów występują przerwy w dostawie prądu. Sklepy muszą wyrzucać jedzenie
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/malta-z-powodu-upalow-wystepuja-przerwy-w-dostawie-pradu-sklepy-musza-wyrzucac-zywnosc/](https://www.polsatnews.pl/wiadomosc/2023-07-25/malta-z-powodu-upalow-wystepuja-przerwy-w-dostawie-pradu-sklepy-musza-wyrzucac-zywnosc/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T13:13:00+00:00

Na Malcie fala upałów spowodowała powszechne przerwy w dostawie prądu. Obywatele krytykują rząd premiera Roberta Abeli i obawiają się, że sytuacja może zaszkodzić turystyce. Media obiegły zdjęcia jednego z supermarketów, na których widać puste lodówki. Sklep musiał wyrzucić jedzenie, które z powodu braku prądu zaczęło się rozmrażać.

## Pożary w Grecji. Samolot pożarniczy rozbił się w trakcie akcji. Na pokładzie co najmniej dwie osoby
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/pozary-w-grecji-samolot-pozarniczy-rozbil-sie-w-trakcie-akcji-na-pokladzie-co-najmniej-dwie-osoby/](https://www.polsatnews.pl/wiadomosc/2023-07-25/pozary-w-grecji-samolot-pozarniczy-rozbil-sie-w-trakcie-akcji-na-pokladzie-co-najmniej-dwie-osoby/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T13:00:00+00:00

Informację o katastrofie samolotu gaśniczego typu Canadair podała grecka straż pożarna. Nie wiadomo, czy załoga przeżyła katastrofę. Walka z pożarami pustoszącymi kilka rejonów Grecji trwa siódmy dzień.

## USA: 10-latek strzelał do policjantów. "Był zrozpaczony"
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/usa-10-latek-strzelal-do-policjantow-byl-zrozpaczony/](https://www.polsatnews.pl/wiadomosc/2023-07-25/usa-10-latek-strzelal-do-policjantow-byl-zrozpaczony/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T12:50:00+00:00

10-letni chłopiec chwycił za broń i oddał strzały w kierunku mundurowych w dzielnicy Beverly na południu Chicago. Jak podała policja, dziecko było w rozpaczy.

## Nowe zdjęcia obozu wagnerowców na Białorusi. Zauważono ważny szczegół
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/nowe-zdjecia-obozu-wagnerowcow-na-bialorusi-zauwazono-wazny-szczegol/](https://www.polsatnews.pl/wiadomosc/2023-07-25/nowe-zdjecia-obozu-wagnerowcow-na-bialorusi-zauwazono-wazny-szczegol/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T10:57:00+00:00

Pojawiły się nowe zdjęcia satelitarne powstającego na Białorusi obozu grupy Wagnera. Ukraińskie media zwracają uwagę na ważny szczegół. Ma on wskazywać na powód, dla którego baza powstała właśnie w tym miejscu. Co więcej, na zdjęciach widać setki pojazdów, sprzęt budowlany oraz cmentarz.

## USA: Niedźwiedź utknął w samochodzie. Właścicielka auta nagrała zmagania
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/usa-niedzwiedz-utknal-w-samochodzie-wlascicielka-auta-nagrala-zmagania/](https://www.polsatnews.pl/wiadomosc/2023-07-25/usa-niedzwiedz-utknal-w-samochodzie-wlascicielka-auta-nagrala-zmagania/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T09:40:00+00:00

W Stanach Zjednoczonych niedźwiedź włamujący się do samochodu nie jest rzadkim widokiem. Nieczęsto jednak zdarza się, by zwierzę zatrzasnęło się w środku i nie mogło wyjść. Tak było w tym przypadku. Drapieżnik nie mógł wydostać się z auta. Całe zajście obserwowała właścicielka pojazdu, która nagrała zmagania.

## Pożary w Grecji. Jakie odszkodowania przysługują turystom?
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/pozary-w-grecji-jakie-odszkodowania-przysluguja-turystom/](https://www.polsatnews.pl/wiadomosc/2023-07-25/pozary-w-grecji-jakie-odszkodowania-przysluguja-turystom/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T09:01:00+00:00

Gdy na greckich wyspach szaleją żywioły, a turyści w popłochu uciekają przed goniącym ich pożarem, Polsat News sprawdził, jakie prawa przysługują klientom biur podróży. - Turyści mają rzeczywiście trudniej - przyznaje Bartosz Kempa, autor serwisu Zmarnowanyurlop.pl i wskazuje, na które przepisy mogą powoływać się poszkodowani.

## Szef kuchni Baracka Obamy nie żyje. Zginął w pobliżu posiadłości byłej pary prezydenckiej
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/szef-kuchni-baracka-obamy-nie-zyje-zginal-w-poblizu-posiadlosci-bylej-pary-prezydenckiej/](https://www.polsatnews.pl/wiadomosc/2023-07-25/szef-kuchni-baracka-obamy-nie-zyje-zginal-w-poblizu-posiadlosci-bylej-pary-prezydenckiej/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T06:59:00+00:00

Osobisty szef kuchni byłego prezydenta USA Tafari Campbell utonął w jeziorze w pobliżu rodzinnego domu Obamów w Massachusetts. 45-latek pływał po zbiorniku na desce. Nagle wpadł do wody i - jak relacjonował świadek - już się nie wynurzył.

## Alaksandr Łukaszenka o "wycieczce" Grupy Wagnera do Warszawy i Rzeszowa. Jest odpowiedź USA
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/alaksandr-lukaszenka-o-wycieczce-grupy-wagnera-do-warszawy-i-rzeszowa-jest-odpowiedz-usa/](https://www.polsatnews.pl/wiadomosc/2023-07-25/alaksandr-lukaszenka-o-wycieczce-grupy-wagnera-do-warszawy-i-rzeszowa-jest-odpowiedz-usa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T06:53:00+00:00

- Będziemy bronić każdego cala terytorium NATO - zadeklarował rzecznik Departament Stanu USA. To reakcja na słowa białoruskiego dyktatora Alaksandra Łukaszenki o tym, że Wagnerowcy chcą urządzić wycieczkę do największego miasta Podkarpacia i Warszawy.

## Viktor Orban nazwał Słowację "oderwanym" terytorium. Burza w europejskich stolicach
 - [https://www.polsatnews.pl/wiadomosc/2023-07-25/viktor-orban-nazwal-slowacje-oderwanym-terytorium-burza-w-europejskich-stolicach/](https://www.polsatnews.pl/wiadomosc/2023-07-25/viktor-orban-nazwal-slowacje-oderwanym-terytorium-burza-w-europejskich-stolicach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-07-25T04:56:00+00:00

Węgierski premier Viktor Orban uznał, że dzisiejsza Słowacja jest terytorium oderwanym - w domyśle od dawnych Austro-Węgier w skład których wchodziła. Stwierdził też, że władzę w Czechach zdobyli europejscy federaliści, a jego kraj i Polska są jedynymi w Unii Europejskiej, które dbają o suwerenności. Teorie Orbana wywołały oburzenie w Bukareszcie, Bratysławie i Pradze.

