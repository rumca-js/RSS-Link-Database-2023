# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Dow Jones wydłuża wzrostową serię. S&P500 poprawił szczyt hossy
 - [https://www.bankier.pl/wiadomosc/Dow-Jones-wydluza-wzrostowa-serie-S-P500-poprawil-szczyt-hossy-8584742.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dow-Jones-wydluza-wzrostowa-serie-S-P500-poprawil-szczyt-hossy-8584742.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/1f0e32e37b972a-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najlepiej spisał się Nasdaq, ale to Dow Jones wydłużył
wzrostową serię, a S&amp;P500 zameldował się z nowym tegorocznym maksimum.</p>

## 800+ od czerwca? Komisja senacka za poprawką do budżetu na 2023 rok
 - [https://www.bankier.pl/wiadomosc/800-od-czerwca-Komisja-senacka-za-poprawka-do-budzetu-na-2023-rok-8584709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/800-od-czerwca-Komisja-senacka-za-poprawka-do-budzetu-na-2023-rok-8584709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T18:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/303b69e45d1b7b-948-568-52-172-2947-1768.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Senacka Komisja Budżetu i Finansów Publicznych zaproponowała we wtorek, aby świadczenie 500+ zostało zwiększone o 300 zł z mocą od czerwca 2023 r. Odpowiednią poprawkę zgłoszono do nowelizacji ustawy budżetowej na 2023 r.</p>

## USA ogłosiły kolejny pakiet pomocy dla Ukrainy. Łącznie przekazały już 43 mld dol.
 - [https://www.bankier.pl/wiadomosc/USA-oglosily-kolejny-pakiet-pomocy-dla-Ukrainy-Lacznie-przekazaly-juz-43-mld-dol-8584706.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-oglosily-kolejny-pakiet-pomocy-dla-Ukrainy-Lacznie-przekazaly-juz-43-mld-dol-8584706.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T18:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/ef423ef6a05251-948-568-0-269-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />USA ogłosiły we wtorek kolejny pakiet pomocy wojskowej dla Ukrainy, warty łącznie 400 mln dolarów. W transzy znalazło się 15 różnych rodzajów uzbrojenia, w tym m.in. dodatkowa amunicja do systemów Patriot, NASAMS, HIMARS, 32 wozy opancerzone Stryker oraz mini drony Black Hornet.</p>

## Daninę od nadzwyczajnych zysków z produkcji węgla zapłaci tylko JSW? Jest poprawka do ustawy
 - [https://www.bankier.pl/wiadomosc/Danine-od-nadzwyczajnych-zyskow-z-produkcji-wegla-zaplaci-tylko-JSW-Jest-poprawka-do-ustawy-8584672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Danine-od-nadzwyczajnych-zyskow-z-produkcji-wegla-zaplaci-tylko-JSW-Jest-poprawka-do-ustawy-8584672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T17:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/0/a39406a4c4551d-948-568-0-53-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Senacka komisja gospodarki przyjęła we wtorek 
poprawkę do ustawy o ochronie odbiorców energii ograniczającą do JSW 
grono płatników składki solidarnościowej od ekstra zysków z produkcji 
węgla i koksu w 2022 r.</p>

## Orange Polska pokazało wyniki. Zysk lekko poniżej oczekiwań
 - [https://www.bankier.pl/wiadomosc/Orange-Polska-mial-w-II-kw-823-mln-zl-EBITDAaL-zgodnie-z-konsensusem-8584628.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orange-Polska-mial-w-II-kw-823-mln-zl-EBITDAaL-zgodnie-z-konsensusem-8584628.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T16:02:05.429441+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/4/0ae23a2997544e-948-568-0-51-1475-884.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Orange Polska wypracował w drugim kwartale 2023 roku 823 mln zł EBITDA po uwzględnieniu kosztów leasingu, o 3,1 proc. więcej niż przed rokiem - podała spółka w raporcie. Analitycy ankietowani przez PAP Biznes prognozowali, że spółka osiągnie wynik na poziomie 806,1 mln zł.</p>

## Bogdanka obniżyła cel produkcyjny węgla handlowego na 2023 rok
 - [https://www.bankier.pl/wiadomosc/Bogdanka-obnizyla-cel-produkcyjny-na-2023-rok-do-okolo-7-mln-ton-wegla-handlowego-8584622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bogdanka-obnizyla-cel-produkcyjny-na-2023-rok-do-okolo-7-mln-ton-wegla-handlowego-8584622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T16:02:05.426744+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/68af0e402c6c56-948-568-0-67-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bogdanka obniżyła cel produkcyjny na 2023 rok do około 7 mln ton węgla handlowego - poinformowała spółka w komunikacie.</p>

## Ukraina przygotowuje pierwszy przetarg na rozminowywanie kraju przez firmy prywatne
 - [https://www.bankier.pl/wiadomosc/Ukraina-przygotowuje-pierwszy-przetarg-na-rozminowywanie-kraju-przez-firmy-prywatne-8584591.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-przygotowuje-pierwszy-przetarg-na-rozminowywanie-kraju-przez-firmy-prywatne-8584591.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T16:02:05.422265+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/5/faacd01ea92c7c-948-568-85-185-1915-1148.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd Ukrainy przygotowuje pierwszy przetarg na rozminowywanie kraju; władze chcą zaangażować w proces firmy prywatne - poinformował we wtorek portal Ukrainska Prawda.</p>

## Znów rekordy hossy na GPW. Nowy szczyt WIG20 pod przywództwem KGHM-u
 - [https://www.bankier.pl/wiadomosc/Znow-rekordy-hossy-na-GPW-Nowy-szczyt-WIG20-pod-przywodztwem-KGHM-u-8584595.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Znow-rekordy-hossy-na-GPW-Nowy-szczyt-WIG20-pod-przywodztwem-KGHM-u-8584595.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T16:02:05.394663+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/5/0fe5c770009cdb-948-568-10-10-3564-2138.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />WIG20 poprawił dotychczasowy rekord hossy i na mniej niż 1 proc. zbliżył się do poziomu 2200 pkt., gdzie był notowany przed wybuchem wojny w Ukrainie. Rekordy hossy poprawiły także WIG i mWIG40.</p>

## "Priorytetem polityki mieszkaniowej powinien być rozwój wszystkich form najmu"
 - [https://www.bankier.pl/wiadomosc/Priorytetem-polityki-mieszkaniowej-powinien-byc-rozwoj-wszystkich-form-najmu-8584588.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Priorytetem-polityki-mieszkaniowej-powinien-byc-rozwoj-wszystkich-form-najmu-8584588.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T16:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/b/dfad4e834fcb71-948-568-0-0-3264-1958.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Priorytetem polityki mieszkaniowej na najbliższe lata powinno być równoczesne rozwijanie wszystkich form najmu, czyli najmu rozproszonego, komunalnego i socjalnego, najmu TBS/SIM i najmu profesjonalnego - wynika z raportu "Dekada rynku PRS w Polsce" Polityki Insight i PFR Nieruchomości.</p>

## Polacy od doby koczują na lotnisku w Rodos. Nie wiedzą, kiedy wrócą
 - [https://www.bankier.pl/wiadomosc/Polacy-od-doby-koczuja-na-lotnisku-w-Rodos-Nie-wiedza-kiedy-wroca-8584562.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-od-doby-koczuja-na-lotnisku-w-Rodos-Nie-wiedza-kiedy-wroca-8584562.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T14:57:01.123589+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/88bb9a4189b1fb-948-568-80-130-3920-2351.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od doby na lotnisku w Rodos koczują turyści, którzy w poniedziałek zakończyli wakacje i po południu mieli odlecieć do kraju. "Do Polski przewieziono osoby, które ewakuowano z innych miast, a o tych, którzy planowo mieli powrócić do kraju zapomniano" - powiedziała PAP pani Agnieszka, która od doby koczuje na lotnisku z nastoletnim synem.</p>

## EC Będzin ma nowego prezesa
 - [https://www.bankier.pl/wiadomosc/Rada-nadzorcza-EC-Bedzin-powolala-Marcina-Chodkowskiego-na-prezesa-zarzadu-8584523.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rada-nadzorcza-EC-Bedzin-powolala-Marcina-Chodkowskiego-na-prezesa-zarzadu-8584523.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T14:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/895132f30529cb-948-568-3-18-1146-687.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada nadzorcza Elektrociepłowni Będzin powołała na funkcje prezesa zarządu Marcina Chodkowskiego, dotychczasowego wiceprezesa ds. korporacyjnych - poinformowano w komunikacie. Chodkowski jest związany ze spółką od stycznia 2023 r.</p>

## Pożary w Grecji. Na Krecie zakazane są grille, ogniska i lampiony
 - [https://www.bankier.pl/wiadomosc/Pozary-w-Grecji-Na-Krecie-zakazane-sa-grille-ogniska-i-lampiony-8584519.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pozary-w-Grecji-Na-Krecie-zakazane-sa-grille-ogniska-i-lampiony-8584519.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T14:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/e33360a4953a85-945-560-0-82-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W związku z zagrożeniem pożarowym na Krecie czasowo zostały zakazane grille, ogniska, lampiony, a także jakiekolwiek wykorzystanie ognia w lasach, na polach, łąkach i w pasiekach. Najwyższy, piąty stopień stanu alarmowego obowiązuje na wschodzie wyspy, w Heraklionie, Retimno  i Lasiti. W położonej na zachodzie Chanii wprowadzono niższy, czwarty stopień.</p>

## Którym politykom ufamy najbardziej, a którym najmniej? Jest nowy sondaż CBOS
 - [https://www.bankier.pl/wiadomosc/Ktorym-politykom-ufamy-najbardziej-a-ktorym-najmniej-Jest-nowy-sondaz-CBOS-8584512.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ktorym-politykom-ufamy-najbardziej-a-ktorym-najmniej-Jest-nowy-sondaz-CBOS-8584512.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T14:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/0195463ba1832b-948-568-0-0-3286-1972.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda, prezydent Warszawy Rafał Trzaskowski, prezes PSL Władysław Kosiniak-Kamysz to liderzy lipcowego rankingu zaufania polityków. Największą nieufność ankietowani wyrażają wobec: Jarosława Kaczyńskiego, Zbigniewa Ziobry i Donalda Tuska.</p>

## Tysiące tajemniczych przesyłek z zagranicy budzą niepokój w Korei Południowej
 - [https://www.bankier.pl/wiadomosc/Tysiace-tajemniczych-przesylek-z-zagranicy-budza-niepokoj-w-Korei-Poludniowej-8584508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tysiace-tajemniczych-przesylek-z-zagranicy-budza-niepokoj-w-Korei-Poludniowej-8584508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T14:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/2ec096f205b1d1-948-568-0-116-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tajemnicze paczki wysyłane z zagranicy wzbudzają od czwartku strach i niepokój w Korei Południowej. Policja odebrała przeszło 2 tys. zgłoszeń dotyczących podejrzanych paczek. W czwartek media poinformowały o hospitalizacji trzech osób, które otworzyły przesyłki z Tajwanu - informuje agencja Yonhap. Dotychczas nie znaleziono materiałów niebezpiecznych, a władze mówią, że sprawa nie ma związku z terroryzmem.</p>

## Chorwacja walczy z kilkoma niebezpicznymi żywiołami jednocześnie
 - [https://www.bankier.pl/wiadomosc/Chorwacja-walczy-z-kilkoma-niebezpicznymi-zywiolami-jednoczesnie-8584493.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chorwacja-walczy-z-kilkoma-niebezpicznymi-zywiolami-jednoczesnie-8584493.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T14:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/0eb3a1257f66eb-948-568-0-335-3195-1916.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W kilku regionach Chorwacji ogłoszono czerwony alert pogodowy z powodu nadchodzących burz; w nocy z poniedziałku na wtorek wybuchł pożar, który zbliżał się do położonego na południu kraju Dubrownika, lecz sytuację udało się opanować - poinformował portal thedubrovniktimes.com.</p>

## Te kraje są przeciwne przedłużeniu zakazu eksportu ukraińskiego zboża, m.in. do Polski
 - [https://www.bankier.pl/wiadomosc/Te-kraje-sa-przeciwne-przedluzeniu-zakazu-eksportu-ukrainskiego-zboza-m-in-do-Polski-8584487.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Te-kraje-sa-przeciwne-przedluzeniu-zakazu-eksportu-ukrainskiego-zboza-m-in-do-Polski-8584487.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T14:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/8df1e998a58495-948-568-53-0-1811-1086.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Francja i Niemcy sprzeciwiają się przedłużeniu zakazu eksportu ukraińskiej pszenicy, kukurydzy, rzepaku i słonecznika do 5 krajów, w tym Polski po 15 września. "Niedopuszczalne jest, aby niektóre państwa członkowskie uchylały obowiązujące traktaty" – powiedział we wtorek niemiecki minister rolnictwa Cem Oezdemir. Polska, Węgry, Słowacja, Bułgaria, Rumunia chcą przedłużenia. W poniedziałek ambasador Polski przy UE Andrzej Sadoś informował w Brukseli, że europejscy rolnicy nie mają szans na uczciwą konkurencję i nie można dopuścić do tego, by zbankrutowali.</p>

## MFW zweryfikował swoje prognozy dynamiki PKB Polski
 - [https://www.bankier.pl/wiadomosc/MFW-zweryfikowal-swoje-prognozy-dynamiki-PKB-Polski-8584482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MFW-zweryfikowal-swoje-prognozy-dynamiki-PKB-Polski-8584482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T14:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/414a08a8c3961e-948-568-0-40-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Międzynarodowy Fundusz Walutowy podwyższył prognozę dynamiki PKB Polski w 2023 r. do 1,2 proc. z 0,3 proc., a na 2024 r. obniżył do 2,2 proc. z 2,4 proc. - wynika z bazy danych najnowszej wersji cyklicznego raportu MFW World Economic Outlook.</p>

## Tajne mieszkania dla ludzi PiS - ciąg dalszy. TDT zamierza pozwać posłów KO
 - [https://www.bankier.pl/wiadomosc/Tajne-mieszkania-dla-ludzi-PiS-ciag-dalszy-TDT-zamierza-pozwac-poslow-KO-8584470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tajne-mieszkania-dla-ludzi-PiS-ciag-dalszy-TDT-zamierza-pozwac-poslow-KO-8584470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T13:51:58.257340+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/0/d76800f6ef70cc-760-455-840-176-760-455.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Transportowy Dozór Techniczny (TDT) zamierza pozwać posłów Michała Szczerbę i Dariusza Jońskiego. Chodzi o sprawę pokoi w siedzibie TDT, które zdaniem polityków KO miały być wynajmowane prominentnym działaczom PiS.</p>

## Minister Bortniczuk: Jesteśmy gotowi użyć do ewakuacji polskich turystów samolotów rządowych
 - [https://www.bankier.pl/wiadomosc/Minister-Bortniczuk-Jestesmy-gotowi-uzyc-do-ewakuacji-polskich-turystow-samolotow-rzadowych-8584425.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-Bortniczuk-Jestesmy-gotowi-uzyc-do-ewakuacji-polskich-turystow-samolotow-rzadowych-8584425.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T12:46:55.210491+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/67c5548d4c7313-948-568-20-70-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na dziś biura nie zgłosiły potrzeby interwencji MSiT w proces organizacji powrotu polskich turystów do kraju. Jeżeli taka potrzeba nastąpi, jesteśmy gotowi użyć do tego procesu samolotów pozostających w dyspozycji rządu RP - napisał we wtorek na Twitterze minister sportu i turystyki Kamil Bortniczuk.</p>

## Miliardy dla Ukrainy. Komisja Europejska wypłaciła kolejną transzę pomocy
 - [https://www.bankier.pl/wiadomosc/Miliardy-dla-Ukrainy-Komisja-Europejska-wyplacila-kolejna-transze-pomocy-8584396.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Miliardy-dla-Ukrainy-Komisja-Europejska-wyplacila-kolejna-transze-pomocy-8584396.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T12:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/4/3f6dcbbbc8e958-948-568-0-180-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska wypłaciła we wtorek szóstą transzę w wysokości 1,5 mld euro w ramach pakietu unijnej pomocy makrofinansowej dla Ukrainy o wartości do 18 mld euro.</p>

## Efektywność energetyczna - trzeba będzie ograniczyć zużycie m.in. prądu. UE przyjęła dyrektywę
 - [https://www.bankier.pl/wiadomosc/Efektywnosc-energetyczna-UE-przyjela-dyrektywe-ktora-ma-ograniczyc-zuzycie-energii-8584382.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Efektywnosc-energetyczna-UE-przyjela-dyrektywe-ktora-ma-ograniczyc-zuzycie-energii-8584382.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T12:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/aaeb31b14a569c-948-568-33-0-2602-1561.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Unia Europejska chce zmniejszyć zużycie energii końcowej na szczeblu UE o 11,7 proc. w 2030 r. Aby osiągnąć ten cel, państwa członkowskie będą mogły skorzystać z elastycznych rozwiązań. We wtorek przyjęto w tej sprawie nowe przepisy.</p>

## O krok bliżej do KPO? Prezydent podpisał ustawę będącą kamieniem milowym
 - [https://www.bankier.pl/wiadomosc/Ustawa-ws-planowania-i-zagospodarowania-przestrzennego-z-podpisem-prezydenta-8584364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ustawa-ws-planowania-i-zagospodarowania-przestrzennego-z-podpisem-prezydenta-8584364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T11:41:57.798651+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/2/496ae5af9be4c5-948-568-0-70-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda podpisał nowelę ustawy o planowaniu i zagospodarowaniu przestrzennym, której celem jest uproszczenie, ujednolicenie i przyspieszenie procedury planistycznej - poinformowała we wtorek Kancelaria Prezydenta RP.</p>

## KNF nie pozwoli refinansować niektórych kredytów, by obniżyć raty? Nadzór zabrał głos
 - [https://www.bankier.pl/wiadomosc/KNF-nie-pozwoli-refinansowac-niektorych-kredytow-by-obnizyc-raty-Nadzor-zabral-glos-8584365.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KNF-nie-pozwoli-refinansowac-niektorych-kredytow-by-obnizyc-raty-Nadzor-zabral-glos-8584365.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T11:41:57.779451+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/1/8b39199260ac6d-948-568-0-12-2525-1514.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />UKNF w swoim stanowisku z czerwca nie odbiera kredytobiorcom możliwości zrefinansowania kredytów mieszkaniowych zaciągniętych na okresowo stałą stopę procentową w celu obniżenia kosztów takich kredytów w perspektywie potencjalnej obniżki stóp procentowych NBP – poinformował PAP Biznes Jacek Jastrzębski, przewodniczący Komisji Nadzoru Finansowego.</p>

## Koniec podatku PCC (ale nie dla wszystkich) i użytkowania wieczystego. Prezydent podpisał ustawę
 - [https://www.bankier.pl/wiadomosc/Koniec-podatku-PCC-i-uzytkowania-wieczystego-Prezydent-podpisal-ustawe-8584377.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-podatku-PCC-i-uzytkowania-wieczystego-Prezydent-podpisal-ustawe-8584377.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T11:41:57.771911+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/9d9d099c078338-948-568-0-129-1991-1194.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda podpisał ustawę ws. likwidacji użytkowania wieczystego, która umożliwi firmom, osobom fizycznym i spółdzielniom mieszkaniowym wykup gruntów. Regulacja przewiduje też, że nabycie pierwszego mieszkania będzie zwolnione z PCC - podała we wtorek Kancelaria Prezydenta RP.</p>

## Millennium: ryzyko recesji oddaliło się, najciekawszym aktywem obligacje skarbowe
 - [https://www.bankier.pl/wiadomosc/Millennium-ryzyko-recesji-oddalilo-sie-najciekawszym-aktywem-obligacje-skarbowe-8584336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Millennium-ryzyko-recesji-oddalilo-sie-najciekawszym-aktywem-obligacje-skarbowe-8584336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T11:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/f/f5fcbba097d34c-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ryzyko globalnej silnej recesji oddaliło się, a rynki rozwinięte dość sprawnie radzą sobie z inflacją. Zdaniem zarządzających Millennium TFI, wraz z możliwymi w nowym roku obniżkami stóp proc. na świecie będzie rosła atrakcyjność obligacji skarbowych, które oferują najlepszy stosunek zysku do ryzyka.</p>

## Spotify podnosi ceny za abonamenty. Pierwszy raz od ponad dekady
 - [https://www.bankier.pl/wiadomosc/Spotify-podnosi-ceny-za-abonamenty-Pierwszy-raz-od-ponad-dekady-8584307.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spotify-podnosi-ceny-za-abonamenty-Pierwszy-raz-od-ponad-dekady-8584307.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T11:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/1/ec3984c4a0c259-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Znana platforma streamingowa Spotify zapowiedziała podwyżki cen za abonamenty. Na razie na wyższe ceny muszą przygotować się klienci ze Stanów Zjednoczonych i wielu innych krajów na świecie. W Polsce możemy na ten moment odetchnąć z ulgą, ponieważ ominęły nas te podwyżki. 
</p>

## Użytkownicy Steama na celowniku cyberprzestępców. NASK ostrzega
 - [https://www.bankier.pl/wiadomosc/Uzytkownicy-Steama-na-celowniku-cyberprzestepcow-NASK-ostrzega-8584300.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Uzytkownicy-Steama-na-celowniku-cyberprzestepcow-NASK-ostrzega-8584300.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T10:36:57.155409+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/8/66359c91aa62f7-945-560-139-96-1603-961.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />NASK ostrzega przed oszustami, którzy wyłudzają dane do serwisu Steam. Używają do tego fałszywego panelu logowania - oszuści dokładnie dopracowali stronę - podkreślono.</p>

## Stopa bezrobocia w dół. Nowe dane GUS
 - [https://www.bankier.pl/wiadomosc/Stopa-bezrobocia-w-czerwcu-w-dol-Nowe-dane-GUS-8584232.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stopa-bezrobocia-w-czerwcu-w-dol-Nowe-dane-GUS-8584232.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T10:36:57.148190+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/c24ca871167ae3-945-560-0-0-1400-839.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stopa bezrobocia w czerwcu 2023 r. wyniosła 5,0 proc. wobec 5,1 proc. miesiąc wcześniej - podał Główny Urząd Statystyczny.</p>

## Prawdziwa plaga. Na cudzą tożsamość próbowano wyłudzić łącznie 50 mln zł
 - [https://www.bankier.pl/wiadomosc/Prawdziwa-plaga-Na-cudza-tozsamosc-probowano-wyludzic-lacznie-50-mln-zl-8584301.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prawdziwa-plaga-Na-cudza-tozsamosc-probowano-wyludzic-lacznie-50-mln-zl-8584301.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T10:36:57.121978+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/f964bd52856c6e-948-567-15-50-985-590.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Związek Banków Polskich podał nowe statystyki dotyczące prób wyłudzeń kredytów na skradzioną tożsamość. W II kwartale 2023 r. złodzieje próbowali w ten sposób ukraść łącznie ponad 50 mln zł. Odnotowano ponad 2,1 tys. prób wyłudzeń.</p>

## "Bezpieczny kredyt 2 proc." wkrótce w kolejnych 6 bankach. ZBP ujawnia liczbę wniosków
 - [https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-wkrotce-w-kolejnych-6-bankach-ZBP-ujawnia-liczbe-wnioskow-8584296.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-wkrotce-w-kolejnych-6-bankach-ZBP-ujawnia-liczbe-wnioskow-8584296.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T10:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/7/9df31436f4770b-948-568-0-0-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wkrótce "Bezpieczny Kredyt 2 proc." będzie dostęny w kolejnych 6 bankach - poinformowała na konferencji wiceprezes ZBP Agnieszka Wachnicka. Dodała, że w ramach programu  złożono 11495 wniosków, zawarto 223 umowy z klientami i założono 370 kont mieszkaniowych.</p>

## Tydzień pożarów w Grecji. Najgorsza sytuacja wciąż na Rodos
 - [https://www.bankier.pl/wiadomosc/Tydzien-pozarow-w-Grecji-Najgorsza-sytuacja-wciaz-na-Rodos-8584290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tydzien-pozarow-w-Grecji-Najgorsza-sytuacja-wciaz-na-Rodos-8584290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T10:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/8/cc0dc540b3c2e1-948-568-15-7-2985-1790.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już tydzień trwa walka strażaków z pożarami pustoszącymi kilka rejonów Grecji - napisał we wtorek grecki portal ekhatimerini.com. Najgorsza sytuacja wciąż jest na Rodos - trwa ewakuacja turystów, a operatorzy odwołują wycieczki - dodano.</p>

## Brytyjskie biura podróży nadal wysyłają turystów na Rodos. Zniżki na pobyt w nadpalonych hotelach
 - [https://www.bankier.pl/wiadomosc/Brytyjskie-biura-podrozy-nadal-wysylaja-turystow-na-Rodos-Znizki-na-pobyt-w-nadpalonych-hotelach-8584281.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjskie-biura-podrozy-nadal-wysylaja-turystow-na-Rodos-Znizki-na-pobyt-w-nadpalonych-hotelach-8584281.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T10:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/947351bfff7873-948-568-20-220-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niektóre linie lotnicze i biura turystyczne nadal wysyłają na Rodos kolejnych turystów, a nawet oferują zniżki na pobyt w uszkodzonych przez ogień hotelach - pisze we wtorek brytyjski dziennik "i". Od tygodnia w Grecji szaleją pożary i trwa ewakuacja turystów z Rodos.</p>

## Sycylia płonie. Powodem rekordowe upały - temperatury sięgają 47 stopni
 - [https://www.bankier.pl/wiadomosc/Sycylia-plonie-Powodem-rekordowe-upaly-temperatury-siegaja-47-stopni-8584267.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sycylia-plonie-Powodem-rekordowe-upaly-temperatury-siegaja-47-stopni-8584267.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T09:31:48.536062+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/5/c92a09fd3f976e-948-568-0-124-3840-2303.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 50 pożarów trawi Sycylię - poinformowała we wtorek Ansa. Najtrudniejsza sytuacja panuje w rejonie Palermo. Gaszenie ognia przez śmigłowce utrudnia silny wiatr- scirocco. Na wyspie utrzymują się rekordowe upały, sięgające 47 stopni.</p>

## Zmowa cenowa na rynku malin? UOKiK przedstawia wyniki kontroli
 - [https://www.bankier.pl/wiadomosc/Zmowa-cenowa-na-rynku-malin-UOKiK-przedstawia-wyniki-kontroli-8584282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmowa-cenowa-na-rynku-malin-UOKiK-przedstawia-wyniki-kontroli-8584282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T09:31:48.515495+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/961f5d8313cc8a-948-568-0-243-4242-2545.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brak jest podstaw do twierdzeń, że trudna sytuacja na rynku malin może być wynikiem zmowy cenowej skupów lub przetwórców - wskazał we wtorek Urząd Ochrony Konkurencji i Konsumentów. Wcześniej przeprowadził kontrolę w blisko 60 skupach i u pięciu największych przetwórców.</p>

## DeGiro ukarane w Holandii. Inwestor wygrał z brokerem, po pieniądze mogą zgłosić się kolejni
 - [https://www.bankier.pl/wiadomosc/DeGiro-ukarane-w-Holandii-moga-ruszyc-kolejne-sprawy-8584228.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/DeGiro-ukarane-w-Holandii-moga-ruszyc-kolejne-sprawy-8584228.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/cf5a717928965c-948-568-0-49-1785-1070.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Holenderski regulator ukarał DeGiro. Broker musi zapłacić klientowi 31 500 euro odszkodowania, za kierowanie jego zleceń do strony trzeciej i oszukiwanie go co do sposobu ich realizacji. Werdykt może uruchomić lawinę podobnych spraw.</p>

## Chromecast naruszył patenty? W grze setki milionów odszkodowania od Google'a
 - [https://www.bankier.pl/wiadomosc/Chromecast-naruszyl-patenty-W-grze-setki-milionow-odszkodowania-od-Google-a-8584249.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chromecast-naruszyl-patenty-W-grze-setki-milionow-odszkodowania-od-Google-a-8584249.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T09:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/c915ff1c4fc49d-948-568-148-157-3351-2010.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Technologia zdalnego przesyłania obrazu z telefonu na telewizor, którą z powodzeniem wykorzystuje Google w popularnym urządzeniu Chromecast narusza niektóre patenty firmy Touchstream Technologies – orzekł sąd w Teksasie. Jak donosi Reuters, Google został zobowiązany do zapłaty wielomilionowego odszkodowania. Gigant z Mountain View zapowiada odwołanie.</p>

## Liczba ludności Polski znowu w dół. Jakby zniknęło miasto wielkości Rybnika
 - [https://www.bankier.pl/wiadomosc/W-czerwcu-spadla-liczba-ludnosci-Polski-Nowe-dane-GUS-8584242.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-czerwcu-spadla-liczba-ludnosci-Polski-Nowe-dane-GUS-8584242.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T09:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/3b27113c6b769a-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba ludności Polski na koniec czerwca spadła rdr o 130 tys. do 37,698 mln osób - podał GUS.</p>

## Ukraina nie odpuści. "Będziemy nadal atakować okupowany Krym"
 - [https://www.bankier.pl/wiadomosc/Ukraina-nie-odpusci-Bedziemy-nadal-atakowac-okupowany-Krym-8584219.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-nie-odpusci-Bedziemy-nadal-atakowac-okupowany-Krym-8584219.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T08:26:47.155937+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/ac053909be8691-948-568-0-110-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będziemy nadal atakować okupowany Krym i most, który łączy półwysep z Rosją - powiedział ukraiński minister obrony Ołeksij Reznikow w wywiadzie opublikowanym we wtorek przez CNN. Jak się okazuje, sztab zakładał, że ukraińska kontrofensywa pójdzie szybciej niż ma to miejsce.</p>

## Zaporoska Elektrownia Atomowa zaminowana. Najnowsze dane MAEA
 - [https://www.bankier.pl/wiadomosc/Zaporoska-Elektrownia-Atomowa-zaminowana-Najnowsze-dane-MAEA-8584253.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zaporoska-Elektrownia-Atomowa-zaminowana-Najnowsze-dane-MAEA-8584253.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T08:26:47.153614+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/557ba5d6f6d278-948-568-0-35-1280-767.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Eksperci Międzynarodowej Agencji Energii Atomowej (MAEA) zaobserwowali kierunkowe miny przeciwpiechotne na obrzeżach ukraińskiej Zaporoskiej Elektrowni Jądrowej - poinformował we wtorek dyrektor generalny MAEA Rafael Grossi na stronie internetowej kierowanej przez siebie organizacji.</p>

## Złoty czeka na bankierów. Kurs euro w trendzie bocznym
 - [https://www.bankier.pl/wiadomosc/Zloty-czeka-na-bankierow-Kurs-euro-w-trendzie-bocznym-8584220.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zloty-czeka-na-bankierow-Kurs-euro-w-trendzie-bocznym-8584220.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T08:26:47.141339+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/22a87b3dda74c6-948-568-202-288-4069-2441.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przed posiedzeniami najważniejszych banków centralnych
świata kurs euro do złotego utrzymuje się w lokalnym trendzie bocznym.</p>

## Rząd blokuje rosyjski kapitał. Tymczasowy zarząd przymusowy w 2 spółkach
 - [https://www.bankier.pl/wiadomosc/Rzad-blokuje-rosyjski-kapital-Tymczasowy-zarzad-przymusowy-w-2-spolkach-Boerner-8584234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-blokuje-rosyjski-kapital-Tymczasowy-zarzad-przymusowy-w-2-spolkach-Boerner-8584234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T08:26:47.134028+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/43d7dd7825d9b1-948-568-0-123-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podjęto kolejną decyzję o wprowadzeniu tymczasowego przymusowego zarządu w spółkach powiązanych z Rosjanami: Boerner Insulation i Boerner Service - poinformował minister rozwoju i technologii Waldemar Buda. Nie zatrzymujemy się w blokowaniu rosyjskiego kapitału - dodał.</p>

## Wyciekły zarobki pracowników Google. Ogromne dysproporcje w wynagrodzeniach
 - [https://www.bankier.pl/wiadomosc/Wyciekly-zarobki-pracownikow-Google-Ogromne-dysproporcje-w-wynagrodzeniach-8584218.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyciekly-zarobki-pracownikow-Google-Ogromne-dysproporcje-w-wynagrodzeniach-8584218.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T08:26:47.127238+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/4/b57fb27ba58111-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />
Amerykański magazyn Business Insider opublikował strukturę wynagrodzeń w Google za 2022 rok. Średnie wynagrodzenie w grupie technologicznej wyniosło 280 tys. dolarów. Jest to jednak niepełny obraz sytuacji, ponieważ dane pochodzą z ankiety, którą dobrowolnie wypełniali pracownicy ze Stanów Zjednoczonych.

</p>

## Orange wyłączy sieć 3G. Kiedy i co zrobi konkurencja?
 - [https://www.bankier.pl/wiadomosc/Orange-Polska-planuje-rozpoczac-wylaczanie-sieci-3G-w-II-polowie-IX-UKE-8584215.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orange-Polska-planuje-rozpoczac-wylaczanie-sieci-3G-w-II-polowie-IX-UKE-8584215.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T08:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/22ba2cc077a9e9-948-568-0-40-1613-967.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Orange Polska planuje rozpocząć wyłączanie sieci 3G w II połowie września - podał na blogu Urząd Komunikacji Elektronicznej.</p>

## Frankowe żniwa Votum. IV kw. zapowiada rekordową liczbę wyroków
 - [https://www.bankier.pl/wiadomosc/Liczba-wyrokow-dot-CHF-wzrosla-w-I-pol-23-do-co-najmniej-8-1-tys-IV-kw-zapowiada-sie-rekordowo-Votum-8584206.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Liczba-wyrokow-dot-CHF-wzrosla-w-I-pol-23-do-co-najmniej-8-1-tys-IV-kw-zapowiada-sie-rekordowo-Votum-8584206.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T08:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/2/db1895bc0c41bf-945-560-0-219-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba zapadłych wyroków sądowych w sprawach frankowych w pierwszym półroczu 2023 r. wzrosła do co najmniej 8,1 tys. z 4 tys. rok wcześniej. Ostatni kwartał 2023 roku zapowiada się pod tym względem rekordowo - ocenia radca prawny Wojciech Bochenek z Bochenek i Wspólnicy Kancelaria Radców Prawnych.</p>

## 500 tys. zł dla ofiary siostry Bernadetty. Zapłacić mają była dyrektorka, zakon i PZU
 - [https://www.bankier.pl/wiadomosc/500-tys-zl-dla-ofiary-siostry-Bernadetty-Zaplacic-maja-byla-dyrektorka-zakon-i-PZU-8584200.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/500-tys-zl-dla-ofiary-siostry-Bernadetty-Zaplacic-maja-byla-dyrektorka-zakon-i-PZU-8584200.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/1a381fa1b9a4b6-948-568-0-0-3888-2332.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd uznał, że były wychowanek ośrodka opiekuńczego w Zabrzu prowadzonego przez siostry boromeuszki otrzyma pół miliona złotych zadośćuczynienia. To odszkodowanie za to, że mężczyzna podczas pobytu w ośrodku jako dziecko był bity i gwałcony. Takie informacje podaje portal oko.press, który dodaje, że zapłacić mają siostra Bernadetta, siostry boromeuszki, a także ich ubezpieczyciel, którym jest PZU.
</p>

## Wyższe zarobki ciągle powodem do zmiany pracy
 - [https://www.bankier.pl/wiadomosc/Wyzsze-zarobki-ciagle-powodem-do-zmiany-pracy-8584189.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyzsze-zarobki-ciagle-powodem-do-zmiany-pracy-8584189.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T07:21:44.749719+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/f0052ddfcc26bc-948-568-0-1020-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spośród badanych w Polsce pracowników, 20 proc. zmieniło pracę głównie z powodu zarobków - wynika z cyklicznego badania firmy Randstad, przeprowadzonego w maju i czerwcu. Spada natomiast odsetek respondentów, którzy w ogóle nie biorą pod uwagę zmiany pracodawcy - dodano.</p>

## Pekin wspiera ceny ropy. Jest najdroższa od 3 miesięcy
 - [https://www.bankier.pl/wiadomosc/Pekin-wspiera-ceny-ropy-Jest-najdrozsza-od-3-miesiecy-8584188.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pekin-wspiera-ceny-ropy-Jest-najdrozsza-od-3-miesiecy-8584188.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T07:21:44.742328+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/66c6aa1505e505-945-560-0-3-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną po doniesieniach z Pekinu w sprawie stymulowania gospodarki Chin - podają maklerzy.</p>

## Proboszcz+. Rząd zbudował mechanizm dofinansowań niczym drugi Fundusz Kościelny
 - [https://www.bankier.pl/wiadomosc/Proboszcz-Rzad-zbudowal-mechanizm-dofinansowan-niczym-drugi-Fundusz-Koscielny-8584167.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Proboszcz-Rzad-zbudowal-mechanizm-dofinansowan-niczym-drugi-Fundusz-Koscielny-8584167.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T07:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/0/bf9ae91753598c-948-568-31-306-4190-2514.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kolejny rządowy program budzi kontrowersje. Nabór w 
konkursie dla gmin na odnowę zabytków zdominowały obiekty sakralne i 
kościelne. Można je też dotować poprzez Fundusz Kościelny, ale tam 
warunki dofinansowania są dużo mniej atrakcyjne - informuje "DGP".</p>

## 14. emerytura. Premier Morawiecki podał termin wypłat
 - [https://www.bankier.pl/wiadomosc/14-emerytura-Premier-Morawiecki-podal-termin-wyplat-8584173.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/14-emerytura-Premier-Morawiecki-podal-termin-wyplat-8584173.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T07:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/4/22cd2b479373e5-948-567-10-5-990-593.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />14. emerytura będzie wypłacona na przełomie sierpnia i września - poinformował premier Mateusz Morawiecki, cytowany w komunikacie.</p>

## Przez Bułgarię do Grecji? Nowy pomysł na eksport ukraińskiego zboża
 - [https://www.bankier.pl/wiadomosc/Przez-Bulgarie-do-Grecji-Nowy-pomysl-na-eksport-ukrainskiego-zboza-8584159.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przez-Bulgarie-do-Grecji-Nowy-pomysl-na-eksport-ukrainskiego-zboza-8584159.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T06:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/a640f9a90b035a-948-568-0-70-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bułgarski premier Nikołaj Nenkow przyznał po poniedziałkowej wizycie w Grecji, że z premierem Kyriakosem Micotakisem omawiał możliwość przewozu ukraińskiego zboża pociągami przez Bułgarię do greckich portów.</p>

## Program lojalnościowy MOL idzie jak burza. Ma już 100 tys. użytkowników
 - [https://www.bankier.pl/wiadomosc/MOL-Polska-pozyskal-100-tys-uzytkownikow-programu-lojalnosciowego-8584153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MOL-Polska-pozyskal-100-tys-uzytkownikow-programu-lojalnosciowego-8584153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T06:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/5/fc7c93d575d6a1-948-568-0-54-1994-1196.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W programie lojalnościowym MOL w ciagu pięciu dni od jego uruchomienia zarejestrowało się w Polsce 100 tys. użytkowników - poinformował MOL w komunikacie prasowym.</p>

## Chiny zbroją Rosję? Dostarczyły m.in. setki tysięcy kamizelek kuloodpornych
 - [https://www.bankier.pl/wiadomosc/Chiny-zbroja-Rosje-Dostarczyly-m-in-setki-tysiecy-kamizelek-kuloodpornych-8584147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-zbroja-Rosje-Dostarczyly-m-in-setki-tysiecy-kamizelek-kuloodpornych-8584147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T06:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/d25789267d12ee-948-568-55-110-1945-1166.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wschód wbrew Zachodowi wspierają rosyjską inwazję na Ukrainę. Firmy w Rosji importują setki tysięcy kamizelek kuloodpornych, hełmów, a także znaczne ilości celowników termowizyjnych i dronów z Chin - podaje portal Politico. Sprzęt jest sprowadzany jako dobra cywilnego przeznaczenia, choć jego faktyczne przeznaczenie jest oczywiste.</p>

## Pieniądze nie dla zwierząt tylko dla partii Szymona Hołowni? Wpłynęło zawiadomienie do prokuratury
 - [https://www.bankier.pl/wiadomosc/Polska-2050-sprzeniewierzyla-dotacje-od-wojewody-Wplynelo-zawiadomienie-do-prokuratury-8584137.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-2050-sprzeniewierzyla-dotacje-od-wojewody-Wplynelo-zawiadomienie-do-prokuratury-8584137.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T05:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/ea495d07f41837-948-568-8-0-1161-696.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dwie organizacje uważają, że stowarzyszenie Szymona Hołowni sprzeniewierzyło środki na pomoc dla czworonogów z Ukrainy - ustaliła "Rzeczpospolita"</p>

## Rosjanie "szturmują" Turcję. Duży wzrost migracji
 - [https://www.bankier.pl/wiadomosc/Rosjanie-szturmuja-Turcje-Duzy-wzrost-migracji-8584127.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosjanie-szturmuja-Turcje-Duzy-wzrost-migracji-8584127.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T05:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/de781ddfd7b29b-945-560-0-580-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2022 roku Rosjanie byli najliczniejszym narodem imigrującym do Turcji. Ogółem zaś, w ubiegłym roku odnotowano wzrost emigracji z Turcji o 62 proc. w porównaniu z rokiem poprzednim - wynika z opublikowanych danych Tureckiego Instytutu Statystycznego (TUIK).</p>

## Kosztowne papierosy. Budżet państwa traci 4 razy więcej niż zyskuje z akcyzy
 - [https://www.bankier.pl/wiadomosc/Kosztowne-papierosy-Budzet-panstwa-traci-4-razy-wiecej-niz-zyskuje-z-akcyzy-8584134.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kosztowne-papierosy-Budzet-panstwa-traci-4-razy-wiecej-niz-zyskuje-z-akcyzy-8584134.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T05:11:45.612963+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/f/7c957e317db805-945-560-0-0-1739-1043.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Palenie okazuje się bardzo kosztowne. I nie chodzi tylko o kwestię leczenia, ale także koszty zwolnień lekarskich, z których palacze korzystają częściej i dłużej niż osoby niepalące - pisze we wtorek "Rzeczpospolita". Papierosy pali dziś średnio co trzeci Polak - dodano.</p>

## Polski freelancer nie narzeka na zarobki. Średnie stawki wzrosły prawie o 25 proc. rdr
 - [https://www.bankier.pl/wiadomosc/Polski-freelancer-nie-narzeka-Srednie-stawki-wzrosly-prawie-o-25-proc-rdr-8584120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polski-freelancer-nie-narzeka-Srednie-stawki-wzrosly-prawie-o-25-proc-rdr-8584120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/92fd8981bebd18-948-568-0-84-2400-1439.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najbardziej urosły zarobki freelancerów zajmujących się animacją, a zmalały specjalistów od programowania i tworzenia sklepów internetowych - wynika z raportu "Stawki freelancerów – w których branżach w I połowie 2023 r. wzrosły najbardziej?". Dodano, że średni ich wzrost to ok. 25 proc. rdr.</p>

## Praca i podróże, czyli przyjemne z pożytecznym, ale nie dla wszystkich. Firmy niezbyt przychylne workation
 - [https://www.bankier.pl/wiadomosc/Firmy-niechetne-workation-Polowa-nie-wie-jak-to-zorganizowac-8583951.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Firmy-niechetne-workation-Polowa-nie-wie-jak-to-zorganizowac-8583951.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T04:06:43.306566+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/51932f134ba5c0-948-568-0-169-2506-1503.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Aż 4 na 10 szefów nie zgadza się na
łączenie pracy z wakacjami, a prawie połowa pracodawców nie ma regulaminu
dotyczącego workation – wynika z badania, jakie przeprowadziła firma doradztwa
personalnego HRK.</p>

## Ranking lokat rocznych. „Szczęśliwa siódemka” w czterech bankach
 - [https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-12-miesiecy-lipiec-2023-Ranking-Bankier-pl-8583749.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-12-miesiecy-lipiec-2023-Ranking-Bankier-pl-8583749.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T04:06:43.303781+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/77618910c89a06-948-568-0-82-3008-1804.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />7,50 proc. w skali roku to najlepszy wynik lipca na lokatach rocznych. Lider tabeli oczekuje otwarcia konta osobistego i wpłaty min. 10 000 zł. Pierwszą trójkę uzupełniają propozycje na 7,10 i 7 proc. w skali roku.</p>

## Deweloperzy chętnie dzielą się zyskami. Mieszkaniówka dalej wypłaca spore dywidendy
 - [https://www.bankier.pl/wiadomosc/Deweloperzy-chetnie-dziela-sie-zyskami-Mieszkaniowka-dalej-placi-spore-dywidendy-8583803.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Deweloperzy-chetnie-dziela-sie-zyskami-Mieszkaniowka-dalej-placi-spore-dywidendy-8583803.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T04:06:43.300988+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/b4217ba7512441-948-568-53-0-1809-1085.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Indeks giełdowych deweloperów notuje rekordy,
sprzedaż mieszkań rośnie, a na dodatek branżowe spółki dalej dzielą się zyskami,
wypłacając akcjonariuszom sowite dywidendy. W niektórych przypadkach na ten cel przeznaczony został prawie cały zysk. </p>

## Dochód podstawowy za bycie człowiekiem. Kryptowaluta twórcy ChatGPT zadebiutowała na giełdach - kurs wystrzelił
 - [https://www.bankier.pl/wiadomosc/Woldcoin-kryptowaluta-tworcy-ChatGPT-juz-na-gieldach-8583847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Woldcoin-kryptowaluta-tworcy-ChatGPT-juz-na-gieldach-8583847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-07-25T04:06:43.298027+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/6/78d71b911b65d3-948-568-10-260-3990-2393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Worldcoin - kryptowaluta dyrektora spółki OpenAI, 
zadebiutowała na giełdach, a jej kurs eksplodował. Projekt mający na 
sztandarach prywatność i demokrację ma zapewnić dochód podstawowy 
"zweryfikowanym ludziom", ale wzbudza przy tym duże kontrowersje.</p>

