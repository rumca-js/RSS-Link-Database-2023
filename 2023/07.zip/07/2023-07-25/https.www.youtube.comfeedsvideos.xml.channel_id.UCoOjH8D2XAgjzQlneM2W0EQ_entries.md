# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## The EVIL History of Doctors (Documentary)
 - [https://www.youtube.com/watch?v=V6DidoPEwSs](https://www.youtube.com/watch?v=V6DidoPEwSs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2023-07-25T15:15:02+00:00

🩸 Check out Aethlon Medical by clicking HERE ➡️ https://bit.ly/3QgCiAx

💻 Learn exactly how I landed my $40/hr work-from-home job ($83k/yr) at 19 years old WITHOUT a degree or experience ✅ Click here ➡️ https://www.evil.university/remote

😳 Learn the ONE SECRET that has made every giant corporation and government successful ➡️ https://evil.university/war 

😈 Watch exclusive documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

📸 Follow me on IG: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran

🎥 About this channel: We make free premium documentaries on money, power, and crime to expose how the world really works. Subscribe for more: https://jake.yt/watch-now

🍔 Subscribe to our other channel @EvilFoodSupply, where we expose all the evils of our modern diet ➡️ https://jake.yt/evilfood

🍿 OUR MOST VIRAL VIDEOS: 
+6M VIEWS:  Nestlé: The Most Evil Business in the World https://youtu.be/rj6JOKrL_vg
+3M VIEWS:  BlackRock: The Company that Owns the World https://youtu.be/1n4zkdfKUAE
+2M VIEWS:  Recycling is literally a scam https://youtu.be/LELvVUIz5pY
+2M VIEWS:  Why do Chinese Billionaires Keep Disappearing? https://youtu.be/qyMsrgI7-_s

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: https://jake.yt/3JEzXLn 

-----------------------

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2023 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

This video was conducted on behalf of Aethlon Medical, Inc., and was funded by Outside The Box Capital Inc. and/or affiliates after TRANSCEND VISUALS, LLC was engaged by Outside The Box Capital Inc. to advertise for Aethlon Medical, Inc. For our full disclaimer, please visit: https://bit.ly/3rHjQGO

