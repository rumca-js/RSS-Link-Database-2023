# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## US Education Dept opens probe into Harvard’s legacy admissions
 - [https://www.aljazeera.com/news/2023/7/25/us-education-dept-opens-probe-into-harvards-legacy-admissions](https://www.aljazeera.com/news/2023/7/25/us-education-dept-opens-probe-into-harvards-legacy-admissions)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T23:25:46+00:00

A complaint earlier this month triggered the investigation, which will consider whether the practice is discriminatory.

## Mexican armed forces facilitated Ayotzinapa disappearances: Panel
 - [https://www.aljazeera.com/news/2023/7/25/mexican-armed-forces-facilitated-ayotzinapa-disappearances-panel](https://www.aljazeera.com/news/2023/7/25/mexican-armed-forces-facilitated-ayotzinapa-disappearances-panel)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T21:56:31+00:00

An independent investigatory panel says security forces obstructed their efforts to investigate human rights scandal.

## Photos: Wildfires ravage Greece, Italy as Mediterranean swelters
 - [https://www.aljazeera.com/gallery/2023/7/25/photos-wildfires-ravage-greece-italy-as-mediterranean-swelters](https://www.aljazeera.com/gallery/2023/7/25/photos-wildfires-ravage-greece-italy-as-mediterranean-swelters)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T21:10:10+00:00

High temperatures and parched ground have sparked wildfires in countries on both sides of the Mediterranean.

## Al Jazeera slams naming of its journalists on Egypt ‘terror’ list
 - [https://www.aljazeera.com/news/2023/7/25/al-jazeera-slams-naming-of-its-journalists-on-egypt-terror-list](https://www.aljazeera.com/news/2023/7/25/al-jazeera-slams-naming-of-its-journalists-on-egypt-terror-list)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T20:57:18+00:00

Al Jazeera Media Network denounces the Egyptian move to reinstate a number of its journalists on &#039;terror&#039; list.

## UK warns Russia may begin targeting civilian ships in Black Sea
 - [https://www.aljazeera.com/news/2023/7/25/uk-warns-russia-may-begin-targeting-civilian-ships-in-black-sea](https://www.aljazeera.com/news/2023/7/25/uk-warns-russia-may-begin-targeting-civilian-ships-in-black-sea)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T20:49:07+00:00

UK ambassador to the UN says the &#039;Russian military may expand their targeting of Ukrainian grain facilities further&#039;.

## Guatemala voters voice uncertainty ahead of presidential run-off
 - [https://www.aljazeera.com/news/2023/7/25/guatemala-voters-voice-uncertainty-ahead-of-presidential-run-off](https://www.aljazeera.com/news/2023/7/25/guatemala-voters-voice-uncertainty-ahead-of-presidential-run-off)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T20:24:08+00:00

Observers fear interference in the final leg of the presidential race, as prosecutors target one of the leading parties.

## Kenya’s Ruto offers to meet leader of opposition protests
 - [https://www.aljazeera.com/news/2023/7/25/kenyas-ruto-offers-to-meet-leader-of-opposition-protests](https://www.aljazeera.com/news/2023/7/25/kenyas-ruto-offers-to-meet-leader-of-opposition-protests)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T19:54:37+00:00

Opposition leader Raila Odinga has accused police of using violence against demonstrators.

## Internet ban partially lifted in India’s violence-hit Manipur
 - [https://www.aljazeera.com/news/2023/7/25/internet-ban-partially-lifted-in-indias-violence-hit-manipur](https://www.aljazeera.com/news/2023/7/25/internet-ban-partially-lifted-in-indias-violence-hit-manipur)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T19:43:43+00:00

State lifts ban on wired broadband internet but social media websites, VPNS and mobile hotspots remain inaccessible.

## US judge blocks Biden’s ‘asylum ban’ at Mexico border
 - [https://www.aljazeera.com/news/2023/7/25/us-judge-blocks-bidens-asylum-ban-at-mexico-border](https://www.aljazeera.com/news/2023/7/25/us-judge-blocks-bidens-asylum-ban-at-mexico-border)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T19:34:11+00:00

Rights groups hail the ruling as a &#039;victory&#039; but note it will have little immediate effect at the US-Mexico border.

## Is Israel being torn apart by law that weakens the Supreme Court?
 - [https://www.aljazeera.com/program/inside-story/2023/7/25/is-israel-being-torn-apart-by-law-that-weakens-the-supreme-court](https://www.aljazeera.com/program/inside-story/2023/7/25/is-israel-being-torn-apart-by-law-that-weakens-the-supreme-court)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T19:31:03+00:00

Months of mass demonstrations fail to stop the far-right government from limiting the judiciary&#039;s independence.

## Belgian court convicts suspects over role in 2016 Brussels attack
 - [https://www.aljazeera.com/news/2023/7/25/belgian-court-convicts-suspects-over-role-in-2016-brussels-attack](https://www.aljazeera.com/news/2023/7/25/belgian-court-convicts-suspects-over-role-in-2016-brussels-attack)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T18:58:12+00:00

Six men have been convicted for two coordinated attacks claimed by ISIL that shook Belgium&#039;s capital.

## Photos: Monument cements Emmett Till case as ‘an American story’
 - [https://www.aljazeera.com/gallery/2023/7/25/photos-monument-cements-emmett-till-case-as-an-american-story](https://www.aljazeera.com/gallery/2023/7/25/photos-monument-cements-emmett-till-case-as-an-american-story)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T18:44:13+00:00

The Black teenager&#039;s killing in Mississippi in 1955 helped propel the US civil rights movement.

## Indian captain Harmanpreet Kaur handed two-match ban for outburst
 - [https://www.aljazeera.com/news/2023/7/25/indian-captain-harmanpreet-kaur-handed-two-match-ban-for-outburst](https://www.aljazeera.com/news/2023/7/25/indian-captain-harmanpreet-kaur-handed-two-match-ban-for-outburst)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T18:04:33+00:00

Kaur was reprimanded for smashing the wickets after her dismissal and terming the umpiring &#039;pathetic&#039;.

## Ecuador declares state of emergency in prisons amid fatal attacks
 - [https://www.aljazeera.com/news/2023/7/25/ecuador-declares-state-of-emergency-in-prisons-amid-fatal-attacks](https://www.aljazeera.com/news/2023/7/25/ecuador-declares-state-of-emergency-in-prisons-amid-fatal-attacks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T18:02:27+00:00

President Guillermo Lasso orders military and police to take control of Ecuador&#039;s prison system after wave of violence.

## Wang Yi replaces Qin Gang as Chinese FM: What to know
 - [https://www.aljazeera.com/news/2023/7/25/wang-yi-replaces-qin-gang-as-chinese-foreign-minister-what-to-know](https://www.aljazeera.com/news/2023/7/25/wang-yi-replaces-qin-gang-as-chinese-foreign-minister-what-to-know)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T18:00:40+00:00

Qin Gang&#039;s removal is seen as an &#039;enormous shock&#039; as the Chinese government reappoints Wang Yi to the post he once held.

## What’s next for Israel after Netanyahu’s judicial overhaul bill?
 - [https://www.aljazeera.com/news/2023/7/25/whats-next-for-israel-after-netanyahus-judicial-overhaul-bill](https://www.aljazeera.com/news/2023/7/25/whats-next-for-israel-after-netanyahus-judicial-overhaul-bill)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T16:53:33+00:00

The new law limiting the powers of the judiciary is not irreversible, but the path ahead is uncertain.

## Biden honours Emmett Till, his mother with US national monument
 - [https://www.aljazeera.com/news/2023/7/25/biden-honours-emmett-till-his-mother-with-us-national-monument](https://www.aljazeera.com/news/2023/7/25/biden-honours-emmett-till-his-mother-with-us-national-monument)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T16:47:44+00:00

The 1955 lynching of Till, a Black teen, and his mother&#039;s subsequent activism helped propel US civil rights movement.

## Will Egypt’s asset sale get it out of its economic hole?
 - [https://www.aljazeera.com/economy/2023/7/25/will-egypts-asset-sale-get-it-out-of-its-economic-hole](https://www.aljazeera.com/economy/2023/7/25/will-egypts-asset-sale-get-it-out-of-its-economic-hole)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T15:57:37+00:00

Egypt is privatising - but is it enough to please the IMF and get more funding from the international financial body?

## Qurans burned outside Egyptian, Turkish embassies in Denmark
 - [https://www.aljazeera.com/news/2023/7/25/qurans-burned-outside-egyptian-turkish-embassies-in-denmark](https://www.aljazeera.com/news/2023/7/25/qurans-burned-outside-egyptian-turkish-embassies-in-denmark)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T15:19:21+00:00

The anti-Islam demonstration in Copenhagen comes after a string of Quran burnings in Sweden and Denmark in recent weeks.

## Tunisia protest marks two years since president’s power grab
 - [https://www.aljazeera.com/news/2023/7/25/tunisia-protest-marks-two-years-since-presidents-power-grab](https://www.aljazeera.com/news/2023/7/25/tunisia-protest-marks-two-years-since-presidents-power-grab)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T15:09:05+00:00

Opposition has kept up its demonstrations against what it calls a &#039;coup&#039; against Tunisia&#039;s democracy.

## DR Congo intensifies street security ahead of Francophone Games
 - [https://www.aljazeera.com/news/2023/7/25/dr-congo-intensifies-street-security-ahead-of-francophone-games](https://www.aljazeera.com/news/2023/7/25/dr-congo-intensifies-street-security-ahead-of-francophone-games)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T14:42:34+00:00

The 10-day Jeux de la Francophonie had been pushed back from 2021 to bring infrastructure up to international standards.

## UN starts moving oil from Yemen tanker in bid to stop disaster
 - [https://www.aljazeera.com/news/2023/7/25/un-starts-moving-oil-from-yemen-tanker-in-bid-to-stop-disaster](https://www.aljazeera.com/news/2023/7/25/un-starts-moving-oil-from-yemen-tanker-in-bid-to-stop-disaster)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T14:08:28+00:00

The supertanker, with more than a million barrels of oil, has been deteriorating since 2015.

## US says Russian aircraft struck its drone with flare over Syria
 - [https://www.aljazeera.com/news/2023/7/25/us-says-russian-aircraft-struck-its-drone-with-flare-over-syria](https://www.aljazeera.com/news/2023/7/25/us-says-russian-aircraft-struck-its-drone-with-flare-over-syria)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T14:00:31+00:00

Incident is latest in a series of recent encounters involving Russian fighter jets and US drones flying over Syria.

## Firefighting plane crashes in Greece as wildfires rage
 - [https://www.aljazeera.com/news/2023/7/25/plane-fighting-wildfires-in-greece-crashes](https://www.aljazeera.com/news/2023/7/25/plane-fighting-wildfires-in-greece-crashes)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T13:55:32+00:00

Search and rescue operation under way after plane with two airmen on board crashes on island of Evia.

## A traumatised father battles Russia on Ukraine’s front line
 - [https://www.aljazeera.com/news/2023/7/25/reporters-notebook-a-traumatised-father-on-ukraines-front-line](https://www.aljazeera.com/news/2023/7/25/reporters-notebook-a-traumatised-father-on-ukraines-front-line)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T13:26:18+00:00

Losses in east Ukraine are felt by soldiers and civilians alike. For many, nothing remains of their homes but memories.

## Peru’s cocaine trade overruns remote Indigenous territory
 - [https://www.aljazeera.com/news/2023/7/25/perus-cocaine-trade-overruns-remote-indigenous-territory](https://www.aljazeera.com/news/2023/7/25/perus-cocaine-trade-overruns-remote-indigenous-territory)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T13:09:26+00:00

As coca production surges, Indigenous communities in Peru fear addiction and violence are encroaching on their lands.

## Suspended Nigerian central bank governor denies firearm charges
 - [https://www.aljazeera.com/economy/2023/7/25/suspended-nigerian-central-bank-governor-denies-firearm-charges](https://www.aljazeera.com/economy/2023/7/25/suspended-nigerian-central-bank-governor-denies-firearm-charges)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T12:37:57+00:00

The central bank chief, Nigeria&#039;s longest-serving, has been suspended since June 10 and in state custody.

## Ruto unmasked: Breaking the rules of Kenya’s game of thrones
 - [https://www.aljazeera.com/opinions/2023/7/25/ruto-unmasked-breaking-the-rules-of-kenyas-game-of-thrones](https://www.aljazeera.com/opinions/2023/7/25/ruto-unmasked-breaking-the-rules-of-kenyas-game-of-thrones)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T12:04:29+00:00

President Ruto seems unwilling to respect the red lines that keep Kenya functioning amid chronic intra-elite fighting.

## One dead in perilous boat journey to reach Spain from Africa
 - [https://www.aljazeera.com/news/2023/7/25/spain-rescues-boat-with-84-people-one-dead](https://www.aljazeera.com/news/2023/7/25/spain-rescues-boat-with-84-people-one-dead)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T11:58:47+00:00

The Spanish coastguard reports the death as it saved 84 others, a day after a similar fatal incident near Senegal.

## Which players have signed for the Saudi Pro League?
 - [https://www.aljazeera.com/news/2023/7/25/which-players-have-signed-for-the-saudi-pro-league](https://www.aljazeera.com/news/2023/7/25/which-players-have-signed-for-the-saudi-pro-league)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T11:37:29+00:00

The exodus of big-name footballers making the move from European leagues to Saudi Arabia shows no sign of abating.

## China’s Foreign Minister Qin Gang removed from office
 - [https://www.aljazeera.com/news/2023/7/25/chinas-foreign-minister-qin-gang-removed-from-office](https://www.aljazeera.com/news/2023/7/25/chinas-foreign-minister-qin-gang-removed-from-office)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T11:27:15+00:00

Announcement by state media comes a month after Qin Gang&#039;s last public appearance.

## China, Philippines and Taiwan brace for Super Typhoon Doksuri
 - [https://www.aljazeera.com/news/2023/7/25/china-philippines-and-taiwan-brace-for-super-typhoon-doksuri](https://www.aljazeera.com/news/2023/7/25/china-philippines-and-taiwan-brace-for-super-typhoon-doksuri)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T11:05:31+00:00

Currently packing top wind speeds of 223kmph, Doksuri will make landfall on the Chinese mainland on Friday.

## Russia’s Shoigu to join Chinese officials in North Korea visit
 - [https://www.aljazeera.com/news/2023/7/25/russias-shoigu-to-join-chinese-officials-in-north-korea-visit](https://www.aljazeera.com/news/2023/7/25/russias-shoigu-to-join-chinese-officials-in-north-korea-visit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T10:34:03+00:00

Moscow and Beijing are set to participate in the 70th anniversary of North Korea&#039;s Victory Day.

## Wildfire closes Sicily airport; storms kill two in northern Italy
 - [https://www.aljazeera.com/news/2023/7/25/wildfire-closes-sicily-airport-storms-kill-two-in-northern-italy](https://www.aljazeera.com/news/2023/7/25/wildfire-closes-sicily-airport-storms-kill-two-in-northern-italy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T09:57:11+00:00

Car and train traffic also disrupted due to fire near Palermo&#039;s airport as trees fall and buildings damaged in Milan.

## The choir helping people reclaim the voices they lost to cancer
 - [https://www.aljazeera.com/features/2023/7/25/the-choir-helping-people-reclaim-the-voices-they-lost-to-cancer](https://www.aljazeera.com/features/2023/7/25/the-choir-helping-people-reclaim-the-voices-they-lost-to-cancer)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T09:35:12+00:00

In the UK, people who underwent life-saving surgery to remove their voice boxes sing songs of hope and survival.

## Southern Turkey rocked by magnitude 5.5 earthquake
 - [https://www.aljazeera.com/news/2023/7/25/southern-turkey-rocked-by-5-5-magnitude-earthquake](https://www.aljazeera.com/news/2023/7/25/southern-turkey-rocked-by-5-5-magnitude-earthquake)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T09:01:16+00:00

The earthquake comes five months after a magnitude 7.8 quake devastated parts of Turkey and Syria.

## India women’s cricket captain slammed for ‘deplorable’ behaviour
 - [https://www.aljazeera.com/news/2023/7/25/india-womens-cricket-captain-slammed-for-deplorable-behaviour](https://www.aljazeera.com/news/2023/7/25/india-womens-cricket-captain-slammed-for-deplorable-behaviour)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T08:46:19+00:00

Harmanpreet Kaur is being criticised after she smashed the stumps and took a verbal swipe at umpires in Bangladesh.

## Deadly wildfires raging across Algeria
 - [https://www.aljazeera.com/gallery/2023/7/25/deadly-wildfires-raging-across-algeria](https://www.aljazeera.com/gallery/2023/7/25/deadly-wildfires-raging-across-algeria)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T08:30:54+00:00

Wildfires, some spread by strong winds, moved across forests and agricultural areas in 16 regions causing 97 blazes.

## Philippines shock New Zealand for first Women’s World Cup win
 - [https://www.aljazeera.com/sports/2023/7/25/philippines-shock-new-zealand-1-0-womens-world-cup](https://www.aljazeera.com/sports/2023/7/25/philippines-shock-new-zealand-1-0-womens-world-cup)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T08:05:38+00:00

Sarina Bolden scores Philippines&#039; historic match-winner from their first shot on goal in a 1-0 win.

## Three Palestinians killed by Israeli forces in occupied West Bank
 - [https://www.aljazeera.com/news/2023/7/25/three-palestinians-killed-by-israeli-forces-in-occupied-west-bank-2](https://www.aljazeera.com/news/2023/7/25/three-palestinians-killed-by-israeli-forces-in-occupied-west-bank-2)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T07:36:21+00:00

The occupied West Bank is currently experiencing a period of increasing violence, marked by repeated Israeli raids.

## S&P lowers Bangladesh’s outlook to negative on liquidity risks
 - [https://www.aljazeera.com/news/2023/7/25/sp-lowers-bangladeshs-outlook-to-negative-on-liquidity-risks](https://www.aljazeera.com/news/2023/7/25/sp-lowers-bangladeshs-outlook-to-negative-on-liquidity-risks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T07:10:49+00:00

Ratings agency says it expects the country&#039;s economy to expand up to 6.4 percent annually between 2024 and 2026.

## JPMorgan ignored Epstein’s ‘nymphettes,’ US Virgin Islands says
 - [https://www.aljazeera.com/economy/2023/7/25/jpmorgan-ignored-epsteins-nymphettes-us-virgin-islands-says](https://www.aljazeera.com/economy/2023/7/25/jpmorgan-ignored-epsteins-nymphettes-us-virgin-islands-says)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T06:51:24+00:00

JPMorgan says US Virgin Islands was also to blame for allowing Epstein&#039;s sexual abuse of young women and girls.

## Binance, CEO Zhao to seek dismissal of US watchdog’s complaint
 - [https://www.aljazeera.com/economy/2023/7/25/binance-ceo-zhao-to-seek-dismissal-of-us-watchdogs-complaint](https://www.aljazeera.com/economy/2023/7/25/binance-ceo-zhao-to-seek-dismissal-of-us-watchdogs-complaint)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T06:39:10+00:00

Commodity Futures Trading Commission is suing crypto exchange for allegedly operating &#039;sham&#039; compliance program.

## Guess who’s holding Trump accountable? Regular American jurors
 - [https://www.aljazeera.com/opinions/2023/7/25/guess-whos-holding-trump-accountable-regular-american-jurors](https://www.aljazeera.com/opinions/2023/7/25/guess-whos-holding-trump-accountable-regular-american-jurors)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T06:15:37+00:00

Benjamin Franklin famously said the US was a republic &#039;if you can keep it&#039;. Everyday Americans are doing just that.

## Sirens blare in Kyiv as Ukrainian forces down Russian drones
 - [https://www.aljazeera.com/news/2023/7/25/sirens-blare-in-kyiv-as-ukrainian-forces-down-russian-drones](https://www.aljazeera.com/news/2023/7/25/sirens-blare-in-kyiv-as-ukrainian-forces-down-russian-drones)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T05:06:03+00:00

Officials say Russia launched Iranian-made Shahed drones in its sixth attack this month on the Ukrainian capital.

## Philippines mulls unlicensed nurses as low pay fuels brain drain
 - [https://www.aljazeera.com/economy/2023/7/25/philippines-mulls-unlicensed-nurses-as-low-pay-fuels-brain-drain](https://www.aljazeera.com/economy/2023/7/25/philippines-mulls-unlicensed-nurses-as-low-pay-fuels-brain-drain)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T04:54:28+00:00

Exodus of nurses due to poor working conditions has prompted Manila to propose hiring unlicensed graduates.

## ‘We are at war’: More evacuations as Greece battles wildfires
 - [https://www.aljazeera.com/news/2023/7/25/we-are-at-war-more-evacuations-as-greece-battles-wildfires](https://www.aljazeera.com/news/2023/7/25/we-are-at-war-more-evacuations-as-greece-battles-wildfires)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T04:39:36+00:00

Prime minister says Greece is at war and faces several difficult days before high temperatures are forecast to ease.

## India police arrest 74 Rohingya refugees in latest crackdown
 - [https://www.aljazeera.com/news/2023/7/25/india-police-arrest-seventy-four-rohingya-in-latest-crackdown-on-refugees](https://www.aljazeera.com/news/2023/7/25/india-police-arrest-seventy-four-rohingya-in-latest-crackdown-on-refugees)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T04:22:44+00:00

The refugees were living in six districts of Uttar Pradesh state &#039;after crossing the border illegally&#039;, police said.

## Tall claims, modest gains as Philippines’s Marcos marks 1st year
 - [https://www.aljazeera.com/news/2023/7/25/tall-claims-modest-gains-as-philippiness-marcos-marks-first-year](https://www.aljazeera.com/news/2023/7/25/tall-claims-modest-gains-as-philippiness-marcos-marks-first-year)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T02:10:13+00:00

Analysts say Marcos&#039;s rhetorical deftness has helped buoy his administration&#039;s lacklustre performance in public&#039;s eyes.

## Barack Obama’s personal chef found dead in Martha’s Vineyard lake
 - [https://www.aljazeera.com/news/2023/7/25/barack-obamas-personal-chef-found-dead-in-marthas-vineyard-lake](https://www.aljazeera.com/news/2023/7/25/barack-obamas-personal-chef-found-dead-in-marthas-vineyard-lake)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T01:02:04+00:00

Obama family say they are heartbroken over death of &#039;warm, fun, extraordinarily kind&#039; chef Tafari Campbell.

## Russia-Ukraine war: List of key events, day 517
 - [https://www.aljazeera.com/news/2023/7/25/russia-ukraine-war-list-of-key-events-day-517](https://www.aljazeera.com/news/2023/7/25/russia-ukraine-war-list-of-key-events-day-517)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T00:37:47+00:00

These are the main developments as the Russian invasion of Ukraine enters its 517th day.

## Ecuador announces state of emergency after mayor shot to death
 - [https://www.aljazeera.com/news/2023/7/25/ecuador-announces-state-of-emergency-after-mayor-shot-to-death](https://www.aljazeera.com/news/2023/7/25/ecuador-announces-state-of-emergency-after-mayor-shot-to-death)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-07-25T00:18:01+00:00

The country is also contending with violence within its prison system as deadly clashes erupt between gangs.

