# Source:Techlinked, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCeeFfhMcJa1kjtfZAGskOCA, language:en-US

## 𝕏
 - [https://www.youtube.com/watch?v=_RMY-aSOAG8](https://www.youtube.com/watch?v=_RMY-aSOAG8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCeeFfhMcJa1kjtfZAGskOCA
 - date published: 2023-07-25T03:06:35+00:00

Save 10% and Free Shipping at Ridge by using offer code LINKED at https://ridge.com/linked

►► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► LISTEN TO THE TECH NEWS: https://lmg.gg/TechLinkedPodcast
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR PODCAST GEAR: https://lmg.gg/podcastgear

NEWS SOURCES: https://lmg.gg/Zz1Cn
---------------------------------------------------
Timestamps:
0:00 Twitter rebrands to 'X'
1:55 Google proposes "DRM for the Web"
3:12 Apple launches Vision Pro dev kits
4:29 The Ridge Wallet
5:07 QUICK BITS
5:13 Worldcoin launch
5:58 Playstation Project Q video leak
6:33 connector-less ASUS RTX 4070 
7:13 GPD's GPU dock works with Steam Deck
7:51 Neopets recruits John Legend

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: http://twitter.com/TechLinkedYT
Instagram: http://instagram.com/TechLinkedYT
Facebook: http://facebook.com/TechLinked
TikTok: https://www.tiktok.com/@techlinkedyt

