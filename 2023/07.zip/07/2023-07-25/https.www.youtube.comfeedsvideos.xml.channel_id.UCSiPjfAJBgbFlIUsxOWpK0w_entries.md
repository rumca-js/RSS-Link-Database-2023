# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Larry is never impressed by his own genius…never. (Also you can listen to “À Cabo” now. 😄)
 - [https://www.youtube.com/watch?v=Fe-Fm_lZ7ZA](https://www.youtube.com/watch?v=Fe-Fm_lZ7ZA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2023-07-25T16:12:21+00:00



