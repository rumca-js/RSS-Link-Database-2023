# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## FLASH FIGHT! Two NASes, all Flashes #shorts
 - [https://www.youtube.com/watch?v=AbwXyopBURI](https://www.youtube.com/watch?v=AbwXyopBURI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2023-07-25T16:05:30+00:00

Check out a longer video with more detail on these two NASes: https://www.youtube.com/watch?v=5QH8Dj6g_Nk

Links to the products mentioned (some are affiliate links):

  - ASUSTOR AS-T10G3 Dual M.2 + 10 GbE card: https://amzn.to/3D1DUpV
  - TeamGroup M.2 SATA 1TB SSD (for Pocket NAS): https://amzn.to/3D3FJTl
  - TeamGroup M.2 NVMe 1TB SSD (for Flashstor): https://amzn.to/3PPySV0
  - ASUSTOR Flashstor 12 Pro: https://amzn.to/3NIfQxh
  - SilverTip Labs' PocketNAS questionnaire: https://rpgtavern.live/index.php?page=mininas
  - Setting up OMV on the Rock 5 model B: https://www.jeffgeerling.com/blog/2023/building-tiny-6-drive-m2-nas-rock-5-model-b
  - Installing TrueNAS on the ASUSTOR: https://www.jeffgeerling.com/blog/2023/how-i-installed-truenas-on-my-new-asustor-nas

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com
2nd Channel: https://www.youtube.com/c/GeerlingEngineering

