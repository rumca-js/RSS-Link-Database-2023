# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Inkscape 1.3 Release: New Features Make it a Better Rival to Adobe Illustrator!
 - [https://news.itsfoss.com/inkscape-1-3-release/](https://news.itsfoss.com/inkscape-1-3-release/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-07-25T09:19:43+00:00

Inkscape 1.3 is all about impressive upgrades. Check out all the details here.

