# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Twitter headquarters left with half a sign as police interrupt
 - [https://www.bbc.co.uk/news/technology-66300107?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-66300107?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-07-25T12:39:31+00:00

The microblogging firm pauses removal of its name at San Francisco HQ after changing its brand to X.

## TikTok: Chinese platform challenges X and Threads with text-only posts
 - [https://www.bbc.co.uk/news/business-66297595?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66297595?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-07-25T05:03:30+00:00

The Chinese-owned app says the new function gives users "another way to express themselves".

## Is Musk right to ditch the Twitter logo?
 - [https://www.bbc.co.uk/news/business-66296468?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66296468?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-07-25T01:43:30+00:00

Rebrands can pay off - but it's a risky move.

