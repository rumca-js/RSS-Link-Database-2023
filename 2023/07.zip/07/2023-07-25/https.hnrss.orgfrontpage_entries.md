# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Seattle in Progress
 - [https://www.seattleinprogress.com/](https://www.seattleinprogress.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T22:40:58+00:00

<p>Article URL: <a href="https://www.seattleinprogress.com/">https://www.seattleinprogress.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36870702">https://news.ycombinator.com/item?id=36870702</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Whom the Gods Would Destroy, They First Give Real-Time Analytics
 - [https://mcfunley.com/whom-the-gods-would-destroy-they-first-give-real-time-analytics](https://mcfunley.com/whom-the-gods-would-destroy-they-first-give-real-time-analytics)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T21:56:00+00:00

<p>Article URL: <a href="https://mcfunley.com/whom-the-gods-would-destroy-they-first-give-real-time-analytics">https://mcfunley.com/whom-the-gods-would-destroy-they-first-give-real-time-analytics</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36870140">https://news.ycombinator.com/item?id=36870140</a></p>
<p>Points: 29</p>
<p># Comments: 6</p>

## Stone Knives and Bear Skins – There is no money in tools
 - [https://queue.acm.org/detail.cfm?id=3606027](https://queue.acm.org/detail.cfm?id=3606027)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T21:18:45+00:00

<p>Article URL: <a href="https://queue.acm.org/detail.cfm?id=3606027">https://queue.acm.org/detail.cfm?id=3606027</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36869747">https://news.ycombinator.com/item?id=36869747</a></p>
<p>Points: 20</p>
<p># Comments: 10</p>

## The Mathematica Journal is no longer accepting submissions
 - [https://www.mathematica-journal.com/](https://www.mathematica-journal.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T21:02:32+00:00

<p>Article URL: <a href="https://www.mathematica-journal.com/">https://www.mathematica-journal.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36869486">https://news.ycombinator.com/item?id=36869486</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## A command-line murder mystery
 - [https://github.com/veltman/clmystery](https://github.com/veltman/clmystery)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T20:33:39+00:00

<p>Article URL: <a href="https://github.com/veltman/clmystery">https://github.com/veltman/clmystery</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36868978">https://news.ycombinator.com/item?id=36868978</a></p>
<p>Points: 35</p>
<p># Comments: 4</p>

## Treemaps Are Awesome!
 - [https://blog.phronemophobic.com/treemaps-are-awesome.html](https://blog.phronemophobic.com/treemaps-are-awesome.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T20:31:12+00:00

<p>Article URL: <a href="https://blog.phronemophobic.com/treemaps-are-awesome.html">https://blog.phronemophobic.com/treemaps-are-awesome.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36868940">https://news.ycombinator.com/item?id=36868940</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## US Education Dept. Opens Civil Rights Inquiry into Harvard’s Legacy Admissions
 - [https://www.nytimes.com/2023/07/25/us/politics/harvard-admissions-civil-rights-inquiry.html](https://www.nytimes.com/2023/07/25/us/politics/harvard-admissions-civil-rights-inquiry.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T20:11:07+00:00

<p>Article URL: <a href="https://www.nytimes.com/2023/07/25/us/politics/harvard-admissions-civil-rights-inquiry.html">https://www.nytimes.com/2023/07/25/us/politics/harvard-admissions-civil-rights-inquiry.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36868630">https://news.ycombinator.com/item?id=36868630</a></p>
<p>Points: 21</p>
<p># Comments: 1</p>

## Alphabet Announces Second Quarter 2023 Results [pdf]
 - [https://abc.xyz/assets/20/ef/844a05b84b6f9dbf2c3592e7d9c7/2023q2-alphabet-earnings-release.pdf](https://abc.xyz/assets/20/ef/844a05b84b6f9dbf2c3592e7d9c7/2023q2-alphabet-earnings-release.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T20:08:45+00:00

<p>Article URL: <a href="https://abc.xyz/assets/20/ef/844a05b84b6f9dbf2c3592e7d9c7/2023q2-alphabet-earnings-release.pdf">https://abc.xyz/assets/20/ef/844a05b84b6f9dbf2c3592e7d9c7/2023q2-alphabet-earnings-release.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36868593">https://news.ycombinator.com/item?id=36868593</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Texas A&M suspended professor accused of criticizing Lt. Gov. Patrick in lecture
 - [https://www.texastribune.org/2023/07/25/texas-a-m-professor-opioids-dan-patrick/](https://www.texastribune.org/2023/07/25/texas-a-m-professor-opioids-dan-patrick/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T19:24:38+00:00

<p>Article URL: <a href="https://www.texastribune.org/2023/07/25/texas-a-m-professor-opioids-dan-patrick/">https://www.texastribune.org/2023/07/25/texas-a-m-professor-opioids-dan-patrick/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36867988">https://news.ycombinator.com/item?id=36867988</a></p>
<p>Points: 80</p>
<p># Comments: 25</p>

## PRQL, Pipelined Relational Query Language
 - [https://github.com/PRQL/prql](https://github.com/PRQL/prql)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T18:13:51+00:00

<p>Article URL: <a href="https://github.com/PRQL/prql">https://github.com/PRQL/prql</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36866861">https://news.ycombinator.com/item?id=36866861</a></p>
<p>Points: 52</p>
<p># Comments: 13</p>

## Show HN: RealAboutInstagram – a replica highlighting harmful strategies
 - [https://realaboutinstagram.netlify.app/](https://realaboutinstagram.netlify.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T18:01:12+00:00

<p>Hello HN! I'm a creative technologist and recently decided to develop RealAboutInstagram, a replica of the current About page of Instagram replacing its content with their current harmful strategies used on the platform and the negative impacts of social media.<p>The information on the website is extracted from resources such as the Digital Minimalism book by Cal Newport, Ted Talks, and many others that can be found in the footer.<p>This is one of many projects for my career, and I appreciate anyone taking the time to read this and check out the website.<p>You can check out my other projects at <a href="https://santiagoaguirre.netlify.app/" rel="nofollow noreferrer">https://santiagoaguirre.netlify.app/</a><p>Thank you for your time!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36866629">https://news.ycombinator.com/item?id=36866629</a></p>
<p>Points: 28</p>
<p># Comments: 4</p>

## The Prophecies of AARON (2022)
 - [https://outland.art/harold-cohen-aaron/](https://outland.art/harold-cohen-aaron/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T17:48:02+00:00

<p>Article URL: <a href="https://outland.art/harold-cohen-aaron/">https://outland.art/harold-cohen-aaron/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36866382">https://news.ycombinator.com/item?id=36866382</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Hyperlink Maximalism (2022)
 - [https://thesephist.com/posts/hyperlink/](https://thesephist.com/posts/hyperlink/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T17:40:37+00:00

<p>Article URL: <a href="https://thesephist.com/posts/hyperlink/">https://thesephist.com/posts/hyperlink/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36866242">https://news.ycombinator.com/item?id=36866242</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Unix-like OS in Rust inspired by xv6-riscv
 - [https://github.com/o8vm/octox](https://github.com/o8vm/octox)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T17:10:38+00:00

<p>Article URL: <a href="https://github.com/o8vm/octox">https://github.com/o8vm/octox</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36865682">https://news.ycombinator.com/item?id=36865682</a></p>
<p>Points: 18</p>
<p># Comments: 6</p>

## Launch HN: Roundtable (YC S23) – Using AI to Simulate Surveys
 - [https://news.ycombinator.com/item?id=36865625](https://news.ycombinator.com/item?id=36865625)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T17:07:12+00:00

<p>Hi HN, we’re Mayank and Matt of Roundtable (<a href="https://roundtable.ai/">https://roundtable.ai/</a>). We use LLMs to produce cheap, yet surprisingly useful, simulations of surveys. Specifically, we train LLMs on standard, curated survey datasets. This approach allows us to essentially build general-purpose models of human behavior and opinion. We combine this with a nice UI that lets users easily visualize and interpret the results.<p>Surveys are incredibly important for user and market research, but are expensive and take months to design, run, and analyze. By simulating responses, our users can get results in seconds and make decisions faster. See <a href="https://roundtable.ai/showcase">https://roundtable.ai/showcase</a> for a bunch of examples, and <a href="https://www.loom.com/share/eb6fb27acebe48839dd561cf1546f131" rel="nofollow noreferrer">https://www.loom.com/share/eb6fb27acebe48839dd561cf1546f131</a> for a demo video.<p>Our product lets you add questions (e.g. “how old are you”) and conditions (e.g. “is a Hacker News user”) and then see how these affect the survey results. For example, the survey “Are you interested in buying an e-bike?” shows ‘yes’ 28% [1]. But if you narrow it down to people who own a Tesla, ‘yes’ jumps to 52% [2]. Another example: if you survey “where did you learn to code”, the question “how old are you?” makes a dramatic difference—for “45 or older” the answer is 55% “books” [3], but for “younger than 45” it’s 76% “online” [4]. One more: 5% of people answer “legroom” to the question “Which of the following factors is most important for choosing which airline to fly?” [5], and this jumps to 20% when you condition on people over six feet tall [6].<p>You wouldn’t think (well, we didn’t think) that such simulated surveys would work very well, but empirically they work a lot better than expected—we have run many surveys in the wild to validate Roundtable's results (e.g. comparing age demographics to U.S. Census data). We’re still trying to figure out why. We believe that LLMs that are pre-trained on the public Internet have internalized a lot of information/correlations about communities (e.g. Tesla drivers, Hacker News, etc.) and can reasonably approximate their behavior. In any case, researchers are seeing the same things that we are. A nice paper by a BYU group [7] discusses extracting sub-population information from GPT/LLMs. A related paper from Microsoft [8] shows how GPT can simulate different human behaviors. It’s an active research topic, and we hope we can get a sense of the theoretical basis relatively soon.<p>Because these models are primarily trained on Internet data, they start out skewed towards the demographics of heavy Internet users (e.g., high-income, male). We addressed this by fine-tuning GPT on the GSS (General Social Survey [9] - the gold standard of demographic surveys in the US) so our models emulate a more representative U.S. population.<p>We’ve built a transparency feature that shows how similar your survey question is to the training data and thus gives a confidence metric of our accuracy. If you click ‘Investigate Results’, we report the most similar (in terms of cosine distance between LLM embeddings) GSS questions as a way of estimating how much extrapolation / interpolation is going on. This doesn’t quite address the accuracy of the subpopulations / conditioning questions (we are working on this), but we thought we are at a sufficiently advanced point to share what we’ve built with you all.<p>We're graduating PhD students from Princeton University in cognitive science and AI. We ran a ton of surveys and behavioral experiments and were often frustrated with the pipeline. We were looking to leave academia, and saw an opportunity in making the survey pipeline better. User and market research is a big market, and many of the tools and methods the industry uses are clunky and slow. Mayank’s PhD work used large datasets and ML for developing interpretable scientific theories, and Matt’s developed complex experimental software to study coordinated group decision-making. We see Roundtable as operating at the intersection of our interests.<p>We charge per survey. We are targeting small and mid-market businesses who have market research teams, and ask for a minimum subscription amount. Pricing is at the bottom of our home page.<p>We are still in the early stages of building this product, and we’d love for you all to play around with the demo and provide us feedback. Let us know whatever you see - this is our first major endeavor into the private sector from academia, and we’re eager to hear whatever you have to say!<p>[1]: <a href="https://roundtable.ai/sandbox/e02e92a9ad20fdd517182788f4ae7e1f96a849c0">https://roundtable.ai/sandbox/e02e92a9ad20fdd517182788f4ae7e...</a><p>[2]: <a href="https://roundtable.ai/sandbox/6b4bf8740ad1945b08c0bf584c84c1202a5fec53">https://roundtable.ai/sandbox/6b4bf8740ad1945b08c0bf584c84c1...</a><p>[3] <a href="https://roundtable.ai/sandbox/d701556248385d05ce5d26ce7fc776bb4d32fad0">https://roundtable.ai/sandbox/d701556248385d05ce5d26ce7fc776...</a><p>[4] <a href="https://roundtable.ai/sandbox/8bd80babad042cf60d500ca28c40f7db413f553a">https://roundtable.ai/sandbox/8bd80babad042cf60d500ca28c40f7...</a><p>[5] <a href="https://roundtable.ai/sandbox/0450d499048c089894c34fba514db4042eafb6c0">https://roundtable.ai/sandbox/0450d499048c089894c34fba514db4...</a><p>[6] <a href="https://roundtable.ai/sandbox/0450d499048c089894c34fba514db4042eafb6c0">https://roundtable.ai/sandbox/0450d499048c089894c34fba514db4...</a><p>[7] <a href="https://arxiv.org/abs/2209.06899" rel="nofollow noreferrer">https://arxiv.org/abs/2209.06899</a><p>[8] <a href="https://openreview.net/pdf?id=eYlLlvzngu" rel="nofollow noreferrer">https://openreview.net/pdf?id=eYlLlvzngu</a><p>[9] <a href="https://www.norc.org/research/projects/gss.html" rel="nofollow noreferrer">https://www.norc.org/research/projects/gss.html</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36865625">https://news.ycombinator.com/item?id=36865625</a></p>
<p>Points: 18</p>
<p># Comments: 13</p>

## Aviator (YC S21) is hiring engineers to build advanced Git tools
 - [https://www.ycombinator.com/companies/aviator/jobs](https://www.ycombinator.com/companies/aviator/jobs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T17:00:53+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/aviator/jobs">https://www.ycombinator.com/companies/aviator/jobs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36865531">https://news.ycombinator.com/item?id=36865531</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## A comprehensive guide to running Llama 2 locally
 - [https://replicate.com/blog/run-llama-locally](https://replicate.com/blog/run-llama-locally)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T16:58:42+00:00

<p>Article URL: <a href="https://replicate.com/blog/run-llama-locally">https://replicate.com/blog/run-llama-locally</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36865495">https://news.ycombinator.com/item?id=36865495</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## GM reverses plan to retire Chevrolet Bolt as it chases EV target
 - [https://www.ft.com/content/fd367bd6-a73a-4d80-b0d0-32837724bd0a](https://www.ft.com/content/fd367bd6-a73a-4d80-b0d0-32837724bd0a)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T16:57:35+00:00

<p>Article URL: <a href="https://www.ft.com/content/fd367bd6-a73a-4d80-b0d0-32837724bd0a">https://www.ft.com/content/fd367bd6-a73a-4d80-b0d0-32837724bd0a</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36865465">https://news.ycombinator.com/item?id=36865465</a></p>
<p>Points: 44</p>
<p># Comments: 41</p>

## I Want Off Mr. Golang's Wild Ride (2022)
 - [https://fasterthanli.me/articles/i-want-off-mr-golangs-wild-ride](https://fasterthanli.me/articles/i-want-off-mr-golangs-wild-ride)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T16:48:59+00:00

<p>Article URL: <a href="https://fasterthanli.me/articles/i-want-off-mr-golangs-wild-ride">https://fasterthanli.me/articles/i-want-off-mr-golangs-wild-ride</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36865309">https://news.ycombinator.com/item?id=36865309</a></p>
<p>Points: 45</p>
<p># Comments: 19</p>

## Unicode is harder than you think
 - [https://mcilloni.ovh/2023/07/23/unicode-is-hard/](https://mcilloni.ovh/2023/07/23/unicode-is-hard/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T16:47:58+00:00

<p>Article URL: <a href="https://mcilloni.ovh/2023/07/23/unicode-is-hard/">https://mcilloni.ovh/2023/07/23/unicode-is-hard/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36865287">https://news.ycombinator.com/item?id=36865287</a></p>
<p>Points: 42</p>
<p># Comments: 11</p>

## Social engineering campaign targeting tech employees spreads through NPM malware
 - [https://socket.dev/blog/social-engineering-campaign-npm-malware](https://socket.dev/blog/social-engineering-campaign-npm-malware)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T16:35:47+00:00

<p>Article URL: <a href="https://socket.dev/blog/social-engineering-campaign-npm-malware">https://socket.dev/blog/social-engineering-campaign-npm-malware</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36865060">https://news.ycombinator.com/item?id=36865060</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Crucial system of ocean currents is collapsing; ‘affects everyone on the planet’
 - [https://www.cnn.com/2023/07/25/world/gulf-stream-atlantic-current-collapse-climate-scn-intl/index.html](https://www.cnn.com/2023/07/25/world/gulf-stream-atlantic-current-collapse-climate-scn-intl/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T16:28:13+00:00

<p>Article URL: <a href="https://www.cnn.com/2023/07/25/world/gulf-stream-atlantic-current-collapse-climate-scn-intl/index.html">https://www.cnn.com/2023/07/25/world/gulf-stream-atlantic-current-collapse-climate-scn-intl/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36864892">https://news.ycombinator.com/item?id=36864892</a></p>
<p>Points: 18</p>
<p># Comments: 3</p>

## The First Room-Temperature Ambient-Pressure Superconductor
 - [https://arxiv.org/abs/2307.12008](https://arxiv.org/abs/2307.12008)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T16:14:32+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2307.12008">https://arxiv.org/abs/2307.12008</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36864624">https://news.ycombinator.com/item?id=36864624</a></p>
<p>Points: 45</p>
<p># Comments: 28</p>

## Autoenshittification. How the computer killed capitalism. – by Cory Doctorow
 - [https://doctorow.medium.com/autoenshittification-cb851c2574fb](https://doctorow.medium.com/autoenshittification-cb851c2574fb)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T16:10:53+00:00

<p>Article URL: <a href="https://doctorow.medium.com/autoenshittification-cb851c2574fb">https://doctorow.medium.com/autoenshittification-cb851c2574fb</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36864547">https://news.ycombinator.com/item?id=36864547</a></p>
<p>Points: 61</p>
<p># Comments: 23</p>

## At this company, we are family
 - [https://pboyd.io/posts/at-company-we-are-family/](https://pboyd.io/posts/at-company-we-are-family/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T16:07:33+00:00

<p>Article URL: <a href="https://pboyd.io/posts/at-company-we-are-family/">https://pboyd.io/posts/at-company-we-are-family/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36864476">https://news.ycombinator.com/item?id=36864476</a></p>
<p>Points: 61</p>
<p># Comments: 9</p>

## Warning of forthcoming collapse of Atlantic meridional overturning circulation
 - [https://www.nature.com/articles/s41467-023-39810-w](https://www.nature.com/articles/s41467-023-39810-w)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T15:59:54+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41467-023-39810-w">https://www.nature.com/articles/s41467-023-39810-w</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36864319">https://news.ycombinator.com/item?id=36864319</a></p>
<p>Points: 83</p>
<p># Comments: 40</p>

## Is technical analysis just stock market astrology?
 - [https://alicegg.tech//2023/07/25/technical-analysis.html](https://alicegg.tech//2023/07/25/technical-analysis.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T15:49:39+00:00

<p>Article URL: <a href="https://alicegg.tech//2023/07/25/technical-analysis.html">https://alicegg.tech//2023/07/25/technical-analysis.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36864115">https://news.ycombinator.com/item?id=36864115</a></p>
<p>Points: 31</p>
<p># Comments: 6</p>

## Show HN: Marsha – An LLM-Based Programming Language
 - [https://github.com/alantech/marsha](https://github.com/alantech/marsha)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T15:43:56+00:00

<p>Article URL: <a href="https://github.com/alantech/marsha">https://github.com/alantech/marsha</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36864021">https://news.ycombinator.com/item?id=36864021</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## The Messaging Layer Security (MLS) Protocol
 - [https://datatracker.ietf.org/doc/html/rfc9420](https://datatracker.ietf.org/doc/html/rfc9420)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T15:38:41+00:00

<p>Article URL: <a href="https://datatracker.ietf.org/doc/html/rfc9420">https://datatracker.ietf.org/doc/html/rfc9420</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36863915">https://news.ycombinator.com/item?id=36863915</a></p>
<p>Points: 30</p>
<p># Comments: 9</p>

## 'Verified human': Worldcoin users queue up for iris scans
 - [https://neuters.de/technology/verified-human-worldcoin-users-queue-up-iris-scans-2023-07-25/](https://neuters.de/technology/verified-human-worldcoin-users-queue-up-iris-scans-2023-07-25/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T15:20:52+00:00

<p>Article URL: <a href="https://neuters.de/technology/verified-human-worldcoin-users-queue-up-iris-scans-2023-07-25/">https://neuters.de/technology/verified-human-worldcoin-users-queue-up-iris-scans-2023-07-25/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36863631">https://news.ycombinator.com/item?id=36863631</a></p>
<p>Points: 37</p>
<p># Comments: 28</p>

## We're Not Platonists, We've Just Learned the Bitter Lesson
 - [https://astralcodexten.substack.com/p/were-not-platonists-weve-just-learned](https://astralcodexten.substack.com/p/were-not-platonists-weve-just-learned)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T15:17:45+00:00

<p>Article URL: <a href="https://astralcodexten.substack.com/p/were-not-platonists-weve-just-learned">https://astralcodexten.substack.com/p/were-not-platonists-weve-just-learned</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36863581">https://news.ycombinator.com/item?id=36863581</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Onnx Runtime: “Cross-Platform Accelerated Machine Learning”
 - [https://onnxruntime.ai/](https://onnxruntime.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T15:13:57+00:00

<p>Article URL: <a href="https://onnxruntime.ai/">https://onnxruntime.ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36863522">https://news.ycombinator.com/item?id=36863522</a></p>
<p>Points: 18</p>
<p># Comments: 4</p>

## Journalists should be skeptical of all sources including scientists
 - [https://www.natesilver.net/p/journalists-should-be-skeptical-of](https://www.natesilver.net/p/journalists-should-be-skeptical-of)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T15:09:11+00:00

<p>Article URL: <a href="https://www.natesilver.net/p/journalists-should-be-skeptical-of">https://www.natesilver.net/p/journalists-should-be-skeptical-of</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36863443">https://news.ycombinator.com/item?id=36863443</a></p>
<p>Points: 44</p>
<p># Comments: 22</p>

## The remote work dominates on HN:Who is hiring? – 69% jobs in 2023 are remote
 - [https://blog.spatial.chat/tracking-hackernews-shifting-preferences-for-remote-jobs-over-5-years/](https://blog.spatial.chat/tracking-hackernews-shifting-preferences-for-remote-jobs-over-5-years/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T14:59:31+00:00

<p>Article URL: <a href="https://blog.spatial.chat/tracking-hackernews-shifting-preferences-for-remote-jobs-over-5-years/">https://blog.spatial.chat/tracking-hackernews-shifting-preferences-for-remote-jobs-over-5-years/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36863280">https://news.ycombinator.com/item?id=36863280</a></p>
<p>Points: 108</p>
<p># Comments: 47</p>

## Goodbye, waitlist. Hello, Arc 1.0
 - [https://twitter.com/browsercompany/status/1683839541399154689](https://twitter.com/browsercompany/status/1683839541399154689)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T14:58:57+00:00

<p>Article URL: <a href="https://twitter.com/browsercompany/status/1683839541399154689">https://twitter.com/browsercompany/status/1683839541399154689</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36863262">https://news.ycombinator.com/item?id=36863262</a></p>
<p>Points: 27</p>
<p># Comments: 38</p>

## Before you try to do something, make sure you can do nothing
 - [https://devblogs.microsoft.com/oldnewthing/20230725-00/?p=108482](https://devblogs.microsoft.com/oldnewthing/20230725-00/?p=108482)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T14:49:14+00:00

<p>Article URL: <a href="https://devblogs.microsoft.com/oldnewthing/20230725-00/?p=108482">https://devblogs.microsoft.com/oldnewthing/20230725-00/?p=108482</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36863094">https://news.ycombinator.com/item?id=36863094</a></p>
<p>Points: 57</p>
<p># Comments: 26</p>

## The burden of Long Covid “so large as to be unfathomable”
 - [https://www.rnz.co.nz/national/programmes/saturday/audio/2018899512/prof-danny-altmann-the-burden-of-long-covid](https://www.rnz.co.nz/national/programmes/saturday/audio/2018899512/prof-danny-altmann-the-burden-of-long-covid)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T14:34:37+00:00

<p>Article URL: <a href="https://www.rnz.co.nz/national/programmes/saturday/audio/2018899512/prof-danny-altmann-the-burden-of-long-covid">https://www.rnz.co.nz/national/programmes/saturday/audio/2018899512/prof-danny-altmann-the-burden-of-long-covid</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36862855">https://news.ycombinator.com/item?id=36862855</a></p>
<p>Points: 75</p>
<p># Comments: 53</p>

## OpenAI Quietly Shuts Down Its AI Detection Tool
 - [https://decrypt.co/149826/openai-quietly-shutters-its-ai-detection-tool](https://decrypt.co/149826/openai-quietly-shutters-its-ai-detection-tool)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T14:34:17+00:00

<p>Article URL: <a href="https://decrypt.co/149826/openai-quietly-shutters-its-ai-detection-tool">https://decrypt.co/149826/openai-quietly-shutters-its-ai-detection-tool</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36862850">https://news.ycombinator.com/item?id=36862850</a></p>
<p>Points: 103</p>
<p># Comments: 54</p>

## Why did it take psychedelics so long to become popular?
 - [https://resobscura.substack.com/p/why-did-it-take-psychedelics-so-long](https://resobscura.substack.com/p/why-did-it-take-psychedelics-so-long)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T14:21:50+00:00

<p>Article URL: <a href="https://resobscura.substack.com/p/why-did-it-take-psychedelics-so-long">https://resobscura.substack.com/p/why-did-it-take-psychedelics-so-long</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36862658">https://news.ycombinator.com/item?id=36862658</a></p>
<p>Points: 11</p>
<p># Comments: 9</p>

## Arc 1.0 – a freeware web browser developed by The Browser Company
 - [https://arc.net/](https://arc.net/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T14:14:25+00:00

<p>Article URL: <a href="https://arc.net/">https://arc.net/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36862546">https://news.ycombinator.com/item?id=36862546</a></p>
<p>Points: 28</p>
<p># Comments: 32</p>

## Apple already shipped attestation on the web, and we barely noticed
 - [https://httptoolkit.com/blog/apple-private-access-tokens-attestation/](https://httptoolkit.com/blog/apple-private-access-tokens-attestation/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T14:10:12+00:00

<p>Article URL: <a href="https://httptoolkit.com/blog/apple-private-access-tokens-attestation/">https://httptoolkit.com/blog/apple-private-access-tokens-attestation/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36862494">https://news.ycombinator.com/item?id=36862494</a></p>
<p>Points: 101</p>
<p># Comments: 49</p>

## Safari 17 Link Tracking Protection
 - [https://mjtsai.com/blog/2023/06/19/safari-17-link-tracking-protection/](https://mjtsai.com/blog/2023/06/19/safari-17-link-tracking-protection/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T13:18:09+00:00

<p>Article URL: <a href="https://mjtsai.com/blog/2023/06/19/safari-17-link-tracking-protection/">https://mjtsai.com/blog/2023/06/19/safari-17-link-tracking-protection/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36861755">https://news.ycombinator.com/item?id=36861755</a></p>
<p>Points: 22</p>
<p># Comments: 10</p>

## Life on Earth didn’t arise as described in textbooks
 - [https://science.ku.dk/english/press/news/2023/life-on-earth-didnt-arise-as-described-in-textbooks/](https://science.ku.dk/english/press/news/2023/life-on-earth-didnt-arise-as-described-in-textbooks/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T12:52:57+00:00

<p>Article URL: <a href="https://science.ku.dk/english/press/news/2023/life-on-earth-didnt-arise-as-described-in-textbooks/">https://science.ku.dk/english/press/news/2023/life-on-earth-didnt-arise-as-described-in-textbooks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36861499">https://news.ycombinator.com/item?id=36861499</a></p>
<p>Points: 51</p>
<p># Comments: 93</p>

## Ask HN: Does a framework exist for “open-source SaaS”?
 - [https://news.ycombinator.com/item?id=36861409](https://news.ycombinator.com/item?id=36861409)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T12:44:07+00:00

<p>The OSS model for collaborating on code is broadly understood. I'm curious if anyone has been successful in deploying and hosting a SaaS app in an open-source way, using community or public user funding.<p>For example, many of us use Calendly. There are many for-profit Calendly alternatives. Could we band together and create an open-source, truly free Calendly alternative where users split hosting costs in a fair way? The cost for functionality would go down to pennies per user, since no one expects to make a profit. I don't necessarily want to take on the whole burden of self-hosting an open-source platform, but would be happy to pay for usage if those funds only go towards keeping the platform online.<p>Just curious if some such experiment has been successful, or perhaps why they fail.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36861409">https://news.ycombinator.com/item?id=36861409</a></p>
<p>Points: 7</p>
<p># Comments: 8</p>

## Our World of Pixels
 - [https://ourworldofpixels.com/](https://ourworldofpixels.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T12:33:01+00:00

<p>Article URL: <a href="https://ourworldofpixels.com/">https://ourworldofpixels.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36861302">https://news.ycombinator.com/item?id=36861302</a></p>
<p>Points: 17</p>
<p># Comments: 11</p>

## What We Know About LLMs (A Primer)
 - [https://willthompson.name/what-we-know-about-llms-primer](https://willthompson.name/what-we-know-about-llms-primer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T11:57:27+00:00

<p>Article URL: <a href="https://willthompson.name/what-we-know-about-llms-primer">https://willthompson.name/what-we-know-about-llms-primer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36860992">https://news.ycombinator.com/item?id=36860992</a></p>
<p>Points: 29</p>
<p># Comments: 2</p>

## Show HN: Invoice Dragon – An Open Source App to Create PDF Invoices for Free
 - [https://invoicedragon.com/](https://invoicedragon.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T11:45:06+00:00

<p>Article URL: <a href="https://invoicedragon.com/">https://invoicedragon.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36860898">https://news.ycombinator.com/item?id=36860898</a></p>
<p>Points: 43</p>
<p># Comments: 15</p>

## Textual Paint – MS Paint in your terminal
 - [https://github.com/1j01/textual-paint](https://github.com/1j01/textual-paint)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T09:20:50+00:00

<p>Article URL: <a href="https://github.com/1j01/textual-paint">https://github.com/1j01/textual-paint</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36859880">https://news.ycombinator.com/item?id=36859880</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

## From Python to Elixir Machine Learning
 - [https://www.thestackcanary.com/from-python-pytorch-to-elixir-nx/](https://www.thestackcanary.com/from-python-pytorch-to-elixir-nx/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T09:04:21+00:00

<p>Article URL: <a href="https://www.thestackcanary.com/from-python-pytorch-to-elixir-nx/">https://www.thestackcanary.com/from-python-pytorch-to-elixir-nx/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36859785">https://news.ycombinator.com/item?id=36859785</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## I've skimmed 66520 newsgroups trying to find some life on the Usenet (2020)
 - [https://mastodon.sdf.org/@cfenollosa/103469996345323076](https://mastodon.sdf.org/@cfenollosa/103469996345323076)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T08:26:22+00:00

<p>Article URL: <a href="https://mastodon.sdf.org/@cfenollosa/103469996345323076">https://mastodon.sdf.org/@cfenollosa/103469996345323076</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36859510">https://news.ycombinator.com/item?id=36859510</a></p>
<p>Points: 29</p>
<p># Comments: 11</p>

## YouTube is banning links to filmmusic (free music provider), appeal doesn't work
 - [https://news.ycombinator.com/item?id=36858642](https://news.ycombinator.com/item?id=36858642)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T06:21:55+00:00

<p>Just got this email a few mins ago:<p>> We wanted to let you know our team reviewed your content, and we think it violates our spam, deceptive practices and scams policy. We know you may not have realized this was a violation of our policies, so we're not applying a strike to your channel. However, we have removed the following content from YouTube:
> URL: ht tps://filmmusic. io/standard-license<p>Looks like some false positive, Youtube is really banning links to a valid and safe URL.
The "appeal" link doesn't seem to work either. Worst part is that this probably affects thousands of videos using royalty free music, and they are now breaking the license due to deleting the attribution link :(<p>Any ideas on how to contact YT to fix that?<p>Edit: they have fixed it!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36858642">https://news.ycombinator.com/item?id=36858642</a></p>
<p>Points: 14</p>
<p># Comments: 2</p>

## Robo-Taxis are rolling, did you notice?
 - [https://cmte.ieee.org/futuredirections/2023/07/25/robo-taxi-are-rolling-did-you-notice/](https://cmte.ieee.org/futuredirections/2023/07/25/robo-taxi-are-rolling-did-you-notice/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T06:19:49+00:00

<p>Article URL: <a href="https://cmte.ieee.org/futuredirections/2023/07/25/robo-taxi-are-rolling-did-you-notice/">https://cmte.ieee.org/futuredirections/2023/07/25/robo-taxi-are-rolling-did-you-notice/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36858633">https://news.ycombinator.com/item?id=36858633</a></p>
<p>Points: 13</p>
<p># Comments: 8</p>

## The 1990s Amiga with Video Toaster has a VFX cool factor that endures today
 - [https://cdm.link/2023/07/amiga-video-toaster-cool-factor/](https://cdm.link/2023/07/amiga-video-toaster-cool-factor/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T04:07:36+00:00

<p>Article URL: <a href="https://cdm.link/2023/07/amiga-video-toaster-cool-factor/">https://cdm.link/2023/07/amiga-video-toaster-cool-factor/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36857758">https://news.ycombinator.com/item?id=36857758</a></p>
<p>Points: 19</p>
<p># Comments: 2</p>

## Contributor to Google's WEI repo: So, you don't like a web platform proposal
 - [https://blog.yoav.ws/posts/web_platform_change_you_do_not_like/](https://blog.yoav.ws/posts/web_platform_change_you_do_not_like/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T03:55:43+00:00

<p>Article URL: <a href="https://blog.yoav.ws/posts/web_platform_change_you_do_not_like/">https://blog.yoav.ws/posts/web_platform_change_you_do_not_like/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36857676">https://news.ycombinator.com/item?id=36857676</a></p>
<p>Points: 5</p>
<p># Comments: 3</p>

## Parents, environmentalists to Google: stop Chromebooks from expiring this summer
 - [https://pirg.org/edfund/resources/chromebook-expiration-full-letter/](https://pirg.org/edfund/resources/chromebook-expiration-full-letter/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T03:27:58+00:00

<p>Article URL: <a href="https://pirg.org/edfund/resources/chromebook-expiration-full-letter/">https://pirg.org/edfund/resources/chromebook-expiration-full-letter/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36857506">https://news.ycombinator.com/item?id=36857506</a></p>
<p>Points: 25</p>
<p># Comments: 3</p>

## Got called to a professor’s office after a complaint his Sparc4 was running slow
 - [https://infosec.exchange/@paco/110772422266480371](https://infosec.exchange/@paco/110772422266480371)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T03:00:26+00:00

<p>Article URL: <a href="https://infosec.exchange/@paco/110772422266480371">https://infosec.exchange/@paco/110772422266480371</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36857314">https://news.ycombinator.com/item?id=36857314</a></p>
<p>Points: 20</p>
<p># Comments: 4</p>

## Mozilla Standards Positions Opposes Web Integrity API
 - [https://github.com/mozilla/standards-positions/issues/852](https://github.com/mozilla/standards-positions/issues/852)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T02:14:27+00:00

<p>Article URL: <a href="https://github.com/mozilla/standards-positions/issues/852">https://github.com/mozilla/standards-positions/issues/852</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36857032">https://news.ycombinator.com/item?id=36857032</a></p>
<p>Points: 70</p>
<p># Comments: 7</p>

## Intro to Drone Detection Radar with Emphasis on Automatic Target Recognition
 - [https://arxiv.org/abs/2307.10326](https://arxiv.org/abs/2307.10326)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T02:02:36+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2307.10326">https://arxiv.org/abs/2307.10326</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36856946">https://news.ycombinator.com/item?id=36856946</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## How Signal Walks the Line Between Anarchism and Pragmatism
 - [https://www.wired.com/story/signal-politics-software-criticism/](https://www.wired.com/story/signal-politics-software-criticism/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T01:53:45+00:00

<p>Article URL: <a href="https://www.wired.com/story/signal-politics-software-criticism/">https://www.wired.com/story/signal-politics-software-criticism/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36856882">https://news.ycombinator.com/item?id=36856882</a></p>
<p>Points: 17</p>
<p># Comments: 11</p>

## Play the Nimatron, the World’s First Video Game Invented in 1930s New York
 - [https://flashbak.com/play-the-nimatron-the-worlds-first-video-game-invented-in-1930s-new-york-462185/](https://flashbak.com/play-the-nimatron-the-worlds-first-video-game-invented-in-1930s-new-york-462185/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T01:37:15+00:00

<p>Article URL: <a href="https://flashbak.com/play-the-nimatron-the-worlds-first-video-game-invented-in-1930s-new-york-462185/">https://flashbak.com/play-the-nimatron-the-worlds-first-video-game-invented-in-1930s-new-york-462185/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36856755">https://news.ycombinator.com/item?id=36856755</a></p>
<p>Points: 8</p>
<p># Comments: 6</p>

## Researchers find evidence of a 2000 year old curry, oldest ever found in SE Asia
 - [https://phys.org/news/2023-07-evidence-year-old-curry-oldest-southeast.html](https://phys.org/news/2023-07-evidence-year-old-curry-oldest-southeast.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T01:17:16+00:00

<p>Article URL: <a href="https://phys.org/news/2023-07-evidence-year-old-curry-oldest-southeast.html">https://phys.org/news/2023-07-evidence-year-old-curry-oldest-southeast.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36856564">https://news.ycombinator.com/item?id=36856564</a></p>
<p>Points: 15</p>
<p># Comments: 2</p>

## Story of the SS Warimoo
 - [http://www.mastermariners.org.au/stories-from-the-past/2304-strange-story-of-the-ss-warimoo](http://www.mastermariners.org.au/stories-from-the-past/2304-strange-story-of-the-ss-warimoo)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T01:16:14+00:00

<p>Article URL: <a href="http://www.mastermariners.org.au/stories-from-the-past/2304-strange-story-of-the-ss-warimoo">http://www.mastermariners.org.au/stories-from-the-past/2304-strange-story-of-the-ss-warimoo</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36856555">https://news.ycombinator.com/item?id=36856555</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Twitter’s Rebrand to X Could Be a Trademark Nightmare Thanks to Microsoft
 - [https://themessenger.com/tech/twitters-rebrand-to-x-could-be-a-trademark-nightmare-thanks-to-microsoft](https://themessenger.com/tech/twitters-rebrand-to-x-could-be-a-trademark-nightmare-thanks-to-microsoft)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T01:01:56+00:00

<p>Article URL: <a href="https://themessenger.com/tech/twitters-rebrand-to-x-could-be-a-trademark-nightmare-thanks-to-microsoft">https://themessenger.com/tech/twitters-rebrand-to-x-could-be-a-trademark-nightmare-thanks-to-microsoft</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36856433">https://news.ycombinator.com/item?id=36856433</a></p>
<p>Points: 43</p>
<p># Comments: 18</p>

## The Mad Magazine Fold-In Effect in CSS – Thomas Park
 - [https://thomaspark.co/2020/06/the-mad-magazine-fold-in-effect-in-css/](https://thomaspark.co/2020/06/the-mad-magazine-fold-in-effect-in-css/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T01:01:39+00:00

<p>Article URL: <a href="https://thomaspark.co/2020/06/the-mad-magazine-fold-in-effect-in-css/">https://thomaspark.co/2020/06/the-mad-magazine-fold-in-effect-in-css/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36856428">https://news.ycombinator.com/item?id=36856428</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Per capita CO₂ emissions Over Time
 - [https://ourworldindata.org/grapher/co-emissions-per-capita](https://ourworldindata.org/grapher/co-emissions-per-capita)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T01:00:03+00:00

<p>Article URL: <a href="https://ourworldindata.org/grapher/co-emissions-per-capita">https://ourworldindata.org/grapher/co-emissions-per-capita</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36856416">https://news.ycombinator.com/item?id=36856416</a></p>
<p>Points: 6</p>
<p># Comments: 4</p>

## Record Linkage and the Universal Identifier (1972)
 - [https://dl.acm.org/doi/10.1145/958609.958610](https://dl.acm.org/doi/10.1145/958609.958610)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-07-25T00:26:47+00:00

<p>Article URL: <a href="https://dl.acm.org/doi/10.1145/958609.958610">https://dl.acm.org/doi/10.1145/958609.958610</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36856121">https://news.ycombinator.com/item?id=36856121</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

