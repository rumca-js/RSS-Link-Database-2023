# Source:Austin Evans, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg, language:en-US

## I bought Japanese MYSTERY TECH
 - [https://www.youtube.com/watch?v=1vJoXQP9sS0](https://www.youtube.com/watch?v=1vJoXQP9sS0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg
 - date published: 2023-07-25T15:01:48+00:00

https://youtu.be/WtQs7R3hbsg on @thisis 
https://youtu.be/5Gk99B_M6r8 on @DNKI 

Subscribe for more! https://www.youtube.com/austinevans
TikTok: https://www.tiktok.com/@austintechtips
Instagram: https://instagram.com/austinnotduncan
Twitter: https://twitter.com/austinnotduncan
Threads: https://www.threads.net/@austinnotduncan

Chapter Titles:
0:00 What's Sendico?
0:34 Ordering Japanese Tech
1:54 Tech Has Arrived!
3:08 Casio Loopy
4:02 Loopy Part 2
5:54 Pokemon Cards (obviously)
7:17 Nintendo DS Lite
9:12 Sega Game Gear
11:05 Game Boy Light
13:33 How Did This Get Here?
14:00 WonderSwan Color
15:50 Sony PSX

