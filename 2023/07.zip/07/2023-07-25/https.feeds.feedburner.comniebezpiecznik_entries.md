# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik/, language:pl-PL

## Dziury w policyjnych radiotelefonach TETRA
 - [https://niebezpiecznik.pl/post/dziury-w-policyjnych-radiotelefonach-tetra/](https://niebezpiecznik.pl/post/dziury-w-policyjnych-radiotelefonach-tetra/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2023-07-25T09:30:04+00:00

<a href="https://niebezpiecznik.pl/post/dziury-w-policyjnych-radiotelefonach-tetra/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2023/07/tetra-hacked-150x150.jpg" width="100" /></a>TETRA to standard komunikacji, z którego korzystają służby i wojsko wielu krajów. W Polsce z TETRY korzysta m.in. policja. TETRA oferuje szyfrowanie transmisji, ale w jednym z algorytmów właśnie znaleziono błędy, które pozwalają na rozszyfrowanie komunikacji. Co jednak ciekawsze, badacze twierdzą, że rodzaj znalezionego przez nich błędu jasno wskazuje na to, że to celowy backdoor. [&#8230;]

## * Państwowy rejestr PESEL przeciwko wyłudzeniom kredytów i SIM swaps &#8211; ustawa opublikowana
 - [https://niebezpiecznik.pl/post/panstwowy-rejestr-pesel-przeciwko-wyludzeniom-kredytow-i-sim-swaps-ustawa-opublikowana/](https://niebezpiecznik.pl/post/panstwowy-rejestr-pesel-przeciwko-wyludzeniom-kredytow-i-sim-swaps-ustawa-opublikowana/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2023-07-25T07:55:53+00:00

Polacy będą mogli zastrzec numer PESEL w specjalnym państwowym rejestrze, chroniąc się przed ewentualnymi wyłudzeniami kredytów albo nawet wydawaniem duplikatów kart SIM. Ustawa, która wprowadza takie rozwiązania, została opublikowana w Dzienniku Ustaw. Pod koniec ubiegłego roku pisaliśmy na temat Ustawy o zmianie niektórych ustaw w związku z zapobieganiem kradzieży tożsamości. Prace nad dokumentem były wówczas [&#8230;]

