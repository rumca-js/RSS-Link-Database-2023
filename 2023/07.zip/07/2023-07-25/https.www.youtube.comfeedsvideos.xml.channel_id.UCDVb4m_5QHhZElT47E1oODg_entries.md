# Source:The Dave Cullen Show, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg, language:en-US

## The Nadir of Star Trek
 - [https://www.youtube.com/watch?v=vFpybTYervU](https://www.youtube.com/watch?v=vFpybTYervU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg
 - date published: 2023-07-25T09:31:13+00:00

Support my work on Subscribe Star: https://www.subscribestar.com/dave-cullen
Follow me on Bitchute: https://www.bitchute.com/channel/hybM74uIHJKg/

KEEP UP ON SOCIAL MEDIA:
Gab: https://gab.ai/DaveCullen
Subscribe on Gab TV: https://tv.gab.com/channel/DaveCullen
Minds.com: https://www.minds.com/davecullen
Subscribe on Odysee: https://odysee.com/@TheDaveCullenShow:7

