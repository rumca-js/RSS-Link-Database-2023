# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Pandemic deaths in Ohio and Florida show partisan divide after vaccine rollout
 - [https://arstechnica.com/?p=1956547](https://arstechnica.com/?p=1956547)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T20:48:44+00:00

The death gap between Democrats and Republicans was larger in counties with lower vaccination rates.

## How developers will test their apps before Vision Pro launches
 - [https://arstechnica.com/?p=1956470](https://arstechnica.com/?p=1956470)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T20:36:25+00:00

Apple opened up access to three ways to test apps on real hardware.

## FCC chair: Speed standard of 25Mbps down, 3Mbps up isn’t good enough anymore
 - [https://arstechnica.com/?p=1956502](https://arstechnica.com/?p=1956502)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T20:18:09+00:00

Chair proposes 100Mbps national standard and an evaluation of broadband prices.

## Mass extinction event 260 million years ago resulted from climate change, studies say
 - [https://arstechnica.com/?p=1956409](https://arstechnica.com/?p=1956409)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T18:00:00+00:00

Ocean stagnation, ecosystem collapses, and volcano eruptions all played a role.

## Musk plans Supreme Court appeal after losing bid to terminate SEC settlement
 - [https://arstechnica.com/?p=1956438](https://arstechnica.com/?p=1956438)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T17:40:59+00:00

Supreme Court is Musk's last option as judges uphold limits on his Tesla tweets.

## Android 4.4 KitKat is truly dead, loses Play Services support
 - [https://arstechnica.com/?p=1956401](https://arstechnica.com/?p=1956401)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T16:46:55+00:00

With Play Services gone, it's only a matter of time before you can't log in.

## Encryption-breaking, password-leaking bug in many AMD CPUs could take months to fix
 - [https://arstechnica.com/?p=1956383](https://arstechnica.com/?p=1956383)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T16:31:57+00:00

"Zenbleed" bug affects all Zen 2-based Ryzen, Threadripper, and EPYC CPUs.

## Climatologists: July’s intense heat “exactly what we expected to see”
 - [https://arstechnica.com/?p=1956411](https://arstechnica.com/?p=1956411)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T16:18:04+00:00

Deadly temperatures will become common unless greenhouse gas emissions are cut fast.

## GM announces a new Ultium-based Chevrolet Bolt during Q2 report
 - [https://arstechnica.com/?p=1956353](https://arstechnica.com/?p=1956353)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T13:36:14+00:00

The much-loved affordable EV looked finished, but Chevy will build Bolt 2.0.

## Researchers find deliberate backdoor in police radio encryption algorithm
 - [https://arstechnica.com/?p=1956349](https://arstechnica.com/?p=1956349)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T13:05:32+00:00

Vendors knew all about it, but most customers were clueless.

## Catching up with Foundation S2 as the Second Crisis unfolds
 - [https://arstechnica.com/?p=1953801](https://arstechnica.com/?p=1953801)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-07-25T12:52:53+00:00

The second season has faster pacing, more linear storytelling, and bits of levity.

