# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Senat zmienił ustawę o 800 plus. Chce szybszej podwyżki
 - [https://businessinsider.com.pl/gospodarka/senat-zmienil-ustawe-o-800-plus-chca-szybszej-podwyzki/0kgrfd8](https://businessinsider.com.pl/gospodarka/senat-zmienil-ustawe-o-800-plus-chca-szybszej-podwyzki/0kgrfd8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T19:19:22+00:00

Senacka Komisja Budżetu i Finansów Publicznych zaproponowała we wtorek, aby świadczenie 500 plus zostało zwiększone o 300 zł z mocą od czerwca 2023 r. Odpowiednią poprawkę zgłoszono do nowelizacji ustawy budżetowej. Żeby jednak tak się stało, poprawka w ostatecznym rozrachunku nie może zostać odrzucona przez Sejm.

## Premier Czech: Polska wywiązuje się z umowy w sprawie Turowa
 - [https://businessinsider.com.pl/gospodarka/premier-czech-polska-wywiazuje-sie-z-umowy-w-sprawie-turowa/mynx3we](https://businessinsider.com.pl/gospodarka/premier-czech-polska-wywiazuje-sie-z-umowy-w-sprawie-turowa/mynx3we)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T18:49:01+00:00

Polska wywiązuje się z umowy w sprawie kopalni Turów — powiedział we wtorek agencji CTK premier Czech Petr Fiala. Zareagował tak na informację Czeskiej Służby Geologicznej (CGS), że mimo postawionej podziemnej ściany, wody gruntowe wciąż wypływają z Czech do polskiej kopalni.

## Polska kupi szwedzkie samoloty wczesnego ostrzegania. Jest umowa
 - [https://businessinsider.com.pl/gospodarka/polska-kupi-szwedzkie-samoloty-wczesnego-ostrzegania-jest-umowa/yhx53ev](https://businessinsider.com.pl/gospodarka/polska-kupi-szwedzkie-samoloty-wczesnego-ostrzegania-jest-umowa/yhx53ev)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T17:13:46+00:00

Agencja Uzbrojenia podpisała we wtorek umowę na dostawę szwedzkich samolotów wczesnego ostrzegania Saab 340 AEW; polska przestrzeń powietrzna staje się dzięki temu bezpieczniejsza - przekazał minister obrony narodowej Mariusz Błaszczak.

## Chorwacja. Pożar w okolicach Dubrownika
 - [https://businessinsider.com.pl/wiadomosci/chorwacja-pozar-w-okolicach-dubrownika/p3kb3y5](https://businessinsider.com.pl/wiadomosci/chorwacja-pozar-w-okolicach-dubrownika/p3kb3y5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T17:08:48+00:00

W nocy z poniedziałku na wtorek wybuchł pożar, który zbliżał się do położonego na południu kraju Dubrownika, lecz sytuację udało się opanować — poinformował portal thedubrovniktimes.com. Natomiast w kilku regionach Chorwacji ogłoszono czerwony alert pogodowy z powodu nadchodzących burz.

## Upały zagrażają europejskiej branży turystycznej. Na szali 2 bln dol.
 - [https://businessinsider.com.pl/gospodarka/upaly-zmienia-turystyke-londyn-jak-barcelona-sztokholm-jak-budapeszt/mzyg0gr](https://businessinsider.com.pl/gospodarka/upaly-zmienia-turystyke-londyn-jak-barcelona-sztokholm-jak-budapeszt/mzyg0gr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T16:56:52+00:00

Ekstremalne upały zagrażają europejskiej branży turystycznej o wartości 2 bln dol. Greckie pożary wymusiły ewakuację tysięcy wczasowiczów. To przypomnienie, że europejska branża turystyczna musi stawić czoła realiom zmian klimatycznych i szybko się przystosować — pisze Bloomberg. "Wciąż jest całkiem spora część branży, która dosłownie dopiero się budzi" — ocenia ekspert.

## Pożary na Rodos. Polska linia lotnicza wydała oświadczenie
 - [https://businessinsider.com.pl/wiadomosci/pozary-na-rodos-czarterowa-linia-wydala-oswiadczenie/8xvxspj](https://businessinsider.com.pl/wiadomosci/pozary-na-rodos-czarterowa-linia-wydala-oswiadczenie/8xvxspj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T16:54:46+00:00

Linia Enter Air zapewnia, że stara się "jak najszybciej" sprowadzić do Polski turystów, którzy utknęli na nękanej pożarami greckiej wyspie Rodos. W opublikowanym we wtorek oświadczeniu zarząd linii poinformował, że po Polaków poleci samolot z Bazylei.

## 2023 prawdopodobnie będzie najgorętszym rokiem w historii
 - [https://businessinsider.com.pl/wiadomosci/na-sardynii-upal-zabija-telefony-2023-bedzie-najgoretszy-w-historii/hm7jl21](https://businessinsider.com.pl/wiadomosci/na-sardynii-upal-zabija-telefony-2023-bedzie-najgoretszy-w-historii/hm7jl21)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T16:17:10+00:00

Po najcieplejszym czerwcu od czasu rozpoczęcia pomiarów w 1850 r. nowa analiza wykazała, że ​​obecnie istnieje ponad 80 proc. szans, że ten rok będzie najcieplejszy w historii. Na włoskiej Sardynii temperatura, która zbliża się do europejskiego rekordu, "zabija" iPhony — pisze Bloomberg.

## Przerwałeś urlop na greckich wyspach? Takie prawa ci przysługują
 - [https://businessinsider.com.pl/prawo/nie-daj-sie-oszukac-jak-odzyskac-pieniadze-za-przerwane-wakacje-w-grecji/bp0np3b](https://businessinsider.com.pl/prawo/nie-daj-sie-oszukac-jak-odzyskac-pieniadze-za-przerwane-wakacje-w-grecji/bp0np3b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T16:15:57+00:00

Od tygodnia w części Grecji i na wyspach na Morzu Egejskim obowiązuje najwyższy, czwarty stopień zagrożenia pożarowego. Trwa też ewakuacja turystów. W poniedziałek przed północą na lotnisku Chopina w Warszawie wylądował samolot z pasażerami z greckiej wyspy Rodos. Wśród nich byli turyści, którzy z wyspy uciekli przed pożarem. Jakie mają prawa? Podpowiadamy możliwości, jakie polskie i unijne prawo daje klientom biur podróży.

## Pierwszy magazyn baterii litowo-jonowych. Z Polski robi się znaczący gracz
 - [https://businessinsider.com.pl/technologie/nowe-technologie/pierwszy-w-polsce-magazyn-baterii-litowo-jonowych-nawet-szwecja-takiego-nie-ma/j96kf4m](https://businessinsider.com.pl/technologie/nowe-technologie/pierwszy-w-polsce-magazyn-baterii-litowo-jonowych-nawet-szwecja-takiego-nie-ma/j96kf4m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T16:14:59+00:00

To kluczowe zagadnienie w rozwoju energetyki wiatrowej i fotowoltaiki. Bez magazynowania energii miliardy wydane na nowe moce tracą momentami sens. Rozwiązaniem jest magazynowanie energii, a magazynem mogą być choćby baterie litowo-jonowe, czyli źródło zasilania najpopularniejszych obecnie samochodów elektrycznych. Powstał pierwszy w Polsce magazyn takich baterii. Oznacza to, że na polskim rynku osiągnęliśmy pewien kamień milowy.

## To już demograficzna depresja. Dane są dramatyczne
 - [https://businessinsider.com.pl/gospodarka/to-juz-demograficzna-depresja-dane-sa-dramatyczne/gg6gn8p](https://businessinsider.com.pl/gospodarka/to-juz-demograficzna-depresja-dane-sa-dramatyczne/gg6gn8p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T15:57:45+00:00

Zaledwie 23,1 tys. dzieci urodziło się w czerwcu na terenie Polski. To o ponad 4 tys. mniej niż rok temu o tej samej porze. Demograficzne nożyce rozwierają się coraz mocniej, a sytuacja dawno nie była aż tak krytyczna. Tylko w ciągu ostatniego roku Polska zmniejszyła się o ponad 130 tys. osób, czyli tyle, ile na co dzień mieszka w Opolu, Rudzie Śląskiej czy Rybniku.

## Barbie. Na marketing wydano więcej niż na sam film. Opłacało się
 - [https://businessinsider.com.pl/media/marketing/rozowy-burger-dom-marzen-barbie-w-malibu-na-marketing-filmu-wydano-krocie/ywr38yz](https://businessinsider.com.pl/media/marketing/rozowy-burger-dom-marzen-barbie-w-malibu-na-marketing-filmu-wydano-krocie/ywr38yz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T14:59:13+00:00

Na marketing "Barbie" wydano 150 mln dol. To więcej niż budżet całego filmu. W ramach akcji promocyjnej powstały m.in. naturalnej wielkości replika domu marzeń Barbie w Malibu czy różowy burger.

## Gwiazda "Barbie" spłaciła mamie hipotekę za pieniądze z aktorstwa
 - [https://businessinsider.com.pl/biznes/gwiazda-barbie-splacila-mamie-hipoteke-za-pieniadze-z-aktorstwa/mny9yzb](https://businessinsider.com.pl/biznes/gwiazda-barbie-splacila-mamie-hipoteke-za-pieniadze-z-aktorstwa/mny9yzb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T14:33:05+00:00

Margot Robbie, tytułowa "Barbie" z najnowszego kinowego hitu, wykorzystała swoje zarobki w Hollywood, aby spłacić kredyt hipoteczny swojej matki. W ten sposób chciała odwdzięczyć się za to, jak jej mama wspierała gwiazdę finansowo na początku jej kariery aktorskiej. — Miałam zapisanego każdego dolara, którego pożyczyła mi mama — stwierdziła aktorka.

## Najbardziej znana elektrociepłownia w Polsce ma nowego prezesa
 - [https://businessinsider.com.pl/biznes/ec-bedzin-ma-nowego-prezesa-to-marcin-chodkowski/xqf62x9](https://businessinsider.com.pl/biznes/ec-bedzin-ma-nowego-prezesa-to-marcin-chodkowski/xqf62x9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T14:16:14+00:00

Rada nadzorcza Elektrociepłowni Będzin powołała na funkcje prezesa zarządu Marcina Chodkowskiego, dotychczasowego wiceprezesa ds. korporacyjnych — poinformowano w komunikacie. Chodkowski jest związany ze spółką od stycznia 2023 r.

## Zakaz importu ukraińskiego zboża. Niemcy i Francja przeciwne decyzji Polski
 - [https://businessinsider.com.pl/gospodarka/zboze-niemcy-o-decyzji-polski-problemy-wyborcze-na-barkach-ukrainy/9lpcbfs](https://businessinsider.com.pl/gospodarka/zboze-niemcy-o-decyzji-polski-problemy-wyborcze-na-barkach-ukrainy/9lpcbfs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T14:08:08+00:00

Francja i Niemcy sprzeciwiają się przedłużeniu zakazu eksportu ukraińskiej pszenicy, kukurydzy, rzepaku i słonecznika do pięciu krajów, w tym Polski, po 15 września. Polska, Węgry, Słowacja, Bułgaria, Rumunia chcą przedłużenia. "Niedopuszczalne jest, aby niektóre państwa członkowskie uchylały obowiązujące traktaty" – powiedział we wtorek niemiecki minister rolnictwa Cem Oezdemir.

## Rząd chce regulować ceny żywności. Szykuje "ustawę hiszpańską"
 - [https://businessinsider.com.pl/gospodarka/rzad-chce-regulowac-ceny-zywnosci-szykuje-ustawe-hiszpanska/33hsvj5](https://businessinsider.com.pl/gospodarka/rzad-chce-regulowac-ceny-zywnosci-szykuje-ustawe-hiszpanska/33hsvj5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T13:51:41+00:00

Ministerstwo Rolnictwa i Rozwoju Wsi opracowuje projekt ustawy, dzięki której rolnik nie musiałby sprzedawać swoich towarów poniżej kosztów wytworzenia - poinformował na antenie TVP 1 minister rolnictwa Robert Telus.

## Antybiotyki, akumulatory, samochody, drut kolczasty. Boom na polskie produkty
 - [https://businessinsider.com.pl/gospodarka/antybiotyki-akumulatory-samochody-drut-kolczasty-produkcja-wielu-wyrobow-wystrzelila/1dw0x8b](https://businessinsider.com.pl/gospodarka/antybiotyki-akumulatory-samochody-drut-kolczasty-produkcja-wielu-wyrobow-wystrzelila/1dw0x8b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T13:44:03+00:00

Przemysł narzeka na brak zamówień, szczególnie zagranicznych, produkcja się ogólnie rzecz biorąc kurczy, ale są produkty z polskich fabryk, które sprzedają się rewelacyjnie. Antybiotyki, akumulatory, samochody i drut kolczasty to jedne z wielu przykładów. Zarazem załamanie przeżywa górnictwo. Węgla potrzeba coraz mniej w miarę wzrostu produkcji energii ze źródeł odnawialnych.

## Antybiotyki, akumulatory, samochody, drut kolczasty. Boom na produkty made in Poland
 - [https://businessinsider.com.pl/gospodarka/antybiotyki-akumulatory-drut-kolczasty-boom-na-produkty-made-in-poland/1dw0x8b](https://businessinsider.com.pl/gospodarka/antybiotyki-akumulatory-drut-kolczasty-boom-na-produkty-made-in-poland/1dw0x8b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T13:44:03+00:00

Przemysł narzeka na brak zamówień, szczególnie zagranicznych, produkcja się ogólnie rzecz biorąc kurczy, ale są produkty z polskich fabryk, które sprzedają się rewelacyjnie. Antybiotyki, akumulatory, samochody i drut kolczasty to jedne z wielu przykładów. Zarazem załamanie przeżywa górnictwo. Węgla potrzeba coraz mniej w miarę wzrostu produkcji energii ze źródeł odnawialnych.

## Rząd chce wysłać samoloty do ewakuacji turystów z Grecji
 - [https://businessinsider.com.pl/wiadomosci/rzad-chce-wyslac-samoloty-do-ewakuacji-turystow-z-grecji/6t29qme](https://businessinsider.com.pl/wiadomosci/rzad-chce-wyslac-samoloty-do-ewakuacji-turystow-z-grecji/6t29qme)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T13:12:27+00:00

Na dziś biura nie zgłosiły potrzeby interwencji Ministerstwa Sportu i Turystyki w proces organizacji powrotu polskich turystów do kraju. "Jeżeli taka potrzeba nastąpi, jesteśmy gotowi użyć do tego procesu samolotów pozostających w dyspozycji rządu RP" — napisał we wtorek na Twitterze minister sportu i turystyki Kamil Bortniczuk.

## Papierosy niszczą polską gospodarkę. Padła kwota, która oszałamia
 - [https://businessinsider.com.pl/gospodarka/papierosy-niszcza-polska-gospodarke-padly-szacunkowe-koszty/4pey8qz](https://businessinsider.com.pl/gospodarka/papierosy-niszcza-polska-gospodarke-padly-szacunkowe-koszty/4pey8qz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T12:43:53+00:00

Koszt palenia papierosów dla polskiej gospodarki można szacować łącznie na ok. 92 mld zł w 2021 r., z czego 50 mld zł to bezpośrednie koszty leczenia — ocenia prezes Polskiego Towarzystwa Zdrowia Publicznego Andrzej M. Fal w ekspertyzie opublikowanej przez Biuro Analiz Sejmowych. 92 mld zł to dwukrotnie więcej niż kosztuje program Rodzina 500 plus.

## Elon Musk buduje dom we Włoszech. 15 łazienek i podwieszany szklany basen
 - [https://businessinsider.com.pl/lifestyle/elon-musk-buduje-wymarzony-dom-we-wloszech-projekt-przysnil-mi-sie-w-nocy/trzeppy](https://businessinsider.com.pl/lifestyle/elon-musk-buduje-wymarzony-dom-we-wloszech-projekt-przysnil-mi-sie-w-nocy/trzeppy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T12:40:40+00:00

Elon Musk, jeden z najbogatszych ludzi na świecie, kilka lat temu przyjechał na narty w Dolomity. Tak bardzo mu się spodobało, że postanowił zbudować tam dom. Będzie w nim m.in. komora kriogeniczna i podwieszany szklany basen.

## 13 sygnałów, które mogą świadczyć o tym, że twój kolega z pracy jest psychopatą
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/jak-rozpoznac-psychopate-w-pracy-jakie-sa-cechy-psychopaty/s79lzc7](https://businessinsider.com.pl/rozwoj-osobisty/kariera/jak-rozpoznac-psychopate-w-pracy-jakie-sa-cechy-psychopaty/s79lzc7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T12:30:00+00:00

"Każdy pracownik, który zostaje zatrudniony lub awansowany na stanowisko managera i ma zarządzać zespołem, powinien przejść test psychologiczny" – twierdzi Andrew Faas, manager, który przez wiele lat pracował w największych korporacjach kanadyjskich. W przeszłości zwrócił uwagę szefostwa na korupcję, której dopuścił się jeden z jego pracowników. Zaraz potem na jego telefon i skrzynkę mailową włamał się haker i ktoś zaczął grozić mu śmiercią. Okazało się, że miał do czynienia z psychopatą. To trudne doświadczenie zmotywowało go do tego, by napisać książkę ("The Bully's Trap"), w której opowiada swoją historię i zwraca uwagę na temat tabu – stanu psychicznego współpracowników.

## Naukowcy sprawdzili, jak często trzeba ćwiczyć, brać kąpiel i kiedy pić kawę. Oto wyniki ich badań
 - [https://businessinsider.com.pl/lifestyle/myjesz-sie-rano-to-blad-zbyt-czeste-kapanie-zle-wplywa-na-skore/nv0vtwp](https://businessinsider.com.pl/lifestyle/myjesz-sie-rano-to-blad-zbyt-czeste-kapanie-zle-wplywa-na-skore/nv0vtwp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T12:00:00+00:00

Zastanawiasz się, czy lepiej ćwiczyć rano, czy wieczorem? Czy te multiwitaminy, które łykasz codziennie, działają? A może nie wiesz, kiedy ćwiczenia, które wykonujesz, zaczną przynosić efekty? Okazuje się, że naukowcy również szukają odpowiedzi na te pytania. Możesz sięgnąć po naukę przy podejmowaniu codziennych decyzji o tym, co jeść rano i jak często zmieniać pościel.

## Kluczowe zmiany w nieruchomościach. Jest podpis prezydenta
 - [https://businessinsider.com.pl/wiadomosci/kluczowe-zmiany-dla-rynku-nieruchomosci-jest-podpis-prezydenta/ecbnsl3](https://businessinsider.com.pl/wiadomosci/kluczowe-zmiany-dla-rynku-nieruchomosci-jest-podpis-prezydenta/ecbnsl3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T11:57:14+00:00

Prezydent Andrzej Duda podpisał ustawę ws. likwidacji użytkowania wieczystego, która umożliwi firmom, osobom fizycznym i spółdzielniom mieszkaniowym wykup gruntów. Regulacja przewiduje też, że nabycie pierwszego mieszkania będzie zwolnione z PCC — podała we wtorek Kancelaria Prezydenta RP.

## Tysiące uciekły z Rosji po inwazji na Ukrainę. Rosną gospodarki, które ich przyjęły
 - [https://businessinsider.com.pl/gospodarka/tysiace-uciekly-z-rosji-rosna-gospodarki-panstw-ktore-ich-przyjely/yy3yk49](https://businessinsider.com.pl/gospodarka/tysiace-uciekly-z-rosji-rosna-gospodarki-panstw-ktore-ich-przyjely/yy3yk49)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T11:56:34+00:00

Setki tysięcy Rosjan, którzy uciekli ze swojej ojczyzny po inwazji na Ukrainę, przesiedliło się do sąsiednich krajów i napędzają teraz tamtejsze gospodarki.

## Tajemnicza roszada na szczycie chińskiego aparatu władzy
 - [https://businessinsider.com.pl/wiadomosci/tajemnicza-roszada-na-szczycie-chinskiego-aparatu-wladzy/edx7nb3](https://businessinsider.com.pl/wiadomosci/tajemnicza-roszada-na-szczycie-chinskiego-aparatu-wladzy/edx7nb3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T11:52:18+00:00

Chiny ogłosiły zmianę ministra spraw zagranicznych Qin Ganga, miesiąc po tym, jak były ulubieniec prezydenta Xi Jinpinga przestał pokazywać się publicznie.

## Tajemnicza roszada na szczycie chińskiego aparatu władzy
 - [https://businessinsider.com.pl/wiadomosci/tajemnicza-zmiana-w-chinskim-rzadzie-ulubieniec-xi-jinpinga-zniknal/edx7nb3](https://businessinsider.com.pl/wiadomosci/tajemnicza-zmiana-w-chinskim-rzadzie-ulubieniec-xi-jinpinga-zniknal/edx7nb3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T11:52:18+00:00

Chiny ogłosiły zmianę ministra spraw zagranicznych Qin Ganga, miesiąc po tym, jak były ulubieniec prezydenta Xi Jinpinga przestał pokazywać się publicznie — podaje "Financial Times".

## Roszada na ważnym stanowisku dla światowej gospodarki. Nowy szef chińskiego banku centralnego
 - [https://businessinsider.com.pl/gospodarka/pan-gongsheng-nowym-szefem-chinskiego-banku-centralnego/mp67yep](https://businessinsider.com.pl/gospodarka/pan-gongsheng-nowym-szefem-chinskiego-banku-centralnego/mp67yep)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T11:42:22+00:00

Pan Gongsheng został nowym szefem chińskiego banku centralnego, stając się de facto najważniejszym urzędnikiem w drugiej gospodarce świata. Zastąpił na tym stanowisku Yi Ganga, który osiągnął wiek emerytalny.

## UE przyjmuje przełomowe prawo. Ma odrodzić kluczowy przemysł
 - [https://businessinsider.com.pl/gospodarka/ue-przyjmuje-przelomowe-prawo-uniezalezni-europe-od-kluczowej-technologii/qflxe1t](https://businessinsider.com.pl/gospodarka/ue-przyjmuje-przelomowe-prawo-uniezalezni-europe-od-kluczowej-technologii/qflxe1t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T11:29:58+00:00

Unia Europejska zatwierdziła we wtorek rozporządzenie wzmacniające europejski ekosystem półprzewodników, znane jako "akt w sprawie czipów". Dzięki temu już wkrótce Europa ma stać się niezależna od tych niezbędnych komponentów.

## Bezpośrednie porównanie tańszych i droższych wideorejestratorów
 - [https://businessinsider.com.pl/technologie/bezposrednie-porownanie-tanszych-i-drozszych-wideorejestratorow/zf83rbp](https://businessinsider.com.pl/technologie/bezposrednie-porownanie-tanszych-i-drozszych-wideorejestratorow/zf83rbp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T11:13:15+00:00

Wybraliśmy po dwa wideorejestratory tej samej marki. Po jednym z niższej półki i po jednym z wyższej półki cenowej. Jeśli zastanawiasz się, czy warto dopłacać kilkaset złotych do droższej kamery samochodowej, koniecznie sprawdź bezpośrednie porównanie.

## Kto wygrywa wojnę w Ukrainie? Eksperci analizują położenie Putina i Zełenskiego
 - [https://businessinsider.com.pl/wiadomosci/kto-wygrywa-wojne-w-ukrainie-eksperci-analizuja-polozenie-putina-i-zelenskiego/tgej8z0](https://businessinsider.com.pl/wiadomosci/kto-wygrywa-wojne-w-ukrainie-eksperci-analizuja-polozenie-putina-i-zelenskiego/tgej8z0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:53:17+00:00

Codziennie docierają do nas kolejne informacje z ukraińskiego frontu o postępach i problemach jednej i drugiej strony. Z tych strzępków wojennego przekazu trudno ocenić, kto ma w tej chwili przewagę. Eksperci wyjaśniają, kto i w jakim zakresie jest bliżej zwycięstwa.

## Chciał zostać aktorem, studiował filozofię i pedagogikę, a został Agile Coachem. Poznaj historię Marka
 - [https://businessinsider.com.pl/praca/chcial-zostac-aktorem-studiowal-filozofie-i-pedagogike-a-zostal-agile-coachem-poznaj/metkxgq](https://businessinsider.com.pl/praca/chcial-zostac-aktorem-studiowal-filozofie-i-pedagogike-a-zostal-agile-coachem-poznaj/metkxgq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:50:37+00:00

Marek Pakoński przetarł w swoim zawodowym życiu wiele humanistycznych szlaków. Skończył filozofię, pedagogikę, pracował jako asystent seksuologa, radiowiec, animator kultury. Jak to się stało, że został Agile Team Coachem w Ringier Axel Springer Tech?

## Rosja przygotowywała to od dawna. Wywiad Ukrainy ujawnia kulisy zerwania umowy zbożowej
 - [https://businessinsider.com.pl/gospodarka/rosja-przygotowywala-to-od-dawna-wywiad-ukrainy-ujawnia-kulisy-umowy-zbozowej/xsef5r7](https://businessinsider.com.pl/gospodarka/rosja-przygotowywala-to-od-dawna-wywiad-ukrainy-ujawnia-kulisy-umowy-zbozowej/xsef5r7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:39:18+00:00

Zdobyty przez ukraiński wywiad niejawny rosyjski raport świadczy o tym, że wszystkie działania w ramach zerwania umowy zbożowej to elementy wcześniej przygotowanego planu, a niszczenie infrastruktury ukraińskiej to jego kolejna część – poinformował ukraiński wywiad wojskowy HUR.

## 10 rzeczy, których inteligentni ludzie starają się nie mówić w pracy
 - [https://businessinsider.com.pl/rozwoj-osobisty/negatywne-slowa-ktore-psuja-odbior-wypowiedzi/f5p2jqe](https://businessinsider.com.pl/rozwoj-osobisty/negatywne-slowa-ktore-psuja-odbior-wypowiedzi/f5p2jqe)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:39:00+00:00

Słowa mają ogromne znaczenie. Inteligentni ludzie zdają sobie z tego sprawę i przykładają wagę do zawartości swojego słownika. Pewne rzeczy wykreślają z niego na stałe, innych nigdy nie stosują w pracy.

## Nie tylko Grecja. Europa walczy z pożarami
 - [https://businessinsider.com.pl/wiadomosci/nie-tylko-rodos-kilkadziesiat-pozarow-na-kolejnej-wyspie/k2gzc62](https://businessinsider.com.pl/wiadomosci/nie-tylko-rodos-kilkadziesiat-pozarow-na-kolejnej-wyspie/k2gzc62)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:32:41+00:00

Europa walczy ze skutkami upałów i pożarów. Czerwiec był najgorętszym miesiącem w historii monitorowania temperatury od 174 lat — podaje Reuters. Najgorsza sytuacja wciąż jest na greckiej wyspie Rodos, jednak kilkadziesiąt pożarów wybuchło na Sycylii. Z żywiołem walczy też m.in. Turcja i Chorwacja.

## Premier Grecji: nie ma "magicznej obrony" przed pożarami. Przed nami trudne lato
 - [https://businessinsider.com.pl/wiadomosci/pozary-w-grecji-premier-nie-ma-magicznej-obrony-przed-nami-trudne-lato/fyleq9d](https://businessinsider.com.pl/wiadomosci/pozary-w-grecji-premier-nie-ma-magicznej-obrony-przed-nami-trudne-lato/fyleq9d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:31:53+00:00

"Gdyby istniała »magiczna obrona«, zastosowalibyśmy ją" — powiedział premier Grecji Kyriakos Mitsotakis podczas posiedzenia rządu. — Wszyscy są w pogotowiu" — dodał.

## Witamy w Nowym Średniowieczu. Słynny myśliciel mówi, jak ma wyglądać porządek świata w 2100 r.
 - [https://businessinsider.com.pl/wiadomosci/przepowiednia-slynnego-mysliciela-jak-bedzie-wygladac-przyszlosc-nowe-sredniowiecze/pyjt9t9](https://businessinsider.com.pl/wiadomosci/przepowiednia-slynnego-mysliciela-jak-bedzie-wygladac-przyszlosc-nowe-sredniowiecze/pyjt9t9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:30:00+00:00

Od czasu inwazji Rosji na Ukrainę wydaje się, że zimna wojna wróciła. Ale tak nie jest, mówi globalny myśliciel Parag Khanna, który wiele lat temu przewidział zmiany władzy, które pojawiają się dzisiaj. Teraz po raz kolejny odważył się spojrzeć w przyszłość naszego świata.

## Firmy szykują się do zwolnień. Dwie kluczowe branże mają przerost mocy
 - [https://businessinsider.com.pl/gospodarka/firmy-szykuja-sie-do-zwolnien-dwie-kluczowe-branze-maja-przerost-mocy/4vtm5h8](https://businessinsider.com.pl/gospodarka/firmy-szykuja-sie-do-zwolnien-dwie-kluczowe-branze-maja-przerost-mocy/4vtm5h8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:26:23+00:00

Gdyby nie lockdowny w pierwszej fali pandemii, to mielibyśmy właśnie najgorsze wykorzystanie mocy przerobowych przemysłu od dziewięciu lat. W lipcu pracowało zaledwie 78 proc. mocy, a dwie kluczowe branże zeszły nawet poniżej 74 proc. W jednej z nich działa Orlen.

## Jeszcze chwila i zaczną się zwolnienia. Dwie kluczowe branże mają przerost mocy
 - [https://businessinsider.com.pl/gospodarka/jeszcze-chwila-i-zaczna-sie-zwolnienia-dwie-kluczowe-branze-maja-przerost-mocy/4vtm5h8](https://businessinsider.com.pl/gospodarka/jeszcze-chwila-i-zaczna-sie-zwolnienia-dwie-kluczowe-branze-maja-przerost-mocy/4vtm5h8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:26:23+00:00

Gdyby nie lockdowny w pierwszej fali pandemii, to mielibyśmy właśnie najgorsze wykorzystanie mocy przerobowych przemysłu od dziewięciu lat. W lipcu pracowało zaledwie 78 proc. mocy, a dwie kluczowe branże zeszły nawet poniżej 74 proc. W jednej z nich działa Orlen.

## Bomba ekologiczna w Bałtyku. Niszczy środowisko, opóźni wielki projekt
 - [https://businessinsider.com.pl/gospodarka/bomba-ekologiczna-w-baltyku-niszczy-srodowisko-opozni-wielki-projekt/7pqd22b](https://businessinsider.com.pl/gospodarka/bomba-ekologiczna-w-baltyku-niszczy-srodowisko-opozni-wielki-projekt/7pqd22b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T10:18:01+00:00

Jak podaje "Financial Times", bomby z czasów nazistowskich Niemiec zagrażają budowie morskich farm wiatrowych na Bałtyku. Za sprawą szkodliwych odpadów załamała się też populacja dorsza. "To prawdziwa ekologiczna tykająca bomba zegarowa" — przestrzega jedna z unijnych instytucji.

## Skandaliczne zachowanie biur podróży. Wysyłały turystów do nadpalonych hoteli
 - [https://businessinsider.com.pl/wiadomosci/skandaliczne-zachowanie-biur-podrozy-wysylaly-turystow-do-nadpalonych-hoteli/34jc15y](https://businessinsider.com.pl/wiadomosci/skandaliczne-zachowanie-biur-podrozy-wysylaly-turystow-do-nadpalonych-hoteli/34jc15y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T09:41:46+00:00

Choć pożary na Rodos zagrażają zdrowi i życiu przebywających tam osób, to jeszcze w poniedziałek niektóre brytyjskie biura podróży oferowały wyloty w zagrożoną strefę. Niektóre oferty dotyczyły nawet uszkodzonych przez ogień hoteli.

## Nie płacili kredytu, dom poszedł na licytację. Ziobro znów stanął w obronie frankowiczów
 - [https://businessinsider.com.pl/wiadomosci/pozyczyli-242-tys-zl-maja-oddac-586-ziobro-staje-w-obronie-frankowiczow/tm1qqer](https://businessinsider.com.pl/wiadomosci/pozyczyli-242-tys-zl-maja-oddac-586-ziobro-staje-w-obronie-frankowiczow/tm1qqer)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T09:30:00+00:00

W 2008 roku para zdecydowała się na zaciągnięcie kredytu we frankach szwajcarskich na cele remontowe i spłatę innych długów. Łącznie pożyczyli od banku nieco ponad 242 tys. zł. Po kilku latach zaczęli mieć problemy ze spłatą rat na czas. W rezultacie, w 2016 roku bank rozwiązał umowę i skierował sprawę na drogę sądową.

## Malinowa zmowa istnieje czy nie? UOKiK skontrolował skupy. Oto wyniki
 - [https://businessinsider.com.pl/wiadomosci/malinowa-zmowa-istnieje-czy-nie-uokik-skontrolowal-skupy-oto-wyniki/nyxnccd](https://businessinsider.com.pl/wiadomosci/malinowa-zmowa-istnieje-czy-nie-uokik-skontrolowal-skupy-oto-wyniki/nyxnccd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T09:26:18+00:00

Minister rolnictwa w połowie lipca powiadomił CBA o podejrzeniu zmowy cen na rynku malin. Do kontroli ruszył w międzyczasie UOKiK. I co? Na razie dowodów na zmowę nie ma.

## Młynki do kawy, nad których zakupem nie musisz się zastanawiać
 - [https://businessinsider.com.pl/technologie/mlynki-do-kawy-nad-ktorych-zakupem-nie-musisz-sie-zastanawiac/08cy3q3](https://businessinsider.com.pl/technologie/mlynki-do-kawy-nad-ktorych-zakupem-nie-musisz-sie-zastanawiac/08cy3q3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T09:20:42+00:00

Każdy barista i miłośnik kawy potwierdzi, że młynek jest jednym z najważniejszych elementów procesu przygotowania kawy. Jeśli rzeczywiście zależy ci na jak najlepszy naparze, wybierz możliwie jak najlepszy młynek. Poniżej przedstawiamy pięć urządzeń z wyższej półki, które możesz kupować w ciemno.

## Shopee zostawiło w Polsce majątek. Poznaliśmy kwoty, jakie wydano na marketing
 - [https://businessinsider.com.pl/firmy/shopee-zostawilo-w-polsce-majatek-poznalismy-kwoty-jakie-wydano-na-marketing/dvsr34e](https://businessinsider.com.pl/firmy/shopee-zostawilo-w-polsce-majatek-poznalismy-kwoty-jakie-wydano-na-marketing/dvsr34e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T09:16:25+00:00

Platforma Shopee tak jak z przebojem weszła na polski rynek, tak szybko z niego zniknęła. Polacy dobrze zapamiętali jednak krzykliwe reklamy i wszechobecny marketing firmy, która miała rywalizować nad Wisłą z Allegro czy Amazonem. Ile wydała na ten cel? Poznaliśmy kwoty.

## Spotify i YouTube drożeją jak większość streamingów
 - [https://businessinsider.com.pl/poradnik-finansowy/spotify-i-youtube-drozeja-jak-wiekszosc-streamingow/zc5bl3l](https://businessinsider.com.pl/poradnik-finansowy/spotify-i-youtube-drozeja-jak-wiekszosc-streamingow/zc5bl3l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T09:13:47+00:00

Spotify Premium drożeje na kilkudziesięciu rynkach na świecie. To już kolejna platforma streamingowa, która w ostatnim czasie zdecydowała się na korekty stawek.

## Spotify i YouTube drożeją jak większość streamingów
 - [https://businessinsider.com.pl/poradnik-finansowy/spotify-i-youtube-coraz-drozsze-przejrzyj-swoje-zakupione-streamingi/zc5bl3l](https://businessinsider.com.pl/poradnik-finansowy/spotify-i-youtube-coraz-drozsze-przejrzyj-swoje-zakupione-streamingi/zc5bl3l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T09:13:47+00:00

Spotify Premium drożeje na kilkudziesięciu rynkach na świecie. To już kolejna platforma streamingowa, która w ostatnim czasie zdecydowała się na korekty stawek.

## Bunt rolnika z Lubelszczyzny. Zaczął rozdawać owoce za darmo. "Można rwać bez pytania"
 - [https://businessinsider.com.pl/gospodarka/rolnik-rozdaje-owoce-za-darmo-wszystko-przez-ceny-na-skupie-mozna-rwac/yzb7jmd](https://businessinsider.com.pl/gospodarka/rolnik-rozdaje-owoce-za-darmo-wszystko-przez-ceny-na-skupie-mozna-rwac/yzb7jmd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T08:57:10+00:00

Piotr Belcarz, rolnik z województwa lubelskiego, jest rozczarowany cenami, które za zbiory proponuje mu skup owoców. W związku z tym postanowił za darmo rozdać to, co urosło na jego polu. Wpis mężczyzny jest szeroko komentowany w mediach.

## Ukraina będzie miała kłopoty, jeśli kobiety nie wrócą po wojnie. Analityk nie ma wątpliwości
 - [https://businessinsider.com.pl/gospodarka/ukrainki-sa-niezbedne-przy-odbudowie-kraju-analityk-nie-ma-watpliwosci/vvvteqg](https://businessinsider.com.pl/gospodarka/ukrainki-sa-niezbedne-przy-odbudowie-kraju-analityk-nie-ma-watpliwosci/vvvteqg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T08:44:19+00:00

Blisko 70 proc. uchodźców z Ukrainy to kobiety. Zdaniem analityka agencji Bloomberga Aleksandra Isakowa, jeśli 2,8 mln kobiet w wieku produkcyjnym, które opuściły Ukrainę, nie powróci do niej po wojnie, będzie to kosztować kraj 10 proc. przedwojennego PKB.

## Poszukiwacze skarbów muszą mieć stosowne pozwolenie
 - [https://businessinsider.com.pl/wiadomosci/poszukiwacze-skarbow-musza-miec-stosowne-pozwolenie/hnb50zv](https://businessinsider.com.pl/wiadomosci/poszukiwacze-skarbow-musza-miec-stosowne-pozwolenie/hnb50zv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T08:31:58+00:00

Marzy ci się wakacyjna zabawa w poszukiwanie skarbów? Uważaj, bo w wielu sytuacjach wymagane jest specjalne pozwolenie na użycie wykrywacza metali. Są jednak wyjątki.

## 11 sposobów na to, by zostać milionerem, nie wygrywając na loterii
 - [https://businessinsider.com.pl/twoje-pieniadze/11-nieoczywistych-krokow-do-bogactwa-jak-zostac-milionerem-bez-wygranej-na-loterii/bpwvdhw](https://businessinsider.com.pl/twoje-pieniadze/11-nieoczywistych-krokow-do-bogactwa-jak-zostac-milionerem-bez-wygranej-na-loterii/bpwvdhw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T08:30:00+00:00

"Gdybym był bogaty" — myślisz, kupując losy na loterię przy kolejnej kumulacji. Znowu przegrana? Dobra wiadomość jest taka, że są inne sposoby na wzbogacenie się. Poznaj inne metody na wzbogacenie się niż wygrana na loterii.

## Krupówki wpadły w turystyczny kryzys. Oto tegoroczny "hit" Zakopanego
 - [https://businessinsider.com.pl/wiadomosci/hot-dog-zamiast-biesiady-turysci-z-zakopanego-optymalizuja-koszty/l1m3hkz](https://businessinsider.com.pl/wiadomosci/hot-dog-zamiast-biesiady-turysci-z-zakopanego-optymalizuja-koszty/l1m3hkz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T08:30:00+00:00

Jeżeli zwykle widzisz Krupówki pełne tłumów turystów, w tym roku możesz doświadczyć niespodzianki. "Najnowszym trendem jest optymalizacja cenowa" - wyjaśnia Karol Wagner z Tatrzańskiej Izby Gospodarczej w rozmowie z portalem zakopane.wyborcza.pl. Podkreśla, że nie oznacza to konieczności mniejszych wydatków, ale raczej zmiany w podejściu do cen.

## Kiedy czternasta emerytura? Premier podał datę, wybory nie bez znaczenia
 - [https://businessinsider.com.pl/gospodarka/kiedy-czternasta-emerytura-premier-podal-date-wybory-nie-bez-znaczenia/tlh8tn8](https://businessinsider.com.pl/gospodarka/kiedy-czternasta-emerytura-premier-podal-date-wybory-nie-bez-znaczenia/tlh8tn8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T08:07:26+00:00

Premier Mateusz Morawiecki podał termin, w jakim można spodziewać się wypłaty czternastej emerytury. Zgodnie z deklaracją, ma odbyć się to jeszcze przed wyborami.

## Bezrobocie najniższe od 33 lat. Idziemy na rekord
 - [https://businessinsider.com.pl/gospodarka/gdy-bezrobocie-bylo-ostatnio-tak-nisko-ministrem-byl-jacek-kuron-nowe-dane/jg756vh](https://businessinsider.com.pl/gospodarka/gdy-bezrobocie-bylo-ostatnio-tak-nisko-ministrem-byl-jacek-kuron-nowe-dane/jg756vh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T08:02:55+00:00

Ostatni raz tak nisko stopa bezrobocia w Polsce była w sierpniu 1990 r. Wtedy ministrem pracy był Jacek Kuroń. Teraz sprawami bezrobocia zajmuje się ministerstwo, które nawet słowa "praca" nie ma w nazwie, ale nie jest to najwyraźniej potrzebne, bo i bez opieki rządu rynek idzie na rekord. GUS podał, że stopa bezrobocia zeszła do 5 proc.

## Ceny polskich ziemniaków w marketach. Susza i koszty produkcji nie pomagają
 - [https://businessinsider.com.pl/wiadomosci/ceny-polskich-ziemniakow-w-marketach-susza-i-koszty-produkcji-nie-pomagaja/xwprv4l](https://businessinsider.com.pl/wiadomosci/ceny-polskich-ziemniakow-w-marketach-susza-i-koszty-produkcji-nie-pomagaja/xwprv4l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T07:55:44+00:00

Choć Polska historycznie jest jednym z ziemniaczanych potentatów, to z roku na rok upraw ubywa. Klienci w sklepach mają coraz trudniej o płody z polskich pól, szczególnie te młode. A ceny idą w górę.

## Putin próbuje zniwelować straty wizerunkowe. Napisał artykuł
 - [https://businessinsider.com.pl/gospodarka/putin-probuje-zniwelowac-straty-wizerunkowe-napisal-artykul/6wfphd9](https://businessinsider.com.pl/gospodarka/putin-probuje-zniwelowac-straty-wizerunkowe-napisal-artykul/6wfphd9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T07:35:40+00:00

Władimir Putin napisał artykuł poświęcony współpracy Rosji z Afryką. Ścigany listem gończym przez Międzynarodowy Trybunał Karny rosyjski prezydent twierdzi, że umowa zbożowa została zerwana z winy Zachodu, a Rosja może zastąpić ukraińskie zboże na światowym rynku.

## Ustawa ocenowa w Senacie. Gra idzie o nowe uprawnienia dla rządu
 - [https://businessinsider.com.pl/wiadomosci/ustawa-ocenowa-w-senacie-gra-idzie-o-nowe-uprawnienia-dla-rzadu/e7scn94](https://businessinsider.com.pl/wiadomosci/ustawa-ocenowa-w-senacie-gra-idzie-o-nowe-uprawnienia-dla-rzadu/e7scn94)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T07:34:24+00:00

Senat zajmie się w tym tygodniu tzw. ustawą ocenową. Eksperci ostrzegają, że nowe prawo da władzy możliwość realizowania inwestycji bez ogłaszania przetargów, a to może prowadzić do nadużyć.

## Orlen przejmuje farmy słoneczne i wiatrowe. Z outsidera na rynku stanie się liderem
 - [https://businessinsider.com.pl/gielda/wiadomosci/orlen-przejmuje-farmy-sloneczne-i-wiatrowe-z-outsidera-na-rynku-stanie-sie-gigantem/mbd4g0z](https://businessinsider.com.pl/gielda/wiadomosci/orlen-przejmuje-farmy-sloneczne-i-wiatrowe-z-outsidera-na-rynku-stanie-sie-gigantem/mbd4g0z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T07:26:01+00:00

Wchodząca w skład grupy Orlen spółka Energa Wytwarzanie podpisała z firmą Greenvolt umowę przedwstępną na zakup farmy wiatrowej i czterech instalacji fotowoltaicznych — poinformował Orlen w komunikacie prasowym. To zwiększy obecne moce energetyki odnawialnej w Orlenie o ponad 8 proc. Na razie ma niewielki udział w krajowych OZE, ale spółka podała, jak to będzie wyglądać za siedem lat.

## Miliony przychodów i reklamy państwowych spółek. Nowy biznes kuzyna Kaczyńskiego
 - [https://businessinsider.com.pl/firmy/miliony-przychodow-i-reklamy-panstwowych-spolek-nowy-biznes-kuzyna-kaczynskiego/r26m39h](https://businessinsider.com.pl/firmy/miliony-przychodow-i-reklamy-panstwowych-spolek-nowy-biznes-kuzyna-kaczynskiego/r26m39h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T07:07:58+00:00

Jak donosi serwis "Wirtualne Media", Forum Polskiej Gospodarki wydające miesięcznik o tej samej nazwie, w 2022 r. zwiększyło przychody o 63 proc. do 2,72 mln zł. Spółka w której prezesem jest kuzyn Jarosława Kaczyńskiego, nie może też narzekać na brak reklam — chętnie kupują je spółki skarbu państwa.

## Kurs dolara 25 lipca w okolicy 4 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-25-lipca-2023/fdj1glf](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-25-lipca-2023/fdj1glf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T07:06:20+00:00

Kurs dolara w okolicy 4 zł. We wtorek 25 lipca 2023 r. rano kurs USD/PLN wynosi 4,0151.

## Kurs franka 25 lipca powyżej 4,6 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-25-lipca-2023/5lk2hr0](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-25-lipca-2023/5lk2hr0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T07:04:35+00:00

Frank szwajcarski powyżej 4,6 zł. We wtorek 25 lipca 2023 r. kurs tej waluty wobec polskiego złotego wynosi 4,6258.

## Największy na świecie statek wycieczkowy właśnie wypływa na ocean. Ma 365 m i może pomieścić 7,6 tys pasażerów
 - [https://businessinsider.com.pl/wiadomosci/najwiekszy-na-swiecie-mega-statek-wycieczkowy-wyplywa-na-ocean-pomiesci-76-tys/k2l7yxh](https://businessinsider.com.pl/wiadomosci/najwiekszy-na-swiecie-mega-statek-wycieczkowy-wyplywa-na-ocean-pomiesci-76-tys/k2l7yxh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T06:57:00+00:00

Nowy, największy na świecie statek wycieczkowy właśnie pojawił się na oceanie. Zanim ten gigantyczny, pływający hotel, mogący pomieścić 7,6 tysiąca gości, zadebiutuje w 2024 roku, przyjrzyjmy mu się bliżej.

## Dziura w budżecie szybko się powiększa, pomimo nadwyżki w czerwcu
 - [https://businessinsider.com.pl/gospodarka/dziura-w-budzecie-szybko-sie-powieksza-pomimo-nadwyzki-w-czerwcu/vmldwvt](https://businessinsider.com.pl/gospodarka/dziura-w-budzecie-szybko-sie-powieksza-pomimo-nadwyzki-w-czerwcu/vmldwvt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T06:44:44+00:00

Budżet państwa w czerwcu akurat miał nadwyżkę, ale w danych za ostatni rok widać coraz większą dziurę. Za to po przerwie znowu rośnie wartość kredytów mieszkaniowych udzielanych w złotych. Techland zyskuje potężnego inwestora z Chin, a władze Chin zapowiadają większą aktywność w gospodarce, co cieszy tamtejszych inwestorów giełdowych. Z kolei w strefie euro koniunktura gospodarcza wygląda fatalnie. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Toyota GR86 – najlepsze auto do zabawy
 - [https://businessinsider.com.pl/technologie/motoryzacja/toyota-gr86-najlepsze-auto-do-zabawy-test/jtf78jr](https://businessinsider.com.pl/technologie/motoryzacja/toyota-gr86-najlepsze-auto-do-zabawy-test/jtf78jr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T06:30:00+00:00

Jeśli ktoś jeszcze dziś kojarzy Toyotę z nudnymi, służbowymi Avensisami, jakich niedawno pełno było na naszych drogach, to powinien zmienić zdanie o tej japońskiej marce. Teraz, myśląc o Toyocie, trzeba wspomnieć o rewelacyjnych, sportowych samochodach za rozsądną cenę. Jednym z nich jest model GR86. Takich aut w dzisiejszych czasach jest coraz mniej.

## Zimna wojna o żywność. Ceny pszenicy wystrzeliły, a Putin obiecuje "zboże za darmo"
 - [https://businessinsider.com.pl/gospodarka/wojna-o-zywnosc-ceny-pszenicy-wystrzelily-a-putin-obiecuje-zboze-za-darmo/4h35tps](https://businessinsider.com.pl/gospodarka/wojna-o-zywnosc-ceny-pszenicy-wystrzelily-a-putin-obiecuje-zboze-za-darmo/4h35tps)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T06:01:36+00:00

Zerwanie przez Rosję umowy zbożowej już powoduje gwałtowny wzrost cen pszenicy. W obliczu zawirowań zarówno Władimir Putin, jak i administracja USA planują dyplomatyczną ofensywę w Afryce.

## "Pryskali nas z węży, a my piliśmy". Kulisy ewakuacji z Rodos
 - [https://businessinsider.com.pl/wiadomosci/pryskali-nas-z-wezy-a-my-pilismy-kulisy-ewakuacji-z-rodos/l4v849s](https://businessinsider.com.pl/wiadomosci/pryskali-nas-z-wezy-a-my-pilismy-kulisy-ewakuacji-z-rodos/l4v849s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T05:41:08+00:00

Od kilku dni na greckiej wyspie Rodos szaleją pożary. W poniedziałek ponad 2 tys. turystów wróciło do domu, ale część z nich musiała wcześniej maszerować wiele kilometrów, by dostać się na lotnisko. "Chcieliśmy się napić, ludzie stali przed swoimi domami i pryskali nas z węży, a my piliśmy" – powiedziała agencji Reutera jedna z podróżnych.

## Nowy odcinek flagowej trasy wkrótce otwarty. Podano termin
 - [https://businessinsider.com.pl/gospodarka/nowy-odcinek-flagowej-trasy-wkrotce-otwarty-podano-termin/0fr66zy](https://businessinsider.com.pl/gospodarka/nowy-odcinek-flagowej-trasy-wkrotce-otwarty-podano-termin/0fr66zy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T05:31:55+00:00

Olsztyński oddział Generalnej Dyrekcji Dróg Krajowych i Autostrad zapowiedział, że w połowie sierpnia udostępni do ruchu ostatni z trzech fragmentów Via Baltica w woj. warmińsko-mazurskim.

## Spalinówki odchodzą do lamusa? Polskie firmy przekonały się do elektryków
 - [https://businessinsider.com.pl/gospodarka/spalinowki-odchodza-do-lamusa-polskie-firmy-przekonaly-sie-do-elektrykow/xkznw90](https://businessinsider.com.pl/gospodarka/spalinowki-odchodza-do-lamusa-polskie-firmy-przekonaly-sie-do-elektrykow/xkznw90)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T05:12:50+00:00

Co dziesiąta działająca w Polsce firma ma już we flocie auta na prąd. Co piąta kupi takie w najbliższym czasie. 30 proc. nie interesuje się jeszcze tym tematem - informuje we wtorek "Puls Biznesu".

## Polska traci miliony na papierosach. Palacze to duże obciążenie budżetu
 - [https://businessinsider.com.pl/gospodarka/polska-traci-miliony-na-papierosach-palacze-to-duze-obciazenie-budzetu/q7z046r](https://businessinsider.com.pl/gospodarka/polska-traci-miliony-na-papierosach-palacze-to-duze-obciazenie-budzetu/q7z046r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T05:02:53+00:00

Palenie jest kosztowne zarówno dla palaczy, jak i krajowego budżetu. To nie tylko kwestia leczenia, ale także koszty zwolnień lekarskich, z których palacze korzystają częściej i dłużej niż osoby niepalące — pisze we wtorek "Rzeczpospolita".

## Kurs EUR/PLN 25 lipca 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-25-lipca-2023-r/dmf5yvp](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-25-lipca-2023-r/dmf5yvp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T05:00:01+00:00

Bieżący kurs waluty euro z dnia 25 lipca 2023 z godziny 7 rano oraz zmiany kursu dzień do dnia i tydzień do tygodnia. Jak się zmienił kurs w tym okresie i czy warto dziś wymieniać złotówki na euro? Aktualny kurs euro interesuje przede wszystkim przedsiębiorców, którzy zajmują się importem i eksportem usług oraz towarów. Ważny jest także dla turystów planujących wakacje. Wczoraj kurs euro wynosił: 4,4484 zł

## Ten pożar tlił się od lat. Historia składowiska w Zielonej Górze może się powtórzyć [ANALIZA]
 - [https://businessinsider.com.pl/prawo/firma/to-oni-zawinili-pozar-wybuchl-bo-nikt-nie-chcial-pomoc-w-usunieciu-odpadow/x3l0fkk](https://businessinsider.com.pl/prawo/firma/to-oni-zawinili-pozar-wybuchl-bo-nikt-nie-chcial-pomoc-w-usunieciu-odpadow/x3l0fkk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T04:57:23+00:00

O groźnym składowisku w Przylepie oficjalnie wiadomo od lat. Prezydent Zielonej Góry decyzję zobowiązującą do usunięcia odpadów wydał w 2015 r. Do wybuchu pożaru nie udało się jej wykonać z braku pieniędzy, choć wszyscy wiedzieli, że to tykająca bomba. Taka historia może się jeszcze powtórzyć, bo zamiast nadzoru i współpracy, mamy spychologię.

## Ten pożar tlił się od lat. Historia składowiska w Zielonej Górze może się powtórzyć [ANALIZA]
 - [https://businessinsider.com.pl/prawo/firma/to-oni-zawinili-wszyscy-wiedzieli-o-tykajacej-bombie-w-zielonej-gorze-nikt-nie-chcial/x3l0fkk](https://businessinsider.com.pl/prawo/firma/to-oni-zawinili-wszyscy-wiedzieli-o-tykajacej-bombie-w-zielonej-gorze-nikt-nie-chcial/x3l0fkk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T04:57:23+00:00

O groźnym składowisku w Przylepie oficjalnie wiadomo od lat. Prezydent Zielonej Góry decyzję zobowiązującą do niezwłocznego usunięcia odpadów wydał w 2015 r. Do wybuchu pożaru nie udało się jej wykonać z braku pieniędzy, choć wszyscy wiedzieli, że to tykająca bomba. Taka historia może się jeszcze powtórzyć, bo zamiast nadzoru i współpracy, mamy spychologię.

## "Proboszcz plus"? Tak rząd stworzył drugi fundusz kościelny
 - [https://businessinsider.com.pl/gospodarka/proboszcz-plus-tak-rzad-stworzyl-drugi-fundusz-koscielny/4kxlpzx](https://businessinsider.com.pl/gospodarka/proboszcz-plus-tak-rzad-stworzyl-drugi-fundusz-koscielny/4kxlpzx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T04:45:49+00:00

Jak opisuje "Dziennik Gazeta Prawna", w Rządowym Programie Odbudowy Zabytków pieniądze otrzymują przede wszystkim obiekty sakralne i kościelne. Tym samym powiela założenia istniejącego już Funduszu Kościelnego.

## Limit dla ryczałtowców ma wzrosnąć. Kto skorzysta, a kto nie?
 - [https://businessinsider.com.pl/prawo/podatki/limit-dla-ryczaltowcow-ma-wzrosnac-kto-skorzysta-a-kto-nie/kddsbhk](https://businessinsider.com.pl/prawo/podatki/limit-dla-ryczaltowcow-ma-wzrosnac-kto-skorzysta-a-kto-nie/kddsbhk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T04:42:18+00:00

PiS chce podwyższyć limit przychodów dla ryczałtowców. Ma on wzrosnąć z obecnych 2 mln euro (po przeliczeniu to ok. 9 mln 654 tys. 400 zł) do 3 mln euro. Tłumaczymy, dla kogo i dlaczego będzie to korzystne oraz jakie są różnice w opodatkowaniu ryczałtowców, liniowców i przedsiębiorców opodatkowujących dochody według skali PIT.

## Dramat dla polskich fanów kebabów. Tak lokale oszukują klientów
 - [https://businessinsider.com.pl/wiadomosci/dramat-dla-polskich-fanow-kebabow-tak-lokale-oszukuja-klientow/4gw8pel](https://businessinsider.com.pl/wiadomosci/dramat-dla-polskich-fanow-kebabow-tak-lokale-oszukuja-klientow/4gw8pel)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T04:36:02+00:00

Inspekcja Jakości Handlowej Artykułów Rolno-Spożywczych (IJHARS) w I kwartale 2023 r. po raz pierwszy przeprowadziła kontrole jakości handlowej kebabów. Jej wyniki nie napawają optymizmem. Okazało się bowiem, że w prawie 82 proc. ze skontrolowanych lokali wykryto nieprawidłowości w jakości oferowanych produktów. Większość z nich dotyczyła mięsa.

## Kontrowersje wokół przejścia ze stałej stopy na zmienną. Komisja Nadzoru Finansowego wyjaśnia
 - [https://businessinsider.com.pl/finanse/kontrowersje-wokol-przejscia-ze-stalej-stopy-na-zmienna-knf-wyjasnia/83knr75](https://businessinsider.com.pl/finanse/kontrowersje-wokol-przejscia-ze-stalej-stopy-na-zmienna-knf-wyjasnia/83knr75)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T04:34:24+00:00

W ostatnich dniach rozgorzała dyskusja dotycząca nowych zaleceń Urzędu Komisji Nadzoru Finansowego w sprawie kredytów mieszkaniowych o stałym oprocentowaniu. Przedstawiamy wyjaśnienia nadzoru dotyczące tego, czy klient z taką hipoteką może przejść na zmienną stopę procentową i jak może płacić niższe odsetki. Pokazujemy też, jak bankowcy oceniają ten pomysł.

## Freelancerzy zarabiają krocie? "Zmalały zarobki specjalistów od programowania"
 - [https://businessinsider.com.pl/praca/freelancerzy-zarabiaja-krocie-zmalaly-zarobki-specjalistow-od-programowania/955gfp5](https://businessinsider.com.pl/praca/freelancerzy-zarabiaja-krocie-zmalaly-zarobki-specjalistow-od-programowania/955gfp5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T04:18:05+00:00

Najbardziej urosły zarobki freelancerów zajmujących się animacją, a zmalały specjalistów od programowania i tworzenia sklepów internetowych — wynika z raportu "Stawki freelancerów – w których branżach w I połowie 2023 r. wzrosły najbardziej?". Ogólnie "wolni strzelcy" nie mają jednak powodów do narzekania — średni wzrost ich płac to ok. 25 proc. w porównaniu do ubiegłego roku.

## Samochód po wykupie z leasingu zostawiłeś w firmie? Z VAT będziesz miał problem
 - [https://businessinsider.com.pl/prawo/podatki/samochod-po-wykupie-z-leasingu-zostawiles-w-firmie-z-vat-bedziesz-mial-problem/2nkgcd1](https://businessinsider.com.pl/prawo/podatki/samochod-po-wykupie-z-leasingu-zostawiles-w-firmie-z-vat-bedziesz-mial-problem/2nkgcd1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T04:13:35+00:00

Wielu podatników po zakończonym leasingu samochodu zostawia pojazd w działalności, a dopiero po jakimś czasie zamierza pozbyć się auta lub nawet zamknąć firmę. Po wykupie auto jest zwykle nadal przydatne, może być korzystnie rozliczone w PIT, można od wydatków eksploatacyjnych nadal odliczać VAT. Problem pojawia się później – gdy auto w działalności przestaje być potrzebne i chcesz coś zrobić z nim lub firmą.

## Zielona Góra to dopiero początek. Polska ma bardzo poważny problem
 - [https://businessinsider.com.pl/gospodarka/zielona-gora-to-dopiero-poczatek-polska-ma-bardzo-powazny-problem/nqc3csr](https://businessinsider.com.pl/gospodarka/zielona-gora-to-dopiero-poczatek-polska-ma-bardzo-powazny-problem/nqc3csr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-07-25T04:01:00+00:00

Pożar składowiska odpadów w Przylepie pod Zieloną Górą to tylko wierzchołek góry lodowej. Problem jest znacznie głębszy i na terenie całej Polski takich miejsc jest więcej. Wskazywała na to nawet Najwyższa Izba Kontroli. Kłopot w tym, że gminy po prostu nie mają pieniędzy na walkę ze składowaniem nielegalnych i niebezpiecznych substancji. Bo jej koszty idą w grube miliony złotych. Tymczasem politycy zajmują się tylko przerzucaniem odpowiedzialności.

