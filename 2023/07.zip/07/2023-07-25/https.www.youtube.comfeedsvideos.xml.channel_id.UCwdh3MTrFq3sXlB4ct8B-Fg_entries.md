# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## Warhammer 40,000: Chaos Gate - Daemonhunters  - Execution Force - Official Launch Trailer
 - [https://www.youtube.com/watch?v=LpgVcznTCGM](https://www.youtube.com/watch?v=LpgVcznTCGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-25T14:00:15+00:00

The Assassins are here! Check out the new DLC for Warhammer 40,000: Chaos Gate – Daemonhunters.

Find out more: https://www.chaosgate.com/ 

Follow for more Warhammer: 

- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial
- Instagram: https://www.instagram.com/warhammerofficial
- Warhammer Community: https://www.warhammer-community.com

## Painting Essentials: Undercoating
 - [https://www.youtube.com/watch?v=JotmitVvwlQ](https://www.youtube.com/watch?v=JotmitVvwlQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-25T11:41:55+00:00

Undercoating is the first step when painting your miniatures. In this video we'll show you everything you need to know to get that smooth undercoat.

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Painting Essentials: Drybrushing
 - [https://www.youtube.com/watch?v=JMtssgDigZ0](https://www.youtube.com/watch?v=JMtssgDigZ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-25T10:00:58+00:00

Drybrushing allows you to highlight your miniatures in no time at all! This video shows you which paints to use and how to use them in order to take your painting to the next level.    
     
If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Painting Essentials: Applying Transfers
 - [https://www.youtube.com/watch?v=PV1odeKdGD8](https://www.youtube.com/watch?v=PV1odeKdGD8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-25T10:00:56+00:00

Transfers allow us to add intricate details to our miniatures. In this video we'll be showing you how to apply them to both flat and curved surfaces using the Citadel Colour paint range.        

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Painting Essentials: Layering
 - [https://www.youtube.com/watch?v=P_oYMKB-QqA](https://www.youtube.com/watch?v=P_oYMKB-QqA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-25T10:00:56+00:00

Layering up a basecoat with a slightly brighter colour is a fantastic way to start adding depth and gradient to your miniatures. Follow along with this video to learn everything you need to know about layering!    
    
If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Painting Essentials: Contrast Paint
 - [https://www.youtube.com/watch?v=TnJmtAT6TXY](https://www.youtube.com/watch?v=TnJmtAT6TXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-25T10:00:51+00:00

Contrast paints are incredibly versatile and are a great addition to any painter's toolbox. This video shows you how to get the best results using Contrast in a variety of ways.        
 
If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Painting Essentials: Shading
 - [https://www.youtube.com/watch?v=ejXlcA1Mjs4](https://www.youtube.com/watch?v=ejXlcA1Mjs4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-25T10:00:49+00:00

Shading a miniature is a really simple way to elevate a painted miniature. In this video we'll be using the Citadel Colour paint range to show you how to achieve this effect in different ways.     
    
If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Painting Essentials: Undercoating
 - [https://www.youtube.com/watch?v=fyyCriFbOHI](https://www.youtube.com/watch?v=fyyCriFbOHI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-25T10:00:49+00:00

Undercoating is the first step when painting your miniatures. In this video we'll show you everything you need to know to get that smooth undercoat.

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Painting Essentials: Basing
 - [https://www.youtube.com/watch?v=Q2BjTl4jDEU](https://www.youtube.com/watch?v=Q2BjTl4jDEU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-07-25T10:00:48+00:00

The finishing touch to any miniature is the base! In this video, we'll be showing you how to make the most of the Citadel Technical Paints to create some awesome looking scenic bases. 
       
If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

