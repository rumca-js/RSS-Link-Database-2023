# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Ban smartphones from schools, says major UN report
 - [https://www.telegraph.co.uk/news/2023/07/25/smartphones-school-classroom-ban-united-nations-unesco/](https://www.telegraph.co.uk/news/2023/07/25/smartphones-school-classroom-ban-united-nations-unesco/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-25T22:50:03+00:00



## Ukraine: The Latest - The future for Ukraine's counter-offensive
 - [https://www.telegraph.co.uk/news/2023/07/25/ukraine-russia-counteroffensive-supplies-training-slow/](https://www.telegraph.co.uk/news/2023/07/25/ukraine-russia-counteroffensive-supplies-training-slow/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-25T17:43:03+00:00



## Sexual predator posed as Uber driver to assault vulnerable women
 - [https://www.telegraph.co.uk/news/2023/07/25/sexual-predator-posed-as-taxi-uber-driver-brighton-hove/](https://www.telegraph.co.uk/news/2023/07/25/sexual-predator-posed-as-taxi-uber-driver-brighton-hove/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-25T17:37:09+00:00



## Dame Alison Rose's statement in full: 'I made a serious error of judgment'
 - [https://www.telegraph.co.uk/news/2023/07/25/dame-alison-rose-statement-in-full-nigel-farage-bbc-coutts/](https://www.telegraph.co.uk/news/2023/07/25/dame-alison-rose-statement-in-full-nigel-farage-bbc-coutts/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-25T17:36:17+00:00



## Woman died of cancer after urgent referral left in hospital pigeonhole
 - [https://www.telegraph.co.uk/news/2023/07/25/cancer-death-urgent-referral-left-wales-hospital-pigeonhole/](https://www.telegraph.co.uk/news/2023/07/25/cancer-death-urgent-referral-left-wales-hospital-pigeonhole/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-25T17:35:22+00:00



## Tuesday evening news briefing: Firefighting plane crashes in Greece
 - [https://www.telegraph.co.uk/news/2023/07/25/tuesday-evening-news-briefing-greek-wildfire-crash-hsbc/](https://www.telegraph.co.uk/news/2023/07/25/tuesday-evening-news-briefing-greek-wildfire-crash-hsbc/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-25T17:18:31+00:00



## NatWest boss Dame Alison Rose admits leaking information about Nigel Farage to BBC
 - [https://www.telegraph.co.uk/news/2023/07/25/alison-rose-natwest-leak-bbc-nigel-farage-coutts/](https://www.telegraph.co.uk/news/2023/07/25/alison-rose-natwest-leak-bbc-nigel-farage-coutts/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-25T16:56:28+00:00



## Bodybuilder sued NHS over arm operation – then posted videos of himself at gym
 - [https://www.telegraph.co.uk/news/2023/07/25/bodybuilder-sean-murphy-sued-nhs-operation-caught-out/](https://www.telegraph.co.uk/news/2023/07/25/bodybuilder-sean-murphy-sued-nhs-operation-caught-out/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-25T16:29:20+00:00



## Readers remember George Alagiah: ‘He is the sort of person that once personified the BBC’
 - [https://www.telegraph.co.uk/news/2023/07/25/telegraph-readers-remember-george-alagiah-personified-bbc/](https://www.telegraph.co.uk/news/2023/07/25/telegraph-readers-remember-george-alagiah-personified-bbc/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-07-25T10:57:09+00:00



