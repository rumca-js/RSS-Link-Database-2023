# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## The Guardian turns to Europe for growth as UK sales decline
 - [https://www.telegraph.co.uk/business/2023/07/25/the-guardian-turns-to-europe-for-growth-as-uk-sales-decline/](https://www.telegraph.co.uk/business/2023/07/25/the-guardian-turns-to-europe-for-growth-as-uk-sales-decline/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T15:51:26+00:00



## British economy will outperform Germany this year, IMF admits
 - [https://www.telegraph.co.uk/business/2023/07/25/british-economy-outperform-germany-this-year-imf/](https://www.telegraph.co.uk/business/2023/07/25/british-economy-outperform-germany-this-year-imf/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T15:50:40+00:00



## CityAM on the brink of administration after working from home blow
 - [https://www.telegraph.co.uk/business/2023/07/25/cityam-on-the-brink-of-administration-working-from-home/](https://www.telegraph.co.uk/business/2023/07/25/cityam-on-the-brink-of-administration-working-from-home/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T14:49:55+00:00



## Spotify takes £34m hit on podcasting in wake of Harry & Meghan split
 - [https://www.telegraph.co.uk/business/2023/07/25/spotify-podcasts-cutbacks-cost-34m-megan-markle-deal-split/](https://www.telegraph.co.uk/business/2023/07/25/spotify-podcasts-cutbacks-cost-34m-megan-markle-deal-split/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T14:10:55+00:00



## 'How can we prevent AI hitting escape velocity and leaving us behind?'
 - [https://www.telegraph.co.uk/business/2023/07/25/artificial-intelligence-ai-qa-expert-answers-questions/](https://www.telegraph.co.uk/business/2023/07/25/artificial-intelligence-ai-qa-expert-answers-questions/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T13:20:21+00:00



## Apple hit by £800m British lawsuit over ‘excessive’ App Store fees
 - [https://www.telegraph.co.uk/business/2023/07/25/apple-hit-by-800m-british-lawsuit-over-excessive-app-store/](https://www.telegraph.co.uk/business/2023/07/25/apple-hit-by-800m-british-lawsuit-over-excessive-app-store/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T12:27:03+00:00



## Police block Elon Musk’s rebrand of Twitter’s headquarters
 - [https://www.telegraph.co.uk/business/2023/07/25/elon-musk-twitter-rebrand-headquarters-blocked-police/](https://www.telegraph.co.uk/business/2023/07/25/elon-musk-twitter-rebrand-headquarters-blocked-police/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T08:44:39+00:00



## Marmite maker Unilever’s profits soar as watchdog investigates greedflation
 - [https://www.telegraph.co.uk/business/2023/07/25/unilever-profits-investigation-greedflation-marmite/](https://www.telegraph.co.uk/business/2023/07/25/unilever-profits-investigation-greedflation-marmite/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T08:11:46+00:00



## Wheat prices hit five month high as Russia attacks Ukrainian port - latest updates
 - [https://www.telegraph.co.uk/business/2023/07/25/ftse-100-markets-live-news-wheat-prices-russia-ukraine-port/](https://www.telegraph.co.uk/business/2023/07/25/ftse-100-markets-live-news-wheat-prices-russia-ukraine-port/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T06:11:28+00:00



## Tube strikes: July walkout dates called off by RMT and ASLEF
 - [https://www.telegraph.co.uk/business/2023/07/25/tube-strike-dates-july-2023-tfl-london-underground/](https://www.telegraph.co.uk/business/2023/07/25/tube-strike-dates-july-2023-tfl-london-underground/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T06:00:41+00:00



## Pay us more to boost the City of London, say FTSE chiefs
 - [https://www.telegraph.co.uk/business/2023/07/25/higher-pay-needed-boost-city-of-london-ftse-chiefs/](https://www.telegraph.co.uk/business/2023/07/25/higher-pay-needed-boost-city-of-london-ftse-chiefs/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T06:00:00+00:00



## Train strikes 2023: Walkout dates and the services affected
 - [https://www.telegraph.co.uk/business/2023/07/25/train-strikes-2023-dates-rmt-rail-services-affected/](https://www.telegraph.co.uk/business/2023/07/25/train-strikes-2023-dates-rmt-rail-services-affected/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T05:58:07+00:00



## Lawyer pay bonanza widens gap between London and the rest of UK
 - [https://www.telegraph.co.uk/business/2023/07/25/lawyer-pay-bonanza-widens-gap-between-london-and-uk/](https://www.telegraph.co.uk/business/2023/07/25/lawyer-pay-bonanza-widens-gap-between-london-and-uk/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-07-25T05:00:00+00:00



