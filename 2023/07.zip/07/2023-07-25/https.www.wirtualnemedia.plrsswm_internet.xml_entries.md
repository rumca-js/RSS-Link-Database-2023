# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Alphabet zarobił na czysto ponad 2 mld więcej. Spadek w sieci reklamowej Google
 - [https://www.wirtualnemedia.pl/artykul/alphabet-zarobil-na-czysto-ponad-2-mld-wiecej-spadek-w-sieci-reklamowej-google](https://www.wirtualnemedia.pl/artykul/alphabet-zarobil-na-czysto-ponad-2-mld-wiecej-spadek-w-sieci-reklamowej-google)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-25T21:34:05.762004+00:00

W drugim kwartale br. koncern Alphabet zanotował wzrost przychodów o 7 proc. do 74,6 mld dolarów, przy czym zmalały wpływy sieci reklamowej Google. Zysk netto zwiększył się z 16 do 18,37 mld dolarów, w wskutek zwolnień liczba pracowników przez pół roku spadła o ponad 8 tys.

## TikTok wprowadza posty tekstowe
 - [https://www.wirtualnemedia.pl/artykul/tiktok-posty-tekstowe](https://www.wirtualnemedia.pl/artykul/tiktok-posty-tekstowe)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-25T11:50:21.226696+00:00

Platforma rozrywkowo-społecznościowa TikTok właśnie ogłosiła wprowadzenie postów tekstowych. Prawdopodobnie chce w ten sposób włączyć się do rywalizacji Twittera/X z Threads od Mety.

## InPost obsłuży przesyłki Allegro do Czech
 - [https://www.wirtualnemedia.pl/artykul/inpost-przesylki-allegro-czechy-cena-jak-zamowic](https://www.wirtualnemedia.pl/artykul/inpost-przesylki-allegro-czechy-cena-jak-zamowic)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-25T11:50:21.224464+00:00

InPost podpisał umowę z Allegro na obsługę przesyłek zamawianych przez użytkowników platformy do Czech. Usługa będzie dostępna od września, a docelowo będzie rozszerzana na kolejne kraje.

## Angielski klub grozi pozwem Mateuszowi Borkowi za wypowiedzi o rehabilitacji polskiego piłkarza
 - [https://www.wirtualnemedia.pl/artykul/mateusz-borek-kanal-sportowy-youtube-kontuzja-jakub-moder](https://www.wirtualnemedia.pl/artykul/mateusz-borek-kanal-sportowy-youtube-kontuzja-jakub-moder)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-25T08:35:27.446994+00:00

Mateusz Borek ujawnił, że w związku z jego wypowiedziami w Kanale Sportowym o kontuzji Jakuba Modera, zatrudniający piłkarza angielski klub Brighton grozi mu pozwem. - W ogóle się tym nie przejmuję. Niech składają sprawę, jak chcą - stwierdził Borek.

## InPost obsłuży przesyłki Allegro do Czech
 - [https://www.wirtualnemedia.pl/artykul/inpost-obsluzy-przesylki-allegro-do-czech](https://www.wirtualnemedia.pl/artykul/inpost-obsluzy-przesylki-allegro-do-czech)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-25T08:35:27.444806+00:00

InPost podpisał umowę z Allegro na obsługę przesyłek zamawianych przez użytkowników platformy do Czech. Usługa będzie dostępna od września, a docelowo będzie rozszerzana na kolejne kraje.

## Spotify podnosi ceny subskrypcji
 - [https://www.wirtualnemedia.pl/artykul/podwyzka-spotify-premium-ile-kosztuje-subskrypcja-ceny](https://www.wirtualnemedia.pl/artykul/podwyzka-spotify-premium-ile-kosztuje-subskrypcja-ceny)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-25T07:28:05.810955+00:00

Platforma streamingowa Spotify ogłosiła podwyżkę cen swoich pakietów subskrypcyjnych w kilkudziesięciu krajach, m.in. USA. W Polsce ceny pozostaną bez zmian.

## Internet wolniejszy niż w reklamach. „Z marketingowego punktu widzenia to oczywista decyzja”
 - [https://www.wirtualnemedia.pl/artykul/upc-play-vectra-orange-netia-predkosc-internet-maksymalna-minimalna-rzeczywista-marketing-speed-test-test-predkosci](https://www.wirtualnemedia.pl/artykul/upc-play-vectra-orange-netia-predkosc-internet-maksymalna-minimalna-rzeczywista-marketing-speed-test-test-predkosci)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-25T04:13:07.693794+00:00

Choć operatorzy chwalą się coraz szybszym internetem, to po wykonaniu dowolnego „speed testu” często okazuje się, że łącze jest niemal dwa razy wolniejsze niż w reklamie. Przedstawiciele Orange, UPC Polska, Vectry i Netii zapewniają Wirtualnemedia.pl, że to całkowicie zgodna z prawem praktyka marketingowa.

## Twitter to teraz X. Będzie "aplikacją od wszystkiego"
 - [https://www.wirtualnemedia.pl/artykul/x-koniec-twitter](https://www.wirtualnemedia.pl/artykul/x-koniec-twitter)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-07-25T04:13:07.688800+00:00

Należący do Elona Muska Twitter rozpoczął w poniedziałek rebranding, zmieniając swoje logo na literę X. Według zapowiedzi miliardera i dyrektor spółki Lindy Yaccarino, X ma się stać "aplikacją od wszystkiego". - Paradoksalnie, dzięki nowej marce Musk zaciąga kredyt zaufania, który skoncentruje uwagę na nowej ofercie i przyciągnie podmioty chcące być częścią potencjalnej rewolucji. Nie gwarantuje to oczywiście sukcesu nowej platformy, ale daje większe szanse na powodzenie niż stopniowe testowanie i wprowadzanie nowych funkcjonalności do Twittera. Słowem - Typowe zagranie All In - ocenia dla Wirtualnemedia.pl Rafał Oracz, CEO AdNext.

