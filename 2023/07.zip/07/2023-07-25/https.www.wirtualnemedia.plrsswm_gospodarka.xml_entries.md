# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Link4 uruchomiła aplikację wspomaganą sztuczną inteligencją. Pomoże ocenić szkody
 - [https://www.wirtualnemedia.pl/artykul/link4-sztuczna-inteligencja-pomoze-ocenic-szkody](https://www.wirtualnemedia.pl/artykul/link4-sztuczna-inteligencja-pomoze-ocenic-szkody)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-25T19:24:05.112251+00:00

Klienci Link4 mogą już korzystać z nowej aplikacji do wyceny szkody, która wykorzystuje sztuczną inteligencję (AI). Po załączeniu zdjęć uszkodzonego pojazdu klienci średnio w ciągu 30 sekund otrzymują gotowy kosztorys i propozycję zakończenia procesu likwidacji.

## Palikot o kontroli skarbówki i materiale TVP: chodzi o atak na Tuska, już jestem winny
 - [https://www.wirtualnemedia.pl/artykul/janusz-palikot-pozyczka-kontrola-skarbowki-kuba-wojewodzki-donald-tusk](https://www.wirtualnemedia.pl/artykul/janusz-palikot-pozyczka-kontrola-skarbowki-kuba-wojewodzki-donald-tusk)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-25T18:19:29.641649+00:00

Janusz Palikot odniósł się do ogłoszonej w poniedziałek kontroli Krajowej Administracji Skarbowej w jego holdingu alkoholowym, w której mniejszościowy pakiet akcji ma Kuba Wojewódzki. - W sztabie wyborczym PiS zapadła decyzja o politycznym wykorzystaniu problemów spółki, której jestem Prezesem, do ataku na Donalda Tuska. Jestem już winny, kwestią dyskusji jest sposób wykonania wyroku - stwierdził Palikot.

## O prawie 25 proc. wzrosły średnie stawki polskich freelancerów
 - [https://www.wirtualnemedia.pl/artykul/stawka-freelancer-wzrost-cen](https://www.wirtualnemedia.pl/artykul/stawka-freelancer-wzrost-cen)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-25T07:28:05.452741+00:00

Najbardziej urosły zarobki freelancerów zajmujących się animacją, a zmalały specjalistów od programowania i tworzenia sklepów internetowych - wynika z raportu "Stawki freelancerów – w których branżach w I połowie 2023 r. wzrosły najbardziej?". Średni ich wzrost wyniósł prawie 25 procent.

## Przez aplikację mobilną PKP Intercity sprzedano milion biletów
 - [https://www.wirtualnemedia.pl/artykul/jak-dziala-aplikacja-mobilna-pkp-intercity](https://www.wirtualnemedia.pl/artykul/jak-dziala-aplikacja-mobilna-pkp-intercity)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-25T06:23:17.940898+00:00

PKP Intercity sprzedało przez swoją aplikację mobilną milion biletów kolejowych. Aplikacja została uruchomiona na początku tego roku i od tego czasu została pobrana ponad 650 tys. razy.

## Przed 95 lat zapoczątkowane zostało odkrycie penicyliny
 - [https://www.wirtualnemedia.pl/artykul/odkrycie-penicylina-narasta-odpornosc-bakterii-na-antybiotyki](https://www.wirtualnemedia.pl/artykul/odkrycie-penicylina-narasta-odpornosc-bakterii-na-antybiotyki)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-25T06:23:17.938627+00:00

W lipcu 1928 r. Aleksander Fleming zapoczątkował badania, które doprowadziły do odkrycia penicyliny. Wydarzenie to jest przypominane, gdyż na świecie narasta odporność bakterii na antybiotyki.

## O prawie 25 proc. wzrosły średnie stawki polskich freelancerów
 - [https://www.wirtualnemedia.pl/artykul/sstawki-polskich-freelancerow-wzrost-cen](https://www.wirtualnemedia.pl/artykul/sstawki-polskich-freelancerow-wzrost-cen)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-25T06:23:17.936372+00:00

Najbardziej urosły zarobki freelancerów zajmujących się animacją, a zmalały specjalistów od programowania i tworzenia sklepów internetowych - wynika z raportu "Stawki freelancerów – w których branżach w I połowie 2023 r. wzrosły najbardziej?". Średni ich wzrost wyniósł prawie 25 procent.

## Problemy techniczne w obsłudze e-skierowań. "Reagujemy na bieżąco"
 - [https://www.wirtualnemedia.pl/artykul/problemy-techniczne-e-skierowania](https://www.wirtualnemedia.pl/artykul/problemy-techniczne-e-skierowania)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-25T05:18:22.205215+00:00

Obsługa e-skierowań uzdrowiskowych działa nieprzerwanie. Na problemy techniczne reagujemy na bieżąco - przekazało PAP Ministerstwo Zdrowia odnosząc się do zarzutów Porozumienia Pracodawców Ochrony Zdrowia dot. e-skierowań do sanatorium.

## W aukcji na 4 rezerwacje częstotliwości pasma 3,6-3,8 GHz wezmą udział 4 duzi operatorzy
 - [https://www.wirtualnemedia.pl/artykul/aukcja-5g-uke-rezerwacja-czestotliwosci-pasmo-3-6-3-8-ghz-kto-bierze-udzial](https://www.wirtualnemedia.pl/artykul/aukcja-5g-uke-rezerwacja-czestotliwosci-pasmo-3-6-3-8-ghz-kto-bierze-udzial)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-25T04:13:07.294861+00:00

Urząd Komunikacji Elektronicznej przewiduje, że w aukcji na cztery rezerwacje częstotliwości pasma 3,6-3,8 GHz wezmą udział czterej duzi operatorzy w Polsce: T-Mobile, Polkomtel, Orange Polska i P4.

## Value Media urosła o dwie trzecie, 6,5 mln zł zysku
 - [https://www.wirtualnemedia.pl/artykul/value-media-urosla-o-dwie-trzecie-6-5-mln-zl-zysku](https://www.wirtualnemedia.pl/artykul/value-media-urosla-o-dwie-trzecie-6-5-mln-zl-zysku)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-07-25T04:13:07.292436+00:00

Agencja mediowa Value Media (należy do holdingu Group One) osiągnęła w ub.r. wzrost przychodów o 65,4 proc. do 465,58 mln zł, a jej zysk netto zwiększył się z 5,55 do 6,5 mln zł.

