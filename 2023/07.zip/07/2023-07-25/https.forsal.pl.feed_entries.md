# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## GIS ostrzega przed wysokim poziomem akryloamidu w chipsach. Podano numer partii
 - [https://forsal.pl/biznes/handel/artykuly/8961237,gis-ostrzega-przed-wysokim-poziomem-akryloamidu-w-chipsach-podano-num.html](https://forsal.pl/biznes/handel/artykuly/8961237,gis-ostrzega-przed-wysokim-poziomem-akryloamidu-w-chipsach-podano-num.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T21:01:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-7pktkuTURBXy9kNWNlYWNhMC0xNjc0LTRjNTEtYjViMS00MzNhZjVmNDIwNGQuanBlZ5GTBc0BHcyg" />Główny Inspektorat Sanitarny poinformował we wtorek o wycofaniu z obrotu partii chipsów warzywnych &quot;enerBio Chipsy warzywne 75 g, z trzech rodzajów warzyw, produkt odpowiedni dla vegan&quot;.

## MFW: Gospodarka Niemiec skurczy się bardziej niż zakładano
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8960548,mfw-gospodarka-niemiec-skurczy-sie-bardziej-niz-zakladano.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8960548,mfw-gospodarka-niemiec-skurczy-sie-bardziej-niz-zakladano.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T19:53:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4BbktkuTURBXy81NGEwMjlkOC04NzI0LTQ2ZWQtYjQ5Ni05NDY4MThjODNlMWUuanBlZ5GTBc0BHcyg" />Międzynarodowy Fundusz Walutowy (MFW) zaktualizował we wtorek prognozy, dotyczące globalnego wzrostu i ocenił, że jest on nadal słaby i towarzyszy mu wiele zagrożeń. MFW skorygował też założenia dla niemieckiej gospodarki i podał, że PKB kraju skurczy się w tym roku o 0,3 proc.

## Bezpieczny Autobus w aplikacji mObywatel. Sprawdź, czy pojazd ma ważne badania techniczne
 - [https://forsal.pl/transport/aktualnosci/artykuly/8960189,bezpieczny-autobus-w-aplikacji-mobywatel-sprawdz-czy-pojazd-ma-wazne.html](https://forsal.pl/transport/aktualnosci/artykuly/8960189,bezpieczny-autobus-w-aplikacji-mobywatel-sprawdz-czy-pojazd-ma-wazne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T19:30:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xguktkuTURBXy8yZTNiYzQ1Zi0zZjYxLTQzOWEtYWEwYS1lOGMzMDZhZTMyZmMuanBlZ5GTBc0BHcyg" />Od wtorku w mObywatelu dostępna jest funkcja Bezpieczny Autobus - poinformował minister cyfryzacji Janusz Cieszyński. Nowa usługa pozwala sprawdzić, czy autobus, którym będzie się podróżować, ma ważne badania techniczne i polisę OC.

## Nawałnica na zachodzie Szwajcarii. Jedna ofiara śmiertelna, zniszczone budynki i lasy w La Chaux-de-Fonds
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8959002,nawalnica-na-zachodzie-szwajcarii-jedna-ofiara-smiertelna-zniszczone.html](https://forsal.pl/swiat/aktualnosci/artykuly/8959002,nawalnica-na-zachodzie-szwajcarii-jedna-ofiara-smiertelna-zniszczone.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T17:57:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/B4BktkuTURBXy82MzcyMTk4MS00MjdjLTQxMzQtYjFkMi0wMGRlYWM4MWU3YWYuanBlZ5GTBc0BHcyg" />Poniedziałkowa nawałnica w rejonie miasta La Chaux-de-Fonds (kanton Neuchatel) na zachodzie Szwajcarii spowodowała szkody w wysokości nawet 90 mln franków – poinformowały we wtorek lokalne władze. Porywy wiatru dochodziły do 217 km/h, uszkodzeniu uległo 4 tys. budynków i duże obszary lasów.

## USA ogłosiły kolejny pakiet pomocy wojskowej dla Ukrainy wart 400 mln dolarów
 - [https://forsal.pl/swiat/usa/artykuly/8958875,usa-oglosily-kolejny-pakiet-pomocy-wojskowej-dla-ukrainy-wart-400-mln.html](https://forsal.pl/swiat/usa/artykuly/8958875,usa-oglosily-kolejny-pakiet-pomocy-wojskowej-dla-ukrainy-wart-400-mln.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T17:49:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mEJktkuTURBXy81ZTc4NTdkZC0zM2I4LTQ4ZGMtYWE3MS0yZmEyMzY3NDk0NDguanBlZ5GTBc0BHcyg" />USA ogłosiły we wtorek kolejny pakiet pomocy wojskowej dla Ukrainy, warty łącznie 400 mln dolarów. W transzy znalazło się 15 różnych rodzajów uzbrojenia, w tym m.in. dodatkowa amunicja do systemów Patriot, NASAMS, HIMARS, 32 wozy opancerzone Stryker oraz mini drony Black Hornet.

## Banki inwestycyjne obniżają ocenę Izraela. Powód: "kontrowersyjna reforma sądownictwa"
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8958618,banki-inwestycyjne-obnizaja-ocene-izraela-powod-kontrowersyjna-refo.html](https://forsal.pl/finanse/aktualnosci/artykuly/8958618,banki-inwestycyjne-obnizaja-ocene-izraela-powod-kontrowersyjna-refo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T17:31:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Tb5ktkuTURBXy9iOWJmZjkzYS1iZTNkLTQzYzYtYjcwYS04Zjc2NmY2NDQzMDkuanBlZ5GTBc0BHcyg" />Banki inwestycyjne Morgan Stanley i Citi obniżyły ocenę długu Izraela ze względu na kontrowersyjną reformę sądownictwa. Spada kurs izraelskiej waluty i notowania na tamtejszej giełdzie. Moody’s zapowiedział specjalny raport na temat ratingu tego kraju - podaje we wtorek portal Times of Israel.

## Rosja zaatakuje cywilne statki na Morzu Czarnym? Carpenter: To byłaby zbrodnia wojenna
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8957856,rosja-zaatakuje-cywilne-statki-na-morzu-czarnym-carpenter-to-bylaby.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8957856,rosja-zaatakuje-cywilne-statki-na-morzu-czarnym-carpenter-to-bylaby.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T16:37:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZaAktkuTURBXy9hZmNlMGI1MS01OWM5LTQ2ZDctYjNjMC04MjYxYzE3YjRmMTMuanBlZ5GTBc0BHcyg" />Wiemy, że Rosja posiada plan ataku na cywilne statki na Morzu Czarnym i zrzucenia za niego winy na Ukrainę - powiedział we wtorek ambasador USA przy OBWE Michael Carpenter, odpowiadając na pytanie PAP. Dyplomata stwierdził, że taki atak stanowiłby zbrodnię wojenną, a Ameryka podchodzi do sprawy &quot;bardzo, bardzo poważnie&quot;

## Zatrzymano wyciek ścieków do Bałtyku po awarii w Lipawie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8957422,zatrzymano-wyciek-sciekow-do-baltyku-po-awarii-w-lipawie.html](https://forsal.pl/swiat/aktualnosci/artykuly/8957422,zatrzymano-wyciek-sciekow-do-baltyku-po-awarii-w-lipawie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T16:06:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Xo8ktkuTURBXy9kMmUwNDg0ZS0zMzY2LTQ4ODktYTFkOC04ODgxZWQwODQxMmMuanBlZ5GTBc0BHcyg" />Zatrzymano wyciek nieczystości do Morza Bałtyckiego, do którego doszło po zawaleniu się ściany zbiornika oczyszczalni ścieków w Lipawie na zachodzie Łotwy - informują we wtorek łotewskie media. Władze odradzają kąpiele w morzu w tej okolicy.

## Bogdanka obniżyła cel produkcyjny ws. węgla handlowego
 - [https://forsal.pl/biznes/handel/artykuly/8957267,bogdanka-obnizyla-cel-produkcyjny-ws-wegla-handlowego.html](https://forsal.pl/biznes/handel/artykuly/8957267,bogdanka-obnizyla-cel-produkcyjny-ws-wegla-handlowego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T15:49:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1UpktkuTURBXy82MGM0MzYzNi1hZTcxLTQ0YmYtYWE0NS1kMDQ5NjZkNzY0YzUuanBlZ5GTBc0BHcyg" />undefined

## Szwedzkie samoloty wczesnego ostrzegania. Szef MON: Agencja Uzbrojenia podpisała umowę na dostawę
 - [https://forsal.pl/transport/artykuly/8957161,szwedzkie-samoloty-wczesnego-ostrzegania-szef-mon-agencja-uzbrojenia.html](https://forsal.pl/transport/artykuly/8957161,szwedzkie-samoloty-wczesnego-ostrzegania-szef-mon-agencja-uzbrojenia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T15:26:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Hh6ktkuTURBXy9kYzM2MWZjMC0yNmVlLTQ4OGMtOGMzZS1jYmVlY2M5MGEyOWUuanBlZ5GTBc0BHcyg" />Agencja Uzbrojenia podpisała we wtorek umowę na dostawę szwedzkich samolotów wczesnego ostrzegania Saab 340 AEW; polska przestrzeń powietrzna staje się dzięki temu bezpieczniejsza - przekazał minister obrony narodowej Mariusz Błaszczak.

## TSMC zainwestuje 2,9 mld dol. w nową fabrykę. To odpowiedź na boom w AI
 - [https://forsal.pl/biznes/artykuly/8957096,tsmc-zainwestuje-29-mld-dol-w-nowa-fabryke-to-odpowiedz-na-boom-w-a.html](https://forsal.pl/biznes/artykuly/8957096,tsmc-zainwestuje-29-mld-dol-w-nowa-fabryke-to-odpowiedz-na-boom-w-a.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T15:21:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PVEktkuTURBXy9jMTlmNTU0YS1lN2MxLTQxODQtYTBiMy0wOTg5N2NmZDYwNmUuanBlZ5GTBc0BHcyg" />TSMC, tajwański lider rynku czipów, planuje zainwestować ogromne środki w budowę w tym azjatyckim kraju fabryki pakowania czipów - pisze CNBC. Ma to być forma dostosowania się do szybkiego rozwoju sztucznej inteligencji.

## Teleskop Webba wykrył parę wodną w strefie formowania się planet skalistych
 - [https://forsal.pl/lifestyle/nauka/artykuly/8957017,teleskop-webba-wykryl-pare-wodna-w-strefie-formowania-sie-planet-skali.html](https://forsal.pl/lifestyle/nauka/artykuly/8957017,teleskop-webba-wykryl-pare-wodna-w-strefie-formowania-sie-planet-skali.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T15:16:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Sf8ktkuTURBXy8wOGM5ZmU1YS0zZjdjLTQ1ZDQtODVmYS00ZDg0NTM0YTUwNGQuanBlZ5GTBc0BHcyg" />NASA poinformowała o nowych wynikach obserwacji przy pomocy Kosmicznego Teleskopu Jamesa Webba. Naukowcom udało się wykryć parę wodną w jednym z młodych systemów gwiazdowych w odległości od gwiazdy podobnej jak dystans Ziemi od Słońca.

## "Putin popełnił niewybaczalny błąd. Stracił reputację najtwardszego człowieka w mieście"
 - [https://forsal.pl/swiat/rosja/artykuly/8956940,putin-popelnil-niewybaczalny-blad-stracil-reputacje-najtwardszego-cz.html](https://forsal.pl/swiat/rosja/artykuly/8956940,putin-popelnil-niewybaczalny-blad-stracil-reputacje-najtwardszego-cz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T15:11:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/33FktkuTURBXy9jMWUwZDQ3Yi1kYmRkLTRhNzEtYWY1OC04ZDllOWZmMDQ5ZjkuanBlZ5GTBc0BHcyg" />Władimir Putin był &quot;sparaliżowany&quot; i niezdecydowany podczas pierwszych kilkunastu godzin buntu Jewgienija Prigożyna - przekazuje we wtorek &quot;Washington Post&quot;, powołując się na zachodnie i ukraińskie źródła wywiadowcze. Dziennik podaje, że Putin wiedział o planowanym buncie na co najmniej dwa dni przed jego wybuchem, lecz nie zrobił nic, by go powstrzymać.

## Żaryn: Królewiec najsilniej odczuwa zachodnie sankcje nałożone na reżim w Moskwie
 - [https://forsal.pl/gospodarka/polityka/artykuly/8956780,zaryn-krolewiec-najsilniej-odczuwa-zachodnie-sankcje-nalozone-na-rezi.html](https://forsal.pl/gospodarka/polityka/artykuly/8956780,zaryn-krolewiec-najsilniej-odczuwa-zachodnie-sankcje-nalozone-na-rezi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T14:55:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dwjktkuTURBXy8yYzRlNWM2Zi1hNjE0LTQ1NDYtYTdmMi04ZjY5NjFkZjJlY2MuanBlZ5GTBc0BHcyg" />Królewiec najsilniej odczuwa zachodnie sankcje nałożone na reżim w Moskwie - napisał w InfoAlercie na Twitterze pełnomocnik rządu ds. bezpieczeństwa przestrzeni informacyjnej RP Stanisław Żaryn. Nie potrafi tego zatuszować nawet rosyjska propaganda - dodał.

## Polacy od doby koczują na lotnisku w Rodos. Nie wiedzą, kiedy wrócą
 - [https://forsal.pl/transport/lotnictwo/artykuly/8956616,polacy-od-doby-koczuja-na-lotnisku-w-rodos-nie-wiedza-kiedy-wroca.html](https://forsal.pl/transport/lotnictwo/artykuly/8956616,polacy-od-doby-koczuja-na-lotnisku-w-rodos-nie-wiedza-kiedy-wroca.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T14:45:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fagktkuTURBXy9jOWIzMzNlNi04NDNjLTQ0NTEtYTk3Ni1iNTJiNWU3Njc5YWEuanBlZ5GTBc0BHcyg" />Od doby na lotnisku w Rodos koczują turyści, którzy w poniedziałek zakończyli wakacje i po południu mieli odlecieć do kraju. &quot;Do Polski przewieziono osoby, które ewakuowano z innych miast, a o tych, którzy planowo mieli powrócić do kraju zapomniano&quot; - powiedziała PAP pani Agnieszka, która od doby koczuje na lotnisku z nastoletnim synem.

## Mrożonki pod lupą inspektorów. Oto, co pokazała kontrola
 - [https://forsal.pl/biznes/handel/artykuly/8956414,mrozonki-pod-lupa-inspektorow-oto-co-pokazala-kontrola.html](https://forsal.pl/biznes/handel/artykuly/8956414,mrozonki-pod-lupa-inspektorow-oto-co-pokazala-kontrola.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T14:31:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CupktkuTURBXy82MmFiZWJjZC0xNGQxLTQ0MDYtOTA0Zi04MWU3NDM4NjA2ZDMuanBlZ5GTBc0BHcyg" />Ponad 300 sprawdzonych pojazdów typu chłodnia i niemal bez zastrzeżeń. Tylko w jednym przypadku międzynarodowy transport mrożonek był wykonywany bez certyfikatu ATP - poinformowała po kontroli Inspekcja Transportu Drogowego.

## Marcin Chodkowski został powołany na prezesa EC Będzin z dniem 26 lipca
 - [https://forsal.pl/finanse/gielda/artykuly/8956338,marcin-chodkowski-zostal-powolany-na-prezesa-ec-bedzin-z-dniem-26-lipc.html](https://forsal.pl/finanse/gielda/artykuly/8956338,marcin-chodkowski-zostal-powolany-na-prezesa-ec-bedzin-z-dniem-26-lipc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T14:26:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zn1ktkuTURBXy8yN2U3OTYxYS0wNWVmLTRmYzctOTgwNC1mZjkyOWJkYjkyZTkuanBlZ5GTBc0BHcyg" />undefined

## S&amp;P Global Ratings podtrzymał rating MOL na poziomie BBB-
 - [https://forsal.pl/finanse/gielda/artykuly/8956307,sp-global-ratings-podtrzymal-rating-mol-na-poziomie-bbb.html](https://forsal.pl/finanse/gielda/artykuly/8956307,sp-global-ratings-podtrzymal-rating-mol-na-poziomie-bbb.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T14:24:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7tQktkuTURBXy85YTc1MGVlNi0yNzJkLTRkNWEtYTJmMC03ZjI2ZGEzMTBiODIuanBlZ5GTBc0BHcyg" />undefined

## Akcjonariusze Echo zgodzili się na wniesienie segmentu mieszkaniowego do Archicomu
 - [https://forsal.pl/finanse/gielda/artykuly/8956270,akcjonariusze-echo-zgodzili-sie-na-wniesienie-segmentu-mieszkaniowego.html](https://forsal.pl/finanse/gielda/artykuly/8956270,akcjonariusze-echo-zgodzili-sie-na-wniesienie-segmentu-mieszkaniowego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T14:22:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bfEktkuTURBXy81MTY0NTc4MS01MDE0LTRjYjMtOTk0MS1kYjRiNDVjN2E3MjYuanBlZ5GTBc0BHcyg" />undefined

## Komu z polityków Polacy ufają najbardziej? [SONDAŻ]
 - [https://forsal.pl/gospodarka/polityka/artykuly/8956166,komu-z-politykow-polacy-ufaja-najbardziej-sondaz.html](https://forsal.pl/gospodarka/polityka/artykuly/8956166,komu-z-politykow-polacy-ufaja-najbardziej-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T14:15:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LG0ktkuTURBXy85ZmMxZmIwNi0yM2NiLTRjNTUtYWQyYS1lOGZiNWMwNmJmNmYuanBlZ5GTBc0BHcyg" />Prezydent Andrzej Duda, prezydent Warszawy Rafał Trzaskowski, prezes PSL Władysław Kosiniak-Kamysz to liderzy lipcowego rankingu zaufania polityków. Największą nieufność ankietowani wyrażają wobec: Jarosława Kaczyńskiego, Zbigniewa Ziobry i Donalda Tuska.

## Rosyjski myśliwiec uszkodził amerykańskiego drona nad Syrią
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8956020,rosyjski-mysliwiec-uszkodzil-amerykanskiego-drona-nad-syria.html](https://forsal.pl/swiat/aktualnosci/artykuly/8956020,rosyjski-mysliwiec-uszkodzil-amerykanskiego-drona-nad-syria.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T14:02:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fEnktkuTURBXy80Mjg2NWY5Yy1hMTk1LTQzNTctODQyYS1mNzc5YjY5YTlmMGMuanBlZ5GTBc0BHcyg" />Amerykański dron MQ-9, wykonujący misję przeciwko Państwu Islamskiemu w Syrii, został w niedzielę uszkodzony przez rosyjski myśliwiec Su-35, który wystrzelił w jego kierunku flary - podało we wtorek Dowództwo Centralne Sił Powietrznych USA (AFCENT). Mimo uszkodzeń pilotom udało się ściągnąć maszynę do bazy.

## MFW podwyższył prognozę wzrostu PKB Polski w 2023 r.
 - [https://forsal.pl/gospodarka/pkb/artykuly/8960860,mfw-podwyzszyl-prognoze-wzrostu-pkb-polski-w-2023-r.html](https://forsal.pl/gospodarka/pkb/artykuly/8960860,mfw-podwyzszyl-prognoze-wzrostu-pkb-polski-w-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T13:50:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QUjktkuTURBXy8yOTE5MWYzYy0zMjliLTQ0MjktYWM4Zi03OGFmMWVjZGM3ZGEuanBlZ5GTBc0BHcyg" />undefined

## 5 tys. zł mandatu i utrata prawa jazdy. Wzmożone kontrole z okazji Dnia Bezpiecznego Kierowcy
 - [https://forsal.pl/transport/drogi/artykuly/8955315,5-tys-zl-mandatu-i-utrata-prawa-jazdy-wzmozone-kontrole-z-okazji-dni.html](https://forsal.pl/transport/drogi/artykuly/8955315,5-tys-zl-mandatu-i-utrata-prawa-jazdy-wzmozone-kontrole-z-okazji-dni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T13:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SOrktkuTURBXy8xYjE3OTlmMy1jYWMzLTRmZDAtOGNlNC1iNTQ0ZWQ5ODA4ZWIuanBlZ5GTBc0BHcyg" />Z okazji Dnia Bezpiecznego Kierowcy policja rozpoczęła wzmożone kontrole kierowców oraz stanu technicznego ich aut. Przekraczanie dozwolonej prędkości, a w dodatku niesprawny samochód? Uważaj, spotkanie z drogówką może kosztować cię utratę prawa jazdy, odholowanie pojazdu i 30 tys. grzywny nałożonej przez sąd.

## Reforma planowania przestrzennego. Prezydent podpisał nowelizację przepisów
 - [https://forsal.pl/gospodarka/prawo/artykuly/8955732,reforma-planowania-przestrzennego-prezydent-podpisal-nowelizacje-prze.html](https://forsal.pl/gospodarka/prawo/artykuly/8955732,reforma-planowania-przestrzennego-prezydent-podpisal-nowelizacje-prze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T13:39:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/o2wktkuTURBXy82ZWQ1ZWU4OS02NTZlLTQ0NzgtYjZlYy04YjNjYWY3OWM4Y2UuanBlZ5GTBc0BHcyg" />undefined

## Gwałtowna burza w Berlinie i Brandenburgii. Są osoby ranne
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8955593,gwaltowna-burza-w-berlinie-i-brandenburgii-sa-osoby-ranne.html](https://forsal.pl/swiat/aktualnosci/artykuly/8955593,gwaltowna-burza-w-berlinie-i-brandenburgii-sa-osoby-ranne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T13:29:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6XlktkuTURBXy8wYjI5OTJiZC04OTUzLTRmZWUtODJlMC02OWYzZGU3NWEyZDguanBlZ5GTBc0BHcyg" />Trzy osoby zostały ranne w Berlinie i trzy w południowej Brandenburgii podczas gwałtownej burzy, która przeszła nad tym regionem Niemiec w poniedziałek wieczorem - informuje we wtorek portal rbb24.

## Marczuk z PFR: Liczba uczestników PPK przekroczyła 3,3 mln
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8955154,marczuk-z-pfr-liczba-uczestnikow-ppk-przekroczyla-33-mln.html](https://forsal.pl/finanse/aktualnosci/artykuly/8955154,marczuk-z-pfr-liczba-uczestnikow-ppk-przekroczyla-33-mln.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T12:52:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/03xktkuTURBXy9hZTdjNThhOS1mNmFlLTRjMTEtYjc1Mi1lNjlhMmU5MGVhZTUuanBlZ5GTBc0BHcyg" />undefined

## Zmiana na stanowisku szefa chińskiego Ministerstwa Spraw Zagranicznych
 - [https://forsal.pl/swiat/chiny/artykuly/8955146,zmiana-na-stanowisku-szefa-chinskiego-ministerstwa-spraw-zagranicznych.html](https://forsal.pl/swiat/chiny/artykuly/8955146,zmiana-na-stanowisku-szefa-chinskiego-ministerstwa-spraw-zagranicznych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T12:35:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wwXktkuTURBXy8wNjI3NDZmMS03ZTdmLTRkM2YtOTJjOS0yNDMxNzA2NjkwZDUuanBlZ5GTBc0BHcyg" />Qin Gang, który od miesiąca nie był widziany publicznie, został usunięty ze stanowiska ministra spraw zagranicznych Chin. Zastąpi go Wanga Yi, dotychczasowy dyrektor Biura Centralnej Komisji Spraw Zagranicznych Komunistycznej Partii Chin (KPCh) i były szef resortu dyplomacji – poinformowała we wtorek chińska agencja informacyjna Xinhua.

## Polscy turyści będą ewakuowani z Rodos rządowymi samolotami?
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8955121,polscy-turysci-beda-ewakuowani-z-rodos-rzadowymi-samolotami.html](https://forsal.pl/lifestyle/turystyka/artykuly/8955121,polscy-turysci-beda-ewakuowani-z-rodos-rzadowymi-samolotami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T12:28:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-8BktkuTURBXy9hNWFmZmMzMi1mMDg3LTQyNzYtOWUxOS00ZTg0MmM1OTE4ZGEuanBlZ5GTBc0BHcyg" />Na dziś biura nie zgłosiły potrzeby interwencji MSiT w proces organizacji powrotu polskich turystów do kraju. Jeżeli taka potrzeba nastąpi, jesteśmy gotowi użyć do tego procesu samolotów pozostających w dyspozycji rządu RP - napisał we wtorek na Twitterze minister sportu i turystyki Kamil Bortniczuk.

## Pomoc makrofinansowa dla Ukrainy. Komisja Europejska wypłaciła 1,5 mld euro
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8954731,pomoc-makrofinansowa-dla-ukrainy-komisja-europejska-wyplacila-15-mld.html](https://forsal.pl/swiat/unia-europejska/artykuly/8954731,pomoc-makrofinansowa-dla-ukrainy-komisja-europejska-wyplacila-15-mld.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T11:53:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/e5_ktkuTURBXy8yZWU1MDQ4ZC02NTljLTRkNDMtYmU0Mi1lZTM5NjllYzg2ZWMuanBlZ5GTBc0BHcyg" />Komisja Europejska wypłaciła we wtorek szóstą transzę w wysokości 1,5 mld euro w ramach pakietu unijnej pomocy makrofinansowej dla Ukrainy o wartości do 18 mld euro.

## Europa przygotowana na kryzys w dostawach półprzewodników? UE zatwierdziła akt o czipach
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8954624,europa-przygotowana-na-kryzys-w-dostawach-polprzewodnikow-ue-zatwierd.html](https://forsal.pl/biznes/aktualnosci/artykuly/8954624,europa-przygotowana-na-kryzys-w-dostawach-polprzewodnikow-ue-zatwierd.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T11:45:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nzQktkuTURBXy83NDY3MzAwNi1kZWNjLTQwNGItYWQyNS01NDEwYTkyZWY4YTEuanBlZ5GTBc0BHcyg" />Unia Europejska zatwierdziła we wtorek rozporządzenie wzmacniające europejski ekosystem półprzewodników, znane jako „akt w sprawie czipów”. Ma stworzyć warunki do rozwoju europejskiej bazy przemysłowej półprzewodników, przyciągnąć inwestycje, promować badania naukowe i innowacje oraz przygotować Europę na wszelkie przyszłe kryzysy w zakresie dostaw czipów.

## Atak Rosji na ukraiński port na Dunaju. Cena pszenicy najwyższa od pięciu miesięcy
 - [https://forsal.pl/gospodarka/artykuly/8953206,atak-rosji-na-ukrainski-port-na-dunaju-cena-pszenicy-najwyzsza-od-pie.html](https://forsal.pl/gospodarka/artykuly/8953206,atak-rosji-na-ukrainski-port-na-dunaju-cena-pszenicy-najwyzsza-od-pie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T11:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1N1ktkuTURBXy8zZDZmNDFmMi1mNjE3LTQ3M2MtOGYzNy0zOWYyYmY1ZmRjMzYuanBlZ5GTBc0BHcyg" />Rosja zaatakowała port na Dunaju w Ukrainie, a pszenica podrożała do najwyższego poziomu od pięciu miesięcy. Po wycofaniu się z umowy zbożowej Moskwa intensyfikuje natarcia w celu sparaliżowania ważnego eksportowego szlaku ukraińskiego zboża na światowe rynki.

## Co to jest recesja?
 - [https://forsal.pl/gospodarka/artykuly/8953808,co-to-jest-recesja.html](https://forsal.pl/gospodarka/artykuly/8953808,co-to-jest-recesja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T10:43:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NwXktkuTURBXy81NGJmMTdlMC0wYTg1LTRiODMtYThlOC03MGQwNTgxOWVhZTkuanBlZ5GTBc0BHcyg" />Recesja to przeciwieństwo wzrostu gospodarczego. Termin ten opisuje okres ekonomiczny charakteryzujący się spadkiem aktywności gospodarczej w kraju lub regionie przez dłuższy czas. Podczas recesji spada produkcja, obroty handlowe, zatrudnienie, a także widoczny jest wzrost cen.

## W 2075 roku jedna trzecia osób w wieku produkcyjnym będzie pochodziła z Afryki
 - [https://forsal.pl/gospodarka/demografia/artykuly/8953564,w-2075-roku-jedna-trzecia-osob-w-wieku-produkcyjnym-bedzie-pochodzila.html](https://forsal.pl/gospodarka/demografia/artykuly/8953564,w-2075-roku-jedna-trzecia-osob-w-wieku-produkcyjnym-bedzie-pochodzila.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T10:25:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WevktkuTURBXy9lM2M4Mjk0YS1hMTM5LTRmOGItYjI0My1hNjQ3YjI0NDgwYjguanBlZ5GTBc0BHcyg" />Do 2075 r. jedną trzecią światowej populacji osób w wieku produkcyjnym będą stanowić Afrykanie - powiedział przedstawiciel Banku Światowego Nathan Belete, otwierając szczyt Youth Side Event w Dar Es Salam w Tanzanii poświęcony kapitałowi ludzkiemu w Afryce - podaje serwis dailynews.

## Choroba w trakcie urlopu. Masz prawo pójść do dowolnej przychodni bez skierowania
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8953504,choroba-w-trakcie-urlopu-masz-prawo-pojsc-do-dowolnej-przychodni-bez.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8953504,choroba-w-trakcie-urlopu-masz-prawo-pojsc-do-dowolnej-przychodni-bez.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T10:21:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MbSktkuTURBXy9lYmQ1MzY0My1iNWI0LTQzNWMtYTQzZi05YTJjZTAxNDJhZDMuanBlZ5GTBc0BHcyg" />Nawet gdy jesteśmy na urlopie daleko od domu, mamy prawo do opieki medycznej. Każdy, kto posiada ubezpieczenie zdrowotne, może zgłosić się w ramach POZ w dowolnej przychodni do lekarza rodzinnego. Bez skierowania – przypomina NFZ.

## Selena FM ma warunkową umowę przejęcia 50 proc. węgierskiej Pimco za wkład maks. 10 mln euro
 - [https://forsal.pl/finanse/gielda/artykuly/8953399,selena-fm-ma-warunkowa-umowe-przejecia-50-proc-wegierskiej-pimco-za-w.html](https://forsal.pl/finanse/gielda/artykuly/8953399,selena-fm-ma-warunkowa-umowe-przejecia-50-proc-wegierskiej-pimco-za-w.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T10:14:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />undefined

## Bezpieczny Kredyt 2 proc. w praktyce. Ile osób skorzystało?
 - [https://forsal.pl/biznes/bankowosc/artykuly/8953354,bezpieczny-kredyt-2-proc-w-praktyce-ile-osob-skorzystalo.html](https://forsal.pl/biznes/bankowosc/artykuly/8953354,bezpieczny-kredyt-2-proc-w-praktyce-ile-osob-skorzystalo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T10:11:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bs-ktkuTURBXy80ZGYyNjBiMS01YzgzLTQzMGItOWI3Mi1kNWI5YjQ1ZmRmZmYuanBlZ5GTBc0BHcyg" />undefined

## Uwaga na burze z gradem i silnym wiatrem. To te województwa są najbardziej zagrożone
 - [https://forsal.pl/lifestyle/artykuly/8953230,uwaga-na-burze-z-gradem-i-silnym-wiatrem-to-te-wojewodztwa-sa-najbard.html](https://forsal.pl/lifestyle/artykuly/8953230,uwaga-na-burze-z-gradem-i-silnym-wiatrem-to-te-wojewodztwa-sa-najbard.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T10:01:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NtAktkuTURBXy8xODc5ZDVlYi1lMGZiLTQ1NjQtODU1OC0zMWI4MGU4NjMxYjIuanBlZ5GTBc0BHcyg" />Rządowe Centrum Bezpieczeństwa ostrzega przed burzami z gradem i silnym wiatrem. Które części kraju czekają największe anomalie pogodowe?

## Urlop w spalonym hotelu, ale ze zniżką. Biura turystyczne wciąż wysyłają klientów na Rodos
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8953188,urlop-w-spalonym-hotelu-ale-ze-znizka-biura-turystyczne-wciaz-wysyla.html](https://forsal.pl/biznes/aktualnosci/artykuly/8953188,urlop-w-spalonym-hotelu-ale-ze-znizka-biura-turystyczne-wciaz-wysyla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T09:15:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/emIktkuTURBXy9iOGVhM2U5NC0zYjZiLTRhNGQtYTE2ZC00NmRmYWRmNjFiNmUuanBlZ5GTBc0BHcyg" />Mimo trwającej ewakuacji turystów z ogarniętej ogromnymi pożarami greckiej wyspy Rodos, niektóre linie lotnicze i biura turystyczne nadal wysyłają na nią kolejnych, a nawet oferują zniżki na pobyt w uszkodzonych przez ogień hotelach - pisze we wtorek brytyjski dziennik &quot;i&quot;.

## Trudna sytuacja na rynku malin. Zmowa cenowa? Jest opinia UOKiK
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8953114,trudna-sytuacja-na-rynku-malin-zmowa-cenowa-jest-opinia-uokik.html](https://forsal.pl/biznes/aktualnosci/artykuly/8953114,trudna-sytuacja-na-rynku-malin-zmowa-cenowa-jest-opinia-uokik.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T09:09:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_ElktkuTURBXy84ZjhjMjJmNy01MDIwLTQxNjEtYTZhOC00MjkxODM0ODk5M2UuanBlZ5GTBc0BHcyg" />Brak jest podstaw do twierdzeń, że trudna sytuacja na rynku malin może być wynikiem zmowy cenowej skupów lub przetwórców - wskazał we wtorek Urząd Ochrony Konkurencji i Konsumentów, który przedstawił wyniki kontroli w blisko 60 skupach i u pięciu największych przetwórców.

## Płonie nie tylko grecka Rodos, ale też włoska Sycylia. Upały na wyspie sięgają 47 stopni
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8952977,plonie-nie-tylko-grecka-rodos-ale-tez-wloska-sycylia-upaly-na-wyspie.html](https://forsal.pl/swiat/aktualnosci/artykuly/8952977,plonie-nie-tylko-grecka-rodos-ale-tez-wloska-sycylia-upaly-na-wyspie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T08:56:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XgqktkuTURBXy80ZjRmMzZjNy03YmQ3LTRiMDgtYWRiMi05NjZhMDZhZjkwYTguanBlZ5GTBc0BHcyg" />55 pożarów trwa na Sycylii - podała we wtorek Ansa. Najwięcej wybuchło w rejonie Palermo. Gaszenie ognia przez śmigłowce utrudnia silny wiatr - scirocco. Na wyspie utrzymują się rekordowe upały, sięgające 47 stopni.

## Koronawirus w Polsce: 12 zakażeń, jedna osoba zmarła [DANE Z 25.07]
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-12-zakazen-jedna-osoba-zmarla-dane-z-2507.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-12-zakazen-jedna-osoba-zmarla-dane-z-2507.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T08:33:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 12 zakażeń koronawirusem, w tym trzy ponowne. Z powodu COVID-19 zmarł jeden pacjent – poinformowano we wtorek na stronach rządowych. Wykonano 659 testów w kierunku SARS-CoV-2. W tygodniu (od 22 do 28 czerwca) było o ponad 16 proc. zakażeń mniej niż tydzień wcześniej.

## Koniec sieci 3G. Na kiedy operatorzy zaplanowali jej wyłączanie?
 - [https://forsal.pl/lifestyle/technologie/artykuly/8952952,koniec-sieci-3g-na-kiedy-operatorzy-zaplanowali-jej-wylaczanie.html](https://forsal.pl/lifestyle/technologie/artykuly/8952952,koniec-sieci-3g-na-kiedy-operatorzy-zaplanowali-jej-wylaczanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T08:28:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mfyktkuTURBXy8yOTk3YmU0Yy1lNDM5LTRiZWYtOWQ0NC0xOTdjMzgyNWE5MjMuanBlZ5GTBc0BHcyg" />undefined

## Bezrobocie w Polsce nieznacznie spada. Dane GUS
 - [https://forsal.pl/praca/bezrobocie/artykuly/8952878,bezrobocie-w-polsce-nieznacznie-spada-dane-gus.html](https://forsal.pl/praca/bezrobocie/artykuly/8952878,bezrobocie-w-polsce-nieznacznie-spada-dane-gus.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T08:10:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/d05ktkuTURBXy9mMDA3Y2NlMy0wMzc2LTQ2MTMtYjU3OC01ZWMzNzE3NDQ1YTguanBlZ5GTBc0BHcyg" />undefined

## Jeszcze przed wojną wyzwaniem dla Ukrainy była demografia. Co się stanie, jeśli Ukrainki nie wrócą do kraju?
 - [https://forsal.pl/gospodarka/demografia/artykuly/8952369,jeszcze-przed-wojna-wyzwaniem-dla-ukrainy-byla-demografia-co-sie-stan.html](https://forsal.pl/gospodarka/demografia/artykuly/8952369,jeszcze-przed-wojna-wyzwaniem-dla-ukrainy-byla-demografia-co-sie-stan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T07:17:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/y27ktkuTURBXy8wYTkxM2M5ZC0zZGIxLTQwZDYtODU3NC0zZTQyZjUwNDc0OWEuanBlZ5GTBc0BHcyg" />Blisko 70 procent uchodźców z Ukrainy to kobiety, a zdaniem analityka agencji Bloomberga Aleksandra Isakowa, jeśli 2,8 mln kobiet w wieku produkcyjnym, które opuściły Ukrainę, nie powróci do niej po wojnie, będzie to kosztować kraj 10 proc. przedwojennego PKB.

## Umowa zbożowa zerwana z winy Zachodu, Rosja zastąpi ukraińskie zboże... Putin pisze artykuł
 - [https://forsal.pl/swiat/rosja/artykuly/8951839,umowa-zbozowa-zerwana-z-winy-zachodu-rosja-zastapi-ukrainskie-zboze.html](https://forsal.pl/swiat/rosja/artykuly/8951839,umowa-zbozowa-zerwana-z-winy-zachodu-rosja-zastapi-ukrainskie-zboze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T06:34:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/r-pktkuTURBXy9iZDdkYmVlYy1jZTNiLTQwZTUtOTUwMC03MDY1ODUzOWU1OGEuanBlZ5GTBc0BHcyg" />Artykuł Putina, poświęcony współpracy Rosji z Afryką, ma na celu zniwelowanie jego strat wizerunkowych w tym regionie – pisze Instytut Badań nad Wojną. Ścigany listem gończym przez Międzynarodowy Trybunał Karny rosyjski prezydent twierdzi, że umowa zbożowa została zerwana z winy Zachodu, a Rosja może zastąpić ukraińskie zboże na światowym rynku.

## Kursy walut: Złoty we wtorek rano stracił wobec euro, dolara i franka
 - [https://forsal.pl/finanse/waluty/artykuly/8951465,kursy-walut-zloty-we-wtorek-rano-stracil-wobec-euro-dolara-i-franka.html](https://forsal.pl/finanse/waluty/artykuly/8951465,kursy-walut-zloty-we-wtorek-rano-stracil-wobec-euro-dolara-i-franka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T06:09:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qJuktkuTURBXy84OGVlN2Y5ZC1jMzY1LTQ5M2ItYjY1NC03ZDdkNmIzODhhZDYuanBlZ5GTBc0BHcyg" />We wtorek rano polska waluta straciła na wartości wobec euro, franka szwajcarskiego i dolara amerykańskiego. Euro kosztowało 4,45 zł, frank szwajcarski 4,62 zł, a dolar – 4,02 zł.

## Recesja puka do drzwi Europy
 - [https://forsal.pl/gospodarka/pkb/artykuly/8941167,recesja-puka-do-drzwi-europy.html](https://forsal.pl/gospodarka/pkb/artykuly/8941167,recesja-puka-do-drzwi-europy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T06:02:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9VLktkuTURBXy85YWU4ZmI4Zi01Y2Q1LTQ0YzktYWIxZS1mOWZkNmZiZTBkNjAuanBlZ5GTBc0BHcyg" />Najnowsze badanie menedżerów prywatnych firm przemysłowych i usługowych pokazuje umocnienie niekorzystnych trendów w największych europejskich gospodarkach

## Nocny atak na Kijów: Zestrzelono wszystkie drony
 - [https://forsal.pl/swiat/ukraina/artykuly/8951411,nocny-atak-na-kijow-zestrzelono-wszystkie-drony.html](https://forsal.pl/swiat/ukraina/artykuly/8951411,nocny-atak-na-kijow-zestrzelono-wszystkie-drony.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T05:59:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mNJktkuTURBXy9iNGExODQ5OC1iN2M4LTRmMTgtOWY5MC1kMDliNzgyMDU0YmEuanBlZ5GTBc0BHcyg" />Wszystkie drony przeciwnika, które w nocy atakowały Kijów, zostały zestrzelone przez obronę powietrzną – powiadomiły władze ukraińskiej stolicy we wtorek rano.

## Solidne wzrosty na Wall Street. Dow jedenasty dzień w górę
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8951280,solidne-wzrosty-na-wall-street-dow-jedenasty-dzien-w-gore.html](https://forsal.pl/biznes/aktualnosci/artykuly/8951280,solidne-wzrosty-na-wall-street-dow-jedenasty-dzien-w-gore.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T05:50:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u3ektkuTURBXy8xOGZkMzMxYS03N2E0LTQxMzctODA2Zi0xMTVmNTUwMjhjYmQuanBlZ5GTBc0BHcyg" />Poniedziałkowa sesja na Wall Street zakończyła się solidnymi wzrostami głównych indeksów, a Dow zanotował już jedenasty wzrostowy dzień z rzędu. W centrum uwagi są zaplanowane na ten tydzień posiedzenie Fed oraz wyniki kwartalne dużych firm, w tym technologicznych Meta, Microsoft i Alphabet.

## Alarm lotniczy w Kijowie. Zagrożenie wrogim atakiem utrzymuje się w centrum oraz na północy Ukrainy
 - [https://forsal.pl/swiat/ukraina/artykuly/8951218,alarm-lotniczy-w-kijowie-zagrozenie-wrogim-atakiem-utrzymuje-sie-w-ce.html](https://forsal.pl/swiat/ukraina/artykuly/8951218,alarm-lotniczy-w-kijowie-zagrozenie-wrogim-atakiem-utrzymuje-sie-w-ce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T05:46:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GI-ktkuTURBXy80NjlhZjg2Ny05ZmEwLTRhOTItYWUyNS1iODE0ZjEzMzI5MGQuanBlZ5GTBc0BHcyg" />W Kijowie ogłoszono w nocy z poniedziałku na wtorek alarm lotniczy - poinformowały ukraińskie media. Siły zbrojne Ukrainy podały, że w regionie działają jednostki obrony powietrznej.

## USA nakładają sankcje na ministra obrony Mali za współpracę z Grupą Wagnera
 - [https://forsal.pl/swiat/usa/artykuly/8951149,usa-nakladaja-sankcje-na-ministra-obrony-mali-za-wspolprace-z-grupa-wa.html](https://forsal.pl/swiat/usa/artykuly/8951149,usa-nakladaja-sankcje-na-ministra-obrony-mali-za-wspolprace-z-grupa-wa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T05:42:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XrZktkuTURBXy9kYTY0ZDE5Ni03NDMyLTQxNTQtYWE5YS1hOTFkZGJmNzVlNDUuanBlZ5GTBc0BHcyg" />Administracja USA ogłosiła w poniedziałek sankcje przeciwko ministrowi obrony Mali oraz dwóm malijskim dowódcom za współpracę z Grupą Wagnera i prace na rzecz jej ekspansji w tym kraju. Według Departamentu Stanu, odkąd wagnerowcy pojawili się w Mali, liczba ofiar cywilnych operacji wojskowych wzrosła o 278 proc.

## Polscy freelancerzy się bogacą. Jak w tym roku wzrosły ich stawki?
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8951091,polscy-freelancerzy-sie-bogaca-jak-w-tym-roku-wzrosly-ich-stawki.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8951091,polscy-freelancerzy-sie-bogaca-jak-w-tym-roku-wzrosly-ich-stawki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T05:38:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9-MktkuTURBXy9mYmNmMDFlZC0yN2IyLTRkZWQtOThhMi05MWIyZmY2ZmY4OGIuanBlZ5GTBc0BHcyg" />Najbardziej urosły zarobki freelancerów zajmujących się animacją, a zmalały specjalistów od programowania i tworzenia sklepów internetowych - wynika z raportu &quot;Stawki freelancerów – w których branżach w I połowie 2023 r. wzrosły najbardziej?&quot;. Dodano, że średni ich wzrost to ok. 25 proc. rdr.

## Duży wzrost emigracji do Turcji. Najliczniej wybywają tam Rosjanie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8950997,duzy-wzrost-emigracji-do-turcji-najliczniej-wybywaja-tam-rosjanie.html](https://forsal.pl/swiat/aktualnosci/artykuly/8950997,duzy-wzrost-emigracji-do-turcji-najliczniej-wybywaja-tam-rosjanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T05:31:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/krmktkuTURBXy9kNzJjN2Q4MC01MGY5LTRkYWEtODMxNy00YWMyYTY5OWE2ZDAuanBlZ5GTBc0BHcyg" />W 2022 roku odnotowano wzrost emigracji z Turcji o 62 proc. w porównaniu z rokiem poprzednim. Rosjanie byli w ubiegłym roku najliczniejszym narodem imigrującym do Turcji - wynika z opublikowanych w poniedziałek danych Tureckiego Instytutu Statystycznego (TUIK).

## Rosyjskie zakupy w Chinach. Kamizelki kuloodporne, hełmy, drony...
 - [https://forsal.pl/swiat/rosja/artykuly/8950939,rosyjskie-zakupy-w-chinach-kamizelki-kuloodporne-helmy-drony.html](https://forsal.pl/swiat/rosja/artykuly/8950939,rosyjskie-zakupy-w-chinach-kamizelki-kuloodporne-helmy-drony.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T05:27:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/izCktkuTURBXy8wZjdmYzEyMy00OTUwLTQ2NjgtYTJiYi0yNGVkYjY2OGU4NzkuanBlZ5GTBc0BHcyg" />Firmy w Rosji importują setki tysięcy kamizelek kuloodpornych, hełmów, a także znaczne ilości celowników termowizyjnych i dronów z Chin - podaje portal Politico. Sprzęt jest sprowadzany jako dobra cywilnego przeznaczenia.

## Początek ery reshoringu?
 - [https://forsal.pl/gospodarka/artykuly/8875602,poczatek-ery-reshoringu.html](https://forsal.pl/gospodarka/artykuly/8875602,poczatek-ery-reshoringu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZnuktkuTURBXy9iYjI1NDJhNS1hZWY3LTQyMTUtYjEyMS04NTBhMDViZDEyZmMuanBlZ5GTBc0BHcyg" />Zachodnie firmy przenoszą część produkcji z Chin do innych państw – tańszych lub uznanych za bardziej bezpieczne. Zdarzają się też powroty do krajów macierzystych, lecz nie na masową skalę.

## Tesla poświęciła zyski na rzecz walki o rynkowy udział. Rekordowe dostawy
 - [https://forsal.pl/motoforsal/artykuly/8934988,tesla-poswiecila-zyski-na-rzecz-walki-o-rynkowy-udzial-rekordowe-dost.html](https://forsal.pl/motoforsal/artykuly/8934988,tesla-poswiecila-zyski-na-rzecz-walki-o-rynkowy-udzial-rekordowe-dost.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jxnktkuTURBXy82NGYxYzFhZC02ZjA5LTQwNjItODY3MS0yZGQzOTI4OGFiZDAuanBlZ5GTBc0BHcyg" />Tesla realizuję długoterminową strategię zwiększania rynkowego udziału kosztem zysków. Marża zysku brutto firmy drastycznie spadła - pisze Statista.

## To nie koniec wojny cenowej. Producenci samochodów w Chinach nie osiągają celów sprzedaży
 - [https://forsal.pl/motoforsal/motobiznes/artykuly/8937568,to-nie-koniec-wojny-cenowej-producenci-samochodow-w-chinach-nie-osiag.html](https://forsal.pl/motoforsal/motobiznes/artykuly/8937568,to-nie-koniec-wojny-cenowej-producenci-samochodow-w-chinach-nie-osiag.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aBOktkuTURBXy81MGEyOTAzZi02NDIxLTQwOWQtYjM0ZS0zNjNlZTRiOWI3YjIuanBlZ5GTBc0BHcyg" />Najlepsi chińscy producenci samochodów nie osiągają swoich celów sprzedaży. To sugeruje, że wojna cenowa, w którą uwikłał się na największy rynek samochodowy na świecie w pierwszej połowie roku, będzie się utrzymywać, ponieważ producenci ścigają się, by osiągnąć swoje cele.

## Transport ukraińskiego zboża jest uzależniony od rzeki, która wysycha podczas suszy
 - [https://forsal.pl/swiat/ukraina/artykuly/8936536,transport-ukrainskiego-zboza-jest-uzalezniony-od-rzeki-ktora-wysycha.html](https://forsal.pl/swiat/ukraina/artykuly/8936536,transport-ukrainskiego-zboza-jest-uzalezniony-od-rzeki-ktora-wysycha.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FxMktkuTURBXy9mMWZiNmI0MS1jMWM2LTQ0MzktYWUwNC0yZmZiMTQyOGE3YWMuanBlZ5GTBc0BHcyg" />Groźba rosyjskich ataków na ukraińskie porty i statki ze zbożem na Morzu Czarnym zmusi Ukraińców do eksportu ogromnych ilości ziarna drogą rzeczną, drogową i kolejową. Wszystkie alternatywne dla Morza Czarnego drogi są jednak pełne wyzwań.

## Niespodziewane skutki akcji "Stop NOP"
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8941189,niespodziewane-skutki-akcji-stop-nop.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8941189,niespodziewane-skutki-akcji-stop-nop.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-07-25T00:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/B_zktkuTURBXy9iNGU5MzMzOC03OTNiLTQyZjktODUyZS1hMTRhYTliZDYzMzUuanBlZ5GTBc0BHcyg" />Polacy częściej walczą o odszkodowania za szczepienia po COVID-19 niż za te obowiązkowe

