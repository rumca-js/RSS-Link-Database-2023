# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Red Hat Freeloaders Tried Submitting To RHEL
 - [https://www.youtube.com/watch?v=k_60vvh9fG4](https://www.youtube.com/watch?v=k_60vvh9fG4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2023-07-25T21:00:34+00:00

We've had too much serious Red Hat and RHEL stuff recently so let's talk about a situation that didn't even remotely need to happen if people from Red Hat just communicated there perspective.

==========Support The Channel==========
► $100 Linode Credit: https://brodierobertson.xyz/linode
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Red Hat Gitlab: https://gitlab.com/redhat/centos-stream/rpms/iperf3/-/merge_requests/
Red Hat CVE: https://access.redhat.com/security/cve/CVE-2023-38403
Red Hat Bugzilla: https://bugzilla.redhat.com/show_bug.cgi?id=2223729

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson.xyz/discord
🎤 Matrix Space: https://brodierobertson.xyz/matrix
🐦 Twitter: https://brodierobertson.xyz/twitter
🌐 Mastodon: https://brodierobertson.xyz/mastodon
🖥️ GitHub: https://brodierobertson.xyz/github

==========Credits==========
🎨 Channel Art:
Profile Picture:
https://www.instagram.com/supercozman_draws/

🎵 Ending music
Track: Debris & Jonth - Game Time [NCS Release]
Music provided by NoCopyrightSounds.
Watch:  https://www.youtube.com/watch?v=yDTvvOTie0w 
Free Download / Stream: http://ncs.io/GameTime

#RedHat #RHEL #Linux #OpenSource #FOSS

DISCLOSURE: Wherever possible I use referral links, which means if you click one of the links in this video or description and make a purchase I may receive a small commission or other compensation.

