# Source:Eli the Computer Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ, language:en-US

## WormGPT - What is... (Super Scary AI HACKING TOOL)
 - [https://www.youtube.com/watch?v=rqA_LkM0qIk](https://www.youtube.com/watch?v=rqA_LkM0qIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ
 - date published: 2023-07-25T15:52:16+00:00

Support Silicon Dojo at: https://donorbox.org/etcg
RSVP for Classes at: http://www.silicondojo.com
LinkedIN at: https://www.linkedin.com/in/eli-etherton-a15362211/

