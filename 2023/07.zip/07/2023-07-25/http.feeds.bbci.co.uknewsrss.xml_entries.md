# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Conor Gallagher 'still in Chelsea plans' after they reject bid from West Ham
 - [https://www.bbc.co.uk/sport/football/66298560?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66298560?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T23:06:37+00:00

Chelsea manager Mauricio Pochettino says Conor Gallagher is still in his plans after the club reject a reported £40m bid from West Ham.

## Trevor Reed: Ex-US marine freed by Russia is injured fighting in Ukraine
 - [https://www.bbc.co.uk/news/world-us-canada-66308584?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66308584?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T21:51:32+00:00

After being freed last year in a prisoner exchange with Russia, Trevor Reed is injured in Ukraine.

## Chancellor has concerns as NatWest boss Dame Alison Rose admits 'serious error'
 - [https://www.bbc.co.uk/news/business-66308627?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66308627?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T21:47:31+00:00

Dame Alison Rose admitted a "serious error" in talking about Nigel Farage's relationship with its private banking arm Coutts.

## Robin Grainger: Only selling one ticket to my show launched my career
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-66268111?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-66268111?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T21:44:27+00:00

The comedian who brought a whole new meaning to the term "one-man show" is returning to the Edinburgh Fringe.

## Brussels bombers found guilty after long murder trial
 - [https://www.bbc.co.uk/news/world-europe-66299186?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66299186?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T18:06:58+00:00

Six of the 10 suspects are convicted of terrorist murder for the twin bombings that killed 32 people.

## Tour de France Femmes 2023: Lorena Wiebes beats Marianne Vos in sprint finish on stage three
 - [https://www.bbc.co.uk/sport/cycling/66304739?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/66304739?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T17:33:52+00:00

Lorena Wiebes wins stage three of the Tour de France Femmes as breakaway rider Julie Van De Velde is caught with about 200m to go.

## Greece fires: Two pilots die after firefighting plane crashes
 - [https://www.bbc.co.uk/news/world-europe-66305720?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66305720?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T17:10:31+00:00

The Greek air force pilots had been responding to a wildfire near Platanistos on the island of Evia.

## Nigel Farage: NatWest boss admits 'serious' error in bank closure row
 - [https://www.bbc.co.uk/news/business-66307353?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66307353?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T17:00:36+00:00

Dame Alison Rose said she was "wrong" to respond to questions from the BBC about his bank account being closed.

## LeBron James' eldest son Bronny stable after cardiac arrest
 - [https://www.bbc.co.uk/sport/basketball/66304746?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/basketball/66304746?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T16:15:22+00:00

Bronny James, the eldest son of basketball great LeBron James, is in a stable condition after suffering a cardiac arrest, says a family spokesperson.

## Swansea dad jailed for taking son's points before fatal crash
 - [https://www.bbc.co.uk/news/uk-wales-66304860?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-66304860?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T15:56:15+00:00

Dewi George accepted speeding points on behalf of his son, who was later involved in a fatal crash.

## Pastor at kidnapped US girl's funeral in 1975 charged with her murder
 - [https://www.bbc.co.uk/news/world-us-canada-66301562?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66301562?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T15:48:43+00:00

Gretchen Harrington, eight, was abducted by a family friend during a Bible camp in 1975, police say.

## David Goodwillie: Prosecutors urged to re-open rape case
 - [https://www.bbc.co.uk/news/uk-scotland-66298242?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-66298242?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T15:33:19+00:00

The Crown Office is being urged to reconsider its stance after the footballer said he would go on trial.

## BBC reporter sees wildfire spreading in Rhodes
 - [https://www.bbc.co.uk/news/world-europe-66305324?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66305324?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T15:26:54+00:00

BBC reporter Azadeh Moshiri speaks about a fire spreading in southern Rhodes and being exacerbated by the wind.

## Ukraine war: Russia expands pool of men eligible for call-up
 - [https://www.bbc.co.uk/news/world-europe-66304522?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66304522?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T15:04:32+00:00

Men can now be conscripted into the armed forces up to the age of 30, an increase of three years.

## Whales bunch together before ‘horrific’ mass stranding
 - [https://www.bbc.co.uk/news/world-australia-66298711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-66298711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T15:03:36+00:00

Authorities are racing to save a pod of pilot whales which have become stranded on a beach in Australia.

## Rare Apple computer trainers on sale for $50,000
 - [https://www.bbc.co.uk/news/technology-66290382?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-66290382?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T14:48:04+00:00

The iconic pair were a limited edition made in the 1990s only for employees.

## Brother found guilty of Amber Gibson's murder
 - [https://www.bbc.co.uk/news/uk-scotland-66300209?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-66300209?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T14:45:03+00:00

Connor Gibson has been convicted of sexually assaulting and killing his 16-year-old sister in 2021.

## Women's World Cup: Can Republic of Ireland, a 'horrible team to play against', cause a shock?
 - [https://www.bbc.co.uk/sport/football/66255626?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66255626?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T14:37:09+00:00

After being described as a "horrible team to play against", can the Republic of Ireland shock Canada in the Women's World Cup?

## German WW1 U-boat found off the coast of Shetland
 - [https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-66302352?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-66302352?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T14:05:58+00:00

The SM UC-55 submarine which was sank in 1917 was identified by a team divers on Friday.

## Cambridge University releases 1913 English test question
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-66299898?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-66299898?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T14:04:47+00:00

The question is released to mark the 110th anniversary of Cambridge University's English exams.

## Just Stop Oil protests cost Met Police £7.7m since April
 - [https://www.bbc.co.uk/news/uk-england-london-66301164?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-66301164?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T14:01:15+00:00

Policing 515 protests since April is costing the equivalent of 23,500 officer shifts, the Met says.

## Greece fires: Satellite images and maps show extent of damage
 - [https://www.bbc.co.uk/news/world-europe-66295972?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66295972?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T13:52:02+00:00

Maps, satellite images and before and after pictures show the extent of wildfires across Greece.

## Leicester: Man and five-year-old boy found dead in house
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-66304503?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-66304503?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T13:36:41+00:00

Police are not looking for anyone else in connection with the death of the man, 41, and boy.

## Kylian Mbappe transfer news: Will Frenchman move to Saudi Arabia or Real Madrid?
 - [https://www.bbc.co.uk/sport/football/66298561?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66298561?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T13:20:12+00:00

It's this summer's headline transfer saga, but after a world record bid, where will Kylian Mbappe end up?

## Bradford amputee footballer, 12, selected for England squad
 - [https://www.bbc.co.uk/news/uk-england-leeds-66301031?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-66301031?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T13:10:36+00:00

Freddy, 12, has only been playing for 18 months but has now been called up for his country

## Labour drops pledge to introduce self-ID for trans people
 - [https://www.bbc.co.uk/news/uk-politics-66299705?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66299705?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T12:31:29+00:00

The party says it will keep a requirement for a medical diagnosis to change legal sex if it wins power.

## Qin Gang: China removes foreign minister months after appointment
 - [https://www.bbc.co.uk/news/world-asia-china-66299379?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-66299379?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T11:31:41+00:00

Qin Gang's prolonged disappearance from public view - and the silence over it - has fuelled furious speculation.

## World Aquatics Championships 2023: GB's Matt Richards and Tom Dean win 200m freestyle gold and silver
 - [https://www.bbc.co.uk/sport/swimming/66302622?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/swimming/66302622?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T11:20:20+00:00

Matt Richards and Tom Dean win 200m freestyle gold and silver to secure Great Britain's first medals of the World Aquatics Championships in Japan.

## Marmite maker Unilever's sales soar after hiking prices
 - [https://www.bbc.co.uk/news/business-66299138?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66299138?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T11:12:26+00:00

The consumer goods giant reports growth based almost entirely on lifting its prices.

## Numbers in temporary accommodation in England hit record
 - [https://www.bbc.co.uk/news/uk-66296333?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66296333?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T11:04:02+00:00

One family tells BBC News of their struggle to cope with two young children in a hotel room.

## In Pictures: Plumes of smoke and tourists evacuated
 - [https://www.bbc.co.uk/news/in-pictures-66289156?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-66289156?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T10:50:55+00:00

Wildfires continue to cause chaos on Rhodes, as tourists are evacuated.

## Matty Healy: Malaysia LGBT community angry at 1975 'white saviour stunt'
 - [https://www.bbc.co.uk/news/world-asia-66286800?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-66286800?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T10:35:57+00:00

Locals affected by singer Matty Healy's protest say it did their cause more harm than good.

## Anthony Elanga: Nottingham Forest sign Sweden forward from Man Utd
 - [https://www.bbc.co.uk/sport/football/66301365?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66301365?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T10:26:30+00:00

Nottingham Forest complete the signing of Sweden forward Anthony Elanga from Manchester United on a five-year deal.

## Switzerland 0-0 Norway: Former winners Norway in danger of early exit
 - [https://www.bbc.co.uk/sport/football/66290034?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66290034?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T10:23:28+00:00

Former winners Norway face an early exit from the Women's World Cup after a draw with Switzerland leaves them bottom of Group A.

## Julian Sands: Room with a View actor's final cause of death is undetermined
 - [https://www.bbc.co.uk/news/entertainment-arts-66298417?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66298417?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T10:03:10+00:00

The British actor's body was recovered in June, months after he'd gone missing in the mountains.

## Watch: Twitter HQ left with 'er' sign as police stop work
 - [https://www.bbc.co.uk/news/technology-66300332?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-66300332?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T09:34:38+00:00

Workers in San Francisco were taking down the sign after Elon Musk's rebrand of the company.

## Lost Raphael masterpiece goes on show in UK first
 - [https://www.bbc.co.uk/news/uk-england-leeds-66291225?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-66291225?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T09:06:10+00:00

The work was recently confirmed to be by the Renaissance artist after work by two university teams.

## Indo-Caribbeans in the UK: 'Our stories are yet to be heard'
 - [https://www.bbc.co.uk/news/newsbeat-66267574?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-66267574?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T08:57:40+00:00

People from the Indo-Caribbean community tell BBC Asian Network their stories aren't often heard.

## Women's World Cup 2023: Philippines defeat co-hosts New Zealand in shock victory
 - [https://www.bbc.co.uk/sport/av/football/66268678?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/66268678?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T08:46:04+00:00

Watch highlights as New Zealand miss a golden opportunity to edge closer to the knockout stages as the Philippines defeat New Zealand to become the first debutants to pick up a win at the 2023 Fifa Women's World Cup.

## Emma Raducanu's agent defends coaching turnover
 - [https://www.bbc.co.uk/sport/tennis/66298536?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/66298536?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T08:40:19+00:00

Emma Raducanu's approach of regularly changing coaches is "probably going to be like that for the rest of her career", says her agent.

## Rasmus Hojlund: Getting to know the Manchester United target
 - [https://www.bbc.co.uk/sport/football/66243517?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66243517?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T08:31:58+00:00

Rasmus Hojlund is being heavily linked with Manchester United - but what type of player is he, and what are his stats?

## Laura Whitmore on incels, rough sex and cyber stalking
 - [https://www.bbc.co.uk/news/entertainment-arts-66222630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66222630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T08:13:47+00:00

The ex-Love Island host says she is exploring "uncomfortable" topics in her new documentary series.

## The TikTok star cleaning up litter in Scotland's forests
 - [https://www.bbc.co.uk/news/uk-scotland-tayside-central-66257549?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-tayside-central-66257549?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T08:08:11+00:00

Thousands of people watch John Donaldson, 32, clearing rubbish from his local forest.

## Virgin Media O2 to cut up to 2,000 UK jobs
 - [https://www.bbc.co.uk/news/business-66298892?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66298892?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T07:54:04+00:00

The roles will go by the end of this year during what, the firm says, could be a "difficult" time.

## New Zealand 0-1 Philippines: Co-hosts upset by World Cup debutants in shock defeat
 - [https://www.bbc.co.uk/sport/football/66290027?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66290027?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T07:47:54+00:00

New Zealand miss a golden opportunity to edge closer to the knockout stages of the Women's World Cup as the Philippines upset them in Wellington.

## Shaka Hislop 'thankful' for support after on-air collapse at Real Madrid v AC Milan game
 - [https://www.bbc.co.uk/sport/football/66298535?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66298535?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T06:23:03+00:00

Former West Ham goalkeeper turned TV pundit Shaka Hislop says he is "thankful" for support after his on-air collapse.

## Women's World Cup 2023: Colombia defeat South Korea to earn their second ever win at the tournament
 - [https://www.bbc.co.uk/sport/av/football/66268677?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/66268677?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T05:52:21+00:00

Watch highlights as Colombia earn their second ever Women's World Cup win as they defeat South Korea 2-0 at the Fifa Women's World Cup in Moore Park.

## Cornish hill near Helston listed for sale for £150,000
 - [https://www.bbc.co.uk/news/uk-england-cornwall-66292887?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cornwall-66292887?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T05:15:13+00:00

Tregonning Hill includes Bronze Age burial mounds, an Iron Age hillfort and a war memorial.

## Europe and US heatwaves near 'impossible' without climate change
 - [https://www.bbc.co.uk/news/science-environment-66289489?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-66289489?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T05:04:01+00:00

Scientists say the heatwaves seen in Europe, the US and China in July are no longer unusual.

## Watch: Raging wildfires shut down Italian airport
 - [https://www.bbc.co.uk/news/world-europe-66298131?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66298131?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T04:47:35+00:00

Palermo’s airport was shut down overnight as wildfires burned around its perimeter.

## The children left injured and starving in Yemen's forgotten war
 - [https://www.bbc.co.uk/news/world-middle-east-66258171?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-66258171?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T04:20:36+00:00

A rare glimpse of a fractured conflict where the young are stalked by war and hunger.

## Colombia 2-0 South Korea: South Americans capitalise on mistakes for opening World Cup win
 - [https://www.bbc.co.uk/sport/football/66290020?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66290020?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T04:12:07+00:00

Colombia get their Women's World Cup off to the perfect start with victory over South Korea, while Casey Phair becomes the youngest-ever player at a Women's World Cup.

## Bayer: Weedkiller maker to take $2.8bn hit as sales fall
 - [https://www.bbc.co.uk/news/business-66297589?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66297589?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T03:48:49+00:00

The German firm has set aside more than $15bn to settle potential lawsuits linking Roundup to cancer.

## Chris Bart-Williams: Former midfielder dies aged 49
 - [https://www.bbc.co.uk/sport/football/66297415?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66297415?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T03:27:01+00:00

Former Sheffield Wednesday and Nottingham Forest midfielder Chris Bart-Williams dies aged 49.

## Rhodes fires: Hundreds back in UK after 'traumatic' Rhodes fires
 - [https://www.bbc.co.uk/news/uk-66297476?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66297476?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T03:09:38+00:00

Britons have been flying into airports including Gatwick, Heathrow, Stansted, Birmingham and Bristol.

## How desperate US prisoners try to escape deadly heat
 - [https://www.bbc.co.uk/news/world-us-canada-66274629?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66274629?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T01:29:51+00:00

With no air conditioning, a former prisoner describes lying in toilet water to survive brutal heat.

## Ghana minister Cecilia Abena Dapaah reported a robbery. Why was she arrested?
 - [https://www.bbc.co.uk/news/world-africa-66291294?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-66291294?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T01:17:40+00:00

A Ghanaian minister allegedly lost $1m cash, handbags and jewels from her house.

## Iraq and others condemn Quran-burning in Denmark
 - [https://www.bbc.co.uk/news/world-europe-66297340?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66297340?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T00:18:26+00:00

Large crowds protest in Iraq and Yemen after the acts of a far-right group in Copenhagen.

## Obamas' chef Tafari Campbell dies in paddleboarding accident
 - [https://www.bbc.co.uk/news/world-us-canada-66297450?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66297450?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T00:15:41+00:00

Tafari Campbell, 45, is recovered near the Massachusetts home of Barack and Michelle Obama.

## Paris to bring back swimming in Seine after 100 years
 - [https://www.bbc.co.uk/news/world-europe-66238618?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66238618?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-07-25T00:04:20+00:00

Banned for a century because of filthy water, bathing is to resume in parts of the river in Paris.

