# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## "Ogień był niezwykle potężny". Pożary w znanym tureckim kurorcie
 - [https://tvn24.pl/tvnmeteo/swiat/pozary-w-turcji-antalya-kemer-ogien-byl-niezwykle-potezny-7257613?source=rss](https://tvn24.pl/tvnmeteo/swiat/pozary-w-turcji-antalya-kemer-ogien-byl-niezwykle-potezny-7257613?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-07-25T13:57:08+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dz7btm-turcja-7257891/alternates/LANDSCAPE_1280" />
    W tureckim kurorcie Kemer w prowincji Antalya wybuchły pożary. Z żywiołem walczy ponad 200 strażaków. W akcji gaszenia biorą udział samoloty i śmigłowce gaśnicze. Na Kontakt 24 otrzymujemy materiały przedstawiające sytuację w tym kraju.

