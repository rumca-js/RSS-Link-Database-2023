# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Śląskie. Przyszedł do bankomatu po pieniądze. Normalna sprawa, ale dlaczego w kominiarce?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29783567,slaskie-przyszedl-do-bankomatu-po-pieniadze-normalna-sprawa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29783567,slaskie-przyszedl-do-bankomatu-po-pieniadze-normalna-sprawa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-21 17:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2c/67/1c/z29783596M,Przyszedl-do-bankomatu-po-pieniadze-w-kominiarce--.jpg" vspace="2" />Policjanci z Gorzyc w woj. śląskim otrzymali zgłoszenie o dziwnie zachowującym się mężczyźnie. Wybierał on pieniądze z bankomatu, a na twarzy miał założoną kominiarkę. Jak się okazało, obywatel Niemiec miał ważny powód.

## Tragiczny wypadek na A1. Dachował bus, wypadły trzy osoby, kierowca był pijany
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29783413,smiertelny-wypadek-na-a1-dachowal-bus-kierowca-byl-pijany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29783413,smiertelny-wypadek-na-a1-dachowal-bus-kierowca-byl-pijany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-21 15:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cf/67/1c/z29783503M,Smiertelny-wypadek-na-A1--Dachowal-bus--kierowca-b.jpg" vspace="2" />Tragiczny wypadek busa na węźle Blachownia na autostradzie A1 w województwie śląskim. Pojazd dachował, wypadły z niego trzy osoby, dwie z nich zginęły. Policja podała, że kierowca busa był pod wpływem alkoholu.

## Szczecin. Niebezpieczny pożar w domu wielorodzinnym. "Zaczęli robić grilla"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29783259,szczecin-niebezpieczny-pozar-w-domu-wielorodzinnym-zaczeli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29783259,szczecin-niebezpieczny-pozar-w-domu-wielorodzinnym-zaczeli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-21 14:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/67/1c/z29783363M,Szczecin--Niebezpieczny-pozar-w-domu-wielorodzinny.jpg" vspace="2" />Nocny pożar w jednym z domów wielorodzinnych na osiedlu Bukowe-Klęskowo w Szczecinie. Ogień pojawił się w mieszkaniu na parterze. Sąsiedzi twierdzą, że powodem pożaru był grill, rozpalony na tarasie.

## Komunijne "dywaniki do kibla" z Jezusem. Ksiądz wylicza wymysły rodziców i pyta dzieci o prezenty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29782921,komunijne-dywaniki-do-kibla-z-jezusem-ksiadz-wylicza-wymysly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29782921,komunijne-dywaniki-do-kibla-z-jezusem-ksiadz-wylicza-wymysly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-21 14:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/da/46/1c/z29649882M,Pierwsza-komunia-swieta--zdjecie-ilustracyjne-.jpg" vspace="2" />"Czy w pierwszej komunii chodzi jeszcze o Boga?" - takie pytanie w nowym odcinku swojego programu postawił ks. Rafał Główczyński, youtuber znany jako "Ksiądz z osiedla". Zapytał rodziców m.in. o to, czy widzą coś złego w komercjalizacji komunii, a dzieci - o to, jaki jest ich wymarzony prezent.

## Nowe ostrzeżenia IMGW. Nadchodzą gwałtowne burze, możliwe wezbrania wód i pożary [zagrożone regiony]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29783028,nowe-ostrzezenia-imgw-nadchodza-gwaltowne-burze-mozliwe-wezbrania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29783028,nowe-ostrzezenia-imgw-nadchodza-gwaltowne-burze-mozliwe-wezbrania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-21 13:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/10/67/1c/z29783056M,Wyladowania-atmosferyczne-w-trakcie-burzy---zdjeci.jpg" vspace="2" />Za nami majowa zimna Zośka i towarzyszący jej zimni ogrodnicy. Choć sytuacja pogodowa zdaje się na powrót stabilizować, a słońce chętniej dotrzymuje nam towarzystwa, w niektórych regionach Polski sytuacja pozostaje niespokojna. IMGW wydało bowiem aż trzy ostrzeżenia różnych kategorii dla konkretnych regionów kraju.

