# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## These Plants Make the Best Living Fences
 - [https://lifehacker.com/these-plants-make-the-best-living-fences-1850449614](https://lifehacker.com/these-plants-make-the-best-living-fences-1850449614)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-05-21 17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--UVvkXrkP--/c_fit,fl_progressive,q_80,w_636/fafe3a1fc25ab9dcaf01d888555b15b3.jpg" /><p>When we think of fences, materials like lumber, chain-link, stone, brick, and chickenwire tend to come to mind. But what about shrubs and small trees? They can be used to create what’s known as a “living fence,” which is exactly what it sounds like. </p><p><a href="https://lifehacker.com/these-plants-make-the-best-living-fences-1850449614">Read more...</a></p>

## The Difference Between Contact Cement and Rubber Cement
 - [https://lifehacker.com/the-difference-between-contact-cement-and-rubber-cement-1850449617](https://lifehacker.com/the-difference-between-contact-cement-and-rubber-cement-1850449617)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-05-21 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--vALzvpA3--/c_fit,fl_progressive,q_80,w_636/3d85da098cbbcddb20d73733cf81c30c.jpg" /><p>Walk into any hardware, big-box, or craft store, and you’ll find an aisle (or at least part of an aisle) full of different types of adhesives. Having so many options can be overwhelming, and it may be tempting to use super glue for everything, and hope it works. And maybe, so far, it has. But there’s no reason to…</p><p><a href="https://lifehacker.com/the-difference-between-contact-cement-and-rubber-cement-1850449617">Read more...</a></p>

## The Best Free and Cheap Food You Can Get for Memorial Day
 - [https://lifehacker.com/the-best-free-and-cheap-food-you-can-get-for-memorial-d-1850448272](https://lifehacker.com/the-best-free-and-cheap-food-you-can-get-for-memorial-d-1850448272)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-05-21 13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--4Dv10eqc--/c_fit,fl_progressive,q_80,w_636/75911db124854f9cbd05a0798a3bb271.jpg" /><p>Not only is Monday, May 29 Memorial Day—widely considered the unofficial start of summer—but Sunday, May 28 is National Hamburger Day. And whether you’re traveling over the long weekend or staying local, you’re going to have to eat at some point. Fortunately, there are plenty of food deals and freebies to choose from…</p><p><a href="https://lifehacker.com/the-best-free-and-cheap-food-you-can-get-for-memorial-d-1850448272">Read more...</a></p>

