# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Supercharge Your ChatGPT Prompts With Auto-GPT
 - [https://www.wired.com/story/chatgpt-prompts-auto-gpt/](https://www.wired.com/story/chatgpt-prompts-auto-gpt/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-05-21 11:00:00+00:00

The new tool basically transforms ChatGPT into a virtual assistant to help you manage projects, run a marketing campaign, and more.

