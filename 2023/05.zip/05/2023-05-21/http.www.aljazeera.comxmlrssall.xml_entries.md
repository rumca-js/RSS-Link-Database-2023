# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Greece’s conservative party takes commanding lead in election
 - [https://www.aljazeera.com/news/2023/5/21/greeces-conservative-party-leads-election-with-wide-margin](https://www.aljazeera.com/news/2023/5/21/greeces-conservative-party-leads-election-with-wide-margin)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 19:56:09+00:00

The New Democracy party of PM Mitsotakis is scoring a resounding but indecisive victory against left-wing Syriza.

## Russians celebrate reports that ‘fortress Bakhmut’ has fallen
 - [https://www.aljazeera.com/news/2023/5/21/russians-celebrate-fall-of-fortress](https://www.aljazeera.com/news/2023/5/21/russians-celebrate-fall-of-fortress)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 19:31:18+00:00

Ukraine&#039;s president is denying claims that the eastern city is under Russian control after months of heavy battle.

## Will worsening US relations with Beijing affect EU-China trade?
 - [https://www.aljazeera.com/program/inside-story/2023/5/21/will-worsening-us-relations-with-beijing-affect-eu-china-trade](https://www.aljazeera.com/program/inside-story/2023/5/21/will-worsening-us-relations-with-beijing-affect-eu-china-trade)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 18:14:26+00:00

The United States has sought to increase pressure on Beijing.

## Fentanyl: The new face of the US war on the poor
 - [https://www.aljazeera.com/opinions/2023/5/21/fentanyl-the-new-face-of-the-us-war-on-the-poor](https://www.aljazeera.com/opinions/2023/5/21/fentanyl-the-new-face-of-the-us-war-on-the-poor)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 17:39:28+00:00

The US government is trying to blame the fentanyl crisis on drug trafficking but it is a disaster of its own making.

## Why is Bakhmut important in the Russia-Ukraine war?
 - [https://www.aljazeera.com/news/2023/5/21/why-is-bakhmut-important-in-the-russia-ukraine-war](https://www.aljazeera.com/news/2023/5/21/why-is-bakhmut-important-in-the-russia-ukraine-war)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 16:25:53+00:00

The symbolic importance of the small city in Ukraine&#039;s east now far outweighs any strategic value for either side.

## Zelenskyy calls on G7 to ensure Russia is ‘last aggressor’
 - [https://www.aljazeera.com/news/2023/5/21/zelenskyy-calls-on-g7-to-ensure-russia-is-last](https://www.aljazeera.com/news/2023/5/21/zelenskyy-calls-on-g7-to-ensure-russia-is-last)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 15:23:54+00:00

Zelenskyy’s visit to Japan highlighted significant divisions preventing the formation of a united front against Russia.

## Tens of thousands rally in Moldova for EU membership
 - [https://www.aljazeera.com/news/2023/5/21/pro-government-rally-in-moldovan-capital-draws-tens-of-thousands](https://www.aljazeera.com/news/2023/5/21/pro-government-rally-in-moldovan-capital-draws-tens-of-thousands)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 14:54:17+00:00

Demonstrators called on leaders to amend the constitution to specifically mention the country&#039;s European orientation.

## Israel far-right minister visits Al-Aqsa compound
 - [https://www.aljazeera.com/news/2023/5/21/israel-far-right-minister-visits-al-aqsa-compound](https://www.aljazeera.com/news/2023/5/21/israel-far-right-minister-visits-al-aqsa-compound)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 14:37:22+00:00

Visit of Itamar Ben-Gvir comes days after tens of thousands of Jewish nationalists marched through the Old City.

## How important is Captagon in al-Assad’s return to the Arab fold?
 - [https://www.aljazeera.com/news/2023/5/21/how-important-is-captagon-in-al-assads-return-to-the-arab-fold](https://www.aljazeera.com/news/2023/5/21/how-important-is-captagon-in-al-assads-return-to-the-arab-fold)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 14:20:30+00:00

The billions of dollars Syria&#039;s al-Assad is believed to be making from Captagon have given him a financial lifeline.

## ‘Don’t have a problem with army chief,’ Imran Khan says
 - [https://www.aljazeera.com/news/2023/5/21/dont-have-a-problem-with-army-chief-imran-khan-says](https://www.aljazeera.com/news/2023/5/21/dont-have-a-problem-with-army-chief-imran-khan-says)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 14:00:21+00:00

Former Pakistan PM tells Al Jazeera the government and military want to &#039;crush&#039; his PTI party ahead of the polls.

## Greece heads to polls in first election since end of bailout
 - [https://www.aljazeera.com/news/2023/5/21/greece-heads-to-polls-in-first-election-since-end-of-bailout](https://www.aljazeera.com/news/2023/5/21/greece-heads-to-polls-in-first-election-since-end-of-bailout)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 13:16:19+00:00

Two main contenders are conservative Prime Minister Kyriakos Mitsotakis and Alexis Tsipras, who heads the Syriza party.

## Iran says it is strong enough to defend regional waters
 - [https://www.aljazeera.com/news/2023/5/21/iran-says-it-is-strong-enough-to-defend-regional-waters](https://www.aljazeera.com/news/2023/5/21/iran-says-it-is-strong-enough-to-defend-regional-waters)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 12:39:58+00:00

Tehran says the longest trip in its navy history is an indication that it is successfully circumventing US sanctions.

## German police investigate suspected poisoning of Russian exiles
 - [https://www.aljazeera.com/news/2023/5/21/german-police-investigate-suspected-poisoning-of-russian-exiles](https://www.aljazeera.com/news/2023/5/21/german-police-investigate-suspected-poisoning-of-russian-exiles)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 12:04:21+00:00

The inquiry is being handled by the state security unit, a specialised team that examines cases related to &#039;terrorism&#039;.

## Expats start voting in Turkey election run-off
 - [https://www.aljazeera.com/news/2023/5/21/expats-start-voting-in-turkey-election-run-off](https://www.aljazeera.com/news/2023/5/21/expats-start-voting-in-turkey-election-run-off)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 11:42:52+00:00

Polls recommenced for Turkish expats on Saturday, presenting regional divide and growing urges for participation.

## Tunisia: Tourism dreams and violence woes after Djerba attack
 - [https://www.aljazeera.com/news/2023/5/21/tunisia-tourism-dreams-and-violence-woes-after-djerba-attack](https://www.aljazeera.com/news/2023/5/21/tunisia-tourism-dreams-and-violence-woes-after-djerba-attack)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 10:44:06+00:00

Kais Saied&#039;s government is working hard to minimise the recent attack on the Ghriba Synagogue, hoping to save tourism.

## Greek elections so far: All you need to know in 400 words
 - [https://www.aljazeera.com/news/2023/5/21/greek-elections-so-far-all-you-need-to-know-in-400-words](https://www.aljazeera.com/news/2023/5/21/greek-elections-so-far-all-you-need-to-know-in-400-words)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 10:17:56+00:00

A simple to the parliamentary election in the European Union country.

## Haney retains titles with controversial win over Lomachenko
 - [https://www.aljazeera.com/sports/2023/5/21/boxing-haney-retains-lightweight-titles-lomachenko](https://www.aljazeera.com/sports/2023/5/21/boxing-haney-retains-lightweight-titles-lomachenko)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 10:02:28+00:00

Lomachenko&#039;s camp slam the judges after Devin Haney retains lightweight boxing titles with unanimous decision.

## Tea or chai? Celebrating International Tea Day
 - [https://www.aljazeera.com/news/2023/5/21/tea-or-chai-celebrating-international-tea-day](https://www.aljazeera.com/news/2023/5/21/tea-or-chai-celebrating-international-tea-day)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 10:00:02+00:00

Across the globe, nearly all words for tea can be derived from the root-words cha or te.

## Bahrain to restore full diplomatic relations with Lebanon
 - [https://www.aljazeera.com/news/2023/5/21/bahrain-to-restore-full-diplomatic-relations-with-lebanon](https://www.aljazeera.com/news/2023/5/21/bahrain-to-restore-full-diplomatic-relations-with-lebanon)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 09:50:25+00:00

The Gulf nation has ended a year-and-a-half-long impasse as it looks to strengthen &#039;fraternal relations&#039; with Lebanon.

## At G7, Japanese PM pledges ‘unwavering solidarity’ with Ukraine
 - [https://www.aljazeera.com/news/2023/5/21/at-g7-japanese-pm-pledges-unwavering-solidarity-with-ukraine](https://www.aljazeera.com/news/2023/5/21/at-g7-japanese-pm-pledges-unwavering-solidarity-with-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 09:36:25+00:00

Prime Minister Kishida says Moscow&#039;s invasion of Ukraine struck at the &#039;very foundation of the international order&#039;.

## Iran hangs three on drug charges amid criticism
 - [https://www.aljazeera.com/news/2023/5/21/iran-hangs-three-on-drug-charges-amid-criticism](https://www.aljazeera.com/news/2023/5/21/iran-hangs-three-on-drug-charges-amid-criticism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 09:15:05+00:00

The latest executions were carried out after offenders were reportedly caught with large quantities of heroin.

## First Saudi astronauts to blast off in private mission to ISS
 - [https://www.aljazeera.com/news/2023/5/21/first-saudi-astronauts-to-blast-off-in-private-mission-to-iss](https://www.aljazeera.com/news/2023/5/21/first-saudi-astronauts-to-blast-off-in-private-mission-to-iss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 08:10:46+00:00

Rayyanah Barnawi, the first female Arab astronaut, is also on the mission.

## At least dozen killed in El Salvador football stadium crush
 - [https://www.aljazeera.com/news/2023/5/21/at-least-dozen-killed-in-el-salvador-football-stadium-crush](https://www.aljazeera.com/news/2023/5/21/at-least-dozen-killed-in-el-salvador-football-stadium-crush)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 07:55:22+00:00

The police said initial reports point to a crush of fans who tried to enter the stadium to watch a match in the capital.

## Russians ‘destroyed everything’ in Bakhmut: Ukraine’s Zelenskyy
 - [https://www.aljazeera.com/news/2023/5/21/ukraines-zelenskyy-appears-to-confirm-loss-of-bakhmut-to-russia](https://www.aljazeera.com/news/2023/5/21/ukraines-zelenskyy-appears-to-confirm-loss-of-bakhmut-to-russia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 07:08:27+00:00

His spokesman denies reports attributed to the Ukrainian president that the city was captured by the Russian forces.

## Music and spirit go full throttle at Cape Verdean music festival
 - [https://www.aljazeera.com/gallery/2023/5/21/music-and-spirit-go-full-throttle-at-cape-verdean-music-festival](https://www.aljazeera.com/gallery/2023/5/21/music-and-spirit-go-full-throttle-at-cape-verdean-music-festival)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 05:48:35+00:00

Musicians and other industry stakeholders converge at an annual Cape Verdean festival, to discuss evolution of the art.

## G7 wants ‘constructive’ China ties, calls out rights record
 - [https://www.aljazeera.com/news/2023/5/21/g7-wants-constructive-china-ties-calls-out-rights-record](https://www.aljazeera.com/news/2023/5/21/g7-wants-constructive-china-ties-calls-out-rights-record)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 03:14:21+00:00

G7 says it will not block China&#039;s development but calls out Beijing for its rights record and territorial claims.

## Putin congratulates Russia troops, Wagner for ‘capturing Bakhmut’
 - [https://www.aljazeera.com/news/2023/5/21/putin-congratulates-russia-troops-wagner-for-capturing-bakhmut](https://www.aljazeera.com/news/2023/5/21/putin-congratulates-russia-troops-wagner-for-capturing-bakhmut)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 02:14:00+00:00

Russian claims of capturing Bakhmut came hours after Ukraine said the battle for the eastern city was continuing.

## Sudan’s army, Rapid Support Forces sign 7-day ceasefire
 - [https://www.aljazeera.com/news/2023/5/21/sudans-army-rapid-support-forces-sign-7-day-ceasefire](https://www.aljazeera.com/news/2023/5/21/sudans-army-rapid-support-forces-sign-7-day-ceasefire)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-21 00:53:14+00:00

Truce will come into effect 48 hours after signing of agreement and is to be enforced by the US and Saudi Arabia.

