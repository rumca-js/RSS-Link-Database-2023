# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Why Are We So Depressed?
 - [https://www.youtube.com/watch?v=47x-v6U68mY](https://www.youtube.com/watch?v=47x-v6U68mY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-05-21 00:45:00+00:00

#depression #mentalhealth #whatistheproblem #howdowefixit #anxiety #MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

