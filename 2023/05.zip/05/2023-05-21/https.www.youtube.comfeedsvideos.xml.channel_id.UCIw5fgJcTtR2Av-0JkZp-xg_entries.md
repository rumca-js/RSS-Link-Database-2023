# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "I'm The Dude" // Remixing The Big Lebowski // Smpltrek
 - [https://www.youtube.com/watch?v=kfVwGvSL--4](https://www.youtube.com/watch?v=kfVwGvSL--4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2023-05-21 12:00:36+00:00

SmplTrek skin by Cremacaffe: https://cremacaffe.shop
Support my music on Patreon: https://patreon.com/yuriwong
Remixed on the Sonicware SmplTrek
Completed in Logic Pro
0:00 Making-of
3:22 Full Song

Let me explain something to you. Um, I am not "Mr. Lebowski". You're Mr. Lebowski. I'm the Dude. So that's what you call me. You know, that or, uh, His Dudeness, or uh, Duder, or El Duderino if you're not into the whole brevity thing.

