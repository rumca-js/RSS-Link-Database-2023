# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Fast X Speeds Off to a Massive Box Office Start
 - [https://gizmodo.com/fast-x-box-office-opening-weekend-1850459541](https://gizmodo.com/fast-x-box-office-opening-weekend-1850459541)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 20:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--R1Xbz-Jt--/c_fit,fl_progressive,q_80,w_636/5da3efdae5fd92d6607b7f46e059ead9.png" /><p><a href="https://gizmodo.com/fast-x-review-jason-momoa-vin-diesel-fast-and-furious-1850409790"><em>Fast X</em></a><em> </em>just out came out over the weekend, and it’s already off to an impressive start. </p><p><a href="https://gizmodo.com/fast-x-box-office-opening-weekend-1850459541">Read more...</a></p>

## College Graduates Support Writers Strike, Boo David Zaslav at Boston Ceremony
 - [https://gizmodo.com/david-zaslav-wb-discovery-writers-strike-1850459565](https://gizmodo.com/david-zaslav-wb-discovery-writers-strike-1850459565)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 19:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--LUSl9h2d--/c_fit,fl_progressive,q_80,w_636/0a56486d6d1fbd61c19dadb9f39824fd.jpg" /><p>As the <a href="https://gizmodo.com/wga-writers-strike-2023-explained-streaming-ai-tv-1850392982">Writers Strike</a> enters its third week, support has grown <a href="https://gizmodo.com/writers-strike-nyc-adam-scott-bob-odenkirk-wga-picket-1850433920">more and more</a> over time. Actors have publicly joined in on the picketing efforts as they may be on the verge of <a href="https://gizmodo.com/sag-aftra-actors-guild-strike-authorization-vote-wga-1850449053">striking themselves</a>, and people online and in real life are showing solidarity in various ways. And as it turns out, even college students are…</p><p><a href="https://gizmodo.com/david-zaslav-wb-discovery-writers-strike-1850459565">Read more...</a></p>

## Jujutsu Kaisen's New Season 2 Trailer is a Supernatural Showdown
 - [https://gizmodo.com/jujutsu-kaisen-season-2-trailer-2023-1850459383](https://gizmodo.com/jujutsu-kaisen-season-2-trailer-2023-1850459383)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 18:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0Aes1J1W--/c_fit,fl_progressive,q_80,w_636/f806114906b634669a645d9401da6d12.png" /><p>Gege Akutami’s <a href="https://gizmodo.com/halloween-arrives-early-in-the-horrifying-trailer-for-j-1844704261"><em>Jujutsu Kaisen</em></a><em> </em>has often been a fun read thanks to its cast. It isn’t new for a series to have all of its characters be enjoyable, but the fun of shonen stories in particular is they allow the creators to just have a <a href="https://gizmodo.com/jujutsu-kaisen-0-film-review-1848649784">bunch of weirdos</a> use their equally weird powers. The anime adaptation from <a href="https://gizmodo.com/eve-fight-song-chainsaw-man-episode-12-ed-music-video-1849934612">MAPPA</a>…</p><p><a href="https://gizmodo.com/jujutsu-kaisen-season-2-trailer-2023-1850459383">Read more...</a></p>

## Nick Fury Returns to the Spy Trade in Secret Invasion Promo
 - [https://gizmodo.com/secret-invasion-promo-disney-plus-mcu-1850459421](https://gizmodo.com/secret-invasion-promo-disney-plus-mcu-1850459421)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 17:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--8EFrmY13--/c_fit,fl_progressive,q_80,w_636/8ef603c0bf2a516a5d66086cd9379d50.jpg" /><p>With a full month to go before <a href="https://gizmodo.com/secret-invasion-marvel-the-little-mermaid-beetlejuice-1850451284"><em>Secret Invasion</em></a><em>, </em>it’s about that time for Marvel to start stepping up its promo game. Disney’s put out a new commercial for the upcoming miniseries that offers a deeper look at the <a href="https://gizmodo.com/secret-invasion-marvel-emilia-clarke-skrull-disney-plus-1850287877">espionage at play</a> by the Skrulls and <a href="https://gizmodo.com/secret-invasion-trailer-mcu-nick-fury-skrulls-1850292374">Nick Fury</a> (Samuel L. Jackson). Unlike the last couple of alien…</p><p><a href="https://gizmodo.com/secret-invasion-promo-disney-plus-mcu-1850459421">Read more...</a></p>

## The John Wick Franchise Has Killed Its Way to $1 Billion
 - [https://gizmodo.com/john-wick-franchise-1-billion-box-office-1850458305](https://gizmodo.com/john-wick-franchise-1-billion-box-office-1850458305)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 16:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--6QNZ07rt--/c_fit,fl_progressive,q_80,w_636/06ec04ef2356bda8e5def227dedc86dd.jpg" /><p>Since 2014, the <a href="https://gizmodo.com/john-wick-2014-worldbuilding-violence-keanu-reeves-1850313131"><em>John Wick</em></a><em> </em>franchise has been lauded for delivering the action movies goods on a consistent basis. With <a href="https://gizmodo.com/john-wick-franchise-chapter-4-keanu-reeves-donnie-yen-1850248724">each installment</a>, the series has built up a reliable fanbase for itself, both due to the merits of each film, and its larger ability to take advantage of the star power of leading man Keanu Reeves.…</p><p><a href="https://gizmodo.com/john-wick-franchise-1-billion-box-office-1850458305">Read more...</a></p>

## Meet the Dinosaurs of Prehistoric Planet Season 2
 - [https://gizmodo.com/prehistoric-planet-season-2-apple-tv-dinosaurs-images-1850435501](https://gizmodo.com/prehistoric-planet-season-2-apple-tv-dinosaurs-images-1850435501)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--u9TMECA8--/c_fit,fl_progressive,q_80,w_636/88682f2fa623fb1a551610c475ec99ba.jpg" /><p>Behold the newest snarling, scurrying, foraging, and feasting dinosaurs and other extinct creatures of <em>Prehistoric Planet</em>.</p><p><a href="https://gizmodo.com/prehistoric-planet-season-2-apple-tv-dinosaurs-images-1850435501">Read more...</a></p>

## Powerpuff Girls Reboot, Other CW Spinoffs Are Officially Dead
 - [https://gizmodo.com/the-cw-powerpuff-girls-reboot-canceled-1850458922](https://gizmodo.com/the-cw-powerpuff-girls-reboot-canceled-1850458922)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--2WjpI7_m--/c_fit,fl_progressive,q_80,w_636/48a7599fedab83ea2cce42829120f0b9.jpg" /><p>The CW is a network that’s often taken some strange swings, and whose shows like <em>Riverdale </em>or <a href="https://gizmodo.com/beetlejuice-2-casting-monica-bellucci-justin-theroux-1850430721"><em>The Winchesters</em></a><em> </em>cause no small amount of confusion when they first get announced. When it was revealed in 2020 that the network was aiming towards a live-action reboot of <a href="https://gizmodo.com/the-live-action-powerpuff-girls-tv-show-debuts-the-new-1846668340"><em>The Powerpuff Girls</em></a><em>, </em>one of Cartoon Network’s most…</p><p><a href="https://gizmodo.com/the-cw-powerpuff-girls-reboot-canceled-1850458922">Read more...</a></p>

## These Are the Best Apps to Help You Move
 - [https://gizmodo.com/best-moving-apps-nextdoor-google-keep-sortly-moving-box-1850447410](https://gizmodo.com/best-moving-apps-nextdoor-google-keep-sortly-moving-box-1850447410)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--qiSFl_eT--/c_fit,fl_progressive,q_80,w_636/debfd3d5cb9c0277b34de706bbecedbc.jpg" /><p>As summer approaches and leases start to end, moving season begins. You can use your phone to get some much needed distraction while you navigate the hectic task, sure, but it can also help make it less stressful. If you’re planning to shift your entire life from one place to another in the near future, then these are…</p><p><a href="https://gizmodo.com/best-moving-apps-nextdoor-google-keep-sortly-moving-box-1850447410">Read more...</a></p>

## What Could ChatGPT Do to Wall Street?
 - [https://gizmodo.com/chatgpt-ai-finance-wall-street-free-app-chat-gtp-1850456302](https://gizmodo.com/chatgpt-ai-finance-wall-street-free-app-chat-gtp-1850456302)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Y-oEH8Zj--/c_fit,fl_progressive,q_80,w_636/cb584cb038157de7f87f5490bb00464e.jpg" /><p>Artificial Intelligence-powered tools, such as ChatGPT, have the potential to revolutionize the efficiency, effectiveness and speed of the work humans do. And this is true in financial markets as much as in sectors like <a href="https://www.healthcareittoday.com/2023/05/01/chatgpt-may-not-be-ready-to-revolutionize-the-healthcare-industry-quite-yet-but-theres-promise-for-the-future/" rel="noopener noreferrer" target="_blank">health care</a>, <a href="https://www.technologyreview.com/2023/03/25/1070275/chatgpt-revolutionize-economy-decide-what-looks-like/" rel="noopener noreferrer" target="_blank">manufacturing</a> and pretty much every other aspect of our lives.</p><p><a href="https://gizmodo.com/chatgpt-ai-finance-wall-street-free-app-chat-gtp-1850456302">Read more...</a></p>

## Watch Live: Axiom Space Launches Its Second Private Mission to the ISS
 - [https://gizmodo.com/watch-live-axiom-space-launch-ax2-mission-iss-nasa-1850451594](https://gizmodo.com/watch-live-axiom-space-launch-ax2-mission-iss-nasa-1850451594)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--BAIOJl7D--/c_fit,fl_progressive,q_80,w_636/7f8c9189a14c5e486b1291c102c33499.jpg" /><p>Axiom Space is gearing up for the launch of its <a href="https://gizmodo.com/axiom-ax-2-second-private-mission-iss-explainer-nasa-1850445293">second private crew to the International Space Station (ISS)</a>. The four astronauts will spend a little over a week conducting experiments within the orbital lab.</p><p><a href="https://gizmodo.com/watch-live-axiom-space-launch-ax2-mission-iss-nasa-1850451594">Read more...</a></p>

## What Is a Luddite, and Why Does It Matter? A Tech Expert Explains.
 - [https://gizmodo.com/ai-chatgpt-artificial-intelligence-jobs-what-is-luddite-1850456137](https://gizmodo.com/ai-chatgpt-artificial-intelligence-jobs-what-is-luddite-1850456137)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-21 12:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Knv4pfV3--/c_fit,fl_progressive,q_80,w_636/76815b986e90441ac2f6a3bb99732f4e.jpg" /><p>The term “Luddite” emerged in <a href="https://www.smithsonianmag.com/history/what-the-luddites-really-fought-against-264412/" rel="noopener noreferrer" target="_blank">early 1800s England</a>. At the time there was a thriving textile industry that depended on manual knitting frames and a skilled workforce to create cloth and garments out of cotton and wool. But as <a href="https://www.bl.uk/georgian-britain/articles/the-industrial-revolution" rel="noopener noreferrer" target="_blank">the Industrial Revolution</a> gathered momentum, steam-powered mills threatened the livelihood of…</p><p><a href="https://gizmodo.com/ai-chatgpt-artificial-intelligence-jobs-what-is-luddite-1850456137">Read more...</a></p>

