# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Nie zamierzają być "szantażowani przez Kreml". Tysiące ludzi na ulicach
 - [https://tvn24.pl/swiat/kiszyniow-moldawia-manifestacja-poparcia-dla-proeurpejskich-dzialan-rzadu-i-prezydent-mai-sandu-7137217?source=rss](https://tvn24.pl/swiat/kiszyniow-moldawia-manifestacja-poparcia-dla-proeurpejskich-dzialan-rzadu-i-prezydent-mai-sandu-7137217?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-05-21 15:14:02+00:00

<img alt="Nie zamierzają być " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8tau8v-manifestacja-w-kiszyniowie-poparcia-dla-proeurpejskich-dzialan-rzadu-7137219/alternates/LANDSCAPE_1280" />
    Dziesiątki tysięcy Mołdawian zgromadziło się w niedzielę w Kiszyniowie, aby wyrazić poparcie dla działań prozachodniego rządu, związanych z integracją europejską. Dzieje się to w obliczu rosyjskich wysiłków zmierzających do destabilizacji kraju. - Nie chcemy już być na peryferiach Europy - powiedziała prezydent Maia Sandu, obiecując, że Mołdawia zostanie członkiem Unii Europejskiej do 2030 roku. Przebywająca w stolicy kraju przewodnicząca Parlamentu Europejskiego Roberta Metsola powiedziała do zgromadzonych, że Europa powita Mołdawię "z otwartymi ramionami i otwartymi sercami".

## "Adres MAC" a szczepionki. Kolejna fałszywa teoria o COVID-19
 - [https://konkret24.tvn24.pl/zdrowie/covid-19-adres-mac-a-szczepionki-kolejna-falszywa-teoria-o-pandemii-7132760?source=rss](https://konkret24.tvn24.pl/zdrowie/covid-19-adres-mac-a-szczepionki-kolejna-falszywa-teoria-o-pandemii-7132760?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-05-21 12:15:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eg6rlb-adres-mac-a-szczypawki-film-powiela-falszywe-teorie-o-covid-19-7132671/alternates/LANDSCAPE_1280" />
    Autorzy filmu rozpowszechnianego w mediach społecznościowych przekonują, że wraz ze szczepionką na COVID-19 do organizmu wprowadza się "adres MAC". Ten przekaz jest wariacją teorii spiskowej o potężnych siłach, które czipują ludzkość, by przejąć kontrolę nad światem.

## Zderzenie na autostradzie. "Z jednego z samochodów wypadł chłopiec"
 - [https://tvn24.pl/krakow/biadoliny-szlacheckie-zderzenie-dwoch-samochodow-osobowych-na-a4-ranne-dziecko-7137017?source=rss](https://tvn24.pl/krakow/biadoliny-szlacheckie-zderzenie-dwoch-samochodow-osobowych-na-a4-ranne-dziecko-7137017?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-05-21 12:14:49+00:00

<img alt="Zderzenie na autostradzie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-954w8x-9-latek-ranny-w-zderzeniu-dwoch-osobowek-na-a4-7137058/alternates/LANDSCAPE_1280" />
    Dziewięcioletni chłopiec został ranny i przetransportowany śmigłowcem Lotniczego Pogotowia Ratunkowego do szpitala po wypadku, do którego doszło na autostradzie A4 w miejscowości Biadoliny Szlacheckie (woj. małopolskie). Jak przekazuje policja, doszło tam do zderzenia dwóch samochodów osobowych, które jechały w tym samym kierunku.

