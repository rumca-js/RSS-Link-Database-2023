# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## So About The Idubbbz Apology Video...
 - [https://www.youtube.com/watch?v=Po5pp3Sbj_k](https://www.youtube.com/watch?v=Po5pp3Sbj_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-05-21 21:36:42+00:00

Hello guys and gals, it's me Mutahar again! One of the most popular figures in 2016-era YouTube has come out with a video denouncing a lot of his most popular content. Idubbbz is a person that feels some genuine remorse about his past and as someone who's watched him actively I wanted to chime in a bit. Thanks for watching!
Like, COmment and Subscribe for more videos!

Check out the newest podcast episode: https://youtu.be/zm4coMOhtn8

