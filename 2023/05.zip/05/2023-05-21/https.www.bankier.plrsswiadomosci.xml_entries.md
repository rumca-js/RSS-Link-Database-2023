# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Morawiecki na prezydenta? Premier ma dużą przewagę jako kandydt Zjednoczonej Prawicy wśród Polaków
 - [https://www.bankier.pl/wiadomosc/Morawiecki-na-prezydenta-Premier-ma-duza-przewage-jako-kandydt-Zjednoczonej-Prawicy-wsrod-Polakow-8544448.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morawiecki-na-prezydenta-Premier-ma-duza-przewage-jako-kandydt-Zjednoczonej-Prawicy-wsrod-Polakow-8544448.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 17:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/b/7e4de07a647bbc-948-568-0-0-3440-2063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />21,4 proc. respondentów sondażu United Surveys dla Wirtualnej Polski wskazało premiera Mateusza Morawieckiego jako potencjalnego kandydata Zjednoczonej Prawicy na prezydenta. 8,9 proc. badanych widzi w roli kandydatki na prezydenta byłą premier Beatę Szydło.</p>

## Wybory w Grecji. Nowa Demokracja premiera Micotakisa wygrywa
 - [https://www.bankier.pl/wiadomosc/Wybory-w-Grecji-Nowa-Demokracja-premiera-Micotakisa-wygrywa-8544443.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wybory-w-Grecji-Nowa-Demokracja-premiera-Micotakisa-wygrywa-8544443.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 17:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/aefd98624f07dc-948-568-0-120-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Według badań exit poll, opublikowanych zaraz po zamknięciu lokali wyborczych, niedzielne wybory parlamentarne w Grecji wygrała Nowa Demokracja premiera Kyriakosa Micotakisa.</p>

## Francuzi wracają z długiego weekendu. Ponad 900 kilometrów korków
 - [https://www.bankier.pl/wiadomosc/Francuzi-wracaja-z-dlugiego-weekendu-Ponad-900-kilometrow-korkow-8544442.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Francuzi-wracaja-z-dlugiego-weekendu-Ponad-900-kilometrow-korkow-8544442.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 17:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/6/a403b8b1041a30-945-560-0-13-1801-1080.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bądźcie ostrożni i cierpliwi na drogach Francji. Na koniec długiego słonecznego weekendu, zgodnie z oczekiwaniami, tworzą się gigantyczne korki na drogach  spowodowane masowym powrotem Francuzów do domów, to najbardziej ruchliwy dzień w roku, przestrzega w niedzielę portal Le Figaro.</p>

## Erozja dochodów realnych. Siła nabywcza Włochów spadła o ponad 14,5 mld euro w ciągu dwóch lat
 - [https://www.bankier.pl/wiadomosc/Erozja-dochodow-realnych-Sila-nabywcza-Wlochow-spadla-o-ponad-14-5-mld-euro-w-ciagu-dwoch-lat-8540658.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Erozja-dochodow-realnych-Sila-nabywcza-Wlochow-spadla-o-ponad-14-5-mld-euro-w-ciagu-dwoch-lat-8540658.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 16:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/5/a6b433971f955b-948-568-0-158-4230-2537.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ciągu ostatnich dwóch lat siła nabywcza Włochów 
spadła o ok. 14,7 mld euro, czyli o ponad 540 euro na gospodarstwo 
domowe – wynika z raportu „Handel dziś i jutro”. Od roku 2019 zniknęło 
we Włoszech ponad 52 tys. lokalnych sklepów.</p>

## Polskie kina odżyły po pandemii. Wzrosła liczba widzów i seansów
 - [https://www.bankier.pl/wiadomosc/Polskie-kina-odzyly-po-pandemii-Wzrosla-liczba-widzow-i-seansow-8543002.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-kina-odzyly-po-pandemii-Wzrosla-liczba-widzow-i-seansow-8543002.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 15:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/0486a8564ea327-945-560-0-86-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kina szczególnie ciężko zniosły pandemię. Jednak branża może się cieszyć - w 2022 roku odnotowano o 57,2 proc. więcej seansów. O połowę zwiększyła się także liczba widzów - wynika z raportu Głównego Urzędu Statystycznego (GUS) o polskiej kinematografii w 2022 r.</p>

## Boom "złote wizy" w Hiszpanii. "Są niemoralne i przyczyniają się do spekulacji na rynku nieruchomości"
 - [https://www.bankier.pl/wiadomosc/Boom-zlote-wizy-w-Hiszpanii-Sa-niemoralne-i-przyczyniaja-sie-do-spekulacji-na-rynku-nieruchomosci-8542589.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Boom-zlote-wizy-w-Hiszpanii-Sa-niemoralne-i-przyczyniaja-sie-do-spekulacji-na-rynku-nieruchomosci-8542589.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/1/1dc7bfa1ef5fc8-948-568-7-47-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zainteresowanie hiszpańskimi "złotymi wizami" znacznie wzrosło wśród zagranicznych fortun po wycofaniu w lutym tego kontrowersyjnego mechanizmu przyznawania prawa do pobytu bogatym cudzoziemcom przez Portugalię i Irlandię - poinformowała brytyjska firma Astons na podstawie kierowanych do niej pytań oraz bazując na danych w Google Trends.</p>

## Prezydent USA: Rosja straciła w Bachmucie ponad 100 tys. żołnierzy
 - [https://www.bankier.pl/wiadomosc/Prezydent-USA-Rosja-stracila-w-Bachmucie-ponad-100-tys-zolnierzy-8544393.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-USA-Rosja-stracila-w-Bachmucie-ponad-100-tys-zolnierzy-8544393.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 13:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/009c1050448c7c-948-568-0-100-3343-2005.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosja straciła w Bachmucie na wschodzie Ukrainy ponad 100 tys. żołnierzy - powiedział w niedzielę prezydent USA Joe Biden, uczestniczący w szczycie grupy G7 w Hiroszimie w Japonii.</p>

## Coraz mniej zatrudnionych w rolnictwie, a alternatywy często brak. Dochodzi do „pustynnienia” wsi
 - [https://www.bankier.pl/wiadomosc/Coraz-mniej-zatrudnionych-w-rolnictwie-a-alternatywy-czesto-brak-Dochodzi-do-pustynnienia-wsi-8540959.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-mniej-zatrudnionych-w-rolnictwie-a-alternatywy-czesto-brak-Dochodzi-do-pustynnienia-wsi-8540959.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/1/146aeda08f2619-948-568-504-327-3038-1822.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jak wskazuje GUS, liczba rolników stopniowo maleje - zatrudnienie w rolnictwie dziś deklaruje już tylko 8,4 proc. ogółu pracujących. Jednocześnie zbyt wolno przybywa nierolniczych miejsc pracy na wsi, co powoduje...</p>

## Czarna woda w fontannie di Trevi w Rzymie - kolejna akcja przeciwników paliw kopalnych
 - [https://www.bankier.pl/wiadomosc/Czarna-woda-w-fontannie-di-Trevi-w-Rzymie-kolejna-akcja-przeciwnikow-paliw-kopalnych-8544378.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czarna-woda-w-fontannie-di-Trevi-w-Rzymie-kolejna-akcja-przeciwnikow-paliw-kopalnych-8544378.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 12:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/9f047e1b6a3839-945-560-14-0-1800-1079.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Działacze ruchu Ostatnie Pokolenie wlali do rzymskiej
 fontanny di Trevi czarny płyn z węgla drzewnego. Ich kolejna akcja 
protestu przeciwko paliwom kopalnym wymierzona w zabytki wywołała 
oburzenie przebywających tam turystów i przechodniów.</p>

## Kobiety na rynku pracy. Ich wzrost zatrudnienia mocno wpłynął na wzrost gospodarczy Polski
 - [https://www.bankier.pl/wiadomosc/Kobiety-na-rynku-pracy-Ich-wzrost-zatrudnienia-mocno-wplynal-na-wzrost-gospodarczy-Polski-8540144.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kobiety-na-rynku-pracy-Ich-wzrost-zatrudnienia-mocno-wplynal-na-wzrost-gospodarczy-Polski-8540144.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/e/eb3750fc40223b-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost zatrudnienia kobiet w ciągu ostatnich kilkunastu lat przyczynił się do ok. 2/5 wzrostu gospodarczego Polski - wynika z opublikowanego raportu Polskiego Instytutu Ekonomicznego. Zauważono, że w 2021 r. wskaźnik zatrudnienia Polek w wieku 15-64 lat wyniósł 64 proc.</p>

## Rynek nieruchomości szuka nowej równowagi, ale nie zapowiada się na spadek cen mieszkań
 - [https://www.bankier.pl/wiadomosc/Rynek-nieruchomosci-szuka-nowej-rownowagi-ale-nie-zapowiada-sie-na-spadek-cen-mieszkan-8540790.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rynek-nieruchomosci-szuka-nowej-rownowagi-ale-nie-zapowiada-sie-na-spadek-cen-mieszkan-8540790.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/1d0314e34cb5cd-948-568-0-190-4010-2405.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rynek nieruchomości szuka nowej równowagi. Pierwszy kwartał przyniósł mocne odbicie po słabym 2022 roku, ale zaczyna brakować podaży z powodu niskiej aktywności deweloperów - uważa prezes JLL Polska Mateusz Bonca. W dłuższej perspektywie Polska pozostanie bardzo atrakcyjnym miejscem do inwestowania.</p>

## Idzie rewolucja w budowlance? Do produkcji betonu można używać... pieluszek
 - [https://www.bankier.pl/wiadomosc/Idzie-rewolucja-w-budowlance-Do-produkcji-betonu-mozna-uzywac-pieluszek-8543335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Idzie-rewolucja-w-budowlance-Do-produkcji-betonu-mozna-uzywac-pieluszek-8543335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/2/a1858b3f3e794b-948-568-0-250-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do 8 proc. piasku w betonie i zaprawie użytej do budowy domu można zastąpić rozdrobnionymi używanymi pieluchami jednorazowymi bez znacznego zmniejszenia wytrzymałości – informuje pismo „Scientific Reports”.</p>

## Limity na telemedycynę? To może znów wydłużyć kolejki do lekarza i odbić się na portfelach pacjentów
 - [https://www.bankier.pl/wiadomosc/Limity-na-telemedycyne-To-moze-znow-wydluzyc-kolejki-do-lekarza-i-odbic-sie-na-portfelach-pacjentow-8542757.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Limity-na-telemedycyne-To-moze-znow-wydluzyc-kolejki-do-lekarza-i-odbic-sie-na-portfelach-pacjentow-8542757.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/ad3f0f4e19cdc7-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dłuższe kolejki do lekarza, większy ruch w przychodniach, odległe terminy wizyt, dodatkowe koszty - eksperci ostrzegają, że wprowadzenie limitów dotyczących liczby konsultacji telemedycznych (takie zmiany rekomenduje m.in. Naczelna Izba Lekarska), w rezultacie uderzą w pacjentów. Polacy, którzy dotychczas korzystali z telemedycyny, wrócą do kolejek pod gabinetami lekarskimi. Za prywatną wizytę u lekarza specjalisty będą musieli zapłacić ok. 100-300 zł, a za konsultację telemedyczną płacili ok. 50-70 zł.</p>

## Polacy chronią oszczędności w dziełach sztuki? Wzrosła kwota sprzedaży na tym rynku
 - [https://www.bankier.pl/wiadomosc/Polacy-chronia-oszczednosci-w-dzielach-sztuki-Wzrosla-kwota-sprzedazy-na-tym-rynku-8541915.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-chronia-oszczednosci-w-dzielach-sztuki-Wzrosla-kwota-sprzedazy-na-tym-rynku-8541915.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/6/2373ecfa8e65e6-948-568-0-120-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Łączna kwota sprzedaży dzieł sztuki i antyków wyniosła w zeszłym roku 650,7 mln zł i w porównaniu z 2021 r. wzrosła o 10,1 proc. - wynika z opublikowanego badania GUS "Rynek dzieł sztuki i antyków w 2022 r.".</p>

## USA przekażą Ukrainie nowy pakiet pomocy wojskowej o wartości 375 mln dolarów
 - [https://www.bankier.pl/wiadomosc/USA-przekaza-Ukrainie-nowy-pakiet-pomocy-wojskowej-o-wartosci-375-mln-dolarow-8544323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-przekaza-Ukrainie-nowy-pakiet-pomocy-wojskowej-o-wartosci-375-mln-dolarow-8544323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 07:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/1/4a6b06e82529a8-948-568-75-142-2887-1732.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stany Zjednoczone robią wszystko, co w ich mocy, by wzmocnić możliwości obronne Ukrainy w wojnie tego kraju z Rosją; przekażemy władzom w Kijowie nowy pakiet pomocy militarnej zawierający amunicję, artylerię i pojazdy opancerzone - oświadczył w niedzielę prezydent USA Joe Biden, uczestniczący w szczycie grupy G7 w Hiroszimie w Japonii.</p>

## Nowy system podatkowy dla rodzin. PSL i Polska 2050 zaproponują nowe rozwiązanie w zakresie wsparcia rodziny
 - [https://www.bankier.pl/wiadomosc/Nowy-system-podatkowy-dla-rodzin-PSL-i-Polska-2050-zaproponuja-nowe-rozwiazanie-w-zakresie-wsparcia-rodziny-8544317.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowy-system-podatkowy-dla-rodzin-PSL-i-Polska-2050-zaproponuja-nowe-rozwiazanie-w-zakresie-wsparcia-rodziny-8544317.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 07:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/5/ef472a928487fd-948-568-0-0-3960-2375.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wspólnie z Polską 2050 zaproponujemy rozwiązanie w zakresie wsparcia rodziny - tak zwany francuski model systemu podatkowego, gdzie rozliczanie podatku będzie w ramach rodziny - przekazał PAP poseł Marek Sawicki (PSL). Jak dodał, oba ugrupowania będą prezentować propozycje programowe na wspólnych konwencjach.</p>

## Dzicy lokatorzy zajmują nieruchomości w Hiszpanii, a właściciele muszą jeszcze płacić rachunki
 - [https://www.bankier.pl/wiadomosc/Dzicy-lokatorzy-zajmuja-nieruchomosci-w-Hiszpanii-a-wlasciciele-musza-jeszcze-placic-rachunki-8541800.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dzicy-lokatorzy-zajmuja-nieruchomosci-w-Hiszpanii-a-wlasciciele-musza-jeszcze-placic-rachunki-8541800.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/74ad459adbcd3e-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Hiszpanii narasta zjawisko nielegalnego zajmowania domów i mieszkań przez „dzikich lokatorów”, w tym własności cudzoziemców w rejonach turystycznych kraju - alarmują media brytyjskie.</p>

## EBI założył fundusz na odbudowę Ukrainy. "Nie powinniśmy czekać do końca wojny"
 - [https://www.bankier.pl/wiadomosc/EBI-zalozyl-fundusz-na-odbudowe-Ukrainy-Nie-powinnismy-czekac-do-konca-wojny-8544314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/EBI-zalozyl-fundusz-na-odbudowe-Ukrainy-Nie-powinnismy-czekac-do-konca-wojny-8544314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 06:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/ffd393c891b3f6-948-568-0-0-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Odbudowa Ukrainy powinna trwać już dzisiaj, nie powinniśmy czekać do końca wojny – powiedziała PAP wiceprezes EBI Teresa Czerwińska. Dodała, że Europejski Bank Inwestycyjny chce kontynuować swoje wsparcie dla Ukrainy; tylko w ub. roku EBI przeznaczył na ten cel 1,7 mld euro.</p>

## Spór o port w Elblągu. Gróbarczyk: Nie zamierzamy go nacjonalizować
 - [https://www.bankier.pl/wiadomosc/Grobarczyk-Nie-zamierzamy-nacjonalizowac-portu-w-Elblagu-8544306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Grobarczyk-Nie-zamierzamy-nacjonalizowac-portu-w-Elblagu-8544306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 06:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/a/71e654e5a3bb3b-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie zamierzamy nacjonalizować portu w Elblągu; w niedługim czasie rozpoczniemy negocjacje ws. współpracy biznesowej z właścicielami gruntów znajdujących się w porcie - zapowiedział w rozmowie z PAP wiceminister infrastruktury Marek Gróbarczyk.</p>

## Rozpoczęły się wybory parlamentarne w Grecji. Na czele wyścigu partia rządząca
 - [https://www.bankier.pl/wiadomosc/Wybory-parlamentarne-w-Grecji-na-czele-wyscigu-partia-rzadzaca-8544289.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wybory-parlamentarne-w-Grecji-na-czele-wyscigu-partia-rzadzaca-8544289.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 05:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/a69410aed13b07-948-568-0-190-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />O godz. 7.00 czasu lokalnego (6.00 w Polsce) w niedzielę rozpoczęły się wybory parlamentarne w Grecji. Partie polityczne walczą o obsadzenie 300 miejsc w izbie ustawodawczej. Według ostatnich sondaży w wyścigu prowadzi Nowa Demokracja premiera Kyriakosa Micotakisa.</p>

## Firmy zwalniają z zatrudnianiem pracowników. W tych branżach spadki liczby ofert były największe
 - [https://www.bankier.pl/wiadomosc/Firmy-zwalniaja-z-zatrudnianiem-pracownikow-W-tych-branzach-spadki-liczby-ofert-byly-najwieksze-8541037.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Firmy-zwalniaja-z-zatrudnianiem-pracownikow-W-tych-branzach-spadki-liczby-ofert-byly-najwieksze-8541037.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/e/7a53f98bb7a630-948-568-0-1240-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W kwietniu br. mniej ogłoszeń o pracę w internecie; na przełomie trzeciego i czwartego kwartału br. ich liczba może spaść do poziomu sprzed pandemii - wynika z Barometru Ofert Pracy.</p>

## Handel internetowy żyłą złota? Zakupy w sieci napędza inflacja, ale też nowinki technologiczne
 - [https://www.bankier.pl/wiadomosc/Handel-internetowy-zyla-zlota-Zakupy-w-sieci-napedza-inflacja-ale-tez-nowinki-technologiczne-8540960.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Handel-internetowy-zyla-zlota-Zakupy-w-sieci-napedza-inflacja-ale-tez-nowinki-technologiczne-8540960.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/02cd60f9bd62e6-948-567-5-20-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pandemia i lockdowny przyspieszyły rozwój e-commerce, a wiele firm musiała szybko dostosować się do nowej rzeczywistości. Rynek w dalszym ciągu ma przed sobą optymistyczne perspektywy. Strategy&amp;Polska ocenia, że w latach 2021-2027 wartość rynku wzrośnie o 94 mld zł. W ostatnim czasie wzrosty napędza wysoka inflacja, ale motorem są też nowinki technologiczne, które stale poprawiają doświadczenia klientów.</p>

## Sama ochrona z polisy OC nie wystarczy kierowcy. W tych miejscach w Polsce wypadki są wyjątkowo tragiczne
 - [https://www.bankier.pl/wiadomosc/Gdzie-w-Polsce-wypadki-sa-wyjatkowo-krwawe-Sprawdz-mape-8538260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gdzie-w-Polsce-wypadki-sa-wyjatkowo-krwawe-Sprawdz-mape-8538260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/50b6d9adcec316-948-568-7-202-2987-1792.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poszczególne części kraju mocno różnią się stosunkiem liczby ofiar śmiertelnych i wypadków. Sprawdzamy, gdzie wypadki drogowe są najbardziej tragiczne.</p>

## Taniej nie będzie, ale drogie noclegi nie odstraszają Polaków. To najpopularniejsze miejscowości tegorocznych wakacji
 - [https://www.bankier.pl/wiadomosc/Taniej-nie-bedzie-ale-drogie-noclegi-nie-odstraszaja-Polakow-To-najpopularniejsze-miejscowosci-tegorocznych-wakacji-8542595.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Taniej-nie-bedzie-ale-drogie-noclegi-nie-odstraszaja-Polakow-To-najpopularniejsze-miejscowosci-tegorocznych-wakacji-8542595.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-21 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/4/eaa36412e0dd01-948-568-0-230-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kołobrzeg, Gdańsk, Mielno, Jastrzębia Góra, Ostróda, Iława, Zakopane - to najpopularniejsze miejscowości tegorocznych wakacji - wynika z danych portalu rezerwacyjnego Travelist.pl.</p>

