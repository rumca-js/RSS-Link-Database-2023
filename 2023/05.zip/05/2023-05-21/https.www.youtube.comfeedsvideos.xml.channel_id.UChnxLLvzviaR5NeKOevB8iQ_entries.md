# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Introducing: Modular Percussion (Sample Pack)
 - [https://www.youtube.com/watch?v=o7vONWnxZ2Y](https://www.youtube.com/watch?v=o7vONWnxZ2Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2023-05-21 14:42:56+00:00

Get it here: https://redmeansrecording.gumroad.com/l/modperc

I am VERY happy to announce my first sample pack: Modular Percussion!
⭐Over 1000 samples ⭐ Meticulously sampled using voltage fuzzing to create completely unheard-of before sounds ⭐Made for flexibility! ⭐ All one-shots, no loops, no effects ⭐Will work great in hardware samplers ⭐Perfect for techno, microhouse, glitch, IDM, and many more genres that may or may not exist⭐
SAMPLED FROM: 
⭐VPME QD ⭐ Claps, Cowbells, Hihats, Karplus Strong Hits, Kicks, Mallets, Modal Hits, Snares, Tonal Hits
⭐MODBAP TRINITY ⭐Hihats, Toms (sort of), Bursts, Glitches, Clangs, Kicks, Basses, Noise, Snares, Rattles
⭐WINTER PLANKTON ZAPS ⭐51 sampled kits of a dizzying variety of virtual analog percussion and drums
⭐I make samples I want to use in my productions, and I hope you enjoy them too!⭐

Join me on Patreon and get access to music, presets, samples, and a great community: http://bit.ly/rmrpatreon

Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

