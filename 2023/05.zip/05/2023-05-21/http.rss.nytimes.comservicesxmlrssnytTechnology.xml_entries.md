# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Minnesota Passes Bill Seeking to Ensure Minimum Wage for Gig Workers
 - [https://www.nytimes.com/2023/05/21/technology/minnesota-uber-lyft-gig-work.html](https://www.nytimes.com/2023/05/21/technology/minnesota-uber-lyft-gig-work.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-05-21 23:09:36+00:00

Lyft and Uber have opposed the legislation, with Uber threatening to leave the state if it is enacted.

## Uber Suspends DEI Chief After Employees Complain of Insensitivity
 - [https://www.nytimes.com/2023/05/21/business/uber-bo-young-lee-suspended.html](https://www.nytimes.com/2023/05/21/business/uber-bo-young-lee-suspended.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-05-21 22:02:29+00:00

The executive hosted sessions about race and being a white woman that were titled “Don’t Call Me Karen,” prompting an employee uproar.

## China Bans Some Chip Sales of Micron, the US Company
 - [https://www.nytimes.com/2023/05/21/business/china-ban-microchips-micron.html](https://www.nytimes.com/2023/05/21/business/china-ban-microchips-micron.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-05-21 18:02:50+00:00

Many analysts see the move as retaliation for Washington’s efforts to cut off China’s access to high-end chips.

