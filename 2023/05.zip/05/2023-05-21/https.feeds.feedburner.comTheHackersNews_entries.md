# Source:The Hacker News, URL:https://feeds.feedburner.com/TheHackersNews, language:en-US

## PyPI Repository Under Attack: User Sign-Ups and Package Uploads Temporarily Halted
 - [https://thehackernews.com/2023/05/pypi-repository-under-attack-user-sign.html](https://thehackernews.com/2023/05/pypi-repository-under-attack-user-sign.html)
 - RSS feed: https://feeds.feedburner.com/TheHackersNews
 - date published: 2023-05-21 08:58:00+00:00

The maintainers of Python Package Index (PyPI), the official third-party software repository for the Python programming language, have temporarily disabled the ability for users to sign up and upload new packages until further notice.
"The volume of malicious users and malicious projects being created on the index in the past week has outpaced our ability to respond to it in a timely fashion,

