# Source:Tabletop Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ, language:en-US

## What Topics Do YOU Want? - The Every Other Sunday Show
 - [https://www.youtube.com/watch?v=IngPnFlDXVw](https://www.youtube.com/watch?v=IngPnFlDXVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ
 - date published: 2023-05-21 03:31:37+00:00

It's that time again - one of those episodes where I ask for feedback from you, the viewers. What kinds of video topics are you looking for from your Uncle Atom? We'll talk about that and of course, I'll answer your wargaming-related questions. Come have fun!

Vince Venturella and I made another game! Check out Space Station Zero at http://www.spacestationzerogame.com

I'm now a partner on Twitch! I paint minis every Friday morning and Monday night, and sometimes take paint breaks (play video games poorly). Follow me: http://www.twitch.tv/tabletopminions

Official Tabletop Minions t-shirts: http://bit.ly/merchbunker

Help support the channel on Patreon, and get access to the Discord: http://www.patreon.com/tabletopminions

Twitter: http://www.twitter.com/tabletopminions
Instagram: http://www.instagram.com/tabletopminions

