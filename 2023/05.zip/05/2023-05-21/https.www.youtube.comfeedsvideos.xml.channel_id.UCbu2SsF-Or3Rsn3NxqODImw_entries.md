# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## How Twilight Princess SAVED the Zelda Franchise
 - [https://www.youtube.com/watch?v=ta8QYE6ov_Q](https://www.youtube.com/watch?v=ta8QYE6ov_Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-05-21 15:00:43+00:00

While The Legend of Zelda has always been one of Nintendo's top franchises, after The Wind Waker released to GameCube, there were major questions for Nintendo if Zelda would continue to sell. Love it or hate it, Here is how Twilight Princess SAVED the Zelda Franchise.
#zelda #twilightprincess #windwaker 

The Legend of Zelda: Twilight Princess is somewhat controversial in the Zelda fanbase. But, Zelda was starting to struggle before its release. Nintendo was extremely disappointed with how well Zelda sold in both Japan and the West, and after Twilight Princess, the team tried Four Swords Adventure deciding innovations was what gamers were looking for. Unfortunately, it was another massive misstep and failure for Nintendo and Zelda.

So, Eiji Aonuma had a bitter pill to swallow. While he hated the realistic Zelda presentation Nintendo had shown to promote the GameCube, Western reactions had been positive to it. So, he presented a realistic Zelda to Shigeru Miyamoto, and the team went forwards with a more realistic Zelda - hoping this project would succeed. Nintendo doesn't always have the time/money/resources to spend on long development cycles, as revealed by Satoru Iwata, so, hopefully Twilight Princess would succeed. Dave Klein breaks down this story with the help of Manley Reviews.

Timestamps:
0:00 - Intro
0:35 - Shigeru Miyamoto's Influence in Nintendo
1:31 - Zelda and Mario's incredible success
2:25 - Zelda: Ocarina of Time
3:08 - Zelda GameCube Space World Trailer
3:47 - Eiji Aonuma's Reaction
4:15 - The Legend of Zelda: The Wind Waker
5:30 - The Legend of Zelda: Four Swords Adventure
6:26 - Zelda's Downward Trajectory
7:06 - Making Twilight Princess
9:32 - The Nintendo Wii
10:41 - The success of The Legend of Zelda: Twilight Princess
11:38 - How Twilight Princess saved the Zelda franchise

