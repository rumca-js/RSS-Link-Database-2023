# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Alan Wake 2. Aktor głosowy ujawnia datę premiery gry
 - [https://ithardware.pl/aktualnosci/alan_wake_2_aktor_glosowy_ujawnia_date_premiery_gry-27394.html](https://ithardware.pl/aktualnosci/alan_wake_2_aktor_glosowy_ujawnia_date_premiery_gry-27394.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 21:46:46+00:00

<img src="https://ithardware.pl/artykuly/min/27394_1.jpg" />            Gracze z niecierpliwością czekają na premierę gry Alan Wake 2, kt&oacute;rego produkcja nie wydaje się zagrożona, więc nie powinno dojść do op&oacute;źnienia debiutu. Informacją odnośnie wydania produkcji podzielił się aktor...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/alan_wake_2_aktor_glosowy_ujawnia_date_premiery_gry-27394.html">https://ithardware.pl/aktualnosci/alan_wake_2_aktor_glosowy_ujawnia_date_premiery_gry-27394.html</a></p>

## Hogwarts Legacy generuje krocie. Warner Bros. ujawnia dane
 - [https://ithardware.pl/aktualnosci/hogwarts_legacy_generuje_krocie_warner_bros_ujawnia_dane-27393.html](https://ithardware.pl/aktualnosci/hogwarts_legacy_generuje_krocie_warner_bros_ujawnia_dane-27393.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 19:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/27393_1.jpg" />            Hogwarts Legacy to jak na razie najlepsza gra osadzona w magicznym świecie wykreowanym przez J.K. Rowling, kt&oacute;ra generuje Warner Bros. krocie czego dowodzą ostatnie wyniki finansowe firmy. Z drugiej strony produkcja&nbsp;jeżeli chodzi o...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hogwarts_legacy_generuje_krocie_warner_bros_ujawnia_dane-27393.html">https://ithardware.pl/aktualnosci/hogwarts_legacy_generuje_krocie_warner_bros_ujawnia_dane-27393.html</a></p>

## Posiadacze iPhone'ów są bogatsi, dlatego płacą więcej za usługi. No i mamy pozew...
 - [https://ithardware.pl/aktualnosci/posiadacze_iphone_ow_sa_bogatsi_dlatego_placa_wiecej_za_dostawy_no_i_mamy_pozew-27392.html](https://ithardware.pl/aktualnosci/posiadacze_iphone_ow_sa_bogatsi_dlatego_placa_wiecej_za_dostawy_no_i_mamy_pozew-27392.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 18:14:40+00:00

<img src="https://ithardware.pl/artykuly/min/27392_1.jpg" />            Posiadacze telefon&oacute;w Apple iOS są przeciętnie bogatsi niż użytkownicy Androida. Przynajmniej tak twierdzi firma&nbsp;DoorDash, kt&oacute;rej usługi są droższe dla posiadaczy iPhone'&oacute;w, niż smartfon&oacute;w z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/posiadacze_iphone_ow_sa_bogatsi_dlatego_placa_wiecej_za_dostawy_no_i_mamy_pozew-27392.html">https://ithardware.pl/aktualnosci/posiadacze_iphone_ow_sa_bogatsi_dlatego_placa_wiecej_za_dostawy_no_i_mamy_pozew-27392.html</a></p>

## W Niemczech powstaje największy w Europie budynek wydrukowany w 3D
 - [https://ithardware.pl/aktualnosci/w_niemczech_powstaje_najwiekszy_w_europie_budynek_wydrukowany_w_3d-27391.html](https://ithardware.pl/aktualnosci/w_niemczech_powstaje_najwiekszy_w_europie_budynek_wydrukowany_w_3d-27391.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 17:57:27+00:00

<img src="https://ithardware.pl/artykuly/min/27391_1.jpg" />            Niemcy będą miały największy w Europie budynek zbudowany przy użyciu technologii druku 3D. Jest to&nbsp;centrum danych, kt&oacute;re wyr&oacute;żnia się nie tylko swoją funkcjonalnością, ale także oryginalnym projektem architektonicznym.

W...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/w_niemczech_powstaje_najwiekszy_w_europie_budynek_wydrukowany_w_3d-27391.html">https://ithardware.pl/aktualnosci/w_niemczech_powstaje_najwiekszy_w_europie_budynek_wydrukowany_w_3d-27391.html</a></p>

## Gotion obiecuje akumulatory LMFP 240 Wh/kg bez niklu i kobaltu z zasięgiem 1000 km
 - [https://ithardware.pl/aktualnosci/gotion_obiecuje_akumulatory_lmfp_240_wh_kg_bez_niklu_i_kobaltu_z_zasiegiem_1000_km-27390.html](https://ithardware.pl/aktualnosci/gotion_obiecuje_akumulatory_lmfp_240_wh_kg_bez_niklu_i_kobaltu_z_zasiegiem_1000_km-27390.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 17:55:50+00:00

<img src="https://ithardware.pl/artykuly/min/27390_1.png" />            Przewiduje&nbsp;się, że ważnym kamieniem milowym w rozwoju akumulator&oacute;w będą ogniwa związk&oacute;w metalicznych fluoro fosforanowych (LMFP). Firma Gotion dołącza do grona przedsiębiorstw pracujących nad tymi ogniwami, a ich unikalne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gotion_obiecuje_akumulatory_lmfp_240_wh_kg_bez_niklu_i_kobaltu_z_zasiegiem_1000_km-27390.html">https://ithardware.pl/aktualnosci/gotion_obiecuje_akumulatory_lmfp_240_wh_kg_bez_niklu_i_kobaltu_z_zasiegiem_1000_km-27390.html</a></p>

## ASUS wydał aktualizację, która odbiera użytkownikom routerów dostęp do sieci
 - [https://ithardware.pl/aktualnosci/asus_wydal_aktualizacje_ktora_odbiera_uzytkownikom_routerow_dostep_do_sieci-27389.html](https://ithardware.pl/aktualnosci/asus_wydal_aktualizacje_ktora_odbiera_uzytkownikom_routerow_dostep_do_sieci-27389.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 16:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/27389_1.jpg" />            ASUS zirytował tysiące użytkownik&oacute;w swoich router&oacute;w aktualizacją, kt&oacute;ra sprawiła, że urządzenia przestały łączyć się z siecią. Firma przeprosiła klient&oacute;w za problem i znalazła rozwiązanie kłopotu.

Routery...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/asus_wydal_aktualizacje_ktora_odbiera_uzytkownikom_routerow_dostep_do_sieci-27389.html">https://ithardware.pl/aktualnosci/asus_wydal_aktualizacje_ktora_odbiera_uzytkownikom_routerow_dostep_do_sieci-27389.html</a></p>

## AmpereOne - nowe procesory z niesamowitą ilością rdzeni i 8-kanałowym kontrolerem DDR5
 - [https://ithardware.pl/aktualnosci/ampereone_nowe_procesory_z_niesamowita_iloscia_rdzeni_i_8_kanalowym_kontrolerem_ddr5-27388.html](https://ithardware.pl/aktualnosci/ampereone_nowe_procesory_z_niesamowita_iloscia_rdzeni_i_8_kanalowym_kontrolerem_ddr5-27388.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 15:58:10+00:00

<img src="https://ithardware.pl/artykuly/min/27388_1.jpg" />            Ampere Computing przedstawia swoją najnowszą generację procesor&oacute;w serwerowych, nazwaną AmpereOne. Ta nowa seria procesor&oacute;w wprowadza znaczący wzrost w liczbie rdzeni, umożliwiając teraz konfigurację modeli z imponującymi 192...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ampereone_nowe_procesory_z_niesamowita_iloscia_rdzeni_i_8_kanalowym_kontrolerem_ddr5-27388.html">https://ithardware.pl/aktualnosci/ampereone_nowe_procesory_z_niesamowita_iloscia_rdzeni_i_8_kanalowym_kontrolerem_ddr5-27388.html</a></p>

## Tom Hanks: Sztuczna inteligencja „pozwoli mi grać” nawet po śmierci
 - [https://ithardware.pl/aktualnosci/tom_hanks_sztuczna_inteligencja_pozwoli_mi_grac_nawet_po_smierci-27387.html](https://ithardware.pl/aktualnosci/tom_hanks_sztuczna_inteligencja_pozwoli_mi_grac_nawet_po_smierci-27387.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 15:36:20+00:00

<img src="https://ithardware.pl/artykuly/min/27387_1.jpg" />            W jednym z niedawnych odcink&oacute;w podcastu z Adama Buxtona, poruszono temat wpływu sztucznej inteligencji na świat aktorstwa. Znany aktor Tom Hanks podzielił się swoimi przemyśleniami na temat tego, jak taka technologia mogłaby umożliwić mu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tom_hanks_sztuczna_inteligencja_pozwoli_mi_grac_nawet_po_smierci-27387.html">https://ithardware.pl/aktualnosci/tom_hanks_sztuczna_inteligencja_pozwoli_mi_grac_nawet_po_smierci-27387.html</a></p>

## Nawet testy NVIDII sugerują, że 8 GB VRAM to czasem za mało do 1080p
 - [https://ithardware.pl/aktualnosci/nawet_testy_nvidii_sugeruja_ze_8_gb_vram_to_czasem_za_malo_do_1080p-27385.html](https://ithardware.pl/aktualnosci/nawet_testy_nvidii_sugeruja_ze_8_gb_vram_to_czasem_za_malo_do_1080p-27385.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 14:06:50+00:00

<img src="https://ithardware.pl/artykuly/min/27385_1.jpg" />            Bolączką nowych kart graficznych może być niewystarczająca ilość VRAM-u. Jak wynika z wewnętrznych test&oacute;w serii GeForce RTX 4060/Ti, w niekt&oacute;rych przypadkach, 8 GB pamięci wideo może zwyczajnie nie wystarczyć, aby cieszyć się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nawet_testy_nvidii_sugeruja_ze_8_gb_vram_to_czasem_za_malo_do_1080p-27385.html">https://ithardware.pl/aktualnosci/nawet_testy_nvidii_sugeruja_ze_8_gb_vram_to_czasem_za_malo_do_1080p-27385.html</a></p>

## BWM patentuje system do grania w samochodzie. Ma on działać, ale tylko pod pewnym warunkiem
 - [https://ithardware.pl/aktualnosci/bwm_patentuje_system_do_grania_w_samochodzie_ma_on_dzialac_ale_tylko_pod_pewnym_warunkiem-27386.html](https://ithardware.pl/aktualnosci/bwm_patentuje_system_do_grania_w_samochodzie_ma_on_dzialac_ale_tylko_pod_pewnym_warunkiem-27386.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 13:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/27386_1.jpg" />            BMW jedna z najbardziej rozpoznawalnych marek samochod&oacute;w na świecie opatentowała rozwiązanie skierowane do os&oacute;b, kt&oacute;re lubią grać podczas podr&oacute;ży.&nbsp;Ten patent pozwoli jednemu pasażerowi cieszyć się grą dla...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/bwm_patentuje_system_do_grania_w_samochodzie_ma_on_dzialac_ale_tylko_pod_pewnym_warunkiem-27386.html">https://ithardware.pl/aktualnosci/bwm_patentuje_system_do_grania_w_samochodzie_ma_on_dzialac_ale_tylko_pod_pewnym_warunkiem-27386.html</a></p>

## Chcesz kupić Steam Deck? O tym musisz wiedzieć. Poradnik i optymalizacja konsoli Valve
 - [https://ithardware.pl/poradniki/steam_deck_porady_wskazowki_optymalizacja-27371.html](https://ithardware.pl/poradniki/steam_deck_porady_wskazowki_optymalizacja-27371.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 11:53:10+00:00

<img src="https://ithardware.pl/artykuly/min/27371_1.jpg" />            Poradnik dla początkujących - od czego zacząć po zakupie Steam Decka

Kusząca cena konsoli Steam Deck w Polsce to jeden z gł&oacute;wnych czynnik&oacute;w, dlaczego właśnie konsumenci tak chętnie sięgają po to urządzenie. Za podstawową 64...
            <p>Pełna wersja strony <a href="https://ithardware.pl/poradniki/steam_deck_porady_wskazowki_optymalizacja-27371.html">https://ithardware.pl/poradniki/steam_deck_porady_wskazowki_optymalizacja-27371.html</a></p>

## Apple zepsuło przejściówkę za 239 złotych... aktualizacją
 - [https://ithardware.pl/aktualnosci/apple_zepsulo_przejsciowke_za_239_zlotych_aktualizacja-27384.html](https://ithardware.pl/aktualnosci/apple_zepsulo_przejsciowke_za_239_zlotych_aktualizacja-27384.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 11:52:10+00:00

<img src="https://ithardware.pl/artykuly/min/27384_1.jpg" />            Instalacja niedawno wypuszczonej aktualizacji iOS 16.5 oraz iPadOS 16.5 może nie być najlepszym wyborem dla os&oacute;b, kt&oacute;re korzystają z pewnego akcesorium od Apple. Okazuje się, że nowe wersje tych dw&oacute;ch system&oacute;w psują...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_zepsulo_przejsciowke_za_239_zlotych_aktualizacja-27384.html">https://ithardware.pl/aktualnosci/apple_zepsulo_przejsciowke_za_239_zlotych_aktualizacja-27384.html</a></p>

## Referencyjny Radeon RX 7600 pozuje do zdjęć. Jest niewielki
 - [https://ithardware.pl/aktualnosci/referencyjny_radeon_rx_7600_pozuje_do_zdjec_jest_niewielki-27381.html](https://ithardware.pl/aktualnosci/referencyjny_radeon_rx_7600_pozuje_do_zdjec_jest_niewielki-27381.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 10:50:50+00:00

<img src="https://ithardware.pl/artykuly/min/27381_1.jpg" />            Do internetu trafiły zdjęcia referencyjnej wersji Radeona RX 7600 (Made by AMD). Karta jest naprawdę niewielka, ponieważ mierzy niespełna 21 cm. Na szczęście układ chłodzenia wyposażono nie w jeden, a w dwa wentylatory. Nie jest tylko jasne,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/referencyjny_radeon_rx_7600_pozuje_do_zdjec_jest_niewielki-27381.html">https://ithardware.pl/aktualnosci/referencyjny_radeon_rx_7600_pozuje_do_zdjec_jest_niewielki-27381.html</a></p>

## Padł nowy rekord w podkręcaniu pamięci DDR5
 - [https://ithardware.pl/aktualnosci/padl_nowy_rekord_w_podkrecaniu_pamieci_ddr5-27380.html](https://ithardware.pl/aktualnosci/padl_nowy_rekord_w_podkrecaniu_pamieci_ddr5-27380.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-21 10:20:20+00:00

<img src="https://ithardware.pl/artykuly/min/27380_1.jpg" />            Overclocker o pseudonimie&nbsp;Seby9123 ustanowił nowy rekord świata w podkręcaniu pamięci DDR5. W tym celu konieczne było wykorzystanie ekstremalnego sposobu chłodzenie ciekłym azotem. Mimo, że op&oacute;źnienia nie wyglądają najlepiej,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/padl_nowy_rekord_w_podkrecaniu_pamieci_ddr5-27380.html">https://ithardware.pl/aktualnosci/padl_nowy_rekord_w_podkrecaniu_pamieci_ddr5-27380.html</a></p>

