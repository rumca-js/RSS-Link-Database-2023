# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## 500+ na hulajnogach LIVE #1
 - [https://www.youtube.com/watch?v=OiDetmbjeeI](https://www.youtube.com/watch?v=OiDetmbjeeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2023-05-21 15:38:17+00:00



## Na podbój Niemiec! 500+ na hulajnogach
 - [https://www.youtube.com/watch?v=pFr7s83klgU](https://www.youtube.com/watch?v=pFr7s83klgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2023-05-21 15:00:37+00:00

Nasza strona we współpracy z Odoo, na której możecie śledzić trasę hulajnogową: https://www.500plusnahulajnogach.pl
Tutaj dowiecie się więcej o samodzielnej budowie strony na Odoo - https://www.odoo.com/r/EWsK

Testowane hulajnogi:
Xiaomi - https://bit.ly/4371blg
Motus - https://bit.ly/45n95bU
Kugoo - https://bit.ly/3WrYw3A


W odcinku:
00:00 Wstęp
00:39 Przygotowania i sprzęt
03:19 Trasa do przejechania
03:50 Wielki finał – Centrum Testów w Gdyni
04:08 Zawodnicy: Xiaomi Mi Electric Scooter 3 vs Motus Scooty 10 Lite vs Kugoo Kirin S1 Pro
06:30 Kompletowanie sprzętu
07:19 Wyjazd i droga do Peenemünde
08:37 Tajemniczy kierowca – Andrzej
11:28 Fragment sponsorowany – Odoo
13:17 Ośrodek wypoczynkowy w Peenemünde - zakończenie

