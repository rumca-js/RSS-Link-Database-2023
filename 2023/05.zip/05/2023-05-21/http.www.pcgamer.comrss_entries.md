# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Filename forensics suggest there has always been a PC version of Bloodborne—but that doesn't mean we can ever play it
 - [https://www.pcgamer.com/filename-forensics-suggest-there-has-always-been-a-pc-version-of-bloodbornebut-that-doesnt-mean-we-can-ever-play-it](https://www.pcgamer.com/filename-forensics-suggest-there-has-always-been-a-pc-version-of-bloodbornebut-that-doesnt-mean-we-can-ever-play-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-05-21 22:14:57+00:00

Longtime Souls series dataminer Lance McDonald has discussed this build before, but also noticed fresh evidence on the Bloodborne Wiki.

## The Dead Cells board game is off to a promising crowdfunding start
 - [https://www.pcgamer.com/the-dead-cells-board-game-is-off-to-a-promising-crowdfunding-start](https://www.pcgamer.com/the-dead-cells-board-game-is-off-to-a-promising-crowdfunding-start)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-05-21 22:04:16+00:00

Good designers, good company, maybe even a good game.

## I could barely keep it together in this free game where you're the president trying to hide that he's an alien
 - [https://www.pcgamer.com/i-could-barely-keep-it-together-in-this-free-game-where-youre-the-president-trying-to-hide-that-hes-an-alien](https://www.pcgamer.com/i-could-barely-keep-it-together-in-this-free-game-where-youre-the-president-trying-to-hide-that-hes-an-alien)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-05-21 20:49:35+00:00

Extremely relatable body snatcher-masquerading-as-human-politician content.

## Here's the first trailer for System Shock 2: Enhanced Edition
 - [https://www.pcgamer.com/heres-the-first-trailer-for-system-shock-2-enhanced-edition](https://www.pcgamer.com/heres-the-first-trailer-for-system-shock-2-enhanced-edition)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-05-21 17:12:42+00:00

Observe and be amazed, flesh-thing.

## Great moments in PC gaming: Reaching Warrior rank in Tekken 7
 - [https://www.pcgamer.com/great-moments-in-pc-gaming-reaching-warrior-rank-in-tekken-7](https://www.pcgamer.com/great-moments-in-pc-gaming-reaching-warrior-rank-in-tekken-7)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-05-21 06:25:24+00:00

The first major milestone for any budding fighting game player.

## Mass Effect: Andromeda's creative director still wishes it had got a sequel
 - [https://www.pcgamer.com/mass-effect-andromedas-creative-director-still-wishes-it-had-got-a-sequel](https://www.pcgamer.com/mass-effect-andromedas-creative-director-still-wishes-it-had-got-a-sequel)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-05-21 05:07:27+00:00

Mac Walters says Andromeda was developed during "a weird phase in the industry where a lot of people were saying quantity was quality".

## Today's Wordle hint and answer #701: Sunday, May 21
 - [https://www.pcgamer.com/wordle-today-hint-answer-701-may-21](https://www.pcgamer.com/wordle-today-hint-answer-701-may-21)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-05-21 04:07:44+00:00

A hint to help you out and today's Wordle answer if you need it.

## Peter Molyneux's Magic Carpet was a game of violent chess, and a true one-off
 - [https://www.pcgamer.com/peter-molyneuxs-magic-carpet-was-a-game-of-violent-chess-and-a-true-one-off](https://www.pcgamer.com/peter-molyneuxs-magic-carpet-was-a-game-of-violent-chess-and-a-true-one-off)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-05-21 03:41:19+00:00

In this classic feature, Ed Ricketts beats the dust off Magic Carpet and takes it for a spin.

## Despite being dead for 20 years, Warhammer Online is hosting a live event on a private server
 - [https://www.pcgamer.com/despite-being-dead-for-20-years-warhammer-online-is-hosting-a-live-event-on-a-private-server](https://www.pcgamer.com/despite-being-dead-for-20-years-warhammer-online-is-hosting-a-live-event-on-a-private-server)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-05-21 03:14:55+00:00

For a dead MMO, Warhammer Online shows plenty of signs of life.

