# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## MOTD2 analysis: How Erling Haaland helped Manchester City win Premier League title
 - [https://www.bbc.co.uk/sport/av/football/65667595?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/65667595?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 23:16:30+00:00

Match of the Day 2 pundits Ben Mee, Jermaine Jenas and Micah Richards discuss Erling Haaland's "outstanding" impact on Manchester City's Premier League title win.

## Explaining the 'how' - the launch of BBC Verify
 - [https://www.bbc.co.uk/news/uk-65650822?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65650822?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 23:12:36+00:00

BBC News CEO Deborah Turness introduces Verify, where BBC journalists share their evidence gathering.

## Manchester United: 'Special night' - but Red Devils 'need miracle' to win WSL title
 - [https://www.bbc.co.uk/sport/football/65664802?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65664802?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 22:51:11+00:00

Marc Skinner says he would have "bitten your hands off" to still be in with a chance of winning the Women's Super League title on the last day.

## US PGA Championship 2023: Brooks Koepka beats Scottie Scheffler and Viktor Hovland at Oak Hill
 - [https://www.bbc.co.uk/sport/golf/65666788?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/65666788?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 22:50:04+00:00

A resurgent Brooks Koepka holds off Scottie Scheffler and Viktor Hovland to claim his third US PGA Championship title at Oak Hill.

## Manchester City: Pep Guardiola 'the difference maker' - but is this his best team yet?
 - [https://www.bbc.co.uk/sport/football/65667251?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65667251?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 21:25:44+00:00

Pep Guardiola is described as "the difference maker" after leading Manchester City to a third successive Premier League title - but is this his best team yet?

## Titanic: Amateur radio heard SOS in Welsh town 2,000 miles away
 - [https://www.bbc.co.uk/news/uk-wales-65398807?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-65398807?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 20:51:20+00:00

Artie Moore's homemade station picked up the ship's distress signals - but nobody believed him.

## Spanish football has racism problem, Madrid boss says
 - [https://www.bbc.co.uk/sport/football/65666613?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65666613?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 20:28:56+00:00

Real Madrid forward Vinicius Junior is sent off late in their defeat at Valencia after being subjected to racist chants from fans at the Mestalla.

## Manchester United 2-1 Manchester City: Lucia Garcia goal keeps Red Devils' WSL title hopes alive
 - [https://www.bbc.co.uk/sport/football/65586930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65586930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 20:04:09+00:00

Lucia Garcia scores an injury-time winner in a dramatic derby to keep Manchester United's faint Women's Super League title hopes alive.

## Manchester City must win the Champions League 'to be considered one of best' - Pep Guardiola
 - [https://www.bbc.co.uk/sport/football/65666407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65666407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 19:25:41+00:00

Manchester City boss Pep Guardiola says his Premier League champions have to win the Champions League to be "considered one of the best teams".

## Manchester City 1-0 Chelsea: Pep Guardiola says his side's third successive title 'extraordinary'
 - [https://www.bbc.co.uk/sport/av/football/65635503?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/65635503?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 19:16:29+00:00

Manchester City manager Pep Guardiola says his side's third successive Premier League title win is "extraordinary" after their 1-0 victory over Chelsea.

## Watch: Activists turn Trevi Fountain water black
 - [https://www.bbc.co.uk/news/world-europe-65666775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65666775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 17:25:00+00:00

Climate change protesters Last Generation pour "vegetable charcoal" into the Rome landmark.

## Glasgow City clinch title with dramatic late winner
 - [https://www.bbc.co.uk/sport/football/65665847?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65665847?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 17:08:38+00:00

Glasgow City secure their 16th Scottish title after beating reigning champions Rangers at Ibrox thanks to Lauren Davidson's stoppage-time winner.

## Manchester City 1-0 Chelsea: Blues celebrate third straight title with home win
 - [https://www.bbc.co.uk/sport/football/65586964?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65586964?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 16:56:24+00:00

Julian Alvarez's goal helps Manchester City celebrate a third successive Premier League title triumph with victory over Chelsea.

## Greece election: Centre-right leads but no majority, exit poll suggests
 - [https://www.bbc.co.uk/news/world-europe-65666261?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65666261?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 16:50:49+00:00

Centre-right Kyriakos Mitsotakis will struggle to form a coalition despite lead, exit poll suggests.

## West Ham 3-1 Leeds: Sam Allardyce accepts survival a 'big ask' after defeat
 - [https://www.bbc.co.uk/sport/football/65661366?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65661366?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 16:42:59+00:00

Leeds manager Sam Allardyce accepts it will be a "big ask" to secure Premier League survival following Sunday's loss 3-1 loss at West Ham.

## Brighton & Hove Albion 3-1 Southampton: Seagulls secure European football with win
 - [https://www.bbc.co.uk/sport/football/65586962?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65586962?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 16:06:12+00:00

Evan Ferguson scores twice in the first half as Brighton beat Southampton in the Premier League to secure European football for the first time in their history.

## Challenge Cup: Castleford 8-32 Hull FC - Adam Swift hat-trick helps Black and Whites knock out Tigers
 - [https://www.bbc.co.uk/sport/rugby-league/65615495?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-league/65615495?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 15:59:27+00:00

Winger Adam Swift scores three of the six tries as Hull FC win at Castleford to reach the Challenge Cup quarter-finals.

## Ten in hospital after bus roof cut off in Glasgow bridge crash
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-65665113?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-65665113?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 15:38:02+00:00

A number of other people were treated at the scene of the smash in Glasgow's south side.

## Chris Mason: Rishi Sunak's view from the Summit? Trouble back home
 - [https://www.bbc.co.uk/news/uk-politics-65665693?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65665693?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 15:36:10+00:00

The PM wrapped up an intense few days of diplomacy at the G7 with questions about Suella Braverman looming.

## West Ham United 3-1 Leeds United: Whites stay in relegation zone after defeat
 - [https://www.bbc.co.uk/sport/football/65586966?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65586966?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 14:53:59+00:00

Leeds United's Premier League fate is hanging by a thread as West Ham come from behind to secure victory at London Stadium.

## Kurt Cobain: Guitar smashed by Nirvana frontman sells for nearly $600,000
 - [https://www.bbc.co.uk/news/world-us-canada-65664330?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65664330?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 14:35:58+00:00

The black Stratocaster destroyed by Nirvana's frontman is signed by all three band members.

## WSL: Chelsea close in on title after 2-0 win over Arsenal - highlights
 - [https://www.bbc.co.uk/sport/av/football/65664858?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/65664858?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 13:57:11+00:00

Watch highlights as Chelsea defeat Arsenal 2-0 leaving them five points clear at the top of the table and on the brink of another WSL title.

## CBI banned alcohol-only events after staff party, says ex-chief
 - [https://www.bbc.co.uk/news/business-65662892?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65662892?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 13:31:42+00:00

Former boss Dame Carolyn Fairbairn claims she took action following poor behaviour at the event.

## Labour's NHS plan will offer patients more choice, Wes Streeting says
 - [https://www.bbc.co.uk/news/uk-politics-65663464?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65663464?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 12:54:29+00:00

Shadow health secretary says regional waiting lists could help people get hospital treatment quicker.

## France attack: Kalashnikov assault on car kills three in Marseille
 - [https://www.bbc.co.uk/news/world-europe-65664329?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65664329?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 12:30:43+00:00

The killings near a nightclub come amid a spike in drug violence in France's second-largest city.

## Government rules out more help on energy bills
 - [https://www.bbc.co.uk/news/business-65662895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65662895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 11:51:33+00:00

The price cap on gas and electricity is set to fall, but at about £2,000 remains historically high.

## Andy Murray withdraws from French Open to prioritise Wimbledon
 - [https://www.bbc.co.uk/sport/tennis/65663508?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65663508?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 11:31:54+00:00

Britain's Andy Murray withdraws from the French Open and will prioritise the grass-court season instead.

## Missing Bath grandmother found dead on Greek island
 - [https://www.bbc.co.uk/news/uk-england-somerset-65663406?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-somerset-65663406?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 10:58:46+00:00

Susan Hart, 74, was on holiday on the island of Telendos when she disappeared three weeks ago.

## Watch: Japan riot police pin G7 protesters to ground in violent scuffle
 - [https://www.bbc.co.uk/news/world-asia-65663384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65663384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 10:58:43+00:00

Violence breaks out at the summit in Hiroshima, Japan.

## Hackney housing: 'We had mushrooms growing from the ceiling'
 - [https://www.bbc.co.uk/news/uk-england-london-65658011?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-65658011?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 10:16:11+00:00

A woman has told the BBC about the impact problems in her flat are having on her and her young sons

## Police probe into ex-SNP council leader over sex assault claim
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-65662871?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-65662871?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 09:59:03+00:00

An allegation of sexual assault has been made against ex-North Lanarkshire council leader Jordan Linden.

## Chantelle Cameron v Katie Taylor: Undisputed champion stuns Taylor in Dublin - highlights
 - [https://www.bbc.co.uk/sport/av/boxing/65663633?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/boxing/65663633?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 09:51:08+00:00

Watch highlights as Chantelle Cameron beats Katie Taylor to retain her undisputed light-welterweight crown in Dublin.

## O'Gara targets Ireland job after La Rochelle triumph
 - [https://www.bbc.co.uk/sport/rugby-union/65661051?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65661051?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 09:35:52+00:00

Ronan O'Gara says he wants to coach his native Ireland after guiding La Rochelle to a second successive Heineken Champions Cup success.

## Barking dogs help owners escape Takeley house fire
 - [https://www.bbc.co.uk/news/uk-england-essex-65663297?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-65663297?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 08:56:39+00:00

The blaze destroyed the detached home but the occupants managed to flee unharmed.

## G7: Taking a stand against China's economic coercion
 - [https://www.bbc.co.uk/news/world-asia-65662720?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65662720?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 08:06:18+00:00

Worried of being held hostage economically by China, the G7 spells out its plan to escape.

## Devin Haney beats Vasiliy Lomachenko to retain undisputed lightweight world titles
 - [https://www.bbc.co.uk/sport/boxing/65620856?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/65620856?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 07:55:35+00:00

Undisputed world lightweight champion Devin Haney retains his titles by beating Vasiliy Lomachenko on points in Las Vegas.

## Bakhmut: Zelensky indicates Russia has control of city
 - [https://www.bbc.co.uk/news/world-europe-65662563?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65662563?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 07:04:27+00:00

Asked on Sunday whether Ukraine had control of the city, Ukraine's president said: "I think not."

## NI council elections 2023: Restore Stormont Executive now, Sinn Féin urges
 - [https://www.bbc.co.uk/news/uk-northern-ireland-65660650?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-65660650?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 06:13:48+00:00

The party is now the largest in Northern Ireland's local government as well as its assembly.

## From snubbed to main spotlight - Cameron emerges as pound-for-pound contender
 - [https://www.bbc.co.uk/sport/boxing/65661897?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/65661897?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 05:21:14+00:00

Chantelle Cameron is now in the conversation for the best female fighter in the world after a career-defining victory over Katie Taylor in Dublin.

## At least nine killed in El Salvador stadium stampede
 - [https://www.bbc.co.uk/news/world-latin-america-65662194?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-65662194?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 04:39:15+00:00

The disaster happened during a clash between two rival football sides in the capital San Salvador.

## Sudan conflict: Warring factions agree seven-day ceasefire, US says
 - [https://www.bbc.co.uk/news/world-africa-65661257?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65661257?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 04:22:30+00:00

US State Department urges military leaders to uphold agreement after past failed peace attempts.

## Phillip Schofield and Holly Willoughby: What went wrong for This Morning pair?
 - [https://www.bbc.co.uk/news/entertainment-arts-65658938?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65658938?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 00:49:16+00:00

The presenter left ITV's This Morning after reports of a strained relationship with Holly Willoughby.

## The Papers: Schofield quits This Morning and Braverman 'cover-up'
 - [https://www.bbc.co.uk/news/blogs-the-papers-65661337?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-65661337?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-21 00:11:30+00:00

Phillip Schofield's resignation from ITV's popular daytime show and the home secretary's speeding leads the front pages.

