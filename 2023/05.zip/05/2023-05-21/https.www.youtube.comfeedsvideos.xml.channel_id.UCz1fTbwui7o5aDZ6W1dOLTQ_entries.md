# Source:Literature Devil, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ, language:en-US

## Reviewing A Million Dollar Indie Comic! Cyberfrog: Rekt Planet (Graphic Novel Review and Critique)
 - [https://www.youtube.com/watch?v=M08dBZCpDQ4](https://www.youtube.com/watch?v=M08dBZCpDQ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ
 - date published: 2023-05-21 16:06:29+00:00

I'll be covering a titan of the indie crowdfunding scene. A comic that raised well over a million dollars, and written by comics veteran Ethan Van Sciver. The long awaited sequel to the groundbreaking crowdfunded comic Cyberfrog: Blood Honey has finally arrived. So how does it fair compared to the previous installment? Let's find out, shall we?

Get Dr. Alpha: Dead Man's Lullaby Vol. 1 here: https://www.indiegogo.com/projects/dr-alpha-dead-man-s-lullaby-vol-1/x/22169562#/

