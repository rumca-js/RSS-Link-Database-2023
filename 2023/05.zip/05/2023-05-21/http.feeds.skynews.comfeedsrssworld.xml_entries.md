# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Real Madrid star says Spain's top league 'belongs to the racists' after pointing out abusers
 - [https://news.sky.com/story/real-madrid-star-vinicius-junior-says-spains-la-liga-belongs-to-the-racists-after-pointing-out-abusers-during-match-12886586](https://news.sky.com/story/real-madrid-star-vinicius-junior-says-spains-la-liga-belongs-to-the-racists-after-pointing-out-abusers-during-match-12886586)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-21 22:08:00+00:00

Real Madrid star Vinicius Junior has claimed racism is "normal" in Spain's top league after fans allegedly targeted him with abusive chants.

## Flights to Sicily suspended as Mount Etna spews volcanic ash onto runway
 - [https://news.sky.com/story/mount-etna-eruption-forces-grounding-of-flights-at-sicilys-catania-airport-12886506](https://news.sky.com/story/mount-etna-eruption-forces-grounding-of-flights-at-sicilys-catania-airport-12886506)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-21 19:40:00+00:00

Flights to eastern Sicily were disrupted on Sunday after the nearby Mount Etna volcano began to erupt, tipping black ash onto runways and vehicles.

## Italian PM visits flood stricken areas after 36,000 evacuated
 - [https://news.sky.com/story/italian-pm-giorgia-meloni-visits-floods-after-36000-forced-from-their-homes-12886333](https://news.sky.com/story/italian-pm-giorgia-meloni-visits-floods-after-36000-forced-from-their-homes-12886333)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-21 17:12:00+00:00

The Italian prime minister cut short her trip to Japan for the G7 summit to visit flood-stricken areas of northern Italy, where thousands have been uprooted from their homes.

## Zelenskyy's visit to the G7 has paid dividends - he can fly home confident in the West's support
 - [https://news.sky.com/story/volodymyr-zelenskyy-can-fly-home-from-the-g7-confident-in-the-wests-support-12886047](https://news.sky.com/story/volodymyr-zelenskyy-can-fly-home-from-the-g7-confident-in-the-wests-support-12886047)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-21 12:59:00+00:00

"Russia will feel it when our counteroffensive comes". The warning from President Volodymyr Zelenskyy, who has now completed diplomatic preparations for the long awaited Ukrainian counterattack.

## Russian control of 'kill box' Bakhmut comes at a high cost to Kremlin war machine
 - [https://news.sky.com/story/ukraine-war-russian-control-of-kill-box-bakhmut-comes-at-a-high-cost-to-kremlin-war-machine-12885976](https://news.sky.com/story/ukraine-war-russian-control-of-kill-box-bakhmut-comes-at-a-high-cost-to-kremlin-war-machine-12885976)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-21 11:11:00+00:00

Even as Ukrainian fighters remain in Bakhmut, for all intents and purposes the city is now effectively controlled by Russia.

## China poses 'biggest challenge' to global security - PM
 - [https://news.sky.com/story/rishi-sunak-china-poses-biggest-challenge-to-global-security-12885792](https://news.sky.com/story/rishi-sunak-china-poses-biggest-challenge-to-global-security-12885792)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-21 05:29:00+00:00

China poses "the biggest challenge" to global security, Rishi Sunak has said at the end of a G7 summit.

## At least nine dead after football fans 'smothered' in stampede at stadium
 - [https://news.sky.com/story/el-salvador-at-least-nine-dead-after-football-fans-smothered-in-stampede-at-stadium-12885783](https://news.sky.com/story/el-salvador-at-least-nine-dead-after-football-fans-smothered-in-stampede-at-stadium-12885783)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-21 03:50:00+00:00

At least nine people have been killed and dozens more are injured after being "smothered" during a stampede at a football stadium in El Salvador.

## Sudan's warring factions agree to new ceasefire
 - [https://news.sky.com/story/sudans-warring-factions-agree-to-seven-day-ceasefire-12885766](https://news.sky.com/story/sudans-warring-factions-agree-to-seven-day-ceasefire-12885766)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-21 00:16:00+00:00

Sudan's warring factions have agreed to a new seven-day ceasefire.

