# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## Canada in Short Supply of Housing; Industry Calls for Cuts to Taxes, Fees
 - [https://www.theepochtimes.com/canada-in-short-supply-of-housing-industry-calls-for-cuts-to-taxes-fees_5281450.html](https://www.theepochtimes.com/canada-in-short-supply-of-housing-industry-calls-for-cuts-to-taxes-fees_5281450.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 23:00:46+00:00

Mountains loom behind homes under construction in Canmore, Alta., on April 24, 2023. (The Canadian Press/Jeff McIntosh)

## SpaceX Launches Saudi Astronauts on Private Flight to International Space Station
 - [https://www.theepochtimes.com/spacex-launches-saudi-astronauts-to-international-space-station_5281346.html](https://www.theepochtimes.com/spacex-launches-saudi-astronauts-to-international-space-station_5281346.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 22:30:31+00:00

A SpaceX Falcon 9 rocket, with the Dragon capsule and a crew of four private astronauts, lifts off from pad 39A, at the Kennedy Space Center in Cape Canaveral, Fla., on May 21, 2023. (John Raoux/AP Photo)

## Canada Considers Regulating Products Containing ‘Forever Chemicals’ Deemed Harmful to Health, Environment
 - [https://www.theepochtimes.com/canada-considers-regulating-products-containing-forever-chemicals-deemed-harmful-to-health-environment_5281225.html](https://www.theepochtimes.com/canada-considers-regulating-products-containing-forever-chemicals-deemed-harmful-to-health-environment_5281225.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 22:14:16+00:00

A restaurant worker packs food in a biodegradable and compostable container to fill a food delivery order in Mexico City on Jan. 7, 2021. (Photo by PEDRO PARDO/AFP via Getty Images)

## Michael Taube: Canada Needs a Public Inquiry on Foreign Interference, Not a Special Rapporteur With a ‘Fake Job’
 - [https://www.theepochtimes.com/michael-taube-canada-needs-a-public-inquiry-on-foreign-interference-not-a-special-rapporteur-with-a-fake-job_5280438.html](https://www.theepochtimes.com/michael-taube-canada-needs-a-public-inquiry-on-foreign-interference-not-a-special-rapporteur-with-a-fake-job_5280438.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 21:45:51+00:00

The Chinese embassy in Ottawa in a file photo. (The Epoch Tiems)

## Meteorites Found in Canada Cannot Be Removed From the Country Without Permit
 - [https://www.theepochtimes.com/meteorites-found-in-canada-cannot-be-removed-from-the-country-without-permit_5281456.html](https://www.theepochtimes.com/meteorites-found-in-canada-cannot-be-removed-from-the-country-without-permit_5281456.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 21:19:23+00:00

Scientists from Western University and NASA display some meteorites during a press conference in St.Thomas, Ont., on March 21, 2014. (The Canadian Press/Geoff Robins)

## At Least 12 Dead in Stampede at El Salvador Stadium
 - [https://www.theepochtimes.com/at-least-12-dead-in-stampede-at-el-salvador-stadium_5281364.html](https://www.theepochtimes.com/at-least-12-dead-in-stampede-at-el-salvador-stadium_5281364.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 21:12:17+00:00

A medical team arrives following a stampede prior to a soccer game between C.D. FAS Vs. Alianza F.C. at the Cuzcatlan stadium in San Salvador, El Salvador, on May 20, 2023. (Jose Cabezas/Reuters)

## Biden at G7: Most US Allies Clear ‘There Would Be a Response’ If China Takes Action Against Taiwan
 - [https://www.theepochtimes.com/biden-at-g7-most-us-allies-clear-there-would-be-a-response-if-china-takes-action-against-taiwan_5280839.html](https://www.theepochtimes.com/biden-at-g7-most-us-allies-clear-there-would-be-a-response-if-china-takes-action-against-taiwan_5280839.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 19:07:21+00:00

President Joe Biden speaks during a press conference following the G7 Leaders' Summit in Hiroshima on May 21, 2023. (Kiyoshi Ota/Pool/AFP via Getty Images)

## Japan, South Korea Leaders Pray at Memorial for Korean Atomic Bomb Victims in Hiroshima
 - [https://www.theepochtimes.com/japan-south-korea-leaders-pray-at-memorial-for-korean-atomic-bomb-victims-in-hiroshima_5281078.html](https://www.theepochtimes.com/japan-south-korea-leaders-pray-at-memorial-for-korean-atomic-bomb-victims-in-hiroshima_5281078.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 17:25:38+00:00

South Korea's President Yoon Suk Yeol (L) and Japan's Prime Minister Fumio Kishida bow as they lay flowers at the Monument in Memory of the Korean Victims of the 1945 atomic bombing near the Peace Park Memorial in Hiroshima, western Japan, on May 21, 2023, on the sidelines of the G-7 Summit Leaders' Meeting. (Yuichi Yamazaki/Pool Photo via AP)

## Zelenskyy Denies Ukrainian City of Bakhmut Occupied by Russian Forces
 - [https://www.theepochtimes.com/zelenskyy-denies-ukrainian-city-of-bakhmut-occupied-by-russian-forces_5280967.html](https://www.theepochtimes.com/zelenskyy-denies-ukrainian-city-of-bakhmut-occupied-by-russian-forces_5280967.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 16:49:28+00:00

Ukrainian President Volodymyr Zelenskyy speaks during a news conference at the Group of Seven nations' summit in Hiroshima, western Japan, on May 21, 2023. (Louise Delmotte/Pool via AP)

## Biden Says Zelenskyy Gave ‘Flat Assurance’ He Won’t Use F-16s in Russia
 - [https://www.theepochtimes.com/biden-says-zelenskyy-gave-flat-assurance-he-wont-use-f-16s-in-russia_5280878.html](https://www.theepochtimes.com/biden-says-zelenskyy-gave-flat-assurance-he-wont-use-f-16s-in-russia_5280878.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 16:13:57+00:00

U.S. President Joe Biden (L) walks with Ukraine's President Volodymyr Zelenskyy ahead of a working session on Ukraine during the G-7 Leaders' Summit in Hiroshima, Japan, on May 21, 2023. (Susan Walsh/Pool/AFP via Getty Images)

## China Poses ‘Biggest Challenge’ to Global Security and Prosperity, UK Prime Minister Warns
 - [https://www.theepochtimes.com/china-poses-biggest-challenge-to-global-security-and-prosperity-uk-prime-minister-warns_5280887.html](https://www.theepochtimes.com/china-poses-biggest-challenge-to-global-security-and-prosperity-uk-prime-minister-warns_5280887.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 15:12:08+00:00

British Prime Minister Rishi Sunak speaks during a press conference following the G-7 summit in Hiroshima, Japan, on May 21, 2023. (Issei Kato - Pool/Getty Images)

## F-16 Jets to Ukraine: Russian Minister Warns of ‘Escalation Scenario’
 - [https://www.theepochtimes.com/f-16-jets-to-ukraine-russian-minister-warns-of-escalation-scenario_5280821.html](https://www.theepochtimes.com/f-16-jets-to-ukraine-russian-minister-warns-of-escalation-scenario_5280821.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 14:31:10+00:00

A U.S. Air Force F-16 fighter taking part in the U.S.-led Saber Strike exercise flies over Estonia on June 6, 2018. (Ints Kalnins/Reuters)

## Biden Announces New Military Aid in Meeting With Ukraine’s Zelenskyy in Japan
 - [https://www.theepochtimes.com/biden-announces-new-military-aid-in-meeting-with-ukraines-zelenskyy-in-japan_5280669.html](https://www.theepochtimes.com/biden-announces-new-military-aid-in-meeting-with-ukraines-zelenskyy-in-japan_5280669.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 11:11:33+00:00

President Joe Biden attends a quad meeting with with Australia's Prime Minister Anthony Albanese, Japan's Prime Minister Fumio Kishida, and India's Prime Minister Narendra Modi on the sidelines of the G7 Leaders' Summit in Hiroshima on May 20, 2023. (Kenny Holston/POOL/AFP via Getty Images)

## Psychiatrist: Family Dinners Are a Great Marker of a Cohesive Household
 - [https://www.theepochtimes.com/psychiatrist-family-dinners-are-a-great-marker-of-a-cohesive-household_5279695.html](https://www.theepochtimes.com/psychiatrist-family-dinners-are-a-great-marker-of-a-cohesive-household_5279695.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 10:39:18+00:00

Make dinnertime a time to connect with and bond as a family—without phones in sight. (Drazen Zigic/Shutterstock)

## Sinn Fein Becomes Largest Party in Northern Ireland Local Government
 - [https://www.theepochtimes.com/sinn-fein-becomes-largest-party-in-northern-ireland-local-government_5280704.html](https://www.theepochtimes.com/sinn-fein-becomes-largest-party-in-northern-ireland-local-government_5280704.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 09:32:28+00:00

Sinn Fein northern leader Michelle O'Neill reacts with candidates and party workers as the count continues in the Northern Ireland council elections in Magherafelt, Northern Ireland, on May 19, 2023. (Charles McQuillan/Getty Images)

## ABC Boss Apologises to Stan Grant After Q&A Call
 - [https://www.theepochtimes.com/abc-boss-apologises-to-stan-grant-after-qa-call_5280695.html](https://www.theepochtimes.com/abc-boss-apologises-to-stan-grant-after-qa-call_5280695.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 08:44:49+00:00

Australian Broadcasting Corporation (ABC) Managing Director David Anderson speaks during Senate Estimates at Parliament House in Canberra, Australia, on Feb. 14, 2023. (AAP Image/Lukas Coch)

## Russia Opens Far East Port Vladivostok to China
 - [https://www.theepochtimes.com/russia-opens-far-east-port-vladivostok-to-china_5280615.html](https://www.theepochtimes.com/russia-opens-far-east-port-vladivostok-to-china_5280615.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 08:32:17+00:00

The Russian navy corvette Sovershenny and the Gazprom owned pipe-laying ship Akademik Cherskiy are seen offshore Vladivostok, Russia, on Sept. 6, 2017. (Sergei Karpukhin/Reuters)

## Talks Moving Forward on Key Canada-US Treaty on Columbia River Management
 - [https://www.theepochtimes.com/talks-moving-forward-on-key-canada-us-treaty-on-columbia-river-management_5280646.html](https://www.theepochtimes.com/talks-moving-forward-on-key-canada-us-treaty-on-columbia-river-management_5280646.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 05:26:12+00:00

Water spills over the Bonneville Dam on the Columbia River, which runs along the Washington and Oregon state line, on June 21, 2022. (The Canadian Press/AP-Jessie Wardarski)

## Bloc Leader Yves-François Blanchet Scores 97.25 Percent in Confidence Vote
 - [https://www.theepochtimes.com/bloc-leader-yves-francois-blanchet-scores-97-25-percent-in-confidence-vote_5280642.html](https://www.theepochtimes.com/bloc-leader-yves-francois-blanchet-scores-97-25-percent-in-confidence-vote_5280642.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 05:19:46+00:00

Bloc Quebecois Leader Yves-Francois Blanchet speaks to reporters before Question Period on Parliament Hill in Ottawa, on May 17, 2023. (The Canadian Press/Spencer Colby)

## US Default Risk Casts Shadow Over Biden’s G7 Trip
 - [https://www.theepochtimes.com/us-default-risk-casts-shadow-over-bidens-g7-trip_5280635.html](https://www.theepochtimes.com/us-default-risk-casts-shadow-over-bidens-g7-trip_5280635.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 05:18:10+00:00

President Joe Biden attends a quad meeting with with Australia's Prime Minister Anthony Albanese, Japan's Prime Minister Fumio Kishida, and India's Prime Minister Narendra Modi on the sidelines of the G7 Leaders' Summit in Hiroshima on May 20, 2023. (KENNY HOLSTON/POOL/AFP via Getty Images)

## Australian PM Backs G7 Statement Against China’s Economic Coercion
 - [https://www.theepochtimes.com/australian-pm-backs-g7-statement-against-chinas-economic-coercion_5280607.html](https://www.theepochtimes.com/australian-pm-backs-g7-statement-against-chinas-economic-coercion_5280607.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 04:39:13+00:00

Australia's Prime Minister Anthony Albanese arrives at Hiroshima airport in Mihara, Hiroshima prefecture on May 19, 2023, to attend the first day of the G7 Leaders' Summit. (Philip Fong/AFP via Getty Images)

## Polish Official Says Object That Entered Airspace Was Russian-Made Rocket
 - [https://www.theepochtimes.com/polish-official-says-object-that-entered-airspace-was-russian-made-rocket_5278816.html](https://www.theepochtimes.com/polish-official-says-object-that-entered-airspace-was-russian-made-rocket_5278816.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 03:58:38+00:00

Polish President Andrzej Duda attends a joint press conference with the Austrian President during an official visit in Vienna on April 14, 2023. (Alex Halada/AFP via Getty Images)

## Northeast China ‘Forerunner’ in China’s Development
 - [https://www.theepochtimes.com/northeast-china-forerunner-in-chinas-development_5274700.html](https://www.theepochtimes.com/northeast-china-forerunner-in-chinas-development_5274700.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 03:54:56+00:00

Northeast China (Wiki Commons)

## Radio Host Jailed for Sedition in Hong Kong Finds a Home and Freedom in Canada
 - [https://www.theepochtimes.com/radio-host-jailed-for-sedition-in-hong-kong-finds-a-home-and-freedom-in-canada_5280625.html](https://www.theepochtimes.com/radio-host-jailed-for-sedition-in-hong-kong-finds-a-home-and-freedom-in-canada_5280625.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 03:34:19+00:00

Edmund Wan, a former Hong Kong radio personality better known as "Giggs", poses for a photograph in Vancouver, on May 12, 2023. (The Canadian Press/Darryl Dyck)

## Plane Crash in Swiss Mountains Kills 3
 - [https://www.theepochtimes.com/plane-crash-in-swiss-mountains-kills-3_5280215.html](https://www.theepochtimes.com/plane-crash-in-swiss-mountains-kills-3_5280215.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-21 02:03:57+00:00

A map shows the location of Switzerland's Ponts-de-Martel area. (Google Maps)

