# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Ukraińcy oburzeni nagraniem z piłkarzami Barcelony. Zwrócili się do Lewandowskiego
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2022-2023/dwaj-pilkarze-barcelony-pozdrawiali-rosjan.-oburzenie-na-ukrainie.-co-powiedzieli_sto9617597/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2022-2023/dwaj-pilkarze-barcelony-pozdrawiali-rosjan.-oburzenie-na-ukrainie.-co-powiedzieli_sto9617597/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 20:20:00+00:00

<img alt="Ukraińcy oburzeni nagraniem z piłkarzami Barcelony. Zwrócili się do Lewandowskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-69p3sb-barcelona-w-ogniu-krytyki-7137440/alternates/LANDSCAPE_1280" />
    Alejandro Balde, Sergi Roberto i cała FC Barcelona znaleźli się w ogniu krytyki. Do sprawy odniósł się już kapitan reprezentacji Polski.

## Kosztowne potknięcie Realu Madryt
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2022-2023/valencia-real-madryt-wynik-meczu-i-relacja_sto9617497/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2022-2023/valencia-real-madryt-wynik-meczu-i-relacja_sto9617497/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 18:57:03+00:00

<img alt="Kosztowne potknięcie Realu Madryt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k8pnj7-real-madryt-7137417/alternates/LANDSCAPE_1280" />
    Stracili pozycję wicelidera.

## Miller: Jarosław "nic nie mogę" Kaczyński powinien zadzwonić do Daniela "wszystko mogę" Obajtka
 - [https://tvn24.pl/polska/500-plus800-plus-propozycje-jaroslawa-kaczynskiego-i-donalda-tuska-leszek-miller-komentuje-7137352?source=rss](https://tvn24.pl/polska/500-plus800-plus-propozycje-jaroslawa-kaczynskiego-i-donalda-tuska-leszek-miller-komentuje-7137352?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 18:56:49+00:00

<img alt="Miller: Jarosław " src="https://tvn24.pl/najnowsze/cdn-zdjecie-603i2n-leszek-miller-7137388/alternates/LANDSCAPE_1280" />
    Były premier w "Faktach po Faktach".

## "To jest chyba największe zaskoczenie tej wojny"
 - [https://tvn24.pl/polska/f-16-dla-ukrainy-piotr-lukasiewicz-i-adam-eberhardt-o-znaczeniu-przekazania-mysliwcow-7137391?source=rss](https://tvn24.pl/polska/f-16-dla-ukrainy-piotr-lukasiewicz-i-adam-eberhardt-o-znaczeniu-przekazania-mysliwcow-7137391?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 18:32:28+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kwmfhz-ukrainski-zolnierz-w-obwodzie-donieckim-7137401/alternates/LANDSCAPE_1280" />
    Piotr Łukasiewicz i Adam Eberhardt w "Faktach po Faktach".

## Wjechała pod prąd na S19, ledwo uniknęła zderzenia, po czym zawróciła na poboczu
 - [https://fakty.tvn24.pl/zobacz-fakty/kobieta-wjechala-pod-prad-na-s19-ledwo-uniknela-zderzenia-po-czym-zawrocila-na-poboczu-7137393?source=rss](https://fakty.tvn24.pl/zobacz-fakty/kobieta-wjechala-pod-prad-na-s19-ledwo-uniknela-zderzenia-po-czym-zawrocila-na-poboczu-7137393?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 18:10:05+00:00

<img alt="Wjechała pod prąd na S19, ledwo uniknęła zderzenia, po czym zawróciła na poboczu" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-4z88dg-kobieta-wjechala-pod-prad-na-s19-ledwo-uniknela-zderzenia-po-czym-zawrocila-na-poboczu-7137318/alternates/LANDSCAPE_1280" />
    Śmiertelnie naraziła siebie i innych.

## Przywódcy G7 o Chinach
 - [https://tvn24.pl/swiat/szczyt-g7-w-hiroszimie-twarde-oswiadczenie-wobec-wobec-pekinu-7137335?source=rss](https://tvn24.pl/swiat/szczyt-g7-w-hiroszimie-twarde-oswiadczenie-wobec-wobec-pekinu-7137335?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 17:55:34+00:00

<img alt="Przywódcy G7 o Chinach " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7in6ln-rozmowy-przywodcow-grupy-g7-w-hiroszimie-7137325/alternates/LANDSCAPE_1280" />
    Twarde stanowisko wobec Pekinu.

## Arcybiskup Jędraszewski odznaczony Krzyżem Komandorskim Orderu Odrodzenia Polski
 - [https://tvn24.pl/polska/arcybiskup-marek-jedraszewski-metropolita-krakowski-odznaczony-przez-prezydenta-andrzeja-dude-krzyzem-komandorskim-orderu-odrodzenia-polski-7137313?source=rss](https://tvn24.pl/polska/arcybiskup-marek-jedraszewski-metropolita-krakowski-odznaczony-przez-prezydenta-andrzeja-dude-krzyzem-komandorskim-orderu-odrodzenia-polski-7137313?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 17:39:54+00:00

<img alt="Arcybiskup Jędraszewski odznaczony Krzyżem Komandorskim Orderu Odrodzenia Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nv2q22-abp-marek-jedraszewski-odznaczony-przez-prezydenta-andrzeja-dude-krzyzem-komandorskim-orderu-odrodzenia-polski-7137324/alternates/LANDSCAPE_1280" />
    "Za wybitne zasługi w pracy duszpasterskiej, za propagowanie postaw patriotycznych".

## Bayern stracił pozycję lidera. Borussia Dortmund krok od mistrzostwa
 - [https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2022-2023/borussia-dortmund-pokonala-augsburg-i-jest-juz-krok-od-mistrzostwa-bundesligi_sto9617366/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2022-2023/borussia-dortmund-pokonala-augsburg-i-jest-juz-krok-od-mistrzostwa-bundesligi_sto9617366/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 17:37:00+00:00

<img alt="Bayern stracił pozycję lidera. Borussia Dortmund krok od mistrzostwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ifb4rt-sebastien-haller-strzelil-dwa-gole-dla-borussii-dortmund-w-meczu-z-augsburgiem-7137365/alternates/LANDSCAPE_1280" />
    Na kolejkę przed końcem dortmundczycy są na pierwszym miejscu.

## Ogromne emocje w Kielcach
 - [https://eurosport.tvn24.pl/pilka-reczna/barlinek-industria-kielce-orlen-wisla-plock-wynik-meczu-i-relacja_sto9617319/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/barlinek-industria-kielce-orlen-wisla-plock-wynik-meczu-i-relacja_sto9617319/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 17:08:57+00:00

<img alt="Ogromne emocje w Kielcach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yq03hg-barlinek-industria-kielce-mistrzem-polski-7137336/alternates/LANDSCAPE_1280" />
    Barlinek Industria wyszarpała mistrzostwo.

## Lotnisko w Katanii zamknięte do "przywrócenia warunków bezpieczeństwa"
 - [https://tvn24.pl/tvnmeteo/swiat/wlochy-erupcja-wulkanu-etna-na-sycylii-zamkniete-lotnisko-w-katanii-7137306?source=rss](https://tvn24.pl/tvnmeteo/swiat/wlochy-erupcja-wulkanu-etna-na-sycylii-zamkniete-lotnisko-w-katanii-7137306?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 16:56:23+00:00

<img alt="Lotnisko w Katanii zamknięte do " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dz4q89-pyl-wulkaniczny-w-miescie-nicolosi-7137316/alternates/LANDSCAPE_1280" />
    Powodem jest aktywność wulkanu Etna.

## Trudna rozmowa marszałek Witek. "Powiedz mi, ile jest płci w przyrodzie"
 - [https://tvn24.pl/polska/marszalek-sejmu-elzbieta-witek-w-rozmowie-z-norbertem-huczkiem-z-mlodej-lewicy-na-temat-sytuacji-spolecznosci-lgbt-i-hejtu-7137260?source=rss](https://tvn24.pl/polska/marszalek-sejmu-elzbieta-witek-w-rozmowie-z-norbertem-huczkiem-z-mlodej-lewicy-na-temat-sytuacji-spolecznosci-lgbt-i-hejtu-7137260?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 16:48:14+00:00

<img alt="Trudna rozmowa marszałek Witek. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gwkhy9-marszalek-sejmu-elzbieta-witek-podczas-rozmowy-z-nikodemem-huczkiem-z-mlodej-lewicy-7137248/alternates/LANDSCAPE_1280" />
    Podczas pikniku rodzinnego w Korfantowie na Opolszczyźnie.

## Pomylono nazwiska zawodniczek, ale to nie koniec. Organizatorzy wygwizdani
 - [https://eurosport.tvn24.pl/tenis/wta-rzym/2023/jelena-rybakina-anhelina-kalinina-skandaliczne-sceny-podczas-finalu-turnieju-w-rzymie_sto9617229/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-rzym/2023/jelena-rybakina-anhelina-kalinina-skandaliczne-sceny-podczas-finalu-turnieju-w-rzymie_sto9617229/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 16:43:00+00:00

<img alt="Pomylono nazwiska zawodniczek, ale to nie koniec. Organizatorzy wygwizdani" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ayorkk-jelena-rybakina-7137311/alternates/LANDSCAPE_1280" />
    Finał turnieju WTA 1000 w Rzymie nie zapisał się złotymi zgłoskami na kartach historii tenisa.

## Pierwsze skutki "paktu z diabłem". "Dlaczego tu przylecieliście?"
 - [https://tvn24.pl/swiat/gruzja-napiecia-po-wznowieniu-bezposrednich-lotow-z-rosja-protesty-w-tbilisi-rzad-sie-tlumaczy-7137256?source=rss](https://tvn24.pl/swiat/gruzja-napiecia-po-wznowieniu-bezposrednich-lotow-z-rosja-protesty-w-tbilisi-rzad-sie-tlumaczy-7137256?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 16:39:04+00:00

<img alt="Pierwsze skutki " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nhppig-nie-jestescie-mile-widziani-przekaz-od-gruzinow-do-rosjan-przy-lotnisku-w-tbilisi-7137264/alternates/LANDSCAPE_1280" />
    Obawy Gruzinów po wznowieniu bezpośrednich połączeń lotniczych z Moskwą.

## Kolejne potężne trzęsieni ziemi zagraża Stambułowi. "Możemy być pewni wysokiego poziomu zniszczeń"
 - [https://tvn24.pl/tvnmeteo/swiat/turcja-wielkie-trzesienie-ziemi-zagraza-stambulowi-mozemy-byc-pewni-wysokiego-poziomu-zniszczen-7136795?source=rss](https://tvn24.pl/tvnmeteo/swiat/turcja-wielkie-trzesienie-ziemi-zagraza-stambulowi-mozemy-byc-pewni-wysokiego-poziomu-zniszczen-7136795?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 16:04:11+00:00

<img alt="Kolejne potężne trzęsieni ziemi zagraża Stambułowi. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ro842r-stambul-fotografia-z-lutego-2023-roku-7136802/alternates/LANDSCAPE_1280" />
    Specjaliści o tym, jak zabezpieczyć metropolię.

## Fenomenalna walka do ostatnich metrów
 - [https://eurosport.tvn24.pl/kolarstwo/giro-d-italia/2023/15.-etap-seregno-bergamo-wyniki-etapu-klasyfikacja-generalna-i-relacja_sto9617008/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/giro-d-italia/2023/15.-etap-seregno-bergamo-wyniki-etapu-klasyfikacja-generalna-i-relacja_sto9617008/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 15:48:04+00:00

<img alt="Fenomenalna walka do ostatnich metrów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4u9tlp-brandon-mcnulty-cieszy-sie-ze-zwyciestwa-7137277/alternates/LANDSCAPE_1280" />
    Amerykanin królem Bergamo.

## Mistrzostwo, rozmowa z Messim i przyszłość reprezentacji
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2022-2023/lewandowski-o-mistrzostwie-rozmowie-z-messim-i-przyszlosci-reprezentacji_sto9616625/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2022-2023/lewandowski-o-mistrzostwie-rozmowie-z-messim-i-przyszlosci-reprezentacji_sto9616625/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 15:30:00+00:00

<img alt="Mistrzostwo, rozmowa z Messim i przyszłość reprezentacji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q0v2b-21-1355-lewandowski-0039-7137227/alternates/LANDSCAPE_1280" />
    Z kapitanem reprezentacji Polski i piłkarzem Barcelony rozmawiał Adrian Mielnik.

## Triumfalny powrót zdobywców Ligi Mistrzów
 - [https://eurosport.tvn24.pl/siatkowka/liga-mistrzow/2022-2023/grupa-azoty-zaksa-kedzierzyn-kozle-powitana-wodnym-salutem-w-katowicach-po-wygraniu-ligi-mistrzow_sto9616652/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/liga-mistrzow/2022-2023/grupa-azoty-zaksa-kedzierzyn-kozle-powitana-wodnym-salutem-w-katowicach-po-wygraniu-ligi-mistrzow_sto9616652/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 15:24:00+00:00

<img alt="Triumfalny powrót zdobywców Ligi Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ihfsg-powitanie-zaksy-na-lotnisku-z-katowicach-7137257/alternates/LANDSCAPE_1280" />
    Siatkarze Grupy Azoty ZAKSY Kędzierzyn-Koźle w niedzielę powrócili do Polski z Turynu.

## Bus dachował na autostradzie, dwie osoby nie żyją
 - [https://tvn24.pl/katowice/czestochowa-wypadek-na-a1-bus-dachowal-na-autostradzie-dwie-osoby-nie-zyja-kierowca-byl-pijany-7137171?source=rss](https://tvn24.pl/katowice/czestochowa-wypadek-na-a1-bus-dachowal-na-autostradzie-dwie-osoby-nie-zyja-kierowca-byl-pijany-7137171?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 14:14:41+00:00

<img alt="Bus dachował na autostradzie, dwie osoby nie żyją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-90kxek-busdrv-7137233/alternates/LANDSCAPE_1280" />
    Kierowca był pijany - informuje policja.

## Ukrywał się od 2021 roku, często zmieniał miejsce pobytu. Po pieniądze z bankomatu przyszedł w kominiarce
 - [https://tvn24.pl/katowice/godow-w-kominiarce-wybieral-pieniadze-z-bankomatu-okazalo-sie-ze-byl-poszukiwany-7137067?source=rss](https://tvn24.pl/katowice/godow-w-kominiarce-wybieral-pieniadze-z-bankomatu-okazalo-sie-ze-byl-poszukiwany-7137067?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 13:24:13+00:00

<img alt="Ukrywał się od 2021 roku, często zmieniał miejsce pobytu. Po pieniądze z bankomatu przyszedł w kominiarce" src="https://tvn24.pl/katowice/cdn-zdjecie-82vqg6-w-kominiarce-wybieral-pieniadze-z-bankomatu-okazalo-sie-ze-byl-poszukiwany-7137069/alternates/LANDSCAPE_1280" />
    Jego zachowanie zaniepokoiło świadków, którzy powiadomili policję.

## O tym wyzwaniu przywódcy G7 dyskutowali po raz pierwszy
 - [https://tvn24.pl/biznes/ze-swiata/przywodcy-g7-przyjeli-stanowisko-w-sprawie-sztucznej-inteligencji-7137068?source=rss](https://tvn24.pl/biznes/ze-swiata/przywodcy-g7-przyjeli-stanowisko-w-sprawie-sztucznej-inteligencji-7137068?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 13:18:49+00:00

<img alt="O tym wyzwaniu przywódcy G7 dyskutowali po raz pierwszy " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-s9rdc5-sztuczna-inteligencja-sluzy-do-tworzenia-deepfejkow-ale-moze-tez-je-rozpoznawac-musimy-bardzo-uwazac-7134884/alternates/LANDSCAPE_1280" />
    Stwierdzili, że zarządzanie technologią nie nadąża za jej rozwojem.

## Arcyważne zwycięstwo Śląska.
 - [https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2022-2023/pko-bp-ekstraklasa-2022-23.-slask-wroclaw-miedz-legnica.-wynik-i-relacja-z-meczu_sto9616395/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2022-2023/pko-bp-ekstraklasa-2022-23.-slask-wroclaw-miedz-legnica.-wynik-i-relacja-z-meczu_sto9616395/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 13:06:26+00:00

<img alt="Arcyważne zwycięstwo Śląska." src="https://tvn24.pl/najnowsze/cdn-zdjecie-sf4xza-john-yeboah-w-meczu-slask-wroclaw-miedz-legnica-7137149/alternates/LANDSCAPE_1280" />
    Wzrosły szanse na utrzymanie.

## Czarna woda w fontannie di Trevi
 - [https://tvn24.pl/swiat/wlochy-rzym-czarna-woda-w-fontannie-di-trevi-to-kolejna-akcja-przeciwnikow-paliw-kopalnych-7137070?source=rss](https://tvn24.pl/swiat/wlochy-rzym-czarna-woda-w-fontannie-di-trevi-to-kolejna-akcja-przeciwnikow-paliw-kopalnych-7137070?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 12:30:05+00:00

<img alt="Czarna woda w fontannie di Trevi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qkz4ja-dzialacze-ruchu-ostatnie-pokolenie-wlali-do-rzymskiej-fontanny-di-trevi-czarny-plyn-z-wegla-drzewnego-7137048/alternates/LANDSCAPE_1280" />
    Oburzenie turystów.

## Wielki sukces polskiego tenisisty. Wygrał turniej w Rzymie
 - [https://eurosport.tvn24.pl/tenis/atp-rzym-debel/2023/atp-1000-w-rzymie.-wynik-finalu-debla-z-janem-zielinskim-i-hugo-nysem_sto9616256/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/atp-rzym-debel/2023/atp-1000-w-rzymie.-wynik-finalu-debla-z-janem-zielinskim-i-hugo-nysem_sto9616256/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 12:27:10+00:00

<img alt="Wielki sukces polskiego tenisisty. Wygrał turniej w Rzymie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a25omv-jan-zielinski-i-hugo-nys-wygrali-turniej-w-rzymie-7137116/alternates/LANDSCAPE_1280" />
    Rangi ATP Masters 1000.

## Stracił obie nogi na wojnie. Teraz wspiął się na Mount Everest
 - [https://tvn24.pl/tvnmeteo/swiat/stracil-obie-nogi-na-wojnie-teraz-wspial-sie-na-mount-everest-7137015?source=rss](https://tvn24.pl/tvnmeteo/swiat/stracil-obie-nogi-na-wojnie-teraz-wspial-sie-na-mount-everest-7137015?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 11:50:59+00:00

<img alt="Stracił obie nogi na wojnie. Teraz wspiął się na Mount Everest" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nnuulw-hari-budha-magar-podczas-wspinaczki-7137012/alternates/LANDSCAPE_1280" />
    "Górę Gór" zdobyto do tej pory ponad 11 tysięcy razy.

## Palił się pensjonat. Na miejscu biegli
 - [https://tvn24.pl/bialystok/naleczow-pozar-pensjonatu-biegli-ustalaja-przyczyne-7136837?source=rss](https://tvn24.pl/bialystok/naleczow-pozar-pensjonatu-biegli-ustalaja-przyczyne-7136837?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 11:05:13+00:00

<img alt="Palił się pensjonat. Na miejscu biegli" src="https://tvn24.pl/najnowsze/cdn-zdjecie-je7oem-ustalaja-jak-doszlo-do-pozaru-pensjonatu-w-naleczowie-7137003/alternates/LANDSCAPE_1280" />
    Sprawdzają, jak i dlaczego doszło do pożaru w Nałęczowie.

## Dostali potężną listę numerów telefonów. "Od razu wiedzieliśmy, że to gigantyczna afera"
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1243,S00E1243,1065376?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1243,S00E1243,1065376?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 11:03:03+00:00

<img alt="Dostali potężną listę numerów telefonów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v75s1i-pegasus-szpieg-w-moim-telefonie-cz-2-7137005/alternates/LANDSCAPE_1280" />
    Druga część reportażu "Pegasus. Szpieg w moim telefonie"

## Brak dymisji wojskowych "potwierdza tylko tezę, że pan minister Błaszczak kłamie"
 - [https://tvn24.pl/polska/rakieta-pod-bydgoszcza-dyskusja-w-kawie-na-lawe-o-odpowiedzialnosci-rzadzacych-i-szefie-mon-mariuszu-blaszczaku-7136770?source=rss](https://tvn24.pl/polska/rakieta-pod-bydgoszcza-dyskusja-w-kawie-na-lawe-o-odpowiedzialnosci-rzadzacych-i-szefie-mon-mariuszu-blaszczaku-7136770?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 11:00:24+00:00

<img alt="Brak dymisji wojskowych " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hsbu3m-21-1045-kawa-cl-0004-7136875/alternates/LANDSCAPE_1280" />
    Dyskusja w "Kawie na ławę".

## Szybciej czy taniej? Komunikacją czy autem? Jedziemy na Lotnisko Warszawa-Radom
 - [https://tvn24.pl/tvnwarszawa/okolice/dojazd-z-warszawy-na-lotnisko-warszawa-radom-komunikacja-i-samochodem-czas-i-koszt-podrozy-7127296?source=rss](https://tvn24.pl/tvnwarszawa/okolice/dojazd-z-warszawy-na-lotnisko-warszawa-radom-komunikacja-i-samochodem-czas-i-koszt-podrozy-7127296?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 10:32:46+00:00

<img alt="Szybciej czy taniej? Komunikacją czy autem? Jedziemy na Lotnisko Warszawa-Radom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cqyar2-lotnisko-7136929/alternates/LANDSCAPE_1280" />
    Kto był pierwszy, a kto zapłacił mniej?

## Zełenski proponuje szczyt w lipcu
 - [https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-proponuje-szczyt-w-lipcu-w-sprawie-ukrainskiej-formuly-pokoju-7136890?source=rss](https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-proponuje-szczyt-w-lipcu-w-sprawie-ukrainskiej-formuly-pokoju-7136890?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 10:29:49+00:00

<img alt="Zełenski proponuje szczyt w lipcu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kzyepl-wolodymyr-zelenski-na-szczycie-g7-w-hiroszimie-7136891/alternates/LANDSCAPE_1280" />
    Spotkanie liderów państw miałoby być poświęcone proponowanej przez Kijów formule pokojowej.

## O czym marzą? Czego się obawiają? Maturzyści mogą pisać, konkurs trwa
 - [https://tvn24.pl/polska/konkurs-dla-maturzystow-na-tekst-o-przyszlosci-polski-jacek-zakowski-wyjasnil-szczegoly-i-zachecil-do-udzialu-7136884?source=rss](https://tvn24.pl/polska/konkurs-dla-maturzystow-na-tekst-o-przyszlosci-polski-jacek-zakowski-wyjasnil-szczegoly-i-zachecil-do-udzialu-7136884?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 10:16:06+00:00

<img alt="O czym marzą? Czego się obawiają? Maturzyści mogą pisać, konkurs trwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l70txd-matury-2023-7127657/alternates/LANDSCAPE_1280" />
    Jacek Żakowski w TVN24 opowiedział o konkursie dla tegorocznych maturzystów na tekst o przyszłości Polski po wyborach w 2023 roku.

## Włamali się do domu, zniszczyli sejf, wyjęli gotówkę. Szajka rozbita
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-radzymin-wlamywali-sie-do-domow-7136771?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-radzymin-wlamywali-sie-do-domow-7136771?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 09:58:24+00:00

<img alt="Włamali się do domu, zniszczyli sejf, wyjęli gotówkę. Szajka rozbita" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-71377p-funkcjonariusze-zatrzymali-trzech-mezczyzn-7136774/alternates/LANDSCAPE_1280" />
    Trzy osoby zatrzymane.

## Jeden kopnął w twarz, we dwóch bili pięściami i uderzali butelką. Pobili 16-latka za e-papierosa
 - [https://tvn24.pl/pomorze/koszalin-16-latek-brutalnie-pobity-przez-dwoch-mezczyzn-policja-powodem-byl-e-papieros-7136784?source=rss](https://tvn24.pl/pomorze/koszalin-16-latek-brutalnie-pobity-przez-dwoch-mezczyzn-policja-powodem-byl-e-papieros-7136784?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 09:52:31+00:00

<img alt="Jeden kopnął w twarz, we dwóch bili pięściami i uderzali butelką. Pobili 16-latka za e-papierosa" src="https://tvn24.pl/pomorze/cdn-zdjecie-dlcaul-16-latek-brutalnie-pobity-przez-dwoch-mezczyzn-powodem-byl-e-papieros-7136848/alternates/LANDSCAPE_1280" />
    19- i 20-latek odpowiedzą za rozbój.

## De Niro i DiCaprio w "arcydziele" Scorsesego. Wielka owacja w Cannes
 - [https://tvn24.pl/kultura-i-styl/festiwal-w-cannes-film-killers-of-the-flower-moon-martina-scorsesego-z-9-minutowa-owacja-7136615?source=rss](https://tvn24.pl/kultura-i-styl/festiwal-w-cannes-film-killers-of-the-flower-moon-martina-scorsesego-z-9-minutowa-owacja-7136615?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 09:37:16+00:00

<img alt="De Niro i DiCaprio w " src="https://tvn24.pl/najnowsze/cdn-zdjecie-q8y417-martin-scorsese-robert-de-niro-i-leonardo-dicaprio-na-premierze-w-cannes-7136612/alternates/LANDSCAPE_1280" />
    Po projekcji filmu "Killers of the Flower Moon".

## Do policjantów przyszedł po poradę, do więzienia trafił na rok
 - [https://tvn24.pl/bialystok/urszulin-przyszedl-po-porade-i-zostal-zatrzymany-zapomnial-ze-jest-poszukiwany-7136779?source=rss](https://tvn24.pl/bialystok/urszulin-przyszedl-po-porade-i-zostal-zatrzymany-zapomnial-ze-jest-poszukiwany-7136779?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 09:17:32+00:00

<img alt="Do policjantów przyszedł po poradę, do więzienia trafił na rok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ahgx9w-poszukiwany-mezczyzna-przyszedl-na-komende-po-porade-zostal-zatrzymany-7136794/alternates/LANDSCAPE_1280" />
    Zapomniał, że jest poszukiwany.

## Trener Bayernu grzmi po porażce. "To niewytłumaczalne"
 - [https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2022-2023/bundesliga-2022-23.-thomas-tuchel-po-porazce-bayernu-monachium-z-rb-lipsk_sto9615922/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2022-2023/bundesliga-2022-23.-thomas-tuchel-po-porazce-bayernu-monachium-z-rb-lipsk_sto9615922/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 09:13:06+00:00

<img alt="Trener Bayernu grzmi po porażce. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hxleiu-thomas-tuchel-nie-potrafil-wyjasnic-porazki-bayernu-z-rb-lipsk-7136833/alternates/LANDSCAPE_1280" />
    To może być bardzo kosztowna wpadka.

## Co z Bachmutem? Rzecznik Zełenskiego: prezydent zaprzeczył zdobyciu miasta przez Rosjan
 - [https://tvn24.pl/swiat/bachmut-w-ukrainie-sytuacja-miasta-w-obwodzie-donieckim-co-mowi-strona-ukrainska-w-tym-wolodymyr-zelenski-i-strona-rosyjska-7136681?source=rss](https://tvn24.pl/swiat/bachmut-w-ukrainie-sytuacja-miasta-w-obwodzie-donieckim-co-mowi-strona-ukrainska-w-tym-wolodymyr-zelenski-i-strona-rosyjska-7136681?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 08:54:54+00:00

<img alt="Co z Bachmutem? Rzecznik Zełenskiego: prezydent zaprzeczył zdobyciu miasta przez Rosjan" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6algnh-bachmut-jest-niemal-calkowicie-zniszczony-7133797/alternates/LANDSCAPE_1280" />
    O sytuację wokół miasta był pytany Wołodymyr Zełenski. Później do słów prezydenta odniósł się jego rzecznik.

## Chciał wyprzedzić, zderzył się czołowo z autem osobowym. 21-letni motocyklista nie żyje
 - [https://tvn24.pl/krakow/brzesko-chcial-wyprzedzic-zderzyl-sie-czolowo-z-bmw-21-letni-motocyklista-nie-zyje-7136755?source=rss](https://tvn24.pl/krakow/brzesko-chcial-wyprzedzic-zderzyl-sie-czolowo-z-bmw-21-letni-motocyklista-nie-zyje-7136755?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 08:41:29+00:00

<img alt="Chciał wyprzedzić, zderzył się czołowo z autem osobowym. 21-letni motocyklista nie żyje " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hnb4ab-motocyklista-zginal-w-czolowym-zderzeniu-z-osobowka-7136757/alternates/LANDSCAPE_1280" />
    Wypadek w Małopolsce.

## Robert Karaś walczy o rekord świata. "Pływanie zakończył z niesamowitym czasem"
 - [https://eurosport.tvn24.pl/triathlon/brasil-ultra-tri/2023/brasil-ultra-tri-2023.-robert-karas-walczy-o-rekord-swiata-na-dystansie-10-krotnego-ironmana.-polak-_sto9615930/story.shtml?source=rss](https://eurosport.tvn24.pl/triathlon/brasil-ultra-tri/2023/brasil-ultra-tri-2023.-robert-karas-walczy-o-rekord-swiata-na-dystansie-10-krotnego-ironmana.-polak-_sto9615930/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 08:36:58+00:00

<img alt="Robert Karaś walczy o rekord świata. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ui510-robert-karas-instagram-7136780/alternates/LANDSCAPE_1280" />
    Polski triathlonista zakończył już pływanie.

## Najpierw miało dojść do awantury na myjni, później do szpitala trafił 32-latek z obrażeniami po postrzale
 - [https://tvn24.pl/lodz/lodz-awantura-na-myjni-samochodowej-do-szpitala-trafil-mezczyzna-z-obrazeniami-po-postrzale-7136748?source=rss](https://tvn24.pl/lodz/lodz-awantura-na-myjni-samochodowej-do-szpitala-trafil-mezczyzna-z-obrazeniami-po-postrzale-7136748?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 08:28:17+00:00

<img alt="Najpierw miało dojść do awantury na myjni, później do szpitala trafił 32-latek z obrażeniami po postrzale " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2xn49w-policja-szuka-kierowcy-ktory-uciekl-przed-kontrola-drogowa-3117160/alternates/LANDSCAPE_1280" />
    W Łodzi.

## "Logan Roy zmienił moje życie"
 - [https://tvn24.pl/kultura-i-styl/sukcesja-w-hbo-max-brian-cox-logan-roy-zmienil-moje-zyciewywiad-7134087?source=rss](https://tvn24.pl/kultura-i-styl/sukcesja-w-hbo-max-brian-cox-logan-roy-zmienil-moje-zyciewywiad-7134087?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 08:27:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b4ws2r-brian-cox-sukcesja-7134106/alternates/LANDSCAPE_1280" />
    Wywiad z Brianem Coksem z "Sukcesji".

## Masakra w trakcie pokazu samochodów terenowych. Wielu zabitych
 - [https://tvn24.pl/swiat/meksyk-kalifornia-dolna-masakra-w-trakcie-pokazu-samochodow-terenowych-wielu-zabitych-7136691?source=rss](https://tvn24.pl/swiat/meksyk-kalifornia-dolna-masakra-w-trakcie-pokazu-samochodow-terenowych-wielu-zabitych-7136691?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 08:19:53+00:00

<img alt="Masakra w trakcie pokazu samochodów terenowych. Wielu zabitych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9qxglt-meksyk-strzelanina-podczas-pokazu-samochodow-terenowych-7136731/alternates/LANDSCAPE_1280" />
    Napastnicy otworzyli ogień do uczestników.

## Szef nie wierzył, że przyszła do pracy po tym, co zrobiła
 - [https://tvn24.pl/premium/wings-for-life-2023-kim-jest-katarzyna-szkoda-globalna-zwyciezczyni-charytatywnego-biegu-7126563?source=rss](https://tvn24.pl/premium/wings-for-life-2023-kim-jest-katarzyna-szkoda-globalna-zwyciezczyni-charytatywnego-biegu-7126563?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 07:53:16+00:00

<img alt="Szef nie wierzył, że przyszła do pracy po tym, co zrobiła " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hvplo8-katarzyna-szkoda-7133949/alternates/LANDSCAPE_1280" />
    Szefa zamurowało. Zaniemówił. Trąbią o niej w mediach nie tylko w Polsce, a ona zjawia się w pracy, dzień po takim sukcesie. - Miałam wziąć wolne, ale zrezygnowałam. Nie byłam aż tak zmęczona, wolałam rozruszać mięśnie i stawy - tłumaczy Katarzyna Szkoda, absolwentka lingwistyki stosowanej, specjalistka do spraw ochrony przeciwpożarowej i globalna zwyciężczyni tegorocznej edycji biegu Wings for Life.

## Dwie Polki w kwalifikacjach Rolanda Garrosa. Relacje w Eurosporcie Extra
 - [https://eurosport.tvn24.pl/tenis/roland-garros/2023/kwalifikacje-do-rolanda-garrosa-wylacznie-w-eurosporcie-extra-w-playerze_sto9614369/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros/2023/kwalifikacje-do-rolanda-garrosa-wylacznie-w-eurosporcie-extra-w-playerze_sto9614369/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 07:52:15+00:00

<img alt="Dwie Polki w kwalifikacjach Rolanda Garrosa. Relacje w Eurosporcie Extra" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e5l3pu-maja-chwalinska-7136732/alternates/LANDSCAPE_1280" />
    Od poniedziałku.

## Rosjanie się przestraszyli. Ekspert: ukryli sprzęt
 - [https://tvn24.pl/swiat/krym-ekspert-ataki-ukrainy-na-krymie-zmusily-rosje-do-ukrycia-okretow-floty-czarnomorskiej-7136634?source=rss](https://tvn24.pl/swiat/krym-ekspert-ataki-ukrainy-na-krymie-zmusily-rosje-do-ukrycia-okretow-floty-czarnomorskiej-7136634?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 07:52:14+00:00

<img alt="Rosjanie się przestraszyli. Ekspert: ukryli sprzęt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yliars-potezny-pozar-na-krymie-7029077/alternates/LANDSCAPE_1280" />
    Według analityka Andrija Kłymenki, to skutek ukraińskich ataków na okupowanym przez Moskwę Krymie.

## Rywalka znów kreczuje. Rybakina znów wygrywa
 - [https://eurosport.tvn24.pl/tenis/wta-rzym/2023/jelena-rybakina-anhelina-kalinina-wynik-finalu-i-relacja-turniej-wta-1000-w-rzymie_sto9615901/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-rzym/2023/jelena-rybakina-anhelina-kalinina-wynik-finalu-i-relacja-turniej-wta-1000-w-rzymie_sto9615901/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 07:27:07+00:00

<img alt="Rywalka znów kreczuje. Rybakina znów wygrywa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-69zy0y-jelena-rybakina-z-lewej-i-anhelina-kalinina-7136705/alternates/LANDSCAPE_1280" />
    Finał turnieju w Rzymie.

## Niemiecki gigant opuszcza Rosję. Sprzedał fabrykę
 - [https://tvn24.pl/biznes/ze-swiata/rosja-volkswagen-wycofuje-sie-z-rosji-niemiecki-producent-samochodow-sprzedal-fabryke-kaludze-7136505?source=rss](https://tvn24.pl/biznes/ze-swiata/rosja-volkswagen-wycofuje-sie-z-rosji-niemiecki-producent-samochodow-sprzedal-fabryke-kaludze-7136505?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 06:57:08+00:00

<img alt="Niemiecki gigant opuszcza Rosję. Sprzedał fabrykę" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-418qu9-fabryka-w-kaludze-rosja-7136542/alternates/LANDSCAPE_1280" />
    Wartość transakcji miała przekroczyć 100 milionów euro.

## Kumulacja w Lotto rośnie
 - [https://tvn24.pl/biznes/pieniadze/wyniki-lotto-zdnia-200523-liczby-z-ostatniego-losowania-7136656?source=rss](https://tvn24.pl/biznes/pieniadze/wyniki-lotto-zdnia-200523-liczby-z-ostatniego-losowania-7136656?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 06:47:32+00:00

<img alt="Kumulacja w Lotto rośnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e8daeg-emerytka-emeryt-kupon-lotto-senior-shutterstock1464157709-6189722/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## Biden z Zełenskim na szczycie G7
 - [https://tvn24.pl/swiat/szczyt-g7-w-japonii-spotkanie-joe-biden-wolodymyr-zelenskim-7136662?source=rss](https://tvn24.pl/swiat/szczyt-g7-w-japonii-spotkanie-joe-biden-wolodymyr-zelenskim-7136662?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 06:36:33+00:00

<img alt="Biden z Zełenskim na szczycie G7" src="https://tvn24.pl/najnowsze/cdn-zdjecie-btwfa0-biden-i-zelenski-na-szczycie-g7-w-hiroszimie-7136674/alternates/LANDSCAPE_1280" />
    Nowa transza pomocy wojskowej.

## Miedwiediew ograł Tsitsipasa
 - [https://eurosport.tvn24.pl/tenis/atp-rzym/2023/atp-1000-w-rzymie.-daniil-miedwiediew-stefanos-tsitsipas.-wynik-i-relacja-z-polfinalu_sto9615896/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/atp-rzym/2023/atp-1000-w-rzymie.-daniil-miedwiediew-stefanos-tsitsipas.-wynik-i-relacja-z-polfinalu_sto9615896/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 06:35:35+00:00

<img alt="Miedwiediew ograł Tsitsipasa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3sr08g-daniil-miedwiediew-awansowal-do-finalu-turnieju-w-rzymie-7136667/alternates/LANDSCAPE_1280" />
    Ma finał turnieju w Rzymie.

## Puchar w rękach Lewandowskiego. Barcelona czekała cztery lata
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2022-2023/robert-lewandowski-i-pilkarze-barcelony-odebrali-puchar-za-mistrzostwo-hiszpanii_sto9615884/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2022-2023/robert-lewandowski-i-pilkarze-barcelony-odebrali-puchar-za-mistrzostwo-hiszpanii_sto9615884/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 06:13:13+00:00

<img alt="Puchar w rękach Lewandowskiego. Barcelona czekała cztery lata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wgcjng-robert-lewandowski-z-pucharem-za-mistrzostwo-hiszpanii-7136654/alternates/LANDSCAPE_1280" />
    Wielkie święto na Camp Nou.

## "To był legendarny mecz"
 - [https://eurosport.tvn24.pl/siatkowka/liga-mistrzow/2022-2023/siatkowka.-final-ligi-mistrzow.-grupa-azoty-kedzierzyn-kozle-jastrzebski-wegiel.-aleksander-sliwka-p_sto9615887/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/liga-mistrzow/2022-2023/siatkowka.-final-ligi-mistrzow.-grupa-azoty-kedzierzyn-kozle-jastrzebski-wegiel.-aleksander-sliwka-p_sto9615887/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 06:01:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dd29pj-aleksander-sliwka-pierwszy-z-lewej-to-kapitan-zaksy-7136637/alternates/LANDSCAPE_1280" />
    Śliwka dumny po finale Ligi Mistrzów.

## On poprowadzi misję pokojową w sprawie Ukrainy
 - [https://tvn24.pl/swiat/ukraina-rosyjska-agresja-kardynal-matteo-zuppi-poprowadzi-misje-pokojowa-to-decyzja-papieza-franciszka-7136544?source=rss](https://tvn24.pl/swiat/ukraina-rosyjska-agresja-kardynal-matteo-zuppi-poprowadzi-misje-pokojowa-to-decyzja-papieza-franciszka-7136544?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 05:16:17+00:00

<img alt="On poprowadzi misję pokojową w sprawie Ukrainy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nvpmlg-kardynal-matteo-zuppi-7136632/alternates/LANDSCAPE_1280" />
    Ma się postarać na początek m.in. o rozmowę z Władimirem Putinem.

## Mirosław wspina się w swojej lidze. Kolejny triumf w Pucharze Świata
 - [https://eurosport.tvn24.pl/wspinaczka-1/wspinaczka-sportowa.-aleksandra-miroslaw-wygrala-zawody-pucharu-swiata-w-salt-lake-city_sto9615869/story.shtml?source=rss](https://eurosport.tvn24.pl/wspinaczka-1/wspinaczka-sportowa.-aleksandra-miroslaw-wygrala-zawody-pucharu-swiata-w-salt-lake-city_sto9615869/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 04:39:24+00:00

<img alt="Mirosław wspina się w swojej lidze. Kolejny triumf w Pucharze Świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ww2x1u-aleksandra-miroslaw-7136613/alternates/LANDSCAPE_1280" />
    Aleksandra Mirosław wygrała zawody Pucharu Świata we wspinaczce na czas w Salt Lake City.

## Grecy wybierają parlament na nowych zasadach
 - [https://tvn24.pl/swiat/grecja-wybory-parlamentarne-2023-nowe-zasady-przeliczania-glosow-na-mandaty-7136550?source=rss](https://tvn24.pl/swiat/grecja-wybory-parlamentarne-2023-nowe-zasady-przeliczania-glosow-na-mandaty-7136550?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 04:38:24+00:00

<img alt="Grecy wybierają parlament na nowych zasadach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vikjas-lokal-wyborczy-w-atenach-grecja-7136551/alternates/LANDSCAPE_1280" />
    Lokale wyborcze otwarte.

## Grecy zagłosowali. Wyniki
 - [https://tvn24.pl/swiat/grecja-wybory-parlamentarne-2023-wyniki-nowa-demokracja-premiera-kyriakosa-micotakisa-zwyciezca-7136550?source=rss](https://tvn24.pl/swiat/grecja-wybory-parlamentarne-2023-wyniki-nowa-demokracja-premiera-kyriakosa-micotakisa-zwyciezca-7136550?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 04:38:24+00:00

<img alt="Grecy zagłosowali. Wyniki " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6mohfp-sympatycy-nowej-demokracji-swietuja-po-ogloszeniu-pierwszych-wynikow-wyborow-parlamentarnych-7137415/alternates/LANDSCAPE_1280" />
    Krajowa prasa komentuje pierwsze oficjalne wyniki jako historyczne.

## Burze z gradem. Alerty
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-w-polsce-w-tych-regionach-aura-moze-dac-nam-sie-we-znaki-prognoza-zagrozen-na-wtorek-7136609?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-w-polsce-w-tych-regionach-aura-moze-dac-nam-sie-we-znaki-prognoza-zagrozen-na-wtorek-7136609?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 04:36:50+00:00

<img alt="Burze z gradem. Alerty" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-u0k485-burze-6105351/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie wydano alarmy.

## W tych regionach pogoda może dać się we znaki. Prognoza zagrożeń
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-w-tych-regionach-aura-moze-dac-nam-sie-we-znaki-prognoza-zagrozen-na-wtorek-7136609?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-w-tych-regionach-aura-moze-dac-nam-sie-we-znaki-prognoza-zagrozen-na-wtorek-7136609?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 04:36:50+00:00

<img alt="W tych regionach pogoda może dać się we znaki. Prognoza zagrożeń" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-7yvl2q-burze-5792389/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie mogą obowiązywać ostrzeżenia.

## Co się wydarzyło w Ukrainie i wokół niej w ostatnich godzinach
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-najwazniejsze-wydarzenia-ostatnich-godzin-21-maja-2023-7136591?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-najwazniejsze-wydarzenia-ostatnich-godzin-21-maja-2023-7136591?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 04:24:00+00:00

<img alt="Co się wydarzyło w Ukrainie i wokół niej w ostatnich godzinach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6algnh-bachmut-jest-niemal-calkowicie-zniszczony-7133797/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa 452. dzień.

## Wybuch paniki na stadionie piłkarskim. Są zabici i ranni
 - [https://tvn24.pl/swiat/salwador-wybuch-paniki-na-stadionie-pilkarskim-cuscatlan-zabici-i-ranni-7136603?source=rss](https://tvn24.pl/swiat/salwador-wybuch-paniki-na-stadionie-pilkarskim-cuscatlan-zabici-i-ranni-7136603?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 04:00:06+00:00

<img alt="Wybuch paniki na stadionie piłkarskim. Są zabici i ranni " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bnbvho-plansza-pilne-szeroki-drv-4712015/alternates/LANDSCAPE_1280" />
    Poinformowała miejscowa policja.

## "Myślę, że Polska nie wyda mnie Rosjanom"
 - [https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-133,S00E133,1071429?source=rss](https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-133,S00E133,1071429?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 04:00:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i8tyeb-wyrypajew-bez-polityki-7135845/alternates/LANDSCAPE_1280" />
    Iwan Wyrypajew w rozmowie z Piotrem Jaconiem.

## Niszczyciel rakietowy w Gdyni, polskie kluby zapisały się w historii. Co warto dziś wiedzieć
 - [https://tvn24.pl/polska/szesc-rzeczy-ktore-warto-wiedziec-21-maja-grupa-azoty-zaksa-kedzierzyn-kozle-wygrala-lige-mistrzow-wloski-niszczyciel-rakietowy-w-gdyni-7136595?source=rss](https://tvn24.pl/polska/szesc-rzeczy-ktore-warto-wiedziec-21-maja-grupa-azoty-zaksa-kedzierzyn-kozle-wygrala-lige-mistrzow-wloski-niszczyciel-rakietowy-w-gdyni-7136595?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 03:49:45+00:00

<img alt="Niszczyciel rakietowy w Gdyni, polskie kluby zapisały się w historii. Co warto dziś wiedzieć" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jvckzy-siatkarze-grupy-azoty-zaksa-kedzierzyn-kozle-7136596/alternates/LANDSCAPE_1280" />
    Sześć rzeczy na początek dnia.

## Zawaliły się schody prowadzące z karczmy nad rzekę, siedem osób poszkodowanych
 - [https://tvn24.pl/krakow/zawoja-malopolska-zawalily-sie-schody-na-terenie-karczmy-kilka-osob-poszkodowanych-7136564?source=rss](https://tvn24.pl/krakow/zawoja-malopolska-zawalily-sie-schody-na-terenie-karczmy-kilka-osob-poszkodowanych-7136564?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 03:39:03+00:00

<img alt="Zawaliły się schody prowadzące z karczmy nad rzekę, siedem osób poszkodowanych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tp4gos-wypadek-7136565/alternates/LANDSCAPE_1280" />
    Wypadek w Małopolsce.

## Ofensywa dyplomatyczna Zełenskiego
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-21-maja-2023-7136571?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-21-maja-2023-7136571?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 03:16:42+00:00

<img alt="Ofensywa dyplomatyczna Zełenskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-41m5dk-szczyt-g7-w-japonii-7136589/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## "Super ogarnięta, bizneswoman. Na zewnątrz wzór idealnego życia". Do dna
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3175,S00E3175,1071440?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3175,S00E3175,1071440?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-21 03:00:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-socwni-gdy-kobieta-siega-po-alkohol2-7136056/alternates/LANDSCAPE_1280" />
    Historia każdej z bohaterek reportażu Joanny Pawlińskiej jest inna. Łączy je alkohol.

