# Source:Chris Ray Gun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA, language:en-US

## Chris Plays Zelda While YOU HARASS HIM - Ray Gun Live
 - [https://www.youtube.com/watch?v=-333NLMB8cQ](https://www.youtube.com/watch?v=-333NLMB8cQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA
 - date published: 2023-05-21 19:22:46+00:00

It's been a minute! Got some videos in the chamber now, but I figured I'd pop in to say hi for once!

Social Media!
TWITTER ► https://twitter.com/ChrisRGun
INSTAGRAM ► https://www.instagram.com/chris_ray_gun/
TWITCH ► https://www.twitch.tv/chrisraygun
TIKTOK ► https://www.tiktok.com/@chrisraygun
SUBREDDIT ► https://www.reddit.com/r/ChrisRayGun/

Support Me Over Here!
MERCH ► https://teespring.com/stores/chris-ray-gun
PATREON ► https://www.patreon.com/ChrisRay

Podcasts!
SACRED SYMBOLS : A PLAYSTATION PODCAST ► https://apple.co/2Rqmklc
SNARK TANK ► https://www.youtube.com/c/TheSnarkTank

