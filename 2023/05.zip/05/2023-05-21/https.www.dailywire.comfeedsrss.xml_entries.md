# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Target Faces Backlash Over ‘Pride’ Collection Designer Behind ‘Satan Respects Pronouns’ Shirts
 - [https://www.dailywire.com/news/target-faces-backlash-over-pride-collection-designer-behind-satan-respects-pronouns-shirts](https://www.dailywire.com/news/target-faces-backlash-over-pride-collection-designer-behind-satan-respects-pronouns-shirts)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 18:15:29+00:00

Target is facing backlash over a designer featured in the company&#8217;s &#8220;Pride&#8221; collection who appears to have created products with Satanic imagery. Scarlett Johnson, an activist from Wisconsin, went viral on Twitter this weekend with a thread explaining why she is &#8220;done&#8221; with the retailer. In particular, Johnson took issue with Target listing three items ...

## ‘I Definitely Want To Stand’: Brittney Griner Sees U.S. Flag And Anthem Differently After Russian Imprisonment
 - [https://www.dailywire.com/news/i-definitely-want-to-stand-brittney-griner-sees-u-s-flag-and-anthem-differently-after-russian-imprisonment](https://www.dailywire.com/news/i-definitely-want-to-stand-brittney-griner-sees-u-s-flag-and-anthem-differently-after-russian-imprisonment)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 17:29:24+00:00

WNBA player Brittney Griner says her time in a Russian prison has changed her perspective on the American flag and the national anthem: after promising to protest the traditional pregame anthem in 2020, she said this season she is ready to stand. The Phoenix Mercury star center spent nearly ten months imprisoned in Russia after ...

## Rome Mayor Says Climate Activists Cause ‘Environmental Damage’ After Turning Trevi Fountain Water Black Using Charcoal
 - [https://www.dailywire.com/news/rome-mayor-says-climate-activists-cause-environmental-damage-after-turning-trevi-fountain-water-black-using-charcoal](https://www.dailywire.com/news/rome-mayor-says-climate-activists-cause-environmental-damage-after-turning-trevi-fountain-water-black-using-charcoal)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 16:50:21+00:00

Climate eco-anarchists in Rome turned the Trevi Fountain water black on Sunday after pouring diluted charcoal into the pool during a staged protest against public funding for fossil fuels they claim caused a recent flood that killed 14 people in northeastern Italy. Protestors from the &#8220;Ultima Generazione&#8221; — translated as the &#8220;Last Generation&#8221; — climbed ...

## Michael J. Fox Spills Biggest Career Regret To Whoopi Goldberg: ‘I’m A F***ing Idiot’
 - [https://www.dailywire.com/news/michael-j-fox-spills-biggest-career-regret-to-whoopi-goldberg-im-a-fing-idiot](https://www.dailywire.com/news/michael-j-fox-spills-biggest-career-regret-to-whoopi-goldberg-im-a-fing-idiot)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 16:41:27+00:00

Actor Michael J. Fox revealed his biggest career regret to actress Whoopi Goldberg — and it just so happened to be the fact that he had once turned down a film role opposite her: &#8220;Ghost.&#8221; Fox joined Goldberg and her cohosts for Friday&#8217;s broadcast of ABC midday talk show &#8220;The View,&#8221; and the &#8220;Back to ...

## Durham Report Sheds Light On ‘Catastrophic’ Two-Tiered Justice System
 - [https://www.dailywire.com/news/durham-report-sheds-light-on-catastrophic-two-tiered-justice-system](https://www.dailywire.com/news/durham-report-sheds-light-on-catastrophic-two-tiered-justice-system)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 15:15:21+00:00

Special Counsel John Durham shed another light on the United States&#8217; two-tiered justice system when he concluded the FBI had no evidence to launch the now-infamous &#8220;Crossfire Hurricane&#8221; investigation into then-presidential candidate Donald Trump&#8217;s 2016 campaign and its alleged ties to Russia. Durham, who former Attorney General Bill Barr tasked to examine the propriety of ...

## Lawyer For NYC Woman Accused Of Racism Over Bike Dispute Asks Public For Help Tracking ‘Defamatory’ Statements
 - [https://www.dailywire.com/news/lawyer-for-nyc-woman-accused-of-racism-over-bike-dispute-asks-public-for-help-tracking-defamatory-statements](https://www.dailywire.com/news/lawyer-for-nyc-woman-accused-of-racism-over-bike-dispute-asks-public-for-help-tracking-defamatory-statements)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 14:51:01+00:00

The attorney for Sarah Comrie — a white pregnant woman vilified on social media as a racist over a viral video showing a bike rental dispute between her and a black man with his friends in New York City — created a Twitter account to track defamatory remarks about his client. Comrie, a physician&#8217;s assistant ...

## Send Migrants To The ‘Cities, Villages, Towns’ Across America So ‘It’s Not A Burden’ On NYC, Mayor Says
 - [https://www.dailywire.com/news/send-migrants-to-the-cities-villages-towns-across-america-so-its-not-a-burden-on-nyc-mayor-says](https://www.dailywire.com/news/send-migrants-to-the-cities-villages-towns-across-america-so-its-not-a-burden-on-nyc-mayor-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 14:33:31+00:00

New York City Democratic Mayor Eric Adams has a new proposal for dealing with migrants crossing the border, and it involves the federal government dispersing them across America.  In an appearance on CBS&#8217;s “Face The Nation” on Sunday, Adams said that instead of burdening one city with an influx of migrants, the federal government needs ...

## Biden And McCarthy Set To Meet After ‘Productive’ Chat On Debt Ceiling
 - [https://www.dailywire.com/news/biden-and-mccarthy-set-to-meet-after-productive-chat-on-debt-ceiling](https://www.dailywire.com/news/biden-and-mccarthy-set-to-meet-after-productive-chat-on-debt-ceiling)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 14:24:19+00:00

President Joe Biden and House Speaker Kevin McCarthy (R-CA) are expected to meet on Monday to get debt ceiling negotiations back on track. McCarthy said the plan for another round of face-to-face talks between the leaders emerged from a &#8220;productive&#8221; conversation by phone as Biden flew back to the United States from Japan on Sunday. ...

## McCarthy Expects FBI To Share File On Biden Bribery Allegations
 - [https://www.dailywire.com/news/mccarthy-expects-fbi-to-share-file-on-biden-bribery-allegations](https://www.dailywire.com/news/mccarthy-expects-fbi-to-share-file-on-biden-bribery-allegations)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 13:43:51+00:00

The GOP-led House may have reached a breakthrough in its standoff with the FBI over a file believed to contain bribery allegations concerning President Joe Biden. House Speaker Kevin McCarthy (R-CA) revealed on Sunday that he spoke with Director Christopher Wray about the FBI failing to comply with a subpoena for the document and pushed ...

## Obama’s Secretary Of Defense Reveals What He Believes Is The Greatest Threat To The U.S.
 - [https://www.dailywire.com/news/obamas-secretary-of-defense-reveals-what-he-believes-is-the-greatest-threat-to-the-u-s](https://www.dailywire.com/news/obamas-secretary-of-defense-reveals-what-he-believes-is-the-greatest-threat-to-the-u-s)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 13:34:22+00:00

Robert Gates, who served as Secretary of Defense under former President Barack Obama, said during an interview over the weekend that he believes the extreme political polarization in the U.S. is the greatest threat the country faces. Gates made the remarks during an interview that aired Sunday on CBS&#8217;s &#8220;Face The Nation&#8221; with host Margaret ...

## Jeffrey Epstein Threatened Bill Gates With Sexual Blackmail: Report
 - [https://www.dailywire.com/news/jeffrey-epstein-threatened-bill-gates-with-sexual-blackmail-report](https://www.dailywire.com/news/jeffrey-epstein-threatened-bill-gates-with-sexual-blackmail-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 12:41:07+00:00

Jeffrey Epstein reportedly learned that Microsoft co-founder Bill Gates had an affair with a young Russian woman and later appeared to threaten to expose the tryst if Gates refused to do business with him. The Wall Street Journal reported that Gates met Russian bridge player Mila Antonova in 2010 when she was in her 20s ...

## Yellen Says ‘Low’ Odds Of U.S. Paying All Bills Past Mid-June Without Debt Ceiling Deal
 - [https://www.dailywire.com/news/yellen-says-low-odds-of-u-s-paying-all-bills-past-mid-june-without-debt-ceiling-deal](https://www.dailywire.com/news/yellen-says-low-odds-of-u-s-paying-all-bills-past-mid-june-without-debt-ceiling-deal)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 12:08:27+00:00

Treasury Secretary Janet Yellen views mid-June as the likely time period when the United States can no longer pay all its obligations without a debt ceiling deal. During a Sunday appearance on NBC News, Yellen gave her most specific prediction to date as talks between the White House and Congress appear to hit a snag. ...

## McCarthy Says Biden Beholden To ‘Radical Socialists,’ POTUS Calls GOP Debt Ceiling Position ‘Extreme’
 - [https://www.dailywire.com/news/mccarthy-says-biden-beholden-to-radical-socialists-potus-calls-gop-debt-ceiling-position-extreme](https://www.dailywire.com/news/mccarthy-says-biden-beholden-to-radical-socialists-potus-calls-gop-debt-ceiling-position-extreme)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-21 09:02:56+00:00

President Joe Biden said he would discuss the debt limit with House Speaker Kevin McCarthy (R-CA) via telephone from Air Force One as he returns home from Japan after the top Republican accused him of being beholden to &#8220;radical socialists&#8221; as a potential default looms. Biden spoke to the media on Sunday from Japan as ...

