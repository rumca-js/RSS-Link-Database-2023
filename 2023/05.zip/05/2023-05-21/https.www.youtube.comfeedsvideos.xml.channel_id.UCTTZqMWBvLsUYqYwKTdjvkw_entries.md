# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Atak hakera na firmę #prawieLIVE
 - [https://www.youtube.com/watch?v=PTYS5F9XgZw](https://www.youtube.com/watch?v=PTYS5F9XgZw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-05-21 16:00:16+00:00

🕹️ Kiedy byłem małym chłopcem, marzyłem o tym, żeby zostać profesjonalnym graczem w Starcrafta. Rzeczywistość jednak szybko zweryfikowała moje umiejętności. Drugą w kolejności rzeczą, która mogła w jakiś sposób otrzeć łzy rozpaczy spod moich oczu, było komentowanie Starkraftowych pojedynków. Okazuje się, że nawet po wielu latach marzenia mogą się spełnić. A moje postanowiła spełnić katowicka firma DAGMA Bezpieczeństwo IT, dystrybutor produktów marki Eset na polskim rynku.

Zapraszamy Was wspólnie na konferencję Cyberbezpieczeństwo Polskich Firm 2023, która odbędzie się już niedługo, bo 15. czerwca. Więcej szczegółów znajdziecie pod linkiem:
[https://in.eset.pl/cyberbezpieczenstwo-polskich-firm](https://in.eset.pl/cyberbezpieczenstwo-polskich-firm)

A teraz zobaczmy jak wygląda atak złośliwego hakera na firmę!

PS I wybaczcie drobny błąd z wytłumaczeniem przełącznika -Pn w nmapie. Robi on dokładnie odwrotnie to, co powiedziałem. ;)
 
Źródła:
🔗 Strona DAGMA Bezpieczeństwo IT
https://dagma.eu/pl

🔎 Rozwiązanie klasy Extended Detection & Response (XDR) firmy ESET
https://bit.ly/3WiXXJ0 && https://bit.ly/437iZ09

🎬 Kanał na youtube DAGMA Bezpieczeństwo IT
https://www.youtube.com/channel/UCCYwtZ3QT5NeiyPHrJC5w3g

💼 Profil DAGMA na LinkedIn
https://www.linkedin.com/company/dagma/

💼 Profil ESET Polska na LinkedIn
https://www.linkedin.com/company/eset-polska/

🐚 Czym jest reverse shell?
https://bit.ly/458YTUq

📝 Dokumentacja metasploita
https://bit.ly/45k8tnM

↔️ Jak pivotować? Praktyczny przykład.
https://bit.ly/3Wiv5Ro

🐤 Jak działają pliki-kanarki?
https://bit.ly/3BF0K5W
 
Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly dokąd prowadzą.
 
Relevant xkcd: https://xkcd.com/2176/
 
© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.
❤️ Dziękuję za Waszą uwagę.
 
Znajdziecie mnie również na:
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/ 
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok 
Mastodonie https://infosec.exchange/@mateuszchrobok 
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/ 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok
Podcasty na: 
Anchor https://anchor.fm/mateusz-chrobok 
Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR 
Apple Podcasts https://apple.co/3OwjvOh
 
Rozdziały:
00:00 Intro
01:07 Bohaterowie
01:42 Do ataku!
03:40 email
05:10 Otwarcie załącznika
06:16 Reverse shell
07:01 Pivot
07:57 Proxy
09:09 nmap
11:22 Hydra
12:42 RDP
13:28 Ransomware
14:32 Analiza obrońcy
19:44 Bezbronność
21:27 Co Robić i Jak Żyć?
 
#XDR #EDR #Eset #DAGMA #współpracareklamowa

