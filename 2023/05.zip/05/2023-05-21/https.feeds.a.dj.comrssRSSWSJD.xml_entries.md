# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Beijing Bans Micron as Supplier to Big Chinese Firms
 - [https://www.wsj.com/articles/beijing-bans-micron-as-supplier-to-big-chinese-firms-citing-national-security-5f326b90?mod=rss_Technology](https://www.wsj.com/articles/beijing-bans-micron-as-supplier-to-big-chinese-firms-citing-national-security-5f326b90?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-05-21 15:45:00+00:00

Cyberspace office says the chip maker’s products pose a major national-security risk.

## Apple Messages vs. Snapchat: the Battle for Gen Z's Texts
 - [https://www.wsj.com/articles/imessage-vs-snapchat-the-battle-for-gen-zs-texts-a31ce69f?mod=rss_Technology](https://www.wsj.com/articles/imessage-vs-snapchat-the-battle-for-gen-zs-texts-a31ce69f?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-05-21 12:00:00+00:00

Teens and young adults love Snap’s messaging app almost as much as they love their iPhones. Will they stick with it when they’re 30?

