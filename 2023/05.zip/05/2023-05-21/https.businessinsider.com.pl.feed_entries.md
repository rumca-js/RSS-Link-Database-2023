# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Nie wierzą w pracę od 8 do 16. Pokolenie Z dorabia na boku i dobrze na tym wychodzi
 - [https://businessinsider.com.pl/lifestyle/nie-wierza-w-prace-od-8-do-16-pokolenie-z-dorabia-na-boku/7j4f4yx](https://businessinsider.com.pl/lifestyle/nie-wierza-w-prace-od-8-do-16-pokolenie-z-dorabia-na-boku/7j4f4yx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 14:59:00+00:00

W obliczu niepewnej gospodarki i chwiejnego rynku pracy "Zetki" robią, co mogą, aby utrzymać się na powierzchni. Gen przedsiębiorczości to ich znak rozpoznawczy. Poznajcie więc generację Z — pokolenie ludzi przedsiębiorczych.

## Myśliwce F-16 dla Ukrainy. Ten kraj może dołączyć do szkolenia ukraińskich pilotów
 - [https://businessinsider.com.pl/wiadomosci/ukraina-czeka-na-mysliwce-f-16-nieoczekiwana-deklaracja-kanady/ky0298k](https://businessinsider.com.pl/wiadomosci/ukraina-czeka-na-mysliwce-f-16-nieoczekiwana-deklaracja-kanady/ky0298k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 14:32:50+00:00

Premier Kanady Justin Trudeau zapowiedział w niedzielę podczas szczytu G-7 w Japonii, że jego kraj będzie kontynuował szkolenie ukraińskiej armii i może uczestniczyć w szkoleniu pilotów myśliwców F-16, poinformowała Agencja Reutera.

## Hillary Clinton o Putinie i planach Chin wobec Tajwanu
 - [https://businessinsider.com.pl/wiadomosci/hillary-clinton-dosadnie-o-putinie-i-planach-chin-wobec-tajwanu/prf650g](https://businessinsider.com.pl/wiadomosci/hillary-clinton-dosadnie-o-putinie-i-planach-chin-wobec-tajwanu/prf650g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 13:46:09+00:00

Wojna Putina w Ukrainie "cofnęła" ambicje Chin do inwazji na Tajwan — powiedziała była sekretarz stanu USA Hillary Clinton w wywiadzie dla "Financial Times Weekend".

## Tak firmy wprowadzają nas w błąd. Udają, że są bardziej eko niż w rzeczywistości
 - [https://businessinsider.com.pl/wiadomosci/firmy-wprowadzaja-nas-w-blad-udaja-ze-sa-bardziej-eko-niz-w-rzeczywistosci/dnw6gs2](https://businessinsider.com.pl/wiadomosci/firmy-wprowadzaja-nas-w-blad-udaja-ze-sa-bardziej-eko-niz-w-rzeczywistosci/dnw6gs2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 13:27:00+00:00

Korporacje często wprowadzają nas w błąd. Twierdzą, iż dokonują korzystnych wyborów dla środowiska, podczas gdy prawda wygląda inaczej. Thomas Lyon, naukowiec z Uniwersytetu Michigan, komentuje sens robienia zakupów ekologicznych produktów, tłumaczy, czym są kredyty węglowe i czy faktycznie działają, oraz wyjaśnia, jak powszechny jest greenwashing.

## Miliardy na odbudowę Ukrainy. Wiceprezeska EBI: nie powinniśmy czekać do końca wojny
 - [https://businessinsider.com.pl/wiadomosci/miliardy-na-odbudowe-ukrainy-wiceprezeska-ebi-podaje-konkretne-kwoty/5dkjz2m](https://businessinsider.com.pl/wiadomosci/miliardy-na-odbudowe-ukrainy-wiceprezeska-ebi-podaje-konkretne-kwoty/5dkjz2m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 13:16:37+00:00

Odbudowa Ukrainy powinna trwać już dzisiaj, nie powinniśmy czekać do końca wojny – stwierdziła wiceprezeska EBI Teresa Czerwińska. Dodała, że Europejski Bank Inwestycyjny chce kontynuować swoje wsparcie dla Ukrainy. Tylko w ubiegłym roku EBI przeznaczył na ten cel 1,7 mld euro.

## Ten alkohol trafia do głównego nurtu. Z produkcji feni żyją całe rodziny
 - [https://businessinsider.com.pl/technologie/feni-ten-alkohol-trafia-do-glownego-nurtu-z-produkcji-zyja-cale-rodziny/12ysly3](https://businessinsider.com.pl/technologie/feni-ten-alkohol-trafia-do-glownego-nurtu-z-produkcji-zyja-cale-rodziny/12ysly3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 12:30:00+00:00

Podczas gdy niektóre marki starają się wprowadzić feni do głównego nurtu, ci rolnicy kontynuują wielowiekową tradycję. Rodzina Goankar każdego ranka przeszukuje swoją ziemię w poszukiwaniu opadłych owoców. Z nich powstaje trunek.

## Wygląda jak kawałek kredy, gnie się jak modelina. Sztuczna kość stworzona przez Polaków wchodzi na rynek arabski
 - [https://businessinsider.com.pl/biznes/sztuczna-kosc-stworzona-przez-polakow-wchodzi-na-rynek-arabski-wyglada-jak-kreda-gnie/y68q6r5](https://businessinsider.com.pl/biznes/sztuczna-kosc-stworzona-przez-polakow-wchodzi-na-rynek-arabski-wyglada-jak-kreda-gnie/y68q6r5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 12:21:59+00:00

FlexiOss to biomateriał stworzony przez prof. Grażynę Ginalską z Uniwersytetu Medycznego w Lublinie na zamówienie chirurgów. Wygląda jak kawałek kredy, która po namoczeniu staje się elastyczna i sprężysta. Można za jej pomocą uzupełniać ubytki kostne i leczyć skomplikowane złamania. Sztuczna kość ma też zastosowanie w stomatologii i na rynku weterynaryjnym. Polski wynalazek uratował już kilka osób przed amputacją. Teraz interesują się nim lekarze i kliniki z Europy, Azji i państw arabskich.

## Kenia, Egipt lub RPA — zaplanuj niezapomniane wakacje
 - [https://businessinsider.com.pl/lifestyle/podroze/kenia-egipt-lub-rpa-zaplanuj-niezapomniane-wakacje/gbbrfg5](https://businessinsider.com.pl/lifestyle/podroze/kenia-egipt-lub-rpa-zaplanuj-niezapomniane-wakacje/gbbrfg5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 12:00:00+00:00

Przenikanie się społeczności, kultur, języków, kolorów, dźwięków i zwyczajów to cechy charakterystyczne dla krajów afrykańskich. Każdy, kto wybiera się na urlop do Afryki, może liczyć na słoneczną pogodę, piaszczyste plaże, piękne krajobrazy oraz wiele przygód i atrakcji. Kenia, Egipt i RPA to popularne kierunki turystyczne, pozwalające na wypoczynek w słońcu i wiele niesamowitych przygód. Kraje afrykańskie od lat przyciągają turystów dobrą pogodą, wysokim standardem usług hotelowych, dziką przyrodą i cenami, które nie są szczególnie wygórowane dla Europejczyków. W artykule polecamy sprawdzone i docenione przez klientów wycieczki biura podróży Albatros. Zapraszamy!

## Korepetycje opłaca już 26 proc. rodziców. Stawki bywają wyższe niż za wizytę u lekarza specjalisty
 - [https://businessinsider.com.pl/poradnik-finansowy/korepetycje-oplaca-juz-26-proc-rodzicow-stawki-bywaja-wyzsze-niz-za-wizyte-u-lekarza/gp93mvs](https://businessinsider.com.pl/poradnik-finansowy/korepetycje-oplaca-juz-26-proc-rodzicow-stawki-bywaja-wyzsze-niz-za-wizyte-u-lekarza/gp93mvs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 11:28:35+00:00

Trwają matury, zbliża się egzamin ósmoklasisty. Wielu uczniów przygotowuje się do nich z pomocą korepetytorów. Obok tradycyjnych lekcji w domu ucznia, na rynku znajdziemy korepetycje zdalne, grupowe kursy powtórkowe i materiały wideo. Stawki rzędu 200-300 zł za godzinę nie należą wcale do rzadkości.

## Lewandowski obniża wartość własnej marki? "Rozmienia się na drobne"
 - [https://businessinsider.com.pl/media/marketing/lewandowski-obniza-wartosc-wlasnej-marki-eksperci-bezlitosni-dla-lewego/m70ybd0](https://businessinsider.com.pl/media/marketing/lewandowski-obniza-wartosc-wlasnej-marki-eksperci-bezlitosni-dla-lewego/m70ybd0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 10:51:00+00:00

"Nieumiejętne dobieranie kontraktów", "rozmienianie się na drobne" – nie milkną echa po ogłoszeniu przez Roberta Lewandowskiego decyzji o współpracy z nową, mało znaną na rynku marką. Sam Lewy przyznaje, że dotąd w ogóle o niej nie słyszał.

## Powodzie we Włoszech. Polska gotowa wysłać swoje służby ratownicze
 - [https://businessinsider.com.pl/wiadomosci/wlosi-walcza-ze-skutkami-powodzi-polska-odpowiada-na-prosbe-misja-italia/5svrr1g](https://businessinsider.com.pl/wiadomosci/wlosi-walcza-ze-skutkami-powodzi-polska-odpowiada-na-prosbe-misja-italia/5svrr1g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 10:32:14+00:00

Polska zaoferowała Włochom pomoc w postaci modułu ratowniczego złożonego z 44 ratowników, 19 pojazdów oraz pomp wysokiej wydajności — poinformował w niedzielę rzecznik prasowy Państwowej Straży Pożarnej bryg. Karol Kierzkowski.

## Poświęcił swoje życie, aby walczyć w błocie. "Budzę się codziennie o 3:55"
 - [https://businessinsider.com.pl/wideo/poswiecil-swoje-zycie-aby-walczyc-w-blocie-budze-sie-codziennie-o-355/txsg4wr](https://businessinsider.com.pl/wideo/poswiecil-swoje-zycie-aby-walczyc-w-blocie-budze-sie-codziennie-o-355/txsg4wr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 10:00:00+00:00

Mauli w ciągu czteromiesięcznego sezonu zarabia do 55 tys. dol. Zwykłej rodzinie rolniczej zajęłoby w Indiach ponad 35 lat, aby tyle zarobić.

## Szef znanej sieci piekarni: podwyżki są dwa razy w roku, a pracowników i tak brakuje
 - [https://businessinsider.com.pl/wiadomosci/brakuje-chetnych-do-pracy-w-piekarniach-ta-siec-od-reki-zatrudnilaby-100-osob/g70gfrm](https://businessinsider.com.pl/wiadomosci/brakuje-chetnych-do-pracy-w-piekarniach-ta-siec-od-reki-zatrudnilaby-100-osob/g70gfrm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 09:45:25+00:00

Każdego dnia piekarnie i cukiernie Putka przerabiają ok. 60 ton mąki. Firma ma 66 piekarni firmowych i 46 patronackich na terenie Warszawy i okolic oraz w Łodzi. W sklepach i piekarniach zatrudnia 1500 osób, ale jak przyznaje prezes Grzegorz Putka, od ręki zatrudniłby kolejne 100.

## Cmentarzysko dźwięków. Tak wygląda jeden z najdziwaczniejszych obiektów testowych NASA
 - [https://businessinsider.com.pl/technologie/cmentarz-dla-dzwiekow-oto-jak-wyglada-jeden-z-najdziwaczniejszych-obiektow-testowych/mk3nenh](https://businessinsider.com.pl/technologie/cmentarz-dla-dzwiekow-oto-jak-wyglada-jeden-z-najdziwaczniejszych-obiektow-testowych/mk3nenh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 09:28:00+00:00

W Cleveland w stanie Ohio znajduje się siedziba jednego z najdziwaczniejszych obiektów NASA: Aeroakustycznego Laboratorium Napędu Odrzutowego (AAPL). To miejsce, gdzie umierają dźwięki. — Gdybyś stanął w wejściu i krzyknął "Halo!" do przyjaciela znajdującego się w samym środku, ten ledwo usłyszałby twój głos, mimo że dzieliłaby was odległość zaledwie 20 m — opowiada ekspert.

## Rewolucja w wojnie powietrznej. Amerykańskie drony nowej generacji nadlatują i będą walczyć obok samolotów
 - [https://businessinsider.com.pl/wiadomosci/rewolucja-w-wojnie-powietrznej-amerykanskie-drony-nowej-generacji-nadlatuja-i-beda/jqr81gk](https://businessinsider.com.pl/wiadomosci/rewolucja-w-wojnie-powietrznej-amerykanskie-drony-nowej-generacji-nadlatuja-i-beda/jqr81gk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 08:47:00+00:00

Aby zwiększyć swoją flotę bez rozbijania banku, Siły Powietrzne USA testują drony nowej generacji. Mają współpracować z pilotowanymi w tradycyjny sposób samolotami albo walczyć samodzielnie.

## Tak będzie wyglądać inteligentna paczka sterowana przez aplikację [ZDJĘCIA]
 - [https://businessinsider.com.pl/technologie/nowe-technologie/inteligentna-paczka-stworzona-przez-polakow-mamy-zdjecia-wynalazku/lxct1wm](https://businessinsider.com.pl/technologie/nowe-technologie/inteligentna-paczka-stworzona-przez-polakow-mamy-zdjecia-wynalazku/lxct1wm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 08:34:30+00:00

Czujniki ruchu, temperatury i wilgotności. Panel fotowoltaiczny, sterowany elektronicznie rygiel i e-papier — to elementy, z jakich składa się opatentowana przez Polaków inteligenta paczka wielokrotnego użytku. E-Pack pozwoli śledzić, czy nasza przesyłka dotarła bezpiecznie do odbiorcy. Jeśli ulegnie uszkodzeniu, łatwo znajdziemy winnych.

## Kolejny etap przekopu Mierzei Wiślanej. Najdłuższy most obrotowy niemal gotowy
 - [https://businessinsider.com.pl/wiadomosci/najdluzszy-most-obrotowy-przy-przekopie-mierzei-niemal-gotowy-kiedy-otwarcie/9s9egj1](https://businessinsider.com.pl/wiadomosci/najdluzszy-most-obrotowy-przy-przekopie-mierzei-niemal-gotowy-kiedy-otwarcie/9s9egj1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 08:16:20+00:00

Most obrotowy w Nowakowie, budowany w ramach drogi wodnej łączącej Zalew Wiślany z Zatoką Gdańską, zostanie oddany do użytku przed wakacjami. To trzeci i największy most obrotowy na nowym szlaku do Elbląga — podała rzeczniczka inwestora Urzędu Morskiegow Gdyni Magdalena Kierzkowska.

## Co jeszcze można przekazać Ukrainie? Doradca NATO ma pomysł [WYWIAD]
 - [https://businessinsider.com.pl/wiadomosci/co-jeszcze-mozna-przekazac-ukrainie-do-walki-z-rosja-doradca-nato-ma-pomysl/m0g189x](https://businessinsider.com.pl/wiadomosci/co-jeszcze-mozna-przekazac-ukrainie-do-walki-z-rosja-doradca-nato-ma-pomysl/m0g189x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 07:40:18+00:00

Wciąż istnieje całych wachlarz możliwości. To nie tylko większa liczba czołgów czy odrzutowce — mówi o wspieraniu Ukrainy prof. Julian Lindley-French, brytyjski strateg i autor przedstawianych na forum NATO analiz. W rozmowie z Business Insiderem mówi też, czy mogłoby dojść do interwencji pokojowej oddziałów Sojuszu.

## Politycy proponują proste podatki. Mentzen chce wręcz rewolucji. Jesteś za czy przeciw?
 - [https://businessinsider.com.pl/prawo/podatki/pis-po-i-mentzen-chca-prostych-podatkow-co-z-tego-jest-realne/6hxqg13](https://businessinsider.com.pl/prawo/podatki/pis-po-i-mentzen-chca-prostych-podatkow-co-z-tego-jest-realne/6hxqg13)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 07:04:01+00:00

Proste i niskie podatki to nośne hasło polityczne. Swoje propozycje przedstawili premier Mateusz Morawiecki, Sławomir Mentzen z Konfederacji oraz Donald Tusk. Porównujemy propozycje polityków i sprawdzamy, czy są realne. Najwięcej konkretów pokazał Mentzen. Jego wizja jest sprzeczne z tym, co zrobił i chce zrobić PiS. W praktyce może to stawiać pod znakiem zapytania potencjalną koalicję. A zdaniem ekspertów pomysły lidera Konfederacji są nie do zrealizowania.

## Państwowe spółki ratują budżet państwa. Oto które płacą najwięcej podatków
 - [https://businessinsider.com.pl/gielda/wiadomosci/panstwowe-spolki-ratuja-budzet-panstwa-oto-ktore-placa-najwiecej-podatkow/qh4n6g3](https://businessinsider.com.pl/gielda/wiadomosci/panstwowe-spolki-ratuja-budzet-panstwa-oto-ktore-placa-najwiecej-podatkow/qh4n6g3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 07:00:00+00:00

Tak wiele zależy od tak niewielu, jakby mógł powiedzieć Winston Churchill. Dziesięciu największych płatników podatków wśród spółek giełdowych wpłaciło w ubiegłym roku o 21 mld zł więcej danin publicznych niż rok wcześniej. Przy tym pierwsza dziesiątka to prawie wyłącznie spółki kontrolowane przez państwo i to one ratowały budżet w potrzebie.

## Kupiła trzy opuszczone domy za 3,3 dol. Włochy desperacko próbują zaludniać miasta-widma
 - [https://businessinsider.com.pl/lifestyle/kupila-trzy-domy-za-33-dol-wlochy-desperacko-probuja-zaludniac-miasta-widma/f5ctbkr](https://businessinsider.com.pl/lifestyle/kupila-trzy-domy-za-33-dol-wlochy-desperacko-probuja-zaludniac-miasta-widma/f5ctbkr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-21 06:59:00+00:00

Włochy oferują środki finansowe i domy za bezcen wszystkim tym, którzy pomogą w ponownym zaludnieniu pustoszejących wsi i miasteczek. Trzeba jednak liczyć się także z wyzwaniami, jakie niesie za sobą taki ruch.

