# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## NYC installs kiosks in bodegas to combat rising theft - WTF
 - [https://www.youtube.com/watch?v=oVOkbjukvNI](https://www.youtube.com/watch?v=oVOkbjukvNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-05-21 21:20:36+00:00

👉 https://archive.is/HxYUt
https://youtu.be/aSjzHhsHzv4
https://www.youtube.com/watch?v=ctv5JzDPWCE
https://www.youtube.com/watch?v=b0GG0dEPrMI
https://youtu.be/yi8_9WGk3Ok?list=PLkVbIsAWN2ls-WXrvFtAxoJ_VZIMSG9Z3
https://youtu.be/5oDjSoic9Zk?list=PLkVbIsAWN2ls-WXrvFtAxoJ_VZIMSG9Z3
https://youtu.be/qFVwQCFhKSE?list=PLkVbIsAWN2ls-WXrvFtAxoJ_VZIMSG9Z3
https://youtu.be/nSlGTVInDOI?list=PLkVbIsAWN2ls-WXrvFtAxoJ_VZIMSG9Z3

🔵 Hot air station: https://store.rossmanngroup.com/atten-862.html
🔵 Cheesy mugs & t-shirts: https://bit.ly/rossmannstore

👉 Rossmann chat: https://tinyurl.com/rossmatrix

👉 Equipment used:
🔵 Chair: https://amzn.to/3MjLrnT
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av 
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Working from home is IMMORAL!
 - [https://www.youtube.com/watch?v=Y53elVaJUew](https://www.youtube.com/watch?v=Y53elVaJUew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-05-21 04:24:02+00:00

https://www.youtube.com/watch?v=6pLLVqqF8VA

🔵 Hot air station: https://store.rossmanngroup.com/atten-862.html
🔵 Cheesy mugs & t-shirts: https://bit.ly/rossmannstore

👉 Rossmann chat: https://tinyurl.com/rossmatrix

👉 Equipment used:
🔵 Chair: https://amzn.to/3MjLrnT
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av 
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

