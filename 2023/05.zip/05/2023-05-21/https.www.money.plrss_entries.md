# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Awantura o pół miliona złotych. Nagle dostali wezwanie z sądu
 - [https://www.money.pl/ubezpieczenia/awantura-o-pol-miliona-zlotych-nagle-dostali-wezwanie-z-sadu-6898590844287872a.html](https://www.money.pl/ubezpieczenia/awantura-o-pol-miliona-zlotych-nagle-dostali-wezwanie-z-sadu-6898590844287872a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-21 09:41:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ad86579a-4025-418a-ac51-500ea0a2b8b1" width="308" /> Pracownica firmy serwisującej luksusowe auta rozbiła Ferrari Californię. Warta najpierw wypłaciła odszkodowanie, a następnie pociągnęła do odpowiedzialności jej pracodawcę - Autocar Concierge. Ta nie zapłaciła, bo przejażdżka była prywatna. Trzy lata później komornik ku zaskoczeniu firmy zajął jej konto na 500 tys. zł.

## Fabryka Tesli w Niemczech. Prawie co czwarty pracownik pochodzi z Polski
 - [https://www.money.pl/gospodarka/fabryka-tesli-w-niemczech-prawie-co-czwarty-pracownik-pochodzi-z-polski-6900358577904512a.html](https://www.money.pl/gospodarka/fabryka-tesli-w-niemczech-prawie-co-czwarty-pracownik-pochodzi-z-polski-6900358577904512a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-21 08:30:51+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2184f593-7519-46b5-a946-782816290ecc" width="308" /> W fabryce Tesli w Grünheide pod Berlinem zatrudnienie znalazła całkiem spora grupa Polaków. Na 10-tysięczną załogę  fabryki, prawie co czwarty jej pracownik pochodzi z Polski. Fabryka położona jest około 60 km od granicy z Polską - informuje portal Deutsche Welle.

## Ubezpieczenie od deszczu na wakacje: hit czy kit? Sprawdzamy
 - [https://www.money.pl/ubezpieczenia/ubezpieczenie-od-deszczu-na-wakacje-hit-czy-kit-sprawdzamy-6899693350292384a.html](https://www.money.pl/ubezpieczenia/ubezpieczenie-od-deszczu-na-wakacje-hit-czy-kit-sprawdzamy-6899693350292384a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-21 06:45:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a8bf54f0-cca9-4303-8024-b9e3c8e9b98a" width="308" /> Polisa od deszczu, jaką wprowadziło właśnie do oferty biuro podróży Itaka, nie jest niczym nowym - podobną oferowało swoim klientom Generali, ale przestało. Czy tym razem okaże się sprzedażowym hitem - czas pokaże. Spytaliśmy eksperta ubezpieczeniowego, czy kupiłby takie ubezpieczenie.

## Spór o port w Elblągu. "Nie zamierzamy nacjonalizować"
 - [https://www.money.pl/gospodarka/spor-o-port-w-elblagu-nie-zamierzamy-nacjonalizowac-6900317220596608a.html](https://www.money.pl/gospodarka/spor-o-port-w-elblagu-nie-zamierzamy-nacjonalizowac-6900317220596608a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-21 05:42:35+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/37524599-cfaa-47f2-b4eb-2a853470ac99" width="308" /> Nie zamierzamy nacjonalizować portu w Elblągu. W niedługim czasie rozpoczniemy negocjacje ws. współpracy biznesowej z właścicielami gruntów znajdujących się w porcie - zapowiedział  wiceminister infrastruktury Marek Gróbarczyk.

## Volkswagen opuszcza Rosję. Sprzedaje najważniejszą fabrykę
 - [https://www.money.pl/gospodarka/volkswagen-opuszcza-rosje-sprzedaje-najwazniejsza-fabryke-6900312970210208a.html](https://www.money.pl/gospodarka/volkswagen-opuszcza-rosje-sprzedaje-najwazniejsza-fabryke-6900312970210208a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-21 05:25:17+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7715d646-85a0-4ee4-add5-7d06ccebdad7" width="308" /> Grupa Volkswagen sprzedaje swoją najważniejszą fabrykę w Rosji. Tym samym firma całkowicie wycofuje się z tego kraju, ponad rok po rozpoczęciu rosyjskiego ataku na Ukrainę - informuje portal RND. Zakład w Kałudze zostanie sprzedany grupie handlowej Avilon.

## Unia szykuje kolejny cios w Rosję. Tym razem stracą firmy, które pomagają Kremlowi
 - [https://www.money.pl/gospodarka/unia-szykuje-kolejny-cios-w-rosje-tym-razem-straca-firmy-ktore-pomagaja-kremlowi-6900306769664928a.html](https://www.money.pl/gospodarka/unia-szykuje-kolejny-cios-w-rosje-tym-razem-straca-firmy-ktore-pomagaja-kremlowi-6900306769664928a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-21 05:00:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e6253c23-826f-4611-b960-e649827a60f1" width="308" /> Przewodnicząca Komisji Europejskiej Ursula von der Leyen zapowiedziała, że nowy pakiet sankcji Unii Europejskiej wobec Rosji będzie obejmował ograniczenia dla wielu zagranicznych firm, które pomagają Moskwie uniknąć sankcji.

## Makłowicz i synowie rozkręcają nowy biznes. Nakarmią Polaków gotowymi daniami
 - [https://www.money.pl/gospodarka/maklowicz-i-synowie-rozkrecaja-nowy-biznes-nakarmia-polakow-gotowymi-daniami-6898684736871328a.html](https://www.money.pl/gospodarka/maklowicz-i-synowie-rozkrecaja-nowy-biznes-nakarmia-polakow-gotowymi-daniami-6898684736871328a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-21 04:36:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/abdf20c5-8bac-4590-8393-317684404429" width="308" /> Robert Makłowicz wraz z synami rozkręcają wspólny biznes. Zaoferują Polakom dania gotowe. – Chcemy pokazać, że jakościowe jedzenie wcale nie musi być drogie – mówi money.pl Mikołaj Makłowicz, wiceprezes firmy Makłowicz i Synowie. Zapowiada, że mają duże ambicje i mierzą wysoko.

