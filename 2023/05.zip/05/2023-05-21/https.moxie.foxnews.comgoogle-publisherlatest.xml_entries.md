# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Robert De Niro compares new 'evil' character to Donald Trump: 'That guy is stupid'
 - [https://www.foxnews.com/media/robert-de-niro-compares-new-evil-character-donald-trump-guy-stupid](https://www.foxnews.com/media/robert-de-niro-compares-new-evil-character-donald-trump-guy-stupid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 19:00:03+00:00

Actor Robert De Niro compared his latest movie role as a real-life killer to former President Donald Trump at the Cannes Film Festival, calling them both “evil.&quot;

## Brooks Koepka captures third career PGA Championship with win at Oak Hill
 - [https://www.foxnews.com/sports/brooks-koepka-captures-third-career-pga-championship-win-at-oak-hill](https://www.foxnews.com/sports/brooks-koepka-captures-third-career-pga-championship-win-at-oak-hill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 18:45:13+00:00

Brooks Koepka clearly loves playing majors in New York. The LIV Golfer won his third Wanamaker Trophy of his career with his 2023 PGA Championship victory at Oak Hill on Sunday.

## Indiana man killed, two teenagers wounded after grenade found inside grandfather's belongings explodes
 - [https://www.foxnews.com/us/indiana-man-killed-teenagers-wounded-grenade-found-inside-grandfathers-belongings-explodes](https://www.foxnews.com/us/indiana-man-killed-teenagers-wounded-grenade-found-inside-grandfathers-belongings-explodes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 18:38:44+00:00

An Indiana man died, and two teenagers were injured, after the pin was removed from a grenade found in their grandfather&apos;s belongings, causing it to explode.

## Golden Knights take commanding series lead with overtime win over Stars
 - [https://www.foxnews.com/sports/golden-knights-take-commanding-series-lead-overtime-win-stars](https://www.foxnews.com/sports/golden-knights-take-commanding-series-lead-overtime-win-stars)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 18:33:34+00:00

Jonathan Marchessault and Chandler Stephenson doomed the Dallas Stars on Sunday with clutch goals to give the Vegas Golden Knights a 3-2 overtime win.

## Medical school professor says parents must implement gender ideology for babies: 'It... starts at birth'
 - [https://www.foxnews.com/media/medical-school-professor-says-parents-must-implement-gender-ideology-for-babies-starts-birth](https://www.foxnews.com/media/medical-school-professor-says-parents-must-implement-gender-ideology-for-babies-starts-birth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 18:30:12+00:00

Albert Einstein College of Medicine Lauren T. Roth claims that children as young as 18 months develop gender identity and can discuss their gender

## Team Canada's Joe Veleno suspended 5 games after stomping on opponent's leg
 - [https://www.foxnews.com/sports/team-canada-joe-veleno-suspended-stomp-opponents-leg-nino-niederreiter](https://www.foxnews.com/sports/team-canada-joe-veleno-suspended-stomp-opponents-leg-nino-niederreiter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 18:24:02+00:00

Team Canada will be without Joe Veleno after he was suspended for five games following his stomp on a Swiss player&apos;s leg during a game Saturday.

## Manchester City wraps Premier League title with victory over Chelsea
 - [https://www.foxnews.com/sports/manchester-city-wraps-premier-league-title-victory-chelsea](https://www.foxnews.com/sports/manchester-city-wraps-premier-league-title-victory-chelsea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 18:23:08+00:00

Julian Alvarez&apos;s score is all Manchester City needed to defeat Chelsea and wrap up its third consecutive Premier League championship.

## NYC Mayor Adams receives praise from unlikely GOP ally for comments on migrant crisis
 - [https://www.foxnews.com/politics/nyc-mayor-adams-receives-praise-from-unlikely-gop-ally-miami-francis-suarez-comments-migrant-crisis](https://www.foxnews.com/politics/nyc-mayor-adams-receives-praise-from-unlikely-gop-ally-miami-francis-suarez-comments-migrant-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 18:14:52+00:00

Republican Miami Mayor Francis Suarez said Sunday that his city has yet to receive any federal funds to help manage the flood of migrants over the past year.

## Michael Block sinks hole-in-one as dream PGA Championship continues
 - [https://www.foxnews.com/sports/michael-block-sinks-hole-in-one-dream-pga-championship-continues](https://www.foxnews.com/sports/michael-block-sinks-hole-in-one-dream-pga-championship-continues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 18:02:00+00:00

Michael Block&apos;s dream PGA Championship at Oak Hill got even better in his final round on Sunday when he dunked a hole-in-one

## Trump tears into ‘The View’ co-host, ex-aide Alyssa Farah Griffin in online tirade: A 'sleazebag' and 'loser'
 - [https://www.foxnews.com/media/trump-tears-view-co-host-ex-aide-alyssa-farah-griffin-online-tirade-sleazebag-loser](https://www.foxnews.com/media/trump-tears-view-co-host-ex-aide-alyssa-farah-griffin-online-tirade-sleazebag-loser)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 18:00:15+00:00

Former President Trump slammed his former White House staffer Alyssa Farah Griffin as a &apos;sleazebag&apos; and &apos;loser&apos; in a Truth Social post over the weekend.

## NFL running back says Jets released him after surgery that team told him to get
 - [https://www.foxnews.com/sports/nfl-running-back-ty-johnson-says-jets-released-him-surgery-team-told-him-get](https://www.foxnews.com/sports/nfl-running-back-ty-johnson-says-jets-released-him-surgery-team-told-him-get)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 17:23:19+00:00

The New York Jets told running back Ty Johnson to get surgery after injuring himself during an offseason workout, but cut him shortly afterward.

## Smart tech tips to make summer travel cheaper and less stressful
 - [https://www.foxnews.com/tech/smart-tech-tips-make-summer-travel-cheaper-less-stressful](https://www.foxnews.com/tech/smart-tech-tips-make-summer-travel-cheaper-less-stressful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 17:15:08+00:00

Mobile Passport Control is a free U.S. Customs and Border Protection app that lets you get back home faster and all you have to do is download the app.

## College baseball player performs national anthem on guitar before game
 - [https://www.foxnews.com/sports/college-baseball-player-tre-jones-iii-performs-national-anthem-guitar-game](https://www.foxnews.com/sports/college-baseball-player-tre-jones-iii-performs-national-anthem-guitar-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 17:13:44+00:00

Tre Jones III put on an electric performance of the national anthem before Texas A&amp;M-Corpus Christi played Incarnate Word in the final game of the regular season.

## Taylor Swift's song 'The Man' can save lives, according to American Heart Association
 - [https://www.foxnews.com/entertainment/taylor-swifts-song-the-man-can-save-lives-according-american-heart-association](https://www.foxnews.com/entertainment/taylor-swifts-song-the-man-can-save-lives-according-american-heart-association)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 17:03:25+00:00

The American Heart Association just announced that one of Taylor Swift&apos;s hit songs is the perfect tempo to perform CPR to. Her song &quot;The Man&quot; has 110 beats per minute.

## Man on Reddit upset he can't sleep in the nude with new neighbors nearby: 'Only so much I can do'
 - [https://www.foxnews.com/lifestyle/man-reddit-upset-he-cant-sleep-nude-neighbors-nearby-can-do](https://www.foxnews.com/lifestyle/man-reddit-upset-he-cant-sleep-nude-neighbors-nearby-can-do)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 17:03:10+00:00

A 28-year-old man on Reddit insists on sleeping in the nude in his home and can&apos;t understand how he&apos;s in the wrong now that new neighbors (including children) can see him through his window.

## Yankees' Aaron Boone ejected after controversial play leads to Reds' run
 - [https://www.foxnews.com/sports/yankees-aaron-boone-ejected-controversial-play-leads-reds-run](https://www.foxnews.com/sports/yankees-aaron-boone-ejected-controversial-play-leads-reds-run)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 16:51:46+00:00

New York Yankees manager Aaron Boone was ejected on Sunday against the Cincinnati Reds after a foul ball was overturned to fair and a run crossed the plate.

## 5.5 magnitude earthquake reported off Northern California's coast
 - [https://www.foxnews.com/us/5-5-magnitude-earthquake-reported-off-northern-californias-coast](https://www.foxnews.com/us/5-5-magnitude-earthquake-reported-off-northern-californias-coast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 16:31:57+00:00

A 5.5 magnitude earthquake struck the coast of Northern California on Sunday, the United States Geological Survey reported. Its epicenter was in the Pacific Ocean.

## NYT op-ed mocked for dismissing border crisis as fearmongering tactic: 'Reprehensible excuse for journalism'
 - [https://www.foxnews.com/media/nyt-oped-mocked-dismissing-border-crisis-fearmongering-tactic-reprehensible-excuse-journalism](https://www.foxnews.com/media/nyt-oped-mocked-dismissing-border-crisis-fearmongering-tactic-reprehensible-excuse-journalism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 16:30:13+00:00

A New York Times opinion piece drew attention on Saturday after claiming that the intense focus on the border is only because “someone is trying to scare you.&quot;

## Ben Crump deletes viral tweet branding pregnant nurse racist after her lawyer steps in
 - [https://www.foxnews.com/politics/ben-crump-deletes-viral-tweet-branding-pregnant-nurse-racist-after-lawyer-steps-in](https://www.foxnews.com/politics/ben-crump-deletes-viral-tweet-branding-pregnant-nurse-racist-after-lawyer-steps-in)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 16:27:53+00:00

A prominent civil rights attorney deleted his viral tweet attacking a NYC hospital worker hours after her lawyer threatened a defamation lawsuit in a Fox News segment.

## Texas takes step to ban diversity offices at public universities: 'Strongest pushback on woke policies'
 - [https://www.foxnews.com/politics/texas-takes-step-ban-diversity-offices-public-universities-strongest-pushback-woke-policies](https://www.foxnews.com/politics/texas-takes-step-ban-diversity-offices-public-universities-strongest-pushback-woke-policies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 16:02:51+00:00

The Texas House approved a bill that would ban diversity, equity and inclusion (DEI) offices and diversity training from public colleges in the state.

## Russian invasion kills 42K Ukrainian civilians since start of war, US officials say
 - [https://www.foxnews.com/world/russian-invasion-kills-42k-ukrainian-civilians-since-start-war-us-officials-say](https://www.foxnews.com/world/russian-invasion-kills-42k-ukrainian-civilians-since-start-war-us-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 15:56:25+00:00

U.S. officials confirm to Fox News that 42,000 Ukrainian civilians have been killed since Russia launched its full-scale invasion of Ukraine in Feb. 24, 2022.

## College baseball umpire appears to tell complaining batter 'f--- you' after strikeout
 - [https://www.foxnews.com/sports/college-baseball-umpire-jimmy-paylor-appears-tell-complaining-batter-andrew-brait-f-you-strikeout](https://www.foxnews.com/sports/college-baseball-umpire-jimmy-paylor-appears-tell-complaining-batter-andrew-brait-f-you-strikeout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 15:45:02+00:00

An umpire appeared to curse off a Central Florida batter after he complained about a strike call in the last inning of a game against Wichita State on Friday.

## Blue Jays' John Schneider admits he 'f---ed up' during loss vs Orioles
 - [https://www.foxnews.com/sports/blue-jays-john-schneider-admits-f-ed-up-during-loss-orioles](https://www.foxnews.com/sports/blue-jays-john-schneider-admits-f-ed-up-during-loss-orioles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 15:43:33+00:00

Toronto Blue Jays manager John Schneider had a big blunder with a mound visit during the team&apos;s extra-innings loss to the Baltimore Orioles on Saturday.

## Kids as young as 4 years old can begin to learn medical emergency training: New report
 - [https://www.foxnews.com/health/kids-young-4-years-old-begin-learn-medical-emergency-training-report](https://www.foxnews.com/health/kids-young-4-years-old-begin-learn-medical-emergency-training-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 15:34:21+00:00

Medical groups including the American Heart Association found that teaching kids as young as age 4 to begin to understand health emergencies and how to respond is smart and proactive.

## Rep. Byron Donalds, Chuck Todd clash over debt negotiations, IRS agents: 'That's salacious and you know it'
 - [https://www.foxnews.com/media/rep-byron-donalds-chuck-todd-clash-debt-negotiations-irs-agents-salacious-you-know-it](https://www.foxnews.com/media/rep-byron-donalds-chuck-todd-clash-debt-negotiations-irs-agents-salacious-you-know-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 15:30:50+00:00

Rep. Byron Donalds clashed with Chuck Todd on Sunday during NBC&apos;s &quot;Meet the Press&quot; over the House Republican&apos;s debt limit bill and the ongoing debt negotiations.

## Arizona woman allegedly kills boyfriend with car during argument: police
 - [https://www.foxnews.com/us/arizona-woman-allegedly-kills-boyfriend-car-argument-police](https://www.foxnews.com/us/arizona-woman-allegedly-kills-boyfriend-car-argument-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 15:28:14+00:00

Arizona woman Shelly Shears was charged with second-degree murder after allegedly killing her boyfriend Billy Stephens with a car during an argument, Casa Grande police said.

## Jeffrey Epstein allegedly threatened Bill Gates over reported affair with Russian card player: report
 - [https://www.foxnews.com/politics/jeffrey-epstein-allegedly-threatened-bill-gates-reported-affair-russian-card-player-report](https://www.foxnews.com/politics/jeffrey-epstein-allegedly-threatened-bill-gates-reported-affair-russian-card-player-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 15:03:31+00:00

Jeffrey Epstein allegedly tried to leverage knowledge of an affair between Bill Gates and a Russian bridge player in an email, according to the Wall Street Journal.

## USFL's Derrick Dillon returns missed field-goal kick 109 yards for incredible Showboats touchdown
 - [https://www.foxnews.com/sports/usfls-derrick-dillon-returns-missed-field-goal-kick-109-yards-incredible-showboats-touchdown](https://www.foxnews.com/sports/usfls-derrick-dillon-returns-missed-field-goal-kick-109-yards-incredible-showboats-touchdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 15:02:42+00:00

Memphis Showboats wide receiver Derrick Dillon electrified his team on Saturday with a 109-yard return for a touchdown off a missed field-goal kick.

## Michigan man wanted after 8 starving dogs rescued, 6 others found rotting in yard
 - [https://www.foxnews.com/us/michigan-man-casey-autry-kidd-dog-fighting-ring-wanted-8-starving-dogs-rescued-6-others-found-rotting-yard](https://www.foxnews.com/us/michigan-man-casey-autry-kidd-dog-fighting-ring-wanted-8-starving-dogs-rescued-6-others-found-rotting-yard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 14:50:08+00:00

Casey Autry Kidd is wanted in Genesee County, Michigan, after deputies rescued eight starving and chained dogs from a yard and discovered six more dead and rotting.

## The urgent PayPal email scam you can't afford to ignore
 - [https://www.foxnews.com/tech/urgent-paypal-email-scam-afford-ignore](https://www.foxnews.com/tech/urgent-paypal-email-scam-afford-ignore)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 14:43:12+00:00

The Federal Trade Commission issued warnings about phishing emails from PayPal and Metamask. Kurt &quot;CyberGuy&quot; Knutssons shows you how to keep data safe.

## Transgender California high school runner's 2nd-place finish in girls race draws backlash
 - [https://www.foxnews.com/sports/transgender-california-high-school-runner-athena-ryan-2nd-place-finish-girls-race-draws-backlash](https://www.foxnews.com/sports/transgender-california-high-school-runner-athena-ryan-2nd-place-finish-girls-race-draws-backlash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 14:34:23+00:00

Athena Ryan&apos;s second-place finish at the Meet of Champions in the girls race in California on Saturday drew ire on social media. Ryan is a trans girl.

## Kim Kardashian admits 'I cry myself to sleep' while juggling 'good cop and bad cop' duty as single mom
 - [https://www.foxnews.com/entertainment/kim-kardashian-admits-cry-myself-sleep-juggling-good-cop-bad-cop-duty-single-mom](https://www.foxnews.com/entertainment/kim-kardashian-admits-cry-myself-sleep-juggling-good-cop-bad-cop-duty-single-mom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 14:32:02+00:00

Kim Kardashian is opening up on the trials and tribulations of being a single parent to four young children and juggling the role of good and bad cop.

## Free digital perks you may be missing out on by not having a library card
 - [https://www.foxnews.com/tech/free-digital-perks-may-missing-having-library-card](https://www.foxnews.com/tech/free-digital-perks-may-missing-having-library-card)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 14:19:45+00:00

Some local libraries offer services you may not be aware of, and Kurt &quot;CyberGuy&quot; Knutsson lists some of the best apps to access these free digital perks.

## Trans woman sues NYC yoga studio for $5 million after being told to leave women's locker room: 'Humiliation'
 - [https://www.foxnews.com/media/trans-woman-sues-nyc-yoga-studio-5-million-leave-womens-locker-room-humiliation](https://www.foxnews.com/media/trans-woman-sues-nyc-yoga-studio-5-million-leave-womens-locker-room-humiliation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 14:18:50+00:00

A transgender woman, Ali Miles, is suing a yoga studio in New York City after being asked to exit the women&apos;s locker room and told to use the men&apos;s facilities.

## NYC Mayor Adams: Migrants should be sent to every city 'throughout the entire country'
 - [https://www.foxnews.com/politics/nyc-mayor-adams-migrants-should-sent-every-city-throughout-entire-country](https://www.foxnews.com/politics/nyc-mayor-adams-migrants-should-sent-every-city-throughout-entire-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 14:15:45+00:00

New York City Mayor Eric Adams said Sunday that migrants who cross the border should be resettled &quot;through the entire country,&quot; not just big cities.

## McCarthy announces 'productive' budget call with Biden, says they will meet 'personally'
 - [https://www.foxnews.com/politics/mccarthy-announces-productive-budget-call-biden-says-they-will-meet-personally](https://www.foxnews.com/politics/mccarthy-announces-productive-budget-call-biden-says-they-will-meet-personally)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 14:11:30+00:00

President Biden and House Speaker Kevin McCarthy will meet &quot;personally&quot; in Monday to discuss debt ceiling negotiations as the deadline for a default nears.

## DOJ Jan. 6 prosecutor and tech lawyer who defends social media giants faced off in sealed hearing: report
 - [https://www.foxnews.com/politics/doj-jan-6-prosecutor-tech-lawyer-defends-social-media-giants-faced-off-sealed-hearing-report](https://www.foxnews.com/politics/doj-jan-6-prosecutor-tech-lawyer-defends-social-media-giants-faced-off-sealed-hearing-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 14:04:59+00:00

A DOJ lawyer, who&apos;s been helping special counsel Jack Smith&apos;s probe, and an attorney who recently defended Twitter faced off in a secret DC court battle

## Woman shoved into train, man slashed during violent weekend on NYC subways
 - [https://www.foxnews.com/us/woman-shoved-train-man-slashed-during-violent-weekend-nyc-subways](https://www.foxnews.com/us/woman-shoved-train-man-slashed-during-violent-weekend-nyc-subways)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 13:54:35+00:00

Police in New York City are looking for a person who is suspected of &quot;slashing&quot; a fellow passenger while on the subway in Manhattan on Friday, injuring his chin.

## Biden ad touting personal accountability resurfaces after claiming he's 'blameless' on debt
 - [https://www.foxnews.com/politics/biden-ad-touting-personal-accountability-resurfaces-after-claiming-hes-blameless-debt](https://www.foxnews.com/politics/biden-ad-touting-personal-accountability-resurfaces-after-claiming-hes-blameless-debt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 13:45:20+00:00

An ad from President Biden’s 2020 campaign is circulating on Twitter after he claimed Sunday that he would be blameless if the U.S. defaults on its debt.

## Ex-boxing champ Andy Ruiz Jr says Twitter was hacked by ex after tweets about weed, prostitutes surface
 - [https://www.foxnews.com/sports/ex-boxing-champ-andy-ruiz-jr-says-twitter-hacked-tweets-weed-prostitutes-surface](https://www.foxnews.com/sports/ex-boxing-champ-andy-ruiz-jr-says-twitter-hacked-tweets-weed-prostitutes-surface)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 13:38:15+00:00

Andy Ruiz Jr., a former heavyweight boxing champion, said it was an ex who posted tweets about weed and prostitutes on his account.

## Foods that may help calm seasonal allergies, according to health experts
 - [https://www.foxnews.com/lifestyle/foods-may-help-calm-seasonal-allergies-according-health-experts](https://www.foxnews.com/lifestyle/foods-may-help-calm-seasonal-allergies-according-health-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 13:33:20+00:00

Seasonal allergies can put a damper on your favorite times of the year, but experts say certain foods and herbs might help combat uncomfortable side effects to the new season.

## 'SNL' star Kenan Thompson surprises Newport, RI police with coffee and donuts: 'Wicked nice'
 - [https://www.foxnews.com/entertainment/snl-star-kenan-thompson-surprises-rhode-island-police-department-coffee-donuts-wicked-nice](https://www.foxnews.com/entertainment/snl-star-kenan-thompson-surprises-rhode-island-police-department-coffee-donuts-wicked-nice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 13:31:13+00:00

Kenan Thompson surprised an entire police department on Saturday, showing up with donuts and coffee during Newport&apos;s shift change.

## NASCAR star Bubba Wallace addresses boos after truck race: 'I finished fifth, I got a good payday'
 - [https://www.foxnews.com/sports/nascar-star-bubba-wallace-addresses-boos-truck-race-finished-fifth-got-good-payday](https://www.foxnews.com/sports/nascar-star-bubba-wallace-addresses-boos-truck-race-finished-fifth-got-good-payday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 13:25:02+00:00

Bubba Wallace was asked about the boos he received before and after the NASCAR Truck Series race at North Wilkesboro Speedway on Saturday.

## Congress must exercise the power of the purse to limit what FBI, DOJ are doing to Americans: Rep. Jordan
 - [https://www.foxnews.com/media/congress-must-exercise-power-purse-limit-what-fbi-doj-doing-americans-rep-jordan](https://www.foxnews.com/media/congress-must-exercise-power-purse-limit-what-fbi-doj-doing-americans-rep-jordan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 13:11:56+00:00

Rep. Jim Jordan, R-Ohio, discussed how Congress can use appropriations to reign in the DOJ and FBI.

## Philadelphia suspects bust down grocery store door with ax, hold worker at gunpoint during robbery: video
 - [https://www.foxnews.com/us/philadelphia-suspects-bust-grocery-store-door-ax-hold-worker-gunpoint-robbery-video](https://www.foxnews.com/us/philadelphia-suspects-bust-grocery-store-door-ax-hold-worker-gunpoint-robbery-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 13:11:01+00:00

An ax-wielding suspect pounded open the door to a store while his accomplice held an employee at gunpoint during a robbery in Philadelphia, police said.

## Who is Air Force Gen. Charles Q. Brown Jr, likely replacement for Gen. Milley as Joint Chiefs of Staff chair?
 - [https://www.foxnews.com/us/who-is-air-force-gen-charles-q-brown-jr-likely-replacement-gen-milley-joint-chiefs-staff-chair](https://www.foxnews.com/us/who-is-air-force-gen-charles-q-brown-jr-likely-replacement-gen-milley-joint-chiefs-staff-chair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 13:04:32+00:00

Air Force Gen. Charles Q. Brown Jr. has made a name for himself as a by-the-book commander, but he has ruffled feathers at times for speaking his mind without warning.

## Dem senator praises Feinstein's 'energy' and 'concentration' despite slew of missed votes, absences
 - [https://www.foxnews.com/politics/dem-senator-praises-feinsteins-energy-concentration-despite-slew-missed-votes-absences](https://www.foxnews.com/politics/dem-senator-praises-feinsteins-energy-concentration-despite-slew-missed-votes-absences)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 12:44:10+00:00

Democratic Sen. Jack Reed says Sen. Dianna Feinstein &quot;deserves the opportunity to&quot; make a decision about her career after calls mount for her to resign amid health issues.

## LeBron James accidentally bloodies referee in Game 3: 'You’ve been wanting to do that for 25 years'
 - [https://www.foxnews.com/sports/lebron-james-accidentally-bloodies-referee-game-3-youve-been-wanting-25-years](https://www.foxnews.com/sports/lebron-james-accidentally-bloodies-referee-game-3-youve-been-wanting-25-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 12:37:24+00:00

LeBron James ran into NBA referee Scott Foster during Saturday&apos;s game between the Los Angeles Lakers and Denver Nuggets. Foster was left bloodied.

## IT employee sues boss after mistaking his initials for lewd reference, email abbreviations for sexual advances
 - [https://www.foxnews.com/world/it-employee-sues-boss-after-mistaking-email-abbreviations-for-sexual-advances](https://www.foxnews.com/world/it-employee-sues-boss-after-mistaking-email-abbreviations-for-sexual-advances)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 12:29:52+00:00

An IT worker in England attempted to sue her former boss over claims that email abbreviations such as &quot;xx&quot; and &quot;???&quot; were code to start a sexual relationship.

## Ted Cruz accuses Biden of 'scaremongering' on debt ceiling as Biden complains of 'MAGA Republicans'
 - [https://www.foxnews.com/politics/ted-cruz-accuses-biden-scaremongering-debt-ceiling-biden-complains-maga-republicans](https://www.foxnews.com/politics/ted-cruz-accuses-biden-scaremongering-debt-ceiling-biden-complains-maga-republicans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 12:13:09+00:00

President Biden is willing to &quot;tank the economy&quot; rather than negotiate with Republicans in Congress on a debt ceiling deal, Sen. Ted Cruz said Sunday.

## Jake Sullivan pressed on Syria drone strike after US walks back claim it killed major al Qaeda leader
 - [https://www.foxnews.com/politics/jake-sullivan-pressed-syria-drone-strike-after-us-walks-back-claim-killed-major-al-qaeda-leader](https://www.foxnews.com/politics/jake-sullivan-pressed-syria-drone-strike-after-us-walks-back-claim-killed-major-al-qaeda-leader)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 12:04:11+00:00

White House national security adviser Jake Sullivan was pressed in an interview Sunday over an alleged civilian casualty – a father of 10 – by U.S. forces in Syria.

## Biden accused of succumbing to far-left progressives on debt ceiling talks: 'Wants default more' than a deal
 - [https://www.foxnews.com/media/biden-accused-succumbing-far-left-progressives-debt-ceiling-talks-wants-default-deal](https://www.foxnews.com/media/biden-accused-succumbing-far-left-progressives-debt-ceiling-talks-wants-default-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 12:00:04+00:00

House Speaker Kevin McCarthy accused Biden of succumbing to the demands of the radical left on debt ceiling negotiations during &apos;Sunday Morning Futures.&apos;

## Killer whales ram boat off the coast of Morocco: 'We were sitting ducks,' says 'petrified' couple
 - [https://www.foxnews.com/lifestyle/killer-whales-ram-boat-coast-morocco-sitting-ducks-couple-petrified](https://www.foxnews.com/lifestyle/killer-whales-ram-boat-coast-morocco-sitting-ducks-couple-petrified)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 11:58:58+00:00

A British couple, Janet Morris and Stephen Bidwell of Cambridge, said they were taking a sailing course in early May 2023 off the coast of Morocco when a pod of orcas attacked their boat.

## Family of Chinatown woman stabbed to death by homeless career criminal sues New York City, NYPD officers
 - [https://www.foxnews.com/us/family-chinatown-woman-stabbed-death-homeless-career-criminal-sues-new-york-city-nypd-officers](https://www.foxnews.com/us/family-chinatown-woman-stabbed-death-homeless-career-criminal-sues-new-york-city-nypd-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 11:43:37+00:00

Christian Yuna&apos;s family Lee sued the City of New York and 10 NYPD officers after she was murdered in her Chinatown apartment in February 2022 by a homeless career criminal.

## Turn it up on World Paloma Day with these 3 cocktail recipe twists
 - [https://www.foxnews.com/lifestyle/turn-it-up-world-paloma-day-3-cocktail-recipe-twists](https://www.foxnews.com/lifestyle/turn-it-up-world-paloma-day-3-cocktail-recipe-twists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 11:36:50+00:00

Celebrate World Paloma Day with these three fun and innovative recipes that add a twist to the classic cocktail made of tequila, grapefruit and a squeeze of lime.

## Son of longtime Michigan coach's Twitter account had questionable 'likes' about slavery, Jim Crow: reports
 - [https://www.foxnews.com/sports/son-longtime-michigan-coachs-twitter-account-questionable-likes-slavery-jim-crow-reports](https://www.foxnews.com/sports/son-longtime-michigan-coachs-twitter-account-questionable-likes-slavery-jim-crow-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 11:33:35+00:00

Glenn Schembechler resigned from his post with Michigan football on Saturday over what the school called concerning social media activity.

## Voters spar over abortion issue: Can't 'fight to support complete genocide' of Black babies in womb
 - [https://www.foxnews.com/media/voters-spar-abortion-issue-fight-support-complete-genocide-black-babies-womb](https://www.foxnews.com/media/voters-spar-abortion-issue-fight-support-complete-genocide-black-babies-womb)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 11:30:50+00:00

Two voters engaged in a heated debate over abortion during &apos;Fox &amp; Friends Weekend&apos; while discussing key issues ahead of the 2024 presidential election.

## Team Canada's Joe Veleno stomps on opponent's ankle in battle for puck: 'That's beyond dirty'
 - [https://www.foxnews.com/sports/team-canadas-joe-veleno-stomps-opponents-ankle-battle-puck-thats-beyond-dirty](https://www.foxnews.com/sports/team-canadas-joe-veleno-stomps-opponents-ankle-battle-puck-thats-beyond-dirty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 11:10:32+00:00

Team Canada&apos;s Joe Veleno was accused of committing a dirty play during his matchup against Switzerland on Saturday at the IIHF World Hockey Championship.

## In a tense world, God fulfills his promise to never abandon his followers, says Alabama pastor
 - [https://www.foxnews.com/lifestyle/in-tense-world-god-fulfills-promise-never-abandon-followers-alabama-pastor](https://www.foxnews.com/lifestyle/in-tense-world-god-fulfills-promise-never-abandon-followers-alabama-pastor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 11:07:51+00:00

Jesus Christ and the love of God are a constant, an Alabama-based pastor told Fox News Digital. Unlike worldly things, Jesus promised to be with his followers forever.

## Justice Ketanji Brown Jackson tells law school grads 'Survivor' provides useful 'lessons' for their careers
 - [https://www.foxnews.com/politics/justice-ketanji-brown-jackson-tells-law-school-grads-survivor-provides-useful-lessons-their-careers](https://www.foxnews.com/politics/justice-ketanji-brown-jackson-tells-law-school-grads-survivor-provides-useful-lessons-their-careers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 11:04:57+00:00

Supreme Court Justice Ketanji Brown Jackson is a massive fan of &quot;Survivor&quot; and has watched every episode of 42 seasons from the hit show, she told graduates this weekend.

## Democratic lawmaker clashes with CNN host after question about heckling George Santos: 'CNN, y'all trippin'
 - [https://www.foxnews.com/media/democratic-lawmaker-clashes-cnn-host-question-heckling-george-santos-cnn-yall-trippin](https://www.foxnews.com/media/democratic-lawmaker-clashes-cnn-host-question-heckling-george-santos-cnn-yall-trippin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 10:45:43+00:00

Rep. Jamaal Bowman sparred with CNN&apos;s Erin Burnett on Friday after she asked if he regretted telling George Santos to resign while he was talking to reporters.

## Jordan Spieth tees off at himself in PGA Championship: 'Hit one good f---ing iron shot'
 - [https://www.foxnews.com/sports/jordan-spieth-tees-off-himself-pga-championship-hit-one-good-f-ing-iron-shot](https://www.foxnews.com/sports/jordan-spieth-tees-off-himself-pga-championship-hit-one-good-f-ing-iron-shot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 10:37:50+00:00

Jordan Spieth was extremely frustrated with his approach on the third hole in Round 3 of the PGA Championship on Saturday. The hot mic caught him cursing up a storm.

## El Salvador soccer stadium stampede leaves at least 9 dead, hundreds injured: officials
 - [https://www.foxnews.com/world/el-salvador-soccer-stadium-stampede-leaves-least-9-dead-hundreds-injured-officials](https://www.foxnews.com/world/el-salvador-soccer-stadium-stampede-leaves-least-9-dead-hundreds-injured-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 10:13:10+00:00

A stampede at an El Salvador soccer stadium on Saturday resulted in at least nine dead and hundreds injured, according to officials.

## Crowd size for Brittney Griner's WNBA return baffles coach: 'How was it not a sellout?'
 - [https://www.foxnews.com/sports/crowd-size-brittney-griners-wnba-return-baffles-coach-how-was-not-sellout](https://www.foxnews.com/sports/crowd-size-brittney-griners-wnba-return-baffles-coach-how-was-not-sellout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 10:05:39+00:00

Phoenix Mercury head coach Vanessa Nygaard couldn&apos;t believe the Crypto.com Arena wasn&apos;t sold out for Brittney Griner&apos;s official return to the WNBA floor.

## Ninth horse dies at Churchill Downs in span of less than a month
 - [https://www.foxnews.com/sports/ninth-horse-dies-churchill-downs-span-less-than-month](https://www.foxnews.com/sports/ninth-horse-dies-churchill-downs-span-less-than-month)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 09:41:11+00:00

Churchill Downs was the site of yet another horse death on Saturday – Swanson Lake became the ninth horse to die at the track in less than a month.

## Blue Jays star Vladimir Guerrero Jr gifts bat to child who beat cancer
 - [https://www.foxnews.com/sports/blue-jays-star-vladimir-guerrero-jr-gifts-bat-child-beat-cancer](https://www.foxnews.com/sports/blue-jays-star-vladimir-guerrero-jr-gifts-bat-child-beat-cancer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 09:28:06+00:00

After a young fan brought a sign to the Blue Jays game saying he beat cancer, Toronto superstar Vladimir Guerrero Jr. gifted him a bat.

## Education expert rips school systems after history grades plummet: ‘Appalling,’ ‘dumbed down curriculum’
 - [https://www.foxnews.com/media/education-expert-rips-school-systems-history-grades-plummet-appalling-dumbed-down-curriculum](https://www.foxnews.com/media/education-expert-rips-school-systems-history-grades-plummet-appalling-dumbed-down-curriculum)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 09:00:40+00:00

Education expert Connor Boyack said that one solution to America&apos;s failing education system was a decentralized and individualized curriculum for students.

## The Durham report: Here's how we restore accountability and rule of law
 - [https://www.foxnews.com/opinion/durham-report-heres-how-restore-accountability-rule-law](https://www.foxnews.com/opinion/durham-report-heres-how-restore-accountability-rule-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 09:00:36+00:00

Corruption and lies by the U.S. government were exposed last week in a nonpartisan, 300-page report by John Durham, one of the most apolitical prosecutors in the nation.

## Biden says China’s ‘silly balloon’ derailed open communications with Beijing
 - [https://www.foxnews.com/politics/biden-chinas-silly-balloon-derailed-communications-beijing](https://www.foxnews.com/politics/biden-chinas-silly-balloon-derailed-communications-beijing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 08:33:35+00:00

President Biden hopes to reopen dialogue with Beijing in the near future after the talks were derailed due to China&apos;s spy craft that flew across the U.S.

## Mike Rowe gives his expertise to recession-proof career in an expensive education climate
 - [https://www.foxnews.com/media/mike-rowe-gives-expertise-recession-proof-career-expensive-education-climate](https://www.foxnews.com/media/mike-rowe-gives-expertise-recession-proof-career-expensive-education-climate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 08:30:53+00:00

&quot;How America Works&quot; host Mike Rowe shares alternatives for an overly expensive education that doesn&apos;t pay off as fear grows over a recession on &quot;Fox News Tonight.&quot;

## Kansas City bar shooting leaves 3 dead, 2 wounded: police
 - [https://www.foxnews.com/us/kansas-city-bar-shooting-leaves-3-dead-2-wounded-police](https://www.foxnews.com/us/kansas-city-bar-shooting-leaves-3-dead-2-wounded-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 08:22:31+00:00

At least three people were killed and two others wounded Sunday in an early morning shooting at Klymax Lounge in Kansas City, Missouri, authorities said.

## Zelenskyy says Ukrainian city of Bakhmut 'only in our hearts' after Russia claims seizure
 - [https://www.foxnews.com/world/zelenskyy-ukrainian-city-bakhmut-only-our-hearts-russia-claims-seizure](https://www.foxnews.com/world/zelenskyy-ukrainian-city-bakhmut-only-our-hearts-russia-claims-seizure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 08:03:23+00:00

Ukrainian President Volodymyr Zelenskyy remarked Sunday that the city of Bakhmut is &quot;only in our hearts&quot; after Russia claimed to have seized the region.

## Bruce Willis is battling this terrifying disease and here’s what you need to know to prevent it
 - [https://www.foxnews.com/opinion/bruce-willis-battling-terrifying-disease-heres-what-you-need-know-prevent](https://www.foxnews.com/opinion/bruce-willis-battling-terrifying-disease-heres-what-you-need-know-prevent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 08:00:56+00:00

Bruce Willis is battling this terrifying disease and here’s what you need to know to prevent it. Medicine gives us more ways to avoid or treat such problems.

## Texas rancher who keeps pistol in hand over violent migrant fears shreds Biden for forsaking crisis: 'Wake up'
 - [https://www.foxnews.com/media/texas-rancher-keeps-pistol-hand-violent-migrant-fears-shreds-biden-forsaking-crisis-wake](https://www.foxnews.com/media/texas-rancher-keeps-pistol-hand-violent-migrant-fears-shreds-biden-forsaking-crisis-wake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 08:00:50+00:00

Wayne King, a Texas rancher, shared his experiences from the heart of the border crisis with Gregg Jarrett on Fox Nation&apos;s &apos;Biden&apos;s Border Crisis: The End of Title 42&apos;

## Here are the whistleblowers scorching the Biden administration on Hunter probe, IRS, FBI
 - [https://www.foxnews.com/politics/whistleblowers-scorching-biden-hunter-probe-irs-fbi](https://www.foxnews.com/politics/whistleblowers-scorching-biden-hunter-probe-irs-fbi)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 08:00:42+00:00

Whistleblowers have emerged over the last few years to accuse the Biden administration of mishandling the Hunter Biden probe and politicization at the FBI and IRS.

## Biden declares himself 'blameless' if US defaults on debt: 'I've done my part'
 - [https://www.foxnews.com/politics/biden-declares-himself-blameless-us-defaults-debt-ive-done-my-part](https://www.foxnews.com/politics/biden-declares-himself-blameless-us-defaults-debt-ive-done-my-part)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 07:31:59+00:00

President Biden says some Republicans want to intentionally default on America&apos;s debt to hurt his re-election chances. He argues he would be &quot;blameless.&quot;

## She was a victim of a home break-in. Now she teaches women how to shoot
 - [https://www.foxnews.com/us/victim-home-break-now-teaches-women-shoot](https://www.foxnews.com/us/victim-home-break-now-teaches-women-shoot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 07:30:30+00:00

After surviving a home break-in, Jane Milhans said people started asking her to show them how to use a firearm. Now she teaches other women gun safety in Washington.

## 'They're Marxist': Oklahoma's top education official wages war against teachers unions
 - [https://www.foxnews.com/media/marxist-oklahomas-top-education-official-wages-war-against-teachers-unions](https://www.foxnews.com/media/marxist-oklahomas-top-education-official-wages-war-against-teachers-unions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 07:30:08+00:00

Oklahoma&apos;s top education official is waging a war on teachers unions that aims to completely overhaul the state&apos;s education system.

## No evidence supporting claim that New York hotels kicked out veterans to make room for migrants
 - [https://www.foxnews.com/media/no-evidence-supporting-claim-new-york-hotels-kicked-out-veterans-make-room-migrants](https://www.foxnews.com/media/no-evidence-supporting-claim-new-york-hotels-kicked-out-veterans-make-room-migrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 07:02:19+00:00

Despite initial reports amplifying the claims, there has been no evidence found to back up claims that ex-military members were booted from several New York hotels to make room for migrants being transported in from a recent border surge.

## Durham report shows it was Clinton, not Trump, who colluded with Russians: Victor Davis Hanson
 - [https://www.foxnews.com/media/durham-report-shows-was-clinton-not-trump-colluded-russians-victor-davis-hanson](https://www.foxnews.com/media/durham-report-shows-was-clinton-not-trump-colluded-russians-victor-davis-hanson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 07:00:52+00:00

Stanford University Hoover Institution senior fellow Victor Davis Hanson sounded off on &quot;Life, Liberty &amp; Levin&quot; after the release of John Durham&apos;s report.

## New York cat Julie, rescued from hoarders, needs a new and healthier home
 - [https://www.foxnews.com/lifestyle/new-york-cat-julie-rescued-hoarders-new-healthier-home](https://www.foxnews.com/lifestyle/new-york-cat-julie-rescued-hoarders-new-healthier-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 07:00:27+00:00

Julie is a 4-year-old black and white kitty with a pair of beautiful green eyes. She is up for adoption in New York after being rescued from a hoarding situation.

## In the footsteps of Jesus: 2,000-year-old trade receipt found in Jerusalem
 - [https://www.foxnews.com/world/in-the-footsteps-of-jesus-2000-year-old-trade-receipt-found-in-jerusalem](https://www.foxnews.com/world/in-the-footsteps-of-jesus-2000-year-old-trade-receipt-found-in-jerusalem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 06:00:31+00:00

A 2,000-year-old stone tablet was discovered in Jerusalem with financial recordings indicating it is a receipt from the Early Roman era.

## Former Sen. Scott Brown hosts 2024 GOP presidential contenders in NH as he mulls another Senate run in 2026
 - [https://www.foxnews.com/politics/former-sen-scott-brown-hosts-2024-gop-presidential-contenders-nh-he-mulls-another-senate-run-2026](https://www.foxnews.com/politics/former-sen-scott-brown-hosts-2024-gop-presidential-contenders-nh-he-mulls-another-senate-run-2026)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 06:00:28+00:00

Former senator and ambassador Scott Brown is bringing back his No BS backyard BBQs as he hosts the 2024 Republican presidential candidates. First up is Nikki Haley in Rye, New Hampshire

## Christian group urges congressional action after Biden's 'muted response' to crisis
 - [https://www.foxnews.com/world/christian-group-urges-congressional-action-bidens-muted-response-crisis](https://www.foxnews.com/world/christian-group-urges-congressional-action-bidens-muted-response-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 06:00:03+00:00

A conflict between Armenia and Azerbaijan over the past half year has seen little progress toward a resolution since groups started appealing to President Biden for direct assistance.

## Georgia Secretary of State Brad Raffensperger 'honored' to be banned from Russia
 - [https://www.foxnews.com/politics/georgia-secretary-state-brad-raffensperger-honored-banned-russia](https://www.foxnews.com/politics/georgia-secretary-state-brad-raffensperger-honored-banned-russia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 05:17:44+00:00

Georgia Secretary of State Brad Raffensperger said he appreciates that the Russian government banned him from its country for spreading “Russophobia.&quot;

## Moscow mayor introduces quarantine in 16 city districts amid bird flu outbreak
 - [https://www.foxnews.com/world/moscow-mayor-introduces-quarantine-16-city-districts-amid-bird-flu-outbreak](https://www.foxnews.com/world/moscow-mayor-introduces-quarantine-16-city-districts-amid-bird-flu-outbreak)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 05:02:02+00:00

Moscow Mayor Sergey Sobyanin issued an order on Thursday to place 16 districts under quarantine due to an outbreak of bird flu.

## Selma Blair went undiagnosed with MS for 40 years; she's working with charity to find a cure
 - [https://www.foxnews.com/entertainment/selma-blair-undiagnosed-ms-40-years-working-charity-find-cure](https://www.foxnews.com/entertainment/selma-blair-undiagnosed-ms-40-years-working-charity-find-cure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 05:00:05+00:00

Selma Blair is working with the charity Race to Erase MS in an effort to find a cure for the autoimmune disease. Founder Nancy Davis spoke with Fox News Digital about the actress.

## This Christian college that attributes its soaring enrollment to free speech has a checkered past
 - [https://www.foxnews.com/us/christian-college-attributes-soaring-enrollment-free-speech-checkered-past](https://www.foxnews.com/us/christian-college-attributes-soaring-enrollment-free-speech-checkered-past)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 04:30:53+00:00

Grand Canyon University President Brian Mueller shared how his college aims to teach, not indoctrinate, despite their focus on teaching from a biblical view.

## Minnesota Senate passes bill to legalize recreational marijuana
 - [https://www.foxnews.com/politics/minnesota-senate-passes-bill-legalize-recreational-marijuana](https://www.foxnews.com/politics/minnesota-senate-passes-bill-legalize-recreational-marijuana)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 04:09:06+00:00

The Minnesota Senate passed a bill on Saturday to legalize recreational marijuana for adults ages 21 and older. The governor is expected to sign the bill into law.

## University of Minnesota faces backlash over summer research program restricted to non-white applicants
 - [https://www.foxnews.com/us/university-minnesota-faces-backlash-over-summer-research-program-restricted-non-white-applicants](https://www.foxnews.com/us/university-minnesota-faces-backlash-over-summer-research-program-restricted-non-white-applicants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 03:51:34+00:00

The University of Minnesota&apos;s Office of Undergraduate Studies is under fire after they opened up a paid summer internship program to only non-white applicants.

## Yogi Berra's granddaughter previews doc showcasing baseball icon's legacy, historic career
 - [https://www.foxnews.com/media/yogi-berras-granddaughter-previews-doc-showcasing-baseball-icons-legacy-historic-career](https://www.foxnews.com/media/yogi-berras-granddaughter-previews-doc-showcasing-baseball-icons-legacy-historic-career)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 03:00:15+00:00

Yogi Berra&apos;s granddaughter Lindsay Berra speaks about &quot;It Ain&apos;t Over,&quot; a documentary that looks at the baseball legend&apos;s life and influence, on &quot;Your World.&quot;

## Arrest made in connection with the murder of 20-year-old Texas woman
 - [https://www.foxnews.com/us/arrest-made-connection-murder-20-year-old-texas-woman](https://www.foxnews.com/us/arrest-made-connection-murder-20-year-old-texas-woman)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 02:20:58+00:00

A Texas man was arrested for the alleged murder on Saturday following the discovery of a missing woman&apos;s remains. She was last seen alive on May 10 in the city of Midland

## FAA investigating small aircraft crash in Pacific Ocean off coast of Half Moon Bay
 - [https://www.foxnews.com/us/faa-investigating-small-aircraft-crash-pacific-ocean-off-coast-half-moon-bay](https://www.foxnews.com/us/faa-investigating-small-aircraft-crash-pacific-ocean-off-coast-half-moon-bay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 02:07:22+00:00

The National Transportation Safety Board and the Federal Aviation Administration are investigating a plane crash that occurred about 40 miles off the coast of Half Moon Bay.

## 'Absolutely not': Americans weigh in on whether Kamala Harris can lead on AI after Elon Musk mocked her
 - [https://www.foxnews.com/politics/absolutely-not-americans-weigh-kamala-harris-lead-ai-elon-musk-mocked](https://www.foxnews.com/politics/absolutely-not-americans-weigh-kamala-harris-lead-ai-elon-musk-mocked)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 02:00:35+00:00

Several Washington. D.C. residents said they don&apos;t trust Vice President Kamala Harris to lead the White House&apos;s response to artificial intelligence.

## Florida man allegedly beat grandmother to death with hammer then called housekeeper to clean up bloody scene
 - [https://www.foxnews.com/us/florida-man-allegedly-beat-grandmother-death-hammer-called-housekeeper-clean-up-bloody-scene](https://www.foxnews.com/us/florida-man-allegedly-beat-grandmother-death-hammer-called-housekeeper-clean-up-bloody-scene)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 01:10:31+00:00

A Florida sheriff’s office arrested a blood-soaked man Wednesday after he allegedly beat his grandmother to death with a hammer and severely injured his grandfather.

## On this day in history, May 21, 1881, Clara Barton, 'brave' battlefield nurse, creates American Red Cross
 - [https://www.foxnews.com/lifestyle/this-day-history-may-21-1881-clara-barton-brave-battlefield-nurse-creates-american-red-cross](https://www.foxnews.com/lifestyle/this-day-history-may-21-1881-clara-barton-brave-battlefield-nurse-creates-american-red-cross)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-21 00:02:17+00:00

American nurse Clara Barton founded the American Red Cross on this day in history, May 21, 1881. She led the organization until 1904, when she retired to her Maryland home.

