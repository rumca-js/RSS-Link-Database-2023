# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## “You Can’t Stop Them!” Why The Deep State Is UNSTOPPABLE
 - [https://www.youtube.com/watch?v=J_uH_ZM_5Ds](https://www.youtube.com/watch?v=J_uH_ZM_5Ds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-05-21 17:00:10+00:00

This week I spoke with Professor of History at Columbia, Matthew Connolly. We discuss how power truly operates regarding classified documents & who has access to them. #power #corruption #politics 

Watch Full Interview Here: https://rumble.com/v2o3vls-trump-was-right-what-the-durham-report-really-means-130-stay-free-with-russ.html

You Can Find His Book HERE: https://www.amazon.com/Declassification-Engine-History-Reveals-Americas/dp/1101871571
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble
Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community
Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/
Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

