# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Niemcy: Były wiceminister gospodarki podejrzany o plagiat pracy naukowej
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-byly-wiceminister-gospodarki-podejrzany-o-plagiat-pra,nId,6791785](https://wydarzenia.interia.pl/zagranica/news-niemcy-byly-wiceminister-gospodarki-podejrzany-o-plagiat-pra,nId,6791785)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 20:49:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-byly-wiceminister-gospodarki-podejrzany-o-plagiat-pra,nId,6791785"><img align="left" alt="Niemcy: Były wiceminister gospodarki podejrzany o plagiat pracy naukowej" src="https://i.iplsc.com/niemcy-byly-wiceminister-gospodarki-podejrzany-o-plagiat-pra/000H6J38GDJK8FFY-C321.jpg" /></a>Niemieckie media tygodniami pisały o zarzutach dotyczących nepotyzmu, którego miał się dopuścić sekretarz stanu w ministerstwie gospodarki Patrick Graichen. Ostatecznie polityka odwołano, ale to nie koniec jego problemów - podkreśla &quot;Welt&quot;. Gazety piszą o nowych podejrzeniach, tym razem w sprawie plagiatu pracy doktorskiej.</p><br clear="all" />

## Chorwacja: Trzej Holendrzy zginęli w katastrofie samolotu
 - [https://wydarzenia.interia.pl/zagranica/news-chorwacja-trzej-holendrzy-zgineli-w-katastrofie-samolotu,nId,6791775](https://wydarzenia.interia.pl/zagranica/news-chorwacja-trzej-holendrzy-zgineli-w-katastrofie-samolotu,nId,6791775)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 20:20:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chorwacja-trzej-holendrzy-zgineli-w-katastrofie-samolotu,nId,6791775"><img align="left" alt="Chorwacja: Trzej Holendrzy zginęli w katastrofie samolotu" src="https://i.iplsc.com/chorwacja-trzej-holendrzy-zgineli-w-katastrofie-samolotu/000H6IZ6B4QA8BVG-C321.jpg" /></a>W zachodniej Chorwacji rozbił się holenderski samolot Cirrus 20. Odnaleziono ciała trzech osób. Przyczyna katastrofy nie jest jeszcze znana.</p><br clear="all" />

## Szkocja: Piętrowy autobus uderzył w most kolejowy. Są ranni
 - [https://wydarzenia.interia.pl/zagranica/news-szkocja-pietrowy-autobus-uderzyl-w-most-kolejowy-sa-ranni,nId,6791761](https://wydarzenia.interia.pl/zagranica/news-szkocja-pietrowy-autobus-uderzyl-w-most-kolejowy-sa-ranni,nId,6791761)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 19:14:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szkocja-pietrowy-autobus-uderzyl-w-most-kolejowy-sa-ranni,nId,6791761"><img align="left" alt="Szkocja: Piętrowy autobus uderzył w most kolejowy. Są ranni" src="https://i.iplsc.com/szkocja-pietrowy-autobus-uderzyl-w-most-kolejowy-sa-ranni/000H6IPBYE4EPBF8-C321.jpg" /></a>Dziesięć osób trafiło do szpitala po tym, jak piętrowy autobus uderzył w spód mostu kolejowego w Glasgow. W wyniku uderzenia dach pojazdu został odcięty.</p><br clear="all" />

## Brytyjski finansista: W 2030 Polska będzie bogatsza, niż my
 - [https://wydarzenia.interia.pl/zagranica/news-brytyjski-finansista-w-2030-polska-bedzie-bogatsza-niz-my,nId,6791766](https://wydarzenia.interia.pl/zagranica/news-brytyjski-finansista-w-2030-polska-bedzie-bogatsza-niz-my,nId,6791766)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 19:14:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brytyjski-finansista-w-2030-polska-bedzie-bogatsza-niz-my,nId,6791766"><img align="left" alt="Brytyjski finansista: W 2030 Polska będzie bogatsza, niż my" src="https://i.iplsc.com/brytyjski-finansista-w-2030-polska-bedzie-bogatsza-niz-my/000H6ISL8TEKMILI-C321.jpg" /></a>Brytyjski finansista Guy Hands ostrzega przed kolejnymi konsekwencjami rozstania Londynu i Brukseli. Mówił o &quot;schyłku geriatrycznym&quot; i stwierdził, że w 2030 roku Polska będzie bogatsza od Wielkiej Brytanii.</p><br clear="all" />

## Grecja: Podano wyniki wyborów parlamentarnych. Dominacja Nowej Demokracji
 - [https://wydarzenia.interia.pl/zagranica/news-grecja-podano-wyniki-wyborow-parlamentarnych-dominacja-nowej,nId,6791749](https://wydarzenia.interia.pl/zagranica/news-grecja-podano-wyniki-wyborow-parlamentarnych-dominacja-nowej,nId,6791749)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 18:40:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-grecja-podano-wyniki-wyborow-parlamentarnych-dominacja-nowej,nId,6791749"><img align="left" alt="Grecja: Podano wyniki wyborów parlamentarnych. Dominacja Nowej Demokracji" src="https://i.iplsc.com/grecja-podano-wyniki-wyborow-parlamentarnych-dominacja-nowej/000H6IJ41G8R6LHL-C321.jpg" /></a>Nowa Demokracja premiera Kyriakosa Micotakisa zdominowała wybory parlamentarne w Grecji - wynika z pierwszych częściowych oficjalnych danych po przeliczeniu ponad jednej trzeciej wszystkich głosów. Partia wyprzedziła Syrizę o 20 proc. </p><br clear="all" />

## Krytykowały Kreml i politykę Putina. Rosyjskie opozycjonistki z objawami zatrucia
 - [https://wydarzenia.interia.pl/zagranica/news-krytykowaly-kreml-i-polityke-putina-rosyjskie-opozycjonistki,nId,6791758](https://wydarzenia.interia.pl/zagranica/news-krytykowaly-kreml-i-polityke-putina-rosyjskie-opozycjonistki,nId,6791758)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 18:38:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-krytykowaly-kreml-i-polityke-putina-rosyjskie-opozycjonistki,nId,6791758"><img align="left" alt="Krytykowały Kreml i politykę Putina. Rosyjskie opozycjonistki z objawami zatrucia" src="https://i.iplsc.com/krytykowaly-kreml-i-polityke-putina-rosyjskie-opozycjonistki/000400PPDDOBLY6U-C321.jpg" /></a>Dwie rosyjskie dysydentki mogły zostać otrute w trakcie konferencji opozycjonistów krytycznych wobec Kremla - poinformował rzecznik policji w Berlinie. Śledztwo w tej sprawie prowadzi brandenburski Urząd Kryminalny.</p><br clear="all" />

## Wypadek na A1: Nie żyją dwie osoby, kolejne dwie są w ciężkim stanie
 - [https://wydarzenia.interia.pl/slaskie/news-wypadek-na-a1-nie-zyja-dwie-osoby-kolejne-dwie-sa-w-ciezkim-,nId,6791739](https://wydarzenia.interia.pl/slaskie/news-wypadek-na-a1-nie-zyja-dwie-osoby-kolejne-dwie-sa-w-ciezkim-,nId,6791739)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 17:36:48+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-wypadek-na-a1-nie-zyja-dwie-osoby-kolejne-dwie-sa-w-ciezkim-,nId,6791739"><img align="left" alt="Wypadek na A1: Nie żyją dwie osoby, kolejne dwie są w ciężkim stanie" src="https://i.iplsc.com/wypadek-na-a1-nie-zyja-dwie-osoby-kolejne-dwie-sa-w-ciezkim/000H6IFSHFQDPEYK-C321.jpg" /></a>Dwie osoby zginęły w wypadku busa na autostradzie A1 w okolicach Częstochowy. Lekarze walczą o życie dwóch kolejnych poszkodowanych. 41-letni kierowca busa był nietrzeźwy, miał ponad 1,5 promila alkoholu w organizmie.</p><br clear="all" />

## Polityk dotknął kolana przywódcy Indii. Nietypowe powitanie na lotnisku
 - [https://wydarzenia.interia.pl/zagranica/news-polityk-dotknal-kolana-przywodcy-indii-nietypowe-powitanie-n,nId,6791741](https://wydarzenia.interia.pl/zagranica/news-polityk-dotknal-kolana-przywodcy-indii-nietypowe-powitanie-n,nId,6791741)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 17:24:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polityk-dotknal-kolana-przywodcy-indii-nietypowe-powitanie-n,nId,6791741"><img align="left" alt="Polityk dotknął kolana przywódcy Indii. Nietypowe powitanie na lotnisku" src="https://i.iplsc.com/polityk-dotknal-kolana-przywodcy-indii-nietypowe-powitanie-n/000H6IF8N5O3CHGU-C321.jpg" /></a>Podczas powitania przywódcy Indii w Papui-Nowej Gwinei doszło do nietypowego powitania. Premier Marape w geście szacunku dotknął kolana Narendry Modiego.</p><br clear="all" />

## Władimir Sołowjow ogłasza zwycięstwo w Bachmucie. Pokazał ukradziony herb miasta
 - [https://wydarzenia.interia.pl/zagranica/news-wladimir-solowjow-oglasza-zwyciestwo-w-bachmucie-pokazal-ukr,nId,6791734](https://wydarzenia.interia.pl/zagranica/news-wladimir-solowjow-oglasza-zwyciestwo-w-bachmucie-pokazal-ukr,nId,6791734)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 16:50:12+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wladimir-solowjow-oglasza-zwyciestwo-w-bachmucie-pokazal-ukr,nId,6791734"><img align="left" alt="Władimir Sołowjow ogłasza zwycięstwo w Bachmucie. Pokazał ukradziony herb miasta" src="https://i.iplsc.com/wladimir-solowjow-oglasza-zwyciestwo-w-bachmucie-pokazal-ukr/000H6IC19TCAGFRK-C321.jpg" /></a>Przepraszam, ale tak zaczniemy... Bachmut to znowu Artiomowsk - ogłosił Władimir Sołowjow w programie &quot;Niedzielny wieczór&quot; na antenie telewizji Rosja 1. Kremlowska propaganda rozpoczęła ogłaszanie wielkiego zwycięstwa rosyjskiej armii w &quot;wojskowej operacji specjalnej&quot;.</p><br clear="all" />

## Grecja: Szukali jej przez trzy tygodnie. Jej ciało znaleziono na odludziu
 - [https://wydarzenia.interia.pl/zagranica/news-grecja-szukali-jej-przez-trzy-tygodnie-jej-cialo-znaleziono-,nId,6791727](https://wydarzenia.interia.pl/zagranica/news-grecja-szukali-jej-przez-trzy-tygodnie-jej-cialo-znaleziono-,nId,6791727)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 16:48:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-grecja-szukali-jej-przez-trzy-tygodnie-jej-cialo-znaleziono-,nId,6791727"><img align="left" alt="Grecja: Szukali jej przez trzy tygodnie. Jej ciało znaleziono na odludziu" src="https://i.iplsc.com/grecja-szukali-jej-przez-trzy-tygodnie-jej-cialo-znaleziono/000H6IASG7PYNE4D-C321.jpg" /></a>Po trzech tygodniach poszukiwań znaleziono ciało 74-letniej Brytyjki, która zaginęła w Grecji. Rodzina kobiety oskarża miejscową policję o utrudnianie poszukiwań.</p><br clear="all" />

## Czerwona farba na unijnym budynku. Prorosyjski protest w Bułgarii
 - [https://wydarzenia.interia.pl/zagranica/news-czerwona-farba-na-unijnym-budynku-prorosyjski-protest-w-bulg,nId,6791732](https://wydarzenia.interia.pl/zagranica/news-czerwona-farba-na-unijnym-budynku-prorosyjski-protest-w-bulg,nId,6791732)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 16:41:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czerwona-farba-na-unijnym-budynku-prorosyjski-protest-w-bulg,nId,6791732"><img align="left" alt="Czerwona farba na unijnym budynku. Prorosyjski protest w Bułgarii" src="https://i.iplsc.com/czerwona-farba-na-unijnym-budynku-prorosyjski-protest-w-bulg/000H6IANFBDXMAIR-C321.jpg" /></a>Podczas prorosyjskiej demonstracji w Sofii oblano czerwoną farbą przedstawicielstwo Komisji Europejskiej. Manifestujący domagali się &quot;zachowania przez Bułgarię neutralności i niewysyłania broni na Ukrainę&quot;.</p><br clear="all" />

## Włochy: Lotnisko w Katanii zamknięte z powodu aktywności Etny
 - [https://wydarzenia.interia.pl/zagranica/news-wlochy-lotnisko-w-katanii-zamkniete-z-powodu-aktywnosci-etny,nId,6791730](https://wydarzenia.interia.pl/zagranica/news-wlochy-lotnisko-w-katanii-zamkniete-z-powodu-aktywnosci-etny,nId,6791730)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 16:35:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlochy-lotnisko-w-katanii-zamkniete-z-powodu-aktywnosci-etny,nId,6791730"><img align="left" alt="Włochy: Lotnisko w Katanii zamknięte z powodu aktywności Etny" src="https://i.iplsc.com/wlochy-lotnisko-w-katanii-zamkniete-z-powodu-aktywnosci-etny/0007U6ZP961QLR35-C321.jpg" /></a>Z powodu nowej aktywności wulkanu Etna na Sycylii lotnisko w Katanii zostało zamknięte do poniedziałku do godziny 9 rano lub też do zakończenia obecnej erupcji - poinformowała w niedzielę dyrekcja portu lotniczego. Pasażerowie koniecznie powinni sprawdzić statusy swoich lotów. 
</p><br clear="all" />

## Trzaskowski odpowiada Semeniuk w sprawie Dworca Gdańskiego: PiS w pigułce
 - [https://wydarzenia.interia.pl/raport-transport-publiczny/news-trzaskowski-odpowiada-semeniuk-w-sprawie-dworca-gdanskiego-p,nId,6791710](https://wydarzenia.interia.pl/raport-transport-publiczny/news-trzaskowski-odpowiada-semeniuk-w-sprawie-dworca-gdanskiego-p,nId,6791710)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 15:46:54+00:00

<p><a href="https://wydarzenia.interia.pl/raport-transport-publiczny/news-trzaskowski-odpowiada-semeniuk-w-sprawie-dworca-gdanskiego-p,nId,6791710"><img align="left" alt="Trzaskowski odpowiada Semeniuk w sprawie Dworca Gdańskiego: PiS w pigułce" src="https://i.iplsc.com/trzaskowski-odpowiada-semeniuk-w-sprawie-dworca-gdanskiego-p/000H6I5H6OU8MGDI-C321.jpg" /></a>Radna PiS i wiceminister Olga Semeniuk-Patkowska napisała interpelację w sprawie sytuacji na Dworcu Gdańskim do prezydenta Warszawy Rafała Trzaskowskiego. Polityk odpowiedział jej w mediach społecznościowych, zwracając uwagę, że za dworzec odpowiada państwowa spółka. &quot;Bałagan i koszmarny nieprofesjonalizm tej ekipy bywa czasami zabawny, ale często jest zwyczajnie niebezpieczny&quot; - skomentował Trzaskowski.</p><br clear="all" />

## "Święty" liść z Parczewa na sprzedaż. Licytacja trwa
 - [https://wydarzenia.interia.pl/kraj/news-swiety-lisc-z-parczewa-na-sprzedaz-licytacja-trwa,nId,6791714](https://wydarzenia.interia.pl/kraj/news-swiety-lisc-z-parczewa-na-sprzedaz-licytacja-trwa,nId,6791714)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 15:30:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-swiety-lisc-z-parczewa-na-sprzedaz-licytacja-trwa,nId,6791714"><img align="left" alt="&quot;Święty&quot; liść z Parczewa na sprzedaż. Licytacja trwa" src="https://i.iplsc.com/swiety-lisc-z-parczewa-na-sprzedaz-licytacja-trwa/000H6I47FMYVLBT5-C321.jpg" /></a>&quot;Chciałbym, aby Parczew był znany ze swojej wyjątkowej historii, tradycji i wspaniałych ludzi. Wyszło, jak wyszło, ale trzeba ten szum przekuć w coś pożytecznego&quot; - pisze w mediach społecznościowych Adam Kościańczuk, autor licytacji liścia ze &quot;świętego&quot; drzewa. Akcja trwać będzie do poniedziałku, a uzyskane pieniądze trafią do Lubelskiego Stowarzyszenia Naukowego Na Rzecz Rozwoju Psychiatrii.</p><br clear="all" />

## Rosja: Dzieci zamknęły kolegę w stodole. Chłopiec spłonął żywcem
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-dzieci-zamknely-kolege-w-stodole-chlopiec-splonal-zywc,nId,6791712](https://wydarzenia.interia.pl/zagranica/news-rosja-dzieci-zamknely-kolege-w-stodole-chlopiec-splonal-zywc,nId,6791712)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 15:21:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-dzieci-zamknely-kolege-w-stodole-chlopiec-splonal-zywc,nId,6791712"><img align="left" alt="Rosja: Dzieci zamknęły kolegę w stodole. Chłopiec spłonął żywcem" src="https://i.iplsc.com/rosja-dzieci-zamknely-kolege-w-stodole-chlopiec-splonal-zywc/000H6I3HQ91F210Y-C321.jpg" /></a>We wsi na przedmieściach Moskwy doszło do tragicznego zdarzenia, 11-letni chłopiec spłonął żywcem. Znajdował się w stodole, gdzie zamknęły go inne dzieci. To oficjalne ustalenia Komitetu Śledczego Rosji.</p><br clear="all" />

## Gdańsk: Łosie spacerują po ulicach. Sceny jak z "Przystanku Alaska"
 - [https://wydarzenia.interia.pl/pomorskie/news-gdansk-losie-spaceruja-po-ulicach-sceny-jak-z-przystanku-ala,nId,6791698](https://wydarzenia.interia.pl/pomorskie/news-gdansk-losie-spaceruja-po-ulicach-sceny-jak-z-przystanku-ala,nId,6791698)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 14:44:20+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-gdansk-losie-spaceruja-po-ulicach-sceny-jak-z-przystanku-ala,nId,6791698"><img align="left" alt="Gdańsk: Łosie spacerują po ulicach. Sceny jak z &quot;Przystanku Alaska&quot;" src="https://i.iplsc.com/gdansk-losie-spaceruja-po-ulicach-sceny-jak-z-przystanku-ala/000H6HZY4JEERMXS-C321.jpg" /></a>Na jednej z gdańskich ulic pojawili się niespodziewani goście. Mieszkaniec nagrał nietypową scenę rodem z serialu &quot;Przystanek Alaska&quot; - po chodniku spacerowały dwa dorosłe łosie.</p><br clear="all" />

## Indie: Masowa bijatyka na weselu. Poszło o klimatyzator
 - [https://wydarzenia.interia.pl/zagranica/news-indie-masowa-bijatyka-na-weselu-poszlo-o-klimatyzator,nId,6791702](https://wydarzenia.interia.pl/zagranica/news-indie-masowa-bijatyka-na-weselu-poszlo-o-klimatyzator,nId,6791702)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 14:43:22+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-indie-masowa-bijatyka-na-weselu-poszlo-o-klimatyzator,nId,6791702"><img align="left" alt="Indie: Masowa bijatyka na weselu. Poszło o klimatyzator" src="https://i.iplsc.com/indie-masowa-bijatyka-na-weselu-poszlo-o-klimatyzator/000H6I1T3EQKLD11-C321.jpg" /></a>Masową bijatyką i opatrywaniem ran zakończyło się wesele w mieście Kannauj w stanie Uttar Pradesh w Indiach. Powodem scysji był posag panny młodej, a dokładniej fakt, że zabrakło w nim klimatyzatora.</p><br clear="all" />

## Rosja: Babcia wbiegła pod motocykl, bo kibicowała wnukowi
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-babcia-wbiegla-pod-motocykl-bo-kibicowala-wnukowi,nId,6791701](https://wydarzenia.interia.pl/zagranica/news-rosja-babcia-wbiegla-pod-motocykl-bo-kibicowala-wnukowi,nId,6791701)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 14:40:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-babcia-wbiegla-pod-motocykl-bo-kibicowala-wnukowi,nId,6791701"><img align="left" alt="Rosja: Babcia wbiegła pod motocykl, bo kibicowała wnukowi" src="https://i.iplsc.com/rosja-babcia-wbiegla-pod-motocykl-bo-kibicowala-wnukowi/000H6I09MRYIP27R-C321.jpg" /></a>W rosyjskim Krymsku doszło do poważnego wypadku podczas zawodów motocrossowych. Na trasę rajdu wbiegła 60-letnia kobieta, która kibicowała swojemu wnukowi. Niestety wpadł na nią przejeżdżający w tym momencie zawodnik.</p><br clear="all" />

## Egzamin ósmoklasisty 2023: Arkusze egzaminacyjne 2022 i 2021. Co było na egzaminie w poprzednich latach?
 - [https://wydarzenia.interia.pl/raport-egzamin-osmoklasisty-2023/news-egzamin-osmoklasisty-2023-arkusze-egzaminacyjne-2022-i-2021-,nId,6790214](https://wydarzenia.interia.pl/raport-egzamin-osmoklasisty-2023/news-egzamin-osmoklasisty-2023-arkusze-egzaminacyjne-2022-i-2021-,nId,6790214)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 14:32:43+00:00

<p><a href="https://wydarzenia.interia.pl/raport-egzamin-osmoklasisty-2023/news-egzamin-osmoklasisty-2023-arkusze-egzaminacyjne-2022-i-2021-,nId,6790214"><img align="left" alt="Egzamin ósmoklasisty 2023: Arkusze egzaminacyjne 2022 i 2021. Co było na egzaminie w poprzednich latach?" src="https://i.iplsc.com/egzamin-osmoklasisty-2023-arkusze-egzaminacyjne-2022-i-2021/000H5KWE3O5QBAL2-C321.jpg" /></a>Egzamin ósmoklasisty zbliża się wielkimi krokami. Zgodnie z harmonogramem będzie przeprowadzany od wtorku 23 maja do czwartku 25 maja 2023 roku. Uczniowie zobowiązani są do przystąpienia do trzech egzaminów - z języka polskiego, matematyki i języka obcego nowożytnego. By dobrze przygotować się do sprawdzenia wiedzy z tych przedmiotów, warto zapoznać się z arkuszami z poprzednich lat. Co znalazło się w arkuszach egzaminacyjnych w roku 2022, 2021, 2020 i 2019? Interia podpowiada.</p><br clear="all" />

## Żołnierz zwolniony z rosyjskiej niewoli. "To była egzekucja"
 - [https://wydarzenia.interia.pl/zagranica/news-zolnierz-zwolniony-z-rosyjskiej-niewoli-to-byla-egzekucja,nId,6791682](https://wydarzenia.interia.pl/zagranica/news-zolnierz-zwolniony-z-rosyjskiej-niewoli-to-byla-egzekucja,nId,6791682)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 13:52:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zolnierz-zwolniony-z-rosyjskiej-niewoli-to-byla-egzekucja,nId,6791682"><img align="left" alt="Żołnierz zwolniony z rosyjskiej niewoli. &quot;To była egzekucja&quot;" src="https://i.iplsc.com/zolnierz-zwolniony-z-rosyjskiej-niewoli-to-byla-egzekucja/000H6HE1FBAISDIE-C321.jpg" /></a>- Rosjanie celowo zorganizowali atak terrorystyczny w Oleniwce. To była egzekucja ukraińskich obrońców - twierdzi żołnierz brygady szturmowej &quot;AZOW&quot;. Uwolniony z rosyjskiej niewoli mężczyzna posługujący się pseudonimem &quot;Komunista&quot; opowiedział, jak wyglądał atak na ośrodek jeniecki.</p><br clear="all" />

## "Mołdawianie to Europejczycy". Wielki wiec poparcia w Kiszyniowie
 - [https://wydarzenia.interia.pl/zagranica/news-moldawianie-to-europejczycy-wielki-wiec-poparcia-w-kiszyniow,nId,6791687](https://wydarzenia.interia.pl/zagranica/news-moldawianie-to-europejczycy-wielki-wiec-poparcia-w-kiszyniow,nId,6791687)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 13:45:28+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-moldawianie-to-europejczycy-wielki-wiec-poparcia-w-kiszyniow,nId,6791687"><img align="left" alt="&quot;Mołdawianie to Europejczycy&quot;. Wielki wiec poparcia w Kiszyniowie" src="https://i.iplsc.com/moldawianie-to-europejczycy-wielki-wiec-poparcia-w-kiszyniow/000H6HIXO292KPVA-C321.jpg" /></a>W Kiszyniowie odbyła się proeuropejska manifestacja, która zgromadziła 80 tysięcy osób. Przed tłumem wystąpiła szefowa Parlamentu Europejskiego Roberta Metsola. &quot;Mołdawianie to Europejczycy&quot; - podkreślała prezydent Maia Sandu.</p><br clear="all" />

## Rosyjski polityk: Polska musi zostać ukarana. Żąda miliardów i rewizji granic
 - [https://wydarzenia.interia.pl/zagranica/news-rosyjski-polityk-polska-musi-zostac-ukarana-zada-miliardow-i,nId,6791669](https://wydarzenia.interia.pl/zagranica/news-rosyjski-polityk-polska-musi-zostac-ukarana-zada-miliardow-i,nId,6791669)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 12:43:49+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosyjski-polityk-polska-musi-zostac-ukarana-zada-miliardow-i,nId,6791669"><img align="left" alt="Rosyjski polityk: Polska musi zostać ukarana. Żąda miliardów i rewizji granic" src="https://i.iplsc.com/rosyjski-polityk-polska-musi-zostac-ukarana-zada-miliardow-i/000H6H3RJQ37RBAG-C321.jpg" /></a>Przewodniczący rosyjskiej Dumy Państwowej Wiaczesław Wołodin żąda od Polski 750 miliardów dolarów za &quot;wyzwolenie spod niemieckiej okupacji&quot;. Zdaniem polityka pieniądze miałyby zostać wypłacone w zamian za działania armii radzieckiej w naszym kraju.</p><br clear="all" />

## Sprzeczne doniesienia o Bachmucie. Ukraińcy zapewniają: Miasto nie padło
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-sprzeczne-doniesienia-o-bachmucie-ukraincy-zapewniaja-miasto,nId,6791666](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-sprzeczne-doniesienia-o-bachmucie-ukraincy-zapewniaja-miasto,nId,6791666)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 12:16:13+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-sprzeczne-doniesienia-o-bachmucie-ukraincy-zapewniaja-miasto,nId,6791666"><img align="left" alt="Sprzeczne doniesienia o Bachmucie. Ukraińcy zapewniają: Miasto nie padło" src="https://i.iplsc.com/sprzeczne-doniesienia-o-bachmucie-ukraincy-zapewniaja-miasto/000H6H498TFN3ERN-C321.jpg" /></a>Duża część Bachmutu jest kontrolowana przez wojska rosyjskie, ale miasto nie padło, a ukraińscy obrońcy wciąż walczą - taki przekaz płynie obecnie z strony Kijowa. Trwająca od miesięcy bitwa o Bachmut uchodzi na najkrwawsze starcie od czasu pełnowymiarowej agresji Rosji na Ukrainę.</p><br clear="all" />

## Aleksandr Łukaszenka uderza w Polaków na Białorusi. Zmiany w ustawie o "obywatelstwie"
 - [https://wydarzenia.interia.pl/zagranica/news-aleksandr-lukaszenka-uderza-w-polakow-na-bialorusi-zmiany-w-,nId,6791658](https://wydarzenia.interia.pl/zagranica/news-aleksandr-lukaszenka-uderza-w-polakow-na-bialorusi-zmiany-w-,nId,6791658)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 12:07:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-aleksandr-lukaszenka-uderza-w-polakow-na-bialorusi-zmiany-w-,nId,6791658"><img align="left" alt="Aleksandr Łukaszenka uderza w Polaków na Białorusi. Zmiany w ustawie o &quot;obywatelstwie&quot;" src="https://i.iplsc.com/aleksandr-lukaszenka-uderza-w-polakow-na-bialorusi-zmiany-w/000H6GZUHJBUGO14-C321.jpg" /></a>- Białoruski reżim dokręca śrubę. Starają się dowiedzieć, kto ma Kartę Polaka, by za to ukarać. Białoruscy urzędnicy uważają, że Karta Polaka jest jakby drugim obywatelstwem - twierdzi Leszek Szerepka, były ambasador Polski na Białorusi. Dyplomata na łamach Biełsatu skomentował zmiany wprowadzane w ustawie &quot;O obywatelstwie&quot;.</p><br clear="all" />

## Włochy: Czarna woda w fontannie Fontanna di Trevi. To akcja aktywistów
 - [https://wydarzenia.interia.pl/zagranica/news-wlochy-czarna-woda-w-fontannie-fontanna-di-trevi-to-akcja-ak,nId,6791656](https://wydarzenia.interia.pl/zagranica/news-wlochy-czarna-woda-w-fontannie-fontanna-di-trevi-to-akcja-ak,nId,6791656)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 11:49:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlochy-czarna-woda-w-fontannie-fontanna-di-trevi-to-akcja-ak,nId,6791656"><img align="left" alt="Włochy: Czarna woda w fontannie Fontanna di Trevi. To akcja aktywistów" src="https://i.iplsc.com/wlochy-czarna-woda-w-fontannie-fontanna-di-trevi-to-akcja-ak/000H6GV32HB3IB3I-C321.jpg" /></a>&quot;Nasz kraj umiera&quot; - takie okrzyki słychać było dziś przy Fontannie di Trevi w Rzymie. Grupa kilku aktywistów wlała do słynnego włoskiego zabytku czarny barwnik i weszła do wody, by zwrócić uwagę władz na zmiany klimatyczne. To kolejna taka akcja w Wiecznym Mieście. </p><br clear="all" />

## Czy Alaksandr Łukaszenka ma sobowtóra? Mnożą się spekulacje
 - [https://wydarzenia.interia.pl/zagranica/news-czy-alaksandr-lukaszenka-ma-sobowtora-mnoza-sie-spekulacje,nId,6791643](https://wydarzenia.interia.pl/zagranica/news-czy-alaksandr-lukaszenka-ma-sobowtora-mnoza-sie-spekulacje,nId,6791643)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 11:23:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czy-alaksandr-lukaszenka-ma-sobowtora-mnoza-sie-spekulacje,nId,6791643"><img align="left" alt="Czy Alaksandr Łukaszenka ma sobowtóra? Mnożą się spekulacje" src="https://i.iplsc.com/czy-alaksandr-lukaszenka-ma-sobowtora-mnoza-sie-spekulacje/000H6GSPAXTDDPJI-C321.jpg" /></a>Wobec doniesień o problemach zdrowotnych białoruskiego dyktatora nasilają się spekulacje, czy Alaksandr Łukaszenka ma sobowtóra. Według dziennikarza Aleksieja Burłakowa, są ku temu przesłanki. </p><br clear="all" />

## Były żołnierz po amputacji nóg zdobył Mount Everest
 - [https://wydarzenia.interia.pl/zagranica/news-byly-zolnierz-po-amputacji-nog-zdobyl-mount-everest,nId,6791652](https://wydarzenia.interia.pl/zagranica/news-byly-zolnierz-po-amputacji-nog-zdobyl-mount-everest,nId,6791652)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 11:07:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-byly-zolnierz-po-amputacji-nog-zdobyl-mount-everest,nId,6791652"><img align="left" alt="Były żołnierz po amputacji nóg zdobył Mount Everest" src="https://i.iplsc.com/byly-zolnierz-po-amputacji-nog-zdobyl-mount-everest/000H6GROLS8PWHNT-C321.jpg" /></a>Dla Hariego Budhy Magara nie ma góry nie do zdobycia. Były żołnierz udowodnił to wspinając się na najwyższy szczyt na świecie - Mount Everest (8848 m). Magara 13 lat temu przeszedł operację amputacji obu nóg po tym, jak nadepnął na minę podczas misji w Afganistanie. </p><br clear="all" />

## Zamaskowane osoby na polskiej granicy. Straż Graniczna reaguje
 - [https://wydarzenia.interia.pl/kraj/news-zamaskowane-osoby-na-polskiej-granicy-straz-graniczna-reaguj,nId,6791631](https://wydarzenia.interia.pl/kraj/news-zamaskowane-osoby-na-polskiej-granicy-straz-graniczna-reaguj,nId,6791631)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 10:37:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zamaskowane-osoby-na-polskiej-granicy-straz-graniczna-reaguj,nId,6791631"><img align="left" alt="Zamaskowane osoby na polskiej granicy. Straż Graniczna reaguje" src="https://i.iplsc.com/zamaskowane-osoby-na-polskiej-granicy-straz-graniczna-reaguj/000H6GPJVD7W1DQP-C321.jpg" /></a>W sobotę z Białorusi do Polski nielegalnie próbowało się dostać 81 osób - poinformowała Straż Graniczna. Część z nich była zamaskowana i posiadała radiotelefony. Funkcjonariusze zatrzymali także osoby, które przewoziły nielegalnych imigrantów. </p><br clear="all" />

## Grecy wybierają nowy skład parlamentu. Na czele sondaży partia premiera
 - [https://wydarzenia.interia.pl/zagranica/news-grecy-wybieraja-nowy-sklad-parlamentu-na-czele-sondazy-parti,nId,6791628](https://wydarzenia.interia.pl/zagranica/news-grecy-wybieraja-nowy-sklad-parlamentu-na-czele-sondazy-parti,nId,6791628)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 10:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-grecy-wybieraja-nowy-sklad-parlamentu-na-czele-sondazy-parti,nId,6791628"><img align="left" alt="Grecy wybierają nowy skład parlamentu. Na czele sondaży partia premiera" src="https://i.iplsc.com/grecy-wybieraja-nowy-sklad-parlamentu-na-czele-sondazy-parti/000H6GLCSO0002BC-C321.jpg" /></a>Grecy idą do urn. O godz. 7.00 czasu lokalnego (6.00 w Polsce) w niedzielę rozpoczęły się wybory do greckiego parlamentu. Partie polityczne walczą o obsadzenie 300 miejsc w izbie ustawodawczej. Według ostatnich sondaży w wyścigu prowadzi Nowa Demokracja premiera Kyriakosa Micotakisa.</p><br clear="all" />

## Abp Marek Jędraszewski odznaczony orderem za służbę ojczyźnie i Kościołowi
 - [https://wydarzenia.interia.pl/kraj/news-abp-marek-jedraszewski-odznaczony-orderem-za-sluzbe-ojczyzni,nId,6791615](https://wydarzenia.interia.pl/kraj/news-abp-marek-jedraszewski-odznaczony-orderem-za-sluzbe-ojczyzni,nId,6791615)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 09:35:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-abp-marek-jedraszewski-odznaczony-orderem-za-sluzbe-ojczyzni,nId,6791615"><img align="left" alt="Abp Marek Jędraszewski odznaczony orderem za służbę ojczyźnie i Kościołowi" src="https://i.iplsc.com/abp-marek-jedraszewski-odznaczony-orderem-za-sluzbe-ojczyzni/000H6GIAL62SW3RN-C321.jpg" /></a>Prezydent Andrzej Duda odznaczył metropolitę krakowskiego abp. Marka Jędraszewskiego Krzyżem Komandorskim Orderu Odrodzenia Polski - podała Archidiecezja Krakowska, dodając, że wyróżnienie przyznano za służbę ojczyźnie i Kościołowi.</p><br clear="all" />

## Rosja: Tajemnicza śmierć wiceministra nauki. Miał 46 lat
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-tajemnicza-smierc-wiceministra-nauki-mial-46-lat,nId,6791607](https://wydarzenia.interia.pl/zagranica/news-rosja-tajemnicza-smierc-wiceministra-nauki-mial-46-lat,nId,6791607)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 09:22:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-tajemnicza-smierc-wiceministra-nauki-mial-46-lat,nId,6791607"><img align="left" alt="Rosja: Tajemnicza śmierć wiceministra nauki. Miał 46 lat" src="https://i.iplsc.com/rosja-tajemnicza-smierc-wiceministra-nauki-mial-46-lat/000H6GHHW9NIMK1D-C321.jpg" /></a>W wieku 46 lat, zmarł rosyjski wiceminister nauki i szkolnictwa wyższego Piotr Kuczerenko. Mężczyzna miał źle poczuć się na pokładzie samolotu, którym wracał z podróży służbowej. Po wylądowaniu, mimo pomocy lekarskiej, zmarł. Kuczerenko prywatnie był mężem znanej w Rosji gruzińskiej piosenkarki popowej Diany Ghurckai. </p><br clear="all" />

## Ambasador Ukrainy z nowym wpisem. Poprzedni został usunięty
 - [https://wydarzenia.interia.pl/kraj/news-ambasador-ukrainy-z-nowym-wpisem-poprzedni-zostal-usuniety,nId,6791591](https://wydarzenia.interia.pl/kraj/news-ambasador-ukrainy-z-nowym-wpisem-poprzedni-zostal-usuniety,nId,6791591)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 08:42:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ambasador-ukrainy-z-nowym-wpisem-poprzedni-zostal-usuniety,nId,6791591"><img align="left" alt="Ambasador Ukrainy z nowym wpisem. Poprzedni został usunięty" src="https://i.iplsc.com/ambasador-ukrainy-z-nowym-wpisem-poprzedni-zostal-usuniety/000H6GE36YE5I41T-C321.jpg" /></a>&quot;Jesteśmy otwarci na dialog, współpracę w sprawie historii, rozumiemy jej znaczenie, czcimy pamięć ofiar. Razem silniejsi&quot; - napisał na Twitterze Wasyl Zwarycz, ambasador Ukrainy w Polsce. Wyjaśnił, że jego sobotni wpis odnosił się do słów rzecznika MSZ Łukasza Jasiny, który stwierdził, że Wołodymyr Zełenski powinien przeprosić Polaków za Wołyń. Poprzedni wpis dyplomaty zniknął z Twittera - na Facebooku dostępna jest jego wersja po ukraińsku.</p><br clear="all" />

## Pogoda na niedzielę. Ciepło, ale gdzieniegdzie zagrzmi
 - [https://wydarzenia.interia.pl/kraj/news-pogoda-na-niedziele-cieplo-ale-gdzieniegdzie-zagrzmi,nId,6791581](https://wydarzenia.interia.pl/kraj/news-pogoda-na-niedziele-cieplo-ale-gdzieniegdzie-zagrzmi,nId,6791581)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 08:24:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogoda-na-niedziele-cieplo-ale-gdzieniegdzie-zagrzmi,nId,6791581"><img align="left" alt="Pogoda na niedzielę. Ciepło, ale gdzieniegdzie zagrzmi" src="https://i.iplsc.com/pogoda-na-niedziele-cieplo-ale-gdzieniegdzie-zagrzmi/000H6GAR4B89J0CR-C321.jpg" /></a>W niedzielę na przeważającym obszarze kraju temperatura wyniesie między 20 a 24 stopniami Celsjusza - powiedziała Ewa Łapińska z Centralnego Biura Prognoz IMGW-PIB. Mieszkańcy południowo-zachodnich krańców Polski mogą spodziewać się burz. Od przyszłego tygodnia pogoda się popsuje. Niewykluczone są nawet nocne, przygruntowe przymrozki. 

</p><br clear="all" />

## Ukraińcy utracili Bachmut? Konsternacja po słowach Zełenskiego
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-utracili-bachmut-konsternacja-po-slowach-zelenskieg,nId,6791589](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-utracili-bachmut-konsternacja-po-slowach-zelenskieg,nId,6791589)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 08:17:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-utracili-bachmut-konsternacja-po-slowach-zelenskieg,nId,6791589"><img align="left" alt="Ukraińcy utracili Bachmut? Konsternacja po słowach Zełenskiego" src="https://i.iplsc.com/ukraincy-utracili-bachmut-konsternacja-po-slowach-zelenskieg/000H6GCZ67IYCU7I-C321.jpg" /></a>Międzynarodowe agencje prasowe podały, że wypowiedź ukraińskiego prezydenta Wołodymyra Zełenskiego o sytuacji w Bachmucie oznacza, że potwierdził on utratę przez Ukrainę tego miasta. Według strony rosyjskiej zostało ono przez zdobyte przez Rosjan. Tymczasem sztab generalny Sił Zbrojnych Ukrainy podaje, że walki o Bachmut wciąż trwają. Co dokładnie powiedział Zełenski i dlaczego jego słowa wywołały konsternację? Wyjaśniamy.</p><br clear="all" />

## Nocna strzelanina w Łodzi. "Biegł w jego stronę z siekierą"
 - [https://wydarzenia.interia.pl/lodzkie/news-nocna-strzelanina-w-lodzi-biegl-w-jego-strone-z-siekiera,nId,6791595](https://wydarzenia.interia.pl/lodzkie/news-nocna-strzelanina-w-lodzi-biegl-w-jego-strone-z-siekiera,nId,6791595)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 08:13:34+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-nocna-strzelanina-w-lodzi-biegl-w-jego-strone-z-siekiera,nId,6791595"><img align="left" alt="Nocna strzelanina w Łodzi. &quot;Biegł w jego stronę z siekierą&quot;" src="https://i.iplsc.com/nocna-strzelanina-w-lodzi-biegl-w-jego-strone-z-siekiera/000G0F5YLJUP24H0-C321.jpg" /></a>Kierowca bmw strzelał do innego mężczyzny na terenie myjni samochodowej przy ulicy Rokicińskiej w Łodzi - informuje radio RMF FM. Z nieoficjalnych informacji wynika, że jedna osoba trafiła do szpitala z raną postrzałową twarzoczaszki.</p><br clear="all" />

## Potężna eksplozja w Rosji. Oskarżają Ukrainę, jest odpowiedź
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-potezna-eksplozja-w-rosji-oskarzaja-ukraine-jest-odpowiedz,nId,6791583](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-potezna-eksplozja-w-rosji-oskarzaja-ukraine-jest-odpowiedz,nId,6791583)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 08:05:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-potezna-eksplozja-w-rosji-oskarzaja-ukraine-jest-odpowiedz,nId,6791583"><img align="left" alt="Potężna eksplozja w Rosji. Oskarżają Ukrainę, jest odpowiedź" src="https://i.iplsc.com/potezna-eksplozja-w-rosji-oskarzaja-ukraine-jest-odpowiedz/000H6GC6TI2QMVJ4-C321.jpg" /></a>Do potężnej eksplozji i pożaru doszło na terytorium Rosji w pobliżu granicy z Ukrainą. Według gubernatora obwodu biełgorodzkiego był to wynik rzekomego &quot;ostrzału&quot;. Ukraińskie media wskazują, że do zdarzenia mogli doprowadzić sami Rosjanie.</p><br clear="all" />

## Wołdymyr Zełenski: Bachmut zniszczony, jest już tylko w naszych sercach
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-woldymyr-zelenski-bachmut-zniszczony-jest-juz-tylko-w-naszyc,nId,6791569](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-woldymyr-zelenski-bachmut-zniszczony-jest-juz-tylko-w-naszyc,nId,6791569)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 06:31:17+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-woldymyr-zelenski-bachmut-zniszczony-jest-juz-tylko-w-naszyc,nId,6791569"><img align="left" alt="Wołdymyr Zełenski: Bachmut zniszczony, jest już tylko w naszych sercach" src="https://i.iplsc.com/woldymyr-zelenski-bachmut-zniszczony-jest-juz-tylko-w-naszyc/000H6G5S3MYYVLCY-C321.jpg" /></a>Prezydent Ukrainy Wołodymyr Zełenski potwierdził w niedzielę utratę kontroli nad Bachmutem. - Myślę, że nie - powiedział podczas spotkania z prezydentem USA Joe Bidenem, gdy zapytano go, czy miasto pozostaje pod kontrolą Kijowa.  - Dzisiaj jest tylko w naszych sercach - dodał, komentując skalę zniszczeń. Dzień wcześniej szef Grupy Wagnera Jewgienij Prigożyn ogłosił przejęcie pełnej kontroli nad oblężonym miastem.</p><br clear="all" />

## Włochy proszą o pomoc w związku z powodziami. Odpowiedzieli polscy strażacy
 - [https://wydarzenia.interia.pl/zagranica/news-wlochy-prosza-o-pomoc-w-zwiazku-z-powodziami-odpowiedzieli-p,nId,6791556](https://wydarzenia.interia.pl/zagranica/news-wlochy-prosza-o-pomoc-w-zwiazku-z-powodziami-odpowiedzieli-p,nId,6791556)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 06:19:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlochy-prosza-o-pomoc-w-zwiazku-z-powodziami-odpowiedzieli-p,nId,6791556"><img align="left" alt="Włochy proszą o pomoc w związku z powodziami. Odpowiedzieli polscy strażacy" src="https://i.iplsc.com/wlochy-prosza-o-pomoc-w-zwiazku-z-powodziami-odpowiedzieli-p/000H6G3NKOPKOSV3-C321.jpg" /></a>W związku z trudną sytuacja w regionie Emilia-Romania, Włochy zwróciły się o międzynarodową pomoc w postaci 4 modułów pomp o dużej wydajności. &quot;W odpowiedzi polscy strażacy są gotowi. Misja Italia&quot; - poinformował Komendant Główny Państwowej Straży Pożarnej Andrzej Bartkowiak. Do tej pory w powodziach we Włoszech zginęło 14 osób. Straty szacowane są na miliardy euro.

</p><br clear="all" />

## Wojna. Joe Biden ogłasza nową transzę pomocy dla Ukrainy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-joe-biden-oglasza-nowa-transze-pomocy-dla-ukrainy,nId,6791557](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-joe-biden-oglasza-nowa-transze-pomocy-dla-ukrainy,nId,6791557)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 05:52:07+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-joe-biden-oglasza-nowa-transze-pomocy-dla-ukrainy,nId,6791557"><img align="left" alt="Wojna. Joe Biden ogłasza nową transzę pomocy dla Ukrainy" src="https://i.iplsc.com/wojna-joe-biden-oglasza-nowa-transze-pomocy-dla-ukrainy/000H6G4EFH8OPJMI-C321.jpg" /></a>Stany Zjednoczone robią wszystko, by wzmocnić obronę Ukrainy - powiedział amerykański prezydent, Joe Biden, ogłaszając nowy pakiet pomocy dla walczącego z rosyjskim najeźdźcą Kijowa. Na wspólnej konferencji prasowej prezydent Zełenskki potwierdził, że okupowany przez Rosjan Bachmut został &quot;zupełnie zniszczony&quot;. - Jest już tylko w naszych sercach - dodał.</p><br clear="all" />

## Nie żyje Martin Amis. Pisarz miał 73 lata
 - [https://wydarzenia.interia.pl/zagranica/news-nie-zyje-martin-amis-pisarz-mial-73-lata,nId,6791551](https://wydarzenia.interia.pl/zagranica/news-nie-zyje-martin-amis-pisarz-mial-73-lata,nId,6791551)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 05:44:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nie-zyje-martin-amis-pisarz-mial-73-lata,nId,6791551"><img align="left" alt="Nie żyje Martin Amis. Pisarz miał 73 lata" src="https://i.iplsc.com/nie-zyje-martin-amis-pisarz-mial-73-lata/000H6G32R90868MH-C321.jpg" /></a>Zmarł Martin Louis Amis, brytyjski pisarz - podaje &quot;The New York Times&quot;, powołując się na informację od żony zmarłego, Isabel Fonseca. Amis miał 73 lata, przed śmiercią chorował na raka przełyku. </p><br clear="all" />

## Salwador: Wybuch paniki na stadionie. Dziewięć osób zginęło, 90 zostało rannych
 - [https://wydarzenia.interia.pl/zagranica/news-salwador-wybuch-paniki-na-stadionie-dziewiec-osob-zginelo-90,nId,6791549](https://wydarzenia.interia.pl/zagranica/news-salwador-wybuch-paniki-na-stadionie-dziewiec-osob-zginelo-90,nId,6791549)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 05:31:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-salwador-wybuch-paniki-na-stadionie-dziewiec-osob-zginelo-90,nId,6791549"><img align="left" alt="Salwador: Wybuch paniki na stadionie. Dziewięć osób zginęło, 90 zostało rannych" src="https://i.iplsc.com/salwador-wybuch-paniki-na-stadionie-dziewiec-osob-zginelo-90/000H6G2L50L09BRW-C321.jpg" /></a>Co najmniej dziewięć osób zostało stratowanych na śmierć, a ponad 90 zostało rannych podczas meczu piłkarskiego w stolicy Salwadoru San Salvador. Do wybuchu paniki na stadionie doprowadziła prawdopodobnie próba sforsowania zamkniętych bram obiektu przez kibiców próbujących przedostać się na jego teren. Prezydent kraju zapowiedział, że odpowiedzialni za to zdarzenie poniosą karę.</p><br clear="all" />

## Pędził ulicami Szczecina bez prawa jazdy. Spieszył się na egzamin
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-pedzil-ulicami-szczecina-bez-prawa-jazdy-spieszyl-sie-na-egz,nId,6790219](https://wydarzenia.interia.pl/zachodniopomorskie/news-pedzil-ulicami-szczecina-bez-prawa-jazdy-spieszyl-sie-na-egz,nId,6790219)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 05:13:00+00:00

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-pedzil-ulicami-szczecina-bez-prawa-jazdy-spieszyl-sie-na-egz,nId,6790219"><img align="left" alt="Pędził ulicami Szczecina bez prawa jazdy. Spieszył się na egzamin" src="https://i.iplsc.com/pedzil-ulicami-szczecina-bez-prawa-jazdy-spieszyl-sie-na-egz/000FRI70D0S2WGH5-C321.jpg" /></a>To byłą nietypowa kontrola przeprowadzona przez szczecińskich policjantów. Funkcjonariusze zatrzymali 44-latka za przekroczenie prędkości. Okazało się, że kierowca nie posiada uprawnień do prowadzenia pojazdów, a śpieszy się... na egzamin. Mężczyzna prawdopodobnie przez dłuższy czas nie będzie mógł wsiąść za kółko. </p><br clear="all" />

## Egzamin ósmoklasisty 2023. Czy można nie zdać egzaminu ósmoklasisty?
 - [https://wydarzenia.interia.pl/raport-egzamin-osmoklasisty-2023/news-egzamin-osmoklasisty-2023-czy-mozna-nie-zdac-egzaminu-osmokl,nId,6785805](https://wydarzenia.interia.pl/raport-egzamin-osmoklasisty-2023/news-egzamin-osmoklasisty-2023-czy-mozna-nie-zdac-egzaminu-osmokl,nId,6785805)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 05:03:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-egzamin-osmoklasisty-2023/news-egzamin-osmoklasisty-2023-czy-mozna-nie-zdac-egzaminu-osmokl,nId,6785805"><img align="left" alt="Egzamin ósmoklasisty 2023. Czy można nie zdać egzaminu ósmoklasisty?" src="https://i.iplsc.com/egzamin-osmoklasisty-2023-czy-mozna-nie-zdac-egzaminu-osmokl/0002AGMPHQ7TI55A-C321.jpg" /></a>Egzaminy ósmoklasisty w 2023 roku odbędą się 23, 24 i 25 maja. W sumie można w nich zdobyć 100 punktów na potrzeby rekrutacji do kolejnej szkoły. Co zrobić, jeżeli do wymarzonych wyników zabraknie sporo punktów? Czy można nie zdać egzaminu ósmoklasisty? Co robić, kiedy czujemy, że nie poszło nam za dobrze?</p><br clear="all" />

## Czy 21 maja jest niedziela handlowa? Tutaj zrobisz dziś zakupy. Podpowiadamy
 - [https://wydarzenia.interia.pl/kraj/news-czy-21-maja-jest-niedziela-handlowa-tutaj-zrobisz-dzis-zakup,nId,6785437](https://wydarzenia.interia.pl/kraj/news-czy-21-maja-jest-niedziela-handlowa-tutaj-zrobisz-dzis-zakup,nId,6785437)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 04:31:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-czy-21-maja-jest-niedziela-handlowa-tutaj-zrobisz-dzis-zakup,nId,6785437"><img align="left" alt="Czy 21 maja jest niedziela handlowa? Tutaj zrobisz dziś zakupy. Podpowiadamy" src="https://i.iplsc.com/czy-21-maja-jest-niedziela-handlowa-tutaj-zrobisz-dzis-zakup/000H61LEQTV0AHJC-C321.jpg" /></a>Czy dziś jest niedziela handlowa? Odpowiedzi na to pytanie co tydzień szukają tysiące Polaków, którzy tego dnia chcą wybrać się do supermarketów, galerii handlowych i innych większych sklepów. W całym 2023 roku zakaz handlu nie obejmuje siedmiu niedziel. Czy 21 maja to niedziela handlowa? Gdzie można zrobić dziś zakupy?</p><br clear="all" />

## Walki o Bachmut. Putin pogratulował rosyjskim żołnierzom zdobycia miasta
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-walki-o-bachmut-putin-pogratulowal-rosyjskim-zolnierzom-zdob,nId,6791545](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-walki-o-bachmut-putin-pogratulowal-rosyjskim-zolnierzom-zdob,nId,6791545)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-21 04:01:09+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-walki-o-bachmut-putin-pogratulowal-rosyjskim-zolnierzom-zdob,nId,6791545"><img align="left" alt="Walki o Bachmut. Putin pogratulował rosyjskim żołnierzom zdobycia miasta" src="https://i.iplsc.com/walki-o-bachmut-putin-pogratulowal-rosyjskim-zolnierzom-zdob/000H6G0PYILKY88H-C321.jpg" /></a>Rosja w sobotę ogłosiła, że zdobyła Bachmut, a prezydent Władimir Putin obiecał walczącym tam żołnierzom specjalne nagrody. Kijów jednak zapewnia, że ukraińskie jednostki nadal walczą. Zdobycie tego miasta oznaczałoby pierwsze duże zwycięstwo Moskwy od ponad 10 miesięcy. Bitwa pod Bachmutem trwa od sierpnia 2022 roku i, zdaniem analityków, jest jednym z największych i najcięższych starć tej wojny.</p><br clear="all" />

