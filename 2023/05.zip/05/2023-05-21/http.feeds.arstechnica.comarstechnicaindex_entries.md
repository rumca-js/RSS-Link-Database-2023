# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Ready the Ig Nobel: Researchers incorporate used diapers into concrete
 - [https://arstechnica.com/?p=1940676](https://arstechnica.com/?p=1940676)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-05-21 11:00:25+00:00

Used disposable diapers can be added to concrete without killing its strength.

