# Source:DistroTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCVls1GmFKf6WlTraIb_IaJg, language:en-US

## Set Your Desktop On Fire With These GNOME Extensions
 - [https://www.youtube.com/watch?v=pqO_y_zSyjA](https://www.youtube.com/watch?v=pqO_y_zSyjA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCVls1GmFKf6WlTraIb_IaJg
 - date published: 2023-05-21 13:00:39+00:00

I really like the latest versions of the GNOME 40 series.  But there are a few things that I miss from GNOME in the distant past (15 years ago or so).  And that is the cool animations.  So let's add a few of them back into GNOME...

REFERENCED:
► https://extensions.gnome.org/extension/3210/compiz-windows-effect/
► https://extensions.gnome.org/extension/4679/burn-my-windows/
► https://extensions.gnome.org/extension/4648/desktop-cube/

WANT TO SUPPORT THE CHANNEL? 
💰 Patreon: https://www.patreon.com/distrotube 
💳 Paypal: https://www.youtube.com/redirect?event=channel_banner&amp;redir_token=QUFFLUhqazNocEhiaGFBT1l1MnRHbnlIcHFKbXJWVnpQd3xBQ3Jtc0tsLVZJc19YeFlwZ2JqbXVOa3g0Skw4TVhTV2otNm1tM3A1bUNnamh3S2V6OGQtLTBnSjBxYTlvUXMxeEVIS3o4US10NENHMUQ3STk2a01FOFBhUnZjZFctMEhFUTg1TVctQmFfVUdxZXJ4TDl0azlYNA&amp;q=https%3A%2F%2Fwww.paypal.com%2Fcgi-bin%2Fwebscr%3Fcmd%3D_donations%26business%3Dderek%2540distrotube%252ecom%26lc%3DUS%26item_name%3DDistroTube%26no_note%3D0%26currency_code%3DUSD%26bn%3DPP%252dDonationsBF%253abtn_donateCC_LG%252egif%253aNonHostedGuest
🛍️ Amazon: https://amzn.to/2RotFFi
👕 Teespring: https://teespring.com/stores/distrotube

DONATE CRYPTO:
💰 Bitcoin: 1Mp6ebz5bNcjNFW7XWHVht36SkiLoxPKoX
🐶 Dogecoin: D5fpRD1JRoBFPDXSBocRTp8W9uKzfwLFAu
📕 LBC: bMfA2c3zmcLxPCpyPcrykLvMhZ7A5mQuhJ

DT ON THE WEB:
🕸️ Website: http://distrotube.com/
📁 GitLab: https://gitlab.com/dwt1  
🗨️ Mastodon: https://fosstodon.org/@distrotube
👫 Reddit: https://www.reddit.com/r/DistroTube/
📽️ LBRY/Odysee: https://odysee.com/@DistroTube:2

FREE AND OPEN SOURCE SOFTWARE THAT I USE:
🌐 Brave Browser - https://brave.com/dis872 
📽️ Open Broadcaster Software: https://obsproject.com/
🎬 Kdenlive: https://kdenlive.org
🎨 GIMP: https://www.gimp.org/
🎵 Tenacity: https://github.com/tenacityteam/tenacity
💻 VirtualBox: https://www.virtualbox.org/
🗒️ Doom Emacs: https://github.com/hlissner/doom-emacs

Your support is very much appreciated. Thanks, guys!

