# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## Today's AI boom will amplify social problems if we don't act now, says AI ethicist
 - [https://www.zdnet.com/article/todays-ai-boom-will-amplify-social-problems-if-we-dont-act-now-says-ai-ethicist/#ftag=RSSbaffb68](https://www.zdnet.com/article/todays-ai-boom-will-amplify-social-problems-if-we-dont-act-now-says-ai-ethicist/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-05-21 23:07:48+00:00

AI systems trained on internet data are in danger of reinforcing negative bias and causing societal harm. Salesforce's Kathy Baxter explains how to fix it.

## This $350 Lenovo Chromebook will change your mind about cheap laptops
 - [https://www.zdnet.com/article/this-350-lenovo-chromebook-will-change-your-mind-about-cheap-laptops/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-350-lenovo-chromebook-will-change-your-mind-about-cheap-laptops/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-05-21 11:30:00+00:00

Take everything you'd want in an everyday laptop and slap an affordable price tag on it. Lenovo somehow did just that.

## This $7 medical tool is a surprising must-have in my workshop
 - [https://www.zdnet.com/home-and-office/this-7-medical-tool-is-a-surprising-must-have-in-my-workshop/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/this-7-medical-tool-is-a-surprising-must-have-in-my-workshop/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-05-21 11:00:00+00:00

Don't get into trouble for destroying someone's favorite scissors (like I used to!). Keep these on hand instead.

