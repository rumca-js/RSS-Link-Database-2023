# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## USA: Transpłciowa kolarka sama stanęła na podium. "Nie mam pojęcia, dlaczego inni uciekli"
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/usa-transplciowa-kolarka-samotnie-stanela-na-podium-nie-mam-pojecia-dlaczego-uciekli/](https://www.polsatnews.pl/wiadomosc/2023-05-21/usa-transplciowa-kolarka-samotnie-stanela-na-podium-nie-mam-pojecia-dlaczego-uciekli/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 19:44:00+00:00

Lesley Mumford wygrała wyścig rowerowy z Kolorado do Utah. Transpłciowa kolarka stanęła jednak na podium sama, bo inne nagrodzone - zdaniem niektórych komentujących sprawę - zbojkotowały ceremonię wręczenia nagród. - Nie obchodzi mnie, że zwyciężczyni jest osobą transpłciową. Jakie to ma znaczenie? - powiedziała zdobywczyni drugiego miejsca.

## Zwlekała z wizytą u lekarza. Usłyszała: Od śmierci dzielą panią 24 godziny
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/zwlekala-z-wizyta-u-lekarza-uslyszala-od-smierci-dziela-pania-24-godziny/](https://www.polsatnews.pl/wiadomosc/2023-05-21/zwlekala-z-wizyta-u-lekarza-uslyszala-od-smierci-dziela-pania-24-godziny/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 19:02:00+00:00

Mieszkanka Wielkiej Brytanii tygodniami ignorowała nasilający się ból brzucha. Kiedy w końcu trafiła do szpitala, usłyszała druzgocącą diagnozę. Po operacji ratującej życie lekarz stwierdził, że od śmierci dzieliły ją zaledwie 24 godziny.

## Kraje G7 naciskają na Chiny w sprawie Rosji. "Wtrącanie w wewnętrzne sprawy"
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/kraje-g7-naciskaja-na-chiny-w-sprawie-rosji-wtracanie-w-wewnetrzne-sprawy/](https://www.polsatnews.pl/wiadomosc/2023-05-21/kraje-g7-naciskaja-na-chiny-w-sprawie-rosji-wtracanie-w-wewnetrzne-sprawy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 18:00:00+00:00

Kraje G7 we wspólnym oświadczeniu na szczycie w Hiroszimie wezwały Chiny do wywarcia presji na Rosję, by Moskwa bezzwłocznie wycofała wojska z Ukrainy. W dokumencie poruszono także kwestię Tajwanu. Komunikat wywołał stanowczą reakcję Pekinu. MSZ nazwał go wtrącaniem w wewnętrzne sprawy Chin.

## Wybory parlamentarne w Grecji. Spłynęły wyniki exit poll
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/wybory-parlamentarne-w-grecji-sondaze-nie-wskazuja-na-zmiane-wladzy/](https://www.polsatnews.pl/wiadomosc/2023-05-21/wybory-parlamentarne-w-grecji-sondaze-nie-wskazuja-na-zmiane-wladzy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 16:27:00+00:00

W Atenach trwa oczekiwanie na wyniki wyborów parlamentarnych. Sondaże exit poll nie wskazują na zmianę władzy w Grecji. Prowadzi konserwatywna partia Nowa Demokracja.

## Grecja. Zaginęła na wakacjach z mężem. Po kilku tygodniach ciało 74-latki odnaleziono na wyspie
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/grecja-zaginela-na-wakacjach-z-mezem-po-kilku-tygodniach-cialo-74-latki-odnaleziono-na-wyspie/](https://www.polsatnews.pl/wiadomosc/2023-05-21/grecja-zaginela-na-wakacjach-z-mezem-po-kilku-tygodniach-cialo-74-latki-odnaleziono-na-wyspie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 15:36:00+00:00

Brytyjska babcia wyjechała na wakacje ze swoim mężem. Krótko po tym zaginęła. Mimo intensywnych poszukiwań, policja miała odmówić dostępu do monitoringu. Po trzech tygodniach ciało kobiety znaleziono w odludnym miejscu na wyspie.

## Rosja chce nałożyć sankcje na Polskę. Żądanie zwrotu pieniędzy i ziem
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/rosja-chce-nalozyc-sankcje-na-polske-zadanie-zwrotu-pieniedzy-i-ziem/](https://www.polsatnews.pl/wiadomosc/2023-05-21/rosja-chce-nalozyc-sankcje-na-polske-zadanie-zwrotu-pieniedzy-i-ziem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 15:12:00+00:00

Przewodniczący rosyjskiej Dumy Państwowej domaga się od Polski 750 mld dolarów odszkodowania za wyzwolenie spod faszystowskiej okupacji. Wiaczesław Wołodin podkreślił, że sprawa wypłaty pieniędzy oraz zwrotu ziem przyznanych Polsce po II wojnie światowej zostanie rozważona na poniedziałkowym posiedzeniu Rady Dumy.

## Transpłciowa kobieta wyproszona z damskiej szatni. Pozywa firmę na pięć milionów dolarów
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/transplciowa-kobieta-wyproszona-z-damskiej-szatni-pozywa-firme-na-piec-milionow-dolarow/](https://www.polsatnews.pl/wiadomosc/2023-05-21/transplciowa-kobieta-wyproszona-z-damskiej-szatni-pozywa-firme-na-piec-milionow-dolarow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 11:47:00+00:00

Ali Miles urodziła się jako biologiczny mężczyzna, ale jest w trakcie terapii hormonalnej. Twierdzi, że w studiu jogi, gdzie uczęszcza na zajęcia, odmówiono jej korzystania z szatni i łazienek dla kobiet. Skierowała więc sprawę do sądu i żąda pięciu milionów dolarów. To trzeci pozew Miles o dyskryminację w ciągu roku.

## Floryda. W toalecie znalazł iguanę. "Agresywnie syczała"
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/floryda-w-toalecie-znalazl-iguane-agresywnie-syczala/](https://www.polsatnews.pl/wiadomosc/2023-05-21/floryda-w-toalecie-znalazl-iguane-agresywnie-syczala/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 11:03:00+00:00

Gdy wszedł do toalety, okazało się, że nie jest sam. - Znalazłem Godzillę w mojej łazience - mieszkaniec Hollywood powiedział w rozmowie z mediami i dodał: - Nie wyglądała na zadowoloną.

## Wołodymyr Zełenski na szczycie G7 w Japonii. Odniósł się do sytuacji w Bachmucie
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/wolodymyr-zelenski-na-szczycie-g7-potwierdzil-utrate-bachmutu/](https://www.polsatnews.pl/wiadomosc/2023-05-21/wolodymyr-zelenski-na-szczycie-g7-potwierdzil-utrate-bachmutu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 06:19:00+00:00

Prezydent Ukrainy Wołodymyr Zełenski na szczycie G7 w Hiroszimie został zapytany przez dziennikarzy, czy Bachmut wciąż jest kontrolowany przez Kijów. - Myślę, że nie. Ale na dziś Bachmut jest już tylko w naszych sercach - odpowiedział ukraiński przywódca.

## Salwador: Panika na stadionie w stolicy. Nie żyje co najmniej 12 osób
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/salwador-panika-na-stadionie-w-stolicy-nie-zyje-co-najmniej-12-osob/](https://www.polsatnews.pl/wiadomosc/2023-05-21/salwador-panika-na-stadionie-w-stolicy-nie-zyje-co-najmniej-12-osob/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 05:50:00+00:00

Na stadionie w stolicy Salwadoru wybuchła panika. Co najmniej 12 osób zostało stratowanych na śmierć. Kibice próbując dostać się na teren obiektu forsowali zamknięte bramy. Świadkowie tragedii relacjonowali, że na wejścia mogło napierać nawet kilka tysięcy osób.

## Wołodymyr Zełenski w Hiroszimie. Prezydent Ukrainy spotkał się z premierem Kanady
 - [https://www.polsatnews.pl/wiadomosc/2023-05-21/zelenski-w-hiroszimie-prezydent-ukrainy-spotkal-sie-z-premierem-kanady/](https://www.polsatnews.pl/wiadomosc/2023-05-21/zelenski-w-hiroszimie-prezydent-ukrainy-spotkal-sie-z-premierem-kanady/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-21 04:02:00+00:00

Na marginesie szczytu G7 w Hiroszimie Wołodymyr Zełenski rozmawiał z premierem Ukrainy Justinem Trudeau. Wcześniej spotkał się z premierem Wielkiej Brytanii Rishi Sunakiem oraz prezydentem Francji Emmanuelem Macronem. W niedzielę ma też dojść do rozmowy prezydenta Ukrainy z Joe Bidenem.

