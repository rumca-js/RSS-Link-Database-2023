# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Apple łata ~40 podatności w iPhone, w tym luki wykorzystywane aktywnie w realnych atakach
 - [https://sekurak.pl/apple-lata-40-podatnosci-w-iphone-w-tym-luki-wykorzystywane-aktywnie-w-realnych-atakach/](https://sekurak.pl/apple-lata-40-podatnosci-w-iphone-w-tym-luki-wykorzystywane-aktywnie-w-realnych-atakach/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-05-21 10:02:27+00:00

<p>Szczegóły dostępne są w opisie elementów bezpieczeństwa, które zostały naprawione w iOS 16.5. Mamy tutaj takie niespodzianki jak: Impact: Processing an image may lead to arbitrary code execution czy sporo podatności polegających na możliwości podniesienia uprawnień do uprawnień Kernela (czyli praktycznie najwyższe uprawnienia). W szczególności załatane są trzy podatności wykorzystywane...</p>
<p>Artykuł <a href="https://sekurak.pl/apple-lata-40-podatnosci-w-iphone-w-tym-luki-wykorzystywane-aktywnie-w-realnych-atakach/" rel="nofollow">Apple łata ~40 podatności w iPhone, w tym luki wykorzystywane aktywnie w realnych atakach</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

