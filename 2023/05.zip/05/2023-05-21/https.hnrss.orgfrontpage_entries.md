# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## China is calling in loans to dozens of countries from Pakistan to Kenya
 - [https://fortune.com/2023/05/18/china-belt-road-loans-pakistan-sri-lanka-africa-collapse-economic-instability/](https://fortune.com/2023/05/18/china-belt-road-loans-pakistan-sri-lanka-africa-collapse-economic-instability/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 22:38:23+00:00

<p>Article URL: <a href="https://fortune.com/2023/05/18/china-belt-road-loans-pakistan-sri-lanka-africa-collapse-economic-instability/">https://fortune.com/2023/05/18/china-belt-road-loans-pakistan-sri-lanka-africa-collapse-economic-instability/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36025288">https://news.ycombinator.com/item?id=36025288</a></p>
<p>Points: 21</p>
<p># Comments: 0</p>

## Ask HN: What's your favorite software testing framework and why?
 - [https://news.ycombinator.com/item?id=36025278](https://news.ycombinator.com/item?id=36025278)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 22:36:58+00:00

<p>Seeing so many different testing frameworks in every programming language. Would love to understand how this happened, when they all seemingly do the same thing. Would love to know which is your favorite and what makes it different than whatever else popular framework in your language?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36025278">https://news.ycombinator.com/item?id=36025278</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## LLVM's Libc Gets Much Faster memcpy For RISC-V
 - [https://www.phoronix.com/news/LLVM-libc-Faster-memcpy](https://www.phoronix.com/news/LLVM-libc-Faster-memcpy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 22:26:05+00:00

<p>Article URL: <a href="https://www.phoronix.com/news/LLVM-libc-Faster-memcpy">https://www.phoronix.com/news/LLVM-libc-Faster-memcpy</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36025209">https://news.ycombinator.com/item?id=36025209</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Cloud GPU Resources and Pricing
 - [https://fullstackdeeplearning.com/cloud-gpus/](https://fullstackdeeplearning.com/cloud-gpus/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 22:08:35+00:00

<p>Article URL: <a href="https://fullstackdeeplearning.com/cloud-gpus/">https://fullstackdeeplearning.com/cloud-gpus/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36025099">https://news.ycombinator.com/item?id=36025099</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Noise is all around us
 - [https://thewalrus.ca/noise-ethics/](https://thewalrus.ca/noise-ethics/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 21:33:05+00:00

<p>Article URL: <a href="https://thewalrus.ca/noise-ethics/">https://thewalrus.ca/noise-ethics/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36024887">https://news.ycombinator.com/item?id=36024887</a></p>
<p>Points: 56</p>
<p># Comments: 24</p>

## An Example of a Sad Google Account Recovery Failure and Its Effects
 - [https://lauren.vortex.com/2023/05/17/google-account-recovery-failure-sad](https://lauren.vortex.com/2023/05/17/google-account-recovery-failure-sad)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 21:13:31+00:00

<p>Article URL: <a href="https://lauren.vortex.com/2023/05/17/google-account-recovery-failure-sad">https://lauren.vortex.com/2023/05/17/google-account-recovery-failure-sad</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36024754">https://news.ycombinator.com/item?id=36024754</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## The $40M bet that made South Korea a food and cultural power
 - [https://blog.hubspot.com/the-hustle/the-40m-bet-that-made-south-korea-a-food-and-cultural-power](https://blog.hubspot.com/the-hustle/the-40m-bet-that-made-south-korea-a-food-and-cultural-power)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 20:32:36+00:00

<p>Article URL: <a href="https://blog.hubspot.com/the-hustle/the-40m-bet-that-made-south-korea-a-food-and-cultural-power">https://blog.hubspot.com/the-hustle/the-40m-bet-that-made-south-korea-a-food-and-cultural-power</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36024445">https://news.ycombinator.com/item?id=36024445</a></p>
<p>Points: 21</p>
<p># Comments: 0</p>

## How Much Memory Do You Need to Run 1M Concurrent Tasks?
 - [https://pkolaczk.github.io/memory-consumption-of-async/](https://pkolaczk.github.io/memory-consumption-of-async/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 19:58:24+00:00

<p>Article URL: <a href="https://pkolaczk.github.io/memory-consumption-of-async/">https://pkolaczk.github.io/memory-consumption-of-async/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36024209">https://news.ycombinator.com/item?id=36024209</a></p>
<p>Points: 20</p>
<p># Comments: 9</p>

## No Screens Cafe
 - [https://cmart.blog/no-screens-cafe/](https://cmart.blog/no-screens-cafe/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 18:56:47+00:00

<p>Article URL: <a href="https://cmart.blog/no-screens-cafe/">https://cmart.blog/no-screens-cafe/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36023745">https://news.ycombinator.com/item?id=36023745</a></p>
<p>Points: 27</p>
<p># Comments: 5</p>

## Tell HN: Be aware of people trying to scam contractors
 - [https://news.ycombinator.com/item?id=36023656](https://news.ycombinator.com/item?id=36023656)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 18:44:02+00:00

<p>In short, I just received a nice proposal to work on a new contract, the potential customer sent me a "document" with the project specs which turned out to be a password-protected compressed file with some pictures and a ".exe" file inside.<p>I submitted the executable to virustotal which reports this as a trojan (https://www.virustotal.com/gui/file/088e2dabf218024d30e6899152b6a031dc30ae6f7d516492cb797292d6255d27/detection), seems like this takes screenshots and steals browser data which can be used for other purposes later.<p>Anyway, be cautious with proposals you receive.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36023656">https://news.ycombinator.com/item?id=36023656</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Optery (YC W22) Hiring in Sales, Marketing, Customer Success, Business Ops
 - [https://www.ycombinator.com/companies/optery/jobs](https://www.ycombinator.com/companies/optery/jobs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 17:58:08+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/optery/jobs">https://www.ycombinator.com/companies/optery/jobs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36023266">https://news.ycombinator.com/item?id=36023266</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## AI boom could expose investors’ natural stupidity
 - [https://www.reuters.com/breakingviews/ai-boom-could-expose-investors-natural-stupidity-2023-05-19/](https://www.reuters.com/breakingviews/ai-boom-could-expose-investors-natural-stupidity-2023-05-19/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 16:58:56+00:00

<p>Article URL: <a href="https://www.reuters.com/breakingviews/ai-boom-could-expose-investors-natural-stupidity-2023-05-19/">https://www.reuters.com/breakingviews/ai-boom-could-expose-investors-natural-stupidity-2023-05-19/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36022768">https://news.ycombinator.com/item?id=36022768</a></p>
<p>Points: 22</p>
<p># Comments: 12</p>

## Recreating RP2040 PIO Interface in an FPGA
 - [https://github.com/lawrie/fpga_pio](https://github.com/lawrie/fpga_pio)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 16:51:22+00:00

<p>Article URL: <a href="https://github.com/lawrie/fpga_pio">https://github.com/lawrie/fpga_pio</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36022695">https://news.ycombinator.com/item?id=36022695</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Neural Network Architecture Beyond Width and Depth
 - [https://arxiv.org/abs/2205.09459](https://arxiv.org/abs/2205.09459)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 16:22:34+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2205.09459">https://arxiv.org/abs/2205.09459</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36022460">https://news.ycombinator.com/item?id=36022460</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>

## High-Performance Graph Databases, Scaling to Hundreds of Thousands of Cores
 - [https://arxiv.org/abs/2305.11162](https://arxiv.org/abs/2305.11162)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 15:39:48+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2305.11162">https://arxiv.org/abs/2305.11162</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36022042">https://news.ycombinator.com/item?id=36022042</a></p>
<p>Points: 24</p>
<p># Comments: 1</p>

## Plain Text Accounting
 - [https://plaintextaccounting.org/](https://plaintextaccounting.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 15:35:52+00:00

<p>Article URL: <a href="https://plaintextaccounting.org/">https://plaintextaccounting.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36022005">https://news.ycombinator.com/item?id=36022005</a></p>
<p>Points: 43</p>
<p># Comments: 15</p>

## US is expanding CO2 pipelines. One poisoned town wants you to know its story
 - [https://text.npr.org/1172679786](https://text.npr.org/1172679786)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 14:51:27+00:00

<p>Article URL: <a href="https://text.npr.org/1172679786">https://text.npr.org/1172679786</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36021530">https://news.ycombinator.com/item?id=36021530</a></p>
<p>Points: 47</p>
<p># Comments: 20</p>

## The Drakon Language
 - [https://drakonhub.com/en/drakon](https://drakonhub.com/en/drakon)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 14:49:12+00:00

<p>Article URL: <a href="https://drakonhub.com/en/drakon">https://drakonhub.com/en/drakon</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36021495">https://news.ycombinator.com/item?id=36021495</a></p>
<p>Points: 17</p>
<p># Comments: 7</p>

## The End of the Accounting Search
 - [https://lwn.net/Articles/925782/](https://lwn.net/Articles/925782/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 14:26:44+00:00

<p>Article URL: <a href="https://lwn.net/Articles/925782/">https://lwn.net/Articles/925782/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36021197">https://news.ycombinator.com/item?id=36021197</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## PGP signatures on PyPI: worse than useless
 - [https://blog.yossarian.net/2023/05/21/PGP-signatures-on-PyPI-worse-than-useless](https://blog.yossarian.net/2023/05/21/PGP-signatures-on-PyPI-worse-than-useless)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 14:25:25+00:00

<p>Article URL: <a href="https://blog.yossarian.net/2023/05/21/PGP-signatures-on-PyPI-worse-than-useless">https://blog.yossarian.net/2023/05/21/PGP-signatures-on-PyPI-worse-than-useless</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36021172">https://news.ycombinator.com/item?id=36021172</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Paris’s Centre Pompidou to Close for Five Years Starting in 2025
 - [https://www.artnews.com/art-news/news/centre-pompidou-closing-five-years-2025-1234667508/](https://www.artnews.com/art-news/news/centre-pompidou-closing-five-years-2025-1234667508/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 13:47:56+00:00

<p>Article URL: <a href="https://www.artnews.com/art-news/news/centre-pompidou-closing-five-years-2025-1234667508/">https://www.artnews.com/art-news/news/centre-pompidou-closing-five-years-2025-1234667508/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36020811">https://news.ycombinator.com/item?id=36020811</a></p>
<p>Points: 41</p>
<p># Comments: 26</p>

## Show HN: Trogon – An automatic TUI for command line apps
 - [https://github.com/Textualize/trogon](https://github.com/Textualize/trogon)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 13:36:44+00:00

<p>Hi HN,<p>Trogon is a project to generate a TUI for command line apps.<p>It presents the arguments, options, and switches as a form. Editing the form generates a command line, which you can then run with a keypress.<p>I'm a lover of the command line. But I can recall only a fraction of the switches for most commands I use. I would love it if there was a TUI available for most commands.<p>Trogon currently works with Python and the Click library, but I would like it to cover more of the Python ecosystem and also generate TUIs for apps not written in Python.<p>More information in the repository.<p>Let me know what you think...</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36020717">https://news.ycombinator.com/item?id=36020717</a></p>
<p>Points: 23</p>
<p># Comments: 1</p>

## Study finds 90% of Australian teachers can't afford to live where they teach
 - [https://phys.org/news/2023-05-australian-teachers.html](https://phys.org/news/2023-05-australian-teachers.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 13:01:44+00:00

<p>Article URL: <a href="https://phys.org/news/2023-05-australian-teachers.html">https://phys.org/news/2023-05-australian-teachers.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36020473">https://news.ycombinator.com/item?id=36020473</a></p>
<p>Points: 68</p>
<p># Comments: 87</p>

## The Bill of Materials for the Apple Headset Leaked Online
 - [https://twitter.com/cixliv/status/1660038281034350592](https://twitter.com/cixliv/status/1660038281034350592)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 12:57:27+00:00

<p>Article URL: <a href="https://twitter.com/cixliv/status/1660038281034350592">https://twitter.com/cixliv/status/1660038281034350592</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36020437">https://news.ycombinator.com/item?id=36020437</a></p>
<p>Points: 44</p>
<p># Comments: 17</p>

## Potentially millions of Android TVs and phones come with malware preinstalled
 - [https://arstechnica.com/information-technology/2023/05/potentially-millions-of-android-tvs-and-phones-come-with-malware-preinstalled/](https://arstechnica.com/information-technology/2023/05/potentially-millions-of-android-tvs-and-phones-come-with-malware-preinstalled/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 12:56:52+00:00

<p>Article URL: <a href="https://arstechnica.com/information-technology/2023/05/potentially-millions-of-android-tvs-and-phones-come-with-malware-preinstalled/">https://arstechnica.com/information-technology/2023/05/potentially-millions-of-android-tvs-and-phones-come-with-malware-preinstalled/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36020431">https://news.ycombinator.com/item?id=36020431</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Suspicious iOS KeePass Client
 - [https://old.reddit.com/r/techsupport/comments/13nqarb/suspicious_ios_keepass_client/](https://old.reddit.com/r/techsupport/comments/13nqarb/suspicious_ios_keepass_client/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 12:27:22+00:00

<p>Article URL: <a href="https://old.reddit.com/r/techsupport/comments/13nqarb/suspicious_ios_keepass_client/">https://old.reddit.com/r/techsupport/comments/13nqarb/suspicious_ios_keepass_client/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36020196">https://news.ycombinator.com/item?id=36020196</a></p>
<p>Points: 50</p>
<p># Comments: 3</p>

## Emerge Tools is building the future of mobile tooling, come join us
 - [https://www.ycombinator.com/companies/emerge-tools/jobs/S8b1ojf-senior-software-engineer-remote](https://www.ycombinator.com/companies/emerge-tools/jobs/S8b1ojf-senior-software-engineer-remote)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 12:01:14+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/emerge-tools/jobs/S8b1ojf-senior-software-engineer-remote">https://www.ycombinator.com/companies/emerge-tools/jobs/S8b1ojf-senior-software-engineer-remote</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36020029">https://news.ycombinator.com/item?id=36020029</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Ask HN: I have 176 logins/accounts. How many do you have?
 - [https://news.ycombinator.com/item?id=36020008](https://news.ycombinator.com/item?id=36020008)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 11:57:50+00:00

<p>Here is a screenshot of my Bitwarden: https://imgur.com/a/UdG7Inb<p>They include some really important things such as:<p>Health insurance
G-Suite for work
Bill.com (which I use to get paid)
IRS.gov (which I use to get un-paid)
UK Companies House Register
Interactive Brokers
My bank<p>Obviously, anything with OAuth is "bundled" into my Google account. So if anything this is a huge underestimate.<p>I'm asking because of how insane auth has become. I know companies like OnePassword and Bitwarden are working on this and overall they do a great job. But I still have a near-stroke every time I have to do the "forgot my password" loop, or use Duo Mobile/other 2FA.<p>The only really good auth feature I've ever encountered has been Apple's "fill from Messages" feature as well as their Touch.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36020008">https://news.ycombinator.com/item?id=36020008</a></p>
<p>Points: 29</p>
<p># Comments: 41</p>

## Show HN: SpaceBadgers – Free and Libre SVG Badges
 - [https://badgers.space](https://badgers.space)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 11:54:34+00:00

<p>Greetings, Hacker News community!<p>I am thrilled to present SpaceBadgers, a new free and open-source SVG badge generator I've been working on. It's located at badgers.space.<p>SpaceBadgers is born out of the desire to offer more flexibility and customization for project badges, often used in open-source projects.<p>It's fully open source, provided under the permissive MIT license, and will always be provided for free. The core badge worker is written in Rust, and so is the library behind it, which you can also find on crates.io under the name spacebadgers.<p>I am excited to receive your feedback and suggestions. Check it out and let me know what you think in the comments. Contributions are also welcomed and appreciated. You can find the source code here: <a href="https://github.com/splittydev/spacebadgers">https://github.com/splittydev/spacebadgers</a>.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36020001">https://news.ycombinator.com/item?id=36020001</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## Arch Linux: Git migration completed
 - [https://archlinux.org/news/git-migration-completed/](https://archlinux.org/news/git-migration-completed/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 11:32:34+00:00

<p>Article URL: <a href="https://archlinux.org/news/git-migration-completed/">https://archlinux.org/news/git-migration-completed/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019870">https://news.ycombinator.com/item?id=36019870</a></p>
<p>Points: 30</p>
<p># Comments: 0</p>

## Show HN: A simple echo server for testing HTTP clients
 - [https://echoserver.dev/](https://echoserver.dev/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 10:56:53+00:00

<p>I have developed an application called "echoserver" and I would like to share its details on Hacker News. The purpose of "echoserver" is to simplify the testing of HTTP clients. It functions as an echo server, meaning it responds to requests by echoing back the received data. This allows users to simulate various server responses and test their HTTP clients accordingly.<p>With "echoserver," users can generate custom responses by specifying the desired status code, headers, and response body. This flexibility enables thorough testing of HTTP clients and simplifies the process of verifying client behavior under various scenarios. Whether it's testing error handling, handling specific headers, or evaluating performance under different response sizes, "echoserver" provides a convenient solution.<p>Overall, "echoserver" aims to streamline the testing process for developers and enhance their ability to verify the functionality and robustness of their HTTP clients. Its simplicity, versatility, and user-friendly interface make it an invaluable tool in the development and testing workflow. I invite the Hacker News community to explore and provide feedback on the app, as I believe it has the potential to greatly benefit developers and testers worldwide.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019664">https://news.ycombinator.com/item?id=36019664</a></p>
<p>Points: 12</p>
<p># Comments: 4</p>

## GPT detectors are biased against non-native English writers
 - [https://arxiv.org/abs/2304.02819](https://arxiv.org/abs/2304.02819)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 10:36:11+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2304.02819">https://arxiv.org/abs/2304.02819</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019580">https://news.ycombinator.com/item?id=36019580</a></p>
<p>Points: 59</p>
<p># Comments: 24</p>

## GitHub – GEIGEIGEIST/KLOR: a 36-42 key column-staggered split keyboard
 - [https://github.com/GEIGEIGEIST/KLOR](https://github.com/GEIGEIGEIST/KLOR)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 10:25:15+00:00

<p>Article URL: <a href="https://github.com/GEIGEIGEIST/KLOR">https://github.com/GEIGEIGEIST/KLOR</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019535">https://news.ycombinator.com/item?id=36019535</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## HP rushes to fix bricked printers after faulty firmware update
 - [https://www.bleepingcomputer.com/news/technology/hp-rushes-to-fix-bricked-printers-after-faulty-firmware-update/](https://www.bleepingcomputer.com/news/technology/hp-rushes-to-fix-bricked-printers-after-faulty-firmware-update/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 10:17:17+00:00

<p>Article URL: <a href="https://www.bleepingcomputer.com/news/technology/hp-rushes-to-fix-bricked-printers-after-faulty-firmware-update/">https://www.bleepingcomputer.com/news/technology/hp-rushes-to-fix-bricked-printers-after-faulty-firmware-update/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019492">https://news.ycombinator.com/item?id=36019492</a></p>
<p>Points: 32</p>
<p># Comments: 14</p>

## Dolphin Emulator: Progress Report February, March, and April 2023
 - [https://dolphin-emu.org/blog/2023/05/21/dolphin-progress-report-february-march-april-2023/](https://dolphin-emu.org/blog/2023/05/21/dolphin-progress-report-february-march-april-2023/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 10:16:38+00:00

<p>Article URL: <a href="https://dolphin-emu.org/blog/2023/05/21/dolphin-progress-report-february-march-april-2023/">https://dolphin-emu.org/blog/2023/05/21/dolphin-progress-report-february-march-april-2023/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019485">https://news.ycombinator.com/item?id=36019485</a></p>
<p>Points: 20</p>
<p># Comments: 0</p>

## Ask HN: Are App Store anti-steering rules dead now?
 - [https://news.ycombinator.com/item?id=36019391](https://news.ycombinator.com/item?id=36019391)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 09:59:03+00:00

<p>After Epic vs Apple's ruling in the U.S. and EU's recent statement of objections ( https://ec.europa.eu/commission/presscorner/detail/en/ip_23_1217 ), does that mean we can simply use external payment methods for in-app purchases? Has anyone tried submitting an app with alternative payment methods?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019391">https://news.ycombinator.com/item?id=36019391</a></p>
<p>Points: 14</p>
<p># Comments: 2</p>

## Experimenting with graph databases with Memgraph and Elixir
 - [https://0x7f.dev/post/elixir_memgraph/](https://0x7f.dev/post/elixir_memgraph/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 09:48:47+00:00

<p>Article URL: <a href="https://0x7f.dev/post/elixir_memgraph/">https://0x7f.dev/post/elixir_memgraph/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019336">https://news.ycombinator.com/item?id=36019336</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## The Absurdity Of Stacks
 - [https://www.tfeb.org/fragments/2023/03/25/the-absurdity-of-stacks/](https://www.tfeb.org/fragments/2023/03/25/the-absurdity-of-stacks/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 09:40:24+00:00

<p>Article URL: <a href="https://www.tfeb.org/fragments/2023/03/25/the-absurdity-of-stacks/">https://www.tfeb.org/fragments/2023/03/25/the-absurdity-of-stacks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019293">https://news.ycombinator.com/item?id=36019293</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Building a Handheld PC
 - [https://bytewelder.com/posts/2023/05/20/building-a-handheld-pc.html](https://bytewelder.com/posts/2023/05/20/building-a-handheld-pc.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 09:25:34+00:00

<p>Article URL: <a href="https://bytewelder.com/posts/2023/05/20/building-a-handheld-pc.html">https://bytewelder.com/posts/2023/05/20/building-a-handheld-pc.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019208">https://news.ycombinator.com/item?id=36019208</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## How AI coding companions will change the way developers work
 - [https://www.allthingsdistributed.com/2023/04/how-ai-coding-companions-will-change-the-way-developers-work.html](https://www.allthingsdistributed.com/2023/04/how-ai-coding-companions-will-change-the-way-developers-work.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 09:02:57+00:00

<p>Article URL: <a href="https://www.allthingsdistributed.com/2023/04/how-ai-coding-companions-will-change-the-way-developers-work.html">https://www.allthingsdistributed.com/2023/04/how-ai-coding-companions-will-change-the-way-developers-work.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019109">https://news.ycombinator.com/item?id=36019109</a></p>
<p>Points: 5</p>
<p># Comments: 2</p>

## Reasons Not to Become Famous
 - [https://tim.blog/2020/02/02/reasons-to-not-become-famous/](https://tim.blog/2020/02/02/reasons-to-not-become-famous/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 08:47:10+00:00

<p>Article URL: <a href="https://tim.blog/2020/02/02/reasons-to-not-become-famous/">https://tim.blog/2020/02/02/reasons-to-not-become-famous/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019038">https://news.ycombinator.com/item?id=36019038</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## r9: Plan 9 in Rust
 - [https://github.com/r9os/r9](https://github.com/r9os/r9)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 08:45:31+00:00

<p>Article URL: <a href="https://github.com/r9os/r9">https://github.com/r9os/r9</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019030">https://news.ycombinator.com/item?id=36019030</a></p>
<p>Points: 17</p>
<p># Comments: 0</p>

## Typical: Data interchange with algebraic data types
 - [https://github.com/stepchowfun/typical](https://github.com/stepchowfun/typical)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 08:41:11+00:00

<p>Article URL: <a href="https://github.com/stepchowfun/typical">https://github.com/stepchowfun/typical</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36019005">https://news.ycombinator.com/item?id=36019005</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## ПП-BESM – a Soviet language (1955)
 - [http://xav.io/posts/besm/](http://xav.io/posts/besm/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 08:29:23+00:00

<p>Article URL: <a href="http://xav.io/posts/besm/">http://xav.io/posts/besm/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018949">https://news.ycombinator.com/item?id=36018949</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## TOML: Tom's Obvious Minimal Language
 - [https://toml.io/en/](https://toml.io/en/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 07:56:22+00:00

<p>Article URL: <a href="https://toml.io/en/">https://toml.io/en/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018817">https://news.ycombinator.com/item?id=36018817</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Notes on the Cost of Go Finalizers
 - [https://utcc.utoronto.ca/~cks/space/blog/programming/GoFinalizerCostsNotes](https://utcc.utoronto.ca/~cks/space/blog/programming/GoFinalizerCostsNotes)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 07:49:03+00:00

<p>Article URL: <a href="https://utcc.utoronto.ca/~cks/space/blog/programming/GoFinalizerCostsNotes">https://utcc.utoronto.ca/~cks/space/blog/programming/GoFinalizerCostsNotes</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018794">https://news.ycombinator.com/item?id=36018794</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Cultured meat might not be that environmentap friendly
 - [https://www.biorxiv.org/content/10.1101/2023.04.21.537778v1](https://www.biorxiv.org/content/10.1101/2023.04.21.537778v1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 07:35:38+00:00

<p>Article URL: <a href="https://www.biorxiv.org/content/10.1101/2023.04.21.537778v1">https://www.biorxiv.org/content/10.1101/2023.04.21.537778v1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018747">https://news.ycombinator.com/item?id=36018747</a></p>
<p>Points: 9</p>
<p># Comments: 13</p>

## DarkBERT: A Language Model for the Dark Side of the Internet
 - [https://arxiv.org/abs/2305.08596](https://arxiv.org/abs/2305.08596)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 07:11:42+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2305.08596">https://arxiv.org/abs/2305.08596</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018657">https://news.ycombinator.com/item?id=36018657</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Writing Python like it's Rust
 - [https://kobzol.github.io/rust/python/2023/05/20/writing-python-like-its-rust.html](https://kobzol.github.io/rust/python/2023/05/20/writing-python-like-its-rust.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 06:59:59+00:00

<p>Article URL: <a href="https://kobzol.github.io/rust/python/2023/05/20/writing-python-like-its-rust.html">https://kobzol.github.io/rust/python/2023/05/20/writing-python-like-its-rust.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018621">https://news.ycombinator.com/item?id=36018621</a></p>
<p>Points: 10</p>
<p># Comments: 3</p>

## Best Linux Books for Different Target Groups and Use Cases
 - [https://linuxstans.com/linux-books/](https://linuxstans.com/linux-books/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 06:28:19+00:00

<p>Article URL: <a href="https://linuxstans.com/linux-books/">https://linuxstans.com/linux-books/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018512">https://news.ycombinator.com/item?id=36018512</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## The AI revolution already transforming education
 - [https://www.ft.com/content/47fd20c6-240d-4ffa-a0de-70717712ed1c](https://www.ft.com/content/47fd20c6-240d-4ffa-a0de-70717712ed1c)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 05:55:34+00:00

<p>Article URL: <a href="https://www.ft.com/content/47fd20c6-240d-4ffa-a0de-70717712ed1c">https://www.ft.com/content/47fd20c6-240d-4ffa-a0de-70717712ed1c</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018386">https://news.ycombinator.com/item?id=36018386</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Tarteel – AI-powered Quran companion
 - [https://www.tarteel.ai/](https://www.tarteel.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 05:42:42+00:00

<p>Article URL: <a href="https://www.tarteel.ai/">https://www.tarteel.ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018332">https://news.ycombinator.com/item?id=36018332</a></p>
<p>Points: 14</p>
<p># Comments: 0</p>

## Get a Horse America’s Skepticism Toward the First Automobiles
 - [https://www.saturdayeveningpost.com/2017/01/get-horse-americas-skepticism-toward-first-automobiles/](https://www.saturdayeveningpost.com/2017/01/get-horse-americas-skepticism-toward-first-automobiles/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 05:28:43+00:00

<p>Article URL: <a href="https://www.saturdayeveningpost.com/2017/01/get-horse-americas-skepticism-toward-first-automobiles/">https://www.saturdayeveningpost.com/2017/01/get-horse-americas-skepticism-toward-first-automobiles/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018272">https://news.ycombinator.com/item?id=36018272</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Dragonfly – The most performant in-memory data store on Earth
 - [https://www.dragonflydb.io/?gclid=CjwKCAjw36GjBhAkEiwAKwIWyR8z6AbdHnG7gNsdqQpndmNTkck5av2CU0WDVVMJQjwEAjd9NK7hnhoCqGkQAvD_BwE](https://www.dragonflydb.io/?gclid=CjwKCAjw36GjBhAkEiwAKwIWyR8z6AbdHnG7gNsdqQpndmNTkck5av2CU0WDVVMJQjwEAjd9NK7hnhoCqGkQAvD_BwE)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 05:17:19+00:00

<p>Article URL: <a href="https://www.dragonflydb.io/?gclid=CjwKCAjw36GjBhAkEiwAKwIWyR8z6AbdHnG7gNsdqQpndmNTkck5av2CU0WDVVMJQjwEAjd9NK7hnhoCqGkQAvD_BwE">https://www.dragonflydb.io/?gclid=CjwKCAjw36GjBhAkEiwAKwIWyR8z6AbdHnG7gNsdqQpndmNTkck5av2CU0WDVVMJQjwEAjd9NK7hnhoCqGkQAvD_BwE</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018221">https://news.ycombinator.com/item?id=36018221</a></p>
<p>Points: 8</p>
<p># Comments: 6</p>

## KeyDB – multi-threaded Redis fork by Snapchat
 - [https://docs.keydb.dev/](https://docs.keydb.dev/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 05:00:41+00:00

<p>Article URL: <a href="https://docs.keydb.dev/">https://docs.keydb.dev/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018149">https://news.ycombinator.com/item?id=36018149</a></p>
<p>Points: 31</p>
<p># Comments: 3</p>

## The Raygun Conspiracy
 - [https://www.youtube.com/watch?v=zTZAQSEcPGc](https://www.youtube.com/watch?v=zTZAQSEcPGc)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 04:47:41+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=zTZAQSEcPGc">https://www.youtube.com/watch?v=zTZAQSEcPGc</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36018107">https://news.ycombinator.com/item?id=36018107</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## The Bitter Lesson – Rich Sutton (2019)
 - [http://incompleteideas.net/IncIdeas/BitterLesson.html?dup](http://incompleteideas.net/IncIdeas/BitterLesson.html?dup)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 03:49:50+00:00

<p>Article URL: <a href="http://incompleteideas.net/IncIdeas/BitterLesson.html?dup">http://incompleteideas.net/IncIdeas/BitterLesson.html?dup</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36017857">https://news.ycombinator.com/item?id=36017857</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Feynman Lectures on Physics now online
 - [https://www.feynmanlectures.caltech.edu/](https://www.feynmanlectures.caltech.edu/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 03:34:04+00:00

<p>Article URL: <a href="https://www.feynmanlectures.caltech.edu/">https://www.feynmanlectures.caltech.edu/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36017793">https://news.ycombinator.com/item?id=36017793</a></p>
<p>Points: 30</p>
<p># Comments: 4</p>

## Moonrabbit Collection
 - [https://ldjam.com/events/ludum-dare/53/moonrabbit-collection](https://ldjam.com/events/ludum-dare/53/moonrabbit-collection)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 03:28:58+00:00

<p>Article URL: <a href="https://ldjam.com/events/ludum-dare/53/moonrabbit-collection">https://ldjam.com/events/ludum-dare/53/moonrabbit-collection</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36017775">https://news.ycombinator.com/item?id=36017775</a></p>
<p>Points: 27</p>
<p># Comments: 5</p>

## Thought as a System (David Bohm, 1990) [pdf]
 - [https://ia601808.us.archive.org/16/items/david-bohm-thought-as-a-system/David%20Bohm%20-%20Thought%20as%20a%20System.pdf](https://ia601808.us.archive.org/16/items/david-bohm-thought-as-a-system/David%20Bohm%20-%20Thought%20as%20a%20System.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 02:38:58+00:00

<p>Article URL: <a href="https://ia601808.us.archive.org/16/items/david-bohm-thought-as-a-system/David%20Bohm%20-%20Thought%20as%20a%20System.pdf">https://ia601808.us.archive.org/16/items/david-bohm-thought-as-a-system/David%20Bohm%20-%20Thought%20as%20a%20System.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36017538">https://news.ycombinator.com/item?id=36017538</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Just Calm Down About GPT-4 Already
 - [https://spectrum.ieee.org/gpt-4-calm-down](https://spectrum.ieee.org/gpt-4-calm-down)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 01:54:50+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/gpt-4-calm-down">https://spectrum.ieee.org/gpt-4-calm-down</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36017309">https://news.ycombinator.com/item?id=36017309</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## The Problem with Consensus
 - [http://scienceunicorn.blogspot.com/2015/02/the-problem-with-consensus.html](http://scienceunicorn.blogspot.com/2015/02/the-problem-with-consensus.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 01:47:11+00:00

<p>Article URL: <a href="http://scienceunicorn.blogspot.com/2015/02/the-problem-with-consensus.html">http://scienceunicorn.blogspot.com/2015/02/the-problem-with-consensus.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36017274">https://news.ycombinator.com/item?id=36017274</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## Nonprofits are sapping the progressive project
 - [https://www.noahpinion.blog/p/nonprofits-are-sapping-the-progressive](https://www.noahpinion.blog/p/nonprofits-are-sapping-the-progressive)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 01:16:56+00:00

<p>Article URL: <a href="https://www.noahpinion.blog/p/nonprofits-are-sapping-the-progressive">https://www.noahpinion.blog/p/nonprofits-are-sapping-the-progressive</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36017115">https://news.ycombinator.com/item?id=36017115</a></p>
<p>Points: 19</p>
<p># Comments: 3</p>

## How Do Semiconductors Work? Introduction to SiliWiz
 - [https://tinytapeout.com/siliwiz/introduction/](https://tinytapeout.com/siliwiz/introduction/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-21 00:49:29+00:00

<p>Article URL: <a href="https://tinytapeout.com/siliwiz/introduction/">https://tinytapeout.com/siliwiz/introduction/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36016982">https://news.ycombinator.com/item?id=36016982</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

