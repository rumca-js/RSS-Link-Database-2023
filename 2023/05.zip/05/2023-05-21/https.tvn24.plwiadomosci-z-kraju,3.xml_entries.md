# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Spłonął prawie dwa tysiące razy większy obszar niż w tym samym okresie ubiegłego roku
 - [https://tvn24.pl/tvnmeteo/swiat/kanada-pozary-w-albercie-splonal-prawie-dwa-tysiace-razy-wiekszy-obszar-niz-w-tym-samym-okresie-ubieglego-roku-7137425?source=rss](https://tvn24.pl/tvnmeteo/swiat/kanada-pozary-w-albercie-splonal-prawie-dwa-tysiace-razy-wiekszy-obszar-niz-w-tym-samym-okresie-ubieglego-roku-7137425?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 20:16:31+00:00

<img alt="Spłonął prawie dwa tysiące razy większy obszar niż w tym samym okresie ubiegłego roku" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-orp3ig-pozary-lasow-w-prowincji-alberta-7137434/alternates/LANDSCAPE_1280" />
    Kanadyjska prowincja Alberta doświadcza bezprecedensowego sezonu pożarowego. W sobotę strażacy gasili ponad 90 aktywnych pożarów lasów. Od początku roku spłonęło ponad 840 tysięcy hektarów, w tym samym okresie tamtego roku było to niecałe 460 ha. Służby liczą, że niższa temperatura i opady deszczu prognozowane na najbliższe dni pomogą w walce z żywiołem.

## Śmierć 8-letniego Kamila. Procedura Serious Case Review może pomóc zapobiec takim tragediom
 - [https://fakty.tvn24.pl/zobacz-fakty/smierc-kamila-procedura-serious-case-review-moglaby-pomoc-zapobiec-tragediom-w-przyszlosci-7137379?source=rss](https://fakty.tvn24.pl/zobacz-fakty/smierc-kamila-procedura-serious-case-review-moglaby-pomoc-zapobiec-tragediom-w-przyszlosci-7137379?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 18:43:07+00:00

<img alt="Śmierć 8-letniego Kamila. Procedura Serious Case Review może pomóc zapobiec takim tragediom" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-71e3g8-smierc-8-letniego-kamila-procedura-serious-case-review-moze-pomoc-zapobiec-takim-tragediom-7137295/alternates/LANDSCAPE_1280" />
    Dramat 8-letniego Kamila wstrząsnął Polakami. Wciąż wybrzmiewa pytanie, co zrobić, by zapobiec takim sytuacjom. Fundacja "Dajemy Dzieciom Siłę" wskazuje na rozwiązanie, które sprawdziło się w Wielkiej Brytanii. Chodzi o Serious Case Reviews, czyli urzędową analizę tego, co nie zadziałało w systemie w danym przypadku.

## Kobieta wjechała pod prąd na S19, ledwo uniknęła zderzenia, po czym zawróciła na poboczu
 - [https://fakty.tvn24.pl/najnowsze/kobieta-wjechala-pod-prad-na-s19-ledwo-uniknela-zderzenia-po-czym-zawrocila-na-poboczu-7137393?source=rss](https://fakty.tvn24.pl/najnowsze/kobieta-wjechala-pod-prad-na-s19-ledwo-uniknela-zderzenia-po-czym-zawrocila-na-poboczu-7137393?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 18:10:05+00:00

<img alt="Kobieta wjechała pod prąd na S19, ledwo uniknęła zderzenia, po czym zawróciła na poboczu" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-4z88dg-kobieta-wjechala-pod-prad-na-s19-ledwo-uniknela-zderzenia-po-czym-zawrocila-na-poboczu-7137318/alternates/LANDSCAPE_1280" />
    Było o włos od katastrofy. Wbrew znakom osoba kierująca samochodem wjechała pod prąd i pędziła drogą ekspresową S19 na wysokości Janowa Lubelskiego, śmiertelnie narażając siebie i innych. Czołowego zderzenia udało się uniknąć w ostatniej chwili.

## Pogoda na jutro - poniedziałek 22.05. Dużo słońca i bardzo ciepło
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-poniedzialek-2205-duzo-slonca-i-bardzo-cieplo-7137361?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-poniedzialek-2205-duzo-slonca-i-bardzo-cieplo-7137361?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 17:47:25+00:00

<img alt="Pogoda na jutro - poniedziałek 22.05. Dużo słońca i bardzo ciepło" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-c1hbxi-pogodnie-slonecznie-7137370/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. Poniedziałek 22.05 będzie kolejnym ciepłym dniem. Najmniej chmur na niebie pojawi się w zachodnich regionach, ale wszędzie dzień upłynie pod znakiem słońca. Zagrzmieć może tylko lokalnie na krańcach zachodnich i południowych.

## Wysłannik Franciszka Matteo Zuppi zakończy wojnę w Ukrainie? "Misja niemożliwa", "nie budzi wielkich nadziei".
 - [https://fakty.tvn24.pl/fakty-po-poludniu/wyslannik-papieza-franciszka-matteo-zuppi-zakonczy-wojne-w-ukrainie-misja-niemozliwa-nie-budzi-wielkich-nadziei-7137250?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/wyslannik-papieza-franciszka-matteo-zuppi-zakonczy-wojne-w-ukrainie-misja-niemozliwa-nie-budzi-wielkich-nadziei-7137250?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 16:00:00+00:00

<img alt="Wysłannik Franciszka Matteo Zuppi zakończy wojnę w Ukrainie? " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-1yxjw4-wyslannik-franciszka-matteo-zuppi-zakonczy-wojne-w-ukrainie-misja-niemozliwa-nie-budzi-wielkich-nadziei-7137283/alternates/LANDSCAPE_1280" />
    Watykan ogłosił nazwisko kardynała, którego papież wyznaczył do misji pokojowej w Ukrainie. To Matteo Zuppi, przewodniczący Konferencji Episkopatu Włoch i przyjaciel Franciszka. Jednak duchowni mają wątpliwości co do powodzenia misji Stolicy Apostolskiej. Ojciec Stanisław Tasiemski ocenia, że nie budzi ona wielkich nadziei.

## Aktywiści chcą ocalić Puszczę Bukową. Protestują przeciwko wycince wiekowego drzewostanu
 - [https://tvn24.pl/pomorze/szczecin-aktywisci-chca-ocalic-puszcze-bukowa-protestuja-przeciwko-wycince-wiekowego-drzewostanu-7137074?source=rss](https://tvn24.pl/pomorze/szczecin-aktywisci-chca-ocalic-puszcze-bukowa-protestuja-przeciwko-wycince-wiekowego-drzewostanu-7137074?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 15:49:31+00:00

<img alt="Aktywiści chcą ocalić Puszczę Bukową. Protestują przeciwko wycince wiekowego drzewostanu" src="https://tvn24.pl/pomorze/cdn-zdjecie-z57mdt-aktywisci-chca-ocalic-puszcze-bukowa-protestuja-przeciwko-wycince-wiekowego-drzewostanu-7137240/alternates/LANDSCAPE_1280" />
    W Puszczy Bukowej (woj. zachodniopomorskie) trwa protest przeciw wycince drzew na terenie Nadleśnictwa Gryfino. Aktywistom nie podobają się plany leśników. - Nie zgadzamy się na dewastowanie tak cennych siedlisk przyrodniczych - podkreślają. Noc z soboty na niedzielę - w ramach protestu - spędzili w lesie. Przedstawiciele nadleśnictwa zaznaczają, że są gotowi do rozmów.

## Drzewa masowo znikają z miast i miasteczek. "Trzeba odbetonować każdy możliwy fragment"
 - [https://tvn24.pl/pomorze/kujawsko-pomorskie-drzewa-masowo-znikaja-z-miast-i-miasteczek-trzeba-odbetonowac-kazdy-mozliwy-fragment-7127787?source=rss](https://tvn24.pl/pomorze/kujawsko-pomorskie-drzewa-masowo-znikaja-z-miast-i-miasteczek-trzeba-odbetonowac-kazdy-mozliwy-fragment-7127787?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 14:16:48+00:00

<img alt="Drzewa masowo znikają z miast i miasteczek. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ewjt5-alejka-parkowa-w-toruniu-7137194/alternates/LANDSCAPE_1280" />
    W miastach ubywa drzew, a nowe nasadzenia w zupełności nie rekompensują strat sprzed wycinki. Wycina się ich więcej niż sadzi, jak na przykład w Bydgoszczy (woj. kujawsko-pomorskie), choć eksperci od zieleni zgodnie przyznają, że to i tak najlepiej zazielenione miasto województwa kujawsko-pomorskiego.

## Most obrotowy w Nowakowie. Podano, kiedy zostanie oddany do użytku
 - [https://tvn24.pl/biznes/z-kraju/most-obrotowy-w-nowakowie-zostanie-oddany-do-uzytku-przed-wakacjami-7137159?source=rss](https://tvn24.pl/biznes/z-kraju/most-obrotowy-w-nowakowie-zostanie-oddany-do-uzytku-przed-wakacjami-7137159?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 13:51:45+00:00

<img alt="Most obrotowy w Nowakowie. Podano, kiedy zostanie oddany do użytku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hl8246-most-obrotowy-w-nowakowie-7137178/alternates/LANDSCAPE_1280" />
    Most obrotowy w Nowakowie, budowany w ramach drogi wodnej łączącej Zalew Wiślany z Zatoką Gdańską, zostanie oddany do użytku przed wakacjami. To trzeci i największy most obrotowy na nowym szlaku do Elbląga - podała rzeczniczka inwestora Urzędu Morskiego w Gdyni Magdalena Kierzkowska.

## Pogoda na 16 dni: temperatura na huśtawce
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-16-dni-dlugoterminowa-prognoza-pogody-cieplo-ale-z-jednym-wyjatkiem-7137131?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-16-dni-dlugoterminowa-prognoza-pogody-cieplo-ale-z-jednym-wyjatkiem-7137131?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 13:11:41+00:00

<img alt="Pogoda na 16 dni: temperatura na huśtawce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-by4x8-16-7137136/alternates/LANDSCAPE_1280" />
    Po weekendzie temperatura nadal będzie przekraczać 20 stopni Celsjusza. Co czeka nas w ciągu kolejnych dni? Sprawdź długoterminową prognozę pogody Tomasza Wasilewskiego.

## Ktoś zauważył topiącego się mężczyznę. Akcja ratunkowa na Wiśle
 - [https://tvn24.pl/pomorze/grudziadz-akcja-ratunkowa-na-wisle-grupa-nurkow-szuka-topiacego-sie-mezczyzny-7137098?source=rss](https://tvn24.pl/pomorze/grudziadz-akcja-ratunkowa-na-wisle-grupa-nurkow-szuka-topiacego-sie-mezczyzny-7137098?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 13:04:24+00:00

<img alt="Ktoś zauważył topiącego się mężczyznę. Akcja ratunkowa na Wiśle" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ecyb7y-straz-pozarna-6789469/alternates/LANDSCAPE_1280" />
    Trwa akcja ratunkowa na Wiśle w Grudziądzu (woj. kujawsko-pomorskie). Grupa nurków poszukuje topiącego się mężczyzny.

## Młody mężczyzna pod wodą. Akcja ratunkowa i reanimacja
 - [https://tvn24.pl/tvnwarszawa/najnowsze/zegrze-mezczyzna-tonal-reanimacja-lpr-7137057?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/zegrze-mezczyzna-tonal-reanimacja-lpr-7137057?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 12:22:07+00:00

<img alt="Młody mężczyzna pod wodą. Akcja ratunkowa i reanimacja" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9p4tx-interwencja-sluzb-nad-zegrzem-7137055/alternates/LANDSCAPE_1280" />
    Młody mężczyzna topił się na Jeziorze Zegrzyńskim. Z wody wyciągnęli go ratownicy. Na miejscu lądował śmigłowiec Lotniczego Pogotowia Ratunkowego.

## Gdzie jest burza? Uwaga, grzmi w górach
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-2105-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-7137019?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-2105-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-7137019?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 11:40:15+00:00

<img alt="Gdzie jest burza? Uwaga, grzmi w górach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-rif6nm-wyladowania-atmosferyczne-w-polsce-w-niedziele-2105-7137035/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W niedzielę po południu nad Polską pojawiają się wyładowania atmosferyczne. Sprawdź, gdzie jest burza, i śledź aktualną sytuację pogodową w kraju na tvnmeteo.pl.

## Polskie MSZ wzywa władze Białorusi do uwolnienia wszystkich więźniów politycznych
 - [https://tvn24.pl/swiat/polskie-msz-wzywa-wladze-bialorusi-do-uwolnienia-wszystkich-wiezniow-politycznych-7136924?source=rss](https://tvn24.pl/swiat/polskie-msz-wzywa-wladze-bialorusi-do-uwolnienia-wszystkich-wiezniow-politycznych-7136924?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 11:06:25+00:00

<img alt="Polskie MSZ wzywa władze Białorusi do uwolnienia wszystkich więźniów politycznych" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecied41d8cd98f00b204e9800998ecf8427e-z-polski-plyna-zyczenia-do-andrzeja-poczobuta-dziennikarz-spedza-50-urodziny-w-bialoruskim-wiezieniu-5387535/alternates/LANDSCAPE_1280" />
    Polskie Ministerstwo Spraw Zagranicznych ponownie zaapelowało do władz w Mińsku o uwolnienie wszystkich więźniów politycznych, w tym Andrzeja Poczobuta. Resort przypomniał, że w niedzielę przypada Dzień Więźnia Politycznego, taki status ma obecnie na Białorusi niemal 1,5 tysiąca osób.

## "Wróciły wspomnienia z powodzi we Wrocławiu w 1997 roku". Relacja Polaka z Emilii-Romanii
 - [https://tvn24.pl/tvnmeteo/swiat/wrocily-wspomnienia-z-powodzi-we-wroclawiu-w-1997-roku-relacja-polaka-z-emilii-romanii-7136927?source=rss](https://tvn24.pl/tvnmeteo/swiat/wrocily-wspomnienia-z-powodzi-we-wroclawiu-w-1997-roku-relacja-polaka-z-emilii-romanii-7136927?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 10:58:15+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2y0mc3-zalana-faenza-w-regionie-emilia-romania-7136977/alternates/LANDSCAPE_1280" />
    Na Kontakt 24 otrzymaliśmy relację pana Piotra, który od 20 lat mieszka w Faenzie we włoskim regionie Emilia-Romania. Jak opowiadał, okolicę spotkała "tragedia nie do opisania". Na szczęście służby prężnie działają, by wesprzeć mieszkańców, nie można też mówić o braku pomocy między sąsiadami.

## Prezydent Gruzji na czarnej liście linii lotniczych. Założyciel domaga się przeprosin
 - [https://tvn24.pl/biznes/ze-swiata/prezydent-gruzji-na-czarnej-liscie-linii-lotniczych-zalozyciel-domaga-sie-przeprosin-7136901?source=rss](https://tvn24.pl/biznes/ze-swiata/prezydent-gruzji-na-czarnej-liscie-linii-lotniczych-zalozyciel-domaga-sie-przeprosin-7136901?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 10:39:30+00:00

<img alt="Prezydent Gruzji na czarnej liście linii lotniczych. Założyciel domaga się przeprosin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5x6z3d-prezydent-gruzji-salome-zurabiszwili-4585368/alternates/LANDSCAPE_1280" />
    Założyciel prywatnych gruzińskich linii lotniczych Georgian Airways zakazał prezydent kraju Salome Zurabiszwili korzystania z ich usług - poinformował Reuters, powołując się na rosyjską propagandową agencję TASS. Wcześniej polityk zapowiedziała bojkot przewoźnika w związku ze wznowieniem lotów do Rosji.

## Maks nie żyje, Lenka była bita. Proces przed sądem trwa już ponad cztery lata
 - [https://tvn24.pl/krakow/rzeszow-maks-nie-zyje-lenka-byla-bita-proces-matki-i-znajomego-rodziny-trwa-ponad-cztery-lata-sad-czeka-na-opinie-bieglych-7136845?source=rss](https://tvn24.pl/krakow/rzeszow-maks-nie-zyje-lenka-byla-bita-proces-matki-i-znajomego-rodziny-trwa-ponad-cztery-lata-sad-czeka-na-opinie-bieglych-7136845?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 10:39:07+00:00

<img alt="Maks nie żyje, Lenka była bita. Proces przed sądem trwa już ponad cztery lata " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kyot8e-maks-nie-zyje-lenka-byla-bita-przed-sadem-odpowiada-znajomy-rodziny-i-matka-dzieci-7136913/alternates/LANDSCAPE_1280" />
    Sąd Okręgowy w Rzeszowie czeka na opinię biegłych w sprawie zabójstwa półrocznego Maksa i znęcania się nad jego 2,5-letnią siostrą Lenką. Na ławie oskarżonych siedzi znajomy rodziny Grzegorz B. i matka dzieci - Karina B. Mężczyzna usłyszał zarzut zabójstwa chłopca i znęcania się nad dziewczynką, matka znęcania się nad córką. Proces w tej sprawie toczy się od ponad czterech lat.

## Lekarz musiał zwrócić zasiłek chorobowy. Podczas zwolnienia udzielał konsultacji w innym szpitalu
 - [https://tvn24.pl/pomorze/kujawsko-pomorskie-zwolnienia-l4-lekarz-musial-zwrocic-zasilek-chorobowy-podczas-zwolnienia-udzielal-konsultacji-w-innym-szpitalu-7128532?source=rss](https://tvn24.pl/pomorze/kujawsko-pomorskie-zwolnienia-l4-lekarz-musial-zwrocic-zasilek-chorobowy-podczas-zwolnienia-udzielal-konsultacji-w-innym-szpitalu-7128532?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 10:25:58+00:00

<img alt="Lekarz musiał zwrócić zasiłek chorobowy. Podczas zwolnienia udzielał konsultacji w innym szpitalu" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecieb460bd39dd290534fe2b143f96c47e78-zus-skontrolowal-zwolnienia-lekarskie-4301104/alternates/LANDSCAPE_1280" />
    Zakład Ubezpieczeń Społecznych regularnie przeprowadza kontrole dotyczące prawidłowego wykorzystania zwolnień lekarskich przez pracowników. Pewien lekarz z województwa kujawsko-pomorskiego w trakcie zwolnienia udzielał konsultacji medycznych w innym szpitalu. Musiał zwrócić zasiłek chorobowy.

## Przyszedł na komisariat z narkotykami i "poczuciem winy"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mokotow-przyszedl-na-komisariat-i-powiedzial-ze-ma-narkotyki-7136792?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mokotow-przyszedl-na-komisariat-i-powiedzial-ze-ma-narkotyki-7136792?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 10:08:27+00:00

<img alt="Przyszedł na komisariat z narkotykami i " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-s9t9ky-komenda-rejonowa-policji-na-mokotowie-7136888/alternates/LANDSCAPE_1280" />
    Trzy lata więzienia grozi mężczyźnie, który sam zgłosił się na mokotowską komendę. W plecaku przyniósł narkotyki, bo - jak oświadczył - poczucie winy nie pozwala mu normalnie funkcjonować.

## Motocyklista wjechał w tył samochodu. Został ranny
 - [https://tvn24.pl/tvnwarszawa/ulice/stanislawow-pierwszy-trasa-632-motocyklista-wjechal-w-auto-7136793?source=rss](https://tvn24.pl/tvnwarszawa/ulice/stanislawow-pierwszy-trasa-632-motocyklista-wjechal-w-auto-7136793?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 09:28:19+00:00

<img alt="Motocyklista wjechał w tył samochodu. Został ranny" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qf95c8-wypadek-na-trasie-632-7136809/alternates/LANDSCAPE_1280" />
    Utrudnienia na trasie 632. Powodem jest wypadek z udziałem motocyklisty, który wjechał w auto osobowe. Trafił do szpitala.

## Zasłużony klub z problemami, regularnie zalewa im boisko. "Pojawiło się światełko w tunelu"
 - [https://tvn24.pl/pomorze/torun-pomorzanin-torun-z-problemami-regularnie-zalewa-im-boisko-jest-swiatelko-w-tunelu-7128321?source=rss](https://tvn24.pl/pomorze/torun-pomorzanin-torun-z-problemami-regularnie-zalewa-im-boisko-jest-swiatelko-w-tunelu-7128321?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 08:42:59+00:00

<img alt="Zasłużony klub z problemami, regularnie zalewa im boisko. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-flqpj4-zalane-boisko-laskarzy-pomorzanina-torun-7128300/alternates/LANDSCAPE_1280" />
    Hokeiści na trawie Pomorzanina Toruń (woj. kujawsko-pomorskie) od lat zmagają się z problemem notorycznie zalewanego boiska. Po opadach deszczu muszą przekładać mecze. Ostatnio jednak pojawiło się światełko w tunelu.

## Sprzedaż ziemi rolnej w Polsce. Tyle płacono za hektar
 - [https://tvn24.pl/biznes/z-kraju/sprzedaz-ziemi-rolnej-w-polsce-w-2022-roku-srednia-cena-za-hektar-to-ponad-43-tysiace-zlotych-7136722?source=rss](https://tvn24.pl/biznes/z-kraju/sprzedaz-ziemi-rolnej-w-polsce-w-2022-roku-srednia-cena-za-hektar-to-ponad-43-tysiace-zlotych-7136722?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 08:13:09+00:00

<img alt="Sprzedaż ziemi rolnej w Polsce. Tyle płacono za hektar" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p3dqhx-ziemia-rolna-traktor-shutterstock748405993jpg/alternates/LANDSCAPE_1280" />
    W ubiegłym roku Krajowy Ośrodek Wsparcia Rolnictwa sprzedał 3620 hektarów ziemi rolnej, o 1 procent więcej niż rok wcześniej. Średnia cena wyniosła 43466 złotych za hektar. Najwięcej za grunty zapłacono w województwach pomorskim i dolnośląskim.

## Wyprzedziła nieoznakowany radiowóz na przejściu dla pieszych
 - [https://tvn24.pl/tvnwarszawa/najnowsze/radom-wyprzedzila-policyjny-radiowoz-na-przejsciu-dla-pieszych-wideo-7136701?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/radom-wyprzedzila-policyjny-radiowoz-na-przejsciu-dla-pieszych-wideo-7136701?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 08:04:02+00:00

<img alt="Wyprzedziła nieoznakowany radiowóz na przejściu dla pieszych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b5mexr-nieoznakowany-radiowoz-wyprzedzila-na-przejsciu-dla-pieszych-7136703/alternates/LANDSCAPE_1280" />
    Policjanci z grupy Speed w Radomiu nagrali i zatrzymali kierującą, która wyprzedziła ich nieoznakowany radiowóz na przejściu dla pieszych.  - Zupełnie nie zdawała sobie sprawy z wagi popełnionego wykroczenia - opisują funkcjonariusze.

## Dziki Warszawa zagrają w koszykarskiej elicie
 - [https://tvn24.pl/tvnwarszawa/wola/warszawa-dziki-warszawa-zagraja-w-koszykarskiej-ekstraklasie-7136734?source=rss](https://tvn24.pl/tvnwarszawa/wola/warszawa-dziki-warszawa-zagraja-w-koszykarskiej-ekstraklasie-7136734?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 07:57:50+00:00

<img alt="Dziki Warszawa zagrają w koszykarskiej elicie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-25eesg-dziki-pokonaly-walbrzyskiego-gornika-7136727/alternates/LANDSCAPE_1280" />
    Dziki Warszawa pokonały Górnika Trans.Eu Zamek Książ Wałbrzych 66:62 (19:14, 14:18, 22:15, 11:15) w trzecim meczu finału 1. ligi koszykarzy i awansowały do ekstraklasy. Zespół z Warszawy zwyciężył Górnika 3-0.

## Polscy strażacy wesprą Włochy w walce ze skutkami powodzi
 - [https://tvn24.pl/tvnmeteo/swiat/powodzie-we-wloszech-polska-wesprze-poszkodowany-kraj-na-miejsce-pojedzie-kilkudziesieciu-strazakow-i-specjalistyczny-sprzet-7136694?source=rss](https://tvn24.pl/tvnmeteo/swiat/powodzie-we-wloszech-polska-wesprze-poszkodowany-kraj-na-miejsce-pojedzie-kilkudziesieciu-strazakow-i-specjalistyczny-sprzet-7136694?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 07:46:45+00:00

<img alt="Polscy strażacy wesprą Włochy w walce ze skutkami powodzi" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-kcf8rw-konsekwencje-powodzi-we-wloskim-regionie-emilia-romania-7136716/alternates/LANDSCAPE_1280" />
    Od wielu dni Włochy walczą z konsekwencjami rozległych powodzi. Zjawiska przyczyniły się do śmierci co najmniej 14 osób i przesiedlenia ponad 36 tysięcy mieszkańców regionu Emilia-Romania. W niedzielę Państwowa Straż Pożarna przekazała, że jest gotowa do wsparcia Włoch. Na miejsce ma pojechać kilkudziesięciu polskich strażaków oraz specjalistyczny sprzęt.

## Zamknięte szkoły, opóźnione loty. Wulkan Popocatepetl dał o sobie znać
 - [https://tvn24.pl/tvnmeteo/swiat/meksyk-zamkniete-szkoly-opoznione-loty-wulkan-popocatepetl-dal-o-sobie-znac-7136677?source=rss](https://tvn24.pl/tvnmeteo/swiat/meksyk-zamkniete-szkoly-opoznione-loty-wulkan-popocatepetl-dal-o-sobie-znac-7136677?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 07:12:46+00:00

<img alt="Zamknięte szkoły, opóźnione loty. Wulkan Popocatepetl dał o sobie znać" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-yg39g5-wybuchl-wulkan-popocatepetl-7136649/alternates/LANDSCAPE_1280" />
    Wulkan Popocatepetl w Meksyku przebudził się kilka dni temu i od tego czasu niepokoi mieszkańców. Jego najbliższe okolice zostały przyprószone warstwą popiołu, z uwagi na zagrożenie, w niektórych miastach odwołano lekcje.

## Zmiana 500 plus na 800 plus. Kołodko: należy ograniczyć liczbę osób, które z tego korzystają
 - [https://tvn24.pl/biznes/z-kraju/800-plus-zamiast-500-plus-grzegorz-kolodko-byly-minister-finansow-o-waloryzacji-500-plus-i-kryterium-dochodowym-7136009?source=rss](https://tvn24.pl/biznes/z-kraju/800-plus-zamiast-500-plus-grzegorz-kolodko-byly-minister-finansow-o-waloryzacji-500-plus-i-kryterium-dochodowym-7136009?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 06:04:53+00:00

<img alt="Zmiana 500 plus na 800 plus. Kołodko: należy ograniczyć liczbę osób, które z tego korzystają" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-k1drry-grzegorz-kolodko-7136077/alternates/LANDSCAPE_1280" />
    500 plus ma się zmienić w 800 plus. - Należy zwaloryzować świadczenie, ale zarazem ograniczyć liczbę osób, które z tego świadczenia korzystają - mówił w "Faktach po Faktach" w TVN24 były wicepremier i minister finansów profesor Grzegorz Kołodko. W jego ocenie należy wprowadzić tym samym kryterium dochodowe w programie Rodzina 500 plus.

## Iran chce wysłać okręty wojenne na Antarktydę
 - [https://tvn24.pl/swiat/iran-chce-wyslac-okrety-wojenne-na-antarktyde-media-w-teheranie-7136549?source=rss](https://tvn24.pl/swiat/iran-chce-wyslac-okrety-wojenne-na-antarktyde-media-w-teheranie-7136549?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 05:47:07+00:00

<img alt="Iran chce wysłać okręty wojenne na Antarktydę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-25s9bp-teheran-5084932/alternates/LANDSCAPE_1280" />
    Iran ma wysłać swoje okręty wojenne na Antarktydę. Informacje w tej sprawie przekazały w sobotę irańskie media. Z ich doniesień wynika, że misja polarna ma się rozpocząć w "najbliższej przyszłości".

## Lubisz robić selfie w słońcu? Uważaj
 - [https://tvn24.pl/tvnmeteo/nauka/lubisz-robic-selfie-w-sloncu-uwazaj-7136618?source=rss](https://tvn24.pl/tvnmeteo/nauka/lubisz-robic-selfie-w-sloncu-uwazaj-7136618?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 05:24:38+00:00

<img alt="Lubisz robić selfie w słońcu? Uważaj" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3cc5dy-uwaga-na-slonce-5194504/alternates/LANDSCAPE_1280" />
    Nawet krótkotrwałe patrzenie na słońce bez odpowiedniej ochrony może zniszczyć nasz wzrok. Jak ostrzegają włoscy okuliści, w takiej sytuacji szczególnie niebezpieczne jest także wpatrywanie się telefon, na przykład by zrobić odpowiednią pozę do selfie.

## Pogoda na dziś - niedziela 21.05. Nawet 25 stopni, w górach możliwe burze
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-niedziela-2105-nawet-25-stopni-w-gorach-mozliwe-burze-7135965?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-niedziela-2105-nawet-25-stopni-w-gorach-mozliwe-burze-7135965?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-21 00:00:00+00:00

<img alt="Pogoda na dziś - niedziela 21.05. Nawet 25 stopni, w górach możliwe burze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oj20c4-burze-w-gorach-5744220/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Niedziela 21.05 w niemal całym kraju upłynie pod znakiem słońca. Wyjątkiem będą krańce południowe, w tym góry, gdzie w drugiej części dnia może zagrzmieć. Termometry wszędzie wskażą ponad 20 stopni Celsjusza.

