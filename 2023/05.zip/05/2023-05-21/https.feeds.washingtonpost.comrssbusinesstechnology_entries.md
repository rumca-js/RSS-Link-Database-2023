# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## SpaceX to launch 4 private citizens Sunday to the space station
 - [https://www.washingtonpost.com/technology/2023/05/21/axiom-spacex-iss-launch/](https://www.washingtonpost.com/technology/2023/05/21/axiom-spacex-iss-launch/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-05-21 15:10:50+00:00

It's the second mission chartered by the Houston company Axiom Space. Aboard will be a veteran astronaut, two Saudi Arabians and an American entrepreneur.

