# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Facts Don't Care About Gender Equality
 - [https://www.youtube.com/watch?v=E7NtvJWQwu0](https://www.youtube.com/watch?v=E7NtvJWQwu0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-05-21 21:00:04+00:00

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire 
#shorts #shortsfeed #shortsreaction #masculinity #genderroles #feminism #toxicfemininity #viral #reaction

