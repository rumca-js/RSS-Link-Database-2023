# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Biden: Warunki Republikanów ws. podniesienia limitu zadłużenia rządu są nie do przyjęcia
 - [https://forsal.pl/swiat/usa/artykuly/8720045,biden-warunki-republikanow-ws-podniesienia-limitu-zadluzenia-rzadu-nie-do-przyjecia.html](https://forsal.pl/swiat/usa/artykuly/8720045,biden-warunki-republikanow-ws-podniesienia-limitu-zadluzenia-rzadu-nie-do-przyjecia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 20:44:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gm4ktkuTURBXy80MGQ5NGJiNS01ZDkxLTRlZGMtOTY0OC00YjJlNjJhNzlmZDIuanBlZ5GTBc0BHcyg" />Prezydent Joe Biden powiedział w niedzielę, że warunki Republikanów w negocjacjach na temat podniesienia limitu zadłużenia rządu są &quot;nie do przyjęcia&quot;. Zapowiedział, gotowość obniżenia wydatków i korekt podatkowych w celu porozumienia.

## Gitara, rozbita przez Kurta Cobaina z Nirvany, sprzedana za prawie 600 tys. dolarów
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8720043,gitara-rozbita-przez-kurta-cobaina-z-nirvany-sprzedana-za-prawie-600-tys-dolarow.html](https://forsal.pl/biznes/aktualnosci/artykuly/8720043,gitara-rozbita-przez-kurta-cobaina-z-nirvany-sprzedana-za-prawie-600-tys-dolarow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 20:36:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/E67ktkuTURBXy84MjZiNTJiYS0zNzNkLTQ2YzgtODczYy1kZWRlMDE2NmJjM2EuanBlZ5GTBc0BHcyg" />Gitara rozbita przez Kurta Cobaina, nieżyjącego już frontmana amerykańskiego zespołu rockowego Nirvana została sprzedana na sobotniej aukcji w Hard Rock Cafe w Nowym Jorku za prawie 600 tys. dolarów, poinformowało BBC.

## "Defender Europe 23". Największe na Bałkanach ćwiczenia NATO
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8720042,defender-europe-23-rozpoczely-sie-najwieksze-na-balkanach-cwiczenia-nato.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8720042,defender-europe-23-rozpoczely-sie-najwieksze-na-balkanach-cwiczenia-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 20:26:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LsiktkuTURBXy8yMDE4Y2RhYS1jOGIxLTQ2YzctODI3Yi1hYWM0MzUzNmYxZWIuanBlZ5GTBc0BHcyg" />W Prisztinie - stolicy Kosowa - rozpoczęły się w niedzielę największe na Bałkanach ćwiczenia wojskowe NATO &quot;Defender Europe 23&quot; - poinformował kosowski dziennik &quot;Koha Ditore&quot;.

## Ziobro: Premier we wszystkich decyzjach unijnych się pomylił
 - [https://forsal.pl/gospodarka/polityka/artykuly/8720031,zbigniew-ziobro-premier-we-wszystkich-decyzjach-unijnych-sie-pomylil.html](https://forsal.pl/gospodarka/polityka/artykuly/8720031,zbigniew-ziobro-premier-we-wszystkich-decyzjach-unijnych-sie-pomylil.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 19:36:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lKcktkuTURBXy9lZGFjMTY3Zi1kYTQxLTQ4YTQtOGIyNC01ZmFmYTc1NGQ5OWEuanBlZ5GTBc0BHcyg" />Premier Mateusz Morawiecki pomylił się we wszystkich najważniejszych decyzjach unijnych; w efekcie zgody premiera na unijny mechanizm warunkowości i KPO Polska będzie stopniowo tracić suwerenność – mówi w wywiadzie dla &quot;Do Rzeczy&quot; minister sprawiedliwości i szef Suwerennej Polski Zbigniew Ziobro.

## AP: Przywódcy Afryki chcą rozmawiać w Moskwie i Kijowie o pokoju i sankcjach
 - [https://forsal.pl/artykuly/8719997,przywodcy-afryki-chca-rozmawiac-w-moskwie-i-kijowie-o-pokoju-i-sankcjach.html](https://forsal.pl/artykuly/8719997,przywodcy-afryki-chca-rozmawiac-w-moskwie-i-kijowie-o-pokoju-i-sankcjach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 19:00:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BwOktkuTURBXy9hY2I3Mjk2OC01ODFjLTQ1ZTMtOWYxNy0yYWViOWI2NDVkMjYuanBlZ5GTBc0BHcyg" />Przywódcy sześciu krajów afrykańskich: Egiptu, Konga, RPA, Senegalu, Ugandy i Zambii planują rozmowy z Rosją i Ukrainą na temat procesu pokojowego, jak i kupowania przez Afrykę - w obliczu sankcji - nawozów rosyjskich - informuje w niedzielę Associated Press.

## "Cokolwiek Rosjanie mówią o Bachmucie, cieszą się przedwcześnie"
 - [https://forsal.pl/swiat/ukraina/artykuly/8719944,cokolwiek-rosjanie-mowia-o-bachmucie-ciesza-sie-przedwczesnie.html](https://forsal.pl/swiat/ukraina/artykuly/8719944,cokolwiek-rosjanie-mowia-o-bachmucie-ciesza-sie-przedwczesnie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 17:51:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dYbktkuTURBXy8wOTgwNTcwNC04N2I2LTRmZmUtYmM1ZS1hNzhmOTc3Y2Q5MGEuanBlZ5GTBc0BHcyg" />Bez względu na to, co Rosjanie mówią obecnie o Bachmucie, cieszą się przedwcześnie; powinni raczej pomyśleć o pojawieniu się na Ukrainie samolotów F-16 - oceniła w niedzielę wicepremier ukraińskiego rządu Iryna Wereszczuk.

## Kto będzie kandydatem Zjednoczonej Prawicy na prezydenta? [SONDAŻ]
 - [https://forsal.pl/gospodarka/polityka/artykuly/8719832,kto-bedzie-kandydatem-zjednoczonej-prawicy-na-prezydenta-sondaz.html](https://forsal.pl/gospodarka/polityka/artykuly/8719832,kto-bedzie-kandydatem-zjednoczonej-prawicy-na-prezydenta-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 17:03:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NmWktkuTURBXy9jMDRkYzI4MC03OTU0LTQyYTUtOTRhNC01ZmQ5MzY5MDRiNjIuanBlZ5GTBc0BHcyg" />21,4 proc. respondentów sondażu United Surveys dla Wirtualnej Polski wskazało premiera Mateusza Morawieckiego jako potencjalnego kandydata Zjednoczonej Prawicy na prezydenta. 8,9 proc. badanych widzi w roli kandydatki na prezydenta byłą premier Beatę Szydło.

## Wybory parlamentarne w Grecji. Oto wyniki exit poll
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8719817,wybory-parlamentarne-w-grecji-oto-wyniki-exit-poll.html](https://forsal.pl/swiat/aktualnosci/artykuly/8719817,wybory-parlamentarne-w-grecji-oto-wyniki-exit-poll.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 16:46:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3ATktkuTURBXy9mNjEwMmY0ZS0wNmUxLTQwMWEtYWYxNS1lZGEzNjlkN2U0NTMuanBlZ5GTBc0BHcyg" />Według badań exit poll, opublikowanych zaraz po zamknięciu lokali wyborczych, niedzielne wybory parlamentarne w Grecji wygrała Nowa Demokracja premiera Kyriakosa Micotakisa.

## Wybory parlamentarne w Grecji. Wstępne oficjalne wyniki
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8719817,wybory-parlamentarne-w-grecji-wstepne-oficjalne-wyniki.html](https://forsal.pl/swiat/aktualnosci/artykuly/8719817,wybory-parlamentarne-w-grecji-wstepne-oficjalne-wyniki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 16:46:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3ATktkuTURBXy9mNjEwMmY0ZS0wNmUxLTQwMWEtYWYxNS1lZGEzNjlkN2U0NTMuanBlZ5GTBc0BHcyg" />Jak wynika z pierwszych częściowych oficjalnych danych po przeliczeniu ponad jednej trzeciej wszystkich głosów, Nowa Demokracja premiera Kyriakosa Micotakisa zdominowała niedzielne wybory parlamentarne, wyprzedzając drugą Syrizę o 20 proc.

## Największe wróg dekarbonizacji? Dominacja monopoli i brak swobodnej konkurencji
 - [https://forsal.pl/gospodarka/artykuly/8719309,najwieksze-wrog-dekarbonizacji-dominacja-monopoli-i-brak-swobodnej-konkurencji.html](https://forsal.pl/gospodarka/artykuly/8719309,najwieksze-wrog-dekarbonizacji-dominacja-monopoli-i-brak-swobodnej-konkurencji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 15:39:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZvzktkuTURBXy80NTc1YTJiMy02ZGViLTRmYzUtOTQ3MS1lODA4NDBjMThhMjkuanBlZ5GTBc0BHcyg" />Na globalne emisje wpływają głównie kraje o mniejszej swobodzie gospodarczej i większej kontroli rządu, gdzie dominują monopole. W takich miejscach wciąż korzysta się z węgla.

## Kraje G7 wezwały Chiny, by wywarły presję na Rosję w celu zakończenia wojny przeciw Ukrainie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8719788,kraje-g7-wezwaly-chiny-by-wywarly-presje-na-rosje-w-celu-zakonczenia-wojny-przeciw-ukrainie.html](https://forsal.pl/swiat/aktualnosci/artykuly/8719788,kraje-g7-wezwaly-chiny-by-wywarly-presje-na-rosje-w-celu-zakonczenia-wojny-przeciw-ukrainie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 15:36:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fJKktkuTURBXy9jNTUzYjMxZC0xYmJjLTQ1OTYtYThmOC1jOGFkYWVlNTY0NjAuanBlZ5GTBc0BHcyg" />Kraje G7 w oświadczeniu na szczycie w Hiroszimie wezwały Chiny do wywarcia presji na Rosję, aby Moskwa &quot;przerwała agresję militarną&quot; i &quot;bezzwłocznie wycofała wojska z Ukrainy&quot; - wynika z dokumentu opublikowanego na stronie internetowej Białego Domu.

## Hillary Clinton: Niepowodzenia Rosji w wojnie na Ukrainie cofnęły plany Chin ws. Tajwanu
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8719690,hillary-clinton-niepowodzenia-rosji-w-wojnie-na-ukrainie-cofnely-plany-chin-ws-tajwanu.html](https://forsal.pl/swiat/aktualnosci/artykuly/8719690,hillary-clinton-niepowodzenia-rosji-w-wojnie-na-ukrainie-cofnely-plany-chin-ws-tajwanu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 15:28:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Yz4ktkuTURBXy84ZTY2OTI0Mi05YTI3LTQyZmItODA0Ny1iZjYwZTI1ZGYwNjIuanBlZ5GTBc0BHcyg" />Wojna Putina na Ukrainie &quot;cofnęła&quot; ambicje Chin do inwazji na Tajwan, powiedziała była sekretarz stanu USA Hillary Clinton w wywiadzie dla &quot;Financial Times Weekend&quot;.

## Sunak: Chiny stanowią największe wyzwanie dla globalnego bezpieczeństwa
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8719689,politico-sunak-okreslil-chiny-jako-najwieksze-wyzwanie-dla-globalnego-bezpieczenstwa.html](https://forsal.pl/swiat/aktualnosci/artykuly/8719689,politico-sunak-okreslil-chiny-jako-najwieksze-wyzwanie-dla-globalnego-bezpieczenstwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 15:18:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GBsktkuTURBXy8xOGRkMDI1NC05Njk0LTQ2MzEtOGNkOS1jNzJmZWQzNTYyYmQuanBlZ5GTBc0BHcyg" />Premier Wielkiej Brytanii Rishi Sunak, który uczestniczy w szczycie grupy G7 w Hiroszimie w Japonii, określił Chiny jako największe wyzwanie dla globalnego bezpieczeństwa, poinformował w niedzielę portal Politico.

## Bezprecedensowa konsolidacja władzy i własności. Nierówności na świecie rosną dramatycznie
 - [https://forsal.pl/gospodarka/artykuly/8719323,bezprecedensowa-konsolidacja-wladzy-i-wlasnosci-nierownosci-na-swiecie-rosna-dramatycznie.html](https://forsal.pl/gospodarka/artykuly/8719323,bezprecedensowa-konsolidacja-wladzy-i-wlasnosci-nierownosci-na-swiecie-rosna-dramatycznie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 14:18:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qnuktkuTURBXy82MTBiMmJiMS04ZGM0LTQzNTgtYmMxNy05Mjg3NzBhOTgyZWQuanBlZ5GTBc0BHcyg" />W latach 60. XX w. studenci i pracownicy mogli protestować – kontrowały ich konserwatywne średnie kadry. Obecnie wszyscy jesteśmy średnimi kadrami dla samych siebie i czujemy, że bunt zwróci się najpewniej przeciwko nam.

## Wielka deregulacja. Jak to się stało, że kolej w USA tak podupadła?
 - [https://forsal.pl/swiat/usa/artykuly/8719321,wielka-deregulacja-w-usa-jak-to-sie-stalo-ze-kolej-w-usa-tak-podupadla.html](https://forsal.pl/swiat/usa/artykuly/8719321,wielka-deregulacja-w-usa-jak-to-sie-stalo-ze-kolej-w-usa-tak-podupadla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 13:28:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cGTktkuTURBXy80OGJkZjc4Yi0xNWMyLTRiMGUtYTlmNC1lYmQ5NTU5NGZlYjAuanBlZ5GTBc0BHcyg" />Od 2002 r. lobbyści wydali ponad 635 mln dol., przekonując do dalszej deregulacji kolejnictwa.

## Rewolucja w węgierskiej edukacji. Co rząd Orbana zrobi z unijną presją?
 - [https://forsal.pl/lifestyle/edukacja/artykuly/8719317,rewolucja-w-wegierskiej-edukacji-co-rzad-orbana-zrobi-z-unijna-presja.html](https://forsal.pl/lifestyle/edukacja/artykuly/8719317,rewolucja-w-wegierskiej-edukacji-co-rzad-orbana-zrobi-z-unijna-presja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 13:00:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AaIktkuTURBXy8xZDJlZjEyNC0zYTQzLTQzNDYtYThjOS1lMjExMDI2Y2ZkNjAuanBlZ5GTBc0BHcyg" />Węgierscy nauczyciele protestują przeciw projektowi uregulowania ich statusu, choć władze twierdzą, że czekają ich wysokie podwyżki, a w ogóle to do zmian prawa zmusiła je Unia Europejska.

## Prezydent USA: Rosja straciła w Bachmucie ponad 100 tys. żołnierzy
 - [https://forsal.pl/swiat/ukraina/artykuly/8719677,prezydent-usa-rosja-stracila-w-bachmucie-ponad-100-tys-zolnierzy.html](https://forsal.pl/swiat/ukraina/artykuly/8719677,prezydent-usa-rosja-stracila-w-bachmucie-ponad-100-tys-zolnierzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 12:46:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TXIktkuTURBXy9jNmRiNGRmOC1iMDUzLTQ1N2ItYTU4My05YWVjNDFkYTQwZDcuanBlZ5GTBc0BHcyg" />Rosja straciła w Bachmucie na wschodzie Ukrainy ponad 100 tys. żołnierzy - powiedział w niedzielę prezydent USA Joe Biden, uczestniczący w szczycie grupy G7 w Hiroszimie w Japonii.

## Plakaty z sierpem i młotem na ateńskich ulicach. "W Polsce siedzieliby w więzieniu, u nas walczą o władzę"
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8719670,plakaty-z-sierpem-i-mlotem-na-atenskich-ulicach-w-polsce-siedzieliby-w-wiezieniu-u-nas-walcza-o-wladze.html](https://forsal.pl/swiat/aktualnosci/artykuly/8719670,plakaty-z-sierpem-i-mlotem-na-atenskich-ulicach-w-polsce-siedzieliby-w-wiezieniu-u-nas-walcza-o-wladze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 12:27:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/B81ktkuTURBXy9iNTE0NzExMC1hYjk2LTQxNDMtOTMzMy0yMDMxYzA4NWJjMDcuanBlZ5GTBc0BHcyg" />W związku z niedzielnymi wyborami na ateńskich ulicach rzucają się w oczy przede wszystkim plakaty opozycyjnych partii lewicowych, w tym Komunistycznej Partii Grecji. W Polsce komuniści siedzieliby w więzieniu, u nas walczą o władzę – powiedzieli PAP mieszkańcy Aten.

## Kraków: Nie będzie całodobowej poczty; skróceniu godzin pracy punktu sprzeciwiają się prawnicy
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8719661,w-krakowie-nie-bedzie-calodobowej-poczty-skroceniu-godzin-pracy-punktu-sprzeciwiaja-sie-prawnicy.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8719661,w-krakowie-nie-bedzie-calodobowej-poczty-skroceniu-godzin-pracy-punktu-sprzeciwiaja-sie-prawnicy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 11:08:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RMzktkuTURBXy82YWRjYWYxYy03NDRmLTRhY2UtYTlhNS1iNTgwMGUxN2Y3MWUuanBlZ5GTBc0BHcyg" />Jedyny w Krakowie całodobowy punkt Poczty Polskiej, w rejonie dworca PKP, od 1 czerwca czyny będzie do godz. 20. Nie zgadzają się z tym adwokaci i radcy prawni argumentując, że dzięki temu oddziałowi mogli w terminie składać pisma procesowe, a to leży w interesie wymiaru sprawiedliwości.

## Egzamin ósmoklasisty 2023: Duże zmiany. Czy będzie trudny?
 - [https://forsal.pl/lifestyle/edukacja/artykuly/8719339,egzamin-osmoklasisty-2023-duze-zmiany-czy-bedzie-trudny.html](https://forsal.pl/lifestyle/edukacja/artykuly/8719339,egzamin-osmoklasisty-2023-duze-zmiany-czy-bedzie-trudny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 10:03:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/p5LktkuTURBXy84YTE3NGJhYy1hZjlhLTQwYTMtOGM1OC05MTVmNmQ2NTEzMmIuanBlZ5GTBc0BHcyg" />Egzamin ósmoklasisty 2023 odbędzie się w dniach 23-25 maja. Jego wyniki będą miały znaczenie przy rekrutacji do szkół średnich. Czy będzie trudny? Ósmoklasiści liczą, że nie, ponieważ odbędzie się jeszcze na zasadach określonych w pandemii. Czego zatem można spodziewać się na egzaminie ósmoklasisty 2023?

## Scholz na szczycie G7. Kanclerz Niemiec nawiązał do "ważnego przekazu" dla Rosji
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8719648,scholz-na-szczycie-g7-kanclerz-niemiec-nawiazal-do-waznego-przekazu-dla-rosji.html](https://forsal.pl/swiat/aktualnosci/artykuly/8719648,scholz-na-szczycie-g7-kanclerz-niemiec-nawiazal-do-waznego-przekazu-dla-rosji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 09:38:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/V-3ktkuTURBXy8yN2YxNGFmMi0wMjQzLTRlZWItOWJmYS1iNGMwZTE1ZjJmZWYuanBlZ5GTBc0BHcyg" />Niemcy nie będą dostarczać Ukrainie myśliwców i sprawa ta nie podlega dyskusji; nawet nie dysponujemy samolotami F-16 – oznajmił w niedzielę kanclerz Niemiec Olaf Scholz na marginesie szczytu G7 w Hiroszimie w Japonii. Szkolenia ukraińskich pilotów na tych maszynach to długoterminowy projekt i ważny przekaz dla rosyjskich agresorów - dodał.

## Okuliści ostrzegają: Selfie na słońcu może spowodować uraz oczu
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8719634,wlochy-okulisci-ostrzegaja-selfie-na-sloncu-moze-spowodowac-uraz-oczu.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8719634,wlochy-okulisci-ostrzegaja-selfie-na-sloncu-moze-spowodowac-uraz-oczu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 08:23:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lCpktkuTURBXy85MzAzY2MxYy1lYWQ0LTQ4YjgtYWUwZC0zOWM5NDAyNDBmNTkuanBlZ5GTBc0BHcyg" />Selfie robione na słońcu może spowodować uraz oczu - alarmują włoscy okuliści. Ostrzegają, że także długie wpatrywanie się w smartfon lub tablet może uszkodzić siatkówkę oka.

## Okuliści ostrzegają: Selfie w słońcu może spowodować uraz oczu
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8719634,wlochy-okulisci-ostrzegaja-selfie-w-sloncu-moze-spowodowac-uraz-oczu.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8719634,wlochy-okulisci-ostrzegaja-selfie-w-sloncu-moze-spowodowac-uraz-oczu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 08:23:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lCpktkuTURBXy85MzAzY2MxYy1lYWQ0LTQ4YjgtYWUwZC0zOWM5NDAyNDBmNTkuanBlZ5GTBc0BHcyg" />Selfie robione w słońcu może spowodować uraz oczu - alarmują włoscy okuliści. Ostrzegają, że także długie wpatrywanie się w smartfon lub tablet może uszkodzić siatkówkę oka.

## Czy automatyczne rolety wpływają na oszczędzanie energii?
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8719632,czy-automatyczne-rolety-okienne-wplywaja-na-oszczedzanie-energii.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8719632,czy-automatyczne-rolety-okienne-wplywaja-na-oszczedzanie-energii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 08:14:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eupktkuTURBXy8xYzQ4NTUyMC04ZmM3LTQxYTgtOWY4NS05MWYyZTM2ZmY2MTcuanBlZ5GTBc0BHcyg" />Korzystanie ze zautomatyzowanych rolet okiennych może wpłynąć na duże oszczędności energii w domach i biurach. Zużycie prądu można zredukować nawet do ok. 25 procent, a inwestycje na modernizacje zwracają się w przeciągu kilku lat - wskazują badacze z USA.

## Tymczasowe elektroniczne prawo jazdy. Egzaminator WORD: To rozwiązanie, na które czekają wszyscy kandydaci
 - [https://forsal.pl/transport/aktualnosci/artykuly/8719628,tymczasowe-elektroniczne-prawo-jazdy-egzaminator-word-to-rozwiazanie-na-ktore-czekaja-wszyscy-kandydaci.html](https://forsal.pl/transport/aktualnosci/artykuly/8719628,tymczasowe-elektroniczne-prawo-jazdy-egzaminator-word-to-rozwiazanie-na-ktore-czekaja-wszyscy-kandydaci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 07:44:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8lLktkuTURBXy85ODczOTQ1Ni1lNjQ3LTRmZjYtOWMxNi0xODRhY2M2YWRhZWUuanBlZ5GTBc0BHcyg" />Tymczasowe elektroniczne prawo jazdy to bardzo dobre rozwiązanie, na które na pewno czekają wszyscy kandydaci na kierowców - ocenił w rozmowie z PAP egzaminator z Wojewódzkiego Ośrodka Ruchu Drogowego w Warszawie Rafał Grodzicki.

## Zełenski: Dzisiaj Bachmut jest już tylko w naszych sercach
 - [https://forsal.pl/swiat/ukraina/artykuly/8719625,zelenski-dzisiaj-bachmut-jest-juz-tylko-w-naszych-sercach.html](https://forsal.pl/swiat/ukraina/artykuly/8719625,zelenski-dzisiaj-bachmut-jest-juz-tylko-w-naszych-sercach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 07:33:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/poyktkuTURBXy8yYTRkMDFjNC05N2IyLTQzNjUtOGY3Mi03ODU2ZTI1NDViZjIuanBlZ5GTBc0BHcyg" />Dzisiaj Bachmut jest już tylko w naszych sercach - oświadczył w niedzielę prezydent Ukrainy Wołodymyr Zełenski podczas szczytu G7 w Hiroszimie w Japonii.

## Kto zarabia na streamingu utworów?
 - [https://forsal.pl/lifestyle/rozrywka/artykuly/8719322,kto-zarabia-krocie-na-streamingu-utworow.html](https://forsal.pl/lifestyle/rozrywka/artykuly/8719322,kto-zarabia-krocie-na-streamingu-utworow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 07:20:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FafktkuTURBXy81NTJmZjVhYS1jN2UwLTQyYjItYTdhMi1iMmY4Y2I0YmE3ZGYuanBlZ5GTBc0BHcyg" />Kto zarabia na streamingu utworów? Głównie wydawcy nagrań i autorzy piosenek. Pomijani do tej pory wykonawcy twierdzą, że pieniądze należą się także im.

## Dedolaryzacja światowej gospodarki. Realne zagrożenie czy finansowa fikcja?
 - [https://forsal.pl/finanse/waluty/artykuly/8719326,dedolaryzacja-swiatowej-gospodarki-realne-zagrozenie-czy-finansowa-fikcja.html](https://forsal.pl/finanse/waluty/artykuly/8719326,dedolaryzacja-swiatowej-gospodarki-realne-zagrozenie-czy-finansowa-fikcja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 06:17:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wFIktkuTURBXy9iNmU0MTIxYy01ZDJmLTQ0NjAtODI3OS1hYmJmNzhjOTIzMzguanBlZ5GTBc0BHcyg" />Współczesny świat ma wiele kolektywnych lęków i neuroz. Globalne ocieplenie, możliwa wojna atomowa, wymknięcie się sztucznej inteligencji spod ludzkiego panowania… Ekonomiści (zachodni) dodają do tej listy jeszcze jedną obawę – dedolaryzację światowej gospodarki.

## Egzamin ósmoklasisty 2023: Harmonogram, wymagania, arkusze CKE i terminy
 - [https://forsal.pl/lifestyle/edukacja/artykuly/8719335,egzamin-osmoklasisty-2023-harmonogram-wymagania-arkusze-cke-i-terminy.html](https://forsal.pl/lifestyle/edukacja/artykuly/8719335,egzamin-osmoklasisty-2023-harmonogram-wymagania-arkusze-cke-i-terminy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-21 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YpEktkuTURBXy82NDBjMWY3Yi03ZDU1LTQ3YjUtYjE1Ni0xYmJhMmExODIyOWIuanBlZ5GTBc0BHcyg" />Kiedy dokładnie odbędzie się egzamin ósmoklasisty 2023? Ile czasu zdający będą mieli na rozwiązanie arkuszy? Gdzie szukać wymagań egzaminacyjnych i arkuszy CKE? Poniżej znajdziesz wszystko, co musisz wiedzieć o egzaminie ósmoklasisty 2023.

