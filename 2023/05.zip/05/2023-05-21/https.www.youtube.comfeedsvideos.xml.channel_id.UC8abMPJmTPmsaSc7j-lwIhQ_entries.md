# Source:Nineteenth century videos. Back to life., URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ, language:en-US

## [4K, 60 fps, colorized] (1901) Preston Egg Rolling.
 - [https://www.youtube.com/watch?v=rTVuihAFDe0](https://www.youtube.com/watch?v=rTVuihAFDe0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ
 - date published: 2023-05-21 21:01:40+00:00

Egg Rolling is a big Easter tradition, going back over 150 years, that takes place on Avenham and Miller Parks in Preston every Easter Monday. 

No visit to Preston's Egg rolling is complete without bringing your own Easter egg and rolling it down the hill with hundreds of other people. You can find a quiet spot and roll with the family or join in with the official egg rolls on the hour. 

It may sound wacky and exciting but that's because it is! With each year differing from the next, you never know what to expect. You are, however, guaranteed a great Easter Monday out.


Join as a member to support this channel:
https://www.youtube.com/channel/UC8abMPJmTPmsaSc7j-lwIhQ/join

Music: Mozart, K239

