# Source:Le Monde, URL:https://www.lemonde.fr/en/rss/une.xml, language:en-US

## Axiom Space successfully launches second private flight to space station
 - [https://www.lemonde.fr/en/economy/article/2023/05/21/axiom-space-successfully-launches-second-private-flight-to-space-station_6027495_19.html](https://www.lemonde.fr/en/economy/article/2023/05/21/axiom-space-successfully-launches-second-private-flight-to-space-station_6027495_19.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 21:51:51+00:00

On Sunday, May 21, at 5:37 pm (11:37 pm Paris time), a SpaceX Dragon spacecraft chartered by Axiom Space took a four-person crew from Cape Canaveral to the International Space Station, where they will stay for about 10 days.

## Ligue 1: PSG all but secures league title with 2-1 victory at Auxerre
 - [https://www.lemonde.fr/en/sports/article/2023/05/21/ligue-1-psg-all-but-secure-league-title-with-2-1-victory-at-auxerre_6027493_9.html](https://www.lemonde.fr/en/sports/article/2023/05/21/ligue-1-psg-all-but-secure-league-title-with-2-1-victory-at-auxerre_6027493_9.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 21:17:38+00:00

Two goals from Kylian Mbappé were enough to give PSG the win but not enough to secure a second straight Ligue 1 title with second-place Lens defeating Lorient earlier in the day.

## Greek elections: Conservative Prime Minister Mitsotakis claims landslide victory, seeks supermajority
 - [https://www.lemonde.fr/en/elections/article/2023/05/21/greek-elections-conservative-prime-minister-mitsotakis-celebrates-big-win-but-wants-supermajority_6027490_84.html](https://www.lemonde.fr/en/elections/article/2023/05/21/greek-elections-conservative-prime-minister-mitsotakis-celebrates-big-win-but-wants-supermajority_6027490_84.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 20:30:46+00:00

Greek Prime Minister Kyriakos Mitsotakis, whose conservative party has a 20-point lead ahead of his nearest rival with 82% of the vote counted, doesn't have enough parliamentary seats to form a government. He indicated he will seek a second election hoping to consolidate his victory without the need of a coalition partner.

## Video investigation: How Russia staged fake anti-Ukraine protests in Paris, Brussels and The Hague
 - [https://www.lemonde.fr/en/international/video/2023/05/21/video-investigation-how-russia-staged-fake-anti-ukraine-protests-in-paris-brussels-and-the-hague_6027484_4.html](https://www.lemonde.fr/en/international/video/2023/05/21/video-investigation-how-russia-staged-fake-anti-ukraine-protests-in-paris-brussels-and-the-hague_6027484_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 17:30:10+00:00

Documents obtained by Le Monde and its partners show how fake demonstrators were recruited and paid to protest against Ukraine and NATO in major European cities. An operation organized by the Russian intelligence services.

## Zelensky, the G7's surprise guest, upsets summit agenda
 - [https://www.lemonde.fr/en/international/article/2023/05/21/surprise-guest-zelensky-upsets-g7-agenda_6027477_4.html](https://www.lemonde.fr/en/international/article/2023/05/21/surprise-guest-zelensky-upsets-g7-agenda_6027477_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 16:11:13+00:00

After his invitation to the Arab League Summit, the Ukrainian president expanded his diplomatic contacts with leaders of the Global South.

## French left's favorite radical MP prepares for the post-Mélenchon era
 - [https://www.lemonde.fr/en/france/article/2023/05/21/french-left-s-favorite-radical-mp-prepares-for-the-post-melenchon-era_6027473_7.html](https://www.lemonde.fr/en/france/article/2023/05/21/french-left-s-favorite-radical-mp-prepares-for-the-post-melenchon-era_6027473_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 14:35:37+00:00

Visibly keen to remain loyal to the founder of the radical left party La France Insoumise and expand the left electorate, François Ruffin appears determined to come up with a plan for the 2027 presidential election.

## 'Killers of the Flower Moon', Martin Scorsese on the bloodied land of the Osage tribe
 - [https://www.lemonde.fr/en/culture/article/2023/05/21/killers-of-the-flower-moon-martin-scorsese-on-the-bloodied-land-of-the-osage-tribe_6027469_30.html](https://www.lemonde.fr/en/culture/article/2023/05/21/killers-of-the-flower-moon-martin-scorsese-on-the-bloodied-land-of-the-osage-tribe_6027469_30.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 14:17:12+00:00

Adapted from the book of the same name by journalist David Grann, Scorsese's new film depicts a series of murders committed among members of the Osage Nation in the 1920s.

## Vegan beauty: Marketing ploy or real progress?
 - [https://www.lemonde.fr/en/lifestyle/article/2023/05/21/vegan-beauty-marketing-ploy-or-real-progress_6027467_37.html](https://www.lemonde.fr/en/lifestyle/article/2023/05/21/vegan-beauty-marketing-ploy-or-real-progress_6027467_37.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 13:00:08+00:00

The vegan cosmetics label is flourishing without the consumer always really understanding its meaning. All the more so as the sector struggles to do without certain animal-derived ingredients.

## German police probe suspected poisoning of Russian exiles following Berlin meeting
 - [https://www.lemonde.fr/en/europe/article/2023/05/21/german-police-probe-suspected-poisoning-of-russian-exiles-following-berlin-meeting_6027466_143.html](https://www.lemonde.fr/en/europe/article/2023/05/21/german-police-probe-suspected-poisoning-of-russian-exiles-following-berlin-meeting_6027466_143.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 12:57:22+00:00

Police are investigating the possible poisoning of Russian dissidents after a journalist and an activist reported health problems following a Berlin meeting.

## Three shot dead in Marseille as gang murders surge
 - [https://www.lemonde.fr/en/france/article/2023/05/21/three-shot-dead-in-marseille-as-gang-murders-surge_6027464_7.html](https://www.lemonde.fr/en/france/article/2023/05/21/three-shot-dead-in-marseille-as-gang-murders-surge_6027464_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 12:02:03+00:00

The number of drug-related homicides amounts to 21 in the French port city since the start of the year, according to an AFP count.

## Macron arrives for first visit to Mongolia
 - [https://www.lemonde.fr/en/france/article/2023/05/21/macron-arrives-for-first-visit-to-mongolia_6027462_7.html](https://www.lemonde.fr/en/france/article/2023/05/21/macron-arrives-for-first-visit-to-mongolia_6027462_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 11:49:03+00:00

Since the Russian invasion of Ukraine in February 2022, France has stepped up its efforts to speak with countries who have not explicitly condemned it – of which Mongolia is one.

## Greek PM Mitsotakis seeks second term playing on a 'me or chaos' strategy
 - [https://www.lemonde.fr/en/international/article/2023/05/21/greek-pm-mitsotakis-seeks-second-term-playing-on-a-me-or-chaos-strategy_6027458_4.html](https://www.lemonde.fr/en/international/article/2023/05/21/greek-pm-mitsotakis-seeks-second-term-playing-on-a-me-or-chaos-strategy_6027458_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 11:40:39+00:00

The head of the conservative government will face re-election against left-wing leader Alexis Tsipras, who is highlighting the 'many wounds' in Greek society.

## Biden says 'looking' at invoking constitutional power to avoid US default
 - [https://www.lemonde.fr/en/international/article/2023/05/21/biden-says-looking-at-invoking-constitutional-power-to-avoid-us-default_6027457_4.html](https://www.lemonde.fr/en/international/article/2023/05/21/biden-says-looking-at-invoking-constitutional-power-to-avoid-us-default_6027457_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 11:26:29+00:00

The US government could default on its $31 trillion debt on June 1 if Congress does not authorize more borrowing.

## Too fast, too soon? Sweden backs away from screens in schools
 - [https://www.lemonde.fr/en/health/article/2023/05/21/too-fast-too-soon-sweden-backs-away-from-screens-in-schools_6027454_14.html](https://www.lemonde.fr/en/health/article/2023/05/21/too-fast-too-soon-sweden-backs-away-from-screens-in-schools_6027454_14.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 10:50:06+00:00

Based on doctors' advice, the center-right government wants to reduce the amount of time students spend in front of screens and bring textbooks back into the classroom.

## Wagner and Putin claim the capture of Bakhmut, a city reduced to rubble
 - [https://www.lemonde.fr/en/international/article/2023/05/21/bakhmut-wagner-and-putin-claim-the-capture-of-a-city-reduced-to-rubble_6027450_4.html](https://www.lemonde.fr/en/international/article/2023/05/21/bakhmut-wagner-and-putin-claim-the-capture-of-a-city-reduced-to-rubble_6027450_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 09:34:49+00:00

The boss of the Wagner mercenary group said on Saturday the city 'has been taken in its entirety.' Kyiv said its soldiers still control some areas on the outskirts, but that the situation was 'critical.'

## Israel far-right minister visits al-Aqsa Mosque compound once again
 - [https://www.lemonde.fr/en/international/article/2023/05/21/israel-far-right-minister-visits-al-aqsa-mosque-compound-once-again_6027447_4.html](https://www.lemonde.fr/en/international/article/2023/05/21/israel-far-right-minister-visits-al-aqsa-mosque-compound-once-again_6027447_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 08:41:59+00:00

The move came three days after Itamar Ben-Gvir and tens of thousands of Jewish nationalists marched through the Old City.

## In Addis Ababa, residents are being sacrificed on the altar of development
 - [https://www.lemonde.fr/en/international/article/2023/05/21/in-addis-ababa-residents-are-being-sacrificed-on-the-altar-of-development_6027444_4.html](https://www.lemonde.fr/en/international/article/2023/05/21/in-addis-ababa-residents-are-being-sacrificed-on-the-altar-of-development_6027444_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 08:00:06+00:00

The Ethiopian capital and its suburbs are being forcibly transformed, displacing small farmers and poor populations.

## Zelensky appears to confirm Bakhmut loss, saying 'nothing left'
 - [https://www.lemonde.fr/en/international/article/2023/05/21/zelensky-appears-to-confirm-bakhmut-loss-saying-nothing-left_6027437_4.html](https://www.lemonde.fr/en/international/article/2023/05/21/zelensky-appears-to-confirm-bakhmut-loss-saying-nothing-left_6027437_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 06:35:28+00:00

Russian President Vladimir Putin late Saturday congratulated the Wagner mercenary group and the national army on their claimed capture of the east Ukrainian city.

## NBA: Nuggets beat the Lakers to take a commanding 3-0 series lead
 - [https://www.lemonde.fr/en/sports/article/2023/05/21/nba-nuggets-beat-the-lakers-to-take-a-commanding-3-0-series-lead_6027435_9.html](https://www.lemonde.fr/en/sports/article/2023/05/21/nba-nuggets-beat-the-lakers-to-take-a-commanding-3-0-series-lead_6027435_9.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 03:33:25+00:00

After claiming back-to-back victories at home in games one and two, Denver delivered a performance of ruthless precision to dispatch LeBron James and the 17-time champion Lakers in LA.

## Turkey: The opposition's dangerous shift to the right
 - [https://www.lemonde.fr/en/turkey/article/2023/05/21/turkey-the-opposition-s-dangerous-shift-to-the-right_6027428_219.html](https://www.lemonde.fr/en/turkey/article/2023/05/21/turkey-the-opposition-s-dangerous-shift-to-the-right_6027428_219.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 03:09:12+00:00

Ahead of the presidential runoff election on May 28, Kemal Kiliçdaroglu has taken a strategic shift towards the right to appeal to nationalist voters.

## Sudan: Warring factions agree to new short-term ceasefire
 - [https://www.lemonde.fr/en/international/article/2023/05/21/sudan-warring-factions-agree-to-new-short-term-ceasefire_6027426_4.html](https://www.lemonde.fr/en/international/article/2023/05/21/sudan-warring-factions-agree-to-new-short-term-ceasefire_6027426_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 01:16:25+00:00

US and Saudi mediators helped secure a seven-day ceasefire that is due to take effect on Monday.

## Homophobia: 'A portion of the French football governing bodies doesn't want to tackle the issue head-on'
 - [https://www.lemonde.fr/en/sports/article/2023/05/21/homophobia-a-portion-of-the-french-football-governing-bodies-doesn-t-want-to-tackle-the-issue-head-on_6027422_9.html](https://www.lemonde.fr/en/sports/article/2023/05/21/homophobia-a-portion-of-the-french-football-governing-bodies-doesn-t-want-to-tackle-the-issue-head-on_6027422_9.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 01:04:35+00:00

In his book and upcoming documentary series, Ouissem Belgacem shares his experience of how his homosexuality hindered his path to a professional football career.

## 'Taiwan's exclusion from the WHO raises questions about the organization's independence from Beijing'
 - [https://www.lemonde.fr/en/opinion/article/2023/05/21/taiwan-s-exclusion-from-the-who-raises-questions-about-the-organization-s-independence-from-beijing_6027419_23.html](https://www.lemonde.fr/en/opinion/article/2023/05/21/taiwan-s-exclusion-from-the-who-raises-questions-about-the-organization-s-independence-from-beijing_6027419_23.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 00:02:49+00:00

As the World Health Assembly is being held from May 21 to 30, international relations specialist Vincent Rollet highlights Taiwan's vital role in global health and challenges the WHO's exclusionary stance.

## In Chile, a publishing house has changed the face of children's literature
 - [https://www.lemonde.fr/en/international/article/2023/05/21/in-chile-a-publishing-house-has-changed-the-face-of-children-s-literature_6027418_4.html](https://www.lemonde.fr/en/international/article/2023/05/21/in-chile-a-publishing-house-has-changed-the-face-of-children-s-literature_6027418_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-05-21 00:00:07+00:00

For more than 20 years, Amanuta has been publishing intelligent, innovative and regionally specific works, raising the bar in the sector.

