# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## This Week in Warhammer – All Part of the Great Plan
 - [https://www.youtube.com/watch?v=_mKq_tC9uos](https://www.youtube.com/watch?v=_mKq_tC9uos)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-05-21 17:00:15+00:00

It's all about the lizards and wizards! Check out this week's Warhammer highlights. https://bit.ly/3oodVoG

