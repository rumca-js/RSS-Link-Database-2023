# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Brooks Koepka wins PGA Championship
 - [https://abcnews.go.com/Sports/wireStory/brooks-koepka-wins-pga-championship-major-title-99496072](https://abcnews.go.com/Sports/wireStory/brooks-koepka-wins-pga-championship-major-title-99496072)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 23:19:23+00:00

Brooks Koepka wins the PGA Championship for his fifth major title.

## 2 killed when plane headed for Hawaii crashes off Northern California
 - [https://abcnews.go.com/US/wireStory/2-killed-plane-headed-hawaii-crashes-pacific-ocean-99494080](https://abcnews.go.com/US/wireStory/2-killed-plane-headed-hawaii-crashes-pacific-ocean-99494080)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 20:54:03+00:00

Authorities say two people were killed when a small plane headed for Hawaii crashed in the Pacific Ocean shortly after takeoff from Northern California

## Berlin police investigate report of Russian exiles falling ill
 - [https://abcnews.go.com/International/wireStory/berlin-police-investigate-report-russian-exiles-falling-ill-99493631](https://abcnews.go.com/International/wireStory/berlin-police-investigate-report-russian-exiles-falling-ill-99493631)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 19:33:50+00:00

The  conference was linked to a Russian opposition figure.

## France pension protest held on outskirts of Cannes Film Festival
 - [https://abcnews.go.com/International/wireStory/france-pension-protest-held-outskirts-cannes-film-festival-99492994](https://abcnews.go.com/International/wireStory/france-pension-protest-held-outskirts-cannes-film-festival-99492994)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 17:02:25+00:00

Though protests over pension reforms have roiled France in recent months, demonstrations have been kept largely at bay at one of the country&rsquo;s glitziest events, the Cannes Film Festival

## Soccer stadium stampede in El Salvador leaves 12 dead
 - [https://abcnews.go.com/International/wireStory/soccer-stadium-stampede-el-salvador-leaves-12-dead-99491462](https://abcnews.go.com/International/wireStory/soccer-stadium-stampede-el-salvador-leaves-12-dead-99491462)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 17:02:21+00:00

Officials and witnesses say that fans angry at being blocked from entering a Salvadoran soccer league match knocked down an entrance gate to the stadium, leading to a crush that left at least 12 people dead and dozens injured

## New trial ordered for man who spent 15 years on death row in death of 3-year-old boy
 - [https://abcnews.go.com/US/wireStory/new-trial-ordered-man-spent-15-years-death-99492988](https://abcnews.go.com/US/wireStory/new-trial-ordered-man-spent-15-years-death-99492988)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 17:02:11+00:00

A new trial has been ordered for a man who spent more than a decade and a half on Ohio&rsquo;s death row in the 2006 death of the 3-year-old son of his former live-in girlfriend

## Civil rights groups warn tourists about Florida in wake of 'hostile' laws
 - [https://abcnews.go.com/Business/wireStory/civil-rights-groups-warn-tourists-florida-wake-hostile-99492203](https://abcnews.go.com/Business/wireStory/civil-rights-groups-warn-tourists-florida-wake-hostile-99492203)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 16:54:58+00:00

The NAACP over the weekend issued a travel advisory for Florida, joining two other civil rights groups in warning potential tourists that recent laws championed by Gov_ Ron DeSantis and Florida lawmakers are &ldquo;openly hostile toward African Americans, pe...

## Biden looks to deal directly with McCarthy on debt limit as speaker slams tax comment
 - [https://abcnews.go.com/Politics/biden-negotiate-directly-mccarthy-debt-ceiling-republicans-move/story?id=99490207](https://abcnews.go.com/Politics/biden-negotiate-directly-mccarthy-debt-ceiling-republicans-move/story?id=99490207)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 16:46:42+00:00

Biden on Sunday hammered Republicans over what he called "extreme positions" on raising the debt ceiling as the nation careens toward a potentially catastrophic default

## 19 shot, 10 fatally, at car rally less than 100 miles from Mexico-US border
 - [https://abcnews.go.com/International/19-shot-10-fatally-car-rally-100-miles/story?id=99489832](https://abcnews.go.com/International/19-shot-10-fatally-car-rally-100-miles/story?id=99489832)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 16:27:02+00:00

At least 10 people were killed and nine were wounded when an apparent team of gunmen ambushed a car rally in Baja, Mexico, authorities said.

## Mount Etna volcano erupts, raining ash on Catania, forcing flight suspension
 - [https://abcnews.go.com/Technology/wireStory/mount-etna-volcano-erupts-raining-ash-catania-forcing-99490256](https://abcnews.go.com/Technology/wireStory/mount-etna-volcano-erupts-raining-ash-catania-forcing-99490256)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 15:02:05+00:00

Mount Etna, Europe's most active volcano, is erupting, spewing ash on Catania, eastern Sicily's largest city, and forcing suspension of flights at that city's airport

## WATCH:  Bee appears to 'wave' at toddler
 - [https://abcnews.go.com/Lifestyle/video/bee-appears-wave-toddler-99490877](https://abcnews.go.com/Lifestyle/video/bee-appears-wave-toddler-99490877)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 14:59:31+00:00

A 2-year-old in Ireland was initially nervous of a bee until the bee appeared to "wave" goodbye back to the child.

## WATCH:  Tree burns after lightning strike in Florida
 - [https://abcnews.go.com/US/video/tree-burns-after-lightning-strike-florida-99490876](https://abcnews.go.com/US/video/tree-burns-after-lightning-strike-florida-99490876)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 14:59:07+00:00

A lightning strike set a tree on fire outside a Florida home that had livestock. No animals were injured from the severe thunderstorms, the home's owner said.

## Animal rights activists protest octopus farm plans in Spain
 - [https://abcnews.go.com/International/wireStory/animal-rights-activists-protest-octopus-farm-plans-spain-99489234](https://abcnews.go.com/International/wireStory/animal-rights-activists-protest-octopus-farm-plans-spain-99489234)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 14:06:20+00:00

Animal rights activists have gathered in Madrid to protest plans for the construction of a large-scale octopus farm

## Biden: No debt limit deal solely on its 'partisan terms'
 - [https://abcnews.go.com/Business/wireStory/biden-gop-move-off-extreme-positions-debt-limit-99488065](https://abcnews.go.com/Business/wireStory/biden-gop-move-off-extreme-positions-debt-limit-99488065)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 14:06:11+00:00

President Joe Biden says Republicans in the U.S. House must move off their &ldquo;extreme positions&rdquo; on the now-stalled talks over raising America&rsquo;s debt limit

## Afghan ministry says helicopter crash kills 2 crewmembers during patrol in country's north
 - [https://abcnews.go.com/International/wireStory/afghan-ministry-helicopter-crash-kills-2-crewmembers-patrol-99488288](https://abcnews.go.com/International/wireStory/afghan-ministry-helicopter-crash-kills-2-crewmembers-patrol-99488288)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 12:06:16+00:00

The Ministry of Defense says an Afghan military helicopter crashed in the country&rsquo;s north after hitting a power line base, killing at least two crewmembers

## Extremist Israeli Cabinet minister visits sensitive Jerusalem holy site
 - [https://abcnews.go.com/International/wireStory/extremist-israel-cabinet-minister-visits-sensitive-jerusalem-holy-99487830](https://abcnews.go.com/International/wireStory/extremist-israel-cabinet-minister-visits-sensitive-jerusalem-holy-99487830)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 12:06:16+00:00

An extremist Israeli Cabinet minister has visited a sensitive Jerusalem holy site at a time of heightened tensions with the Palestinians

## 3 dead in Kansas City lounge shooting
 - [https://abcnews.go.com/US/3-dead-kansas-city-lounge-shooting/story?id=99487967](https://abcnews.go.com/US/3-dead-kansas-city-lounge-shooting/story?id=99487967)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 10:03:51+00:00

Five people were shot, including three of them fatally, when a gunman opened fire at the Klymax Lounge in Kansas City, Missouri, early Sunday, police said.

## Alabama police: 4 people wounded in exchange of gunfire outside Birmingham bar
 - [https://abcnews.go.com/US/wireStory/alabama-police-4-people-wounded-exchange-gunfire-birmingham-99487957](https://abcnews.go.com/US/wireStory/alabama-police-4-people-wounded-exchange-gunfire-birmingham-99487957)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 09:02:30+00:00

Four people were shot and wounded outside an Alabama bar early Sunday in what police described as an exchange of gunfire

## Zelenskyy: 'Bakhmut is only in our hearts' after Ukraine loses control of destroyed city to Russia
 - [https://abcnews.go.com/Business/wireStory/zelenskyy-bakhmut-hearts-after-ukraine-loses-control-destroyed-99487831](https://abcnews.go.com/Business/wireStory/zelenskyy-bakhmut-hearts-after-ukraine-loses-control-destroyed-99487831)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 08:06:15+00:00

Ukrainian President Volodymyr Zelenskyy says that he believes that Russia has taken control of the eastern city of Bakhmut

## Using 'he/him,' 'she/her' in emails got 2 dorm directors fired at small New York Christian college
 - [https://abcnews.go.com/US/wireStory/hehim-sheher-emails-2-dorm-directors-fired-small-99487176](https://abcnews.go.com/US/wireStory/hehim-sheher-emails-2-dorm-directors-fired-small-99487176)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 05:09:51+00:00

The firing of two employees at a religious school in western New York is fanning the culture wars roiling parts of the United States

## Polls open in Greece's first election since international bailout spending controls ended
 - [https://abcnews.go.com/International/wireStory/polls-open-greeces-election-international-bailout-spending-controls-99486990](https://abcnews.go.com/International/wireStory/polls-open-greeces-election-international-bailout-spending-controls-99486990)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 05:00:33+00:00

Polls open in Greece's first election since international bailout spending controls ended

## Biden to call McCarthy to discuss debt ceiling after G7 summit
 - [https://abcnews.go.com/Politics/biden-call-mccarthy-discuss-debt-ceiling-after-g7/story?id=99459051](https://abcnews.go.com/Politics/biden-call-mccarthy-discuss-debt-ceiling-after-g7/story?id=99459051)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 02:34:19+00:00

There are no meetings currently scheduled for Saturday between White House and GOP negotiators, multiple sources familiar with the matter told ABC News.

## Lawsuit alleges supervisor at homebuilding company brought noose to staff meeting
 - [https://abcnews.go.com/US/lawsuit-alleges-supervisor-homebuilding-company-brought-noose-staff/story?id=99483413](https://abcnews.go.com/US/lawsuit-alleges-supervisor-homebuilding-company-brought-noose-staff/story?id=99483413)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-21 01:32:45+00:00

A lawsuit alleges a homebuilding company discriminated against three Black employees, one of whom reportedly attended a meeting where a noose was displayed.

