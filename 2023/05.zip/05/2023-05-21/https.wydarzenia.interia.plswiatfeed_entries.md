# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Prigożyn kpi z generała Szojgu. Złożył mu ironiczne życzenia urodzinowe
 - [https://wydarzenia.interia.pl/zagranica/news-prigozyn-kpi-z-generala-szojgu-zlozyl-mu-ironiczne-zyczenia-,nId,6791743](https://wydarzenia.interia.pl/zagranica/news-prigozyn-kpi-z-generala-szojgu-zlozyl-mu-ironiczne-zyczenia-,nId,6791743)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-05-21 17:30:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prigozyn-kpi-z-generala-szojgu-zlozyl-mu-ironiczne-zyczenia-,nId,6791743"><img align="left" alt="Prigożyn kpi z generała Szojgu. Złożył mu ironiczne życzenia urodzinowe" src="https://i.iplsc.com/prigozyn-kpi-z-generala-szojgu-zlozyl-mu-ironiczne-zyczenia/000H6IHBL8EA76C4-C321.jpg" /></a>Założyciel Grupy Wagnera Jewgienij Prigożyn opublikował list z życzeniami urodzinowymi dla ministra obrony Federacji Rosyjskiej Siergieja Szojgu. W tekście &quot;Kucharz Putina&quot; kilkukrotnie wyśmiał rosyjskiego generała.</p><br clear="all" />

## Włochy: Czarna woda w fontannie di Trevi. To akcja aktywistów
 - [https://wydarzenia.interia.pl/zagranica/news-wlochy-czarna-woda-w-fontannie-di-trevi-to-akcja-aktywistow,nId,6791656](https://wydarzenia.interia.pl/zagranica/news-wlochy-czarna-woda-w-fontannie-di-trevi-to-akcja-aktywistow,nId,6791656)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-05-21 11:49:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlochy-czarna-woda-w-fontannie-di-trevi-to-akcja-aktywistow,nId,6791656"><img align="left" alt="Włochy: Czarna woda w fontannie di Trevi. To akcja aktywistów" src="https://i.iplsc.com/wlochy-czarna-woda-w-fontannie-di-trevi-to-akcja-aktywistow/000H6H1ZDLWR7LGG-C321.jpg" /></a>&quot;Nasz kraj umiera&quot; - takie okrzyki słychać było dziś przy Fontannie di Trevi w Rzymie. Grupa kilku aktywistów wlała do słynnego włoskiego zabytku czarny barwnik i weszła do wody, by zwrócić uwagę władz na zmiany klimatyczne. To kolejna taka akcja w Wiecznym Mieście. </p><br clear="all" />

