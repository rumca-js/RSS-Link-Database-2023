# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Conservative Issues Dire Warning About Impact of Christian Nationalism
 - [http://www.msn.com/en-us/news/politics/conservative-issues-dire-warning-about-impact-of-christian-nationalism/ar-AA1buAgt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/conservative-issues-dire-warning-about-impact-of-christian-nationalism/ar-AA1buAgt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 23:14:52.808194+00:00



## Biden Plans to Thaw and Diversify Relationship With China
 - [http://www.msn.com/en-us/news/politics/biden-plans-to-thaw-and-diversify-relationship-with-china/vi-AA1bunTC?srcref=rss](http://www.msn.com/en-us/news/politics/biden-plans-to-thaw-and-diversify-relationship-with-china/vi-AA1bunTC?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 23:14:52.800521+00:00



## Reporter's Notebook: Will the US provide F-16s to support Ukraine?
 - [http://www.msn.com/en-us/news/world/reporter-s-notebook-will-the-us-provide-f-16s-to-support-ukraine/ar-AA1buAfg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/reporter-s-notebook-will-the-us-provide-f-16s-to-support-ukraine/ar-AA1buAfg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 23:14:52.791514+00:00



## Trump tears into ‘The View’ co-host, ex-aide Alyssa Farah Griffin in online tirade: A 'sleazebag' and 'loser'
 - [http://www.msn.com/en-us/news/politics/trump-tears-into-the-view-co-host-ex-aide-alyssa-farah-griffin-in-online-tirade-a-sleazebag-and-loser/ar-AA1bunOk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-tears-into-the-view-co-host-ex-aide-alyssa-farah-griffin-in-online-tirade-a-sleazebag-and-loser/ar-AA1bunOk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 23:14:52.782358+00:00



## Celebration at California dance ballroom a sign of healing following Lunar New Year shooting
 - [http://www.msn.com/en-us/news/crime/celebration-at-california-dance-ballroom-a-sign-of-healing-following-lunar-new-year-shooting/ar-AA1buAoN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/celebration-at-california-dance-ballroom-a-sign-of-healing-following-lunar-new-year-shooting/ar-AA1buAoN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 23:14:52.769746+00:00



## American imprisoned in Russia calls CNN to push for his release
 - [http://www.msn.com/en-us/news/world/american-imprisoned-in-russia-calls-cnn-to-push-for-his-release/ar-AA1butz2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/american-imprisoned-in-russia-calls-cnn-to-push-for-his-release/ar-AA1butz2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 23:14:52.761989+00:00



## House avoids sacking George Santos: For good reason?
 - [http://www.msn.com/en-us/news/politics/house-avoids-sacking-george-santos-for-good-reason/ar-AA1buy1J?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-avoids-sacking-george-santos-for-good-reason/ar-AA1buy1J?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 23:14:52.754444+00:00



## Conservative party of Greek prime minister in big election lead, to seek outright majority
 - [http://www.msn.com/en-us/news/world/conservative-party-of-greek-prime-minister-in-big-election-lead-to-seek-outright-majority/ar-AA1bulcm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/conservative-party-of-greek-prime-minister-in-big-election-lead-to-seek-outright-majority/ar-AA1bulcm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 22:14:49.589966+00:00



## Warner CEO booed at Boston University as supporters of writers' strike picket outside
 - [http://www.msn.com/en-us/news/us/warner-ceo-booed-at-boston-university-as-supporters-of-writers-strike-picket-outside/ar-AA1buxgT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/warner-ceo-booed-at-boston-university-as-supporters-of-writers-strike-picket-outside/ar-AA1buxgT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 22:14:49.582128+00:00



## Ivanka Trump looks cool in a summer dress as she takes a stroll with her son Joseph in Miami
 - [http://www.msn.com/en-us/news/politics/ivanka-trump-looks-cool-in-a-summer-dress-as-she-takes-a-stroll-with-her-son-joseph-in-miami/ar-AA1buuWy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ivanka-trump-looks-cool-in-a-summer-dress-as-she-takes-a-stroll-with-her-son-joseph-in-miami/ar-AA1buuWy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 22:14:49.574167+00:00



## School choice won big in states this year. Is the movement about to hit a wall?
 - [http://www.msn.com/en-us/news/politics/school-choice-won-big-in-states-this-year-is-the-movement-about-to-hit-a-wall/ar-AA1buiZp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/school-choice-won-big-in-states-this-year-is-the-movement-about-to-hit-a-wall/ar-AA1buiZp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 22:14:49.566380+00:00



## McCarthy blames Biden for succumbing to progressive Dems in debt ceiling talks
 - [http://www.msn.com/en-us/news/politics/mccarthy-blames-biden-for-succumbing-to-progressive-dems-in-debt-ceiling-talks/ar-AA1bu6s8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccarthy-blames-biden-for-succumbing-to-progressive-dems-in-debt-ceiling-talks/ar-AA1bu6s8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 21:14:43.477009+00:00



## Dem. congressman calls 'No Labels' presidential run by Sen. Joe Manchin in a race against Biden and Trump a 'historic disaster'
 - [http://www.msn.com/en-us/news/politics/dem-congressman-calls-no-labels-presidential-run-by-sen-joe-manchin-in-a-race-against-biden-and-trump-a-historic-disaster/ar-AA1buijS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/dem-congressman-calls-no-labels-presidential-run-by-sen-joe-manchin-in-a-race-against-biden-and-trump-a-historic-disaster/ar-AA1buijS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 21:14:43.467063+00:00



## Shootout at Baja California car rally leaves 10 dead, 10 wounded
 - [http://www.msn.com/en-us/news/crime/shootout-at-baja-california-car-rally-leaves-10-dead-10-wounded/ar-AA1buejw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/shootout-at-baja-california-car-rally-leaves-10-dead-10-wounded/ar-AA1buejw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 21:14:43.458229+00:00



## Sunak says China is the ‘biggest challenge of our age to global security and prosperity’
 - [http://www.msn.com/en-us/news/world/sunak-says-china-is-the-biggest-challenge-of-our-age-to-global-security-and-prosperity/ar-AA1bung8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/sunak-says-china-is-the-biggest-challenge-of-our-age-to-global-security-and-prosperity/ar-AA1bung8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 21:14:43.449914+00:00



## A Royal Confusion: What Really Happened to Meghan Markle and Prince Harry During the Paparazzi Chase?
 - [http://www.msn.com/en-us/news/us/a-royal-confusion-what-really-happened-to-meghan-markle-and-prince-harry-during-the-paparazzi-chase/ar-AA1bul0a?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-royal-confusion-what-really-happened-to-meghan-markle-and-prince-harry-during-the-paparazzi-chase/ar-AA1bul0a?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 21:14:43.439621+00:00



## Watch: Biden Addresses the Debt Ceiling at G-7 Summit
 - [http://www.msn.com/en-us/news/politics/watch-biden-addresses-the-debt-ceiling-at-g-7-summit/vi-AA1budbG?srcref=rss](http://www.msn.com/en-us/news/politics/watch-biden-addresses-the-debt-ceiling-at-g-7-summit/vi-AA1budbG?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 20:14:32.388489+00:00



## Kansas City nightclub shooting leaves 3 dead, 2 injured
 - [http://www.msn.com/en-us/news/crime/kansas-city-nightclub-shooting-leaves-3-dead-2-injured/ar-AA1btkzC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/kansas-city-nightclub-shooting-leaves-3-dead-2-injured/ar-AA1btkzC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 20:14:32.378735+00:00



## Miami Mayor Francis Suarez dismisses some of DeSantis' recent immigration laws
 - [http://www.msn.com/en-us/news/politics/miami-mayor-francis-suarez-dismisses-some-of-desantis-recent-immigration-laws/ar-AA1bu3Vl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/miami-mayor-francis-suarez-dismisses-some-of-desantis-recent-immigration-laws/ar-AA1bu3Vl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 20:14:32.371428+00:00



## 'Exhaust them': Why Ukraine has fought Russia for every inch of Bakhmut, despite high cost
 - [http://www.msn.com/en-us/news/world/exhaust-them-why-ukraine-has-fought-russia-for-every-inch-of-bakhmut-despite-high-cost/ar-AA1bu3U4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/exhaust-them-why-ukraine-has-fought-russia-for-every-inch-of-bakhmut-despite-high-cost/ar-AA1bu3U4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 20:14:32.363929+00:00



## California Gov. Gavin Newsom demands records from textbook companies to see which are caving to Florida's 'extremist' demands
 - [http://www.msn.com/en-us/news/us/california-gov-gavin-newsom-demands-records-from-textbook-companies-to-see-which-are-caving-to-florida-s-extremist-demands/ar-AA1btRlD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/california-gov-gavin-newsom-demands-records-from-textbook-companies-to-see-which-are-caving-to-florida-s-extremist-demands/ar-AA1btRlD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 20:14:32.354695+00:00



## Russian invasion kills 42K Ukrainian civilians since start of war, US officials say
 - [http://www.msn.com/en-us/news/world/russian-invasion-kills-42k-ukrainian-civilians-since-start-of-war-us-officials-say/ar-AA1bui1t?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-invasion-kills-42k-ukrainian-civilians-since-start-of-war-us-officials-say/ar-AA1bui1t?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 20:14:32.345368+00:00



## Nunes says Durham report shows ‘total collapse of the justice system’
 - [http://www.msn.com/en-us/news/politics/nunes-says-durham-report-shows-total-collapse-of-the-justice-system/ar-AA1bus0n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/nunes-says-durham-report-shows-total-collapse-of-the-justice-system/ar-AA1bus0n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 20:14:32.336326+00:00



## Durham report: Graham says 'damning' findings show FBI tried to 'get a political outcome'
 - [http://www.msn.com/en-us/news/politics/durham-report-graham-says-damning-findings-show-fbi-tried-to-get-a-political-outcome/ar-AA1bucAj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/durham-report-graham-says-damning-findings-show-fbi-tried-to-get-a-political-outcome/ar-AA1bucAj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 19:14:43.026725+00:00



## Trans woman sues NYC yoga studio for $5 million after being told to leave women's locker room: 'Humiliation'
 - [http://www.msn.com/en-us/news/us/trans-woman-sues-nyc-yoga-studio-for-5-million-after-being-told-to-leave-women-s-locker-room-humiliation/ar-AA1bu3fk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/trans-woman-sues-nyc-yoga-studio-for-5-million-after-being-told-to-leave-women-s-locker-room-humiliation/ar-AA1bu3fk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 19:14:43.016678+00:00



## Biden and McCarthy to meet on Monday to negotiate directly on debt ceiling
 - [http://www.msn.com/en-us/news/politics/biden-and-mccarthy-to-meet-on-monday-to-negotiate-directly-on-debt-ceiling/ar-AA1btXqb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-and-mccarthy-to-meet-on-monday-to-negotiate-directly-on-debt-ceiling/ar-AA1btXqb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 19:14:43.009256+00:00



## Column: Robert De Niro compares villain of 'Killers of the Flower Moon' to Trump
 - [http://www.msn.com/en-us/news/us/column-robert-de-niro-compares-villain-of-killers-of-the-flower-moon-to-trump/ar-AA1bu0sJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/column-robert-de-niro-compares-villain-of-killers-of-the-flower-moon-to-trump/ar-AA1bu0sJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 19:14:43.001449+00:00



## A World Without Martin Amis
 - [http://www.msn.com/en-us/news/us/a-world-without-martin-amis/ar-AA1bucTW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-world-without-martin-amis/ar-AA1bucTW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 19:14:42.993974+00:00



## McCarthy says he'll meet with Biden Monday after 'productive' debt ceiling call
 - [http://www.msn.com/en-us/news/politics/mccarthy-says-he-ll-meet-with-biden-monday-after-productive-debt-ceiling-call/ar-AA1buaZR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccarthy-says-he-ll-meet-with-biden-monday-after-productive-debt-ceiling-call/ar-AA1buaZR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 19:14:42.986425+00:00



## Thune, No. 2 Senate Republican, set to endorse Tim Scott's presidential bid
 - [http://www.msn.com/en-us/news/politics/thune-no-2-senate-republican-set-to-endorse-tim-scott-s-presidential-bid/ar-AA1bub0D?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/thune-no-2-senate-republican-set-to-endorse-tim-scott-s-presidential-bid/ar-AA1bub0D?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 19:14:42.975858+00:00



## A call to arms: Defending America’s soul in an age of extremism
 - [http://www.msn.com/en-us/news/politics/a-call-to-arms-defending-america-s-soul-in-an-age-of-extremism/ar-AA1btR4f?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/a-call-to-arms-defending-america-s-soul-in-an-age-of-extremism/ar-AA1btR4f?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 19:14:42.967690+00:00



## Cruz blames Democrats for ‘wild spending binge’ despite Trump increases
 - [http://www.msn.com/en-us/news/politics/cruz-blames-democrats-for-wild-spending-binge-despite-trump-increases/ar-AA1bu4WY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/cruz-blames-democrats-for-wild-spending-binge-despite-trump-increases/ar-AA1bu4WY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 18:14:47.272169+00:00



## Kevin McCarthy to meet with Biden in person on Monday
 - [http://www.msn.com/en-us/news/politics/kevin-mccarthy-to-meet-with-biden-in-person-on-monday/ar-AA1bu7LG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kevin-mccarthy-to-meet-with-biden-in-person-on-monday/ar-AA1bu7LG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 18:14:47.264428+00:00



## GOP Rep. Confronted With Trump Flip-Flop on Debt Limit
 - [http://www.msn.com/en-us/news/politics/gop-rep-confronted-with-trump-flip-flop-on-debt-limit/ar-AA1bu32J?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-rep-confronted-with-trump-flip-flop-on-debt-limit/ar-AA1bu32J?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 18:14:47.256506+00:00



## Thousands of Afghans who worked for the US have made a perilous 16,000-mile journey to the US-Mexico border to seek asylum in the last year
 - [http://www.msn.com/en-us/news/world/thousands-of-afghans-who-worked-for-the-us-have-made-a-perilous-16-000-mile-journey-to-the-us-mexico-border-to-seek-asylum-in-the-last-year/ar-AA1btZZv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/thousands-of-afghans-who-worked-for-the-us-have-made-a-perilous-16-000-mile-journey-to-the-us-mexico-border-to-seek-asylum-in-the-last-year/ar-AA1btZZv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 18:14:47.248497+00:00



## 'SNL' star Kenan Thompson surprises Newport, RI police with coffee and donuts: 'Wicked nice'
 - [http://www.msn.com/en-us/news/us/snl-star-kenan-thompson-surprises-newport-ri-police-with-coffee-and-donuts-wicked-nice/ar-AA1btTT1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/snl-star-kenan-thompson-surprises-newport-ri-police-with-coffee-and-donuts-wicked-nice/ar-AA1btTT1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 18:14:47.239307+00:00



## WSJ Opinion: Hits and Misses of the Week
 - [http://www.msn.com/en-us/news/offbeat/wsj-opinion-hits-and-misses-of-the-week/vi-AA1btJ5g?srcref=rss](http://www.msn.com/en-us/news/offbeat/wsj-opinion-hits-and-misses-of-the-week/vi-AA1btJ5g?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 18:14:47.230111+00:00



## A 3-year-old in Indiana accidentally shot a man who was wanted for murder in another state, police say
 - [http://www.msn.com/en-us/news/crime/a-3-year-old-in-indiana-accidentally-shot-a-man-who-was-wanted-for-murder-in-another-state-police-say/ar-AA1bu5jb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-3-year-old-in-indiana-accidentally-shot-a-man-who-was-wanted-for-murder-in-another-state-police-say/ar-AA1bu5jb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 18:14:47.221896+00:00



## NAACP issues travel advisory for Florida over DeSantis’ ‘aggressive attempts to erase Black history’
 - [http://www.msn.com/en-us/news/us/naacp-issues-travel-advisory-for-florida-over-desantis-aggressive-attempts-to-erase-black-history/ar-AA1bu81X?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/naacp-issues-travel-advisory-for-florida-over-desantis-aggressive-attempts-to-erase-black-history/ar-AA1bu81X?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 18:14:47.213250+00:00



## The Debrief with David Mark: What will Republicans do about George Santos?
 - [http://www.msn.com/en-us/news/politics/the-debrief-with-david-mark-what-will-republicans-do-about-george-santos/ar-AA1btV27?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-debrief-with-david-mark-what-will-republicans-do-about-george-santos/ar-AA1btV27?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 17:14:42.646875+00:00



## France pension protest held on outskirts of Cannes Film Festival
 - [http://www.msn.com/en-us/news/world/france-pension-protest-held-on-outskirts-of-cannes-film-festival/ar-AA1btQ2w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/france-pension-protest-held-on-outskirts-of-cannes-film-festival/ar-AA1btQ2w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 17:14:42.639046+00:00



## A Dallas car dealership gifted a Jeep to a high school sophomore who never missed a day of school as a way to increase attendance
 - [http://www.msn.com/en-us/news/us/a-dallas-car-dealership-gifted-a-jeep-to-a-high-school-sophomore-who-never-missed-a-day-of-school-as-a-way-to-increase-attendance/ar-AA1btLpF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-dallas-car-dealership-gifted-a-jeep-to-a-high-school-sophomore-who-never-missed-a-day-of-school-as-a-way-to-increase-attendance/ar-AA1btLpF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 17:14:42.630846+00:00



## WSJ Opinion: Diversity, Equity and Inclusion Develops a Counter-Movement
 - [http://www.msn.com/en-us/news/offbeat/wsj-opinion-diversity-equity-and-inclusion-develops-a-counter-movement/vi-AA1bu9Po?srcref=rss](http://www.msn.com/en-us/news/offbeat/wsj-opinion-diversity-equity-and-inclusion-develops-a-counter-movement/vi-AA1bu9Po?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 17:14:42.622697+00:00



## My Friend, Tim Keller
 - [http://www.msn.com/en-us/news/us/my-friend-tim-keller/ar-AA1bu7rp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/my-friend-tim-keller/ar-AA1bu7rp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 17:14:42.613419+00:00



## Biden looks to deal directly with McCarthy on debt limit as speaker slams tax comment
 - [http://www.msn.com/en-us/news/politics/biden-looks-to-deal-directly-with-mccarthy-on-debt-limit-as-speaker-slams-tax-comment/ar-AA1btXqb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-looks-to-deal-directly-with-mccarthy-on-debt-limit-as-speaker-slams-tax-comment/ar-AA1btXqb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 17:14:42.605540+00:00



## The oldest, most complete Hebrew Bible that went missing for 600 years sells for a record $38 million
 - [http://www.msn.com/en-us/news/world/the-oldest-most-complete-hebrew-bible-that-went-missing-for-600-years-sells-for-a-record-38-million/ar-AA1btVqW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-oldest-most-complete-hebrew-bible-that-went-missing-for-600-years-sells-for-a-record-38-million/ar-AA1btVqW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 17:14:42.596233+00:00



## McCarthy says Biden call on debt limit ‘productive,’ leaders to meet Monday
 - [http://www.msn.com/en-us/news/politics/mccarthy-says-biden-call-on-debt-limit-productive-leaders-to-meet-monday/ar-AA1btXz7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccarthy-says-biden-call-on-debt-limit-productive-leaders-to-meet-monday/ar-AA1btXz7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 17:14:42.588505+00:00



## CNN Gives Uvalde Parents Access to Videos of Kids Escaping School Shooting
 - [http://www.msn.com/en-us/news/us/cnn-gives-uvalde-parents-access-to-videos-of-kids-escaping-school-shooting/ar-AA1btIfH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/cnn-gives-uvalde-parents-access-to-videos-of-kids-escaping-school-shooting/ar-AA1btIfH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 16:14:43.751415+00:00



## Moderate GOP lawmaker says there’s ‘wiggle room’ in debt default deadline
 - [http://www.msn.com/en-us/news/politics/moderate-gop-lawmaker-says-there-s-wiggle-room-in-debt-default-deadline/ar-AA1btUIp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/moderate-gop-lawmaker-says-there-s-wiggle-room-in-debt-default-deadline/ar-AA1btUIp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 16:14:43.742575+00:00



## Feminine hygiene dispenser in Oregon boys' bathroom found in toilet in apparent protest
 - [http://www.msn.com/en-us/news/us/feminine-hygiene-dispenser-in-oregon-boys-bathroom-found-in-toilet-in-apparent-protest/ar-AA1btzin?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/feminine-hygiene-dispenser-in-oregon-boys-bathroom-found-in-toilet-in-apparent-protest/ar-AA1btzin?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 16:14:43.734835+00:00



## China tells tech manufacturers to stop using Micron chips, stepping up feud with United States
 - [http://www.msn.com/en-us/news/world/china-tells-tech-manufacturers-to-stop-using-micron-chips-stepping-up-feud-with-united-states/ar-AA1btSxL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-tells-tech-manufacturers-to-stop-using-micron-chips-stepping-up-feud-with-united-states/ar-AA1btSxL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 16:14:43.727425+00:00



## Family of Chinatown woman stabbed to death by homeless career criminal sues New York City, NYPD officers
 - [http://www.msn.com/en-us/news/crime/family-of-chinatown-woman-stabbed-to-death-by-homeless-career-criminal-sues-new-york-city-nypd-officers/ar-AA1btzgB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/family-of-chinatown-woman-stabbed-to-death-by-homeless-career-criminal-sues-new-york-city-nypd-officers/ar-AA1btzgB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 16:14:43.717787+00:00



## Biden says Zelenskyy gave a 'flat assurance' that F-16s fighter jets wouldn't attack Russian territory as drastic policy shift takes shape
 - [http://www.msn.com/en-us/news/world/biden-says-zelenskyy-gave-a-flat-assurance-that-f-16s-fighter-jets-wouldn-t-attack-russian-territory-as-drastic-policy-shift-takes-shape/ar-AA1btL3y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/biden-says-zelenskyy-gave-a-flat-assurance-that-f-16s-fighter-jets-wouldn-t-attack-russian-territory-as-drastic-policy-shift-takes-shape/ar-AA1btL3y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 16:14:43.709607+00:00



## Wes Moore calls out politicians who ‘ban books and muzzle educators’
 - [http://www.msn.com/en-us/news/politics/wes-moore-calls-out-politicians-who-ban-books-and-muzzle-educators/ar-AA1btPSr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/wes-moore-calls-out-politicians-who-ban-books-and-muzzle-educators/ar-AA1btPSr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 16:14:43.700113+00:00



## Column: Feinstein is not going to quit the Senate. Ever. Just ask her biographer
 - [http://www.msn.com/en-us/news/politics/column-feinstein-is-not-going-to-quit-the-senate-ever-just-ask-her-biographer/ar-AA1btMGv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/column-feinstein-is-not-going-to-quit-the-senate-ever-just-ask-her-biographer/ar-AA1btMGv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 15:14:30.136452+00:00



## Georgia Democrat Slams Her Own Party Choosing Migrants Over Black Children
 - [http://www.msn.com/en-us/news/us/georgia-democrat-slams-her-own-party-choosing-migrants-over-black-children/ar-AA1btG0G?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/georgia-democrat-slams-her-own-party-choosing-migrants-over-black-children/ar-AA1btG0G?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 15:14:30.128667+00:00



## Will the U.S. send F-16s directly to Ukraine? No final decision yet, Sullivan says
 - [http://www.msn.com/en-us/news/world/will-the-u-s-send-f-16s-directly-to-ukraine-no-final-decision-yet-sullivan-says/ar-AA1bttVo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/will-the-u-s-send-f-16s-directly-to-ukraine-no-final-decision-yet-sullivan-says/ar-AA1bttVo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 15:14:30.120701+00:00



## Biden says 'MAGA Republicans' could use default to sink his reelection
 - [http://www.msn.com/en-us/news/politics/biden-says-maga-republicans-could-use-default-to-sink-his-reelection/ar-AA1btyF8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-says-maga-republicans-could-use-default-to-sink-his-reelection/ar-AA1btyF8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 15:14:30.112134+00:00



## South Korean, German leaders agree to cooperate on supply chains, North Korea
 - [http://www.msn.com/en-us/news/world/south-korean-german-leaders-agree-to-cooperate-on-supply-chains-north-korea/ar-AA1btRZW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/south-korean-german-leaders-agree-to-cooperate-on-supply-chains-north-korea/ar-AA1btRZW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 15:14:30.104116+00:00



## House Budget chair: Biden ‘just making more excuses’ not to negotiate debt ceiling deal
 - [http://www.msn.com/en-us/news/politics/house-budget-chair-biden-just-making-more-excuses-not-to-negotiate-debt-ceiling-deal/ar-AA1btUik?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-budget-chair-biden-just-making-more-excuses-not-to-negotiate-debt-ceiling-deal/ar-AA1btUik?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 15:14:30.095836+00:00



## Evidence of the first recorded romantic kiss dating back 4,500 years has been discovered
 - [http://www.msn.com/en-us/news/world/evidence-of-the-first-recorded-romantic-kiss-dating-back-4-500-years-has-been-discovered/ar-AA1btUls?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/evidence-of-the-first-recorded-romantic-kiss-dating-back-4-500-years-has-been-discovered/ar-AA1btUls?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 15:14:30.084980+00:00



## G-7 Struggles to Win Over Swing Nations Courted by China, Russia
 - [http://www.msn.com/en-us/news/world/g-7-struggles-to-win-over-swing-nations-courted-by-china-russia/ar-AA1btovM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/g-7-struggles-to-win-over-swing-nations-courted-by-china-russia/ar-AA1btovM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 14:14:42.995798+00:00



## Check your 'bossware' tools for bias, U.S. agency head warns employers
 - [http://www.msn.com/en-us/news/us/check-your-bossware-tools-for-bias-u-s-agency-head-warns-employers/ar-AA1btHfQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/check-your-bossware-tools-for-bias-u-s-agency-head-warns-employers/ar-AA1btHfQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 14:14:42.987850+00:00



## Education expert rips school systems after history grades plummet: ‘Appalling,’ ‘dumbed down curriculum’
 - [http://www.msn.com/en-us/news/us/education-expert-rips-school-systems-after-history-grades-plummet-appalling-dumbed-down-curriculum/ar-AA1btCO4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/education-expert-rips-school-systems-after-history-grades-plummet-appalling-dumbed-down-curriculum/ar-AA1btCO4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 14:14:42.979291+00:00



## G7 calls on China to pressure Russia to end Ukraine war
 - [http://www.msn.com/en-us/news/politics/g7-calls-on-china-to-pressure-russia-to-end-ukraine-war/ar-AA1btEVz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/g7-calls-on-china-to-pressure-russia-to-end-ukraine-war/ar-AA1btEVz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 14:14:42.971512+00:00



## SpaceX launching Saudi astronauts on private flight to space station
 - [http://www.msn.com/en-us/news/technology/spacex-launching-saudi-astronauts-on-private-flight-to-space-station/ar-AA1btlZm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/spacex-launching-saudi-astronauts-on-private-flight-to-space-station/ar-AA1btlZm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 14:14:42.963370+00:00



## Dems should get ready for 'Plan B' on debt ceiling and force House vote: Van Hollen
 - [http://www.msn.com/en-us/news/politics/dems-should-get-ready-for-plan-b-on-debt-ceiling-and-force-house-vote-van-hollen/ar-AA1btygY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/dems-should-get-ready-for-plan-b-on-debt-ceiling-and-force-house-vote-van-hollen/ar-AA1btygY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 14:14:42.955608+00:00



## Biden says 'it's time' for Republicans 'to move' on their 'extreme' debt ceiling demands
 - [http://www.msn.com/en-us/news/politics/biden-says-it-s-time-for-republicans-to-move-on-their-extreme-debt-ceiling-demands/ar-AA1btHAh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-says-it-s-time-for-republicans-to-move-on-their-extreme-debt-ceiling-demands/ar-AA1btHAh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 14:14:42.947566+00:00



## Biden’s G-7 summit shadowed by debt limit drama at home
 - [http://www.msn.com/en-us/news/world/biden-s-g-7-summit-shadowed-by-debt-limit-drama-at-home/ar-AA1btvAv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/biden-s-g-7-summit-shadowed-by-debt-limit-drama-at-home/ar-AA1btvAv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 14:14:42.938142+00:00



## Texas rancher who keeps pistol in hand over violent migrant fears shreds Biden for forsaking crisis: 'Wake up'
 - [http://www.msn.com/en-us/news/us/texas-rancher-who-keeps-pistol-in-hand-over-violent-migrant-fears-shreds-biden-for-forsaking-crisis-wake-up/ar-AA1btpU9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/texas-rancher-who-keeps-pistol-in-hand-over-violent-migrant-fears-shreds-biden-for-forsaking-crisis-wake-up/ar-AA1btpU9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 13:14:48.813873+00:00



## Three killed and two wounded in shooting at a bar in Kansas City
 - [http://www.msn.com/en-us/news/crime/three-killed-and-two-wounded-in-shooting-at-a-bar-in-kansas-city/ar-AA1btt69?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/three-killed-and-two-wounded-in-shooting-at-a-bar-in-kansas-city/ar-AA1btt69?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 13:14:48.806409+00:00



## G-7 Latest: Leaders Focus on Russia’s War, Reducing China Risks
 - [http://www.msn.com/en-us/news/world/g-7-latest-leaders-focus-on-russia-s-war-reducing-china-risks/ar-AA1bt1N3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/g-7-latest-leaders-focus-on-russia-s-war-reducing-china-risks/ar-AA1bt1N3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 13:14:48.798824+00:00



## Ukraine's Zelensky denies Russian forces are occupying Bakhmut
 - [http://www.msn.com/en-us/news/world/ukraine-s-zelensky-denies-russian-forces-are-occupying-bakhmut/ar-AA1btEKS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-s-zelensky-denies-russian-forces-are-occupying-bakhmut/ar-AA1btEKS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 13:14:48.791794+00:00



## Warning Signs That You Need a New Vacuum Cleaner
 - [http://www.msn.com/en-us/news/technology/warning-signs-that-you-need-a-new-vacuum-cleaner/ar-AA1bto9v?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/warning-signs-that-you-need-a-new-vacuum-cleaner/ar-AA1bto9v?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 13:14:48.783468+00:00



## Zelensky: Russian forces do not occupy Bakhmut ‘as of today’
 - [http://www.msn.com/en-us/news/politics/zelensky-russian-forces-do-not-occupy-bakhmut-as-of-today/ar-AA1bt1w0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/zelensky-russian-forces-do-not-occupy-bakhmut-as-of-today/ar-AA1bt1w0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 13:14:48.775269+00:00



## East Timor votes in parliamentary election aiming to break political impasse
 - [http://www.msn.com/en-us/news/world/east-timor-votes-in-parliamentary-election-aiming-to-break-political-impasse/ar-AA1btoli?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/east-timor-votes-in-parliamentary-election-aiming-to-break-political-impasse/ar-AA1btoli?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 13:14:48.754867+00:00



## School choice for all families passes House, heads to Senate
 - [http://www.msn.com/en-us/news/politics/school-choice-for-all-families-passes-house-heads-to-senate/ar-AA1btJOy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/school-choice-for-all-families-passes-house-heads-to-senate/ar-AA1btJOy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 13:14:48.747165+00:00



## Sammy goes to school: After 30 years of incarceration, graduation
 - [http://www.msn.com/en-us/news/crime/sammy-goes-to-school-after-30-years-of-incarceration-graduation/ar-AA1btnix?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/sammy-goes-to-school-after-30-years-of-incarceration-graduation/ar-AA1btnix?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 12:14:35.854962+00:00



## Stacey Abrams on Writing Suspense Novels and Her Future in Politics
 - [http://www.msn.com/en-us/news/us/stacey-abrams-on-writing-suspense-novels-and-her-future-in-politics/ar-AA1btuts?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/stacey-abrams-on-writing-suspense-novels-and-her-future-in-politics/ar-AA1btuts?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 12:14:35.845451+00:00



## Justice Ketanji Brown Jackson tells law students ‘Survivor’ offers helpful lessons
 - [http://www.msn.com/en-us/news/us/justice-ketanji-brown-jackson-tells-law-students-survivor-offers-helpful-lessons/ar-AA1btnpJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/justice-ketanji-brown-jackson-tells-law-students-survivor-offers-helpful-lessons/ar-AA1btnpJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 12:14:35.838426+00:00



## GOP must move off 'extreme' positions on debt limit or no deal, Biden says
 - [http://www.msn.com/en-us/news/politics/gop-must-move-off-extreme-positions-on-debt-limit-or-no-deal-biden-says/ar-AA1bteuC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-must-move-off-extreme-positions-on-debt-limit-or-no-deal-biden-says/ar-AA1bteuC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 12:14:35.830701+00:00



## Archaeologists discover a lost world of 417 ancient Mayans cities buried in remote jungle, connected by miles of 'superhighways,' WaPo reports
 - [http://www.msn.com/en-us/news/world/archaeologists-discover-a-lost-world-of-417-ancient-mayans-cities-buried-in-remote-jungle-connected-by-miles-of-superhighways-wapo-reports/ar-AA1btzqQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/archaeologists-discover-a-lost-world-of-417-ancient-mayans-cities-buried-in-remote-jungle-connected-by-miles-of-superhighways-wapo-reports/ar-AA1btzqQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 12:14:35.823255+00:00



## 'They're Marxist': Oklahoma's top education official wages war against teachers unions
 - [http://www.msn.com/en-us/news/us/they-re-marxist-oklahoma-s-top-education-official-wages-war-against-teachers-unions/ar-AA1btxel?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/they-re-marxist-oklahoma-s-top-education-official-wages-war-against-teachers-unions/ar-AA1btxel?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 12:14:35.816170+00:00



## Senate Democrat urges McCarthy to put ‘pin back in grenade’ on debt talks
 - [http://www.msn.com/en-us/news/politics/senate-democrat-urges-mccarthy-to-put-pin-back-in-grenade-on-debt-talks/ar-AA1btsxE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-democrat-urges-mccarthy-to-put-pin-back-in-grenade-on-debt-talks/ar-AA1btsxE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 12:14:35.808661+00:00



## Masculinity
 - [http://www.msn.com/en-us/news/us/masculinity/ar-AA1btbt2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/masculinity/ar-AA1btbt2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 12:14:35.800949+00:00



## I Sued My Neighbors, Now They Are Harassing Me—What Should I Do?
 - [http://www.msn.com/en-us/news/technology/i-sued-my-neighbors-now-they-are-harassing-me-what-should-i-do/ar-AA1btkPu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/i-sued-my-neighbors-now-they-are-harassing-me-what-should-i-do/ar-AA1btkPu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 11:14:35.633967+00:00



## Editorial: House Republicans' border security bill misses chance to fix real immigration challenges
 - [http://www.msn.com/en-us/news/us/editorial-house-republicans-border-security-bill-misses-chance-to-fix-real-immigration-challenges/ar-AA1btaMf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/editorial-house-republicans-border-security-bill-misses-chance-to-fix-real-immigration-challenges/ar-AA1btaMf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 11:14:35.626589+00:00



## Biden: GOP must move off 'extreme' positions, no debt limit deal solely on its 'partisan terms'
 - [http://www.msn.com/en-us/news/politics/biden-gop-must-move-off-extreme-positions-no-debt-limit-deal-solely-on-its-partisan-terms/ar-AA1btrMR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-gop-must-move-off-extreme-positions-no-debt-limit-deal-solely-on-its-partisan-terms/ar-AA1btrMR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 11:14:35.619602+00:00



## 3 dead in Kansas City lounge shooting
 - [http://www.msn.com/en-us/news/crime/3-dead-in-kansas-city-lounge-shooting/ar-AA1btkzC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/3-dead-in-kansas-city-lounge-shooting/ar-AA1btkzC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 11:14:35.611616+00:00



## Once again, GOP voters reject election deniers
 - [http://www.msn.com/en-us/news/politics/once-again-gop-voters-reject-election-deniers/ar-AA1btiTT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/once-again-gop-voters-reject-election-deniers/ar-AA1btiTT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 11:14:35.602831+00:00



## Biden says he thinks he has authority to use 14th Amendment on debt ceiling
 - [http://www.msn.com/en-us/news/politics/biden-says-he-thinks-he-has-authority-to-use-14th-amendment-on-debt-ceiling/ar-AA1btumY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-says-he-thinks-he-has-authority-to-use-14th-amendment-on-debt-ceiling/ar-AA1btumY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 11:14:35.595264+00:00



## Tim Keller Tried to Put Jesus Before Politics
 - [http://www.msn.com/en-us/news/us/tim-keller-tried-to-put-jesus-before-politics/ar-AA1btb9C?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tim-keller-tried-to-put-jesus-before-politics/ar-AA1btb9C?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 11:14:35.587498+00:00



## Biden says Republicans must move from ‘extreme positions’ on debt ceiling talks
 - [http://www.msn.com/en-us/news/politics/biden-says-republicans-must-move-from-extreme-positions-on-debt-ceiling-talks/ar-AA1btwWn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-says-republicans-must-move-from-extreme-positions-on-debt-ceiling-talks/ar-AA1btwWn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 11:14:35.579837+00:00



## Lawmakers revisit mandatory minimum sentencing laws to curtail rising crime rates
 - [http://www.msn.com/en-us/news/crime/lawmakers-revisit-mandatory-minimum-sentencing-laws-to-curtail-rising-crime-rates/ar-AA1btao4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/lawmakers-revisit-mandatory-minimum-sentencing-laws-to-curtail-rising-crime-rates/ar-AA1btao4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 10:14:42.932610+00:00



## How A Wasp Nest Caused One of the Worst Aviation Disasters
 - [http://www.msn.com/en-us/news/technology/how-a-wasp-nest-caused-one-of-the-worst-aviation-disasters/ar-AA1bt491?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-a-wasp-nest-caused-one-of-the-worst-aviation-disasters/ar-AA1bt491?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 10:14:42.925234+00:00



## The G7 shows China's rise prompting assertive new alliances in its own backyard
 - [http://www.msn.com/en-us/news/world/the-g7-shows-china-s-rise-prompting-assertive-new-alliances-in-its-own-backyard/ar-AA1bthKd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-g7-shows-china-s-rise-prompting-assertive-new-alliances-in-its-own-backyard/ar-AA1bthKd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 10:14:42.918228+00:00



## Watch live: Biden press conference in Japan
 - [http://www.msn.com/en-us/news/politics/watch-live-biden-press-conference-in-japan/ar-AA1btoZV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/watch-live-biden-press-conference-in-japan/ar-AA1btoZV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 10:14:42.910561+00:00



## State TV says armed group kills 5 Iranian border guards in clash near Pakistani border
 - [http://www.msn.com/en-us/news/world/state-tv-says-armed-group-kills-5-iranian-border-guards-in-clash-near-pakistani-border/ar-AA1btcpY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/state-tv-says-armed-group-kills-5-iranian-border-guards-in-clash-near-pakistani-border/ar-AA1btcpY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 09:14:43.966178+00:00



## Jill Biden addresses graduating seniors at US military base in Japan
 - [http://www.msn.com/en-us/news/politics/jill-biden-addresses-graduating-seniors-at-us-military-base-in-japan/ar-AA1bsLxD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jill-biden-addresses-graduating-seniors-at-us-military-base-in-japan/ar-AA1bsLxD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 09:14:43.957110+00:00



## G-7 Latest: Leaders Finish Talks Focused on Russia and China
 - [http://www.msn.com/en-us/news/world/g-7-latest-leaders-finish-talks-focused-on-russia-and-china/ar-AA1bt1N3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/g-7-latest-leaders-finish-talks-focused-on-russia-and-china/ar-AA1bt1N3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 09:14:43.948822+00:00



## The ballot initiative that could legalize recreational marijuana in the Sunshine State
 - [http://www.msn.com/en-us/news/us/the-ballot-initiative-that-could-legalize-recreational-marijuana-in-the-sunshine-state/ar-AA1btcEE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-ballot-initiative-that-could-legalize-recreational-marijuana-in-the-sunshine-state/ar-AA1btcEE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 09:14:43.941786+00:00



## Minnesota Senate passes bill to legalize recreational marijuana
 - [http://www.msn.com/en-us/news/politics/minnesota-senate-passes-bill-to-legalize-recreational-marijuana/ar-AA1btcwM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/minnesota-senate-passes-bill-to-legalize-recreational-marijuana/ar-AA1btcwM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 09:14:43.933358+00:00



## The G-7 shows China's rise prompting assertive new alliances in its own backyard
 - [http://www.msn.com/en-us/news/world/the-g-7-shows-china-s-rise-prompting-assertive-new-alliances-in-its-own-backyard/ar-AA1bthKd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-g-7-shows-china-s-rise-prompting-assertive-new-alliances-in-its-own-backyard/ar-AA1bthKd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 09:14:43.925253+00:00



## Huge black spider seen hanging from roof of house in Baldivis, south of Perth
 - [http://www.msn.com/en-us/news/technology/huge-black-spider-seen-hanging-from-roof-of-house-in-baldivis-south-of-perth/ar-AA1bt7au?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/huge-black-spider-seen-hanging-from-roof-of-house-in-baldivis-south-of-perth/ar-AA1bt7au?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 08:14:29.499228+00:00



## Biden Title IX transgender sports rule ignites 156K comments: 'Voices in opposition'
 - [http://www.msn.com/en-us/news/us/biden-title-ix-transgender-sports-rule-ignites-156k-comments-voices-in-opposition/ar-AA1bt7j8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/biden-title-ix-transgender-sports-rule-ignites-156k-comments-voices-in-opposition/ar-AA1bt7j8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 08:14:29.491739+00:00



## Fact Check: Did Jason Knauf Contribute to Meghan Markle's Miscarriage
 - [http://www.msn.com/en-us/news/world/fact-check-did-jason-knauf-contribute-to-meghan-markle-s-miscarriage/ar-AA1btcil?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fact-check-did-jason-knauf-contribute-to-meghan-markle-s-miscarriage/ar-AA1btcil?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 08:14:29.484725+00:00



## State TV says armed group kills 6 Iranian border guards in clash near Pakistani border
 - [http://www.msn.com/en-us/news/world/state-tv-says-armed-group-kills-6-iranian-border-guards-in-clash-near-pakistani-border/ar-AA1btcpY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/state-tv-says-armed-group-kills-6-iranian-border-guards-in-clash-near-pakistani-border/ar-AA1btcpY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 08:14:29.477745+00:00



## Bakhmut is 'only in our hearts' after Ukraine loses control of city, Zelensky says
 - [http://www.msn.com/en-us/news/world/bakhmut-is-only-in-our-hearts-after-ukraine-loses-control-of-city-zelensky-says/ar-AA1bteT7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/bakhmut-is-only-in-our-hearts-after-ukraine-loses-control-of-city-zelensky-says/ar-AA1bteT7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 08:14:29.470476+00:00



## Georgia Democrat launches scathing attack on her own party for prioritizing migrants over local kids
 - [http://www.msn.com/en-us/news/us/georgia-democrat-launches-scathing-attack-on-her-own-party-for-prioritizing-migrants-over-local-kids/ar-AA1bt4RR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/georgia-democrat-launches-scathing-attack-on-her-own-party-for-prioritizing-migrants-over-local-kids/ar-AA1bt4RR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 07:14:35.335474+00:00



## Control of Bakhmut in question as Ukraine disputes Russian victory claims
 - [http://www.msn.com/en-us/news/world/control-of-bakhmut-in-question-as-ukraine-disputes-russian-victory-claims/ar-AA1bsOfM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/control-of-bakhmut-in-question-as-ukraine-disputes-russian-victory-claims/ar-AA1bsOfM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 07:14:35.326204+00:00



## Zelenskyy making his appeal in person to G7 leaders in Japan could be a 'game changer' as the Ukrainian president seeks more aid and hopes to persuade on-the-fence countries like India
 - [http://www.msn.com/en-us/news/world/zelenskyy-making-his-appeal-in-person-to-g7-leaders-in-japan-could-be-a-game-changer-as-the-ukrainian-president-seeks-more-aid-and-hopes-to-persuade-on-the-fence-countries-like-india/ar-AA1bsOly?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/zelenskyy-making-his-appeal-in-person-to-g7-leaders-in-japan-could-be-a-game-changer-as-the-ukrainian-president-seeks-more-aid-and-hopes-to-persuade-on-the-fence-countries-like-india/ar-AA1bsOly?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 07:14:35.318664+00:00



## Extremist Israel Cabinet minister visits sensitive Jerusalem holy site
 - [http://www.msn.com/en-us/news/world/extremist-israel-cabinet-minister-visits-sensitive-jerusalem-holy-site/ar-AA1bsVyf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/extremist-israel-cabinet-minister-visits-sensitive-jerusalem-holy-site/ar-AA1bsVyf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 07:14:35.311076+00:00



## McCarthy Says Biden Would Rather Default on Debt Than Upset 'Radical Socialists'
 - [http://www.msn.com/en-us/news/politics/mccarthy-says-biden-would-rather-default-on-debt-than-upset-radical-socialists/ar-AA1bt6Ne?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccarthy-says-biden-would-rather-default-on-debt-than-upset-radical-socialists/ar-AA1bt6Ne?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 06:14:42.958550+00:00



## RACE HORNE is Britain's last bespoke scissor maker
 - [http://www.msn.com/en-us/news/crime/race-horne-is-britain-s-last-bespoke-scissor-maker/ar-AA1bsVf1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/race-horne-is-britain-s-last-bespoke-scissor-maker/ar-AA1bsVf1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 06:14:42.947427+00:00



## Florida man allegedly beat grandmother to death with hammer then called housekeeper to clean up bloody scene
 - [http://www.msn.com/en-us/news/crime/florida-man-allegedly-beat-grandmother-to-death-with-hammer-then-called-housekeeper-to-clean-up-bloody-scene/ar-AA1bsPVH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/florida-man-allegedly-beat-grandmother-to-death-with-hammer-then-called-housekeeper-to-clean-up-bloody-scene/ar-AA1bsPVH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 06:14:42.938575+00:00



## Meloni and Trudeau Spar on LGBTQ Rights in Unusual G-7 Disunity
 - [http://www.msn.com/en-us/news/world/meloni-and-trudeau-spar-on-lgbtq-rights-in-unusual-g-7-disunity/ar-AA1bsRNI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/meloni-and-trudeau-spar-on-lgbtq-rights-in-unusual-g-7-disunity/ar-AA1bsRNI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 05:14:26.785012+00:00



## NRL bosses 'complain to Nine about unfair treatment on the Today show'
 - [http://www.msn.com/en-us/news/world/nrl-bosses-complain-to-nine-about-unfair-treatment-on-the-today-show/ar-AA1bsNqL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nrl-bosses-complain-to-nine-about-unfair-treatment-on-the-today-show/ar-AA1bsNqL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 05:14:26.729202+00:00



## The Hunter investigation needs a special counsel
 - [http://www.msn.com/en-us/news/us/the-hunter-investigation-needs-a-special-counsel/ar-AA1bsNyP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-hunter-investigation-needs-a-special-counsel/ar-AA1bsNyP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 05:14:26.675084+00:00



## A critically endangered rat-sized marsupial that looks like a mini kangaroo is returning to parts of Australia for the first time in a century
 - [http://www.msn.com/en-us/news/world/a-critically-endangered-rat-sized-marsupial-that-looks-like-a-mini-kangaroo-is-returning-to-parts-of-australia-for-the-first-time-in-a-century/ar-AA1bsINq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-critically-endangered-rat-sized-marsupial-that-looks-like-a-mini-kangaroo-is-returning-to-parts-of-australia-for-the-first-time-in-a-century/ar-AA1bsINq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 05:14:26.609411+00:00



## What should I do on the death anniversary? More are asking as US mass killings rise
 - [http://www.msn.com/en-us/news/us/what-should-i-do-on-the-death-anniversary-more-are-asking-as-us-mass-killings-rise/ar-AA1bsDHB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-should-i-do-on-the-death-anniversary-more-are-asking-as-us-mass-killings-rise/ar-AA1bsDHB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 05:14:26.530791+00:00



## Biden to call McCarthy from G7 as stalemate derails debt limit negotiations
 - [http://www.msn.com/en-us/news/politics/biden-to-call-mccarthy-from-g7-as-stalemate-derails-debt-limit-negotiations/ar-AA1bsN8B?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-to-call-mccarthy-from-g7-as-stalemate-derails-debt-limit-negotiations/ar-AA1bsN8B?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 04:14:26.865275+00:00



## Would You Let NASA Lock You Up in a Fake Mars Habitat for a Year?
 - [http://www.msn.com/en-us/news/technology/would-you-let-nasa-lock-you-up-in-a-fake-mars-habitat-for-a-year/ar-AA1bsRvW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/would-you-let-nasa-lock-you-up-in-a-fake-mars-habitat-for-a-year/ar-AA1bsRvW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 04:14:26.857599+00:00



## Japanese atomic bomb survivors worry Zelenskyy's G7 visit overshadows nuke disarmament message
 - [http://www.msn.com/en-us/news/world/japanese-atomic-bomb-survivors-worry-zelenskyy-s-g7-visit-overshadows-nuke-disarmament-message/ar-AA1bsKbQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/japanese-atomic-bomb-survivors-worry-zelenskyy-s-g7-visit-overshadows-nuke-disarmament-message/ar-AA1bsKbQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 04:14:26.848611+00:00



## Husband of Missing Teacher Kills Himself Under Suspicion
 - [http://www.msn.com/en-us/news/crime/husband-of-missing-teacher-kills-himself-under-suspicion/ar-AA1bsF5R?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/husband-of-missing-teacher-kills-himself-under-suspicion/ar-AA1bsF5R?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 03:14:38.649996+00:00



## Lawyer says he quit Trump's legal team over clashes with one of his advisors
 - [http://www.msn.com/en-us/news/politics/lawyer-says-he-quit-trump-s-legal-team-over-clashes-with-one-of-his-advisors/ar-AA1bsJRK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lawyer-says-he-quit-trump-s-legal-team-over-clashes-with-one-of-his-advisors/ar-AA1bsJRK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 03:14:38.642241+00:00



## Biden to call McCarthy to discuss debt ceiling after G7 summit
 - [http://www.msn.com/en-us/news/politics/biden-to-call-mccarthy-to-discuss-debt-ceiling-after-g7-summit/ar-AA1bpGZ1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-to-call-mccarthy-to-discuss-debt-ceiling-after-g7-summit/ar-AA1bpGZ1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 03:14:38.634199+00:00



## DeSantis largely avoids abortion at anti-abortion group’s gala
 - [http://www.msn.com/en-us/news/politics/desantis-largely-avoids-abortion-at-anti-abortion-group-s-gala/ar-AA1bsFjI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/desantis-largely-avoids-abortion-at-anti-abortion-group-s-gala/ar-AA1bsFjI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 03:14:38.625989+00:00



## Former Marine charged with killing NYC man argues it ‘had nothing to do with race’
 - [http://www.msn.com/en-us/news/crime/former-marine-charged-with-killing-nyc-man-argues-it-had-nothing-to-do-with-race/ar-AA1bsRnf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/former-marine-charged-with-killing-nyc-man-argues-it-had-nothing-to-do-with-race/ar-AA1bsRnf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 03:14:38.616819+00:00



## Trump's former lawyer blasts Trump's current lawyer
 - [http://www.msn.com/en-us/news/politics/trump-s-former-lawyer-blasts-trump-s-current-lawyer/ar-AA1bsC1A?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-s-former-lawyer-blasts-trump-s-current-lawyer/ar-AA1bsC1A?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 02:14:41.012463+00:00



## Former Trump lawyer points to internal division as reason for leaving legal team
 - [http://www.msn.com/en-us/news/politics/former-trump-lawyer-points-to-internal-division-as-reason-for-leaving-legal-team/ar-AA1bsETh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/former-trump-lawyer-points-to-internal-division-as-reason-for-leaving-legal-team/ar-AA1bsETh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 02:14:41.005129+00:00



## Smoke from Canada wildfires prompts air quality alerts in Colorado, Montana
 - [http://www.msn.com/en-us/health/health-news/smoke-from-canada-wildfires-prompts-air-quality-alerts-in-colorado-montana/ar-AA1bsOJe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/smoke-from-canada-wildfires-prompts-air-quality-alerts-in-colorado-montana/ar-AA1bsOJe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 02:14:40.995611+00:00



## Transgender student misses graduation after Mississippi judge backs dress code
 - [http://www.msn.com/en-us/news/us/transgender-student-misses-graduation-after-mississippi-judge-backs-dress-code/ar-AA1bstB4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/transgender-student-misses-graduation-after-mississippi-judge-backs-dress-code/ar-AA1bstB4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 02:14:40.987543+00:00



## Trump team responds to allegations of interference in classified document searches: ‘Categorically false’
 - [http://www.msn.com/en-us/news/politics/trump-team-responds-to-allegations-of-interference-in-classified-document-searches-categorically-false/ar-AA1bsOK2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-team-responds-to-allegations-of-interference-in-classified-document-searches-categorically-false/ar-AA1bsOK2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 02:14:40.979294+00:00



## Gurkha who lost both his legs in Afghanistan explosion makes history by scaling Mount Everest
 - [http://www.msn.com/en-us/news/world/gurkha-who-lost-both-his-legs-in-afghanistan-explosion-makes-history-by-scaling-mount-everest/ar-AA1bsqH6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/gurkha-who-lost-both-his-legs-in-afghanistan-explosion-makes-history-by-scaling-mount-everest/ar-AA1bsqH6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 01:14:24.556905+00:00



## Conservatives Upset by New $14 Trillion Reparations Proposal
 - [http://www.msn.com/en-us/news/politics/conservatives-upset-by-new-14-trillion-reparations-proposal/ar-AA1bsqBL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/conservatives-upset-by-new-14-trillion-reparations-proposal/ar-AA1bsqBL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 01:14:24.547819+00:00



## Lawyer who quit Trump legal team cites disagreements with Trump adviser as basis for departure
 - [http://www.msn.com/en-us/news/politics/lawyer-who-quit-trump-legal-team-cites-disagreements-with-trump-adviser-as-basis-for-departure/ar-AA1bsqvO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lawyer-who-quit-trump-legal-team-cites-disagreements-with-trump-adviser-as-basis-for-departure/ar-AA1bsqvO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 01:14:24.540065+00:00



## Warring factions in Sudan agree to temporary ceasefire
 - [http://www.msn.com/en-us/news/world/warring-factions-in-sudan-agree-to-temporary-ceasefire/ar-AA1bsLWr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/warring-factions-in-sudan-agree-to-temporary-ceasefire/ar-AA1bsLWr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 01:14:24.532837+00:00



## COVID public health emergency is over: Here's what it means for you
 - [http://www.msn.com/en-us/health/health-news/covid-public-health-emergency-is-over-here-s-what-it-means-for-you/ar-AA1bsvq1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/covid-public-health-emergency-is-over-here-s-what-it-means-for-you/ar-AA1bsvq1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 01:14:24.525561+00:00



## Russian private army head claims control of Bakhmut but Ukraine says fighting continues
 - [http://www.msn.com/en-us/news/world/russian-private-army-head-claims-control-of-bakhmut-but-ukraine-says-fighting-continues/ar-AA1bsgQw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-private-army-head-claims-control-of-bakhmut-but-ukraine-says-fighting-continues/ar-AA1bsgQw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 01:14:24.517825+00:00



## House Speaker McCarthy says debt ceiling negotiations can't resume until Biden returns from G-7 summit
 - [http://www.msn.com/en-us/news/politics/house-speaker-mccarthy-says-debt-ceiling-negotiations-can-t-resume-until-biden-returns-from-g-7-summit/ar-AA1bsijR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-speaker-mccarthy-says-debt-ceiling-negotiations-can-t-resume-until-biden-returns-from-g-7-summit/ar-AA1bsijR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 00:10:01.225732+00:00



## Mississippi Court Rules Trans Girl Must Dress as Boy for School Graduation
 - [http://www.msn.com/en-us/news/us/mississippi-court-rules-trans-girl-must-dress-as-boy-for-school-graduation/ar-AA1bsBQY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/mississippi-court-rules-trans-girl-must-dress-as-boy-for-school-graduation/ar-AA1bsBQY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 00:10:01.216607+00:00



## Wagner Group seizes Bakhmut with help from Russian troops
 - [http://www.msn.com/en-us/news/world/wagner-group-seizes-bakhmut-with-help-from-russian-troops/ar-AA1bsfMy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/wagner-group-seizes-bakhmut-with-help-from-russian-troops/ar-AA1bsfMy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 00:10:01.205638+00:00



## Debt ceiling talks break down and attacks escalate as deadline approaches
 - [http://www.msn.com/en-us/news/politics/debt-ceiling-talks-break-down-and-attacks-escalate-as-deadline-approaches/ar-AA1bsEvr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/debt-ceiling-talks-break-down-and-attacks-escalate-as-deadline-approaches/ar-AA1bsEvr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 00:09:59.265225+00:00



## Warring factions in Sudan agree to temporary ceasefire, say US-Saudi mediators
 - [http://www.msn.com/en-us/news/world/warring-factions-in-sudan-agree-to-temporary-ceasefire-say-us-saudi-mediators/ar-AA1bsovW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/warring-factions-in-sudan-agree-to-temporary-ceasefire-say-us-saudi-mediators/ar-AA1bsovW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-21 00:09:59.253972+00:00



