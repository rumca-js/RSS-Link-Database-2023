# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Ambasador Ukrainy w Polsce, szczerze o przeprosinach za Wołyń!
 - [https://www.youtube.com/watch?v=ixODKGspjhI](https://www.youtube.com/watch?v=ixODKGspjhI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2023-05-21 14:41:23+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3AEK0uJ
2. https://bit.ly/43baYY5
3. https://bit.ly/42Xd5yv
4. https://bit.ly/3q1LM7H
5. https://bit.ly/42TU7Zn
6. https://bit.ly/3IwZVjk
7. https://bit.ly/3IwZXaW
---------------------------------------------------------------
🎴 Wykorzystano grafikę ze stron:
poland.mfa.gov.ua - https://bit.ly/3C3YDJj
---
Wikipedia.org - https://bit.ly/45m1RF7
---
CC BY 4.0 - https://bit.ly/2YrsjQn
---------------------------------------------------------------
💡 Tagi: #ukraina #polityka 
--------------------------------------------------------------

