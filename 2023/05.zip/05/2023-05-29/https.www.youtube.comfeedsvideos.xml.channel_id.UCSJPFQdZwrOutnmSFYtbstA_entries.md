# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Little Mermaid - Absolute Bilge
 - [https://www.youtube.com/watch?v=nhShXCslwow](https://www.youtube.com/watch?v=nhShXCslwow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-05-29 17:15:03+00:00

Disney's latest live action remake hasn't exactly hit the mark with critics or audiences. So strap on your fake mermaid tails and let's dive deep into this beast. 

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker

