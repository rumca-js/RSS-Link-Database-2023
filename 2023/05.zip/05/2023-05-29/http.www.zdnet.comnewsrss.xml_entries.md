# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## What I use to measure device power consumption (and what you should use instead)
 - [https://www.zdnet.com/home-and-office/this-is-what-i-use-to-measure-how-much-electricity-a-device-consumes/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/this-is-what-i-use-to-measure-how-much-electricity-a-device-consumes/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-05-29 09:28:08+00:00

This is another one of those 'Do as I say, not as I do' moments.

## Nvidia unveils new kind of Ethernet for AI, Grace Hopper 'Superchip' in full production
 - [https://www.zdnet.com/article/nvidia-unveils-new-kind-of-ethernet-for-ai-grace-hopper-superchip-in-full-production/#ftag=RSSbaffb68](https://www.zdnet.com/article/nvidia-unveils-new-kind-of-ethernet-for-ai-grace-hopper-superchip-in-full-production/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-05-29 04:45:00+00:00

The Spectrum-X ethernet switch offers "lossless" transmission via a new kind of congestion control, said Nvidia.

