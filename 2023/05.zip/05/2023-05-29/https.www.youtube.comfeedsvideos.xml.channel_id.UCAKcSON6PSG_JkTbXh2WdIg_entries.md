# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## The New Pornographers – Continue as a Guest (live for The Current)
 - [https://www.youtube.com/watch?v=z7V-2xFWT-8](https://www.youtube.com/watch?v=z7V-2xFWT-8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-05-29 02:00:29+00:00

A band since 1997, the New Pornographers continue to evolve with their latest album, Continue as a Guest. The band visited The Current to play songs from the record, their ninth full-length release, and their first on Merge Records.

Watch and listen to the complete session, including A.C. Newman's interview with Jill Riley: https://youtu.be/eQOfX8dB0Ic

Musicians
A.C. Newman – vocals, guitar
Kathryn Calder – keyboard, vocals
Adam Schatz – saxophone, keyboard
Joe Seiders – drums, vocals

Credits
Guests – @TheNewPornographers 
Host – Jill Riley
Producer – Derrick Stevens
Video Director – Evan Clark
Camera Operators – Guillermo Bonilla, Peter Ecklund
Audio – Evan Clark
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/
https://www.tiktok.com/@thecurrent.org

#thenewpornographers @MergeRecords

