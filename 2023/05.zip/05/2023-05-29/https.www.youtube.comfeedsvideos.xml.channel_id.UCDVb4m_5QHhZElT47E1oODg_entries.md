# Source:The Dave Cullen Show, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg, language:en-US

## Little Mermaid Sinking at International Box Office
 - [https://www.youtube.com/watch?v=XDPyQO6B-Dg](https://www.youtube.com/watch?v=XDPyQO6B-Dg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg
 - date published: 2023-05-29 17:12:14+00:00

Support my work on Subscribe Star: https://www.subscribestar.com/dave-cullen
Follow me on Bitchute: https://www.bitchute.com/channel/hybM74uIHJKg/

Source articles:
https://deadline.com/2023/05/the-little-mermaid-global-opening-review-bombing-international-box-office-1235381992/

https://variety.com/2023/film/news/china-box-office-fast-x-the-little-mermaid-1235627599/

KEEP UP ON SOCIAL MEDIA:
Gab: https://gab.ai/DaveCullen
Subscribe on Gab TV: https://tv.gab.com/channel/DaveCullen
Minds.com: https://www.minds.com/davecullen
Subscribe on Odysee: https://odysee.com/@TheDaveCullenShow:7

