# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Paul Rudd and Aaron Rogers go viral at Taylor Swift concert, Camila Cabello and Shawn Mendes rekindle romance
 - [https://www.foxnews.com/entertainment/paul-rudd-aaron-rogers-go-viral-taylor-swift-concert-camila-cabello-shawn-mendes-rekindle-romance](https://www.foxnews.com/entertainment/paul-rudd-aaron-rogers-go-viral-taylor-swift-concert-camila-cabello-shawn-mendes-rekindle-romance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 18:42:34+00:00

Celebrities flocked to Taylor Swift&apos;s New Jersey concerts this weekend, embracing their inner Swiftie status. Stars went viral for their dancing and their PDA.

## Maine police shoot at suspect who evaded trooper to Canadian and was believed to have explosive in truck
 - [https://www.foxnews.com/us/maine-police-shoot-suspect-evaded-trooper-canadian-believed-explosive-truck](https://www.foxnews.com/us/maine-police-shoot-suspect-evaded-trooper-canadian-believed-explosive-truck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 18:14:25+00:00

Maine State Police shot at a Rhode Island man who police suspect had an explosive as he evaded a trooper, and threatened to leave the U.S. and enter Canada from Houlton.

## Virginia church's Memorial Day concert honors lives lost to COVID, Ukraine war alongside service members
 - [https://www.foxnews.com/media/virginia-churchs-memorial-day-concert-honors-lives-lost-covid-ukraine-war-alongside-service-members](https://www.foxnews.com/media/virginia-churchs-memorial-day-concert-honors-lives-lost-covid-ukraine-war-alongside-service-members)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 17:45:23+00:00

Andrew Chapel United Methodist Church promoted a Memorial Day event to honor fallen veterans as well as those who died from COVID-19 and the Ukrainian war.

## 76ers replace Doc Rivers with championship-winning coach
 - [https://www.foxnews.com/sports/76ers-replace-doc-rivers-championship-winning-coach](https://www.foxnews.com/sports/76ers-replace-doc-rivers-championship-winning-coach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 17:40:01+00:00

The Philadelphia 76ers have reportedly hired Nick Nurse, who won the NBA championship with the Toronto Raptors in 2019, as their next head coach.

## Inmates hope to befriend Theranos founder Elizabeth Holmes ahead of her arrival at Texas prison
 - [https://www.foxnews.com/media/inmates-hope-befriend-theranos-founder-elizabeth-holmes-arrival-texas-prison](https://www.foxnews.com/media/inmates-hope-befriend-theranos-founder-elizabeth-holmes-arrival-texas-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 17:28:20+00:00

Inmates at Federal Prison Camp, Bryan in Texas are awaiting Theranos founder Elizabeth Holmes to surrender herself Tuesday and join them for her 11-year sentence.

## Kosovo police, NATO peacekeepers clash with Serb protesters as tensions in the region escalate
 - [https://www.foxnews.com/world/kosovo-police-nato-peacekeepers-clash-serb-protesters-tensions-region-escalate](https://www.foxnews.com/world/kosovo-police-nato-peacekeepers-clash-serb-protesters-tensions-region-escalate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 16:52:13+00:00

Violent protests erupted in Northern Kosovo Monday between local police and NATO-led forces and ethnic Serbs, leading to injuries on both sides.

## Shania Twain's Hollywood concert draws a photobombing Tom Hanks, crying Dax Shepard
 - [https://www.foxnews.com/entertainment/shania-twains-hollywood-concert-draws-photobombing-tom-hanks-crying-dax-shepard](https://www.foxnews.com/entertainment/shania-twains-hollywood-concert-draws-photobombing-tom-hanks-crying-dax-shepard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 16:49:04+00:00

Shania Twain&apos;s show at the Hollywood Bowl was packed with celebrities, including two famous couples in Kristen Bell and Dax Shepard and Tom Hanks and Rita Wilson.

## Camera crane swings into action, knocking climate protester to the ground during live Swedish dance show
 - [https://www.foxnews.com/media/camera-crane-swings-action-knocking-climate-protester-ground-live-swedish-dance-show](https://www.foxnews.com/media/camera-crane-swings-action-knocking-climate-protester-ground-live-swedish-dance-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 16:46:42+00:00

A cameraman knocked over a climate activist who ran on stage and held up a &quot;restore wetlands&quot; banner during a Swedish dance show on TV4 Friday.

## Florida man arrested after allegedly pouring gas on another man and lighting him on fire: police
 - [https://www.foxnews.com/us/florida-man-arrested-allegedly-pouring-gas-another-man-lighting-fire-police](https://www.foxnews.com/us/florida-man-arrested-allegedly-pouring-gas-another-man-lighting-fire-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 16:40:24+00:00

A Tampa, Florida man was arrested and charged with first-degree attempted murder after he poured gas on a man and set him on fire, according to police.

## Ottawa woman, 96, sets world record with blazing 5K race
 - [https://www.foxnews.com/sports/ottawa-woman-96-sets-world-record-blazing-5k-race](https://www.foxnews.com/sports/ottawa-woman-96-sets-world-record-blazing-5k-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 16:18:10+00:00

Rejeanne Fairhead, a 96-year-old woman from Ottawa, walked a five-kilometer race in 51:09, the fastest 5K ever by a woman aged 95-99.

## Jets teammate playfully calls out ‘weird’ fans over video of Aaron Rodgers dancing at Taylor Swift concert
 - [https://www.foxnews.com/sports/jets-teammate-playfully-calls-out-weird-fans-over-video-aaron-rodgers-dancing-taylor-swift-concert](https://www.foxnews.com/sports/jets-teammate-playfully-calls-out-weird-fans-over-video-aaron-rodgers-dancing-taylor-swift-concert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 16:00:16+00:00

Video of New York Jets quarterback Aaron Rodgers dancing at Taylor Swift&apos;s concert at MetLife Stadium has gone viral on social media and one teammate thinks it&apos;s &quot;weird.&quot;

## Texas firefighter stabbed while putting out early morning fire on I-35
 - [https://www.foxnews.com/us/texas-firefighter-stabbed-putting-out-early-morning-fire](https://www.foxnews.com/us/texas-firefighter-stabbed-putting-out-early-morning-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:53:47+00:00

An Austin, Texas firefighter who was working several fires along I-35 was stabbed early Monday morning after a person approached the crew and became aggressive.

## Martin Scorsese meets with Pope Francis, announces plans to make a new film about Jesus
 - [https://www.foxnews.com/entertainment/martin-scorsese-meets-pope-francis-announces-plans-make-new-film-jesus](https://www.foxnews.com/entertainment/martin-scorsese-meets-pope-francis-announces-plans-make-new-film-jesus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:49:10+00:00

Martin Scorsese revealed at the Vatican on Saturday that he would be making a movie about Jesus after meeting with Pope Francis.

## Lindsey Graham vows to 'undo' 'absurd' bipartisan debt deal, calls it 'disaster for defense'
 - [https://www.foxnews.com/politics/lindsey-graham-vows-undo-absurd-bipartisan-debt-deal-calls-it-disaster-defense](https://www.foxnews.com/politics/lindsey-graham-vows-undo-absurd-bipartisan-debt-deal-calls-it-disaster-defense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:38:02+00:00

Republican South Carolina Sen. Lindsey Graham vowed to undo the debt ceiling deal struck between the White House and House GOP Sunday, calling it &quot;absurd&quot; and a &quot;disaster for defense.&quot;

## Father of high school female skier who lost state title to transgender says competition 'not fair' for girls
 - [https://www.foxnews.com/sports/father-high-school-female-skier-lost-state-title-transgender-says-competition-not-fair-girls](https://www.foxnews.com/sports/father-high-school-female-skier-lost-state-title-transgender-says-competition-not-fair-girls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:33:54+00:00

A father of a high school female skier who lost the state title to a transgender says the competition was &quot;not fair&quot; to the athletes who were born girls.

## Suspect in Indianapolis policewoman's killing seeks insanity defense to avoid death penalty
 - [https://www.foxnews.com/us/suspect-indianapolis-policewomans-killing-seeks-insanity-defense-avoid-death-penalty](https://www.foxnews.com/us/suspect-indianapolis-policewomans-killing-seeks-insanity-defense-avoid-death-penalty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:08:47+00:00

Elliahs Dorsey appears intent on submitting an insanity plea to avoid the death penalty for the fatal shooting of Indianapolis Metropolitan Police Officer Breann Leath.

## Polish President Andrzej Duda to approve controversial bill rooting out Russian influence
 - [https://www.foxnews.com/world/polish-president-andrzej-duda-approve-controversial-bill-rooting-out-russian-influence](https://www.foxnews.com/world/polish-president-andrzej-duda-approve-controversial-bill-rooting-out-russian-influence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:07:46+00:00

Polish President Andrzej Duda says he will sign a bill meant to curb Russian influence, but critics allege it is intended to hurt the opposition party ahead of elections.

## Italy reports 4 dead after storm capsizes tourist boat
 - [https://www.foxnews.com/world/italy-reports-4-dead-storm-capsizes-tourist-boat](https://www.foxnews.com/world/italy-reports-4-dead-storm-capsizes-tourist-boat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:07:39+00:00

A body was retrieved Monday from a lake in northern Italy, raising the death toll aboard a houseboat that capsized during a Sunday storm to four.

## Florida woman accused of speeding down beach is charged with DUI: police
 - [https://www.foxnews.com/us/florida-woman-accused-speeding-down-beach-charged-dui-police](https://www.foxnews.com/us/florida-woman-accused-speeding-down-beach-charged-dui-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:03:43+00:00

A Florida woman was charged with a DUI and reckless driving after plowing her car into the water on a beach, narrowly missing several bystanders.

## Iranian-born model draws outrage for dress with noose around neck to raise awareness for Iran executions
 - [https://www.foxnews.com/media/iranian-born-model-draws-outrage-dress-noose-neck-raise-awareness-iran-executions](https://www.foxnews.com/media/iranian-born-model-draws-outrage-dress-noose-neck-raise-awareness-iran-executions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:00:23+00:00

Mahlagha Jaberi, an Iranian-born model, is going viral after she wore a dress that resembled a noose in an attempt to raise awareness for recent executions in Iran.

## Bald eagle struck by car in Wisconsin needs 'further evaluation,' police say
 - [https://www.foxnews.com/lifestyle/bald-eagle-struck-car-wisconsin-needs-further-evaluation-police-say](https://www.foxnews.com/lifestyle/bald-eagle-struck-car-wisconsin-needs-further-evaluation-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 15:00:06+00:00

A sheriff&apos;s department in Kewaunee, Wisconsin, announced on Facebook on May 25 that a bald eagle had been &quot;struck by a vehicle.&quot; A wildlife rescue group says the bird is &quot;on pain meds.&quot;

## Libyan court tries 51 suspected ISIS militants, 23 sentenced to death
 - [https://www.foxnews.com/world/libyan-court-tries-51-suspected-isis-militants-23-sentenced-death](https://www.foxnews.com/world/libyan-court-tries-51-suspected-isis-militants-23-sentenced-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 14:54:21+00:00

A Libyan appellate court on Monday sentenced 23 suspected Islamic State militants to death, with 23 more receiving substantial prison terms.

## Ex-Jets running back Le’Veon Bell rips former coach Adam Gase, admits to marijuana use before NFL games
 - [https://www.foxnews.com/sports/ex-jets-running-back-leveon-bell-rips-former-coach-adam-gase-admits-marijuana-use-before-nfl-games](https://www.foxnews.com/sports/ex-jets-running-back-leveon-bell-rips-former-coach-adam-gase-admits-marijuana-use-before-nfl-games)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 14:53:23+00:00

Le&apos;Veon Bell lasted less than two season with the New York Jets, but the three-time Pro Bowl running back pointed to ex-head coach Adam Gase as the problem during an interview Friday.

## US Open champion Sloane Stephens says racism against athletes has 'only gotten worse'
 - [https://www.foxnews.com/sports/us-open-champion-sloane-stephens-says-racism-against-athletes-has-only-gotten-worse](https://www.foxnews.com/sports/us-open-champion-sloane-stephens-says-racism-against-athletes-has-only-gotten-worse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 14:47:47+00:00

Sloane Stephens, who turned professional in 2009, said after her victory at the French Open that racism against athletes has &quot;only gotten worse.&quot;

## China to land astronauts on moon before 2030, officials say
 - [https://www.foxnews.com/science/china-land-astronauts-moon-before-2030-officials-say](https://www.foxnews.com/science/china-land-astronauts-moon-before-2030-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 14:42:42+00:00

Officials with the Chinese Manned Space Agency said in a news conference on Monday that the program plans to place astronauts on the moon before 2030 and expand its space station.

## 365 Belarusians sanctioned by Poland over journalist's 'draconian' jail sentence
 - [https://www.foxnews.com/world/365-belarusians-sanctioned-poland-journalists-draconian-jail-sentence](https://www.foxnews.com/world/365-belarusians-sanctioned-poland-journalists-draconian-jail-sentence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 14:41:01+00:00

Poland has sanctioned 365 Belarusian nationals and frozen the financial assets of 36 entities over the country&apos;s decision to uphold journalist Andrzej Poczobut&apos;s eight-year prison term.

## Japanese PM's son resigns government post over executive residence partying scandal
 - [https://www.foxnews.com/world/japanese-pms-son-resigns-government-post-executive-residence-partying-scandal](https://www.foxnews.com/world/japanese-pms-son-resigns-government-post-executive-residence-partying-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 14:23:59+00:00

Shotaro Kishida, son of conservative Japanese Prime Minister Fumio Kishida, has resigned from his position as the Asian nation&apos;s executive secretary for political affairs.

## Knife-wielding suspect killed, bystander injured in northern Illinois police shooting
 - [https://www.foxnews.com/us/knife-wielding-suspect-killed-bystander-injured-northern-illinois-police-shooting](https://www.foxnews.com/us/knife-wielding-suspect-killed-bystander-injured-northern-illinois-police-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 14:06:07+00:00

A Wauconda, Illinois man was shot and killed by Fox Lake police after lunging at them with a knife, while a woman at the scene who was also shot sustained non-life-threatening injuries.

## 7 appear in Northern Irish court for policeman's attempted murder
 - [https://www.foxnews.com/world/7-appear-northern-irish-court-policemans-attempted-murder](https://www.foxnews.com/world/7-appear-northern-irish-court-policemans-attempted-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 14:05:43+00:00

Seven men, ranging in age from 28 to 72, appeared in a Northern Irish court Monday on attempted murder charges relating to the February shooting of a police officer.

## On Memorial Day, Lee Greenwood remembers America's heroes: 'Never take freedom for granted'
 - [https://www.foxnews.com/lifestyle/memorial-day-lee-greenwood-remembers-americas-heroes-never-take-freedom-granted](https://www.foxnews.com/lifestyle/memorial-day-lee-greenwood-remembers-americas-heroes-never-take-freedom-granted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 14:00:17+00:00

Country music star Lee Greenwood honors America&apos;s servicemen and women on Memorial Day, plants flags on graves of soldiers buried at Normandy. &quot;Never take freedom for granted,&quot; he said.

## President Biden mourns son Beau at Memorial Day ceremony: 'It never gets easier'
 - [https://www.foxnews.com/politics/president-biden-mourns-son-beau-memorial-day-ceremony-never-gets-easier](https://www.foxnews.com/politics/president-biden-mourns-son-beau-memorial-day-ceremony-never-gets-easier)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 13:30:44+00:00

President Biden grieved with Gold Star families during his remarks on Memorial Day 2023, when he observed the anniversary of his son Beau Biden&apos;s death.

## Teen boy drowns at New Jersey beach over Memorial Day weekend; 4 others hospitalized
 - [https://www.foxnews.com/us/teen-boy-drowns-new-jersey-beach-memorial-day-weekend-4-others-hospitalized](https://www.foxnews.com/us/teen-boy-drowns-new-jersey-beach-memorial-day-weekend-4-others-hospitalized)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 13:07:46+00:00

A 15-year-old boy died over the weekend after entering the waters off a Sandy Hook beach in New Jersey. Multiple others were transported to two medical centers.

## Zoo joy: Hearts melt when orangutan 'asks' to see baby through enclosure, then 'kisses' glass
 - [https://www.foxnews.com/lifestyle/zoo-joy-hearts-melt-orangutan-asks-see-baby-enclosure-kisses-glass](https://www.foxnews.com/lifestyle/zoo-joy-hearts-melt-orangutan-asks-see-baby-enclosure-kisses-glass)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 13:00:54+00:00

An orangutan at the Louisville Zoo in Kentucky warmed hearts after she tapped on the glass of her enclosure to try to see a three-month-old baby better — then kissed the glass.

## 'Boycott Target' rap climbs iTunes charts: 'Somebody has to stand up for the kids'
 - [https://www.foxnews.com/media/boycott-target-rap-climbs-itunes-charts-somebody-stand-kids](https://www.foxnews.com/media/boycott-target-rap-climbs-itunes-charts-somebody-stand-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 13:00:39+00:00

Rapper Forgiato Blow joined &quot;Fox &amp; Friends First&quot; to discuss his new song calling out Target&apos;s controversial LGBTQ Pride line for kids

## 'Squad' Democrat senses lack of frustration among Black Americans over reparations: 'People have lost hope'
 - [https://www.foxnews.com/media/squad-democrat-senses-lack-frustration-black-americans-reparations-people-lost-hope](https://www.foxnews.com/media/squad-democrat-senses-lack-frustration-black-americans-reparations-people-lost-hope)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 12:52:14+00:00

Democratic &quot;Squad&quot; member Jamaal Bowman told the New York Times that Black Americans have &quot;lost hope&quot; for reparations because the party hasn&apos;t explained it well.

## Colorado’s Deion Sanders delivers powerful message about ‘success’ in first meeting with ‘new team’
 - [https://www.foxnews.com/sports/colorados-deion-sanders-delivers-powerful-message-about-success-first-meeting-new-team](https://www.foxnews.com/sports/colorados-deion-sanders-delivers-powerful-message-about-success-first-meeting-new-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 12:49:43+00:00

Deion Sanders delivered a powerful message to Colorado&apos;s football team over the weekend after a massive overhaul saw more than 70 players enter the transfer portal since August.

## Can ethical AI surveillance exist? Data scientist Rumman Chowdhury doesn't think so
 - [https://www.foxnews.com/tech/can-ethical-ai-surveillance-exist-rumman-chowdhury-doesnt-think-so](https://www.foxnews.com/tech/can-ethical-ai-surveillance-exist-rumman-chowdhury-doesnt-think-so)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 12:32:40+00:00

Rumman Chowdhury said during a recent talk that she does not believe ethical AI surveillance can exist, noting in a later interview that the issue is hugely concerning to her.

## 2 dead, 2 injured in shooting at Northern Virginia home
 - [https://www.foxnews.com/us/2-dead-2-injured-shooting-northern-virginia-home](https://www.foxnews.com/us/2-dead-2-injured-shooting-northern-virginia-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 12:29:21+00:00

Two men were found dead and two others have been hospitalized following a shooting in Woodbridge, Virginia, just outside Washington, D.C.

## 'Route 66' star George Maharis dead at 94
 - [https://www.foxnews.com/us/route-66-star-george-maharis-dead-94](https://www.foxnews.com/us/route-66-star-george-maharis-dead-94)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 12:25:37+00:00

George Maharis, best known for his starring role in &quot;Route 66,&quot; a television crime drama that premiered over six decades ago, has died. He was 94.

## California detainee breaks hospital window with oxygen tank, falls to death
 - [https://www.foxnews.com/us/california-detainee-breaks-hospital-window-oxygen-tank-falls-death](https://www.foxnews.com/us/california-detainee-breaks-hospital-window-oxygen-tank-falls-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 12:19:58+00:00

A San Jose, California man in police custody reportedly killed himself after breaking through a hospital window with his oxygen tank and falling from the ledge he climbed onto.

## The dark side of PayPal and how to stay safe
 - [https://www.foxnews.com/tech/dark-side-paypal-stay-safe](https://www.foxnews.com/tech/dark-side-paypal-stay-safe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 12:04:44+00:00

PayPal is a very useful payment platform; however, hackers try to exploit the app and steal your information. Kurt &quot;CyberGuy&quot; Knutsson shows you how to stay safe.

## Kohl’s faces shopper uproar after becoming latest retailer to market LGBTQ clothing to children: 'Disgusting'
 - [https://www.foxnews.com/media/kohls-shopper-uproar-latest-retailer-market-lgbtq-clothing-children-disgusting](https://www.foxnews.com/media/kohls-shopper-uproar-latest-retailer-market-lgbtq-clothing-children-disgusting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 11:38:26+00:00

Some customers are calling for a boycott of Kohl&apos;s after the department story became the most recent major retailer to sell LGBTQ merch for babies and kids.

## How to delete photos of your house from real estate websites
 - [https://www.foxnews.com/tech/how-delete-photos-your-house-real-estate-websites](https://www.foxnews.com/tech/how-delete-photos-your-house-real-estate-websites)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 11:33:00+00:00

Kurt &quot;The CyberGuy&quot; Knutsson walks homeowners through how to remove photos of your house from real estate websites, to ensure your at-home privacy.

## White Sox' Liam Hendriks set to return months after cancer diagnosis
 - [https://www.foxnews.com/sports/white-sox-liam-hendriks-set-return-months-cancer-diagnosis](https://www.foxnews.com/sports/white-sox-liam-hendriks-set-return-months-cancer-diagnosis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 11:32:38+00:00

Chicago White Sox closer Liam Hendriks, who was diagnosed in January with stage 4 non-Hodgkin lymphoma, is set to return to the active active roster, the team announced Sunday.

## Woman's $3,700 camera was accidentally donated to Goodwill — here's what happened next
 - [https://www.foxnews.com/lifestyle/womans-3700-camera-accidentally-donated-goodwill-happened-next](https://www.foxnews.com/lifestyle/womans-3700-camera-accidentally-donated-goodwill-happened-next)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 11:26:18+00:00

A 23-year-old amateur photographer from San Diego, California, took to TikTok after her mom accidentally dropped off her $3,700 camera at an Arizona Goodwill. Here&apos;s what happened.

## Georgia prison guard, jail nurse charged with giving inmates contraband
 - [https://www.foxnews.com/us/georgia-prison-guard-jail-nurse-charged-giving-inmates-contraband](https://www.foxnews.com/us/georgia-prison-guard-jail-nurse-charged-giving-inmates-contraband)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 11:13:03+00:00

Clayton County, Georgia corrections officer Tabitha Clifton and jail nurse Jessica Castellanos have been arrested and charged with supplying contraband to prisoners.

## Ron DeSantis reflects on Navy career, warns military is ‘different’ from when he served
 - [https://www.foxnews.com/media/ron-desantis-navy-career-warns-military-different](https://www.foxnews.com/media/ron-desantis-navy-career-warns-military-different)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 11:02:17+00:00

2024 presidential candidate Gov. Ron DeSantis warned on Memorial Day that leftist ideologies are driving away potential military recruits and lowering morale.

## Paris Saint-Germain's Sergio Rico 'fighting to recover' after being hit by a horse in Spain
 - [https://www.foxnews.com/sports/paris-saint-germains-sergio-rico-fighting-recover-after-being-hit-by-horse-spain](https://www.foxnews.com/sports/paris-saint-germains-sergio-rico-fighting-recover-after-being-hit-by-horse-spain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 10:39:39+00:00

Paris Saint-Germain goalkeeper Sergio Rico suffered an apparent head injury after being in an accident in Spain involving a horse, his representatives revealed Sunday.

## Saudi Arabia executes 2 alleged Bahraini militants after 'grossly unfair' trial
 - [https://www.foxnews.com/world/saudi-arabia-executes-2-alleged-bahraini-militants-grossly-unfair-trial](https://www.foxnews.com/world/saudi-arabia-executes-2-alleged-bahraini-militants-grossly-unfair-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 10:36:55+00:00

Saudi Arabia claims to have executed two Bahraini men the kingdom claims belonged to a militant group intent on destabilizing the neighboring Mideastern countries&apos; governments.

## Russia issues Lindsey Graham arrest warrant after Ukraine comments
 - [https://www.foxnews.com/politics/russia-issues-lindsey-graham-arrest-warrant-ukraine-comments](https://www.foxnews.com/politics/russia-issues-lindsey-graham-arrest-warrant-ukraine-comments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 10:36:22+00:00

Russia&apos;s Interior Ministry issued a warrant for South Carolina GOP Sen. Lindsey Graham&apos;s arrest on Monday for comments he made on a visit to Ukraine.

## Uganda greenlights death penalty for 'aggravated homosexuality' in controversial crackdown
 - [https://www.foxnews.com/world/uganda-greenlights-death-penalty-aggravated-homosexuality-controversial-crackdown](https://www.foxnews.com/world/uganda-greenlights-death-penalty-aggravated-homosexuality-controversial-crackdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 10:33:58+00:00

Ugandan President Yoweri Museveni has approved a bill that, while not outright criminalizing LGBTQ identification, imposes grave penalties for homosexuals convicted of sex crimes.

## Wedding drama erupts as bride's anger at guest who wore white turns 'blue'
 - [https://www.foxnews.com/lifestyle/wedding-drama-brides-anger-guest-who-wore-white-turns-blue](https://www.foxnews.com/lifestyle/wedding-drama-brides-anger-guest-who-wore-white-turns-blue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 10:32:11+00:00

A wedding drama was described in detail in a social media post on Reddit — with thousands weighing in. A bride, upset when a guest wore white to her wedding, was able to &quot;fix&quot; the issue.

## Wild video shows Charlotte bus driver, passenger shooting at each other after argument
 - [https://www.foxnews.com/us/wild-video-shows-charlotte-bus-driver-passenger-shooting-each-other-argument](https://www.foxnews.com/us/wild-video-shows-charlotte-bus-driver-passenger-shooting-each-other-argument)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 10:27:54+00:00

A North Carolina bus driver and passenger suffered gunshot wounds during a shootout on the bus that ensued after the passenger requested a &quot;not-assigned bus stop.&quot;

## Christian teacher banned from teaching for 'misgendering' student: 'Just one view allowed' on gender
 - [https://www.foxnews.com/media/christian-teacher-banned-teaching-misgendering-student-one-view-allowed-gender](https://www.foxnews.com/media/christian-teacher-banned-teaching-misgendering-student-one-view-allowed-gender)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 10:00:36+00:00

UK math teacher Joshua Sutcliffe has been banned from teaching by a regulatory agency under the UK&apos;s Department of Education for &apos;misgendering&apos; a student.

## Bigoted Dems ignore Tim Scott's character and instead attack color of his skin
 - [https://www.foxnews.com/opinion/bigoted-dems-ignore-tim-scotts-character-instead-attack-color-skin](https://www.foxnews.com/opinion/bigoted-dems-ignore-tim-scotts-character-instead-attack-color-skin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 10:00:18+00:00

Bigoted Dems ignore Tim Scott&apos;s character and instead attack color of his skin. New presidential candidate victimized by relentless assault from left and media.

## Public cost of Atlanta's 'Cop City' more than doubled in new estimate
 - [https://www.foxnews.com/politics/public-cost-atlantas-cop-city-more-doubled-new-estimate](https://www.foxnews.com/politics/public-cost-atlantas-cop-city-more-doubled-new-estimate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 10:00:06+00:00

Atlanta&apos;s proposed police and fire training facility, commonly dubbed &quot;Cop City&quot; by detractors, is expected to require $36 million more in public funds than previously estimated.

## Memorial Day cocktail and mocktail recipes to enjoy in the sun this holiday weekend
 - [https://www.foxnews.com/lifestyle/memorial-day-cocktail-mocktail-recipes](https://www.foxnews.com/lifestyle/memorial-day-cocktail-mocktail-recipes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 09:51:09+00:00

Memorial Day is acknowledged by millions of Americans across the country. Whether poolside or on a porch, give thanks to the men and women who gave their lives.

## Maryland duo get 40 years for killing, dismembering roommate after crack-fueled fight
 - [https://www.foxnews.com/us/maryland-duo-40-years-killing-dismembering-roommate-crack-fueled-fight](https://www.foxnews.com/us/maryland-duo-40-years-killing-dismembering-roommate-crack-fueled-fight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 09:46:58+00:00

Christina Harnish and William Rice have been sentenced to 40 years in prison for the second-degree murder of former roommate Megan Tilman of Annapolis, Maryland.

## New Mexico man charged with murder after biker gang shootout leaves 3 dead
 - [https://www.foxnews.com/us/new-mexico-man-charged-murder-biker-gang-shootout-leaves-3-dead](https://www.foxnews.com/us/new-mexico-man-charged-murder-biker-gang-shootout-leaves-3-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 09:35:06+00:00

New Mexico police said Sunday that three men who were killed during a shootout at a motorcycle rally were identified as members of outlaw biker gangs.

## Memorial Day 2023: Recipes for the grill and barbecue 101 tips to serve this holiday weekend
 - [https://www.foxnews.com/lifestyle/grilling-recipes-cook-barbecue-friends-family](https://www.foxnews.com/lifestyle/grilling-recipes-cook-barbecue-friends-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 09:25:25+00:00

On Memorial Day this year, spend the holiday with friends and family by cooking them delicious summer recipes in your backyard with your favorite grill. Here&apos;s how.

## Nigeria's Tinubu sworn in as president amid social, political turmoil
 - [https://www.foxnews.com/world/nigerias-tinubu-sworn-president-social-political-turmoil](https://www.foxnews.com/world/nigerias-tinubu-sworn-president-social-political-turmoil)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 09:13:30+00:00

Bola Tinubu has been sworn in as Nigeria&apos;s president, succeeding Muhammadu Buhari and left to address significant socioeconomic and national security grievances.

## Here's why America's Memorial Day car parades are great
 - [https://www.foxnews.com/auto/memorial-day-car-parades](https://www.foxnews.com/auto/memorial-day-car-parades)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 09:13:13+00:00

Many Americans volunteer their cars each year to help transport veterans who need assistance along the routes of their local Memorial Day parade.

## Juneteenth event banner featuring White couple in South Carolina sparks outrage: 'I was appalled'
 - [https://www.foxnews.com/media/juneteenth-event-banner-featuring-white-couple-south-carolina-sparks-outrage-appalled](https://www.foxnews.com/media/juneteenth-event-banner-featuring-white-couple-south-carolina-sparks-outrage-appalled)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 09:00:56+00:00

A South Carolina Juneteenth banner faced backlash after depicting a white couple to promote an upcoming event caused an uproar for a social justice organization.

## MI woman accused of defacing religious centers tried to frame Ukrainian militia: police
 - [https://www.foxnews.com/us/mi-woman-accused-defacing-religious-centers-tried-frame-ukrainian-militia-police](https://www.foxnews.com/us/mi-woman-accused-defacing-religious-centers-tried-frame-ukrainian-militia-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 08:44:35+00:00

Police claim a woman vandalized two Detroit-area houses of worship with Nazi symbols and the word &quot;Azov&quot; to stoke anti-Ukrainian sentiment in the U.S.

## Vermont Gov. Scott vetoes $8B budget that would have been state's largest ever
 - [https://www.foxnews.com/politics/vermont-gov-scott-vetoes-8b-budget-states-largest-ever](https://www.foxnews.com/politics/vermont-gov-scott-vetoes-8b-budget-states-largest-ever)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 08:41:09+00:00

Republican Vermont Gov. Phil Scott has vetoed a proposed state budget of over $8 billion, calling on Democratic General Assembly supermajorities to cooperate with him in revising it.

## 3 wounded, gunman dead in shooting outside Texas strip club
 - [https://www.foxnews.com/us/3-wounded-gunman-dead-shooting-texas-strip-club](https://www.foxnews.com/us/3-wounded-gunman-dead-shooting-texas-strip-club)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 08:40:43+00:00

A shooting in the parking lot of Temptations Cabaret in Tarrant County, Texas, left three people wounded and reportedly followed an altercation inside the establishment.

## Texas crackdown on drag performances with minors present reaches Gov. Abbott's desk
 - [https://www.foxnews.com/politics/texas-crackdown-drag-performances-minors-present-reaches-gov-abbotts-desk](https://www.foxnews.com/politics/texas-crackdown-drag-performances-minors-present-reaches-gov-abbotts-desk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 08:40:19+00:00

A Texas bill restricting sexually-charged performances in public, which drag artists worry may criminalize their shows, has cleared the Legislature and is expected to become law.

## NY Times ripped for piece lamenting lack of 'kink' in new 'Little Mermaid': 'The left sexualizes kids'
 - [https://www.foxnews.com/media/ny-times-ripped-piece-lamenting-kink-new-little-mermaid-left-sexualizes-kids](https://www.foxnews.com/media/ny-times-ripped-piece-lamenting-kink-new-little-mermaid-left-sexualizes-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 08:35:20+00:00

A New York Times review that argued &quot;kink&quot; was missing from &quot;The Little Mermaid&quot; remake has divided movie critics and political commentators online.

## Honor the fallen this Memorial Day, but remember to check on vets and active duty troops still with us
 - [https://www.foxnews.com/opinion/honor-fallen-memorial-day-remember-check-vets-active-duty-troops](https://www.foxnews.com/opinion/honor-fallen-memorial-day-remember-check-vets-active-duty-troops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 08:00:48+00:00

A recent report found that the veteran suicide rate per day is closer to 44 deaths. That&apos;s more than double the Veterans Affairs&apos; report of 17 per day

## Miss Oregon USA Manju Bangalore is headed to space: A 'dream come true'
 - [https://www.foxnews.com/entertainment/miss-oregon-usa-manju-bangalore-headed-space-dream-true](https://www.foxnews.com/entertainment/miss-oregon-usa-manju-bangalore-headed-space-dream-true)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 08:00:39+00:00

Miss Oregon USA, Manju Bangalore, is excited to announce she will be travelling to space in August and will experience weightlessness for eight minutes.

## Mexico accused of financing Cuban regime by sponsoring 'slave' medical missions
 - [https://www.foxnews.com/world/mexico-accused-financing-cuban-regime-sponsoring-slave-medical-missions](https://www.foxnews.com/world/mexico-accused-financing-cuban-regime-sponsoring-slave-medical-missions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 08:00:23+00:00

Cuba spreads socialism by sending &quot;doctors&quot; to its allied countries, many of whom are reportedly members of the military and intelligence service of the dictatorship.

## Georgia Medal of Honor recipient's family believed he would never be found; now his remains are home
 - [https://www.foxnews.com/us/georgia-medal-honor-recipients-family-believed-he-would-never-be-found-his-remains-home](https://www.foxnews.com/us/georgia-medal-honor-recipients-family-believed-he-would-never-be-found-his-remains-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 07:59:32+00:00

The remains of Army Pfc. Luther Herschel Story, 18, have returned home to Georgia. A burial for the soldier, who is a Medal of Honor recipient, was slated for Memorial Day.

## Republicans win on the debt ceiling: Here's why House GOP should support deal
 - [https://www.foxnews.com/opinion/republicans-win-debt-ceiling-heres-why-house-gop-should-support-deal](https://www.foxnews.com/opinion/republicans-win-debt-ceiling-heres-why-house-gop-should-support-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 07:00:53+00:00

The debt ceiling agreement is a step toward creating a smaller government, lower taxes, less regulation, economic growth, prosperity, and more take home pay.

## Questions face family that claimed they adopted adult ‘masquerading’ as 6-year-old: lawyer
 - [https://www.foxnews.com/us/questions-face-family-who-claimed-they-adopted-adult-masquerading-as-6-year-old-lawyer](https://www.foxnews.com/us/questions-face-family-who-claimed-they-adopted-adult-masquerading-as-6-year-old-lawyer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 07:00:49+00:00

Fox News Digital spoke with the attorney featured in a docuseries called &quot;The Curious Case of Natalia Grace,&quot; diving into the allegations that were made against Natalia Grace.

## Target marketing VP holds senior position at org pushing secretive transgender policies in K-12 schools
 - [https://www.foxnews.com/media/target-vp-marketing-holds-senior-position-at-org-pushing-transgender-agenda-into-k-12-public-schools](https://www.foxnews.com/media/target-vp-marketing-holds-senior-position-at-org-pushing-transgender-agenda-into-k-12-public-schools)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 07:00:39+00:00

Target Corporation&apos;s VP of brand marketing is the treasurer of national K-12 org called GLSEN, which advocates for schools to keep parents in the dark on gender transitions.

## Hunter Biden's 'sugar brother' keeps the first son afloat amid multiple scandals
 - [https://www.foxnews.com/politics/hunter-bidens-sugar-brother-keeps-first-son-afloat-amid-multiple-scandals](https://www.foxnews.com/politics/hunter-bidens-sugar-brother-keeps-first-son-afloat-amid-multiple-scandals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 06:50:23+00:00

Amid a federal investigation into his finances and overseas business dealings, Hunter Biden has been turning to a Hollywood mega-lawyer for money and strategic advice.

## Former chief scientist at Georgia Tech Research Institute pleads guilty to defrauding university, CIA
 - [https://www.foxnews.com/us/former-chief-scientist-georgia-tech-research-institute-pleads-guilty-defrauding-university-cia](https://www.foxnews.com/us/former-chief-scientist-georgia-tech-research-institute-pleads-guilty-defrauding-university-cia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 06:04:51+00:00

The former chief scientist at the Georgia Tech Research Institute pleaded guilty to conspiring to defraud Georgia Tech and the CIA from 2007 until 2013.

## No new service members added to Army memorial wall for first time since 9/11
 - [https://www.foxnews.com/us/no-new-service-members-added-army-memorial-the-first-time-since-9/11](https://www.foxnews.com/us/no-new-service-members-added-army-memorial-the-first-time-since-9/11)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 06:00:49+00:00

The U.S. Army Special Operations Command memorial wall at Fort Bragg, North Carolina, did not see a new name added this year for the first time since 9/11

## 'Duck Dynasty's' Willie Robertson: Memorial Day is about ‘remembering our fallen soldiers’
 - [https://www.foxnews.com/entertainment/duck-dynastys-willie-robertson-memorial-day-about-remembering-our-fallen-soldiers](https://www.foxnews.com/entertainment/duck-dynastys-willie-robertson-memorial-day-about-remembering-our-fallen-soldiers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 06:00:43+00:00

Willie Robertson shared his thoughts on Memorial Day, comparing the sacrifice the soldiers made to Jesus&apos; story and his sacrifice, saying it is the &quot;closest representation&quot; of &quot;the Gospel.&quot;

## Female athletes are retiring after competing against biological men, track champion warns: 'It's devastating'
 - [https://www.foxnews.com/media/female-athletes-retiring-competing-against-biological-men-track-champion-warns-its-devastating](https://www.foxnews.com/media/female-athletes-retiring-competing-against-biological-men-track-champion-warns-its-devastating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 06:00:29+00:00

Track athlete Selina Soule discussed her lawsuit against Connecticut&apos;s &quot;unfair&quot; transgender sports policy that she says puts female athletes at a disadvantage.

## I truly understood Memorial Day when I became part of this Gold Star family
 - [https://www.foxnews.com/opinion/truly-understood-memorial-day-became-part-gold-star-family](https://www.foxnews.com/opinion/truly-understood-memorial-day-became-part-gold-star-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 06:00:11+00:00

Often we think we understand something, only to find out we just skimmed the surface. The observance of Memorial Day was one of those things for me.

## Iowa apartment building partially collapses, prompting massive rescue effort
 - [https://www.foxnews.com/us/iowa-apartment-building-partially-collapses-prompting-massive-rescue-effort](https://www.foxnews.com/us/iowa-apartment-building-partially-collapses-prompting-massive-rescue-effort)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 05:50:00+00:00

Davenport Mayor Mike Matson said authorities are continuing to try and rescue victims after an apartment building partially collapsed Sunday afternoon.

## North Korea tells neighboring Japan of plans to launch satellite, safety warning issued
 - [https://www.foxnews.com/world/north-korea-tells-neighboring-japan-plans-launch-satellite-safety-warning-issued](https://www.foxnews.com/world/north-korea-tells-neighboring-japan-plans-launch-satellite-safety-warning-issued)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 05:35:15+00:00

North Korea notified neighboring Japan on Monday that it expects to launch a satellite in the coming days, which would require long-range missile technology.

## Chicago toddler shoots herself after finding gun at home in Rogers Park neighborhood: police
 - [https://www.foxnews.com/us/chicago-toddler-shoots-herself-after-finding-gun-home-rogers-park-neighborhood-police](https://www.foxnews.com/us/chicago-toddler-shoots-herself-after-finding-gun-home-rogers-park-neighborhood-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 05:04:02+00:00

Police said a 2-year-old girl in Chicago&apos;s Rogers Park neighborhood shot herself in the hand after finding an unsecured firearm at a home Sunday night.

## CUNY Law commencement speaker claims laws are 'White supremacy,' attacks 'fascist' police and military
 - [https://www.foxnews.com/media/cuny-law-commencement-speaker-claims-laws-white-supremacy-attacks-fascist-police-military](https://www.foxnews.com/media/cuny-law-commencement-speaker-claims-laws-white-supremacy-attacks-fascist-police-military)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 05:00:56+00:00

City University of New York (CUNY) Law school speaker blasts America for its &apos;oppression&apos; of Black and brown communities and calls for a &apos;revolution.&apos;

## Memorial Day 2023: Note on a white stone cross
 - [https://www.foxnews.com/opinion/memorial-day-2023-note-white-stone-cross](https://www.foxnews.com/opinion/memorial-day-2023-note-white-stone-cross)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 05:00:28+00:00

I served as a Navy SEAL. I have felt the loss of losing a brother in arms and remember on this Memorial Day 2023.

## Sen. Dianne Feinstein confused by VP Kamala Harris' participation in tie-breaking vote: report
 - [https://www.foxnews.com/politics/sen-dianne-feinstein-confused-vp-kamala-harris-participation-tie-breaking-vote-report](https://www.foxnews.com/politics/sen-dianne-feinstein-confused-vp-kamala-harris-participation-tie-breaking-vote-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 04:18:48+00:00

California Sen. Dianne Feinstein was reportedly confused last year during a tie-breaking vote in which Vice President Kamala Harris had to preside over the Senate.

## Tom Brady, Oprah, Gwyneth Paltrow diets analyzed: Expert reveals 'emotional rollercoaster' with fad dieting
 - [https://www.foxnews.com/entertainment/tom-brady-oprah-gwyneth-paltrow-diets-analyzed-expert-reveals-emotional-rollercoaster-fad-dieting](https://www.foxnews.com/entertainment/tom-brady-oprah-gwyneth-paltrow-diets-analyzed-expert-reveals-emotional-rollercoaster-fad-dieting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 04:00:45+00:00

From limiting carbohydrates to fruit-based diets and intermittent fasting, celebrity nutrition expert reveals which diets work and which to avoid.

## San Francisco business owners and residents talk drug, crime crisis: ‘Zombie apocalypse,' ‘dystopia’
 - [https://www.foxnews.com/media/san-francisco-business-owners-residents-talk-drug-crime-crisis-zombie-apocalypse-dystopia](https://www.foxnews.com/media/san-francisco-business-owners-residents-talk-drug-crime-crisis-zombie-apocalypse-dystopia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 04:00:14+00:00

Residents and business owners in San Francisco gave personal stories of homelessness, drug addiction and crime in a city that many said is changing for the worse.

## Florida National Guard troops 'proud to help’ fight Texas border crisis, DeSantis says
 - [https://www.foxnews.com/politics/florida-national-guard-troops-proud-help-fight-texas-border-crisis-desantis-says](https://www.foxnews.com/politics/florida-national-guard-troops-proud-help-fight-texas-border-crisis-desantis-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 03:26:08+00:00

Texas Gov. Greg Abbott thanked Florida Gov. Ron DeSantis for sending National Guard troops to the United States-Mexico border to help combat the flow of migrants.

## The 'New Opium War': America's deadly fentanyl invasion could be China's revenge for 'century of humiliation'
 - [https://www.foxnews.com/lifestyle/new-opium-war-americas-deadly-fentanyl-invasion-chinas-revenge-humiliation](https://www.foxnews.com/lifestyle/new-opium-war-americas-deadly-fentanyl-invasion-chinas-revenge-humiliation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 03:00:42+00:00

China fought two Opium Wars with Europe in the 1800s while suffering a crisis of opium addiction. Is it now seeking revenge by flooding the U.S. with synthetic opioids today?

## Memorial Day requires reflection and reverence for those who laid down their lives for freedom: lawmakers
 - [https://www.foxnews.com/politics/memorial-day-requires-reflection-reverence-laid-lives-freedom-lawmakers-say](https://www.foxnews.com/politics/memorial-day-requires-reflection-reverence-laid-lives-freedom-lawmakers-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 02:30:58+00:00

Democrats and Republicans, veterans and civilians share why it&apos;s important to reflect on the sacrifices U.S. soldiers have made to protect our shared freedoms.

## AI in dentistry: Researchers find that artificial intelligence can create better dental crowns
 - [https://www.foxnews.com/health/ai-dentistry-researchers-find-artificial-intelligence-create-better-dental-crowns](https://www.foxnews.com/health/ai-dentistry-researchers-find-artificial-intelligence-create-better-dental-crowns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 02:00:18+00:00

Researchers from the University of Hong Kong developed an AI algorithm that uses 3D machine learning to design personalized dental crowns with a higher degree of accuracy than traditional methods.

## Amusement park mayhem: 4 times outdoor fun descended into horrifying chaos
 - [https://www.foxnews.com/us/amusement-park-mayhem-times-outdoor-fun-descended-horrifying-chaos](https://www.foxnews.com/us/amusement-park-mayhem-times-outdoor-fun-descended-horrifying-chaos)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 02:00:04+00:00

Memorial Day marks the unofficial start to summer, meaning there will be more families headed to amusement parks across America in coming months.

## Republican Rep. Rosendale to vote against $4 trillion debt ceiling deal: 'Insult to the American people'
 - [https://www.foxnews.com/politics/republican-rep-rosendale-vote-against-4-trillion-debt-ceiling-deal-insult-american-people](https://www.foxnews.com/politics/republican-rep-rosendale-vote-against-4-trillion-debt-ceiling-deal-insult-american-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 01:09:56+00:00

House Republicans are starting to weigh in on the &quot;Fiscal Responsibility Act,&quot; the newly revealed debt ceiling deal negotiated between President Biden and Speaker McCarthy.

## Republicans secure massive gas pipeline approval in debt ceiling deal
 - [https://www.foxnews.com/politics/republicans-secure-massive-gas-pipeline-approval-debt-ceiling-deal](https://www.foxnews.com/politics/republicans-secure-massive-gas-pipeline-approval-debt-ceiling-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 00:37:01+00:00

The budget deal reached by President Biden and House Republicans on Sunday unexpectedly approves a massive natural gas pipeline vehemently opposed by climate activists.

## On this day in history, May 29, 1851, Sojourner Truth delivers famed 'Ain’t I a Woman' speech
 - [https://www.foxnews.com/lifestyle/this-day-history-may-29-1851-sojourner-truth-delivers-aint-i-woman-speech](https://www.foxnews.com/lifestyle/this-day-history-may-29-1851-sojourner-truth-delivers-aint-i-woman-speech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 00:02:07+00:00

African American abolitionist and women&apos;s right advocate Sojourner Truth delivered her famous &quot;Ain&apos;t I a Woman?&quot; speech on this day in history, May 29, 1851, in Akron, Ohio.

## Grilled teriyaki chicken pineapple skewers: Try the recipe
 - [https://www.foxnews.com/food-drink/grilled-teriyaki-chicken-pineapple-skewers-recipe](https://www.foxnews.com/food-drink/grilled-teriyaki-chicken-pineapple-skewers-recipe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-29 00:00:45+00:00

These tasty teriyaki chicken pineapple skewers are a perfect way to celebrate the summer grilling season. Here&apos;s how you can make them at home, according to the Slofoodgroup.

