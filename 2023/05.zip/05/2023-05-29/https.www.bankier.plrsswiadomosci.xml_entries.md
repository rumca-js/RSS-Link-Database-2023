# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## "Mamy obsesję na punkcie jakości". Znamy najlepsze banki 2023 - zwycięzców rankingu Złoty Bankier
 - [https://www.bankier.pl/wiadomosc/Najlepsze-banki-2023-Zloty-Bankier-wyniki-rankingu-8549114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-banki-2023-Zloty-Bankier-wyniki-rankingu-8549114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 19:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/f92a41ee676a50-948-568-0-105-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zmiana lidera jakości obsługi klienta, nowa kategoria w części produktowej rankingu i pożegnanie z inną - to tylko niektóre zaskoczenia finału 14. edycji rankingu Złoty Bankier organizowanego przez Bankier.pl i "Puls Biznesu". Poznajcie laureatów największego badania sektora bankowego w kraju.</p>

## Euractiv: Leyen i skandal polityczny w Bułgarii. "Musisz wymyślić, jak obejść zasady"
 - [https://www.bankier.pl/wiadomosc/Euractiv-Leyen-i-skandal-polityczny-w-Bulgarii-Musisz-wymyslic-jak-obejsc-zasady-8549862.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Euractiv-Leyen-i-skandal-polityczny-w-Bulgarii-Musisz-wymyslic-jak-obejsc-zasady-8549862.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 18:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/61d86166e5c2cb-948-568-0-10-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nazwisko przewodniczącej Komisji Europejskiej Ursuli von der Leyen zostało przywołane w najnowszym skandalu politycznym w Bułgarii. W 5-godzinnym nagraniu były premier Kirił Petkow relacjonuje swoim kolegom z partii m.in. przebieg dyskusji z von der Leyen na temat uczestnictwa Bułgarii w Schengen i strefie euro – podaje portal Euractiv.</p>

## Prezydent Ugandy podpisał jedną z najsurowszych ustaw antyLGBT na świecie. Zachód zapowiada sankcje
 - [https://www.bankier.pl/wiadomosc/Prezydent-Ugandy-podpisal-jedna-z-najsurowszych-ustaw-antyLGBT-na-swiecie-Zachod-zapowiada-sankcje-8549853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-Ugandy-podpisal-jedna-z-najsurowszych-ustaw-antyLGBT-na-swiecie-Zachod-zapowiada-sankcje-8549853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 18:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/9a2b6a3e6ba6d8-948-568-0-70-1766-1059.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Ugandy Yoveri Museveni podpisał w poniedziałek ustawę penalizującą homoseksualizm, jego propagowanie oraz nie informowanie władz o znanych związkach homoseksualnych - poinformowała agencja Reutera. Stany Zjednoczone natychmiast zagroziły Ugandzie sankcjami, Holandia wstrzymała pomoc finansową.</p>

## Ciech otrzymał decyzję dot. podatku spółki zależnej; oczekuje zwrotu podatku i odsetek
 - [https://www.bankier.pl/wiadomosc/Ciech-otrzymal-decyzje-dot-podatku-spolki-zaleznej-oczekuje-zwrotu-podatku-i-odsetek-8549809.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ciech-otrzymal-decyzje-dot-podatku-spolki-zaleznej-oczekuje-zwrotu-podatku-i-odsetek-8549809.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 17:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/a2d1785f5b419d-945-560-0-50-987-592.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ciech otrzymał decyzję Dyrektora Izby Administracji Skarbowej w Rzeszowie w sprawie podatku dochodowego spółki zależnej - Ciech Sarzyna - i oczekuje, że zapłacone kwoty podatku w wysokości 4,7 mln zł oraz 0,8 mln zł odsetek za zwłokę zostaną im zwrócone - podał Ciech w komunikacie.</p>

## Polska zamknie granicę z Białorusią dla białoruskich i rosyjskich ciężarówek i naczep
 - [https://www.bankier.pl/wiadomosc/Polska-zamknie-granice-z-Bialorusia-dla-bialoruskich-i-rosyjskich-ciezarowek-i-naczep-8549782.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-zamknie-granice-z-Bialorusia-dla-bialoruskich-i-rosyjskich-ciezarowek-i-naczep-8549782.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 16:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/3198b1550032ff-948-568-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 1 czerwca do odwołania ruch towarowy na granicy z Białorusią zostanie zawieszony dla ciężarówek, ciągników samochodowych, przyczep, w tym naczep, oraz zespołów pojazdów zarejestrowanych na terytorium Białorusi i Rosji - stanowi rozporządzenie MSWiA.</p>

## USA o krok od bankructwa. Podwyższenie limitu długu na czas może być utrudnione
 - [https://www.bankier.pl/wiadomosc/USA-o-krok-od-bankructwa-Podwyzszenie-limitu-dlugu-na-czas-moze-byc-utrudnione-8549780.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-o-krok-od-bankructwa-Podwyzszenie-limitu-dlugu-na-czas-moze-byc-utrudnione-8549780.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 16:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/ee1851a2298f1c-948-568-8-141-3534-2120.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mimo wynegocjowanego przez prezydenta i spikera Izby 
Reprezentantów porozumienia w sprawie podniesienia limitu długu 
kongresmeni ze skrajnych skrzydeł obydwu partii głośno okazują swoje 
niezadowolenie - podają w poniedziałek media. Według Politico może to 
znacznie utrudnić przyjęcie ustawy na czas, by uniknąć niewypłacalności.</p>

## CD Projekt pokazał wyniki. Spółka sprzedał ponad 50 mln kopii gry "Wiedźmin 3"
 - [https://www.bankier.pl/wiadomosc/CD-Projekt-sprzedal-ponad-50-mln-kopii-gry-Wiedzmin-3-prezentacja-8549768.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/CD-Projekt-sprzedal-ponad-50-mln-kopii-gry-Wiedzmin-3-prezentacja-8549768.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 16:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/4/d4cc6c000c8a19-948-568-0-0-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />CD Projekt pokazał wyniki za I kwartał 2023 
roku. Przychody grupy wyniosły 175 mln zł, a skonsolidowany zysk netto 
osiągnął poziom 70 mln zł.</p>

## Niewielkie obroty, niska zmienność i tajemnicze wzrosty CD Projektu
 - [https://www.bankier.pl/wiadomosc/Niewielkie-obroty-niska-zmiennosc-i-tajemnicze-wzrosty-CD-Projektu-8549709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niewielkie-obroty-niska-zmiennosc-i-tajemnicze-wzrosty-CD-Projektu-8549709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 16:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/fe1bea4e41e75a-948-568-31-42-4224-2534.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Giełdowy tydzień rozpoczęliśmy przy nieobecności inwestorów
z Wall Street i londyńskiego City. Na warszawskim parkiecie odbiło się to w
postaci wyraźnie zimniejszych obrotów.</p>

## Koniec Twittera w UE coraz bliższy? Firma wycofała się sojuszu dotyczącego dezinformacji
 - [https://www.bankier.pl/wiadomosc/Koniec-Twittera-w-UE-coraz-blizszy-Firma-wycofala-sie-sojuszu-dotyczacego-dezinformacji-8549711.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-Twittera-w-UE-coraz-blizszy-Firma-wycofala-sie-sojuszu-dotyczacego-dezinformacji-8549711.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 15:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/1/82577fc2642bee-948-568-0-116-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Twitter zostanie wyrzucony z UE w przypadku 
naruszenia jej zasad - oświadczył w poniedziałek francuski minister 
Jean-Noel Barrot odpowiedzialny za transformację cyfrową i 
telekomunikację w wywiadzie dla telewizji France Info.</p>

## Wielka Brytania walczy z plastikiem. Batoniki Mars są testowo sprzedawane w papierowych opakowaniach
 - [https://www.bankier.pl/wiadomosc/Wielka-Brytania-walczy-z-plastikiem-Batoniki-Mars-sa-testowo-sprzedawane-w-papierowych-opakowaniach-8549697.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wielka-Brytania-walczy-z-plastikiem-Batoniki-Mars-sa-testowo-sprzedawane-w-papierowych-opakowaniach-8549697.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 15:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/11e130c8bec1e7-948-568-0-110-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od poniedziałku batoniki Mars są testowo sprzedawane w Wielkiej Brytanii w papierowych, nadających się do recyklingu opakowaniach, a nie z tworzywa sztucznego.</p>

## Powstanie Wyższa Szkoła Straży Granicznej. Prezydent Andrzej Duda podpisał ustawę
 - [https://www.bankier.pl/wiadomosc/Powstanie-Wyzsza-Szkola-Strazy-Granicznej-Prezydent-Andrzej-Duda-podpisal-ustawe-8549696.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powstanie-Wyzsza-Szkola-Strazy-Granicznej-Prezydent-Andrzej-Duda-podpisal-ustawe-8549696.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 15:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/65b9f57108dbb2-948-568-6-0-1362-817.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda podpisał ustawę, która umożliwi powołanie Wyższej Szkoły Straży Granicznej w Koszalinie, a także zmieni nazwy Wyższej Szkoły Policji i Szkoły Głównej Służby Pożarniczej na Akademię Policji w Szczytnie i Akademię Pożarnicza. Ta ustawa ma historyczne znaczenie - powiedział.</p>

## Ekonomista: Spadek inflacji w Polsce mocno wyhamuje w 2024 roku; efekt obietnic wyborczych będzie istotny
 - [https://www.bankier.pl/wiadomosc/Ekonomista-Spadek-inflacji-w-Polsce-mocno-wyhamuje-w-2024-roku-efekt-obietnic-wyborczych-bedzie-istotny-8549644.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekonomista-Spadek-inflacji-w-Polsce-mocno-wyhamuje-w-2024-roku-efekt-obietnic-wyborczych-bedzie-istotny-8549644.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 14:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/6/c926b99a57a434-948-568-0-176-1722-1033.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Drugi kwartał będzie prawdopodobnie punktem przełomu w polskiej gospodarce, po dołku na początku roku kolejne kwartały przyniosą stopniowe ożywienie - ocenia główny ekonomista Citi Handlowego Piotr Kalisz. Choć w kolejnych miesiącach inflacja w Polsce będzie dość dynamicznie spadać, to w 2024 r. obniżanie się CPI mocno wyhamuje.</p>

## MF zapewnia: dalej chcemy upraszczać prawo podatkowe
 - [https://www.bankier.pl/wiadomosc/MF-zapewnia-dalej-chcemy-upraszczac-prawo-podatkowe-8549616.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MF-zapewnia-dalej-chcemy-upraszczac-prawo-podatkowe-8549616.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 14:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/d43fc4550a091c-948-568-0-56-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W najbliższych miesiącach chcemy kontynuować uszczelnianie systemu podatkowego, dalej upraszczać prawo podatkowe, wprowadzać nowe technologie – zadeklarował w poniedziałek w Warszawie dyrektor departamentu polityki podatkowej w Ministerstwie Finansów Marcin Lachowicz.</p>

## Comarch chce wypłacić 4 zł dywidendy na akcję
 - [https://www.bankier.pl/wiadomosc/Comarch-chce-wyplacic-4-zl-dywidendy-na-akcje-8549599.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Comarch-chce-wyplacic-4-zl-dywidendy-na-akcje-8549599.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 13:40:00+00:00

<p>Rada nadzorcza Comarchu pozytywnie zaopiniowała wniosek zarządu, aby z zysku osiągniętego w 2022 roku na dywidendę trafiło 32,5 mln zł, co daje 4 zł na akcję - poinformowała spółka w komunikacie.</p>

## Polska wpisała setki przedstawicieli białoruskiego reżimu na listę sankcyjną
 - [https://www.bankier.pl/wiadomosc/Polska-wpisala-setki-przedstawicieli-bialoruskiego-rezimu-na-liste-sankcyjna-8549589.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-wpisala-setki-przedstawicieli-bialoruskiego-rezimu-na-liste-sankcyjna-8549589.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 13:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/f/bc854b83cb3e68-948-568-0-59-4724-2834.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zdecydowałem o wpisaniu na listę sankcyjną 365 przedstawicieli białoruskiego reżimu. Osoby te dostaną m.in. zakaz wjazdu do strefy Schengen. Sankcje obejmą też 20 podmiotów i 16 przedsiębiorców powiązanych głównie z rosyjskim kapitałem - poinformował szef MSWiA Mariusz Kamiński.</p>

## Ranking zaufania do polityków. Im Polacy ufają najbardziej
 - [https://www.bankier.pl/wiadomosc/Ranking-zaufania-do-politykow-Im-Polacy-ufaja-najbardziej-8549554.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-zaufania-do-politykow-Im-Polacy-ufaja-najbardziej-8549554.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 13:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/8b2d1e879fc94d-948-568-0-152-1450-869.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda, prezydent Warszawy, wiceszef PO Rafał Trzaskowski oraz lider Polski 2050 Szymon Hołownia są liderami majowego rankingu zaufania - wynika z sondażu CBOS. Z największą nieufnością spotykają się szef PO Donald Tusk, prezes PiS Jarosław Kaczyński oraz minister sprawiedliwości Zbigniew Ziobro (SP).</p>

## Czarne chmury nad Niemcami. Słabszy rozwój gospodarczy dopadł też rynek pracy
 - [https://www.bankier.pl/wiadomosc/Czarne-chmury-nad-Niemcami-Slabszy-rozwoj-gospodarczy-dopadl-tez-rynek-pracy-8549546.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czarne-chmury-nad-Niemcami-Slabszy-rozwoj-gospodarczy-dopadl-tez-rynek-pracy-8549546.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 13:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/056857d537b40e-945-560-0-14-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Słabszy rozwój gospodarczy i niepewność spowodowana wysokimi cenami energii oraz wojną w Ukrainie odbijają się także na rynku pracy – oceniają niemieccy eksperci. Firmy zatrudniają coraz mniej nowych pracowników, a najbliższe miesiące przyniosą wzrost bezrobocia – informuje „Handelsblatt”.</p>

## Rząd Wielkiej Brytanii namawia sieci handlowe do zamrożenia cen żwyności
 - [https://www.bankier.pl/wiadomosc/Rzad-Wielkiej-Brytanii-namawia-sieci-handlowe-do-zamrozenia-cen-zwynosci-8549532.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-Wielkiej-Brytanii-namawia-sieci-handlowe-do-zamrozenia-cen-zwynosci-8549532.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 12:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/9bb855f5ac05b5-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Wielkiej Brytanii trwa debata nad wprowadzeniem maksymalnego limitu cen na podstawowe produkty żywnościowe. Ma to być odpowiedzią na fakt, że choć inflacja zaczęła spowalniać, to ceny żywności nadal rosną w rekordowym tempie.</p>

## 89-latka oszukana metodą "na policjanta". Straciła 167 tys. zł
 - [https://www.bankier.pl/wiadomosc/89-latka-oszukana-metoda-na-policjanta-Stracila-167-tys-zl-8549506.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/89-latka-oszukana-metoda-na-policjanta-Stracila-167-tys-zl-8549506.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 12:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/db0e5ad0180dc7-948-568-0-140-2250-1349.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do 89-letniej mieszkanki Bielan zadzwonił mężczyzna, który podał się za policjanta. Wyłudził od kobiety łącznie 167 tys. złotych - poinformowała w poniedziałek podinsp. Elwira Kozłowska.</p>

## PKN Orlen zmienia nazwę. "Odzwierciedli to rzeczywistą formę działalności spółki"
 - [https://www.bankier.pl/wiadomosc/Polski-Koncern-Naftowy-Orlen-zmienia-nazwe-8549498.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polski-Koncern-Naftowy-Orlen-zmienia-nazwe-8549498.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 12:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/0f977c8c8aefe1-948-568-50-0-2457-1474.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polski Koncern Naftowy Orlen Spółka Akcyjna zmienia nazwę na Orlen Spółka Akcyjna - wynika z uzasadnienia do projektu uchwały zwyczajnego walnego zgromadzenia akcjonariuszy spółki, które zwołano na 21 czerwca.</p>

## Czarne złoto nie tylko w przenośni. Górnictwo z dobrymi wynikami finansowymi
 - [https://www.bankier.pl/wiadomosc/Czarne-zloto-nie-tylko-w-przenosni-Gornictwo-z-dobrymi-wynikami-finansowymi-8549486.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czarne-zloto-nie-tylko-w-przenosni-Gornictwo-z-dobrymi-wynikami-finansowymi-8549486.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 12:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/62fc14a77df28a-948-568-0-115-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wynik finansowy netto sektora górnictwa węgla kamiennego w I kwartale wyniósł 3,23 mld zł wobec 2,058 mld zł w I kw. 2022 roku - podała Agencja Rozwoju Przemysłu, która analizuje rynek węgla.</p>

## Niższe stawki za wywóz śmieci w Warszawie. Jest projekt uchwały
 - [https://www.bankier.pl/wiadomosc/Nizsze-stawki-za-wywoz-smieci-w-Warszawie-Jest-projekt-uchwaly-8549480.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nizsze-stawki-za-wywoz-smieci-w-Warszawie-Jest-projekt-uchwaly-8549480.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 12:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/09f996ed461633-948-568-0-64-1989-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wojewoda mazowiecki na poniedziałkowej konferencji przedstawił projekt uchwały, który złoży do prezydenta Warszawy i przewodniczącej Rady Miasta Stołecznego. W uchwale wojewoda proponuje niższe stawki za wywóz śmieci.</p>

## Dużo nowości dla inwestorów w DM BOŚ. Promocje zostają na dłużej
 - [https://www.bankier.pl/wiadomosc/Bossa-promocje-i-zmiany-w-ofercie-DM-BOS-8549303.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bossa-promocje-i-zmiany-w-ofercie-DM-BOS-8549303.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 12:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/af25bd161acb9e-948-568-0-35-2362-1417.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prowizje na zagranicznych instrumentach, nowa platforma do handlu CFD i dostęp dla użytkowników Apple to niektóre z tematów, o których rozmawialiśmy z Sebastianem Zadorą - dyrektorem wydziału Sprzedaży Instrumentów Finansowych Bossy, podczas konferencji Wall Street 27.</p>

## Senior miał zainwestować w kryptowaluty. Stracił kilkadzieisąt tysięcy złotych
 - [https://www.bankier.pl/wiadomosc/Senior-mial-zainwestowac-w-kryptowaluty-Stracil-kilkadzieisat-tysiecy-zlotych-8549433.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Senior-mial-zainwestowac-w-kryptowaluty-Stracil-kilkadzieisat-tysiecy-zlotych-8549433.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 11:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/3/1654da7b966e39-948-568-25-187-2471-1483.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kolejny senior stracił pieniądze. Z konta 65-letniego mieszkańca Rzeszowa, który chciał zainwestować w kryptowaluty, zniknęło 50 tys. złotych. Uwierzył oszustom i zainstalował oprogramowanie AnyDesk, dzięki któremu przestępcy zyskali dostęp do jego konta. Policja po raz kolejny ostrzega przed oszustami działającymi metodą na tzw. zdalny pulpit.</p>

## Przedterminowe wybory w Hiszpanii. Premier Sanchez rozwiązał parlament
 - [https://www.bankier.pl/wiadomosc/Przedterminowe-wybory-w-Hiszpanii-Premier-Sanchez-rozwiazal-parlament-8549436.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przedterminowe-wybory-w-Hiszpanii-Premier-Sanchez-rozwiazal-parlament-8549436.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 11:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/7/c1012aadb6ee17-948-568-2-27-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W następstwie porażki w wyborach regionalnych i lokalnych partii rządzącej w Hiszpanii, premier Pedro Sanchez ogłosił w poniedziałek rozwiązanie parlamentu i rozpisanie przedterminowych wyborów parlamentarnych. Hiszpanie do urn udadzą się 23 lipca.</p>

## Ostatnie dni na złożenie wniosku o zwrot nadpłaty składki zdrowotnej
 - [https://www.bankier.pl/wiadomosc/Ostatnie-dni-na-zlozenie-wniosku-o-zwrot-nadplaty-skladki-zdrowotnej-8549390.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ostatnie-dni-na-zlozenie-wniosku-o-zwrot-nadplaty-skladki-zdrowotnej-8549390.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 10:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/225949a5b72a96-948-568-0-27-2784-1670.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prawie 660 tys. płatników dostarczyło już zweryfikowany wniosek o zwrot nadpłaconej składki zdrowotnej na łącznie ponad 1,2 mld zł – informuje Zakład Ubezpieczeń Społecznych. Co istotne, przedsiębiorcy mają czas na złożenie takiego dokumentu przez PUE ZUS tylko do 1 czerwca.</p>

## Kolejne ułatwienia w skarbówce. Projekt przewiduje uzyskanie informacji podatkowych bez wizyty
 - [https://www.bankier.pl/wiadomosc/Kolejne-ulatwienia-w-skarbowce-Projekt-przewiduje-uzyskanie-informacji-podatkowych-bez-wizyty-8549385.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejne-ulatwienia-w-skarbowce-Projekt-przewiduje-uzyskanie-informacji-podatkowych-bez-wizyty-8549385.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 10:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/bd435b7675745e-948-568-248-472-4468-2680.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Naczelnicy urzędów skarbowych będą mogli telefonicznie lub za pośrednictwem e-Urzędu Skarbowego przekazywać podatnikom dane skarbowe, których uzyskanie obecnie wymaga wizyty w urzędzie – wynika z opublikowanego w poniedziałek projektu rozporządzenia Ministerstwa Finansów.</p>

## "Więcej generałów niż haubic". Media zaniepokojone stanem brytyjskiej armii
 - [https://www.bankier.pl/wiadomosc/Wiecej-generalow-niz-haubic-Media-zaniepokojone-stanem-brytyjskiej-armii-8549373.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiecej-generalow-niz-haubic-Media-zaniepokojone-stanem-brytyjskiej-armii-8549373.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 10:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/6f5f1a661205b8-948-568-0-215-1689-1013.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba generałów jest nieproporcjonalnie duża w stosunku do zmniejszającego się stanu osobowego armii. Co więcej, brytyjskie wojska lądowe mają więcej generałów niż sztuk haubic - wynika z danych ministerstwa obrony, o których pisze w poniedziałek "The Times".</p>

## Wybuchy w Kijowie. Rosyjski atak rakietowy na Ukrainę
 - [https://www.bankier.pl/wiadomosc/Wybuchy-w-Kijowie-Rosyjski-atak-rakietowy-na-Ukraine-8549346.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wybuchy-w-Kijowie-Rosyjski-atak-rakietowy-na-Ukraine-8549346.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 09:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/c/6b9e46dacabd3f-948-568-0-39-1773-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosjanie atakują Kijów rakietami – potwierdziły w poniedziałek władze ukraińskiej stolicy. Odłamki pocisku upadły w pobliżu centrum. Alarm lotniczy ogłoszono już w większości regionów, w tym na zachodzie kraju.</p>

## Sprzeczne sygnały z RPP. Złoty traci
 - [https://www.bankier.pl/wiadomosc/Sprzeczne-sygnaly-z-RPP-Zloty-traci-8549327.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sprzeczne-sygnaly-z-RPP-Zloty-traci-8549327.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 09:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/f/b8a1acffb1db8a-948-568-210-70-3790-2273.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Złotemu raczej nie pomogły sprzeczne wypowiedzi członków Rady Polityki
Pieniężnej. Kurs euro piął się w górę, powracając powyżej 4,50 zł.</p>

## Lex Tusk. Prezydent Duda podpisał ustawę o komisji ds. wpływów rosyjskich
 - [https://www.bankier.pl/wiadomosc/Lex-Tusk-Prezydent-Duda-podpisal-ustawe-o-komisji-ds-wplywow-rosyjskich-8549276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lex-Tusk-Prezydent-Duda-podpisal-ustawe-o-komisji-ds-wplywow-rosyjskich-8549276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/c7a75ae31a3f4a-948-568-0-97-3264-1958.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Andrzej Duda podpisze ustawę o powołaniu komisji ds. wpływów rosyjskich. Jego zdaniem opinia publiczna ma prawo wiedzieć, jak Kreml ingerował w polskie interesy. "Takie ciało powinno także powstać na poziomie europejskim, by zbadać m.in. Nord Stream I i Nord Stream II" - zaznaczył prezydent. </p>

## Etniczni Serbowie w Kosowie próbowali przejąć siedziby władz lokalnych
 - [https://www.bankier.pl/wiadomosc/Etniczni-Serbowie-w-Kosowie-probowali-przejac-siedziby-wladz-lokalnych-8549314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Etniczni-Serbowie-w-Kosowie-probowali-przejac-siedziby-wladz-lokalnych-8549314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 09:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/0/153dde9f21a139-945-567-11-89-1488-893.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Etniczni Serbowie próbowali w poniedziałek rano opanować siedziby władz lokalnych w Kosowie - poinformowała agencja AP. W ubiegłym tygodniu burmistrzowie albańskiego pochodzenia wkroczyli do swoich biur w eskorcie policji.</p>

## Kary za brak OC będą wyższe. W 2024 roku mogą przebić 8000 złotych
 - [https://www.bankier.pl/wiadomosc/Rekordowe-kary-za-brak-OC-w-2024-r-Mozna-zaplacic-nawet-ponad-8-tys-zl-8549306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rekordowe-kary-za-brak-OC-w-2024-r-Mozna-zaplacic-nawet-ponad-8-tys-zl-8549306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 08:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/2/287ead4a65f500-948-568-0-84-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W przyszłym roku przerwa w obowiązkowym
ubezpieczeniu OC samochodu może drogo kosztować. Stawki będą różne w pierwszej
i drugiej połowie roku. Jednak już wiadomo, że najwyższa kara może przekroczyć
nawet 8 tys. zł.  </p>

## Brytyjski MON: Rosja ćwiczyła obronę Mostu Krymskiego
 - [https://www.bankier.pl/wiadomosc/Brytyjski-MON-Rosja-cwiczyla-obrone-Mostu-Krymskiego-8549281.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjski-MON-Rosja-cwiczyla-obrone-Mostu-Krymskiego-8549281.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/9e7fd280e8c76d-948-568-0-110-1773-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosja przeprowadziła ćwiczenia obronne wokół Mostu Krymskiego, które obejmowały m.in. stworzenie na tej przeprawie zasłony dymnej - przekazało w poniedziałek brytyjskie ministerstwo obrony. Położenie mostu jest strategiczne - prowadzi on bezpośrednio z Rosji na terytorium okupowanego Krymu.</p>

## Obniżki stóp najwcześniej w 2025 roku? Kotecki ma obawy
 - [https://www.bankier.pl/wiadomosc/Obnizki-stop-najwczesniej-w-2025-roku-Kotecki-Obawaim-sie-ze-tak-8549277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Obnizki-stop-najwczesniej-w-2025-roku-Kotecki-Obawaim-sie-ze-tak-8549277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 08:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/40f16837d6ed1a-948-568-0-0-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2023 roku nie będzie miejsca na obniżki stóp proc., być może nie będzie też na to miejsca w 2024 roku - powiedział w radiu TOK FM członek RPP Ludwik Kotecki. Dodał, że odczyt inflacji za maj wyniesie ok. 13 proc.</p>

## ING Bank Śląsk zablokował karty płatnicze
 - [https://www.bankier.pl/wiadomosc/Wyciek-danych-ING-Bank-Slask-zablokowal-karty-platnicze-8549260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyciek-danych-ING-Bank-Slask-zablokowal-karty-platnicze-8549260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 07:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/b/7c62b8c646f67e-948-568-0-144-4128-2476.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Część klientów ING Banku Śląskiego musiała w weekend zmagać się z zablokowanymi kartami płatniczymi. To efekt wycieku danych u jednego z operatorów kart.</p>

## "Lewe" certyfikaty szczepień. COVID-19 przyniósł oszustom miliony
 - [https://www.bankier.pl/wiadomosc/Lewe-certyfikaty-szczepien-COVID-19-przyniosl-oszustom-miliony-8549238.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lewe-certyfikaty-szczepien-COVID-19-przyniosl-oszustom-miliony-8549238.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 07:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/f/6b11955e656d18-948-568-2-62-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />10 osób zostało zatrzymanych przez policję - miały one wprowadzać do systemu gabinet.gov.pl podrobione zaświadczenia o szczepieniu przeciwko COVID-19. Zdaniem śledczych członkowie gangu wystawili ok. 4 tysięcy fałszywych certyfikatów zarabiając na tym około 4 mln zł.</p>

## Minister Buda: Największe banki chętne do wprowadzenia "Bezpiecznego kredytu"
 - [https://www.bankier.pl/wiadomosc/Minister-Buda-Najwieksze-banki-chetne-do-wprowadzenia-Bezpiecznego-kredytu-8549236.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-Buda-Najwieksze-banki-chetne-do-wprowadzenia-Bezpiecznego-kredytu-8549236.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 07:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/c/2a9b3068051825-948-568-0-127-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trzy największe banki w Polsce zadeklarowały chęć i gotowość wprowadzenia do oferty rządowego programu "Bezpieczny kredyt" - powiedział w poniedziałek minister rozwoju i technologii Waldemar Buda w Programie 1 Polskiego Radia. 3 lipca wprowadzamy produkt w życie - dodał.</p>

## Podwyżka 500+? Większość Polaków uważa, że zwiększy inflację
 - [https://www.bankier.pl/wiadomosc/Podwyzka-500-Wiekszosc-Polakow-uwaza-ze-zwiekszy-inflacje-8549225.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podwyzka-500-Wiekszosc-Polakow-uwaza-ze-zwiekszy-inflacje-8549225.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 07:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/0d0f9bb9746a95-891-535-32-132-891-535.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jarosław Kaczyński zapowiedział podniesienie świadczenia 500+ do kwoty 800 złotych. Większość Polaków uważa jednak, że taka podwyżka będzie proinflacyjna, czyli zwiększy inflację. Co ciekawe, 1,9 proc. badanych uważa, że podwyżka inflację zmniejszy - wynika z sondażu IBRiS dla Radia ZET.</p>

## Ropa w USA drożeje. Motorem porozumienie ws. długu
 - [https://www.bankier.pl/wiadomosc/Ropa-w-USA-drozeje-Motorem-porozumienie-ws-dlugu-8549222.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ropa-w-USA-drozeje-Motorem-porozumienie-ws-dlugu-8549222.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 07:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/a62ce8688abdf6-945-560-0-237-1609-965.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku powiększają wzrosty w reakcji na osiągnięcie w USA porozumienia w sprawie limitu zadłużenia - podają maklerzy.</p>

## Masłowska (RPP): Jednocyfrowa inflacja możliwa na koniec roku
 - [https://www.bankier.pl/wiadomosc/Maslowska-RPP-Jednocyfrowa-inflacja-mozliwa-na-koniec-roku-8549192.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Maslowska-RPP-Jednocyfrowa-inflacja-mozliwa-na-koniec-roku-8549192.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 06:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/b/9e77cdf8741f85-948-568-12-173-2467-1480.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pod koniec roku możemy się spodziewać jednocyfrowej inflacji - powiedziała poniedziałkowemu magazynowi "Polska. Metropolia Warszawska" Gabriela Masłowska, członek Rady Polityki Pieniężnej. Warunkiem jest, by "sytuacja gospodarcza i poziom presji inflacyjnej kształtował tak jak to widzimy dzisiaj" - dodała.</p>

## NASA wynajmie pojazdy księżycowe od prywatnych firm
 - [https://www.bankier.pl/wiadomosc/NASA-wynajmie-pojazdy-ksiezycowe-od-firm-kosmicznych-8549191.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NASA-wynajmie-pojazdy-ksiezycowe-od-firm-kosmicznych-8549191.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 06:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/b682b03becd30b-948-568-0-240-1632-979.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niegdyś nie możliwe do pomyślenia, a dziś jednak realne - amerykańska agencja kosmiczna NASA chciałaby, aby astronauci w projekcie Artemis mogli poruszać się po Księżycu w pojazdach nowej generacji. Nie wyprodukuje ich jednak sama, a... planuje je wynajmować jako usługę od firm przemysłu kosmicznego.</p>

## Ponad połowa badanych oczekuje odwołania szefa MON
 - [https://www.bankier.pl/wiadomosc/Ponad-polowa-badanych-oczekuje-odwolania-szefa-MON-8549186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ponad-polowa-badanych-oczekuje-odwolania-szefa-MON-8549186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 06:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/b6e4f6883d562b-948-568-61-46-1843-1105.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad połowa badanych oczekuje odwołania szefa resortu obrony narodowej Mariusza Błaszczaka. Jego rezygnacji domagają się przedstawiciele opozycji - pisze poniedziałkowa "Rzeczpospolita".</p>

## Ukraińcy na polskim rynku pracy. Mają zbyt wysokie kwalifikacje do potrzeb pracodawców?
 - [https://www.bankier.pl/wiadomosc/Ukraincy-na-polskim-rynku-pracy-Maja-zbyt-wysokie-kwalifikacje-do-potrzeb-pracodawcow-8549181.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraincy-na-polskim-rynku-pracy-Maja-zbyt-wysokie-kwalifikacje-do-potrzeb-pracodawcow-8549181.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/e0299ea32e2d3e-948-568-218-271-2581-1548.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />78 proc. Ukraińców przebywających w Polsce pracuje. Odsetek ten jest bardzo wysoki zarówno wśród migrantów przedwojennych, jak i uchodźców. Polski rynek pracy potrzebuje ich jeszcze więcej, szczególnie w okresie prac sezonowych. Ukraińcy wskazują jednak na kilka trudności - wśród nich są wysokie oczekiwania pracodawców, słaba znajomość języka polskiego i praca poniżej zdobytych w ojczyźnie kwalifikacji.</p>

## Etyka, ekologia i oczywiście cena. Na te wskażniki patrzą konsumenci
 - [https://www.bankier.pl/wiadomosc/Etyka-ekologia-i-oczywiscie-cena-Na-te-wskazniki-patrza-konsumenci-8549175.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Etyka-ekologia-i-oczywiscie-cena-Na-te-wskazniki-patrza-konsumenci-8549175.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/8/61746825e2ac95-948-568-0-82-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć w dobie szybko rosnącej inflacji konsumenci uważniej przyglądają się cenom, to kwestie jakości, ekologii i etyki firm będących właścicielami sklepów pozostają dla nich istotne. Pandemia przekierowała uwagę logistyków na lokalne źródła zaopatrzenia, a to trend współgrający z ekologią ze względu na ograniczenie śladu węglowego.</p>

## Gospodarczy kalendarz inwestora. Co wydarzy się w tym tygodniu?
 - [https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-Gospodarczy-kalendarz-inwestora-8549168.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-Gospodarczy-kalendarz-inwestora-8549168.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 05:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/f/ca65f4fafbd4ab-948-568-33-168-2212-1327.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W tym tygodniu uwaga inwestorów skupi się na danych makro z USA - raport payrolls, odczyty PMI, wstępne dane o CPI w maju. W tle będzie także polityka - podniesienie limitu zadłużenia USA i reperkusje wyborów prezydenckich w Turcji. Istotne będą też wystąpienia bankierów centralnych. W poniedziałek rynki w USA i Wielkiej Brytanii są zamknięte ze względu na święta.</p>

## 800+ od nowego roku. Jakie warunki trzeba spełnić?
 - [https://www.bankier.pl/wiadomosc/800-od-nowego-roku-Jakie-warunki-trzeba-spelnic-8549086.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/800-od-nowego-roku-Jakie-warunki-trzeba-spelnic-8549086.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/ef414f54f9c4d0-948-568-0-45-1805-1083.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Waloryzację
świadczenia 500 plus do 800 zł zapowiedziało Prawo i Sprawiedliwość w połowie
maja br. Ma być ona wprowadzona od 1 stycznia 2024 roku, a w najbliższych
miesiącach partia rządząca ma pokazać, że będą zagwarantowane pieniądze na ten
program. Czy, aby otrzymać zapowiedzianą kwotę trzeba spełnić jakieś warunki?</p>

## Więcej pieniędzy dla etatowców. Nawet kilkaset złotych na wakacje
 - [https://www.bankier.pl/wiadomosc/Wczasy-pod-grusza-Kto-moze-skorzystac-ze-swiadczenia-Jaka-jest-jego-wysokosc-8548038.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wczasy-pod-grusza-Kto-moze-skorzystac-ze-swiadczenia-Jaka-jest-jego-wysokosc-8548038.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/e/016c711a73165e-948-568-0-74-1355-812.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wczasy pod gruszą to opcja na otrzymanie dodatkowych pieniędzy dla osób zatrudnionych w ramach umowy o pracę. Pracownicy mogą otrzymać nawet kilka tysięcy złotych na sfinansowania letniego wypoczynku. Zasady przyznawania świadczenia są określone w regulaminie Zakładowego Funduszu Świadczeń Socjalnych (ZFŚS). Sprawdź, kto i, pod jakimi warunkami może liczyć na dodatkowe środki na wakacje.</p>

## Wyższy limit zadłużenia USA. Biden: Czas na Kongres
 - [https://www.bankier.pl/wiadomosc/Wyzszy-limit-zadluzenia-USA-Biden-Czas-na-Kongres-8549152.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyzszy-limit-zadluzenia-USA-Biden-Czas-na-Kongres-8549152.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 02:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/3bbd19691ad97d-948-568-305-296-1418-851.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Joe Biden oświadczył w niedzielę, że ostatecznie sfinalizował porozumienie budżetowe z spikerem Izby Reprezentantów Kevinem McCarthym. Dodał, że porozumienie w sprawie podwyższenia limitu zadłużenia jest gotowe do przekazania Kongresowi .</p>

## Powolny upadek Sancheza? Hiszpańscy socjaliści przegrali wybory lokalne
 - [https://www.bankier.pl/wiadomosc/Powolny-upadek-Sancheza-Hiszpanscy-socjalisci-przegrali-wybory-lokalne-8549147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powolny-upadek-Sancheza-Hiszpanscy-socjalisci-przegrali-wybory-lokalne-8549147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 00:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/c42f8c54c6d554-948-568-24-6-2455-1473.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Hiszpańska Socjalistyczna Partia Robotnicza (PSOE), kierowana przez premiera Pedro Sancheza, przegrała niedzielne wybory do władz regionalnych i samorządowych w Hiszpanii, wynika z danych Państwowej Komisji Wyborczej po przeliczeniu głosów z ponad 99,7 proc. okręgów wyborczych.</p>

## Damaszek pod ostrzałem. Syria oskarża Izrael o atak
 - [https://www.bankier.pl/wiadomosc/Damaszek-pod-ostrzalem-Syria-oskarza-Izrael-o-atak-8549146.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Damaszek-pod-ostrzalem-Syria-oskarza-Izrael-o-atak-8549146.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-29 00:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/f/d163c244971c98-945-567-11-249-4528-2717.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Syryjskie media alarmują, że późnym wieczorem Izrael dokonał uderzeń z powietrza na stolicę Damaszek. Agencja SANA podaje, że znaczna część pocisków została zestrzelona. Nie ma ofiar śmiertelnych, a jedynie "straty materialne".</p>

