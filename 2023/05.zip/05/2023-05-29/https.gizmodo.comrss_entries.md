# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Deborah Chow Chats About the Work Behind Obi-Wan Kenobi
 - [https://gizmodo.com/deborah-chow-obi-wan-kenobi-disney-plus-star-wars-1850485402](https://gizmodo.com/deborah-chow-obi-wan-kenobi-disney-plus-star-wars-1850485402)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-29 21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--yeOI_78p--/c_fit,fl_progressive,q_80,w_636/fc9028ebfd6890c71f10a1df30d1941e.jpg" /><p>Deborah Chow, the director of the Disney+ show, <a href="https://gizmodo.com/obi-wan-kenobi-darth-vader-ewan-mcgregor-christensen-1850317103"><em>Obi-Wan Kenobi</em></a>, went on the <a href="https://podcasts.apple.com/us/podcast/deborah-chow/id1434867623?i=1000614833771" rel="noopener noreferrer" target="_blank">Crew Call </a>podcast to chat about the challenges that came alongside working on the <a href="https://gizmodo.com/obi-wan-kenobi-season-2-ewan-mcgregor-kathleen-kennedy-1850334069">limited series</a>. She had just finished <em>Mandalorian</em> and <a href="https://gizmodo.com/mark-hamill-luke-skywalker-rey-movie-mandalorian-disney-1850480679"><em>Kenobi</em></a> had gone through “numerous iterations” and passed through multiple hands before landing in her lap. </p><p><a href="https://gizmodo.com/deborah-chow-obi-wan-kenobi-disney-plus-star-wars-1850485402">Read more...</a></p>

## Wake Up Besties, the Barbie and Ken Mugshot Meme Is Everywhere
 - [https://gizmodo.com/barbie-ken-mugshot-meme-fanart-roundup-fandom-movie-1850484680](https://gizmodo.com/barbie-ken-mugshot-meme-fanart-roundup-fandom-movie-1850484680)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-29 16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Vwl-qwZI--/c_fit,fl_progressive,q_80,w_636/3157cbd804e6994128647feb6c39dfe4.png" /><p>After an eagle-eyed Twitter user (@<a href="https://twitter.com/kojironanjo/status/1661772826897002507?s=20" rel="noopener noreferrer" target="_blank">kojironanjo</a>) realized that the <a href="https://gizmodo.com/new-barbie-trailer-margot-robbie-ryan-gosling-gerwig-1850475228"><em>Barbie</em> trailer</a> was ripe for meme-ification, Twitter fandom did what fandom does best, and immediately took the joke to the extreme. Reaching all corners of the world, fandoms immediately drew their favorite pairings using the <a href="https://gizmodo.com/margot-robbie-barbie-movie-interview-greta-gerwig-1850470404"><em>Barbie</em> mugshot screenshots</a>…</p><p><a href="https://gizmodo.com/barbie-ken-mugshot-meme-fanart-roundup-fandom-movie-1850484680">Read more...</a></p>

## Relentless Melt is H.P. Lovecraft Meets Agatha Christie
 - [https://gizmodo.com/relentless-melt-excerpt-read-first-chapter-bushnell-1850484633](https://gizmodo.com/relentless-melt-excerpt-read-first-chapter-bushnell-1850484633)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-29 14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--wRimJjQ7--/c_fit,fl_progressive,q_80,w_636/d7560e848dd122dd69f5f38b98962026.png" /><p>Giving us <a href="https://gizmodo.com/brandon-sanderson-graphic-novel-dark-one-excerpt-vault-1850447918">gothic vibes</a> in early 1900s Boston, <em>Relentless Melt </em>follows Artie Quick, a crossdressing young woman who disguises herself as a man in order to further her education, and her friend Theodore, an up-and-coming <a href="https://gizmodo.com/queer-fantasy-book-recommendations-disaster-gays-1849535707">high society magician</a>, as they <a href="https://gizmodo.com/victor-manibo-the-sleepless-new-book-escape-velocity-1850420951">investigate claims</a> of abductions on the Boston Common. As Artie works…</p><p><a href="https://gizmodo.com/relentless-melt-excerpt-read-first-chapter-bushnell-1850484633">Read more...</a></p>

## ‘Are We Waiting for S**t to Hit The Fan?’: Former Google Safety Lead Warns of AI Chatbots Writing News
 - [https://gizmodo.com/google-smartnews-ai-news-tiktok-bytedance-trust-safety-1850439273](https://gizmodo.com/google-smartnews-ai-news-tiktok-bytedance-trust-safety-1850439273)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-29 12:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_UV2V-hq--/c_fit,fl_progressive,q_80,w_636/ddf70c11bd5d9a4fb21d4bfc7756c316.jpg" /><p>In a few short months, the idea of convincing news articles written entirely by computers have evolved from perceived absurdity into a reality that’s <a href="https://gizmodo.com/chatgpt-ai-fake-news-stories-content-farms-newsguard-1850391104">already confusing some readers</a>. Now, writers, editors, and <a href="https://gizmodo.com/chatgpt-ai-openai-sam-altman-congress-watch-hearing-1850440738">policymakers</a> are scrambling to develop standards to maintain trust in a world where AI-generated text will…</p><p><a href="https://gizmodo.com/google-smartnews-ai-news-tiktok-bytedance-trust-safety-1850439273">Read more...</a></p>

## Gizmodo Monday Puzzle: Can You Outsmart a Mouse?
 - [https://gizmodo.com/gizmodo-monday-puzzle-find-the-mouse-1850383358](https://gizmodo.com/gizmodo-monday-puzzle-find-the-mouse-1850383358)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-05-29 11:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--5fohpQ5e--/c_fit,fl_progressive,q_80,w_636/0d26026f5cb13c0bfa8ee0707636e290.png" /><p>I adore Rube Goldberg machines as much as the next puzzle-fanatic, but I never had the pleasure of playing the Goldberg-inspired board game <em>Mouse Trap</em>. As I understand it, the gameplay didn’t matter much. The joy was in building a contraption that, with the crank of a gear, set off a chain reaction in which a marble…</p><p><a href="https://gizmodo.com/gizmodo-monday-puzzle-find-the-mouse-1850383358">Read more...</a></p>

