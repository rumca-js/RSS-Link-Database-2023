# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## IT'S OVER
 - [https://www.youtube.com/watch?v=TOEHC-Rb1Eo](https://www.youtube.com/watch?v=TOEHC-Rb1Eo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-05-29 17:00:14+00:00

Belief is dead & so is God..? A recent survey reveals that only half of Americans claim to believe in God, sparking a profound discussion about the evolving nature of faith and its impact on various aspects of our lives.
#god #religion #church #belief 
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble
Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community
Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/
Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

