# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## These Glasses Are Ridiculous
 - [https://www.youtube.com/watch?v=EtYwadd5E10](https://www.youtube.com/watch?v=EtYwadd5E10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-05-29 21:30:04+00:00

This is the greatest tactical equipment of All Time
Merch https://moistglobal.com/

## The Official Podcast #338: Vin Diesel Masterpiece
 - [https://www.youtube.com/watch?v=i6mIDRvZOS0](https://www.youtube.com/watch?v=i6mIDRvZOS0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-05-29 16:00:33+00:00

Four close man friends gather around to talk about Vin Diesel.

This is the Official Podcast. Every Monday at 7pm EST. Links Below.

---

Get additional episodes and bonus content with early access:
go to https://www.PATREON.com/THEOFFICIALPODCAST

Brought to you by the following sponsors:

GET $20 OFF YOUR FIRST SEATGEEK ORDER:
go to https://seatgeek.onelink.me/RrnK/OFFICIAL

GET A NEW WIRELESS PLAN FOR JUST $15 A MONTH:
go to https://www.MINTMOBILE.com/OFFICIAL

GET 50% OFF 1 ITEM AT ADAM AND EVE, WITH FREE SHIPPING TO US + CANADA:
go to https://www.ADAMANDEVE.com and use code DEFENSE

GET GODSLAP AND PLAGUE SEEKER RIGHT NOW:
go to https://www.BADEGG.co

---

Timestamps:

00:03:00 - Zelda TOTK
00:15:30 - Fast & Furious X
00:23:45 - SeatGeek, Mint Mobile, Adam&amp;Eve *Ads*
00:34:45 - Pope's Exorcist
00:56:00 - The Dark Universe
01:16:10 - Voicemails

---

Hosts: 

Jackson: https://twitter.com/zealotonpc 
Andrew: https://twitter.com/huggbeestv 
Charlie: https://twitter.com/moistcr1tikal 
Kaya: https://twitter.com/kayaorsan

---

The Official Podcast Links: 

SubReddit: https://reddit.com/r/theofficialpodcast 
Google Play: https://play.google.com/music/m/Iv4af6j46ldkjja7vwnvljbyiw4?t=The_Official_Podcast 
Google Podcasts: https://www.google.com/podcasts?feed=aHR0cHM6Ly9mZWVkcy5tZWdhcGhvbmUuZm0vVE9QNzc4NDYyNTk4MA%3D%3D 
Spotify: https://open.spotify.com/show/6TXzjtMTEopiGjIsCfvv6W 
iTunes: https://itunes.apple.com/au/podcast/the-official-podcast/id1186089636 
Patreon: https://www.patreon.com/theofficialpodcast
Intro by: https://www.youtube.com/c/Derpmii
Music by: https://soundcloud.com/inst1nctive
Thumbnail by: https://www.instagram.com/nook_eilyk/

## Actually Amazing News
 - [https://www.youtube.com/watch?v=XOKkzNsJkF0](https://www.youtube.com/watch?v=XOKkzNsJkF0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-05-29 01:00:09+00:00

This is the greatest happy stories of All Time
Merch https://moistglobal.com/

