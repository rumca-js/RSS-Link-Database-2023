# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Czeski wywiad: Rosjanie zrobią wszystko, aby Czechy nie ratyfikowały porozumienia obronnego z USA
 - [https://wydarzenia.interia.pl/zagranica/news-czeski-wywiad-rosjanie-zrobia-wszystko-aby-czechy-nie-ratyfi,nId,6808532](https://wydarzenia.interia.pl/zagranica/news-czeski-wywiad-rosjanie-zrobia-wszystko-aby-czechy-nie-ratyfi,nId,6808532)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 20:16:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czeski-wywiad-rosjanie-zrobia-wszystko-aby-czechy-nie-ratyfi,nId,6808532"><img align="left" alt="Czeski wywiad: Rosjanie zrobią wszystko, aby Czechy nie ratyfikowały porozumienia obronnego z USA" src="https://i.iplsc.com/czeski-wywiad-rosjanie-zrobia-wszystko-aby-czechy-nie-ratyfi/000H7Q002ODSW66C-C321.jpg" /></a>- Rosjanie użyją wszelkich środków - także osobistych, a nawet intymnych - aby zapobiec ratyfikacji umowy z USA - powiedział szef cywilnej agencji kontrwywiadowczej Informacyjnej Służby Bezpieczeństwa (BIS) Michal Koudelka na konferencji poświęconej bezpieczeństwu wewnętrznemu i odporności państwa zorganizowanej przez Izbę Poselską. Dokument podpisano w ubiegłym tygodniu w Waszyngtonie. Jego zdaniem Rosja będzie chciała oczerniać polityków i w ten sposób wpływać na ich decyzje.  </p><br clear="all" />

## Ukraina: Ostrzał koszar w Jurjiwce. 100 zabitych i ponad 400 rannych rosyjskich żołnierz
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-ostrzal-koszar-w-jurjiwce-100-zabitych-i-ponad-400-r,nId,6808519](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-ostrzal-koszar-w-jurjiwce-100-zabitych-i-ponad-400-r,nId,6808519)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 19:42:18+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-ostrzal-koszar-w-jurjiwce-100-zabitych-i-ponad-400-r,nId,6808519"><img align="left" alt="Ukraina: Ostrzał koszar w Jurjiwce. 100 zabitych i ponad 400 rannych rosyjskich żołnierz" src="https://i.iplsc.com/ukraina-ostrzal-koszar-w-jurjiwce-100-zabitych-i-ponad-400-r/000H7PXS6LIQ5J9Q-C321.jpg" /></a>&quot;Stu ruskich już nigdy nie będzie walczyć. Chyba że w piekle&quot;  - napisał w poniedziałek lojalny wobec Kijowa doradca mera Mariupola Petro Andriuszczenko. Około 100 rosyjskich żołnierzy zginęło w niedzielnym ostrzale koszar w okupowanej Jurjiwce w pobliżu Mariupola, a ponad 400 zostało rannych i przebywają na oddziale intensywnej terapii. </p><br clear="all" />

## Rektor UEK odchodzi z prezydenckiej rady. Napisał list otwarty
 - [https://wydarzenia.interia.pl/kraj/news-rektor-uek-odchodzi-z-prezydenckiej-rady-napisal-list-otwart,nId,6808512](https://wydarzenia.interia.pl/kraj/news-rektor-uek-odchodzi-z-prezydenckiej-rady-napisal-list-otwart,nId,6808512)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 19:39:47+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rektor-uek-odchodzi-z-prezydenckiej-rady-napisal-list-otwart,nId,6808512"><img align="left" alt="Rektor UEK odchodzi z prezydenckiej rady. Napisał list otwarty" src="https://i.iplsc.com/rektor-uek-odchodzi-z-prezydenckiej-rady-napisal-list-otwart/000H7PUS38Y60F7O-C321.jpg" /></a>Rektor krakowskiego Uniwersytetu Ekonomicznego zrezygnował w poniedziałek z członkostwa w Radzie ds. Szkolnictwa Wyższego, Nauki i Innowacji, która doradza prezydentowi RP. Prof. Stanisław Mazur zareagował w ten sposób na decyzję Andrzeja Dudy, który zgodził się na powołanie komisji badającej rosyjskie wpływy w Polsce. Jego zdaniem ustawa, pod którą podpisała się głowa państwa, ma wady prawne, a jej charakter jest &quot;antydemokratyczny&quot;.</p><br clear="all" />

## Rektor UEK odchodzi z prezydenckiej rady. Wysłał list otwarty
 - [https://wydarzenia.interia.pl/kraj/news-rektor-uek-odchodzi-z-prezydenckiej-rady-wyslal-list-otwarty,nId,6808512](https://wydarzenia.interia.pl/kraj/news-rektor-uek-odchodzi-z-prezydenckiej-rady-wyslal-list-otwarty,nId,6808512)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 19:39:47+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rektor-uek-odchodzi-z-prezydenckiej-rady-wyslal-list-otwarty,nId,6808512"><img align="left" alt="Rektor UEK odchodzi z prezydenckiej rady. Wysłał list otwarty" src="https://i.iplsc.com/rektor-uek-odchodzi-z-prezydenckiej-rady-wyslal-list-otwarty/000H7PUS38Y60F7O-C321.jpg" /></a>Rektor krakowskiego Uniwersytetu Ekonomicznego zrezygnował w poniedziałek z członkostwa w Radzie ds. Szkolnictwa Wyższego, Nauki i Innowacji, która doradza prezydentowi RP. Prof. Stanisław Mazur zareagował w ten sposób na decyzję Andrzeja Dudy, który zgodził się na powołanie komisji badającej rosyjskie wpływy w Polsce. Jego zdaniem ustawa, pod którą podpisała się głowa państwa, ma wady prawne, a jej charakter jest &quot;antydemokratyczny&quot;.</p><br clear="all" />

## Łódź: Zmarł 32-latek postrzelony na myjni. Prokuratura zmieni zarzuty podejrzanemu
 - [https://wydarzenia.interia.pl/lodzkie/news-lodz-zmarl-32-latek-postrzelony-na-myjni-prokuratura-zmieni-,nId,6808478](https://wydarzenia.interia.pl/lodzkie/news-lodz-zmarl-32-latek-postrzelony-na-myjni-prokuratura-zmieni-,nId,6808478)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 19:05:43+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-lodz-zmarl-32-latek-postrzelony-na-myjni-prokuratura-zmieni-,nId,6808478"><img align="left" alt="Łódź: Zmarł 32-latek postrzelony na myjni. Prokuratura zmieni zarzuty podejrzanemu" src="https://i.iplsc.com/lodz-zmarl-32-latek-postrzelony-na-myjni-prokuratura-zmieni/000H7PLNJNNCRTW1-C321.jpg" /></a>W poniedziałek w godzinach popołudniowych zmarł 32-latek, który został postrzelony na myjni w Łodzi w poprzedni weekend. - W związku z tym w postępowaniu zajdzie konieczność zmiany kwalifikacji prawnej czynu zarzuconego 45-letniemu podejrzanemu na zabójstwo - przekazał w rozmowie z Interią Krzysztof Kopania rzecznik prasowy Prokuratur Okręgowej w Łodzi.</p><br clear="all" />

## Nowy rodzaj broni na Białorusi. Dostawa z Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-nowy-rodzaj-broni-na-bialorusi-dostawa-z-rosji,nId,6808453](https://wydarzenia.interia.pl/zagranica/news-nowy-rodzaj-broni-na-bialorusi-dostawa-z-rosji,nId,6808453)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 18:50:28+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowy-rodzaj-broni-na-bialorusi-dostawa-z-rosji,nId,6808453"><img align="left" alt="Nowy rodzaj broni na Białorusi. Dostawa z Rosji" src="https://i.iplsc.com/nowy-rodzaj-broni-na-bialorusi-dostawa-z-rosji/000H7PI2AXS7NPN2-C321.jpg" /></a>Na Białoruś dotarł z Rosji system rakietowy S-400. Zestaw ten trafił do jednostki wojskowej w miejscowości Nawakołasawa w obwodzie mińskim - poinformował w poniedziałek niezależny kanał Biełaruski Hajun. Najpewniej S-400, służące do obrony przeciwlotniczej, będą stacjonowały 50 km od stolicy - Mińska.</p><br clear="all" />

## Starcia w Kosowie. Żołnierze misji pokojowej NATO zostali ciężko ranni
 - [https://wydarzenia.interia.pl/zagranica/news-starcia-w-kosowie-zolnierze-misji-pokojowej-nato-zostali-cie,nId,6808446](https://wydarzenia.interia.pl/zagranica/news-starcia-w-kosowie-zolnierze-misji-pokojowej-nato-zostali-cie,nId,6808446)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 18:29:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-starcia-w-kosowie-zolnierze-misji-pokojowej-nato-zostali-cie,nId,6808446"><img align="left" alt="Starcia w Kosowie. Żołnierze misji pokojowej NATO zostali ciężko ranni " src="https://i.iplsc.com/starcia-w-kosowie-zolnierze-misji-pokojowej-nato-zostali-cie/000H7PEV9Q0PMXXT-C321.jpg" /></a>Narasta napięcie w Kosowie. Podczas poniedziałkowych protestów doszło do poważnych starć policji i sił pokojowych KFOR (misja NATO) z serbskimi demonstrantami. Rannych zostało 25 żołnierzy KFOR - podała agencja Reutera. Co najmniej trzech z nich jest w stanie ciężkim. Do walk doszło, gdy etniczni Serbowie próbowali opanować siedzibę władz lokalnych w Kosowie po tym jak w ubiegłym tygodniu burmistrzowie albańskiego pochodzenia wkroczyli do swoich biur w eskorcie policji. </p><br clear="all" />

## Duda odpowiada Tuskowi. "Są granice pazerności"
 - [https://wydarzenia.interia.pl/kraj/news-duda-odpowiada-tuskowi-sa-granice-pazernosci,nId,6808466](https://wydarzenia.interia.pl/kraj/news-duda-odpowiada-tuskowi-sa-granice-pazernosci,nId,6808466)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 18:06:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-duda-odpowiada-tuskowi-sa-granice-pazernosci,nId,6808466"><img align="left" alt="Duda odpowiada Tuskowi. &quot;Są granice pazerności&quot;" src="https://i.iplsc.com/duda-odpowiada-tuskowi-sa-granice-pazernosci/000H7PGHLJ0CRU0D-C321.jpg" /></a>- Nigdy nie zrozumiem, jak można porzucić ważną funkcję w Polsce po to, by pracować gdzieś w Brukseli. Są granice pazerności na pieniądze, widać niektórzy ich nie znają - stwierdził prezydent RP Andrzej Duda na spotkaniu z mieszkańcami Połczyna-Zdroju (woj. zachodniopomorskie). Nawiązując do Donalda Tuska odniósł się do komentarzy opozycji, która krytykuje podpisanie przez niego ustawy o komisji ds. wpływów rosyjskich. W ocenie głowy państwa nowy organ będzie pracował transparentnie, a jego działaniom przyjrzą się media.</p><br clear="all" />

## Poważny wypadek w Żyznowie. Wielu poszkodowanych
 - [https://wydarzenia.interia.pl/podkarpackie/news-powazny-wypadek-w-zyznowie-wielu-poszkodowanych,nId,6808415](https://wydarzenia.interia.pl/podkarpackie/news-powazny-wypadek-w-zyznowie-wielu-poszkodowanych,nId,6808415)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 17:25:20+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-powazny-wypadek-w-zyznowie-wielu-poszkodowanych,nId,6808415"><img align="left" alt="Poważny wypadek w Żyznowie. Wielu poszkodowanych " src="https://i.iplsc.com/powazny-wypadek-w-zyznowie-wielu-poszkodowanych/000H7P94UNRV2OBG-C321.jpg" /></a>Siedem osób zostało poszkodowanych w wypadku, do którego doszło w miejscowości Żyznów na Podkarpaciu. Na miejsce wezwano do śmigłowce Lotniczego Pogotowia Ratunkowego. Strażacy musieli wydostać dwie osoby zakleszczone w samochodzie. </p><br clear="all" />

## Nowe nagranie z Alaksandrem Łukaszenką. "Nie możemy dać się zwieść"
 - [https://wydarzenia.interia.pl/zagranica/news-nowe-nagranie-z-alaksandrem-lukaszenka-nie-mozemy-dac-sie-zw,nId,6808206](https://wydarzenia.interia.pl/zagranica/news-nowe-nagranie-z-alaksandrem-lukaszenka-nie-mozemy-dac-sie-zw,nId,6808206)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 16:55:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowe-nagranie-z-alaksandrem-lukaszenka-nie-mozemy-dac-sie-zw,nId,6808206"><img align="left" alt="Nowe nagranie z Alaksandrem Łukaszenką. &quot;Nie możemy dać się zwieść&quot;" src="https://i.iplsc.com/nowe-nagranie-z-alaksandrem-lukaszenka-nie-mozemy-dac-sie-zw/000H7OUEK088HP7T-C321.jpg" /></a>Białoruski opozycjonista Waleryj Cepkała, który nieoficjalnie informował, że w zeszłym tygodniu Alaksandr Łukaszenka trafił do szpitala w Moskwie w krytycznym stanie, zareagował na nowe nagranie z białoruskim dyktatorem. Ostrzegł, by &quot;nie dać się zwieść&quot; podobnym zabiegom. Przypomniał, że moskiewscy medycy już wcześniej stawiali na nogi i przed kamery takich polityków jak Breżniew, Andropow, Czernienko czy Jelcyn.</p><br clear="all" />

## Spotkanie opozycji i samorządowców. Jednym głosem o "lex Tusk"
 - [https://wydarzenia.interia.pl/kraj/news-spotkanie-opozycji-i-samorzadowcow-jednym-glosem-o-lex-tusk,nId,6808419](https://wydarzenia.interia.pl/kraj/news-spotkanie-opozycji-i-samorzadowcow-jednym-glosem-o-lex-tusk,nId,6808419)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 16:53:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-spotkanie-opozycji-i-samorzadowcow-jednym-glosem-o-lex-tusk,nId,6808419"><img align="left" alt="Spotkanie opozycji i samorządowców. Jednym głosem o &quot;lex Tusk&quot;" src="https://i.iplsc.com/spotkanie-opozycji-i-samorzadowcow-jednym-glosem-o-lex-tusk/000H7PAVORUX63WC-C321.jpg" /></a>- Mówimy &quot;nie&quot; dla hańby, którą okrył się prezydent Rzeczpospolitej - mówił w poniedziałek w Gliwicach prezes PSL Władysław Kosiniak-Kamysz podczas wspólnej konferencji prasowej z samorządowcami oraz liderami Nowej Lewicy i Koalicji Obywatelskiej. Nawiązywał do podpisu, który Andrzej Duda złożył pod ustawą powołującą komisję ds. badania wpływów rosyjskich, nazywaną przez jej przeciwników &quot;lex Tusk&quot;. Politycy opozycji alarmowali, że zaakceptowane przez głowę państwa przepisy mogą uderzyć w każdego Polaka.</p><br clear="all" />

## Chińczycy oszaleli na punkcie tej pandy. 230 milionów wyświetleń
 - [https://wydarzenia.interia.pl/zagranica/news-chinczycy-oszaleli-na-punkcie-tej-pandy-230-milionow-wyswiet,nId,6808082](https://wydarzenia.interia.pl/zagranica/news-chinczycy-oszaleli-na-punkcie-tej-pandy-230-milionow-wyswiet,nId,6808082)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 16:09:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chinczycy-oszaleli-na-punkcie-tej-pandy-230-milionow-wyswiet,nId,6808082"><img align="left" alt="Chińczycy oszaleli na punkcie tej pandy. 230 milionów wyświetleń" src="https://i.iplsc.com/chinczycy-oszaleli-na-punkcie-tej-pandy-230-milionow-wyswiet/000H7NB6GBAFDJKC-C321.jpg" /></a>Ya Ya, panda, która przez 20 lat przebywała w Stanach Zjednoczonych, powróciła do swojej ojczyzny - Chin. Po przylocie z zagranicy przeszła kwarantannę, a teraz w końcu trafiła do zoo w Pekinie. Media obiegły zdjęcia i nagrania, na których widać zwierzę zagryzające bambusa. Pandę wielką przywitały tłumy Chińczyków. Na Weibo, chińskim odpowiedniku Twittera, najpopularniejszy stał się hashtag śledzący powrót Ya Ya. Szybko zyskał ponad 230 milionów wyświetleń.</p><br clear="all" />

## Media: Co najmniej 16 weteranów armii USA zginęło w Ukrainie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-co-najmniej-16-weteranow-armii-usa-zginelo-w-ukrainie,nId,6808222](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-co-najmniej-16-weteranow-armii-usa-zginelo-w-ukrainie,nId,6808222)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 15:44:25+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-co-najmniej-16-weteranow-armii-usa-zginelo-w-ukrainie,nId,6808222"><img align="left" alt="Media: Co najmniej 16 weteranów armii USA zginęło w Ukrainie " src="https://i.iplsc.com/media-co-najmniej-16-weteranow-armii-usa-zginelo-w-ukrainie/000H7OV8UQ391COF-C321.jpg" /></a>Od początku inwazji Rosji na Ukrainie zginęło co najmniej 16 weteranów armii USA - poinformował w poniedziałek &quot;Washington Post&quot;. Jak podkreślono, byli to ochotnicy, którzy dobrowolnie zdecydowali się wziąć udział w walkach. 
</p><br clear="all" />

## Zmiany na granicy z Białorusią. Decyzja ministra
 - [https://wydarzenia.interia.pl/kraj/news-polska-ograniczy-ruch-na-granicy-z-bialorusia,nId,6808242](https://wydarzenia.interia.pl/kraj/news-polska-ograniczy-ruch-na-granicy-z-bialorusia,nId,6808242)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 15:37:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polska-ograniczy-ruch-na-granicy-z-bialorusia,nId,6808242"><img align="left" alt="Zmiany na granicy z Białorusią. Decyzja ministra" src="https://i.iplsc.com/zmiany-na-granicy-z-bialorusia-decyzja-ministra/000H7OXN1YS437Q6-C321.jpg" /></a>Od 1 czerwca ruch towarowy na granicy z Białorusią zawieszony dla białoruskich i rosyjskich ciężarówek i naczep - podało polskie Ministerstwo Spraw Wewnętrznych i Administracji. Kilka godzin wcześniej szef resortu Mariusz Kamiński informował o wpisaniu 365 osób związanych z reżimem Alaksandra Łukaszenki na listę sankcji. To reakcje polskiego rządu na potrzymanie wyroku ośmiu lat więzienia dla dziennikarza Andrzeja Poczobuta.</p><br clear="all" />

## Świdnik Air Festival rusza 4 czerwca. Sprawdź program, atrakcje
 - [https://wydarzenia.interia.pl/kraj/news-swidnik-air-festival-rusza-4-czerwca-sprawdz-program-atrakcj,nId,6808197](https://wydarzenia.interia.pl/kraj/news-swidnik-air-festival-rusza-4-czerwca-sprawdz-program-atrakcj,nId,6808197)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 15:01:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-swidnik-air-festival-rusza-4-czerwca-sprawdz-program-atrakcj,nId,6808197"><img align="left" alt="Świdnik Air Festival rusza 4 czerwca. Sprawdź program, atrakcje" src="https://i.iplsc.com/swidnik-air-festival-rusza-4-czerwca-sprawdz-program-atrakcj/000H7ONURYKX1AF9-C321.jpg" /></a>Lotnicza niedziela czeka na wszystkich 4 czerwca 2023 r. podczas III Świdnik Air Festivalu. Pokazy lotnicze odbędą się zarówno w ciągu dnia, jak i po zmroku. Festiwalowe gwiazdy zobaczymy na niebie od godz. 12:00 do 22:00. Bramy wejściowe na wydarzenie otworzą się o godz. 10:30. </p><br clear="all" />

## Poszukiwania 14-letniej Nikoli. Wyszła z domu i nie wróciła
 - [https://wydarzenia.interia.pl/pomorskie/news-poszukiwania-14-letniej-nikoli-wyszla-z-domu-i-nie-wrocila,nId,6808156](https://wydarzenia.interia.pl/pomorskie/news-poszukiwania-14-letniej-nikoli-wyszla-z-domu-i-nie-wrocila,nId,6808156)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 14:15:19+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-poszukiwania-14-letniej-nikoli-wyszla-z-domu-i-nie-wrocila,nId,6808156"><img align="left" alt="Poszukiwania 14-letniej Nikoli. Wyszła z domu i nie wróciła" src="https://i.iplsc.com/poszukiwania-14-letniej-nikoli-wyszla-z-domu-i-nie-wrocila/000H7OE4LMBNGA5R-C321.jpg" /></a>14-letnia Nikola Kirschen zaginęła w sobotę po południu. Wyszła z domu w Gdańsku i od tej pory nie ma z nią kontaktu. Nie wiadomo też, gdzie przebywa. Funkcjonariusze z komendy w Nowym Porcie opublikowali zdjęcia i rysopis poszukiwanej nastolatki.</p><br clear="all" />

## Tego zasiłku już nie dostaniesz z KRUS. Ważna zmiana dotyczy uprawnionych
 - [https://wydarzenia.interia.pl/ciekawostki/news-tego-zasilku-juz-nie-dostaniesz-z-krus-wazna-zmiana-dotyczy-,nId,6802864](https://wydarzenia.interia.pl/ciekawostki/news-tego-zasilku-juz-nie-dostaniesz-z-krus-wazna-zmiana-dotyczy-,nId,6802864)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 13:37:11+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-tego-zasilku-juz-nie-dostaniesz-z-krus-wazna-zmiana-dotyczy-,nId,6802864"><img align="left" alt="Tego zasiłku już nie dostaniesz z KRUS. Ważna zmiana dotyczy uprawnionych" src="https://i.iplsc.com/tego-zasilku-juz-nie-dostaniesz-z-krus-wazna-zmiana-dotyczy/000H7B1B44BAE8X2-C321.jpg" /></a>KRUS zapowiedział zmiany w sposobie wypłacania zasiłku pogrzebowego. Co się zmieni? Kogo będą dotyczyć nowe zasady? Sprawdź, jak się zmieni sposób przyznawania i wypłacania rekompensaty za poniesione koszty pogrzebu. </p><br clear="all" />

## Komisja, jakiej jeszcze nie było. Na co tak naprawdę zgodził się prezydent?
 - [https://wydarzenia.interia.pl/kraj/news-komisja-jakiej-jeszcze-nie-bylo-na-co-tak-naprawde-zgodzil-s,nId,6808049](https://wydarzenia.interia.pl/kraj/news-komisja-jakiej-jeszcze-nie-bylo-na-co-tak-naprawde-zgodzil-s,nId,6808049)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 12:48:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-komisja-jakiej-jeszcze-nie-bylo-na-co-tak-naprawde-zgodzil-s,nId,6808049"><img align="left" alt="Komisja, jakiej jeszcze nie było. Na co tak naprawdę zgodził się prezydent?" src="https://i.iplsc.com/komisja-jakiej-jeszcze-nie-bylo-na-co-tak-naprawde-zgodzil-s/000H7NHKYHLHOWK4-C321.jpg" /></a>Prezydent Andrzej Duda poinformował w poniedziałek rano, że podpisze ustawę powołującą komisję ds. badania rosyjskich wpływów. Komisja od początku budzi wiele kontrowersji, zwłaszcza po stronie opozycji, która określa nowe przepisy mianem &quot;lex Tusk&quot;. Interia przyjrzała się najważniejszym zarzutom wobec tej ustawy oraz temu, jak odpowiada na nie strona rządząca. </p><br clear="all" />

## Pandemia doprowadziła Wuhan na skraj upadku. Apel władz miast
 - [https://wydarzenia.interia.pl/zagranica/news-pandemia-doprowadzila-wuhan-na-skraj-upadku-apel-wladz-miast,nId,6807980](https://wydarzenia.interia.pl/zagranica/news-pandemia-doprowadzila-wuhan-na-skraj-upadku-apel-wladz-miast,nId,6807980)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 12:42:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pandemia-doprowadzila-wuhan-na-skraj-upadku-apel-wladz-miast,nId,6807980"><img align="left" alt="Pandemia doprowadziła Wuhan na skraj upadku. Apel władz miast " src="https://i.iplsc.com/pandemia-doprowadzila-wuhan-na-skraj-upadku-apel-wladz-miast/000H7NHW2PEWD3BD-C321.jpg" /></a>Władze Wuhanu, największego miasta w środkowych Chinach, publicznie zaapelowały do swoich dłużników, wśród których są również państwowe firmy o spłatę należności. Jest to niezwykle rzadkie posunięcie, które podkreśla tragiczną sytuację finansową miasta dotkniętego pandemią COVID-19 i wprowadzonymi w związku z nią obostrzeniami - podaje CNN. Jak się jednak okazuje, z problemami, które ma Wuhan, borykają się również inne chińskie miasta.</p><br clear="all" />

## Polska rozszerza sankcje na Białorusinów. Odwet za wyrok na Poczobuta
 - [https://wydarzenia.interia.pl/kraj/news-polska-rozszerza-sankcje-na-bialorusinow-odwet-za-wyrok-na-p,nId,6808055](https://wydarzenia.interia.pl/kraj/news-polska-rozszerza-sankcje-na-bialorusinow-odwet-za-wyrok-na-p,nId,6808055)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 12:38:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polska-rozszerza-sankcje-na-bialorusinow-odwet-za-wyrok-na-p,nId,6808055"><img align="left" alt="Polska rozszerza sankcje na Białorusinów. Odwet za wyrok na Poczobuta" src="https://i.iplsc.com/polska-rozszerza-sankcje-na-bialorusinow-odwet-za-wyrok-na-p/000H7NE4VOSV2M04-C321.jpg" /></a>365 osób powiązanych z władzami Białorusi wpisało w poniedziałek polskie MSWiA na listę sankcyjną. O reakcji Warszawy po tym, jak Sąd Najwyższy w Mińsku podtrzymał surowy wyrok na Andrzeja Poczobuta, poinformował minister Mariusz Kamiński. W wykazie pojawiły się nazwiska parlamentarzystów, sędziów, prokuratorów, ale i sportowców oraz pracowników mediów.</p><br clear="all" />

## Zatrzymano chiński statek. Mógł plądrować wraki brytyjskich okrętów
 - [https://wydarzenia.interia.pl/zagranica/news-zatrzymano-chinski-statek-mogl-pladrowac-wraki-brytyjskich-o,nId,6807996](https://wydarzenia.interia.pl/zagranica/news-zatrzymano-chinski-statek-mogl-pladrowac-wraki-brytyjskich-o,nId,6807996)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 12:35:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zatrzymano-chinski-statek-mogl-pladrowac-wraki-brytyjskich-o,nId,6807996"><img align="left" alt="Zatrzymano chiński statek. Mógł plądrować wraki brytyjskich okrętów" src="https://i.iplsc.com/zatrzymano-chinski-statek-mogl-pladrowac-wraki-brytyjskich-o/000H7N641EYNF5FR-C321.jpg" /></a>Statek zarejestrowany w Chinach został zatrzymany u wybrzeży Johor w Malezji. Znaleziono na nim pocisk armatni, który prawdopodobnie pochodzi z okresu II wojny światowej. Pojawiły się wątpliwości, czy statek nie uczestniczył w plądrowaniu brytyjskich okrętów.</p><br clear="all" />

## Myślała, że wygrała 2000 dolarów. Suma była o wiele wyższa
 - [https://wydarzenia.interia.pl/zagranica/news-myslala-ze-wygrala-2000-dolarow-suma-byla-o-wiele-wyzsza,nId,6807994](https://wydarzenia.interia.pl/zagranica/news-myslala-ze-wygrala-2000-dolarow-suma-byla-o-wiele-wyzsza,nId,6807994)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 12:17:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-myslala-ze-wygrala-2000-dolarow-suma-byla-o-wiele-wyzsza,nId,6807994"><img align="left" alt="Myślała, że wygrała 2000 dolarów. Suma była o wiele wyższa" src="https://i.iplsc.com/myslala-ze-wygrala-2000-dolarow-suma-byla-o-wiele-wyzsza/000H7N58QJGP5OYU-C321.jpg" /></a>Ruby Evans z Kalifornii była przekonana, że udało jej się wygrać dwa 2000 dolarów w zdrapce. Jak się jednak okazało, wygrana była o wiele większa... Ostatecznie Evans zgarnęła główną nagrodę - dwa miliony dolarów. Nie był to pierwszy raz, kiedy miała takie szczęście.</p><br clear="all" />

## "Porażająca historia". Posłowie reagują na reportaż Interii
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-porazajaca-historia-poslowie-reaguja-na-reportaz-interii,nId,6807949](https://wydarzenia.interia.pl/tylko-w-interii/news-porazajaca-historia-poslowie-reaguja-na-reportaz-interii,nId,6807949)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 11:44:38+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-porazajaca-historia-poslowie-reaguja-na-reportaz-interii,nId,6807949"><img align="left" alt="&quot;Porażająca historia&quot;. Posłowie reagują na reportaż Interii" src="https://i.iplsc.com/porazajaca-historia-poslowie-reaguja-na-reportaz-interii/000H7MZ8UATB2CM2-C321.jpg" /></a>- Porażająca historia. Przypomina sprawę Tomasza Komendy. Pokazuje bezsilność obywatela wobec państwa - mówi w rozmowie z Interią poseł Michał Szczerba. - To historia człowieka zmanipulowanego, który z powodu swoich obniżonych zdolności intelektualnych nie był w stanie przeciwstawić się władzy - ocenia posłanka Anna Maria Żukowska. W ten sposób parlamentarzyści z komisji sprawiedliwości odnoszą się do sprawy Piotra Mikołajczyka, którą opisaliśmy w Interii. Mężczyzna został skazany za morderstwo dwóch kobiet, choć nie było żadnego dowodu...</p><br clear="all" />

## Prezydent Kazachstanu wyśmiał ofertę Łukaszenki. "Doceniam jego żart"
 - [https://wydarzenia.interia.pl/zagranica/news-prezydent-kazachstanu-wysmial-oferte-lukaszenki-doceniam-jeg,nId,6807985](https://wydarzenia.interia.pl/zagranica/news-prezydent-kazachstanu-wysmial-oferte-lukaszenki-doceniam-jeg,nId,6807985)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 11:42:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prezydent-kazachstanu-wysmial-oferte-lukaszenki-doceniam-jeg,nId,6807985"><img align="left" alt="Prezydent Kazachstanu wyśmiał ofertę Łukaszenki. &quot;Doceniam jego żart&quot;" src="https://i.iplsc.com/prezydent-kazachstanu-wysmial-oferte-lukaszenki-doceniam-jeg/000G5UACA8AS7I2S-C321.jpg" /></a>- Doceniam jego żart - stwierdził prezydent Kassym-Zhomart Tokajew, odnosząc się do propozycji wystosowanej przez Alaksandra Łukaszenkę. Dyktator z Mińska zaoferował rozszerzenie Państwa Związkowego poprzez dołączenie Kazachstanu.</p><br clear="all" />

## Jechali na szkolną wycieczkę, autokar stanął w ogniu. Troje uczniów w szpitalu
 - [https://wydarzenia.interia.pl/opolskie/news-jechali-na-szkolna-wycieczke-autokar-stanal-w-ogniu-troje-uc,nId,6807930](https://wydarzenia.interia.pl/opolskie/news-jechali-na-szkolna-wycieczke-autokar-stanal-w-ogniu-troje-uc,nId,6807930)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 11:25:00+00:00

<p><a href="https://wydarzenia.interia.pl/opolskie/news-jechali-na-szkolna-wycieczke-autokar-stanal-w-ogniu-troje-uc,nId,6807930"><img align="left" alt="Jechali na szkolną wycieczkę, autokar stanął w ogniu. Troje uczniów w szpitalu" src="https://i.iplsc.com/jechali-na-szkolna-wycieczke-autokar-stanal-w-ogniu-troje-uc/000H7MYRFNYYYWMF-C321.jpg" /></a>Na autostradzie A4 zapalił się autokar, przewożący wycieczkę szkolną ósmoklasistów. Na skutek zdarzenia troje uczniów zostało zabranych do szpitala. Jak powiadomiła Interię sierż. sztab. Dorota Janać z Komendy Powiatowej Policji w Strzelcach Opolskich, ich życiu i zdrowiu nie zagraża niebezpieczeństwo. Trasa A4 na opolskim odcinku w kierunku Katowic została zablokowana, a kierowcy kierowani są na objazdy. </p><br clear="all" />

## USA: Wjechała samochodem do oceanu. "Próbowałam zawrócić"
 - [https://wydarzenia.interia.pl/zagranica/news-usa-wjechala-samochodem-do-oceanu-probowalam-zawrocic,nId,6807894](https://wydarzenia.interia.pl/zagranica/news-usa-wjechala-samochodem-do-oceanu-probowalam-zawrocic,nId,6807894)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 11:10:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-wjechala-samochodem-do-oceanu-probowalam-zawrocic,nId,6807894"><img align="left" alt="USA: Wjechała samochodem do oceanu. &quot;Próbowałam zawrócić&quot;" src="https://i.iplsc.com/usa-wjechala-samochodem-do-oceanu-probowalam-zawrocic/000H7MXRU7HTQ8VR-C321.jpg" /></a>26-latka z Florydy wjechała swoim samochodem do oceanu. Według świadków zdarzenia kobieta, jadąc po zatłoczonej plaży omal nie doprowadziła do tragedii. Sarah Ramsammy, która jak się okazało była pod wpływem alkoholu, tłumaczyła wezwanym na miejsce policjantom, że chciała jedynie zawrócić.</p><br clear="all" />

## Hiszpania: Premier rozwiązał parlament. Ogłoszono przedterminowe wybory
 - [https://wydarzenia.interia.pl/zagranica/news-hiszpania-premier-rozwiazal-parlament-ogloszono-przedtermino,nId,6807936](https://wydarzenia.interia.pl/zagranica/news-hiszpania-premier-rozwiazal-parlament-ogloszono-przedtermino,nId,6807936)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 11:05:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-hiszpania-premier-rozwiazal-parlament-ogloszono-przedtermino,nId,6807936"><img align="left" alt="Hiszpania: Premier rozwiązał parlament. Ogłoszono przedterminowe wybory" src="https://i.iplsc.com/hiszpania-premier-rozwiazal-parlament-ogloszono-przedtermino/0007U6GM867IW4V1-C321.jpg" /></a>Premier Hiszpanii, Pedro Sanchez zdecydował się na rozwiązanie parlamentu i ogłoszenie przedterminowych wyborów. Decyzja związana jest z dotkliwą porażką Hiszpańskiej Socjalistycznej Partii Robotniczej (PSOE) w wyborach lokalnych i regionalnych.</p><br clear="all" />

## Nowe nagranie z udziałem Alaksandra Łukaszenki. Spotkał się z szefową Banku Centralnego Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-nowe-nagranie-z-udzialem-alaksandra-lukaszenki-spotkal-sie-z,nId,6807874](https://wydarzenia.interia.pl/zagranica/news-nowe-nagranie-z-udzialem-alaksandra-lukaszenki-spotkal-sie-z,nId,6807874)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 10:57:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowe-nagranie-z-udzialem-alaksandra-lukaszenki-spotkal-sie-z,nId,6807874"><img align="left" alt="Nowe nagranie z udziałem Alaksandra Łukaszenki. Spotkał się z szefową Banku Centralnego Rosji" src="https://i.iplsc.com/nowe-nagranie-z-udzialem-alaksandra-lukaszenki-spotkal-sie-z/000H7ML9EEQMTDBJ-C321.jpg" /></a>Alaksandr Łukaszenka spotkał się z prezesem Centralnego Banku Rosji Elwirą Nabiulliną - informuje prezydenckie biuro prasowe. Informacja przeczy wcześniejszym doniesieniom o ciężkim stanie dyktatora, który miał przebywać w szpitalu w Moskwie.</p><br clear="all" />

## "Lex Tusk". Burza po decyzji prezydenta ws. komisji ds. rosyjskich wpływów
 - [https://wydarzenia.interia.pl/kraj/news-lex-tusk-burza-po-decyzji-prezydenta-ws-komisji-ds-rosyjskic,nId,6807868](https://wydarzenia.interia.pl/kraj/news-lex-tusk-burza-po-decyzji-prezydenta-ws-komisji-ds-rosyjskic,nId,6807868)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 10:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-lex-tusk-burza-po-decyzji-prezydenta-ws-komisji-ds-rosyjskic,nId,6807868"><img align="left" alt="&quot;Lex Tusk&quot;. Burza po decyzji prezydenta ws. komisji ds. rosyjskich wpływów" src="https://i.iplsc.com/lex-tusk-burza-po-decyzji-prezydenta-ws-komisji-ds-rosyjskic/000H7MRVXISEO7YB-C321.jpg" /></a>Prezydent Andrzej Duda powiadomił w poniedziałek, że podpisze ustawę o powołaniu komisji do spraw wpływów rosyjskich, tzw. lex Tusk. Ogłoszenie Dudy wywołało poruszenie wśród polskich polityków. - To bardzo dobra decyzja prezydenta Andrzeja Dudy, która, wpisuje się w ciąg działań, jakie podejmujemy, by zwiększać transparentność w naszym życiu publicznym - komentuje w rozmowie z Interią Rafał Bochenek, rzecznik PiS. Całkowicie odmienne zdaniem mają przedstawiciele opozycji. - Skompromitowany prezydent Duda kompromituje się po raz kolejny....</p><br clear="all" />

## Premier: Wystarczy, gdyby Tusk powiedział, o czym rozmawiał z Putinem
 - [https://wydarzenia.interia.pl/kraj/news-premier-wystarczy-gdyby-tusk-powiedzial-o-czym-rozmawial-z-p,nId,6807913](https://wydarzenia.interia.pl/kraj/news-premier-wystarczy-gdyby-tusk-powiedzial-o-czym-rozmawial-z-p,nId,6807913)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 10:32:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-wystarczy-gdyby-tusk-powiedzial-o-czym-rozmawial-z-p,nId,6807913"><img align="left" alt="Premier: Wystarczy, gdyby Tusk powiedział, o czym rozmawiał z Putinem" src="https://i.iplsc.com/premier-wystarczy-gdyby-tusk-powiedzial-o-czym-rozmawial-z-p/000H7MQWG8ULFCII-C321.jpg" /></a>- Wystarczy, gdyby powiedział, o czym rozmawiali z Putinem na molo w Sopocie, czy w samolocie, o czym rozmawiali ze sobą kiedy nie było to rejestrowane - oświadczył na konferencji premier Mateusz Morawiecki, który swoje słowa skierował w stronę Donalda Tuska. Premier został zapytany o decyzję prezydenta ws. ustanowienia komisji ds. badania wpływów rosyjskich. </p><br clear="all" />

## Tusk odpowiada prezydentowi. "Zapraszam na konsultacje społeczne"
 - [https://wydarzenia.interia.pl/kraj/news-tusk-odpowiada-prezydentowi-zapraszam-na-konsultacje-spolecz,nId,6807908](https://wydarzenia.interia.pl/kraj/news-tusk-odpowiada-prezydentowi-zapraszam-na-konsultacje-spolecz,nId,6807908)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 10:16:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-odpowiada-prezydentowi-zapraszam-na-konsultacje-spolecz,nId,6807908"><img align="left" alt="Tusk odpowiada prezydentowi. &quot;Zapraszam na konsultacje społeczne&quot;" src="https://i.iplsc.com/tusk-odpowiada-prezydentowi-zapraszam-na-konsultacje-spolecz/000H7MU2QFXGFSSI-C321.jpg" /></a>&quot;Panie Prezydencie, zapraszam na konsultacje społeczne 4 czerwca. Będzie nas dobrze słychać i widać z okien Pańskiego pałacu. Przyjdziecie?&quot; - tak Donald Tusk zareagował na podpis prezydenta pod komisją ds. badania rosyjskich wpływów, tzw. lex Tusk.</p><br clear="all" />

## Tykająca bomba zbożowa. "Katastrofa przyjdzie po żniwach"
 - [https://wydarzenia.interia.pl/kraj/news-tykajaca-bomba-zbozowa-katastrofa-przyjdzie-po-zniwach,nId,6807757](https://wydarzenia.interia.pl/kraj/news-tykajaca-bomba-zbozowa-katastrofa-przyjdzie-po-zniwach,nId,6807757)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 09:54:29+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tykajaca-bomba-zbozowa-katastrofa-przyjdzie-po-zniwach,nId,6807757"><img align="left" alt="Tykająca bomba zbożowa. &quot;Katastrofa przyjdzie po żniwach&quot;" src="https://i.iplsc.com/tykajaca-bomba-zbozowa-katastrofa-przyjdzie-po-zniwach/000H3U0ZC70DVC3E-C321.jpg" /></a>Rolnicy nie sprzedają ziarna z uwagi na spadki cen. Tymczasem ukraińskie zboże wciąż trafia do Polski. - Coś tam ruszyło po wymianie ministra, ale bomba przed nami. Czekamy na żniwa i to dopiero będzie dramat - mówi Interii rolnik Bartłomiej Szajner. Minister rolnictwa zapewnia, że sprawa znajduje się &quot;pod pełną kontrolą&quot;.</p><br clear="all" />

## Rosyjski senator uderza w Polskę. "Elity chore na szpiegomanię i rusofobię"
 - [https://wydarzenia.interia.pl/zagranica/news-rosyjski-senator-uderza-w-polske-elity-chore-na-szpiegomanie,nId,6807781](https://wydarzenia.interia.pl/zagranica/news-rosyjski-senator-uderza-w-polske-elity-chore-na-szpiegomanie,nId,6807781)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 09:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosyjski-senator-uderza-w-polske-elity-chore-na-szpiegomanie,nId,6807781"><img align="left" alt="Rosyjski senator uderza w Polskę. &quot;Elity chore na szpiegomanię i rusofobię&quot;" src="https://i.iplsc.com/rosyjski-senator-uderza-w-polske-elity-chore-na-szpiegomanie/000H7M3QHDDTYCVG-C321.jpg" /></a>&quot;Szpiegomania i chęć zobaczenia wszędzie agentów Moskwy to nieuleczalna choroba obecnych polskich elit&quot; - twierdzi rosyjski senator Aleksiej Puszkow. Polityk kremlowskiego reżimu nie ukrywa, że jest oburzony postawą polskich władz wobec Federacji Rosyjskiej.</p><br clear="all" />

## Hiszpania: Na głosowanie potrzebowali mniej niż 30 sekund
 - [https://wydarzenia.interia.pl/zagranica/news-hiszpania-na-glosowanie-potrzebowali-mniej-niz-30-sekund,nId,6807811](https://wydarzenia.interia.pl/zagranica/news-hiszpania-na-glosowanie-potrzebowali-mniej-niz-30-sekund,nId,6807811)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 09:29:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-hiszpania-na-glosowanie-potrzebowali-mniej-niz-30-sekund,nId,6807811"><img align="left" alt="Hiszpania: Na głosowanie potrzebowali mniej niż 30 sekund" src="https://i.iplsc.com/hiszpania-na-glosowanie-potrzebowali-mniej-niz-30-sekund/000H7M9I76C6VX2E-C321.jpg" /></a>Mieszkańcy hiszpańskiej wioski Villaroya nie potrzebowali nawet 30 sekund, by wszyscy oddali głos w wyborach do władz regionalnych i lokalnych, które zostały przeprowadzone w niedzielę. Mieszkańcom udało się pobić swój poprzedni rekord z 2019 roku. </p><br clear="all" />

## Władza za wszelką cenę
 - [https://wydarzenia.interia.pl/felietony/news-wladza-za-wszelka-cene,nId,6807857](https://wydarzenia.interia.pl/felietony/news-wladza-za-wszelka-cene,nId,6807857)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 09:25:04+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/news-wladza-za-wszelka-cene,nId,6807857"><img align="left" alt="Władza za wszelką cenę" src="https://i.iplsc.com/wladza-za-wszelka-cene/000GSJUE5RCII0KS-C321.jpg" /></a>Po co Jarosław Kaczyński wymyślił stojącą ponad państwem i prawem komisję, która na życzenie partii władzy osądzi dowolnie wybranego przedstawiciela opozycji, a od wyroków skazujących na dekadę śmierci politycznej nie będzie można się odwołać? Z pewnością nie po to, by Andrzej Duda, uwiedziony rozmaitymi zdroworozsądkowym apelami, ten projekt definitywnie skasował, bo podważyłoby to wiarygodność jego macierzystej partii i skazało ją na spektakularny blamaż w roku wyborczym. Dzisiejsza decyzja prezydenta - podpisanie ustawy i dla...</p><br clear="all" />

## Słoneczna pogoda przyniesie zagrożenie. Nadciąga susza
 - [https://wydarzenia.interia.pl/kraj/news-sloneczna-pogoda-przyniesie-zagrozenie-nadciaga-susza,nId,6807766](https://wydarzenia.interia.pl/kraj/news-sloneczna-pogoda-przyniesie-zagrozenie-nadciaga-susza,nId,6807766)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 09:25:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sloneczna-pogoda-przyniesie-zagrozenie-nadciaga-susza,nId,6807766"><img align="left" alt="Słoneczna pogoda przyniesie zagrożenie. Nadciąga susza" src="https://i.iplsc.com/sloneczna-pogoda-przyniesie-zagrozenie-nadciaga-susza/000H7M3UJ9PSW4UY-C321.jpg" /></a>W ostatnim czasie mogliśmy zapomnieć o deszczowej pogodzie, kiedy w kraju zrobiło się cieplej, a promienie słońca świeciły dłużej. Nie inaczej będzie w najbliższych dniach. Chociaż nie zabraknie lekkich i przelotnych opadów deszczu, to mapy i prognozy jasno wskazują - nadchodzi susza.</p><br clear="all" />

## Ma IQ 62 i popełnił zbrodnię doskonałą? Kompromitujące wyniki śledztwa
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-ma-iq-62-i-popelnil-zbrodnie-doskonala-kompromitujace-wyniki,nId,6807819](https://wydarzenia.interia.pl/tylko-w-interii/news-ma-iq-62-i-popelnil-zbrodnie-doskonala-kompromitujace-wyniki,nId,6807819)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 09:02:03+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-ma-iq-62-i-popelnil-zbrodnie-doskonala-kompromitujace-wyniki,nId,6807819"><img align="left" alt="Ma IQ 62 i popełnił zbrodnię doskonałą? Kompromitujące wyniki śledztwa" src="https://i.iplsc.com/ma-iq-62-i-popelnil-zbrodnie-doskonala-kompromitujace-wyniki/000H7MB579R0RSSJ-C321.jpg" /></a>Piotr Mikołajczyk to dorosły mężczyzna o umyśle 10-letniego chłopca. Ma IQ 62 i według śledczych popełnił zbrodnię doskonałą. Od 12 lat odsiaduje wyrok za brutalne zabójstwo dwóch kobiet, mimo że nie znaleziono żadnych dowodów świadczących o jego winie. Dzisiaj w Interii wstrząsający reportaż Dawida Serafina &quot;Skazany za niewinność&quot;. </p><br clear="all" />

## Białoruś drży przed dywersantami. Część dróg do Rosji zamknięta
 - [https://wydarzenia.interia.pl/zagranica/news-bialorus-drzy-przed-dywersantami-czesc-drog-do-rosji-zamknie,nId,6807737](https://wydarzenia.interia.pl/zagranica/news-bialorus-drzy-przed-dywersantami-czesc-drog-do-rosji-zamknie,nId,6807737)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 08:06:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialorus-drzy-przed-dywersantami-czesc-drog-do-rosji-zamknie,nId,6807737"><img align="left" alt="Białoruś drży przed dywersantami. Część dróg do Rosji zamknięta" src="https://i.iplsc.com/bialorus-drzy-przed-dywersantami-czesc-drog-do-rosji-zamknie/000H7LV4YOLY3IC6-C321.jpg" /></a>Białoruś w celu zapewnienia bezpieczeństwa zamknęła drogi łączące ją z Rosją - ogłosiła w poniedziałek prokremlowska agencja Ria Nowosti. Jak się okazuje, reżimowe władze Białorusi dla ochrony przed &quot;nielegalnymi formacjami zbrojnymi&quot;, czyli grupami dywersyjnymi, zaleciły zamknięcie &quot;nieużytkowych dróg&quot; i wzmocnienie kontroli na głównych drogach. Zgodnie z zapowiedziami białoruskich władz, na granicy mają także stacjonować jednostki wojskowe. </p><br clear="all" />

## Obrzydliwa "niespodzianka" z kranu. Zrozpaczeni mieszkańcy pokazują zdjęcia
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-obrzydliwa-niespodzianka-z-kranu-zrozpaczeni-mieszkancy-poka,nId,6802479](https://wydarzenia.interia.pl/tylko-w-interii/news-obrzydliwa-niespodzianka-z-kranu-zrozpaczeni-mieszkancy-poka,nId,6802479)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 07:53:00+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-obrzydliwa-niespodzianka-z-kranu-zrozpaczeni-mieszkancy-poka,nId,6802479"><img align="left" alt="Obrzydliwa &quot;niespodzianka&quot; z kranu. Zrozpaczeni mieszkańcy pokazują zdjęcia" src="https://i.iplsc.com/obrzydliwa-niespodzianka-z-kranu-zrozpaczeni-mieszkancy-poka/000H79Y99BVFH58S-C321.jpg" /></a>Płacimy za dobrą wodę, a niestety leci syf - skarżą się w rozmowie z Interią mieszkańcy gminy Obrowo (woj. kujawsko-pomorskie). Po ostatniej awarii sieci wodociągowej z kranów leciała ciecz o kolorze whisky. Do tego zdarza się, że woda śmierdzi zgniłymi jajami. Urzędnicy zapewniają, że problemy są chwilowe, ale nie przekonuje to mieszkańców. - Dzieci kąpię u teściowej, która mieszka w innej gminie. Stamtąd też zwozimy wodę w baniakach do domu. Absolutnie tego co leci u nas z kranu nie pijemy - mówi Interii Emilia.</p><br clear="all" />

## Śmierdząca i brązowa "niespodzianka" z kranu. Mieszkańcy mówią o "błędnym kole"
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-smierdzaca-i-brazowa-niespodzianka-z-kranu-mieszkancy-mowia-,nId,6802479](https://wydarzenia.interia.pl/tylko-w-interii/news-smierdzaca-i-brazowa-niespodzianka-z-kranu-mieszkancy-mowia-,nId,6802479)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 07:53:00+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-smierdzaca-i-brazowa-niespodzianka-z-kranu-mieszkancy-mowia-,nId,6802479"><img align="left" alt="Śmierdząca i brązowa &quot;niespodzianka&quot; z kranu. Mieszkańcy mówią o &quot;błędnym kole&quot;" src="https://i.iplsc.com/smierdzaca-i-brazowa-niespodzianka-z-kranu-mieszkancy-mowia/000H79Y99BVFH58S-C321.jpg" /></a>Płacimy za dobrą wodę, a niestety leci syf - skarżą się w rozmowie z Interią mieszkańcy gminy Obrowo (woj. kujawsko-pomorskie). Po ostatniej awarii sieci wodociągowej z kranów leciała ciecz o kolorze whisky. Do tego zdarza się, że woda śmierdzi zgniłymi jajami. Urzędnicy zapewniają, że problemy są chwilowe, ale nie przekonuje to mieszkańców. - Dzieci kąpię u teściowej, która mieszka w innej gminie. Stamtąd też zwozimy wodę w baniakach do domu. Absolutnie tego co leci u nas z kranu nie pijemy - mówi Interii Emilia.</p><br clear="all" />

## Pomorskie: Pożar zakładu stolarskiego produkującego trumny
 - [https://wydarzenia.interia.pl/pomorskie/news-pomorskie-pozar-zakladu-stolarskiego-produkujacego-trumny,nId,6807758](https://wydarzenia.interia.pl/pomorskie/news-pomorskie-pozar-zakladu-stolarskiego-produkujacego-trumny,nId,6807758)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 07:44:10+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-pomorskie-pozar-zakladu-stolarskiego-produkujacego-trumny,nId,6807758"><img align="left" alt="Pomorskie: Pożar zakładu stolarskiego produkującego trumny" src="https://i.iplsc.com/pomorskie-pozar-zakladu-stolarskiego-produkujacego-trumny/000H7LWJVVULEBCR-C321.jpg" /></a>W nocy z niedzieli na poniedziałek w Łubnej (woj. pomorskie) doszło do pożaru zakładu stolarskiego produkującego trumny. Chociaż pożar został już opanowany, straty materialne są ogromne. W szczytowym momencie akcji z ogniem walczyły 32 zastępy straży pożarnej.</p><br clear="all" />

## "Grupa Wagnera praktycznie nie istnieje". Dowódca "Gruzińskiego Legionu Narodowego" o sytuacji w Bachmucie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-grupa-wagnera-praktycznie-nie-istnieje-dowodca-gruzinskiego-,nId,6807739](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-grupa-wagnera-praktycznie-nie-istnieje-dowodca-gruzinskiego-,nId,6807739)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 07:41:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-grupa-wagnera-praktycznie-nie-istnieje-dowodca-gruzinskiego-,nId,6807739"><img align="left" alt="&quot;Grupa Wagnera praktycznie nie istnieje&quot;. Dowódca &quot;Gruzińskiego Legionu Narodowego&quot; o sytuacji w Bachmucie" src="https://i.iplsc.com/grupa-wagnera-praktycznie-nie-istnieje-dowodca-gruzinskiego/000H7LUWLAJX5SOY-C321.jpg" /></a>- Myślę, że grupa Wagnera praktycznie nie istnieje, a Bachmut odegrał ogromną rolę w jej zniszczeniu - twierdzi Mamuk Mamulashvili, dowódca &quot;Gruzińskiego Legionu Narodowego&quot;. Żołnierz przedstawił najnowsze informacje dotyczące walk w okolicach zrujnowanego miasta.</p><br clear="all" />

## Włochy: Łódź przewróciła się na jeziorze. Cztery osoby utonęły
 - [https://wydarzenia.interia.pl/zagranica/news-wlochy-lodz-przewrocila-sie-na-jeziorze-cztery-osoby-utonely,nId,6807740](https://wydarzenia.interia.pl/zagranica/news-wlochy-lodz-przewrocila-sie-na-jeziorze-cztery-osoby-utonely,nId,6807740)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 07:35:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlochy-lodz-przewrocila-sie-na-jeziorze-cztery-osoby-utonely,nId,6807740"><img align="left" alt="Włochy: Łódź przewróciła się na jeziorze. Cztery osoby utonęły" src="https://i.iplsc.com/wlochy-lodz-przewrocila-sie-na-jeziorze-cztery-osoby-utonely/000H7LPRKWVPYQSR-C321.jpg" /></a>Tragedia na jeziorze Maggiore we Włoszech. Co najmniej cztery osoby zginęły po tym, jak wywróciła się łódź turystyczna. W akcji ratunkowej uczestniczyli strażacy wspomagani przez śmigłowiec. Pojawiają się sprzeczne informacje dotyczące narodowości osób, które znajdowały się na pokładzie.</p><br clear="all" />

## Rosyjskie MSW: Senator Graham na liście ściganych. "Rusofobiczne wypowiedzi"
 - [https://wydarzenia.interia.pl/zagranica/news-rosyjskie-msw-senator-graham-na-liscie-sciganych-rusofobiczn,nId,6807706](https://wydarzenia.interia.pl/zagranica/news-rosyjskie-msw-senator-graham-na-liscie-sciganych-rusofobiczn,nId,6807706)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 07:14:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosyjskie-msw-senator-graham-na-liscie-sciganych-rusofobiczn,nId,6807706"><img align="left" alt="Rosyjskie MSW: Senator Graham na liście ściganych. &quot;Rusofobiczne wypowiedzi&quot;" src="https://i.iplsc.com/rosyjskie-msw-senator-graham-na-liscie-sciganych-rusofobiczn/000H7LOLXOLY4NWO-C321.jpg" /></a>Ministerstwo Spraw Wewnętrznych Federacji Rosyjskiej wpisało senatora Lindsey'a Grahama na listę osób poszukiwanych - informuje agencja informacyjna TASS. W wyjaśnieniu podano, że powodem są rusofobiczne wypowiedzi amerykańskiego polityka.</p><br clear="all" />

## Oświadczenie prezydenta Andrzeja Dudy. "Lex Tusk" czeka na decyzję
 - [https://wydarzenia.interia.pl/kraj/news-oswiadczenie-prezydenta-andrzeja-dudy-lex-tusk-czeka-na-decy,nId,6807729](https://wydarzenia.interia.pl/kraj/news-oswiadczenie-prezydenta-andrzeja-dudy-lex-tusk-czeka-na-decy,nId,6807729)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 06:50:10+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-oswiadczenie-prezydenta-andrzeja-dudy-lex-tusk-czeka-na-decy,nId,6807729"><img align="left" alt="Oświadczenie prezydenta Andrzeja Dudy. &quot;Lex Tusk&quot; czeka na decyzję" src="https://i.iplsc.com/oswiadczenie-prezydenta-andrzeja-dudy-lex-tusk-czeka-na-decy/000H7LOR68MHJAUE-C321.jpg" /></a>W poniedziałek o godz. 10.30 w Pałacu Prezydenckim prezydent Andrzej Duda wygłosi oświadczenie - poinformowało biuro prasowe Kancelarii Prezydenta RP. Tematu wypowiedzi nie ujawniono. Na biurko prezydenta trafiła ustawa o powołaniu komisji do spraw wpływów rosyjskich, tzw. lex Tusk.</p><br clear="all" />

## Słowacja: Tragedia w Karpatach. Matka zginęła na oczach dzieci
 - [https://wydarzenia.interia.pl/zagranica/news-slowacja-tragedia-w-karpatach-matka-zginela-na-oczach-dzieci,nId,6807682](https://wydarzenia.interia.pl/zagranica/news-slowacja-tragedia-w-karpatach-matka-zginela-na-oczach-dzieci,nId,6807682)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 06:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-slowacja-tragedia-w-karpatach-matka-zginela-na-oczach-dzieci,nId,6807682"><img align="left" alt="Słowacja: Tragedia w Karpatach. Matka zginęła na oczach dzieci" src="https://i.iplsc.com/slowacja-tragedia-w-karpatach-matka-zginela-na-oczach-dzieci/000H7LS73IFLPSV2-C321.jpg" /></a>Tragedia po słowackiej stronie Karpat. Matka, która wybrała się na wędrówkę po górach z trójką małych dzieci, spadła ze szlaku i runęła w przepaść. Kobiety nie udało się uratować - zginęła na miejscu. Jej dzieciom nic się nie stało. </p><br clear="all" />

## Seria tragicznych strzelanin w USA. Ciało niedaleko domu burmistrza
 - [https://wydarzenia.interia.pl/zagranica/news-seria-tragicznych-strzelanin-w-usa-cialo-niedaleko-domu-burm,nId,6807707](https://wydarzenia.interia.pl/zagranica/news-seria-tragicznych-strzelanin-w-usa-cialo-niedaleko-domu-burm,nId,6807707)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 06:25:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-seria-tragicznych-strzelanin-w-usa-cialo-niedaleko-domu-burm,nId,6807707"><img align="left" alt="Seria tragicznych strzelanin w USA. Ciało niedaleko domu burmistrza" src="https://i.iplsc.com/seria-tragicznych-strzelanin-w-usa-cialo-niedaleko-domu-burm/000DSNK5SDF0S1ST-C321.jpg" /></a>Długi weekend z okazji święta Dnia Pamięci w Stanach Zjednoczonych, który jeszcze trwa, stanął pod znakiem przemocy. W serii strzelanin zginęło co najmniej 19 osób, w tym dziewięć w samym Chicago, gdzie dwie przecznice od domu burmistrza znaleziono ciało.</p><br clear="all" />

## Łukaszenka pogratulował "przyjacielowi Białorusi": Zawsze możesz na nas liczyć
 - [https://wydarzenia.interia.pl/zagranica/news-lukaszenka-pogratulowal-przyjacielowi-bialorusi-zawsze-mozes,nId,6807698](https://wydarzenia.interia.pl/zagranica/news-lukaszenka-pogratulowal-przyjacielowi-bialorusi-zawsze-mozes,nId,6807698)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 06:15:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lukaszenka-pogratulowal-przyjacielowi-bialorusi-zawsze-mozes,nId,6807698"><img align="left" alt="Łukaszenka pogratulował &quot;przyjacielowi Białorusi&quot;: Zawsze możesz na nas liczyć" src="https://i.iplsc.com/lukaszenka-pogratulowal-przyjacielowi-bialorusi-zawsze-mozes/000H7LAH125JAVJ4-C321.jpg" /></a>Alaksandr Łukaszenka pogratulował tureckiemu prezydentowi Recepowi Tayyipowi Erdoganowi reelekcji. &quot;Mamy takie same interesy w zakresie deeskalacji sytuacji międzynarodowej&quot; - napisał białoruski dyktator, zaznaczając, że Erdogan &quot;zawsze może liczyć&quot; na Białoruś. </p><br clear="all" />

## Alaksandr Łukaszenka panicznie boi się zamachu. Pułk Kalinowskiego gotowy go obalić
 - [https://wydarzenia.interia.pl/zagranica/news-alaksandr-lukaszenka-panicznie-boi-sie-zamachu-pulk-kalinows,nId,6807689](https://wydarzenia.interia.pl/zagranica/news-alaksandr-lukaszenka-panicznie-boi-sie-zamachu-pulk-kalinows,nId,6807689)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 06:01:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-alaksandr-lukaszenka-panicznie-boi-sie-zamachu-pulk-kalinows,nId,6807689"><img align="left" alt="Alaksandr Łukaszenka panicznie boi się zamachu. Pułk Kalinowskiego gotowy go obalić" src="https://i.iplsc.com/alaksandr-lukaszenka-panicznie-boi-sie-zamachu-pulk-kalinows/000GT6TIPYPO98GL-C321.jpg" /></a>- Infiltracja terytorium Białorusi nie będzie trudna - twierdzi ukraiński ekspert wojskowy Aleksander Kowalenko. Alaksandr Łukaszenka, zdaniem analityka, jest przerażony rosnącym w siłę oddziałem białoruskich ochotników na Ukrainie. </p><br clear="all" />

## Przyszłość Mariusza Błaszczaka. Ponad połowa ankietowanych za odwołaniem
 - [https://wydarzenia.interia.pl/kraj/news-przyszlosc-mariusza-blaszczaka-ponad-polowa-ankietowanych-za,nId,6807687](https://wydarzenia.interia.pl/kraj/news-przyszlosc-mariusza-blaszczaka-ponad-polowa-ankietowanych-za,nId,6807687)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 05:34:07+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-przyszlosc-mariusza-blaszczaka-ponad-polowa-ankietowanych-za,nId,6807687"><img align="left" alt="Przyszłość Mariusza Błaszczaka. Ponad połowa ankietowanych za odwołaniem" src="https://i.iplsc.com/przyszlosc-mariusza-blaszczaka-ponad-polowa-ankietowanych-za/000H7L8AEXFBDWHN-C321.jpg" /></a>Nie milkną echa po ujawnieniu szczątków rosyjskiej rakiety pod Bydgoszczą. Jak wynika z najnowszego sondażu, ponad połowa badanych oczekuje odwołania szefa resortu obrony narodowej Mariusza Błaszczaka. Jego rezygnacji domagają się także przedstawiciele opozycji, z kolei 61 proc. zwolenników partii rządzącej uważa, że minister &quot;zdecydowanie powinien zostać na stanowisku&quot;.</p><br clear="all" />

## Korea Płn. chce wystrzelić "satelitę". Japonia odpowiada: Zestrzelimy każdy pocisk
 - [https://wydarzenia.interia.pl/zagranica/news-korea-pln-chce-wystrzelic-satelite-japonia-odpowiada-zestrze,nId,6807675](https://wydarzenia.interia.pl/zagranica/news-korea-pln-chce-wystrzelic-satelite-japonia-odpowiada-zestrze,nId,6807675)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 05:28:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-korea-pln-chce-wystrzelic-satelite-japonia-odpowiada-zestrze,nId,6807675"><img align="left" alt="Korea Płn. chce wystrzelić &quot;satelitę&quot;. Japonia odpowiada: Zestrzelimy każdy pocisk" src="https://i.iplsc.com/korea-pln-chce-wystrzelic-satelite-japonia-odpowiada-zestrze/000H7L8XWIUQ7Q5H-C321.jpg" /></a>Korea Północna uprzedziła Japonię o zamiarze wystrzelenia satelity wojskowego między 31 maja i 11 czerwca. W odpowiedzi Japonia postawiła swoją obronę przeciwlotniczą w stan gotowości. - Każde wystrzelenie pocisku przez Koreę Północną, nawet jeżeli zostanie on nazwany satelitą, będzie poważnym naruszeniem rezolucji Rady Bezpieczeństwa ONZ - przekazał premier Japonii Fumio Kishida.</p><br clear="all" />

## Czy wieś skrywa mroczny sekret? Marta przypomina dziwne słowa księdza
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-czy-wies-skrywa-mroczny-sekret-marta-przypomina-dziwne-slowa,nId,6781276](https://wydarzenia.interia.pl/tylko-w-interii/news-czy-wies-skrywa-mroczny-sekret-marta-przypomina-dziwne-slowa,nId,6781276)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 05:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-czy-wies-skrywa-mroczny-sekret-marta-przypomina-dziwne-slowa,nId,6781276"><img align="left" alt="Czy wieś skrywa mroczny sekret? Marta przypomina dziwne słowa księdza" src="https://i.iplsc.com/czy-wies-skrywa-mroczny-sekret-marta-przypomina-dziwne-slowa/000H5QL7I1LXWR49-C321.jpg" /></a>- Kiedy usłyszałam, że Piotr został zatrzymany, pojechałam do Tłokini dowiedzieć się czegoś od mieszkańców. Oni wyglądali, jakby się kogoś bali. Najbardziej w pamięci zapadła mi rozmowa z księdzem proboszczem. Powiedział mi: wieś wie, ale skoro wieś milczy, to ja tym bardziej będę milczeć. I dodał: może ktoś na łożu śmierci wyzna, jaka jest prawda - mówi Marta Kaźmierczak w wywiadzie dla Interii. Kobieta od 12 lat walczy o uniewinnienie swojego brata ciotecznego, który został skazany za morderstwo dwóch kobiet, choć nie było żadnego dowodu...</p><br clear="all" />

## Mec. Wolny: Każdy z nas może stać się Piotrem. Wystarczy być w złym miejscu
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-mec-wolny-kazdy-z-nas-moze-stac-sie-piotrem-wystarczy-byc-w-,nId,6787824](https://wydarzenia.interia.pl/tylko-w-interii/news-mec-wolny-kazdy-z-nas-moze-stac-sie-piotrem-wystarczy-byc-w-,nId,6787824)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 05:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-mec-wolny-kazdy-z-nas-moze-stac-sie-piotrem-wystarczy-byc-w-,nId,6787824"><img align="left" alt="Mec. Wolny: Każdy z nas może stać się Piotrem. Wystarczy być w złym miejscu" src="https://i.iplsc.com/mec-wolny-kazdy-z-nas-moze-stac-sie-piotrem-wystarczy-byc-w/000H684ULNIJ6AXW-C321.jpg" /></a>- Dla mnie Piotr jest niewinny. Najgorsze jest to, że każdy z nas może się nim stać. Wystarczy być w złym miejscu, o złej porze i nie mieć odporności psychicznej. Przerażające jest to, że nasz system nie jest gotowy na takie przypadki - mówi  mecenas Marcin Wolny z Helsińskiej Fundacji Praw Człowieka. W ten sposób odnosi się do sprawy Piotra Mikołajczyka, którą opisaliśmy w Interii. Mężczyzna został skazany za morderstwo dwóch kobiet, choć nie było żadnego dowodu świadczącego o jego winie. Od 12 lat przebywa w zakładzie karnym. </p><br clear="all" />

## Prof. Gruza o sprawie Piotra: Dla mnie ten człowiek jest niewinny
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-prof-gruza-o-sprawie-piotra-dla-mnie-ten-czlowiek-jest-niewi,nId,6787894](https://wydarzenia.interia.pl/tylko-w-interii/news-prof-gruza-o-sprawie-piotra-dla-mnie-ten-czlowiek-jest-niewi,nId,6787894)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 05:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-prof-gruza-o-sprawie-piotra-dla-mnie-ten-czlowiek-jest-niewi,nId,6787894"><img align="left" alt="Prof. Gruza o sprawie Piotra: Dla mnie ten człowiek jest niewinny" src="https://i.iplsc.com/prof-gruza-o-sprawie-piotra-dla-mnie-ten-czlowiek-jest-niewi/000H68JHTTOYRYL4-C321.jpg" /></a>- Z akt wynika, że Piotr Mikołajczyk jest geniuszem zbrodni - ironizuje prof. Ewa Gruza, kryminalistyk z Uniwersytetu Warszawskiego w rozmowie z Interią. - Dla mnie ten człowiek jest niewinny. W aktach nie ma żadnego dowodu świadczącego o jego winie. Wystarczyło trochę chęci i zdrowego rozsądku sędziów, aby ten niewinny człowiek nie siedział w więzieniu - dodaje. W ten sposób komentuje sprawę Piotra Mikołajczyka. Mężczyzna z niepełnosprawnością umysłową został skazany za morderstwo dwóch kobiet, choć nie było żadnego dowodu świadczącego o...</p><br clear="all" />

## Skazany za niewinność
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-skazany-za-niewinnosc,nId,6779110](https://wydarzenia.interia.pl/tylko-w-interii/news-skazany-za-niewinnosc,nId,6779110)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 04:58:45+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-skazany-za-niewinnosc,nId,6779110"><img align="left" alt="Skazany za niewinność" src="https://i.iplsc.com/skazany-za-niewinnosc/000H68ZHFUYE0VD8-C321.jpg" /></a>Piotr Mikołajczyk, choć jest dorosły, ma umysł 10-letniego dziecka. Od 12 lat odsiaduje wyrok za brutalne zabójstwo dwóch kobiet, mimo że nie ma żadnych dowodów świadczących o jego winie. Zebrane materiały, badania wariografem, policyjne podsłuchy, służbowe notatki wskazują, że zbrodnię popełnił ktoś inny. </p><br clear="all" />

## Nocny atak na Kijów. Użyto dronów i rakiet
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nocny-atak-na-kijow-uzyto-dronow-i-rakiet,nId,6807671](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nocny-atak-na-kijow-uzyto-dronow-i-rakiet,nId,6807671)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 04:43:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nocny-atak-na-kijow-uzyto-dronow-i-rakiet,nId,6807671"><img align="left" alt="Nocny atak na Kijów. Użyto dronów i rakiet" src="https://i.iplsc.com/nocny-atak-na-kijow-uzyto-dronow-i-rakiet/000H7L6H61PIEJFM-C321.jpg" /></a>W nocy z niedzieli na poniedziałek Rosjanie przeprowadzili atak na Kijów. Jak powiadomił lokalne służy, na skutek działania wroga nikt nie został ranny, nie ma ofiar śmiertelnych. Ukraińskie siły obrony przeciwlotniczej zestrzeliły nad Kijowem i obwodem kijowskim ponad 40 celów. Był to 15. rosyjski atak na stolicę Ukrainy od początku maja. </p><br clear="all" />

## Wojna w Ukrainie. 460. dzień inwazji Rosji na Ukrainę. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja-,nzId,4240,akt,290610](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja-,nzId,4240,akt,290610)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 04:10:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja-,nzId,4240,akt,290610"><img align="left" alt="Wojna w Ukrainie. 460. dzień inwazji Rosji na Ukrainę. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja/000H7L66QFV5434B-C321.jpg" /></a>Zapraszamy do śledzenia naszej relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 460. dzień inwazji Rosji na Ukrainę. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja-,nzId,4240,akt,290657](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja-,nzId,4240,akt,290657)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 04:10:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja-,nzId,4240,akt,290657"><img align="left" alt="Wojna w Ukrainie. 460. dzień inwazji Rosji na Ukrainę. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja/000H7L66QFV5434B-C321.jpg" /></a>Zapraszamy do śledzenia naszej relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 460. dzień inwazji Rosji na Ukrainę. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja-,nzId,4240,akt,290811](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja-,nzId,4240,akt,290811)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-05-29 04:10:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja-,nzId,4240,akt,290811"><img align="left" alt="Wojna w Ukrainie. 460. dzień inwazji Rosji na Ukrainę. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-460-dzien-inwazji-rosji-na-ukraine-relacja/000H7L66QFV5434B-C321.jpg" /></a>Zapraszamy do śledzenia naszej relacji na żywo.</p><br clear="all" />

