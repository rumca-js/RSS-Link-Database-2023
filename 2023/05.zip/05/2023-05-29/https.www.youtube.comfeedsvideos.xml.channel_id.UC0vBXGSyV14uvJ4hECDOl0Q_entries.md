# Source:Techquickie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q, language:en-US

## Microsoft HQ Got Stormed #Shorts
 - [https://www.youtube.com/watch?v=D4QUykqZ9sY](https://www.youtube.com/watch?v=D4QUykqZ9sY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q
 - date published: 2023-05-29 19:53:00+00:00



