# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Tekken 8 - Official Bryan Fury Gameplay Reveal Trailer
 - [https://www.youtube.com/watch?v=IvI056RVHCk](https://www.youtube.com/watch?v=IvI056RVHCk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-05-29 13:30:07+00:00

Tekken 8 has unveiled its latest fighter to the game, the one and only Bryan Fury. Bryan Fury is a former cop turned psychotic cyborg who is a wildcard for violence and destruction. Take a look at the trailer for brand new Bryan Fury gameplay in Tekken 8 coming to PlayStation 5, Xbox Series S|X, and PC.

#Tekken8 #BryanFury

