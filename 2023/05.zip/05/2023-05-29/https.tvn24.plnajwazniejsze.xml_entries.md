# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Zajmiemy Teheran w ciągu kilku godzin". Groźby ze strony Talibów
 - [https://tvn24.pl/swiat/iran-afganistan-dowodca-talibow-zajmiemy-teheran-w-ciagu-kilku-godzin-7151074?source=rss](https://tvn24.pl/swiat/iran-afganistan-dowodca-talibow-zajmiemy-teheran-w-ciagu-kilku-godzin-7151074?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 20:01:46+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-25s9bp-teheran-5084932/alternates/LANDSCAPE_1280" />
     W sobotę na granicy Iranu i Afganistanu doszło do starć, w których życie straciło kilku pograniczników.

## "Nie ma wątpliwości, że jesteśmy w nowej erze komputerowej"
 - [https://tvn24.pl/biznes/tech/prezes-nvidii-zapowiada-ze-sztuczna-inteligencja-zmieni-swiat-7150816?source=rss](https://tvn24.pl/biznes/tech/prezes-nvidii-zapowiada-ze-sztuczna-inteligencja-zmieni-swiat-7150816?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 19:52:17+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l71mwy-jensen-huang-ceo-nvidia-7150758/alternates/LANDSCAPE_1280" />
    Prezes Nvidii o sztucznej inteligencji.

## Wierzy się, że jest jedyna na świecie. Całkowicie biała panda wielka uchwycona przez fotopułapkę
 - [https://tvn24.pl/tvnmeteo/swiat/biala-panda-panda-albinos-uchwycona-przez-fotopulapke-7151195?source=rss](https://tvn24.pl/tvnmeteo/swiat/biala-panda-panda-albinos-uchwycona-przez-fotopulapke-7151195?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 19:51:50+00:00

<img alt="Wierzy się, że jest jedyna na świecie. Całkowicie biała panda wielka uchwycona przez fotopułapkę" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6lu3ge-biala-panda-uchwycona-przez-fotopulapke-w-chinach-7151211/alternates/LANDSCAPE_1280" />
    Niespodzianka

## Znów gorąco wokół Sabalenki. Spięcie z ukraińską dziennikarką
 - [https://eurosport.tvn24.pl/tenis/roland-garros/2023/roland-garros-aryna-sabalenka-wdala-sie-w-dyskusje-z-ukrainska-dziennikarka_sto9629837/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros/2023/roland-garros-aryna-sabalenka-wdala-sie-w-dyskusje-z-ukrainska-dziennikarka_sto9629837/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 19:15:00+00:00

<img alt="Znów gorąco wokół Sabalenki. Spięcie z ukraińską dziennikarką" src="https://tvn24.pl/najnowsze/cdn-zdjecie-weah3e-aryna-sabalenka-jest-bialoruska-gwiazda-tenisa-7151216/alternates/LANDSCAPE_1280" />
    Jedna z faworytek Rolanda Garrosa tym razem musiała zmierzyć się z mocnymi pytaniami i oskarżeniami.

## Starcia w Kosowie. 25 żołnierzy NATO rannych
 - [https://tvn24.pl/swiat/kosowo-starcia-serbskich-demonstrantow-z-silami-misji-pokojowej-nato-25-zolnierzy-rannych-7151178?source=rss](https://tvn24.pl/swiat/kosowo-starcia-serbskich-demonstrantow-z-silami-misji-pokojowej-nato-25-zolnierzy-rannych-7151178?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 19:01:12+00:00

<img alt="Starcia w Kosowie. 25 żołnierzy NATO rannych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i73fev-zolnierze-sil-nato-z-misji-pokojowej-kfor-ranni-po-starciu-z-serbskimi-demonstrantami-7151189/alternates/LANDSCAPE_1280" />
    W miasteczku Zveczan.

## "Biznesowe Oscary" rozdane
 - [https://tvn24.pl/biznes/z-kraju/nagrody-polskiej-rady-biznesu-2023-lista-laureatow-7150702?source=rss](https://tvn24.pl/biznes/z-kraju/nagrody-polskiej-rady-biznesu-2023-lista-laureatow-7150702?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 18:58:26+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-rye4fl-nagrody-polskiej-rady-biznesu-7151174/alternates/LANDSCAPE_1280" />
    Poznaliśmy laureatów 12. edycji Nagrody Polskiej Rady Biznesu.

## "Prezydent podpisał karę śmierci politycznej za bycie przeciwnikiem tego rządu"
 - [https://tvn24.pl/polska/lex-tusk-z-podpisem-prezydenta-andrzeja-dudy-michal-kaminski-i-pawel-kowal-komentuja-7151175?source=rss](https://tvn24.pl/polska/lex-tusk-z-podpisem-prezydenta-andrzeja-dudy-michal-kaminski-i-pawel-kowal-komentuja-7151175?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 18:54:51+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e318tb-29-2000-kropka-cl-0042-7151152/alternates/LANDSCAPE_1280" />
    Wicemarszałek senatu Michał Kamiński i poseł Paweł Kowal w "Kropce nad i".

## Szukają 16-latka spod Ożarowa. Wyszedł z domu w środku nocy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/krzysztof-dyminski-zaginiecie-rysopis-7151061?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/krzysztof-dyminski-zaginiecie-rysopis-7151061?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 18:15:38+00:00

<img alt="Szukają 16-latka spod Ożarowa. Wyszedł z domu w środku nocy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wr1c95-zaginiony-16-latek-7151081/alternates/LANDSCAPE_1280" />
    Poszukiwania Krzysztofa Dymińskiego.

## Profesor Adam Strzembosz po decyzji prezydenta: jest człowiekiem skompromitowanym
 - [https://tvn24.pl/polska/lex-tuskprofesor-adam-strzembosz-komentuje-postawe-prezydenta-andrzeja-dudy-7151060?source=rss](https://tvn24.pl/polska/lex-tuskprofesor-adam-strzembosz-komentuje-postawe-prezydenta-andrzeja-dudy-7151060?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 18:11:38+00:00

<img alt="Profesor Adam Strzembosz po decyzji prezydenta: jest człowiekiem skompromitowanym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l2gpfm-profesor-strzembosz-7151077/alternates/LANDSCAPE_1280" />
    Były pierwszy prezes Sądu Najwyższego w "Faktach po Faktach".

## Będzie zakaz dla Twittera?
 - [https://tvn24.pl/biznes/najnowsze/twitter-moze-zostac-zakazany-w-europie-jesli-nie-bedzie-przestrzegal-przepisow-7150863?source=rss](https://tvn24.pl/biznes/najnowsze/twitter-moze-zostac-zakazany-w-europie-jesli-nie-bedzie-przestrzegal-przepisow-7150863?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 17:41:03+00:00

<img alt="Będzie zakaz dla Twittera?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-37qjhr-jean-noel-barrot-7150865/alternates/LANDSCAPE_1280" />
    Zapowiedź francuskiego ministra.

## Andrzej Duda o "lex Tusk": nie jest najważniejszy werdykt tej komisji
 - [https://tvn24.pl/polska/andrzej-duda-o-lex-tusk-nie-jest-najwazniejszy-werdykt-tej-komisji-7151016?source=rss](https://tvn24.pl/polska/andrzej-duda-o-lex-tusk-nie-jest-najwazniejszy-werdykt-tej-komisji-7151016?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 17:37:36+00:00

<img alt="Andrzej Duda o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8nbtmg-29-1740-polczyn-duda-0033-7151054/alternates/LANDSCAPE_1280" />
    Prezydent na spotkaniu w Połczynie-Zdroju.

## Atak na kobietę na Powiślu. "Złapał mnie i próbował wciągnąć w stronę parku"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-kobieta-zaatakowana-na-stacji-pkp-powisle-7150858?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-kobieta-zaatakowana-na-stacji-pkp-powisle-7150858?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 17:09:04+00:00

<img alt="Atak na kobietę na Powiślu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wckjow-do-zdarzenia-doszlo-w-weekend-7150981/alternates/LANDSCAPE_1280" />
    Mężczyzna zatrzymany "do sprawy". Jest znany policji

## RPO o "lex Tusk": w państwie prawa kary wymierza sąd
 - [https://tvn24.pl/polska/lex-tusk-rzecznik-praw-obywatelskich-ustawa-niezgodna-z-wieloma-przepisami-konstytucji-7150959?source=rss](https://tvn24.pl/polska/lex-tusk-rzecznik-praw-obywatelskich-ustawa-niezgodna-z-wieloma-przepisami-konstytucji-7150959?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 17:06:09+00:00

<img alt="RPO o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1yagaf-rpo-7150968/alternates/LANDSCAPE_1280" />
    Ta ustawa jest niezgodna z wieloma przepisami konstytucji - ocenił Marcin Wiącek.

## Wielka niespodzianka. Mistrzyni olimpijska już poza turniejem
 - [https://eurosport.tvn24.pl/tenis/roland-garros/2023/elina-awanesian-belinda-bencic-wynik-i-relacja-z-meczu_sto9629554/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros/2023/elina-awanesian-belinda-bencic-wynik-i-relacja-z-meczu_sto9629554/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 17:02:47+00:00

<img alt="Wielka niespodzianka. Mistrzyni olimpijska już poza turniejem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gqfckx-belinda-bencic-to-mistrzyni-olimpijska-z-tokio-7151019/alternates/LANDSCAPE_1280" />
    W pierwszej rundzie uległa zdecydowanie niżej notowanej Rosjance.

## Bez sponsora i mediów społecznościowych. Z kim zagra Iga Świątek?
 - [https://eurosport.tvn24.pl/tenis/roland-garros/2023/iga-swiatek-cristina-bucsa.-kim-jest-pierwsza-rywalka-polki-w-roland-garros-sylwetka-sukcesy_sto9628611/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros/2023/iga-swiatek-cristina-bucsa.-kim-jest-pierwsza-rywalka-polki-w-roland-garros-sylwetka-sukcesy_sto9628611/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 16:34:00+00:00

<img alt="Bez sponsora i mediów społecznościowych. Z kim zagra Iga Świątek?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-prl7j0-cristina-bucsa-bedzie-rywalka-igi-swiatek-w-paryzu-7150974/alternates/LANDSCAPE_1280" />
    Ma 25 lat, od siedmiu reprezentuje Hiszpanię, ale nawet rodacy wiedzą o niej mało.

## "Podpis prezydenta Andrzeja Dudy zakończył demokrację w Polsce"
 - [https://tvn24.pl/polska/lex-tusk-ruch-samorzadowy-tak-dla-polski-ustawa-bedzie-wymierzona-w-kazdego-kto-mysli-inaczej-niz-pis-7150740?source=rss](https://tvn24.pl/polska/lex-tusk-ruch-samorzadowy-tak-dla-polski-ustawa-bedzie-wymierzona-w-kazdego-kto-mysli-inaczej-niz-pis-7150740?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 16:28:03+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hg437r-andrzej-duda-7146475/alternates/LANDSCAPE_1280" />
    Ruch Samorządowy TAK! Dla Polski o "lex Tusk".

## Bochenek: komisja z "lex Tusk" taka jak reprywatyzacyjna. Nieprawda
 - [https://konkret24.tvn24.pl/polityka/lex-tusk-bochenek-komisja-z-lex-tusk-taka-jak-reprywatyzacyjna-nieprawda-7150049?source=rss](https://konkret24.tvn24.pl/polityka/lex-tusk-bochenek-komisja-z-lex-tusk-taka-jak-reprywatyzacyjna-nieprawda-7150049?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 16:19:19+00:00

<img alt="Bochenek: komisja z " src="https://tvn24.pl/najnowsze/cdn-zdjecie-58bzw3-wpis-rafala-bochenka-7150760/alternates/LANDSCAPE_1280" />
    Politycy PiS przekonują, że utworzona na podstawie "lex Tusk" komisja będzie działa tak samo jak komisja dotycząca reprywatyzacji.

## "Pięć lat równaliście mnie z ziemią". Ostre słowa Billie Eilish do krytyków
 - [https://tvn24.pl/kultura-i-styl/billie-eilish-w-ostrych-slowach-odpowiada-krytykom-piec-lat-rownaliscie-mnie-z-ziemia-7150814?source=rss](https://tvn24.pl/kultura-i-styl/billie-eilish-w-ostrych-slowach-odpowiada-krytykom-piec-lat-rownaliscie-mnie-z-ziemia-7150814?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 16:17:13+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s7tu3q-billie-eilish-z-met-gali-2023-7150946/alternates/LANDSCAPE_1280" />
    "Czy wiedzieliście, że kobiety mogą mieć wiele twarzy? Szokujące, prawda?".

## Piknik lotniczy bez pokazu akrobacji. Zakaz wydany dzień przed imprezą
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-na-wawerskim-pikniku-lotniczym-nie-odbyly-sie-pokazy-wstrzymano-na-nie-zgode-7148633?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-na-wawerskim-pikniku-lotniczym-nie-odbyly-sie-pokazy-wstrzymano-na-nie-zgode-7148633?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 16:10:59+00:00

<img alt="Piknik lotniczy bez pokazu akrobacji. Zakaz wydany dzień przed imprezą " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-gccqcl-wawerski-piknik-lotniczy-7148227/alternates/LANDSCAPE_1280" />
    Zawiedzeni uczestnicy, skonsternowani organizatorzy.

## Czerwone światło dla białoruskich i rosyjskich ciężarówek. Opublikowano rozporządzenie
 - [https://tvn24.pl/biznes/z-kraju/bialorus-zawieszenie-ruchu-towarowego-na-granicy-dla-bialoruskich-i-rosyjskich-ciezarowek-i-naczep-7150917?source=rss](https://tvn24.pl/biznes/z-kraju/bialorus-zawieszenie-ruchu-towarowego-na-granicy-dla-bialoruskich-i-rosyjskich-ciezarowek-i-naczep-7150917?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 16:03:30+00:00

<img alt="Czerwone światło dla białoruskich i rosyjskich ciężarówek. Opublikowano rozporządzenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xatp3c-shutterstock_2094957040-7150933/alternates/LANDSCAPE_1280" />
    Od 1 czerwca.

## Kara śmierci za "ciężki homoseksualizm". Ustawa anty-LGBTQ podpisana przez prezydenta
 - [https://tvn24.pl/swiat/uganda-kara-smierci-za-ciezki-homoseksualizm-ustawa-anty-lgbtq-podpisana-przez-prezydenta-7150572?source=rss](https://tvn24.pl/swiat/uganda-kara-smierci-za-ciezki-homoseksualizm-ustawa-anty-lgbtq-podpisana-przez-prezydenta-7150572?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 15:45:26+00:00

<img alt="Kara śmierci za " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n103v3-uganda-lgbt-7150693/alternates/LANDSCAPE_1280" />
    W Ugandzie.

## Chelsea ma nowego trenera
 - [https://eurosport.tvn24.pl/pilka-nozna/mauricio-pochettino-od-poczatku-sezonu-2023-24-bedzie-trenerem-chelsea_sto9629408/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/mauricio-pochettino-od-poczatku-sezonu-2023-24-bedzie-trenerem-chelsea_sto9629408/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 15:24:56+00:00

<img alt="Chelsea ma nowego trenera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-209kai-mauricio-pochettino-7150911/alternates/LANDSCAPE_1280" />
    Pracował w wielkich klubach.

## "Tajna narada opozycji z sędziami". Fogiel powtarza fałszywą narrację
 - [https://konkret24.tvn24.pl/polityka/trybunal-konstytucyjny-tajna-narada-opozycji-z-sedziami-fogiel-powtarza-falszywa-narracje-7145672?source=rss](https://konkret24.tvn24.pl/polityka/trybunal-konstytucyjny-tajna-narada-opozycji-z-sedziami-fogiel-powtarza-falszywa-narracje-7145672?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 15:09:21+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vghp8e-posel-fogiel-o-tajnym-spotkaniu-sedziow-z-opozycja-7145586/alternates/LANDSCAPE_1280" />
    Spotkanie nie było tajne, nie odbyło się w siedzibie PO, a prof. Rzepliński nie był już wtedy prezesem trybunału.

## Pewny awans Djokovicia
 - [https://eurosport.tvn24.pl/tenis/roland-garros/2023/novak-djokovic-aleksandar-kovacevic-wynik-i-relacja-z-meczu_sto9629201/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros/2023/novak-djokovic-aleksandar-kovacevic-wynik-i-relacja-z-meczu_sto9629201/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 15:07:42+00:00

<img alt="Pewny awans Djokovicia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lvki3l-novak-djokovic-to-byly-lider-rankingu-atp-7150869/alternates/LANDSCAPE_1280" />
    Znakomita passa w Paryżu podtrzymana.

## Ambasador USA w TVN24 o "lex Tusk": jesteśmy świadomi tego, co niepokoi wiele osób w tej ustawie
 - [https://tvn24.pl/polska/lex-tusk-ambasador-mark-brzezinski-usa-podzielaja-obawy-zwiazane-z-ustawami-ktore-moga-pozwalac-na-zmniejszanie-zdolnosci-glosujacych-do-glosowania-na-tych-na-ktorych-chca-7150829?source=rss](https://tvn24.pl/polska/lex-tusk-ambasador-mark-brzezinski-usa-podzielaja-obawy-zwiazane-z-ustawami-ktore-moga-pozwalac-na-zmniejszanie-zdolnosci-glosujacych-do-glosowania-na-tych-na-ktorych-chca-7150829?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 15:06:23+00:00

<img alt="Ambasador USA w TVN24 o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ssbes-ambasador-usa-mark-brzezinski-7150838/alternates/LANDSCAPE_1280" />
    Ambasador USA w Polsce Mark Brzezinski w TVN24 i TVN24 BiS.

## Gigant zamknie fabrykę w Polsce. Pracę ma stracić ponad 800 osób
 - [https://tvn24.pl/biznes/z-kraju/scania-zamyka-fabryke-w-slupsku-prace-ma-stracic-ponad-800-osob-7150835?source=rss](https://tvn24.pl/biznes/z-kraju/scania-zamyka-fabryke-w-slupsku-prace-ma-stracic-ponad-800-osob-7150835?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 15:06:22+00:00

<img alt="Gigant zamknie fabrykę w Polsce. Pracę ma stracić ponad 800 osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wrruh6-shutterstock_1158770821-7150862/alternates/LANDSCAPE_1280" />
    Komunikat.

## Najbogatsi mogliby sfinansować tysiące mieszkań
 - [https://tvn24.pl/biznes/ze-swiata/wielka-brytania-najbogatsi-mogliby-zrzucic-sie-na-tysiace-mieszkan-7150384?source=rss](https://tvn24.pl/biznes/ze-swiata/wielka-brytania-najbogatsi-mogliby-zrzucic-sie-na-tysiace-mieszkan-7150384?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 15:01:58+00:00

<img alt="Najbogatsi mogliby sfinansować tysiące mieszkań" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0dlyaz-londyn-4765285/alternates/LANDSCAPE_1280" />
    Pisze brytyjski "The Guardian".

## Siedem osób w szpitalu po zderzeniu dwóch aut
 - [https://tvn24.pl/krakow/siedem-osob-w-szpitalu-po-zderzeniu-dwoch-aut-7150827?source=rss](https://tvn24.pl/krakow/siedem-osob-w-szpitalu-po-zderzeniu-dwoch-aut-7150827?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 14:57:53+00:00

<img alt="Siedem osób w szpitalu po zderzeniu dwóch aut" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ymlhmb-protest-pielegniarek-zdjecie-ilustracyjne-6098505/alternates/LANDSCAPE_1280" />
    Na miejscu lądował śmigłowiec Lotniczego Pogotowia Ratunkowego.

## Pożar samochodu elektrycznego na stacji paliw
 - [https://tvn24.pl/pomorze/gdansk-pozar-samochodu-elektrycznego-na-stacji-paliw-dzialania-sluzb-trwaly-kilka-godzin-7150819?source=rss](https://tvn24.pl/pomorze/gdansk-pozar-samochodu-elektrycznego-na-stacji-paliw-dzialania-sluzb-trwaly-kilka-godzin-7150819?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 14:52:35+00:00

<img alt="Pożar samochodu elektrycznego na stacji paliw" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eajyl6-pozar-samochodu-elektrycznego-7150808/alternates/LANDSCAPE_1280" />
    Działania służb trwały kilka godzin.

## Lekarka po raz kolejny przyłapana na pracy, mimo że ma zawieszone prawo do wykonywania zawodu
 - [https://tvn24.pl/poznan/poznan-lekarka-po-raz-kolejny-przylapana-na-pracy-mimo-ze-ma-zawieszone-prawo-do-wykonywania-zawodu-7150778?source=rss](https://tvn24.pl/poznan/poznan-lekarka-po-raz-kolejny-przylapana-na-pracy-mimo-ze-ma-zawieszone-prawo-do-wykonywania-zawodu-7150778?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 14:43:21+00:00

<img alt="Lekarka po raz kolejny przyłapana na pracy, mimo że ma zawieszone prawo do wykonywania zawodu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xj96s2-lekarka-zostala-przylapana-na-pracy-bez-uzprawnien-zdjecie-ilustracyjne-5508586/alternates/LANDSCAPE_1280" />
    Pierwszą informację dostaliśmy na Kontakt 24.

## 36-latek zadziwił w Paryżu
 - [https://eurosport.tvn24.pl/tenis/roland-garros/2023/felix-auger-aliassime-fabio-fognini-wynik-meczu-i-relacja_sto9629324/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros/2023/felix-auger-aliassime-fabio-fognini-wynik-meczu-i-relacja_sto9629324/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 14:40:52+00:00

<img alt="36-latek zadziwił w Paryżu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ysqsvr-fabio-fognini-w-drugiej-rundzie-roland-garros-7150833/alternates/LANDSCAPE_1280" />
    Faworyt nie ugrał nawet seta.

## Gigantyczna fala wycofanych aut w USA
 - [https://tvn24.pl/biznes/moto/w-usa-wycofanie-prawie-300-tysiecy-aut-roznych-marek-7150674?source=rss](https://tvn24.pl/biznes/moto/w-usa-wycofanie-prawie-300-tysiecy-aut-roznych-marek-7150674?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 14:39:27+00:00

<img alt="Gigantyczna fala wycofanych aut w USA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sn86nd-shutterstock_2006585378-7150773/alternates/LANDSCAPE_1280" />
    Ponad 275 tysięcy samochodów w ciągu tygodnia.

## Duże banki zablokowały karty części klientów. "Wyciek danych"
 - [https://tvn24.pl/biznes/pieniadze/ing-bank-slaski-santander-bank-polska-i-bank-millennium-zablokowaly-karty-czesci-klientow-7148837?source=rss](https://tvn24.pl/biznes/pieniadze/ing-bank-slaski-santander-bank-polska-i-bank-millennium-zablokowaly-karty-czesci-klientow-7148837?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 14:37:00+00:00

<img alt="Duże banki zablokowały karty części klientów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uwxy4x-karta-platnosc-transakcja-terminal-sklep-5137797/alternates/LANDSCAPE_1280" />
    SMS-y do klientów.

## Atak siekierą przy zoo
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-atak-siekiera-przy-zoo-sprawca-mial-zostac-wczesniej-zaatakowany-widelcem-7150767?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-atak-siekiera-przy-zoo-sprawca-mial-zostac-wczesniej-zaatakowany-widelcem-7150767?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 14:18:06+00:00

<img alt="Atak siekierą przy zoo" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8abg8i-klotnia-obok-zoo-7150775/alternates/LANDSCAPE_1280" />
    "Przeciwnik próbował ugodzić go widelcem".

## Koniec kariery w wieku 21 lat
 - [https://eurosport.tvn24.pl/pilka-nozna/zofia-buszewska-oglosila-zakonczenie-pilkarskiej-kariery.-dlaczego_sto9628971/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/zofia-buszewska-oglosila-zakonczenie-pilkarskiej-kariery.-dlaczego_sto9628971/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 14:00:01+00:00

<img alt="Koniec kariery w wieku 21 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yoj5fd-zofia-buszewska-to-byla-reprezentantka-polski-7150768/alternates/LANDSCAPE_1280" />
    Zaskakująca decyzja reprezentantki Polski.

## Rosyjski cień w wielkiej transakcji Obajtka. Plandeki nie zasłoniły wszystkiego
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2411,S00E2411,1078338?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2411,S00E2411,1078338?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 13:51:22+00:00

<img alt="Rosyjski cień w wielkiej transakcji Obajtka. Plandeki nie zasłoniły wszystkiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x7gtwu-orlen-na-wegrzech-7150743/alternates/LANDSCAPE_1280" />
    Prezes Daniel Obajtek zapewniał, że w fuzji Orlenu z Lotosem nie ma śladu Rosjan. Oto, co odkryli dziennikarze, sprawdzając słowa szefa koncernu.

## Okulary przeciwsłoneczne spowodowały pożar samochodu
 - [https://tvn24.pl/swiat/wielka-brytania-okulary-przeciwsloneczne-spowodowaly-pozar-samochodu-7150457?source=rss](https://tvn24.pl/swiat/wielka-brytania-okulary-przeciwsloneczne-spowodowaly-pozar-samochodu-7150457?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 13:11:05+00:00

<img alt="Okulary przeciwsłoneczne spowodowały pożar samochodu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lvqwf9-nottinghamshire-fire-and-rescue-service-7150560/alternates/LANDSCAPE_1280" />
    Media zauważają, że ten dzień był bardzo słoneczny.

## Ustawa bez podpisu i z podpisem. Dlaczego przy przesyłaniu do TK ma to znaczenie
 - [https://tvn24.pl/polska/lex-tusk-i-decyzja-prezydenta-znaczenie-podpisania-ustawy-i-przeslania-jej-do-trybunalu-konstytucyjnego-7150557?source=rss](https://tvn24.pl/polska/lex-tusk-i-decyzja-prezydenta-znaczenie-podpisania-ustawy-i-przeslania-jej-do-trybunalu-konstytucyjnego-7150557?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 13:09:45+00:00

<img alt="Ustawa bez podpisu i z podpisem. Dlaczego przy przesyłaniu do TK ma to znaczenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p9z0wq-trybunal-konstytucyjny-shutterstock_2219218359-7074767/alternates/LANDSCAPE_1280" />
    Co oznacza podpis prezydenta pod lex Tusk i jednoczesne skierowanie tej ustawy do Trybunału Konstytucyjnego?

## "Czekali na niego przed domem". Konflikt sąsiedzki skończył się śmiercią 58-latka
 - [https://tvn24.pl/wroclaw/jelenia-gora-grupa-mezczyzn-pobila-58-latka-zaatakowany-nie-zyje-prokuratura-to-byl-konflikt-sasiedzki-pieciu-zatrzymanych-7150575?source=rss](https://tvn24.pl/wroclaw/jelenia-gora-grupa-mezczyzn-pobila-58-latka-zaatakowany-nie-zyje-prokuratura-to-byl-konflikt-sasiedzki-pieciu-zatrzymanych-7150575?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 13:07:41+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ia3rap-konflikt-sasiedzki-skonczyl-sie-smiercia-58-latka-7150684/alternates/LANDSCAPE_1280" />
    Pięciu mężczyzn zatrzymano za udział w pobiciu, którego następstwem była śmierć człowieka.

## "Poprosiliśmy autora, by opowiedział tę historię od początku". Powstaje nowy film o Kargulu i Pawlaku
 - [https://tvn24.pl/krakow/tokarnia-powstaje-prequel-samych-swoich-7150601?source=rss](https://tvn24.pl/krakow/tokarnia-powstaje-prequel-samych-swoich-7150601?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 13:03:58+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-97v8e-sami-swoi_08-7150485/alternates/LANDSCAPE_1280" />
    W skansenie Muzeum Wsi Kieleckiej w Tokarni (woj. świętokrzyskie) powstaje prequel kultowej serii filmowej "Sami swoi".

## Tyle wynosi średnie oprocentowanie lokat. "Majowy ruch jest zaskakujący"
 - [https://tvn24.pl/biznes/pieniadze/oprocentowanie-lokat-srednio-w-maju-wynioslo-705-procent-7150581?source=rss](https://tvn24.pl/biznes/pieniadze/oprocentowanie-lokat-srednio-w-maju-wynioslo-705-procent-7150581?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 13:03:05+00:00

<img alt="Tyle wynosi średnie oprocentowanie lokat. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-o1014f-adobestock35215616-5599361/alternates/LANDSCAPE_1280" />
    Analiza HREIT.

## Kończyło mu się paliwo, zjechał na stację. Wygrał milion
 - [https://tvn24.pl/ciekawostki/usa-wygral-milion-dolarow-w-zdrapce-na-stacji-benzynowej-7150567?source=rss](https://tvn24.pl/ciekawostki/usa-wygral-milion-dolarow-w-zdrapce-na-stacji-benzynowej-7150567?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 12:57:22+00:00

<img alt="Kończyło mu się paliwo, zjechał na stację. Wygrał milion" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zhmguo-lot-7150613/alternates/LANDSCAPE_1280" />
    "Pokazałem zdrapkę dziewczynom stojącym przy kasie, one na jej widok prawie oszalały".

## Naukowcy odkryli w mózgu możliwą przyczynę nagłej śmierci łóżeczkowej
 - [https://tvn24.pl/swiat/nauka-nagla-smierc-lozeczkowa-mozliwa-przyczyna-odkryta-w-mozgu-7144198?source=rss](https://tvn24.pl/swiat/nauka-nagla-smierc-lozeczkowa-mozliwa-przyczyna-odkryta-w-mozgu-7144198?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 12:39:10+00:00

<img alt="Naukowcy odkryli w mózgu możliwą przyczynę nagłej śmierci łóżeczkowej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4i3qpa-dziewieciomiesieczne-dziecko-trafilo-do-szpitala-z-licznymi-siniakami-7127843/alternates/LANDSCAPE_1280" />
    Zjawisko to pozostaje nie w pełni zrozumiane przez naukowców.

## "'Lex Tusk' łamie tak wiele przepisów konstytucji, że trudno je na jednym tchu wymienić"
 - [https://tvn24.pl/polska/lex-tusk-konstytucjonalistka-o-przepisach-ktore-lamie-ustawa-7150506?source=rss](https://tvn24.pl/polska/lex-tusk-konstytucjonalistka-o-przepisach-ktore-lamie-ustawa-7150506?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 12:37:10+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w8tdev-andrzej-duda-7150588/alternates/LANDSCAPE_1280" />
    Ocenia konstytucjonalistka doktor Monika Haczkowska.

## Dagmara Domińczyk w niezwykły sposób pożegnała się z ekipą "Sukcesji"
 - [https://tvn24.pl/kultura-i-styl/sukcesja-dagmara-dominczyk-zegna-sie-z-ekipa-serialu-opublikowala-zdjecie-7150177?source=rss](https://tvn24.pl/kultura-i-styl/sukcesja-dagmara-dominczyk-zegna-sie-z-ekipa-serialu-opublikowala-zdjecie-7150177?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 12:30:41+00:00

<img alt="Dagmara Domińczyk w niezwykły sposób pożegnała się z ekipą " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hpmzkl-wpis-dagmary-dominczyk-7150179/alternates/LANDSCAPE_1280" />
    Między innymi z kuzynem Gregiem, który stał się postacią kultową.

## Ciężarna 33-latka zmarła w szpitalu. Wstępne wyniki sekcji zwłok
 - [https://tvn24.pl/krakow/nowy-targ-w-szpitalu-zmarla-33-letnia-ciezarna-wyniki-sekcji-zwlok-7150509?source=rss](https://tvn24.pl/krakow/nowy-targ-w-szpitalu-zmarla-33-letnia-ciezarna-wyniki-sekcji-zwlok-7150509?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 12:26:15+00:00

<img alt="Ciężarna 33-latka zmarła w szpitalu. Wstępne wyniki sekcji zwłok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-agthgk-podhalanski-szpital-specjalistyczny-7145327/alternates/LANDSCAPE_1280" />
    Sprawę bada prokuratura.

## 365 obywateli Białorusi na liście sankcji. Decyzja szefa MSWiA
 - [https://tvn24.pl/polska/bialorus-sankcje-szef-mswia-mariusz-kaminski-zdecydowalem-o-wpisaniu-na-liste-sankcyjna-365-obywateli-bialorusi-7150563?source=rss](https://tvn24.pl/polska/bialorus-sankcje-szef-mswia-mariusz-kaminski-zdecydowalem-o-wpisaniu-na-liste-sankcyjna-365-obywateli-bialorusi-7150563?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 12:18:24+00:00

<img alt="365 obywateli Białorusi na liście sankcji. Decyzja szefa MSWiA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ccrtf9-plansza-pilne-16-4712016/alternates/LANDSCAPE_1280" />
    Komunikat MSWiA.

## Skurkiewicz: wielu dziennikarzy powinno stanąć przed taką komisją
 - [https://tvn24.pl/polska/lex-tusk-wojciech-skurkiewicz-o-komisji-w-sprawie-wplywow-rosyjskich-wielu-dziennikarzy-powinno-stanac-przed-taka-komisja-7150437?source=rss](https://tvn24.pl/polska/lex-tusk-wojciech-skurkiewicz-o-komisji-w-sprawie-wplywow-rosyjskich-wielu-dziennikarzy-powinno-stanac-przed-taka-komisja-7150437?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 12:16:41+00:00

<img alt="Skurkiewicz: wielu dziennikarzy powinno stanąć przed taką komisją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-huj6ej-wojciech-skurkiewicz-7150414/alternates/LANDSCAPE_1280" />
    Podpisanie tak zwanego "lex Tusk" zapowiedział w poniedziałek prezydent.

## Koniec oczekiwania. Wiadomo, kiedy Iga Świątek zagra pierwszy mecz w Paryżu
 - [https://eurosport.tvn24.pl/tenis/roland-garros/2023/iga-swiatek-cristina-bucsa.-kiedy-i-o-ktorej-pierwszy-mecz-polki-w-rolandzie-garrosie_sto9628742/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros/2023/iga-swiatek-cristina-bucsa.-kiedy-i-o-ktorej-pierwszy-mecz-polki-w-rolandzie-garrosie_sto9628742/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 12:06:17+00:00

<img alt="Koniec oczekiwania. Wiadomo, kiedy Iga Świątek zagra pierwszy mecz w Paryżu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-juoviu-iga-swiatek-trenuje-podczas-roland-garros-7150548/alternates/LANDSCAPE_1280" />
    Iga Świątek we wtorek rozpocznie rywalizację, której celem jest obrona tytułu i trzecie trofeum na kortach im. Rolanda Garrosa w Paryżu.

## Agnieszka została napadnięta i zgwałcona, zmarła w szpitalu. Prawomocny wyrok po 22 latach
 - [https://tvn24.pl/bialystok/bialystok-agnieszka-zostala-napadnieta-i-zgwalcona-zmarla-w-szpitalu-prawomocny-wyrok-za-zabojstwo-pielegniarki-22-lata-po-zbrodni-7148757?source=rss](https://tvn24.pl/bialystok/bialystok-agnieszka-zostala-napadnieta-i-zgwalcona-zmarla-w-szpitalu-prawomocny-wyrok-za-zabojstwo-pielegniarki-22-lata-po-zbrodni-7148757?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 12:01:06+00:00

<img alt="Agnieszka została napadnięta i zgwałcona, zmarła w szpitalu. Prawomocny wyrok po 22 latach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kbu5sm-44-latek-zostal-w-2022-roku-przekazany-polskim-organom-scigania-zdjecie-z-marca-2022-roku-6638777/alternates/LANDSCAPE_1280" />
    Oskarżony nie przyznał się do winy.

## Do myjni samochodowej zabrali psa. "Dwukrotnie szorowali go szczotką z chemią"
 - [https://tvn24.pl/krakow/oswiecim-umyli-psa-w-myjni-samochodowej-szuka-ich-policja-nagranie-7150266?source=rss](https://tvn24.pl/krakow/oswiecim-umyli-psa-w-myjni-samochodowej-szuka-ich-policja-nagranie-7150266?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:59:59+00:00

<img alt="Do myjni samochodowej zabrali psa. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4h6e33-do-myjni-samochodowej-zabrali-psa-7150520/alternates/LANDSCAPE_1280" />
    Jest nagranie z monitoringu. Sprawców szuka policja.

## Kolizja z udziałem autobusu. Z drzwi niewiele zostało
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-z-udzialem-autobusu-miejskiego-na-tarchominie-7150451?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-z-udzialem-autobusu-miejskiego-na-tarchominie-7150451?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:55:15+00:00

<img alt="Kolizja z udziałem autobusu. Z drzwi niewiele zostało" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-193jwu-zderzenie-z-udzialem-autobusu-miejskiego-7150405/alternates/LANDSCAPE_1280" />
    Zderzył się z autem.

## Decyzje komisji "lex Tusk" ostateczne. Eksperci: kontrola sądu iluzoryczna
 - [https://konkret24.tvn24.pl/polityka/lex-tusk-decyzje-komisji-ostateczne-eksperci-kontrola-sadu-iluzoryczna-7150241?source=rss](https://konkret24.tvn24.pl/polityka/lex-tusk-decyzje-komisji-ostateczne-eksperci-kontrola-sadu-iluzoryczna-7150241?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:50:59+00:00

<img alt="Decyzje komisji " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yacu06-decyzje-komisji-lex-tusk-ostateczne-eksperci-kontrola-sadu-iluzoryczna-7150298/alternates/LANDSCAPE_1280" />
    Od decyzji komisji do zbadania wpływów rosyjskich nie będzie się można odwołać do organu wyższej instancji - bo takiego organu ustawa "lex Tusk" nie przewiduje.

## Zobaczył policję, wyrzucił plecak i zaczął uciekać. Jest nagranie pościgu
 - [https://tvn24.pl/poznan/zielona-gora-mezczyzna-zobaczyl-policje-wyrzucil-plecak-i-zaczal-uciekac-jest-nagranie-poscigu-7150161?source=rss](https://tvn24.pl/poznan/zielona-gora-mezczyzna-zobaczyl-policje-wyrzucil-plecak-i-zaczal-uciekac-jest-nagranie-poscigu-7150161?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:47:04+00:00

<img alt="Zobaczył policję, wyrzucił plecak i zaczął uciekać. Jest nagranie pościgu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a83k9f-zielona-gora-poscig-za-podejrzanym-o-handel-narkotykami-7150183/alternates/LANDSCAPE_1280" />
    Po zatrzymaniu od razu się przyznał.

## Obietnice minus. Mieli "uwolnić Polaków z niewoli" kredytów frankowych. Nie uwolnili
 - [https://konkret24.tvn24.pl/obietnice-minus/obietnice-minus-mieli-uwolnic-polakow-z-niewoli-kredytow-frankowych-nie-uwolnili-7145560?source=rss](https://konkret24.tvn24.pl/obietnice-minus/obietnice-minus-mieli-uwolnic-polakow-z-niewoli-kredytow-frankowych-nie-uwolnili-7145560?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:43:04+00:00

<img alt="Obietnice minus. Mieli " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k46xk6-mieli-uwolnic-polakow-z-niewoli-kredytow-frankowych-nie-uwolnili-7145600/alternates/LANDSCAPE_1280" />
    Cykl Konkretu24.

## Turniejowe "jedynki" nie mają w Paryżu łatwo. Świątek musi mieć się na baczności
 - [https://eurosport.tvn24.pl/tenis/roland-garros/2023/iga-swiatek-walczy-o-trzeci-tytul-w-paryzu.-najwyzej-rozstawionej-moze-byc-trudniej.-raz-juz-wygrala_sto9628587/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros/2023/iga-swiatek-walczy-o-trzeci-tytul-w-paryzu.-najwyzej-rozstawionej-moze-byc-trudniej.-raz-juz-wygrala_sto9628587/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:36:32+00:00

<img alt="Turniejowe " src="https://tvn24.pl/najnowsze/cdn-zdjecie-i7j9r4-iga-swiatek-broni-w-paryzu-wywalczonego-przed-rokiem-trofeum-7150464/alternates/LANDSCAPE_1280" />
    Od 1968 roku tylko 20 razy po tytuł w wielkoszlemowym Rolandzie Garrosie sięgnęły najwyżej rozstawione zawodniczki.

## Europoseł PiS złożył skargę na dziennikarzy TVN24. Odpowiedź Rady Etyki Mediów
 - [https://tvn24.pl/polska/europosel-grzegorz-tobiszowski-wplaty-na-kampanie-skarga-na-reportaz-tvn24-rada-etyki-mediow-odpowiada-7148880?source=rss](https://tvn24.pl/polska/europosel-grzegorz-tobiszowski-wplaty-na-kampanie-skarga-na-reportaz-tvn24-rada-etyki-mediow-odpowiada-7148880?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:30:41+00:00

<img alt="Europoseł PiS złożył skargę na dziennikarzy TVN24. Odpowiedź Rady Etyki Mediów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nuf54r-dziennikarz-tvn24pl-grzegorz-lakomski-i-europosel-pis-grzegorz-tobiszowski-6205899/alternates/LANDSCAPE_1280" />
    "Dariusz Kubik i Grzegorz Łakomski w reportażu 'Kopalnia interesów' zyskali dla społeczeństwa wiedzę o nieznanych, złych mechanizmach wyborczych" - napisała REM.

## 6-latek przed śmiercią ważył 8 kilogramów
 - [https://tvn24.pl/swiat/usa-matka-przyznala-sie-do-zaglodzenia-syna-mial-6-lat-wazyl-8-kilogramow-7150178?source=rss](https://tvn24.pl/swiat/usa-matka-przyznala-sie-do-zaglodzenia-syna-mial-6-lat-wazyl-8-kilogramow-7150178?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:24:53+00:00

<img alt="6-latek przed śmiercią ważył 8 kilogramów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w7k6z1-policja-usa-6743069/alternates/LANDSCAPE_1280" />
    Matka miała zamykać chłopca w szafie, by "nauczył się dyscypliny".

## Dzięki próbkom DNA odpowie za włamanie sprzed 20 lat. "Był zdziwiony, ale pamiętał"
 - [https://tvn24.pl/tvnwarszawa/okolice/pruszkow-okradl-mieszkanie-znalezli-go-20-lat-pozniej-dzieki-probkom-dna-7148923?source=rss](https://tvn24.pl/tvnwarszawa/okolice/pruszkow-okradl-mieszkanie-znalezli-go-20-lat-pozniej-dzieki-probkom-dna-7148923?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:24:35+00:00

<img alt="Dzięki próbkom DNA odpowie za włamanie sprzed 20 lat. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8r2u31-mezczyzna-odpowie-za-kradziez-z-wlamaniem-sprzed-20-lat-zdj-ilustracyjne-7148961/alternates/LANDSCAPE_1280" />
    Przyznał się.

## Podczas policyjnej interwencji podawała się za prokuratorkę. Trzecia osoba z zarzutami
 - [https://tvn24.pl/pomorze/wierzchucin-krokowa-podczas-ataku-na-policjantow-miala-podawac-sie-za-prokuratorke-trzecia-osoba-z-zarzutami-7148729?source=rss](https://tvn24.pl/pomorze/wierzchucin-krokowa-podczas-ataku-na-policjantow-miala-podawac-sie-za-prokuratorke-trzecia-osoba-z-zarzutami-7148729?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:12:14+00:00

<img alt="Podczas policyjnej interwencji podawała się za prokuratorkę. Trzecia osoba z zarzutami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zbxtay-grupa-ludzi-zaatakowala-interweniujacych-policjantow-w-krokowej-zatrzymano-dwie-osoby-7142118/alternates/LANDSCAPE_1280" />
    Policja prowadzi postępowanie wyjaśniające w sprawie przebiegu interwencji.

## W aucie miał ponad 32 kilogramy narkotyków
 - [https://tvn24.pl/najnowsze/torun-w-bagazniku-znalezli-torbe-sportowa-a-w-niej-bezowe-krysztaly-52-latek-uslyszal-juz-zarzut-7150132?source=rss](https://tvn24.pl/najnowsze/torun-w-bagazniku-znalezli-torbe-sportowa-a-w-niej-bezowe-krysztaly-52-latek-uslyszal-juz-zarzut-7150132?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 11:07:25+00:00

<img alt="W aucie miał ponad 32 kilogramy narkotyków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nffc12-zakazane-substancje-to-srodki-psychotropowe-7150118/alternates/LANDSCAPE_1280" />
    52-latek usłyszał zarzut.

## "Chaos i dzika nienawiść". Pseudokibice podpalili stadion podczas derbów Sztokholmu
 - [https://eurosport.tvn24.pl/pilka-nozna/allsvenskan/2023/chaos-i-dzika-nienawisc.-pseudokibice-podpalili-stadion-podczas-derbow-sztokholmu_sto9628170/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/allsvenskan/2023/chaos-i-dzika-nienawisc.-pseudokibice-podpalili-stadion-podczas-derbow-sztokholmu_sto9628170/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:46:40+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xujuxk-derby-sztokholmu-zakonczyly-sie-bitwa-z-policja-i-podpaleniem-stadionu-7150295/alternates/LANDSCAPE_1280" />
    Skandaliczne sceny podczas niedzielnego meczu Djurgardens IF z AIK.

## Erdogan rozdawał pieniądze przed lokalem wyborczym
 - [https://tvn24.pl/biznes/ze-swiata/turcja-wybory-2023-erdogan-rozdawal-wyborcom-banknoty-7148909?source=rss](https://tvn24.pl/biznes/ze-swiata/turcja-wybory-2023-erdogan-rozdawal-wyborcom-banknoty-7148909?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:39:20+00:00

<img alt="Erdogan rozdawał pieniądze przed lokalem wyborczym" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-7n235q-erdogan-7150190/alternates/LANDSCAPE_1280" />
    Media na całym świecie obiegło to nagranie.

## Co najmniej siedem dni stanu wyjątkowego. "Zabierzcie zwierzęta, dokumenty, leki i zapasy"
 - [https://tvn24.pl/tvnmeteo/swiat/kanada-nowa-szkocja-pozary-wprowadzono-stan-wyjatkowy-7150149?source=rss](https://tvn24.pl/tvnmeteo/swiat/kanada-nowa-szkocja-pozary-wprowadzono-stan-wyjatkowy-7150149?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:36:31+00:00

<img alt="Co najmniej siedem dni stanu wyjątkowego. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-23yufh-pozar-w-kanadzie-7151165/alternates/LANDSCAPE_1280" />
    Stan wyjątkowy ma obowiązywać przez siedem dni, jednak może zostać przedłużony w zależności od rozwoju sytuacji.

## Najbardziej niedoceniane miasto na świecie. "Nowy, gorący punkt na mapie"
 - [https://tvn24.pl/ciekawostki/turystyka-najbardziej-niedoceniane-miasto-bolonia-nowy-goracy-punkt-na-mapie-7148709?source=rss](https://tvn24.pl/ciekawostki/turystyka-najbardziej-niedoceniane-miasto-bolonia-nowy-goracy-punkt-na-mapie-7148709?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:31:20+00:00

<img alt="Najbardziej niedoceniane miasto na świecie. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjeciee8c11e35098365101560fa5b97fc599b-stolica-regionu-emilia-romania-jest-bolonia-4610110/alternates/LANDSCAPE_1280" />
    "Mekka smakoszy" i miasto zabytków.

## Donald Tusk skomentował decyzję prezydenta
 - [https://tvn24.pl/polska/lex-tusk-i-decyzja-prezydenta-donald-tusk-skomentowal-7150173?source=rss](https://tvn24.pl/polska/lex-tusk-i-decyzja-prezydenta-donald-tusk-skomentowal-7150173?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:23:58+00:00

<img alt="Donald Tusk skomentował decyzję prezydenta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7v4dd2-pap_20230523_0bb-1-7150210/alternates/LANDSCAPE_1280" />
    W sprawie "lex Tusk".

## Prigożyn "może być sfrustrowany", wskazuje "na jedną osobę"
 - [https://tvn24.pl/swiat/prigozyn-moze-byc-sfrustrowany-isw-obachmucie-i-dzialaniach-szefa-grupy-wagnera-7149038?source=rss](https://tvn24.pl/swiat/prigozyn-moze-byc-sfrustrowany-isw-obachmucie-i-dzialaniach-szefa-grupy-wagnera-7149038?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:22:00+00:00

<img alt="Prigożyn " src="https://tvn24.pl/najnowsze/cdn-zdjecie-y6t0ea-prigozyn-7143550/alternates/LANDSCAPE_1280" />
    Najnowsza analiza Instytutu Studiów nad Wojną (ISW).

## Nie będą sprzedawać biletów na miejsca przy drzwiach. To skutek groźnego incydentu podczas lotu
 - [https://tvn24.pl/swiat/korea-poludniowa-asiana-airlines-nie-bedzie-sprzedawac-biletow-na-miejsca-przy-drzwiach-to-skutek-groznego-incydentu-7149023?source=rss](https://tvn24.pl/swiat/korea-poludniowa-asiana-airlines-nie-bedzie-sprzedawac-biletow-na-miejsca-przy-drzwiach-to-skutek-groznego-incydentu-7149023?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:13:32+00:00

<img alt="Nie będą sprzedawać biletów na miejsca przy drzwiach. To skutek groźnego incydentu podczas lotu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rri9d7-asiana-airlines-7144964/alternates/LANDSCAPE_1280" />
    Sprawca został aresztowany, grozi mu nawet 10 lat pozbawienia wolności.

## Ciężarówka przebiła bariery, zjechała na przeciwległy pas, uderzyła w auta. "Można mówić o cudzie"
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-przed-tunelem-pow-utrudnienia-7150122?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-przed-tunelem-pow-utrudnienia-7150122?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:11:23+00:00

<img alt="Ciężarówka przebiła bariery, zjechała na przeciwległy pas, uderzyła w auta. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1hkn09-zderzenie-trzech-aut-na-s2-7150333/alternates/LANDSCAPE_1280" />
    Połowa tunelu POW zamknięta.

## "Komisja ma wydawać decyzje administracyjne, które de facto będą śmiercią cywilną"
 - [https://tvn24.pl/polska/lex-tusk-z-podpisem-prezydenta-andrzeja-dudy-marcin-matczak-sedzia-bartlomiej-przymusinski-i-mecenas-michal-wawrykiewicz-komentuja-7150082?source=rss](https://tvn24.pl/polska/lex-tusk-z-podpisem-prezydenta-andrzeja-dudy-marcin-matczak-sedzia-bartlomiej-przymusinski-i-mecenas-michal-wawrykiewicz-komentuja-7150082?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:10:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7j8akf-radosc-poslow-pis-po-glosowaniu-nad-powolaniem-komisji-ds-badania-rosyjskich-wplywow-7146347/alternates/LANDSCAPE_1280" />
    Sędzia Bartłomiej Przymusiński ze Stowarzyszenia Sędziów Polskich "Iustitia" odniósł się do decyzji prezydenta w sprawie "lex Tusk".

## Pożar autokaru przewożącego dzieci
 - [https://tvn24.pl/wroclaw/autostrada-a4-opolskie-pozar-autokaru-przewozacego-dzieci-trzy-osoby-trafily-do-szpitala-7150086?source=rss](https://tvn24.pl/wroclaw/autostrada-a4-opolskie-pozar-autokaru-przewozacego-dzieci-trzy-osoby-trafily-do-szpitala-7150086?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:02:04+00:00

<img alt="Pożar autokaru przewożącego dzieci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yvn09u-pozar-autokaru-na-a4-7149004/alternates/LANDSCAPE_1280" />
    Zdjęcia ze zdarzenia otrzymaliśmy na Kontakt 24.

## Wkrótce nowe połączenia z lotniska Warszawa-Radom. "Pobijemy roczny rekord"
 - [https://tvn24.pl/biznes/turystyka/lotnisko-warszawa-radom-wkrotce-nowe-polaczenia-ilu-pasazerow-skorzystalo-z-lotniska-nowe-dane-ppl-7150048?source=rss](https://tvn24.pl/biznes/turystyka/lotnisko-warszawa-radom-wkrotce-nowe-polaczenia-ilu-pasazerow-skorzystalo-z-lotniska-nowe-dane-ppl-7150048?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 10:01:55+00:00

<img alt="Wkrótce nowe połączenia z lotniska Warszawa-Radom. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-x5h30p-lotnisko-warszawa-radom-7130676/alternates/LANDSCAPE_1280" />
    Spółka Polskie Porty Lotnicze podała nowe dane.

## Auto nie ustępuje pierwszeństwa, niemal rozjeżdża dziecko w wózku
 - [https://tvn24.pl/lodz/piotrkow-trybunalski-auto-niemal-potracilo-dziecko-w-wozku-nagranie-sprawa-63-latki-trafi-do-sadu-7148865?source=rss](https://tvn24.pl/lodz/piotrkow-trybunalski-auto-niemal-potracilo-dziecko-w-wozku-nagranie-sprawa-63-latki-trafi-do-sadu-7148865?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:53:36+00:00

<img alt="Auto nie ustępuje pierwszeństwa, niemal rozjeżdża dziecko w wózku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mlsu7c-do-zdarzenia-doszlo-na-skrzyzowaniu-ulicy-wojska-polskiego-i-stronczynskiego-7148836/alternates/LANDSCAPE_1280" />
    Jest nagranie, sprawa trafi do sądu.

## Pokora i radość. Ważne słowa trzeciej rakiety świata
 - [https://eurosport.tvn24.pl/tenis/roland-garros-gra-pojedyncza-kobiet/2023/jessica-pegula-wypowiedziala-sie-na-temat-wielkiej-trojki-w-kobiecym-tenisie_sto9628293/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros-gra-pojedyncza-kobiet/2023/jessica-pegula-wypowiedziala-sie-na-temat-wielkiej-trojki-w-kobiecym-tenisie_sto9628293/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:45:37+00:00

<img alt="Pokora i radość. Ważne słowa trzeciej rakiety świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rdsodl-jessica-pegula-jest-trzecia-rakieta-swiata-7150077/alternates/LANDSCAPE_1280" />
    Pegula doceniła Świątek, Sabalenkę i Rybakinę.

## Samotny, czteroletni chłopiec na hulajnodze w centrum miasta
 - [https://tvn24.pl/katowice/mikolow-samotny-czteroletni-chlopiec-na-hulajnodze-w-centrum-miasta-ojciec-byl-pijany-7150051?source=rss](https://tvn24.pl/katowice/mikolow-samotny-czteroletni-chlopiec-na-hulajnodze-w-centrum-miasta-ojciec-byl-pijany-7150051?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:45:02+00:00

<img alt="Samotny, czteroletni chłopiec na hulajnodze w centrum miasta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qn569g-chlopiec-blakal-sie-bez-opieki-7149920/alternates/LANDSCAPE_1280" />
    Pijany ojciec nie zauważył, jak wychodzi z domu.

## Woda podmyła ulicę. Tył autobusu zawisł nad wyrwą w jezdni
 - [https://tvn24.pl/pomorze/szczecin-tyl-autobusu-zawisl-nad-wyrwa-w-jezdni-woda-podmyla-ulice-7148943?source=rss](https://tvn24.pl/pomorze/szczecin-tyl-autobusu-zawisl-nad-wyrwa-w-jezdni-woda-podmyla-ulice-7148943?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:21:32+00:00

<img alt="Woda podmyła ulicę. Tył autobusu zawisł nad wyrwą w jezdni " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6ct2wx-autobus-zawisl-na-podmyta-jezdnia-7148956/alternates/LANDSCAPE_1280" />
    Droga zamknięta będzie przynajmniej przez dwa dni.

## "Twór rodem ze stalinowskich trójek", "prezydent poważnie osłabił dziś nasz kraj"
 - [https://tvn24.pl/polska/lex-tusk-z-podpisem-prezydenta-andrzeja-dudy-opozycja-komentuje-7149021?source=rss](https://tvn24.pl/polska/lex-tusk-z-podpisem-prezydenta-andrzeja-dudy-opozycja-komentuje-7149021?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:21:27+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-er4oyf-skl-komentarze-7149278/alternates/LANDSCAPE_1280" />
    Decyzję prezydenta komentują politycy opozycji.

## Cztery doby poszukiwań. "Niesamowity cud"
 - [https://tvn24.pl/swiat/ukraina-dwuletnia-dziewczynka-zaginela-w-lesie-poszukiwania-trwaly-cztery-doby-7148290?source=rss](https://tvn24.pl/swiat/ukraina-dwuletnia-dziewczynka-zaginela-w-lesie-poszukiwania-trwaly-cztery-doby-7148290?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:18:00+00:00

<img alt="Cztery doby poszukiwań. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mb5e22-odnaleziona-wioletta-muzeczuk-7148303/alternates/LANDSCAPE_1280" />
    Dwuletnia dziewczynka zaginęła w lesie, szukało jej prawie tysiąc osób.

## Na oczach dzieci spadła do wąwozu, nie przeżyła
 - [https://tvn24.pl/krakow/mala-fatra-slowacja-kobieta-zginela-na-oczach-dzieci-7148900?source=rss](https://tvn24.pl/krakow/mala-fatra-slowacja-kobieta-zginela-na-oczach-dzieci-7148900?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:12:18+00:00

<img alt="Na oczach dzieci spadła do wąwozu, nie przeżyła" src="https://tvn24.pl/krakow/cdn-zdjecie-r33feu-smiertelny-wypadek-w-malej-fatrze-7148911/alternates/LANDSCAPE_1280" />
    W Małej Fatrze.

## Niedźwiedź przez 17 dni chodził z cylindrem na głowie
 - [https://tvn24.pl/tvnmeteo/swiat/tatry-slowacja-niedzwiedz-przez-17-dni-chodzil-z-cylindrem-na-glowie-7148934?source=rss](https://tvn24.pl/tvnmeteo/swiat/tatry-slowacja-niedzwiedz-przez-17-dni-chodzil-z-cylindrem-na-glowie-7148934?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:07:18+00:00

<img alt="Niedźwiedź przez 17 dni chodził z cylindrem na głowie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ues0s6-niedzwiedz-z-cylindrem-na-glowie-7148945/alternates/LANDSCAPE_1280" />
    W słowackich Tatrach.

## Rząd chce walczyć z "martwymi duszami". Minister podał przykład
 - [https://tvn24.pl/biznes/moto/centralna-ewidencja-pojazdow-cep-sejm-przyjal-nowe-przepisy-walka-z-martwymi-duszami-janusz-cieszynski-minister-cyfryzacji-komentuje-7148655?source=rss](https://tvn24.pl/biznes/moto/centralna-ewidencja-pojazdow-cep-sejm-przyjal-nowe-przepisy-walka-z-martwymi-duszami-janusz-cieszynski-minister-cyfryzacji-komentuje-7148655?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:02:39+00:00

<img alt="Rząd chce walczyć z " src="https://tvn24.pl/najnowsze/cdn-zdjecie-s3yod1-chodnik-ulica-samochod-parkowanie-samochody-shutterstock_1928734472-6084491/alternates/LANDSCAPE_1280" />
    Sejm przyjął nowe przepisy.

## W karambolu zginęły dwie osoby. Wyrok dla kierowcy busa
 - [https://tvn24.pl/wroclaw/magnice-w-karambolu-pod-wroclawiem-zginely-dwie-osoby-wyrok-dla-kierowcy-busa-7148704?source=rss](https://tvn24.pl/wroclaw/magnice-w-karambolu-pod-wroclawiem-zginely-dwie-osoby-wyrok-dla-kierowcy-busa-7148704?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 09:01:54+00:00

<img alt="W karambolu zginęły dwie osoby. Wyrok dla kierowcy busa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-deu58c-karambol-na-drodze-krajowej-numer-8-5142208/alternates/LANDSCAPE_1280" />
    Zderzyły się dwa busy, pięć samochodów osobowych i ciężarówka.

## "Lex Tusk". Jest decyzja prezydenta
 - [https://tvn24.pl/polska/lex-tusk-prezydent-andrzej-duda-podpisze-ustawe-w-sprawie-wplywow-rosyjskich-7148584?source=rss](https://tvn24.pl/polska/lex-tusk-prezydent-andrzej-duda-podpisze-ustawe-w-sprawie-wplywow-rosyjskich-7148584?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 08:45:32+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mmr6e8-andrzej-duda-7148968/alternates/LANDSCAPE_1280" />
    Wygłosił oświadczenie.

## Pijany kierowca wjechał w rowerzystę. Nagranie
 - [https://tvn24.pl/pomorze/torun-pijany-kierowca-wjechal-w-rowerzyste-mezczyzna-przekoziolkowal-i-upadl-na-ziemie-nagranie-7148273?source=rss](https://tvn24.pl/pomorze/torun-pijany-kierowca-wjechal-w-rowerzyste-mezczyzna-przekoziolkowal-i-upadl-na-ziemie-nagranie-7148273?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 08:25:54+00:00

<img alt="Pijany kierowca wjechał w rowerzystę. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ybk3t4-rowerzysta-z-obrazeniami-ciala-trafil-do-szpitala-7148270/alternates/LANDSCAPE_1280" />
    Miał ponad promil alkoholu w organizmie.

## Duży bank zablokował karty części klientów. "Wyciek danych"
 - [https://tvn24.pl/biznes/pieniadze/ing-bank-slaski-zablokowal-karty-czesci-klientow-powodem-wyciek-danych-7148837?source=rss](https://tvn24.pl/biznes/pieniadze/ing-bank-slaski-zablokowal-karty-czesci-klientow-powodem-wyciek-danych-7148837?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 08:21:24+00:00

<img alt="Duży bank zablokował karty części klientów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wvsfci-karta-platnicza-4671413/alternates/LANDSCAPE_1280" />
    Jest komunikat.

## Błaszczak do dymisji? Ponad połowa badanych odpowiedziała jednoznacznie
 - [https://tvn24.pl/polska/rakieta-pod-bydgoszcza-szef-mon-mariusz-blaszczak-do-dymisji-sondaz-i-wyniki-7148756?source=rss](https://tvn24.pl/polska/rakieta-pod-bydgoszcza-szef-mon-mariusz-blaszczak-do-dymisji-sondaz-i-wyniki-7148756?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:58:18+00:00

<img alt="Błaszczak do dymisji? Ponad połowa badanych odpowiedziała jednoznacznie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cuv3j9-mariusz-blaszczak-w-miejscowosci-kopczany-7148741/alternates/LANDSCAPE_1280" />
    Wyniki sondażu.

## "Wnosimy o uchylenie decyzji w całości". TOK FM odwołuje się po karze nałożonej przez KRRiT
 - [https://tvn24.pl/polska/tok-fm-odwolanie-od-kary-krrit-80-tysiecy-zlotych-o-co-chodzi-w-sprawie-ukarania-radia-7148732?source=rss](https://tvn24.pl/polska/tok-fm-odwolanie-od-kary-krrit-80-tysiecy-zlotych-o-co-chodzi-w-sprawie-ukarania-radia-7148732?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:46:58+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qf7zgs-tok-fm-7019806/alternates/LANDSCAPE_1280" />
    O szczegółach poinformował serwis internetowy Press.

## "Było naprawdę blisko śmierci"
 - [https://tvn24.pl/kultura-i-styl/edward-james-olmos-gwiazdor-miami-vice-o-walce-z-rakiem-7148714?source=rss](https://tvn24.pl/kultura-i-styl/edward-james-olmos-gwiazdor-miami-vice-o-walce-z-rakiem-7148714?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:45:42+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ulzde5-edward-james-olmos-7148726/alternates/LANDSCAPE_1280" />
    Gwiazdor "Miami Vice" opowiedział o walce z rakiem.

## Wyjaśniła się przyszłość Mbappe
 - [https://eurosport.tvn24.pl/pilka-nozna/kylian-mbappe-pilkarzem-sezonu-we-francji.-oglosil-ze-zostaje-psg_sto9628156/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/kylian-mbappe-pilkarzem-sezonu-we-francji.-oglosil-ze-zostaje-psg_sto9628156/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:38:54+00:00

<img alt="Wyjaśniła się przyszłość Mbappe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wc19ln-mbappe-oglosil-ze-zostaje-w-psg-7148784/alternates/LANDSCAPE_1280" />
    Kluczowe zdanie na gali.

## "Jeśli sytuacja się pogłębi, jeszcze trudniej będzie mu utrzymać władzę"
 - [https://tvn24.pl/swiat/turcja-recep-tayyip-erdogan-wygral-wybory-karolina-wanda-olszowska-komentuje-7148710?source=rss](https://tvn24.pl/swiat/turcja-recep-tayyip-erdogan-wygral-wybory-karolina-wanda-olszowska-komentuje-7148710?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:35:01+00:00

<img alt="" src="https://tvn24.pl/polska/cdn-zdjecie-r8ojau-erdogan-7148745/alternates/LANDSCAPE_1280" />
    Doktor Karolina Wanda Olszowska w TVN24 o wyniku wyborów prezydenckich w Turcji.

## Jest termin startu programu Pierwsze Mieszkanie
 - [https://tvn24.pl/biznes/nieruchomosci/kredyty-mieszkaniowe-bezpieczny-kredyt-2-procent-od-kiedy-waldemar-buda-minister-rozwoju-o-terminie-7148736?source=rss](https://tvn24.pl/biznes/nieruchomosci/kredyty-mieszkaniowe-bezpieczny-kredyt-2-procent-od-kiedy-waldemar-buda-minister-rozwoju-o-terminie-7148736?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:33:04+00:00

<img alt="Jest termin startu programu Pierwsze Mieszkanie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ja4p6l-nieruchomosci-bloki-osiedle-budowa-deweloperzy-6597043/alternates/LANDSCAPE_1280" />
    Minister rozwoju Waldemar Buda w radiowym wywiadzie.

## Oświadczenia majątkowe szefów ABW i Agencji Wywiadu zniknęły z sieci
 - [https://tvn24.pl/premium/abw-agencja-wywiadu-jawnosc-zycia-publicznego-oswiadczenia-majatkowe-szefow-sluzb-specjalnych-niedostepne-7137383?source=rss](https://tvn24.pl/premium/abw-agencja-wywiadu-jawnosc-zycia-publicznego-oswiadczenia-majatkowe-szefow-sluzb-specjalnych-niedostepne-7137383?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:30:22+00:00

<img alt="Oświadczenia majątkowe szefów ABW i Agencji Wywiadu zniknęły z sieci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ayqs31-krzysztof-k-zostal-zatrzymany-przez-abw-zdjecie-ilustracyjne-6996489/alternates/LANDSCAPE_1280" />
    Szefowie Agencji Bezpieczeństwa Wewnętrznego i Agencji Wywiadu przestali publikować swoje oświadczenia majątkowe. Kierownictwo Krajowej Administracji Skarbowej ich nie publikuje, bo "nie ma takiego obowiązku". Powiększa się bałagan dotyczący oświadczeń. Miała go uporządkować ustawa o jawności życia publicznego, ale od pięciu lat nikt się nie zajmuje pracą nad nią.

## Robienie tej rzeczy jeszcze bardziej pogarsza bezsenność
 - [https://tvn24.pl/tvnmeteo/ciekawostki/robienie-tej-rzeczy-jeszcze-bardziej-pogarsza-bezsennosc-7148632?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/robienie-tej-rzeczy-jeszcze-bardziej-pogarsza-bezsennosc-7148632?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:23:15+00:00

<img alt="Robienie tej rzeczy jeszcze bardziej pogarsza bezsenność" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qb4vtf-problemy-ze-snem-i-bezsennosc-5723113/alternates/LANDSCAPE_1280" />
    Wystarczy wyeliminowanie jednego przyzwyczajenia - twierdzą naukowcy.

## "Pewien potworek prawny". Prezes Polskiej Rady Biznesu o "lex Tusk"
 - [https://tvn24.pl/biznes/z-kraju/lex-tusk-komentuje-wojciech-kostrzewa-prezes-polskiej-rady-biznesu-7148643?source=rss](https://tvn24.pl/biznes/z-kraju/lex-tusk-komentuje-wojciech-kostrzewa-prezes-polskiej-rady-biznesu-7148643?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:17:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cuat28-radosc-poslow-pis-po-glosowaniu-nad-powolaniem-komisji-ds-badania-rosyjskich-wplywow-7146347/alternates/LANDSCAPE_1280" />
    Wojciech Kostrzewa we "Wstajesz i wiesz".

## Świętowali urodziny na jeziorze we Włoszech. Nadeszła burza, nie żyją cztery osoby
 - [https://tvn24.pl/swiat/wlochy-statek-z-turystami-zatonal-na-jeziorze-maggiore-cztery-osoby-nie-zyja-7148636?source=rss](https://tvn24.pl/swiat/wlochy-statek-z-turystami-zatonal-na-jeziorze-maggiore-cztery-osoby-nie-zyja-7148636?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:15:11+00:00

<img alt="Świętowali urodziny na jeziorze we Włoszech. Nadeszła burza, nie żyją cztery osoby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-83wckg-lodz-przewrocila-sie-na-jeziorze-maggiore-na-polnocy-wloch-7148646/alternates/LANDSCAPE_1280" />
    Turystyczny statek zatonął w Lombardii.

## "Gang trucicieli" przejmował mieszkania. Na ławie oskarżonych zasiądzie sześć osób
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-gang-trucicieli-przejmowal-mieszkania-starszych-osob-data-procesu-7148615?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-gang-trucicieli-przejmowal-mieszkania-starszych-osob-data-procesu-7148615?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:07:58+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-69l28w-jeden-z-zatrzymanych-w-sprawie-5553637/alternates/LANDSCAPE_1280" />
    Jest data pierwszej rozprawy.

## Palił się zakład produkujący trumny
 - [https://tvn24.pl/pomorze/lubna-pozar-zakladu-produkujacego-trumny-akcja-strazy-gasniczej-7148625?source=rss](https://tvn24.pl/pomorze/lubna-pozar-zakladu-produkujacego-trumny-akcja-strazy-gasniczej-7148625?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 07:06:17+00:00

<img alt="Palił się zakład produkujący trumny" src="https://tvn24.pl/pomorze/cdn-zdjecie-cy2ype-pozar-zakladu-produkujacego-trumny-w-akcji-gasniczej-wziely-udzial-32-zastepy-strazy-pozarnej-7148621/alternates/LANDSCAPE_1280" />
    W akcji brały udział 32 zastępy straży pożarnej.

## Samochód wypadł z drogi, pięć osób rannych
 - [https://tvn24.pl/tvnwarszawa/ulice/s7-uniszki-cegielnia-samochod-wypadl-z-drogi-piec-osob-rannych-7148672?source=rss](https://tvn24.pl/tvnwarszawa/ulice/s7-uniszki-cegielnia-samochod-wypadl-z-drogi-piec-osob-rannych-7148672?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 06:31:43+00:00

<img alt="Samochód wypadł z drogi, pięć osób rannych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5h50q-wypadek-na-trasie-s7-7148676/alternates/LANDSCAPE_1280" />
    Wypadek pod Mławą.

## Dziki na przejściu dla pieszych. Zachowały się przepisowo
 - [https://tvn24.pl/tvnmeteo/polska/gdynia-dziki-na-przejsciu-dla-pieszych-zachowaly-sie-przepisowo-nagranie-7148654?source=rss](https://tvn24.pl/tvnmeteo/polska/gdynia-dziki-na-przejsciu-dla-pieszych-zachowaly-sie-przepisowo-nagranie-7148654?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 06:29:03+00:00

<img alt="Dziki na przejściu dla pieszych. Zachowały się przepisowo" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-fvmx7g-dziki-na-pasach-w-gdyni-7148665/alternates/LANDSCAPE_1280" />
    Nagranie otrzymaliśmy na Kontakt 24.

## "Silnie wzywamy Koreę Północną do powstrzymania się". Stanowcza reakcja Japonii
 - [https://tvn24.pl/swiat/koreapolnocna-proby-rakietowe-pjongjang-chce-wystrzelic-satelite-wojskowego-japonia-odpowiada-7148565?source=rss](https://tvn24.pl/swiat/koreapolnocna-proby-rakietowe-pjongjang-chce-wystrzelic-satelite-wojskowego-japonia-odpowiada-7148565?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 06:10:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oejsih-pap_20190509_2ho-1-7148653/alternates/LANDSCAPE_1280" />
    Reżim północnokoreański zapowiada wystrzelenie satelity wojskowego.

## "Prezydent też musi myśleć o swojej przyszłości. To jeszcze jest młody człowiek"
 - [https://tvn24.pl/polska/lex-tusk-czeka-na-decyzje-prezydenta-andrzeja-dudy-roza-thun-komentuje-7148650?source=rss](https://tvn24.pl/polska/lex-tusk-czeka-na-decyzje-prezydenta-andrzeja-dudy-roza-thun-komentuje-7148650?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 06:08:23+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yrr3og-roza-thun-7148628/alternates/LANDSCAPE_1280" />
    Europosłanka Róża Thun w TVN24.

## Polski gigant ma zmienić nazwę, co z logo? Spółka wyjaśnia
 - [https://tvn24.pl/biznes/z-kraju/pkn-orlen-ma-zmienic-nazwe-co-z-logo-czy-bedzie-rebranding-pkn-orlen-wyjasnia-7148606?source=rss](https://tvn24.pl/biznes/z-kraju/pkn-orlen-ma-zmienic-nazwe-co-z-logo-czy-bedzie-rebranding-pkn-orlen-wyjasnia-7148606?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 06:05:15+00:00

<img alt="Polski gigant ma zmienić nazwę, co z logo? Spółka wyjaśnia" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-wf5vzv-orlentransport10-6559268/alternates/LANDSCAPE_1280" />
    Mamy odpowiedź.

## Istnieją 176 lat. Zadebiutują w Bundeslidze
 - [https://eurosport.tvn24.pl/pilka-nozna/2-bundesliga/2022-2023/heidenheim-pierwszy-raz-w-historii-zagra-w-bundeslidze_sto9627246/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/2-bundesliga/2022-2023/heidenheim-pierwszy-raz-w-historii-zagra-w-bundeslidze_sto9627246/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 06:01:31+00:00

<img alt="Istnieją 176 lat. Zadebiutują w Bundeslidze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dt1qma-awans-do-bundesligi-jest-wielkim-sukcesem-fc-heidenheim-7148656/alternates/LANDSCAPE_1280" />
    Dla tak niespodziewanych momentów powstała piłka nożna. FC Heidenheim, mały niemiecki klub, istniejący co prawda już od 176 lat, pierwszy raz w dziejach awansował do Bundesligi. Debiut w tamtejszej ekstraklasie zapewnił sobie przy okazji szalonej, 34. serii gier 2. Bundesligi.

## Prezydent zabierze głos. Podano godzinę
 - [https://tvn24.pl/polska/prezydent-andrzej-duda-wyglosi-wypowiedz-dla-mediow-na-decyzje-prezydenta-czeka-ustawa-lex-tusk-7148617?source=rss](https://tvn24.pl/polska/prezydent-andrzej-duda-wyglosi-wypowiedz-dla-mediow-na-decyzje-prezydenta-czeka-ustawa-lex-tusk-7148617?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 05:49:00+00:00

<img alt="Prezydent zabierze głos. Podano godzinę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h6b75g-andrzej-duda-7146530/alternates/LANDSCAPE_1280" />
    Kancelaria Andrzeja Dudy wydała komunikat.

## Grupa migrantów na polsko-białoruskiej granicy. "Od dwóch dni bez wody"
 - [https://tvn24.pl/polska/polsko-bialoruska-granica-grupa-migrantow-przy-murze-na-granicy-biuro-rpo-zajmuje-sie-sprawa-7148589?source=rss](https://tvn24.pl/polska/polsko-bialoruska-granica-grupa-migrantow-przy-murze-na-granicy-biuro-rpo-zajmuje-sie-sprawa-7148589?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 05:35:15+00:00

<img alt="Grupa migrantów na polsko-białoruskiej granicy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hmvbe7-migranci-na-polsko-bialoruskiej-granicy-7148597/alternates/LANDSCAPE_1280" />
    Według aktywistów jest tam kilka kobiet i mężczyzn oraz kilkanaścioro dzieci.

## Szczęsny bez szans. Główka Giroud na wagę Ligi Mistrzów
 - [https://eurosport.tvn24.pl/pilka-nozna/serie-a/2022-2023/juventus-ac-milan-wynik-meczu-i-relacja-serie-a_sto9628144/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/serie-a/2022-2023/juventus-ac-milan-wynik-meczu-i-relacja-serie-a_sto9628144/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 05:29:15+00:00

<img alt="Szczęsny bez szans. Główka Giroud na wagę Ligi Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pt0jj6-giroud-dal-milanowi-zwyciestwo-7148611/alternates/LANDSCAPE_1280" />
    Piłkarze AC Milan wygrali w Turynie z Juventusem 1:0.

## Zachodni kapitał ucieka z Rosji. Wysokość strat
 - [https://tvn24.pl/biznes/ze-swiata/rosja-zagraniczny-kapital-opuszcza-rosje-podano-kwote-7148581?source=rss](https://tvn24.pl/biznes/ze-swiata/rosja-zagraniczny-kapital-opuszcza-rosje-podano-kwote-7148581?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 05:26:13+00:00

<img alt="Zachodni kapitał ucieka z Rosji. Wysokość strat" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-htwulk-wladimir-putin-7148592/alternates/LANDSCAPE_1280" />
    Szacunki na podstawie danych banku centralnego.

## Kto następną rywalką Fręch?
 - [https://eurosport.tvn24.pl/tenis/roland-garros/2023/z-kim-zagra-magdalena-frech-w-drugiej-rundzie-roland-garros-kto-rywalka-polki_sto9626759/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros/2023/z-kim-zagra-magdalena-frech-w-drugiej-rundzie-roland-garros-kto-rywalka-polki_sto9626759/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 04:59:00+00:00

<img alt="Kto następną rywalką Fręch?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q6o0ta-frech-gra-dalej-7148588/alternates/LANDSCAPE_1280" />
    Magdalena Fręch poznała rywalkę w drugiej rundzie Rolanda Garrosa.

## Kalendarz gospodarczy. Na to warto zwrócić uwagę w tym tygodniu
 - [https://tvn24.pl/biznes/z-kraju/gospodarka-najwazniejsze-wydarzenia-w-tym-tygodniu-7148575?source=rss](https://tvn24.pl/biznes/z-kraju/gospodarka-najwazniejsze-wydarzenia-w-tym-tygodniu-7148575?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 04:58:55+00:00

<img alt="Kalendarz gospodarczy. Na to warto zwrócić uwagę w tym tygodniu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-97ab0w-do-35-procent-w-ujeciu-rocznym-z-32-procent-szacowanego-pod-koniec-maja-obnizyla-prognoze-pkb-polski-agencja-fitch-4686378/alternates/LANDSCAPE_1280" />
    Lista.

## Sankcje na 50 lat. "Teheranowi chciałbym dziś przypomnieć prawo bumerangu"
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-sankcje-wobec-iranu-zelenski-prosi-o-zatwierdzenie-sankcji-na-50-lat-7148527?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-sankcje-wobec-iranu-zelenski-prosi-o-zatwierdzenie-sankcji-na-50-lat-7148527?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 04:48:06+00:00

<img alt="Sankcje na 50 lat. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-25s9bp-teheran-5084932/alternates/LANDSCAPE_1280" />
    Decyzja podjęta, czeka na zatwierdzenie parlamentu.

## Porozumienie w sprawie limitu zadłużenia. "Mamy dobre wieści"
 - [https://tvn24.pl/biznes/ze-swiata/prezydent-usa-joe-biden-o-porozumieniu-w-sprawie-budzetu-wkrotce-glosowanie-w-kongresie-7148566?source=rss](https://tvn24.pl/biznes/ze-swiata/prezydent-usa-joe-biden-o-porozumieniu-w-sprawie-budzetu-wkrotce-glosowanie-w-kongresie-7148566?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 04:47:09+00:00

<img alt="Porozumienie w sprawie limitu zadłużenia. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-fgd9ih-joe-biden-7148576/alternates/LANDSCAPE_1280" />
    Prezydent Joe Biden o porozumieniu.

## Biden, Duda, Zełenski, Macron. Gratulacje płyną z całego świata
 - [https://tvn24.pl/swiat/recep-tayyip-erdogan-wygral-wybory-prezydenckie-w-turcji-swiatowi-przywodcy-pogratulowali-erdoganowi-7148551?source=rss](https://tvn24.pl/swiat/recep-tayyip-erdogan-wygral-wybory-prezydenckie-w-turcji-swiatowi-przywodcy-pogratulowali-erdoganowi-7148551?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 04:20:00+00:00

<img alt="Biden, Duda, Zełenski, Macron. Gratulacje płyną z całego świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lb1qnv-recep-tayyip-erdogan-przemawia-do-swoich-zwolennikow-7148561/alternates/LANDSCAPE_1280" />
    Recep Tayyip Erdogan wygrał wybory prezydenckie w Turcji - ogłosił przewodniczący tamtejszej państwowej komisji wyborczej.

## Uczta dla fanów tenisa. Zagrają lider rankingu i najbardziej utytułowany zawodnik
 - [https://eurosport.tvn24.pl/tenis/roland-garros-gra-pojedyncza-mezczyzn/2023/plan-transmisji-2.-dnia-roland-garros-2023_sto9627625/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/roland-garros-gra-pojedyncza-mezczyzn/2023/plan-transmisji-2.-dnia-roland-garros-2023_sto9627625/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 04:18:53+00:00

<img alt="Uczta dla fanów tenisa. Zagrają lider rankingu i najbardziej utytułowany zawodnik" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m8xlbj-novak-djokovic-7148567/alternates/LANDSCAPE_1280" />
    Plan transmisji 2. dnia Roland Garros.

## Nowy parlament zaprzysiężony. Najpóźniej we wtorek będzie rozwiązany
 - [https://tvn24.pl/swiat/grecja-nowy-parlament-zaprzysiezony-wkrotce-ma-zostac-rozwiazany-7148517?source=rss](https://tvn24.pl/swiat/grecja-nowy-parlament-zaprzysiezony-wkrotce-ma-zostac-rozwiazany-7148517?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 04:00:37+00:00

<img alt="Nowy parlament zaprzysiężony. Najpóźniej we wtorek będzie rozwiązany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lfqryt-zaprzysiezenie-nowego-parlamentu-w-grecji-7148522/alternates/LANDSCAPE_1280" />
    Zawirowania polityczne w Grecji.

## "Odporność Kijowa pokazuje siłę jego mieszkańców"
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-brytyjski-szef-msz-o-ataku-rosjan-na-kijow-odpornosc-miasta-pokazuje-sile-jego-mieszkancow-7148541?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-brytyjski-szef-msz-o-ataku-rosjan-na-kijow-odpornosc-miasta-pokazuje-sile-jego-mieszkancow-7148541?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 03:50:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ykw231-kijow-zniszczenia-po-kolejnym-rosyjskim-ataku-7148193/alternates/LANDSCAPE_1280" />
    Ocenił James Cleverly, brytyjski minister spraw zagranicznych.

## Radość w Turcji. Tłumy na ulicach
 - [https://tvn24.pl/swiat/recep-tayyip-erdogan-wygral-wybory-prezydenckie-w-turcji-zwolennicy-erdogana-swietowali-w-ankarze-i-stambule-7148550?source=rss](https://tvn24.pl/swiat/recep-tayyip-erdogan-wygral-wybory-prezydenckie-w-turcji-zwolennicy-erdogana-swietowali-w-ankarze-i-stambule-7148550?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 03:38:00+00:00

<img alt="Radość w Turcji. Tłumy na ulicach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7fq52o-zwolennicy-prezydenta-erdogana-swietuja-na-ulicach-stambulu-7148563/alternates/LANDSCAPE_1280" />
    Między innymi w Ankarze i Stambule.

## Zwycięstwo Erdogana, wygrana Barcelony, triumf Hurkacza i Fręch. Pięć rzeczy, które warto wiedzieć 29 maja
 - [https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-29-maja-7148546?source=rss](https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-29-maja-7148546?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 03:30:00+00:00

<img alt="Zwycięstwo Erdogana, wygrana Barcelony, triumf Hurkacza i Fręch. Pięć rzeczy, które warto wiedzieć 29 maja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bq6uws-wybory-w-turcji-7148562/alternates/LANDSCAPE_1280" />
    Podsumowujemy.

## Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-28-maja-2023-7148545?source=rss](https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-28-maja-2023-7148545?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 03:22:49+00:00

<img alt="Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r0iv3j-kijow-ukraina-28052023-7147821/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 460 dni.

## Eksplozje słyszane w Kijowie. "Obrona przeciwlotnicza działa!"
 - [https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-na-zywo-poniedzialek-29-maja-7148532?source=rss](https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-na-zywo-poniedzialek-29-maja-7148532?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-05-29 03:12:08+00:00

<img alt="Eksplozje słyszane w Kijowie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m50y1x-kijow-zaatakowany-dronami-7147695/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

