# Source:Vsauce, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA, language:en-US

## The Only Element You Can Chew Like Gum
 - [https://www.youtube.com/watch?v=Xed60vrCuVM](https://www.youtube.com/watch?v=Xed60vrCuVM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA
 - date published: 2023-05-29 13:42:12+00:00



