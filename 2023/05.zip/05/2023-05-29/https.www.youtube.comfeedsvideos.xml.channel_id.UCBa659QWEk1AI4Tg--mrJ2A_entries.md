# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## This is an excuse to show you a really good tunnel
 - [https://www.youtube.com/watch?v=xWL40q3DMoQ](https://www.youtube.com/watch?v=xWL40q3DMoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2023-05-29 15:00:45+00:00

The Catesby Tunnel, in the UK, is an old Victorian railway tunnel that has a new use: a secretive car testing facility, like a wind tunnel but in reverse. So rather than just show it to the world, I thought I'd answer a question: if you stick a camera on the outside of your car, how much does the drag cost you? ■ The tunnel: https://catesbytunnel.com/

Camera: Jamie MacLeod https://www.jamiemacleod.co.uk/
Editor: Michelle Martin https://twitter.com/mrsmmartin

This is not an advert, Catesby Projects and the tunnel team had no editorial control and I wasn't paid. (In fact, I paid quite a bit for the fire safety team!)

Thank you to the many people who suggested this over the years, but in particular to David who was able to put me in touch with them directly!

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

