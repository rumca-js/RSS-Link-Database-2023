# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Plaga szarańczy na włoskiej wyspie. Na pomoc wysłano wojsko
 - [https://www.money.pl/gospodarka/plaga-szaranczy-na-wloskiej-wyspie-na-pomoc-wyslano-wojsko-6903351875697376a.html](https://www.money.pl/gospodarka/plaga-szaranczy-na-wloskiej-wyspie-na-pomoc-wyslano-wojsko-6903351875697376a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 19:30:36+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3387e129-8395-4fb1-8936-af50a01f3984" width="308" /> Rolnicy z Sardynii alarmują w sprawie szarańczy, która niszczy uprawy na tej włoskiej wyspie. Obszar dotknięty tą plagą zwiększył się tam aż 25-krotnie w ciągu ostatnich pięciu lat. Na ratunek ma ruszyć wojsko.

## Scania zamyka fabrykę na północy Polski. Ponad 800 osób straci pracę
 - [https://www.money.pl/gospodarka/scania-zamyka-fabryke-na-polnocy-polski-ponad-800-osob-straci-prace-6903325153262304a.html](https://www.money.pl/gospodarka/scania-zamyka-fabryke-na-polnocy-polski-ponad-800-osob-straci-prace-6903325153262304a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 17:41:53+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/42584dc8-e5a0-461c-ba0e-a368740d9742" width="308" /> Scania zamyka fabrykę w Słupsku. Pracę straci 847 osób. Wygaszenie produkcji w zakładzie planowane jest na pierwszy kwartał 2024 roku. Jednocześnie nadal będzie działać zakład w okolicach Słupska, który zatrudnia 200 osób.

## Marsy tylko w papierku. Rewolucja na Wsypach
 - [https://www.money.pl/gospodarka/marsy-tylko-w-papierku-rewolucja-na-wsypach-6903310306933472a.html](https://www.money.pl/gospodarka/marsy-tylko-w-papierku-rewolucja-na-wsypach-6903310306933472a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 16:41:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/602c4027-c5af-4fd2-9553-5e50518549d4" width="308" /> Batoniki Mars w papierowym opakowania testowo wprowadzone zostały w Wielkiej Brytanii. Mars Wrigley UK tłumaczy zmianę tym, że celem korporacji jest zapewnienie, aby wszystkie opakowania produktów nadawały się do recyklingu, ponownego wykorzystania lub kompostowania

## Świadczenie wspierające inne od zapowiadanego. PiS w Sejmie całkowicie je zmieniło
 - [https://www.money.pl/gospodarka/swiadczenie-wspierajace-inne-od-zapowiadanego-pis-w-sejmie-calkowicie-je-zmienilo-6901918996544128a.html](https://www.money.pl/gospodarka/swiadczenie-wspierajace-inne-od-zapowiadanego-pis-w-sejmie-calkowicie-je-zmienilo-6901918996544128a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 15:59:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bad1eac1-2237-4d76-aff8-0b1c23618704" width="308" /> Sejm na ostatnim posiedzeniu uchwalił ustawę o świadczeniu wspierającym. W trakcie prac okazało się, że Prawo i Sprawiedliwość przygotowało szereg poprawek, które "wysadziły w kosmos" pierwotną propozycję. Środowiska osób z niepełnosprawnościami zgłaszają szereg uwag do nowego rozwiązania.

## PiS zamiast Stanów? Nie milkną komentarze po decyzji Andrzeja Dudy
 - [https://www.money.pl/gospodarka/pis-zamiast-stanow-nie-milkna-komentarze-po-decyzji-andrzeja-dudy-6903289414118080a.html](https://www.money.pl/gospodarka/pis-zamiast-stanow-nie-milkna-komentarze-po-decyzji-andrzeja-dudy-6903289414118080a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 15:16:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6bcbf957-1f51-4222-8d75-f1d5328177ed" width="308" /> Decyzja Andrzeja Dudy w sprawie tzw. lex Tusk wywołała falę komentarzy. Także dotyczących przyszłości politycznej urzędującego prezydenta. Zdaniem politologa Rafał Chwedoruka urzędująca głowa państwa miała dwie opcje, a decyzja w sprawie komisji wskazuje na to, że prezydent dokonał wyboru.

## Bycie influencerem i chrześcijaninem. Watykan zabiera głos w sprawie
 - [https://www.money.pl/gospodarka/bycie-influencerem-i-chrzescijaninem-watykan-zabiera-glos-w-sprawie-6903272157784768a.html](https://www.money.pl/gospodarka/bycie-influencerem-i-chrzescijaninem-watykan-zabiera-glos-w-sprawie-6903272157784768a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 14:13:35+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5f47d923-85ed-44ab-af3a-da1961811e36" width="308" /> Watykan odniósł się do kwestii bycia influencerem. Jak wynika z kościelnego dokumentu – nic nie stoi przeciw temu, żeby chrześcijanie mogli korzystać ze swoich zasięgów w sieci. Zdaniem hierarchów influencerami byli już męczennicy.

## Miała pozwać rodziców za swoje narodziny. Teraz tłumaczy się z żartu i własnych dzieci
 - [https://www.money.pl/gospodarka/miala-pozwac-rodzicow-za-swoje-narodziny-teraz-tlumaczy-sie-z-zartu-i-wlasnych-dzieci-6903266678053600a.html](https://www.money.pl/gospodarka/miala-pozwac-rodzicow-za-swoje-narodziny-teraz-tlumaczy-sie-z-zartu-i-wlasnych-dzieci-6903266678053600a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 14:06:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/dd66946f-1272-4eb3-9eaf-3707106f96cc" width="308" /> Miała pozwać rodziców za swoje narodziny,&nbsp;a teraz żart obrócił się przeciwko mieszkającej w New Jersey influencerce. Okazało się, że Kass Theaz, choć sama oburza się na swoje przyjście na świat, ma dzieci, ale, jak sama tłumaczy – zgodnie ze swoimi przekonaniami.

## Oto jak turecka lira zareagowała na wynik wyborów w Turcji
 - [https://www.money.pl/pieniadze/turecka-lira-zareagowala-na-wynik-wyborow-w-turcji-podziekujcie-erdoganowi-6903248437066432a.html](https://www.money.pl/pieniadze/turecka-lira-zareagowala-na-wynik-wyborow-w-turcji-podziekujcie-erdoganowi-6903248437066432a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 13:44:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7a57dc3b-c3e3-4889-9120-6690bddb9819" width="308" /> Turecka lira wyznacza nowe minima po ogłoszeniu wyników wyborów, które wygrał urzędujący prezydent Recep Tayyip Erdogan. W poniedziałek rano kurs dolara przekroczył historyczną granicę 20 lir.

## 29.05 Program Money.pl | Polska w ogonie Europy jeśli chodzi o dzietność. Dlaczego Polacy nie chcą mieć dzieci?
 - [https://www.money.pl/gospodarka/29-05-program-money-pl-polska-w-ogonie-europy-jesli-chodzi-o-dzietnosc-dlaczego-polacy-nie-chca-miec-dzieci-6903239196067969v.html](https://www.money.pl/gospodarka/29-05-program-money-pl-polska-w-ogonie-europy-jesli-chodzi-o-dzietnosc-dlaczego-polacy-nie-chca-miec-dzieci-6903239196067969v.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 11:52:12+00:00

<img src="https://i.wpimg.pl/308x/wptv-upload-api.wpcdn.pl/06197857-f78f-479a-a350-58ee1525af7c.jpg" width="308" /> Wskaźnik dzietności w Polsce spadł w 2022 r. do najniższego poziomu od 9 lat. Jak wskazał Kamil Sobolewski, główny ekonomista Pracodawców RP, jest kilka powodów, dla których dzietność w Polsce jest niska, ale głównym czynnikiem może być niepewność dotycząca przyszłości. Wyjaśnił również, jak niska dzietność wpłynie na rynek pracy - m.in. w jakich zawodach będzie brakować ludzi.

## Amerykańska firma otwiera samochodowe centrum w Gliwicach. Oto szczegóły
 - [https://www.money.pl/gospodarka/amerykanska-firma-otwiera-samochodowe-centrum-w-gliwicach-oto-szczegoly-6903238626732736a.html](https://www.money.pl/gospodarka/amerykanska-firma-otwiera-samochodowe-centrum-w-gliwicach-oto-szczegoly-6903238626732736a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 11:49:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/65abe82b-54d6-4f93-95fd-44d290842fbe" width="308" /> Firma Tenneco ze Stanów Zjednoczonych otworzyła w Gliwicach centrum inżynieryjne. Ma ono obsługiwać spółki w zakresie europejskiego systemu kontroli jazdy i technologii zawieszenia. Pracę w nowym zakładzie znajdzie ponad 200 inżynierów.

## Rekordowy spadek kursu Borussii Dortmund. Czegoś takiego jeszcze nie było
 - [https://www.money.pl/gielda/rekordowy-spadek-kursu-borussii-dortmund-czegos-takiego-jeszcze-nie-bylo-6903219732040416a.html](https://www.money.pl/gielda/rekordowy-spadek-kursu-borussii-dortmund-czegos-takiego-jeszcze-nie-bylo-6903219732040416a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 11:06:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/692323da-ce6d-4186-b9bb-4757d6cea5fa" width="308" /> Borussia Dortmund w ostatnich minutach sezonu straciła szanse na tytuł mistrza Niemiec. Kibice przeżyli dramat w weekend, w poniedziałek płaczą akcjonariusze, gdy kurs akcji Borussii na otwarcie nowego tygodnia odnotował stratę rzędu ponad 30 proc.

## Wzrost oprocentowania depozytów. "Ruch w górę zaskoczył"
 - [https://www.money.pl/pieniadze/wzrost-oprocentowania-depozytow-ruch-w-gore-zaskoczyl-6903219232770752a.html](https://www.money.pl/pieniadze/wzrost-oprocentowania-depozytow-ruch-w-gore-zaskoczyl-6903219232770752a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 10:44:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/34339eef-062b-4665-bab0-cbcd01474e62" width="308" /> Średnie oprocentowanie najlepszych lokat i rachunków oszczędnościowych wynosi 7,05 proc. - wynika z majowej analizy HREIT opublikowanej w poniedziałek.

## Zmiany w urzędach skarbowych. Wielkie ułatwienie dla podatników
 - [https://www.money.pl/podatki/zmiany-w-urzedach-skarbowych-wielkie-ulatwienie-dla-podatnikow-6903209518914240a.html](https://www.money.pl/podatki/zmiany-w-urzedach-skarbowych-wielkie-ulatwienie-dla-podatnikow-6903209518914240a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 10:15:02+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5179e9c2-75d9-421a-86fc-780442c13d70" width="308" /> Naczelnicy urzędów skarbowych będą mogli telefonicznie lub za pośrednictwem e-Urzędu Skarbowego przekazywać podatnikom dane skarbowe, których uzyskanie obecnie wymaga wizyty w urzędzie – wynika projektu rozporządzenia Ministerstwa Finansów.

## "VAT-owskie pijawki" i zakopane pieniądze. Rząd rusza z nową kampanią
 - [https://www.money.pl/podatki/vat-owskie-pijawki-i-zakopane-pieniadze-rzad-rusza-z-nowa-kampania-6903208255691456a.html](https://www.money.pl/podatki/vat-owskie-pijawki-i-zakopane-pieniadze-rzad-rusza-z-nowa-kampania-6903208255691456a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 09:46:14+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cbad5a30-4c94-4ed0-a678-6a0faf0e73f8" width="308" /> Mateusz Morawiecki na konferencji prasowej stwierdził, że jego rząd wprowadził system finansowy w XXI w. Jego zdaniem dzięki walce z mafiami VAT-owskimi udało się znaleźć pieniądze na programy socjalne. – Pan Tusk był jak znachor, przykładał do systemu pijawki – stwierdził szef rządu.

## Komisja Europejska renegocjowała umowę z Pfizerem. "Pozostaje więcej pytań niż odpowiedzi"
 - [https://www.money.pl/gospodarka/komisja-europejska-renegocjowala-umowe-z-pfizerem-pozostaje-wiecej-pytan-niz-odpowiedzi-6903190847003264a.html](https://www.money.pl/gospodarka/komisja-europejska-renegocjowala-umowe-z-pfizerem-pozostaje-wiecej-pytan-niz-odpowiedzi-6903190847003264a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 08:51:02+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/aefb2129-f72c-4532-be6a-2da303d47ede" width="308" /> Komisja Europejska poinformowała, że osiągnęła porozumienie z Pfizerem w kwestii renegocjacji dostaw szczepionek przeciwko koronawirusowi. Krytyki nie szczędzi politico.eu. "Zrobiła to w taki sposób, że pozostaje więcej pytań niż odpowiedzi" – napisał portal.

## Jak zacząć oszczędzać na emeryturę już teraz?
 - [https://www.money.pl/emerytury/jak-zaczac-oszczedzac-na-emeryture-juz-teraz-6903187894536832a.html](https://www.money.pl/emerytury/jak-zaczac-oszczedzac-na-emeryture-juz-teraz-6903187894536832a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 08:23:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b0473a13-d462-40a1-928a-cac6c546b5cf" width="308" /> Polacy obawiają się obniżenia poziomu życia po przejściu na emeryturę. Wielu z nas drży o to, że będzie dotkniętych ubóstwem. Niestety, ale takie obawy mogą być uzasadnione, zwłaszcza biorąc pod uwagę wyliczenia ekspertów, które wskazują, że przyszłe świadczenia dzisiejszych 40-latków będą głodowe. Dlatego warto z odpowiednim wyprzedzeniem pomyśleć o oszczędzaniu na przyszłość. Jak to zrobić? Z jakich produktów emerytalnych naprawdę warto skorzystać?

## Cała prawda o zarobkach budowlańców. Oto ile można zarobić na budowie
 - [https://www.money.pl/gospodarka/cala-prawda-o-zarobkach-budowlancow-oto-ile-mozna-zarobic-na-budowie-6903158409910912a.html](https://www.money.pl/gospodarka/cala-prawda-o-zarobkach-budowlancow-oto-ile-mozna-zarobic-na-budowie-6903158409910912a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 07:43:55+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d6b29976-4f4b-4978-8fbd-aaf52278c777" width="308" /> Wiosna na dobre zagościła w Polsce, a to oznacza przyspieszenie prac i inwestycji w sektorze budowlanym. Ciepłe dni zachęcają też Polaków do remontów, a część z nich będzie wolała oddać prace w ręce fachowców. Dlatego też portal Superbiz.se.pl przyjrzał się zarobkom pracowników sektora.

## "Bezpieczny kredyt". Jest deklaracja trzech największych banków
 - [https://www.money.pl/banki/bezpieczny-kredyt-jest-deklaracja-trzech-najwiekszych-bankow-6903165897931424a.html](https://www.money.pl/banki/bezpieczny-kredyt-jest-deklaracja-trzech-najwiekszych-bankow-6903165897931424a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 06:53:53+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a43fb2b6-4fa9-4c05-9bf8-17d3a021b1ed" width="308" /> Trzy największe banki w Polsce zadeklarowały chęć i gotowość wprowadzenia do oferty rządowego programu "Bezpieczny kredyt" - powiedział w poniedziałek minister rozwoju i technologii Waldemar Buda w Programie 1 Polskiego Radia. 3 lipca program wejdzie w życie.

## Mistrzyni olimpijska uciekła z Ukrainy ze względu na wojnę. Dziś pracuje w monopolowym
 - [https://www.money.pl/gospodarka/mistrzyni-olimpijska-uciekla-z-ukrainy-ze-wzgledu-na-wojne-dzis-pracuje-w-monopolowym-6903165282609792a.html](https://www.money.pl/gospodarka/mistrzyni-olimpijska-uciekla-z-ukrainy-ze-wzgledu-na-wojne-dzis-pracuje-w-monopolowym-6903165282609792a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 06:51:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9f74ebb8-cb05-40e7-818c-959455a0661f" width="308" /> Iryna Mełeni to ukraińska mistrzyni olimpijska, świata i Europy w zapasach. Musiała jednak uciec ze swojego kraju ze względu na wojnę. Sportsmenka odnalazła się w Szwecji, gdzie pracuje w państwowym sklepie monopolowym. Zdradziła też, ile zarabia na nowym stanowisku.

## Rząd chce przyspieszyć z inwestycjami. Szykuje się rewolucja. Postanowienia nie będzie można zaskarżyć
 - [https://www.money.pl/gospodarka/rzad-chce-przyspieszyc-z-inwestycjami-szykuje-sie-rewolucja-postanowienia-nie-bedzie-mozna-zaskarzyc-6903139590544000a.html](https://www.money.pl/gospodarka/rzad-chce-przyspieszyc-z-inwestycjami-szykuje-sie-rewolucja-postanowienia-nie-bedzie-mozna-zaskarzyc-6903139590544000a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 06:24:41+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/be2d9839-e532-428e-9160-df0001c43dc7" width="308" /> Rząd chce przyspieszyć ważne inwestycji. Do Sejmu trafił projekt zmian w kilku ustawach. Jeżeli zostaną przegłosowane, to dla wybranych inwestycji nie trzeba już będzie zdobywać decyzji środowiskowej. Wystarczy postanowienie Generalnej Dyrekcji Ochrony Środowiska, którego nie będzie można zaskarżyć- donosi "Dziennik Gazeta Prawna".

## Krok w stronę atomu w Polsce. Amerykańskie koncerny się porozumiały
 - [https://www.money.pl/gospodarka/krok-w-strone-atomu-w-polsce-amerykanskie-koncerny-sie-porozumialy-6903156532755072a.html](https://www.money.pl/gospodarka/krok-w-strone-atomu-w-polsce-amerykanskie-koncerny-sie-porozumialy-6903156532755072a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 06:15:45+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d849acec-040d-40af-933b-4b55e6a31241" width="308" /> Dwa amerykańskie podmioty porozumiały się w sprawie stworzenia konsorcjum. Westinghouse i Bechtel, bo o nich mowa, wspólnymi siłami mają wybudować pierwszą elektrownię jądrową w Polsce – pisze "Puls Biznesu".

## Rządowi marzy się 300-tysięczna armia. Wiadomo, ile to będzie kosztować
 - [https://www.money.pl/gospodarka/rzadowi-marzy-sie-300-tysieczna-armia-wiadomo-ile-to-bedzie-kosztowac-6903155588430496a.html](https://www.money.pl/gospodarka/rzadowi-marzy-sie-300-tysieczna-armia-wiadomo-ile-to-bedzie-kosztowac-6903155588430496a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 06:11:55+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2735cdf5-3950-4d6b-9002-089de2697d0f" width="308" /> Ministerstwo Obrony Narodowej  chce zwiększyć liczebność wojska, do 300 tys. żołnierzy. Na same wynagrodzenia i utrzymanie tak wielkiej armii trzeba będzie wydawać kilkadziesiąt miliardów złotych rocznie - informuje "Rzeczypospolita".

## Kary za brak OC. Stawki będą rekordowo wysokie
 - [https://www.money.pl/pieniadze/kary-za-brak-oc-stawki-beda-rekordowo-wysokie-6903147692345984a.html](https://www.money.pl/pieniadze/kary-za-brak-oc-stawki-beda-rekordowo-wysokie-6903147692345984a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 05:39:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/355e85fc-a72e-4d71-a337-d7c753e54bab" width="308" /> Opłata za brak obowiązkowego ubezpieczenia OC pojazdu będzie w 2024 r. rekordowo wysoka - donosi serwis autokult.pl. Stawki będą różne w pierwszej i drugiej połowie roku. Maksymalna kara przekroczy 8 tys. zł.

## Afera w NCBiR uderzyła w nich rykoszetem. "To nie my popełniliśmy błąd"
 - [https://www.money.pl/gospodarka/afera-w-ncbir-uderzyla-w-nich-rykoszetem-to-nie-my-popelnilismy-blad-6903146432342656a.html](https://www.money.pl/gospodarka/afera-w-ncbir-uderzyla-w-nich-rykoszetem-to-nie-my-popelnilismy-blad-6903146432342656a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 05:34:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f54283ce-ea60-40eb-b7c0-1f00a435d3f1" width="308" /> W nagłośnionym programie "Szybka ścieżka" NCBiR-u udział wzięły też firmy niezwiązane z politykami. W wyniku kontroli resortu funduszy także i one tracą granty i dofinansowania. – To nie my popełniliśmy jakiś błąd, ale ktoś, kto nasz wniosek oceniał – stwierdził przedstawiciel jednej z nich.

## Kursy walut 29.05.2023. Poniedziałkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-29-05-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6903139067071136a.html](https://www.money.pl/pieniadze/kursy-walut-29-05-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6903139067071136a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 05:04:43+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 29.05.2023. W poniedziałek za jednego dolara (USD) zapłacimy 4,2200 zł. Cena jednego funta szterlinga (GBP) to 5,2138 zł, a franka szwajcarskiego (CHF) 4,6634 zł. Z kolei euro (EUR) możemy zakupić za 4,5302 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 29.05.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-29-05-2023-6903138739133056a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-29-05-2023-6903138739133056a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 05:03:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 29.05.2023. W poniedziałek za jednego dolara (USD) trzeba zapłacić 4.2182 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 29.05.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-29-05-2023-6903138739128960a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-29-05-2023-6903138739128960a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 05:03:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 29.05.2023. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.6616 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 29.05.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-29-05-2023-6903138728553088a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-29-05-2023-6903138728553088a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 05:03:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 29.05.2023. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.5283 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 29.05.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-29-05-2023-6903138728688288a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-29-05-2023-6903138728688288a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 05:03:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 29.05.2023. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.212 zł.

## Kolejny dobry kwartał państwowych spółek. Zyski są liczone w miliardach
 - [https://www.money.pl/gielda/kolejny-dobry-kwartal-panstwowych-spolek-zyski-sa-liczone-w-miliardach-6903136403577504a.html](https://www.money.pl/gielda/kolejny-dobry-kwartal-panstwowych-spolek-zyski-sa-liczone-w-miliardach-6903136403577504a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 04:53:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5410b7fa-8870-40b1-b064-15c999c0a577" width="308" /> Z państwowymi spółkami kolejny kwartał, w którym ich łączny zysk netto przekroczył 10 mld zł. Najmocniej na ten wynik pracował Orlen, który po fuzji z Lotosem i PGNiG działa już jako jedna firma. Wynik naftowego giganta jednak dość mocno "podbił" mechanizm rekompensat cen prądu.

## Ukraina pomimo wojny zainstalowała  więcej turbin wiatrowych niż Anglia
 - [https://www.money.pl/gospodarka/ukraina-pomimo-wojny-zainstalowala-wiecej-turbin-wiatrowych-niz-anglia-6903134710807200a.html](https://www.money.pl/gospodarka/ukraina-pomimo-wojny-zainstalowala-wiecej-turbin-wiatrowych-niz-anglia-6903134710807200a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 04:46:59+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1c8b0e93-c41b-4907-bdae-8c1233c8a042" width="308" /> Ukraina, pomimo wojny,  wzniosła więcej lądowych turbin wiatrowych niż Anglia, choć była obietnica rządu Wielkiej Brytanii, że ten złagodzi ograniczenia dotyczące lądowych farm wiatrowych - donosi "The Guardian".

## Bankructwo techniczne USA. Groźba katastrofy odsunięta?
 - [https://www.money.pl/gospodarka/bankructwo-techniczne-usa-grozba-katastrofy-odsunieta-6903128924224160a.html](https://www.money.pl/gospodarka/bankructwo-techniczne-usa-grozba-katastrofy-odsunieta-6903128924224160a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 04:23:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e058fdf2-837d-4084-a156-2012a04edf18" width="308" /> Prezydent Joe Biden poinformował, że ostatecznie sfinalizował porozumienie budżetowe z spikerem Izby Reprezentantów Kevinem McCarthym. Dodał, że porozumienie w sprawie podwyższenia limitu zadłużenia jest gotowe do przekazania Kongresowi.

## Pierwsze mieszkanie bez podatku. To tysiące złotych oszczędności
 - [https://www.money.pl/gospodarka/pierwsze-mieszkanie-bez-podatku-to-tysiace-zlotych-oszczednosci-6903124198042272a.html](https://www.money.pl/gospodarka/pierwsze-mieszkanie-bez-podatku-to-tysiace-zlotych-oszczednosci-6903124198042272a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 04:04:11+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0e01926f-325d-4378-9d9f-e20a943416ea" width="308" /> Sejm zdecydował, że zniesiony zostanie 2 proc. podatek od czynności cywilnoprawnych (PCC) dla osób kupujących pierwsze mieszkanie na rynku wtórnym. Zmiana ta pozwoli sporo zaoszczędzić kupującym nieruchomość. Teraz przepisy trafią do Senatu.

## Stracili gigantyczne pieniądze. Polacy szykują pozwy przeciwko Szwajcarii
 - [https://www.money.pl/banki/stracili-gigantyczne-pieniadze-polacy-szykuja-pozwy-przeciwko-szwajcarii-6902272509438624a.html](https://www.money.pl/banki/stracili-gigantyczne-pieniadze-polacy-szykuja-pozwy-przeciwko-szwajcarii-6902272509438624a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-29 03:30:06+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c15a1ed3-9824-4a16-b7a7-aaf777ef2af6" width="308" /> Kilku Polaków na przymusowym przejęciu banku Credit Suisse przez UBS straciło łącznie ponad 25 mln zł. Teraz szykują pozwy przeciwko Szwajcarii. Dotarliśmy do kancelarii, która będzie prowadzić ich sprawy. To będzie walka Dawida z Goliatem.

