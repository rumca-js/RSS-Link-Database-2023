# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Oświęcim. Uwiązali i umyli psa chemikaliami na myjni samochodowej. Przestraszone zwierzę próbowało uciec
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29813111,oswiecim-mezczyzna-uwiazal-i-umyl-psa-na-myjni-samochodowej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29813111,oswiecim-mezczyzna-uwiazal-i-umyl-psa-na-myjni-samochodowej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-29 16:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/be/6e/1c/z29813182M.jpg" vspace="2" />Kamery monitoringu zarejestrowały parę, która umyła swojego czworonoga na myjni samochodowej. Na nagraniu widać jak mężczyzna myje psa chemikaliami i oblewa wodą pod silnym ciśnieniem. "Nic mu nie będzie! Do gó**a wszedł, z gó**a musi wyjść!" - mieli tłumaczyć sprawcy.

## Śmierć ciężarnej 33-latki w Nowym Targu. Są wstępne wyniki sekcji zwłok
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29812766,smierc-ciezarnej-33-latki-w-nowym-targu-sa-wstepne-wyniki-sekcji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29812766,smierc-ciezarnej-33-latki-w-nowym-targu-sa-wstepne-wyniki-sekcji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-29 14:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/6e/1c/z29812825M,Podhalanski-Szpital-Specjalistyczny---zdjecie-ilus.jpg" vspace="2" />Podano wstępne ustalenia sekcji zwłok ciężarnej 33-letniej kobiety, która zmarła podczas pobytu w Podhalańskim Szpitalu Specjalistycznym. Zdaniem biegłych do śmierci pacjentki miało dojść za sprawą wstrząsu septycznego. Śledztwo prowadzi prokuratura w Nowym Targu.

## O co chodzi z "lex Tusk"? Ustawa, która wywraca konstytucyjny porządek
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29810457,o-co-chodzi-z-lex-tusk-ustawa-ktora-wywraca-konstytucyjny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29810457,o-co-chodzi-z-lex-tusk-ustawa-ktora-wywraca-konstytucyjny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-29 08:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0b/6d/1c/z29810187M,Andrzej-Duda-wyglosi-oswiadczenie--Zdecyduje-o--le.jpg" vspace="2" />"Lex Tusk", czyli ustawa o powołaniu komisji do spraw wpływów rosyjskich trafiła na biurko Andrzeja Dudy. Nowe prawo może wywrócić konstytucyjny porządek, a przede wszystkim załamać demokratyczny system. Prezydent podjął już decyzję.

## Prognoza pogody. Początek tygodnia pełen słońca i burz. Zagrzmi w kilku województwach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29810152,prognoza-pogody-poczatek-tygodnia-pelen-slonca-i-burz-zagrzmi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29810152,prognoza-pogody-poczatek-tygodnia-pelen-slonca-i-burz-zagrzmi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-29 06:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/44/6d/1c/z29810244M,Burza--zdjecie-ilustracyjne-.jpg" vspace="2" />Miniony weekend w całej Polsce był ciepły i słoneczny. Najbliższe dni przyniosą niewielkie zmiany w pogodzie. Możemy spodziewać się pogodnego nieba, jednak miejscami mogą pojawić się burze i opady deszczu.

## Na granicy polsko-białoruskiej migranci proszą Polskę o azyl. Wśród nich dzieci. "Jak w Usnarzu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29810127,na-granicy-polsko-bialoruskiej-migranci-prosza-polske-o-azyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29810127,na-granicy-polsko-bialoruskiej-migranci-prosza-polske-o-azyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-29 05:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f9/6d/1c/z29809401M.jpg" vspace="2" />25 osób, w tym 11 dzieci, na granicy polsko-białoruskiej prosi o azyl. Na powrót do Białorusi nie pozwalają im tamtejsi strażnicy z psami. Aktywiści Grupy Granica oraz była zastępczyni Rzecznika Praw Obywatelskich dr Hanna Machińska alarmują: "Mamy sytuację taką jak w Usnarzu."

## Kiedy będą wyniki z egzaminu ósmoklasisty? Jakie są zasady rekrutacji do szkół średnich 2023/2024?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29806318,kiedy-beda-wyniki-z-egzaminu-osmoklasisty-jakie-sa-zasady-rekrutacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29806318,kiedy-beda-wyniki-z-egzaminu-osmoklasisty-jakie-sa-zasady-rekrutacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-29 05:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/42/6c/1c/z29806402M,Egzamin-osmoklasisty-w-Warszawie.jpg" vspace="2" />Dla większości uczniów egzaminy ósmoklasisty dobiegły końca, choć część osób podejdzie jeszcze do testów w terminach dodatkowych. Wszyscy zdający otrzymają swoje wyniki na początku lipca. Wtedy też rozpocznie się ważny etap tegorocznej rekrutacji do szkół średnich.

## Sezon na kleszcze trwa. Co je przyciąga? Tych zapachów należy unikać
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29755016,sezon-na-kleszcze-trwa-co-je-przyciaga-tych-zapachow-nalezy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29755016,sezon-na-kleszcze-trwa-co-je-przyciaga-tych-zapachow-nalezy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-29 04:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1f/f3/19/z27209759M,Kleszcz--zdjecie-ilustracyjne-.jpg" vspace="2" />Kleszcze stanowią zagrożenie dla zwierząt i ludzi. Jak się przed nimi uchronić? Są zapachy, które je odstraszają, ale też takie, które ułatwiają jedynie zlokalizowanie "ofiary".

