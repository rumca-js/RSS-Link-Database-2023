# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Strzelanina w autobusie w USA. Kierowca odpowiedział ogniem
 - [https://fakty.tvn24.pl/fakty-o-swiecie/strzelanina-w-autobusie-w-usa-kierowca-odpowiedzial-ogniem-7151197?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/strzelanina-w-autobusie-w-usa-kierowca-odpowiedzial-ogniem-7151197?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 20:36:40+00:00

<img alt="Strzelanina w autobusie w USA. Kierowca odpowiedział ogniem" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-hioq6r-strzelanina-w-autobusie-w-usa-kierowca-odpowiedzial-ogniem-7151161/alternates/LANDSCAPE_1280" />
    Zaczęło się dość spokojnie. Pasażer podszedł do kierowcy autobusu i poprosił o zatrzymanie pojazdu. Kierowca odmówił. Rozmowa zamieniła się w kłótnię. Chwilę później pasażer zrobił krok do tyłu i wyjął broń. Kierowca to samo zrobił ze swoją. Padły strzały, obaj zostali ranni.

## Śmierć 24-letniego rekruta Navy Seals na szkoleniu. Raport wykazał nieprawidłowości
 - [https://fakty.tvn24.pl/fakty-o-swiecie/smierc-24-letniego-rekruta-navy-seals-na-szkoleniu-raport-wykazal-nieprawidlowosci-7151184?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/smierc-24-letniego-rekruta-navy-seals-na-szkoleniu-raport-wykazal-nieprawidlowosci-7151184?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 20:26:11+00:00

<img alt="Śmierć 24-letniego rekruta Navy Seals na szkoleniu. Raport wykazał nieprawidłowości" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-hqlel7-tak-wyglada-tydzien-w-piekle-rekrutow-navy-seals-to-jest-naprawde-bardzo-trudny-okres-7151160/alternates/LANDSCAPE_1280" />
    Okazuje się, że proces trafiania do Navy Seals jest bardzo wadliwy, a elitarni kandydaci pozbawieni są choćby odpowiedniej opieki, gdy coś pójdzie nie tak. Tak wynika z raportu, na który czekała Ameryka.

## Krzysztof to pierwszy maturzysta z kliniki Budzik. Pomogli lekarze, miłość i nadzieja
 - [https://fakty.tvn24.pl/zobacz-fakty/krzysztof-to-pierwszy-maturzysta-z-kliniki-budzik-pomogli-lekarze-milosc-i-nadzieja-7151028?source=rss](https://fakty.tvn24.pl/zobacz-fakty/krzysztof-to-pierwszy-maturzysta-z-kliniki-budzik-pomogli-lekarze-milosc-i-nadzieja-7151028?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 19:39:07+00:00

<img alt="Krzysztof to pierwszy maturzysta z kliniki Budzik. Pomogli lekarze, miłość i nadzieja" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-rruu5u-krzysztof-to-pierwszy-maturzysta-z-kliniki-budzik-pomogli-lekarze-milosc-i-nadzieja-7151107/alternates/LANDSCAPE_1280" />
    Kiedy sześć lat temu Krzysztofa potrącił samochód, nikt nie przypuszczał, że wróci do szkoły, będzie się uczył i będzie chodził po górach. Udało się dzięki determinacji lekarzy, rehabilitantów, nauczycieli i rodziny. Krzysztof to pierwszy maturzysta z kliniki Budzik.

## Ruszyła rejestracja na szczepienia dzieci przeciwko HPV. Obejmie w sumie osiemset tysięcy nastolatków
 - [https://fakty.tvn24.pl/zobacz-fakty/ruszyla-rejestracja-na-szczepienia-dzieci-przeciwko-hpv-obejmie-w-sumie-osiemset-tysiecy-nastolatkow-7151058?source=rss](https://fakty.tvn24.pl/zobacz-fakty/ruszyla-rejestracja-na-szczepienia-dzieci-przeciwko-hpv-obejmie-w-sumie-osiemset-tysiecy-nastolatkow-7151058?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 18:46:26+00:00

<img alt="Ruszyła rejestracja na szczepienia dzieci przeciwko HPV. Obejmie w sumie osiemset tysięcy nastolatków" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-hi0ucf-ruszyla-rejestracja-na-szczepienia-dzieci-przeciwko-hpv-obejmie-w-sumie-osiemset-tysiecy-nastolatkow-7151109/alternates/LANDSCAPE_1280" />
    W sobotę ruszyły zapisy na szczepienie przeciwko HPV dla dziewcząt i chłopców w wieku 12-13 lat. Można zapisać dziecko przez internet, infolinię, a wkrótce także w przychodniach.

## Kolejny atak na Kijów. Wszystkie rosyjskie rakiety zostały zestrzelone
 - [https://fakty.tvn24.pl/najnowsze/kolejny-atak-na-kijow-wszystkie-rosyjskie-rakiety-zostaly-zestrzelone-7151180?source=rss](https://fakty.tvn24.pl/najnowsze/kolejny-atak-na-kijow-wszystkie-rosyjskie-rakiety-zostaly-zestrzelone-7151180?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 18:28:33+00:00

<img alt="Kolejny atak na Kijów. Wszystkie rosyjskie rakiety zostały zestrzelone" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-cqebfo-kolejny-atak-na-kijow-wszystkie-rosyjskie-rakiety-zostaly-zestrzelone-7151110/alternates/LANDSCAPE_1280" />
    Krzyki małych dzieci na ulicach Kijowa, przerażonych atakiem rakietowym - to symbol dzisiejszego dnia. Na Ukrainę leciały rakiety i drony kamikadze. Od początku miesiąca było już 17 takich ataków. Prezydent Zełenski zapowiada, że żaden okupant nie pozostanie na ukraińskiej ziemi.

## Wybory w Turcji. Erdogan wygrywa kolejną kadencję, ale społeczeństwo pozostaje podzielone
 - [https://fakty.tvn24.pl/zobacz-fakty/wybory-w-turcji-erdogan-wygrywa-kolejna-kadencje-ale-spoleczenstwo-pozostaje-podzielone-7151177?source=rss](https://fakty.tvn24.pl/zobacz-fakty/wybory-w-turcji-erdogan-wygrywa-kolejna-kadencje-ale-spoleczenstwo-pozostaje-podzielone-7151177?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 18:24:05+00:00

<img alt="Wybory w Turcji. Erdogan wygrywa kolejną kadencję, ale społeczeństwo pozostaje podzielone" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-dijgr-wybory-w-turcji-erdogan-wygrywa-kolejna-kadencje-ale-spoleczenstwo-pozostaje-podzielone-7151111/alternates/LANDSCAPE_1280" />
    Przewaga nie była przytłaczająca, ale Recep Ergodan może być już pewny, że pozostanie prezydentem Turcji. Miał ponad 52 procent poparcia w drugie turze wyborów. Ich symbolem będą zdjęcia Erdogana rozdającego pieniądze pod lokalem wyborczym.

## Migranci wciąż koczują na polsko-białoruskiej granicy. "Jakim my jesteśmy narodem tak naprawdę?"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/migranci-wciaz-koczuja-na-polsko-bialoruskiej-granicy-jakim-my-jestesmy-narodem-tak-naprawde-7150931?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/migranci-wciaz-koczuja-na-polsko-bialoruskiej-granicy-jakim-my-jestesmy-narodem-tak-naprawde-7150931?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 17:15:41+00:00

<img alt="Migranci wciąż koczują na polsko-białoruskiej granicy. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-qtkiug-migranci-wciaz-koczuja-na-polsko-bialoruskiej-granicy-jakim-my-jestesmy-narodem-tak-naprawde-7150898/alternates/LANDSCAPE_1280" />
    Na polsko-białoruskiej granicy koczuje grupa około 30 migrantów. Proszą o azyl i międzynarodową ochronę. Na miejscu są aktywiści, przyjechali też przedstawiciele Biura Rzecznika Praw Obywatelskich.

## Pogoda na jutro - wtorek, 30.05. Dużo słońca. W jednej części kraju możliwe burze
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-3005-duzo-slonca-w-jednej-czesci-kraju-mozliwe-burze-7150930?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-3005-duzo-slonca-w-jednej-czesci-kraju-mozliwe-burze-7150930?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 17:04:44+00:00

<img alt="Pogoda na jutro - wtorek, 30.05. Dużo słońca. W jednej części kraju możliwe burze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6sqytc-slonecznie-pogodnie-cieplo-wiosna-7131015/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. Wtorek 30.05 upłynie na ogół pod znakiem pogodnej i słonecznej aury. Tylko miejscami przelotnie popada słaby deszcz, niewykluczone są też burze. Termometry pokażą maksymalnie 23 stopnie Celsjusza.

## Jeśli mewa ma do wyboru chipsy, sięga po te, które bardziej smakują człowiekowi
 - [https://tvn24.pl/tvnmeteo/ciekawostki/jesli-mewa-ma-do-wyboru-chipsy-siega-po-te-ktore-bardziej-smakuja-czlowiekowi-7150805?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/jesli-mewa-ma-do-wyboru-chipsy-siega-po-te-ktore-bardziej-smakuja-czlowiekowi-7150805?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 16:49:38+00:00

<img alt="Jeśli mewa ma do wyboru chipsy, sięga po te, które bardziej smakują człowiekowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kbm0e5-mewa-srebrzysta-7150882/alternates/LANDSCAPE_1280" />
    Mewy srebrzyste są ptakami o dużych zdolnościach adaptacyjnych, co pokazuje eksperyment przeprowadzony przez naukowców z University of Sussex. Mając do wyboru chipsy z paczek o różnych kolorach, mewy wybiorą tę paczkę, z której jadł obserwowany przez nie człowiek.

## Wypadki w górach. Nieważne, że jest wiosna. Na wysokościach jest potrzebny sprzęt zimowy
 - [https://fakty.tvn24.pl/fakty-po-poludniu/wypadki-w-gorach-niewazne-ze-jest-wiosna-na-wysokosciach-jest-potrzebny-sprzet-zimowy-7150915?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/wypadki-w-gorach-niewazne-ze-jest-wiosna-na-wysokosciach-jest-potrzebny-sprzet-zimowy-7150915?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 16:36:22+00:00

<img alt="Wypadki w górach. Nieważne, że jest wiosna. Na wysokościach jest potrzebny sprzęt zimowy" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-tpyp0l-sluzby-ostrzegaja-przed-gorskimi-wycieczkami-warunki-sa-typowo-zimowe-7150851/alternates/LANDSCAPE_1280" />
    Końcówka maja wcale nie oznacza, że lato w górach jest na wyciągniecie ręki. Na szlakach leży śnieg i jest niebezpiecznie. Jak bardzo? O tym w miniony weekend na własnej skórze przekonało się w Tatrach kilkunastu turystów. Są ofiary śmiertelne.

## Zmarł 32-latek postrzelony na terenie myjni samochodowej. Prokuratura o zmianie zarzutów
 - [https://tvn24.pl/lodz/lodz-zmarl-32-latek-postrzelony-w-myjni-samochodowej-prokuratura-o-zmianie-zarzutow-dla-podejrzanego-7150935?source=rss](https://tvn24.pl/lodz/lodz-zmarl-32-latek-postrzelony-w-myjni-samochodowej-prokuratura-o-zmianie-zarzutow-dla-podejrzanego-7150935?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 16:20:42+00:00

<img alt="Zmarł 32-latek postrzelony na terenie myjni samochodowej. Prokuratura o zmianie zarzutów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lb766o-policja-i-prokuratura-badaja-co-stalo-sie-na-myjni-w-lodzi-7137029/alternates/LANDSCAPE_1280" />
    Jak poinformował rzecznik łódzkiej prokuratury okręgowej Krzysztof Kopania, 32-latek postrzelony na terenie myjni samochodowej w Łodzi zmarł w poniedziałek w szpitalu. Do tej pory zatrzymano sześć osób. Przedstawiono im zarzuty udziału w bójce z użyciem niebezpiecznych narzędzi. Jeden z mężczyzn dodatkowo usłyszał zarzut usiłowania zabójstwa, ale jak zapowiada prokuratura, w związku ze śmiercią 32-letniego mężczyzny dojdzie do zmiany kwalifikacji czynu.

## Protestowali przed MON, ale minister do nich nie wyszedł. Zielone miasteczko i zapowiedź protestu "do skutku"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-protest-przed-mon-postulaty-7150894?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-protest-przed-mon-postulaty-7150894?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 16:15:18+00:00

<img alt="Protestowali przed MON, ale minister do nich nie wyszedł. Zielone miasteczko i zapowiedź protestu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lzajeg-pikieta-przed-mon-7150888/alternates/LANDSCAPE_1280" />
    Cywile w armii chcą więcej zarabiać. Pracownicy resortu obrony narodowej protestowali w Warszawie. Walczą o podwyżki, bo, jak mówią, od lat ich nie było, a płace mają najniższe w całej budżetówce. Liczą na rozmowy z kierownictwem ministerstwa, liczą też na konkrety. Chcą protestować do skutku.

## Lex Tusk. Mueller przekonuje: do czasu decyzji sądu dana osoba będzie mogła dalej pełnić swoją funkcję
 - [https://tvn24.pl/polska/lex-tuskpiotr-mueller-rzecznik-rzadu-o-przepisach-ustawy-powolujacej-komisje-i-o-kontroli-sadowej-wydawanych-decyzji-7150689?source=rss](https://tvn24.pl/polska/lex-tuskpiotr-mueller-rzecznik-rzadu-o-przepisach-ustawy-powolujacej-komisje-i-o-kontroli-sadowej-wydawanych-decyzji-7150689?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 16:13:47+00:00

<img alt="Lex Tusk. Mueller przekonuje: do czasu decyzji sądu dana osoba będzie mogła dalej pełnić swoją funkcję" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hj1grt-piotr-mueller-7150781/alternates/LANDSCAPE_1280" />
    Piotr Mueller, rzecznik rządu, odniósł się na konferencji prasowej do ustawy "lex Tusk". Stwierdził, że "jeżeli komisja podejmie decyzję dotyczącą tak zwanych środków zaradczych lub podejmie decyzję dotyczące odebrania uprawnień, to jest zaskarżenie do sądu". - W związku z tym do czasu rozstrzygnięcia sądowego ta osoba będzie dalej pełniła swoją funkcję - dodał. Eksperci zwracają jednak uwagę, że kontrola sądowa to iluzja: sąd nie będzie mógł ocenić, czy ktoś działał pod wpływem rosyjskim.

## Dwie osoby ranne po wybuchu paniki w kawiarni. Powodem okazał się karaluch
 - [https://tvn24.pl/swiat/tel-awiw-dwie-osoby-ranne-po-wybuchu-paniki-w-kawiarni-powodem-okazal-sie-karaluch-7150759?source=rss](https://tvn24.pl/swiat/tel-awiw-dwie-osoby-ranne-po-wybuchu-paniki-w-kawiarni-powodem-okazal-sie-karaluch-7150759?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 15:28:48+00:00

<img alt="Dwie osoby ranne po wybuchu paniki w kawiarni. Powodem okazał się karaluch" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wrmda2-ulica-dizengoffa-w-tel-awiwie-7150812/alternates/LANDSCAPE_1280" />
    Krzyk jednej z klientek Dizengoff Cafe w Tel Awiwie wywołał panikę wśród gości obecnych w kawiarni. Ludzie rzucili się do wyjścia w obawie, że nastąpił atak terrorystyczny. Jak się później okazało, powodem reakcji kobiety był karaluch. W wyniku incydentu dwie osoby zostały ranne.

## Próbował przewieźć przez granicę kurtkę ze skóry pytona
 - [https://tvn24.pl/krakow/medyka-ukrainiec-probowal-przewiezc-przez-granice-kurtke-ze-skory-pytona-7150704?source=rss](https://tvn24.pl/krakow/medyka-ukrainiec-probowal-przewiezc-przez-granice-kurtke-ze-skory-pytona-7150704?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 15:27:34+00:00

<img alt="Próbował przewieźć przez granicę kurtkę ze skóry pytona" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d3jdcr-ukrainiec-probowal-przewiezc-przez-granice-kurtke-ze-skory-pytona-7150765/alternates/LANDSCAPE_1280" />
    Kurtkę ze skóry pytona wykryli funkcjonariusze Służby Celno-Skarbowej podczas kontroli na polsko-ukraińskim przejściu granicznym w Medyce (woj. podkarpackie). Służby przypominają, że przewóz przez granicę chronionych okazów i wykonanych z nich wyrobów jest przestępstwem.

## "Lex Tusk" - zagraniczne media o decyzji prezydenta. "Przykład tego, jak Prawo i Sprawiedliwość wykorzystuje prawo do swoich celów"
 - [https://tvn24.pl/polska/lex-tusk-zagraniczne-media-o-decyzji-prezydenta-andrzeja-dudy-piszaopolsce-7150855?source=rss](https://tvn24.pl/polska/lex-tusk-zagraniczne-media-o-decyzji-prezydenta-andrzeja-dudy-piszaopolsce-7150855?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 15:26:21+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2x5rvy-piszaopolsce-7150866/alternates/LANDSCAPE_1280" />
    Prezydent Andrzej Duda zapowiedział podpisanie ustawy "lex Tusk". Amerykański dziennik "Washington Post" przytoczył opinie krytyków ustawy, których zdaniem jest ona "jasnym przykładem tego, jak Prawo i Sprawiedliwość wykorzystuje prawo do swoich celów od czasu dojścia do władzy w 2015 roku". Gazeta dodaje, że powołanie komisji może pogłębić konflikt między polskim rządem a Unią Europejską. Zagraniczne media #PisząoPolsce.

## Byli pijani i żądali wpuszczenia na koncert za darmo. W plecaku jednego z nich biały proszek, waga i woreczki
 - [https://tvn24.pl/najnowsze/sopot-pijani-mezczyzni-zadali-wpuszczenia-na-impreze-za-darmo-w-plecaku-jednego-z-nich-bialy-proszek-waga-i-woreczki-7150696?source=rss](https://tvn24.pl/najnowsze/sopot-pijani-mezczyzni-zadali-wpuszczenia-na-impreze-za-darmo-w-plecaku-jednego-z-nich-bialy-proszek-waga-i-woreczki-7150696?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 15:16:47+00:00

<img alt="Byli pijani i żądali wpuszczenia na koncert za darmo. W plecaku jednego z nich biały proszek, waga i woreczki" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-brh210-amfetamina-zdjecie-ilustracyjne-6352643/alternates/LANDSCAPE_1280" />
    Najpierw wulgarnie awanturowali się przed wejściem na jedną z imprez w Sopocie. Twierdzili, że wejście powinno być za darmo i byli niezadowoleni, że ochrona lokalu ma inne zdanie. Wzbudzili zainteresowanie przechodzących obok policjantów i tak zaczęły się ich problemy.

## Potrącili policjanta i zaczęli uciekać autostradą, taranując punkt poboru opłat. Ich auto dachowało
 - [https://tvn24.pl/katowice/slaskie-potracili-policjanta-i-zaczeli-uciekac-autostrada-taranujac-punkt-poboru-oplat-ich-auto-dachowalo-7150754?source=rss](https://tvn24.pl/katowice/slaskie-potracili-policjanta-i-zaczeli-uciekac-autostrada-taranujac-punkt-poboru-oplat-ich-auto-dachowalo-7150754?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 15:06:37+00:00

<img alt="Potrącili policjanta i zaczęli uciekać autostradą, taranując punkt poboru opłat. Ich auto dachowało" src="https://tvn24.pl/najnowsze/cdn-zdjecie-30dirw-kierowca-stracil-panowanie-nad-pojazdem-i-dachowal-7150747/alternates/LANDSCAPE_1280" />
    Do dziesięciu lat więzienia grozi dwóm mężczyznom, którzy uciekali przed policją na autostradzie A4 w województwie śląskim. W trakcie pościgu, jadąc z dużą prędkością, staranowali szlaban punktu poboru opłat. Wcześniej zdążyli jeszcze potrącić policjanta. Ostatecznie pościg zakończył się w Mysłowicach, gdzie kierowca stracił panowanie nad pędzącym mercedesem, w wyniku czego dachował.

## "Wykorzystywanie seksualne" na planie słynnego filmu? Jest decyzja sądu
 - [https://tvn24.pl/kultura-i-styl/hollywood-wykorzystywanie-seksualne-na-planie-romea-i-julii-jest-decyzja-sadu-7150593?source=rss](https://tvn24.pl/kultura-i-styl/hollywood-wykorzystywanie-seksualne-na-planie-romea-i-julii-jest-decyzja-sadu-7150593?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 15:06:28+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fs56hg-olivia-hussey-i-leonard-whiting-z-rezyserem-franco-zeffirellim-na-planie-romea-i-julii-6592190/alternates/LANDSCAPE_1280" />
    Sędzia Sądu Najwyższego w Los Angeles zapowiedziała oddalenie pozwu przeciwko wytwórni filmowej Paramount Pictures, wniesionego w grudniu ubiegłego roku przez Olivię Hussey i Leonarda Whitinga. Aktorzy oskarżyli wytwórnię twierdząc, że zostali "wykorzystani seksualnie" podczas pracy nad filmem "Romeo i Julia".

## Przebywały w pełnym słońcu, bez wody. Strażnicy zatrzymali mężczyznę dręczącego sowy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-starowka-straznicy-zatrzymali-mezczyzne-dreczacego-sowy-7150644?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-starowka-straznicy-zatrzymali-mezczyzne-dreczacego-sowy-7150644?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 14:53:41+00:00

<img alt="Przebywały w pełnym słońcu, bez wody. Strażnicy zatrzymali mężczyznę dręczącego sowy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-aduus4-dreczyl-sowy-zostal-zatrzymany-7150642/alternates/LANDSCAPE_1280" />
    Strażnicy miejscy patrolujący warszawską Starówkę odebrali dwie sowy mężczyźnie, który zarabiał na tym, że pozwalał turystom na zrobienie sobie z nimi zdjęć. Właściciel nie dbał o ptaki. Jedno ze zwierząt posiadał bez zezwolenia.

## Uratowali kacze pisklęta, które wpadły do studzienki. "Całe i zdrowe trafiły pod skrzydła mamy"
 - [https://tvn24.pl/pomorze/olecko-uratowali-kacze-piskleta-ktore-wpadly-do-studzienki-cale-i-zdrowe-trafily-pod-skrzydla-mamy-7150515?source=rss](https://tvn24.pl/pomorze/olecko-uratowali-kacze-piskleta-ktore-wpadly-do-studzienki-cale-i-zdrowe-trafily-pod-skrzydla-mamy-7150515?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 14:48:14+00:00

<img alt="Uratowali kacze pisklęta, które wpadły do studzienki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lifr2s-policjanci-z-olecka-uratowali-kaczatka-uwiezione-w-studzience-kanalizacyjnej-7150503/alternates/LANDSCAPE_1280" />
    Kacze pisklęta wpadły do studzienki kanalizacyjnej przy ul. Zamkowej w Olecku (woj. warmińsko-mazurskie). Z pomocą ruszyli im policjanci. Kaczątka całe i zdrowe trafiły pod skrzydła swojej matki.

## Dziwny zapach moczu po zjedzeniu szparagów. Skąd się bierze?
 - [https://tvn24.pl/tvnmeteo/ciekawostki/dziwny-zapach-moczu-po-zjedzeniu-szparagow-dziwny-zapach-moczu-po-szparagach-skad-sie-bierze-7150707?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/dziwny-zapach-moczu-po-zjedzeniu-szparagow-dziwny-zapach-moczu-po-szparagach-skad-sie-bierze-7150707?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 14:34:49+00:00

<img alt="Dziwny zapach moczu po zjedzeniu szparagów. Skąd się bierze? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-btxx23-szparagi-7150782/alternates/LANDSCAPE_1280" />
    Sezon na szparagi trwa w najlepsze. Zjedzenie tych bogatych w witaminy warzyw powoduje, że mocz części ludzi ma charakterystyczny, mocno kapuściany zapach. Naukowczyni z Instytutu Rozrodu Zwierząt i Badań Żywności Polskiej Akademii Nauk w Olsztynie tłumaczy, czym jest on spowodowany.

## Ratusz skarży decyzję wojewody w sprawie strefy parkowania. Bocheński: nie uznajemy tej skargi
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ratusz-skarzy-decyzje-wojewody-w-sprawie-strefy-parkowania-bochenski-nie-uznajemy-tej-skargi-7150721?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ratusz-skarzy-decyzje-wojewody-w-sprawie-strefy-parkowania-bochenski-nie-uznajemy-tej-skargi-7150721?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 14:26:51+00:00

<img alt="Ratusz skarży decyzję wojewody w sprawie strefy parkowania. Bocheński: nie uznajemy tej skargi" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c8b6yd-strefa-platnego-parkowania-niestrzezonego-zdjecie-ilustracyjne-5017581/alternates/LANDSCAPE_1280" />
    Wojewoda mazowiecki Tobiasz Bocheński poinformował, że nie uznaje skargi złożonej przez ratusz do Wojewódzkiego Sądu Administracyjnego na rozstrzygnięcie stwierdzające nieważność uchwały wprowadzającej strefę płatnego parkowania na Saskiej Kępie i Kamionku. - Została przygotowana błędnie i zawiera braki legislacyjne - stwierdził.

## Przechodził z rowerem przez przejazd kolejowy. Potrącił go pociąg
 - [https://tvn24.pl/krakow/sosnica-przechodzil-z-rowerem-przez-przejazd-kolejowy-potracil-go-pociag-7150710?source=rss](https://tvn24.pl/krakow/sosnica-przechodzil-z-rowerem-przez-przejazd-kolejowy-potracil-go-pociag-7150710?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 14:17:52+00:00

<img alt="Przechodził z rowerem przez przejazd kolejowy. Potrącił go pociąg" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mndjij-mezczyzna-ktory-prowadzil-rower-zostal-potracony-przez-pociag-7150713/alternates/LANDSCAPE_1280" />
    Policja ustala okoliczności wypadku oraz tożsamość mężczyzny, który prowadząc rower przez przejazd kolejowy w Sośnicy (woj. podkarpackie), został śmiertelnie potrącony przez pociąg pospieszny Warszawa-Przemyśl. Zginął na miejscu.

## Pijana kobieta wjechała autem w miejski autobus
 - [https://tvn24.pl/pomorze/pijana-kobieta-wjechala-autem-w-miejski-autobus-7150433?source=rss](https://tvn24.pl/pomorze/pijana-kobieta-wjechala-autem-w-miejski-autobus-7150433?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 14:03:48+00:00

<img alt="Pijana kobieta wjechała autem w miejski autobus" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5xaofq-gdansk-pijana-wjechala-w-autobus-7150447/alternates/LANDSCAPE_1280" />
    Tylko w ubiegły weekend gdańska policja zatrzymała czworo kierowców jadących pod wpływem alkoholu. Jedną z nich była kobieta, która uderzyła w miejski autobus. Wszystkim zatrzymano prawo jazdy.

## Dzwonił kilka razy, podawał się za policjanta. Seniorka straciła 167 tysięcy złotych
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-bielany-seniorka-oszukana-metoda-na-policjanta-apel-policji-7150653?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-bielany-seniorka-oszukana-metoda-na-policjanta-apel-policji-7150653?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 13:48:45+00:00

<img alt="Dzwonił kilka razy, podawał się za policjanta. Seniorka straciła 167 tysięcy złotych" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecied41d8cd98f00b204e9800998ecf8427e-oszusci-wciaz-wyludzaja-pieniadze-metoda-na-policjanta-czy-na-wnuczka-5364389/alternates/LANDSCAPE_1280" />
    Kolejna seniorka straciła oszczędności, ponieważ odebrała telefon od fałszywego policjanta. 89-latka chcąc "ratować siostrę", oddała oszustom 167 tysięcy złotych.

## Zachowajcie szczególną ostrożność, będąc w lesie. We wtorek miejscami "ekstremalnie" groźnie
 - [https://tvn24.pl/tvnmeteo/polska/zagrozenie-pozarowe-w-polsce-w-czesci-kraju-moze-byc-nawet-ekstremalne-7150664?source=rss](https://tvn24.pl/tvnmeteo/polska/zagrozenie-pozarowe-w-polsce-w-czesci-kraju-moze-byc-nawet-ekstremalne-7150664?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 13:31:03+00:00

<img alt="Zachowajcie szczególną ostrożność, będąc w lesie. We wtorek miejscami " src="https://tvn24.pl/najnowsze/cdn-zdjecie-98mshq-pozary-lasow-5636412/alternates/LANDSCAPE_1280" />
    Pogodna aura sprawia, że w lasach wzrasta zagrożenie pożarowe. Uważajmy, aby podczas spacerów nie zaprószyć przypadkowo ognia. Z prognozy Instytutu Meteorologii i Gospodarki Wodnej wynika, że we wtorek po południu miejscami zagrożenie pożarowe może być ekstremalne.

## 12 500 mil morskiej żeglugi. Dar Młodzieży przejdzie przez równik i weźmie udział w regatach
 - [https://tvn24.pl/pomorze/gdynia-12500-mil-morskiej-zeglugi-dar-mlodziezy-wyruszyl-w-polroczny-rejs-7150372?source=rss](https://tvn24.pl/pomorze/gdynia-12500-mil-morskiej-zeglugi-dar-mlodziezy-wyruszyl-w-polroczny-rejs-7150372?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 13:27:18+00:00

<img alt="12 500 mil morskiej żeglugi. Dar Młodzieży przejdzie przez równik i weźmie udział w regatach" src="https://tvn24.pl/pomorze/cdn-zdjecie-i0c038-dar-mlodziezy-wyplynal-w-polroczny-rejs-przejdzie-przez-rownik-i-wezmie-udzial-w-regatach-7150445/alternates/LANDSCAPE_1280" />
    Dar Młodzieży, żaglowiec Uniwersytetu Morskiego w Gdyni, wypłynął w niemal półroczny rejs. Ma pokonać około 12 tysięcy 500 mil morskich. W trakcie swojej podróży zawita do licznych portów, weźmie udział w regatach i przepłynie równik.

## Pociągiem nad Zalew Zegrzyński. Dojadą tam dwie linie SKM
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-pociagiem-nad-zalew-zegrzynski-dojada-tam-dwie-linie-skm-7150337?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-pociagiem-nad-zalew-zegrzynski-dojada-tam-dwie-linie-skm-7150337?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 13:04:05+00:00

<img alt="Pociągiem nad Zalew Zegrzyński. Dojadą tam dwie linie SKM" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-97zs6q-pociag-skm-na-trasie-zdjecie-ilustracyjne-7150584/alternates/LANDSCAPE_1280" />
    W najbliższy weekend rozpocznie kursowanie linia S3 z lotniska Chopina, przez Nieporęt, do Radzymina.  Z kolei od niedzieli, 11 czerwca, pociągi SKM, kursujące od strony Legionowa i Wieliszewa, będą mogły dojechać aż do Zegrza Południowego.

## Wyż Wiola przynosi słońce i ciepło, ale na horyzoncie widać ochłodzenie. Pogoda na 5 dni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-pogoda-na-piec-dni-wyz-wiola-sloneczna-aura-czeka-nas-wzrost-temperatury-7150532?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-pogoda-na-piec-dni-wyz-wiola-sloneczna-aura-czeka-nas-wzrost-temperatury-7150532?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 13:01:59+00:00

<img alt="Wyż Wiola przynosi słońce i ciepło, ale na horyzoncie widać ochłodzenie. Pogoda na 5 dni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8noat6-pogodnie-slonecznie-7150640/alternates/LANDSCAPE_1280" />
    Wyż Wiola będzie kształtował aurę w Polsce i sprawi, że czekają nas pogodne dni. W czwartek temperatura wzrośnie miejscami do 26 stopni Celsjusza. Tylko lokalnie może się chmurzyć, niewykluczone są też burze.

## Rowerem na rondzie pod prąd, po zjeździe zderzył się z autem. Nagranie
 - [https://tvn24.pl/bialystok/lukow-byl-pijany-jechal-rowerem-na-rondzie-pod-prad-zderzyl-sie-autem-nagranie-7150367?source=rss](https://tvn24.pl/bialystok/lukow-byl-pijany-jechal-rowerem-na-rondzie-pod-prad-zderzyl-sie-autem-nagranie-7150367?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 12:13:48+00:00

<img alt="Rowerem na rondzie pod prąd, po zjeździe zderzył się z autem. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u29mts-rowerem-na-rondzie-pod-prad-7150559/alternates/LANDSCAPE_1280" />
    Policja zatrzymała 27-letniego rowerzystę, który na rondzie w Łukowie (woj. lubelskie) jechał pod prąd i zderzył się z autem. A później odjechał z miejsca kolizji. Okazało się, że miał w organizmie ponad dwa promile alkoholu i był poszukiwany do odbycia kary aresztu za niezapłaconą grzywnę.

## W Łodzi zapadła się jezdnia. Tuż obok stały zaparkowane auta
 - [https://tvn24.pl/lodz/lodz-zapadla-sie-jezdnia-doszlo-do-awarii-przylacza-kanalizacyjnego-7150438?source=rss](https://tvn24.pl/lodz/lodz-zapadla-sie-jezdnia-doszlo-do-awarii-przylacza-kanalizacyjnego-7150438?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 12:01:32+00:00

<img alt="W Łodzi zapadła się jezdnia. Tuż obok stały zaparkowane auta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q34dtw-na-ulicy-zapadl-sie-sporych-rozmiarow-fragment-jezdni-7150410/alternates/LANDSCAPE_1280" />
    Zapadł się fragment ulicy Praskiej w Łodzi. Wyrwa powstała obok zaparkowanych samochodów. Powodem może być podmycie gruntu spowodowane awarią wodociągową. Naprawa - jak informuje Zakład Wodociągów i Kanalizacji - ma potrwać do końca tygodnia. Konieczne będzie między innymi wykopanie czterometrowej dziury.

## Atak na dostawcę pizzy w Lublinie. Jeden z napastników został zatrzymany, policja szuka drugiego
 - [https://tvn24.pl/bialystok/lublin-atak-na-dostawce-pizzy-jeden-z-napastnikow-zostal-zatrzymany-policja-szuka-drugiego-7150186?source=rss](https://tvn24.pl/bialystok/lublin-atak-na-dostawce-pizzy-jeden-z-napastnikow-zostal-zatrzymany-policja-szuka-drugiego-7150186?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 11:35:55+00:00

<img alt="Atak na dostawcę pizzy w Lublinie. Jeden z napastników został zatrzymany, policja szuka drugiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vworml-policja-zatrzymala-39-latka-7150222/alternates/LANDSCAPE_1280" />
    39-latek miał przy jednym ze sklepów w Lublinie zaatakować i pobić dostawcę pizzy, 37-letniego obywatela Nigerii. Policja informuje, że 39-latek wsiadał do jego auta i zażądał, żeby ten go podwiózł, a gdy Nigeryjczyk odmówił, mężczyzna stał się agresywny. Mundurowi mają informacje o jeszcze jednym uczestniku pobicia. Trwa ustalanie jego personaliów.

## Zaginiony aktor nie żyje. Jego zwłoki znaleziono w drewnianym kufrze
 - [https://tvn24.pl/kultura-i-styl/brazylia-zaginiony-aktor-jeff-machado-nie-zyje-jego-zwloki-znaleziono-w-drewnianym-kufrze-7150202?source=rss](https://tvn24.pl/kultura-i-styl/brazylia-zaginiony-aktor-jeff-machado-nie-zyje-jego-zwloki-znaleziono-w-drewnianym-kufrze-7150202?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 11:35:42+00:00

<img alt="Zaginiony aktor nie żyje. Jego zwłoki znaleziono w drewnianym kufrze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c2dre1-zwloki-jeffa-machado-znaleziono-w-dzielnicy-campo-grande-w-rio-de-janeiro-7150289/alternates/LANDSCAPE_1280" />
    Aktor Jeff Machado był poszukiwany od 27 stycznia. O odnalezieniu jego ciała poinformował w czwartek prawnik rodziny. Zwłoki 44-letniego Brazylijczyka zostały wepchnięte do drewnianego kufra, a następnie zakopane na terenie posesji w dzielnicy Campo Grande w Rio de Janeiro. O zamordowanie mężczyzny śledczy podejrzewają jego znajomego.

## Tajfun Mawar wciąż sieje niepokój. Ostrzeżenia na Filipinach
 - [https://tvn24.pl/tvnmeteo/swiat/tajfun-mawar-wciaz-sieje-niepokoj-ostrzezenia-na-filipinach-7150351?source=rss](https://tvn24.pl/tvnmeteo/swiat/tajfun-mawar-wciaz-sieje-niepokoj-ostrzezenia-na-filipinach-7150351?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 11:33:57+00:00

<img alt="Tajfun Mawar wciąż sieje niepokój. Ostrzeżenia na Filipinach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-78vopu-tajfun-mawar-na-zdjeciach-satelitarnych-7150307/alternates/LANDSCAPE_1280" />
    Tajfun Mawar, który w ubiegłym tygodniu przeszedł przez Guam, nadciąga teraz nad Filipiny. Wydano już alerty meteorologiczne i nakazy ewakuacji, miejscami nie odbywają się lekcje, a biura są puste. Sytuacja jest bardzo dynamiczna.

## Albańczyk podawał się za Hiszpana. Zamiast  do Czarnogóry, chciał polecieć do Kanady
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-na-podrobionych-dokumentach-chcial-poleciec-do-kanady-7150075?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-na-podrobionych-dokumentach-chcial-poleciec-do-kanady-7150075?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 11:33:16+00:00

<img alt="Albańczyk podawał się za Hiszpana. Zamiast  do Czarnogóry, chciał polecieć do Kanady " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-m4zm52-na-podrobionych-dokumentach-chcial-poleciec-do-kanady-zdjecie-ilustracyjne-7150265/alternates/LANDSCAPE_1280" />
    Na Lotnisku Chopina strażnicy graniczni zatrzymali 29-letniego Albańczyka, który - posługując się podrobionymi dokumentami - próbował przedostać się do samolotu lecącego do Toronto.

## Wjechał w bok autobusu, ten uderzył w drzewo. Zginęły cztery osoby, jest wyrok
 - [https://tvn24.pl/pomorze/mierzyno-gdansk-wjechal-w-bok-autobusu-ten-uderzyl-w-drzewo-zginely-cztery-osoby-jest-wyrok-7150187?source=rss](https://tvn24.pl/pomorze/mierzyno-gdansk-wjechal-w-bok-autobusu-ten-uderzyl-w-drzewo-zginely-cztery-osoby-jest-wyrok-7150187?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 11:28:16+00:00

<img alt="Wjechał w bok autobusu, ten uderzył w drzewo. Zginęły cztery osoby, jest wyrok" src="https://tvn24.pl/lodz/cdn-zdjecie-7yggsu-straz-pozarna-trzy-osoby-zginely-trzy-inne-w-bardzo-ciezkim-stanie-4637731/alternates/LANDSCAPE_1280" />
    Sąd Okręgowy w Gdańsku skazał 23-letniego Przemysława P. za spowodowanie wypadku, w którym zginęły cztery osoby. Do zdarzenia doszło w lipcu 2020 roku w Mierzynie (woj. pomorskie). Wyrok nie jest prawomocny.

## Solidarność ma uwagi do 14. emerytur. "Może być wykorzystywane jako narzędzie polityczne"
 - [https://tvn24.pl/biznes/dla-seniora/czternasta-emerytura-nszz-solidarnosc-z-uwagami-do-rzadowego-projektu-w-sprawie-14-emerytur-7150184?source=rss](https://tvn24.pl/biznes/dla-seniora/czternasta-emerytura-nszz-solidarnosc-z-uwagami-do-rzadowego-projektu-w-sprawie-14-emerytur-7150184?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 11:07:57+00:00

<img alt="Solidarność ma uwagi do 14. emerytur. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-lh7q9s-posiedzenie-rzadu-16052023-7130324/alternates/LANDSCAPE_1280" />
    Tak zwana czternasta emerytura ma być wypłacana co roku. Ustawa w tej sprawie została uchwalona w Sejmie. Uwagi do rządowego projektu ma Prezydium Komisji Krajowej NSZZ "Solidarność". W ocenie związkowców, przepisy w proponowanym kształcie mogą prowadzić do wykorzystywania tak zwanych 14. emerytur przez rząd jako narzędzia politycznego. Z oburzeniem stwierdzono też, że projekt nie przeszedł ustawowego trybu konsultacji społecznych.

## Chcieli przemycić części luksusowych samochodów. Wpadli na granicy
 - [https://tvn24.pl/krakow/korczowa-na-granicy-przechwycono-kolejne-czesci-ze-skradzionych-luksusowych-aut-7149879?source=rss](https://tvn24.pl/krakow/korczowa-na-granicy-przechwycono-kolejne-czesci-ze-skradzionych-luksusowych-aut-7149879?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 10:55:21+00:00

<img alt="Chcieli przemycić części luksusowych samochodów. Wpadli na granicy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3sy8nl-na-granicy-w-korczowej-straz-graniczna-przechwycila-kolejne-czesci-ze-skradzionych-luksusowych-aut-7149934/alternates/LANDSCAPE_1280" />
    Kolejną próbę wywozu do Ukrainy części pochodzących z luksusowych aut skradzionych w Niemczech, udaremnili strażnicy graniczni z przejścia w Korczowej (woj. podkarpackie). Szacunkowa wartość odzyskanego mienia to około 150 tysięcy złotych.

## W zderzeniu dwóch samochodów zginął 21-latek
 - [https://tvn24.pl/lodz/leszcze-stracil-panowanie-nad-samochodem-i-zderzyl-sie-z-innym-pojazdem-nie-zyje-21-latek-7150196?source=rss](https://tvn24.pl/lodz/leszcze-stracil-panowanie-nad-samochodem-i-zderzyl-sie-z-innym-pojazdem-nie-zyje-21-latek-7150196?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 10:39:45+00:00

<img alt="W zderzeniu dwóch samochodów zginął 21-latek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4n6gk0-zderzenie-dwoch-samochodow-nie-zyje-21-latek-7148942/alternates/LANDSCAPE_1280" />
    Policja pod nadzorem prokuratury w Łęczycy (woj. łódzkie) wyjaśnia okoliczności śmiertelnego wypadku na drodze wojewódzkiej 703 w miejscowości Leszcze. Na łuku drogi doszło do zderzenia dwóch samochodów osobowych. Na miejscu zginął 21-letni kierowca jednego z pojazdów.

## Służby w akcji, neutralizują złote algi w wodach Kanału Gliwickiego. "Konieczne dla podjęcia dalszych działań zaradczych"
 - [https://tvn24.pl/katowice/kanal-gliwicki-sluzby-w-akcji-neutralizuja-zlote-algi-konieczne-dla-podjecia-dalszych-dzialan-zaradczych-7150125?source=rss](https://tvn24.pl/katowice/kanal-gliwicki-sluzby-w-akcji-neutralizuja-zlote-algi-konieczne-dla-podjecia-dalszych-dzialan-zaradczych-7150125?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 10:38:38+00:00

<img alt="Służby w akcji, neutralizują złote algi w wodach Kanału Gliwickiego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-d5t1gd-dzialania-sluzb-przy-kanale-gliwickim-7150234/alternates/LANDSCAPE_1280" />
    Żołnierze, strażacy i przedstawiciele służb wojewody opolskiego pracują w poniedziałek przy Kanale Gliwickim. "Zgodnie z zapowiedzią rozpoczynamy neutralizację złotej algi na Kanale Gliwickim" - poinformowała w mediach społecznościowych Anna Moskwa, minister klimatu i środowiska. Pobrane z wody próbki zostaną zbadane w laboratorium. Wyniki mają być znane w ciągu dwóch tygodni.

## Jazda przez szalejącą pożogę. Wprowadzono stan wyjątkowy
 - [https://tvn24.pl/tvnmeteo/swiat/kanada-nowa-szkocja-pozary-szaleja-wprowadzono-stan-wyjatkowy-7150149?source=rss](https://tvn24.pl/tvnmeteo/swiat/kanada-nowa-szkocja-pozary-szaleja-wprowadzono-stan-wyjatkowy-7150149?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 10:36:31+00:00

<img alt="Jazda przez szalejącą pożogę. Wprowadzono stan wyjątkowy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dfmyzx-rozlegle-pozary-w-kanadzie-7150053/alternates/LANDSCAPE_1280" />
    Kolejna kanadyjska prowincja - Nowa Szkocja - zmaga się z rozległymi pożarami. W weekend płomienie rozprzestrzeniły się jeszcze bardziej i ogarnęły już ponad 1,3 tysiąca hektarów terenu. Trwa walka z żywiołem, władze podjęły decyzję o wprowadzeniu stanu wyjątkowego. To, jak niebezpieczna jest sytuacja, widać na nagraniach.

## "Wracam do bezpiecznego świata". Martyna Wojciechowska o zdjęciach w Ukrainie
 - [https://tvn24.pl/kultura-i-styl/kobieta-na-krancu-swiata-tvn-martyna-wojciechowska-o-odcinku-w-ukrainie-7148975?source=rss](https://tvn24.pl/kultura-i-styl/kobieta-na-krancu-swiata-tvn-martyna-wojciechowska-o-odcinku-w-ukrainie-7148975?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 10:22:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o38rvu-martyna-ukraina-7148834/alternates/LANDSCAPE_1280" />
    Martyna Wojciechowska wróciła z Ukrainy, gdzie nagrywała kolejny odcinek "Kobiety na krańcu świata". "Czasem warto, żebyśmy sobie przypomnieli, jakim przywilejem jest własny dach nad głową, czysta pościel, prysznic, jajko na miękko na śniadanie. A przede wszystkim wolność i bezpieczeństwo" - napisała dziennikarka na Instagramie.

## Wypadł z drogi, uderzył w przepust i dachował. Chwilę później stanął w płomieniach
 - [https://tvn24.pl/bialystok/sitaniec-wolica-zjechal-z-drogi-i-stanal-w-plomieniach-kierowca-wydmuchal-ponad-dwa-promile-7148988?source=rss](https://tvn24.pl/bialystok/sitaniec-wolica-zjechal-z-drogi-i-stanal-w-plomieniach-kierowca-wydmuchal-ponad-dwa-promile-7148988?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 09:35:27+00:00

<img alt="Wypadł z drogi, uderzył w przepust i dachował. Chwilę później stanął w płomieniach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-25qga5-kierowca-mial-ponad-dwa-promile-alkoholu-w-organizmie-7148989/alternates/LANDSCAPE_1280" />
    Ponad dwa promile alkoholu miał w organizmie 52-latek, który w miejscowości Sitaniec Wolica wypadł z drogi, uderzył w betonowy przepust i dachował. Samochód stanął w płomieniach, kierowca zdołał o własnych siłach opuścić auto. Alkomat wykazał, że jest kompletnie pijany. Za kółko wsiadł pomimo sądowego zakazu, który został orzeczony za jazdę pod wpływem alkoholu.

## Kierowca miał ponad trzy promile, pasażer o promil więcej. Jechali motorowerem
 - [https://tvn24.pl/poznan/tarnow-jezierny-nowa-sol-kierowca-mial-ponad-trzy-promile-pasazer-o-promil-wiecej-jechali-motorowerem-7148840?source=rss](https://tvn24.pl/poznan/tarnow-jezierny-nowa-sol-kierowca-mial-ponad-trzy-promile-pasazer-o-promil-wiecej-jechali-motorowerem-7148840?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 07:59:28+00:00

<img alt="Kierowca miał ponad trzy promile, pasażer o promil więcej. Jechali motorowerem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ml3omc-policja-drogowka-lizak-shutterstock2147933467-6156273/alternates/LANDSCAPE_1280" />
    Motorowerzysta i jego pasażer zostali zatrzymani na terenie Tarnowa Jeziernego (woj. lubuskie), bo podróżowali bez kasków. Okazało się, że mężczyźni byli pijani. Jak informuje policja, kierowca miał w organizmie ponad trzy promile alkoholu, a jego pasażer - ponad cztery. - Nieodpowiedzialna podróż znajdzie finał w sądzie - informują mundurowi.

## Cztery tysiące fałszywych zaświadczeń o szczepieniach przeciwko COVID-19. Zatrzymano 10 osób
 - [https://tvn24.pl/krakow/krakow-za-falszywe-certyfikaty-szczepien-przeciwko-covid-19-mieli-zarobic-cztery-miliony-zlotych-10-osob-zatrzymanych-7148737?source=rss](https://tvn24.pl/krakow/krakow-za-falszywe-certyfikaty-szczepien-przeciwko-covid-19-mieli-zarobic-cztery-miliony-zlotych-10-osob-zatrzymanych-7148737?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 07:34:14+00:00

<img alt="Cztery tysiące fałszywych zaświadczeń o szczepieniach przeciwko COVID-19. Zatrzymano 10 osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gmrut6-cztery-tysiace-falszywych-zaswiadczen-o-szczepieniach-przeciwko-covid-19-zatrzymano-10-osob-7148851/alternates/LANDSCAPE_1280" />
    Policja poinformowała o zatrzymaniu 10 osób, które miały wprowadzać do systemu gabinet.gov.pl podrobione zaświadczenia o szczepieniu przeciwko COVID-19 dla osób, które w rzeczywistości nie były szczepione. Podejrzani mieli wzbogacić się o około cztery miliony złotych.

## Atak na Kijów. "Kombinowany i prowadzony z różnych kierunków"
 - [https://tvn24.pl/swiat/ukraina-rosja-rosyjski-atak-na-kijow-zestrzelone-drony-i-rakiety-7148652?source=rss](https://tvn24.pl/swiat/ukraina-rosja-rosyjski-atak-na-kijow-zestrzelone-drony-i-rakiety-7148652?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 07:19:02+00:00

<img alt="Atak na Kijów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3wdb1p-skutki-ostrzalu-rejonu-kijowa-7148700/alternates/LANDSCAPE_1280" />
    Ponad 40 celów zostało zestrzelonych nad Kijowem i obwodem kijowskim podczas nocnego ataku rosyjskich rakiet i dronów - poinformowały tamtejsze władze. Był to piętnasty atak na stolicę Ukrainy od początku maja. Alarm przeciwlotniczy trwał ponad cztery godziny.

## Watykański sekretarz stanu o misji pokojowej na Ukrainie: nie wykluczamy innych rozmówców
 - [https://tvn24.pl/swiat/kardynal-pietro-parolin-watykanski-sekretarz-stanu-w-dazeniach-do-pokoju-w-ukrainie-nie-nalezy-wykluczac-zadnego-rozmowcy-7148534?source=rss](https://tvn24.pl/swiat/kardynal-pietro-parolin-watykanski-sekretarz-stanu-w-dazeniach-do-pokoju-w-ukrainie-nie-nalezy-wykluczac-zadnego-rozmowcy-7148534?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 07:15:00+00:00

<img alt="Watykański sekretarz stanu o misji pokojowej na Ukrainie: nie wykluczamy innych rozmówców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x1kg4i-rzym-watykan-shutterstock350716526-5441898/alternates/LANDSCAPE_1280" />
    Kardynał Pietro Parolin, watykański sekretarz stanu, powiedział, że "w dążeniach do pokoju w Ukrainie nie należy wykluczać żadnego rozmówcy". Na łamach dziennika "Corriere della Sera" mówił, że Watykan chce pomóc stworzyć "inną atmosferę", bo dotąd mówi się tylko o rozwiązaniu militarnym.

## Radni twierdzą, że opera przepłacała za prąd, bo nie dopełniono formalności. "Sprawa nie jest jednoznaczna"
 - [https://tvn24.pl/bialystok/bialystok-opera-przeplacala-za-prad-sa-informacje-ze-stracila-kilkaset-tysiecy-zlotych-7146040?source=rss](https://tvn24.pl/bialystok/bialystok-opera-przeplacala-za-prad-sa-informacje-ze-stracila-kilkaset-tysiecy-zlotych-7146040?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 06:22:29+00:00

<img alt="Radni twierdzą, że opera przepłacała za prąd, bo nie dopełniono formalności. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wk1kxp-opera-i-filharmonia-podlaska-w-bialymstoku-7143423/alternates/LANDSCAPE_1280" />
    Opera i Filharmonia Podlaska miała nie złożyć na czas oświadczenia, dzięki któremu instytucja mogłaby korzystać z rządowej tarczy zamrażającej od 1 grudnia 2022 roku stawki za prąd - wynika z informacji, którą otrzymali radni wojewódzcy Koalicji Obywatelskiej. Brak oświadczenia miał przynieść stratę rzędu kilkuset tysięcy złotych. Sprawa jest badana przez zarząd województwa. Z kolei marszałek województwa podkreśla, że sprawa nie jest jednoznaczna. Na sesji sejmiku województwa radni mają głosować nad projektem uchwały w sprawie zmian w budżecie i zwiększeniu dotacji dla opery.

## Miał cofnięte prawo jazdy i był pijany. Z podróży nie zrezygnował
 - [https://tvn24.pl/tvnwarszawa/ulice/szczaki-piaseczno-pijany-bez-prawa-jazdy-zatrzymany-kierowca-7148587?source=rss](https://tvn24.pl/tvnwarszawa/ulice/szczaki-piaseczno-pijany-bez-prawa-jazdy-zatrzymany-kierowca-7148587?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 05:36:56+00:00

<img alt="Miał cofnięte prawo jazdy i był pijany. Z podróży nie zrezygnował" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-opnr0r-kierowca-zostal-zatrzymany-w-miejscowosci-szczaki-7148583/alternates/LANDSCAPE_1280" />
    Do zatrzymania kierowcy doszło w miejscowości Szczaki, niedaleko Piaseczna. Mężczyzna miał cofnięte uprawnienia i prowadził pijany, dlatego usłyszy dwa zarzut.

## Pogratulowali Erdoganowi przed ogłoszeniem jego zwycięstwa. Wśród nich Putin i Orban
 - [https://tvn24.pl/swiat/wybory-prezydenckie-w-turcji-recep-tayyip-erdogan-zwyciezyl-putin-i-orban-zlozyli-gratulacje-7148503?source=rss](https://tvn24.pl/swiat/wybory-prezydenckie-w-turcji-recep-tayyip-erdogan-zwyciezyl-putin-i-orban-zlozyli-gratulacje-7148503?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 05:28:00+00:00

<img alt="Pogratulowali Erdoganowi przed ogłoszeniem jego zwycięstwa. Wśród nich Putin i Orban" src="https://tvn24.pl/najnowsze/cdn-zdjecie-afbqm9-zwolennicy-prezydenta-turcji-7148609/alternates/LANDSCAPE_1280" />
    Recep Tayyip Erdogan będzie ponownie prezydentem Turcji - wynika z policzonych głosów oddanych w drugiej turze wyborów. Zanim oficjalnie potwierdzono zwycięstwo urzędującego prezydenta nad Kemalem Kiricdaroglu, z gratulacjami pośpieszyli między innymi rosyjski prezydent Władimir Putin, węgierski premier Viktor Orban, prezydent Egiptu Abdel Fattah es-Sisi oraz emir Kataru, szejk Tamim bin Hamad al-Thani.

## Odkryli antybiotyk przeciwko superbakterii. Pomogła sztuczna inteligencja
 - [https://tvn24.pl/tvnmeteo/nauka/odkryli-antybiotyk-przeciwko-superbakterii-acinetobacter-baumannii-pomogla-sztuczna-inteligencja-7148574?source=rss](https://tvn24.pl/tvnmeteo/nauka/odkryli-antybiotyk-przeciwko-superbakterii-acinetobacter-baumannii-pomogla-sztuczna-inteligencja-7148574?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 05:16:24+00:00

<img alt="Odkryli antybiotyk przeciwko superbakterii. Pomogła sztuczna inteligencja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9wftnb-superbakteria-acinetobacter-baumannii-7148582/alternates/LANDSCAPE_1280" />
    Naukowcy z Kanady wykorzystali sztuczną inteligencję (AI), by wyselekcjonować najsilniejszy z jeszcze niepoznanych antybiotyków przeciwko groźnej superbakterii Acinetobacter baumannii. Najpierw samodzielnie przetestowali substancje na patogenie, a następnie pozwolili AI stworzyć listę najbardziej obiecujących leków. Rezultaty były znakomite.

## Pogoda na dziś - poniedziałek 29.05. W niektórych miejscach może popadać
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-poniedzialek-2905-w-niektorych-miejscach-moze-popadac-7148473?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-poniedzialek-2905-w-niektorych-miejscach-moze-popadac-7148473?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-05-29 00:00:00+00:00

<img alt="Pogoda na dziś - poniedziałek 29.05. W niektórych miejscach może popadać" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8tz61h-deszcz-7148485/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Poniedziałek 29.05 upłynie pod znakiem słońca. Słabe i przelotne opady deszczu możliwe są lokalnie na północnym wschodzie i południowo-wschodnich krańcach Polski. Termometry wskażą od 19 do 24 stopni Celsjusza.

