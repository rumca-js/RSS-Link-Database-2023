# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Boogeyman - Movie Review
 - [https://www.youtube.com/watch?v=E2UxQNcSiEE](https://www.youtube.com/watch?v=E2UxQNcSiEE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2023-05-29 13:00:09+00:00

A 90 film based on the 12 page short story by Stephen King....kind of. Here's my review for THE BOOGEYMAN!

