# Source:NBC world, URL:https://feeds.nbcnews.com/nbcnews/public/world, language:en-US

## Russia fires three massive waves of attacks across Ukraine in 48 hours
 - [https://www.nbcnews.com/nightly-news/video/russia-fires-three-massive-waves-of-attacks-across-ukraine-in-48-hours-178143813841](https://www.nbcnews.com/nightly-news/video/russia-fires-three-massive-waves-of-attacks-across-ukraine-in-48-hours-178143813841)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-05-29 23:03:33+00:00

11 Russian missiles targeted Kyiv after more than 60 cruise missiles and drones were fired across the country overnight. Ukraine’s air force says they shot down nearly everything. NBC News’ Molly Hunter reports the latest.

## Ex-El Salvador president sentenced to 14 years for negotiating with gangs
 - [https://www.nbcnews.com/news/world/ex-el-salvador-president-sentenced-14-years-negotiating-gangs-rcna86691](https://www.nbcnews.com/news/world/ex-el-salvador-president-sentenced-14-years-negotiating-gangs-rcna86691)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-05-29 18:35:06+00:00

A judge sentenced former El Salvador President Mauricio Funes to 14 years in prison Monday for negotiating with gangs during his administration.

## British prank TikToker who went viral for entering stranger's home is in custody
 - [https://www.nbcnews.com/news/world/british-prank-tiktoker-went-viral-entering-strangers-home-custody-rcna86677](https://www.nbcnews.com/news/world/british-prank-tiktoker-went-viral-entering-strangers-home-custody-rcna86677)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-05-29 18:07:31+00:00

A British TikToker who has become notorious for extreme pranks is in custody for allegedly violating a court order barring him from posting videos of people without their consent, according to London’s Metropolitan Police.

## Blasts hit central Kyiv as Russia launches rare daytime attack
 - [https://www.nbcnews.com/news/world/kyiv-ukraine-russia-airstrikes-blasts-rare-daytime-rcna86642](https://www.nbcnews.com/news/world/kyiv-ukraine-russia-airstrikes-blasts-rare-daytime-rcna86642)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-05-29 14:25:12+00:00

Air raid sirens wailed, residents rushed to bomb shelters and explosions rocked buildings in Kyiv amid an intensifying Russian assault on Ukraine's capital.

## Russia issues arrest warrant for Lindsey Graham after Ukraine comments
 - [https://www.nbcnews.com/news/world/russia-issues-arrest-warrant-lindsey-graham-ukraine-comments-rcna86655](https://www.nbcnews.com/news/world/russia-issues-arrest-warrant-lindsey-graham-ukraine-comments-rcna86655)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-05-29 14:20:48+00:00

Russia’s Interior Ministry on Monday issued an arrest warrant for U.S. Sen. Lindsey Graham following his comments related to the fighting in Ukraine.

## Japan on standby for falling missile debris as North Korea announces plans to launch satellite into orbit
 - [https://www.nbcnews.com/news/world/north-korea-launch-satellite-japan-on-alert-rcna86641](https://www.nbcnews.com/news/world/north-korea-launch-satellite-japan-on-alert-rcna86641)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-05-29 12:13:29+00:00

North Korea on Monday notified Japan that it plans to launch a satellite soon, which may be an attempt to put Pyongyang’s first military reconnaissance satellite.

## ‘Nuclear weapons for everyone’ who joins Belarus and Russia, Putin ally promises
 - [https://www.nbcnews.com/news/world/nuclear-weapons-ukraine-belarus-lukashenko-russia-putin-rcna86640](https://www.nbcnews.com/news/world/nuclear-weapons-ukraine-belarus-lukashenko-russia-putin-rcna86640)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-05-29 11:20:15+00:00

Belarusian President Alexander Lukashenko, a close ally of President Vladimir Putin, promised nuclear weapons to any nation that joined Russia and Belarus.

## Venice police investigating after famed Grand Canal turns bright green
 - [https://www.nbcnews.com/news/world/venice-police-investigating-grand-canal-turns-bright-green-rcna86635](https://www.nbcnews.com/news/world/venice-police-investigating-grand-canal-turns-bright-green-rcna86635)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-05-29 07:15:59+00:00

Police in Venice are investigating the source of a phosphorescent green liquid patch that appeared Sunday in the city’s famed Grand Canal.

