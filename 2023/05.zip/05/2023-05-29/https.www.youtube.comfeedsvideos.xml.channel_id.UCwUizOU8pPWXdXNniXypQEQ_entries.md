# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## DeSantis is running for President!
 - [https://www.youtube.com/watch?v=vhEWiHO3wHg](https://www.youtube.com/watch?v=vhEWiHO3wHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-05-29 16:18:15+00:00

#shorts

