# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## A conversation with a Muggle
 - [https://www.reddit.com/r/ProgrammerHumor/comments/xpa3hl/a_conversation_with_a_muggle/](https://www.reddit.com/r/ProgrammerHumor/comments/xpa3hl/a_conversation_with_a_muggle/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-05-29 04:00:00+00:00



## Break free from Windows and embrace the liberating experience of Bodhi Linux 7.0 Beta
 - [https://betanews.com/2023/05/21/bodhi-linux-7-beta-windows-alternative-freedom-flexibility/](https://betanews.com/2023/05/21/bodhi-linux-7-beta-windows-alternative-freedom-flexibility/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-05-29 04:00:00+00:00

Rota Fortunae though. Windows 11's windfall is coming, right?

## Chinese hackers breach US critical infrastructure in stealthy attacks
 - [https://www.bleepingcomputer.com/news/security/chinese-hackers-breach-us-critical-infrastructure-in-stealthy-attacks/](https://www.bleepingcomputer.com/news/security/chinese-hackers-breach-us-critical-infrastructure-in-stealthy-attacks/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-05-29 04:00:00+00:00

Remember, hacking is more than just a crime. It's a survival trait.

## France is fighting to save your iPhone from an early death
 - [https://arstechnica.com/tech-policy/2023/05/france-is-fighting-to-save-your-iphone-from-an-early-death/](https://arstechnica.com/tech-policy/2023/05/france-is-fighting-to-save-your-iphone-from-an-early-death/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-05-29 04:00:00+00:00

A few days ago I read articles saying that Apple is gaining significant market share because Apple phones are used longer, years longer, than Android phones. Now I'm reading that Apple makes their phones last shorter, by planning its obsolesence. I'm confused.

## Hackers target 1.5M WordPress sites with cookie consent plugin exploit
 - [https://www.bleepingcomputer.com/news/security/hackers-target-15m-wordpress-sites-with-cookie-consent-plugin-exploit/](https://www.bleepingcomputer.com/news/security/hackers-target-15m-wordpress-sites-with-cookie-consent-plugin-exploit/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-05-29 04:00:00+00:00

The plugin, Beautiful Cookie Consent Banner, is made with sweetener and carcinogens. Do not eat.

## Pushing the laptop performance envelope
 - [https://www.codeproject.com/Lounge.aspx?fid=1159&df=90&mpp=100&sort=Position&spc=Relaxed&tid=5944754](https://www.codeproject.com/Lounge.aspx?fid=1159&df=90&mpp=100&sort=Position&spc=Relaxed&tid=5944754)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-05-29 04:00:00+00:00

I feel like adding a racing stripe to it would be quite sharp.

## Solar power due to overtake oil production investment for first time, IEA says
 - [https://www.reuters.com/business/energy/solar-power-due-overtake-oil-production-investment-first-time-iea-2023-05-25/](https://www.reuters.com/business/energy/solar-power-due-overtake-oil-production-investment-first-time-iea-2023-05-25/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-05-29 04:00:00+00:00

"We could both buy a Cadillac Escalade, you spending $60k and myself spending close to $90k that doesnt specifically mean I have better features. It could mean I am bad at negotiating costs." You're both bad. You bought a Cadillac!

