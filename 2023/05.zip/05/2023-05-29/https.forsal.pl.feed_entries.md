# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Nvidia buduje superkomputer do pracy ze sztuczną inteligencją
 - [https://forsal.pl/lifestyle/technologie/artykuly/8724924,nvidia-buduje-superkomputer-do-pracy-ze-sztuczna-inteligencja.html](https://forsal.pl/lifestyle/technologie/artykuly/8724924,nvidia-buduje-superkomputer-do-pracy-ze-sztuczna-inteligencja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 19:32:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mPYktkuTURBXy9hYmZkNzZlMC05NGFlLTRhOTctODFiOS01MWZkYzFkZmMwYmIuanBlZ5GTBc0BHcyg" />Amerykański gigant w dziedzinie gier i grafiki komputerowej Nvidia poinformował w poniedziałek, że aby sprostać rosnącemu zapotrzebowaniu klientów na aplikacje oparte na sztucznej inteligencji (SI), buduje w Izraelu superkomputer o nazwie Israel-1, który będzie jednym z najszybszych w swoim rodzaju.

## Szef sztabu generalnego armii Czech: Rosja dąży do konfliktu z NATO
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8724853,szef-sztabu-generalnego-armii-czech-rosja-dazy-do-konfliktu-z-nato.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8724853,szef-sztabu-generalnego-armii-czech-rosja-dazy-do-konfliktu-z-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 18:58:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-o-ktkuTURBXy8xMjFmMTUxYS1mOTAwLTRkZGQtODNmNi0zYzZhMmJkZTkyYWEuanBlZ5GTBc0BHcyg" />Szef sztabu generalnego armii Czech Karel Rzehka ostrzegł w poniedziałek, że Rosja zmierza w kierunku konfliktu z NATO. Na seminarium w Izbie Poselskiej o bezpieczeństwie stwierdził też, że Czechy będą w takim konflikcie uczestniczyć „od pierwszej chwili”.

## Ukraińska armia zna nazwiska dowódców  jednostek, które zastąpią Grupę Wagnera w Bachmucie
 - [https://forsal.pl/swiat/ukraina/artykuly/8724850,ukrainska-armia-zna-nazwiska-dowodcow-jednostek-ktore-zastapia-grupe-wagnera-w-bachmucie.html](https://forsal.pl/swiat/ukraina/artykuly/8724850,ukrainska-armia-zna-nazwiska-dowodcow-jednostek-ktore-zastapia-grupe-wagnera-w-bachmucie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 18:47:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/COhktkuTURBXy9mNDU1OTc2Ny02ZjU3LTRkYzAtODI5OC0yZDllZDZiZTkwYjEuanBlZ5GTBc0BHcyg" />Armia Rosji wymienia Grupę Wagnera w Bachmucie na wojska powietrznodesantowe i zmotoryzowane; Ukraina zna potencjał tych oddziałów i nazwiska dowódców – oznajmił w poniedziałek rzecznik Wschodniego Zgrupowania Wojsk armii ukraińskiej Serhij Czerewaty.

## Laponia: Rozpoczęły się największe manewry myśliwców w Europie. Pacyfiści i ekolodzy protestują
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8724710,laponia-najwieksze-manewry-mysliwcow-w-europie-pacyfisci-i-ekolodzy-protestuja.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8724710,laponia-najwieksze-manewry-mysliwcow-w-europie-pacyfisci-i-ekolodzy-protestuja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 17:28:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wx8ktkuTURBXy81MmFlYTc2ZS0yMDY4LTRiNTctOWQyOC01MjdjNDJlOWVlMjQuanBlZ5GTBc0BHcyg" />Około 150 samolotów oraz 3 tys. żołnierzy z kilkunastu krajów NATO uczestniczy w rozpoczętych w poniedziałek manewrach lotniczych „Arctic Challenge 2023”. Ćwiczenia z udziałem m.in. amerykańskich, francuskich i szwedzkich myśliwców odbywają się w rejonie północnej Finlandii, Szwecji i Norwegii. W Rovaniemi przeciwko manewrom protestowali pacyfiści i ekolodzy.

## Rosyjski system rakietowy S-400 przybył do obwodu mińskiego
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8724701,rosyjski-system-rakietowy-s-400-przybyl-do-obwodu-minskiego.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8724701,rosyjski-system-rakietowy-s-400-przybyl-do-obwodu-minskiego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 16:54:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/X3sktkuTURBXy9kZGZiOGQzZS02NTk3LTRhMTAtYTU5Zi0wZGFiZDE3ZDNmOGMuanBlZ5GTBc0BHcyg" />Na Białoruś przybył z Rosji system rakietowy S-400; zestaw ten trafił do jednostki wojskowej w miejscowości Nawakołasawa w obwodzie mińskim - podał w poniedziałek niezależny projekt monitoringowy Biełaruski Hajun.

## 01 czerwca białoruskie i rosyjskie ciężarówki z naczepami nie wjadą do Polski od strony Białorusi
 - [https://forsal.pl/swiat/rosja/artykuly/8724699,01-czerwca-bialoruskie-i-rosyjskie-ciezarowki-z-naczepami-nie-wjada-do-polski-od-strony-bialorusi.html](https://forsal.pl/swiat/rosja/artykuly/8724699,01-czerwca-bialoruskie-i-rosyjskie-ciezarowki-z-naczepami-nie-wjada-do-polski-od-strony-bialorusi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 16:49:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HxTktkuTURBXy8yMDM4YTZlMC0xZTQ1LTQ1MjctODdmNS0wZDJmZTZmYzdhNGIuanBlZ5GTBc0BHcyg" />Od 1 czerwca do odwołania ruch towarowy na granicy z Białorusią zostanie zawieszony dla ciężarówek, ciągników samochodowych, przyczep, w tym naczep, oraz zespołów pojazdów zarejestrowanych na terytorium Białorusi i Rosji - stanowi rozporządzenie MSWiA.

## Klincz w amerykańskim Kongresie. Przedstawiciele obu partii mogą zablokować podwyżkę limitu długu
 - [https://forsal.pl/swiat/usa/artykuly/8724689,usa-kongresmeni-obu-partii-moga-zablokowac-podwyzke-limitu-dlugu.html](https://forsal.pl/swiat/usa/artykuly/8724689,usa-kongresmeni-obu-partii-moga-zablokowac-podwyzke-limitu-dlugu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 16:39:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RfvktkuTURBXy8yNjg0MDc1YS05ZTQxLTRjMDEtYmU2MS0xMDAwNTM4MmJlNzkuanBlZ5GTBc0BHcyg" />Mimo wynegocjowanego przez prezydenta i spikera Izby Reprezentantów porozumienia w sprawie podniesienia limitu długu, kongresmeni ze skrajnych skrzydeł obydwu partii głośno okazują swoje niezadowolenie - podają w poniedziałek media. Według Politico może to znacznie utrudnić przyjęcie ustawy na czas, by uniknąć niewypłacalności.

## Śleszyński: Dziś jesteśmy optymistyczni, choć nie wiemy co przyniesie przyszłość
 - [https://forsal.pl/biznes/energetyka/artykuly/8724681,sleszynski-dzis-jestesmy-optymistyczni-choc-nie-wiemy-co-przyniesie-przyszlosc.html](https://forsal.pl/biznes/energetyka/artykuly/8724681,sleszynski-dzis-jestesmy-optymistyczni-choc-nie-wiemy-co-przyniesie-przyszlosc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 16:08:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1D2ktktTURBXy85ZmIwNjk1OS00ODZmLTRiNjctODI2Yi1hNGExMTBmNTU3ZWQucG5nkZMFzQEdzKA" />O planach strategii największego polskiego koncernu podczas CEO Council Summit w Londynie opowiadał Robert Śleszyński, Dyrektor Wykonawczy ds. Strategii i Inwestycji Kapitałowych PKN Orlen.

## Sprzedaż gry 'Wiedźmin 3: Dziki Gon' przekroczyła 50 mln. Cała trylogia rozeszła się w 75 mln egz.
 - [https://forsal.pl/lifestyle/rozrywka/artykuly/8724621,sprzedaz-gry-wiedzmin-3-dziki-gon-przekroczyla-50-mln-trylogia-75-mln-egz.html](https://forsal.pl/lifestyle/rozrywka/artykuly/8724621,sprzedaz-gry-wiedzmin-3-dziki-gon-przekroczyla-50-mln-trylogia-75-mln-egz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 15:59:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tzvktkuTURBXy9hNGU1MWRjNC04MDE4LTQzODktYmI4MC1jNzM0NWRiMWRkNTQuanBlZ5GTBc0BHcyg" />undefined

## Ropa drożeje. Brent kosztuje 76,52 dol., a WTI 72,49 dol.
 - [https://forsal.pl/biznes/energetyka/artykuly/8724600,ropa-drozeje-brent-kosztuje-7652-dol-a-wti-7249-dol.html](https://forsal.pl/biznes/energetyka/artykuly/8724600,ropa-drozeje-brent-kosztuje-7652-dol-a-wti-7249-dol.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 15:34:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BGUktkuTURBXy81YzFhNjU3ZC04ZTVhLTQxNTMtOTI3YS00MGE5Yjk2Yzk4M2MuanBlZ5GTBc0BHcyg" />W poniedziałek po godz. 17.00 notowania ropy Brent na giełdzie w Londynie spadały o 0,56 proc., do 76,52 dol. za baryłkę. Amerykańska ropa WTI na giełdzie w Nowym Jorku staniała o 0,25 proc., do 72,49 dol. za baryłkę.

## Twitter musi respektować unijne zasady dotyczące dezinformacji. Inaczej zostanie "wyrzucony z UE"
 - [https://forsal.pl/biznes/media/artykuly/8724595,twitter-respektowac-zasady-dezinformacja-lub-zostanie-wyrzucony-z-ue.html](https://forsal.pl/biznes/media/artykuly/8724595,twitter-respektowac-zasady-dezinformacja-lub-zostanie-wyrzucony-z-ue.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 15:23:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8nxktkuTURBXy8yODE5NTZmNi1kMWNlLTQ3OWQtOTBiZC04MWU2MDI3ODVmMzIuanBlZ5GTBc0BHcyg" />Twitter zostanie wyrzucony z EU w przypadku naruszenia jej zasad - oświadczył w poniedziałek francuski minister Jean-Noel Barrot odpowiedzialny za transformację cyfrową i telekomunikację w wywiadzie dla telewizji France Info.

## Ruch FIRE - czy wczesna niezależność finansowa ma sens w Polsce?
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8721556,ruch-fire-czy-wczesna-niezaleznosc-finansowa-ma-sens-w-polsce.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8721556,ruch-fire-czy-wczesna-niezaleznosc-finansowa-ma-sens-w-polsce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 14:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/P6mktkuTURBXy9iYjA3MGVlZi0zNGVkLTRlMzEtODBlNC01YzQyZDMxYjBiMGYuanBlZ5GTBc0BHcyg" />Statystyczny mieszkaniec Polski musiałby odkładać aż 65% swojego rocznego wynagrodzenia po przekroczeniu 30 roku życia, by osiągnąć niezależność finansową już w wieku 55 lat. Kiedy więc idea FIRE może mieć sens, a kiedy pozostaje nieosiągalna?

## Media: Holenderski rząd w ubiegłym roku zarobił na hazardzie 123 mln euro
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8724581,media-holenderski-rzad-w-ubieglym-roku-zarobil-na-hazardzie-123-mln-euro.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8724581,media-holenderski-rzad-w-ubieglym-roku-zarobil-na-hazardzie-123-mln-euro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 14:24:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u5ektkuTURBXy83ODU0YmMwOC1jODYxLTQwYTMtODkxYi00NDhhN2Y0ODcyMmIuanBlZ5GTBc0BHcyg" />Rząd jest jednym z największych bossów hazardowych w Holandii i w ubiegłym roku osiągnął 123 mln euro zysku z hazardu - napisał w poniedziałek dziennik „Algemeen Dagblad”. Z jednej strony gabinet określa zasady obowiązujące na rynku gier hazardowych, ale z drugiej strony jest na nim ważnym graczem - zauważa gazeta.

## Rynek walut: Wzrost apetytu na ryzyko może sprzyjać złotemu
 - [https://forsal.pl/finanse/waluty/artykuly/8724575,rynek-walut-wzrost-apetytu-na-ryzyko-moze-sprzyjac-zlotemu.html](https://forsal.pl/finanse/waluty/artykuly/8724575,rynek-walut-wzrost-apetytu-na-ryzyko-moze-sprzyjac-zlotemu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 14:07:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KVJktkuTURBXy9hZTY0YTU2Yi0wZGJiLTQ5ZmEtYTE4Yi1iNzQ2Y2IxY2I3NGUuanBlZ5GTBc0BHcyg" />Osiągnięte porozumienie w kwestii podniesienia limitu zadłużenia w USA może stanowić czynnik zwiększający apetyt na bardziej ryzykowne aktywa, w tym na złotego - oceniają ekonomiści Banku Millennium. Kierunek notowaniom SPW i PLN mogą dać też publikowane w tym tygodniu dane z krajowej gospodarki.

## Kryzys motoryzacyjny w USA. Wycofano z użytku ponad 275 tysięcy samochodów z wadami produkcyjnymi
 - [https://forsal.pl/motoforsal/motobiznes/artykuly/8724569,kryzys-motoryzacyjny-w-usa-wycofano-z-uzytku-ponad-275-tysiecy-samochodow-z-wadami-produkcyjnymi.html](https://forsal.pl/motoforsal/motobiznes/artykuly/8724569,kryzys-motoryzacyjny-w-usa-wycofano-z-uzytku-ponad-275-tysiecy-samochodow-z-wadami-produkcyjnymi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 13:58:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gkXktkuTURBXy8xMmZiZjYyZi0wODhmLTQ3MDQtODJiZS1lOTRkMDk1NjM0ODEuanBlZ5GTBc0BHcyg" />Amerykański urząd ds. bezpieczeństwa ruchu drogowego (NHTSA) poinformował o wycofaniu z użycia w ubiegłym tygodniu łącznie ponad 275 tysięcy samochodów, m.in. takich firm jak Ford, Jeep, Mercedes-Benz i Nissan, z powodu różnorodnych wad produkcyjnych - podał w poniedziałek portal dziennika &quot;USA Today&quot;. Po bezpłatnej naprawie pojazdy mogą trafić z powrotem do klientów.

## Comarch rekomenduje wypłatę 4 zł dywidendy na akcję za 2022 rok
 - [https://forsal.pl/finanse/gielda/artykuly/8724549,comarch-rekomenduje-wyplate-4-zl-dywidendy-na-akcje-za-2022-rok.html](https://forsal.pl/finanse/gielda/artykuly/8724549,comarch-rekomenduje-wyplate-4-zl-dywidendy-na-akcje-za-2022-rok.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 13:23:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1z2ktkuTURBXy8zNDMwZjU0OS03NjgyLTQ3MzAtYjlkOC04ZGQ1NGNhM2NhNGEuanBlZ5GTBc0BHcyg" />undefined

## Dino Polska zdecydowało o budowie centrum dystryb. w Wielkopolsce za ok. 130 mln zł netto
 - [https://forsal.pl/finanse/gielda/artykuly/8724547,dino-polska-zdecydowalo-o-budowie-centrum-dystryb-w-wielkopolsce-za-ok-130-mln-zl-netto.html](https://forsal.pl/finanse/gielda/artykuly/8724547,dino-polska-zdecydowalo-o-budowie-centrum-dystryb-w-wielkopolsce-za-ok-130-mln-zl-netto.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 13:22:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PXTktktTURBXy9lZTU0ZDZiZS01NzM4LTQ4YTAtOTg3Ny1lM2U1MGU4N2RkZjYucG5nkZMFzQEdzKA" />undefined

## Kamiński: 365. przedstawicieli białoruskiego reżimu z zakazem wjazdu do strefy Schengen
 - [https://forsal.pl/gospodarka/polityka/artykuly/8724546,kaminski-365-przedstawicieli-bialoruskiego-rezimu-zakaz-wjazdu-strefa-schengen.html](https://forsal.pl/gospodarka/polityka/artykuly/8724546,kaminski-365-przedstawicieli-bialoruskiego-rezimu-zakaz-wjazdu-strefa-schengen.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 13:21:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/j69ktkuTURBXy8zYzc0NDU3Zi0zNWQ3LTQ2MjItOTA0NC1jZGI5NzMyOTUzNDEuanBlZ5GTBc0BHcyg" />Zdecydowałem o wpisaniu na listę sankcyjną 365 przedstawicieli białoruskiego reżimu. Osoby te dostaną m.in. zakaz wjazdu do strefy Schengen. Sankcje obejmą też 20 podmiotów i 16 przedsiębiorców powiązanych głównie z rosyjskim kapitałem — poinformował szef MSWiA Mariusz Kamiński.

## Esotiq &amp; Henderson miał ok. 80 mln zł przychodów po kwietniu, marża będzie dalej rosła
 - [https://forsal.pl/finanse/gielda/artykuly/8724544,esotiq--henderson-mial-ok-80-mln-zl-przychodow-po-kwietniu-marza-bedzie-dalej-rosla.html](https://forsal.pl/finanse/gielda/artykuly/8724544,esotiq--henderson-mial-ok-80-mln-zl-przychodow-po-kwietniu-marza-bedzie-dalej-rosla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 13:19:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EhBktkuTURBXy83NmQxNDRiYi05ZTE3LTQyMjQtYjllMS1kNjEzM2Q2ZmZiZmEuanBlZ5GTBc0BHcyg" />undefined

## Esotiq &amp; Henderson miało 0,22 mln zł zysku netto, 5,4 mln zł zysku EBITDA w I kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8724542,esotiq--henderson-mialo-022-mln-zl-zysku-netto-54-mln-zl-zysku-ebitda-w-i-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/8724542,esotiq--henderson-mialo-022-mln-zl-zysku-netto-54-mln-zl-zysku-ebitda-w-i-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 13:15:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Xh_ktkuTURBXy8zNjY5ODllOS1lMTVlLTQ5MTMtYjNmZS05MWE0MWYyZmZiOGQuanBlZ5GTBc0BHcyg" />undefined

## Unijni decydenci: UE będzie nadal kontynuowała wzajemnie korzystną współpracę z Turcją
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8724540,unijni-decydenci-ue-bedzie-nadal-kontynuowala-wzajemnie-korzystna-wspolprace-z-turcja.html](https://forsal.pl/swiat/unia-europejska/artykuly/8724540,unijni-decydenci-ue-bedzie-nadal-kontynuowala-wzajemnie-korzystna-wspolprace-z-turcja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 13:08:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Km2ktkuTURBXy85Mjg4NTBjNi0xMzhkLTQ0YzQtYjgwNS1hNDNjYzg4NzA5NzQuanBlZ5GTBc0BHcyg" />W strategicznym interesie UE leży kontynuacja opartych na współpracy, wzajemnie korzystnych stosunków z Turcją i wszystkimi jej mieszkańcami, a także zapewnienie stabilnego i bezpiecznego środowiska we wschodniej części Morza Śródziemnego - napisali we wspólnym oświadczeniu szef unijnej dyplomacji Josep Borrell oraz komisarz ds. sąsiedztwa i rozszerzenia Oliver Varhelyi.

## Media: Gospodarka Niemiec zwalnia. Widać to już na rynku pracy
 - [https://forsal.pl/gospodarka/pkb/artykuly/8724537,media-gospodarka-niemiec-zwalnia-widac-to-juz-na-rynku-pracy.html](https://forsal.pl/gospodarka/pkb/artykuly/8724537,media-gospodarka-niemiec-zwalnia-widac-to-juz-na-rynku-pracy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 12:56:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6BlktkuTURBXy8zM2MyMGYwMC00ODQyLTQ4M2ItODk1ZS1hOGJhYjdiODAxMTYuanBlZ5GTBc0BHcyg" />Słabszy rozwój gospodarczy i niepewność spowodowana wysokimi cenami energii oraz wojną w Ukrainie odbijają się także na rynku pracy – oceniają niemieccy eksperci. Firmy zatrudniają coraz mniej nowych pracowników, a najbliższe miesiące przyniosą wzrost bezrobocia – informuje „Handelsblatt”.

## ML System rusza z budową księgi popytu na 896 848 akcji serii F, cena emisyjna  30 maja
 - [https://forsal.pl/finanse/artykuly/8724516,ml-system-rusza-z-budowa-ksiegi-popytu-na-896-848-akcji-serii-f-cena-emisyjna-30-maja.html](https://forsal.pl/finanse/artykuly/8724516,ml-system-rusza-z-budowa-ksiegi-popytu-na-896-848-akcji-serii-f-cena-emisyjna-30-maja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:59:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fOzktkuTURBXy85MjNlMTUxMy03YjVmLTRmMDEtYWQxYS1lN2IzZDQ5Nzc2OWQuanBlZ5GTBc0BHcyg" />undefined

## Bioceltix miało 2,63 mln zł straty netto, 2,59 mln zł zysku EBIT w I kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8724514,bioceltix-mialo-263-mln-zl-straty-netto-259-mln-zl-zysku-ebit-w-i-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/8724514,bioceltix-mialo-263-mln-zl-straty-netto-259-mln-zl-zysku-ebit-w-i-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:57:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5nfktkuTURBXy9hYWFmOGY4NC05YTE4LTQ5ZDQtOGQ4MS01OTI1ZGMwMmYzYjkuanBlZ5GTBc0BHcyg" />undefined

## Tower Inv. miał 0,76 mln zł zysku netto, 1,26 mln zł zysku EBIT w I kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8724513,tower-inv-mial-076-mln-zl-zysku-netto-126-mln-zl-zysku-ebit-w-i-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/8724513,tower-inv-mial-076-mln-zl-zysku-netto-126-mln-zl-zysku-ebit-w-i-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:56:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yKBktkuTURBXy9lZmQ3MDc5NS0zNDk2LTQxNTYtODIyMS1lYTAxYWYyNTI0MzUuanBlZ5GTBc0BHcyg" />undefined

## Zarząd Pure Biologics z prezesem Filipem Jeleniem został powołany na nową kadencję
 - [https://forsal.pl/finanse/gielda/artykuly/8724512,zarzad-pure-biologics-z-prezesem-filipem-jeleniem-zostal-powolany-na-nowa-kadencje.html](https://forsal.pl/finanse/gielda/artykuly/8724512,zarzad-pure-biologics-z-prezesem-filipem-jeleniem-zostal-powolany-na-nowa-kadencje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:54:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zn1ktkuTURBXy8yN2U3OTYxYS0wNWVmLTRmYzctOTgwNC1mZjkyOWJkYjkyZTkuanBlZ5GTBc0BHcyg" />undefined

## Mercator Medical miał szac. 18 mln zł straty netto, 25,1 mln zł straty EBITDA w I kw.
 - [https://forsal.pl/finanse/gielda/artykuly/8724511,mercator-medical-mial-szac-18-mln-zl-straty-netto-251-mln-zl-straty-ebitda-w-i-kw.html](https://forsal.pl/finanse/gielda/artykuly/8724511,mercator-medical-mial-szac-18-mln-zl-straty-netto-251-mln-zl-straty-ebitda-w-i-kw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:48:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Xh_ktkuTURBXy8zNjY5ODllOS1lMTVlLTQ5MTMtYjNmZS05MWE0MWYyZmZiOGQuanBlZ5GTBc0BHcyg" />undefined

## Moonlit otrzymał wypowiedzenie umowy licencyjnej od CD Projekt ws. DLD do 'Model Buildera'
 - [https://forsal.pl/finanse/gielda/artykuly/8724510,moonlit-otrzymal-wypowiedzenie-umowy-licencyjnej-od-cd-projekt-ws-dld-do-model-buildera.html](https://forsal.pl/finanse/gielda/artykuly/8724510,moonlit-otrzymal-wypowiedzenie-umowy-licencyjnej-od-cd-projekt-ws-dld-do-model-buildera.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:47:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yfaktkuTURBXy9jN2E5ZTliNS05MWE0LTRlNzgtYjVjZS04ZTdkNDdkMDRjMzQuanBlZ5GTBc0BHcyg" />

## Gaming Factory miał 0,18 mln zł zysku netto, 0,26 mln zł zysku EBITDA w I kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8724508,gaming-factory-mial-018-mln-zl-zysku-netto-026-mln-zl-zysku-ebitda-w-i-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/8724508,gaming-factory-mial-018-mln-zl-zysku-netto-026-mln-zl-zysku-ebitda-w-i-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:46:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oYVktkuTURBXy8yMDI4MDJhYy02MGFjLTQyMDYtYTlhMC0yODQ2MjI0NTNiM2YuanBlZ5GTBc0BHcyg" />undefined

## Polska 2050 dołączy do manifestacji 4 czerwca w Warszawie
 - [https://forsal.pl/gospodarka/polityka/artykuly/8724507,polska-2050-dolaczy-do-manifestacji-4-czerwca-w-warszawie.html](https://forsal.pl/gospodarka/polityka/artykuly/8724507,polska-2050-dolaczy-do-manifestacji-4-czerwca-w-warszawie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:45:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VzxktkuTURBXy8wODg1YmFlZi0zZjAyLTRjYjUtYTAwYi05YzY5OGU4M2MxNmUuanBlZ5GTBc0BHcyg" />Warszawski marsz 4 czerwca to już nie tylko manifestacja jednej partii, a rzecz o bezpieczeństwie narodowym; wezmą w nim udział nasi politycy, zwolennicy oraz struktury - zapowiedział w poniedziałek lider Polski 2050 Szymon Hołownia.

## Compremum miało 5,71 mln zł zysku netto, 11,51 mln zł zysku EBIT w I kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8724506,compremum-mialo-571-mln-zl-zysku-netto-1151-mln-zl-zysku-ebit-w-i-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/8724506,compremum-mialo-571-mln-zl-zysku-netto-1151-mln-zl-zysku-ebit-w-i-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:44:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fBMktkuTURBXy81ZTVlNDFlNy1hMzE1LTRlMGMtYmRjZS02NDlhZGZmZTk3NWIuanBlZ5GTBc0BHcyg" />undefined

## Dekpol miał 9,59 mln zł zysku netto, 10,27 mln zł zysku EBIT w I kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8724505,dekpol-mial-959-mln-zl-zysku-netto-1027-mln-zl-zysku-ebit-w-i-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/8724505,dekpol-mial-959-mln-zl-zysku-netto-1027-mln-zl-zysku-ebit-w-i-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:43:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bfEktkuTURBXy81MTY0NTc4MS01MDE0LTRjYjMtOTk0MS1kYjRiNDVjN2E3MjYuanBlZ5GTBc0BHcyg" />undefined

## Portfel zamówień Grupy Polimex Mostostal ma wartość ok. 4,7 mld zł
 - [https://forsal.pl/finanse/gielda/artykuly/8724503,portfel-zamowien-grupy-polimex-mostostal-ma-wartosc-ok-47-mld-zl.html](https://forsal.pl/finanse/gielda/artykuly/8724503,portfel-zamowien-grupy-polimex-mostostal-ma-wartosc-ok-47-mld-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:40:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/o2wktkuTURBXy82ZWQ1ZWU4OS02NTZlLTQ0NzgtYjZlYy04YjNjYWY3OWM4Y2UuanBlZ5GTBc0BHcyg" />undefined

## Polimex Mostostal miał 22,91 mln zł zysku netto, 28,99 mln zł zysku EBIT w I kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8724502,polimex-mostostal-mial-2291-mln-zl-zysku-netto-2899-mln-zl-zysku-ebit-w-i-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/8724502,polimex-mostostal-mial-2291-mln-zl-zysku-netto-2899-mln-zl-zysku-ebit-w-i-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:39:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LWrktkuTURBXy80NjcxYTk2Yy00OWIwLTQ4N2EtOTUyYS1kNjIzZmJlNDNjYTguanBlZ5GTBc0BHcyg" />undefined

## PMPG rozważa debiut na NewConnect spółki Orle Pióro, wydawcy 'Do Rzeczy' - wywiad
 - [https://forsal.pl/finanse/gielda/artykuly/8724500,pmpg-rozwaza-debiut-na-newconnect-spolki-orle-pioro-wydawcy-do-rzeczy-wywiad.html](https://forsal.pl/finanse/gielda/artykuly/8724500,pmpg-rozwaza-debiut-na-newconnect-spolki-orle-pioro-wydawcy-do-rzeczy-wywiad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:38:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zn1ktkuTURBXy8yN2U3OTYxYS0wNWVmLTRmYzctOTgwNC1mZjkyOWJkYjkyZTkuanBlZ5GTBc0BHcyg" />undefined

## PCF Group rozpoczyna emisję do ok. 5,85 mln akcji serii F, chce pozyskać 205-295 mln zł
 - [https://forsal.pl/finanse/gielda/artykuly/8724497,pcf-group-rozpoczyna-emisje-do-ok-585-mln-akcji-serii-f-chce-pozyskac-205-295-mln-zl.html](https://forsal.pl/finanse/gielda/artykuly/8724497,pcf-group-rozpoczyna-emisje-do-ok-585-mln-akcji-serii-f-chce-pozyskac-205-295-mln-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:37:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-rwktkuTURBXy8yYWNhMjAyNi01YWJlLTQxY2EtYjM5OC04MWRlZDA4NzIzN2MuanBlZ5GTBc0BHcyg" />undefined

## PCF Group miało 4,56 mln zł straty netto, 3 mln zł zysku EBITDA w I kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8724495,pcf-group-mialo-456-mln-zl-straty-netto-3-mln-zl-zysku-ebitda-w-i-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/8724495,pcf-group-mialo-456-mln-zl-straty-netto-3-mln-zl-zysku-ebitda-w-i-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:35:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fhiktkuTURBXy9kNzM5MjRmZi00MGMyLTQ2ODUtOWI3YS0wNzg5ODIwMzZiMzUuanBlZ5GTBc0BHcyg" />undefined

## Lewica: Apelujemy, by media zbojkotowały komisję ds. zbadania wpływów rosyjskich
 - [https://forsal.pl/gospodarka/polityka/artykuly/8724486,lewica-apelujemy-by-media-zbojkotowaly-komisje-ds-zbadania-wplywow-rosyjskich.html](https://forsal.pl/gospodarka/polityka/artykuly/8724486,lewica-apelujemy-by-media-zbojkotowaly-komisje-ds-zbadania-wplywow-rosyjskich.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:16:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TRwktkuTURBXy8wNTE2MTdlZi0yYTkyLTQ0MzYtOGUxNi1jNTkxZGIzMzVjOGQuanBlZ5GTBc0BHcyg" />Klub Lewicy nie wystawi swoich przedstawicieli do komisji d. wpływów rosyjskich - oświadczyli posłowie Magdalena Biejat, Włodzimierz Czarzasty i Adrian Zandberg. Liderzy Lewicy zaapelowali też do mediów o bojkotowanie tej komisji oraz zapowiedzieli postawienie prezydenta przed Trybunałem Stanu.

## 5G bez Huawei w kolejnym kraju Europy. Ericsson i Nokia zacierają ręce
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8724466,5g-bez-huawei-w-kolejnym-kraju-europy-ericsson-i-nokia-zacieraja-rece.html](https://forsal.pl/swiat/aktualnosci/artykuly/8724466,5g-bez-huawei-w-kolejnym-kraju-europy-ericsson-i-nokia-zacieraja-rece.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 11:15:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-0zktkuTURBXy84ODNjZWMyMC1iNjQ1LTRkZGItYWE1OS0xMDQ3MDdlMjlmNGEuanBlZ5GTBc0BHcyg" />Do grona państw, które zakażą korzystania z urządzeń sieciowych chińskiego giganta, dołączy Portugalia.

## Trzaskowski: Żeby pozbyć się rosyjskich wpływów, trzeba odsunąć PiS od władzy
 - [https://forsal.pl/gospodarka/polityka/artykuly/8724470,trzaskowski-zeby-pozbyc-sie-rosyjskich-wplywow-trzeba-odsunac-pis-od-wladzy.html](https://forsal.pl/gospodarka/polityka/artykuly/8724470,trzaskowski-zeby-pozbyc-sie-rosyjskich-wplywow-trzeba-odsunac-pis-od-wladzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 10:27:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2fKktkuTURBXy84OGRlYjE2ZC0wOTg5LTQ4ZjgtODMwYi1hNTA5MWE0YzRiZWMuanBlZ5GTBc0BHcyg" />Prezydent RP zdecydował się na podpisanie ustawy o powołaniu Komisji ds. badania wpływów rosyjskich, a także tego, że skieruje ją w trybie następczym do Trybunału Konstytucyjnego. Jednak według prezydenta Warszawy to partia rządząca stosuje politykę rosyjską.

## Państwowa Komisja będzie badać wpływy rosyjskie na Polskę w latach 2007-2022
 - [https://forsal.pl/gospodarka/polityka/artykuly/8724420,panstwowa-komisja-bedzie-badac-wplywy-rosyjskie-na-polske-w-latach-2007-2022.html](https://forsal.pl/gospodarka/polityka/artykuly/8724420,panstwowa-komisja-bedzie-badac-wplywy-rosyjskie-na-polske-w-latach-2007-2022.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 08:57:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mrnktkuTURBXy82ZWJhYzExMC1jNTI1LTRmMDUtOTA1Ny04YjY5ZDVmZGU3ZjkuanBlZ5GTBc0BHcyg" />Prezydent podpisał ustawę o powołaniu Państwowej Komisji ds. badania wpływów rosyjskich na bezpieczeństwo wewnętrzne RP w latach 2007-2022.

## W Kijowie alarm lotniczy. Słychać odgłosy eksplozji
 - [https://forsal.pl/swiat/ukraina/artykuly/8724417,w-kijowie-alarm-lotniczy-slychac-odglosy-eksplozji.html](https://forsal.pl/swiat/ukraina/artykuly/8724417,w-kijowie-alarm-lotniczy-slychac-odglosy-eksplozji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 08:50:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mNJktkuTURBXy9iNGExODQ5OC1iN2M4LTRmMTgtOWY5MC1kMDliNzgyMDU0YmEuanBlZ5GTBc0BHcyg" />W ukraińskiej stolicy ogłoszono w poniedziałek alarm lotniczy. Media informują o odgłosach eksplozji.

## Polskie firmy chcą się włączyć w budowę morskich farm wiatrowych [BADANIE]
 - [https://forsal.pl/biznes/ekologia/artykuly/8724415,polskie-firmy-chca-sie-wlaczyc-w-budowe-morskich-farm-wiatrowych-badanie.html](https://forsal.pl/biznes/ekologia/artykuly/8724415,polskie-firmy-chca-sie-wlaczyc-w-budowe-morskich-farm-wiatrowych-badanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 08:45:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/y9-ktkuTURBXy9hZGRjYWUzOC0zMWIzLTQyNGYtOTk3Zi0xMWNjMDM3ZTlhNzcuanBlZ5GTBc0BHcyg" />undefined

## Etniczni Serbowie próbowali przejąć siedziby władz lokalnych w Kosowie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8724408,etniczni-serbowie-probowali-przejac-siedziby-wladz-lokalnych-w-kosowie.html](https://forsal.pl/swiat/aktualnosci/artykuly/8724408,etniczni-serbowie-probowali-przejac-siedziby-wladz-lokalnych-w-kosowie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 08:40:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ywKktkuTURBXy9lMTUyNjk0MS0xMzFhLTRhODYtYjlmNi1jZWQwZGJjN2U2OTIuanBlZ5GTBc0BHcyg" />Etniczni Serbowie próbowali w poniedziałek rano opanować siedziby władz lokalnych w Kosowie po tym jak w ubiegłym tygodniu burmistrzowie albańskiego pochodzenia wkroczyli do swoich biur w eskorcie policji - poinformowała agencja AP.

## Grupa Wagnera w Afryce. To zagrożenie dla misji pokojowych
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8724397,grupa-wagnera-w-afryce-to-zagrozenie-dla-misji-pokojowych.html](https://forsal.pl/swiat/aktualnosci/artykuly/8724397,grupa-wagnera-w-afryce-to-zagrozenie-dla-misji-pokojowych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 08:16:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UXZktkuTURBXy81ZWI0YmQzNi1hNWYyLTQ3ZDgtYjgwNi1mYjMxYzQzYTg0ZjAuanBlZ5GTBc0BHcyg" />Obecność w Afryce powiązanej z Rosją firmy najemniczej Grupa Wagnera zagraża misjom pokojowym - głosi opublikowany w poniedziałek raport Sztokholmskiego Międzynarodowego Instytutu Badań nad Pokojem (SIPRI). Ogółem w 2022 roku na świecie przeprowadzono 64 operacje rozjemcze; jest to największa liczba od 10 lat.

## Ile wyniesie inflacja konsumencka w maju?
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8724379,ile-wyniesie-inflacja-konsumencka-w-maju.html](https://forsal.pl/gospodarka/inflacja/artykuly/8724379,ile-wyniesie-inflacja-konsumencka-w-maju.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 07:52:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/H-HktkuTURBXy9jNTQ1NTkxOS0wYTQ3LTQ2MzAtOGIwZC01NzlhNTExNjUxYTQuanBlZ5GTBc0BHcyg" />undefined

## Ile wydamy na prezenty z okazji Dnia Dziecka? [BADANIE]
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8724332,ile-wydamy-na-prezenty-z-okazji-dnia-dziecka-badanie.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8724332,ile-wydamy-na-prezenty-z-okazji-dnia-dziecka-badanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 07:16:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3RfktkuTURBXy84OTZkODRiMC05NjNhLTRhMjktYWNhZC01ODM5MjgzYmU1OGUuanBlZ5GTBc0BHcyg" />undefined

## RPP: Prawdopodobieństwo obniżek stóp procentowych w tym roku jest coraz większe
 - [https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8724311,rpp-prawdopodobienstwo-obnizek-stop-procentowych-w-tym-roku-jest-coraz-wieksze.html](https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8724311,rpp-prawdopodobienstwo-obnizek-stop-procentowych-w-tym-roku-jest-coraz-wieksze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 07:03:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_vKktkuTURBXy8yNGIwNDdiMS1kMjJhLTRhMmEtYjViNi1kNDc3MTJlMzg3OTcuanBlZ5GTBc0BHcyg" />undefined

## NASA wynajmie pojazdy księżycowe od firm kosmicznych
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8724272,nasa-wynajmie-pojazdy-ksiezycowe-od-firm-kosmicznych.html](https://forsal.pl/biznes/aktualnosci/artykuly/8724272,nasa-wynajmie-pojazdy-ksiezycowe-od-firm-kosmicznych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 06:28:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Sf8ktkuTURBXy8wOGM5ZmU1YS0zZjdjLTQ1ZDQtODVmYS00ZDg0NTM0YTUwNGQuanBlZ5GTBc0BHcyg" />Amerykańska agencja kosmiczna NASA chciałaby, aby astronauci w projekcie Artemis mogli poruszać się po Księżycu w pojazdach nowej generacji. Planuje wynajmować je jako usługę od firm przemysłu kosmicznego.

## Kursy walut: Złoty stracił wobec euro, dolara i franka
 - [https://forsal.pl/finanse/waluty/artykuly/8724270,kursy-walut-zloty-stracil-wobec-euro-dolara-i-franka.html](https://forsal.pl/finanse/waluty/artykuly/8724270,kursy-walut-zloty-stracil-wobec-euro-dolara-i-franka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 06:26:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oD6ktkuTURBXy9lMDY0N2Q2Yy0yN2U4LTRmOGYtOWI1MC1jOTIzMTA0ZGE1OWQuanBlZ5GTBc0BHcyg" />W poniedziałek ok. godz. 7.00 polska waluta straciła na wartości wobec euro, dolara amerykańskiego i franka szwajcarskiego. Euro kosztowało nieco ponad 4,53 zł, dolar 4,22 zł, a frank szwajcarski ponad 4,66 zł.

## Sztuczna inteligencja pomogła odkryć antybiotyk przeciwko superbakterii
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8724269,sztuczna-inteligencja-pomogla-odkryc-antybiotyk-przeciwko-superbakterii.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8724269,sztuczna-inteligencja-pomogla-odkryc-antybiotyk-przeciwko-superbakterii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 06:24:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kXCktkuTURBXy9mN2M4MGVhMy05MzY0LTQ3NmUtODY4ZC1mZjlmYjg0MGNlNjUuanBlZ5GTBc0BHcyg" />Dzięki wykorzystaniu sztucznej inteligencji (AI) udało się odkryć nowy antybiotyk, który może zwalczać zagrażający życiu gatunek superbakterii – informuje pismo &quot;Nature Chemical Biology&quot;.

## Polacy boją się, że 800 plus podniesie inflację [SONDAŻ]
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8724265,polacy-boja-sie-ze-800-plus-podniesie-inflacje-sondaz.html](https://forsal.pl/gospodarka/inflacja/artykuly/8724265,polacy-boja-sie-ze-800-plus-podniesie-inflacje-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 06:22:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/I-VktkuTURBXy84NTQ3OGUxNy0zMjQyLTQ2NWUtYjAyNC1lMzhlODE3NmI3NTkuanBlZ5GTBc0BHcyg" />65,1 proc. Polaków jest przekonanych, że podwyższenie świadczenia 500 plus do 800 złotych wpłynie na wzrost inflacji w Polsce. 1,9 proc. badanych uważa, że podwyżka inflację zmniejszy - wynika z sondażu IBRiS dla Radia ZET.

## Biden do Erdogana: Liczę na dalszą współpracę w ramach NATO
 - [https://forsal.pl/swiat/artykuly/8724260,biden-do-erdogana-licze-na-dalsza-wspolprace-w-ramach-nato.html](https://forsal.pl/swiat/artykuly/8724260,biden-do-erdogana-licze-na-dalsza-wspolprace-w-ramach-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 06:14:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MG9ktkuTURBXy9jY2YxNjJjZi1iYjdhLTRjOGQtYjZkMy05OWY1NzJjMjI4N2YuanBlZ5GTBc0BHcyg" />Prezydent USA Joe Biden pogratulował w niedzielę wpisem na Twitterze prezydentowi Turcji Recepowi Tayyipowi Erdoganowi zwycięstwa w wyborach podkreślając jednocześnie, że spodziewa się &quot;dalszej współpracy, jako sojusznicy w NATO, w sprawach bilateralnych i wyzwaniach globalnych&quot;.

## USA: Porozumienie w sprawie limitu zadłużenia poskutkowało wzrostem cen ropy
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8724259,usa-porozumienie-w-sprawie-limitu-zadluzenia-poskutkowalo-wzrostem-cen-ropy.html](https://forsal.pl/biznes/aktualnosci/artykuly/8724259,usa-porozumienie-w-sprawie-limitu-zadluzenia-poskutkowalo-wzrostem-cen-ropy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 06:13:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rQ0ktkuTURBXy9lNWZhOWQ5OS0wZTdjLTQ2MTItYTRmMS1lYTEyZDk5ZDYyYjYuanBlZ5GTBc0BHcyg" />Ceny ropy na giełdzie paliw w Nowym Jorku powiększają wzrosty w reakcji na osiągnięcie w USA porozumienia w sprawie limitu zadłużenia - podają maklerzy.

## Będą sztywne kary za niezarejestrowanie pojazdu na czas
 - [https://forsal.pl/transport/aktualnosci/artykuly/8723968,beda-sztywne-kary-za-niezarejestrowanie-pojazdu-na-czas.html](https://forsal.pl/transport/aktualnosci/artykuly/8723968,beda-sztywne-kary-za-niezarejestrowanie-pojazdu-na-czas.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 05:59:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/05nktkuTURBXy8wYTE2M2E1ZC1jZjQxLTRlNWMtYjhiYS1mN2I1YmYzZjg1N2YuanBlZ5GTBc0BHcyg" />Wysokość kary za niedopełnienie obowiązku rejestracji pojazdu lub zawiadomienia o jego zbyciu wynosi dziś od 200 zł do 1 tys. zł. Przepisy nie określają kryteriów, kiedy można poprzestać na dolnej granicy kary, a kiedy zasadne jest nałożenie surowszej. Teraz kara pieniężna ma być określona na sztywno, a to za sprawą autopoprawki zgłoszonej do… ustawy o ograniczaniu niektórych skutków kradzieży tożsamości, która wprowadziła zmiany do prawa o ruchu drogowym, które mają określać sztywną wysokość administracyjnej kary pieniężnej.

## Znikający Polacy. 500 plus nie poprawiło dzietności
 - [https://forsal.pl/gospodarka/demografia/artykuly/8724065,znikajacy-polacy-500-plus-nie-poprawilo-dzietnosci.html](https://forsal.pl/gospodarka/demografia/artykuly/8724065,znikajacy-polacy-500-plus-nie-poprawilo-dzietnosci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 05:53:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/v3iktkuTURBXy85OTQ5NmJmNi01OWNlLTRjZjEtOTU2Mi05MWJhZDFkYjhiNmUuanBlZ5GTBc0BHcyg" />Niezależnie od tego, czy 500 plus, czy 800 plus, świadczenie to będzie wypłacane ok. 100 tys. dzieci mniej niż w momencie, gdy program był wprowadzany w 2016 r.

## Los komisji w rękach prezydenta
 - [https://forsal.pl/gospodarka/polityka/artykuly/8724053,los-komisji-w-rekach-prezydenta.html](https://forsal.pl/gospodarka/polityka/artykuly/8724053,los-komisji-w-rekach-prezydenta.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 05:40:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NNoktkuTURBXy9mNzUxNDNhNi03MzdiLTQ1MDAtODNlNi00Y2Y5NTEyZWE4NDkuanBlZ5GTBc0BHcyg" />Z nieoficjalnych informacji z obozu władzy wynika, że prezydent skłania się do tego, by nie blokować powołania komisji do badania rosyjskich wpływów.

## Gdzie jest najwięcej myśliwców F-16? Kilka krajów ma 3/4 światowej floty [MAPA]
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8723370,gdzie-jest-najwiecej-mysliwcow-f-16-kilka-krajow-ma-34-swiatowej-floty-mapa.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8723370,gdzie-jest-najwiecej-mysliwcow-f-16-kilka-krajow-ma-34-swiatowej-floty-mapa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9eWktkuTURBXy8wNDEyNjdkNC04MTMyLTQxY2EtYWJkZS00NTc4NzBkZjNjMTMuanBlZ5GTBc0BHcyg" />Podczas szczytu G7, który odbył się w dniach 19-21 maja w Japonii, prezydent USA Joe Biden zezwolił innym państwom na dostawy na Ukrainę myśliwców F-16 produkowanych przez amerykańską firmę Lockheed Martin. Zobacz, które kraje mają w użyciu najwięcej samolotów F-16.

## Rosja powodem frustracji krajów OPEC? Chodzi o obietnicę ograniczenia produkcji ropy
 - [https://forsal.pl/biznes/energetyka/artykuly/8723449,rosja-powodem-frustracji-krajow-opec-chodzi-o-obietnice-ograniczenia-produkcji-ropy.html](https://forsal.pl/biznes/energetyka/artykuly/8723449,rosja-powodem-frustracji-krajow-opec-chodzi-o-obietnice-ograniczenia-produkcji-ropy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EYWktkuTURBXy8wNGI0NGQ5MS05MDQ3LTQ0ZjEtYTkyNy03NmMyMDYzOWIyMTkuanBlZ5GTBc0BHcyg" />Gdziekolwiek spojrzeć, jest bardzo mało oznak, że Rosja ogranicza produkcję ropy. Wbrew temu, co twierdzą prezydent Władimir Putin i inni urzędnicy z Moskwy.

## Sami twórcy nie są pewni, kto miałby tego słuchać. Podcasty generowane przez AI (też) już istnieją
 - [https://forsal.pl/lifestyle/technologie/artykuly/8723323,sami-tworcy-nie-sa-pewni-kto-mialby-tego-sluchac-podcasty-generowane-przez-ai-tez-juz-istnieja.html](https://forsal.pl/lifestyle/technologie/artykuly/8723323,sami-tworcy-nie-sa-pewni-kto-mialby-tego-sluchac-podcasty-generowane-przez-ai-tez-juz-istnieja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GYQktkuTURBXy8zOTYxNjEyNi1jNmMwLTQ5OGMtODM0OS1hZTM5M2RlYmEyNWEuanBlZ5GTBc0BHcyg" />Rynek podcastów, zwłaszcza tych anglojęzycznych, jest mocno nasycony. Kate Knibbs w „Wired” podaje, że baza Podcast Index wymienia ponad 4 miliony tytułów. True crime, filozofia, obsesyjna analiza jednego z seriali, prawa zwierząt, technologia, matematyka – ciężko wymyślić temat, na który nie powstałby chociaż jeden. Jest w czym wybierać. A mimo to są firmy, które konstruują narzędzia mające służyć generowaniu podcastów za pomocą sztucznej inteligencji.

## Samochód królem transportu w USA. Dlaczego Amerykanie unikają rowerów?
 - [https://forsal.pl/transport/artykuly/8723382,samochod-krolem-transportu-w-usa-dlaczego-amerykanie-unikaja-rowerow.html](https://forsal.pl/transport/artykuly/8723382,samochod-krolem-transportu-w-usa-dlaczego-amerykanie-unikaja-rowerow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-05-29 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VD5ktkuTURBXy82M2Y5ZWI5NS0zZDZmLTQ5NTQtYjY5ZS0xNDg5MDgyZGM5YjIuanBlZ5GTBc0BHcyg" />Według Statista Consumer Insights, 73 procent amerykańskich obywateli dojeżdżających do pracy korzysta z własnego samochodu, co czyni go zdecydowanie najpopularniejszym środkiem transportu. Natomiast rower jako środek transportu to nadal rzadkość. Dlaczego?

