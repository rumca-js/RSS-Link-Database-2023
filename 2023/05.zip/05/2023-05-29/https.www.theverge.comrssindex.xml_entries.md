# Source:The Verge, URL:https://www.theverge.com/rss/index.xml, language:en-US

## League of Legends esports players voted ‘overwhelmingly’ for a walkout
 - [https://www.theverge.com/2023/5/29/23741567/league-of-legends-players-association-lcspa-walkout](https://www.theverge.com/2023/5/29/23741567/league-of-legends-players-association-lcspa-walkout)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-05-29 21:35:31+00:00

<figure>
      <img alt="Robert “Blaber” Huang of League of Legends team Cloud9." src="https://cdn.vox-cdn.com/thumbor/QtI8JJWOsVZu6oWt0-rMx358n1c=/0x1:2000x1334/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72322811/CYW_MSI_BRACKET_D6_2023_383.0.jpeg" />
        <figcaption>Photo by Colin Young-Wolff / Riot Games</figcaption>
    </figure>

  <p id="fEabfd">Players in the North American <em>League of Legends</em> esports league have voted to walk out in protest of Riot Games’ decision to no longer require franchises to field an amateur team. Since Riot’s announcement, many franchises have already dropped their amateur teams for the summer season, cutting off an important development pipeline for players who want to compete in the main League Championship Series (LCS). The vote, held by the LCSPA, which represents North American <em>League of Legends</em> esports players, passed “overwhelmingly,” <a href="https://twitter.com/NALCSPA/status/1663039093557608448">according to an early Monday tweet</a>.</p>
<p id="yw9nkv">It’s unclear exactly when the walkout will take place, but assuming the two sides don’t come to some sort of agreement, it seems likely it will happen at the start of the summer...</p>
  <p>
    <a href="https://www.theverge.com/2023/5/29/23741567/league-of-legends-players-association-lcspa-walkout">Continue reading&hellip;</a>
  </p>

## The Witcher is officially one of the most successful game series of all time
 - [https://www.theverge.com/2023/5/29/23741471/the-witcher-cd-projekt-red-cdpr-gaming-franchises](https://www.theverge.com/2023/5/29/23741471/the-witcher-cd-projekt-red-cdpr-gaming-franchises)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-05-29 18:57:19+00:00

<figure>
      <img alt="A screenshot from The Witcher 3: Wild Hunt." src="https://cdn.vox-cdn.com/thumbor/nzyynhRKV9DZXNsBkCAl1dh4cB4=/300x0:1920x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72322594/ss_5710298af2318afd9aa72449ef29ac4a2ef64d8e.0.jpg" />
        <figcaption>Image: CD Projekt Red</figcaption>
    </figure>

  <p id="tSPcCp"><em>The Witcher</em> is a juggernaut, and thanks to new data from <em>The Witcher</em> game developer CD Projekt Red (CDPR), we have a better idea of just how huge it really is. The studio revealed Monday that <em>The Witcher</em> video games have sold <a href="https://twitter.com/CDPROJEKTRED_IR/status/1663204245946900480">more than 75 million copies</a>, with <em>The Witcher 3: Wild Hunt</em> alone responsible for <a href="https://twitter.com/CDPROJEKTRED_IR/status/1663203765187485705">more than 50 million of those sales</a>.</p>
<p id="Fi4shA">Those sorts of numbers mean that series is one of the biggest video game franchises of all time. For comparison, this new data puts <em>The Witcher 3</em> in spitting distance of smash hits like <a href="https://www.nintendo.co.jp/ir/en/finance/software/index.html"><em>Mario Kart 8 Deluxe</em></a> and <a href="https://www.gamespot.com/articles/gta-sells-5m-copies-in-past-3-months-jumps-to-180-million-in-total-sales/1100-6514297/"><em>Red Dead Redemption 2</em></a>, which have both sold more than 53 million copies, and both of those are <a href="https://en.wikipedia.org/wiki/List_of_best-selling_video_games">among the top-selling games ever</a>.</p>
<div class="c-float-left c-float-hang"><aside id="fgdKiB"><div></div></aside></div>
<p id="q1Urxo">Those <em>Witcher</em> sales numbers will probably grow by quite a bit...</p>
  <p>
    <a href="https://www.theverge.com/2023/5/29/23741471/the-witcher-cd-projekt-red-cdpr-gaming-franchises">Continue reading&hellip;</a>
  </p>

## WhatsApp is working on usernames and screen sharing
 - [https://www.theverge.com/2023/5/29/23741313/whatsapp-user-names-screen-sharing-beta-test](https://www.theverge.com/2023/5/29/23741313/whatsapp-user-names-screen-sharing-beta-test)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-05-29 15:43:26+00:00

<figure>
      <img alt="An image showing the WhatsApp logo in black" src="https://cdn.vox-cdn.com/thumbor/_hsNyg7EGonXx7fKUb8MmDBimGA=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72322225/STK110_whats_app_Kradtke_01.0.jpg" />
        <figcaption>Image: The Verge</figcaption>
    </figure>

  <p id="JyZQiY">WhatsApp is developing a number of new features, including usernames and screen sharing, as reported by <a href="https://wabetainfo.com/whatsapp-news-of-the-week-username-and-screen-sharing-feature/"><em>WABetaInfo</em></a>.</p>
<p id="8Yao8o">The username feature was spotted in the beta version 2.23.11.15 for Android, and allows WhatsApp users to select a unique username attached to their account. The feature could mean that in the future, users could find each other by their username instead of using a phone number. Conversations that are started using a username are <a href="https://www.theverge.com/23186209/best-secure-messaging-apps-end-to-end-encryption-e2ee">end-to-end encrypted</a>, <a href="https://wabetainfo.com/whatsapp-beta-for-android-2-23-11-15-whats-new/">according to <em>WABetaInfo</em></a><em>. </em></p>
<p id="KstYwU">Some beta testers using the 2.23.11.19 version of the Android app also noticed a new screen sharing feature. After pressing the screen sharing button, users could confirm and begin sharing the contents of their screen on video calls. The feature also...</p>
  <p>
    <a href="https://www.theverge.com/2023/5/29/23741313/whatsapp-user-names-screen-sharing-beta-test">Continue reading&hellip;</a>
  </p>

## Computex 2023: all the news from Taiwan’s big PC show
 - [https://www.theverge.com/2023/5/29/23739290/computex-2023-laptop-pc-announcement-news](https://www.theverge.com/2023/5/29/23739290/computex-2023-laptop-pc-announcement-news)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-05-29 15:42:42+00:00

<figure>
      <img alt="Two visitors stand behind a desk with Computex logo during Computex 2018 at the Nangang Exhibition Center in Taipei." src="https://cdn.vox-cdn.com/thumbor/nFOb53NwuwXLl41iGHsSagSxyKk=/148x0:7344x4797/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72322223/967571974.0.jpg" />
        <figcaption>Photo by Sam Yeh / AFP via Getty Images</figcaption>
    </figure>

  <p>For one glorious week, PC enthusiasts will gather in Taipei.</p>
  <p>
    <a href="https://www.theverge.com/2023/5/29/23739290/computex-2023-laptop-pc-announcement-news">Continue reading&hellip;</a>
  </p>

## Logi Dock review: conference calls have never been so cute
 - [https://www.theverge.com/23728549/logitech-logi-dock-review-conference-laptop-docking-station](https://www.theverge.com/23728549/logitech-logi-dock-review-conference-laptop-docking-station)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-05-29 13:00:00+00:00

<p>Power, ports, and pretty lighting — for a price.</p>
  <p>
    <a href="https://www.theverge.com/23728549/logitech-logi-dock-review-conference-laptop-docking-station">Continue reading&hellip;</a>
  </p>

## The System Shock remake is a delightful surprise
 - [https://www.theverge.com/23738938/system-shock-remake-nightdive-review](https://www.theverge.com/23738938/system-shock-remake-nightdive-review)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-05-29 12:00:00+00:00

<figure>
      <img alt="A picture of a cyborg in the System Shock remake." src="https://cdn.vox-cdn.com/thumbor/sL6czUvlHpOLipDgHVkr5vgJreI=/130x0:2290x1440/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72321757/20230527221003_1.0.jpg" />
        <figcaption><em>POV: You are a pathetic creature of meat and bone.</em> | Nightdive Studios</figcaption>
    </figure>


  		 <p>Welcome to my death machine, interloper.</p>
  <p>
    <a href="https://www.theverge.com/23738938/system-shock-remake-nightdive-review">Continue reading&hellip;</a>
  </p>

## Watch this Nvidia demo and imagine actually speaking to AI game characters
 - [https://www.theverge.com/2023/5/28/23740908/nvidia-ace-demo-voice-ai-npc-game-characters](https://www.theverge.com/2023/5/28/23740908/nvidia-ace-demo-voice-ai-npc-game-characters)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-05-29 03:15:59+00:00

<figure>
      <img alt="A cyberpunk ramen shop owner rendered digitally with AI voiceover responding to human input." src="https://cdn.vox-cdn.com/thumbor/NPCRa0c_ov8-uQVra9mBYasEwpY=/270x50:1623x952/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72321299/ACE_for_Games_Image.0.jpg" />
        <figcaption><em>A sample of Nvidia’s ACE (Avatar Cloud Engine) for games.</em> | Image: Nvidia</figcaption>
    </figure>

  <p id="tZGh2P"><a href="https://www.theverge.com/2023/5/27/23738895/nvidia-jensen-huang-computex-2023-keynote-how-to-watch">At Computex 2023</a> in Taipei, Nvidia CEO Jensen Huang just gave the world a glimpse of what it might be like when gaming and AI collide — with a graphically breathtaking recreation of a cyberpunk ramen shop where you can actually talk to the proprietor. </p>
<div id="hpc5Xz"><div style="width: 100%; height: 0; padding-bottom: 56.25%;"></div></div>
<p id="BPdMdi">Seriously, instead of clicking on dialogue options, it imagines you could hold down a button, <em>just say something with your own voice,</em> and get an answer from a video game character. Nvidia’s calling it a “peek at the future of games.” </p>
<p id="FIXul0">Unfortunately, the actual dialogue leaves a lot to be desired — maybe try GPT-4 <a href="https://www.theverge.com/2023/5/24/23732252/sudowrite-story-engine-ai-generated-cyberpunk-novella">or Sudowrite</a> next time, Nvidia? </p>
<p id="qOyNle">Here’s the entire conversation I hastily transcribed: </p>
<blockquote>
<p id="dQ6RcJ"><strong>Player: Hey Jin, how are you?</strong></p>
<p id="3cDkrd">Jin: Unfortunately not so good.</p>
<p id="Pp2JPI"><strong>How come?</strong></p>
<p id="S3ZzrX">I am worried...</p>
</blockquote>
  <p>
    <a href="https://www.theverge.com/2023/5/28/23740908/nvidia-ace-demo-voice-ai-npc-game-characters">Continue reading&hellip;</a>
  </p>

## Dolphin says Nintendo blocked a Steam release of its Wii and GameCube emulator
 - [https://www.theverge.com/2023/5/28/23740749/nintendo-wii-dolphin-emulator-steam-pc-gaming](https://www.theverge.com/2023/5/28/23740749/nintendo-wii-dolphin-emulator-steam-pc-gaming)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-05-29 00:22:25+00:00

<figure>
      <img alt="The Steam brand logo against a blue and black backdrop" src="https://cdn.vox-cdn.com/thumbor/nQJsdgoCVQpKGW2wqWS8slttWSw=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72321142/STK138_Stream_Kradtke_02.0.jpg" />
        <figcaption>Image: <em>The Verge</em></figcaption>
    </figure>

  <p id="XafBvY">The Steam launch of Dolphin, an open-source emulator for the Wii and the GameCube, has been delayed indefinitely (via <a href="https://www.pcgamer.com/nintendo-sends-valve-dmca-notice-to-block-steam-release-of-wii-emulator-dolphin/"><em>PC Gamer</em></a>). A blog post by the developers says that’s due to a Nintendo “cease and desist citing the DMCA” (an <a href="https://web.archive.org/web/20230526232537/https://dolphin-emu.org/blog/2023/05/27/dolphin-steam-indefinitely-postponed/">earlier version</a> of the blog post simply said “issued a DMCA” but it has since been updated) after they’d <a href="https://dolphin-emu.org/blog/2023/03/28/coming-soon-dolphin-steam/">announced plans</a> for a Steam launch in March.</p>
<p id="Exzciu"><a href="https://dolphin-emu.org/blog/2023/05/27/dolphin-steam-indefinitely-postponed/"><strong>Dolphin Emulator Project</strong></a><strong>:</strong></p>
<blockquote>
<p id="c2jEhZ">It is with much disappointment that we have to announce that the Dolphin on Steam release has been indefinitely postponed. We were notified by Valve that Nintendo has issued a cease and desist citing the DMCA against Dolphin’s Steam page, and have removed Dolphin from Steam until the matter is settled. We are currently investigating our...</p>
</blockquote>
  <p>
    <a href="https://www.theverge.com/2023/5/28/23740749/nintendo-wii-dolphin-emulator-steam-pc-gaming">Continue reading&hellip;</a>
  </p>

