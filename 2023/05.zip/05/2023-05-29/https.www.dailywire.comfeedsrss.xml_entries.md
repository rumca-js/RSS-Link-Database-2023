# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Jewel Drives Wedge Between Fans With Indy 500 Take On National Anthem
 - [https://www.dailywire.com/news/jewel-drives-wedge-between-fans-with-indy-500-take-on-national-anthem](https://www.dailywire.com/news/jewel-drives-wedge-between-fans-with-indy-500-take-on-national-anthem)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 18:43:04+00:00

Singer-songwriter Jewel struck a sour note with some people while delighting others with her performance of the national anthem at the Indianapolis 500 on Sunday. Race fans at Indianapolis Motor Speedway cheered as the 49-year-old music artist, wearing a white outfit and sporting a checkered-flag bandana underneath a cowboy hat, ended a soulful rendition of ...

## On Memorial Day: We ‘Thank God That Such Men Lived’
 - [https://www.dailywire.com/news/on-memorial-day-we-thank-god-that-such-men-lived](https://www.dailywire.com/news/on-memorial-day-we-thank-god-that-such-men-lived)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 17:35:31+00:00

Because of my father, my family spends part of every Memorial Day at Jefferson Barracks National Cemetery. Captain John Thomas Greenplate (1954-2017) is buried there, and while he was not killed in action, he rests alongside many who did — and many more who would have, if they had been called upon to do so. ...

## New York Times Review Of ‘The Little Mermaid’ Laments Lack Of ‘Kink’ In Kids Movie
 - [https://www.dailywire.com/news/new-york-times-review-of-the-little-mermaid-laments-lack-of-kink-in-kids-movie](https://www.dailywire.com/news/new-york-times-review-of-the-little-mermaid-laments-lack-of-kink-in-kids-movie)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 17:32:43+00:00

Reviews of Disney’s remake of “The Little Mermaid” were mixed, with even the most generous viewers wondering if the film was necessary. But the review from movie critic Wesley Morris for The New York Times is getting attention for wondering about the lack of “kink” in the children’s movie. &#8220;The new, live-action ‘The Little Mermaid’ ...

## Monday Afternoon Update: Target Down $10 Billion, Debt Deal Latest, Rescue Efforts Underway In Davenport Iowa After Building Collapse
 - [https://www.dailywire.com/news/monday-afternoon-update-target-down-10-billion-debt-deal-latest-rescue-efforts-underway-in-davenport-iowa-after-building-collapse](https://www.dailywire.com/news/monday-afternoon-update-target-down-10-billion-debt-deal-latest-rescue-efforts-underway-in-davenport-iowa-after-building-collapse)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 17:25:59+00:00

This article is adapted from today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. 8 People Rescued After Apartment Building Partially Collapses In Iowa Authorities in Davenport, Iowa are conducting a massive search and rescue operation after a six-story apartment building partially collapsed Sunday evening. So far, authorities have not released the number ...

## ‘I Was Attacked Because I Didn’t Want To Have Sex With Him’: New Jersey Female Inmate Details Alleged Assault From Trans-Identified Male Transfer
 - [https://www.dailywire.com/news/i-was-attacked-because-i-didnt-want-to-have-sex-with-him-new-jersey-female-inmate-details-alleged-assault-from-trans-identified-male-transfer](https://www.dailywire.com/news/i-was-attacked-because-i-didnt-want-to-have-sex-with-him-new-jersey-female-inmate-details-alleged-assault-from-trans-identified-male-transfer)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 17:17:58+00:00

A New Jersey woman incarcerated at a state women&#8217;s correctional facility alleges a male transfer who identifies as female assaulted her after several instances of sexual harassment. Shakira Reed, an inmate at New Jersey&#8217;s Edna Mahan Correctional Facility for Women, told Reduxx in an exclusive report that a trans-identifying male named Jermain Gibson allegedly repeatedly ...

## Feinstein Confused By VP Harris Doing Her Job: Report
 - [https://www.dailywire.com/news/feinstein-confused-by-vp-harris-doing-her-job-report](https://www.dailywire.com/news/feinstein-confused-by-vp-harris-doing-her-job-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 16:14:35+00:00

In yet another report underscoring the health struggles of Sen. Dianne Feinstein (D-CA), the lawmaker appeared flummoxed by Vice President Kamala Harris presiding over the Senate. A source told The New York Times that last year Feinstein looked confused when Harris showed up to be a tie-breaking vote, which is one of the powers of ...

## Wanda Sykes Criticizes Dave Chappelle For ‘Hurtful And Damaging’ Trans Jokes
 - [https://www.dailywire.com/news/wanda-sykes-criticizes-dave-chappelle-for-hurtful-and-damaging-trans-jokes](https://www.dailywire.com/news/wanda-sykes-criticizes-dave-chappelle-for-hurtful-and-damaging-trans-jokes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 14:14:48+00:00

Wanda Sykes isn’t happy with her longtime friend and colleague Dave Chappelle making jokes about transgender people. Chappelle came under fire when his Netflix special “The Closer” came out in 2021. In it, the comedian claimed to be “Team TERF,” an acronym for trans-exclusionary radical feminist. He also defended “Harry Potter” author J.K. Rowling, who ...

## Texas Lawmakers Advance School Safety Bill Requiring Mental Health Training, Armed Security On Campuses
 - [https://www.dailywire.com/news/texas-lawmakers-advance-school-safety-bill-requiring-mental-health-training-armed-security-on-campuses](https://www.dailywire.com/news/texas-lawmakers-advance-school-safety-bill-requiring-mental-health-training-armed-security-on-campuses)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 14:03:40+00:00

Texas state lawmakers advanced a public school safety bill on Sunday requiring certain district employees to undergo mental health training and all campuses to staff at least one armed security guard during regular school hours. Both chambers passed House Bill 3 just more than a year after a lone gunman killed 19 children and two ...

## What A Recent Trip To Japan Taught Me About Modern America
 - [https://www.dailywire.com/news/what-a-recent-trip-to-japan-taught-me-about-modern-america](https://www.dailywire.com/news/what-a-recent-trip-to-japan-taught-me-about-modern-america)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 13:16:59+00:00

I felt something new on a recent international trip to Japan, something I&#8217;ve never felt in my travels to 23 countries across 5 continents. Something I&#8217;m not proud of as an American. I felt that the United States, in critical areas, is not only not a world leader, but it&#8217;s not even a model anymore. ...

## Woman Allegedly Drives Drunk Onto Florida Beach Narrowly Missing Child, Car Ends Up In Water
 - [https://www.dailywire.com/news/woman-allegedly-drives-drunk-onto-florida-beach-narrowly-missing-child-car-ends-up-in-water](https://www.dailywire.com/news/woman-allegedly-drives-drunk-onto-florida-beach-narrowly-missing-child-car-ends-up-in-water)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 13:13:52+00:00

A Florida woman was arrested and charged with driving under the influence after allegedly driving up to 50 mph on a crowded beach Saturday, nearly hitting a child.  The woman, 26-year-old Sarah Ramsammy of Orlando, drove on the shoreline of New Smyrna Beach as people flocked to the ocean for the holiday weekend. After driving ...

## ‘They Never Talked About The War’: Honoring Our World War II Veterans On Memorial Day With Author Andrew Biggio
 - [https://www.dailywire.com/news/they-never-talked-about-the-war-honoring-our-world-war-ii-veterans-on-memorial-day-with-author-andrew-biggio](https://www.dailywire.com/news/they-never-talked-about-the-war-honoring-our-world-war-ii-veterans-on-memorial-day-with-author-andrew-biggio)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 12:41:00+00:00

The following interview transcript is taken from our special Memorial Day edition of Morning Wire. Andrew Biggio is a Marine veteran and author of “The Rifle.” He’s spent years traveling the country collecting and sharing the stories of America&#8217;s last living World War II veterans, many of whom – in their 90s or early 100s ...

## Russia Seeks Arrest Of Sen. Lindsey Graham
 - [https://www.dailywire.com/news/russia-seeks-arrest-of-sen-lindsey-graham](https://www.dailywire.com/news/russia-seeks-arrest-of-sen-lindsey-graham)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 12:38:14+00:00

Russia issued a warrant on Monday seeking the arrest of Sen. Lindsey Graham (R-SC) after the release of an edited video that made it appear the lawmaker was celebrating the United States spending money on the killing of Russians in Ukraine. After top Russian investigator Alexander Bastrykin ordered criminal proceedings, the Russian Interior Ministry added ...

## ‘Sinister, Nefarious, And Dangerous’: Federal Government Watchdog Slammed For Memo Urging Woke Language
 - [https://www.dailywire.com/news/sinister-nefarious-and-dangerous-federal-government-watchdog-slammed-for-memo-urging-woke-language](https://www.dailywire.com/news/sinister-nefarious-and-dangerous-federal-government-watchdog-slammed-for-memo-urging-woke-language)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 12:15:29+00:00

Even a supposed federal government watchdog has gone radically woke, prompting harsh criticism from conservatives. A leaked October 2022 memo from the Government Accountability Office (GAO) — which examines government spending and is considered the supreme audit institution of the federal government of the United States — was obtained by The Daily Mail and reveals the ...

## ‘Twilight’ Star Rachelle Lefevre Whines About Target Moving Pride Collection, Says She Has ‘Non-Binary’ 7-Year-Old
 - [https://www.dailywire.com/news/twilight-star-rachelle-lefevre-whines-about-target-moving-pride-collection-says-she-has-non-binary-7-year-old](https://www.dailywire.com/news/twilight-star-rachelle-lefevre-whines-about-target-moving-pride-collection-says-she-has-non-binary-7-year-old)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 11:55:34+00:00

“Twilight” actress Rachelle Lefevre made a video accusing Target of “trying to erase” LGBTQ people because the retailer opted to move its Pride collection to the back of the store. “I came in here two days ago and my 7-year-old, who’s nonbinary, saw it and said, ‘Look, Mom, it’s pride Look, they’re going to celebrate ...

## Lululemon Employees Fired After Confronting Thieves: Reports
 - [https://www.dailywire.com/news/lululemon-employees-fired-after-confronting-thieves-reports](https://www.dailywire.com/news/lululemon-employees-fired-after-confronting-thieves-reports)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 11:29:05+00:00

Two women say they were fired by Lululemon after trying to stop thieves ransacking an Atlanta-area store and calling police to report the robbery last month. The former employees, Rachel Rogers and Jennifer Ferguson, said they were told they violated the &#8220;athleisure&#8221; company&#8217;s &#8220;zero-tolerance policy&#8221; upon being let go in the weeks that followed the ...

## 8 People Rescued After Apartment Building Partially Collapses In Iowa
 - [https://www.dailywire.com/news/8-people-rescued-after-apartment-building-partially-collapses-in-iowa](https://www.dailywire.com/news/8-people-rescued-after-apartment-building-partially-collapses-in-iowa)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 11:10:10+00:00

Authorities have rescued eight people as search efforts continue after an apartment building in Davenport, Iowa, partially collapsed Sunday evening.  First responders arrived on the scene around 5:00 p.m. local time Sunday to find that a large section of the six-story building had given way. Seven people were rescued immediately, and an eighth person trapped ...

## Jane Fonda Blames White Men For ‘Climate Crisis,’ Demands Their Imprisonment
 - [https://www.dailywire.com/news/jane-fonda-blames-white-men-for-climate-crisis-demands-their-imprisonment](https://www.dailywire.com/news/jane-fonda-blames-white-men-for-climate-crisis-demands-their-imprisonment)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 09:23:20+00:00

Actress Jane Fonda, whose leftist views have engendered harsh criticism over the decades, added to her radical resume over the weekend, holding white men responsible for the “climate crisis” and demanding their imprisonment. Fonda made her remarks at the Cannes Film Festival on Saturday. “This is serious,” Fonda charged, according to Outkick. “We’ve got about seven, ...

## ‘Another Company Needing Bud-Lighting’: Kohl’s Ripped For Infant LGBT Merchandise
 - [https://www.dailywire.com/news/another-company-needing-bud-lighting-kohls-ripped-for-infant-lgbt-merchandise](https://www.dailywire.com/news/another-company-needing-bud-lighting-kohls-ripped-for-infant-lgbt-merchandise)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-29 08:47:36+00:00

Kohl&#8217;s has joined Target and Bud Light in the group of companies ripped for their woke products as the retailer is being slammed for selling LGBTQ clothing for infants. To celebrate Pride Month in June, Kohl’s is selling onesies with the LGBTQ pride flag on them. The company’s merchandise includes the “baby Sonoma Community Pride ...

