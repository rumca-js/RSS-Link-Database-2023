# Source:Techlore, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg, language:en-US

## Aurora Users: Proceed with Caution!
 - [https://www.youtube.com/watch?v=NNyqbT_xvPA](https://www.youtube.com/watch?v=NNyqbT_xvPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg
 - date published: 2023-05-29 06:30:53+00:00

For More Info: https://discuss.techlore.tech/t/aurora-store-anonymous-logins-are-removed-indefinitely/3817
To Support Aurora: https://auroraoss.com/

Aurora is a staple tool for people looking to de-google their Android devices. Currently, the anonymous login functionality is not working - and Google is rumored to be deleting some Google accounts used through Aurora. Proceed with caution, spread the word, and support the Aurora project if you’re able. Aurora is looking into options to bring back anon login, so let’s support and do our best to be patient 🚀 

🔐 Our Website: https://techlore.tech
🏫 Techlore Coaching - to get direct support: https://techlore.tech/coaching
🕵 Go Incognito Course - to learn about privacy: https://techlore.tech/goincognito

Connect with our privacy community:
✉️ Blog: https://dispatch.techlore.tech
💻 Forum: https://discuss.techlore.tech
Ⓜ️ Mastodon: https://social.lol/@techlore

We provide all content & resources for free, please consider supporting our work to help us expand our content:
🧡 Patreon: https://www.patreon.com/techlore
💖 All Other Support Methods: https://techlore.tech/support
#aurora #techlore #shorts

