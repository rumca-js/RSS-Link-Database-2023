# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## FirstFT: AI is creating a ‘new computing era’
 - [https://www.ft.com/content/b3347bd8-49cc-4d7a-9efd-215ff430fe1a](https://www.ft.com/content/b3347bd8-49cc-4d7a-9efd-215ff430fe1a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 21:27:26+00:00

Plus, new corruption allegations in India and PwC suspends nine partners over Australia tax leak scandal

## Kosovo erupts in violence as ethnic Serbs bar Albanian mayors from taking office
 - [https://www.ft.com/content/a499014a-4615-4842-809c-56c2261f3f47](https://www.ft.com/content/a499014a-4615-4842-809c-56c2261f3f47)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 20:49:02+00:00

Dozens of protesters and 25 Nato peacekeepers injured in clashes following disputed elections

## Labour plans to tackle housing crisis by forcing landowners to sell at lower prices
 - [https://www.ft.com/content/87d76063-66a8-4803-b134-45988a5218bd](https://www.ft.com/content/87d76063-66a8-4803-b134-45988a5218bd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 19:00:20+00:00

Reforms would change valuation of plots acquired in England through compulsory purchase orders

## ‘All or nothing’: Spain’s Pedro Sánchez gambles on snap election
 - [https://www.ft.com/content/2e9fc437-788c-47e2-989b-c5dcb848835e](https://www.ft.com/content/2e9fc437-788c-47e2-989b-c5dcb848835e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 17:54:40+00:00

Embattled prime minister makes riskiest bet of his career to hold on to power after disastrous showing in local polls

## Cabinet Office in stand-off with Covid inquiry over Johnson messages
 - [https://www.ft.com/content/2f4f128d-edb9-4a66-9e3f-ae4b85ef51c3](https://www.ft.com/content/2f4f128d-edb9-4a66-9e3f-ae4b85ef51c3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 17:19:16+00:00

Tensions between investigators and ministers build as government refuses to hand over unredacted information

## India files criminal complaint against Rolls-Royce and BAE
 - [https://www.ft.com/content/5de6e985-5798-443c-bd1b-e50cea471aeb](https://www.ft.com/content/5de6e985-5798-443c-bd1b-e50cea471aeb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 16:45:51+00:00

Groups accused over historic deals to supply country with fighter jets

## Turkey’s lira weakens as economists warn of economic challenge
 - [https://www.ft.com/content/246951b4-1bcd-4144-a9c9-33f9f6c3e107](https://www.ft.com/content/246951b4-1bcd-4144-a9c9-33f9f6c3e107)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 16:39:55+00:00

Re-elected Erdoğan insists interest rates should stay low despite inflation running at more than 40 per cent

## The UK needs a new deal for its highly taxed graduates
 - [https://www.ft.com/content/e0666337-ace0-44db-ad67-b4c88470dc36](https://www.ft.com/content/e0666337-ace0-44db-ad67-b4c88470dc36)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 15:30:20+00:00

Repayments under the student loan system hinder their potential contributions to the economy

## Russia pounds Ukraine with missile and drone barrage
 - [https://www.ft.com/content/ce61ee12-fec6-43f4-8ff9-696ecbdd738c](https://www.ft.com/content/ce61ee12-fec6-43f4-8ff9-696ecbdd738c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 13:27:57+00:00

Strikes beyond front lines aim to deplete stock of western-supplied air defence systems ahead of counter-offensive

## We need to build a new business case for nature
 - [https://www.ft.com/content/f1aaba0f-64f0-4528-86d0-8d6513d88e4e](https://www.ft.com/content/f1aaba0f-64f0-4528-86d0-8d6513d88e4e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 12:02:52+00:00

Those fighting the biodiversity crisis are still stuck in the old model of conservation — climate tech indicates a fresh path

## US retail investors: losing their animal spirits
 - [https://www.ft.com/content/dc0f69b5-e363-4ffc-ae7e-f74bf7aace6b](https://www.ft.com/content/dc0f69b5-e363-4ffc-ae7e-f74bf7aace6b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 11:30:17+00:00

Equity markets have rallied strongly in the first half of the year, but maintaining momentum could be a struggle

## De-risking trade with China is a risky business
 - [https://www.ft.com/content/1caf3dd9-1097-4de2-9b57-80b70e465154](https://www.ft.com/content/1caf3dd9-1097-4de2-9b57-80b70e465154)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 10:55:13+00:00

Security-driven approach to trade clashes with western corporate interests and environmental targets

## Democrats and Republicans confident they can pass deal to avert US default
 - [https://www.ft.com/content/6a74e4b3-2476-4b71-b964-29299ae32aaa](https://www.ft.com/content/6a74e4b3-2476-4b71-b964-29299ae32aaa)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 10:15:17+00:00

Centrists in both parties back agreement to raise borrowing limit despite opposition of hardliners

## What is in the US debt ceiling deal?
 - [https://www.ft.com/content/078914f2-9559-4c81-8e6d-fb68b595736b](https://www.ft.com/content/078914f2-9559-4c81-8e6d-fb68b595736b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 10:15:17+00:00

Democrats and Republicans have made compromises to head off a damaging default

## Surge in shopping crime costing US retailers millions of dollars
 - [https://www.ft.com/content/1d43e0cb-704c-4049-95b5-08a7c96be0ca](https://www.ft.com/content/1d43e0cb-704c-4049-95b5-08a7c96be0ca)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 10:00:17+00:00

More frequent and more violent incidents are being reported this year

## Japan threatens to shoot down any North Korean missile that enters its territory
 - [https://www.ft.com/content/e4a1d0f0-084f-438a-bf21-05ed73131c7b](https://www.ft.com/content/e4a1d0f0-084f-438a-bf21-05ed73131c7b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 09:43:52+00:00

Tokyo puts ballistic missile defences on alert after Pyongyang signals imminent launch of military satellite

## Spain’s prime minister calls snap election after regional defeats
 - [https://www.ft.com/content/c9480e75-7acd-49a6-a97e-9af830ad4853](https://www.ft.com/content/c9480e75-7acd-49a6-a97e-9af830ad4853)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 09:40:48+00:00

Sánchez sets July date after resounding defeat for his Socialists at hands of centre right

## China developers: the main quake is over but the aftershocks are not
 - [https://www.ft.com/content/1dd14046-2164-4cf4-8b9f-06c2eaabfe61](https://www.ft.com/content/1dd14046-2164-4cf4-8b9f-06c2eaabfe61)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 08:30:18+00:00

Surge in court-ordered liquidations and developer defaults should give investors pause for thought

## ‘I can do it’: Erdoğan promises Turkey more strongman medicine
 - [https://www.ft.com/content/1b75ed7b-2b89-4b91-bf99-db3ea38872ef](https://www.ft.com/content/1b75ed7b-2b89-4b91-bf99-db3ea38872ef)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 06:44:37+00:00

Veteran leader faces economic reckoning after defeating rivals in Sunday’s presidential election

## An anxious future for Turkey’s economy and democracy
 - [https://www.ft.com/content/632f4eef-e50a-43d0-8375-8afdb8a7cd7e](https://www.ft.com/content/632f4eef-e50a-43d0-8375-8afdb8a7cd7e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 06:00:17+00:00

Recep Tayyip Erdoğan has little time to bask in his electoral triumph

## PwC suspends 9 partners over Australian tax leak scandal
 - [https://www.ft.com/content/358c5012-512c-4007-9f85-a664c6b6ec23](https://www.ft.com/content/358c5012-512c-4007-9f85-a664c6b6ec23)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 05:12:27+00:00

Big Four firm pledges to publish results from internal review this year

## Toyota chair faces removal vote over governance issues
 - [https://www.ft.com/content/f887b41d-eb90-4a41-bf82-d50b280cd2f6](https://www.ft.com/content/f887b41d-eb90-4a41-bf82-d50b280cd2f6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:40:44+00:00

More challenges to boards on diversity and corporate values expected during Japan’s annual meeting season

## Bank turmoil does not justify mission creep by deposit insurance
 - [https://www.ft.com/content/2865f500-4b33-4444-99fa-5060fe168ceb](https://www.ft.com/content/2865f500-4b33-4444-99fa-5060fe168ceb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:00:18+00:00

Higher levels of cover would increase implicit subsidies to reckless bankers

## Brussels proposes tough targets for live trading database operators
 - [https://www.ft.com/content/73780844-fc6f-4948-b56f-4e533af98960](https://www.ft.com/content/73780844-fc6f-4948-b56f-4e533af98960)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:00:18+00:00

Commission has suggested minimum turnover for companies running consolidated tape service

## ETF share of US market turnover jumps to a record 31%
 - [https://www.ft.com/content/86b40fb7-39d0-4f2a-a651-5f71b8b98190](https://www.ft.com/content/86b40fb7-39d0-4f2a-a651-5f71b8b98190)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:00:18+00:00

Surge reignites debate over ETF influence and underlines increasing use to rapidly change market exposure

## Economy and insecurity top agenda for Nigeria’s new president
 - [https://www.ft.com/content/ef16b792-8438-44cf-b36b-dd3e05e50086](https://www.ft.com/content/ef16b792-8438-44cf-b36b-dd3e05e50086)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:00:18+00:00

Bola Tinubu will face an overflowing in-tray following his inauguration on Monday

## Emerging markets warned against swift rate cuts until inflation is under control
 - [https://www.ft.com/content/595d4403-7987-4072-8768-394b61cfe767](https://www.ft.com/content/595d4403-7987-4072-8768-394b61cfe767)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:00:18+00:00

Fuel and food costs ease in central Europe and Latin America but core price pressures upset plans to kick-start growth

## Larger UK companies predicted to fall into administration as inflation bites
 - [https://www.ft.com/content/e983b7d4-5e8f-4909-9835-5992200a09f0](https://www.ft.com/content/e983b7d4-5e8f-4909-9835-5992200a09f0)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:00:18+00:00

Smaller businesses have so far dominated rising levels of insolvencies, says recovery specialist

## Prince Harry takes on Fleet Street over phone hacking
 - [https://www.ft.com/content/eceffd65-d668-49a3-a3b9-2199cd2dd042](https://www.ft.com/content/eceffd65-d668-49a3-a3b9-2199cd2dd042)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:00:18+00:00

New round of lawsuits brings scandal back to fore and poses fresh financial risks for tabloid media groups

## Ukraine war opens door for Moldova to end its frozen conflict
 - [https://www.ft.com/content/4a9603cb-709c-4137-9530-9f568ab11aab](https://www.ft.com/content/4a9603cb-709c-4137-9530-9f568ab11aab)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:00:18+00:00

Russian-backed separatist enclave of Transnistria is increasingly reliant on western trade after Kyiv closed its border

## ‘We are all thinking about how to contribute’: Hongkongers boost Britain’s suburbs
 - [https://www.ft.com/content/9089a988-2467-46a5-91cf-59738e019b8a](https://www.ft.com/content/9089a988-2467-46a5-91cf-59738e019b8a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 04:00:18+00:00

Immigration influx brings a highly skilled workforce that is eager to integrate

## ‘Genshin Impact’ maker aims for Tencent’s China gaming crown
 - [https://www.ft.com/content/c97f7266-7c51-4616-a086-7d6b585001fe](https://www.ft.com/content/c97f7266-7c51-4616-a086-7d6b585001fe)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 01:00:17+00:00

Independent studio miHoYo pins hopes on new title to take on big incumbents in lucrative market

## ByteDance and CNPC take over Hong Kong offices vacated by foreign companies
 - [https://www.ft.com/content/0c9d6fe0-96b4-43c9-9924-5ab11a4facab](https://www.ft.com/content/0c9d6fe0-96b4-43c9-9924-5ab11a4facab)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 00:30:17+00:00

Mainland Chinese businesses are among those securing prime locations in Central district

## China’s economy loses steam as concerns mount over Covid recovery
 - [https://www.ft.com/content/e2aaaa56-5dee-41be-9ed4-181496de6bf3](https://www.ft.com/content/e2aaaa56-5dee-41be-9ed4-181496de6bf3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 00:01:17+00:00

Weak property sales, industrial output and consumption sap confidence in rapid bounceback for growth

## How to buy a global $20bn company for nothing
 - [https://www.ft.com/content/185c5169-35c1-45df-9102-e4c19b32cdfc](https://www.ft.com/content/185c5169-35c1-45df-9102-e4c19b32cdfc)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-05-29 00:00:17+00:00

Japan is only theoretically fertile territory for stock market takeovers, as the Toyota thought experiment reveals

