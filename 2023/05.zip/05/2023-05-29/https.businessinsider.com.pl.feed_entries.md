# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Brzezinski o lex Tusk: rząd USA podziela obawy
 - [https://businessinsider.com.pl/wiadomosci/brzezinski-o-lex-tusk-rzad-usa-podziela-obawy/yxkqxke](https://businessinsider.com.pl/wiadomosci/brzezinski-o-lex-tusk-rzad-usa-podziela-obawy/yxkqxke)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 18:37:48+00:00

Rząd USA podziela obawy związane z ustawami, które mogą pozwalać na zmniejszenie możliwości wyborców do głosowania na tych kandydatów, na których chcą głosować, ustawami omijającymi jasno określony proces przed niezawisłymi sądami — powiedział w TVN24 ambasador USA w Polsce Mark Brzezinski.

## Cena truskawek. Drogo, ale nie padł rekord
 - [https://businessinsider.com.pl/wiadomosci/po-ile-truskawki-jest-drogo-ale-nie-padl-rekord/re8lcl9](https://businessinsider.com.pl/wiadomosci/po-ile-truskawki-jest-drogo-ale-nie-padl-rekord/re8lcl9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 18:14:29+00:00

Za ile możemy kupić truskawki? Analitycy wzięli pod lupę ceny w maju. Wniosek? Wprawdzie w tym roku jest drogo, ale nie rekordowo drogo.

## Powstanie Wyższa Szkoła Straży Granicznej. Prezydent podpisał ustawę
 - [https://businessinsider.com.pl/wiadomosci/powstanie-wyzsza-szkola-strazy-granicznej-prezydent-podpisal-ustawe/7zp5jvc](https://businessinsider.com.pl/wiadomosci/powstanie-wyzsza-szkola-strazy-granicznej-prezydent-podpisal-ustawe/7zp5jvc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 18:12:21+00:00

Prezydent Andrzej Duda podpisał ustawę, która umożliwi powołanie Wyższej Szkoły Straży Granicznej w Koszalinie, a także zmieni nazwy Wyższej Szkoły Policji na Akademię Policji w Szczytnie oraz Szkoły Głównej Służby Pożarniczej na Akademię Pożarniczą. Ta ustawa ma historyczne znaczenie — powiedział.

## Scania zamyka fabrykę. Pracę straci ponad 800 osób
 - [https://businessinsider.com.pl/biznes/scania-zamyka-fabryke-w-slupsku-zwolni-ponad-800-osob/4zd60e6](https://businessinsider.com.pl/biznes/scania-zamyka-fabryke-w-slupsku-zwolni-ponad-800-osob/4zd60e6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 17:50:33+00:00

Scania zamknie fabrykę nadwozi autobusów w Słupsku, w której zatrudnionych jest 847 pracowników. Zakład ma przestać działać w pierwszym kwartale 2024 r.

## Nie wiesz, czy zmieścisz się w limicie taniego prądu? Te narzędzia mogą ci pomóc
 - [https://businessinsider.com.pl/poradnik-finansowy/nie-wiesz-czy-zmiescisz-sie-w-limicie-taniego-pradu-te-narzedzia-moga-ci-pomoc/fjexck9](https://businessinsider.com.pl/poradnik-finansowy/nie-wiesz-czy-zmiescisz-sie-w-limicie-taniego-pradu-te-narzedzia-moga-ci-pomoc/fjexck9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 17:39:08+00:00

Gospodarstwa domowe korzystają w tym roku z zamrożonych cen prądu, ale tylko do określonych przez ustawę limitów. Koncerny energetyczne przypominają, że 30 czerwca mija czas na składanie oświadczeń dla tych osób, które mają prawo do wyższych progów zużycia energii w niskiej cenie. Pokazują też narzędzia, które pomagają na bieżąco śledzić pobór prądu i obniżać rachunki.

## Bruksela reaguje na lex Tusk
 - [https://businessinsider.com.pl/wiadomosci/lex-tusk-pierwsze-komentarze-z-brukseli/3x0eywn](https://businessinsider.com.pl/wiadomosci/lex-tusk-pierwsze-komentarze-z-brukseli/3x0eywn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 16:52:26+00:00

Komisja Europejska zareagowała na decyzję prezydenta Andrzeja Dudy o podpisaniu tzw. lex Tusk. Jest też nieoficjalny komentarz z Brukseli na propozycję prezydenta, który chciałby komisji ds. wpływów rosyjskich na poziomie europejskim.

## Polska zamyka granicę dla białoruskich i rosyjskich ciężarówek
 - [https://businessinsider.com.pl/wiadomosci/polska-zamyka-granice-z-bialorusia-dla-bialoruskich-i-rosyjskich-ciezarowek/78bcqxl](https://businessinsider.com.pl/wiadomosci/polska-zamyka-granice-z-bialorusia-dla-bialoruskich-i-rosyjskich-ciezarowek/78bcqxl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 16:35:11+00:00

Od 1 czerwca do odwołania ruch towarowy na granicy z Białorusią zostanie zawieszony dla ciężarówek, ciągników samochodowych, przyczep, w tym naczep, oraz zespołów pojazdów zarejestrowanych na terytorium Białorusi i Rosji — stanowi rozporządzenie MSWiA.

## Nie tylko Tusk. Kto i za co powinien się bać speckomisji do badania wpływów rosyjskich
 - [https://businessinsider.com.pl/prawo/lex-tusk-kto-i-za-co-powinien-sie-bac-speckomisji/bp729k2](https://businessinsider.com.pl/prawo/lex-tusk-kto-i-za-co-powinien-sie-bac-speckomisji/bp729k2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 15:04:00+00:00

Pole rażenia lex Tusk jest ogromne. Specjalna komisja będzie mogła badać działalność nie tylko posłów, senatorów, radnych, pracowników administracji, ale też członków zarządu spółek i rad nadzorczych, dyrektorów i pracowników spółek. Na jej celowniku może się znaleźć nie tylko Donald Tusk, ale i sam Andrzej Duda. A uprawnienia komisji są ogromne.

## Orlen wraca z promocją na wakacje. Tankowanie znów będzie tańsze
 - [https://businessinsider.com.pl/poradnik-finansowy/orlen-wraca-z-promocja-na-wakacje-tankowanie-znow-bedzie-tansze/4c0ks03](https://businessinsider.com.pl/poradnik-finansowy/orlen-wraca-z-promocja-na-wakacje-tankowanie-znow-bedzie-tansze/4c0ks03)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 14:59:32+00:00

Orlen również w tym roku zamierza wprowadzić wakacyjne obniżki cen paliw na swoich stacjach — informuje "Rzeczpospolita". Według gazety kierowcy będą mogli otrzymać 30 gr zniżki za każdy kupiony litr diesla lub benzyny. Będą jednak limity.

## Wynajem tańszy niż kredyt 2 proc. tylko w trzech miastach. Nowy raport
 - [https://businessinsider.com.pl/poradnik-finansowy/oszczedzanie/wynajem-tanszy-niz-kredyt-2-proc-tylko-w-trzech-miastach-nowy-raport/4ekwcj5](https://businessinsider.com.pl/poradnik-finansowy/oszczedzanie/wynajem-tanszy-niz-kredyt-2-proc-tylko-w-trzech-miastach-nowy-raport/4ekwcj5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 14:44:03+00:00

Przy obecnych cenach wynajmu mieszkań nawet kredyt 2 proc. nie wszędzie będzie opłacało się brać, żeby mieszkanie kupować, zamiast wynajmować. Według wyliczeń Expandera i rentier.io tak byłoby w trzech miastach, tj. nawet tak atrakcyjne raty kredytowe przekroczyłyby tam koszt najmu. Ceny najmu przestały rosnąć, a w wielu miastach w tym roku znacząco spadły. Najbardziej we Wrocławiu.

## Jak zasnąć szybko i bezproblemowo? Oto 12 wskazówek
 - [https://businessinsider.com.pl/rozwoj-osobisty/bezsennosc-jak-zasnac-szybko-i-bezproblemowo-oto-12-wskazowek/z21n9zd](https://businessinsider.com.pl/rozwoj-osobisty/bezsennosc-jak-zasnac-szybko-i-bezproblemowo-oto-12-wskazowek/z21n9zd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 14:10:00+00:00

Spanie dla wielu jest najprostszą czynnością (a raczej bezczynnością) świata, ale nie każdy zasypia minutę po tym, jak przyłoży głowę do poduszki.

## Wydaje ci się, że wszyscy dookoła mają wszystko, a ciebie na nic nie stać? Oto ich sekret
 - [https://businessinsider.com.pl/rozwoj-osobisty/dlaczego-wszyscy-sa-bogatsi-ode-mnie/bzn9xy2](https://businessinsider.com.pl/rozwoj-osobisty/dlaczego-wszyscy-sa-bogatsi-ode-mnie/bzn9xy2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 14:02:00+00:00

Nie opuszcza cię wrażenie, że wszyscy — koledzy z pracy, przyjaciele, sąsiedzi — ciągle gdzieś wyjeżdżają, kupują nowe przedmioty i chodzą w fantastyczne miejsca? Tymczasem tobie wciąż brakuje pieniędzy i nie możesz pozwolić sobie na wszystkie te wspaniałe rzeczy. I wiesz na pewno, że oni wcale nie zarabiają dużo więcej niż ty. W czym tkwi sekret?

## Pięć błędów związanych z mową ciała, przez które inni postrzegają cię jako słabą osobę
 - [https://businessinsider.com.pl/rozwoj-osobisty/mowa-ciala-jakich-bledow-nie-popelniac/ez43wll](https://businessinsider.com.pl/rozwoj-osobisty/mowa-ciala-jakich-bledow-nie-popelniac/ez43wll)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 14:00:00+00:00

Nikt nie chce wyglądać na słabego. Jednak niektórzy tak właśnie wyglądają - często na własną prośbę. Zdradza ich bowiem mowa ciała. Unikaj tych błędów w komunikacji z innymi ludźmi, by sprawiać wrażenie zdecydowanej, pewnej siebie osoby.

## Lex Tusk. Zagraniczne media o decyzji Andrzeja Dudy
 - [https://businessinsider.com.pl/wiadomosci/zagraniczne-media-o-lex-tusk-polowanie-na-czarownice/3f6m9rs](https://businessinsider.com.pl/wiadomosci/zagraniczne-media-o-lex-tusk-polowanie-na-czarownice/3f6m9rs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 13:49:41+00:00

Zagraniczne media komentują decyzję Andrzeja Dudy o podpisaniu lex Tusk. Reuters pisze, że prezydent Polski podpisze ustawę mimo protestów opozycji, która wskazywała, że jest to polowanie na czarownice przed wyborami. Bloomberg z kolei zwraca uwagę na bezprecedensowe uprawnienia komisji.

## Co rekruterzy chcą usłyszeć w odpowiedzi na pytanie: "Gdzie widzisz siebie za pięć lat?"
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/jak-powinna-przebiegac-rozmowa-kwalifikacyjna-i-dlaczego-rozwoj-osobisty-jest-tak/4l4tvrs](https://businessinsider.com.pl/rozwoj-osobisty/kariera/jak-powinna-przebiegac-rozmowa-kwalifikacyjna-i-dlaczego-rozwoj-osobisty-jest-tak/4l4tvrs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 13:28:00+00:00

Rozmowa rekrutacyjna to dla wielu osób niezwykle stresujący etap zatrudniania. Część ubiegających się o pracę podchodzi do niej ze spokojem i bez przygotowania. Jednak czy aby na pewno jest to dobra decyzja? Jak w oczach rekrutera wypada kandydat, który działa spontanicznie oraz bez namysłu? Jakie wymagania stawiają pracodawcy, niezależnie od stanowiska? Czy na rozmowie kwalifikacyjnej mogą paść trudne, podchwytliwe pytania?

## Słońce, turkusowe wybrzeże i niskie ceny. Turcja zaprasza na Riwierę Egejską
 - [https://businessinsider.com.pl/lifestyle/podroze/slonce-turkusowe-wybrzeze-i-niskie-ceny-turcja-zaprasza-na-riwiere-egejska/57cp0ee](https://businessinsider.com.pl/lifestyle/podroze/slonce-turkusowe-wybrzeze-i-niskie-ceny-turcja-zaprasza-na-riwiere-egejska/57cp0ee)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 13:00:00+00:00

Ciepłe morze, góry, piękne plaże, starożytne zabytki oraz baza hotelowo-turystyczna na najwyższym poziomie. Taka jest Riwiera Egejska w Turcji, gdzie możesz spędzić wymarzone wakacje pełne atrakcji i słońca. Warto podkreślić, że z łatwością znajdą tu coś dla siebie miłośnicy spacerów, rejsów żeglarskich, zabytków i dzikich plaż. Ceny rezerwacji w hotelach najwyższej klasy, są teraz szczególnie atrakcyjne. W artykule polecamy sprawdzone obiekty, które mają dostępne terminy wiosną i latem, a jednocześnie są różnorodne pod względem standardu i ceny. Zapraszamy!

## Oto dlaczego żywność w Polsce tak zdrożała. Nowe dane wiele wyjaśniają
 - [https://businessinsider.com.pl/gospodarka/oto-dlaczego-zywnosc-w-polsce-tak-zdrozala-nowe-dane-wiele-wyjasniaja/0c0c5eg](https://businessinsider.com.pl/gospodarka/oto-dlaczego-zywnosc-w-polsce-tak-zdrozala-nowe-dane-wiele-wyjasniaja/0c0c5eg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 12:52:36+00:00

W wyniku przerwania lub wydłużenia łańcuchów dostaw, nie tylko z Ukrainy, Białorusi i Rosji, żywności zaczęło brakować w całej Unii. To była okazja dla polskiego przemysłu spożywczego. Zamiast sprzedawać towar w kraju, częściowo skierowano go na eksport. To jedno z wyjaśnień, dlaczego w naszych sklepach ceny tak wzrosły. Po prostu producenci mieli większy wybór, gdzie sprzedać i za jaką cenę.

## Chiny wcale nie chcą, żeby juan zastąpił dolara. Oto dlaczego
 - [https://businessinsider.com.pl/gospodarka/juan-zastapi-dolara-problem-w-tym-ze-chiny-wcale-tego-nie-chca/p0h02lg](https://businessinsider.com.pl/gospodarka/juan-zastapi-dolara-problem-w-tym-ze-chiny-wcale-tego-nie-chca/p0h02lg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 12:42:31+00:00

Chińska waluta nabrała znaczenia w miarę eskalacji napięć między USA a Chinami i sojuszu Pekinu z Rosją w czasie wojny w Ukrainie. Juan ma swoje pięć minut, jako potencjalny rywal dominującego w globalnym systemie płatności dolara. Jednak Chiny wcale nie chcą, żeby ich waluta zastąpiła dolara. Oto dlaczego.

## Sankcje na przedstawicieli białoruskiego reżimu. Polska spełnia obietnicę
 - [https://businessinsider.com.pl/wiadomosci/sankcje-na-przedstawicieli-bialoruskiego-rezimu-polska-spelnia-obietnice/bnz1enz](https://businessinsider.com.pl/wiadomosci/sankcje-na-przedstawicieli-bialoruskiego-rezimu-polska-spelnia-obietnice/bnz1enz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 12:40:58+00:00

Zdecydowałem o wpisaniu na listę sankcyjną 365 przedstawicieli białoruskiego reżimu. Osoby te dostaną m.in. zakaz wjazdu do strefy Schengen. Sankcje obejmą też 20 podmiotów i 16 przedsiębiorców powiązanych głównie z rosyjskim kapitałem — poinformował szef MSWiA Mariusz Kamiński.

## USA uchronione przed bankructwem. Dla Polski ważny jest jeden szczegół umowy
 - [https://businessinsider.com.pl/gospodarka/usa-uratowane-przed-bankructwem-dla-polski-wazny-jest-jeden-szczegol-umowy/ebhe9j4](https://businessinsider.com.pl/gospodarka/usa-uratowane-przed-bankructwem-dla-polski-wazny-jest-jeden-szczegol-umowy/ebhe9j4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 12:17:01+00:00

Zawarte w ostatniej chwili porozumienie między Republikanami a Demokratami pozwoli USA na zadłużanie się i tym samym utrzymanie wypłacalności. Choć Joe Biden musi iść na kompromisy z opozycją, to z porozumienia płynie jedna bardzo ważna i dobra wiadomość dla Polski.

## Influencer zamiast lekarza. Raport o medycynie estetycznej w Polsce
 - [https://businessinsider.com.pl/lifestyle/zamiast-do-lekarza-do-kosmetyczki-i-influencera-medycyna-estetyczna-w-polsce/6jxl4pk](https://businessinsider.com.pl/lifestyle/zamiast-do-lekarza-do-kosmetyczki-i-influencera-medycyna-estetyczna-w-polsce/6jxl4pk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 12:13:31+00:00

Jedynie 30 proc. osób korzystających w Polsce z zabiegów medycyny estetycznej wykonuje je u lekarza. Ponadto to nie lekarz jest dla pacjenta głównym źródłem informacji. Prawie połowa osób podejmuje decyzję o zabiegu pod wpływem influencera — wynika z najnowszego raportu "Etyka i przyszłość medycyny estetycznej".

## Influencer zamiast lekarza. Raport o medycynie estetycznej w Polsce
 - [https://businessinsider.com.pl/lifestyle/medycyna-estetyczna-w-polsce-tylko-30-proc-osob-robi-zabiegi-u-lekarza/6jxl4pk](https://businessinsider.com.pl/lifestyle/medycyna-estetyczna-w-polsce-tylko-30-proc-osob-robi-zabiegi-u-lekarza/6jxl4pk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 12:13:31+00:00

Jedynie 30 proc. osób korzystających w Polsce z zabiegów medycyny estetycznej wykonuje je u lekarza. Ponadto to nie lekarz jest dla pacjenta głównym źródłem informacji. Prawie połowa osób podejmuje decyzję o zabiegu pod wpływem influencera — wynika z najnowszego raportu "Etyka i przyszłość medycyny estetycznej".

## Siedem powodów, dla których warto kupić grill gazowy
 - [https://businessinsider.com.pl/technologie/siedem-powodow-dla-ktorych-warto-kupic-grill-gazowy/8km74sp](https://businessinsider.com.pl/technologie/siedem-powodow-dla-ktorych-warto-kupic-grill-gazowy/8km74sp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 11:48:19+00:00

Jeśli zastanawiasz się, czy warto kupić grilla gazowego, koniecznie przeczytaj nasz krótki poradnik. Znajdziesz w nim siedem najważniejszych zalet tego typu sprzętu. Nawet jeśli już zdecydowałeś się na zakup tradycyjnego grilla węglowego, może się okazać, że szybko zmienisz decyzję.

## Przedsiębiorcy ostrzegali. Lex Tusk uderzy w reputację Polski
 - [https://businessinsider.com.pl/wiadomosci/przedsiebiorcy-ostrzegali-lex-tusk-uderzy-w-reputacje-polski/4jwsmdn](https://businessinsider.com.pl/wiadomosci/przedsiebiorcy-ostrzegali-lex-tusk-uderzy-w-reputacje-polski/4jwsmdn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 11:42:12+00:00

Podpisanie ustawy określanej jako "lex Tusk" ściągnęło na prezydenta krytykę nie tylko ze strony polityków opozycji. Dokument skrytykowali także przedsiębiorcy. Szef Pracodawców RP Rafał Dutkiewicz zarzucił prezydentowi wsparcie dla formacji, z której się wywodzi oraz ostrzegł przed skutkami, które ta ustawa może przynieść Polsce.

## Duży bank zablokował część kart po wycieku danych
 - [https://businessinsider.com.pl/twoje-pieniadze/wyciek-danych-duzy-bank-zablokowal-karty-czesci-klientow/xveg4tk](https://businessinsider.com.pl/twoje-pieniadze/wyciek-danych-duzy-bank-zablokowal-karty-czesci-klientow/xveg4tk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 11:40:17+00:00

ING Bank Śląski zablokował część kart po tym, jak u jednego z operatorów kart nastąpił wyciek danych. Bank zapewnia, że pieniądze klientów są bezpieczne.

## Ostatni dzwonek, żeby zapisać się do Poland Business Run 2023!
 - [https://businessinsider.com.pl/biznes/ostatni-dzwonek-zeby-zapisac-sie-do-poland-business-run-2023/lwc28s1](https://businessinsider.com.pl/biznes/ostatni-dzwonek-zeby-zapisac-sie-do-poland-business-run-2023/lwc28s1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 11:28:31+00:00

Do 31 maja można zgłaszać swoje drużyny do charytatywnej sztafety biznesowej Poland Business Run 2023. Na liście startowej są już 24 000 biegaczy, którzy w Krakowie i w formule wirtualnej pobiegną dla potrzebujących. Jednym z beneficjentów jest 17-letni Mykola z Ukrainy, który po wybuchu wojny zamieszkał w Polsce i zbiera środki na nowy wózek aktywny.

## Inflacja jeszcze długo nam nie odpuści. Członek RPP wskazuje problemy
 - [https://businessinsider.com.pl/gospodarka/inflacja-jeszcze-dlugo-nam-nie-odpusci/s0s719m](https://businessinsider.com.pl/gospodarka/inflacja-jeszcze-dlugo-nam-nie-odpusci/s0s719m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 11:19:08+00:00

Maj przyniesie kolejny spadek inflacji, jednak pozostanie ona daleka od celu NBP. Zdaniem członka Rady Polityki Pieniężnej Ludwika Koteckiego odczyt GUS pokaże ok. 13 proc. wobec 14,7 proc. w kwietniu.

## W niedzielę zdecydowali, że w poniedziałek cały kraj ma wolne. Wystarczył wygrany mecz
 - [https://businessinsider.com.pl/wiadomosci/w-niedziele-zdecydowali-ze-w-poniedzialek-caly-kraj-ma-wolne-wystarczyl-wygrany-mecz/fq67mxj](https://businessinsider.com.pl/wiadomosci/w-niedziele-zdecydowali-ze-w-poniedzialek-caly-kraj-ma-wolne-wystarczyl-wygrany-mecz/fq67mxj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 10:45:57+00:00

W niedzielny wieczór mieszkańcy Łotwy dowiedzieli się, że nie muszą iść dziś do pracy. Wszystko za sprawą hokeistów i polityków. Ci pierwsi zdobyli brązowy medal mistrzostw świata, ci drudzy postanowili to uczcić, ustanawiając jednorazowo dodatkowy dzień wolny.

## Lex Tusk podpisana, złoty i giełda w dół. Negatywna reakcja rynku na podpis prezydenta Dudy
 - [https://businessinsider.com.pl/gielda/wiadomosci/lex-tusk-podpisana-zloty-i-gielda-w-dol-negatywna-reakcja-rynku-na-podpis-prezydenta/047yqw4](https://businessinsider.com.pl/gielda/wiadomosci/lex-tusk-podpisana-zloty-i-gielda-w-dol-negatywna-reakcja-rynku-na-podpis-prezydenta/047yqw4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 10:17:54+00:00

"Żegnajcie pieniądze z KPO". Tak rynek walutowy i giełdowy wydaje się oceniać podpis prezydenta złożony pod ustawą "lex Tusk". Podpis wpłynął zarówno na kurs złotego, jak i notowania akcji na warszawskiej giełdzie. Wybory to zdecydowanie nie jest dobry czas na inwestowanie.

## Lex Tusk podpisana, złoty i giełda w dół. Oto dlaczego rynek tak zareagował
 - [https://businessinsider.com.pl/gielda/wiadomosci/lex-tusk-podpisana-zloty-i-gielda-w-dol-oto-dlaczego-rynek-tak-zareagowal/047yqw4](https://businessinsider.com.pl/gielda/wiadomosci/lex-tusk-podpisana-zloty-i-gielda-w-dol-oto-dlaczego-rynek-tak-zareagowal/047yqw4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 10:17:54+00:00

"Żegnajcie pieniądze z KPO". Tak rynek walutowy i giełdowy wydaje się oceniać podpis prezydenta złożony pod ustawą "lex Tusk". Podpis wpłynął zarówno na kurs złotego, jak i notowania akcji na warszawskiej giełdzie. Wybory to zdecydowanie nie jest dobry czas na inwestowanie.

## Lex Tusk. Co oznacza decyzja Andrzeja Dudy
 - [https://businessinsider.com.pl/prawo/lex-tusk-co-oznacza-decyzja-andrzeja-dudy/r3ll23m](https://businessinsider.com.pl/prawo/lex-tusk-co-oznacza-decyzja-andrzeja-dudy/r3ll23m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 10:08:08+00:00

Prezydent Andrzej Duda zdecydował, że podpisze lex Tusk, czyli ustawę powołującą komisję do spraw badania wpływów rosyjskich. Jednocześnie jednak skierował ją w trybie następczym do Trybunału Konstytucyjnego. Co to oznacza?

## Policja udaremniła przemyt wydzielin kaszalota wartych miliony dolarów
 - [https://businessinsider.com.pl/wiadomosci/policja-udaremnila-przemyt-wydzielin-kaszalota-wartych-miliony-dolarow/exb21d7](https://businessinsider.com.pl/wiadomosci/policja-udaremnila-przemyt-wydzielin-kaszalota-wartych-miliony-dolarow/exb21d7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 10:05:16+00:00

Policja w Indiach zatrzymała przemytników wiozących ambrę — niezwykle cenioną wydzielinę z przewodu pokarmowego kaszalota wartą 1,8 mln dol.

## Oto najpopularniejsze marki na świecie. Lider zmiażdżył konkurencję
 - [https://businessinsider.com.pl/wiadomosci/oto-najpopularniejsze-marki-na-swiecie-na-te-produkty-wydajemy-najwiecej/zfkwy0z](https://businessinsider.com.pl/wiadomosci/oto-najpopularniejsze-marki-na-swiecie-na-te-produkty-wydajemy-najwiecej/zfkwy0z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 10:03:43+00:00

Są takie produkty, po które sięgają klienci na całym świecie. Chodzi przede wszystkim o grupę marek FMCG, czyli tych, które oferują towary pierwszej potrzeby: spożywcze i kosmetyczne. Firma Kantar opublikowała ranking najpopularniejszych marek, opierając się na zwyczajach zakupowych konsumentów w 53 krajach. Pierwsza piątka raczej nie powinna być dla nikogo zaskoczeniem.

## Uparte dzieci mogą w przyszłości zarabiać więcej
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/uparte-dziecko-moze-wiecej-zarabiac/cy40yrl](https://businessinsider.com.pl/rozwoj-osobisty/kariera/uparte-dziecko-moze-wiecej-zarabiac/cy40yrl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 10:03:00+00:00

"Nie" – to jedno z ulubionych słów wielu dzieci. Trudno przekonać je do zrobienia czegokolwiek i nie usłyszeć w odpowiedzi przeraźliwego krzyku. Na nieszczęście dla rodziców, tego typu zachowanie może być dobrym znakiem.

## Rosja może wprowadzić sześciodniowy tydzień pracy
 - [https://businessinsider.com.pl/wiadomosci/rosja-moze-wprowadzic-szesciodniowy-tydzien-pracy/5cb3bp1](https://businessinsider.com.pl/wiadomosci/rosja-moze-wprowadzic-szesciodniowy-tydzien-pracy/5cb3bp1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 09:51:14+00:00

Rosyjskie państwowe media i niektóre firmy powiązane z Kremlem proponują wprowadzenie sześciodniowego tygodnia pracy, aby sfinansować rosyjską wojnę w Ukrainie, a wszystko to bez dodatkowego wynagrodzenia

## Hiszpania. Premier zapowiedział nowe wybory po porażce w regionach
 - [https://businessinsider.com.pl/wiadomosci/hiszpania-premier-zapowiedzial-nowe-wybory-po-porazce-w-regionach/vrym3y3](https://businessinsider.com.pl/wiadomosci/hiszpania-premier-zapowiedzial-nowe-wybory-po-porazce-w-regionach/vrym3y3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 09:46:20+00:00

Po wyborczej porażce na poziomie regionalnym i lokalnym premier Hiszpanii Pedro Sanchez poinformował, że zamierza rozwiązać parlament i zarządzić wybory parlamentarne.

## Smartfony, którymi wykonasz znakomite zdjęcia
 - [https://businessinsider.com.pl/technologie/smartfony-ktorymi-wykonasz-znakomite-zdjecia/3gmk682](https://businessinsider.com.pl/technologie/smartfony-ktorymi-wykonasz-znakomite-zdjecia/3gmk682)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 09:22:28+00:00

Przedstawiamy pięć smartfonów, które wykonują znakomitej jakości zdjęcia. Są dwie, dla wielu oczywiste propozycje, ale niektóre mogą być zaskoczeniem. Nie są tanie, ale dostajemy urządzenie trzy w jednym: telefon, kamerę i aparat cyfrowy.

## Lex Tusk podpisana. Prezydent wskazuje na rolę sądów jako gwaranta
 - [https://businessinsider.com.pl/wiadomosci/lex-tusk-podpisana-prezydent-wskazuje-na-role-sadow/d6dvpzt](https://businessinsider.com.pl/wiadomosci/lex-tusk-podpisana-prezydent-wskazuje-na-role-sadow/d6dvpzt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 09:08:06+00:00

Werdykt komisji nie będzie eliminował z życia publicznego czy politycznego — tak o podpisanej oraz skierowanej do TK ustawie określanej jako lex Tusk mówi prezydent Andrzej Duda. Jak przekonuje, ostateczna decyzja będzie leżeć w gestii dwuinstancyjnego sądu.

## Lex Tusk. Andrzej Duda zdecydował o losie komisji
 - [https://businessinsider.com.pl/wiadomosci/lex-tusk-andrzej-duda-zdecydowal-o-losie-komisji/9t7w1x0](https://businessinsider.com.pl/wiadomosci/lex-tusk-andrzej-duda-zdecydowal-o-losie-komisji/9t7w1x0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 08:44:04+00:00

Prezydent zdecydował ws. ustawy powołującej komisję do zbadania rosyjskich wpływów w Polsce w latach 2007-2022 określaną jako "lex Tusk". Andrzej Duda podpisał ustawę oraz zapowiedział skierowanie jej "w trybie następczym" do Trybunału Konstytucyjnego.

## Obniżki stóp jeszcze w tym roku? Członkini RPP daje nadzieję
 - [https://businessinsider.com.pl/gospodarka/obnizki-stop-jeszcze-w-tym-roku-czlonkini-rpp-daje-nadzieje/srfgelr](https://businessinsider.com.pl/gospodarka/obnizki-stop-jeszcze-w-tym-roku-czlonkini-rpp-daje-nadzieje/srfgelr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 08:23:35+00:00

Prawdopodobieństwo obniżek stóp procentowych w tym roku jest coraz większe, uważa członkini Rady Polityki Pieniężnej (RPP) Gabriela Masłowska. Według niej, na moment przyspieszenia pierwszych obniżek wpływa umocnienie się złotego.

## 18 najważniejszych pojęć korpomowy
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/18-najwazniejszych-pojec-korpomowy/pdv2dby](https://businessinsider.com.pl/rozwoj-osobisty/kariera/18-najwazniejszych-pojec-korpomowy/pdv2dby)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 08:15:00+00:00

Korpomowa to slang używany przez pracowników wielkich firm. Przetykana angielskimi wstawkami, stała się obiektem kpin i żartów, ale bez niej wszystko byłoby trudniejsze. I choć śmieszy, to trzeba ją znać — nie tylko gdy ma się zamiar pracować w korporacji. Na międzynarodowym poziomie biznesu jest wręcz obowiązkowa.

## "Bezpieczny kredyt" w trzech największych bankach
 - [https://businessinsider.com.pl/finanse/bezpieczny-kredyt-w-trzech-najwiekszych-bankach/6675fvt](https://businessinsider.com.pl/finanse/bezpieczny-kredyt-w-trzech-najwiekszych-bankach/6675fvt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 08:06:34+00:00

Trzy największe banki w Polsce zadeklarowały chęć i gotowość wprowadzenia do oferty rządowego programu "bezpieczny kredyt" — powiedział w poniedziałek minister rozwoju i technologii Waldemar Buda w Programie 1 Polskiego Radia. 3 lipca wprowadzamy produkt w życie — dodał.

## ZUS zwraca pieniądze. To już ponad 1,2 mld zł
 - [https://businessinsider.com.pl/poradnik-finansowy/zus-zwraca-pieniadze-to-juz-ponad-12-mld-zl/48ee09h](https://businessinsider.com.pl/poradnik-finansowy/zus-zwraca-pieniadze-to-juz-ponad-12-mld-zl/48ee09h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 07:58:40+00:00

Zakład Ubezpieczeń Społecznych przypomina, że przedsiębiorcy mogą odzyskać nadpłaconą część składki zdrowotnej zapłaconej w 2022 r. Kwota, o którą dotychczas zawnioskowali przedsiębiorcy, to ponad 1,2 mld zł.

## Ten wskaźnik pokazuje najbliższą przyszłość w gospodarce. "Narastający pesymizm"
 - [https://businessinsider.com.pl/gospodarka/ten-wskaznik-pokazuje-co-sie-wydarzy-w-gospodarce-narastajacy-pesymizm/77czce6](https://businessinsider.com.pl/gospodarka/ten-wskaznik-pokazuje-co-sie-wydarzy-w-gospodarce-narastajacy-pesymizm/77czce6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 07:35:39+00:00

Wskaźnik Wyprzedzający Koniunktury ma informować, co w gospodarce zdarzy się w najbliższych miesiącach. I informacje nie są wesołe. W przemyśle coraz mniej zamówień, zarówno krajowych, jak i eksportowych, zyski spadają. "Tym razem optymizmu w danych nie widać" — przekazało Biuro Inwestycji i Cykli Ekonomicznych.

## Kurs EUR/PLN 29 maja 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-29-maja-2023-r/3de1jgc](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-29-maja-2023-r/3de1jgc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 07:09:14+00:00

Bieżący kurs waluty euro z dnia 2023-5-29 z godziny 7 rano oraz zmiany kursu dzień do dnia i tydzień do tygodnia. Jak się zmienił kurs w tym okresie i czy warto dziś wymieniać złotówki na euro? Aktualny kurs euro interesuje przede wszystkim przedsiębiorców, którzy zajmują się importem i eksportem usług oraz towarów. Ważny jest także dla turystów planujących wakacje. Wczoraj kurs euro wynosił: 4.5273 zł

## Przedsiębiorcy apelują do prezydenta. Chcą zawetowania lex Tusk
 - [https://businessinsider.com.pl/biznes/przedsiebiorcy-apeluja-do-prezydenta-chca-zawetowania-lex-tusk/4k5xk7s](https://businessinsider.com.pl/biznes/przedsiebiorcy-apeluja-do-prezydenta-chca-zawetowania-lex-tusk/4k5xk7s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 06:26:21+00:00

Przedsiębiorcy zrzeszeni w Radzie Przedsiębiorczości apelują do prezydenta Andrzeja Dudy o zawetowanie ustawy powołującej komisję, która ma zbadać rzekome wpływy rosyjskie w Polsce w latach 2007-2022. To tzw. lex Tusk.

## Wywiad Donalda Tuska. Pięć najważniejszych cytatów dla biznesu
 - [https://businessinsider.com.pl/gospodarka/wywiad-donalda-tuska-piec-najwazniejszych-cytatow-dla-biznesu/1qms7h6](https://businessinsider.com.pl/gospodarka/wywiad-donalda-tuska-piec-najwazniejszych-cytatow-dla-biznesu/1qms7h6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 05:56:59+00:00

Donald Tusk, lider Platformy Obywatelskiej, udzielił wywiadu tygodnikowi "Newsweek", w którym opowiedział o swoich pierwszych krokach, które podejmie w razie zwycięstwa w jesiennych wyborach parlamentarnych. Oto pięć zapowiedzi najważniejszych zapowiedzi, które wpłyną na biznes i gospodarkę.

## Ameryka nie zbankrutuje, limit długu zostanie podniesiony
 - [https://businessinsider.com.pl/gospodarka/ameryka-nie-zbankrutuje-limit-dlugu-zostanie-podniesiony/28m5t1m](https://businessinsider.com.pl/gospodarka/ameryka-nie-zbankrutuje-limit-dlugu-zostanie-podniesiony/28m5t1m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 05:23:54+00:00

Najważniejszy na rynkach finansowych w ostatnich dniach temat podnoszenia limitu długu w USA właśnie traci swoją pozycję, ponieważ doszło tam do wstępnego porozumienia. Z drugiej strony ponownie zaczyna tam rosnąć inflacja. Ciekawe rzeczy na rynkach mogą dzisiaj dziać się z walutą i aktywami tureckimi po tym jak Erdogan znowu wygrał wybory. Zmiany klimatu będą nam wszystkim podbijać inflację – martwi się Europejski Bank Centralny, a u nas płaca minimalna od przyszłego roku ma przekraczać 4200 złotych brutto – oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Rząd zdecyduje, gdzie budować. "Ta ustawa cofa nas do PRL"
 - [https://businessinsider.com.pl/wiadomosci/rzad-zdecyduje-gdzie-budowac-ta-ustawa-cofa-nas-do-prl/yljckw8](https://businessinsider.com.pl/wiadomosci/rzad-zdecyduje-gdzie-budowac-ta-ustawa-cofa-nas-do-prl/yljckw8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 05:16:33+00:00

Rząd chce decydować, które inwestycje będą przygotowywane w uproszczonym trybie, bez konsultacji społecznych i możliwości odwołań od postanowień środowiskowych. A to — jak pisze "Dziennik Gazeta Prawna" — oznacza, że będzie można budować drogi bez oglądania się na protesty.

## Nieoficjalnie: Andrzej Duda jest gotów podpisać lex Tusk
 - [https://businessinsider.com.pl/wiadomosci/nieoficjalnie-andrzej-duda-jest-gotow-podpisac-lex-tusk/zkce742](https://businessinsider.com.pl/wiadomosci/nieoficjalnie-andrzej-duda-jest-gotow-podpisac-lex-tusk/zkce742)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 04:58:00+00:00

Prezydent skłania się do podpisania ustawy powołującej komisję, której zadaniem będzie zbadanie wątku rosyjskich wpływów w Polsce, tzw. lex Tusk — donosi "Dziennik Gazeta Prawna", powołując się na informacje z obozu władzy.

## Paraliżu przez zadłużenie nie będzie. Porozumienie gotowe do głosowania
 - [https://businessinsider.com.pl/finanse/paralizu-przez-zadluzenie-nie-bedzie-porozumienie-gotowe-do-glosowania/5t4f7ev](https://businessinsider.com.pl/finanse/paralizu-przez-zadluzenie-nie-bedzie-porozumienie-gotowe-do-glosowania/5t4f7ev)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 04:45:39+00:00

Prezydent Joe Biden oświadczył w niedzielę, że ostatecznie sfinalizował porozumienie budżetowe z spikerem Izby Reprezentantów Kevinem McCarthym. Dodał, że porozumienie w sprawie podwyższenia limitu zadłużenia jest gotowe do przekazania Kongresowi .

## Erdogan wygrywa w Turcji. Będzie prezydentem trzecią kadencję
 - [https://businessinsider.com.pl/gospodarka/erdogan-wygrywa-bedzie-prezydentem-trzecia-kadencje/rhy18sl](https://businessinsider.com.pl/gospodarka/erdogan-wygrywa-bedzie-prezydentem-trzecia-kadencje/rhy18sl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 04:29:10+00:00

Recep Tayyip Erdogan pozostanie prezydentem Turcji. Polityk wygrał wyborczy wyścig, pokonując w drugiej turze Kemala Kilicdaroglu.

## W samolotach palić nie wolno. Dlaczego instaluje się w nich popielniczki?
 - [https://businessinsider.com.pl/lifestyle/podroze/popielniczki-w-toalecie-samolotu-a-zakaz-palenia-papierosow/qrmdsc1](https://businessinsider.com.pl/lifestyle/podroze/popielniczki-w-toalecie-samolotu-a-zakaz-palenia-papierosow/qrmdsc1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 04:06:00+00:00

Popielniczka na drzwiach toalety w samolocie a obok znak "zakaz palenia" — nie, to nie absurd i nie pomyłka. Choć na pokładzie samolotu palić nie wolno, popielniczka musi być na jego pokładzie. Co więcej, gdyby jej zabrakło — samolot nie mógłby wystartować.

## Fiskus nie zakwestionuje już tak łatwo odliczenia VAT? Zapadł ważny wyrok
 - [https://businessinsider.com.pl/prawo/podatki/co-z-odliczeniem-vat-gdy-czynnosc-byla-pozorna-zapadl-wazny-wyrok/7dptxl0](https://businessinsider.com.pl/prawo/podatki/co-z-odliczeniem-vat-gdy-czynnosc-byla-pozorna-zapadl-wazny-wyrok/7dptxl0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 04:02:57+00:00

Zapadł ważny wyrok Trybunału Sprawiedliwości UE w sprawie odliczenia VAT. Polski fiskus pozbawiał prawa do odliczenia podatnika, jeśli uznał, że dokonał on czynności pozornych, a więc nieważnych z punktu widzenia prawa cywilnego. Trybunał orzekł, że to nie wystarczy, żeby pozbawić podatnika odliczenia VAT.

## Zakupy coraz przyjemniejsze. Mamy kolejny zjazd cen [Koszyk zakupowy Business Insidera i aplikacji PanParagon]
 - [https://businessinsider.com.pl/poradnik-finansowy/zakupy-coraz-przyjemniejsze-mamy-kolejny-zjazd-cen-w-naszym-koszyku/6z05w24](https://businessinsider.com.pl/poradnik-finansowy/zakupy-coraz-przyjemniejsze-mamy-kolejny-zjazd-cen-w-naszym-koszyku/6z05w24)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 04:00:00+00:00

Im bliżej sezonu wakacyjnego, tym ceny są niższe – wynika z naszej najnowszej analizy. Zwłaszcza cieszą sezonowe spadki cen pomidorów. Są jednak również gorsze wieści.

## Tajemnicze billboardy, zakopane miliardy i mafie vatowskie. Znamy kolejny ruch wyborczy PiS
 - [https://businessinsider.com.pl/wiadomosci/gdzie-te-pieniadze-byly-zakopane-pis-uderzy-w-donalda-tuska-i-po/81j94hn](https://businessinsider.com.pl/wiadomosci/gdzie-te-pieniadze-byly-zakopane-pis-uderzy-w-donalda-tuska-i-po/81j94hn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-05-29 03:58:00+00:00

PiS zamierza w kampanii wyborczej podkreślać swoje sukcesy w uszczelnieniu systemu podatkowego i w walce z mafiami vatowskimi. Chce przy okazji uderzyć w Donalda Tuska i jego rząd narracją o bierności w przeciwdziałaniu wyłudzeniom. W całej Polsce pojawiły się już tajemnicze billboardy z pytaniem "Gdzie te pieniądze były zakopane?". Z ustaleń Business Insider Polska wynika, że na początku czerwca ruszy rządowa kampania ze specjalną stroną internetową niezakopane.gov.pl i internetowymi spotami.

