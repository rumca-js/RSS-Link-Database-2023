# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Why Microsoft's $75 Billion Bid for Activision Hinges on Call of Duty
 - [https://www.wsj.com/articles/why-microsofts-75-billion-bid-for-activision-blizzard-hinges-on-call-of-duty-e86df589?mod=rss_Technology](https://www.wsj.com/articles/why-microsofts-75-billion-bid-for-activision-blizzard-hinges-on-call-of-duty-e86df589?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-05-29 13:00:00+00:00

Regulators worry the popular videogame franchise is so crucial to attract hard-core gamers that it could be used to dominate cloud gaming.

## The AI Boom Runs on Chips, but It Can't Get Enough
 - [https://www.wsj.com/articles/the-ai-boom-runs-on-chips-but-it-cant-get-enough-9f76f554?mod=rss_Technology](https://www.wsj.com/articles/the-ai-boom-runs-on-chips-but-it-cant-get-enough-9f76f554?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-05-29 04:01:00+00:00

A shortage of the kind of advanced chips that are the lifeblood of new generative AI systems has set off a race to lock down computing power and find workarounds.

