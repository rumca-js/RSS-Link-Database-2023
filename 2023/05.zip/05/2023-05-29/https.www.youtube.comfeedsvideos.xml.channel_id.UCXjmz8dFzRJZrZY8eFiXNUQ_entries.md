# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## How Marshall Ruined The Final Season Of How I Met Your Mother
 - [https://www.youtube.com/watch?v=bm_LyoLXAAY](https://www.youtube.com/watch?v=bm_LyoLXAAY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-05-29 17:00:30+00:00

It's no secret that most fans consider the final season of How I Met Your Mother to be the worst in the series.  Though not many can put a finger on what exactly went wrong.  Some point to Jason Segel's contract dispute with How I Met Your Mother producers, but is that the whole story?  Why did one of the central characters of How I Met Your Mother almost jump ship before the shows final season?

#howimetyourmother #jasonsegel  #nerdstalgic

