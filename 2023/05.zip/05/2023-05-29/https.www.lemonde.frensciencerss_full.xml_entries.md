# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Clinical trials at Didier Raoult's former institute: In the absence of any institutional reaction, the 'serious breaches observed could become the norm'
 - [https://www.lemonde.fr/en/opinion/article/2023/05/29/clinical-trials-at-didier-raoult-s-former-institute-in-the-absence-of-any-institutional-reaction-the-serious-breaches-observed-could-become-the-norm_6028406_23.html](https://www.lemonde.fr/en/opinion/article/2023/05/29/clinical-trials-at-didier-raoult-s-former-institute-in-the-absence-of-any-institutional-reaction-the-serious-breaches-observed-could-become-the-norm_6028406_23.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-05-29 16:05:55+00:00

Some clinical trials conducted during the Covid-19 pandemic by the university hospital in Marseille did not respect the legal framework, according to several medical organizations, who call on the public authorities to react.

