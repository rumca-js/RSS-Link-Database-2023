# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## Boot Camp | Welcome To The J: Inside Army Jungle School | Coming June 1
 - [https://www.youtube.com/watch?v=62r2hnmupoQ](https://www.youtube.com/watch?v=62r2hnmupoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-05-29 15:00:05+00:00

As tensions with China build and the U.S. ends more troops to the Asia-Pacific region the Asia-Pacific region, soldiers with the skills to fight and survive in the jungle are increasingly vital. The US Army trains soldiers for jungle warfare at the Lightning Academy on the island of Oahu in Hawaii. Insider's chief video correspondent Graham Flanagan spent 12 days inside the Army's Jungle Operations Training Course, where a cross-section of soldiers of various ranks and experience levels learn to fight, move, and survive in the jungle. 80 students begin the course on day one, but only 51 will make it to graduation. The first feature-length documentary from Insider's "Boot Camp" series is scheduled to go live on Thursday June 1, 2023.

------------------------------------------------------

#USArmy #BootCamp #InsiderBusiness

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

