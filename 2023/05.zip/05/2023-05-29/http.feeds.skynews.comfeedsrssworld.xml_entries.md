# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Djokovic sends political message about Kosovo after violence erupts
 - [https://news.sky.com/story/novak-djokovic-sends-political-message-about-kosovo-at-french-open-after-violence-erupts-12892803](https://news.sky.com/story/novak-djokovic-sends-political-message-about-kosovo-at-french-open-after-violence-erupts-12892803)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 20:32:00+00:00

Novak Djokovic has risked igniting political tensions in his home region with a political message about Kosovo - after peacekeeping troops were hurt when ethnic Serbs clashed with police over the weekend.

## British man dies in Greece after being 'struck by lightning while paddleboarding'
 - [https://news.sky.com/story/british-man-26-dies-in-greece-after-being-struck-by-lightning-while-paddleboarding-12892787](https://news.sky.com/story/british-man-26-dies-in-greece-after-being-struck-by-lightning-while-paddleboarding-12892787)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 19:23:00+00:00

A British man has died after he was reportedly hit by lightning while paddleboarding in Greece.

## Ukraine tennis player who refused to shake hands with Belarusian gets support from foreign minister
 - [https://news.sky.com/story/marta-kostyuk-ukraine-tennis-player-who-refused-to-shake-hands-with-belarusian-aryna-sabalenka-gets-support-from-foreign-minister-12892682](https://news.sky.com/story/marta-kostyuk-ukraine-tennis-player-who-refused-to-shake-hands-with-belarusian-aryna-sabalenka-gets-support-from-foreign-minister-12892682)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 16:06:00+00:00

The Ukrainian foreign minister has expressed his support for a tennis player who was booed off the court at the French Open for refusing to shake hands with her Belarusian opponent.

## Girl, 16, stabbed to death on Delhi street as passers-by watched on
 - [https://news.sky.com/story/man-arrested-after-16-year-old-girl-stabbed-to-death-on-delhi-street-as-passers-by-watched-on-12892678](https://news.sky.com/story/man-arrested-after-16-year-old-girl-stabbed-to-death-on-delhi-street-as-passers-by-watched-on-12892678)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 16:02:00+00:00

A 20-year-old man has been arrested in Delhi following the brutal killing of a 16-year-old girl in public, which was captured on CCTV.

## Mother pleads guilty to murder after six-year-old son starves to death
 - [https://news.sky.com/story/mother-pleads-guilty-to-murder-after-six-year-old-son-starves-to-death-in-arizona-12892651](https://news.sky.com/story/mother-pleads-guilty-to-murder-after-six-year-old-son-starves-to-death-in-arizona-12892651)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 15:11:00+00:00

A mother has pleaded guilty to murder and child abuse over the death of her six-year-old son in Arizona.

## 'Our family have been shot': Wounded refugees stream in from Darfur after violence in Sudan
 - [https://news.sky.com/story/refugees-with-gunshot-wounds-stream-in-from-darfur-after-violence-in-sudan-12892638](https://news.sky.com/story/refugees-with-gunshot-wounds-stream-in-from-darfur-after-violence-in-sudan-12892638)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 14:46:00+00:00

The central patch of Sudan and Chad's 869-mile border is a dried river bed of wet light sand and large puddles of water.

## Anti-gay legislation that could mean the death penalty in some cases signed into law in Uganda
 - [https://news.sky.com/story/uganda-anti-gay-law-that-could-mean-the-death-penalty-in-some-cases-signed-into-law-12892558](https://news.sky.com/story/uganda-anti-gay-law-that-could-mean-the-death-penalty-in-some-cases-signed-into-law-12892558)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 12:25:00+00:00

New anti-gay legislation that could mean the death penalty in some cases has been signed into law in Uganda, amid outcry by LGBT charities.

## Chinese-registered ship detained on suspicion of looting wreckages of British warships
 - [https://news.sky.com/story/chinese-registered-ship-detained-on-suspicion-of-looting-wreckages-of-british-warships-12892516](https://news.sky.com/story/chinese-registered-ship-detained-on-suspicion-of-looting-wreckages-of-british-warships-12892516)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 11:36:00+00:00

A Chinese-registered vessel has been detained in Malaysia, on suspicion of looting the wreckage of Second World War-era British warships in the South China Sea.

## On board the mission to rescue 600 people from overcrowded fishing boat abandoned by its captain
 - [https://news.sky.com/story/we-all-thought-we-were-going-to-die-the-rescue-of-600-people-from-the-mediterranean-12892438](https://news.sky.com/story/we-all-thought-we-were-going-to-die-the-rescue-of-600-people-from-the-mediterranean-12892438)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 09:34:00+00:00

The sun beats down on us. I&#8217;m sweating, and there is noise from every angle. Two marine engines thrum behind me, churning the water of the Mediterranean.

## Putin and Zelenskyy among world leaders to congratulate Turkey's Erodgan on election victory
 - [https://news.sky.com/story/turkey-elections-putin-and-zelenskyy-among-world-leaders-to-congratulate-erdogan-on-election-victory-12892319](https://news.sky.com/story/turkey-elections-putin-and-zelenskyy-among-world-leaders-to-congratulate-erdogan-on-election-victory-12892319)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-29 00:00:00+00:00

Vladimir Putin and Volodymyr Zelenskyy have joined world leaders in congratulating Turkish president Recep Tayyip Erdogan on his election win.

