# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## DNSSEC KSK rollover breaks DNS resolution for .nz domains
 - [https://status.internetnz.nz/incidents/gq1c6slz3198](https://status.internetnz.nz/incidents/gq1c6slz3198)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 22:29:38+00:00

<p>Article URL: <a href="https://status.internetnz.nz/incidents/gq1c6slz3198">https://status.internetnz.nz/incidents/gq1c6slz3198</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36118856">https://news.ycombinator.com/item?id=36118856</a></p>
<p>Points: 35</p>
<p># Comments: 7</p>

## HBO Max new Captcha system
 - [https://twitter.com/wondermeg_/status/1662454909353033730](https://twitter.com/wondermeg_/status/1662454909353033730)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 22:10:46+00:00

<p>Article URL: <a href="https://twitter.com/wondermeg_/status/1662454909353033730">https://twitter.com/wondermeg_/status/1662454909353033730</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36118707">https://news.ycombinator.com/item?id=36118707</a></p>
<p>Points: 51</p>
<p># Comments: 12</p>

## Death by design patterns, or On the cognitive load of abstractions in the code
 - [https://alentred.medium.com/cognitive-load-of-abstractions-in-the-source-code-20a889a106d4](https://alentred.medium.com/cognitive-load-of-abstractions-in-the-source-code-20a889a106d4)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 21:04:34+00:00

<p>Article URL: <a href="https://alentred.medium.com/cognitive-load-of-abstractions-in-the-source-code-20a889a106d4">https://alentred.medium.com/cognitive-load-of-abstractions-in-the-source-code-20a889a106d4</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36118093">https://news.ycombinator.com/item?id=36118093</a></p>
<p>Points: 55</p>
<p># Comments: 32</p>

## Ivy (YC W23) Is Hiring
 - [https://deep-ivy-ltd.breezy.hr/p/055a500d0e8701-ml-research-engineer?ref=upstract.com](https://deep-ivy-ltd.breezy.hr/p/055a500d0e8701-ml-research-engineer?ref=upstract.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 21:01:13+00:00

<p>Article URL: <a href="https://deep-ivy-ltd.breezy.hr/p/055a500d0e8701-ml-research-engineer?ref=upstract.com">https://deep-ivy-ltd.breezy.hr/p/055a500d0e8701-ml-research-engineer?ref=upstract.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36118074">https://news.ycombinator.com/item?id=36118074</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## My first superoptimizer
 - [https://austinhenley.com/blog/superoptimizer.html](https://austinhenley.com/blog/superoptimizer.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 20:47:30+00:00

<p>Article URL: <a href="https://austinhenley.com/blog/superoptimizer.html">https://austinhenley.com/blog/superoptimizer.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36117950">https://news.ycombinator.com/item?id=36117950</a></p>
<p>Points: 53</p>
<p># Comments: 14</p>

## How much would it have cost if GPT-4 had written your code
 - [https://pypi.org/project/cost-of-code/](https://pypi.org/project/cost-of-code/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 20:39:16+00:00

<p>Article URL: <a href="https://pypi.org/project/cost-of-code/">https://pypi.org/project/cost-of-code/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36117846">https://news.ycombinator.com/item?id=36117846</a></p>
<p>Points: 18</p>
<p># Comments: 12</p>

## LHC experiments see first evidence of a rare Higgs boson decay
 - [https://www.interactions.org///press-release/lhc-experiments-see-first-evidence-rare-higgs-boson-decay](https://www.interactions.org///press-release/lhc-experiments-see-first-evidence-rare-higgs-boson-decay)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 20:10:36+00:00

<p>Article URL: <a href="https://www.interactions.org///press-release/lhc-experiments-see-first-evidence-rare-higgs-boson-decay">https://www.interactions.org///press-release/lhc-experiments-see-first-evidence-rare-higgs-boson-decay</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36117558">https://news.ycombinator.com/item?id=36117558</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Three Investing Patterns That You Should Know
 - [https://behavioralvalueinvestor.substack.com/p/3-investing-patterns-that-you-should](https://behavioralvalueinvestor.substack.com/p/3-investing-patterns-that-you-should)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 19:35:28+00:00

<p>Article URL: <a href="https://behavioralvalueinvestor.substack.com/p/3-investing-patterns-that-you-should">https://behavioralvalueinvestor.substack.com/p/3-investing-patterns-that-you-should</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36117186">https://news.ycombinator.com/item?id=36117186</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Show HN: Tiny – A 2D Game Engine in Kotlin Working with Lua
 - [https://minigdx.github.io/tiny/](https://minigdx.github.io/tiny/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 19:19:17+00:00

<p>I created a small 2D game engine named  Tiny.<p>The engine was created using Kotlin Multiplatform and can run on a JVM and JS.
Funny things: Games can be created using the programming language Lua.<p>Tiny is designed to help you create and test your ideas quickly and effectively. Not only can you run your games on your desktop computer, but you can also export them for the web, making it easy to share your creations with others.<p>You can create games easily with the hot reload, small API and Lua, which is very easy to learn.<p>If you want to test a game idea, to try to create your first game or just have fun, give it a try to  Tiny.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36117037">https://news.ycombinator.com/item?id=36117037</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Why I don't need to clean up my desktop and downloads folder
 - [https://www.stefanjudis.com/blog/why-i-dont-need-to-clean-up-my-desktop-and-downloads-folder-in-macos/](https://www.stefanjudis.com/blog/why-i-dont-need-to-clean-up-my-desktop-and-downloads-folder-in-macos/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 18:56:20+00:00

<p>Article URL: <a href="https://www.stefanjudis.com/blog/why-i-dont-need-to-clean-up-my-desktop-and-downloads-folder-in-macos/">https://www.stefanjudis.com/blog/why-i-dont-need-to-clean-up-my-desktop-and-downloads-folder-in-macos/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36116777">https://news.ycombinator.com/item?id=36116777</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## GDP is the wrong tool for measuring what matters (2020)
 - [https://www.scientificamerican.com/article/gdp-is-the-wrong-tool-for-measuring-what-matters/](https://www.scientificamerican.com/article/gdp-is-the-wrong-tool-for-measuring-what-matters/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 18:54:53+00:00

<p>Article URL: <a href="https://www.scientificamerican.com/article/gdp-is-the-wrong-tool-for-measuring-what-matters/">https://www.scientificamerican.com/article/gdp-is-the-wrong-tool-for-measuring-what-matters/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36116762">https://news.ycombinator.com/item?id=36116762</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Nvidia's next DGX supercomputer is all about generative AI
 - [https://www.tomshardware.com/news/nvidia-unveils-dgx-gh200-supercomputer-and-mgx-systems-grace-hopper-superchips-in-production](https://www.tomshardware.com/news/nvidia-unveils-dgx-gh200-supercomputer-and-mgx-systems-grace-hopper-superchips-in-production)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 18:13:16+00:00

<p>Article URL: <a href="https://www.tomshardware.com/news/nvidia-unveils-dgx-gh200-supercomputer-and-mgx-systems-grace-hopper-superchips-in-production">https://www.tomshardware.com/news/nvidia-unveils-dgx-gh200-supercomputer-and-mgx-systems-grace-hopper-superchips-in-production</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36116430">https://news.ycombinator.com/item?id=36116430</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Hold the postmortem: The metaverse was never alive in the first place
 - [https://fastcompanyme.com/technology/hold-the-postmortem-the-metaverse-was-never-alive-in-the-first-place/](https://fastcompanyme.com/technology/hold-the-postmortem-the-metaverse-was-never-alive-in-the-first-place/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 18:09:09+00:00

<p>Article URL: <a href="https://fastcompanyme.com/technology/hold-the-postmortem-the-metaverse-was-never-alive-in-the-first-place/">https://fastcompanyme.com/technology/hold-the-postmortem-the-metaverse-was-never-alive-in-the-first-place/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36116387">https://news.ycombinator.com/item?id=36116387</a></p>
<p>Points: 16</p>
<p># Comments: 10</p>

## MITx Differential Equations starts May 31
 - [https://mitxonline.mit.edu/courses/course-v1:MITxT+18.03.1x/](https://mitxonline.mit.edu/courses/course-v1:MITxT+18.03.1x/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 17:47:35+00:00

<p>Article URL: <a href="https://mitxonline.mit.edu/courses/course-v1:MITxT+18.03.1x/">https://mitxonline.mit.edu/courses/course-v1:MITxT+18.03.1x/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36116189">https://news.ycombinator.com/item?id=36116189</a></p>
<p>Points: 16</p>
<p># Comments: 3</p>

## Filial Piety in Chinese Culture (2016)
 - [https://china-journal.org/2016/03/14/filial-piety-in-chinese-culture/](https://china-journal.org/2016/03/14/filial-piety-in-chinese-culture/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 17:36:23+00:00

<p>Article URL: <a href="https://china-journal.org/2016/03/14/filial-piety-in-chinese-culture/">https://china-journal.org/2016/03/14/filial-piety-in-chinese-culture/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36116091">https://news.ycombinator.com/item?id=36116091</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Tesla rethinks the assembly line
 - [https://www.assemblymag.com/articles/97788-tesla-rethinks-the-assembly-line](https://www.assemblymag.com/articles/97788-tesla-rethinks-the-assembly-line)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 17:28:35+00:00

<p>Article URL: <a href="https://www.assemblymag.com/articles/97788-tesla-rethinks-the-assembly-line">https://www.assemblymag.com/articles/97788-tesla-rethinks-the-assembly-line</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36116018">https://news.ycombinator.com/item?id=36116018</a></p>
<p>Points: 23</p>
<p># Comments: 8</p>

## System76 Virgo Aims to Be the Quietest yet Most Performant Linux Laptop
 - [https://www.phoronix.com/news/System76-Virgo-Quiet-Perform](https://www.phoronix.com/news/System76-Virgo-Quiet-Perform)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 16:27:40+00:00

<p>Article URL: <a href="https://www.phoronix.com/news/System76-Virgo-Quiet-Perform">https://www.phoronix.com/news/System76-Virgo-Quiet-Perform</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36115413">https://news.ycombinator.com/item?id=36115413</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Joker is a small interpreted dialect of Clojure written in Go
 - [https://joker-lang.org/](https://joker-lang.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 16:16:13+00:00

<p>Article URL: <a href="https://joker-lang.org/">https://joker-lang.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36115321">https://news.ycombinator.com/item?id=36115321</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## One Click Deepfake
 - [https://github.com/s0md3v/roop](https://github.com/s0md3v/roop)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 16:12:22+00:00

<p>Article URL: <a href="https://github.com/s0md3v/roop">https://github.com/s0md3v/roop</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36115283">https://news.ycombinator.com/item?id=36115283</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Heavy electric trucks cheaper than diesel goods trucks
 - [https://www.chalmers.se/en/current/news/e2-heavy-electric-trucks-cheaper-than-diesel-goods-trucks/](https://www.chalmers.se/en/current/news/e2-heavy-electric-trucks-cheaper-than-diesel-goods-trucks/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 16:07:53+00:00

<p>Article URL: <a href="https://www.chalmers.se/en/current/news/e2-heavy-electric-trucks-cheaper-than-diesel-goods-trucks/">https://www.chalmers.se/en/current/news/e2-heavy-electric-trucks-cheaper-than-diesel-goods-trucks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36115231">https://news.ycombinator.com/item?id=36115231</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## As rising oceans threaten NYC, study documents another risk: The city is sinking
 - [https://apnews.com/article/new-york-sinking-sea-level-rise-77c92f3603e90d7322b54e339d085abb](https://apnews.com/article/new-york-sinking-sea-level-rise-77c92f3603e90d7322b54e339d085abb)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 15:48:36+00:00

<p>Article URL: <a href="https://apnews.com/article/new-york-sinking-sea-level-rise-77c92f3603e90d7322b54e339d085abb">https://apnews.com/article/new-york-sinking-sea-level-rise-77c92f3603e90d7322b54e339d085abb</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36115062">https://news.ycombinator.com/item?id=36115062</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Wikipedia had wrong Vatican flag for years – now incorrect flags are everywhere
 - [https://www.catholicnewsagency.com/news/254032/wikipedia-had-the-wrong-vatican-city-flag-for-years-now-incorrect-flags-are-everywhere](https://www.catholicnewsagency.com/news/254032/wikipedia-had-the-wrong-vatican-city-flag-for-years-now-incorrect-flags-are-everywhere)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 15:29:58+00:00

<p>Article URL: <a href="https://www.catholicnewsagency.com/news/254032/wikipedia-had-the-wrong-vatican-city-flag-for-years-now-incorrect-flags-are-everywhere">https://www.catholicnewsagency.com/news/254032/wikipedia-had-the-wrong-vatican-city-flag-for-years-now-incorrect-flags-are-everywhere</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36114896">https://news.ycombinator.com/item?id=36114896</a></p>
<p>Points: 27</p>
<p># Comments: 10</p>

## Rheinmetall pilot project for curb stone chargers for EVs
 - [https://www.rheinmetall.com/en/media/news-watch/news/2023/mai/2023-05-16-rheinmetall-launches-first-pilot-project-for-innovative-curb-stone-chargers](https://www.rheinmetall.com/en/media/news-watch/news/2023/mai/2023-05-16-rheinmetall-launches-first-pilot-project-for-innovative-curb-stone-chargers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 15:14:52+00:00

<p>Article URL: <a href="https://www.rheinmetall.com/en/media/news-watch/news/2023/mai/2023-05-16-rheinmetall-launches-first-pilot-project-for-innovative-curb-stone-chargers">https://www.rheinmetall.com/en/media/news-watch/news/2023/mai/2023-05-16-rheinmetall-launches-first-pilot-project-for-innovative-curb-stone-chargers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36114775">https://news.ycombinator.com/item?id=36114775</a></p>
<p>Points: 20</p>
<p># Comments: 19</p>

## Software bugs that cause real-world harm
 - [https://pointersgonewild.com/2023/05/29/software-bugs-that-cause-real-world-harm/](https://pointersgonewild.com/2023/05/29/software-bugs-that-cause-real-world-harm/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 14:59:38+00:00

<p>Article URL: <a href="https://pointersgonewild.com/2023/05/29/software-bugs-that-cause-real-world-harm/">https://pointersgonewild.com/2023/05/29/software-bugs-that-cause-real-world-harm/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36114641">https://news.ycombinator.com/item?id=36114641</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## The Johari Window
 - [https://en.wikipedia.org/wiki/Johari_window](https://en.wikipedia.org/wiki/Johari_window)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 14:52:14+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Johari_window">https://en.wikipedia.org/wiki/Johari_window</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36114562">https://news.ycombinator.com/item?id=36114562</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## C++17’s Useful Features for Embedded Systems
 - [https://interrupt.memfault.com/blog/cpp-17-for-embedded](https://interrupt.memfault.com/blog/cpp-17-for-embedded)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 14:09:58+00:00

<p>Article URL: <a href="https://interrupt.memfault.com/blog/cpp-17-for-embedded">https://interrupt.memfault.com/blog/cpp-17-for-embedded</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36114147">https://news.ycombinator.com/item?id=36114147</a></p>
<p>Points: 26</p>
<p># Comments: 0</p>

## XFS Metadata Corruption on Linux 6.3 Tracked Down to One Missing One-Line Patch
 - [https://www.phoronix.com/news/XFS-Patch-For-Linux-6.3](https://www.phoronix.com/news/XFS-Patch-For-Linux-6.3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 13:38:23+00:00

<p>Article URL: <a href="https://www.phoronix.com/news/XFS-Patch-For-Linux-6.3">https://www.phoronix.com/news/XFS-Patch-For-Linux-6.3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113828">https://news.ycombinator.com/item?id=36113828</a></p>
<p>Points: 32</p>
<p># Comments: 3</p>

## Thanks, David Peter
 - [https://duncanlock.net/blog/2023/05/28/thanks-david-peter/](https://duncanlock.net/blog/2023/05/28/thanks-david-peter/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 13:08:04+00:00

<p>Article URL: <a href="https://duncanlock.net/blog/2023/05/28/thanks-david-peter/">https://duncanlock.net/blog/2023/05/28/thanks-david-peter/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113586">https://news.ycombinator.com/item?id=36113586</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Show HN: A weekly newsletter that explain tech terms in plain, everyday language
 - [https://codictionary.com/](https://codictionary.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 13:06:00+00:00

<p>Hey there! As a software developer, I've always wished that my clients, managers, directors, and stakeholders could get a better grasp of programming. I know they can't become coding gurus overnight, but wouldn't it be awesome if they could at least understand terms like APIs, caching, and variables? I think it would make communication a whole lot smoother and help us have more meaningful conversations. 
I decided to create a newsletter that explains all these tech terms in super simple language!<p>At first, I tried to make a newsletter just for my clients. I wanted to bridge the gap between tech-savvy folks like me and those who aren't as familiar with the ins and outs of programming. But then it hit me—why not make it available to everyone who wants to understand the tech world without having to learn how to code? So, I revamped it to cater to anyone who's curious about technology.<p>Each edition of the newsletter focuses on a specific tech term or concept. We'll break it down, ditch the complicated jargon, and give you real-life examples that make it all crystal clear. My goal isn't to teach you programming (that's a whole different ball game). Instead, I want to give you the knowledge you need to have better conversations and a deeper understanding of the tech that shapes our world.<p>So, whether you're an entrepreneur who wants to connect better with your tech team, a project manager looking to understand what the developers are talking about, or simply a tech enthusiast who wants to dive into the digital world, hop on board and let's make tech simple together!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113564">https://news.ycombinator.com/item?id=36113564</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## India ruling party's IT cell used AI to show smile on arrested protesters' faces
 - [https://www.altnews.in/wrestlers-detained-in-delhi-ai-image-of-smiling-vinesh-sangeeta-phogat-viral/](https://www.altnews.in/wrestlers-detained-in-delhi-ai-image-of-smiling-vinesh-sangeeta-phogat-viral/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 13:04:39+00:00

<p>Article URL: <a href="https://www.altnews.in/wrestlers-detained-in-delhi-ai-image-of-smiling-vinesh-sangeeta-phogat-viral/">https://www.altnews.in/wrestlers-detained-in-delhi-ai-image-of-smiling-vinesh-sangeeta-phogat-viral/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113551">https://news.ycombinator.com/item?id=36113551</a></p>
<p>Points: 50</p>
<p># Comments: 5</p>

## Hardening Drupal with WebAssembly
 - [https://wasmlabs.dev/articles/hardening-drupal-with-webassembly/](https://wasmlabs.dev/articles/hardening-drupal-with-webassembly/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 13:03:05+00:00

<p>Article URL: <a href="https://wasmlabs.dev/articles/hardening-drupal-with-webassembly/">https://wasmlabs.dev/articles/hardening-drupal-with-webassembly/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113542">https://news.ycombinator.com/item?id=36113542</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Winning the AI Products Arms Race
 - [https://www.reforge.com/blog/ai-products-arms-race](https://www.reforge.com/blog/ai-products-arms-race)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 13:02:14+00:00

<p>Article URL: <a href="https://www.reforge.com/blog/ai-products-arms-race">https://www.reforge.com/blog/ai-products-arms-race</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113534">https://news.ycombinator.com/item?id=36113534</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## India’s Olympics medalist female wrestlers detained while protesting against SA
 - [https://twitter.com/SakshiMalik/status/1662729269532065792](https://twitter.com/SakshiMalik/status/1662729269532065792)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:52:48+00:00

<p>Article URL: <a href="https://twitter.com/SakshiMalik/status/1662729269532065792">https://twitter.com/SakshiMalik/status/1662729269532065792</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113453">https://news.ycombinator.com/item?id=36113453</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## The UX Research Reckoning is Here
 - [https://medium.com/onebigthought/the-ux-research-reckoning-is-here-c63710ea4084](https://medium.com/onebigthought/the-ux-research-reckoning-is-here-c63710ea4084)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:50:41+00:00

<p>Article URL: <a href="https://medium.com/onebigthought/the-ux-research-reckoning-is-here-c63710ea4084">https://medium.com/onebigthought/the-ux-research-reckoning-is-here-c63710ea4084</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113444">https://news.ycombinator.com/item?id=36113444</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Deus Ex – Alpha Terrain
 - [https://simonschreibt.de/gat/deus-ex-alpha-terrain/](https://simonschreibt.de/gat/deus-ex-alpha-terrain/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:49:41+00:00

<p>Article URL: <a href="https://simonschreibt.de/gat/deus-ex-alpha-terrain/">https://simonschreibt.de/gat/deus-ex-alpha-terrain/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113432">https://news.ycombinator.com/item?id=36113432</a></p>
<p>Points: 30</p>
<p># Comments: 7</p>

## 300ms Faster: Reducing Wikipedia's Total Blocking Time
 - [https://www.nray.dev/blog/300ms-faster-reducing-wikipedias-total-blocking-time/](https://www.nray.dev/blog/300ms-faster-reducing-wikipedias-total-blocking-time/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:49:11+00:00

<p>Article URL: <a href="https://www.nray.dev/blog/300ms-faster-reducing-wikipedias-total-blocking-time/">https://www.nray.dev/blog/300ms-faster-reducing-wikipedias-total-blocking-time/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113430">https://news.ycombinator.com/item?id=36113430</a></p>
<p>Points: 69</p>
<p># Comments: 9</p>

## Escape from Big Publishing: How Open Source Provided the Alternative Path
 - [https://systemsapproach.substack.com/p/escape-from-big-publishing](https://systemsapproach.substack.com/p/escape-from-big-publishing)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:33:19+00:00

<p>Article URL: <a href="https://systemsapproach.substack.com/p/escape-from-big-publishing">https://systemsapproach.substack.com/p/escape-from-big-publishing</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113335">https://news.ycombinator.com/item?id=36113335</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Ask HN: What are the most reliable tech sites in east and south Asia?
 - [https://news.ycombinator.com/item?id=36113331](https://news.ycombinator.com/item?id=36113331)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:32:58+00:00

<p>Almost all of my tech news comes via HN, SubStack, Twitter and Reddit, but  they only occasionally cite blogs or reports from China, Japan, South Korea or India - countries where a significant proportion of technology is built, designed, or supported from.<p>While there is a lot of tech news related to what is going on in those countries (often for the wrong reasons), it’s hard to gage what the tech ecosystem is up to without knowing where to look.<p>Language barriers aside (which are becoming less of an issue anyway), where would one go for reliable and direct news around semiconductor developments in Taiwan, or the weird products that emerge out of Shenzhen through AliExpress?<p>Is there an HN of India? Or Indonesia?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113331">https://news.ycombinator.com/item?id=36113331</a></p>
<p>Points: 17</p>
<p># Comments: 6</p>

## A Coder in Courierland (2005)
 - [https://web.archive.org/web/20050322021208/http://www.kuro5hin.org/story/2005/3/19/133129/548](https://web.archive.org/web/20050322021208/http://www.kuro5hin.org/story/2005/3/19/133129/548)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:31:26+00:00

<p>Article URL: <a href="https://web.archive.org/web/20050322021208/http://www.kuro5hin.org/story/2005/3/19/133129/548">https://web.archive.org/web/20050322021208/http://www.kuro5hin.org/story/2005/3/19/133129/548</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113324">https://news.ycombinator.com/item?id=36113324</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Amprius High-Density Batteries Go Aloft
 - [https://www.eetimes.com/amprius-high-density-batteries-go-aloft/](https://www.eetimes.com/amprius-high-density-batteries-go-aloft/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:30:13+00:00

<p>Article URL: <a href="https://www.eetimes.com/amprius-high-density-batteries-go-aloft/">https://www.eetimes.com/amprius-high-density-batteries-go-aloft/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113307">https://news.ycombinator.com/item?id=36113307</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Mullvad: Removing the Support for Forwarded Ports
 - [https://mullvad.net/en/blog/2023/5/29/removing-the-support-for-forwarded-ports/](https://mullvad.net/en/blog/2023/5/29/removing-the-support-for-forwarded-ports/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:17:54+00:00

<p>Article URL: <a href="https://mullvad.net/en/blog/2023/5/29/removing-the-support-for-forwarded-ports/">https://mullvad.net/en/blog/2023/5/29/removing-the-support-for-forwarded-ports/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113215">https://news.ycombinator.com/item?id=36113215</a></p>
<p>Points: 13</p>
<p># Comments: 10</p>

## Using computers more freely and safely (2022)
 - [http://akkartik.name/freewheeling](http://akkartik.name/freewheeling)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 12:04:09+00:00

<p>Article URL: <a href="http://akkartik.name/freewheeling">http://akkartik.name/freewheeling</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36113115">https://news.ycombinator.com/item?id=36113115</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Fossil tells the 'tail' of an ancient beast
 - [https://phys.org/news/2023-05-fossil-tail-ancient-beast.html](https://phys.org/news/2023-05-fossil-tail-ancient-beast.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 11:15:25+00:00

<p>Article URL: <a href="https://phys.org/news/2023-05-fossil-tail-ancient-beast.html">https://phys.org/news/2023-05-fossil-tail-ancient-beast.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36112834">https://news.ycombinator.com/item?id=36112834</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Japan will try to beam solar power from space by 2025
 - [https://www.engadget.com/japan-will-try-to-beam-solar-power-from-space-by-2025-214338244.html](https://www.engadget.com/japan-will-try-to-beam-solar-power-from-space-by-2025-214338244.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 10:45:33+00:00

<p>Article URL: <a href="https://www.engadget.com/japan-will-try-to-beam-solar-power-from-space-by-2025-214338244.html">https://www.engadget.com/japan-will-try-to-beam-solar-power-from-space-by-2025-214338244.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36112641">https://news.ycombinator.com/item?id=36112641</a></p>
<p>Points: 23</p>
<p># Comments: 6</p>

## Circles Rolling on Circles (2014)
 - [https://plus.maths.org/content/circles-rolling-circles](https://plus.maths.org/content/circles-rolling-circles)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 08:56:01+00:00

<p>Article URL: <a href="https://plus.maths.org/content/circles-rolling-circles">https://plus.maths.org/content/circles-rolling-circles</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36112080">https://news.ycombinator.com/item?id=36112080</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Arcade Authorship – High Score Table Credits
 - [https://thehistoryofhowweplay.wordpress.com/2023/05/14/arcade-authorship-high-score-table-credits/](https://thehistoryofhowweplay.wordpress.com/2023/05/14/arcade-authorship-high-score-table-credits/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 08:47:29+00:00

<p>Article URL: <a href="https://thehistoryofhowweplay.wordpress.com/2023/05/14/arcade-authorship-high-score-table-credits/">https://thehistoryofhowweplay.wordpress.com/2023/05/14/arcade-authorship-high-score-table-credits/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36112030">https://news.ycombinator.com/item?id=36112030</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## The Statistics Handbook (free culture LaTeX handbook)
 - [https://github.com/carloocchiena/the_statistics_handbook](https://github.com/carloocchiena/the_statistics_handbook)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 08:39:37+00:00

<p>Article URL: <a href="https://github.com/carloocchiena/the_statistics_handbook">https://github.com/carloocchiena/the_statistics_handbook</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36111993">https://news.ycombinator.com/item?id=36111993</a></p>
<p>Points: 25</p>
<p># Comments: 5</p>

## Donut: OCR-Free Document Understanding Transformer
 - [https://github.com/clovaai/donut](https://github.com/clovaai/donut)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 08:19:46+00:00

<p>Article URL: <a href="https://github.com/clovaai/donut">https://github.com/clovaai/donut</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36111878">https://news.ycombinator.com/item?id=36111878</a></p>
<p>Points: 16</p>
<p># Comments: 6</p>

## AI will slightly drain the swamp of higher ed
 - [https://betonit.substack.com/p/how-ai-will-change-higher-education](https://betonit.substack.com/p/how-ai-will-change-higher-education)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 08:09:47+00:00

<p>Article URL: <a href="https://betonit.substack.com/p/how-ai-will-change-higher-education">https://betonit.substack.com/p/how-ai-will-change-higher-education</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36111823">https://news.ycombinator.com/item?id=36111823</a></p>
<p>Points: 32</p>
<p># Comments: 15</p>

## No A/C? No problem, if buildings copy networked tunnels of termite mounds
 - [https://arstechnica.com/science/2023/05/intricate-tunnels-of-termite-mounds-could-be-key-to-energy-efficient-buildings/](https://arstechnica.com/science/2023/05/intricate-tunnels-of-termite-mounds-could-be-key-to-energy-efficient-buildings/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 07:54:44+00:00

<p>Article URL: <a href="https://arstechnica.com/science/2023/05/intricate-tunnels-of-termite-mounds-could-be-key-to-energy-efficient-buildings/">https://arstechnica.com/science/2023/05/intricate-tunnels-of-termite-mounds-could-be-key-to-energy-efficient-buildings/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36111750">https://news.ycombinator.com/item?id=36111750</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## Cloudflare Workers Introduces Connect() API to Create TCP Sockets
 - [https://www.infoq.com/news/2023/05/cloudflare-workers-connect-api/](https://www.infoq.com/news/2023/05/cloudflare-workers-connect-api/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 07:44:15+00:00

<p>Article URL: <a href="https://www.infoq.com/news/2023/05/cloudflare-workers-connect-api/">https://www.infoq.com/news/2023/05/cloudflare-workers-connect-api/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36111683">https://news.ycombinator.com/item?id=36111683</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Production AI systems are hard
 - [https://methexis.substack.com/p/production-ai-systems-are-really](https://methexis.substack.com/p/production-ai-systems-are-really)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 07:27:20+00:00

<p>Article URL: <a href="https://methexis.substack.com/p/production-ai-systems-are-really">https://methexis.substack.com/p/production-ai-systems-are-really</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36111596">https://news.ycombinator.com/item?id=36111596</a></p>
<p>Points: 21</p>
<p># Comments: 12</p>

## The coordinate system for an infinite spreadsheet
 - [https://www.quadratichq.com/blog/2023-05-15-coordinate-system-for-infinite-spreadsheet](https://www.quadratichq.com/blog/2023-05-15-coordinate-system-for-infinite-spreadsheet)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 06:45:28+00:00

<p>Article URL: <a href="https://www.quadratichq.com/blog/2023-05-15-coordinate-system-for-infinite-spreadsheet">https://www.quadratichq.com/blog/2023-05-15-coordinate-system-for-infinite-spreadsheet</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36111392">https://news.ycombinator.com/item?id=36111392</a></p>
<p>Points: 7</p>
<p># Comments: 6</p>

## Commodore 64 Web server [video]
 - [https://www.youtube.com/watch?v=O2cMnxShCVQ](https://www.youtube.com/watch?v=O2cMnxShCVQ)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 04:35:44+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=O2cMnxShCVQ">https://www.youtube.com/watch?v=O2cMnxShCVQ</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36110684">https://news.ycombinator.com/item?id=36110684</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Fitting 44% More Data on a C64/1541 Floppy Disk
 - [https://www.pagetable.com/?p=1107](https://www.pagetable.com/?p=1107)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 04:35:15+00:00

<p>Article URL: <a href="https://www.pagetable.com/?p=1107">https://www.pagetable.com/?p=1107</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36110680">https://news.ycombinator.com/item?id=36110680</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## How much does it cost to develop and manufacture an electronic product? (2022)
 - [https://predictabledesigns.com/how-much-does-it-cost-to-develop-and-manufacture-new-electronic-product/](https://predictabledesigns.com/how-much-does-it-cost-to-develop-and-manufacture-new-electronic-product/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 04:26:15+00:00

<p>Article URL: <a href="https://predictabledesigns.com/how-much-does-it-cost-to-develop-and-manufacture-new-electronic-product/">https://predictabledesigns.com/how-much-does-it-cost-to-develop-and-manufacture-new-electronic-product/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36110629">https://news.ycombinator.com/item?id=36110629</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Everything You Want to Know About Media Queries and Responsive Design
 - [https://engineering.kablamo.com.au/posts/2023/media-queries-and-responsive-design/](https://engineering.kablamo.com.au/posts/2023/media-queries-and-responsive-design/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 04:13:45+00:00

<p>Article URL: <a href="https://engineering.kablamo.com.au/posts/2023/media-queries-and-responsive-design/">https://engineering.kablamo.com.au/posts/2023/media-queries-and-responsive-design/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36110576">https://news.ycombinator.com/item?id=36110576</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Let us serve you, but don't bring us down
 - [https://blog.archive.org/2023/05/29/let-us-serve-you-but-dont-bring-us-down/](https://blog.archive.org/2023/05/29/let-us-serve-you-but-dont-bring-us-down/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 04:03:29+00:00

<p>Article URL: <a href="https://blog.archive.org/2023/05/29/let-us-serve-you-but-dont-bring-us-down/">https://blog.archive.org/2023/05/29/let-us-serve-you-but-dont-bring-us-down/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36110527">https://news.ycombinator.com/item?id=36110527</a></p>
<p>Points: 138</p>
<p># Comments: 22</p>

## The advantage of WASM compared with container runtimes
 - [https://community.arm.com/arm-community-blogs/b/infrastructure-solutions-blog/posts/container-runtimes-wasmedge-arm](https://community.arm.com/arm-community-blogs/b/infrastructure-solutions-blog/posts/container-runtimes-wasmedge-arm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 03:20:46+00:00

<p>Article URL: <a href="https://community.arm.com/arm-community-blogs/b/infrastructure-solutions-blog/posts/container-runtimes-wasmedge-arm">https://community.arm.com/arm-community-blogs/b/infrastructure-solutions-blog/posts/container-runtimes-wasmedge-arm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36110253">https://news.ycombinator.com/item?id=36110253</a></p>
<p>Points: 18</p>
<p># Comments: 6</p>

## New Arm Cores Deliver Up to 40% Better Performance
 - [https://www.phonescoop.com/articles/article.php?a=23023](https://www.phonescoop.com/articles/article.php?a=23023)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 02:29:47+00:00

<p>Article URL: <a href="https://www.phonescoop.com/articles/article.php?a=23023">https://www.phonescoop.com/articles/article.php?a=23023</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36109916">https://news.ycombinator.com/item?id=36109916</a></p>
<p>Points: 23</p>
<p># Comments: 1</p>

## My startup crossed $2M/yr and now co-founder is going for a power grab
 - [https://news.ycombinator.com/item?id=36109851](https://news.ycombinator.com/item?id=36109851)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 02:15:47+00:00

<p>So 3 years ago, me and 4 guys start a company. Roles are as follow:
CEO
COO
Chief Development Officer
Chief UX officer (CUXO)
Chief Data officer (Me)<p>Everyone is 20% owner.<p>Currently my team has 9 people.
Chief UX officer team is 3 people. 
Total company is about 17 people.<p>Our business model is basically...we collect publicly available data, clean, normalize, and enriched with other data sources. The data is made available via an API as well as front end.<p>I basically architected the entire backend infrastructure that manages all of our data pipelines as well as was significantly involved in development of the models/algorithms for enriching data. Chief Development Officer helped out with some execution in early stages.<p>Chief UX officer was responsible for front end. He also manages the API operations after we publish data to the db he manages.<p>During formation, ~3 years ago, we agreed no one would have the role of CTO. About a year or so after formation,  CUXO said he wanted his title to be changed to CTO. 
Chief Dev Officer and I strongly opposed this and with the support of CEO, we decided that there was no need to change things from what we had originally agreed on.<p>Chief Development Officer left the company about a year ago and all his responsibilities fell on me. Though tbh, he wasn't doing much since I had hired a team of offshore engineers.<p>(Today)<p>CUXO is the last person to quit his job and go full time. We had a meeting this morning and he said that He wants to change his title to CTO when he starts next month. 
His stated reasoning was pretty silly to be honest, He said that he wanted the title because it would be better for his career after the startup - which to me is probably the least compelling reason possible.<p>CEO and COO said that didn't want to get involved and it was for me and CUXO to sort it out ourselves.<p>I'm planning on having a meeting 1:1 with him this weekend and explaining that I think the role of CTO implies a set of responsibilities far broader than would be appropriate for either of us since we've kept a very sharp line between front end and back end in terms of management. I think him being CTO will also cause confusion with regards to our roles in the company, both internally with our respective teams and externally when we have client meetings.<p>I also feel like I've built an extremely sophisticated back end system on a pretty unbelievable budget...and having him as the CTO I feel would massively undermine the work that I've done.<p>Lastly, I don't like the idea of us trying to go back and change the original agreement. We all decided on equal equity (20%) as well as no CTO because we wanted to make sure everyone felt equal.<p>Aside from the fact that I don't think he deserves the role of CTO, I really don't like the idea of us re-negotiating the terms of the business formation. Suppose he gets the CTO role, will he later come back and argue for more equity?<p>I should also mention that the first time he asked to be CTO, he said he deserved it because he setup the slack and gmail instances so that makes him CTO. This indicates to me that he is fundamentally unrealistic in his outlook. Also combined with the fact that our relationship has always been a bit tense, I expect him to react very negatively to me opposing his title change.<p>Another important piece of information is that the CEO and CUXO are old friends which I think might be impacting his desire to avoid getting involved in this.<p>I often read about startups failing because of disagreements with co-founders, and I'm really concerned that this could become a much bigger deal than it should be depending on how insistent the CUXO is. I strongly object to him taking this role and I feel like he strongly feels he deserves it.<p>Does anyone have any advice they can give on how I should proceed?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36109851">https://news.ycombinator.com/item?id=36109851</a></p>
<p>Points: 14</p>
<p># Comments: 17</p>

## WordPress Turns 20
 - [https://ma.tt/2023/05/wp20-audrey-scholars/](https://ma.tt/2023/05/wp20-audrey-scholars/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-29 00:24:32+00:00

<p>Article URL: <a href="https://ma.tt/2023/05/wp20-audrey-scholars/">https://ma.tt/2023/05/wp20-audrey-scholars/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36109193">https://news.ycombinator.com/item?id=36109193</a></p>
<p>Points: 40</p>
<p># Comments: 7</p>

