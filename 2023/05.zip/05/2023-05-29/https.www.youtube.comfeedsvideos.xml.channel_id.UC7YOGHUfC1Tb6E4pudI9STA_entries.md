# Source:Mental Outlaw, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA, language:en-US

## Tesla Had a Massive Data Leak
 - [https://www.youtube.com/watch?v=AXYP-d05xz4](https://www.youtube.com/watch?v=AXYP-d05xz4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA
 - date published: 2023-05-29 22:41:03+00:00

In this video I discuss the 100 GB data leak that came out of Tesla and was first reported on by Handelsblatt. 

My merch is available at
https://based.win/

Subscribe to me on Odysee.com
https://odysee.com/@AlphaNerd:8

₿💰💵💲Help Support the Channel by Donating Crypto💲💵💰₿

Monero
45F2bNHVcRzXVBsvZ5giyvKGAgm6LFhMsjUUVPTEtdgJJ5SNyxzSNUmFSBR5qCCWLpjiUjYMkmZoX9b3cChNjvxR7kvh436

Bitcoin
3MMKHXPQrGHEsmdHaAGD59FWhKFGeUsAxV

Ethereum
0xeA4DA3F9BAb091Eb86921CA6E41712438f4E5079

Litecoin
MBfrxLJMuw26hbVi2MjCVDFkkExz8rYvUF

