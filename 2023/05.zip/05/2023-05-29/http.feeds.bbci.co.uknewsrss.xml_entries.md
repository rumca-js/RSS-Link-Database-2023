# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Supermarket price rises hit new high in May
 - [https://www.bbc.co.uk/news/business-65747137?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65747137?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 23:37:28+00:00

Fresh produce prices are lower but coffee and chocolate as well as non-food items lift inflation.

## Newspaper headlines: Labour housing plan and banks 'ripping off' savers
 - [https://www.bbc.co.uk/news/blogs-the-papers-65750501?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-65750501?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 23:34:06+00:00

Labour plans to let councils buy land cheaply and a call for action on interest rates lead the papers.

## Lionel Messi: From shy genius to 'bad boy' leader – his Qatar transformation
 - [https://www.bbc.co.uk/sport/football/65740199?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65740199?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 23:02:18+00:00

The 'completion' of football at the 2022 World Cup required Lionel Messi to configure his character and rediscover his childhood.

## Army's IRA spy Freddie Scappaticci admitted killing suspected informer
 - [https://www.bbc.co.uk/news/uk-northern-ireland-65748734?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-65748734?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 23:00:18+00:00

The detail is uncovered in a BBC Spotlight investigation into Freddie Scappaticci, who died in April.

## Harry Maguire: Manchester United boss Erik ten Hag says defender has decision to make
 - [https://www.bbc.co.uk/sport/football/65749368?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65749368?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 22:02:09+00:00

Erik Ten Hag says Harry Maguire has to decide on his future with Manchester United after making just 16 league appearances for the club this season.

## German police arrest stripper over toy gun
 - [https://www.bbc.co.uk/news/world-europe-65750154?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65750154?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 21:42:42+00:00

Frankfurt police say they took action after receiving reports about a man with an assault rifle.

## IPL 2023: Chennai Super Kings claim last-ball victory over Gujarat Titans in thrilling final
 - [https://www.bbc.co.uk/sport/cricket/65742591?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65742591?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 21:10:01+00:00

Chennai Super Kings stage a remarkable chase to beat Gujarat Titans by five wickets and win the Indian Premier League for a fifth time.

## Darren Moore: Sheffield Wednesday boss says promotion is 'the stuff of dreams'
 - [https://www.bbc.co.uk/sport/football/65749706?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65749706?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 19:15:12+00:00

Sheffield Wednesday boss Darren Moore says his side's win over Barnsley in the League One play-off final proves "anything is possible".

## Lawmakers race to secure US debt deal votes as deadline looms
 - [https://www.bbc.co.uk/news/world-us-canada-65729305?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65729305?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 19:14:21+00:00

A deal to raise the debt ceiling must now pass in the narrowly-divided House of Representatives.

## Kosovo: Fresh clashes as Nato troops called in to northern towns
 - [https://www.bbc.co.uk/news/world-europe-65748024?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65748024?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 18:59:02+00:00

Serb protesters are angry at ethnic Albanian mayors being installed in Serb-majority areas.

## Luton Town: Thousands line streets for Premier League promotion party
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-65750061?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-65750061?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 18:36:40+00:00

Luton will play top flight football for the first time in more than 30 years next season.

## Man dies after workplace explosion in Donegal
 - [https://www.bbc.co.uk/news/articles/c8419zjw111o?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/c8419zjw111o?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 17:11:58+00:00

He was working on the outskirts of a village on the north-west coast when the incident happened.

## Barnsley 0-1 Sheffield Wednesday: Josh Windass wins League One play-off final in last minute of extra time
 - [https://www.bbc.co.uk/sport/football/65667707?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65667707?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 17:04:28+00:00

Josh Windass scores the winning goal with the last action of the League One play-off final as Sheffield Wednesday beat 10-man Barnsley.

## Succession: Critics praise 'perfect, brutal' finale
 - [https://www.bbc.co.uk/news/entertainment-arts-65747269?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65747269?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 17:00:35+00:00

Spoiler-free zone: The show is widely praised by critics, some of whom compare it with Shakespeare.

## Watch: Cheese rollers run down near-vertical hill
 - [https://www.bbc.co.uk/news/uk-england-gloucestershire-65748725?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-gloucestershire-65748725?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 16:34:29+00:00

See dozens run down Coopers Hill in pursuit of a wheel of Double Gloucester cheese.

## Steve Coogan and Lee Mack join pollution protest at Windermere
 - [https://www.bbc.co.uk/news/uk-england-cumbria-65747962?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cumbria-65747962?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 16:30:40+00:00

They are campaigning against sewage discharge into England's largest lake.

## Premier League 2022-23: Who were on an upward curve and who were sleepwalking?
 - [https://www.bbc.co.uk/sport/football/65745007?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65745007?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 16:18:05+00:00

BBC Sport's chief football writer Phil McNulty assesses each Premier League club's season - and looks back at his predictions.

## Boy, 6, conquers UK's 12 highest peaks for charity
 - [https://www.bbc.co.uk/news/uk-england-lancashire-65747050?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-65747050?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 15:52:39+00:00

Oscar Burrow now wants to go on to become the youngest person ever to scale Mount Everest.

## Cheese rolling race: Hundreds compete in Coopers Hill event
 - [https://www.bbc.co.uk/news/uk-england-gloucestershire-65748124?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-gloucestershire-65748124?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 15:43:22+00:00

Canadian Delaney Irving, who won the women's race, was knocked unconscious as she chased the cheese.

## French Open 2023 results: Jack Draper 'hates being the guy who's injured a lot'
 - [https://www.bbc.co.uk/sport/tennis/65747509?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65747509?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 15:40:21+00:00

Jack Draper's injury problems continue as the young Briton retires from his French Open first-round match with a shoulder issue.

## Imran Khan: Ex-Pakistan PM tells BBC crackdown on party is 'untenable'
 - [https://www.bbc.co.uk/news/world-asia-65747563?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65747563?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 14:54:22+00:00

Pakistan's ex-leader says he will wait and see what happens as his party colleagues are arrested and he may be, too.

## US war hero's remains returned home after 73 years
 - [https://www.bbc.co.uk/news/world-us-canada-65729303?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65729303?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 14:53:22+00:00

Cpl Luther Herschel Story died in the Korean War in 1950. His family is finally burying his remains.

## Just Stop Oil protest: Two in court over rugby match stoppage
 - [https://www.bbc.co.uk/news/uk-england-london-65747592?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-65747592?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 14:47:40+00:00

Patrick Hart and Samuel Johnson are charged with criminal damage and aggravated trespass.

## Harry Styles sets Scottish stadium concert record at Murrayfield
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-65745869?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-65745869?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 14:27:26+00:00

More than 65,000 fans watched the former One Direction star perform at Murrayfield in Edinburgh.

## Ashes 2023: Brendon McCullum says 'formidable' Australia great opportunity for England to prove themselves
 - [https://www.bbc.co.uk/sport/cricket/65747363?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65747363?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 13:46:57+00:00

Coach Brendon McCullum says "there is no greater opportunity" for England to prove themselves than the "formidable" challenge of the Ashes series against Australia.

## Uganda approves tough new anti-LGBT law
 - [https://www.bbc.co.uk/news/world-africa-65745850?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65745850?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 12:37:33+00:00

UNAids and the US warn that Uganda's progress in tackling HIV is now in "grave jeopardy".

## Beekeepers 'run out of equipment' as swarms rise
 - [https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-65746081?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-65746081?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 12:26:02+00:00

Experts say a long, cold spring before warmer weather means larger swarms are searching for hives.

## Mauricio Pochettino: Chelsea appoint ex-Tottenham boss as new manager
 - [https://www.bbc.co.uk/sport/football/65371524?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65371524?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 12:17:57+00:00

Chelsea appoint former Tottenham boss Mauricio Pochettino as their new manager on a two-year deal.

## Mauricio Pochettino: Chelsea appointment could be defining moment of new era
 - [https://www.bbc.co.uk/sport/football/65386958?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65386958?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 12:03:59+00:00

Mauricio Pochettino's appointment could be the defining moment of Chelsea's new era - but the owners cannot afford for it to fail.

## French Open 2023 results: Jack Draper retires injured in first round
 - [https://www.bbc.co.uk/sport/tennis/65746694?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65746694?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 12:00:48+00:00

Britain's Jack Draper's injury problems continue as he is forced to quit his French Open first-round match with a shoulder issue.

## French Open 2023 results: Sloane Stephens beats Karolina Pliskova, Madison Keys through
 - [https://www.bbc.co.uk/sport/tennis/65745532?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65745532?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 11:55:11+00:00

Former US Open champion Sloane Stephens shows why she is one of the French Open's most dangerous unseeded players by knocking out Karolina Pliskova.

## This Morning: Presenters say 'we love making this show' as Schofield row continues
 - [https://www.bbc.co.uk/news/entertainment-arts-65745586?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65745586?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 11:49:07+00:00

"We love making this show", says Dermot O'Leary after criticism of its culture by its ex-resident doctor.

## John Caldwell: Seven men in court over attempted murder of detective
 - [https://www.bbc.co.uk/news/uk-northern-ireland-65723277?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-65723277?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 11:47:09+00:00

The detective was shot after coaching youth football in Omagh, County Tyrone, in February.

## Delhi murder: Indian man held after brutally murdering girl in public
 - [https://www.bbc.co.uk/news/world-asia-india-65745958?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-65745958?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 11:44:39+00:00

Footage of the assault shows the man repeatedly stabbing the girl in a public place as people watch.

## Two injured after escaped bull charges into crowd at Kununurra rodeo
 - [https://www.bbc.co.uk/news/world-australia-65745451?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-65745451?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 11:35:19+00:00

Social media videos show people line-dancing at a rodeo, before the escaped bull charges through the arena.

## Government support to be offered to disaster witnesses
 - [https://www.bbc.co.uk/news/uk-england-manchester-65745703?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-65745703?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 11:27:06+00:00

About 1,200 more people - like those caught up in the Manchester Arena bombing - could get support.

## Scotland: Hibernian's Kevin Nisbet earns recall as Southampton's Che Adams misses out
 - [https://www.bbc.co.uk/sport/football/65745470?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65745470?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 11:16:05+00:00

Hibernian striker Kevin Nisbet is back in the Scotland squad for next month's Euro 2024 qualifiers in place of the injured Che Adams.

## Garth Crooks' Team of the Season: Dias, Casemiro, Gundogan, De Bruyne, Haaland
 - [https://www.bbc.co.uk/sport/football/65740717?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65740717?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 11:05:17+00:00

Which players impressed our football pundit Garth Crooks enough to make his latest Team of the Season?

## Rare solar displays spotted in skies over England
 - [https://www.bbc.co.uk/news/uk-england-tyne-65745708?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-65745708?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 11:00:28+00:00

Thin, high cloud gave a spectacular show of halos, arcs and upside-down rainbows.

## Jude Bellingham: Borussia Dortmund midfielder named Bundesliga player of the season
 - [https://www.bbc.co.uk/sport/football/65745978?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65745978?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 10:40:30+00:00

Borussia Dortmund's England midfielder Jude Bellingham is named the Bundesliga player of the season.

## Canada: Dashcam captures driving through huge wildfire
 - [https://www.bbc.co.uk/news/world-us-canada-65745448?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65745448?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 09:36:45+00:00

The Canadian city of Halifax declares a state of local emergency after a wildfire causes power cuts and evacuations.

## Match of the Day analysis: Gary Lineker on why Leicester City were relegated
 - [https://www.bbc.co.uk/sport/av/football/65743099?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/65743099?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 09:26:15+00:00

Match of the Day's Gary Lineker alongside pundits Ian Wright and Alan Shearer analyse Leicester City's downfall and relegation.

## Luciano Spalletti: Manager of Serie A champions Napoli to take year-long sabbatical
 - [https://www.bbc.co.uk/sport/football/65744339?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65744339?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 08:36:29+00:00

Napoli manager Luciano Spalletti will take a year-long sabbatical from the Serie A champions, club president Aurelio De Laurentiis says.

## Swansea triathlon: Athlete dies during swimming stage event
 - [https://www.bbc.co.uk/news/uk-wales-65742763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-65742763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 07:08:09+00:00

Organisers Activity Wales Events confirmed the death with "heavy hearts".

## World Skateboarding Tour: Britain's Sky Brown wins title at San Juan opener
 - [https://www.bbc.co.uk/sport/skateboarding/65744335?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/skateboarding/65744335?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 06:53:31+00:00

World Championship winner Sky Brown says she is "so stoked" to have taken gold at the first World Skateboarding Tour event of the season.

## Premier League 2022-23: Vote for your player of the season and more
 - [https://www.bbc.co.uk/sport/football/65570733?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65570733?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 06:03:14+00:00

Player of the season? Best manager? Most memorable moment? Have your say in our Premier League awards for 2022-23.

## Newcastle United: How Eddie Howe masterminded the club's Champions League return
 - [https://www.bbc.co.uk/sport/football/65691526?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65691526?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 05:20:55+00:00

In only 18 months, Eddie Howe has guided Newcastle from the relegation zone to top four in the Premier League. But how has he achieved it?

## New Zealand: Watch rugby league game chaos as multiple pitch invaders tackled
 - [https://www.bbc.co.uk/news/world-asia-65743921?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65743921?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 05:09:49+00:00

Play was interrupted when at least 10 people ran onto the field at a rugby league match in New Zealand.

## Bola Tinubu inauguration: Nigeria to swear in new president
 - [https://www.bbc.co.uk/news/world-africa-65737846?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65737846?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 04:03:44+00:00

Bola Tinubu, 71, won February's election with a promise to renew hope and needs to act fast.

## Sudan Darfur crisis: 'Everything civilians can use has been burned or destroyed'
 - [https://www.bbc.co.uk/news/world-africa-65722123?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65722123?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 04:01:20+00:00

Large-scale destruction caused by Arab militias in western Sudan is now visible from space.

## Mars bar plastic wrapper swapped for paper
 - [https://www.bbc.co.uk/news/business-65712151?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65712151?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 02:23:47+00:00

Mars trials environmentally friendly paper wrappers for some of its chocolate bars.

## Food price cap won't make a difference - retailers
 - [https://www.bbc.co.uk/news/uk-65743163?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65743163?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 01:57:57+00:00

The government wants to encourage supermarkets to impose voluntary price caps on some food products.

## Turkey elections: What to expect from newly emboldened Erdogan
 - [https://www.bbc.co.uk/news/world-europe-65743021?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65743021?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 01:33:05+00:00

Voters in the strategic Nato country opted for a seasoned autocrat - rather than an untested democrat.

## Phillip Schofield: What next for Holly Willoughby, ITV and This Morning?
 - [https://www.bbc.co.uk/news/entertainment-arts-65738931?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65738931?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 01:25:13+00:00

Phillip Schofield left his role on the daytime show after admitting an affair with a colleague.

## Erdogan hails election victory but Turkey left divided
 - [https://www.bbc.co.uk/news/world-europe-65743031?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65743031?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 01:06:42+00:00

The president's supporters celebrate long into the night after he secures five more years in power.

## Necrotising fasciitis: Mum's warning after she nearly dies from disease
 - [https://www.bbc.co.uk/news/uk-england-essex-65696791?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-65696791?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 00:26:31+00:00

A mother is warning others to look out for symptoms of necrotising fasciitis after she nearly died.

## Why Everest base camp won't be moving anytime soon
 - [https://www.bbc.co.uk/news/world-asia-65723447?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65723447?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-29 00:15:28+00:00

Nepal will not shift base camp due to climate change, after opposition from Sherpas and mountaineers.

