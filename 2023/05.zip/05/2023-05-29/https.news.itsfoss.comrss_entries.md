# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Sniffnet: An Interesting Open-Source Network Monitoring Tool Anyone Can Use
 - [https://news.itsfoss.com/sniffnet/](https://news.itsfoss.com/sniffnet/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-05-29 03:58:06+00:00

Take a glance at your network connection with this handy app.

