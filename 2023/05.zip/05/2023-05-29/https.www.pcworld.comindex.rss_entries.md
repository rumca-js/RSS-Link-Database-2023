# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## HP’s Firebird transformed PC design. VoodooPC’s founder explains how
 - [https://www.pcworld.com/article/1933275/the-hp-firebird-was-a-revolution-in-desktop-pc-design.html](https://www.pcworld.com/article/1933275/the-hp-firebird-was-a-revolution-in-desktop-pc-design.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-29 14:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>It&rsquo;s been almost 20 years since HP purchased the boutique computer maker VoodooPC, bolstering both its gaming and design offerings. And in 2009, that purchase bore fruit: The company&rsquo;s &ldquo;Blackbird&rdquo; design was refined into a super-powered, super-modular microtower called the Firebird 803. On the latest PCWorld YouTube video, we&rsquo;re joined by VoodooPC founder Rahul Sood (currently CEO of <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://irreverentlabs.com/&amp;xcust=2-3-1933275-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Irreverent Labs</a>) for a personal tour of this incredibly unique desktop design. </p>



<p>Despite being incredibly compact and featuring several parts designed for laptops, the Firebird is designed to be modular in every way, with easy user access to all parts. That includes the dual mobile graphics cards, a pair of Nvidia GeForce 9800S GPUs in SLI. Both <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://en.wikipedia.org/wiki/Mobile_PCI_Express_Module&amp;xcust=2-3-1933275-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">MXM cards</a> were slotted into the motherboard under massive watercooling blocks, almost like oversized RAM DIMMs, user-accessible with no soldering. </p>



<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">

</div></figure>



<p>The unique case deserves some attention. Despite visually resembling the Blackbird, it&rsquo;s a complete custom design integrating a laptop power supply for a relatively tiny interior volume, though today the slot-loading Blu-ray drive seems a little dated. Around back you can see relics like Firewire and eSATA ports.  </p>



<p>Sood had hoped that the Firebird would be the first in a series of designs focused on modularity and user customization, including a possible collaboration with LEGO on a full DIY build-a-PC kit. Alas, HP went in a different direction, switching to more conventional desktops and sleek laptops for the Voodoo sub-brand. Today, the Firebird&rsquo;s reliance on MXM mobile graphics cards and a custom liquid cooling setup means your upgrade options are limited, even if you can track one down in working order. </p>



<p>But arguably, the Firebird&rsquo;s very existence inspired a new generation of small form factor PCs that refused to compromise on gaming performance. For more deep dives on the history of computer design, <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.youtube.com/@pcworld&amp;xcust=2-3-1933275-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">subscribe to PCWorld on YouTube</a>. </p>

Gaming PCs</div>

## Asus ZenScreen MB249C review: A versatile 24-inch portable monitor
 - [https://www.pcworld.com/article/1930322/asus-zenscreen-mb249c-review.html](https://www.pcworld.com/article/1930322/asus-zenscreen-mb249c-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-29 13:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Small, versatile desk stand with unique options</li><li>Sturdy built-in kickstand for portable use</li><li>Offers USB-C for easy single-cable connections</li><li>Good image quality</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>Lacks additional connection options</li><li>Only 1080p resolution</li><li>A bit pricey for its feature set</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">The Asus ZenScreen MB249C&rsquo;s unusual design doesn&rsquo;t come cheap but provides genuinely useful versatility.</p>
</div>


<p>Portable monitors are advertised for travel but, in reality, most never leave the home or office they&rsquo;re shipped to. Many purchase portable monitors not for their portability but instead their versatility and ease of use. The Asus ZenScreen MB249C leans into this, offering unique benefits alongside a 24-inch screen.</p>



<blockquote class="wp-block-quote"><p><strong>Further reading:</strong> See our roundup of the <a href="https://www.pcworld.com/article/1787210/best-portable-monitors.html">best portable monitors</a> to learn about competing products.</p></blockquote>



<h2 id="what-are-the-asus-zenscreen-mb249c-specs">What are the Asus ZenScreen MB249C specs?</h2>



<p>Asus ZenScreen MB249C is marketed as &ldquo;portable&rdquo; but has a 23.8-inch display. Clearly, portability in this case isn&rsquo;t about sticking the monitor in a suitcase but instead refers to moving it across a home or corporate office.</p>



<ul><li>Display size: 23.8-inch widescreen</li><li>Native resolution: 1920&times;1080</li><li>Panel type: IPS LCD</li><li>Refresh rate: 75Hz</li><li>Adaptive Sync: Yes, AMD FreeSync</li><li>HDR: None</li><li>Ports: 1x USB-C with DisplayPort Alternate Mode and 60 watts Power Delivery, 1x HDMI 1.4, 1x 3.5mm audio out</li><li>Stand adjustment: Height, swivel, tilt</li><li>VESA mount: Yes, 100x100mm</li><li>Speakers: Yes, 2x 1-watt</li><li>Price: $349.99</li></ul>



<p>The MB249C&rsquo;s specifications are otherwise average for a 1080p office display. It does improve on the typical refresh rate of 60Hz, instead delivering up to 75Hz, and provides support for Adaptive Sync.</p>



<h2 id="asus-zenscreen-mb249c-design">Asus ZenScreen MB249C design&nbsp;</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ZenScreen MB249C" class="wp-image-1930330" height="800" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/asus-zenscreen-mb249c-1.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>The Asus ZenScreen MB249C can be mounted on a desk or set up with its kickstand.</p>
</figcaption></figure><p class="imageCredit">Matt Smith</p></div>



<p>Let&rsquo;s talk about the elephant in the room. Asus&rsquo; ZenScreen MB249C is a portable monitor, yet it has a 24-inch display panel, measures 21 inches wide, and weighs over six pounds. So, what gives?</p>



<p>Asus imagines this monitor as a portable display for office and home office use. It may not be suited for travel, but there are still situations where it&rsquo;s handy to move a display around a space. At home, it could let you have two home office setups without two monitors. In an office, it could be carried to meetings if you need to lead a presentation.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ZenScreen MB249C" class="wp-image-1930331" height="800" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/asus-zenscreen-mb249c-5.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>Asus&rsquo; ZenScreen MB249C comes with an attachable kickstand.</p>
</figcaption></figure><p class="imageCredit">Matt Smith</p></div>



<p>The ZenScreen ships with a stand that clips to the back of a desk instead of sitting on top of it, which makes the ZenScreen MB249C easy to use as a second monitor in any home office setup. The stand is small, yet functional, supporting adjustment for height, tilt, and swivel. It also rotates 90 degrees into portrait orientation.</p>



<p>It also comes with two alternative options to the stand: a folding kickstand and an unusual hanger. The kickstand flips out from the rear of the display to support it, as true of most portable monitor kickstands. The hanger, which Asus calls a &ldquo;partition mount,&rdquo; is designed to hang from a half-height cubicle partition and effectively functions as a wall mount, placing the display flush with a cubicle wall. I don&rsquo;t have a cubicle in my home office, so I wasn&rsquo;t able to give this option a try.&nbsp;</p>



<p>The MB249C&rsquo;s design is unusual but clever. It&rsquo;s a niche, but one that many will appreciate.</p>



<h2 id="asus-zenscreen-mb249c-features-and-menus">Asus ZenScreen MB249C features and menus&nbsp;</h2>



<p>The Asus ZenScreen MB249C offers advantages to those who want to tweak the monitor&rsquo;s settings. It ships with a reasonably capable menu that includes a variety of image mode presets and control over aspects of image quality such as color temperature and skin tone. Interestingly, it also has a &ldquo;Shadow Boost&rdquo; which can be used in games to make enemies in dark areas easier to notice.&nbsp;</p>



<p>That&rsquo;s not to say image quality adjustments are extensive. There&rsquo;s no gamma adjustment and the color temperature adjustment is slim. Still, many portable monitors only offer brightness and contrast adjustment, so the MB249C is above average.</p>



<figure class="wp-block-pullquote"><blockquote><p>The MB249C&rsquo;s design is unusual but clever. It&rsquo;s a niche, but one that many will appreciate.</p></blockquote></figure>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ZenScreen MB249C" class="wp-image-1930332" height="800" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/asus-zenscreen-mb249c-3-1.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>Asus ZenScreen MB249C connectivity and ports.</p>
</figcaption></figure><p class="imageCredit">Matt Smith</p></div>



<p>Connectivity is more mundane. The monitor supports USB-C input through DisplayPort Alternate Mode alongside HDMI 1.4, but that&rsquo;s it. Given the price, an additional video input would be appreciated. The monitor lacks USB-A, which feels like a missed opportunity&mdash;there&rsquo;s room.&nbsp;</p>



<p>Those looking to connect over USB-C should note the monitor supports up to 60 watts of Power Delivery and, in my testing, will require that to operate solely over USB-C. The monitor will function with a USB-C laptop or desktop that lacks adequate USB Power Delivery when the monitor&rsquo;s bundled power brick is connected. The power brick is also needed when only the HDMI video input is in use.&nbsp;</p>



<p>The monitor has built-in speakers, but you won&rsquo;t want to rely on them. Volume is low and the speakers suffer distortion when playing music, movies, or anything more complicated than spoken dialogue and system messages. Weak speakers, though disappointing, are typical for an office monitor.</p>



<h2 id="how-is-the-asus-zenscreen-mb249c-sdr-image-quality">How is the Asus ZenScreen MB249C SDR image quality?</h2>



<p>The Asus ZenScreen MB249C targets office productivity and makes few specific claims about its image quality. That left me with low expectations, which, to my surprise, the monitor easily beat.&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ZenScreen MB249C" class="wp-image-1930333" height="815" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/asus-zenscreen-mb249c-brightness.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith</p></div>



<p>Brightness comes in at a respectable 264 nits which, although not amazing, is mid-pack for a portable monitor and quite good for an office productivity monitor. This level of brightness is sufficient for use in any room with moderate light control. It may appear a bit dim near a sunlit window, however.&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ZenScreen MB249C" class="wp-image-1930334" height="846" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/asus-zenscreen-mb249c-contrast.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith</p></div>



<p>The monitor delivered a surprise in contrast with a maximum contrast ratio of 1380:1. That&rsquo;s towards the high end of what I expect from monitors with an IPS display panel and no advanced backlight technology, such as Mini-LED.&nbsp;</p>



<p>Don&rsquo;t get too excited. The monitor can still struggle with shadow detail, especially when viewing movies that have a dark palette like <em>The Batman</em>. Still, a contrast ratio of 1380:1 is higher than most competitors and it provides a better sense of depth. An alternative like the <a href="https://www.pcworld.com/article/1777291/benq-gw2785tc-review.html">BenQ GW2785TC</a> will appear flat and one-dimensional by comparison.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ZenScreen MB249C" class="wp-image-1930338" height="816" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/asus-zenscreen-mb249c-color-gamut.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith</p></div>



<p>Color gamut isn&rsquo;t bad, either, providing 100 percent of the sRGB color gamut and 81 percent of DCI-P3. This isn&rsquo;t enough to be considered a &ldquo;wide gamut&rdquo; monitor, and not enough for many content creators looking to edit photos or video, but it&rsquo;s a few percent better than most alternatives. The monitor has enjoyable, vibrant color.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ZenScreen MB249C" class="wp-image-1930339" height="880" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/asus-zenscreen-mb249c-color-error.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith</p></div>



<p>It&rsquo;s accurate, as well, achieving an average color error that&rsquo;s just a tad worse than the Asus ProArt PA279CRV, a monitor specifically built for accurate and realistic color performance. The color error is worst in blue hues, which is often true of LED-backlit monitors, but it didn&rsquo;t jump out in real-world use.</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="mentioned-in-this-article">
					Mentioned in this article				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="proart-pa279crv">ProArt PA279CRV</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="ProArt PA279CRV" class="product-widget__image" height="1000" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/asus-proart-pa279crv-3.jpg?quality=50&amp;strip=all" width="1500" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
													<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/1794810/asus-proart-pa279crv-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
											<div class="product-widget__information--rrp-wrapper">
								<span class="product-widget__information--rrp-label">
															</span>
								<span class="product-widget__information--rrp-value">
																</span>
							</div>
						
									</div>
			</div>
		</div>

		


<p>The monitor&rsquo;s accuracy is further helped by a gamma reading of 2.1, which means that images appear just slightly brighter than they should. Color temperature came in at precisely the preferred target of 6500K, so it&rsquo;s neither overly warm or too cool. To put it simply, the monitor appears extremely accurate in real-world use and is well suited to office productivity.&nbsp;</p>



<p>Sharpness is a downside, as the display provides only 1080p resolution with a pixel density of roughly 93 pixels per inch. Many office monitors in this price range can hit 4K resolution, which increase pixel density to 163 pixels per inch. It&rsquo;s a noticeable gap and the Asus ZenScreen MB249C can look pixelated and soft next to 4K alternatives.</p>



<p>On the whole, Asus&rsquo; ZenScreen MB249C provides excellent image quality for its intended purpose. It&rsquo;s bright enough and scores well in contrast, color gamut, and color accuracy, all while avoiding notable problems or pitfalls. The only caveat is resolution, as it&rsquo;s possible to buy a similar 4K such as the <a href="https://www.anrdoezrs.net/click-8200811-12839518?url=https://www.dell.com/en-us/shop/dell-27-4k-uhd-monitor-s2721qs/apd/210-axlg/monitors-monitor-accessories&amp;sid=2-1-1930322-1-0-0" rel="nofollow">Dell S2721QS</a> for less&mdash;however, such alternatives lack the MB249C&rsquo;s portability.</p>



<h2 id="asus-zenscreen-mb249c-hdr-image-quality">Asus ZenScreen MB249C HDR image quality</h2>



<p>The Asus ZenScreen MB249C doesn&rsquo;t support HDR. That&rsquo;s to be expected, as the monitor&rsquo;s maximum brightness is well below what&rsquo;s needed for a passable HDR experience. Increasing brightness to levels suitable for HDR also increases power draw, which wouldn&rsquo;t pair well with the monitor&rsquo;s USB-C connectivity.&nbsp;</p>



<h2 id="asus-zenscreen-mb249c-motion-performance">Asus ZenScreen MB249C motion performance</h2>



<p>Though meant for productivity, the Asus ZenScreen MB249C offers a slightly improved refresh rate of 75Hz and <a href="https://www.pcworld.com/article/423202/g-sync-vs-freesync-amd-nvidia-monitor.html">Adaptive Sync support</a> for smooth frame pacing in games. Adaptive Sync was functional with the monitor connected to an AMD video card. I wasn&rsquo;t able to test the monitor with Nvidia G-Sync.&nbsp;</p>



<h2 id="is-the-asus-zenscreen-mb249c-worth-it">Is the Asus ZenScreen MB249c worth it?</h2>



<p>The Asus ZenScreen MB249C is an unusual but useful home and office productivity monitor. Its odd design, which pairs a 24-inch screen with several stand options including a kickstand, makes it easy to tote around a house or corporate office. It also provides good image quality with adequate brightness and strong color performance. The $350 price is a bit much for a 1080p monitor and won&rsquo;t make sense if you have no reason to use its unique features, but it&rsquo;s not unreasonable. The MB249C is a great choice for a second monitor, too, as it offers multiple ways to mount and orient it alongside your primary monitor.</p>

Monitors</div>

## This MSI Creator laptop is a monster video editing machine
 - [https://www.pcworld.com/article/1933019/this-msi-creator-laptop-is-a-monster-video-editing-machine.html](https://www.pcworld.com/article/1933019/this-msi-creator-laptop-is-a-monster-video-editing-machine.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-29 10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Editing video is still one of the most demanding tasks you can do on a PC. So when you try and do it on a laptop, and furthermore, on a laptop you wouldn&rsquo;t mind hauling on an international flight, things can get complicated quickly. Which brings us to the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://xoticpc.com/products/msi-creator-z17hxstudio-a13vgt-065us&amp;xcust=2-3-1933019-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">MSI Creator Z17HX</a>, the latest and greatest workstation laptop from MSI. With a 13th-gen Intel Core i9 processor and an RTX 4070, it should be able to handle whatever video Adam Patrick Murray can throw at it&hellip;right? He&rsquo;ll put it to the test at Computex this week. </p>



<p>This laptop is bursting at the seams with the latest tech, including that 24-core i9-13950HX processor, 64GB of DDR5 RAM, and 2TB of super-fast PCIe Gen 5 storage, touchscreen with wireless pen support (included in the box and magnetically docked, nice!), and double Thunderbolt 4 ports. Video editors will love the full-sized SD card slot and front-firing speakers. </p>



<p>The screen is a massive 17-inch panel at 2560&times;1600, at a slightly taller-than-average 16:10 ratio, though other laptops in this category hit 4K resolution fairly easily. But for editing video, raw pixels are only half the story. For color accuracy, the IPS panel is rated at 100% DCI-P3, which means it can&rsquo;t be beaten in terms of &ldquo;what you see is what you get&rdquo; colors while editing. But it doesn&rsquo;t come from the factory pre-calibrated for Pantone and X-Rite accuracy. That means you might have to do some fiddling with your own hardware for truly perfect color accuracy. Some may prefer the extra saturation and contrast of an OLED panel, too. </p>



<blockquote class="wp-block-quote"><p><strong>Further reading: </strong><a href="https://www.pcworld.com/article/436674/the-best-pc-laptops-of-the-year.html">The best laptops</a></p></blockquote>



<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">

</div></figure>



<p>The Creator is huge laptop by today&rsquo;s standards, tipping the scales at five pounds and twelve ounces. That&rsquo;s fairly okay for something with such a large screen, but there are certainly more svelte models on the market, even in this size range. (And that&rsquo;s before the rather chunky charging brick.) But it does justify the bulk: In addition to that high-powered hardware, you get full-sized SD card reader (a big deal for shooting video), full-sized HDMI, two USB-C Thunderbolt ports and a USB-A, just to make sure you can leave the dongles at home. It&rsquo;s possible to charge the Creator via USB-C, but for maximum speed you&rsquo;ll want that 200-watt proprietary charger (which looks like USB-A, but is not). </p>



<p>What about using this thing? While cranked up to the maximum power setting, the Creator Z17HX&rsquo;s three fans emit quite a bit of noise, but manage to spread it out at lower frequencies than some other workstation laptops. Users might like the small but present 10-key area on the keyboard, and might not like the way the roomy trackpad is off-center from the main typing area. </p>



<p>For raw performance, the Creator Z17HX is handily beating Adam&rsquo;s previous road warrior editing machine, the Gigabyte Aero 16 with a Core i7-12700H and 3070Ti. In PugetBench&rsquo;s Lightroom test it won out by about 25 percent, indicating much faster exporting thanks to those extra processor cores. In Photoshop the MSI model handily beats it with a newer processor and GPU, with a more than 40 percent performance jump. In the crucial PugetBench Premiere and DaVinci tests, the newer laptop managed a 20-25 percent across the board, though the 3070 Ti with its wider memory bus and more CUDA cores did have a slight edge in DaVinci GPU effects. Even so, the newer GPU managed to win dramatically in Handbrake encoding. </p>



<p>Adam will have a full breakdown of the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://xoticpc.com/products/msi-creator-z17hxstudio-a13vgt-065us&amp;xcust=2-3-1933019-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">MSI Creator Z17HX</a> after a trial by fire, covering Computex live in Taiwan. For more in-depth looks at the latest laptops, be sure to <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.youtube.com/@pcworld&amp;xcust=2-3-1933019-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">subscribe to PCWorld on YouTube</a>. </p>

Laptops</div>

## Browse safely while accessing your streaming services all over the world
 - [https://www.pcworld.com/article/1931832/browse-safely-while-accessing-your-streaming-services-all-over-the-world.html](https://www.pcworld.com/article/1931832/browse-safely-while-accessing-your-streaming-services-all-over-the-world.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-29 08:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Who can blame you if you want to access your familiar US Netflix while you&rsquo;re traveling abroad this summer? With Getflix, you can bypass online geo-restrictions while ensuring your privacy stays completely secure.</p>



<p>Getflix is a <a href="https://shop.pcworld.com/sales/getflix-lifetime-subscription-4?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=getflix-lifetime-subscription-4&amp;utm_term=scsf-571945&amp;utm_content=a0x1P000004IjNbQAK&amp;scsonar=1" rel="noreferrer noopener" target="_blank">DNS service</a> that re-routes only connections of interest to overseas servers, thereby maintaining fast streaming speeds without compromising your security. Getflix takes just a few seconds to set up, doesn&rsquo;t require any additional software, and never logs, analyzes, inspects, or archives any of your data. It also supports any PC, Mac, or mobile device operating system for peak ease of use.</p>



<p>Find out why Getflix has been featured in Lifehacker, Digital Spy, and Entrepreneur when you connect on your summer travels. Right now, you can get a lifetime subscription to <a href="https://shop.pcworld.com/sales/getflix-lifetime-subscription-4?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=getflix-lifetime-subscription-4&amp;utm_term=scsf-571945&amp;utm_content=a0x1P000004IjNbQAK&amp;scsonar=1" rel="noreferrer noopener" target="_blank">Getflix Smart DNS &amp; VPN</a> for 69% off $162 at just $49.99.</p>



<p><a href="https://shop.pcworld.com/sales/getflix-lifetime-subscription-4?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=getflix-lifetime-subscription-4&amp;utm_term=scsf-571945&amp;utm_content=a0x1P000004IjNbQAK&amp;scsonar=1" rel="noreferrer noopener" target="_blank">&nbsp;</a></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image"><img alt="" src="https://cdnp0.stackassets.com/e0aa789c6dc03bf3481e8f94373bc5bb76d6cc08/store/b274e1c3ed6f98b0b8f1baeae3ae861986edbd9bf1d1d0ea8e1c1ccc64c2/sale_313486_primary_image.jpg" /></figure></div>



<p><strong>Getflix Smart DNS &amp; VPN: Lifetime Subscription &ndash; $49.99</strong></p>



<p><a href="https://shop.pcworld.com/sales/getflix-lifetime-subscription-4?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=getflix-lifetime-subscription-4&amp;utm_term=scsf-571945&amp;utm_content=a0x1P000004IjNbQAK&amp;scsonar=1" rel="noreferrer noopener" target="_blank">See Deal</a></p>



<p>Prices subject to change.</p>

VPN</div>

