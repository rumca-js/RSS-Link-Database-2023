# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## The State Of Our Military | @JockoPodcastOfficial
 - [https://www.youtube.com/watch?v=NNmZzJSh-P4](https://www.youtube.com/watch?v=NNmZzJSh-P4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-05-29 17:00:20+00:00

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Black Rifle Coffee - Get 10% off coffee, coffee gear, apparel, or a Coffee Club subscription with code SHAPIRO: https://www.blackriflecoffee.com/

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire

