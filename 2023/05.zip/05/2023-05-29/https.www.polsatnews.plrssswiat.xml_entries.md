# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Kosowo: 25 żołnierzy NATO rannych w starciach z Serbami
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/kosowo-25-zolnierzy-nato-rannych-w-starciach-z-serbami/](https://www.polsatnews.pl/wiadomosc/2023-05-29/kosowo-25-zolnierzy-nato-rannych-w-starciach-z-serbami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 19:39:00+00:00

25 żołnierzy sił pokojowych NATO zostało rannych w starciach z Serbami protestującymi przeciwko objęciu przez albańskich burmistrzów stanowisk w gminach z przewagą serbską na północy Kosowa - poinformowała w oświadczeniu dowodzona przez NATO misja pokojowa w Kosowie KFOR.

## Wielka Brytania: Zaparkował tuż przy plaży. Zmyło mu auto do morza
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/wielka-brytania-zaparkowal-tuz-przy-plazy-zmylo-mu-auto-do-morza/](https://www.polsatnews.pl/wiadomosc/2023-05-29/wielka-brytania-zaparkowal-tuz-przy-plazy-zmylo-mu-auto-do-morza/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 17:56:00+00:00

Mieszkaniec Wielkiej Brytanii postanowił spędzić czas nad morzem, ale nie chciał zostawiać swojego auta zbyt daleko od plaży. Decyzja okazała się brzemienna w skutkach. Straż przybrzeżna z Kornwalii opublikowała w sieci nagranie, na którym widać czarne bmw porwane przez fale.

## Izrael. Nowa terapia w leczeniu szpiczaka mnogiego. 90 proc. pacjentów z remisją
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/izrael-nowa-terapia-w-leczeniu-szpiczaka-mnogiego-90-proc-pacjentow-z-remisja/](https://www.polsatnews.pl/wiadomosc/2023-05-29/izrael-nowa-terapia-w-leczeniu-szpiczaka-mnogiego-90-proc-pacjentow-z-remisja/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 17:25:00+00:00

Eksperymentalna terapia opracowana w izraelskim Hadassah-University Medical Center ma 90 proc. skuteczność w doprowadzeniu do remisji u pacjentów ze szpiczakiem mnogim - podaje dziennik The Jerusalem Post. Jej twórcy twierdzą, że stanowi przełom w leczeniu tego rodzaju raka. W kolejnych miesiącach badania nad innowacyjną metodą rozpoczęte zostaną także w Stanach Zjednoczonych.

## USA: Paleontolodzy odkryli gatunek dinozaura ze "szczotką" na głowie
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/usa-paleontolodzy-odkryli-gatunek-dinozaura-ze-szczotka-na-glowie/](https://www.polsatnews.pl/wiadomosc/2023-05-29/usa-paleontolodzy-odkryli-gatunek-dinozaura-ze-szczotka-na-glowie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 17:23:00+00:00

Amerykańscy paleontolodzy opisali nowy gatunek dinozaura. Zdaniem specjalistów, żyjący 68 mln lat temu okaz nosił bardzo niecodzienne nakrycie głowy. Badacze twierdzą, że dinozaur najprawdopodobniej miał na czaszce rzędy twardego włosia, przypominające gigantyczną szczoteczkę do zębów.

## Jedna currywurst w miesiącu? Tego chcą niemieccy dietetycy
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/jedna-currywurst-w-miesiacu-tego-chca-niemieccy-dietetycy/](https://www.polsatnews.pl/wiadomosc/2023-05-29/jedna-currywurst-w-miesiacu-tego-chca-niemieccy-dietetycy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 17:21:00+00:00

10 gramów mięsa dziennie - takie zalecenia planuje wydać wkrótce Niemieckie Towarzystwo Żywieniowe. Według tamtejszych mediów miesięczne jego spożycie miałoby równowartość uwielbianej przez wielu małej currywurst.

## Australia: 16-latek uczył się jeździć. Wyjechał na drogę taką "elką"
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/australia-16-latek-uczyl-sie-jezdzic-wyjechal-na-droge-taka-elka/](https://www.polsatnews.pl/wiadomosc/2023-05-29/australia-16-latek-uczyl-sie-jezdzic-wyjechal-na-droge-taka-elka/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 16:00:00+00:00

Na autostradzie w australijskim stanie Wiktoria zaobserwowano bardzo niecodzienny pojazd nauki jazdy. Okazuje się, że pewien 16-latek uczył się jeździć, siedząc za kierownicą sportowego lamborghini. Zdjęcie nietypowej elki lotem błyskawicy obiegło media społecznościowe i wywołało lawinę komentarzy.

## Filipiny: Kupiła kiść owoców. Na bananie ukazał się jej prezydent USA
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/filipiny-kupila-kisc-owocow-na-bananie-ukazal-sie-jej-prezydent-usa/](https://www.polsatnews.pl/wiadomosc/2023-05-29/filipiny-kupila-kisc-owocow-na-bananie-ukazal-sie-jej-prezydent-usa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 14:51:00+00:00

Mieszkanka Filipin nie mogła uwierzyć własnym oczom, kiedy wróciła z zakupów. Na przyniesionej do domu kiści bananów kobieta zobaczyła twarz Abrahama Lincolna, byłego prezydenta USA. Zdjęcie odbiło się szerokim echem w mediach społecznościowych. Część komentujących stwierdziła, że kształt na bananie przypomina bardziej kubańskiego rewolucjonistę, Fidela Castro.

## Kłopoty wokalisty Rammsteina. Poważne oskarżenia
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/klopoty-wokalisty-rammsteina-powazne-oskarzenia/](https://www.polsatnews.pl/wiadomosc/2023-05-29/klopoty-wokalisty-rammsteina-powazne-oskarzenia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 14:08:00+00:00

Fanka zespołu Rammstein wystosowała poważne oskarżenia pod adresem wokalisty Tilla Lindemana. 24-letnia Shelby Lynn z Irlandii zarzuciła frontmanowi grupy podanie jej substancji odurzających oraz przemoc - poinformował Bild. Zespół opublikował w sprawie oficjalne oświadczenie, w którym odrzucono wszelkie oskarżenia.

## Izrael. Wpadła w panikę na widok karalucha. Goście restauracji myśleli, że to atak terrorystyczny
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/izrael-wpadla-w-panike-na-widok-karalucha-goscie-restauracji-mysleli-ze-to-atak-terrorystyczny/](https://www.polsatnews.pl/wiadomosc/2023-05-29/izrael-wpadla-w-panike-na-widok-karalucha-goscie-restauracji-mysleli-ze-to-atak-terrorystyczny/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 13:13:00+00:00

Chaos w kawiarni w Tel Awiwie. Wieczorny posiłek klientów zaburzył krzyk pewnej kobiety, która miała zauważyć karalucha. Jej gwałtowna reakcja wywołała ogólną panikę. Sądząc, że to atak terrorystyczny, przerażeni goście rzucili się do wyjścia, tratując wszystko, co napotkali na swojej drodze. W zamieszaniu ucierpiały dwie osoby.

## Szwecja: Incydent podczas programu tanecznego. Aktywiści wbiegli na scenę, jednego uderzyła kamera
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/szwecja-incydent-podczas-programu-tanecznego-aktywisci-wbiegli-na-scene-jednego-uderzyla-kamera/](https://www.polsatnews.pl/wiadomosc/2023-05-29/szwecja-incydent-podczas-programu-tanecznego-aktywisci-wbiegli-na-scene-jednego-uderzyla-kamera/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 12:06:00+00:00

Podczas programu tanecznego doszło do incydentu z udziałem aktywistów klimatycznych. Na scenę wbiegło kilka osób z transparentem, jedna z nich została uderzona przez przesuwającą się kamerę. Autorzy widowiska zwracają uwagę, że akcja stanowiła zagrożenie dla uczestniczki, która jest w ciąży.

## Włochy: Wichura wywróciła łódź. Cztery osoby utonęły w jeziorze
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/wlochy-wichura-wywrocila-lodz-tragedia-na-jeziorze/](https://www.polsatnews.pl/wiadomosc/2023-05-29/wlochy-wichura-wywrocila-lodz-tragedia-na-jeziorze/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 11:26:00+00:00

Cztery osoby utonęły na skutek wywrócenia łodzi przez silny wiatr w północnych Włoszech. Straż pożarna poinformowała, że pozostali pasażerowi zdołali się uratować. Na miejsce wysłano helikopter ratunkowy i specjalistycznych nurków, którzy przeczesali dno zbiornika wodnego.

## Jeden na 10 milionów. Narodziny białego bizona w USA
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/jeden-na-10-milionow-narodziny-bialego-bizona-w-usa/](https://www.polsatnews.pl/wiadomosc/2023-05-29/jeden-na-10-milionow-narodziny-bialego-bizona-w-usa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 10:59:00+00:00

W parku stanowym Wyoming przyszedł na świat niezwykle rzadki okaz bizona albinosa. Według ekspertów szanse na takie zjawisko u tych zwierząt wynoszą jeden do 10 milionów. Dla niektórych plemion rdzennych Amerykanów białe bizony są uważane za święte. Ciele jest niewielkiej postury, ale ma się dobrze - informują urzędnicy. Jest jeszcze za wcześnie na określenie płci zwierzęcia.

## Przekłuła uszy jednodniowej córeczce. Na matkę wylał się hejt
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/przeklula-uszy-jednodniowej-coreczce-na-matke-wylal-sie-hejt/](https://www.polsatnews.pl/wiadomosc/2023-05-29/przeklula-uszy-jednodniowej-coreczce-na-matke-wylal-sie-hejt/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 09:29:00+00:00

Kobieta, która zaledwie dobę po porodzie przekłuła uszy swojemu dziecku, a następnie opublikowała wideo z noworodkiem na TikToku, musiała zmierzyć się z falą krytyką internautów. Mimo emocjonalnych reakcji komentatorów, matka broniła swojej decyzji. Obecnie jej córka ma ponad cztery lata, a klip z kontrowersyjnym nagraniem zebrał blisko 2,5 mln wyświetleń.

## Wenecja: Zielona plama na Canal Grande. Policja poszukuje sprawcy
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/wenecja-zielona-plama-na-canal-grande-policja-poszukuje-sprawcy/](https://www.polsatnews.pl/wiadomosc/2023-05-29/wenecja-zielona-plama-na-canal-grande-policja-poszukuje-sprawcy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 09:18:00+00:00

W niedzielę woda w Canal Grande w Wenecji zabarwiła się na zielony, fluorescencyjny kolor. Na razie nie wiadomo, czy był to akt wandalizmu, czy może działanie aktywistów, którzy chcieli w ten sposób zwrócić uwagę na zanieczyszczenie środowiska.

## Rosja wysłała broń na Białoruś. Łukaszenka dostał nowoczesne systemy S-400
 - [https://www.polsatnews.pl/wiadomosc/2023-05-29/rosja-wyslala-bron-na-bialorus-lukaszenka-dostal-nowoczesne-systemy-s-400/](https://www.polsatnews.pl/wiadomosc/2023-05-29/rosja-wyslala-bron-na-bialorus-lukaszenka-dostal-nowoczesne-systemy-s-400/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-29 08:13:00+00:00

Białoruski resort obrony poinformował o transporcie systemów S-400. Przeciwlotnicze zestawy rakietowe koleją przyjechały z Rosji, gdzie wcześniej szkolili się żołnierze Alaksandra Łukaszenki. Pojawiają się też nieoficjalne informacje o obecnej lokalizacji systemu, którego zasięg wynosi 400 kilometrów.

