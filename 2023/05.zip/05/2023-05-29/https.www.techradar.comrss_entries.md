# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Bryan Fury has been announced for Tekken 8, unannounced and then announced again
 - [https://www.techradar.com/news/bryan-fury-has-been-announced-for-tekken-8-unannounced-and-then-announced-again](https://www.techradar.com/news/bryan-fury-has-been-announced-for-tekken-8-unannounced-and-then-announced-again)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 21:34:35+00:00

Bryan Fury has finally joined the fight in Tekken 8, following an accidental post before his scheduled debut.

## Nintendo explains the decision behind blocking release of Dolphin emulator
 - [https://www.techradar.com/news/nintendo-explains-the-decision-behind-blocking-release-of-dolphin-emulator](https://www.techradar.com/news/nintendo-explains-the-decision-behind-blocking-release-of-dolphin-emulator)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 19:49:48+00:00

Nintendo has explained why it decided to block the Steam release of GameCube and Wii emulator Dolphin.

## Microsoft reveals Azure Linux is available now
 - [https://www.techradar.com/news/microsoft-reveals-azure-linux-is-available-now](https://www.techradar.com/news/microsoft-reveals-azure-linux-is-available-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 19:20:11+00:00

Azure Linux container host for Azure Kubernetes Service is now available following months of testing.

## Nvidia reveals a whole new kind of Ethernet for generative AI
 - [https://www.techradar.com/news/nvidia-reveals-a-whole-new-kind-of-ethernet-for-generative-ai](https://www.techradar.com/news/nvidia-reveals-a-whole-new-kind-of-ethernet-for-generative-ai)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 18:17:00+00:00

Blisteringly quick Ethernet speeds are being enabled by Nvidia Spectrum-X technology.

## A gaming Chromebook with an Nvidia RTX graphics card? Sign me up
 - [https://www.techradar.com/news/a-gaming-chromebook-with-an-nvidia-rtx-graphics-card-sign-me-up](https://www.techradar.com/news/a-gaming-chromebook-with-an-nvidia-rtx-graphics-card-sign-me-up)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 18:00:23+00:00

A new partnership between Google and Nvidia will see the latest RTX GPUs make their way into two upcoming Chromebooks.

## Windows 11 cloud backup is getting a whole lot better at last
 - [https://www.techradar.com/news/microsoft-unveils-a-new-windows-11-backup-app](https://www.techradar.com/news/microsoft-unveils-a-new-windows-11-backup-app)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 15:54:59+00:00

Windows 11 is set to get a new cloud backup tool that covers just about all bases, and it’s in Preview now.

## HP printers could soon lose their official environmental certification following user fury
 - [https://www.techradar.com/news/hp-printers-could-soon-lose-their-official-environmental-certification-following-user-fury](https://www.techradar.com/news/hp-printers-could-soon-lose-their-official-environmental-certification-following-user-fury)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 15:05:43+00:00

The IITC has asked the Global Electronics Council to revoke eco-certification from around 100 HP printers.

## Watch out - that Amazon or Microsoft ad could just be malware
 - [https://www.techradar.com/news/watch-out-that-amazon-or-microsoft-ad-could-just-be-malware](https://www.techradar.com/news/watch-out-that-amazon-or-microsoft-ad-could-just-be-malware)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 14:16:07+00:00

Just because an ad is on Google, it doesn't mean it's clean - hackers can abuse the platform to deliver malware.

## More and more criminals are using legitimate websites to obfuscate malicious payloads
 - [https://www.techradar.com/news/more-and-more-criminals-are-using-legitimate-websites-to-obfuscate-malicious-payloads](https://www.techradar.com/news/more-and-more-criminals-are-using-legitimate-websites-to-obfuscate-malicious-payloads)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 13:06:05+00:00

Legitimate services can be used to bypass protections and deliver malware to victims more easily, experts warn.

## 5 things I can't wait to see at Computex 2023
 - [https://www.techradar.com/news/5-things-i-cant-wait-to-see-at-computex-2023](https://www.techradar.com/news/5-things-i-cant-wait-to-see-at-computex-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 13:00:04+00:00

Computex 2022 was more of a somber event. This year, I’m looking forward to manufacturers bringing in the fun stuff.

## Most CEOs now see cybersecurity as more important than economic performance
 - [https://www.techradar.com/news/most-ceos-now-see-cybersecurity-as-more-important-than-economic-performance](https://www.techradar.com/news/most-ceos-now-see-cybersecurity-as-more-important-than-economic-performance)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 12:22:49+00:00

Growing cybersecurity threats are keeping many CEOs up at night.

## Spotify festival: how to generate your dream festival lineup poster
 - [https://www.techradar.com/news/spotify-festival-how-to-generate-your-dream-festival-lineup-poster](https://www.techradar.com/news/spotify-festival-how-to-generate-your-dream-festival-lineup-poster)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 12:00:00+00:00

Use the Instafest app and your music listening history to produce a festival lineup perfectly aligned to your tastes.

## Bigger iPhone 16 Pro sizes are rumored to be making room for camera upgrades
 - [https://www.techradar.com/news/bigger-iphone-16-pro-sizes-are-rumored-to-be-making-room-for-camera-upgrades](https://www.techradar.com/news/bigger-iphone-16-pro-sizes-are-rumored-to-be-making-room-for-camera-upgrades)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 11:30:21+00:00

There's more information on the larger iPhone 16 Pro and Pro Max models, which could be the biggest iPhones yet.

## Microsoft Defender Antivirus is getting a new performance mode, but you probably won't ever see it
 - [https://www.techradar.com/news/microsoft-defender-antivirus-is-getting-a-new-performance-mode-but-you-probably-wont-ever-see-it](https://www.techradar.com/news/microsoft-defender-antivirus-is-getting-a-new-performance-mode-but-you-probably-wont-ever-see-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 11:25:35+00:00

Microsoft Defender performance mode for developers only, but it should speed up build times.

## Apple shuts My Photo Stream on July 26, so make sure you don't lose your photos
 - [https://www.techradar.com/news/apple-shuts-my-photo-stream-on-july-26-so-make-sure-you-dont-lose-your-photos](https://www.techradar.com/news/apple-shuts-my-photo-stream-on-july-26-so-make-sure-you-dont-lose-your-photos)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 10:30:30+00:00

It launched alongside iCloud in 2011 to sync your photos and videos, but now My Photo Stream is going away.

## This new malware hijacks Windows WordPad to avoid detection
 - [https://www.techradar.com/news/this-new-malware-hijacks-windows-wordpad-to-avoid-detection](https://www.techradar.com/news/this-new-malware-hijacks-windows-wordpad-to-avoid-detection)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 10:22:20+00:00

Qbot operators are at it again, using legitimate software to distribute malware via Windows WordPad.

## Quordle today - hints and answers for Monday, May 29 (game #490)
 - [https://www.techradar.com/news/quordle-today-answers-clues-29-may-2023](https://www.techradar.com/news/quordle-today-answers-clues-29-may-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 06:16:49+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

## This tiny laptop charger has a 1TB SSD and automatic backup functionality
 - [https://www.techradar.com/news/this-tiny-laptop-charger-has-a-1tb-ssd-and-automatic-backup-functionality](https://www.techradar.com/news/this-tiny-laptop-charger-has-a-1tb-ssd-and-automatic-backup-functionality)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 04:55:42+00:00

iXCharger delivers an intriguing combination but will it be good enough for the rest of us?

## Nvidia Computex 2023 Keynote Live: On the ground at Computex 2023
 - [https://www.techradar.com/news/live/nvidia-computex-2023-keynote](https://www.techradar.com/news/live/nvidia-computex-2023-keynote)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-29 01:00:13+00:00

The Computex 2023 opening keynote from Nvidia is a break from AMD tradition, but Nvidia CEO Jensen Huang is sure to deliver some major news at the event.

