# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## How to Make Meetings Shorter (for Real)
 - [https://www.wired.com/story/how-to-make-meetings-shorter/](https://www.wired.com/story/how-to-make-meetings-shorter/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-05-29 11:00:00+00:00

Time is money. Reclaim your precious minutes with these strategies for in-person and virtual meetings.

