# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Maine police shoot at suspect who evaded trooper to Canada and was believed to have explosive in truck
 - [https://www.msn.com/en-us/news/world/maine-police-shoot-at-suspect-who-evaded-trooper-to-canada-and-was-believed-to-have-explosive-in-truck/ar-AA1bRfDj?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/maine-police-shoot-at-suspect-who-evaded-trooper-to-canada-and-was-believed-to-have-explosive-in-truck/ar-AA1bRfDj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 23:20:40.223374+00:00



## Senators gear up for chaotic post-recess return to Washington
 - [https://www.msn.com/en-us/news/politics/senators-gear-up-for-chaotic-post-recess-return-to-washington/ar-AA1bR10e?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/senators-gear-up-for-chaotic-post-recess-return-to-washington/ar-AA1bR10e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 23:20:40.215563+00:00



## Scorsese meets with pope, announces new film about Jesus
 - [https://www.msn.com/en-us/news/politics/scorsese-meets-with-pope-announces-new-film-about-jesus/ar-AA1bRbIi?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/scorsese-meets-with-pope-announces-new-film-about-jesus/ar-AA1bRbIi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 23:20:40.206975+00:00



## Adorable moment family of RACCOONS have a pool party in California man's backyard
 - [https://www.msn.com/en-us/news/us/adorable-moment-family-of-raccoons-have-a-pool-party-in-california-man-s-backyard/ar-AA1bRbhH?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/adorable-moment-family-of-raccoons-have-a-pool-party-in-california-man-s-backyard/ar-AA1bRbhH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 22:20:42.293945+00:00



## Lindsey Graham Attacks McCarthy Over Debt Deal: 'Total Disgust'
 - [https://www.msn.com/en-us/news/politics/lindsey-graham-attacks-mccarthy-over-debt-deal-total-disgust/ar-AA1bRft5?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/lindsey-graham-attacks-mccarthy-over-debt-deal-total-disgust/ar-AA1bRft5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 22:20:42.286915+00:00



## A secret Cold War-era deal lets British jets shadow Russian bombers when they fly near a vital Atlantic chokepoint
 - [https://www.msn.com/en-us/news/world/a-secret-cold-war-era-deal-lets-british-jets-shadow-russian-bombers-when-they-fly-near-a-vital-atlantic-chokepoint/ar-AA1bRfhf?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/a-secret-cold-war-era-deal-lets-british-jets-shadow-russian-bombers-when-they-fly-near-a-vital-atlantic-chokepoint/ar-AA1bRfhf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 22:20:42.279862+00:00



## McCarthy rallies support for debt deal amid hints of mutiny
 - [https://www.msn.com/en-us/news/politics/mccarthy-rallies-support-for-debt-deal-amid-hints-of-mutiny/ar-AA1bRaTy?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/mccarthy-rallies-support-for-debt-deal-amid-hints-of-mutiny/ar-AA1bRaTy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 22:20:42.272899+00:00



## China Spurns US Defense Chiefs Meeting Amid Sanctions Snag
 - [https://www.msn.com/en-us/news/world/china-spurns-us-defense-chiefs-meeting-amid-sanctions-snag/ar-AA1bR07m?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/china-spurns-us-defense-chiefs-meeting-amid-sanctions-snag/ar-AA1bR07m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 22:20:42.265957+00:00



## Joran van der Sloot Beaten in Peruvian Prison, Lawyer Says
 - [https://www.msn.com/en-us/news/world/joran-van-der-sloot-beaten-in-peruvian-prison-lawyer-says/ar-AA1bRb5i?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/joran-van-der-sloot-beaten-in-peruvian-prison-lawyer-says/ar-AA1bRb5i?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 22:20:42.258308+00:00



## 'He's home': Missing 73 years, Medal of Honor recipient's remains return to Georgia
 - [https://www.msn.com/en-us/news/us/he-s-home-missing-73-years-medal-of-honor-recipient-s-remains-return-to-georgia/ar-AA1bRhFx?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/he-s-home-missing-73-years-medal-of-honor-recipient-s-remains-return-to-georgia/ar-AA1bRhFx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 22:20:42.250427+00:00



## Cruz condemns sweeping anti-gay Uganda law as ‘horrific’ and ‘wrong’
 - [https://www.msn.com/en-us/news/politics/cruz-condemns-sweeping-anti-gay-uganda-law-as-horrific-and-wrong/ar-AA1bRfzH?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/cruz-condemns-sweeping-anti-gay-uganda-law-as-horrific-and-wrong/ar-AA1bRfzH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 22:20:42.240835+00:00



## US Says China Declined Request to Meet Austin in Singapore
 - [https://www.msn.com/en-us/news/world/us-says-china-declined-request-to-meet-austin-in-singapore/ar-AA1bR07m?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/us-says-china-declined-request-to-meet-austin-in-singapore/ar-AA1bR07m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 21:20:38.015422+00:00



## Debt limit: Leading Democratic senator trying to remove provision greenlighting Joe Manchin project
 - [https://www.msn.com/en-us/news/politics/debt-limit-leading-democratic-senator-trying-to-remove-provision-greenlighting-joe-manchin-project/ar-AA1bQSTz?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/debt-limit-leading-democratic-senator-trying-to-remove-provision-greenlighting-joe-manchin-project/ar-AA1bQSTz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 21:20:38.007824+00:00



## Ottawa woman, 96, sets world record with blazing 5K race
 - [https://www.msn.com/en-us/news/world/ottawa-woman-96-sets-world-record-with-blazing-5k-race/ar-AA1bQUzY?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ottawa-woman-96-sets-world-record-with-blazing-5k-race/ar-AA1bQUzY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 21:20:38.000864+00:00



## ER doctor, 49, who 'worked in crypto' was texting his fiancé moments before he disappeared
 - [https://www.msn.com/en-us/news/crime/er-doctor-49-who-worked-in-crypto-was-texting-his-fiancé-moments-before-he-disappeared/ar-AA1bR54n?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/er-doctor-49-who-worked-in-crypto-was-texting-his-fiancé-moments-before-he-disappeared/ar-AA1bR54n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 21:20:37.991529+00:00



## Biden calls for repeal of Uganda’s new anti-gay law, threatens sanctions
 - [https://www.msn.com/en-us/news/politics/biden-calls-for-repeal-of-uganda-s-new-anti-gay-law-threatens-sanctions/ar-AA1bR4TG?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-calls-for-repeal-of-uganda-s-new-anti-gay-law-threatens-sanctions/ar-AA1bR4TG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 21:20:37.983732+00:00



## House GOP hardliners trash debt limit bill as party leaders try to shore up votes
 - [https://www.msn.com/en-us/news/politics/house-gop-hardliners-trash-debt-limit-bill-as-party-leaders-try-to-shore-up-votes/ar-AA1bQXIn?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/house-gop-hardliners-trash-debt-limit-bill-as-party-leaders-try-to-shore-up-votes/ar-AA1bQXIn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 21:20:37.976350+00:00



## Sam Kaplan, 72, graduates from a Georgia college with his 99-year-old mom cheering him on
 - [https://www.msn.com/en-us/news/us/sam-kaplan-72-graduates-from-a-georgia-college-with-his-99-year-old-mom-cheering-him-on/ar-AA1bRcEs?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/sam-kaplan-72-graduates-from-a-georgia-college-with-his-99-year-old-mom-cheering-him-on/ar-AA1bRcEs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 21:20:37.968765+00:00



## 2 inmates escape from jail weeks after 4 others broke out from same facility
 - [https://www.msn.com/en-us/news/crime/2-inmates-escape-from-jail-weeks-after-4-others-broke-out-from-same-facility/ar-AA1bR9Ff?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/2-inmates-escape-from-jail-weeks-after-4-others-broke-out-from-same-facility/ar-AA1bR9Ff?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 20:20:45.886322+00:00



## Father of high school female skier who lost state title to transgender says competition 'not fair' for girls
 - [https://www.msn.com/en-us/news/us/father-of-high-school-female-skier-who-lost-state-title-to-transgender-says-competition-not-fair-for-girls/ar-AA1bR9GA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/father-of-high-school-female-skier-who-lost-state-title-to-transgender-says-competition-not-fair-for-girls/ar-AA1bR9GA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 20:20:45.879373+00:00



## China plans to land astronauts on moon before 2030
 - [https://www.msn.com/en-us/news/world/china-plans-to-land-astronauts-on-moon-before-2030/ar-AA1bQZIu?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/china-plans-to-land-astronauts-on-moon-before-2030/ar-AA1bQZIu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 20:20:45.871477+00:00



## Venezuela’s Maduro Visits Brazil in a Blow to US Strategy of Isolation
 - [https://www.msn.com/en-us/news/world/venezuela-s-maduro-visits-brazil-in-a-blow-to-us-strategy-of-isolation/ar-AA1bQLvW?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/venezuela-s-maduro-visits-brazil-in-a-blow-to-us-strategy-of-isolation/ar-AA1bQLvW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 20:20:45.864625+00:00



## Benedict Cumberbatch’s Home Attacked by Knife-Wielding Chef
 - [https://www.msn.com/en-us/news/world/benedict-cumberbatch-s-home-attacked-by-knife-wielding-chef/ar-AA1bQZIo?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/benedict-cumberbatch-s-home-attacked-by-knife-wielding-chef/ar-AA1bQZIo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 20:20:45.855730+00:00



## Debt limit crisis: How three Republicans could make McCarthy's life difficult this week
 - [https://www.msn.com/en-us/news/politics/debt-limit-crisis-how-three-republicans-could-make-mccarthy-s-life-difficult-this-week/ar-AA1bReEw?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/debt-limit-crisis-how-three-republicans-could-make-mccarthy-s-life-difficult-this-week/ar-AA1bReEw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 20:20:45.848811+00:00



## Texas lawmakers send anti-DEI bill to Abbott’s desk
 - [https://www.msn.com/en-us/news/politics/texas-lawmakers-send-anti-dei-bill-to-abbott-s-desk/ar-AA1bR9OP?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/texas-lawmakers-send-anti-dei-bill-to-abbott-s-desk/ar-AA1bR9OP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 20:20:45.841872+00:00



## Here's which generation you're part of based on your birth year — and why those distinctions exist
 - [https://www.msn.com/en-us/news/technology/here-s-which-generation-you-re-part-of-based-on-your-birth-year-and-why-those-distinctions-exist/ar-AA1bR9Yd?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/here-s-which-generation-you-re-part-of-based-on-your-birth-year-and-why-those-distinctions-exist/ar-AA1bR9Yd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 20:20:45.833950+00:00



## Race to secure US debt deal votes as deadline looms
 - [https://www.msn.com/en-us/news/politics/race-to-secure-us-debt-deal-votes-as-deadline-looms/ar-AA1bQGcd?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/race-to-secure-us-debt-deal-votes-as-deadline-looms/ar-AA1bQGcd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 19:29:33.195366+00:00



## Elizabeth Holmes spends final weekend at beach with partner and two kids ahead of prison sentence
 - [https://www.msn.com/en-us/news/crime/elizabeth-holmes-spends-final-weekend-at-beach-with-partner-and-two-kids-ahead-of-prison-sentence/ar-AA1bQZvv?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/elizabeth-holmes-spends-final-weekend-at-beach-with-partner-and-two-kids-ahead-of-prison-sentence/ar-AA1bQZvv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 19:29:33.187662+00:00



## Biden calls for immediate repeal of Uganda’s anti-gay law
 - [https://www.msn.com/en-us/news/politics/biden-calls-for-immediate-repeal-of-uganda-s-anti-gay-law/ar-AA1bQZmO?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-calls-for-immediate-repeal-of-uganda-s-anti-gay-law/ar-AA1bQZmO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 19:29:33.180672+00:00



## Biden marks Memorial Day lauding generations of fallen U.S. troops who 'dared all and gave all'
 - [https://www.msn.com/en-us/news/world/biden-marks-memorial-day-lauding-generations-of-fallen-u-s-troops-who-dared-all-and-gave-all/ar-AA1bQIYZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/biden-marks-memorial-day-lauding-generations-of-fallen-u-s-troops-who-dared-all-and-gave-all/ar-AA1bQIYZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 19:29:33.173616+00:00



## Iranian-born model draws outrage for dress with noose around neck to raise awareness for Iran executions
 - [https://www.msn.com/en-us/news/world/iranian-born-model-draws-outrage-for-dress-with-noose-around-neck-to-raise-awareness-for-iran-executions/ar-AA1bR6YZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/iranian-born-model-draws-outrage-for-dress-with-noose-around-neck-to-raise-awareness-for-iran-executions/ar-AA1bR6YZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 19:29:33.166675+00:00



## Student flouts Colorado school, wears Mexican and American flag sash to graduation
 - [https://www.msn.com/en-us/news/us/student-flouts-colorado-school-wears-mexican-and-american-flag-sash-to-graduation/ar-AA1bQOcQ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/student-flouts-colorado-school-wears-mexican-and-american-flag-sash-to-graduation/ar-AA1bQOcQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 19:29:33.159664+00:00



## DeSantis Disney governing board appointee quits a few months into job
 - [https://www.msn.com/en-us/news/politics/desantis-disney-governing-board-appointee-quits-a-few-months-into-job/ar-AA1bR6WO?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/desantis-disney-governing-board-appointee-quits-a-few-months-into-job/ar-AA1bR6WO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 19:29:33.152723+00:00



## What's in the debt limit bill? Key provisions in the Biden-McCarthy deal to avert default
 - [https://www.msn.com/en-us/news/politics/what-s-in-the-debt-limit-bill-key-provisions-in-the-biden-mccarthy-deal-to-avert-default/ar-AA1bQlSt?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/what-s-in-the-debt-limit-bill-key-provisions-in-the-biden-mccarthy-deal-to-avert-default/ar-AA1bQlSt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 19:29:33.145442+00:00



## Lindsey Graham responds defiantly to arrest warrant from Russia
 - [https://www.msn.com/en-us/news/world/lindsey-graham-responds-defiantly-to-arrest-warrant-from-russia/ar-AA1bQRXJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/lindsey-graham-responds-defiantly-to-arrest-warrant-from-russia/ar-AA1bQRXJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 18:29:29.473669+00:00



## Head of Russian state media calls for Lindsey Graham to be assassinated: 'We have his address'
 - [https://www.msn.com/en-us/news/world/head-of-russian-state-media-calls-for-lindsey-graham-to-be-assassinated-we-have-his-address/ar-AA1bQYZu?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/head-of-russian-state-media-calls-for-lindsey-graham-to-be-assassinated-we-have-his-address/ar-AA1bQYZu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 18:29:29.465495+00:00



## Ex-El Salvador President Mauricio Funes sentenced to 14 years for negotiating with gangs
 - [https://www.msn.com/en-us/news/world/ex-el-salvador-president-mauricio-funes-sentenced-to-14-years-for-negotiating-with-gangs/ar-AA1bQTSy?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ex-el-salvador-president-mauricio-funes-sentenced-to-14-years-for-negotiating-with-gangs/ar-AA1bQTSy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 18:29:29.458567+00:00



## Apartment collapse: Resident describes terrifying shaking, 8th victim rescued
 - [https://www.msn.com/en-us/news/crime/apartment-collapse-resident-describes-terrifying-shaking-8th-victim-rescued/ar-AA1bQb54?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/apartment-collapse-resident-describes-terrifying-shaking-8th-victim-rescued/ar-AA1bQb54?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 18:29:29.450616+00:00



## SpaceX and the science of failure
 - [https://www.msn.com/en-us/news/technology/spacex-and-the-science-of-failure/ar-AA1bQwhB?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/spacex-and-the-science-of-failure/ar-AA1bQwhB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 18:29:29.442836+00:00



## British prank TikToker who went viral for entering stranger's home is in custody
 - [https://www.msn.com/en-us/news/world/british-prank-tiktoker-who-went-viral-for-entering-stranger-s-home-is-in-custody/ar-AA1bQLnT?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/british-prank-tiktoker-who-went-viral-for-entering-stranger-s-home-is-in-custody/ar-AA1bQLnT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 18:29:29.435054+00:00



## China says it will send astronauts to the moon by 2030
 - [https://www.msn.com/en-us/news/world/china-says-it-will-send-astronauts-to-the-moon-by-2030/ar-AA1bQwmE?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/china-says-it-will-send-astronauts-to-the-moon-by-2030/ar-AA1bQwmE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 18:29:29.427206+00:00



## Rescue groups say Malta coordinated the return of 500 migrants to Libya instead of saving them
 - [https://www.msn.com/en-us/news/world/rescue-groups-say-malta-coordinated-the-return-of-500-migrants-to-libya-instead-of-saving-them/ar-AA1bQWwp?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/rescue-groups-say-malta-coordinated-the-return-of-500-migrants-to-libya-instead-of-saving-them/ar-AA1bQWwp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 18:29:29.419604+00:00



## What 5 more years of Erdogan's rule means for Turkey
 - [https://www.msn.com/en-us/news/world/what-5-more-years-of-erdogan-s-rule-means-for-turkey/ar-AA1bQM6S?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/what-5-more-years-of-erdogan-s-rule-means-for-turkey/ar-AA1bQM6S?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 17:29:34.452813+00:00



## Debt limit: What Biden and McCarthy's deal could mean for student loan forgiveness scheme
 - [https://www.msn.com/en-us/news/politics/debt-limit-what-biden-and-mccarthy-s-deal-could-mean-for-student-loan-forgiveness-scheme/ar-AA1bQyaF?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/debt-limit-what-biden-and-mccarthy-s-deal-could-mean-for-student-loan-forgiveness-scheme/ar-AA1bQyaF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 17:29:34.446025+00:00



## Laughter as Bulldog Spotted Dancing With Owner: 'Such a Personality'
 - [https://www.msn.com/en-us/news/technology/laughter-as-bulldog-spotted-dancing-with-owner-such-a-personality/ar-AA1bQKKF?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/laughter-as-bulldog-spotted-dancing-with-owner-such-a-personality/ar-AA1bQKKF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 17:29:34.437645+00:00



## Trump wishes happy Memorial Day to those fighting ‘misfits and lunatic thugs’ within the nation
 - [https://www.msn.com/en-us/news/politics/trump-wishes-happy-memorial-day-to-those-fighting-misfits-and-lunatic-thugs-within-the-nation/ar-AA1bQRpN?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-wishes-happy-memorial-day-to-those-fighting-misfits-and-lunatic-thugs-within-the-nation/ar-AA1bQRpN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 17:29:34.429043+00:00



## Ukrainian forces scattered around Bakhmut could retake the city after Wagner Group mercenaries evacuate and are replaced by regular Russian troops
 - [https://www.msn.com/en-us/news/world/ukrainian-forces-scattered-around-bakhmut-could-retake-the-city-after-wagner-group-mercenaries-evacuate-and-are-replaced-by-regular-russian-troops/ar-AA1bQAE5?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ukrainian-forces-scattered-around-bakhmut-could-retake-the-city-after-wagner-group-mercenaries-evacuate-and-are-replaced-by-regular-russian-troops/ar-AA1bQAE5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 17:29:34.421407+00:00



## Video Shows Russian Battle Tank Obliterated in Pinpoint Javelin Strike
 - [https://www.msn.com/en-us/news/world/video-shows-russian-battle-tank-obliterated-in-pinpoint-javelin-strike/ar-AA1bQJqD?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/video-shows-russian-battle-tank-obliterated-in-pinpoint-javelin-strike/ar-AA1bQJqD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 16:29:29.795289+00:00



## Debt limit: Here are three key takeaways from Biden and McCarthy's deal
 - [https://www.msn.com/en-us/news/politics/debt-limit-here-are-three-key-takeaways-from-biden-and-mccarthy-s-deal/ar-AA1bQLZn?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/debt-limit-here-are-three-key-takeaways-from-biden-and-mccarthy-s-deal/ar-AA1bQLZn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 16:29:29.786738+00:00



## Brit, 26, is killed by lightning 'while his girlfriend filmed him swimming in the sea' in Rhodes
 - [https://www.msn.com/en-us/news/world/brit-26-is-killed-by-lightning-while-his-girlfriend-filmed-him-swimming-in-the-sea-in-rhodes/ar-AA1bQl3r?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/brit-26-is-killed-by-lightning-while-his-girlfriend-filmed-him-swimming-in-the-sea-in-rhodes/ar-AA1bQl3r?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 16:29:29.779763+00:00



## Congress should not restrict care for veterans — deficit be damned
 - [https://www.msn.com/en-us/news/politics/congress-should-not-restrict-care-for-veterans-deficit-be-damned/ar-AA1bQssA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/congress-should-not-restrict-care-for-veterans-deficit-be-damned/ar-AA1bQssA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 16:29:29.772792+00:00



## Feds seek to scuttle showdown over 14th Amendment debt powers
 - [https://www.msn.com/en-us/news/politics/feds-seek-to-scuttle-showdown-over-14th-amendment-debt-powers/ar-AA1bQH7s?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/feds-seek-to-scuttle-showdown-over-14th-amendment-debt-powers/ar-AA1bQH7s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 16:29:29.765773+00:00



## At least 16 dead, dozens injured in shootings across the U.S. over Memorial Day weekend
 - [https://www.msn.com/en-us/news/us/at-least-16-dead-dozens-injured-in-shootings-across-the-u-s-over-memorial-day-weekend/ar-AA1bQxyt?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/at-least-16-dead-dozens-injured-in-shootings-across-the-u-s-over-memorial-day-weekend/ar-AA1bQxyt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 16:29:29.758381+00:00



## Former Russian commander in Ukraine says Putin could be overthrown by the Wagner mercenary army
 - [https://www.msn.com/en-us/news/world/former-russian-commander-in-ukraine-says-putin-could-be-overthrown-by-the-wagner-mercenary-army/ar-AA1bQMar?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/former-russian-commander-in-ukraine-says-putin-could-be-overthrown-by-the-wagner-mercenary-army/ar-AA1bQMar?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 16:29:29.750011+00:00



## Western supplies of weapons to Ukraine could escalate the war to a 'new dimension', Russia's ambassador to the UK says
 - [https://www.msn.com/en-us/news/world/western-supplies-of-weapons-to-ukraine-could-escalate-the-war-to-a-new-dimension-russia-s-ambassador-to-the-uk-says/ar-AA1bQnpF?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/western-supplies-of-weapons-to-ukraine-could-escalate-the-war-to-a-new-dimension-russia-s-ambassador-to-the-uk-says/ar-AA1bQnpF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 15:29:37.340040+00:00



## Boy, 15, drowns and 5 others rescued at New Jersey beach
 - [https://www.msn.com/en-us/news/us/boy-15-drowns-and-5-others-rescued-at-new-jersey-beach/ar-AA1bQwHq?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/boy-15-drowns-and-5-others-rescued-at-new-jersey-beach/ar-AA1bQwHq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 15:29:37.330104+00:00



## Here’s What’s in the Debt Ceiling Deal
 - [https://www.msn.com/en-us/news/politics/here-s-what-s-in-the-debt-ceiling-deal/ar-AA1bQwKF?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/here-s-what-s-in-the-debt-ceiling-deal/ar-AA1bQwKF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 15:29:37.322713+00:00



## Texas lawmakers send school safety bill to Gov. Abbott’s desk a year after Uvalde shooting
 - [https://www.msn.com/en-us/news/us/texas-lawmakers-send-school-safety-bill-to-gov-abbott-s-desk-a-year-after-uvalde-shooting/ar-AA1bQq8O?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/texas-lawmakers-send-school-safety-bill-to-gov-abbott-s-desk-a-year-after-uvalde-shooting/ar-AA1bQq8O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 15:29:37.315371+00:00



## Ukrainian tennis star Marta Kostyuk said she didn't respect her Belarus opponent for remaining silent about Russia's invasion
 - [https://www.msn.com/en-us/news/world/ukrainian-tennis-star-marta-kostyuk-said-she-didn-t-respect-her-belarus-opponent-for-remaining-silent-about-russia-s-invasion/ar-AA1bQwR5?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ukrainian-tennis-star-marta-kostyuk-said-she-didn-t-respect-her-belarus-opponent-for-remaining-silent-about-russia-s-invasion/ar-AA1bQwR5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 15:29:37.308085+00:00



## Ron DeSantis reflects on Navy career, warns military is ‘different’ from when he served
 - [https://www.msn.com/en-us/news/us/ron-desantis-reflects-on-navy-career-warns-military-is-different-from-when-he-served/ar-AA1bQBOA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/ron-desantis-reflects-on-navy-career-warns-military-is-different-from-when-he-served/ar-AA1bQBOA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 15:29:37.300325+00:00



## Biden marks Memorial Day nearly 2 years after ending America's longest war, lauds troops' sacrifice
 - [https://www.msn.com/en-us/news/politics/biden-marks-memorial-day-nearly-2-years-after-ending-america-s-longest-war-lauds-troops-sacrifice/ar-AA1bQo41?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-marks-memorial-day-nearly-2-years-after-ending-america-s-longest-war-lauds-troops-sacrifice/ar-AA1bQo41?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 15:29:37.292094+00:00



## Russia strikes Kyiv during daylight hours after first launching a nighttime barrage
 - [https://www.msn.com/en-us/news/world/russia-strikes-kyiv-during-daylight-hours-after-first-launching-a-nighttime-barrage/ar-AA1bQoYY?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/russia-strikes-kyiv-during-daylight-hours-after-first-launching-a-nighttime-barrage/ar-AA1bQoYY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 14:36:46.069291+00:00



## We should memorialize all soldiers who died serving America’s interests
 - [https://www.msn.com/en-us/news/politics/we-should-memorialize-all-soldiers-who-died-serving-america-s-interests/ar-AA1bPVQj?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/we-should-memorialize-all-soldiers-who-died-serving-america-s-interests/ar-AA1bPVQj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 14:36:46.062360+00:00



## Sudan army, rival force under pressure to extend truce after mediators show impatience with breaches
 - [https://www.msn.com/en-us/news/world/sudan-army-rival-force-under-pressure-to-extend-truce-after-mediators-show-impatience-with-breaches/ar-AA1bQdCA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/sudan-army-rival-force-under-pressure-to-extend-truce-after-mediators-show-impatience-with-breaches/ar-AA1bQdCA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 14:36:46.055243+00:00



## Sitcom heroes, sports analogies, and rap parodies: How sassy floor charts have spiced up Congress
 - [https://www.msn.com/en-us/news/politics/sitcom-heroes-sports-analogies-and-rap-parodies-how-sassy-floor-charts-have-spiced-up-congress/ar-AA1bQjZF?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/sitcom-heroes-sports-analogies-and-rap-parodies-how-sassy-floor-charts-have-spiced-up-congress/ar-AA1bQjZF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 14:36:46.047410+00:00



## Authorities search for possible missing residents in Iowa apartment collapse
 - [https://www.msn.com/en-us/news/us/authorities-search-for-possible-missing-residents-in-iowa-apartment-collapse/ar-AA1bQppL?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/authorities-search-for-possible-missing-residents-in-iowa-apartment-collapse/ar-AA1bQppL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 14:36:46.040414+00:00



## School official laments electric buses cost ‘5X more’ and are riddled with ‘performance issues’
 - [https://www.msn.com/en-us/news/us/school-official-laments-electric-buses-cost-5x-more-and-are-riddled-with-performance-issues/ar-AA1bQpwz?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/school-official-laments-electric-buses-cost-5x-more-and-are-riddled-with-performance-issues/ar-AA1bQpwz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 14:36:46.033457+00:00



## 8th victim rescued from building collapse, resident describes terrifying shaking
 - [https://www.msn.com/en-us/news/crime/8th-victim-rescued-from-building-collapse-resident-describes-terrifying-shaking/ar-AA1bQb54?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/8th-victim-rescued-from-building-collapse-resident-describes-terrifying-shaking/ar-AA1bQb54?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 14:36:46.026451+00:00



## DeSantis dunks on debt deal: We're 'careening towards bankruptcy'
 - [https://www.msn.com/en-us/news/politics/desantis-dunks-on-debt-deal-we-re-careening-towards-bankruptcy/ar-AA1bQnbp?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/desantis-dunks-on-debt-deal-we-re-careening-towards-bankruptcy/ar-AA1bQnbp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 14:36:46.018577+00:00



## Davenport building collapse: One person rescued overnight as search for survivors continues
 - [https://www.msn.com/en-us/news/us/davenport-building-collapse-one-person-rescued-overnight-as-search-for-survivors-continues/ar-AA1bQ4EW?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/davenport-building-collapse-one-person-rescued-overnight-as-search-for-survivors-continues/ar-AA1bQ4EW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 13:36:49.269425+00:00



## Ukrainian special operators are learning to fight Russia without the 'tethers' other militaries have gotten used to
 - [https://www.msn.com/en-us/news/world/ukrainian-special-operators-are-learning-to-fight-russia-without-the-tethers-other-militaries-have-gotten-used-to/ar-AA1bQ7rZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ukrainian-special-operators-are-learning-to-fight-russia-without-the-tethers-other-militaries-have-gotten-used-to/ar-AA1bQ7rZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 13:36:49.262250+00:00



## Intel's Next PC Chip, Meteor Lake, Will Speed Up AI Later This Year
 - [https://www.msn.com/en-us/news/technology/intel-s-next-pc-chip-meteor-lake-will-speed-up-ai-later-this-year/ar-AA1bQcIg?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/intel-s-next-pc-chip-meteor-lake-will-speed-up-ai-later-this-year/ar-AA1bQcIg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 13:36:49.254628+00:00



## At the center of L.A.'s transformation: a man named Zev. His memoir is essential history
 - [https://www.msn.com/en-us/news/us/at-the-center-of-l-a-s-transformation-a-man-named-zev-his-memoir-is-essential-history/ar-AA1bQ3yq?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/at-the-center-of-l-a-s-transformation-a-man-named-zev-his-memoir-is-essential-history/ar-AA1bQ3yq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 13:36:49.245829+00:00



## Juneteenth event banner featuring White couple in South Carolina sparks outrage: 'I was appalled'
 - [https://www.msn.com/en-us/news/us/juneteenth-event-banner-featuring-white-couple-in-south-carolina-sparks-outrage-i-was-appalled/ar-AA1bPLsU?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/juneteenth-event-banner-featuring-white-couple-in-south-carolina-sparks-outrage-i-was-appalled/ar-AA1bPLsU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 13:36:49.238838+00:00



## Authorities search for missing residents in Iowa apartment collapse
 - [https://www.msn.com/en-us/news/us/authorities-search-for-missing-residents-in-iowa-apartment-collapse/ar-AA1bONhK?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/authorities-search-for-missing-residents-in-iowa-apartment-collapse/ar-AA1bONhK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 13:36:49.230064+00:00



## Ukrainian official hints counteroffensive coming ‘soon’
 - [https://www.msn.com/en-us/news/world/ukrainian-official-hints-counteroffensive-coming-soon/ar-AA1bQ7Ga?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ukrainian-official-hints-counteroffensive-coming-soon/ar-AA1bQ7Ga?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 13:36:49.222104+00:00



## Russia issues arrest warrant for Lindsey Graham after Ukraine comments
 - [https://www.msn.com/en-us/news/politics/russia-issues-arrest-warrant-for-lindsey-graham-after-ukraine-comments/ar-AA1bPXhz?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/russia-issues-arrest-warrant-for-lindsey-graham-after-ukraine-comments/ar-AA1bPXhz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 12:36:47.621794+00:00



## Georgia Medal of Honor recipient's family believed he would never be found; now his remains are home
 - [https://www.msn.com/en-us/news/us/georgia-medal-of-honor-recipient-s-family-believed-he-would-never-be-found-now-his-remains-are-home/ar-AA1bPXnO?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/georgia-medal-of-honor-recipient-s-family-believed-he-would-never-be-found-now-his-remains-are-home/ar-AA1bPXnO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 12:36:47.614816+00:00



## Reality, starring Sydney Sweeney, is unsettling, vital viewing
 - [https://www.msn.com/en-us/news/us/reality-starring-sydney-sweeney-is-unsettling-vital-viewing/ar-AA1bQ4lJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/reality-starring-sydney-sweeney-is-unsettling-vital-viewing/ar-AA1bQ4lJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 12:36:47.607235+00:00



## The Biggest Rumored Samsung Gadgets to Expect in 2023
 - [https://www.msn.com/en-us/news/technology/the-biggest-rumored-samsung-gadgets-to-expect-in-2023/ar-AA16w9Ee?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/the-biggest-rumored-samsung-gadgets-to-expect-in-2023/ar-AA16w9Ee?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 12:36:47.597900+00:00



## Morning Rundown: Iowa apartment collapse, ‘Succession’ finale, and debt ceiling deal
 - [https://www.msn.com/en-us/news/us/morning-rundown-iowa-apartment-collapse-succession-finale-and-debt-ceiling-deal/ar-AA1bPKZY?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/morning-rundown-iowa-apartment-collapse-succession-finale-and-debt-ceiling-deal/ar-AA1bPKZY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 12:36:47.590781+00:00



## Uganda signs anti-gay bill into law that calls for death penalty in some cases
 - [https://www.msn.com/en-us/news/world/uganda-signs-anti-gay-bill-into-law-that-calls-for-death-penalty-in-some-cases/ar-AA1bPv9q?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/uganda-signs-anti-gay-bill-into-law-that-calls-for-death-penalty-in-some-cases/ar-AA1bPv9q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 12:36:47.583615+00:00



## Russia issues arrest warrant for Lindsey Graham over Ukraine comments
 - [https://www.msn.com/en-us/news/world/russia-issues-arrest-warrant-for-lindsey-graham-over-ukraine-comments/ar-AA1bPXuW?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/russia-issues-arrest-warrant-for-lindsey-graham-over-ukraine-comments/ar-AA1bPXuW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 12:36:47.575728+00:00



## Why do Kosovo-Serbia tensions persist?
 - [https://www.msn.com/en-us/news/world/why-do-kosovo-serbia-tensions-persist/ar-AA1bQ7cM?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/why-do-kosovo-serbia-tensions-persist/ar-AA1bQ7cM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 12:36:47.568411+00:00



## Acts of Remembrance
 - [https://www.msn.com/en-us/news/us/acts-of-remembrance/ar-AA1bPKiF?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/acts-of-remembrance/ar-AA1bPKiF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:36:41.558540+00:00



## Kirk Cameron: ‘You don’t realize how precious the cost of liberty is until you’ve lost it, and we’re losing it’
 - [https://www.msn.com/en-us/news/us/kirk-cameron-you-don-t-realize-how-precious-the-cost-of-liberty-is-until-you-ve-lost-it-and-we-re-losing-it/ar-AA1bPD0T?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/kirk-cameron-you-don-t-realize-how-precious-the-cost-of-liberty-is-until-you-ve-lost-it-and-we-re-losing-it/ar-AA1bPD0T?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:36:41.551542+00:00



## Marianne Williamson's campaign against the world
 - [https://www.msn.com/en-us/news/politics/marianne-williamson-s-campaign-against-the-world/ar-AA1bPCWO?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/marianne-williamson-s-campaign-against-the-world/ar-AA1bPCWO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:36:41.543910+00:00



## iOS 17 Should Steal These Android 14 Features
 - [https://www.msn.com/en-us/news/technology/ios-17-should-steal-these-android-14-features/ar-AA1bPPZU?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/ios-17-should-steal-these-android-14-features/ar-AA1bPPZU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:36:41.535737+00:00



## Republicans win on the debt ceiling: Here's why House GOP should support deal
 - [https://www.msn.com/en-us/news/politics/republicans-win-on-the-debt-ceiling-here-s-why-house-gop-should-support-deal/ar-AA1bPTRq?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/republicans-win-on-the-debt-ceiling-here-s-why-house-gop-should-support-deal/ar-AA1bPTRq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:36:41.528034+00:00



## Hope and loss on Memorial Day: It's been a rough year since Buffalo
 - [https://www.msn.com/en-us/news/us/hope-and-loss-on-memorial-day-it-s-been-a-rough-year-since-buffalo/ar-AA1bPYG8?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/hope-and-loss-on-memorial-day-it-s-been-a-rough-year-since-buffalo/ar-AA1bPYG8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:05:04.793509+00:00



## No new service members added to Army memorial wall for first time since 9/11
 - [https://www.msn.com/en-us/news/us/no-new-service-members-added-to-army-memorial-wall-for-first-time-since-9-11/ar-AA1bPddK?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/no-new-service-members-added-to-army-memorial-wall-for-first-time-since-9-11/ar-AA1bPddK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:05:04.784917+00:00



## Russia issues arrest warrant for Lindsey Graham over Ukraine comments
 - [https://www.msn.com/en-us/news/world/russia-issues-arrest-warrant-for-lindsey-graham-over-ukraine-comments/ar-AA1bPy01?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/russia-issues-arrest-warrant-for-lindsey-graham-over-ukraine-comments/ar-AA1bPy01?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:05:04.777057+00:00



## TikTok Owner Under Pressure in China Over Death of Influencer
 - [https://www.msn.com/en-us/news/world/tiktok-owner-under-pressure-in-china-over-death-of-influencer/ar-AA1bPPL2?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/tiktok-owner-under-pressure-in-china-over-death-of-influencer/ar-AA1bPPL2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:05:04.769956+00:00



## Ralph Yarl raises money for traumatic brain injuries following wrong house shooting
 - [https://www.msn.com/en-us/news/crime/ralph-yarl-raises-money-for-traumatic-brain-injuries-following-wrong-house-shooting/ar-AA1bPLI4?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/ralph-yarl-raises-money-for-traumatic-brain-injuries-following-wrong-house-shooting/ar-AA1bPLI4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:05:04.761553+00:00



## Uganda's president signs harsh anti-gay law, with the death penalty in some cases
 - [https://www.msn.com/en-us/news/world/uganda-s-president-signs-harsh-anti-gay-law-with-the-death-penalty-in-some-cases/ar-AA1bPTMM?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/uganda-s-president-signs-harsh-anti-gay-law-with-the-death-penalty-in-some-cases/ar-AA1bPTMM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:05:04.754439+00:00



## The IRS still plays political speech police
 - [https://www.msn.com/en-us/news/politics/the-irs-still-plays-political-speech-police/ar-AA1bPCSQ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/the-irs-still-plays-political-speech-police/ar-AA1bPCSQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:05:04.746621+00:00



## UK experts are teaching Ukrainians to make can-sized bombs that can bring down buildings, report says
 - [https://www.msn.com/en-us/news/world/uk-experts-are-teaching-ukrainians-to-make-can-sized-bombs-that-can-bring-down-buildings-report-says/ar-AA1bPKbZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/uk-experts-are-teaching-ukrainians-to-make-can-sized-bombs-that-can-bring-down-buildings-report-says/ar-AA1bPKbZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 11:05:04.738750+00:00



## North Korea Says It’s About to Launch Its First Military Satellite. Here’s What We Know So Far
 - [https://www.msn.com/en-us/news/world/north-korea-says-it-s-about-to-launch-its-first-military-satellite-here-s-what-we-know-so-far/ar-AA1bPMjg?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/north-korea-says-it-s-about-to-launch-its-first-military-satellite-here-s-what-we-know-so-far/ar-AA1bPMjg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 10:02:44.900111+00:00



## Russian Barrage Hits Air Base in Western Ukraine, Targets Kyiv
 - [https://www.msn.com/en-us/news/world/russian-barrage-hits-air-base-in-western-ukraine-targets-kyiv/ar-AA1bPOxN?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/russian-barrage-hits-air-base-in-western-ukraine-targets-kyiv/ar-AA1bPOxN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 10:02:44.891690+00:00



## Thousands evacuated in Philippines amid warnings of floods, landslides from Typhoon Mawar
 - [https://www.msn.com/en-us/news/world/thousands-evacuated-in-philippines-amid-warnings-of-floods-landslides-from-typhoon-mawar/ar-AA1bPFrS?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/thousands-evacuated-in-philippines-amid-warnings-of-floods-landslides-from-typhoon-mawar/ar-AA1bPFrS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 10:02:44.883878+00:00



## Marjorie Taylor Greene Finds Herself Isolated Among Republicans
 - [https://www.msn.com/en-us/news/politics/marjorie-taylor-greene-finds-herself-isolated-among-republicans/ar-AA1bPlhK?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/marjorie-taylor-greene-finds-herself-isolated-among-republicans/ar-AA1bPlhK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 10:02:44.876645+00:00



## Dramatic video captures shootout between Charlotte bus driver and passenger
 - [https://www.msn.com/en-us/news/us/dramatic-video-captures-shootout-between-charlotte-bus-driver-and-passenger/ar-AA1bPzXk?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/dramatic-video-captures-shootout-between-charlotte-bus-driver-and-passenger/ar-AA1bPzXk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 10:02:44.869546+00:00



## Spanish prime minister calls for early general election
 - [https://www.msn.com/en-us/news/world/spanish-prime-minister-calls-for-early-general-election/ar-AA1bPxA8?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/spanish-prime-minister-calls-for-early-general-election/ar-AA1bPxA8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 10:02:44.862312+00:00



## Websites linked to Iran's presidency hacked with images of exile group's leaders
 - [https://www.msn.com/en-us/news/world/websites-linked-to-iran-s-presidency-hacked-with-images-of-exile-group-s-leaders/ar-AA1bPd5j?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/websites-linked-to-iran-s-presidency-hacked-with-images-of-exile-group-s-leaders/ar-AA1bPd5j?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 10:02:44.855066+00:00



## Uganda's president signs anti-LGBTQ bill into law
 - [https://www.msn.com/en-us/news/world/uganda-s-president-signs-anti-lgbtq-bill-into-law/ar-AA1bPv9q?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/uganda-s-president-signs-anti-lgbtq-bill-into-law/ar-AA1bPv9q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 10:02:44.846366+00:00



## Russian State TV Is Running Out of Ideas
 - [https://www.msn.com/en-us/news/world/russian-state-tv-is-running-out-of-ideas/ar-AA1bPanE?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/russian-state-tv-is-running-out-of-ideas/ar-AA1bPanE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 08:22:48.414027+00:00



## Florida National Guard troops 'proud to help’ fight Texas border crisis, DeSantis says
 - [https://www.msn.com/en-us/news/us/florida-national-guard-troops-proud-to-help-fight-texas-border-crisis-desantis-says/ar-AA1bPrld?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/florida-national-guard-troops-proud-to-help-fight-texas-border-crisis-desantis-says/ar-AA1bPrld?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 08:22:48.401955+00:00



## UN talks on a treaty to end global plastic pollution open in Paris
 - [https://www.msn.com/en-us/news/world/un-talks-on-a-treaty-to-end-global-plastic-pollution-open-in-paris/ar-AA1bPcib?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/un-talks-on-a-treaty-to-end-global-plastic-pollution-open-in-paris/ar-AA1bPcib?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 08:22:48.391138+00:00



## Party leaders face daunting task of selling debt limit deal to dissatisfied Congress
 - [https://www.msn.com/en-us/news/politics/party-leaders-face-daunting-task-of-selling-debt-limit-deal-to-dissatisfied-congress/ar-AA1bPozL?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/party-leaders-face-daunting-task-of-selling-debt-limit-deal-to-dissatisfied-congress/ar-AA1bPozL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 07:22:15.543356+00:00



## US, Japan, Philippines to Hold Drills Amid China Tensions
 - [https://www.msn.com/en-us/news/world/us-japan-philippines-to-hold-drills-amid-china-tensions/ar-AA1bPr2O?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/us-japan-philippines-to-hold-drills-amid-china-tensions/ar-AA1bPr2O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 07:22:15.531870+00:00



## Nigeria’s Tinubu to be sworn in as president amid hopes and scepticism
 - [https://www.msn.com/en-us/news/world/nigeria-s-tinubu-to-be-sworn-in-as-president-amid-hopes-and-scepticism/ar-AA1bPr5w?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/nigeria-s-tinubu-to-be-sworn-in-as-president-amid-hopes-and-scepticism/ar-AA1bPr5w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 07:22:15.522790+00:00



## Rescues search for people unaccounted for after after Iowa apartment collapse
 - [https://www.msn.com/en-us/news/world/rescues-search-for-people-unaccounted-for-after-after-iowa-apartment-collapse/ar-AA1bP7Ks?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/rescues-search-for-people-unaccounted-for-after-after-iowa-apartment-collapse/ar-AA1bP7Ks?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 06:22:17.925117+00:00



## Read Biden and McCarthy's Debt Limit Compromise That is Causing Outrage
 - [https://www.msn.com/en-us/news/politics/read-biden-and-mccarthy-s-debt-limit-compromise-that-is-causing-outrage/ar-AA1bPoo0?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/read-biden-and-mccarthy-s-debt-limit-compromise-that-is-causing-outrage/ar-AA1bPoo0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 06:22:17.915904+00:00



## AI in dentistry: Researchers find that artificial intelligence can create better dental crowns
 - [https://www.msn.com/en-us/health/health-news/ai-in-dentistry-researchers-find-that-artificial-intelligence-can-create-better-dental-crowns/ar-AA1bOXia?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/health/health-news/ai-in-dentistry-researchers-find-that-artificial-intelligence-can-create-better-dental-crowns/ar-AA1bOXia?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 06:22:17.907143+00:00



## Kosovo Serbs gather to take over municipality buildings in the north
 - [https://www.msn.com/en-us/news/world/kosovo-serbs-gather-to-take-over-municipality-buildings-in-the-north/ar-AA1bP0d0?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/kosovo-serbs-gather-to-take-over-municipality-buildings-in-the-north/ar-AA1bP0d0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 06:22:17.898321+00:00



## Someone made a hyper-realistic deepfake of Ron DeSantis as Michael Scott from 'The Office' wearing women's clothes. It's the latest instance of AI being weaponized to take DeSantis down.
 - [https://www.msn.com/en-us/news/politics/someone-made-a-hyper-realistic-deepfake-of-ron-desantis-as-michael-scott-from-the-office-wearing-women-s-clothes-it-s-the-latest-instance-of-ai-being-weaponized-to-take-desantis-down/ar-AA1bPlWt?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/someone-made-a-hyper-realistic-deepfake-of-ron-desantis-as-michael-scott-from-the-office-wearing-women-s-clothes-it-s-the-latest-instance-of-ai-being-weaponized-to-take-desantis-down/ar-AA1bPlWt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 06:22:17.889996+00:00



## Rescues search for people unaccounted for after after Iowa apartment collapse
 - [https://www.msn.com/en-us/news/crime/rescues-search-for-people-unaccounted-for-after-after-iowa-apartment-collapse/ar-AA1bP7Ks?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/rescues-search-for-people-unaccounted-for-after-after-iowa-apartment-collapse/ar-AA1bP7Ks?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 05:22:14.214260+00:00



## Memorial Day, 2023
 - [https://www.msn.com/en-us/news/us/memorial-day-2023/ar-AA1bOQ5z?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/memorial-day-2023/ar-AA1bOQ5z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 05:22:14.205775+00:00



## Authorities search for possible missing residents in Iowa apartment collapse
 - [https://www.msn.com/en-us/news/us/authorities-search-for-possible-missing-residents-in-iowa-apartment-collapse/ar-AA1bONhK?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/authorities-search-for-possible-missing-residents-in-iowa-apartment-collapse/ar-AA1bONhK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 05:22:14.197852+00:00



## 'He's home': Missing 73 years, Medal of Honor recipient's remains return to Georgia
 - [https://www.msn.com/en-us/news/us/he-s-home-missing-73-years-medal-of-honor-recipient-s-remains-return-to-georgia/ar-AA1bP9nf?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/he-s-home-missing-73-years-medal-of-honor-recipient-s-remains-return-to-georgia/ar-AA1bP9nf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 05:22:14.188457+00:00



## U.S Tech Mogul Bankrolls Pro-Russia, Pro-China News Network
 - [https://www.msn.com/en-us/news/world/u-s-tech-mogul-bankrolls-pro-russia-pro-china-news-network/ar-AA1bP4pO?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/u-s-tech-mogul-bankrolls-pro-russia-pro-china-news-network/ar-AA1bP4pO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 04:22:14.467365+00:00



## ‘Succession’ finally has a winner, but that was never the point
 - [https://www.msn.com/en-us/news/world/succession-finally-has-a-winner-but-that-was-never-the-point/ar-AA1bP6Y8?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/succession-finally-has-a-winner-but-that-was-never-the-point/ar-AA1bP6Y8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 04:22:14.460009+00:00



## Ukraine's defense ministry says its Storm Shadow long-range missiles have hit 100% of their targets
 - [https://www.msn.com/en-us/news/world/ukraine-s-defense-ministry-says-its-storm-shadow-long-range-missiles-have-hit-100-of-their-targets/ar-AA1bOUgA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ukraine-s-defense-ministry-says-its-storm-shadow-long-range-missiles-have-hit-100-of-their-targets/ar-AA1bOUgA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 04:22:14.452589+00:00



## Trump's welcome of Scott into 2024 race shows his calculus: The more GOP rivals, the better for him
 - [https://www.msn.com/en-us/news/politics/trump-s-welcome-of-scott-into-2024-race-shows-his-calculus-the-more-gop-rivals-the-better-for-him/ar-AA1bP2Qt?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-s-welcome-of-scott-into-2024-race-shows-his-calculus-the-more-gop-rivals-the-better-for-him/ar-AA1bP2Qt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 04:22:14.444099+00:00



## Key Takeaways From Biden-McCarthy Deal to Avert US Default
 - [https://www.msn.com/en-us/news/politics/key-takeaways-from-biden-mccarthy-deal-to-avert-us-default/ar-AA1bMHgo?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/key-takeaways-from-biden-mccarthy-deal-to-avert-us-default/ar-AA1bMHgo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 03:22:14.825873+00:00



## McConnell endorses debt-limit deal, calls on Senate conservatives not to delay it
 - [https://www.msn.com/en-us/news/politics/mcconnell-endorses-debt-limit-deal-calls-on-senate-conservatives-not-to-delay-it/ar-AA1bP1b2?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/mcconnell-endorses-debt-limit-deal-calls-on-senate-conservatives-not-to-delay-it/ar-AA1bP1b2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 03:22:14.817382+00:00



## Elon Musk says Twitter has no 'actual choice' when complying with authoritarian government requests to restrict content
 - [https://www.msn.com/en-us/news/technology/elon-musk-says-twitter-has-no-actual-choice-when-complying-with-authoritarian-government-requests-to-restrict-content/ar-AA1bOTRF?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/elon-musk-says-twitter-has-no-actual-choice-when-complying-with-authoritarian-government-requests-to-restrict-content/ar-AA1bOTRF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 03:22:14.809846+00:00



## ‘The Orphan’ Comes to Life in This Horrifying True Story
 - [https://www.msn.com/en-us/news/crime/the-orphan-comes-to-life-in-this-horrifying-true-story/ar-AA1bP1Ru?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/the-orphan-comes-to-life-in-this-horrifying-true-story/ar-AA1bP1Ru?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 03:22:14.802530+00:00



## Escaped inmate convicted of double murder found dead in river: Marshals
 - [https://www.msn.com/en-us/news/crime/escaped-inmate-convicted-of-double-murder-found-dead-in-river-marshals/ar-AA1bARQj?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/escaped-inmate-convicted-of-double-murder-found-dead-in-river-marshals/ar-AA1bARQj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 03:22:14.795508+00:00



## Wrinkles and curveballs in the debt ceiling bill
 - [https://www.msn.com/en-us/news/politics/wrinkles-and-curveballs-in-the-debt-ceiling-bill/ar-AA1bOYVj?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/wrinkles-and-curveballs-in-the-debt-ceiling-bill/ar-AA1bOYVj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 03:22:14.787924+00:00



## North Korea notifies neighboring Japan it plans to launch satellite in coming days
 - [https://www.msn.com/en-us/news/world/north-korea-notifies-neighboring-japan-it-plans-to-launch-satellite-in-coming-days/ar-AA1bOxud?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/north-korea-notifies-neighboring-japan-it-plans-to-launch-satellite-in-coming-days/ar-AA1bOxud?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 02:22:17.313611+00:00



## Trump blasts Greg Abbott for silent response to Ken Paxton impeachment
 - [https://www.msn.com/en-us/news/politics/trump-blasts-greg-abbott-for-silent-response-to-ken-paxton-impeachment/ar-AA1bOR8j?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-blasts-greg-abbott-for-silent-response-to-ken-paxton-impeachment/ar-AA1bOR8j?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 02:22:17.303218+00:00



## What to expect from newly emboldened Erdogan
 - [https://www.msn.com/en-us/news/world/what-to-expect-from-newly-emboldened-erdogan/ar-AA1bOVDz?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/what-to-expect-from-newly-emboldened-erdogan/ar-AA1bOVDz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 02:22:17.295138+00:00



## Debt limit deal would approve West Virginia pipeline, curtail environmental law
 - [https://www.msn.com/en-us/news/politics/debt-limit-deal-would-approve-west-virginia-pipeline-curtail-environmental-law/ar-AA1bOTvj?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/debt-limit-deal-would-approve-west-virginia-pipeline-curtail-environmental-law/ar-AA1bOTvj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 02:22:17.286724+00:00



## Body of escaped inmate found floating in Ohio River in Kentucky, police say
 - [https://www.msn.com/en-us/news/crime/body-of-escaped-inmate-found-floating-in-ohio-river-in-kentucky-police-say/ar-AA1bOv11?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/body-of-escaped-inmate-found-floating-in-ohio-river-in-kentucky-police-say/ar-AA1bOv11?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 02:22:17.278165+00:00



## Key questions and takeaways from the debt ceiling deal
 - [https://www.msn.com/en-us/news/politics/key-questions-and-takeaways-from-the-debt-ceiling-deal/ar-AA1bOVNZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/key-questions-and-takeaways-from-the-debt-ceiling-deal/ar-AA1bOVNZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 02:22:17.270185+00:00



## Video Games Are Finally Waking Up to Climate Change
 - [https://www.msn.com/en-us/news/technology/video-games-are-finally-waking-up-to-climate-change/ar-AA1bwhzJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/video-games-are-finally-waking-up-to-climate-change/ar-AA1bwhzJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 01:22:11.661789+00:00



## CHRISTOPHER STEVENS: Gary Lineker lacks charisma of a game show host
 - [https://www.msn.com/en-us/news/world/christopher-stevens-gary-lineker-lacks-charisma-of-a-game-show-host/ar-AA1bOCBd?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/christopher-stevens-gary-lineker-lacks-charisma-of-a-game-show-host/ar-AA1bOCBd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 01:22:11.654447+00:00



## Erdogan hails election victory but Turkey left divided
 - [https://www.msn.com/en-us/news/world/erdogan-hails-election-victory-but-turkey-left-divided/ar-AA1bOHHE?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/erdogan-hails-election-victory-but-turkey-left-divided/ar-AA1bOHHE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 01:22:11.646857+00:00



## Debt ceiling deal includes completion of embattled Mountain Valley Pipeline
 - [https://www.msn.com/en-us/news/politics/debt-ceiling-deal-includes-completion-of-embattled-mountain-valley-pipeline/ar-AA1bOKef?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/debt-ceiling-deal-includes-completion-of-embattled-mountain-valley-pipeline/ar-AA1bOKef?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 01:22:11.635903+00:00



## North Korea tells neighboring Japan it plans to launch satellite in coming days
 - [https://www.msn.com/en-us/news/world/north-korea-tells-neighboring-japan-it-plans-to-launch-satellite-in-coming-days/ar-AA1bOxud?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/north-korea-tells-neighboring-japan-it-plans-to-launch-satellite-in-coming-days/ar-AA1bOxud?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 01:22:11.627790+00:00



## The Bionic Eye That Could Restore Vision (and Put Humans in the Matrix)
 - [https://www.msn.com/en-us/news/technology/the-bionic-eye-that-could-restore-vision-and-put-humans-in-the-matrix/ar-AA1ayh2H?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/the-bionic-eye-that-could-restore-vision-and-put-humans-in-the-matrix/ar-AA1ayh2H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 00:18:27.526815+00:00



## Why the U.S. Debt Ceiling Deal Could Have Trouble in Congress
 - [https://www.msn.com/en-us/news/politics/why-the-u-s-debt-ceiling-deal-could-have-trouble-in-congress/vi-AA1bOkz4?srcref=rss](https://www.msn.com/en-us/news/politics/why-the-u-s-debt-ceiling-deal-could-have-trouble-in-congress/vi-AA1bOkz4?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 00:18:27.517086+00:00



## Debt deal text released as leaders corral votes
 - [https://www.msn.com/en-us/news/politics/debt-deal-text-released-as-leaders-corral-votes/ar-AA1bOkCO?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/debt-deal-text-released-as-leaders-corral-votes/ar-AA1bOkCO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 00:18:27.508627+00:00



## McCarthy may need Democrat support to pass the debt ceiling deal and a secret group of moderates may be there to catch him if the GOP revolts, report says
 - [https://www.msn.com/en-us/news/politics/mccarthy-may-need-democrat-support-to-pass-the-debt-ceiling-deal-and-a-secret-group-of-moderates-may-be-there-to-catch-him-if-the-gop-revolts-report-says/ar-AA1bOCm9?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/mccarthy-may-need-democrat-support-to-pass-the-debt-ceiling-deal-and-a-secret-group-of-moderates-may-be-there-to-catch-him-if-the-gop-revolts-report-says/ar-AA1bOCm9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 00:18:27.500873+00:00



## Arizona mom pleads guilty to locking 6-year-old son in closet, starving him to death
 - [https://www.msn.com/en-us/news/crime/arizona-mom-pleads-guilty-to-locking-6-year-old-son-in-closet-starving-him-to-death/ar-AA1bOuuG?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/arizona-mom-pleads-guilty-to-locking-6-year-old-son-in-closet-starving-him-to-death/ar-AA1bOuuG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 00:18:27.493221+00:00



## With deal in place, Biden urges Congress to pass debt ceiling agreement
 - [https://www.msn.com/en-us/news/politics/with-deal-in-place-biden-urges-congress-to-pass-debt-ceiling-agreement/ar-AA1bO8kB?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/with-deal-in-place-biden-urges-congress-to-pass-debt-ceiling-agreement/ar-AA1bO8kB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-29 00:18:27.485247+00:00



