# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Pretty Girl (LIVE) - David Ryan Harris + Scary Pockets
 - [https://www.youtube.com/watch?v=p4jnyHQCEpo](https://www.youtube.com/watch?v=p4jnyHQCEpo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2023-05-29 13:00:40+00:00

New vinyl alert: Pockets Presents: David Ryan Harris! Preorder at https://www.scarypocketsfunk.com
Get tickets to see us on tour with David Ryan Harris! https://www.scarypocketsfunk.com

Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A live funk version of David Ryan Harris' "Pretty Girl" with Scary Pockets.

MUSICIAN CREDITS
Lead vocal: David Ryan Harris
Drums: JJ Johnson
Bass: Sean Hurley
Organ: Lee Pardini
Keys: Will Gramling
Guitar: Ryan Lerman
BGVs: Therese Curatolo, Devin Velez, India Carney

AUDIO CREDITS
Recording Engineer/Mix: Caleb Parker

VIDEO CREDITS
Camera Operator: Ricky Chavez
Editor: Adam Kritzberg

Recorded LIVE at the Echoplex in Los Angeles, CA.

#ScaryPockets #Funk #DavidRyanHarris #prettygirl

