# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Właściciel Wikipedii walczy z władzami Rosji. Skierował pozwy do sądu
 - [https://wydarzenia.interia.pl/zagranica/news-wlasciciel-wikipedii-walczy-z-wladzami-rosji-skierowal-pozwy,nId,6808199](https://wydarzenia.interia.pl/zagranica/news-wlasciciel-wikipedii-walczy-z-wladzami-rosji-skierowal-pozwy,nId,6808199)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-05-29 15:25:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlasciciel-wikipedii-walczy-z-wladzami-rosji-skierowal-pozwy,nId,6808199"><img align="left" alt="Właściciel Wikipedii walczy z władzami Rosji. Skierował pozwy do sądu" src="https://i.iplsc.com/wlasciciel-wikipedii-walczy-z-wladzami-rosji-skierowal-pozwy/000H7OSEUC71G9VQ-C321.jpg" /></a>Fundacja Wikimedia, do której należy internetowa encyklopedia Wikipedia, nie zamierza poddać się cenzurze informacji m.in. o wojnie w Ukrainie, jaką narzucają władze Rosji. Chociaż organizacja jest karana w tym kraju kolejnymi grzywnami, zdecydowała się pozwać państwowe organy, w tym Prokuraturę Generalną. Treści pojawiające się w Wikipedii są niewygodne dla Kremla, więc proputinowscy politycy nie od dziś twierdzą, że należy zakazać dostępu do tego serwisu i stworzyć dla niego &quot;swoją&quot; alternatywę.</p><br clear="all" />

## Etna pokazała groźne oblicze. Czym grozi wybuch tego wulkanu?
 - [https://wydarzenia.interia.pl/zagranica/news-etna-pokazala-grozne-oblicze-czym-grozi-wybuch-tego-wulkanu,nId,6800026](https://wydarzenia.interia.pl/zagranica/news-etna-pokazala-grozne-oblicze-czym-grozi-wybuch-tego-wulkanu,nId,6800026)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-05-29 15:24:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-etna-pokazala-grozne-oblicze-czym-grozi-wybuch-tego-wulkanu,nId,6800026"><img align="left" alt="Etna pokazała groźne oblicze. Czym grozi wybuch tego wulkanu?" src="https://i.iplsc.com/etna-pokazala-grozne-oblicze-czym-grozi-wybuch-tego-wulkanu/000H7MHBBBK0BL09-C321.jpg" /></a>Etna to najwyższy i największy w Europie wulkan. Leżący na włoskiej Sycylii góra przyciąga tłumy turystów choć stożek jest stale aktywny, a erupcje występują niemal co roku. W ostatnich dniach Etna znowu postraszyła turystów i mieszkańców, sprawdzamy więc, czy wulkan jest groźny oraz jak wyglądały największe erupcje. Podpowiadamy również, jak zachować się podczas wybuchu wulkanu oraz co przygotować na wyjazd na Sycylię.</p><br clear="all" />

