# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## 1 dead, 4 missing after luxury fishing charter boat sinks off the coast of Alaska
 - [https://abcnews.go.com/US/1-dead-4-missing-after-luxury-fishing-charter/story?id=99680922](https://abcnews.go.com/US/1-dead-4-missing-after-luxury-fishing-charter/story?id=99680922)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 23:52:27+00:00

The Coast Guard is searching for four missing people after a charter fishing boat sank off the coast of Alaska.

## Motorist with sign claiming to have an explosive device drives to Canadian border
 - [https://abcnews.go.com/US/wireStory/motorist-sign-claiming-explosive-device-drives-canadian-border-99680730](https://abcnews.go.com/US/wireStory/motorist-sign-claiming-explosive-device-drives-canadian-border-99680730)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 21:26:09+00:00

Officials say the driver of vehicle with a sign indicating there was an explosive device on board led Maine State Police on a chase on Interstate 95 to the Canadian border

## Nevada Legislators weigh plan to put MLB stadium on Las Vegas Strip
 - [https://abcnews.go.com/Sports/wireStory/nevada-legislators-weigh-plan-put-mlb-stadium-las-99680436](https://abcnews.go.com/Sports/wireStory/nevada-legislators-weigh-plan-put-mlb-stadium-las-99680436)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 21:02:31+00:00

A long-awaited proposal to finance a Major League Baseball stadium on the Las Vegas Strip is scheduled for its first public hearing at the Nevada Legislature

## Teenage girl in Guyana charged as adult with 19 counts of murder in dormitory fire
 - [https://abcnews.go.com/International/wireStory/teenage-girl-guyana-charged-adult-19-counts-murder-99679102](https://abcnews.go.com/International/wireStory/teenage-girl-guyana-charged-adult-19-counts-murder-99679102)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 20:45:01+00:00

A teenage student who police in Guyana accuse of deliberately setting a fire in a girl&rsquo;s dormitory that killed 18 schoolmates and a five-year-old boy has been charged as an adult with 19 counts of murder

## UAE announces groundbreaking mission to asteroid belt, seeking clues to life's origins
 - [https://abcnews.go.com/Technology/wireStory/uae-announces-groundbreaking-mission-asteroid-belt-seeking-clues-99679742](https://abcnews.go.com/Technology/wireStory/uae-announces-groundbreaking-mission-asteroid-belt-seeking-clues-99679742)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 20:43:58+00:00

The United Arab Emirates has unveiled plans to send a spaceship to explore the galaxy&rsquo;s main asteroid belt, the latest space project by the oil-rich nation after it launched the successful Hope spacecraft to Mars in 2020

## Police: Puerto Rico assailants targeting drug rival killed 2 and injured 13
 - [https://abcnews.go.com/International/wireStory/police-puerto-rico-assailants-targeting-drug-rival-killed-99680125](https://abcnews.go.com/International/wireStory/police-puerto-rico-assailants-targeting-drug-rival-killed-99680125)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 20:38:51+00:00

Authorities in Puerto Rico say that drug trafficking was behind a mass shooting over the weekend outside a bar that killed two people and injured 13 others

## 2 inmates escape from jail weeks after 4 others broke out from same facility
 - [https://abcnews.go.com/US/2-inmates-escape-mississippi-jail-weeks-after-4/story?id=99678616](https://abcnews.go.com/US/2-inmates-escape-mississippi-jail-weeks-after-4/story?id=99678616)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 19:22:46+00:00

Two inmates allegedly escaped from a Mississippi jail on Monday, weeks after four others broke out from the same facility.

## What is fungal meningitis? Two Americans die from infection contracted in Mexico
 - [https://abcnews.go.com/Health/fungal-meningitis-after-2-americans-die-infection-contracted/story?id=99673644](https://abcnews.go.com/Health/fungal-meningitis-after-2-americans-die-infection-contracted/story?id=99673644)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 19:02:45+00:00

At least 17 suspected and confirmed cases and 2 deaths are linked to a fungal meningitis outbreak at clinics in Mexico. Here's what you need to know about the infection.

## Horse racing authority calls for emergency summit with Churchill Downs in wake of 12 deaths
 - [https://abcnews.go.com/Sports/wireStory/horse-racing-authority-calls-emergency-summit-churchill-downs-99678346](https://abcnews.go.com/Sports/wireStory/horse-racing-authority-calls-emergency-summit-churchill-downs-99678346)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 18:06:56+00:00

Horse racing&rsquo;s oversight authority will hold an emergency summit with Churchill Downs, Kentucky&rsquo;s racing commission and HISA veterinary teams to review information and analysis in the wake of 12 horse fatalities the past month at the home of the Kentuc...

## Debt ceiling timeline: What's next as lawmakers race to pass deal, prevent default
 - [https://abcnews.go.com/Politics/debt-ceiling-timeline-lawmakers-race-pass-deal-prevent/story?id=99674161](https://abcnews.go.com/Politics/debt-ceiling-timeline-lawmakers-race-pass-deal-prevent/story?id=99674161)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 18:06:55+00:00

Lawmakers have one week to pass a debt ceiling bill in Congress before the predicted June 5 "X-date" for default

## South America's presidents gather in Brazil for first regional summit in 9 years
 - [https://abcnews.go.com/International/wireStory/south-americans-presidents-gather-brazil-regional-summit-9-99674504](https://abcnews.go.com/International/wireStory/south-americans-presidents-gather-brazil-regional-summit-9-99674504)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 17:18:16+00:00

South America&rsquo;s leaders will gather in Brazil&rsquo;s capital on Tuesday as part of President Luiz In&aacute;cio Lula da Silva&rsquo;s attempt to reinvigorate regional integration efforts that have in the past floundered amid the continent&rsquo;s political swings and polariza...

## Josef Newgarden finally relishes an Indy 500 win after so many disappointments
 - [https://abcnews.go.com/Sports/wireStory/josef-newgarden-finally-relishes-indy-500-win-after-99676665](https://abcnews.go.com/Sports/wireStory/josef-newgarden-finally-relishes-indy-500-win-after-99676665)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 17:02:40+00:00

Josef Newgarden walked around Indianapolis Motor Speedway on Monday as the Indy 500 champion

## What 5 more years of Erdogan's rule means for Turkey
 - [https://abcnews.go.com/International/wireStory/5-years-erdogans-rule-means-turkey-99676263](https://abcnews.go.com/International/wireStory/5-years-erdogans-rule-means-turkey-99676263)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 16:54:36+00:00

Turkish President Recep Tayyip Erdogan won reelection in a runoff Sunday, following a nail-biter first round two weeks earlier

## Libyan court sentences 23 suspected Islamic State militants to death
 - [https://abcnews.go.com/International/wireStory/libyan-court-sentences-23-suspected-islamic-state-militants-99676165](https://abcnews.go.com/International/wireStory/libyan-court-sentences-23-suspected-islamic-state-militants-99676165)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 16:53:05+00:00

A Libyan court has sentenced 23 suspected Islamic State group militants to death for launching deadly attacks that killed dozens of people, including Egyptian Coptic Christians

## Biden marks Memorial Day nearly 2 years after ending America's longest war
 - [https://abcnews.go.com/Politics/wireStory/biden-marks-memorial-day-2-years-after-ending-99675728](https://abcnews.go.com/Politics/wireStory/biden-marks-memorial-day-2-years-after-ending-99675728)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 16:24:30+00:00

Biden said Americans &quot;must never forget the price that was paid&quot; by troops.

## High school student in Italy wounds teacher with hunting knife, waves toy gun
 - [https://abcnews.go.com/International/wireStory/high-school-student-italy-wounds-teacher-hunting-knife-99673753](https://abcnews.go.com/International/wireStory/high-school-student-italy-wounds-teacher-hunting-knife-99673753)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 14:06:44+00:00

Police in Italy say a high-school student wounded his teacher with a hunting knife and brandished what turned out to be a toy gun at classmates

## South African president appoints judge to oversee weapons-for-Russia inquiry
 - [https://abcnews.go.com/International/wireStory/south-african-president-appoints-judge-oversee-weapons-russia-99672763](https://abcnews.go.com/International/wireStory/south-african-president-appoints-judge-oversee-weapons-russia-99672763)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 13:31:39+00:00

South African President Cyril Ramaphosa has appointed a judge to oversee an inquiry into allegations that the country supplied arms to Russia on a ship that docked secretly at a naval base in December

## Saudi Arabia executes 2 Bahraini men over militant activities
 - [https://abcnews.go.com/International/wireStory/saudi-arabia-executes-2-bahraini-men-militant-activities-99671931](https://abcnews.go.com/International/wireStory/saudi-arabia-executes-2-bahraini-men-militant-activities-99671931)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 13:02:48+00:00

Saudi Arabia says it executed two Bahraini men after being convicted of belonging to a militant group wanting to destabilize the two Mideast kingdoms

## Russia issues arrest warrant for Lindsey Graham over Ukraine comments
 - [https://abcnews.go.com/US/wireStory/russia-issues-arrest-warrant-lindsey-graham-ukraine-comments-99670463](https://abcnews.go.com/US/wireStory/russia-issues-arrest-warrant-lindsey-graham-ukraine-comments-99670463)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 10:54:33+00:00

Russia has moved to open a criminal inquiry against Graham.

## Why State Farm won't be accepting applications for homeowners insurance in California
 - [https://abcnews.go.com/US/state-farm-longer-accept-applications-homeowners-insurance-california/story?id=99660740](https://abcnews.go.com/US/state-farm-longer-accept-applications-homeowners-insurance-california/story?id=99660740)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 10:24:23+00:00

One of the largest and most reputable insurance agencies in the company will no longer be accepting applications for home and business insurance in California.

## Uganda's president signs anti-LGBTQ bill into law
 - [https://abcnews.go.com/International/uganda-president-signs-anti-lgbtq-bill-law/story?id=99669794](https://abcnews.go.com/International/uganda-president-signs-anti-lgbtq-bill-law/story?id=99669794)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 10:01:13+00:00

Ugandan President Yoweri Museveni signed one of the world's harshest anti-LGBTQ bills into law on Monday.

## Malaysia detains Chinese barge on suspicion of looting WWII British warship wrecks
 - [https://abcnews.go.com/International/wireStory/malaysia-detains-chinese-barge-suspicion-looting-wwii-british-99669458](https://abcnews.go.com/International/wireStory/malaysia-detains-chinese-barge-suspicion-looting-wwii-british-99669458)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 09:50:17+00:00

Malaysia&rsquo;s maritime agency says it has detained a Chinese-registered vessel on suspicion of looting two British warship wrecks in the South China Sea

## UN warns of starvation risk in Sudan, Haiti, Burkina Faso and Mali, call for aid
 - [https://abcnews.go.com/US/wireStory/agencies-warn-starvation-risk-sudan-haiti-burkina-faso-99669695](https://abcnews.go.com/US/wireStory/agencies-warn-starvation-risk-sudan-haiti-burkina-faso-99669695)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 09:26:43+00:00

Two U.N. agencies are warning of rising food emergencies including starvation in Sudan due to the outbreak of war and in Haiti, Burkina Faso and Mali due to restricted movements of people and goods

## UN talks on a treaty to end global plastic pollution open in Paris
 - [https://abcnews.go.com/International/wireStory/talks-treaty-end-global-plastic-pollution-open-paris-99669317](https://abcnews.go.com/International/wireStory/talks-treaty-end-global-plastic-pollution-open-paris-99669317)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 08:17:03+00:00

A United Nations committee is meeting in Paris to work on what is intended to be a landmark treaty to bring an end to global plastic pollution, but there is little agreement on what the outcome should be

## Building partially collapses in Davenport, Iowa; potential injuries not immediately known
 - [https://abcnews.go.com/US/wireStory/building-partially-collapses-davenport-iowa-potential-injuries-immediately-99666884](https://abcnews.go.com/US/wireStory/building-partially-collapses-davenport-iowa-potential-injuries-immediately-99666884)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 03:17:36+00:00

It was not known if there were any injuries or deaths, or if anyone was trapped.

## Texas passes sexual conduct bill drag show artists fear will prompt crackdown
 - [https://abcnews.go.com/US/wireStory/texas-passes-sexual-conduct-bill-drag-show-artists-99666705](https://abcnews.go.com/US/wireStory/texas-passes-sexual-conduct-bill-drag-show-artists-99666705)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 03:16:49+00:00

The bill expands what is considered an illegal performance of sexual conduct.

## North Korea notifies neighboring Japan it plans to launch satellite in coming days
 - [https://abcnews.go.com/International/wireStory/north-korea-tells-neighboring-japan-plans-launch-satellite-99666518](https://abcnews.go.com/International/wireStory/north-korea-tells-neighboring-japan-plans-launch-satellite-99666518)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 02:17:12+00:00

It may be an attempt to put a military reconnaissance satellite into orbit.

## Suspect arrested in 5 separate shootings in Phoenix metro area that left 4 dead
 - [https://abcnews.go.com/US/wireStory/police-suspect-arrested-5-separate-shootings-arizonas-phoenix-99666340](https://abcnews.go.com/US/wireStory/police-suspect-arrested-5-separate-shootings-arizonas-phoenix-99666340)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 02:17:11+00:00

The shootings in the Phoenix area left four people dead and a woman wounded.

## Key questions and takeaways from the debt ceiling deal
 - [https://abcnews.go.com/Politics/key-questions-takeaways-debt-ceiling-deal/story?id=99660552](https://abcnews.go.com/Politics/key-questions-takeaways-debt-ceiling-deal/story?id=99660552)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 02:03:54+00:00

Biden and McCarthy have reached a debt ceiling bill: What's in it and when does it need to pass to prevent a default?

## George Maharis, star of TV's 'Route 66' in the 1960s, dies at 94
 - [https://abcnews.go.com/Entertainment/wireStory/george-maharis-star-tvs-route-66-1960s-dies-99665462](https://abcnews.go.com/Entertainment/wireStory/george-maharis-star-tvs-route-66-1960s-dies-99665462)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-05-29 00:01:29+00:00

The handsome actor became an icon to American youth on the hit 1960s series.

