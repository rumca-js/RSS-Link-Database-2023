# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## „Bezpieczne dzieci w sieci” – bezpłatne super szkolenie dla rodziców (i nie tylko!)
 - [https://sekurak.pl/bezpieczne-dzieci-w-sieci-bezplatne-super-szkolenie-dla-rodzicow-i-nie-tylko/](https://sekurak.pl/bezpieczne-dzieci-w-sieci-bezplatne-super-szkolenie-dla-rodzicow-i-nie-tylko/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-05-29 07:48:04+00:00

<p>TLDR: prowadzimy bezpłatne 2-godzinne szkolenie o cyberbezpieczeństwie (on-line) &#8211; agenda i zapisy tutaj. Wakacje zbliżają się wielkimi krokami. Dla dzieci to czas odpoczynku i zabawy, ale dla rodziców i opiekunów czas, w którym dzieci mogą być narażone na dodatkowe zagrożenia. Warto je znać, być na bieżąco i wiedzieć jak im...</p>
<p>Artykuł <a href="https://sekurak.pl/bezpieczne-dzieci-w-sieci-bezplatne-super-szkolenie-dla-rodzicow-i-nie-tylko/" rel="nofollow">„Bezpieczne dzieci w sieci” – bezpłatne super szkolenie dla rodziców (i nie tylko!)</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

