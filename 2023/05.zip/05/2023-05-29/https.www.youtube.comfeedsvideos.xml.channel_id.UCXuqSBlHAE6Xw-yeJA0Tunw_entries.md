# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## NVIDIA Made a CPU.. I’m Holding It.
 - [https://www.youtube.com/watch?v=It9D08W8Z7o](https://www.youtube.com/watch?v=It9D08W8Z7o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-05-29 20:34:09+00:00

Try Pulseway FREE today, and make IT monitoring simple at: https://lmg.gg/LTT23

I'm at the Gigabyte booth at Computex 2023 where they're showing off bonkers new hardware from Nvidia! 

Discuss on the forum: https://linustechtips.com/topic/1509962-nvidia-made-a-cpu-i%E2%80%99m-holding-it-computex-2023/

Immersion tank 1 A1P0-EB0 (rev. 100) :https://www.gigabyte.com/Enterprise/Accessory/A1P0-EB0-rev-200#Specifications
Immersion tank 2 A1O3-CC0 (rev. 100): https://www.gigabyte.com/Enterprise/Accessory/A1O3-CC0-rev-100
Big AI server (h100) - G593-SD0 (rev. AAX1): https://www.gigabyte.com/Enterprise/GPU-Server/G593-SD0-rev-AAX1

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► EQUIPMENT WE USE TO FILM LTT: https://lmg.gg/LTTEquipment
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:22 Meet the Grace Super Chip!
1:22 We got permission for this...
3:13 ..but not for this.
4:40 Now for the GPU!
6:13 That's where the Interconnect comes in
7:32 There's "old-fashioned GPUs" too
8:35 Crazy network card
11:00 outro

