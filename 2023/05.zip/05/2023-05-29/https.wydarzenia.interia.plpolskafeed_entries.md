# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## "Wieś wie, ale wieś milczy". Co naprawdę wydarzyło się w Tłokini Wielkiej?
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-wies-wie-ale-wies-milczy-co-naprawde-wydarzylo-sie-w-tlokini,nId,6807819](https://wydarzenia.interia.pl/tylko-w-interii/news-wies-wie-ale-wies-milczy-co-naprawde-wydarzylo-sie-w-tlokini,nId,6807819)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-05-29 09:02:03+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-wies-wie-ale-wies-milczy-co-naprawde-wydarzylo-sie-w-tlokini,nId,6807819"><img align="left" alt="&quot;Wieś wie, ale wieś milczy&quot;. Co naprawdę wydarzyło się w Tłokini Wielkiej?" src="https://i.iplsc.com/wies-wie-ale-wies-milczy-co-naprawde-wydarzylo-sie-w-tlokini/000H7MY6R7P124H3-C321.jpg" /></a>Piotr Mikołajczyk to dorosły mężczyzna o umyśle 10-letniego chłopca. Ma IQ 62 i według śledczych popełnił zbrodnię doskonałą. Od 12 lat odsiaduje wyrok za brutalne zabójstwo dwóch kobiet - Bronisławy J. i jej córki Moniki - mimo że nie znaleziono żadnych dowodów świadczących o jego winie. Dzisiaj w Interii wstrząsający reportaż Dawida Serafina &quot;Skazany za niewinność&quot;. </p><br clear="all" />

## Przykra "niespodzianka" z kranu. "Dzieci kąpię u teściowej"
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-przykra-niespodzianka-z-kranu-dzieci-kapie-u-tesciowej,nId,6802479](https://wydarzenia.interia.pl/tylko-w-interii/news-przykra-niespodzianka-z-kranu-dzieci-kapie-u-tesciowej,nId,6802479)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-05-29 07:53:00+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-przykra-niespodzianka-z-kranu-dzieci-kapie-u-tesciowej,nId,6802479"><img align="left" alt="Przykra &quot;niespodzianka&quot; z kranu. &quot;Dzieci kąpię u teściowej&quot;" src="https://i.iplsc.com/przykra-niespodzianka-z-kranu-dzieci-kapie-u-tesciowej/000H79Y99BVFH58S-C321.jpg" /></a>Płacimy za dobrą wodę, a niestety leci syf - skarżą się w rozmowie z Interią mieszkańcy gminy Obrowo (woj. kujawsko-pomorskie). Po ostatniej awarii sieci wodociągowej z kranów leciała ciecz o kolorze whisky. Do tego zdarza się, że woda śmierdzi zgniłymi jajami. Urzędnicy zapewniają, że problemy są chwilowe, ale nie przekonuje to mieszkańców. - Dzieci kąpię u teściowej, która mieszka w innej gminie. Stamtąd też zwozimy wodę w baniakach do domu. Absolutnie tego co leci u nas z kranu nie pijemy - mówi Interii Emilia.</p><br clear="all" />

## Oświadczenie prezydenta Andrzeja Dudy. Podpisze ustawę o badaniu rosyjskich wpływów
 - [https://wydarzenia.interia.pl/kraj/news-oswiadczenie-prezydenta-andrzeja-dudy-podpisze-ustawe-o-bada,nId,6807729](https://wydarzenia.interia.pl/kraj/news-oswiadczenie-prezydenta-andrzeja-dudy-podpisze-ustawe-o-bada,nId,6807729)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-05-29 06:50:10+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-oswiadczenie-prezydenta-andrzeja-dudy-podpisze-ustawe-o-bada,nId,6807729"><img align="left" alt="Oświadczenie prezydenta Andrzeja Dudy. Podpisze ustawę o badaniu rosyjskich wpływów" src="https://i.iplsc.com/oswiadczenie-prezydenta-andrzeja-dudy-podpisze-ustawe-o-bada/000H7MCH53WE94RL-C321.jpg" /></a>Prezydent Andrzej Duda poinformował, że podpisze ustawę o powołaniu komisji do spraw wpływów rosyjskich. To tzw. lex Tusk. Jednocześnie prezydent poinformował, że skieruje ustawę w trybie następczym do Trybunału Konstytucyjnego.  - Nie jest dla nikogo tajemnicą, że Rosja przez wiele lat próbowała wpływać na politykę wielu krajów - powiedział. - Uczciwi ludzie, którzy rzeczywiście działali w interesie Rzeczpospolitej Polskiej nie mają niczego do ukrycia i niczego nie muszą się obawiać - dodał.</p><br clear="all" />

