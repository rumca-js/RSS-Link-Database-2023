# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Galaxy S23 FE – wiemy, jaki procesor dostanie smartfon Samsunga
 - [https://ithardware.pl/aktualnosci/galaxy_s23_fe_wiemy_jaki_procesor_dostanie_smartfon_samsunga-27526.html](https://ithardware.pl/aktualnosci/galaxy_s23_fe_wiemy_jaki_procesor_dostanie_smartfon_samsunga-27526.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 21:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/27526_1.jpg" />            Samsung Galaxy S23 FE stanowi wielką zagadkę, bo nie wiadomo czy i kiedy zadebiutuje. Plotki sprzed paru miesięcy sugerowały, że producent z Korei Południowej wyda op&oacute;źnionego Galaxy S22 FE. Tymczasem teraz ujawniono procesor, jaki ma...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/galaxy_s23_fe_wiemy_jaki_procesor_dostanie_smartfon_samsunga-27526.html">https://ithardware.pl/aktualnosci/galaxy_s23_fe_wiemy_jaki_procesor_dostanie_smartfon_samsunga-27526.html</a></p>

## Seria gier Wiedźmin odnosi olbrzymi sukces. CD Projekt ujawnia dane
 - [https://ithardware.pl/aktualnosci/seria_gier_wiedzmin_odnosi_olbrzymi_sukces_cd_projekt_ujawnia_dane-27524.html](https://ithardware.pl/aktualnosci/seria_gier_wiedzmin_odnosi_olbrzymi_sukces_cd_projekt_ujawnia_dane-27524.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 19:01:30+00:00

<img src="https://ithardware.pl/artykuly/min/27524_1.jpg" />            Seria gier Wiedźmin pozwala generować firmie CD Projekt krocie, na co wskazują nowe oficjalne dane. Polska marka pod względem sprzedażnych egzemplarzy zbliża się do kamienia milowego.

Seria gier Wiedźmin odnosi sukces. CD Projekt ujawnia dane...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/seria_gier_wiedzmin_odnosi_olbrzymi_sukces_cd_projekt_ujawnia_dane-27524.html">https://ithardware.pl/aktualnosci/seria_gier_wiedzmin_odnosi_olbrzymi_sukces_cd_projekt_ujawnia_dane-27524.html</a></p>

## Podsumowanie newsów ITHardware - tydzień 107. Sprawdź co Cię ominęło
 - [https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_sto_siodmy_maj_2023-27523.html](https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_sto_siodmy_maj_2023-27523.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 17:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/27523_1.jpg" />            Jak co tydzień zapraszamy naszych czytelnik&oacute;w do odwiedzenia kanału&nbsp;ITHardware&nbsp;na YouTube i do zapoznania się z materiałem prezentującym najważniejsze wydarzenia minionych 7 dni.

Za powstanie wideo odpowiada&nbsp;nasz redakcyjny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_sto_siodmy_maj_2023-27523.html">https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_sto_siodmy_maj_2023-27523.html</a></p>

## Twitter opuści Unię Europejską? Elon Musk nie chce się dostosować do zasad
 - [https://ithardware.pl/aktualnosci/twitter_opusci_unie_europejska_elon_musk_nie_chce_sie_dostosowac_do_zasad-27522.html](https://ithardware.pl/aktualnosci/twitter_opusci_unie_europejska_elon_musk_nie_chce_sie_dostosowac_do_zasad-27522.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 16:53:50+00:00

<img src="https://ithardware.pl/artykuly/min/27522_1.jpg" />            Twitter wycofał się z dobrowolnego unijnego kodeksu walki z dezinformacją, poinformowała Unia Europejska.&nbsp;Thierry Breton, kt&oacute;ry jest komisarzem UE ds. rynku wewnętrznego ostrzegł jednak, że nowe przepisy wymuszają dostosowanie się to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/twitter_opusci_unie_europejska_elon_musk_nie_chce_sie_dostosowac_do_zasad-27522.html">https://ithardware.pl/aktualnosci/twitter_opusci_unie_europejska_elon_musk_nie_chce_sie_dostosowac_do_zasad-27522.html</a></p>

## Twitter opuści Unię Europejską? Taki scenariusz jest możliwy
 - [https://ithardware.pl/aktualnosci/twitter_opusci_unie_europejska_taki_scenariusz_jest_mozliwy-27522.html](https://ithardware.pl/aktualnosci/twitter_opusci_unie_europejska_taki_scenariusz_jest_mozliwy-27522.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 16:53:50+00:00

<img src="https://ithardware.pl/artykuly/min/27522_1.jpg" />            Twitter wycofał się z unijnego kodeksu walki z dezinformacją, poinformowała Unia Europejska.&nbsp;Thierry Breton, kt&oacute;ry jest komisarzem UE ds. rynku wewnętrznego ostrzegł jednak, że nowe przepisy wymuszą&nbsp;dostosowanie się to tej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/twitter_opusci_unie_europejska_taki_scenariusz_jest_mozliwy-27522.html">https://ithardware.pl/aktualnosci/twitter_opusci_unie_europejska_taki_scenariusz_jest_mozliwy-27522.html</a></p>

## Test i recenzja Lenovo Tab P11 (2. Gen). Tablety jeszcze nie powiedziały "do widzenia"
 - [https://ithardware.pl/testyirecenzje/test_i_recenzja_lenovo_tab_p11_2_gen_tablety_jeszcze_nie_powiedzialy_do_widzenia-27520.html](https://ithardware.pl/testyirecenzje/test_i_recenzja_lenovo_tab_p11_2_gen_tablety_jeszcze_nie_powiedzialy_do_widzenia-27520.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 15:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/27520_1.jpg" />            To ciągle można jeszcze kupić tablety? Dla wielu os&oacute;b to pewnie spore zaskoczenie, bo od lat słuchamy przecież, że nie miały szans w starciu ze smartfonami. I choć jest w tym dużo prawdy, do czego przyczynili się sami producenci, robiąc...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/test_i_recenzja_lenovo_tab_p11_2_gen_tablety_jeszcze_nie_powiedzialy_do_widzenia-27520.html">https://ithardware.pl/testyirecenzje/test_i_recenzja_lenovo_tab_p11_2_gen_tablety_jeszcze_nie_powiedzialy_do_widzenia-27520.html</a></p>

## Unia Europejska ujawnia, jak wygląda sprzedaż konsol Xbox i PlayStation
 - [https://ithardware.pl/aktualnosci/unia_europejska_ujawnia_jak_wyglada_sprzedaz_konsol_xbox_i_playstation-27521.html](https://ithardware.pl/aktualnosci/unia_europejska_ujawnia_jak_wyglada_sprzedaz_konsol_xbox_i_playstation-27521.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 14:46:47+00:00

<img src="https://ithardware.pl/artykuly/min/27521_1.jpg" />            Komisja Europejska dała pozwolenie na przejęcie Activision Blizzard przez Microsoft wskazując, że firma z Redmond wdroży odpowiednie rozwiązania w kwestii platformy do grania w chmurze, dzięki czemu całość nie wpłynie negatywnie na cały...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/unia_europejska_ujawnia_jak_wyglada_sprzedaz_konsol_xbox_i_playstation-27521.html">https://ithardware.pl/aktualnosci/unia_europejska_ujawnia_jak_wyglada_sprzedaz_konsol_xbox_i_playstation-27521.html</a></p>

## CD Projekt RED zostanie przejęty przez Sony? Przedstawicielka polskiego studia odpowiada
 - [https://ithardware.pl/aktualnosci/cd_projekt_red_zostanie_przejety_przez_sony_przedstawicielka_polskiego_studia_odpowiada-27519.html](https://ithardware.pl/aktualnosci/cd_projekt_red_zostanie_przejety_przez_sony_przedstawicielka_polskiego_studia_odpowiada-27519.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 13:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/27519_1.jpg" />            Ostatnio pojawiła się zaskakująca informacja jakoby Sony prowadziło rozmowy z autorami Wiedźmina 3: Dziki Gon oraz Cyberpunka 2077 studiem CD Projekt RED i poważnie przymierzało się do jego kupna. Teraz do tej plotki odniosła się na Twitterze...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cd_projekt_red_zostanie_przejety_przez_sony_przedstawicielka_polskiego_studia_odpowiada-27519.html">https://ithardware.pl/aktualnosci/cd_projekt_red_zostanie_przejety_przez_sony_przedstawicielka_polskiego_studia_odpowiada-27519.html</a></p>

## Chiński gigant przeżywa kryzys. Dochody Lenovo spadły aż o 75%
 - [https://ithardware.pl/aktualnosci/chinski_gigant_przezywa_kryzys_dochody_lenovo_spadly_az_o_75-27513.html](https://ithardware.pl/aktualnosci/chinski_gigant_przezywa_kryzys_dochody_lenovo_spadly_az_o_75-27513.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 10:41:01+00:00

<img src="https://ithardware.pl/artykuly/min/27513_1.jpg" />            Rynek komputer&oacute;w PC odczuwa postpandemicznego kaca, ponieważ klienci nie muszą już tak często aktualizować swoich maszyn, jak to miało miejsce w ostatnich latach. Tempo wymiany sprzętu mocno zwolniło, co ma duży wpływ na wyniki...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chinski_gigant_przezywa_kryzys_dochody_lenovo_spadly_az_o_75-27513.html">https://ithardware.pl/aktualnosci/chinski_gigant_przezywa_kryzys_dochody_lenovo_spadly_az_o_75-27513.html</a></p>

## Test ASUS ProArt X670E-CREATOR WIFI. Bogatszej funkcjonalności ze świecą szukać
 - [https://ithardware.pl/testyirecenzje/asus_proart_x670e_creator_wifi_test_recenzja_opinia-27475.html](https://ithardware.pl/testyirecenzje/asus_proart_x670e_creator_wifi_test_recenzja_opinia-27475.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 10:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/27475_1.jpg" />            ASUS ProArt X670E-CREATOR WIFI - test

Tematem przewodnim dzisiejszego testu będzie następna płyta gł&oacute;wna dla procesor&oacute;w Ryzen 7000, a konkretnie ASUS ProArt X670E-CREATOR WIFI. Jest to model na topowym chipsecie AMD X670E, od strony...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/asus_proart_x670e_creator_wifi_test_recenzja_opinia-27475.html">https://ithardware.pl/testyirecenzje/asus_proart_x670e_creator_wifi_test_recenzja_opinia-27475.html</a></p>

## John Wick 5 nadchodzi, a wraz z nim gra AAA, spin-offy i Ana de Armas
 - [https://ithardware.pl/aktualnosci/john_wick_5_nadchodzi_a_wraz_z_nim_gra_aaa_spin_offy_i_ana_de_armas-27518.html](https://ithardware.pl/aktualnosci/john_wick_5_nadchodzi_a_wraz_z_nim_gra_aaa_spin_offy_i_ana_de_armas-27518.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 09:41:20+00:00

<img src="https://ithardware.pl/artykuly/min/27518_1.jpg" />            Przedstawiciel studia produkcyjnego Lionsgate poinformował niedawno, że pomimo zakończenia kinowej premiery filmu &quot;John Wick: Rozdział 4&quot;, trwają prace nad kontynuacją. Podczas rozmowy dotyczącej wynik&oacute;w finansowych&nbsp;prezes...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/john_wick_5_nadchodzi_a_wraz_z_nim_gra_aaa_spin_offy_i_ana_de_armas-27518.html">https://ithardware.pl/aktualnosci/john_wick_5_nadchodzi_a_wraz_z_nim_gra_aaa_spin_offy_i_ana_de_armas-27518.html</a></p>

## To może być kolejny cios dla Huawei. Portugalia rozważa zbanowanie firmy
 - [https://ithardware.pl/aktualnosci/to_moze_byc_kolejny_cios_dla_huawei_portugalia_rozwaza_zbanowanie_firmy-27514.html](https://ithardware.pl/aktualnosci/to_moze_byc_kolejny_cios_dla_huawei_portugalia_rozwaza_zbanowanie_firmy-27514.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 09:14:00+00:00

<img src="https://ithardware.pl/artykuly/min/27514_1.jpg" />            Portugalia może stać się kolejnym krajem, kt&oacute;ry skutecznie zbanuje Huawei i inne chińskie firmy biorące udział w budowaniu sieci 5G.&nbsp;

Jak donosi agencja Bloomberg, rząd Portugalii w zeszłym tygodniu zalecił zakazanie lokalnym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/to_moze_byc_kolejny_cios_dla_huawei_portugalia_rozwaza_zbanowanie_firmy-27514.html">https://ithardware.pl/aktualnosci/to_moze_byc_kolejny_cios_dla_huawei_portugalia_rozwaza_zbanowanie_firmy-27514.html</a></p>

## ASRock zdradza, że Intel szykuje nowe CPU o wyższym poborze mocy dla LGA 1700
 - [https://ithardware.pl/aktualnosci/asrock_zdradza_ze_intel_szykuje_nowe_cpu_o_wyzszym_poborze_mocy_dla_lga_1700-27511.html](https://ithardware.pl/aktualnosci/asrock_zdradza_ze_intel_szykuje_nowe_cpu_o_wyzszym_poborze_mocy_dla_lga_1700-27511.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 08:36:50+00:00

<img src="https://ithardware.pl/artykuly/min/27511_1.jpg" />            Jak sugeruje ASRock, Intel może przygotowywać nowe procesory do komputer&oacute;w stacjonarnych dla swojej platformy LGA 1700, kt&oacute;re wymagać będą jeszcze więcej mocy.&nbsp;

ASRock Phantom Gaming Z790 Nova WiFi

ASRock przygotowuje trzy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/asrock_zdradza_ze_intel_szykuje_nowe_cpu_o_wyzszym_poborze_mocy_dla_lga_1700-27511.html">https://ithardware.pl/aktualnosci/asrock_zdradza_ze_intel_szykuje_nowe_cpu_o_wyzszym_poborze_mocy_dla_lga_1700-27511.html</a></p>

## Unia Europejska: Identyfikator cyfrowy dla wszystkich do 2030 roku
 - [https://ithardware.pl/aktualnosci/unia_europejska_identyfikator_cyfrowy_dla_wszystkich_do_2030_roku-27516.html](https://ithardware.pl/aktualnosci/unia_europejska_identyfikator_cyfrowy_dla_wszystkich_do_2030_roku-27516.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 07:45:40+00:00

<img src="https://ithardware.pl/artykuly/min/27516_1.jpg" />            Wdrażanie identyfikator&oacute;w cyfrowych przyspiesza przy niewielkiej uwadze społeczności i właściwie jakimkolwiek braku sprzeciwu.&nbsp;Komisja Europejska przeznaczyła 46 mln EUR na kontrowersyjny europejski portfel tożsamości cyfrowej,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/unia_europejska_identyfikator_cyfrowy_dla_wszystkich_do_2030_roku-27516.html">https://ithardware.pl/aktualnosci/unia_europejska_identyfikator_cyfrowy_dla_wszystkich_do_2030_roku-27516.html</a></p>

## NVIDIA prezentuje G-SYNC ULMB 2: klarowność obrazu w ruchu niczym odświeżanie ponad 1000 Hz
 - [https://ithardware.pl/aktualnosci/nvidia_prezentuje_g_sync_ulmb_2_klarownosc_obrazu_w_ruchu_niczym_odswiezanie_ponad_1000_hz-27515.html](https://ithardware.pl/aktualnosci/nvidia_prezentuje_g_sync_ulmb_2_klarownosc_obrazu_w_ruchu_niczym_odswiezanie_ponad_1000_hz-27515.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 07:35:18+00:00

<img src="https://ithardware.pl/artykuly/min/27515_1.jpg" />            NVIDIA właśnie zaprezentowała technologię G-SYNC ULMB (Ultra Low Motion Blur) drugiej generacji, kt&oacute;ra zapewnia efektywną klarowność ruchu na poziomie odświeżania wynoszącego 1000 Hz. Technika ta jest już dostępna.&nbsp;

G-SYNC ULMB...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_prezentuje_g_sync_ulmb_2_klarownosc_obrazu_w_ruchu_niczym_odswiezanie_ponad_1000_hz-27515.html">https://ithardware.pl/aktualnosci/nvidia_prezentuje_g_sync_ulmb_2_klarownosc_obrazu_w_ruchu_niczym_odswiezanie_ponad_1000_hz-27515.html</a></p>

## NVIDIA prezentuje superkomputer DGX GH200 napędzany przez 256 superchipów Grace Hopper
 - [https://ithardware.pl/aktualnosci/nvidia_prezentuje_superkomputer_dgx_gh200_napedzany_przez_256_superchipow_grace_hopper-27510.html](https://ithardware.pl/aktualnosci/nvidia_prezentuje_superkomputer_dgx_gh200_napedzany_przez_256_superchipow_grace_hopper-27510.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 07:07:37+00:00

<img src="https://ithardware.pl/artykuly/min/27510_1.jpg" />            GPU NVIDIA GH200 Hopper został właśnie ujawniony dla Grace Hopper Superchips i będzie napędzał systemy HGX.

NVIDIA GH200 Grace Hopper Superchip

NVIDIA ogłosiła dzisiaj, że układ NVIDIA GH200 Grace Hopper Superchip znajduje się w fazie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_prezentuje_superkomputer_dgx_gh200_napedzany_przez_256_superchipow_grace_hopper-27510.html">https://ithardware.pl/aktualnosci/nvidia_prezentuje_superkomputer_dgx_gh200_napedzany_przez_256_superchipow_grace_hopper-27510.html</a></p>

## Kup wybrany laptop MSI i otrzymaj Microsoft 365 Personal oraz rok dodatkowej gwarancji
 - [https://ithardware.pl/aktualnosci/kup_wybrany_laptop_msi_i_otrzymaj_microsoft_365_personal_oraz_rok_dodatkowej_gwarancji-27509.html](https://ithardware.pl/aktualnosci/kup_wybrany_laptop_msi_i_otrzymaj_microsoft_365_personal_oraz_rok_dodatkowej_gwarancji-27509.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 06:40:40+00:00

<img src="https://ithardware.pl/artykuly/min/27509_1.jpg" />            MSI startuje z nową promocją, w ramach kt&oacute;rej osoby decydujące się na zakup wybranych laptop&oacute;w z rodziny Content Creation lub Business &amp; Productivity, otrzymają gratis usługę Microsoft 365 Personal oraz dodatkowy rok gwarancji na...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kup_wybrany_laptop_msi_i_otrzymaj_microsoft_365_personal_oraz_rok_dodatkowej_gwarancji-27509.html">https://ithardware.pl/aktualnosci/kup_wybrany_laptop_msi_i_otrzymaj_microsoft_365_personal_oraz_rok_dodatkowej_gwarancji-27509.html</a></p>

## NVIDIA prezentuje przełomową technologię ACE. AI napędzać będzie dialogi NPC w grach
 - [https://ithardware.pl/aktualnosci/nvidia_prezentuje_przelomowa_technologie_ace_ai_napedzac_bedzie_dialogi_npc_w_grach-27508.html](https://ithardware.pl/aktualnosci/nvidia_prezentuje_przelomowa_technologie_ace_ai_napedzac_bedzie_dialogi_npc_w_grach-27508.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 06:07:42+00:00

<img src="https://ithardware.pl/artykuly/min/27508_1.jpg" />            Podczas dzisiejszego inauguracyjnego wystąpienia na targach Computex na Tajwanie, Jensen Huang, dyrektor generalny firmy NVIDIA, zaprezentował nową technologię dla tw&oacute;rc&oacute;w gier. Ta obejmuje wykorzystanie sztucznej inteligencji i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_prezentuje_przelomowa_technologie_ace_ai_napedzac_bedzie_dialogi_npc_w_grach-27508.html">https://ithardware.pl/aktualnosci/nvidia_prezentuje_przelomowa_technologie_ace_ai_napedzac_bedzie_dialogi_npc_w_grach-27508.html</a></p>

## NVIDIA prezentuje przełomową technologię ACE. AI napędzać będzie dialogii NPC w grach
 - [https://ithardware.pl/aktualnosci/nvidia_prezentuje_przelomowa_technologie_ace_ai_napedzac_bedzie_dialogii_npc_w_grach-27508.html](https://ithardware.pl/aktualnosci/nvidia_prezentuje_przelomowa_technologie_ace_ai_napedzac_bedzie_dialogii_npc_w_grach-27508.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-29 06:07:42+00:00

<img src="https://ithardware.pl/artykuly/min/27508_1.jpg" />            Podczas dzisiejszego inauguracyjnego wystąpienia na targach Computex na Tajwanie, Jensen Huang, dyrektor generalny firmy NVIDIA, zaprezentował nową technologię dla tw&oacute;rc&oacute;w gier. Ta obejmuje wykorzystanie sztucznej inteligencji i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_prezentuje_przelomowa_technologie_ace_ai_napedzac_bedzie_dialogii_npc_w_grach-27508.html">https://ithardware.pl/aktualnosci/nvidia_prezentuje_przelomowa_technologie_ace_ai_napedzac_bedzie_dialogii_npc_w_grach-27508.html</a></p>

