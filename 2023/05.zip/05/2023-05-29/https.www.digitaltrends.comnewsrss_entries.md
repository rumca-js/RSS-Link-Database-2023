# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Nvidia’s supercomputer may bring on a new era of ChatGPT
 - [https://www.digitaltrends.com/computing/nvidia-announces-dgx-gh200-supercomputer/](https://www.digitaltrends.com/computing/nvidia-announces-dgx-gh200-supercomputer/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2023-05-29 11:34:06.098739+00:00

Nvidia has just announced the DGX GH200, an AI supercomputer equipped with previously unseen power. It might bring big advancements to generative AI.

