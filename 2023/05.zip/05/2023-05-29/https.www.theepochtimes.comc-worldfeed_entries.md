# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## John Robson: Elite Pushback Against a Canadian Foreign Agent Registry Is a Ruse
 - [https://www.theepochtimes.com/john-robson-elite-pushback-against-a-canadian-foreign-agent-registry-is-a-ruse_5298431.html](https://www.theepochtimes.com/john-robson-elite-pushback-against-a-canadian-foreign-agent-registry-is-a-ruse_5298431.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 23:04:20+00:00

Sen. Yuen Pau Woo (R) denounces RCMP allegations of Beijing interference in Canada during a news conference in Montreal on May 5, 2023. (The Canadian Press/Ryan Remiorz)

## Plan for Fate of Crumbling 24 Sussex Expected by Fall, Minister Tells MPs
 - [https://www.theepochtimes.com/plan-for-fate-of-crumbling-24-sussex-expected-by-fall-minister-tells-mps_5298794.html](https://www.theepochtimes.com/plan-for-fate-of-crumbling-24-sussex-expected-by-fall-minister-tells-mps_5298794.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 22:25:09+00:00

A construction worker walks past the front entrance to 24 Sussex Drive in Ottawa on May 29, 2023. (The Canadian Press/Sean Kilpatrick)

## Minister Reviewing CBC’s Mandate With Eye to Making It Less Reliant on Advertising
 - [https://www.theepochtimes.com/minister-reviewing-cbcs-mandate-with-eye-to-making-it-less-reliant-on-advertising_5298778.html](https://www.theepochtimes.com/minister-reviewing-cbcs-mandate-with-eye-to-making-it-less-reliant-on-advertising_5298778.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 22:21:48+00:00

Minister of Canadian Heritage Pablo Rodriguez prepares to appear before a Senate committee on Parliament Hill in Ottawa on Nov. 22, 2022. (Justin Tang/The Canadian Press)

## Quebec, Ottawa Pledge $300 Million for GM Electric Car Battery Component Plant
 - [https://www.theepochtimes.com/quebec-ottawa-pledge-300-million-for-gm-electric-car-battery-component-plant_5298643.html](https://www.theepochtimes.com/quebec-ottawa-pledge-300-million-for-gm-electric-car-battery-component-plant_5298643.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 21:08:33+00:00

Innovation, Science, and Industry Minister Francois-Philippe Champagne responds to a question during Question Period in Ottawa on Nov. 16, 2022. (Adrian Wyld/The Canadian Press)

## NDP MP Jenny Kwan Told by CSIS She’s a Target of Beijing
 - [https://www.theepochtimes.com/ndp-mp-jenny-kwan-told-by-csis-shes-a-target-of-beijing_5298371.html](https://www.theepochtimes.com/ndp-mp-jenny-kwan-told-by-csis-shes-a-target-of-beijing_5298371.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 20:50:48+00:00

NDP MP Jenny Kwan speaks to reporters about her briefing with CSIS where they confirmed that she was a target of foreign interference, in the Foyer of the House of Commons on Parliament Hill in Ottawa, on May 29, 2023. (THE CANADIAN PRESS/Justin Tang)

## Man Pleads Guilty to Murder, Assault in BC Library Stabbing Spree
 - [https://www.theepochtimes.com/man-pleads-guilty-to-murder-assault-in-bc-library-stabbing-spree_5298574.html](https://www.theepochtimes.com/man-pleads-guilty-to-murder-assault-in-bc-library-stabbing-spree_5298574.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 20:41:23+00:00

A lady places flowers at a makeshift memorial as the RCMP give a news conference outside of the Lynn Valley Library in Lynn Valley in North Vancouver, B.C., on March 29, 2021. (The Canadian Press/Jonathan Hayward)

## BC Police Say Remains of Madison Scott, Last Seen in 2011, Have Been Found
 - [https://www.theepochtimes.com/bc-police-say-remains-of-madison-scott-last-seen-in-2011-have-been-found_5298563.html](https://www.theepochtimes.com/bc-police-say-remains-of-madison-scott-last-seen-in-2011-have-been-found_5298563.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 20:38:27+00:00

Madison Scott is shown in this undated handout photo. (The Canadian Press/HO-RCMP)

## NDP Motion Asks Johnston to Step Down as Special Rapporteur
 - [https://www.theepochtimes.com/ndp-motion-asks-johnston-to-step-down-as-special-rapporteur_5298270.html](https://www.theepochtimes.com/ndp-motion-asks-johnston-to-step-down-as-special-rapporteur_5298270.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 20:12:49+00:00

New Democratic Party leader Jagmeet Singh listens to a question from a reporter during a news conference, on Oct. 5, 2022 in Ottawa. (The Canadian Press/Adrian Wyld)

## Feds Will Introduce ‘Online Safety Bill’ by This Fall, Says Heritage Minister
 - [https://www.theepochtimes.com/feds-will-introduce-online-safety-bill-by-this-fall-says-heritage-minister_5298046.html](https://www.theepochtimes.com/feds-will-introduce-online-safety-bill-by-this-fall-says-heritage-minister_5298046.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 19:24:07+00:00

Canadian Heritage Minister Pablo Rodriguez rises during question period on Parliament Hill in Ottawa on April 28, 2023. (The Canadian Press/Adrian Wyld)

## Canada Must Strengthen the Nation-State and Stop Eroding Its Sovereignty: Brian Peckford
 - [https://www.theepochtimes.com/canada-must-strengthen-the-nation-state-and-stop-eroding-its-sovereignty-brian-peckford_5297280.html](https://www.theepochtimes.com/canada-must-strengthen-the-nation-state-and-stop-eroding-its-sovereignty-brian-peckford_5297280.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 18:04:43+00:00

Former Newfoundland and Labrador premier Brian Peckford holds a press conference on Parliament Hill in Ottawa on Sept. 19, 2012. (The Canadian Press/Adrian Wyld)

## Feds Scrap Cultural Fund That Spent Canadian Tax Dollars on Sex Toy Show
 - [https://www.theepochtimes.com/feds-scrap-cultural-fund-that-spent-canadian-tax-dollars-on-sex-toy-show_5297796.html](https://www.theepochtimes.com/feds-scrap-cultural-fund-that-spent-canadian-tax-dollars-on-sex-toy-show_5297796.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 17:44:43+00:00

Canadian dollar coins sit atop Canada's flag in a file photo. (Mark Blinch/Reuters)

## Libyan Court Sentences 23 Suspected ISIS Terrorists to Death
 - [https://www.theepochtimes.com/libyan-court-sentences-23-suspected-isis-terrorists-to-death_5297964.html](https://www.theepochtimes.com/libyan-court-sentences-23-suspected-isis-terrorists-to-death_5297964.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 16:50:47+00:00

This is a locator map for Libya with its capital, Tripoli. (AP Photo)

## When Environmental Radicalism Is More Harmful Than Good
 - [https://www.theepochtimes.com/when-environmental-radicalism-is-more-harmful-than-good_5297320.html](https://www.theepochtimes.com/when-environmental-radicalism-is-more-harmful-than-good_5297320.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 16:43:24+00:00

Signs of regrowth are seen amongst bushfire affected natives and blue gum forestry west of Parndana, Australia, on Feb. 23, 2020. (Lisa Maree Williams/Getty Images)

## High School Student in Italy Wounds Teacher With Hunting Knife, Waves Toy Gun in Class
 - [https://www.theepochtimes.com/high-school-student-in-italy-wounds-teacher-with-hunting-knife-waves-toy-gun-in-class_5297881.html](https://www.theepochtimes.com/high-school-student-in-italy-wounds-teacher-with-hunting-knife-waves-toy-gun-in-class_5297881.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 16:18:00+00:00

File photo of a police tape in Italy. (FooTToo/Shutterstock)

## Seven in Court Charged With Attempted Murder of Northern Ireland Detective
 - [https://www.theepochtimes.com/seven-in-court-charged-with-attempted-murder-of-northern-ireland-detective_5297734.html](https://www.theepochtimes.com/seven-in-court-charged-with-attempted-murder-of-northern-ireland-detective_5297734.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 15:50:31+00:00

PSNI Detective Chief Inspector John Caldwell pictured at a garden party in Northern Ireland on May 24, 2023 (Brian Lawless/PA Wire)

## Two-Thirds of Canadian Marijuana Dealers Falling Behind in Tax Payments, Report Finds
 - [https://www.theepochtimes.com/two-thirds-of-canadian-marijuana-dealers-falling-behind-in-tax-payments-report-finds_5297730.html](https://www.theepochtimes.com/two-thirds-of-canadian-marijuana-dealers-falling-behind-in-tax-payments-report-finds_5297730.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 15:50:03+00:00

As of September 2022, 66 percent of licensed marijuana prodcuers required to remit excise duties had an outstanding debt with the Canada Revenue Agency, and unpaid taxes last year totalled $52.4 million, according (Dmytro Tyshchenko/Shuterstock)

## 4 Dead After Tourist Boat Capsizes in Storm on Italian Lake
 - [https://www.theepochtimes.com/4-dead-after-tourist-boat-capsizes-in-storm-on-italian-lake_5297562.html](https://www.theepochtimes.com/4-dead-after-tourist-boat-capsizes-in-storm-on-italian-lake_5297562.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 15:40:26+00:00

A helicopter searches for missing after a tourist boat capsized in a storm on Italy's Lago Maggiore in the northern Lombardy region on May 28, 2023. (Vigili Del Fuoco via AP)

## 14,000 People Evacuated From Areas Near Halifax as Wildfires Spread
 - [https://www.theepochtimes.com/14000-people-evacuated-from-areas-near-halifax-as-wildfires-spread_5297635.html](https://www.theepochtimes.com/14000-people-evacuated-from-areas-near-halifax-as-wildfires-spread_5297635.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 15:14:48+00:00

Thick plumes of heavy smoke fill the Halifax sky as an out-of-control fire in a suburban community quickly spread, engulfing multiple homes and forcing the evacuation of local residents on May 28, 2023. 
(THE CANADIAN PRESS/Kelly Clark)

## Air France Flight Turns Back to Osaka After Malfunction: Kyodo
 - [https://www.theepochtimes.com/air-france-flight-turns-back-to-osaka-after-malfunction-kyodo_5296741.html](https://www.theepochtimes.com/air-france-flight-turns-back-to-osaka-after-malfunction-kyodo_5296741.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 15:13:58+00:00

Logo of Air France KLM Group is pictured on the first Air France airliner's Airbus A350 during a ceremony at the aircraft builder's headquarters of Airbus in Colomiers near Toulouse, France, on Sept. 27, 2019. (Regis Duvignau/Reuters)

## Conservatives on Finance Committee Resume Filibuster of Liberals’ Budget Bills
 - [https://www.theepochtimes.com/conservatives-on-finance-committee-resume-filibuster-of-liberals-budget-bills_5294850.html](https://www.theepochtimes.com/conservatives-on-finance-committee-resume-filibuster-of-liberals-budget-bills_5294850.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 14:57:23+00:00

The Parliament Hill Peace Tower is framed in an iron fence on Wellington Street in Ottawa on March 12, 2020. (Sean Kilpatrick/The Canadian Press)

## UK Police to Help Crack Down on People Smugglers in North Africa
 - [https://www.theepochtimes.com/uk-police-to-help-crack-down-on-people-smugglers-in-north-africa_5297687.html](https://www.theepochtimes.com/uk-police-to-help-crack-down-on-people-smugglers-in-north-africa_5297687.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 14:55:31+00:00

An undated image of an NCA officer in front of a poster highlighting modern slavery. (Alamy/PA)

## Malaysia Arrests Chinese Ship Suspected of Plundering British Warship Wrecks
 - [https://www.theepochtimes.com/malaysia-arrests-chinese-ship-suspected-of-plundering-british-warship-wrecks_5297424.html](https://www.theepochtimes.com/malaysia-arrests-chinese-ship-suspected-of-plundering-british-warship-wrecks_5297424.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 14:32:03+00:00

A Malaysian Maritime Enforcement Agency boat takes part in the rescue operation for the missing sailors from the USS John S. McCain off the Johor coast of Malaysia on Aug. 24, 2017. (Mohd Rasfan/AFP via Getty Images)

## Met Police to Stop Attending Mental Health Calls
 - [https://www.theepochtimes.com/met-police-to-stop-attending-mental-health-calls_5297359.html](https://www.theepochtimes.com/met-police-to-stop-attending-mental-health-calls_5297359.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 13:58:46+00:00

A close-up photo of police insignia provided by the Metropolitan Police on Oct. 6, 2018. (Metropolitan Police)

## Ontario Hospitals Prepare and Brace for Summer ER Staffing Challenges
 - [https://www.theepochtimes.com/ontario-hospitals-prepare-and-brace-for-summer-er-staffing-challenges_5297627.html](https://www.theepochtimes.com/ontario-hospitals-prepare-and-brace-for-summer-er-staffing-challenges_5297627.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 13:48:37+00:00

Ontario Health Minister Sylvia Jones makes an announcement on health care with Premier Doug Ford in the province in Toronto, on Jan. 16, 2023. (The Canadian Press/Frank Gunn)

## UCP or NDP? Albertans Head to the Polls Today
 - [https://www.theepochtimes.com/ucp-or-ndp-albertans-head-to-the-polls-today_5297517.html](https://www.theepochtimes.com/ucp-or-ndp-albertans-head-to-the-polls-today_5297517.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 13:15:47+00:00

UCP Leader Danielle Smith (L) and Alberta NDP Leader Rachel Notley. (Jeff McIntosh/The Canadian Press)

## 13,000 Albanians Breach Bail Conditions
 - [https://www.theepochtimes.com/13000-albanians-breach-bail-conditions_5297504.html](https://www.theepochtimes.com/13000-albanians-breach-bail-conditions_5297504.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 12:28:02+00:00

A 30-year-old Albanian national is arrested by National Crime Agency officers in a dawn raid in Surbiton, southwest London, on Oct. 7, 2022. (National Crime Agency)

## Heavy Clashes in Sudan’s Capital as Truce Set to Expire
 - [https://www.theepochtimes.com/heavy-clashes-in-sudans-capital-as-truce-set-to-expire_5297522.html](https://www.theepochtimes.com/heavy-clashes-in-sudans-capital-as-truce-set-to-expire_5297522.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 11:54:21+00:00

Smoke billows behind buildings in Khartoum, amid ongoing fighting between the forces of two rival generals in Sudan, on May 29, 2023. (AFP via Getty Images)

## Russia Hits Ukrainian Military Facility and Odesa Port in Air Strikes
 - [https://www.theepochtimes.com/russia-hits-ukrainian-military-facility-and-odesa-port-in-air-strikes_5297500.html](https://www.theepochtimes.com/russia-hits-ukrainian-military-facility-and-odesa-port-in-air-strikes_5297500.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 11:33:33+00:00

An explosion is seen in the sky over the city during a Russian drone and missile strike in Kyiv, Ukraine, on May 29, 2023. (Gleb Garanich/Reuters)

## South Korea Forms Diplomatic Relations With Niue
 - [https://www.theepochtimes.com/south-korea-forms-diplomatic-relations-with-niue_5297051.html](https://www.theepochtimes.com/south-korea-forms-diplomatic-relations-with-niue_5297051.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 11:24:10+00:00

South Korea's president-elect Yoon Suk-yeol attends a ceremony of disbanding his presidential election camp at the National Assembly Library in Seoul, South Korea, on March 10, 2022. (Song Kyung-seok/Pool via Reuters)

## NATO Warns Kosovo Against Taking ‘Destabilizing Steps’ Amid Serbia Tensions
 - [https://www.theepochtimes.com/nato-warns-kosovo-against-taking-destabilizing-steps-amid-serbia-tensions_5297248.html](https://www.theepochtimes.com/nato-warns-kosovo-against-taking-destabilizing-steps-amid-serbia-tensions_5297248.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 08:26:29+00:00

Serbian army self-propelled 155 mm gun-howitzers on position near administrative line with Kosovo, south Serbia, on Dec. 26, 2022. (Serbian Defense Ministry Press Service via AP)

## China’s New US Ambassador Calls on ‘Compatriots’, Chinese Students to ‘Serve the Motherland’
 - [https://www.theepochtimes.com/chinas-new-us-ambassador-calls-on-compatriots-chinese-students-to-serve-the-motherland_5297202.html](https://www.theepochtimes.com/chinas-new-us-ambassador-calls-on-compatriots-chinese-students-to-serve-the-motherland_5297202.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 07:45:24+00:00

Xie Feng, China's new ambassador to the U.S., addresses the media as he arrives at JFK airport in New York City, U.S., May 23, 2023. REUTERS/Brendan McDermid

## Lidia Thorpe to Abstain During Indigenous Voice to Parliament Senate Vote
 - [https://www.theepochtimes.com/lidia-thorpe-to-abstain-during-indigenous-voice-to-parliament-senate-vote_5297301.html](https://www.theepochtimes.com/lidia-thorpe-to-abstain-during-indigenous-voice-to-parliament-senate-vote_5297301.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 07:34:02+00:00

Senator Lidia Thorpe announces she is resigning from the Greens and moving to the cross bench at a press conference at Parliament House in Canberra, Australia, on Feb. 6, 2023. (AAP Image/Mick Tsikas)

## ‘I’m Tired’: WA Premier Steps Down Citing Exhaustion From COVID-19 Lockdown Years
 - [https://www.theepochtimes.com/im-tired-wa-premier-steps-down-citing-exhaustion-from-covid-19-lockdown-years_5297276.html](https://www.theepochtimes.com/im-tired-wa-premier-steps-down-citing-exhaustion-from-covid-19-lockdown-years_5297276.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 07:22:32+00:00

Western Australian Labor Premier Mark McGowan speaks to media during a press conference at Dumas House in Perth, Australia on May 29, 2023. (AAP Image/Richard Wainwright)

## Australian Office Workers Still Reluctant to Return to Workplaces
 - [https://www.theepochtimes.com/australian-office-workers-still-reluctant-to-return-to-workplaces_5297261.html](https://www.theepochtimes.com/australian-office-workers-still-reluctant-to-return-to-workplaces_5297261.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 06:48:35+00:00

Spanish consultant Antonio Linaje works at his home in Villalba de Duero, Spain, on Dec. 4, 2020. (Pierre-Philippe Marcou/AFP via Getty Images)

## Sunrise Host David Koch Retires From Breakfast TV
 - [https://www.theepochtimes.com/sunrise-host-david-koch-retires-from-breakfast-tv_5297271.html](https://www.theepochtimes.com/sunrise-host-david-koch-retires-from-breakfast-tv_5297271.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 05:48:33+00:00

Sunrise host David Koch is seen during the Fast &#038; Furious Presents: Hobbs &#038; Shaw movie premiere at Hoyts Entertainment Quarter in Sydney, Wednesday, July 31, 2019. (AAP Image/Bianca De Marchi)

## US and Australia Drink the Kool-Aid on Climate Change
 - [https://www.theepochtimes.com/us-and-australia-drink-the-kool-aid-on-climate-change_5297181.html](https://www.theepochtimes.com/us-and-australia-drink-the-kool-aid-on-climate-change_5297181.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 04:46:17+00:00

US President Joe Biden (R) signs documents with Australia's Prime Minister Anthony Albanese during a bilateral meeting as part of the G7 Leaders' Summit  on May 20, 2023 in Hiroshima. (Brendan Smialowski/Getty Images)

## Halifax-Area Neighbourhoods Evacuated as Fast-Moving Fires Engulf Homes and Spread
 - [https://www.theepochtimes.com/halifax-area-neighbourhoods-evacuated-as-fast-moving-fires-engulf-homes-and-spread_5297221.html](https://www.theepochtimes.com/halifax-area-neighbourhoods-evacuated-as-fast-moving-fires-engulf-homes-and-spread_5297221.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 04:23:27+00:00

Thick plumes of heavy smoke fill the Halifax sky as an out-of-control fire in a suburban community quickly spread, engulfing multiple homes and forcing the evacuation of local residents, Sunday May 28, 2023. (The Canadian Press/Kelly Clark)

## PwC Stands Down 9 Executives and Apologises for Tax Scandal
 - [https://www.theepochtimes.com/pwc-stands-down-9-executives-and-apologises-for-tax-scandal_5297026.html](https://www.theepochtimes.com/pwc-stands-down-9-executives-and-apologises-for-tax-scandal_5297026.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 03:57:10+00:00

The PricewaterhouseCoopers (PwC) offices stand in More London Riverside in London, England, on Oct. 2, 2018. (Jack Taylor/Getty Images)

## Army Air Force Pilot From Pennsylvania Killed During WWII Accounted For, Authorities Say
 - [https://www.theepochtimes.com/army-air-force-pilot-from-pennsylvania-killed-during-wwii-accounted-for-authorities-say_5296685.html](https://www.theepochtimes.com/army-air-force-pilot-from-pennsylvania-killed-during-wwii-accounted-for-authorities-say_5296685.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 02:45:23+00:00

U.S. Army Air Forces 2nd Lt. James Litherland in a file photo. (Defense POW/MIA Accounting Agency)

## John Paul II Would Not Have Supported The Voice
 - [https://www.theepochtimes.com/john-paul-ii-would-not-have-supported-the-voice_5296999.html](https://www.theepochtimes.com/john-paul-ii-would-not-have-supported-the-voice_5296999.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 02:07:11+00:00

Pope John Paul II waves the faithful in Vercelli, May 23, 1998, during beatification ceremonies for Italian army chaplain Secondo Pollo, who died in 1941. (Gerard Julien/AFP via Getty Images)

## North Korea Notifies Japan of Plan to Launch Satellite
 - [https://www.theepochtimes.com/north-korea-notifies-japan-of-plan-to-launch-satellite_5297050.html](https://www.theepochtimes.com/north-korea-notifies-japan-of-plan-to-launch-satellite_5297050.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 01:49:03+00:00

North Korean leader Kim Jong Un inspects North Korea's National Aerospace Development Administration after recent satellite system tests, in Pyongyang, North Korea, in this photo released by state media on March 10, 2022. (KCNA via Reuters)

## Amazon to Shut Down China App Store in Further Retreat From Country
 - [https://www.theepochtimes.com/amazon-to-shut-down-china-app-store-in-further-retreat-from-country_5296971.html](https://www.theepochtimes.com/amazon-to-shut-down-china-app-store-in-further-retreat-from-country_5296971.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 00:49:08+00:00

Visitors gathering at Amazon booth during the 2016 China International Electronic Commerce Expo in Yiwu, east China's Zhejiang province, on April 11, 2016. (STR/AFP via Getty Images)

## Childcare Waitlists Delaying Parents Returning to Work
 - [https://www.theepochtimes.com/childcare-waitlists-delaying-parents-returning-to-work_5296935.html](https://www.theepochtimes.com/childcare-waitlists-delaying-parents-returning-to-work_5296935.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 00:17:11+00:00

Australian Prime Minister Anthony Albanese visits a childcare centre in Perth, Australia, on May 16, 2022. (Lisa Maree Williams/Getty Images)

## Albanese Takes Aim at Indigenous Voice ‘Doomsayers’
 - [https://www.theepochtimes.com/albanese-takes-aim-at-indigenous-voice-doomsayers_5296925.html](https://www.theepochtimes.com/albanese-takes-aim-at-indigenous-voice-doomsayers_5296925.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-05-29 00:11:47+00:00

Australia's Prime Minister Anthony Albanese arrives at Hiroshima airport in Mihara, Hiroshima prefecture on May 19, 2023, to attend the first day of the G7 Leaders' Summit. (Philip Fong/AFP via Getty Images)

