# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## As per your politics, debt ceiling plan is good or a ‘disaster’
 - [https://www.aljazeera.com/economy/2023/5/29/as-per-your-politics-debt-ceiling-plan-is-good-or-a-disaster](https://www.aljazeera.com/economy/2023/5/29/as-per-your-politics-debt-ceiling-plan-is-good-or-a-disaster)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 20:50:25+00:00

While some of US Congress&#039;s most conservative members are not happy with the deal, business groups gave it a thumbs up.

## Iran journalist faces trial over charges tied to Amini protests
 - [https://www.aljazeera.com/news/2023/5/29/iranian-journalists-who-reported-aminis-death-stands-trial](https://www.aljazeera.com/news/2023/5/29/iranian-journalists-who-reported-aminis-death-stands-trial)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 20:24:09+00:00

Iranian reporter tried in a closed court on charges linked to her coverage of Mahsa Amini’s funeral.

## Teenaged student charged with murder in deadly Guyana school fire
 - [https://www.aljazeera.com/news/2023/5/29/teenaged-student-charged-with-murder-in-deadly-guyana-school-fire](https://www.aljazeera.com/news/2023/5/29/teenaged-student-charged-with-murder-in-deadly-guyana-school-fire)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 19:35:20+00:00

The 15-year-old is accused of starting a fire in a school dormitory, killing 19, after her cell phone was confiscated.

## Kosovo-Serbia tension: History, latest flare-up and what’s next?
 - [https://www.aljazeera.com/news/2023/5/29/kosovo-serbia-tension-history-latest-flare-up-and-whats-next](https://www.aljazeera.com/news/2023/5/29/kosovo-serbia-tension-history-latest-flare-up-and-whats-next)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 19:33:02+00:00

Clashes erupt between police and local Serbs in northern Kosovo after new ethnic Albanian mayors take office.

## What does re-election of Erdogan mean for Turkey and the world?
 - [https://www.aljazeera.com/program/inside-story/2023/5/29/what-does-re-election-of-erdogan-mean-for-turkey-and-the-world](https://www.aljazeera.com/program/inside-story/2023/5/29/what-does-re-election-of-erdogan-mean-for-turkey-and-the-world)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 19:10:53+00:00

Leader set to begin a third term after winning presidential run-off vote.

## El Salvador ex-president sentenced to 14 years over gang talks
 - [https://www.aljazeera.com/news/2023/5/29/el-salvador-ex-president-sentenced-to-14-years-over-gang-talks](https://www.aljazeera.com/news/2023/5/29/el-salvador-ex-president-sentenced-to-14-years-over-gang-talks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 19:10:25+00:00

Mauricio Funes, who currently lives in Nicaragua, denies the charges and says 2012 truce was brokered by the church.

## Libya court sentences 23 to death for ISIL campaign
 - [https://www.aljazeera.com/news/2023/5/29/libya-court-sentences-23-to-death-for-isil-campaign](https://www.aljazeera.com/news/2023/5/29/libya-court-sentences-23-to-death-for-isil-campaign)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 18:34:07+00:00

Appeals court sentences 14 others to life in prison for campaign including beheading Egyptian Christians in 2015.

## India files graft case against BAE Systems, Rolls-Royce
 - [https://www.aljazeera.com/economy/2023/5/29/india-files-graft-case-against-bae-systems-rolls-royce](https://www.aljazeera.com/economy/2023/5/29/india-files-graft-case-against-bae-systems-rolls-royce)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 17:42:14+00:00

The &#039;criminal conspiracy&#039; case is related to the procurement and licensed manufacturing of 123 advanced jet trainers.

## Venezuela’s Maduro meets Lula in Brazil as relations improve
 - [https://www.aljazeera.com/news/2023/5/29/venezuelas-maduro-meets-lula-in-brazil-as-relations-improve](https://www.aljazeera.com/news/2023/5/29/venezuelas-maduro-meets-lula-in-brazil-as-relations-improve)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 17:35:41+00:00

Nicolas Maduro makes first visit to Brazil in years as Venezuela sees better ties with region&#039;s left-wing leaders.

## US debt ceiling deal: What’s in, what’s out of the bill
 - [https://www.aljazeera.com/economy/2023/5/29/us-debt-ceiling-deal-whats-in-whats-out-of-the-bill](https://www.aljazeera.com/economy/2023/5/29/us-debt-ceiling-deal-whats-in-whats-out-of-the-bill)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 17:29:15+00:00

The Democratic president and Republican speaker are trying to win over lawmakers to the plan in time to avert a default.

## Ukraine’s parliament approves sanctions against Russia ally Iran
 - [https://www.aljazeera.com/news/2023/5/29/ukraines-parliament-approves-sanctions-against-russia-ally-iran](https://www.aljazeera.com/news/2023/5/29/ukraines-parliament-approves-sanctions-against-russia-ally-iran)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 16:42:07+00:00

Package imposes trade, financial and technology sanctions against Iran and stops Tehran from using Ukraine&#039;s airspace.

## Fighting continues in Sudan as latest ceasefire close to expiring
 - [https://www.aljazeera.com/news/2023/5/29/fighting-continues-in-sudan-as-latest-ceasefire-close-to-expiring](https://www.aljazeera.com/news/2023/5/29/fighting-continues-in-sudan-as-latest-ceasefire-close-to-expiring)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 16:40:07+00:00

War inflicts widespread destruction on residential areas in Khartoum and adjacent cities of Omdurman and North Khartoum.

## Nigeria’s new President Bola Tinubu vows reset for ailing economy
 - [https://www.aljazeera.com/news/2023/5/29/nigerias-new-president-tinubu-promises-economic-reboot](https://www.aljazeera.com/news/2023/5/29/nigerias-new-president-tinubu-promises-economic-reboot)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 16:25:44+00:00

Tinubu inherits economy riddled with huge debt from predecessor Buhari, whose protectionist policies spooked investors.

## The adoption of sign language is a loud win for anti-capitalism
 - [https://www.aljazeera.com/opinions/2023/5/29/the-adoption-of-sign-language-is-a-loud-win-for-anti-capitalism](https://www.aljazeera.com/opinions/2023/5/29/the-adoption-of-sign-language-is-a-loud-win-for-anti-capitalism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 16:18:56+00:00

Its new status as a national language in South Africa follows a long struggle against forces putting profit over people.

## Wildfire forces thousands of people to evacuate in eastern Canada
 - [https://www.aljazeera.com/news/2023/5/29/wildfire-forces-thousands-of-people-to-evacuate-in-eastern-canada](https://www.aljazeera.com/news/2023/5/29/wildfire-forces-thousands-of-people-to-evacuate-in-eastern-canada)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 15:24:56+00:00

More than 16,000 people leave their homes as crews battle raging blaze near Halifax, Nova Scotia.

## Shanghai records hottest day in May in 100 years
 - [https://www.aljazeera.com/news/2023/5/29/shanghai-records-hottest-day-in-may-in-100-years](https://www.aljazeera.com/news/2023/5/29/shanghai-records-hottest-day-in-may-in-100-years)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 15:06:42+00:00

Temperature hits 36.7C in China&#039;s largest city as records fall across Southeast Asia and South Asia.

## Lavrov in shock Kenya visit days after Ukraine FM trip to Africa
 - [https://www.aljazeera.com/news/2023/5/29/lavrov-in-shock-kenya-visit-days-after-ukraine-fm-trip-to-africa](https://www.aljazeera.com/news/2023/5/29/lavrov-in-shock-kenya-visit-days-after-ukraine-fm-trip-to-africa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 15:05:08+00:00

The visits come as global powers continue to tussle for influence on the continent of 1.3 billion people.

## Saudi Arabia executes two Bahrainis accused of ‘terrorism’
 - [https://www.aljazeera.com/news/2023/5/29/saudi-arabia-executes-two-bahrainis-accused-of-terrorism](https://www.aljazeera.com/news/2023/5/29/saudi-arabia-executes-two-bahrainis-accused-of-terrorism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 14:59:25+00:00

Government did not specify the groups the men were associated with, but said they had been planning to launch attacks.

## After Turkey election win, what problems does Erdogan face next?
 - [https://www.aljazeera.com/news/2023/5/29/after-turkey-election-win-what-problems-does-erdogan-face-next](https://www.aljazeera.com/news/2023/5/29/after-turkey-election-win-what-problems-does-erdogan-face-next)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 13:34:46+00:00

Economic concerns and relations with the West lie at the top of Erdogan&#039;s agenda after Sunday&#039;s presidential win.

## Palestinian Authority officer killed by Israeli forces in Jenin
 - [https://www.aljazeera.com/news/2023/5/29/palestinian-authority-officer-killed-by-israeli-forces-in-jenin](https://www.aljazeera.com/news/2023/5/29/palestinian-authority-officer-killed-by-israeli-forces-in-jenin)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 13:26:28+00:00

Ashraf Mohammad Ameen Ibrahim, 37, dies from gunshot wounds after a raid by Israeli forces on the Jenin refugee camp.

## Five key takeaways from Turkey’s pivotal election
 - [https://www.aljazeera.com/news/2023/5/29/five-key-takeaways-from-turkeys-pivotal-election](https://www.aljazeera.com/news/2023/5/29/five-key-takeaways-from-turkeys-pivotal-election)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 13:23:54+00:00

Erdogan a political survivor, Kurds put off by nationalist rhetoric and other reflections.

## Troubled Chelsea hire Mauricio Pochettino on two-year deal
 - [https://www.aljazeera.com/sports/2023/5/29/chelsea-hire-mauricio-pochettino-coach](https://www.aljazeera.com/sports/2023/5/29/chelsea-hire-mauricio-pochettino-coach)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 13:12:57+00:00

The 51-year-old Argentinian is tasked with reviving Chelsea&#039;s fortunes after worst Premier League campaign since 1994.

## ‘Hope never dies’: Venezuelan migrants disappear in Colombia
 - [https://www.aljazeera.com/news/2023/5/29/hope-never-dies-venezuelan-migrants-disappear-in-colombia](https://www.aljazeera.com/news/2023/5/29/hope-never-dies-venezuelan-migrants-disappear-in-colombia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 13:07:05+00:00

Human rights groups say the state is not doing enough to find hundreds of Venezuelans who have gone missing in Colombia.

## Photos: Memories of Nakba inspire Palestinian artist’s work
 - [https://www.aljazeera.com/gallery/2023/5/29/photos-memories-of-nakba-inspire-palestinian-artists-work](https://www.aljazeera.com/gallery/2023/5/29/photos-memories-of-nakba-inspire-palestinian-artists-work)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 12:52:46+00:00

Abed Abdi, 81, is a Palestinian visual artist who was expelled from Haifa in 1948 and returned three years later.

## ‘Squandered goodwill’: How Buhari failed Nigeria a second time
 - [https://www.aljazeera.com/features/2023/5/29/squandered-goodwill-how-buhari-failed-nigeria-a-second-time](https://www.aljazeera.com/features/2023/5/29/squandered-goodwill-how-buhari-failed-nigeria-a-second-time)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 12:17:21+00:00

From the economy to security, Buhari&#039;s legacy will be one of missteps and misdeeds, analysts say as he hands over power.

## ICC leaders in Pakistan to secure cricket World Cup participation
 - [https://www.aljazeera.com/sports/2023/5/29/cricket-odi-world-cup-pakistan-india](https://www.aljazeera.com/sports/2023/5/29/cricket-odi-world-cup-pakistan-india)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 12:01:18+00:00

After India declined to tour Pakistan for the Asia Cup, Pakistan says it won&#039;t play in the Cricket World Cup in India.

## ‘Ultimate influencer’ Ronaldo’s mixed season in Saudi Arabia
 - [https://www.aljazeera.com/sports/2023/5/29/football-cristiano-ronaldo-first-season-saudi-arabia-al-nassr](https://www.aljazeera.com/sports/2023/5/29/football-cristiano-ronaldo-first-season-saudi-arabia-al-nassr)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 11:43:10+00:00

Ronaldo ends his first season in Saudi football empty-handed but his move to Al Nassr had impacts on and off the pitch.

## US Senator Lindsey Graham on Russia wanted list after war remarks
 - [https://www.aljazeera.com/news/2023/5/29/us-senator-lindsey-graham-on-russia-wanted-list-after-war-remarks](https://www.aljazeera.com/news/2023/5/29/us-senator-lindsey-graham-on-russia-wanted-list-after-war-remarks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 11:03:05+00:00

Russia&#039;s Investigative Committee says it is opening a criminal investigation into comments made by Republican senator.

## NATO troops form security cordons in Kosovo as Serbs protest
 - [https://www.aljazeera.com/news/2023/5/29/nato-troops-form-security-cordons-in-kosovo-as-serbs-protest](https://www.aljazeera.com/news/2023/5/29/nato-troops-form-security-cordons-in-kosovo-as-serbs-protest)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 10:57:58+00:00

Soldiers block off four town halls to keep back Serbs protesting against ethnic Albanian mayors taking office.

## Uganda’s Museveni approves anti-LGBTQ law – parliament speaker
 - [https://www.aljazeera.com/news/2023/5/29/ugandas-museveni-approves-anti-lgbtq-law-parliament-speaker](https://www.aljazeera.com/news/2023/5/29/ugandas-museveni-approves-anti-lgbtq-law-parliament-speaker)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 10:32:20+00:00

The new law, one of the world&#039;s strictest anti-LGBTQ laws, is in defiance of condemnations from international community.

## Not just Ben-Gvir: A new Al-Aqsa provocation is building up
 - [https://www.aljazeera.com/news/2023/5/29/not-just-ben-gvir-a-new-al-aqsa-provocation-is-building-up](https://www.aljazeera.com/news/2023/5/29/not-just-ben-gvir-a-new-al-aqsa-provocation-is-building-up)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 10:30:12+00:00

The Israeli minister&#039;s visits have deep roots in religious Zionism. But his approach is now finding new takers too.

## How did Turks living abroad vote in Turkey’s run-off election?
 - [https://www.aljazeera.com/news/2023/5/29/how-did-turks-living-abroad-vote-in-turkeys-run-off-election](https://www.aljazeera.com/news/2023/5/29/how-did-turks-living-abroad-vote-in-turkeys-run-off-election)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 10:18:47+00:00

Erdogan received 59.4 percent of international votes, while Kilicdaroglu managed to garner 40.6 percent.

## Lira hits record low, but stocks rise after Erdogan win in Turkey
 - [https://www.aljazeera.com/economy/2023/5/29/lira-hits-record-low-but-stocks-rise-after-erdogan-win-in-turkey](https://www.aljazeera.com/economy/2023/5/29/lira-hits-record-low-but-stocks-rise-after-erdogan-win-in-turkey)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 10:14:34+00:00

The Turkish leader won the presidency for a third time after a run-off vote on Sunday.

## Tinubu sworn in as Nigeria’s president, succeeds Buhari
 - [https://www.aljazeera.com/news/2023/5/29/tinubu-sworn-in-as-nigerias-president-succeeds-buhari](https://www.aljazeera.com/news/2023/5/29/tinubu-sworn-in-as-nigerias-president-succeeds-buhari)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 09:55:54+00:00

Tinubu is Nigeria&#039;s fifth president since the return of democracy in 1999.

## Everest continues to attract climbers 70 years after first summit
 - [https://www.aljazeera.com/news/2023/5/29/everest-continues-to-attract-climbers-70-years-after-first-summit](https://www.aljazeera.com/news/2023/5/29/everest-continues-to-attract-climbers-70-years-after-first-summit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 09:33:03+00:00

Nepal&#039;s mountains captivate both adventurers and tourists and bring a vital lifeline to surrounding villages.

## Spanish PM Pedro Sanchez calls early election for July 23
 - [https://www.aljazeera.com/news/2023/5/29/spanish-pm-pedro-sanchez-calls-early-election-for-july-23](https://www.aljazeera.com/news/2023/5/29/spanish-pm-pedro-sanchez-calls-early-election-for-july-23)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 09:31:30+00:00

Prime minister says he will dissolve Spain&#039;s parliament after his party performed poorly in local and regional polls.

## History Illustrated: Wagner and the Rise of a Russian Mercenary
 - [https://www.aljazeera.com/gallery/2023/5/29/history-illustrated-wagner-and-the-rise-of-a-russian-mercenary](https://www.aljazeera.com/gallery/2023/5/29/history-illustrated-wagner-and-the-rise-of-a-russian-mercenary)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 09:24:19+00:00

Yevgeny Prigozhin is a former convict and self-made oligarch who some now see as gunning for President Putin’s job.

## Carmakers emitting 74 million tonnes of CO2, Greenpeace says
 - [https://www.aljazeera.com/economy/2023/5/29/carmakers-emitting-74-million-tonnes-of-co2-greenpeace-says](https://www.aljazeera.com/economy/2023/5/29/carmakers-emitting-74-million-tonnes-of-co2-greenpeace-says)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 06:28:36+00:00

Top automakers&#039; dependence on steel steering planet towards &#039;climate catastrophe&#039;, environmental group says.

## Japan’s Nikkei hits 33-year high on weak yen, US optimism
 - [https://www.aljazeera.com/economy/2023/5/29/japans-nikkei-hits-33-year-high-on-weak-yen-us-optimism](https://www.aljazeera.com/economy/2023/5/29/japans-nikkei-hits-33-year-high-on-weak-yen-us-optimism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 05:34:27+00:00

Japanese stock market rises to the highest level since July 1990 after the US finalises deal to raise the debt ceiling.

## PwC Australia stands down staff amid tax plans leak scandal
 - [https://www.aljazeera.com/economy/2023/5/29/pwc-australia-stands-down-staff-amid-deepening-tax-leak-scandal](https://www.aljazeera.com/economy/2023/5/29/pwc-australia-stands-down-staff-amid-deepening-tax-leak-scandal)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 04:50:12+00:00

Accounting firm pledges to do &#039;everything it takes&#039; to regain trust after leaking government information to clients.

## China to send its first civilian astronaut into space
 - [https://www.aljazeera.com/news/2023/5/29/china-to-send-its-first-civilian-astronaut-into-space](https://www.aljazeera.com/news/2023/5/29/china-to-send-its-first-civilian-astronaut-into-space)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 04:39:52+00:00

Payload expert Gui Haichao will set off for the Tiangong space station as part of a three-person mission on Tuesday.

## Explosions as Russia launches 15th air assault on Kyiv in May
 - [https://www.aljazeera.com/news/2023/5/29/explosions-as-russia-launches-15th-air-assault-on-kyiv-in-may](https://www.aljazeera.com/news/2023/5/29/explosions-as-russia-launches-15th-air-assault-on-kyiv-in-may)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 03:14:05+00:00

Overnight missile attack comes a day after Russia unleashed its largest ever drone assault on the Ukrainian capital.

## Philippines’ crackdown on anonymous SIM cards prompts backlash
 - [https://www.aljazeera.com/economy/2023/5/29/philippines-crackdown-on-anonymous-sim-cards-prompts-backlash](https://www.aljazeera.com/economy/2023/5/29/philippines-crackdown-on-anonymous-sim-cards-prompts-backlash)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 03:03:10+00:00

Some cybersecurity experts fear the SIM Card Registration Act will encourage identity theft and fraud.

## Biden says final US debt ceiling deal ready for Congress vote
 - [https://www.aljazeera.com/news/2023/5/29/biden-says-final-us-debt-ceiling-deal-ready-for-congress-vote](https://www.aljazeera.com/news/2023/5/29/biden-says-final-us-debt-ceiling-deal-ready-for-congress-vote)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 02:33:03+00:00

US president and House Speaker Kevin McCarthy are confident they will be able to get enough support to avert a default.

## Russia-Ukraine war: List of key events, day 460
 - [https://www.aljazeera.com/news/2023/5/29/russia-ukraine-war-list-of-key-events-day-460](https://www.aljazeera.com/news/2023/5/29/russia-ukraine-war-list-of-key-events-day-460)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 02:04:57+00:00

As the war enters its 460th day, we take a look at the main developments.

## Dozens killed in clashes with troops in northeastern India
 - [https://www.aljazeera.com/news/2023/5/29/dozens-killed-in-clashes-with-troops-in-northeastern-india](https://www.aljazeera.com/news/2023/5/29/dozens-killed-in-clashes-with-troops-in-northeastern-india)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 01:26:40+00:00

New Delhi has deployed security forces to Manipur to try and put down ethnic unrest that began earlier this month.

## North Korea plans ‘satellite’ launch in coming weeks: Japan
 - [https://www.aljazeera.com/news/2023/5/29/north-korea-plans-satellite-launch-in-coming-weeks-japan](https://www.aljazeera.com/news/2023/5/29/north-korea-plans-satellite-launch-in-coming-weeks-japan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-29 01:03:48+00:00

Pyongyang has said previously it completed work on a spy satellite, but Tokyo says launch could be ballistic missile.

