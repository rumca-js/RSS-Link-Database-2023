# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Microsoft President Wants It To Be Illegal To Remove AI Watermark Microsoft And Others Are Developing
 - [https://reclaimthenet.org/microsoft-wants-it-to-be-illegal-to-remove-ai-watermark](https://reclaimthenet.org/microsoft-wants-it-to-be-illegal-to-remove-ai-watermark)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-05-29 18:21:41+00:00

<a href="https://reclaimthenet.org/microsoft-wants-it-to-be-illegal-to-remove-ai-watermark" rel="nofollow" title="Microsoft President Wants It To Be Illegal To Remove AI Watermark Microsoft And Others Are Developing"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/05/brad-bird-ai.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The Big Tech giant is proposing legislation.</p>
<p>The post <a href="https://reclaimthenet.org/microsoft-wants-it-to-be-illegal-to-remove-ai-watermark" rel="nofollow">Microsoft President Wants It To Be Illegal To Remove AI Watermark Microsoft And Others Are Developing</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## EU Threatens Twitter Over “Disinformation” – “You Can Run But You Can’t Hide”
 - [https://reclaimthenet.org/eu-twitter-digital-services-act-threat](https://reclaimthenet.org/eu-twitter-digital-services-act-threat)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-05-29 17:24:22+00:00

<a href="https://reclaimthenet.org/eu-twitter-digital-services-act-threat" rel="nofollow" title="EU Threatens Twitter Over &#8220;Disinformation&#8221; &#8211; &#8220;You Can Run But You Can’t Hide&#8221;"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/05/breton-twitter.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The EU says Twitter will have to comply with its censorship laws in August.</p>
<p>The post <a href="https://reclaimthenet.org/eu-twitter-digital-services-act-threat" rel="nofollow">EU Threatens Twitter Over &#8220;Disinformation&#8221; &#8211; &#8220;You Can Run But You Can’t Hide&#8221;</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

