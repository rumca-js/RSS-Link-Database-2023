# Source:Tomasz Samołyk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg, language:pl-PL

## Czy sztuczna inteligencja nam zagraża? Czy wiara wyklucza naukę? Odpowiedź na słowa Andrzeja Dragana
 - [https://www.youtube.com/watch?v=lRdIb_7XPyo](https://www.youtube.com/watch?v=lRdIb_7XPyo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg
 - date published: 2023-05-29 15:20:14+00:00

W dzisiejszym odcinku próbuję odpowiedzieć na pytanie co Bóg myśli o sztucznej inteligencji i czy wiara i nauka mogą iść w parze. 

#sztucznainteligencja #andrzejdragan #nauka 

Linki do Drabiny Jakubowej:
👉 Zapisy na wolontariat: https://zaplecze.drabinajakubowa.pl/ 
👉 Wsparcie finansowe: https://przypnijskrzydla.drabinajakubowa.pl/ 
👉 Bieżące relacje: https://www.facebook.com/wolontariatbranszczyk 

Linki do materiałów wspomnianych w filmie:
👉 Hejpark z Andrzejem Draganem: https://www.youtube.com/live/zzPwTJGBLOc?feature=share
👉 Gaudium et spes: https://sip.lex.pl/akty-prawne/akty-korporacyjne/konstytucja-duszpasterska-o-kosciele-w-swiecie-wspolczesnym-286768068
👉 Redemptor Hominis Jana Pawła II: https://www.vatican.va/content/john-paul-ii/pl/encyclicals/documents/hf_jp-ii_enc_04031979_redemptor-hominis.html
👉 Fides et ratio Jana Pawła II: https://www.vatican.va/content/john-paul-ii/pl/encyclicals/documents/hf_jp-ii_enc_14091998_fides-et-ratio.html
👉 Tomasz Miller o książce Andrzeja Dragana: https://youtu.be/qkM67iLZVpw
👉 Kanał Copernicus: https://www.youtube.com/@CopernicusCenter
👉 Wykład „Fizyka i transcendencja”  prof. Krzysztofa Meissnera: https://youtu.be/yz95ULpnFug
👉 Tekst "Fizyka jest dziś o wiele bliżej uznania istnienia Boga jako aktywnego elementu obiektywnej rzeczywistości": https://wyborcza.pl/magazyn/7,124059,29258559,fizyka-jest-dzis-o-wiele-blizej-uznania-istnienia-boga-jako.html
👉 Tekst "Andrzej Dragan: Skoro fizycy grzęzną w elementarnych pytaniach, skąd odwaga, by pytać o naturę Boga?": https://wyborcza.pl/magazyn/7,124059,29311694,andrzej-dragan-skoro-fizycy-grzezna-w-elementarnych-pytaniach.html?fbclid=IwAR3rflnWAG0KwnQhzam0rFPD0nshgFEmoyypYMcxEuCsGTeRnTlH-zyzgo4#S.MT-K.C-B.1-L.1.duzy

👉 Kontynuowanie i rozwijanie mojej pracy możliwe jest dzięki Patronom. Tu można do nich dołączyć oraz dowiedzieć się o tym na co idą środki ze wsparcia oraz poczytać o planowanych kierunkach rozwoju kanału: https://patronite.pl/Samolyk

JAK MOŻNA WESPRZEĆ KANAŁ i DOŁĄCZYĆ DO GRUPY FACEBOOK DLA WSPIERAJĄCYCH:

Można mnie wesprzeć na https://patronite.pl/samolyk, przez przycisk "WESPRZYJ" lub wpłacając dobrowolną kwotę na nr konta: Bank Pekao SA 08 1240 2786 1111 0010 1984 8265 tytułem: "darowizna"
--------------------------------------------------------------------------------------
Jeżeli wpłaciłeś darowiznę, wsparłeś mnie przez przycisk "WESPRZYJ" i chcesz być w napisach końcowych I dołączyć do grupy Patronów na Facebooku to daj mi znać na tsamolyk@gmail.com. Kiedyś wpisywałem w napisach końcowych wszystkich Darczyńców, ale kilku z nich zwróciło mi uwagę, że chcą pozostać anonimowi. Mają do tego prawo więc wprowadzam taką praktykę. Dziękuję za zrozumienie.

