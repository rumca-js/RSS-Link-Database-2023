# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Which Australian MP Does ChatGPT Consider ‘Controversial?’
 - [https://www.theepochtimes.com/which-australian-mp-does-chatgpt-consider-controversial_5297015.html](https://www.theepochtimes.com/which-australian-mp-does-chatgpt-consider-controversial_5297015.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-05-29 05:16:24+00:00

Screens display the logos of OpenAI and ChatGPT in Toulouse, France, on Jan. 23, 2023. (Lionel Bonaventure/AFP via Getty Images)

