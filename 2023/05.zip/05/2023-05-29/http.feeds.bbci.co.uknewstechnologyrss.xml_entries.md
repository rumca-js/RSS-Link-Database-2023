# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Elizabeth Holmes is going to prison. Will she ever pay victims too?
 - [https://www.bbc.co.uk/news/world-us-canada-65678967?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65678967?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-05-29 20:09:38+00:00

Experts say victims often never get their money back from those who defrauded them.

## Capita hack: 90 organisations report data breaches to watchdog
 - [https://www.bbc.co.uk/news/technology-65746518?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65746518?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-05-29 18:26:35+00:00

The privacy watchdog is urging groups using the outsourcing giant to check if data has been exposed.

## FTX: Singapore state fund Temasek cuts pay after failed investment
 - [https://www.bbc.co.uk/news/business-65743247?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65743247?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-05-29 04:03:53+00:00

Last year, Temasek Holdings wrote off all of the $275m (£222.8m) it had invested in FTX.

