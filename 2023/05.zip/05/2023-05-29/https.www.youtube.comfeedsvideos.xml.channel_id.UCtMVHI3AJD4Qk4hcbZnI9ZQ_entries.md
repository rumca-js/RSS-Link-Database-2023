# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## China Just Hacked The U.S. Navy...
 - [https://www.youtube.com/watch?v=4VYk3O777mU](https://www.youtube.com/watch?v=4VYk3O777mU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-05-29 22:23:44+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at a serious situation regarding an alleged Chinese state-backed hacking group known as Volt Typhoon. This group has hacked critical infrastructures involving the U.S. Navy and appears to be setting up for future events. Truly wild times we're living in. Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the newest podcast episode: https://youtu.be/tg7gjHJvxtI

