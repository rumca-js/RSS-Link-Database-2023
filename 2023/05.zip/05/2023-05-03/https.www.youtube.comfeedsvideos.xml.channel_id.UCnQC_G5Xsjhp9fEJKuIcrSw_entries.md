# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## 🔥 Fit From the Met Gala
 - [https://www.youtube.com/watch?v=tU6pBg8eiKc](https://www.youtube.com/watch?v=tU6pBg8eiKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-05-03 23:30:08+00:00

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

#shorts #BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #shortsnews #metgala #redcarpet #caradelevingne #celebnews #celebs

## New Military Requirements: Fat, Stupid or a Drag Queen
 - [https://www.youtube.com/watch?v=I28d85Car_U](https://www.youtube.com/watch?v=I28d85Car_U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-05-03 22:17:38+00:00

The military is now falling down the individualistic black hole. They are advertising that you can join the military so you can "find yourself." The Navy has decided to invite a drag queen to increase recruitment. Amazing stuff.

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: https://youtu.be/oeiu_huw72c

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Try ZipRecruiter for FREE: https://www.ziprecruiter.com/dailywire

Use promo code "SHAPIRO" at checkout for 15% off your order: https://www.bollandbranch.com/

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #weirdnews #lgbtq #military #navy #drag #dragqueen #army

## Did Ukraine Try to Assassinate Putin? 😳
 - [https://www.youtube.com/watch?v=m6Qt3BrHt58](https://www.youtube.com/watch?v=m6Qt3BrHt58)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-05-03 22:00:24+00:00

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

#shorts #BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #shortsfeed #shortsnews #dailynews #ukraine #russia #ukrainewar #worldnews

## Ben Interviews VIRAL Anti-Woke Rapper | @TomMacDonaldOfficial
 - [https://www.youtube.com/watch?v=QTpqhfNKFo0](https://www.youtube.com/watch?v=QTpqhfNKFo0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-05-03 20:00:12+00:00

Tom MacDonald is an anti-woke rapper that says what most Americans think without fear. MacDonald talks about how he is able to create music without getting canceled by the woke mob. 

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full show here: https://youtu.be/ImZiO8q6EdU

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #tommacdonald #antiwokerapper #dirtymoney #rapper #music #antiwoke #based

## Did Ukraine Just Try To Assassinate Putin?
 - [https://www.youtube.com/watch?v=oeiu_huw72c](https://www.youtube.com/watch?v=oeiu_huw72c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-05-03 17:00:11+00:00

Russia reports that Ukraine tried to kill Vladimir Putin at the Kremlin with a drone; the US military can’t recruit anyone – except, apparently, drag queens; and an illegal immigration time bomb is primed to explode.

1️⃣ Click here to join the member exclusive portion of my show:  https://bit.ly/41LQK62
2️⃣ Order your copy of “When Race Trumps Merit” by Heather Mac Donald: https://amzn.to/3I1mOMb 

3️⃣ Pre-order your Jeremy's Chocolate here: https://bit.ly/3EQeVag

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw
🔴Today's Sponsors🔴

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Policygenius LIFE - Get your free life insurance quote & see how much you could save: http://policygenius.com/SHAPIRO

Balance of Nature - Get 35% off your first order as a preferred customer. Use promo code SHAPIRO at checkout: https://www.balanceofnature.com/

Boll & Branch - Use promo code "SHAPIRO" at checkout for 15% off your order: https://www.bollandbranch.com/

ZipRecruiter - Try ZipRecruiter for FREE: https://www.ziprecruiter.com/dailywire

- - -

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire

## Wild Protest
 - [https://www.youtube.com/watch?v=PY6mCsOCgqo](https://www.youtube.com/watch?v=PY6mCsOCgqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-05-03 01:00:20+00:00

1️⃣ Click here to join the member exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

#shorts #BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #shortsfeed #reaction #protest #lgbtq #weirdnews #shortsnews

