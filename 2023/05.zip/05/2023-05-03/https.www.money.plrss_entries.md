# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Ceny gazu najniższe od 21 miesięcy. Na europejskim rynku nie widać już kryzysu
 - [https://www.money.pl/gielda/ceny-gazu-najnizsze-od-21-miesiecy-na-europejskim-rynku-nie-widac-juz-kryzysu-6894012978350880a.html](https://www.money.pl/gielda/ceny-gazu-najnizsze-od-21-miesiecy-na-europejskim-rynku-nie-widac-juz-kryzysu-6894012978350880a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-03 10:38:51+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/994666c6-cafc-4a8b-9bfd-78237951de13" width="308" /> W środę cena gazu w kontraktach na czerwiec spadła na holenderskiej giełdzie TTF poniżej 37 euro za megawatogodzinę. To najniższa kwota, jaką trzeba zapłacić za błękitne paliwo w Europie od 21 miesięcy - zwracają uwagę eksperci.

## Jak stworzyć biznes przyszłości dzięki rozszerzonej i wirtualnej rzeczywistości (AR i VR)
 - [https://www.money.pl/gospodarka/jak-stworzyc-biznes-przyszlosci-dzieki-rozszerzonej-i-wirtualnej-rzeczywistosci-ar-i-vr-6892264943315520a.html](https://www.money.pl/gospodarka/jak-stworzyc-biznes-przyszlosci-dzieki-rozszerzonej-i-wirtualnej-rzeczywistosci-ar-i-vr-6892264943315520a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-03 09:19:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2dbb67ff-ce7f-4dd3-9d56-5efbab05e298" width="308" /> Nowoczesne technologie powodują, że wiele czynności, które dotychczas wymuszały na nas aktywność, można już zrobić, siedząc wygodnie na własnej kanapie. Przymierzanie butów i ubrań w swojej sypialni? Fitness w salonie z wirtualnym trenerem? To wszystko jest już możliwe dzięki rozszerzonej i wirtualnej rzeczywistości. Wyniosły one rozrywkę i naukę na zupełnie inny poziom. Jak wpływają na biznes? Jak stworzyć firmę przyszłości dzięki takim rozwiązaniom?

## Słynny inwestor i miliarder radzi, jak założyć biznes, z którego będą "duże pieniądze"
 - [https://www.money.pl/pieniadze/slynny-inwestor-i-miliarder-radzi-jak-zalozyc-biznes-z-ktorego-beda-duze-pieniadze-6889808971979360a.html](https://www.money.pl/pieniadze/slynny-inwestor-i-miliarder-radzi-jak-zalozyc-biznes-z-ktorego-beda-duze-pieniadze-6889808971979360a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-03 07:18:53+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e9334beb-8f75-444e-9f75-b827640a9e67" width="308" /> Jeśli myślisz, że pozyskanie kapitału zewnętrznego jest najlepszym sposobem na rozkręcenie biznesu, to według Marka Cubana jesteś w błędzie. Podczas panelu na festiwalu SXSW miliarder stwierdził, że najlepiej rozpoczynać działalność "z możliwie jak najmniejszą ilością pieniędzy" – informuje serwis CNBC.

## Nowe mocarstwo na horyzoncie. "Indie chcą być drugą fabryką świata"
 - [https://www.money.pl/gospodarka/nowe-mocarstwo-na-horyzoncie-indie-chca-byc-druga-fabryka-swiata-6892241602902592a.html](https://www.money.pl/gospodarka/nowe-mocarstwo-na-horyzoncie-indie-chca-byc-druga-fabryka-swiata-6892241602902592a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-03 05:39:42+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/52fc2696-95eb-4e1e-ab13-0298aaeff008" width="308" /> Są najludniejszym krajem świata i niedawno zostali piątą gospodarką, wyprzedzając Wlk. Brytanię. - Indie są w czołówce najważniejszych państw świata. Porzućmy protekcjonalne i europocentryczne wyobrażenia o nich, bo stracimy. To atrakcyjny rynek i inwestor - uważa Bartłomiej Radziejewski, prezes thinkzine’u Nowa Konfederacja.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 03.05.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-03-05-2023-6893937456114464a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-03-05-2023-6893937456114464a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-03 05:03:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 03.05.2023. W środę za jednego dolara (USD) trzeba zapłacić 4.1507 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 03.05.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-03-05-2023-6893937457539872a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-03-05-2023-6893937457539872a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-03 05:03:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 03.05.2023. W środę za jedno euro (EUR) trzeba zapłacić 4.5757 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 03.05.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-03-05-2023-6893937457498912a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-03-05-2023-6893937457498912a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-03 05:03:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 03.05.2023. W środę za jednego franka (CHF) trzeba zapłacić 4.6569 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 03.05.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-03-05-2023-6893937455921920a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-03-05-2023-6893937455921920a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-05-03 05:03:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 03.05.2023. W środę za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.1846 zł.

