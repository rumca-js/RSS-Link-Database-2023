# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Matura 2023. Co grozi za ściąganie na maturze? Bezlitosne zasady
 - [https://wydarzenia.interia.pl/raport-matura-2023/news-matura-2023-co-grozi-za-sciaganie-na-maturze-bezlitosne-zasa,nId,6739008](https://wydarzenia.interia.pl/raport-matura-2023/news-matura-2023-co-grozi-za-sciaganie-na-maturze-bezlitosne-zasa,nId,6739008)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-05-03 05:31:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-matura-2023/news-matura-2023-co-grozi-za-sciaganie-na-maturze-bezlitosne-zasa,nId,6739008"><img align="left" alt="Matura 2023. Co grozi za ściąganie na maturze? Bezlitosne zasady" src="https://i.iplsc.com/matura-2023-co-grozi-za-sciaganie-na-maturze-bezlitosne-zasa/000H2NTMTHW7AS47-C321.jpg" /></a>Wraz z początkiem maja uczniowie w całej Polsce przystąpią do matury 2023. Dla jednych to wielki sprawdzian wiedzy, dla drugich zaś sprawdzian umiejętności ściągania. Każdego roku nie brakuje chętnych, którzy próbują oszukiwać, nie zważając na surowe konsekwencje. Co grozi za ściąganie na maturze? Wyjaśniamy.</p><br clear="all" />

