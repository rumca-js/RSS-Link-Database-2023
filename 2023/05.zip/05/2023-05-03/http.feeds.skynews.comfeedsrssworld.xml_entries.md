# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Ex-Brazil president's home searched by police probing 'fake COVID vaccine cards'
 - [https://news.sky.com/story/brazil-ex-president-jair-bolsonaros-home-searched-by-police-probing-fake-covid-vaccine-cards-12872367](https://news.sky.com/story/brazil-ex-president-jair-bolsonaros-home-searched-by-police-probing-fake-covid-vaccine-cards-12872367)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 19:04:00+00:00

The home of Brazil's ex-president Jair Bolsonaro has been searched by police investigating COVID-19 vaccine cards allegedly being falsified.

## Cristiano Ronaldo named highest paid athlete, as Forbes reveals the top ten most expensive sports stars
 - [https://news.sky.com/story/top-ten-most-expensive-sports-stars-cristiano-ronaldo-highest-paid-athlete-forbes-reveals-12872252](https://news.sky.com/story/top-ten-most-expensive-sports-stars-cristiano-ronaldo-highest-paid-athlete-forbes-reveals-12872252)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 15:34:00+00:00

Portuguese football star Cristiano Ronaldo has been named the world's highest paid athlete, thanks to a big money move to Saudi Arabia, according to Forbes.

## Drone attack probably wasn't assassination attempt but you can't blame Russia for making the most of it
 - [https://news.sky.com/story/moscow-drone-attack-probably-wasnt-assassination-attempt-but-you-cant-blame-russia-for-making-the-most-of-it-12872254](https://news.sky.com/story/moscow-drone-attack-probably-wasnt-assassination-attempt-but-you-cant-blame-russia-for-making-the-most-of-it-12872254)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 15:28:00+00:00

Whoever flew a drone into the Kremlin knew what they were doing. The footage is spectacular.

## Iran seizes second oil tanker in a week in 'threat to global economy'
 - [https://news.sky.com/story/iran-seizes-second-oil-tanker-in-a-week-as-tensions-with-us-increase-12872187](https://news.sky.com/story/iran-seizes-second-oil-tanker-in-a-week-as-tensions-with-us-increase-12872187)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 13:52:00+00:00

Iran has seized a second oil tanker in Gulf waters in a week as tensions with the US increase.

## Any Russian threat to Eurovision voting will be dealt with, MPs told
 - [https://news.sky.com/story/eurovision-mp-seeks-assurances-contest-voting-will-be-protected-from-russian-threats-12872164](https://news.sky.com/story/eurovision-mp-seeks-assurances-contest-voting-will-be-protected-from-russian-threats-12872164)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 13:14:00+00:00

Threats to voting at the Eurovision song contest in Liverpool from Russian agents or cyber attacks will be dealt with by the UK's security experts, MPs have been assured.

## Kremlin claims it foiled two drones in 'planned terrorist act' on Putin's residence
 - [https://news.sky.com/story/kremlin-claims-it-foiled-two-drones-in-planned-terrorist-act-on-putins-residence-12872091](https://news.sky.com/story/kremlin-claims-it-foiled-two-drones-in-planned-terrorist-act-on-putins-residence-12872091)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 12:01:00+00:00

Russia has claimed it stopped two drone attacks on Vladimir Putin's presidential home overnight.

## Inside war-torn Sudan where people are trapped in prison of urban warfare
 - [https://news.sky.com/story/inside-war-torn-sudan-where-people-are-trapped-in-prison-of-urban-warfare-12871994](https://news.sky.com/story/inside-war-torn-sudan-where-people-are-trapped-in-prison-of-urban-warfare-12871994)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 09:59:00+00:00

Smoky spectres climb up the Khartoum skyline. A pop goes off in the distance and there is a slow rumble of thunder before another pillar builds upwards.

## The million dollar streets strewn with bodies contorted by the effects of fentanyl
 - [https://news.sky.com/story/the-million-dollar-streets-strewn-with-bodies-contorted-by-the-effects-of-fentanyl-12871961](https://news.sky.com/story/the-million-dollar-streets-strewn-with-bodies-contorted-by-the-effects-of-fentanyl-12871961)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 09:32:00+00:00

Bodies are strewn on the doorstep of San Francisco's main government building, contorted by the effects of fentanyl, a painkiller 100 times more potent than morphine.

## Boy kills at least one and injures five in Belgrade school shooting
 - [https://news.sky.com/story/boy-kills-one-and-injures-five-in-belgrade-school-shooting-12871917](https://news.sky.com/story/boy-kills-one-and-injures-five-in-belgrade-school-shooting-12871917)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 08:48:00+00:00

A 14-year-old boy shot his teacher before opening fire on other students and security guards in a school shooting in Serbia which has left one dead and five injured, police have said.

## Russian 'ghost ships' pictured near pipeline explosion site days before blasts
 - [https://news.sky.com/story/russian-ghost-ships-with-underwater-capabilities-circled-nord-stream-explosion-site-documentary-claims-12871910](https://news.sky.com/story/russian-ghost-ships-with-underwater-capabilities-circled-nord-stream-explosion-site-documentary-claims-12871910)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 08:39:00+00:00

Russian navy vessels able to perform underwater operations were present near the sabotaged Nord Stream gas pipelines prior to mysterious blasts in September, according to an investigative documentary.

## Lionel Messi suspended by PSG for unauthorised trip to Saudi Arabia
 - [https://news.sky.com/story/lionel-messi-suspended-by-psg-for-unauthorised-trip-to-saudi-arabia-12871905](https://news.sky.com/story/lionel-messi-suspended-by-psg-for-unauthorised-trip-to-saudi-arabia-12871905)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 08:35:00+00:00

Lionel&#160;Messi&#160;has been suspended by Paris Saint-Germain for making a personal promotional trip to Saudi Arabia without the club's permission.

## Russia's Victory Day celebrations scaled back over fears of attack
 - [https://news.sky.com/story/ukraine-war-russias-victory-day-celebrations-scaled-back-over-fears-of-attack-12871894](https://news.sky.com/story/ukraine-war-russias-victory-day-celebrations-scaled-back-over-fears-of-attack-12871894)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 08:22:00+00:00

Security is being beefed up in Moscow and several Russian regions have announced they are scaling back this year's Victory Day celebrations due to fears pro-Ukrainian saboteurs could target the festivities.

## Stab wounds to heart and lung killed 'brilliant' app founder
 - [https://news.sky.com/story/cash-app-founder-bob-lee-was-stabbed-in-the-heart-and-lung-post-mortem-finds-12871885](https://news.sky.com/story/cash-app-founder-bob-lee-was-stabbed-in-the-heart-and-lung-post-mortem-finds-12871885)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 08:05:00+00:00

Cash App founder Bob Lee died during surgery for stab wounds that pierced his heart and a lung.

## Teenage girl dies after horse knocks her off during contest
 - [https://news.sky.com/story/teenage-girl-dies-after-horse-knocks-her-off-during-contest-12871850](https://news.sky.com/story/teenage-girl-dies-after-horse-knocks-her-off-during-contest-12871850)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 07:11:00+00:00

A teenager has died in Florida after being knocked off her horse during a contest.

## More than 150 arrested across Europe after investigation into Italy's most powerful mafia group
 - [https://news.sky.com/story/more-than-100-arrested-across-europe-after-investigation-into-italys-most-powerful-mafia-group-12871852](https://news.sky.com/story/more-than-100-arrested-across-europe-after-investigation-into-italys-most-powerful-mafia-group-12871852)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 07:09:00+00:00

More than 150 people have been arrested across Germany, Spain and Italy after a three-year investigation into a powerful Italian mafia group.

## 'Fentanyl steals your friends': Pills bought on social media are killing kids in classrooms and in their beds
 - [https://news.sky.com/story/fentanyl-steals-your-friends-pills-bought-on-social-media-are-killing-kids-in-classrooms-and-in-their-beds-12871799](https://news.sky.com/story/fentanyl-steals-your-friends-pills-bought-on-social-media-are-killing-kids-in-classrooms-and-in-their-beds-12871799)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 05:53:00+00:00

All over America, families are being broken by fentanyl.

## Remains of fisherman who vanished found inside two crocodiles
 - [https://news.sky.com/story/human-remains-found-inside-two-crocodiles-after-search-for-missing-fisherman-in-australia-12871782](https://news.sky.com/story/human-remains-found-inside-two-crocodiles-after-search-for-missing-fisherman-in-australia-12871782)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-05-03 04:53:00+00:00

Human remains of a missing fisherman have been found inside two crocodiles in a remote part of northern Queensland in Australia.

