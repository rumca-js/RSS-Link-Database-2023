# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Tucker Carlson to make first public appearance since leaving Fox News
 - [http://www.msn.com/en-us/news/us/tucker-carlson-to-make-first-public-appearance-since-leaving-fox-news/ar-AA1aI9L3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tucker-carlson-to-make-first-public-appearance-since-leaving-fox-news/ar-AA1aI9L3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 23:31:45.993050+00:00



## Judge tosses Trump lawsuit against New York Times
 - [http://www.msn.com/en-us/news/politics/judge-tosses-trump-lawsuit-against-new-york-times/ar-AA1aHUfg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/judge-tosses-trump-lawsuit-against-new-york-times/ar-AA1aHUfg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 23:31:45.983613+00:00



## Trump suit against New York Times thrown out by state Supreme Court
 - [http://www.msn.com/en-us/news/politics/trump-suit-against-new-york-times-thrown-out-by-state-supreme-court/ar-AA1aIeZ5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-suit-against-new-york-times-thrown-out-by-state-supreme-court/ar-AA1aIeZ5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 23:31:45.975264+00:00



## 7 people found dead in Oklahoma were shot in the head in apparent murder-suicide, authorities say
 - [http://www.msn.com/en-us/news/crime/7-people-found-dead-in-oklahoma-were-shot-in-the-head-in-apparent-murder-suicide-authorities-say/ar-AA1aHWSS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/7-people-found-dead-in-oklahoma-were-shot-in-the-head-in-apparent-murder-suicide-authorities-say/ar-AA1aHWSS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 23:31:45.966437+00:00



## A look at the mom and 5 teenagers killed in rural Oklahoma
 - [http://www.msn.com/en-us/news/us/a-look-at-the-mom-and-5-teenagers-killed-in-rural-oklahoma/ar-AA1aI4DF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-look-at-the-mom-and-5-teenagers-killed-in-rural-oklahoma/ar-AA1aI4DF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 23:31:45.958108+00:00



## Beaten and forced to flee Uganda for being gay
 - [http://www.msn.com/en-us/news/world/beaten-and-forced-to-flee-uganda-for-being-gay/ar-AA1aI4MI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/beaten-and-forced-to-flee-uganda-for-being-gay/ar-AA1aI4MI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 23:31:45.949588+00:00



## Death of man on NYC subway ruled a homicide
 - [http://www.msn.com/en-us/news/crime/death-of-man-on-nyc-subway-ruled-a-homicide/ar-AA1aGW86?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/death-of-man-on-nyc-subway-ruled-a-homicide/ar-AA1aGW86?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 23:31:45.941069+00:00



## Why didn't the state budget debate go all night? This is the reason.
 - [http://www.msn.com/en-us/news/politics/why-didn-t-the-state-budget-debate-go-all-night-this-is-the-reason/ar-AA1aIcsU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/why-didn-t-the-state-budget-debate-go-all-night-this-is-the-reason/ar-AA1aIcsU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 23:31:45.932513+00:00



## Four Possibilities for the Kremlin Attack
 - [http://www.msn.com/en-us/news/world/four-possibilities-for-the-kremlin-attack/ar-AA1aHv1J?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/four-possibilities-for-the-kremlin-attack/ar-AA1aHv1J?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 22:31:28.153166+00:00



## Politifact defends Randi Weingarten: ‘Misleading’ to claim she opposed reopening schools
 - [http://www.msn.com/en-us/news/us/politifact-defends-randi-weingarten-misleading-to-claim-she-opposed-reopening-schools/ar-AA1aHxqd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/politifact-defends-randi-weingarten-misleading-to-claim-she-opposed-reopening-schools/ar-AA1aHxqd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 22:31:28.143608+00:00



## Details in the drone incident the Kremlin says aimed to assassinate Putin 'don't quite add up.' Experts have 3 theories on what happened.
 - [http://www.msn.com/en-us/news/world/details-in-the-drone-incident-the-kremlin-says-aimed-to-assassinate-putin-don-t-quite-add-up-experts-have-3-theories-on-what-happened/ar-AA1aHxmV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/details-in-the-drone-incident-the-kremlin-says-aimed-to-assassinate-putin-don-t-quite-add-up-experts-have-3-theories-on-what-happened/ar-AA1aHxmV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 22:31:28.134857+00:00



## Four ways Biden is boosting fossil fuels — and drawing heat for it
 - [http://www.msn.com/en-us/news/politics/four-ways-biden-is-boosting-fossil-fuels-and-drawing-heat-for-it/ar-AA1aHqhq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/four-ways-biden-is-boosting-fossil-fuels-and-drawing-heat-for-it/ar-AA1aHqhq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 22:31:28.126606+00:00



## Press Freedom ‘Bad’ in 7 in 10 Countries Globally, Report Finds
 - [http://www.msn.com/en-us/news/world/press-freedom-bad-in-7-in-10-countries-globally-report-finds/ar-AA1aHnWN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/press-freedom-bad-in-7-in-10-countries-globally-report-finds/ar-AA1aHnWN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 22:31:28.116168+00:00



## Why nationalities matter as US braces for migration surge
 - [http://www.msn.com/en-us/news/world/why-nationalities-matter-as-us-braces-for-migration-surge/ar-AA1aHCxM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/why-nationalities-matter-as-us-braces-for-migration-surge/ar-AA1aHCxM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 22:31:28.108283+00:00



## Auto union withholds support for Biden, citing electric vehicles
 - [http://www.msn.com/en-us/news/politics/auto-union-withholds-support-for-biden-citing-electric-vehicles/ar-AA1aHCAB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/auto-union-withholds-support-for-biden-citing-electric-vehicles/ar-AA1aHCAB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 22:31:28.099658+00:00



## Man fatally shot during altercation at Tesla charging station, authorities say
 - [http://www.msn.com/en-us/news/crime/man-fatally-shot-during-altercation-at-tesla-charging-station-authorities-say/ar-AA1aHa5J?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/man-fatally-shot-during-altercation-at-tesla-charging-station-authorities-say/ar-AA1aHa5J?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 22:31:28.088772+00:00



## Bernie Sanders will introduce measure to raise minimum wage to $17: Report
 - [http://www.msn.com/en-us/news/politics/bernie-sanders-will-introduce-measure-to-raise-minimum-wage-to-17-report/ar-AA1aHpMJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bernie-sanders-will-introduce-measure-to-raise-minimum-wage-to-17-report/ar-AA1aHpMJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 21:31:46.016735+00:00



## At UN, world's divided nations agree there's little trust
 - [http://www.msn.com/en-us/news/world/at-un-world-s-divided-nations-agree-there-s-little-trust/ar-AA1aHh2Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/at-un-world-s-divided-nations-agree-there-s-little-trust/ar-AA1aHh2Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 21:31:46.008313+00:00



## Alex Murdaugh admits he 'invented' the story for insurance about housekeeper tripping over the dogs to her death
 - [http://www.msn.com/en-us/news/crime/alex-murdaugh-admits-he-invented-the-story-for-insurance-about-housekeeper-tripping-over-the-dogs-to-her-death/ar-AA1aHnsf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/alex-murdaugh-admits-he-invented-the-story-for-insurance-about-housekeeper-tripping-over-the-dogs-to-her-death/ar-AA1aHnsf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 21:31:45.999835+00:00



## First-ever RSV vaccine approved by FDA for adults 60 and over
 - [http://www.msn.com/en-us/health/health-news/first-ever-rsv-vaccine-approved-by-fda-for-adults-60-and-over/ar-AA1aHBZO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/first-ever-rsv-vaccine-approved-by-fda-for-adults-60-and-over/ar-AA1aHBZO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 21:31:45.991200+00:00



## Republicans subpoena FBI for document alleging unspecified ‘criminal scheme’ involving Biden
 - [http://www.msn.com/en-us/news/politics/republicans-subpoena-fbi-for-document-alleging-unspecified-criminal-scheme-involving-biden/ar-AA1aHzAz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-subpoena-fbi-for-document-alleging-unspecified-criminal-scheme-involving-biden/ar-AA1aHzAz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 21:31:45.982041+00:00



## Laws Cracking Down on British Protesters Fast-Tracked Before Coronation
 - [http://www.msn.com/en-us/news/world/laws-cracking-down-on-british-protesters-fast-tracked-before-coronation/ar-AA1aHlzy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/laws-cracking-down-on-british-protesters-fast-tracked-before-coronation/ar-AA1aHlzy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 21:31:45.972480+00:00



## Dozens on last UK evacuation flights out of Sudan
 - [http://www.msn.com/en-us/news/world/dozens-on-last-uk-evacuation-flights-out-of-sudan/ar-AA1aHuEN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/dozens-on-last-uk-evacuation-flights-out-of-sudan/ar-AA1aHuEN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 21:31:45.963512+00:00



## Teens arrested in rock-throwing spree now face 13 charges each
 - [http://www.msn.com/en-us/news/crime/teens-arrested-in-rock-throwing-spree-now-face-13-charges-each/ar-AA1aHug5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/teens-arrested-in-rock-throwing-spree-now-face-13-charges-each/ar-AA1aHug5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 21:31:45.953481+00:00



## Watch: Federal Reserve Raises Interest Rate by Quarter-Point
 - [http://www.msn.com/en-us/money/markets/watch-federal-reserve-raises-interest-rate-by-quarter-point/vi-AA1aHp7e?srcref=rss](http://www.msn.com/en-us/money/markets/watch-federal-reserve-raises-interest-rate-by-quarter-point/vi-AA1aHp7e?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:35:02.568921+00:00



## Syrian refugees fearful as Lebanon steps up deportations
 - [http://www.msn.com/en-us/news/world/syrian-refugees-fearful-as-lebanon-steps-up-deportations/ar-AA1aGTuN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/syrian-refugees-fearful-as-lebanon-steps-up-deportations/ar-AA1aGTuN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:35:02.558619+00:00



## Madison’s Montpelier makes big change, but its wokeness may remain
 - [http://www.msn.com/en-us/news/us/madison-s-montpelier-makes-big-change-but-its-wokeness-may-remain/ar-AA1aHgnb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/madison-s-montpelier-makes-big-change-but-its-wokeness-may-remain/ar-AA1aHgnb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:35:02.550128+00:00



## California prisoner who almost swallowed a staple leads hunger strike to protest jail conditions
 - [http://www.msn.com/en-us/news/crime/california-prisoner-who-almost-swallowed-a-staple-leads-hunger-strike-to-protest-jail-conditions/ar-AA1aGTrZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/california-prisoner-who-almost-swallowed-a-staple-leads-hunger-strike-to-protest-jail-conditions/ar-AA1aGTrZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:35:02.542664+00:00



## Real or not, reported Kremlin drone attack unsettles Russia
 - [http://www.msn.com/en-us/news/world/real-or-not-reported-kremlin-drone-attack-unsettles-russia/ar-AA1aHmUa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/real-or-not-reported-kremlin-drone-attack-unsettles-russia/ar-AA1aHmUa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:35:02.509647+00:00



## No charges filed in man's death after being choked by passenger on NYC subway
 - [http://www.msn.com/en-us/news/crime/no-charges-filed-in-man-s-death-after-being-choked-by-passenger-on-nyc-subway/ar-AA1aGW86?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/no-charges-filed-in-man-s-death-after-being-choked-by-passenger-on-nyc-subway/ar-AA1aGW86?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:35:02.500379+00:00



## Illinois closes the book on book bans
 - [http://www.msn.com/en-us/news/politics/illinois-closes-the-book-on-book-bans/ar-AA1aHphy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/illinois-closes-the-book-on-book-bans/ar-AA1aHphy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:35:02.491649+00:00



## Trump lawyers won’t call any witnesses in rape trial
 - [http://www.msn.com/en-us/news/politics/trump-lawyers-won-t-call-any-witnesses-in-rape-trial/ar-AA1aH9eg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-lawyers-won-t-call-any-witnesses-in-rape-trial/ar-AA1aH9eg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:35:00.848315+00:00



## New data shows COVID crime surge starting to recede. Can Republicans still rely on crime to counter Democrats' advantage on abortion?
 - [http://www.msn.com/en-us/news/politics/new-data-shows-covid-crime-surge-starting-to-recede-can-republicans-still-rely-on-crime-to-counter-democrats-advantage-on-abortion/ar-AA1aHmLu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/new-data-shows-covid-crime-surge-starting-to-recede-can-republicans-still-rely-on-crime-to-counter-democrats-advantage-on-abortion/ar-AA1aHmLu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:13:05.895737+00:00



## 'The Donald' forum user convicted of assaulting officers on Jan. 6
 - [http://www.msn.com/en-us/news/us/the-donald-forum-user-convicted-of-assaulting-officers-on-jan-6/ar-AA1aHkOy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-donald-forum-user-convicted-of-assaulting-officers-on-jan-6/ar-AA1aHkOy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:13:05.887816+00:00



## Suspect at large in shooting at Atlanta medical facility that left 1 dead and multiple injured, police say
 - [http://www.msn.com/en-us/news/us/suspect-at-large-in-shooting-at-atlanta-medical-facility-that-left-1-dead-and-multiple-injured-police-say/ar-AA1aH2AB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/suspect-at-large-in-shooting-at-atlanta-medical-facility-that-left-1-dead-and-multiple-injured-police-say/ar-AA1aH2AB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:13:05.879818+00:00



## Gov. Ron DeSantis paints Florida as the 'anti-New York' and 'anti-California'
 - [http://www.msn.com/en-us/news/politics/gov-ron-desantis-paints-florida-as-the-anti-new-york-and-anti-california/ar-AA1aH95T?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gov-ron-desantis-paints-florida-as-the-anti-new-york-and-anti-california/ar-AA1aH95T?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:13:05.871817+00:00



## College baseball player struck by stray bullet suffers partial paralysis, other severe injuries: report
 - [http://www.msn.com/en-us/news/crime/college-baseball-player-struck-by-stray-bullet-suffers-partial-paralysis-other-severe-injuries-report/ar-AA1aHkWM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/college-baseball-player-struck-by-stray-bullet-suffers-partial-paralysis-other-severe-injuries-report/ar-AA1aHkWM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:13:05.864239+00:00



## US to send Ukraine another $300M in weapons ahead of spring offensive
 - [http://www.msn.com/en-us/news/politics/us-to-send-ukraine-another-300m-in-weapons-ahead-of-spring-offensive/ar-AA1aHgbQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/us-to-send-ukraine-another-300m-in-weapons-ahead-of-spring-offensive/ar-AA1aHgbQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:13:05.853951+00:00



## New legislation to counter China pushed by Senate Democrats
 - [http://www.msn.com/en-us/news/politics/new-legislation-to-counter-china-pushed-by-senate-democrats/ar-AA1aGTkv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/new-legislation-to-counter-china-pushed-by-senate-democrats/ar-AA1aGTkv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 20:13:05.844984+00:00



## 258 million people worldwide faced acute food insecurity in 2022, report says
 - [http://www.msn.com/en-us/news/world/258-million-people-worldwide-faced-acute-food-insecurity-in-2022-report-says/ar-AA1aH5HL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/258-million-people-worldwide-faced-acute-food-insecurity-in-2022-report-says/ar-AA1aH5HL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 19:25:32.207950+00:00



## Washington Governor Forces Lawmakers to Reconsider Drug Crime Bill
 - [http://www.msn.com/en-us/news/politics/washington-governor-forces-lawmakers-to-reconsider-drug-crime-bill/ar-AA1aGWeM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/washington-governor-forces-lawmakers-to-reconsider-drug-crime-bill/ar-AA1aGWeM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 19:25:32.197247+00:00



## Jim Jordan demands answers on why more Supreme Court protesters weren't arrested
 - [http://www.msn.com/en-us/news/politics/jim-jordan-demands-answers-on-why-more-supreme-court-protesters-weren-t-arrested/ar-AA1aHatc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jim-jordan-demands-answers-on-why-more-supreme-court-protesters-weren-t-arrested/ar-AA1aHatc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 19:25:32.189639+00:00



## Kyrsten Sinema calls out Karine Jean-Pierre: 'Anyone with eyes' can see this is not true
 - [http://www.msn.com/en-us/news/politics/kyrsten-sinema-calls-out-karine-jean-pierre-anyone-with-eyes-can-see-this-is-not-true/ar-AA1aH8rZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kyrsten-sinema-calls-out-karine-jean-pierre-anyone-with-eyes-can-see-this-is-not-true/ar-AA1aH8rZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 19:25:32.181719+00:00



## Broadway performers send off Starlite Deli owners with viral performance viewed around the world
 - [http://www.msn.com/en-us/news/world/broadway-performers-send-off-starlite-deli-owners-with-viral-performance-viewed-around-the-world/ar-AA1aH3ed?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/broadway-performers-send-off-starlite-deli-owners-with-viral-performance-viewed-around-the-world/ar-AA1aH3ed?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 19:25:32.173772+00:00



## NJ GOP seeks wind projects halt to see if whales benefit
 - [http://www.msn.com/en-us/news/us/nj-gop-seeks-wind-projects-halt-to-see-if-whales-benefit/ar-AA1aGYBB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nj-gop-seeks-wind-projects-halt-to-see-if-whales-benefit/ar-AA1aGYBB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 19:25:32.165909+00:00



## Expansion of ‘Don’t Say Gay’ passes Florida Senate, heads to DeSantis’s desk
 - [http://www.msn.com/en-us/news/politics/expansion-of-don-t-say-gay-passes-florida-senate-heads-to-desantis-s-desk/ar-AA1aHay4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/expansion-of-don-t-say-gay-passes-florida-senate-heads-to-desantis-s-desk/ar-AA1aHay4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 19:25:32.157658+00:00



## Legal experts: "Almost certain" that Trump will be hit with new charges over the summer
 - [http://www.msn.com/en-us/news/politics/legal-experts-almost-certain-that-trump-will-be-hit-with-new-charges-over-the-summer/ar-AA1aHjOL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/legal-experts-almost-certain-that-trump-will-be-hit-with-new-charges-over-the-summer/ar-AA1aHjOL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 18:25:36.293342+00:00



## California lawmaker running for Congress is arrested for drunk driving
 - [http://www.msn.com/en-us/news/politics/california-lawmaker-running-for-congress-is-arrested-for-drunk-driving/ar-AA1aHciA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/california-lawmaker-running-for-congress-is-arrested-for-drunk-driving/ar-AA1aHciA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 18:25:36.283712+00:00



## North Carolina legislators reach veto-proof abortion restrictions
 - [http://www.msn.com/en-us/news/politics/north-carolina-legislators-reach-veto-proof-abortion-restrictions/ar-AA1aHjZv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/north-carolina-legislators-reach-veto-proof-abortion-restrictions/ar-AA1aHjZv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 18:25:36.275372+00:00



## ‘Large’ snake causes power outage at Virginia intersection during morning rush hour
 - [http://www.msn.com/en-us/news/us/large-snake-causes-power-outage-at-virginia-intersection-during-morning-rush-hour/ar-AA1aH2yd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/large-snake-causes-power-outage-at-virginia-intersection-during-morning-rush-hour/ar-AA1aH2yd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 18:25:36.266528+00:00



## Atlanta mass shooting live updates: 1 killed, 4 hurt; suspect at large
 - [http://www.msn.com/en-us/news/crime/atlanta-mass-shooting-live-updates-1-killed-4-hurt-suspect-at-large/ar-AA1aGV9d?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/atlanta-mass-shooting-live-updates-1-killed-4-hurt-suspect-at-large/ar-AA1aGV9d?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 18:25:36.258712+00:00



## Cops Bust ‘Sextortion’ Ring That Led Michigan Teen to Kill Himself
 - [http://www.msn.com/en-us/news/crime/cops-bust-sextortion-ring-that-led-michigan-teen-to-kill-himself/ar-AA1aHjZf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/cops-bust-sextortion-ring-that-led-michigan-teen-to-kill-himself/ar-AA1aHjZf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 18:25:36.250747+00:00



## Senate Democrats unveil China competition push 2.0
 - [http://www.msn.com/en-us/news/politics/senate-democrats-unveil-china-competition-push-2-0/ar-AA1aGVMy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-democrats-unveil-china-competition-push-2-0/ar-AA1aGVMy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 18:25:36.242851+00:00



## Hackers hijacked a university's emergency system to threaten students and faculty
 - [http://www.msn.com/en-us/news/us/hackers-hijacked-a-university-s-emergency-system-to-threaten-students-and-faculty/ar-AA1aHhAj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/hackers-hijacked-a-university-s-emergency-system-to-threaten-students-and-faculty/ar-AA1aHhAj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 18:25:36.233390+00:00



## If You Pay for Cardboard Boxes, You're Moving All Wrong
 - [http://www.msn.com/en-us/news/technology/if-you-pay-for-cardboard-boxes-you-re-moving-all-wrong/ar-AA1aA6t5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/if-you-pay-for-cardboard-boxes-you-re-moving-all-wrong/ar-AA1aA6t5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 17:25:45.263269+00:00



## 4 dangers that most worry AI pioneer Geoffrey Hinton
 - [http://www.msn.com/en-us/news/technology/4-dangers-that-most-worry-ai-pioneer-geoffrey-hinton/ar-AA1aGyRt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/4-dangers-that-most-worry-ai-pioneer-geoffrey-hinton/ar-AA1aGyRt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 17:25:45.256283+00:00



## Man dies after NYC subway rider puts him in chokehold during train altercation
 - [http://www.msn.com/en-us/news/us/man-dies-after-nyc-subway-rider-puts-him-in-chokehold-during-train-altercation/ar-AA1aGXe5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/man-dies-after-nyc-subway-rider-puts-him-in-chokehold-during-train-altercation/ar-AA1aGXe5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 17:25:45.248852+00:00



## Putin assassination claim: Embarrassing failure for Moscow?
 - [http://www.msn.com/en-us/news/world/putin-assassination-claim-embarrassing-failure-for-moscow/ar-AA1aH73w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-assassination-claim-embarrassing-failure-for-moscow/ar-AA1aH73w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 17:25:45.239929+00:00



## Another hint about Tucker Carlson’s firing: A racist text
 - [http://www.msn.com/en-us/news/us/another-hint-about-tucker-carlson-s-firing-a-racist-text/ar-AA1aGVbB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/another-hint-about-tucker-carlson-s-firing-a-racist-text/ar-AA1aGVbB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 17:25:45.232454+00:00



## Meta faces new restrictions over FTC allegations Facebook violated kids’ privacy rules
 - [http://www.msn.com/en-us/news/politics/meta-faces-new-restrictions-over-ftc-allegations-facebook-violated-kids-privacy-rules/ar-AA1aH76W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/meta-faces-new-restrictions-over-ftc-allegations-facebook-violated-kids-privacy-rules/ar-AA1aH76W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 17:25:45.223947+00:00



## Virginia police officer narrowly avoids getting hit by out-of-control BMW
 - [http://www.msn.com/en-us/news/us/virginia-police-officer-narrowly-avoids-getting-hit-by-out-of-control-bmw/ar-AA1aGOnV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/virginia-police-officer-narrowly-avoids-getting-hit-by-out-of-control-bmw/ar-AA1aGOnV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 17:25:45.216110+00:00



## Trump rape accuser E. Jean Carroll 'didn't blame the store,' psychologist testifies
 - [http://www.msn.com/en-us/news/politics/trump-rape-accuser-e-jean-carroll-didn-t-blame-the-store-psychologist-testifies/ar-AA1aGty5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-rape-accuser-e-jean-carroll-didn-t-blame-the-store-psychologist-testifies/ar-AA1aGty5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 17:25:45.207939+00:00



## What is the debt ceiling, and could Biden avoid a financial crisis with the 14th Amendment?
 - [http://www.msn.com/en-us/news/politics/what-is-the-debt-ceiling-and-could-biden-avoid-a-financial-crisis-with-the-14th-amendment/ar-AA1aGIMe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/what-is-the-debt-ceiling-and-could-biden-avoid-a-financial-crisis-with-the-14th-amendment/ar-AA1aGIMe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 16:25:43.557039+00:00



## Ex-Biden aide didn’t know she unpacked classified documents in Penn office: Report
 - [http://www.msn.com/en-us/news/politics/ex-biden-aide-didn-t-know-she-unpacked-classified-documents-in-penn-office-report/ar-AA1aGL1H?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ex-biden-aide-didn-t-know-she-unpacked-classified-documents-in-penn-office-report/ar-AA1aGL1H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 16:25:43.547694+00:00



## Mom Vacuums Her Cat Once, Now He Demands It All the Time
 - [http://www.msn.com/en-us/news/technology/mom-vacuums-her-cat-once-now-he-demands-it-all-the-time/ar-AA1aGL5p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/mom-vacuums-her-cat-once-now-he-demands-it-all-the-time/ar-AA1aGL5p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 16:25:43.539233+00:00



## Hawaii’s Native language nearly vanished—this is the fight to bring it back
 - [http://www.msn.com/en-us/news/us/hawaii-s-native-language-nearly-vanished-this-is-the-fight-to-bring-it-back/ar-AA1aDh1t?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/hawaii-s-native-language-nearly-vanished-this-is-the-fight-to-bring-it-back/ar-AA1aDh1t?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 16:25:43.528614+00:00



## Texas mass shooting suspect found hiding in closet, wife also taken into custody
 - [http://www.msn.com/en-us/news/crime/texas-mass-shooting-suspect-found-hiding-in-closet-wife-also-taken-into-custody/ar-AA1aEP20?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/texas-mass-shooting-suspect-found-hiding-in-closet-wife-also-taken-into-custody/ar-AA1aEP20?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 16:25:43.521165+00:00



## Former Texas Rep calls for firing Mayorkas, blasts Biden over border policy: 'This administration is ignorant'
 - [http://www.msn.com/en-us/news/politics/former-texas-rep-calls-for-firing-mayorkas-blasts-biden-over-border-policy-this-administration-is-ignorant/ar-AA1aGWoH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/former-texas-rep-calls-for-firing-mayorkas-blasts-biden-over-border-policy-this-administration-is-ignorant/ar-AA1aGWoH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 16:25:43.512191+00:00



## Biden campaign focuses on economy in second ad for 2024
 - [http://www.msn.com/en-us/news/politics/biden-campaign-focuses-on-economy-in-second-ad-for-2024/ar-AA1aGy87?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-campaign-focuses-on-economy-in-second-ad-for-2024/ar-AA1aGy87?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 16:25:43.504766+00:00



## Biden's former executive assistant testified she didn't know about classified docs
 - [http://www.msn.com/en-us/news/politics/biden-s-former-executive-assistant-testified-she-didn-t-know-about-classified-docs/ar-AA1aGYTF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-s-former-executive-assistant-testified-she-didn-t-know-about-classified-docs/ar-AA1aGYTF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 16:25:43.495038+00:00



## School principal comes face-to-face with black bear
 - [http://www.msn.com/en-us/news/us/school-principal-comes-face-to-face-with-black-bear/vi-AA1aGq8g?srcref=rss](http://www.msn.com/en-us/news/us/school-principal-comes-face-to-face-with-black-bear/vi-AA1aGq8g?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 15:25:52.967554+00:00



## Russian Government Says Kremlin Hit by Ukraine Drones
 - [http://www.msn.com/en-us/news/world/russian-government-says-kremlin-hit-by-ukraine-drones/vi-AA1aG8Nv?srcref=rss](http://www.msn.com/en-us/news/world/russian-government-says-kremlin-hit-by-ukraine-drones/vi-AA1aG8Nv?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 14:25:28.481698+00:00



## Why you shouldn't get out of your car immediately after fender bender
 - [http://www.msn.com/en-us/news/crime/why-you-shouldn-t-get-out-of-your-car-immediately-after-fender-bender/ar-AA1aGrYt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/why-you-shouldn-t-get-out-of-your-car-immediately-after-fender-bender/ar-AA1aGrYt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 14:25:28.474217+00:00



## How Manchin and Sinema are helping Republicans plot a big win over Democrats and Biden
 - [http://www.msn.com/en-us/news/politics/how-manchin-and-sinema-are-helping-republicans-plot-a-big-win-over-democrats-and-biden/ar-AA1aGzst?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/how-manchin-and-sinema-are-helping-republicans-plot-a-big-win-over-democrats-and-biden/ar-AA1aGzst?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 14:25:28.466726+00:00



## Fossils or not? Nations split on how to meet climate goals
 - [http://www.msn.com/en-us/news/world/fossils-or-not-nations-split-on-how-to-meet-climate-goals/ar-AA1aGbfD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fossils-or-not-nations-split-on-how-to-meet-climate-goals/ar-AA1aGbfD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 14:25:28.459283+00:00



## Russia-Ukraine live updates: Russia says Ukraine tried to kill Putin in Kremlin
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-russia-says-ukraine-tried-to-kill-putin-in-kremlin/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-russia-says-ukraine-tried-to-kill-putin-in-kremlin/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 14:25:28.450758+00:00



## Map: These states had the highest turnouts in the midterm elections
 - [http://www.msn.com/en-us/news/us/map-these-states-had-the-highest-turnouts-in-the-midterm-elections/ar-AA1aGut9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/map-these-states-had-the-highest-turnouts-in-the-midterm-elections/ar-AA1aGut9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 14:25:28.443198+00:00



## Photo shows the moment lighting struck the launchpad as SpaceX's Falcon Heavy rocket was preparing for liftoff
 - [http://www.msn.com/en-us/news/technology/photo-shows-the-moment-lighting-struck-the-launchpad-as-spacex-s-falcon-heavy-rocket-was-preparing-for-liftoff/ar-AA1aGrXx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/photo-shows-the-moment-lighting-struck-the-launchpad-as-spacex-s-falcon-heavy-rocket-was-preparing-for-liftoff/ar-AA1aGrXx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 14:25:28.435557+00:00



## Ukraine rejects Russia’s claim of Kremlin drone attack
 - [http://www.msn.com/en-us/news/world/ukraine-rejects-russia-s-claim-of-kremlin-drone-attack/ar-AA1aGOG8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-rejects-russia-s-claim-of-kremlin-drone-attack/ar-AA1aGOG8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 14:25:28.427116+00:00



## Kremlin Accuses Ukraine of Trying to Assassinate Putin With Drones
 - [http://www.msn.com/en-us/news/world/kremlin-accuses-ukraine-of-trying-to-assassinate-putin-with-drones/ar-AA1aGdly?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/kremlin-accuses-ukraine-of-trying-to-assassinate-putin-with-drones/ar-AA1aGdly?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 13:25:51.064204+00:00



## Colin Allred announces campaign to challenge Cruz for Texas Senate seat
 - [http://www.msn.com/en-us/news/politics/colin-allred-announces-campaign-to-challenge-cruz-for-texas-senate-seat/ar-AA1aGl4q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/colin-allred-announces-campaign-to-challenge-cruz-for-texas-senate-seat/ar-AA1aGl4q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 13:25:51.054172+00:00



## When did we get so obsessed with unique baby names?
 - [http://www.msn.com/en-us/news/us/when-did-we-get-so-obsessed-with-unique-baby-names/ar-AA1aGgjq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/when-did-we-get-so-obsessed-with-unique-baby-names/ar-AA1aGgjq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 13:25:51.046201+00:00



## Several people are arrested after the Texas man accused of killing 5 neighbors is captured
 - [http://www.msn.com/en-us/news/crime/several-people-are-arrested-after-the-texas-man-accused-of-killing-5-neighbors-is-captured/ar-AA1aGmMz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/several-people-are-arrested-after-the-texas-man-accused-of-killing-5-neighbors-is-captured/ar-AA1aGmMz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 13:25:51.037465+00:00



## California reparations panel hints at $1.2 million payments to each Black resident
 - [http://www.msn.com/en-us/news/us/california-reparations-panel-hints-at-1-2-million-payments-to-each-black-resident/ar-AA1aGdug?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/california-reparations-panel-hints-at-1-2-million-payments-to-each-black-resident/ar-AA1aGdug?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 13:25:51.027669+00:00



## Judge: Synagogue massacre suspect can face death penalty
 - [http://www.msn.com/en-us/news/crime/judge-synagogue-massacre-suspect-can-face-death-penalty/ar-AA1aGiCr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/judge-synagogue-massacre-suspect-can-face-death-penalty/ar-AA1aGiCr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 13:25:51.018855+00:00



## Biden administration working with GOP to advance judicial nominees amid Feinstein absence
 - [http://www.msn.com/en-us/news/politics/biden-administration-working-with-gop-to-advance-judicial-nominees-amid-feinstein-absence/ar-AA1aGgph?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-administration-working-with-gop-to-advance-judicial-nominees-amid-feinstein-absence/ar-AA1aGgph?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 13:25:51.007634+00:00



## Russia Says It Downed Drone Attack on Putin’s Kremlin Residence
 - [http://www.msn.com/en-us/news/world/russia-says-it-downed-drone-attack-on-putin-s-kremlin-residence/ar-AA1aGki0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-says-it-downed-drone-attack-on-putin-s-kremlin-residence/ar-AA1aGki0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 12:25:39.845318+00:00



## You Should Change These Spotify Settings to Amp Up Your Music
 - [http://www.msn.com/en-us/news/technology/you-should-change-these-spotify-settings-to-amp-up-your-music/ar-AAQxC7S?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/you-should-change-these-spotify-settings-to-amp-up-your-music/ar-AAQxC7S?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 12:25:39.837820+00:00



## Al Franken thinks he knows the Supreme Court. Here's what he's missing
 - [http://www.msn.com/en-us/news/us/al-franken-thinks-he-knows-the-supreme-court-here-s-what-he-s-missing/ar-AA1aGhOk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/al-franken-thinks-he-knows-the-supreme-court-here-s-what-he-s-missing/ar-AA1aGhOk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 12:25:39.830147+00:00



## Editorial: The new anti-trash mantra should be reduce, recycle — and repair
 - [http://www.msn.com/en-us/news/technology/editorial-the-new-anti-trash-mantra-should-be-reduce-recycle-and-repair/ar-AA1aGa8p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/editorial-the-new-anti-trash-mantra-should-be-reduce-recycle-and-repair/ar-AA1aGa8p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 12:25:39.820284+00:00



## Among voters' choices today, choosing to raise or renew millages
 - [http://www.msn.com/en-us/news/us/among-voters-choices-today-choosing-to-raise-or-renew-millages/ar-AA1aFXLP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/among-voters-choices-today-choosing-to-raise-or-renew-millages/ar-AA1aFXLP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 12:25:39.812336+00:00



## Teen kills 8 children and school guard, police in Serbia say
 - [http://www.msn.com/en-us/news/politics/teen-kills-8-children-and-school-guard-police-in-serbia-say/ar-AA1aG2lT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/teen-kills-8-children-and-school-guard-police-in-serbia-say/ar-AA1aG2lT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 12:25:39.803752+00:00



## Human remains found inside 2 crocodiles believed to be missing fisherman
 - [http://www.msn.com/en-us/news/world/human-remains-found-inside-2-crocodiles-believed-to-be-missing-fisherman/ar-AA1aFCFh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/human-remains-found-inside-2-crocodiles-believed-to-be-missing-fisherman/ar-AA1aFCFh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 12:25:39.794895+00:00



## Kremlin accuses Ukraine of trying to assassinate Putin
 - [http://www.msn.com/en-us/news/world/kremlin-accuses-ukraine-of-trying-to-assassinate-putin/ar-AA1aG0lK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/kremlin-accuses-ukraine-of-trying-to-assassinate-putin/ar-AA1aG0lK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 12:25:39.785976+00:00



## Press freedom under 'unprecedented' attack - report
 - [http://www.msn.com/en-us/news/world/press-freedom-under-unprecedented-attack-report/ar-AA1aFWQ9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/press-freedom-under-unprecedented-attack-report/ar-AA1aFWQ9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 11:25:32.294663+00:00



## How Russia Could 'Deliberately Engineer' a Nuclear Disaster in Ukraine
 - [http://www.msn.com/en-us/news/world/how-russia-could-deliberately-engineer-a-nuclear-disaster-in-ukraine/ar-AA1aG6H7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/how-russia-could-deliberately-engineer-a-nuclear-disaster-in-ukraine/ar-AA1aG6H7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 11:25:32.286909+00:00



## ‘We’re All Worse Off Now’
 - [http://www.msn.com/en-us/news/world/we-re-all-worse-off-now/ar-AA1aG1Iw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/we-re-all-worse-off-now/ar-AA1aG1Iw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 11:25:32.279060+00:00



## King Charles’s coronation, decoded
 - [http://www.msn.com/en-us/news/world/king-charles-s-coronation-decoded/ar-AA1aG1CU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/king-charles-s-coronation-decoded/ar-AA1aG1CU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 11:25:32.271324+00:00



## McConnell treads warily around debt limit fight as fears of default catastrophe grow
 - [http://www.msn.com/en-us/news/politics/mcconnell-treads-warily-around-debt-limit-fight-as-fears-of-default-catastrophe-grow/ar-AA1aFG9S?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mcconnell-treads-warily-around-debt-limit-fight-as-fears-of-default-catastrophe-grow/ar-AA1aFG9S?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 11:25:32.263161+00:00



## Biden dispatches 1,500 troops to provide office support to Border Patrol ahead of expected migrant surge
 - [http://www.msn.com/en-us/news/us/biden-dispatches-1-500-troops-to-provide-office-support-to-border-patrol-ahead-of-expected-migrant-surge/ar-AA1aFUoe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/biden-dispatches-1-500-troops-to-provide-office-support-to-border-patrol-ahead-of-expected-migrant-surge/ar-AA1aFUoe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 11:25:32.255069+00:00



## US Navy platformed ‘drag queen influencer’ to attract youth to the military in hiring crisis
 - [http://www.msn.com/en-us/news/politics/us-navy-platformed-drag-queen-influencer-to-attract-youth-to-the-military-in-hiring-crisis/ar-AA1aGbZq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/us-navy-platformed-drag-queen-influencer-to-attract-youth-to-the-military-in-hiring-crisis/ar-AA1aGbZq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 11:25:32.217484+00:00



## US, Mexico reach migration deal as Title 42 deadline nears
 - [http://www.msn.com/en-us/news/world/us-mexico-reach-migration-deal-as-title-42-deadline-nears/ar-AA1aFWI8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-mexico-reach-migration-deal-as-title-42-deadline-nears/ar-AA1aFWI8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 11:25:32.207987+00:00



## Teen Gunman Kills Eight Children at School in Serbia, Police Say
 - [http://www.msn.com/en-us/news/world/teen-gunman-kills-eight-children-at-school-in-serbia-police-say/ar-AA1aFLjE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/teen-gunman-kills-eight-children-at-school-in-serbia-police-say/ar-AA1aFLjE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 10:27:34.455453+00:00



## What You Need to Know About Stillbirths
 - [http://www.msn.com/en-us/news/us/what-you-need-to-know-about-stillbirths/ar-AA1aFvDw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-you-need-to-know-about-stillbirths/ar-AA1aFvDw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 10:27:34.446580+00:00



## The Republican push to weaken child labor laws, explained
 - [http://www.msn.com/en-us/news/politics/the-republican-push-to-weaken-child-labor-laws-explained/ar-AA1aFSxk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-republican-push-to-weaken-child-labor-laws-explained/ar-AA1aFSxk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 10:27:34.437364+00:00



## Keeping teachers unions honest
 - [http://www.msn.com/en-us/news/world/keeping-teachers-unions-honest/ar-AA1aFDwr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/keeping-teachers-unions-honest/ar-AA1aFDwr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 10:27:34.428890+00:00



## Lawmakers throw cold water on short-term debt limit hike
 - [http://www.msn.com/en-us/news/politics/lawmakers-throw-cold-water-on-short-term-debt-limit-hike/ar-AA1aFDm1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lawmakers-throw-cold-water-on-short-term-debt-limit-hike/ar-AA1aFDm1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 10:27:34.420130+00:00



## Florida dentist accused of bludgeoning doctor with club on ritzy golf course
 - [http://www.msn.com/en-us/news/crime/florida-dentist-accused-of-bludgeoning-doctor-with-club-on-ritzy-golf-course/ar-AA1aFDoJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/florida-dentist-accused-of-bludgeoning-doctor-with-club-on-ritzy-golf-course/ar-AA1aFDoJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 10:27:34.412074+00:00



## Letters to the Editor: L.A. Times readers can't rescue every kid unable to afford UC
 - [http://www.msn.com/en-us/news/us/letters-to-the-editor-l-a-times-readers-can-t-rescue-every-kid-unable-to-afford-uc/ar-AA1aFQ8Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/letters-to-the-editor-l-a-times-readers-can-t-rescue-every-kid-unable-to-afford-uc/ar-AA1aFQ8Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 10:27:34.404369+00:00



## Palace weapons arrest comes amid coronations security push
 - [http://www.msn.com/en-us/news/world/palace-weapons-arrest-comes-amid-coronations-security-push/ar-AA1aFCk3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/palace-weapons-arrest-comes-amid-coronations-security-push/ar-AA1aFCk3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 09:27:45.535310+00:00



## Rwanda flooding: More than 100 killed in natural disaster
 - [http://www.msn.com/en-us/news/world/rwanda-flooding-more-than-100-killed-in-natural-disaster/ar-AA1aFPc7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/rwanda-flooding-more-than-100-killed-in-natural-disaster/ar-AA1aFPc7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 09:27:45.527760+00:00



## Princess Diana's Thoughts on Being 'Queen' Resurface Ahead of Coronation
 - [http://www.msn.com/en-us/news/world/princess-diana-s-thoughts-on-being-queen-resurface-ahead-of-coronation/ar-AA1aFKy2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/princess-diana-s-thoughts-on-being-queen-resurface-ahead-of-coronation/ar-AA1aFKy2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 09:27:45.517850+00:00



## A shocking video shows a Virginia officer dodging a near-fatal accident with a car that spiraled out of control and crashed
 - [http://www.msn.com/en-us/news/crime/a-shocking-video-shows-a-virginia-officer-dodging-a-near-fatal-accident-with-a-car-that-spiraled-out-of-control-and-crashed/ar-AA1aFMND?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-shocking-video-shows-a-virginia-officer-dodging-a-near-fatal-accident-with-a-car-that-spiraled-out-of-control-and-crashed/ar-AA1aFMND?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 09:27:45.509990+00:00



## Overinflated: The Journey of a Humble Tire Reveals Why Prices Are Still So High
 - [http://www.msn.com/en-us/news/us/overinflated-the-journey-of-a-humble-tire-reveals-why-prices-are-still-so-high/ar-AA1aFuWd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/overinflated-the-journey-of-a-humble-tire-reveals-why-prices-are-still-so-high/ar-AA1aFuWd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 09:27:45.502622+00:00



## Texas mass murder allegedly by illegal immigrant fodder for Biden impeachment, attorney argues
 - [http://www.msn.com/en-us/news/us/texas-mass-murder-allegedly-by-illegal-immigrant-fodder-for-biden-impeachment-attorney-argues/ar-AA1aFq6n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/texas-mass-murder-allegedly-by-illegal-immigrant-fodder-for-biden-impeachment-attorney-argues/ar-AA1aFq6n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 09:27:45.495559+00:00



## Security guard killed in Serbia school shooting
 - [http://www.msn.com/en-us/news/world/security-guard-killed-in-serbia-school-shooting/ar-AA1aFMWl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/security-guard-killed-in-serbia-school-shooting/ar-AA1aFMWl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 09:27:45.487498+00:00



## Teenage boy opens fire at Belgrade school, killing 1 and injuring 4
 - [http://www.msn.com/en-us/news/crime/teenage-boy-opens-fire-at-belgrade-school-killing-1-and-injuring-4/ar-AA1aFHMZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/teenage-boy-opens-fire-at-belgrade-school-killing-1-and-injuring-4/ar-AA1aFHMZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 09:27:45.478651+00:00



## US Lawmakers Query Nike, Adidas Over Forced Labor in China
 - [http://www.msn.com/en-us/news/world/us-lawmakers-query-nike-adidas-over-forced-labor-in-china/ar-AA1aFo0I?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-lawmakers-query-nike-adidas-over-forced-labor-in-china/ar-AA1aFo0I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 08:27:30.912549+00:00



## Iran's president lands in Syria for rare meeting with Assad
 - [http://www.msn.com/en-us/news/world/iran-s-president-lands-in-syria-for-rare-meeting-with-assad/ar-AA1aFnPK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/iran-s-president-lands-in-syria-for-rare-meeting-with-assad/ar-AA1aFnPK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 08:27:30.904983+00:00



## Human Remains Found Inside Crocodiles in Search for Missing Man
 - [http://www.msn.com/en-us/news/world/human-remains-found-inside-crocodiles-in-search-for-missing-man/ar-AA1aFwGn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/human-remains-found-inside-crocodiles-in-search-for-missing-man/ar-AA1aFwGn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 08:27:30.895658+00:00



## Could Biden's underwhelming lead against minor primary foes open door to others?
 - [http://www.msn.com/en-us/news/politics/could-biden-s-underwhelming-lead-against-minor-primary-foes-open-door-to-others/ar-AA1aFpDp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/could-biden-s-underwhelming-lead-against-minor-primary-foes-open-door-to-others/ar-AA1aFpDp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 08:27:30.887839+00:00



## Massachusetts man allegedly plants fake bomb at Harvard, tries to extort money after answering Craigslist ad
 - [http://www.msn.com/en-us/news/crime/massachusetts-man-allegedly-plants-fake-bomb-at-harvard-tries-to-extort-money-after-answering-craigslist-ad/ar-AA1aFzFX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/massachusetts-man-allegedly-plants-fake-bomb-at-harvard-tries-to-extort-money-after-answering-craigslist-ad/ar-AA1aFzFX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 08:27:30.879897+00:00



## Texas manhunt ends after suspect accused of killing 5 neighbors found in laundry pile
 - [http://www.msn.com/en-us/news/us/texas-manhunt-ends-after-suspect-accused-of-killing-5-neighbors-found-in-laundry-pile/ar-AA1aEDbZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/texas-manhunt-ends-after-suspect-accused-of-killing-5-neighbors-found-in-laundry-pile/ar-AA1aEDbZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 08:27:30.871858+00:00



## Jim Justice Is Trying to Be the GOP’s Version of Joe Manchin
 - [http://www.msn.com/en-us/news/politics/jim-justice-is-trying-to-be-the-gop-s-version-of-joe-manchin/ar-AA1aFJS3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jim-justice-is-trying-to-be-the-gop-s-version-of-joe-manchin/ar-AA1aFJS3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 08:27:30.863241+00:00



## Rising teenage equestrian star killed after horse falls on her head in competition
 - [http://www.msn.com/en-us/news/us/rising-teenage-equestrian-star-killed-after-horse-falls-on-her-head-in-competition/ar-AA1aFizc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/rising-teenage-equestrian-star-killed-after-horse-falls-on-her-head-in-competition/ar-AA1aFizc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 07:27:27.165781+00:00



## What we know about the 7 people found dead at an Oklahoma property
 - [http://www.msn.com/en-us/news/us/what-we-know-about-the-7-people-found-dead-at-an-oklahoma-property/ar-AA1aFizq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-we-know-about-the-7-people-found-dead-at-an-oklahoma-property/ar-AA1aFizq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 07:27:27.156978+00:00



## Jesinta Franklin ditches brunette hair in stunning transformation
 - [http://www.msn.com/en-us/news/world/jesinta-franklin-ditches-brunette-hair-in-stunning-transformation/ar-AA1aFnAU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/jesinta-franklin-ditches-brunette-hair-in-stunning-transformation/ar-AA1aFnAU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 07:27:27.149217+00:00



## Showtime! UK readies pomp for King Charles III's coronation
 - [http://www.msn.com/en-us/news/world/showtime-uk-readies-pomp-for-king-charles-iii-s-coronation/ar-AA1aFfQL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/showtime-uk-readies-pomp-for-king-charles-iii-s-coronation/ar-AA1aFfQL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 07:27:27.140860+00:00



## Lake Wales shooting: Mother and her three children killed
 - [http://www.msn.com/en-us/news/crime/lake-wales-shooting-mother-and-her-three-children-killed/ar-AA1aFmfN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/lake-wales-shooting-mother-and-her-three-children-killed/ar-AA1aFmfN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 06:27:46.995882+00:00



## Ugandan Asian exhibition shortlisted for award
 - [http://www.msn.com/en-us/news/world/ugandan-asian-exhibition-shortlisted-for-award/ar-AA1aFhHi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ugandan-asian-exhibition-shortlisted-for-award/ar-AA1aFhHi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 06:27:46.986748+00:00



## US defense contractors want deeper cooperation with Taiwan
 - [http://www.msn.com/en-us/news/world/us-defense-contractors-want-deeper-cooperation-with-taiwan/ar-AA1aF0t3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-defense-contractors-want-deeper-cooperation-with-taiwan/ar-AA1aF0t3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 06:27:46.977523+00:00



## Russia-Ukraine live updates: Former US Marine dies fighting in Ukraine
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-former-us-marine-dies-fighting-in-ukraine/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-former-us-marine-dies-fighting-in-ukraine/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 06:27:46.968297+00:00



## India's ties with Russia remain steady. But Moscow's tighter embrace of China makes it wary
 - [http://www.msn.com/en-us/news/world/india-s-ties-with-russia-remain-steady-but-moscow-s-tighter-embrace-of-china-makes-it-wary/ar-AA1aFjzM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/india-s-ties-with-russia-remain-steady-but-moscow-s-tighter-embrace-of-china-makes-it-wary/ar-AA1aFjzM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 05:27:26.853314+00:00



## Texas Mass Shooting Suspect Arrested After Sprawling Manhunt
 - [http://www.msn.com/en-us/news/crime/texas-mass-shooting-suspect-arrested-after-sprawling-manhunt/vi-AA1aFjMf?srcref=rss](http://www.msn.com/en-us/news/crime/texas-mass-shooting-suspect-arrested-after-sprawling-manhunt/vi-AA1aFjMf?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 05:27:26.844385+00:00



## Washington state to decriminalize drugs unless lawmakers act
 - [http://www.msn.com/en-us/news/politics/washington-state-to-decriminalize-drugs-unless-lawmakers-act/ar-AA1aF7Ad?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/washington-state-to-decriminalize-drugs-unless-lawmakers-act/ar-AA1aF7Ad?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 05:27:26.835186+00:00



## Florida man charged with setting off explosive device in Capitol tunnel during Jan. 6 riot
 - [http://www.msn.com/en-us/news/crime/florida-man-charged-with-setting-off-explosive-device-in-capitol-tunnel-during-jan-6-riot/ar-AA1aFgKd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/florida-man-charged-with-setting-off-explosive-device-in-capitol-tunnel-during-jan-6-riot/ar-AA1aFgKd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 04:27:30.604788+00:00



## Critics Say DeSantis Is Undermining Florida’s Vaunted Education System
 - [http://www.msn.com/en-us/news/us/critics-say-desantis-is-undermining-florida-s-vaunted-education-system/ar-AA1aF9V2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/critics-say-desantis-is-undermining-florida-s-vaunted-education-system/ar-AA1aF9V2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 04:27:30.597353+00:00



## An attack on the Supreme Court's legitimacy
 - [http://www.msn.com/en-us/news/politics/an-attack-on-the-supreme-court-s-legitimacy/ar-AA1aF01t?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/an-attack-on-the-supreme-court-s-legitimacy/ar-AA1aF01t?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 04:27:30.589002+00:00



## Florida to execute prisoner for 1986 fatal stabbing of woman
 - [http://www.msn.com/en-us/news/crime/florida-to-execute-prisoner-for-1986-fatal-stabbing-of-woman/ar-AA1aEXHp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/florida-to-execute-prisoner-for-1986-fatal-stabbing-of-woman/ar-AA1aEXHp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 04:27:30.580734+00:00



## India's ties with Russia remains steady. But Moscow's tighter embrace of China makes it wary
 - [http://www.msn.com/en-us/news/world/india-s-ties-with-russia-remains-steady-but-moscow-s-tighter-embrace-of-china-makes-it-wary/ar-AA1aFjzM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/india-s-ties-with-russia-remains-steady-but-moscow-s-tighter-embrace-of-china-makes-it-wary/ar-AA1aFjzM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 04:27:30.570254+00:00



## Suspect in Texas mass shooting 'caught hiding in a closet' under laundry: Sheriff
 - [http://www.msn.com/en-us/news/crime/suspect-in-texas-mass-shooting-caught-hiding-in-a-closet-under-laundry-sheriff/ar-AA1aEP20?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/suspect-in-texas-mass-shooting-caught-hiding-in-a-closet-under-laundry-sheriff/ar-AA1aEP20?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 04:27:30.562899+00:00



## Texas mass shooting suspect found by police after dayslong manhunt
 - [http://www.msn.com/en-us/news/crime/texas-mass-shooting-suspect-found-by-police-after-dayslong-manhunt/ar-AA1aFboS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/texas-mass-shooting-suspect-found-by-police-after-dayslong-manhunt/ar-AA1aFboS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 03:27:27.256945+00:00



## Illegal immigrant mass murder suspect captured was deported five times, ex-detective says
 - [http://www.msn.com/en-us/news/crime/illegal-immigrant-mass-murder-suspect-captured-was-deported-five-times-ex-detective-says/ar-AA1aF9aE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/illegal-immigrant-mass-murder-suspect-captured-was-deported-five-times-ex-detective-says/ar-AA1aF9aE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 03:27:27.248067+00:00



## Francisco Oropeza Arrested Within Miles of Texas Mass Shooting Site
 - [http://www.msn.com/en-us/news/crime/francisco-oropeza-arrested-within-miles-of-texas-mass-shooting-site/ar-AA1aF4mj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/francisco-oropeza-arrested-within-miles-of-texas-mass-shooting-site/ar-AA1aF4mj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 03:27:27.240324+00:00



## Text shows Tucker Carlson describing how a 'group of Trump guys' jumped an 'Antifa kid,' saying 'It's not how white men fight'
 - [http://www.msn.com/en-us/news/us/text-shows-tucker-carlson-describing-how-a-group-of-trump-guys-jumped-an-antifa-kid-saying-it-s-not-how-white-men-fight/ar-AA1aEKZs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/text-shows-tucker-carlson-describing-how-a-group-of-trump-guys-jumped-an-antifa-kid-saying-it-s-not-how-white-men-fight/ar-AA1aEKZs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 03:27:27.232420+00:00



## This Meal Kit Service Is About as Cheap as Buying the Groceries Yourself
 - [http://www.msn.com/en-us/news/technology/this-meal-kit-service-is-about-as-cheap-as-buying-the-groceries-yourself/ar-AAW873T?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/this-meal-kit-service-is-about-as-cheap-as-buying-the-groceries-yourself/ar-AAW873T?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 03:27:27.223812+00:00



## Officer on traffic stop barely avoids vehicle spinning out at 120 mph on Virginia highway
 - [http://www.msn.com/en-us/news/us/officer-on-traffic-stop-barely-avoids-vehicle-spinning-out-at-120-mph-on-virginia-highway/ar-AA1aF9mp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/officer-on-traffic-stop-barely-avoids-vehicle-spinning-out-at-120-mph-on-virginia-highway/ar-AA1aF9mp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 03:27:27.214472+00:00



## School district bans all backpacks from buildings, citing safety concerns
 - [http://www.msn.com/en-us/news/us/school-district-bans-all-backpacks-from-buildings-citing-safety-concerns/ar-AA1aF6fS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/school-district-bans-all-backpacks-from-buildings-citing-safety-concerns/ar-AA1aF6fS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 03:27:27.206096+00:00



## LAPD investigating Menudo founder over allegations of sexually assaulting ex-boy band member
 - [http://www.msn.com/en-us/news/crime/lapd-investigating-menudo-founder-over-allegations-of-sexually-assaulting-ex-boy-band-member/ar-AA1aF6VU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/lapd-investigating-menudo-founder-over-allegations-of-sexually-assaulting-ex-boy-band-member/ar-AA1aF6VU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 03:27:27.196867+00:00



## Jesse Watters Says He ‘Can Tell’ What Illegal Immigrants Look Like
 - [http://www.msn.com/en-us/news/us/jesse-watters-says-he-can-tell-what-illegal-immigrants-look-like/ar-AA1aEKA5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jesse-watters-says-he-can-tell-what-illegal-immigrants-look-like/ar-AA1aEKA5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 02:27:28.269351+00:00



## Suspect caught in Texas mass shooting that left five dead
 - [http://www.msn.com/en-us/news/politics/suspect-caught-in-texas-mass-shooting-that-left-five-dead/ar-AA1aF8XM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/suspect-caught-in-texas-mass-shooting-that-left-five-dead/ar-AA1aF8XM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 02:27:28.261255+00:00



## Virginia man confesses to 2004 double murder, sentenced to 4 life sentences: reports
 - [http://www.msn.com/en-us/news/crime/virginia-man-confesses-to-2004-double-murder-sentenced-to-4-life-sentences-reports/ar-AA1aF6gR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/virginia-man-confesses-to-2004-double-murder-sentenced-to-4-life-sentences-reports/ar-AA1aF6gR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 02:27:28.253284+00:00



## Suspect accused of gunning down 5 in Texas taken into custody: Officials
 - [http://www.msn.com/en-us/news/crime/suspect-accused-of-gunning-down-5-in-texas-taken-into-custody-officials/ar-AA1aEP20?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/suspect-accused-of-gunning-down-5-in-texas-taken-into-custody-officials/ar-AA1aEP20?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 02:27:28.245596+00:00



## Man accused of killing 5 neighbors in Texas is apprehended after manhunt
 - [http://www.msn.com/en-us/news/crime/man-accused-of-killing-5-neighbors-in-texas-is-apprehended-after-manhunt/ar-AA1aEDbZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/man-accused-of-killing-5-neighbors-in-texas-is-apprehended-after-manhunt/ar-AA1aEDbZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 02:27:28.237585+00:00



## Suspected gunman arrested after 5 dead in Texas mass shooting
 - [http://www.msn.com/en-us/news/crime/suspected-gunman-arrested-after-5-dead-in-texas-mass-shooting/ar-AA1aF94E?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/suspected-gunman-arrested-after-5-dead-in-texas-mass-shooting/ar-AA1aF94E?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 02:27:28.228420+00:00



## 3 imprisoned Iranian female journalists win top UN prize
 - [http://www.msn.com/en-us/news/world/3-imprisoned-iranian-female-journalists-win-top-un-prize/ar-AA1aENsj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/3-imprisoned-iranian-female-journalists-win-top-un-prize/ar-AA1aENsj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 02:27:28.219008+00:00



## Oregon advances bill expanding access to abortion, gender affirming health care
 - [http://www.msn.com/en-us/news/politics/oregon-advances-bill-expanding-access-to-abortion-gender-affirming-health-care/ar-AA1aEOSe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/oregon-advances-bill-expanding-access-to-abortion-gender-affirming-health-care/ar-AA1aEOSe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 01:27:28.084099+00:00



## Suspect in Texas neighbour shooting arrested - reports
 - [http://www.msn.com/en-us/news/world/suspect-in-texas-neighbour-shooting-arrested-reports/ar-AA1aEWc8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/suspect-in-texas-neighbour-shooting-arrested-reports/ar-AA1aEWc8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 01:27:28.075619+00:00



## Texas mass shooting suspect accused of killing five neighbors taken into custody 'without incident': Sources
 - [http://www.msn.com/en-us/news/crime/texas-mass-shooting-suspect-accused-of-killing-five-neighbors-taken-into-custody-without-incident-sources/ar-AA1aEMMD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/texas-mass-shooting-suspect-accused-of-killing-five-neighbors-taken-into-custody-without-incident-sources/ar-AA1aEMMD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 01:27:28.065416+00:00



## E. Jean Carroll's friend testifies in rape allegation trial as Trump declines to take the stand
 - [http://www.msn.com/en-us/news/us/e-jean-carroll-s-friend-testifies-in-rape-allegation-trial-as-trump-declines-to-take-the-stand/ar-AA1aDM9f?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/e-jean-carroll-s-friend-testifies-in-rape-allegation-trial-as-trump-declines-to-take-the-stand/ar-AA1aDM9f?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 01:27:28.056349+00:00



## Gunman Nabbed in Texas After Days on the Run
 - [http://www.msn.com/en-us/news/crime/gunman-nabbed-in-texas-after-days-on-the-run/ar-AA1aF18A?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/gunman-nabbed-in-texas-after-days-on-the-run/ar-AA1aF18A?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 01:27:28.047405+00:00



## Man believed to be suspect accused of gunning down 5 taken into custody: DA
 - [http://www.msn.com/en-us/news/crime/man-believed-to-be-suspect-accused-of-gunning-down-5-taken-into-custody-da/ar-AA1aEP20?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/man-believed-to-be-suspect-accused-of-gunning-down-5-taken-into-custody-da/ar-AA1aEP20?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 01:27:28.038318+00:00



## Paraguay: Populist candidate fires up protesters after vote
 - [http://www.msn.com/en-us/news/world/paraguay-populist-candidate-fires-up-protesters-after-vote/ar-AA1aEI62?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/paraguay-populist-candidate-fires-up-protesters-after-vote/ar-AA1aEI62?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 01:27:28.027932+00:00



## Wagner Group lost more than 100 soldiers in a single day because of a lack of ammunition, mercenary boss says
 - [http://www.msn.com/en-us/news/world/wagner-group-lost-more-than-100-soldiers-in-a-single-day-because-of-a-lack-of-ammunition-mercenary-boss-says/ar-AA1aEYX6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/wagner-group-lost-more-than-100-soldiers-in-a-single-day-because-of-a-lack-of-ammunition-mercenary-boss-says/ar-AA1aEYX6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 01:27:28.016622+00:00



## Texas gender bill delayed after LGBT protesters disrupt proceedings
 - [http://www.msn.com/en-us/news/us/texas-gender-bill-delayed-after-lgbt-protesters-disrupt-proceedings/ar-AA1aEuYJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/texas-gender-bill-delayed-after-lgbt-protesters-disrupt-proceedings/ar-AA1aEuYJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 00:23:07.595752+00:00



## Syria on way back to Arab fold as isolation crumbles
 - [http://www.msn.com/en-us/news/world/syria-on-way-back-to-arab-fold-as-isolation-crumbles/ar-AA1aEuQO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/syria-on-way-back-to-arab-fold-as-isolation-crumbles/ar-AA1aEuQO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 00:23:07.588086+00:00



## New reversal by Twitter after move sparked MTA withdrawl
 - [http://www.msn.com/en-us/news/us/new-reversal-by-twitter-after-move-sparked-mta-withdrawl/ar-AA1aEHse?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/new-reversal-by-twitter-after-move-sparked-mta-withdrawl/ar-AA1aEHse?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 00:23:07.579381+00:00



## ‘Corruption toll’: Federal jury convicts 4 at Chicago bribery trial
 - [http://www.msn.com/en-us/news/crime/corruption-toll-federal-jury-convicts-4-at-chicago-bribery-trial/ar-AA1aEYlQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/corruption-toll-federal-jury-convicts-4-at-chicago-bribery-trial/ar-AA1aEYlQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 00:23:07.570828+00:00



## Oklahoma governor vetoes state PBS funding, accuses network of using 'tax dollars to indoctrinate kids'
 - [http://www.msn.com/en-us/news/us/oklahoma-governor-vetoes-state-pbs-funding-accuses-network-of-using-tax-dollars-to-indoctrinate-kids/ar-AA1aEJW0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/oklahoma-governor-vetoes-state-pbs-funding-accuses-network-of-using-tax-dollars-to-indoctrinate-kids/ar-AA1aEJW0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 00:23:07.563137+00:00



## Utah judge pauses implementation of law banning abortion clinics across state
 - [http://www.msn.com/en-us/news/politics/utah-judge-pauses-implementation-of-law-banning-abortion-clinics-across-state/ar-AA1aEMo7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/utah-judge-pauses-implementation-of-law-banning-abortion-clinics-across-state/ar-AA1aEMo7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 00:23:07.555632+00:00



## Woman arrested for allegedly throwing wine at Matt Gaetz
 - [http://www.msn.com/en-us/news/crime/woman-arrested-for-allegedly-throwing-wine-at-matt-gaetz/ar-AA1aEEF5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/woman-arrested-for-allegedly-throwing-wine-at-matt-gaetz/ar-AA1aEEF5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 00:23:07.548684+00:00



## Third inmate who escaped Mississippi jail is found dead in New Orleans truck stop
 - [http://www.msn.com/en-us/news/crime/third-inmate-who-escaped-mississippi-jail-is-found-dead-in-new-orleans-truck-stop/ar-AA1aEvjU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/third-inmate-who-escaped-mississippi-jail-is-found-dead-in-new-orleans-truck-stop/ar-AA1aEvjU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-05-03 00:23:07.540870+00:00



