# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Qualcomm Issues Muted Outlook, Signaling Sustained Smartphone Demand Weakness
 - [https://www.wsj.com/articles/qualcomm-qcom-q2-earnings-report-2023-99c0fd5a?mod=rss_Technology](https://www.wsj.com/articles/qualcomm-qcom-q2-earnings-report-2023-99c0fd5a?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-05-03 20:16:00+00:00

The mobile-phone chip company is diversifying into new areas as its core market slows.

## How to Store Your Bike Like a Professional
 - [https://www.wsj.com/articles/how-to-store-your-bike-like-a-professional-17f04286?mod=rss_Technology](https://www.wsj.com/articles/how-to-store-your-bike-like-a-professional-17f04286?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-05-03 18:00:00+00:00

Stop leaning your bike against a bookcase. A guide to choosing the best floor racks and bike mounts with recommendations from experts.

## TikTok Is Launching an Ad Product for Publishers and Giving Them a 50% Cut
 - [https://www.wsj.com/articles/tiktok-is-launching-an-ad-product-for-publishers-and-giving-them-a-50-cut-cff0c9a0?mod=rss_Technology](https://www.wsj.com/articles/tiktok-is-launching-an-ad-product-for-publishers-and-giving-them-a-50-cut-cff0c9a0?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-05-03 17:05:00+00:00

TikTok said it is launching a new product that will make it possible for publishers to sell ads alongside their posts.

## FTC Proposes New Sanctions for Meta
 - [https://www.wsj.com/articles/ftc-proposes-new-sanctions-for-facebook-owner-meta-879ec7e8?mod=rss_Technology](https://www.wsj.com/articles/ftc-proposes-new-sanctions-for-facebook-owner-meta-879ec7e8?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-05-03 17:00:00+00:00

The Federal Trade Commission proposed barring Meta Platforms from profiting off data it collects from young users, after concluding that the company repeatedly violated its privacy promises.

## Unity Conducts Its Third and Largest Round of Layoffs in a Year
 - [https://www.wsj.com/articles/unity-conducts-its-third-and-largest-round-of-layoffs-in-a-year-48fdafe1?mod=rss_Technology](https://www.wsj.com/articles/unity-conducts-its-third-and-largest-round-of-layoffs-in-a-year-48fdafe1?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-05-03 00:30:00+00:00

The software company’s move to let go about 600 employees follows a recent string of job cuts in the tech industry and beyond.

