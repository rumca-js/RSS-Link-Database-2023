# Source:Nineteenth century videos. Back to life., URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ, language:en-US

## [4K, 60 fps, colorized] (1914) The sex change of Lillian Travers. A Florida Enchantment .
 - [https://www.youtube.com/watch?v=R8LsIx_y6Gg](https://www.youtube.com/watch?v=R8LsIx_y6Gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ
 - date published: 2023-05-03 15:11:17+00:00

A Florida Enchantment (1914) is a silent film notable for its cross-dressing lead characters, later discussed as bisexual, lesbian, gay, and transgender.

Lillian decides to test the effects of the seeds that change men into women and vice versa . The next morning, Lillian discovers that she has transformed into a man. The film has been considered to have the first documented appearance of bisexual characters in an American motion picture.

Music: Mozart, K464

