# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## You've Gotta Be F**king KIDDING Me!!
 - [https://www.youtube.com/watch?v=It85uJlrMXU](https://www.youtube.com/watch?v=It85uJlrMXU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-05-03 18:27:11+00:00

Robert F. Kennedy Jr. has been smeared by almost every media organisation reporting on his Presidential campaign launch. But is there a reason they only focus on his medical opinions, rather than his stance on environment issues, the corrupt relationships between government and big business, and endless war? And does his surge to 19% in the polls suggest he’s a genuine threat to Biden? 
#election #joebiden #democrats 

References
https://scheerpost.com/2023/04/27/why-should-we-pay-attention-to-robert-f-kennedy-jr/
https://www.washingtonpost.com/politics/2023/04/27/robert-kennedy-jr-democratic-primary/
https://www.thenation.com/article/world/cold-war-russia-china-iran/
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble
Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community
Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/
Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

## WTF!? Facebook Worse Than Fox? Plus RFK Jnr Surges - #121 - Stay Free With Russell Brand PREVIEW
 - [https://www.youtube.com/watch?v=513Q4aowAY8](https://www.youtube.com/watch?v=513Q4aowAY8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-05-03 16:17:16+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me live and exclusively over on RUMBLE:
https://bit.ly/stayfree-121-facebook-fox-rfk

As Facebook agrees to $725 million security breach settlement, why hasn’t this been covered in the mainstream news in the same way as Fox News’ $787 million payout? Dr John Campbell’s had a YouTube Strike, he joins us live. As RFK Jr surges in the polls, we ask… is he being smeared by the mainstream media and how much of a threat is he to Joe Biden? Plus, we’re joined by economist and the author of ‘Free and Equal - What Would a Fair Society Look Like?’, Daniel Chandler, to find out how to get money out of politics!

--------------------------------------------------------------------------------------------------------------------------

FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand
5:00PM BST | 12:00 PM EDT | 9:00AM PDT

Get My New Stand Up Special 'Brandemic' NOW https://rumble.com/v2d09w8-brandemic.html

Join The STAY FREE Community: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/

NEW MERCH! https://stuff.russellbrand.com/

## 4 MORE YEARS?!
 - [https://www.youtube.com/watch?v=6rW1WrWck8g](https://www.youtube.com/watch?v=6rW1WrWck8g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-05-03 02:00:01+00:00



