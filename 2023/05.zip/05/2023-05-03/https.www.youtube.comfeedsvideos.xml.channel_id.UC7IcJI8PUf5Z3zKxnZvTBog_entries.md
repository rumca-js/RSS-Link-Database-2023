# Source:The School of Life, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog, language:en-US

## Three Kinds Of Parental Love
 - [https://www.youtube.com/watch?v=bELfHs1kaQA](https://www.youtube.com/watch?v=bELfHs1kaQA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog
 - date published: 2023-05-03 13:00:32+00:00

The moment babies are born, their minds are dominated by a powerful implicit question: What do I need to do in order to be loved?
Sign up to our mailing list to receive 10% off your first order with us: https://r1.dotdigital-pages.com/p/6TU0-63X/hellotsol
For books and more from The School of Life, visit our online shop: https://bit.ly/3LqoPBW
Our website has classes, articles and products to help you lead a more fulfilled life: https://bit.ly/3NB7hFV
​​For Psychotherapy and other therapeutic services: https://www.theschooloflife.com/therapy-booking/?presetTherapyType=Psychotherapy 
If you want to keep working on your mental well-being and self-understanding, download our hugely helpful new app now: https://bit.ly/42ibgeJ
For information on The School of Life’s learning and wellbeing solutions for businesses, including workshops and talks, visit https://bit.ly/3ICqvGw  
Email business@theschooloflife.com or join our monthly business newsletter: https://bit.ly/3ICEJHq 
Join this channel to get access to exclusive members perks:
https://www.youtube.com/channel/UC7IcJI8PUf5Z3zKxnZvTBog/join


FURTHER READING

You can read more on this and other subjects on our blog, here: https://bit.ly/41PS8F3

“The moment babies are born, their minds are dominated by a powerful implicit question: What do I need to do in order to be loved?
We have to remember that babies are entirely at the mercy of the prevailing environment, and therefore, knowing what exactly the people in this environment want from them in exchange for keeping them alive is central to their very survival. Furthermore, how the question is answered will shape their entire personality and sense of adult priorities; who we are is predominantly the result of what we needed to do to capture and sustain the interest of the people who put us on the earth…”


MORE SCHOOL OF LIFE

Watch more films on SELF in our playlist: 
http://bit.ly/TSOLself


SOCIAL MEDIA

Feel free to follow us at the links below:

Facebook: https://www.facebook.com/theschooloflifelondon/  
Twitter: https://twitter.com/TheSchoolOfLife   
Instagram: https://www.instagram.com/theschooloflifelondon/ 
LinkedIn: https://www.linkedin.com/company/the-school-of-life-for-business/

CREDITS

Produced in collaboration with:

Léon Moh-Cah
Na Na Na Studio
https://nananastudio.com/


Title animation produced in collaboration with


Graeme Probert
www.gpmotion.co.uk

