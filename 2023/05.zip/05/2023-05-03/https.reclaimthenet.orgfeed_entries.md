# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Australian eSafety Commissioner’s baffling statement: Compares strong encryption to open doors for intruders
 - [https://reclaimthenet.org/australias-esafety-commissioner-strong-encryption-to-open-doors-for-intruders](https://reclaimthenet.org/australias-esafety-commissioner-strong-encryption-to-open-doors-for-intruders)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-05-03 21:59:57+00:00

<a href="https://reclaimthenet.org/australias-esafety-commissioner-strong-encryption-to-open-doors-for-intruders" rel="nofollow" title="Australian eSafety Commissioner&#8217;s baffling statement: Compares strong encryption to open doors for intruders"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/05/Julie-Inman-Grant.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Bizarre.</p>
<p>The post <a href="https://reclaimthenet.org/australias-esafety-commissioner-strong-encryption-to-open-doors-for-intruders" rel="nofollow">Australian eSafety Commissioner&#8217;s baffling statement: Compares strong encryption to open doors for intruders</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## RFK Jr. vows to pardon Assange, Snowden, and other whistleblowers if elected President
 - [https://reclaimthenet.org/rfk-jr-vows-to-pardon-assange-snowden](https://reclaimthenet.org/rfk-jr-vows-to-pardon-assange-snowden)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-05-03 17:08:51+00:00

<a href="https://reclaimthenet.org/rfk-jr-vows-to-pardon-assange-snowden" rel="nofollow" title="RFK Jr. vows to pardon Assange, Snowden, and other whistleblowers if elected President"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/05/kennedy-assange.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>"I’ll pardon brave truth-tellers like Julian Assange and investigate the corruption and crimes they exposed."</p>
<p>The post <a href="https://reclaimthenet.org/rfk-jr-vows-to-pardon-assange-snowden" rel="nofollow">RFK Jr. vows to pardon Assange, Snowden, and other whistleblowers if elected President</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## House GOP probes State Department’s censorship ties to social media giants
 - [https://reclaimthenet.org/house-gop-probes-state-departments-censorship-ties-to-social-media-giants](https://reclaimthenet.org/house-gop-probes-state-departments-censorship-ties-to-social-media-giants)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-05-03 16:05:28+00:00

<a href="https://reclaimthenet.org/house-gop-probes-state-departments-censorship-ties-to-social-media-giants" rel="nofollow" title="House GOP probes State Department&#8217;s censorship ties to social media giants"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/05/jim-jordan-52864.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>An investigation into outsourcing censorship to third-parties.</p>
<p>The post <a href="https://reclaimthenet.org/house-gop-probes-state-departments-censorship-ties-to-social-media-giants" rel="nofollow">House GOP probes State Department&#8217;s censorship ties to social media giants</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Academics develop plot to scan social media, flag posts with “pre-crime” machine learning
 - [https://reclaimthenet.org/academics-develop-plot-to-scan-social-media-flag-posts-with-pre-crime-machine-learning](https://reclaimthenet.org/academics-develop-plot-to-scan-social-media-flag-posts-with-pre-crime-machine-learning)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-05-03 02:06:23+00:00

<a href="https://reclaimthenet.org/academics-develop-plot-to-scan-social-media-flag-posts-with-pre-crime-machine-learning" rel="nofollow" title="Academics develop plot to scan social media, flag posts with &#8220;pre-crime&#8221; machine learning"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/05/ai-pre-crime.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>🛡</p>
<p>The post <a href="https://reclaimthenet.org/academics-develop-plot-to-scan-social-media-flag-posts-with-pre-crime-machine-learning" rel="nofollow">Academics develop plot to scan social media, flag posts with &#8220;pre-crime&#8221; machine learning</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Google removes criticism of Brazil’s “fake news” censorship law after government threatens it with huge fine
 - [https://reclaimthenet.org/google-removes-criticism-brazil-fake-news-law](https://reclaimthenet.org/google-removes-criticism-brazil-fake-news-law)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-05-03 01:55:24+00:00

<a href="https://reclaimthenet.org/google-removes-criticism-brazil-fake-news-law" rel="nofollow" title="Google removes criticism of Brazil&#8217;s &#8220;fake news&#8221; censorship law after government threatens it with huge fine"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/05/google-removes-criticism-brazil-fake-news-law.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Brazil's Justice Minister suggested silencing Google would somehow protect freedom of expression.</p>
<p>The post <a href="https://reclaimthenet.org/google-removes-criticism-brazil-fake-news-law" rel="nofollow">Google removes criticism of Brazil&#8217;s &#8220;fake news&#8221; censorship law after government threatens it with huge fine</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Immunologist is investigated by University for liking vaccine skeptic tweets, gender surgery criticism
 - [https://reclaimthenet.org/dr-mark-tykocinski-for-liking-vaccine-skeptic-tweets](https://reclaimthenet.org/dr-mark-tykocinski-for-liking-vaccine-skeptic-tweets)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-05-03 01:42:29+00:00

<a href="https://reclaimthenet.org/dr-mark-tykocinski-for-liking-vaccine-skeptic-tweets" rel="nofollow" title="Immunologist is investigated by University for liking vaccine skeptic tweets, gender surgery criticism"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/05/Tykocinski.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Mark Tykocinski quickly apologized after a news article complained about his tweets.</p>
<p>The post <a href="https://reclaimthenet.org/dr-mark-tykocinski-for-liking-vaccine-skeptic-tweets" rel="nofollow">Immunologist is investigated by University for liking vaccine skeptic tweets, gender surgery criticism</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

