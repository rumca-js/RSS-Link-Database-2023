# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## US regulator says Meta putting child users at risk
 - [https://www.bbc.co.uk/news/technology-65478062?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65478062?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-05-03 22:42:41+00:00

The Federal Trade Commission says it wants to stop Facebook's owner from making money out of children.

## Air travel chaos looms as US keeps 5G altimeter refit deadline
 - [https://www.bbc.co.uk/news/world-us-canada-65465512?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65465512?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-05-03 01:45:35+00:00

A July deadline for airlines to refit planes to avoid 5G signal interference will remain in place.

