# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Judge dismisses Trump's $100 million lawsuit against The New York Times
 - [https://www.foxnews.com/politics/judge-dismisses-trump-100-million-lawsuit-new-york-times](https://www.foxnews.com/politics/judge-dismisses-trump-100-million-lawsuit-new-york-times)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 19:22:29+00:00

Former President Donald Trump&apos;s $100 million dollar lawsuit against The New York Times was dismissed by a New York Supreme Court judge on Wednesday.

## Black box recorders recovered from deadly Alaska Army chopper crash site
 - [https://www.foxnews.com/us/black-box-recorders-recovered-deadly-alaska-army-chopper-crash-site](https://www.foxnews.com/us/black-box-recorders-recovered-deadly-alaska-army-chopper-crash-site)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 19:20:51+00:00

Military investigators have recovered black boxes from both Army helicopters that crashed April 27 at Alaska&apos;s Fort Wainwright, leaving three soldiers dead.

## Mexican government develops own COVID vaccine 2 years after US, China
 - [https://www.foxnews.com/world/mexican-government-develops-own-covid-vaccine-2-years-us-china](https://www.foxnews.com/world/mexican-government-develops-own-covid-vaccine-2-years-us-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 19:18:49+00:00

Mexican officials on Wednesday touted the release of the country&apos;s &quot;Patria,&quot; or &quot;Motherland&quot; COVID-19 vaccine, two years after the West and China released their respective vaccines.

## New York minimum wage hike becomes law as Hochul signs off on $229B budget
 - [https://www.foxnews.com/politics/new-york-minimum-wage-hike-becomes-law-hochul-signs-229b-budget](https://www.foxnews.com/politics/new-york-minimum-wage-hike-becomes-law-hochul-signs-229b-budget)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 19:17:14+00:00

New York lawmakers have passed a $229 billion spending plan that includes a minimum wage hike that must be implemented by 2026. Its passage was delayed by over a month.

## Who is Deion Patterson, the man police suspect of killing 1 and injuring 4 in Atlanta hospital shooting?
 - [https://www.foxnews.com/us/deion-patterson-police-suspect-atlanta-hospital-shooting](https://www.foxnews.com/us/deion-patterson-police-suspect-atlanta-hospital-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 19:16:35+00:00

Atlanta police are searching for former Coast Guard member Deion Patterson, who allegedly shot and killed one person and injured four others.

## Steph Curry shares hilarious details on interaction with LeBron James during Warriors-Lakers playoff game
 - [https://www.foxnews.com/sports/steph-curry-details-viral-lebron-interaction-during-warriors-lakers-playoff-game](https://www.foxnews.com/sports/steph-curry-details-viral-lebron-interaction-during-warriors-lakers-playoff-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 19:10:31+00:00

After the Warriors suffered a defeat in Game 1, an understandably somber Steph Curry was asked about LeBron James following him to the Warriors’ bench in the first half.

## Senate passes bipartisan bill to override Biden's handout to Chinese solar companies
 - [https://www.foxnews.com/politics/senate-passes-bipartisan-bill-override-bidens-handout-chinese-solar-companies](https://www.foxnews.com/politics/senate-passes-bipartisan-bill-override-bidens-handout-chinese-solar-companies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:47:27+00:00

The Senate passed a resolution Wednesday evening to strike down President Biden&apos;s actions last year which allow Chinese solar panel manufacturers to skirt tariffs.

## Jets' Sauce Gardner says Aaron Rodgers couldn't believe he didn't know A-list actress at Knicks-Heat game
 - [https://www.foxnews.com/sports/jets-sauce-gardner-aaron-rodgers-couldnt-believe-didnt-know-a-list-actress-knicks-heat-game](https://www.foxnews.com/sports/jets-sauce-gardner-aaron-rodgers-couldnt-believe-didnt-know-a-list-actress-knicks-heat-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:45:22+00:00

Jets cornerback Sauce Gardner revealed Aaron Rodgers couldn&apos;t believe Gardner didn&apos;t recognize a famous actress sitting near them at the Knicks-Heat game Tuesday night.

## Giants pitcher Logan Webb says most of the team 'has the s--ts' after Mexico City series
 - [https://www.foxnews.com/sports/giants-pitcher-logan-webb-says-most-team-has-s-ts-mexico-city-series](https://www.foxnews.com/sports/giants-pitcher-logan-webb-says-most-team-has-s-ts-mexico-city-series)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:44:30+00:00

The San Francisco Giants recently finished a two-game set in Mexico City, but apparently the food south of the border has upset the stomachs of most of the team.

## WWE star Sonya Deville's stalker agrees to plea deal after attempted kidnapping
 - [https://www.foxnews.com/sports/wwe-star-sonya-devilles-stalker-plea-deal-attempted-kidnapping](https://www.foxnews.com/sports/wwe-star-sonya-devilles-stalker-plea-deal-attempted-kidnapping)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:43:33+00:00

Sonya Deville&apos;s stalker Phillip Thomas has been sentenced to 15 years in prison after striking a plea deal following an attempted kidnapping of the WWE star in August 2020.

## New Mexico delegates renew push for broader protection at Chaco National Park
 - [https://www.foxnews.com/us/new-mexico-delegates-renew-push-broader-protection-chaco-national-park](https://www.foxnews.com/us/new-mexico-delegates-renew-push-broader-protection-chaco-national-park)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:42:45+00:00

New Mexico delegates renewed a push for broader protection for the Chaco Culture National Historical Park. The legislation will provide a 10-mile buffer around the national park.

## Washington police fatally shoot man armed with shotgun in his yard
 - [https://www.foxnews.com/us/washington-police-fatally-shoot-man-armed-shotgun-his-yard](https://www.foxnews.com/us/washington-police-fatally-shoot-man-armed-shotgun-his-yard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:40:13+00:00

Washington police officers fatally shot a man who was armed with a shotgun in his front yard. Police responded to a 911 call saying the man was suffering from mental health issues.

## Michigan passes bill to protect abortion-seekers from discrimination
 - [https://www.foxnews.com/politics/michigan-passes-bill-protect-abortion-seekers-discrimination](https://www.foxnews.com/politics/michigan-passes-bill-protect-abortion-seekers-discrimination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:37:35+00:00

The Michigan Legislature has passed a bill that would prohibit employers from discriminating or retaliating against female employees for receiving abortions.

## California sees more snow fall halfway through spring
 - [https://www.foxnews.com/us/california-sees-more-snow-fall-halfway-through-spring](https://www.foxnews.com/us/california-sees-more-snow-fall-halfway-through-spring)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:34:33+00:00

California is still seeing snow fall halfway through spring. The unusual winter weather is being caused by an unseasonably cold system spinning off San Francisco Bay.

## Female high school student scorches school district for allowing biological male student to use girls bathroom
 - [https://www.foxnews.com/media/female-high-school-student-scorches-school-district-allowing-biological-male-student-girls-bathroom](https://www.foxnews.com/media/female-high-school-student-scorches-school-district-allowing-biological-male-student-girls-bathroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:30:20+00:00

A senior high school student confronted the local school board for catering to transgender ideology at her school district, claiming it makes women feel unsafe.

## State Department 'unable to confirm' video purporting to show drone attack on Kremlin
 - [https://www.foxnews.com/world/state-department-unable-confirm-video-purporting-drone-attack-kremlin](https://www.foxnews.com/world/state-department-unable-confirm-video-purporting-drone-attack-kremlin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:29:44+00:00

The State Department says it&apos;s &quot;unable to confirm&quot; the authenticity of a video supposedly showing a drone attack on the Kremlin.

## Patrick Mahomes, Stephen Curry set to return for The Match alongside teammates Travis Kelce, Klay Thompson
 - [https://www.foxnews.com/sports/patrick-mahomes-stephen-curry-return-the-match-alongside-teammates-travis-kelce-klay-thompson](https://www.foxnews.com/sports/patrick-mahomes-stephen-curry-return-the-match-alongside-teammates-travis-kelce-klay-thompson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:25:56+00:00

The Kansas City Chiefs will face the Golden State Warriors June 29. Patrick Mahomes and Travis Kelce will face Stephen Curry and Klay Thompson in The Match at Wynn Golf Club.

## WWE lands Olympic gold medalist Tamyra Mensah-Stock
 - [https://www.foxnews.com/sports/wwe-lands-olympic-medalist-tamyra-mensah-stock](https://www.foxnews.com/sports/wwe-lands-olympic-medalist-tamyra-mensah-stock)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:25:49+00:00

Tamyra Mensah-Stock has made a major career decision, signing with the WWE. After winning an Olympic medal in Tokyo, Mensah-Stock hinted that she could join the WWE.

## Kansas City becomes latest Dem-run city to form reparations commission, seek payments for Black residents
 - [https://www.foxnews.com/politics/kansas-city-latest-dem-run-city-form-reparations-commission-seek-payments-black-residents](https://www.foxnews.com/politics/kansas-city-latest-dem-run-city-form-reparations-commission-seek-payments-black-residents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:09:21+00:00

Kansas City&apos;s reparations commission is up and running with the appointment of 13 members who will be seeking taxpayer dollars for payments to eligible Black residents in the area.

## Tennessee football player sings national anthem ahead of Vols' baseball game
 - [https://www.foxnews.com/sports/tennessee-football-player-sings-national-anthem-ahead-vols-baseball-game](https://www.foxnews.com/sports/tennessee-football-player-sings-national-anthem-ahead-vols-baseball-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:08:33+00:00

Before winning their eighth-straight game, the 18th-ranked Tennessee Vols had a member of the football team sing the national anthem before a baseball game.

## Critics explode over US Navy's use of drag queen to solve recruiting crisis: 'What NOT to do'
 - [https://www.foxnews.com/politics/critics-explode-over-us-navys-use-drag-queen-solve-recruiting-crisis](https://www.foxnews.com/politics/critics-explode-over-us-navys-use-drag-queen-solve-recruiting-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:07:18+00:00

Critics exploded on the U.S. Navy over its decision to use a drag queen sailor to help persuade new recruits amid the military&apos;s massive recruitment crisis.

## Massachusetts man awarded $13M after serving 32 years for wrongful arson conviction
 - [https://www.foxnews.com/us/massachusetts-man-awarded-13m-serving-32-years-wrongful-arson-conviction](https://www.foxnews.com/us/massachusetts-man-awarded-13m-serving-32-years-wrongful-arson-conviction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:07:07+00:00

Victor Rosario, 35, has been awarded $13 million from the city of Lowell, Massachusetts, after spending 32 years in prison for an arson he did not commit.

## Georgia Gov. Kemp signs bill to ban outside election funds
 - [https://www.foxnews.com/us/georgia-gov-kemp-signs-bill-ban-outside-election-funds](https://www.foxnews.com/us/georgia-gov-kemp-signs-bill-ban-outside-election-funds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:04:42+00:00

Georgia Gov. Kemp signed a bill that would ban funding for elections from outside groups. The state will still allow contributions to the federal or state government.

## California leads blue state charge against Florida restrictions on transition surgeries
 - [https://www.foxnews.com/politics/california-leads-blue-state-charge-florida-restrictions-transition-surgeries](https://www.foxnews.com/politics/california-leads-blue-state-charge-florida-restrictions-transition-surgeries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:04:27+00:00

California Attorney General Rob Bonta is leading a charge of Democratic-led states against Florida&apos;s new rule banning Medicaid dollars from being used for transition surgeries.

## California construction site collapses, trapping workers
 - [https://www.foxnews.com/us/california-construction-site-collapses-trapping-workers](https://www.foxnews.com/us/california-construction-site-collapses-trapping-workers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:01:19+00:00

California emergency workers rescued six construction workers in Glendale after a building collapse on Wednesday. Some workers were stuck at least 30 feet in the air on cranes.

## Politifact defends Randi Weingarten: ‘Misleading’ to claim she opposed reopening schools
 - [https://www.foxnews.com/media/politifact-defends-randi-weingarten-misleading-claim-opposed-reopening-schools](https://www.foxnews.com/media/politifact-defends-randi-weingarten-misleading-claim-opposed-reopening-schools)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 18:00:21+00:00

Politifact published an analysis that insisted there needs to be additional context to the claim that Randi Weingarten opposed opening reopening schools during the pandemic.

## Georgia couple awarded $135.5M for damages from polluted land, water
 - [https://www.foxnews.com/us/georgia-couple-awarded-135-5m-damages-polluted-land-water](https://www.foxnews.com/us/georgia-couple-awarded-135-5m-damages-polluted-land-water)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:59:20+00:00

A Georgia couple has been awarded $135.5M for damages from polluted land and water. The lawsuit says Silicon Ranch Corp. developed over 160 solar panel facilities across the U.S.

## Billionaire Dem mega-donor bankrolling Trump accuser's rape lawsuit visited Epstein's private island
 - [https://www.foxnews.com/politics/billionaire-dem-mega-donor-reid-hoffman-bankrolling-trump-accusers-rape-lawsuit-visited-epsteins-private-island](https://www.foxnews.com/politics/billionaire-dem-mega-donor-reid-hoffman-bankrolling-trump-accusers-rape-lawsuit-visited-epsteins-private-island)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:57:53+00:00

A billionaire Democratic mega-donor who&apos;s currently bankrolling a rape lawsuit against former President Donald Trump visited the private island of sex offender Jeffrey Epstein.

## Toronto-area man jailed for counseling suicide, causing 2 deaths
 - [https://www.foxnews.com/world/toronto-area-man-jailed-counseling-suicide-causing-2-deaths](https://www.foxnews.com/world/toronto-area-man-jailed-counseling-suicide-causing-2-deaths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:57:32+00:00

Kenneth Law, 57, of Mississauga, Ontario has been arrested for allegedly providing lethal substances to two people at risk of suicide.

## NJ Republicans eye wind turbine construction moratorium over whale death concerns
 - [https://www.foxnews.com/politics/nj-republicans-eye-wind-turbine-construction-moratorium-whale-death-concerns](https://www.foxnews.com/politics/nj-republicans-eye-wind-turbine-construction-moratorium-whale-death-concerns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:56:03+00:00

New Jersey Republicans and other opponents of shoreside wind turbines have proposed a moratorium of up to 60 days on construction to assess potential effects on whale mortality.

## Texas teacher arrested over improper relationship with student: police
 - [https://www.foxnews.com/us/texas-teacher-arrested-improper-relationship-student-police](https://www.foxnews.com/us/texas-teacher-arrested-improper-relationship-student-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:50:04+00:00

Newman International Academy teacher Alberto De La Cruz was arrested and charged with an improper relationship between educator and student. He was a high school athletic director.

## Illinois school backtracks after segregating math classes for Black, 'Latinx' students
 - [https://www.foxnews.com/politics/illinois-school-backtracks-segregating-math-classes-black-latinx-students](https://www.foxnews.com/politics/illinois-school-backtracks-segregating-math-classes-black-latinx-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:49:39+00:00

An Illinois high school has reversed course after it appeared to restrict access to certain Advanced Placement Calculus courses to Black and Latinx students only.

## Florida man accused of killing girlfriend, her 3 children, killed by officers during motel standoff
 - [https://www.foxnews.com/us/florida-man-accused-killing-girlfriend-three-children-killed-officers-motel](https://www.foxnews.com/us/florida-man-accused-killing-girlfriend-three-children-killed-officers-motel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:44:44+00:00

A Florida man who allegedly killed his girlfriend and her three children was fatally shot by police officers at a motel, authorities said.

## South Carolina women’s basketball coach Dawn Staley reveals unusual hobby
 - [https://www.foxnews.com/sports/south-carolina-womens-basketball-coach-dawn-staley-reveals-unusual-hobby](https://www.foxnews.com/sports/south-carolina-womens-basketball-coach-dawn-staley-reveals-unusual-hobby)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:41:33+00:00

South Carolina head women’s basketball coach Dawn Staley revealed an interesting hobby, saying she likes to attend murder trials in her free time.

## Mexican president accuses US of funding groups hostile to his administration, calls on Biden to intervene
 - [https://www.foxnews.com/world/mexican-president-accuses-us-funding-groups-hostile-his-administration-calls-biden-intervene](https://www.foxnews.com/world/mexican-president-accuses-us-funding-groups-hostile-his-administration-calls-biden-intervene)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:35:11+00:00

Mexico President Andres Manuel López Obrador is accusing the US Agency for International Development of funding organizations hostile to his administration.

## US spends nearly $300 million on military aid to Ukraine
 - [https://www.foxnews.com/world/us-spends-nearly-300-million-military-aid-ukraine](https://www.foxnews.com/world/us-spends-nearly-300-million-military-aid-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:31:35+00:00

The United States has spent nearly $300 million in additional military aid to Ukraine. The new package will include Hydra-70 rockets, artillery rounds, howitzers and ammunition.

## Ex-NHL defenseman PK Subban causes social media frenzy after controversial Lizzo remark during NHL playoffs
 - [https://www.foxnews.com/sports/ex-nhl-defenseman-pk-subban-causes-social-media-frenzy-controversial-lizzo-remark-during-nhl-playoffs](https://www.foxnews.com/sports/ex-nhl-defenseman-pk-subban-causes-social-media-frenzy-controversial-lizzo-remark-during-nhl-playoffs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:31:29+00:00

Former NHL defenseman P.K. Subban made a remark about Grammy Award winner Lizzo when discussing the Toronto Maple Leafs on Tuesday night, and social media users were not happy.

## Coronation advice from one in the know: Grenadier Guard at Queen Elizabeth II's event spills secrets
 - [https://www.foxnews.com/lifestyle/coronation-advice-one-know-grenadier-guard-queen-elizabeth-iis-event-spills-secrets](https://www.foxnews.com/lifestyle/coronation-advice-one-know-grenadier-guard-queen-elizabeth-iis-event-spills-secrets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:31:20+00:00

A retired Grenadier Guard who stood in the rain for nine hours at Queen Elizabeth II&apos;s coronation in 1953 offered advice to those who will be guarding King Charles III on May 6, 2023.

## 4 horses have died at Churchill Downs ahead of 149th Kentucky Derby
 - [https://www.foxnews.com/sports/4-horses-died-churchill-downs-ahead-149th-kentucky-derby](https://www.foxnews.com/sports/4-horses-died-churchill-downs-ahead-149th-kentucky-derby)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:30:42+00:00

Four horses have reportedly died at Churchill Downs since Thursday ahead of the 149th Kentucky Derby on Saturday. Two of the horses belonged to the same owner.

## Flames fire coach Darryl Sutter after missing playoffs
 - [https://www.foxnews.com/sports/flames-fire-coach-darryl-sutter-missing-playoffs](https://www.foxnews.com/sports/flames-fire-coach-darryl-sutter-missing-playoffs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:30:34+00:00

The Calgary Flames fired head coach Darryl Sutter on Monday after the team went 38-27-17 during the 2022-23 season. The team missed the playoffs.

## Manhattan DA Alvin Bragg investigating after aggressive homeless man on NYC subway dies in Marine's chokehold
 - [https://www.foxnews.com/us/manhattan-da-alvin-bragg-investigating-aggressive-homeless-man-nyc-subway-dies-marines-chokehold](https://www.foxnews.com/us/manhattan-da-alvin-bragg-investigating-aggressive-homeless-man-nyc-subway-dies-marines-chokehold)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:18:11+00:00

Manhattan District Attorney Alvin Bragg may file charges against the Marine who put a homeless man in a chokehold for 15 minutes on Monday. Jordan Neely died after losing consciousness.

## First-ever RSV vaccine approved by FDA for adults 60 and over
 - [https://www.foxnews.com/health/first-ever-rsv-vaccine-approved-fda-adults-60-over](https://www.foxnews.com/health/first-ever-rsv-vaccine-approved-fda-adults-60-over)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 17:08:58+00:00

The Food and Drug Administration (FDA) has approved the first respiratory syncytial virus (RSV) vaccine for use in the U.S., the public health agency announced on Wednesday.

## Heidi Klum and daughter Leni pose together again for lingerie ad despite past backlash
 - [https://www.foxnews.com/entertainment/heidi-klum-daughter-leni-pose-together-again-lingerie-ad-despite-past-backlash](https://www.foxnews.com/entertainment/heidi-klum-daughter-leni-pose-together-again-lingerie-ad-despite-past-backlash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:57:17+00:00

Heidi Klum stirred up controversy last year when she and her 18-year-old daughter posed together for a lingerie campaign. On Wednesday, the two shared photos from a new ad.

## Vermont Legislature urged to impeach prosecutor over harassment, discrimination claims
 - [https://www.foxnews.com/politics/vermont-legislature-urged-impeach-prosecutor-harassment-discrimination-claims](https://www.foxnews.com/politics/vermont-legislature-urged-impeach-prosecutor-harassment-discrimination-claims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:55:52+00:00

The Vermont Legislature has been advised to impeach Franklin County State&apos;s Attorney John Lavoie after harassment and discrimination claims against him were determined to have merit.

## New malware is targeting macOS and can steal sensitive information from your devices
 - [https://www.foxnews.com/tech/new-malware-targeting-macos-can-steal-sensitive-information-devices](https://www.foxnews.com/tech/new-malware-targeting-macos-can-steal-sensitive-information-devices)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:52:43+00:00

Once malware has gotten hold of your macOS device, it has the ability to infiltrate and steal confidential files and information, recent studies have shown.

## Curvy mermaid statue in Italy makes a viral splash as residents debate if its 'vulgar' or 'beautiful'
 - [https://www.foxnews.com/lifestyle/curvy-mermaid-statue-italy-makes-viral-splash-residents-debate-vulgar-or-beautiful](https://www.foxnews.com/lifestyle/curvy-mermaid-statue-italy-makes-viral-splash-residents-debate-vulgar-or-beautiful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:52:42+00:00

A cheeky and buxom mermaid statue created to honor an Italian Nobel Prize winner has appeared to confuse residents of a small port city and the rest of the world.

## FBI reveals how tipster's call led to arrest of illegal immigrant who allegedly killed five neighbors
 - [https://www.foxnews.com/us/fbi-reveals-tipsters-call-led-arrest-illegal-immigrant-allegedly-killed-five-neighbors](https://www.foxnews.com/us/fbi-reveals-tipsters-call-led-arrest-illegal-immigrant-allegedly-killed-five-neighbors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:45:05+00:00

The Federal Bureau of Investigation revealed how one tipster&apos;s phone call led to the arrest of an illegal immigrant who was deported at least four times in Texas.

## Alleged drunken driver charged with killing bride had dressed as 'Bud Lightyear' for Halloween
 - [https://www.foxnews.com/us/jamie-komoroski-south-carolina-drunken-driver-killed-bride-dressed-bud-lightyear-halloween-samantha-miller-aric-hutchinson](https://www.foxnews.com/us/jamie-komoroski-south-carolina-drunken-driver-killed-bride-dressed-bud-lightyear-halloween-samantha-miller-aric-hutchinson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:39:58+00:00

Alleged drunken driver Jamie Komoroski, who is accused of killing bride Samantha Miller, once wore a Bud Light costume on Halloween, according to a newly surfaced photo.

## Brooks Koepka, wife Jena Sims, announce pregnancy
 - [https://www.foxnews.com/sports/brooks-koepka-wife-jena-sims-announce-pregnancy](https://www.foxnews.com/sports/brooks-koepka-wife-jena-sims-announce-pregnancy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:38:50+00:00

Four-time major winner and LIV Golf star Brooks Koepka and his wife, Jena Sims, announced on Instagram that they are expecting their first child.

## Ted Cruz says Biden's 'mental faculties are too diminished' for debt ceiling talks
 - [https://www.foxnews.com/politics/ted-cruz-biden-debt-ceiling-talks](https://www.foxnews.com/politics/ted-cruz-biden-debt-ceiling-talks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:37:05+00:00

More than a dozen Senate Republicans stood shoulder to shoulder on Wednesday in a show of unity behind the House GOP&apos;s debt limit bill

## Maria Menounos secretly survived pancreatic cancer ‘with excruciating abdominal pain’ while expecting a child
 - [https://www.foxnews.com/entertainment/maria-menounos-secretly-survived-pancreatic-cancer-pain-expecting-child](https://www.foxnews.com/entertainment/maria-menounos-secretly-survived-pancreatic-cancer-pain-expecting-child)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:33:57+00:00

Television personality Maria Menounos revealed she was diagnosed with pancreatic cancer in January. She and husband Keven Undergaro are expecting their first child via surrogate.

## Biden education secretary decries book banning after post-COVID test score plunge: A 'disservice' to students
 - [https://www.foxnews.com/media/biden-education-secretary-decries-book-banning-post-covid-test-score-plunge-disservice-students](https://www.foxnews.com/media/biden-education-secretary-decries-book-banning-post-covid-test-score-plunge-disservice-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:30:37+00:00

Biden Education Secretary Miguel Cardona criticized book &quot;banning&quot; for declining test scores following the latest numbers showing dips in history, civics proficiency.

## Missouri Gov. Parson plays key role in bill seeking control of policing, prosecution
 - [https://www.foxnews.com/us/missouri-gov-parson-plays-key-role-bill-seeking-control-policing-prosecution](https://www.foxnews.com/us/missouri-gov-parson-plays-key-role-bill-seeking-control-policing-prosecution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:29:14+00:00

Missouri&apos;s governor is playing a major role in a bill that would give the state greater control over policing and prosecution. The GOP-led bill is seen as a way to fight crime in St. Louis.

## Connecticut man gets 48 years for arranging attack that killed stepmother, wounded father
 - [https://www.foxnews.com/us/connecticut-man-48-years-arranging-attack-killed-stepmother-wounded-father](https://www.foxnews.com/us/connecticut-man-48-years-arranging-attack-killed-stepmother-wounded-father)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:26:23+00:00

Charles Dzurenka Jr. of Windsor, Connecticut, has been sentenced to 48 years in prison for ordering a knife attack that left his stepmother and her mother dead and his father injured.

## Rwanda floods leave at least 129 dead
 - [https://www.foxnews.com/world/rwanda-floods-leave-least-129-dead](https://www.foxnews.com/world/rwanda-floods-leave-least-129-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:24:32+00:00

Floods caused by torrential rainfall in northern and western Rwanda have left at least 129 people dead, according to a regional public broadcaster.

## Anticommunist dissident's shooting in Laos capital fuels investigation demand
 - [https://www.foxnews.com/world/anticommunist-dissidents-shooting-laos-capital-fuels-investigation-demand](https://www.foxnews.com/world/anticommunist-dissidents-shooting-laos-capital-fuels-investigation-demand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:23:18+00:00

International human rights groups are calling for an investigation into the Saturday shooting of Lao activist and outspoken government critic Anousa Luangsuphom.

## Belgrade school shooting: boy kills 9 in planned attack
 - [https://www.foxnews.com/world/belgrade-school-shooting-boy-kills-9-planned-attack](https://www.foxnews.com/world/belgrade-school-shooting-boy-kills-9-planned-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:23:09+00:00

The shooter, 13, who killed nine and injured six, is below Serbia&apos;s age of criminal responsibility — he will be placed in a psychiatric institution to serve his time.

## AP Stylebook advises journalists to put 'woke' in quotation marks, blames conservatives
 - [https://www.foxnews.com/us/ap-stylebook-advises-journalists-put-woke-quotation-marks-blames-conservatives](https://www.foxnews.com/us/ap-stylebook-advises-journalists-put-woke-quotation-marks-blames-conservatives)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:18:43+00:00

The AP Stylebook was mocked on social media for releasing guidance saying the word &quot;woke&quot; should be used in quotation marks due to &quot;derogatory&quot; use by conservatives.

## British tech chief warns AI's social impact 'as big as the Industrial Revolution,' urges national response
 - [https://www.foxnews.com/world/british-tech-chief-warns-ai-social-impact-big-industrial-revolution-urges-national-response](https://www.foxnews.com/world/british-tech-chief-warns-ai-social-impact-big-industrial-revolution-urges-national-response)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:18:07+00:00

Sir Patrick Vallance echoed the sentiments of fellow countryman and the &quot;Godfather of AI&quot; Geoffrey Hinton, who said he regretted creating the breakthrough that led to modern AI.

## Michigan school district bans backpacks amid gun concerns: ‘a difficult decision’
 - [https://www.foxnews.com/us/michigan-school-district-bans-backpacks-amid-gun-concerns-a-difficult-decision](https://www.foxnews.com/us/michigan-school-district-bans-backpacks-amid-gun-concerns-a-difficult-decision)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:17:17+00:00

Flint Community Schools in Michigan says the district will no longer be permitting backpacks on campuses in order to address rising safety concerns.

## Colorado woman jumped to her death from NYC hotel after fight with boyfriend
 - [https://www.foxnews.com/us/colorado-woman-jumped-death-new-york-city-hotel-fight-boyfriend-tyler-griffen](https://www.foxnews.com/us/colorado-woman-jumped-death-new-york-city-hotel-fight-boyfriend-tyler-griffen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:11:29+00:00

A Colorado couple&apos;s trip to New York City ended in horror Tuesday when the 20-year-old mother jumped to her death from the roof of their hotel following a violent fight.

## Florida to execute man for 1986 deadly stabbing, has last meal of fried chicken, cornbread
 - [https://www.foxnews.com/us/florida-execute-man-deadly-stabbing-has-last-meal-fried-chicken-cornbread](https://www.foxnews.com/us/florida-execute-man-deadly-stabbing-has-last-meal-fried-chicken-cornbread)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:11:21+00:00

A Florida death row inmate is set to be executed Wednesday for the 1986 killing of a 24-year-old woman.

## Four sisters are pregnant at the same time, due within six months of each other
 - [https://www.foxnews.com/lifestyle/four-sisters-pregnant-same-time-due-six-months-each-other](https://www.foxnews.com/lifestyle/four-sisters-pregnant-same-time-due-six-months-each-other)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:01:27+00:00

A family in central Scotland will welcome four children by the end of 2023 as four sisters are pregnant at the same time. Three sisters have one child already — one is a first-time mom.

## Bud Light is facing an 'unmitigated disaster' that is only getting worse, says Clay Travis
 - [https://www.foxnews.com/media/bud-light-facing-unmitigated-disaster-only-getting-worse-clay-travis](https://www.foxnews.com/media/bud-light-facing-unmitigated-disaster-only-getting-worse-clay-travis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:00:24+00:00

OutKick founder Clay Travis comments on Bud Light&apos;s woes after widespread backlash over a transgender campaign prompted a dramatic drop in sales.

## Mother of anxious child explores mental health crisis gripping young adults in 'Anxious Nation'
 - [https://www.foxnews.com/media/mother-anxious-child-explores-mental-health-crisis-gripping-young-adults-anxious-nation](https://www.foxnews.com/media/mother-anxious-child-explores-mental-health-crisis-gripping-young-adults-anxious-nation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 16:00:15+00:00

Author and filmmaker Laura Morton explores the struggles young adults and families face when dealing with anxiety in her new documentary &quot;Anxious Nation.&quot;

## Montana governor Greg Gianforte signs 5 pro-life bills: 'Every human life is precious and must be protected'
 - [https://www.foxnews.com/media/montana-governor-greg-gianforte-signs-5-pro-life-bills-every-human-life-precious-must-be-protected](https://www.foxnews.com/media/montana-governor-greg-gianforte-signs-5-pro-life-bills-every-human-life-precious-must-be-protected)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:59:29+00:00

Montana Governor Greg Gianforte highlighted several pro-life bills and signed five of them during a ceremony at the state capitol on Wednesday.

## 'Wheel of Fortune' host Pat Sajak jokes about stalking Vanna White in cheeky exchange
 - [https://www.foxnews.com/entertainment/wheel-fortune-host-pat-sajak-jokes-stalking-vanna-white-cheeky-exchange](https://www.foxnews.com/entertainment/wheel-fortune-host-pat-sajak-jokes-stalking-vanna-white-cheeky-exchange)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:57:14+00:00

In Tuesday night&apos;s episode of &quot;Wheel of Fortune,&quot; Pat Sajak implied he hung around Vanna White&apos;s backyard in the late hours of the night.

## College baseball player struck by stray bullet suffers partial paralysis, other severe injuries: report
 - [https://www.foxnews.com/sports/matthew-delaney-college-baseball-player-struck-stray-bullet-suffers-partial-paralysis-other-severe-injuries-report](https://www.foxnews.com/sports/matthew-delaney-college-baseball-player-struck-stray-bullet-suffers-partial-paralysis-other-severe-injuries-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:53:56+00:00

Texas A&amp;M University-Texarkana baseball player Matthew Delaney suffered serious injuries after he was shot in the chest by a stray bullet from a nearby shooting during a game.

## Biden nominee pushing electric vehicles faces massive opposition from energy industry
 - [https://www.foxnews.com/politics/biden-nominee-pushing-electric-vehicles-faces-massive-opposition-energy-industry](https://www.foxnews.com/politics/biden-nominee-pushing-electric-vehicles-faces-massive-opposition-energy-industry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:53:07+00:00

A sizable coalition of some of the nation&apos;s leading oil and gas industry organizations is sounding the alarm on President Biden&apos;s pick to lead an obscure agency.

## Lori Vallow threatened to 'cut' up bestie when friendship turned sour
 - [https://www.foxnews.com/us/lori-vallow-threatened-cut-up-bestie-when-friendship-turned-sour](https://www.foxnews.com/us/lori-vallow-threatened-cut-up-bestie-when-friendship-turned-sour)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:52:54+00:00

Lori Vallow&apos;s ex-friend, Audrey Barattiero, testified Tuesday that the &quot;cult mom&quot; threatened to kill her after Barattiero decided to end their friendship in 2019.

## Army helicopter collision in Alaska that killed 3 soldiers occurred in mountains, cause under investigation
 - [https://www.foxnews.com/us/army-helicopter-collision-alaska-killed-soldiers-mountains-cause-under-investigation](https://www.foxnews.com/us/army-helicopter-collision-alaska-killed-soldiers-mountains-cause-under-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:51:01+00:00

The Army identified three soldiers who were killed in a helicopter collision in Alaska last week

## Missouri man sentenced to prison for Jan. 6 participation
 - [https://www.foxnews.com/us/missouri-man-sentenced-prison-jan-6-participation](https://www.foxnews.com/us/missouri-man-sentenced-prison-jan-6-participation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:38:34+00:00

A Missouri man argued cases against participants in the Jan. 6, 2021, U.S. Capitol protests were unconstitutional. The man was found guilty in January of two misdemeanors related to storming the U.S. Capitol.

## Man charged in shooting that wounded 3 St. Louis officers
 - [https://www.foxnews.com/us/man-charged-shooting-wounded-3-st-louis-officers](https://www.foxnews.com/us/man-charged-shooting-wounded-3-st-louis-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:36:27+00:00

A man was charged Tuesday in a shooting that wounded three St. Louis police officers. Two other officers went to the man&apos;s home to check on his welfare.

## Jeffrey Epstein calendar reveals appointments with Woody Allen, former Clinton admin official, ex Israeli PM
 - [https://www.foxnews.com/us/jeffrey-epstein-private-calendar-reveals-appointments-woody-allen-former-clinton-admin-official-ex-israeli-pm](https://www.foxnews.com/us/jeffrey-epstein-private-calendar-reveals-appointments-woody-allen-former-clinton-admin-official-ex-israeli-pm)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:35:37+00:00

A newly revealed trove of Jeffrey Epstein documents reveals he had scheduled meetings with prominent figures such as Woody Allen and former Clinton Treasury Secretary Lawrence Summers.

## Mississippi teen accused of fatally shooting pregnant 16-year-old
 - [https://www.foxnews.com/us/mississippi-teen-accused-fatally-shooting-pregnant-16-year-old](https://www.foxnews.com/us/mississippi-teen-accused-fatally-shooting-pregnant-16-year-old)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:34:50+00:00

A Mississippi teenager is accused of killing a pregnant 16-year-old and her fetus. Three other teens were also arrested in connection with the homicide on Sunday.

## Mississippi man fatally shot by police after 16-hour standoff
 - [https://www.foxnews.com/us/mississippi-man-fatally-shot-police-16-hour-standoff](https://www.foxnews.com/us/mississippi-man-fatally-shot-police-16-hour-standoff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:33:17+00:00

A Mississippi man was shot and killed Wednesday by police after a 16-hour standoff. The Mississippi Bureau of Investigation is conducting an ongoing probe of the case.

## Ohio overturns conviction of man facing up to 12 years for stealing leaf blower
 - [https://www.foxnews.com/us/ohio-overturns-conviction-man-facing-12-years-stealing-leaf-blower](https://www.foxnews.com/us/ohio-overturns-conviction-man-facing-12-years-stealing-leaf-blower)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:30:27+00:00

The Ohio Supreme Court has overturned the burglary conviction of Donald Bertram, who stole a $500 leaf blower from his victim&apos;s garage.

## Sen. Rand Paul takes aim at Dr. Fauci in new book focused on the COVID-19 'cover-up'
 - [https://www.foxnews.com/politics/sen-rand-paul-takes-aim-dr-fauci-new-book-focused-covid-19-cover](https://www.foxnews.com/politics/sen-rand-paul-takes-aim-dr-fauci-new-book-focused-covid-19-cover)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:30:10+00:00

Sen. Rand Paul will release a book in October focusing on the origins of the coronavirus, as well as Dr. Anthony Fauci&apos;s role in the pandemic.

## Famous wooden 'Plybertruck' Tesla parody on sale
 - [https://www.foxnews.com/auto/famous-wooden-plybertruck-tesla-parody-sale](https://www.foxnews.com/auto/famous-wooden-plybertruck-tesla-parody-sale)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:29:42+00:00

A custom off-road SUV with a wooden body designed to look like the Tesla Cybertruck has been listed for sale on Facebook Marketplace in Arizona.

## Wisconsin lawmakers introduce healthcare cost transparency bill
 - [https://www.foxnews.com/politics/wisconsin-lawmakers-introduce-healthcare-cost-transparency-bill](https://www.foxnews.com/politics/wisconsin-lawmakers-introduce-healthcare-cost-transparency-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:29:09+00:00

A proposal by Republicans in the Wisconsin Legislature would impose daily fines ranging from $600 to $10,000 on hospitals that fail to comply with federal cost transparency regulations.

## Jamie Foxx breaks silence amid mystery ‘medical complication’
 - [https://www.foxnews.com/entertainment/jamie-foxx-breaks-silence-amid-mystery-medical-complication](https://www.foxnews.com/entertainment/jamie-foxx-breaks-silence-amid-mystery-medical-complication)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:23:48+00:00

Nick Cannon and Kelly Osbourne will take over Jamie Foxx&apos;s spot on &quot;Beat Shazam&quot; while the actor remains hospitalized. Foxx experienced a &quot;medical complication&quot; in April.

## NOAA offering reward up to $20,000 for information on boater seen allegedly harassing sea lions
 - [https://www.foxnews.com/us/noaa-offering-reward-20000-information-boater-allegedly-harassing-sea-lions](https://www.foxnews.com/us/noaa-offering-reward-20000-information-boater-allegedly-harassing-sea-lions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:20:54+00:00

The National Oceanic and Atmospheric Administration is offering a reward of up to $20,000 for information about a boater seen on camera harassing sea lions.

## Christian ex-teacher sues California district after refusing to hide kids' gender transitions from parents
 - [https://www.foxnews.com/us/christian-ex-teacher-sues-california-district-refusing-hide-kids-gender-transitions-parents](https://www.foxnews.com/us/christian-ex-teacher-sues-california-district-refusing-hide-kids-gender-transitions-parents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:09:45+00:00

A Christian ex-teacher claims she was fired after her California school district directed her to hide children&apos;s gender identities from parents.

## DeSantis backs bill to let 18-year-olds buy rifles
 - [https://www.foxnews.com/politics/desantis-backs-bill-let-18-year-olds-buy-rifles](https://www.foxnews.com/politics/desantis-backs-bill-let-18-year-olds-buy-rifles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:08:10+00:00

Florida Gov. Ron DeSantis on Wednesday backed a bill that would lower the minimum age to purchase a rifle to 18 in his state, calling current law &quot;unconstitutional.&quot;

## Federal prosecutors near decision on Hunter Biden probe: report
 - [https://www.foxnews.com/politics/federal-prosecutors-near-decision-hunter-biden-probe](https://www.foxnews.com/politics/federal-prosecutors-near-decision-hunter-biden-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:06:47+00:00

Federal prosecutors investigating President Biden&apos;s son Hunter Biden for alleged gun- and tax-related violations are reportedly nearing a decision in the four-year probe.

## Biden proposes tighter national security rules around military bases after Chinese real estate purchases
 - [https://www.foxnews.com/politics/biden-proposes-tighter-national-security-rules-military-bases-chinese-real-estate-purchases](https://www.foxnews.com/politics/biden-proposes-tighter-national-security-rules-military-bases-chinese-real-estate-purchases)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:00:52+00:00

The Biden administration is proposing to tighten security around eight new military installations by requiring a close review of nearby property transactions.

## Kyrsten Sinema calls out Karine Jean-Pierre: 'Anyone with eyes' can see this is not true
 - [https://www.foxnews.com/media/kyrsten-sinema-calls-karine-jean-pierre-anyone-eyes-see-true](https://www.foxnews.com/media/kyrsten-sinema-calls-karine-jean-pierre-anyone-eyes-see-true)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 15:00:01+00:00

Senators James Lankford, R-Okla., and Kyrsten Sinema, I-Ariz., joined &quot;Special Report&quot; to call out Karine Jean-Pierre for false statements about the border crisis

## Julianna Peña sidelined for fight against Amanda Nunes due to fractured rib, Dana White says
 - [https://www.foxnews.com/sports/julianna-pena-sidelined-fight-against-amanda-nunes-due-fractured-rib-dana-white-says](https://www.foxnews.com/sports/julianna-pena-sidelined-fight-against-amanda-nunes-due-fractured-rib-dana-white-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:53:34+00:00

A broken rib will force Julianna Peña to miss her third bout with Amanda Nunes at UFC 289, UFC President Dana White confirmed earlier this week.

## Florida bill clears $12M for DeSantis' migrant relocation initiative months after Martha's Vineyard flights
 - [https://www.foxnews.com/politics/florida-bill-clears-12m-desantis-migrant-relocation-initiative-months-marthas-vineyard-flights](https://www.foxnews.com/politics/florida-bill-clears-12m-desantis-migrant-relocation-initiative-months-marthas-vineyard-flights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:51:50+00:00

The Florida GOP controlled legislature passed sweeping immigration bill that allocates $12 million to Gov. Ron DeSantis&apos; &quot;Unauthorized Alien Transport Program.&quot;

## 3 Colorado teens charged with murder in rock-throwing death
 - [https://www.foxnews.com/us/3-colorado-teens-charged-murder-rock-throwing-death](https://www.foxnews.com/us/3-colorado-teens-charged-murder-rock-throwing-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:43:23+00:00

Three teenagers have been charged with murder after killing a 20-year-old woman by throwing large rocks at passing cars. The 18-year-olds allegedly attacked six cars in suburban Denver.

## Aid officials say Syria conditions dire, months after deadly quake
 - [https://www.foxnews.com/world/aid-officials-say-syria-conditions-dire-months-deadly-quake](https://www.foxnews.com/world/aid-officials-say-syria-conditions-dire-months-deadly-quake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:41:03+00:00

Aid officials said that three months after the massive Feb. 6 earthquake hit Turkey and Syria the living conditions remained dire in Syria’s rebel-held northwest.

## Chargers’ Quentin Johnston has big plans for Army veteran mother after being drafted
 - [https://www.foxnews.com/sports/chargers-quentin-johnston-has-big-plans-army-veteran-mother-being-drafted](https://www.foxnews.com/sports/chargers-quentin-johnston-has-big-plans-army-veteran-mother-being-drafted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:40:31+00:00

Los Angeles Chargers first-round draft pick Quentin Johnston told his mother he wanted her to retire after his selection as the 21st pick of the 2023 NFL Draft.

## Companies authorized to dodge excessive federal regulations under GOP bill
 - [https://www.foxnews.com/politics/joni-ernst-small-businesses-authorized-prove-it-act-of-2023-excessive-federal-regulations-gop-bill](https://www.foxnews.com/politics/joni-ernst-small-businesses-authorized-prove-it-act-of-2023-excessive-federal-regulations-gop-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:40:31+00:00

Sen. Joni Ernst spoke with reporters in her office just before unveiling the Prove It Act of 2023 to coincide with Small Business Week.

## Arizona man convicted of murder faces retrial in 6-year-old's death
 - [https://www.foxnews.com/us/arizona-man-convicted-murder-faces-retrial-6-year-olds-death](https://www.foxnews.com/us/arizona-man-convicted-murder-faces-retrial-6-year-olds-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:38:55+00:00

An Arizona man who was convicted of murder is facing a retrial for the death of a 6-year-old girl. He was tried for the same charges in February, but a mistrial was declared.

## US military carries out Syria drone strike targeting senior al-Qaida leader
 - [https://www.foxnews.com/world/us-military-carries-syria-drone-strike-targeting-senior-al-qaida-leader](https://www.foxnews.com/world/us-military-carries-syria-drone-strike-targeting-senior-al-qaida-leader)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:37:24+00:00

The U.S. military carried out a drone strike that targeted a senior al-Qaida leader in Syria. The strike hit a chicken farm near the town of Harem, which killed one person.

## `Insufficient support' blamed for Georgia courthouse floor collapse
 - [https://www.foxnews.com/us/insufficient-support-blamed-georgia-courthouse-floor-collapse](https://www.foxnews.com/us/insufficient-support-blamed-georgia-courthouse-floor-collapse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:35:46+00:00

A federal agency announced construction crews placed “insufficient support&quot; beneath part of an upper floor that collapsed during renovations on the historic federal courthouse in Georgia.

## California Democrat in key House race reveals DUI charges: 'I am so deeply sorry'
 - [https://www.foxnews.com/politics/california-democrat-in-key-house-race-reveals-dui-charges-i-am-so-deeply-sorry](https://www.foxnews.com/politics/california-democrat-in-key-house-race-reveals-dui-charges-i-am-so-deeply-sorry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:34:04+00:00

California state Senator David Min made a Facebook post revealing and apologizing for a misdemeanor citation for driving under the influence.

## Florida to execute prisoner for 1986 fatal stabbing of woman
 - [https://www.foxnews.com/us/florida-execute-prisoner-1986-fatal-stabbing-of-woman](https://www.foxnews.com/us/florida-execute-prisoner-1986-fatal-stabbing-of-woman)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:33:52+00:00

Florida is planning to execute a man for breaking into a woman’s home and stabbing her to death in 1986. Darryl B. Barwick is scheduled to be executed Wednesday in Florida.

## Native American tribe condemns Biden admin effort to ban oil, gas leasing on lands
 - [https://www.foxnews.com/politics/native-american-tribe-condemns-biden-admin-effort-ban-oil-gas-leasing-lands](https://www.foxnews.com/politics/native-american-tribe-condemns-biden-admin-effort-ban-oil-gas-leasing-lands)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:33:32+00:00

The Navajo Nation&apos;s legislative council approved a resolution this week condemning and opposing a Biden administration proposal banning oil and gas drilling.

## Turkey closes airspace to Armenian flights over objections to monument
 - [https://www.foxnews.com/world/turkey-closes-airspace-armenian-flights-objections-monument](https://www.foxnews.com/world/turkey-closes-airspace-armenian-flights-objections-monument)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:32:19+00:00

Turkey&apos;s foreign minister announced his country closed its airspace to Armenian aircraft, in retaliation for the erection of a monument in the Armenian capital, Yerevan.

## Democrats groan as Oklahoma superintendent calls teacher unions a 'terrorist organization'
 - [https://www.foxnews.com/media/democrats-groan-oklahoma-superintendent-calls-teacher-unions-terrorist-organization](https://www.foxnews.com/media/democrats-groan-oklahoma-superintendent-calls-teacher-unions-terrorist-organization)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:30:37+00:00

Oklahoma&apos;s top education official called teacher unions &quot;terrorist organizations,&quot; prompting groans from Democratic lawmakers.

## Swedes pass anti-terror legislation, likely to help NATO membership bid
 - [https://www.foxnews.com/world/swedes-pass-anti-terror-legislation-likely-help-nato-membership-bid](https://www.foxnews.com/world/swedes-pass-anti-terror-legislation-likely-help-nato-membership-bid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:30:23+00:00

Sweden passed anti-terror legislation that targets funding and assisting terrorist groups and joining terrorist group by travelling abroad. It is expected to aid the nation&apos;s NATO membership bid.

## Texas bill would let state secretary redo county election during ballot shortage
 - [https://www.foxnews.com/politics/texas-bill-would-let-state-secretary-redo-county-election-during-a-ballot-shortage](https://www.foxnews.com/politics/texas-bill-would-let-state-secretary-redo-county-election-during-a-ballot-shortage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:22:52+00:00

The Texas state senate has passed a bill that would grant the state secretary authority to order elections be redone if ballot shortages compromise voting.

## Meghan Markle ready for Hollywood comeback? Duchess of Sussex ‘has a knack for getting what she wants’: expert
 - [https://www.foxnews.com/entertainment/meghan-markle-ready-hollywood-comeback-duchess-sussex-knack-getting](https://www.foxnews.com/entertainment/meghan-markle-ready-hollywood-comeback-duchess-sussex-knack-getting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:20:51+00:00

Shortly before King Charles III&apos;s coronation, Meghan Markle signed with WME. The Duchess of Sussex will be in California with her son Prince Archie and daughter Princess Lilibet.

## New York Republican Lee Zeldin 'keeping an eye' on run against Democrat Sen Kirsten Gillibrand
 - [https://www.foxnews.com/politics/new-york-republican-lee-zeldin-keeping-eye-run-against-democrat-sen-kirsten-gillibrand](https://www.foxnews.com/politics/new-york-republican-lee-zeldin-keeping-eye-run-against-democrat-sen-kirsten-gillibrand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:16:25+00:00

Former GOP Rep. Lee Zeldin, who ran against New York Gov. Kathy Hochul, said he would &quot;keep on eye on&quot; Democrat Sen. Kirsten Gillibrand&apos;s reelection bid.

## Nashville police delay Covenant School shooting manifesto release
 - [https://www.foxnews.com/us/nashville-police-delay-covenant-school-shooting-manifesto-release](https://www.foxnews.com/us/nashville-police-delay-covenant-school-shooting-manifesto-release)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:14:18+00:00

The Metropolitan Nashville Police Department is delaying the release of records belonging to Nashville Covenant School shooter Audrey Elizabeth Hale.

## 258 million people faced acute food insecurity in 2020, UN reports
 - [https://www.foxnews.com/world/258-million-people-faced-acute-food-insecurity-2020-un-reports](https://www.foxnews.com/world/258-million-people-faced-acute-food-insecurity-2020-un-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:06:40+00:00

More than a quarter-billion people faced acute food insecurity during the pandemic, according to a United Nations report. The worst-off countries include Afghanistan, Yemen, and Haiti.

## Lawsuit begins over ‘Kansas two step’ tactic possibly used to search vehicles without legitimate cause
 - [https://www.foxnews.com/us/lawsuit-begins-kansas-two-step-tactic-possibly-search-vehicles-without-legitimate-cause](https://www.foxnews.com/us/lawsuit-begins-kansas-two-step-tactic-possibly-search-vehicles-without-legitimate-cause)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:06:18+00:00

A lawsuit over a “Kansas two step&quot; vehicle search tactic will be heard this week. The suit claimed that troopers would pull over a car without any legitimate cause.

## Artwork shown in museums can make people happier on one condition, says study
 - [https://www.foxnews.com/lifestyle/artwork-shown-museums-make-people-happier-one-condition-study](https://www.foxnews.com/lifestyle/artwork-shown-museums-make-people-happier-one-condition-study)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:05:00+00:00

A new study out of the University of Florence in Italy has found that improving the cultural experience of &quot;non-expert&quot; visitors is critical work for art museums — here&apos;s how.

## Oregon Democrats backpedal after massive public outcry against bill allowing homeless to sue over encampments
 - [https://www.foxnews.com/politics/oregon-democrats-backpedal-massive-public-outcry-bill-allowing-homeless-sue-encampments](https://www.foxnews.com/politics/oregon-democrats-backpedal-massive-public-outcry-bill-allowing-homeless-sue-encampments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:01:47+00:00

Oregon lawmakers were scheduled to hold a public hearing this week on a bill decriminalizing homeless camping. Then thousands of negative comments poured in.

## Whistleblower alleges FBI, DOJ have document revealing criminal scheme involving Biden, foreign national
 - [https://www.foxnews.com/politics/whistleblower-alleges-fbi-doj-have-document-revealing-scheme-involving-biden-foreign-national](https://www.foxnews.com/politics/whistleblower-alleges-fbi-doj-have-document-revealing-scheme-involving-biden-foreign-national)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:00:55+00:00

A whistleblower is alleging that the FBI and the Justice Department are in possession of a document that describes an alleged criminal scheme involving then-Vice President Joe Biden and a foreign national relating to the exchange of money for policy decisions, House Oversight Committee Chairman James Comer and Sen. Chuck Grassley said Wednesday.

## Laura Ingraham reveals 'heartbreaking' state of San Francisco as open-air drug market fuels addiction
 - [https://www.foxnews.com/media/laura-ingraham-reveals-heartbreaking-state-san-francisco-open-air-drug-market-fuels-addiction](https://www.foxnews.com/media/laura-ingraham-reveals-heartbreaking-state-san-francisco-open-air-drug-market-fuels-addiction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:00:53+00:00

Laura Ingraham took a second trip to San Francisco to investigate the city&apos;s drug crisis as the Tenderloin district remains &apos;ground zero&apos; for city addicts.

## Musk threatens to give NPR's Twitter handle to another account
 - [https://www.foxnews.com/media/musk-threatens-give-nprs-twitter-handle-another-account](https://www.foxnews.com/media/musk-threatens-give-nprs-twitter-handle-another-account)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 14:00:27+00:00

A National Public Radio report complained that Twitter head Elon Musk was threatening to give the news outlet&apos;s Twitter handle to another account.

## ‘Large’ snake causes power outage at Virginia intersection during morning rush hour
 - [https://www.foxnews.com/us/large-snake-causes-power-outage-virginia-intersection-morning-rush-hour](https://www.foxnews.com/us/large-snake-causes-power-outage-virginia-intersection-morning-rush-hour)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:50:33+00:00

Drivers in Prince William County, Virginia, were briefly delayed Monday when a snake cut off power to traffic lights at a busy intersection, authorities said.

## Texas shooting: Timeline how Cleveland massacre ignited 4-day manhunt resulting in illegal immigrant's arrest
 - [https://www.foxnews.com/us/texas-shooting-timeline-how-cleveland-massacre-ignited-4-day-manhunt-resulting-illegal-immigrants-arrest](https://www.foxnews.com/us/texas-shooting-timeline-how-cleveland-massacre-ignited-4-day-manhunt-resulting-illegal-immigrants-arrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:47:50+00:00

A timeline details how Francisco Oropesa, an illegal immigrant, allegedly fatally shot 5 neighbors in Cleveland, Texas, launching a massive 4-day manhunt.

## Knife attack at Berlin school seriously injures 2 young girls
 - [https://www.foxnews.com/world/knife-attack-berlin-school-seriously-injures-2-young-girls](https://www.foxnews.com/world/knife-attack-berlin-school-seriously-injures-2-young-girls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:40:00+00:00

A 39-year-old suspect allegedly attacked students at a school in Berlin, Germany. Two young girls, ages 7 and 8, sustained serious injuries.

## Former FBI supervisory agent arrested in Oregon for his involvement in the Jan. 6 protest
 - [https://www.foxnews.com/us/former-fbi-supervisory-agent-arrested-oregon-involvement-jan-6-protest](https://www.foxnews.com/us/former-fbi-supervisory-agent-arrested-oregon-involvement-jan-6-protest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:39:21+00:00

An ex-FBI supervisory agent was arrested in Oregon for his role in the Jan. 6 Capitol protest. The man also cheered on protestors attacking police officers.

## SEE IT: New Jersey 'neighbors from hell' allegedly try to run over police officers with car, injuring K9
 - [https://www.foxnews.com/us/see-new-jersey-neighbors-hell-allegedly-try-run-over-police-officers-car-injuring-k9](https://www.foxnews.com/us/see-new-jersey-neighbors-hell-allegedly-try-run-over-police-officers-car-injuring-k9)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:38:52+00:00

Police body camera footage shows a New Jersey man attempting to run over officers with his vehicle while his partner threatens police in the background.

## Nearly half of all 2022 midterm voters cast ballots early or by mail
 - [https://www.foxnews.com/politics/nearly-half-2022-midterm-voters-cast-ballots-early-mail](https://www.foxnews.com/politics/nearly-half-2022-midterm-voters-cast-ballots-early-mail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:38:13+00:00

According to new data released by the U.S. Census Bureau, casting ballots early or by mail were popular voting methods during the 2022 midterm elections.

## 'They'll never catch me': Vegas shoplifter arrested after taunting cops in viral video back on the run again
 - [https://www.foxnews.com/us/theyll-never-catch-me-vegas-shoplifter-arrested-taunting-cops-viral-video-back-run-again](https://www.foxnews.com/us/theyll-never-catch-me-vegas-shoplifter-arrested-taunting-cops-viral-video-back-run-again)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:31:38+00:00

A Las Vegas woman who was arrested after taunting police that she&apos;d never be caught shoplifting is now on the run once again after missing her court date.

## Dee Snider backs fellow rocker’s stance against gender treatments for kids: No 'rash conclusions'
 - [https://www.foxnews.com/media/dee-snider-backs-fellow-rockers-stance-against-gender-treatments-kids-no-rash-conclusions](https://www.foxnews.com/media/dee-snider-backs-fellow-rockers-stance-against-gender-treatments-kids-no-rash-conclusions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:30:45+00:00

Twisted Sister rocker Dee Snider defended KISS star Paul Stanley&apos;s controversial stance against gender-affirming care for minors with a tweet posted Monday.

## Sunny Hostin fumes over Donald Trump doing televised town hall: 'I'm so disgusted'
 - [https://www.foxnews.com/media/sunny-hostin-fumes-over-donald-trump-doing-televised-town-hall-disgusted](https://www.foxnews.com/media/sunny-hostin-fumes-over-donald-trump-doing-televised-town-hall-disgusted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:25:26+00:00

&quot;The View&quot; co-host Sunny Hostin was furious on Monday over CNN planning to host a town hall with Donald Trump and insisted they shouldn&apos;t give him a platform.

## Biden admin secures deal with Mexico to deport some non-Mexican migrants ahead of Title 42 bedlam
 - [https://www.foxnews.com/politics/biden-admin-secures-deal-mexico-deport-some-non-mexican-migrants-ahead-title-42-bedlam](https://www.foxnews.com/politics/biden-admin-secures-deal-mexico-deport-some-non-mexican-migrants-ahead-title-42-bedlam)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:21:49+00:00

The U.S. and Mexico have announced that Mexico will continue to accept non-Mexican migrant deportations when Title 42 ends on May 11, the White House announced.

## King Charles, Prince William and Kate Middleton’s 3 kids prepare for coronation with royal family rehearsal
 - [https://www.foxnews.com/entertainment/king-charles-prince-william-kate-middletons-3-kids-prepare-coronation](https://www.foxnews.com/entertainment/king-charles-prince-william-kate-middletons-3-kids-prepare-coronation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:21:49+00:00

Prince William, Princess Kate and royal family members gear up for King Charles III&apos;s coronation with a rehearsal at Westminster Abbey.

## Atlanta 'active shooter' situation leaves at least 1 dead, 4 injured, police say
 - [https://www.foxnews.com/us/atlanta-active-shooter-situation-leaves-multiple-people-injured-police-say](https://www.foxnews.com/us/atlanta-active-shooter-situation-leaves-multiple-people-injured-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:21:04+00:00

A suspected gunman is on the loose following an &quot;active shooter&quot; situation inside a building in Atlanta, authorities said Wednesday.

## Innocent LA father killed after DA Gascon gives violent career criminal multiple diversions
 - [https://www.foxnews.com/politics/innocent-la-father-killed-da-gascon-gives-violent-career-criminal-multiple-diversions](https://www.foxnews.com/politics/innocent-la-father-killed-da-gascon-gives-violent-career-criminal-multiple-diversions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:13:25+00:00

A career criminal who District Attorney George Gascon&apos;s office kept out of jail is accused of killing a Los Angeles father of two in April, police say.

## Virginia police officer narrowly avoids getting hit by out-of-control BMW
 - [https://www.foxnews.com/us/virginia-police-officer-narrowly-avoids-getting-hit-bmw](https://www.foxnews.com/us/virginia-police-officer-narrowly-avoids-getting-hit-bmw)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:06:26+00:00

A Fairfax County Police officer is seen on video escaping after a car traveling at a high rate of speed crashed into a vehicle he had pulled over.

## Ousted White House aide who made ‘abhorrent’ attack on female reporter sneaking back in Biden’s orbit: report
 - [https://www.foxnews.com/politics/ousted-white-house-aide-abhorrent-attack-female-reporter-sneaking-back-bidens-orbit-report](https://www.foxnews.com/politics/ousted-white-house-aide-abhorrent-attack-female-reporter-sneaking-back-bidens-orbit-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:02:23+00:00

A disgraced former member of President Biden&apos;s White House is likely to be rehired to work on the president&apos;s 2024 re-election campaign, according to media reports.

## Kilmeade confronts Dem Texas mayor for not calling out Biden over migrant surge: 'He destroyed your city'
 - [https://www.foxnews.com/media/kilmeade-confronts-dem-texas-mayor-calling-biden-migrant-surge-destroyed-city](https://www.foxnews.com/media/kilmeade-confronts-dem-texas-mayor-calling-biden-migrant-surge-destroyed-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:00:27+00:00

&quot;Fox &amp; Friends&quot; co-host Brian Kilmeade called out El Paso Mayor Oscar Leeser for refusing to call out the Biden administration over the border crisis.

## Regulation could allow China to dominate in the artificial intelligence race, experts warn: 'We will lose'
 - [https://www.foxnews.com/media/regulation-allow-china-dominate-artificial-intelligence-race-experts-warn-we-will-lose](https://www.foxnews.com/media/regulation-allow-china-dominate-artificial-intelligence-race-experts-warn-we-will-lose)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 13:00:26+00:00

Calls for Congress to regulate artificial intelligence could be premature and allow China to dominate globally in the industry, experts warned.

## Protesters loudly disrupt Gov. Abbott school choice event at church: 'You're a traitor'
 - [https://www.foxnews.com/politics/protesters-disrupt-gov-abbott-school-choice-event-church-traitor](https://www.foxnews.com/politics/protesters-disrupt-gov-abbott-school-choice-event-church-traitor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:59:53+00:00

Disruptors gathered to protest Gov. Greg Abbott&apos;s push for school voucher programs, calling him a &quot;traitor&quot; while he was giving a speech in southeast Houston Tuesday.

## South Carolina Democrats express frustration with Republicans for not taking action on hate crimes bill
 - [https://www.foxnews.com/politics/south-carolina-democrats-frustrated-republicans-not-taking-action-hate-crimes-bill](https://www.foxnews.com/politics/south-carolina-democrats-frustrated-republicans-not-taking-action-hate-crimes-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:53:30+00:00

For the past three years, Democrats in South Carolina have not been able to pass a hate crimes bill. Republican leaders said they don’t believe the bill will solve the problem of hate.

## FLASHBACK: Alvin Bragg invoked race while comparing Trump to Epstein, Weinstein: 'Rich old White man'
 - [https://www.foxnews.com/politics/alvin-bragg-invoked-race-comparing-trump-epstein-weinstein-rich-old-white-man](https://www.foxnews.com/politics/alvin-bragg-invoked-race-comparing-trump-epstein-weinstein-rich-old-white-man)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:52:28+00:00

Manhattan District Attorney Alvin Bragg compared former President Trump to sex criminals Harvey Weinstein and Jeffrey Epstein during his 2021 campaign.

## Washington’s Howard University appoints African diaspora scholar as next president
 - [https://www.foxnews.com/us/washingtons-howard-university-appoints-african-diaspora-scholar-next-president](https://www.foxnews.com/us/washingtons-howard-university-appoints-african-diaspora-scholar-next-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:48:53+00:00

African diaspora scholar Ben Vinson III will officially become Howard University’s next president. Vinson will start on Sept. 1 at the historically Black university in Washington.

## Jets’ Aaron Rodgers ‘having a blast’ in New York after trade: ‘Pinching myself a lot of days’
 - [https://www.foxnews.com/sports/jets-aaron-rodgers-having-blast-new-york-trade-pinching-myself-lot-days](https://www.foxnews.com/sports/jets-aaron-rodgers-having-blast-new-york-trade-pinching-myself-lot-days)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:47:50+00:00

New York Jets quarterback Aaron Rodgers said Tuesday he&apos;s &quot;having an absolute blast&quot; in the city after being traded by the Green Bay Packers.

## North Carolina House advances legislation banning gender surgeries for minors
 - [https://www.foxnews.com/politics/north-carolina-house-advances-legislation-banning-gender-surgeries-minors](https://www.foxnews.com/politics/north-carolina-house-advances-legislation-banning-gender-surgeries-minors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:46:30+00:00

A North Carolina House committee has approved a measure that prohibits health care providers from performing gender surgeries on minors.

## Aaron Rodgers' longtime teammate Randall Cobb following him to the Jets: reports
 - [https://www.foxnews.com/sports/aaron-rodgers-longtime-teammate-randall-cobb-following-him-jets-reports](https://www.foxnews.com/sports/aaron-rodgers-longtime-teammate-randall-cobb-following-him-jets-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:44:43+00:00

Aaron Rodgers received another favorite target on Tuesday. Randall Cobb reportedly agreed to sign with the New York Jets on a one-year deal.

## NYC alleged shoplifter hits Walgreens security guard on video – guard arrested on assault charge
 - [https://www.foxnews.com/us/nyc-alleged-shoplifter-hits-walgreens-security-guard-video-guard-arrested-assault-charge](https://www.foxnews.com/us/nyc-alleged-shoplifter-hits-walgreens-security-guard-video-guard-arrested-assault-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:41:38+00:00

An alleged shoplifter failed to show up to a court appearance after getting into a scuffle with a security guard at a Walgreens store, a report said.

## Wisconsin train repaired, returned to service following derailment into Mississippi River
 - [https://www.foxnews.com/us/wisconsin-train-repaired-returned-service-following-derailment-mississippi-river](https://www.foxnews.com/us/wisconsin-train-repaired-returned-service-following-derailment-mississippi-river)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:39:53+00:00

A train that derailed in Wisconsin has been repaired and returned to service. All of the tracks involved in the derailment were repaired, and trains are already running at full speed.

## Outsmart spammers to finally end unsolicited emails
 - [https://www.foxnews.com/tech/outsmart-spammers-finally-end-unsolicited-emails](https://www.foxnews.com/tech/outsmart-spammers-finally-end-unsolicited-emails)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:30:42+00:00

Scammers are now targeting email users via spam unsubscribe emails. Kurt &quot;Cyberguy&quot; Knutsson tells you how to block senders and use an alias email address.

## Sen. Ted Cruz lands his first major Democratic challenger in 2024 re-election bid
 - [https://www.foxnews.com/politics/sen-ted-cruz-lands-first-major-democratic-challenger-runs-re-election-texas](https://www.foxnews.com/politics/sen-ted-cruz-lands-first-major-democratic-challenger-runs-re-election-texas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:25:26+00:00

Former professional football player now Texas Rep. Colin Allred launched a 2024 Democratic Senate challenge Wednesday against conservative firebrand Sen. Ted Cruz.

## Patrick Cantlay hires Tiger Woods' longtime caddie Joe LaCava amid uncertainty following ankle surgery
 - [https://www.foxnews.com/sports/patrick-cantlay-hires-tiger-woods-longtime-caddie-joe-lacava-amid-uncertainty-following-ankle-surgery](https://www.foxnews.com/sports/patrick-cantlay-hires-tiger-woods-longtime-caddie-joe-lacava-amid-uncertainty-following-ankle-surgery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:18:07+00:00

Patrick Cantlay has hired Tiger Woods&apos; longtime caddie, Joe LaCava, as Woods recovers from ankle surgery.

## Florida teacher accused of 'touching' student orchestrated elaborate cover-up: police
 - [https://www.foxnews.com/us/florida-teacher-accused-of-touching-student-orchestrated-elaborate-cover-up-police](https://www.foxnews.com/us/florida-teacher-accused-of-touching-student-orchestrated-elaborate-cover-up-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:14:58+00:00

Michele Little, 29, allegedly had a sexual relationship with a male student in Sarasota Military Academy High School, where she taught for &quot;several weeks,&quot; Sarasota police said.

## Electric Ford Mustang Mach-E prices slashed as range and power go up
 - [https://www.foxnews.com/auto/electric-ford-mustang-mach-e-prices-slashed-range-power](https://www.foxnews.com/auto/electric-ford-mustang-mach-e-prices-slashed-range-power)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:05:36+00:00

Prices for the Ford Mustang Mach-E have been cut up to $4,000 thanks to new battery technology and increased production of the electric SUV.

## GOP senators urge Biden to reverse Title 42 termination, citing estimates of migrant deluge
 - [https://www.foxnews.com/politics/gop-senators-urge-biden-reverse-title-42-termination-citing-estimates-migrant-deluge](https://www.foxnews.com/politics/gop-senators-urge-biden-reverse-title-42-termination-citing-estimates-migrant-deluge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:01:27+00:00

A group of Republican senators are calling on President Biden to reverse the decision to end the Title 42 public health order next week amid fears of a new surge.

## Cowboys executive disputes Deion Sanders’ statement on lack of HBCU players drafted: ‘Not a conspiracy’
 - [https://www.foxnews.com/sports/cowboys-executive-disputes-deion-sanders-statement-lack-hbcu-players-drafted-not-conspiracy](https://www.foxnews.com/sports/cowboys-executive-disputes-deion-sanders-statement-lack-hbcu-players-drafted-not-conspiracy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:00:27+00:00

Dallas Cowboys vice president of player personnel Will McClay disputed Deion Sanders&apos; statements about the lack of HBCU players selected in the NFL Draft.

## Former Texas Rep calls for firing Mayorkas, blasts Biden over border policy: 'This administration is ignorant'
 - [https://www.foxnews.com/media/former-texas-rep-calls-firing-mayorkas-blasts-biden-over-border-policy-administration-ignorant](https://www.foxnews.com/media/former-texas-rep-calls-firing-mayorkas-blasts-biden-over-border-policy-administration-ignorant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:00:15+00:00

Former Texas Congressman Will Hurd blasted President Biden&apos;s administration as &quot;ignorant&quot; on border policy and suggested DHS Secretary Mayorkas be fired.

## Stabbings leave UC Davis on edge as many students opt for remote classes: 'People are worried to go outside'
 - [https://www.foxnews.com/media/stabbings-leave-uc-davis-edge-students-opt-remote-classes-people-worried-go-outside](https://www.foxnews.com/media/stabbings-leave-uc-davis-edge-students-opt-remote-classes-people-worried-go-outside)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:00:11+00:00

UC Davis graduate Karan Brar called for increased police presence, surveillance cameras and extended lighting around the city after three separate stabbing incidents.

## Riley Gaines never considered herself a feminist. Then she raced Lia Thomas
 - [https://www.foxnews.com/sports/riley-gaines-never-considered-feminist-raced-lia-thomas](https://www.foxnews.com/sports/riley-gaines-never-considered-feminist-raced-lia-thomas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 12:00:00+00:00

NCAA swimmer Riley Gaines never called herself a feminist. Then she tied Lia Thomas, a transgender athlete, in the 2022 championship. That changed everything for Gaines.

## North Carolina Republicans back measure banning abortion after 1st trimester
 - [https://www.foxnews.com/politics/north-carolina-republicans-back-measure-banning-abortion-1st-trimester](https://www.foxnews.com/politics/north-carolina-republicans-back-measure-banning-abortion-1st-trimester)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:57:13+00:00

The GOP-dominated legislature in North Carolina is backing a measure that would restrict abortions to only pregnant women in their first trimester.

## Gas leak at German high school exposes at least 84 to suspected irritant gas
 - [https://www.foxnews.com/world/gas-leak-german-high-school-exposes-least-84-suspected-irritant-gas](https://www.foxnews.com/world/gas-leak-german-high-school-exposes-least-84-suspected-irritant-gas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:45:51+00:00

Both students and teachers at a German high school were exposed to an irritant gas. Three students and a teacher were taken to a hospital following the gas leak.

## Jamie Foxx reportedly still hospitalized as friend begs for prayers
 - [https://www.foxnews.com/entertainment/jamie-foxx-reportedly-still-hospitalized-friend-begs-prayers](https://www.foxnews.com/entertainment/jamie-foxx-reportedly-still-hospitalized-friend-begs-prayers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:44:17+00:00

Jamie Foxx is in need of prayers, according to his friend Charlie Mack, while the actor reportedly remains hospitalized after suffering a &quot;medical complication&quot; last month.

## New Hampshire pays tribute to the Old Man of the Mountain 20 years after it crumbled
 - [https://www.foxnews.com/us/new-hampshire-pays-tribute-man-mountain-20-years-after-crumbled](https://www.foxnews.com/us/new-hampshire-pays-tribute-man-mountain-20-years-after-crumbled)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:39:21+00:00

New Hampshire residents paid tribute to the fallen Old Man of the Mountain with poetry, a song, and a scavenger hunt. The celebration came nearly 20 years after the structure crumbled.

## Russia reducing Victory Day celebrations in wake of Ukraine war losses, drone attacks
 - [https://www.foxnews.com/world/russia-reducing-victory-day-celebrations-wake-ukraine-war-losses-drone-attacks](https://www.foxnews.com/world/russia-reducing-victory-day-celebrations-wake-ukraine-war-losses-drone-attacks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:37:01+00:00

Russian President Vladimir Putin has previously used the Victory Day celebrations as a moment to push his propaganda, including a rallying cry to &quot;denazify&quot; Ukraine in 2021.

## Brazil's federal police search home of former President Bolsonaro over alleged doctored vaccine cards
 - [https://www.foxnews.com/world/brazils-federal-police-search-home-former-president-bolsonaro-over-alleged-doctored-vaccine-cards](https://www.foxnews.com/world/brazils-federal-police-search-home-former-president-bolsonaro-over-alleged-doctored-vaccine-cards)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:32:37+00:00

Former Brazilian President Jair Bolsonaro had his home searched and phone seized by Brazil&apos;s Federal Police Wednesday in an investigation into alleged doctored vaccine cards.

## Schmitt targets federal regulations in first Senate bill, calls Biden ‘poster child’ for excessive rules
 - [https://www.foxnews.com/politics/schmitt-targets-federal-regulations-first-senate-bill-biden-poster-child-excessive-rules](https://www.foxnews.com/politics/schmitt-targets-federal-regulations-first-senate-bill-biden-poster-child-excessive-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:30:24+00:00

Senator Eric Schmitt&apos;s first authored legislation is aimed at stripping the power of federal agencies to over regulate and &quot;rein in the Administrative State.&quot;

## Tori Bowie, Olympic gold medalist in 2016, dead at 32
 - [https://www.foxnews.com/sports/tori-bowie-olympic-gold-medalist-dead](https://www.foxnews.com/sports/tori-bowie-olympic-gold-medalist-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:29:20+00:00

Tori Bowe, a superstar track and field athlete, who won NCAA championships in long jump and was a three-time medalist in the Olympics, has died. She was 32.

## Anheuser-Busch gives away free Bud Light to 'make amends' to distributors after Mulvaney controversy: Report
 - [https://www.foxnews.com/media/anheuser-busch-gives-away-free-bud-light-make-amends-distributors-after-mulvaney-controversy-report](https://www.foxnews.com/media/anheuser-busch-gives-away-free-bud-light-make-amends-distributors-after-mulvaney-controversy-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:28:07+00:00

Anheuser-Busch has given away free cases of Bud Light to distributors as a way to make amends for the Dylan Mulvaney controversy, according to a report.

## Christian evangelists at Boston's SatanCon claim about 100 people converted: 'We're in a battle'
 - [https://www.foxnews.com/us/christian-evangelists-bostons-satancon-claim-about-100-people-converted-were-in-battle](https://www.foxnews.com/us/christian-evangelists-bostons-satancon-claim-about-100-people-converted-were-in-battle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:26:30+00:00

Christians with an organized evangelism outreach at SatanCon in Boston over the weekend told Fox News Digital approximately 100 people converted to Christianity.

## Florida prosecutors seek death penalty in Jared Bridegan murder
 - [https://www.foxnews.com/us/florida-prosecutors-seek-death-penalty-jared-bridegan-murder](https://www.foxnews.com/us/florida-prosecutors-seek-death-penalty-jared-bridegan-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:21:38+00:00

Mario Fernandez, accused of the murder of Microsoft executive Jared Bridegan, could face the death penalty if convicted, Florida prosecutors announced Wednesday in court.

## AI brain activity decoder can reveal stories in peoples' minds, researchers say
 - [https://www.foxnews.com/science/ai-brain-activity-decoder-can-reveal-stories-peoples-minds-researchers-say](https://www.foxnews.com/science/ai-brain-activity-decoder-can-reveal-stories-peoples-minds-researchers-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:17:08+00:00

An artificial intelligence system developed at the University of Texas is able to translate a subject&apos;s brain activity into a stream of text after storytelling.

## Alabama church shooter sentenced to life for murdering 3 at potluck dinner
 - [https://www.foxnews.com/us/alabama-church-shooter-sentenced-life-murdering-3-potluck-dinner](https://www.foxnews.com/us/alabama-church-shooter-sentenced-life-murdering-3-potluck-dinner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:15:24+00:00

A 71-year-old man has been sentenced to life in prison for fatally shooting three elderly people during a potluck dinner at an Alabama church near Birmingham.

## Mom shoots ‘belligerently’ drunk man trying to set house on fire with elderly uncle, child inside: sheriff
 - [https://www.foxnews.com/us/mom-shoots-belligerently-drunk-man-trying-set-house-fire-elderly-uncle-child-inside-sheriff](https://www.foxnews.com/us/mom-shoots-belligerently-drunk-man-trying-set-house-fire-elderly-uncle-child-inside-sheriff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:13:12+00:00

An Alabama woman fatally shot a man who allegedly tried to burn down a home where she, her 8-year-old daughter and elderly uncle resided, the Mobile Sheriff&apos;s Office says.

## 2024 Dem primary polls are flashing warning signs about Biden's re-election campaign
 - [https://www.foxnews.com/politics/2024-dem-primary-polls-are-flashing-warning-signs-about-bidens-re-election-campaign](https://www.foxnews.com/politics/2024-dem-primary-polls-are-flashing-warning-signs-about-bidens-re-election-campaign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:10:13+00:00

The 2024 Democratic primary polls are a flashing warning sign for President Biden&apos;s re-election campaign as his two Democratic challengers gain steam.

## 9 killed in explosion at Chinese petrochemical plant, 3 others dead in helicopter crash
 - [https://www.foxnews.com/world/9-killed-explosion-chinese-petrochemical-plant-3-dead-helicopter-crash](https://www.foxnews.com/world/9-killed-explosion-chinese-petrochemical-plant-3-dead-helicopter-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:03:31+00:00

Three people died in a helicopter crash in China. At least nine others were killed in an explosion at a petrochemical plant during the country&apos;s May Day celebrations.

## Missing Madeleine McCann's parents 'await a breakthrough' in toddler's kidnapping
 - [https://www.foxnews.com/world/missing-madeleine-mccanns-parents-await-breakthrough-toddlers-kidnapping](https://www.foxnews.com/world/missing-madeleine-mccanns-parents-await-breakthrough-toddlers-kidnapping)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:01:48+00:00

Kate and Gerry McCann, the parents of missing British girl Madeleine McCann, said they &quot;await a breakthrough&quot; in a Tuesday statement marking 16 years since their daughter disappeared.

## Top medical programs exposed for providing gender-affirming care to toddlers
 - [https://www.foxnews.com/media/top-medical-programs-exposed-providing-gender-affirming-care-toddlers](https://www.foxnews.com/media/top-medical-programs-exposed-providing-gender-affirming-care-toddlers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 11:00:48+00:00

Top medical programs in North Carolina are reportedly offering &apos;gender-affirming&apos; care for children as young as two, according to a bombshell report.

## Flooding in Italy leaves at least 2 dead
 - [https://www.foxnews.com/world/flooding-italy-leaves-least-2-dead](https://www.foxnews.com/world/flooding-italy-leaves-least-2-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:58:26+00:00

Nonstop flooding in Italy left at least two people dead in the populous Emilia-Romagna region. One of the people who died was swept away by flood waters while riding a bike.

## Pelosi continues massive private jet spending after relinquishing leadership post
 - [https://www.foxnews.com/politics/pelosi-continues-massive-private-jet-spending-after-relinquishing-leadership-post](https://www.foxnews.com/politics/pelosi-continues-massive-private-jet-spending-after-relinquishing-leadership-post)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:57:53+00:00

Democratic Rep. Nancy Pelosi dropped more than $40,000 into private jets from her campaign&apos;s coffers during the first three months of the year, filings show.

## Celebrate Mother's Day by learning cooking and kitchen secrets from real-life moms
 - [https://www.foxnews.com/lifestyle/celebrate-mothers-day-learning-cooking-kitchen-secrets-real-life-moms](https://www.foxnews.com/lifestyle/celebrate-mothers-day-learning-cooking-kitchen-secrets-real-life-moms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:52:09+00:00

In celebration of Mother&apos;s Day, here are eight tried-and-true kitchen secrets from real-life moms. Give them a try the next time you cook a meal in your own kitchen.

## Who are the Cleveland, Texas mass shooting victims?
 - [https://www.foxnews.com/us/who-cleveland-texas-mass-shooting-victims](https://www.foxnews.com/us/who-cleveland-texas-mass-shooting-victims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:51:11+00:00

The victims of a mass shooting in Cleveland, Texas, allegedly carried out by suspect Francisco Oropesa are being remembered as loving family members.

## Pope Francis greets Russian Orthodox leader amid secret Vatican 'mission' to end war in Ukraine
 - [https://www.foxnews.com/world/pope-francis-meets-russian-orthodox-leader-secret-mission-end-war-ukraine](https://www.foxnews.com/world/pope-francis-meets-russian-orthodox-leader-secret-mission-end-war-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:45:12+00:00

Pope Francis met with Chairman for External Church Relations of the Moscow Patriarchate Anthony of Volokolamsk at the Vatican on Wednesday, speaking to one another at the pontiff&apos;s general audience.

## Pittsburgh synagogue shooter still eligible to face death penalty, according to PA judge
 - [https://www.foxnews.com/us/pittsburgh-synagogue-shooter-still-eligible-face-death-penalty](https://www.foxnews.com/us/pittsburgh-synagogue-shooter-still-eligible-face-death-penalty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:44:26+00:00

A judge ruled against a motion that challenged the government&apos;s pursuit of the death penalty in the case of a man who killed 11 people at a Pittsburgh synagogue.

## Police across Europe crackdown on Italian mob with raids, arrests
 - [https://www.foxnews.com/world/police-europe-crackdown-italian-mob-raids-arrests](https://www.foxnews.com/world/police-europe-crackdown-italian-mob-raids-arrests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:41:24+00:00

Police are cracking down on Italy’s ’ndrangheta organized crime syndicate. Homes have been raided and millions of euros have been seized across Europe.

## New Hampshire man accused of lighting pipe bombs faces more charges
 - [https://www.foxnews.com/us/new-hampshire-accused-lighting-pipe-bombs-faces-more-charges](https://www.foxnews.com/us/new-hampshire-accused-lighting-pipe-bombs-faces-more-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:37:53+00:00

Dale Stewart Jr., a man accused of lighting pipe bombs in New Hampshire, is facing more charges related to the crime in federal court. The bomb injured one person.

## Biden campaign off to 'slow start,' months behind Obama's 2012 pace: Report
 - [https://www.foxnews.com/media/biden-campaign-off-slow-start-months-behind-obamas-2012-pace-report](https://www.foxnews.com/media/biden-campaign-off-slow-start-months-behind-obamas-2012-pace-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:37:31+00:00

A new Axios report claims that President Biden&apos;s re-election campaign is &quot;months behind&quot; the start of former President Barack Obama&apos;s 2012 re-election bid.

## Delaware Democrats pass bill requiring handgun buyers to undergo training, get fingerprinted, obtain permits
 - [https://www.foxnews.com/politics/delaware-democrats-pass-bill-requiring-handgun-buyers-undergo-training-fingerprinted-obtain-permits](https://www.foxnews.com/politics/delaware-democrats-pass-bill-requiring-handgun-buyers-undergo-training-fingerprinted-obtain-permits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:36:47+00:00

The Democrat-controlled Delaware Senate has passed a handgun permit requirement. Buyers would also need to undergo training and get fingerprinted to purchase firearm.

## Jackson Mahomes arrested on aggravated sexual battery charge after restaurant incident
 - [https://www.foxnews.com/sports/jackson-mahomes-arrested-aggravated-sexual-battery-charge-restaurant-incident](https://www.foxnews.com/sports/jackson-mahomes-arrested-aggravated-sexual-battery-charge-restaurant-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:34:55+00:00

Jackson Mahomes, the brother of Kansas City Chiefs star Patrick Mahomes, was arrested on an aggravated sexual battery charge Wednesday stemming from an incident at a Kansas restaurant.

## Dissident Belarusian journalist who was pulled off of commercial flight sentenced to 8 years in prison
 - [https://www.foxnews.com/world/dissident-belarusian-journalist-pulled-off-commercial-flight-sentenced-8-years-prison](https://www.foxnews.com/world/dissident-belarusian-journalist-pulled-off-commercial-flight-sentenced-8-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:33:19+00:00

Raman Pratasevich, a dissident journalist who was arrested after being pulled off a commercial flight, has been sentenced to eight years in prison.

## Former drug dealer who killed a Texas teen moved off death row to serve life sentence
 - [https://www.foxnews.com/us/drug-dealer-killed-texas-teen-moved-death-row-serve-life-sentence](https://www.foxnews.com/us/drug-dealer-killed-texas-teen-moved-death-row-serve-life-sentence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:28:15+00:00

Bruce Webster, a former drug dealer who killed a teenage girl, has been moved off death row to serve a life sentence in a different prison.

## Democrat bill aims to remove stigma of menstruation for women, girls, and ‘people who menstruate’
 - [https://www.foxnews.com/politics/democrat-bill-remove-stigma-menstruation-women-girls-people-menstruate](https://www.foxnews.com/politics/democrat-bill-remove-stigma-menstruation-women-girls-people-menstruate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:27:18+00:00

House Democrats this week proposed a bill aimed at removing the stigma associated with menstruation that can effect women, girls and &quot;people who menstruate.&quot;

## Alabama lawmakers advance measure exempting overtime pay from income taxes
 - [https://www.foxnews.com/politics/alabama-lawmakers-advance-measure-exempting-overtime-pay-income-taxes](https://www.foxnews.com/politics/alabama-lawmakers-advance-measure-exempting-overtime-pay-income-taxes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:24:43+00:00

The Alabama House has unanimously advanced a measure that would allow hourly workers to keep more of their income by exempting their overtime pay from state income tax.

## Senate Democrat blasts Biden's 'militarization' of border
 - [https://www.foxnews.com/politics/senate-democrat-blasts-bidens-militarization-of-border](https://www.foxnews.com/politics/senate-democrat-blasts-bidens-militarization-of-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:17:10+00:00

Democratic Senator Bob Menendez called President Biden&apos;s plan to send 1,500 troops to the U.S.-Mexico border &quot;unacceptable,&quot; arguing the move signals that migrants are a military threat.

## Tlaib's tweet calling Israel 'apartheid state' gets torn apart by instant fact check
 - [https://www.foxnews.com/politics/tlaibs-tweet-calling-israel-apartheid-state-gets-torn-apart-instant-fact-check](https://www.foxnews.com/politics/tlaibs-tweet-calling-israel-apartheid-state-gets-torn-apart-instant-fact-check)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:11:15+00:00

Rep. Rashida Tlaib was the subject of a fact check by Twitter&apos;s revamped &quot;community notes&quot; system, which took issue with the Democrat calling Israel an &quot;apartheid state.&quot;

## New book explores why COVID leak theory was shut down by liberal media: 'Lab accidents aren't rare'
 - [https://www.foxnews.com/media/new-book-explores-covid-leak-theory-shut-down-liberal-media-lab-accidents-arent-rare](https://www.foxnews.com/media/new-book-explores-covid-leak-theory-shut-down-liberal-media-lab-accidents-arent-rare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:08:08+00:00

The media suffered a credibility crisis by prematurely dismissing the COVID lab leak theory and a new book puts a spotlight on why so many people wanted it shut down altogether.

## Trevor Bauer wins in Japanese professional league debut: 'I want to entertain the fans’
 - [https://www.foxnews.com/sports/trevor-bauer-wins-japanese-professional-league-debut-i-want-entertain-fans](https://www.foxnews.com/sports/trevor-bauer-wins-japanese-professional-league-debut-i-want-entertain-fans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:05:18+00:00

Trevor Bauer made his Japanese professional league debut on Wednesday, allowing just one run in seven innings for the Yokohama DeNA Baystars.

## Blinken says ‘I don’t do politics’ despite spending decades in politics, donating lavishly to Dems
 - [https://www.foxnews.com/politics/blinken-says-i-dont-do-politics-despite-spending-decades-politics-donating-lavishly-dems](https://www.foxnews.com/politics/blinken-says-i-dont-do-politics-despite-spending-decades-politics-donating-lavishly-dems)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:02:49+00:00

Secretary of State Antony Blinken told Fox News&apos; &quot;Special Report&quot; Monday night that he doesn’t &quot;do politics&quot; despite spending the past several decades in politics.

## US students know less about American history than ever before, data shows
 - [https://www.foxnews.com/us/us-students-know-less-american-history-data-shows](https://www.foxnews.com/us/us-students-know-less-american-history-data-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:01:59+00:00

American 8th graders are less proficient in history and civics than ever before, according to new data. Students struggle to explain basic historical figures and events.

## China's war on our dollar is really about ruling the world
 - [https://www.foxnews.com/opinion/china-war-dollar-really-about-ruling-world](https://www.foxnews.com/opinion/china-war-dollar-really-about-ruling-world)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 10:00:28+00:00

China has been waging war on the U.S. dollar for years.

## Florida deputy helps deliver baby on shoulder of highway in dramatic video
 - [https://www.foxnews.com/us/florida-deputy-helps-deliver-baby-shoulder-highway-dramatic-video](https://www.foxnews.com/us/florida-deputy-helps-deliver-baby-shoulder-highway-dramatic-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:58:31+00:00

Master Deputy Daniel &quot;Red&quot; Jones, with the Hillsborough County Sheriff&apos;s Office, helped deliver a healthy baby girl on the side of a Florida highway.

## New Mexico man arrested after calling 911 to confess to the 2008 killing of ex-landlord
 - [https://www.foxnews.com/us/new-mexico-man-arrested-calling-911-confesse-2008-killing-ex-landlord](https://www.foxnews.com/us/new-mexico-man-arrested-calling-911-confesse-2008-killing-ex-landlord)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:51:24+00:00

Authorities have arrested a New Mexico man who called 911 to admit that he murdered his landlord in 2008. The suspect also told the police where the body was buried.

## Federal jury convicts all 4 defendants in Chicago bribery trial
 - [https://www.foxnews.com/us/federal-jury-convicts-defendants-chicago-bribery-trial](https://www.foxnews.com/us/federal-jury-convicts-defendants-chicago-bribery-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:49:20+00:00

Four defendants were convicted of bribery conspiracy at a trial in Chicago, Illinois. The defendants bribed associates of Michael Madigan to ensure certain bills became law.

## Texas man who is suing 3 women for helping his ex-wife get abortion pills accused of abuse
 - [https://www.foxnews.com/us/texas-man-suing-3-women-helping-ex-wife-abortion-accused-abuse](https://www.foxnews.com/us/texas-man-suing-3-women-helping-ex-wife-abortion-accused-abuse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:48:50+00:00

Marcus Silva, a man who is suing three women who helped his now ex-wife obtain abortion pills, has been accused of abuse in a new court filing.

## Gwyneth Paltrow says Ben Affleck was ‘excellent’ in bed compared to Brad Pitt
 - [https://www.foxnews.com/entertainment/gwyneth-paltrow-ben-affleck-excellent-bed-compared-brad-pitt](https://www.foxnews.com/entertainment/gwyneth-paltrow-ben-affleck-excellent-bed-compared-brad-pitt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:48:40+00:00

50-year-old Hollywood actress Gwyneth Paltrow confessed which one of her high-profile past romances, between Brad Pitt or Ben Affleck, was better in bed.

## Utah judge delays implementing state’s first-in-the-nation abortion clinic ban
 - [https://www.foxnews.com/politics/utah-judge-delays-implementing-states-first-nation-abortion-clinic-ban](https://www.foxnews.com/politics/utah-judge-delays-implementing-states-first-nation-abortion-clinic-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:47:17+00:00

As a Utah court deliberates over a lawsuit filed by Planned Parenthood, a judge has delayed an abortion clinic ban that sought to restrict clinics from applying for certain licenses

## US cities call for federal help as local immigration shelters become more strained, budgets hit
 - [https://www.foxnews.com/politics/us-cities-call-federal-help-local-immigration-shelters-become-strained-budgets-hit](https://www.foxnews.com/politics/us-cities-call-federal-help-local-immigration-shelters-become-strained-budgets-hit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:37:30+00:00

Democratic cities are asking for federal help as a rule that denies asylum on the grounds of preventing the spread of COVID-19 is set to end in over a week.

## European Union announces plans to ramp up production of ammunition to help Ukraine
 - [https://www.foxnews.com/world/european-union-announces-plans-ramp-production-ammunition-help-ukraine](https://www.foxnews.com/world/european-union-announces-plans-ramp-production-ammunition-help-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:36:09+00:00

Ukraine has been burning through ammunition at a furious rate. The EU announced they are planning to ramp up the production of ammunition to help Ukraine.

## Former NBA player Alexey Shved injured in 'hooligan attack' in Russia: report
 - [https://www.foxnews.com/sports/former-nba-player-alexey-shved-injured-hooligan-attack-russia-report](https://www.foxnews.com/sports/former-nba-player-alexey-shved-injured-hooligan-attack-russia-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:33:12+00:00

Alexey Shved, a former NBA player who played for several teams, was the victim of an alleged &quot;hooligan attack&quot; near a Moscow restaurant.

## Ukraine's President Volodymyr Zelenskyy asks for more firepower for his country during trip to Finland
 - [https://www.foxnews.com/world/ukraines-president-volodymyr-zelenskyy-firepower-country-during-trip-finland](https://www.foxnews.com/world/ukraines-president-volodymyr-zelenskyy-firepower-country-during-trip-finland)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:30:39+00:00

Volodymyr Zelenskyy, the president of Ukraine, visited Helsinki, Finland, today as part of an effort to secure firepower for his country&apos;s war with Russia.

## Florida apartment complex shooting leaves 4 dead, including mother and three children
 - [https://www.foxnews.com/us/florida-apartment-complex-shooting-leaves-4-dead-including-mother-three-children](https://www.foxnews.com/us/florida-apartment-complex-shooting-leaves-4-dead-including-mother-three-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:29:12+00:00

Lake Wales, Florida, police are continuing to search for a suspect in a shooting Tuesday evening at the Sunrise Park apartments complex, where a mother and her three children were killed.

## Homeless encampment wreaking havoc on LA residents with drugs, fires, nudity: 'Just don't feel safe'
 - [https://www.foxnews.com/us/homeless-encampment-wreaking-havoc-la-residents-drugs-fires-nudity-just-dont-feel-safe](https://www.foxnews.com/us/homeless-encampment-wreaking-havoc-la-residents-drugs-fires-nudity-just-dont-feel-safe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:27:47+00:00

Residents and business owners in LA say they do not feel safe living next to a homeless camp where fires, drug use and nude sun bathers are becoming the norm.

## Escaped Mississippi inmate Casey Grayson found dead in New Orleans
 - [https://www.foxnews.com/us/escaped-mississippi-inmate-casey-grayson-found-dead-new-orleans](https://www.foxnews.com/us/escaped-mississippi-inmate-casey-grayson-found-dead-new-orleans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:16:32+00:00

An inmate who escaped from the Raymond Detention Center in Mississippi in April has been found dead at a truck stop in New Orleans.

## 1 Texas climber dead, 1 rescued in national park where rock climbing is banned
 - [https://www.foxnews.com/us/1-texas-climber-dead-1-rescued-national-park-rock-climbing-banned](https://www.foxnews.com/us/1-texas-climber-dead-1-rescued-national-park-rock-climbing-banned)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:10:52+00:00

A climber was found deceased in a Texas national park on Sunday morning. Search teams also rescued a stranded member of the same party. One rescuer was injured.

## Hawley bill would force large corporations to crack down on child labor amid spike in migrant trafficking
 - [https://www.foxnews.com/politics/hawley-bill-would-force-large-corporations-crack-down-child-labor-amid-spike-migrant-trafficking](https://www.foxnews.com/politics/hawley-bill-would-force-large-corporations-crack-down-child-labor-amid-spike-migrant-trafficking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:00:53+00:00

Sen. Josh Hawley is introducing legislation that would make corporations take steps -- including audits and mandatory reporting -- to eradicate the use of child labor.

## California reparations panel hints at $1.2 million payments to each Black resident
 - [https://www.foxnews.com/media/california-reparations-panel-hints-1-2-million-payments-each-black-resident](https://www.foxnews.com/media/california-reparations-panel-hints-1-2-million-payments-each-black-resident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 09:00:29+00:00

Economists provided advice on how to implement a massive reparations program, up to $1.2 million per person, to compensate Black Californians.

## NYC Mayor Eric Adams slams 'irresponsibility' of White House on immigration
 - [https://www.foxnews.com/politics/nyc-mayor-eric-adams-slams-irresponsibility-white-house-immigration](https://www.foxnews.com/politics/nyc-mayor-eric-adams-slams-irresponsibility-white-house-immigration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 08:50:32+00:00

New York City Mayor Eric Adams criticized the &quot;irresponsibility&quot; of the White House regarding immigration and said it needs to do &quot;real immigration reform.&quot;

## Russia claims Putin targeted in drone assassination attempt, as videos circulate online
 - [https://www.foxnews.com/world/russia-claims-putin-targeted-drone-assassination-attempt-videos-circulate-online](https://www.foxnews.com/world/russia-claims-putin-targeted-drone-assassination-attempt-videos-circulate-online)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 08:47:48+00:00

The Russian government claims two drones attempted to assassinate President Vladimir Putin at his residence within the Kremlin before being disabled by defense systems.

## School shooting in Serbia kills at least 9 after young boy takes father’s gun
 - [https://www.foxnews.com/world/school-shooting-serbia-kills-least-9-young-boy-takes-fathers-gun](https://www.foxnews.com/world/school-shooting-serbia-kills-least-9-young-boy-takes-fathers-gun)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 08:44:29+00:00

At least nine people were killed and seven more were injured after a 14-year-old boy fired on his fellow students and two adults at his school in Belgrade, Serbia.

## Baltimore City Council may prohibit ‘willful' and 'incorrect' pronoun use at schools, hospitals: report
 - [https://www.foxnews.com/media/baltimore-city-council-may-prohibit-willful-incorrect-pronoun-use-schools-hospitals-report](https://www.foxnews.com/media/baltimore-city-council-may-prohibit-willful-incorrect-pronoun-use-schools-hospitals-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 08:35:29+00:00

A Baltimore City councilman has reportedly proposed a bill amendment to enforce correct pronoun use for employers and even at schools, health facilities and resorts.

## CA restaurant owner defiant after woke backlash to daily national anthem: 'We won't be stopping'
 - [https://www.foxnews.com/media/ca-restaurant-owner-defiant-woke-backlash-daily-national-anthem-stopping](https://www.foxnews.com/media/ca-restaurant-owner-defiant-woke-backlash-daily-national-anthem-stopping)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 08:24:24+00:00

Rainbow Oaks restaurant owner Jeanene Paulino joined &apos;Fox &amp; Friends First&apos; on Wednesday to respond to woke backlash against her establishment for playing the national anthem.

## Cool, unsettled weather forecast across both coasts
 - [https://www.foxnews.com/us/cool-unsettled-weather-forecast-across-both-coasts](https://www.foxnews.com/us/cool-unsettled-weather-forecast-across-both-coasts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 08:24:09+00:00

While both coasts are forecast to see cool and unsettled weather this week, the southern Plains will see the risk of severe storms, including possible tornadoes.

## Republicans demand answers from regulators on possible Chinese exposure of Americans' financial data
 - [https://www.foxnews.com/politics/republicans-demand-answers-regulators-possible-chinese-exposure-americans-financial-data](https://www.foxnews.com/politics/republicans-demand-answers-regulators-possible-chinese-exposure-americans-financial-data)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 08:00:30+00:00

Sen. Tommy Tuberville, R-Ala., and Rep. Jim Banks, R-Ind., sent a letter to financial regulators demanding answers on possible Chinese exposure of Americans&apos; financial data.

## Al Franken thinks he knows the Supreme Court. Here's what he's missing
 - [https://www.foxnews.com/opinion/al-franken-know-supreme-court-missing](https://www.foxnews.com/opinion/al-franken-know-supreme-court-missing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 08:00:14+00:00

Former Minnesota Senator and &quot;Saturday Night Live&quot; star Al Franken now hosts a podcast. He has been railing lately against Supreme Court Chief Justice John Roberts. But he&apos;s clueless.

## Texas mass shooting: Authorities announce additional arrests after 4-day manhunt ends with fugitive's capture
 - [https://www.foxnews.com/us/texas-mass-shooting-authorities-announce-additional-arrests-4-day-manhunt-ends-fugitives-capture](https://www.foxnews.com/us/texas-mass-shooting-authorities-announce-additional-arrests-4-day-manhunt-ends-fugitives-capture)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:58:32+00:00

The sheriff&apos;s office in San Jacinto County, Texas, announced additional arrests were made in the Cleveland massacre after Francisco Oropesa&apos;s capture.

## Arkansas' Quincey McAdoo hospitalized after being involved in car accident
 - [https://www.foxnews.com/sports/arkansas-quincey-mcadoo-hospitalized-being-involved-car-accident](https://www.foxnews.com/sports/arkansas-quincey-mcadoo-hospitalized-being-involved-car-accident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:46:36+00:00

Arkansas cornerback Quincey McAdoo is in stable condition and recovering after being involved in a car accident early Monday morning, the university said Tuesday.

## Jaguars draft pick Erick Hallett sent team's phone calls to voicemail
 - [https://www.foxnews.com/sports/jaguars-draft-pick-erick-hallett-sent-teams-phone-calls-voicemail](https://www.foxnews.com/sports/jaguars-draft-pick-erick-hallett-sent-teams-phone-calls-voicemail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:42:25+00:00

Former Pittsburgh defensive back Erick Hallett sent phone calls from Jacksonville Jaguars officials to voicemail during the draft.

## This Ford truck is the vehicle most likely to last 250,000 miles
 - [https://www.foxnews.com/auto/ford-truck-lasts-longer-any-vehicle](https://www.foxnews.com/auto/ford-truck-lasts-longer-any-vehicle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:37:27+00:00

The Ford F-350 Super Duty is the vehicle that is most likely to reach 250,000 miles according to a new study of vehicle sales by iSeeCars.com.

## Public safety report details chaos that ensued before deadly stampede at GloRilla's New York concert
 - [https://www.foxnews.com/us/public-safety-report-details-chaos-ensued-deadly-stampede-glorillas-new-york-concert](https://www.foxnews.com/us/public-safety-report-details-chaos-ensued-deadly-stampede-glorillas-new-york-concert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:32:40+00:00

A public safety report detailed the chaos that ensued before the deadly shooting at GloRilla&apos;s Rochester concert that killed three people.

## Brain teaser: Can you find the green apple hidden among the cacti?
 - [https://www.foxnews.com/lifestyle/brain-teaser-can-find-green-apple-hidden-among-cacti](https://www.foxnews.com/lifestyle/brain-teaser-can-find-green-apple-hidden-among-cacti)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:30:12+00:00

Challenge your vision and attention to detail with this cactus seek-and-find brain teaser, which has a green apple hidden among an array of cacti. How fast can you solve the puzzle?

## California creates hotline to provide legal help related to abortion
 - [https://www.foxnews.com/politics/california-creates-hotline-provide-legal-help-related-abortion](https://www.foxnews.com/politics/california-creates-hotline-provide-legal-help-related-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:26:53+00:00

California, along with law firms and advocacy groups, are planning to create a hotline that offers pro bono legal services for those seeking help related to accessing abortion.

## Texas mass shooting suspect nabbed, experts tackle future of AI and more top headlines
 - [https://www.foxnews.com/us/texas-mass-shooting-suspect-nabbed-experts-take-on-ais-future](https://www.foxnews.com/us/texas-mass-shooting-suspect-nabbed-experts-take-on-ais-future)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:13:18+00:00

Texas mass shooting suspect nabbed, experts tackle future of AI and more top headlines

## Titans draft pick Will Levis' sister, Kelley, has four-word message of support for her brother after slide
 - [https://www.foxnews.com/sports/titans-draft-pick-will-levis-sister-kelley-four-word-message-support-her-brother-slide](https://www.foxnews.com/sports/titans-draft-pick-will-levis-sister-kelley-four-word-message-support-her-brother-slide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:12:18+00:00

The sister of Tennessee Titans draft pick Will Levis gave her brother a message of support on Monday. Levis fell to the second round of the draft over the weekend.

## US Navy platformed ‘drag queen influencer’ to attract youth to the military in hiring crisis
 - [https://www.foxnews.com/media/us-navy-platformed-drag-queen-influencer-attract-youth-military-hiring-crisis](https://www.foxnews.com/media/us-navy-platformed-drag-queen-influencer-attract-youth-military-hiring-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:05:45+00:00

A drag queen who goes by the name of &quot;Harpy Daniels&quot; was invited by the U.S. Navy to help reach a &quot;wide range of potential candidates&quot; during a difficult recruitment time.

## NRA taunts Biden over 2020 pledge to ‘defeat’ 2A group, mocks him over ice cream
 - [https://www.foxnews.com/us/nra-taunts-biden-2020-pledge-defeat-2a-group-mocks-ice-cream](https://www.foxnews.com/us/nra-taunts-biden-2020-pledge-defeat-2a-group-mocks-ice-cream)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:00:59+00:00

The NRA released a new video criticizing President Biden&apos;s 2020 vow to &quot;defeat the NRA,&quot; citing how the U.S. became a constitutional carry-majority nation under Biden.

## Will Hurd makes the case for his possible presidential run: ‘No one is taking on Trump effectively’
 - [https://www.foxnews.com/politics/will-hurd-makes-case-possible-presidential-run-no-one-is-taking-on-trump-effectively](https://www.foxnews.com/politics/will-hurd-makes-case-possible-presidential-run-no-one-is-taking-on-trump-effectively)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:00:51+00:00

Former Republican Rep. Will Hurd of Texas, who served as a CIA clandestine officer, is seriously considering a 2024 run for the GOP presidential nomination

## Pornhub blocks all users in Utah as state enacts age verification law
 - [https://www.foxnews.com/media/pornhub-blocks-users-utah-state-enacts-age-verification-law](https://www.foxnews.com/media/pornhub-blocks-users-utah-state-enacts-age-verification-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:00:49+00:00

Pornhub blocked all IP addresses from Utah from accessing its content after the state passed age verification legislation to prevent minors from viewing pornography.

## More than half of American murders go unsolved: FBI data
 - [https://www.foxnews.com/us/more-than-half-american-murders-go-unsolved-fbi-data](https://www.foxnews.com/us/more-than-half-american-murders-go-unsolved-fbi-data)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:00:12+00:00

As U.S. homicides continue to increase since 2020, more than half are going unsolved due to a lack of resources and skepticism toward police in crime-ridden communities.

## Pro-GOP super PAC targets Democrat Manchin for backing Biden’s marquee ‘Inflation Reduction Act’
 - [https://www.foxnews.com/politics/pro-gop-super-pac-targets-democrat-manchin-backing-bidens-marquee-inflation-reduction-act](https://www.foxnews.com/politics/pro-gop-super-pac-targets-democrat-manchin-backing-bidens-marquee-inflation-reduction-act)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 07:00:00+00:00

There’s no letup in the Republican push to oust Democratic Sen. Joe Manchin of West Virginia in 2024, as a pro-GOP super PAC targets Manchin over his support fora a marquee Biden law

## Iran seizes second oil tanker in a week, US Navy says
 - [https://www.foxnews.com/world/iran-seizes-second-oil-tanker-week-us-navy-says](https://www.foxnews.com/world/iran-seizes-second-oil-tanker-week-us-navy-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:53:45+00:00

The Islamic Revolutionary Guard Corps Navy captured another foreign vessel on Wednesday, the second ship unlawfully seized by Iran in less than a week.

## Test scores in civics, history decline for students across the United States following the pandemic
 - [https://www.foxnews.com/us/test-scores-civics-history-decline-students-across-united-states-following-andemic](https://www.foxnews.com/us/test-scores-civics-history-decline-students-across-united-states-following-andemic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:50:44+00:00

The National Assessment of Educational Progress released a report saying that test scores for civics and history declined for eight grade students across the United States.

## Crucial call in Heat-Knicks Game 2 irks NBA fans: 'Terrible'
 - [https://www.foxnews.com/sports/crucial-call-heat-knicks-game-2-irks-nba-fans-terrible](https://www.foxnews.com/sports/crucial-call-heat-knicks-game-2-irks-nba-fans-terrible)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:41:26+00:00

A controversial call late in the game between the Miami Heat and the New York Knicks had fans crying foul. The Knicks would eventually pick up the win.

## Jessica Alba steals the show at Madison Square Garden as Knicks top Heat to tie playoff series
 - [https://www.foxnews.com/sports/jessica-alba-steals-show-madison-square-garden-knicks-top-heat-tie-playoff-series](https://www.foxnews.com/sports/jessica-alba-steals-show-madison-square-garden-knicks-top-heat-tie-playoff-series)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:35:23+00:00

The New York Knicks may have eked out a victory over the Miami Heat but it was Jessica Alba who stole the show Tuesday night at Madison Square Garden.

## Florida man wins women's poker tournament, sparks debate over male inclusion in female sporting events
 - [https://www.foxnews.com/sports/florida-man-wins-womens-poker-tournament-sparks-debate-over-male-inclusion-in-female-sporting-events](https://www.foxnews.com/sports/florida-man-wins-womens-poker-tournament-sparks-debate-over-male-inclusion-in-female-sporting-events)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:32:38+00:00

A 70-year-old Florida man won a women&apos;s Texas Hold&apos;em poker tournament at a casino over the weekend and sparked a debate online over ethical concerns.

## Super Bowl champion JuJu Smith-Schuster on decision to play for Bill Belichick: 'He respects me'
 - [https://www.foxnews.com/sports/super-bowl-champion-juju-smith-schuster-decision-play-bill-belichick-he-respects-me](https://www.foxnews.com/sports/super-bowl-champion-juju-smith-schuster-decision-play-bill-belichick-he-respects-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:22:39+00:00

Wide receiver JuJu Smith-Schuster seems to be fully embracing his new team after he decided to leave the Chiefs in favor of the Patriots earlier this offseason.

## Free agent defensive lineman handed 17-week suspension for PEDs, his third since college
 - [https://www.foxnews.com/sports/free-agent-defensive-lineman-handed-17-week-suspension-peds-his-third-since-college](https://www.foxnews.com/sports/free-agent-defensive-lineman-handed-17-week-suspension-peds-his-third-since-college)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:18:47+00:00

Amani Bledsoe was handed down another suspension due to performance-enhancing drugs - it is his third since college and second as a pro.

## Emilio Estevez says Laurence Fishburne saved him from drowning in quicksand during ‘Apocalypse Now’ shoot
 - [https://www.foxnews.com/entertainment/emilio-estevez-says-laurence-fishburne-saved-him-from-drowning-quicksand-apocalypse-now-shoot](https://www.foxnews.com/entertainment/emilio-estevez-says-laurence-fishburne-saved-him-from-drowning-quicksand-apocalypse-now-shoot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:10:04+00:00

Emilio Estevez recounted the time Laurence Fishburne saved his life when they were both teens while Fishburne was shooting &quot;Apocalypse Now.&quot;

## Irish citizens could soon be jailed for 'possessing material likely to incite violence or hatred'
 - [https://www.foxnews.com/media/irish-citizens-jailed-possessing-material-likely-incite-violence-hatred](https://www.foxnews.com/media/irish-citizens-jailed-possessing-material-likely-incite-violence-hatred)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:00:58+00:00

A bill coursing through Ireland&apos;s government may lead to the political persecution of socially-conservative and religious Irish citizens if it becomes law.

## Florida dentist accused of bludgeoning doctor with club on ritzy golf course
 - [https://www.foxnews.com/us/florida-dentist-accused-bludgeoning-doctor-club-ritzy-golf-course](https://www.foxnews.com/us/florida-dentist-accused-bludgeoning-doctor-club-ritzy-golf-course)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:00:44+00:00

A Florida dentist was charged Sunday for allegedly bludgeoning a doctor with a golf club at swanky Harbor Hills Country Club over an etiquette dispute, authorities said.

## Megan Rapino, Brittney Griner are undermining their legacies with transgender athletes support: Riley Gaines
 - [https://www.foxnews.com/media/megan-rapino-brittney-griner-undermining-legacies-transgender-athletes-support-riley-gaines](https://www.foxnews.com/media/megan-rapino-brittney-griner-undermining-legacies-transgender-athletes-support-riley-gaines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:00:26+00:00

Former NCAA swimmer Riley Gaines has a message for star female athletes who have come out in support of biological males competing in women&apos;s sports.

## Biden's radical climate agenda wants to keep you unplugged
 - [https://www.foxnews.com/opinion/bidens-radical-climate-agenda-keep-unplugged](https://www.foxnews.com/opinion/bidens-radical-climate-agenda-keep-unplugged)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 06:00:13+00:00

The Biden administration wants to radically alter the energy landscape in the United States. The latest move is to shut down electric power plants across the country. That&apos;s a mistake.

## Florida elementary school bans backpacks after student brought Airsoft gun on campus
 - [https://www.foxnews.com/us/florida-elementary-school-bans-backpacks-student-brought-airsoft-gun-campus](https://www.foxnews.com/us/florida-elementary-school-bans-backpacks-student-brought-airsoft-gun-campus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 05:36:31+00:00

A Florida elementary school is banning students from using backpacks for the remainder of the school year after a student brought an Airsoft gun onto school grounds.

## Texas mass murder allegedly by illegal immigrant fodder for Biden impeachment, attorney argues
 - [https://www.foxnews.com/media/texas-mass-murder-allegedly-illegal-immigrant-fodder-biden-impeachment-attorney](https://www.foxnews.com/media/texas-mass-murder-allegedly-illegal-immigrant-fodder-biden-impeachment-attorney)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 05:00:37+00:00

The capture of an illegal immigrant wanted in connection with a pentuple murder in Texas is solid evidence of President Biden&apos;s dangerous border policies, Terrell says.

## Texas college highlights feminist word ‘wimmin’ that avoids women ending in ‘men:' 'Makes conversation easier'
 - [https://www.foxnews.com/media/texas-college-highlights-feminist-word-wimmin-avoids-women-ending-men-makes-conversation-easier](https://www.foxnews.com/media/texas-college-highlights-feminist-word-wimmin-avoids-women-ending-men-makes-conversation-easier)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 05:00:35+00:00

The University of Texas at Austin promotes the word &quot;wimmin&quot; which avoids the word ending &quot;men,&quot; according to their website’s glossary. The title of the page reads &quot;Language Matters: Glossary of Terms.&quot;

## 'Candy cops': Food, beverage industry slam California bill that may change how favorite snacks taste
 - [https://www.foxnews.com/politics/candy-cops-food-beverage-industry-slam-california-bill-may-change-how-favorite-snacks-taste](https://www.foxnews.com/politics/candy-cops-food-beverage-industry-slam-california-bill-may-change-how-favorite-snacks-taste)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 04:55:57+00:00

The food and beverage industry is fighting to kill a bill making its way through the California Legislature that critics argue could negatively impact America&apos;s favorite snacks.

## Former Maryland Gov. Larry Hogan closes door on Senate run: 'Didn't have any interest'
 - [https://www.foxnews.com/politics/former-maryland-gov-larry-hogan-closes-door-senate-run-didnt-have-any-interest](https://www.foxnews.com/politics/former-maryland-gov-larry-hogan-closes-door-senate-run-didnt-have-any-interest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 04:30:39+00:00

Former Maryland Gov. Larry Hogan said he will not be launching a bid for Maryland&apos;s open U.S. Senate seat following the retirement of Democrat Sen. Ben Cardin.

## Why Baltimore’s thousands of vacant buildings are a ‘crisis of epic proportions’
 - [https://www.foxnews.com/us/baltimores-thousands-vacant-buildings-crisis-epic-proportions](https://www.foxnews.com/us/baltimores-thousands-vacant-buildings-crisis-epic-proportions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 04:30:38+00:00

Baltimore has one of the highest rates of vacant properties in America, costing the city upwards of $100 million a year. One city councilor shares her plan to fix it.

## Massachusetts man allegedly plants fake bomb at Harvard, tries to extort money after answering Craigslist ad
 - [https://www.foxnews.com/us/massachusetts-man-allegedly-plants-fake-bomb-harvard-tries-extort-money-after-answering-craigslist-ad](https://www.foxnews.com/us/massachusetts-man-allegedly-plants-fake-bomb-harvard-tries-extort-money-after-answering-craigslist-ad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 04:04:29+00:00

A Massachusetts man is being held in federal custody after allegedly aiding and abetting an extortion attempt, conspiracy, and bomb threats at Harvard University last month.

## Teachers sound alarm on growing problems in schools, say colleagues are 'leaving in droves'
 - [https://www.foxnews.com/media/teachers-sound-alarm-growing-problems-schools-colleagues-leaving-droves](https://www.foxnews.com/media/teachers-sound-alarm-growing-problems-schools-colleagues-leaving-droves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 04:00:46+00:00

As Republicans lean into education as a key issue ahead of the 2024 election, three teachers weighed in on the most pressing issues for them in the classroom.

## I met with Zelenskyy in Ukraine and told him to shift strategy in these 4 ways
 - [https://www.foxnews.com/opinion/met-zelenskyy-ukraine-told-him-shift-strategy-4-ways](https://www.foxnews.com/opinion/met-zelenskyy-ukraine-told-him-shift-strategy-4-ways)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 04:00:28+00:00

Putin’s invasion has demonstrated that Russia’s military training, doctrine and equipment were wildly overestimated. We should be grateful for this new reality and adjust accordingly.

## Infleuntial trans care doctor once warned puberty blockers could cause permanent sexual dysfunction
 - [https://www.foxnews.com/media/infleuntial-trans-care-doctor-once-warned-puberty-blockers-could-cause-permanent-sexual-dysfunction](https://www.foxnews.com/media/infleuntial-trans-care-doctor-once-warned-puberty-blockers-could-cause-permanent-sexual-dysfunction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 04:00:12+00:00

Marci Bowers, a gynecologist specializing in sex change surgeries, has endorsed using puberty blockers on minors after once warning they may cause sexual dysfunction.

## Padma Lakshmi, Sports Illustrated Swimsuit's newest model, reveals how she stays in shape: 'Really difficult'
 - [https://www.foxnews.com/entertainment/padma-lakshmi-sports-illustrated-swimsuits-newest-model-reveals-how-stays-shape](https://www.foxnews.com/entertainment/padma-lakshmi-sports-illustrated-swimsuits-newest-model-reveals-how-stays-shape)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 04:00:00+00:00

Padma Lakshmi, longtime host of Bravo&apos;s &quot;Top Chef,&quot; is kicking off season 2 of HULU&apos;s &quot;Taste the Nation&quot; and celebrating her new spread in the 2023 issue of SI Swimsuit.

## Fading newsrooms, blatant bias and a war with Trump has ravaged the business
 - [https://www.foxnews.com/media/fading-newsrooms-blatant-bias-war-trump-ravaged-business](https://www.foxnews.com/media/fading-newsrooms-blatant-bias-war-trump-ravaged-business)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 03:00:07+00:00

The underwhelming White House Correspondents&apos; Dinner this weekend leaves the door open for questions of the past, present and future of America&apos;s newsrooms.

## Artificial intelligence helping detect early signs of breast cancer in some US hospitals
 - [https://www.foxnews.com/tech/artificial-intelligence-helping-detect-early-signs-breast-cancer-some-us-hospitals](https://www.foxnews.com/tech/artificial-intelligence-helping-detect-early-signs-breast-cancer-some-us-hospitals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:59:30+00:00

The use of artificial intelligence during mammograms has helped identify early signs of breast cancer before a traditional scan might be able to pick up on the abnormalities.

## AI life hacks: How travelers are using ChatGPT to plan trips on a budget
 - [https://www.foxnews.com/lifestyle/ai-life-hacks-travelers-chatgpt-plan-trips-budget](https://www.foxnews.com/lifestyle/ai-life-hacks-travelers-chatgpt-plan-trips-budget)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:11:35+00:00

In a viral TikTok video, travel enthusiast Madison Rolley shared how she used ChatGPT to plan a two-week trip to Europe on a budget. AI expert Dan Schneider and travel expert Katy Nastro weighed in.

## Montgomery County Councilman Will Jawando announces run for Maryland's open US Senate seat
 - [https://www.foxnews.com/politics/montgomery-county-councilman-will-jawando-announces-run-marylands-open-us-senate-seat](https://www.foxnews.com/politics/montgomery-county-councilman-will-jawando-announces-run-marylands-open-us-senate-seat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:07:19+00:00

Montgomery County Council member Will Jawando is running to replace retiring Democrat Ben Cardin in the U.S. Senate. Jawando has served as an at-large council member since 2018.

## 'I refuse to be outsmarted by an inanimate object': Americans reveal true thoughts on AI
 - [https://www.foxnews.com/tech/refuse-outsmarted-inanimate-object-americans-reveal-true-thoughts-ai](https://www.foxnews.com/tech/refuse-outsmarted-inanimate-object-americans-reveal-true-thoughts-ai)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:00:59+00:00

Americans in Los Angeles and Austin reveal if they&apos;re familiar with artificial intelligence and how how they view the technology&apos;s impact on society.

## South Carolina priest says there's 'no place' for AI after Asia Catholic Church uses it for synodal document
 - [https://www.foxnews.com/lifestyle/south-carolina-priest-no-place-ai-asia-catholic-church-synodal-document](https://www.foxnews.com/lifestyle/south-carolina-priest-no-place-ai-asia-catholic-church-synodal-document)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:00:58+00:00

The Asia Catholic Church just used AI to help create a synodal document. Fr. Jeffrey Kirby of South Carolina offers objections, saying that there is no place for Ai pertaining to this usage.

## Texas shooting suspect: Gov. Abbott, lawmakers respond after four-day manhunt ends with arrest
 - [https://www.foxnews.com/politics/texas-shooting-suspect-gov-abbott-lawmakers-respond-after-four-day-manhunt-ends-arrest](https://www.foxnews.com/politics/texas-shooting-suspect-gov-abbott-lawmakers-respond-after-four-day-manhunt-ends-arrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:00:57+00:00

Texas Gov. Greg Abbott, Sen. Ted Cruz and others from the state praised a massive law enforcement effort to find 38-year-old Mexican national Francisco Oropesa.

## Queen Camilla 'furious' with Prince Harry's 'Spare,' won't forgive 'bomb-like' expose: insider
 - [https://www.foxnews.com/entertainment/queen-camilla-furious-prince-harrys-spare-wont-forgive-bomb-like-expose-insider](https://www.foxnews.com/entertainment/queen-camilla-furious-prince-harrys-spare-wont-forgive-bomb-like-expose-insider)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:00:43+00:00

In his memoir, Prince Harry singled out Camilla, accusing her of leaking private conversations to the media as she sought to rehabilitate her image after marrying King Charles.

## I helped build Sophia the Robot. We should not be scared of AI for these 5 reasons
 - [https://www.foxnews.com/opinion/helped-build-sophia-robot-should-not-scared-ai-5-reasons](https://www.foxnews.com/opinion/helped-build-sophia-robot-should-not-scared-ai-5-reasons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:00:39+00:00

If we&apos;re really at the dawn of superhuman intelligence, we should not be scared.

## Russian warlord expands activity in Africa on Moscow's behalf, creating foothold in vital region
 - [https://www.foxnews.com/world/russian-warlord-expands-activity-africa-moscows-behalf-creating-foothold-vital-region](https://www.foxnews.com/world/russian-warlord-expands-activity-africa-moscows-behalf-creating-foothold-vital-region)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:00:29+00:00

The Wagner Group has appeared to involve itself in a number of armed conflicts across the continent and gained access to mining operations valued at around $1 billion.

## AI requires ‘new generation’ of arms control deal to govern future warfighting, says Marine veteran lawmaker
 - [https://www.foxnews.com/politics/ai-requires-new-generation-arms-control-deal-govern-future-warfighting-marine-veteran-lawmaker](https://www.foxnews.com/politics/ai-requires-new-generation-arms-control-deal-govern-future-warfighting-marine-veteran-lawmaker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:00:20+00:00

Rep. Seth Moulton says the U.S. should have already started work on an international framework governing the military use of artificial intelligence on the battlefield.

## AI-driven video company Snipitz to deliver innovative viewing experience for fans during sports broadcasts
 - [https://www.foxnews.com/sports/ai-driven-video-company-snipitz-deliver-innovative-viewing-experience-fans-during-sports-broadcasts](https://www.foxnews.com/sports/ai-driven-video-company-snipitz-deliver-innovative-viewing-experience-fans-during-sports-broadcasts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:00:11+00:00

When someone watches a sports event, someone else ultimately decides how the viewer watches what they choose to spend time with. Snipitz aims to shift that power structure.

## Older generations trail the nation on AI know-how: Poll
 - [https://www.foxnews.com/us/older-generations-trail-nation-ai-know-how-poll](https://www.foxnews.com/us/older-generations-trail-nation-ai-know-how-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 02:00:09+00:00

U.S. voters over the age of 45 trail younger generations on familiarity with artificial intelligence technology like ChatGPT, a Fox News poll found.

## Kraken take Game 1 in overtime, thwart Stars' heroic comeback efforts
 - [https://www.foxnews.com/sports/kraken-take-game-1-in-overtime-thwart-stars-heroic-comeback-efforts](https://www.foxnews.com/sports/kraken-take-game-1-in-overtime-thwart-stars-heroic-comeback-efforts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 01:16:32+00:00

The Seattle Kraken thwarted a valiant comeback attempt led by Dallas Stars center Joe Pavelski on Monday night to win Game 1 in overtime.

## Anthony Davis enters Lakers history with incredible Game 1 performance in win over Warriors
 - [https://www.foxnews.com/sports/anthony-davis-enters-lakers-history-incredible-game-1-performance-win-warriors](https://www.foxnews.com/sports/anthony-davis-enters-lakers-history-incredible-game-1-performance-win-warriors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 01:01:24+00:00

Anthony Davis had an epic performance and led the Los Angeles Lakers to a Game 1 victory over the Golden State Warriors on Tuesday night.

## Texas shooting suspect's location came through FBI tip line: 'Courage to call'
 - [https://www.foxnews.com/us/texas-shooting-suspects-location-came-through-fbi-tip-line-courage-call](https://www.foxnews.com/us/texas-shooting-suspects-location-came-through-fbi-tip-line-courage-call)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 00:47:38+00:00

A four-day manhunt to locate Francisco Oropesa, a 38-year-old mass shooting suspect, who allegedly killed five of his neighbors last month, ended after a tip provided his location.

## On this day in history, May 3, 1937, Margaret Mitchell's Civil War saga 'Gone with the Wind' wins Pulitzer
 - [https://www.foxnews.com/lifestyle/this-day-history-may-3-1937-margaret-mitchell-civil-war-saga-gone-wind-wins-pulitzer](https://www.foxnews.com/lifestyle/this-day-history-may-3-1937-margaret-mitchell-civil-war-saga-gone-wind-wins-pulitzer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-05-03 00:02:57+00:00

Margaret Mitchell earned a Pulitzer Prize in Novels for her Civil War epic &quot;Gone with the Wind&quot; on this day in history, May 3, 1937. She died tragically at age 48.

