# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Met Gala: Lizzo bows down to 'idol' Sir James Galway in flute duet
 - [https://www.bbc.co.uk/news/uk-northern-ireland-65475929?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-65475929?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 23:04:07+00:00

The US star paid tribute to her "idol" Sir James Galway after he performed with her at the Met Gala.

## Local elections 2023: Polls to open across England
 - [https://www.bbc.co.uk/news/uk-politics-65475411?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65475411?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 23:00:38+00:00

Voters will head to the polls later on Thursday for the biggest round of elections since 2019.

## New mums missing out on mental health services, report finds
 - [https://www.bbc.co.uk/news/health-65473737?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-65473737?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 21:40:48+00:00

A report says the NHS is failing to meet targets around services for pregnant women and new mums.

## Manchester City 3-0 West Ham: Erling Haaland breaks Premier League goals record
 - [https://www.bbc.co.uk/sport/football/64929885?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64929885?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 21:19:50+00:00

Erling Haaland scores a record-breaking 35th Premier League goal of the season as Manchester City beat West Ham to return to the top of the table.

## Sudan: Dozens on last UK evacuation flights to leave the country
 - [https://www.bbc.co.uk/news/uk-65476769?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65476769?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 21:15:26+00:00

An operation, which has seen more than 2,300 people rescued, enters its final stages.

## Liverpool 1-0 Fulham: Mohamed Salah scores for eighth straight Anfield game
 - [https://www.bbc.co.uk/sport/football/64923724?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64923724?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 21:14:56+00:00

Liverpool's outside hopes of qualifying for next season's Champions League remain alive after Mohamed Salah continues his remarkable Anfield scoring form to help sink Fulham.

## Haaland breaks Premier League goal record
 - [https://www.bbc.co.uk/sport/football/65474843?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65474843?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 21:14:45+00:00

Manchester City striker Erling Haaland scores against West Ham to break the record for goals in a Premier League season.

## Sir Richard Branson thought 'we were going to lose everything' in pandemic
 - [https://www.bbc.co.uk/news/uk-65458395?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65458395?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 20:59:48+00:00

Sir Richard Branson says the pandemic left his businesses near collapse and him "a little depressed".

## Chelsea 2-1 Liverpool: Women's Super League title hopes boosted by Sam Kerr winner
 - [https://www.bbc.co.uk/sport/football/65475104?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65475104?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 20:22:20+00:00

Chelsea's Women's Super League title hopes remain in their own hands after Sam Kerr's late goal gives them victory over Liverpool.

## Ryder Cup: Sergio Garcia, Ian Poulter & Lee Westwood ineligible for 2023 event after quitting DP World Tour
 - [https://www.bbc.co.uk/sport/golf/65476846?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/65476846?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 19:43:03+00:00

Sergio Garcia, Ian Poulter and Lee Westwood will be ineligible to play in this year's Ryder Cup after resigning from the DP World Tour.

## Bona Mugabe owns Dubai mansion, Zimbabwe court papers allege
 - [https://www.bbc.co.uk/news/world-africa-65475901?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65475901?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 19:12:37+00:00

Court papers list assets including an $80m Dubai mansion, luxury vehicles and 21 farms.

## Fed raises US interest rates to highest in 16 years
 - [https://www.bbc.co.uk/news/business-65474456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65474456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 19:01:14+00:00

The US central bank announces its tenth rate rise, while signalling it may be the last increase for now.

## IPL 2023: Liam Livingstone's 82 in vain as Mumbai Indians chase 215 to beat Punjab Kings
 - [https://www.bbc.co.uk/sport/cricket/65469446?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65469446?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 18:03:48+00:00

Liam Livingstone's 82 not out is in vain as Mumbai Indians chase 215 to beat Punjab Kings by six wickets in the Indian Premier League.

## Man dies after being put in chokehold on New York subway
 - [https://www.bbc.co.uk/news/world-us-canada-65472810?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65472810?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 17:09:44+00:00

Police are investigating the incident, which was captured on video by a bystander.

## What do we know about drone attacks in Russia?
 - [https://www.bbc.co.uk/news/world-europe-65475333?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65475333?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 17:06:07+00:00

Russia accuses Ukraine of trying to kill President Putin in a drone attack, which Ukraine denies.

## In pictures: King joins preparations for Coronation
 - [https://www.bbc.co.uk/news/in-pictures-65474812?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-65474812?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 16:56:51+00:00

Pictures of the Royal Family preparing for the Coronation, and the fans and workers making it happen.

## Sam Allardyce: Leeds boss says he is 'up there' with Jurgen Klopp & Pep Guardiola
 - [https://www.bbc.co.uk/sport/football/65473908?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65473908?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 16:41:05+00:00

New Leeds United manager Sam Allardyce says he is "up there" with any manager in the Premier League including Manchester City boss Pep Guardiola and Liverpool's Jurgen Klopp.

## Jude Bellingham: Real Madrid in advanced talks to sign England midfielder
 - [https://www.bbc.co.uk/sport/football/65473901?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65473901?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 16:20:13+00:00

Real Madrid are in advanced talks with Borussia Dortmund to sign England midfielder Jude Bellingham for more than 100m euros.

## Emma Raducanu out of French Open and Wimbledon after hand and ankle surgery
 - [https://www.bbc.co.uk/sport/tennis/65469123?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65469123?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 16:12:17+00:00

British number one Emma Raducanu will be out of action for the "next few months" while she recovers from hand and ankle surgery.

## Do Labour or Conservatives have higher council tax?
 - [https://www.bbc.co.uk/news/65471344?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/65471344?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 15:55:46+00:00

Both parties claim to have cheaper council tax but it's very hard to tell.

## Sam Allardyce: Leeds manager says 'there's nobody ahead of me' in terms of footballing knowledge
 - [https://www.bbc.co.uk/sport/av/football/65475052?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/65475052?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 15:32:53+00:00

New Leeds United boss Sam Allardyce says there is nobody ahead of him "in football terms" as a manager - not even Pep Guardiola.

## Andy Murray beats Gael Monfils in ATP Challenger event in France
 - [https://www.bbc.co.uk/sport/tennis/65474722?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65474722?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 15:26:18+00:00

Andy Murray's preparations for the French Open continue with a clay-court win over France's Gael Monfils at an ATP Challenger event in Aix-en-Provence.

## Ukraine war: How old tech is helping Ukraine avoid detection
 - [https://www.bbc.co.uk/news/world-europe-65458263?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65458263?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 15:02:17+00:00

Ukrainian troops preparing for a major offensive use a wind-up phone to stop the enemy listening in.

## Lionel Messi: Argentina forward to leave Paris St-Germain this summer
 - [https://www.bbc.co.uk/sport/football/65465532?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65465532?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 14:54:13+00:00

Lionel Messi will be looking for a new club this summer after both him and PSG decide not to extend his stay in Paris.

## Jair Bolsonaro: Police search home of ex-president
 - [https://www.bbc.co.uk/news/world-latin-america-65468779?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-65468779?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 14:51:09+00:00

Police search Jair Bolsonaro's home as part of an investigation into false data in a vaccination database.

## Russian driver Mazepin begins High Court bid to lift UK sanctions
 - [https://www.bbc.co.uk/sport/formula1/65472770?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/65472770?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 14:28:46+00:00

Russian racing driver Nikita Mazepin begins High Court action against the UK government to try and get sanctions against him lifted.

## ECB recommends fines and bans for ex-Yorkshire players found to have used racist language
 - [https://www.bbc.co.uk/sport/cricket/65472292?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65472292?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 14:24:26+00:00

The England and Wales Cricket Board recommend fines and bans for former Yorkshire players found to have used racist language.

## Tori Bowie: American three-time Olympic medallist and ex-world champion dies aged 32
 - [https://www.bbc.co.uk/sport/athletics/65471163?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/65471163?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 14:11:55+00:00

American sprinter Tori Bowie, a three-time Olympic medallist and former 100m world champion, has died aged 32.

## Grays pub that displayed golly dolls closes after supplier boycott
 - [https://www.bbc.co.uk/news/uk-england-essex-65471314?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-65471314?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 13:37:11+00:00

The leaseholder says she has "had enough" after intervention from Heineken, Carlsberg and Innserve.

## New Alzheimer's drug slows disease by a third
 - [https://www.bbc.co.uk/news/health-65471914?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-65471914?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 13:36:08+00:00

The second such drug in a year raises hopes we can start treating dementia.

## Row over Met Gala's tribute to Karl Lagerfeld tribute
 - [https://www.bbc.co.uk/news/entertainment-arts-65469466?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65469466?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 13:07:07+00:00

Actress Jameela Jamil is among those criticising the event for honouring the controversial designer.

## Kremlin accuses Ukraine of trying to assassinate Putin
 - [https://www.bbc.co.uk/news/world-europe-65471904?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65471904?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 12:57:48+00:00

Ukraine denies having anything to do with an apparent drone attack on the Kremlin in Moscow.

## Chris Packham libel trial: Presenter faced 'relentless intimidation'
 - [https://www.bbc.co.uk/news/uk-england-hampshire-65470329?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hampshire-65470329?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 12:53:33+00:00

The presenter is suing over articles alleging he misled people about a tiger rescue charity.

## Stephen Tompkinson trial: Actor 'caused traumatic brain injuries'
 - [https://www.bbc.co.uk/news/uk-england-tyne-65466493?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-65466493?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 12:43:10+00:00

The 57-year-old DCI Banks actor denies inflicting grievous bodily harm on Karl Poole in May 2021.

## Kate Bush and George Michael inducted to Rock & Roll Hall of Fame
 - [https://www.bbc.co.uk/news/entertainment-arts-65467456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65467456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 12:13:44+00:00

The stars will be inducted to the Rock and Roll Hall of Fame, as will Chaka Khan and Missy Elliott.

## How to watch the Coronation of King Charles III and TV schedule
 - [https://www.bbc.co.uk/news/uk-65461957?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65461957?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 12:10:58+00:00

Here's how to follow the UK's first coronation in 70 years.

## Cristiano Ronaldo becomes world's highest paid athlete after Al Nassr move - Forbes
 - [https://www.bbc.co.uk/sport/65471162?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/65471162?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 12:04:51+00:00

Cristiano Ronaldo has become the world's highest paid athlete for the first time since 2017 following his move to Saudi Arabian side Al Nassr.

## Local elections 2023: Leaders to make final pitch to voters
 - [https://www.bbc.co.uk/news/uk-politics-65467742?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65467742?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 12:01:56+00:00

Leaders will visit battleground areas on the last day of campaigning before Thursday's polls.

## MasterChef Australia to premiere after host Jock Zonfrillo's death
 - [https://www.bbc.co.uk/news/world-australia-65469456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-65469456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 12:01:51+00:00

The award-winning chef's final season on the franchise will air with his family's blessing.

## Hall and Hull withdrawals lacked 'decency'
 - [https://www.bbc.co.uk/sport/golf/65469033?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/65469033?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 11:40:41+00:00

Bronte Law says Georgia Hall and Charley Hull lacked "decency" in the way they withdrew from the International Crown tournament.

## Love Island star Samie Elishi gets cancer check after fans spot lump
 - [https://www.bbc.co.uk/news/newsbeat-65469193?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-65469193?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 11:36:45+00:00

Samie Elishi says she wouldn't have got the lump checked out if fans hadn't got in touch with her.

## British Cycling considering banning transgender women from elite female competition
 - [https://www.bbc.co.uk/sport/cycling/65467163?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/65467163?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 11:35:55+00:00

British Cycling considering banning transgender women from elite female competition.

## Dame Deborah James' on-air goodbye named radio moment of the year at Aria Awards
 - [https://www.bbc.co.uk/news/entertainment-arts-65466673?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65466673?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 11:27:15+00:00

The podcaster and fundraiser's final on-air chat on BBC Radio 5 Live wins a prestigious Aria Award.

## Belarusian dissident Roman Protasevich sentenced to eight years
 - [https://www.bbc.co.uk/news/world-65466698?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-65466698?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 10:57:52+00:00

Roman Protasevich was arrested after his Ryanair flight was diverted to Belarus in May 2021.

## Sue Gray: Inside track on an almighty row
 - [https://www.bbc.co.uk/news/uk-politics-65470101?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65470101?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 10:51:21+00:00

Has the Partygate probe chief who wants to work for Labour acted properly? And why are some people so angry?

## King Charles's coronation dress rehearsal lights up London night
 - [https://www.bbc.co.uk/news/in-pictures-65467802?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-65467802?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 10:27:34+00:00

Pictures of the Coronation dress rehearsal in central London.

## Met officers arrested in rape and kidnap inquiry
 - [https://www.bbc.co.uk/news/articles/cyd8m51zpj1o?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/cyd8m51zpj1o?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 10:23:53+00:00

Two Met officers have been suspended following an allegation of rape and kidnap while off-duty.

## Man arrested for shining laser at Chelsea's Mudryk
 - [https://www.bbc.co.uk/sport/football/65469443?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65469443?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 10:23:14+00:00

Arsenal condemn the "dangerous and totally unacceptable behaviour" of a 21-year-old man arrested for shining a laser in the face of Chelsea winger Mykhailo Mudryk.

## Brolly or sun cream? Your weekend weather forecast
 - [https://www.bbc.co.uk/news/uk-65468056?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65468056?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 10:00:42+00:00

A look at whether you can expect rain or sunshine between Saturday 6 May and Monday 8 May.

## Leeds United: Javi Gracia sacked and replaced by Sam Allardyce at struggling Premier League club
 - [https://www.bbc.co.uk/sport/football/65444406?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65444406?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 09:55:55+00:00

Leeds United sack manager Javi Gracia and appoint Sam Allardyce with the relegation-threatened club 17th in the Premier League.

## SNP appoints new auditors as deadline looms
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65467591?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65467591?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 09:54:48+00:00

The party risks losing £1.2m of public funds if it does not file its accounts by the end of the month.

## Coronation protests allowed, security minister insists
 - [https://www.bbc.co.uk/news/uk-65466825?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65466825?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 09:43:51+00:00

Campaign groups have received letters reminding them about penalties under new protest laws.

## At least nine dead in Serbia school shooting
 - [https://www.bbc.co.uk/news/world-europe-65468404?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65468404?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 09:41:14+00:00

A schoolboy has been arrested after shots were fired at an elementary school in Serbia's capital.

## Teacher strikes: More schools than ever unable to fully open in England
 - [https://www.bbc.co.uk/news/education-65457164?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-65457164?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 09:38:34+00:00

Members of the National Education Union walked out for the fifth time in England on Tuesday.

## Sam Allardyce named Leeds manager: 'A club in meltdown turns to the old street fighter'
 - [https://www.bbc.co.uk/sport/football/65460670?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65460670?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 09:30:43+00:00

Sam Allardyce's appointment caps a dysfunctional period at Elland Road and a complete shift in style for Leeds United, writes Phil McNulty.

## ADHD on TikTok: Raising awareness or driving inaccurate self-diagnosis?
 - [https://www.bbc.co.uk/news/newsbeat-65457044?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-65457044?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 08:21:14+00:00

Content about the condition generates billions of views, but is it driving too many to self-diagnose?

## UK to ban all cold calls selling financial products
 - [https://www.bbc.co.uk/news/business-65466653?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65466653?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 07:52:04+00:00

It comes as part of a wider crackdown on scams that affect millions of people each year.

## Light suffered stroke after Okolie defeat
 - [https://www.bbc.co.uk/sport/boxing/65466739?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/65466739?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 06:55:29+00:00

New Zealand boxer David Light suffers mild stroke and requires operation to remove a blood clot after his defeat by Lawrence Okolie in March.

## 'The Gorilla' enters the lion's den - Ryder ready for 'Canelo' fight
 - [https://www.bbc.co.uk/sport/boxing/65452138?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/65452138?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 06:01:32+00:00

John 'The Gorilla' Ryder heads to the lion's den to face Saul 'Canelo' Alvarez in Guadalajara, Mexico, aiming to pull off one of the biggest shocks in boxing history.

## Daniel Entwistle: The boy who vanished after going out on his bike
 - [https://www.bbc.co.uk/news/uk-england-norfolk-65459567?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-norfolk-65459567?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 05:09:33+00:00

Despite new leads in the case, police cannot yet say what happened to Daniel Entwistle.

## Ashes 2023: Pick your England team for first Australia Test at Edgbaston
 - [https://www.bbc.co.uk/sport/cricket/65460563?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65460563?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 05:05:13+00:00

With the men's Ashes almost here, put yourself in Ben Stokes and Brendon McCullum's shoes and pick your England team for the first Test at Edgbaston.

## John Ryder v Saul 'Canelo' Alvarez: Matthew Hatton offers survival tips for fighting Mexican
 - [https://www.bbc.co.uk/sport/av/boxing/65461905?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/boxing/65461905?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 05:02:48+00:00

Matthew Hatton reflects on being the first British fighter to face Saul 'Canelo' Alvarez in 2011, and offers tips to John Ryder for his fight with the undisputed super middleweight champion.

## Ukraine war: Russia scales back Victory Day celebrations
 - [https://www.bbc.co.uk/news/world-europe-65465978?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65465978?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 04:48:06+00:00

The traditional Immortal Regiment procession will be moved online amid security concerns.

## Nord Stream: Report puts Russian navy ships near pipeline blast site
 - [https://www.bbc.co.uk/news/world-europe-65461401?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65461401?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 04:00:03+00:00

A documentary reports Russian naval ships were located near the site of the Nord Stream explosions.

## Chris Mason: What's at stake in this week's local elections?
 - [https://www.bbc.co.uk/news/uk-politics-65455770?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65455770?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 02:20:10+00:00

This week's results matter, as new councillors are elected and voters deliver their verdict on the parties.

## Coronation of King Charles III: Golden carriage on display in night-time rehearsal
 - [https://www.bbc.co.uk/news/uk-65465760?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65465760?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 02:05:28+00:00

Pomp and ceremony were on display during night-time parade rehearsals in London.

## Missing Australian fisherman's body found in crocodile
 - [https://www.bbc.co.uk/news/world-australia-65446354?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-65446354?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 01:31:16+00:00

Kevin Darmody vanished while fishing with friends in far north Queensland on Saturday.

## Why TV writers are on strike - explained in 80 seconds
 - [https://www.bbc.co.uk/news/world-us-canada-65465491?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65465491?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 01:25:06+00:00

The BBC's Sophie Long looks at why Hollywood television production has nearly ground to a halt.

## Suspect in Texas neighbour shooting arrested - reports
 - [https://www.bbc.co.uk/news/world-us-canada-65464937?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65464937?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 00:59:20+00:00

Francisco Oropesa, 38, is reportedly arrested in the town of Cut and Shoot, Texas, after a manhunt.

## The Papers: 'Lockdown at Palace' and 'AI claims first scalp'
 - [https://www.bbc.co.uk/news/blogs-the-papers-65465043?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-65465043?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 00:37:23+00:00

The arrest of a man outside Buckingham Palace and tumult in the education sector lead the papers.

## Medicinal cannabis helps cancer pain - study
 - [https://www.bbc.co.uk/news/health-65461319?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-65461319?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-05-03 00:01:31+00:00

More rigorous trials are needed to confirm the findings, the Canadian researchers say.

