# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Nadciągają tańsze Radeony. Seria RX 7000 doczeka się nowych modeli
 - [https://ithardware.pl/aktualnosci/nadciagaja_tansze_radeony_seria_rx_7000_doczeka_sie_nowych_modeli-27085.html](https://ithardware.pl/aktualnosci/nadciagaja_tansze_radeony_seria_rx_7000_doczeka_sie_nowych_modeli-27085.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-03 09:35:20+00:00

<img src="https://ithardware.pl/artykuly/min/27085_1.jpg" />            Nie samym high-endem gracze żyją. AMD zamierza wprowadzić na rynek nowe, bardziej przystępne cenowo karty graficzne z serii Radeon RX 7000 dla komputer&oacute;w stacjonarnych. Średniop&oacute;łkowych modeli możemy spodziewać się już niebawem, o...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nadciagaja_tansze_radeony_seria_rx_7000_doczeka_sie_nowych_modeli-27085.html">https://ithardware.pl/aktualnosci/nadciagaja_tansze_radeony_seria_rx_7000_doczeka_sie_nowych_modeli-27085.html</a></p>

## Najgorzej zoptymalizowane gry na premierę, na PC i konsolach - Top 10
 - [https://ithardware.pl/artykuly/najgorzej_zoptymalizowane_gry_na_premiere_na_pc_i_konsolach_top_10-27066.html](https://ithardware.pl/artykuly/najgorzej_zoptymalizowane_gry_na_premiere_na_pc_i_konsolach_top_10-27066.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-03 08:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/27066_1.jpg" />            Robienie zestawień negatywnych jest z zasady problematyczne. Biorąc pod uwagę to ile pracy, czasu i zaangażowania jest wewnątrz branży gier, trudno po prostu usiąść i wytykać komuś błędy. Istnieje jednak druga strona medalu, kt&oacute;ra...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/najgorzej_zoptymalizowane_gry_na_premiere_na_pc_i_konsolach_top_10-27066.html">https://ithardware.pl/artykuly/najgorzej_zoptymalizowane_gry_na_premiere_na_pc_i_konsolach_top_10-27066.html</a></p>

## AMD odniosło się do opóźnienia serii Ryzen 7040HS. Kiedy zobaczymy pierwsze laptopy?
 - [https://ithardware.pl/aktualnosci/amd_odnioslo_sie_do_opoznienia_serii_ryzen_7040hs_kiedy_zobaczymy_pierwsze_laptopy-27084.html](https://ithardware.pl/aktualnosci/amd_odnioslo_sie_do_opoznienia_serii_ryzen_7040hs_kiedy_zobaczymy_pierwsze_laptopy-27084.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-05-03 08:03:10+00:00

<img src="https://ithardware.pl/artykuly/min/27084_1.jpg" />            AMD znacząco op&oacute;źnia rynkowy debiut procesor&oacute;w z serii Ryzen 7040HS (Phoenix). Pierwsze komputery wyposażone w układy z tej rodziny miały pojawić się w marcu. Następnie premierę przesunięto na kwiecień. Teraz, w maju, AMD...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_odnioslo_sie_do_opoznienia_serii_ryzen_7040hs_kiedy_zobaczymy_pierwsze_laptopy-27084.html">https://ithardware.pl/aktualnosci/amd_odnioslo_sie_do_opoznienia_serii_ryzen_7040hs_kiedy_zobaczymy_pierwsze_laptopy-27084.html</a></p>

