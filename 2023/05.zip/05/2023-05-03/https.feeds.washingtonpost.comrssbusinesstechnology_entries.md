# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## FTC plans to bar Meta from monetizing teens’ data after privacy lapses
 - [https://www.washingtonpost.com/technology/2023/05/03/ftc-meta-children-data-privacy/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/05/03/ftc-meta-children-data-privacy/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-05-03 13:03:04+00:00

The agency wants to update a 2020 settlement with the Facebook parent company after allegations that the company misled parents about its Messenger Kids app.

## Big Tech-funded groups try to kill bills to protect children online
 - [https://www.washingtonpost.com/technology/2023/05/03/big-tech-lobby-children-safety/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/05/03/big-tech-lobby-children-safety/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-05-03 07:00:47+00:00

Tech groups funded by Amazon, Google and Meta are pushing to kill state bills to protect children online.

## The completely correct guide to organizing your phone screen
 - [https://www.washingtonpost.com/technology/2023/05/03/organize-phone-home-screen/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/05/03/organize-phone-home-screen/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-05-03 07:00:28+00:00

The completely correct guide to organizing your phone screen

## Amazon is paying small-town florists and funeral homes to deliver packages
 - [https://www.washingtonpost.com/technology/2023/05/03/amazon-delivery-small-business-rural/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/05/03/amazon-delivery-small-business-rural/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-05-03 06:00:34+00:00

In a new program, Amazon is paying small businesses in hard-to-reach places $2.50 per package delivered.

## See how a quick-fix climate solution could also trigger war
 - [https://www.washingtonpost.com/climate-environment/2023/05/03/comic-geosolar-engineering-explained/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/climate-environment/2023/05/03/comic-geosolar-engineering-explained/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-05-03 06:00:14+00:00

A technology called geosolar engineering is a cheap and fast way to fight global warming. But it could also spark conflict.

