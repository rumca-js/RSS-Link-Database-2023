# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Mexico’s Lopez Obrador denounces USAID funds as ‘interventionist’
 - [https://www.aljazeera.com/news/2023/5/3/mexicos-lopez-obrador-denounces-usaid-funds-as-interventionist](https://www.aljazeera.com/news/2023/5/3/mexicos-lopez-obrador-denounces-usaid-funds-as-interventionist)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 22:59:17+00:00

The president issued a letter to his US counterpart Joe Biden, calling to halt funds to groups &#039;against&#039; his government.

## US halts food aid to Ethiopia’s Tigray, citing illicit sales
 - [https://www.aljazeera.com/news/2023/5/3/us-halts-food-aid-to-ethiopias-tigray-citing-illicit-sales](https://www.aljazeera.com/news/2023/5/3/us-halts-food-aid-to-ethiopias-tigray-citing-illicit-sales)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 21:55:39+00:00

USAID head says shipments will resume to war-torn region in Ethiopia only after &#039;oversight measures are in place&#039;.

## What are the chances for peace in Sudan?
 - [https://www.aljazeera.com/program/inside-story/2023/5/3/what-are-the-chances-for-peace-in](https://www.aljazeera.com/program/inside-story/2023/5/3/what-are-the-chances-for-peace-in)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 20:32:34+00:00

Warring generals invited to peace talks as they observe a week-long ceasefire

## Pakistan beat New Zealand in third ODI cricket match
 - [https://www.aljazeera.com/sports/2023/5/3/pakistan-beat-new-zealand-in-third-odi-cricket-match](https://www.aljazeera.com/sports/2023/5/3/pakistan-beat-new-zealand-in-third-odi-cricket-match)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 20:15:11+00:00

Pakistan wrap up five-match series after defeating New Zealand by 26 runs in the third one-day international in Karachi.

## Press Freedom Day: US slammed over response to Abu Akleh killing
 - [https://www.aljazeera.com/news/2023/5/3/press-freedom-day-us-slammed-over-response-to-abu-akleh-killing](https://www.aljazeera.com/news/2023/5/3/press-freedom-day-us-slammed-over-response-to-abu-akleh-killing)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 19:28:45+00:00

State Department official reiterates US is pressing Israel to &#039;review its policies&#039; after Al Jazeera reporter&#039;s killing.

## Rights commission says Peru crackdown may qualify as a ‘massacre’
 - [https://www.aljazeera.com/news/2023/5/3/rights-commission-says-peru-crackdown-may-qualify-as-a](https://www.aljazeera.com/news/2023/5/3/rights-commission-says-peru-crackdown-may-qualify-as-a)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 19:11:26+00:00

A new report says that the killing of protesters amid widespread unrest may constitute &#039;extrajudicial executions&#039;.

## Former FBI agent charged in US Capitol attack
 - [https://www.aljazeera.com/news/2023/5/3/former-fbi-agent-charged-in-us-capitol-attack](https://www.aljazeera.com/news/2023/5/3/former-fbi-agent-charged-in-us-capitol-attack)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 18:19:05+00:00

Video footage shows Jared Wise egging on protesters and comparing the Capitol police to &#039;Nazi&#039; and &#039;Gestapo&#039; officers.

## US Fed hikes interest rates by 25bps, signals a pause
 - [https://www.aljazeera.com/economy/2023/5/3/us-fed-hikes-interest-rates-by-25bps-signals-a-pause](https://www.aljazeera.com/economy/2023/5/3/us-fed-hikes-interest-rates-by-25bps-signals-a-pause)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 18:16:07+00:00

In face of recent bank failures &amp; debt cap negotiations, US Fed said it will study economy, inflation in coming weeks.

## US Senate launches latest legislative effort to take on China
 - [https://www.aljazeera.com/news/2023/5/3/us-senate-launches-latest-legislative-effort-to-take-on-china](https://www.aljazeera.com/news/2023/5/3/us-senate-launches-latest-legislative-effort-to-take-on-china)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 17:25:41+00:00

Congressional push comes as US secretary of state says he will reschedule China visit cancelled over &#039;spy balloon&#039; row.

## What we know about the alleged drone attack on the Kremlin so far
 - [https://www.aljazeera.com/news/2023/5/3/what-we-know-alleged-drone-attack-kremlin](https://www.aljazeera.com/news/2023/5/3/what-we-know-alleged-drone-attack-kremlin)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 17:21:05+00:00

Russia accused Ukraine of a failed attempt to assassinate Putin in a drone attack on Moscow&#039;s Kremlin citadel.

## Haiti ‘dangling over an abyss’, UN human rights chief says
 - [https://www.aljazeera.com/news/2023/5/3/haiti-dangling-over-an-abyss-un-human-rights-chief-says](https://www.aljazeera.com/news/2023/5/3/haiti-dangling-over-an-abyss-un-human-rights-chief-says)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 16:54:16+00:00

In address to UN Security Council, Volker Turk warns &#039;current lawlessness&#039; in Caribbean nation requires urgent action.

## Philadelphia 76ers star Joel Embiid wins first NBA MVP award
 - [https://www.aljazeera.com/sports/2023/5/3/philadelphia-76ers-star-joel-embiid-wins-first-nba-mvp-award](https://www.aljazeera.com/sports/2023/5/3/philadelphia-76ers-star-joel-embiid-wins-first-nba-mvp-award)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 16:49:37+00:00

Nikola Jokic of the Denver Nuggets finished runner-up and Giannis Antetokounmpo of the Milwaukee Bucks was third.

## Ukraine says 16 killed in Russian attack on Kherson
 - [https://www.aljazeera.com/news/2023/5/3/ukraine-says-16-killed-in-russian-attack-on-kherson](https://www.aljazeera.com/news/2023/5/3/ukraine-says-16-killed-in-russian-attack-on-kherson)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 16:37:54+00:00

Strikes take place as local authorities announce a 58-hour curfew in the city starting on Friday.

## Syria and Iran leaders sign long-term oil, trade agreements
 - [https://www.aljazeera.com/news/2023/5/3/syria-and-iran-leaders-sign-long-term-oil-trade-agreements](https://www.aljazeera.com/news/2023/5/3/syria-and-iran-leaders-sign-long-term-oil-trade-agreements)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 16:31:09+00:00

The agreements were signed in Damascus to bolster economic ties between war-torn Syria and longtime ally Iran.

## Icahn’s investment firm plunges, down 39% since Hindenburg report
 - [https://www.aljazeera.com/economy/2023/5/3/icahns-investment-firm-plunges-down-39-since-hindenburg-report](https://www.aljazeera.com/economy/2023/5/3/icahns-investment-firm-plunges-down-39-since-hindenburg-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 16:30:07+00:00

Hindenburg has accused the company of overvaluing its holdings and relying on a &quot;Ponzi-like&quot; structure to pay dividends.

## World Bank elects US nominee Ajay Banga president
 - [https://www.aljazeera.com/economy/2023/5/3/world-bank-elects-us-nominee-ajay-banga-as-president](https://www.aljazeera.com/economy/2023/5/3/world-bank-elects-us-nominee-ajay-banga-as-president)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 16:27:33+00:00

He replaces Malpass, who was criticised for his stance on climate change and will step down nearly a year early.

## The struggle against mega-basins is a struggle for life
 - [https://www.aljazeera.com/opinions/2023/5/3/the-struggle-against-mega-basins-is-a-struggle-for-life](https://www.aljazeera.com/opinions/2023/5/3/the-struggle-against-mega-basins-is-a-struggle-for-life)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 15:33:21+00:00

From France to Chile, constructing water reservoirs for irrigation threatens communities and violates water rights.

## We must do more to protect journalists globally
 - [https://www.aljazeera.com/opinions/2023/5/3/we-must-do-more-to-protect-journalists-globally](https://www.aljazeera.com/opinions/2023/5/3/we-must-do-more-to-protect-journalists-globally)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 15:32:35+00:00

Over the past year, imprisonment of journalists and violence against media professionals have spiked.

## Leeds United hire Sam Allardyce as manager after firing Gracia
 - [https://www.aljazeera.com/sports/2023/5/3/leeds-united-hire-sam-allardyce-as-manager-after-firing-gracia](https://www.aljazeera.com/sports/2023/5/3/leeds-united-hire-sam-allardyce-as-manager-after-firing-gracia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 15:22:20+00:00

Allardyce&#039;s last coaching role was at West Brom in 2020-21, when he failed to keep the team in the Premier League.

## Barred from polls, a Greek neo-Nazi seeks way back to politics
 - [https://www.aljazeera.com/features/2023/5/3/barred-from-polls-a-greek-neo-nazi-seeks-way-back-to-politics](https://www.aljazeera.com/features/2023/5/3/barred-from-polls-a-greek-neo-nazi-seeks-way-back-to-politics)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 14:42:34+00:00

Ex-Golden Dawn member Ilias Kasidiaris launches a party before the May 21 vote, but the Supreme Court disqualifies it.

## German troops deployed to UN mission begin withdrawal from Mali
 - [https://www.aljazeera.com/news/2023/5/3/german-troops-deployed-to-un-mission-begin-withdrawal-from-mali](https://www.aljazeera.com/news/2023/5/3/german-troops-deployed-to-un-mission-begin-withdrawal-from-mali)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 14:39:33+00:00

The German troops currently gather reconnaissance for the UN peacekeeping mission MINUSMA fighting armed groups in Mali.

## Ronaldo becomes world’s best-paid athlete after Saudi move
 - [https://www.aljazeera.com/sports/2023/5/3/ronaldo-becomes-worlds-best-paid-athlete-after-saudi-move](https://www.aljazeera.com/sports/2023/5/3/ronaldo-becomes-worlds-best-paid-athlete-after-saudi-move)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 14:24:16+00:00

PSG forward Lionel Messi was next on the Forbes list, while club teammate and France captain Kylian Mbappe was third.

## Tunisia’s choice: Migration and realpolitik in the Mediterranean
 - [https://www.aljazeera.com/news/2023/5/3/skin-trade-energy-migration-realpolitik-in-the-mediterranean](https://www.aljazeera.com/news/2023/5/3/skin-trade-energy-migration-realpolitik-in-the-mediterranean)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 14:19:27+00:00

Tunisia&#039;s relationship with Europe remains firm as the EU courts Tunis&#039;s help in stopping migration.

## Putin ICC warrant debate goes on in South Africa: All the details
 - [https://www.aljazeera.com/news/2023/5/3/putin-icc-warrant-debate-continues-in-s-africa-all-the-details](https://www.aljazeera.com/news/2023/5/3/putin-icc-warrant-debate-continues-in-s-africa-all-the-details)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 13:57:24+00:00

Many in government and opposition are united in proclaiming South Africa&#039;s reluctance to arrest Putin when he visits.

## Clashes rock Sudan ceasefire as UN official seeks aid protection
 - [https://www.aljazeera.com/news/2023/5/3/clashes-rock-sudan-ceasefire-as-un-official-seeks-aid-protection](https://www.aljazeera.com/news/2023/5/3/clashes-rock-sudan-ceasefire-as-un-official-seeks-aid-protection)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 13:45:52+00:00

Martin Griffiths, in visit to the country, seeks pledges from warring sides to allow movement of staff and supplies.

## Brazilian police raid ex-President Bolsonaro’s home, seize phone
 - [https://www.aljazeera.com/news/2023/5/3/brazilian-police-raid-ex-president-bolsonaros-home-seize-phone](https://www.aljazeera.com/news/2023/5/3/brazilian-police-raid-ex-president-bolsonaros-home-seize-phone)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 13:41:35+00:00

Jair Bolsonaro says &#039;surprised&#039; by search, as police said they conducted 16 raids in probe into false COVID documents.

## ‘State of terror’ hangs over Syrians in Lebanon amid deportations
 - [https://www.aljazeera.com/news/2023/5/3/state-of-terror-hangs-over-syrians-in-lebanon-amid-deportations](https://www.aljazeera.com/news/2023/5/3/state-of-terror-hangs-over-syrians-in-lebanon-amid-deportations)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 13:35:50+00:00

Some 800,000 Syrian refugees are registered with the UNHCR after fleeing the civil war that began in 2011.

## Iran seizes second oil tanker in a week amid US confrontation
 - [https://www.aljazeera.com/news/2023/5/3/iran-seizes-second-oil-tanker-in-a-week-amid-us-confrontation](https://www.aljazeera.com/news/2023/5/3/iran-seizes-second-oil-tanker-in-a-week-amid-us-confrontation)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 13:20:26+00:00

US Navy says several Iranian vessels approached the tanker in the Strait of Hormuz and forced it into Iranian waters.

## Why are journalists at risk in the Sahel?
 - [https://www.aljazeera.com/program/the-stream/2023/5/3/why-are-journalists-at-risk-in-the-sahel](https://www.aljazeera.com/program/the-stream/2023/5/3/why-are-journalists-at-risk-in-the-sahel)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 13:03:39+00:00

Five journalists killed and six missing in last decade as conflict rises.

## Israel discussing possible direct Hajj flights to Saudi Arabia
 - [https://www.aljazeera.com/news/2023/5/3/israel-discussing-possible-direct-hajj-flights-to-saudi-arabia](https://www.aljazeera.com/news/2023/5/3/israel-discussing-possible-direct-hajj-flights-to-saudi-arabia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 12:45:25+00:00

Israel&#039;s foreign minister says request submitted and &quot;issue is under discussion&quot;.

## ‘My dog works, too’: The 73-year-old vending on Lima’s streets
 - [https://www.aljazeera.com/features/longform/2023/5/3/my-dog-works-too-the-73-year-old-vending-on-limas-streets](https://www.aljazeera.com/features/longform/2023/5/3/my-dog-works-too-the-73-year-old-vending-on-limas-streets)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 12:01:15+00:00

A vendor in Peru’s capital and his cocker spaniel find ‘life’ on the city&#039;s streets as they work hard to earn a living.

## Port Sudan, a Red Sea refuge for many fleeing Sudan’s violence
 - [https://www.aljazeera.com/features/longform/2023/5/3/port-sudan-a-red-sea-refuge-for-many-fleeing-sudans-violence](https://www.aljazeera.com/features/longform/2023/5/3/port-sudan-a-red-sea-refuge-for-many-fleeing-sudans-violence)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 11:57:34+00:00

People fleeing Khartoum are finding respite in Port Sudan – whether they ultimately choose to leave Sudan or stay.

## Russia accuses Ukraine of attempted drone attack on Kremlin
 - [https://www.aljazeera.com/news/2023/5/3/russia-accuses-ukraine-of-attempted-drone-attack-on-kremlin](https://www.aljazeera.com/news/2023/5/3/russia-accuses-ukraine-of-attempted-drone-attack-on-kremlin)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 11:46:44+00:00

Alleged assault in Moscow seen as an attempt on Putin&#039;s life, state media reports.

## Senegal: Widows of the Sea
 - [https://www.aljazeera.com/program/al-jazeera-world/2023/5/3/senegal-widows-of-the-sea](https://www.aljazeera.com/program/al-jazeera-world/2023/5/3/senegal-widows-of-the-sea)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 11:42:01+00:00

Senegalese women reflect on the loss of their menfolk, feared dead after attempting the 1,500km boat journey to Europe.

## Western countries pile pressure on Mali over Wagner presence
 - [https://www.aljazeera.com/news/2023/5/3/western-countries-pile-pressure-on-mali-over-wagner-presence](https://www.aljazeera.com/news/2023/5/3/western-countries-pile-pressure-on-mali-over-wagner-presence)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 11:18:56+00:00

Questions are raised at a UN human rights meeting about the role of the Russian private military contractor

## Map: What is the state of press freedom in the world today?
 - [https://www.aljazeera.com/news/2023/5/3/map-what-is-the-state-of-press-freedom-in-the-world-today](https://www.aljazeera.com/news/2023/5/3/map-what-is-the-state-of-press-freedom-in-the-world-today)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 11:18:04+00:00

To mark World Press Freedom Day, Al Jazeera looks at where the media is most restricted around the globe.

## British Asians reflect on Empire before King Charles’s coronation
 - [https://www.aljazeera.com/features/2023/5/3/british-asians-reflect-on-empire-before-king-charless-coronation](https://www.aljazeera.com/features/2023/5/3/british-asians-reflect-on-empire-before-king-charless-coronation)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 11:02:32+00:00

Decades after the end of the British Empire, many South Asian Britons are still grappling with the monarchical legacy.

## Delhi’s Coronation Park a neglected site of India’s colonial past
 - [https://www.aljazeera.com/news/2023/5/3/delhis-coronation-park-a-neglected-site-of-indias-colonial-past](https://www.aljazeera.com/news/2023/5/3/delhis-coronation-park-a-neglected-site-of-indias-colonial-past)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 10:22:58+00:00

Visitors to sprawling site meant as memorial to British rule in the subcontinent get no help in understanding the space.

## Gaza truce holds as Palestinians protest death of hunger striker
 - [https://www.aljazeera.com/news/2023/5/3/gaza-truce-holds-as-palestinians-protest-death-of-hunger-striker](https://www.aljazeera.com/news/2023/5/3/gaza-truce-holds-as-palestinians-protest-death-of-hunger-striker)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 10:15:06+00:00

Israeli forces demolish Palestinian homes in the occupied West Bank as more rallies planned after death of Khader Adnan.

## Pakistan government, Imran Khan’s PTI agree on simultaneous polls
 - [https://www.aljazeera.com/news/2023/5/3/pakistan-government-imran-khans-pti-agree-on-simultaneous-polls](https://www.aljazeera.com/news/2023/5/3/pakistan-government-imran-khans-pti-agree-on-simultaneous-polls)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 10:10:22+00:00

Late-night talks between the ruling alliance and Khan&#039;s PTI party however end without any agreement on a poll date.

## UN: 258 million people faced acute food insecurity in 2022
 - [https://www.aljazeera.com/news/2023/5/3/un-258-million-people-faced-acute-food-insecurity-in-2022](https://www.aljazeera.com/news/2023/5/3/un-258-million-people-faced-acute-food-insecurity-in-2022)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 10:07:29+00:00

Report finds number of people facing acute food insecurity and requiring urgent food aid increased for a fourth year.

## Let us have a proper discussion about child sexual abuse
 - [https://www.aljazeera.com/opinions/2023/5/3/let-us-have-a-proper-discussion-about-child-sexual-abuse](https://www.aljazeera.com/opinions/2023/5/3/let-us-have-a-proper-discussion-about-child-sexual-abuse)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 09:52:34+00:00

Turning this important issue into a matter of colour and ethnicity could allow predators to avoid detection.

## Anti-mafia raids lead to more than 100 arrests across Europe
 - [https://www.aljazeera.com/news/2023/5/3/anti-mafia-raids-lead-to-more-than-100-arrests-across-europe](https://www.aljazeera.com/news/2023/5/3/anti-mafia-raids-lead-to-more-than-100-arrests-across-europe)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 09:38:34+00:00

An operation against the Italian &#039;Ndrangheta mafia takes place in Germany, Belgium, France, Italy, Portugal and Spain.

## Photos: Crowds of those seeking rescue swell at Sudan’s seaport
 - [https://www.aljazeera.com/gallery/2023/5/3/photos-crowds-of-those-seeking-rescue-swell-at-sudans-seaport](https://www.aljazeera.com/gallery/2023/5/3/photos-crowds-of-those-seeking-rescue-swell-at-sudans-seaport)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 09:33:33+00:00

Fighting has displaced at least 334,000 people inside Sudan and sent tens of thousands more to neighbouring countries.

## Belarusian activist Protasevich sentenced to eight years in jail
 - [https://www.aljazeera.com/news/2023/5/3/belarusian-activist-protasevich-sentenced-to-eight-years-in-jail](https://www.aljazeera.com/news/2023/5/3/belarusian-activist-protasevich-sentenced-to-eight-years-in-jail)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 09:32:28+00:00

Accusations against the 27-year-old included organising mass riots and calling for sanctions against Belarus.

## School shooting kills one, injures five in Serbia’s Belgrade
 - [https://www.aljazeera.com/news/2023/5/3/school-shootout-kills-one-injures-five-in-serbias-belgrade](https://www.aljazeera.com/news/2023/5/3/school-shootout-kills-one-injures-five-in-serbias-belgrade)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 09:05:43+00:00

A 14-year-old boy is arrested and accused of using his father&#039;s gun to kill a security guard and injure five students.

## Iran’s Raisi in Syria; visit hailed as ‘strategic victory’
 - [https://www.aljazeera.com/news/2023/5/3/irans-raisi-in-syria-visit-hailed-as-strategic-victory](https://www.aljazeera.com/news/2023/5/3/irans-raisi-in-syria-visit-hailed-as-strategic-victory)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 08:39:30+00:00

President&#039;s deputy says it also represents a failure of US policies in the region.

## Sierra Leone ratifies candidacy of president, opposition leader
 - [https://www.aljazeera.com/news/2023/5/3/sierra-leone-ratifies-candidacy-of-president-opposition-leader](https://www.aljazeera.com/news/2023/5/3/sierra-leone-ratifies-candidacy-of-president-opposition-leader)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 08:33:25+00:00

President Julius Maada Bio and opposition leader Samura Kamara also contested in the 2018 elections.

## India, Brazil among most dangerous places for activists: Report
 - [https://www.aljazeera.com/economy/2023/5/3/india-brazil-among-most-dangerous-places-for-activists-report](https://www.aljazeera.com/economy/2023/5/3/india-brazil-among-most-dangerous-places-for-activists-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 08:04:12+00:00

Business &amp; Human Rights Resource Centre says it recorded more than 550 attacks on human rights defenders in 2022.

## UK, Norway scramble fighter jets to track Russia patrol plane
 - [https://www.aljazeera.com/news/2023/5/3/uk-norway-scramble-fighter-jets-to-track-russian-patrol-plane](https://www.aljazeera.com/news/2023/5/3/uk-norway-scramble-fighter-jets-to-track-russian-patrol-plane)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 08:01:03+00:00

Typhoon jets take off from the UK and Norwegian F-35As are also scrambled in a NATO response to the Russian aircraft.

## At least 55 killed in Rwanda flash floods
 - [https://www.aljazeera.com/news/2023/5/3/at-least-55-killed-in-rwanda-flash-floods](https://www.aljazeera.com/news/2023/5/3/at-least-55-killed-in-rwanda-flash-floods)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 07:46:24+00:00

Rwanda is expected to receive above-average rainfall in May.

## Child marriage rate falling too slowly, UN says in new report
 - [https://www.aljazeera.com/news/2023/5/3/child-marriage-rate-falling-too-slowly-un-says-in-new-report](https://www.aljazeera.com/news/2023/5/3/child-marriage-rate-falling-too-slowly-un-says-in-new-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 07:34:22+00:00

UNICEF estimates that some 640 million girls and women today were married when they were below 18.

## Sudan fighting in its 19th day: A list of key events
 - [https://www.aljazeera.com/news/2023/5/3/sudan-fighting-in-its-19th-day-a-list-of-key-events](https://www.aljazeera.com/news/2023/5/3/sudan-fighting-in-its-19th-day-a-list-of-key-events)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 07:25:19+00:00

Sudan&#039;s warring military factions agreed to a new and longer seven-day ceasefire from Thursday.

## Could an old tribal foe undercut Sudan’s Hemedti?
 - [https://www.aljazeera.com/news/2023/5/3/could-an-old-tribal-foe-undercut-sudans-hemedti](https://www.aljazeera.com/news/2023/5/3/could-an-old-tribal-foe-undercut-sudans-hemedti)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 05:54:25+00:00

The RSF could be more vulnerable in its stronghold in Darfur, where a rival foe is challenging Hemedti.

## Myanmar to free more than 2,000 political dissidents
 - [https://www.aljazeera.com/news/2023/5/3/myanmar-to-free-more-than-2000-political-dissidents](https://www.aljazeera.com/news/2023/5/3/myanmar-to-free-more-than-2000-political-dissidents)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 05:43:41+00:00

Military, which has used force to stamp out opposition to its rule, says amnesty is for &#039;humanitarian&#039; reasons.

## US police capture suspect in killing of 5 neighbours in Texas
 - [https://www.aljazeera.com/news/2023/5/3/us-police-capture-suspect-in-killing-of-5-neighbours-in-texas](https://www.aljazeera.com/news/2023/5/3/us-police-capture-suspect-in-killing-of-5-neighbours-in-texas)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 05:26:28+00:00

Francisco Oropesa, 38, is suspected of shooting dead five neighbours aged between eight and 31.

## Russian defence minister calls for missile production to double
 - [https://www.aljazeera.com/news/2023/5/3/russian-defence-minister-calls-for-missile-production-to-double](https://www.aljazeera.com/news/2023/5/3/russian-defence-minister-calls-for-missile-production-to-double)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 04:46:18+00:00

Russia launched a drone attack on Kyiv overnight on Tuesday, though all drones were shot down, Ukrainian officials say.

## Russia-Ukraine war: List of key events, day 434
 - [https://www.aljazeera.com/news/2023/5/3/russia-ukraine-war-list-of-key-events-day-434](https://www.aljazeera.com/news/2023/5/3/russia-ukraine-war-list-of-key-events-day-434)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 04:32:31+00:00

As the war enters its 434th day, we take a look at the main developments.

## US on track to open new Tonga embassy this month
 - [https://www.aljazeera.com/news/2023/5/3/us-on-track-to-open-new-tonga-embassy-this-month](https://www.aljazeera.com/news/2023/5/3/us-on-track-to-open-new-tonga-embassy-this-month)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 04:06:06+00:00

The US has been deepening engagement in the Pacific region amid concerns about China&#039;s influence.

## First Republic rescue fails to calm market turmoil
 - [https://www.aljazeera.com/economy/2023/5/3/first-republic-rescue-fails-to-calm-market-turmoil](https://www.aljazeera.com/economy/2023/5/3/first-republic-rescue-fails-to-calm-market-turmoil)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 03:57:20+00:00

Regional bank shares suffer double-digit losses despite JPMorgan Chase&#039;s acquisition of troubled lender.

## China’s foreign minister touts ‘friendship’ on Myanmar visit
 - [https://www.aljazeera.com/news/2023/5/3/chinas-foreign-minister-touts-friendship-on-myanmar-visit](https://www.aljazeera.com/news/2023/5/3/chinas-foreign-minister-touts-friendship-on-myanmar-visit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 03:44:06+00:00

Qin Gang is the highest-ranking Chinese official to meet Myanmar&#039;s Min Aung Hlaing since his power grab two years ago.

## Messi to face disciplinary action at PSG over Saudi Arabia trip
 - [https://www.aljazeera.com/news/2023/5/3/messi-to-face-disciplinary-action-at-psg-over-saudi-arabia-trip](https://www.aljazeera.com/news/2023/5/3/messi-to-face-disciplinary-action-at-psg-over-saudi-arabia-trip)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 03:09:09+00:00

Football superstar Messi may face suspension for taking a trip to Saudi Arabia without permission from PSG: News reports

## Beyond barbed wire: South Korea invites public to hike DMZ
 - [https://www.aljazeera.com/news/2023/5/3/beyond-barbed-wire-south-korea-invites-public-to-hike-dmz](https://www.aljazeera.com/news/2023/5/3/beyond-barbed-wire-south-korea-invites-public-to-hike-dmz)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 03:01:52+00:00

New trails, currently open only to Koreans for security reasons, provide a new perspective on heavily-fortified border.

## IBM to freeze hiring as CEO expects AI to replace 7,800 jobs
 - [https://www.aljazeera.com/economy/2023/5/3/ibm-to-freeze-hiring-as-ceo-expects-ai-to-replace-7800-jobs](https://www.aljazeera.com/economy/2023/5/3/ibm-to-freeze-hiring-as-ceo-expects-ai-to-replace-7800-jobs)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 02:27:15+00:00

CEO Arvind Krishna says 30 percent of non-customer-facing roles could be axed in the next five years.

## Hong Kong reduces directly-elected seats in district polls
 - [https://www.aljazeera.com/news/2023/5/3/hong-kong-reduces-directly-elected-seats-in-district-polls](https://www.aljazeera.com/news/2023/5/3/hong-kong-reduces-directly-elected-seats-in-district-polls)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 02:20:18+00:00

The latest changes are part of an effort to ensure only &#039;patriots&#039; hold political office in the territory.

## Hong Kong court considers journalist appeal on press freedom day
 - [https://www.aljazeera.com/news/2023/5/3/hong-kong-court-considers-journalist-appeal-on-press-freedom-day](https://www.aljazeera.com/news/2023/5/3/hong-kong-court-considers-journalist-appeal-on-press-freedom-day)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 02:15:17+00:00

Bao Choy is appealing her conviction over her investigation into a brutal mob attack at the Yuen Long station in 2019.

## Palestinian groups, Israeli forces agree to Gaza truce: Report
 - [https://www.aljazeera.com/news/2023/5/3/palestinian-groups-israeli-forces-agree-to-gaza-truce-report](https://www.aljazeera.com/news/2023/5/3/palestinian-groups-israeli-forces-agree-to-gaza-truce-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 01:50:40+00:00

Israeli forces and armed Palestinian groups in Gaza have agreed to a &#039;reciprocal and simultaneous&#039; ceasefire: Reuters.

## Amid protests, authorities uphold legitimacy of Paraguay election
 - [https://www.aljazeera.com/news/2023/5/3/amid-protests-authorities-uphold-legitimacy-of-paraguay-election](https://www.aljazeera.com/news/2023/5/3/amid-protests-authorities-uphold-legitimacy-of-paraguay-election)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-05-03 00:26:04+00:00

The Organization of American States, as well as Paraguay officials, have affirmed the legitimacy of Sunday&#039;s vote.

