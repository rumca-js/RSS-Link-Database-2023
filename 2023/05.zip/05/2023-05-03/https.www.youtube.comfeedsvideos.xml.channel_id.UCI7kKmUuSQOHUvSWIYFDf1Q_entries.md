# Source:Eliminate, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCI7kKmUuSQOHUvSWIYFDf1Q, language:en-US

## Sampling Virtual Riot
 - [https://www.youtube.com/watch?v=GPAKfcYiCl8](https://www.youtube.com/watch?v=GPAKfcYiCl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCI7kKmUuSQOHUvSWIYFDf1Q
 - date published: 2023-05-03 19:50:01+00:00

be the god of your own destiny

boxter: https://soundcloud.com/boxtermusic

sample credit: https://www.youtube.com/watch?v=iRCD8ovBD9o
vr patreon: https://www.patreon.com/virtualriot

I stream every Tuesday/Wednesday/Thursday 1pm PST

• TWITCH: https://www.twitch.tv/eliminatehq
• DISCORD: https://discord.gg/eliminatehq
• MY SAMPLE PACK: https://splice.com/sounds/disciple-samples/eliminate-cyber-trap-vol-1?sound_type=sample
• INSTAGRAM: https://www.instagram.com/eliminatemusic/
• TWITTER: https://twitter.com/eliminatemusic
• SUBREDDIT: https://www.reddit.com/r/EliminateHQ/


top secret burner account:
https://soundcloud.com/dubsteptractor

edited by https://twitter.com/noiziatrics & myself
outro animation by https://www.instagram.com/kuroeigakan/

