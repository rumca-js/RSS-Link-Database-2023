# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Niemcy: Atak nożownika w szkole. Dwie dziewczynki ciężko ranne
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/niemcy-atak-nozownika-w-szkole-dwie-dziewczynki-ciezko-ranne/](https://www.polsatnews.pl/wiadomosc/2023-05-03/niemcy-atak-nozownika-w-szkole-dwie-dziewczynki-ciezko-ranne/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 19:57:00+00:00

Nożownik zaatakował dwoje dzieci na terenie szkoły protestanckiej w dzielnicy Berlina - Neukölln. Został aresztowany. Jak donoszą niemieckie media, 39-latek prawdopodobnie jest chory psychicznie, a atak nie miał motywów politycznych ani religijnych.

## Watykan. Kard. Pietro Parolin: Bdzie się misja pokojowa Watykanu w sprawie wojny w Ukrainie
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/watykan-kard-pietro-parolin-bdzie-sie-misja-pokojowa-watykanu-w-sprawie-wojny-w-ukrainie/](https://www.polsatnews.pl/wiadomosc/2023-05-03/watykan-kard-pietro-parolin-bdzie-sie-misja-pokojowa-watykanu-w-sprawie-wojny-w-ukrainie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 19:14:00+00:00

Odbędzie się misja pokojowa Watykanu w sprawie wojny w Ukrainie - powiedział w środę sekretarz stanu kardynał Pietro Parolin. Dodał, że jest zaskoczony reakcją władz Rosji i Ukrainy, które stwierdziły, że nie wiedzą o nic o misji pokojowej.

## Dmitrij Miedwiediew: Atak dronów nie zostawia Rosji innej opcji niż eliminacja Zełenskiego
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/dmitrij-miedwiediew-atak-dronow-nie-zostawia-rosji-innej-opcji-niz-eliminacja-zelenskiego/](https://www.polsatnews.pl/wiadomosc/2023-05-03/dmitrij-miedwiediew-atak-dronow-nie-zostawia-rosji-innej-opcji-niz-eliminacja-zelenskiego/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 16:33:00+00:00

Atak dronów nie pozostawia Rosji żadnych opcji z wyjątkiem eliminacji Zełenskiego i jego kliki - napisał były prezydent Rosji Dmitrij Miedwiediew. W środę Rosja oskarżyła Ukrainę o nocny atak dronami na Kreml, co miało być próbą zabicia prezydenta Władimira Putina. Ukraina zaprzeczyła, by miała coś wspólnego z tym incydentem.

## USA. Policja zatrzymała mężczyznę, który zabił swoich sąsiadów. Ukrył się w szafce pod praniem
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/usa-policja-zatrzymala-mezczyzne-ktory-zabil-swoich-sasiadow-ukryl-sie-w-szafce-pod-praniem/](https://www.polsatnews.pl/wiadomosc/2023-05-03/usa-policja-zatrzymala-mezczyzne-ktory-zabil-swoich-sasiadow-ukryl-sie-w-szafce-pod-praniem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 15:53:00+00:00

Policja zatrzymała mężczyznę z Teksasu, który w sobotę zastrzelił pięcioro swoich sąsiadów. Mężczyzna ukrywał się kilka kilometrów od swojego domu. Funkcjonariusze znaleźli go u krewnego, gdzie schował się w szafce, pod stertą prania.

## Rosja oskarża Ukrainę o atak dronami na Kreml. Twierdzą, że była to próba zabicia Putina
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/rosja-oskarza-ukraine-o-atak-dronami-na-kreml-twierdza-ze-byla-to-proba-zabicia-putina/](https://www.polsatnews.pl/wiadomosc/2023-05-03/rosja-oskarza-ukraine-o-atak-dronami-na-kreml-twierdza-ze-byla-to-proba-zabicia-putina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 13:28:00+00:00

Rosja oskarżyła Ukrainę o nocny atak dronami na Kreml w celu próby zabicia prezydenta Władimira Putina. Doradca prezydenta Ukrainy Wołodymyra Zełenskiego, Mychajło Podoliak zaprzeczył, jakoby Kijów miał coś wspólnego z tym incydentem.

## Serbia. 14-latek zabił dziewięć osób w szkole. Miał listę
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/serbia-14-latek-zabil-dziewiec-osob-w-szkole-mial-liste/](https://www.polsatnews.pl/wiadomosc/2023-05-03/serbia-14-latek-zabil-dziewiec-osob-w-szkole-mial-liste/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 13:00:00+00:00

Dziewięć osób nie żyje - ośmioro dzieci i dorosły - po strzelaninie, do której doszło w Belgradzie. 14-letni sprawca sam zadzwonił na policję i powiedział co zrobił. Nad planem ataku pracował miesiąc, miał też listę osób, które chciał zabić.

## Palestyna. Sześciolatek wpadł do klatki lwa. Nie żyje
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/palestyna-nie-zyje-6-latek-chlopiec-zostal-zaatakowany-przez-lwa-w-prywatnym-zoo/](https://www.polsatnews.pl/wiadomosc/2023-05-03/palestyna-nie-zyje-6-latek-chlopiec-zostal-zaatakowany-przez-lwa-w-prywatnym-zoo/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 11:40:00+00:00

Sześcioletni Hamada Iqtiet podczas wizyty w prywatnym zoo w mieście Chan Junus w Strefie Gazy został zaatakowany przez lwa po tym, jak wspiął się na ogrodzenie wybiegu. W starciu ze zwierzęciem chłopiec odniósł poważne obrażenia i nie udało się go uratować.

## Rosjanie zaatakowali dronami. Skuteczna obrona Ukraińców
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/ukraina-rosyjski-zaatakowali-dronami-shahed-sily-powietrzne-zestrzelily-wiekszosc-bezzalogowcow/](https://www.polsatnews.pl/wiadomosc/2023-05-03/ukraina-rosyjski-zaatakowali-dronami-shahed-sily-powietrzne-zestrzelily-wiekszosc-bezzalogowcow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 10:57:00+00:00

Ukraińskie siły obrony powietrznej zestrzeliły w nocy z wtorku na środę 21 z 26 irańskich dronów Shahed – przekazały ukraińskie siły powietrzne. Nad Kijowem zestrzelone zostały wszystkie obiekty. Okupanci trafili w cele w Dnieprze oraz obwodzie kirowohradzkim.

## Białoruś: Raman Pratasiewicz dostał osiem lat więzienia
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/bialorus-raman-pratasiewicz-z-wyrokiem-8-lat-wiezienia-dwoch-innych-dziennikarzy-skazano-zaocznie/](https://www.polsatnews.pl/wiadomosc/2023-05-03/bialorus-raman-pratasiewicz-z-wyrokiem-8-lat-wiezienia-dwoch-innych-dziennikarzy-skazano-zaocznie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 10:31:00+00:00

Opozycyjny dziennikarz Raman Pratasiewicz został skazany przez sąd w Mińsku na osiem lat więzienia. W przeszłości był współredaktorem kanału Nexta, który białoruskie władze uznały za ekstremistyczny - w 2022 roku serwis zaliczono do organizacji terrorystycznych, zaś Pratasiewicza określano jako terrorystę.

## Australia: Znaleziono szczątki wędkarza. Były we wnętrzu krokodyla
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/australia-znaleziono-szczatki-wedkarza-byly-we-wnetrzu-krokodyla/](https://www.polsatnews.pl/wiadomosc/2023-05-03/australia-znaleziono-szczatki-wedkarza-byly-we-wnetrzu-krokodyla/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 09:57:00+00:00

We wnętrzu krokodyla znaleziono szczątki poszukiwanego od kilku dni wędkarza. Mężczyzna był ostatnio widziany w sobotę na polu kempingowym Kennedys Bend, w północno-wschodniej Australii. - Usłyszałem krzyk, po którym nastąpił głośny plusk - relacjonował jeden z turystów.

## Ukraina: Rosjanie ostrzelali market w Chersoniu. Zginęły co najmniej trzy osoby
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/ukraina-rosjanie-ostrzelali-market-w-chersoniu-zginely-co-najmniej-trzy-osoby/](https://www.polsatnews.pl/wiadomosc/2023-05-03/ukraina-rosjanie-ostrzelali-market-w-chersoniu-zginely-co-najmniej-trzy-osoby/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 09:14:00+00:00

Armia rosyjska ostrzelała jedyny działający supermarket w Chersoniu. Co najmniej trzy osoby zginęły, a pięć zostało rannych - poinformowało Ministerstwo Spraw Wewnętrznych Ukrainy. Ofiary to pracownicy i klienci obiektu.

## Wielka Brytania: Przerzucił przedmioty przez ogrodzenie Pałacu Buckingham. Został zatrzymany
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/wielka-brytania-przerzucil-przedmioty-przez-ogrodzenie-palacu-buckingham-zostal-zatrzymany/](https://www.polsatnews.pl/wiadomosc/2023-05-03/wielka-brytania-przerzucil-przedmioty-przez-ogrodzenie-palacu-buckingham-zostal-zatrzymany/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 08:17:00+00:00

Na teren Pałacu Buckingham w Londynie mężczyzna przerzucał przez ogrodzenie przedmioty, prawdopodobnie naboje do strzelby. Podejrzanego zatrzymała policja. Do incydentu doszło cztery dni przed koronacją króla Karola III, która jest zaplanowana na sobotę.

## Pożar składu paliwa w Rosji. "Ogień widoczny z Mostu Krymskiego"
 - [https://www.polsatnews.pl/wiadomosc/2023-05-03/rosja-pozar-skladu-ropy-w-kraju-krasnodarskim-powodem-mogl-byc-atak-dronow/](https://www.polsatnews.pl/wiadomosc/2023-05-03/rosja-pozar-skladu-ropy-w-kraju-krasnodarskim-powodem-mogl-byc-atak-dronow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-05-03 07:20:00+00:00

Zbiornik paliwa płonie w regionie Krasnodaru - podobno po ataku drona - poinformował na Twitterze Anton Heraszczenko, doradca szefa MSW Ukrainy. Ogień ma być widoczny z Mostu Krymskiego. Władze lokalne podały, że nie ma informacji o ofiarach i rannych.

