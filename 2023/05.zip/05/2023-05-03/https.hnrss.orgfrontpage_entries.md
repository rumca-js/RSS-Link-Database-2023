# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Voyager as Technosignature
 - [https://www.centauri-dreams.org/2023/05/03/voyager-as-technosignature/](https://www.centauri-dreams.org/2023/05/03/voyager-as-technosignature/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 21:20:45+00:00

<p>Article URL: <a href="https://www.centauri-dreams.org/2023/05/03/voyager-as-technosignature/">https://www.centauri-dreams.org/2023/05/03/voyager-as-technosignature/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35807957">https://news.ycombinator.com/item?id=35807957</a></p>
<p>Points: 19</p>
<p># Comments: 2</p>

## Wearing an eye mask during sleep improves episodic learning and alertness
 - [https://pubmed.ncbi.nlm.nih.gov/36521010/](https://pubmed.ncbi.nlm.nih.gov/36521010/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 21:20:18+00:00

<p>Article URL: <a href="https://pubmed.ncbi.nlm.nih.gov/36521010/">https://pubmed.ncbi.nlm.nih.gov/36521010/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35807951">https://news.ycombinator.com/item?id=35807951</a></p>
<p>Points: 24</p>
<p># Comments: 21</p>

## Measured typing latency of popular terminal emulators
 - [https://tomscii.sig7.se/2021/01/Typing-latency-of-Zutty](https://tomscii.sig7.se/2021/01/Typing-latency-of-Zutty)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 20:54:32+00:00

<p>Article URL: <a href="https://tomscii.sig7.se/2021/01/Typing-latency-of-Zutty">https://tomscii.sig7.se/2021/01/Typing-latency-of-Zutty</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35807660">https://news.ycombinator.com/item?id=35807660</a></p>
<p>Points: 18</p>
<p># Comments: 8</p>

## Lotus 1-2-3 for Linux
 - [https://github.com/taviso/123elf](https://github.com/taviso/123elf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 20:52:41+00:00

<p>Article URL: <a href="https://github.com/taviso/123elf">https://github.com/taviso/123elf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35807639">https://news.ycombinator.com/item?id=35807639</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Is Perpetual Motion Possible at the Quantum Level?
 - [https://www.quantamagazine.org/is-perpetual-motion-possible-at-the-quantum-level-20230503/](https://www.quantamagazine.org/is-perpetual-motion-possible-at-the-quantum-level-20230503/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 20:41:43+00:00

<p>Article URL: <a href="https://www.quantamagazine.org/is-perpetual-motion-possible-at-the-quantum-level-20230503/">https://www.quantamagazine.org/is-perpetual-motion-possible-at-the-quantum-level-20230503/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35807489">https://news.ycombinator.com/item?id=35807489</a></p>
<p>Points: 7</p>
<p># Comments: 4</p>

## Searches for VPN Soar in Utah Amidst Pornhub Blockage
 - [https://www.culturalcurrents.institute/insights/utah-pornhub-blocked](https://www.culturalcurrents.institute/insights/utah-pornhub-blocked)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 20:35:00+00:00

<p>Article URL: <a href="https://www.culturalcurrents.institute/insights/utah-pornhub-blocked">https://www.culturalcurrents.institute/insights/utah-pornhub-blocked</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35807408">https://news.ycombinator.com/item?id=35807408</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Angular v16 Is Here
 - [https://blog.angular.io/angular-v16-is-here-4d7a28ec680d?gi=59158dd70516](https://blog.angular.io/angular-v16-is-here-4d7a28ec680d?gi=59158dd70516)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 20:11:49+00:00

<p>Article URL: <a href="https://blog.angular.io/angular-v16-is-here-4d7a28ec680d?gi=59158dd70516">https://blog.angular.io/angular-v16-is-here-4d7a28ec680d?gi=59158dd70516</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35807125">https://news.ycombinator.com/item?id=35807125</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## New in Chrome 113
 - [https://developer.chrome.com/blog/new-in-chrome-113/](https://developer.chrome.com/blog/new-in-chrome-113/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 19:47:31+00:00

<p>Article URL: <a href="https://developer.chrome.com/blog/new-in-chrome-113/">https://developer.chrome.com/blog/new-in-chrome-113/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35806796">https://news.ycombinator.com/item?id=35806796</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## FDA Approves First Respiratory Syncytial Virus (RSV) Vaccine
 - [https://www.fda.gov/news-events/press-announcements/fda-approves-first-respiratory-syncytial-virus-rsv-vaccine](https://www.fda.gov/news-events/press-announcements/fda-approves-first-respiratory-syncytial-virus-rsv-vaccine)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 19:44:30+00:00

<p>Article URL: <a href="https://www.fda.gov/news-events/press-announcements/fda-approves-first-respiratory-syncytial-virus-rsv-vaccine">https://www.fda.gov/news-events/press-announcements/fda-approves-first-respiratory-syncytial-virus-rsv-vaccine</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35806753">https://news.ycombinator.com/item?id=35806753</a></p>
<p>Points: 18</p>
<p># Comments: 2</p>

## Graviton 3, Apple M2 and Qualcomm 8cx 3rd gen: a URL parsing benchmark
 - [https://lemire.me/blog/2023/05/03/graviton-3-apple-m2-and-qualcomm-8cx-3rd-gen-a-url-parsing-benchmark/](https://lemire.me/blog/2023/05/03/graviton-3-apple-m2-and-qualcomm-8cx-3rd-gen-a-url-parsing-benchmark/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 19:31:47+00:00

<p>Article URL: <a href="https://lemire.me/blog/2023/05/03/graviton-3-apple-m2-and-qualcomm-8cx-3rd-gen-a-url-parsing-benchmark/">https://lemire.me/blog/2023/05/03/graviton-3-apple-m2-and-qualcomm-8cx-3rd-gen-a-url-parsing-benchmark/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35806633">https://news.ycombinator.com/item?id=35806633</a></p>
<p>Points: 22</p>
<p># Comments: 8</p>

## Testosterone in tusks: Hormones in mammoth fossils excite paleontologists
 - [https://arstechnica.com/science/2023/05/testosterone-in-tusks-hormones-in-mammoth-fossils-excite-paleontologists/](https://arstechnica.com/science/2023/05/testosterone-in-tusks-hormones-in-mammoth-fossils-excite-paleontologists/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 19:18:25+00:00

<p>Article URL: <a href="https://arstechnica.com/science/2023/05/testosterone-in-tusks-hormones-in-mammoth-fossils-excite-paleontologists/">https://arstechnica.com/science/2023/05/testosterone-in-tusks-hormones-in-mammoth-fossils-excite-paleontologists/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35806515">https://news.ycombinator.com/item?id=35806515</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Is ChatGPT Securities Fraud?
 - [https://www.bloomberg.com/opinion/articles/2023-05-03/is-chatgpt-securities-fraud](https://www.bloomberg.com/opinion/articles/2023-05-03/is-chatgpt-securities-fraud)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 19:15:28+00:00

<p>Article URL: <a href="https://www.bloomberg.com/opinion/articles/2023-05-03/is-chatgpt-securities-fraud">https://www.bloomberg.com/opinion/articles/2023-05-03/is-chatgpt-securities-fraud</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35806483">https://news.ycombinator.com/item?id=35806483</a></p>
<p>Points: 22</p>
<p># Comments: 1</p>

## Unity lays off 600 staff members, prepares to close half of its offices
 - [https://venturebeat.com/games/unity-lays-off-600-staff-members-prepares-to-close-half-of-its-offices/](https://venturebeat.com/games/unity-lays-off-600-staff-members-prepares-to-close-half-of-its-offices/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 19:07:03+00:00

<p>Article URL: <a href="https://venturebeat.com/games/unity-lays-off-600-staff-members-prepares-to-close-half-of-its-offices/">https://venturebeat.com/games/unity-lays-off-600-staff-members-prepares-to-close-half-of-its-offices/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35806397">https://news.ycombinator.com/item?id=35806397</a></p>
<p>Points: 47</p>
<p># Comments: 18</p>

## Driving Compilers
 - [https://fabiensanglard.net/dc/index.php](https://fabiensanglard.net/dc/index.php)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 18:54:33+00:00

<p>Article URL: <a href="https://fabiensanglard.net/dc/index.php">https://fabiensanglard.net/dc/index.php</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35806237">https://news.ycombinator.com/item?id=35806237</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Federal Reserve pushes interest rates above 5% for first time since 2007
 - [https://finance.yahoo.com/news/federal-reserve-interest-rate-decision-may-3-155524134.html](https://finance.yahoo.com/news/federal-reserve-interest-rate-decision-may-3-155524134.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 18:16:36+00:00

<p>Article URL: <a href="https://finance.yahoo.com/news/federal-reserve-interest-rate-decision-may-3-155524134.html">https://finance.yahoo.com/news/federal-reserve-interest-rate-decision-may-3-155524134.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35805757">https://news.ycombinator.com/item?id=35805757</a></p>
<p>Points: 49</p>
<p># Comments: 34</p>

## SyBOS Is Hiring a German-Speaking VP of Engineering
 - [https://www.sybos.net/](https://www.sybos.net/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 17:57:47+00:00

<p>Article URL: <a href="https://www.sybos.net/">https://www.sybos.net/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35805530">https://news.ycombinator.com/item?id=35805530</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Brazilian frog might be the first pollinating amphibian known to science
 - [https://www.science.org/content/article/brazilian-frog-might-be-first-pollinating-amphibian-known-science](https://www.science.org/content/article/brazilian-frog-might-be-first-pollinating-amphibian-known-science)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 17:41:44+00:00

<p>Article URL: <a href="https://www.science.org/content/article/brazilian-frog-might-be-first-pollinating-amphibian-known-science">https://www.science.org/content/article/brazilian-frog-might-be-first-pollinating-amphibian-known-science</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35805345">https://news.ycombinator.com/item?id=35805345</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## How Does an FPGA Work?
 - [https://learn.sparkfun.com/tutorials/how-does-an-fpga-work/all](https://learn.sparkfun.com/tutorials/how-does-an-fpga-work/all)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 17:11:47+00:00

<p>Article URL: <a href="https://learn.sparkfun.com/tutorials/how-does-an-fpga-work/all">https://learn.sparkfun.com/tutorials/how-does-an-fpga-work/all</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35804935">https://news.ycombinator.com/item?id=35804935</a></p>
<p>Points: 30</p>
<p># Comments: 8</p>

## Three failed US banks had one thing in common: KPMG
 - [https://www.ft.com/content/feb33914-493e-467c-b67e-28fcd1b3814d](https://www.ft.com/content/feb33914-493e-467c-b67e-28fcd1b3814d)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 16:59:07+00:00

<p>Article URL: <a href="https://www.ft.com/content/feb33914-493e-467c-b67e-28fcd1b3814d">https://www.ft.com/content/feb33914-493e-467c-b67e-28fcd1b3814d</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35804759">https://news.ycombinator.com/item?id=35804759</a></p>
<p>Points: 27</p>
<p># Comments: 16</p>

## Steve Jobs and the Usable Computer (6 October 2011 by Tim Berners-Lee)
 - [https://www.w3.org/blog/2011/10/steve-jobs/](https://www.w3.org/blog/2011/10/steve-jobs/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 16:57:02+00:00

<p>Article URL: <a href="https://www.w3.org/blog/2011/10/steve-jobs/">https://www.w3.org/blog/2011/10/steve-jobs/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35804721">https://news.ycombinator.com/item?id=35804721</a></p>
<p>Points: 26</p>
<p># Comments: 5</p>

## SparseGPT: Language Models Can Be Accurately Pruned in One-Shot
 - [https://arxiv.org/abs/2301.00774](https://arxiv.org/abs/2301.00774)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 16:44:19+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2301.00774">https://arxiv.org/abs/2301.00774</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35804556">https://news.ycombinator.com/item?id=35804556</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Temporal .NET – Deterministic Workflow Authoring in .NET
 - [https://temporal.io/blog/introducing-temporal-dotnet](https://temporal.io/blog/introducing-temporal-dotnet)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 16:18:51+00:00

<p>Article URL: <a href="https://temporal.io/blog/introducing-temporal-dotnet">https://temporal.io/blog/introducing-temporal-dotnet</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35804220">https://news.ycombinator.com/item?id=35804220</a></p>
<p>Points: 29</p>
<p># Comments: 6</p>

## Why “free” street parking could be costing you hundreds more in rent
 - [https://www.washingtonpost.com/climate-environment/2023/05/02/eliminating-parking-minimums-liveable-cities/](https://www.washingtonpost.com/climate-environment/2023/05/02/eliminating-parking-minimums-liveable-cities/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 15:32:30+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/climate-environment/2023/05/02/eliminating-parking-minimums-liveable-cities/">https://www.washingtonpost.com/climate-environment/2023/05/02/eliminating-parking-minimums-liveable-cities/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35803624">https://news.ycombinator.com/item?id=35803624</a></p>
<p>Points: 24</p>
<p># Comments: 12</p>

## The Full Story of Large Language Models and RLHF
 - [https://www.assemblyai.com/blog/the-full-story-of-large-language-models-and-rlhf/](https://www.assemblyai.com/blog/the-full-story-of-large-language-models-and-rlhf/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 15:24:52+00:00

<p>Article URL: <a href="https://www.assemblyai.com/blog/the-full-story-of-large-language-models-and-rlhf/">https://www.assemblyai.com/blog/the-full-story-of-large-language-models-and-rlhf/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35803522">https://news.ycombinator.com/item?id=35803522</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Neverssl Uses SSL
 - [https://twitter.com/NeverSSL/status/1456310362551164928](https://twitter.com/NeverSSL/status/1456310362551164928)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 15:24:04+00:00

<p>Article URL: <a href="https://twitter.com/NeverSSL/status/1456310362551164928">https://twitter.com/NeverSSL/status/1456310362551164928</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35803511">https://news.ycombinator.com/item?id=35803511</a></p>
<p>Points: 29</p>
<p># Comments: 14</p>

## Replit's new Code LLM: Open Source, 77% smaller than Codex, trained in 1 week
 - [https://www.latent.space/p/reza-shabani#details](https://www.latent.space/p/reza-shabani#details)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 15:19:20+00:00

<p>Article URL: <a href="https://www.latent.space/p/reza-shabani#details">https://www.latent.space/p/reza-shabani#details</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35803435">https://news.ycombinator.com/item?id=35803435</a></p>
<p>Points: 80</p>
<p># Comments: 25</p>

## Web3's fake version of Web history
 - [https://davekarpf.substack.com/p/web3s-fake-version-of-the-history](https://davekarpf.substack.com/p/web3s-fake-version-of-the-history)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 14:51:20+00:00

<p>Article URL: <a href="https://davekarpf.substack.com/p/web3s-fake-version-of-the-history">https://davekarpf.substack.com/p/web3s-fake-version-of-the-history</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35803096">https://news.ycombinator.com/item?id=35803096</a></p>
<p>Points: 19</p>
<p># Comments: 9</p>

## Unity to lay off 8% of its workforce
 - [https://www.cnbc.com/2023/05/03/unity-layoffs-company-to-cut-600-employees-or-8percent-of-its-workforce.html](https://www.cnbc.com/2023/05/03/unity-layoffs-company-to-cut-600-employees-or-8percent-of-its-workforce.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 14:21:41+00:00

<p>Article URL: <a href="https://www.cnbc.com/2023/05/03/unity-layoffs-company-to-cut-600-employees-or-8percent-of-its-workforce.html">https://www.cnbc.com/2023/05/03/unity-layoffs-company-to-cut-600-employees-or-8percent-of-its-workforce.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35802730">https://news.ycombinator.com/item?id=35802730</a></p>
<p>Points: 61</p>
<p># Comments: 20</p>

## Google, Microsoft CEOs Called to AI Meeting at White House
 - [https://www.reuters.com/technology/google-microsoft-openai-ceos-attend-white-house-ai-meeting-official-2023-05-02/](https://www.reuters.com/technology/google-microsoft-openai-ceos-attend-white-house-ai-meeting-official-2023-05-02/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 14:18:46+00:00

<p>Article URL: <a href="https://www.reuters.com/technology/google-microsoft-openai-ceos-attend-white-house-ai-meeting-official-2023-05-02/">https://www.reuters.com/technology/google-microsoft-openai-ceos-attend-white-house-ai-meeting-official-2023-05-02/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35802698">https://news.ycombinator.com/item?id=35802698</a></p>
<p>Points: 49</p>
<p># Comments: 31</p>

## State of Private Markets: Q1 2023
 - [https://carta.com/blog/state-of-private-markets-q1-2023/](https://carta.com/blog/state-of-private-markets-q1-2023/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 14:07:29+00:00

<p>Article URL: <a href="https://carta.com/blog/state-of-private-markets-q1-2023/">https://carta.com/blog/state-of-private-markets-q1-2023/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35802575">https://news.ycombinator.com/item?id=35802575</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## The Framework Laptop 13
 - [https://frame.work/blog/announcing-the-framework-laptop-13-powered-by-amd-ryzen](https://frame.work/blog/announcing-the-framework-laptop-13-powered-by-amd-ryzen)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 13:36:24+00:00

<p>Article URL: <a href="https://frame.work/blog/announcing-the-framework-laptop-13-powered-by-amd-ryzen">https://frame.work/blog/announcing-the-framework-laptop-13-powered-by-amd-ryzen</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35802210">https://news.ycombinator.com/item?id=35802210</a></p>
<p>Points: 92</p>
<p># Comments: 52</p>

## Poisoning Language Models During Instruction Tuning
 - [https://arxiv.org/abs/2305.00944](https://arxiv.org/abs/2305.00944)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 12:39:58+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2305.00944">https://arxiv.org/abs/2305.00944</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35801673">https://news.ycombinator.com/item?id=35801673</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Passkeys: The Beginning of the End of the Password
 - [https://blog.google/technology/safety-security/the-beginning-of-the-end-of-the-password/](https://blog.google/technology/safety-security/the-beginning-of-the-end-of-the-password/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 12:13:23+00:00

<p>Article URL: <a href="https://blog.google/technology/safety-security/the-beginning-of-the-end-of-the-password/">https://blog.google/technology/safety-security/the-beginning-of-the-end-of-the-password/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35801392">https://news.ycombinator.com/item?id=35801392</a></p>
<p>Points: 40</p>
<p># Comments: 29</p>

## Haskell in Production: Standard Chartered
 - [https://serokell.io/blog/haskell-in-production-standard-chartered](https://serokell.io/blog/haskell-in-production-standard-chartered)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 12:01:03+00:00

<p>Article URL: <a href="https://serokell.io/blog/haskell-in-production-standard-chartered">https://serokell.io/blog/haskell-in-production-standard-chartered</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35801293">https://news.ycombinator.com/item?id=35801293</a></p>
<p>Points: 41</p>
<p># Comments: 9</p>

## Show HN: Niui 3.0 – lightweight, rich, accessible front end
 - [https://niui.dev](https://niui.dev)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 11:58:01+00:00

<p>Here is a library of the most common components I've created in the last decade. It aims to solve the toughest UI problems like Carousel, Modal and Select, while using native browser capabilities as much as possible, and focusing on accessibility, stability and customisation. 14 KB of CSS, JS optional.<p><a href="https://rado.bg/niui-3-0-native-internet-user-interface/" rel="nofollow">https://rado.bg/niui-3-0-native-internet-user-interface/</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35801269">https://news.ycombinator.com/item?id=35801269</a></p>
<p>Points: 12</p>
<p># Comments: 7</p>

## The Skills Gap for Fortran Looms Large in HPC
 - [https://www.nextplatform.com/2023/05/02/the-skills-gap-for-fortran-looms-large-in-hpc/](https://www.nextplatform.com/2023/05/02/the-skills-gap-for-fortran-looms-large-in-hpc/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 11:57:25+00:00

<p>Article URL: <a href="https://www.nextplatform.com/2023/05/02/the-skills-gap-for-fortran-looms-large-in-hpc/">https://www.nextplatform.com/2023/05/02/the-skills-gap-for-fortran-looms-large-in-hpc/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35801265">https://news.ycombinator.com/item?id=35801265</a></p>
<p>Points: 14</p>
<p># Comments: 13</p>

## James Webb Space Telescope detects water vapor around alien planet
 - [https://www.space.com/james-webb-space-telescope-exoplanet-water-vapor-atmosphere-or-star](https://www.space.com/james-webb-space-telescope-exoplanet-water-vapor-atmosphere-or-star)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 11:46:10+00:00

<p>Article URL: <a href="https://www.space.com/james-webb-space-telescope-exoplanet-water-vapor-atmosphere-or-star">https://www.space.com/james-webb-space-telescope-exoplanet-water-vapor-atmosphere-or-star</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35801172">https://news.ycombinator.com/item?id=35801172</a></p>
<p>Points: 22</p>
<p># Comments: 8</p>

## A 16 bit computer simulated on circuitverse
 - [https://circuitverse.org/users/4699/projects/femto-4v2-6-computer](https://circuitverse.org/users/4699/projects/femto-4v2-6-computer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 11:35:48+00:00

<p>Article URL: <a href="https://circuitverse.org/users/4699/projects/femto-4v2-6-computer">https://circuitverse.org/users/4699/projects/femto-4v2-6-computer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35801086">https://news.ycombinator.com/item?id=35801086</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## I want to talk about WebGPU
 - [https://cohost.org/mcc/post/1406157-i-want-to-talk-about-webgpu](https://cohost.org/mcc/post/1406157-i-want-to-talk-about-webgpu)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 11:24:57+00:00

<p>Article URL: <a href="https://cohost.org/mcc/post/1406157-i-want-to-talk-about-webgpu">https://cohost.org/mcc/post/1406157-i-want-to-talk-about-webgpu</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35800988">https://news.ycombinator.com/item?id=35800988</a></p>
<p>Points: 33</p>
<p># Comments: 1</p>

## Snobol (“StriNg Oriented and SymBOlic Language”)
 - [https://en.wikipedia.org/wiki/SNOBOL](https://en.wikipedia.org/wiki/SNOBOL)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 11:19:23+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/SNOBOL">https://en.wikipedia.org/wiki/SNOBOL</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35800936">https://news.ycombinator.com/item?id=35800936</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Beware of AI pseudoscience and snake oil
 - [https://www.baldurbjarnason.com/2023/beware-of-ai-snake-oil/](https://www.baldurbjarnason.com/2023/beware-of-ai-snake-oil/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 10:51:13+00:00

<p>Article URL: <a href="https://www.baldurbjarnason.com/2023/beware-of-ai-snake-oil/">https://www.baldurbjarnason.com/2023/beware-of-ai-snake-oil/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35800667">https://news.ycombinator.com/item?id=35800667</a></p>
<p>Points: 12</p>
<p># Comments: 4</p>

## It's A(door)able
 - [https://ncase.me/door/](https://ncase.me/door/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 10:32:10+00:00

<p>Article URL: <a href="https://ncase.me/door/">https://ncase.me/door/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35800492">https://news.ycombinator.com/item?id=35800492</a></p>
<p>Points: 35</p>
<p># Comments: 11</p>

## The Windscale Fire: Britain's 'Chernobyl' (2019)
 - [https://www.mirror.co.uk/news/uk-news/windscale-fire-britains-chernobyl-covered-15774677](https://www.mirror.co.uk/news/uk-news/windscale-fire-britains-chernobyl-covered-15774677)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 10:17:37+00:00

<p>Article URL: <a href="https://www.mirror.co.uk/news/uk-news/windscale-fire-britains-chernobyl-covered-15774677">https://www.mirror.co.uk/news/uk-news/windscale-fire-britains-chernobyl-covered-15774677</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35800376">https://news.ycombinator.com/item?id=35800376</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## MSFT is forcing Outlook and Teams to open links in Edge and IT admins are angry
 - [https://www.theverge.com/2023/5/3/23709297/microsoft-edge-force-outlook-teams-web-links-open](https://www.theverge.com/2023/5/3/23709297/microsoft-edge-force-outlook-teams-web-links-open)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 09:47:15+00:00

<p>Article URL: <a href="https://www.theverge.com/2023/5/3/23709297/microsoft-edge-force-outlook-teams-web-links-open">https://www.theverge.com/2023/5/3/23709297/microsoft-edge-force-outlook-teams-web-links-open</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35800158">https://news.ycombinator.com/item?id=35800158</a></p>
<p>Points: 34</p>
<p># Comments: 14</p>

## A Programmer's Introduction to Mathematics
 - [https://pimbook.org](https://pimbook.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 09:45:09+00:00

<p>Article URL: <a href="https://pimbook.org">https://pimbook.org</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35800136">https://news.ycombinator.com/item?id=35800136</a></p>
<p>Points: 23</p>
<p># Comments: 0</p>

## Arc Will Change the Way You Work on the Web
 - [https://tidbits.com/2023/05/01/arc-will-change-the-way-you-work-on-the-web/](https://tidbits.com/2023/05/01/arc-will-change-the-way-you-work-on-the-web/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 09:35:58+00:00

<p>Article URL: <a href="https://tidbits.com/2023/05/01/arc-will-change-the-way-you-work-on-the-web/">https://tidbits.com/2023/05/01/arc-will-change-the-way-you-work-on-the-web/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35800072">https://news.ycombinator.com/item?id=35800072</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## A professor found her name on an article she didn’t write. Then it got worse
 - [https://retractionwatch.com/2023/04/18/a-professor-found-her-name-on-an-article-she-didnt-write-then-it-got-worse/](https://retractionwatch.com/2023/04/18/a-professor-found-her-name-on-an-article-she-didnt-write-then-it-got-worse/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 08:45:42+00:00

<p>Article URL: <a href="https://retractionwatch.com/2023/04/18/a-professor-found-her-name-on-an-article-she-didnt-write-then-it-got-worse/">https://retractionwatch.com/2023/04/18/a-professor-found-her-name-on-an-article-she-didnt-write-then-it-got-worse/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35799691">https://news.ycombinator.com/item?id=35799691</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## UK Campaigning to replace the Monarchy with an elected head of state
 - [https://twitter.com/RepublicStaff](https://twitter.com/RepublicStaff)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 08:31:40+00:00

<p>Article URL: <a href="https://twitter.com/RepublicStaff">https://twitter.com/RepublicStaff</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35799609">https://news.ycombinator.com/item?id=35799609</a></p>
<p>Points: 7</p>
<p># Comments: 9</p>

## Ask HN: Why are there no 5G USB-C dongles for laptops?
 - [https://news.ycombinator.com/item?id=35799605](https://news.ycombinator.com/item?id=35799605)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 08:30:47+00:00

<p>I was deciding between a Macbook Air and framework laptop. I thought one way I can justify buying a Framework over MBA(and give up stellar battery life, proper sleep/instant wakeup function etc) is if it could be had with 5G connectivity that would allow me to use the laptop even while I''m on the train without drining my phone battery for a hotspot.<p>But, to my surprise, I could not find any 5G dongles that are cheap and available to buy easily...
I found one on an Austrian website intended for IOT uses coming at a price almost as that of a laptop.https://www.fts-hennig.at/netztechnik/router/mobilfunkrouter/hocell-5g-dongle-m210.html<p>What am I missing? 
If my phone could have 5G  and even my watch could have 5G for cheap, why not a laptop?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35799605">https://news.ycombinator.com/item?id=35799605</a></p>
<p>Points: 16</p>
<p># Comments: 9</p>

## FBI Bureau Supervisor Arrested in Connection with Jan 6th Capitol Riot
 - [https://www.nbcnews.com/politics/justice-department/fbi-says-former-agent-arrested-jan-6-called-officers-nazis-rcna82567](https://www.nbcnews.com/politics/justice-department/fbi-says-former-agent-arrested-jan-6-called-officers-nazis-rcna82567)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 08:20:38+00:00

<p>Article URL: <a href="https://www.nbcnews.com/politics/justice-department/fbi-says-former-agent-arrested-jan-6-called-officers-nazis-rcna82567">https://www.nbcnews.com/politics/justice-department/fbi-says-former-agent-arrested-jan-6-called-officers-nazis-rcna82567</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35799545">https://news.ycombinator.com/item?id=35799545</a></p>
<p>Points: 16</p>
<p># Comments: 3</p>

## “All Tomorrow’s Parties”: AI Synthesis – The End of Copyright as We Knew It
 - [https://www.heise.de/meinung/All-Tomorrow-s-Parties-AI-Synthesis-The-End-of-Copyright-as-We-Knew-It-8985282.html](https://www.heise.de/meinung/All-Tomorrow-s-Parties-AI-Synthesis-The-End-of-Copyright-as-We-Knew-It-8985282.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 07:13:46+00:00

<p>Article URL: <a href="https://www.heise.de/meinung/All-Tomorrow-s-Parties-AI-Synthesis-The-End-of-Copyright-as-We-Knew-It-8985282.html">https://www.heise.de/meinung/All-Tomorrow-s-Parties-AI-Synthesis-The-End-of-Copyright-as-We-Knew-It-8985282.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35799116">https://news.ycombinator.com/item?id=35799116</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Rules of Thumb for Software Development Estimations
 - [https://vadimkravcenko.com/shorts/project-estimates/](https://vadimkravcenko.com/shorts/project-estimates/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 06:59:44+00:00

<p>Article URL: <a href="https://vadimkravcenko.com/shorts/project-estimates/">https://vadimkravcenko.com/shorts/project-estimates/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35799013">https://news.ycombinator.com/item?id=35799013</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## OpenLLaMA: An Open Reproduction of LLaMA
 - [https://github.com/openlm-research/open_llama](https://github.com/openlm-research/open_llama)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 06:43:41+00:00

<p>Article URL: <a href="https://github.com/openlm-research/open_llama">https://github.com/openlm-research/open_llama</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35798888">https://news.ycombinator.com/item?id=35798888</a></p>
<p>Points: 19</p>
<p># Comments: 2</p>

## Americans Gaining Most Weight in Their 20s and 30s: What They Can Do
 - [https://www.healthline.com/health-news/americans-gaining-most-weight-in-their-20s-and-30s-what-they-can-do](https://www.healthline.com/health-news/americans-gaining-most-weight-in-their-20s-and-30s-what-they-can-do)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 06:43:03+00:00

<p>Article URL: <a href="https://www.healthline.com/health-news/americans-gaining-most-weight-in-their-20s-and-30s-what-they-can-do">https://www.healthline.com/health-news/americans-gaining-most-weight-in-their-20s-and-30s-what-they-can-do</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35798883">https://news.ycombinator.com/item?id=35798883</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Inflection AI First Release – Pi
 - [https://heypi.com/talk](https://heypi.com/talk)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 06:27:03+00:00

<p>Article URL: <a href="https://heypi.com/talk">https://heypi.com/talk</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35798744">https://news.ycombinator.com/item?id=35798744</a></p>
<p>Points: 3</p>
<p># Comments: 2</p>

## Feynman’s Maze-Running Story
 - [https://gwern.net/maze](https://gwern.net/maze)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 05:05:19+00:00

<p>Article URL: <a href="https://gwern.net/maze">https://gwern.net/maze</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35798239">https://news.ycombinator.com/item?id=35798239</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## The Second Freeway Revolt (2013)
 - [https://www.foundsf.org/index.php?title=Second_Freeway_Revolt](https://www.foundsf.org/index.php?title=Second_Freeway_Revolt)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 04:19:11+00:00

<p>Article URL: <a href="https://www.foundsf.org/index.php?title=Second_Freeway_Revolt">https://www.foundsf.org/index.php?title=Second_Freeway_Revolt</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35797954">https://news.ycombinator.com/item?id=35797954</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## AI-generated beer commercial contains joyful monstrosities, goes viral
 - [https://arstechnica.com/information-technology/2023/05/ai-generated-beer-commercial-contains-joyful-monstrosities-goes-viral/](https://arstechnica.com/information-technology/2023/05/ai-generated-beer-commercial-contains-joyful-monstrosities-goes-viral/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 02:58:55+00:00

<p>Article URL: <a href="https://arstechnica.com/information-technology/2023/05/ai-generated-beer-commercial-contains-joyful-monstrosities-goes-viral/">https://arstechnica.com/information-technology/2023/05/ai-generated-beer-commercial-contains-joyful-monstrosities-goes-viral/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35797258">https://news.ycombinator.com/item?id=35797258</a></p>
<p>Points: 27</p>
<p># Comments: 4</p>

## RIP HTTP
 - [http://http.rip/](http://http.rip/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 02:16:56+00:00

<p>Article URL: <a href="http://http.rip/">http://http.rip/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35796931">https://news.ycombinator.com/item?id=35796931</a></p>
<p>Points: 11</p>
<p># Comments: 5</p>

## De-dollarization is happening at a ‘stunning’ pace
 - [https://www.bloomberg.com/news/articles/2023-04-18/de-dollarization-is-happening-at-a-stunning-pace-jen-says](https://www.bloomberg.com/news/articles/2023-04-18/de-dollarization-is-happening-at-a-stunning-pace-jen-says)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 02:15:12+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-04-18/de-dollarization-is-happening-at-a-stunning-pace-jen-says">https://www.bloomberg.com/news/articles/2023-04-18/de-dollarization-is-happening-at-a-stunning-pace-jen-says</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35796915">https://news.ycombinator.com/item?id=35796915</a></p>
<p>Points: 63</p>
<p># Comments: 82</p>

## Truth About the War
 - [https://www.hs.fi/ulkomaat/art-2000009555855.html](https://www.hs.fi/ulkomaat/art-2000009555855.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 01:42:31+00:00

<p>Article URL: <a href="https://www.hs.fi/ulkomaat/art-2000009555855.html">https://www.hs.fi/ulkomaat/art-2000009555855.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35796671">https://news.ycombinator.com/item?id=35796671</a></p>
<p>Points: 18</p>
<p># Comments: 2</p>

## Bank Failures Visualized
 - [https://observablehq.com/@mbostock/bank-failures](https://observablehq.com/@mbostock/bank-failures)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-05-03 00:03:26+00:00

<p>Article URL: <a href="https://observablehq.com/@mbostock/bank-failures">https://observablehq.com/@mbostock/bank-failures</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35795975">https://news.ycombinator.com/item?id=35795975</a></p>
<p>Points: 20</p>
<p># Comments: 4</p>

