# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Czy to ostatnia podwyżka w cyklu? Stopy procentowe w USA najwyższe od 2007 roku
 - [https://www.bankier.pl/wiadomosc/Fed-podnosi-stopy-procentowe-maj-2023-8534015.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fed-podnosi-stopy-procentowe-maj-2023-8534015.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 19:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/71c0716ed918bf-948-568-5-25-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Federalny Komitet Otwartego Rynku
zdecydował się podnieść przedział stopy funduszy federalnych o kolejne 25 pb. - do najwyższego poziomu od 2007 roku.</p>

## 100 mln euro od KE dla rolników z  Bułgarii, Węgier, Polski, Rumunii i Słowacji
 - [https://www.bankier.pl/wiadomosc/100-mln-euro-od-KE-dla-rolnikow-z-Bulgarii-Wegier-Polski-Rumunii-i-Slowacji-8534009.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/100-mln-euro-od-KE-dla-rolnikow-z-Bulgarii-Wegier-Polski-Rumunii-i-Slowacji-8534009.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 17:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/65b4593d506121-948-568-0-224-3736-2241.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W następstwie porozumienia osiągniętego 28 kwietnia z Bułgarią, Węgrami, Polską, Rumunią i Słowacją Komisja Europejska przedstawiła w środę propozycję wsparcia o wartości 100 mln euro dla rolników z tych krajów.</p>

## Ziobro: Powołujemy Suwerenną Polskę. Suwerenność jest zagrożona najbardziej od czasu upadku komunizmu
 - [https://www.bankier.pl/wiadomosc/Ziobro-Powolujemy-Suwerenna-Polske-Suwerennosc-jest-zagrozona-najbardziej-od-czasu-upadku-komunizmu-8533957.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ziobro-Powolujemy-Suwerenna-Polske-Suwerennosc-jest-zagrozona-najbardziej-od-czasu-upadku-komunizmu-8533957.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 14:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/2/830a3abd326b84-948-568-0-140-3291-1975.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Suwerenność Polski jest zagrożona najbardziej od czasu upadku komunizmu; nieprzypadkowo spotykamy się w rocznicę uchwalenia Konstytucji 3 maja - powiedział w środę szef Solidarnej Polski, minister sprawiedliwości Zbigniew Ziobro. Na konwencji partii ogłoszono zmianę nazwy partii na "Suwerenna Polska".</p>

## Start-upy aktywnie włączają się w walkę ze zmianami klimatycznymi. Branża climate tech rośnie w siłę
 - [https://www.bankier.pl/wiadomosc/Start-upy-aktywnie-wlaczaja-sie-w-walke-ze-zmianami-klimatycznymi-Branza-climate-tech-rosnie-w-sile-8528066.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Start-upy-aktywnie-wlaczaja-sie-w-walke-ze-zmianami-klimatycznymi-Branza-climate-tech-rosnie-w-sile-8528066.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/67b0d706de4ce6-948-568-0-57-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Polsce i całej Europie Środkowo-Wschodniej pojawia się coraz więcej start-upów z branży climate tech, które wspierają walkę ze zmianami klimatycznymi. Zajmują się m.in. alternatywnymi źródłami...</p>

## Rosyjskie okręty "widma" operowały na Bałtyku przed wysadzeniem NS i NS2
 - [https://www.bankier.pl/wiadomosc/Rosyjskie-okrety-widma-operowaly-na-Baltyku-przed-wysadzeniem-NS-i-NS2-8533945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosyjskie-okrety-widma-operowaly-na-Baltyku-przed-wysadzeniem-NS-i-NS2-8533945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 13:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/613246a658b541-948-567-0-40-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czy to Rosjanie stoją za wybuchami gazociągów Nord Stream 1 i 2? Trzy rosyjskie okręty wojenne "widma" operowały na Bałtyku w pobliżu miejsca sabotażu przez kilka godzin, a w jednym przypadku przez prawie dobę - ujawniają w środę nadawcy publiczni krajów nordyckich.</p>

## Bycie eko nie musi być kosztowne. Walka o klimat może iść w parze z zyskami i rozwojem
 - [https://www.bankier.pl/wiadomosc/Bycie-eko-nie-musi-byc-kosztowne-Walka-o-klimat-moze-isc-w-parze-z-zyskami-i-rozwojem-8526141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bycie-eko-nie-musi-byc-kosztowne-Walka-o-klimat-moze-isc-w-parze-z-zyskami-i-rozwojem-8526141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/594a9883a3004c-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />- Wciąż jeszcze pokutuje przestarzała narracja mówiąca o tym, że ochrona środowiska jest kosztowna, nudna, wymaga poświęceń i szkodzi rozwojowi gospodarczemu. Takie podejście sprawia, że mamy do czynienia...</p>

## Były szef Audi chce przyznać się do winy
 - [https://www.bankier.pl/wiadomosc/Afera-Dieselgate-Byly-szef-Audi-chce-przyznac-sie-do-winy-8533888.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Afera-Dieselgate-Byly-szef-Audi-chce-przyznac-sie-do-winy-8533888.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 11:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/8d3592e57fa757-945-560-0-22-1788-1072.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ekologia jedynie na papierze - Dieselgate to największa afera w motoryzacji w ostatnich latach. Były prezes niemieckiego producenta samochodów Audi, Rupert Stadler, chce przyznać się do winy w procesie o oszustwo związane z podawaniem emisji spalin i złożyć obszerne zeznania. Jeśli przyzna się do winy i zapłaci karę finansową oraz otrzyma wyrok w zawieszeniu. Stadler chce złożyć zeznanie za dwa tygodnie – informuje w środę portal dziennika „Welt”.</p>

## Dziennikarz to bezpieczny zawód? Na pewno nie w Ameryce Łacińskiej
 - [https://www.bankier.pl/wiadomosc/Dziennikarz-to-bezpieczny-zawod-Na-pewno-nie-w-Ameryce-Lacinskiej-8531501.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dziennikarz-to-bezpieczny-zawod-Na-pewno-nie-w-Ameryce-Lacinskiej-8531501.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/0/1f32cb58011341-948-568-61-0-1767-1060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dziennikarstwo stało się w Ameryce Łacińskiej jednym z zawodów największego ryzyka,  a demokracja rozumiana jako wolność słowa „przeżywa jeden z najgorszych momentów” – bije na alarm w ogłoszonym w czwartek w Miami dokumencie Międzyamerykańskie Stowarzyszenie Prasy SIP.</p>

## Strzelanina w szkole w centrum Belgradu. Są ofiary śmiertelne
 - [https://www.bankier.pl/wiadomosc/Strzelanina-w-szkole-w-centrum-Belgradu-Sa-ofiary-smiertelne-8533883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Strzelanina-w-szkole-w-centrum-Belgradu-Sa-ofiary-smiertelne-8533883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 10:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/d/c058fb529378c9-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę rano w szkole w centrum Belgradu 14-latek otworzył ogień do uczniów i pracowników szkoły podstawowej. W wyniku strzelaniny zginęło ośmioro dzieci i woźny; nauczycielka i sześcioro dzieci trafiło do szpitala - poinformowała agencja Tanjug, powołując się na informacje ministerstwa spraw wewnętrznych Serbii.</p>

## Ceny gazu w Europie spadają. Jest najtaniej od 21 miesięcy
 - [https://www.bankier.pl/wiadomosc/Ceny-gazu-w-Europie-spadaja-Jest-najtaniej-od-21-miesiecy-8533853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-gazu-w-Europie-spadaja-Jest-najtaniej-od-21-miesiecy-8533853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 09:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/e707ac8815541b-948-568-0-1286-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny gazu w Europie kontynuują spadki. Benchmarkowe kontrakty na gaz w Amsterdamie (ICE Entawex Dutch TTF) zniżkuje o 1,1 proc., a cena paliwa wynosi 37,10 euro za MWh - informują maklerzy. Tak tanio nie było od 21 miesięcy.</p>

## Branża turystyczna na wschodzie Polski boryka się z problemami. Podróżujących odstrasza wojna w Ukrainie
 - [https://www.bankier.pl/wiadomosc/Branza-turystyczna-na-wschodzie-Polski-boryka-sie-z-problemami-Podrozujacych-odstrasza-wojna-w-Ukrainie-8528859.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branza-turystyczna-na-wschodzie-Polski-boryka-sie-z-problemami-Podrozujacych-odstrasza-wojna-w-Ukrainie-8528859.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/51dcbcae9575b5-948-568-180-0-2416-1450.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po dwóch latach covidowych obostrzeń wojna w Ukrainie, problemy związane z inflacją oraz drastycznymi podwyżkami cen prądu i ogrzewania okazały się kolejnym ciosem dla branży turystycznej. Mimo ubiegłorocznego...</p>

## Stare komórki warte fortunę. „Przeszukaj szuflady, może jesteś bogaty”
 - [https://www.bankier.pl/wiadomosc/Stare-komorki-warte-fortune-Przeszukaj-szuflady-moze-jestes-bogaty-8533617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stare-komorki-warte-fortune-Przeszukaj-szuflady-moze-jestes-bogaty-8533617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/2/9adbfa57eeff5d-948-568-0-157-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przeszukaj swoje szuflady, albowiem możesz być bogaty, nawet o tym nie wiedząc - napisał belgijski dziennik „Le Soir”. Wszystko dlatego, że niektóre stare telefony komórkowe stały się przedmiotami kolekcjonerskimi i trzeba za nie zapłacić nawet... 40 tys. euro.</p>

## Największa elektrownia słoneczna w Europie otwarta. Przy okazji Turcy informują o odkryciu nowych złóż ropy
 - [https://www.bankier.pl/wiadomosc/Najwieksza-elektrownia-sloneczna-w-Europie-otwarta-Przy-okazji-Turcy-informuja-o-odkryciu-nowych-zloz-ropy-8533833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najwieksza-elektrownia-sloneczna-w-Europie-otwarta-Przy-okazji-Turcy-informuja-o-odkryciu-nowych-zloz-ropy-8533833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 08:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/0be015866fedae-948-568-0-93-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W centralnej Turcji otwarto największą w Europie elektrownie słoneczną. Przy okazji uroczystości prezydent Erdogan ogłosił również odkrycie nowego złoża ropy, które będzie w stanie zaspokoić 10 proc. dziennego zapotrzebowania kraju na ten surowiec - poinformowała agencja Anatolia.</p>

## "Panie, aż żal nie kupić, stan igła", czyli jak nie wpaść w sidła nieuczciwego sprzedawcy samochodu
 - [https://www.bankier.pl/wiadomosc/Panie-az-zal-nie-kupic-stan-igla-czyli-jak-nie-wpasc-w-sidla-nieuczciwego-sprzedawcy-samochodu-8530577.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Panie-az-zal-nie-kupic-stan-igla-czyli-jak-nie-wpasc-w-sidla-nieuczciwego-sprzedawcy-samochodu-8530577.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/d77a996d773685-948-568-0-260-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kupno używanego samochodu może być stresującym procesem, szczególnie w przypadku osób, które nie bardzo znają się na motoryzacji. Niewiedzę kupujących chętnie wykorzystują nieuczciwi sprzedawcy, którzy chcą się pozbyć wadliwego pojazdu lub po prostu uzyskać dużo większy zysk ze sprzedaży. Oszustwa w branży motoryzacyjnej są powszechne, dlatego warto wiedzieć, jakie sposoby stosują naciągacze. Eksperci serwisu autobaza.pl podpowiadają, jak można się przed nimi ustrzec.</p>

## Podróż do Wielkiej Brytanii. Strajk na lotnisku Heathrow w okresie wokół koronacji Karola III, pracownicy chcą podwyżek
 - [https://www.bankier.pl/wiadomosc/Podroz-do-Wielkiej-Brytanii-Strajk-na-lotnisku-Heathrow-w-okresie-wokol-koronacji-Karola-III-pracownicy-chca-podwyzek-8526062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podroz-do-Wielkiej-Brytanii-Strajk-na-lotnisku-Heathrow-w-okresie-wokol-koronacji-Karola-III-pracownicy-chca-podwyzek-8526062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/183ebf03ee86bd-948-568-240-19-3568-2140.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z "nieuniknionymi zakłóceniami" będą musieli się liczyć podróżni przylatujący do Londynu w okresie wokół koronacji króla Karola III - ostrzegł w środę związek zawodowy Unite, zapowiadając kolejny strajk pracowników kontroli bezpieczeństwa na lotnisku Heathrow.</p>

## Polska śmietniskiem Europy? W 2022 r. z Polski wyjechało więcej odpadów niż przyjechało z zagranicy
 - [https://www.bankier.pl/wiadomosc/Polska-smietniskiem-Europy-W-2022-r-z-Polski-wyjechalo-wiecej-odpadow-niz-przyjechalo-z-zagranicy-8533801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-smietniskiem-Europy-W-2022-r-z-Polski-wyjechalo-wiecej-odpadow-niz-przyjechalo-z-zagranicy-8533801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 06:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/fe06b1c9c34087-948-568-0-110-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />2022 rok był pierwszym, kiedy więcej odpadów wyjechało z kraju niż przyjechało z zagranicy; w ub.r. do kraju wwieziono ok. 300 tys. ton odpadów przeznaczonych m.in. do odzysku - poinformowała PAP wiceszefowa Głównego Inspektoratu Ochrony Środowiska Magda Gosk. Polska nie jest śmietnikiem Europy - podkreśliła.</p>

## Prawie dzień rocznie. Tyle czasu tracimy na zmianę haseł do kont internetowych
 - [https://www.bankier.pl/wiadomosc/Prawie-dzien-rocznie-Tyle-czasu-tracimy-na-zmiane-hasel-do-kont-internetowych-8533780.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prawie-dzien-rocznie-Tyle-czasu-tracimy-na-zmiane-hasel-do-kont-internetowych-8533780.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 06:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/5680ce932d6900-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Cyfrowa rzeczywistość staje się faktem, a hasło do konta jest jej nieodłącznym elementem. Na zmianę nowych haseł przeciętny użytkownik internetu przeznacza aż 21 godzin rocznie - wynika z raportu "Cyberbezpieczeństwo Polaków".</p>

## Banki płacą za otwarcie konta firmowego. Sprawdź premie dla przedsiębiorców
 - [https://www.bankier.pl/wiadomosc/Ranking-kont-firmowych-z-premia-maj-2023-r-8533397.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kont-firmowych-z-premia-maj-2023-r-8533397.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/1/641e0fc3cffbd5-948-568-0-0-2400-1439.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Banki kuszą przedsiębiorców premiami pieniężnymi. Najwyższe bonusy sięgają 3300 zł za wykonanie określonych aktywności. W najnowszym rankingu przyjrzeliśmy się promocyjnym ofertom dla osób prowadzących własny biznes.</p>

## Jeden z liderów rynku kapitałowego o "odjeżdżających kursach" i możliwych dużych debiutach w 2023 r.
 - [https://www.bankier.pl/wiadomosc/Jeden-z-liderow-rynku-kapitalowego-o-odjezdzajacych-kursach-i-mozliwych-duzych-debiutach-w-2023-r-8531716.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jeden-z-liderow-rynku-kapitalowego-o-odjezdzajacych-kursach-i-mozliwych-duzych-debiutach-w-2023-r-8531716.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/6de236b7797142-948-568-0-1189-1333-799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ostatnim tygodniu kwietnia GPW nagrodziła liderów rynku kapitałowego podczas Podsumowania Roku Giełdowego 2022. Jednym z laureatów został Dom Maklerski Navigator za przeprowadzenie największej liczby wprowadzeń na rynek główny w 2022 r. O pierwszych oznakach odwilży na rynku ofert publicznych w nowym roku rozmawialiśmy z Dariuszem Tenderendą, członkiem zarządu Navigatora. </p>

## Przybywa promocji kredytów hipotecznych i... procentów w cennikach
 - [https://www.bankier.pl/wiadomosc/Promocje-kredytow-hipotecznych-maj-2023-8533441.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Promocje-kredytow-hipotecznych-maj-2023-8533441.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/1c8fd223dda64c-948-568-0-134-1994-1196.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po wiosennych porządkach w bankowych cennikach na scenę powracają banki, które już wcześniej promowały hipoteki. Zła wiadomość dla kredytobiorców to lekki wzrost stawek w porównaniu z poprzednim miesiącem. Wahania w górę i w dół to już norma, obserwowana przez nas od kilku miesięcy.</p>

## Równość płci. W bogatszych krajach bardziej korzystają na tym mężczyźni niż kobiety
 - [https://www.bankier.pl/wiadomosc/Rownosc-plci-W-bogatszych-krajach-bardziej-korzystaja-na-tym-mezczyzni-niz-kobiety-8521917.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rownosc-plci-W-bogatszych-krajach-bardziej-korzystaja-na-tym-mezczyzni-niz-kobiety-8521917.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/2/7f27f6f96668b7-948-568-0-260-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zwiększanie równości płci przekłada się na dłuższą oczekiwaną długość życia zarówno kobiet, jak i mężczyzn, przy czym ten wzrost jest większy w przypadku pań - zauważyli naukowcy z Imperial...</p>

## Miał zastrzelić 5 osób, w tym dziecko. Został aresztowany w Teksasie
 - [https://www.bankier.pl/wiadomosc/Kolejna-strzelalnina-w-USA-Podejrzany-o-zastrzelenie-5-osob-aresztowany-8533777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejna-strzelalnina-w-USA-Podejrzany-o-zastrzelenie-5-osob-aresztowany-8533777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 04:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/4/3f7421565ef65c-945-560-3-33-1197-718.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Organy ścigania zatrzymały we wtorek 38-letniego Francisco Oropesę po trwającej od piątku obławie z udziałem ponad 250 funkcjonariuszy, który jest oskarżony o zabicie 5 sąsiadów, w tym 8-letniego chłopca. Nagroda za informacje prowadzące do jego aresztowania została wyznaczona na 80 tys. dolarów.</p>

## Zawieszenie broni w Strefie Gazy. Izrael i Palestyńczycy doszli do porozumienia
 - [https://www.bankier.pl/wiadomosc/Zawieszenie-broni-w-Strefie-Gazy-Izrael-i-Palestynczycy-doszli-do-porozumienia-8533773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zawieszenie-broni-w-Strefie-Gazy-Izrael-i-Palestynczycy-doszli-do-porozumienia-8533773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 03:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/24bb98bb4f5b53-945-560-0-187-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izrael i palestyńskie grupy zbrojne w Strefie Gazy zgodziły się na zawieszenie broni w środę we wczesnych godzinach porannych - przekazał Reuters, cytując władze palestyńskie. W negocjacjach uczestniczył Egipt, Katar i ONZ.</p>

## Trudne relacje Serbii i Kosowa. Brak porozumienia i porozumienie
 - [https://www.bankier.pl/wiadomosc/Trudne-relacje-Serbii-i-Kosowa-Brak-porozumienia-i-porozumienie-8533771.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trudne-relacje-Serbii-i-Kosowa-Brak-porozumienia-i-porozumienie-8533771.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-05-03 01:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/0/153dde9f21a139-945-567-11-89-1488-893.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przywódcy Kosowa i Serbii nie doszli we wtorek w Brukseli do porozumienia w sprawie redukcji napięć na terenach zamieszkałych przez Serbów w północnym Kosowie - powiedział późnym wieczorem po wielogodzinnych negocjacjach szef polityki zagranicznej UE Josep Borrell. Główny dyplomata unijny ostrzegł przed eskalacją konfliktu, która może podważyć wspierane przez UE porozumienie w sprawie normalizacji więzi między zwaśnionymi krajami.</p>

