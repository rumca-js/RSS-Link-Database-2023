# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Can’t wait for Hulu’s cult thriller The Clearing? Here are 4 TV shows just like it
 - [https://www.techradar.com/news/cant-wait-for-hulus-cult-thriller-the-clearing-here-are-4-tv-shows-just-like-it](https://www.techradar.com/news/cant-wait-for-hulus-cult-thriller-the-clearing-here-are-4-tv-shows-just-like-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 18:30:00+00:00

Hulu just dropped the official trailer for a new TV show called The Clearing. While we wait for it to premiere, here are four more cult thrillers to watch.

## Hackers target years-old surveillance camera security flaw
 - [https://www.techradar.com/news/hackers-target-years-old-surveillance-camera-security-flaw](https://www.techradar.com/news/hackers-target-years-old-surveillance-camera-security-flaw)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 18:11:04+00:00

There had been more than 50,000 breach attempts on TBK DVRs already.

## AMD confirms normal-priced Radeon 7600 GPU for normal people at last
 - [https://www.techradar.com/news/amd-confirms-normal-priced-radeon-7600-gpu-for-normal-people-at-last](https://www.techradar.com/news/amd-confirms-normal-priced-radeon-7600-gpu-for-normal-people-at-last)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 17:55:54+00:00

AMD has officially confirmed that it will be releasing more Radeon RX 7000-series GPUs, which will most likely include mid-range 7700 and 7600 options.

## Canon wants to bring down the cost of printing with affordable ink tank printers but isn’t discounting laser printers yet
 - [https://www.techradar.com/news/canon-wants-to-bring-down-the-cost-of-printing-with-affordable-ink-tank-printers-but-isnt-discounting-laser-printers-yet](https://www.techradar.com/news/canon-wants-to-bring-down-the-cost-of-printing-with-affordable-ink-tank-printers-but-isnt-discounting-laser-printers-yet)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 17:07:02+00:00

Six new printers from one of the market leaders target SMB, work-from-home employees.

## TP-Link routers targeted by Mirai botnet once again, US government warns
 - [https://www.techradar.com/news/tp-link-routers-targeted-by-mirai-botnet-once-again-us-government-warns](https://www.techradar.com/news/tp-link-routers-targeted-by-mirai-botnet-once-again-us-government-warns)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 16:52:08+00:00

CISA issues a warning to US government agencies, urging them to patch immediately.

## ChatGPT could be worse than cryptocurrency when it comes to scams
 - [https://www.techradar.com/news/chatgpt-could-be-worse-than-cryptocurrency-when-it-comes-to-scams](https://www.techradar.com/news/chatgpt-could-be-worse-than-cryptocurrency-when-it-comes-to-scams)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 16:29:45+00:00

Alarm is growing over the rise in ChatGPT scams, with Meta warning it could be worse than what we saw with cryptocurrency.

## Dune Part 2 trailer teases thrills, sci-fi spills, and Timothée Chalamet riding a sandworm
 - [https://www.techradar.com/news/dune-part-2-trailer-teases-thrills-sci-fi-spills-and-timothee-chalamet-riding-a-sandworm](https://www.techradar.com/news/dune-part-2-trailer-teases-thrills-sci-fi-spills-and-timothee-chalamet-riding-a-sandworm)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 16:16:12+00:00

The first trailer for Dune: Part Two has debuted online – and it looks and sounds as epic as we expected it to.

## Motorola Razr 40 Ultra specs leak reveals Snapdragon 8 Plus Gen 1 and more
 - [https://www.techradar.com/news/motorola-razr-40-ultra-specs-leak-reveals-snapdragon-8-plus-gen-1-and-more](https://www.techradar.com/news/motorola-razr-40-ultra-specs-leak-reveals-snapdragon-8-plus-gen-1-and-more)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 16:07:03+00:00

A new Motorola Razr 40 Ultra specs leak points to an older processor, but it’s still plenty powerful.

## ChatGPT gets a new feature – but would you trust AI to help you buy a house?
 - [https://www.techradar.com/news/chatgpt-gets-a-new-feature-but-would-you-trust-ai-to-help-you-buy-a-house](https://www.techradar.com/news/chatgpt-gets-a-new-feature-but-would-you-trust-ai-to-help-you-buy-a-house)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 15:46:05+00:00

A three-bedroom house? In an up-and-coming area? With an open house this weekend? Step this way…

## Squarespace wants to help you build a website much quicker than before
 - [https://www.techradar.com/news/squarespace-update-helps-businesses-that-struggle-with-website-designing](https://www.techradar.com/news/squarespace-update-helps-businesses-that-struggle-with-website-designing)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 15:42:27+00:00

Squarespace Blueprint website design system is now included in its site building tool.

## Porn VPN searches soar in Utah amid age verification bill
 - [https://www.techradar.com/news/porn-vpn-searches-soar-in-utah-amid-age-verification-bill](https://www.techradar.com/news/porn-vpn-searches-soar-in-utah-amid-age-verification-bill)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 15:34:03+00:00

The move comes as Utah becomes the last US state to introduce mandatory age verification to access porn sites, causing a spike of interest in VPN services.

## Google used AI to make a puzzle game that rivals Wordle
 - [https://www.techradar.com/news/google-used-ai-to-make-a-puzzle-game-that-rivals-wordle](https://www.techradar.com/news/google-used-ai-to-make-a-puzzle-game-that-rivals-wordle)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 15:32:58+00:00

Google has used AI to help create four games including XYZ Toy, a puzzle game that rivals Wordle.

## World Press Freedom Day: organizations join forces to save encryption
 - [https://www.techradar.com/news/world-press-freedom-day-organizations-join-forces-to-save-encryption](https://www.techradar.com/news/world-press-freedom-day-organizations-join-forces-to-save-encryption)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 15:08:56+00:00

With encrypted communication increasingly under siege across democracies, the coalition seeks to protect privacy to promote press freedom.

## Some of the top AMD chips are suffering a serious security flaw
 - [https://www.techradar.com/news/some-of-the-top-amd-chips-are-suffering-a-serious-security-flaw](https://www.techradar.com/news/some-of-the-top-amd-chips-are-suffering-a-serious-security-flaw)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 15:08:50+00:00

A novel flaw can be used to read sensitive content on AMD Zen chips, researchers warn.

## Here's the real reason James Gunn put Zune in Guardians of the Galaxy Vol. 3
 - [https://www.techradar.com/news/heres-the-real-reason-james-gunn-put-zune-in-guardians-of-the-galaxy-vol-3](https://www.techradar.com/news/heres-the-real-reason-james-gunn-put-zune-in-guardians-of-the-galaxy-vol-3)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 14:39:29+00:00

Guardians of the Galaxy Vol. 3 thrusts the unloved Zune back into the spotlight, and I asked its director why he chose it.

## FBI, Europol make hundreds of arrests in dark web shutdown
 - [https://www.techradar.com/news/fbi-europol-make-hundreds-of-arrests-in-dark-web-shutdown](https://www.techradar.com/news/fbi-europol-make-hundreds-of-arrests-in-dark-web-shutdown)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 14:28:08+00:00

SpecTor shutdown sees almost 300 people arrested, and millions of dollars taken.

## AMD promises its new laptop chips will crush the Apple M2 - and it’s got reciepts
 - [https://www.techradar.com/news/amd-promises-its-new-laptop-chips-will-crush-the-apple-m2-and-its-got-reciepts](https://www.techradar.com/news/amd-promises-its-new-laptop-chips-will-crush-the-apple-m2-and-its-got-reciepts)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 14:02:46+00:00

AMD’s new ‘Phoenix’ chips could change the gaming laptop landscape forever, with better performance and battery life.

## Google now lets you log in without a password
 - [https://www.techradar.com/news/google-now-lets-you-log-in-without-a-password](https://www.techradar.com/news/google-now-lets-you-log-in-without-a-password)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 13:34:06+00:00

Google becomes the first big tech player to allow its users to login to their accounts without a password.

## Xbox just revealed a new way to get 2 weeks of free Game Pass Ultimate
 - [https://www.techradar.com/news/xbox-just-revealed-a-new-way-to-get-2-weeks-of-free-game-pass-ultimate](https://www.techradar.com/news/xbox-just-revealed-a-new-way-to-get-2-weeks-of-free-game-pass-ultimate)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 13:27:24+00:00

Xbox Game Pass Ultimate and PC subscribers now have a chance to get 2 weeks for free if they’re referred by a friend.

## 1Password reassures users following password change notification scare
 - [https://www.techradar.com/news/1password-reassures-users-following-password-change-notification-scare](https://www.techradar.com/news/1password-reassures-users-following-password-change-notification-scare)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 13:02:34+00:00

1Password has clarified that it has not suffered a security breach.

## US and EU warn Malaysia on Huawei 5G deal
 - [https://www.techradar.com/news/us-and-eu-warn-malaysia-on-huawei-5g-deal](https://www.techradar.com/news/us-and-eu-warn-malaysia-on-huawei-5g-deal)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 13:01:08+00:00

Malaysia could allow Huawei to build its 5G network and Western leaders are worried.

## After hearing Moon's new amplification system, most consumer hi-fi is dead to me
 - [https://www.techradar.com/news/after-hearing-moons-new-amplification-system-most-consumer-hi-fi-is-dead-to-me](https://www.techradar.com/news/after-hearing-moons-new-amplification-system-most-consumer-hi-fi-is-dead-to-me)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 13:01:00+00:00

An evening spent with Moon's new North 'mid range' amplification system and Audiovector R6 Arreté speakers has ruined most other home systems for me.

## Garmin could soon challenge the Apple Watch Ultra with the Epix 2 Pro
 - [https://www.techradar.com/news/garmin-could-soon-challenge-the-apple-watch-ultra-with-the-epix-2-pro](https://www.techradar.com/news/garmin-could-soon-challenge-the-apple-watch-ultra-with-the-epix-2-pro)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 12:58:46+00:00

One of Garmin's most powerful sports watches, the Epix 2, could soon get an updated version, according to fresh rumors.

## Google TV gets a free update to make it faster and slicker to use
 - [https://www.techradar.com/news/google-tv-gets-a-free-update-to-make-it-faster-and-slicker-to-use](https://www.techradar.com/news/google-tv-gets-a-free-update-to-make-it-faster-and-slicker-to-use)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 12:58:33+00:00

The Google TV platform is getting a free update, speeding up its response times, and reducing the size of apps by ‘roughly 25%’.

## Chrome is removing this useful security warning tool - so be on your guard
 - [https://www.techradar.com/news/chrome-is-removing-this-useful-security-warning-tool-so-be-on-your-guard](https://www.techradar.com/news/chrome-is-removing-this-useful-security-warning-tool-so-be-on-your-guard)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 12:39:44+00:00

The lock icon has been a part of Chrome for years, warning users about possible security risks.

## Samsung Galaxy S23 FE could get a 50MP main camera – but you might have to wait for it
 - [https://www.techradar.com/news/samsung-galaxy-s23-fe-could-get-a-50mp-main-camera-but-you-might-have-to-wait-for-it](https://www.techradar.com/news/samsung-galaxy-s23-fe-could-get-a-50mp-main-camera-but-you-might-have-to-wait-for-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 12:01:10+00:00

The Samsung Galaxy S23 FE is rumored to still be in the works – and it could pack a 50MP main camera.

## Titanfall director is “finding the fun in something new” for Respawn
 - [https://www.techradar.com/news/titanfall-director-is-finding-the-fun-in-something-new-for-respawn](https://www.techradar.com/news/titanfall-director-is-finding-the-fun-in-something-new-for-respawn)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 11:13:01+00:00

Titanfall director Steve Fukuda is working with Respawn to lead a small team in conjuring up a new IP.

## The Samsung Galaxy Watch series just got better for music fans, thanks to Bixby
 - [https://www.techradar.com/news/the-samsung-galaxy-watch-series-just-got-better-for-music-fans-thanks-to-bixby](https://www.techradar.com/news/the-samsung-galaxy-watch-series-just-got-better-for-music-fans-thanks-to-bixby)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 11:05:36+00:00

Bixby on the Samsung Galaxy Watch 5 and Watch 4 has had a substantial update, with music recognition at its heart.

## LinkedIn wants to use AI to help you nail that job application
 - [https://www.techradar.com/news/linkedin-wants-to-use-ai-to-help-you-nail-that-job-application](https://www.techradar.com/news/linkedin-wants-to-use-ai-to-help-you-nail-that-job-application)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 11:00:41+00:00

Generative AI can now message hiring staff and managers for you, but it hasn’t been met without criticism.

## Microsoft is testing a private business version of ChatGPT to prevent any data leaks
 - [https://www.techradar.com/news/microsoft-is-testing-a-private-business-version-of-chatgpt-to-prevent-any-data-leaks](https://www.techradar.com/news/microsoft-is-testing-a-private-business-version-of-chatgpt-to-prevent-any-data-leaks)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 10:54:38+00:00

Would you be happy if your bank used ChatGPT with your sensitive information? Microsoft thinks it has the answer.

## Two more classic Apple products are heading for the graveyard
 - [https://www.techradar.com/news/two-more-classic-apple-products-are-heading-for-the-graveyard](https://www.techradar.com/news/two-more-classic-apple-products-are-heading-for-the-graveyard)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 10:47:50+00:00

Apple is reportedly adding the Thunderbolt Display and original iPad Air to its official obsolete products list.

## Box thinks AI is the key to making you more productive
 - [https://www.techradar.com/news/box-thinks-ai-is-the-key-to-making-you-more-productive](https://www.techradar.com/news/box-thinks-ai-is-the-key-to-making-you-more-productive)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 10:40:18+00:00

Box AI will integrate ChatGPT into its cloud storage platform to digest existing work and create new content.

## The RTX 4090 is finally getting cheaper – but there’s bad news for some
 - [https://www.techradar.com/news/the-rtx-4090-is-finally-getting-cheaper-but-theres-bad-news-for-some](https://www.techradar.com/news/the-rtx-4090-is-finally-getting-cheaper-but-theres-bad-news-for-some)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 10:36:03+00:00

If you’ve had your eye on Nvidia’s flagship GPU, now might be the time to snap one up – but only if you need the power it offers.

## Netflix users cancel subscriptions amid growing feud over writers' strike
 - [https://www.techradar.com/news/netflix-users-cancel-subscriptions-amid-growing-feud-over-writers-strike](https://www.techradar.com/news/netflix-users-cancel-subscriptions-amid-growing-feud-over-writers-strike)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 10:03:10+00:00

TV and movie writers have called on Netflix users to leave the service over its role in the ongoing writers' strike.

## Nokia XR21 could have been the perfect rugged smartphone, if not for these three drawbacks
 - [https://www.techradar.com/news/nokia-xr21-could-be-been-the-perfect-rugged-smartphone-if-not-for-these-two-drawbacks](https://www.techradar.com/news/nokia-xr21-could-be-been-the-perfect-rugged-smartphone-if-not-for-these-two-drawbacks)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 10:00:06+00:00

A high launch price, lack of wireless charging and a USB 2.0 port left us perplexed.

## Status Between 3ANC earbuds claim noise cancellation to put AirPods Pro to shame
 - [https://www.techradar.com/news/status-between-3anc-earbuds-claim-noise-cancellation-to-put-airpods-pro-to-shame](https://www.techradar.com/news/status-between-3anc-earbuds-claim-noise-cancellation-to-put-airpods-pro-to-shame)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 09:59:01+00:00

Status Between 3ANC earbuds: confusing name, massive triple driver ANC claims…

## The Samsung Galaxy S24 might be very hard to tell apart from the Galaxy S23
 - [https://www.techradar.com/news/the-samsung-galaxy-s24-might-be-very-hard-to-tell-apart-from-the-galaxy-s23](https://www.techradar.com/news/the-samsung-galaxy-s24-might-be-very-hard-to-tell-apart-from-the-galaxy-s23)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 09:23:56+00:00

The Samsung Galaxy S24 and Galaxy S24 Plus could have identical designs to their predecessors.

## Businesses are more prepared for cyberattacks than ever - but they still aren't confident
 - [https://www.techradar.com/news/businesses-are-more-prepared-for-cyberattacks-than-ever-but-they-still-arent-confident](https://www.techradar.com/news/businesses-are-more-prepared-for-cyberattacks-than-ever-but-they-still-arent-confident)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 09:13:55+00:00

Businesses are moving the needle, but are wary of the future.

## AWS has a new way to secure remote working
 - [https://www.techradar.com/news/aws-has-a-new-way-to-secure-remote-working](https://www.techradar.com/news/aws-has-a-new-way-to-secure-remote-working)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 08:56:07+00:00

AWS reckons it can protect workers and companies without having to use an annoying VPN.

## No, gamers aren’t fleeing Windows 11 in droves – quite the opposite
 - [https://www.techradar.com/news/no-gamers-arent-fleeing-windows-11-in-droves-quite-the-opposite](https://www.techradar.com/news/no-gamers-arent-fleeing-windows-11-in-droves-quite-the-opposite)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 08:49:15+00:00

In fact, Windows 11 just hit a big milestone: 1 in 3 gamers are now using Microsoft’s OS.

## Quordle today - hints and answers for Wednesday, May 3 (game #464)
 - [https://www.techradar.com/news/quordle-today-answers-clues-3-may-2023](https://www.techradar.com/news/quordle-today-answers-clues-3-may-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 06:00:33+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

## Motorola brings the Edge 40 Pro to North America with a new name and battery
 - [https://www.techradar.com/news/motorola-brings-the-edge-40-pro-to-north-america-with-a-new-name-and-battery](https://www.techradar.com/news/motorola-brings-the-edge-40-pro-to-north-america-with-a-new-name-and-battery)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-05-03 00:30:00+00:00

The Edge Plus 2023 keeps much of what made the Edge 40 Pro great while upgrading the battery to last two whole days.

