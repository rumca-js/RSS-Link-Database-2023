# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Pilot zgłosił awaryjne lądowanie, po chwili kontakt się urwał. Trwają poszukiwania śmigłowca pod Olsztynem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29724179,pilot-zglosil-awaryjne-ladowanie-kontakt-sie-urwal-trwaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29724179,pilot-zglosil-awaryjne-ladowanie-kontakt-sie-urwal-trwaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-03 19:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6a/43/1c/z29635946M,Ochotnicza-straz-pozarna--zdjecie-ilustracyjne-.jpg" vspace="2" />W okolicach miejscowości Siła w powiecie olsztyńskim prowadzone są poszukiwania śmigłowca. Pilot zasygnalizował potrzebę awaryjnego lądowania.

## Co zabrać ze sobą na maturę? O tych przedmiotach trzeba pamiętać [LISTA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29715830,co-zabrac-ze-soba-na-mature-trzeba-pamietac-o-kilku-przedmiotach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29715830,co-zabrac-ze-soba-na-mature-trzeba-pamietac-o-kilku-przedmiotach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-03 17:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cb/56/1c/z29715915M,Egzamin-maturalny--zdjecie-ilustracyjne-.jpg" vspace="2" />Maturzyści powinni koniecznie zabrać ze sobą na egzaminy kilka niezbędnych przedmiotów. Część z nich będzie potrzebna uczniom podczas wszystkich egzaminów maturalnych. O niektóre rzeczy należy natomiast zatroszczyć się wtedy, gdy maturzyści będą przystępowali do egzaminów z poszczególnych przedmiotów.

## Matura 2023. Jakie konsekwencje czekają ucznia, który wniesie telefon na salę egzaminacyjną? [ZASADY]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29713750,matura-2023-cke-wniesienie-telefonu-na-sale-egaminacyjna-bedzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29713750,matura-2023-cke-wniesienie-telefonu-na-sale-egaminacyjna-bedzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-03 14:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/db/56/1c/z29713883M,Posiadanie-telefonow-podczas-matury-jest-zabronion.jpg" vspace="2" />Podczas egzaminów maturalnych zabronione jest korzystanie z telefonów komórkowych, a nawet wnoszenie urządzeń na salę egzaminacyjną. CKE poinformowało, jakie konsekwencje czekają tych maturzystów, którzy złamią zakaz. Posiadanie przy sobie telefonu podczas matury będzie skutkowało unieważnieniem egzaminu i brakiem możliwości podejścia do niego w terminie poprawkowym.

## Mamy nowych generałów. Prezydent wręczył nominacje ośmiu oficerom. "Zobowiązanie do lepszej służby"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29722454,mamy-nowych-generalow-prezydent-wreczyl-nominacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29722454,mamy-nowych-generalow-prezydent-wreczyl-nominacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-03 11:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/84/58/1c/z29722500M,Prezydent-Andrzej-Duda-wreczyl-nominacje-generalsk.jpg" vspace="2" />Prezydent Andrzej Duda wręczył akty mianowania ośmiu oficerów Wojska Polskiego na stopnie generalskie. Uroczystość odbyła się w Pałacu Prezydenckim w 232. rocznicę uchwalenia Kontytucji 3 Maja. - To jest zobowiązanie do jeszcze lepszej i wydajnej służby dla Rzeczypospolitej, także do jeszcze większego samodoskonalenia się - mówił prezydent.

## Wielkopolska. Pijana, w zawansowanej ciąży, zalała mieszkanie. Pod opieką miała niemowlę. Jest zarzut
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29722098,wielkopolska-bulwersujace-zachowanie-ciezarnej-pijana-zaniedbala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29722098,wielkopolska-bulwersujace-zachowanie-ciezarnej-pijana-zaniedbala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-03 09:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2a/58/1c/z29722154M,Wielkopolska--Bulwersujace-zachowanie-ciezarnej--P.jpg" vspace="2" />Pięć lat więzienia grozi 39-letniej ciężarnej z Ostrowa Wielkopolskiego za narażenie kilkumiesięcznego dziecka na niebezpieczeństwo utraty życia lub zdrowia. Taki zarzut kobiecie postawiła prokuratura. Z mieszkania, w którym była z dzieckiem, lała się woda, a kiedy strażacy weszli do środka okazało się, że kobieta jest pijana.

## TVP ma łagodzić przekaz w "Wiadomościach" i pokazywać reporterów. "Nie toporna propaganda"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29722036,tvp-lagodzi-przekaz-w-wiadomosciach-i-pokazuje-reporterow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29722036,tvp-lagodzi-przekaz-w-wiadomosciach-i-pokazuje-reporterow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-03 08:21:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d7/58/1c/z29722071M,TVP-lagodzi-przekaz-w--Wiadomosciach--i-pokazuje-r.jpg" vspace="2" />"Wiadomości" Telewizji Polskiej zmieniają sposób przekazywania informacji - to zarządzenie nowego kierownictwa Telewizyjnej Agencji Informacyjnej, o którym piszą Wirtualne Media. Reporterzy, którzy przygotowują materiały do dziennika mają pokazywać się na wizji w podsumowaniu tematu, a przekaz na paskach informacyjnych ma być "łagodniejszy".

## Biskupi zabrali głos ws. wyborów parlamentarnych. Jest apel do "wszystkich uczestników kampanii"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29721789,biskupi-zabrali-glos-ws-wyborow-parlamentarnych-jest-apel.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29721789,biskupi-zabrali-glos-ws-wyborow-parlamentarnych-jest-apel.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-05-03 05:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c1/58/1c/z29721793M,Obrady-Rady-Stalej-Konferencji-Episkopatu-Polski.jpg" vspace="2" />Rada Stała Konferencji Episkopatu Polski we wtorkowym komunikacie nawiązała m.in. do jesiennych wyborów parlamentarnych. Biskupi udzielili politykom kilku rad, zwrócili się także z apelem o to, by powstrzymać się od "instrumentalizowania Kościoła" w kampanii wyborczej.

