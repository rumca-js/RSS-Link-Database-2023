# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## ‘Isn’t Magic’: More And More Celebrities Are Getting Honest About Their Marriages Not Being ‘Perfect,’ Taking Work
 - [https://www.dailywire.com/news/isnt-magic-more-and-more-celebrities-are-getting-honest-about-their-marriages-not-being-perfect-taking-work](https://www.dailywire.com/news/isnt-magic-more-and-more-celebrities-are-getting-honest-about-their-marriages-not-being-perfect-taking-work)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 19:38:19+00:00

More and more celebrities lately have been getting honest about their marriage and relationships not being perfect and taking work in order to make things stronger. Stars like Tom Hanks and Rita Wilson have been married for more than three decades and the 66-year-old actor opened up in the past about what he and Wilson ...

## Senator Sinema Blasts Karine Jean-Pierre For Claiming Border Is Secure: ‘Factually Not True’
 - [https://www.dailywire.com/news/senator-sinema-blasts-karine-jean-pierre-for-claiming-border-is-secure-factually-not-true](https://www.dailywire.com/news/senator-sinema-blasts-karine-jean-pierre-for-claiming-border-is-secure-factually-not-true)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 19:31:53+00:00

Sen. Kyrsten Sinema (I-AZ) slammed White House Press Secretary Karine Jean-Pierre this week for falsely claiming that the U.S. southern border was secure, saying that her comments were “just factually not true.” Jean-Pierre had claimed on Monday that “the actions that this president has taken” had led to a 90% decrease in illegal immigration. Sinema hit ...

## ‘I Know This Sounds Really Far Out’: Nicolas Cage’s ‘First Memory’ Has Stephen Colbert Asking Questions
 - [https://www.dailywire.com/news/i-know-this-sounds-really-far-out-nicolas-cages-first-memory-has-stephen-colbert-asking-questions](https://www.dailywire.com/news/i-know-this-sounds-really-far-out-nicolas-cages-first-memory-has-stephen-colbert-asking-questions)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 19:13:34+00:00

Actor Nicolas Cage&#8217;s recently revealed &#8220;earliest memory&#8221; inspired several follow-up questions from comedian and &#8220;The Late Show&#8221; host Stephen Colbert. Cage, who made an appearance on the show to promote his vampire-themed horror comedy &#8220;Renfield,&#8221; participated in the &#8220;Colbert Questionert&#8221; — during which he fielded a series of random questions from the host. WATCH: Things ...

## ‘You Don’t Know, Do You?’: GOP Senator Corners Biden Lackey On Climate Agenda
 - [https://www.dailywire.com/news/you-dont-know-do-you-gop-senator-corners-biden-lackey-on-climate-agenda](https://www.dailywire.com/news/you-dont-know-do-you-gop-senator-corners-biden-lackey-on-climate-agenda)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 18:42:36+00:00

Senator John Kennedy (R-LA) made it clear on Wednesday that he was not impressed by Deputy Energy Secretary David Turk, challenging him to explain just how the Biden administration&#8217;s climate agenda would translate to a real-world impact. Kennedy noted that the Biden administration wanted to spend trillions on climate initiatives, and asked Turk to estimate ...

## New York Court Tosses Trump Suit Against NYT, Niece Over Leaked Tax Records
 - [https://www.dailywire.com/news/new-york-court-tosses-trump-suit-against-nyt-niece-over-leaked-tax-records](https://www.dailywire.com/news/new-york-court-tosses-trump-suit-against-nyt-niece-over-leaked-tax-records)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 18:22:21+00:00

A New York court tossed former President Donald Trump’s lawsuit against The New York Times, a blow to Trump’s efforts to exact damages for the leak of his private tax returns. New York Supreme Court Justice Robert Reed ordered the former president to pay all legal expenses, attorney fees, and other costs in a Wednesday ...

## Ocasio-Cortez Is Right Again: Sen. Dianne Feinstein Should Resign
 - [https://www.dailywire.com/news/ocasio-cortez-is-right-again-sen-dianne-feinstein-should-resign](https://www.dailywire.com/news/ocasio-cortez-is-right-again-sen-dianne-feinstein-should-resign)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 18:16:11+00:00

Rep. Alexandria Ocasio-Cortez (D-NY), who has been in the House since January 2019, is calling on Sen. Dianne Feinstein (D-CA), who has been in the Senate for 31 years, to resign. Now, we don&#8217;t exactly disagree with her. Feinstein has been in public service (read: sucking off the government teat) since 1978 — 45 years. ...

## Liberal SCOTUS Justice Took $3M From Book Publisher, Didn’t Recuse From Its Cases
 - [https://www.dailywire.com/news/liberal-scotus-justice-took-3m-from-book-publisher-didnt-recuse-from-its-cases](https://www.dailywire.com/news/liberal-scotus-justice-took-3m-from-book-publisher-didnt-recuse-from-its-cases)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 18:13:10+00:00

Liberal Supreme Court Justice Sonia Sotomayor declined to recuse herself from a court case involving book publisher Penguin Random House despite having been paid millions by the firm for her books, making it by far her largest source of income, records show.

## FDA Approves First-Ever RSV Vax Nearly 60 Years After Disastrous Experimental Shot
 - [https://www.dailywire.com/news/fda-approves-first-ever-rsv-vax-nearly-60-years-after-disastrous-experimental-shot](https://www.dailywire.com/news/fda-approves-first-ever-rsv-vax-nearly-60-years-after-disastrous-experimental-shot)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 18:08:03+00:00

Nearly 60 years after scientists tried and disastrously failed to develop a vaccine for respiratory syncytial virus (RSV), the Food and Drug Administration has approved the first-ever RSV shot. On Wednesday, the FDA gave a thumbs-up to Arexvy, the RSV vaccine developed by British pharmaceutical company GSK, which is intended for those 60 years old ...

## Wednesday Afternoon Update: Atlanta Shooting, Russia Accuses Ukraine Of Assassination Attempt, Olympian Dead At 32
 - [https://www.dailywire.com/news/wednesday-afternoon-update-atlanta-shooting-russia-accuses-ukraine-of-assassination-attempt-olympian-dead-at-32](https://www.dailywire.com/news/wednesday-afternoon-update-atlanta-shooting-russia-accuses-ukraine-of-assassination-attempt-olympian-dead-at-32)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 17:41:44+00:00

This article is adapted from today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. Atlanta Shooting: One person is dead and four are injured after a shooter opened fire in an Atlanta medical facility shortly after noon today. According to police, the shooter entered Northside Hospital Medical Midtown wearing a gray hoodie ...

## Suspect Still At Large After Atlanta Shooting, Identified As Coast Guard Veteran
 - [https://www.dailywire.com/news/suspect-still-at-large-after-atlanta-shooting-identified-as-coast-guard-veteran](https://www.dailywire.com/news/suspect-still-at-large-after-atlanta-shooting-identified-as-coast-guard-veteran)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 17:26:39+00:00

A suspect is still at large after a shooting rocked midtown Atlanta, Georgia, on Wednesday — when a man opened fire at a medical facility, leaving one dead and several others injured. The suspect has been identified as Coast Guard veteran Deion Patterson, who reportedly enlisted in 2018 and served as an Electrician’s Mate Second ...

## ‘No Special Treatment’: Elon Musk Says He Will Give NPR’s Twitter Handle To Another Company Unless They Return To The Platform
 - [https://www.dailywire.com/news/no-special-treatment-elon-musk-says-he-will-give-nprs-twitter-handle-to-another-company-unless-they-return-to-the-platform](https://www.dailywire.com/news/no-special-treatment-elon-musk-says-he-will-give-nprs-twitter-handle-to-another-company-unless-they-return-to-the-platform)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 17:07:05+00:00

NPR said on Wednesday that Elon Musk threatened to take away the Twitter handle belonging to the news outlet unless the firm continues to post on the platform. The outlet, which ceased using Twitter last month after Musk temporarily affixed a label to the account noting that NPR receives funds from government entities, revealed that ...

## Navy Hires Active Duty Drag Queen To Combat Sinking Recruitment
 - [https://www.dailywire.com/news/navy-hires-active-duty-drag-queen-to-combat-sinking-recruitment](https://www.dailywire.com/news/navy-hires-active-duty-drag-queen-to-combat-sinking-recruitment)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 17:07:02+00:00

The U.S. Navy hired an active-duty sailor and drag queen to be the face of the Navy&#8217;s campaign to fight dropping recruitment. Yeoman 2nd Class Joshua Kelley, 29, who identifies as non-binary, became one of five Navy Digital Ambassadors in a pilot recruitment program that lasted from October to March. Kelley&#8217;s drag queen name is ...

## Kelly Osbourne, Nick Cannon Take Over As Host Of Jamie Foxx Show After Illness Keeps Actor In Hospital
 - [https://www.dailywire.com/news/kelly-osbourne-nick-cannon-take-over-as-host-of-jamie-foxx-show-after-illness-keeps-actor-in-hospital](https://www.dailywire.com/news/kelly-osbourne-nick-cannon-take-over-as-host-of-jamie-foxx-show-after-illness-keeps-actor-in-hospital)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 16:52:23+00:00

Kelly Osbourne and Nick Cannon have been named to take over hosting duties for Jamie Foxx on his show &#8220;Beat Shazam&#8221; after a &#8220;medical complication&#8221; landed him in the hospital three weeks ago, where he remains. “‘Beat Shazam&#8217; has been an unscripted mainstay on the FOX schedule for six seasons and counting,&#8221; read a statement ...

## Twitter Users Set The Record Straight After Politifact Says Randi Weingarten ‘Advocated For Reopening Schools’ During Pandemic
 - [https://www.dailywire.com/news/twitter-users-set-the-record-straight-after-politifact-says-randi-weingarten-advocated-for-reopening-schools-during-pandemic](https://www.dailywire.com/news/twitter-users-set-the-record-straight-after-politifact-says-randi-weingarten-advocated-for-reopening-schools-during-pandemic)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 16:43:49+00:00

Twitter users debunked a claim made by Politifact on Wednesday about American Federation of Teachers President Randi Weingarten, contending she advocated for reopening schools during COVID. Community Notes, a feature on Twitter that allows a crowd-based solution to collaboratively add context to potentially misleading Tweets without third-party groups, such as the American nonprofit group Politifact, fact-checked ...

## California Democrat Running For Porter’s House Seat Admits To DUI
 - [https://www.dailywire.com/news/california-democrat-running-for-porters-house-seat-admits-to-dui](https://www.dailywire.com/news/california-democrat-running-for-porters-house-seat-admits-to-dui)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 16:16:44+00:00

A California Democrat running to replace Rep. Katie Porter (D-CA) in the House as she vies for a Senate seat apologized on Wednesday for drunk driving. &#8220;Last night I was cited for a misdemeanor for driving under the influence,&#8221; state Sen. Dave Min said in a post on Facebook. &#8220;My decision to drive last night was irresponsible. ...

## Lawmakers Dumped Their Shares In First Republic Bank Before The Company Collapsed
 - [https://www.dailywire.com/news/lawmakers-dumped-their-shares-in-first-republic-bank-before-the-company-collapsed](https://www.dailywire.com/news/lawmakers-dumped-their-shares-in-first-republic-bank-before-the-company-collapsed)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 16:10:13+00:00

Multiple lawmakers sold their shares in First Republic Bank in the weeks before the firm collapsed and was sold to JPMorgan Chase by financial regulators. First Republic Bank imploded on Monday, weeks after Silicon Valley Bank and Signature Bank similarly collapsed, as account holders with balances above the Federal Deposit Insurance Corporation threshold rushed to ...

## ‘American Idol’ Judge Luke Bryan Praises Contestant For Not Being ‘Scared’ To Share ‘Your Faith’
 - [https://www.dailywire.com/news/american-idol-judge-luke-bryan-praises-contestant-for-not-being-scared-to-share-your-faith](https://www.dailywire.com/news/american-idol-judge-luke-bryan-praises-contestant-for-not-being-scared-to-share-your-faith)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 15:43:22+00:00

&#8220;American Idol&#8221; judge Luke Bryan praised a 21-year-old contestant in the top 8 finalist section of the competition series for not being &#8220;scared&#8221; to share her &#8220;faith.&#8221; The 46-year-old country singer recently told Megan Danielle, a waitress from Douglasville, Georgia, that he was impressed with her commitment. It happened on Monday&#8217;s show after Danielle sang, ...

## Eighth Graders Had Record Low U.S. History, Civics Scores In 2022
 - [https://www.dailywire.com/news/eighth-graders-had-record-low-u-s-history-civics-scores-in-2022](https://www.dailywire.com/news/eighth-graders-had-record-low-u-s-history-civics-scores-in-2022)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 15:42:07+00:00

Eighth graders had the lowest U.S. history scores on record in 2022 and among the lowest civics scores, the Department of Education revealed this week. The Education Department on Wednesday released the first federal history and civics testing data since before the COVID pandemic. The data shows that the last few years have erased the ...

## Texas Democrat Announces Bid For Senate; Ted Cruz Fires Back: ‘Puppet’ Of Pelosi
 - [https://www.dailywire.com/news/texas-democrat-announces-bid-for-senate-ted-cruz-fires-back-puppet-of-pelosi](https://www.dailywire.com/news/texas-democrat-announces-bid-for-senate-ted-cruz-fires-back-puppet-of-pelosi)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 15:39:00+00:00

Yet another House Democrat is taking on Sen. Ted Cruz (R-TX), whose re-election campaign immediately shot back at the 2024 election challenger. Rep. Colin Allred, a former Tennessee Titans linebacker and Obama administration official who has represented Texas&#8216; 32nd district since 2019, announced his campaign on Wednesday. &#8220;I’m running for U.S. Senate because Texans deserve a ...

## Former FBI Agent Faces Charges Related To Capitol Riot: Authorities
 - [https://www.dailywire.com/news/former-fbi-agent-faces-charges-related-to-capitol-riot-authorities](https://www.dailywire.com/news/former-fbi-agent-faces-charges-related-to-capitol-riot-authorities)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 15:27:50+00:00

The Justice Department charged a former FBI agent on Wednesday for unlawfully entering the U.S. Capitol for nine minutes and three other misdemeanor counts after allegedly threatening police during the riot on January 6, 2021, according to court documents. Jared Wise, 50, who worked in the bureau from 2004 to 2017, was arrested on Monday ...

## Billionaire Buys Jeffrey Epstein’s Infamous Island, Plans To Turn It Into A Luxury Resort: Report
 - [https://www.dailywire.com/news/billionaire-buys-jeffrey-epsteins-infamous-island-plans-to-turn-it-into-a-luxury-resort-report](https://www.dailywire.com/news/billionaire-buys-jeffrey-epsteins-infamous-island-plans-to-turn-it-into-a-luxury-resort-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 15:21:54+00:00

A billionaire investor has reportedly purchased Jeffrey Epstein&#8217;s notorious private islands in the Caribbean and plans to turn them into a luxury resort. Forbes reported that Stephen Deckoff, founder of private equity firm Black Diamond Capital Management, bought the islands for $60 million — approximately half of their initial asking price. Deckoff told the publication ...

## Nashville Police Refuse To Release School Shooter’s Manifesto, Citing Pending Lawsuit
 - [https://www.dailywire.com/news/nashville-police-refuse-to-release-school-shooters-manifesto-citing-pending-lawsuit](https://www.dailywire.com/news/nashville-police-refuse-to-release-school-shooters-manifesto-citing-pending-lawsuit)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 15:05:56+00:00

The Metropolitan Nashville Police Department is indefinitely delaying releasing records related to the shooting of a Christian school, despite having told the state’s governor last week that a release was imminent.

## Woman Claims ‘Green Vegetables’ Convinced Her That Her Child Was Transgender
 - [https://www.dailywire.com/news/woman-claims-green-vegetables-convinced-her-that-her-child-was-transgender](https://www.dailywire.com/news/woman-claims-green-vegetables-convinced-her-that-her-child-was-transgender)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 14:48:08+00:00

A Louisiana woman claimed during a Tuesday hearing that an unusual affinity for &#8220;raw green vegetables&#8221; was one of the clues that led her to believe her daughter would identify as transgender. The woman appeared before the Louisiana State House&#8217;s Health and Welfare Committee to speak ahead of a vote on HB 463, which would ban so-called ...

## ‘God Granted Me A Miracle’: Maria Menounos Reveals Secret Cancer Battle
 - [https://www.dailywire.com/news/god-granted-me-a-miracle-maria-menounos-reveals-secret-cancer-battle](https://www.dailywire.com/news/god-granted-me-a-miracle-maria-menounos-reveals-secret-cancer-battle)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 14:45:03+00:00

TV host Maria Menounos revealed that she&#8217;s been dealing with a secret health battle after being diagnosed with stage two pancreatic cancer and said &#8220;God granted&#8221; her a &#8220;miracle.&#8221; The 44-year-old, who has hosted shows like &#8220;Extra&#8221; and &#8220;E! News,&#8221; said life was going great as she and her husband Keven Undergaro were finally going ...

## Freedom Caucus Chair Blasts White House For Punting Debt Ceiling Talks For Months Then Saying There Is ‘Limited Time’ To Negotiate
 - [https://www.dailywire.com/news/freedom-caucus-chair-blasts-white-house-for-punting-debt-ceiling-talks-for-months-then-saying-there-is-limited-time-to-negotiate](https://www.dailywire.com/news/freedom-caucus-chair-blasts-white-house-for-punting-debt-ceiling-talks-for-months-then-saying-there-is-limited-time-to-negotiate)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 14:31:45+00:00

House Freedom Caucus Chair Scott Perry (R-PA) blasted White House Press Secretary Karine Jean-Pierre after she said that lawmakers have “limited time” to raise the debt ceiling, an assertion which comes after the Biden administration delayed negotiations on the matter for several weeks. The debt ceiling, a policy established by Congress that prevents the federal ...

## Whistleblower Alleges FBI Has Evidence Of Biden Engaging In Bribery Scheme With Foreign National
 - [https://www.dailywire.com/news/whistleblower-alleges-fbi-has-evidence-of-biden-engaging-in-bribery-scheme-with-foreign-national](https://www.dailywire.com/news/whistleblower-alleges-fbi-has-evidence-of-biden-engaging-in-bribery-scheme-with-foreign-national)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 14:24:21+00:00

Republican lawmakers demanded on Wednesday that the FBI produce an unclassified record that allegedly contains evidence showing that then-Vice President Joe Biden was involved in a criminal bribery scheme with a foreign national. Senate Budget Committee Ranking Member Chuck Grassley (R-IA) and House Committee on Oversight and Accountability Chairman James Comer (R-KY) released a joint ...

## NFL Star Patrick Mahomes’ Brother Arrested, Charged With Aggravated Sexual Battery
 - [https://www.dailywire.com/news/nfl-star-patrick-mahomes-brother-arrested-charged-with-aggravated-sexual-battery](https://www.dailywire.com/news/nfl-star-patrick-mahomes-brother-arrested-charged-with-aggravated-sexual-battery)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 14:18:37+00:00

Kansas City Chiefs quarterback Patrick Mahomes’ younger brother, Jackson Mahomes, was arrested on Wednesday morning. The 22-year-old was booked into the Johnson County Detention Center in Kansas on a $100,000 bond, ESPN reported. He&#8217;s been charged with three counts of aggravated sexual battery and one count of battery, according to online records. Overland Park Police confirmed ...

## Bride Killed, Groom Injured When Suspected Drunk Driver Slammed Into Their Golf Cart
 - [https://www.dailywire.com/news/bride-killed-groom-injured-when-suspected-drunk-driver-slammed-into-their-golf-cart](https://www.dailywire.com/news/bride-killed-groom-injured-when-suspected-drunk-driver-slammed-into-their-golf-cart)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 14:15:19+00:00

A newlywed couple riding away from their wedding reception in a golf cart was struck by a suspected drunk driver, resulting in the bride’s death and the groom being seriously injured. The incident occurred in Folly Beach, South Carolina, about 10 miles outside of Charleston, on April 28, according to an NBC report. The bride, ...

## Federal Reserve Unveils Quarter-Point Target Interest Rate Hike As Banking System Reels
 - [https://www.dailywire.com/news/federal-reserve-unveils-quarter-point-target-interest-rate-hike-as-banking-system-reels](https://www.dailywire.com/news/federal-reserve-unveils-quarter-point-target-interest-rate-hike-as-banking-system-reels)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 14:04:22+00:00

Officials at the Federal Reserve announced a 0.25% increase in the target federal funds rate on Wednesday, marking a slowdown from previous rate hikes meant to combat inflation, even as the financial sector contends with the collapse of three medium-sized regional banks. Rate hikes increase the cost of borrowing money, decreasing inflationary pressures as consumers ...

## SOS: Anheuser-Busch Now Sending Free Beer To Every Employee Of Wholesaler Network: Report
 - [https://www.dailywire.com/news/sos-anheuser-busch-now-sending-free-beer-to-every-employee-of-wholesaler-network-report](https://www.dailywire.com/news/sos-anheuser-busch-now-sending-free-beer-to-every-employee-of-wholesaler-network-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 13:54:41+00:00

Anheuser-Busch, which has seen sales of Bud Light nosedive since it teamed up with trans-identifying influencer Dylan Mulvaney for an ill-fated endorsement deal, is reportedly offering a free case of beer to every employee of its wholesaler network. In-store sales of Bud Light plummeted 26% in the week ending April 22 after plunging 21% the previous ...

## Greg Gutfeld Defends Tucker, Blasts ‘Hall Monitor Failures’ Desperate To Destroy Him
 - [https://www.dailywire.com/news/greg-gutfeld-defends-tucker-blasts-hall-monitor-failures-desperate-to-destroy-him](https://www.dailywire.com/news/greg-gutfeld-defends-tucker-blasts-hall-monitor-failures-desperate-to-destroy-him)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 13:42:29+00:00

Fox News host Greg Gutfeld defended his former colleague Tucker Carlson, calling out the &#8220;hall monitor failures&#8221; who would like nothing better than to see the popular ex-Fox News host destroyed. Gutfeld responded Tuesday to a slew of leaked videos — disseminated primarily by regular Carlson target Media Matters for America — that purported to ...

## Former DOD Elementary Teacher Sentenced To Life In Prison For Sexually Abusing Children As Young As 6
 - [https://www.dailywire.com/news/former-dod-elementary-teacher-sentenced-to-life-in-prison-for-sexually-abusing-children-as-young-as-6](https://www.dailywire.com/news/former-dod-elementary-teacher-sentenced-to-life-in-prison-for-sexually-abusing-children-as-young-as-6)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 13:26:34+00:00

A 56-year-old elementary school teacher formerly employed by the Department of Defense Education Activity will spend the rest of his life behind bars for sexually abusing four students between 6 and 8 years old. From 2001 to 2021, Stefan Zappey taught first through third grade at Patch Elementary, a school on a U.S. military base ...

## DOJ Asks To Move Michael Flynn’s Wrongful Prosecution Lawsuit From Florida To D.C.
 - [https://www.dailywire.com/news/doj-asks-to-move-michael-flynns-wrongful-prosecution-lawsuit-from-florida-to-d-c](https://www.dailywire.com/news/doj-asks-to-move-michael-flynns-wrongful-prosecution-lawsuit-from-florida-to-d-c)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 13:15:43+00:00

The federal government wants to move former Trump national security adviser Michael Flynn&#8216;s $50 million wrongful prosecution lawsuit from Florida to Washington, D.C., where years ago a judge resisted the Department of Justice&#8217;s bid to drop its own criminal case against the retired Army lieutenant general. DOJ lawyers filed a motion on Monday arguing that ...

## U.S. Olympic Champion Sprinter Tori Bowie Dies At 32
 - [https://www.dailywire.com/news/u-s-olympic-champion-sprinter-tori-bowie-dies-at-32](https://www.dailywire.com/news/u-s-olympic-champion-sprinter-tori-bowie-dies-at-32)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 13:08:48+00:00

American track and field star Tori Bowie, a three-time Olympic medalist and a two-time world champion in track and field, has died. She was 32 years old. “We’re devasted to share the very sad news that Tori Bowie has passed away,&#8221; Icon Management said in a statement on Twitter. &#8220;We’ve lost a client, dear friend, daughter ...

## Chris Cuomo Brings In Big Guns To Defend Blinken’s Alleged Lies: Disgraced FBI Agent Peter Strzok
 - [https://www.dailywire.com/news/chris-cuomo-brings-in-big-guns-to-defend-blinkens-alleged-lies-disgraced-fbi-agent-peter-strzok](https://www.dailywire.com/news/chris-cuomo-brings-in-big-guns-to-defend-blinkens-alleged-lies-disgraced-fbi-agent-peter-strzok)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 13:01:46+00:00

NewsNation host Chris Cuomo brought in fired FBI agent Peter Strzok to discuss the recent news concerning Secretary of State Antony Blinken&#8217;s contact with Hunter Biden and alleged attempts to hide that interaction when speaking to Congress. Strzok was fired from the FBI in 2018 after several of his private text messages — many disparaging ...

## Additional Arrests Made In Connection To Illegal Alien Accused Of Murdering 5 Neighbors
 - [https://www.dailywire.com/news/additional-arrests-made-in-connection-to-illegal-alien-accused-of-murdering-5-neighbors](https://www.dailywire.com/news/additional-arrests-made-in-connection-to-illegal-alien-accused-of-murdering-5-neighbors)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 12:59:17+00:00

Several additional arrests have been made in connection to the case in Texas involving an illegal alien who allegedly murdered five of his neighbors after they asked him to stop shooting his gun because they had a sleeping baby. The 38-year-old suspect was arrested in the small Texas town of Cut and Shoot, which has ...

## AOC And Matt Gaetz Team Up To Ban Stock Trading Among Lawmakers
 - [https://www.dailywire.com/news/aoc-and-matt-gaetz-team-up-to-ban-stock-trading-among-lawmakers](https://www.dailywire.com/news/aoc-and-matt-gaetz-team-up-to-ban-stock-trading-among-lawmakers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 12:26:16+00:00

Democratic and Republican lawmakers, including conservative firebrand Rep. Matt Gaetz (R-FL) and leftist rising star Rep. Alexandria Ocasio-Cortez (D-NY), proposed a bill that would ban members of Congress from trading individual stocks. Several prominent lawmakers have been accused in recent years of using their intimate knowledge about forthcoming regulations or economic tumult to purchase stocks ...

## ‘I Don’t Look At That S***’: Woody Harrelson Dismisses Backlash Over COVID Monologue On SNL
 - [https://www.dailywire.com/news/i-dont-look-at-that-s-woody-harrelson-dismisses-backlash-over-covid-monologue-on-snl](https://www.dailywire.com/news/i-dont-look-at-that-s-woody-harrelson-dismisses-backlash-over-covid-monologue-on-snl)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 11:37:44+00:00

Very few celebrities broke rank with the limousine liberals who went all in on COVID. But Woody Harrelson, an actor who turned a bit role in the TV series &#8220;Cheers&#8221; into a major Hollywood career, threw caution to the wind and blasted it all in a monologue on &#8220;Saturday Night Live&#8221; that went viral. There ...

## ‘Pray For Jamie’: Foxx’s Illness Still A Mystery As ‘Beat Shazam’ Game Show Gets New Host
 - [https://www.dailywire.com/news/pray-for-jamie-foxxs-illness-still-a-mystery-as-beat-shazam-game-show-gets-new-host](https://www.dailywire.com/news/pray-for-jamie-foxxs-illness-still-a-mystery-as-beat-shazam-game-show-gets-new-host)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 11:36:39+00:00

Actor Jamie Foxx has been hospitalized since mid-April with what his family has only referenced as a &#8220;complication&#8221; — and now, with no new information regarding his condition, a new host has been selected for his game show &#8220;Beat Shazam.&#8221; According to a report published Wednesday by entertainment site TMZ, the new season of the ...

## JPMorgan Chase Repeatedly ‘De-Banked’ Conservative And Religious Groups, Republican State Officials Say
 - [https://www.dailywire.com/news/jpmorgan-chase-repeatedly-de-banked-conservative-and-religious-groups-republican-state-officials-say](https://www.dailywire.com/news/jpmorgan-chase-repeatedly-de-banked-conservative-and-religious-groups-republican-state-officials-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 11:24:05+00:00

Nineteen Republican state attorneys general asserted on Tuesday that JPMorgan Chase “de-banked” organizations for their conservative and religious tendencies, calling on the nation’s largest financial institution to respect the viewpoints of their customers. The officials stated in a letter to the firm provided to The Daily Wire that the National Committee for Religious Freedom, a ...

## Emilio Estevez Said Laurence Fishburne Saved Him From Quicksand While Shooting ‘Apocalypse Now’
 - [https://www.dailywire.com/news/emilio-estevez-said-laurence-fishburne-saved-him-from-quicksand-while-shooting-apocalypse-now](https://www.dailywire.com/news/emilio-estevez-said-laurence-fishburne-saved-him-from-quicksand-while-shooting-apocalypse-now)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 11:07:03+00:00

Actor Emilio Estevez said this week that Laurence Fishburne saved his life when he fell into quicksand in the Philippines. Estevez was just a kid at the time, accompanying his father, Martin Sheen, on the set of the 1979 action film, “Apocalypse Now.” The 60-year-old actor said he only met Fishburne a &#8220;couple of days&#8221; ...

## Girl Gives Fiery Speech Blasting School Board About Violent Trans Student In Viral Video
 - [https://www.dailywire.com/news/girl-gives-fiery-speech-blasting-school-board-about-violent-trans-student-in-viral-video](https://www.dailywire.com/news/girl-gives-fiery-speech-blasting-school-board-about-violent-trans-student-in-viral-video)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 11:01:09+00:00

A California high schooler blistered her local school board for allowing a violent male student to use girls&#8217; bathrooms and locker rooms, telling the officials they were putting safety at risk. Megan Simpkins, a senior at Martin Luther King High School in Riverside, California, referred to a boy at the school caught twice on video ...

## Oklahoma Bans 13 Woke Financial Firms From Doing Business With State Government
 - [https://www.dailywire.com/news/oklahoma-bans-13-woke-financial-firms-from-doing-business-with-state-government](https://www.dailywire.com/news/oklahoma-bans-13-woke-financial-firms-from-doing-business-with-state-government)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 10:50:05+00:00

The state of Oklahoma banned more than one dozen investment and asset management firms, including BlackRock and JPMorgan Chase, from conducting business with state government entities over alleged efforts to boycott energy companies. Recently enacted legislation enabled Oklahoma Republican State Treasurer Todd Russ to create a list of firms deemed on Wednesday to be engaged ...

## Russia Accuses Ukraine Of Sending Drones To Assassinate Putin
 - [https://www.dailywire.com/news/russia-accuses-ukraine-of-sending-drones-to-assassinate-putin](https://www.dailywire.com/news/russia-accuses-ukraine-of-sending-drones-to-assassinate-putin)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 10:31:58+00:00

Russia accused Ukraine of attempting to assassinate Russian President Vladimir Putin after reporting that two drones crashed into the Kremlin on Wednesday. Videos circulating on social media appear to show a drone exploding and smoke rising over the roof of the Kremlin. Russia said in a statement posted to the Kremlin’s website that two drones ...

## UFOs Go Mainstream: Inside The Government’s Search For Answers On ‘Unidentified Aerial Phenomena’
 - [https://www.dailywire.com/news/ufos-go-mainstream-inside-the-governments-search-for-answers-on-unidentified-aerial-phenomena](https://www.dailywire.com/news/ufos-go-mainstream-inside-the-governments-search-for-answers-on-unidentified-aerial-phenomena)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 10:29:09+00:00

This is part 2 of a series documenting the U.S. Government’s response to UFOs. Part 1 can be viewed here. The full segment originally aired on Morning Wire.  After hundreds of documented cases of UFO sightings from U.S. service members and other military personnel, the Pentagon, intelligence community, and Congress have begun to take action. ...

## ‘Yellowstone’ Star Kevin Costner’s Wife Files For Divorce After 18 Years Of Marriage
 - [https://www.dailywire.com/news/yellowstone-star-kevin-costners-wife-files-for-divorce-after-18-years-of-marriage](https://www.dailywire.com/news/yellowstone-star-kevin-costners-wife-files-for-divorce-after-18-years-of-marriage)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 10:21:56+00:00

Kevin Costner’s wife Christine Baumgartner has filed for divorce after 18 years of marriage. The 49-year-old handbag designer filed to end their marriage on Monday, citing “irreconcilable differences,” per TMZ. The filing indicates that she wanted to share custody of their three kids: Cayden, 15; Hayes, 14; and Grace, 12. TMZ reported that the couple ...

## ‘WitchTok’ And The Rise Of Paganism In The Western World
 - [https://www.dailywire.com/news/witchtok-and-the-rise-of-paganism-in-the-western-world](https://www.dailywire.com/news/witchtok-and-the-rise-of-paganism-in-the-western-world)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 08:57:46+00:00

Stories about the decline of Christianity in the Western world have dominated headlines for decades. A secularizing society, however, appears to be a fertile breeding ground for the return of deities which were once worshiped before the successful spread of the gospel. Attention toward paganism and heathenism, which generally reference the ethnic polytheistic religions that ...

## ‘Feels Like A Horror Movie’: Viral Video Of Americans Standing For Anthem In Restaurant Freaks Out Foreigners, Leftists
 - [https://www.dailywire.com/news/feels-like-a-horror-movie-viral-video-of-americans-standing-for-anthem-in-restaurant-freaks-out-foreigners-leftists](https://www.dailywire.com/news/feels-like-a-horror-movie-viral-video-of-americans-standing-for-anthem-in-restaurant-freaks-out-foreigners-leftists)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 07:47:22+00:00

A viral TikTok video of Americans at a Southern California restaurant standing up during the restaurant’s daily playing of the national anthem catalyzed some apparent foreigners and leftists to freak out on social media. The Rainbow Oaks Restaurant in Fallbrook, California, located roughly 50 miles northeast of San Diego, has played the Star Spangled Banner ...

## BREAKING: Teenage Boy Allegedly Kills 9 In School Shooting In Serbia
 - [https://www.dailywire.com/news/breaking-teenage-boy-allegedly-kills-9-in-school-shooting-in-serbia](https://www.dailywire.com/news/breaking-teenage-boy-allegedly-kills-9-in-school-shooting-in-serbia)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-05-03 07:16:45+00:00

A 14-year-old Serbian student allegedly opened fire at a school in Belgrade, Serbia, on Wednesday morning, killing eight children and a school guard. Six other children and a teacher were injured in the attack before the suspected shooter was arrested in the schoolyard. The suspected assailant allegedly used his father’s gun at the Vladislav Ribnikar ...

