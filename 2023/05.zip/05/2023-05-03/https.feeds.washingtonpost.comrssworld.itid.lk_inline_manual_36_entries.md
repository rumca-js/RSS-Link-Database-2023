# Source:The Washington Post - World, URL:https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36, language:en-US

## Guatemala seeks arrest of ex-guerrilla leader in 1980 blast
 - [https://www.washingtonpost.com/world/2023/05/03/guatemala-civil-war-bombing/9405ca50-ea03-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/guatemala-civil-war-bombing/9405ca50-ea03-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 19:00:45+00:00

A judge in Guatemala has issued an arrest warrant for Gustavo Meoño, a former leftist guerrilla leader and transparency activist, in connection with a 1980 bomb attack

## Greek authorities rescue 39 migrants dumped on border islet
 - [https://www.washingtonpost.com/world/2023/05/03/greece-turkey-migrants-rescued-river-islet/83d39fcc-e9f4-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/greece-turkey-migrants-rescued-river-islet/83d39fcc-e9f4-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 16:53:11+00:00

Greek authorities say they have rescued a group of 39 migrants abandoned by smugglers on an islet in the river that runs along the country’s land border with Turkey

## Mexico develops own COVID-19 vaccine, 2 years late
 - [https://www.washingtonpost.com/world/2023/05/03/mexico-covid19-vaccine-coronavirus/deabe0ae-e9ee-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/mexico-covid19-vaccine-coronavirus/deabe0ae-e9ee-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 16:12:46+00:00

Mexican officials are crowing about the country finally developing its own COVID-19 vaccine, more than two years after inoculations from the U.S., Europe and China were rolled out

## Real or not, reported Kremlin drone attack unsettles Russia
 - [https://www.washingtonpost.com/world/2023/05/03/russia-ukraine-drones-kremlin-video-attack-putin-zelenskyy/5324ec24-e9ee-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/russia-ukraine-drones-kremlin-video-attack-putin-zelenskyy/5324ec24-e9ee-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 16:08:52+00:00

A cloud of questions hangs over Russia’s claim that two Ukrainian drones flew into the very heart of Moscow under the cover of darkness, reaching the Kremlin before they were shot down at the last minute

## Canadian man charged with counseling suicides in 2 deaths
 - [https://www.washingtonpost.com/world/2023/05/03/canada-suicide-arrest-sodium-nitrate/c6b432fc-e9ea-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/canada-suicide-arrest-sodium-nitrate/c6b432fc-e9ea-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 15:43:28+00:00

Police in Canada have arrested a man for allegedly selling a lethal substance to people at risk of self-harm and charged him with counseling suicide in the deaths of two Canadians

## Mexico president complains US is funding opposition
 - [https://www.washingtonpost.com/world/2023/05/03/mexico-united-states-funding-organizations/7465935a-e9e1-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/mexico-united-states-funding-organizations/7465935a-e9e1-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 15:10:35+00:00

Mexico President Andrés Manuel López Obrador has again complained to the United States that the U.S. government is funding organizations opposed to his administration, this time in a letter to President Joe Biden

## Ukraine’s military is stronger than U.S. leaks indicated, Blinken says
 - [https://www.washingtonpost.com/national-security/2023/05/03/ukraine-discord-leaks-blinken/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/national-security/2023/05/03/ukraine-discord-leaks-blinken/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 14:11:53+00:00

Secretary of State Antony Blinken said he was "confident" Ukraine's counteroffensive would yield some success in regaining Russian-occupied territory.

## Pompeii chariot stars in Rome exhibit probing ancient roots
 - [https://www.washingtonpost.com/world/2023/05/03/pompeii-chariot-ancient-rome-greece-exhibition/7f9c2666-e9d8-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/pompeii-chariot-ancient-rome-greece-exhibition/7f9c2666-e9d8-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 13:58:48+00:00

A reconstructed Pompeii bridal chariot that eluded modern-day thieves in the ancient city is a star of a new exhibition in Rome

## Rights panel: Peru used excessive force to quell protests
 - [https://www.washingtonpost.com/world/2023/05/03/peru-protests-human-rights-iachr/c9a1f5a6-e9d3-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/peru-protests-human-rights-iachr/c9a1f5a6-e9d3-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 12:58:54+00:00

The Inter American Commission on Human Rights says Peru’s military and police forces used excessive force to quell violent anti-government protests, and that they should be investigated as possible extrajudicial executions and massacres

## Berlin police say 2 girls seriously wounded in school attack
 - [https://www.washingtonpost.com/world/2023/05/03/germany-berlin-school-attack-children-girls-wounded/51b18f66-e9c9-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/germany-berlin-school-attack-children-girls-wounded/51b18f66-e9c9-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 12:19:34+00:00

Berlin police say two young children were seriously wounded in an attack at a school in the south of the capital

## Sudan’s warring generals closely matched ahead of latest cease-fire
 - [https://www.washingtonpost.com/world/2023/05/03/sudan-conflict-rsf-military/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/sudan-conflict-rsf-military/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 12:10:04+00:00

The military and the RSF have divided up Sudan's towns, factories and resources between them as neither side appears to have the immediate upper hand.

## Juan Guaidó says he felt U.S. pressure to get on plane to Miami
 - [https://www.washingtonpost.com/world/2023/05/03/guaido-interview-colombia-venezuela-miami/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/guaido-interview-colombia-venezuela-miami/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 11:23:37+00:00

The Venezuelan opposition leader appeared in Bogotá last week hoping to attend an international summit. Instead, he told The Washington Post, he felt pressured to leave by U.S. and Colombian officials.

## Report: Taliban interfering with NGO work in Afghanistan
 - [https://www.washingtonpost.com/world/2023/05/03/afghanistan-taliban-ngo-rifle-harassment-women/babddd0e-e995-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/afghanistan-taliban-ngo-rifle-harassment-women/babddd0e-e995-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 11:23:21+00:00

A U.S. report says a Taliban fighter fired his rifle into the air during a food distribution event recently in Afghanistan, citing it as an example of their harassment of nongovernmental groups working in the country

## Bolsonaro’s vaccine status forged before entering U.S., police say
 - [https://www.washingtonpost.com/world/2023/05/03/bolsonaro-vaccination-covid-police-raid/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/bolsonaro-vaccination-covid-police-raid/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 11:08:52+00:00

Bolsonaro, a longtime skeptic of the coronavirus vaccines, has repeatedly said he would not be vaccinated: "Let me die."

## Belizeans question the role of the British monarchy ahead of coronation
 - [https://www.washingtonpost.com/world/2023/05/03/coronation-charles-belize-commonwealth/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/coronation-charles-belize-commonwealth/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 11:00:09+00:00

The Central American nation is a British commonwealth realm with King Charles III as its monarch and head of state.

## US military says it targeted senior al-Qaida leader in Syria
 - [https://www.washingtonpost.com/world/2023/05/03/syria-alqaida-idlib-centcom/9be18cdc-e9c2-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/syria-alqaida-idlib-centcom/9be18cdc-e9c2-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 10:55:56+00:00

The U.S. military says it has carried out a drone strike in northwestern Syria targeting a senior al-Qaida leader

## Ancient Knights of Malta gets its first nonaristocratic head
 - [https://www.washingtonpost.com/world/2023/05/03/vatican-pope-knights-of-malta-john-dunlap/a5f7b7c6-e9bf-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/vatican-pope-knights-of-malta-john-dunlap/a5f7b7c6-e9bf-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 10:34:45+00:00

A Canadian lawyer who found his vocation caring for AIDS patients in Harlem has been elected the grand master of the Knights of Malta

## Fossils or not? Nations split on how to meet climate goals
 - [https://www.washingtonpost.com/world/2023/05/03/germany-climate-talks/626a94ee-e9b8-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/germany-climate-talks/626a94ee-e9b8-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 09:42:45+00:00

Senior officials from dozens of nations meeting in Berlin remain divided on how to meet international climate goals

## UN humanitarian chief in Sudan, seeking guarantees on aid
 - [https://www.washingtonpost.com/world/2023/05/03/sudan-humanitarian-port-un-displaced-evacuations/4d7b905c-e994-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/sudan-humanitarian-port-un-displaced-evacuations/4d7b905c-e994-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 09:31:22+00:00

The U.N.’s humanitarian chief has arrived in Sudan’s main seaport, as thousands of Sudanese and foreign nationals gather there, hoping to flee the conflict-torn east African country

## King Charles III: Memorable quotes from his decades as an outspoken royal
 - [https://www.washingtonpost.com/world/2023/05/03/king-charles-quotes/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/king-charles-quotes/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 09:23:31+00:00

Before becoming king, Charles shared his views on topics from "monstrous carbuncle" architecture to the "headless chicken brigade" of climate deniers.

## Swiss lower house approves closer ties to Taiwan legislature
 - [https://www.washingtonpost.com/world/2023/05/03/taiwan-china-switzerland-parliament/6ddb1984-e9b3-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/taiwan-china-switzerland-parliament/6ddb1984-e9b3-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 09:07:17+00:00

Switzerland’s lower house of parliament has voted to tighten ties with the legislature in Taiwan, a move that could further rankle China after recent visits by Western lawmakers to the island

## These people want to flee Sudan. Their passports are locked in empty embassies.
 - [https://www.washingtonpost.com/world/2023/05/03/sudan-embassy-passports/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/sudan-embassy-passports/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 09:00:12+00:00

Some Sudanese are trapped in the country with their passports in the custody of embassies that evacuated staff without returning travel documents.

## Severe flooding in Italy kills 2; drought persists
 - [https://www.washingtonpost.com/world/2023/05/03/floods-agriculture-drought-deaths-italy/3de047be-e9b2-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/floods-agriculture-drought-deaths-italy/3de047be-e9b2-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 08:58:47+00:00

Heavy rains have caused flooding in Italy’s populous Emilia-Romagna region, leaving at least two people dead as riverbeds left dry by drought overflowed their banks after a day and a half of non-stop rain

## Turkey closes airspace to Armenian flights over monument
 - [https://www.washingtonpost.com/world/2023/05/03/turkey-armenia-monument-airspace-closed/961a7cea-e9af-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/turkey-armenia-monument-airspace-closed/961a7cea-e9af-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 08:39:46+00:00

Turkey’s foreign minister says his country has closed its airspace to Armenian aircraft, in retaliation for the erection of a monument in the Armenian capital, Yerevan

## Kremlin says Ukraine sent two drones to attack Vladimir Putin
 - [https://www.washingtonpost.com/world/2023/05/03/vladimir-putin-attack-drones-kremlin/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/vladimir-putin-attack-drones-kremlin/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 08:13:42+00:00

Moscow said that two drones attempted to attack the Russian president's residence at the Kremlin in Moscow but that he was not in the building at the time. The claim could not be verified.

## In Photos: The scene after 8 children and 1 guard were killed in a school shooting in Serbia
 - [https://www.washingtonpost.com/photography/interactive/2023/photos-serbia-shooting-school-belgrade/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/photography/interactive/2023/photos-serbia-shooting-school-belgrade/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 07:17:43+00:00

Eight children and a security guard were killed after a seventh grade student opened fire at a school in the Serbian capital of Belgrade on Wednesday morning, authorities said.

## UN denounces Taliban intimidation, attacks on Afghan media
 - [https://www.washingtonpost.com/world/2023/05/03/afghanistan-taliban-press-freedom/88588390-e9a0-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/afghanistan-taliban-press-freedom/88588390-e9a0-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 06:52:01+00:00

The United Nations says the Taliban’s intimidation, threats and attacks on Afghan journalists are unacceptable

## Autopsies find some victims of Kenya starvation cult were suffocated
 - [https://www.washingtonpost.com/world/2023/05/03/kenya-starvation-cult-preacher-smothering/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/kenya-starvation-cult-preacher-smothering/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 06:51:26+00:00

At least 110 bodies have been exhumed so far, as authorities investigate what appears to be a religious cult that preached starvation to its members.

## Germany: School evacuated over suspected gas exposure
 - [https://www.washingtonpost.com/world/2023/05/03/germany-school-gas-exposure-evacuated/d60d2b96-e99f-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/germany-school-gas-exposure-evacuated/d60d2b96-e99f-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 06:47:01+00:00

Exposure to a suspected irritant gas has affected at least 70 people at a school in southwestern Germany, according to a media report

## 12 die in explosion, helicopter crash during Chinese holiday
 - [https://www.washingtonpost.com/world/2023/05/03/china-explosion-helicopter-crash-may-day/ed723b8e-e998-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/china-explosion-helicopter-crash-may-day/ed723b8e-e998-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 06:14:45+00:00

At least nine people were killed in an explosion at a Chinese petrochemical plant and three others died in a helicopter crash during the country’s May Day holiday

## Turkish singer sentenced over joke on religious schools
 - [https://www.washingtonpost.com/world/2023/05/03/turkish-singer-sentenced-joke-religious-schools/e1625d9a-e99a-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/turkish-singer-sentenced-joke-religious-schools/e1625d9a-e99a-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 06:11:33+00:00

A Turkish court has given pop singer Gulsen a 10-month suspended sentence after convicting her of “inciting hatred and enmity” over a joke about Turkey’s religious schools

## 8 children, 1 guard killed in rare school shooting in Serbia
 - [https://www.washingtonpost.com/world/2023/05/03/serbia-shooting-school-belgrade/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/serbia-shooting-school-belgrade/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 06:08:10+00:00

Officials said a seventh grader suspected of opening fire at a Belgrade school was arrested. Authorities said six children and a teacher were also injured.

## Dissident pulled off plane by Belarus gets 8 years in prison
 - [https://www.washingtonpost.com/world/2023/05/03/journalist-belarus-dissident-sentenced/80f170aa-e994-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/journalist-belarus-dissident-sentenced/80f170aa-e994-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 06:05:24+00:00

A Belarusian court has convicted a dissident journalist who was arrested after being pulled off a commercial flight that was diverted to the country

## Fire rages at Russian oil depot; Zelenskyy visits Finland
 - [https://www.washingtonpost.com/world/2023/05/03/russia-ukraine-war-drone-attacks-ammunition/595eab74-e995-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/russia-ukraine-war-drone-attacks-ammunition/595eab74-e995-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 06:05:03+00:00

Officials say a massive blaze has broken out at a Russian oil depot

## Courtiers make life for Britain’s royals possible — and for some miserable
 - [https://www.washingtonpost.com/world/2023/05/03/royals-courtiers-king-charles-harry-behind-the-scenes/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/royals-courtiers-king-charles-harry-behind-the-scenes/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 06:00:29+00:00

The Washington Post sat down for a talk with Britain's premier chronicler of court life, Valentine Low about what goes on behind the scenes of royal life.

## Israel-Gaza hostilities new test Netanyahu’s hard-right government
 - [https://www.washingtonpost.com/world/2023/05/03/israel-palestinian-rockets-adnan-khader/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/israel-palestinian-rockets-adnan-khader/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 05:54:40+00:00

An internationally-brokered cease-fire is holding for now, but several hard-right members of the government have pushed for harsher measures in the face of Gaza rocket attacks.

## Ukraine's Zelenskyy in Finland for summit of Nordic leaders
 - [https://www.washingtonpost.com/world/2023/05/03/finland-nordics-ukraine-zelenskyy/f41357dc-e990-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/finland-nordics-ukraine-zelenskyy/f41357dc-e990-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 05:14:06+00:00

Ukrainian President Volodymyr Zelenskyy is in the Finnish capital, Helsinki, for a one-day Nordic summit

## US Navy: Iran seizes oil tanker in Strait of Hormuz
 - [https://www.washingtonpost.com/world/2023/05/03/iran-us-oil-tanker-seizure-strait-of-hormuz/c0929a80-e990-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/iran-us-oil-tanker-seizure-strait-of-hormuz/c0929a80-e990-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 05:13:20+00:00

Iran seized a Panama-flagged oil tanker in the Strait of Hormuz on Wednesday, the second-such capture by Tehran in recent days

## Pope greets Russian Orthodox envoy amid peace mission talk
 - [https://www.washingtonpost.com/world/2023/05/03/russia-ukraine-orthodox-pope-vatican/8afeb814-e98f-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/russia-ukraine-orthodox-pope-vatican/8afeb814-e98f-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 04:50:24+00:00

Pope Francis has greeted the foreign envoy of the Russian Orthodox Church at the Vatican

## Palace weapons arrest comes amid coronations security push
 - [https://www.washingtonpost.com/world/2023/05/03/charles-coronation-palace-arrest-security/b2e58656-e98e-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/charles-coronation-palace-arrest-security/b2e58656-e98e-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 04:44:21+00:00

Britain’s security minister says the coronation of King Charles III involves one of the most important security operations in U.K. history

## One of the world’s priciest cities raises minimum wage – to $5
 - [https://www.washingtonpost.com/world/2023/05/03/hong-kong-minimum-wage-cost-living/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/hong-kong-minimum-wage-cost-living/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 04:37:23+00:00

Hong Kong labor groups said the first wage raise in four years wasn't enough in a city with famously expensive and cramped housing.

## Teenage boy opens fire in school in Serbian capital
 - [https://www.washingtonpost.com/world/2023/05/03/serbia-shooting-school/e3e7df32-e985-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/serbia-shooting-school/e3e7df32-e985-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 04:18:41+00:00

Serbian police say that a teenage boy has opened fire in a school in central Belgrade, causing injuries

## Priest, scientist on trial in Germany over climate protest
 - [https://www.washingtonpost.com/world/2023/05/03/germany-climate-activists-trial-court-jesuit-priest/adfc2a54-e98a-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/germany-climate-activists-trial-court-jesuit-priest/adfc2a54-e98a-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 04:15:35+00:00

A Jesuit priest and a scientist are appearing before a court in Munich charged with coercion in connection with a climate protest last year

## Iran's president lands in Syria for rare meeting with Assad
 - [https://www.washingtonpost.com/world/2023/05/03/syria-iran-raisi-assad-war/471d726c-e984-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/syria-iran-raisi-assad-war/471d726c-e984-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 04:13:04+00:00

Iran’s president has landed in Damascus on the first visit by an Iranian head of state to war-wracked Syria since Tehran helped tip the balance of power there to the government

## UN: 258 million people faced acute food insecurity in 2022
 - [https://www.washingtonpost.com/world/2023/05/03/un-hunger-ukraine-covid/964b0dfe-e989-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/un-hunger-ukraine-covid/964b0dfe-e989-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 04:07:46+00:00

A report says more than a quarter-billion people in 58 countries faced acute food insecurity last year

## French constitutional body rules on pension referendum call
 - [https://www.washingtonpost.com/world/2023/05/03/france-retirement-age-constitutional-council/f37fae36-e988-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/france-retirement-age-constitutional-council/f37fae36-e988-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 04:03:12+00:00

France’s top constitutional body is to rule on a last-ditch effort by opposition lawmakers to thwart President Emmanuel Macron’s move to raise the retirement age to 64, through a possible referendum or new bill restoring the pension age to 62

## In coronation, King Charles carries on a medieval tradition
 - [https://www.washingtonpost.com/world/2023/05/03/coronation-king-charles-queen-elizabeth/5449f11a-e982-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/coronation-king-charles-queen-elizabeth/5449f11a-e982-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 03:15:48+00:00

Great Britain’s royal family turns the page on a new chapter with the coronation of King Charles III

## Showtime! UK readies pomp for King Charles III's coronation
 - [https://www.washingtonpost.com/world/2023/05/03/king-charles-iii-coronation-britain-crown-monarchy/c9285b5c-e97d-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/king-charles-iii-coronation-britain-crown-monarchy/c9285b5c-e97d-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 02:43:17+00:00

King Charles III will be crowned Saturday at Westminster Abbey in an event full of all the pageantry Britain can muster

## Syrian refugees fearful as Lebanon steps up deportations
 - [https://www.washingtonpost.com/world/2023/05/03/lebanon-refugees-syria-arrests-deportations/56d27498-e97d-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/lebanon-refugees-syria-arrests-deportations/56d27498-e97d-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 02:40:05+00:00

Lebanese officials have launched a crackdown on the country’s Syrian refugees against the backdrop of a worsening economic crisis and political stalemate

## German police clamp down on Italian mob with raids, arrests
 - [https://www.washingtonpost.com/world/2023/05/03/germany-europe-italy-raids-ndrangheta/2900fb76-e97c-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/germany-europe-italy-raids-ndrangheta/2900fb76-e97c-11ed-869e-986dd5713bc8_story.html?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 02:31:39+00:00

Police have arrested suspects and raided homes across Germany in a massive effort to clamp down on member of the Italian ’ndrangheta organized crime syndicate

## Love, ambition, no politics: Chinese women flock to read Eileen Chang
 - [https://www.washingtonpost.com/world/2023/05/03/china-writer-eileen-chang-lust-caution/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/china-writer-eileen-chang-lust-caution/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 02:06:28+00:00

Celebrated novelist Eileen Chang is enjoying a new surge in popularity in China, especially among young women looking to navigate social expectations.

## Ukraine live briefing: Moscow seeks to replenish arms; E.U. to boost ammunition stock for Kyiv
 - [https://www.washingtonpost.com/world/2023/05/03/russia-ukraine-war-news/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/russia-ukraine-war-news/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 02:01:04+00:00

Russian Defense Minister Sergei Shoigu said Moscow has made improvements in repairing arms and military vehicles but wants to intensify such efforts.

## The death toll in Ukraine is huge. It may still be far behind Tigray.
 - [https://www.washingtonpost.com/world/2023/05/03/tigray-ethiopia-casualty-death-ukraine-russia/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world](https://www.washingtonpost.com/world/2023/05/03/tigray-ethiopia-casualty-death-ukraine-russia/?utm_source=rss&utm_medium=referral&utm_campaign=wp_world)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-05-03 00:00:26+00:00

For all the weight of its brutality and violence, the war in Ukraine was not even the single deadliest conflict in the world last year.

