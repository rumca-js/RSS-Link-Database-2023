# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## Microsoft is pushing Edge with dirty tricks, again
 - [https://www.pcworld.com/article/1807165/microsoft-is-pushing-edge-with-dirty-tricks-again.html](https://www.pcworld.com/article/1807165/microsoft-is-pushing-edge-with-dirty-tricks-again.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 16:11:35+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Microsoft Edge, the default web browser that comes pre-installed on approximately 1.4 billion Windows PCs, <a href="https://www.pcworld.com/article/394959/why-switch-google-chrome-microsoft-edge.html">is pretty darn good</a>. Over the last few years Microsoft has invested a lot of time and money in expanding its features to compete with Chrome. So it&rsquo;s a shame that I have to tell you, <em>once again</em>, that Microsoft is abusing its position as the publisher of Windows to try and force its users onto its first-party browser. </p>



<p>Earlier this week, some Windows users found that every time they opened Chrome, the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://gizmodo.com/microsoft-windows-google-chrome-feature-broken-edge-1850392901&amp;xcust=2-3-1807165-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Windows default app settings window would open too</a>. Some of them reported that the window would open <em>every time they clicked a link </em>in the browser, so long as Chrome was set to the default. The issue seemed to be especially common for Windows Enterprise users. Apparently it was a problem with the KB5025221 Windows update issued in April, which broke Chrome&rsquo;s one-click option to change the default browser, a feature Google introduced last year. Gizmodo reports that simply changing the name of the Chrome executable was enough to avoid the issue, indicating that Microsoft&rsquo;s update specifically targeted Chrome&rsquo;s default button behavior. </p>



<p>But that&rsquo;s not the end of the story. Just this morning Microsoft announced that a new update to the desktop versions of Outlook and Teams <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.tomshardware.com/news/microsoft-edge-365-outlook-teams-link-hijacking&amp;xcust=2-3-1807165-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">will force links to open in the Edge browser</a>, ignoring the user&rsquo;s default settings if they&rsquo;re assigned to another browser. Not only is it a flagrant abuse of Microsoft&rsquo;s position as the publisher of Windows and its associated tools, it&rsquo;s blatantly ignoring Windows&rsquo; users ability to set custom app associations with files and links. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Edge browser search" class="wp-image-1807309" height="596" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/edge-browser-search.jpg?quality=50&amp;strip=all" width="1024" /><figcaption><p>Making searches from the Windows Start menu will open Bing in Edge, no matter what your default browser. And if it isn&rsquo;t set to Edge, you&rsquo;ll get a little banner telling you to change it.&nbsp;</p></figcaption></figure><p class="imageCredit">Michael Crider/Foundry</p></div>



<p>Pushing Edge (and formerly Internet Explorer) on users with these passive-aggressive tactics is nothing new for Microsoft. In fact it <a href="https://www.pcworld.com/article/401698/microsoft-tries-forcing-mail-users-to-open-links-in-edge-and-people-are-freaking-out.html" rel="noreferrer noopener" target="_blank">tried precisely the same tactic</a> with the default Mail program five years ago. The Settings menu for apps still begs you to try Edge the first time you change the default browser, and making web searches from the Start menu will <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://answers.microsoft.com/en-us/windows/forum/all/windows-search-bar-opens-always-microsoft-edge-and/ff59a0db-6cfa-4118-8d29-a34f5310aa85&amp;xcust=2-3-1807165-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">ignore your default browser setting</a> if it isn&rsquo;t Edge. Edge still periodically nags you to change your default when you open it, which is particularly cheeky since apparently Microsoft has intentionally hamstrung Chrome&rsquo;s ability to do <em>exactly the same thing</em>. </p>



<p>But there&rsquo;s a certain irony in these latest attempts to push Edge on users, just a few weeks after <a href="https://www.pcworld.com/article/1665135/needy-windows-apps-are-going-to-beg-you-to-pin-them.html" rel="noreferrer noopener" target="_blank">a Microsoft representative said</a>, &ldquo;We have taken and will continue to take steps to mitigate unrequested modifications to a user&rsquo;s choices.&rdquo; It doesn&rsquo;t help that last week <a href="https://www.pcworld.com/article/1801888/microsoft-edge-maybe-you-should-slow-your-roll-a-little.html" rel="noreferrer noopener" target="_blank">Edge was caught sending user traffic data to Bing</a> &mdash; an alleged bug that Microsoft patched quickly, but not quickly enough to give a black eye to the company&rsquo;s boasts of security and privacy <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.microsoft.com/en-us/edge?form=MA13FJ&amp;exp=e00&amp;xcust=2-3-1807165-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">on the browser&rsquo;s promotional page</a>. </p>



<p>Microsoft, in the wise if uncouth words of my Texan grandpa, &ldquo;Don&rsquo;t piss on my boots and tell me it&rsquo;s raining.&rdquo; Eight years after its introduction, and despite being installed on over a billion machines, <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://gs.statcounter.com/browser-market-share/desktop/worldwide&amp;xcust=2-3-1807165-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Edge has just 10.95 percent of the desktop browser market</a> &mdash; even less than Apple&rsquo;s Safari as of this month. It&rsquo;s clear that no amount of manipulative tricks are going to force Windows users off of their preferred browser, so it would be wise to stop trying. </p>



<p>To paraphrase <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.youtube.com/watch?v=gZzdqTY-aKw&amp;xcust=2-3-1807165-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">another great Texan philosopher</a>, &ldquo;You&rsquo;re not making Edge better, you&rsquo;re just making Windows worse.&rdquo; </p>

Windows</div>

## Hey Utah: These are the excellent VPNs you’re searching for
 - [https://www.pcworld.com/article/1807277/hey-utah-these-are-the-excellent-vpns-youre-searching-for.html](https://www.pcworld.com/article/1807277/hey-utah-these-are-the-excellent-vpns-youre-searching-for.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 16:06:31+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Today, a new law took effect in Utah, requiring websites to verify the ages of users attempting to view adult content. In response, the ultra-popular PornHub and numerous other&hellip; <em>adult</em> sites went dark in Utah, replacing the NSFW videos you&rsquo;d normally expect to see with a message decrying government overreach and proposed compromises.</p>



<p>You can read excerpts and a rundown of the complicated political situation in <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.cnn.com/2023/05/02/tech/pornhub-utah-age-verification/index.html&amp;xcust=2-3-1807277-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">CNN&rsquo;s coverage</a> if you want. What caught my eye was NBC News&rsquo; dystopia beat reporter Ben Collins noticing that Google searches for &ldquo;VPN&rdquo; immediately skyrocketed in Utah as folks looked to circumvent the ban. I <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://trends.google.com/trends/explore?q=vpn&amp;date=now%201-d&amp;geo=US&amp;hl=en&amp;xcust=2-3-1807277-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">checked Google Trends myself</a> and yep, Utah now shows 100 percent interest for &ldquo;VPN.&rdquo;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="A screenshot of Google Trends on 5/3/23 showing VPN search interest in Utah at 100" class="wp-image-1807292" height="508" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/vpn-interest-utah.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>A screenshot of Google Trends on 5/3/23 showing VPN search interest in Utah at 100</p>
</figcaption></figure><p class="imageCredit">Brad Chacos/IDG</p></div>



<p>I don&rsquo;t know much about politics, but we sure know VPNs here at PCWorld! I&rsquo;m not encouraging circumventing laws whatsoever, but if you&rsquo;re a Utah resident who just so happens to be looking for a VPN for totally legal reasons, here are some especially choice picks, culled from our roundup of the <a href="https://www.pcworld.com/article/406870/best-vpn-services-apps-reviews-buying-advice.html">best VPN services</a>.</p>



<h2 id="nordvpn">NordVPN</h2>



		<div class="wp-block-product-widget-block product-widget">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="">
									</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="nordvpn">NordVPN</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="NordVPN" class="product-widget__image" height="675" src="https://b2c-contenthub.com/wp-content/uploads/2021/09/nordvpnlogo.jpg?quality=50&amp;strip=all" width="1200" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/398777/nordvpn-review-3.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://go.nordvpn.net/aff_c?offer_id=15&amp;aff_id=2873&amp;aff_sub=2-3-1807277-5-392013-17957" rel="nofollow" target="_blank">$3.49 at  NordVPN</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p>If you&rsquo;re looking for an inexpensive VPN that doesn&rsquo;t log the sites you visit and provides fairly anonymous payment methods, <a href="https://www.pcworld.com/article/398777/nordvpn-review-3.html">NordVPN</a> is a fine choice. It&rsquo;s loaded with features and offers fast servers perfect for streaming videos. The one downside? While it only costs $3.29 per month if you commit to a two-year plan, it costs $12.99 monthly if you don&rsquo;t want to sign up for a long term contract.</p>



<h2 id="mullvad">Mullvad</h2>



		<div class="wp-block-product-widget-block product-widget">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="">
									</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="mullvad">Mullvad</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Mullvad" class="product-widget__image" height="400" src="https://images.idgesg.net/images/article/2017/06/mullvadhero-100726436-orig.jpg?quality=50&amp;strip=all" width="700" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/395038/mullvad-vpn-review-2.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.mullvad.net/en/&amp;xcust=2-3-1807277-5-246276-16447&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">&pound;5 at  Amagicom AB</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p>This might be a better option, however. <a href="https://www.pcworld.com/article/395038/mullvad-vpn-review-2.html">Mullvad</a> isn&rsquo;t just in our top five VPNs for overall speeds, it more importantly earns top marks for privacy, taking seemingly every effort to know as little as possible about its users. From our roundup:</p>



<p>&ldquo;We&rsquo;ve never seen another VPN that actively resists knowing who you are the way Mullvad does. Mullvad doesn&rsquo;t ask for your email address, name, or anything else. Instead it assigns a random account number that acts as your identifier and login. Mullvad accepts payments using standard methods such as credit cards and PayPal, but you can also mail your payment in cash to remain as private as possible. Mullvad has a no-logging policy and doesn&rsquo;t collect any identifying metadata from your usage.&rdquo;</p>



<p>Better yet, it costs just $5 per month regardless of the plan you choose.</p>



<h2 id="avg-secure">AVG Secure</h2>



		<div class="wp-block-product-widget-block product-widget">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="">
									</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="avg-secure">AVG Secure</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="AVG Secure" class="product-widget__image" height="827" src="https://b2c-contenthub.com/wp-content/uploads/2022/04/avg-secure.png" width="1200" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
													<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/394897/avgsecure-vpn-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
									</div>
			</div>
		</div>

		


<p>Finally, we love the simplicity of <a href="https://www.pcworld.com/article/394897/avgsecure-vpn-review.html">AVG Secure</a>, which was crowned the best VPN for novices. It&rsquo;s easy to use, backed by a well-known security brand and&mdash;get this&mdash;it includes a free 60 day trial. Lots (including laws) can change in 60 days.</p>



<p>If you&rsquo;re looking for a no-cost VPN, we&rsquo;d suggest giving AVG Secure a whirl. While <a href="https://www.pcworld.com/article/629037/best-free-vpn.html">free VPNs exist</a>, they tend to limit your speeds and overall bandwidth, while often collecting data about users in aggregate and sometimes serving ads that could be used to surreptitiously track your browsing. If you&rsquo;re worried about staying as anonymous as possible, paid VPNs are the way to go.</p>



<p>Happy surfing! (But not <em>too </em>happy).</p>

VPN</div>

## IDrive gets even better with unlimited backups of your Google, Microsoft cloud
 - [https://www.pcworld.com/article/1806088/idrive-adds-20-cloud-to-cloud-backup.html](https://www.pcworld.com/article/1806088/idrive-adds-20-cloud-to-cloud-backup.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 15:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>iDrive is trying something a little different in cloud backups: Backing up your entire Google Workspace or Microsoft 365 storage, for only $20 per year per computer.</p>



<p>Confused? Then let&rsquo;s, er, back up. <a href="https://www.pcworld.com/article/407286/idrive-review-online-backup-for-the-person-who-wants-everything.html">IDrive is one of our most highly recommended cloud backup options</a>, able to back up your PC to the cloud with either a free plan or paid options that go all the way to 20TB. It&rsquo;s basically one of the only good independent cloud storage/backup providers that isn&rsquo;t a major corporation like Google or Microsoft.</p>



<p>Due to be formally announced Thursday, IDrive will now offer unlimited cloud backup for both Google Workspace (Google Drive, Gmail, Calendar, and Contacts) and Office 365 (OneDrive, Exchange, SharePoint, and Teams), called Unlimited Cloud to Cloud Backup. What IDrive will do is back up all of your files in the Google or Microsoft cloud over to to IDrive as well. And if you pay for extra storage in either service, IDrive can accommodate all of those files. </p>



		<div class="wp-block-product-widget-block product-widget">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="">
									</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="idrive-online-cloud-backup">iDrive Online Cloud Backup</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="iDrive Online Cloud Backup" class="product-widget__image" height="945" src="https://images.idgesg.net/images/article/2017/09/idrive_logo_300-100737328-orig.jpg?quality=50&amp;strip=all" width="2244" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/407286/idrive-review-online-backup-for-the-person-who-wants-everything.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://www.idrive.com/idrive/signup/el/pcw80" rel="nofollow" target="_blank">$79.50 at  iDrive</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p>Why do this? It&rsquo;s an additional layer of security for those who worry about cloud services going down and data being unable to accessed. It sounds a little far-fetched &mdash; until you remember that <a href="https://www.pcworld.com/article/1681254/western-digitals-my-cloud-goes-down-after-hack.html">Western Digital&rsquo;s cloud service was down for over a week</a>. That&rsquo;s why the &ldquo;rule of three&rdquo; exists: You should have your <a href="https://www.pcworld.com/article/1684372/wds-my-cloud-outage-proves-the-rule-of-three-in-a-harsh-way.html">data stored in three places</a>, just in case: a local copy and two backups. That&rsquo;s what IDrive is offering.</p>



<p>IDrive&rsquo;s Unlimited Cloud to Cloud Backup backs up data from the other clouds three times per day. It retains snapshots of previous versions, allowing you to restore your data from a given point in time &mdash; and not just all of it at once. You can seek out and restore individual files and folders, too. IDrive considers this service to be an add-on, meaning that you can attach it to existing IDrive plans. (You can also buy Unlimited Cloud to Cloud Backup as a standalone service.)</p>



<p>IDrive seems to be pitching this as a solution for individuals, families or small businesses, since a demonstration video showed a backup of a Microsoft cloud with about twenty different users. The only catch, if there is one, is that IDrive charges the $20 annual fee (or roughly $1.66 per month) per computer for backing up one service, <a href="https://www.idrive.com/google-workspace-backup/">Google Drive</a> or <a href="https://www.idrive.com/microsoft-office-365-backup/">Microsoft Office 365</a>.</p>

Storage</div>

## Viewsonic VG2756V-2K review: A video-conferencing powerhouse monitor
 - [https://www.pcworld.com/article/1799741/viewsonic-vg2756v-2k-review.html](https://www.pcworld.com/article/1799741/viewsonic-vg2756v-2k-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 14:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Bundled webcam, microphone, and speakers</li><li>USB-C port with 90 watts power delivery</li><li>Sturdy and functional design</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>Mediocre image quality</li><li>No HDR</li><li>Bundled features add to the price</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">The Viewsonic VG2756V-2K&rsquo;s built-in webcam, microphone, and USB-C hub make it a great fit in any home office setup.</p>
</div>
				<h3 class="review-best-price" id="best-prices-today-viewsonic-vg2756v-2k">
			Best Prices Today: Viewsonic VG2756V-2K		</h3>
				<div class="wp-block-price-comparison price-comparison ">
			<div class="price-comparison__record price-comparison__record--header">
				<div>
					<span>Retailer</span>
				</div>
				<div class="price-comparison__price">
					<span>Price</span>
				</div>
			</div>

														<div class="price-comparison__record">
							<div class="price-comparison__image">
																	<span>B&amp;H Photo</span>
															</div>
							<div class="price-comparison__price">
								<span>$399.99</span>
							</div>
							<div>
								<a class="price-comparison__view-button" href="https://www.bhphotovideo.com/c/product/1734170-REG/viewsonic_vg2756v_2k_27_qhd_docking_video.html/?msclkid=2c029cd462c0185e8895f89d11c0887f?BI=21883&amp;KBID=28249" rel="nofollow" target="_blank">View Deal</a>							</div>
						</div>
															<div class="price-comparison__record">
							<div class="price-comparison__image">
																	<span>Viewsonic</span>
															</div>
							<div class="price-comparison__price">
								<span>$404.99</span>
							</div>
							<div>
								<a class="price-comparison__view-button" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.viewsonic.com/us/vg2756v-2k.html&amp;xcust=2-1-1799741-2-1799773-10068&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">View Deal</a>							</div>
						</div>
												<div class="price-comparison__record price-comparison__record--footer">
					<span class="price-comparison__footer-text">
													Price comparison from over 24,000 stores worldwide												</span>
									</div>
						</div>
		


<p>Video conferencing is an all-too-familiar part of every white-collar workday. Even individuals who frequently clock in at an office are likely to attend a majority of meetings through video calls. The VG2756V-2K adapts to this new reality with a built-in webcam, microphone, and speakers.</p>



<blockquote class="wp-block-quote"><p><strong>Further reading: </strong>See our roundup of the <a href="https://www.pcworld.com/article/1389780/best-home-office-monitors.html">best home office monitors</a> to learn about competing products.</p></blockquote>



<h2 id="viewsonic-vg2756v-2k-specs-and-features">Viewsonic VG2756V-2K specs and features</h2>



<p>Viewsonic&rsquo;s VG2756V-2K is all about the extras. It has a 1080p webcam with integrated lightbar, a noise-canceling microphone, and a soundbar with two 5-watt speakers. These extras are accessible over both USB-C and USB-B.</p>



<ul><li>Display size: 27-inch widescreen</li><li>Native resolution: 2560&times;1440</li><li>Panel type: IPS LCD</li><li>Refresh rate: 60Hz</li><li>Adaptive-Sync: None</li><li>HDR: None</li><li>Ports: 1x USB-C with DisplayPort Alternate Mode and 90 watts Power Delivery, 1x USB-B Upstream, 2x USB-A, 1x HDMI 1.4, 1x DisplayPort 1.2, 1x Ethernet (RJ45), 1x 3.5mm audio</li><li>Stand adjustment: Height, swivel, tilt, pivot</li><li>VESA mount: Yes, 100x100mm</li><li>Webcam: 1080p with lightbar</li><li>Microphone: Integrated noise-cancelling</li><li>Speakers: Yes, 2x 5W</li><li>Price: $399.99 MSRP</li></ul>



<p>The VG2756V-2K&rsquo;s current retail price of $399.99 is expensive for a 27-inch 1440p monitor but justified by the bundled features. Viewsonic also offers a 24-inch 1080p version with the same features for $299.99.</p>



<h2 id="viewsonic-vg2756v-2k-design">Viewsonic VG2756V-2K design</h2>



<p>The Viewsonic VG2756V-2K is clearly focused on home-office and corporate-office use, and that&rsquo;s reflected in its design. It&rsquo;s as barebones as can be with simple, unobjectionable matte-black plastics on both front and rear. Even the fabric covering the soundbar is matte black, seamlessly blending into the bezels.</p>



<p>It&rsquo;s a well-built monitor with thick plastic panels and good material quality across also surfaces. I&rsquo;d even argue it looks upscale in its own, subtle way. The fabric over the speaker is an especially nice touch.</p>



<p>Viewsonic includes a versatile ergonomic stand that adjusts for height, tilt, swivel, and can pivot 90 degrees (in both directions) for use in portrait orientation. It has a simple, compact, yet sturdy stand with a flat base that minimizes its footprint on a desk. That&rsquo;s a good choice for any display but doubly important for a home office monitor. A 100x100mm VESA mount is available, as well, for adding a third-party monitor stand or arm.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Viewsonic VG2756V-2K back" class="wp-image-1799765" height="800" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/viewsonic-vg-2756v-2k-5.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>The Viewsonic VG2756V-2K feaures a simple, well-built design that will blend in with any home office.</p></figcaption></figure><p class="imageCredit">Matt Smith/Foundry</p></div>



<h2 id="viewsonic-vg2756v-2k-features-and-menus">Viewsonic VG2756V-2K features and menus</h2>



<p>The VG2756V-2K is a &ldquo;video conferencing monitor&rdquo; with a built-in webcam, microphone, and speakers. It even throws in a pair of LED lights to help brighten up your face during video calls.</p>



<p>Video quality is fine. The included webcam is capable of 1080p resolution but still suffers the grainy look common to webcams. It&rsquo;s a step up from most laptop webcams or a budget standalone webcam, but it won&rsquo;t beat a quality desktop webcam. The webcam snaps into the body of the monitor when not in use, which effectively works as a privacy shutter. This also disables the microphone.&nbsp;</p>



<p>The microphone&rsquo;s volume is a little low, but it handled background noise well and didn&rsquo;t echo when audio was produced from the speakers. The monitor even includes several settings to increase background noise reduction. Soft, humming background noise (such as a space heater) was eliminated.</p>



<figure class="wp-block-pullquote"><blockquote><p>The VG2756V-2K is a well-built monitor with thick plastic panels and good material quality across also surfaces. I&rsquo;d even argue it looks upscale in its own, subtle way.</p></blockquote></figure>



<p>A healthy range of connectivity can be found on the VG2756V-2K&rsquo;s rear panel including a USB-C port with DisplayPort Alternate Mode and 90 watts of Power Delivery. That&rsquo;s on the upper end of power that modern monitors can deliver and will keep many midrange laptops charged if connected over USB-C. <a href="https://www.pcworld.com/article/612470/you-should-buy-a-usb-c-hub-monitor-heres-what-you-need-to-know.html">It acts as a USB-C hub</a> for two additional USB-A ports and even an Ethernet port, which is uncommon among USB-C monitors sold below $500.</p>



<p>The USB-C port is the best way to connect with the monitor, but a USB-B upstream port is available for connecting a laptop or desktop that lacks USB-C, and supports the monitor&rsquo;s full range of features including the webcam, microphone, and Ethernet port. Additional video connectivity is provided over HDMI and DisplayPort for a total of three video inputs.</p>



<p>Menu options are controlled with touch-sensitive buttons built into the touch bar instead of the rear-mounted joystick found on most competitors. Viewsonic offers a wide range of image quality options including multiple gamma and color temperature presets and six-axis color calibration.</p>



<p>The built-in soundbar includes two 5-watt speakers. They deliver good volume but are skewed towards video conferences, not entertainment. Dialogue sounds crisp, so podcasts and YouTube videos are enjoyable, but the lack of low-end oomph cramps the midrange. Still, they&rsquo;re much better than the 2-watt speakers found in most monitors and well suited to video or audio calls.</p>



<h2 id="how-is-the-viewsonic-vg2756v-2k-image-quality">How is the Viewsonic VG2756V-2K image quality?</h2>



<p>The Viewsonic VG2756V-2K&rsquo;s has many added features, but the display panel is basic. It&rsquo;s an IPS LCD with 2560&times;1440 resolution and a refresh rate of 60Hz. Image quality in SDR is fine, but it&rsquo;s clear that this monitor is designed for day-to-day office productivity, not content creation or entertainment.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Viewsonic VG2756V-2K brightness chart" class="wp-image-1799760" height="850" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/viewsonic-vg2756v-2k-brightness.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith/Foundry</p></div>



<p>Maximum brightness comes in at a reasonable 310 nits. That&rsquo;s higher than most budget monitors but behind those that target a step up in image quality, such as the <a href="https://www.pcworld.com/article/828353/nzxt-canvas-27q-monitor-review.html">NZXT Canvas 27Q</a> and Asus ProArt PA279CRV. Still, the VG2756V-2K&rsquo;s brightness is sufficient for most situations and will only seem dim in a room with large, sunlit windows.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Viewsonic VG2756V-2K contrast chart" class="wp-image-1799758" height="843" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/viewsonic-vg2756v-2k-contrast.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith/Foundry</p></div>



<p>Contrast is average for a monitor in this category with a maximum contrast ratio of 850:1. That&rsquo;s low compared to the best monitors available today but mid-pack among monitors priced south of $500. The VG2756V-2K offers some sense of depth and dimension but can have trouble displaying detail in dark scenes, especially when viewed in a dark room.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Viewsonic VG2756V-2K color gamut chart" class="wp-image-1799759" height="836" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/viewsonic-vg2756v-2k-color-gamut.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith/Foundry</p></div>



<p>The color gamut is once again mid-pack, reaching 100 percent of sRGB but 82 percent of DCI-P3. It&rsquo;s an improvement over most inexpensive and midrange office monitors, which typically land around 77 or 78 percent of DCI-P3. Unfortunately, this small win feels a bit pointless, as 82 percent of DCI-P3 is not going to impress content creators who need to work in wider color gamuts. The gamut is great for day-to-day use, however, and it importantly manages to cover all of the sRGB color gamut, which is the color gamut most commonly targeted by computer software and games (in SDR, at least).</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Viewsonic VG2756V-2K average color error" class="wp-image-1799757" height="902" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/viewsonic-vg2756v-2k-color-accuracy.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith/Foundry</p></div>



<p>The average color error is a bit towards the high end, though not unusual for a monitor in this category. Image quality remains lifelike and realistic but some colors appear overly blue or green even when compared to other inexpensive monitors, such as the <a href="https://www.pcworld.com/article/631916/acer-k242hyl-review.html">Acer K242HYL</a>.</p>



<p>Color temperature and gamma results are mediocre, too, with a default gamma curve of 2.3 and color temperature of 7200K. These numbers mean the image appears slightly darker than it should and that whites have a noticeable shift towards blue. This can be corrected with the monitor&rsquo;s built-in preset options, though none were precisely ideal.</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="mentioned-in-this-article">
					mentioned in this article				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="acer-k242hyl">Acer K242HYL</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Acer K242HYL" class="product-widget__image" height="1000" src="https://b2c-contenthub.com/wp-content/uploads/2022/04/acer-k242hyl-2.jpg?quality=50&amp;strip=all" width="1500" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
													<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/631916/acer-k242hyl-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://adorama.rfvk.net/c/321564/1175784/1036?prodsku=ACK242HYLBIX&amp;u=https%3A%2F%2Fwww.adorama.com%2Fack242hylbix.html&amp;intsrc=CATF_9102&amp;subid1=2-1-1799741-5-632573-9925" rel="nofollow" target="_blank">$132.99 at  Adorama</a>											<span class="amp-bar"> | </span>
																		<a class="product-widget__pricing-details--link" href="https://www.jdoqocy.com/click-8200811-15180503?sid=2-1-1799741-5-632573-9925&amp;url=https://www.acer.com/ac/en/US/content/model/UM.QX2AA.B03" rel="nofollow" target="_blank">$149.99 at  Acer</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p>Sharpness is a perk. The monitor&rsquo;s 2560&times;1440 resolution packs roughly 109 pixels per inch, a big upgrade over the roughly 81 pixels per inch you&rsquo;ll find in a 27-inch 1080p monitor. Small text appears crisp and small interface elements are well-defined, a major advantage when writing in Word or editing a spreadsheet in Excel. 4K monitors like the ProArt PA279CRV are even sharper, to be sure, but also more expensive.</p>



<p>The VG2756V-2K&rsquo;s overall image quality is a mix but well-suited for its intended use. It provides a sharp, bright image with good clarity in productivity apps. The monitor also manages to avoid serious problems that might limit its appeal, such as an overly narrow color gamut or terrible contrast ratio. It&rsquo;s a functional monitor that&rsquo;s comfortable to use day-to-day.</p>



<h2 id="viewsonic-vg2756v-2k-hdr-image-quality">Viewsonic VG2756V-2K HDR image quality</h2>



<p>HDR is not supported by the Viewsonic VG2756V-2K. That may seem disappointing, given its price tag, but most monitors sold below $500 don&rsquo;t perform well in HDR whether it&rsquo;s supported or not. The VG2756V-2K&rsquo;s focus on office use makes it a particularly poor choice for HDR support, making Viewsonic&rsquo;s decision to stick with SDR a sensible choice.</p>



<h2 id="viewsonic-vg2756v-2k-motion-performance">Viewsonic VG2756V-2K motion performance</h2>



<p>The Viewsonic VG2756V-2K offers a refresh rate of 60Hz and doesn&rsquo;t include support for Adaptive Sync. That&rsquo;s not unusual for an office monitor but bad news for gamers. The monitor suffers significant motion blur that can obscure fast-moving objects and frame tearing may be visible if a game&rsquo;s V-Sync setting is off. An alternative like the NZXT Canvas 27Q is a much better choice for gaming (though you will need to bring your own webcam).</p>



<h2 id="should-you-buy-the-viewsonic-vg2756v-2k">Should you buy the Viewsonic VG2756V-2K?</h2>



<p>Viewsonic&rsquo;s VG2756V-2K is a good video conferencing monitor well suited for use in a home office, corporate office, or conference room. Video quality is not significantly better than other similar monitors but the built-in LED lights are an advantage in darker rooms. Microphone quality and speaker quality hold up well, too, and the monitor has a wide range of features.</p>



<p>Image quality is merely okay. The VG2756V-2K&rsquo;s picture looks fine, but its pricing is comparable to monitors with far better image quality like the NZXT Canvas 27Q, Gigabyte M27Q-X, and Asus ProArt PA279CRV. These don&rsquo;t offer a built-in webcam or microphone, however, so they&rsquo;re not a true alternative. The VG2756V-2K is built to make home office productivity easier and more comfortable&mdash;and, in that, it succeeds.</p>

Monitors</div>

## Get Amazon’s 55-inch 4K Fire TV for just $380
 - [https://www.pcworld.com/article/1806875/1806875.html](https://www.pcworld.com/article/1806875/1806875.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 14:00:22+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>I&rsquo;m a massive fan of smart TVs. They&rsquo;re easy to set up and nothing really beats having your favorite streaming services all in one place. If you&rsquo;ve been shopping around for a smart TV, we&rsquo;ve got a fantastic deal for you today. Amazon&rsquo;s currently selling the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.amazon.com/amazon-fire-tv-55-inch-4-series-4k-smart-tv/dp/B08P3QB66R&amp;xcust=2-1-1806875-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">55-inch 4K Fire TV for $379.99</a>, which is a savings of $140. This particular TV features 4K Ultra HD (more pixels) and HDR 10 (more vibrant darks and color). Plus, at 55-inches, it&rsquo;s the perfect size for most living rooms.</p>



<p>Amazon&rsquo;s Fire TV has four HDMI inputs and works with Alexa, so you can ask the digital assistant to search for your favorite shows, dim the lights, or show the video feed from your front door if you have compatible smart home equipment installed. The home screen seems easy enough to navigate and you can control the content on your TV thanks to the included Alexa voice remote. According to Amazon, the Fire TV 4-Series gives you &ldquo;access to over 1 million movies and TV episodes.&rdquo; You can even pair <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.amazon.com/alexa-multi-room-audio/b?node=21480962011&amp;xcust=2-1-1806875-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Echo speakers with the TV</a> or connect a soundbar to it for the ultimate movie theatre experience.</p>



<p>And did I mention this big, feature-packed TV is just $380? This is a fabulous deal. You better scoop it up sooner rather than later.</p>


<p class="cta wp-block wp-block-button"><a class="cta__btn" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.amazon.com/amazon-fire-tv-55-inch-4-series-4k-smart-tv/dp/B08P3QB66R&amp;xcust=2-1-1806875-7-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Get the 55" Amazon Fire TV for $379.99 at Amazon</a></p>
Smart TVs</div>

## RIP passwords: Google accounts now support passkeys
 - [https://www.pcworld.com/article/1806627/rip-passwords-google-accounts-now-support-passkeys.html](https://www.pcworld.com/article/1806627/rip-passwords-google-accounts-now-support-passkeys.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 13:27:52+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Managing passwords is pain. Tools exist to help (like <a href="https://www.pcworld.com/article/407092/best-password-managers-reviews-and-buying-advice.html">password managers</a>) but staying on top of them remains dreary work.</p>



<p>But a new system for securing accounts is filtering through the web&mdash;passkeys. They take away a lot of the burden associated with passwords. You simply need a device capable of serving as an authenticator to set up a passkey, then you&rsquo;ll use a biometric method on that device (face identification, fingerprint) or a PIN to authorize logins. And after much anticipation, their rollout is starting to pick up steam&mdash;as evidenced by this week&rsquo;s launch of passkey support for Google accounts, right on the eve of World Password Day 2023.</p>



<p>Passkeys first started generating buzz last year when Google, Microsoft, and Apple <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.apple.com/newsroom/2022/05/apple-google-and-microsoft-commit-to-expanded-support-for-fido-standard/&amp;xcust=2-1-1806627-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">all pledged to adopt</a> them. A form of passwordless sign-in based on <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://fidoalliance.org/&amp;xcust=2-1-1806627-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">FIDO standards</a>, passkeys manage your login info through <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.cloudflare.com/learning/ssl/what-is-asymmetric-encryption/&amp;xcust=2-1-1806627-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">public-key encryption</a> (also known as asymmetrical encryption), in which a public key and private key are generated. For a passkey, the public key is held by the website you&rsquo;re logging into, while you have the private key. You can store the private key to a device, but also sync it to an account for access from other devices. The two keys together let you to get into the website. Google first started with support for storing passkeys in Chrome and Android back in October 2022. Now you can log into your Google account via passkeys, too.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Nokia G60 smartphone in front of a vase" class="wp-image-1672625" height="675" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Nokia-G60-5G-Review_0005_IMG_6415-2.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption>Most people using passkeys will likely use a phone as their authenticating device.</figcaption></figure><p class="imageCredit">Lloyd Coombes / Foundry</p></div>



<p>Why would you want to use a passkey instead of a password when you already have a strong, unique password and <a href="https://www.pcworld.com/article/403535/two-factor-authentication-faq-sms-authenticator-security-key-icloud.html">two-factor authentication</a> (2FA) set up? Passkeys offer higher protection against data breaches. Google only has your public key, which can&rsquo;t be used to figure out your private key. Passkeys are also bound to the website they&rsquo;re generated for, which prevents bogus sites from stealing your credentials. Additional two-factor authentication isn&rsquo;t needed for added protection.</p>



<p>You don&rsquo;t have to move completely over to a passkey, however, especially if you still have questions about them after reading <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://developers.google.com/identity/passkeys&amp;xcust=2-1-1806627-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Google&rsquo;s easy-to-read overview</a> of how passkeys work. (I hope to address common concerns in a future article.) But the best way to understand how they work is to see them in action. Read on for instructions on enabling passkeys on your Google account.</p>



<blockquote class="wp-block-quote"><p><span style="text-decoration: underline;">Note:</span> At the time we tested this feature, no obvious option existed to remove passkeys once enabled. If you find that problematic, you can try passkeys on <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://passkeys.directory/&amp;xcust=2-1-1806627-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">a different service</a> where that outcome won&rsquo;t bother you.</p></blockquote>



<h2 id="how-to-enable-passkeys-on-a-google-account">How to enable passkeys on a Google account</h2>



<ol><li>Head to <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://myaccount.google.com/&amp;xcust=2-1-1806627-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow"><em>myaccount.google.com</em></a>.</li><li>On the left side of the page, click on <em>Security</em>.</li><li>Under <em>How you sign into Google</em>, click on <em>Passkeys</em>. If you don&rsquo;t see this option, you&rsquo;ll need first to click on <em>Use your phone to sign in</em> and link your account to a device like a phone or tablet.</li><li>Click on the blue <em>Use passkeys</em> button.</li></ol>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Passkey setup screen in Google account" class="wp-image-1806679" height="684" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/passkeys1_2.png" width="1024" /><figcaption>The screen you&rsquo;ll see after enabling passkeys.</figcaption></figure><p class="imageCredit">PCWorld</p></div>



<p>Any Android devices you&rsquo;re logged into with your Google account will automatically be available for passkey setup. The actual creation of the passkey won&rsquo;t happen until you first authenticate via passcode and complete the process using the device, however.</p>



<p>You can create other passkeys by clicking the white <em>Create a passkey</em> button. If you&rsquo;re on a PC that can&rsquo;t be used to create a passkey, you&rsquo;ll see a dialog box with a blue button to <em>Use another device</em>. Clicking on it will open another window with several options to choose from, including a different device. For that option, a QR code will appear that you&rsquo;ll scan with your phone or tablet&rsquo;s photo app. This is also the way to set up passkeys in a password manager. (Yep, such services are expanding and evolving, rather than waiting to die.)</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Additional passkey device added to Google account" class="wp-image-1806678" height="551" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/secondary-passkey-screenshot-2.png" width="980" /><figcaption>The confirmation screen you&rsquo;ll see after adding another passkey to your account.</figcaption></figure><p class="imageCredit">PCWorld</p></div>



<p>By the way, if you have two-factor authentication enabled on your Google account, it won&rsquo;t be asked for when you log in with a passkey. You&rsquo;ll only ever be asked for a second factor when logging in with your password. Since a passkey already requires something you know (the private encryption key stored on the device) and something you have (the phone), the thinking is that people don&rsquo;t need another layer for login.</p>



<h2 id="what-about-other-sites">What about other sites?</h2>



		<div class="wp-block-product-widget-block product-widget">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="our-favorite-password-manager-supports-passkeys">
					our favorite password manager supports passkeys				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="dashlane">Dashlane</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Dashlane" class="product-widget__image" height="4013" src="https://b2c-contenthub.com/wp-content/uploads/2022/06/Dashlane-Lockup-Green-3619X1385.png" width="15080" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/407081/dashlane-password-manager-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://www.tkqlhce.com/click-100470607-12528922?sid=2-1-1806627-5-389931-15360" rel="nofollow" target="_blank">$33 at  Dashlane</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p>The amount of time it takes to set up a passcode is breathtakingly fast, but its implementation is still unfolding slowly, as you can see from <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://passkeys.directory/&amp;xcust=2-1-1806627-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">this list</a> hosted by password manager 1Password. Speaking of, <a href="https://www.pcworld.com/article/407092/best-password-managers-reviews-and-buying-advice.html">password managers</a> haven&rsquo;t universally released passkey support yet&mdash;so far, NordPass and Dashlane (our favorite) appear to be first out the gate, though others like 1Password have plans to follow later in 2023. Passkeys are still in their early days, however. Adoption should spread faster as the months roll on.</p>

Internet, Security</div>

## AMD Ryzen 7040U CPUs bring cutting-edge performance to ultraportable laptops
 - [https://www.pcworld.com/article/1806031/amd-launches-ai-powered-ryzens-for-thin-notebooks.html](https://www.pcworld.com/article/1806031/amd-launches-ai-powered-ryzens-for-thin-notebooks.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 13:11:07+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>AMD announced four new processors within its Ryzen Mobile 7040 series, taking more steps toward what AMD believes will eventually be a future full of artificial intelligence-enhanced PCs powered by its XDNA AI architecture.</p>



<p>Two of these new chips include Ryzen AI, hardware AI logic supported by new instructions. That said, you&rsquo;ll want to buy laptops based upon new chips for what they can deliver <em>now</em>, more than for their potential for AI in the future. And AMD&rsquo;s latest laptop processors look to pack plenty of punch. These new 7040U processors wield not only AMD&rsquo;s latest Zen 4 compute cores, but also powerful integrated Radeon graphics based on the same RDNA 3 architecture found in the <a href="https://www.pcworld.com/article/416006/the-best-graphics-cards-for-pc-gaming.html">latest and greatest Radeon graphics cards</a>. </p>



<p>AMD&rsquo;s new processors plug a small hole in the <a href="https://www.pcworld.com/article/1444850/amd-launches-mobile-ryzen-7000-cpus-prepping-for-an-ai-future.html">complicated mosaic of mobile Ryzen processors</a> AMD announced this January at CES, specifically the Ryzen 7040 Mobile series, or &ldquo;Phoenix.&rdquo; AMD announced two families of Phoenix parts in January, detailing the 7040HS series for &ldquo;elite ultrathin&rdquo; notebooks. Those are beginning to arrive on retail shelves. These new versions, the Ryzen Mobile 7040U processors, are aimed at lower-power (15-30W) notebooks instead.</p>



<p>Specifically, AMD announced four new processors:</p>



<ul><li><strong>Ryzen 7 7840U:</strong>&nbsp;8 cores/16 threads, 3.3GHz base clock/5.1GHz turbo; 24MB cache; 780M GPU; Ryzen AI; 15-30W TDP</li><li><strong><strong>Ryzen 5 7640U:</strong>&nbsp;</strong>6 cores/12 threads, 3.5GHz base clock/4.9GHz turbo; 22MB cache; 760M GPU; Ryzen AI; 15-30W TDP</li><li><strong>Ryzen 5 7540U:</strong>&nbsp;6 cores/12 threads, 3.2GHz base clock/4.9GHz turbo; 22MB cache; 740M GPU; 15-30W TDP</li><li><strong>Ryzen 3 7440U:</strong>&nbsp;4 cores/8 threads, 3.0GHz base clock/4.7GHz turbo; 12MB cache; 740M GPU; 15-30W TDP</li></ul>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="AMD Ryzen Mobile 7040U list" class="wp-image-1806047" height="613" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/AMD-Rzyen-7040U-overview.png?w=1200" width="1200" /></figure><p class="imageCredit">AMD</p></div>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="AMD Ryzen Mobile 7040U diagram" class="wp-image-1806046" height="633" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/AMD-Ryzen-7050U-graphics.png?w=1200" width="1200" /></figure><p class="imageCredit">AMD</p></div>



<h2 id="amd-ryzen-7040u-performance-claims">AMD Ryzen 7040U performance claims</h2>



<p>Before we dig into futuristic AI ambitions, it makes more sense to look at how the 7040U handles traditional applications <em>today</em>.</p>



<p>The difference between what AMD&rsquo;s performance assessment in January and today is actually the retail availability of Intel&rsquo;s 13th-gen Core notebooks. Then, AMD compared the Ryzen 7 7840HS to the Intel Core i7-1280P. Now, AMD is claiming that its 8-core Ryzen 7 7840U can outperform a Core i7-1360P instead in both games and application performance. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="AMD Ryzen Mobile 7040U application performance " class="wp-image-1806044" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/AMD-Mobile-Ryzen-7040U-application-performance.png?w=1200" width="1200" /></figure><p class="imageCredit">AMD</p></div>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="AMD Ryzen Mobile 7040U games performance " class="wp-image-1806045" height="673" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/AMD-Ryzen-7040U-game-performance.png?w=1200" width="1200" /></figure><p class="imageCredit">AMD</p></div>



<p>In part, that&rsquo;s because AMD&rsquo;s new Radeon graphics cores outrun the Iris Xe GPU inside an Intel chip. AMD offers three integrated GPUs&mdash;the 780M (12 cores, up to 2.7GHz), the 760M (8 cores, up to 2.6GHz) and the 740M (4 cores, up to 2.5GHz)&mdash;based upon the RDNA3 graphics architecture and DDR5/LPDDR5 support. The game comparison uses Low image quality settings as a point of comparison, as these <em>are</em> integrated graphics, but running games like <em>Cyberpunk 2077 </em>and <em>Far Cry 6</em> off your processor in an ultrathin laptop is an impressive technical accomplishment. </p>



<p>Productivity tasks no doubt enjoy the performance boost AMD&rsquo;s cutting-edge Zen 4 CPU architecture offers. Machine learning is used for video encoding as well as the AI instructions. Speaking of&hellip;</p>



<h2 id="future-proofing-through-ai">Future-proofing through AI</h2>



<p>Dr. Lisa Su, AMD&rsquo;s chief executive, told analysts Tuesday that AI is AMD&rsquo;s &ldquo;number one strategic priority.&rdquo;</p>



<p>Though AI has dominated the news with everything from <a href="https://www.pcworld.com/article/820518/midjourneys-ai-art-goes-live-for-everyone.html">AI art</a> to chatbots like <a href="https://www.pcworld.com/article/1681251/10-awesome-things-you-can-do-with-chatgpt.html">ChatGPT</a> and <a href="https://www.pcworld.com/article/1671133/chatgpt-vs-bing-vs-bard-whats-the-best-ai-chatbot.html">Bing</a>, its presence on the PC has been relatively muted. In 2018, Microsoft made a small splash with <a href="https://www.pcworld.com/article/401941/how-microsofts-windows-ml-machine-learning-could-help-apps-anticipate-your-needs.html">Windows ML</a>, a machine learning update that debuted in Windows 10. Intel, for its part, showed how its <a href="https://www.pcworld.com/article/402099/movidius-windows-ml-intel-smart-pcs.html">Movidius chips could tap Windows ML</a> and begin creating an AI-empowered future.</p>



<p>Microsoft eventually tapped Arm instead, working with the smartphone developer and its Snapdragon PC chips to create AI-powered video experiences called Windows Studio Effects for the <a href="https://www.pcworld.com/article/1357826/microsoft-surface-pro-9-5g-review-an-arm-tablet-worth-buying.html">Surface Pro 9 5G</a>. A very few of Intel&rsquo;s 13th-gen Core chips contain AI capabilities via bundled <a href="https://www.pcworld.com/article/1435904/intel-launches-13th-gen-mobile-core-chips-with-endurance-gaming.html">Movidius AI cards</a>, which have appeared in <a href="https://www.pcworld.com/article/560732/intel-expands-premium-evo-brand-into-desktops-foldables-and-more.html">Evo-branded</a> laptops like the <a href="https://www.pcworld.com/article/1486723/samsung-reveals-galaxy-book3-oled-laptops.html">Samsung Galaxy Book3 series</a>. It&rsquo;s this distinctly &ldquo;dipping a toe in&rdquo; approach to AI that AMD&rsquo;s Ryzen 7040 Mobile series adopts, too.</p>



<p>AMD&rsquo;s Ryzen AI is based on a more compact, less complex version of the Versal AI logic AMD acquired with its purchase of Xilinx &mdash; scaled up for the datacenter, and scaled down for the PC. AMD hopes that using a common AI engine for the datacenter as well as the PC will allow developers a faster, easier road to develop AI-enabled software for the PC. AMD has unified its AI efforts across the company, led by the former CEO of Xilinx, Victor Peng.</p>



<p>One remaining question? AMD hasn&rsquo;t said when these processors will appear in laptops. With the 7040HS beginning to appear, however, we can hope that these won&rsquo;t be too far behind.</p>

CPUs and Processors</div>

## Speed up Google Chrome: 9 tips and tweaks
 - [https://www.pcworld.com/article/1804219/speed-up-google-chrome-9-tips-and-tweaks.html](https://www.pcworld.com/article/1804219/speed-up-google-chrome-9-tips-and-tweaks.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 10:45:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Google Chrome, the most popular web browser for PC users, initially delivers a fast and responsive browsing experience. However, over time, Chrome can become sluggish due to factors like cache files, extensions, and resource consumption.</p>



<p>There are many ways to improve Chrome&rsquo;s performance, such as keeping your browser up-to-date, clearing the cache, and taking advantage of some available special features. Here are nine fairly simple ways to keep Google Chrome running as fast as possible.</p>



<h2 id="always-update-chrome">Always update Chrome</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Chrome settings" class="wp-image-1804227" height="583" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/Update-Chrome.png?w=1200" width="1200" /></figure><p class="imageCredit">Marshall Gunnell/IDG</p></div>



<p>Updating Google Chrome to the latest version ensures that you have the most recent performance improvements, bug fixes, and security updates. Google frequently provides updates to its browser, so it&rsquo;s important to always stay up-to-date.</p>



<p>Chrome is designed to update automatically in the background when you close your browser. If you&rsquo;re like the many out there who almost never close their browsers, you should check for an update.</p>



<p>Chrome will place a button in the top-right corner of the browser window when it&rsquo;s time for an update. Just click it to update Chrome. If you don&rsquo;t see it, in the top-right corner of the window, click the <strong>three vertical dots</strong> &gt; <strong>Help</strong> &gt; <strong>About Google Chrome</strong>. Here, Chrome will check and install updates. Click <strong>Relaunch</strong> to finish updating Chrome. Chrome will close, so make sure you don&rsquo;t have any unfinished work open in a tab.</p>



<h2 id="be-conservative-with-your-tabs">Be conservative with your Tabs</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Chrome settings" class="wp-image-1804232" height="638" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/Close-some-tabs.png?w=1200" width="1200" /><figcaption>Don&rsquo;t be like me.</figcaption></figure><p class="imageCredit">Marshall Gunnell/IDG</p></div>



<p><a href="https://www.pcworld.com/article/693413/got-tons-of-browser-tabs-dont-ignore-this-small-but-life-changing-feature-in-chrome.html">Having multiple tabs open</a> in your browser consumes memory (RAM) and, to a lesser extent, processing power (CPU). As the number of open tabs increases, so does the demand on your computer&rsquo;s resources. This can lead to slower performance, increased page load times, and even crashes or freezes if your system becomes overwhelmed.</p>



<h2 id="disable-unused-extensions">Disable unused extensions</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Chrome settings" class="wp-image-1804226" height="928" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/Remove-browser-extensions.png" width="1024" /></figure><p class="imageCredit">Marshall Gunnell/IDG</p></div>



<p><a href="https://www.pcworld.com/article/631993/5-free-chrome-browser-extensions-need-to-try.html">Extensions</a> are small software programs that add functionality to your browser. They can be useful, having too many extensions installed or using poorly optimized ones can negatively impact Google Chrome&rsquo;s performance. Disabling unnecessary extensions can help speed up your browser&rsquo;s performance.</p>



<p>You can disable browser extensions by going to <strong>chrome://extensions</strong> and then toggling the extension&rsquo;s slider to the <strong>Off</strong> position, or by clicking <strong>Remove</strong>.</p>



<h2 id="clear-your-browsing-data">Clear your browsing data</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Chrome settings" class="wp-image-1804224" height="1200" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/Clear-browsing-data.png?w=1149" width="1149" /></figure><p class="imageCredit">Marshall Gunnell/IDG</p></div>



<p>Clearing browsing data, including history, <a href="https://www.pcworld.com/article/477864/how-to-delete-cookies.html">cookies</a>, and cached files, can enhance performance by freeing up disk space and resolving website issues caused by outdated or corrupted files. This not only improves system performance but also enhances privacy and security.</p>



<p>Clearing browsing data can also lead to better performance by reducing RAM usage since cookies and cached files are usually stored in your computer&rsquo;s RAM for quick access. This usually means smoother browsing and faster page loading times, especially if your device has limited memory.</p>



<p>You can clear your browsing data by clicking the <strong>three vertical dots</strong> &gt; <strong>Settings</strong> &gt; <strong>Privacy and Security</strong>. Here, you&rsquo;ll select each option individually and delete the data.</p>



<h2 id="preload-web-pages">Preload web pages</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Chrome settings" class="wp-image-1804228" height="759" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/Enable-page-preloading.png?w=1200" width="1200" /></figure><p class="imageCredit">Marshall Gunnell/IDG</p></div>



<p>Preloading web pages improves performance by fetching and loading resources for a web page before you actually navigate to it. When you hover over a link or when the browser predicts that you&rsquo;re likely to visit a particular page, Chrome can start fetching the resources (such as images, CSS, and JavaScript files) needed to display the page. This is done in the background while you&rsquo;re still on the current page. When you eventually click the link, Chrome has already loaded much of the content, so the page appears to load faster.</p>



<p>You can enable the feature to preload web pages by clicking the <strong>three vertical dots</strong> &gt; <strong>Settings</strong> &gt; <strong>Privacy and Security</strong> &gt; <strong>Cookies and other site data</strong>. Toggle the slider next to <strong>Preload pages for faster browsing and searching</strong> to the <strong>On</strong> position.</p>



<h2>Use Chrome&rsquo;s Energy Saver</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Chrome settings" class="wp-image-1804231" height="801" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/Enable-Energy-Saver.png?w=1200" width="1200" /></figure><p class="imageCredit">Marshall Gunnell/IDG</p></div>



<p>Chrome&rsquo;s Energy Saver&rsquo;s main function is to conserve battery life, but it&rsquo;s also improves performance a bit by limiting certain background activity. You can set Energy Saver to only turn on when your battery hits 20 percent capacity, but you can also enable it when your computer is unplugged.</p>



<p>To enable Energy Saver, click the <strong>three vertical dots</strong> &gt; <strong>Settings</strong> &gt; <strong>Performance</strong>. In the Power group, toggle the slider next to <strong>Energy Saver</strong> to the <strong>On</strong> position. Next, choose when you&rsquo;d like this feature to activate.</p>



<h2 id="turn-on-hardware-acceleration">Turn on Hardware Acceleration</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Chrome settings" class="wp-image-1804225" height="583" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/Use-hardware-acceleration.png?w=1200" width="1200" /></figure><p class="imageCredit">Marshall Gunnell/IDG</p></div>



<p>Hardware acceleration tells Chrome to use your computer&rsquo;s GPU for specific tasks that can benefit from it. GPUs are designed to handle graphics-intensive tasks efficiently and can parallelize certain operations, making them more suited for tasks like rendering graphics, animations, and video playback.</p>



<p>By offloading some of these tasks from the CPU to the GPU, you&rsquo;ll see improved performance, smoother rendering of web content, and reduced system resource consumption. This can be especially beneficial on systems with <a href="https://www.pcworld.com/article/416006/the-best-graphics-cards-for-pc-gaming.html">powerful graphics</a> or when using applications and websites with heavy graphical elements.</p>



<p>To enable hardware acceleration, click the <strong>three vertical dots</strong> &gt; <strong>Settings</strong> &gt; <strong>System</strong>. Here, toggle the slider next to <strong>User hardware acceleration when available</strong> to the <strong>On</strong> position.</p>



<h2 id="enable-gpu-rasterization-in-google-flags-experimental">Enable GPU rasterization in Google Flags (Experimental)</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Chrome settings" class="wp-image-1804229" height="583" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/Enable-GPU-Rasterization.png?w=1200" width="1200" /></figure><p class="imageCredit">Marshall Gunnell/IDG</p></div>



<p>Rasterization is the process of converting vector graphics (like HTML, CSS, and SVG elements) into pixels that can be displayed on your screen. By default, Chrome uses the CPU for rasterization.</p>



<p>Enabling GPU Rasterization offloads this task to your computer&rsquo;s GPU&nbsp;instead. GPUs are designed to handle graphics processing more efficiently than CPUs, which can lead to faster rendering of web pages and improved performance, especially on systems with a powerful GPU.</p>



<p>You can enable GPU rasterization by going to <strong>chrome://flags</strong>, searching <strong>GPU Rasterization</strong>, and then selecting <strong>Enabled</strong> next to it.</p>



<p>It&rsquo;s worth noting that these are experimental features, and Google Chrome is pretty clear about only using these for testing purposes. Just because you <em>can</em> use it, doesn&rsquo;t mean you <em>should</em>. The risk may be higher than the reward. And if you&rsquo;ve enabled Hardware Acceleration, then you already have rasterization enabled anyway.</p>



<h2>Reset Google Chrome</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Chrome settings" class="wp-image-1804230" height="682" src="https://b2c-contenthub.com/wp-content/uploads/2023/05/Reset-Chrome.png?w=1200" width="1200" /></figure><p class="imageCredit">Marshall Gunnell/IDG</p></div>



<p>Resetting Chrome to its default settings can resolve performance issues by restoring the browser to its original configuration, eliminating any customizations, extensions, and settings that may be causing slowdowns or other problems.</p>



<p>You may want to do this if you&rsquo;ve tried other performance improvement methods without success or if you&rsquo;re unsure about which specific settings or extensions are causing the issues.</p>



<p>To reset Google Chrome, click the <strong>three vertical dots</strong> &gt; <strong>Settings</strong> &gt; <strong>Reset Settings</strong>. You&rsquo;ll find the option to reset Crhome to its default settings on this page.</p>



<h2 id="google-already-makes-chrome-faster">Google already makes Chrome Faster</h2>



<p><a href="https://developer.chrome.com/blog/new-in-chrome-112/">Google Chrome 112</a> brought significant performance improvements to the popular web browser. Optimizations have been made to JavaScript functions such as toString() and join(), as well as specialized fast paths for parsing innerHTML.</p>



<p>These features are extensively utilized across numerous websites and web apps, resulting in a noticeable difference in web browsing. <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://techcrunch.com/2023/04/13/google-says-it-just-made-chrome-a-lot-faster-on-both-mac-and-android/&amp;xcust=2-1-1804219-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Google reported a 10% increase in Apple&rsquo;s Speedometer 2.1 browser benchmark</a> over three months due to these improvements.</p>



<p>This is yet another reason to always keep Chrome up-to-date. Google is constantly bringing performance updates to Chrome, so let them do the hard work for you.</p>

Internet</div>

## G.Skill KM250 keyboard review: Gold standard for the bargain bin
 - [https://www.pcworld.com/article/1801607/g-skill-km250-keyboard-review.html](https://www.pcworld.com/article/1801607/g-skill-km250-keyboard-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><img alt="Editors' Choice" class="review-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" /><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Incredible value </li><li>PBT &ldquo;pudding&rdquo; caps </li><li>Great layout</li><li>Hot-swap switch sockets</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>No programming options</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">The G.Skill KM250 has a ton of features and incredible value&mdash;it&rsquo;s absolutely unbeatable at this price. The only thing it&rsquo;s missing is programming. </p>
</div>
				<h3 class="review-best-price" id="best-prices-today-g-skill-km250-rgb-keyboard">
			Best Prices Today: G.Skill KM250 RGB Keyboard		</h3>
				<div class="wp-block-price-comparison price-comparison ">
			<div class="price-comparison__record price-comparison__record--header">
				<div>
					<span>Retailer</span>
				</div>
				<div class="price-comparison__price">
					<span>Price</span>
				</div>
			</div>

														<div class="price-comparison__record">
							<div class="price-comparison__image">
																	<img alt="Amazon" src="https://www.pcworld.com/wp-content/themes/idg-base-theme/dist/static/img/amazon-logo.svg" />
															</div>
							<div class="price-comparison__price">
								<span>$39.99</span>
							</div>
							<div>
								<a class="price-comparison__view-button" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.amazon.com/dp/B0BSLCT417/&amp;xcust=2-1-1801607-2-1801815-13555&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">View Deal</a>							</div>
						</div>
															<div class="price-comparison__record">
							<div class="price-comparison__image">
																	<span>Amazon Canada</span>
															</div>
							<div class="price-comparison__price">
								<span>$82.53</span>
							</div>
							<div>
								<a class="price-comparison__view-button" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.amazon.ca/G-Skill-67-Key-Mechanical-Keyboard-Injection/dp/B0BSLCT417/ref=sr_1_2?crid=Q9LG6PWED76&amp;keywords=km250&amp;qid=1682624500&amp;sprefix=km250+%2Caps%2C106&amp;sr=8-2&amp;xcust=2-1-1801607-2-1801815-13555&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">View Deal</a>							</div>
						</div>
												<div class="price-comparison__record price-comparison__record--footer">
					<span class="price-comparison__footer-text">
													Price comparison from over 24,000 stores worldwide												</span>
									</div>
						</div>
		


<p>If you&rsquo;ve been following my keyboard reviews lately, you know I&rsquo;ve been lamenting the ever-increasing price of mainstream &ldquo;gaming&rdquo; boards that don&rsquo;t seem to be in any way related to their actual function. I was <a href="https://www.pcworld.com/article/1666820/havit-kb487l-keyboard-review.html" rel="noreferrer noopener" target="_blank">looking around for good budget alternatives</a> when all of a sudden G.Skill released a new mechanical keyboard, priced at just $55 on Amazon. How incredibly fortuitous! </p>



<p>Of course, with a budget keyboard you give up certain luxuries like a rotary dial&mdash;oh, wait, the KM250 has one. Well, you can&rsquo;t expect to pay so little and also get decent keycaps&hellip;huh, <em>actually</em>, the KM250 has PBT &ldquo;pudding&rdquo; keycaps that complement the RGB lighting rather nicely. But of course, with a budget board you get budget mechanical switches from <em>[checks spec list]</em> Kailh? What? Well there&rsquo;s no way that the board includes hot-swap switch sockets so you can swap them out for better ones&hellip;<em>oh wait it does that too. </em> </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="G.Skill KM250 hot-swap sockets" class="wp-image-1801789" height="676" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/DSC01507.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">Michael Crider/Foundry</p></div>



<p>In fact, the G.Skill KM250 has a laundry list of features that are shocking to see on a board at this price range, omitting only a few that are fairly reasonable. As such, it gets an easy recommendation for anyone looking for a high-quality, entry-level board, especially if you think you might want to invest in some upgraded switches or keycaps. </p>



<h2 id="what-are-the-g-skill-km250-specs">What are the G.Skill KM250 specs?</h2>



<p>The KM250 is a fairly standard wired mechanical keyboard in the increasingly popular, and somewhat nebulous, &ldquo;65%&rdquo; form factor. That means all of your primary typing keys and an arrow cluster, the absence of a function row, and a few more keys rounding it out: In this case, Delete, Page Up, and Page Down, plus a rotary dial. </p>



<p>That dial has become a mainstay of premium keyboards&mdash;if you don&rsquo;t have at least one dial, don&rsquo;t even bother coming to the meetup&mdash;so it&rsquo;s impressive and welcome to see it on this budget build. Though it&rsquo;s as plastic as the rest of the board, it does include a &ldquo;click&rdquo; button when you press down, so it&rsquo;s perfect for the standard volume + mute functionality. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="dial " class="wp-image-1801790" height="676" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/DSC01388.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">Michael Crider/Foundry</p></div>



<p>Elsewhere you get a functional, if chunky, case with double-sectioned feet for three typing angles, a 6-foot detachable braided USB-C cable, and a keycap/switch puller in the box. The keycaps are high-quality PBT, which some other companies make you pay extra for (Razer, <a href="https://www.pcworld.com/article/541284/razer-blackwidow-v3-pro-review-a-wireless-keyboard-with-gaming-audacity.html" rel="noreferrer noopener" target="_blank">I&rsquo;ll stop calling you out for this</a> when you stop doing it). The caps are of the somewhat niche but appealing &ldquo;pudding&rdquo; style&mdash;that is to say, solid black tops with translucent sides to make the RGB lighting shine even brighter. It&rsquo;s not up to the dazzling standard of the <a href="https://www.pcworld.com/article/1338064/roccat-vulcan-ii-mini-keyboard-review.html" rel="noreferrer noopener" target="_blank">Roccat Vulkan</a> series, but it&rsquo;s pretty nice nonetheless. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="G.Skill KM250 illuminated keycaps" class="wp-image-1801791" height="675" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/DSC01431.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">Michael Crider/Foundry</p></div>



<p>Underneath are linear Red switches for speedy, game-friendly key presses. As noted in the intro, the switches are from Kailh, a pretty huge supplier of switches both fancy (like the &ldquo;Blueberry Ice Cream Pro&rdquo; ones in the <a href="https://www.pcworld.com/article/1793350/keydous-nj80-ap-keyboard-review.html">Keydous NJ80-AP</a>) and basic. These <em>are </em>basic Red switches, without any reinforced BOX stems or pre-lubed springs, but I appreciate that G.Skill <em>could </em>have gone with a cheaper brand and didn&rsquo;t. </p>



<p>And finally, the switches can be taken out of the plastic plate and replaced with any MX-compatible alternative. Again, this is a standard of more expensive boards that by rights shouldn&rsquo;t be in one this cheap&mdash;it wasn&rsquo;t in the <a href="https://www.pcworld.com/article/1666820/havit-kb487l-keyboard-review.html">Havit KB487L</a>, for example, and that board is only slightly cheaper. The KM250 is an absolute marvel of mechanical keyboard value. </p>



<figure class="wp-block-pullquote"><blockquote><p>The KM250 is an absolute marvel of mechanical keyboard value.</p></blockquote></figure>



<h2 id="where-is-the-g-skill-km250-programmability">Where is the G.Skill KM250 programmability?</h2>



<p>G.Skill included pretty much everything in this board, unless you&rsquo;re looking for wireless options or exotic construction. But there is one thing on the basic laundry list that isn&rsquo;t here: programmability. The KM250 is locked to the layout you get out of the box, including the function layer and lighting controls&mdash;the only download you&rsquo;ll see on the support page is a digital copy of the quick start guide you get in the box. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="G.Skill KM250 USB port" class="wp-image-1801786" height="676" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/DSC01439.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">Michael Crider/Foundry</p></div>



<p>Not that the guide is really necessary. The sub-functions of each key are printed on the keycaps, and easy enough to figure out on their own. With no lighting programming options, you <em>do </em>get an admirable selection of light shows: 18 different animation options in various colors, for which you can adjust the speed and direction. I&rsquo;m not really a fan of RGB, so I set it to the static rainbow and left it there. </p>



<p>This is where I&rsquo;d put a screenshot of the programming tool. But there isn&rsquo;t one. Sorry about that. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="function row" class="wp-image-1801788" height="676" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/DSC01405.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">Michael Crider/Foundry</p></div>



<p>So yes, there&rsquo;s the KM250&rsquo;s one weakness, if it&rsquo;s fair to call it a weakness in a keyboard this cheap. That said, a lack of programmability doesn&rsquo;t really matter for the stated goal of PC gaming, since each game should allow you to re-bind key controls. Otherwise it&rsquo;s down to OS-level tools, <a href="https://www.pcworld.com/article/547570/5-free-windows-power-user-tools-we-love.html" rel="noreferrer noopener" target="_blank">like my go-to, SharpKeys</a>. </p>



<h2 id="typing-and-gaming-on-the-g-skill-km250">Typing and gaming on the G.Skill KM250 </h2>



<p>So the only thing left to ask is, is it a good keyboard to use? Plainly, yes. You don&rsquo;t get the fancy feel that comes from more premium parts&mdash;everything here is plastic to one degree or another. But it&rsquo;s about as good as mass-produced plastic can get, and very much in line with G.Skill&rsquo;s reputation for functional, low-priced hardware. (Love your RAM DIMMs, by the way!) </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="G.Skill KM250 at my desk" class="wp-image-1801787" height="675" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/DSC01551.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">Michael Crider/Foundry</p></div>



<p>The KM250 works equally well as a full-time keyboard or as a secondary, more portable option, thanks to its lightweight build and full dedicated arrow cluster. If you want something to bring along to a LAN party (or perhaps more timely, just hanging out at your friend&rsquo;s place while you both play online), it&rsquo;ll do that, albeit not quite as stylishly as something low-profile like the <a href="https://www.pcworld.com/article/1438527/razer-deathstalker-v2-pro-review-big-keyboards-are-thin-again.html" rel="noreferrer noopener" target="_blank">Razer DeathStalker</a> or <a href="https://www.pcworld.com/article/1438544/keychron-k3-pro-keyboard-review.html" rel="noreferrer noopener" target="_blank">Keychron K series.</a> </p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="mentioned-in-this-article">
					mentioned in this article				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="keychron-k3-pro">Keychron K3 Pro</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Keychron K3 Pro" class="product-widget__image" height="634" src="https://b2c-contenthub.com/wp-content/uploads/2022/12/keychron-K3-PRo-hero.jpg?quality=50&amp;strip=all" width="1548" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/1438544/keychron-k3-pro-keyboard-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.keychron.com/products/keychron-k3-pro-qmk-via-wireless-custom-mechanical-keyboard&amp;xcust=2-1-1801607-5-1438563-17202&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">$94 at  Keychron</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p>And if you just want an inexpensive board to see what this mechanical craze is all about, it&rsquo;ll do that, too. Just for the hell of it, I took the excellent exotic switches from the Keydous NJ80 and my favorite &ldquo;Galaxy Class&rdquo; DSA keycaps. I wanted to simulate a bunch of money poured into this cheap board, and yes, a few premium parts goes much farther on this board than many others in its price range. For example, when I noticed that there&rsquo;s <em>also </em>sound-absorbing foam underneath the plastic plate, and even in the gap beneath the space bar, preventing the distinctive &ldquo;space rattle.&rdquo; <em>MAN </em>this board goes so much harder than it has to!</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="G.Skill KM250 RGB Keyboard foam" class="wp-image-1801886" height="675" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/its-got-foam.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>This board has sound-absorbing foam stopping the space bar from rattling.&nbsp;</p>
</figcaption></figure><p class="imageCredit">Michael Crider/Foundry</p></div>



<h2 id="should-you-buy-the-g-skill-km250">Should you buy the G.Skill KM250?</h2>



<p>The KM250 is an astonishingly good value, and gets an easy recommendation unless you simply <em>must </em>have the ability to program your keys and lighting. For everyone else it&rsquo;s an absolute steal, setting a new gold standard for super-cheap, super-functional mechanical boards. </p>

Keyboards</div>

## This vacation planning tool could save you a bundle this summer
 - [https://www.pcworld.com/article/1806037/this-vacation-planning-tool-could-save-you-a-bundle-this-summer.html](https://www.pcworld.com/article/1806037/this-vacation-planning-tool-could-save-you-a-bundle-this-summer.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-05-03 08:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Summer is almost here and you&rsquo;re ready for a vacation. But with inflation causing price increases in everything from hotels to airfare, you want to find ways to <a href="https://shop.pcworld.com/sales/vacaygo-ultimate-travel-deals-planning-tool-lifetime-pro-subscription?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=vacaygo-ultimate-travel-deals-planning-tool-lifetime-pro-subscription&amp;utm_term=scsf-570102&amp;utm_content=a0x1P000004IXI3QAO&amp;scsonar=1" rel="noreferrer noopener" target="_blank">save money while traveling</a>. With VacayGo, that&rsquo;s easier than ever.</p>



<p>This comprehensive travel companion helps you plan, book, and track your experience in a single app. You can use it as a source of inspiration, adding destinations and build a vision board of where you want to travel by yourself or with friends and family. The app makes it easy to plan trips with groups, booking tours, attractions, and more all together to make your itineraries a lot easier to manage. VacayGo helps you find the best deals for every aspect of your trip and lets you track expenses, journals, and photos from your trip.</p>



<p>VacayGo makes your summer travel planning easier than ever. All you&rsquo;ll have to do is <a href="https://www.pcworld.com/article/1794775/learn-the-language-before-you-travel-with-a-special-discount-on-rosetta-stone.html" rel="noreferrer noopener" target="_blank">learn a little of the language</a> of your destination. Grab a lifetime Pro subscription to <a href="https://shop.pcworld.com/sales/vacaygo-ultimate-travel-deals-planning-tool-lifetime-pro-subscription?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=vacaygo-ultimate-travel-deals-planning-tool-lifetime-pro-subscription&amp;utm_term=scsf-570102&amp;utm_content=a0x1P000004IXI3QAO&amp;scsonar=1" rel="noreferrer noopener" target="_blank">VacayGo&trade;</a> for $49.99 for a limited time.</p>



<p><a href="https://shop.pcworld.com/sales/vacaygo-ultimate-travel-deals-planning-tool-lifetime-pro-subscription?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=vacaygo-ultimate-travel-deals-planning-tool-lifetime-pro-subscription&amp;utm_term=scsf-570102&amp;utm_content=a0x1P000004IXI3QAO&amp;scsonar=1" rel="noreferrer noopener" target="_blank">&nbsp;</a></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image"><img alt="" src="https://cdnp3.stackassets.com/9bde14df531bf072aaf218cd18e485fd539d51d4/store/54713587ef3bd35ed08d954af1d0eeea4a1495c86a9a89300f2ff4ced7d8/sale_321459_primary_image.jpg" /></figure></div>



<p><strong>VacayGo&trade; Ultimate Travel Deals &amp; Planning Tool: Lifetime Pro Subscription &ndash; $49.99</strong></p>



<p><a href="https://shop.pcworld.com/sales/vacaygo-ultimate-travel-deals-planning-tool-lifetime-pro-subscription?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=vacaygo-ultimate-travel-deals-planning-tool-lifetime-pro-subscription&amp;utm_term=scsf-570102&amp;utm_content=a0x1P000004IXI3QAO&amp;scsonar=1" rel="noreferrer noopener" target="_blank">See Deal</a></p>



<p>Prices subject to change.</p>

Entertainment</div>

