# Source:AdamNeely, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnkp4xDOwqqJD7sSM3xdUiQ, language:en-US

## Tour bus quintuplets (with @ShubhSaran)
 - [https://www.youtube.com/watch?v=50Lvaid6b1I](https://www.youtube.com/watch?v=50Lvaid6b1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnkp4xDOwqqJD7sSM3xdUiQ
 - date published: 2023-05-03 01:42:10+00:00



