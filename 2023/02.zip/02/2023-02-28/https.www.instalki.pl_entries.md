# Source:Instalki.pl, URL:https://www.instalki.pl, language:pl-PL

## Rząd przyjął ustawę. Aplikacja mObywatel zastąpi dowód osobisty - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/software/58272-rzad-przyjal-ustawe-mobywatel-zamiast-dowodu-osobistego.html](https://www.instalki.pl/aktualnosci/software/58272-rzad-przyjal-ustawe-mobywatel-zamiast-dowodu-osobistego.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-02-28 17:23:45.633520+00:00

Rząd przyjął ustawę. Aplikacja mObywatel zastąpi dowód osobisty - Instalki.pl

## TikTok zbanowany w kolejnym kraju. Blokada platformy postępuje - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/software/58271-tiktok-blokada-kanada.html](https://www.instalki.pl/aktualnosci/software/58271-tiktok-blokada-kanada.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-02-28 16:23:55.388808+00:00

TikTok zbanowany w kolejnym kraju. Blokada platformy postępuje - Instalki.pl

## Białorusini uszkodzili "Trzmiela" - jeden z najważniejszych samolotów Rosjan - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/technika/58270-bialorusini-uszkodzili-trzmiela-jeden-z-najwazniejszych-samolotow-rosjan.html](https://www.instalki.pl/aktualnosci/technika/58270-bialorusini-uszkodzili-trzmiela-jeden-z-najwazniejszych-samolotow-rosjan.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-02-28 15:23:46.022426+00:00

Białorusini uszkodzili "Trzmiela" - jeden z najważniejszych samolotów Rosjan - Instalki.pl

## Słońce emituje tajemnicze sygnały. Nareszcie rozwiązano ich zagadkę - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/nauka/58269-slonce-emituje-tajemnicze-sygnaly-nareszcie-rozwiazano-ich-zagadke.html](https://www.instalki.pl/aktualnosci/nauka/58269-slonce-emituje-tajemnicze-sygnaly-nareszcie-rozwiazano-ich-zagadke.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-02-28 12:23:36.468920+00:00

Słońce emituje tajemnicze sygnały. Nareszcie rozwiązano ich zagadkę - Instalki.pl

## YouTube można wykorzystać jako darmową chmurę na pliki, bez limitu danych - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/internet/58266-youtube-mozna-wykorzystac-jako-darmowa-chmure-na-pliki-bez-limitu-danych.html](https://www.instalki.pl/aktualnosci/internet/58266-youtube-mozna-wykorzystac-jako-darmowa-chmure-na-pliki-bez-limitu-danych.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-02-28 12:23:36.153065+00:00

YouTube można wykorzystać jako darmową chmurę na pliki, bez limitu danych - Instalki.pl

## Microsoft może pracować nad alternatywą dla sklepu Google Play - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/software/58268-microsoft-moze-pracowac-nad-alternatywa-dla-sklepu-google-play.html](https://www.instalki.pl/aktualnosci/software/58268-microsoft-moze-pracowac-nad-alternatywa-dla-sklepu-google-play.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-02-28 11:23:37.571804+00:00

Microsoft może pracować nad alternatywą dla sklepu Google Play - Instalki.pl

## Znak wodny w Windows 11 o niewspieranym komputerze? Usuń go tym sposobem - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/software/58267-znak-wodny-w-windows-11-o-niewspieranym-komputerze-jak-go-usunac.html](https://www.instalki.pl/aktualnosci/software/58267-znak-wodny-w-windows-11-o-niewspieranym-komputerze-jak-go-usunac.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-02-28 09:23:35.470461+00:00

Znak wodny w Windows 11 o niewspieranym komputerze? Usuń go tym sposobem - Instalki.pl

## Ruszył proces o negatywną opinię Polki w Google Maps - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/internet/58265-pozew-za-negatywna-opinie-w-mapach-google-sad-rejonowy-w-lublinie.html](https://www.instalki.pl/aktualnosci/internet/58265-pozew-za-negatywna-opinie-w-mapach-google-sad-rejonowy-w-lublinie.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-02-28 08:23:33.898121+00:00

Ruszył proces o negatywną opinię Polki w Google Maps - Instalki.pl

## Hulajnoga Xiaomi Electric Scooter 4 Ultra ma zdumiewający zasięg, naprawia się sama - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/hardware/58264-hulajnoga-xiaomi-electric-scooter-4-ultra-ma-zdumiewajacy-zasieg-naprawia-sie-sama.html](https://www.instalki.pl/aktualnosci/hardware/58264-hulajnoga-xiaomi-electric-scooter-4-ultra-ma-zdumiewajacy-zasieg-naprawia-sie-sama.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-02-28 07:23:35.259496+00:00

Hulajnoga Xiaomi Electric Scooter 4 Ultra ma zdumiewający zasięg, naprawia się sama - Instalki.pl

