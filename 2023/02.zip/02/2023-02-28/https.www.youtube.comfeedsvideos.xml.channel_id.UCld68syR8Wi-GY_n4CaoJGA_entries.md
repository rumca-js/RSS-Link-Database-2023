# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Ubuntu Flavors Put An End To Shipping Flatpak
 - [https://www.youtube.com/watch?v=hyXxdAr-bL0](https://www.youtube.com/watch?v=hyXxdAr-bL0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2023-02-28 20:00:15+00:00

Canonical as the developers of Snap are all in on it but a lot of the flavors have been shipping it as a default, Canonical supposedly with support of the flavors has decided to stop this trend in it's tracks

==========Support The Channel==========
► $100 Linode Credit: https://brodierobertson.xyz/linode
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Canonical Blog Post: https://discourse.ubuntu.com/t/ubuntu-flavor-packaging-defaults/34061
Ubuntu Website: https://ubuntu.com/
OMGUbuntu Article: https://www.omgubuntu.co.uk/2023/02/ubuntu-flavors-no-flatpak
Ubuntu Flavors: https://ubuntu.com/desktop/flavours
Ubuntu Flavor Guidelines: https://wiki.ubuntu.com/RecognizedFlavors
Ubuntu Cinnamon: https://ubuntucinnamon.org/
Flatpak Package: https://packages.ubuntu.com/lunar/flatpak

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson.xyz/discord
🎤 Matrix Space: https://brodierobertson.xyz/matrix
🐦 Twitter: https://brodierobertson.xyz/twitter
🌐 Mastodon: https://brodierobertson.xyz/mastodon
🖥️ GitHub: https://brodierobertson.xyz/github

==========Credits==========
🎨 Channel Art:
Profile Picture:
https://www.instagram.com/supercozman_draws/

#Ubuntu #Linux #OpenSource #FOSS #Debian #UbuntuUnity

🎵 Ending music
Music from https://filmmusic.io
"Basic Implosion" by Kevin MacLeod (https://incompetech.com)
License: CC BY (http://creativecommons.org/licenses/by/4.0/)

DISCLOSURE: Wherever possible I use referral links, which means if you click one of the links in this video or description and make a purchase I may receive a small commission or other compensation.

