# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## Jaguar Land Rover owner demands £500mn from UK for battery factory
 - [https://www.ft.com/content/f4c5f4e7-b1c6-4499-865d-1247f3302f34](https://www.ft.com/content/f4c5f4e7-b1c6-4499-865d-1247f3302f34)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 21:00:43+00:00

Tata Motors will decide between Somerset and Spain for new plant within weeks

## US Supreme Court conservatives cast doubt on Biden’s student loan relief
 - [https://www.ft.com/content/13ea7db9-d62a-4188-88a9-c57596b4c4e1](https://www.ft.com/content/13ea7db9-d62a-4188-88a9-c57596b4c4e1)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 20:38:03+00:00

Majority of justices express scepticism about administration’s $400bn programme

## Treasury looking at U-turn on planned cut to UK energy subsidies
 - [https://www.ft.com/content/a6a0a2a2-2b24-474b-ad50-eb4ed6d6d85d](https://www.ft.com/content/a6a0a2a2-2b24-474b-ad50-eb4ed6d6d85d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 19:25:55+00:00

Hope for action on preventing fresh spike in household bills with room for manoeuvre in Budget

## Tinubu leads disputed Nigerian vote as opposition calls for election rerun
 - [https://www.ft.com/content/64724f5c-a6b5-45cb-8fa6-96e1531a98f8](https://www.ft.com/content/64724f5c-a6b5-45cb-8fa6-96e1531a98f8)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 18:59:51+00:00

Anger directed at the Independent National Electoral Commission over long delays in collecting results

## Inside the secret talks that broke Brexit deadlock on N Ireland
 - [https://www.ft.com/content/a809604c-fed4-4b7e-8833-8618d542adee](https://www.ft.com/content/a809604c-fed4-4b7e-8833-8618d542adee)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 18:59:37+00:00

EU recognised Sunak’s willingness to plunge into detail of potential solutions after confrontation of Johnson years

## Threat from Berlin to block EU’s combustion engine ban
 - [https://www.ft.com/content/c7cbd180-34b0-493b-857f-b5632fd56861](https://www.ft.com/content/c7cbd180-34b0-493b-857f-b5632fd56861)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 18:34:08+00:00

Coalition ministers from pro-market FDP say Brussels must allow for use of vehicles running on e-fuels after 2035

## The west must give Ukraine what it needs
 - [https://www.ft.com/content/53804bd6-7e07-45f5-b650-d5a841db2c50](https://www.ft.com/content/53804bd6-7e07-45f5-b650-d5a841db2c50)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 18:14:58+00:00

This war is a vital national interest of European countries and the US

## London’s most expensive ever house sale lined up after Saudi loan expires
 - [https://www.ft.com/content/947cd38b-72ae-4eb6-b3c7-c3e5c27e9434](https://www.ft.com/content/947cd38b-72ae-4eb6-b3c7-c3e5c27e9434)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 18:02:03+00:00

Mansion set in 4 acres of Regent’s Park expected to attract offers as high as £250mn

## Tesla to build car plant in Monterrey, says Mexico’s president
 - [https://www.ft.com/content/856dd21e-7e77-40ef-8c50-7cf3e1e4a840](https://www.ft.com/content/856dd21e-7e77-40ef-8c50-7cf3e1e4a840)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 17:53:59+00:00

López Obrador confirms investment after finalising details with carmaker’s CEO Elon Musk

## UK competition regulator to probe housebuilding market
 - [https://www.ft.com/content/a915d643-67c2-439d-a498-dcdd619298ce](https://www.ft.com/content/a915d643-67c2-439d-a498-dcdd619298ce)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 17:08:00+00:00

Year-long study will focus on property quality, land management and local authority oversight

## Tackling Britain’s dearth of skills and workers
 - [https://www.ft.com/content/e790c414-3640-4285-a3c3-ce0a222068ae](https://www.ft.com/content/e790c414-3640-4285-a3c3-ce0a222068ae)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 17:01:48+00:00

Fixing education, training and high inactivity is key to boosting UK productivity

## Ransomware attack on chip supplier causes delays for semiconductor groups
 - [https://www.ft.com/content/b8669140-8dde-493e-bb30-f5f1e9830804](https://www.ft.com/content/b8669140-8dde-493e-bb30-f5f1e9830804)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 15:45:00+00:00

US-based MKS Instruments says attack would cost at least $200mn in lost or delayed sales

## Record UK grocery inflation has added £811 to yearly bill, survey finds
 - [https://www.ft.com/content/a48ab8a4-a92c-4196-b2d4-187d059ee844](https://www.ft.com/content/a48ab8a4-a92c-4196-b2d4-187d059ee844)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 15:41:24+00:00

Annual food prices rose 17.1% in February, research by Kantar shows, as consumers switched to discount supermarkets

## ‘Stormont brake’ in N Ireland deal must be an instrument not an ornament
 - [https://www.ft.com/content/85987313-0ffb-47b6-a00c-7a9b4d9220e6](https://www.ft.com/content/85987313-0ffb-47b6-a00c-7a9b4d9220e6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 15:40:55+00:00

The Windsor framework provides for dispute resolution but it may still be difficult to apply

## Inflation will remain high in volatile markets, warns hedge fund chief
 - [https://www.ft.com/content/a1ce3459-08bb-476a-b422-aab336ae28c5](https://www.ft.com/content/a1ce3459-08bb-476a-b422-aab336ae28c5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 15:27:07+00:00

Man Group boss Luke Ellis says investors must get used to significant moves up and down in markets

## Bayer chief hits out at US legal system after weedkiller fight
 - [https://www.ft.com/content/6848561f-8c4b-4827-affc-c47a43e46e61](https://www.ft.com/content/6848561f-8c4b-4827-affc-c47a43e46e61)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 15:01:43+00:00

Companies are ‘at the mercy of an industry of litigation lawyers’, says outgoing CEO Werner Baumann

## UK gambling groups braced for sweeping reforms to protect customers
 - [https://www.ft.com/content/1f42f3d8-f399-48a6-8c7d-25380ed21002](https://www.ft.com/content/1f42f3d8-f399-48a6-8c7d-25380ed21002)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 14:55:14+00:00

Long-delayed white paper expected to try to curb football sponsorship and ban VIP packages on betting sites

## Pimco strikes deal for London offices as demand for modern workplaces grows
 - [https://www.ft.com/content/2241e3ba-6443-4cd3-b251-d78cde64f6cc](https://www.ft.com/content/2241e3ba-6443-4cd3-b251-d78cde64f6cc)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 14:54:09+00:00

Asset manager agrees to pay £11mn in annual rent for five floors of Marylebone building

## Investors expect further sterling gains from Sunak’s Brexit deal
 - [https://www.ft.com/content/978cfb1d-62c7-4533-9c70-c08259258b22](https://www.ft.com/content/978cfb1d-62c7-4533-9c70-c08259258b22)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 14:38:07+00:00

UK-EU agreement over Northern Ireland should help the pound though dollar’s strength will dampen recovery, analysts say

## Years after Woodford’s crash, what have fund managers learnt about illiquid assets?
 - [https://www.ft.com/content/41e69209-c0ca-4752-b4ac-2e5baee9bcb9](https://www.ft.com/content/41e69209-c0ca-4752-b4ac-2e5baee9bcb9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 14:35:19+00:00

Regulators are still grappling with liquidity rules as investors risk being left in the dark

## DUP must not lose sight of the benefits of the Northern Ireland deal
 - [https://www.ft.com/content/db469c5b-325c-4b18-8169-572c88284686](https://www.ft.com/content/db469c5b-325c-4b18-8169-572c88284686)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 14:00:09+00:00

The ‘Windsor framework’ repairs some of the damage done by Boris Johnson’s original Brexit agreement

## Turkish economy’s growth driven by strong consumer spending
 - [https://www.ft.com/content/c038cf70-5a32-491b-a113-2e20a83af951](https://www.ft.com/content/c038cf70-5a32-491b-a113-2e20a83af951)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 13:36:19+00:00

Rise in GDP last year underlines how President Recep Tayyip Erdoğan prioritises growth over fighting inflation

## Lithuanian utility wants to donate windfall profits to Ukraine
 - [https://www.ft.com/content/0c73e768-1c6d-4448-8750-8430e4302c97](https://www.ft.com/content/0c73e768-1c6d-4448-8750-8430e4302c97)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 13:15:51+00:00

Ignitis launches public appeal to more than 50 energy groups in the US and Europe to follow suit

## The cultural left has peaked
 - [https://www.ft.com/content/6f69ea55-32c6-477e-93d2-598bbd6e761a](https://www.ft.com/content/6f69ea55-32c6-477e-93d2-598bbd6e761a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 12:27:53+00:00

Moderate liberals are braver now and economic concerns more important

## Former Brexit negotiator Olly Robbins swaps Goldman for Hakluyt
 - [https://www.ft.com/content/ef6025e2-675e-49b9-b914-aad10423097f](https://www.ft.com/content/ef6025e2-675e-49b9-b914-aad10423097f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 11:45:07+00:00

Ex-civil servant who led Theresa May’s talks with the EU is joining corporate intelligence firm

## There is too much we don’t know about Russia’s central bank reserves
 - [https://www.ft.com/content/37a4143b-ce25-4491-a946-3423cce5598b](https://www.ft.com/content/37a4143b-ce25-4491-a946-3423cce5598b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 11:25:29+00:00

Ignorance is not bliss in sanctions policy

## ‘Are you mad for model railways? Me too’
 - [https://www.ft.com/content/81ad6468-b012-4904-b9de-6017d6619110](https://www.ft.com/content/81ad6468-b012-4904-b9de-6017d6619110)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 10:55:44+00:00

Linwood Barclay, the bestselling detective novelist, tracks his life in trains

## Rising inflation in France and Spain fuels fears of more ECB rate increases
 - [https://www.ft.com/content/dc05bfee-e9ad-4ac3-89b6-744da511cfab](https://www.ft.com/content/dc05bfee-e9ad-4ac3-89b6-744da511cfab)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 10:29:38+00:00

Persistent price pressures in leading economies drive rise in eurozone governments’ borrowing costs

## US Chips Act fund recipients barred from expanding in China for 10 years
 - [https://www.ft.com/content/9f4f9684-088c-45eb-b6bf-962061bfea7b](https://www.ft.com/content/9f4f9684-088c-45eb-b6bf-962061bfea7b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 10:01:12+00:00

Commerce department imposes new rules on beneficiaries of $39bn programme

## European equities fall on strong French and Spanish inflation
 - [https://www.ft.com/content/da541c73-db3b-4f05-983a-fbc800d30be3](https://www.ft.com/content/da541c73-db3b-4f05-983a-fbc800d30be3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 09:40:27+00:00

Data suggests European Central Bank will keep interest rates high for longer than previously expected

## Brexit deal: Sunak’s first serious achievement of his own
 - [https://www.ft.com/content/65b46f5c-ecbb-40f2-abab-58b11caf66fd](https://www.ft.com/content/65b46f5c-ecbb-40f2-abab-58b11caf66fd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 09:30:44+00:00

Front pages from across the political spectrum hail result by prime minister, who remains beset by real policy challenges

## Japanese prosecutors charge Dentsu over Olympic bid-rigging scandal
 - [https://www.ft.com/content/cb216550-f398-493f-afe7-3f0be15f9f11](https://www.ft.com/content/cb216550-f398-493f-afe7-3f0be15f9f11)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 08:58:14+00:00

Public relations giant says five executives will hand back pay after indictments

## Who drives the restructuring bus?
 - [https://www.ft.com/content/9cd3fbee-d5f4-4297-98ed-fb61070e2fe5](https://www.ft.com/content/9cd3fbee-d5f4-4297-98ed-fb61070e2fe5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 08:00:44+00:00

Hint: Not the lenders

## Sunak heads to Belfast to sell Northern Ireland trade deal
 - [https://www.ft.com/content/3d2b4e24-5c92-4a28-b2fa-c4bfe143e814](https://www.ft.com/content/3d2b4e24-5c92-4a28-b2fa-c4bfe143e814)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 07:18:55+00:00

Some senior DUP figures say agreement does not go far enough

## BoJ finally corners 10-year JGB market
 - [https://www.ft.com/content/d7a1cc13-eb07-49f3-b026-46e3a81bbda8](https://www.ft.com/content/d7a1cc13-eb07-49f3-b026-46e3a81bbda8)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 07:10:33+00:00

Just incredible stuff

## EU keeps the champagne on ice over tentative Serbia-Kosovo deal
 - [https://www.ft.com/content/c9e19556-2a9c-4292-b96f-e9301beb8f3c](https://www.ft.com/content/c9e19556-2a9c-4292-b96f-e9301beb8f3c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 06:00:44+00:00

Also in today’s newsletter: signs of progress in Finland and Sweden’s Nato journey

## EU workers lack skills to green the economy, EIB poll finds
 - [https://www.ft.com/content/ec47ede3-773a-4bdd-a1e9-1a7f48037099](https://www.ft.com/content/ec47ede3-773a-4bdd-a1e9-1a7f48037099)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

Shortage of engineers and IT professionals is holding back clean technology transition

## Efama pushes for pre-trade data in European consolidated tape
 - [https://www.ft.com/content/b5fc2c43-9e00-4896-ba1f-709d6dcf0cdb](https://www.ft.com/content/b5fc2c43-9e00-4896-ba1f-709d6dcf0cdb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

The fund industry association wants the planned bundling of trading information to include more than post-trade content

## Here’s how to stop an ever sicker workforce dropping out
 - [https://www.ft.com/content/e2818aaf-6e79-4c12-bfe5-1864d078f8a7](https://www.ft.com/content/e2818aaf-6e79-4c12-bfe5-1864d078f8a7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

Occupational therapists may provide one practical solution to those struggling with their physical or mental health

## How can we avoid double taxation and UK inheritance tax?
 - [https://www.ft.com/content/33a3ae99-8fc1-4670-872e-f3610f07dee0](https://www.ft.com/content/33a3ae99-8fc1-4670-872e-f3610f07dee0)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

We are American and want to buy a home in London so our children can go to a British school

## How to be a digital nomad in Madrid
 - [https://www.ft.com/content/9013b059-d657-43d9-a841-ecda187b8680](https://www.ft.com/content/9013b059-d657-43d9-a841-ecda187b8680)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

Ever dreamt of moving to the Spanish capital? A new law makes it especially appealing — and easy — for non-EU freelancers and remote workers. Here’s what you need to know

## Meta’s AI-driven advertising system splits marketers
 - [https://www.ft.com/content/fc95a0f7-5e4e-4616-9b17-7b72daee6c60](https://www.ft.com/content/fc95a0f7-5e4e-4616-9b17-7b72daee6c60)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

Social network claims successes with tool to counteract Apple’s privacy changes that resulted in billions in lost revenue

## Need to Know . . . equity crowdfunding
 - [https://www.ft.com/content/1b6bfe9a-ab3a-4e74-b650-b930244f5821](https://www.ft.com/content/1b6bfe9a-ab3a-4e74-b650-b930244f5821)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

A low-cost way to invest in private companies — though there are risks

## The angry divide in Israel over the rule of law and religion
 - [https://www.ft.com/content/05f15936-882e-4a4f-a7c4-96870cc39a3e](https://www.ft.com/content/05f15936-882e-4a4f-a7c4-96870cc39a3e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

A broad swath of Israelis says the government’s proposed judicial reforms erode the foundations of democracy

## UK consortium takes on Palantir for £480mn NHS data contract
 - [https://www.ft.com/content/11f250df-5125-4bab-bbee-3c4324685c55](https://www.ft.com/content/11f250df-5125-4bab-bbee-3c4324685c55)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

Group argues it can provide software for less and better safeguard patient data, in challenge to US frontrunner

## US child labour violations rise as businesses defy laws to fill roles
 - [https://www.ft.com/content/656ba14d-0c41-4d65-88ac-8ba928bdc399](https://www.ft.com/content/656ba14d-0c41-4d65-88ac-8ba928bdc399)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

Tight job market fuels increase in breaches as some state legislators push to relax rules

## ‘You’re up against antipathy’: Democrats battle to rally black vote for 2024
 - [https://www.ft.com/content/7127f107-42d0-46c2-88eb-e172493af912](https://www.ft.com/content/7127f107-42d0-46c2-88eb-e172493af912)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:45+00:00

African-Americans in crucial ‘purple’ states are increasingly frustrated by issues such as policing and voting reform

## From ‘paradise’ to hell: how a luxury residence in Turkey became an earthquake death trap
 - [https://ig.ft.com/turkey-earthquake-apartment-collapse/](https://ig.ft.com/turkey-earthquake-apartment-collapse/)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 05:00:44+00:00

A collapsed apartment complex symbolises rot in country’s construction system

## Hong Kong ditches Covid mask mandate
 - [https://www.ft.com/content/a07babfc-4744-4c18-b40e-e963c993b7d3](https://www.ft.com/content/a07babfc-4744-4c18-b40e-e963c993b7d3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 04:39:41+00:00

Government drops most visible pandemic control as it seeks to revive financial hub

## Chinese factories launch charm offensive for buyers after Covid isolation
 - [https://www.ft.com/content/b96da70d-471c-4db6-8f96-76eed6232943](https://www.ft.com/content/b96da70d-471c-4db6-8f96-76eed6232943)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 00:30:43+00:00

Local governments send delegations to global trade fairs to woo back customers and fight decoupling

## UK executive target for women met three years ahead of schedule
 - [https://www.ft.com/content/de0ae7ac-8194-4adf-ad12-baf54e0f9703](https://www.ft.com/content/de0ae7ac-8194-4adf-ad12-baf54e0f9703)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-28 00:01:44+00:00

Two out of five board seats at FTSE 350 companies now occupied by females

