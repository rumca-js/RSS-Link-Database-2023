# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## The Shadow Medical Community Behind the Attempt to Ban Medication Abortion
 - [https://theintercept.com/2023/02/28/medication-abortion-lawsuit/](https://theintercept.com/2023/02/28/medication-abortion-lawsuit/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-02-28 17:44:47+00:00

<p>Anti-abortion groups orchestrated their legal challenge to wind up before far-right Judge Matthew Kacsmaryk.</p>
<p>The post <a href="https://theintercept.com/2023/02/28/medication-abortion-lawsuit/" rel="nofollow">The Shadow Medical Community Behind the Attempt to Ban Medication Abortion</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## How to Save Yellowstone's Wolves
 - [https://theintercept.com/2023/02/28/yellowstone-wolves-doug-smith/](https://theintercept.com/2023/02/28/yellowstone-wolves-doug-smith/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-02-28 11:00:51+00:00

<p>Biologist Doug Smith looks back on a quarter century leading one of the most historic and controversial government conservation initiatives of all time.</p>
<p>The post <a href="https://theintercept.com/2023/02/28/yellowstone-wolves-doug-smith/" rel="nofollow">How to Save Yellowstone&#8217;s Wolves</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

