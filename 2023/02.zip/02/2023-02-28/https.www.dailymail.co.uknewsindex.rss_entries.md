# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Melbourne radio presenter Neil Mitchell calls out Labor's Bill Shorten over Twitter video
 - [https://www.dailymail.co.uk/news/article-11804659/Melbourne-radio-presenter-Neil-Mitchell-calls-Labors-Bill-Shorten-Twitter-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804659/Melbourne-radio-presenter-Neil-Mitchell-calls-Labors-Bill-Shorten-Twitter-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 23:18:32+00:00

Radio presenter Neil Mitchell has blasted Bill Shorten over a segment of an interview the government services minister posted to his Twitter account.

## Estranged wife of transgender sex attacker Isla Bryson slams eight-year sentence for two rapes
 - [https://www.dailymail.co.uk/news/article-11804917/Estranged-wife-transgender-sex-attacker-Isla-Bryson-slams-eight-year-sentence-two-rapes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804917/Estranged-wife-transgender-sex-attacker-Isla-Bryson-slams-eight-year-sentence-two-rapes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 23:15:58+00:00

Bryson was jailed at Edinburgh High Court on Tuesday for the rape of a woman in Clydebank in 2016 and a second victim in Drumchapel three years later - while still a man known as Adam Graham.

## Bob Irwin asks for investigation into animal cruelty after crocodile killed at Bloomfield Queensland
 - [https://www.dailymail.co.uk/news/article-11804793/Bob-Irwin-asks-investigation-animal-cruelty-crocodile-killed-Bloomfield-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804793/Bob-Irwin-asks-investigation-animal-cruelty-crocodile-killed-Bloomfield-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 23:13:56+00:00

Bob Irwin, 83, says he is 'constantly upset' that crocodiles pay the 'ultimate price' in any interactions between humans and crocodiles.

## Sydney, Melbourne, Adelaide property: Surprise shift as prices go UP despite inflation
 - [https://www.dailymail.co.uk/news/article-11804785/Sydney-Melbourne-Adelaide-property-Surprise-shift-prices-despite-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804785/Sydney-Melbourne-Adelaide-property-Surprise-shift-prices-despite-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 23:13:37+00:00

Despite some huge falls in recent months Australian property prices went up overall in the past year, with all but one capital city rebounding

## Wimmera Highway crash, Murtoa: Truck driver arrested after man and woman killed
 - [https://www.dailymail.co.uk/news/article-11804777/Wimmera-Highway-crash-Murtoa-Truck-driver-arrested-man-woman-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804777/Wimmera-Highway-crash-Murtoa-Truck-driver-arrested-man-woman-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 23:11:28+00:00

A truck driver has been arrested after two people died in a horror early morning collision on a regional highway in Victoria.

## Britain WON'T ban government officials from using TikTok
 - [https://www.dailymail.co.uk/news/article-11805117/Britain-WONT-ban-government-officials-using-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11805117/Britain-WONT-ban-government-officials-using-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 23:11:06+00:00

The new Science Secretary, Michelle Donelan, said prohibiting MPs and civil servants from using the popular social media platform would be a 'very, very forthright move'.

## Vintage Dodge Charger used for Dukes of Hazzard TV show crashes while speeding
 - [https://www.dailymail.co.uk/news/article-11804531/Vintage-Dodge-Charger-used-Dukes-Hazzard-TV-crashes-speeding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804531/Vintage-Dodge-Charger-used-Dukes-Hazzard-TV-crashes-speeding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 23:07:01+00:00

A vintage 1969 Dodge Charger used for the iconic 1980s Dukes of Hazzard TV show has crashed while speeding - as two people not authorized to drive it were hospitalized.

## House votes to block 'woke' Biden plan pushing retirement planners to invest in ESG in 401ks
 - [https://www.dailymail.co.uk/news/article-11805047/House-votes-block-woke-Biden-plan-pushing-retirement-planners-invest-ESG-401ks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11805047/House-votes-block-woke-Biden-plan-pushing-retirement-planners-invest-ESG-401ks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 23:02:27+00:00

The House voted Tuesday to quash a Biden administration rule that encourages private retirement funds to consider ESG factors in investment decisions.

## Today Show host Karl Stefanovic accuses Anthony Albanese's of breaking a promise
 - [https://www.dailymail.co.uk/news/article-11804521/Today-host-Karl-Stefanovic-accuses-Anthony-Albaneses-breaking-promise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804521/Today-host-Karl-Stefanovic-accuses-Anthony-Albaneses-breaking-promise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 23:00:05+00:00

The Prime Minister on Tuesday announced that Australia's richest 0.5 per cent  would see their super contribution tax rate double to 30 per cent, up from 15 per cent from July 1, 2025.

## Biden claims he had a nurse who would whisper in his ear and BREATHE on him
 - [https://www.dailymail.co.uk/news/article-11804573/Biden-claims-nurse-whisper-ear-BREATHE-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804573/Biden-claims-nurse-whisper-ear-BREATHE-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:59:07+00:00

President Joe Biden awkwardly gushed about the good treatment he received from the nurses at Walter Reed during a healthcare event in Virginia Beach, Virginia on Tuesday.

## Sydney: Glamorous lawyer Ashlyn Nassif, 27, arrested and charged with multi-million dollar fraud
 - [https://www.dailymail.co.uk/news/article-11804615/Sydney-Glamorous-lawyer-Ashlyn-Nassif-27-arrested-charged-multi-million-dollar-fraud.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804615/Sydney-Glamorous-lawyer-Ashlyn-Nassif-27-arrested-charged-multi-million-dollar-fraud.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:51:09+00:00

The daughter of a high-profile Sydney property developer - who is also a top lawyer - has been charged over an alleged multi-million dollar fraud plot.

## Jim Chalmers grilled by Sunrise's David Koch over capital gains tax on family home after super tweak
 - [https://www.dailymail.co.uk/news/article-11804715/Jim-Chalmers-grilled-Sunrises-David-Koch-capital-gains-tax-family-home-super-tweak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804715/Jim-Chalmers-grilled-Sunrises-David-Koch-capital-gains-tax-family-home-super-tweak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:18:18+00:00

Treasurer Jim Chalmers has repeatedly refused to rule out introducing a capital gains tax on the family home during a car crash interview with Sunrise host David Koch.

## Missing Argentine man's body is found inside a SHARK after he went missing while driving ATV
 - [https://www.dailymail.co.uk/news/article-11804499/Missing-Argentine-mans-body-inside-SHARK-went-missing-driving-ATV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804499/Missing-Argentine-mans-body-inside-SHARK-went-missing-driving-ATV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:18:12+00:00

DNA testing is pending for Diego Barría, whose remains were found inside a shark captured by fishermen in Chubut, Argentina, on Sunday.

## Biden tears into 'MAGA Republicans' again in Virginia Beach saying they would slash Medicaid
 - [https://www.dailymail.co.uk/news/article-11804425/Biden-tears-MAGA-Republicans-Virginia-Beach-saying-slash-Medicaid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804425/Biden-tears-MAGA-Republicans-Virginia-Beach-saying-slash-Medicaid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:17:44+00:00

President Joe Biden traveled to Virginia Beach, where he accused House Republicans of plotting cuts to Medicaid and Obamacare, even if they 'found religion' on Social Security.

## Dilbert creator Scott Adams says his racist comments about black people 'hold up the mirror' to US
 - [https://www.dailymail.co.uk/news/article-11804407/Dilbert-creator-Scott-Adams-says-racist-comments-black-people-hold-mirror-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804407/Dilbert-creator-Scott-Adams-says-racist-comments-black-people-hold-mirror-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:17:30+00:00

The creator of the popular 'Dilbert' comic strip laughed at the idea that he has 'lost all his money' after being canceled for making bigoted comments against black Americans.

## Maryland man, 52, sues local bar for banning him because he's 'old and white' sparking culture war
 - [https://www.dailymail.co.uk/news/article-11804409/Maryland-man-52-sues-local-bar-banning-hes-old-white-sparking-culture-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804409/Maryland-man-52-sues-local-bar-banning-hes-old-white-sparking-culture-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:14:23+00:00

Dan's Restaurant and Taphouse has sparked a culture war in the small town of Boonsboro, Maryland, after a bartender allegedly threw a customer out because he's an 'old, white man.'

## Rural Oregon residents' campaign to secede from Dem-led state and join Idaho gains momentum
 - [https://www.dailymail.co.uk/news/article-11804015/Rural-Oregon-residents-campaign-secede-join-Idaho-gains-momentum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804015/Rural-Oregon-residents-campaign-secede-join-Idaho-gains-momentum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:13:42+00:00

Passing the measure would require an agreement from both Oregon and Idaho's legislature, and approval of that deal from the United States Congress.

## Hollywood's favorite final resting place is decimated by freak storm
 - [https://www.dailymail.co.uk/news/article-11804313/Hollywoods-favorite-final-resting-place-decimated-freak-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804313/Hollywoods-favorite-final-resting-place-decimated-freak-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:13:15+00:00

Hollywood's favorite final resting place Forest Lawn Memorial Park was damaged by a powerful storm that pummeled Los Angeles with fierce winds that toppled trees and downed wires.

## Lawyer attacked by female client who decapitated her lover QUITS
 - [https://www.dailymail.co.uk/news/article-11804523/Lawyer-attacked-female-client-decapitated-lover-QUITS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804523/Lawyer-attacked-female-client-decapitated-lover-QUITS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:12:52+00:00

Quinn Jolly, pictured bottom right, has quit the case of accused killer Taylor Schabusiness, top right, after she attacked him in a violent assault while on trial for murdering her lover in a drug rage.

## TOM RAWSTORNE: The trail for Constance Marten and Mark Gordon had gone cold
 - [https://www.dailymail.co.uk/news/article-11804779/TOM-RAWSTORNE-trail-Constance-Marten-Mark-Gordon-gone-cold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804779/TOM-RAWSTORNE-trail-Constance-Marten-Mark-Gordon-gone-cold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:07:12+00:00

TOM RAWSTORNE: The massive police hunt ended in the way it had begun - with two people, not three. From the beginning of the investigation, the welfare of the child was the main focus of police.

## Loudon County Republican Committee votes to censure board member in woke school system
 - [https://www.dailymail.co.uk/news/article-11804467/Loudon-County-Republican-Committee-votes-censure-board-member-woke-school-system.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804467/Loudon-County-Republican-Committee-votes-censure-board-member-woke-school-system.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:06:36+00:00

The Loudoun County GOP Committee censured Jeff Morse, the board member who voted against releasing a review that focused on how the system investigated sexual assaults.

## Ruthless drugs gangs are 'grooming' youngsters and recruiting them through online gaming
 - [https://www.dailymail.co.uk/news/article-11804865/Ruthless-drugs-gangs-grooming-youngsters-recruiting-online-gaming.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804865/Ruthless-drugs-gangs-grooming-youngsters-recruiting-online-gaming.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:05:17+00:00

Children as young as seven are among the 27,000 in England used to run drugs for ruthless gangs, according to Johnny Bolderson, of social welfare campaign group Catch22.

## Rishi Sunak warns MPs they can't trust 'Mr 2nd Referendum' Keir Starmer on Brexit
 - [https://www.dailymail.co.uk/news/article-11804675/Rishi-Sunak-warns-MPs-trust-Mr-2nd-Referendum-Keir-Starmer-Brexit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804675/Rishi-Sunak-warns-MPs-trust-Mr-2nd-Referendum-Keir-Starmer-Brexit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:03:30+00:00

Rishi Sunak branded Labour leader Sir Keir Starmer 'Mr 2nd Referendum' as he told the 1922 Committee of backbench Tories that the public are sick of Brexit 'drama'.

## Heston Blumenthal's fury as Waitrose ends 12-year partnership after tiring of his unpredictability'
 - [https://www.dailymail.co.uk/news/article-11804651/Heston-Blumenthals-fury-Waitrose-ends-12-year-partnership-tiring-unpredictability.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804651/Heston-Blumenthals-fury-Waitrose-ends-12-year-partnership-tiring-unpredictability.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 22:03:06+00:00

At the weekend, The Mail on Sunday disclosed that Waitrose had decided to drop the chef after a partnership which saw the Michelin-starred chef starring in TV adverts and helping boost sales.

## Shingle bank measuring just 330ft by 65ft formed in the Solent is 'claimed' by two sailors
 - [https://www.dailymail.co.uk/news/article-11804547/Shingle-bank-measuring-just-330ft-65ft-formed-Solent-claimed-two-sailors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804547/Shingle-bank-measuring-just-330ft-65ft-formed-Solent-claimed-two-sailors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:58:32+00:00

Chris Fox and Nick Ryley set out for the uncharted isle which gradually built up over the last few months as a result of work to protect the historic Hurst Castle from coastal erosion.

## Female police officer lied about her sergeant lover's controlling behaviour, court hears
 - [https://www.dailymail.co.uk/news/article-11803725/Female-police-officer-lied-sergeant-lovers-controlling-behaviour-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803725/Female-police-officer-lied-sergeant-lovers-controlling-behaviour-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:38:45+00:00

Amanda Aston, an officer based at Guildford police station in Surrey, is said to have 'distorted' difficulties in her relationship with Matthew Taylor knowing he would likely face repercussions.

## Rottweiler attack, Moruya: Mia Riley's parents speak after baby dies and reveal memorial plans
 - [https://www.dailymail.co.uk/news/article-11801575/Rottweiler-attack-Moruya-Mia-Rileys-parents-speak-baby-dies-reveal-memorial-plans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801575/Rottweiler-attack-Moruya-Mia-Rileys-parents-speak-baby-dies-reveal-memorial-plans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:35:08+00:00

The parents of a newborn mauled to death by Rottweilers at Moruyra, on the NSW south coast, have broken their silence to reveal plans for her memorial service.

## Scottish Green family facing deportation from Australia win battle to stay
 - [https://www.dailymail.co.uk/news/article-11804465/Scottish-Green-family-facing-deportation-Australia-win-battle-stay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804465/Scottish-Green-family-facing-deportation-Australia-win-battle-stay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:17:01+00:00

The Green family, who moved to Australia in 2012, have finally been granted permission to apply for permanent residency after an almost year-long legal battle.

## Jon Stewart reflects on comments that Covid came from a lab as fresh government report says it did
 - [https://www.dailymail.co.uk/news/article-11804385/Jon-Stewart-reflects-comments-Covid-came-lab-fresh-government-report-says-did.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804385/Jon-Stewart-reflects-comments-Covid-came-lab-fresh-government-report-says-did.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:15:10+00:00

Jon Stewart has reflected on backlash he received after suggesting in 2021 that Covid could have leaked from a lab.

## Cops descend on Murdaugh's hunting estate Moselle ahead of visit by double murder trial jury
 - [https://www.dailymail.co.uk/news/article-11804481/Cops-descend-Murdaughs-hunting-estate-Moselle-ahead-visit-double-murder-trial-jury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804481/Cops-descend-Murdaughs-hunting-estate-Moselle-ahead-visit-double-murder-trial-jury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:14:01+00:00

A convoy of police and fire department vehicles descended on the entrance to the kennels where Maggie, 52, and Paul, 22, were shot dead in Moselle, South Carolina, on June 7, 2021.

## Sixth grade student stands up at Maine school board meeting to read from sexually explicit book
 - [https://www.dailymail.co.uk/news/article-11803723/Sixth-grade-student-stands-Maine-school-board-meeting-read-sexually-explicit-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803723/Sixth-grade-student-stands-Maine-school-board-meeting-read-sexually-explicit-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:12:24+00:00

An 11-year-old boy made a statement at a school board meeting in Maine by reading from an explicit book he said he took from his middle school library.

## Jamaican offender used 'right to family life' to avoid deportation before going on to commit murder
 - [https://www.dailymail.co.uk/news/article-11804351/Jamaican-offender-used-right-family-life-avoid-deportation-going-commit-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804351/Jamaican-offender-used-right-family-life-avoid-deportation-going-commit-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:09:55+00:00

The lawyers of hardened criminal Ernesto Elliott (pictured) lodged a last-minute legal challenged under Article 8 of the European human rights convention against a bid to deport him

## Train carrying more than 30,000 gallons of propane fuel derails in Florida
 - [https://www.dailymail.co.uk/news/article-11804491/Train-carrying-30-000-gallons-propane-fuel-derails-Florida.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804491/Train-carrying-30-000-gallons-propane-fuel-derails-Florida.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:09:18+00:00

A train carrying more than 30,0000 gallons of propane fuel derailed in Florida Tuesday afternoon, just weeks after a toxic train overturned in Ohio.

## Sales manager wins £15,000 after recruitment agency boss told her to flirt with customers
 - [https://www.dailymail.co.uk/news/article-11804387/Sales-manager-wins-15-000-recruitment-agency-boss-told-flirt-customers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804387/Sales-manager-wins-15-000-recruitment-agency-boss-told-flirt-customers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:08:58+00:00

Kinga Zborowska was made to feel like a 'sex object' after P&amp;M Resources boss Adam Peruta insisted that it was the 'the best way to get a client's attention,' a tribunal in Manchester heard.

## Newcastle United fan left red-faced after getting a 'Cup Winners' tattoo three days before Wembley
 - [https://www.dailymail.co.uk/news/article-11804447/Newcastle-United-fan-left-red-faced-getting-Cup-Winners-tattoo-three-days-Wembley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804447/Newcastle-United-fan-left-red-faced-getting-Cup-Winners-tattoo-three-days-Wembley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:03:25+00:00

A Newcastle United fan has been left red-faced after getting a 'Cup Winners' tattoo three days before they crashed to defeat at Wembley.

## Manchester Arena bomber had ties to preacher suspected of radicalising people years before attack
 - [https://www.dailymail.co.uk/news/article-11804241/Manchester-Arena-bomber-ties-preacher-suspected-radicalising-people-years-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804241/Manchester-Arena-bomber-ties-preacher-suspected-radicalising-people-years-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 21:00:19+00:00

The preacher, Mansour Al-Anezi, had been investigated before another close associate of his tried to carry out a suicide bombing in Exeter, Devon, in 2008, according to a BBC investigation.

## Window cleaner Keith Richards, 44, is bitten by a pitbull near his Tyne and Wear home
 - [https://www.dailymail.co.uk/news/article-11804469/Window-cleaner-Keith-Richards-44-bitten-pitbull-near-Tyne-Wear-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804469/Window-cleaner-Keith-Richards-44-bitten-pitbull-near-Tyne-Wear-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:59:19+00:00

Keith Richards was left needing hospital treatment after a pit bull reportedly launched a vicious attack on him while he walked his border terrier in Wallsend, Tyne-and-Wear at around 8.15pm on February 14.

## New York teacher 'manipulated' fifth-grade student into changing gender without parents' consent
 - [https://www.dailymail.co.uk/news/article-11804089/New-York-teacher-manipulated-fifth-grade-student-changing-gender-without-parents-consent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804089/New-York-teacher-manipulated-fifth-grade-student-changing-gender-without-parents-consent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:16:42+00:00

The child, who was taught by Debra Rosenquist at Terryville Road Elementary School in Long Island, identifies as a girl but was being called a boy's name and given male pronouns in class.

## Swimming champion's boyfriend jailed for 10 years for 'beating tourist to death' in 2007
 - [https://www.dailymail.co.uk/news/article-11804335/Swimming-champions-boyfriend-jailed-10-years-beating-tourist-death-2007.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804335/Swimming-champions-boyfriend-jailed-10-years-beating-tourist-death-2007.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:16:39+00:00

Sources confirmed to Fox News Digital her boyfriend is Kamal Thomas, 34, who discovered her at their home after returning home from the pub.

## Houston mother who drowned her two children, five and seven, in the bathtub pleads guilty to murder
 - [https://www.dailymail.co.uk/news/article-11804173/Houston-mother-drowned-two-children-five-seven-bathtub-pleads-guilty-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804173/Houston-mother-drowned-two-children-five-seven-bathtub-pleads-guilty-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:16:29+00:00

Sheborah Latrice Thomas, 37, pleaded guilty on Monday to the drowning deaths of her daughter, Kayiana, 5, and son, Araylon, 7, in August 2016.

## Letter to Kmart, Coles, Woolworths and Bunnings staff: 'Nonsense'
 - [https://www.dailymail.co.uk/news/article-11801291/Letter-Kmart-Coles-Woolworths-Bunnings-staff-Nonsense.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801291/Letter-Kmart-Coles-Woolworths-Bunnings-staff-Nonsense.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:15:56+00:00

A shopper's rant on the  number of self-checkouts replacing registers in supermarkets and department stores across Australia has gone viral on social media.

## Notorious Scottish men's prison where transgender rapist Isla Bryson will serve  sentence
 - [https://www.dailymail.co.uk/news/article-11804209/Notorious-Scottish-mens-prison-transgender-rapist-Isla-Bryson-serve-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804209/Notorious-Scottish-mens-prison-transgender-rapist-Isla-Bryson-serve-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:14:26+00:00

Bryson, 31, was last month convicted of raping a woman in Clydebank in 2016 and a second victim in Drumchapel three years later while a man known as Adam Graham.

## Heinz tracks down Ketchup sailor who survived at sea for 24 days eating just the red sauce
 - [https://www.dailymail.co.uk/news/article-11803873/Heinz-tracks-Ketchup-sailor-survived-sea-24-days-eating-just-red-sauce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803873/Heinz-tracks-Ketchup-sailor-survived-sea-24-days-eating-just-red-sauce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:13:03+00:00

Heinz's all-out search for aElvis Francois, who survived 24 days adrift at sea eating ketchup is finally over. The company said it will be gifting him a new boat.

## 'Traumatized' teacher's aide brutally beaten by student reveals she did NOT take Nintendo Switch
 - [https://www.dailymail.co.uk/news/article-11804169/Traumatized-teachers-aide-brutally-beaten-student-reveals-did-NOT-Nintendo-Switch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804169/Traumatized-teachers-aide-brutally-beaten-student-reveals-did-NOT-Nintendo-Switch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:11:39+00:00

Naydich has denied taking the Nintendo Switch from Depa, saying that it was 'misinformation' and she 'wanted to set the record straight.

## The View's Joy Behar DEFENDS Marjorie Taylor Greene over restaurant attack
 - [https://www.dailymail.co.uk/news/article-11804283/The-View-host-Joy-Behar-DEFENDS-Rep-Marjorie-Taylor-Greene-attacked-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804283/The-View-host-Joy-Behar-DEFENDS-Rep-Marjorie-Taylor-Greene-attacked-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:11:32+00:00

View co-host Joy Behar announced during  Tuesday's show that she defended Republican Marjorie Taylor Greene after the congresswoman claimed she was attacked in a restaurant

## Teen girl to go on trial accused of battering three officers at medical centre
 - [https://www.dailymail.co.uk/news/article-11803753/Teen-girl-trial-accused-battering-three-officers-medical-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803753/Teen-girl-trial-accused-battering-three-officers-medical-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:11:25+00:00

Sophie Whyte, 18, allegedly assaulted a female officer and two male constables during a disturbance at Monkgate Health Centre in York on June 20 last year.

## Child hit by train at Tambelin Railway Station in northern Adelaide fighting for life
 - [https://www.dailymail.co.uk/news/article-11804345/Child-hit-train-Tambelin-Railway-Station-northern-Adelaide-fighting-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804345/Child-hit-train-Tambelin-Railway-Station-northern-Adelaide-fighting-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:10:04+00:00

An 11-year-old boy is fighting for life in hospital after he was struck by a train in suburban Adelaide during the morning rush hour yesterday morning

## Maegan Hall says she was 'sexually groomed' by fellow cops
 - [https://www.dailymail.co.uk/news/article-11804297/Maegan-Hall-says-sexually-groomed-fellow-cops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804297/Maegan-Hall-says-sexually-groomed-fellow-cops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:09:03+00:00

Tennessee cop-gone-wild Maegan Hall who was fired over numerous sex romps with officers has claimed that she was 'sexually groomed' by her 'predator' superiors and tried to 'kill herself.'

## Pentagon insists billions in weapons being sent to Ukraine are NOT falling into the wrong hands
 - [https://www.dailymail.co.uk/news/article-11803497/Pentagon-insists-billions-weapons-sent-Ukraine-NOT-falling-wrong-hands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803497/Pentagon-insists-billions-weapons-sent-Ukraine-NOT-falling-wrong-hands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:07:54+00:00

Top Defense officials insisted that Ukraine will not fall to Russia and they have no reason to believe US dollars and equipment are being 'diverted' for unintended purposes.

## San Francisco salon owner says her store has been robbed 4 times in a year as amid rise in crime
 - [https://www.dailymail.co.uk/news/article-11804003/San-Francisco-salon-owner-says-store-robbed-4-times-year-amid-rise-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804003/San-Francisco-salon-owner-says-store-robbed-4-times-year-amid-rise-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:05:44+00:00

A San Francisco salon owner says she is fed up with the rampant crime and mismanagement of the city after her business has been hit by burglars four times in the span of a single year.

## Four men including two Albanian nationals are arrested on suspicion of smuggling migrants
 - [https://www.dailymail.co.uk/news/article-11804427/Four-men-including-two-Albanian-nationals-arrested-suspicion-smuggling-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804427/Four-men-including-two-Albanian-nationals-arrested-suspicion-smuggling-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:03:30+00:00

Four Albanian men suspected of smuggling migrants into the UK in boats from Belgium have been arrested this morning, it has been revealed.

## Henry Rafferty died in a 'tragic accident' after he was killed on a night out in Hartlepool
 - [https://www.dailymail.co.uk/news/article-11803769/Henry-Rafferty-died-tragic-accident-killed-night-Hartlepool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803769/Henry-Rafferty-died-tragic-accident-killed-night-Hartlepool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 20:00:14+00:00

Henry Rafferty, 22, from Hartlepool, Cleveland, died after he was struck by a car while sleeping on the driveway of a house in the town following a night out with friends.

## Cops seized four medical gloves, a silver flashlight and Bryan Kohberger's Under Armour underwear
 - [https://www.dailymail.co.uk/news/article-11804277/Cops-seized-four-medical-gloves-silver-flashlight-Bryan-Kohbergers-Armour-underwear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804277/Cops-seized-four-medical-gloves-silver-flashlight-Bryan-Kohbergers-Armour-underwear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:57:33+00:00

Kohberger, 28, is in custody for the murders of Maddie Mogen, Kaylee Goncalves, Xana Kernodle and Ethan Chapin.

## There is NO plan for John Fetterman to step down, Pennsylvania governor says
 - [https://www.dailymail.co.uk/news/article-11804001/There-NO-plan-John-Fetterman-step-Pennsylvania-governor-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804001/There-NO-plan-John-Fetterman-step-Pennsylvania-governor-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:53:14+00:00

Pennsylvania Gov. Josh Shapiro said Monday that he doesn't expect Sen. John Fetterman to step down and there is 'no contingency plan' in place to pick a replacement.

## The Day Of The Jackal author Frederick Forsyth blasts rewriting Roald Dahl and Ian Fleming
 - [https://www.dailymail.co.uk/news/article-11803919/The-Day-Jackal-author-Frederick-Forsyth-blasts-rewriting-Roald-Dahl-Ian-Fleming.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803919/The-Day-Jackal-author-Frederick-Forsyth-blasts-rewriting-Roald-Dahl-Ian-Fleming.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:45:53+00:00

Best-selling author Frederick Forsyth slammed the decision to rewrite parts of Roald Dahl and Ian Fleming's work to make them more 'acceptable' to modern audiences.

## Ocado kicks off price war with Tesco in bid to lure back shoppers
 - [https://www.dailymail.co.uk/news/article-11804057/Ocado-kicks-price-war-Tesco-bid-lure-shoppers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804057/Ocado-kicks-price-war-Tesco-bid-lure-shoppers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:43:30+00:00

Price-matched items will include Ocado's Own Range essentials, which include items such as milk, eggs and pasta, as well as some branded goods.

## Nigerian lottery fraudster conman has not paid back any of the money he scammed pensioners out of
 - [https://www.dailymail.co.uk/news/article-11803917/Nigerian-lottery-fraudster-conman-not-paid-money-scammed-pensioners-of.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803917/Nigerian-lottery-fraudster-conman-not-paid-money-scammed-pensioners-of.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:33:32+00:00

Frank Onyeachonam, 49, was jailed for eight years in 2014 after a jury found him guilty of conspiracy to defraud following a three week Old Bailey trial.

## Doctor 'felt extremely uncomfortable' about Lucy Letby being alone with baby girl
 - [https://www.dailymail.co.uk/news/article-11803793/Doctor-felt-extremely-uncomfortable-Lucy-Letby-baby-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803793/Doctor-felt-extremely-uncomfortable-Lucy-Letby-baby-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:19:16+00:00

Dr Ravi Jayaram told Manchester Crown Court he felt 'extremely uncomfortable' and found Lucy Letby, 33, doing 'nothing' when the baby's oxygen levels were dropping.

## Joe Biden's brother Jim touted his connections in a groveling letter to a Qatari prince
 - [https://www.dailymail.co.uk/news/article-11763421/Joe-Bidens-brother-Jim-touted-connections-groveling-letter-Qatari-prince.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11763421/Joe-Bidens-brother-Jim-touted-connections-groveling-letter-Qatari-prince.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:16:51+00:00

The letter is the latest in a series of revelations about Jim Biden using his family name and connection to Joe to boost his connections in the Middle East.

## Missouri girl, 15, shot dead in 'robbery gone wrong': Two teenagers arrested for murder
 - [https://www.dailymail.co.uk/news/article-11803729/Missouri-girl-15-shot-dead-robbery-gone-wrong-Two-teenagers-arrested-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803729/Missouri-girl-15-shot-dead-robbery-gone-wrong-Two-teenagers-arrested-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:09:02+00:00

A 15-year-old Missouri girl was fatally shot during a botched robbery when gunman opened fire into the car she was in. Two teens - 16 and 17 - are now arrested for her murder.

## Rishi Sunak warns Tory critics that failure to back his Brexit deal could lead to election hammering
 - [https://www.dailymail.co.uk/news/article-11804139/Rishi-Sunak-warns-Tory-critics-failure-Brexit-deal-lead-election-hammering.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11804139/Rishi-Sunak-warns-Tory-critics-failure-Brexit-deal-lead-election-hammering.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:04:18+00:00

The Prime Minister faced his MPs tonight and told them failing to settle the long-running saga over Northern Ireland would mean 'voters will begin to doubt our ability to deliver' any political change.

## Law firm sues attorney for 'quiet quitting' by doing 'bare minimum' while collecting $400k salary
 - [https://www.dailymail.co.uk/news/article-11803483/Law-firm-sues-attorney-quiet-quitting-doing-bare-minimum-collecting-400k-salary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803483/Law-firm-sues-attorney-quiet-quitting-doing-bare-minimum-collecting-400k-salary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 19:04:07+00:00

Napoli Shkolnik is suing Heather Palmore, 52, claiming she also set up her own firm while she was meant to be devoted to her role at their firm.

## Furious Tennessee residents slam Jack Daniels for out-of-control black 'whiskey fungus'
 - [https://www.dailymail.co.uk/news/article-11803583/Furious-Tennessee-residents-slam-Jack-Daniels-control-black-whiskey-fungus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803583/Furious-Tennessee-residents-slam-Jack-Daniels-control-black-whiskey-fungus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:59:40+00:00

Known as 'whisky fungus', a persistent black mold has plagued residents of Lincoln County ever since Jack Daniels expanded its barrel house operation, with the fungus being fueled by ethanol vapors.

## Hundreds of New Jersey high school students stage walkout days after boy, 11, was stabbed
 - [https://www.dailymail.co.uk/news/article-11803651/Hundreds-New-Jersey-high-school-students-stage-walkout-days-boy-11-stabbed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803651/Hundreds-New-Jersey-high-school-students-stage-walkout-days-boy-11-stabbed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:57:51+00:00

Hundreds of New Jersey high school students and parents have demanded for the resignation of Perth Amboy's superintendent after an 11-year-old boy was taken to hospital after being stabbed.

## Family of Brooklyn cyclist who died after being run over by 26-foot box truck sue city for $100M
 - [https://www.dailymail.co.uk/news/article-11803413/Family-Brooklyn-cyclist-died-run-26-foot-box-truck-sue-city-100M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803413/Family-Brooklyn-cyclist-died-run-26-foot-box-truck-sue-city-100M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:48:31+00:00

Cyclist Sarah Schick, 37, died after she was struck by a truck on Ninth Street near Second Avenue in the Gowanus area of Brooklyn last month - and now her family is suing NYC for $100M.

## 'It's worse than the McCarthy era'. 3/4 of conservative academics fear being sacked for their views
 - [https://www.dailymail.co.uk/news/article-11803257/Its-worse-McCarthy-era-3-4-conservative-academics-fear-sacked-views.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803257/Its-worse-McCarthy-era-3-4-conservative-academics-fear-sacked-views.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:20:02+00:00

The poll of some 1,500 faculty members across the US comes as campaigners and politicians from left and right turn campuses into front lines on America's culture wars.

## Supreme Court conservatives question if Biden has power to wipe student debt
 - [https://www.dailymail.co.uk/news/article-11803605/Supreme-Court-conservatives-question-Biden-power-wipe-student-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803605/Supreme-Court-conservatives-question-Biden-power-wipe-student-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:18:41+00:00

Conservative Supreme Court justices expressed doubt during arguments Tuesday that the Biden administration had the ability to bypass Congress to provide billions in student loan forgiveness.

## Horrific moment man casually loads his gun and executes homeless man on St Louis sidewalk
 - [https://www.dailymail.co.uk/news/article-11803869/Horrific-moment-man-casually-loads-gun-executes-homeless-man-St-Louis-sidewalk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803869/Horrific-moment-man-casually-loads-gun-executes-homeless-man-St-Louis-sidewalk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:18:07+00:00

Harrowing footage shared online shows the shooter standing behind the homeless victim as he sits on the sidewalk with his hands covering his ears.

## Pathologist in Murdaugh trial rejects claim shotgun was touching back of son's head
 - [https://www.dailymail.co.uk/news/article-11803795/Pathologist-Murdaugh-trial-rejects-claim-shotgun-touching-sons-head.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803795/Pathologist-Murdaugh-trial-rejects-claim-shotgun-touching-sons-head.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:11:35+00:00

Dr Ellen Riemer told the Colleton County court in Walterboro that if the 12-gauge shotgun was pressed against Paul's head the blast would have 'split his face open' and left his 'eyes hanging down.'

## U.S. mistakes led to rapid collapse of Afghanistan government, report states
 - [https://www.dailymail.co.uk/news/article-11802825/U-S-mistakes-led-rapid-collapse-Afghanistan-government-report-states.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802825/U-S-mistakes-led-rapid-collapse-Afghanistan-government-report-states.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:05:49+00:00

The scathing analysis by the Special Inspector General for Afghanistan Reconstruction (SIGAR) has detailed the role of the U.S. in laying the groundwork for the Taliban to take control.

## Constance Marten: Wealthy aristocratic lifestyle of the ex Tatler It-girl
 - [https://www.dailymail.co.uk/news/article-11803405/Constance-Marten-Wealthy-aristocratic-lifestyle-ex-Tatler-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803405/Constance-Marten-Wealthy-aristocratic-lifestyle-ex-Tatler-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:05:07+00:00

Constance Marten, 35, is the daughter of Napier Marten, a former page to the Queen who experienced an 'epiphany'.

## Drug addict scammed her grandfather out of £75,000
 - [https://www.dailymail.co.uk/news/article-11803831/Drug-addict-scammed-grandfather-75-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803831/Drug-addict-scammed-grandfather-75-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 18:04:07+00:00

Olivia Crutchley stole nearly £75,000 from the man she described as her 'best friend', cruelly conning him over the course of more than 18 months in order to fund her drug addiction.

## JV Vandergrift hasn't used credit cards, phone since vanishing; no leads in 94.9 DJ's disappearance
 - [https://www.dailymail.co.uk/news/article-11803597/JV-Vandergrift-used-credit-cards-phone-vanishing-no-leads-94-9-DJs-disappearance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803597/JV-Vandergrift-used-credit-cards-phone-vanishing-no-leads-94-9-DJs-disappearance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:58:03+00:00

JV Vandergrift, the San Francisco radio DJ who went missing after leaving a chilling final message on his Instagram page, hasn't used his credit cards or phone since disappearing, Wild 94.9 confirmed.

## 'Killer cannibal' is arrested at Portuguese airport with 'suspicious meat' in his suitcase
 - [https://www.dailymail.co.uk/news/article-11803817/Killer-cannibal-arrested-Portuguese-airport-suspicious-meat-suitcase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803817/Killer-cannibal-arrested-Portuguese-airport-suspicious-meat-suitcase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:57:12+00:00

Begolea Mendes Fernandes, 25, was detained at Lisbon Airport after arriving on a flight from Amsterdam. He is suspected of killing a 21-year-old man in the Dutch capital on Sunday

## Bus driver with Asperger's Syndrome who was called an 'illiterate imbecile' wins £30,000 payout
 - [https://www.dailymail.co.uk/news/article-11803091/Bus-driver-Aspergers-Syndrome-called-illiterate-imbecile-wins-30-000-payout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803091/Bus-driver-Aspergers-Syndrome-called-illiterate-imbecile-wins-30-000-payout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:21:43+00:00

The Leeds tribunal panel heard that bus driver Thomas Holland started working for A&amp;A Coach Travel Ltd in September 2016 after telling them he had Asperger's Syndrome.

## Ferrari driver who smashed £500K supercar head-on into row of five parked cars
 - [https://www.dailymail.co.uk/news/article-11803313/Ferrari-driver-smashed-500K-supercar-head-row-five-parked-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803313/Ferrari-driver-smashed-500K-supercar-head-row-five-parked-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:21:22+00:00

Richard Cullen was reportedly banned from the roads after losing control of his vehicle and causing a five-car collision in Romsley, Worcestershire.

## Evan Rachel Wood denies she 'manipulated' Marilyn Manson accuser to 'lie' about sexual assault
 - [https://www.dailymail.co.uk/news/article-11803311/Evan-Rachel-Wood-denies-manipulated-Marilyn-Manson-accuser-lie-sexual-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803311/Evan-Rachel-Wood-denies-manipulated-Marilyn-Manson-accuser-lie-sexual-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:21:15+00:00

Evan Rachel Wood, 35, denied in a recent court filing that she 'manipulated' Ashley Morgan Smithline to 'lie' about being sexually abused by singer Marilyn Manson.

## Ed Sheeran's touring partner, musician Ben Kweller, reveals his 16-year-old son has been killed
 - [https://www.dailymail.co.uk/news/article-11803695/Ed-Sheerans-touring-partner-musician-Ben-Kweller-reveals-16-year-old-son-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803695/Ed-Sheerans-touring-partner-musician-Ben-Kweller-reveals-16-year-old-son-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:18:44+00:00

Musician Ben Kweller said that his son Dorian, 16, was a keen musician and recorded songs 'every day'.

## Kayla Lemieux: Parents launch legal fund to sue school over her 'fetish-gear'
 - [https://www.dailymail.co.uk/news/article-11803341/Kayla-Lemieux-Parents-launch-legal-fund-sue-school-fetish-gear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803341/Kayla-Lemieux-Parents-launch-legal-fund-sue-school-fetish-gear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:17:38+00:00

Concerned parents of students in Oakville Trafalgar High School , where trans teacher Kayla Lemieux works, have launched a legal fund in order to sue the district to enforce a dress code.

## Lady whose dream Norfolk home is inching closer to cliff edge says she won't last much longer
 - [https://www.dailymail.co.uk/news/article-11803567/Lady-dream-Norfolk-home-inching-closer-cliff-edge-says-wont-longer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803567/Lady-dream-Norfolk-home-inching-closer-cliff-edge-says-wont-longer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:17:37+00:00

A pub landlady who bought her dream Norfolk retirement home has seen her dream turn into a nightmare as it teeters over a cliff and on the verge of slipping into the sea.

## Chance The Rapper reveals Martin Short gave up his plane seat to singer's daughter
 - [https://www.dailymail.co.uk/news/article-11803289/Chance-Rapper-reveals-Martin-Short-gave-plane-seat-singers-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803289/Chance-Rapper-reveals-Martin-Short-gave-plane-seat-singers-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:13:14+00:00

Chance the Rapper has described how actor Martin Short offered to swap plane seats with his daughter so he could sit next to her.

## Judge slams GMC for 'failure' as bogus psychiatrist faked qualifications to practise for two decades
 - [https://www.dailymail.co.uk/news/article-11803691/Judge-slams-GMC-failure-bogus-psychiatrist-faked-qualifications-practise-two-decades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803691/Judge-slams-GMC-failure-bogus-psychiatrist-faked-qualifications-practise-two-decades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:13:05+00:00

The General Medical Council was savaged for for a 'failure of scrutiny' today - after a bogus psychiatrist was able to practise in the UK for more than 20 years with fake papers.

## US requests extradition of El Chapo's son Ovidio Guzman
 - [https://www.dailymail.co.uk/news/article-11802969/US-requests-extradition-El-Chapos-son-Ovidio-Guzman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802969/US-requests-extradition-El-Chapos-son-Ovidio-Guzman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:11:07+00:00

The United States embassy in Mexico submitted a formal request for the extradition of Ovidio Guzmán, one of El Chapo's four sons who run half of the Sinaloa Cartel.

## FTX engineering director agrees to plead guilty, flips on Sam Bankman-Fried
 - [https://www.dailymail.co.uk/news/article-11803701/FTX-engineering-director-agrees-plead-guilty-flips-Sam-Bankman-Fried.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803701/FTX-engineering-director-agrees-plead-guilty-flips-Sam-Bankman-Fried.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:09:43+00:00

Nishad Singh (right), the former director of engineering at now-bankrupt cryptocurrency exchange FTX, has agreed to plead guilty to US criminal charges, his lawyer said on Tuesday

## Ex-Marine arrested trying to board fligh with AR-15, handguns, a Taser and fake US Marshalls badge
 - [https://www.dailymail.co.uk/news/article-11803201/Ex-Marine-arrested-trying-board-fligh-AR-15-handguns-Taser-fake-Marshalls-badge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803201/Ex-Marine-arrested-trying-board-fligh-AR-15-handguns-Taser-fake-Marshalls-badge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:08:07+00:00

Ex-felon Seretse Clouden, 42, was arrested for trying to board a flight from Newark armed with an AR-15, handguns, Taser and bogus US Marshalls badge, but was caught at the luggage check-in.

## Paul O'Grady slams Radio 2 saying station is 'not what it was' after Ken Bruce quit
 - [https://www.dailymail.co.uk/news/article-11803045/Paul-OGrady-slams-Radio-2-saying-station-not-Ken-Bruce-quit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803045/Paul-OGrady-slams-Radio-2-saying-station-not-Ken-Bruce-quit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:08:07+00:00

The broadcaster, 67, spoke out following the news Bruce was leaving the BBC station after 45 years to go to commercial rival Greatest Hits Radio.

## Last Instagram posts of Lib Dem peer Brian Paddick's husband in months before his mystery death
 - [https://www.dailymail.co.uk/news/article-11803119/Last-Instagram-posts-Lib-Dem-peer-Brian-Paddicks-husband-months-mystery-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803119/Last-Instagram-posts-Lib-Dem-peer-Brian-Paddicks-husband-months-mystery-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:08:02+00:00

Liberal Democrat peer and former I'm A Celebrity contestant Brian Paddick's husband's final social media posts showed him at home in Oslo and enjoying time on a beach.

## Biden steps up war with 'MAGA Republicans' by claiming they will add $3trillion more to the deficit
 - [https://www.dailymail.co.uk/news/article-11803011/Biden-steps-war-MAGA-Republicans-claiming-add-3trillion-deficit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803011/Biden-steps-war-MAGA-Republicans-claiming-add-3trillion-deficit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 17:05:05+00:00

President Joe Biden heads to Virginia beach on Tuesday, where he will go after 'MAGA' Republicans for proposals to cut Medicaid or try to go after the Affordable Care Act.

## How Mark Wahlberg served time after attacks on Vietnamese men as a teenager
 - [https://www.dailymail.co.uk/news/article-11803485/How-Mark-Wahlberg-served-time-attacks-Vietnamese-men-teenager.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803485/How-Mark-Wahlberg-served-time-attacks-Vietnamese-men-teenager.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:56:53+00:00

Renowned actor Mark Wahlberg was arrested in 1988, aged 16, after knocking out a man with a stick while under the influence of PCP and punching a man in the face  the same day,

## Trump rages at Rupert Murdoch over Dominion lawsuit deposition
 - [https://www.dailymail.co.uk/news/article-11803239/Trump-rages-Rupert-Murdoch-Dominion-lawsuit-deposition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803239/Trump-rages-Rupert-Murdoch-Dominion-lawsuit-deposition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:18:12+00:00

The 2024 Republican presidential candidate also insisted there is 'massive evidence' of voter fraud from the 2020 election, and claimed Fox News is 'scared and frightened' to discuss it.

## Leila Borrington convicted of manslaughter after filming her stepson, 3, dying
 - [https://www.dailymail.co.uk/news/article-11803183/Leila-Borrington-convicted-manslaughter-filming-stepson-3-dying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803183/Leila-Borrington-convicted-manslaughter-filming-stepson-3-dying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:17:17+00:00

Little Harvey Borrington was found by paramedics at the family home in Jacksdale, Nottingham, 'unconscious' and 'unresponsive' on August 7, 2021,

## Kate Middleton joins Prince William on a visit to Wales
 - [https://www.dailymail.co.uk/femail/article-11802145/Kate-Middleton-joins-Prince-William-visit-Wales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11802145/Kate-Middleton-joins-Prince-William-visit-Wales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:14:55+00:00

Ahead of St. David's Day, The Prince and Princess of Wales are visiting the country to champion mental health initiatives and meet local communities.

## Paedophile who sexually abused children while posing as a babysitter is jailed in Germany
 - [https://www.dailymail.co.uk/news/article-11803099/Paedophile-sexually-abused-children-posing-babysitter-jailed-Germany.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803099/Paedophile-sexually-abused-children-posing-babysitter-jailed-Germany.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:12:07+00:00

Marcus R., 45, drugged the young girls and boys inside their homes before sexually abusing them as they screamed in pain, the district court of Cologne heard.

## Britain's 'best beach' is seaside spot in Norfolk which featured in Richard Curtis movie 'Yesterday'
 - [https://www.dailymail.co.uk/news/article-11802539/Britains-best-beach-seaside-spot-Norfolk-featured-Richard-Curtis-movie-Yesterday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802539/Britains-best-beach-seaside-spot-Norfolk-featured-Richard-Curtis-movie-Yesterday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:11:24+00:00

Gorleston-on-Sea, Norfolk,  was named the best beach in the UK, while Bournemouth, Weymouth and Fistral beaches also came in the top 25 best beaches worldwide

## Race faking white Muslim RESIGNS as chief equity and inclusion officer
 - [https://www.dailymail.co.uk/news/article-11802847/Race-faking-white-Muslim-inclusion-officer-RESIGNS-role-chief-equity-inclusion-officer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802847/Race-faking-white-Muslim-inclusion-officer-RESIGNS-role-chief-equity-inclusion-officer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:10:48+00:00

A white chief inclusion officer at a Philadelphia Quaker-founded social justice firm who faked 'Arab, Latin and South Asian' heritage has resigned from her position after being outed for lying.

## Share of home deals done in cash rises to nine-year high
 - [https://www.dailymail.co.uk/news/article-11802827/Share-home-deals-cash-rises-nine-year-high.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802827/Share-home-deals-cash-rises-nine-year-high.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:07:33+00:00

The share of home purchases made in cash rose to its highest level in nine years in 2022, even as the institutional buyers who traditionally pay in cash pulled back from the market.

## Husband of Epsom College headteacher 'shot himself in the head', inquest hears
 - [https://www.dailymail.co.uk/news/article-11803335/Husband-Epsom-College-headteacher-shot-head-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803335/Husband-Epsom-College-headteacher-shot-head-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:02:12+00:00

George Pattison, who is believed to have murdered his wife Emma Pattison and daughter Lettie before killing himself, died of a 'shotgun wound to the head', an inquest heard

## Barefoot Investor Scott Pape reveals how much Superannuation you need to retire
 - [https://www.dailymail.co.uk/news/article-11801621/Barefoot-Investor-Scott-Pape-reveals-Superannuation-need-retire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801621/Barefoot-Investor-Scott-Pape-reveals-Superannuation-need-retire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:01:49+00:00

Finance guru Scott Pape has revealed that Aussies only need about half the recommended amount of superannuation when they retire,

## Reddit channel 'Brynation' which sprang up in support of Idaho murder suspect Bryan Kohberger banned
 - [https://www.dailymail.co.uk/news/article-11802951/Reddit-channel-Brynation-sprang-support-Idaho-murder-suspect-Bryan-Kohberger-banned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802951/Reddit-channel-Brynation-sprang-support-Idaho-murder-suspect-Bryan-Kohberger-banned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:01:00+00:00

A Reddit channel for supporters of Idaho quadruple murder suspect Bryan Kohberger, 28, has been banned - yet there are Facebook fan groups with thousands of members still active.

## College admissions scandal ringleader Rick Singer starts 42-month sentence
 - [https://www.dailymail.co.uk/news/article-11802857/College-admissions-scandal-ringleader-Rick-Singer-starts-42-month-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802857/College-admissions-scandal-ringleader-Rick-Singer-starts-42-month-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:00:57+00:00

Rick Singer began his three-and-a-half year prison sentence at the Federal Prison Camp Pensacola in Florida on Tuesday. He plead guilty to organizing a college admission scheme.

## How Lisa Wilkinson could derail Bruce Lehrmann's defamation claim
 - [https://www.dailymail.co.uk/news/article-11800843/How-Lisa-Wilkinson-derail-Bruce-Lehrmanns-defamation-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800843/How-Lisa-Wilkinson-derail-Bruce-Lehrmanns-defamation-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:00:54+00:00

Bruce Lehrmann is suing Channel 10 over an interview aired on The Project where Ms Higgins first alleged to Ms Wilkinson that she was raped by 'a male colleague' in 2019.

## Biden administration promises crack down on child  labor after damning report
 - [https://www.dailymail.co.uk/news/article-11802955/Biden-administration-promises-crack-child-labor-damning-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802955/Biden-administration-promises-crack-child-labor-damning-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:00:18+00:00

The New York Times published an expose  that laid bare how hundreds of children were being funneled out of overwhelmed shelters and into the care of distant relatives or strangers.

## Gold Coast crash: Soccer player's unsuccessful $600,000 injury compensation claim
 - [https://www.dailymail.co.uk/news/article-11794389/Gold-Coast-crash-Soccer-players-unsuccessful-600-000-injury-compensation-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11794389/Gold-Coast-crash-Soccer-players-unsuccessful-600-000-injury-compensation-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 16:00:16+00:00

A promising young soccer player who suffered a long list of injuries when a car slammed into her  on a Gold Coast footpath has had most of her compensation claim dismissed.

## Ghislaine Maxwell is appealing her sex trafficking conviction
 - [https://www.dailymail.co.uk/news/article-11803287/Ghislaine-Maxwell-appealing-sex-trafficking-conviction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803287/Ghislaine-Maxwell-appealing-sex-trafficking-conviction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:57:48+00:00

Ghislaine Maxwell will claim that she did not testify during her sex trafficking trial because she was in poor condition due to prison treatment.

## Theresa Mayday, mayday! Ex-PM feigns sleep as hardcore eurosceptic Bill Cash drones on about Europe
 - [https://www.dailymail.co.uk/news/article-11803165/Theresa-Mayday-mayday-Ex-PM-feigns-sleep-hardcore-eurosceptic-Bill-Cash-drones-Europe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803165/Theresa-Mayday-mayday-Ex-PM-feigns-sleep-hardcore-eurosceptic-Bill-Cash-drones-Europe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:56:50+00:00

Mrs May slumped over in her seat, feigning boredom and falling sleep as 82-year-old Bill Cash subjected the chamber to an anecdote about the Maastricht Treaty.

## Paul O'Grady slams Radio 2 saying station is 'not what it was' after Ken Bruce was forced out
 - [https://www.dailymail.co.uk/news/article-11803045/Paul-OGrady-slams-Radio-2-saying-station-not-Ken-Bruce-forced-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803045/Paul-OGrady-slams-Radio-2-saying-station-not-Ken-Bruce-forced-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:55:33+00:00

The broadcaster, 67, spoke out following the news Bruce was leaving the BBC station after 45 years to go to commercial rival Greatest Hits Radio .

## BBC journalist apologises to the people of Grenada for aristocratic family's ownership of slaves
 - [https://www.dailymail.co.uk/news/article-11802961/BBC-journalist-apologises-people-Grenada-aristocratic-familys-ownership-slaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802961/BBC-journalist-apologises-people-Grenada-aristocratic-familys-ownership-slaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:52:56+00:00

Laura Trevelyan, 54, a BBC reporter based in New York, delivered the apology at a ceremony in the capital St George's on Monday, attended by Grenada's prime minister.

## Pictured: Mother-of-three reported missing as detectives arrest man on suspicion of murder
 - [https://www.dailymail.co.uk/news/article-11803193/Pictured-Mother-three-reported-missing-detectives-arrest-man-suspicion-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803193/Pictured-Mother-three-reported-missing-detectives-arrest-man-suspicion-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:33:14+00:00

Sarah Albone's family reported her missing to the police on Tuesday February 21 after concerns they had not seen her since before Christmas 2022.

## Transgender pedophile Hannah Tubbs screamed at prison guards 'I'm a grown-a** man'
 - [https://www.dailymail.co.uk/news/article-11798683/Transgender-pedophile-Hannah-Tubbs-screamed-prison-guards-Im-grown-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11798683/Transgender-pedophile-Hannah-Tubbs-screamed-prison-guards-Im-grown-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:24:48+00:00

Prosecutor Shea Sanna tells DailyMail.com that Tubbs repeatedly referred to herself as 'he' and joked with her father about choosing the name Hannah.

## British woman is mauled to death in Spain by an abandoned pit bull she took in
 - [https://www.dailymail.co.uk/news/spain/article-11803039/British-woman-mauled-death-Spain-abandoned-pit-bull-took-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/spain/article-11803039/British-woman-mauled-death-Spain-abandoned-pit-bull-took-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:21:22+00:00

The woman had been in possession of the dog for just a few days before it fatally injured her at her house. At around 2pm on Friday, authorities were called to the scene after screams were overheard.

## Sainsbury's plans to close two Argos depots over next three years
 - [https://www.dailymail.co.uk/news/article-11803151/Sainsburys-plans-close-two-Argos-depots-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803151/Sainsburys-plans-close-two-Argos-depots-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:19:14+00:00

Reacting to today's news, trade union Unite said it would be 'fighting to preserve every job' at the UK sites.

## Swimming champion, 42, 'was in cardiac arrest and was given CPR before she was pronounced dead'
 - [https://www.dailymail.co.uk/news/article-11802893/Swimming-champion-42-cardiac-arrest-given-CPR-pronounced-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802893/Swimming-champion-42-cardiac-arrest-given-CPR-pronounced-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:15:02+00:00

Jamie Cail, 42, was found unresponsive on February 21 by her boyfriend - who has not been identified - with police launching a criminal investigation.

## Madonna paid the bill for troubled brother's rehab treatment in Michigan days before his death
 - [https://www.dailymail.co.uk/news/article-11802753/Madonna-paid-bill-troubled-brothers-rehab-treatment-Michigan-days-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802753/Madonna-paid-bill-troubled-brothers-rehab-treatment-Michigan-days-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:14:49+00:00

Despite a fierce sibling rivalry that plagued their relationship for decades, Madonna, left, reportedly footed the bill for the rehab treatment of her troubled brother Anthony Ciccone, right.

## Food price inflation hits record 17% and could add £810 to annual shopping bills, new figures show
 - [https://www.dailymail.co.uk/news/article-11802019/Food-price-inflation-hits-record-17-add-810-annual-shopping-bills-new-figures-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802019/Food-price-inflation-hits-record-17-add-810-annual-shopping-bills-new-figures-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:13:42+00:00

This month marks a full year since monthly grocery inflation rose beyond four per cent as consumers named it their second most important issue behind energy costs, analysts said.

## Shocking moment New Jersey home explodes with six firefighters inside
 - [https://www.dailymail.co.uk/news/article-11802749/Shocking-moment-New-Jersey-home-explodes-six-firefighters-inside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802749/Shocking-moment-New-Jersey-home-explodes-six-firefighters-inside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:12:16+00:00

Body cam footage captured the moment six volunteer firefighters in New Jersey were in a home that dramatically exploded.

## Parents who let children truant could be stripped of benefits, Michael Gove says
 - [https://www.dailymail.co.uk/news/article-11803097/Parents-let-children-truant-stripped-benefits-Michael-Gove-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11803097/Parents-let-children-truant-stripped-benefits-Michael-Gove-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:09:59+00:00

Levelling Up Secretary Michael Gove floated the idea as part of a 'rigorous drive' to get youngsters in the classroom.

## Rockpool Bar and Grill in Perth's Crown Casino slammed for forcing customers to tip
 - [https://www.dailymail.co.uk/news/article-11802507/Rockpool-Bar-Grill-Perths-Crown-Casino-slammed-forcing-customers-tip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802507/Rockpool-Bar-Grill-Perths-Crown-Casino-slammed-forcing-customers-tip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:03:27+00:00

Customer Claire O'Donnell was shocked by a 'service fee' that made up $71.01 of her $1491.01 bill after dining at Rockpool Bar and Grill.

## Chris Rock will hit back at Will Smith's Oscars slap during live-streamed Netflix special
 - [https://www.dailymail.co.uk/news/article-11802823/Chris-Rock-hit-Smiths-Oscars-slap-live-streamed-Netflix-special.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802823/Chris-Rock-hit-Smiths-Oscars-slap-live-streamed-Netflix-special.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 15:02:09+00:00

Nearly a year after he was assaulted on stage by Will Smith, comedian Chris Rock will finally address the slap heard round the world in his upcoming Netflix special.

## Sonya Gapes found guilty of 126 counts of animal abuse in Townsville, Queensland
 - [https://www.dailymail.co.uk/news/article-11802525/Sonya-Gapes-guilty-126-counts-animal-abuse-Townsville-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802525/Sonya-Gapes-guilty-126-counts-animal-abuse-Townsville-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:59:51+00:00

Sonya Lesley Gapes, 52, was convicted of 126 counts of animal abuse and was deemed 'ill-equipped' to handle  pets.

## Adidas could be forced to burn $500M in Yeezy stock after Kanye West's anti-Semitic outbursts
 - [https://www.dailymail.co.uk/news/article-11802889/Adidas-forced-burn-500M-Yeezy-stock-Kanye-Wests-anti-Semitic-outbursts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802889/Adidas-forced-burn-500M-Yeezy-stock-Kanye-Wests-anti-Semitic-outbursts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:56:19+00:00

Adidas could be forced to burn Yeezy sneakers worth around half-a-billion dollars after rapper and fashion designer Kanye West's anti-Semitic outbursts.

## Chicago Mayor Lori Lightfoot facing uphill battle to keep her seat amid soaring crime
 - [https://www.dailymail.co.uk/news/article-11802761/Chicago-Mayor-Lori-Lightfoot-facing-uphill-battle-seat-amid-soaring-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802761/Chicago-Mayor-Lori-Lightfoot-facing-uphill-battle-seat-amid-soaring-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:32:41+00:00

Lori Lightfoot could become the first Chicago mayor in 40 years to lose reelection as voters head to the polls Tuesday amid soaring crime-rates in the city, leading to a clear out of the shopping district.

## Family of 18th century Tory politician Henry Dundas claim plaque added to his statue 'inaccurate'
 - [https://www.dailymail.co.uk/news/article-11802801/Family-18th-century-Tory-politician-Henry-Dundas-claim-plaque-added-statue-inaccurate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802801/Family-18th-century-Tory-politician-Henry-Dundas-claim-plaque-added-statue-inaccurate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:20:48+00:00

Planning officials are recommending that the Melville Monument's plaque is removed amid claims that it is historically inaccurate and misleading about Henry Dundas.

## Debate erupts between Boomers and Millennials over ANZ home loan document from 1996
 - [https://www.dailymail.co.uk/news/article-11802155/Debate-erupts-Boomers-Millennials-ANZ-home-loan-document-1996.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802155/Debate-erupts-Boomers-Millennials-ANZ-home-loan-document-1996.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:20:39+00:00

An old home loan document showing high interest rates in the 1990s has sparked furious debate about which generation had it tougher buying a place of their own.

## Levi Davis: Final voice message sent by missing X Factor star just hours after vanishing is revealed
 - [https://www.dailymail.co.uk/news/article-11802763/Levi-Davis-Specialist-crime-unit-Spain-investigating-disappearance-missing-X-Factor-star.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802763/Levi-Davis-Specialist-crime-unit-Spain-investigating-disappearance-missing-X-Factor-star.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:19:09+00:00

Former Bath rugby player Davis, 24, went missing on October 29 after leaving a friend in Ibiza to get the ferry to Barcelona alone.

## Teen who knocked out his teacher was arrested THREE times for battery and will be charged as adult
 - [https://www.dailymail.co.uk/news/article-11802533/Teen-knocked-teacher-arrested-THREE-times-battery-charged-adult.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802533/Teen-knocked-teacher-arrested-THREE-times-battery-charged-adult.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:18:09+00:00

Brendan Depa, 17, can be named for the first time after the Seventh Judicial Court of Florida ruled that he would be transferred to adult court.

## Manson Family member Linda Kasabian dies at age 73
 - [https://www.dailymail.co.uk/news/article-11802737/Manson-Family-member-Linda-Kasabian-dies-age-73.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802737/Manson-Family-member-Linda-Kasabian-dies-age-73.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:17:58+00:00

Linda Kasabian, who dodged jail by testifying against the other members of the cult, was the getaway driver and lookout during the murders in 1969 - in which pregnant Sharon Tate was butchered.

## Black British Army soldier drove his car at pals before slashing at them with a machete
 - [https://www.dailymail.co.uk/news/article-11802627/Black-British-Army-soldier-drove-car-pals-slashing-machete.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802627/Black-British-Army-soldier-drove-car-pals-slashing-machete.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:16:02+00:00

Bombardier Kevin Carasco allegedly became annoyed when he thought his comrades were conspiring to beat him up, which triggered his alleged attack at Baker Barracks, near Portsmouth, Hampshire.

## Hotel manager, 27, killed after being hit by car while crossing Kensington High Street
 - [https://www.dailymail.co.uk/news/article-11802933/Hotel-manager-27-killed-hit-car-crossing-Kensington-High-Street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802933/Hotel-manager-27-killed-hit-car-crossing-Kensington-High-Street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:12:25+00:00

Tributes have poured in for a 27-year-old hotel manager who was killed after being struck by a vehicle on Kensington High Street last week. Niksan D'Costa was hit and killed by a car.

## Prosecutors in Alex Murdaugh's trial are set to hit back with rebuttal witnesses
 - [https://www.dailymail.co.uk/news/article-11802855/Prosecutors-Alex-Murdaughs-trial-set-hit-rebuttal-witnesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802855/Prosecutors-Alex-Murdaughs-trial-set-hit-rebuttal-witnesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:09:55+00:00

Alex Murdaugh's double murder trial is today set to hear from rebuttal witnesses for the prosecution after the defense claimed two shooters killed his wife and son in Moselle, SC.

## 'TikTok protests' rock Britain's schools: Pupils  scale gates and trash classrooms over rules
 - [https://www.dailymail.co.uk/news/article-11802555/TikTok-protests-rock-Britains-schools-Pupils-scale-gates-trash-classrooms-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802555/TikTok-protests-rock-Britains-schools-Pupils-scale-gates-trash-classrooms-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:09:08+00:00

TikTok protests are continuing to rock Britain's schools in Hampshire, Essex and Lancashire as hundreds of pupils rebelled against school rules, including unisex toilets.

## Poll finds public backs lower spending and lower taxes
 - [https://www.dailymail.co.uk/news/article-11802821/Poll-finds-public-backs-lower-spending-lower-taxes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802821/Poll-finds-public-backs-lower-spending-lower-taxes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:05:02+00:00

Research for MailOnline found 38 per cent want to see the government reduce the burden immediately - double the 19 per cent who favoured more tax.

## JK Rowling says backlash over trans views is being used to silence others
 - [https://www.dailymail.co.uk/news/article-11802481/JK-Rowling-says-backlash-trans-views-used-silence-others.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802481/JK-Rowling-says-backlash-trans-views-used-silence-others.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 14:02:37+00:00

Speaking on a new podcast, The Witch Trials of JK Rowling, the British author said she had received 'direct threats of violence'.

## 2014 South Park clip of Cartman identifying as trans to use women's bathroom goes viral
 - [https://www.dailymail.co.uk/news/article-11802405/2014-South-Park-clip-Cartman-identifying-trans-use-womens-bathroom-goes-viral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802405/2014-South-Park-clip-Cartman-identifying-trans-use-womens-bathroom-goes-viral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:57:23+00:00

'The Cissy' originally aired in 2014 and followed Eric Cartman as he chose to identify as a girl, wearing a pink bow, in order to enjoy more space using a cubicle in the girls' school bathroom.

## Florida gunman who shot journalist and nine-year-old girl seen in new mugshot
 - [https://www.dailymail.co.uk/news/article-11802605/Florida-gunman-shot-journalist-nine-year-old-girl-seen-new-mugshot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802605/Florida-gunman-shot-journalist-nine-year-old-girl-seen-new-mugshot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:49:57+00:00

Keith Melvin Moses, 19, is in custody for shooting dead Nathacha Augustin, 38, journalist Dylan Lyons, and nine-year-old T'Yonna Major last Wednesday.

## Watch the moment a cashier is attacked by mom and daughters over queue-jumping row the week before
 - [https://www.dailymail.co.uk/news/article-11802715/Watch-moment-cashier-attacked-mom-daughters-queue-jumping-row-week-before.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802715/Watch-moment-cashier-attacked-mom-daughters-queue-jumping-row-week-before.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:41:32+00:00

Violent crime including rape, robbery and assault were all reported to have risen last year based on annually released statistics, despite efforts to increase police presence on the streets of the city.

## Energy Secretary hints 20% energy bill hike in April WILL be ditched
 - [https://www.dailymail.co.uk/news/article-11802793/Energy-Secretary-hints-20-energy-bill-hike-April-ditched.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802793/Energy-Secretary-hints-20-energy-bill-hike-April-ditched.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:36:19+00:00

Grant Shapes said he was 'sympathetic' to calls for more state aid with families staring at a 20 per cent increase in average bills.

## Mother, 32, died when she crashed her car into tree after night out drinking, inquest hears
 - [https://www.dailymail.co.uk/news/article-11802611/Mother-32-died-crashed-car-tree-night-drinking-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802611/Mother-32-died-crashed-car-tree-night-drinking-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:26:53+00:00

Young mother and army veteran Sarah Smith, 32, died after crashing her car drunk in Leyland after celebrating passing her exams to become a paramedic.

## Met Office warns snow flurry could hit country next week as temperatures tumble to near freezing
 - [https://www.dailymail.co.uk/news/article-11802493/Met-Office-warns-snow-flurry-hit-country-week-temperatures-tumble-near-freezing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802493/Met-Office-warns-snow-flurry-hit-country-week-temperatures-tumble-near-freezing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:19:56+00:00

'Disruptive' flurries could hit the nation over the coming week as a cold snap takes a hold of parts of Scotland and England.

## Driver 'cheats death' when his car is flattened by 18-tonne lorry in horror crash
 - [https://www.dailymail.co.uk/news/article-11802743/Driver-cheats-death-car-flattened-18-tonne-lorry-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802743/Driver-cheats-death-car-flattened-18-tonne-lorry-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:19:50+00:00

Stunned police said it was a 'miracle' the driver walked away with only minor injuries following the accident that took place on the M6 in the early hours of today.

## POWDERED beer is created by German firm - and it could slash the cost of a pint!
 - [https://www.dailymail.co.uk/news/article-11802427/POWDERED-beer-created-German-firm-slash-cost-pint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802427/POWDERED-beer-created-German-firm-slash-cost-pint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:19:34+00:00

Neuzeller Klosterbräu in eastern Germany, which has been brewing for nearly 500 years, said it will put the powder on sale this year.

## Video: Ukrainian tank blows up a house being used as cover by Putin's soldiers
 - [https://www.dailymail.co.uk/news/article-11802425/Video-Ukrainian-tank-blows-house-used-cover-Putins-soldiers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802425/Video-Ukrainian-tank-blows-house-used-cover-Putins-soldiers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:19:23+00:00

Two separate videos released by Ukrainian battalions show Kyiv's forces fighting back against advancing Russian troops in the Donbas, as Moscow pushes to encircle the city of Bakhmut.

## Moment Charles Bronson threatens teacher with spear after taking him hostage in prison in 1999
 - [https://www.dailymail.co.uk/news/article-11802271/Moment-Charles-Bronson-threatens-teacher-spear-taking-hostage-prison-1999.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802271/Moment-Charles-Bronson-threatens-teacher-spear-taking-hostage-prison-1999.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:19:20+00:00

Terrifying CCTV footage showing notorious lag Charles Bronson threatening a hostage with a homemade spear has been unearthed as part of a new Channel 4 documentary.

## Black lecturer who sued Bristol University for race discrimination loses tribunal claim
 - [https://www.dailymail.co.uk/news/article-11802537/Black-lecturer-sued-Bristol-University-race-discrimination-loses-tribunal-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802537/Black-lecturer-sued-Bristol-University-race-discrimination-loses-tribunal-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:16:10+00:00

Black university lecturer Dr Christabelle Peters sued Bristol uni for race discrimination because her nameplate on her door didn't have her 'Dr' title on it.

## Belarusian actor Aleh Sidorchyk out of Adelaide Fringe Festival over indecent assault charge
 - [https://www.dailymail.co.uk/news/article-11802499/Belarusian-actor-Aleh-Sidorchyk-Adelaide-Fringe-Festival-indecent-assault-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802499/Belarusian-actor-Aleh-Sidorchyk-Adelaide-Fringe-Festival-indecent-assault-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:15:14+00:00

An actor charged with committing an indecent act on another person during his flight to Australia has been axed from his Adelaide Fringe Festival show ahead of a court appearance.

## B&M will close MORE sites across Britain in coming weeks... so will your store be affected?
 - [https://www.dailymail.co.uk/news/article-11802613/B-M-close-sites-Britain-coming-weeks-store-affected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802613/B-M-close-sites-Britain-coming-weeks-store-affected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:09:36+00:00

B&amp;M sites in Newport, Stockton, Kilmarnock and Bristol are to be affected, according to the Mirror.

## Neighbours living next to creamery which produces Cathedral City say fumes are making them suicidal
 - [https://www.dailymail.co.uk/news/article-11802347/Neighbours-living-creamery-produces-Cathedral-City-say-fumes-making-suicidal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802347/Neighbours-living-creamery-produces-Cathedral-City-say-fumes-making-suicidal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 13:06:23+00:00

Residents living near the world's largest cheddar factory say cheese really does give you nightmares claiming its fumes and pollution make them depressed, sleepless - and even suicidal.

## Thomas Matthews pleads guilty to running down three police officers in a car in Canberra
 - [https://www.dailymail.co.uk/news/article-11802067/Thomas-Matthews-pleads-guilty-running-three-police-officers-car-Canberra.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802067/Thomas-Matthews-pleads-guilty-running-three-police-officers-car-Canberra.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:50:30+00:00

The man, Thomas Matthews, hit Detective leading senior constable Alun Mills and constables Melanie Miller and Alyce Mueck outside the National Arboretum, in Canberra's west, on July 11 2021.

## Jamie Muir's replies to his own police wanted post on Facebook
 - [https://www.dailymail.co.uk/news/article-11801393/Jamie-Muirs-replies-police-wanted-post-Facebook.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801393/Jamie-Muirs-replies-police-wanted-post-Facebook.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:40:14+00:00

Jamie Muir, 30, has three outstanding warrants for domestic violence and traffic charges in the Nepean area in   Sydney's west.

## Women going through the menopause could be get more rights at work
 - [https://www.dailymail.co.uk/news/article-11802531/Women-going-menopause-rights-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802531/Women-going-menopause-rights-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:34:44+00:00

Women going through the menopause could be given the right to work from home or receive paid time off to attend doctors' appointments under a Labour government.

## Mother-of-six faces losing her toes from deadly sepsis after doctors told her to 'go back to bed'
 - [https://www.dailymail.co.uk/news/article-11802557/Mother-six-faces-losing-toes-deadly-sepsis-doctors-told-bed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802557/Mother-six-faces-losing-toes-deadly-sepsis-doctors-told-bed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:33:40+00:00

Michelle Griffiths, 28, has been diagnosed with pneumonia and sepsis. The mother, of Llanllyfni, North Wales, will now have to have her toes and her thumb amputated.

## Police launch urgent appeal to find convicted female thief, 44, who is wanted on recall to prison
 - [https://www.dailymail.co.uk/news/article-11802593/Police-launch-urgent-appeal-convicted-female-thief-44-wanted-recall-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802593/Police-launch-urgent-appeal-convicted-female-thief-44-wanted-recall-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:28:29+00:00

Anita McGarry was released from jail in January. The 44-year-old had previously been jailed for theft, Greater Manchester Police (GMP) said.

## Biden's $400 BILLION student loan relief plan set for Supreme Court showdown
 - [https://www.dailymail.co.uk/news/article-11799915/Bidens-400-BILLION-student-loan-relief-plan-set-Supreme-Court-showdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11799915/Bidens-400-BILLION-student-loan-relief-plan-set-Supreme-Court-showdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:26:59+00:00

The final step in President Joe Biden's efforts to forgive $10,000 in student loans for most borrowers will hang in the balance as the Supreme Court hears arguments in the case on Tuesday.

## Shoppers race to buy Easter eggs at Morrisons as prices drop to £1.99
 - [https://www.dailymail.co.uk/news/article-11802561/Shoppers-race-buy-Easter-eggs-Morrisons-prices-drop-1-99.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802561/Shoppers-race-buy-Easter-eggs-Morrisons-prices-drop-1-99.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:21:43+00:00

Shoppers have stampeded to Morrisons to take advantage of a cracking new Easter deal that has seen the supermarket giant slash the price of brand eggs to £1.99.

## Family of make-up artist killed in Qatar crash urge Foreign Office to press for information on death
 - [https://www.dailymail.co.uk/news/article-11801967/Family-make-artist-killed-Qatar-crash-urge-Foreign-Office-press-information-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801967/Family-make-artist-killed-Qatar-crash-urge-Foreign-Office-press-information-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:21:36+00:00

Raffy Tsakanika, 21, from Cambridge, died after the car she was travelling in as a passenger was struck from behind by a second vehicle near Doha in March 2019.

## Amateur boxer was killed when his friend crashed a van he was driving 'well above' 30mph limit
 - [https://www.dailymail.co.uk/news/article-11802441/Amateur-boxer-killed-friend-crashed-van-driving-30mph-limit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802441/Amateur-boxer-killed-friend-crashed-van-driving-30mph-limit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:16:39+00:00

Shane Thomas (pictured), 22, died in a fatal collision when a van, allegedly driven by Jason Evans, collided with two parked cars before smacking into a stone wall.

## Amy Nuttall's love life: How actor Ben Freeman split with her in 2005 over cheating rumours
 - [https://www.dailymail.co.uk/news/article-11802115/Amy-Nuttalls-love-life-actor-Ben-Freeman-split-2005-cheating-rumours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802115/Amy-Nuttalls-love-life-actor-Ben-Freeman-split-2005-cheating-rumours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:13:52+00:00

Today's news may cast minds back to an earlier incident in 2005, which saw the British actress infamously cheated on by her Emmerdale castmate Ben Freeman in 2005.

## How to see the Northern Lights TONIGHT as the auroras continue to dazzle stargazers across the UK
 - [https://www.dailymail.co.uk/sciencetech/article-11802177/How-Northern-Lights-TONIGHT-auroras-continue-dazzle-stargazers-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-11802177/How-Northern-Lights-TONIGHT-auroras-continue-dazzle-stargazers-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:10:16+00:00

The Northern Lights are the result of an eruption of charged particles from the sun, called a coronal mass ejection, interacting with the Earth's atmosphere.

## Italian restaurant boss fears his firm will go under in weeks amid soaring food prices
 - [https://www.dailymail.co.uk/news/article-11802209/Italian-restaurant-boss-fears-firm-weeks-amid-soaring-food-prices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802209/Italian-restaurant-boss-fears-firm-weeks-amid-soaring-food-prices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:09:29+00:00

Carmine Monturi, 52, moved to Bristol from Italy nine years ago - and runs an independent Italian restaurant. But now he fears his firm will close in a matter of weeks amid soaring food costs.

## British woman cheats death when dolphin attacks her in Bolivian river
 - [https://www.dailymail.co.uk/news/article-11802057/British-woman-cheats-death-dolphin-attacks-Bolivian-river.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802057/British-woman-cheats-death-dolphin-attacks-Bolivian-river.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 12:00:01+00:00

Claire Bye, 28, survived two life-threatening infections and required 32 stitches after she was bitten by the pink river dolphin while swimming in a river in Santa Rosa de Yacuma.

## Balding Andrew Tate and his brother 'demanded a HAIRSTYLIST and a PlayStation while held in custody'
 - [https://www.dailymail.co.uk/news/article-11802135/Balding-Andrew-Tate-brother-demanded-HAIRSTYLIST-PlayStation-held-custody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802135/Balding-Andrew-Tate-brother-demanded-HAIRSTYLIST-PlayStation-held-custody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 11:43:55+00:00

A balding Andrew Tate and his brother Tristan allegedly demanded that a hairstylist visit them in jail and for a PlayStation to be placed in their prison cell.

## Female lout who attacked her neighbours with a bag containing vodka bottle is fined just £40
 - [https://www.dailymail.co.uk/news/article-11802119/Female-lout-attacked-neighbours-bag-containing-vodka-bottle-fined-just-40.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802119/Female-lout-attacked-neighbours-bag-containing-vodka-bottle-fined-just-40.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 11:43:52+00:00

Claudia Carrington saw two charges of assault against her dropped this week after she swung a bag containing the bottle at Jean Clewes, 61, and Alison Edge, 51, whilst they were gardening.

## The 54 day hunt for runaway couple Constance Marten and Mark Gordon
 - [https://www.dailymail.co.uk/news/article-11801845/The-54-day-hunt-runaway-couple-Constance-Marten-Mark-Gordon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801845/The-54-day-hunt-runaway-couple-Constance-Marten-Mark-Gordon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 11:15:07+00:00

An aristocrat and her partner are this morning in custody after 54 days on the run with their newborn baby.

## Trans double rapist Isla Bryson has been jailed for 8 years for attacking two women while a man
 - [https://www.dailymail.co.uk/news/article-11802161/Trans-double-rapist-Isla-Bryson-jailed-8-years-attacking-two-women-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802161/Trans-double-rapist-Isla-Bryson-jailed-8-years-attacking-two-women-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 11:14:36+00:00

Transgender rapist Isla Bryson has been jailed for eight years at the High Court in Edinburgh after being found guilty of raping two women while still a man.

## Ukraine WILL become a NATO member in the 'long-term', head of the alliance says
 - [https://www.dailymail.co.uk/news/article-11802207/Ukraine-NATO-member-long-term-head-alliance-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802207/Ukraine-NATO-member-long-term-head-alliance-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 11:08:50+00:00

Vladimir Putin has cited the eastern expansion of NATO's borders as a reason behind his assault on the country. This has been dismissed by Kyiv and is allies.

## Sperm donors should be identified as soon as baby is born with 'children not having to wait'
 - [https://www.dailymail.co.uk/news/article-11801857/Sperm-donors-identified-soon-baby-born-children-not-having-wait.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801857/Sperm-donors-identified-soon-baby-born-children-not-having-wait.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 11:05:19+00:00

Sperm and egg donors could soon be identified as soon as the child is born, if proposed changes to the law suggested by a watchdog are approved. Currently children must wait until they are 18.

## Dozens of UK pupils stuck in New York after hotel shreds passports
 - [https://www.dailymail.co.uk/news/article-11802047/Dozens-UK-pupils-stuck-New-York-hotel-shreds-passports.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802047/Dozens-UK-pupils-stuck-New-York-hotel-shreds-passports.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 11:03:23+00:00

Forty-two teenagers from Barr Beacon School in Walsall, near Birmingham, had been on a skiing trip to the States and were due to fly home on Saturday. They're now stuck in New York city.

## Princess Diana's dance partner Wayne Sleep reveals she would do his dirty dishes to 'take a break'
 - [https://www.dailymail.co.uk/femail/article-11801793/Princess-Dianas-dance-partner-Wayne-Sleep-reveals-dirty-dishes-break.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11801793/Princess-Dianas-dance-partner-Wayne-Sleep-reveals-dirty-dishes-break.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 11:03:18+00:00

The choreographer, 74, who is originally from Plymouth, appeared on BBC Radio 3's Private Passions where he spoke about his friendship with the mother-of-two.

## Travis Perkins reveals it axed 400 jobs and shut 19 branches last year in bid to slash £25m costs
 - [https://www.dailymail.co.uk/news/article-11802193/Travis-Perkins-reveals-axed-400-jobs-shut-19-branches-year-bid-slash-25m-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802193/Travis-Perkins-reveals-axed-400-jobs-shut-19-branches-year-bid-slash-25m-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:57:21+00:00

Builders' merchant Travis Perkins has revealed it axed 400 jobs and shut 19 branches at the end of last year as a slowdown in the construction sector hit its bottom line.

## Pokey pad which costs £1,150-a-month is so small the bed is on a DIY wooden shelf
 - [https://www.dailymail.co.uk/news/article-11802105/Pokey-pad-costs-1-150-month-small-bed-DIY-wooden-shelf.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802105/Pokey-pad-costs-1-150-month-small-bed-DIY-wooden-shelf.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:56:34+00:00

Described as 'cozy' by sellers, this one-bed flat in Hendon, north London, offers a space-saving sleeping area accessed only by climbing up a very steep step ladder.

## Bird flu: Ex-SAGE adviser calls on UK to start stockpiling antiviral drugs and PPE
 - [https://www.dailymail.co.uk/health/article-11799345/Bird-flu-Ex-SAGE-adviser-calls-UK-start-stockpiling-antiviral-drugs-PPE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11799345/Bird-flu-Ex-SAGE-adviser-calls-UK-start-stockpiling-antiviral-drugs-PPE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:49:15+00:00

EXCLUSIVE: Professor Peter Openshaw, an immunologist who sat on two SAGE committees, has urged ministers to boost supplies of virus-fighting drugs and PPE in case of an outbreak.

## Joe Biden praises new Northern Ireland Brexit deal
 - [https://www.dailymail.co.uk/news/article-11802149/Joe-Biden-praises-new-Northern-Ireland-Brexit-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802149/Joe-Biden-praises-new-Northern-Ireland-Brexit-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:30:12+00:00

US President Joe Biden welcomed the new terms for Northern Ireland, after the situation caused tensions in the Special Relationship for years.

## Fears Russia is planning false flag chemical weapons attack in Ukraine that it will blame on West
 - [https://www.dailymail.co.uk/news/article-11801889/Fears-Russia-planning-false-flag-chemical-weapons-attack-Ukraine-blame-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801889/Fears-Russia-planning-false-flag-chemical-weapons-attack-Ukraine-blame-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:16:56+00:00

Russian media went into overdrive today, claiming the US and its allies are plotting a chemical strike. Yet the frenzy has the hallmarks of a Russian operation to blame the West for its own attack.

## Tears from 'Brexit hard man' Steve Baker
as he hails PM's Northern Ireland deal
 - [https://www.dailymail.co.uk/news/article-11802117/Tears-Brexit-hard-man-Steve-Baker-hails-PMs-Northern-Ireland-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802117/Tears-Brexit-hard-man-Steve-Baker-hails-PMs-Northern-Ireland-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:16:53+00:00

Steve Baker, who is now a Northern Ireland Minister, suggested that the Windsor Framework was statecraft on a par with the 1998 Good Friday Agreement that ended the Troubles.

## Photographer Richard Sandler exhibition shows contrasted lives in New York, 1977-2001
 - [https://www.dailymail.co.uk/news/article-11802121/Photographer-Richard-Sandler-exhibition-shows-contrasted-lives-New-York-1977-2001.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11802121/Photographer-Richard-Sandler-exhibition-shows-contrasted-lives-New-York-1977-2001.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:14:00+00:00

Richard Sandler discovered a passion for photography after learning to develop photos in 1977. For 24 years, he worked as a street photographer, capturing the reality of life in New York City

## Storm Juliette: Mallorca is hit by TWENTY INCHES of snow and 25ft waves
 - [https://www.dailymail.co.uk/news/article-11801861/Storm-Juliette-Mallorca-hit-TWENTY-INCHES-snow-25ft-waves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801861/Storm-Juliette-Mallorca-hit-TWENTY-INCHES-snow-25ft-waves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:12:29+00:00

Mallorca has been gripped by a winter storm that is wreaking havoc on the Spanish holiday island, with 20 inches of snow shutting down roads and cutting off power.

## 'Hogwarts Legacy' becomes one of the fastest-selling video games ever making $850M in two weeks
 - [https://www.dailymail.co.uk/news/article-11801873/Hogwarts-Legacy-one-fastest-selling-video-games-making-850M-two-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801873/Hogwarts-Legacy-one-fastest-selling-video-games-making-850M-two-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:07:44+00:00

The video game racked up $850 million in revenue with 12 million sales, according to figures released by Warner Bros. Games. This makes the game one of the fastest selling games of all time.

## Warning over TV shows like The Gold and You for glorifying male killers
 - [https://www.dailymail.co.uk/news/article-11801851/Warning-TV-shows-like-Gold-glorifying-male-killers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801851/Warning-TV-shows-like-Gold-glorifying-male-killers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:07:04+00:00

Audrey Gillan, who created a podcast exploring the three victims of the Scottish serial killer Bible John, said too much focus was placed on male perpetrators.

## Christian lawyer who called down biblical curses on rival barrister is struck off
 - [https://www.dailymail.co.uk/news/article-11801885/Christian-lawyer-called-biblical-curses-rival-barrister-struck-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801885/Christian-lawyer-called-biblical-curses-rival-barrister-struck-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 10:02:25+00:00

Solicitor Alvin Just (pictured), 51,  sent 'inappropriate and unprofessional' emails to barrister Philip Noble after clashing during a will dispute at Central London County Court in 2017.

## Maggot-infested food from Snowy 2.0 mega-project sparks worker fury
 - [https://www.dailymail.co.uk/news/article-11801105/Maggot-infested-food-Snowy-2-0-mega-project-sparks-worker-fury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801105/Maggot-infested-food-Snowy-2-0-mega-project-sparks-worker-fury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 09:59:40+00:00

Laborer's working on Australia's largest 
renewable energy project, Snowy 2.0, south of Canberra, are now
considering strike action at the $2billion project.

## Waleed Aly left stunned by Reuben Kaye joke about Jesus on The Project
 - [https://www.dailymail.co.uk/news/article-11801859/Waleed-Aly-left-stunned-Reuben-Kaye-joke-Jesus-Project.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801859/Waleed-Aly-left-stunned-Reuben-Kaye-joke-Jesus-Project.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 09:22:15+00:00

Queer comedian and Reuben Kaye has left The Project panel stunned after an x-rated joke about Jesus on air.

## Constance Martine live: Hunt for baby as Mark Gordon and aristocrat arrested
 - [https://www.dailymail.co.uk/news/live/article-11801703/Constance-Martine-live-Hunt-baby-Mark-Gordon-aristocrat-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11801703/Constance-Martine-live-Hunt-baby-Mark-Gordon-aristocrat-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 09:20:02+00:00

MAILONLINE LIVEBLOG: Get all the latest updates on the urgent search for the missing newborn baby of Constance Marten and Mark Gordon in Brighton on February 28, 2023.

## Luke Lembryk murder trial hears how cocaine Tinder party led to stabbing
 - [https://www.dailymail.co.uk/news/article-11801779/Luke-Lembryk-murder-trial-hears-cocaine-Tinder-party-led-stabbing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801779/Luke-Lembryk-murder-trial-hears-cocaine-Tinder-party-led-stabbing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 09:16:47+00:00

Three men and two women are facing trial, accused of playing roles in the alleged murder of Luke Lembryk, with the court hearing the fatal incident began at a cocaine-fuelled Tinder party.

## Mobile phone that folds into 'gun' seized by police in drug raid in Baldivis, WA
 - [https://www.dailymail.co.uk/news/article-11801521/Mobile-phone-folds-gun-seized-police-drug-raid-Baldivis-WA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801521/Mobile-phone-folds-gun-seized-police-drug-raid-Baldivis-WA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 09:14:56+00:00

WA police have seized a device that looks like a mobile phone but which folds out to become a gun as well as quantities of illegal drugs and other weapons with ammunition in raids south of Perth.

## Brexit deal: Expert says monarch would only meet foreign leaders if told by No10
 - [https://www.dailymail.co.uk/news/article-11801651/Brexit-deal-Expert-says-monarch-meet-foreign-leaders-told-No10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801651/Brexit-deal-Expert-says-monarch-meet-foreign-leaders-told-No10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 08:43:33+00:00

The row over who dragged King Charles into Brexit politics wades on as an expert claimed he monarch would only have an audience with foreign leaders if told by No 10

## Putin is 'definitely not up to' deciding if he will run for president next year, spokesman says
 - [https://www.dailymail.co.uk/news/article-11801681/Putin-definitely-not-deciding-run-president-year-spokesman-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801681/Putin-definitely-not-deciding-run-president-year-spokesman-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 08:27:18+00:00

The Kremlin leader has been dogged by rumours of ill health, including cancer, and is embroiled in a brutal war he unleashed in Ukraine which is not going according to plan.

## Three teens rushed to hospital after stabbing in east London 'following mass brawl inside takeaway'
 - [https://www.dailymail.co.uk/news/article-11801699/Three-teens-rushed-hospital-stabbing-east-London-following-mass-brawl-inside-takeaway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801699/Three-teens-rushed-hospital-stabbing-east-London-following-mass-brawl-inside-takeaway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 08:25:41+00:00

Three teenagers aged 15, 16 and 17 were found with stab wounds, not thought to be life threatening, in Romford, east London.

## TGA recalls 55 cough medicine products: Including Benadryl, Bisolvin and Codral
 - [https://www.dailymail.co.uk/news/article-11801639/TGA-recalls-55-cough-medicine-products-Including-Benadryl-Bisolvin-Codral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801639/TGA-recalls-55-cough-medicine-products-Including-Benadryl-Bisolvin-Codral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 08:17:40+00:00

A national recall has been issued on dozens of cough medicines by the Therapeutic Goods Administration (TGA) due to the potentially deadly ingredient pholcodine.

## Beard transplant clinic says it's seen a 100% spike in demand and they think Prince Harry is why!
 - [https://www.dailymail.co.uk/health/article-11797951/Beard-transplant-clinic-says-seen-100-spike-demand-think-Prince-Harry-why.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11797951/Beard-transplant-clinic-says-seen-100-spike-demand-think-Prince-Harry-why.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 08:13:20+00:00

EXCLUSIVE: British men are  travelling to a hair clinic in Turkey and paying £2,500 for a beard transplant emulating Prince Harry's facial hair in a trend linked to his memoir Spare.

## Rishi Sunak steps up sales pitch after dramatic NI breakthrough
 - [https://www.dailymail.co.uk/news/article-11801719/Rishi-Sunak-steps-sales-pitch-dramatic-NI-breakthrough.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801719/Rishi-Sunak-steps-sales-pitch-dramatic-NI-breakthrough.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 08:10:31+00:00

Rishi Sunak is visiting Northern Ireland before returning to address Tory MPs this evening, after his 'Windsor Framework' was given a cautious welcome.

## Russia Ukraine war: Kyiv admits situation is 'extremely tense' as Putin steps up assault on Bakhmut
 - [https://www.dailymail.co.uk/news/article-11801549/Russia-Ukraine-war-Kyiv-admits-situation-extremely-tense-Putin-steps-assault-Bakhmut.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801549/Russia-Ukraine-war-Kyiv-admits-situation-extremely-tense-Putin-steps-assault-Bakhmut.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:46:03+00:00

Russia is trying to cut the Ukrainian defenders' supply lines to the city of Bakhmut, the scene of some of the war's toughest fighting, and force them to surrender or withdraw.

## San Francisco's reparations committee reveal how it calculated $5M payout
 - [https://www.dailymail.co.uk/news/article-11801303/San-Franciscos-reparations-committee-reveal-calculated-5M-payout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801303/San-Franciscos-reparations-committee-reveal-calculated-5M-payout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:27:52+00:00

Black San Francisco residents could see up to $5million each in reparations as the city admits there's no 'mathematical formula' for the number.

## Queen Elizabeth's ex-head groom will be installed as a 'military knight' at Windsor Castle today
 - [https://www.dailymail.co.uk/news/article-11801507/Queen-Elizabeths-ex-head-groom-installed-military-knight-Windsor-Castle-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801507/Queen-Elizabeths-ex-head-groom-installed-military-knight-Windsor-Castle-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:16:43+00:00

Terry Pendry, 72, could always be seen by the late monarch's side as she rode through the estate, the pair whiling away hours on end chatting about their favourite subject - horses.

## Missouri church foils armed robbery when former police officer pastor, congregation pray for gunmen
 - [https://www.dailymail.co.uk/news/article-11801357/Missouri-church-foils-armed-robbery-former-police-officer-pastor-congregation-pray-gunmen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801357/Missouri-church-foils-armed-robbery-former-police-officer-pastor-congregation-pray-gunmen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:12:53+00:00

During Sunday service former St Louis cop turned pastor Marquaello Futrell noticed four masked men with guns in their waistbands enter the church in Ferguson, Missouri.

## Striking teachers launch first of three days of walkouts TODAY - will your child's school be closed?
 - [https://www.dailymail.co.uk/news/article-11801463/Striking-teachers-launch-three-days-walkouts-TODAY-childs-school-closed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801463/Striking-teachers-launch-three-days-walkouts-TODAY-childs-school-closed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:08:20+00:00

Teachers will walk out across the north of England on Tuesday with the majority of schools expected to either restrict access or fully close, the National Education Union (NEU) has said.

## Cyclone Gabrielle, New Zealand: Napier man Peter Lafferty digs for daughter's grave
 - [https://www.dailymail.co.uk/news/article-11774467/Cyclone-Gabrielle-New-Zealand-Napier-man-Peter-Lafferty-digs-daughters-grave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11774467/Cyclone-Gabrielle-New-Zealand-Napier-man-Peter-Lafferty-digs-daughters-grave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:03:19+00:00

Sarah Lafferty was buried at a small, privately-owned cemetery on the banks of the Mangaone River at Rissington, near Napier, in the Hawke's Bay region.

## NYC Christopher Columbus statue at entrance to Central Park is hit by vandals
 - [https://www.dailymail.co.uk/news/article-11801391/NYC-Christopher-Columbus-statue-entrance-Central-Park-hit-vandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801391/NYC-Christopher-Columbus-statue-entrance-Central-Park-hit-vandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:02:05+00:00

Police are on the hunt for two people who vandalized the Central Park statue with spray paint on Sunday around 11:30pm. Investigators believe the suspects are a man and a woman.

## Trans double rapist Isla Bryson who was initially sent to all-female prison will be sentenced today
 - [https://www.dailymail.co.uk/news/article-11801401/Trans-double-rapist-Isla-Bryson-initially-sent-female-prison-sentenced-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801401/Trans-double-rapist-Isla-Bryson-initially-sent-female-prison-sentenced-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:01:56+00:00

Isla Bryson, 31, was convicted of raping two women: one in Clydebank in 2016; and one in Drumchapel, Glasgow, in 2019; committing the offences while still a man known as Adam Graham.

## 'ASX Wolf' Tyson Scholz sells luxury Gold Coast mansion for $4.61million
 - [https://www.dailymail.co.uk/news/article-11801207/ASX-Wolf-Tyson-Scholz-sells-luxury-Gold-Coast-mansion-4-61million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801207/ASX-Wolf-Tyson-Scholz-sells-luxury-Gold-Coast-mansion-4-61million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:01:55+00:00

Queensland influencer Tyson Scholz's Hamptons-style home sold for $4.61million - making Scholz a profit of $310,000 since its purchase 11 months ago.

## Canberra grandmother accused of child abuse against granddaughter and posting on TikTok
 - [https://www.dailymail.co.uk/news/article-11801413/Canberra-grandmother-accused-child-abuse-against-granddaughter-posting-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801413/Canberra-grandmother-accused-child-abuse-against-granddaughter-posting-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 07:01:55+00:00

A grandmother, 50, who has been charged with sexually abusing her young granddaughter and posting the abuse material on TikTok has appeared in a Canberra court.

## Anthony Albanese is accused of breaking 11 word election promise on superannuation
 - [https://www.dailymail.co.uk/news/article-11801197/Anthony-Albanese-accused-breaking-11-word-election-promise-superannuation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801197/Anthony-Albanese-accused-breaking-11-word-election-promise-superannuation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 06:51:24+00:00

Anthony Albanese has been accused of breaking an election promise after declaring tax rates would be doubled for Australians with more than $3million in superannuation.

## Jump Start cartoonist turns on former friend Scott Adams after racist rant from Dilbert creator
 - [https://www.dailymail.co.uk/news/article-11801165/Jump-Start-cartoonist-turns-former-friend-Scott-Adams-racist-rant-Dilbert-creator.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801165/Jump-Start-cartoonist-turns-former-friend-Scott-Adams-racist-rant-Dilbert-creator.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 06:49:15+00:00

Robb Armstrong, creator of the cartoon Jump Start, has disavowed his former friend Dilbert cartoonist Scott Adams and is leading the 'black sharpie revolt' against him.

## Squadron of fighter jets fly across Melbourne and Sydney skies ahead of Avalon Airport show
 - [https://www.dailymail.co.uk/news/article-11801045/Squadron-fighter-jets-fly-Melbourne-Sydney-skies-ahead-Avalon-Airport-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801045/Squadron-fighter-jets-fly-Melbourne-Sydney-skies-ahead-Avalon-Airport-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 06:43:41+00:00

State-of-the-art F-35A Lighting II aircraft, made by Lockheed Martin, roared over Melbourne in recent days, rattling windows and causing locals to look towards the skies.

## Driver asks who was in the right after being abused over an infuriating parking problem
 - [https://www.dailymail.co.uk/news/article-11800869/Driver-asks-right-abused-infuriating-parking-problem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800869/Driver-asks-right-abused-infuriating-parking-problem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 06:43:01+00:00

It's one of the most intense situations drivers go through: being confronted by another motorist who believes you took 'their' car space. So who is right in this case?

## Cairns police officer allegedly attacked in the middle of press conference about city crime
 - [https://www.dailymail.co.uk/news/article-11801199/Cairns-police-officer-allegedly-attacked-middle-press-conference-city-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801199/Cairns-police-officer-allegedly-attacked-middle-press-conference-city-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 06:17:06+00:00

Senior Sergeant Gary Hunter was addressing media in the far north Queensland city's CBD on Monday morning when shouts broke out off camera.

## Banksmeadow cooling tower fire: Evacuation order over plastic plant fears near Sydney Airport
 - [https://www.dailymail.co.uk/news/article-11801353/Banksmeadow-cooling-tower-fire-Evacuation-order-plastic-plant-fears-near-Sydney-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801353/Banksmeadow-cooling-tower-fire-Evacuation-order-plastic-plant-fears-near-Sydney-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 06:11:46+00:00

A massive evacuation zone has been set up near Sydney Airport after a cooling tower at a plastic factory caught fire, sparking fears it could fall onto hydrogen tanks.

## Motorist films a car being driven on its rims in Coomera on the Gold Coast after tyres exploded
 - [https://www.dailymail.co.uk/news/article-11801119/Motorist-films-car-driven-rims-Coomera-Gold-Coast-tyres-exploded.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801119/Motorist-films-car-driven-rims-Coomera-Gold-Coast-tyres-exploded.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 06:11:24+00:00

The lopsided car with two busted tyres was filmed from a vehicle behind as it rolled along on its rims down a major road in Coomera on the Gold Coast last weekend.

## Ex-Australian soldier who served in Afghanistan dies suddenly in Thailand
 - [https://www.dailymail.co.uk/news/article-11801005/Ex-Australian-soldier-served-Afghanistan-dies-suddenly-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801005/Ex-Australian-soldier-served-Afghanistan-dies-suddenly-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 05:49:24+00:00

Justin Christopher House passed away on February 2 in Bangkok, where he was living, after service in Afghanistan.

## Australian Montesalvo family from Melbourne try to get missing daughter back after move to Italy
 - [https://www.dailymail.co.uk/news/article-11800963/Australian-Montesalvo-family-Melbourne-try-missing-daughter-Italy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800963/Australian-Montesalvo-family-Melbourne-try-missing-daughter-Italy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 05:47:41+00:00

Courtney Montesalvo, who suffers from bipolar disorder and was previously diagnosed with postnatal psychosis, stunned her family when she left Australia in 2014 with her Italian husband.

## Failure of the Voice to Parliament 'unthinkable' says Liberal frontbencher
 - [https://www.dailymail.co.uk/news/article-11801235/Failure-Voice-Parliament-unthinkable-says-Liberal-frontbencher.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801235/Failure-Voice-Parliament-unthinkable-says-Liberal-frontbencher.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 05:43:00+00:00

A senior Liberal MP says there is scope for co-operation with Labor on a constitutionally enshrined Indigenous Voice, but the focus must be on outcomes.

## Drunk passenger on Air Canada flight is arrested at Sydney Airport after drinking his own alcohol
 - [https://www.dailymail.co.uk/news/article-11801189/Drunk-passenger-Air-Canada-flight-arrested-Sydney-Airport-drinking-alcohol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801189/Drunk-passenger-Air-Canada-flight-arrested-Sydney-Airport-drinking-alcohol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 05:41:54+00:00

Australian Federal Police officers who met Hardik Patel at Sydney Airport after he had flown in from Canada observed he had a 'flushed face and a strong odor of alcohol coming from his person'.

## Reservoir High School, Melbourne student allegedly stabs classmate as police arrest boy
 - [https://www.dailymail.co.uk/news/article-11801075/Reservoir-High-School-Melbourne-student-allegedly-stabs-classmate-police-arrest-boy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801075/Reservoir-High-School-Melbourne-student-allegedly-stabs-classmate-police-arrest-boy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 05:40:14+00:00

Victorian Police officers responded to reports of a stabbing at Reservoir High School in Reservoir, Melbourne's north, at 10.50am on Tuesday.

## Woke Syracuse University student reignites calls for the Kansas City Chiefs to change its name
 - [https://www.dailymail.co.uk/news/article-11801083/Woke-Syracuse-University-student-reignites-calls-Kansas-City-Chiefs-change-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801083/Woke-Syracuse-University-student-reignites-calls-Kansas-City-Chiefs-change-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 05:36:54+00:00

Student Grace 'Gray' Reed, who goes by the pronouns they and them, highlighted in the Syracuse University school's new paper that the Kansas City Chiefs' name is 'racist.'

## Wendy's war: Aussie milk bar takes on US burger chain amid expansion plan to open hundreds of stores
 - [https://www.dailymail.co.uk/news/article-11801017/Wendys-war-Aussie-milk-bar-takes-burger-chain-amid-expansion-plan-open-hundreds-stores.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801017/Wendys-war-Aussie-milk-bar-takes-burger-chain-amid-expansion-plan-open-hundreds-stores.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 05:21:33+00:00

The war of the Wendy's has started, pitting a plucky little Aussie chain with 120 outlets against an American giant with more than 7,000 stores around the world.

## NFL Zac Stacy jailed over attacks on ex girlfriend video throwing her around like a rag doll STAGED
 - [https://www.dailymail.co.uk/news/article-11801139/NFL-Zac-Stacy-jailed-attacks-ex-girlfriend-video-throwing-like-rag-doll-STAGED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801139/NFL-Zac-Stacy-jailed-attacks-ex-girlfriend-video-throwing-like-rag-doll-STAGED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:55:39+00:00

NFL star Zac Stacy has been sentenced to six months in jail and one year of probation for attacking his ex-girlfriend on two separate occasions in 2021.

## Sydney man finds red belly black snake inside his shoe prompting a warning from snake handlers
 - [https://www.dailymail.co.uk/news/article-11800901/Sydney-man-finds-red-belly-black-snake-inside-shoe-prompting-warning-snake-handlers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800901/Sydney-man-finds-red-belly-black-snake-inside-shoe-prompting-warning-snake-handlers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:54:29+00:00

Snake handlers have warned Aussies about storing clothing in safe places after a man discovered a red belly black snake in his shoe.

## Incredible Southern Lights display dazzles the night sky in Australia
 - [https://www.dailymail.co.uk/news/article-11800935/Incredible-Southern-Lights-display-dazzles-night-sky-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800935/Incredible-Southern-Lights-display-dazzles-night-sky-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:53:51+00:00

The Aurora Australis, Southern Lights, were spotted halfway up NSW on Monday night is an extremely rare event.

## Google worker, 33, found dead in New York City apartment
 - [https://www.dailymail.co.uk/news/article-11801051/Google-worker-33-dead-New-York-City-apartment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801051/Google-worker-33-dead-New-York-City-apartment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:49:20+00:00

Jacob Pratt, 33, was found dead inside his Chelsea apartment on February 16 and appeared to have hung himself, an NYPD source said.

## Dr Nick Coatsworth calls out China after report concludes virus likely leaked from lab
 - [https://www.dailymail.co.uk/news/article-11800259/Dr-Nick-Coatsworth-calls-China-report-concludes-virus-likely-leaked-lab.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800259/Dr-Nick-Coatsworth-calls-China-report-concludes-virus-likely-leaked-lab.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:39:35+00:00

The former deputy chief medical officer called on Beijing help to identify the source of the outbreak so the world could be better prepared for future pandemics.

## Brisbane man blasts Newstead apartment owner for throwing dog poo off balcony as council steps in
 - [https://www.dailymail.co.uk/news/article-11800839/Brisbane-man-blasts-Newstead-apartment-owner-throwing-dog-poo-balcony-council-steps-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800839/Brisbane-man-blasts-Newstead-apartment-owner-throwing-dog-poo-balcony-council-steps-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:32:51+00:00

One resident of the Unison complex on Longland St, in the Brisbane suburb of Newstead was so incensed by the foul practice, he warned the thrower he would be getting them soon.

## The Iconic Australia to sack dozens of workers
 - [https://www.dailymail.co.uk/news/article-11800887/The-Iconic-Australia-sack-dozens-workers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800887/The-Iconic-Australia-sack-dozens-workers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:28:03+00:00

The Iconic's Sydney staff were called into an in-person meeting with management advising them 69 roles would be affected by the company's restructure.

## China warned 'be honest' about coronavirus origins after US found possible Wuhan lab leak
 - [https://www.dailymail.co.uk/news/article-11801001/China-warned-honest-coronavirus-origins-possible-Wuhan-lab-leak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11801001/China-warned-honest-coronavirus-origins-possible-Wuhan-lab-leak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:25:35+00:00

The US ambassador to China, Nicholas Burns, called on Beijing to be more transparent over the origins of the virus. China's foreign ministry had earlier lashed out at the 'smear' campaign.

## Bizarre moment white 'Karen' berates two black men for shoveling snow for free outside her house
 - [https://www.dailymail.co.uk/news/article-11800797/Bizarre-moment-white-Karen-berates-two-black-men-shoveling-snow-free-outside-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800797/Bizarre-moment-white-Karen-berates-two-black-men-shoveling-snow-free-outside-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:18:06+00:00

A TikTok video is going viral of a white woman calling the police on two young black men for shoveling snow.

## Australia's highest rental yield: Fibro house for rent in Katanning returns 15 per cent rent yield
 - [https://www.dailymail.co.uk/news/article-11800285/Australias-highest-rental-yield-Fibro-house-rent-Katanning-returns-15-cent-rent-yield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800285/Australias-highest-rental-yield-Fibro-house-rent-Katanning-returns-15-cent-rent-yield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:17:23+00:00

A small fibro home in a regional WA working town could have the highest rental yield in Australia after weekly rent costs skyrocketed by 47 per cent.

## Hot car: Harrowing moment female cop cradles baby after rescuing her from Roselands Shopping Centre
 - [https://www.dailymail.co.uk/news/article-11800667/roselands-shopping-centre-hot-car-baby-girl-dee-why.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800667/roselands-shopping-centre-hot-car-baby-girl-dee-why.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:16:39+00:00

Police have smashed open the window of a hot car to rescue a three-month-old baby girl at a shopping centre in Sydney's south-west, after a mum accidentally locked her keys in the car.

## NSW Premier Dominic Perrottet unveils election plan to ditch stamp duty for cheaper land tax
 - [https://www.dailymail.co.uk/news/article-11794089/NSW-Premier-Dominic-Perrottet-unveils-election-plan-ditch-stamp-duty-cheaper-land-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11794089/NSW-Premier-Dominic-Perrottet-unveils-election-plan-ditch-stamp-duty-cheaper-land-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:12:31+00:00

NSW Premier Dominic Perrottet has proposed an expansion of the scheme that allows first homebuyers to choose between paying stamp duty or ongoing land tax at a cheaper rate.

## Phillip Island mum knew her days were numbered when she was hanged in a garage by her abusive ex
 - [https://www.dailymail.co.uk/news/melbourne/article-11800439/Phillip-Island-mum-knew-days-numbered-hanged-garage-abusive-ex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/melbourne/article-11800439/Phillip-Island-mum-knew-days-numbered-hanged-garage-abusive-ex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 04:03:45+00:00

A mother brutally murdered by her abusive husband who tried to make it look like a suicide knew she was powerless to stop him.

## More than 100 hoons shut down M1 motorway near Yatala in Queensland forcing drivers to wait
 - [https://www.dailymail.co.uk/news/article-11800655/More-100-hoons-shut-M1-motorway-near-Yatala-Queensland-forcing-drivers-wait.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800655/More-100-hoons-shut-M1-motorway-near-Yatala-Queensland-forcing-drivers-wait.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 03:49:29+00:00

More than 100 hoons took to the M1 near Yatala north of the Gold Coast on Saturday - stopping drivers in their tracks on the busy freeway as spectators filmed cars doing burnouts and donuts.

## Former Lord Mayor of Birmingham faces investigation for election bribery over packets of dates
 - [https://www.dailymail.co.uk/news/article-11800759/Former-Lord-Mayor-Birmingham-faces-investigation-election-bribery-packets-dates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800759/Former-Lord-Mayor-Birmingham-faces-investigation-election-bribery-packets-dates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 03:17:41+00:00

Former lord mayor of Birmingham, 78-year-old Muhammed Afzal, who handed packets of dates to Muslim voters during Ramadan is facing investigation for election bribery.

## Commonwealth Bank financial planner sues for $172,000 over working from home arrangement
 - [https://www.dailymail.co.uk/news/article-11800255/Commonwealth-Bank-financial-planner-sues-172-000-working-home-arrangement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800255/Commonwealth-Bank-financial-planner-sues-172-000-working-home-arrangement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 03:17:17+00:00

The Commonwealth Bank is being sued by a jilted financial planner after he argued their order he work from home permanently would disrupt his home life and cause tension in his family.

## Sydney podcaster slammed by dentists after travelling to Turkey for veneers to fix gap in his teeth
 - [https://www.dailymail.co.uk/news/article-11800341/Sydney-podcaster-slammed-dentists-travelling-Turkey-veneers-fix-gap-teeth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800341/Sydney-podcaster-slammed-dentists-travelling-Turkey-veneers-fix-gap-teeth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 03:05:31+00:00

Dentists have slammed a Sydney podcaster after he travelled to Turkey for his decision to get drastic dental work to get rid of the gap in his top front teeth.

## Forbes 30-Under-30 winner facing claims she duped JPMorgan into buying 'Amazon startup' for $175M
 - [https://www.dailymail.co.uk/news/article-11800533/Forbes-30-30-winner-facing-claims-duped-JPMorgan-buying-Amazon-startup-175M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800533/Forbes-30-30-winner-facing-claims-duped-JPMorgan-buying-Amazon-startup-175M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 03:01:17+00:00

Charlie Javice, 30, who is being sued by JPMorgan after they acquired her education startup for $175 million, has denied the bank's allegations of fraud that she created millions of fake customer accounts.

## Gold Coast jeweller Kevin Goonan robbed at gunpoint by two masked men as they steal precious gems
 - [https://www.dailymail.co.uk/news/article-11800479/Gold-Coast-jeweller-Kevin-Goonan-robbed-gunpoint-two-masked-men-steal-precious-gems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800479/Gold-Coast-jeweller-Kevin-Goonan-robbed-gunpoint-two-masked-men-steal-precious-gems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:46:51+00:00

Kevin Goonan was targeted in his home in Paradise Point, Gold Coast on Saturday afternoon by two masked thieves armed with a hammer and shotgun.

## Disney's longest serving employee of 70 YEARS dies at age 87: Animator worked on Lady and the Tramp
 - [https://www.dailymail.co.uk/news/article-11800639/Disneys-longest-serving-employee-70-YEARS-dies-age-87-Animator-worked-Lady-Tramp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800639/Disneys-longest-serving-employee-70-YEARS-dies-age-87-Animator-worked-Lady-Tramp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:44:34+00:00

Burny Mattinson, 87, was known as the longest-serving employee at The Walt Disney Company before he passed in Los Angeles on Monday. He worked at the company since he was about 18.

## Two missing Maine women discovered alive in their Jeep - after getting stuck in the snow for 5 DAYS
 - [https://www.dailymail.co.uk/news/article-11800683/Two-missing-Maine-women-discovered-alive-Jeep-getting-stuck-snow-5-DAYS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800683/Two-missing-Maine-women-discovered-alive-Jeep-getting-stuck-snow-5-DAYS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:41:24+00:00

Kimberly Pushard, 51, and Angela Bussell, 50, were heading to the Maine Mall in South Portland to go bowling when they got turned around on Tuesday.

## Qantas CEO Alan Joyce to leave airline by end of 2023 as ex-Air NZ boss Cameron Wallace joins race
 - [https://www.dailymail.co.uk/news/article-11799911/Qantas-CEO-Alan-Joyce-leave-airline-end-2023-ex-Air-NZ-boss-Cameron-Wallace-joins-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11799911/Qantas-CEO-Alan-Joyce-leave-airline-end-2023-ex-Air-NZ-boss-Cameron-Wallace-joins-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:21:39+00:00

The airline announced on Monday Cameron Wallace, the former Air New Zealand customer and chief com­mercial officer, had been appointed to CEO of Qantas International.

## All sides deny being behind 'constitutionally unwise' meeting between King and Ursula von der Leyen
 - [https://www.dailymail.co.uk/news/article-11800763/Northern-Ireland-protocol-Royal-thumbs-commission-boss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800763/Northern-Ireland-protocol-Royal-thumbs-commission-boss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:18:44+00:00

Questions are being asked over who did arrange the meeting between King Charles and EU commission chief Ursula von der Leyen - after all sides denied organising it.

## Australian Prudential Regulation Authority banking regulator reaffirms lending buffer rules
 - [https://www.dailymail.co.uk/news/article-11800093/Australian-Prudential-Regulation-Authority-banking-regulator-reaffirms-lending-buffer-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800093/Australian-Prudential-Regulation-Authority-banking-regulator-reaffirms-lending-buffer-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:18:40+00:00

Average-income Australians can now no longer buy a house selling for more than $545,000. Canstar money expert Effie Zahos has called for home lending rules to be changed.

## Sex education suspended in Isle of Man school after drag queen 'tells pupil there are 73 genders'
 - [https://www.dailymail.co.uk/news/article-11800751/Sex-education-suspended-Isle-Man-school-drag-queen-tells-pupil-73-genders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800751/Sex-education-suspended-Isle-Man-school-drag-queen-tells-pupil-73-genders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:17:16+00:00

An independent review has been launched into Queen Elizabeth II High School in Peel, Isle of Man, after Year 7 children were left 'traumatised'.

## Jim Chalmers unveils specific superannuation changes
 - [https://www.dailymail.co.uk/news/article-11800809/Jim-Chalmers-unveils-specific-superannuation-changes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800809/Jim-Chalmers-unveils-specific-superannuation-changes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:16:30+00:00

Treasurer Jim Chalmers has revealed Australians with more than $3million in superannuation savings will no longer be able to pay a concessional tax rate.

## Charles Bronson will 'likely have privileges removed' in prison amid new documentary
 - [https://www.dailymail.co.uk/news/article-11800777/Charles-Bronson-likely-privileges-removed-prison-amid-new-documentary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800777/Charles-Bronson-likely-privileges-removed-prison-amid-new-documentary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:14:15+00:00

The hardened criminal spoke to his supposed son George Bamby-Salvador via video call from HMP Woodhill for the Channel 4 programme 'Bronson: Fit To Be Free?'

## Alec Baldwin sued by three Rust crew members who suffer from anxiety PTSD and have blast injuries
 - [https://www.dailymail.co.uk/news/article-11800781/Alec-Baldwin-sued-three-Rust-crew-members-suffer-anxiety-PTSD-blast-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800781/Alec-Baldwin-sued-three-Rust-crew-members-suffer-anxiety-PTSD-blast-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:14:06+00:00

Three crew members of  Rust have filed a lawsuit against Alec Baldwin and the producers, claiming that they have experienced anxiety and PTSD symptoms.

## Headmaster tells parents to deal with their children's social media arguments
 - [https://www.dailymail.co.uk/news/article-11800761/Headmaster-tells-parents-deal-childrens-social-media-arguments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800761/Headmaster-tells-parents-deal-childrens-social-media-arguments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:10:52+00:00

Jon Boyes, headmaster of Herne Bay High School in Kent, said in a letter to parents and guardians that pupils in years 7 and 8 at the school are too young to be on the platforms.

## Auburn police station shooting: Counter terrorism detectives Indian man stabbing cleaner
 - [https://www.dailymail.co.uk/news/article-11800657/Auburn-police-station-shooting-Counter-terrorism-detectives-Indian-man-stabbing-cleaner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800657/Auburn-police-station-shooting-Counter-terrorism-detectives-Indian-man-stabbing-cleaner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 02:08:14+00:00

A 28-year-old male cleaner was starting his shift at Auburn Train Station, in Western Sydney, around 12am on Tuesday when he was randomly attacked by the 32-year-old man.

## 2GB's Ray Hadley panics at the suggestion he's caught Covid-19
 - [https://www.dailymail.co.uk/news/article-11800497/2GBs-Ray-Hadley-panics-suggestion-hes-caught-Covid-19.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800497/2GBs-Ray-Hadley-panics-suggestion-hes-caught-Covid-19.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:45:00+00:00

Ben Fordham and Ray Hadley had an awkward exchange live on 2GB after Fordham joked that Covid had 'finally got you'.
Hadley responded that he wouldn't 'poison' his co-workers.

## Radio 2 axed Ken Bruce early 'as BBC thought remaining on air was free advertising for his new show'
 - [https://www.dailymail.co.uk/news/article-11800749/Radio-2-axed-Ken-Bruce-early-BBC-thought-remaining-air-free-advertising-new-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800749/Radio-2-axed-Ken-Bruce-early-BBC-thought-remaining-air-free-advertising-new-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:38:28+00:00

The Scottish broadcaster, 72, will host his final 9.30am to 12pm Radio 2 show on Friday after 31 years before joining Greatest Hits Radio.

## JV Vandergrift: San Francisco radio DJ missing after making concerning edits to Instagram caption
 - [https://www.dailymail.co.uk/news/article-11800365/JV-Vandergrift-San-Francisco-radio-DJ-missing-making-concerning-edits-Instagram-caption.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800365/JV-Vandergrift-San-Francisco-radio-DJ-missing-making-concerning-edits-Instagram-caption.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:38:01+00:00

Jeffrey 'JV' Vandergrift, a California radio DJ, has gone missing without a trace after he made concerning edits to an Instagram caption thanking followers for a 'great journey.'

## Stranded Alice Springs Jetstar passenger Nikki Mitropoulos pulled off plane over tummy tuck pain
 - [https://www.dailymail.co.uk/news/article-11800109/Stranded-Alice-Springs-Jetstar-passenger-Nikki-Mitropoulos-pulled-plane-tummy-tuck-pain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800109/Stranded-Alice-Springs-Jetstar-passenger-Nikki-Mitropoulos-pulled-plane-tummy-tuck-pain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:36:42+00:00

Nikki Mitropoulos was on flight JQ30 from Bangkok to Melbourne that was forced to make an emergency landing in Alice Springs on Saturday night after a passenger had a suspected stroke.

## Sea World helicopter crash: Boy suffers another devastating blow after the crash killed his mother
 - [https://www.dailymail.co.uk/news/article-11800551/Sea-World-helicopter-crash-Boy-suffers-devastating-blow-crash-killed-mother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800551/Sea-World-helicopter-crash-Boy-suffers-devastating-blow-crash-killed-mother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:17:44+00:00

The brave boy who survived the SeaWorld helicopter crash that claimed the life of his mother has had his right leg amputated after doctors were unable to save it.

## A rare LS Lowry painting worth £150,000 returns to the public eye
 - [https://www.dailymail.co.uk/news/article-11800631/A-rare-LS-Lowry-painting-worth-150-000-returns-public-eye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800631/A-rare-LS-Lowry-painting-worth-150-000-returns-public-eye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:15:50+00:00

A rare LS Lowry painting worth an estimated £150,000 that has been hidden away in a private collection for decades will go up for auction.

## Hungarian budget airline Wizz Air suspends all flights to and from Moldova amid security concerns
 - [https://www.dailymail.co.uk/news/article-11800673/Hungarian-budget-airline-Wizz-Air-suspends-flights-Moldova-amid-security-concerns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800673/Hungarian-budget-airline-Wizz-Air-suspends-flights-Moldova-amid-security-concerns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:14:11+00:00

Moldova, a pro-European republic of 2.6 million people located between Romania and Ukraine, has feared that it could be Moscow's next target ever since Russia launched its offensive in Ukraine

## Kamala and Biden say nation can't 'erase' America's past at black history event
 - [https://www.dailymail.co.uk/news/article-11800437/Kamala-Biden-say-nation-erase-Americas-past-black-history-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800437/Kamala-Biden-say-nation-erase-Americas-past-black-history-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:12:41+00:00

Vice President Kamala Harris warned against efforts to 'erase' black history, and President Biden said 'great nations' remember 'the truth' as well as achievements of the past.

## Shock change to Bunnings that every Australian needs to know about
 - [https://www.dailymail.co.uk/news/article-11800053/Shock-change-Bunnings-Australian-needs-know-about.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800053/Shock-change-Bunnings-Australian-needs-know-about.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:11:51+00:00

Bunnings' boss Mike Schneider describes the decision to take advantage of a booming retail sector as 'the biggest category expansion in Bunnings for 20 years'.

## Landlords exploit Australia's rental crisis with garden SHED up for $350 - and wooden box for $330
 - [https://www.dailymail.co.uk/news/article-11800063/Landlords-exploit-Australias-rental-crisis-garden-SHED-350-wooden-box-330.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800063/Landlords-exploit-Australias-rental-crisis-garden-SHED-350-wooden-box-330.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:11:35+00:00

A shed in Melbourne for $350 per month and a homemade wooden box with visible nails in Sydney for $330 per week highlight the plight of renters.

## Outback Wrangler pens powerful post about helicopter crash victim
 - [https://www.dailymail.co.uk/news/article-11800349/Outback-Wrangler-pens-powerful-post-helicopter-crash-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800349/Outback-Wrangler-pens-powerful-post-helicopter-crash-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:08:55+00:00

Chris Wilson, 34, died in a helicopter crash on February 28 last year. Outback Wrangler Matt Wright was charged over his death. Wright wrote a tribute to his mate on the  anniversary of the tragedy.

## ABC demands no bias over Voice as it bans words 'grog' and 'booze' from Alice Springs reporting
 - [https://www.dailymail.co.uk/news/article-11800415/ABC-demands-no-bias-Voice-bans-words-grog-booze-Alice-Springs-reporting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800415/ABC-demands-no-bias-Voice-bans-words-grog-booze-Alice-Springs-reporting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 01:07:37+00:00

An email sent to staff on Monday noted ABC journalists were about to 'embark on one of the most difficult and consequential stories of recent times.'

## Christian high school girls' basketball team forfeits playoffs game against team with trans student
 - [https://www.dailymail.co.uk/news/article-11800321/Christian-high-school-girls-basketball-team-forfeits-playoffs-game-against-team-trans-student.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800321/Christian-high-school-girls-basketball-team-forfeits-playoffs-game-against-team-trans-student.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:57:26+00:00

A Christian prep school in Vermont forfeited a playoff girls basketball game in the state championship tournament after discovering the opposing team had a transgender player on the roster.

## Law student, 20, claims Durham University failed to take racist abuse seriously
 - [https://www.dailymail.co.uk/news/article-11800699/Law-student-20-claims-Durham-University-failed-racist-abuse-seriously.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800699/Law-student-20-claims-Durham-University-failed-racist-abuse-seriously.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:55:46+00:00

Samantha Smith, 20, said she was called the N-word at a late-night gathering of the Durham Union, the university's oldest and largest society.

## Collingwood Magpies superfan: Man sexually abused by Jeffrey 'Joffa' Corfe breaks his silence
 - [https://www.dailymail.co.uk/news/article-11799981/Collingwood-Magpies-superfan-Man-sexually-abused-Jeffrey-Joffa-Corfe-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11799981/Collingwood-Magpies-superfan-Man-sexually-abused-Jeffrey-Joffa-Corfe-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:46:43+00:00

Alex Case, 31, was groomed and sexually abused by Collingwood Magpies superfan Jeffrey 'Joffa' Corfe in his home in Coburg, in Melbourne's north, on January 29, 2005.

## DOMINIC RAAB, STEVE BARCLAY and DAVID DAVIS give their backing to the Northern Ireland Protocol
 - [https://www.dailymail.co.uk/news/article-11800599/DOMINIC-RAAB-STEVE-BARCLAY-DAVID-DAVIS-backing-Northern-Ireland-Protocol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800599/DOMINIC-RAAB-STEVE-BARCLAY-DAVID-DAVIS-backing-Northern-Ireland-Protocol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:31:33+00:00

In 2016 we all voted to leave the European Union and take back control of our laws, our borders and our seas. It was the right choice for our country.

## CRAIG BROWN discusses how author Roald Dahl censored his own books
 - [https://www.dailymail.co.uk/news/article-11800587/CRAIG-BROWN-discusses-author-Roald-Dahl-censored-books.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800587/CRAIG-BROWN-discusses-author-Roald-Dahl-censored-books.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:21:28+00:00

CRAIG BROWN: Roald Dahl was a contrarian. He loved to take people by surprise, and to go too far.

## Shocking moment high school girls' basketball coach jumps into stand to fight a spectator
 - [https://www.dailymail.co.uk/news/article-11800299/Shocking-moment-high-school-girls-basketball-coach-jumps-stand-fight-spectator.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800299/Shocking-moment-high-school-girls-basketball-coach-jumps-stand-fight-spectator.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:10:27+00:00

Richlands High School's coach of the year Tom Rife was caught jumping over chairs and launching toward a man who appeared to be yelling at him seconds before his team lost 54 to 51.

## Grandmas recreate Rihanna's Super Bowl performance in hilarious viral TikTok video
 - [https://www.dailymail.co.uk/news/article-11799925/Grandmas-recreate-Rihannas-Super-Bowl-performance-hilarious-viral-TikTok-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11799925/Grandmas-recreate-Rihannas-Super-Bowl-performance-hilarious-viral-TikTok-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:10:24+00:00

A group of Kentucky grandmothers are proving you only get better with age after posting a hilarious recreation of Rihanna's Super Bowl LVII performance.

## Experts sound the alarm on antibiotic-resistant superbugs
 - [https://www.dailymail.co.uk/news/article-11800043/Experts-sound-alarm-antibiotic-resistant-superbugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800043/Experts-sound-alarm-antibiotic-resistant-superbugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:09:51+00:00

Australia is at risk of a 'silent pandemic' that could kill tens of millions a year, with experts sounding the alarm on the growing crisis of antibiotic-resistant superbugs.

## Production company behind 'Sharknado' is set to release 'Attack of the Meth Gator' this summer
 - [https://www.dailymail.co.uk/news/article-11800205/Production-company-Sharknado-set-release-Attack-Meth-Gator-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800205/Production-company-Sharknado-set-release-Attack-Meth-Gator-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:08:52+00:00

The Asylum production company has announced Attack of the Meth Gator will be hitting screens this May. The company pioneered the crazy animal movies after it debuted Sharknado in 2013.

## Jeremy Hunt gets a £56billion Budget boost - but he now faces calls to deliver tax cuts
 - [https://www.dailymail.co.uk/news/article-11800471/Jeremy-Hunt-gets-56billion-Budget-boost-faces-calls-deliver-tax-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800471/Jeremy-Hunt-gets-56billion-Budget-boost-faces-calls-deliver-tax-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:05:36+00:00

Jeremy Hunt has been given the boost thanks to falling energy prices and a stronger economy which have left the public finances in a better position than predicted.

## Drag queen Penny Tration is refused service from a taxi driver during Sydney's Mardi Gras
 - [https://www.dailymail.co.uk/news/article-11800143/Drag-queen-Penny-Tration-refused-service-taxi-driver-Sydneys-Mardi-Gras.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800143/Drag-queen-Penny-Tration-refused-service-taxi-driver-Sydneys-Mardi-Gras.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:05:14+00:00

Footage shows a taxi driving off when the driver spotted the performer - who goes by the stage name Penny Tration - leaving her on the street struggling to get home while carrying bags.

## Royal Mail unveils the final stamps that will feature the late Queen's silhouette
 - [https://www.dailymail.co.uk/news/article-11800443/Royal-Mail-unveils-final-stamps-feature-late-Queens-silhouette.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800443/Royal-Mail-unveils-final-stamps-feature-late-Queens-silhouette.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:02:56+00:00

The final stamps to feature the late Queen's silhouette will be unveiled today. She will appear on a set of special stamps which mark the 100th anniversary of the Flying Scotsman.

## BBC warned to 'reconsider' its focus on sharing stories on TikTok
 - [https://www.dailymail.co.uk/news/article-11800523/BBC-warned-reconsider-focus-sharing-stories-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800523/BBC-warned-reconsider-focus-sharing-stories-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:01:51+00:00

BBC News boss Deborah Turness has told staff that increasing the corporation's presence on the social media platform is a priority for this year.

## Rupert Murdoch admits Fox News hosts endorsed Trump claims that the election was stolen
 - [https://www.dailymail.co.uk/news/article-11800233/Rupert-Murdoch-admits-Fox-News-hosts-endorsed-Trump-claims-election-stolen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11800233/Rupert-Murdoch-admits-Fox-News-hosts-endorsed-Trump-claims-election-stolen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-28 00:01:43+00:00

Murdoch denied that Fox as a network endorsed the claims, but admitted a collection his hosts shared the 'stolen election lies', according to a transcript of the billionaire's deposition from last month.

