# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Będą zwolnienia w dziennikach "Bild" i "Welt". Axel Springer planuje redukcję zatrudnienia
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8670166,niemcy-wydawnictwo-axel-springer-planuje-redukcje-zatrudnienia-w-dziennikach-bild-i-welt.html](https://forsal.pl/biznes/aktualnosci/artykuly/8670166,niemcy-wydawnictwo-axel-springer-planuje-redukcje-zatrudnienia-w-dziennikach-bild-i-welt.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 20:51:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eTsktkuTURBXy9kYWEyYTc3Ny0wZTRkLTQxYWMtYWYxNC02YTZlNzA3ZjYzZWQuanBlZ5GTBc0BHcyg" />Koncern medialny Axel Springer redukuje miejsca pracy w swoich niemieckich dziennikach &quot;Bild&quot; i &quot;Welt&quot;. W liście do pracowników szef koncernu Mathias Doepfner wyjaśnił, że będą &quot;znaczące redukcje miejsc pracy&quot; w produkcji, składzie, korekcie i administracji.

## Finlandia rozpoczęła budowę zapory na granicy z Rosją
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8670155,finlandia-rosja-zapora.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8670155,finlandia-rosja-zapora.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 19:53:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3iBktkuTURBXy9mMDhjYTM5OS1lZWE0LTRlMjgtODMwYi0zZDRmOTIyMTZmYzguanBlZ5GTBc0BHcyg" />W okolicach Imatry, na południowym wschodzie Finlandii, rozpoczęła się budowa zapory na granicy z Rosją – poinformowała we wtorek fińska straż graniczna. Powstający w ramach pilotażowego projektu trzymetrowy płot ma się rozciągać na odcinku 3 km.

## Parlament Danii znalazł ciekawy sposób na sfinansowanie wojska. Zlikwidował święto
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8670069,dania-wojsko-swieto-narodowe.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8670069,dania-wojsko-swieto-narodowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 19:04:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BIbktkuTURBXy9mZDBlZjY2Mi1kMGIzLTRjYzEtODljNy1lNzUyMzBkMDNjYTIuanBlZ5GTBc0BHcyg" />Parlament Danii Folketing po kilkugodzinnej debacie przegłosował we wtorek zniesienie od przyszłego roku wolnego od pracy święta Wielki Dzień Modlitwy. Uzyskane z tego tytułu oszczędności mają sfinansować wzrost nakładów na wojsko.

## Polski holding technologiczny FAMUR S.A. szantażowany przez Rosjan
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8670062,famur-szantazowany-przez-rosjan.html](https://forsal.pl/biznes/aktualnosci/artykuly/8670062,famur-szantazowany-przez-rosjan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 18:54:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ViYktkuTURBXy8yYmQwYzRlYS1mZjY5LTQ3OTAtYWVjYy0xYzI1ODAyNDE2N2MuanBlZ5GTBc0BHcyg" />Jak przekazał w komunikacie Zarząd FAMUR S.A., polskiego holdingu dostarczającego urządzeń dla branż energetycznej, wydobywczej i transportowej, w poniedziałek 27 lutego jego biuro w Katowicach odwiedzili dwaj rosyjskojęzyczni mężczyźni. Przedstawili oni firmie ofertę &quot;nie do odrzucenia&quot;.

## Reforma emerytalna we Francji wzbudza burzliwe dyskusje. Senat przyjął projekt z kilkoma poprawkami
 - [https://forsal.pl/praca/aktualnosci/artykuly/8669971,francja-reforma-emerytalna-senat.html](https://forsal.pl/praca/aktualnosci/artykuly/8669971,francja-reforma-emerytalna-senat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 18:21:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mVrktkuTURBXy9lNGQ0MDY4ZS05ZTVlLTRjNTMtODA5Zi01OWRjMWY4OGNkMTMuanBlZ5GTBc0BHcyg" />Komisja Senatu Francji, która we wtorek zajęła się rządowym projektem reformy zakładającej podniesienie wieku emerytalnego z 62 do 64 lat, zaakceptowała tekst po wprowadzeniu kilku poprawek. Poprawki głównie wnoszą korzystniejsze rozwiązania w sprawie przechodzenia na emeryturę matek i ochrony starszych pracowników.

## Dochody kontra inflacja. Tylko jednej grupie udało się wyjść na plus
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8669566,inflacja-kto-stracil-najwiecej-realny-spadek-dochodow.html](https://forsal.pl/gospodarka/inflacja/artykuly/8669566,inflacja-kto-stracil-najwiecej-realny-spadek-dochodow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 18:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MSEktkuTURBXy9jMGQ0ZTBmMi01MzMyLTRmYTUtYmVjNS1iNWE4ZTY2ZDc3YTEuanBlZ5GTBc0BHcyg" />&quot;Pracujący na stanowiskach nierobotniczych” to grupa, która w ostatnich dwóch latach została dotknięta największym realnym spadkiem dochodu. Z kolei jedyna grupa, która jest realnie na plusie, to pracujący na własny rachunek.

## Daniel Obajtek: "To my ustalamy ceny". Strategia Orlenu [OPINIA]
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669958,strategia-orlenu-opinia.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669958,strategia-orlenu-opinia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 17:40:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Qi-ktkuTURBXy8zMWRjOWI3MC0yZDE5LTRmNTQtYTk5ZS1iZmI4NDQ1ZTQ5NDAuanBlZ5GTBc0BHcyg" />PKN Orlen stał się na tyle dużą firmą, że zaprezentowane z okazji aktualizacji strategii firmy liczby, mają znaczenie dla całej gospodarki. Dla klientów firmy, którymi są niemal wszyscy Polacy, ważniejsze były słowa prezesa Daniela Obajtka o tym, jak Orlen ustala ceny benzyny, oleju napędowego i gazu na rynku.

## Prorosyjska, antyrządowa demonstracja w Mołdawii
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8669948,moldawia-prorosyjska-antyrzadowa-demonstracja.html](https://forsal.pl/swiat/aktualnosci/artykuly/8669948,moldawia-prorosyjska-antyrzadowa-demonstracja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 17:14:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hidktkuTURBXy82M2I2ZmMyYi0zN2YxLTQxZWEtOTdhMS03ZDNlMjRhMjQyMjMuanBlZ5GTBc0BHcyg" />Tysiące demonstrantów wyszło we wtorek na ulice stolicy Mołdawii Kiszyniowa w antyrządowej demonstracji; domagają się dopłat do rachunków za energię za okres zimowy oraz &quot;nieangażowania kraju w wojnę&quot;. Protesty zorganizowała prorosyjska opozycja - podała agencja AP.

## Prokurator skierował do sądu wniosek o tymczasowy areszt dla Włodzimierza Karpińskiego
 - [https://forsal.pl/gospodarka/prawo/artykuly/8669894,wlodzimierz-k-areszt-tymczasowy.html](https://forsal.pl/gospodarka/prawo/artykuly/8669894,wlodzimierz-k-areszt-tymczasowy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 16:15:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u3mktkuTURBXy9lZTc4YmRlMy01NGM1LTQ0MDUtOGQ4Yi05Mzg1NDEwNjY2M2IuanBlZ5GTBc0BHcyg" />Po przesłuchaniu podejrzanego prokurator zdecydował o skierowaniu do sądu wniosku o zastosowanie tymczasowego aresztowania Włodzimierza K. wz. z zarzutem dotyczącym żądania i przyjęcia korzyści majątkowej - przekazał PAP we wtorek rzecznik Prokuratury Krajowej prok. Łukasz Łapczyński.

## Parlament Finlandii debatuje nad ratyfikacją członkostwa w NATO. Nie czeka na decyzje Turcji i Węgier
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8669866,finlandia-turcja-wegry-nato-parlament-debata.html](https://forsal.pl/swiat/aktualnosci/artykuly/8669866,finlandia-turcja-wegry-nato-parlament-debata.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 15:51:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3iBktkuTURBXy9mMDhjYTM5OS1lZWE0LTRlMjgtODMwYi0zZDRmOTIyMTZmYzguanBlZ5GTBc0BHcyg" />We wtorek w fińskim parlamencie rozpoczęło się ostateczne czytanie projektu ustawy o ratyfikacji Traktatu Północnoatlantyckiego. Deputowani chcą przyjąć akt, jeszcze zanim protokoły akcesyjne złożone przez Finlandię i Szwecję ratyfikują Turcja i Węgry.

## Ustawowy zakaz eksploatowania migrantów zarobkowych w Holandii
 - [https://forsal.pl/praca/aktualnosci/artykuly/8669863,holandia-zakaz-eksploatacji-migrantow-zarobkowych.html](https://forsal.pl/praca/aktualnosci/artykuly/8669863,holandia-zakaz-eksploatacji-migrantow-zarobkowych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 15:47:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rvnktkuTURBXy82ZGIwZWU3MS1iNWZlLTQ4Y2EtYWYwNi02OGI0NGZkYzI4MDAuanBlZ5GTBc0BHcyg" />Rząd Holandii przekazał we wtorek do parlamentu projekt ustawy penalizujący wykorzystywanie migrantów zarobkowych. Podlegające karze ma być m.in. kwaterowanie w złych warunkach oraz zaniżanie wynagrodzenia.

## Donald Tusk, jeśli wygra wybory, nie podniesie wieku emerytalnego i zalegalizuje aborcję
 - [https://forsal.pl/gospodarka/polityka/artykuly/8669859,donald-tusk-wybory-wiek-emerytalny-aborcja.html](https://forsal.pl/gospodarka/polityka/artykuly/8669859,donald-tusk-wybory-wiek-emerytalny-aborcja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 15:41:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2liktkuTURBXy80OGVjNDIzOS1kOTQ0LTQ5NzUtYjg4My0yZDE5N2QwYTFhYmEuanBlZ5GTBc0BHcyg" />Do przymusowego podniesienia wieku emerytalnego na pewno nie będę wracał - mówił we wtorek w Łodzi szef PO Donald Tusk. Zapowiedział też, że po wygraniu wyborów będzie przekonywał przyszłych koalicjantów do wprowadzenia w Polsce legalnej aborcji do 12 tygodnia ciąży.

## Chaos komunikacyjny w Portugalii. Powód? Strajku kolejarzy
 - [https://forsal.pl/transport/kolej/artykuly/8669830,portugalia-strajk-kolejarzy-chaos-komunikacyjny.html](https://forsal.pl/transport/kolej/artykuly/8669830,portugalia-strajk-kolejarzy-chaos-komunikacyjny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 14:39:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QTQktkuTURBXy8xMzdhMzY1My03YmNlLTRhMGMtODgxYy1mYjBhYjQ2OTFkYzguanBlZ5GTBc0BHcyg" />Zorganizowany przez kilka związków zawodowych strajk na kolei w Portugalii doprowadził we wtorek do chaosu komunikacyjnego. Czterodniowy protest na tle płacowym prowadzony jest na terenie całego kraju.

## Według Ministerstwa Finansów zadłużenie Skarbu Państwa wzrosło w grudniu, ale w styczniu spadło
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8669824,ministerstwo-finansow-skarb-panstwa-zadluzenie.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8669824,ministerstwo-finansow-skarb-panstwa-zadluzenie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 14:30:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5BEktkuTURBXy9mYjUyYWI2Ny02YzI1LTQyNTUtOTgxYS1kZTgwYWM1MDdmMmIuanBlZ5GTBc0BHcyg" />undefined

## Znów chorujemy na grypę. Rośnie też liczba zgonów
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8669814,grypa-wzrost-zachorowan-zgonow.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8669814,grypa-wzrost-zachorowan-zgonow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 14:14:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MPXktkuTURBXy8zNjYyZDA1ZS1hNjZiLTQyNjUtOGNkZi1jOGUwZGZkY2Q3YWUuanBlZ5GTBc0BHcyg" />Według Narodowego Instytutu Zdrowia Publicznego-PZH do 22 lutego 2023 r. odnotowano blisko 4 mln przypadków zachorowań z powodu grypy - czyli tyle, ile w sezonach grypowych przed pandemią. Zarejestrowano też dużą liczbę zgonów - jedną z największych w ostatniej dekadzie.

## Wikipedia z 2 milionami rubli kary. Za... publikowanie "fałszywych informacji"
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669806,wikipedia-wikimedia-kara-2-mln-rubli.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669806,wikipedia-wikimedia-kara-2-mln-rubli.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 14:06:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UDHktkuTURBXy9iZjhhYWNjOC04OTUwLTQ1OTctOGEyOC1mZTgzMmJlYmNiODkuanBlZ5GTBc0BHcyg" />Sąd w Moskwie skazał we wtorek Fundację Wikimedia (organizację non-profit administrującą Wikipedią) na grzywnę w wysokości 2 milionów rubli, czyli około 118 tys. złotych, za publikowanie &quot;fałszywych informacji&quot;.

## Mobilny dowód osobisty? Będzie obsługiwany przez aplikację mObywatel
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8669794,mobywatel-mobilny-dowod-osobisty.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8669794,mobywatel-mobilny-dowod-osobisty.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 13:42:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/blMktkuTURBXy84NmEwNjlhZC03NGY3LTQ0MDUtYTNiZS01MTIyYzBjYzkxYzIuanBlZ5GTBc0BHcyg" />undefined

## Samorządy będą sprzedawać węgiel do końca czerwca? Rząd planuje przedłużenie terminu
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8669793,samorzady-sprzedaz-wegla.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8669793,samorzady-sprzedaz-wegla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 13:36:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Em2ktkuTURBXy8zZGRhNThhMC03NTQ1LTQzOWUtYWI4ZC0zNDQ4MDA4M2U5ZWEuanBlZ5GTBc0BHcyg" />undefined

## Obajtek: Gaz dla biznesu od marca o połowę tańszy
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669791,pkn-orlen.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669791,pkn-orlen.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 13:28:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TycktkuTURBXy8yMDhmMzQxZS1iNzU3LTQyM2QtYmQ5Ni0zOTIxNmVmZjQ2NmUuanBlZ5GTBc0BHcyg" />Cena gazu sprzedawanego dla tzw. klientów cennikowych, m.in. piekarni, zostanie od 15 marca obniżona o ponad 50 proc. do 353 zł z 650 zł za jedną MWh - poinformował podczas wtorkowej konferencji prasowej prezes PKN Orlen Daniel Obajtek.

## Budimex wszedł w elektromobilność. Negocjuje pozyskanie kolejnych stacji ładowania
 - [https://forsal.pl/biznes/ekologia/artykuly/8669788,budimex-elektromobilnosc-stacje-ladowania.html](https://forsal.pl/biznes/ekologia/artykuly/8669788,budimex-elektromobilnosc-stacje-ladowania.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 13:25:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jDLktkuTURBXy81MDU5MzRiNS1lYzNjLTQ0YWItYTQwMi01OThmYmYwN2Y1NmUuanBlZ5GTBc0BHcyg" />undefined

## PKO BP: W IV kw. 2022 r. zaczęła się w Polsce recesja konsumencka. Ponure perspektywy
 - [https://forsal.pl/gospodarka/artykuly/8669781,pko-bp-w-iv-kw-2022-r-zaczela-sie-w-polsce-recesja-konsumencka.html](https://forsal.pl/gospodarka/artykuly/8669781,pko-bp-w-iv-kw-2022-r-zaczela-sie-w-polsce-recesja-konsumencka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 13:12:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/urYktkuTURBXy8yYzhmZGE2OC1mM2RjLTQ3NmQtYmI0YS0wM2IxNzRkNTlkNzUuanBlZ5GTBc0BHcyg" />W IV kw. 2022 r. zaczęła się w Polsce recesja konsumencka. Perspektywy dla konsumpcji na najbliższe kwartały rysują się naszym zdaniem w ciemnych barwach – stwierdzono w komentarzu banku PKO BP do wtorkowych danych GUS.

## Morawiecki: Chcemy, by program "pierwsze mieszkanie" wszedł w życie od 1 lipca br.
 - [https://forsal.pl/gospodarka/polityka/artykuly/8669764,kiedy-wejdzie-program-pierwsze-mieszkanie.html](https://forsal.pl/gospodarka/polityka/artykuly/8669764,kiedy-wejdzie-program-pierwsze-mieszkanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 12:46:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w46ktkuTURBXy8zYzM3MDQ4Mi0zMGZkLTRiMDItYjFmNS1iMzU0ZmQ2NjgyMzEuanBlZ5GTBc0BHcyg" />Chcemy, żeby program &quot;pierwsze mieszkanie&quot; został przegłosowany w ciągu dwóch miesięcy i wszedł w życie od 1 lipca br. - powiedział we wtorek na konferencji prasowej po posiedzeniu rządu premier Mateusz Morawiecki.

## News DGP: Poznaliśmy nazwisko nowego szefa Narodowego Instytutu Zdrowia Publicznego
 - [https://forsal.pl/gospodarka/artykuly/8669754,nowy-szef-narodowego-instytutu-zdrowia-publicznego.html](https://forsal.pl/gospodarka/artykuly/8669754,nowy-szef-narodowego-instytutu-zdrowia-publicznego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 12:32:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/c4mktkuTURBXy84YmEzODAwOC04MzU1LTQ4M2EtOGY0Mi1hYjc0MjI2ZjQwNDAuanBlZ5GTBc0BHcyg" />Jest nowy szef Narodowego Instytutu Zdrowia Publicznego. Jak wynika z informacji DGP - został nim były wiceprezes NFZ Bernard Waśko. Poprzedni szef Grzegorz Juszczyk został odwołany na początku września zeszłego roku. Oficjalnym powodem były sprawy osobiste.

## Szef MON zatwierdził umowę ramową na 1000 wozów Borsuk
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8669748,mon-zatwierdzil-umowe-ramowa-na-1000-wozow-borsuk.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8669748,mon-zatwierdzil-umowe-ramowa-na-1000-wozow-borsuk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 12:18:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LguktkuTURBXy9mZjUwZTY1OC00MzA4LTQ2OTYtOTBmYi01MTVkZDllNTVmNjIuanBlZ5GTBc0BHcyg" />Wicepremier, szef MON Mariusz Błaszczak zatwierdził we wtorek umowę ramową na dostawę blisko 1400 nowych pojazdów dla wojska, w tym blisko 1000 gąsienicowych bojowych wozów piechoty Borsuk oraz pojazdy towarzyszące.

## Morawiecki: Nadwyżka budżetu w styczniu 2023 r. wyniosła ponad 11 mld zł
 - [https://forsal.pl/gospodarka/artykuly/8669677,nadwyzka-budzetu-w-styczniu-2023.html](https://forsal.pl/gospodarka/artykuly/8669677,nadwyzka-budzetu-w-styczniu-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 11:51:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-z5ktkuTURBXy8yNDIyY2Q5My1kZTBlLTRjMWItYjA4ZC0yMmFlOTJjZWZmNTQuanBlZ5GTBc0BHcyg" />Budżet państwa w styczniu 2023 r. miał ponad 11 mld zł nadwyżki - poinformował we wtorek na konferencji prasowej po posiedzeniu rządu premier Mateusz Morawiecki.

## Stoltenberg: Putin nie planuje pokoju, lecz kontynuację wojny
 - [https://forsal.pl/gospodarka/polityka/artykuly/8669658,putin-nie-planuje-pokoju-wojna.html](https://forsal.pl/gospodarka/polityka/artykuly/8669658,putin-nie-planuje-pokoju-wojna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 11:44:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u-HktkuTURBXy82OWI1ODkwYy04ZjViLTRkNzItOGJhMC04ZGQ2NjJmZWVkMzguanBlZ5GTBc0BHcyg" />Nie ma oznak, aby Putin dążył do pokoju i zmienił swoje plany; w kwestii bezpieczeństwa jesteśmy w krytycznym momencie – oświadczył we wtorek w Helsinkach sekretarz generalny NATO Jens Stoltenberg. Priorytetem jest, aby Finlandia i Szwecja weszły do NATO „możliwie szybko”, ale to i tak jest – zaznaczył – „najszybszy proces akcesyjny w historii” Sojuszu.

## Rzecznik PiS: Z propozycji Tuska cieszą się deweloperzy i wielkie banki
 - [https://forsal.pl/gospodarka/polityka/artykuly/8669610,deweloperzy-wielkie-banki-pis-donald-tusk.html](https://forsal.pl/gospodarka/polityka/artykuly/8669610,deweloperzy-wielkie-banki-pis-donald-tusk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 11:37:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QdHktkuTURBXy9hNGFmOTQ5MC0zYzdmLTQ1ZjktYWIyMy04MjE5NTRmZGI1MDAuanBlZ5GTBc0BHcyg" />Najbardziej z propozycji Donalda Tuska Kredyt 0% cieszą się deweloperzy i wielkie banki; to propozycja skrojona pod nich, a nie pod zwykłych obywateli - uważają politycy PiS.

## Rzecznik SP: Unijny zakaz rejestracji samochodów spalinowych jest sprzeczny z polskim interesem
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8669601,zakaz-rejestracji-samochodow-spalinowych-sprzeczny-z-polskim-interesem.html](https://forsal.pl/swiat/unia-europejska/artykuly/8669601,zakaz-rejestracji-samochodow-spalinowych-sprzeczny-z-polskim-interesem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 11:27:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tSCktkuTURBXy9iNWZhNGE4Yi1kNzJiLTRjMTktYWRjMS1jZDIxYjRhNmM2NTIuanBlZ5GTBc0BHcyg" />Solidarna Polska rozpoczyna ogólnopolską akcję informowania o sprzeczności unijnego zakazu rejestracji samochodów spalinowych z polskim interesem; miejmy nadzieję, że w nowej kadencji Parlament Europejski naprawi swój błąd - powiedział rzecznik SP, wiceszef resortu klimatu i środowiska Jacek Ozdoba.

## Carbon Group złożył wnioski o upadłość i układ, liczy na restrukturyzację w ramach układu
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669580,carbon-group-zlozyl-wnioski-o-upadlosc-i-uklad-liczy-na-restrukturyzacje-w-ramach-ukladu.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669580,carbon-group-zlozyl-wnioski-o-upadlosc-i-uklad-liczy-na-restrukturyzacje-w-ramach-ukladu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 11:19:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/D81ktkuTURBXy8yODM3N2M1NS1jNDcxLTRmMmUtOTYwYi04YjhjMjhkOGMwMzYuanBlZ5GTBc0BHcyg" />undefined

## Wielton chce zwiększyć marżę EBITDA do 5,9%, przychody - do ok. 3,6 mld zł w 2023 r.
 - [https://forsal.pl/biznes/przemysl/artykuly/8669556,wielton-chce-zwiekszyc-marze-ebitda-do-59-przychody-do-ok-36-mld-zl-w-2023-r.html](https://forsal.pl/biznes/przemysl/artykuly/8669556,wielton-chce-zwiekszyc-marze-ebitda-do-59-przychody-do-ok-36-mld-zl-w-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 11:14:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dbMktkuTURBXy9hNzI1MmUyMi04OGQ2LTRhMDUtYjcxMS02MGRlNmQwNjg3OTYuanBlZ5GTBc0BHcyg" />undefined

## Grupa Wielton miała szacunkowo 201,2 mln zł zysku EBITDA w 2022 r.
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669543,wielton-wyniki-finansowe-szacunkowy-zysk-ebitda-w-2022-r.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669543,wielton-wyniki-finansowe-szacunkowy-zysk-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 11:11:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wDMktkuTURBXy81ZjlmYjRiMy05MmM5LTQ3OWMtOTQzNy1jNTJlNDg5MDNmMjMuanBlZ5GTBc0BHcyg" />undefined

## MSWiA: Stopnie alarmowe BRAVO i CHARLIE-CRP przedłużone do końca maja
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8669520,mswia-stopnie-alarmowe-bravo-i-charlie-crp-przedluzone-do-konca-maja.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8669520,mswia-stopnie-alarmowe-bravo-i-charlie-crp-przedluzone-do-konca-maja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 11:06:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MiZktkuTURBXy82ZjE5ZDA4ZC1kODEzLTQ3ZTctOGZjYy1iNTc1MjI1MDZlYzIuanBlZ5GTBc0BHcyg" />Premier Mateusz Morawiecki przedłużył do końca maja obowiązywanie stopni alarmowych BRAVO i CHARLIE–CRP - podało Ministerstwo Spraw Wewnętrznych i Administracji. Stopień BRAVO dotyczy zagrożenia terroryzmem, a CHARLIE-CRP - cyberterroryzmem.

## Tusk i Kaczyński na samym dnie. Oto ranking zaufania do polityków
 - [https://forsal.pl/gospodarka/polityka/artykuly/8669491,ranking-zaufania-do-politykow-cbos.html](https://forsal.pl/gospodarka/polityka/artykuly/8669491,ranking-zaufania-do-politykow-cbos.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 10:46:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EXiktkuTURBXy9jZDc3OGY0NS1jMDRiLTQyYjUtYmM5My03NzUwMDU0NDExZTIuanBlZ5GTBc0BHcyg" />Prezydent Andrzej Duda, szef MON Mariusz Błaszczak, prezydent Warszawy Rafał Trzaskowski i premier Mateusz Morawiecki to liderzy rankingu zaufania w lutym - wynika z sondażu CBOS. Z największą nieufnością spotyka się szef PO Donald Tusk i prezes PiS Jarosław Kaczyński.

## "Polskie Szwalnie”. Porażka programu, są wyniki kontroli NIK
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669488,polskie-szwalnie-porazka-kontrola-nik-wyniki.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669488,polskie-szwalnie-porazka-kontrola-nik-wyniki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 10:45:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EcyktkuTURBXy82YWJhNjAwYi01NWVlLTQ4YzgtOWJjMy01YzczMWE2ZDBkN2EuanBlZ5GTBc0BHcyg" />Porażka programu „Polskie Szwalnie” - NIK ogłasza wyniki kontroli produkcji polskich maseczek.

## Ekonomiści ING: Wzrost PKB w 2023 r. wyniesie ok. 1 proc.
 - [https://forsal.pl/gospodarka/pkb/artykuly/8669459,ekonomisci-ing-wzrost-pkb-w-2023-r-wyniesie-ok-1-proc.html](https://forsal.pl/gospodarka/pkb/artykuly/8669459,ekonomisci-ing-wzrost-pkb-w-2023-r-wyniesie-ok-1-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 10:42:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FXzktkuTURBXy9hMWYyYzI3My1jMDZlLTQ3ODYtYjBmMy02OWVjYzA4YWIxNTYuanBlZ5GTBc0BHcyg" />W całym 2023 r. spodziewamy się wzrostu PKB w okolicach 1 proc. – poinformowano w komentarzu ekonomistów ING BSK do wtorkowych danych GUS o wzroście PKB w ostatnim kwartale zeszłego roku.

## Serbia i Kosowo zatwierdziły projekt porozumienia normalizującego ich stosunki
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8669421,serbia-i-kosowo-zatwierdzily-projekt-porozumienia-normalizujacego-ich-stosunki.html](https://forsal.pl/swiat/aktualnosci/artykuly/8669421,serbia-i-kosowo-zatwierdzily-projekt-porozumienia-normalizujacego-ich-stosunki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 10:23:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wgDktkuTURBXy83MTNmYzg4NS1hOTg1LTQ1YTgtYjY5Mi0wYzFjOGMwMmQ5OGIuanBlZ5GTBc0BHcyg" />Prezydent Serbii Aleksandar Vuczić oraz premier Kosowa Albin Kurti zgodzili się, że dalsze rozmowy na temat treści firmowanego przez Unię Europejską porozumienia nie są potrzebne - przekazał szef unijnej dyplomacji Josep Borrell. Po raz pierwszy również oficjalnie przedstawiono treść &quot;Umowy zmierzającej do normalizacji stosunków pomiędzy Kosowem i Serbią&quot;.

## Japonia ma rekordowy budżet. Będą wielkie inwestycje w zbrojenia i świadczenia społeczne
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8669321,japonia-ma-rekordowy-budzet-beda-wielkie-inwestycje-w-zbrojenia-i-swiadczenia-spoleczne.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8669321,japonia-ma-rekordowy-budzet-beda-wielkie-inwestycje-w-zbrojenia-i-swiadczenia-spoleczne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 09:51:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YXSktkuTURBXy9lNWI0MTMyMy04YmNlLTRmNTYtODc3Ny0yMjE0NmVlZDcxZWYuanBlZ5GTBc0BHcyg" />Niższa izba parlamentu Japonii zatwierdziła rekordowy budżet wynoszący 114,38 bln jenów (840 mld USD), który przewiduje znaczny wzrost wydatków na obronność i największe w historii środki na świadczenia społeczne – podała we wtorek agencja Kyodo.

## O co chodzi w awanturze o Mołdawię? [OPINIA]
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8668501,moldawia-awantura-o-co-chodzi-rosja.html](https://forsal.pl/swiat/aktualnosci/artykuly/8668501,moldawia-awantura-o-co-chodzi-rosja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 09:35:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pXsktkuTURBXy9kOWRlMjhkZC1jOTMzLTQ3MGYtOWUwMS0yMDlhYTM3MThhYWIuanBlZ5GTBc0BHcyg" />Mołdawscy politycy mówią o ryzyku prorosyjskiego zamachu stanu czy nawet desantu na stołeczne lotnisko. W trwającym od kilku tygodni szumie wokół Mołdawii jest trochę przesady, ale i szczypta trafnej konstatacji: cele Kremla są stałe i obejmują zainstalowanie w Kiszyniowie prorosyjskiego rządu – zgodnie z wolą Mołdawian albo i wbrew niej.

## Wzrost polskiego PKB zwalnia. Kuleje konsumpcja prywatna
 - [https://forsal.pl/gospodarka/pkb/artykuly/8669243,pkb-polski-iv-kwartal-2022.html](https://forsal.pl/gospodarka/pkb/artykuly/8669243,pkb-polski-iv-kwartal-2022.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 09:11:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zKKktkuTURBXy8wM2I4NjcxNi03YzFkLTRiNmUtOTVhYS1mOTdjNjI1Y2ZkZTYuanBlZ5GTBc0BHcyg" />Produkt Krajowy Brutto Polski w IV kw. 2022 r. wzrósł o 2,0 proc. rdr w porównaniu ze wzrostem o 3,6 proc. rdr w III kw. 2022 r. - wynika z komunikatu GUS. Odczyt jest zgodny z wcześniejszym szacunkiem flash GUS.

## Akcjonariusze Intersportu zdecydują 20 kwietnia o emisji do 55,3 mln akcji serii I
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669207,akcjonariusze-intersportu-zdecyduja-20-kwietnia-o-emisji-do-553-mln-akcji-serii-i.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669207,akcjonariusze-intersportu-zdecyduja-20-kwietnia-o-emisji-do-553-mln-akcji-serii-i.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:57:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/H_HktkuTURBXy8zNGY0NjIxMi03OWVlLTQ0MDQtODFkZi1hODBlZjhiYjQ0ZDAuanBlZ5GTBc0BHcyg" />undefined

## Apator miał 12,58 mln zł zysku netto, 31,61 mln zł zysku EBITDA w IV kw. 2022 r.
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669143,apator-wyniki-finansowe-zysku-netto-ebitda-w-4-kw-2022-r.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669143,apator-wyniki-finansowe-zysku-netto-ebitda-w-4-kw-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:48:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EhBktkuTURBXy83NmQxNDRiYi05ZTE3LTQyMjQtYjllMS1kNjEzM2Q2ZmZiZmEuanBlZ5GTBc0BHcyg" />undefined

## Rosja jeszcze słabsza w powietrzu? Utrata tego samolotu byłaby dużą stratą
 - [https://forsal.pl/swiat/rosja/artykuly/8669138,utrata-samolotu-wczesnego-ostrzegania-a-50-rosja.html](https://forsal.pl/swiat/rosja/artykuly/8669138,utrata-samolotu-wczesnego-ostrzegania-a-50-rosja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:46:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WCsktkuTURBXy9jMWU3ZGZmMy1iMmI0LTRiYzQtODkzMi0yNDg4MTVkOTQyNDkuanBlZ5GTBc0BHcyg" />Utrata samolotu wczesnego ostrzegania A-50, który został uszkodzony w bazie na Białorusi, byłaby dla Rosji znaczącą stratą, bo pozostanie jej zapewne sześć sprawnych A-50, co jeszcze bardziej ograniczy jej operacje powietrzne - przekazało we wtorek brytyjskie ministerstwo obrony.

## Allegro skupiło w buy-backu 725 tys. akcji za kwotę 20,06 mln zł
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669136,allegro-skupilo-w-buy-backu-725-tys-akcji-za-kwote-2006-mln-zl.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669136,allegro-skupilo-w-buy-backu-725-tys-akcji-za-kwote-2006-mln-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:46:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/avkktkuTURBXy9iZDQ4ZWU4Yy02MTY0LTRlYmItYjFmZS05NzRiMzc5ZGExMmQuanBlZ5GTBc0BHcyg" />undefined

## Akcjonariusze Esotiq &amp; Henderson upoważnili zarząd do buy-backu do 20 proc. akcji za 20 mln zł
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669130,akcjonariusze-esotiq--henderson-upowaznili-zarzad-do-buy-backu-do-20-proc-akcji-za-20-mln-zl.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669130,akcjonariusze-esotiq--henderson-upowaznili-zarzad-do-buy-backu-do-20-proc-akcji-za-20-mln-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:44:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fhiktkuTURBXy9kNzM5MjRmZi00MGMyLTQ2ODUtOWI3YS0wNzg5ODIwMzZiMzUuanBlZ5GTBc0BHcyg" />undefined

## Portfel zamówień Budimexu wynosił 13,29 mld zł na koniec 2022 r.
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669123,portfel-zamowien-budimexu-wynosil-1329-mld-zl-na-koniec-2022-r.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669123,portfel-zamowien-budimexu-wynosil-1329-mld-zl-na-koniec-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:40:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Z1ZktkuTURBXy80YTE5NGU4Yy0zN2VmLTRkYjUtODQ2Yi0wZjNlN2Q4YzI5ODMuanBlZ5GTBc0BHcyg" />undefined

## Budimex miał wstępnie 548,13 mln zł zysku netto w 2022 r.
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669121,budimex-wstepne-wyniki-finansowe-zysku-netto-w-2022-r.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669121,budimex-wstepne-wyniki-finansowe-zysku-netto-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:38:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/flgktkuTURBXy83ZjJkMTMzYS02NDQ1LTQyNGMtYTM0YS04ZWMwYjdhNTFjODguanBlZ5GTBc0BHcyg" />undefined

## Creepy Jar chce rekomendować min. 50 proc. zysku netto za 2022 r. na dywidendę
 - [https://forsal.pl/biznes/artykuly/8669117,creepy-jar-chce-rekomendowac-min-50-proc-zysku-netto-za-2022-r-na-dywidende.html](https://forsal.pl/biznes/artykuly/8669117,creepy-jar-chce-rekomendowac-min-50-proc-zysku-netto-za-2022-r-na-dywidende.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:35:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Xh_ktkuTURBXy8zNjY5ODllOS1lMTVlLTQ5MTMtYjNmZS05MWE0MWYyZmZiOGQuanBlZ5GTBc0BHcyg" />undefined

## Import produktów ropopochodnych zwiększają gracze z Bliskiego Wschodu
 - [https://forsal.pl/biznes/energetyka/artykuly/8668537,produkty-ropopochodne-arabowie-europa.html](https://forsal.pl/biznes/energetyka/artykuly/8668537,produkty-ropopochodne-arabowie-europa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:29:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7OwktkuTURBXy8wZTMwNWYxNS02MTVjLTRkYjYtYjFjNS1jYmQ5NWFhMzBkMDYuanBlZ5GTBc0BHcyg" />Państwa Zachodu rezygnują z rosyjskich produktów ropopochodnych. Import zwiększają za to gracze z Bliskiego Wschodu.

## Mostostal Zabrze miał wstępnie 9,4 mln zł zysku netto, 20,2 mln zł zysku EBIT w IV kw.
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669115,mostostal-zabrze-mial-wstepnie-94-mln-zl-zysku-netto-202-mln-zl-zysku-ebit-w-iv-kw.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669115,mostostal-zabrze-mial-wstepnie-94-mln-zl-zysku-netto-202-mln-zl-zysku-ebit-w-iv-kw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:28:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />undefined

## Creepy Jar miał wstępnie 36,5 mln zł zysku netto w 2022 r.
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8669113,creepy-jar-mial-wstepnie-365-mln-zl-zysku-netto-w-2022-r.html](https://forsal.pl/biznes/aktualnosci/artykuly/8669113,creepy-jar-mial-wstepnie-365-mln-zl-zysku-netto-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:26:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DY5ktkuTURBXy84NDBhOTYwNS00ZjY1LTRlNzMtOGQ0NS0xODQ0OTQ3MDdmNTYuanBlZ5GTBc0BHcyg" />undefined

## Rodzinna darowizna nie musi wyjść z bankowego konta
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8668467,darowizna-rodzina-konto-bankowe.html](https://forsal.pl/finanse/aktualnosci/artykuly/8668467,darowizna-rodzina-konto-bankowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:22:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AycktkuTURBXy81ODBhMTkzYi01OGZhLTQ4ZjEtOTIzYi02M2U2MmY0ODc4M2IuanBlZ5GTBc0BHcyg" />Obdarowany, który otrzyma gotówkę od najbliższej rodziny, a następnie wpłaci ją na swój rachunek bankowy, ma prawo do zwolnienia z podatku od spadków i darowizn – orzekł Wojewódzki Sąd Administracyjny w Poznaniu.

## Europejskie obligacje tanieją. Koszty finansowania rosną
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8668509,obligacje-koszty-finansowania.html](https://forsal.pl/finanse/aktualnosci/artykuly/8668509,obligacje-koszty-finansowania.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:15:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yhWktkuTURBXy85YjExNzVlMy0wYzZhLTRlNzAtYjk0Mi1lM2UxNzMzMjM4OGQuanBlZ5GTBc0BHcyg" />Przecena rządowych papierów to problem dla wielu państw ponoszących duże wydatki na zwalczanie skutków kryzysu energetycznego.

## Prokuratura coraz skuteczniejsza w walce z oszustwami w VAT
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8668459,oszustwa-vat.html](https://forsal.pl/finanse/aktualnosci/artykuly/8668459,oszustwa-vat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 08:03:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IKIktkuTURBXy81Njk0YjAxYi1lNzk4LTRlOGQtOWFhZS04MDc5YzJmYWQwZjkuanBlZ5GTBc0BHcyg" />W 2022 r. prokuratorzy w całym kraju prowadzili trzykrotnie więcej spraw o tzw. zbrodnie VAT-owskie niż rok wcześniej. W tym zakresie wnieśli do sądów 404 akty oskarżenia, czyli o połowę więcej niż w 2021 r.

## ChatGPT i konkurencja? "Musk rekrutuje zespół" do opracowania alternatywy
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8668953,chatgpt-elon-musk-rywal-alternatywa.html](https://forsal.pl/biznes/aktualnosci/artykuly/8668953,chatgpt-elon-musk-rywal-alternatywa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:59:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QmVktkuTURBXy8wNWI3NDkxYS01MGI0LTRhZDQtYWFmNS1kMGRlODA0YWFkNDguanBlZ5GTBc0BHcyg" />Elon Musk zwrócił się w ostatnich tygodniach do specjalistów od sztucznej inteligencji w sprawie utworzenia nowego laboratorium badawczego w celu opracowania alternatywy dla ChatGPT - podał we wtorek Reuters, cytując portal branży technologicznej &quot;The Information&quot;.

## Jaki odsetek Polaków systematycznie oszczędza?
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8669026,jaki-odsetek-polakow-systematycznie-oszczedza.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8669026,jaki-odsetek-polakow-systematycznie-oszczedza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:58:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/asNktkuTURBXy9kMDA0ZWYzYS1mMTBjLTQyNWYtYjlkYS1hOWJkYzUwNjk0N2UuanBlZ5GTBc0BHcyg" />Systematycznie oszczędza 38 proc. ankietowanych Polaków - wynika z badania „Polaków Portfel Własny: czas oszczędzania”. Powyżej 5 miesięcznych wynagrodzeń zgromadziło 28 proc. tych, którzy budują poduszkę finansową - dodano.

## Ceny biletów PKP Intercity wracają od 1 marca do poziomu sprzed podwyżki
 - [https://forsal.pl/transport/kolej/artykuly/8669021,kiedy-obnizki-cen-biletow-pkp-intercity.html](https://forsal.pl/transport/kolej/artykuly/8669021,kiedy-obnizki-cen-biletow-pkp-intercity.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:53:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0ZVktkuTURBXy8wMTc2MDcwZC1iNWI5LTQxMTQtOGIyNC1mMzYyNTQ5N2Q5NzMuanBlZ5GTBc0BHcyg" />Od środy, 1 marca br. ceny biletów w PKP Intercity spadną do poziomów sprzed podwyżki wprowadzonej 11 stycznia tego roku. Ceny bazowe na połączenia kategorii TLK i IC będą średnio o około 11 proc. niższe, zaś dla kategorii EIC i EIP – średnio o około 15 proc.

## Bezsenność ma związek z wyższym ryzykiem zawału serca [BADANIE]
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8669020,bezsennosc-zawal-serca.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8669020,bezsennosc-zawal-serca.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:53:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RYUktkuTURBXy81ZjQxY2YwYi1lMjEyLTQxNjItYWEyOC0xYjUzNjAzNWFlZmQuanBlZ5GTBc0BHcyg" />Osoby cierpiące na bezsenność są o 69 proc. bardziej narażone na zawał serca – wynika z badań, których wyniki zostaną ogłoszone podczas Światowego Kongresu Kardiologii w Nowym Orleanie (4-6 marca). Związek ten obserwuje się częściej zwłaszcza u kobiet.

## Muszą usunąć TikToka z urządzeń federalnych. Biały Dom daje 30 dni  agencjom rządowym
 - [https://forsal.pl/biznes/media/artykuly/8669014,tiktok-usa-agencje-rzadowe-bialy-dom.html](https://forsal.pl/biznes/media/artykuly/8669014,tiktok-usa-agencje-rzadowe-bialy-dom.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:48:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9LzktkuTURBXy83NjFkYmYwYi05NDVmLTQwZTMtOTNkMy1jNDVkNGI2MmRmYTYuanBlZ5GTBc0BHcyg" />Biały Dom nakazał w poniedziałek agencjom rządowym wyeliminowanie w ciągu 30 dni chińskiej aplikacji Tik Tok z federalnych urządzeń i systemów. Zaprotestował przeciw temu Amerykański Związek Swobód Obywatelskich (ACLU).

## ISW: Ukraińskie wojska mogą przeprowadzić kontrofensywę w obwodzie zaporoskim
 - [https://forsal.pl/swiat/ukraina/artykuly/8669000,isw-ukrainskie-wojska-moga-przeprowadzic-kontrofensywe-w-obwodzie-zaporoskim.html](https://forsal.pl/swiat/ukraina/artykuly/8669000,isw-ukrainskie-wojska-moga-przeprowadzic-kontrofensywe-w-obwodzie-zaporoskim.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:46:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1nkktkuTURBXy84MmU3ZDVhZi0wMDkyLTQ2YTItYmU0Ni1kZjU3N2RhNjZlYTguanBlZ5GTBc0BHcyg" />Wiosną ukraińskie wojska mogą przeprowadzić kontrofensywę w obwodzie zaporoskim, przecinając rosyjską linię frontu na południu Ukrainy i pozbawiając siły wroga na okupowanym Krymie lądowego połączenia z terytorium Rosji - podał w najnowszym raporcie amerykański Instytut Studiów nad Wojną (ISW).

## Wyraźny trend spadkowy na rynku ropy. Czwarty kolejny miesiąc obniżek cen
 - [https://forsal.pl/biznes/energetyka/artykuly/8668954,ropa-naftowa-ceny.html](https://forsal.pl/biznes/energetyka/artykuly/8668954,ropa-naftowa-ceny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:42:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/S-nktkuTURBXy8zZjNmN2Q2Yy1kMjY2LTRlZmEtOGZlNi1iMDEyMjg5YjE1YWYuanBlZ5GTBc0BHcyg" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną w trakcie wtorkowej sesji, ale surowiec w ujęciu miesięcznym zalicza już 4. z kolei miesiąc ze zniżką notowań - podają maklerzy.

## Japonia nałożyła sankcje na kolejne 143 podmioty związane z rosyjską inwazją na Ukrainę
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8668948,japonia-kolejne-sankcje-na-rosje.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8668948,japonia-kolejne-sankcje-na-rosje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:39:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GQgktkuTURBXy85YTY1NGI2Ni1jMmViLTQxM2ItOTQxMS0zYmU2ZmQzMzZhZTEuanBlZ5GTBc0BHcyg" />Rząd Japonii ogłosił we wtorek dopisanie 143 osób i instytucji do listy podmiotów objętych sankcjami za inwazję Rosji na Ukrainę. Są wśród nich rosyjscy politycy, wojskowi, biznesmeni, instytuty badawcze i firmy, w tym Grupa Wagnera i Rosbank.

## Niedobory żywności w Korei Płn. Kim Dzong Un wezwał do "fundamentalnej transformacji" rolnictwa
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8668937,niedobory-zywnosci-korea-polnocna.html](https://forsal.pl/swiat/aktualnosci/artykuly/8668937,niedobory-zywnosci-korea-polnocna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:31:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Hr-ktkuTURBXy9jNjgwOTU1ZC1kYjNhLTRiNjctOWI4Mi1lZTIwNjk2NzMzZWYuanBlZ5GTBc0BHcyg" />Przywódca Korei Północnej wezwał do &quot;fundamentalnej transformacji&quot; w produkcji rolnej - podały we wtorek państwowe media, które cytuje Reuters. Krok ten podyktowany jest pogłębiającym się w kraju niedoborem żywności.

## Musk i Tesla pozwani przez akcjonariuszy. Jaki jest powód?
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8668920,musk-tesla-bezpieczenstwo-pojazdow-samokierujacych.html](https://forsal.pl/biznes/aktualnosci/artykuly/8668920,musk-tesla-bezpieczenstwo-pojazdow-samokierujacych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:23:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tqgktkuTURBXy8xYjMzMzEyYi00NGY4LTRkMDAtYThkNC1iNzZiYjVhYmMxOWQuanBlZ5GTBc0BHcyg" />Tesla i jej szef Elon Musk zostali w poniedziałek pozwani przez akcjonariuszy, którzy oskarżyli spółkę i Muska o przecenianie skuteczności i bezpieczeństwa technologii Autopilot i Full Self-Driving swoich pojazdów elektrycznych.

## Sunak: Porozumienie z UE ws. protokołu spełnia nasze oczekiwania
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8668887,wielka-brytania-porozumienie-unia-europejska.html](https://forsal.pl/swiat/unia-europejska/artykuly/8668887,wielka-brytania-porozumienie-unia-europejska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:14:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PHrktkuTURBXy9iOTk3MjU3NC1mY2E1LTQ2MWQtYTk2YS1mZWFiZjhiNzE3MGYuanBlZ5GTBc0BHcyg" />Brytyjski premier Rishi Sunak oświadczył w poniedziałek, że porozumienie z Unią Europejską w sprawie zmian w protokole północnoirlandzkim spełnia oczekiwania brytyjskiego rządu i wobec tego wycofany zostaje projekt ustawy pozwalający jednostronnie zawiesić niektóre jego zapisy.

## Rekordowa waloryzacja świadczeń wypłacanych z ZUS
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8668418,waloryzacja-emerytury-renty.html](https://forsal.pl/finanse/aktualnosci/artykuly/8668418,waloryzacja-emerytury-renty.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 07:02:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/I2iktkuTURBXy85MTE1YmI4NS01ZGVlLTQ2OGUtYWI1YS02MjUzOWRmNWI4MDEuanBlZ5GTBc0BHcyg" />Od 1 marca ponad 10 mln Polek i Polaków dostanie najwyższą od 27 lat podwyżkę świadczeń. Skorzystają nie tylko emeryci i renciści, lecz także m.in. osoby pobierające renty rodzinne i socjalne oraz świadczenia kompensacyjne.

## Bijemy rekordy w wydatkach na uzbrojenie. Polska wyda na obronność ok. 4 proc. PKB
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8668533,uzbrojenie-wojsko-polska-wydatki.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8668533,uzbrojenie-wojsko-polska-wydatki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 06:56:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NzHktkuTURBXy9hMjdmZmFjOS1hMjRlLTQxOTUtYTZmOS0xZTlmZTA5ZmFiYjYuanBlZ5GTBc0BHcyg" />W ubiegłym roku środki przeznaczone na nowe uzbrojenie były ponad dwa razy wyższe niż rok wcześniej. W 2023 r. Polska wyda na obronność ok. 4 proc. PKB, co stawia nas w czołówce NATO.

## Jedność i solidarność w UE to piękne slogany [OPINIA]
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8668497,unia-europejska-wojna-ukraina-polska.html](https://forsal.pl/swiat/unia-europejska/artykuly/8668497,unia-europejska-wojna-ukraina-polska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 06:49:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/e5_ktkuTURBXy8yZWU1MDQ4ZC02NTljLTRkNDMtYmU0Mi1lZTM5NjllYzg2ZWMuanBlZ5GTBc0BHcyg" />Kiedy zbliżała się pierwsza rocznica rosyjskiej inwazji na Ukrainę, w Polsce wszyscy żyli przyjazdem Joego Bidena i wypatrywali odpowiedzi Kremla na odważny krok amerykańskiego przywódcy. Tymczasem Unia Europejska przygotowywała 10. pakiet sankcji, który miał być nie tylko bolesny dla rosyjskiej gospodarki w dłuższym terminie, ale przede wszystkim miał świadczyć o jedności całego bloku i solidarności wobec Ukrainy. Wówczas pisałem, że UE na rocznicę inwazji przygotuje „tylko sankcje”. Z dzisiejszej perspektywy powinienem był wówczas napisać „aż sankcje”.

## Sankcje nie działają? "Przychody z eksportu paliw wciąż pomagają Kremlowi"
 - [https://forsal.pl/swiat/rosja/artykuly/8668541,rosja-sankcje-eksport-paliw.html](https://forsal.pl/swiat/rosja/artykuly/8668541,rosja-sankcje-eksport-paliw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 06:44:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ORXktkuTURBXy9hYzU0MjQ4Ni03OGFkLTQwYWMtYWM4Zi02NmZhMTYwNTA4NzguanBlZ5GTBc0BHcyg" />Rok po rozpoczęciu pełnoskalowej inwazji na Ukrainę przychody z eksportu paliw wciąż pomagają Kremlowi finansować wojnę.

## Śledztwo w chińskich kopalniach litu. To może zatrząść światowym rynkiem
 - [https://forsal.pl/gospodarka/artykuly/8668207,ceny-litu-zatrzymanie-produkcji-chiny-sledztwo.html](https://forsal.pl/gospodarka/artykuly/8668207,ceny-litu-zatrzymanie-produkcji-chiny-sledztwo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 05:30:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ab6ktkuTURBXy8yMTJkNDBiMi01OTQyLTQ2ODktOTk5Mi0yNjQwNDY4ZDYwMWQuanBlZ5GTBc0BHcyg" />Chiński przemysł litowy zaczyna się chwiać. Jego główny ośrodek produkcyjny, odpowiedzialny za około jedną dziesiątą światowej podaży, stoi w obliczu ryzyka poważnych przestojów związku z rządowym dochodzeniem w sprawie negatywnego wpływu na środowisko.

## Rynek surowców. Pięć kluczowych wykresów, które warto śledzić
 - [https://forsal.pl/gospodarka/galeria/8668174,rynek-surowcow-olej-napedowy-zywnosc-gaz.html](https://forsal.pl/gospodarka/galeria/8668174,rynek-surowcow-olej-napedowy-zywnosc-gaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 05:30:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WGSktkuTURBXy85ZDJmNGMzYS1lNDc2LTQ4YmEtOTUwYS02OTc2OTIyZDIwMmMuanBlZ5GTBc0BHcyg" />Oto kilka wykresów z rynku towarowego, które warto monitorować.

## Marihuana – czy codzienne stosowanie jest szkodliwe? [BADANIE]
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8667405,marihuana-czy-stosowanie-jest-szkodliwe-konopie-indyjskie.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8667405,marihuana-czy-stosowanie-jest-szkodliwe-konopie-indyjskie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 05:30:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/APPktkuTURBXy8xNzE5OTdiOS1jZjJmLTRhYTUtYmY2My04NDFiMTYzZjI3NjcuanBlZ5GTBc0BHcyg" />Codzienne stosowanie marihuany zwiększa ryzyko chorób serca – wynika z najnowszego badania amerykańskich naukowców, o którym informuje Bloomberg.

## 5 oznak, że wychowałeś „małego tyrana” i jak zmienić go w „dziecko idealne”
 - [https://forsal.pl/lifestyle/psychologia/artykuly/8666842,wychowales-malego-tyrana-zmien-go-w-dziecko-idealne.html](https://forsal.pl/lifestyle/psychologia/artykuly/8666842,wychowales-malego-tyrana-zmien-go-w-dziecko-idealne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 05:30:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fNLktkuTURBXy9jN2E4MGNhOS1kODU2LTQ2NjItYmY5NC04NmViOGNhNGJlZDIuanBlZ5GTBc0BHcyg" />Wielu rodziców ma problem ze stawianiem swoim dzieciom granic, bo nie lubią patrzeć, jak ich dzieci są nieszczęśliwe. Najzwyczajniej w świecie ustąpienie potomkowi czasem wydaje się o wiele łatwiejsze niż odmowa, pisze Michele Borba w artykule dla cnbc.com.

## IKEA będzie eliminować nabiał w swoich punktach sprzedaży. Cel? Klimatyczny
 - [https://forsal.pl/biznes/ekologia/artykuly/8667424,ikea-eliminacja-nabialu.html](https://forsal.pl/biznes/ekologia/artykuly/8667424,ikea-eliminacja-nabialu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 05:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NPOktkuTURBXy82YmE2ZDdmNS1hMDg5LTRiZjktYTYwNi1iOTk2MTQ2MjRjNDIuanBlZ5GTBc0BHcyg" />Jak pisze Polly Foreman dla portalu „Plant Based News”, sieć sklepów IKEA opublikowała niedawno swój „Sustainability Report FY 2022”. Wyznaczyła w nim cele z zakresu polityki klimatycznej w pięciu obszarach: woda, energia, powietrze, odpady oraz żywność. Zmiany w ostatnim z nich będą polegać na stopniowym odchodzeniu od produktów pochodzenia zwierzęcego.

## Pomoc wojskowa USA dla Ukrainy przekroczyła koszty wojny w Afganistanie
 - [https://forsal.pl/swiat/usa/artykuly/8667301,pomoc-wojskowa-usa-dla-ukrainy-koszt-wojny-w-afganistanie.html](https://forsal.pl/swiat/usa/artykuly/8667301,pomoc-wojskowa-usa-dla-ukrainy-koszt-wojny-w-afganistanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 05:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Di5ktkuTURBXy9lYmUzN2ViNS1hMmY3LTQ0MTEtOWU2Ni1lODM3MDg2MmI4MDUuanBlZ5GTBc0BHcyg" />Największą pomoc wojskową Ukraina otrzymuje od Stanów Zjednoczonych. Od początku wojny do 15 stycznia 2023 r. do kraju będącego w stanie wojny z Rosją napłynęło 46,6 mld USD pomocy finansowej na cele wojskowe. To więcej niż USA wydały na wojnę w Afganistanie.

## Wojna chipowa wchodzi w decydującą fazę. To musisz wiedzieć o wielkiej rozgrywce
 - [https://forsal.pl/swiat/artykuly/8667355,wojna-chipowa-usa-chiny.html](https://forsal.pl/swiat/artykuly/8667355,wojna-chipowa-usa-chiny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-28 05:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PCZktkuTURBXy9iODcyNjRlNC1lN2UwLTQ3ZjAtYmQwZS1iNjQ3MDBlMjdhNDcuanBlZ5GTBc0BHcyg" />Pandemia i geopolityczne wstrząsy z ostatnich lat zakończyły pewną gospodarczą erę. Doszło do załamania się globalnej struktury łańcuchów dostaw. Obserwujemy technologiczną wojnę, która wyłoni nowy porządek oparty o gospodarcze bloki. Sercem trwającej rywalizacji są półprzewodniki.

