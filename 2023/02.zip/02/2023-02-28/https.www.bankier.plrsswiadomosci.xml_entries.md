# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Lutowa korekta na Wall Street. Wtorek nieznacznie pod kreską
 - [https://www.bankier.pl/wiadomosc/Lutowa-korekta-na-Wall-Street-Wtorek-nieznacznie-pod-kreska-8497589.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lutowa-korekta-na-Wall-Street-Wtorek-nieznacznie-pod-kreska-8497589.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/a6421912c820ee-948-568-185-190-1815-1088.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po styczniowej mini-euforii luty przyniósł schłodzenie
nastrojów na Wall Street. Główne nowojorskie indeksy zakończyły miesiąc pod
kreską</p>

## Iran zwiększał swoje zapasy wzbogaconego uranu w ostatnich miesiącach
 - [https://www.bankier.pl/wiadomosc/Iran-zwiekszal-swoje-zapasy-wzbogaconego-uranu-w-ostatnich-miesiacach-8497540.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Iran-zwiekszal-swoje-zapasy-wzbogaconego-uranu-w-ostatnich-miesiacach-8497540.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 18:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/7449baa65d36e2-945-567-0-105-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Iran na drodze do broni atomowej. Międzynarodowa Agencja Energii Atomowej (MAEA) alarmuje: w ostatnich miesiącach Iran wciąż zwiększał swoje zapasy wzbogaconego uranu.</p>

## Wybuchu granatnika w KGP.  "Wiele pytań pozostaje odpowiedzi"
 - [https://www.bankier.pl/wiadomosc/Wybuchu-granatnika-w-KGP-Wiele-pytan-pozostaje-odpowiedzi-8497509.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wybuchu-granatnika-w-KGP-Wiele-pytan-pozostaje-odpowiedzi-8497509.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 17:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/1aa2c057b59e01-948-568-7-44-2992-1795.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trzy godziny obrad i nic? Na to wygląda. Tajemnica śledztwa spowodowała, że komisja powołana do wyjaśnienia okoliczności wybuchu granatnika w KGP nie zyskała odpowiedzi na wiele pytań</p>

## Niemcy planują zakazać instalowania systemów ogrzewania gazowego i olejowego
 - [https://www.bankier.pl/wiadomosc/Niemcy-planuja-zakazac-instalowania-systemow-ogrzewania-gazowego-i-olejowego-8497508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemcy-planuja-zakazac-instalowania-systemow-ogrzewania-gazowego-i-olejowego-8497508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 17:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/0/f2bcd8f9e11fcd-948-568-0-27-3600-2159.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już od 2024 roku w Niemczech pracę mogą stracić instalatorzy gazowego i olejowego ogrzewania. Jak donosi "Bild", może zostać wprowadzony zakaz ich montowania. Podobno została już przygotowana odpowiednia ustawa. </p>

## Orlen napędził wzrosty na GPW. WIG20 najlepszy w Europie
 - [https://www.bankier.pl/wiadomosc/Orlen-napedzil-wzrosty-na-GPW-WIG20-najlepszy-w-Europie-8497462.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orlen-napedzil-wzrosty-na-GPW-WIG20-najlepszy-w-Europie-8497462.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 16:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/4/a42ca6f1319839-945-560-7-78-1492-895.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tak jak się spodziewano największy wpływ na przebieg wtorkowej sesji na WIG20 i szerokim rynku miała prezentacja strategii PKN Orlen. Reakcja inwestorów w szczególności na jasno określoną politykę dywidendową podbiła wyraźnie kurs spółki przy największych obrotach na rynku. Pomógł także sektor bankowy, który wzrósł czwartą sesję z rzędu.</p>

## Tysiące demonstrantów na ulicach. Protesty prorosyjskiej opozycji w Mołdawii
 - [https://www.bankier.pl/wiadomosc/Tysiace-demonstrantow-na-ulicach-Protesty-prorosyjskiej-opozycji-w-Moldawii-8497456.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tysiace-demonstrantow-na-ulicach-Protesty-prorosyjskiej-opozycji-w-Moldawii-8497456.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 16:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/7/be4d6043253a14-948-568-0-60-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mołdawia mierzy się z antyrządowymi demonstracjami wspieranymi przez prorosyjską opozycję. tysiące demonstrantów w stolicy żądało dopłat do rachunków za energię za okres zimowy oraz "nieangażowania kraju w wojnę". Interweniowała policja.</p>

## Pożegnanie stacji Lotosu. Orlen zakończył rebranding
 - [https://www.bankier.pl/wiadomosc/Pozegnanie-stacji-Lotosu-Orlen-zakonczyl-rebranding-8497431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pozegnanie-stacji-Lotosu-Orlen-zakonczyl-rebranding-8497431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 16:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/21b8d8a5c50284-945-560-261-24-2951-1770.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stacje Lotosu, które Orlen przejął w ramach fuzji, noszą już logo orła. Koncern podał, że zakończył ich rebranding. Podobnie z programem Navigator, który został zastąpiony przez Vitay. Orlen pracuje także nad nową aplikacją dla klientów. </p>

## Prokuratura żąda aresztu dla byłego ministra Skarbu Państwa Włodzimierza Karpińskiego
 - [https://www.bankier.pl/wiadomosc/Prokuratura-zada-aresztu-dla-bylego-ministra-Skarbu-Panstwa-Karpinskiego-8497421.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prokuratura-zada-aresztu-dla-bylego-ministra-Skarbu-Panstwa-Karpinskiego-8497421.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 16:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/ebad52cbc6f0b3-948-568-2025-123-2343-1406.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prokuratura Krajowa wnioskuje o areszt dla byłego ministra Skarbu Państwa Włodzimierza Karpińskiego, który w poniedziałek został zatrzymany przez CBA. Po przesłuchaniu postawiono mu zarzut żądania i przyjęcia korzyści majątkowej. </p>

## Kolejowa "zakopianka" ponownie zamknięta. Pociągi nie dojadą pod Tatry
 - [https://www.bankier.pl/wiadomosc/Kolejowa-zakopianka-ponownie-zamknieta-Pociagi-nie-dojada-pod-Tatry-8497417.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejowa-zakopianka-ponownie-zamknieta-Pociagi-nie-dojada-pod-Tatry-8497417.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 15:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/c/e6b61831248a61-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />1 marca, po zimowej przerwie, ruszają kolejne prace na linii kolejowej Sucha Beskidzka – Chabówka - Zakopane. Przerwa w ruchu pociągów pod Tatry potrwa do 21 czerwca. W tym czasie zostanie m.in. zmodernizowana stacja Szaflary, a w Poroninie powstanie podziemne przejście pomiędzy peronami.</p>

## Tytuł najbogatszego człowieka świata zmienia właściciela. Bloomberg ogłasza przetasowania na liście
 - [https://www.bankier.pl/wiadomosc/Tytul-najbogatszego-czlowieka-swiata-zmienia-wlasciciela-Bloomberg-oglasza-przetasowania-na-liscie-8497412.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tytul-najbogatszego-czlowieka-swiata-zmienia-wlasciciela-Bloomberg-oglasza-przetasowania-na-liscie-8497412.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 15:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/0/37b77e9a6aefd2-948-568-30-61-4073-2443.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Żółtą koszulkę lidera najbogatszych ludzi świata stracił szef Louis Vuitton Moët Hennessy. Wróciła ona do kontrowersyjnego prezesa Twittera i Tesli Elona Muska - informuje agencja Bloomberg. Tytuł ten stracił w grudniu ubiegłego roku.</p>

## Nie musisz wyjmować zakupów z kosza. K-Scan zawita do kolejnych miast
 - [https://www.bankier.pl/wiadomosc/K-Scan-zawita-do-kolejnych-miast-Kaufland-zadowolony-z-testow-8496919.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/K-Scan-zawita-do-kolejnych-miast-Kaufland-zadowolony-z-testow-8496919.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 15:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/2/9eb774257c2fe7-948-568-0-0-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po zadowalających wynikach pilotażu Kaufland zamierza jeszcze intensywniej rozwijać usługę samodzielnego skanowania produktów. Urządzenia K-Scan pojawią się wkrótce w blisko 30 nowych lokalizacjach. W tym roku takich sklepów ma być docelowo 60. </p>

## Finlandia nie czeka na Turcję i Węgry. Parlament debatuje nad ratyfikacją członkostwa w NATO
 - [https://www.bankier.pl/wiadomosc/Finlandia-nie-czeka-na-Turcje-i-Wegry-Parlament-debatuje-nad-ratyfikacja-czlonkostwa-w-NATO-8497392.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Finlandia-nie-czeka-na-Turcje-i-Wegry-Parlament-debatuje-nad-ratyfikacja-czlonkostwa-w-NATO-8497392.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 15:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/d/3a1a5f61cc3935-948-568-0-62-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Parlament Finlandii rozpoczął ostateczne czytanie projektu ustawy o ratyfikacji Traktatu Północnoatlantyckiego, mimo iż protokoły akcesyjne nie zostały jeszcze ratyfikowane przez wszystkich członków NATO (Turcja i Węgry zwlekają). </p>

## Nie ruszą wieku emerytalnego. Donald Tusk o obietnicach PO
 - [https://www.bankier.pl/wiadomosc/Nie-rusza-wieku-emerytalnego-Donald-Tusk-o-obietnicach-PO-8497384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-rusza-wieku-emerytalnego-Donald-Tusk-o-obietnicach-PO-8497384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 15:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/0da3d9edd549fb-948-568-0-53-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Donald Tusk zapowiedział, że zrezygnował z jednego z założeń, z którymi partia startowała 10 lat temu, w więc podniesieniem wieku emerytalnego. Jego zdaniem to jeden z powodów porażki w poprzednich wyborach. </p>

## Kwiaty z Holandii w rosyjskich kwiaciarniach. „Eksporterzy nie mają oporów moralnych”
 - [https://www.bankier.pl/wiadomosc/Kwiaty-z-Holandii-w-rosyjskich-kwiaciarniach-Eksporterzy-nie-maja-oporow-moralnych-8497373.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kwiaty-z-Holandii-w-rosyjskich-kwiaciarniach-Eksporterzy-nie-maja-oporow-moralnych-8497373.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 15:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/5c49bf699d91cf-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie tylko słynne na całym świecie tulipany, ale i chryzantemy z holenderskich plantacji są sprzedawane w rosyjskich kwiaciarniach. Sprzedaż kwiatów nie podlega sankcjom. Jak komentuje portal NU, najwyraźniej eksporterzy nie mają oporów moralnych. </p>

## "Chcemy iść zgodnie z rynkami". Orlen obniży ceny gazu dla biznesu
 - [https://www.bankier.pl/wiadomosc/Grupa-Orlen-od-15-III-obnizy-ceny-gazu-dla-biznesu-o-ponad-50-proc-opis-8497329.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Grupa-Orlen-od-15-III-obnizy-ceny-gazu-dla-biznesu-o-ponad-50-proc-opis-8497329.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 14:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/6f8bea84db8ac9-948-568-167-4-1679-1007.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />O 50 proc. grupa Orlen obniży ceny dla klientów biznesowych, którzy są rozliczani według cenników. Od kwietnia ceny mają odzwierciedlać notowania na europejskich giełdach - zapowiedział prezes Orlenu Daniel Obajtek. Potwierdził to PGNiG z Grupy Orlen. </p>

## Pakt senacki opozycji. Wspólnie wystartują w wyborach
 - [https://www.bankier.pl/wiadomosc/Pakt-senacki-opozycji-Wspolnie-wystartuja-w-wyborach-8497318.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pakt-senacki-opozycji-Wspolnie-wystartuja-w-wyborach-8497318.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 14:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/4/72bcce31124b94-948-568-10-286-4078-2447.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pakt senacki 2.0. Pierwszy się sprawdził, więc przed kolejnymi wyborami parlamentarnymi, które odbędą się w tym roku, liderzy partii opozycyjnych znów zwierają szyki. - Przygotowujemy pakt senacki. W tę sprawę angażuje się ponownie samorząd - ogłosił senator KO Zygmunt Frankiewicz.</p>

## 1000 Borsuków wjedzie do polskiej armii. Kolejny kontrakt MON
 - [https://www.bankier.pl/wiadomosc/1000-borsukow-wjedzie-do-polskiej-armii-Kolejny-kontrakt-MON-8497272.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/1000-borsukow-wjedzie-do-polskiej-armii-Kolejny-kontrakt-MON-8497272.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 13:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/db8415d4d50bf8-948-568-0-282-4181-2508.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Umowa ramowa na dostawę blisko 1400 nowych pojazdów dla wojska, w tym blisko 1 tys. gąsienicowych bojowych wozów piechoty (BWP) Borsuk oraz pojazdów towarzyszących została zatwierdzona przez wicepremiera, szefa MON Mariusza Błaszczaka. Pojazdy wyprodukuje Huta Stalowa Wola.</p>

## Rentowność "na minusie". Producenci części samochodowych o 2023 roku
 - [https://www.bankier.pl/wiadomosc/Rentownosc-na-minusie-Producenci-czesci-samochodowych-o-2023-roku-8497263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rentownosc-na-minusie-Producenci-czesci-samochodowych-o-2023-roku-8497263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 13:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/2/3e5546cdf873bb-948-568-0-0-2023-1213.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To nie jest najlepszy czas dla branży motoryzacyjnej. Tym razem przepytano producentów części samochodowych, z których prawie połowa oczekuje spadku rentowności, a jedynie jedna trzecia spodziewa się jej wzrostów w 2023 roku. </p>

## Resort obrony Rosji oskarżył Ukrainę o ataki z użyciem dronów
 - [https://www.bankier.pl/wiadomosc/Resort-obrony-Rosji-oskarzyl-Ukraine-o-ataki-z-uzyciem-dronow-8497245.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Resort-obrony-Rosji-oskarzyl-Ukraine-o-ataki-z-uzyciem-dronow-8497245.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 13:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/f50cfaf503def2-948-568-0-0-1875-1124.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraina miała użyć dronów do ataków w Kraju Krasnodarskim i Adygei (innym regionie na południu Rosji). "Nie odnotowano żadnych szkód". Tak wynika z komunikatu Ministerstwa Obrony Rosji cytowanego przez agencję Reutera. </p>

## "W ciemnych barwach". PKO BP mówi wprost o recesji konsumenckiej
 - [https://www.bankier.pl/wiadomosc/W-ciemnych-barwach-PKO-BP-mowi-wprost-o-recesji-konsumenckiej-8497219.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-ciemnych-barwach-PKO-BP-mowi-wprost-o-recesji-konsumenckiej-8497219.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 12:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/7/5563a4583399ff-948-567-0-5-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ciemne barwy - tak można streścić komentarz banku PKO BP do wtorkowych danych GUS. Zdaniem analityków od IV kwartału 2022 roku mamy do czynienia z recesją konsumencką, które perspektywy nie wyglądają dobrze. </p>

## "Pierwsze mieszkanie" gotowe na wakacje. Tak zapowiada premier
 - [https://www.bankier.pl/wiadomosc/Pierwsze-mieszkanie-gotowe-na-wakacje-Tak-zapowiada-premier-8497215.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pierwsze-mieszkanie-gotowe-na-wakacje-Tak-zapowiada-premier-8497215.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 12:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/f34288e83e5b14-948-568-104-144-3072-1843.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dwa miesiące - tyle daje sobie rząd, by dopracować szczegóły programy "Pierwsze mieszkanie". Premier Mateusz Morawiecki zapowiedział początek na 1 lipca i zapewnia, że to realistyczny program. </p>

## mObywatel na równi z tradycyjnymi dokumentami "plastikowymi". Rząd przyjął ustawę
 - [https://www.bankier.pl/wiadomosc/mObywatel-na-rowni-z-tradycyjnymi-dokumentami-plastikowymi-Rzad-przyjal-ustawe-8497174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/mObywatel-na-rowni-z-tradycyjnymi-dokumentami-plastikowymi-Rzad-przyjal-ustawe-8497174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 12:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/94b27a5ef991db-948-568-412-0-1352-811.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd przyjął we wtorek projekt ustawy o mObywatelu, którego celem jest zrównanie dokumentów cyfrowych w tej aplikacji z dokumentami tradycyjnymi. Chcemy, żeby mObywatel stał się mitycznym w czasach PO "jednym okienkiem" do załatwiania s"Rząd Platformy Obywatelskiej zastał Polskę papierową i papierową pozostawił, natomiast rząd Prawa i Sprawiedliwości zastał Polskę papierową, a pozostawi cyfrową - ocenił minister Adam Andruszkiewicz, komentując najnowszą ustawę, która zrównuje aplikację mObywatel z dokumentami tradycyjnymi. woich spraw - powiedział premier Mateusz Morawiecki.</p>

## Prezes Obajtek ogłasza strategię PKN Orlen. Rekordowa dywidenda z rekordowych zysków
 - [https://www.bankier.pl/wiadomosc/Prezes-Obajtek-oglasza-strategie-PKN-Orlen-Co-z-dywidenda-z-rekordowych-zyskow-8497160.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezes-Obajtek-oglasza-strategie-PKN-Orlen-Co-z-dywidenda-z-rekordowych-zyskow-8497160.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 11:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/4/e33043406697bb-948-568-0-5-1975-1185.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezentacja zaktualizowanej strategii rozwoju PKN Orlen to jedno z najważniejszych wydarzeń wtorkowej sesji na GPW. Konferencja pt. „Strategiczne kierunki rozwoju połączonego koncernu multienergetycznego” z udziałem prezesa Daniela Obajtka jest pilnie obserwowane przez inwestorów także z racji zapowiedzianej informacji nt. polityki dywidendowej.</p>

## Maseczki opadły. Raport NIK obnaża porażkę programu „Polskie szwalnie”
 - [https://www.bankier.pl/wiadomosc/Raport-NIK-obnaza-porazke-programu-Polskie-szwalnie-8497139.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Raport-NIK-obnaza-porazke-programu-Polskie-szwalnie-8497139.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 11:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/3f775ceea19c00-945-560-1041-761-2380-1427.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Hucznie uruchamiany projekt "Polskie szwalnie" miał 
zapewnić pracę setkom osób w czasie pandemii
koronawirusa i zaopatrzyć Polskę w miliony maseczek ochronnych. Po wielu
 doniesieniach o nieprawidłowościach w programie pod lupę program wzięła
 Najwyższa Izba Kontroli. Teraz poznaliśmy raport z kontroli.</p>

## Nadwyżka w budżecie państwa wyniosła ponad 11 mld zł w styczniu
 - [https://www.bankier.pl/wiadomosc/Nadwyzka-w-budzecie-panstwa-wyniosla-ponad-11-mld-zl-w-styczniu-8497137.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nadwyzka-w-budzecie-panstwa-wyniosla-ponad-11-mld-zl-w-styczniu-8497137.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 11:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/5/f3fce894afed02-948-568-15-0-2985-1790.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W styczniu nadwyżka w budżecie państwa wyniosła ponad 11 mld zł - poinformował premier Mateusz Morawiecki.</p>

## Zarobki nauczycieli. ZNP żąda 20-proc. wzrostu wynagrodzeń, związek złoży projekt w Sejmie
 - [https://www.bankier.pl/wiadomosc/Ile-zarabiaja-nauczyciele-ZNP-chce-podwyzek-w-oswiacie-8497102.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ile-zarabiaja-nauczyciele-ZNP-chce-podwyzek-w-oswiacie-8497102.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 10:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/5a09154b867ef4-948-568-0-125-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zarobki nauczycieli to temat, który wraca jak 
bumerang i to przeważnie pod hasłem "podwyżki". ZNP poinformował, że ma 
gotowy projekt w tej sprawie i domaga się 20-procentowego wzrostu 
wynagrodzeń nauczycieli od 1 lipca. Przedstawiciele związku 
zapowiedzieli, że złożą go w Sejmie 9 marca.</p>

## Skandal korupcyjny w PE. Pojawiły się kolejne podejrzenia
 - [https://www.bankier.pl/wiadomosc/Skandal-korupcyjny-w-PE-Pojawily-sie-kolejne-podejrzenia-8497088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skandal-korupcyjny-w-PE-Pojawily-sie-kolejne-podejrzenia-8497088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 10:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/3/c17fca37750db1-945-567-5-51-2038-1223.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pojawiły się nowe podejrzenia wobec belgijskiego eurodeputowanego Marca Tarabelli, przeciwko któremu śledczy prowadzą dochodzenie w związku z aferą korupcyjną w Parlamencie Europejskim. Według informacji ujawnionych przez organy ścigania miał on do końca 2024 roku otrzymać 250 mln euro za wspieranie prokatarskiej polityki.</p>

## Suplementy diety na cenzurowanym. Resort zdrowia chce nawet 1 mln złotych kary
 - [https://www.bankier.pl/wiadomosc/Suplementy-diety-na-cenzurowanym-Resort-zdrowia-chce-nawet-1-mln-zlotych-kary-8497075.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Suplementy-diety-na-cenzurowanym-Resort-zdrowia-chce-nawet-1-mln-zlotych-kary-8497075.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 10:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/7/b2a9b286799e33-948-568-0-37-2511-1506.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Suplementy diety na cenzurowanym. Ministerstwo 
Zdrowia chce wprowadzić nowe zasady sprzedaży tych produktów. Preparaty 
mają zniknąć z półek w pobliżu okienek w aptekach, a także kas na 
stacjach benzynowych i w marketach. Zmiany mają dotknąć także ich 
reklamowania, a za złamanie obostrzeń mają grozić wysokie kary - podaje 
Prawo.pl.</p>

## Inflacyjny wystrzał w Hiszpanii. To dopiero początek negatywnych niespodzianek?
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-Hiszpanii-luty-2023-Wzrost-cen-nie-bedzie-tak-szybko-jak-sadzono-8497036.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-Hiszpanii-luty-2023-Wzrost-cen-nie-bedzie-tak-szybko-jak-sadzono-8497036.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 09:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/6/91ce9c0c8b017c-948-568-0-286-997-598.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najnowsze dane z Półwyspu Iberyjskiego wpisują się w ciąg
negatywnych inflacyjnych niespodzianek. Coraz więcej wskazuje na to, że
dezinflacja nie będzie na tyle szybka i trwała, jak na to liczono jeszcze
jesienią.</p>

## GUS potwierdza niepokojące dane. Polska gospodarka mocno hamowała
 - [https://www.bankier.pl/wiadomosc/PKB-Polski-IV-kwartal-2022-r-Gospodarka-mocno-hamuje-8496948.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKB-Polski-IV-kwartal-2022-r-Gospodarka-mocno-hamuje-8496948.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/8/f9d4ff18b84711-948-568-8-78-3491-2094.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pod koniec minionego roku polska gospodarka skurczyła
 się w porównaniu do poprzedniego kwartału najmocniej w XXI w., 
pomijając lockdownowy II kwartał 2020 r. Wzrost PKB Polski w ujęciu 
rocznym nadal podbijała akumulacja zapasów, a dodatkowo wsparła go 
słabość importu. Zmniejszyła się za to konsumpcja.</p>

## Rekordowy budżet Japonii. Tak chcą walczyć z kryzysem demograficznym
 - [https://www.bankier.pl/wiadomosc/Rekordowy-budzet-Japonii-Tak-chca-walczyc-z-kryzysem-demograficznym-8497024.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rekordowy-budzet-Japonii-Tak-chca-walczyc-z-kryzysem-demograficznym-8497024.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 09:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/304e458970c65a-948-568-0-113-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niższa izba parlamentu Japonii zatwierdziła rekordowy budżet wynoszący 114,38 bln jenów (840 mld USD), który przewiduje znaczny wzrost wydatków na obronność i największe w historii środki na świadczenia społeczne – podała we wtorek agencja Kyodo.</p>

## Szef Volkswagena w Chinach: Nie widziałem oznak pracy przymusowej w fabryce w Sinciangu
 - [https://www.bankier.pl/wiadomosc/Szef-Volkswagena-w-Chinach-Nie-widzialem-oznak-pracy-przymusowej-w-fabryce-w-Sinciangu-8497011.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szef-Volkswagena-w-Chinach-Nie-widzialem-oznak-pracy-przymusowej-w-fabryce-w-Sinciangu-8497011.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 09:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/308b7de4cf585d-948-568-0-75-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szef chińskiego oddziału Volkswagena Ralf Brandstaetter odwiedził fabrykę w regionie Sinciang i oświadczył, że nie widział tam oznak pracy przymusowej – podała we wtorek agencja Reutera. Niemiecki koncern przekazał, że nie planuje wycofania się z tej fabryki.</p>

## Dziś mija ważny termin dla emerytów. ZUS może upomnieć się o zwrot świadczeń za trzy lata
 - [https://www.bankier.pl/wiadomosc/Wazny-termin-dla-emerytow-ZUS-moze-upomniec-sie-o-zwrot-swiadczen-za-trzy-lata-8496969.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wazny-termin-dla-emerytow-ZUS-moze-upomniec-sie-o-zwrot-swiadczen-za-trzy-lata-8496969.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 08:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/af1124b4cea3ad-948-568-0-84-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pracujący emeryci i
renciści mają dziś ostatni dzień na złożenie
do ZUS zaświadczenia o swoich przychodach. Jeżeli nie dopełnią tej formalności, mogą być zmuszeni do zwrotu świadczeń nawet za
trzy ostatnie lata.</p>

## Niezidentyfikowany obiekt nad Petersburgiem. Zamknięte wcześniej lotnisko już działa
 - [https://www.bankier.pl/wiadomosc/Petersburg-zamknal-niebo-nad-miastem-Lotnisko-nie-przyjmuje-samolotow-8496986.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Petersburg-zamknal-niebo-nad-miastem-Lotnisko-nie-przyjmuje-samolotow-8496986.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 08:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/0/fdcf9ef247e8f6-948-568-0-57-958-575.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Druga co do wielkości rosyjska metropolia zamknęła przestrzeń powietrzną nad miastem, a samoloty były zawracane. Lotnisko Pułkowo pod Petersburgiem w Rosji przestało na pewien czas przyjmować rejsy. Jednak sytuacja wróciła do normy i znów samoloty są przyjmowane - informuje niezależny rosyjski portal Meduza.</p>

## Kurs euro wrócił do kanału. Frank najtańszy od trzech tygodni
 - [https://www.bankier.pl/wiadomosc/Kurs-dolara-Kurs-euro-wrocil-do-kanalu-Frank-najtanszy-od-trzech-tygodni-8496973.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-dolara-Kurs-euro-wrocil-do-kanalu-Frank-najtanszy-od-trzech-tygodni-8496973.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 08:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/8/53ccbeda863acf-948-569-55-10-1891-1135.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Końcówka lutego przyniosła spadek kursu euro poniżej poziomu
4,7250 zł, czyli górnego ograniczenia jesienno-noworocznej konsolidacji.</p>

## McDonald’s chce być bardziej eko. Sieć testuje nowe rozwiązanie
 - [https://www.bankier.pl/wiadomosc/McDonald-s-testuje-kubki-do-napojow-bez-slomek-8496949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/McDonald-s-testuje-kubki-do-napojow-bez-slomek-8496949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 07:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/ba263ce7192f20-948-568-0-0-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trzy lata po zastąpieniu plastikowych słomek papierowymi McDonald’s testuje nowe kubki w ogóle pozbawione rurek do picia – informuje serwis antyweb.pl. Testy odbywają się w kilku amerykańskich restauracjach sieci.</p>

## 13. emerytura. Podano datę wypłat świadczenia
 - [https://www.bankier.pl/wiadomosc/13-emerytura-kiedy-wyplata-swiadczenia-8496945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/13-emerytura-kiedy-wyplata-swiadczenia-8496945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 07:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/5/72c521efffeb73-948-568-0-0-1600-959.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />13. emerytura będzie wypłacana w kwietniu, czyli tak jak zostało to zaplanowane - poinformował we wtorek rzecznik rządu Piotr Müller.</p>

## "Zainstalujesz na ich polecenie oprogramowanie - stracisz pieniądze". Ostrzega PKO BP
 - [https://www.bankier.pl/wiadomosc/PKO-Bank-Polski-ostrzega-przed-instalacja-programow-wysylanych-przez-oszustow-8496915.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-Bank-Polski-ostrzega-przed-instalacja-programow-wysylanych-przez-oszustow-8496915.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 07:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/16346558c547cc-948-568-0-51-2305-1382.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PKO Bank Polski ostrzega przed przestępcami wyłudzającymi kod Blik, dane do logowania do bankowości elektronicznej lub zachęcającymi do instalacji wysłanego przez nich oprogramowania na urządzeniu. "Zainstalujesz na ich polecenie oprogramowanie - stracisz pieniądze" – alarmuje PKO Bank Polski.</p>

## Cyberatak na stronę podatki.gov.pl
 - [https://www.bankier.pl/wiadomosc/Cyberatak-na-strone-podatki-gov-pl-8496933.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cyberatak-na-strone-podatki-gov-pl-8496933.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 07:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/29e973452d533f-948-568-0-22-1313-787.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />We wtorek rano nie działała strona internetowa Ministerstwa Finansów umożliwiająca rozliczenie PIT-ów online. Rządowa domena była niedostepna z powodu cyberataku, podaje RMF.</p>

## Netflix obniża ceny w ponad 100 krajach. Platforma walczy o klientów
 - [https://www.bankier.pl/wiadomosc/Netflix-obniza-ceny-w-ponad-100-krajach-Platforma-walczy-o-klientow-8496927.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Netflix-obniza-ceny-w-ponad-100-krajach-Platforma-walczy-o-klientow-8496927.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 07:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/a/5c0a3ea0ee2259-948-568-0-192-3352-2011.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W porównaniu z innymi platformami streamingowymi Netflix cechował się najwyższymi cenami. Widząc, że konkurencja "ma taniej" Netflix zdecydował się na wielką obniżkę cen. Czy dotkną one polskich klientów?</p>

## Soboń: Dyskusja o wprowadzeniu euro nie powinna się odbywać przy takiej huśtawce rynków
 - [https://www.bankier.pl/wiadomosc/Sobon-Dyskusja-o-wprowadzeniu-euro-nie-powinna-sie-odbywac-przy-takiej-hustawce-rynkow-8496921.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sobon-Dyskusja-o-wprowadzeniu-euro-nie-powinna-sie-odbywac-przy-takiej-hustawce-rynkow-8496921.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 07:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/b35d5260d8f705-948-568-0-17-1773-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przy tak niestabilnej sytuacji zewnętrznej dyskusja o wprowadzeniu euro nie powinna się dzisiaj odbywać – powiedział we wtorek wiceminister finansów Artur Soboń. W jego ocenie prowadzenie suwerennej polityki monetarnej jest kluczowe dla polskiej gospodarki.</p>

## Fundusze europejskie po nowemu i z korzyścią dla firm. Przeglądamy zmiany
 - [https://www.bankier.pl/wiadomosc/Fundusze-europejskie-na-innowacje-dla-firm-Zmiany-dla-przedsiebiorcow-8494048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fundusze-europejskie-na-innowacje-dla-firm-Zmiany-dla-przedsiebiorcow-8494048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/8b963995672ded-948-568-0-68-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowa perspektywa funduszy europejskich to niemałe zmiany dla przedsiębiorców. Poza ścieżką SMART wprowadzono również finansowanie wdrożenia innowacji, tj. wdrożenia wyników
prac B+R na zasadzie dotacji warunkowej. Na czym polega ten mechanizm?</p>

## Zbrodnie VAT-owskie mają się świetnie. Lawinowo przybywa tych przestępstw podatkowych
 - [https://www.bankier.pl/wiadomosc/Zbrodnie-VAT-owskie-maja-sie-swietnie-Lawinowo-przybywa-tych-przestepstw-podatkowych-8496899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zbrodnie-VAT-owskie-maja-sie-swietnie-Lawinowo-przybywa-tych-przestepstw-podatkowych-8496899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 06:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/4/df50a0bd732fb6-948-568-0-113-2512-1507.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2022 r. prokuratorzy wszczęli 1390 śledztw w sprawach najpoważniejszych przestępstw uszczuplających budżet na ponad 1 mln zł. Zarzuty usłyszało 3359 podejrzanych - pisze we wtorek "Dziennik Gazeta Prawna".</p>

## Tu znajdziesz pieniądze dla swojej firmy. Wystartowały pierwsze nabory wniosków na dotacje z funduszy europejskich
 - [https://www.bankier.pl/wiadomosc/Dotacje-z-funduszy-UE-dla-firm-Tu-czekaja-pieniadze-8496417.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dotacje-z-funduszy-UE-dla-firm-Tu-czekaja-pieniadze-8496417.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 06:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/315972cf815041-948-568-0-30-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wystartowały pierwsze nabory wniosków o dotacje z 
funduszy europejskich. Wsparcie można otrzymać na rozwój nowego biznesu,
 produktów oraz usług. Dodatkowo środki pieniężne dostępne są również na
 wsparcie cyfrowej transformacji   oraz przedsięwzięć mających na celu 
zmniejszenie emisyjności. To tylko część oferty, z której mogą 
skorzystać firmy w najbliższych latach. Sprawdź, na jakie inwestycje 
można starać się o pieniądze z Unii Europejskiej.</p>

## Na wojsko pieniędzy nie zabraknie. W tym roku pobijemy kolejny rekord
 - [https://www.bankier.pl/wiadomosc/Na-wojsko-pieniedzy-nie-zabraknie-W-tym-roku-pobijemy-kolejny-rekord-8496884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Na-wojsko-pieniedzy-nie-zabraknie-W-tym-roku-pobijemy-kolejny-rekord-8496884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/edddb7d99ed185-948-568-48-129-1872-1123.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ubiegłym roku środki przeznaczone na nowe uzbrojenie były ponad dwa razy wyższe niż rok wcześniej. W 2023 r. Polska wyda na obronność ok. 4 proc. PKB, co stawia nas w czołówce NATO - pisze we wtorek "Dziennik Gazeta Prawna".</p>

## Borys (PFR): Inflacja nie przekroczy 20 proc. i będzie silnie hamować wiosną. Polska uniknie recesji w tym roku
 - [https://www.bankier.pl/wiadomosc/Borys-PFR-Inflacja-nie-przekroczy-20-proc-i-bedzie-silnie-hamowac-wiosna-Polska-uniknie-recesji-w-tym-roku-8496882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Borys-PFR-Inflacja-nie-przekroczy-20-proc-i-bedzie-silnie-hamowac-wiosna-Polska-uniknie-recesji-w-tym-roku-8496882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/76a42e865a9b06-948-568-0-21-1738-1042.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wysoka inflacja, hamowanie gospodarki, obawy przed 
recesją i wiele innych obaw ekonomicznych spędza Polakom (i nie tylko) 
sen z powiek. Jednak jak powiedział prezes Polskiego Funduszu Rozwoju Paweł Borys, już wiosną zobaczymy poprawiające się wskaźniki sprzedaży i produkcji i zarazem silnie hamującą inflację.</p>

## Kogo stać na oszczędzanie? Poduszka finansowa Polaków jest niezbyt wygodna
 - [https://www.bankier.pl/wiadomosc/Kogo-stac-na-oszczedzanie-Poduszka-finansowa-Polakow-jest-niezbyt-wygodna-8496864.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kogo-stac-na-oszczedzanie-Poduszka-finansowa-Polakow-jest-niezbyt-wygodna-8496864.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/6/a62594f46f1b9a-948-568-0-54-1823-1093.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jak i czy w ogóle oszczędzają Polacy? Obraz, jaki wyłania się z badania „Polaków Portfel Własny: czas oszczędzania”,
 nie jest zbyt optymistyczny. Systematycznie oszczędza tylko 38 proc. 
ankietowanych, a powyżej 5 miesięcznych pensji zgromadziło niecałe 30 
proc. tych, którzy budują poduszkę finansową.</p>

## Browar Staropolski warzy nie tylko smacznie, ale i zdrowo
 - [https://www.bankier.pl/wiadomosc/Browar-Staropolski-warzy-nie-tylko-smacznie-ale-i-zdrowo-8496478.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Browar-Staropolski-warzy-nie-tylko-smacznie-ale-i-zdrowo-8496478.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/6/037c64a77b603b-948-567-5-17-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po 14 latach pracy dla największych międzynarodowych korporacji Marek Łycyniak stwierdził, że czas przejść na swoje. Najpierw wraz z żoną stworzyli sieć sklepów z alkoholami, by po ośmiu latach, w 2014 r., kupić od syndyka Browar Staropolski w Zduńskiej Woli. </p>

## Koniec exodusu w policji i wojsku? Mundurowi zyskają nowe świadczenie za długoletnią służbę
 - [https://www.bankier.pl/wiadomosc/Mundurowi-zyskaja-nowe-swiadczenie-za-dlugoletnia-sluzbe-8496570.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mundurowi-zyskaja-nowe-swiadczenie-za-dlugoletnia-sluzbe-8496570.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/6/25d22e0eb9fb6b-948-568-0-31-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będzie nowe świadczenie motywacyjne dla
doświadczonych funkcjonariuszy i żołnierzy posiadających co najmniej 15-letni
staż. Dodatek będzie obowiązywał od 1 marca 2023 r. i ma powstrzymać
mundurowych przed odchodzeniem ze służby.</p>

## NCBR ogłosi niebawem pierwsze konkursy z programu FER
 - [https://www.bankier.pl/wiadomosc/NCBR-oglosi-niebawem-pierwsze-konkursy-z-programu-FER-8496467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NCBR-oglosi-niebawem-pierwsze-konkursy-z-programu-FER-8496467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/6/b9165dc4baff16-948-568-20-13-2760-1656.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fundusze Europejskie dla Rozwoju
Społecznego będą realizowane w sześciu priorytetach, z czego NCBR będzie jedną z
instytucji pośredniczących dla priorytetu I Umiejętności oraz priorytetu III Dostępność
i usługi dla osób z niepełnosprawnościami.</p>

## Na wzornictwo, ekologię i IT. Obok tych środków z UE firmy nie mogą przejść obojętnie
 - [https://www.bankier.pl/wiadomosc/Fundusze-europejskie-dla-firm-Najciekawsze-konkursy-8494722.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fundusze-europejskie-dla-firm-Najciekawsze-konkursy-8494722.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/6047c74592a524-948-568-0-169-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowa oferta funduszy europejskich jest na tyle bogata, że każdy przedsiębiorca znajdzie w niej coś dla siebie. Jednocześnie tak duża konkursów i usług może przyprawiać o lekki zawrót głowy. By nieco to wszystko uporządkować, postanowiliśmy przygotować subiektywne zestawienie najciekawszych propozycji dla właścicieli małych i średnich firm. 


</p>

## Najlepsze oferty banków na 12 miesięcy. Tyle można zarobić na lokacie rocznej
 - [https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-12-miesiecy-luty-2023-Ranking-Bankier-pl-8496565.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-12-miesiecy-luty-2023-Ranking-Bankier-pl-8496565.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/70561a298e04f4-948-568-96-197-2039-1223.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najwyższa stawka na rynku na lokacie rocznej to aktualnie 8,20 proc. w skali roku. Z takiej oferty skorzystają osoby, które mają lub założą konto osobiste u lidera tabeli. W zestawieniu znalazł się jeszcze jeden bank, który proponuje nie mniej niż 8 proc. rocznie.</p>

## Pieniądze na wyciagnięcie ręki, czyli miliardy euro dla polskich firm. Jak je zdobyć? Przedsiębiorcy mogą liczyć na pomoc
 - [https://www.bankier.pl/wiadomosc/Innowacje-w-firmach-Jak-uzyskac-pomoc-przy-dotacjach-unijnych-8496470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Innowacje-w-firmach-Jak-uzyskac-pomoc-przy-dotacjach-unijnych-8496470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/9/55c9ccfa7b4e74-948-568-450-33-3693-2216.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Unijne
pieniądze na innowacje w obecnej perspektywie są ogromne – do podziału jest aż
4,4 mld euro. Firmy, które chcą je zdobyć, muszą dobrze przygotować projekt i opisać go we wniosku. Wydaje się to proste,
ale jak zwykle diabeł tkwi w szczegółach… Gdzie szukać pomocy? Podpowiadamy.</p>

## Powell złamał "gołębie" oczekiwania inwestorów. Fed kontra rynki: 1 do 0
 - [https://www.bankier.pl/wiadomosc/Stopy-procentowe-w-USA-Fed-kontra-rynki-1-do-0-8496391.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stopy-procentowe-w-USA-Fed-kontra-rynki-1-do-0-8496391.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/9cde2dbb7389aa-948-568-0-150-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przez ostatni miesiąc doszło do istotnego przesunięcia w
górę rynkowych oczekiwań względem stóp procentowych w Rezerwie Federalnych.</p>

## TikTok zniknie z USA? Biały Dom stawia pierwsze kroki w tym kierunku
 - [https://www.bankier.pl/wiadomosc/TikTok-zniknie-z-USA-Bialy-Dom-stawia-pierwsze-kroki-w-tym-kierunku-8496860.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/TikTok-zniknie-z-USA-Bialy-Dom-stawia-pierwsze-kroki-w-tym-kierunku-8496860.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 04:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/e3dbe718759edf-948-568-0-169-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Biały Dom nakazał w poniedziałek agencjom rządowym wyeliminowanie w ciągu 30 dni chińskiej aplikacji Tik Tok z federalnych urządzeń i systemów. Zaprotestował przeciw temu Amerykański Związek Swobód Obywatelskich (ACLU).</p>

## Rywal ChatGPT na horyzoncie. Elon Musk znów wchodzi w sztuczną inteligencję
 - [https://www.bankier.pl/wiadomosc/Elon-Musk-kontra-ChatGPT-Chce-stworzyc-konkurencje-dla-chatbota-8496852.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Elon-Musk-kontra-ChatGPT-Chce-stworzyc-konkurencje-dla-chatbota-8496852.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 02:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/a5b4e0e837c527-948-568-0-303-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Elon Musk w ostatnim czasie krytykował ChatGPT, 
stworzony przez OpenAI, którego sam był założycielem. Jak donosza media,
 miliarder poszukuje obecnie specjalistów od sztucznej inteligencji i 
chce utworzyć nowe laboratorium badawcze w celu opracowania alternatywy 
dla popularnego chatbota.</p>

## Niedobory żywności w Korei Północnej. Kim Dzong Un nakazuje "fundamentalną transformację" rolnictwa
 - [https://www.bankier.pl/wiadomosc/Niedobory-zywnosci-w-Korei-Polnocnej-Kim-Dzong-Un-nakazuje-fundamentalna-transformacje-rolnictwa-8496851.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niedobory-zywnosci-w-Korei-Polnocnej-Kim-Dzong-Un-nakazuje-fundamentalna-transformacje-rolnictwa-8496851.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 01:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/1/f70b6435b5bd2c-948-568-0-0-1751-1050.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przywódca Korei Północnej Kim Jong Un wezwał do "fundamentalnej transformacji" w produkcji rolnej - podały we wtorek państwowe media, które cytuje Reuters. Krok ten podyktowany jest pogłębiającym się w kraju niedoborem żywności.</p>

## Elon Musk i Tesla pozwani przez akcjonariuszy. "Ponieśli znaczące straty i szkody"
 - [https://www.bankier.pl/wiadomosc/Elon-Musk-i-Tesla-pozwani-przez-akcjonariuszy-Poniesli-znaczace-straty-i-szkody-8496850.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Elon-Musk-i-Tesla-pozwani-przez-akcjonariuszy-Poniesli-znaczace-straty-i-szkody-8496850.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-28 00:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/71d5d2ecb3083e-948-567-0-47-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Elon Musk ma ostatnio coraz więcej problemów. W 
poniedziałek Tesla i jej szef zostali pozwani przez akcjonariuszy, 
którzy oskarżyli spółkę i miliardera o przecenianie skuteczności i 
bezpieczeństwa technologii Autopilot i Full Self-Driving swoich 
samochodów elektrycznych.</p>

