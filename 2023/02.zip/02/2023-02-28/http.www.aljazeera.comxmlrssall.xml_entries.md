# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Mexico’s president hits out at implicit criticism from US
 - [https://www.aljazeera.com/news/2023/2/28/mexicos-president-hits-out-at-implicit-criticism-from-us](https://www.aljazeera.com/news/2023/2/28/mexicos-president-hits-out-at-implicit-criticism-from-us)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 21:39:06+00:00

&#039;There&#039;s currently more democracy in Mexico than in the United States,&#039; Andres Manuel Lopez Obrador says.

## Bankman-Fried’s close associate pleads guilty to criminal charges
 - [https://www.aljazeera.com/economy/2023/2/28/bankman-frieds-close-associate-pleads-guilty-to-criminal-charges](https://www.aljazeera.com/economy/2023/2/28/bankman-frieds-close-associate-pleads-guilty-to-criminal-charges)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 20:42:39+00:00

Nishad Singh says he knew by mid-2022 that FTX funds were being borrowed by its sister firm without customer knowledge.

## Putin warns of espionage as Russia presses Ukraine’s Bakhmut
 - [https://www.aljazeera.com/news/2023/2/28/putin-warns-of-espionage-as-russians-try-to-encircle-bakhmut](https://www.aljazeera.com/news/2023/2/28/putin-warns-of-espionage-as-russians-try-to-encircle-bakhmut)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 20:41:35+00:00

As Putin asked the FSB to bolster security, Moscow said it is open to peace talks, but will not give up annexed regions.

## Will new UK-EU deal over Northern Ireland end the Brexit impasse?
 - [https://www.aljazeera.com/program/inside-story/2023/2/28/will-new-uk-eu-deal-over-northern-ireland-end-the-brexit-impasse](https://www.aljazeera.com/program/inside-story/2023/2/28/will-new-uk-eu-deal-over-northern-ireland-end-the-brexit-impasse)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 20:37:38+00:00

The UK&#039;s leader has been negotiating with the EU to replace the Northern Ireland Protocol.

## Mexico approves new Tesla plant in northern Mexico
 - [https://www.aljazeera.com/news/2023/2/28/mexico-approves-new-tesla-plant-in-northern-mexico](https://www.aljazeera.com/news/2023/2/28/mexico-approves-new-tesla-plant-in-northern-mexico)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 19:38:34+00:00

Mexican President Andres Manuel Lopez Obrador announced the decision on Tuesday following a call with Elon Musk.

## Cholera outbreak in quake-hit northwestern Syria kills two people
 - [https://www.aljazeera.com/news/2023/2/28/cholera-outbreak-in-quake-hit-northwestern-syria-leaves-two-dead](https://www.aljazeera.com/news/2023/2/28/cholera-outbreak-in-quake-hit-northwestern-syria-leaves-two-dead)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 19:15:26+00:00

Two people have died and 568 non-fatal cases have been reported in the earthquake-hit areas of northwestern Syria.

## European Parliament to ban TikTok from staff phones: EU official
 - [https://www.aljazeera.com/news/2023/2/28/european-parliament-to-ban-tiktok-from-staff-phones-eu-official](https://www.aljazeera.com/news/2023/2/28/european-parliament-to-ban-tiktok-from-staff-phones-eu-official)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 18:46:39+00:00

The move comes a day after the US gave federal agencies 30 days to wipe TikTok off all government devices.

## From California to NY, coast-to-coast storms ravage US
 - [https://www.aljazeera.com/gallery/2023/2/28/from-california-to-ny-storms-ravage-us-from-coast-to-coast](https://www.aljazeera.com/gallery/2023/2/28/from-california-to-ny-storms-ravage-us-from-coast-to-coast)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 16:28:12+00:00

Snow, high winds, tornadoes cause damage across US with another massive winter storm brewing.

## Putin orders tightening of Ukraine border as drones hit Russia
 - [https://www.aljazeera.com/news/2023/2/28/putin-orders-tightening-of-ukraine-border-as-drones-hit-russia](https://www.aljazeera.com/news/2023/2/28/putin-orders-tightening-of-ukraine-border-as-drones-hit-russia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 15:55:20+00:00

One drone crashed 100 km from Moscow on Tuesday, according to the regional governor.

## Bola Tinubu leads in Nigeria election, opposition seeks new vote
 - [https://www.aljazeera.com/news/2023/2/28/bola-tinubu-leads-in-nigeria-election-opposition-seeks-new-vote](https://www.aljazeera.com/news/2023/2/28/bola-tinubu-leads-in-nigeria-election-opposition-seeks-new-vote)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 15:40:50+00:00

Three opposition parties call for cancellation of election, as ruling party candidate is in the lead.

## US Supreme Court weighs Biden’s college student debt relief
 - [https://www.aljazeera.com/news/2023/2/28/us-supreme-court-scrutinizes-biden-college-student-debt-relief](https://www.aljazeera.com/news/2023/2/28/us-supreme-court-scrutinizes-biden-college-student-debt-relief)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 15:25:08+00:00

Joe Biden wants to forgive student debt for millions, but critics argue he overstepped his authority.

## Europe leaps towards energy autonomy as sanctions undercut Russia
 - [https://www.aljazeera.com/news/2023/2/28/europe-leaps-towards-energy-autonomy-as-sanctions-undercut-russia](https://www.aljazeera.com/news/2023/2/28/europe-leaps-towards-energy-autonomy-as-sanctions-undercut-russia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 15:09:58+00:00

Moscow has waged an energy war against the EU over the past year, but the bloc appears to be holding firm.

## Israel releases settlers arrested after anti-Palestinian attacks
 - [https://www.aljazeera.com/news/2023/2/28/israel-releases-settlers-arrested-after-anti-palestinian-attacks](https://www.aljazeera.com/news/2023/2/28/israel-releases-settlers-arrested-after-anti-palestinian-attacks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 14:42:30+00:00

Only eight Jewish settlers were arrested after Sunday&#039;s attack on villages near Nablus that left one Palestinian dead.

## A global happy birthday to hip hop
 - [https://www.aljazeera.com/opinions/2023/2/28/a-global-happy-birthday-to-hip-hop](https://www.aljazeera.com/opinions/2023/2/28/a-global-happy-birthday-to-hip-hop)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 14:15:57+00:00

For 50 years, hip hop has given us the soundtrack of rebellion across the world.

## Russia after a year of sanctions
 - [https://www.aljazeera.com/opinions/2023/2/28/russia-after-a-year-of-sanctions](https://www.aljazeera.com/opinions/2023/2/28/russia-after-a-year-of-sanctions)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 13:48:22+00:00

The Russian economy has fallen into a recession, but economic and political instability are not yet on the horizon.

## Record number of countries enforced internet blackouts in 2022
 - [https://www.aljazeera.com/news/2023/2/28/record-number-of-countries-enforce-internet-shutdowns-in-2022](https://www.aljazeera.com/news/2023/2/28/record-number-of-countries-enforce-internet-shutdowns-in-2022)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 13:41:11+00:00

A new report by Access Now and the #KeepItOn campaign finds 35 countries have hit the kill button over the past year.

## In search of healthcare, a child joins mass migration to Chile
 - [https://www.aljazeera.com/news/longform/2023/2/28/in-search-of-healthcare-a-child-joins-mass-migration-to-chile](https://www.aljazeera.com/news/longform/2023/2/28/in-search-of-healthcare-a-child-joins-mass-migration-to-chile)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 13:25:49+00:00

Waves of Venezuelan refugees and migrants are arriving in Chile, attracted by political and economic stability.

## Who’s leading the Nigeria election? All to know about the results
 - [https://www.aljazeera.com/news/2023/2/28/whats-going-on-with-the-nigeria-election-three-days-after](https://www.aljazeera.com/news/2023/2/28/whats-going-on-with-the-nigeria-election-three-days-after)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 13:19:41+00:00

Voters and observer missions have highlighted INEC&#039;s failures and violence on election day as results are awaited.

## UK’s COVID-19 inquiry should address racism, says campaign group
 - [https://www.aljazeera.com/news/2023/2/28/uk-covid-19-inquiry-must-address-structural-racism-report](https://www.aljazeera.com/news/2023/2/28/uk-covid-19-inquiry-must-address-structural-racism-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 13:14:09+00:00

Officials must probe why Black and ethnic minority Britons were overrepresented in pandemic tolls, says group.

## In 2022, the world saw 187 internet shutdowns – 84 by India alone
 - [https://www.aljazeera.com/news/2023/2/28/in-2022-the-world-saw-187-internet-shutdowns-84-by-india-alone](https://www.aljazeera.com/news/2023/2/28/in-2022-the-world-saw-187-internet-shutdowns-84-by-india-alone)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 12:24:47+00:00

More than half of 84 shutdowns in 2022 recorded in Kashmir as India leads Access Now list for a fifth consecutive year.

## Twitter under fire for censoring Palestinian public figures
 - [https://www.aljazeera.com/features/2023/2/28/twitter-under-fire-for-censuring-palestinian-public-figures](https://www.aljazeera.com/features/2023/2/28/twitter-under-fire-for-censuring-palestinian-public-figures)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 12:10:19+00:00

Digital rights groups say social media giants have restricted, suspended accounts of Palestinian journalists, activists.

## ‘Everywhere they go, the Rohingya are exploited’
 - [https://www.aljazeera.com/news/2023/2/28/rohingya-book-kaamil-ahmed](https://www.aljazeera.com/news/2023/2/28/rohingya-book-kaamil-ahmed)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 12:08:19+00:00

Kaamil Ahmed, a British journalist, on his new book about the Rohingya&#039;s extraordinary suffering.

## From displacement to homecoming: Dispatch from Nigeria
 - [https://www.aljazeera.com/opinions/2023/2/28/from-displacement-to-homecoming-dispatch-from-nigeria](https://www.aljazeera.com/opinions/2023/2/28/from-displacement-to-homecoming-dispatch-from-nigeria)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 11:52:54+00:00

A community in northeast Nigeria, devastated by Boko Haram, is rebuilding a remarkable story of resilience and hope.

## Blinken in Central Asia to boost ties amid Russia-Ukraine war
 - [https://www.aljazeera.com/news/2023/2/28/blinken-in-central-asia-to-boost-ties-amid-ukraine-war](https://www.aljazeera.com/news/2023/2/28/blinken-in-central-asia-to-boost-ties-amid-ukraine-war)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 11:17:37+00:00

US secretary of state to meet with counterparts of five Central Asian countries on visits to Kazakhstan and Uzbekistan.

## Philippines’ Marcos Jr urges military to focus on South China Sea
 - [https://www.aljazeera.com/news/2023/2/28/philippines-marcos-jr-urges-military-to-focus-on-south-china-sea](https://www.aljazeera.com/news/2023/2/28/philippines-marcos-jr-urges-military-to-focus-on-south-china-sea)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 10:20:51+00:00

Philippine president says country&#039;s boundaries being called into question just weeks after public dispute with China.

## Rights group, UN experts express concern over Bahrain arrests
 - [https://www.aljazeera.com/news/2023/2/28/rights-group-un-experts-express-concern-over-bahrain-arrests](https://www.aljazeera.com/news/2023/2/28/rights-group-un-experts-express-concern-over-bahrain-arrests)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 10:08:19+00:00

HRW says Manama still committing widespread rights violations as it seeks to &#039;display image of reform and tolerance&#039;.

## Follow the vote: Nigeria presidential election results 2023
 - [https://www.aljazeera.com/news/2023/2/28/nigeria-presidential-election-results-2023](https://www.aljazeera.com/news/2023/2/28/nigeria-presidential-election-results-2023)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 09:47:33+00:00

Counting has been under way since polls closed on Sunday, with the final tally expected within five days.

## Pakistan launches trafficking probe after refugee boat tragedy
 - [https://www.aljazeera.com/news/2023/2/28/pakistan-launches-trafficking-probe-after-refugee-boat-tragedy](https://www.aljazeera.com/news/2023/2/28/pakistan-launches-trafficking-probe-after-refugee-boat-tragedy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 09:33:09+00:00

Federal agency investigates people smugglers after two recent incidents of Pakistanis drowning on their way to Europe.

## HRW calls on Tunisia’s president to halt crackdown on judiciary
 - [https://www.aljazeera.com/news/2023/2/28/hrw-calls-on-tunisias-president-to-halt-crackdown-judiciary](https://www.aljazeera.com/news/2023/2/28/hrw-calls-on-tunisias-president-to-halt-crackdown-judiciary)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 09:25:43+00:00

Human Rights Watch says Kais Saied&#039;s government has taken away the independence of the judiciary.

## Iran’s Asiatic cheetah cub, Pirouz, dies of kidney failure
 - [https://www.aljazeera.com/news/2023/2/28/irans-only-endangered-cheetah-cub-pirouz-dies-of-kidney-failure](https://www.aljazeera.com/news/2023/2/28/irans-only-endangered-cheetah-cub-pirouz-dies-of-kidney-failure)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 09:08:11+00:00

Pirouz, meaning &#039;victor&#039;, had become a symbol of hope for many amid crushing social and economic pressures.

## Messi, Putellas named FIFA’s Best for 2022
 - [https://www.aljazeera.com/sports/2023/2/28/lionel-messi-named-fifa-best-mens-player-of-2022](https://www.aljazeera.com/sports/2023/2/28/lionel-messi-named-fifa-best-mens-player-of-2022)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 09:07:35+00:00

Messi named men&#039;s player of the year after leading Argentina to World Cup glory; Putellas wins best women player award.

## Brazil cracks down on illegal miners in Amazon’s Indigenous land
 - [https://www.aljazeera.com/gallery/2023/2/28/photos-brazil-cracks-down-on-illegal-gold-miners-in-amazon](https://www.aljazeera.com/gallery/2023/2/28/photos-brazil-cracks-down-on-illegal-gold-miners-in-amazon)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 09:02:45+00:00

Brazilian authorities deploy helicopters over the Amazon jungle in search of clandestine gold mine sites in the Amazon.

## Belarus president and firm Russia ally Lukashenko to visit China
 - [https://www.aljazeera.com/news/2023/2/28/belarus-leader-and-firm-russia-ally-lukashenko-to-visit-china](https://www.aljazeera.com/news/2023/2/28/belarus-leader-and-firm-russia-ally-lukashenko-to-visit-china)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 08:41:21+00:00

Belarusian President Alexander Lukashenko&#039;s visit to Beijing comes as China&#039;s relations with the US have plummeted.

## Are asylum seekers safe in the UK?
 - [https://www.aljazeera.com/program/the-stream/2023/2/28/are-asylum-seekers-safe-in-the-uk](https://www.aljazeera.com/program/the-stream/2023/2/28/are-asylum-seekers-safe-in-the-uk)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 08:38:59+00:00

Vulnerable people in hotels face intimidation from protesters that far-right groups are targeting for support.

## Russia-Ukraine war: List of key events, day 370
 - [https://www.aljazeera.com/news/2023/2/28/russia-ukraine-war-list-of-key-events-day-370](https://www.aljazeera.com/news/2023/2/28/russia-ukraine-war-list-of-key-events-day-370)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 07:25:35+00:00

As the Russia-Ukraine war enters its 370th day, we take a look at the main developments.

## Israeli-American killed in Jericho attack
 - [https://www.aljazeera.com/news/2023/2/28/israeli-american-killed-in-jericho-attack](https://www.aljazeera.com/news/2023/2/28/israeli-american-killed-in-jericho-attack)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 07:19:25+00:00

Drive-by shooting comes after Jewish settlers killed a Palestinian during a rampage through villages in the West Bank.

## India terror law haunts Muslims jailed since 2020 for Delhi riots
 - [https://www.aljazeera.com/news/2023/2/28/india-terror-law-haunts-muslims-jailed-since-2020-for-delhi-riots](https://www.aljazeera.com/news/2023/2/28/india-terror-law-haunts-muslims-jailed-since-2020-for-delhi-riots)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 06:38:00+00:00

Activists and family members of those in jail for 2020 violence say &#039;draconian&#039; UAPA is being misused to deny them bail.

## North Korea’s Kim orders ‘radical change’ in agriculture
 - [https://www.aljazeera.com/economy/2023/2/28/north-koreas-kim-orders-radical-change-in-agriculture](https://www.aljazeera.com/economy/2023/2/28/north-koreas-kim-orders-radical-change-in-agriculture)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 05:13:07+00:00

North Korean leader calls on officials to meet production targets after South Korea warns of &quot;grave&quot; food situation.

## Japan seeks charges against ad firms over Olympics contracts
 - [https://www.aljazeera.com/economy/2023/2/28/japan-seeks-charges-against-ad-firms-over-olympics-contracts](https://www.aljazeera.com/economy/2023/2/28/japan-seeks-charges-against-ad-firms-over-olympics-contracts)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 03:36:12+00:00

Japanese authorities have alleged that companies rigged the bids for 26 contracts worth $3.95m.

## Hong Kong scraps COVID-19 mask mandate after almost 1,000 days
 - [https://www.aljazeera.com/news/2023/2/28/hong-kong-scraps-mask-mandate-after-almost-1000-days](https://www.aljazeera.com/news/2023/2/28/hong-kong-scraps-mask-mandate-after-almost-1000-days)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 03:30:34+00:00

Chinese territory hopes the relaxation of its last coronavirus measures will lure back visitors and boost business.

## US announces crackdown on child labour amid surge in violations
 - [https://www.aljazeera.com/economy/2023/2/28/us-announces-crackdown-on-child-labor-amid-uptick-in-violations](https://www.aljazeera.com/economy/2023/2/28/us-announces-crackdown-on-child-labor-amid-uptick-in-violations)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 02:36:22+00:00

Biden administration announcement comes after reports of underage refugees and migrants working in dangerous industries.

## US requests extradition of El Chapo’s son, Mexico says
 - [https://www.aljazeera.com/news/2023/2/28/us-requests-extradition-of-el-chapos-son-mexico-says](https://www.aljazeera.com/news/2023/2/28/us-requests-extradition-of-el-chapos-son-mexico-says)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 02:17:42+00:00

Ovidio Guzman was arrested in January triggering a wave of violence in Sinaloa, the stronghold of their drug empire.

## Why money will not be enough to address Japan’s baby crisis
 - [https://www.aljazeera.com/news/2023/2/28/why-money-will-not-be-enough-to-address-japans-demographic-crisis](https://www.aljazeera.com/news/2023/2/28/why-money-will-not-be-enough-to-address-japans-demographic-crisis)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 02:06:51+00:00

Japanese women are having children later in life and worry motherhood will end their careers in a patriarchal society.

## Can faking volcanic eruptions save the climate? Science is spilt
 - [https://www.aljazeera.com/economy/2023/2/28/could-fake-volcanos-solve-climate-change-scientists-are-divided](https://www.aljazeera.com/economy/2023/2/28/could-fake-volcanos-solve-climate-change-scientists-are-divided)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-28 00:05:20+00:00

The controversial theory of solar geoengineering is at the centre of a growing body of climate research in Asia.

