# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## 50 tys. zł w trzy lata. Tak można zaoszczędzić w PPK
 - [https://www.money.pl/emerytury/50-tys-zl-w-trzy-lata-tak-mozna-zaoszczedzic-w-ppk-6871030054603392a.html](https://www.money.pl/emerytury/50-tys-zl-w-trzy-lata-tak-mozna-zaoszczedzic-w-ppk-6871030054603392a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 18:50:13+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/576374ed-1c4b-45d5-ba62-127ad1c03698" width="308" /> Osiem milionów pracowników w Polsce będzie musiało ponownie podjąć decyzję, czy chce odkładać na przyszłą emeryturę w ramach Pracowniczych Planów Kapitałowych. Sprawdziliśmy, jak oszczędzanie w PPK wygląda w praktyce i czy faktycznie się opłaca.

## Koniec z ogrzewaniem gazowym i olejowym. Niemcy przed ważną decyzją
 - [https://www.money.pl/gospodarka/koniec-z-ogrzewaniem-gazowym-i-olejowym-niemcy-przed-wazna-decyzja-6871490763991744a.html](https://www.money.pl/gospodarka/koniec-z-ogrzewaniem-gazowym-i-olejowym-niemcy-przed-wazna-decyzja-6871490763991744a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 18:47:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/85dc2cf9-cb85-4e89-b33b-e9a9f2064db5" width="308" /> Już od 2024 roku w Niemczech może zostać wprowadzony zakaz instalowania nowych systemów ogrzewania gazowego i olejowego - poinformował we wtorek dziennik "Bild", który dotarł do projektu odpowiedniej ustawy.

## Coraz bliżej do głośnej reformy emerytalnej we Francji. Senacka komisja przyjęła projekt
 - [https://www.money.pl/emerytury/coraz-blizej-do-glosnej-reformy-emerytalnej-we-francji-senacka-komisja-przyjela-projekt-6871486601054944a.html](https://www.money.pl/emerytury/coraz-blizej-do-glosnej-reformy-emerytalnej-we-francji-senacka-komisja-przyjela-projekt-6871486601054944a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 18:40:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2f741bd7-fada-4057-8beb-f31961552ebc" width="308" /> Francuzi mogą przechodzić na emeryturę już w wieku 62 lat, a państwo wydaje na świadczenia 14,8 proc. PKB rocznie. Dlatego rząd chce podnieść wiek emerytalny o dwa lata. We wtorek senackiej komisji udało się przyjąć projekt reformy z kilkoma poprawkami.

## Niemcy otrząsają się z szoku. Czeka ich rewolucja
 - [https://www.money.pl/gospodarka/niemcy-otrzasaja-sie-z-szoku-czeka-ich-rewolucja-6871464491940576a.html](https://www.money.pl/gospodarka/niemcy-otrzasaja-sie-z-szoku-czeka-ich-rewolucja-6871464491940576a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 17:00:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/138ddc1d-242e-49e8-93f2-6a366c51efa4" width="308" /> Niemcy powoli otrząsają się z szoku spowodowanego inwazją Rosji na Ukrainę. Nazwali już procesy, które mają pomóc im zrewidować dotychczasowy, rzekomo doskonały model uprawiania polityki i biznesu - komentuje Ośrodek Studiów Wschodnich, dodając, że Niemcy czeka rewolucja.

## Biden chce, aby te amerykańskie firmy dzieliły się zyskami
 - [https://www.money.pl/gospodarka/biden-chce-aby-te-amerykanskie-firmy-dzielily-sie-zyskami-6871456161000160a.html](https://www.money.pl/gospodarka/biden-chce-aby-te-amerykanskie-firmy-dzielily-sie-zyskami-6871456161000160a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 16:26:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/81e00710-64d2-4b32-965e-01f39c6fe721" width="308" /> Administracja Joe Bidena poinformowała, że będzie wymagać od firm zdobywających fundusze z wartego 52 miliardy dolarów amerykańskiego programu produkcji i badań półprzewodników, aby podzieliły się nadwyżkami zysków - informuje Reuters.

## Donald Tusk zapowiada kredyt zero procent. Minister rozwoju: to licytowanie się z PiS
 - [https://www.money.pl/banki/donald-tusk-zapowiada-kredyt-zero-procent-minister-rozwoju-to-licytowanie-sie-z-pis-6871444060490464a.html](https://www.money.pl/banki/donald-tusk-zapowiada-kredyt-zero-procent-minister-rozwoju-to-licytowanie-sie-z-pis-6871444060490464a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 16:18:39+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bc45b2b7-f786-4975-acf2-66b2769823d4" width="308" /> Donald Tusk obiecuje kredyt zero procent dla osób, które będą kupowały swoje pierwsze mieszkanie. Tymczasem rząd PiS właśnie pracuje nad podobnym rozwiązaniem, ale oprocentowanym na poziomie dwóch procent. Minister rozwoju Waldemar Buda mówi o propozycji lidera PO wprost: to kalka.

## Nadchodzą zmiany dla milionów Polaków. Oto co musisz wiedzieć
 - [https://www.money.pl/gospodarka/nadchodza-zmiany-dla-milionow-polakow-oto-co-musisz-wiedziec-6871444055149280a.html](https://www.money.pl/gospodarka/nadchodza-zmiany-dla-milionow-polakow-oto-co-musisz-wiedziec-6871444055149280a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 15:37:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ee2dd8e8-59b8-4184-9393-6f86b735cd21" width="308" /> Rekordowa waloryzacja rent i emerytur, nowy dodatek dla służb mundurowych, obniżenie cen biletów PKP czy ponowny autozapis do Pracowniczych Planów Kapitałowych. Od marca wchodzą zmiany, które dotyczyć będą nawet 25 milionów Polaków.

## PIT za 2022 rok z dużym zwrotem. Matki dostają nawet kilka tysięcy złotych. Oto powód
 - [https://www.money.pl/podatki/pit-za-2022-rok-z-duzym-zwrotem-matki-dostaja-nawet-kilka-tysiecy-zlotych-oto-powod-6871419869879008a.html](https://www.money.pl/podatki/pit-za-2022-rok-z-duzym-zwrotem-matki-dostaja-nawet-kilka-tysiecy-zlotych-oto-powod-6871419869879008a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 15:05:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f1a3866b-db2b-42a6-ba44-e220f7cc8857" width="308" /> W ubiegłym roku rząd wprowadził jedną rewolucję podatkową, a później ją odwołał i wprowadził kolejną. Z tego powodu rozliczenie PIT za 2022 rok jest wyjątkowe. Część osób będzie musiała dopłacić, ale część sporo odzyska. Tak jak niektóre kobiety, pobierające w ubiegłym roku zasiłek macierzyński.

## To koniec spokoju. Ceny wynajmu mieszkań ponownie rosną
 - [https://www.money.pl/gospodarka/to-koniec-spokoju-ceny-wynajmu-mieszkan-ponownie-rosna-6871429049645760a.html](https://www.money.pl/gospodarka/to-koniec-spokoju-ceny-wynajmu-mieszkan-ponownie-rosna-6871429049645760a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 14:36:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5db69017-9cbb-41de-a70a-dbf89837a248" width="308" /> Stawki najmu ponownie rosną. Z raportu Expandera i Rentier.io wynika, że w styczniu były one średnio o 1,3 proc. wyższe niż w grudniu i aż o 25 proc. wyższe niż przed rokiem. Po kilku miesiącach względnej stabilizacji powrócił więc wyraźny wzrost.

## Orlen obniży ceny gazu. Oto kto na tym skorzysta
 - [https://www.money.pl/gospodarka/orlen-obnizy-ceny-gazu-oto-kto-na-tym-skorzysta-6871421570259680a.html](https://www.money.pl/gospodarka/orlen-obnizy-ceny-gazu-oto-kto-na-tym-skorzysta-6871421570259680a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 14:05:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/93d8cb67-01a7-45b2-93c0-955e6181cbb6" width="308" /> Cena gazu sprzedawanego dla tzw. klientów biznesowych, m.in. piekarni, zostanie od 15 marca obniżona o ponad 50 proc. do 353 zł z 650 zł za jedną MWh - poinformował podczas wtorkowej konferencji prasowej prezes PKN Orlen Daniel Obajtek.

## Orlen ogłosił, jaką wypłaci dywidendę z zysku w 2022 r. Kurs akcji mocno w górę
 - [https://www.money.pl/gielda/orlen-oglosil-jaka-wyplaci-dywidende-z-zysku-w-2022-r-kurs-akcji-mocno-w-gore-6871403490642656a.html](https://www.money.pl/gielda/orlen-oglosil-jaka-wyplaci-dywidende-z-zysku-w-2022-r-kurs-akcji-mocno-w-gore-6871403490642656a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 13:16:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b00de987-4823-48ff-ad3e-d37318658cd8" width="308" /> Nowa polityka dywidendowa PKN Orlen zakłada wypłatę dywidendy w wysokości 40 proc. skorygowanych wolnych przepływów pieniężnych – poinformowała spółka. Dywidenda z zysku w 2022 r. wyniesie 5,50 zł. Kurs akcji Orlenu skoczył we wtorek w górę.

## W niebyt odchodzi znienawidzone słowo 2022 r. Rynek ma nowego faworyta
 - [https://www.money.pl/gielda/w-niebyt-odchodzi-znienawidzone-slowo-2022-r-rynek-ma-nowego-faworyta-6871400476105440a.html](https://www.money.pl/gielda/w-niebyt-odchodzi-znienawidzone-slowo-2022-r-rynek-ma-nowego-faworyta-6871400476105440a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 12:51:30+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a5ad932b-4afb-469e-b397-c629e0296a06" width="308" /> Rynek ewidentnie szuka nowego rozdania. Jak wynika z najnowszych szacunków Bloomberga, stagflacja - znienawidzone słowo ekonomistów 2022 r. - została ostatnio zdetronizowane przez dezinflację. Teraz jest to istotny temat zajmujący inwestorów. Kryje się za tym znacznie głębsza zmiana.

## "Bank szpiegów". Krytyczna sytuacja placówki związanej z Rosją
 - [https://www.money.pl/gospodarka/bank-szpiegow-krytyczna-sytuacja-placowki-zwiazanej-z-rosja-6871402977327808a.html](https://www.money.pl/gospodarka/bank-szpiegow-krytyczna-sytuacja-placowki-zwiazanej-z-rosja-6871402977327808a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 12:50:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8aad24a8-462e-43a0-8343-e91ddf02dbc9" width="308" /> Międzynarodowy Bank Inwestycyjny (IIB) z siedzibą w Budapeszcie, który jest nazywany "bankiem szpiegów" i w którym niemal połowa udziałów należy do Rosji, jest w krytycznej sytuacji w związku z nałożonymi na Kreml po agresji na Ukrainę sankcjami - poinformował węgierski portal HVG.

## Wojsko kupuje tysiąc wozów bojowych Borsuk. Zastąpią w armii radzieckie pojazdy
 - [https://www.money.pl/gospodarka/wojsko-kupuje-tysiac-wozow-bojowych-borsuk-zastapia-w-armii-radzieckie-pojazdy-6871397275486944a.html](https://www.money.pl/gospodarka/wojsko-kupuje-tysiac-wozow-bojowych-borsuk-zastapia-w-armii-radzieckie-pojazdy-6871397275486944a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 12:27:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9cddf6f9-7753-4f60-8f6b-11724ed41c51" width="308" /> Wicepremier, szef Ministerstwa Obrony Narodowej Mariusz Błaszczak zatwierdził umowę na dostawę blisko 1400 nowych pojazdów dla wojska, w tym blisko 1000 gąsienicowych bojowych wozów piechoty Borsuk oraz pojazdy towarzyszące.

## Kiedy ruszą wypłaty "trzynastek"? KPRM zabiera głos ws. zaskakującej zapowiedzi premiera
 - [https://www.money.pl/pieniadze/kiedy-rusza-wyplaty-trzynastek-kprm-zabiera-glos-ws-zaskakujacej-zapowiedzi-premiera-6871378393586368a.html](https://www.money.pl/pieniadze/kiedy-rusza-wyplaty-trzynastek-kprm-zabiera-glos-ws-zaskakujacej-zapowiedzi-premiera-6871378393586368a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 11:28:07+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/54f114eb-7a64-454f-bbd0-03b91dfca62d" width="308" /> Trzynasta emerytura trafi do seniorów w maju i czerwcu - zapowiedział w poniedziałek Mateusz Morawiecki. To zaskakujące słowa, bo zgodnie z przepisami pieniądze powinny być wypłacone w kwietniu. I tak właśnie się stanie - we wtorek poinformowało o tym Centrum Informacyjne Rządu.

## Ciemne chmury zbierają się nad dark store'ami. Miasta ich nie chcą. Wylecą też z Warszawy?
 - [https://www.money.pl/gospodarka/ciemne-chmury-zbieraja-sie-nad-dark-storeami-miasta-ich-nie-chca-wyleca-tez-z-warszawy-6871327083088512a.html](https://www.money.pl/gospodarka/ciemne-chmury-zbieraja-sie-nad-dark-storeami-miasta-ich-nie-chca-wyleca-tez-z-warszawy-6871327083088512a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 10:56:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3d008182-f6e8-4656-9fba-649623dba790" width="308" /> Europejskie miasta wypowiadają wojnę rozprzestrzeniającym się w nich dark store'om. Najpierw Amsterdam, a teraz Barcelona zakazują lokowania ich w swoich granicach. Za tą decyzją stoi fakt, że "ciemne sklepy" są uciążliwe dla mieszkańców i szpecą miasto. Czy na taki sam krok zdecyduje się Warszawa?

## Banki bały się darmowego kredytu. Może być jeszcze gorzej
 - [https://www.money.pl/banki/banki-baly-sie-darmowego-kredytu-moze-byc-jeszcze-gorzej-6871186846329472a.html](https://www.money.pl/banki/banki-baly-sie-darmowego-kredytu-moze-byc-jeszcze-gorzej-6871186846329472a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 10:42:36+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5811a406-ba1b-4735-b7a0-90fb3aa56c75" width="308" /> Na banki padł blady strach. Istnieje ryzyko, że wyrok TSUE pozwoli frankowiczom zawalczyć w sądach o znacznie więcej niż darmowy kredyt. Jak nieoficjalnie dowiedział się money.pl, KNF poprosiła przedstawicieli sektora o oszacowanie potencjalnych kosztów dodatkowych roszczeń.

## Rusza autozapis do PPK. Miliony pracowników otrzymają niższą pensję
 - [https://www.money.pl/emerytury/rusza-autozapis-do-ppk-miliony-pracownikow-otrzymaja-nizsza-pensje-6871369180699264a.html](https://www.money.pl/emerytury/rusza-autozapis-do-ppk-miliony-pracownikow-otrzymaja-nizsza-pensje-6871369180699264a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 10:34:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/46dc78e5-9746-4bc6-8173-bdfd13a238f6" width="308" /> 1 marca rusza autozapis do Pracowniczych Planów Kapitałowych, obejmie 8 mln pracowników – powiedział wiceprezes Polskiego Funduszu Rozwoju Bartosz Marczuk. Jeśli do końca lutego pracownicy nie złożą deklaracji o rezygnacji z programu, to automatycznie zostaną do niego zapisani. Czy warto zostać w PPK?

## Ostatni dzwonek dla wielu emerytów i rencistów. Lepiej nie podpaść ZUS-owi
 - [https://www.money.pl/emerytury/ostatni-dzwonek-dla-wielu-emerytow-i-rencistow-lepiej-nie-podpasc-zus-owi-6871362968115808a.html](https://www.money.pl/emerytury/ostatni-dzwonek-dla-wielu-emerytow-i-rencistow-lepiej-nie-podpasc-zus-owi-6871362968115808a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 10:07:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/44e9efcd-3ff3-4162-af3d-4ef4a50aeb5b" width="308" /> Mijają ostatnie godziny na złożenie zaświadczenia o przychodach przez wielu dorabiających emerytów i rencistów. Lepiej nie przeoczyć tego terminu. Zakład Ubezpieczeń Społecznych w przeciwnym razie może upomnieć się o ogromny zwrot świadczeń.

## Są najnowsze dane o PKB Polski. Spory spadek
 - [https://www.money.pl/gospodarka/produkt-krajowy-brutto-iv-kwartal-2022-r-pkb-polski-wstepny-szacunek-gus-6871336678046304a.html](https://www.money.pl/gospodarka/produkt-krajowy-brutto-iv-kwartal-2022-r-pkb-polski-wstepny-szacunek-gus-6871336678046304a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 09:01:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ec69a9e9-3994-451b-9c34-35aa4e270aaf" width="308" /> Produktu krajowy brutto w IV kwartale 2022 r. zmniejszył się o 2,4 proc. w porównaniu z poprzednim kwartałem i był wyższy niż przed rokiem o 0,4 proc. – podał GUS.

## Dostawy ropy z Rosji wstrzymane. "Dobry dzień dla Polski. Świat wreszcie to zrozumiał"
 - [https://www.money.pl/gospodarka/dostawy-ropy-z-rosji-wstrzymane-dobry-dzien-dla-polski-swiat-wreszcie-to-zrozumial-6871345621091969v.html](https://www.money.pl/gospodarka/dostawy-ropy-z-rosji-wstrzymane-dobry-dzien-dla-polski-swiat-wreszcie-to-zrozumial-6871345621091969v.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 08:58:03+00:00

<img src="https://i.wpimg.pl/308x/wptv-upload-api.wpcdn.pl/7e0e35c0-2bc4-44bd-88a0-99bcda9aa68e.jpg" width="308" /> - Zerwanie z dostawami surowców z Rosji to jedyna słuszna decyzja, to dobry dzień dla Polski – powiedział w programie "Newsroom" WP Janusz Steinhoff, były wicepremier i minister gospodarki. – Polska jak każdy kraj UE powinna odejść od importu nośników energii z Rosji. Rosja jest krajem niedemokratycznym, jest krajem, który nie przestrzega żadnych zasad szanowanych w cywilizowanym świecie. W związku z tym nigdy nie powinna być traktowana jako wiarygodny partner, który dostarcza surowce. Myślę, że wreszcie świat zrozumiał, że szukanie kompromisu tak, gdzie go nie ma, jest droga donikąd. Rosja eskaluje swoje imperialne narzędzia polityki i z tego trzeba wyciągnąć wnioski. Perturbacje na rynku energii, węgla sprawiły, że ceny poszły w górę. Takie są konsekwencje uniezależniania się od Rosji. Ale to będzie nasz wkład w walkę z rosyjskim reżimem i trzeba mieć świadomość, że konsekwencje dla gospodarek europejskich będą czasowo odczuwalne. Orlen sprowadzał większość ropy z Rosji ropociągiem „Przyjaźń”, ale nie obawiałbym się wzrostów na stacjach paliw, bo na tym rynku jest duża konkurencja. Bardziej obawiam się wpływu na rynek monopolisty, czyli Orlenu. To jest główna przyczyna tego, że na stacjach wciąż płacimy dużo. To jest podmiot, który ma 70-80 proc. hurtowego rynku paliw i 90 proc. hurtowego rynku gazu. Budowanie tego molochu odbywa się ze szkodą dla polskiej gospodarki i poziomu życia obywateli. Ceny paliw płynnych nie są cenami rynkowymi. Grudzień udowodnił, że cenami paliw płynnych można sterować w oparciu o kryteria polityczne. Nie jestem w stanie od dłuższego już czasu traktować wypowiedzi pana Obajtka poważnie. On nie jest od kształtowania cen paliw, od tego jest rynek. Rynek reguluje ceny, a państwo ma funkcję regulacyjną i musi dbać o konkurencyjne rynki. Ogon nie może machać psem - kwituje ekspert.

## Kursy walut 28.02.2023. Wtorkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-28-02-2023-wtorkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6871312306596480a.html](https://www.money.pl/pieniadze/kursy-walut-28-02-2023-wtorkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6871312306596480a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 06:41:13+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 28.02.2023. We wtorek za jednego dolara (USD) zapłacimy 4.45 zł. Cena jednego funta szterlinga (GBP) to 5.36 zł, a franka szwajcarskiego (CHF) 4.75 zł. Z kolei euro (EUR) możemy zakupić za 4.71 zł.

## Rosną wydatki na przywileje emerytalne. Eksperci wskazują niebezpieczeństwo
 - [https://www.money.pl/emerytury/rosna-wydatki-na-przywileje-emerytalne-eksperci-wskazuja-niebezpieczenstwo-6871309449419392a.html](https://www.money.pl/emerytury/rosna-wydatki-na-przywileje-emerytalne-eksperci-wskazuja-niebezpieczenstwo-6871309449419392a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 06:29:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/046552f8-d887-4432-ae57-10cd8c0b0fa3" width="308" /> W tym roku dotacja budżetowa na emerytury i renty uprzywilejowanych grup zawodowych wzrośnie o 4 mld zł. Eksperci przekonują, że potrzeba zmian w systemie emerytalnym. Ostrzegają, że bez tego nie wytrzyma, przez co coraz więcej osób będzie dostawało minimalne świadczenia.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 28.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-28-02-2023-6871302520040064a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-28-02-2023-6871302520040064a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 06:01:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 28.02.2023. We wtorek za jedno euro (EUR) trzeba zapłacić 4.7145 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 28.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-28-02-2023-6871302518901344a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-28-02-2023-6871302518901344a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 06:01:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 28.02.2023. We wtorek za jednego franka (CHF) trzeba zapłacić 4.7533 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 28.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-28-02-2023-6871302494845536a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-28-02-2023-6871302494845536a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 06:01:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 28.02.2023. We wtorek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.363 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 28.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-28-02-2023-6871302475307616a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-28-02-2023-6871302475307616a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-28 06:01:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 28.02.2023. We wtorek za jednego dolara (USD) trzeba zapłacić 4.4544 zł.

