# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## No Evidence US Weapons Being Diverted, Misused by Ukraine: Pentagon
 - [https://www.theepochtimes.com/no-evidence-us-weapons-being-diverted-misused-by-ukraine-pentagon_5090116.html](https://www.theepochtimes.com/no-evidence-us-weapons-being-diverted-misused-by-ukraine-pentagon_5090116.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 23:23:10+00:00

Ukrainian service members are shown with an infantry fighting vehicle near the frontline town of Bakhmut, amid Russia's invasion of Ukraine, in the Donetsk region on Feb. 25, 2023. (Yan Dobronosov/Reuters)

## National Broadcaster to Re-Train Journalists on Impartiality After Pressure Over “Inaccurate” Alice Springs Report
 - [https://www.theepochtimes.com/national-broadcaster-to-re-train-journalists-on-impartiality-after-pressure-over-inaccurate-alice-springs-report_5087857.html](https://www.theepochtimes.com/national-broadcaster-to-re-train-journalists-on-impartiality-after-pressure-over-inaccurate-alice-springs-report_5087857.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 23:22:54+00:00

An employee walks past the logo of the ABC located at the main entrance to the ABC building located at Ultimo in Sydney, Australia, on June 5, 2019. (AAP/David Gray)

## Canada’s Economy Flatlined in Last Quarter of 2022 Following Year of GDP Growth: StatCan
 - [https://www.theepochtimes.com/canadas-economy-flatlined-in-last-quarter-of-2022-following-year-of-gdp-growth-statcan_5089427.html](https://www.theepochtimes.com/canadas-economy-flatlined-in-last-quarter-of-2022-following-year-of-gdp-growth-statcan_5089427.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 22:37:31+00:00

A construction worker works from a lift at a new housing development in Ottawa on Oct. 14, 2022. A new report from Statistics Canada indicates the economy flatlined in the last quarter of 2022. (The Canadian Press/Sean Kilpatrick)

## China’s Calling for Peace in Ukraine Could Imply It Needs Russia’s Backing Elsewhere: Former Executive VP of Fox News
 - [https://www.theepochtimes.com/chinas-calling-for-peace-in-ukraine-could-imply-it-needs-russias-backing-elsewhere-former-executive-vp-of-fox-news_5080464.html](https://www.theepochtimes.com/chinas-calling-for-peace-in-ukraine-could-imply-it-needs-russias-backing-elsewhere-former-executive-vp-of-fox-news_5080464.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 21:51:37+00:00

Russian President Vladimir Putin meets with China's Director of the Office of the Central Foreign Affairs Commission, Wang Yi, at the Kremlin in Moscow on Feb. 22, 2023. (Anton Novoderezhkin/Sputnik/AFP via Getty Images)

## Patrick Brown Hosts $1,700 per Ticket Fundraiser for Leadership Debt Without Party
 - [https://www.theepochtimes.com/patrick-brown-hosts-1700-per-ticket-fundraiser-for-leadership-debt-without-party_5089896.html](https://www.theepochtimes.com/patrick-brown-hosts-1700-per-ticket-fundraiser-for-leadership-debt-without-party_5089896.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 21:50:11+00:00

Brampton Mayor Patrick Brown speaks during a press conference to announce his intention to re-run for mayorship, at city hall in Brampton, Ont., on July 18, 2022. (The Canadian Press/Cole Burston)

## House Republicans Aim to Make Canada-US Border Part of National Security Debate
 - [https://www.theepochtimes.com/house-republicans-aim-to-make-canada-us-border-part-of-national-security-debate_5089881.html](https://www.theepochtimes.com/house-republicans-aim-to-make-canada-us-border-part-of-national-security-debate_5089881.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 21:47:24+00:00

A border marker is shown just outside of Emerson, Man. on Jan. 20, 2022.  (The Canadian Press/John Woods)

## John Robson: Attempts to Trivialize Chinese Election Meddling Will Have Serious Consequences
 - [https://www.theepochtimes.com/john-robson-attempts-to-trivialize-chinese-election-meddling-will-have-serious-consequences_5089140.html](https://www.theepochtimes.com/john-robson-attempts-to-trivialize-chinese-election-meddling-will-have-serious-consequences_5089140.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 21:29:10+00:00

Prime Minister Justin Trudeau takes part in a town hall meeting with university students in Halifax on Feb. 23, 2023. (The Canadian Press/Riley Smith)

## Singh Says Allegations That Foreign Interference Impacted Some Ridings ‘Is Very Serious’
 - [https://www.theepochtimes.com/singh-says-allegations-that-foreign-interference-impacted-some-ridings-is-very-serious_5088696.html](https://www.theepochtimes.com/singh-says-allegations-that-foreign-interference-impacted-some-ridings-is-very-serious_5088696.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 21:29:07+00:00

NDP leader Jagmeet Singh speaks to reporters on Parliament Hill in Ottawa on Dec. 7, 2022. (The Canadian Press/Sean Kilpatrick)

## US Committed to WHO Pandemic Accord, Ambassador Says
 - [https://www.theepochtimes.com/us-committed-to-who-pandemic-accord-ambassador-says_5088716.html](https://www.theepochtimes.com/us-committed-to-who-pandemic-accord-ambassador-says_5088716.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 21:17:58+00:00

The flag of the World Health Organization (WHO) at their headquarters in Geneva on March 5, 2021. (Fabrice Coffrini/AFP via Getty Images)

## Putin Signs Bill to Suspend Last Nuclear Arms Treaty With US
 - [https://www.theepochtimes.com/putin-signs-bill-to-suspend-last-nuclear-arms-treaty-with-us_5089430.html](https://www.theepochtimes.com/putin-signs-bill-to-suspend-last-nuclear-arms-treaty-with-us_5089430.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 20:47:33+00:00

Russian President Vladimir Putin listens to Yuri Borisov, the new CEO of the Russian State Space Corporation "Roscosmos," at the Kremlin in Moscow on July 26, 2022. (Mikhail Klimentyev/Sputnik/Kremlin Pool Photo via AP)

## Liberals, Conservatives, NDP Start Stepping Back From TikTok Video App
 - [https://www.theepochtimes.com/liberals-conservatives-ndp-start-stepping-back-from-tiktok-video-app_5089363.html](https://www.theepochtimes.com/liberals-conservatives-ndp-start-stepping-back-from-tiktok-video-app_5089363.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 19:43:35+00:00

TikTok app is seen on a smartphone in this illustration taken on July 13, 2021. (Dado Ruvic/Illustration/Reuters)

## Feds to Require Biggest Suppliers to Disclose Emissions, Set Carbon Footprint Targets
 - [https://www.theepochtimes.com/feds-to-require-biggest-suppliers-to-disclose-emissions-set-carbon-footprint-targets_5089350.html](https://www.theepochtimes.com/feds-to-require-biggest-suppliers-to-disclose-emissions-set-carbon-footprint-targets_5089350.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 19:40:34+00:00

President of the Treasury Board Mona Fortier speaks in the foyer of the House of Commons on Parliament Hill in Ottawa, Dec. 15, 2022. (The Canadian Press/Sean Kilpatrick)

## Brian Giesbrecht: The Genocide Lie
 - [https://www.theepochtimes.com/brian-giesbrecht-the-genocide-lie_5088892.html](https://www.theepochtimes.com/brian-giesbrecht-the-genocide-lie_5088892.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 19:14:50+00:00

The House of Commons chamber in Ottawa in a file photo. (The Canadian Press/Adrian Wyld)

## Protesters Concerned About Beijing Interference Hold Rally Outside BC Organization Probed by RCMP
 - [https://www.theepochtimes.com/protesters-concerned-about-beijing-interference-hold-rally-outside-bc-organization-probed-by-rcmp_5085543.html](https://www.theepochtimes.com/protesters-concerned-about-beijing-interference-hold-rally-outside-bc-organization-probed-by-rcmp_5085543.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 19:12:09+00:00

Protesters at a rally outside of the Wenzhou Friendship Society in Richmond, B.C., on Feb. 25, 2023, were seen holding signs that read "Expel China's Spies" among other slogans. The protest was held to raise concerns about Beijing's interference in Canada following media reports of an RCMP investigation at the building. (Vivian Yu/NTD)

## Commons Committee Summons Google Execs on News Links Blocking
 - [https://www.theepochtimes.com/commons-committee-summons-google-execs-on-news-links-blocking_5089133.html](https://www.theepochtimes.com/commons-committee-summons-google-execs-on-news-links-blocking_5089133.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 19:07:40+00:00

Google's logo on a tablet screen. (Kirill Kudryavtsev/AFP via Getty Images)

## The ‘1619 Project’ Is Wrong About Capitalism, but Not in the Way You May Think
 - [https://www.theepochtimes.com/the-1619-project-is-wrong-about-capitalism-but-not-in-the-way-you-may-think_5088673.html](https://www.theepochtimes.com/the-1619-project-is-wrong-about-capitalism-but-not-in-the-way-you-may-think_5088673.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 18:29:15+00:00

The book "The 1619 Project: A New Origin Story" is displayed at a bookstore in New York on Nov. 17, 2021. (Spencer Platt/Getty Images)

## Vermont Officials Investigating After Man Dies Crossing Border From Quebec
 - [https://www.theepochtimes.com/vermont-officials-investigating-after-man-dies-crossing-border-from-quebec_5088992.html](https://www.theepochtimes.com/vermont-officials-investigating-after-man-dies-crossing-border-from-quebec_5088992.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 18:08:12+00:00

Photo shows the headquarters of the U.S. border patrol's Swanton Sector in Swanton, Feb. 10, 2020. (The Canadian Press/AP-Wilson Ring)

## Criminals Grooming Children With Fast Food Amid Cost of Living Crisis
 - [https://www.theepochtimes.com/criminals-grooming-children-with-fast-food-amid-cost-of-living-crisis_5088809.html](https://www.theepochtimes.com/criminals-grooming-children-with-fast-food-amid-cost-of-living-crisis_5088809.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 18:08:09+00:00

Merseyside Police perform an early morning raid on a home in Liverpool as part of Operation Toxic to infiltrate county lines drug dealing, on Dec. 6, 2021. (Christopher Furlong/POOL/AFP via Getty Images)

## Quebec Follows Federal Lead, Bans TikTok Application on Government Cellphones
 - [https://www.theepochtimes.com/quebec-follows-federal-lead-bans-tiktok-application-on-government-cellphones_5088972.html](https://www.theepochtimes.com/quebec-follows-federal-lead-bans-tiktok-application-on-government-cellphones_5088972.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 18:04:52+00:00

The TikTok startup page is displayed on an iPhone in Ottawa on Feb. 27, 2023. (The Canadian Press/Sean Kilpatrick)

## LIVE NOW: USMCA: Building more integrated, resilient, and secure North American supply chains: A Brookings conversation
 - [https://www.theepochtimes.com/usmca-building-more-integrated-resilient-and-secure-north-american-supply-chains-a-brookings-conversation_5088420.html](https://www.theepochtimes.com/usmca-building-more-integrated-resilient-and-secure-north-american-supply-chains-a-brookings-conversation_5088420.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:55:06+00:00

Members of Congress and farmers from across the country rally for the United States-Mexico-Canada Agreement (USMCA) on the National Mall in Washington on Sept. 12, 2019. (Samira Bouaou/The Epoch Times)

## Tories Blast PM’s Choice of Former Trudeau Foundation Head to Write Report on Election Interference Amid Latest CSIS Leak
 - [https://www.theepochtimes.com/tories-blast-pms-choice-of-former-trudeau-foundation-head-to-write-report-on-election-interference-amid-latest-csis-leak_5087592.html](https://www.theepochtimes.com/tories-blast-pms-choice-of-former-trudeau-foundation-head-to-write-report-on-election-interference-amid-latest-csis-leak_5087592.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:52:39+00:00

Prime Minister Justin Trudeau stands alongside the Minister of National Defence Anita Anand in Toronto on Feb. 24, 2023.  (The Canadian Press/Chris Young)

## UK Police Search for Infant After Missing Couple Arrested
 - [https://www.theepochtimes.com/uk-police-search-for-infant-after-missing-couple-arrested_5088476.html](https://www.theepochtimes.com/uk-police-search-for-infant-after-missing-couple-arrested_5088476.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:48:32+00:00

Mark Gordon and Constance Marten in this handout combination photo provided on Jan. 18, 2023. (Metropolitan Police via AP)

## Russians Claim to Have Encircled Bakhmut, Kyiv Calls Situation ‘Extremely Tense’
 - [https://www.theepochtimes.com/russians-claim-to-have-encircled-bakhmut-kyiv-calls-situation-extremely-tense_5088637.html](https://www.theepochtimes.com/russians-claim-to-have-encircled-bakhmut-kyiv-calls-situation-extremely-tense_5088637.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:35:41+00:00

Smoke during the shelling of the front line city of Bakhmut in Donetsk region, Ukraine, on Feb. 9, 2023. (Yevhen Titov/Reuters)

## No Clear Alternative to Jet Fuel to Support Present Demand Under UK’s Net Zero Plans: Report
 - [https://www.theepochtimes.com/no-clear-alternative-to-jet-fuel-to-support-present-demand-under-uks-net-zero-plans-report_5088072.html](https://www.theepochtimes.com/no-clear-alternative-to-jet-fuel-to-support-present-demand-under-uks-net-zero-plans-report_5088072.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:31:53+00:00

A plane approaches landing over the rooftops of nearby houses at Heathrow Airport in London, on Oct. 25, 2016. (Frank Augstein/AP Photo)

## Massive Forest Fires Rage on in Eastern Cuba
 - [https://www.theepochtimes.com/massive-forest-fires-rage-on-in-eastern-cuba_5088105.html](https://www.theepochtimes.com/massive-forest-fires-rage-on-in-eastern-cuba_5088105.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:26:48+00:00

Smoke from burning vegetation rises in Pinares de Mayari, Cuba, on Feb. 23, 2023. (Juan Pablo Carreras/Reuters)

## US Should Not Let WHO ‘Usurp’ Its Pandemic Response Authority, Says Sen. Roger Marshall
 - [https://www.theepochtimes.com/us-should-not-let-who-usurp-its-pandemic-response-authority-says-sen-roger-marshall_5088805.html](https://www.theepochtimes.com/us-should-not-let-who-usurp-its-pandemic-response-authority-says-sen-roger-marshall_5088805.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:26:21+00:00

Sen. Roger Marshall (R-Kan.) is shown speaking in Washington in this file photograph. (Greg Nash/Pool/AFP via Getty Images)

## Pesticide Ban Could Lead to Crop Failure, Higher Food Prices: Alberta Ag Minister
 - [https://www.theepochtimes.com/pesticide-ban-could-lead-to-crop-failure-higher-food-prices-alberta-ag-minister_5085718.html](https://www.theepochtimes.com/pesticide-ban-could-lead-to-crop-failure-higher-food-prices-alberta-ag-minister_5085718.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:18:30+00:00

Farmer and Agricultural Producers Association of Saskatchewan President Todd Lewis inspects canola at his farm near Gray, Sask., on July 29, 2021. (Kayle Neis/The Canadian Press)

## UK Won’t Be Deterred by Putin’s Nuclear Threats, National Security Adviser Says
 - [https://www.theepochtimes.com/uk-wont-be-deterred-by-putins-nuclear-threats-national-security-adviser-says_5088034.html](https://www.theepochtimes.com/uk-wont-be-deterred-by-putins-nuclear-threats-national-security-adviser-says_5088034.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:17:10+00:00

Sir Tim Barrow (L), national security adviser for the UK, leaves 10 Downing Street following a bilateral meeting with Ukrainian President Volodymyr Zelenskyy, in London, on Feb. 8, 2023. (Leon Neal/Getty Images)

## Federal Departments Spent Over $2 Million on TikTok Ads Since 2020: Document
 - [https://www.theepochtimes.com/federal-departments-spent-over-2-million-on-tiktok-ads-since-2020-document_5088350.html](https://www.theepochtimes.com/federal-departments-spent-over-2-million-on-tiktok-ads-since-2020-document_5088350.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:17:01+00:00

The download page for the TikTok app is displayed on an Apple iPhone in Washington DC, on Aug. 7, 2020. (Drew Angerer/Getty Images)

## Terrorism in Pakistan Got Worse in 2021: Newly Released US Report
 - [https://www.theepochtimes.com/terrorism-in-pakistan-got-worse-in-2021-newly-released-us-report_5087799.html](https://www.theepochtimes.com/terrorism-in-pakistan-got-worse-in-2021-newly-released-us-report_5087799.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:16:44+00:00

Security officials and rescue workers search for bodies at the site of suicide bombing in Peshawar, Pakistan, on Jan. 30, 2023. (Zubair Khan/AP Photo)

## Argentine Fishermen Find Remains of Missing Man Inside Shark
 - [https://www.theepochtimes.com/argentine-fishermen-find-remains-of-missing-man-inside-shark_5088447.html](https://www.theepochtimes.com/argentine-fishermen-find-remains-of-missing-man-inside-shark_5088447.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 17:08:11+00:00

File photo of the shark net. (Michele Spatari/AFP via Getty Images)

## Transgender Rapist Jailed in the UK for 8 Years
 - [https://www.theepochtimes.com/transgender-rapist-jailed-in-the-uk-for-8-years_5088415.html](https://www.theepochtimes.com/transgender-rapist-jailed-in-the-uk-for-8-years_5088415.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 16:44:58+00:00

Isla Bryson, 31, formerly known as Adam Graham, from Clydebank, West Dunbartonshire, arrives at the High Court in Glasgow, on Jan. 23, 2023. (PA Media)

## UK Households Buying Less Food as Grocery Inflation Continues to Soar
 - [https://www.theepochtimes.com/uk-households-buying-less-food-as-grocery-inflation-continues-to-soar_5088410.html](https://www.theepochtimes.com/uk-households-buying-less-food-as-grocery-inflation-continues-to-soar_5088410.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 15:55:34+00:00

A customer shops for meat at a Sainsbury's supermarket in Walthamstow, east London, on Feb. 13, 2022. (Tolga Akmen /AFP via Getty Images)

## Nissan Recalls Over 800,000 SUVs; Key Defect Can Cut Off Engine
 - [https://www.theepochtimes.com/nissan-recalls-over-800000-suvs-key-defect-can-cut-off-engine_5088417.html](https://www.theepochtimes.com/nissan-recalls-over-800000-suvs-key-defect-can-cut-off-engine_5088417.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 15:50:47+00:00

A Nissan logo is seen on a car at its showroom in Tokyo on Feb. 21, 2023. (Shuji Kajiyama/AP Photo)

## Russians Tighten Noose on Ukraine’s Bakhmut, Putin Warns of Western Espionage
 - [https://www.theepochtimes.com/russians-tighten-noose-on-ukraines-bakhmut-putin-warns-of-western-espionage_5088069.html](https://www.theepochtimes.com/russians-tighten-noose-on-ukraines-bakhmut-putin-warns-of-western-espionage_5088069.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 15:30:14+00:00

Ukrainian service members next to an infantry fighting vehicle near the frontline town of Bakhmut in Donetsk region, Ukraine, on Feb. 25, 2023. (Yan Dobronosov/Reuters)

## Canadian Dental Association Releases Recommendations for Feds on Dental Care
 - [https://www.theepochtimes.com/canadian-dental-association-releases-recommendations-for-feds-on-dental-care_5088522.html](https://www.theepochtimes.com/canadian-dental-association-releases-recommendations-for-feds-on-dental-care_5088522.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 15:24:46+00:00

A dentist holds instruments in Skokie, Ill., on June 12, 2020. (The Canadian Press/Charles Rex Arbogast)

## American Citizen Fatally Shot in Violence in West Bank: US State Department
 - [https://www.theepochtimes.com/american-citizen-fatally-shot-in-violence-in-west-bank-us-state-department_5087772.html](https://www.theepochtimes.com/american-citizen-fatally-shot-in-violence-in-west-bank-us-state-department_5087772.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 15:02:24+00:00

Israeli Border police officers walk outside the house of Palestinian gunman Khaire Alkam in A-Tur in East Jerusalem, after Alkam shot and killed seven people near a synagogue in Neve Yaacov, on Jan. 28, 2023. (Ammar Awad/Reuters)

## BC Announces Temporary TikTok Ban for Government-Issued Mobile Devices
 - [https://www.theepochtimes.com/bc-announces-temporary-tiktok-ban-for-government-issued-mobile-devices_5088200.html](https://www.theepochtimes.com/bc-announces-temporary-tiktok-ban-for-government-issued-mobile-devices_5088200.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 14:09:19+00:00

The TikTok app logo is pictured in Tokyo on Sept. 28, 2020. (Kiichiro Sato/AP Photo)

## Japan’s Factory Output Posts Biggest Fall in 8 Months on Weak Autos, Chips Sectors
 - [https://www.theepochtimes.com/japans-factory-output-posts-biggest-fall-in-8-months-on-weak-autos-chips-sectors_5088040.html](https://www.theepochtimes.com/japans-factory-output-posts-biggest-fall-in-8-months-on-weak-autos-chips-sectors_5088040.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 13:55:02+00:00

A worker checks machinery at a factory in Higashiosaka, Japan, on June 23, 2022. (Sakura Murakami/Reuters)

## UK and US Vow to Bolster Energy Independence, End Reliance on Russian Energy
 - [https://www.theepochtimes.com/uk-and-us-vow-to-bolster-energy-independence-end-reliance-on-russian-energy_5088183.html](https://www.theepochtimes.com/uk-and-us-vow-to-bolster-energy-independence-end-reliance-on-russian-energy_5088183.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 13:28:23+00:00

Secretary of State for Energy Security and Net Zero Grant Shapps leaves Downing Street, London, on Feb. 27, 2023. (James Manning/PA Media)

## Northern Ireland Police Review Alleged New IRA’s Claim of Responsibility in Caldwell Shooting
 - [https://www.theepochtimes.com/northern-ireland-police-review-alleged-new-iras-claim-of-responsibility-in-caldwell-shooting_5085740.html](https://www.theepochtimes.com/northern-ireland-police-review-alleged-new-iras-claim-of-responsibility-in-caldwell-shooting_5085740.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 13:19:07+00:00

Detective Chief Inspector John Caldwell in Belfast on Nov. 17, 2020. (PA Media)

## Organ Harvesting Trial Accused Admits Lying About His Own Kidney Donor Being His Cousin
 - [https://www.theepochtimes.com/organ-harvesting-trial-accused-admits-lying-about-his-own-kidney-donor-being-his-cousin_5085307.html](https://www.theepochtimes.com/organ-harvesting-trial-accused-admits-lying-about-his-own-kidney-donor-being-his-cousin_5085307.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 13:00:04+00:00

Undated image of Sonia Ekweremadu sitting next to a man who allegedly donated a kidney to her, in a restaurant in London in February 2022. (Metropolitan Police)

## Only ‘A Matter of Weeks’ Before Iran Could Be Able to Manufacture Nuclear Weapons: CIA Chief
 - [https://www.theepochtimes.com/only-a-matter-of-weeks-before-iran-could-be-able-to-manufacture-nuclear-weapons-cia-chief_5088168.html](https://www.theepochtimes.com/only-a-matter-of-weeks-before-iran-could-be-able-to-manufacture-nuclear-weapons-cia-chief_5088168.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 12:38:41+00:00

An Iranian flag is seen at a nuclear power plant in Iran, on Nov. 10, 2019. (Atta Kenare/AFP via Getty Images)

## White House: China’s Peace Plan for Ukraine and Russia Is ‘Not a Sustainable Option’
 - [https://www.theepochtimes.com/white-house-chinas-peace-plan-for-ukraine-and-russia-is-not-a-sustainable-option_5087791.html](https://www.theepochtimes.com/white-house-chinas-peace-plan-for-ukraine-and-russia-is-not-a-sustainable-option_5087791.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 10:52:34+00:00

National Security Council spokesman John Kirby speaks during the daily press briefing in the James S. Brady Press Briefing Room of the White House in Washington, on Feb. 27, 2023. (Saul Loeb/AFP via Getty Images)

## Taliban: 2 Senior ISIS Members Killed in Afghanistan
 - [https://www.theepochtimes.com/taliban-2-senior-isis-members-killed-in-afghanistan_5085190.html](https://www.theepochtimes.com/taliban-2-senior-isis-members-killed-in-afghanistan_5085190.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 09:33:19+00:00

The locator map for Afghanistan with its capital, Kabul. (AP Photo)

## Hundreds Blocked on Croatia Roads as Snowstorm Spurs Chaos
 - [https://www.theepochtimes.com/hundreds-blocked-on-croatia-roads-as-snowstorm-spurs-chaos_5086369.html](https://www.theepochtimes.com/hundreds-blocked-on-croatia-roads-as-snowstorm-spurs-chaos_5086369.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 09:22:00+00:00

A snowplow moves snow at a gas station near Ravna Gora, Croatia, on Feb. 27, 2023. (AP Photo)

## Yellen in Surprise Visit to Kyiv to Reaffirm US Economic Aid to Ukraine
 - [https://www.theepochtimes.com/yellen-in-surprise-visit-to-kyiv-to-reaffirm-us-economic-aid-to-ukraine_5085702.html](https://www.theepochtimes.com/yellen-in-surprise-visit-to-kyiv-to-reaffirm-us-economic-aid-to-ukraine_5085702.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 08:38:02+00:00

Ukraine's President Volodymyr Zelenskyy welcomes U.S. Treasury Secretary Janet Yellen (R) in Kyiv, Ukraine, on Feb. 27, 2023. (Ukrainian Presidential Press Service/Handout via Reuters)

## Mexican Troops, Border Residents Clash After 5 Shot, Killed
 - [https://www.theepochtimes.com/mexican-troops-border-residents-clash-after-5-shot-killed_5086465.html](https://www.theepochtimes.com/mexican-troops-border-residents-clash-after-5-shot-killed_5086465.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 08:09:49+00:00

Members of the Mexican Army in a file photo. (Nicolas Asfouri/AFP via Getty Images)

## ‘No Hostile Intent’ Toward North Korea, US Says of Its Support for Regional Allies
 - [https://www.theepochtimes.com/no-hostile-intent-toward-north-korea-us-says-of-its-support-for-regional-allies_5087452.html](https://www.theepochtimes.com/no-hostile-intent-toward-north-korea-us-says-of-its-support-for-regional-allies_5087452.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 07:13:47+00:00

State Department spokesman Ned Price speaks on the situation in Afghanistan at the State Department in Washington, D.C., on Aug. 18, 2021. (ANDREW HARNIK/POOL/AFP via Getty Images)

## Ban on Domestic Use of Silica on the Cards
 - [https://www.theepochtimes.com/ban-on-domestic-use-of-silica-on-the-cards_5087802.html](https://www.theepochtimes.com/ban-on-domestic-use-of-silica-on-the-cards_5087802.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 07:08:09+00:00

Employment and Workplace Minister Tony Burke speaks during the jobs and skills summit at Parliament House in Canberra, Australia, on Sept. 1, 2022. (Martin Ollman/Getty Images)

## Tax Rates Doubled for Pension Fund Accounts With Over $3 Million
 - [https://www.theepochtimes.com/tax-rates-doubled-for-pension-fund-accounts-with-over-3-million_5087572.html](https://www.theepochtimes.com/tax-rates-doubled-for-pension-fund-accounts-with-over-3-million_5087572.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 06:31:15+00:00

An elderly couple walk through a park in Sydney, Australia on, April 30, 2017. (AAP Image/Paul Miller)

## State Department Says Biden and Senior Officials Have ‘Repeatedly’ Probed China on Origins of COVID
 - [https://www.theepochtimes.com/state-department-says-biden-and-senior-officials-have-repeatedly-probed-china-on-origins-of-covid_5087015.html](https://www.theepochtimes.com/state-department-says-biden-and-senior-officials-have-repeatedly-probed-china-on-origins-of-covid_5087015.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 06:16:49+00:00

U.S. State Department spokesman Ned Price holds a press briefing on Afghanistan at the State Department in Washington, on Aug. 16, 2021. (Kevin Lamarque/Pool/AFP via Getty Images)

## New Bill Would ‘Protect American Sovereignty Against WHO’: GOP Senators
 - [https://www.theepochtimes.com/new-bill-would-protect-american-sovereignty-against-who-gop-senators_5086494.html](https://www.theepochtimes.com/new-bill-would-protect-american-sovereignty-against-who-gop-senators_5086494.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 06:09:09+00:00

Committee Chairman Ron Johnson (R-Wis.) questions Department of Justice Inspector General Michael Horowitz during a Senate Committee On Homeland Security And Governmental Affairs hearing at the U.S. Capitol in Washington, D.C., on Dec. 18, 2019. (Samuel Corum/Getty Images)

## China’s ‘Peace Plan’ Reveals True Intentions
 - [https://www.theepochtimes.com/chinas-peace-plan-reveals-true-intentions_5087655.html](https://www.theepochtimes.com/chinas-peace-plan-reveals-true-intentions_5087655.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 06:02:43+00:00

Russian President Vladimir Putin (L) gestures while speaking to Chinese leader Xi Jinping during the Shanghai Cooperation Organization (SCO) summit in Samarkand, Uzbekistan, on Sept. 16, 2022. (Sergei Bobylev, Sputnik, Kremlin Pool Photo via AP)

## Canada Pension Board Invests in TikTok’s Chinese Parent Firm; App Just Banned on Gov’t Devices Over Security Risks
 - [https://www.theepochtimes.com/canada-pension-board-invests-in-tiktoks-chinese-parent-firm-app-just-banned-on-govt-devices-over-security-risks_5087692.html](https://www.theepochtimes.com/canada-pension-board-invests-in-tiktoks-chinese-parent-firm-app-just-banned-on-govt-devices-over-security-risks_5087692.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 05:19:33+00:00

A woman walks past a building belonging to ByteDance, the parent company of video sharing app TikTok, in Beijing on Sept. 16, 2020. (Greg Baker/AFP via Getty Images)

## Sydney Rolls Out New Type of Charging Station to Boost Electric Vehicle Adoption
 - [https://www.theepochtimes.com/sydney-rolls-out-new-type-of-charging-station-to-boost-electric-vehicle-adoption_5087654.html](https://www.theepochtimes.com/sydney-rolls-out-new-type-of-charging-station-to-boost-electric-vehicle-adoption_5087654.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 04:59:52+00:00

The first Ausgrid EVX electric vehicle charger at Dixon Park in Newcastle, Australia, Dec. 19, 2022. (AAP Image/Supplied by Ausgrid)

## US Gives More Than $400 Million in New Yemen Aid, Bringing Total to $5.4 Billion
 - [https://www.theepochtimes.com/us-gives-more-than-400-million-in-new-yemen-aid-bringing-total-to-5-4-billion_5086525.html](https://www.theepochtimes.com/us-gives-more-than-400-million-in-new-yemen-aid-bringing-total-to-5-4-billion_5086525.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 04:58:06+00:00

U.S. Secretary of State Antony Blinken speaks during a Security Council meeting concerning the war in Ukraine at United Nations headquarters in New York on Feb. 24, 2023. (Michael M. Santiago/Getty Images)

## Alberta Government Claims Reduced Hospital Wait Times, Faster EMS Response With 90 Day Health Care Update
 - [https://www.theepochtimes.com/alberta-government-claims-reduced-hospital-wait-times-faster-ems-response-with-90-day-health-care-update_5087659.html](https://www.theepochtimes.com/alberta-government-claims-reduced-hospital-wait-times-faster-ems-response-with-90-day-health-care-update_5087659.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 04:49:50+00:00

An adult acute care hospital in Calgary, Alta., is seen on April 1, 2020. (The Canadian Press/Jeff McIntosh)

## NATO Expansion Focus of Parliamentary Committee Trip to Europe to Study Ukraine
 - [https://www.theepochtimes.com/nato-expansion-focus-of-parliamentary-committee-trip-to-europe-to-study-ukraine_5087722.html](https://www.theepochtimes.com/nato-expansion-focus-of-parliamentary-committee-trip-to-europe-to-study-ukraine_5087722.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 04:47:52+00:00

Canada's Foreign Affairs Minister Mélanie Joly arrives for the first day of the meeting of NATO Ministers of Foreign Affairs in Bucharest, Romania, Nov. 29, 2022. (The Canadian Press/AP-Andreea Alexandru)

## Studious Raccoon Shuts Down South Kelowna, BC, Elementary School for the Day
 - [https://www.theepochtimes.com/studious-raccoon-shuts-down-south-kelowna-bc-elementary-school-for-the-day_5087714.html](https://www.theepochtimes.com/studious-raccoon-shuts-down-south-kelowna-bc-elementary-school-for-the-day_5087714.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 04:42:41+00:00

One of two orphaned baby raccoons needing to be fed and watched over in a cage until they are old enough to fend for themselves, at Parc Omega on July 5, 2013. (Matthew Little/The Epoch Times)

## WestJet Customers Offered 7.5-Hour Bus Ride to Destination After Flight Cancelled
 - [https://www.theepochtimes.com/westjet-customers-offered-7-5-hour-bus-ride-to-destination-after-flight-cancelled_5087710.html](https://www.theepochtimes.com/westjet-customers-offered-7-5-hour-bus-ride-to-destination-after-flight-cancelled_5087710.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 04:36:07+00:00

A WestJet flight from Calgary arrives at Halifax Stanfield International Airport in Enfield, N.S. on July 6, 2020. (The Canadian Press/Andrew Vaughan)

## Vancouver Police Shoot Man With Rubber Bullets in Case of Mistaken Identity
 - [https://www.theepochtimes.com/vancouver-police-shoot-man-with-rubber-bullets-in-case-of-mistaken-identity_5087706.html](https://www.theepochtimes.com/vancouver-police-shoot-man-with-rubber-bullets-in-case-of-mistaken-identity_5087706.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 04:31:09+00:00

Police cars are seen parked outside Vancouver Police Department headquarters in Vancouver, on Jan. 9, 2021. (The Canadian Press/Darryl Dyck)

## US Gives Go Ahead for New Lethal Hardware for Australia
 - [https://www.theepochtimes.com/us-gives-go-ahead-for-new-lethal-hardware-for-australia_5087474.html](https://www.theepochtimes.com/us-gives-go-ahead-for-new-lethal-hardware-for-australia_5087474.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 03:16:52+00:00

An AGM-88E Advanced Anti-Radiation Guided Missile is fired from a VX-31 FA-18 Hornet over the NAWCWD China Lake land range in August during the missile’s Operational Assessment.
(Mike McGinnis, Naval Air Systems Command)

## Money for Indigenous ‘Voice’ Should Go Directly to Struggling Communities: Former NBA Player
 - [https://www.theepochtimes.com/money-for-indigenous-voice-should-go-directly-to-struggling-communities-former-nba-player_5087361.html](https://www.theepochtimes.com/money-for-indigenous-voice-should-go-directly-to-struggling-communities-former-nba-player_5087361.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 03:00:20+00:00

Members of the Mutitjulu Aboriginal community walk through the grounds in Mutitjulu, near Alice Springs, Australia, on July 6, 2007. (Ian Waldie/Getty Images)

## Moldova Expels 2 Foreigners Caught in Plot Carrying Out ‘Subversive Actions’
 - [https://www.theepochtimes.com/moldova-expels-2-foreigners-caught-in-plot-carrying-out-subversive-actions_5087445.html](https://www.theepochtimes.com/moldova-expels-2-foreigners-caught-in-plot-carrying-out-subversive-actions_5087445.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 01:33:16+00:00

Holding signs, people take part in a protest against the Moldovan Government and their pro-EU President in Chisinau on Feb. 19, 2023. A couple of thousands of protesters gathered downtown answering the call made by the Russia-friendly "ȘOR" Party, as tension run high in pro-Western Moldova after allegations of Moscow's attempts to destabilise the country came to light last week. Facing multiple crises aggravated by Russia's war in Ukraine, the impoverished former Soviet republic of 2.6 million people wedged between Romania and Ukraine, Moldova is already wrestling with an energy crisis prompted by supply cuts from Russia's targeting of Ukraine's energy infrastructure, and tensions have flared up due to missile overflights connected to the war in Ukraine. (ELENA COVALENCO/AFP via Getty Images)

## Universities’ Push for Quantity Over Quality of Students Sees Higher Failure Rates Than Ever
 - [https://www.theepochtimes.com/universities-push-for-quantity-over-quality-of-students-sees-higher-failure-rates-than-ever_5087410.html](https://www.theepochtimes.com/universities-push-for-quantity-over-quality-of-students-sees-higher-failure-rates-than-ever_5087410.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-28 01:19:21+00:00

University graduates (Chris Ison/PA)

