# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Breaks taken during psych experiments lower participants’ moods
 - [https://arstechnica.com/?p=1920826](https://arstechnica.com/?p=1920826)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 22:45:30+00:00

The lowered mood could throw off the results of studies with rest breaks.

## Tesla shareholder suit says Musk and co. lied about Full Self-Driving safety
 - [https://arstechnica.com/?p=1920791](https://arstechnica.com/?p=1920791)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 21:29:59+00:00

Investor lawsuit cites recall of Tesla cars that act dangerously in intersections.

## The Pixel Watch’s promised fall detection is finally rolling out
 - [https://arstechnica.com/?p=1920744](https://arstechnica.com/?p=1920744)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 20:40:15+00:00

Just like a 2018 Apple Watch, the Pixel Watch can call 911 after a hard fall.

## Beyond Good & Evil 2 studio rocked by reported gov’t labor investigation
 - [https://arstechnica.com/?p=1920772](https://arstechnica.com/?p=1920772)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 20:13:02+00:00

Management shakeup comes as dozens call in sick for stress and/or burnout.

## Dealmaster: Best tablet deals for Samsung Galaxy Tab
 - [https://arstechnica.com/?p=1920686](https://arstechnica.com/?p=1920686)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 19:53:13+00:00

Savings on Samsung's slates for both new and refurbished models.

## Watch these glassy-winged sharpshooters fling pee bubbles with anal catapult
 - [https://arstechnica.com/?p=1920487](https://arstechnica.com/?p=1920487)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 19:23:44+00:00

This "superpropulsion mechanism" could help remove water from smartphones, watches.

## Dell refreshes XPS desktop, announces updates to XPS 15 and 17 laptops
 - [https://arstechnica.com/?p=1920675](https://arstechnica.com/?p=1920675)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 18:56:05+00:00

Dell sticks to chip upgrades for the latest models.

## Russia fines Wikipedia for publishing facts instead of Kremlin war propaganda
 - [https://arstechnica.com/?p=1920690](https://arstechnica.com/?p=1920690)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 18:37:49+00:00

Third fine since Ukraine invasion targets articles about Russian military units.

## YouTube video causes Pixel phones to instantly reboot
 - [https://arstechnica.com/?p=1920654](https://arstechnica.com/?p=1920654)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 16:59:05+00:00

Google's Tensor chips seem to choke on this 4K HDR clip of <em>Alien</em>.

## Meet the space billionaire who is interested in something other than rockets
 - [https://arstechnica.com/?p=1920624](https://arstechnica.com/?p=1920624)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 15:30:40+00:00

Vast's acquisition of Launcher shows that Jed McCaleb is serious about this space thing.

## Namco announces the first Elden Ring expansion is in development
 - [https://arstechnica.com/?p=1920639](https://arstechnica.com/?p=1920639)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 15:14:08+00:00

"Shadow of the Erdtree" promises "new adventure in the Lands Between."

## Preview: Final Fantasy XVI is a bold new direction for the series
 - [https://arstechnica.com/?p=1920599](https://arstechnica.com/?p=1920599)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 14:37:34+00:00

From action-RPG combat to narrative design, <em>Final Fantasy XVI</em> marks a new era.

## Chipmakers receiving US federal funds can’t expand in China for 10 years
 - [https://arstechnica.com/?p=1920618](https://arstechnica.com/?p=1920618)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 14:11:54+00:00

Chipmakers must also provide affordable childcare and are barred from stock buybacks.

## Major Windows 11 update adds Notepad tabs, iPhone pairing, and a dash of AI
 - [https://arstechnica.com/?p=1920566](https://arstechnica.com/?p=1920566)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 14:00:31+00:00

2023's first big update drop is a mix of app and UI changes for the 2022 Update.

## New Windows 11 update puts AI-powered Bing Chat directly in the taskbar
 - [https://arstechnica.com/?p=1920384](https://arstechnica.com/?p=1920384)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 14:00:13+00:00

Occasionally controversial work-in-progress AI project will hit millions of PCs.

## LastPass says employee’s home computer was hacked and corporate vault taken
 - [https://arstechnica.com/?p=1920551](https://arstechnica.com/?p=1920551)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-28 01:01:59+00:00

Already smarting from a breach that stole customer vaults, LastPass has more bad news.

