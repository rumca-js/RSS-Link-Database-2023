# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Wyniki Eurojackpot z 28 lutego 2023. Jakie liczby padły podczas ostatniego losowania?
 - [https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia280223-czy-padla-glowna-wygrana-6785100?source=rss](https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia280223-czy-padla-glowna-wygrana-6785100?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 20:41:52+00:00

<img alt="Wyniki Eurojackpot z 28 lutego 2023. Jakie liczby padły podczas ostatniego losowania?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wn6i5w-eurojackpot-s-shutterstock743570785-4780960/alternates/LANDSCAPE_1280" />
    We wtorkowym losowaniu Eurojackpot nie padła główna wygrana. W Polsce odnotowano wygrane czwartego stopnia. Oto wyniki Eurojackpot z 28 lutego 2023 roku.

## Koniunkcja Wenus i Jowisza. Relacje Reporterów 24
 - [https://tvn24.pl/tvnmeteo/ciekawostki/koniunkcja-wenus-i-jowisza-2023-kiedy-ogladac-zdjecia-reporterow-24-6784997?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/koniunkcja-wenus-i-jowisza-2023-kiedy-ogladac-zdjecia-reporterow-24-6784997?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 20:17:32+00:00

<img alt="Koniunkcja Wenus i Jowisza. Relacje Reporterów 24" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-81jxws-2-6785043/alternates/LANDSCAPE_1280" />
    We wtorek na wieczornym niebie można podziwiać zbliżenie Wenus i Jowisza. Kulminacyjny moment koniunkcji nastąpi w środę, ale już dziś te planety, widoczne jako dwa jasno świecące punkty, są bardzo dobrze widoczne. Zdjęcia zjawiska otrzymaliśmy na Kontakt 24, prosimy o kolejne.

## Motocyklista w szpitalu po zderzeniu z taksówką na Ochocie
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-motocyklista-w-szpitalu-po-zderzeniu-z-taksowka-na-ochocie-6785045?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-motocyklista-w-szpitalu-po-zderzeniu-z-taksowka-na-ochocie-6785045?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 20:09:37+00:00

<img alt="Motocyklista w szpitalu po zderzeniu z taksówką na Ochocie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-78ygr9-zderzenie-motocyklisty-z-taksowka-6785027/alternates/LANDSCAPE_1280" />
    W Alejach Jerozolimskich, na wysokości Dworca Zachodniego, doszło do zderzenia motocyklisty z kierowcą taksówki. Policja przekazała, że kierujący jednośladem trafił do szpitala.

## Obniżka ceny gazu dla biznesu o ponad połowę. Jest zapowiedź
 - [https://tvn24.pl/biznes/z-kraju/ceny-gazu-2023-pgnig-obniza-ceny-gazu-dla-biznesu-o-ponad-polowe-jest-zapowiedz-6785019?source=rss](https://tvn24.pl/biznes/z-kraju/ceny-gazu-2023-pgnig-obniza-ceny-gazu-dla-biznesu-o-ponad-polowe-jest-zapowiedz-6785019?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 20:08:35+00:00

<img alt="Obniżka ceny gazu dla biznesu o ponad połowę. Jest zapowiedź" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ntlmij-gaz-5689079/alternates/LANDSCAPE_1280" />
    Spółka PGNiG Obrót Detaliczny zapowiedziała we wtorek, że od 15 marca obniży ceny gazu dla odbiorców biznesowych w cenniku "Gaz dla Biznesu". Cena za megawatogodzinę (MWh) spadnie do 353 złotych netto, czyli o 55 procent - poinformowano. Prezes Grupy Orlen Daniel Obajtek przekazał, że zmiany obejmą około 130 tysięcy klientów biznesowych.

## Na ten park Ursynów czeka od początku budowy obwodnicy. Niedługo zostanie wbita pierwsza łopata
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ursynow-budowa-parku-nad-poludniowa-obwodnica-warszawy-pierwszy-przetarg-6784102?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ursynow-budowa-parku-nad-poludniowa-obwodnica-warszawy-pierwszy-przetarg-6784102?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 19:16:17+00:00

<img alt="Na ten park Ursynów czeka od początku budowy obwodnicy. Niedługo zostanie wbita pierwsza łopata " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dg5oxn-park-linearny-na-ursynowie-%E2%80%93-wkrotce-poczatek-budowy-6784068/alternates/LANDSCAPE_1280" />
    Zarząd Zieleni szykuje się do ogłoszenia przetargu na prace budowlane w parku nad Południową Obwodnicą Warszawy. Urzędnicy inwestycję podzielili na kilka etapów. Choć nie mają jeszcze zapewnionego całkowitego finansowania, chcieliby, aby pierwsze prace ruszyły jeszcze w tym roku. O tym, czy środki na wszystkie etapy zostaną przyznane, zdecyduje na najbliższej sesji Rada Warszawy.

## Eksperci: Rosja straciła w Ukrainie więcej żołnierzy niż we wszystkich konfliktach po 1945 roku razem wziętych
 - [https://tvn24.pl/swiat/rosja-ile-zolnierzy-stracila-w-ukrainie-eksperci-przez-rok-wiecej-niz-w-sumie-na-calym-swiecie-od-1945-roku-6784964?source=rss](https://tvn24.pl/swiat/rosja-ile-zolnierzy-stracila-w-ukrainie-eksperci-przez-rok-wiecej-niz-w-sumie-na-calym-swiecie-od-1945-roku-6784964?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 19:13:41+00:00

<img alt="Eksperci: Rosja straciła w Ukrainie więcej żołnierzy niż we wszystkich konfliktach po 1945 roku razem wziętych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-50bvvy-rosyjscy-zolnierze-6759559/alternates/LANDSCAPE_1280" />
    Rosja traci miesięcznie w Ukrainie 25 razy więcej żołnierzy niż w Czeczenii i 35 razy więcej niż w Afganistanie. W sumie w ciągu roku na wojnie w Ukrainie Rosja straciła ich więcej niż we wszystkich konfliktach po zakończeniu II wojny światowej razem wziętych - przekazali w raporcie eksperci z amerykańskiego think tanku Centrum Studiów Strategicznych i Międzynarodowych (CSIS).

## Pogoda na jutro - środa 01.03. W nocy do 8 stopni mrozu, w dzień do 8 stopni na plusie
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sroda-0103-w-nocy-do-8-stopni-mrozu-w-dzien-do-8-stopni-na-plusie-6784880?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sroda-0103-w-nocy-do-8-stopni-mrozu-w-dzien-do-8-stopni-na-plusie-6784880?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 18:25:56+00:00

<img alt="Pogoda na jutro - środa 01.03. W nocy do 8 stopni mrozu, w dzień do 8 stopni na plusie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-xsm1hq-w-nocy-scisnie-mroz-6232179/alternates/LANDSCAPE_1280" />
    Mróz w całej Polsce możliwy jest w nocy z wtorku na środę. Temperatura osiągnie najniższe wartości  na południowym wschodzie kraju. Pierwszy dzień marca będzie chłodny, z dużym zachmurzeniem, ale i z przejaśnieniami.

## Obawy o destabilizację Mołdawii. Ludzie zwożeni autobusami i wielki wiec w Kiszyniowie
 - [https://tvn24.pl/swiat/moldawia-protesty-na-ulicach-kiszyniowa-zorganizowane-przez-prorosyjska-opozycje-w-czasie-obaw-o-destabilizacje-kraju-6784907?source=rss](https://tvn24.pl/swiat/moldawia-protesty-na-ulicach-kiszyniowa-zorganizowane-przez-prorosyjska-opozycje-w-czasie-obaw-o-destabilizacje-kraju-6784907?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 18:22:31+00:00

<img alt="Obawy o destabilizację Mołdawii. Ludzie zwożeni autobusami i wielki wiec w Kiszyniowie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-70dvx2-forum-0759247212-6784875/alternates/LANDSCAPE_1280" />
    Ulice stolicy Mołdawii, Kiszyniowa, zalały tysiące protestujących, którzy domagają się dopłat do rachunków za energię za okres zimowy oraz "nieangażowania kraju w wojnę". Agencja Associated Press podała, że protesty zorganizowała prorosyjska opozycja. Mołdawia, która sąsiaduje z Ukrainą, rok temu obrała zdecydowany kurs w stronę uniezależnienia się od Moskwy.

## Jest nowe porozumienie Białorusi z Rosją. Zakontraktowano gaz na lata
 - [https://tvn24.pl/biznes/ze-swiata/rosja-bialorus-gaz-ziemny-jest-nowe-porozumienie-bialorusi-z-rosja-6784836?source=rss](https://tvn24.pl/biznes/ze-swiata/rosja-bialorus-gaz-ziemny-jest-nowe-porozumienie-bialorusi-z-rosja-6784836?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 17:26:57+00:00

<img alt="Jest nowe porozumienie Białorusi z Rosją. Zakontraktowano gaz na lata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gorwlv-gaz-gazociag-rury-6784869/alternates/LANDSCAPE_1280" />
    Rosja i Białoruś uzgodniły, że Moskwa będzie nadal dostarczać do Białorusi gaz ziemny po cenie z 2022 roku - poinformowało we wtorek ministerstwo energetyki Białorusi. Porozumienie ma obowiązywać do końca 2025 roku.

## "Rosyjski bank szpiegów" na Węgrzech w krytycznej sytuacji
 - [https://tvn24.pl/biznes/ze-swiata/wegry-media-krytyczna-sytuacja-rosyjskiego-miedzynarodowego-banku-inwestycyjnego-nazywanego-bankiem-szpiegow-6784583?source=rss](https://tvn24.pl/biznes/ze-swiata/wegry-media-krytyczna-sytuacja-rosyjskiego-miedzynarodowego-banku-inwestycyjnego-nazywanego-bankiem-szpiegow-6784583?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 17:15:55+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uhox12-ibb-6784796/alternates/LANDSCAPE_1280" />
    Międzynarodowy Bank Inwestycyjny (IIB) z siedzibą w Budapeszcie, który jest nazywany "bankiem szpiegów" i w którym niemal połowa udziałów należy do Rosji, jest w krytycznej sytuacji w związku z nałożonymi na Kreml po agresji na Ukrainę sankcjami – poinformował węgierski portal HVG.

## Starszy mężczyzna zginął w pożarze domu
 - [https://tvn24.pl/tvnwarszawa/okolice/gloskow-pod-piasecznem-starszy-mezczyzna-zginal-w-pozarze-domu-6784706?source=rss](https://tvn24.pl/tvnwarszawa/okolice/gloskow-pod-piasecznem-starszy-mezczyzna-zginal-w-pozarze-domu-6784706?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 16:56:11+00:00

<img alt="Starszy mężczyzna zginął w pożarze domu " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8eov9c-w-pozarze-zginal-starszy-mezczyzna-6784704/alternates/LANDSCAPE_1280" />
    We wtorek po południu w miejscowości Głosków niedaleko Piaseczna doszło do pożaru. Strażacy odnaleźli w budynku ciało mężczyzny w podeszłym wieku.

## Pożar magazynu z materiałami do produkcji drzwi. Nie ma osób poszkodowanych
 - [https://tvn24.pl/polska/pozar-magazynu-z-materialami-do-produkcji-drzwi-nie-ma-osob-poszkodowanych-6784771?source=rss](https://tvn24.pl/polska/pozar-magazynu-z-materialami-do-produkcji-drzwi-nie-ma-osob-poszkodowanych-6784771?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 16:35:15+00:00

<img alt="Pożar magazynu z materiałami do produkcji drzwi. Nie ma osób poszkodowanych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mepc3t-pozar-magazynu-z-materialami-do-produkcji-drzwi-w-lodzi-280223-6784795/alternates/LANDSCAPE_1280" />
    Pali się hala przy ulicy Wycieczkowej w Łodzi. Jak podaje straż pożarna, wewnątrz składowane są materiały do wypełniania drzwi, między innymi pianka poliuretanowa.

## Niezwykłe ujęcia z drona na zawodach w miejskim downhillu
 - [https://tvn24.pl/toteraz/niezwykle-ujecia-z-drona-na-zawodach-w-miejskim-downhillu-6784528?source=rss](https://tvn24.pl/toteraz/niezwykle-ujecia-z-drona-na-zawodach-w-miejskim-downhillu-6784528?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 16:23:00+00:00

<img alt="Niezwykłe ujęcia z drona na zawodach w miejskim downhillu" src="https://tvn24.pl/toteraz/cdn-zdjecie-26j8d0-niezwykle-ujecia-z-drona-na-zawodach-w-miejskim-downhillu-6784407/alternates/LANDSCAPE_1280" />
    Zobaczcie przejazd Tomasa Slavika z 2022 roku.

## W Arabii Saudyjskiej pierwszy raz od stu lat spadł śnieg? To nieprawda
 - [https://konkret24.tvn24.pl/swiat/kryzys-klimatyczny-w-arabii-saudyjskiej-pierwszy-raz-od-stu-lat-spadl-snieg-to-nieprawda-6780880?source=rss](https://konkret24.tvn24.pl/swiat/kryzys-klimatyczny-w-arabii-saudyjskiej-pierwszy-raz-od-stu-lat-spadl-snieg-to-nieprawda-6780880?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 15:29:00+00:00

<img alt="W Arabii Saudyjskiej pierwszy raz od stu lat spadł śnieg? To nieprawda" src="https://konkret24.tvn24.pl/najnowsze/cdn-zdjecie-oonwvi-w-arabii-saudyjskiej-pierwszy-raz-od-stu-lat-spadl-snieg-to-nieprawda-6780800/alternates/LANDSCAPE_1280" />
    Wbrew informacjom rozsyłanym w mediach społecznościowych śnieg wcale nie jest bardzo rzadkim zjawiskiem w Arabii Saudyjskiej. Jego opady w tym kraju nie są również żadnym dowodem na to, że nie ma globalnego ocieplenia.

## "Kierująca autem dostawczym uderzyła w tył ciężarówki". Korek na A2 ma pięć kilometrów
 - [https://tvn24.pl/tvnwarszawa/ulice/a2-pruszkow-zderzenie-ciezarowki-z-autem-dostawczym-utrudnienia-6784647?source=rss](https://tvn24.pl/tvnwarszawa/ulice/a2-pruszkow-zderzenie-ciezarowki-z-autem-dostawczym-utrudnienia-6784647?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 15:14:25+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-is71kn-samochod-dostawczy-zderzyl-sie-z-ciezarowka-na-a2-6784632/alternates/LANDSCAPE_1280" />
    Na A2 na wysokości Pruszkowa auto dostawcze wjechało w tył ciężarówki. Zablokowane zostały dwa pasy w kierunku Warszawy. Korek zaczyna się pięć kilometrów wcześniej.

## Juliette przyniosła ziąb i śnieg do Hiszpanii. Nawet na Baleary
 - [https://tvn24.pl/tvnmeteo/swiat/hiszpania-burza-juliette-snieg-spadl-na-majorce-6784236?source=rss](https://tvn24.pl/tvnmeteo/swiat/hiszpania-burza-juliette-snieg-spadl-na-majorce-6784236?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 15:09:07+00:00

<img alt="Juliette przyniosła ziąb i śnieg do Hiszpanii. Nawet na Baleary" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-s2ag6j-sniezyca-na-majorce-6784267/alternates/LANDSCAPE_1280" />
    Hiszpania znalazła się w zasięgu burzy Juliette, która przyniosła ze sobą rekordowe opady deszczu, a także obfity śnieg. W poniedziałek biało zrobiło się w Kraju Basków, Katalonii, a nawet na Balearach. Do Hiszpanii napłynęło wyjątkowo zimne powietrze. We wtorek rano nieopodal Madrytu temperatura spadła do -15 stopni Celsjusza.

## Wypadek w trakcie wyprzedzania. Nie żyje 27-letni motocyklista
 - [https://tvn24.pl/tvnwarszawa/ulice/atalin-zwolen-dk12-zginal-motocyklista-6784538?source=rss](https://tvn24.pl/tvnwarszawa/ulice/atalin-zwolen-dk12-zginal-motocyklista-6784538?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 14:36:56+00:00

<img alt="Wypadek w trakcie wyprzedzania. Nie żyje 27-letni motocyklista " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-76mcqs-w-wypadku-zginal-27-letni-motocyklista-6784541/alternates/LANDSCAPE_1280" />
    Do tragicznego wypadku doszło we wtorek przed południem na drodze krajowej numer 12 w miejscowości Atalin. Motocyklista zderzył się z samochodem osobowym w trakcie wyprzedzania. 27-latek zmarł mimo reanimacji.

## Przyłębska: Trybunał Konstytucyjny działa i podaje dane. Sprawdzamy
 - [https://konkret24.tvn24.pl/polska/trybunal-konstytucyjny-dziala-zapewnia-prezes-julia-przylebska-sprawdzamy-6783852?source=rss](https://konkret24.tvn24.pl/polska/trybunal-konstytucyjny-dziala-zapewnia-prezes-julia-przylebska-sprawdzamy-6783852?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 14:15:00+00:00

<img alt="Przyłębska: Trybunał Konstytucyjny działa i podaje dane. Sprawdzamy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5gaop8-julia-przylebska-6623337/alternates/LANDSCAPE_1280" />
    Julia Przyłębska z satysfakcją podkreśliła w radiowym wywiadzie, że Trybunał Konstytucyjny wciąż działa i podała mające to udowadniać dane. Sprawdziliśmy je i porównaliśmy z poprzednimi latami.

## Najlepsze plaże świata na 2023 rok. Wśród nich te lubiane przez Polaków
 - [https://tvn24.pl/ciekawostki/najlepsze-plaze-swiata-2023-nowy-ranking-tripadvisora-6784189?source=rss](https://tvn24.pl/ciekawostki/najlepsze-plaze-swiata-2023-nowy-ranking-tripadvisora-6784189?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 14:14:08+00:00

<img alt="Najlepsze plaże świata na 2023 rok. Wśród nich te lubiane przez Polaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q53udi-plaza-baia-do-sancho-archipelag-fernando-de-noronha-brazylia-6784295/alternates/LANDSCAPE_1280" />
    Jakie są najlepsze plaże na świecie na nadchodzący sezon wakacyjny? Portal Tripadvisor przygotował ranking 25 plaż, które zebrały w minionym roku najlepsze recenzje milionów turystów. W czołówce również popularne miejsca w Europie.

## Najpierw mieli zaatakować, później zawlec do mieszkania, bić i przypalać żelazkiem. "Na koniec ogolili głowę maszynką"
 - [https://tvn24.pl/wroclaw/wlen-lwowek-slaski-najpierw-mieli-zaatakowac-pozniej-zawlec-do-mieszkania-bic-i-przypalac-zelazkiem-na-koniec-ogolili-glowe-maszynka-6784261?source=rss](https://tvn24.pl/wroclaw/wlen-lwowek-slaski-najpierw-mieli-zaatakowac-pozniej-zawlec-do-mieszkania-bic-i-przypalac-zelazkiem-na-koniec-ogolili-glowe-maszynka-6784261?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 14:06:20+00:00

<img alt="Najpierw mieli zaatakować, później zawlec do mieszkania, bić i przypalać żelazkiem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mhkjdz-mezczyzni-przypalali-zelazkiem-pokrzywdzonego-6784344/alternates/LANDSCAPE_1280" />
    Policjanci z Lwówka Śląskiego (Dolnośląskie) zatrzymali dwóch mężczyzn podejrzanych o pozbawienie wolności ze szczególnym udręczeniem, pobicie i rozbój. Z zebranego przez śledczych materiału dowodowego wynika, że 41- i 44-latek przemocą obezwładnili znajomą sobie osobę, a następnie zawlekli ją do mieszkania, gdzie przez całą noc torturowali. Grozi im do 15 lat więzienia.

## Lekarka nie chciała uśpić psa. Właściciel czworonoga rzucił się na nią z pięściami
 - [https://tvn24.pl/tvnwarszawa/najnowsze/otwock-lekarka-nie-chciala-uspic-psa-wlasciciel-rzucil-sie-na-nia-z-piesciami-6784005?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/otwock-lekarka-nie-chciala-uspic-psa-wlasciciel-rzucil-sie-na-nia-z-piesciami-6784005?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 13:56:34+00:00

<img alt="Lekarka nie chciała uśpić psa. Właściciel czworonoga rzucił się na nią z pięściami" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-v1cjlm-policja-zdjecie-ilustracyjne-6127850/alternates/LANDSCAPE_1280" />
    Policjanci z Otwocka zatrzymali 33-latka, który zaatakował lekarkę weterynarii, gdy ta odmówiła uśpienia jego psa. Mężczyzna wielokrotnie uderzał kobietę pięściami. Chciał ją zmusić do wykonania zabiegu. Na dodatek podczas tego ataku na pokrzywdzoną rzucił się również pies.

## Wyrzuciła psa z drugiego piętra, przyznała się do winy. Zwierzę nie żyje
 - [https://tvn24.pl/bialystok/bialystok-wyrzucila-psa-z-drugiego-pietra-przyznala-sie-do-winy-zwierze-trzeb-bylo-uspic-6784184?source=rss](https://tvn24.pl/bialystok/bialystok-wyrzucila-psa-z-drugiego-pietra-przyznala-sie-do-winy-zwierze-trzeb-bylo-uspic-6784184?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 13:56:03+00:00

<img alt="Wyrzuciła psa z drugiego piętra, przyznała się do winy. Zwierzę nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1eliup-pies-upadl-na-chodnik-6775369/alternates/LANDSCAPE_1280" />
    Zarzut znęcania się nad psem ze szczególnym okrucieństwem usłyszała 42-letnia kobieta, która wyrzuciła z balkonu w centrum Białegostoku psa. Zwierzę przeżyło upadek na beton z drugiego piętra, ale po kilku dniach jego stan tak się pogorszył, że trzeba było je uśpić.

## Rondo "Radosława" do remontu. Co się zmieni?
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-remont-ronda-radoslawa-co-sie-zmieni-6782815?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-remont-ronda-radoslawa-co-sie-zmieni-6782815?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 13:46:14+00:00

<img alt="Rondo " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8bg5xg-rondo-radoslawa-do-remontu-6783157/alternates/LANDSCAPE_1280" />
    - Ogłosiliśmy przetarg na remont ronda "Radosława", jednego z najbardziej popularnych skrzyżowań o ruchu okrężnym w stolicy - poinformował we wtorek Zarząd Dróg Miejskich. Drogowcy planują wymianę asfaltu, remont drogi rowerowej czy przystanku.

## Jest pakt senacki. "Przed nami wybory, które będą najważniejsze od 1989 roku"
 - [https://tvn24.pl/polska/pakt-senacki-2023-opozycja-startuje-wspolnie-do-senatu-konferencja-prasowa-6784385?source=rss](https://tvn24.pl/polska/pakt-senacki-2023-opozycja-startuje-wspolnie-do-senatu-konferencja-prasowa-6784385?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 13:45:26+00:00

<img alt="Jest pakt senacki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fdqd87-pakt-senacki-2023-6784460/alternates/LANDSCAPE_1280" />
    Koalicja Obywatelska, Polska 2050, Lewica, Polskie Stronnictwo Ludowe i samorządowcy podpisali we wtorek w Senacie deklarację zawarcia tak zwanego paktu senackiego na najbliższe wybory parlamentarne. - Przed nami wybory, które będą najważniejsze od 1989 roku - powiedział na konferencji prasowej prezydent Gliwic Zygmunt Frankiewicz z Ruchu "Tak! Dla Polski".

## Gigantyczne wydatki na inwestycje. Orlen aktualizuje strategię
 - [https://tvn24.pl/biznes/z-kraju/orlen-aktualizuje-strategie-do-2030-roku-wyplaci-dywidende-za-2022-rok-daniel-obajtek-komentuje-6784336?source=rss](https://tvn24.pl/biznes/z-kraju/orlen-aktualizuje-strategie-do-2030-roku-wyplaci-dywidende-za-2022-rok-daniel-obajtek-komentuje-6784336?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 13:41:35+00:00

<img alt="Gigantyczne wydatki na inwestycje. Orlen aktualizuje strategię" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-rlyac5-daniel-obajtek-6784400/alternates/LANDSCAPE_1280" />
    PKN Orlen ogłosił aktualizację strategii grupy kapitałowej do 2030 roku. Przewiduje ona nakłady inwestycyjne w tym okresie w łącznej wysokości około 320 miliardów złotych. Z tego około 40 procent, czyli 120 miliardów złotych ma zostać przeznaczone na tak zwane inwestycje zielone. PKN Orlen zakłada też wypłatę dywidendy za 2022 rok, jej rekomendowany poziom "jest najwyższy w historii" - wskazał koncern.

## Dzieci w szkole dostały mus z kofeiną. Sprawą zajął się sanepid
 - [https://tvn24.pl/poznan/krotoszyn-dzieci-w-szkole-dostaly-mus-z-kofeina-sprawa-zajal-sie-sanepid-6784265?source=rss](https://tvn24.pl/poznan/krotoszyn-dzieci-w-szkole-dostaly-mus-z-kofeina-sprawa-zajal-sie-sanepid-6784265?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 13:41:01+00:00

<img alt="Dzieci w szkole dostały mus z kofeiną. Sprawą zajął się sanepid" src="https://tvn24.pl/najnowsze/cdn-zdjecie-98ltz4-szkola-podstawowa-nr-8-w-krotoszynie-6784287/alternates/LANDSCAPE_1280" />
    Dzieciom w szkole podstawowej w Krotoszynie (Wielkopolska) zaserwowano mus owocowy z kofeiną. Na zdarzenie zareagował jeden z rodziców. Sanepid przeprowadził kontrolę.

## Bociek Maciej już się zadomowił w swoim gnieździe. Przyleciał później niż zwykle
 - [https://tvn24.pl/pomorze/bydgoszcz-bociek-maciej-juz-sie-zadomowil-w-swoim-gniezdzie-przylecial-pozniej-niz-zwykle-6784212?source=rss](https://tvn24.pl/pomorze/bydgoszcz-bociek-maciej-juz-sie-zadomowil-w-swoim-gniezdzie-przylecial-pozniej-niz-zwykle-6784212?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 13:30:00+00:00

<img alt="Bociek Maciej już się zadomowił w swoim gnieździe. Przyleciał później niż zwykle" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bo1tyo-bocian-pojawil-sie-juz-w-lutym-w-bydgoszczy-6784193/alternates/LANDSCAPE_1280" />
    W Bydgoszczy na osiedlu Łęgnowo (woj. kujawsko-pomorskie) pojawił się znany od lat mieszkańcom bocian. Przyznają, że przyleciał później niż zwykle. Z reguły bywa tu już na początku lutego. Nie kryją jednak swojej radości, ponieważ ptak zawsze jest przez nich mile widziany.

## 50-latek dwa razy w ciągu dwóch godzin został zatrzymany za jazdę po pijanemu
 - [https://tvn24.pl/polska/skarzysko-kamienna-w-ciagu-dwoch-godzin-dwa-razy-zatrzymano-go-za-jazde-po-pijanemu-6784273?source=rss](https://tvn24.pl/polska/skarzysko-kamienna-w-ciagu-dwoch-godzin-dwa-razy-zatrzymano-go-za-jazde-po-pijanemu-6784273?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 13:15:04+00:00

<img alt="50-latek dwa razy w ciągu dwóch godzin został zatrzymany za jazdę po pijanemu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lj3uj4-policja-zatrzymala-pijanego-kierowce-6725912/alternates/LANDSCAPE_1280" />
    Podczas pierwszego zatrzymania 50-letni kierowca z Radomia miał 1,2 promila alkoholu, za drugim – prawie promil. Teraz drogowemu recydywiście może grozić więzienie.

## Szukają wilka Geralta. Pod koniec stycznia jego obroża przestała wysyłać lokalizację
 - [https://tvn24.pl/bialystok/nadlesnictwo-mircze-szukaja-wilka-geralta-pod-koniec-stycznia-jego-obroza-przestala-wysylac-lokalizacje-6783839?source=rss](https://tvn24.pl/bialystok/nadlesnictwo-mircze-szukaja-wilka-geralta-pod-koniec-stycznia-jego-obroza-przestala-wysylac-lokalizacje-6783839?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 12:56:03+00:00

<img alt="Szukają wilka Geralta. Pod koniec stycznia jego obroża przestała wysyłać lokalizację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-16ojlt-wilk-geralt-zostal-zaobrozowany-gdy-przebywal-jeszcze-na-terenie-puszczy-swietokrzyskiej-6783968/alternates/LANDSCAPE_1280" />
    Fundacja SAVE Wildlife Conservation Fund szuka zaobrożowanego wilka Geralta, który jesienią przywędrował do lasów nadleśnictwa Mircze (woj. lubelskie) i pod koniec stycznia zaginął. Przedstawicielka fundacji uważa, że zwierzę najprawdopodobniej nie żyje. Jak informuje nadleśniczy, kilka dni temu wilka w obroży widziały w lesie cztery osoby i wszystko wskazuje na to, że był to właśnie Geralt.

## Odwołano pogotowie przeciwpowodziowe w powiecie płockim
 - [https://tvn24.pl/tvnmeteo/polska/powiat-plocki-rzeka-wisla-odwolano-pogotowie-przeciwpowodziowe-obowiazuja-alerty-hydrologiczne-imgw-6784155?source=rss](https://tvn24.pl/tvnmeteo/polska/powiat-plocki-rzeka-wisla-odwolano-pogotowie-przeciwpowodziowe-obowiazuja-alerty-hydrologiczne-imgw-6784155?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 12:34:41+00:00

<img alt="Odwołano pogotowie przeciwpowodziowe w powiecie płockim" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-c3e2cc-wydano-alerty-hydrologiczne-5227975/alternates/LANDSCAPE_1280" />
    Pogotowie przeciwpowodziowe, które obowiązywało od piątku w części województwa mazowieckiego, zostało odwołane. Jego ogłoszenie wiązało się z przejściem fali wezbraniowej na Wiśle. W dolnym biegu rzeki we wtorek wciąż obowiązują alerty hydrologiczne drugiego stopnia.

## Dużo służb przy Dworcu Centralnym. "Bezpieczeństwo w przewozie osób"
 - [https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-duzo-sluzb-przy-dworcu-centralnym-bezpieczenstwo-w-przewozie-osob-6781971?source=rss](https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-duzo-sluzb-przy-dworcu-centralnym-bezpieczenstwo-w-przewozie-osob-6781971?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 12:20:35+00:00

<img alt="Dużo służb przy Dworcu Centralnym. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-63c52e-akcja-sluzb-przy-dworcu-centralnym-6781981/alternates/LANDSCAPE_1280" />
    Kierowcy trudniący się przewozem osób znów na celowniku służb. W Warszawie trwa akcja policji, Straży Granicznej oraz Inspekcji Transportu Drogowego. Radiowozy można było dziś zobaczyć między innymi przy Dworcu Centralnym.

## Dyrektor Opery Wrocławskiej blisko utraty stanowiska. Zarząd województwa podjął uchwałę
 - [https://tvn24.pl/wroclaw/wroclaw-zarzad-wojewodztwa-dolnoslaskiego-podjal-uchwale-o-zamiarze-odwolania-haliny-oldakowskiej-ze-stanowiska-dyrektor-opery-6782818?source=rss](https://tvn24.pl/wroclaw/wroclaw-zarzad-wojewodztwa-dolnoslaskiego-podjal-uchwale-o-zamiarze-odwolania-haliny-oldakowskiej-ze-stanowiska-dyrektor-opery-6782818?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 12:08:15+00:00

<img alt="Dyrektor Opery Wrocławskiej blisko utraty stanowiska. Zarząd województwa podjął uchwałę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6jh4vx-opera-wroclawska-w-pelnej-krasie/alternates/LANDSCAPE_1280" />
    Zarząd województwa dolnośląskiego jednogłośnie podjął uchwałę o zamiarze odwołania Haliny Ołdakowskiej ze stanowiska dyrektor Opery Wrocławskiej. W ostatnich miesiącach w instytucji kulturalnej prowadzone były kontrole, które wykazały naruszenie prawa w zakresie dyscypliny finansów publicznych i to właśnie je wskazano jako powód odwołania.

## Na przejściu dla pieszych wyprzedził nieoznakowany radiowóz. Kara była dotkliwa
 - [https://tvn24.pl/pomorze/slupsk-na-przejsciu-dla-pieszych-wyprzedzil-nieoznakowany-radiowoz-kara-byla-dotkliwa-6783189?source=rss](https://tvn24.pl/pomorze/slupsk-na-przejsciu-dla-pieszych-wyprzedzil-nieoznakowany-radiowoz-kara-byla-dotkliwa-6783189?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 12:07:46+00:00

<img alt="Na przejściu dla pieszych wyprzedził nieoznakowany radiowóz. Kara była dotkliwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a42grw-wyprzedzil-radiowoz-na-pasach-6783488/alternates/LANDSCAPE_1280" />
    Kierowca ze Słupska (woj. pomorskie) wyprzedzał na przejściu dla pieszych. Miał pecha, bo manewr wykonał na oczach policjantów z nieoznakowanego radiowozu, który wyprzedził. Dostał mandat w wysokości 1,5 tys. złotych, został też ukarany 15 punktami karnymi.

## Taksówkarz nie miał prawa jazdy. Wpadł, bo nie zapiął pasów
 - [https://tvn24.pl/pomorze/inowroclaw-jezdzil-taksowka-bez-prawy-jazdy-i-zapietych-pasow-6782619?source=rss](https://tvn24.pl/pomorze/inowroclaw-jezdzil-taksowka-bez-prawy-jazdy-i-zapietych-pasow-6782619?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 11:48:51+00:00

<img alt="Taksówkarz nie miał prawa jazdy. Wpadł, bo nie zapiął pasów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9z38kk-policjanci-sprawdzali-czy-taksowkarze-maja-zapiete-pasy-bezpieczenstwa-6782469/alternates/LANDSCAPE_1280" />
    Policjanci z Inowrocławia (woj. kujawsko-pomorskie) zatrzymali kierowcę taksówki, który jechał bez zapiętych pasów. Co więcej nie posiadał uprawnień do kierowania pojazdami. Teraz mężczyzna poniesie konsekwencje swojego nieodpowiedzialnego zachowania.

## Jest decyzja w sprawie stopni alarmowych w Polsce
 - [https://tvn24.pl/biznes/z-kraju/stopnie-alarmowe-charlie-crp-i-bravo-w-polsce-do-konca-maja-2023-decyzja-premiera-mateusza-morawieckiego-6782810?source=rss](https://tvn24.pl/biznes/z-kraju/stopnie-alarmowe-charlie-crp-i-bravo-w-polsce-do-konca-maja-2023-decyzja-premiera-mateusza-morawieckiego-6782810?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 11:19:36+00:00

<img alt="Jest decyzja w sprawie stopni alarmowych w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ra7iel-warszawa-ulica-tlum-ludzie-nataly-reinch-shutterstock523956709-6708831/alternates/LANDSCAPE_1280" />
    Drugi stopień alarmowy BRAVO oraz trzeci stopień alarmowy CHARLIE-CRP na terytorium całego kraju będą obowiązywały do końca maja - poinformowało Rządowe Centrum Bezpieczeństwa. Zarządzenia w tej sprawie podpisał premier Mateusz Morawiecki.

## "Obrzydliwe" uniewinnienie skazanego za gwałt na 10-latce. Przez spór o nazwę żeńskich genitaliów
 - [https://tvn24.pl/swiat/szwecja-skazany-za-gwalt-na-10-latce-uniewinniony-przez-spor-o-nazwe-zenskich-genitaliow-6781727?source=rss](https://tvn24.pl/swiat/szwecja-skazany-za-gwalt-na-10-latce-uniewinniony-przez-spor-o-nazwe-zenskich-genitaliow-6781727?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 11:16:19+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q8at1w-shutterstock_1812892960-6782782/alternates/LANDSCAPE_1280" />
    Mężczyzna skazany w 2022 roku w Szwecji za gwałt na dziesięcioletniej dziewczynce został oczyszczony z zarzutów przez sąd apelacyjny. Powodem unieważnienia wyroku był spór o znaczenie słowa, którego dzieci używają na określenie żeńskich narządów rozrodczych - informują szwedzkie media. Decyzja sądu wywołała burzę wśród mieszkańców Szwecji.

## W co drugi tydzień praca przez cztery dni. Jest decyzja dużej polskiej firmy
 - [https://tvn24.pl/biznes/z-kraju/newag-wprowadza-czterodniowy-tydzien-pracy-6781943?source=rss](https://tvn24.pl/biznes/z-kraju/newag-wprowadza-czterodniowy-tydzien-pracy-6781943?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 11:16:09+00:00

<img alt="W co drugi tydzień praca przez cztery dni. Jest decyzja dużej polskiej firmy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-moef97-newag-6783502/alternates/LANDSCAPE_1280" />
    Dla optymalizacji kosztów podjęliśmy decyzję o pracy co drugi tydzień przez cztery dni robocze - przekazał Zbigniew Konieczek, prezes Newagu. W rozmowie z TVN24 Biznes rzecznik spółki Łukasz Mikołajczyk podał, że w zakładzie aktualnie pracuje około 1,5 tysiąca osób.

## Jeremy Renner dochodzi do siebie po wypadku. Aktor pokazał właśnie nagranie
 - [https://tvn24.pl/kultura-i-styl/jeremy-renner-wraca-do-zdrowia-po-wypadku-nowe-nagranie-6782624?source=rss](https://tvn24.pl/kultura-i-styl/jeremy-renner-wraca-do-zdrowia-po-wypadku-nowe-nagranie-6782624?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 11:14:30+00:00

<img alt="Jeremy Renner dochodzi do siebie po wypadku. Aktor pokazał właśnie nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8rf7in-jeremy-renner-6592277/alternates/LANDSCAPE_1280" />
    Jeremy Renner, który na samym początku roku uległ poważnemu wypadkowi przy odśnieżaniu, powoli wraca do zdrowia. Gwiazdor serii Avengers w poniedziałek pochwalił się na Instagramie postępami w rehabilitacji. Na nagraniu widać, że 52-latek jest już w stanie ćwiczyć na rowerze stacjonarnym.

## Konkurs na Europejskie Drzewo Roku dobiega końca. Jest też kandydat z Polski
 - [https://tvn24.pl/tvnmeteo/ciekawostki/konkurs-na-europejskie-drzewo-roku-2023-jak-glosowac-szanse-na-zwyciestwo-ma-lodzki-dab-fabrykant-6781954?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/konkurs-na-europejskie-drzewo-roku-2023-jak-glosowac-szanse-na-zwyciestwo-ma-lodzki-dab-fabrykant-6781954?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 10:30:44+00:00

<img alt="Konkurs na Europejskie Drzewo Roku dobiega końca. Jest też kandydat z Polski" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-xb9crz-dab-fabrykant-z-lodzi-6781956/alternates/LANDSCAPE_1280" />
    Konkurs na Europejskie Drzewo Roku 2023 zbliża się ku końcowi. Głosowanie na najciekawsze drzewo Starego Kontynentu trwa do ostatniego dnia lutego. Polskę w tym roku reprezentuje 180-letni Dąb Fabrykant z Łodzi - majestatyczna roślina będąca świadkiem przemysłowej historii miasta.

## Zderzenie ciężarówki z pociągiem. Kierowca trafił do szpitala
 - [https://tvn24.pl/pomorze/piechcin-ciezarowka-wjechala-pod-nadjezdzajacy-pociag-towarowy-6781978?source=rss](https://tvn24.pl/pomorze/piechcin-ciezarowka-wjechala-pod-nadjezdzajacy-pociag-towarowy-6781978?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 10:26:17+00:00

<img alt="Zderzenie ciężarówki z pociągiem. Kierowca trafił do szpitala" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m4fpkf-zderzenie-pociagu-z-samochodem-ciezarowym-w-piechcinie-6781968/alternates/LANDSCAPE_1280" />
    Zderzenie samochodu ciężarowego z pociągiem towarowym przewożącym kruszywo na niestrzeżonym przejeździe kolejowym w Piechcinie (woj. kujawsko-pomorskie). W wypadku ucierpiał kierowca, który został przetransportowany do szpitala w Inowrocławiu.

## Grupa Wagnera "zniszczyła pierwszy czołg Leopard" w Ukrainie? To fake news
 - [https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-grupa-wagnera-zniszczyla-pierwszy-czolg-leopard-w-ukrainie-to-fake-news-6780553?source=rss](https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-grupa-wagnera-zniszczyla-pierwszy-czolg-leopard-w-ukrainie-to-fake-news-6780553?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 10:17:57+00:00

<img alt="Grupa Wagnera " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fp8uyx-grupa-wagnera-zniszczyla-pierwszy-czolg-leopard-w-ukrainie-to-fake-news-6780890/alternates/LANDSCAPE_1280" />
    Autorzy wpisów w różnych językach informują, że najemnicy z Grupy Wagnera zniszczyli w Ukrainie pierwszy czołg Leopard z polsko-niemiecką załogą. Zdjęcie zniszczonego czołgu załączane do wpisów nie pochodzi jednak z Ukrainy, a z innego kraju.

## Media: "kłopotliwy" tytuł królowej małżonki Kamili będzie zmieniony po koronacji
 - [https://tvn24.pl/swiat/wielka-brytania-krolowa-malzonka-kamila-zmieni-po-koronacji-klopotliwy-tytul-media-6781902?source=rss](https://tvn24.pl/swiat/wielka-brytania-krolowa-malzonka-kamila-zmieni-po-koronacji-klopotliwy-tytul-media-6781902?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 10:17:05+00:00

<img alt="Media: " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9q609h-krolowa-malzonka-camilla-6167478/alternates/LANDSCAPE_1280" />
    Po zaplanowanej na maj koronacji króla Karola III "kłopotliwy" tytuł jego małżonki Kamili ma zostać zastąpiony jego "prostszą" wersją - donoszą brytyjskie media, powołując się na źródła związane z Pałacem Buckingham. Według nich Kamila ma przestać być tytułowana "królową małżonką" i zacząć być po prostu "królową".

## Najechał na tył auta dostawczego. Motocyklista nie żyje
 - [https://tvn24.pl/tvnwarszawa/ulice/janowek-najechal-na-tyl-auta-dostawczego-motocyklista-nie-zyje-6781963?source=rss](https://tvn24.pl/tvnwarszawa/ulice/janowek-najechal-na-tyl-auta-dostawczego-motocyklista-nie-zyje-6781963?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 09:53:51+00:00

<img alt="Najechał na tył auta dostawczego. Motocyklista nie żyje " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-f81qkz-wypadek-w-miejscowosci-janowek-6782002/alternates/LANDSCAPE_1280" />
    W Janówku koło Tarczyna motocyklista najechał na samochód dostawczy. Nie przeżył wypadku. Szczegółowe okoliczności ustala policja.

## Wypadek na stacji Ratusz Arsenał. Duże utrudnienia dla pasażerów
 - [https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-wypadek-na-stacji-ratusz-arsenal-duze-utrudnienia-dla-pasazerow-metra-6781927?source=rss](https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-wypadek-na-stacji-ratusz-arsenal-duze-utrudnienia-dla-pasazerow-metra-6781927?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 09:33:21+00:00

<img alt="Wypadek na stacji Ratusz Arsenał. Duże utrudnienia dla pasażerów" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ssyokf-utrudnienia-w-metrze-zdjecie-ilustracyjne-635455/alternates/LANDSCAPE_1280" />
    Do nieszczęśliwego wypadku doszło na pierwszej linii metra. Trwa akcja ratunkowa. Na miejscu pracują służby. Pasażerowie muszą liczyć się z utrudnieniami.

## Polska gospodarka wyhamowała. Nowe dane GUS
 - [https://tvn24.pl/biznes/z-kraju/pkb-polski-w-iv-kwartale-2022-gus-podal-dane-6781885?source=rss](https://tvn24.pl/biznes/z-kraju/pkb-polski-w-iv-kwartale-2022-gus-podal-dane-6781885?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 09:08:53+00:00

<img alt="Polska gospodarka wyhamowała. Nowe dane GUS" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bacdz8-warszawa-panorama-shutterstock2085556882-6623200/alternates/LANDSCAPE_1280" />
    Produkt Krajowy Brutto Polski w czwartym kwartale 2022 roku wzrósł o 2,0 procent w ujęciu rocznym w porównaniu ze wzrostem o 3,6 procent rok do roku w trzecim kwartale 2022 roku - wynika z komunikatu GUS. Odczyt jest zgodny z wcześniejszym szacunkiem flash GUS.

## Japonia ogłasza kolejne sankcje w związku z agresją Rosji na Ukrainę. Między innymi na Grupę Wagnera
 - [https://tvn24.pl/swiat/ukraina-rosja-japonia-oglasza-kolejne-sankcje-w-tym-takze-na-grupe-wagnera-6781662?source=rss](https://tvn24.pl/swiat/ukraina-rosja-japonia-oglasza-kolejne-sankcje-w-tym-takze-na-grupe-wagnera-6781662?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 08:54:09+00:00

<img alt="Japonia ogłasza kolejne sankcje w związku z agresją Rosji na Ukrainę. Między innymi na Grupę Wagnera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6swmbl-grupa-wagnera-i-jej-siedziba-w-petersburgu-w-rosji-6725577/alternates/LANDSCAPE_1280" />
    Władze Japonii ogłosiły rozszerzenie sankcji w związku z agresją Rosji na Ukrainę. Do listy objętych nimi podmiotów dopisano 143 osoby i instytucje. Są wśród nich rosyjscy politycy, wojskowi, biznesmeni, instytuty badawcze i firmy, w tym Grupa Wagnera i Rosbank.

## Biegacze na ulicach Teksasu podczas burzy piaskowej
 - [https://tvn24.pl/tvnmeteo/swiat/teksas-usa-burza-piaskowa-ograniczona-widzialnosc-na-ulicach-pojawily-sie-biegacze-6781685?source=rss](https://tvn24.pl/tvnmeteo/swiat/teksas-usa-burza-piaskowa-ograniczona-widzialnosc-na-ulicach-pojawily-sie-biegacze-6781685?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 08:48:39+00:00

<img alt="Biegacze na ulicach Teksasu podczas burzy piaskowej" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9fhr1s-burza-piaskowa-w-teksasie-6781694/alternates/LANDSCAPE_1280" />
    Przez zachodni Teksas przeszła seria burz piaskowych. Miejscami widzialność ograniczona była zaledwie do 200 metrów, a silny wiatr utrudniał poruszanie się nawet zmotoryzowanym. Na ulicach pojawiły się biegacze, czyli charakterystyczne "westernowe" rośliny.

## Czołowe zderzenie ciężarówki i samochodu. Jedna osoba nie żyje, DK 79 zablokowana
 - [https://tvn24.pl/tvnwarszawa/ulice/coniew-czolowe-zderzenie-ciezarowki-i-samochodu-jedna-osoba-nie-zyje-6781688?source=rss](https://tvn24.pl/tvnwarszawa/ulice/coniew-czolowe-zderzenie-ciezarowki-i-samochodu-jedna-osoba-nie-zyje-6781688?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 08:25:35+00:00

<img alt="Czołowe zderzenie ciężarówki i samochodu. Jedna osoba nie żyje, DK 79 zablokowana" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dlwagj-wypadek-w-miejscowosci-coniew-6781875/alternates/LANDSCAPE_1280" />
    W Coniewie koło Góry Kalwarii, na drodze krajowej numer 79 zderzyły się czołowo samochód i ciężarówka. Nie żyje kierowca auta osobowego. Droga jest zablokowana.

## Ovidio Guzman, syn gangstera "El Chapo" stanie przed amerykańskim sądem? USA chcą ekstradycji
 - [https://tvn24.pl/swiat/ovidio-guzman-syn-gangstera-el-chapo-stanie-przed-amerykanskim-sadem-usa-chca-ekstradycji-6781536?source=rss](https://tvn24.pl/swiat/ovidio-guzman-syn-gangstera-el-chapo-stanie-przed-amerykanskim-sadem-usa-chca-ekstradycji-6781536?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 08:24:14+00:00

<img alt="Ovidio Guzman, syn gangstera " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2vojfz-en_01400341_1594-1-6781539/alternates/LANDSCAPE_1280" />
    Stany Zjednoczone zwróciły się do władz Meksyku o ekstradycję Ovidio Guzmana - syna skazanego w USA na dożywocie barona narkotykowego Joaquina "El Chapo" Guzmana, aby mógł on stanąć przed amerykańskim sądem - poinformował Reuters. Agencja powołała się na informacje uzyskane od meksykańskich źródeł rządowych.

## Ukradł auto z pasażerem w środku i sprzedał je znajomemu
 - [https://tvn24.pl/katowice/jaworzno-ukradl-auto-z-pasazerem-w-srodku-i-sprzedal-je-znajomemu-6781014?source=rss](https://tvn24.pl/katowice/jaworzno-ukradl-auto-z-pasazerem-w-srodku-i-sprzedal-je-znajomemu-6781014?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 08:22:00+00:00

<img alt="Ukradł auto z pasażerem w środku i sprzedał je znajomemu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3tg4dk-samochod-kierownica-shutterstock1056150494-4766331/alternates/LANDSCAPE_1280" />
    Policjanci z Jaworzna (woj. śląskie) zatrzymali mężczyznę, który podejrzany jest o to, że ukradł samochód z pijanym pasażerem w środku, a po kilku dniach pojazd sprzedał znajomemu. Odzyskany pojazd wrócił już do właściciela. 37-latkowi za kradzież grozi do pięciu lat pozbawienia wolności.

## Od 1 marca zmiany cen biletów PKP Intercity
 - [https://tvn24.pl/biznes/z-kraju/pkp-intercity-zmiany-cen-biletow-od-1-marca-2023-6781584?source=rss](https://tvn24.pl/biznes/z-kraju/pkp-intercity-zmiany-cen-biletow-od-1-marca-2023-6781584?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 06:18:31+00:00

<img alt="Od 1 marca zmiany cen biletów PKP Intercity" src="https://tvn24.pl/najnowsze/cdn-zdjecie-725r20-shutterstock1589152165-6635667/alternates/LANDSCAPE_1280" />
    Od środy wracają ceny biletów w PKP Intercity do poziomów sprzed podwyżki z 11 stycznia. Ceny bazowe na połączenia kategorii TLK i IC będą średnio o około 11 procent niższe, zaś dla kategorii EIC i EIP średnio o około 15 procent.

## Oman otworzył dla Izraela przestrzeń powietrzną po wieloletniej blokadzie
 - [https://tvn24.pl/swiat/oman-otworzyl-dla-izraela-przestrzen-powietrzna-koniec-blokady-dla-izraelskich-samolotow-6781518?source=rss](https://tvn24.pl/swiat/oman-otworzyl-dla-izraela-przestrzen-powietrzna-koniec-blokady-dla-izraelskich-samolotow-6781518?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 04:45:00+00:00

<img alt="Oman otworzył dla Izraela przestrzeń powietrzną po wieloletniej blokadzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dz4llt-oman-otworzyl-dla-izraela-przestrzen-powietrzna-6781515/alternates/LANDSCAPE_1280" />
    W ślad za Arabią Saudyjską Oman otworzył dla Izraela przestrzeń powietrzną. W przekazanym na Twitterze oświadczeniu omański urząd lotnictwa cywilnego potwierdził, że "przestrzeń powietrzna Sułtanatu jest otwarta dla wszystkich przewoźników spełniających wymagania Urzędu w zakresie przelotów".

## Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-27-lutego-2023-6781527?source=rss](https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-27-lutego-2023-6781527?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 04:12:46+00:00

<img alt="Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kkyn2h-ukrainscy-zolnierze-strzelaja-z-spg-9-w-kierunku-rosyjskich-pozycji-na-linii-frontu-w-poblizu-wuhledaru-na-ukrainie-22-lutego-2023-r-6779266/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 370 dni. - Sytuacja na froncie pod Bachmutem stale robi się trudniejsza - powiadomił w poniedziałkowym, wieczornym wystąpieniu Wołodymyr Zełenski. Odnosząc się do kolejnego rosyjskiego ataku dronów, prezydent Ukrainy zaapelował o "przełamanie tabu na dostawy samolotów". Oto najważniejsze wydarzenia ostatnich godzin.

## Pogoda na dziś - wtorek 28.02. Zimno, ale będzie pojawiać się słońce
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-wtorek-2802-zimno-ale-bedzie-pojawiac-sie-slonce-6781289?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-wtorek-2802-zimno-ale-bedzie-pojawiac-sie-slonce-6781289?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-28 01:00:00+00:00

<img alt="Pogoda na dziś - wtorek 28.02. Zimno, ale będzie pojawiać się słońce" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-sfoy02-pogodnie-slonecznie-6781311/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Wtorek 28.02 w wielu miejscach przyniesie pogodne niebo. Nigdzie nie powinno padać. Termometry wskażą maksymalnie od 1 do 5 stopni Celsjusza. Biomet będzie korzystny.

