# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## WHO moves forward with plans to target “misinformation” and “disinformation” under international law
 - [https://reclaimthenet.org/who-target-misinformation-disinformation-international-law](https://reclaimthenet.org/who-target-misinformation-disinformation-international-law)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-28 19:17:12+00:00

<a href="https://reclaimthenet.org/who-target-misinformation-disinformation-international-law" rel="nofollow" title="WHO moves forward with plans to target &#8220;misinformation&#8221; and &#8220;disinformation&#8221; under international law"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/who-target-misinformation-disinformation-international-law.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The global health agency claims that misinformation and disinformation undermined "compliance with governmental or WHO guidance."</p>
<p>The post <a href="https://reclaimthenet.org/who-target-misinformation-disinformation-international-law" rel="nofollow">WHO moves forward with plans to target &#8220;misinformation&#8221; and &#8220;disinformation&#8221; under international law</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Some insight into how the IRS surveils money
 - [https://reclaimthenet.org/some-insight-into-how-the-irs-surveils-money](https://reclaimthenet.org/some-insight-into-how-the-irs-surveils-money)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-28 19:06:22+00:00

<a href="https://reclaimthenet.org/some-insight-into-how-the-irs-surveils-money" rel="nofollow" title="Some insight into how the IRS surveils money"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/ir-track.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>🛡</p>
<p>The post <a href="https://reclaimthenet.org/some-insight-into-how-the-irs-surveils-money" rel="nofollow">Some insight into how the IRS surveils money</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Sydney Mardi Gras Parade was monitored by mood tracking software
 - [https://reclaimthenet.org/sydney-mardi-gras-parade-was-monitored-by-mood-tracking-software](https://reclaimthenet.org/sydney-mardi-gras-parade-was-monitored-by-mood-tracking-software)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-28 18:44:48+00:00

<a href="https://reclaimthenet.org/sydney-mardi-gras-parade-was-monitored-by-mood-tracking-software" rel="nofollow" title="Sydney Mardi Gras Parade was monitored by mood tracking software"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/Sydney-mardis-gras.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Surveillance. </p>
<p>The post <a href="https://reclaimthenet.org/sydney-mardi-gras-parade-was-monitored-by-mood-tracking-software" rel="nofollow">Sydney Mardi Gras Parade was monitored by mood tracking software</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Ron DeSantis’ chooses Rumble, welcomes the company to Florida
 - [https://reclaimthenet.org/ron-desantis-chooses-rumble](https://reclaimthenet.org/ron-desantis-chooses-rumble)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-28 15:12:35+00:00

<a href="https://reclaimthenet.org/ron-desantis-chooses-rumble" rel="nofollow" title="Ron DeSantis&#8217; chooses Rumble, welcomes the company to Florida"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/desantis-rumble.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The YouTube alternative is growing rapidly.</p>
<p>The post <a href="https://reclaimthenet.org/ron-desantis-chooses-rumble" rel="nofollow">Ron DeSantis&#8217; chooses Rumble, welcomes the company to Florida</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Republicans plan to expand the Hatch Act to stop Biden administration’s censorship collusion
 - [https://reclaimthenet.org/republicans-plan-to-stop-biden-administrations-censorship-collusion](https://reclaimthenet.org/republicans-plan-to-stop-biden-administrations-censorship-collusion)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-28 15:07:37+00:00

<a href="https://reclaimthenet.org/republicans-plan-to-stop-biden-administrations-censorship-collusion" rel="nofollow" title="Republicans plan to expand the Hatch Act to stop Biden administration&#8217;s censorship collusion"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/biden-speech-2.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Two new proposals.</p>
<p>The post <a href="https://reclaimthenet.org/republicans-plan-to-stop-biden-administrations-censorship-collusion" rel="nofollow">Republicans plan to expand the Hatch Act to stop Biden administration&#8217;s censorship collusion</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Tony Blair praises Estonia for its digital ID system, where babies are given a digital ID at birth
 - [https://reclaimthenet.org/tony-blair-estonia-digital-id-at-birth](https://reclaimthenet.org/tony-blair-estonia-digital-id-at-birth)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-28 14:20:44+00:00

<a href="https://reclaimthenet.org/tony-blair-estonia-digital-id-at-birth" rel="nofollow" title="Tony Blair praises Estonia for its digital ID system, where babies are given a digital ID at birth"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/blair-estonia.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Wants other countries to follow.</p>
<p>The post <a href="https://reclaimthenet.org/tony-blair-estonia-digital-id-at-birth" rel="nofollow">Tony Blair praises Estonia for its digital ID system, where babies are given a digital ID at birth</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Commentator Dan Bongino launches live premiere show on Rumble video platform
 - [https://reclaimthenet.org/bongino-launches-live-premiere-show-on-rumble](https://reclaimthenet.org/bongino-launches-live-premiere-show-on-rumble)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-28 14:17:29+00:00

<a href="https://reclaimthenet.org/bongino-launches-live-premiere-show-on-rumble" rel="nofollow" title="Commentator Dan Bongino launches live premiere show on Rumble video platform"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/bongino-1223.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>A big win for the Big Tech alternative.</p>
<p>The post <a href="https://reclaimthenet.org/bongino-launches-live-premiere-show-on-rumble" rel="nofollow">Commentator Dan Bongino launches live premiere show on Rumble video platform</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

