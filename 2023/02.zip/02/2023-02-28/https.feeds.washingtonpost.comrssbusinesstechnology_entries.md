# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Meta joins porn sites in backing new tool to fight revenge porn
 - [https://www.washingtonpost.com/technology/2023/02/28/meta-revenge-porn-take-it-down/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/02/28/meta-revenge-porn-take-it-down/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-28 18:12:57+00:00

Meta is funding debut a new tool using AI to help young people remove sexual images of themselves posted without consent.

## Chinese state media calls out Elon Musk over coronavirus tweet
 - [https://www.washingtonpost.com/technology/2023/02/28/elon-musk-china-media-covid/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/02/28/elon-musk-china-media-covid/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-28 15:58:27+00:00

The Global Times called out Tesla CEO Elon Musk for responding to reports about the origination of the coronavirus.

## ‘Don’t buy eggs. Buy TVs.’ Electronics prices are defying inflation.
 - [https://www.washingtonpost.com/technology/2023/02/28/electronics-inflation-buy/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/02/28/electronics-inflation-buy/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-28 12:30:00+00:00

Prices are (mostly) falling for phones, laptops and TV. Here's how you can hunt for a good deal.

## Canada is latest country to ban TikTok on government phones
 - [https://www.washingtonpost.com/world/2023/02/28/canada-tiktok-ban-government-devices/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/world/2023/02/28/canada-tiktok-ban-government-devices/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-28 09:23:29+00:00

Canada's government said it had reviewed the Chinese-owned video-sharing app and “determined that it presents an unacceptable level of risk to privacy and security.”

## Windows 11 update brings Bing’s chatbot to the desktop
 - [https://www.washingtonpost.com/technology/2023/02/28/bing-ai-chatbot-windows-11-features/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/02/28/bing-ai-chatbot-windows-11-features/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-28 09:00:00+00:00

Thanks to a new update, Microsoft's fascinating Bing chatbot may soon find a home on your Windows desktop. But you may find some other new features handy first.

## See how this ‘cruelty-free’ circus replaced animals with holograms
 - [https://www.washingtonpost.com/technology/2023/02/28/hologram-circus-animals-roncalli/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/02/28/hologram-circus-animals-roncalli/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-28 07:22:04+00:00

The Circus-Theater Roncalli uses 3D holograms instead of real animals. The cruelty-free circus was the first of its kind.

## Governments shut down the internet more often than ever, report says
 - [https://www.washingtonpost.com/world/2023/02/28/internet-shutdowns-highest-india/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/world/2023/02/28/internet-shutdowns-highest-india/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-28 04:00:01+00:00

Authorities in 35 countries instituted internet shutdowns at least 187 times in 2022, according to rights group Access Now, with India doing so the most.

