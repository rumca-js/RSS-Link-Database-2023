# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Uh Oh.. Meta JUST Cancelled TWO VR Headsets
 - [https://www.youtube.com/watch?v=qIOuPy1nksA](https://www.youtube.com/watch?v=qIOuPy1nksA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2023-02-28 20:43:20+00:00

Hello and welcome to Tuesday Newsday, Your number one resource for the entire week's worth of VR news! Today we have a pretty exciting week (actually on a tuesday) consisting of hand tracking coming to the valve index, Meta winning a massive FTC anti trust case, An "XRAY AR Headset", two cancelled VR Headsets from Meta, AND OF COURSE! My PSVR2 impressions. Shoot, I'll hashtag it #psvr2 and #quest2 sheesh
Lots of fun stuff! hope you enjoyed!

hand tracking on WMR/ Valve Index:
https://www.collabora.com/news-and-blog/blog/2022/05/31/monado-hand-tracking-hand-waving-our-way-towards-a-first-attempt/

My links:
Support Content Like this on Patreon:
https://www.patreon.com/Thrillseeker
Discord: 
https://discord.gg/thrill
Twitter:
https://twitter.com/Thrilluwu
Outro Music:
https://youtu.be/u6JwgNQDVfI

