# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Eksport rosyjskiej ropy odporny na zachodnie sankcje? Oto najnowsze dane
 - [https://businessinsider.com.pl/gospodarka/eksport-rosyjskiej-ropy-odporny-na-zachodnie-sankcje-oto-dane-za-luty/z007qfc](https://businessinsider.com.pl/gospodarka/eksport-rosyjskiej-ropy-odporny-na-zachodnie-sankcje-oto-dane-za-luty/z007qfc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 20:50:21+00:00

Eksport rosyjskiej ropy drogą morską utrzymywał się w lutym na stabilnym poziomie. Rosja znalazła nowych nabywców, mimo że zachodnie sankcje zostały w pełni wprowadzone — pisze Bloomberg. Jednak agencja zauważa też, że rosyjski olej napędowy utknął na morzu — w pływających magazynach znajduje się obecnie najwięcej tego paliwa od października 2020 r.

## W Ukrainie zginęło więcej Rosjan niż łącznie we wszystkich konfliktach po II wojnie światowej
 - [https://businessinsider.com.pl/wiadomosci/ukraina-zginelo-wiecej-rosjan-niz-lacznie-we-wszystkich-walkach-po-ii-wojnie/xm4w8kx](https://businessinsider.com.pl/wiadomosci/ukraina-zginelo-wiecej-rosjan-niz-lacznie-we-wszystkich-walkach-po-ii-wojnie/xm4w8kx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 19:38:14+00:00

Rosja straciła w Ukrainie 60-70 tys. żołnierzy, więcej niż we wszystkich konfliktach, w których brała udział po II wojnie światowej, razem wziętych — poinformował w najnowszym raporcie amerykański think tank Centrum Studiów Strategicznych i Międzynarodowych (CSIS). Łączna liczba zabitych, zaginionych i rannych jest znacznie większa.

## O ile więcej wydaliśmy przez inflację? Oto kwota
 - [https://businessinsider.com.pl/gospodarka/o-ile-wiecej-przecietny-kowalski-wydal-przez-inflacje-oto-kwota/f58lvr0](https://businessinsider.com.pl/gospodarka/o-ile-wiecej-przecietny-kowalski-wydal-przez-inflacje-oto-kwota/f58lvr0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 19:19:20+00:00

Przez wzrost cen i fakt, że inflacja w Polsce bardzo mocno odjechała od celu wyznaczonego przez Narodowy Bank Polski, przeciętny Kowalski wydał w ubiegłym roku o 4,6 tys. zł więcej — wynika z wyliczeń ekonomisty Marcina Czaplickiego.

## Duńczycy znieśli święto, aby pokryć wydatki na wojsko
 - [https://businessinsider.com.pl/wiadomosci/dania-zniosla-swieto-aby-zaoszczedzic-na-to-przeznaczy-pieniadze/k5qz0dp](https://businessinsider.com.pl/wiadomosci/dania-zniosla-swieto-aby-zaoszczedzic-na-to-przeznaczy-pieniadze/k5qz0dp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 19:06:43+00:00

"W związku z obecną sytuacją w Europie musimy wydawać więcej pieniędzy na obronę i bezpieczeństwo" — powiedziała premier Danii. Duński parlament przegłosował zniesienie wolnego od pracy święta, co ma przynieść oszczędności w wysokości 400 mln euro, które będą przeznaczone na obronność.

## Francuzi będą pracować dłużej. Coraz bliżej reformy, która wyprowadziła ludzi na ulice
 - [https://businessinsider.com.pl/wiadomosci/francuzi-beda-pracowac-dluzej-coraz-blizej-reformy-ktora-wyprowadzila-ludzi-na-ulice/tyrlg4h](https://businessinsider.com.pl/wiadomosci/francuzi-beda-pracowac-dluzej-coraz-blizej-reformy-ktora-wyprowadzila-ludzi-na-ulice/tyrlg4h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 18:25:22+00:00

Choć sondaże wskazują, że dwie trzecie Francuzów jest przeciwko podniesieniu wieku emerytalnego z 62 do 64 lat, rząd wraz z prezydentem Emmanuelem Macronem nie ustają w wysiłkach, by przeforsować reformę. Komisja Senatu Francji zaakceptowała we wtorek tekst ustawy po wprowadzeniu kilku poprawek. Poprawki głównie wnoszą korzystniejsze rozwiązania w sprawie przechodzenia na emeryturę matek i ochrony starszych pracowników.

## Kredyt na zero procent? Sprawdzamy, czy to realne i ile można zyskać
 - [https://businessinsider.com.pl/finanse/kredyt-na-zero-procent-sprawdzamy-czy-to-realne-i-ile-mozna-zyskac/hfe8zt2](https://businessinsider.com.pl/finanse/kredyt-na-zero-procent-sprawdzamy-czy-to-realne-i-ile-mozna-zyskac/hfe8zt2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 17:29:49+00:00

Bankowcy nie skreślają propozycji Donalda Tuska dotyczącej darmowego kredytu mieszkaniowego. Podkreślają, że diabeł tkwi w szczegółach, ale główne założenia mogą mieć sens i banki przystąpiłyby do programu. O ile oczywiście zostałyby im odpowiednio zrekompensowane koszty odsetek oraz udzielenia i utrzymania kredytu. I tu pojawia się problem, bo wygląda na to, że na pomoc kredytobiorcom — liczoną w miliardach złotych — musieliby się złożyć podatnicy.

## Rosja odrzuca chiński plan pokojowy. Pekin coraz bardziej uwikłany w konflikt
 - [https://businessinsider.com.pl/wiadomosci/rosja-odrzuca-plan-pokojowy-chin-pekin-coraz-bardziej-uwiklany-w-konflikt/lgvrg1q](https://businessinsider.com.pl/wiadomosci/rosja-odrzuca-plan-pokojowy-chin-pekin-coraz-bardziej-uwiklany-w-konflikt/lgvrg1q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 17:19:56+00:00

Kreml w poniedziałek odrzucił chiński plan pokojowy dotyczący wojny w Ukrainie, sugerując, że obecna sytuacja nie sprzyja realizacji propozycji.

## Nie dostałeś PIT-11, urząd też nie? Tłumaczymy, co robić
 - [https://businessinsider.com.pl/prawo/podatki/firma-nie-przeslala-pit-11-co-robic-jak-zlozyc-rozliczenie-roczne-za-2022-r/2prxhl8](https://businessinsider.com.pl/prawo/podatki/firma-nie-przeslala-pit-11-co-robic-jak-zlozyc-rozliczenie-roczne-za-2022-r/2prxhl8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 16:43:37+00:00

Niektórzy czytelnicy informują, że nie dostali jeszcze PIT-11 od pracodawców i zleceniodawców. Chcieliby się już rozliczyć z urzędem skarbowym, ale nie mają pełnych danych. Niektórzy nie widzą też informacji od pracodawcy w Twoim e-PIT, w e-Urzędzie Skarbowym. Co robić w takich sytuacjach?

## Kolejny głos sprzeciwu w sprawie F-16 dla Ukrainy
 - [https://businessinsider.com.pl/wiadomosci/kolejny-glos-sprzeciwu-w-sprawie-f-16-dla-ukrainy/z3vntne](https://businessinsider.com.pl/wiadomosci/kolejny-glos-sprzeciwu-w-sprawie-f-16-dla-ukrainy/z3vntne)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 16:37:06+00:00

Adam Smith, przedstawiciel Demokratów w Komisji Sił Zbrojnych Senatu Stanów Zjednoczonych i były szef tej instytucji stwierdził, że przekazanie Ukrainie myśliwców F-16 "nie jest mądrym wykorzystaniem zasobów".

## Prokuratura wnioskuje o areszt dla Włodzimierza Karpińskiego
 - [https://businessinsider.com.pl/wiadomosci/zatrzymanie-wlodzimierza-karpinskiego-jest-wniosek-o-areszt/nqyn6z2](https://businessinsider.com.pl/wiadomosci/zatrzymanie-wlodzimierza-karpinskiego-jest-wniosek-o-areszt/nqyn6z2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 16:09:33+00:00

Po przesłuchaniu podejrzanego prokurator zdecydował o skierowaniu do sądu wniosku o zastosowanie tymczasowego aresztowania Włodzimierza K. wz. z zarzutem dotyczącym żądania i przyjęcia korzyści majątkowej — przekazał PAP we wtorek rzecznik Prokuratury Krajowej prok. Łukasz Łapczyński.

## Potrzeby pożyczkowe budżetu. Rząd podał, ile jeszcze brakuje
 - [https://businessinsider.com.pl/gospodarka/potrzeby-pozyczkowe-budzetu-rzad-podal-ile-jeszcze-brakuje/yfghtdq](https://businessinsider.com.pl/gospodarka/potrzeby-pozyczkowe-budzetu-rzad-podal-ile-jeszcze-brakuje/yfghtdq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 15:58:01+00:00

Na koniec lutego stopień sfinansowania tegorocznych potrzeb pożyczkowych brutto budżetu państwa wynosi ok. 61 proc., a stan środków na rachunkach budżetowych ok. 112 mld zł – poinformował we wtorek wiceminister finansów Sebastian Skuza. Z naszych szacunków wynika, że rząd będzie musiał pożyczyć na rynku jeszcze ponad 100 mld zł.

## "Może to i nawet zbyt duży ukłon w naszą stronę". Wojciechowski o propozycji Tuska
 - [https://businessinsider.com.pl/biznes/zbyt-duzy-uklon-w-nasza-strone-wojciechowski-o-propozycji-tuska/v0z0dfh](https://businessinsider.com.pl/biznes/zbyt-duzy-uklon-w-nasza-strone-wojciechowski-o-propozycji-tuska/v0z0dfh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 15:50:44+00:00

Donald Tusk znalazł dobry patent na kryzys w naszej branży. Może to i nawet zbyt duży ukłon w naszą stronę – mówi w rozmowie z "Wprost Biznes" Józef Wojciechowski. W ten sposób jeden z najbogatszych Polaków i właściciel firmy deweloperskiej J.W. Construction skomentował program mieszkaniowy Platformy Obywatelskiej.

## "Ekrany podano im w tym samym czasie co smoczki". Poznajcie pokolenie Zalfa
 - [https://businessinsider.com.pl/wiadomosci/ekrany-podano-im-w-tym-samym-czasie-co-smoczki-poznajcie-pokolenie-zalfa/hzh2lqd](https://businessinsider.com.pl/wiadomosci/ekrany-podano-im-w-tym-samym-czasie-co-smoczki-poznajcie-pokolenie-zalfa/hzh2lqd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 15:44:00+00:00

Słyszeliście już o pokoleniu Z. Być może znacie pokolenie Alfa. A teraz pozwólcie, że przedstawimy wam generację Zalfa, która wkrótce stanie się znaczącą siłą nabywczą.

## Plaga oszustw przy kasach samoobsługowych. Szykuje się zmiana prawa?
 - [https://businessinsider.com.pl/finanse/handel/plaga-oszustw-przy-kasach-samoobslugowych-szykuje-sie-zmiana-prawa/r59btmv](https://businessinsider.com.pl/finanse/handel/plaga-oszustw-przy-kasach-samoobslugowych-szykuje-sie-zmiana-prawa/r59btmv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 15:40:37+00:00

Podmiany cenówek przy kasach samoobsługowych to prawdziwa plaga. Pytanie, jak kwalifikować taki czyn. Posel Jarosław Sachajko z Kukiz'15 wysłał w tej sprawie interpelację do ministra sprawiedliwości — informuje serwis dlahandlu.pl.

## NIK skontrolował "Polskie szwalnie". Wnioski mogą oburzać
 - [https://businessinsider.com.pl/biznes/nik-skontrolowal-polskie-szwalnie-wnioski-moga-oburzac/wlhp4e6](https://businessinsider.com.pl/biznes/nik-skontrolowal-polskie-szwalnie-wnioski-moga-oburzac/wlhp4e6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 15:17:18+00:00

Najwyższa Izba kontroli skontrolowała "Polskie szwalnie". Uruchomiony w 2020 r. program miał zapewnić zaopatrzenie kraju w maseczki, a jednocześnie wesprzeć dotkniętych pandemią przedsiębiorców. Jak się okazuje, nie wszystko poszło, jak należy. Wnioski pokontrolne NIK opisuje "Rzeczpospolita".

## Obajtek: znów obniżyliśmy ceny oleju napędowego
 - [https://businessinsider.com.pl/gospodarka/obajtek-znow-obnizylismy-ceny-diesla/h4cs5q0](https://businessinsider.com.pl/gospodarka/obajtek-znow-obnizylismy-ceny-diesla/h4cs5q0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 14:44:06+00:00

— Dziś obniżyliśmy o następne 10 gr ceny oleju napędowego — powiedział we wtorek Daniel Obajtek. Prezes Orlenu odpowiadał także na zarzuty dotyczące zawyżania marż.

## Wygrał na loterii dwa miliardy dolarów. Nie może odebrać nagrody
 - [https://businessinsider.com.pl/wiadomosci/wygral-na-loterii-dwa-miliardy-dolarow-to-byl-poczatek-klopotow/dr2vv91](https://businessinsider.com.pl/wiadomosci/wygral-na-loterii-dwa-miliardy-dolarow-to-byl-poczatek-klopotow/dr2vv91)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 14:43:47+00:00

W popularnej amerykańskiej loterii Powerball padła w listopadzie 2022 r. rekordowa wygrana. Zwycięzca zdobył 2 mld dol., ale wokół szczęśliwego losu rozpętała się gigantyczna afera. Do organizatorów gry zgłosił się mężczyzna, który twierdzi, że skradziono mu zwycięski kupon niemal tuż przed losowaniem. Złożył pozew w Sądzie Najwyższym Hrabstwa Los Angeles.

## Intersport ma inwestora. To firma z Ukrainy
 - [https://businessinsider.com.pl/biznes/intersport-ma-inwestora-to-firma-z-ukrainy/07pvfxt](https://businessinsider.com.pl/biznes/intersport-ma-inwestora-to-firma-z-ukrainy/07pvfxt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 14:25:38+00:00

Intersport Polska ustalił z firmą EpicentrK warunki potencjalnej inwestycji w spółkę. Inwestor ma m.in. objąć akcje nowej emisji, za co spółka otrzyma ok. 10 mln euro — podała firma w komunikacie. Zawarcie umowy inwestycyjnej planowane jest do 3 kwietnia 2023 r.

## Żabka będzie badać trzeźwość pracowników
 - [https://businessinsider.com.pl/finanse/handel/zabka-bedzie-badac-trzezwosc-pracownikow/gf5z408](https://businessinsider.com.pl/finanse/handel/zabka-bedzie-badac-trzezwosc-pracownikow/gf5z408)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 14:24:08+00:00

Firma Żabka wprowadza możliwość kontroli trzeźwości wszystkich pracowników — poinformowała sieć sklepów. Po zmianie prawa na taki krok może zdecydować się każda firma.

## Globalny fintech syna polskiego emigranta w tarapatach. Mimo strat wziął podwyżkę
 - [https://businessinsider.com.pl/gielda/wiadomosci/sebastian-siemiatkowski-w-tarapatach-miliardy-strat-globalnego-fintechu-klarna/q4pkvf0](https://businessinsider.com.pl/gielda/wiadomosci/sebastian-siemiatkowski-w-tarapatach-miliardy-strat-globalnego-fintechu-klarna/q4pkvf0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 14:07:10+00:00

Sebastian Siemiątkowski jest synem polskiego emigranta. Urodził się w Szwecji rok po wyjeździe rodziców z PRLu i zbił niewiarygodny majątek. Z usług firmy założonej przez niego i dwóch kolegów ze szkoły korzysta 80 proc. Niemców, wbiła się też mocno do USA. Ale teraz ma poważne problemy. Co nie przeszkodziło Siemiątkowskiemu otrzymać wysokiej podwyżki.

## Szef PFR: jesteśmy w szczycie inflacji, wyhamuje na wiosnę
 - [https://businessinsider.com.pl/gospodarka/szef-pfr-jestesmy-w-szczycie-inflacji-wyhamuje-na-wiosne/nclcc0h](https://businessinsider.com.pl/gospodarka/szef-pfr-jestesmy-w-szczycie-inflacji-wyhamuje-na-wiosne/nclcc0h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 13:55:12+00:00

Obecnie przechodzimy przez najtrudniejszy moment w gospodarce, bo jednocześnie mamy do czynienia ze szczytowym momentem inflacji oraz ze spowolnieniem gospodarczym. Już wiosną sytuacja się jednak poprawi – mówi prezes Polskiego Funduszu Rozwoju Paweł Borys.

## Obajtek przedstawił strategię. Setki miliardów inwestycji Orlenu i obniżka cen gazu o połowę
 - [https://businessinsider.com.pl/gielda/wiadomosci/orlen-przedstawil-strategie-setki-miliardow-inwestycji-i-obnizka-cen-gazu-o-polowe/4gwr3k8](https://businessinsider.com.pl/gielda/wiadomosci/orlen-przedstawil-strategie-setki-miliardow-inwestycji-i-obnizka-cen-gazu-o-polowe/4gwr3k8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 13:29:28+00:00

PKN Orlen przewiduje w aktualizacji strategii nakłady inwestycyjne w wysokości 320 mld zł do 2030 r., w tym 120 mld zł tzw. inwestycji zielonych. W Polsce za siedem lat mają też działać małomodułowe elektrownie jądrowe Orlenu. Ceny gazu dla biznesu mają spaść od połowy marca.

## Nowe wozy bojowe dla wojska zamówione. Sprzęt pamiętający ZSRR zastąpią borsuki
 - [https://businessinsider.com.pl/wiadomosci/nowe-wozy-bojowe-dla-wojska-zamowione-sprzet-pamietajacy-zsrr-zastapia-borsuki/5tjl9xn](https://businessinsider.com.pl/wiadomosci/nowe-wozy-bojowe-dla-wojska-zamowione-sprzet-pamietajacy-zsrr-zastapia-borsuki/5tjl9xn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 13:28:26+00:00

Szef MON Mariusz Błaszczak zatwierdził umowę ramową na dostawę blisko 1400 nowych pojazdów dla wojska, w tym blisko 1000 gąsienicowych bojowych wozów piechoty Borsuk oraz pojazdy towarzyszące. Nowe pojazdy mają zastąpić skonstruowane w ZSRR wozy BWP-1. Pierwsze cztery borsuki mają zostać dostarczone w tym roku.

## Co drugi tydzień praca przez cztery dni. Jest decyzja wielkiej polskiej firmy
 - [https://businessinsider.com.pl/prawo/praca/co-drugi-tydzien-praca-przez-cztery-dni-przelomowa-decyzja-wielkiej-polskiej-firmy/35mck8p](https://businessinsider.com.pl/prawo/praca/co-drugi-tydzien-praca-przez-cztery-dni-przelomowa-decyzja-wielkiej-polskiej-firmy/35mck8p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 13:26:36+00:00

— Podjęliśmy decyzję o pracy co drugi tydzień przez cztery dni robocze. W takim wariancie będziemy działali do kwietnia — poinformował prezes firmy Newag Zbigniew Konieczek. Powód? Optymalizacja kosztów — obecnie w Polsce nie ma bowiem żadnych nowych przetargów

## Orlen obniża ceny gazu, m.in. dla piekarni. Kto jeszcze skorzysta?
 - [https://businessinsider.com.pl/biznes/obajtek-zapowiedzial-obnizke-cen-gazu-min-dla-piekarni-kto-skorzysta/17w0ygg](https://businessinsider.com.pl/biznes/obajtek-zapowiedzial-obnizke-cen-gazu-min-dla-piekarni-kto-skorzysta/17w0ygg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 13:19:11+00:00

Prezes Orlenu Daniel Obajtek zapowiedział we wtorek, że od połowy marca koncern obniża ceny gazu o ponad 50 proc. dla 130 tys. klientów biznesowych. — To są cukiernie, piekarnie, drobne zakłady — powiedział Obajtek na konferencji prasowej.

## Morawiecki: nadwyżka budżetu w styczniu 2023 r. wyniosła ponad 11 mld zł
 - [https://businessinsider.com.pl/gospodarka/morawiecki-nadwyzka-budzetu-w-styczniu-2023-r-wyniosla-ponad-11-mld-zl/czng3cx](https://businessinsider.com.pl/gospodarka/morawiecki-nadwyzka-budzetu-w-styczniu-2023-r-wyniosla-ponad-11-mld-zl/czng3cx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 13:06:21+00:00

— W styczniu tego roku zrealizowaliśmy budżet nadwyżkowy. Mamy nadwyżkę ponad 11 mld zł w budżecie — powiedział premier Mateusz Morawiecki na konferencji prasowej. — Dzięki tym nadwyżkom możemy realizować śmiałą politykę inwestycyjną — dodał.

## Premier poważnie przejęzyczył się w sprawie trzynastek. Rzecznik tłumaczy i uspokaja seniorów
 - [https://businessinsider.com.pl/twoje-pieniadze/emerytury/premier-przejezyczyl-sie-w-sprawie-trzynastek-rzecznik-rzadu-tlumaczy/62l9hdj](https://businessinsider.com.pl/twoje-pieniadze/emerytury/premier-przejezyczyl-sie-w-sprawie-trzynastek-rzecznik-rzadu-tlumaczy/62l9hdj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 12:50:29+00:00

Premier Mateusz Morawiecki podczas wizyty w Gryfowie Śląskim zapowiedział, że 13. emerytury będą wypłacane w maju i czerwcu. To wbrew temu, co mówi ustawa, która w tym kontekście wskazuje kwiecień. Seniorzy wystraszyli się, że pieniądze dostaną później. Teraz okazuje sie, że premier się przejęzyczył.

## Raport wywiadu: Rosja szykuje się do długiej wojny
 - [https://businessinsider.com.pl/wiadomosci/raport-wywiadu-rosja-szykuje-sie-do-dlugiej-wojny/mzgr57b](https://businessinsider.com.pl/wiadomosci/raport-wywiadu-rosja-szykuje-sie-do-dlugiej-wojny/mzgr57b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 12:39:50+00:00

Rosjanie przygotowują się do długiej wojny na Ukrainie, użycie przez nich broni nuklearnej wydaje się nieprawdopodobne — to wnioski z ogłoszonego we wtorek raportu włoskich służb specjalnych dla parlamentu. Według wywiadu należy spodziewać się dalszych cyberataków ze strony Rosji oraz prób ingerencji w politykę państw NATO.

## Szef NATO: jesteśmy w krytycznym momencie
 - [https://businessinsider.com.pl/wiadomosci/szef-nato-jestesmy-w-krytycznym-momencie/4xed7m2](https://businessinsider.com.pl/wiadomosci/szef-nato-jestesmy-w-krytycznym-momencie/4xed7m2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 12:28:36+00:00

Nie ma oznak, aby Putin dążył do pokoju i zmienił swoje plany; w kwestii bezpieczeństwa jesteśmy w krytycznym momencie – oświadczył we wtorek w Helsinkach sekretarz generalny NATO Jens Stoltenberg.

## 55 mln zł dla 26-latka. Marian Banaś zapowiada wejście NIK
 - [https://businessinsider.com.pl/wiadomosci/55-mln-zl-dla-26-latka-marian-banas-zapowiada-wejscie-nik/ebz7yfb](https://businessinsider.com.pl/wiadomosci/55-mln-zl-dla-26-latka-marian-banas-zapowiada-wejscie-nik/ebz7yfb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 12:15:47+00:00

Będzie kontrola Najwyższej Izby Kontroli w NCBR. — Wpłynęło wiele wniosków o przeprowadzenie kontroli. NCBR wydał prawie 800 mln złotych w konkursie "Szybka ścieżka" — przekazał prezes NIK Marian Banaś. Chodzi m.in. o sprawę 55 mln zł dotacji dla spółki 26-latka.

## Kiedy kredyty mieszkaniowe na 2 proc.? Padła data
 - [https://businessinsider.com.pl/poradnik-finansowy/kredyty/kiedy-kredyty-mieszkaniowe-na-2-proc-padla-data/qk9c9ph](https://businessinsider.com.pl/poradnik-finansowy/kredyty/kiedy-kredyty-mieszkaniowe-na-2-proc-padla-data/qk9c9ph)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 12:09:11+00:00

Premier Mateusz Morawiecki został zapytany podczas konferencji prasowej, kiedy ruszy nowy program mieszkaniowy Prawa i Sprawiedliwości. — Chcemy, by został przegłosowany w ciągu najbliższych kilku miesięcy, tak, by wszedł w życie pierwszego lipca — zadeklarował premier.

## Warren Buffett zainwestował niespotykaną kwotę w akcje
 - [https://businessinsider.com.pl/wiadomosci/warren-buffett-zainwestowal-niespotykana-kwote-w-akcje/vr6vv2l](https://businessinsider.com.pl/wiadomosci/warren-buffett-zainwestowal-niespotykana-kwote-w-akcje/vr6vv2l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 11:54:38+00:00

Jak wynika z ostatniego raportu rocznego, Berkshire Hathaway Warrena Buffetta wydało w 2022 r. prawie 70 mld dol. na akcje. W tym samym czasie firma słynnego inwestora ograniczyła wykup akcji, ale nadal wykorzystywała część swoich rezerw gotówkowych.

## Warrena Buffet zainwestował niespotykaną kwotę w akcje
 - [https://businessinsider.com.pl/wiadomosci/warrena-buffet-zainwestowal-niespotykana-kwote-w-akcje/vr6vv2l](https://businessinsider.com.pl/wiadomosci/warrena-buffet-zainwestowal-niespotykana-kwote-w-akcje/vr6vv2l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 11:54:38+00:00

Jak wynika z ostatniego raportu rocznego, Berkshire Hathaway Warrena Buffetta wydało w 2022 r. prawie 70 mld dol. na akcje. W tym samym czasie firma słynnego inwestora ograniczyła wykup akcji, ale nadal wykorzystywała część swoich rezerw gotówkowych.

## Morawiecki zapytany o rosyjską ropę. Wymijająca odpowiedź
 - [https://businessinsider.com.pl/gospodarka/morawiecki-zapytany-o-rosyjska-rope-wymijajaca-odpowiedz/hlptsq9](https://businessinsider.com.pl/gospodarka/morawiecki-zapytany-o-rosyjska-rope-wymijajaca-odpowiedz/hlptsq9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 11:49:13+00:00

— Moglibyśmy nie odbierać tych 10 proc. ropy, za którą i tak musielibyśmy płacić — tak o rosyjskiej ropie mówił premier Mateusz Morawiecki. Przypomnijmy, że wcześniej rząd sugerował, że w 2023 r. Polska nie sprowadza żadnej ropy z kraju Putina. Teraz premier niejako przyznał, że surowiec w styczniu do naszego kraju płynął.

## Elon Musk wraca do gry. Znów na szczycie listy najbogatszych ludzi świata
 - [https://businessinsider.com.pl/biznes/elon-musk-wraca-do-gry-znow-na-szczycie-listy-najbogatszych-ludzi-swiata/npcstdk](https://businessinsider.com.pl/biznes/elon-musk-wraca-do-gry-znow-na-szczycie-listy-najbogatszych-ludzi-swiata/npcstdk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 11:45:22+00:00

Majątek Muska, szefa wielu firm, w tym Tesli i Twittera, wynosi obecnie 187,1 mld dol. netto  - podaje Bloomberg. Miliarder pokonał tym samym prezesa LVMH Bernarda Arnaulta, wyprzedzając szefa konglomeratu luksusowych marek na liście najbogatszych. Majątek  netto Arnaulta wynosi 182 mld dol. – wynika z indeksu miliarderów Bloomberga.

## Władimir Putin wręczył Stevenowi Seagalowi nagrodę przyjaźni i pochwalił jego pracę humanitarną
 - [https://businessinsider.com.pl/wiadomosci/znany-amerykanski-aktor-z-orderem-od-putina-kocham-rosje-i-waszego-prezydenta/kxbr999](https://businessinsider.com.pl/wiadomosci/znany-amerykanski-aktor-z-orderem-od-putina-kocham-rosje-i-waszego-prezydenta/kxbr999)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 11:29:29+00:00

Prezydent Rosji Władimir Putin przyznał aktorowi Stevenowi Seagalowi Order Przyjaźni. Dekret Putina z 27 lutego uhonorował Seagala, który ma podwójne obywatelstwo (amerykańskie i rosyjskie) za jego "wielki wkład w rozwój międzynarodowej współpracy kulturalnej i humanitarnej".

## mObywatel na równi z dowodem osobistym. Rząd zmienia przepisy
 - [https://businessinsider.com.pl/wiadomosci/mobywatel-na-rowni-z-dowodem-osobistym-rzad-zmienia-przepisy/1n3dn25](https://businessinsider.com.pl/wiadomosci/mobywatel-na-rowni-z-dowodem-osobistym-rzad-zmienia-przepisy/1n3dn25)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 11:26:26+00:00

Aplikacja mObywatel będzie traktowana dokładnie tak samo, jak tradycyjny plastikowy dowód osobisty. To jedno z głównych założeń projektu ustawy, który we wtorek przyjął rząd.

## Tyle węgla Polakom rozdały samorządy
 - [https://businessinsider.com.pl/wiadomosci/tyle-wegla-polakom-rozdaly-samorzady/sr2xqkx](https://businessinsider.com.pl/wiadomosci/tyle-wegla-polakom-rozdaly-samorzady/sr2xqkx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 11:20:52+00:00

Wiceminister aktywów państwowych Karol Rabenda przekazał, ile węgla trafiło do Polaków za pośrednictwem samorządów. To prawie dwa miliony ton.

## Broniarz: domagamy się 20 proc. podwyżki dla nauczycieli
 - [https://businessinsider.com.pl/gospodarka/broniarz-domagamy-sie-20-proc-podwyzki-dla-nauczycieli/dtdq3jf](https://businessinsider.com.pl/gospodarka/broniarz-domagamy-sie-20-proc-podwyzki-dla-nauczycieli/dtdq3jf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 11:10:44+00:00

Domagamy się 20-procentowego wzrostu wynagrodzeń nauczycieli od 1 lipca. Mamy gotowy projekt dotyczący praktycznej realizacji tego pomysłu – poinformował we wtorek prezes ZNP Sławomir Broniarz. Przedstawiciele związku zapowiedzieli, że projekt złożą w Sejmie 9 marca.

## "Gospodarka nabiera zapasów jak szalona", a "uchodźcy maskowali spadki". Komentarze ekonomistów do PKB
 - [https://businessinsider.com.pl/gospodarka/gospodarka-nabiera-zapasow-jak-szalona-komentarze-ekonomistow-do-pkb/kvxl0b9](https://businessinsider.com.pl/gospodarka/gospodarka-nabiera-zapasow-jak-szalona-komentarze-ekonomistow-do-pkb/kvxl0b9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 11:06:32+00:00

W ostatnich dziewięciu miesiącach ub.r. PKB spadł w Polsce o aż 3,7 proc. —wyliczyli ekonomiści. W pierwszym kwartale możemy się spodziewać spadku gospodarczego, a we wzroście przeszkadza inflacja, która uporczywie utrzymuje się na wysokim poziomie, jeśli chodzi o dane bazowe. Wskazuje się też na fakt, że w ub.r. popyt ze strony uchodźców maskował złe wyniki gospodarki.

## Premier przedłużył stopnie alarmowe Charlie-CRP i Bravo
 - [https://businessinsider.com.pl/wiadomosci/premier-przedluzyl-stopnie-alarmowe-charlie-crp-i-bravo/mhg0p0r](https://businessinsider.com.pl/wiadomosci/premier-przedluzyl-stopnie-alarmowe-charlie-crp-i-bravo/mhg0p0r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 10:32:21+00:00

Premier Mateusz Morawiecki podpisał zarządzenia, które przedłużają do 31 maja 2023 r. obowiązywanie stopni alarmowych: 3. stopnia CHARLIE-CRP, 2. stopnia BRAVO na terenie całego kraju oraz 2. stopnia BRAVO wobec polskiej infrastruktury energetycznej, mieszczącej się poza granicami Rzeczypospolitej Polskiej - poinformowało Rządowe Centrum Bezpieczeństwa.

## "Biała wyspa" na mapie drożyzny. Co się dzieje z cenami mleka?
 - [https://businessinsider.com.pl/gospodarka/biala-wyspa-na-mapie-drozyzny-co-sie-dzieje-z-cenami-mleka/jp6g6f5](https://businessinsider.com.pl/gospodarka/biala-wyspa-na-mapie-drozyzny-co-sie-dzieje-z-cenami-mleka/jp6g6f5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 10:20:21+00:00

Kiedy niemal wszystkie wskaźniki cen świecą się na czerwono, w przypadku mleka możemy mówić o zielonej, a w tym przypadku może lepiej pasuje — białej wyspie. W styczniu litr tego produktu kosztował w skupach o prawie 30 gr mniej niż w grudniu 2022 r. — zauważa portal interia.pl. Sytuacja w Polsce jest pokłosiem tego, co dzieje się na świecie i bardzo niepokoi rolników oraz producentów. Twierdzą, że zarobią na tym tylko wielkie sieci sklepów.

## Premier przedłużył stopnie alarmowe Charlie-CRP i Bravo
 - [https://businessinsider.com.pl/wiadomosci/premier-przedluzyl-stopnie-alarmowe-charlie-crp-i-bravo/3vp3r1r](https://businessinsider.com.pl/wiadomosci/premier-przedluzyl-stopnie-alarmowe-charlie-crp-i-bravo/3vp3r1r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 10:14:40+00:00

Premier Mateusz Morawiecki podpisał zarządzenia, które przedłużają do 31 maja 2023 r. obowiązywanie stopni alarmowych: 3. stopnia CHARLIE-CRP, 2. stopnia BRAVO na terenie całego kraju oraz 2. stopnia BRAVO wobec polskiej infrastruktury energetycznej, mieszczącej się poza granicami Rzeczypospolitej Polskiej - poinformowało Rządowe Centrum Bezpieczeństwa.

## Od środy mnóstwo zmian, które dotkną nawet 25 mln Polaków. Oto osiem najważniejszych
 - [https://businessinsider.com.pl/gospodarka/osiem-najwazniejszych-zmian-od-marca-dotkna-nawet-25-mln-polakow/xr604sz](https://businessinsider.com.pl/gospodarka/osiem-najwazniejszych-zmian-od-marca-dotkna-nawet-25-mln-polakow/xr604sz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 10:01:03+00:00

Pracownicy, emeryci, renciści, kierowcy, mundurowi, podróżni, przedsiębiorcy, budujący dom lub mieszkanie, pacjenci — bardzo prawdopodobne, że każdy czytający te słowa należy przynajmniej do jednej z wymienionych grup. A jeśli tak, to musi się przygotować na spore zmiany już od jutra. Większość z nich dotyczy naszych portfeli. Oto osiem najważniejszych marcowych zmian dla nawet 25 mln Polaków.

## Minister odpowiada na raport OECD. Co z wiekiem emerytalnym w Polsce?
 - [https://businessinsider.com.pl/wiadomosci/minister-odpowiada-na-raport-oecd-co-z-wiekiem-emerytalnym-w-polsce/7gjkvmz](https://businessinsider.com.pl/wiadomosci/minister-odpowiada-na-raport-oecd-co-z-wiekiem-emerytalnym-w-polsce/7gjkvmz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 09:32:43+00:00

Organizacji Współpracy Gospodarczej i Rozwoju (OECD) sugeruje, że Polskę czekają ciężkie demograficznie czasy, które będą wymagały niepopularnych politycznie decyzji. Do sprawy odniosła się minister rodziny Marlena Maląg.

## Volkswagen od Niemca wciąż celem Polaków. A co za nim? Oto dane o sprowadzanych autach
 - [https://businessinsider.com.pl/technologie/motoryzacja/volkswagen-od-niemca-wciaz-celem-polakow-a-co-za-nim-oto-dane-o-sprowadzanych-autach/t05t0zf](https://businessinsider.com.pl/technologie/motoryzacja/volkswagen-od-niemca-wciaz-celem-polakow-a-co-za-nim-oto-dane-o-sprowadzanych-autach/t05t0zf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 09:03:45+00:00

Sprowadzanie aut do Polski jest coraz droższe. Średnia cena transportu samochodu z zagranicy wzrosła w 2022 r. o 19 proc. Wciąż pozostaje to jednak kuszącą opcją dla kierowców znad Wisły. Raport serwisu Clicktrans ujawnia, jakie marki i skąd najchętniej ściągają Polacy.

## PKB ostro w dół. Jeden z największych spadków w historii
 - [https://businessinsider.com.pl/gospodarka/pkb-ostro-w-dol-jeden-z-najwiekszych-spadkow-w-historii/r8dh0g5](https://businessinsider.com.pl/gospodarka/pkb-ostro-w-dol-jeden-z-najwiekszych-spadkow-w-historii/r8dh0g5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 09:01:59+00:00

PKB Polski w czwartym kwartale spadł o 2,4 proc. w porównaniu z kwartałem poprzednim—podał GUS we wtorek. I jest jeszcze jedna zła wiadomość. Mamy do czynienia z wydarzeniami historycznymi, bo to jeden z największych spadków od wielu lat.

## Renault Kangoo Van 1.5 dCi – z dieslem, czyli do pracy
 - [https://businessinsider.com.pl/technologie/motoryzacja/renault-kangoo-van-15-dci-z-dieslem-czyli-do-pracy-test/2f757xz](https://businessinsider.com.pl/technologie/motoryzacja/renault-kangoo-van-15-dci-z-dieslem-czyli-do-pracy-test/2f757xz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 09:00:00+00:00

Renault Kangoo to auto znane od wielu lat i cenione przez przedsiębiorców, którzy potrzebują małego dostawczaka, zwinnego w mieście, lecz pakownego. W roli praktycznego vana Kangoo sprawdza się znakomicie, a z dieslem jest dodatkowo

## Polacy popadają w finansowe tarapaty. Młodzi w najgorszej sytuacji
 - [https://businessinsider.com.pl/finanse/polacy-popadaja-w-finansowe-tarapaty-mlodzi-w-najgorszej-sytuacji/3tjz67f](https://businessinsider.com.pl/finanse/polacy-popadaja-w-finansowe-tarapaty-mlodzi-w-najgorszej-sytuacji/3tjz67f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 08:40:59+00:00

Zdecydowana większość Polaków ocenia, że ich sytuacja finansowa pogorszyła się w ciągu roku — wynika z badania przeprowadzonego na zlecenie Santander Consumer Banku. Wśród młodych ten odsetek sięga aż 81 proc. Na oszczędzanie są w stanie sobie pozwolić tylko najbogatsi Polacy.

## Monopole mają się dobrze, reszta odwrotnie. "Ożywienie gospodarki mało prawdopodobne"
 - [https://businessinsider.com.pl/gospodarka/monopole-maja-sie-dobrze-reszta-musi-za-to-placic-biec-ozywienie-gospodarki-malo/e619bvw](https://businessinsider.com.pl/gospodarka/monopole-maja-sie-dobrze-reszta-musi-za-to-placic-biec-ozywienie-gospodarki-malo/e619bvw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 08:31:05+00:00

Analitycy Biura Inwestycji i Cykli Ekonomicznych wskazują na zmonopolizowanie gospodarki jako jeden z czynników jej obecnych problemów. Z najnowszego badania wskaźnika wyprzedzającego koniunktury wynika, że ożywienie nie nastąpi w najbliższych miesiącach — podało Biuro Inwestycji i Cykli Ekonomicznych BIEC.

## Kurs franka 28 lutego poniżej 4,8 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-28-lutego-2023/sngmnlp](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-28-lutego-2023/sngmnlp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 08:07:33+00:00

Frank szwajcarski poniżej 4,8 zł. W wtorek rano 28 lutego 2023 r. kurs tej waluty wobec polskiego złotego wynosi 4,7678.

## Kurs dolara 28 lutego w okolicy 4,5 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-28-lutego-2023/l91q3vz](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-28-lutego-2023/l91q3vz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 08:05:54+00:00

Kurs dolara w okolicy 4,5 zł. We wtorek rano 28 lutego 2023 r. kurs USD/PLN wynosi 4,4540.

## Kurs euro 28 lutego poniżej 4,75 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-28-lutego-2023/gknlnpz](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-28-lutego-2023/gknlnpz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 08:01:24+00:00

Kurs euro poniżej 4,75 zł. We wtorek rano 28 lutego 2023 r. kurs EUR/PLN wynosił 4,7181 zł.

## Atak hakerski na podatkową stronę rządu. PIT-a nie rozliczysz
 - [https://businessinsider.com.pl/wiadomosci/atak-hakerski-na-podatkowa-strone-rzadu-pit-a-nie-rozliczysz/1sbbwcl](https://businessinsider.com.pl/wiadomosci/atak-hakerski-na-podatkowa-strone-rzadu-pit-a-nie-rozliczysz/1sbbwcl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 07:30:01+00:00

Hakerzy zaatakowali rządową stronę podatki.gov.pl. To serwis, w którym miliony Polaków mogą rozliczyć zeszłoroczny PIT. Strona przestałą działać tuż po godzinie 8 rano, a jak informuje RMF FM, dane podatników są bezpieczne.

## Jednak nie atak hakerski. Ministerstwo tłumaczy problemy z PIT-ami
 - [https://businessinsider.com.pl/wiadomosci/jednak-nie-atak-hakerski-ministerstwo-tlumaczy-problemy-z-pit-ami/1sbbwcl](https://businessinsider.com.pl/wiadomosci/jednak-nie-atak-hakerski-ministerstwo-tlumaczy-problemy-z-pit-ami/1sbbwcl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 07:30:01+00:00

RMF FM informował, że hakerzy zaatakowali rządową stronę podatki.gov.pl. To serwis, w którym miliony Polaków mogą rozliczyć zeszłoroczny PIT. Strona przestałą działać tuż po godzinie 8 rano. Ministerstwo finansów zapewnia, że przyczyną problemów była awaria, a nie ingerencja hakerów.

## We wtorek wygasają deklaracje, od środy autozapis do PPK. Tak wpłynie na wypłaty
 - [https://businessinsider.com.pl/poradnik-finansowy/we-wtorek-wygasaja-deklaracje-od-srody-autozapis-do-ppk-tak-wplynie-na-wyplaty/r63tvsv](https://businessinsider.com.pl/poradnik-finansowy/we-wtorek-wygasaja-deklaracje-od-srody-autozapis-do-ppk-tak-wplynie-na-wyplaty/r63tvsv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 07:21:29+00:00

28 lutego wygasają deklaracje o rezygnacji z dokonywania wpłat do Pracowniczych Planów Kapitałowych. Od 1 marca pracownicy znów zostaną zapisani do programu i ewentualnie znów będą musieli składać wnioski o rezygnację. Od 1 kwietnia natomiast pracodawcy wznowią dokonywanie wpłat do PPK dla tych, którzy w systemie pozostaną.

## PiS powtórzy ruch Tuska w sprawie emerytów? Taka jest sugestia OECD
 - [https://businessinsider.com.pl/gospodarka/pis-powtorzy-ruch-tuska-taka-jest-sugestia-oecd/rlbqffl](https://businessinsider.com.pl/gospodarka/pis-powtorzy-ruch-tuska-taka-jest-sugestia-oecd/rlbqffl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 06:58:13+00:00

Choć dziś zarówno Jarosław Kaczyński, jak i Donald Tusk rękami i nogami wzbraniają się przed podwyżką wieku emerytalnego, to OECD właśnie taki ruch Polsce zasugerowało i podało twarde argumenty. Zdaniem organizacji w naszym kraju należy bowiem nie tylko podnieść, ale też zrównać moment przejścia na emeryturę dla kobiet i mężczyzn, co wpłynie na dodatkowy wzrost PKB. Alternatywa? Zdaniem OECD: głodowe świadczenia na starość.

## W środę finał "afery biletowej". Wracają stare ceny
 - [https://businessinsider.com.pl/wiadomosci/w-srode-final-afery-biletowej-wracaja-stare-ceny/26d57m9](https://businessinsider.com.pl/wiadomosci/w-srode-final-afery-biletowej-wracaja-stare-ceny/26d57m9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 06:28:46+00:00

Od środy, 1 marca ceny biletów w PKP Intercity spadną do poziomów sprzed podwyżki wprowadzonej 11 stycznia tego roku. Ceny bazowe na połączenia kategorii TLK i IC będą średnio o ok. 11 proc. niższe, natomiast dla kategorii EIC i EIP – średnio o ok. 15 proc.

## Polska prymusem wśród krajów NATO. Tyle wydajemy na uzbrojenie
 - [https://businessinsider.com.pl/gospodarka/polska-prymusem-wsrod-krajow-nato-tyle-wydajemy-na-uzbrojenie/c0gkxw5](https://businessinsider.com.pl/gospodarka/polska-prymusem-wsrod-krajow-nato-tyle-wydajemy-na-uzbrojenie/c0gkxw5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 06:11:48+00:00

W ubiegłym roku środki przeznaczone na nowe uzbrojenie były ponad dwa razy wyższe niż rok wcześniej. W 2023 r. Polska wyda na obronność ok. 4 proc. PKB, co stawia nas w czołówce NATO — pisze we wtorek "Dziennik Gazeta Prawna".

## Jak powstają piłki tenisowe? Hipnotyzujący proces
 - [https://businessinsider.com.pl/wideo/jak-powstaja-pilki-tenisowe-hipnotyzujacy-proces/smbdcpw](https://businessinsider.com.pl/wideo/jak-powstaja-pilki-tenisowe-hipnotyzujacy-proces/smbdcpw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 06:03:00+00:00

Z czego zrobione są piłki tenisowe? Skąd się biorą na nich charakterystyczne białe paski? Zobacz jak wygląda produkcja.

## Wraca temat unijnego zakazu dla aut spalinowych po 2035 r. Niemcy chcą go znacząco złagodzić
 - [https://businessinsider.com.pl/gospodarka/wraca-temat-unijnego-zakazu-dla-aut-spalinowych-niemcy-chca-go-znaczaco-zlagodzic/ee4ntd4](https://businessinsider.com.pl/gospodarka/wraca-temat-unijnego-zakazu-dla-aut-spalinowych-niemcy-chca-go-znaczaco-zlagodzic/ee4ntd4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 06:01:18+00:00

Niemcy proszą Brukselę, aby wprowadzić zmiany do przepisów o zakazie wprowadzania na rynek aut spalinowych po 2035 r. Inwestorzy na rynku finansowym są coraz bardziej przekonani, że stopy procentowe w strefie euro będą rosnąć aż do przyszłego roku. Polacy spłacają więcej starych kredytów, niż zaciągają nowych, rząd chce inwestować w elektrownie szczytowo-pompowe, a opozycja chce rozdawać darmowe kredyty. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Idą podwyżki cen wody. "Zaakceptowano 150 nowych taryf"
 - [https://businessinsider.com.pl/gospodarka/ida-podwyzki-cen-wody-zaakceptowano-150-nowych-taryf/gfdh4mb](https://businessinsider.com.pl/gospodarka/ida-podwyzki-cen-wody-zaakceptowano-150-nowych-taryf/gfdh4mb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:58:41+00:00

Co trzecia gmina w Polsce złożyła wniosek o zmianę taryf za wodę i ścieki z podwyżkami — zdradził wiceprezes Wód Polskich Paweł Rusiecki. Zaakceptowano 150 z nich, a wzrost cen ma nie przekroczyć 10 proc. rocznie. Regulator odrzucił też 376 wniosków

## Dlaczego Fanta powstała w nazistowskich Niemczech? To był najsłodszy napój na rynku
 - [https://businessinsider.com.pl/wideo/dlaczego-fanta-powstala-w-nazistowskich-niemczech-to-byl-najslodszy-napoj-na-rynku/n62ch8n](https://businessinsider.com.pl/wideo/dlaczego-fanta-powstala-w-nazistowskich-niemczech-to-byl-najslodszy-napoj-na-rynku/n62ch8n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:52:00+00:00

Pierwotna Fanta, któą znamy dziś ze sklepowych półek, mocno różniła się od dzisiejszego produktu. Inny był m.in. kolor. Co ciekawe, niemieckie gospodynie chętnie dodawały ją np. do zup.

## Myślisz, że spotkania w pracy to strata czasu? Masz rację
 - [https://businessinsider.com.pl/firmy/czy-spotkania-w-pracy-sa-potrzebne/95nzqqh](https://businessinsider.com.pl/firmy/czy-spotkania-w-pracy-sa-potrzebne/95nzqqh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:49:00+00:00

Jeśli kiedykolwiek pomyślałeś w pracy: "To spotkanie można było załatwić mailem", miałeś rację. Oszczędziłbyś nie tylko swój czas, ale i pieniądze pracodawcy.

## Mniej czasu na urlop ojcowski. Sprawdź, co i kiedy się zmieni
 - [https://businessinsider.com.pl/prawo/praca/mniej-czasu-na-urlop-ojcowski-sprawdz-co-i-kiedy-sie-zmieni/4tqmz94](https://businessinsider.com.pl/prawo/praca/mniej-czasu-na-urlop-ojcowski-sprawdz-co-i-kiedy-sie-zmieni/4tqmz94)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:46:18+00:00

Nie wszystkie planowane zmiany w kodeksie pracy są korzystne dla rodziców. Mężczyźni będą mieć mniej czasu na wykorzystanie dwutygodniowego urlopu ojcowskiego. W lepszej sytuacji będą ci, których dziecko urodzi się przed wejściem w życie nowych przepisów.

## Menedżerowie państwowych spółek wpłacają na PiS. Znamy nazwiska
 - [https://businessinsider.com.pl/wiadomosci/menedzerowie-panstwowych-spolek-wplacaja-na-pis-znamy-nazwiska/scmt7pv](https://businessinsider.com.pl/wiadomosci/menedzerowie-panstwowych-spolek-wplacaja-na-pis-znamy-nazwiska/scmt7pv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:46:14+00:00

Od początku roku PiS odnotował 11 wpłat od osób fizycznych. Wszystkie z nich to menedżerowie spółek Skarbu Państwa, którzy w tym roku byli wyjątkowo hojni. Żaden z przelewów nie opiewał na mniej niż 20 tys. zł.

## Zapomnij o nagłym spadku rat. Tak przebiegać będzie wdrożenie WIRON-u w istniejących umowach
 - [https://businessinsider.com.pl/finanse/zapomnij-o-naglym-spadku-rat-tak-wibor-zmieni-sie-w-wiron/q37gjde](https://businessinsider.com.pl/finanse/zapomnij-o-naglym-spadku-rat-tak-wibor-zmieni-sie-w-wiron/q37gjde)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:38:53+00:00

Koniec stawki WIBOR nadchodzi wielkimi krokami i trzeba będzie zastąpić ją nowym wskaźnikiem WIRON nie tylko w nowych hipotekach, ale także w tych już istniejących. To zjawisko dotknie blisko 3,3 mln osób spłacających złotowe kredyty mieszkaniowe o zmiennym oprocentowaniu. Czy muszą podpisywać aneksy? Co, jeśli mają klauzule awaryjne? Czy mogą liczyć na zmniejszenie oprocentowania? Oto czego dotychczas dowiedzieliśmy się na temat zamiany WIBOR-u na WIRON.

## Musk pozwany przez akcjonariuszy. Chodzi o bezpieczeństwo jego aut
 - [https://businessinsider.com.pl/biznes/musk-pozwany-przez-akcjonariuszy-chodzi-o-bezpieczenstwo-jego-aut/ny6tqfq](https://businessinsider.com.pl/biznes/musk-pozwany-przez-akcjonariuszy-chodzi-o-bezpieczenstwo-jego-aut/ny6tqfq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:28:47+00:00

Tesla i jej szef Elon Musk zostali w poniedziałek pozwani przez akcjonariuszy, którzy oskarżyli spółkę i Muska o przecenianie skuteczności i bezpieczeństwa technologii Autopilot i Full Self-Driving swoich pojazdów elektrycznych.

## Jest kompromis w sprawie nowego wiceministra od węgla. Nominacja możliwa na dniach
 - [https://businessinsider.com.pl/wiadomosci/jest-kompromis-w-sprawie-nowego-wiceministra-od-wegla-nominacja-mozliwa-na-dniach/nkzv31d](https://businessinsider.com.pl/wiadomosci/jest-kompromis-w-sprawie-nowego-wiceministra-od-wegla-nominacja-mozliwa-na-dniach/nkzv31d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:21:24+00:00

Po kilku miesiącach spekulacji powraca temat powołania posła PiS Marka Wesołego na stanowisko wiceministra aktywów państwowych. Według informacji Business Insidera premier Mateusz Morawiecki i szef MAP Jacek Sasin osiągnęli wreszcie kompromis w tej sprawie. Jak mówią nasze źródła, ostateczna decyzja może zapaść w tym tygodniu.

## Za 12 lat wszyscy kierowcy będą musieli się na tym znać. Powstała polska ładowarka do elektryków
 - [https://businessinsider.com.pl/technologie/nowe-technologie/za-12-lat-wszyscy-kierowcy-beda-musieli-sie-na-tym-znac-powstala-polska-ladowarka-do/msxbdcf](https://businessinsider.com.pl/technologie/nowe-technologie/za-12-lat-wszyscy-kierowcy-beda-musieli-sie-na-tym-znac-powstala-polska-ladowarka-do/msxbdcf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:11:00+00:00

Jeszcze tylko do 2035 r. w Unii Europejskiej będzie można sprzedawać nowe samochody spalinowe. Potem jedyną opcją staną się elektryki. Rynek przestawia się już stopniowo na motoryzację w innym wydaniu. A Polska, choć robi to bardzo powoli, to zyskuje m.in. na lokalizacji fabryk baterii. W podziale profitów z nowego rynku chcą też uczestniczyć krajowi przedsiębiorcy. Jeden z nich wprowadza właśnie do sprzedaży ładowarkę do aut własnego projektu. Już zarabia na bateriach do rowerów.

## Złoty okres dla emerytów. Rekordzista dostanie 4 tys. zł podwyżki
 - [https://businessinsider.com.pl/poradnik-finansowy/zloty-okres-dla-emerytow-rekordzista-dostanie-4-tys-zl-podwyzki/nf2642w](https://businessinsider.com.pl/poradnik-finansowy/zloty-okres-dla-emerytow-rekordzista-dostanie-4-tys-zl-podwyzki/nf2642w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-28 05:00:00+00:00

Miliony emerytów czekają na ten moment. W marcu ponad 6 mln Polaków dostanie takie podwyżki, jakich jeszcze nigdy nie widziało. Z danych ZUS wynika, że ponad 100 tys. seniorów może liczyć na wzrost świadczenia o nawet 1 tys. zł brutto, a emerytura rekordzisty skoczy o ponad 4 tys. zł. A na tym nie koniec. Już za chwilę rusza bowiem wypłata "trzynastek".

