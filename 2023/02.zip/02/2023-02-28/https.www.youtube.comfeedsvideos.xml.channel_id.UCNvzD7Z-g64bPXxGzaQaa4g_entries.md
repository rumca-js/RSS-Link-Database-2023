# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Weird Gaming Stories of February 2023
 - [https://www.youtube.com/watch?v=ktUluJeYs2s](https://www.youtube.com/watch?v=ktUluJeYs2s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-02-28 21:06:48+00:00

February 2023 was filled with tons of weird, strange, and hilarious gaming news stories. Here are some interesting examples. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


0:00 intro
0:19 Number 10
1:10 Number 9
2:21 Number 8
3:19 Number 7
4:00 Number 6
5:28 Number 5
7:23 Number 4
8:28 Number 3
9:13 Number 2
10:30 Number 1

SOURCES:

https://www.pcworld.com/article/1499957/amd-is-undershipping-chips-to-keep-cpu-gpu-prices-elevated.html

https://www.youtube.com/watch?v=gSsfs_XBu4s&amp;ab_channel=3Dystopia


https://www.esportsheaven.com/features/riot-games-hacker-is-now-selling-league-of-legends-source-code-for-700000-on-black-market-includes-anti-cheat-software/

https://www.eurogamer.net/american-judge-dismisses-switch-joy-con-drift-lawsuit

https://www.pcgamer.com/rainbow-six-siege-is-going-to-start-doing-evil-things-to-mouse-and-keyboard-players-on-console/

https://kotaku.com/wow-max-level-70-grind-exiles-reach-reddit-cheatcho-1850118199

https://www.pcgamer.com/players-are-replacing-their-hogwarts-wands-with-with-guns-luigi-wiimotes-and-asparagus/

https://kotaku.com/witcher-3-wild-hunt-hammer-glitch-cd-projekt-red-fix-1850101307

https://kotaku.com/nintendo-smash-bros-wrestling-wwe-wcw-pikachu-mario-1850115376

https://www.pcgamer.com/the-day-before-devs-say-a-calendar-app-stole-their-trademark-youtube-is-delisting-their-videos-and-no-doubt-the-dogs-eyeing-up-their-homework/

