# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## American Airlines guarantees family seating in new customer service plan
 - [https://www.cnn.com/travel/article/american-airlines-family-seating-dot-dashboard/index.html](https://www.cnn.com/travel/article/american-airlines-family-seating-dot-dashboard/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 22:24:51+00:00

American Airlines will guarantee that children will be seated next to an accompanying adult, according to the airline's updated customer service plan. It's the latest airline response to calls for better family seating policies.

## Man found carrying mummy in a food delivery bag
 - [https://www.cnn.com/2023/02/28/americas/peru-mummy-puno-delivery-man-intl-latam/index.html](https://www.cnn.com/2023/02/28/americas/peru-mummy-puno-delivery-man-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 22:09:51+00:00

A pre-Hispanic mummy, estimated to be between 600 to 800 years old, was discovered in a food delivery cooler bag by Peruvian police over the weekend.

## By getting a good night's sleep, you can collect Pokémon in this new game
 - [https://www.cnn.com/videos/business/2023/02/28/pokemon-sleep-tracking-game-cprog-orig-ht.cnn-business](https://www.cnn.com/videos/business/2023/02/28/pokemon-sleep-tracking-game-cprog-orig-ht.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 21:37:58+00:00

Pokémon Sleep is a sleep tracking app that allows users to interact with characters by getting a good night's rest.

## Fox faces an 'existential threat' from its multibillion-dollar defamation cases
 - [https://www.cnn.com/2023/02/28/media/fox-news-dominion-damages/index.html](https://www.cnn.com/2023/02/28/media/fox-news-dominion-damages/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 20:57:02+00:00

Fox Chairman Rupert Murdoch said under oath that he made a business decision when allowing a conspiracy theorist to promote election lies on Fox News.

## 'He's having some problems back home': Retired lt. general on Putin admitting to Russian losses
 - [https://www.cnn.com/videos/world/2023/02/28/mark-hertling-ukraine-russia-bakhmut-putin-speech-ip-vpx.cnn](https://www.cnn.com/videos/world/2023/02/28/mark-hertling-ukraine-russia-bakhmut-putin-speech-ip-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 20:46:11+00:00

Retired Lt. Gen. Mark Hertling joins CNN's John King to discuss military strategy in Bakhmut, Ukraine, and his thoughts on Putin publicly acknowledging Russian losses on the battlefield.

## America's fastest-growing metro area is running out of water
 - [https://www.cnn.com/videos/us/2023/02/28/utah-water-lake-powell-pipeline-bill-weir-dnt-lead-vpx.cnn](https://www.cnn.com/videos/us/2023/02/28/utah-water-lake-powell-pipeline-bill-weir-dnt-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 20:08:44+00:00

Lake Powell hit its lowest level in decades last year, but Washington County in Utah needs water to keep growing. And the reservoir is their target. CNN's chief climate correspondent Bill Weir reports.

## FAA is investigating a close call between 2 aircraft at Boston Logan
 - [https://www.cnn.com/travel/article/boston-logan-airport-runway-close-call/index.html](https://www.cnn.com/travel/article/boston-logan-airport-runway-close-call/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 19:40:01+00:00

Air traffic controllers stopped a departing private jet from running into a JetBlue flight as it was coming in to land Monday night in Boston, according to the Federal Aviation Administration.

## McCarthy grants access to Capitol security footage to January 6 defendants
 - [https://www.cnn.com/2023/02/28/politics/capitol-security-footage-january-6-mccarthy/index.html](https://www.cnn.com/2023/02/28/politics/capitol-security-footage-january-6-mccarthy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 19:36:10+00:00

House Speaker Kevin McCarthy's office said on Tuesday that lawyers for defendants facing charges in the January 6, 2021, insurrection will be granted access to US Capitol security footage as the top House Republican has faced scrutiny for allowing Fox News host Tucker Carlson to view the video before widely releasing it.

## Shakira reveals the impact of her collaboration with Bizarrap: 'It was necessary for my own healing'
 - [https://www.cnn.com/2023/02/28/entertainment/shakira-bizarrap/index.html](https://www.cnn.com/2023/02/28/entertainment/shakira-bizarrap/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 19:02:47+00:00

Shakira feels emotionally empowered after her song with Argentine producer Bizarrap.

## 'M*A*S*H' said goodbye 40 years ago, with a finale for the ages
 - [https://www.cnn.com/2023/02/28/entertainment/mash-finale/index.html](https://www.cnn.com/2023/02/28/entertainment/mash-finale/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 19:01:41+00:00

"M*A*S*H" ran for 11 seasons, even though the Korean War, during which the CBS series was set, lasted three years. When the show finally signed off 40 years ago -- with a special 2.5-hour episode titled "Goodbye, Farewell and Amen" -- it set a ratings record that will never be equaled, and indeed, has become virtually impossible in the fragmented media market that exists today.

## Takeaways from the Supreme Court oral arguments in cases challenging Biden's student debt relief plan
 - [https://www.cnn.com/2023/02/28/politics/student-loan-forgiveness-supreme-court-arguments-takeaways/index.html](https://www.cnn.com/2023/02/28/politics/student-loan-forgiveness-supreme-court-arguments-takeaways/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 18:43:58+00:00

The Supreme Court on Tuesday heard oral arguments in two challenges to President Joe Biden's student debt relief plan, with several conservative justices appearing skeptical of the government's authority to discharge millions of dollars in federally held loans.

## What travelers to Turkey need to know
 - [https://www.cnn.com/travel/article/turkey-travel-need-to-know/index.html](https://www.cnn.com/travel/article/turkey-travel-need-to-know/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 17:40:34+00:00

It's been nearly a month since a 7.8-magnitude earthquake struck Turkey and Syria, claiming the lives of thousands of people and injuring many more.

## Canada Soccer president quits, acknowledges 'change' required
 - [https://www.cnn.com/2023/02/28/football/nick-bontis-canada-soccer-president-resign-spt-intl/index.html](https://www.cnn.com/2023/02/28/football/nick-bontis-canada-soccer-president-resign-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 17:18:17+00:00

Canada Soccer president Nick Bontis announced his resignation on Monday, acknowledging "change" is required as its national team programs' collective bargaining negotiations continue.

## Kissing device allows users to lock lips through their cell phones
 - [https://www.cnn.com/videos/media/2023/02/28/remote-kissing-device-moos-cprog-orig-bdk.cnn](https://www.cnn.com/videos/media/2023/02/28/remote-kissing-device-moos-cprog-orig-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 17:07:09+00:00

A creepy remote kissing device sends your smooches long-distance. CNN's Jeanne Moos reports these lips have tongues wagging.

## Tesla, Musk sued by shareholders over self-driving safety claims
 - [https://www.cnn.com/2023/02/28/tech/tesla-musk-shareholder-lawsuit/index.html](https://www.cnn.com/2023/02/28/tech/tesla-musk-shareholder-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 17:05:29+00:00

Tesla and its Chief Executive Elon Musk were sued on Monday by shareholders who accused them of overstating the effectiveness and safety of their electric vehicles' Autopilot and Full Self-Driving technologies.

## Mark Zuckerberg looks to 'turbocharge' Meta's AI tools after viral success of ChatGPT
 - [https://www.cnn.com/2023/02/28/tech/mark-zuckerberg-meta-ai-team/index.html](https://www.cnn.com/2023/02/28/tech/mark-zuckerberg-meta-ai-team/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 16:57:11+00:00

Mark Zuckerberg said Meta is creating a new "top-level product group" to "turbocharge" the company's work on AI tools, as it attempts to keep pace with a renewed AI arms race among Big Tech companies.

## Watch: Multiple models fall into the crowd at fashion show
 - [https://www.cnn.com/videos/fashion/2023/02/28/sunnei-fashion-show-models-crowd-surf-contd-lon-orig-na.cnn](https://www.cnn.com/videos/fashion/2023/02/28/sunnei-fashion-show-models-crowd-surf-contd-lon-orig-na.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 16:52:14+00:00

Members of the Sunnei fashion brand took to the runway during Milan Fashion Week to model the label's latest collection, ending their catwalk with a surprise.

## Rape investigation opened into PSG star Hakimi
 - [https://www.cnn.com/2023/02/28/football/achraf-hakimi-rape-investigation-spt-intl/index.html](https://www.cnn.com/2023/02/28/football/achraf-hakimi-rape-investigation-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 16:43:52+00:00

French judicial authorities have opened an investigation for rape into Moroccan soccer player Achraf Hakimi, a source close to the investigation confirmed to CNN on Tuesday.

## Chris Rock will finally talk about Will Smith's Oscars slap in live Netflix special
 - [https://www.cnn.com/2023/02/28/entertainment/chris-rock-will-smith-netflix-special/index.html](https://www.cnn.com/2023/02/28/entertainment/chris-rock-will-smith-netflix-special/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 16:26:09+00:00

Chris Rock will hit back the way he does best -- on stage.

## Tesla, tech and travel stocks have ginormous gains this year
 - [https://www.cnn.com/2023/02/28/investing/tesla-stock-winners/index.html](https://www.cnn.com/2023/02/28/investing/tesla-stock-winners/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 16:11:31+00:00

Last year's stock market zeroes are so far turning out to be this year's Wall Street heroes.

## Turkey's Red Crescent criticized for selling tents to charity instead of giving them to quake victims
 - [https://www.cnn.com/2023/02/28/europe/turkey-earthquake-red-crescent-criticism-intl/index.html](https://www.cnn.com/2023/02/28/europe/turkey-earthquake-red-crescent-criticism-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 16:08:44+00:00

Turkey's Red Crescent organization has been criticized by lawmakers and citizens after revelations that it sold tents to a charity instead of donating them to people in urgent need after the massive earthquake that claimed more than 44,000 lives earlier this month.

## Why it's impossible to find an open squat rack at the gym
 - [https://www.cnn.com/2023/02/28/business/gym-exercise-free-weights-cardio/index.html](https://www.cnn.com/2023/02/28/business/gym-exercise-free-weights-cardio/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 16:08:20+00:00

Planning to hit the gym during rush hour? You'll have much better luck finding an open elliptical machine than a bench press, squat rack or 30-pound dumbbells.

## House panel to vote on bill empowering Biden to ban TikTok
 - [https://www.cnn.com/2023/02/28/tech/house-tiktok-vote/index.html](https://www.cnn.com/2023/02/28/tech/house-tiktok-vote/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 15:34:09+00:00

A powerful House committee is set to vote Tuesday on a bill that would make it easier to ban TikTok from the United States and crack down on other China-related economic activity, amid vocal objections from civil liberties advocates who argue the proposal is unconstitutionally broad and threatens a wide range of online speech.

## US home prices fell in December for the sixth-straight month
 - [https://www.cnn.com/2023/02/28/homes/case-shiller-december-2022/index.html](https://www.cnn.com/2023/02/28/homes/case-shiller-december-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 15:28:15+00:00

US home prices fell for the sixth month in a row in December, as rising mortgage rates pushed prospective buyers out of the housing market, according to the latest S&amp;P CoreLogic Case-Shiller US National Home Price Index, released Tuesday.

## UK grocery price inflation hits record high as more stores impose rationing
 - [https://www.cnn.com/2023/02/28/business/uk-food-price-inflation-shortages/index.html](https://www.cnn.com/2023/02/28/business/uk-food-price-inflation-shortages/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 15:22:04+00:00

A measure of UK grocery price inflation soared to a record high this month — that's more bad news for consumers already facing a shortage of fruit and vegetables that has led to rationing at major supermarkets.

## 'Ted Lasso' Season 3 trailer previews more chaos and competition
 - [https://www.cnn.com/2023/02/28/entertainment/ted-lasso-season-3/index.html](https://www.cnn.com/2023/02/28/entertainment/ted-lasso-season-3/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 15:21:27+00:00

The first full trailer for the new season of "Ted Lasso" is here.

## Consumer confidence slumped in February amid recession concerns
 - [https://www.cnn.com/2023/02/28/economy/consumer-confidence-february/index.html](https://www.cnn.com/2023/02/28/economy/consumer-confidence-february/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 15:18:55+00:00

American consumers felt much worse about the US economy in February amid rising interest rates and concerns about a potential recession, according to the latest survey data released Tuesday by the Conference Board.

## French Football Federation president Noël Le Graët resigns
 - [https://www.cnn.com/2023/02/28/football/french-football-federation-resignations-le-graet-spt-intl/index.html](https://www.cnn.com/2023/02/28/football/french-football-federation-resignations-le-graet-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 15:11:38+00:00

Embattled French Football Federation (FFF) president Noël Le Graët has resigned, the federation announced in a statement on Tuesday.

## Opposition parties in Nigeria call for fresh elections as ruling party takes the lead
 - [https://www.cnn.com/2023/02/28/africa/nigeria-election-tinubu-leads-intl/index.html](https://www.cnn.com/2023/02/28/africa/nigeria-election-tinubu-leads-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 15:05:21+00:00

Nigeria's main opposition parties are calling for fresh elections, describing results currently being announced by electoral body as "heavily doctored and manipulated," in a joint press conference in the capital, Abuja.

## Turkish soccer fans who chanted anti-government slogans banned from stadium
 - [https://www.cnn.com/2023/02/28/football/turkey-football-fans-banned-government-spt-intl/index.html](https://www.cnn.com/2023/02/28/football/turkey-football-fans-banned-government-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 14:55:10+00:00

Supporters of Turkish soccer team Fenerbahçe, who chanted anti-government slogans during a previous match, have been banned from attending this weekend's game against Kayserispor, according to a team statement.

## Indian temple goes 'cruelty- free' with life-sized robotic elephant
 - [https://www.cnn.com/travel/article/india-temple-elephant-robot-intl-scli/index.html](https://www.cnn.com/travel/article/india-temple-elephant-robot-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 14:21:58+00:00

A life-sized mechanical elephant will take part in ceremonies at a temple in the southern Indian state of Kerala, amid concerns about the welfare of animals used for rituals.

## Courteney Cox gets star on Hollywood Walk of Fame and reacts to that Prince Harry book claim
 - [https://www.cnn.com/2023/02/28/entertainment/courteney-cox-walk-fame/index.html](https://www.cnn.com/2023/02/28/entertainment/courteney-cox-walk-fame/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 13:56:47+00:00

Courteney Cox got by with a little help from her "Friends," but she's not saying the same for getting high.

## Apple supplier unlikely to resume full India operations for two months after massive fire
 - [https://www.cnn.com/2023/02/28/tech/apple-supplier-foxlink-fire-issues/index.html](https://www.cnn.com/2023/02/28/tech/apple-supplier-foxlink-fire-issues/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 13:43:51+00:00

Most of the fire safety equipment at Apple supplier Foxlink's facility in southern India was not functional, a government official told Reuters on Tuesday, a day after a massive blaze forced production to be halted.

## Longing for the 'golden age' of air travel? Be careful what you wish for
 - [https://www.cnn.com/travel/article/golden-age-of-air-travel-downsides/index.html](https://www.cnn.com/travel/article/golden-age-of-air-travel-downsides/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 13:25:22+00:00

Long lines at security checkpoints, tiny plastic cups of soda, small bags of pretzels, planes filled to capacity, fees attached to every amenity -- all reflect the realities of 21st century commercial air travel. It's no wonder that many travelers have become nostalgic for the so-called "golden age" of air travel in the United States.

## DeSantis' new book could serve as a blueprint for possible 2024 run
 - [https://www.cnn.com/videos/politics/2023/02/28/ron-desantis-new-book-possible-2024-presidential-run-cnntm-zeleny-vpx.cnn](https://www.cnn.com/videos/politics/2023/02/28/ron-desantis-new-book-possible-2024-presidential-run-cnntm-zeleny-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 13:18:00+00:00

CNN's chief national affairs correspondent Jeff Zeleny highlights excerpts from Florida Gov. Ron DeSantis' new book, "The Courage to Be Free," which could serve as a blueprint for a possible 2024 presidential campaign.

## High levels of chemicals could pose long-term risks at Ohio train derailment site, researchers say
 - [https://www.cnn.com/2023/02/28/health/train-chemical-analysis-east-palestine/index.html](https://www.cnn.com/2023/02/28/health/train-chemical-analysis-east-palestine/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 13:10:52+00:00

An analysis of data from the US Environmental Protection Agency's measurements of pollutants released from the Norfolk Southern train derailment in East Palestine, Ohio, suggests that nine of the dozens of chemicals that the EPA has been monitoring are higher than would normally be found in the area, according to a group of scientists from Texas A&amp;M and Carnegie Mellon University.

## Bad sign for stocks: Bond yields are white hot
 - [https://www.cnn.com/2023/02/28/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2023/02/28/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 12:56:17+00:00

2022 was the worst year on record for bonds. Despite a promising start, 2023 is starting to look rough, too.

## New College of Florida students to hold rally as conservative leaders move forward with overhaul of school
 - [https://www.cnn.com/2023/02/28/us/new-college-florida-board-meeting-reaj/index.html](https://www.cnn.com/2023/02/28/us/new-college-florida-board-meeting-reaj/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 12:43:56+00:00

Students and faculty at the New College of Florida are planning to demonstrate during a board of trustees meeting Tuesday after Gov. Ron DeSantis launched a conservative takeover of the small liberal arts college.

## Police arrest aristocrat and partner, but search for missing baby continues
 - [https://www.cnn.com/2023/02/28/uk/aristocrat-partner-arrest-missing-baby-gbr-intl-scli/index.html](https://www.cnn.com/2023/02/28/uk/aristocrat-partner-arrest-missing-baby-gbr-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 12:40:32+00:00

UK police have arrested an aristocrat and her partner after the pair went missing with their newborn baby in early January, but the search for the infant continues.

## Russia's war in Ukraine
 - [https://www.cnn.com/europe/live-news/russia-ukraine-war-news-02-28-23/index.html](https://www.cnn.com/europe/live-news/russia-ukraine-war-news-02-28-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 12:34:54+00:00



## Wizz Air to suspend flights to Moldova due to airspace 'risk'
 - [https://www.cnn.com/travel/article/wizz-air-moldova-russia-ukraine/index.html](https://www.cnn.com/travel/article/wizz-air-moldova-russia-ukraine/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 12:30:01+00:00

European low-cost carrier Wizz Air is is to suspend flights to Moldova because of concerns over airspace safety.

## Brexit slammed the UK economy. The new Northern Ireland deal gives it hope
 - [https://www.cnn.com/2023/02/28/economy/northern-ireland-new-brexit-deal/index.html](https://www.cnn.com/2023/02/28/economy/northern-ireland-new-brexit-deal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 12:04:21+00:00

The breakthrough deal on Northern Ireland's trading arrangements heralds a reset in the often thorny relationship between the United Kingdom and the European Union — and could be the first step to repairing some of the damage Brexit has done to the UK economy.

## The fastest growing metro in the US is looking to a shrinking reservoir to keep the boom going
 - [https://www.cnn.com/2023/02/28/us/st-george-utah-water-lake-powell-pipeline-climate/index.html](https://www.cnn.com/2023/02/28/us/st-george-utah-water-lake-powell-pipeline-climate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 11:55:56+00:00

In a bright-red county in a state allergic to regulations, there is a ban on growing grass outside new businesses. Only 8% of a home's landscaping can have a grass lawn in this booming corner of Utah, about a hundred miles northeast of Las Vegas.

## Volkswagen sees no sign of forced labor at its plant in Xinjiang
 - [https://www.cnn.com/2023/02/28/business/volkswagen-china-xinjiang-rights/index.html](https://www.cnn.com/2023/02/28/business/volkswagen-china-xinjiang-rights/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 11:24:17+00:00

Volkswagen faced a barrage of criticism from campaigners Tuesday after the head of its Chinese business said he saw no sign of forced labor during a visit to the carmaker's plant in Xinjiang.

## Nigerian voter describes being attacked at polling unit
 - [https://www.cnn.com/videos/world/2023/02/28/nigeria-election-voter-jennifer-efidi-bina-sot-busari-contd-ovn-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2023/02/28/nigeria-election-voter-jennifer-efidi-bina-sot-busari-contd-ovn-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 11:03:36+00:00

Amid one of the more fiercely contested presidential elections in Nigeria in recent years, many voters in Lagos complained of intimidation and attempts to suppress their votes. CNN's Stephanie Busari speaks to a voter who says she was attacked at a polling station.

## US citizen killed in West Bank as Israeli-Palestinian tensions ratchet up
 - [https://www.cnn.com/2023/02/28/middleeast/israeli-american-killed-west-bank-intl/index.html](https://www.cnn.com/2023/02/28/middleeast/israeli-american-killed-west-bank-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 11:01:38+00:00

An Israeli-American citizen was killed in the occupied West Bank as tensions in the region continued to ratchet up after a weekend of violence.

## Lionel Messi and Alexia Putellas honored as best men's and women's football players
 - [https://www.cnn.com/2023/02/28/football/fifa-best-awards-lionel-messi-alexia-putellas-spt-intl/index.html](https://www.cnn.com/2023/02/28/football/fifa-best-awards-lionel-messi-alexia-putellas-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 10:46:14+00:00

Lionel Messi and Alexia Putellas were crowned the best players in men's and women's football at FIFA's annual awards ceremony in Paris on Monday.

## Milan Fashion Week Highlights: Crowd-surfing models, a condom mountain and 80s club culture
 - [https://www.cnn.com/style/article/milan-fashion-week-aw23-highlights/index.html](https://www.cnn.com/style/article/milan-fashion-week-aw23-highlights/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 10:30:21+00:00

Oscillating between flashy and understated, escapist and down to earth, Milan Fashion Week's Fall-Winter 2023 collections conjured glamor in very different ways, with several brands putting on theatrical displays that provided ample entertainment.

## What to watch for as the Supreme Court hears oral arguments on Biden's student loan debt relief plan
 - [https://www.cnn.com/2023/02/28/politics/supreme-court-student-loan-oral-arguments-what-to-watch/index.html](https://www.cnn.com/2023/02/28/politics/supreme-court-student-loan-oral-arguments-what-to-watch/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 10:03:23+00:00

The Supreme Court on Tuesday will take up two challenges to President Joe Biden's student loan forgiveness program -- an initiative aimed at providing targeted debt relief to millions of student-loan borrowers -- that has so far been stalled by legal challenges.

## Can't get to The Masters? Have a 'taste' of the tournament delivered instead
 - [https://www.cnn.com/2023/02/28/golf/the-masters-food-concessions-kit-spc-spt-intl/index.html](https://www.cnn.com/2023/02/28/golf/the-masters-food-concessions-kit-spc-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 09:44:48+00:00

Getting tickets to golf's most prestigious event is, quite literally, a lottery.

## Family and friends of slain Hong Kong model pay final respects as investigation continues
 - [https://www.cnn.com/2023/02/28/asia/hong-kong-abby-choi-funeral-rites-intl-hnk/index.html](https://www.cnn.com/2023/02/28/asia/hong-kong-abby-choi-funeral-rites-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 09:15:27+00:00

Friends and relatives of Hong Kong model Abby Choi on Tuesday paid their final respects at the scene where police say they found what are believed to be the socialite's dismembered body parts, public broadcaster RTHK reported.

## Gymnastics teams look nothing like they used to. And this is the biggest change
 - [https://www.cnn.com/2023/02/27/opinions/black-gymnastics-us-black-history-month-rogers-ctpr/index.html](https://www.cnn.com/2023/02/27/opinions/black-gymnastics-us-black-history-month-rogers-ctpr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 08:51:07+00:00

I'm one of just five Black women in history to win the NCAA individual all-around title in gymnastics. It was a tremendous accomplishment which, when I won it two decades ago, left me elated.

## 16 year-old becomes youngest snowboarding world champion after landing stunning trick
 - [https://www.cnn.com/2023/02/28/sport/mia-brookes-snowboarding-world-champion-spt-intl/index.html](https://www.cnn.com/2023/02/28/sport/mia-brookes-snowboarding-world-champion-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 08:48:09+00:00

At just 16 years old, Mia Brookes became the youngest snowboarding world champion after winning gold in the women's slopestyle at the Snowboard, Freestyle and Freeski World Championships in Bakuriani, Georgia on Monday.

## Ukraine's military says Wagner mercenaries are throwing their 'most trained' assault units into the battle for the eastern city
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-02-28-23/index.html](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-02-28-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 08:22:23.478055+00:00



## Top Republicans question McCarthy over release of Jan. 6 footage
 - [https://www.cnn.com/2023/02/27/politics/kevin-mccarthy-january-6-footage-reaction/index.html](https://www.cnn.com/2023/02/27/politics/kevin-mccarthy-january-6-footage-reaction/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 08:21:46+00:00

Speaker Kevin McCarthy faced questions from his leadership team Monday night over his plans to publicly release security footage from January 6, 2021, multiple sources told CNN -- a process that he said could take some time to disseminate widely even as Fox News host Tucker Carlson has had an early glimpse.

## Thai drug dealer disguised himself as a 'Korean man' using plastic surgery, police say
 - [https://www.cnn.com/2023/02/28/asia/thai-drug-dealer-korean-plastic-surgery-intl-hnk/index.html](https://www.cnn.com/2023/02/28/asia/thai-drug-dealer-korean-plastic-surgery-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 08:08:17+00:00

Last Thursday, Thai investigative police raided a condo in the suburbs of Bangkok -- the hideout of an alleged drug smuggler who had been on the run for months.

## China is rolling out the red carpet for a key Putin ally as US warns against aiding Russia's war
 - [https://www.cnn.com/collections/intl-2801-russia-ukraine/](https://www.cnn.com/collections/intl-2801-russia-ukraine/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 07:36:24+00:00



## China rolls out carpet for key Putin ally as US warns against aiding Russia's war
 - [https://www.cnn.com/2023/02/28/china/belarus-lukashenko-visits-beijing-china-xi-jinping-intl-hnk/index.html](https://www.cnn.com/2023/02/28/china/belarus-lukashenko-visits-beijing-china-xi-jinping-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 07:28:14+00:00

China is preparing to welcome a key autocratic ally of Russian President Vladimir Putin for a state visit, amid warnings from United States officials that Beijing may be considering aiding Moscow in its ongoing assault on Ukraine.

## Zelensky says situation in Bakhmut is getting more challenging for Ukraine
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-02-28-23/index.html](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-02-28-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 06:22:11.683158+00:00



## Fresh disagreements over the exact origins of Covid-19 and whether China will arm Russia in its war in Ukraine are heightening an increasingly adversarial relationship
 - [https://www.cnn.com/2023/02/28/politics/us-china-relations-ukraine-covid/index.html](https://www.cnn.com/2023/02/28/politics/us-china-relations-ukraine-covid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 06:08:44+00:00

It gets worse every day.

## Watch the archived news report of the 'cocaine bear'
 - [https://www.cnn.com/videos/media/2023/02/28/cocaine-bear-1985-true-story-wxia-ctn-cprog-hnk-vpx.cnn](https://www.cnn.com/videos/media/2023/02/28/cocaine-bear-1985-true-story-wxia-ctn-cprog-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 06:05:29+00:00

CNN Tonight digs out the original 1985 WXIA report about a bear that overdosed on cocaine - the real life inspiration of the recently released 'Cocaine Bear' movie.

## US Navy reconnaissance flight over Taiwan Strait draws angry response from China
 - [https://www.cnn.com/2023/02/28/asia/us-navy-plane-taiwan-srait-transit-intl-hnk-ml/index.html](https://www.cnn.com/2023/02/28/asia/us-navy-plane-taiwan-srait-transit-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 05:38:30+00:00

A US Navy reconnaissance jet flew over the Taiwan Strait on Monday, in a maneuver intended to assert the right to operate in international airspace despite strong objections from the Chinese military.

## Agencies have 30 days to ban TikTok on government devices, White House says
 - [https://www.cnn.com/2023/02/28/politics/tiktok-federal-device-ban-guidance/index.html](https://www.cnn.com/2023/02/28/politics/tiktok-federal-device-ban-guidance/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 05:31:34+00:00

The White House has directed federal agencies that they have 30 days to remove TikTok from all government-issued devices.

## World's best beaches for 2023, according to Tripadvisor
 - [https://www.cnn.com/travel/article/best-beaches-2023-tripadvisor/index.html](https://www.cnn.com/travel/article/best-beaches-2023-tripadvisor/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 05:09:49+00:00

Stretching out on the world's best beach won't come easy. Baía do Sancho is accessible only by boat or via ladders descending down steep cliffs to the golden sand below.

## Sony World Photography Awards 2023: The year's best images unveiled
 - [https://www.cnn.com/style/article/sony-world-photography-awards-professional-2023/index.html](https://www.cnn.com/style/article/sony-world-photography-awards-professional-2023/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 04:16:35+00:00

An aerial view of a volcano, a shot from inside a damaged building in Ukraine and a portrait of a dog are among the best images taken globally in the past year, according to judges of the prestigious Sony World Photography Awards.

## South Korean diplomats dance into Indian hearts in 'Naatu Naatu' viral video
 - [https://www.cnn.com/2023/02/27/india/south-korea-embassy-india-dance-naatu-naatu-intl-hnk-scli/index.html](https://www.cnn.com/2023/02/27/india/south-korea-embassy-india-dance-naatu-naatu-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 04:15:10+00:00

Dancing South Korean diplomats have won the hearts of millions of Indians with their viral video performance of Oscar-nominated song "Naatu Naatu," reinforcing Seoul's soft power diplomacy and even earning a nod of approval from India's leader.

## Sustainable ships: The world's most eco-conscious cruises
 - [https://www.cnn.com/travel/article/eco-conscious-sustainable-cruises-cmd/index.html](https://www.cnn.com/travel/article/eco-conscious-sustainable-cruises-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 03:59:06+00:00

For travelers who love to cruise but also consider themselves to be environmentally minded, the concept of "green" cruising can seem counterintuitive.

## Murdaugh's brother details what he saw cleaning up the murder scene
 - [https://www.cnn.com/videos/us/2023/02/28/alex-murdaugh-murder-trial-brother-crime-scene-gallagher-dnt-ebof-vpx.cnn](https://www.cnn.com/videos/us/2023/02/28/alex-murdaugh-murder-trial-brother-crime-scene-gallagher-dnt-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 03:05:55+00:00

Alex Murdaugh's defense in his double murder trial rested its case after calling up 14 witnesses over about two weeks of testimony, crime scene experts and the defendant's brother John Marvin Murdaugh. CNN's Dianne Gallagher reports.

## Actor Tom Sizemore's family deciding end of life matters, rep says
 - [https://www.cnn.com/2023/02/27/entertainment/tom-sizemore-end-of-life-decision/index.html](https://www.cnn.com/2023/02/27/entertainment/tom-sizemore-end-of-life-decision/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 02:56:11+00:00

The family of actor Tom Sizemore is currently "deciding end of life matters" following an update from doctors, according to a statement CNN received Monday evening from Sizemore's manager Charles Lago.

## Hong Kong scraps mask mandate after nearly three years
 - [https://www.cnn.com/2023/02/27/asia/hong-kong-mask-mandate-lifted-intl-hnk/index.html](https://www.cnn.com/2023/02/27/asia/hong-kong-mask-mandate-lifted-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 02:32:49+00:00

Hong Kong, one of the last major international cities requiring Covid face masks, has announced it will end its controversial mandate more than three years into the pandemic.

## Video shows Russian soldiers bolting for cover after their tank was struck
 - [https://www.cnn.com/videos/world/2023/02/28/russian-soldiers-running-cover-attack-ebof-vpx.cnn](https://www.cnn.com/videos/world/2023/02/28/russian-soldiers-running-cover-attack-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 02:13:13+00:00

CNN's Erin Burnett details the desperation and brutal reality of Russian soldiers as war rages on in Ukraine.

## Hear why legal analyst thinks Fox News is facing 'very serious' legal exposure
 - [https://www.cnn.com/videos/media/2023/02/27/rupert-murdoch-deposition-fox-news-dominion-lawsuit-darcy-norm-eisen-sot-tsr-vpx.cnn](https://www.cnn.com/videos/media/2023/02/27/rupert-murdoch-deposition-fox-news-dominion-lawsuit-darcy-norm-eisen-sot-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 01:56:46+00:00

The chairman of Fox corporation Rupert Murdoch admitted in a deposition taken by Dominion Voting Systems that some Fox News hosts endorsed false claims that the 2020 election was stolen. CNN senior media reporter Oliver Darcy and legal analyst Norm Eisen join Wolf Blitzer to discuss.

## China infuriated by lab leak theory, points finger at US lab
 - [https://www.cnn.com/videos/world/2023/02/28/wuhan-covid-lab-leak-theory-culver-pkg-china-ebof-intl-vpx.cnn](https://www.cnn.com/videos/world/2023/02/28/wuhan-covid-lab-leak-theory-culver-pkg-china-ebof-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 01:49:03+00:00

A classified intelligence report from the Department of Energy assesses with low confidence that the Covid-19 pandemic likely came from a leak in a Chinese laboratory. The Chinese are pushing back. CNN's David Culver visits the labs.

## Why tensions are at a recent high in Israel
 - [https://www.cnn.com/videos/world/2023/02/27/israel-palestine-tensions-netanyahu-pkg-gold-lead-vpx.cnn](https://www.cnn.com/videos/world/2023/02/27/israel-palestine-tensions-netanyahu-pkg-gold-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 01:36:16+00:00

CNN's Hadas Gold breaks down the multi-faceted battles currently facing Israeli Prime Minister Benjamin Netanyahu, including protests against his planned changes to the judicial system and high tensions with the Palestinians.

## Hear why some Russian troops are refusing to fight and say they're in a 'desperate position'
 - [https://www.cnn.com/videos/world/2023/02/27/pleitgen-putin-soliders-ukraine-war-dnt-lead-vpx.cnn](https://www.cnn.com/videos/world/2023/02/27/pleitgen-putin-soliders-ukraine-war-dnt-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 01:12:03+00:00

CNN's Frederik Pleitgen reports on the conflict in Ukraine as Russian President Vladimir Putin touts success, yet some of his soldiers refuse to fight.

## What we've learned about the Covid 'lab leak theory'
 - [https://www.cnn.com/collections/intl-covid-origin-2803/](https://www.cnn.com/collections/intl-covid-origin-2803/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 00:32:30+00:00



## European airline will suspend all flights to Moldovan capital due to 'recent developments'
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-02-27-23/h_3ad7bf5ac0516bbcc00bf751e5715b75](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-02-27-23/h_3ad7bf5ac0516bbcc00bf751e5715b75)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-02-28 00:16:52.178577+00:00



