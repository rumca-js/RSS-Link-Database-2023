# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## As criticism grows louder, Mexico's president accuses protesters of narco links
 - [https://www.cnn.com/2023/02/27/americas/mexico-protest-ine-amlo-intl-latam/index.html](https://www.cnn.com/2023/02/27/americas/mexico-protest-ine-amlo-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-02-28 02:31:20+00:00

Mexico's President Andrés Manuel López Obrador has dismissed concerns about his plan to shrink the country's electoral watchdog on Monday, accusing protesters of links to drug traffickers.

