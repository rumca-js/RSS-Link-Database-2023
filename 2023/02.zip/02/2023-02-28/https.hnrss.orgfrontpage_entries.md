# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Vodafone unveils prototype 5G network built on a Raspberry Pi computer
 - [https://www.vodafone.com/news/technology/vodafone-unveils-prototype-5g-network-built-raspberry-pi-computer](https://www.vodafone.com/news/technology/vodafone-unveils-prototype-5g-network-built-raspberry-pi-computer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 22:37:13+00:00

<p>Article URL: <a href="https://www.vodafone.com/news/technology/vodafone-unveils-prototype-5g-network-built-raspberry-pi-computer">https://www.vodafone.com/news/technology/vodafone-unveils-prototype-5g-network-built-raspberry-pi-computer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34975920">https://news.ycombinator.com/item?id=34975920</a></p>
<p>Points: 34</p>
<p># Comments: 9</p>

## TCG TPM2.0 implementations vulnerable to memory corruption
 - [https://kb.cert.org/vuls/id/782720](https://kb.cert.org/vuls/id/782720)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 20:31:08+00:00

<p>Article URL: <a href="https://kb.cert.org/vuls/id/782720">https://kb.cert.org/vuls/id/782720</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34974406">https://news.ycombinator.com/item?id=34974406</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## The Weapons That Win World Wars
 - [https://austinvernon.site/blog/peerwareconomics.html](https://austinvernon.site/blog/peerwareconomics.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 19:30:08+00:00

<p>Article URL: <a href="https://austinvernon.site/blog/peerwareconomics.html">https://austinvernon.site/blog/peerwareconomics.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34973700">https://news.ycombinator.com/item?id=34973700</a></p>
<p>Points: 16</p>
<p># Comments: 8</p>

## OpenAI's Foundry leaked pricing says a lot
 - [https://cognitiverevolution.substack.com/p/openais-foundry-leaked-pricing-says](https://cognitiverevolution.substack.com/p/openais-foundry-leaked-pricing-says)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 19:26:45+00:00

<p>Article URL: <a href="https://cognitiverevolution.substack.com/p/openais-foundry-leaked-pricing-says">https://cognitiverevolution.substack.com/p/openais-foundry-leaked-pricing-says</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34973654">https://news.ycombinator.com/item?id=34973654</a></p>
<p>Points: 14</p>
<p># Comments: 9</p>

## Generic dynamic array in 60 lines of C
 - [https://gist.github.com/nicebyte/86bd1f119d3ff5c8da06bc2fd59ad668](https://gist.github.com/nicebyte/86bd1f119d3ff5c8da06bc2fd59ad668)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 18:50:21+00:00

<p>Article URL: <a href="https://gist.github.com/nicebyte/86bd1f119d3ff5c8da06bc2fd59ad668">https://gist.github.com/nicebyte/86bd1f119d3ff5c8da06bc2fd59ad668</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34973210">https://news.ycombinator.com/item?id=34973210</a></p>
<p>Points: 10</p>
<p># Comments: 4</p>

## Show HN: Tinasaurus – a Docusaurus starter project with TinaCMS
 - [https://github.com/tinacms/tinasaurus](https://github.com/tinacms/tinasaurus)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 18:33:46+00:00

<p>Article URL: <a href="https://github.com/tinacms/tinasaurus">https://github.com/tinacms/tinasaurus</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972964">https://news.ycombinator.com/item?id=34972964</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Safety Performance of the Waymo Driver at One Million Miles [pdf]
 - [https://storage.googleapis.com/waymo-uploads/files/documents/safety/Safety%20Performance%20of%20Waymo%20RO%20at%201M%20miles.pdf](https://storage.googleapis.com/waymo-uploads/files/documents/safety/Safety%20Performance%20of%20Waymo%20RO%20at%201M%20miles.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 18:24:01+00:00

<p>Article URL: <a href="https://storage.googleapis.com/waymo-uploads/files/documents/safety/Safety%20Performance%20of%20Waymo%20RO%20at%201M%20miles.pdf">https://storage.googleapis.com/waymo-uploads/files/documents/safety/Safety%20Performance%20of%20Waymo%20RO%20at%201M%20miles.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972844">https://news.ycombinator.com/item?id=34972844</a></p>
<p>Points: 30</p>
<p># Comments: 13</p>

## Show HN: Briefsky – a free Dark Sky clone for multiple weather APIs
 - [https://briefsky.app/](https://briefsky.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 18:23:36+00:00

<p>Article URL: <a href="https://briefsky.app/">https://briefsky.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972839">https://news.ycombinator.com/item?id=34972839</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Show HN: The largest collection of ChatGPT jailbreaks on the internet
 - [https://www.jailbreakchat.com](https://www.jailbreakchat.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 18:19:21+00:00

<p>Created this site two weeks ago to compile some ChatGPT jailbreaks I had created and gradually began to add more from across the internet. Been loving growing the site and tracking the status of new jailbreak prompts.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972791">https://news.ycombinator.com/item?id=34972791</a></p>
<p>Points: 15</p>
<p># Comments: 4</p>

## How SMS Fraud Works and How to Guard Against It
 - [https://apuchitnis.substack.com/p/how-sms-fraud-works-and-how-to-guard-against-it](https://apuchitnis.substack.com/p/how-sms-fraud-works-and-how-to-guard-against-it)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 18:13:43+00:00

<p>Article URL: <a href="https://apuchitnis.substack.com/p/how-sms-fraud-works-and-how-to-guard-against-it">https://apuchitnis.substack.com/p/how-sms-fraud-works-and-how-to-guard-against-it</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972712">https://news.ycombinator.com/item?id=34972712</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Floating Calculation in Mesopotamia [pdf]
 - [https://arxiv.org/abs/2302.13607](https://arxiv.org/abs/2302.13607)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 18:13:17+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2302.13607">https://arxiv.org/abs/2302.13607</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972708">https://news.ycombinator.com/item?id=34972708</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Team-based map making with Felt
 - [https://felt.com/blog/felt-reaches-1-0-now-ready-for-teams](https://felt.com/blog/felt-reaches-1-0-now-ready-for-teams)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 18:03:56+00:00

<p>Article URL: <a href="https://felt.com/blog/felt-reaches-1-0-now-ready-for-teams">https://felt.com/blog/felt-reaches-1-0-now-ready-for-teams</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972587">https://news.ycombinator.com/item?id=34972587</a></p>
<p>Points: 21</p>
<p># Comments: 8</p>

## Null References: The Billion Dollar Mistake
 - [https://www.infoq.com/presentations/Null-References-The-Billion-Dollar-Mistake-Tony-Hoare/](https://www.infoq.com/presentations/Null-References-The-Billion-Dollar-Mistake-Tony-Hoare/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 18:03:43+00:00

<p>Article URL: <a href="https://www.infoq.com/presentations/Null-References-The-Billion-Dollar-Mistake-Tony-Hoare/">https://www.infoq.com/presentations/Null-References-The-Billion-Dollar-Mistake-Tony-Hoare/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972584">https://news.ycombinator.com/item?id=34972584</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## How the 8086 processor determines the length of an instruction
 - [https://www.righto.com/2023/02/how-8086-processor-determines-length-of.html](https://www.righto.com/2023/02/how-8086-processor-determines-length-of.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 17:56:49+00:00

<p>Article URL: <a href="https://www.righto.com/2023/02/how-8086-processor-determines-length-of.html">https://www.righto.com/2023/02/how-8086-processor-determines-length-of.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972490">https://news.ycombinator.com/item?id=34972490</a></p>
<p>Points: 22</p>
<p># Comments: 3</p>

## Free Music/Audio Visualizer Software to Render Videos
 - [https://github.com/s-a/sonic-sound-picture](https://github.com/s-a/sonic-sound-picture)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 17:27:13+00:00

<p>Article URL: <a href="https://github.com/s-a/sonic-sound-picture">https://github.com/s-a/sonic-sound-picture</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34972090">https://news.ycombinator.com/item?id=34972090</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Benchmarks of JavaScript Package Managers
 - [https://pnpm.io/benchmarks](https://pnpm.io/benchmarks)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 17:18:37+00:00

<p>Article URL: <a href="https://pnpm.io/benchmarks">https://pnpm.io/benchmarks</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34971950">https://news.ycombinator.com/item?id=34971950</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## A Spellchecker Used to Be a Major Feat of Software Engineering
 - [https://prog21.dadgum.com/29.html](https://prog21.dadgum.com/29.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 17:17:10+00:00

<p>Article URL: <a href="https://prog21.dadgum.com/29.html">https://prog21.dadgum.com/29.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34971924">https://news.ycombinator.com/item?id=34971924</a></p>
<p>Points: 19</p>
<p># Comments: 4</p>

## Core64: Interactive Core Memory Kit
 - [https://www.core64.io](https://www.core64.io)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 17:16:06+00:00

<p>Article URL: <a href="https://www.core64.io">https://www.core64.io</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34971904">https://news.ycombinator.com/item?id=34971904</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Launch HN: Pyq (YC W23) – Simple APIs to Popular AI Models
 - [https://news.ycombinator.com/item?id=34971883](https://news.ycombinator.com/item?id=34971883)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 17:14:59+00:00

<p>Hello HN! We’re Emily and Aman, the cofounders of Pyq (<a href="https://www.pyqai.com">https://www.pyqai.com</a>). We make it easy for developers to build features powered by AI. We do this by identifying specific tasks that AI can solve well and providing simple APIs that any developer can start using straight from our website.<p>We built Pyq because it took too long to build features that were powered by AI at our previous jobs. A lot of people want to get started using AI, but struggle because of the difficulties involved in managing infrastructure, finding the right model and learning how to call it. There are many interesting and useful models in places like Github or Hugging Face, as well as specific applications of popular models like OpenAI’s GPT, but they require a decent amount of work/knowledge to get working in your app.<p>The first issue is determining if and how your problem can be solved with AI. This generally involves experimenting with different models and (more recently) prompts, followed by potentially fine-tuning your model, at which point you’ll have to repeat this process with datasets. Then you move onto the set of challenges posed by getting that model deployed in production, including messing around with Docker, cloud infrastructure etc. This process can take weeks or even months. We aim to make it easy to match a problem to an AI solution and get it working in your application quickly.<p>Aman was leading a product team at a startup and was told that an already-built AI model would take an additional 3 weeks to bring to production. The only solution was to hire an engineer to do this and potentially pay for an enterprise MLOps platform on top of that. Simultaneously, Emily at Microsoft found herself asking the Azure team directly for help to hook up a model into the HoloLens application she was working on. The ensuing frustration resulted in our first principle: bringing an AI model to production should take minutes, not weeks!<p>Infrastructure is only one part of the problem. With all of the new possibilities afforded by modern AI models, it can be difficult to understand what business applications they can be used for. We decided to apply our knowledge of building AI-powered products to finding practical use cases that are easy for any developer to understand, even if they don’t have any AI knowledge.<p>We identify use cases of various AI models and provide straightforward APIs tailored to those use cases. We use both open-source models and popular providers such as OpenAI. This allows for easy and fast integration into apps. Rather than starting with the model, experimenting to see if it can actually do what you want it to, learning about deployment and serving, developers can just make a POST call to start using AI.<p>We serve our models with FastAPI, containerize them, and then deploy them to our GKE clusters. Depending on the model, we choose different machines - some require GPUs, most are decent on CPU. We take models up or down based on usage, so we have cold starts unless otherwise specified by customers. We expose access to the model via a POST call through our cloud app. We track inputs and outputs, as we expect that people will become interested in fine tuning models based on their past usage.<p>Pyq is not meant for AI experts or specialists, but for people who are building features which are powered by AI. We have a curated list of models that are good at specific tasks and are inexpensive to use. Some have been used thousands of times already!<p>Deploying your own model with us is also a very straightforward process and can usually be done within an hour. For those requiring low latency and high volume, we also offer a high performance API at additional cost.<p>Shortly after the launch of Chat GPT, we created a GPT Detector (<a href="https://www.gpt-detector.com" rel="nofollow">https://www.gpt-detector.com</a>, also available via API through our website) in collaboration with another YC company. This got a surprising amount of traction due to the virality of ChatGPT itself. Building the entire website took less than a day - we fine-tuned an existing text classification model, deployed it on Pyq and our partner integrated it with their front-end. It has been used 10,000+ times since then, and has been quite performant and inexpensive.<p>We have seen several other applications created in a similar way using Pyq. These include document OCR apps, chatbots, stock image generators and more.<p>We have a prepaid, usage-based pricing model. Every model has a “spot price” - the cost of 1 second of compute. This is available on each model’s page in our ‘Zoo.’ If you deploy your own model, we will give you your initial price manually and adjust it up or down over time depending on your needs.<p>We also provide $10 of free computing credit upon signup. This is enough to experiment with all of our models and, for some of them, enough to run a few hundred or even a thousand inferences. We add more credits on an ad-hoc basis, so feel free to email us at team[at]pyqai.com describing what you’re working on and we’ll do our best to accommodate you!<p>We are so excited to show this product. Our hope is that it helps you bring a project to life, finish that feature you’ve been working on, or just gives you ideas for what to build next. Please weigh in and tell us what you think!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34971883">https://news.ycombinator.com/item?id=34971883</a></p>
<p>Points: 23</p>
<p># Comments: 7</p>

## Complex Systems of Secrecy: The Offshore Networks of Oligarchs
 - [https://academic.oup.com/pnasnexus/advance-article/doi/10.1093/pnasnexus/pgad051/7059318](https://academic.oup.com/pnasnexus/advance-article/doi/10.1093/pnasnexus/pgad051/7059318)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 17:02:37+00:00

<p>Article URL: <a href="https://academic.oup.com/pnasnexus/advance-article/doi/10.1093/pnasnexus/pgad051/7059318">https://academic.oup.com/pnasnexus/advance-article/doi/10.1093/pnasnexus/pgad051/7059318</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34971717">https://news.ycombinator.com/item?id=34971717</a></p>
<p>Points: 31</p>
<p># Comments: 0</p>

## Legion Health (YC S21) is hiring a founding engineer to fix mental health
 - [https://www.ycombinator.com/companies/legion-health/jobs/rYWoawE-founding-engineer-full-stack](https://www.ycombinator.com/companies/legion-health/jobs/rYWoawE-founding-engineer-full-stack)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 17:00:39+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/legion-health/jobs/rYWoawE-founding-engineer-full-stack">https://www.ycombinator.com/companies/legion-health/jobs/rYWoawE-founding-engineer-full-stack</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34971686">https://news.ycombinator.com/item?id=34971686</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## The E-Ink Badge: The Coolest Badge You Didn't Know You Needed
 - [https://census.dev/blog/diy-e-ink-badge](https://census.dev/blog/diy-e-ink-badge)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 16:56:04+00:00

<p>Article URL: <a href="https://census.dev/blog/diy-e-ink-badge">https://census.dev/blog/diy-e-ink-badge</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34971627">https://news.ycombinator.com/item?id=34971627</a></p>
<p>Points: 63</p>
<p># Comments: 21</p>

## Show HN: Scribble Diffusion – Turn your sketch into a refined image using AI
 - [https://scribblediffusion.com](https://scribblediffusion.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 16:52:12+00:00

<p>Article URL: <a href="https://scribblediffusion.com">https://scribblediffusion.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34971579">https://news.ycombinator.com/item?id=34971579</a></p>
<p>Points: 38</p>
<p># Comments: 7</p>

## Hackers Claim They Breached T-Mobile More Than 100 Times in 2022
 - [https://krebsonsecurity.com/2023/02/hackers-claim-they-breached-t-mobile-more-than-100-times-in-2022/](https://krebsonsecurity.com/2023/02/hackers-claim-they-breached-t-mobile-more-than-100-times-in-2022/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 16:49:11+00:00

<p>Article URL: <a href="https://krebsonsecurity.com/2023/02/hackers-claim-they-breached-t-mobile-more-than-100-times-in-2022/">https://krebsonsecurity.com/2023/02/hackers-claim-they-breached-t-mobile-more-than-100-times-in-2022/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34971530">https://news.ycombinator.com/item?id=34971530</a></p>
<p>Points: 27</p>
<p># Comments: 14</p>

## Show HN: Crul – Query Any Webpage or API
 - [https://www.crul.com/](https://www.crul.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 16:12:58+00:00

<p>Hi HN, we’re Carl and Nic, the creators of crul (<a href="https://www.crul.com" rel="nofollow">https://www.crul.com</a>), and we’ve been hard at work for the last year and a half building our dream of turning the web into a dataset. In a nutshell crul is a tool for querying and building web and api data feeds from anywhere to anywhere.<p>With crul you can crawl and transform web pages into csv tables, explore and dynamically query APIs, filter and organize data, and push data sets to third party data lakes and analytics tools. Here’s a demo video, we’ve been told Nic sounds like John Mayer (lol) (<a href="https://www.crul.com/demo-video" rel="nofollow">https://www.crul.com/demo-video</a>)<p>We’ve personally struggled wrangling data from the web using puppeteer/playwright/selenium, jq or cobbling together python scripts, client libraries, and schedulers to consume APIs. The reality is that shit is hard, doesn’t scale (classic blocking for-loop or async saturation), and comes with thorny maintenance/security issues. The tools we love to hate.<p>Crul’s value prop is simple: Query any Webpage or API for free.<p>At its core, crul is based on the foundational linked nature of Web/API content. It consists of a purpose built map/expand/reduce engine for hierarchical Web/API content (kind of like postman but with a membership to Gold's Gym) with a familiar parser expression grammar that naturally gets the job done (and layered caching to make it quick to fix when it doesn’t on the first try). There’s a boatload of other features like domain policies, scheduler, checkpoints, templates, REST API, Web UI, vault, OAuth for third parties and 20+ stores to send your data to.<p>Our goal is to open source crul as time and resources permit. At the end of the day it’s just the two of us trying to figure things out as we go! We’re just getting started.<p>Crul is one bad mother#^@%*& and the web is finally yours!<p>Download crul for free as a Mac OS desktop application or as a Docker image (<a href="https://www.crul.com" rel="nofollow">https://www.crul.com</a>) and let us know if you love it or hate it. (<a href="https://forms.gle/5BXb5bLC1D5QG7i99" rel="nofollow">https://forms.gle/5BXb5bLC1D5QG7i99</a>) And come say hello to us on our slack channel - we’re a friendly bunch! (<a href="https://crulinc.slack.com/" rel="nofollow">https://crulinc.slack.com/</a>)<p>Nic and Carl (<a href="https://www.crul.com/early-days" rel="nofollow">https://www.crul.com/early-days</a>)</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34970917">https://news.ycombinator.com/item?id=34970917</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Transformer learning explained: Coinductive guide to inductive transformer heads
 - [https://arxiv.org/abs/2302.01834](https://arxiv.org/abs/2302.01834)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 16:10:19+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2302.01834">https://arxiv.org/abs/2302.01834</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34970877">https://news.ycombinator.com/item?id=34970877</a></p>
<p>Points: 20</p>
<p># Comments: 7</p>

## Loneliness Reshapes the Brain
 - [https://www.quantamagazine.org/how-loneliness-reshapes-the-brain-20230228/](https://www.quantamagazine.org/how-loneliness-reshapes-the-brain-20230228/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 16:00:58+00:00

<p>Article URL: <a href="https://www.quantamagazine.org/how-loneliness-reshapes-the-brain-20230228/">https://www.quantamagazine.org/how-loneliness-reshapes-the-brain-20230228/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34970752">https://news.ycombinator.com/item?id=34970752</a></p>
<p>Points: 33</p>
<p># Comments: 5</p>

## The End of the English Major
 - [https://www.newyorker.com/magazine/2023/03/06/the-end-of-the-english-major](https://www.newyorker.com/magazine/2023/03/06/the-end-of-the-english-major)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 15:53:52+00:00

<p>Article URL: <a href="https://www.newyorker.com/magazine/2023/03/06/the-end-of-the-english-major">https://www.newyorker.com/magazine/2023/03/06/the-end-of-the-english-major</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34970650">https://news.ycombinator.com/item?id=34970650</a></p>
<p>Points: 27</p>
<p># Comments: 91</p>

## Ford patents car that can repossess itself and drive back to showroom
 - [https://www.newscientist.com/article/2361657-ford-patents-car-that-can-repossess-itself-and-drive-back-to-showroom/](https://www.newscientist.com/article/2361657-ford-patents-car-that-can-repossess-itself-and-drive-back-to-showroom/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 15:51:04+00:00

<p>Article URL: <a href="https://www.newscientist.com/article/2361657-ford-patents-car-that-can-repossess-itself-and-drive-back-to-showroom/">https://www.newscientist.com/article/2361657-ford-patents-car-that-can-repossess-itself-and-drive-back-to-showroom/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34970619">https://news.ycombinator.com/item?id=34970619</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Show HN: Tabular – Email design tool that generates bulletproof email HTML
 - [https://tabular.email/](https://tabular.email/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 15:11:29+00:00

<p>Article URL: <a href="https://tabular.email/">https://tabular.email/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34970142">https://news.ycombinator.com/item?id=34970142</a></p>
<p>Points: 26</p>
<p># Comments: 9</p>

## Beating OpenAI CLIP with 100x less data and compute
 - [https://www.unum.cloud/blog/2023-02-20-efficient-multimodality](https://www.unum.cloud/blog/2023-02-20-efficient-multimodality)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 15:04:12+00:00

<p>Article URL: <a href="https://www.unum.cloud/blog/2023-02-20-efficient-multimodality">https://www.unum.cloud/blog/2023-02-20-efficient-multimodality</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34970045">https://news.ycombinator.com/item?id=34970045</a></p>
<p>Points: 59</p>
<p># Comments: 6</p>

## Microsoft somehow brings iMessage to Windows, will it last?
 - [https://9to5mac.com/2023/02/28/microsoft-imessage-windows-support/](https://9to5mac.com/2023/02/28/microsoft-imessage-windows-support/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 14:49:47+00:00

<p>Article URL: <a href="https://9to5mac.com/2023/02/28/microsoft-imessage-windows-support/">https://9to5mac.com/2023/02/28/microsoft-imessage-windows-support/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969864">https://news.ycombinator.com/item?id=34969864</a></p>
<p>Points: 9</p>
<p># Comments: 3</p>

## AI Tool Reveals How Celebrities’ Faces Have Been Photoshopped
 - [https://petapixel.com/2023/02/28/ai-tool-reveals-how-celebrities-faces-have-been-photoshopped/](https://petapixel.com/2023/02/28/ai-tool-reveals-how-celebrities-faces-have-been-photoshopped/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 14:49:15+00:00

<p>Article URL: <a href="https://petapixel.com/2023/02/28/ai-tool-reveals-how-celebrities-faces-have-been-photoshopped/">https://petapixel.com/2023/02/28/ai-tool-reveals-how-celebrities-faces-have-been-photoshopped/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969854">https://news.ycombinator.com/item?id=34969854</a></p>
<p>Points: 33</p>
<p># Comments: 8</p>

## Rosenpass – formally verified post-quantum WireGuard
 - [https://github.com/rosenpass/rosenpass](https://github.com/rosenpass/rosenpass)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 14:40:19+00:00

<p>Article URL: <a href="https://github.com/rosenpass/rosenpass">https://github.com/rosenpass/rosenpass</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969760">https://news.ycombinator.com/item?id=34969760</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Client-side encryption for Gmail is now generally available (for Workspace/Edu)
 - [https://workspaceupdates.googleblog.com/2023/02/client-side-encryption-for-gmail-generally-available.html](https://workspaceupdates.googleblog.com/2023/02/client-side-encryption-for-gmail-generally-available.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 14:36:51+00:00

<p>Article URL: <a href="https://workspaceupdates.googleblog.com/2023/02/client-side-encryption-for-gmail-generally-available.html">https://workspaceupdates.googleblog.com/2023/02/client-side-encryption-for-gmail-generally-available.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969726">https://news.ycombinator.com/item?id=34969726</a></p>
<p>Points: 46</p>
<p># Comments: 29</p>

## Show HN: Photovatar – The AI-Powered Avatar Generator
 - [https://github.com/ozalpozqur/photovatar](https://github.com/ozalpozqur/photovatar)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 14:30:24+00:00

<p>Hey Hacker News community! I'm thrilled to share with you my latest creation - Photovatar, the ultimate avatar generator app powered by state-of-the-art AI models like sczhou/codeformer and pollinations/modnet.<p>With Photovatar, you can easily generate custom avatars with just a few clicks. The app allows you to remove unwanted backgrounds, define custom backgrounds, and even increase photo quality. And the best part? It's completely free, and you can build your own!
Our app is perfect for anyone looking to create personalized avatars for their social media profiles, blogs, websites, and more. We've also made it super easy to accept payments and top-up credits with Stripe integration(test mode)<p>Stripe test cards:
Card number: 4242 4242 4242 4242
Expiration date: Any future date (1234)
CVC: Any 3 digits (567)<p>Give Photovatar a try, and let us know what you think! Feel free the share any feedback and question. Contribute the example repository with issues and pull requests.<p>Live demo: <a href="https://www.photovatar.com" rel="nofollow">https://www.photovatar.com</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969662">https://news.ycombinator.com/item?id=34969662</a></p>
<p>Points: 19</p>
<p># Comments: 5</p>

## Rare insect found at AR Walmart sets historic record, points to deeper questions
 - [https://phys.org/news/2023-02-rare-insect-arkansas-walmart-historic.html](https://phys.org/news/2023-02-rare-insect-arkansas-walmart-historic.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 14:27:49+00:00

<p>Article URL: <a href="https://phys.org/news/2023-02-rare-insect-arkansas-walmart-historic.html">https://phys.org/news/2023-02-rare-insect-arkansas-walmart-historic.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969629">https://news.ycombinator.com/item?id=34969629</a></p>
<p>Points: 22</p>
<p># Comments: 21</p>

## Ford seeks patent for cars that ditch you if payments missed
 - [https://www.theregister.com/2023/02/28/ford_self_repossessing_patent/](https://www.theregister.com/2023/02/28/ford_self_repossessing_patent/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 14:27:09+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/02/28/ford_self_repossessing_patent/">https://www.theregister.com/2023/02/28/ford_self_repossessing_patent/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969623">https://news.ycombinator.com/item?id=34969623</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## sqlean: A set of SQLite extensions
 - [https://github.com/nalgeon/sqlean](https://github.com/nalgeon/sqlean)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 14:14:14+00:00

<p>Article URL: <a href="https://github.com/nalgeon/sqlean">https://github.com/nalgeon/sqlean</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969491">https://news.ycombinator.com/item?id=34969491</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Deep learning tool audioFlux: a systematic audio feature extraction library
 - [https://github.com/libAudioFlux/audioFlux](https://github.com/libAudioFlux/audioFlux)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 13:30:31+00:00

<p>Article URL: <a href="https://github.com/libAudioFlux/audioFlux">https://github.com/libAudioFlux/audioFlux</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969054">https://news.ycombinator.com/item?id=34969054</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Proposal to Merge Pyston with Cpython
 - [https://discuss.python.org/t/contributing-the-pyston-jit/24195](https://discuss.python.org/t/contributing-the-pyston-jit/24195)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 13:29:50+00:00

<p>Article URL: <a href="https://discuss.python.org/t/contributing-the-pyston-jit/24195">https://discuss.python.org/t/contributing-the-pyston-jit/24195</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34969046">https://news.ycombinator.com/item?id=34969046</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## The Micro-Paper: Towards cheaper, citable research ideas and conversations [pdf]
 - [https://export.arxiv.org/ftp/arxiv/papers/2302/2302.12854.pdf](https://export.arxiv.org/ftp/arxiv/papers/2302/2302.12854.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 13:24:50+00:00

<p>Article URL: <a href="https://export.arxiv.org/ftp/arxiv/papers/2302/2302.12854.pdf">https://export.arxiv.org/ftp/arxiv/papers/2302/2302.12854.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968996">https://news.ycombinator.com/item?id=34968996</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Pandas 2.0 and the Arrow revolution
 - [https://datapythonista.me/blog/](https://datapythonista.me/blog/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:59:11+00:00

<p>Article URL: <a href="https://datapythonista.me/blog/">https://datapythonista.me/blog/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968769">https://news.ycombinator.com/item?id=34968769</a></p>
<p>Points: 55</p>
<p># Comments: 14</p>

## Linux is not “ready to run” on Apple Silicon, but give it time
 - [https://arstechnica.com/gadgets/2023/02/linux-is-not-exactly-ready-to-run-on-apple-silicon-but-give-it-time/](https://arstechnica.com/gadgets/2023/02/linux-is-not-exactly-ready-to-run-on-apple-silicon-but-give-it-time/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:58:36+00:00

<p>Article URL: <a href="https://arstechnica.com/gadgets/2023/02/linux-is-not-exactly-ready-to-run-on-apple-silicon-but-give-it-time/">https://arstechnica.com/gadgets/2023/02/linux-is-not-exactly-ready-to-run-on-apple-silicon-but-give-it-time/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968757">https://news.ycombinator.com/item?id=34968757</a></p>
<p>Points: 14</p>
<p># Comments: 8</p>

## Explanation of the Domino's Pizza Tracker
 - [https://twitter.com/snubs/status/1630220894919598080](https://twitter.com/snubs/status/1630220894919598080)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:55:10+00:00

<p>Article URL: <a href="https://twitter.com/snubs/status/1630220894919598080">https://twitter.com/snubs/status/1630220894919598080</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968730">https://news.ycombinator.com/item?id=34968730</a></p>
<p>Points: 28</p>
<p># Comments: 13</p>

## Tunnelmole – give your local servers a public URL
 - [https://github.com/robbie-cahill/tunnelmole-client](https://github.com/robbie-cahill/tunnelmole-client)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:44:44+00:00

<p>Article URL: <a href="https://github.com/robbie-cahill/tunnelmole-client">https://github.com/robbie-cahill/tunnelmole-client</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968649">https://news.ycombinator.com/item?id=34968649</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Mars will have a lot of wicker furniture
 - [https://havewelanded.com/mars-wicker-furniture](https://havewelanded.com/mars-wicker-furniture)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:39:47+00:00

<p>Article URL: <a href="https://havewelanded.com/mars-wicker-furniture">https://havewelanded.com/mars-wicker-furniture</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968606">https://news.ycombinator.com/item?id=34968606</a></p>
<p>Points: 20</p>
<p># Comments: 1</p>

## Woman wins case against British Airways over flight vouchers
 - [https://www.bbc.co.uk/news/uk-england-birmingham-64788448](https://www.bbc.co.uk/news/uk-england-birmingham-64788448)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:39:23+00:00

<p>Article URL: <a href="https://www.bbc.co.uk/news/uk-england-birmingham-64788448">https://www.bbc.co.uk/news/uk-england-birmingham-64788448</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968602">https://news.ycombinator.com/item?id=34968602</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Fourier analysis provides ideas on how to train more accurate neural networks
 - [https://spectrum.ieee.org/black-box-ai](https://spectrum.ieee.org/black-box-ai)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:04:51+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/black-box-ai">https://spectrum.ieee.org/black-box-ai</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968381">https://news.ycombinator.com/item?id=34968381</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## What I Learned at Stripe
 - [https://steinkamp.us/post/2022/11/10/what-i-learned-at-stripe.html](https://steinkamp.us/post/2022/11/10/what-i-learned-at-stripe.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:02:35+00:00

<p>Article URL: <a href="https://steinkamp.us/post/2022/11/10/what-i-learned-at-stripe.html">https://steinkamp.us/post/2022/11/10/what-i-learned-at-stripe.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968371">https://news.ycombinator.com/item?id=34968371</a></p>
<p>Points: 30</p>
<p># Comments: 19</p>

## Laudspeaker (YC W21) hiring to build open source customer journey software
 - [https://news.ycombinator.com/item?id=34968362](https://news.ycombinator.com/item?id=34968362)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:00:18+00:00

<p>Our mission is to build a new, open source suite of software tools to completely handle the "customer journey". You can see our repo here: (<a href="https://github.com/laudspeaker/laudspeaker">https://github.com/laudspeaker/laudspeaker</a>) we had successful launch on HN a few weeks ago and are moving quickly with a very ambitious roadmap.<p>We are looking for two senior software engineers, who will work closely with the founding team to build a highly scalable, performant software system that is both developer friendly but is also extremely easy to use for marketers and product marketers.<p>Both engineers will be full-stack, but one will focus more on<p>- Building a distributed system with job queues, and parallelization that can handle sending millions of customer messages a second.
- Building and maintaining a system for integrations for novel customer messaging channels, product analytics systems, and customer data sources
- Building developer tooling for first-in-class "journey testing"
- Testing and helping build determinism in the system consistent with our state machine like architecture<p>The other engineer will be more customer and product focused and will work on our core user experience, helping to build
- Our no-code journey builder canvas
- Our Messaging template editor
- An easy way to determine, save and find customer segments
- A lot more to come!<p>Both engineers will have a big say in the product direction, should be excited to move quickly and will help build out a team of world-class, highly collaborative, software engineers.<p>Some more details:<p>- We work in Typescript with Nest.js for the backend and react for the frontend
- We use technologies like: clickhouse, postgres, bullmq, docker, mongo
- technologies we will likely use soon: kafka, celery, temporal
- We are a remote team out of NY/Mountain View and Ukraine (and are open to gmt +2 to gmt + 8 timezones)
- Did we mention we are open source :D (<a href="https://github.com/laudspeaker/laudspeaker">https://github.com/laudspeaker/laudspeaker</a>)
- We raised our seed round from top tier investors (including YC) and will announce the funding in a future press release.<p>If this interests you please reach out to the founders, at hey [at] laudspeaker [dot] com</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968362">https://news.ycombinator.com/item?id=34968362</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Comparing static website hosts (2022)
 - [https://kevquirk.com/comparing-static-site-hosts-best-host-for-a-static-site/](https://kevquirk.com/comparing-static-site-hosts-best-host-for-a-static-site/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 12:00:12+00:00

<p>Article URL: <a href="https://kevquirk.com/comparing-static-site-hosts-best-host-for-a-static-site/">https://kevquirk.com/comparing-static-site-hosts-best-host-for-a-static-site/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968360">https://news.ycombinator.com/item?id=34968360</a></p>
<p>Points: 16</p>
<p># Comments: 15</p>

## News Corp says state hackers were on its network for two years
 - [https://www.bleepingcomputer.com/news/security/news-corp-says-state-hackers-were-on-its-network-for-two-years/](https://www.bleepingcomputer.com/news/security/news-corp-says-state-hackers-were-on-its-network-for-two-years/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 11:59:42+00:00

<p>Article URL: <a href="https://www.bleepingcomputer.com/news/security/news-corp-says-state-hackers-were-on-its-network-for-two-years/">https://www.bleepingcomputer.com/news/security/news-corp-says-state-hackers-were-on-its-network-for-two-years/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968354">https://news.ycombinator.com/item?id=34968354</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Who rules Earth? Wild mammals far outweighed by humans and domestic animals
 - [https://www.science.org/content/article/who-rules-earth-wild-mammals-far-outweighed-humans-and-domestic-animals](https://www.science.org/content/article/who-rules-earth-wild-mammals-far-outweighed-humans-and-domestic-animals)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 11:55:15+00:00

<p>Article URL: <a href="https://www.science.org/content/article/who-rules-earth-wild-mammals-far-outweighed-humans-and-domestic-animals">https://www.science.org/content/article/who-rules-earth-wild-mammals-far-outweighed-humans-and-domestic-animals</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968316">https://news.ycombinator.com/item?id=34968316</a></p>
<p>Points: 13</p>
<p># Comments: 8</p>

## We will not ‘walk out’ of UK, nor comply with any request to bypass encryption
 - [https://tutanota.com/blog/posts/uk-undermine-encryption](https://tutanota.com/blog/posts/uk-undermine-encryption)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 11:51:49+00:00

<p>Article URL: <a href="https://tutanota.com/blog/posts/uk-undermine-encryption">https://tutanota.com/blog/posts/uk-undermine-encryption</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968295">https://news.ycombinator.com/item?id=34968295</a></p>
<p>Points: 102</p>
<p># Comments: 47</p>

## AI simulates hypersonic air battle, offering tactic for winning Mach 11 dogfight
 - [https://www.scmp.com/news/china/science/article/3211730/chinese-ai-simulates-hypersonic-air-battle-offering-surprising-tactic-winning-mach-11-dogfight](https://www.scmp.com/news/china/science/article/3211730/chinese-ai-simulates-hypersonic-air-battle-offering-surprising-tactic-winning-mach-11-dogfight)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 11:51:20+00:00

<p>Article URL: <a href="https://www.scmp.com/news/china/science/article/3211730/chinese-ai-simulates-hypersonic-air-battle-offering-surprising-tactic-winning-mach-11-dogfight">https://www.scmp.com/news/china/science/article/3211730/chinese-ai-simulates-hypersonic-air-battle-offering-surprising-tactic-winning-mach-11-dogfight</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968290">https://news.ycombinator.com/item?id=34968290</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## How to write Python extensions in Rust with PyO3
 - [https://www.infoworld.com/article/3687744/how-to-write-python-extensions-in-rust-with-pyo3.html](https://www.infoworld.com/article/3687744/how-to-write-python-extensions-in-rust-with-pyo3.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 11:31:19+00:00

<p>Article URL: <a href="https://www.infoworld.com/article/3687744/how-to-write-python-extensions-in-rust-with-pyo3.html">https://www.infoworld.com/article/3687744/how-to-write-python-extensions-in-rust-with-pyo3.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34968186">https://news.ycombinator.com/item?id=34968186</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## Why and How I use Org Mode for my writing and more
 - [https://www.evalapply.org/posts/why-and-how-i-use-org-mode/index.html](https://www.evalapply.org/posts/why-and-how-i-use-org-mode/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 10:34:06+00:00

<p>Article URL: <a href="https://www.evalapply.org/posts/why-and-how-i-use-org-mode/index.html">https://www.evalapply.org/posts/why-and-how-i-use-org-mode/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34967802">https://news.ycombinator.com/item?id=34967802</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## World Building with GPT
 - [https://ianbicking.org/blog/2023/02/world-building-with-gpt.html](https://ianbicking.org/blog/2023/02/world-building-with-gpt.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 09:48:34+00:00

<p>Article URL: <a href="https://ianbicking.org/blog/2023/02/world-building-with-gpt.html">https://ianbicking.org/blog/2023/02/world-building-with-gpt.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34967515">https://news.ycombinator.com/item?id=34967515</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## “Clean” Code, Horrible Performance – Casey Muratori [video]
 - [https://www.youtube.com/watch?v=tD5NrevFtbU](https://www.youtube.com/watch?v=tD5NrevFtbU)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 09:47:40+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=tD5NrevFtbU">https://www.youtube.com/watch?v=tD5NrevFtbU</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34967512">https://news.ycombinator.com/item?id=34967512</a></p>
<p>Points: 13</p>
<p># Comments: 8</p>

## Finding a former Australian prime minister’s passport number on Instagram (2020)
 - [https://mango.pdf.zone/finding-former-australian-prime-minister-tony-abbotts-passport-number-on-instagram](https://mango.pdf.zone/finding-former-australian-prime-minister-tony-abbotts-passport-number-on-instagram)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 08:13:40+00:00

<p>Article URL: <a href="https://mango.pdf.zone/finding-former-australian-prime-minister-tony-abbotts-passport-number-on-instagram">https://mango.pdf.zone/finding-former-australian-prime-minister-tony-abbotts-passport-number-on-instagram</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34966909">https://news.ycombinator.com/item?id=34966909</a></p>
<p>Points: 31</p>
<p># Comments: 12</p>

## Where has all the Chartreuse gone?
 - [https://www.everydaydrinking.com/p/where-has-all-the-chartreuse-gone](https://www.everydaydrinking.com/p/where-has-all-the-chartreuse-gone)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 08:04:19+00:00

<p>Article URL: <a href="https://www.everydaydrinking.com/p/where-has-all-the-chartreuse-gone">https://www.everydaydrinking.com/p/where-has-all-the-chartreuse-gone</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34966845">https://news.ycombinator.com/item?id=34966845</a></p>
<p>Points: 25</p>
<p># Comments: 5</p>

## We're creating a new top-level product group at Meta focused on generative AI
 - [https://www.facebook.com/4/posts/were-creating-a-new-top-level-product-group-at-meta-focused-on-generative-ai-to-/10115006704889901/](https://www.facebook.com/4/posts/were-creating-a-new-top-level-product-group-at-meta-focused-on-generative-ai-to-/10115006704889901/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 07:43:53+00:00

<p>Article URL: <a href="https://www.facebook.com/4/posts/were-creating-a-new-top-level-product-group-at-meta-focused-on-generative-ai-to-/10115006704889901/">https://www.facebook.com/4/posts/were-creating-a-new-top-level-product-group-at-meta-focused-on-generative-ai-to-/10115006704889901/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34966715">https://news.ycombinator.com/item?id=34966715</a></p>
<p>Points: 13</p>
<p># Comments: 6</p>

## “Clean” Code, Horrible Performance [video]
 - [https://www.youtube.com/watch?v=VkillO8yf4Y](https://www.youtube.com/watch?v=VkillO8yf4Y)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 07:19:05+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=VkillO8yf4Y">https://www.youtube.com/watch?v=VkillO8yf4Y</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34966572">https://news.ycombinator.com/item?id=34966572</a></p>
<p>Points: 28</p>
<p># Comments: 8</p>

## X12 (2013)
 - [https://www.x.org/wiki/Development/X12/](https://www.x.org/wiki/Development/X12/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 06:59:39+00:00

<p>Article URL: <a href="https://www.x.org/wiki/Development/X12/">https://www.x.org/wiki/Development/X12/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34966472">https://news.ycombinator.com/item?id=34966472</a></p>
<p>Points: 51</p>
<p># Comments: 19</p>

## The widespread layoffs are more because of copycat behavior than cost-cutting
 - [https://www.businessinsider.com/stanford-professor-mass-layoffs-caused-by-social-contagion-companies-imitating-2023-2](https://www.businessinsider.com/stanford-professor-mass-layoffs-caused-by-social-contagion-companies-imitating-2023-2)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 05:55:24+00:00

<p>Article URL: <a href="https://www.businessinsider.com/stanford-professor-mass-layoffs-caused-by-social-contagion-companies-imitating-2023-2">https://www.businessinsider.com/stanford-professor-mass-layoffs-caused-by-social-contagion-companies-imitating-2023-2</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34966138">https://news.ycombinator.com/item?id=34966138</a></p>
<p>Points: 29</p>
<p># Comments: 6</p>

## pgvector: Open-source vector similarity search for Postgres
 - [https://github.com/pgvector/pgvector](https://github.com/pgvector/pgvector)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 05:38:40+00:00

<p>Article URL: <a href="https://github.com/pgvector/pgvector">https://github.com/pgvector/pgvector</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34966045">https://news.ycombinator.com/item?id=34966045</a></p>
<p>Points: 23</p>
<p># Comments: 0</p>

## FFmpeg 6.0
 - [http://www.ffmpeg.org/download.html#release_6.0](http://www.ffmpeg.org/download.html#release_6.0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 04:13:53+00:00

<p>Article URL: <a href="http://www.ffmpeg.org/download.html#release_6.0">http://www.ffmpeg.org/download.html#release_6.0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34965535">https://news.ycombinator.com/item?id=34965535</a></p>
<p>Points: 80</p>
<p># Comments: 36</p>

## LLMs that can see and hear
 - [https://arxiv.org/abs/2302.14045](https://arxiv.org/abs/2302.14045)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 03:36:31+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2302.14045">https://arxiv.org/abs/2302.14045</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34965326">https://news.ycombinator.com/item?id=34965326</a></p>
<p>Points: 22</p>
<p># Comments: 6</p>

## LastPass says DevOps engineer’s hacked computer led to security breach in 2022
 - [https://9to5mac.com/2023/02/27/lastpass-devops-engineers-hacked/](https://9to5mac.com/2023/02/27/lastpass-devops-engineers-hacked/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 03:21:53+00:00

<p>Article URL: <a href="https://9to5mac.com/2023/02/27/lastpass-devops-engineers-hacked/">https://9to5mac.com/2023/02/27/lastpass-devops-engineers-hacked/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34965260">https://news.ycombinator.com/item?id=34965260</a></p>
<p>Points: 46</p>
<p># Comments: 12</p>

## The Lone Developer Problem
 - [https://evanhahn.com/the-lone-developer-problem/](https://evanhahn.com/the-lone-developer-problem/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 03:11:04+00:00

<p>Article URL: <a href="https://evanhahn.com/the-lone-developer-problem/">https://evanhahn.com/the-lone-developer-problem/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34965201">https://news.ycombinator.com/item?id=34965201</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## I just wanted to see James Taylor – – I didn't know it would cost me $5k
 - [https://www.berkshireeagle.com/opinion/columnists/simon-winchester-james-taylor-tickets-secondary-ticket-market-five-thousand-dollars/article_628155f2-b471-11ed-8e17-c79bc3e262ff.html](https://www.berkshireeagle.com/opinion/columnists/simon-winchester-james-taylor-tickets-secondary-ticket-market-five-thousand-dollars/article_628155f2-b471-11ed-8e17-c79bc3e262ff.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 03:04:58+00:00

<p>Article URL: <a href="https://www.berkshireeagle.com/opinion/columnists/simon-winchester-james-taylor-tickets-secondary-ticket-market-five-thousand-dollars/article_628155f2-b471-11ed-8e17-c79bc3e262ff.html">https://www.berkshireeagle.com/opinion/columnists/simon-winchester-james-taylor-tickets-secondary-ticket-market-five-thousand-dollars/article_628155f2-b471-11ed-8e17-c79bc3e262ff.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34965162">https://news.ycombinator.com/item?id=34965162</a></p>
<p>Points: 29</p>
<p># Comments: 9</p>

## Unfolder for Mac – a 3D modelcreating papercraft
 - [https://www.unfolder.app/](https://www.unfolder.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 02:31:48+00:00

<p>Article URL: <a href="https://www.unfolder.app/">https://www.unfolder.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34964939">https://news.ycombinator.com/item?id=34964939</a></p>
<p>Points: 27</p>
<p># Comments: 3</p>

## Vimium – The Hacker's Browser
 - [https://vimium.github.io/](https://vimium.github.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 01:32:06+00:00

<p>Article URL: <a href="https://vimium.github.io/">https://vimium.github.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34964572">https://news.ycombinator.com/item?id=34964572</a></p>
<p>Points: 62</p>
<p># Comments: 30</p>

## Firecracker internals: deep dive inside the technology powering AWS Lambda(2021)
 - [https://www.talhoffman.com/2021/07/18/firecracker-internals/](https://www.talhoffman.com/2021/07/18/firecracker-internals/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 00:37:11+00:00

<p>Article URL: <a href="https://www.talhoffman.com/2021/07/18/firecracker-internals/">https://www.talhoffman.com/2021/07/18/firecracker-internals/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34964197">https://news.ycombinator.com/item?id=34964197</a></p>
<p>Points: 25</p>
<p># Comments: 3</p>

## Work-from-Home Regulations Are Coming. Companies Aren’t Ready
 - [https://sloanreview.mit.edu/article/work-from-home-regulations-are-coming-companies-arent-ready/](https://sloanreview.mit.edu/article/work-from-home-regulations-are-coming-companies-arent-ready/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 00:33:01+00:00

<p>Article URL: <a href="https://sloanreview.mit.edu/article/work-from-home-regulations-are-coming-companies-arent-ready/">https://sloanreview.mit.edu/article/work-from-home-regulations-are-coming-companies-arent-ready/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34964159">https://news.ycombinator.com/item?id=34964159</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Why CMake Sucks?
 - [https://twdev.blog/2021/08/cmake/](https://twdev.blog/2021/08/cmake/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-28 00:32:24+00:00

<p>Article URL: <a href="https://twdev.blog/2021/08/cmake/">https://twdev.blog/2021/08/cmake/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34964152">https://news.ycombinator.com/item?id=34964152</a></p>
<p>Points: 35</p>
<p># Comments: 20</p>

