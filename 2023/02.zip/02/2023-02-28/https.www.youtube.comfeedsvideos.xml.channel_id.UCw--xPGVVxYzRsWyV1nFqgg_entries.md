# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Rebel's Creed - FULL AUDIOBOOK
 - [https://www.youtube.com/watch?v=pOzAwvLIWuo](https://www.youtube.com/watch?v=pOzAwvLIWuo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2023-02-28 14:00:34+00:00

The Full Audiobook for the second book in the Lawful Times series, Breach of Peace! Narrated by Kate Reading and Michael Kramer. 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.danielbgreene.com 

Lawful Times Series: 
Breach of Peace: https://tinyurl.com/BoPTLT 
Rebels Creed: https://tinyurl.com/RCTLTDG

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lens: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

