# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## Don't Lose Your Data Like a Dummy
 - [https://www.youtube.com/watch?v=RB4kwfY2w7A](https://www.youtube.com/watch?v=RB4kwfY2w7A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2023-02-28 16:00:13+00:00

In this episode, we discuss the 3-2-1 backup method and why your data is probably at risk.
Thanks for Acronis for sponsoring this video! Head to https://go.acronis.com/SNAZZYLABS and use code SNAZZYLABS2023 to get 40% off Acronis Cyber Protect Home Office.

Let's face it: backing up data is boring. But nothing is more devastating than losing family photos, important work reports, school essays, and more. The good thing is that data loss is 100% avoidable and it's always human error. While computers can fail, drives can be corrupted, homes can burn down, and more, properly backing up using the 3-2-1 method ensures your data will live far longer than you. From Blu-ray, to LTO, to cloud storage, and more... there are a lot of very affordable (and very expensive) ways to backup and archive your data shown in this episode and by the end of it, you'll have a good idea of what you need to do to save your own stuff!

Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

