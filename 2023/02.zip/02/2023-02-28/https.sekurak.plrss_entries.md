# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## ING Bank jako pierwszy w Polsce wprowadzi możliwość logowania się z wykorzystaniem kluczy U2F
 - [https://sekurak.pl/ing-polska-jako-pierwszy-w-polsce-wprowadzi-mozliwosc-logowania-sie-z-wykorzystaniem-kluczy-u2f/](https://sekurak.pl/ing-polska-jako-pierwszy-w-polsce-wprowadzi-mozliwosc-logowania-sie-z-wykorzystaniem-kluczy-u2f/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-02-28 19:32:25+00:00

<p>Bank od dłuższego czasu pracował nad wprowadzeniem tego mechanizmu dwuczynnikowego logowania do bankowości elektronicznej: Obecnie wszystko wskazuje na to, że prace dobiegają końca i w okolicach Q2/Q3 2023 roku całość będzie gotowa. Bank w ten sposób odpowiedział na pytanie serwisu Cashless: Sprzętowe klucze zabezpieczające planujemy wprowadzić jako kolejny faktor silnego...</p>
<p>Artykuł <a href="https://sekurak.pl/ing-polska-jako-pierwszy-w-polsce-wprowadzi-mozliwosc-logowania-sie-z-wykorzystaniem-kluczy-u2f/" rel="nofollow">ING Bank jako pierwszy w Polsce wprowadzi możliwość logowania się z wykorzystaniem kluczy U2F</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## LastPass: „atakujący zhackowali komputer jednego z naszych pracowników, zainstalowali keyloggera” [nowe szczegóły dotyczące poprzedniego ataku]
 - [https://sekurak.pl/lastpass-atakujacy-zhackowali-komputer-jednego-z-naszych-pracownikow-zainstalowali-keyloggera-nowe-szczegoly-dotyczace-poprzedniego-ataku/](https://sekurak.pl/lastpass-atakujacy-zhackowali-komputer-jednego-z-naszych-pracownikow-zainstalowali-keyloggera-nowe-szczegoly-dotyczace-poprzedniego-ataku/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-02-28 08:48:26+00:00

<p>Cały czas nie cichną echa afery związanej ze zhackowaniem infrastruktury managera haseł LastPass (więcej o temacie pisaliśmy w tym miejscu). W ostatniej aktualizacji LastPass zaznacza, że jednym z kluczowych elementów całego dużego hacku infrastruktury było otrzymanie dostępu do komputera jednego z kluczowych pracowników: hacker zaatakował jednego z czterech inżynierów DevOps,...</p>
<p>Artykuł <a href="https://sekurak.pl/lastpass-atakujacy-zhackowali-komputer-jednego-z-naszych-pracownikow-zainstalowali-keyloggera-nowe-szczegoly-dotyczace-poprzedniego-ataku/" rel="nofollow">LastPass: &#8222;atakujący zhackowali komputer jednego z naszych pracowników, zainstalowali keyloggera&#8221; [nowe szczegóły dotyczące poprzedniego ataku]</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

