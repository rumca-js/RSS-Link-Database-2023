# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## NX: The Bizarre Feud Over What the Switch Could Be
 - [https://www.youtube.com/watch?v=KGi2tKNdydo](https://www.youtube.com/watch?v=KGi2tKNdydo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2023-02-28 21:00:16+00:00

The first 100 people to use code KNOWLEDGEHUSK at the link below will get 20% off of Incogni: https://incogni.com/knowledgehusk



This is a story about internet arguments. About Nintendo. About people arguing about Nintendo.

The Nintendo Switch is a pretty well known thing today, but years ago, a lot of people spent a lot of time arguing about what it might be.

Today I’m gonna talk about it.

Patreon:
https://www.patreon.com/theknowledgehub

Soundcloud:
https://soundcloud.com/user-503704039


Timestamps

0:00 Sponsor
1:28 NX

