# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## What Is Erythritol (and How Bad Is It for You)?
 - [https://lifehacker.com/what-is-erythritol-and-how-bad-is-it-for-you-1850170222](https://lifehacker.com/what-is-erythritol-and-how-bad-is-it-for-you-1850170222)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 23:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Mk6gxHRn--/c_fit,fl_progressive,q_80,w_636/28eab59bc2dd1af460bff45373587a72.jpg" /><p>A <a href="https://www.nature.com/articles/s41591-023-02223-9.epdf?sharing_token=tb2urRenOBAk2NpxokLz4dRgN0jAjWel9jnR3ZoTv0MTnVt_Yzm2YDkmKtSZJOysYZlROr0ymfAdj9yPHH8bMVWpKjhPzPeMT8zTG9DpNMmnfRfOqNqOH8PhwI2X9sxfHMa-Tpawl-dyIWq9WdTUO2lqDJWIHLoFK3aG5AGi1Ygkx9rtpSId-Z5OCLOxe08af2c3xD_BI2lGX5FYZgSWvw%3D%3D&amp;tracking_referrer=www.cnn.com" rel="noopener noreferrer" target="_blank">recent study</a> suggests that the sweetener erythritol, found in many foods, may put us more at risk for blood clots, and thus for heart attack and stroke. So what is erythritol, and what are the chances you ate something containing it today? I’ll explain.<br /></p><p><a href="https://lifehacker.com/what-is-erythritol-and-how-bad-is-it-for-you-1850170222">Read more...</a></p>

## What's New on Prime Video in March 2023
 - [https://lifehacker.com/whats-new-on-prime-video-in-march-2023-1850169834](https://lifehacker.com/whats-new-on-prime-video-in-march-2023-1850169834)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 22:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ZV27YX4G--/c_fit,fl_progressive,q_80,w_636/9532f8125cc206b5ee48b051271ef251.jpg" /><p>From<em> Hunters,</em> to<em> Paper Girls, </em>to <em>The Peripheral</em>—hell, arguably even<em> The Rings of Power</em>—Amazon seems determined to produce one quality show after another that they can dump a ton of money into and then abandon on the billion-dollar afterthought of Prime Video. Maybe that will change in March with the launch of three…</p><p><a href="https://lifehacker.com/whats-new-on-prime-video-in-march-2023-1850169834">Read more...</a></p>

## Get These Gift Card Deals While You Can
 - [https://lifehacker.com/get-these-gift-card-deals-while-you-can-1850168858](https://lifehacker.com/get-these-gift-card-deals-while-you-can-1850168858)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 22:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ybgIjOEG--/c_fit,fl_progressive,q_80,w_636/d89b0bc74cc33dda3d9dbd480864eaaa.jpg" /><p>Sometimes a deal can feel too good to pass up, and that can especially be the case with a gift card deal—particularly since <a href="https://www.fdic.gov/consumers/consumer/news/december2019.html#:~:text=Federal%20Law%20Offers%20Protections&amp;text=Under%20the%20law%2C%20a%20gift,places%20general%20limitations%20on%20fees." rel="noopener noreferrer" target="_blank">federal law</a> gives you five years from the date a gift card is activated to use it before it expires. If you’ve got a purchase planned in the semi-near future for places like Apple, Nintendo, GAP…</p><p><a href="https://lifehacker.com/get-these-gift-card-deals-while-you-can-1850168858">Read more...</a></p>

## What's New on Hulu in March 2023
 - [https://lifehacker.com/whats-new-on-hulu-in-march-2023-1850169381](https://lifehacker.com/whats-new-on-hulu-in-march-2023-1850169381)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--m1ZHdUHc--/c_fit,fl_progressive,q_80,w_636/e6b8afc92f591b947b97a6f15d6d29d4.jpg" /><p>Hulu continues its quest to uproot HBO Max as the best streaming service with an eclectic bunch of new series and movies coming in March. It’s become the “adult” repository for all of the content that doesn’t fit on the family-friendly Disney+, as well as a bunch of great FX series and a good number of original films…</p><p><a href="https://lifehacker.com/whats-new-on-hulu-in-march-2023-1850169381">Read more...</a></p>

## You Can Finally Search for Comments in Reddit Threads
 - [https://lifehacker.com/you-can-finally-search-for-comments-in-reddit-threads-1850168769](https://lifehacker.com/you-can-finally-search-for-comments-in-reddit-threads-1850168769)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--IOADRsY---/c_fit,fl_progressive,q_80,w_636/bc9fb9d62de58c7bc8cb4e8e8dd4381f.png" /><p>In April 2022, <a href="https://www.reddit.com/r/reddit/comments/u3oz2x/whats_up_with_reddit_search_episode_vi_retrieve/" rel="noopener noreferrer" target="_blank">Reddit added the ability to search for comments on desktop</a>. The feature was so popular, <a href="https://www.reddit.com/r/reddit/comments/wg6oqb/whats_up_with_reddit_search_episode_vii_the/" rel="noopener noreferrer" target="_blank">they quickly added it to their iOS and Android apps as well</a>. It was a long time coming: The change allows you to search comments across Reddit’s entire catalog of discussions, increasing the chances you’ll find…</p><p><a href="https://lifehacker.com/you-can-finally-search-for-comments-in-reddit-threads-1850168769">Read more...</a></p>

## 9 Extremely Niche (but Still Useful) Mobile Apps
 - [https://lifehacker.com/9-extremely-niche-but-still-useful-mobile-apps-1850168829](https://lifehacker.com/9-extremely-niche-but-still-useful-mobile-apps-1850168829)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ZCV8cd-j--/c_fit,fl_progressive,q_80,w_636/66dce3f4ca3122645fd4728ea007ddac.jpg" /><p>“Not everything is for everyone, but almost everything is for someone,” Abraham Lincoln once said, probably, and these nine mobile apps prove him right. They each do one  specific thing, and most of them will be useful to only one specific kind of person.<br /></p><p><a href="https://lifehacker.com/9-extremely-niche-but-still-useful-mobile-apps-1850168829">Read more...</a></p>

## The Best Grocery Store Apps for Every Need
 - [https://lifehacker.com/the-best-grocery-store-apps-for-every-need-1850168630](https://lifehacker.com/the-best-grocery-store-apps-for-every-need-1850168630)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WkEGg7j0--/c_fit,fl_progressive,q_80,w_636/66382537b03bee4f4bf632d3c1595e8c.jpg" /><p>Making a grocery list seems simple enough. People have been doing it for generations—you simply write down what you need, and take the paper with you to the store. The thing is, there are a lot of ways this can go wrong: When you’re in the living room finishing a snack on a cozy night, are you really going to shed…</p><p><a href="https://lifehacker.com/the-best-grocery-store-apps-for-every-need-1850168630">Read more...</a></p>

## 10 Professional Baking Tools I Use at Home
 - [https://lifehacker.com/10-professional-baking-tools-i-use-at-home-1850168766](https://lifehacker.com/10-professional-baking-tools-i-use-at-home-1850168766)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--FYEnaheO--/c_fit,fl_progressive,q_80,w_636/2c49de64c1cdc4f8c9c2908f50736f4c.jpg" /><p>In a professional bakery kitchen, you’ll see plenty of multi-purpose tools in action, and cabinets full of gadgets that are equally believable as scalp massagers or torture devices. Although there’s a time and use for all of those utensils, in my home kitchen I ditch the docking roller for a fork. You do not, however,…</p><p><a href="https://lifehacker.com/10-professional-baking-tools-i-use-at-home-1850168766">Read more...</a></p>

## Stop Using Cheap Plastic Drywall Anchors
 - [https://lifehacker.com/stop-using-cheap-plastic-drywall-anchors-1850168414](https://lifehacker.com/stop-using-cheap-plastic-drywall-anchors-1850168414)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--7VwOIfbs--/c_fit,fl_progressive,q_80,w_636/efafaf823987bf0523559ccc26d7e006.jpg" /><p>Even if you’re not handy, there are certain universal projects that just about everyone tackles at some point in their lives, like hanging a towel rack or a shelf on the wall. And trying to <a href="https://lifehacker.com/how-to-hang-pictures-without-destroying-your-walls-5829198">hang stuff on your walls</a> leads to a crucial lesson: Drywall absolutely sucks when it comes to supporting weight.<br /></p><p><a href="https://lifehacker.com/stop-using-cheap-plastic-drywall-anchors-1850168414">Read more...</a></p>

## Don’t Trust Your iPhone’s Passcode to Keep Your Data Safe
 - [https://lifehacker.com/don-t-trust-your-iphone-s-passcode-to-keep-your-data-sa-1850166806](https://lifehacker.com/don-t-trust-your-iphone-s-passcode-to-keep-your-data-sa-1850166806)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--PBk0ndsw--/c_fit,fl_progressive,q_80,w_636/63cfe334989be2647629942ff14f782b.jpg" /><p>Losing your iPhone is bad. Losing your entire digital life, from photos to finances, is traumatic. Unfortunately, the latter is all too common. Journalist Joanna Stern <a href="https://www.wsj.com/articles/apple-iphone-security-theft-passcode-data-privacya-basic-iphone-feature-helps-criminals-steal-your-digital-life-cbf14b1a" rel="noopener noreferrer" target="_blank">recently published a report with The Wall Street Journal</a> detailing how thieves in places like New York aren’t just stealing iPhones, but every valuable…</p><p><a href="https://lifehacker.com/don-t-trust-your-iphone-s-passcode-to-keep-your-data-sa-1850166806">Read more...</a></p>

## Use ‘Hydro-Dipping’ to Give Anything a Faux Marble Finish
 - [https://lifehacker.com/use-hydro-dipping-to-give-anything-a-faux-marble-fini-1850168235](https://lifehacker.com/use-hydro-dipping-to-give-anything-a-faux-marble-fini-1850168235)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--plNnOIpS--/c_fit,fl_progressive,q_80,w_636/9ad00e17950878b0a4386ba365edfac7.jpg" /><p>Sometimes an old piece of glassware or plant pot simply needs a refresh, or you might have a thrifted item that doesn’t quite go with your decor. Refinishing can be a hassle, especially with ceramic and glassware—but there’s a way to use a bucket of water and some paint to make your old things look fresh again, with a…</p><p><a href="https://lifehacker.com/use-hydro-dipping-to-give-anything-a-faux-marble-fini-1850168235">Read more...</a></p>

## That ‘Compliment’ Might Actually Be Offensive
 - [https://lifehacker.com/that-compliment-might-actually-be-offensive-1850165585](https://lifehacker.com/that-compliment-might-actually-be-offensive-1850165585)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Xo5QxkSZ--/c_fit,fl_progressive,q_80,w_636/c8fedb1957ce1d168bfe12ebb8af6087.jpg" /><p>Compliments (usually) feel good. They can reflect appreciation and value, help build and boost self-esteem, encourage positive behavior, and help create a positive environment. However, even if a compliment is well-intentioned, it can easily fall flat. On the extreme end, it also has the potential to cross lines in…</p><p><a href="https://lifehacker.com/that-compliment-might-actually-be-offensive-1850165585">Read more...</a></p>

## What to Do When You Can Smell Layoffs Coming
 - [https://lifehacker.com/what-to-do-when-you-can-smell-layoffs-coming-1850162589](https://lifehacker.com/what-to-do-when-you-can-smell-layoffs-coming-1850162589)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--3eihzcQA--/c_fit,fl_progressive,q_80,w_636/edbc44538df98ecafeb618abccc3cd81.png" /><p>It’s been <a href="https://thehill.com/homenews/nexstar_media_wire/3867925-layoffs-but-low-unemployment-what-is-going-on-in-this-strange-economy/" rel="noopener noreferrer" target="_blank">a hell of a layoffs season</a>. With this <a href="https://lifehacker.com/how-to-calculate-the-real-unemployment-rate-and-why-it-1849447911">uncertainty in the labor market</a>—not to mention the bigger picture of a <a href="https://lifehacker.com/what-you-should-do-now-to-prepare-for-a-recession-1849129353">looming recession</a>—it’s natural to feel a sense of helplessness. You can’t live in a constant state of paranoia, but <a href="https://lifehacker.com/how-to-tell-youre-about-to-be-laid-off-1849150165">it helps to be on the lookout</a> for some signs that layoffs are coming to your office.…</p><p><a href="https://lifehacker.com/what-to-do-when-you-can-smell-layoffs-coming-1850162589">Read more...</a></p>

## How to Get Off a Scammer's 'Sucker List'
 - [https://lifehacker.com/how-to-get-off-a-scammers-sucker-list-1850166269](https://lifehacker.com/how-to-get-off-a-scammers-sucker-list-1850166269)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WAZ6OYGX--/c_fit,fl_progressive,q_80,w_636/1cf9d481e07b60c73dd058b52359e4ef.png" /><p>It’s probably not just a feeling you have: Some people really do get way more spam calls, emails, and texts than others. For every fake McAfee order email your friend gets, you get three missives from African, Swedish, Jordanian, and Australian princes trying to take your money—plus two fake package tracking texts and…</p><p><a href="https://lifehacker.com/how-to-get-off-a-scammers-sucker-list-1850166269">Read more...</a></p>

## How to Tell If Your Cat's Teeth Are Hurting
 - [https://lifehacker.com/how-to-tell-if-your-cats-teeth-are-hurting-1850166169](https://lifehacker.com/how-to-tell-if-your-cats-teeth-are-hurting-1850166169)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Eaqp1XjM--/c_fit,fl_progressive,q_80,w_636/f244ee8425f8376bc01e8539590dd45e.jpg" /><p>Maintaining healthy teeth is obviously important for us, but the same is also true for our cats. Although we may not think about a cat’s dental health quite as often as ours—and attempting to brush their teeth can be its own battle—cats can develop their own dental issues, including abscessed teeth, gingivitis, or a…</p><p><a href="https://lifehacker.com/how-to-tell-if-your-cats-teeth-are-hurting-1850166169">Read more...</a></p>

## The Best (and Most Affordable) Way to Store Old Video Games
 - [https://lifehacker.com/the-best-and-most-affordable-way-to-store-old-video-g-1850166193](https://lifehacker.com/the-best-and-most-affordable-way-to-store-old-video-g-1850166193)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--BiU4_6g9--/c_fit,fl_progressive,q_80,w_636/315dffa091697f41ff9e334e36752602.jpg" /><p>If you collect video games, or are holding onto a batch of your childhood favorites, chances are you have more than a few loose carts and discs in your collection. Many retro games came in flimsy cardboard boxes, and I’m willing to bet I wasn’t the only person whose family got rid of game cases in favor of those giant…</p><p><a href="https://lifehacker.com/the-best-and-most-affordable-way-to-store-old-video-g-1850166193">Read more...</a></p>

## Find a Relationship by 'Home Depot Dating'
 - [https://lifehacker.com/find-a-relationship-by-home-depot-dating-1850165628](https://lifehacker.com/find-a-relationship-by-home-depot-dating-1850165628)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--YYAu1lS4--/c_fit,fl_progressive,q_80,w_636/bda386739f34765ea6609bf8695709c8.jpg" /><p>Is it possible to go shopping for a life partner? According to the latest TikTok trend, it might just be: “<a href="https://www.tiktok.com/tag/homedepotdating" rel="noopener noreferrer" target="_blank">Home Depot dating</a>,” which has racked up more than 6 million views on the social media app, first started as videos of single women looking for eligible bachelors among the hammers, paints, and screwdrivers in the…</p><p><a href="https://lifehacker.com/find-a-relationship-by-home-depot-dating-1850165628">Read more...</a></p>

## Make Easier Mashed Potatoes With a Cooling Rack
 - [https://lifehacker.com/make-easier-mashed-potatoes-with-a-cooling-rack-1850165708](https://lifehacker.com/make-easier-mashed-potatoes-with-a-cooling-rack-1850165708)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--U2MMEQSV--/c_fit,fl_progressive,q_80,w_636/309483ea2d6da4e7ee155e15796c46a0.jpg" /><p>I do not own a potato masher. I own a potato ricer, because it’s better at its job. Rather than chasing potatoes around the pot with a masher, I push them through the ricer, extruding them into tiny little bits that can be gently stirred into warmed dairy, reducing the amount of mashing needed, which keeps the…</p><p><a href="https://lifehacker.com/make-easier-mashed-potatoes-with-a-cooling-rack-1850165708">Read more...</a></p>

## 11 Ways to Make a Frozen Pizza Less Sad
 - [https://lifehacker.com/11-ways-to-make-a-frozen-pizza-less-sad-1850158066](https://lifehacker.com/11-ways-to-make-a-frozen-pizza-less-sad-1850158066)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-02-28 14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--uJdaX0o4--/c_fit,fl_progressive,q_80,w_636/1b16d402e213d705f2acca5342730957.jpg" /><p>Eating a frozen pizza for supper can feel a little like giving up, but you can’t deny the convenience factor, nor the nostalgic, juvenile appeal. It is, after all, still pizza. <br /><br />I would never judge or belittle someone for enjoying their freezer pizza au naturel, but a little adornment can do wonders for them. Here are…</p><p><a href="https://lifehacker.com/11-ways-to-make-a-frozen-pizza-less-sad-1850158066">Read more...</a></p>

