# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## We need checkmarks for Floatplane, NOW
 - [https://www.youtube.com/watch?v=bGeL6YUwqCY](https://www.youtube.com/watch?v=bGeL6YUwqCY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-02-28 19:48:39+00:00

There's Twitter Blue, and Meta Verified - it's time for Floatplane to get on the blue tick train.

Watch the full WAN Show: https://www.youtube.com/watch?v=_FqH1rqQrQg

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

## Linus Rage Quits
 - [https://www.youtube.com/watch?v=05VL6KBR0Jo](https://www.youtube.com/watch?v=05VL6KBR0Jo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-02-28 18:08:58+00:00

What would make Linus give up on a game 30 hours in?

Watch the full WAN Show: https://www.youtube.com/watch?v=_FqH1rqQrQg

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

## Pay Up, Hosers
 - [https://www.youtube.com/watch?v=AQSXkEnBX6k](https://www.youtube.com/watch?v=AQSXkEnBX6k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-02-28 18:04:37+00:00

Canada wants Google and Meta to pay to link to Canadian news. 

Watch the full WAN Show: https://www.youtube.com/watch?v=_FqH1rqQrQg

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

## Never Build a PC for Family
 - [https://www.youtube.com/watch?v=B73K3vxfsP8](https://www.youtube.com/watch?v=B73K3vxfsP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-02-28 17:48:46+00:00

Linus and Luke discuss the frustration of building a PC as a favour and becoming “forever tech support.”

Watch the full WAN Show: https://www.youtube.com/watch?v=_FqH1rqQrQg

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

## $144 for Facebook
 - [https://www.youtube.com/watch?v=fMg6m6KwUoQ](https://www.youtube.com/watch?v=fMg6m6KwUoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-02-28 02:00:12+00:00

test

## Joining the Console Master Race
 - [https://www.youtube.com/watch?v=COhpgVa9tJQ](https://www.youtube.com/watch?v=COhpgVa9tJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-02-28 02:00:02+00:00

Note: I flubbed one of the specs of the Quest 2. It has physical IPD adjustments. I was thinking of the Rift S. My bad! - LS

The PSVR2 has arrived and is a far step beyond its predecessor.

Watch the full WAN Show: https://www.youtube.com/watch?v=_FqH1rqQrQg

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

