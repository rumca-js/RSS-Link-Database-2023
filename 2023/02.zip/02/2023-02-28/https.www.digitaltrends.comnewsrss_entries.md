# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## This AMD GPU from 2021 beats the RX 7900 XTX and the RTX 4080
 - [https://www.digitaltrends.com/computing/amd-radeon-pro-w6800x-duo-beats-current-gen/](https://www.digitaltrends.com/computing/amd-radeon-pro-w6800x-duo-beats-current-gen/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2023-02-28 14:23:06.896510+00:00

Thanks to a few clever modifications, an AMD card built for Apple computers was able to run and be benchmarked -- with outstanding results.

