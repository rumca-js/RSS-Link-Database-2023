# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Fusion Energy: Hype or The Future?
 - [https://www.youtube.com/watch?v=ouecRm8cCoY](https://www.youtube.com/watch?v=ouecRm8cCoY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2023-02-28 18:07:34+00:00

In this episode we take a look at the good the bad and the ugly of fusion energy. Is it as promised? And if not, what are the major issues?

Animator: @then what happens

ColdFusion Podcast: 

https://www.youtube.com/watch?v=fS8pAPN9Er0 

First Song: 

https://youtu.be/IECITKmNnzM

Last Song: 

https://youtu.be/X3Sh_EPtgys

ColdFusion Music: 

https://www.youtube.com/@burnwatermusic7421 
http://burnwater.bandcamp.com   

Real Engineering Video: https://youtu.be/_bDXXWQxK38

Get my book: 

http://bit.ly/NewThinkingbook 

ColdFusion Socials: 

https://discord.gg/coldfusion
https://facebook.com/ColdFusionTV 
https://twitter.com/ColdFusion_TV 
https://instagram.com/coldfusiontv

Producer: Dagogo Altraide
Editor: Tanzim Uddin

