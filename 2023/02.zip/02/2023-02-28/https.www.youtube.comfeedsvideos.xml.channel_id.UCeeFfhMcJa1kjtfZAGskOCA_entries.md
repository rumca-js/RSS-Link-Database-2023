# Source:Techlinked, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCeeFfhMcJa1kjtfZAGskOCA, language:en-US

## AMD is BACK BIG TIME
 - [https://www.youtube.com/watch?v=5jejoohQBm8](https://www.youtube.com/watch?v=5jejoohQBm8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCeeFfhMcJa1kjtfZAGskOCA
 - date published: 2023-02-28 02:43:46+00:00

Add Kudos for free today ▸ https://joinkudos.com/techlinked
Enter code “TECHLINKED” for a chance to receive a LTT screwdriver!

►► LISTEN TO THE TECH NEWS: https://lmg.gg/TechLinkedPodcast

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners

NEWS SOURCES: https://lmg.gg/QLPWE
---------------------------------------------------
Timestamps:
0:00 say HELLO to him
0:03 Ryzen 9 7950X3D, fastest gaming processor
1:26 Android/iOS passcode flaw
3:01 Unsupported PCs pushed to W11
4:23 Kudos
5:16 QUICK BITS
5:26 Google employees sharing desks
6:06 Nokia G22 completely repairable
6:44 Snapchat ChatGPT chatbot
7:23 Xiaomi Wireless AR Glass
8:05 Pokemon Sleep

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: http://twitter.com/TechLinkedYT
Instagram: http://instagram.com/TechLinkedYT
Facebook: http://facebook.com/TechLinked

