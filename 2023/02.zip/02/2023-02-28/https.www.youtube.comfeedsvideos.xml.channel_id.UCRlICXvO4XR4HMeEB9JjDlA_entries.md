# Source:Thoughy2, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA, language:en-US

## The Bizarre Time NASA Made Dolphin Porn
 - [https://www.youtube.com/watch?v=qz15mgIBN7g](https://www.youtube.com/watch?v=qz15mgIBN7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA
 - date published: 2023-02-28 15:06:59+00:00

Learn more than ever from important non-fiction books at https://shortform.com/thoughty2 and receive 5-days of unlimited access and an additional 20% discount on the annual subscription.


Thoughty2 Audiobook: https://geni.us/t2audio
Thoughty2 Book: https://geni.us/t2book
Support Me & Get Early Access: http://bit.ly/t2club
Thoughty2 Merchandise: https://bit.ly/t2merch

Follow Thoughty2
Facebook: https://facebook.com/thoughty2
Instagram: https://instagram.com/thoughty2
Website: http://thoughty2.com

About Thoughty2
Thoughty2 (Arran) is a British YouTuber and gatekeeper of useless facts. Thoughty2 creates mind-blowing factual videos about science, tech, history, opinion and just about everything else.
#Thoughty2

Writing: Steven Rix
Editing: Jack Stevens

