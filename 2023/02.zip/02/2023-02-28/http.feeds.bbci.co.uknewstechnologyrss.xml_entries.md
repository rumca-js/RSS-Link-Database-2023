# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## FTX's Nishad Singh pleads guilty to fraud charges
 - [https://www.bbc.co.uk/news/business-64803468?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64803468?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-02-28 19:24:11+00:00

Former FTX engineer says he is 'unbelievably sorry' for his role in the alleged crypto scheme.

## The tiny diamond sphere that could unlock clean power
 - [https://www.bbc.co.uk/news/business-64553796?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64553796?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-02-28 00:00:32+00:00

A diamond sphere made in Germany was key to December's breakthrough fusion experiment in California.

