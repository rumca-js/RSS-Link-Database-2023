# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## ‘I Saw Jonathan Frakes Giving Patrick Stewart a Noogie’
 - [https://gizmodo.com/i-saw-jonathan-frakes-giving-patrick-stewart-a-noogie-1850167321](https://gizmodo.com/i-saw-jonathan-frakes-giving-patrick-stewart-a-noogie-1850167321)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 23:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--aLfxYARz--/c_fit,fl_progressive,q_80,w_636/ccf0cfc2b2ac8583f5372f64926c785c.jpg" /><p><a href="https://gizmodo.com/i-saw-jonathan-frakes-giving-patrick-stewart-a-noogie-1850167321">Read more...</a></p>

## Rupert Murdoch Said Fox News Was Seeing ‘Green’ During Stop the Steal, and More Revelations
 - [https://gizmodo.com/rupert-murdoch-fox-news-trump-dominion-voting-1850170272](https://gizmodo.com/rupert-murdoch-fox-news-trump-dominion-voting-1850170272)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 22:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--HIiOZ5Ui--/c_fit,fl_progressive,q_80,w_636/095e738dd3c65bc27b597b6986623740.jpg" /><p>Billionaire Fox Corporation Chair Rupert Murdoch thought all the noise spewed by former President Donald Trump during his “stop the steal” hoax was “bullshit and damaging.” However, the thought of curbing the spread of an incredibly dangerous conspiracy wasn’t at the top of his mind back then. He was focused on…</p><p><a href="https://gizmodo.com/rupert-murdoch-fox-news-trump-dominion-voting-1850170272">Read more...</a></p>

## AMD's Top of the Stack 3D V-Cache CPU Pushes Even the RTX 3090 to Its Limits
 - [https://gizmodo.com/amd-ryzen-7950x3d-cpu-review-3d-v-cache-gaming-pc-chip-1850170448](https://gizmodo.com/amd-ryzen-7950x3d-cpu-review-3d-v-cache-gaming-pc-chip-1850170448)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 22:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--L13DrZj---/c_fit,fl_progressive,q_80,w_636/42bbe8ab18b1081c8e9e413484a1cab2.png" /><p>Saying that it has been a busy launch season for AMD is an incredible understatement. Not only did we see the release of the high powered, high performing <a href="https://gizmodo.com/amd-ryzen-7700x-7900x-review-zen-4-mid-range-benchmarks-1849579076">Ryzen 7000X Series</a>, but we also got a full stack of lower powered, but still respectably performant processors in the <a href="https://gizmodo.com/amd-65-w-non-x-ryzen-5-7-9-cpus-zen-4-chips-review-pc-1849964203">Ryzen 7000 Non-X Series</a>. And let’s not forget…</p><p><a href="https://gizmodo.com/amd-ryzen-7950x3d-cpu-review-3d-v-cache-gaming-pc-chip-1850170448">Read more...</a></p>

## The Mandalorian’s New Ship Makes No Sense
 - [https://gizmodo.com/mandalorian-season-3-new-star-wars-ship-disney-1850168556](https://gizmodo.com/mandalorian-season-3-new-star-wars-ship-disney-1850168556)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 22:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--hu1YG725--/c_fit,fl_progressive,q_80,w_636/a9f7430b9c0acf342963e83aec6b1710.jpg" /><p>Dij Djarin’s instantly iconic starship the <a href="https://gizmodo.com/mandalorian-razor-crest-lego-ultimate-collector-set-1849580549"><em>Razor Crest</em></a><em> </em>was destroyed in the second to last episode of <a href="https://gizmodo.com/the-mandalorian-finale-just-expanded-star-wars-streamin-1845911817"><em>The Mandalorian</em>’s second season</a>. It was a bummer, because it was such a cool, fresh, and unique design that seemed to match the title character’s whole vibe perfectly. Obviously, Din was going to need a…</p><p><a href="https://gizmodo.com/mandalorian-season-3-new-star-wars-ship-disney-1850168556">Read more...</a></p>

## Jack Dorsey’s New 'Decentralized' Twitter Hits the App Store
 - [https://gizmodo.com/jack-dorsey-twitter-bluesky-social-media-elon-musk-1850170011](https://gizmodo.com/jack-dorsey-twitter-bluesky-social-media-elon-musk-1850170011)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 22:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ZVM4xdJz--/c_fit,fl_progressive,q_80,w_636/419b6a0b7dff86b7ab8c0e7f35b2b33d.jpg" /><p>Twitter users could have the chance to pivot to an upcoming rival social media app, <a href="https://gizmodo.com/jack-dorsey-bluesky-twitter-social-media-1849676675">Bluesky</a>, which launched its Beta test on Apple’s app store Tuesday. Former Twitter CEO and founder Jack Dorsey is the mastermind behind Bluesky, which he announced he would be focusing on after <a href="https://gizmodo.com/elon-musk-twitter-takeover-chaos-explained-1849768358">Elon Musk bought Twitter for $44 billion</a>…</p><p><a href="https://gizmodo.com/jack-dorsey-twitter-bluesky-social-media-elon-musk-1850170011">Read more...</a></p>

## The iPhone 15's USB-C Port Might Need Special Cables For Full Functionality
 - [https://gizmodo.com/apple-iphone-15-usb-c-mfi-cable-charging-data-speed-1850170096](https://gizmodo.com/apple-iphone-15-usb-c-mfi-cable-charging-data-speed-1850170096)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 22:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--grimpTfd--/c_fit,fl_progressive,q_80,w_636/f4bdbfa9bdfd09bbad700f76e80fd137.jpg" /><p>Leave it to Apple to comply with the EU’s <a href="https://gizmodo.com/iphones-androids-usb-c-lightning-ports-2024-europe-deal-1849027963">USB-C mandate</a>, only to find a way to keep its tech proprietary. There’s a report from a noted leaker that while the iPhone 15 will have a USB-C port, it will rely on the MFi certification for full capability. That means non-certified cables and power adapters will likely face…</p><p><a href="https://gizmodo.com/apple-iphone-15-usb-c-mfi-cable-charging-data-speed-1850170096">Read more...</a></p>

## 56 New Sci-Fi, Horror, and Fantasy Books Coming Your Way in March
 - [https://gizmodo.com/56-new-scifi-fantasy-horror-books-march-victor-lavalle-1850053585](https://gizmodo.com/56-new-scifi-fantasy-horror-books-march-victor-lavalle-1850053585)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--uuPOyBDI--/c_fit,fl_progressive,q_80,w_636/7ebd359a0b22e624abf3d00a9fe3f946.jpg" /><p>This month, we’ve got new releases from <a href="https://gizmodo.com/the-girl-with-all-the-gifts-author-m-r-carey-has-a-new-1838643505">M.R. Carey</a> <em>(<a href="https://gizmodo.com/movie-review-the-girl-with-all-the-gifts-has-joined-th-1787137939">The Girl With All the Gifts</a>)</em> and <a href="https://gizmodo.com/victor-lavalle-on-destroyer-a-modern-comic-book-sequel-1794799203">Victor LaValle</a> <em>(<a href="https://gizmodo.com/the-ballad-of-black-toms-a-spellbinding-horror-to-revis-1844421990">The Ballad of Black Tom</a>, The Changeling)</em>, as well as a whole bunch of others, featuring rebellious royals, time-travelers, time-loop travelers, space adventurers, monsters, witches, and so much more.</p><p><a href="https://gizmodo.com/56-new-scifi-fantasy-horror-books-march-victor-lavalle-1850053585">Read more...</a></p>

## Dish Network Confirms Hack Following Chaotic Multi-Day Outage
 - [https://gizmodo.com/dish-network-boost-mobile-hack-sling-tv-1850169814](https://gizmodo.com/dish-network-boost-mobile-hack-sling-tv-1850169814)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 21:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--gB2BUy4S--/c_fit,fl_progressive,q_80,w_636/8bd68c506292361b86e5202410bdba83.jpg" /><p>Dish Network, the television provider and satellite/telecoms company, has been hacked, according to <a href="https://www.dish.com/statement" rel="noopener noreferrer" target="_blank">a statement</a> published Tuesday on its website. Dish— <a href="https://gizmodo.com/dish-aims-to-become-fourth-biggest-wireless-carrier-now-1844238071">which owns Boost Mobile</a>, <a href="https://gizmodo.com/sling-tv-prices-are-going-up-now-too-1846142080">Sling TV</a>, and, weirdly, the <a href="https://gizmodo.com/dish-networks-new-blockbuster-streaming-service-offers-5843280">last remaining scraps of Blockbuster</a>, among other subsidiaries—has been experiencing significant disruption since…</p><p><a href="https://gizmodo.com/dish-network-boost-mobile-hack-sling-tv-1850169814">Read more...</a></p>

## NASA's Water-Probing Satellite Appears to Be In Trouble
 - [https://gizmodo.com/nasa-water-probing-swot-satellite-trouble-1850169531](https://gizmodo.com/nasa-water-probing-swot-satellite-trouble-1850169531)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 21:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--TkPlb6bZ--/c_fit,fl_progressive,q_80,w_636/7fbec05be370eb8e2ca2a3f44c6dce8d.jpg" /><p>NASA Engineers are racing to fix a worrying glitch with a recently launched water satellite, hoping to get the <a href="https://gizmodo.com/swot-water-satellite-nasa-oceans-drought-science-1849787118">Surface Water and Ocean Topography (SWOT) mission</a> up and running so that it can start surveying our planet’s oceans, lakes, and rivers.</p><p><a href="https://gizmodo.com/nasa-water-probing-swot-satellite-trouble-1850169531">Read more...</a></p>

## Another Round Of Winter Weather Dropped Snow From Coast to Coast
 - [https://gizmodo.com/another-round-of-winter-weather-dropped-snow-from-coast-1850168153](https://gizmodo.com/another-round-of-winter-weather-dropped-snow-from-coast-1850168153)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--5_fH3iY---/c_fit,fl_progressive,q_80,w_636/27f99d915d391807167522f745076e7f.jpg" /><p>Winter weather hit both coasts over the last few days, dropping snow over California and across the Northeast. Cities around the country experienced power outages and massive transit headaches. And there’s more to come.</p><p><a href="https://gizmodo.com/another-round-of-winter-weather-dropped-snow-from-coast-1850168153">Read more...</a></p>

## Ford Tries to Patent a Dystopian Future Where Self-Driving Cars Repo Themselves
 - [https://gizmodo.com/ford-self-driving-repo-autonomous-vehicle-1850168765](https://gizmodo.com/ford-self-driving-repo-autonomous-vehicle-1850168765)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 20:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--rclhvAzz--/c_fit,fl_progressive,q_80,w_636/93879520e134b61a4aa7d270a2b1749e.png" /><p>Car companies often talk about autonomous vehicles as an avenue towards increased freedom—enabling more people to access roadways and giving drivers back their time and attention. But at least one auto giant is considering alternate (and darker) uses of still-elusive self-driving technology.<br /></p><p><a href="https://gizmodo.com/ford-self-driving-repo-autonomous-vehicle-1850168765">Read more...</a></p>

## On The Mandalorian, Way More Time Has Passed Than You Think
 - [https://gizmodo.com/mandalorian-star-wars-timeline-luke-skywalker-grogu-1850169197](https://gizmodo.com/mandalorian-star-wars-timeline-luke-skywalker-grogu-1850169197)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 20:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--cxwNOWCL--/c_fit,fl_progressive,q_80,w_636/e4b2d2d0635d5089e613b8d92850d3a7.jpg" /><p>Time in <em>Star Wars</em> is rarely a cut and dried thing. Even from its legendary opener of “A long time ago in a galaxy far, far away,” specifics can be rather vague. That’s not the case, though, when you’re telling stories between other stories. <a href="https://gizmodo.com/star-wars-clone-wars-movie-io9-review-retro-1849822103"><em>The Clone Wars</em></a> had to meet up with <em>Revenge of the Sith</em>. We know how <em>Andor</em> <a href="https://gizmodo.com/rogue-one-remembered-a-timeline-for-its-5-year-anniver-1848227859">is…</a></p><p><a href="https://gizmodo.com/mandalorian-star-wars-timeline-luke-skywalker-grogu-1850169197">Read more...</a></p>

## Thrilling Images Show First Launch of SpaceX's Revamped Starlink Satellites
 - [https://gizmodo.com/images-show-first-launch-spacex-revamped-starlinks-1850168089](https://gizmodo.com/images-show-first-launch-spacex-revamped-starlinks-1850168089)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 20:35:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--Qu_jlU4R--/c_fit,fl_progressive,q_80,w_636/fdd7d8e1abc9f1391f42f1cbcc77257b.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--B-YY4_hz--/c_fit,fl_progressive,q_80,w_636/fdd7d8e1abc9f1391f42f1cbcc77257b.mp4" type="video/mp4" /></video><p>SpaceX successfully deployed the first batch of its <a href="https://gizmodo.com/spacex-shows-off-new-starlink-v2-mini-satellites-1850162783">next-generation Starlink satellites</a>, which the company hopes will increase the broadband capacity of its internet megaconstellation.</p><p><a href="https://gizmodo.com/images-show-first-launch-spacex-revamped-starlinks-1850168089">Read more...</a></p>

## We're the U.S. Marshals and We're Here to Say, We Just Got Hacked in a Major Way
 - [https://gizmodo.com/us-marshals-hacked-ransomware-ongoing-investigations-1850168141](https://gizmodo.com/us-marshals-hacked-ransomware-ongoing-investigations-1850168141)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 20:28:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--GoRb8M2g--/c_fit,fl_progressive,q_80,w_636/9af38ad555f058a291810fbad962ca15.jpg" /><p>America’s oldest law enforcement agency, the U.S. Marshals Service, is in a bit of security trouble. The federal police agency had been targeted by ransomware hackers earlier this month in an episode that officials are saying involved  a significant amount of “sensitive” data, according to a statement. </p><p><a href="https://gizmodo.com/us-marshals-hacked-ransomware-ongoing-investigations-1850168141">Read more...</a></p>

## Record Number of Countries Blocked the Internet in Blackouts in 2022
 - [https://gizmodo.com/internet-access-blackout-censorship-india-1850169234](https://gizmodo.com/internet-access-blackout-censorship-india-1850169234)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 20:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--O74PP6MU--/c_fit,fl_progressive,q_80,w_636/56db79d9efd6e29cd91729fc9f0501c4.jpg" /><p>Governments in 35 countries shut down the internet for a record total of at least 185 times in 2022 alone, a new study shows. The New York-based watchdog group, Access Now, published the <a href="https://www.accessnow.org/cms/assets/uploads/2023/02/KeepItOn-2022-Report.pdf" rel="noopener noreferrer" target="_blank">report</a> on Tuesday noting that the rate of online shutdowns has not only skyrocketed but is lasting longer and are often targeting…</p><p><a href="https://gizmodo.com/internet-access-blackout-censorship-india-1850169234">Read more...</a></p>

## Ads in Audiobooks Is a Cursed Idea That Won't Go Away
 - [https://gizmodo.com/amazon-audible-ebook-library-digital-book-1850168978](https://gizmodo.com/amazon-audible-ebook-library-digital-book-1850168978)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Kx3gsyYF--/c_fit,fl_progressive,q_80,w_636/3a652b4c26e28681e80f9e83497b8bcf.jpg" /><p>Imagine you’re stuck in your daily commute and listening to a riveting audiobook, your mind far away and swimming with scenes of action and romance, only to be jettisoned back into reality when your listening is interrupted with an advertisement for, say, Pampers or Geico cutting in.</p><p><a href="https://gizmodo.com/amazon-audible-ebook-library-digital-book-1850168978">Read more...</a></p>

## Battle Chasers Is Coming Back for New Stories, Over 20 Years Later
 - [https://gizmodo.com/battle-chasers-10-release-date-preview-joe-madureira-1850168774](https://gizmodo.com/battle-chasers-10-release-date-preview-joe-madureira-1850168774)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--FYZbUx1v--/c_fit,fl_progressive,q_80,w_636/4f48fede0ece3da909b402c19804865e.png" /><p>Over two decades ago, <a href="https://gizmodo.com/in-comics-hellboy-meets-mutant-cows-and-everyone-want-5791227"><em>Battle Chasers</em></a>—<a href="https://gizmodo.com/a-chaotic-ranking-of-the-scarlet-witchs-comics-costumes-1842759068">Joe Madureira</a>’s “arcane punk” adventure series known for its <a href="https://gizmodo.com/10-of-the-most-maddening-delays-in-comics-history-1726666125">languid release pacing</a>—came to an end on a cliffhanger fans never got to see the conclusion of. Now, at long last, Madureira is finally delivering it.<br /></p><p><a href="https://gizmodo.com/battle-chasers-10-release-date-preview-joe-madureira-1850168774">Read more...</a></p>

## Samsung Patents Point to Potential Galaxy Ring and AR Galaxy Glasses
 - [https://gizmodo.com/samsung-galaxy-ring-glasses-patent-filing-wearable-ar-1850169168](https://gizmodo.com/samsung-galaxy-ring-glasses-patent-filing-wearable-ar-1850169168)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 19:55:08+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--f9eYi8Wq--/c_fit,fl_progressive,q_80,w_636/028b97bbbd18d42c9931c43800986d2d.jpg" /><p>A Samsung smart ring could be in the works, and I’m here for it. The company recently filed two new patents with the Korean Intellectual Property Right Information Services. The patents are labeled <a href="http://engdtj.kipris.or.kr/engdtj/grrt1000a.do?method=biblioTMFrame&amp;masterKey=4020230032679&amp;index=1&amp;kindOfReq=A&amp;valid_fg=&amp;rights=TM&amp;KeyWord=4020230032679&amp;applno=4020230032679&amp;Gubun=1&amp;sCurrPage=1&amp;searchFg=N&amp;expression=4020230032679&amp;openPageId=View01&amp;isMyConcern=N&amp;isMyFolder=N&amp;config=/main/sharePage_EN.jsp,%20className=jeus_jspwork._main._700_sharePage_5fEN_5fjsp,%20jspUri=%27/main/sharePage_EN.jsp" rel="noopener noreferrer" target="_blank">Galaxy Ring</a> and <a href="http://engdtj.kipris.or.kr/engdtj/grrt1000a.do?method=biblioTMFrame&amp;masterKey=4020230032297&amp;index=1&amp;kindOfReq=A&amp;valid_fg=&amp;rights=TM&amp;KeyWord=4020230032297&amp;applno=4020230032297&amp;Gubun=1&amp;sCurrPage=1&amp;searchFg=N&amp;expression=4020230032297&amp;openPageId=View01&amp;isMyConcern=N&amp;isMyFolder=N&amp;config=/main/sharePage_EN.jsp,%20className=jeus_jspwork._main._700_sharePage_5fEN_5fjsp,%20jspUri=%27/main/sharePage_EN.jsp" rel="noopener noreferrer" target="_blank">Galaxy Glasses</a>. Which means we might also see a pair of AR glasses, especially with the company’s <a href="https://www.samsung.com/nz/business/insights/demystifying-extended-reality-experiences-in-asia-pacific/" rel="noopener noreferrer" target="_blank">…</a></p><p><a href="https://gizmodo.com/samsung-galaxy-ring-glasses-patent-filing-wearable-ar-1850169168">Read more...</a></p>

## The Mandalorian's Dave Filoni and Jon Favreau Talk Luke, Boba, and Star Wars' Future
 - [https://gizmodo.com/mandalorian-jon-favreau-dave-filoni-star-wars-disney-pl-1850168239](https://gizmodo.com/mandalorian-jon-favreau-dave-filoni-star-wars-disney-pl-1850168239)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 19:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--riflqr3I--/c_fit,fl_progressive,q_80,w_636/5b8ad82de877b260efd2d4e28a004f8b.jpg" /><p>Though 2022 was filled with many <a href="https://gizmodo.com/star-wars-andor-diego-luna-disney-plus-lucasfilm-1849555939">fantastic</a> <em>Star Wars</em> <a href="https://gizmodo.com/obi-wan-kenobi-finale-ewan-mcgregor-darth-vader-luke-sk-1849092136">memories</a>, very few of those centered on the Mandalorian and Grogu. That changes this week with the season three premiere of <em>The Mandalorian,</em> which picks up both from the end of its second season, <a href="https://gizmodo.com/the-mandalorians-explosive-finale-blew-our-minds-and-im-1845912360">which was over two years ago</a>, as well as <em>The Book of Boba Fett</em>, in…</p><p><a href="https://gizmodo.com/mandalorian-jon-favreau-dave-filoni-star-wars-disney-pl-1850168239">Read more...</a></p>

## Prepare for Marvel's Multiverse Saga in a RSVLTS Iron Man Outfit
 - [https://gizmodo.com/marvel-iron-man-rsvlts-fashion-first-look-tony-stark-1850165981](https://gizmodo.com/marvel-iron-man-rsvlts-fashion-first-look-tony-stark-1850165981)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--u9nJzJOT--/c_fit,fl_progressive,q_80,w_636/2bfa9a7df05e83b61fc46664affde3be.jpg" /><p>There’s more to <a href="https://gizmodo.com/valentines-day-gift-guide-fandom-star-wars-marvel-dc-1850071423">fandom fashion</a> than plain black tees with screen prints—especially if you’re an Iron Man fan, thanks to this new line of <a href="https://www.rsvlts.com/" rel="noopener noreferrer" target="_blank">RSVLTS</a> button-down shirts paying tribute to <a href="https://gizmodo.com/tony-stark-was-right-about-something-for-once-1845134211">the Marvel hero</a>.</p><p><a href="https://gizmodo.com/marvel-iron-man-rsvlts-fashion-first-look-tony-stark-1850165981">Read more...</a></p>

## FTX's Nishad Singh Pleads Guilty to Fraud and Conspiracy Charges
 - [https://gizmodo.com/ftx-nishad-singh-sbf-crypto-sam-bankman-fried-1850168590](https://gizmodo.com/ftx-nishad-singh-sbf-crypto-sam-bankman-fried-1850168590)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 18:23:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--olO889O1--/c_fit,fl_progressive,q_80,w_636/8a208e9fe4745ac5c703de820c4b7bb4.jpg" /><p>While  <a href="https://gizmodo.com/ftx-crypto-sam-bankman-fried-binance-1849768382">FTX  collapsed</a> just a few months ago, the fallout of the defunct crypto exchange is still developing. Today, FTX’s former director of engineering Nishad Singh pleaded guilty to six counts of fraud and conspiracy as <a href="https://gizmodo.com/doj-sec-investigating-ftx-bitcoin-price-crypto-plunges-1849766102">court cases into FTX higher-ups</a> continue.<br /></p><p><a href="https://gizmodo.com/ftx-nishad-singh-sbf-crypto-sam-bankman-fried-1850168590">Read more...</a></p>

## Watch This Smartphone Fully Recharge in Just Five Minutes
 - [https://gizmodo.com/fast-charge-phone-xiaomi-mwc-mobile-world-congress-1850168187](https://gizmodo.com/fast-charge-phone-xiaomi-mwc-mobile-world-congress-1850168187)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 18:05:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--eIBAn_WX--/c_fit,fl_progressive,q_80,w_636/1e5198531ee9397d62af0edb1cc04711.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--ZCMLPd25--/c_fit,fl_progressive,q_80,w_636/1e5198531ee9397d62af0edb1cc04711.mp4" type="video/mp4" /></video><p>The easiest cure for smartphone battery anxiety isn’t to pair your svelte device with a chunky portable charger, but to fully capitalize on those times when you have access to a power outlet. As recently demonstrated on <a href="https://weibo.com/3021514657/Mv4ZUgVFN" rel="noopener noreferrer" target="_blank">Weibo</a>, the <a href="https://www.youtube.com/watch?v=D7rD-qs1oQk" rel="noopener noreferrer" target="_blank">Xiaomi Redmi Note 12 Pro+</a> does exactly that, <a href="https://www.forbes.com/sites/barrycollins/2023/02/28/the-phone-that-can-fully-charge-in-5-minutes/?sh=4d86f7315a6b" rel="noopener noreferrer" target="_blank">needing just five minutes</a> to fully…</p><p><a href="https://gizmodo.com/fast-charge-phone-xiaomi-mwc-mobile-world-congress-1850168187">Read more...</a></p>

## Michael B. Jordon on How Naruto Inspired Creed 3's Fight Scenes
 - [https://gizmodo.com/michael-b-jordan-jonathan-majors-creed-3-anime-naruto-1850167936](https://gizmodo.com/michael-b-jordan-jonathan-majors-creed-3-anime-naruto-1850167936)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 17:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--MVIpv4lS--/c_fit,fl_progressive,q_80,w_636/07dfec9399b19b8852af9a44c44b7e35.png" /><p><a href="https://gizmodo.com/i-am-legend-2-ending-will-smith-michael-b-jordan-new-yo-1850119107">Michael B. Jordan</a> is riding a winning streak. He both directed and acted in <em>Creed 3</em>, and he’s showing off some of his <a href="https://gizmodo.com/what-if-tried-to-make-black-panthers-killmonger-tony-st-1847680919">anime influences </a>in the big fight scenes between his character—Adonis Creed—and <a href="https://gizmodo.com/ant-man-quantumania-villain-kang-jonathan-majors-mcu-1850085210">Jonathan Majors</a>’ Damian Anderson. Jordan revealed to <a href="https://www.polygon.com/23617380/michael-b-jordan-creed-3-interview-anime" rel="noopener noreferrer" target="_blank">Polygon</a> that he took a lot of inspiration from Episode 450 of <a href="https://gizmodo.com/naruto-creator-is-involved-with-that-dreaded-live-actio-1790226955"><em>Naruto</em>…</a></p><p><a href="https://gizmodo.com/michael-b-jordan-jonathan-majors-creed-3-anime-naruto-1850167936">Read more...</a></p>

## The Spirited Away Stage Play Headlines Ghibli Fest 2023
 - [https://gizmodo.com/studio-ghibli-fest-2023-us-dates-miyazaki-spirited-away-1850167659](https://gizmodo.com/studio-ghibli-fest-2023-us-dates-miyazaki-spirited-away-1850167659)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 17:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--a6oiH46f--/c_fit,fl_progressive,q_80,w_636/114a30ca434c0a4f9229df032bd563ef.png" /><p>If you’re looking for a reason to brave movie theaters and <a href="https://gizmodo.com/ant-man-3-review-quantumania-paul-rudd-evangeline-lilly-1850083664"><em>Ant-Man and the Wasp: Quantumania</em></a> ended up giving you Quantumalaise, might I make a modest proposal: Why not go watch an anime masterpiece or nine? Because GKids is bringing nine of the legendary <a href="https://gizmodo.com/hayao-miyazaki-ghibli-how-do-you-live-release-date-1849887285">Hayao Miyazaki</a>’s films back into U.S. movie theaters for Studio…</p><p><a href="https://gizmodo.com/studio-ghibli-fest-2023-us-dates-miyazaki-spirited-away-1850167659">Read more...</a></p>

## Google Says Chrome Should Eat Up Less Battery Life on MacBooks
 - [https://gizmodo.com/google-chrome-macbook-pro-air-m1-m2-battery-life-update-1850167770](https://gizmodo.com/google-chrome-macbook-pro-air-m1-m2-battery-life-update-1850167770)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--nUzXTviE--/c_fit,fl_progressive,q_80,w_636/1146045eacb6c1bbe9f23dba4178a44d.jpg" /><p>Google has a new “under the hood” update rolling out that should give Apple laptop users a small boost in battery life for even longer marathon browsing or streaming. Google shared its wide array of optimizations with Gizmodo over email, which included in-house benchmarks using the 13-inch MacBook Pro. The company…</p><p><a href="https://gizmodo.com/google-chrome-macbook-pro-air-m1-m2-battery-life-update-1850167770">Read more...</a></p>

## Russia Hits Wikipedia With Fine for Going Against Putin's War Narrative
 - [https://gizmodo.com/russia-wikipedia-putin-ukraine-war-misinformation-1850167891](https://gizmodo.com/russia-wikipedia-putin-ukraine-war-misinformation-1850167891)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--LsxpGwJK--/c_fit,fl_progressive,q_80,w_636/86ee30fbc82e414b81ffe08ecf4ab19a.jpg" /><p>Russia issued a two million ruble fine ($27,000) to Wikipedia on Tuesday, claiming the site refused to remove “misinformation” about the country’s military involvement in the Ukraine War. The Kremlin issued a series of laws last year restricting reports that contradict Russia’s official message.</p><p><a href="https://gizmodo.com/russia-wikipedia-putin-ukraine-war-misinformation-1850167891">Read more...</a></p>

## Brace Your Wallet For the Best Lego Sets You Can Finally Buy in March
 - [https://gizmodo.com/lego-sets-march-2023-release-date-price-rivendell-lotr-1850141403](https://gizmodo.com/lego-sets-march-2023-release-date-price-rivendell-lotr-1850141403)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--OkBwFQvS--/c_fit,fl_progressive,q_80,w_636/a1ca1fc854868404039a447d2844520e.jpg" /><p>When Lego reveals a <a href="https://gizmodo.com/lego-new-sets-for-2023-disney-technic-speed-champions-1849953650">new batch of sets</a> it’s usually a test of patience for fans who often have to wait weeks, or sometimes months, to empty their wallets and start building. As February draws to a close, however, March will bring with it around <a href="https://gizmodo.com/lego-supersize-minifigure-captain-redbeard-denmark-only-1850163170">45 new Lego sets</a>, and more challenges for those trying to be responsible…</p><p><a href="https://gizmodo.com/lego-sets-march-2023-release-date-price-rivendell-lotr-1850141403">Read more...</a></p>

## Zuckerberg Says 'AI Personas' Are Coming to WhatsApp, Messenger, and Instagram
 - [https://gizmodo.com/whatsapp-ai-zuckerberg-chatbot-instagram-facebook-1850167349](https://gizmodo.com/whatsapp-ai-zuckerberg-chatbot-instagram-facebook-1850167349)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 15:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--hj936v4F--/c_fit,fl_progressive,q_80,w_636/f9ae44aeb5ad115f2eb898c310add44d.jpg" /><p>It seems like just yesterday that Meta was emphasizing the importance of slow and responsible AI development, and rolling out its <a href="https://gizmodo.com/facebook-chatgpt-google-ai-chatbot-google-bard-1850155514">large language model only to eligible researchers</a>. But actually it was Friday. Now, just four days later, the company has seemingly abandoned the “AI for researchers alone” tack and…</p><p><a href="https://gizmodo.com/whatsapp-ai-zuckerberg-chatbot-instagram-facebook-1850167349">Read more...</a></p>

## Amazon Driver Says AI Is Tracking Their Every Move, Even Beard Scratching
 - [https://gizmodo.com/amazon-amazon-prime-distracted-driving-jeff-bezos-1850167485](https://gizmodo.com/amazon-amazon-prime-distracted-driving-jeff-bezos-1850167485)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 15:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--7BTAF-4e--/c_fit,fl_progressive,q_80,w_636/a36647ca09442cdc61863903991a131d.jpg" /><p>The dark overlord Sauron that is the online retail giant Amazon always has its eye on its workers, and none more so than its delivery drivers. One TikTok shows how Amazon’s in-van cameras and AI system can track everything, from how often they buckle up, to whether they take their hand off the steering wheel to…</p><p><a href="https://gizmodo.com/amazon-amazon-prime-distracted-driving-jeff-bezos-1850167485">Read more...</a></p>

## From Airless Basketballs to Self-Cleaning Touchscreens, These Were February's Coolest and Weirdest Gadgets
 - [https://gizmodo.com/february-best-gadgets-sony-samsung-ikea-lg-anker-oppo-1850163627](https://gizmodo.com/february-best-gadgets-sony-samsung-ikea-lg-anker-oppo-1850163627)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 15:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--4zgGzo3s--/c_fit,fl_progressive,q_80,w_636/369bec6e86b2cd906b6fcba239c275cb.jpg" /><p>January brings feelings of new beginnings and fresh starts, while February always seems to be just another reminder of how quickly the year flies by. It probably has something to with the month clocking in at just 28 days, but that was still enough time for lots of weird and wonderful gadgets to debut this year, and…</p><p><a href="https://gizmodo.com/february-best-gadgets-sony-samsung-ikea-lg-anker-oppo-1850163627">Read more...</a></p>

## Updates From The Last of Us, The Mandalorian, Walking Dead: Dead City, and More
 - [https://gizmodo.com/last-of-us-mandalorian-season-3-trailer-pedro-pascal-1850164449](https://gizmodo.com/last-of-us-mandalorian-season-3-trailer-pedro-pascal-1850164449)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--xj9vYB4---/c_fit,fl_progressive,q_80,w_636/e8c99b07e44d19c2ae7eb96c6d91b889.png" /><p>Dermot Mulroney talks about the legacy his cop character brings to <em>Scream 6</em>. Nic Cage’s Dracula rises in new <em>Renfield</em> images. Plus, the CW teases more from <em>Gotham Knights</em>, and what’s coming in the rest of <em>Star Trek: Picard</em>’s final season. To me, my spoilers!<br /></p><p><a href="https://gizmodo.com/last-of-us-mandalorian-season-3-trailer-pedro-pascal-1850164449">Read more...</a></p>

## White House to Federal Employees: You Have 30 Days to Delete TikTok
 - [https://gizmodo.com/tiktok-bytedance-tiktok-ban-white-house-1850167273](https://gizmodo.com/tiktok-bytedance-tiktok-ban-white-house-1850167273)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 14:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--yBSguZVL--/c_fit,fl_progressive,q_80,w_636/1867df07211a8cb4ceb9d086586ba056.jpg" /><p>In a move to cut government employees from accessing TikTok on government-issued devices, the White House told federal agencies yesterday that they have 30 days to <a href="https://gizmodo.com/tiktok-banned-official-devices-house-congress-staff-1849933822">remove the app from government-issued devices</a>. The TikTok ban comes as the U.S. government grows weary about security concerns the app may pose, such as <a href="https://gizmodo.com/tiktok-bytedance-track-americans-locations-forbes-data-1849687337">…</a></p><p><a href="https://gizmodo.com/tiktok-bytedance-tiktok-ban-white-house-1850167273">Read more...</a></p>

## These Upcoming Missions to Deep Space Have Us Stoked About the Future
 - [https://gizmodo.com/big-upcoming-deep-space-missions-nasa-esa-russia-1850164273](https://gizmodo.com/big-upcoming-deep-space-missions-nasa-esa-russia-1850164273)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 14:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--4BgJt_JY--/c_fit,fl_progressive,q_80,w_636/729d533fd0b5badc599e71c02e7f70c6.jpg" /><p>Space exploration takes tons of planning, technological expertise, and daring. And given the long timescales involved, they often require considerable patience. Many upcoming missions to deep space aren’t happening any time soon, but that doesn’t mean we can’t be excited. <br /></p><p><a href="https://gizmodo.com/big-upcoming-deep-space-missions-nasa-esa-russia-1850164273">Read more...</a></p>

## Google Starts Rolling Out Fall Detection to the Pixel Watch
 - [https://gizmodo.com/google-pixel-watch-fall-detection-emergency-call-androi-1850166277](https://gizmodo.com/google-pixel-watch-fall-detection-emergency-call-androi-1850166277)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--kZnVp24Y--/c_fit,fl_progressive,q_80,w_636/fd92fdd086437d11f11c4ce562c1e141.jpg" /><p>Four months after its launch, Google has finally brought fall detection to the <a href="https://gizmodo.com/review-google-pixel-watch-1849683718">Pixel Watch</a>. The software update starts rolling out today to all Pixel Watch users. You can check for it on the device or through the Personal Safety app on Android.<br /></p><p><a href="https://gizmodo.com/google-pixel-watch-fall-detection-emergency-call-androi-1850166277">Read more...</a></p>

## Microsoft Bakes Bing AI Chatbot Right Into the Windows 11 Taskbar
 - [https://gizmodo.com/bing-ai-chatbot-windows-11-taskbar-microsoft-update-1850165759](https://gizmodo.com/bing-ai-chatbot-windows-11-taskbar-microsoft-update-1850165759)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--cvH9BXaT--/c_fit,fl_progressive,q_80,w_636/6eb287146f1cd8bac1939cea91a139d4.png" /><p>Microsoft’s foray into artificial intelligence has been wild, and now its <a href="https://gizmodo.com/ai-bing-microsoft-chatgpt-heil-hitler-prompt-google-1850109362">sometimes unhinged Bing chatbot</a> is going to get even easier to access. Microsoft <a href="https://blogs.windows.com/windowsexperience/?p=178108" rel="noopener noreferrer" target="_blank">announced</a> that the new <a href="https://gizmodo.com/bing-microsoft-chatgpt-ai-microsoft-edge-1850084072" target="_blank">AI-powered Bing</a>, based on ChatGPT and pushed out into the world fast to beat Google to the punch, is coming to users in today’s Windows 11…</p><p><a href="https://gizmodo.com/bing-ai-chatbot-windows-11-taskbar-microsoft-update-1850165759">Read more...</a></p>

## Elon Musk Is Looking Into Creating an AI Alternative to ChatGPT
 - [https://gizmodo.com/elon-musk-ai-research-lab-rival-open-ai-chatgpt-1850167149](https://gizmodo.com/elon-musk-ai-research-lab-rival-open-ai-chatgpt-1850167149)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 13:07:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1foeT3dA--/c_fit,fl_progressive,q_80,w_636/de4d12cae8240e6e3346aad3eb40d1b2.jpg" /><p>A new report from <a href="https://www.theinformation.com/articles/fighting-woke-ai-musk-recruits-team-to-develop-openai-rival" rel="noopener noreferrer" target="_blank">The Information</a> states that the billionaire has been reaching out to AI researchers in recent weeks about founding a new lab to challenge OpenAI, which Musk co-founded back in 2015 but is no longer involved with. The new Musk AI lab would work to create an alternative to ChatGPT, OpenAI’s viral…</p><p><a href="https://gizmodo.com/elon-musk-ai-research-lab-rival-open-ai-chatgpt-1850167149">Read more...</a></p>

## Yikes, the U.S. is Now Using Facial Recognition Rigged Drones for Special Ops
 - [https://gizmodo.com/drones-facial-recognition-us-air-force-realnetworks-1850163798](https://gizmodo.com/drones-facial-recognition-us-air-force-realnetworks-1850163798)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 01:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--x-aSthTg--/c_fit,fl_progressive,q_80,w_636/c8419868e59fcb2643bd701d95ecd44b.jpg" /><p>Flying killer robots used to be a nightmarish sci-fi fantasy—something that only existed in James Cameron movies or Michael Crichton novels. These days, <a href="https://www.theatlantic.com/technology/archive/2022/11/russia-ukraine-war-drones-future-of-warfare/672241/" rel="noopener noreferrer" target="_blank">not so much</a>. Not only is drone warfare  close to <a href="https://www.newamerica.org/international-security/reports/americas-counterterrorism-wars/the-drone-war-in-pakistan/" rel="noopener noreferrer" target="_blank">two decades old</a>, but innovations to this lethal technology are being developed all the time. </p><p><a href="https://gizmodo.com/drones-facial-recognition-us-air-force-realnetworks-1850163798">Read more...</a></p>

## Florida Governor Strips Disney of Special District Control
 - [https://gizmodo.com/disney-company-stripped-of-district-control-by-desantis-1850165767](https://gizmodo.com/disney-company-stripped-of-district-control-by-desantis-1850165767)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-28 00:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--91IQ4Re1--/c_fit,fl_progressive,q_80,w_636/c48f376678f9e895af82f4833c71f97b.jpg" /><p>Florida governor Ron DeSantis has retaliated against Disney for <a href="https://gizmodo.com/disney-has-finally-had-it-with-floridas-dont-say-gay-bi-1848714726">speaking out against</a> the state’s “Don’t Say Gay” bill by revoking the Disney Company’s control over the <a href="https://www.rcid.org/about/" rel="noopener noreferrer" target="_blank">Reedy Creek District</a>, the area where <a href="https://gizmodo.com/disney-world-splash-mountain-closure-water-ebay-racism-1850025658">Disney Parks</a> has long encompassed <a href="https://gizmodo.com/florida-senate-bill-to-remove-disney-self-governing-1848822893">its own city</a>.</p><p><a href="https://gizmodo.com/disney-company-stripped-of-district-control-by-desantis-1850165767">Read more...</a></p>

