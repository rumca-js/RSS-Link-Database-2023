# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Omagh police shooting: Four men released over John Caldwell attack
 - [https://www.bbc.co.uk/news/uk-northern-ireland-64797677?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-64797677?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 23:24:45+00:00

Police have been granted more time to question two men over the attack in Omagh on 22 February.

## FA Cup 2023 - Leicester 1-2 Blackburn: Rovers 'write new chapter', says boss Jon Dahl Tomasson
 - [https://www.bbc.co.uk/sport/football/64806400?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64806400?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 23:09:33+00:00

The euphoric contingent of Blackburn's travelling fans are now dreaming of a trip to Wembley after a deserved 2-1 victory at Leicester took their side into the quarter-finals.

## How Wales-England gaffe sparked trip for Canadian TikToker
 - [https://www.bbc.co.uk/news/uk-wales-64680104?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-64680104?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 22:58:48+00:00

TikToker Pavlina has had a re-education in Wales after mistakenly thinking it was in England.

## FA Cup 2023: Championship Blackburn knock Leicester out - highlights
 - [https://www.bbc.co.uk/sport/av/football/64737574?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64737574?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 22:34:16+00:00

Watch highlights as Championship side Blackburn Rovers cause an FA Cup fifth round upset by stunning Premier League Leicester City.

## FA Cup 2023 highlights: Joao Palhinha and Manor Solomon score wonder goals as Fulham beat Leeds United
 - [https://www.bbc.co.uk/sport/av/football/64737577?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64737577?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 22:13:03+00:00

Watch highlights as Fulham score two spectacular goals to defeat Leeds 2-0 and reach the quarter-finals of the FA Cup for the first time since 2010.

## Blackpink lead top stars back on the road in Asia
 - [https://www.bbc.co.uk/news/business-64286127?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64286127?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 22:04:24+00:00

The K-pop superstars are among major acts that have returned as pandemic restrictions ease.

## Bristol City 0-3 Manchester City: Phil Foden scores twice as visitors progress
 - [https://www.bbc.co.uk/sport/football/64788956?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64788956?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 22:00:56+00:00

Phil Foden scores twice as Manchester City see off Championship side Bristol City to reach the FA Cup quarter-finals.

## FA Cup - Leicester 1-2 Blackburn: Tyrhys Dolan and Sammie Szmodics score to send Rovers into last eight
 - [https://www.bbc.co.uk/sport/football/64792079?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64792079?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 22:00:08+00:00

Championship high-fliers Blackburn Rovers cause an FA Cup fifth round upset with victory at Premier League Leicester City.

## Fulham 2-0 Leeds United: Joao Palhinha and Manor Solomon score spectacular goals
 - [https://www.bbc.co.uk/sport/football/64792217?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64792217?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 21:53:10+00:00

Fulham score two spectacular goals to reach the quarter-finals of the FA Cup for the first time since 2010 as Leeds taste defeat under Javi Gracia for the first time.

## FA Cup 2023 highlights: Stoke 0-1 Brighton & Hove Albion
 - [https://www.bbc.co.uk/sport/av/football/64736471?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64736471?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 21:37:21+00:00

Watch highlights as Brighton edge past Stoke to reach the FA Cup quarter-finals as Evan Ferguson's first-half strike leads his side to victory.

## Stoke City 0-1 Brighton & Hove Albion: Seagulls reach FA Cup quarter-finals with narrow win
 - [https://www.bbc.co.uk/sport/football/64792086?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64792086?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 21:09:20+00:00

Brighton edge past Stoke to reach the FA Cup quarter-finals as Evan Ferguson's first-half strike proves the difference at Bet365 Stadium.

## FA Cup 2023: Fulham's Joao Palhinha gives Fulham the lead with 'sensational strike'
 - [https://www.bbc.co.uk/sport/av/football/64806106?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64806106?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 20:39:12+00:00

Watch the moment Fulham midfielder Joao Palhinha wins the ball 30-35 yards out and hits an incredible strike to put his side ahead against Leeds in the FA Cup.

## Yorkshire cricket racism hearing begins: Michael Vaughan, Azeem Rafiq & all you need to know
 - [https://www.bbc.co.uk/sport/cricket/64784843?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64784843?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 20:37:34+00:00

Michael Vaughan and Azeem Rafiq are due to appear at a hearing into the Yorkshire racism scandal, which starts on Wednesday.

## More civil servants to strike on Budget day
 - [https://www.bbc.co.uk/news/business-64802271?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64802271?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 20:11:14+00:00

Some 33,000 civil servants will join 100,000 of their colleagues taking strike action on 15 March.

## Venus and Jupiter to create spectacle in the sky
 - [https://www.bbc.co.uk/news/world-us-canada-64805404?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64805404?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 20:08:46+00:00

People, even without a telescope, will see the astronomical phenomenon by looking west after sundown.

## Don't create drama over Brexit deal, Rishi Sunak tells Tory MPs
 - [https://www.bbc.co.uk/news/uk-politics-64804971?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64804971?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 19:54:06+00:00

Rishi Sunak addresses his MPs in an attempt to win support for his new deal on Northern Ireland.

## Watch Kate beat William in spin class endurance race
 - [https://www.bbc.co.uk/news/uk-64803331?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64803331?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 19:49:48+00:00

The Princess of Wales is awarded a golden trophy after beating Prince William in a race.

## Nigeria election results 2023: Bola Tinubu takes strong lead over Atiku Abubakar and Peter Obi
 - [https://www.bbc.co.uk/news/world-africa-64805024?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-64805024?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 19:08:47+00:00

Opposition parties condemn the election as a sham, with Bola Tinubu on 39% of votes counted so far.

## Cut parents' benefits over school truancy, suggests Michael Gove
 - [https://www.bbc.co.uk/news/uk-politics-64803947?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64803947?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 18:29:02+00:00

The cabinet minister says the measure could help restore an "ethic of responsibility".

## No sausage mishmash? Food firms welcome NI Brexit trade deal
 - [https://www.bbc.co.uk/news/business-64785114?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64785114?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 17:50:50+00:00

Sausage producer Heck, garden centre Hillmount and Wilson's Country potato growers express their "delight".

## Drone crash near Moscow was failed attack, governor says
 - [https://www.bbc.co.uk/news/world-europe-64802453?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64802453?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 17:48:53+00:00

A drone that crashed in the Moscow region was targeting infrastructure, the regional governor said.

## Jake Paul v Tommy Fury: How will Saudi Arabia fight affect 'traditional' boxing's future?
 - [https://www.bbc.co.uk/sport/boxing/64802139?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/64802139?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 17:35:23+00:00

Was Paul v Fury a positive for 'traditional' boxing's future? Or could lucrative bouts against YouTubers become more attractive than pursuing titles?

## Missing baby couple held on suspicion of manslaughter
 - [https://www.bbc.co.uk/news/uk-64804320?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64804320?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 17:08:16+00:00

Police say Constance Marten and Mark Gordon's missing baby may have "come to harm".

## William and Kate take part in spin class on south Wales visit
 - [https://www.bbc.co.uk/news/uk-wales-64793299?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-64793299?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 16:51:52+00:00

The Prince and Princess of Wales went head-to-head in a spin class race at a leisure centre.

## Doctors pressured not to make a fuss over Lucy Letby, trial told
 - [https://www.bbc.co.uk/news/uk-england-merseyside-64802048?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-64802048?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 16:45:07+00:00

A doctor tells jurors he wished he had bypassed hospital management and gone to the police.

## Fox and badger have stand-off over food
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-64803509?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-64803509?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 16:14:19+00:00

A fox and badger were filmed having a stand-off over food left out in someone's garden.

## Sainsbury's to axe Argos depots with 1,400 jobs hit
 - [https://www.bbc.co.uk/news/business-64802615?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64802615?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 16:11:23+00:00

The supermarket giant plans to shut two of the Argos sites over the next three years.

## MPs want F1 to look into links between races and human rights violations
 - [https://www.bbc.co.uk/sport/formula1/64794237?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/64794237?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 15:54:37+00:00

UK MPs urge Formula 1 to set up an independent inquiry into the links between grands prix and human rights violations.

## Serrano injury causes Taylor rematch postponement
 - [https://www.bbc.co.uk/sport/boxing/64803049?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/64803049?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 15:46:12+00:00

Katie Taylor's world title rematch against Amanda Serrano, due to take place in Dublin in May, is postponed after the Puerto Rican sustains an injury.

## Massive walrus spotted in the Inner Hebrides
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-64793768?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-64793768?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 15:45:03+00:00

The sighting of the Arctic animal was made off Mull by a creel fisherman.

## TikTok: The reality of being a British Asian influencer
 - [https://www.bbc.co.uk/news/newsbeat-64784714?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-64784714?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 14:03:36+00:00

Can the influencer lifestyle last forever when it clashes with your culture, community and faith?

## Fake psychiatrist Zholia Alemi who forged medical degree jailed
 - [https://www.bbc.co.uk/news/uk-england-lancashire-64797676?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-64797676?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 13:48:57+00:00

Zholia Alemi worked as a psychiatrist for 22 years after she forged a medical degree, a court hears.

## BBC staff vote for strike over radio cuts
 - [https://www.bbc.co.uk/news/entertainment-arts-64799941?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64799941?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 13:15:45+00:00

Under new plans, the local 39 stations will share more shows in afternoons, evenings and at weekends.

## Homelessness: Rough sleeping up more than a quarter in a year
 - [https://www.bbc.co.uk/news/uk-64742599?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64742599?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 12:49:30+00:00

Rising prices are forcing people who have never slept rough before on to the streets, say charities.

## Banshees of Inisherin: The 83-year-old behind Oscar film's famous knits
 - [https://www.bbc.co.uk/news/world-europe-64797613?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64797613?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 12:12:26+00:00

Delia Barry's knitwear for Banshees of Inisherin has featured in Vogue, but she says "they're just jumpers".

## TikTok answers three big cybersecurity fears about the app
 - [https://www.bbc.co.uk/news/technology-64797355?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64797355?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 12:12:11+00:00

Calls in the US for a ban on TikTok have reignited the global debate about its cybersecurity risks.

## Pilot circles plane to show passengers northern lights
 - [https://www.bbc.co.uk/news/uk-england-manchester-64795572?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-64795572?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 12:03:17+00:00

The captain dimmed the lights and made a 360-degree turn so passengers could see the display.

## Six Nations 2023: Marcus Smith left out of England squad preparing for match against France
 - [https://www.bbc.co.uk/sport/rugby-union/64799016?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64799016?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 12:01:18+00:00

Marcus Smith is left out of England's training squad before the Six Nations match against France, with George Ford returning.

## New Zealand v England: After the Bash at the Basin, bring on the Ashes
 - [https://www.bbc.co.uk/sport/cricket/64776695?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64776695?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 11:55:18+00:00

Even in defeat, England threw another party in honour of Test cricket in Wellington - now the Ashes countdown is on, writes Stephan Shemilt.

## Grant Shapps 'sympathetic' to ditching energy bill rise
 - [https://www.bbc.co.uk/news/business-64797779?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64797779?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 11:46:29+00:00

Energy secretary claims he and the chancellor are looking "very carefully" at April's £500 increase.

## Marine reserves off English coast to get full protection
 - [https://www.bbc.co.uk/news/science-environment-64790153?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64790153?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 11:22:08+00:00

Fishing will be banned to allow nature to recover in three areas but critics say the plans lack ambition.

## Ben Stokes: England captain says Test matches like defeat by New Zealand 'don't come around too often'
 - [https://www.bbc.co.uk/sport/av/cricket/64798763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/64798763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 10:59:17+00:00

England Test Captain Ben Stokes says Test matches like defeat by New Zealand "don't come around too often" as he reflects on a "great game to have been a part of".

## Fifa Best Awards: David Alaba says Lionel Messi vote was Austria team decision
 - [https://www.bbc.co.uk/sport/football/64797003?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64797003?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 10:58:05+00:00

David Alaba says it was an Austria team decision for him to vote for Lionel Messi over Real Madrid team-mate Karim Benzema at the Best Fifa Awards.

## Isla Bryson: Transgender rapist jailed for eight years
 - [https://www.bbc.co.uk/news/uk-scotland-64796926?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-64796926?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 10:44:44+00:00

The case sparked a heated debate over whether Bryson should be held in a male or a female prison.

## Thiago Silva: Chelsea defender faces spell on sidelines with knee ligament damage
 - [https://www.bbc.co.uk/sport/football/64797819?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64797819?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 10:40:21+00:00

Chelsea confirm defender Thiago Silva suffered knee ligament damage during Sunday's 2-0 defeat at Tottenham.

## Nigeria election results 2023: Tinubu ahead of Atiku and Obi
 - [https://www.bbc.co.uk/news/world-africa-64786553?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-64786553?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 09:57:50+00:00

The ruling party's candidate has 44% of tallied votes, but the opposition says counting is flawed.

## Brexit Northern Ireland deal: Tory MP Steve Baker describes relief at breakthrough
 - [https://www.bbc.co.uk/news/uk-politics-64796590?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64796590?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 09:14:39+00:00

The Northern Ireland secretary hails "an amazing achievement" after seven years which "cost me my mental health".

## No hope for actor Tom Sizemore after aneurysm - manager
 - [https://www.bbc.co.uk/news/entertainment-arts-64796544?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64796544?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 09:12:15+00:00

The Saving Private Ryan and Black Hawk Down actor suffered a brain aneurysm earlier this month.

## China hits out at US over TikTok ban on federal devices
 - [https://www.bbc.co.uk/news/world-asia-china-64795548?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-64795548?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 09:07:05+00:00

Beijing accuses Washington of attempting to use state power to suppress foreign companies.

## Eggs and margarine drive food inflation to record 17.1%
 - [https://www.bbc.co.uk/news/business-64796022?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64796022?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 08:56:21+00:00

Rising prices put more pressure on household finances, with one in four shoppers struggling, research finds.

## England in Bangladesh: Jos Buttler says tour is 'exactly the kind of challenge we need'
 - [https://www.bbc.co.uk/sport/cricket/64786903?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64786903?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 07:53:23+00:00

Captain Jos Buttler says England's tour of Bangladesh is "exactly the kind of challenge we need" before October's World Cup in India.

## Brexit: What is the Stormont brake?
 - [https://www.bbc.co.uk/news/uk-northern-ireland-64795902?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-64795902?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 07:52:30+00:00

This part of the new Brexit deal aims to give NI politicians a greater say over how EU laws apply.

## Watch: The 'smart suit' that is changing children's lives
 - [https://www.bbc.co.uk/news/uk-england-london-64791997?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-64791997?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 07:26:48+00:00

Eli Crossley, who has muscular dystrophy, explains now new technology is helping in his daily life.

## The young teachers demanding better pay
 - [https://www.bbc.co.uk/news/newsbeat-64735910?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-64735910?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 07:20:24+00:00

For 27-year-old Amy, the prospect of getting a job closer to where she lives is near impossible.

## What does it mean for business?
 - [https://www.bbc.co.uk/news/uk-northern-ireland-64793597?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-64793597?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 07:15:07+00:00

The Windsor Framework seeks to reduce the frictions on Great Britain to Northern Ireland trade.

## FA Cup: What does Micah Richards remember from the 2011 Man City v Stoke City FA Cup final?
 - [https://www.bbc.co.uk/sport/av/football/64785863?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64785863?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 07:02:42+00:00

BBC Sport tests Micah Richards' memory of the 2011 FA Cup final, when Manchester City beat Stoke City 1-0 to win their first major trophy in 35 years. But who gave Richards his winner's medal?

## Covid inquiry: Race should be at its core, say campaigners
 - [https://www.bbc.co.uk/news/uk-64783753?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64783753?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 06:24:58+00:00

A coalition of organisations says the official inquiry does not focus enough on the role of racism.

## Woman single-handedly takes on BA over vouchers and wins
 - [https://www.bbc.co.uk/news/uk-england-birmingham-64788448?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-64788448?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 06:07:00+00:00

Jennie Barber represents herself in court and cites law from 1943 to win refunds for flights.

## FA Cup: How Brighton keep 'crashing through the ceiling'
 - [https://www.bbc.co.uk/sport/football/64783567?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64783567?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 06:06:27+00:00

Brighton's key figures discuss the club's rise to becoming an established Premier League side and what next for the ambitious Seagulls.

## LGBT+ History Month: Billie Jean King remembers Ted Tinling, gay designer who changed tennis
 - [https://www.bbc.co.uk/sport/av/tennis/64746248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/64746248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 06:04:46+00:00

Billie Jean King pays tribute to iconic gay fashion designer, Ted Tinling whose dresses gave her and many other players ultimate confidence on court and changed the game of tennis.

## Ben Stokes: England captain 'blessed' to be a part of thrilling defeat by New Zealand
 - [https://www.bbc.co.uk/sport/cricket/64794114?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64794114?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 05:08:06+00:00

England captain Ben Stokes says he feels "blessed" to be a part of their thrilling Test match against New Zealand in Wellington.

## Rupert Murdoch says Fox News hosts endorsed false election fraud claims
 - [https://www.bbc.co.uk/news/world-us-canada-64794606?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64794606?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 04:28:51+00:00

The billionaire's acknowledgement is revealed in a defamation case filed by Dominion Voting Systems.

## New Zealand beat England following one of all-time great finishes
 - [https://www.bbc.co.uk/sport/cricket/64794111?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64794111?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 03:18:36+00:00

England lose to New Zealand by one run in one of the all-time great finishes to the second Test in Wellington.

## Parents to be offered weaning advice for babies in England
 - [https://www.bbc.co.uk/news/health-64791565?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-64791565?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 02:22:32+00:00

A series of local family hubs will be opened in England after a survey showed knowledge gaps existed.

## Constance Marten and Mark Gordon arrested in Brighton
 - [https://www.bbc.co.uk/news/uk-64794712?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64794712?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 02:17:01+00:00

Constance Marten and Mark Gordon are in custody, police say, but their baby remains missing.

## Green flights not in easy reach, warn scientists
 - [https://www.bbc.co.uk/news/science-environment-64788106?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64788106?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 01:44:27+00:00

No clear scientific solutions currently to the emissions caused by flying, scientists conclude.

## Final stamps bearing the Queen's head revealed
 - [https://www.bbc.co.uk/news/uk-64785656?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64785656?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 01:40:32+00:00

It is the end of an era with a last set of commemorative stamps featuring the late Queen Elizabeth.

## Chris Mason: The path back to power sharing at Stormont remains difficult
 - [https://www.bbc.co.uk/news/uk-politics-64793895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64793895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 01:22:08+00:00

The PM's deal may not be enough to tempt the DUP back to government, writes our political editor.

## How do sports memorabilia buyers know they are getting the real deal?
 - [https://www.bbc.co.uk/news/uk-england-64554085?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-64554085?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 01:09:48+00:00

Sports memorabilia prices are booming, but how do collectors know they are buying the real deal?

## Carbon capture: What is it and how does it fight climate change?
 - [https://www.bbc.co.uk/news/science-environment-64723497?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64723497?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 01:09:00+00:00

The government hopes a new type of power station will help it meet is climate change targets.

## Inside the UK's Mormon missionary boot camp
 - [https://www.bbc.co.uk/news/uk-64790111?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64790111?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 01:01:43+00:00

The life of a young Mormon missionary trying to bring others into the religion

## Levi Davis: Missing rugby player case probed by Barcelona crime unit
 - [https://www.bbc.co.uk/news/newsbeat-64784670?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-64784670?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 00:53:49+00:00

Police in Barcelona say the rugby player's case raises "disturbing" issues without logical explanation.

## Manchester bomber friend known to MI5, BBC reveals
 - [https://www.bbc.co.uk/news/uk-64785422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64785422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 00:49:48+00:00

A man who was close to Salman Abedi had been investigated by MI5 years earlier, the BBC can reveal.

## The Papers: PM hails 'Brexit breakthrough' but 'tensions loom'
 - [https://www.bbc.co.uk/news/blogs-the-papers-64793883?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-64793883?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 00:39:02+00:00

A deal reached between the UK and the EU on the flow of goods to Northern Ireland leads the papers.

## Ukraine war: Zelensky says situation in Bakhmut worsening
 - [https://www.bbc.co.uk/news/world-europe-64793923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64793923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 00:25:59+00:00

Russian forces have been trying to capture the eastern city of Bakhmut for over six months.

## Nicola Adams backs 'This Girl Can With You' initiative for women in sport
 - [https://www.bbc.co.uk/sport/64787202?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/64787202?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-28 00:01:34+00:00

Two-time Olympic boxing champion Nicola Adams wants women and girls to "get active" as she helps launch the 'This Girl Can With You' initiative.

