# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Wybuch w KGP. "Prace remontowe we własnym zakresie". Ile kosztują? "Nie jest możliwe wskazanie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513496,wybuch-w-kgp-prace-remontowe-we-wlasnym-zakresie-ile-kosztuja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513496,wybuch-w-kgp-prace-remontowe-we-wlasnym-zakresie-ile-kosztuja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 20:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/51/ea/1b/z29270865M,Komendant-Glowny-Policji-Jaroslaw-Szymczyk--Listop.jpg" vspace="2" />W grudniu ubiegłego roku w budynku Komendy Głównej Policji doszło do eksplozji jednego z prezentów, które komendant otrzymał podczas wizyty w Ukrainie. Policja podkreśla, że podczas zajścia nie doszło do uszkodzenia elementów konstrukcyjnych stropu czy budynku. Konkretnych kosztów prac remontowych, które będą musiały zostać przeprowadzone, podać jednak nie chce.

## Męża Gersdorf miały ponieść emocje podczas przesłuchania. Ziobro chce dla niego kary. Jest zawiadomienie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513477,meza-gersdorf-mialy-poniesc-emocje-podczas-przesluchania-ziobro.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513477,meza-gersdorf-mialy-poniesc-emocje-podczas-przesluchania-ziobro.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 20:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ee/08/1b/z28345070M,Bohdan-Zdziennicki.jpg" vspace="2" />Prezydent Andrzej Duda na wniosek Prokuratora Generalnego Zbigniewa Ziobry złożył zawiadomienie do Trybunału Konstytucyjnego ws. byłego prezesa TK, sędziego w stanie spoczynku Bohdana Zdziennickiego. Sprawa ma związek z przesłuchaniem Zdziennickiego w prokuraturze w kwietniu ubiegłego roku. Według Ziobry były prezes TK miał "uchybić godności sędziego".

## Nowe ustalenia ws. Niemców uratowanych na jeziorze Resko. Mogło chodzić o ekshumacje ofiar katastrofy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513429,nowe-ustalenia-ws-niemcow-uratowanych-na-jeziorze-resko-moglo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513429,nowe-ustalenia-ws-niemcow-uratowanych-na-jeziorze-resko-moglo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 19:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/10/25/1c/z29513488M,Niemiecka-lodz-latajaca-Dornier-Do-24.jpg" vspace="2" />- Wszystko wskazuje na to, że zamierzali dokonać ekshumacji, poprzedzając ją pracami poszukiwawczymi - tak o Niemcach uratowanych w ubiegłym tygodniu na jeziorze Resko Przymorskie mówił portalowi naszemiasto.pl Aleksander Ostasz, dyrektor Muzeum Oręża Polskiego w Kołobrzegu. Na dnie jeziora spoczywa wrak łodzi latającej, która w 1945 r. uległa katastrofie. Na pokładzie znajdowało się 76 osób.

## 21-latka zginęła - wcześniej zgłaszała, że były partner jej grozi. Policjant wyznał: Zgodziłem się kłamać
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513407,21-latka-zginela-wczesniej-zglaszala-ze-byly-partner-jej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513407,21-latka-zginela-wczesniej-zglaszala-ze-byly-partner-jej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 19:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/46/95/1b/z28922950M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />21-letnia Monika z Poznania została zabita przez byłego partnera, który wcześniej groził jej, pobił ją i wykorzystał seksualnie. Do tragedii doszło mimo tego, że kobieta zgłosiła sprawę na policję. Niespodziewanie jeden z oskarżonych funkcjonariuszy przerwał "zawodową solidarność". - Zgodziłem się kłamać, bo przestraszyłem się konsekwencji - powiedział Krzysztof W. cytowany przez "Gazetę Wyborczą".

## Egzamin córki Piotrowicza był sfałszowany? "'Rodzina na swoim'. Przecież ona zarabia ok. 16 tys. zł"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513173,egzamin-corki-piotrowicza-byl-sfalszowany-rodzina-na-swoim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513173,egzamin-corki-piotrowicza-byl-sfalszowany-rodzina-na-swoim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 18:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c8/ba/19/z26976968M,Prokurator--zdjecie-ilustracyjne-.jpg" vspace="2" />"Gazeta Wyborcza" dotarła do nagrań, które sugerują, że córka Stanisława Piotrowicza mogła nieuczciwie zdawać egzamin sędziowski. Kobieta była prokuratorką w Prokuraturze Rejonowej w Krośnie, a po zaledwie 4,5 roku pracy została oddelegowana do "najbardziej elitarnego wydziału" podlegającego Prokuraturze Krajowej. - Przecież ona w Prokuraturze Krajowej zarabia ok. 16 tys. zł miesięcznie. Tylko za to, że jest - mówi anonimowo rozmówca Onetu.

## Śmiertelne pobicie 16-latka w centrum Zamościa. Policja szuka dwóch nastolatków
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513357,dwoch-nastolatkow-smiertelnie-pobilo-rowiesnika-policja-poszukuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29513357,dwoch-nastolatkow-smiertelnie-pobilo-rowiesnika-policja-poszukuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 18:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cb/22/1c/z29501899M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Dwóch napastników śmiertelnie pobiło 16-latka na ul. Piłsudskiego w Zamościu. Mimo reanimacji ratownikom nie udało się uratować nastolatka - podaje RMF24. Policja poszukuje sprawców.

## Wyrzuciła psa z drugiego piętra. Zwierzę zmarło. "Przepraszamy cię Muniu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512452,wyrzucila-psa-z-drugiego-pietra-zwierze-zmarlo-przepraszamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512452,wyrzucila-psa-z-drugiego-pietra-zwierze-zmarlo-przepraszamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 16:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/eb/25/1c/z29512683M,Wyrzucila-psa-z-drugiego-pietra--Zwierze-zmarlo.jpg" vspace="2" />42-latka wyrzuciła z balkonu w centrum Białegostoku psa. Usłyszała zarzut znęcania się nad zwierzętami i grozi mu do pięciu lat więzienia. Zwierzę przeżyło upadek na beton, ale po kilku dniach jego stan tak się pogorszył, że trzeba było je uśpić.

## Lubin. Śmigłowiec spadł na ziemię w czasie lądowania
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512709,lublin-smiglowiec-spadl-na-ziemie-w-czasie-ladowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512709,lublin-smiglowiec-spadl-na-ziemie-w-czasie-ladowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 15:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e8/1e/1c/z29486568M.jpg" vspace="2" />Koło godziny 14.30 na lotnisku w Lubinie doszło do katastrofy śmigłowca. Maszyna spadła na ziemię najprawdopodobniej podczas lądowania. Pilot przeżył zdarzenie.

## Odwołano dyrektorkę Opery Wrocławskiej. W piątek urodziny świętował tam kolega Czarnka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512303,odwolano-dyrektorke-opery-wroclawskiej-w-piatek-urodziny-swietowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512303,odwolano-dyrektorke-opery-wroclawskiej-w-piatek-urodziny-swietowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 15:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/80/59/19/z26580096M,Halina-Oldakowska--dyrektorka-Opery-Wroclawskiej.jpg" vspace="2" />Zarząd województwa zdecydował się odwołać Halinę Ołdakowską z funkcji dyrektora Opery Wrocławskiej. Powodem decyzji jest naruszenie prawa w zakresie dyscypliny finansów publicznych. W ostatni piątek imprezę urodzinową zorganizował w Operze Wrocławskiej bliski współpracownik ministra Przemysława Czarnka.

## Ks. Tadeusz Isakowicz-Zaleski choruje na nowotwór. "Testuję stan polskiej służby zdrowia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512071,ks-tadeusz-isakowicz-zaleski-choruje-na-nowotwor-testuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512071,ks-tadeusz-isakowicz-zaleski-choruje-na-nowotwor-testuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 14:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/99/1a/z27891986M,Ks--Tadeusz-Isakowicz-Zaleski.jpg" vspace="2" />Ks. Tadeusz Isakowicz-Zaleski w rozmowie z dziennikarzem "Rzeczpospolitej" przyznał, że choruje na nowotwór. - Ale nie w tym jest problem - powiedział i stwierdził, że martwi go stan i dostępność polskiej ochrony zdrowia.

## Robert Bąkiewicz wyrzucony z Marszu Niepodległości. "Podejmował działania na szkodę stowarzyszenia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512317,robert-bakiewicz-wyrzucony-z-marszu-niepodleglosci-podejmowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29512317,robert-bakiewicz-wyrzucony-z-marszu-niepodleglosci-podejmowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 14:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/56/11/1c/z29431126M,Robert-Bakiewicz-przed-mikrofonem-Mediow-Narodowyc.jpg" vspace="2" />Robert Bąkiewicz został wykluczony z grona członków Stowarzyszenia Marsz Niepodległości. W uchwale zarząd napisał, że Bąkiewicz miał podejmować "szereg działań na szkodę stowarzyszenia".

## Tragedia pod Zieloną Górą. Policjanci znaleźli zwłoki matki w łóżku, ciało córki w fotelu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29511323,tragedia-pod-zielona-gora-policjanci-znalezli-zwloki-matki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29511323,tragedia-pod-zielona-gora-policjanci-znalezli-zwloki-matki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 13:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d9/25/1c/z29511897M,Tragedia-pod-Zielona-Gora.jpg" vspace="2" />W jednym z domów pod Zieloną Górą policjanci znaleźli zwłoki dwóch kobiet - ciało matki leżało w łóżku, a jej martwa córka siedziała w fotelu obok. Prokurator zlecił przeprowadzenie sekcji.

## Nagraniem "w instrybutor nie strzel" bawiła się cała Polska. Dziś Katarzyna A. mówi: Bałam się o życie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509850,nagraniem-w-instrybutor-nie-strzel-bawila-sie-cala-polska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509850,nagraniem-w-instrybutor-nie-strzel-bawila-sie-cala-polska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 12:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/03/24/1c/z29510147M,Kobieta-ze-slawnego-nagrania--w-instrybutor-nie-st.jpg" vspace="2" />W lutym 2021 roku 37-letnia wówczas Katarzyna A. wjechała w budynek stacji paliw w Rymaniu (woj. zachodniopomorskie). Następnie spłoszona policyjnymi strzałami uciekła. O zdarzeniu zrobiło się głośno dzięki nagraniu, w którym padły słowa "w instrybutor nie strzel". Po dwóch latach w programie Polsatu "Interwencja" kobieta opowiedziała, co nią wówczas kierowało. Okazuje się też, że sądy przez dwa lata nie mogły się uporać z tą sprawą.

## Radziejów. Połaszczyła się na papier toaletowy. Teraz grozi jej pięć lat więzienia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29511027,radziejow-polaszczyla-sie-na-papier-toaletowy-teraz-grozi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29511027,radziejow-polaszczyla-sie-na-papier-toaletowy-teraz-grozi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 11:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/19/24/1c/z29511193M,Kradziez-papieru-toaletowego-w-Radziejowie.jpg" vspace="2" />Do pięciu lat więzienia grozi kobiecie, która spod jednego ze sklepów w Radziejowie (województwo kujawsko-pomorskie) ukradła kilkadziesiąt opakowań papieru toaletowego. 27-latkę schwytała ochrona sklepu, która zauważyła kradzież podczas przeglądania monitoringu.

## NIK przez 3 godziny przesłuchiwał Obajtka, ale Orlen wciąż nie wpuszcza kontrolerów. "Chodzi o 3 mln zł"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29510210,nik-przez-3-godziny-przesluchiwal-obajtka-ale-orlen-wciaz-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29510210,nik-przez-3-godziny-przesluchiwal-obajtka-ale-orlen-wciaz-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 10:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/1a/1c/z29469927M,Marian-Banas--Zdjecie-archiwalne.jpg" vspace="2" />Marian Banaś ujawnił, że w związku z prowadzoną przez NIK kontrolą w resorcie aktywów państwowych przez trzy godziny przesłuchiwano Daniela Obajtka. Jednak kontrolerzy wciąż nie mogą wejść do PKN Orlen. Dlaczego? - Myślę, że chodzi o wydatki w kwocie 3 mld złotych na usługi, promocję, konsultacje prawne, sponsoring - wyjaśnił prezes Najwyższej Izby Kontroli.

## Premier przedłużył obowiązywanie w Polsce stopni alarmowych
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29510653,premier-przedluzyl-obowiazywanie-w-polsce-stopni-alarmowych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29510653,premier-przedluzyl-obowiazywanie-w-polsce-stopni-alarmowych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 10:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />Premier podpisał zarządzenia, które przedłużają do 31 maja 2023 r. obowiązywanie stopni alarmowych Chodzi o alarmy: 3. stopnia CHARLIE-CRP, 2. stopnia BRAVO na terenie całego kraju oraz 2. stopnia BRAVO wobec polskiej infrastruktury energetycznej, mieszczącej się poza granicami Rzeczypospolitej Polskiej.

## Co się stało z "patriotycznymi ławkami" za dwa mln zł? Senator Krzysztof Brejza dostał odpowiedź
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509659,co-sie-stalo-z-patriotycznymi-lawkami-za-dwa-mln-zl-senator.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509659,co-sie-stalo-z-patriotycznymi-lawkami-za-dwa-mln-zl-senator.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 09:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/89/d5/1b/z29185673M,Patriotyczna-lawka-w-Poznaniu.jpg" vspace="2" />"Patriotyczne ławki", które przez zaledwie trzy miesiące "zdobiły" 16 polskich miast, kosztowały Bank Gospodarstwa Krajowego blisko dwa mln zł. Teraz zdemontowane leżą w magazynie i czekają na swoje kolejne pięć minut, czyli "ponownie wykorzystane w przestrzeni publicznej" - dowiedział się senator Krzysztof Brejza.

## Pogoda na tydzień. Wracają opady i wichury. Zbliża się cyklon, wiatr nawet do 100 km/h
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509654,pogoda-na-tydzien-wracaja-opady-i-wichury-zbliza-sie-cyklon.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509654,pogoda-na-tydzien-wracaja-opady-i-wichury-zbliza-sie-cyklon.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 09:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/31/24/1c/z29509681M,Przymrozek---zdjecie-ilustracyjne.jpg" vspace="2" />Przed nami mroźny tydzień. Przeciętne temperatury będą oscylować w granicach od -5 do 5 stopni Celsjusza. Rankiem wystąpią mgły powodujące szadź. Od piątku pojawią się opady deszczu oraz deszczu ze śniegiem. Do Polski zbliża się też cyklon, który może sprowadzić do nas wichury z wiatrem wiejącym do 100 km/h.

## "GW": Próba sfałszowania egzaminu córki Piotrowicza nie ulega przedawnieniu. Dzięki przepisom PiS
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509807,gw-proba-sfalszowania-egzaminu-corki-piotrowicza-nie-ulega.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509807,gw-proba-sfalszowania-egzaminu-corki-piotrowicza-nie-ulega.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 08:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/17/10/1a/z27328535M,sedzia-Stanislaw-Piotrowicz.jpg" vspace="2" />Stanisław Piotrowicz miał nakłaniać dwóch sędziów, by dopisali prawidłowe odpowiedzi na karcie jej córki podczas egzaminu na aplikację sędziowską. Z ustaleń "Gazety Wyborczej" wynika, że próba sfałszowania wyników egzaminacyjnych nie ulega przedawnieniu. Wszystko to dzięki przepisom, które Prawo i Sprawiedliwość przyjęło w czasie epidemii koronawirusa.

## Molestowane kobiety mówią: Czuję gniew, wstyd, złość - na siebie, nie na sprawcę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29489519,molestowane-kobiety-mowia-czuje-gniew-wstyd-zlosc-na-siebie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29489519,molestowane-kobiety-mowia-czuje-gniew-wstyd-zlosc-na-siebie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 07:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3d/22/1c/z29500477M,Anonimowa-kobieta--zdjecie-ilustracyjne-.jpg" vspace="2" />Przyzwolenie na seksistowskie "żarty", strach przed ostrą reakcją na niechciany dotyk, na fizyczną czy słowną przemoc, brak wiary, że reakcja przyniesie skutek. I w końcu złość - NA SIEBIE, nie na sprawcę. Te wspólne mianowniki znajdziemy w relacjach kobiet, które wzięły udział w badaniu Polskiego Towarzystwa Prawa Dyskryminacyjnego. "Panicznie się go boję", "skutecznie go unikałam", "jestem grzeczna, jak mnie uczono" - mówią.

## Papież Franciszek odwiedzi Węgry. Terlikowski: Nie uczy się rzeczywistości. Szkoda
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509652,papiez-franciszek-odwiedzi-wegry-terlikowski-nie-uczy-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509652,papiez-franciszek-odwiedzi-wegry-terlikowski-nie-uczy-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 06:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/24/1c/z29509666M,Tomasz-Terlikowski.jpg" vspace="2" />"Franciszek jest zaproszony do Ukrainy, gdzie trwa bestialski, barbarzyński atak Rosji. (...) Zamiast tego pojedzie na Węgry, które prowadzą antyukraińską i prorosyjską politykę" - napisał Tomasz Terlikowski, komentując zapowiedzianą na kwiecień papieską pielgrzymkę. Publicysta dodał, że głowa Kościoła katolickiego "nie wyciąga wniosków z porażek własnej dyplomacji, nie uczy się rzeczywistości".

## CBA zabrało dokumentację z gabinetu ginekologicznego. Jest oświadczenie: Charakter incydentalny
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509644,cba-zabralo-dokumentacje-z-gabinetu-ginekologicznego-w-szczecinie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29509644,cba-zabralo-dokumentacje-z-gabinetu-ginekologicznego-w-szczecinie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-28 06:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/28/24/1c/z29509672M,CBA-zabralo-dokumentacje-z-gabinetu-ginekologiczne.jpg" vspace="2" />"Udział funkcjonariuszy CBA w realizowanych czynnościach miał charakter incydentalny i wynikał z troski o zabezpieczenie prawidłowego toku postępowania" - to fragment oświadczenia CBA dotyczący zabrania dokumentacji medycznej z gabinetu ginekologicznego w Szczecinie. Przypomnijmy, że funkcjonariusze zabrali karty wszystkich pacjentek dr Marii Kubisy z ostatnich 27 lat.

