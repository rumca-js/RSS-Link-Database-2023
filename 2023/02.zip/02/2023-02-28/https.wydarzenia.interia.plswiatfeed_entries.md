# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Taśma na dłoniach, torba na głowie. Tak uciekła porywaczom
 - [https://wydarzenia.interia.pl/zagranica/news-tasma-na-dloniach-torba-na-glowie-tak-uciekla-porywaczom,nId,6625508](https://wydarzenia.interia.pl/zagranica/news-tasma-na-dloniach-torba-na-glowie-tak-uciekla-porywaczom,nId,6625508)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-02-28 10:02:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tasma-na-dloniach-torba-na-glowie-tak-uciekla-porywaczom,nId,6625508"><img align="left" alt="Taśma na dłoniach, torba na głowie. Tak uciekła porywaczom " src="https://i.iplsc.com/tasma-na-dloniach-torba-na-glowie-tak-uciekla-porywaczom/000GTO2NTHV3QF1S-C321.jpg" /></a>Dłonie zaklejone taśmą, torba na głowie. Tak wyglądająca kobieta przejęła kierownicę samochodu i uciekła swoim porywaczom. Brawurowa ucieczka ocaliła jej życie. Para, która ja porwała, trafiła do aresztu. </p><br clear="all" />

## Dramatyczna sytuacja pod Bachmutem. Opublikowano mapę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dramatyczna-sytuacja-pod-bachmutem-opublikowano-mape,nId,6625379](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dramatyczna-sytuacja-pod-bachmutem-opublikowano-mape,nId,6625379)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-02-28 06:22:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dramatyczna-sytuacja-pod-bachmutem-opublikowano-mape,nId,6625379"><img align="left" alt="Dramatyczna sytuacja pod Bachmutem. Opublikowano mapę" src="https://i.iplsc.com/dramatyczna-sytuacja-pod-bachmutem-opublikowano-mape/000GTMIX9WVMKX2G-C321.jpg" /></a>Mimo &quot;małego kotła&quot;, jaki Siły Zbrojne Ukrainy sprawiły wagnerowcom w Bachmucie, położenie ukraińskiej armii jest coraz trudniejsze. Według analityków i osób zajmującycyh się tzw. białym wywiadem Rosja przejęła kontrolę nad częścią osiedli mieszkalnych w północnej części miasta.</p><br clear="all" />

