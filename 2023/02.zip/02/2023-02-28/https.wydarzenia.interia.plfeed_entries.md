# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Zełenski o deokupacji Ukrainy. "Nasi żołnierze się przygotowują"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-o-deokupacji-ukrainy-nasi-zolnierze-sie-przygotowuj,nId,6626225](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-o-deokupacji-ukrainy-nasi-zolnierze-sie-przygotowuj,nId,6626225)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 22:03:39+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-o-deokupacji-ukrainy-nasi-zolnierze-sie-przygotowuj,nId,6626225"><img align="left" alt="Zełenski o deokupacji Ukrainy. &quot;Nasi żołnierze się przygotowują&quot;" src="https://i.iplsc.com/zelenski-o-deokupacji-ukrainy-nasi-zolnierze-sie-przygotowuj/000EUHB8CT435EN4-C321.jpg" /></a>Przygotowujemy powrót naszych wojskowych do aktywnych działań na rzecz wyzwolenia naszej ziemi spod rosyjskiej okupacji - oświadczył prezydent Ukrainy w wieczornej odezwie do narodu. Jak podkreślił, Bachmut wciąż pozostaje najtrudniejszym odcinkiem walk z wrogiem. - Od czwartku, tylko tam, zginęło co najmniej 800 rosyjskich żołnierzy - podkreślił.</p><br clear="all" />

## USA: Zabił szopy i porzucił je pod mostem. Policja szuka sprawcy
 - [https://wydarzenia.interia.pl/zagranica/news-usa-zabil-szopy-i-porzucil-je-pod-mostem-policja-szuka-spraw,nId,6626099](https://wydarzenia.interia.pl/zagranica/news-usa-zabil-szopy-i-porzucil-je-pod-mostem-policja-szuka-spraw,nId,6626099)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 21:38:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-zabil-szopy-i-porzucil-je-pod-mostem-policja-szuka-spraw,nId,6626099"><img align="left" alt="USA: Zabił szopy i porzucił je pod mostem. Policja szuka sprawcy " src="https://i.iplsc.com/usa-zabil-szopy-i-porzucil-je-pod-mostem-policja-szuka-spraw/000GTRCGF1T2SUUS-C321.jpg" /></a>Policjanci poszukują sprawcy, który najprawdopodobniej zabił kilkanaście szopów praczy i porzucił je pod mostem - podaje Fox News. Stacja przypomina, że te dzikie zwierzęta są od 1971 roku jednym z oficjalnych symboli stanu Tennessee. O znalezieniu martwych szopów poinformowali funkcjonariuszy oburzeni mieszkańcy.</p><br clear="all" />

## Ułaskawienie ministrów Kamińskiego i Wąsika. Sąd Najwyższy zajął się sprawą z urzędu
 - [https://wydarzenia.interia.pl/kraj/news-ulaskawienie-ministrow-kaminskiego-i-wasika-sad-najwyzszy-za,nId,6626213](https://wydarzenia.interia.pl/kraj/news-ulaskawienie-ministrow-kaminskiego-i-wasika-sad-najwyzszy-za,nId,6626213)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 21:33:29+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ulaskawienie-ministrow-kaminskiego-i-wasika-sad-najwyzszy-za,nId,6626213"><img align="left" alt="Ułaskawienie ministrów Kamińskiego i Wąsika. Sąd Najwyższy zajął się sprawą z urzędu" src="https://i.iplsc.com/ulaskawienie-ministrow-kaminskiego-i-wasika-sad-najwyzszy-za/000GTS1TORQERQET-C321.jpg" /></a>We wtorek Sąd Najwyższy podjął postępowanie z urzędu w sprawie umorzonej w związku z ułaskawieniem ministrów Mariusza Kamińskiego i Macieja Wąsika, nie czekając na rozstrzygnięcie Trybunału Konstytucyjnego - poinformowała Gazeta Wyborcza. TK badał sprawę pod względem sporu kompetencyjnego. </p><br clear="all" />

## Tusk o "czarnej rozpaczy". Minister Czarnek odpowiada
 - [https://wydarzenia.interia.pl/kraj/news-tusk-o-czarnej-rozpaczy-minister-czarnek-odpowiada,nId,6626196](https://wydarzenia.interia.pl/kraj/news-tusk-o-czarnej-rozpaczy-minister-czarnek-odpowiada,nId,6626196)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 20:19:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-o-czarnej-rozpaczy-minister-czarnek-odpowiada,nId,6626196"><img align="left" alt="Tusk o &quot;czarnej rozpaczy&quot;. Minister Czarnek odpowiada" src="https://i.iplsc.com/tusk-o-czarnej-rozpaczy-minister-czarnek-odpowiada/000GTRVQJQ5EMWOO-C321.jpg" /></a>- Czarna rozpacz może człowieka ogarnąć, ile rzeczy zmarnowano przez tych siedem lat. Od pierwszej klasy podstawowej do końca studiów widzimy ten szlak bojowy ministra Czarnka i dewastowanie edukacji - powiedział lider PO Donald Tusk. W odpowiedzi minister edukacji i nauki Przemysław Czarnek wskazał we wtorek na Twitterze m.in., że za czasów PO podwyżki dla młodych nauczycieli wynosiły 540 zł, przy 2060 zł za rządów PiS. &quot;Myśli Pan, że nikt nie pamięta? Wstydu Pan nie ma!&quot; - napisał.</p><br clear="all" />

## Media: Dwa wybuchy na lotnisku w Jejsku. Władze mówią o ćwiczeniach
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-dwa-wybuchy-na-lotnisku-w-jejsku-wladze-mowia-o-cwicze,nId,6626192](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-dwa-wybuchy-na-lotnisku-w-jejsku-wladze-mowia-o-cwicze,nId,6626192)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 20:11:17+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-dwa-wybuchy-na-lotnisku-w-jejsku-wladze-mowia-o-cwicze,nId,6626192"><img align="left" alt="Media: Dwa wybuchy na lotnisku w Jejsku. Władze mówią o ćwiczeniach" src="https://i.iplsc.com/media-dwa-wybuchy-na-lotnisku-w-jejsku-wladze-mowia-o-cwicze/000GTRVTTQBCQOAC-C321.jpg" /></a>Na rosyjskim lotnisku wojskowym w Jejsku nad Morzem Azowskim miało dojść do dwóch eksplozji - donoszą rosyjskie media. Władze dementują te informacje i twierdzą, że ewentualne wybuchy to efekt zaplanowanych wcześniej ćwiczeń. &quot;Nie dajcie się zwieść prowokacjom&quot; - stwierdził rosyjski urzędnik.</p><br clear="all" />

## Wybuchy na białoruskim lotnisku. Pokazano zdjęcia
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wybuchy-na-bialoruskim-lotnisku-pokazano-zdjecia,nId,6626173](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wybuchy-na-bialoruskim-lotnisku-pokazano-zdjecia,nId,6626173)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 20:07:36+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wybuchy-na-bialoruskim-lotnisku-pokazano-zdjecia,nId,6626173"><img align="left" alt="Wybuchy na białoruskim lotnisku. Pokazano zdjęcia" src="https://i.iplsc.com/wybuchy-na-bialoruskim-lotnisku-pokazano-zdjecia/000GTRZLF8VR7Q4E-C321.jpg" /></a>Po wybuchach na lotnisku w Maczuliszczach w Dzierżyńsku na Białorusi zatrzymano co najmniej sześć osób - poinformowało we wtorek zdelegalizowane przez reżim Alaksandra Łukaszenki centrum praw człowieka Wiasna. Samolot wczesnego ostrzegania A50U został uszkodzony wskutek dwóch wybuchów. Odpowiedzialność za atak wzięła na siebie białoruska organizacja antyrządowa BYPOL. Doradca szefa ukraińskiego MSW Anton Heraszczenko opublikował zdjęcie, pisząc, że samolot nosi ślady zniszczenia w dwóch miejscach. Dziennikarze badający sprawę nie...</p><br clear="all" />

## Dania rezygnuje z dnia wolnego od pracy. Pieniądze potrzebne na armię
 - [https://wydarzenia.interia.pl/zagranica/news-dania-rezygnuje-z-dnia-wolnego-od-pracy-pieniadze-potrzebne-,nId,6626151](https://wydarzenia.interia.pl/zagranica/news-dania-rezygnuje-z-dnia-wolnego-od-pracy-pieniadze-potrzebne-,nId,6626151)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 19:21:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-dania-rezygnuje-z-dnia-wolnego-od-pracy-pieniadze-potrzebne-,nId,6626151"><img align="left" alt="Dania rezygnuje z dnia wolnego od pracy. Pieniądze potrzebne na armię" src="https://i.iplsc.com/dania-rezygnuje-z-dnia-wolnego-od-pracy-pieniadze-potrzebne/000GTROEFG3224FS-C321.jpg" /></a>Duński parlament (Folketing) po burzliwej debacie przegłosował we wtorek zniesienie od przyszłego roku wolnego od pracy święta Wielki Dzień Modlitwy. W ten sposób za zaoszczędzone środki chcą doposażyć wojsko. Jak tłumaczyła premier kraju, to odpowiedź na rosnące zagrożenie ze strony Rosji.  

</p><br clear="all" />

## Wizyta Łukaszenki w Chinach. Białoruski samolot wylądował w Pekinie
 - [https://wydarzenia.interia.pl/zagranica/news-wizyta-lukaszenki-w-chinach-bialoruski-samolot-wyladowal-w-p,nId,6626143](https://wydarzenia.interia.pl/zagranica/news-wizyta-lukaszenki-w-chinach-bialoruski-samolot-wyladowal-w-p,nId,6626143)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 19:07:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wizyta-lukaszenki-w-chinach-bialoruski-samolot-wyladowal-w-p,nId,6626143"><img align="left" alt="Wizyta Łukaszenki w Chinach. Białoruski samolot wylądował w Pekinie" src="https://i.iplsc.com/wizyta-lukaszenki-w-chinach-bialoruski-samolot-wyladowal-w-p/000GTRLUPN5REQKN-C321.jpg" /></a>Alaksandr Łukaszenka przyleciał we wtorek rządowym samolotem do stolicy Chin Pekinu. Ma się tam spotkać z przewodniczącym Chińskiej Republiki Ludowej Xi Jinpingiem. Chińskie media państwowe nie podały żadnych informacji na temat przybycia białoruskiego przywódcy ani planu jego wizyty. W niedawnym wywiadzie dla chińskich mediów Łukaszenka mówił jedynie, że teraz jest &quot;wyjątkowa okazja, aby położyć kres konfliktowi&quot; w Ukrainie.</p><br clear="all" />

## Czarnoskóra wykładowczyni pozwała uczelnię. "To mikroagresja rasowa"
 - [https://wydarzenia.interia.pl/zagranica/news-czarnoskora-wykladowczyni-pozwala-uczelnie-to-mikroagresja-r,nId,6626138](https://wydarzenia.interia.pl/zagranica/news-czarnoskora-wykladowczyni-pozwala-uczelnie-to-mikroagresja-r,nId,6626138)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 19:02:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czarnoskora-wykladowczyni-pozwala-uczelnie-to-mikroagresja-r,nId,6626138"><img align="left" alt="Czarnoskóra wykładowczyni pozwała uczelnię. &quot;To mikroagresja rasowa&quot;" src="https://i.iplsc.com/czarnoskora-wykladowczyni-pozwala-uczelnie-to-mikroagresja-r/000GTRRS26RCDVC3-C321.jpg" /></a>Czarnoskóra wykładowczyni oskarżyła brytyjską uczelnię o &quot;mikroagresję&quot;, molestowanie i dyskryminację rasową - donosi dziennik &quot;Daily Mail&quot;. Uniwersytet miał traktować kobietę gorzej niż swoich białoskórych pracowników, a koledzy z pracy negować jej projekty badawcze o Afryce. Po rozpatrzeniu sprawy sąd odrzucił jednak roszczenia i wyjaśnił wszystkie zarzuty na korzyść placówki.</p><br clear="all" />

## MAEA: Iran ma uran wzbogacony prawie do poziomu potrzebnego do produkcji bomby atomowej
 - [https://wydarzenia.interia.pl/zagranica/news-maea-iran-ma-uran-wzbogacony-prawie-do-poziomu-potrzebnego-d,nId,6626133](https://wydarzenia.interia.pl/zagranica/news-maea-iran-ma-uran-wzbogacony-prawie-do-poziomu-potrzebnego-d,nId,6626133)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 18:57:51+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-maea-iran-ma-uran-wzbogacony-prawie-do-poziomu-potrzebnego-d,nId,6626133"><img align="left" alt="MAEA: Iran ma uran wzbogacony prawie do poziomu potrzebnego do produkcji bomby atomowej" src="https://i.iplsc.com/maea-iran-ma-uran-wzbogacony-prawie-do-poziomu-potrzebnego-d/000GTRNGQRMWPRQD-C321.jpg" /></a>Międzynarodowa Agencja Energii Atomowej potwierdziła we wtorek, że w Iranie wykryto cząsteczki uranu wzbogaconego do 83,7 proc., czyli nieco poniżej 90 proc. potrzebnych do wyprodukowania bomby atomowej. &quot;Dyskusje trwają&quot;, aby ustalić pochodzenie tych cząstek - podała MAEA w raporcie, do którego dotarła AFP. Rząd w Teheranie pytany o uran powiedział, że &quot;mogły wystąpić niezamierzone fluktuacje&quot; podczas procesu wzbogacania. </p><br clear="all" />

## Otwock: 33-latek pobił lekarkę weterynarii, bo nie chciała uśpić psa
 - [https://wydarzenia.interia.pl/mazowieckie/news-otwock-33-latek-pobil-lekarke-weterynarii-bo-nie-chciala-usp,nId,6626127](https://wydarzenia.interia.pl/mazowieckie/news-otwock-33-latek-pobil-lekarke-weterynarii-bo-nie-chciala-usp,nId,6626127)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 18:39:18+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-otwock-33-latek-pobil-lekarke-weterynarii-bo-nie-chciala-usp,nId,6626127"><img align="left" alt="Otwock: 33-latek pobił lekarkę weterynarii, bo nie chciała uśpić psa" src="https://i.iplsc.com/otwock-33-latek-pobil-lekarke-weterynarii-bo-nie-chciala-usp/0006LRDEYXVME8X2-C321.jpg" /></a>Niebezpiecznie dla lekarza weterynarii zakończyła się wizyta jednego z interesantów. 33-letni mężczyzna przyszedł do gabinetu z psem i zażądał od lekarki uśpienia zwierzęcia. Kiedy odmówiła, właściciel psa zaatakował ją. Na kobietę rzucił się także pies, który był bez smyczy i kagańca.</p><br clear="all" />

## "Ta wojna zrujnowała mi życie". Tak teraz żyją Rosjanie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ta-wojna-zrujnowala-mi-zycie-tak-teraz-zyja-rosjanie,nId,6625571](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ta-wojna-zrujnowala-mi-zycie-tak-teraz-zyja-rosjanie,nId,6625571)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 18:38:11+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ta-wojna-zrujnowala-mi-zycie-tak-teraz-zyja-rosjanie,nId,6625571"><img align="left" alt="&quot;Ta wojna zrujnowała mi życie&quot;. Tak teraz żyją Rosjanie " src="https://i.iplsc.com/ta-wojna-zrujnowala-mi-zycie-tak-teraz-zyja-rosjanie/000GTOJVC4H6DEU3-C321.jpg" /></a>- Miałam plany, cele... Teraz moim jedynym celem jest przeprowadzka albo chociaż przeniesienie stąd mojej córki - mówi pielęgniarka z Rosji. - Ludzie się kłócą, są podzieleni - mówi z kolei Rosjanin z centrum kraju. &quot;The Telegraph&quot; publikuje reportaż na temat tego, jak obecnie żyje się w Rosji. Niepewność, niezgoda i wysokie ceny - taki obraz państwa rysują Rosjanie, których cytuje gazeta. </p><br clear="all" />

## Na Krymie rośnie w siłę partyzantka "żółtej wstążki". Protest się rozlewa
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-na-krymie-rosnie-w-sile-partyzantka-zoltej-wstazki-protest-s,nId,6626120](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-na-krymie-rosnie-w-sile-partyzantka-zoltej-wstazki-protest-s,nId,6626120)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 18:27:42+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-na-krymie-rosnie-w-sile-partyzantka-zoltej-wstazki-protest-s,nId,6626120"><img align="left" alt="Na Krymie rośnie w siłę partyzantka &quot;żółtej wstążki&quot;. Protest się rozlewa" src="https://i.iplsc.com/na-krymie-rosnie-w-sile-partyzantka-zoltej-wstazki-protest-s/000GTRKHGYGFTTQ5-C321.jpg" /></a>Za malowanie ukraińskich flag na ławkach w parku i ogrodzeniach została w Sewastopolu na anektowanym przez Rosję Krymie zatrzymana 62-letnia kobieta - podał we wtorek niezależny portal Mediazona. Brała w tym udział Federalna Służba Bezpieczeństwa i specjalny wydział policji. Wobec zatrzymanej wszczęto sprawę karną. W miastach na półwyspie nasila się ruch społecznego oporu, który wszędzie, gdzie się da, maluje bądź wiesza żółte wstążki.</p><br clear="all" />

## Śmiertelne pobicie 16-latka w Zamościu. Policja poszukuje napastników
 - [https://wydarzenia.interia.pl/lubelskie/news-smiertelne-pobicie-16-latka-w-zamosciu-policja-poszukuje-nap,nId,6626104](https://wydarzenia.interia.pl/lubelskie/news-smiertelne-pobicie-16-latka-w-zamosciu-policja-poszukuje-nap,nId,6626104)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 17:48:16+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-smiertelne-pobicie-16-latka-w-zamosciu-policja-poszukuje-nap,nId,6626104"><img align="left" alt="Śmiertelne pobicie 16-latka w Zamościu. Policja poszukuje napastników" src="https://i.iplsc.com/smiertelne-pobicie-16-latka-w-zamosciu-policja-poszukuje-nap/000D96DKF8UKD5NU-C321.jpg" /></a>Nie żyje 16-latek, który został pobity na ul. Piłsudskiego w Zamościu. Choć na miejsce przybyli ratownicy medyczni, nastolatka nie udało się uratować. Policja bada wszelkie okoliczności zdarzenia i poszukuje dwóch napastników.</p><br clear="all" />

## Nieoficjalnie: Robert Biedroń spotka się z Sanną Marin
 - [https://wydarzenia.interia.pl/zagranica/news-nieoficjalnie-robert-biedron-spotka-sie-z-sanna-marin,nId,6626098](https://wydarzenia.interia.pl/zagranica/news-nieoficjalnie-robert-biedron-spotka-sie-z-sanna-marin,nId,6626098)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 17:38:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nieoficjalnie-robert-biedron-spotka-sie-z-sanna-marin,nId,6626098"><img align="left" alt="Nieoficjalnie: Robert Biedroń spotka się z Sanną Marin" src="https://i.iplsc.com/nieoficjalnie-robert-biedron-spotka-sie-z-sanna-marin/000GTR84H58SB852-C321.jpg" /></a>Robert Biedroń współprzewodniczący Nowej Lewicy i szef komisji ds. praw kobiet i równouprawnienia w PE wraz z delegacją Lewicy w czwartek spotkają się z premierką Finlandii Sanną Marin - dowiedziała się Interia od osoby z bliskiego otoczenia lidera partii. Politycy będą rozmawiali na temat dostępu Polek do aborcji.
</p><br clear="all" />

## Peru: Kilkusetletnia mumia w torbie termicznej. "To Juanita, duchowa dziewczyna"
 - [https://wydarzenia.interia.pl/zagranica/news-peru-kilkusetletnia-mumia-w-torbie-termicznej-to-juanita-duc,nId,6626084](https://wydarzenia.interia.pl/zagranica/news-peru-kilkusetletnia-mumia-w-torbie-termicznej-to-juanita-duc,nId,6626084)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 17:11:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-peru-kilkusetletnia-mumia-w-torbie-termicznej-to-juanita-duc,nId,6626084"><img align="left" alt="Peru: Kilkusetletnia mumia w torbie termicznej. &quot;To Juanita, duchowa dziewczyna&quot;" src="https://i.iplsc.com/peru-kilkusetletnia-mumia-w-torbie-termicznej-to-juanita-duc/000GTRD2JOSYGDG9-C321.jpg" /></a>26-latek z Peru przechowywał w swoim domu kilkusetletnią mumię twierdząc, że jest jego &quot;duchową dziewczyną&quot; o imieniu Juanita. Mężczyzna został złapany przez policję na gorącym uczynku, gdy spakował zwłoki do torby termicznej, by pokazać je swoim przyjaciołom. Badania eksperckie wykazały jednak, że ciało nie należy do kobiety.</p><br clear="all" />

## Rzuciła się na papier toaletowy. Zabrała z palet 43 paczki warte 600 zł
 - [https://wydarzenia.interia.pl/kujawsko-pomorskie/news-rzucila-sie-na-papier-toaletowy-zabrala-z-palet-43-paczki-wa,nId,6625940](https://wydarzenia.interia.pl/kujawsko-pomorskie/news-rzucila-sie-na-papier-toaletowy-zabrala-z-palet-43-paczki-wa,nId,6625940)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 17:00:19+00:00

<p><a href="https://wydarzenia.interia.pl/kujawsko-pomorskie/news-rzucila-sie-na-papier-toaletowy-zabrala-z-palet-43-paczki-wa,nId,6625940"><img align="left" alt="Rzuciła się na papier toaletowy. Zabrała z palet 43 paczki warte 600 zł" src="https://i.iplsc.com/rzucila-sie-na-papier-toaletowy-zabrala-z-palet-43-paczki-wa/000GTQWACYUEESV2-C321.jpg" /></a>Kilkadziesiąt opakowań papieru toaletowego zabrała z palet stojących przed magazynem 27-letnia mieszkanka powiatu radziejowskiego (woj. kujawsko-pomorskie). Policjanci z komisariatu w Piotrkowie Kujawskim namierzyli złodziejkę i postawili jej zarzuty. Grozi jej pięć lat więzienia.</p><br clear="all" />

## Zaginęły w drodze na kręgle. Spędziły pięć dni na odludziu
 - [https://wydarzenia.interia.pl/zagranica/news-zaginely-w-drodze-na-kregle-spedzily-piec-dni-na-odludziu,nId,6625879](https://wydarzenia.interia.pl/zagranica/news-zaginely-w-drodze-na-kregle-spedzily-piec-dni-na-odludziu,nId,6625879)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 16:39:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zaginely-w-drodze-na-kregle-spedzily-piec-dni-na-odludziu,nId,6625879"><img align="left" alt="Zaginęły w drodze na kręgle. Spędziły pięć dni na odludziu " src="https://i.iplsc.com/zaginely-w-drodze-na-kregle-spedzily-piec-dni-na-odludziu/000GTQN6MS6FMXUF-C321.jpg" /></a>Dwie poszukiwane od zeszłej środy niepełnosprawne intelektualnie kobiety zostały odnalezione. Jak się okazało, 51-letnia Kimberly Pushard i 50-letnia Angela Bussell utknęły w zaspie śnieżnej w swoim jeepie - donosi &quot;The Mirror&quot;.</p><br clear="all" />

## Wielka Brytania. Arystokratka i jej partner gwałciciel aresztowani. Policja szuka ich dziecka
 - [https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-arystokratka-i-jej-partner-gwalciciel-areszt,nId,6625871](https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-arystokratka-i-jej-partner-gwalciciel-areszt,nId,6625871)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 16:30:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-arystokratka-i-jej-partner-gwalciciel-areszt,nId,6625871"><img align="left" alt="Wielka Brytania. Arystokratka i jej partner gwałciciel aresztowani. Policja szuka ich dziecka" src="https://i.iplsc.com/wielka-brytania-arystokratka-i-jej-partner-gwalciciel-areszt/000GTQPNTYE390AH-C321.jpg" /></a>W Brighton (Wielka Brytania) z udziałem helikopterów, dronów i psów tropiących trwają poszukiwania niemowlaka, którego rodzice zostali aresztowani za zaniedbanie dziecka. Constance Marten i Mark Gordon uciekli miesiąc wcześniej z nowo narodzony maleństwem. Jego ojciec spędził 20 lat w więzieniu za gwałt. </p><br clear="all" />

## Niemcy. Wyrok dla "potwora z Wermelskirchen". Zgwałcił m.in. miesięczne dziecko
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-wyrok-dla-potwora-z-wermelskirchen-zgwalcil-m-in-mies,nId,6625918](https://wydarzenia.interia.pl/zagranica/news-niemcy-wyrok-dla-potwora-z-wermelskirchen-zgwalcil-m-in-mies,nId,6625918)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 16:27:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-wyrok-dla-potwora-z-wermelskirchen-zgwalcil-m-in-mies,nId,6625918"><img align="left" alt="Niemcy. Wyrok dla &quot;potwora z Wermelskirchen&quot;. Zgwałcił m.in. miesięczne dziecko" src="https://i.iplsc.com/niemcy-wyrok-dla-potwora-z-wermelskirchen-zgwalcil-m-in-mies/000GTQQX8TELQWGG-C321.jpg" /></a>Na 14,5 roku więzienia został w Niemczech skazany 45-letni Marcus R., pedofil, który w latach 2005-2019 wykorzystał seksualnie łącznie co najmniej 13 dzieci. Najmłodszą ofiarą &quot;potwora z Wermelskirchen&quot; była miesięczna dziewczynka. Wyrok zapadł w sądzie okręgowym w Kolonii.</p><br clear="all" />

## Prezydent Andrzej Duda zmienił skład Rady Dialogu Społecznego
 - [https://wydarzenia.interia.pl/kraj/news-prezydent-andrzej-duda-zmienil-sklad-rady-dialogu-spoleczneg,nId,6625917](https://wydarzenia.interia.pl/kraj/news-prezydent-andrzej-duda-zmienil-sklad-rady-dialogu-spoleczneg,nId,6625917)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 16:27:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydent-andrzej-duda-zmienil-sklad-rady-dialogu-spoleczneg,nId,6625917"><img align="left" alt="Prezydent Andrzej Duda zmienił skład Rady Dialogu Społecznego" src="https://i.iplsc.com/prezydent-andrzej-duda-zmienil-sklad-rady-dialogu-spoleczneg/000GTQRD6AXUHTQA-C321.jpg" /></a>Troje przedstawicieli OPZZ: Piotr Ostrowski, Elżbieta Aleksandrowicz, Michał Lewandowski oraz przedstawiciele organizacji pracodawców: Piotr Kamiński z Pracodawców RP oraz Piotr Soroczyński z Federacji Przedsiębiorców Polskich - weszło w skład Rady Dialogu Społecznego. Nominacje wręczył we wtorek w Pałacu Prezydenckim prezydent Andrzej Duda.</p><br clear="all" />

## Nowe planetoidy. Jedna z nich nazwana na cześć Polaka
 - [https://wydarzenia.interia.pl/zagranica/news-nowe-planetoidy-jedna-z-nich-nazwana-na-czesc-polaka,nId,6625914](https://wydarzenia.interia.pl/zagranica/news-nowe-planetoidy-jedna-z-nich-nazwana-na-czesc-polaka,nId,6625914)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 16:26:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowe-planetoidy-jedna-z-nich-nazwana-na-czesc-polaka,nId,6625914"><img align="left" alt="Nowe planetoidy. Jedna z nich nazwana na cześć Polaka " src="https://i.iplsc.com/nowe-planetoidy-jedna-z-nich-nazwana-na-czesc-polaka/000GTR70B6YBPN3H-C321.jpg" /></a>Cztery planetoidy zostały nazwane na cześć trzech astronomów jezuitów z Obserwatorium Watykańskiego i papieża Grzegorza XIII (Ugo Boncompagni), który rozpoczął tradycję papieskiego patronatu nad instytucją. Robert Janusz SJ pracujący w Obserwatorium - polski astronom, został patronem nowopoznanego ciała niebieskiego. Jego imię nosi asteroida 565184 - informuje &quot;The Tablet&quot;. </p><br clear="all" />

## Wielkopolskie: Dzieci dostał w szkole mus owocowy. Zawierał kofeinę
 - [https://wydarzenia.interia.pl/wielkopolskie/news-wielkopolskie-dzieci-dostal-w-szkole-mus-owocowy-zawieral-ko,nId,6625827](https://wydarzenia.interia.pl/wielkopolskie/news-wielkopolskie-dzieci-dostal-w-szkole-mus-owocowy-zawieral-ko,nId,6625827)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 16:25:38+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-wielkopolskie-dzieci-dostal-w-szkole-mus-owocowy-zawieral-ko,nId,6625827"><img align="left" alt="Wielkopolskie: Dzieci dostał w szkole mus owocowy. Zawierał kofeinę" src="https://i.iplsc.com/wielkopolskie-dzieci-dostal-w-szkole-mus-owocowy-zawieral-ko/000G293MT6EJGP6P-C321.jpg" /></a>Do niecodziennej sytuacji doszło w jednej z wielkopolskich szkół podstawowych. Uczniom w ramach posiłku wydano mus owocowy o wysokim stężeniu kofeiny. Na sytuację zareagował rodzic, którego zaniepokoiła informacja o składzie produktu umieszczona na jego odwrocie. O sprawie został poinformowany sanepid.   </p><br clear="all" />

## 23 tys. nadmiarowych zgonów w Wielkiej Brytanii. "Ludzie czekają 12 godzin"
 - [https://wydarzenia.interia.pl/zagranica/news-23-tys-nadmiarowych-zgonow-w-wielkiej-brytanii-ludzie-czekaj,nId,6625901](https://wydarzenia.interia.pl/zagranica/news-23-tys-nadmiarowych-zgonow-w-wielkiej-brytanii-ludzie-czekaj,nId,6625901)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 16:15:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-23-tys-nadmiarowych-zgonow-w-wielkiej-brytanii-ludzie-czekaj,nId,6625901"><img align="left" alt="23 tys. nadmiarowych zgonów w Wielkiej Brytanii. &quot;Ludzie czekają 12 godzin&quot;" src="https://i.iplsc.com/23-tys-nadmiarowych-zgonow-w-wielkiej-brytanii-ludzie-czekaj/000GEP11EXHMNGDF-C321.jpg" /></a>Ponad 23 tys. osób zmarło w 2022 roku w Wielkiej Brytanii z powodu długiego oczekiwania na szpitalnych oddziałach ratunkowych - wynika z raportu opublikowanego przez brytyjską organizację lekarzy medycyny ratunkowej, Royal College of Emergency Medicine (RCEM). Zdaniem analityków głównymi problemami służby zdrowia na Wyspach są braki kadrowe w sektorze opieki medycznej i społecznej oraz chroniczne niedofinansowanie systemu.</p><br clear="all" />

## Sprawa Włodzimierza Karpińskiego. Jest wniosek o areszt
 - [https://wydarzenia.interia.pl/kraj/news-sprawa-wlodzimierza-karpinskiego-jest-wniosek-o-areszt,nId,6625422](https://wydarzenia.interia.pl/kraj/news-sprawa-wlodzimierza-karpinskiego-jest-wniosek-o-areszt,nId,6625422)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 15:49:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sprawa-wlodzimierza-karpinskiego-jest-wniosek-o-areszt,nId,6625422"><img align="left" alt="Sprawa Włodzimierza Karpińskiego. Jest wniosek o areszt" src="https://i.iplsc.com/sprawa-wlodzimierza-karpinskiego-jest-wniosek-o-areszt/000GTMTNU8IW0AHL-C321.jpg" /></a>Jest wniosek o areszt dla Włodzimierza Karpińskiego, byłego ministra skarbu w rządzie PO, wraz z zarzutem dotyczącym żądania i przyjęcia korzyści majątkowej - przekazał rzecznik Prokuratury Krajowej prok. Łukasz Łapczyński.
</p><br clear="all" />

## W środę w pogodzie wyjątkowy dzień. IMGW: Jedna z pierwszych takich sytuacji w tym roku
 - [https://wydarzenia.interia.pl/kraj/news-w-srode-w-pogodzie-wyjatkowy-dzien-imgw-jedna-z-pierwszych-t,nId,6625559](https://wydarzenia.interia.pl/kraj/news-w-srode-w-pogodzie-wyjatkowy-dzien-imgw-jedna-z-pierwszych-t,nId,6625559)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 15:44:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-w-srode-w-pogodzie-wyjatkowy-dzien-imgw-jedna-z-pierwszych-t,nId,6625559"><img align="left" alt="W środę w pogodzie wyjątkowy dzień. IMGW: Jedna z pierwszych takich sytuacji w tym roku" src="https://i.iplsc.com/w-srode-w-pogodzie-wyjatkowy-dzien-imgw-jedna-z-pierwszych-t/000GTQK6P4H1PJKA-C321.jpg" /></a>Pierwszy dzień wiosny wypada dokładnie 1 marca. Mowa oczywiście o tej meteorologicznej, ponieważ ta kalendarzowa nadejdzie dopiero za trzy tygodnie. 1 marca 2023 roku będzie wyjątkowy także z innego powodu. Jak podaje IMGW, dzień ten będzie jednym z pierwszych w tym roku z takim usłonecznieniem.</p><br clear="all" />

## Z tym dokumentem obniżysz rachunek za prąd. Co musisz zrobić?
 - [https://wydarzenia.interia.pl/kraj/news-z-tym-dokumentem-obnizysz-rachunek-za-prad-co-musisz-zrobic,nId,6625635](https://wydarzenia.interia.pl/kraj/news-z-tym-dokumentem-obnizysz-rachunek-za-prad-co-musisz-zrobic,nId,6625635)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 15:06:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-z-tym-dokumentem-obnizysz-rachunek-za-prad-co-musisz-zrobic,nId,6625635"><img align="left" alt="Z tym dokumentem obniżysz rachunek za prąd. Co musisz zrobić?" src="https://i.iplsc.com/z-tym-dokumentem-obnizysz-rachunek-za-prad-co-musisz-zrobic/000DBA3K0KVS9Y1A-C321.jpg" /></a>Inflacja i znaczny wzrost cen spowodowały, że wiele rodzin musi liczyć się z ponoszeniem wyższych kosztów życia. W 2023 posiadacze Karty Dużej Rodziny mogą liczyć na niższe ceny za prąd. </p><br clear="all" />

## Turyści nagrywali walczące nosorożce. Zwierzęta zwróciły się przeciwko nim
 - [https://wydarzenia.interia.pl/zagranica/news-turysci-nagrywali-walczace-nosorozce-zwierzeta-zwrocily-sie-,nId,6625689](https://wydarzenia.interia.pl/zagranica/news-turysci-nagrywali-walczace-nosorozce-zwierzeta-zwrocily-sie-,nId,6625689)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 14:31:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-turysci-nagrywali-walczace-nosorozce-zwierzeta-zwrocily-sie-,nId,6625689"><img align="left" alt="Turyści nagrywali walczące nosorożce. Zwierzęta zwróciły się przeciwko nim " src="https://i.iplsc.com/turysci-nagrywali-walczace-nosorozce-zwierzeta-zwrocily-sie/000GTP1KYS6HW4W6-C321.jpg" /></a>To miała być wycieczka na łonie natury. Wszystko zakończyło się jednak poważnym wypadkiem. Pracownicy parku są w szoku - nosorożce nigdy wcześniej nie rzuciły się w pogoń za ludźmi. </p><br clear="all" />

## Małomice. Wypadek śmigłowca na terenie areoklubu. Poszkodowany pilot
 - [https://wydarzenia.interia.pl/slaskie/news-malomice-wypadek-smiglowca-na-terenie-areoklubu-poszkodowany,nId,6625822](https://wydarzenia.interia.pl/slaskie/news-malomice-wypadek-smiglowca-na-terenie-areoklubu-poszkodowany,nId,6625822)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 14:30:18+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-malomice-wypadek-smiglowca-na-terenie-areoklubu-poszkodowany,nId,6625822"><img align="left" alt="Małomice. Wypadek śmigłowca na terenie areoklubu. Poszkodowany pilot" src="https://i.iplsc.com/malomice-wypadek-smiglowca-na-terenie-areoklubu-poszkodowany/000GTPSTF7Q3A4SK-C321.jpg" /></a>Na terenie Aeroklubu Zagłębia Miedziowego w Małomicach doszło do wypadku śmigłowca, w wyniku którego poszkodowany został pilot - poinformował st. kpt. Grzegorz Karpiński z PSP w Lubinie. Na miejscu interweniowało pięć zastępów straży pożarnej. </p><br clear="all" />

## Zmieniają się zasady dla Ukraińców w Polsce. "Nie stać nas"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zmieniaja-sie-zasady-dla-ukraincow-w-polsce-nie-stac-nas,nId,6623476](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zmieniaja-sie-zasady-dla-ukraincow-w-polsce-nie-stac-nas,nId,6623476)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 14:08:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zmieniaja-sie-zasady-dla-ukraincow-w-polsce-nie-stac-nas,nId,6623476"><img align="left" alt="Zmieniają się zasady dla Ukraińców w Polsce. &quot;Nie stać nas&quot;" src="https://i.iplsc.com/zmieniaja-sie-zasady-dla-ukraincow-w-polsce-nie-stac-nas/000GTIHL9OLX05QC-C321.jpg" /></a>Od 1 marca uchodźcy z Ukrainy będą musieli płacić za pobyt w ośrodkach zbiorowego zakwaterowania. Rząd zapewnia, że w nowej ustawie nie chodzi o to, by kogokolwiek pozbawić dachu nad głową, a o aktywizację zawodową. Są jednak tacy, dla których zmiana zasad pobytu w Polsce jest równoznaczna z biletem powrotnym do Ukrainy. Mówią wprost: &quot;Nie stać nas&quot;.</p><br clear="all" />

## USA: 86-latek wygrał noc z prostytutkami. Zmarł przed "odebraniem" nagrody
 - [https://wydarzenia.interia.pl/zagranica/news-usa-86-latek-wygral-noc-z-prostytutkami-zmarl-przed-odebrani,nId,6625769](https://wydarzenia.interia.pl/zagranica/news-usa-86-latek-wygral-noc-z-prostytutkami-zmarl-przed-odebrani,nId,6625769)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 13:35:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-86-latek-wygral-noc-z-prostytutkami-zmarl-przed-odebrani,nId,6625769"><img align="left" alt="USA: 86-latek wygrał noc z prostytutkami. Zmarł przed &quot;odebraniem&quot; nagrody " src="https://i.iplsc.com/usa-86-latek-wygral-noc-z-prostytutkami-zmarl-przed-odebrani/000GTQF545DG5EKP-C321.jpg" /></a>Ed Orris zgłosił swojego dziadka do udziału w radiowym konkursie &quot;Get My Grandfather Laid&quot;. Wygraną była upojna noc z dwiema prosytutkami. 86-letni Johnny został zwycięzcą losowania. Do spotkania z kobietami miało dojść w stanie Nevada, gdzie prostytucja jest legalna. Mężczyzna nie zdążył skorzystać z wygranej, ponieważ zmarł. Zadławił się stekiem - przypomina &quot;Daily Star&quot;.  </p><br clear="all" />

## Pakt Senacki 2023. Opozycja podpisała porozumienie
 - [https://wydarzenia.interia.pl/kraj/news-pakt-senacki-2023-opozycja-podpisala-porozumienie,nId,6625743](https://wydarzenia.interia.pl/kraj/news-pakt-senacki-2023-opozycja-podpisala-porozumienie,nId,6625743)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 13:35:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pakt-senacki-2023-opozycja-podpisala-porozumienie,nId,6625743"><img align="left" alt="Pakt Senacki 2023. Opozycja podpisała porozumienie" src="https://i.iplsc.com/pakt-senacki-2023-opozycja-podpisala-porozumienie/000GTP6R50JQ24GV-C321.jpg" /></a>Przedstawiciele Koalicji Obywatelskiej, Lewicy, Polskiego Stronnictwa Ludowego, Polski 2050 i strony samorządowej podpisali porozumienie dot. wspólnego startu w wyborach do Senatu. - To znaczny krok w celu ich wygrania - przekazał senator Zygmunt Frankiewicz. Jak wcześniej zapowiadali politycy opozycji, pakt senacki ma zapewnić im ponad 60 mandatów w kolejnej kadencji izby wyższej. </p><br clear="all" />

## Mieszkańcy w szoku. Kuria zamurowuje im okna
 - [https://wydarzenia.interia.pl/wielkopolskie/news-mieszkancy-w-szoku-kuria-zamurowuje-im-okna,nId,6625740](https://wydarzenia.interia.pl/wielkopolskie/news-mieszkancy-w-szoku-kuria-zamurowuje-im-okna,nId,6625740)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 13:26:00+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-mieszkancy-w-szoku-kuria-zamurowuje-im-okna,nId,6625740"><img align="left" alt="Mieszkańcy w szoku. Kuria zamurowuje im okna" src="https://i.iplsc.com/mieszkancy-w-szoku-kuria-zamurowuje-im-okna/000GTP0HT6DCLY4L-C321.jpg" /></a>Archidiecezja Poznańska, do której należy kamienica przy ulicy Głogowskiej 32 w Poznaniu, postanowiła zamurować okna sześciu rodzinom. W przeszłości wszystkie te okna wykuto nielegalnie, co stwierdził nadzór budowlany. - One były w większości mieszkań oknami kuchennymi. Ciekawe, jak teraz będzie z wentylacją - mówi jedna z mieszkanek.</p><br clear="all" />

## Tusk do młodzieży: Moje pokolenie powinno przepraszać
 - [https://wydarzenia.interia.pl/kraj/news-tusk-do-mlodziezy-moje-pokolenie-powinno-przepraszac,nId,6625724](https://wydarzenia.interia.pl/kraj/news-tusk-do-mlodziezy-moje-pokolenie-powinno-przepraszac,nId,6625724)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 13:20:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-do-mlodziezy-moje-pokolenie-powinno-przepraszac,nId,6625724"><img align="left" alt="Tusk do młodzieży: Moje pokolenie powinno przepraszać" src="https://i.iplsc.com/tusk-do-mlodziezy-moje-pokolenie-powinno-przepraszac/000GTOXEBS31VFG1-C321.jpg" /></a>We wtorek Donald Tusk zorganizował spotkanie otwarte w Łodzi, gdzie odpowiadał na pytania młodzieży. Odpowiadał między innymi ws. energetyki jądrowej. - Dzisiaj, przynajmniej częściowo, jest bezalternatywna - ocenił szef PO. Krytykował też rządzących za zmiany w edukacji. - Czarna rozpacz może człowieka ogarnąć - stwierdził.</p><br clear="all" />

## Szczecin: 17 razy zdawał egzamin na prawo jazdy. Szybko je stracił
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-szczecin-17-razy-zdawal-egzamin-na-prawo-jazdy-szybko-je-str,nId,6625563](https://wydarzenia.interia.pl/zachodniopomorskie/news-szczecin-17-razy-zdawal-egzamin-na-prawo-jazdy-szybko-je-str,nId,6625563)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 13:16:00+00:00

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-szczecin-17-razy-zdawal-egzamin-na-prawo-jazdy-szybko-je-str,nId,6625563"><img align="left" alt="Szczecin: 17 razy zdawał egzamin na prawo jazdy. Szybko je stracił" src="https://i.iplsc.com/szczecin-17-razy-zdawal-egzamin-na-prawo-jazdy-szybko-je-str/000GTO56SEKORRKK-C321.jpg" /></a>Policjanci ze Szczecina zatrzymali młodego kierowcę, który znacząco przekroczył prędkość w terenie zabudowanym. Za swoje nieodpowiedzialne zachowanie 23-latek stracił uprawnienia do kierowania. Dla mężczyzny musiała to być szczególnie bolesna kara, ponieważ dopiero niedawno zdał egzamin na prawo jazdy. Kosztowało go to sporo wysiłku, bo udało mu się dopiero za 17. razem. </p><br clear="all" />

## Te osoby mogą dostać emeryturę wcześniej. Tobie też się należy?
 - [https://wydarzenia.interia.pl/kraj/news-te-osoby-moga-dostac-emeryture-wczesniej-tobie-tez-sie-nalez,nId,6625564](https://wydarzenia.interia.pl/kraj/news-te-osoby-moga-dostac-emeryture-wczesniej-tobie-tez-sie-nalez,nId,6625564)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 13:10:48+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-te-osoby-moga-dostac-emeryture-wczesniej-tobie-tez-sie-nalez,nId,6625564"><img align="left" alt="Te osoby mogą dostać emeryturę wcześniej. Tobie też się należy?" src="https://i.iplsc.com/te-osoby-moga-dostac-emeryture-wczesniej-tobie-tez-sie-nalez/000GTOBWNVFH7I1K-C321.jpg" /></a>Osoby wykonujące niektóre zawody mogą skorzystać z wcześniejszego prawa do świadczenia emerytalnego. Sprawdź, jakie warunki musisz spełnić, by otrzymać wcześniejszą emeryturę. </p><br clear="all" />

## Indie: Chcą ukrócić znęcanie się nad zwierzętami. Ma pomóc w tym robot
 - [https://wydarzenia.interia.pl/zagranica/news-indie-chca-ukrocic-znecanie-sie-nad-zwierzetami-ma-pomoc-w-t,nId,6625742](https://wydarzenia.interia.pl/zagranica/news-indie-chca-ukrocic-znecanie-sie-nad-zwierzetami-ma-pomoc-w-t,nId,6625742)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 13:04:07+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-indie-chca-ukrocic-znecanie-sie-nad-zwierzetami-ma-pomoc-w-t,nId,6625742"><img align="left" alt="Indie: Chcą ukrócić znęcanie się nad zwierzętami. Ma pomóc w tym robot " src="https://i.iplsc.com/indie-chca-ukrocic-znecanie-sie-nad-zwierzetami-ma-pomoc-w-t/000GTP0ICYXR2YNE-C321.jpg" /></a>Nietypowe rozwiązanie znaleźli obrońcy praw zwierząt w Indiach. W odprawianiu religijnych rytuałów żywe zwierzęta zastąpi robot. Sztuczny słoń waży 800 kilogramów, a mierzy ponad trzy metry - informuje portal BBC. Jak widać na nagraniu zamieszczonym w sieci, jest łudząco podobny do prawdziwego zwierzęcia. Może poruszać uszami i ogonem, lać wodę z trąby, a nawet nosić ludzi na plecach - wylicza portal Newstrack Live.</p><br clear="all" />

## PiS publikuje spot i uderza w PO. "Jedna szklanka dziennie"
 - [https://wydarzenia.interia.pl/kraj/news-pis-publikuje-spot-i-uderza-w-po-jedna-szklanka-dziennie,nId,6625644](https://wydarzenia.interia.pl/kraj/news-pis-publikuje-spot-i-uderza-w-po-jedna-szklanka-dziennie,nId,6625644)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 12:58:20+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pis-publikuje-spot-i-uderza-w-po-jedna-szklanka-dziennie,nId,6625644"><img align="left" alt="PiS publikuje spot i uderza w PO. &quot;Jedna szklanka dziennie&quot;" src="https://i.iplsc.com/pis-publikuje-spot-i-uderza-w-po-jedna-szklanka-dziennie/000GTOI7DLVLFCF3-C321.jpg" /></a>Partia rządząca opublikowała spot, w którym przestrzega przed rządami Platformy Obywatelskiej. Politycy PiS uważają, że Rafał Trzaskowski chcą wprowadzić ograniczenia w dostępie np. do mięsa i nabiału. Nie przekonują ich zapewnienia prezydenta Warszawy, który podkreślał, że żadnych obostrzeń nie będzie.</p><br clear="all" />

## Łukaszenkowcy zamalowali fresk "Cud nad Wisłą" w kościele w Sołach
 - [https://wydarzenia.interia.pl/zagranica/news-lukaszenkowcy-zamalowali-fresk-cud-nad-wisla-w-kosciele-w-so,nId,6625647](https://wydarzenia.interia.pl/zagranica/news-lukaszenkowcy-zamalowali-fresk-cud-nad-wisla-w-kosciele-w-so,nId,6625647)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 12:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lukaszenkowcy-zamalowali-fresk-cud-nad-wisla-w-kosciele-w-so,nId,6625647"><img align="left" alt="Łukaszenkowcy zamalowali fresk &quot;Cud nad Wisłą&quot; w kościele w Sołach" src="https://i.iplsc.com/lukaszenkowcy-zamalowali-fresk-cud-nad-wisla-w-kosciele-w-so/000GTOJAVK9HQ93P-C321.jpg" /></a>Fresk &quot;Cud nad Wisłą&quot;, który w latach 30. minionego stulecia namalowano w kościele pw. Matki Bożej Różańcowej w Sołach na Grodzieńszczyźnie, został zamalowany. Kilka miesięcy temu w jednym z programów białoruskiej państwowej telewizji wyrażono oburzenie na obecność dzieła pokazującego &quot;zabójstwo sowieckich żołnierzy&quot;.</p><br clear="all" />

## Tragiczny wypadek na AGH w Krakowie. Nie żyje student
 - [https://wydarzenia.interia.pl/malopolskie/news-tragiczny-wypadek-na-agh-w-krakowie-nie-zyje-student,nId,6625715](https://wydarzenia.interia.pl/malopolskie/news-tragiczny-wypadek-na-agh-w-krakowie-nie-zyje-student,nId,6625715)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 12:44:41+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-tragiczny-wypadek-na-agh-w-krakowie-nie-zyje-student,nId,6625715"><img align="left" alt="Tragiczny wypadek na AGH w Krakowie. Nie żyje student" src="https://i.iplsc.com/tragiczny-wypadek-na-agh-w-krakowie-nie-zyje-student/000GTP0FIEEU3V67-C321.jpg" /></a>We wtorek rano doszło do tragedii w budynku Akademii Górniczo-Hutniczej w Krakowie. Młody mężczyzna spadł z wysokości piątego piętra i zginął na miejscu. Jak dowiedziała się Interia, policja wykluczyła udział osób trzecich. Rzeczniczka uczelni poinformowała, że ofiara to student.</p><br clear="all" />

## Burza w Mołdawii. Na ulicach prorosyjski protest
 - [https://wydarzenia.interia.pl/zagranica/news-burza-w-moldawii-na-ulicach-prorosyjski-protest,nId,6625688](https://wydarzenia.interia.pl/zagranica/news-burza-w-moldawii-na-ulicach-prorosyjski-protest,nId,6625688)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 12:14:23+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-burza-w-moldawii-na-ulicach-prorosyjski-protest,nId,6625688"><img align="left" alt="Burza w Mołdawii. Na ulicach prorosyjski protest" src="https://i.iplsc.com/burza-w-moldawii-na-ulicach-prorosyjski-protest/000G87D762U532YS-C321.jpg" /></a>W stolicy Mołdawii - Kiszyniowie - rozpoczęły się antyrządowe protesty. Tysiące ludzi na ulicach sparaliżowało miasto. Za manifestacje odpowiada prorosyjska paria Szor. Do akcji, mającej powstrzymać manifestantów, przystąpiła policja.</p><br clear="all" />

## Dron rozbił się w pobliżu podmoskiewskiej tłoczni Gazpromu
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dron-rozbil-sie-w-poblizu-podmoskiewskiej-tloczni-gazpromu,nId,6625682](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dron-rozbil-sie-w-poblizu-podmoskiewskiej-tloczni-gazpromu,nId,6625682)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 12:11:35+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dron-rozbil-sie-w-poblizu-podmoskiewskiej-tloczni-gazpromu,nId,6625682"><img align="left" alt="Dron rozbił się w pobliżu podmoskiewskiej tłoczni Gazpromu" src="https://i.iplsc.com/dron-rozbil-sie-w-poblizu-podmoskiewskiej-tloczni-gazpromu/000GTOPBECKSB87C-C321.jpg" /></a>Około południa w rosyjskich mediach pojawiły się informacje o dronie, który rozbił się w pobliżu Moskwy. Bezzałogowiec spadł w rejonie miejscowości Gubastowo, oddalonej od stolicy o około 80 kilometrów. Znajduje się tam należąca do Gazpromu tłocznia gazu.</p><br clear="all" />

## Morawiecki: Polska za rządów PO była skansenem Europy. My to zmieniliśmy
 - [https://wydarzenia.interia.pl/kraj/news-morawiecki-polska-za-rzadow-po-byla-skansenem-europy-my-to-z,nId,6625651](https://wydarzenia.interia.pl/kraj/news-morawiecki-polska-za-rzadow-po-byla-skansenem-europy-my-to-z,nId,6625651)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 11:47:20+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-morawiecki-polska-za-rzadow-po-byla-skansenem-europy-my-to-z,nId,6625651"><img align="left" alt="Morawiecki: Polska za rządów PO była skansenem Europy. My to zmieniliśmy" src="https://i.iplsc.com/morawiecki-polska-za-rzadow-po-byla-skansenem-europy-my-to-z/000GTOJ2CT3XJWX1-C321.jpg" /></a>Celem rządu PiS od zawsze była budowa silnego, sprawnego i nowoczesnego państwa - powiedział na konferencji prasowej Mateusz Morawiecki. Jak dodał, za rządów PO nasz kraj był &quot;skansenem Europy&quot; pod względem ucyfrowienia różnych usług publicznych. - My to zmieniliśmy. Szeroko otworzyliśmy wrota dla wszystkich obywateli do korzystania z usług elektronicznych - podkreślił premier. </p><br clear="all" />

## Program "Polskie Szwalnie" to porażka. Wyniki kontroli NIK
 - [https://wydarzenia.interia.pl/kraj/news-program-polskie-szwalnie-to-porazka-wyniki-kontroli-nik,nId,6625528](https://wydarzenia.interia.pl/kraj/news-program-polskie-szwalnie-to-porazka-wyniki-kontroli-nik,nId,6625528)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 11:40:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-program-polskie-szwalnie-to-porazka-wyniki-kontroli-nik,nId,6625528"><img align="left" alt="Program &quot;Polskie Szwalnie&quot; to porażka. Wyniki kontroli NIK" src="https://i.iplsc.com/program-polskie-szwalnie-to-porazka-wyniki-kontroli-nik/000A12KMNY003G2W-C321.jpg" /></a>Najwyższa Izba Kontroli przedstawiła wyniki kontroli rządowego programu &quot;Polskie Szwalnie&quot;. Chodzi o produkcję maseczek po wybuchu pandemii koronawirusa w 2020 roku. Program, którego wartość wyceniono na ponad 250 mln złotych okazał się fiaskiem.</p><br clear="all" />

## Morawiecki zdecydował. Chodzi o stopnie alarmowe BRAVO i CHARLIE-CRP
 - [https://wydarzenia.interia.pl/kraj/news-morawiecki-zdecydowal-chodzi-o-stopnie-alarmowe-bravo-i-char,nId,6625623](https://wydarzenia.interia.pl/kraj/news-morawiecki-zdecydowal-chodzi-o-stopnie-alarmowe-bravo-i-char,nId,6625623)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 11:12:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-morawiecki-zdecydowal-chodzi-o-stopnie-alarmowe-bravo-i-char,nId,6625623"><img align="left" alt="Morawiecki zdecydował. Chodzi o stopnie alarmowe BRAVO i CHARLIE-CRP" src="https://i.iplsc.com/morawiecki-zdecydowal-chodzi-o-stopnie-alarmowe-bravo-i-char/000GTOEH4V66EH7M-C321.jpg" /></a>Mateusz Morawiecki zdecydował o przedłużeniu obowiązywania stopni alarmowych BRAVO oraz CHARLIR-CRP. Jak informuje Ministerstwo Spraw Wewnętrznych i Administracji, będa one obowiązywały na terenie naszego kraju co najmniej do końca maja.</p><br clear="all" />

## Rosjanie przyjdą od Mołdawii? "Boimy się. Tych bydlaków nic nie zatrzyma"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-przyjda-od-moldawii-boimy-sie-tych-bydlakow-nic-nie,nId,6625539](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-przyjda-od-moldawii-boimy-sie-tych-bydlakow-nic-nie,nId,6625539)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 11:07:03+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-przyjda-od-moldawii-boimy-sie-tych-bydlakow-nic-nie,nId,6625539"><img align="left" alt="Rosjanie przyjdą od Mołdawii? &quot;Boimy się. Tych bydlaków nic nie zatrzyma&quot;" src="https://i.iplsc.com/rosjanie-przyjda-od-moldawii-boimy-sie-tych-bydlakow-nic-nie/000GTO7D8Q224FRM-C321.jpg" /></a>Jest kilka minut po pierwszej w nocy, ze snu wyrywa mnie alarm. To normalne. Kolejny słyszę o 4, a jeszcze następny o 8 rano. Gdy wstaję, okazuje się, że trafiono w Chmielnicki, stolicę obwodu. Zginęło dwóch ratowników, a kilka osób zostało rannych. Jednak to nie ataki rakietowe spędzają dziś sen z powiek mieszkańców tego obwodu, a sytuacja w Mołdawii, którą Rosja próbuje wciągnąć w brutalną wojnę z Ukrainą.</p><br clear="all" />

## Andrzej Duda liderem rankingu zaufania. Donald Tusk na przeciwnym biegunie
 - [https://wydarzenia.interia.pl/kraj/news-andrzej-duda-liderem-rankingu-zaufania-donald-tusk-na-przeci,nId,6625588](https://wydarzenia.interia.pl/kraj/news-andrzej-duda-liderem-rankingu-zaufania-donald-tusk-na-przeci,nId,6625588)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 10:58:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-andrzej-duda-liderem-rankingu-zaufania-donald-tusk-na-przeci,nId,6625588"><img align="left" alt="Andrzej Duda liderem rankingu zaufania. Donald Tusk na przeciwnym biegunie" src="https://i.iplsc.com/andrzej-duda-liderem-rankingu-zaufania-donald-tusk-na-przeci/000GTO9HM2G2XK2L-C321.jpg" /></a>Prezydent Andrzej Duda, szef MON Mariusz Błaszczak, prezydent Warszawy Rafał Trzaskowski i premier Mateusz Morawiecki to liderzy rankingu zaufania w lutym - wynika z sondażu CBOS. Z największą nieufnością spotyka się szef PO Donald Tusk i prezes PiS Jarosław Kaczyński.</p><br clear="all" />

## Piszesz tak usprawiedliwienie dla dziecka w szkole? Robisz błąd
 - [https://wydarzenia.interia.pl/kraj/news-piszesz-tak-usprawiedliwienie-dla-dziecka-w-szkole-robisz-bl,nId,6623557](https://wydarzenia.interia.pl/kraj/news-piszesz-tak-usprawiedliwienie-dla-dziecka-w-szkole-robisz-bl,nId,6623557)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 10:56:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-piszesz-tak-usprawiedliwienie-dla-dziecka-w-szkole-robisz-bl,nId,6623557"><img align="left" alt="Piszesz tak usprawiedliwienie dla dziecka w szkole? Robisz błąd" src="https://i.iplsc.com/piszesz-tak-usprawiedliwienie-dla-dziecka-w-szkole-robisz-bl/000EE5QHPIIYE0WI-C321.jpg" /></a>Spora część rodziców zastanawia się, jak poprawnie napisać usprawiedliwienie dla dziecka w szkole. Przez wiele lat dominował model, w którym podawano przyczyny nieobecności ucznia. Okazuje się jednak, że usprawiedliwienie dla dziecka w szkole nie musi zawierać informacji, jak nasza pociecha spędzała czas, gdy nie było jej na zajęciach. </p><br clear="all" />

## Syn zabił matkę i odebrał sobie życie. Dramat we Wrocławiu
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-syn-zabil-matke-i-odebral-sobie-zycie-dramat-we-wroclawiu,nId,6625602](https://wydarzenia.interia.pl/dolnoslaskie/news-syn-zabil-matke-i-odebral-sobie-zycie-dramat-we-wroclawiu,nId,6625602)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 10:52:27+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-syn-zabil-matke-i-odebral-sobie-zycie-dramat-we-wroclawiu,nId,6625602"><img align="left" alt="Syn zabił matkę i odebrał sobie życie. Dramat we Wrocławiu" src="https://i.iplsc.com/syn-zabil-matke-i-odebral-sobie-zycie-dramat-we-wroclawiu/000GTOB4GYKX1BJR-C321.jpg" /></a>Nowe fakty ws. tragedii we Wrocławiu. W piątek w jednej z kamienic na rynku znaleziono ciała dwóch osób. Według wstępnych ustaleń doszło do samobójstwa rozszerzonego - syn najpierw zabił własną matkę, a następnie odebrał sobie życie. </p><br clear="all" />

## Jacek Majchrowski w objęciach PiS
 - [https://wydarzenia.interia.pl/malopolskie/news-jacek-majchrowski-w-objeciach-pis,nId,6615803](https://wydarzenia.interia.pl/malopolskie/news-jacek-majchrowski-w-objeciach-pis,nId,6615803)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 10:42:35+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-jacek-majchrowski-w-objeciach-pis,nId,6615803"><img align="left" alt="Jacek Majchrowski w objęciach PiS" src="https://i.iplsc.com/jacek-majchrowski-w-objeciach-pis/000GTNPCWFFTYAL4-C321.jpg" /></a>Prezydent Krakowa Jacek Majchrowski od kilkunastu miesięcy zacieśnia współpracę z Prawem i Sprawiedliwością. Obie strony łączą wspólne polityczne interesy. Majchrowski już w 2018 r. mówił: - Nie wykluczam sojuszu z PiS. </p><br clear="all" />

## Tusk: Jesienią wygramy dla Polski
 - [https://wydarzenia.interia.pl/kraj/news-tusk-jesienia-wygramy-dla-polski,nId,6625578](https://wydarzenia.interia.pl/kraj/news-tusk-jesienia-wygramy-dla-polski,nId,6625578)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 10:31:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-jesienia-wygramy-dla-polski,nId,6625578"><img align="left" alt="Tusk: Jesienią wygramy dla Polski" src="https://i.iplsc.com/tusk-jesienia-wygramy-dla-polski/000GTO72W62V8GP4-C321.jpg" /></a>- Jesienią wygramy dla Polski wybory, jesteśmy do tego gotowi - stwierdził Donald Tusk podczas wyjazdowego posiedzenia klubu parlamentarnego Koalicji Obywatelskiej w Łodzi. Lider PO zapowiedział też, że pierwszy rok programu Kredyt 0 proc. będzie kosztował cztery miliardy złotych.</p><br clear="all" />

## Pożar w Choroszczy. Śledztwo dotyczy dokonania zabójstwa
 - [https://wydarzenia.interia.pl/podlaskie/news-pozar-w-choroszczy-sledztwo-dotyczy-dokonania-zabojstwa,nId,6625566](https://wydarzenia.interia.pl/podlaskie/news-pozar-w-choroszczy-sledztwo-dotyczy-dokonania-zabojstwa,nId,6625566)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 10:21:51+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-pozar-w-choroszczy-sledztwo-dotyczy-dokonania-zabojstwa,nId,6625566"><img align="left" alt="Pożar w Choroszczy. Śledztwo dotyczy dokonania zabójstwa" src="https://i.iplsc.com/pozar-w-choroszczy-sledztwo-dotyczy-dokonania-zabojstwa/000GTGCSBIMNDUAR-C321.jpg" /></a>Nowe informacje w sprawie tragicznego pożaru w Choroszczy. Jak informują służby, śledztwo będzie dotyczyło dokonania zabójstwa i doprowadzenia do pożaru. Działaniami będzie zawiadywać Prokuratura Okręgowa w Białymstoku. Główna obecnie hipoteza zakłada, że 45-letni mężczyzna podpalił dom, a w pożarze zginął on i trójka jego dzieci.</p><br clear="all" />

## Media: Rosyjska rafineria zaatakowana przy użyciu dronów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosyjska-rafineria-zaatakowana-przy-uzyciu-dronow,nId,6625510](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosyjska-rafineria-zaatakowana-przy-uzyciu-dronow,nId,6625510)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 10:17:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosyjska-rafineria-zaatakowana-przy-uzyciu-dronow,nId,6625510"><img align="left" alt="Media: Rosyjska rafineria zaatakowana przy użyciu dronów" src="https://i.iplsc.com/media-rosyjska-rafineria-zaatakowana-przy-uzyciu-dronow/000GTNT0JAS7KCWK-C321.jpg" /></a>W Kraju Krasnodarskim w Rosji rafineria w mieście Tuapse została zaatakowana przy użyciu dwóch dronów - poinformowały niezależne rosyjskie media. Urządzenia prawdopodobnie nie dotarły do wyznaczonego celu i rozbiły się w pobliżu magazynu ropy naftowej.
</p><br clear="all" />

## Lublin: Wjechał w pieszą i dziecko na pasach. Kobieta nie żyje
 - [https://wydarzenia.interia.pl/lubelskie/news-lublin-wjechal-w-piesza-i-dziecko-na-pasach-kobieta-nie-zyje,nId,6625487](https://wydarzenia.interia.pl/lubelskie/news-lublin-wjechal-w-piesza-i-dziecko-na-pasach-kobieta-nie-zyje,nId,6625487)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 10:03:17+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-lublin-wjechal-w-piesza-i-dziecko-na-pasach-kobieta-nie-zyje,nId,6625487"><img align="left" alt="Lublin: Wjechał w pieszą i dziecko na pasach. Kobieta nie żyje" src="https://i.iplsc.com/lublin-wjechal-w-piesza-i-dziecko-na-pasach-kobieta-nie-zyje/000GTNRI3EO84XF8-C321.jpg" /></a>Zmarła kobieta, która w połowie lutego, przechodząc z dzieckiem przez przejście dla pieszych w Lublinie, została potrącona przez samochód dostawczy. Dwuletniemu chłopcu nic się nie stało. Kobieta, która była opiekunką dziecka, trafiła do szpitala w ciężkim stanie.</p><br clear="all" />

## Niezwykły gest pilota. Celowo zboczył z trasy lotu
 - [https://wydarzenia.interia.pl/zagranica/news-niezwykly-gest-pilota-celowo-zboczyl-z-trasy-lotu,nId,6625544](https://wydarzenia.interia.pl/zagranica/news-niezwykly-gest-pilota-celowo-zboczyl-z-trasy-lotu,nId,6625544)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 09:57:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niezwykly-gest-pilota-celowo-zboczyl-z-trasy-lotu,nId,6625544"><img align="left" alt="Niezwykły gest pilota. Celowo zboczył z trasy lotu" src="https://i.iplsc.com/niezwykly-gest-pilota-celowo-zboczyl-z-trasy-lotu/000GTO0B9GLK1JNM-C321.jpg" /></a>Pilot linii easyJet zauważył w trakcie lotu spektakularną zorzę polarną. Aby wszyscy pasażerowie samolotu mogli dokładnie się jej przyjrzeć, maszyna zboczyła z zaplanowanej trasy i okrążyła zjawisko na niebie.</p><br clear="all" />

## Chiny: Powstało urządzenie do całowania na odległość
 - [https://wydarzenia.interia.pl/zagranica/news-chiny-powstalo-urzadzenie-do-calowania-na-odleglosc,nId,6625478](https://wydarzenia.interia.pl/zagranica/news-chiny-powstalo-urzadzenie-do-calowania-na-odleglosc,nId,6625478)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 09:50:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chiny-powstalo-urzadzenie-do-calowania-na-odleglosc,nId,6625478"><img align="left" alt="Chiny: Powstało urządzenie do całowania na odległość" src="https://i.iplsc.com/chiny-powstalo-urzadzenie-do-calowania-na-odleglosc/000GTNN0SI6DCN9A-C321.jpg" /></a>W sieci prawdziwą furorę robi najnowszy chiński wynalazek. Urządzenie ma kształt ust i przeznaczone jest - jak przekonują producenci - dla par żyjących w związkach na odległość. </p><br clear="all" />

## Pakt senacki 2.0 stanie się faktem. Opozycja podpisze porozumienie ramowe
 - [https://wydarzenia.interia.pl/kraj/news-pakt-senacki-2-0-stanie-sie-faktem-opozycja-podpisze-porozum,nId,6625497](https://wydarzenia.interia.pl/kraj/news-pakt-senacki-2-0-stanie-sie-faktem-opozycja-podpisze-porozum,nId,6625497)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 09:50:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pakt-senacki-2-0-stanie-sie-faktem-opozycja-podpisze-porozum,nId,6625497"><img align="left" alt="Pakt senacki 2.0 stanie się faktem. Opozycja podpisze porozumienie ramowe" src="https://i.iplsc.com/pakt-senacki-2-0-stanie-sie-faktem-opozycja-podpisze-porozum/000GTNR2RKJ1KQ0S-C321.jpg" /></a>Opozycja o godz. 14:30 podpisze tzw. pakt senacki przed najbliższymi wyborami. Oznacza to, że w jednomandatowych okręgach do Senatu partie opozycyjne wystawią wspólnych kandydatów. Słyszymy jednak, że podział miejsc nie jest łatwy, a szczegółowe ustalenia i personalia poznamy dopiero w kwietniu. Już dziś wiadomo jednak, że najwięcej senackich szans zgarnie Platforma Obywatelska.</p><br clear="all" />

## Strzelanina obok szkoły w Niemczech. "Dwóch poważnie rannych"
 - [https://wydarzenia.interia.pl/zagranica/news-strzelanina-obok-szkoly-w-niemczech-dwoch-powaznie-rannych,nId,6625502](https://wydarzenia.interia.pl/zagranica/news-strzelanina-obok-szkoly-w-niemczech-dwoch-powaznie-rannych,nId,6625502)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 09:16:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-strzelanina-obok-szkoly-w-niemczech-dwoch-powaznie-rannych,nId,6625502"><img align="left" alt="Strzelanina obok szkoły w Niemczech. &quot;Dwóch poważnie rannych&quot;" src="https://i.iplsc.com/strzelanina-obok-szkoly-w-niemczech-dwoch-powaznie-rannych/000GDJY75Q92KQ0P-C321.jpg" /></a>Niemieckie media donosza o strzelaninie, która miała miejsce w pobliżu szkoły w miejscowości Bramsche. W wyniku zdarzenia dwie osoby miały zostać &quot;poważnie ranne&quot;.</p><br clear="all" />

## Dodatek węglowy w 2023 roku. Czy można jeszcze otrzymać 3000 złotych?
 - [https://wydarzenia.interia.pl/kraj/news-dodatek-weglowy-w-2023-roku-czy-mozna-jeszcze-otrzymac-3000-,nId,6623969](https://wydarzenia.interia.pl/kraj/news-dodatek-weglowy-w-2023-roku-czy-mozna-jeszcze-otrzymac-3000-,nId,6623969)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 09:16:25+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dodatek-weglowy-w-2023-roku-czy-mozna-jeszcze-otrzymac-3000-,nId,6623969"><img align="left" alt="Dodatek węglowy w 2023 roku. Czy można jeszcze otrzymać 3000 złotych?" src="https://i.iplsc.com/dodatek-weglowy-w-2023-roku-czy-mozna-jeszcze-otrzymac-3000/000GDE2A06VWWVNO-C321.jpg" /></a>Dodatek węglowy miał być zastrzykiem gotówki do domowego budżetu Polaków. Zatrważający wzrost cen surowca mógł pozbawić miliony gospodarstw domowych ogrzewania. Sprawdź, czy w 2023 roku można jeszcze otrzymać 3000 złotych dopłaty.</p><br clear="all" />

## UFO nad Petersburgiem. Rosja musiała zamknąć przestrzeń powietrzną
 - [https://wydarzenia.interia.pl/zagranica/news-ufo-nad-petersburgiem-rosja-musiala-zamknac-przestrzen-powie,nId,6625484](https://wydarzenia.interia.pl/zagranica/news-ufo-nad-petersburgiem-rosja-musiala-zamknac-przestrzen-powie,nId,6625484)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 08:57:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ufo-nad-petersburgiem-rosja-musiala-zamknac-przestrzen-powie,nId,6625484"><img align="left" alt="UFO nad Petersburgiem. Rosja musiała zamknąć przestrzeń powietrzną" src="https://i.iplsc.com/ufo-nad-petersburgiem-rosja-musiala-zamknac-przestrzen-powie/000GTNLQVFJEERPA-C321.jpg" /></a>W związku z pojawieniem się niezidentyfikowanego obiektu latającego w promieniu 200 kilometrów od Petersburga zamknięto przestrzeń powietrzną. Rosyjskie siły powietrzne poderwały myśliwce, które miały zbadać zagrożenie.</p><br clear="all" />

## "Polak kupi nawet dziurę w ziemi". Deweloperzy żerują na naszym głodzie
 - [https://wydarzenia.interia.pl/kraj/news-polak-kupi-nawet-dziure-w-ziemi-deweloperzy-zeruja-na-naszym,nId,6624025](https://wydarzenia.interia.pl/kraj/news-polak-kupi-nawet-dziure-w-ziemi-deweloperzy-zeruja-na-naszym,nId,6624025)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 08:53:46+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polak-kupi-nawet-dziure-w-ziemi-deweloperzy-zeruja-na-naszym,nId,6624025"><img align="left" alt="&quot;Polak kupi nawet dziurę w ziemi&quot;. Deweloperzy żerują na naszym głodzie" src="https://i.iplsc.com/polak-kupi-nawet-dziure-w-ziemi-deweloperzy-zeruja-na-naszym/000GTLNRAWNN9D4E-C321.jpg" /></a>- W Polsce w kwestii mieszkalnictwa puszczamy wszystko na rympał i patrzymy, czy będzie płonąć. To taka nasza swojska forma zarządzania strategicznego - mówi w rozmowie z Interią  urbanista dr Łukasz Drozda. - Mamy w społeczeństwie i na rynku gigantyczną presję na mieszkania własnościowe. Znika wszystko, co zostanie wpuszczone w obieg. Polak kupi nawet dziurę w ziemi. To psuje rynek, bo po taniości powstają fatalne mieszkania niskiej jakości, które nakręcają zjawisko ubóstwa mieszkaniowego - diagnozuje autor właśnie wydanej książki &quot;Dziury w...</p><br clear="all" />

## Kobiety spędziły pięć dni w samochodzie, bo utknęły w lesie. Zgubiły się
 - [https://wydarzenia.interia.pl/zagranica/news-kobiety-spedzily-piec-dni-w-samochodzie-bo-utknely-w-lesie-z,nId,6625433](https://wydarzenia.interia.pl/zagranica/news-kobiety-spedzily-piec-dni-w-samochodzie-bo-utknely-w-lesie-z,nId,6625433)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 08:53:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kobiety-spedzily-piec-dni-w-samochodzie-bo-utknely-w-lesie-z,nId,6625433"><img align="left" alt="Kobiety spędziły pięć dni w samochodzie, bo utknęły w lesie. Zgubiły się" src="https://i.iplsc.com/kobiety-spedzily-piec-dni-w-samochodzie-bo-utknely-w-lesie-z/000GTNP6WGLOLX04-C321.jpg" /></a>- Kiedy otworzyłem drzwi samochodu, byłem w totalnym szoku - mówi leśniczy, który znalazł dwie zaginione kobiety w lesie. Ich auto utknęło w śniegu, bez paliwa. Kobiety zostały więc w środku, bez ogrzewania, kiedy termometry pokazywały minusową temperaturę. Intensywne poszukiwania kobiet trwały pięć dni.  </p><br clear="all" />

## Ludzkie szczątki w ciele rekina. To prawdopodobnie zaginiony 32-latek
 - [https://wydarzenia.interia.pl/zagranica/news-ludzkie-szczatki-w-ciele-rekina-to-prawdopodobnie-zaginiony-,nId,6625467](https://wydarzenia.interia.pl/zagranica/news-ludzkie-szczatki-w-ciele-rekina-to-prawdopodobnie-zaginiony-,nId,6625467)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 08:37:07+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ludzkie-szczatki-w-ciele-rekina-to-prawdopodobnie-zaginiony-,nId,6625467"><img align="left" alt="Ludzkie szczątki w ciele rekina. To prawdopodobnie zaginiony 32-latek" src="https://i.iplsc.com/ludzkie-szczatki-w-ciele-rekina-to-prawdopodobnie-zaginiony/000GTNHCIEHAYY04-C321.jpg" /></a>Diego Barria, ojciec trojga dzieci, był ostatni raz widziany 18 lutego. Mężczyzna jechał quadem wzdłuż południowego wybrzeża Argentyny. 35-latek zaginął bez śladu. Wszystko wskazuje na to, że wpadł do wody i padł ofiarą rekina. W ciele jednego z nich znaleziono bowiem ludzkie szczątki z tatuażem identycznym jak ten, który miał zaginiony 32-latek.</p><br clear="all" />

## Afganistan: Talibowie zabili jednego z dowódców Państwa Islamskiego
 - [https://wydarzenia.interia.pl/zagranica/news-afganistan-talibowie-zabili-jednego-z-dowodcow-panstwa-islam,nId,6625416](https://wydarzenia.interia.pl/zagranica/news-afganistan-talibowie-zabili-jednego-z-dowodcow-panstwa-islam,nId,6625416)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 08:29:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-afganistan-talibowie-zabili-jednego-z-dowodcow-panstwa-islam,nId,6625416"><img align="left" alt="Afganistan: Talibowie zabili jednego z dowódców Państwa Islamskiego" src="https://i.iplsc.com/afganistan-talibowie-zabili-jednego-z-dowodcow-panstwa-islam/000GTNER6HW3SNWN-C321.jpg" /></a>Talibowie poinformowali, że ich siły bezpieczeństwa zabiły dowódcę Państwa Islamskiego w Afganistanie. Według przedstawiciela talibskiego rządu, mężczyzna był odpowiedzialny za ataki na misje dyplomatyczne w stolicy Afganistanu, Kabulu.</p><br clear="all" />

## Biały Dom kazał urzędnikom usunąć TikToka. Chiny odpowiadają
 - [https://wydarzenia.interia.pl/zagranica/news-bialy-dom-kazal-urzednikom-usunac-tiktoka-chiny-odpowiadaja,nId,6625441](https://wydarzenia.interia.pl/zagranica/news-bialy-dom-kazal-urzednikom-usunac-tiktoka-chiny-odpowiadaja,nId,6625441)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 08:12:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialy-dom-kazal-urzednikom-usunac-tiktoka-chiny-odpowiadaja,nId,6625441"><img align="left" alt="Biały Dom kazał urzędnikom usunąć TikToka. Chiny odpowiadają" src="https://i.iplsc.com/bialy-dom-kazal-urzednikom-usunac-tiktoka-chiny-odpowiadaja/000GTN32P5KFI8MF-C321.jpg" /></a>Amerykańskie agencje rządowe nakazały wyeliminowanie chińskiej aplikacji TikTok z federalnych urządzeń i systemów. Taką decyzję podjął Biały Dom. Sprzeciwia się jej Amerykański Związek Swobód Obywatelskich. Stanowisko zajęty też władze w Pekinie.</p><br clear="all" />

## Nietypowy strój Łukaszenki na lotnisku. Leci do Chin w dresie
 - [https://wydarzenia.interia.pl/zagranica/news-nietypowy-stroj-lukaszenki-na-lotnisku-leci-do-chin-w-dresie,nId,6625408](https://wydarzenia.interia.pl/zagranica/news-nietypowy-stroj-lukaszenki-na-lotnisku-leci-do-chin-w-dresie,nId,6625408)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 07:43:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nietypowy-stroj-lukaszenki-na-lotnisku-leci-do-chin-w-dresie,nId,6625408"><img align="left" alt="Nietypowy strój Łukaszenki na lotnisku. Leci do Chin w dresie" src="https://i.iplsc.com/nietypowy-stroj-lukaszenki-na-lotnisku-leci-do-chin-w-dresie/000GTMOX5A2ETXBO-C321.jpg" /></a>We wtorek Alaksandr Łukaszenka rozpoczął swoją podróż do Chin, gdzie ma spotkać się z Xi Jinpingiem. Najwidoczniej jednak przywódca Białorusi nad wizerunek ceni sobie wygodę, bo wchodząc na pokład samolotu wybrał niecodzienny dla polityka strój.</p><br clear="all" />

## Sabotaż na terenie Białorusi. Służby na tropie podejrzanego 29-latka
 - [https://wydarzenia.interia.pl/zagranica/news-sabotaz-na-terenie-bialorusi-sluzby-na-tropie-podejrzanego-2,nId,6625387](https://wydarzenia.interia.pl/zagranica/news-sabotaz-na-terenie-bialorusi-sluzby-na-tropie-podejrzanego-2,nId,6625387)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 07:40:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sabotaz-na-terenie-bialorusi-sluzby-na-tropie-podejrzanego-2,nId,6625387"><img align="left" alt="Sabotaż na terenie Białorusi. Służby na tropie podejrzanego 29-latka " src="https://i.iplsc.com/sabotaz-na-terenie-bialorusi-sluzby-na-tropie-podejrzanego-2/000GTMLXOM4P83N4-C321.jpg" /></a>Białoruskie siły bezpieczeństwa poszukują podejrzanego o popełnienie &quot;szczególnie niebezpiecznego przestępstwa&quot; - poinformował portal Zerkalo. Chodzi o wydarzenia z niedzieli, gdy na lotnisku wojskowym w Maczuliszczach doszło do sabotażu. Zdaniem reżimu, czynu miał się dopuścić pochodzący z Krymu Nikolaj Szwec.</p><br clear="all" />

## Banaś: NIK przesłuchiwał Obajtka. Chodzi o kontrolę w MAP
 - [https://wydarzenia.interia.pl/kraj/news-banas-nik-przesluchiwal-obajtka-chodzi-o-kontrole-w-map,nId,6625411](https://wydarzenia.interia.pl/kraj/news-banas-nik-przesluchiwal-obajtka-chodzi-o-kontrole-w-map,nId,6625411)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 07:15:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-banas-nik-przesluchiwal-obajtka-chodzi-o-kontrole-w-map,nId,6625411"><img align="left" alt="Banaś: NIK przesłuchiwał Obajtka. Chodzi o kontrolę w MAP" src="https://i.iplsc.com/banas-nik-przesluchiwal-obajtka-chodzi-o-kontrole-w-map/000FCX9ST3YNCT2T-C321.jpg" /></a>- Prezes Daniel Obajtek był przesłuchiwany przez kontrolerów - powiedział prezes NIK Marian Banaś. Doprecyzował, że chodzi o kontrolę w Ministerstwie Aktywów Państwowych. Jak powiedział Banaś, </p><br clear="all" />

## Banaś: NIK przesłuchiwała Obajtka. Chodzi o kontrolę w MAP
 - [https://wydarzenia.interia.pl/kraj/news-banas-nik-przesluchiwala-obajtka-chodzi-o-kontrole-w-map,nId,6625411](https://wydarzenia.interia.pl/kraj/news-banas-nik-przesluchiwala-obajtka-chodzi-o-kontrole-w-map,nId,6625411)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 07:15:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-banas-nik-przesluchiwala-obajtka-chodzi-o-kontrole-w-map,nId,6625411"><img align="left" alt="Banaś: NIK przesłuchiwała Obajtka. Chodzi o kontrolę w MAP" src="https://i.iplsc.com/banas-nik-przesluchiwala-obajtka-chodzi-o-kontrole-w-map/000FCX9ST3YNCT2T-C321.jpg" /></a>- Prezes Daniel Obajtek był przesłuchiwany przez kontrolerów - powiedział prezes NIK Marian Banaś. Doprecyzował, że chodzi o kontrolę w Ministerstwie Aktywów Państwowych. Zapowiedział również, że NIK planuje kontrolę w Narodowym Centrum Badań i Rozwoju.</p><br clear="all" />

## "Pokojowe przemiany? To śmieszne". Białoruska opozycja nie ma wątpliwości
 - [https://wydarzenia.interia.pl/zagranica/news-pokojowe-przemiany-to-smieszne-bialoruska-opozycja-nie-ma-wa,nId,6625386](https://wydarzenia.interia.pl/zagranica/news-pokojowe-przemiany-to-smieszne-bialoruska-opozycja-nie-ma-wa,nId,6625386)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 07:06:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pokojowe-przemiany-to-smieszne-bialoruska-opozycja-nie-ma-wa,nId,6625386"><img align="left" alt="&quot;Pokojowe przemiany? To śmieszne&quot;. Białoruska opozycja nie ma wątpliwości" src="https://i.iplsc.com/pokojowe-przemiany-to-smieszne-bialoruska-opozycja-nie-ma-wa/000GTMKHD0VFKL8C-C321.jpg" /></a>&quot;Pokojowe przemiany? To śmieszne. Chyba że siłą zmusimy Łukaszenkę, by usiadł do stołu. Innych opcji nie ma&quot; - mówi w wywiadzie Alaksandr Azarau, szef opozycyjnego ruchu BYPOL. Opowiedział o kulisach akcji uszkodzeniu samolotu A-50 oraz o szkoleniach białoruskich partyzantów w Polsce.</p><br clear="all" />

## Idzie załamanie pogody. Możliwe wichury przekraczające 100 km/h
 - [https://wydarzenia.interia.pl/kraj/news-idzie-zalamanie-pogody-mozliwe-wichury-przekraczajace-100-km,nId,6625371](https://wydarzenia.interia.pl/kraj/news-idzie-zalamanie-pogody-mozliwe-wichury-przekraczajace-100-km,nId,6625371)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 06:48:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-idzie-zalamanie-pogody-mozliwe-wichury-przekraczajace-100-km,nId,6625371"><img align="left" alt="Idzie załamanie pogody. Możliwe wichury przekraczające 100 km/h" src="https://i.iplsc.com/idzie-zalamanie-pogody-mozliwe-wichury-przekraczajace-100-km/000GTMI7HP6MPN6W-C321.jpg" /></a>W najbliższych dniach pogoda w Polsce sporo namiesza. Chociaż wtorek będzie dosyć spokojny, czeka nas załamanie pogody, za które będzie odpowiedzialny głęboki cyklon, który rozwinie się nad Europą. Przyniesie on ze sobą prawdziwe wichury. Niewykluczone, że prędkość wiatru przekroczy w naszym kraju 100 km/h.</p><br clear="all" />

## Kryzys żywnościowy w Korei Północnej. Kim Dzong Un wzywa do zmian
 - [https://wydarzenia.interia.pl/zagranica/news-kryzys-zywnosciowy-w-korei-polnocnej-kim-dzong-un-wzywa-do-z,nId,6625388](https://wydarzenia.interia.pl/zagranica/news-kryzys-zywnosciowy-w-korei-polnocnej-kim-dzong-un-wzywa-do-z,nId,6625388)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 06:48:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kryzys-zywnosciowy-w-korei-polnocnej-kim-dzong-un-wzywa-do-z,nId,6625388"><img align="left" alt="Kryzys żywnościowy w Korei Północnej. Kim Dzong Un wzywa do zmian" src="https://i.iplsc.com/kryzys-zywnosciowy-w-korei-polnocnej-kim-dzong-un-wzywa-do-z/000GTMK6OPHEH8OS-C321.jpg" /></a>Korea Północna zmaga się z pogłębiającym się problemem niedoboru żywności. Z tego powodu, jak informują państwowe media, przywódca tego kraju Kim Dzong Un wezwał do &quot;fundamentalnej transformacji&quot; w rolnictwie. Zmiany mają nastąpić w ciągu najbliższych kilku lat.</p><br clear="all" />

## Wielka Brytania dogadała się z UE. Komunikat z Białego Domu
 - [https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-dogadala-sie-z-ue-komunikat-z-bialego-domu,nId,6625362](https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-dogadala-sie-z-ue-komunikat-z-bialego-domu,nId,6625362)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 05:29:42+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-dogadala-sie-z-ue-komunikat-z-bialego-domu,nId,6625362"><img align="left" alt="Wielka Brytania dogadała się z UE. Komunikat z Białego Domu" src="https://i.iplsc.com/wielka-brytania-dogadala-sie-z-ue-komunikat-z-bialego-domu/000AUZUAR8VSA097-C321.jpg" /></a>Wielka Brytania porozumiała się z Unią Europejską w sprawie zmian w protokole północnoirlandzkim. - Dokonaliśmy decydującego przełomu. Wspólnie zmieniliśmy pierwotny protokół i dziś ogłaszamy nowe ramy windsorskie - zaznaczył premier Rishi Sunak. Do zmian w porozumieniu, które od lat było problemem na linii Londyn-Bruksela, odniósł się prezydent USA Joe Biden.</p><br clear="all" />

## Wojna w Ukrainie. 370. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280619](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280619)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 04:38:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280619"><img align="left" alt="Wojna w Ukrainie. 370. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo/000GTMFMY03I9QXL-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 370. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280711](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280711)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 04:38:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280711"><img align="left" alt="Wojna w Ukrainie. 370. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo/000GTMFMY03I9QXL-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 370. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280809](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280809)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 04:38:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280809"><img align="left" alt="Wojna w Ukrainie. 370. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo/000GTMFMY03I9QXL-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 370. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280919](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280919)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-28 04:38:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo,nzId,3844,akt,280919"><img align="left" alt="Wojna w Ukrainie. 370. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-370-dzien-inwazji-rosji-relacja-na-zywo/000GTMFMY03I9QXL-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

