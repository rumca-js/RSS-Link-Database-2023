# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Titans drop off recently released player's belongings on his doorstep in garbage bags
 - [https://www.foxnews.com/sports/titans-drop-recently-released-players-belongings-doorstep-garbage-bags](https://www.foxnews.com/sports/titans-drop-recently-released-players-belongings-doorstep-garbage-bags)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 23:16:59+00:00

The Tennessee Titans released three-time Pro Bowler Taylor Lewan last week, but despite his on-field success, he wasn't given the most gracious farewell.

## NFL kept lewd footage of women cataloged with 'sexually degrading' descriptions, ex-employee says in lawsuit
 - [https://www.foxnews.com/sports/nfl-kept-lewd-footage-women-cataloged-sexually-degrading-descriptions-ex-employee-says-lawsui](https://www.foxnews.com/sports/nfl-kept-lewd-footage-women-cataloged-sexually-degrading-descriptions-ex-employee-says-lawsui)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 23:03:31+00:00

A former NFL HR employee claimed in a lawsuit earlier this year that NFL Films, the league's production company, held footage of women with "sexually degrading remarks."

## Indiana suspect shot by police remains in stable condition
 - [https://www.foxnews.com/us/indiana-suspect-shot-police-remains-stable-condition](https://www.foxnews.com/us/indiana-suspect-shot-police-remains-stable-condition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 23:03:28+00:00

Christopher Crouch, 36, of Nineveh, Indiana, remains in stable condition after being shot by a state trooper after fleeing officers serving multiple felony warrants.

## ‘My Three Sons' actress Dawn Lyn recovering after brain surgery and coma, co-star says: ‘Miracles do happen’
 - [https://www.foxnews.com/entertainment/my-three-sons-actress-dawn-lyn-recovering-brain-surgery-coma-co-star-says](https://www.foxnews.com/entertainment/my-three-sons-actress-dawn-lyn-recovering-brain-surgery-coma-co-star-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 23:02:58+00:00

Dawn Lyn, the sister of former teen idol Leif Garrett, spoke to her "My Three Sons" co-star Tina Cole on Sunday. The former child star had a major health battle in late 2022.

## ‘Peter Pan & Wendy’ star says production hired team to fix franchise’s ‘problematic’ Native American depiction
 - [https://www.foxnews.com/media/peter-pan-wendy-star-production-hired-team-fix-franchises-problematic-native-american-depiction](https://www.foxnews.com/media/peter-pan-wendy-star-production-hired-team-fix-franchises-problematic-native-american-depiction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 23:00:13+00:00

An actress starring in the new Diseny+ "Peter Pan" reboot claimed the film is taking pains to ensure its depiction of Native Americans is respectful.

## Wray responds to FBI critiques over Hunter laptop, Trump raid, Ray Epps: We're 'on the American people's side'
 - [https://www.foxnews.com/media/wray-responds-fbi-critiques-hunter-laptop-trump-raid-ray-epps-on-american-peoples-side](https://www.foxnews.com/media/wray-responds-fbi-critiques-hunter-laptop-trump-raid-ray-epps-on-american-peoples-side)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:51:58+00:00

Christopher Wray, the Trump-appointed director of the Federal Bureau of Investigation, joined 'Special Report' for a wide-ranging interview on Tuesday.

## Michigan judge sets August deadline for new pipes in Flint
 - [https://www.foxnews.com/us/michigan-judge-sets-august-deadline-new-pipes-flint](https://www.foxnews.com/us/michigan-judge-sets-august-deadline-new-pipes-flint)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:51:31+00:00

U.S. District Judge David Lawson has set an Aug. 1 deadline for the city of Flint, Michigan, to replace all remaining lead and steel water lines.

## California teacher secretly recorded students in all-gender restroom: police
 - [https://www.foxnews.com/us/california-teacher-secretly-recorded-students-all-gender-restroom-police](https://www.foxnews.com/us/california-teacher-secretly-recorded-students-all-gender-restroom-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:51:10+00:00

A California teacher arrested Monday is charged with placing recording devices in an all-gender restroom near the school's pool, police say.

## Musician Ben Kweller’s 16-year-old son dead: ‘He was a true legend’
 - [https://www.foxnews.com/entertainment/musician-ben-kweller-16-year-old-son-dead](https://www.foxnews.com/entertainment/musician-ben-kweller-16-year-old-son-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:45:54+00:00

Ben Kweller, a musician who has toured with Ed Sheeran, said his 16-year-old son Dorian Zev died Monday night. The teenager reportedly died in a car accident.

## Virginia police fatally shoot man who pointed gun at them
 - [https://www.foxnews.com/us/virginia-police-fatally-shoot-man-pointed-gun-them](https://www.foxnews.com/us/virginia-police-fatally-shoot-man-pointed-gun-them)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:36:26+00:00

Virginia police officers fatally shot a man who pointed a gun at them on Tuesday. The man ran into a wooded area where he fired several rounds before he was shot.

## New Hampshire judge rules against holding psych patients in emergency rooms
 - [https://www.foxnews.com/us/new-hampshire-judge-rules-against-holding-psych-patients-emergency-rooms](https://www.foxnews.com/us/new-hampshire-judge-rules-against-holding-psych-patients-emergency-rooms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:33:08+00:00

U.S. District Court Judge Landya McCafferty ruled Thursday that New Hampshire's practice of involuntarily holding psychiatric patients in emergency rooms is unconstitutional

## New Jersey Gov. Murphy unveils $51.3B budget plan
 - [https://www.foxnews.com/politics/new-jersey-gov-murphy-unveils-51-3b-budget-plan](https://www.foxnews.com/politics/new-jersey-gov-murphy-unveils-51-3b-budget-plan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:31:24+00:00

Democratic New Jersey Gov. Phil Murphy on Tuesday unveiled his $53.1 billion budget proposal for the state's 2024 fiscal year, an approximate 5% spending increase over 2023.

## New 'bold glamour' TikTok filter blasted as 'psychological warfare and pure evil'
 - [https://www.foxnews.com/media/new-bold-glamour-tiktok-filter-blasted-psychological-warfare-pure-evil](https://www.foxnews.com/media/new-bold-glamour-tiktok-filter-blasted-psychological-warfare-pure-evil)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:30:15+00:00

Social media users across both Twitter and TikTok blasted a new filter that many attacked as harmful to society for posing unrealistic beauty standards.

## 3 hospitalized after emergency crews respond to attack at LA-area jail
 - [https://www.foxnews.com/us/3-hospitalized-emergency-crews-respond-attack-la-area-jail](https://www.foxnews.com/us/3-hospitalized-emergency-crews-respond-attack-la-area-jail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:30:08+00:00

Three people have been hospitalized after emergency crews responded to an LA-area jail on Tuesday. Reports say nearly 20 people were injured in a mass casualty incident at the jail.

## House votes to kill Biden’s ‘woke’ ESG investment rule that props up ‘phony climate movement’
 - [https://www.foxnews.com/politics/house-votes-kill-bidens-woke-esg-investment-rule-props-up-phony-climate-movement](https://www.foxnews.com/politics/house-votes-kill-bidens-woke-esg-investment-rule-props-up-phony-climate-movement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:22:06+00:00

The House voted Tuesday to kill a Biden administration rule encouraging retirement plan fiduciaries to invest in ESG companies, which the GOP says is a disaster for retirees.

## New ‘Bachelor’ creates a 'no sex rule'
 - [https://www.foxnews.com/entertainment/new-bachelor-creates-no-sex-rule](https://www.foxnews.com/entertainment/new-bachelor-creates-no-sex-rule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:17:15+00:00

"The Bachelor" star Zach Shallcross says he's going "against the grain" and implementing a "no sex" rule for his upcoming fantasy suite dates.

## Popular artificial sweetener, erythritol, could raise risk of heart attack and stroke: study
 - [https://www.foxnews.com/health/popular-artificial-sweetener-erythritol-could-raise-risk-heart-attack-stroke-study](https://www.foxnews.com/health/popular-artificial-sweetener-erythritol-could-raise-risk-heart-attack-stroke-study)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:05:20+00:00

A popular artificial sweetener, erythritol, could raise the risk of heart attack and stroke, a new study from Cleveland Clinic revealed. The study was published in Nature Medicine.

## California Gov. Newsom officially ends COVID state of emergency nearly three years later
 - [https://www.foxnews.com/politics/california-gov-newsom-officially-ends-covid-state-emergency-nearly-three-years-later](https://www.foxnews.com/politics/california-gov-newsom-officially-ends-covid-state-emergency-nearly-three-years-later)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:03:04+00:00

California Gov. Gavin Newsom has officially ended the state's COVID-19 state of emergency, nearly three years after first issuing statewide state-at-home orders.

## Packers GM addresses Aaron Rodgers' future in Green Bay amid uncertainty: ‘All options are on the table’
 - [https://www.foxnews.com/sports/packers-gm-addresses-aaron-rodgers-future-green-bay-amid-uncertainty-all-options-are-on-the-table](https://www.foxnews.com/sports/packers-gm-addresses-aaron-rodgers-future-green-bay-amid-uncertainty-all-options-are-on-the-table)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:00:50+00:00

Green Bay Packers general manager Brian Gutekunst was noncommittal on Tuesday when asked if he wanted Aaron Rodgers back for the 2023 season.

## TikTok, Instagram influencer accused of ‘mistreating’ her dogs by online detractors defends herself
 - [https://www.foxnews.com/lifestyle/tiktok-instagram-influencer-accused-mistreating-dogs-online-detractors-defends-herself](https://www.foxnews.com/lifestyle/tiktok-instagram-influencer-accused-mistreating-dogs-online-detractors-defends-herself)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:00:25+00:00

A social media influencer is receiving backlash for allegedly mistreating her two dogs. The dog mom is defending her dogs' social media account, saying they are loved.

## Reddit users torch woman who stormed out of engagement dinner over no vegan options: ‘Rude and entitled’
 - [https://www.foxnews.com/media/reddit-users-torch-woman-stormed-engagement-dinner-over-no-vegan-options-rude-entitled](https://www.foxnews.com/media/reddit-users-torch-woman-stormed-engagement-dinner-over-no-vegan-options-rude-entitled)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 22:00:00+00:00

Reddit users trashed a vegan woman who made a scene at her host's engagement dinner because the restaurant did not provide sufficient vegan options for her.

## Ozzy Osbourne insists he's 'f---ing not dying' after canceling his tour but admits he's in 'constant pain'
 - [https://www.foxnews.com/entertainment/ozzy-osbourne-insists-not-dying-canceling-his-tour-admits-constant-pain](https://www.foxnews.com/entertainment/ozzy-osbourne-insists-not-dying-canceling-his-tour-admits-constant-pain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:58:53+00:00

Ozzy Osbourne claimed he's "f---ing not dying" in a new radio interview as he talked about canceling his tour and his health after his "life-altering" surgery last year.

## West, Northeast blanketed in snow as winter storms span coast to coast
 - [https://www.foxnews.com/us/west-northeast-blanketed-snow-winter-storms-span-coast-coast](https://www.foxnews.com/us/west-northeast-blanketed-snow-winter-storms-span-coast-coast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:56:38+00:00

A string of winter storms has left much of the United States covered in white, with snowy conditions reported from New England to Southern California.

## Kentucky man charged for murdering 3 officers found dead in his jail cell
 - [https://www.foxnews.com/us/kentucky-man-charged-murdering-3-officers-dead-his-jail-cell](https://www.foxnews.com/us/kentucky-man-charged-murdering-3-officers-dead-his-jail-cell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:55:28+00:00

A Kentucky man who was charged in the killings of three police officers was found dead in his jail cell. The man took his life Tuesday morning at the jail where he was being held.

## Tom Brady weighing roast special, instead of comedy career in latest post-NFL move: reports
 - [https://www.foxnews.com/sports/tom-brady-weighing-roast-instead-comedy-career-latest-post-nfl-move-reports](https://www.foxnews.com/sports/tom-brady-weighing-roast-instead-comedy-career-latest-post-nfl-move-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:51:11+00:00

The recently retired Tom Brady won't be launching a career as a stand-up comic, but instead could be in talks about starring in a roast comedy special, according to TMZ Sports.

## Ben & Jerry’s suppliers use migrant child labor, despite company's 'progressive' values
 - [https://www.foxnews.com/media/ben-jerrys-suppliers-use-migrant-child-labor-despite-companys-progressive-values](https://www.foxnews.com/media/ben-jerrys-suppliers-use-migrant-child-labor-despite-companys-progressive-values)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:42:34+00:00

Ben & Jerry's told Fox News Digital it is opposed to child labor, but a New York Times investigation found its suppliers use migrant child labor in milk production.

## Georgia man wrongfully convicted in Army veteran's murder could be cleared more than 70 years later
 - [https://www.foxnews.com/us/georgia-man-wrongfully-convicted-army-veterans-murder-cleared-years-later](https://www.foxnews.com/us/georgia-man-wrongfully-convicted-army-veterans-murder-cleared-years-later)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:40:43+00:00

A Georgia court will decide whether to formally dismiss a murder charge against a Black man stemming from a 1948 killing

## ISIS-affiliated Moroccan jailed for beheading European hikers kills himself in prison
 - [https://www.foxnews.com/world/isis-affiliated-moroccan-jailed-beheading-european-hikers-kills-himself-prison](https://www.foxnews.com/world/isis-affiliated-moroccan-jailed-beheading-european-hikers-kills-himself-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:38:11+00:00

A Moroccan convicted for being a member of an Islamic State-affiliated terror cell has killed himself in prison. The man was sentenced to death for beheading European hikers.

## Fox News Channel viewership crushes CNN, MSNBC in February as win streak hits two years
 - [https://www.foxnews.com/media/fox-news-channel-viewership-crushes-cnn-msnbc-february-win-streak-hits-two-years](https://www.foxnews.com/media/fox-news-channel-viewership-crushes-cnn-msnbc-february-win-streak-hits-two-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:36:45+00:00

Fox News Channel viewership has crushed CNN and MSNBC for two-consecutive years after dominating the news-heavy month of February as "The Five" made history.

## Man who ran over Charlottesville protestors fined for threatening corrections officer, other inmate
 - [https://www.foxnews.com/us/man-ran-over-charlottesville-protestors-fined-threatening-corrections-officer-other-inmate](https://www.foxnews.com/us/man-ran-over-charlottesville-protestors-fined-threatening-corrections-officer-other-inmate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:36:17+00:00

Charlottesville, Virginia, car attacker James Alex Fields Jr. was reportedly fined in prison for threatening a corrections officer and a fellow inmate.

## House Democrat claims 'hundreds' of fellow members worried about Biden in 2024: 'Won’t f---ing say a word'
 - [https://www.foxnews.com/media/house-democrat-claims-hundreds-fellow-members-worried-biden-2024-wont-f-ing-say-word](https://www.foxnews.com/media/house-democrat-claims-hundreds-fellow-members-worried-biden-2024-wont-f-ing-say-word)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:35:54+00:00

Hundreds of Democrats reportedly privately expressed concerns about President Biden's age and didn't want him to run again in 2024, according to one Democrat.

## Border Patrol seized over 800lbs of fentanyl between ports of entry since October: source
 - [https://www.foxnews.com/politics/border-patrol-seized-800lbs-fentanyl-between-ports-entry-source](https://www.foxnews.com/politics/border-patrol-seized-800lbs-fentanyl-between-ports-entry-source)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:34:47+00:00

Border Patrol agents at the southern border have seized over 800lbs of fentanyl since the beginning of the fiscal year, a federal source told Fox News this week.

## Pennsylvania House elects new speaker with narrow Democrat majority
 - [https://www.foxnews.com/politics/pennsylvania-house-elects-new-speaker-narrow-democrat-majority](https://www.foxnews.com/politics/pennsylvania-house-elects-new-speaker-narrow-democrat-majority)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:34:21+00:00

Democratic Pennsylvania state Rep. Joanna McClinton was elected speaker of the state's House of Representatives on Tuesday on the back of her party's one-vote majority.

## Lori Lightfoot 'in for quite a surprise' in Chicago mayor election: Kellyanne Conway
 - [https://www.foxnews.com/media/lori-lightfoot-quite-surprise-chicago-mayor-election-kellyanne-conway](https://www.foxnews.com/media/lori-lightfoot-quite-surprise-chicago-mayor-election-kellyanne-conway)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:31:45+00:00

Fox News contributor Kellyanne Conway weighs Democrat Mayor Lori Lightfoot's chances of reelection as Chicago voters head to the polls to select a new chief executive.

## Could AI race cars replace human drivers?
 - [https://www.foxnews.com/tech/could-ai-race-cars-replace-human-drivers](https://www.foxnews.com/tech/could-ai-race-cars-replace-human-drivers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:30:26+00:00

The Indy Autonomous Challenge showcase is a preview to what the future may hold in the auto industry, with autonomous cars potentially becoming more of the norm.

## Nebraska cheerleader competes alone at state competition after squad backs out: 'Proud of myself'
 - [https://www.foxnews.com/lifestyle/nebraska-cheerleader-competes-alone-state-competition-squad-backs-out-proud-of-myself](https://www.foxnews.com/lifestyle/nebraska-cheerleader-competes-alone-state-competition-squad-backs-out-proud-of-myself)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:28:50+00:00

Morrill High School senior Katrina Kohel was the only cheerleader to represent her cheer squad at the Nebraska state competition after the rest of the team backed out last minute.

## Dramatic rescue of Australian hiker stranded in freezing Arizona mountains caught on video
 - [https://www.foxnews.com/us/dramatic-rescue-australian-hiker-stranded-freezing-arizona-mountains-caught-video](https://www.foxnews.com/us/dramatic-rescue-australian-hiker-stranded-freezing-arizona-mountains-caught-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:26:03+00:00

U.S. Customs and Border Protection launched a rescue operation Friday morning to search for an Australian hiker who had become stranded in the mountains.

## 'Dukes of Hazzard' 'General Lee' wrecked in Missouri
 - [https://www.foxnews.com/auto/dukes-hazzard-general-lee-wrecked-missouri](https://www.foxnews.com/auto/dukes-hazzard-general-lee-wrecked-missouri)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:22:34+00:00

A "General Lee" replica was wrecked in Hollister, Missouri, prompting speculation that it was one of the vehicles used to make the "Dukes of Hazzard" TV show.

## ESPN analyst takes offense to Deion Sanders' recruiting tactics: 'This s--- ain't funny'
 - [https://www.foxnews.com/sports/espn-analyst-takes-offense-deion-sanders-recruiting-tactics-this-s-t-aint-funny](https://www.foxnews.com/sports/espn-analyst-takes-offense-deion-sanders-recruiting-tactics-this-s-t-aint-funny)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:15:47+00:00

New University of Colorado head football coach Deion Sanders has apparently ruffled some feathers after revealing some of his unorthodox recruiting tactics.

## Lawyer in abortion pill case responds to forum shopping accusations
 - [https://www.foxnews.com/politics/lawyer-abortion-pill-case-responds-forum-shopping-accusations](https://www.foxnews.com/politics/lawyer-abortion-pill-case-responds-forum-shopping-accusations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:15:05+00:00

Lawyers who filed a lawsuit challenging the FDA's approval of a popular abortion drug respond to critics who say filing the suit in Texas is forum shopping.

## Florida attorney blew $840k in stolen client money on OnlyFans porn site, drugs: sheriff
 - [https://www.foxnews.com/us/florida-attorney-blew-stolen-client-money-onlyfans-porn-site-drugs-sheriff](https://www.foxnews.com/us/florida-attorney-blew-stolen-client-money-onlyfans-porn-site-drugs-sheriff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:13:57+00:00

The Pinellas County Sheriff announced the arrest of a Florida attorney who allegedly stole $840,000 from his clients and spent the funds on drugs and OnlyFans.

## Gavin Lux to miss entire 2023 season with torn ACL
 - [https://www.foxnews.com/sports/gavin-lux-miss-2023-season-torn-acl](https://www.foxnews.com/sports/gavin-lux-miss-2023-season-torn-acl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:05:12+00:00

The Los Angeles Dodgers' fears became a reality on Tuesday, when further testing revealed Gavin Lux, their projected Opening Day shortstop, suffered a torn ACL in his right knee.

## Former NFL cornerback Irv Cross posthumously diagnosed with ‘most severe type’ of CTE, researchers say
 - [https://www.foxnews.com/sports/former-nfl-cornerback-irv-cross-posthumously-diagnose-most-severe-type-cte-researchers-say](https://www.foxnews.com/sports/former-nfl-cornerback-irv-cross-posthumously-diagnose-most-severe-type-cte-researchers-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:02:55+00:00

Ex-NFL cornerback Irv Cross, who died in 2021 years after being diagnosed with dementia, had Stage 4 CTE after nearly a decade of playing in the NFL, researchers said Tuesday

## California cancer nonprofit says thieves stole bus with wigs, patient supplies
 - [https://www.foxnews.com/us/california-cancer-nonprofit-says-thieves-stole-bus-wigs-patient-supplies](https://www.foxnews.com/us/california-cancer-nonprofit-says-thieves-stole-bus-wigs-patient-supplies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:01:59+00:00

A California cancer nonprofit said its bus loaded with supplies to help patients was stolen earlier this month.

## GOP senator's bill would give pro-life pregnancy centers security upgrades amid attacks
 - [https://www.foxnews.com/politics/gop-senators-bill-give-pro-life-pregnancy-centers-security-upgrades-amid-attacks](https://www.foxnews.com/politics/gop-senators-bill-give-pro-life-pregnancy-centers-security-upgrades-amid-attacks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:00:36+00:00

Idaho Senator James Risch, a Republican, introduced the Pregnancy Center Security Act to give grants to pro-life pregnancy centers for security upgrades after pro-abortion attacks.

## Tom Brady's daughter takes over his Instagram, posts kitten photos to his 13M followers
 - [https://www.foxnews.com/entertainment/tom-bradys-daughter-takes-over-instagram-posts-kitten-photos-13m-followers](https://www.foxnews.com/entertainment/tom-bradys-daughter-takes-over-instagram-posts-kitten-photos-13m-followers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:00:34+00:00

NFL legend Tom Brady's 10-year-old daughter Vivian hacked her father's social media account and shared photos of their adopted kittens with his millions of followers.

## Pollster Nate Silver blasts journalists for 'massive error' in lab-leak discussion: 'Drives me up the wall'
 - [https://www.foxnews.com/media/pollster-nate-silver-blasts-journalists-massive-error-lab-leak-discussion](https://www.foxnews.com/media/pollster-nate-silver-blasts-journalists-massive-error-lab-leak-discussion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:00:28+00:00

Nate Silver slammed journalists who haven't acknowledged the "massive error" made in labeling the lab-leak discussion as "misinformation" on Tuesday in a tweet.

## Thiessen explains why media covered for China on lab leak: 'The goal was to blame Trump' to win an election
 - [https://www.foxnews.com/media/thiessen-explains-media-covered-china-lab-leak-goal-blame-trump-win-election](https://www.foxnews.com/media/thiessen-explains-media-covered-china-lab-leak-goal-blame-trump-win-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 21:00:09+00:00

Former White House speechwriter Marc Thiessen claimed the liberal media's reason for denying the COVID lab leak theory for so long was to continue their tirade against Trump.

## San Francisco radio host Jeffrey 'JV' Vandergrift missing since Thursday, police say
 - [https://www.foxnews.com/us/san-francisco-radio-host-jeffrey-jv-vandergrift-missing-thursday-police-say](https://www.foxnews.com/us/san-francisco-radio-host-jeffrey-jv-vandergrift-missing-thursday-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:53:46+00:00

San Francisco radio host Jeffrey "JV" Vandergrift has been missing since he was last seen at his home on King Street Thursday, according to city police.

## Top senator demands answers from Energy Dept on lab leak reversal: 'I was never provided this report'
 - [https://www.foxnews.com/politics/top-senator-demands-answers-energy-dept-lab-leak-reversal-i-was-never-provided-this-report](https://www.foxnews.com/politics/top-senator-demands-answers-energy-dept-lab-leak-reversal-i-was-never-provided-this-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:47:06+00:00

Sen. John Barrasso sent a letter to Energy Secretary Jennifer Granholm demanding answers and a briefing regarding the Energy Department's assessment of the COVID lab leak theory.

## Florida's 3rd panther this year dies after being struck by vehicle
 - [https://www.foxnews.com/us/floridas-3rd-panther-year-dies-being-struck-vehicle](https://www.foxnews.com/us/floridas-3rd-panther-year-dies-being-struck-vehicle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:45:11+00:00

A Florida panther has died Sunday after being fatally struck by a vehicle. This is the third death by fatal collisions to the endangered animal in the state of Florida.

## Biden climate envoy Kerry meets with socialist Brazilian leadership
 - [https://www.foxnews.com/politics/biden-climate-envoy-kerry-meets-socialist-brazilian-leadership](https://www.foxnews.com/politics/biden-climate-envoy-kerry-meets-socialist-brazilian-leadership)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:44:00+00:00

Climate envoy John Kerry is holding his second day of meetings with Brazilian government officials to outline planned environmental policy in the Latin American nation.

## Gov. Evers looks to spend $1.8B on University of Wisconsin campuses
 - [https://www.foxnews.com/politics/gov-evers-looks-spend-1-8b-university-wisconsin-campuses](https://www.foxnews.com/politics/gov-evers-looks-spend-1-8b-university-wisconsin-campuses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:42:49+00:00

Democratic Wisconsin Gov. Tony Evers proposed Tuesday a $3.8 billion building projects fund, more than half of which would be allocated to the University of Wisconsin System.

## Judge approves $1M settlement in lawsuit over federal immigration raid
 - [https://www.foxnews.com/us/judge-approves-1m-settlement-lawsuit-federal-immigration-raid](https://www.foxnews.com/us/judge-approves-1m-settlement-lawsuit-federal-immigration-raid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:41:19+00:00

A federal judge approved a $1 million settlement in a lawsuit over a federal immigration raid at a Tennessee meatpacking plant. During the raid nearly 100 people were arrested.

## Randi Weingarten screams about student debt outside SCOTUS: ‘That is not fair!’
 - [https://www.foxnews.com/politics/randi-weingarten-melts-down-student-debt-outside-scotus-not-fair](https://www.foxnews.com/politics/randi-weingarten-melts-down-student-debt-outside-scotus-not-fair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:37:43+00:00

Teachers’ union boss Randi Weingarten worked herself into a scream during a rally for student loan debt forgiveness outside the Supreme Court on Tuesday.

## King Charles, Camilla to break royal tradition at coronation with ‘bold move’: ‘An enormous honor’
 - [https://www.foxnews.com/entertainment/king-charles-camilla-break-royal-tradition-coronation-bold-move-enormous](https://www.foxnews.com/entertainment/king-charles-camilla-break-royal-tradition-coronation-bold-move-enormous)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:34:33+00:00

According to reports, the grandchildren of Camilla, queen consort, will have an official role at the coronation on May 6 at London's Westminster Abbey.

## School board slammed after member calls Battle of Iwo Jima victory 'unfortunate'
 - [https://www.foxnews.com/media/school-board-slammed-member-calls-battle-iwo-jima-victory-unfortunate](https://www.foxnews.com/media/school-board-slammed-member-calls-battle-iwo-jima-victory-unfortunate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:30:47+00:00

Fairfax County Public Schools board member Abrar Omeish has doubled down after sparking outrage in Virginia with her Day of Remembrance comments.

## GOP fires warning shot at Biden over ‘deeply flawed’ WHO treaty on pandemic response
 - [https://www.foxnews.com/politics/gop-fires-warning-shot-biden-deeply-flawed-who-treaty-pandemic-response](https://www.foxnews.com/politics/gop-fires-warning-shot-biden-deeply-flawed-who-treaty-pandemic-response)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:30:46+00:00

Senate Republicans are pushing the Biden administration to submit a WHO-negotiated treaty to the Senate for ratification and fear Biden might instead choose to go around Congress.

## Blackhawks trade franchise legend Patrick Kane to Rangers after 16 seasons in Chicago: reports
 - [https://www.foxnews.com/sports/blackhawks-trade-franchise-legend-patrick-kane-rangers-after-16-seasons-chicago](https://www.foxnews.com/sports/blackhawks-trade-franchise-legend-patrick-kane-rangers-after-16-seasons-chicago)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:26:09+00:00

After being the first overall pick by the Chicago Blackhawks in the 2007 NHL draft, franchise legend Patrick Kane has been traded to the New York Rangers.

## Bruce Willis' wife Emma is adding to her ‘dementia care toolbox’ amid actor's diagnosis
 - [https://www.foxnews.com/entertainment/bruce-willis-wife-emma-adding-dementia-care-toolbox-actors-diagnosis](https://www.foxnews.com/entertainment/bruce-willis-wife-emma-adding-dementia-care-toolbox-actors-diagnosis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:23:14+00:00

Emma Heming Willis opened up how a dementia specialist is helping her add to her "care toolbox" amid news of husband Bruce Willis' diagnosis.

## Elderly Florida man had more than a ton of child porn images in his bedroom: police
 - [https://www.foxnews.com/us/elderly-florida-man-had-more-than-ton-child-porn-images-his-bedroom-police](https://www.foxnews.com/us/elderly-florida-man-had-more-than-ton-child-porn-images-his-bedroom-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:20:17+00:00

Marion County officials have arrested Paul Zittel, 72, on 25 counts of possessing child pornography after they found more than 200,000 child porn images in his home.

## Sudanese security forces fatally shoot protester near capital
 - [https://www.foxnews.com/world/sudanese-security-forces-fatally-shoot-protester-near-capital](https://www.foxnews.com/world/sudanese-security-forces-fatally-shoot-protester-near-capital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:13:00+00:00

Sudanese security forces fatally shot a protester in the chest near the country's capital on Tuesday. The man was participating in an anti-government protest.

## GOP Rep. Collins blasts Buttigieg for Ohio response, says impeachment not off the table
 - [https://www.foxnews.com/politics/gop-rep-collins-blasts-buttigieg-ohio-response-impeachment-not-off-table](https://www.foxnews.com/politics/gop-rep-collins-blasts-buttigieg-ohio-response-impeachment-not-off-table)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:10:20+00:00

Georgia Rep. Mike Collins, a Republican, blasted Transportation Secretary Pete Buttigieg for his response to the Ohio train derailment and noted impeachment is not off the table.

## Florida student accused of attacking teacher's aide who took Nintendo Switch will be charged as adult
 - [https://www.foxnews.com/us/florida-student-accused-attacking-teachers-aide-took-nintendo-switch-charged-adult](https://www.foxnews.com/us/florida-student-accused-attacking-teachers-aide-took-nintendo-switch-charged-adult)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:09:38+00:00

A Florida teacher's aide was assaulted by a student after she took away his Nintendo Switch. The student is being charged as an adult and is being held on $1 million bond.

## 9 historians recognized, awarded by Israeli university
 - [https://www.foxnews.com/world/9-historians-recognized-awarded-israeli-university](https://www.foxnews.com/world/9-historians-recognized-awarded-israeli-university)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:09:31+00:00

The Dan David Prize board has announced the nine historians receiving the award this year, each recognized for perceived 'outstanding contributions' to the field.

## Charlottesville police negotiate with suspect in violent incident involving firearm, multiple shots fired
 - [https://www.foxnews.com/us/charlottesville-police-negotiate-suspect-violent-incident-involving-firearm-multiple-shots-fired](https://www.foxnews.com/us/charlottesville-police-negotiate-suspect-violent-incident-involving-firearm-multiple-shots-fired)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:07:40+00:00

Charlottesville police are negotiating with the person responsible for firing several shots. Virginia officers did not have details about whether anyone was injured.

## Defense officials claim there's no evidence Ukraine is mishandling US weapons, aid
 - [https://www.foxnews.com/politics/defense-officials-claim-no-evidence-ukraine-mishandling-us-weapons-aide](https://www.foxnews.com/politics/defense-officials-claim-no-evidence-ukraine-mishandling-us-weapons-aide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:02:22+00:00

The Department of Defense claims there is no evidence of diversion or misuse of American weapons or security assistance that has been sent to Ukraine during its war with Russia.

## Somalia drought 'extremely critical' but no famine projected
 - [https://www.foxnews.com/world/somalia-drought-extremely-critical-famine-projected](https://www.foxnews.com/world/somalia-drought-extremely-critical-famine-projected)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:02:06+00:00

Somalia's drought is being described as "extremely critical," but there is no famine projected. 3.8 million people have been displaced due to Somalia's battles with al-Shabab.

## ‘Jesus Revolution’ performs miracles at the box office, receives rave reviews from audience
 - [https://www.foxnews.com/media/jesus-revolution-miracles-box-office-rave-reviews-audience](https://www.foxnews.com/media/jesus-revolution-miracles-box-office-rave-reviews-audience)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:00:26+00:00

The new faith-based movie "Jesus Revolution" has doubled weekend box office predictions and achieved near perfect review scores from those in attendance.

## Minnesota teen's killer gets nearly 4 decades in prison
 - [https://www.foxnews.com/us/minnesota-teens-killer-gets-nearly-4-decades-prison](https://www.foxnews.com/us/minnesota-teens-killer-gets-nearly-4-decades-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 20:00:16+00:00

Cody Fohrenkam, 30, was sentenced to 38 1/2 years in prison for the murder of 15-year-old Minneapolis North High School student and football quarterback Deshaun Hill Jr.

## Tennessee house fire caused by space heater kills 4, 1 in critical condition
 - [https://www.foxnews.com/us/tennessee-house-fire-caused-space-heater-kills-4-1-critical-condition](https://www.foxnews.com/us/tennessee-house-fire-caused-space-heater-kills-4-1-critical-condition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:56:38+00:00

A Tennessee house fire that was caused by a space heater killed four and left one in critical condition. Firefighters recieved the call around 2 a.m. Tuesday to extingush the flames.

## Kevin Durant expected to make Suns debut on Wednesday vs Hornets
 - [https://www.foxnews.com/sports/kevin-durant-expected-make-suns-debut-hornets](https://www.foxnews.com/sports/kevin-durant-expected-make-suns-debut-hornets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:53:57+00:00

Kevin Durant is finally expected to make his Phoenix Suns debut, as the team announced that he will suit up on Wednesday to face the Charlotte Hornets.

## Herschel Walker's campaign paid defunct car wash for private jets, sparking concerns from experts
 - [https://www.foxnews.com/politics/herschel-walkers-campaign-paid-defunct-car-wash-private-jets-sparking-concerns-experts](https://www.foxnews.com/politics/herschel-walkers-campaign-paid-defunct-car-wash-private-jets-sparking-concerns-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:52:14+00:00

Experts expressed concern after a report showed former Senate candidate Herschel Walker's campaign paid a defunct car wash hundreds of thousands of dollars for private jet travel.

## ‘Yellowstone’ star Kevin Costner talks falling ‘short’ but says ‘we keep on trying’
 - [https://www.foxnews.com/entertainment/yellowstone-star-kevin-costner-talks-falling-short-says-keep-trying](https://www.foxnews.com/entertainment/yellowstone-star-kevin-costner-talks-falling-short-says-keep-trying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:52:08+00:00

Kevin Costner shared a new song he co-wrote titled "One More Day." He revealed the meaning behind the song, saying time is the "greatest gift."

## Florida man high on meth sentenced to life for DUI crash that killed 2 girls, grandfather
 - [https://www.foxnews.com/us/florida-man-high-meth-sentenced-life-dui-crash-killed-2-girls-grandfather](https://www.foxnews.com/us/florida-man-high-meth-sentenced-life-dui-crash-killed-2-girls-grandfather)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:50:57+00:00

A Florida man was sentenced to life for a DUI car crash that killed two girls and their grandfather. The man pleaded no contest to the crash, was high on meth.

## Hospital in disputed Somaliland city shelled during upscale of violence, 1 dead
 - [https://www.foxnews.com/world/hospital-disputed-somaliland-city-shelled-during-upscale-violence-1-dead](https://www.foxnews.com/world/hospital-disputed-somaliland-city-shelled-during-upscale-violence-1-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:49:22+00:00

A hospital in a disputed Somaliland city has been shelled during an upsurge of violence leaving one person dead. Allegedly the al-Shabab extremist group have supported the attacks.

## Benched QB Marcus Mariota released by Falcons in salary cap savings move
 - [https://www.foxnews.com/sports/benched-qb-marcus-mariota-released-by-falcons-in-salary-cap-savings-move](https://www.foxnews.com/sports/benched-qb-marcus-mariota-released-by-falcons-in-salary-cap-savings-move)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:44:45+00:00

Marcus Mariota was given a second chance at being a starting quarterback in the NFL, but be failed to establish himself as a viable option for the Falcons going forward.

## Jerry Jones may go to trial after previously dismissed sexual assault case proceeds
 - [https://www.foxnews.com/sports/jerry-jones-likely-trial-previously-dismissed-sexual-assault-case-proceeds](https://www.foxnews.com/sports/jerry-jones-likely-trial-previously-dismissed-sexual-assault-case-proceeds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:39:06+00:00

A sexual assault lawsuit filed against Dallas Cowboys owner Jerry Jones was dismissed last year, but a Texas judge has ruled that it should go to trial.

## Fox News Politics: Mayor Lori Lightfoot's fate
 - [https://www.foxnews.com/politics/fox-news-politics-mayor-lori-lightfoots-fate](https://www.foxnews.com/politics/fox-news-politics-mayor-lori-lightfoots-fate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:31:40+00:00

Get the latest updates from the 2024 campaign trail, exclusive interviews and more Fox News politics content

## Louisiana teen pleads guilty to carjackings, faces murder charge
 - [https://www.foxnews.com/us/louisiana-teen-pleads-guilty-carjackings-faces-murder-charge](https://www.foxnews.com/us/louisiana-teen-pleads-guilty-carjackings-faces-murder-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:31:15+00:00

A Louisiana teenager has pleaded guilty in multiple carjackings and also faces a second-degree murder charge. The man admitted to five carjackings, including one in which he used a firearm.

## Stephen Colbert ripped for 'willful rejection of reality' after taunting Energy Department lab leak report
 - [https://www.foxnews.com/media/stephen-colbert-ripped-willful-rejection-reality-taunting-energy-department-lab-leak-report](https://www.foxnews.com/media/stephen-colbert-ripped-willful-rejection-reality-taunting-energy-department-lab-leak-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:21:02+00:00

"'Late Show" host Stephen Colbert was criticized after he ridiculed an intelligence agency for reportedly finding the coronavirus leaked from a lab in China.

## Shannon Sharpe rips Brandon Miller for controversial ritual: ‘It’s not funny. It’s not cute’
 - [https://www.foxnews.com/sports/shannon-sharpe-rips-brandon-miller-controversial-ritual-not-funny-not-cute](https://www.foxnews.com/sports/shannon-sharpe-rips-brandon-miller-controversial-ritual-not-funny-not-cute)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:20:11+00:00

Shannon Sharpe of Fox Sports ripped Alabama freshman Brandon Miller for his pregame "pat-down" ritual, which he continued on Saturday against Arkansas.

## Pentagon to change promotion records for service members who refused COVID vaccine
 - [https://www.foxnews.com/politics/pentagon-change-promotion-records-servicemembers-refuses-covid-vaccine](https://www.foxnews.com/politics/pentagon-change-promotion-records-servicemembers-refuses-covid-vaccine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:20:07+00:00

The U.S. military services are currently revising records to ensure that service members who refused a COVID-19 vaccine are not passed over for promotion.

## Newly elected Santa Fe magistrate arrested on DWI charge
 - [https://www.foxnews.com/politics/newly-elected-santa-fe-nm-magistrate-arrested-dwi-charge](https://www.foxnews.com/politics/newly-elected-santa-fe-nm-magistrate-arrested-dwi-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:12:51+00:00

Dev Atma Khalsa, a New Mexico magistrate who took office a few months ago, was arrested on suspicion of aggravated driving while intoxicated. Khalsa also had an expired license.

## House GOP opens probe into Maryland woman's rape, murder by alleged MS-13 member who crossed border as minor
 - [https://www.foxnews.com/politics/house-gop-opens-probe-maryland-womans-rape-murder-alleged-ms-13-member-crossed-border-minor](https://www.foxnews.com/politics/house-gop-opens-probe-maryland-womans-rape-murder-alleged-ms-13-member-crossed-border-minor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:11:40+00:00

House Judiciary GOP Chairman Jim Jordan demands HHS provide details on an MS-13 member who crossed the border as a minor and is charged in the murder of 20-year-old Kayla Hamilton.

## Republican KY gubernatorial candidate Ryan Quarles endorses legalizing medical marijuana
 - [https://www.foxnews.com/politics/republican-ky-gubernatorial-candidate-ryan-quarles-endorses-legalizing-medical-marijuana](https://www.foxnews.com/politics/republican-ky-gubernatorial-candidate-ryan-quarles-endorses-legalizing-medical-marijuana)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:11:05+00:00

Republican gubernatorial candidate and agriculture commissioner of Kentucky, Ryan Quarles, has endorsed legalizing medical marijuana in the state.

## 'The View' co-host Sunny Hostin laments 'White men' in late night: 'Why is it so hard for women to break in?'
 - [https://www.foxnews.com/media/the-view-co-host-sunny-hostin-laments-white-men-late-night-why-hard-women-break-in](https://www.foxnews.com/media/the-view-co-host-sunny-hostin-laments-white-men-late-night-why-hard-women-break-in)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:09:52+00:00

Sunny Hostin lamented "all White men" in late-night comedy on Tuesday and asked comedian Samantha Bee why it is "so hard" for women to break in to hosting.

## Idaho murders: Bryan Kohberger's Pennsylvania warrants unsealed
 - [https://www.foxnews.com/us/idaho-murders-bryan-kohberger-pennsylvania-warrants-unsealed](https://www.foxnews.com/us/idaho-murders-bryan-kohberger-pennsylvania-warrants-unsealed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:04:11+00:00

A Pennsylvania court has unsealed a previously unseen Bryan Kohberger warrant in connection with the University of Idaho student quadruple stabbing murders.

## Reddit user says he doesn't want to build ramp on new home, even though nephew uses a wheelchair
 - [https://www.foxnews.com/lifestyle/reddit-user-says-he-doesnt-want-build-ramp-new-home-nephew-uses-wheelchair](https://www.foxnews.com/lifestyle/reddit-user-says-he-doesnt-want-build-ramp-new-home-nephew-uses-wheelchair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 19:00:31+00:00

A man took to Reddit to explain why he doesn't want to build a wheelchair ramp at his new home. His sister is upset; her son uses a wheelchair, and the Redditor seeks input from others.

## Anti-government protest held in Moldova's capitol, protestors chant 'down with the dictatorship!'
 - [https://www.foxnews.com/world/anti-government-protest-held-moldovas-capitol-protestors-chant-down-dictatorship](https://www.foxnews.com/world/anti-government-protest-held-moldovas-capitol-protestors-chant-down-dictatorship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:57:13+00:00

A protest was held in Moldova's capitol on Tuesday. The protest was organized by an antigovernment group that is supported by members of the country's Russia-friendly Shor Party.

## NC again delays tailored plan for Medicaid enrollees with mental health, developmental disabilities
 - [https://www.foxnews.com/health/nc-again-delays-tailored-plan-medicaid-enrollees-mental-health-developmental-disabilities](https://www.foxnews.com/health/nc-again-delays-tailored-plan-medicaid-enrollees-mental-health-developmental-disabilities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:56:36+00:00

North Carolina is again delaying its health plan specifically designed for Medicaid enrollees with behavioral and intellectual disabilities. The plan will be pushed back by six months.

## WI Republicans propose bill that would limit tuition increases at the University of Wisconsin
 - [https://www.foxnews.com/us/wi-republicans-propose-bill-limit-tuition-increases-university-wisconsin](https://www.foxnews.com/us/wi-republicans-propose-bill-limit-tuition-increases-university-wisconsin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:51:48+00:00

Republican Rep. David Murphy and Sen. Andre Jacque want to limit future tuition raises at the University of Wisconsin. In-state undergraduates had a tuition freeze from 2013 to 2021.

## Sen. Hawley slams Biden nominee for ‘stonewalling’ on past tweets: ‘This is unbelievable’
 - [https://www.foxnews.com/politics/hawley-slams-biden-nominee-stonewalling-past-tweets-unbelievable](https://www.foxnews.com/politics/hawley-slams-biden-nominee-stonewalling-past-tweets-unbelievable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:50:28+00:00

Sen. Josh Hawley, R-Mo., on Tuesday accused Biden’s nominee for Archivist of the United States, Colleen Shogan, of lying under oath and stonewalling his line of questioning.

## Wisconsin wildlife officials say comments on wolf management plan will be released 'eventually'
 - [https://www.foxnews.com/us/wisconsin-wildlife-officials-says-comments-wolf-management-plan-released-eventually](https://www.foxnews.com/us/wisconsin-wildlife-officials-says-comments-wolf-management-plan-released-eventually)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:42:31+00:00

The Wisconsin Department of Natural Resources has not given a clear timeline on when comments regarding a new wolf management plan will be released.

## 2 die from cholera in Syria after a devastating earthquake damages health, water infrastructure
 - [https://www.foxnews.com/health/2-die-cholera-syria-afterdevastating-earthquake-damaged-health-water-infrastructure](https://www.foxnews.com/health/2-die-cholera-syria-afterdevastating-earthquake-damaged-health-water-infrastructure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:41:23+00:00

Two people have died from cholera in post-quake Syria. People fear its recent disaster which damaged the country’s health and water infrastructure could cause a spike in cases.

## Sally Field's hint at her White 'privilege' in awards speech sparks Twitter debate
 - [https://www.foxnews.com/media/sally-fields-hint-white-privilege-awards-speech-sparks-twitter-debate](https://www.foxnews.com/media/sally-fields-hint-white-privilege-awards-speech-sparks-twitter-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:40:56+00:00

Sally Field allegedly hinted at her White privilege during her speech at Sunday's SAG awards, gaining both support and criticism from accounts on Twitter.

## AK to provide $1.7 million to help stock food pantries, address backlog in food stamps
 - [https://www.foxnews.com/politics/ak-provide-1-7-million-help-stock-food-pantries-address-backlog-food-stamps](https://www.foxnews.com/politics/ak-provide-1-7-million-help-stock-food-pantries-address-backlog-food-stamps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:40:41+00:00

Alaska Gov. Mike Dunleavy has allocated $1.7 million to address the state’s backlog of food stamps. The money will be used to bulk purchase food and stock food pantries.

## Dogs that killed elderly San Antonio man ‘snapped’ after pet services visit, owner says
 - [https://www.foxnews.com/us/dogs-that-killed-elderly-san-antonio-man-snapped-pet-services-visit-owner-says](https://www.foxnews.com/us/dogs-that-killed-elderly-san-antonio-man-snapped-pet-services-visit-owner-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:28:12+00:00

Ramon Najera, an 81-year-old Air Force veteran and grandfather, was killed and three others were injured during a dog attack in San Antonio, Texas, last week.

## 'Sister Wives' star Meri Brown debunks sexuality rumors after leaving Kody
 - [https://www.foxnews.com/entertainment/sister-wives-star-meri-brown-debunks-sexuality-rumors-leaving-kody](https://www.foxnews.com/entertainment/sister-wives-star-meri-brown-debunks-sexuality-rumors-leaving-kody)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:17:11+00:00

"Sister Wives" star Meri Brown debunked long-running rumors of her sexuality on social media.

## Kirk Cameron gets 'pushback' from library ahead of children's story-hour event
 - [https://www.foxnews.com/lifestyle/kirk-cameron-gets-pushback-library-ahead-childrens-story-hour-event](https://www.foxnews.com/lifestyle/kirk-cameron-gets-pushback-library-ahead-childrens-story-hour-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:11:41+00:00

The Fox News Lifestyle Newsletter brings you trending stories on family, travel, food, neighbors helping neighbors, pets, autos, military veterans, heroes, faith and American values.

## WA dam owner pleads guilty to a spill that polluted a river with rubber particles
 - [https://www.foxnews.com/us/wa-dam-owner-pleads-guilty-spill-polluted-river-rubber-particles](https://www.foxnews.com/us/wa-dam-owner-pleads-guilty-spill-polluted-river-rubber-particles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:11:13+00:00

The owner of a Washington dam company pleaded guilty to using old field turf for a construction project. The turf ripped which polluted a river with synthetic material.

## 3 men convicted of torturing, killing 2 Albuquerque teens boys in alleged drug deal gone wrong
 - [https://www.foxnews.com/us/3-men-convicted-torturing-killing-2-albuquerque-teens-boys-alleged-drug-deal-gone-wrong](https://www.foxnews.com/us/3-men-convicted-torturing-killing-2-albuquerque-teens-boys-alleged-drug-deal-gone-wrong)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:10:44+00:00

Three men have been convicted of killing two New Mexico teenage boys in 2018. The men beat, tortured, and shot the boys in an alleged drug deal that went awry.

## Transgender rights activist claims laws blocking sex change surgeries for children are like Holocaust
 - [https://www.foxnews.com/media/transgender-rights-activist-claims-laws-blocking-sex-change-surgeries-children-like-holocaust](https://www.foxnews.com/media/transgender-rights-activist-claims-laws-blocking-sex-change-surgeries-children-like-holocaust)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:09:38+00:00

A Jewish father of a transgender child told the Washington Post laws blocking gender affirming care for minors were a "war" on his family and reminded him of the Holocaust.

## Boyfriend of US swim champ found dead in Virgin Islands convicted in Pennsylvania tourist's 2007 beating death
 - [https://www.foxnews.com/us/boyfriend-us-swim-champ-found-dead-virgin-islands-convicted-pennsylvania-tourists-2007-beating-death](https://www.foxnews.com/us/boyfriend-us-swim-champ-found-dead-virgin-islands-convicted-pennsylvania-tourists-2007-beating-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:07:38+00:00

The man who found a 42-year-old former American swimming champ dead last week was convicted in the 2007 beating death of a Pennsylvania man, sources say.

## Dead humpback whale seen off New York, New Jersey coast
 - [https://www.foxnews.com/us/dead-humpback-whale-seen-new-york-new-jersey-coast](https://www.foxnews.com/us/dead-humpback-whale-seen-new-york-new-jersey-coast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:05:26+00:00

A dead humpback was spotted Monday off the shores of New York and New Jersey. NOAA said that 13 dead whales have washed up on the Atlantic Coast since Dec. 1.

## Supreme Court Justice Jackson gets support from conservatives in first majority ruling
 - [https://www.foxnews.com/politics/supreme-court-justice-jackson-gets-support-conservatives-first-majority-ruling](https://www.foxnews.com/politics/supreme-court-justice-jackson-gets-support-conservatives-first-majority-ruling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:04:07+00:00

Supreme Court Justice Ketanji Brown Jackson issued her first ever majority opinion on Tuesday in the case Delaware vs. Pennsylvania Et. Al.

## Khloé Kardashian shuts down trolls, reveals she had a tumor removed from her face
 - [https://www.foxnews.com/entertainment/khloe-kardashian-shuts-down-trolls-reveals-tumor-removed-from-face](https://www.foxnews.com/entertainment/khloe-kardashian-shuts-down-trolls-reveals-tumor-removed-from-face)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 18:02:35+00:00

Khloé Kardashiaan fired back at trolls accusing her of having plastic surgery by revealing she actually had a tumor removed from her face.

## Florida suspect in killing of TV news reporter, girl and woman missed court hearing due to ‘mental health’
 - [https://www.foxnews.com/us/florida-suspect-killing-tv-news-reporter-girl-woman-missed-court-hearing-due-mental-health](https://www.foxnews.com/us/florida-suspect-killing-tv-news-reporter-girl-woman-missed-court-hearing-due-mental-health)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:58:39+00:00

Keith Melvin Moses, accused of gunning down a TV news reporter, 9-year-old girl and a woman, missed a court hearing last week due to "mental health" as he faces added murder counts.

## Chiefs’ Chris Jones has priceless response to Eagles’ Brandon Graham during Super Bowl trash talk session
 - [https://www.foxnews.com/sports/chiefs-chris-jones-priceless-response-eagles-brandon-graham-during-super-bowl-trash-talk-session](https://www.foxnews.com/sports/chiefs-chris-jones-priceless-response-eagles-brandon-graham-during-super-bowl-trash-talk-session)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:53:03+00:00

NFL veteran and Chiefs star defensive end Chris Jones is no stranger to the Super Bowl. So it’s no surprise that he had the perfect response to an Eagles player chirping away.

## 'Do you have the pangolin?' Rep. Scott Perry reams State Department for dismissing lab leak theory
 - [https://www.foxnews.com/politics/do-you-have-pangolin-rep-scott-perry-reams-state-department-dismissing-lab-leak-theory](https://www.foxnews.com/politics/do-you-have-pangolin-rep-scott-perry-reams-state-department-dismissing-lab-leak-theory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:51:30+00:00

Rep. Scott Perry blasted State Department officials for dismissing the COVID-19 lab leak theory on Tuesday, demanding to see what evidence they had to do so.

## 'I don't support it': Manchin will vote against new DC revision reducing penalties on violent crime
 - [https://www.foxnews.com/politics/dont-support-manchin-vote-against-new-dc-revision-reducing-penalties-violent-crime](https://www.foxnews.com/politics/dont-support-manchin-vote-against-new-dc-revision-reducing-penalties-violent-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:46:58+00:00

Democrat Senator Joe Manchin does not support the D.C. city council pushing to reduce penalties on crime in the city and said he will vote in favor of the disapproval resolution.

## Former California FBI agent sentenced for accepting $150K in bribes to provide information
 - [https://www.foxnews.com/us/former-california-fbi-agent-sentenced-accepting-150k-bribes-provide-information](https://www.foxnews.com/us/former-california-fbi-agent-sentenced-accepting-150k-bribes-provide-information)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:46:18+00:00

A former FBI agent in California who accepted $150,000 in bribes to provide confidential information has been sentenced to six years in federal prison.

## ME man charged with killing Massachusetts man, Maine teen
 - [https://www.foxnews.com/us/me-man-charged-killing-massachusetts-man-maine-teen](https://www.foxnews.com/us/me-man-charged-killing-massachusetts-man-maine-teen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:45:51+00:00

A man was charged with killing a teenager from Maine and a man from Massachusetts. The man is currently in custody in New Hampshire. The bodies were discovered in Poland, Maine.

## Stabbing of 11-year-old New Jersey boy spurs protest by parents, students who want leadership changes
 - [https://www.foxnews.com/us/stabbing-11-year-old-new-jersey-boy-spurs-protest-parents-students-leadership-changes](https://www.foxnews.com/us/stabbing-11-year-old-new-jersey-boy-spurs-protest-parents-students-leadership-changes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:45:28+00:00

An 11-year-old boy was stabbed following an altercation with another child. The stabbing spurred protests from parents and students seeking leadership changes in the school district.

## FDA sued for concealing information about children's off-label use of puberty blockers, cross-sex hormones
 - [https://www.foxnews.com/media/fda-sued-concealing-information-childrens-label-use-puberty-blockers-cross-sex-hormones](https://www.foxnews.com/media/fda-sued-concealing-information-childrens-label-use-puberty-blockers-cross-sex-hormones)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:45:22+00:00

America First Legal sues the FDA for illegally concealing records regarding the use of puberty blockers and cross-sex hormone drugs on children after failing to respond to a FOIA as required by law

## Ringleader who led a $18M COVID fraud scheme in LA extradited from Europe
 - [https://www.foxnews.com/us/ringleader-who-led-18m-covid-fraud-scheme-la-extradited-europe](https://www.foxnews.com/us/ringleader-who-led-18m-covid-fraud-scheme-la-extradited-europe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:44:15+00:00

The ringleader of an $18 million coronavirus aid fraud scheme has been extradited from Europe. She used fake identities of dead and elderly people to fraudulently apply for loans.

## Jackie Robinson’s name misspelled as ‘Jakie’ on New York City road sign
 - [https://www.foxnews.com/sports/jackie-robinsons-name-misspelled-jakie-new-york-city-road-sign](https://www.foxnews.com/sports/jackie-robinsons-name-misspelled-jakie-new-york-city-road-sign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:44:06+00:00

The New York City Department of Transportation misspelled Jackie Robinson's name on a road sign in Queens. The sign was replaced on Monday.

## Matthew McConaughey poses with lookalike sons in rare family photo shared by Camila Alves
 - [https://www.foxnews.com/entertainment/matthew-mcconaughey-poses-lookalike-sons-rare-family-photo-shared-camila-alves](https://www.foxnews.com/entertainment/matthew-mcconaughey-poses-lookalike-sons-rare-family-photo-shared-camila-alves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:41:37+00:00

In a rare photo shared to social media, Matthew McConaughey is seen with both his sons, Levi and Livingston, cutting his younger son's hair. Both boys are the spitting image of their father.

## NATO chief says Ukraine will 'become a member of our alliance' in the 'long term'
 - [https://www.foxnews.com/world/nato-chief-ukraine-become-member-alliance-long-term](https://www.foxnews.com/world/nato-chief-ukraine-become-member-alliance-long-term)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:34:22+00:00

NATO General Secretary Jens Stoltenberg indicated Tuesday it is a matter of when, not if, Ukraine will join the alliance and said member nations would continue to support Ukraine in its war against Russia.

## Biden flamed for 'lying' that he attended Black church, fought segregation during youth: 'All debunked lies'
 - [https://www.foxnews.com/media/biden-again-flamed-saying-attended-black-church-fought-segregation-all-debunked-lies](https://www.foxnews.com/media/biden-again-flamed-saying-attended-black-church-fought-segregation-all-debunked-lies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:29:14+00:00

President Biden was accused of "lying" for claiming he used to go to a Black church when he was in high school to plan out desegregation activism.

## Putin orders increased border security after night of drone attacks as fighting in Ukraine intensifies
 - [https://www.foxnews.com/world/putin-orders-increased-border-security-night-drone-attacks-fighting-ukraine-intensifies](https://www.foxnews.com/world/putin-orders-increased-border-security-night-drone-attacks-fighting-ukraine-intensifies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:28:28+00:00

Russian President Vladimir Putin ordered officials to tighten up border security after Russia saw several overnight drone attacks target oil depots.

## Bodycam footage shows NJ house explosion while firefighters still inside
 - [https://www.foxnews.com/us/bodycam-footage-shows-nj-house-explosion-firefighters-still-inside](https://www.foxnews.com/us/bodycam-footage-shows-nj-house-explosion-firefighters-still-inside)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:18:41+00:00

Newly released bodycam video from police in New Jersey shows the moment an explosion rocked a home that firefighters were working in. Five firefighters were injured.

## Artist behind Obama's iconic 'Hope' poster slams cancel culture: People are 'fearful about having an opinion'
 - [https://www.foxnews.com/media/artist-obama-iconic-hope-poster-slams-cancel-culture-people-fearful-having-opinion](https://www.foxnews.com/media/artist-obama-iconic-hope-poster-slams-cancel-culture-people-fearful-having-opinion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:15:56+00:00

Shepard Fairey, the street artist behind the iconic 2008 campaign poster for former President Obama, criticized cancel culture in an interview with Sky News.

## Good Samaritans rescue woman from attack in mall bathroom stall: police
 - [https://www.foxnews.com/us/good-samaritans-rescue-woman-attack-mall-bathroom-stall-police](https://www.foxnews.com/us/good-samaritans-rescue-woman-attack-mall-bathroom-stall-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:14:03+00:00

Two good Samaritans in Miami thwarted a suspected rapist from assaulting a woman in a mall bathroom and stood guard over the suspect until police arrived.

## Cori Bush's campaign paid her husband for security services - but he doesn't have a private security license
 - [https://www.foxnews.com/politics/cori-bushs-campaign-paid-husband-security-services-doesnt-have-private-security-license](https://www.foxnews.com/politics/cori-bushs-campaign-paid-husband-security-services-doesnt-have-private-security-license)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:12:18+00:00

Rep. Cori Bush's now-husband, Cortney Merritts, received $60,000 in security payments from her campaign. He does not have a security license in the St. Louis area.

## Northern lights dazzle Alaska in colorful display seen on video
 - [https://www.foxnews.com/science/northern-lights-dazzles-alaska-colorful-display-seen-video](https://www.foxnews.com/science/northern-lights-dazzles-alaska-colorful-display-seen-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:11:38+00:00

The northern lights were captured on video Sunday, with green lights dancing over the skies of Anchorage, Alaska. The lights were seen as far south as Ohio.

## Ugandan lawmaker introduces legislation to prohibit homosexuality in the country
 - [https://www.foxnews.com/world/ugandan-lawmaker-introduces-legislation-prohibit-homosexuality-country](https://www.foxnews.com/world/ugandan-lawmaker-introduces-legislation-prohibit-homosexuality-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:09:22+00:00

Legislation to prohibit sexuality in Uganda was proposed by a lawmaker on Tuesday. The bill would punish "promotion, recruitment, and funding" of LGBTQ related activies.

## Mom who lost sons to fentanyl rips into lawmakers in emotional House testimony: ‘This is war, act like it!'
 - [https://www.foxnews.com/politics/mom-who-lost-sons-fentanyl-rips-lawmakers-emotional-house-testimony-this-war-act-like-it](https://www.foxnews.com/politics/mom-who-lost-sons-fentanyl-rips-lawmakers-emotional-house-testimony-this-war-act-like-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:04:24+00:00

A mother who lost two sons to fentanyl overdoses called the ongoing fentanyl crisis a "war" and called on lawmakers in Congress to do more to combat the epidemic.

## Mom who survived Maoist China rips Virginia Democrats' 'ignorant' opposition to teaching evils of communism
 - [https://www.foxnews.com/media/mom-survived-maoist-china-rips-virginia-democrats-ignorant-opposition-teaching-evils-communism](https://www.foxnews.com/media/mom-survived-maoist-china-rips-virginia-democrats-ignorant-opposition-teaching-evils-communism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:00:55+00:00

Maoist survivor Xi Van Fleet and concerned Virginia father Joe Mobley joined discuss a bill opposed by Democrats that would teach communism's dangerous history.

## Soros-backed DA cuts deal giving no jail time to 'wasted' bus driver who killed cyclist in crash
 - [https://www.foxnews.com/us/soros-backed-da-cuts-deal-giving-no-jail-time-to-wasted-bus-driver-who-killed-cyclist-in-crash](https://www.foxnews.com/us/soros-backed-da-cuts-deal-giving-no-jail-time-to-wasted-bus-driver-who-killed-cyclist-in-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:00:52+00:00

Progressive Austin District Attorney Jose Garza is facing criticism for negotiating a deal that involved no jail time for an intoxicated bus driver who killed a cyclist.

## I worked for the FDA and its dangerous, new decision will put mothers' and their childen's lives at risk
 - [https://www.foxnews.com/opinion/i-worked-fda-its-dangerous-new-decision-will-put-mothers-their-childens-lives-risk](https://www.foxnews.com/opinion/i-worked-fda-its-dangerous-new-decision-will-put-mothers-their-childens-lives-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:00:25+00:00

I worked for the FDA and its dangerous, new decision wasn’t clinical or scientific. It is thinly disguised partisan politics and will put lives at risk.

## Blake Shelton says Kelly Clarkson 'actually got me fired' from 'The Voice,' jokes she runs NBC
 - [https://www.foxnews.com/entertainment/blake-shelton-kelly-clarkson-actually-got-me-fired-the-voice-jokes-runs-nbc](https://www.foxnews.com/entertainment/blake-shelton-kelly-clarkson-actually-got-me-fired-the-voice-jokes-runs-nbc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:00:17+00:00

Blake Shelton is giving more insight into why season 23 of "The Voice" is his last, jokingly blaming coach Kelly Clarkson for getting him fired while on "Jimmy Kimmel Live!"

## Former dean at Oregon State University who sued school for whistleblower retaliation wins lawsuit
 - [https://www.foxnews.com/us/former-dean-oregon-state-university-who-sued-school-whistleblower-retaliation-wins-lawsuit](https://www.foxnews.com/us/former-dean-oregon-state-university-who-sued-school-whistleblower-retaliation-wins-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 17:00:11+00:00

The former dean at Oregon State University has won a whistleblower lawsuit. She was demoted after she reported concerns over student discrimination and harassment.

## California Republicans slam Gavin Newsom for trying to 'intimidate' judges into 'compliance'
 - [https://www.foxnews.com/politics/california-republican-slams-gavin-newsom-trying-intimidate-judges-compliance](https://www.foxnews.com/politics/california-republican-slams-gavin-newsom-trying-intimidate-judges-compliance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:59:24+00:00

Rep. Kevin Kiley, R-Calif., slammed Democrat Governor Gavin Newsom for trying to "intimidate" judges into "compliance" with his judicial agenda

## Prince William and Kate Middleton secure new titles, Princess Margaret's lady-in-waiting talks marriage woes
 - [https://www.foxnews.com/entertainment/prince-william-kate-middleton-secure-new-titles-princess-margarets-lady-in-waiting-talks-marriage-woes](https://www.foxnews.com/entertainment/prince-william-kate-middleton-secure-new-titles-princess-margarets-lady-in-waiting-talks-marriage-woes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:59:07+00:00

The Fox News Entertainment newsletter brings you the latest Hollywood headlines, celebrity interviews and stories from Los Angeles and beyond.

## China’s Xi ‘in a panic’ over coming population crisis, will be ‘more provocative, more belligerent’: Chang
 - [https://www.foxnews.com/world/chinas-xi-panic-coming-population-crisis-more-provocative-more-belligerent-chang](https://www.foxnews.com/world/chinas-xi-panic-coming-population-crisis-more-provocative-more-belligerent-chang)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:58:50+00:00

Gordon Chang says Xi Jinping must be “in a panic” over China's demographic crisis and warns the leader could act "more provocative, more belligerent" as a result.

## 2 California eagle eggs watched by a web cam unlikely to hatch
 - [https://www.foxnews.com/us/2-california-eagle-eggs-watched-web-cam-unlikely-hatch](https://www.foxnews.com/us/2-california-eagle-eggs-watched-web-cam-unlikely-hatch)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:58:37+00:00

A couple of eagle eggs located east of Los Angeles, California, are unlikely to hatch. The group running its web cam livestream says the eggs are two weeks past its expected hatch date.

## CO supermarket shooting suspect, accused of killing 10, diagnosed with schizophrenia
 - [https://www.foxnews.com/us/co-supermarket-shooting-suspect-accused-killing-10-diagnosed-schizophrenia](https://www.foxnews.com/us/co-supermarket-shooting-suspect-accused-killing-10-diagnosed-schizophrenia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:58:18+00:00

Shooting suspect Ahmad Al Aliwi Alissa who allegedly killed 10 people at a supermarket in Boulder, Colorado, in 2021 has been diagnosed with schizophrenia.

## Texas megachurch votes to leave United Methodist Church as mainline denomination fractures over LGBT issues
 - [https://www.foxnews.com/us/texas-megachurch-votes-leave-united-methodist-church-mainline-denomination-fractures-lgbt-issues](https://www.foxnews.com/us/texas-megachurch-votes-leave-united-methodist-church-mainline-denomination-fractures-lgbt-issues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:46:18+00:00

St. Andrew Methodist Church in Plano, Texas, voted overwhelmingly to depart the United Methodist Church last week as the denomination continues to fracture over sexuality.

## Philly judge increases bail for 2 teens accused of beating elderly man with traffic cone
 - [https://www.foxnews.com/us/philly-judge-increases-bail-2-teens-accused-beating-elderly-man-traffic-cone](https://www.foxnews.com/us/philly-judge-increases-bail-2-teens-accused-beating-elderly-man-traffic-cone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:41:14+00:00

Two Philadelphia teenagers are back behind bars after a judge raised their bail Monday. The two are accused of beating an elderly man to death with a traffic cone last summer.

## CNN's Don Lemon claims he lost 'liberal friends' after predicting Trump's win in 2016: 'Kicked out of parties'
 - [https://www.foxnews.com/media/cnns-don-lemon-claims-he-lost-liberal-friends-after-predicting-trumps-win-2016-kicked-out-parties](https://www.foxnews.com/media/cnns-don-lemon-claims-he-lost-liberal-friends-after-predicting-trumps-win-2016-kicked-out-parties)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:39:04+00:00

CNN host Don Lemon claimed Tuesday that he predicted Donald Trump would win the 2016 election and said he "lost a lot of liberal friends" over the suggestion.

## Taliban using fingerprints, gun records to track down Afghans who assisted US, inspector general finds
 - [https://www.foxnews.com/world/taliban-fingerprints-gun-records-track-down-afghans-who-assisted-us-inspector-general-finds](https://www.foxnews.com/world/taliban-fingerprints-gun-records-track-down-afghans-who-assisted-us-inspector-general-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:29:53+00:00

A new report from the Special Inspector General for Afghanistan Reconstruction says the Taliban are using fingerprints and gun records to track down people there who helped the U.S.

## Newly uncovered Mayan sculpture shows female ruler subduing captive male warrior
 - [https://www.foxnews.com/world/newly-uncovered-mayan-sculpture-shows-female-ruler-subduing-captive-male-warrior](https://www.foxnews.com/world/newly-uncovered-mayan-sculpture-shows-female-ruler-subduing-captive-male-warrior)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:28:59+00:00

A new statue of a female ruler subduing a male warrior was discovered at a Mayan ruin site in Mexico. The sculpture depicts the female grasping the captive man’s hair.

## Puerto Rico's only zoo is closing after years of suspected negligence, lack of resources
 - [https://www.foxnews.com/us/puerto-ricos-zoo-closing-after-years-suspected-negligence-lack-resources](https://www.foxnews.com/us/puerto-ricos-zoo-closing-after-years-suspected-negligence-lack-resources)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:22:13+00:00

The only zoo in Puerto Rico is being closed after years of suspected negligence. Federal authorities are investigating allegations of mistreatment of animals.

## Mexican army soldiers kill 5 unlikely armed victims, igniting a clash with angry residents
 - [https://www.foxnews.com/world/mexican-army-soldiers-kill-5-unlikely-armed-victims-igniting-clash-angry-residents](https://www.foxnews.com/world/mexican-army-soldiers-kill-5-unlikely-armed-victims-igniting-clash-angry-residents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:17:20+00:00

Border residents of Nuevo Laredo clashed with the Mexican army Sunday, after soldiers killed five people that protestors believe were unarmed.

## French soccer federation president resigns after audit finds he no longer has the legitimacy to lead
 - [https://www.foxnews.com/sports/french-soccer-federation-president-resigns-audit-longer-legitimacy-lead](https://www.foxnews.com/sports/french-soccer-federation-president-resigns-audit-longer-legitimacy-lead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:16:54+00:00

A government audit on Noël Le Graët found that he no longer had the legitimacy to lead the French soccer federation. Graët resigned from his leadership position on Tuesday.

## DeSantis fires back after Trump's 'pot shots' as 2024 speculation swirls: 'It's silly season'
 - [https://www.foxnews.com/media/desantis-fires-back-trump-pot-shots-2024-speculation-swirls-silly-season](https://www.foxnews.com/media/desantis-fires-back-trump-pot-shots-2024-speculation-swirls-silly-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:15:28+00:00

Florida Gov. Ron DeSantis fired back at President Trump's 'pot shots' as polling indicates the pair remain the GOP's top contenders in the 2024 election

## GOP House Oversight accuses Treasury Department of 'obstructing' probe into Biden family business schemes
 - [https://www.foxnews.com/politics/gop-house-oversight-accuses-treasury-department-obstructing-probe-biden-family-business-schemes](https://www.foxnews.com/politics/gop-house-oversight-accuses-treasury-department-obstructing-probe-biden-family-business-schemes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:15:13+00:00

Rep. James Comer, GOP chairman of the House Oversight Committee, is calling on the Treasury Department to testify March 10 regarding the Biden family's business dealings.

## IA teen pleads guilty to murderihis parents, claims he wanted to 'take charge of his life'
 - [https://www.foxnews.com/us/ia-teen-pleads-guilty-murder-2021-killing-parents-claims-wanted-charge-life](https://www.foxnews.com/us/ia-teen-pleads-guilty-murder-2021-killing-parents-claims-wanted-charge-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:14:38+00:00

A teen killed his parents with a knife and ax in an effort to "take charge of his life." The teen has pleaded guilty to first-degree murder.

## Alex Murdaugh trial: prosecutors recall former law partner in rebuttal case
 - [https://www.foxnews.com/us/alex-murdaugh-trial-prosecutors-recall-former-law-partner-in-rebuttal-case](https://www.foxnews.com/us/alex-murdaugh-trial-prosecutors-recall-former-law-partner-in-rebuttal-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:05:56+00:00

Prosecutors kicked off their rebuttal case Tuesday by recalling Alex Murdaugh's ex-friend and law partner at his double murder trial in Walterboro, South Carolina.

## Sparks fly as Alex Murdaugh's former friend challenges new claims in disbarred attorney's testimony
 - [https://www.foxnews.com/us/alex-murdaugh-trial-prosecutors-recall-former-law-partner-rebuttal-case](https://www.foxnews.com/us/alex-murdaugh-trial-prosecutors-recall-former-law-partner-rebuttal-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:05:56+00:00

Prosecutors kicked off their rebuttal case Tuesday by recalling Alex Murdaugh's ex-friend and law partner at his double murder trial in Walterboro, South Carolina.

## Climate activists say Norway's energy minister is speaking 'nonsense'
 - [https://www.foxnews.com/us/climate-activists-say-norways-energy-minister-speaking-nonsense](https://www.foxnews.com/us/climate-activists-say-norways-energy-minister-speaking-nonsense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:04:38+00:00

Climate activists accused Terje Aasland of speaking nonsense when he met with wind farm protestors. Aasland said the government will make a "new decision" regarding the wind farm.

## Tom Cotton eviscerates liberal media after COVID lab bombshell: 'They act like lawyers for Chinese communists'
 - [https://www.foxnews.com/media/tom-cotton-eviscerates-liberal-media-lawyers-chinese-communist-party-covid-lab-bombshell](https://www.foxnews.com/media/tom-cotton-eviscerates-liberal-media-lawyers-chinese-communist-party-covid-lab-bombshell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:00:23+00:00

Sen. Tom Cotton, R-Ark., slams President Biden and Democrats after an Energy Department classified report suggests COVID-19 originated in a Chinese lab.

## New York teacher 'forced' and 'manipulated' 5th-grader to become transgender, causing suicidal ideation: suit
 - [https://www.foxnews.com/media/new-york-teacher-forced-manipulated-5th-grader-become-transgender-causing-suicidal-ideation-suit](https://www.foxnews.com/media/new-york-teacher-forced-manipulated-5th-grader-become-transgender-causing-suicidal-ideation-suit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 16:00:09+00:00

A New York teacher in the Brookhaven-Comsewogue School District, Debra Rosenquist, is accused in a lawsuit of having "forced" a 5th-grade girl to change her gender.

## Honda turned the CR-V into a supercapacitor-powered 'Beast'
 - [https://www.foxnews.com/auto/honda-cr-v-supercapacitor-powered-indycar](https://www.foxnews.com/auto/honda-cr-v-supercapacitor-powered-indycar)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:59:54+00:00

The Honda CR-V Hybrid Racer is an IndyCar-powered experimental vehicle that showcases the automaker's technology and will appear at IndyCar events.

## Illinois police officer in critical condition after being wounded while responding to a fatal shooting
 - [https://www.foxnews.com/us/illinois-police-officer-critical-condition-wounded-responding-fatal-shooting](https://www.foxnews.com/us/illinois-police-officer-critical-condition-wounded-responding-fatal-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:58:41+00:00

An Illinois officer was wounded while responding to a homicide on Monday. The officer is in critical but stable condition. The suspect allegedly killed himself following the incident.

## Celtics’ Jayson Tatum earns first career ejection against Knicks: ‘Good for my rep’
 - [https://www.foxnews.com/sports/celtics-jayson-tatum-earns-first-career-ejection-against-knicks-good-for-my-rep](https://www.foxnews.com/sports/celtics-jayson-tatum-earns-first-career-ejection-against-knicks-good-for-my-rep)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:57:23+00:00

Boston Celtics All-Star Jayson Tatum was ejected for the first time in his career Monday night against the New York Knicks, earning his second technical in the fourth quarter.

## Police scour Hong Kong landfill for slain model Abby Choi's missing body parts
 - [https://www.foxnews.com/world/police-scour-hong-kong-landfill-slain-model-abby-chois-missing-body-parts](https://www.foxnews.com/world/police-scour-hong-kong-landfill-slain-model-abby-chois-missing-body-parts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:55:31+00:00

Roughly 100 Hong Kong police officers scoured a landfill looking for missing body parts of model Abby Choi whose legs and skull were found in her former father-in-law's home.

## Suspect poisons hundreds of schoolgirls in Iran, possibly to close classrooms for girls seeking an education
 - [https://www.foxnews.com/world/suspect-poisons-hundreds-schoolgirls-iran-possibly-close-classrooms-girls-seeking-education](https://www.foxnews.com/world/suspect-poisons-hundreds-schoolgirls-iran-possibly-close-classrooms-girls-seeking-education)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:54:18+00:00

Hundreds of Iranian schoolgirls across multiple schools were poisoned by fumes wafting into classrooms. Authorities believe the suspect wants to stop girls from seeking an education.

## Illinois sheriff's deputy suffers serious injuries after North Carolina truck driver crashes into squad car
 - [https://www.foxnews.com/us/illinois-sheriffs-deputy-suffers-serious-injuries-north-carolina-truck-driver-crashes-squad-car](https://www.foxnews.com/us/illinois-sheriffs-deputy-suffers-serious-injuries-north-carolina-truck-driver-crashes-squad-car)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:50:45+00:00

A North Carolina pickup truck driver crashed into a squad car seriously injuring an Illinois sheriff's deputy. The driver was opening a beer when he crashed.

## German babysitter sentenced nearly 15 years for more than 100 child sex crimes: 'Unimaginable brutality'
 - [https://www.foxnews.com/world/german-babysitter-sentenced-nearly-15-years-more-than-100-child-sex-crimes-unimaginable-brutality](https://www.foxnews.com/world/german-babysitter-sentenced-nearly-15-years-more-than-100-child-sex-crimes-unimaginable-brutality)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:48:29+00:00

A 45-year-old German babysitter will spend nearly 15 years in prison for sexually abusing dozens of children over a 14-year-period with the youngest victim being a month old.

## Alex Murdaugh trial: Who's who in South Carolina family dynasty
 - [https://www.foxnews.com/us/alex-murdaugh-trial-whos-who-south-carolina-family-dynasty](https://www.foxnews.com/us/alex-murdaugh-trial-whos-who-south-carolina-family-dynasty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:45:54+00:00

Here are the family members involved in the Alex Murdaugh double murder trial in South Carolina. Murdaugh is accused of killing his wife and son in June 2021.

## ‘Jeopardy!’ fans furious after Mayim Bialik schedule announcement
 - [https://www.foxnews.com/entertainment/jeopardy-fans-furious-mayim-bialik-schedule-announcement](https://www.foxnews.com/entertainment/jeopardy-fans-furious-mayim-bialik-schedule-announcement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:45:24+00:00

"Jeopardy!" fans slammed the game show's hosting schedule as a producer announced the upcoming lineup for the next several months. Mayim Bialik and Ken Jennings currently host.

## Struggling Lori Lightfoot suggests TIME Magazine is racist for not featuring her on cover like Rahm Emanuel
 - [https://www.foxnews.com/media/struggling-lori-lightfoot-suggests-time-magazine-racist-not-featuring-her-cover-like-rahm-emanuel](https://www.foxnews.com/media/struggling-lori-lightfoot-suggests-time-magazine-racist-not-featuring-her-cover-like-rahm-emanuel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:42:37+00:00

Chicago Mayor Lori Lightfoot told Politico that her re-election chances would be better if media wasn't discriminating against her based on her sex and race.

## British police launch major search for 2-month-old baby after officers arrest infant's parents
 - [https://www.foxnews.com/world/british-police-launch-major-search-2-month-old-baby-officers-arrest-infants-parents](https://www.foxnews.com/world/british-police-launch-major-search-2-month-old-baby-officers-arrest-infants-parents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:42:05+00:00

British police recently arrested Aristocrat Constance Marten and Mark Gordon who have been on the run since January. The police are now looking for the couple's infant son.

## NYC spends nearly $100 million to house migrants in hotels after out-of-state busing
 - [https://www.foxnews.com/us/nyc-spends-nearly-100-million-house-migrants-hotels-after-out-state-busing](https://www.foxnews.com/us/nyc-spends-nearly-100-million-house-migrants-hotels-after-out-state-busing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:40:45+00:00

New York City is spending $93.8 million on housing migrants at hotels in Manhattan through the spring, reports show. At least 47,600 migrants have flooded the city since 2022.

## Biden to accuse Republicans of 'slashing Medicaid' in Tuesday speech
 - [https://www.foxnews.com/politics/biden-accuse-republicans-slashing-medicaid-tuesday-speech](https://www.foxnews.com/politics/biden-accuse-republicans-slashing-medicaid-tuesday-speech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:35:49+00:00

President Biden will accuse Republicans of plotting to cut Medicaid and other health care programs in a speech delivered in Virginia Beach on Tuesday.

## Big businesses go woke, China's lab leak, and more from Fox News Opinion
 - [https://www.foxnews.com/opinion/big-businesses-go-woke-china-lab-leak-and-more-from-fox-news-opinion](https://www.foxnews.com/opinion/big-businesses-go-woke-china-lab-leak-and-more-from-fox-news-opinion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:17:38+00:00

Read the latest from Fox News Opinion & watch videos from Tucker Carlson, Sean Hannity, Laura Ingraham & more.

## Rangers’ defenseman K’Andre Miller to have disciplinary hearing for spitting on Kings veteran Drew Doughty
 - [https://www.foxnews.com/sports/rangers-defenseman-kandre-miller-have-disciplinary-hearing-spitting-kings-veteran-drew-doughty](https://www.foxnews.com/sports/rangers-defenseman-kandre-miller-have-disciplinary-hearing-spitting-kings-veteran-drew-doughty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:17:10+00:00

The NHL Department of Player Safety will hold a hearing to consider supplemental discipline after Rangers’ defenseman K’Andre Miller was ejected from a game for spitting at a player.

## Don’t fall for these fake, malware-producing ChatGPT sites, apps
 - [https://www.foxnews.com/tech/fall-these-fake-malware-producing-chatgpt-sites-apps](https://www.foxnews.com/tech/fall-these-fake-malware-producing-chatgpt-sites-apps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:10:44+00:00

ChatGPT is a breakthrough in AI-technology, but some see it as an opportunity to steal your information. Kurt "CyberGuy" Knutsson shows you how to protect your tech.

## Congress poised to end decades-old Iraq war authorizations
 - [https://www.foxnews.com/politics/congress-poised-end-decades-old-iraq-war-authorizations](https://www.foxnews.com/politics/congress-poised-end-decades-old-iraq-war-authorizations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:07:21+00:00

Congress is making another push to end the Iraq war military authorizations, which bipartisan presidents have used for decades to justify military action across the globe.

## LA prosecutor in Hannah Tubbs case slams suspension, Gascon: 'Punished for hurting child molester's feelings'
 - [https://www.foxnews.com/media/la-prosecutor-hannah-tubbs-case-slams-suspension-gascon-punished-hurting-child-molesters-feelings](https://www.foxnews.com/media/la-prosecutor-hannah-tubbs-case-slams-suspension-gascon-punished-hurting-child-molesters-feelings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:00:47+00:00

The LA prosecutor reprimanded for misgendering a trans child molester spoke out against what he called an unjust suspension by District Attorney George Gascon.

## Republicans and activists slam $5 million 'reparations' proposal in San Francisco: 'No justification'
 - [https://www.foxnews.com/media/republicans-activists-slam-5-million-reparations-proposal-san-francisco-no-justification](https://www.foxnews.com/media/republicans-activists-slam-5-million-reparations-proposal-san-francisco-no-justification)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:00:04+00:00

Political commentators, Republican leaders and even pro-reparations activists spoke out against a recent reparations proposal in San Francisco that would cost billions.

## This school choice bill could help millions of students recover from shocking learning loss
 - [https://www.foxnews.com/opinion/school-choice-bill-help-millions-students-recover-shocking-learning-loss](https://www.foxnews.com/opinion/school-choice-bill-help-millions-students-recover-shocking-learning-loss)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 15:00:02+00:00

The U.S. Department of Education recently released a report which bodes ill for America's students.

## Legendary Virginia men’s basketball coach Terry Holland dead at 80
 - [https://www.foxnews.com/sports/legendary-virginia-mens-basketball-coach-terry-holland-dead-80](https://www.foxnews.com/sports/legendary-virginia-mens-basketball-coach-terry-holland-dead-80)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:58:41+00:00

Legendary Virginia men's basketball coach Terry Holland passed away Sunday at the age of 80. Holland went 326-173 as head coach of the Cavaliers.

## Credibility crisis: Egg on media’s face after dismissing COVID lab leak as 'debunked' conspiracy theory
 - [https://www.foxnews.com/media/credibility-crisis-egg-medias-face-after-dismissing-covid-lab-leak-debunked-conspiracy-theory](https://www.foxnews.com/media/credibility-crisis-egg-medias-face-after-dismissing-covid-lab-leak-debunked-conspiracy-theory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:52:08+00:00

The COVID lab leak theory is the latest example of journalists dismissing an inconvenient narrative as "debunked" before the facts come in, analysts say.

## GOP comes out swinging at China: 5 hearings, votes on a dozen bills aimed at CCP
 - [https://www.foxnews.com/politics/gop-comes-out-swinging-china-5-hearings-votes-dozen-bill-aimed-ccp](https://www.foxnews.com/politics/gop-comes-out-swinging-china-5-hearings-votes-dozen-bill-aimed-ccp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:51:30+00:00

House Republicans on Tuesday were taking several steps aimed at reining in China's economic and scientific prowess, as well as warding off the threat of a Taiwan invasion.

## Fred Miller, former Colts star and Super Bowl champion, dead at 82
 - [https://www.foxnews.com/sports/fred-miller-former-colts-star-super-bowl-champion-dead-82](https://www.foxnews.com/sports/fred-miller-former-colts-star-super-bowl-champion-dead-82)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:49:46+00:00

Indianapolis Colts owner Jim Irsay confirmed the death of former All-Pro defensive tackle Fred Miller in a Tweet on Monday. He was 82.

## Government-backed 'disinformation' group under fire for punishing outlets that reported on lab leak theory
 - [https://www.foxnews.com/politics/government-disinformation-group-fire-punishing-outlets-reported-lab-leak-theory](https://www.foxnews.com/politics/government-disinformation-group-fire-punishing-outlets-reported-lab-leak-theory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:45:22+00:00

The Global Disinformation Index was called out for censoring media that reported on the "lab leak theory," after a federal agency suggested.the virus could have originated in a lab.

## 4 major mistakes the experts made about COVID despite saying they would 'follow the science'
 - [https://www.foxnews.com/politics/major-mistakes-experts-made-covid-saying-follow-science](https://www.foxnews.com/politics/major-mistakes-experts-made-covid-saying-follow-science)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:34:25+00:00

Key recommendations pushed by the country's public health experts and implemented by government to combat COVID turned out to be misguided if not outright wrong.

## Philippines shifts focus to protecting territory as tensions between China and US increase
 - [https://www.foxnews.com/world/the-philippines-shifts-focus-protecting-territory-tensions-between-china-us-increase](https://www.foxnews.com/world/the-philippines-shifts-focus-protecting-territory-tensions-between-china-us-increase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:29:52+00:00

The president of the Philippines said the military will shift its focus to protecting the country as tensions between the U.S. and China intensify.

## Oregon murder suspect found hiding under blanket in closet after escaping courthouse
 - [https://www.foxnews.com/us/oregon-murder-suspect-found-hiding-blanket-closet-escaping-courthouse](https://www.foxnews.com/us/oregon-murder-suspect-found-hiding-blanket-closet-escaping-courthouse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:28:49+00:00

Oregon murder suspect Edi Villalobos has been found hiding in a closet in Hillsboro after escaping a courthouse during his trial, the Washington County Sheriff’s Office says.

## Thai, US officials open annual Cobra Gold military exercises following sharp pandemic cutbacks
 - [https://www.foxnews.com/us/thai-us-officials-open-annual-cobra-gold-military-exercises-sharp-pandemic-cutbacks](https://www.foxnews.com/us/thai-us-officials-open-annual-cobra-gold-military-exercises-sharp-pandemic-cutbacks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:28:09+00:00

Cobra Gold military exercises opened on Tuesday, according to Thai and U.S. officials. Countries including Singapore, Japan, Indonesia, South Korea, and Malaysia will participate.

## Clean machine: Jeep launches waterproof seats and floors for Wrangler
 - [https://www.foxnews.com/auto/clean-machine-jeep-waterproof-seats-floors-wrangler](https://www.foxnews.com/auto/clean-machine-jeep-waterproof-seats-floors-wrangler)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:22:21+00:00

Jeep Performance Parts is now offering waterproof vinyl seats and heavy-duty flooring for the four-door Wrangler that can be hosed out for cleaning.

## Protestant Council of Rwanda directs health facilities to stop carrying out all abortions
 - [https://www.foxnews.com/world/protestant-council-rwanda-directs-health-facilities-stop-carrying-abortions](https://www.foxnews.com/world/protestant-council-rwanda-directs-health-facilities-stop-carrying-abortions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:20:28+00:00

The Protestant Council of Rwanda recently described abortion as a sin. The council has directed health facilities run by its members to stop carrying out abortions.

## Chicago mayoral election: Polls open as Lightfoot faces 8 challengers, with crime top of mind
 - [https://www.foxnews.com/politics/chicago-mayoral-election-polls-open-lightfoot-faces-8-challengers-crime-top-mind](https://www.foxnews.com/politics/chicago-mayoral-election-polls-open-lightfoot-faces-8-challengers-crime-top-mind)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:07:47+00:00

Voting in the Chicago mayoral election began Tuesday as incumbent Lori Lightfoot aims to avoid becoming the first one-term mayor in decades.

## San Francisco reparations panel on how it decided on $5M per Black person: ‘There wasn’t a math formula'
 - [https://www.foxnews.com/politics/san-francisco-reparations-panel-decided-5m-per-black-person-wasnt-math-formula](https://www.foxnews.com/politics/san-francisco-reparations-panel-decided-5m-per-black-person-wasnt-math-formula)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:04:53+00:00

A San Francisco reparations panel says it did not use a "math formula" to arrive at its recommendation to give $5 million in reparations to every qualifying Black resident.

## Two victims identified from Minnesota shooting after celebration of life
 - [https://www.foxnews.com/us/two-victims-identified-minnesota-shooting-celebration-life](https://www.foxnews.com/us/two-victims-identified-minnesota-shooting-celebration-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 14:00:40+00:00

Police in St. Paul, Minnesota have released the identities of the two men shot during a shooting after a celebration of life over the weekend. Three others were injured.

## Transgender runner wins women’s 1500m at Canadian Masters Indoor Championships
 - [https://www.foxnews.com/sports/transgender-runner-wins-womens-1500m-canadian-masters-indoor-championships](https://www.foxnews.com/sports/transgender-runner-wins-womens-1500m-canadian-masters-indoor-championships)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:43:09+00:00

Canadian record holder Tiffany Newell, a 50-year-old transgender female runner, placed first at the 2023 Canadian Masters Indoor Championships over the weekend with a time of 5:07.62.

## Tom Selleck has 'Magnum P.I.' reunion with Larry Manetti on 'Blue Bloods'
 - [https://www.foxnews.com/entertainment/tom-selleck-magnum-p-i-reunion-larry-manetti-blue-bloods](https://www.foxnews.com/entertainment/tom-selleck-magnum-p-i-reunion-larry-manetti-blue-bloods)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:38:32+00:00

Longtime "Magnum P.I." stars Tom Selleck and Larry Manetti reunited after 35 years. Manetti will be featured on Selleck's crime drama series "Blue Bloods."

## Many zoos in US phasing out elephants while others embark on breeding projects
 - [https://www.foxnews.com/us/many-zoos-us-phasing-out-elephants-others-embark-breeding-projects](https://www.foxnews.com/us/many-zoos-us-phasing-out-elephants-others-embark-breeding-projects)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:26:01+00:00

Some zoos in the U.S. are phasing out elephants due to the complexity of the animals while others are breeding them to ensure future generations of zoo elephants.

## Hong Kong to lift COVID mask mandate for both outside, inside areas on Wednesday
 - [https://www.foxnews.com/world/hong-kong-lift-covid-mask-mandate-outside-inside-areas-wednesday](https://www.foxnews.com/world/hong-kong-lift-covid-mask-mandate-outside-inside-areas-wednesday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:24:04+00:00

Hong Kong plans to lift its coronavirus mask mandate by Wednesday. Residents will no longer need to mask when they’re outdoors and indoors, including in public transit.

## Republicans unveil effort to boost energy production, fast-track permitting process
 - [https://www.foxnews.com/politics/republicans-unveil-effort-boost-energy-production-fast-track-permitting-process](https://www.foxnews.com/politics/republicans-unveil-effort-boost-energy-production-fast-track-permitting-process)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:23:39+00:00

Republicans are preparing to unveil a series of bills designed to increase energy production on federal lands, reduce permitting delays and strengthen critical mineral supply chains.

## India revives civil militia after 7 Hindus were killed in disputed region of Kashmir
 - [https://www.foxnews.com/world/india-revives-civil-militia-after-7-hindus-killed-disputed-region-kashmir](https://www.foxnews.com/world/india-revives-civil-militia-after-7-hindus-killed-disputed-region-kashmir)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:21:41+00:00

The Indian government is rearming and training villagers to revive a civil militia after seven Hindus were killed in Kashmir, a disputed region between India and Pakistan.

## Gov. Kathy Hochul loses support in New York amid surge in concern over crime and living costs: poll
 - [https://www.foxnews.com/politics/gov-kathy-hochul-loses-support-new-york-amid-surge-concern-crime-living-costs-poll](https://www.foxnews.com/politics/gov-kathy-hochul-loses-support-new-york-amid-surge-concern-crime-living-costs-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:20:27+00:00

New York Gov. Kathy Hochul is witnessing a drop in support as crime and the cost of living continue to dominate concerns from voters who reside in the state.

## CNN ridiculed for suggesting 'wealthy' Supreme Court is biased against student loan debtors: 'Worst tweet'
 - [https://www.foxnews.com/media/cnn-ridiculed-suggesting-wealthy-supreme-court-biased-student-loan-debtors-worst-tweet](https://www.foxnews.com/media/cnn-ridiculed-suggesting-wealthy-supreme-court-biased-student-loan-debtors-worst-tweet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:20:05+00:00

A CNN analysis on Monday emphasized how wealthy and Ivy League graduates on the Supreme Court are going to ultimately decide the fate of student debt relief.

## Jon Stewart recounts angry backlash for pushing lab leak theory on Colbert: 'F--- you, I'm done'
 - [https://www.foxnews.com/media/jon-stewart-recounts-angry-backlash-pushing-lab-leak-rant-colbert-f-you-done](https://www.foxnews.com/media/jon-stewart-recounts-angry-backlash-pushing-lab-leak-rant-colbert-f-you-done)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:10:51+00:00

Comedian Jon Stewart said Monday he was astonished by the left-wing anger toward him in 2021 for espousing the lab-leak theory for the COVID-19 pandemic.

## Rivian trucks and Minis are the most satisfying electric vehicles, study finds
 - [https://www.foxnews.com/auto/rivian-trucks-minis-most-satisfying-electric-vehicles](https://www.foxnews.com/auto/rivian-trucks-minis-most-satisfying-electric-vehicles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:10:44+00:00

The Rivian R1T and Mini Cooper Electric were the highest-ranked models on J.D. Power's 2023 U.S. Electric Vehicle Experience Ownership Study.

## Snow accumulates in NYC following Northeast storm
 - [https://www.foxnews.com/us/snow-accumulates-nyc-following-northeast-storm](https://www.foxnews.com/us/snow-accumulates-nyc-following-northeast-storm)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:10:43+00:00

The Northeast and Midwest will be hit by the next storm on Friday, bringing the risk of rain and snow. This comes as severe weather returns to the southern Plains.

## Gov. Ron DeSantis: Disney will finally pay its fair share
 - [https://www.foxnews.com/media/gov-ron-desantis-disney-finally-pay-fair-share](https://www.foxnews.com/media/gov-ron-desantis-disney-finally-pay-fair-share)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:05:33+00:00

Florida Republican Gov. Ron DeSantis explains why Disney got its self-governing status revoked on "Tucker Carlson Tonight."

## Winter storm brings messy travel conditions for Northeast
 - [https://www.foxnews.com/us/winter-storm-snow-messy-travel-conditions-northeast](https://www.foxnews.com/us/winter-storm-snow-messy-travel-conditions-northeast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:04:52+00:00

A winter storm moving through the Northeast Tuesday is creating difficult travel conditions for millions of Americans while winter weather warnings and advisories are in effect.

## If you think Gavin Newsom has a political future, just ask these folks fleeing California
 - [https://www.foxnews.com/opinion/think-gavin-newsom-political-future-folks-fleeing-california](https://www.foxnews.com/opinion/think-gavin-newsom-political-future-folks-fleeing-california)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:00:46+00:00

Gavin Newsom is expected to be maneuvering to run for the Democrat nomination for president.

## House China Committee sets primetime hearing on CCP’s ‘threat to America’
 - [https://www.foxnews.com/politics/house-china-committee-prime-time-hearing-ccps-threat-america](https://www.foxnews.com/politics/house-china-committee-prime-time-hearing-ccps-threat-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:00:40+00:00

The new House China Select Committee is holding its first hearing Tuesday night, featuring testimony from former national security officials on the China threat.

## Roseanne Barr, Candace Cameron Bure, Liam Neeson: Celebrities overcome cancel culture
 - [https://www.foxnews.com/entertainment/roseanne-barr-candace-cameron-bure-liam-neeson-celebrities-overcome-cancel-culture](https://www.foxnews.com/entertainment/roseanne-barr-candace-cameron-bure-liam-neeson-celebrities-overcome-cancel-culture)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 13:00:13+00:00

Stars like Roseanne Barr, Dave Chappelle, Liam Neeson, and more have faced being canceled, but found ways to recover their careers.

## China plans to begin training foreign astronauts for trips to newly completed orbiting space station
 - [https://www.foxnews.com/world/china-plans-begin-training-foreign-astronauts-trips-newly-completed-orbiting-space-station](https://www.foxnews.com/world/china-plans-begin-training-foreign-astronauts-trips-newly-completed-orbiting-space-station)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 12:30:11+00:00

China recently completed building the Tiangong Station, an orbitting space station. The country will soon begin training foreign astronauts for trips to the station.

## Belarusian President Alexander Lukashenko heading to Beijing for 3-day visit
 - [https://www.foxnews.com/world/belarusian-president-alexander-lukashenko-heading-beijing-3-day-visit](https://www.foxnews.com/world/belarusian-president-alexander-lukashenko-heading-beijing-3-day-visit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 12:29:42+00:00

The president of Belarus is heading to Beijing as tensions rise over Russia's invasion of Ukraine. There has been growing concerns that China will provide military assistance to Russia

## 11-year-old rips sexually explicit material in his Maine middle school: 'The librarian asked if I wanted more'
 - [https://www.foxnews.com/media/11-year-old-speaks-out-against-pornographic-content-maine-middle-school-admin-should-be-prosecuted](https://www.foxnews.com/media/11-year-old-speaks-out-against-pornographic-content-maine-middle-school-admin-should-be-prosecuted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 12:26:18+00:00

Knox Zajac, an 11–year-old sixth grader from Maine, spoke out against "pornographic" content in his middle school and wants the administrators to be prosecuted.

## Weather quiz! See if you have what it takes to be a meteorologist
 - [https://www.foxnews.com/lifestyle/weather-quiz-see-you-have-what-it-takes-be-meteorolog](https://www.foxnews.com/lifestyle/weather-quiz-see-you-have-what-it-takes-be-meteorolog)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 12:22:53+00:00

Rain or shine, sleet or snow, you'll want to test your knowledge of the weather in this fun and engaging lifestyle quiz. Try your hand at 15 questions!

## Dem-led state could soon shrink, man busted trying to board plane with AR-15 and more top headlines
 - [https://www.foxnews.com/us/dem-led-state-could-soon-shrink-man-busted-trying-to-board-plane-with-ar-15-and-more-top-headlines](https://www.foxnews.com/us/dem-led-state-could-soon-shrink-man-busted-trying-to-board-plane-with-ar-15-and-more-top-headlines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 12:11:51+00:00

Dem-led state could soon shrink, man busted trying to board plane with AR-15 and more top headlines

## Biden could issue his first veto as Congress prepares to vote against ESG investment rule
 - [https://www.foxnews.com/politics/biden-issue-first-veto-congress-prepares-vote-against-esg-investment-rule](https://www.foxnews.com/politics/biden-issue-first-veto-congress-prepares-vote-against-esg-investment-rule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 12:00:55+00:00

Lawmakers have said the Department of Labor rule "politicizes" the retirement savings for millions of Americans and are voting to disapprove the rule and kill it.

## Pennsylvania county terminates 'sanctuary county' designation amid 'heartache and angst'
 - [https://www.foxnews.com/us/pennsylvania-county-terminates-sanctuary-county-designation-heartache-angst](https://www.foxnews.com/us/pennsylvania-county-terminates-sanctuary-county-designation-heartache-angst)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 12:00:41+00:00

Butler County, Pennsylvania, announced that it is no longer a "sanctuary county" for illegal immigrants amid what the county commissioner described as “heartache and angst.”

## Columbia University scientists predict record-breaking heat will return this summer
 - [https://www.foxnews.com/us/columbia-university-scientists-record-breaking-heat-return-summer](https://www.foxnews.com/us/columbia-university-scientists-record-breaking-heat-return-summer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 12:00:08+00:00

Columbia scientists believe the extreme heat from 2022 will return in 2023. They expect both ocean and atmospheric temperatures to continue to rise.

## Federal government rests its case in ex-Ohio House Speaker Larry Householder's racketeering trial
 - [https://www.foxnews.com/us/federal-government-rests-case-ex-ohio-house-speaker-larry-householders-racketeering-trial](https://www.foxnews.com/us/federal-government-rests-case-ex-ohio-house-speaker-larry-householders-racketeering-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:57:50+00:00

After the government presented jurors with financial documents, emails, wire-tap audio, and firsthand accounts, it rested its case in ex-Ohio House Speaker Larry Householder's trial.

## Reporter's Notebook: Why Russians are so quick to blame the US
 - [https://www.foxnews.com/world/reporters-notebook-why-russians-are-quick-blame-the-us](https://www.foxnews.com/world/reporters-notebook-why-russians-are-quick-blame-the-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:55:21+00:00

Russians have a high approval rating for Putin and the Ukraine war which may be due to the country's history with the United States and the Cold War.

## Brittany Mahomes, Chiefs star’s wife, calls out ‘grown men talking s---' following Joe Rogan’s divorce comment
 - [https://www.foxnews.com/sports/brittany-mahomes-chiefs-stars-wife-calls-out-grown-men-talking-following-joe-rogans-divorce-comment](https://www.foxnews.com/sports/brittany-mahomes-chiefs-stars-wife-calls-out-grown-men-talking-following-joe-rogans-divorce-comment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:30:30+00:00

Brittany Mahomes, wife of Kansas City Chiefs star Patrick Mahomes, seemed to respond to Joe Rogan's recent comments insinuating a divorce for the couple down the road.

## Top Republican raises alarm on Biden energy secretary's work with China-connected group pushing gas stove ban
 - [https://www.foxnews.com/politics/top-republican-raises-alarm-biden-energy-secretarys-work-china-connected-group-pushing-gas-stove-ban](https://www.foxnews.com/politics/top-republican-raises-alarm-biden-energy-secretarys-work-china-connected-group-pushing-gas-stove-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:30:23+00:00

Rep. Bill Huizenga, R-Mich., sounded the alarm Monday on the Department of Energy's work with a Chinese-connected organization pushing bans on gas stoves.

## Prince Harry to live-stream ‘intimate conversation’ with ‘addiction expert’ in $33 TV special
 - [https://www.foxnews.com/media/prince-harry-live-stream-intimate-conversation-with-trauma-expert-33-tv-special](https://www.foxnews.com/media/prince-harry-live-stream-intimate-conversation-with-trauma-expert-33-tv-special)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:24:43+00:00

A live-stream chat between Prince Harry and "renowned addiction expert" Gabor Maté is set to air on March 4 and is being advertised as an "intimate conversation."

## Brooke Burke says biohacking is the key to her amazing physique at 51: 'I am obsessed'
 - [https://www.foxnews.com/entertainment/brooke-burke-says-biohacking-key-amazing-physique-51](https://www.foxnews.com/entertainment/brooke-burke-says-biohacking-key-amazing-physique-51)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:24:34+00:00

Brooke Burke, 51, shared in a recent interview that she is incorporating biohacking into her lifestyle which helps her stay in great shape.

## CCP government 'intentionally released' COVID-19 'all over the world,' Chinese virologist says
 - [https://www.foxnews.com/media/ccp-government-intentionally-released-covid-19-over-world-chinese-virologist](https://www.foxnews.com/media/ccp-government-intentionally-released-covid-19-over-world-chinese-virologist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:20:58+00:00

Dr. Li Meng Yan, a Chinese virologist who sounded the alarm about the origins of COVID-19 in early 2020, speaks out after a classified intelligence report from the Energy Department found the virus most likely came from a Chinese lab.

## Controversial Virginia school board member doubles down on Iwo Jima comments, says backlash a 'distortion'
 - [https://www.foxnews.com/media/controversial-virginia-school-board-member-doubles-down-iwo-jima-comments-says-backlash-distortion](https://www.foxnews.com/media/controversial-virginia-school-board-member-doubles-down-iwo-jima-comments-says-backlash-distortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:20:52+00:00

An embattled school district in Virginia has been ground zero for controversial public school education policies and one member of the school board has frequently made headlines for her left-wing talking points.

## College students urge others to take pride in faith, ditch social media for God: ‘Cool to be a Christian’
 - [https://www.foxnews.com/media/college-students-take-pride-faith-social-media-god-cool-christian](https://www.foxnews.com/media/college-students-take-pride-faith-social-media-god-cool-christian)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:20:00+00:00

Asbury University students said they hoped other college campuses would accept the love of God and told students to be open about their faith with classmates.

## Media slammed after Energy Dept joins COVID lab-leak chorus: 'Journalists believed China over US senators'
 - [https://www.foxnews.com/media/media-slammed-energy-dept-covid-lab-leak-chorus-journalists-believed-china-senators](https://www.foxnews.com/media/media-slammed-energy-dept-covid-lab-leak-chorus-journalists-believed-china-senators)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:15:39+00:00

Fox News contributor Joe Concha sounded off on the media's take on the lab leak theory after the Energy Department assessed in favor of it in a recent report.

## 'Shark Tank's' Kevin O'Leary slams blue-state regulation: 'Massachusetts is at war with entrepreneurship'
 - [https://www.foxnews.com/media/shark-tanks-kevin-oleary-slams-blue-state-regulation-taxation-massachusetts-war-entrepreneurship](https://www.foxnews.com/media/shark-tanks-kevin-oleary-slams-blue-state-regulation-taxation-massachusetts-war-entrepreneurship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:00:58+00:00

'Shark Tank' investor Kevin O'Leary called out Massachusetts and other heavily-regulated states business-wise, on the latest episode of Fox Nation's "Tucker Carlson Today."

## Alex Murdaugh trial: Prosecution to present rebuttal case; jurors may visit crime scene
 - [https://www.foxnews.com/us/alex-murdaugh-trial-prosecution-present-rebuttal-case-jurors-visit-crime-scene](https://www.foxnews.com/us/alex-murdaugh-trial-prosecution-present-rebuttal-case-jurors-visit-crime-scene)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:00:51+00:00

Prosecutors are scheduled to call at least four witness in their rebuttal case Tuesday at Alex Murdaugh's double-murder trial in Walterboro, South Carolina.

## COVID leaked from a Wuhan lab. Here's how we hold China & Fauci accountable
 - [https://www.foxnews.com/opinion/covid-leaked-wuhan-lab-hold-china-fauci-accountable](https://www.foxnews.com/opinion/covid-leaked-wuhan-lab-hold-china-fauci-accountable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:00:47+00:00

U.S. Department of Energy concluded that the COVID-19 pandemic most likely came from a laboratory leak in China.

## Biden ripped for 'I may be a White boy, but I'm not stupid' comment at Black History Month event: 'He is both'
 - [https://www.foxnews.com/media/biden-ripped-white-boy-stupid-comment-black-history-month-event](https://www.foxnews.com/media/biden-ripped-white-boy-stupid-comment-black-history-month-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:00:09+00:00

President Biden appeared to suggest that many White men are thought of as being "stupid" by default during an event celebrating Black History Month.

## Iran reissues threat to 'kill Trump, Pompeo' for Soleimani death when announcing long-range cruise missile
 - [https://www.foxnews.com/world/iran-reissues-threat-kill-trump-pompeo-soleimani-death-announcing-long-range-cruise-missile](https://www.foxnews.com/world/iran-reissues-threat-kill-trump-pompeo-soleimani-death-announcing-long-range-cruise-missile)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:00:09+00:00

Iran has renewed threats to target former President Donald Trump and his former Secretary of State Mike Pompeo for the 2020 killing of Qasem Soleimani.

## Inside how the Navy axed male pilots to stage all-women Super Bowl flyover
 - [https://www.foxnews.com/us/inside-how-navy-axed-male-pilots-stage-all-women-super-bowl-flyover](https://www.foxnews.com/us/inside-how-navy-axed-male-pilots-stage-all-women-super-bowl-flyover)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 11:00:02+00:00

Fox News Digital spoke to a Navy aircrew member who was originally slated to fly over the Super Bowl before male pilots were booted in favor of an all-women team.

## Marjorie Taylor Greene says she was 'attacked' in restaurant by 'insane' woman: 'Completely out of control'
 - [https://www.foxnews.com/politics/marjorie-taylor-greene-attacked-inside-restaurant-insane-woman-completely-out-control](https://www.foxnews.com/politics/marjorie-taylor-greene-attacked-inside-restaurant-insane-woman-completely-out-control)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 10:38:10+00:00

Rep. Marjorie Taylor Greene said she was at a restaurant Monday evening when she was attacked by an “insane woman” and yelled at by the woman's son.

## Biden sending millions to Palestinians but doesn't care about East Palestine, Ohio, Levin says
 - [https://www.foxnews.com/media/biden-sending-millions-palestinians-doesnt-care-east-palestine-ohio-levin](https://www.foxnews.com/media/biden-sending-millions-palestinians-doesnt-care-east-palestine-ohio-levin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 10:00:21+00:00

Former Justice Department Chief of Staff Mark Levin, host of 'Life, Liberty & Levin' sounds off on 'Hannity' on Biden's reticence to visit the eastern Ohio disaster area.

## Tennessee cops seek suspect who slaughtered 'official' state animals, dumped bodies under bridge
 - [https://www.foxnews.com/us/tennessee-cops-hunt-suspect-who-slaughtered-official-state-animals-dumped-bodies-under-bridge](https://www.foxnews.com/us/tennessee-cops-hunt-suspect-who-slaughtered-official-state-animals-dumped-bodies-under-bridge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 10:00:01+00:00

The Cocke County Sheriff's Office in Tennessee said 11 dead raccoon bodies and trash were cleaned up under a bridge and are calling on the public for tips on the case.

## Biden admin scientist raised alarm on offshore wind harming whales months ago
 - [https://www.foxnews.com/politics/biden-admin-scientist-raised-alarm-offshore-wind-harming-whales-months-ago](https://www.foxnews.com/politics/biden-admin-scientist-raised-alarm-offshore-wind-harming-whales-months-ago)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 09:59:27+00:00

A Biden administration scientist authored an internal memo warning of the impacts offshore wind development may have on marine life months before the recent spate of whale deaths.

## New Orleans pastor fights to save ‘murder capital’ 6 months after son shot just blocks from church
 - [https://www.foxnews.com/us/new-orleans-pastor-fights-save-murder-capital-6-months-son-shot-blocks-church](https://www.foxnews.com/us/new-orleans-pastor-fights-save-murder-capital-6-months-son-shot-blocks-church)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 09:30:51+00:00

A New Orleans pastor lost his son to gun violence during the city's homicide surge that led the city to be named the nation's murder capital in September.

## Airline passenger says he wanted to slap man who refused to switch seats so he could sit by his wife
 - [https://www.foxnews.com/travel/airline-passenger-wanted-slap-man-refused-switch-seats-could-sit-wife](https://www.foxnews.com/travel/airline-passenger-wanted-slap-man-refused-switch-seats-could-sit-wife)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 09:28:48+00:00

A man asked if he was in the wrong to ask a fellow airline passenger to switch seats with him so he could sit by his wife. The man said he wanted to slap the passenger.

## This is the price China must pay for unleashing COVID on the world
 - [https://www.foxnews.com/opinion/price-china-must-pay-unleashing-covid-world](https://www.foxnews.com/opinion/price-china-must-pay-unleashing-covid-world)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 09:00:46+00:00

Two U.S. agencies now agree that COVID-19 likely emerged from a leak at a Wuhan lab.

## School librarian privately defends pornographic book on 'sex parties' by invoking Holy Bible: 'Slippery slope'
 - [https://www.foxnews.com/media/school-librarian-privately-defends-pornographic-book-sex-parties-invoking-holy-bible-slippery-slope](https://www.foxnews.com/media/school-librarian-privately-defends-pornographic-book-sex-parties-invoking-holy-bible-slippery-slope)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 09:00:14+00:00

A librarian in Anchorage, Alaska, defended the district's pornographic book by invoking the Bible in an email to Polaris K-12 Principal, Carol Bartholomew.

## Fishermen find remains of missing man inside shark in Argentina
 - [https://www.foxnews.com/world/fishermen-find-remains-missing-man-inside-shark-argentina](https://www.foxnews.com/world/fishermen-find-remains-missing-man-inside-shark-argentina)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 08:40:12+00:00

A man missing in Argentina was found inside a nearly 5-foot long shark after fishermen caught the animal and discovered human remains inside.

## America, especially Republicans, more divided over Ukraine than we thought
 - [https://www.foxnews.com/shows/media-buzz/america-republicans-divided-ukraine-than-we-thought](https://www.foxnews.com/shows/media-buzz/america-republicans-divided-ukraine-than-we-thought)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 08:09:02+00:00

More than half of all Democrats want America to continue providing supplies for Ukraine indefinitely. At the same time, over half of Republicans want a timeframe on U.S. involvement.

## New Jersey man attempted to board plane with handguns, AR-15, Taser, fake US Marshal badge
 - [https://www.foxnews.com/us/new-jersey-man-attempted-board-plane-handguns-ar-15-taser-fake-us-marshal-badge](https://www.foxnews.com/us/new-jersey-man-attempted-board-plane-handguns-ar-15-taser-fake-us-marshal-badge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 08:05:00+00:00

A New Jersey felon tried to board a flight with firearms, ammunition, a Taser and a fake U.S. Marshal's badge. He pleaded guilty to unlawful possession of a weapon in 2016.

## Tampa is birthplace of the Cuban sandwich, American culinary classic flavored by many cultures
 - [https://www.foxnews.com/lifestyle/tampa-birthplace-cuban-sandwich-american-culinary-classic-flavored-many-cultures](https://www.foxnews.com/lifestyle/tampa-birthplace-cuban-sandwich-american-culinary-classic-flavored-many-cultures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 07:00:53+00:00

The Cuban sandwich is an all-American savory creation first made in Tampa, Florida, over a century ago. It features the flavors of many different cultures that built Tampa.

## King Charles denied by Harry Styles, Adele, Elton John for coronation concert: Experts reveal why
 - [https://www.foxnews.com/entertainment/king-charles-denied-harry-styles-adele-elton-john-coronation-concert-experts-reveal-why](https://www.foxnews.com/entertainment/king-charles-denied-harry-styles-adele-elton-john-coronation-concert-experts-reveal-why)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 07:00:21+00:00

King Charles III and his wife Camilla, queen consort, will be crowned at Westminster Abbey on May 6. On May 7, there will be a coronation concert on the grounds of Windsor Castle.

## I'm defending taxpayers at Supreme Court after paying for my education in blood, sweat, and tears
 - [https://www.foxnews.com/opinion/defending-taxpayers-supreme-court-after-paying-education-blood-sweat-tears](https://www.foxnews.com/opinion/defending-taxpayers-supreme-court-after-paying-education-blood-sweat-tears)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 07:00:01+00:00

Missouri's Attorney General will head to the U.S. Supreme Court to oppose Biden's illegal student debt handout plan.

## TUCKER CARLSON: Why did people 'lie about the truth' of COVID's origins?
 - [https://www.foxnews.com/opinion/tucker-carlson-why-people-lie-truth-covids-origins](https://www.foxnews.com/opinion/tucker-carlson-why-people-lie-truth-covids-origins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 06:29:26+00:00

Fox News host Tucker Carlson shares his take on whether the COVID-19 pandemic was caused by a lab leak on 'Tucker Carlson Tonight.'

## Keisha Lance Bottoms announces departure from White House role
 - [https://www.foxnews.com/politics/keisha-lance-bottoms-announces-departure-white-house](https://www.foxnews.com/politics/keisha-lance-bottoms-announces-departure-white-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 06:23:50+00:00

White House Office of Public Engagement director Keisha Lance Bottoms announced Monday she would be stepping down from the position she's held since June.

## Gretchen Whitmer criticized for apparent night out while Michigan hit with severe winter weather, power loss
 - [https://www.foxnews.com/politics/gretchen-whitmer-criticized-apparent-night-out-while-michigan-hit-with-severe-winter-weather-power-loss](https://www.foxnews.com/politics/gretchen-whitmer-criticized-apparent-night-out-while-michigan-hit-with-severe-winter-weather-power-loss)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 06:00:15+00:00

Democratic Michigan Gov. Gretchen Whitmer and a fellow Democratic state lawmaker were criticized as severe winter storm that struck the state last week.

## LAURA INGRAHAM: Worry within the Democratic party is building
 - [https://www.foxnews.com/media/laura-ingraham-worry-within-the-democratic-party-is-building](https://www.foxnews.com/media/laura-ingraham-worry-within-the-democratic-party-is-building)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 05:58:41+00:00

Laura Ingraham discusses how Democrats are facing growing concerns about Biden running in 2024 and questioning if Kamala should be his VP on "The Ingraham Angle."

## GREG GUTFELD: We need to chase this COVID lab leak story down
 - [https://www.foxnews.com/opinion/greg-gutfeld-need-chase-covid-lab-leak-story-down](https://www.foxnews.com/opinion/greg-gutfeld-need-chase-covid-lab-leak-story-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 05:33:15+00:00

Fox News host Greg Gutfeld weighs in on the latest developments surrounding the Wuhan lab leak theory on 'Gutfeld!'

## On this day in history, Feb. 28, 1983, 'MASH' finale draws record TV audience of over 100 million
 - [https://www.foxnews.com/lifestyle/this-day-history-feb-28-1983-mash-finale-draws-record-tv-audience-100-million](https://www.foxnews.com/lifestyle/this-day-history-feb-28-1983-mash-finale-draws-record-tv-audience-100-million)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 05:02:17+00:00

The final episode of "MASH" drew a record TV audience of more than 100 million Americans on this day in history, Feb. 28, 1983. It held the record for 27 years.

## SEAN HANNITY: Don't put your trust in the federal government
 - [https://www.foxnews.com/media/sean-hannity-dont-trust-federal-government](https://www.foxnews.com/media/sean-hannity-dont-trust-federal-government)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 04:23:29+00:00

Sean Hannity weighed in on the origins of COVID-19 after a classified intelligence report from the Energy Department found it most likely came from a Chinese lab on 'Hannity.'

## Alec Baldwin hit with new 'Rust' lawsuit by three crew members who suffered 'blast injuries'
 - [https://www.foxnews.com/entertainment/alec-baldwin-new-rust-lawsuit-three-crew-members-suffered-blast-injuries](https://www.foxnews.com/entertainment/alec-baldwin-new-rust-lawsuit-three-crew-members-suffered-blast-injuries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 04:04:49+00:00

"Rust" production crew members filed a negligence lawsuit against Alec Baldwin citing "multiple" ignored and unscripted "firearms discharges" on the New Mexico set.

## Hornets announce LaMelo Ball suffered fractured right ankle vs. Pistons
 - [https://www.foxnews.com/sports/hornets-announce-lamelo-ball-suffered-fractured-ankle-pistons](https://www.foxnews.com/sports/hornets-announce-lamelo-ball-suffered-fractured-ankle-pistons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 03:27:08+00:00

The Charlotte Hornets announced that star point guard LaMelo Ball has suffered a right ankle fracture during the team's win over the Detroit Pistons on Monday night.

## Pennsylvania district considers bringing 'feelings' into math curriculum as some community members balk
 - [https://www.foxnews.com/media/pennsylvania-district-considers-bringing-feelings-math-curriculum-community-members-balk](https://www.foxnews.com/media/pennsylvania-district-considers-bringing-feelings-math-curriculum-community-members-balk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 03:09:45+00:00

Littlestown Area School District in Pennsylvania proposed an elementary math curriculum that could integrate social-emotional learning into its curriculum.

## Dan Snyder's 'absurd' demands to NFL owners has renewed vote to remove him from Commanders ownership: report
 - [https://www.foxnews.com/sports/dan-snyders-absurd-demands-nfl-owners-renewed-vote-remove-him-commanders-ownership-report](https://www.foxnews.com/sports/dan-snyders-absurd-demands-nfl-owners-renewed-vote-remove-him-commanders-ownership-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:54:34+00:00

Washington Commanders owner Dan Snyder is reportedly asking the NFL and team owners for assurances that he won't face legal liability after selling franchise.

## Defense Department tells military personnel to stop jumping from planes with U.S. flags in tow
 - [https://www.foxnews.com/us/defense-department-tells-military-personnel-stop-jumping-planes-flags-tow](https://www.foxnews.com/us/defense-department-tells-military-personnel-stop-jumping-planes-flags-tow)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:53:13+00:00

The U.S. Department of Defense reminded service members that jumping from planes with U.S. flags in tow and flying flags horizontally are prohibited acts.

## San Diego Border Patrol seizes massive quantity of deadly, powerful drug, arrests three during traffic stop
 - [https://www.foxnews.com/us/san-diego-border-patrol-seizes-massive-quantity-deadly-powerful-drug-arrests-three-traffic-stop](https://www.foxnews.com/us/san-diego-border-patrol-seizes-massive-quantity-deadly-powerful-drug-arrests-three-traffic-stop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:49:04+00:00

Border Patrol agents in the San Diego Sector seized 232 pounds of fentanyl with a street value of about $3 million from a single vehicle, officials announced on Monday.

## Washington DC City Council says bill for allowing noncitizens to vote is now law: report
 - [https://www.foxnews.com/politics/washington-dc-city-council-bill-allowing-noncitizens-vote-law](https://www.foxnews.com/politics/washington-dc-city-council-bill-allowing-noncitizens-vote-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:42:50+00:00

A proposal to let noncitizens vote in local Washington D.C. elections is not law after Congress failed to push to block it

## Madonna pays tribute to brother Anthony Ciccone following his death at 66
 - [https://www.foxnews.com/entertainment/madonna-pays-tribute-brother-anthony-ciccone-death-66](https://www.foxnews.com/entertainment/madonna-pays-tribute-brother-anthony-ciccone-death-66)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:37:08+00:00

Madonna broke her silence on her brother's death in a post dedicated to the "important seeds" he planted in her life, including Buddhism, Taoism and Miles Davis.

## Seattle police officer assaulted during stolen vehicle recovery, incident escalates into barricade situation
 - [https://www.foxnews.com/us/seattle-police-officer-assaulted-recovery-stolen-vehicle-barricade-situation](https://www.foxnews.com/us/seattle-police-officer-assaulted-recovery-stolen-vehicle-barricade-situation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:33:14+00:00

A Seattle police officer was assaulted early Sunday morning by a suspect with multiple outstanding felony warrants while attempting to recover a stolen vehicle.

## JESSE WATTERS: Why was the Wuhan lab leak theory scandalized?
 - [https://www.foxnews.com/opinion/jesse-watters-why-wuhan-lab-leak-theory-scandalized](https://www.foxnews.com/opinion/jesse-watters-why-wuhan-lab-leak-theory-scandalized)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:32:59+00:00

Fox News host Jesse Watters weighs in on the Wuhan lab leak theory on "Jesse Watters Primetime."

## COVID lab leak theory appears vindicated after Energy Department report: 'They censored us, trashed us'
 - [https://www.foxnews.com/media/covid-lab-leak-theory-appears-vindicated-energy-department-report-censored-trashed](https://www.foxnews.com/media/covid-lab-leak-theory-appears-vindicated-energy-department-report-censored-trashed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:14:05+00:00

'The Five' co-hosts react to a classified intelligence report from the Energy Department, which found the most likely cause of COVID-19 was a lab leak.

## Kyle Busch secures first Richard Childress Racing win in Auto Club 400
 - [https://www.foxnews.com/sports/kyle-busch-secures-first-richard-childress-racing-win-auto-club-400](https://www.foxnews.com/sports/kyle-busch-secures-first-richard-childress-racing-win-auto-club-400)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:11:14+00:00

Kyle Busch won for the fifth time in Southern California on Sunday, but it was his first victory for Richard Childress Racing in the Auto Club 400.

## Tom Sizemore’s doctors 'have recommended end-of-life decision' after brain aneurysm: 'No further hope'
 - [https://www.foxnews.com/entertainment/tom-sizemores-doctors-recommended-end-of-life-decision-after-brain-aneurysm](https://www.foxnews.com/entertainment/tom-sizemores-doctors-recommended-end-of-life-decision-after-brain-aneurysm)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:09:33+00:00

Tom Sizemore has remained in a coma after a brain aneurysm that occurred due to a stroke at his home in Los Angeles last week. Doctors told his family there is "no further hope."

## CBP releases, ICE later arrests Brazilian fugitive wanted for murder who illegally entered the US
 - [https://www.foxnews.com/us/cbp-releases-ice-later-arrests-brazilian-fugitive-wanted-murder-illegally-entered-us](https://www.foxnews.com/us/cbp-releases-ice-later-arrests-brazilian-fugitive-wanted-murder-illegally-entered-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 02:02:30+00:00

ICE said its Enforcement and Removal Operations, or ERO, officers arrested a Brazilian fugitive who was wanted for aggravated homicide in his home country.

## Jeremy Renner doing 'whatever it takes' to recover after snowplow accident
 - [https://www.foxnews.com/entertainment/jeremy-renner-doing-whatever-it-takes-recover-snowplow-accident](https://www.foxnews.com/entertainment/jeremy-renner-doing-whatever-it-takes-recover-snowplow-accident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 01:57:32+00:00

"Mayor of Kingstown" star Jeremy Renner is keeping his fans up to date as he continues to recover from the snowplow accident that occurred on News Year's Day. "Whatever it takes," he told his fans.

## Austin Police Department staffing crisis: 77 officers could retire by end of March as vacancies pile up
 - [https://www.foxnews.com/us/austin-police-department-staffing-crisis-77-officers-could-retire-end-march-vacancies-pile](https://www.foxnews.com/us/austin-police-department-staffing-crisis-77-officers-could-retire-end-march-vacancies-pile)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 01:49:44+00:00

Up to 77 Austin Police Department officers could retire by the end of March when the current contract with the city expires, potentially exacerbating an ongoing staffing crisis.

## Military mom in a bind with baby is accused of 'abusing' her power over younger sister
 - [https://www.foxnews.com/lifestyle/military-mom-bind-baby-accused-abusing-power-younger-sister](https://www.foxnews.com/lifestyle/military-mom-bind-baby-accused-abusing-power-younger-sister)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 01:46:16+00:00

A family drama described on Reddit has elicited over 10,000 reactions. A mom of a young child whose fiancé is deployed and who's supporting her younger sister shared a surprising standoff.

## 'Greater Idaho' movement to absorb conservative rural counties from liberal Oregon gains momentum
 - [https://www.foxnews.com/politics/greater-idaho-movement-absorb-counties-oregon-gains-momentum](https://www.foxnews.com/politics/greater-idaho-movement-absorb-counties-oregon-gains-momentum)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 01:39:43+00:00

A campaign to have rural, conservative counties in eastern Oregon join Idaho is gaining steam as leaders from both states express support for relocating the border between them.

## Lakers' LeBron James expected to miss 'extended period of time' with foot injury: report
 - [https://www.foxnews.com/sports/lakers-lebron-james-expected-miss-extended-period-of-time-foot-injury-report](https://www.foxnews.com/sports/lakers-lebron-james-expected-miss-extended-period-of-time-foot-injury-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 01:29:29+00:00

Los Angeles Lakers superstar LeBron James is reportedly expecting to miss an "extended period of time' with a right foot injury he suffered against the Dallas Mavericks on Sunday.

## Houston police refer investigation of ex-Biden staffer Sam Brinton's alleged airport luggage theft to FBI
 - [https://www.foxnews.com/politics/houston-police-refer-investigation-ex-biden-staffer-sam-brinton-alleged-airport-luggage-theft-fbi](https://www.foxnews.com/politics/houston-police-refer-investigation-ex-biden-staffer-sam-brinton-alleged-airport-luggage-theft-fbi)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 01:24:41+00:00

A division of the Houston Police Department has met with the FBI to discuss a woman's claims she saw a former Biden official wearing her clothes that had been in a stolen luggage.

## Father of Connecticut teen wounded in police shooting is shot, killed by Massachusetts police
 - [https://www.foxnews.com/us/father-connecticut-teen-wounded-police-shooting-shot-killed-massachusetts-police](https://www.foxnews.com/us/father-connecticut-teen-wounded-police-shooting-shot-killed-massachusetts-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 01:21:46+00:00

Police in Springfield, Massachusetts, shot and killed William Tisdol, whose now-20-year-old son, Caleb, was shot and injured by Connecticut police in 2017.

## Proposed Maine law regulating outdoor cats met with backlash
 - [https://www.foxnews.com/politics/proposed-maine-law-regulating-outdoor-cats-met-backlash](https://www.foxnews.com/politics/proposed-maine-law-regulating-outdoor-cats-met-backlash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 01:20:29+00:00

A bill that would apply Maine's animal trespass laws to cats was met with swift opposition on Monday, allowing owners to be fined for cats wandering onto others' property.

## Classic South Park clip mocking transgender bathroom policies in schools goes viral
 - [https://www.foxnews.com/media/classic-south-park-clip-mocking-transgender-bathroom-policies-schools-goes-viral](https://www.foxnews.com/media/classic-south-park-clip-mocking-transgender-bathroom-policies-schools-goes-viral)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 01:12:46+00:00

A clip from a classic 2014 episode of Comedy Central's South Park went viral nearly 9 years later for commenting on cynical weaponization of transgender identity politics.

## Nikki Haley tweets COVID 'likely' came from Chinese lab, pledges to cut US aid if elected president
 - [https://www.foxnews.com/politics/nikki-haley-tweets-covid-chinese-lab-cut-us-aid-elected-president](https://www.foxnews.com/politics/nikki-haley-tweets-covid-chinese-lab-cut-us-aid-elected-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:58:40+00:00

Republican presidential candidate Nikki Haley continues campaign of stopping funding to enemies of U.S., adding China should be cut because COVID likely came from a Chinese lab.

## New warning about the 'dire' impact of the 'climate crisis' on nursing homes
 - [https://www.foxnews.com/media/new-warning-dire-impact-climate-crisis-nursing-homes](https://www.foxnews.com/media/new-warning-dire-impact-climate-crisis-nursing-homes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:41:19+00:00

USA Today covered a Senate committee reports on nursing home and assisted-living facility deaths from the Texas snow and ice storms in February 2021.

## JD Vance, Sherrod Brown demand EPA, CDC start health screenings in East Palestine after train derailment
 - [https://www.foxnews.com/politics/jd-vance-sherrod-brown-demand-epa-cdc-start-health-screenings-in-east-palestine-after-train-derailment](https://www.foxnews.com/politics/jd-vance-sherrod-brown-demand-epa-cdc-start-health-screenings-in-east-palestine-after-train-derailment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:37:46+00:00

Ohio's GOP and Democratic senators want CDC and EPA to conduct health screenings of residents to establish a "medical baseline" to track health outcomes due to the train derailment.

## 'Friends' star Courteney Cox didn't think Hollywood success was 'possibility' growing up in Alabama
 - [https://www.foxnews.com/entertainment/friends-star-courteney-cox-didnt-think-hollywood-success-possibility-growing-alabama](https://www.foxnews.com/entertainment/friends-star-courteney-cox-didnt-think-hollywood-success-possibility-growing-alabama)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:35:11+00:00

Courteney Cox received a star on the Hollywood Walk of Fame where "Friends" co-stars Jennifer Aniston and Lisa Kudrow shared speeches on her behalf. Coco Arquette and Johnny McDaid also attended.

## Ex-NFL running back Zac Stacy sentenced to jail time, probation after attacks on ex-girlfriend: report
 - [https://www.foxnews.com/sports/ex-nfl-running-back-zac-stacy-sentenced-jail-time-probation-attacks-ex-girlfriend-report](https://www.foxnews.com/sports/ex-nfl-running-back-zac-stacy-sentenced-jail-time-probation-attacks-ex-girlfriend-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:22:39+00:00

Former NFL running back Zac Stacy will be serving six months in jail followed by one year of probation after pleading guilty to charges related to attacks on his ex-girlfriend.

## Brandon Miller’s Twitter account disappears following backlash from controversial pregame ritual
 - [https://www.foxnews.com/sports/brandon-millers-twitter-account-disappears-following-backlash-controversial-pregame-ritual](https://www.foxnews.com/sports/brandon-millers-twitter-account-disappears-following-backlash-controversial-pregame-ritual)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:21:06+00:00

Alabama's Brandon Miller seemingly deleted his Twitter account on Monday after facing backlash for his controversial pregame intro over the weekend.

## US Marshals Service attacked by ransomware targeting sensitive law enforcement information: report
 - [https://www.foxnews.com/politics/us-marshals-service-attacked-ransomware-targeting-sensitive-law-enforcement-information-report](https://www.foxnews.com/politics/us-marshals-service-attacked-ransomware-targeting-sensitive-law-enforcement-information-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:17:24+00:00

The U.S. Marshals Service was attacked by ransomware on Feb. 17, which targeted sensitive information and information about fugitives and investigations.

## Thousands of Texas of Asian descent victims of driver’s license breach by criminal Chinese gang
 - [https://www.foxnews.com/us/texas-asian-descent-victims-drivers-license-breach-criminal-chinese-gang](https://www.foxnews.com/us/texas-asian-descent-victims-drivers-license-breach-criminal-chinese-gang)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:12:33+00:00

The driver's licenses of thousands of Texas were shipped to a New York criminal gang, officials said Monday

## Wisconsin Gov. Evers wants bars open until 4 a.m. at 2024 RNC
 - [https://www.foxnews.com/politics/wisconsin-gov-evers-wants-bars-open-4-2024-rnc](https://www.foxnews.com/politics/wisconsin-gov-evers-wants-bars-open-4-2024-rnc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:10:08+00:00

Democratic Wisconsin Gov. Tony Evers is pushing the state Legislature to allow bars in 14 counties surrounding Milwaukee to be open later during the 2024 Republican National Convention.

## White House still backs gain-of-function research to prevent future pandemics: Kirby
 - [https://www.foxnews.com/politics/white-house-still-backs-gain-function-research-prevent-future-pandemics](https://www.foxnews.com/politics/white-house-still-backs-gain-function-research-prevent-future-pandemics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:02:12+00:00

National Security spokesman John Kirby says President Biden supports gain-of-function research conducted safely and securely and prevents future pandemics.

## Serbia, Kosovo back EU diplomacy plan
 - [https://www.foxnews.com/world/serbia-kosovo-back-eu-diplomacy-plan](https://www.foxnews.com/world/serbia-kosovo-back-eu-diplomacy-plan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-28 00:01:28+00:00

The leaders of Serbia and Kosovo, Aleksandar Vucic and Albin Kurti, implicitly agreed to a European Union-sponsored plan to ease tensions between the two nations.

