# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Niebezpieczne 83,7 procenta. Do produkcji bomby atomowej potrzeba uranu wzbogaconego do 90
 - [https://tvn24.pl/swiat/iran-program-nuklearny-raport-maea-niektore-czasteczki-uranu-wzbogacone-do-837-procenta-6785894?source=rss](https://tvn24.pl/swiat/iran-program-nuklearny-raport-maea-niektore-czasteczki-uranu-wzbogacone-do-837-procenta-6785894?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 21:56:34+00:00

<img alt="Niebezpieczne 83,7 procenta. Do produkcji bomby atomowej potrzeba uranu wzbogaconego do 90" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6u86oj-aparatura-w-iranskiej-fabryce-wzbogacania-uranu-w-natanz-zdjecie-z-kwietnia-2021-roku-6786061/alternates/LANDSCAPE_1280" />
    Iran posiada już 18 razy więcej wzbogaconego uranu niż wynosi jego limit zapisany w umowie atomowej z 2015 roku - wynika z raportu MAEA.

## Mourinho odesłany na trybuny. Koniec niechlubnej serii we Włoszech
 - [https://eurosport.tvn24.pl/mourinho-odes-any-na-trybuny--koniec-najd-u-szej-niechlubnej-serii-we-w-oszech,1138096.html?source=rss](https://eurosport.tvn24.pl/mourinho-odes-any-na-trybuny--koniec-najd-u-szej-niechlubnej-serii-we-w-oszech,1138096.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 20:58:05+00:00

<img alt="Mourinho odesłany na trybuny. Koniec niechlubnej serii we Włoszech" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cc12mq-roma-nie-potrafi-ustabilizowac-formy-6785589/alternates/LANDSCAPE_1280" />
    Niespodzianka to mało powiedziane.

## Asteroida Janusz, dotąd znana jako 565184
 - [https://tvn24.pl/tvnmeteo/nauka/asteroida-janusz-dotad-znana-jako-565184-nazwe-dostala-na-czesc-polskiego-naukowca-jezuity-6785061?source=rss](https://tvn24.pl/tvnmeteo/nauka/asteroida-janusz-dotad-znana-jako-565184-nazwe-dostala-na-czesc-polskiego-naukowca-jezuity-6785061?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 20:46:12+00:00

<img alt="Asteroida Janusz, dotąd znana jako 565184" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8ygcje-asteroidy-6785086/alternates/LANDSCAPE_1280" />
    Nazwano ją na cześć polskiego naukowca jezuity.

## "Potępiamy niszczenie polskiego dziedzictwa"
 - [https://tvn24.pl/polska/bialorus-fresk-cud-nad-wisla-zamalowany-rzecznik-msz-lukasz-jasina-potepiamy-niszczenie-polskiego-dziedzictwa-kulturowego-6784931?source=rss](https://tvn24.pl/polska/bialorus-fresk-cud-nad-wisla-zamalowany-rzecznik-msz-lukasz-jasina-potepiamy-niszczenie-polskiego-dziedzictwa-kulturowego-6784931?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 20:38:09+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fq10ap-zamalowany-fresk-cud-nad-wisla-w-bialoruskim-kosciele-6784937/alternates/LANDSCAPE_1280" />
    Stuletni fresk "Cud nad Wisłą", znajdujący się w jednym z kościołów na Białorusi, został zamalowany.

## Męki Hurkacza w Dubaju
 - [https://eurosport.tvn24.pl/hurkacz-zaskoczony-w-dubaju--postawi--mu-si--gracz-z-drugiej-setki-rankingu,1138101.html?source=rss](https://eurosport.tvn24.pl/hurkacz-zaskoczony-w-dubaju--postawi--mu-si--gracz-z-drugiej-setki-rankingu,1138101.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 20:35:41+00:00

<img alt="Męki Hurkacza w Dubaju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-59wti0-hubert-hurkacz-6785250/alternates/LANDSCAPE_1280" />
    W meczu 1. rundy turnieju ATP 500.

## Hołownia o współpracy z PSL-em: w środę ogłosimy listę wspólnych spraw
 - [https://tvn24.pl/polska/polska-2050-psl-szymon-holownia-w-srode-1-marca-oglosimy-liste-wspolnych-spraw-6784945?source=rss](https://tvn24.pl/polska/polska-2050-psl-szymon-holownia-w-srode-1-marca-oglosimy-liste-wspolnych-spraw-6784945?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 20:07:16+00:00

<img alt="Hołownia o współpracy z PSL-em: w środę ogłosimy listę wspólnych spraw" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w6gyyf-kropka-nad-i-6784984/alternates/LANDSCAPE_1280" />
    Lider Polski 2050 był gościem "Kropki nad i".

## Hołownia: Zrobiliśmy badania. Jest 20 procent wyborców PiS-u, którzy mogą zmienić zdanie
 - [https://tvn24.pl/polska/polska-2050-psl-pis-szymon-holownia-zrobilismy-badania-20-procent-wyborcow-pis-moze-zmienic-zdanie-6784945?source=rss](https://tvn24.pl/polska/polska-2050-psl-pis-szymon-holownia-zrobilismy-badania-20-procent-wyborcow-pis-moze-zmienic-zdanie-6784945?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 20:07:16+00:00

<img alt="Hołownia: Zrobiliśmy badania. Jest 20 procent wyborców PiS-u, którzy mogą zmienić zdanie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a45rhy-28-2000-kropka-cl-0039-6784980/alternates/LANDSCAPE_1280" />
    Lider Polski 2050 był gościem "Kropki nad i".

## Wraca sprawa ułaskawienia Kamińskiego i Wąsika. Sąd Najwyższy rozpoczął postępowanie kasacyjne z urzędu
 - [https://tvn24.pl/polska/mariusz-kaminski-i-maciej-wasik-ulaskawieni-sad-najwyzszy-z-urzedu-wszczyna-postepowanie-kasacyjne-blokowal-je-trybunal-konstytucyjny-6784948?source=rss](https://tvn24.pl/polska/mariusz-kaminski-i-maciej-wasik-ulaskawieni-sad-najwyzszy-z-urzedu-wszczyna-postepowanie-kasacyjne-blokowal-je-trybunal-konstytucyjny-6784948?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 20:00:38+00:00

<img alt="Wraca sprawa ułaskawienia Kamińskiego i Wąsika. Sąd Najwyższy rozpoczął postępowanie kasacyjne z urzędu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s54mok-mariusz-kaminski-i-maciej-wasik-6784951/alternates/LANDSCAPE_1280" />
    Nie czekając na decyzję Trybunału Konstytucyjnego - podała "Gazeta Wyborcza".

## Nowa umowa, nowe możliwości. "Niewiarygodnie wyjątkowa pozycja" Irlandii Północnej
 - [https://tvn24.pl/biznes/ze-swiata/wielka-brytania-porozumieniu-z-unia-europejska-premier-sunak-o-wyjatkowej-pozycji-irlandii-polnocnej-6785012?source=rss](https://tvn24.pl/biznes/ze-swiata/wielka-brytania-porozumieniu-z-unia-europejska-premier-sunak-o-wyjatkowej-pozycji-irlandii-polnocnej-6785012?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 19:51:47+00:00

<img alt="Nowa umowa, nowe możliwości. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-i4nlf7-rishi-sunak-6785017/alternates/LANDSCAPE_1280" />
    "Nikt inny tego nie ma".

## Opozycja razem do Senatu. "Mały zgrzyt był, ale jedziemy do przodu"
 - [https://tvn24.pl/polska/pakt-senacki-2023-opozycja-startuje-wspolnie-do-senatu-marcin-kierwinski-i-piotr-zgorzelski-komentuja-6784971?source=rss](https://tvn24.pl/polska/pakt-senacki-2023-opozycja-startuje-wspolnie-do-senatu-marcin-kierwinski-i-piotr-zgorzelski-komentuja-6784971?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 19:31:24+00:00

<img alt="Opozycja razem do Senatu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qaosla-28-1925-fpf-cl-0031-6784959/alternates/LANDSCAPE_1280" />
    Dyskusja w "Faktach po Faktach".

## Marcin Oleksy: uświadomiłem sobie, że mogę być przykładem
 - [https://eurosport.tvn24.pl/marcin-oleksy--u-wiadomi-em-sobie---e-mog--by--przyk-adem,1138077.html?source=rss](https://eurosport.tvn24.pl/marcin-oleksy--u-wiadomi-em-sobie---e-mog--by--przyk-adem,1138077.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 19:15:51+00:00

<img alt="Marcin Oleksy: uświadomiłem sobie, że mogę być przykładem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fun1y7-marcin-oleksy-w-faktach-po-faktach-6784993/alternates/LANDSCAPE_1280" />
    Strzelec najpiękniejszego gola w plebiscycie FIFA The Best w "Faktach po Faktach".

## Dwie Polki z awansem. Althaus nie do pokonania
 - [https://eurosport.tvn24.pl/dwie-polki-z-awansem--althaus-nie-do-pokonania,1138073.html?source=rss](https://eurosport.tvn24.pl/dwie-polki-z-awansem--althaus-nie-do-pokonania,1138073.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 19:03:00+00:00

<img alt="Dwie Polki z awansem. Althaus nie do pokonania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nqstsl-konderla-awansowala-bardzo-pewnie-6784972/alternates/LANDSCAPE_1280" />
    W kwalifikacjach do środowego konkursu na dużej skoczni.

## "Mamy sytuację bardzo krępującą dla prezesa Obajtka"
 - [https://tvn24.pl/biznes/z-kraju/rosja-wstrzymala-dostawy-ropy-naftowej-do-polski-piotr-wozniak-i-katarzyna-bilewska-o-polityce-orlenu-6784930?source=rss](https://tvn24.pl/biznes/z-kraju/rosja-wstrzymala-dostawy-ropy-naftowej-do-polski-piotr-wozniak-i-katarzyna-bilewska-o-polityce-orlenu-6784930?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 19:02:13+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-kq6od3-iwona-waksmundzka-olejniczak-i-daniel-obajtek-6784453/alternates/LANDSCAPE_1280" />
    Rosja wstrzymała dostawy ropy do Polski.

## "Wiedza, którą uzyskaliśmy, nie poszerzyła naszego horyzontu"
 - [https://tvn24.pl/polska/wybuch-granatnika-ktory-otrzymal-na-ukrainie-general-jaroslaw-szymczyk-posiedzenie-sejmowej-komisji-administracji-i-spraw-wewnetrznych-6784892?source=rss](https://tvn24.pl/polska/wybuch-granatnika-ktory-otrzymal-na-ukrainie-general-jaroslaw-szymczyk-posiedzenie-sejmowej-komisji-administracji-i-spraw-wewnetrznych-6784892?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 18:57:02+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wu6cqy-jaroslaw-szymczyk-6509924/alternates/LANDSCAPE_1280" />
    Sejmowa komisja zebrała się w sprawie wybuchu granatnika.

## Orlen Wisła zagra o awans?
 - [https://eurosport.tvn24.pl/fc-porto---orlen-wis-a-p-ock--transmisja-w-tv-i-online-w-internecie--gdzie-ogl-da--mecz-,1138061.html?source=rss](https://eurosport.tvn24.pl/fc-porto---orlen-wis-a-p-ock--transmisja-w-tv-i-online-w-internecie--gdzie-ogl-da--mecz-,1138061.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 18:28:04+00:00

<img alt="Orlen Wisła zagra o awans?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3dz2h6-plocczanie-licza-ze-z-porto-zagraja-o-awans-6784938/alternates/LANDSCAPE_1280" />
    Najpierw musi liczyć na Duńczyków.

## Nauka na węgierskich błędach. "Nie dosypywać pieniędzy zbyt szeroko"
 - [https://tvn24.pl/biznes/ze-swiata/wegry-gospodarka-mateusz-urban-analizuje-na-antenie-tvn24-bis-6784852?source=rss](https://tvn24.pl/biznes/ze-swiata/wegry-gospodarka-mateusz-urban-analizuje-na-antenie-tvn24-bis-6784852?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 18:08:01+00:00

<img alt="Nauka na węgierskich błędach. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-g9hgop-viktor-orban-6720841/alternates/LANDSCAPE_1280" />
    Ekonomista Oxford Economics Mateusz Urban gościem TVN24 BiS.

## Doskonałe wieści dla trenera Skorży
 - [https://eurosport.tvn24.pl/doskona-e-wie-ci-dla-trenera-skor-y--jego-zesp---zagra-w-presti-owym-turnieju,1137928.html?source=rss](https://eurosport.tvn24.pl/doskona-e-wie-ci-dla-trenera-skor-y--jego-zesp---zagra-w-presti-owym-turnieju,1137928.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 18:07:31+00:00

<img alt="Doskonałe wieści dla trenera Skorży" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ri65ej-maciej-skorza-pracuje-w-japonii-6784923/alternates/LANDSCAPE_1280" />
    Jego zespół zagra w prestiżowym turnieju.

## Sielskie chatki, kamienice w centrum miasta. Sprawdziliśmy, na co poszły nasze pieniądze
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2376,S00E2376,1006899?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2376,S00E2376,1006899?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 17:56:33+00:00

<img alt="Sielskie chatki, kamienice w centrum miasta. Sprawdziliśmy, na co poszły nasze pieniądze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fi9yxp-czarno-na-bialym-posiadlosci-organizacji-6784900/alternates/LANDSCAPE_1280" />
    Z wyliczeń Łukasza Karusty z "Czarno na białym" wynika, że na nieruchomości dla wybranych przez władzę organizacji poszło już co najmniej 100 milionów złotych.

## Kilkaset uczennic "podtrutych chemikaliami". Dziwne reakcje ministrów, rodzice wściekli
 - [https://tvn24.pl/swiat/iran-kilkaset-uczennic-ofiarami-atakow-lagodna-trucizna-iran-prowadzi-sledztwo-6784555?source=rss](https://tvn24.pl/swiat/iran-kilkaset-uczennic-ofiarami-atakow-lagodna-trucizna-iran-prowadzi-sledztwo-6784555?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 17:30:11+00:00

<img alt="Kilkaset uczennic " src="https://tvn24.pl/najnowsze/cdn-zdjecie-w4z8jc-protesty-w-iranie-6784792/alternates/LANDSCAPE_1280" />
    Do incydentów doszło w 30 szkołach w Iranie - podają media.

## Żona była w kościele, mąż czekał w aucie i popijał alkohol
 - [https://tvn24.pl/tvnwarszawa/najnowsze/lipsk-zona-w-kosciele-maz-pijal-alkohol-zostal-zatrzymany-6784590?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/lipsk-zona-w-kosciele-maz-pijal-alkohol-zostal-zatrzymany-6784590?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 17:21:35+00:00

<img alt="Żona była w kościele, mąż czekał w aucie i popijał alkohol" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qp5upp-pil-w-samochodzie-przed-kosciolem-6784640/alternates/LANDSCAPE_1280" />
    Policja zatrzymała 85-latka.

## Courtney Cox potwierdza, że książę Harry był u niej w domu
 - [https://tvn24.pl/kultura-i-styl/courtney-cox-potwierdza-ze-ksiaze-harry-byl-u-niej-w-domu-6784760?source=rss](https://tvn24.pl/kultura-i-styl/courtney-cox-potwierdza-ze-ksiaze-harry-byl-u-niej-w-domu-6784760?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 17:11:51+00:00

<img alt="Courtney Cox potwierdza, że książę Harry był u niej w domu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sxcexg-courteney-cox-6784797/alternates/LANDSCAPE_1280" />
    Książę opisał niecodzienną sytuację w swojej autobiografii.

## Pilot zatoczył koło, by pokazać pasażerom zorzę. "Niesamowite" zwieńczenie zaręczynowej podróży
 - [https://tvn24.pl/tvnmeteo/swiat/pilot-zatoczyl-kolo-by-pasazerowie-obejrzeli-zorze-polarna-niesamowite-zwienczenie-zareczynowej-podrozy-6784728?source=rss](https://tvn24.pl/tvnmeteo/swiat/pilot-zatoczyl-kolo-by-pasazerowie-obejrzeli-zorze-polarna-niesamowite-zwienczenie-zareczynowej-podrozy-6784728?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 17:07:35+00:00

<img alt="Pilot zatoczył koło, by pokazać pasażerom zorzę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5m06dd-pilot-zatoczyl-kolo-by-pokazac-pasazerom-zorze-6784839/alternates/LANDSCAPE_1280" />
    Adam i Jasmine nie "upolowali"  zorzy na Islandii, ale zobaczyli ją z samolotu w drodze powrotnej.

## Wypadek śmigłowca podczas ćwiczeń. Pilot stracił panowanie nad maszyną
 - [https://tvn24.pl/wroclaw/lubin-smiglowiec-spadl-na-ziemie-podczas-cwiczen-pilot-z-obrazeniami-6784750?source=rss](https://tvn24.pl/wroclaw/lubin-smiglowiec-spadl-na-ziemie-podczas-cwiczen-pilot-z-obrazeniami-6784750?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 16:58:54+00:00

<img alt="Wypadek śmigłowca podczas ćwiczeń. Pilot stracił panowanie nad maszyną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dy6vj8-do-zdarzenia-doszlo-na-terenie-aeroklubu-w-lubinie-6784830/alternates/LANDSCAPE_1280" />
    Dokładne okoliczności wyjaśnia Komisja ds. Badania Wypadków Lotniczych.

## Popularna chińska aplikacja na cenzurowanym
 - [https://tvn24.pl/biznes/ze-swiata/tiktok-popularna-chinska-aplikacja-ma-byc-zakazana-dla-pracownikow-parlamentu-europejskiego-6784757?source=rss](https://tvn24.pl/biznes/ze-swiata/tiktok-popularna-chinska-aplikacja-ma-byc-zakazana-dla-pracownikow-parlamentu-europejskiego-6784757?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 16:55:12+00:00

<img alt="Popularna chińska aplikacja na cenzurowanym" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-a3ctb1-parlament-europejski-w-strasburgu-6758988/alternates/LANDSCAPE_1280" />
    PE nie chce jej na telefonach pracowników.

## Karambol w Alejach Jerozolimskich. Ogromny korek na wyjeździe z Warszawy
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-karambol-w-alejach-jerozolimskich-utrudnienia-6784801?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-karambol-w-alejach-jerozolimskich-utrudnienia-6784801?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 16:51:06+00:00

<img alt="Karambol w Alejach Jerozolimskich. Ogromny korek na wyjeździe z Warszawy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-lrygxv-zderzenie-w-alejach-jerozolimskich-6784825/alternates/LANDSCAPE_1280" />
    Zderzyło się pięć aut.

## Policja ostrzega przed mężczyzną w przebraniu Ciasteczkowego Potwora
 - [https://tvn24.pl/swiat/usa-policja-ostrzega-przed-mezczyzna-w-przebraniu-ciasteczkowego-potwora-6784593?source=rss](https://tvn24.pl/swiat/usa-policja-ostrzega-przed-mezczyzna-w-przebraniu-ciasteczkowego-potwora-6784593?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 16:43:59+00:00

<img alt="Policja ostrzega przed mężczyzną w przebraniu Ciasteczkowego Potwora" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jbo88w-santa-cruz-wharf-6784634/alternates/LANDSCAPE_1280" />
    Nazywa się tak, jak popularny aktor.

## Kolosalna zmiana w Kijowie
 - [https://tvn24.pl/swiat/kijow-ukraina-wladze-obecnie-w-kijowie-jest-okolo-35-miliona-ludzi-rok-temu-bylo-okolo-800-tysiecy-6784668?source=rss](https://tvn24.pl/swiat/kijow-ukraina-wladze-obecnie-w-kijowie-jest-okolo-35-miliona-ludzi-rok-temu-bylo-okolo-800-tysiecy-6784668?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 16:24:25+00:00

<img alt="Kolosalna zmiana w Kijowie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-295gxd-kijow-ukraina-luty-2023-6784745/alternates/LANDSCAPE_1280" />
    Ile osób mieszka w ukraińskiej stolicy?

## Koniec mistrzostw dla japońskiej gwiazdy. "Muszę wykonać krok wstecz"
 - [https://eurosport.tvn24.pl/koniec-mistrzostw-dla-japo-skiej-gwiazdy---musz--wykona--krok-wstecz-,1138027.html?source=rss](https://eurosport.tvn24.pl/koniec-mistrzostw-dla-japo-skiej-gwiazdy---musz--wykona--krok-wstecz-,1138027.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 16:21:16+00:00

<img alt="Koniec mistrzostw dla japońskiej gwiazdy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yde438-takanashi-konczy-udzial-w-ms-w-planicy-6784782/alternates/LANDSCAPE_1280" />
    Wyjedzie z Planicy bez medalu.

## Im dalej w marzec, tym chłodniej. Wróci śnieg
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-poczatek-marca-zmiana-pogody-w-polsce-w-weekend-wroci-mroz-i-snieg-6784619?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-poczatek-marca-zmiana-pogody-w-polsce-w-weekend-wroci-mroz-i-snieg-6784619?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 16:10:16+00:00

<img alt="Im dalej w marzec, tym chłodniej. Wróci śnieg" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9vayuu-vent-6784722/alternates/LANDSCAPE_1280" />
    Prognoza pogody na pierwsze dni miesiąca.

## "Nie przyszedłem do amp futbolu dla zabawy, a zrobić wielkie rzeczy"
 - [https://eurosport.tvn24.pl/-nie-przyszed-em-do-amp-futbolu-dla-zabawy--a-zrobi--wielkie-rzeczy-,1138033.html?source=rss](https://eurosport.tvn24.pl/-nie-przyszed-em-do-amp-futbolu-dla-zabawy--a-zrobi--wielkie-rzeczy-,1138033.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 15:58:59+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ejwfgj-oleksy-podczas-konferencji-prasowej-w-siedzibie-pzu-w-warszawie-6784747/alternates/LANDSCAPE_1280" />
    Konferencja prasowa z udziałem Marcina Oleksego.

## Jest wniosek o areszt dla byłego ministra skarbu
 - [https://tvn24.pl/polska/wlodzimierz-karpinski-jest-wniosek-o-areszt-dla-bylego-ministra-6784520?source=rss](https://tvn24.pl/polska/wlodzimierz-karpinski-jest-wniosek-o-areszt-dla-bylego-ministra-6784520?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 15:51:59+00:00

<img alt="Jest wniosek o areszt dla byłego ministra skarbu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ffxq8i-wlodzimierz-karpinski-6780332/alternates/LANDSCAPE_1280" />
    Informację przekazała Prokuratura Krajowa.

## Trzy miesiące aresztu dla byłego ministra skarbu
 - [https://tvn24.pl/polska/wlodzimierz-karpinski-trzy-miesiace-do-aresztu-dla-bylego-ministra-skarbu-zdecydowal-sad-6784520?source=rss](https://tvn24.pl/polska/wlodzimierz-karpinski-trzy-miesiace-do-aresztu-dla-bylego-ministra-skarbu-zdecydowal-sad-6784520?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 15:51:59+00:00

<img alt="Trzy miesiące aresztu dla byłego ministra skarbu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ffxq8i-wlodzimierz-karpinski-6780332/alternates/LANDSCAPE_1280" />
    Informację przekazano we wtorek późnym wieczorem.

## Agora przejmuje Eurozet. "To było jedno z najdłuższych postępowań w historii"
 - [https://tvn24.pl/biznes/z-kraju/agora-przejmuje-eurozet-prezes-agory-bartosz-hojka-o-najdluzszym-postepowaniu-uokik-u-6784658?source=rss](https://tvn24.pl/biznes/z-kraju/agora-przejmuje-eurozet-prezes-agory-bartosz-hojka-o-najdluzszym-postepowaniu-uokik-u-6784658?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 15:47:42+00:00

<img alt="Agora przejmuje Eurozet. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ki8n17-bartosz-hojka-prezes-agory-6784708/alternates/LANDSCAPE_1280" />
    Prezes Agory Bartosz Hojka w TVN24 BiS.

## Podwyższenie wieku emerytalnego. Tusk: nie chcemy przymusu w tej kwestii
 - [https://tvn24.pl/biznes/dla-seniora/emerytury-donald-tusk-lider-po-o-podwyzszeniu-wieku-emerytalnego-6784672?source=rss](https://tvn24.pl/biznes/dla-seniora/emerytury-donald-tusk-lider-po-o-podwyzszeniu-wieku-emerytalnego-6784672?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 15:39:36+00:00

<img alt="Podwyższenie wieku emerytalnego. Tusk: nie chcemy przymusu w tej kwestii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rdd6os-emeryt-4520873/alternates/LANDSCAPE_1280" />
    Były premier w Łodzi.

## 55-latek zmarł w policyjnym radiowozie. Są wstępne wyniki sekcji zwłok
 - [https://tvn24.pl/katowice/knurow-55-latek-zmarl-w-policyjnym-radiowozie-sa-wstepne-wyniki-sekcji-zwlok-6784446?source=rss](https://tvn24.pl/katowice/knurow-55-latek-zmarl-w-policyjnym-radiowozie-sa-wstepne-wyniki-sekcji-zwlok-6784446?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 15:29:14+00:00

<img alt="55-latek zmarł w policyjnym radiowozie. Są wstępne wyniki sekcji zwłok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2wmgwc-na-miejsce-wezwana-zostala-policja-zdjecie-ilustracyjne-6768024/alternates/LANDSCAPE_1280" />
    55-latek został zatrzymany 20 lutego, policję wezwali jego bliscy.

## Onkolodzy złożyli wypowiedzenia. "Nie ma zagrożenia dla pacjentów"
 - [https://tvn24.pl/wroclaw/onkolodzy-zlozyli-wypowiedzenia-nie-ma-zagrozenia-dla-pacjentow-6784600?source=rss](https://tvn24.pl/wroclaw/onkolodzy-zlozyli-wypowiedzenia-nie-ma-zagrozenia-dla-pacjentow-6784600?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 15:01:07+00:00

<img alt="Onkolodzy złożyli wypowiedzenia. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wtootm-uniwersytecki-szpital-kliniczny-wroclaw-6784616/alternates/LANDSCAPE_1280" />
    Pierwszą informację dostaliśmy na Kontakt24.

## "Po wizycie pana prezydenta Bidena wstrzymano generalnie dostawy tej ropy"
 - [https://tvn24.pl/biznes/z-kraju/rosja-polska-rosja-wstrzymala-dostawy-ropy-naftowej-do-polski-prezes-orlenu-daniel-obajtek-o-kontrakcie-z-tatnieftem-6784457?source=rss](https://tvn24.pl/biznes/z-kraju/rosja-polska-rosja-wstrzymala-dostawy-ropy-naftowej-do-polski-prezes-orlenu-daniel-obajtek-o-kontrakcie-z-tatnieftem-6784457?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 14:57:22+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-nl34ri-daniel-obajtek-6784425/alternates/LANDSCAPE_1280" />
    Daniel Obajtek podczas wtorkowej konferencji.

## Brutalny napad na taksówkarza. Mężczyzna zamówił kurs, a potem użył gazu, ugodził nożem kierowcę i uciekł
 - [https://tvn24.pl/pomorze/kowalewo-pomorskie-brutalny-napad-na-taksowkarza-uzyl-gazu-ugodzil-go-nozem-a-pozniej-uciekl-6784301?source=rss](https://tvn24.pl/pomorze/kowalewo-pomorskie-brutalny-napad-na-taksowkarza-uzyl-gazu-ugodzil-go-nozem-a-pozniej-uciekl-6784301?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 14:55:31+00:00

<img alt="Brutalny napad na taksówkarza. Mężczyzna zamówił kurs, a potem użył gazu, ugodził nożem kierowcę i uciekł" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d9gz82-policjanci-zatrzymali-sprawce-napadu-na-taksowkarza-6784288/alternates/LANDSCAPE_1280" />
    Teraz grozi mu nawet dożywocie.

## Legia Warszawa w półfinale Pucharu Polski
 - [https://eurosport.tvn24.pl/legia-warszawa-w-p--finale-pucharu-polski,1138032.html?source=rss](https://eurosport.tvn24.pl/legia-warszawa-w-p--finale-pucharu-polski,1138032.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 14:55:07+00:00

<img alt="Legia Warszawa w półfinale Pucharu Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q6eyfh-legia-pewnie-pokonala-lechie-6784636/alternates/LANDSCAPE_1280" />
    Legia Warszawa nie miała problemów z awansem do półfinału rozgrywek o piłkarski Puchar Polski. Ekipa ze stolicy we wtorkowe wczesne popołudnie w Zielonej Górze pokonała bojaźliwie prezentującą się przez całe spotkanie Lechię 3:0. Zawodnikom obu zespołów przeszkadzała nierówna murawa.

## Zagadka "kobiety z lodówki" wyjaśniona
 - [https://tvn24.pl/swiat/usa-zagadka-kobiety-z-lodowki-badanie-dna-pomoglo-ustalic-tozsamosc-kobiety-6784357?source=rss](https://tvn24.pl/swiat/usa-zagadka-kobiety-z-lodowki-badanie-dna-pomoglo-ustalic-tozsamosc-kobiety-6784357?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 14:52:38+00:00

<img alt="Zagadka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pjvg5x-tajemnica-kobiety-z-lodowki-wyjasniona-6784505/alternates/LANDSCAPE_1280" />
    Dzięki badaniu DNA ustalono tożsamość zamordowanej kobiety.

## "Nadeszła era BWP Borsuk". Umowa zatwierdzona
 - [https://tvn24.pl/polska/bwp-borsuk-szef-mon-mariusz-blaszczak-zatwierdzil-umowe-ramowa-na-zakup-wozow-dla-wojska-polskiego-6784491?source=rss](https://tvn24.pl/polska/bwp-borsuk-szef-mon-mariusz-blaszczak-zatwierdzil-umowe-ramowa-na-zakup-wozow-dla-wojska-polskiego-6784491?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 14:40:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e77csq-mariusz-blaszczak-w-hucie-stalowa-wola-6784499/alternates/LANDSCAPE_1280" />
    Pojazdy produkowane będą przez Hutę Stalowa Wola.

## "Od pierwszej klasy szkoły podstawowej do końca studiów widzimy szlak bojowy ministra Czarnka"
 - [https://tvn24.pl/polska/donald-tusk-w-lodzi-szef-po-o-edukacji-i-psychiatrii-6784547?source=rss](https://tvn24.pl/polska/donald-tusk-w-lodzi-szef-po-o-edukacji-i-psychiatrii-6784547?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 14:37:20+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g6il85-donald-tusk-na-spotkaniu-otwartym-z-mlodzieza-w-mediatece-memo-w-lodzi-6784372/alternates/LANDSCAPE_1280" />
    Donald Tusk na spotkaniu z młodzieżą w Łodzi.

## Justin Bieber nie zagra w Krakowie
 - [https://tvn24.pl/kultura-i-styl/justin-bieber-odwoluje-koncerty-nie-zagra-w-tauron-arenie-w-krakowie-6784549?source=rss](https://tvn24.pl/kultura-i-styl/justin-bieber-odwoluje-koncerty-nie-zagra-w-tauron-arenie-w-krakowie-6784549?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 14:30:49+00:00

<img alt="Justin Bieber nie zagra w Krakowie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-48m0us-justin-bieber-6100770/alternates/LANDSCAPE_1280" />
    W Tauron Arenie Kanadyjczyk miał wystąpić 25 marca.

## "Perła w koronie cyfryzacji". Wcześniej była "gadżetem", teraz może zastąpić tradycyjny dokument
 - [https://tvn24.pl/biznes/tech/dowod-z-aplikacji-jak-tradycyjny-beda-dwa-wyjatki-6784384?source=rss](https://tvn24.pl/biznes/tech/dowod-z-aplikacji-jak-tradycyjny-beda-dwa-wyjatki-6784384?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 14:29:44+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie6c09632303007f5b6372b5297c02a188-wystartowala-aplikacja-mobywatel-4467560/alternates/LANDSCAPE_1280" />
    Rząd na wtorkowym posiedzeniu przyjął ustawę o aplikacji mObywatel.

## "Nie wyprodukowano ani jednej maseczki". NIK o "porażce" rządowego programu
 - [https://tvn24.pl/biznes/z-kraju/program-polskie-szwalnie-nik-opublikowal-wnioski-z-kontroli-kontrolerzy-o-porazce-rzadowego-programu-6783843?source=rss](https://tvn24.pl/biznes/z-kraju/program-polskie-szwalnie-nik-opublikowal-wnioski-z-kontroli-kontrolerzy-o-porazce-rzadowego-programu-6783843?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 13:54:22+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-budyl8-najwyzsza-izba-kontroli-5587040/alternates/LANDSCAPE_1280" />
    Wyniki kontroli.

## Kaddy Reeves podbija Instagrama. Choć modelkę stworzyła sztuczna inteligencja
 - [https://tvn24.pl/ciekawostki/sztuczna-inteligencja-wirtualna-modelka-kaddy-reeves-podbija-instagram-6784097?source=rss](https://tvn24.pl/ciekawostki/sztuczna-inteligencja-wirtualna-modelka-kaddy-reeves-podbija-instagram-6784097?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 13:52:42+00:00

<img alt="Kaddy Reeves podbija Instagrama. Choć modelkę stworzyła sztuczna inteligencja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j4xuo0-kaddy-reeves-wygenerowana-przez-sztuczna-inteligencje-modelka-6783504/alternates/LANDSCAPE_1280" />
    W półtora miesiąca jej profil polubiło kilkadziesiąt tysięcy osób.

## Rosjanie usłyszeli ostrzeżenia przed atakiem rakietowym. Ministerstwo wyjaśnia
 - [https://tvn24.pl/swiat/rosja-alarm-przeciwlotniczy-wradiu-i-telewizji-wladze-towina-hakerow-6784308?source=rss](https://tvn24.pl/swiat/rosja-alarm-przeciwlotniczy-wradiu-i-telewizji-wladze-towina-hakerow-6784308?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 13:49:03+00:00

<img alt="Rosjanie usłyszeli ostrzeżenia przed atakiem rakietowym. Ministerstwo wyjaśnia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-22r3tl-petersburg-6782060/alternates/LANDSCAPE_1280" />
    Twierdzi, że to sprawka hakerów.

## Jest pakt senacki. "Przed nami wybory, które będą najważniejsze od 1989 roku"
 - [https://tvn24.pl/polska/pakt-senacki-opozycja-startuje-wspolnie-do-senatu-konferencja-prasowa-6784385?source=rss](https://tvn24.pl/polska/pakt-senacki-opozycja-startuje-wspolnie-do-senatu-konferencja-prasowa-6784385?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 13:45:26+00:00

<img alt="Jest pakt senacki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fdqd87-pakt-senacki-2023-6784460/alternates/LANDSCAPE_1280" />
    Opozycja wspólnie w wyborach do Senatu.

## Problemy radnych z odmianą nazwiska Romualda Traugutta. Pomógł słownik języka polskiego
 - [https://tvn24.pl/lodz/zgierz-problemy-z-odmiana-nazwiska-romualda-traugutta-podczas-sesji-rady-miasta-radnym-pomogl-slownik-jezyka-polskiego-6784183?source=rss](https://tvn24.pl/lodz/zgierz-problemy-z-odmiana-nazwiska-romualda-traugutta-podczas-sesji-rady-miasta-radnym-pomogl-slownik-jezyka-polskiego-6784183?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 13:35:56+00:00

<img alt="Problemy radnych z odmianą nazwiska Romualda Traugutta. Pomógł słownik języka polskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m7r80r-radni-ze-zgierza-blisko-dziesiec-minut-dyskutowali-o-traugucie-6784107/alternates/LANDSCAPE_1280" />
    Mieliśmy pewną zagwozdkę, nie ukrywam - przyznaje wiceprezydent Zgierza.

## "Podejmował szereg działań na szkodę stowarzyszenia". Robert Bąkiewicz wyrzucony
 - [https://tvn24.pl/polska/robert-bakiewicz-wyrzucony-ze-stowarzyszenia-marsz-niepodleglosci-6784331?source=rss](https://tvn24.pl/polska/robert-bakiewicz-wyrzucony-ze-stowarzyszenia-marsz-niepodleglosci-6784331?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 13:29:44+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f9k6vv-robert-bakiewicz-6784346/alternates/LANDSCAPE_1280" />
    Decyzją zarządu.

## Rozmawiały z Banksym, gdy tworzył słynny mural. Nie wiedziały, że to on
 - [https://tvn24.pl/swiat/ukraina-rozmawialy-z-banksym-gdy-tworzyl-mural-w-borodziance-nie-wiedzialy-ze-to-on-6780643?source=rss](https://tvn24.pl/swiat/ukraina-rozmawialy-z-banksym-gdy-tworzyl-mural-w-borodziance-nie-wiedzialy-ze-to-on-6780643?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 13:11:43+00:00

<img alt="Rozmawiały z Banksym, gdy tworzył słynny mural. Nie wiedziały, że to on" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9mjvo3-banksy-mural-borodzianka-ukraina-pap2023022702r-6780667/alternates/LANDSCAPE_1280" />
    Banksy, mimo sławy, zachowuje anonimowość.

## Oleksy wrócił do Polski. "Usiądę teraz i będę się zastanawiał, co zrobić dalej"
 - [https://eurosport.tvn24.pl/marcin-oleksy-wr-ci--do-polski---usi-d--teraz-i-b-d--si--zastanawia---co-zrobi--dalej-,1138011.html?source=rss](https://eurosport.tvn24.pl/marcin-oleksy-wr-ci--do-polski---usi-d--teraz-i-b-d--si--zastanawia---co-zrobi--dalej-,1138011.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 13:02:44+00:00

<img alt="Oleksy wrócił do Polski. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sex22l-marcin-oleksy-wrocil-do-polski-6784323/alternates/LANDSCAPE_1280" />
    Ampfutbolista reprezentacji Polski i autor Bramki Roku wrócił do Polski z gali FIFA The Best w Paryżu.

## Wisła przekroczyła stan ostrzegawczy. Pogotowie przeciwpowodziowe w jednym z miast
 - [https://tvn24.pl/tvnmeteo/polska/pomorskie-pogotowie-przeciwpowodziowe-w-tczewie-wisla-przekroczyla-stan-ostrzegawczy-alerty-imgw-6784155?source=rss](https://tvn24.pl/tvnmeteo/polska/pomorskie-pogotowie-przeciwpowodziowe-w-tczewie-wisla-przekroczyla-stan-ostrzegawczy-alerty-imgw-6784155?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 12:34:41+00:00

<img alt="Wisła przekroczyła stan ostrzegawczy. Pogotowie przeciwpowodziowe w jednym z miast" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6bqnrq-wysoki-poziom-wisly-w-tczewie-6784829/alternates/LANDSCAPE_1280" />
    IMGW wydał alert drugiego stopnia.

## Chcą pomóc rówieśnikom w kryzysie psychicznym, zorganizowali koncert
 - [https://tvn24.pl/tvnwarszawa/kultura/warszawa-centrum-praskie-koneser-chca-pomoc-rowiesnikom-w-kryzysie-psychicznym-zorganizowali-koncert-charytatywny-6782069?source=rss](https://tvn24.pl/tvnwarszawa/kultura/warszawa-centrum-praskie-koneser-chca-pomoc-rowiesnikom-w-kryzysie-psychicznym-zorganizowali-koncert-charytatywny-6782069?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 12:28:35+00:00

<img alt="Chcą pomóc rówieśnikom w kryzysie psychicznym, zorganizowali koncert " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-kvmfeb-centrum-praskie-koneser-2587574/alternates/LANDSCAPE_1280" />
    W Centrum Praskim Koneser.

## Zatrzymano arystokratkę i jej skazanego za gwałt partnera. Trwają poszukiwania ich dziecka
 - [https://tvn24.pl/swiat/wielka-brytania-zatrzymano-arystokratke-constance-marten-i-jej-partnera-trwaja-poszukiwania-dziecka-6783803?source=rss](https://tvn24.pl/swiat/wielka-brytania-zatrzymano-arystokratke-constance-marten-i-jej-partnera-trwaja-poszukiwania-dziecka-6783803?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 12:27:23+00:00

<img alt="Zatrzymano arystokratkę i jej skazanego za gwałt partnera. Trwają poszukiwania ich dziecka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i9chvw-mark-gordon-i-constance-marten-6730890/alternates/LANDSCAPE_1280" />
    Policja "skupia wszystkie wysiłki" na odnalezieniu noworodka.

## Największy program płatnych staży w Polsce. Rusza Program Kariera
 - [https://tvn24.pl/biznes/dla-pracownika/program-kariera-polskiej-rady-biznesu-rusza-kolejna-edycja-staze-w-24-firmach-z-14-miast-jakie-wynagrodzenie-6783734?source=rss](https://tvn24.pl/biznes/dla-pracownika/program-kariera-polskiej-rady-biznesu-rusza-kolejna-edycja-staze-w-24-firmach-z-14-miast-jakie-wynagrodzenie-6783734?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 12:25:44+00:00

<img alt="Największy program płatnych staży w Polsce. Rusza Program Kariera" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-qg0t5c-o-pomoc-z-tak-zwanego-pakietu-finansowego-zawnioskowalo-300-duzych-firm-4687886/alternates/LANDSCAPE_1280" />
    Szczegóły.

## Naukowcy: popularny słodzik może zwiększać ryzyko zawału serca i udaru mózgu
 - [https://tvn24.pl/ciekawostki/nauka-popularny-slodzik-erytrol-moze-zwiekszac-ryzyko-zawalu-serca-i-udaru-mozgu-6782777?source=rss](https://tvn24.pl/ciekawostki/nauka-popularny-slodzik-erytrol-moze-zwiekszac-ryzyko-zawalu-serca-i-udaru-mozgu-6782777?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 12:09:03+00:00

<img alt="Naukowcy: popularny słodzik może zwiększać ryzyko zawału serca i udaru mózgu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s86kal-erytrol-zamiennik-cukru-6782793/alternates/LANDSCAPE_1280" />
    "Ta substancja jest powszechnie dostępna. Jeśli jest szkodliwa, powinniśmy o tym wiedzieć"

## Naukowcy: popularny słodzik może zwiększać ryzyko zawału serca i udaru mózgu
 - [https://tvn24.pl/ciekawostki/erytrol-moze-zwiekszac-ryzyko-zawalu-serca-i-udaru-mozgu-najnowsze-badania-6782777?source=rss](https://tvn24.pl/ciekawostki/erytrol-moze-zwiekszac-ryzyko-zawalu-serca-i-udaru-mozgu-najnowsze-badania-6782777?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 12:09:03+00:00

<img alt="Naukowcy: popularny słodzik może zwiększać ryzyko zawału serca i udaru mózgu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s86kal-erytrol-zamiennik-cukru-6782793/alternates/LANDSCAPE_1280" />
    "Ta substancja jest powszechnie dostępna. Jeśli jest szkodliwa, powinniśmy o tym wiedzieć".

## Najbogatsi ludzie na świecie. Zmiana na szczycie listy
 - [https://tvn24.pl/biznes/ze-swiata/elon-musk-ponownie-najbogatszym-czlowiekiem-na-swiecie-6781942?source=rss](https://tvn24.pl/biznes/ze-swiata/elon-musk-ponownie-najbogatszym-czlowiekiem-na-swiecie-6781942?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 12:08:25+00:00

<img alt="Najbogatsi ludzie na świecie. Zmiana na szczycie listy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-un81az-elon-musk-6227026/alternates/LANDSCAPE_1280" />
    Bloomberg.

## Wysłani do szturmu "niemal z gołymi rękami". "Mieliśmy ze sobą jedynie broń strzelecką i łopaty"
 - [https://tvn24.pl/swiat/rosja-the-insider-zmobilizowani-z-sierpuchowa-nagrali-apel-6781658?source=rss](https://tvn24.pl/swiat/rosja-the-insider-zmobilizowani-z-sierpuchowa-nagrali-apel-6781658?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 12:07:46+00:00

<img alt="Wysłani do szturmu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fbmq40-rosyjscy-zolnierze-6781653/alternates/LANDSCAPE_1280" />
    O zmobilizowanych żołnierzach z Sierpuchowa pod Moskwą pisze rosyjski niezależny portal The Insider.

## Dużo niższa rata, dopłata do najmu. Oto plan Tuska
 - [https://tvn24.pl/biznes/z-kraju/kredyt-zero-procent-dla-kogo-na-jakich-zasadach-szczegoly-programu-6782066?source=rss](https://tvn24.pl/biznes/z-kraju/kredyt-zero-procent-dla-kogo-na-jakich-zasadach-szczegoly-programu-6782066?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 12:02:55+00:00

<img alt="Dużo niższa rata, dopłata do najmu. Oto plan Tuska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-29l6ti-mid-23227420-6784119/alternates/LANDSCAPE_1280" />
    Szczegóły przedstawione przez lidera Platformy Obywatelskiej.

## W tym tygodniu do Ziemi zbliżą się dwie asteroidy. Jedna już tej nocy
 - [https://tvn24.pl/tvnmeteo/nauka/w-tym-tygodniu-do-ziemi-zbliza-sie-dwie-asteroidy-jedna-juz-tej-nocy-nasa-ostrzega-6783141?source=rss](https://tvn24.pl/tvnmeteo/nauka/w-tym-tygodniu-do-ziemi-zbliza-sie-dwie-asteroidy-jedna-juz-tej-nocy-nasa-ostrzega-6783141?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 11:50:21+00:00

<img alt="W tym tygodniu do Ziemi zbliżą się dwie asteroidy. Jedna już tej nocy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-lmzdoh-asteroida-minie-ziemie-5704381/alternates/LANDSCAPE_1280" />
    Inna pokaźnych rozmiarów kosmiczna skała minęła nas również w poniedziałek.

## Adam Hlousek złożył wniosek o bankructwo i zniknął
 - [https://eurosport.tvn24.pl/adam-hlousek-z-o-y--wniosek-o-bankructwo-i-znikn--,1138018.html?source=rss](https://eurosport.tvn24.pl/adam-hlousek-z-o-y--wniosek-o-bankructwo-i-znikn--,1138018.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 11:50:00+00:00

<img alt="Adam Hlousek złożył wniosek o bankructwo i zniknął" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nirrqc-adam-hlousek-ma-ogromne-dlugi-6784134/alternates/LANDSCAPE_1280" />
    Były zawodnik Legii Warszawa i Bruk-Bet Termaliki Nieciecza ma poważne problemy.

## Rząd wzywał do wstrzymania dostaw, rosyjska ropa płynęła do Polski. Dysonans? Mueller: to wina Unii Europejskiej
 - [https://tvn24.pl/polska/rosja-wstrzymala-dostawy-ropy-do-polski-dlaczego-polska-nie-zerwala-kontraktu-rzecznik-rzadu-piotr-mueller-to-wina-unii-europejskiej-6782367?source=rss](https://tvn24.pl/polska/rosja-wstrzymala-dostawy-ropy-do-polski-dlaczego-polska-nie-zerwala-kontraktu-rzecznik-rzadu-piotr-mueller-to-wina-unii-europejskiej-6782367?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 11:47:49+00:00

<img alt="Rząd wzywał do wstrzymania dostaw, rosyjska ropa płynęła do Polski. Dysonans? Mueller: to wina Unii Europejskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ly4lzd-rurociag-przyjazn-6221598/alternates/LANDSCAPE_1280" />
    Rosjanie zakręcili kurek w rurociągu Przyjaźń, którym ropa płynęła do Polski.

## Policjanci na miejscu kolizji nie znaleźli auta. Jechało już na lawecie
 - [https://tvn24.pl/polska/trasa-s7-pijany-kierowca-uszkodzil-slupki-i-ekran-energochlonny-6783176?source=rss](https://tvn24.pl/polska/trasa-s7-pijany-kierowca-uszkodzil-slupki-i-ekran-energochlonny-6783176?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 11:42:19+00:00

<img alt="Policjanci na miejscu kolizji nie znaleźli auta. Jechało już na lawecie" src="https://tvn24.pl/krakow/cdn-zdjecie-fqa0ao-policjanci-zauwazyli-rozbite-bmw-na-lawecie-6783477/alternates/LANDSCAPE_1280" />
    Kierowca i pasażerowie byli pijani.

## Przyczepa kempingowa spłonęła w kilka chwil. 60-latek z ciężkimi poparzeniami
 - [https://tvn24.pl/pomorze/tynwald-przyczepa-kempingowa-stanela-w-ogniu-ciezko-poparzony-mezczyzna-trafil-do-szpitala-6783142?source=rss](https://tvn24.pl/pomorze/tynwald-przyczepa-kempingowa-stanela-w-ogniu-ciezko-poparzony-mezczyzna-trafil-do-szpitala-6783142?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 11:39:53+00:00

<img alt="Przyczepa kempingowa spłonęła w kilka chwil. 60-latek z ciężkimi poparzeniami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u36920-mezczyzna-zostal-ciezko-poparzony-w-pozarze-przyczepy-kempingowej-6783136/alternates/LANDSCAPE_1280" />
    Wewnątrz ratownicy znaleźli rozerwaną butlę z gazem.

## Zdał egzamin na prawo jazdy w wieku 81 lat. "Na początku był trudnym kursantem"
 - [https://tvn24.pl/wroclaw/olawa-brzeg-pan-boleslaw-zdal-egzamin-na-prawo-jazdy-w-wieku-81-lat-6781953?source=rss](https://tvn24.pl/wroclaw/olawa-brzeg-pan-boleslaw-zdal-egzamin-na-prawo-jazdy-w-wieku-81-lat-6781953?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:55:17+00:00

<img alt="Zdał egzamin na prawo jazdy w wieku 81 lat. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mghm2i-pan-boleslaw-zdal-egzamin-na-prawo-jazdy-w-wieku-81-lat-6782030/alternates/LANDSCAPE_1280" />
    "Przesympatyczny nestor naszych kursantów" - napisała szkoła nauki jazdy o panu Bolesławie.

## Strzały w pobliżu szkoły, dwie osoby ciężko ranne
 - [https://tvn24.pl/swiat/niemcy-bramsche-strzaly-w-poblizu-szkoly-dwie-osoby-ciezko-ranne-6781998?source=rss](https://tvn24.pl/swiat/niemcy-bramsche-strzaly-w-poblizu-szkoly-dwie-osoby-ciezko-ranne-6781998?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:50:45+00:00

<img alt="Strzały w pobliżu szkoły, dwie osoby ciężko ranne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y417kz-fqc6l1swcaa6ajq-6782783/alternates/LANDSCAPE_1280" />
    Jedna z rannych osób to napastnik - poinformowała policja.

## "Orlen kontroluje też czeskie rafinerie i tam rosyjska ropa cały czas płynie"
 - [https://tvn24.pl/biznes/z-kraju/ropa-naftowa-z-rosji-ile-kupil-orlen-czy-nadal-jest-sprowadzana-komentuje-robert-tomaszewski-z-polityka-insight-6781854?source=rss](https://tvn24.pl/biznes/z-kraju/ropa-naftowa-z-rosji-ile-kupil-orlen-czy-nadal-jest-sprowadzana-komentuje-robert-tomaszewski-z-polityka-insight-6781854?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:45:09+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ly4lzd-rurociag-przyjazn-6221598/alternates/LANDSCAPE_1280" />
    Gościem TVN24 był Robert Tomaszewski z serwisu Polityka Insight.

## Po medal w niekompletnym stroju. "To nie była zaplanowana akcja"
 - [https://eurosport.tvn24.pl/po-medal-w-niekompletnym-stroju---to-nie-by-a-zaplanowana-akcja-,1138013.html?source=rss](https://eurosport.tvn24.pl/po-medal-w-niekompletnym-stroju---to-nie-by-a-zaplanowana-akcja-,1138013.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:42:00+00:00

<img alt="Po medal w niekompletnym stroju. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qmtvpz-astrid-oeyre-slind-na-trasie-skiathlonu-podczas-ms-w-planicy-6782795/alternates/LANDSCAPE_1280" />
    Astrid Oeyre Slind niespodziewanie wywalczyła brąz w skiathlonie podczas mistrzostw świata w Planicy.

## W pożarze zginęła trójka dzieci i ich ojciec. Prokuratura: śledztwo w kierunku zabójstwa
 - [https://tvn24.pl/bialystok/choroszcz-bialystok-w-pozarze-zginela-trojka-dzieci-i-ich-ojciec-prokuratura-sledztwo-w-kierunku-zabojstwa-6781944?source=rss](https://tvn24.pl/bialystok/choroszcz-bialystok-w-pozarze-zginela-trojka-dzieci-i-ich-ojciec-prokuratura-sledztwo-w-kierunku-zabojstwa-6781944?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:25:53+00:00

<img alt="W pożarze zginęła trójka dzieci i ich ojciec. Prokuratura: śledztwo w kierunku zabójstwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p2ion8-27022023-miejsce-pozaru-domu-jednorodzinnego-w-choroszczy-6782618/alternates/LANDSCAPE_1280" />
    Śledztwo prowadzi Prokuratura Okręgowa w Białymstoku.

## Szalony atak Żyły. Bardzo rzadki przypadek w skokach
 - [https://eurosport.tvn24.pl/szalony-atak--y-y--bardzo-rzadki-przypadek-w-skokach,1138004.html?source=rss](https://eurosport.tvn24.pl/szalony-atak--y-y--bardzo-rzadki-przypadek-w-skokach,1138004.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:17:00+00:00

<img alt="Szalony atak Żyły. Bardzo rzadki przypadek w skokach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8tg0m0-piotr-zyla-obronil-w-planicy-tytul-mistrza-swiata-6782620/alternates/LANDSCAPE_1280" />
    To jedna z najbardziej spektakularnych pogoni, jakie widziała ta dyscyplina.

## "Wymagający, ale nie ryzykowny". Tusk o proponowanym programie mieszkaniowym
 - [https://tvn24.pl/polska/kredyt-zero-procent-tusk-z-punktu-widzenia-budzetu-panstwa-jest-to-program-wymagajacy-ale-nie-jest-ryzykowny-6782037?source=rss](https://tvn24.pl/polska/kredyt-zero-procent-tusk-z-punktu-widzenia-budzetu-panstwa-jest-to-program-wymagajacy-ale-nie-jest-ryzykowny-6782037?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:15:15+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t17af5-donald-tusk-6781910/alternates/LANDSCAPE_1280" />
    Program Kredyt Zero Procent.

## Zablokowali wejście do resortu ropy i energii. Do protestu dołączyła Greta Thunberg
 - [https://tvn24.pl/swiat/norwegia-protest-przeciwko-farmie-wiatrowej-greta-thunberg-i-aktywisci-zablokowali-wejscie-do-ministerstwa-6781514?source=rss](https://tvn24.pl/swiat/norwegia-protest-przeciwko-farmie-wiatrowej-greta-thunberg-i-aktywisci-zablokowali-wejscie-do-ministerstwa-6781514?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:06:56+00:00

<img alt="Zablokowali wejście do resortu ropy i energii. Do protestu dołączyła Greta Thunberg" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hjfmgp-do-protestu-w-oslo-przylaczyla-sie-znana-szwedzka-aktywistka-klimatyczna-gretha-thunberg-6781511/alternates/LANDSCAPE_1280" />
    W ramach protestu przeciwko budowie największej w Norwegii farmy wiatrowej.

## "Jeździmy na wschód, w zasadzie pod linię frontu". Dziennikarze z pomocą dla Ukrainy
 - [https://tvn24.pl/polska/ukraina-rosja-dziennikarze-gazety-wyborczej-z-paczkami-dla-ukrainy-6781747?source=rss](https://tvn24.pl/polska/ukraina-rosja-dziennikarze-gazety-wyborczej-z-paczkami-dla-ukrainy-6781747?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:06:48+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nbyg14-pomoc-gazeta-wyborcza-6782055/alternates/LANDSCAPE_1280" />
    O akcji na antenie TVN24 opowiedziała Agata Kondzińska z "Gazety Wyborczej".

## Ważny termin dla pracowników. "Jutro 8 milionów ludzi zacznie podejmować decyzje"
 - [https://tvn24.pl/biznes/z-kraju/ppk-co-to-jest-do-kiedy-mozna-zrezygnowac-wazny-termin-w-2023-wzor-wniosku-6781783?source=rss](https://tvn24.pl/biznes/z-kraju/ppk-co-to-jest-do-kiedy-mozna-zrezygnowac-wazny-termin-w-2023-wzor-wniosku-6781783?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 10:04:21+00:00

<img alt="Ważny termin dla pracowników. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-bwf1s4-zmiany-w-kodeksie-pracy-4209871/alternates/LANDSCAPE_1280" />
    Będzie to miało wpływ na pensję na rękę.

## "Utrata A-50 Mainstay byłaby znacząca". Brytyjczycy o ataku na rosyjski samolot
 - [https://tvn24.pl/swiat/atak-na-rosyjski-samolot-a-50-na-bialoruskim-lotnisku-brytyjskie-ministerstwo-obrony-komentuje-6781709?source=rss](https://tvn24.pl/swiat/atak-na-rosyjski-samolot-a-50-na-bialoruskim-lotnisku-brytyjskie-ministerstwo-obrony-komentuje-6781709?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 09:48:32+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-18sx76-samolot-6780614/alternates/LANDSCAPE_1280" />
    Komunikat ministerstwa obrony Wielkiej Brytanii.

## Rzeźba stała niecałą dobę, zniszczyli ją wandale. 22-letni Hiszpan zatrzymany na lotnisku
 - [https://tvn24.pl/pomorze/sopot-rzezba-stala-niecala-dobe-zniszczyli-ja-wandale-22-letni-hiszpan-zatrzymany-na-lotnisku-w-gdansku-6781793?source=rss](https://tvn24.pl/pomorze/sopot-rzezba-stala-niecala-dobe-zniszczyli-ja-wandale-22-letni-hiszpan-zatrzymany-na-lotnisku-w-gdansku-6781793?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 09:39:18+00:00

<img alt="Rzeźba stała niecałą dobę, zniszczyli ją wandale. 22-letni Hiszpan zatrzymany na lotnisku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qcuurq-zatrzymany-obywatel-hiszpanii-6781816/alternates/LANDSCAPE_1280" />
    Mężczyźnie grozi nawet 10 lat więzienia.

## Morze wyrzuciło na brzeg setki rozgwiazd
 - [https://tvn24.pl/tvnmeteo/swiat/wyspa-sylt-niemcy-morze-wyrzucilo-na-brzeg-setki-rozgwiazd-6781773?source=rss](https://tvn24.pl/tvnmeteo/swiat/wyspa-sylt-niemcy-morze-wyrzucilo-na-brzeg-setki-rozgwiazd-6781773?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 09:33:29+00:00

<img alt="Morze wyrzuciło na brzeg setki rozgwiazd" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-e6cv41-rozgwiazdy-na-plazach-wyspy-sylt-6781790/alternates/LANDSCAPE_1280" />
    Na plażach w północnych Niemczech.

## Nawet 4 procent PKB na wojsko
 - [https://tvn24.pl/biznes/z-kraju/wydatki-polski-na-obronnosc-w-2023-r-wydamy-prawie-4-proc-pkb-6781594?source=rss](https://tvn24.pl/biznes/z-kraju/wydatki-polski-na-obronnosc-w-2023-r-wydamy-prawie-4-proc-pkb-6781594?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 09:31:32+00:00

<img alt="Nawet 4 procent PKB na wojsko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6w8bui-morag-09122022-przekazanie-czolgow-k2-zolnierzom-wojska-polskiego-6776304/alternates/LANDSCAPE_1280" />
    Polska w czołówce NATO.

## Lotnisko pod Petersburgiem zawraca samoloty. Doniesienia o "niezidentyfikowanym obiekcie"
 - [https://tvn24.pl/swiat/rosja-petersburg-lotnisko-pulkowo-wstrzymalo-przyjmowanie-lotow-samoloty-zawracaly-6781814?source=rss](https://tvn24.pl/swiat/rosja-petersburg-lotnisko-pulkowo-wstrzymalo-przyjmowanie-lotow-samoloty-zawracaly-6781814?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 08:56:00+00:00

<img alt="Lotnisko pod Petersburgiem zawraca samoloty. Doniesienia o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m5zmsk-mapa-pulkowo-6781824/alternates/LANDSCAPE_1280" />
    Poinformowała agencja Reutera i państwowa rosyjska agencja TASS.

## Głowa modelki znaleziona w garnku. Zarzuty dla byłego męża, jego rodziców i brata
 - [https://tvn24.pl/swiat/hongkong-zabojstwo-modelki-abby-choi-zarzuty-dla-bylego-meza-glowa-znaleziona-w-garnku-6781672?source=rss](https://tvn24.pl/swiat/hongkong-zabojstwo-modelki-abby-choi-zarzuty-dla-bylego-meza-glowa-znaleziona-w-garnku-6781672?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 08:51:14+00:00

<img alt="Głowa modelki znaleziona w garnku. Zarzuty dla byłego męża, jego rodziców i brata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oulwvc-abby-choi-nowe-ustalenia-w-sprawie-6781631/alternates/LANDSCAPE_1280" />
    Policja podała prawdopodobną przyczynę śmierci Abby Choi.

## Rosjanie "rzucili najlepiej przygotowane jednostki". Sytuacja w mieście "niezwykle napięta"
 - [https://tvn24.pl/swiat/ukraina-walki-o-bachmut-rosjanie-nasilili-natarcie-trudna-sytuacja-obroncow-6781689?source=rss](https://tvn24.pl/swiat/ukraina-walki-o-bachmut-rosjanie-nasilili-natarcie-trudna-sytuacja-obroncow-6781689?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 08:38:07+00:00

<img alt="Rosjanie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ma4gv7-ukrainscy-zolnierze-w-okopach-na-linii-frontu-w-obwodzie-donieckim-26022023-6781702/alternates/LANDSCAPE_1280" />
    Walki o Bachmut.

## Z dzieckiem przechodzili przez pasy, 66-latek się nie zatrzymał. "Kaleczył ludzi, odrzucało ich"
 - [https://tvn24.pl/bialystok/augustow-dorosli-i-dziecko-potraceni-na-przejsciu-dla-pieszych-zarzut-dla-66-letniego-kierowcy-ktory-sie-nie-zatrzymal-6781654?source=rss](https://tvn24.pl/bialystok/augustow-dorosli-i-dziecko-potraceni-na-przejsciu-dla-pieszych-zarzut-dla-66-letniego-kierowcy-ktory-sie-nie-zatrzymal-6781654?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 08:27:35+00:00

<img alt="Z dzieckiem przechodzili przez pasy, 66-latek się nie zatrzymał. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7hwpit-piesi-trafili-do-szpitala-policja-ustalala-przyczyny-wypadku-6781679/alternates/LANDSCAPE_1280" />
    Wypadek na przejściu dla pieszych w Augustowie (woj. podlaskie).

## Nie ma nadziei dla Toma Sizemore'a. "Lekarze zalecili decyzje o zakończeniu życia"
 - [https://tvn24.pl/kultura-i-styl/usa-aktor-tom-sizemore-w-spiaczce-lekarze-zalecili-decyzje-o-zakonczeniu-zycia-6781619?source=rss](https://tvn24.pl/kultura-i-styl/usa-aktor-tom-sizemore-w-spiaczce-lekarze-zalecili-decyzje-o-zakonczeniu-zycia-6781619?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 08:14:55+00:00

<img alt="Nie ma nadziei dla Toma Sizemore'a. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xd5pah-tom-sizemore-6766980/alternates/LANDSCAPE_1280" />
    Aktor jest w śpiączce po pęknięciu tętniaka mózgu.

## Zachwyty po sukcesie Oleksego. "Król jest tylko jeden"
 - [https://eurosport.tvn24.pl/zachwyty-po-sukcesie-oleksego---kr-l-jest-tylko-jeden-,1137999.html?source=rss](https://eurosport.tvn24.pl/zachwyty-po-sukcesie-oleksego---kr-l-jest-tylko-jeden-,1137999.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 07:57:20+00:00

<img alt="Zachwyty po sukcesie Oleksego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7h3as4-marcin-oleksy-triumfatorem-prestizowej-nagrody-na-bramke-roku-6781699/alternates/LANDSCAPE_1280" />
    Po wygraniu plebiscytu FIFA na Bramkę Roku.

## Rosyjski A-50 na białoruskim lotnisku. Zdjęcia satelitarne sprzed ataku
 - [https://tvn24.pl/swiat/bialorus-rosyjski-samolot-wczesnego-rozpoznania-na-lotnisku-zdjecia-a-50-sprzed-ataku-6781610?source=rss](https://tvn24.pl/swiat/bialorus-rosyjski-samolot-wczesnego-rozpoznania-na-lotnisku-zdjecia-a-50-sprzed-ataku-6781610?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 07:50:12+00:00

<img alt="Rosyjski A-50 na białoruskim lotnisku. Zdjęcia satelitarne sprzed ataku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i1fe1f-a-50-na-lotnisku-6781614/alternates/LANDSCAPE_1280" />
    Opublikowała agencja Reutera.

## Znaleźli szczątki mężczyzny w ciele rekina
 - [https://tvn24.pl/tvnmeteo/swiat/argentyna-szczatki-mezczyzny-w-ciele-rekina-tatuaz-pozwolil-na-identyfikacje-6781599?source=rss](https://tvn24.pl/tvnmeteo/swiat/argentyna-szczatki-mezczyzny-w-ciele-rekina-tatuaz-pozwolil-na-identyfikacje-6781599?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 07:49:33+00:00

<img alt="Znaleźli szczątki mężczyzny w ciele rekina" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5kih43-zarlacz-szary-galeorhinus-galeus-zdj-ilustracyjne-6781596/alternates/LANDSCAPE_1280" />
    Na jego identyfikację pozwolił tatuaż.

## Kłopoty z rozliczeniem podatków, nie działała strona rządowa. "Nie był to atak hakerski"
 - [https://tvn24.pl/biznes/pieniadze/strona-podatkigovpl-nie-dzialala-awaria-6781648?source=rss](https://tvn24.pl/biznes/pieniadze/strona-podatkigovpl-nie-dzialala-awaria-6781648?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 07:31:55+00:00

<img alt="Kłopoty z rozliczeniem podatków, nie działała strona rządowa. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fieui8-twoj-e-pit-podatki-6759775/alternates/LANDSCAPE_1280" />
    Awaria strony podatki.gov.pl.

## Kłopoty z rozliczeniem podatków. Nie działa strona rządowa
 - [https://tvn24.pl/biznes/pieniadze/strona-podatkigovpl-nie-dziala-awaria-6781648?source=rss](https://tvn24.pl/biznes/pieniadze/strona-podatkigovpl-nie-dziala-awaria-6781648?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 07:31:55+00:00

<img alt="Kłopoty z rozliczeniem podatków. Nie działa strona rządowa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cesw8x-komputer-laptop-5786682/alternates/LANDSCAPE_1280" />
    Awaria strony podatki.gov.pl.

## "Największa organizacja charytatywna sprzedawała namioty, zamiast rozdawać je za darmo"
 - [https://tvn24.pl/swiat/oburzenie-w-turcji-doniesienia-o-sprzedazy-przez-czerwony-polksiezyc-namiotow-dla-poszkodowanych-w-trzesieniu-ziemi-6781509?source=rss](https://tvn24.pl/swiat/oburzenie-w-turcji-doniesienia-o-sprzedazy-przez-czerwony-polksiezyc-namiotow-dla-poszkodowanych-w-trzesieniu-ziemi-6781509?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 07:24:14+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k3pg69-pracownicy-czerwonego-polksiezyca-4423882/alternates/LANDSCAPE_1280" />
    Oburzenie w Turcji.

## "Będziemy razem startowali do Senatu". Seria pytań o nazwiska na wspólnej liście
 - [https://tvn24.pl/polska/pakt-senacki-wspolna-lista-opozycji-krzysztof-gawkowski-o-nazwiskach-na-liscie-6781603?source=rss](https://tvn24.pl/polska/pakt-senacki-wspolna-lista-opozycji-krzysztof-gawkowski-o-nazwiskach-na-liscie-6781603?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 07:11:32+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kbvk6r-piasecki-6781622/alternates/LANDSCAPE_1280" />
    Krzysztof Gawkowski w "Rozmowie Piaseckiego".

## Ronaldo pominięty po latach dominacji
 - [https://eurosport.tvn24.pl/jedenastka-roku-fifa--ronaldo-pomini-ty-po-latach-dominacji,1138000.html?source=rss](https://eurosport.tvn24.pl/jedenastka-roku-fifa--ronaldo-pomini-ty-po-latach-dominacji,1138000.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 07:05:00+00:00

<img alt="Ronaldo pominięty po latach dominacji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rvstaa-cristiano-ronaldo-nie-znalazl-sie-w-jedenastce-fifa-za-2022-rok-6781633/alternates/LANDSCAPE_1280" />
    Jedenastka Roku FIFA.

## "Pogarszająca się" sytuacja. Kim Dzong Un wzywa do "fundamentalnej transformacji"
 - [https://tvn24.pl/swiat/korea-polnocna-brakuje-zywnosci-i-zboza-kim-dzong-un-nakazuje-fundamentalna-transformacje-rolnictwa-6781526?source=rss](https://tvn24.pl/swiat/korea-polnocna-brakuje-zywnosci-i-zboza-kim-dzong-un-nakazuje-fundamentalna-transformacje-rolnictwa-6781526?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 06:55:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qug4dn-gettyimages-922231528-6781607/alternates/LANDSCAPE_1280" />
    Korei Północnej brakuje około miliona ton zboża - donoszą media.

## Muszą usunąć popularną aplikację
 - [https://tvn24.pl/biznes/ze-swiata/tiktok-zakazany-dla-pracownikow-agencji-rzadowych-usa-bialy-dom-daje-30-dni-na-usuniecie-aplikacji-6781592?source=rss](https://tvn24.pl/biznes/ze-swiata/tiktok-zakazany-dla-pracownikow-agencji-rzadowych-usa-bialy-dom-daje-30-dni-na-usuniecie-aplikacji-6781592?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 06:53:59+00:00

<img alt="Muszą usunąć popularną aplikację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6m4bcc-android-14-6305642/alternates/LANDSCAPE_1280" />
    Biały Dom wyznaczył termin.

## "Fałszywa narracja Putina". Eksperci ISW analizują nowy przekaz
 - [https://tvn24.pl/swiat/ukraina-rosja-przekaz-propagandowy-putina-nowa-falszywa-narracja-analiza-isw-6781542?source=rss](https://tvn24.pl/swiat/ukraina-rosja-przekaz-propagandowy-putina-nowa-falszywa-narracja-analiza-isw-6781542?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 06:44:22+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-e7wo67-wladimir-putin-6778240/alternates/LANDSCAPE_1280" />
    Instytut Badań nad Wojną we wtorkowej analizie.

## Zaskakujące głosy na Lewandowskiego
 - [https://eurosport.tvn24.pl/kapitan-andory-i-selekcjoner-kostaryki-wskazali-lewandowskiego--tak-g-osowano-w-plebiscycie-fifa,1137998.html?source=rss](https://eurosport.tvn24.pl/kapitan-andory-i-selekcjoner-kostaryki-wskazali-lewandowskiego--tak-g-osowano-w-plebiscycie-fifa,1137998.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 06:42:00+00:00

<img alt="Zaskakujące głosy na Lewandowskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-prnpfp-robert-lewandowski-tym-razem-bez-nagrody-na-gali-fifa-6781608/alternates/LANDSCAPE_1280" />
    Szczegółowe wyniki głosowania na Piłkarza Roku FIFA.

## Nie żyje jedyny taki tyczkarz
 - [https://eurosport.tvn24.pl/nie--yje-bob-richards--by--jedynym-dwukrotnym-mistrzem-olimpijskim-w-skoku-o-tyczce,1137993.html?source=rss](https://eurosport.tvn24.pl/nie--yje-bob-richards--by--jedynym-dwukrotnym-mistrzem-olimpijskim-w-skoku-o-tyczce,1137993.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 06:37:00+00:00

<img alt="Nie żyje jedyny taki tyczkarz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-evanch-bob-richards-mial-97-lat-6781604/alternates/LANDSCAPE_1280" />
    Bob Richards miał 97 lat.

## "Wzrost liczby zachorowań wśród młodych dorosłych". Diagnoza często przychodzi za późno
 - [https://tvn24.pl/polska/rak-jelita-grubego-w-polsce-diagnoza-i-leczenie-immunoterapia-jak-zapisac-sie-na-badania-przesiewowe-6781480?source=rss](https://tvn24.pl/polska/rak-jelita-grubego-w-polsce-diagnoza-i-leczenie-immunoterapia-jak-zapisac-sie-na-badania-przesiewowe-6781480?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 06:20:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mfwv6s-w-polsce-liczba-przypadkow-raka-jelita-grubego-systematycznie-rosnie-6781477/alternates/LANDSCAPE_1280" />
    W Polsce liczba przypadków systematycznie rośnie.

## Elon Musk i Tesla pozwani
 - [https://tvn24.pl/biznes/moto/tesla-i-elon-musk-pozwani-przez-akcjonariuszy-za-wprowadzanie-w-blad-6781541?source=rss](https://tvn24.pl/biznes/moto/tesla-i-elon-musk-pozwani-przez-akcjonariuszy-za-wprowadzanie-w-blad-6781541?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 06:06:06+00:00

<img alt="Elon Musk i Tesla pozwani" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-sp2as8-tesla-6763354/alternates/LANDSCAPE_1280" />
    "Ponieśli znaczące straty i szkody".

## "Największe straty w historii współczesnej Rosji". Wyższe niż podają sami Ukraińcy
 - [https://tvn24.pl/swiat/rosja-rosyjskie-straty-w-ukrainie-zabici-i-ranni-zolnierze-analityk-ruslan-lewijew-szacuje-6781487?source=rss](https://tvn24.pl/swiat/rosja-rosyjskie-straty-w-ukrainie-zabici-i-ranni-zolnierze-analityk-ruslan-lewijew-szacuje-6781487?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 05:48:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-40kepb-rosyjskie-wojsko-w-obwodzie-donieckim-6728969/alternates/LANDSCAPE_1280" />
    Szacunki przedstawione przez analityka nie uwzględniają Rosgwardii i Grupy Wagnera.

## Wzruszająca przemowa Oleksego po wygraniu plebiscytu FIFA
 - [https://eurosport.tvn24.pl/marcin-oleksy-i-wzruszaj-ca-przemowa-po-wygraniu-plebiscytu-fifa,1137997.html?source=rss](https://eurosport.tvn24.pl/marcin-oleksy-i-wzruszaj-ca-przemowa-po-wygraniu-plebiscytu-fifa,1137997.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 05:45:34+00:00

<img alt="Wzruszająca przemowa Oleksego po wygraniu plebiscytu FIFA " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fipmc0-marcin-oleksy-6781544/alternates/LANDSCAPE_1280" />
    Najpierw było niedowierzanie, po chwili wzruszenie. Marcin Oleksy z prestiżową nagrodą FIFA.

## "Był wielokrotnie notowany". Znów trafił do aresztu, bo chciał ukraść maszynki do golenia
 - [https://tvn24.pl/tvnwarszawa/wola/warszawa-byl-wielokrotnie-notowany-i-poszukiwany-teraz-znow-trafi-do-aresztu-bo-nie-chcial-zaplacic-za-maszynki-do-golenia-6780869?source=rss](https://tvn24.pl/tvnwarszawa/wola/warszawa-byl-wielokrotnie-notowany-i-poszukiwany-teraz-znow-trafi-do-aresztu-bo-nie-chcial-zaplacic-za-maszynki-do-golenia-6780869?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 05:44:59+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-g0mi63-zatrzymany-mezczyzna-6780866/alternates/LANDSCAPE_1280" />
    Doszło do szarpaniny.

## Śmiertelnie potrącił pieszego na przejściu. Prokuratura umorzyła, ale sąd się nie zgodził
 - [https://tvn24.pl/tvnwarszawa/ursynow/warszawa-smiertelny-wypadek-na-romera-akt-oskarzenia-6775655?source=rss](https://tvn24.pl/tvnwarszawa/ursynow/warszawa-smiertelny-wypadek-na-romera-akt-oskarzenia-6775655?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 05:42:46+00:00

<img alt="Śmiertelnie potrącił pieszego na przejściu. Prokuratura umorzyła, ale sąd się nie zgodził" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qz9iyn-kierowca-pod-wplywem-alkoholu-potracil-pieszego-4669387/alternates/LANDSCAPE_1280" />
    Jest akt oskarżenia.

## "Zdecydowanie potępiam okrutny i brutalny atak na mieszkańców Huwary"
 - [https://tvn24.pl/swiat/izrael-zachodni-brzeg-jordanu-prezydent-izraela-potepil-atak-zydowskich-osadnikow-na-palestynczykow-6781532?source=rss](https://tvn24.pl/swiat/izrael-zachodni-brzeg-jordanu-prezydent-izraela-potepil-atak-zydowskich-osadnikow-na-palestynczykow-6781532?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 05:36:13+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yq2ezf-izrael-6781531/alternates/LANDSCAPE_1280" />
    Powiedział cytowany przez media prezydent Izraela Isaac Herzog.

## "Moskwa nie może sobie pozwolić na przyznanie, że przegrywa wojnę"
 - [https://tvn24.pl/swiat/ukraina-szef-wywiadu-wojskowego-rosja-nie-jest-gotowa-do-dlugiej-wojny-6781483?source=rss](https://tvn24.pl/swiat/ukraina-szef-wywiadu-wojskowego-rosja-nie-jest-gotowa-do-dlugiej-wojny-6781483?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 05:20:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-95hg0g-zniszczony-rosyjski-czolg-we-wsi-dmytriwka-pod-kijowem-6760431/alternates/LANDSCAPE_1280" />
    Ocenił szef ukraińskiego wywiadu wojskowego Kyryło Budanow.

## "Fałszywa narracja Putina". Eksperci ISW o wypowiedzi dla telewizji państwowej
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-28-lutego-2023-6781528?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-28-lutego-2023-6781528?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 04:50:00+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-e7wo67-wladimir-putin-6778240/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## Steven Seagal odznaczony przez Putina. Najwyższe odznaczenie państwowe
 - [https://tvn24.pl/swiat/rosja-aktor-steven-seagal-odznaczony-przez-putina-dostal-najwyzsze-odznaczenie-panstwowe-6781522?source=rss](https://tvn24.pl/swiat/rosja-aktor-steven-seagal-odznaczony-przez-putina-dostal-najwyzsze-odznaczenie-panstwowe-6781522?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 04:38:00+00:00

<img alt="Steven Seagal odznaczony przez Putina. Najwyższe odznaczenie państwowe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fhajxf-steven-seagal-obserwowal-defilade-w-moskwie-6781519/alternates/LANDSCAPE_1280" />
    Reuters opisuje dekret wydany przez prezydenta Rosji.

## Amerykańska sekretarz skarbu z niezapowiedzianą wizytą w Kijowie
 - [https://tvn24.pl/swiat/ukraina-sekretarz-skarbu-usa-janet-yellen-odwiedzila-bez-zapowiedzi-kijow-6781507?source=rss](https://tvn24.pl/swiat/ukraina-sekretarz-skarbu-usa-janet-yellen-odwiedzila-bez-zapowiedzi-kijow-6781507?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 04:28:00+00:00

<img alt="Amerykańska sekretarz skarbu z niezapowiedzianą wizytą w Kijowie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-343g41-janet-yellen-podczas-spotkania-z-prezydentem-ukrainy-wolodymyrem-zelenskim-6781504/alternates/LANDSCAPE_1280" />
    Powiedziała o "poważnych przeszkodach prawnych" dla całkowitej konfiskaty zamrożonych rosyjskich aktywów.

## Departament Stanu USA: Chiny "bardzo wyraźnie" stanęły po stronie Rosji
 - [https://tvn24.pl/swiat/usa-departament-stanu-chiny-bardzo-wyraznie-stanely-po-stronie-rosji-6781498?source=rss](https://tvn24.pl/swiat/usa-departament-stanu-chiny-bardzo-wyraznie-stanely-po-stronie-rosji-6781498?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-28 04:20:33+00:00

<img alt="Departament Stanu USA: Chiny " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ryuoj-wang-yi-i-wladimir-putin-6771972/alternates/LANDSCAPE_1280" />
    Chiński plan pokojowy "może nie być poważną propozycją" - ocenił rzecznik departamentu, Ned Price.

