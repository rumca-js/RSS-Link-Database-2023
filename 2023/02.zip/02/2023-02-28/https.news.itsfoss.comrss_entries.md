# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Slack Open Sources 'Hakana' to Help Developers With Hack Language
 - [https://news.itsfoss.com/slack-open-source-hakana/](https://news.itsfoss.com/slack-open-source-hakana/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-02-28 10:03:24+00:00

Slack open sources its internal tool Hakana to help other developers and companies using Hack language.

