# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## China's Foreclosures Soar Amid Economic Crisis/What's the secret behind?
 - [https://www.youtube.com/watch?v=F_ZvodfYvi4](https://www.youtube.com/watch?v=F_ZvodfYvi4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-02-28 00:15:09+00:00

#chinainsights 
" After calculation, I would have lost about 600,000 yuan or 87,000 US dollars."--one homeowner.
An important sign of China's deteriorating economy is the significant increase in the number of foreclosed homes in 2022. China Index Academy says this is a historically high number.
Some people may think that those who bought multiple properties are too greedy, which has led to their tragedy today. That's not necessarily true. In China, people's cash on hand is insecure, shrinking due to inflation, and there are almost no safe bank products of any kind. As a result, investing savings in the hot real estate market and rising housing prices has become the hope for many Chinese to preserve and increase the value of their money. 

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

