# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## 'Very Protective' Family Dog Helps Rescue 1-Year-Old Girl from Detroit House Fire
 - [http://www.msn.com/en-us/news/us/very-protective-family-dog-helps-rescue-1-year-old-girl-from-detroit-house-fire/ar-AA184bq6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/very-protective-family-dog-helps-rescue-1-year-old-girl-from-detroit-house-fire/ar-AA184bq6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 23:24:32.183800+00:00



## Congressional 'Gang of 8' gets long-awaited briefing on Trump, Biden and Pence docs
 - [http://www.msn.com/en-us/news/politics/congressional-gang-of-8-gets-long-awaited-briefing-on-trump-biden-and-pence-docs/ar-AA182gUA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/congressional-gang-of-8-gets-long-awaited-briefing-on-trump-biden-and-pence-docs/ar-AA182gUA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 23:24:32.176565+00:00



## Wray responds to FBI critiques over Hunter laptop, Trump raid, Ray Epps: We're 'on the American people's side'
 - [http://www.msn.com/en-us/news/us/wray-responds-to-fbi-critiques-over-hunter-laptop-trump-raid-ray-epps-we-re-on-the-american-people-s-side/ar-AA1846vR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/wray-responds-to-fbi-critiques-over-hunter-laptop-trump-raid-ray-epps-we-re-on-the-american-people-s-side/ar-AA1846vR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 23:24:32.169225+00:00



## Memphis teen 1 of 2 charged in church leader's 2022 killing
 - [http://www.msn.com/en-us/news/us/memphis-teen-1-of-2-charged-in-church-leader-s-2022-killing/ar-AA184dZt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/memphis-teen-1-of-2-charged-in-church-leader-s-2022-killing/ar-AA184dZt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 23:24:32.162026+00:00



## Mexican president: My nation has more democracy than U.S.
 - [http://www.msn.com/en-us/news/world/mexican-president-my-nation-has-more-democracy-than-u-s/ar-AA183YBR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/mexican-president-my-nation-has-more-democracy-than-u-s/ar-AA183YBR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 23:24:32.154751+00:00



## Supreme Court Considers Biden’s Authority to Cancel Student Loan Debt
 - [http://www.msn.com/en-us/news/us/supreme-court-considers-biden-s-authority-to-cancel-student-loan-debt/ar-AA184gIQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/supreme-court-considers-biden-s-authority-to-cancel-student-loan-debt/ar-AA184gIQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 23:24:32.147553+00:00



## We cannot treat our way out of the obesity epidemic
 - [http://www.msn.com/en-us/news/politics/we-cannot-treat-our-way-out-of-the-obesity-epidemic/ar-AA184qSK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/we-cannot-treat-our-way-out-of-the-obesity-epidemic/ar-AA184qSK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 23:24:32.140167+00:00



## Verizon Is Adding a New Fee to Some of Its Older Unlimited Plans
 - [http://www.msn.com/en-us/news/technology/verizon-is-adding-a-new-fee-to-some-of-its-older-unlimited-plans/ar-AA18418H?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/verizon-is-adding-a-new-fee-to-some-of-its-older-unlimited-plans/ar-AA18418H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 23:24:32.132142+00:00



## We Have a Mink Problem
 - [http://www.msn.com/en-us/news/technology/we-have-a-mink-problem/ar-AA183qk8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/we-have-a-mink-problem/ar-AA183qk8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 22:24:32.959947+00:00



## Russia will emerge from the Ukraine war a 'shattered military power,' top Pentagon official says
 - [http://www.msn.com/en-us/news/world/russia-will-emerge-from-the-ukraine-war-a-shattered-military-power-top-pentagon-official-says/ar-AA183LVo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-will-emerge-from-the-ukraine-war-a-shattered-military-power-top-pentagon-official-says/ar-AA183LVo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 22:24:32.953030+00:00



## Chinese Pundit Warns Russia May Bring Major New Threat to Black Sea
 - [http://www.msn.com/en-us/news/world/chinese-pundit-warns-russia-may-bring-major-new-threat-to-black-sea/ar-AA183VUp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/chinese-pundit-warns-russia-may-bring-major-new-threat-to-black-sea/ar-AA183VUp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 22:24:32.945368+00:00



## What the FBI found at the home of the University of Idaho murder suspect
 - [http://www.msn.com/en-us/news/crime/what-the-fbi-found-at-the-home-of-the-university-of-idaho-murder-suspect/ar-AA183xzf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/what-the-fbi-found-at-the-home-of-the-university-of-idaho-murder-suspect/ar-AA183xzf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 22:24:32.938398+00:00



## Residency fights could snare many Georgia voters under bill
 - [http://www.msn.com/en-us/news/politics/residency-fights-could-snare-many-georgia-voters-under-bill/ar-AA183DT1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/residency-fights-could-snare-many-georgia-voters-under-bill/ar-AA183DT1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 22:24:32.931489+00:00



## New poll shows Lightfoot in third place in Chicago mayoral race
 - [http://www.msn.com/en-us/news/politics/new-poll-shows-lightfoot-in-third-place-in-chicago-mayoral-race/ar-AA183Oge?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/new-poll-shows-lightfoot-in-third-place-in-chicago-mayoral-race/ar-AA183Oge?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 22:24:32.924001+00:00



## Teen Who Lost Legs After Being Hit by Car is Learning 'to do Life Again,' While Driver Remains in Custody
 - [http://www.msn.com/en-us/news/us/teen-who-lost-legs-after-being-hit-by-car-is-learning-to-do-life-again-while-driver-remains-in-custody/ar-AA183HNy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/teen-who-lost-legs-after-being-hit-by-car-is-learning-to-do-life-again-while-driver-remains-in-custody/ar-AA183HNy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 22:24:32.915180+00:00



## Former FTX exec pleads guilty to charges related to crypto exchange's collapse
 - [http://www.msn.com/en-us/news/crime/former-ftx-exec-pleads-guilty-to-charges-related-to-crypto-exchange-s-collapse/ar-AA1835qH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/former-ftx-exec-pleads-guilty-to-charges-related-to-crypto-exchange-s-collapse/ar-AA1835qH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 22:24:32.907901+00:00



## Railroads urged to examine track detectors after Ohio crash
 - [http://www.msn.com/en-us/news/us/railroads-urged-to-examine-track-detectors-after-ohio-crash/ar-AA183wIy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/railroads-urged-to-examine-track-detectors-after-ohio-crash/ar-AA183wIy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 21:24:27.301467+00:00



## Russia-Ukraine live updates: Putin admits military losses
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-putin-admits-military-losses/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-putin-admits-military-losses/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 21:24:27.293044+00:00



## Hit-and-Run in St. Louis Kills 3 Teens and a 'Very Sweet,' 20-Year-Old Father, Suspect Still at Large
 - [http://www.msn.com/en-us/news/crime/hit-and-run-in-st-louis-kills-3-teens-and-a-very-sweet-20-year-old-father-suspect-still-at-large/ar-AA183O4p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/hit-and-run-in-st-louis-kills-3-teens-and-a-very-sweet-20-year-old-father-suspect-still-at-large/ar-AA183O4p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 21:24:27.285814+00:00



## Experts think AI could bring on the next Industrial Revolution — and some even think it could trigger nuclear war
 - [http://www.msn.com/en-us/news/technology/experts-think-ai-could-bring-on-the-next-industrial-revolution-and-some-even-think-it-could-trigger-nuclear-war/ar-AA183rfv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/experts-think-ai-could-bring-on-the-next-industrial-revolution-and-some-even-think-it-could-trigger-nuclear-war/ar-AA183rfv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 21:24:27.278490+00:00



## How Ozempic and Wegovy Are Changing the Weight-Loss Drug Market
 - [http://www.msn.com/en-us/news/technology/how-ozempic-and-wegovy-are-changing-the-weight-loss-drug-market/ar-AA17da8H?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-ozempic-and-wegovy-are-changing-the-weight-loss-drug-market/ar-AA17da8H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 21:24:27.270830+00:00



## Senate panel asks Norfolk Southern CEO to testify about Ohio train derailment
 - [http://www.msn.com/en-us/news/politics/senate-panel-asks-norfolk-southern-ceo-to-testify-about-ohio-train-derailment/ar-AA183pKS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-panel-asks-norfolk-southern-ceo-to-testify-about-ohio-train-derailment/ar-AA183pKS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 21:24:27.261683+00:00



## McCarthy’s Tucker Carlson decision ‘despicable,’ says Schumer
 - [http://www.msn.com/en-us/news/politics/mccarthy-s-tucker-carlson-decision-despicable-says-schumer/ar-AA183Hb1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccarthy-s-tucker-carlson-decision-despicable-says-schumer/ar-AA183Hb1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 21:24:27.254327+00:00



## Putin Can’t Win: New Western Insights Show Russia Won’t Claim Victory in Ukraine
 - [http://www.msn.com/en-us/news/world/putin-can-t-win-new-western-insights-show-russia-won-t-claim-victory-in-ukraine/ar-AA183pMM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-can-t-win-new-western-insights-show-russia-won-t-claim-victory-in-ukraine/ar-AA183pMM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 21:24:27.246292+00:00



## Former NFL player Zac Stacy sentenced to jail after assault on ex-girlfriend
 - [http://www.msn.com/en-us/news/crime/former-nfl-player-zac-stacy-sentenced-to-jail-after-assault-on-ex-girlfriend/ar-AA183vSW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/former-nfl-player-zac-stacy-sentenced-to-jail-after-assault-on-ex-girlfriend/ar-AA183vSW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 20:24:36.183248+00:00



## NASA Astronaut Shares 'Absolutely Unreal' View of Earth From ISS
 - [http://www.msn.com/en-us/news/technology/nasa-astronaut-shares-absolutely-unreal-view-of-earth-from-iss/ar-AA183AXR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/nasa-astronaut-shares-absolutely-unreal-view-of-earth-from-iss/ar-AA183AXR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 20:24:36.175471+00:00



## Ron DeSantis Releases New Book Touting Political 'Battles' He's Fought Ahead of Widely Rumored 2024 Campaign
 - [http://www.msn.com/en-us/news/politics/ron-desantis-releases-new-book-touting-political-battles-he-s-fought-ahead-of-widely-rumored-2024-campaign/ar-AA183GdV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ron-desantis-releases-new-book-touting-political-battles-he-s-fought-ahead-of-widely-rumored-2024-campaign/ar-AA183GdV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 20:24:36.167914+00:00



## China bills sail through House committee
 - [http://www.msn.com/en-us/news/politics/china-bills-sail-through-house-committee/ar-AA183B2q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/china-bills-sail-through-house-committee/ar-AA183B2q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 20:24:36.157347+00:00



## When can student loan borrowers expect the repayment pause to end?
 - [http://www.msn.com/en-us/news/politics/when-can-student-loan-borrowers-expect-the-repayment-pause-to-end/ar-AA183GpI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/when-can-student-loan-borrowers-expect-the-repayment-pause-to-end/ar-AA183GpI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 20:24:36.149741+00:00



## Mitch McConnell repeatedly swats away questions about Kevin McCarthy giving January 6 footage to Tucker Carlson: 'Good try'
 - [http://www.msn.com/en-us/news/politics/mitch-mcconnell-repeatedly-swats-away-questions-about-kevin-mccarthy-giving-january-6-footage-to-tucker-carlson-good-try/ar-AA183ILo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mitch-mcconnell-repeatedly-swats-away-questions-about-kevin-mccarthy-giving-january-6-footage-to-tucker-carlson-good-try/ar-AA183ILo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 20:24:36.142038+00:00



## Tenn. governor vows to sign anti-drag bill as photo surfaces
 - [http://www.msn.com/en-us/news/politics/tenn-governor-vows-to-sign-anti-drag-bill-as-photo-surfaces/ar-AA183Bby?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/tenn-governor-vows-to-sign-anti-drag-bill-as-photo-surfaces/ar-AA183Bby?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 20:24:36.134430+00:00



## Kidnapped woman escapes driving away with hands bound and face covered: Police
 - [http://www.msn.com/en-us/news/crime/kidnapped-woman-escapes-driving-away-with-hands-bound-and-face-covered-police/ar-AA1837ob?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/kidnapped-woman-escapes-driving-away-with-hands-bound-and-face-covered-police/ar-AA1837ob?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 19:24:28.418173+00:00



## How Italy's Far-Right Government is Pushing Back Against Migrants
 - [http://www.msn.com/en-us/news/world/how-italy-s-far-right-government-is-pushing-back-against-migrants/ar-AA183gzI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/how-italy-s-far-right-government-is-pushing-back-against-migrants/ar-AA183gzI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 19:24:28.410404+00:00



## Missing Woman Found Possibly Dismembered in Texas; Suspect Allegedly Searched 'How to Be a Serial Killer'
 - [http://www.msn.com/en-us/news/crime/missing-woman-found-possibly-dismembered-in-texas-suspect-allegedly-searched-how-to-be-a-serial-killer/ar-AA183bdX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/missing-woman-found-possibly-dismembered-in-texas-suspect-allegedly-searched-how-to-be-a-serial-killer/ar-AA183bdX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 19:24:28.401775+00:00



## Accused Russian ‘Spy’ Just Wants to Pay His Bills
 - [http://www.msn.com/en-us/news/us/accused-russian-spy-just-wants-to-pay-his-bills/ar-AA183g9U?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/accused-russian-spy-just-wants-to-pay-his-bills/ar-AA183g9U?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 19:24:28.394510+00:00



## Scalise defends McCarthy’s decision to give Jan. 6 tapes to Tucker Carlson as Speaker dodges reporters’ questions
 - [http://www.msn.com/en-us/news/politics/scalise-defends-mccarthy-s-decision-to-give-jan-6-tapes-to-tucker-carlson-as-speaker-dodges-reporters-questions/ar-AA1839xD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/scalise-defends-mccarthy-s-decision-to-give-jan-6-tapes-to-tucker-carlson-as-speaker-dodges-reporters-questions/ar-AA1839xD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 19:24:28.386065+00:00



## Hemorrhaging losses, the Fed’s problems are now the taxpayer’s
 - [http://www.msn.com/en-us/news/politics/hemorrhaging-losses-the-fed-s-problems-are-now-the-taxpayer-s/ar-AA182XaG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hemorrhaging-losses-the-fed-s-problems-are-now-the-taxpayer-s/ar-AA182XaG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 19:24:28.378501+00:00



## Idaho murders: Bryan Kohberger's Pennsylvania warrants unsealed
 - [http://www.msn.com/en-us/news/crime/idaho-murders-bryan-kohberger-s-pennsylvania-warrants-unsealed/ar-AA183bwm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/idaho-murders-bryan-kohberger-s-pennsylvania-warrants-unsealed/ar-AA183bwm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 19:24:28.371513+00:00



## GOP's Portman launches center to foster civility in politics
 - [http://www.msn.com/en-us/news/politics/gop-s-portman-launches-center-to-foster-civility-in-politics/ar-AA183gCL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-s-portman-launches-center-to-foster-civility-in-politics/ar-AA183gCL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 19:24:28.363387+00:00



## Commerce Department requiring CHIPS money be used for child care
 - [http://www.msn.com/en-us/news/us/commerce-department-requiring-chips-money-be-used-for-child-care/ar-AA182Rxo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/commerce-department-requiring-chips-money-be-used-for-child-care/ar-AA182Rxo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 18:24:25.212358+00:00



## Biden to tap Su as next Labor secretary
 - [http://www.msn.com/en-us/news/politics/biden-to-tap-su-as-next-labor-secretary/ar-AA182UGl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-to-tap-su-as-next-labor-secretary/ar-AA182UGl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 18:24:25.203508+00:00



## Sam Bankman-Fried Confidant Cops a Guilty Plea
 - [http://www.msn.com/en-us/news/crime/sam-bankman-fried-confidant-cops-a-guilty-plea/ar-AA1836EL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/sam-bankman-fried-confidant-cops-a-guilty-plea/ar-AA1836EL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 18:24:25.196227+00:00



## Watch live: Biden delivers remarks on health-care costs from Virginia Beach
 - [http://www.msn.com/en-us/news/politics/watch-live-biden-delivers-remarks-on-health-care-costs-from-virginia-beach/ar-AA182F9j?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/watch-live-biden-delivers-remarks-on-health-care-costs-from-virginia-beach/ar-AA182F9j?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 18:24:25.189139+00:00



## Google Replumbs Chrome on Mac for Better Battery Life
 - [http://www.msn.com/en-us/news/technology/google-replumbs-chrome-on-mac-for-better-battery-life/ar-AA1836go?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/google-replumbs-chrome-on-mac-for-better-battery-life/ar-AA1836go?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 18:24:25.180286+00:00



## Missouri Pastor Says He Stopped Potential Armed Robbery During Church by Praying for Suspects
 - [http://www.msn.com/en-us/news/us/missouri-pastor-says-he-stopped-potential-armed-robbery-during-church-by-praying-for-suspects/ar-AA182ZHf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/missouri-pastor-says-he-stopped-potential-armed-robbery-during-church-by-praying-for-suspects/ar-AA182ZHf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 18:24:25.171874+00:00



## Dead humpback whale seen off New York, New Jersey coast
 - [http://www.msn.com/en-us/news/us/dead-humpback-whale-seen-off-new-york-new-jersey-coast/ar-AA182URL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/dead-humpback-whale-seen-off-new-york-new-jersey-coast/ar-AA182URL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 18:24:25.163754+00:00



## John Roberts invokes blocking Trump challenge against DACA in Biden student loan case
 - [http://www.msn.com/en-us/news/us/john-roberts-invokes-blocking-trump-challenge-against-daca-in-biden-student-loan-case/ar-AA1835Qk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/john-roberts-invokes-blocking-trump-challenge-against-daca-in-biden-student-loan-case/ar-AA1835Qk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 17:24:25.615227+00:00



## Asteroid named after pope behind Gregorian calendar reform
 - [http://www.msn.com/en-us/news/world/asteroid-named-after-pope-behind-gregorian-calendar-reform/ar-AA1833tN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/asteroid-named-after-pope-behind-gregorian-calendar-reform/ar-AA1833tN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 17:24:25.607691+00:00



## Kim Jong-un's 3 Children: Everything to Know
 - [http://www.msn.com/en-us/news/world/kim-jong-un-s-3-children-everything-to-know/ar-AA182Eyf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/kim-jong-un-s-3-children-everything-to-know/ar-AA182Eyf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 17:24:25.600193+00:00



## DeSantis' new memoir skips juicy details about his life that could emerge in a presidential bid. Here's what he left out.
 - [http://www.msn.com/en-us/news/politics/desantis-new-memoir-skips-juicy-details-about-his-life-that-could-emerge-in-a-presidential-bid-here-s-what-he-left-out/ar-AA1835Kv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/desantis-new-memoir-skips-juicy-details-about-his-life-that-could-emerge-in-a-presidential-bid-here-s-what-he-left-out/ar-AA1835Kv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 17:24:25.592692+00:00



## 'Relaxed' 6.5ft Alligator Seen Strolling Across Florida School Sports Field
 - [http://www.msn.com/en-us/news/us/relaxed-6-5ft-alligator-seen-strolling-across-florida-school-sports-field/ar-AA182R7P?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/relaxed-6-5ft-alligator-seen-strolling-across-florida-school-sports-field/ar-AA182R7P?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 17:24:25.585172+00:00



## Black teen girls are the curators of culture
 - [http://www.msn.com/en-us/news/us/black-teen-girls-are-the-curators-of-culture/ar-AA182W0Q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/black-teen-girls-are-the-curators-of-culture/ar-AA182W0Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 17:24:25.578083+00:00



## Texas school shooting survivor's 'American Idol' audition moves judges to tears
 - [http://www.msn.com/en-us/news/us/texas-school-shooting-survivor-s-american-idol-audition-moves-judges-to-tears/ar-AA182KFo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/texas-school-shooting-survivor-s-american-idol-audition-moves-judges-to-tears/ar-AA182KFo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 17:24:25.569771+00:00



## Nevada Democratic Party chair was convicted on a felony theft charge in the 1990s
 - [http://www.msn.com/en-us/news/politics/nevada-democratic-party-chair-was-convicted-on-a-felony-theft-charge-in-the-1990s/ar-AA1830Iv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/nevada-democratic-party-chair-was-convicted-on-a-felony-theft-charge-in-the-1990s/ar-AA1830Iv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 17:24:25.561434+00:00



## GOP-led Homeland Security panel holds 1st border hearing, highlighting 'human costs'
 - [http://www.msn.com/en-us/news/politics/gop-led-homeland-security-panel-holds-1st-border-hearing-highlighting-human-costs/ar-AA181MlA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-led-homeland-security-panel-holds-1st-border-hearing-highlighting-human-costs/ar-AA181MlA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 16:24:35.382560+00:00



## Fact Check: Does Video Show Ukraine Drone Dropping Grenades on Civilians?
 - [http://www.msn.com/en-us/news/world/fact-check-does-video-show-ukraine-drone-dropping-grenades-on-civilians/ar-AA181Kh0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fact-check-does-video-show-ukraine-drone-dropping-grenades-on-civilians/ar-AA181Kh0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 16:24:35.373821+00:00



## Northern Ireland confronts compromise in post-Brexit deal
 - [http://www.msn.com/en-us/news/world/northern-ireland-confronts-compromise-in-post-brexit-deal/ar-AA181KdH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/northern-ireland-confronts-compromise-in-post-brexit-deal/ar-AA181KdH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 16:24:35.365164+00:00



## Airline issue weather waivers as winter storm moves through the country
 - [http://www.msn.com/en-us/news/us/airline-issue-weather-waivers-as-winter-storm-moves-through-the-country/ar-AA182T45?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/airline-issue-weather-waivers-as-winter-storm-moves-through-the-country/ar-AA182T45?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 16:24:35.357784+00:00



## Twitter, Who? Flipboard Adds Mastodon Features, Pushing Further Into Social Networking
 - [http://www.msn.com/en-us/news/technology/twitter-who-flipboard-adds-mastodon-features-pushing-further-into-social-networking/ar-AA181Kjz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/twitter-who-flipboard-adds-mastodon-features-pushing-further-into-social-networking/ar-AA181Kjz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 16:24:35.350056+00:00



## JetBlue flight and Learjet have 'close call' at Boston Logan International Airport, feds say
 - [http://www.msn.com/en-us/news/us/jetblue-flight-and-learjet-have-close-call-at-boston-logan-international-airport-feds-say/ar-AA182Ebp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jetblue-flight-and-learjet-have-close-call-at-boston-logan-international-airport-feds-say/ar-AA182Ebp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 16:24:35.341040+00:00



## The US military created an illusion of success in Afghanistan by handling tasks it was supposed to train Afghan troops to do, report says
 - [http://www.msn.com/en-us/news/world/the-us-military-created-an-illusion-of-success-in-afghanistan-by-handling-tasks-it-was-supposed-to-train-afghan-troops-to-do-report-says/ar-AA182QDi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-us-military-created-an-illusion-of-success-in-afghanistan-by-handling-tasks-it-was-supposed-to-train-afghan-troops-to-do-report-says/ar-AA182QDi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 16:24:35.333331+00:00



## Buttigieg pushes back on McConnell criticism of ‘woke initiatives’
 - [http://www.msn.com/en-us/news/politics/buttigieg-pushes-back-on-mcconnell-criticism-of-woke-initiatives/ar-AA182MN7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/buttigieg-pushes-back-on-mcconnell-criticism-of-woke-initiatives/ar-AA182MN7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 16:24:35.326018+00:00



## Social Security could be reshaped as bipartisan group of senators considers increasing age requirement
 - [http://www.msn.com/en-us/news/politics/social-security-could-be-reshaped-as-bipartisan-group-of-senators-considers-increasing-age-requirement/ar-AA182zpX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/social-security-could-be-reshaped-as-bipartisan-group-of-senators-considers-increasing-age-requirement/ar-AA182zpX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 15:24:27.100166+00:00



## What We Know About the U.S. Intelligence Community's Split on COVID-19 Origins
 - [http://www.msn.com/en-us/news/us/what-we-know-about-the-u-s-intelligence-community-s-split-on-covid-19-origins/ar-AA1827AZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-we-know-about-the-u-s-intelligence-community-s-split-on-covid-19-origins/ar-AA1827AZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 15:24:27.092921+00:00



## Marjorie Taylor Greene claims she was 'attacked' in a restaurant
 - [http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-claims-she-was-attacked-in-a-restaurant/ar-AA182woW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-claims-she-was-attacked-in-a-restaurant/ar-AA182woW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 15:24:27.083239+00:00



## Catch up on all the zaniest moments of the Chicago mayor’s race
 - [http://www.msn.com/en-us/news/politics/catch-up-on-all-the-zaniest-moments-of-the-chicago-mayor-s-race/ar-AA182No5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/catch-up-on-all-the-zaniest-moments-of-the-chicago-mayor-s-race/ar-AA182No5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 15:24:27.075215+00:00



## What to make of China’s ‘Peace Plan’ for Ukraine
 - [http://www.msn.com/en-us/news/world/what-to-make-of-china-s-peace-plan-for-ukraine/ar-AA182slm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/what-to-make-of-china-s-peace-plan-for-ukraine/ar-AA182slm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 15:24:27.067452+00:00



## Joe Biden's Miserable Record Doesn't Bode Well for Student Loan Forgiveness
 - [http://www.msn.com/en-us/news/politics/joe-biden-s-miserable-record-doesn-t-bode-well-for-student-loan-forgiveness/ar-AA182n7p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/joe-biden-s-miserable-record-doesn-t-bode-well-for-student-loan-forgiveness/ar-AA182n7p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 15:24:27.059240+00:00



## New details revealed in shootings that killed 3, including reporter
 - [http://www.msn.com/en-us/news/crime/new-details-revealed-in-shootings-that-killed-3-including-reporter/ar-AA182n3H?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/new-details-revealed-in-shootings-that-killed-3-including-reporter/ar-AA182n3H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 15:24:27.052017+00:00



## US Navy changes the name of a missile cruiser, no longer honoring a major Confederate victory in the Civil War
 - [http://www.msn.com/en-us/news/us/us-navy-changes-the-name-of-a-missile-cruiser-no-longer-honoring-a-major-confederate-victory-in-the-civil-war/ar-AA182BD0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/us-navy-changes-the-name-of-a-missile-cruiser-no-longer-honoring-a-major-confederate-victory-in-the-civil-war/ar-AA182BD0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 15:24:27.044495+00:00



## Suspect in Florida TV crew attack faces more murder charges
 - [http://www.msn.com/en-us/news/crime/suspect-in-florida-tv-crew-attack-faces-more-murder-charges/ar-AA182w1y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/suspect-in-florida-tv-crew-attack-faces-more-murder-charges/ar-AA182w1y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 14:24:26.686964+00:00



## Opposition calls for Nigeria poll to be scrapped
 - [http://www.msn.com/en-us/news/world/opposition-calls-for-nigeria-poll-to-be-scrapped/ar-AA182r8J?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/opposition-calls-for-nigeria-poll-to-be-scrapped/ar-AA182r8J?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 14:24:26.679786+00:00



## Biden defeats Republicans in hypothetical matchup but Trump still tops field: Poll
 - [http://www.msn.com/en-us/news/politics/biden-defeats-republicans-in-hypothetical-matchup-but-trump-still-tops-field-poll/ar-AA18255r?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-defeats-republicans-in-hypothetical-matchup-but-trump-still-tops-field-poll/ar-AA18255r?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 14:24:26.671966+00:00



## Russian father had his daughter taken away after she drew an anti-war picture in art class, reports say
 - [http://www.msn.com/en-us/news/world/russian-father-had-his-daughter-taken-away-after-she-drew-an-anti-war-picture-in-art-class-reports-say/ar-AA182jHe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-father-had-his-daughter-taken-away-after-she-drew-an-anti-war-picture-in-art-class-reports-say/ar-AA182jHe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 14:24:26.662440+00:00



## A view from Crimea, the Russian-annexed territory Ukraine is hoping to seize back
 - [http://www.msn.com/en-us/news/world/a-view-from-crimea-the-russian-annexed-territory-ukraine-is-hoping-to-seize-back/ar-AA182bpR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-view-from-crimea-the-russian-annexed-territory-ukraine-is-hoping-to-seize-back/ar-AA182bpR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 14:24:26.645533+00:00



## Buttigieg says he ‘welcomes’ review of his use of government jet
 - [http://www.msn.com/en-us/news/politics/buttigieg-says-he-welcomes-review-of-his-use-of-government-jet/ar-AA182y8q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/buttigieg-says-he-welcomes-review-of-his-use-of-government-jet/ar-AA182y8q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 14:24:26.637746+00:00



## Microsoft's New Phone Link for iPhone Brings Messages, Calls and Notifications to Windows 11
 - [http://www.msn.com/en-us/news/technology/microsoft-s-new-phone-link-for-iphone-brings-messages-calls-and-notifications-to-windows-11/ar-AA182jTQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/microsoft-s-new-phone-link-for-iphone-brings-messages-calls-and-notifications-to-windows-11/ar-AA182jTQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 14:24:26.630388+00:00



## Flurry of drone strikes hits inside Russia as TV and radio are hacked
 - [http://www.msn.com/en-us/news/world/flurry-of-drone-strikes-hits-inside-russia-as-tv-and-radio-are-hacked/ar-AA182Avr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/flurry-of-drone-strikes-hits-inside-russia-as-tv-and-radio-are-hacked/ar-AA182Avr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 14:24:26.622286+00:00



## 11-year-old rips sexually explicit material in his Maine middle school: 'The librarian asked if I wanted more'
 - [http://www.msn.com/en-us/news/us/11-year-old-rips-sexually-explicit-material-in-his-maine-middle-school-the-librarian-asked-if-i-wanted-more/ar-AA182cy7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/11-year-old-rips-sexually-explicit-material-in-his-maine-middle-school-the-librarian-asked-if-i-wanted-more/ar-AA182cy7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 13:24:16.991247+00:00



## Only Trump beats Biden — DeSantis, Haley would lose: Poll
 - [http://www.msn.com/en-us/news/politics/only-trump-beats-biden-desantis-haley-would-lose-poll/ar-AA181J4o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/only-trump-beats-biden-desantis-haley-would-lose-poll/ar-AA181J4o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 13:24:16.982894+00:00



## Congressional 'Gang of 8' to get long-awaited briefing on Trump, Biden and Pence docs
 - [http://www.msn.com/en-us/news/politics/congressional-gang-of-8-to-get-long-awaited-briefing-on-trump-biden-and-pence-docs/ar-AA182gUA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/congressional-gang-of-8-to-get-long-awaited-briefing-on-trump-biden-and-pence-docs/ar-AA182gUA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 13:24:16.974839+00:00



## Marjorie Taylor Greene says she was ‘attacked’ by ‘insane’ woman in restaurant
 - [http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-says-she-was-attacked-by-insane-woman-in-restaurant/ar-AA182cLs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-says-she-was-attacked-by-insane-woman-in-restaurant/ar-AA182cLs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 13:24:16.965512+00:00



## Ultranationalist ally of Netanyahu quits as deputy minister in Israeli government
 - [http://www.msn.com/en-us/news/world/ultranationalist-ally-of-netanyahu-quits-as-deputy-minister-in-israeli-government/ar-AA182vk5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ultranationalist-ally-of-netanyahu-quits-as-deputy-minister-in-israeli-government/ar-AA182vk5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 13:24:16.958552+00:00



## Armed Waffle House Customer Pays for Meal, Tips Waitress Then Robs It-Cops
 - [http://www.msn.com/en-us/news/crime/armed-waffle-house-customer-pays-for-meal-tips-waitress-then-robs-it-cops/ar-AA1829MS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/armed-waffle-house-customer-pays-for-meal-tips-waitress-then-robs-it-cops/ar-AA1829MS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 13:24:16.951775+00:00



## Flurry of drone strikes hits Russia as TV, radio are hacked
 - [http://www.msn.com/en-us/news/world/flurry-of-drone-strikes-hits-russia-as-tv-radio-are-hacked/ar-AA182eBm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/flurry-of-drone-strikes-hits-russia-as-tv-radio-are-hacked/ar-AA182eBm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 13:24:16.942869+00:00



## Drones Attack Russia From All Sides
 - [http://www.msn.com/en-us/news/world/drones-attack-russia-from-all-sides/ar-AA182g7z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/drones-attack-russia-from-all-sides/ar-AA182g7z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 12:24:15.209520+00:00



## Ron DeSantis is breaking Democrats' brains
 - [http://www.msn.com/en-us/news/politics/ron-desantis-is-breaking-democrats-brains/ar-AA180eEo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ron-desantis-is-breaking-democrats-brains/ar-AA180eEo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 12:24:15.202228+00:00



## Italy: Migrants paid 8,000 euros each for 'voyage of death'
 - [http://www.msn.com/en-us/news/world/italy-migrants-paid-8-000-euros-each-for-voyage-of-death/ar-AA18222U?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/italy-migrants-paid-8-000-euros-each-for-voyage-of-death/ar-AA18222U?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 12:24:15.194910+00:00



## Ohio train derailment: Buttigieg urges Norfolk Southern to join close call system
 - [http://www.msn.com/en-us/news/us/ohio-train-derailment-buttigieg-urges-norfolk-southern-to-join-close-call-system/ar-AA182gfV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/ohio-train-derailment-buttigieg-urges-norfolk-southern-to-join-close-call-system/ar-AA182gfV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 12:24:15.187321+00:00



## Our military leaders need a national security ‘fast lane’ to compete with China
 - [http://www.msn.com/en-us/news/politics/our-military-leaders-need-a-national-security-fast-lane-to-compete-with-china/ar-AA181ZWz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/our-military-leaders-need-a-national-security-fast-lane-to-compete-with-china/ar-AA181ZWz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 12:24:15.179629+00:00



## Marking TIME's Centennial With the Man Who Knows Its History Best
 - [http://www.msn.com/en-us/news/us/marking-time-s-centennial-with-the-man-who-knows-its-history-best/ar-AA182dLL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/marking-time-s-centennial-with-the-man-who-knows-its-history-best/ar-AA182dLL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 12:24:15.172353+00:00



## China must be ‘more honest’ on Covid origins, U.S. ambassador says
 - [http://www.msn.com/en-us/news/world/china-must-be-more-honest-on-covid-origins-u-s-ambassador-says/ar-AA181ILN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-must-be-more-honest-on-covid-origins-u-s-ambassador-says/ar-AA181ILN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 12:24:15.164981+00:00



## 'Lady in the fridge' is identified nearly 3 decades after she was found in California
 - [http://www.msn.com/en-us/news/crime/lady-in-the-fridge-is-identified-nearly-3-decades-after-she-was-found-in-california/ar-AA182c7n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/lady-in-the-fridge-is-identified-nearly-3-decades-after-she-was-found-in-california/ar-AA182c7n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 12:24:15.156918+00:00



## Classified document fallout swirls around nomination hearing for national archivist
 - [http://www.msn.com/en-us/news/politics/classified-document-fallout-swirls-around-nomination-hearing-for-national-archivist/ar-AA181QEM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/classified-document-fallout-swirls-around-nomination-hearing-for-national-archivist/ar-AA181QEM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 11:24:16.373460+00:00



## Commerce Dept. issuing aid to build computer chip plants
 - [http://www.msn.com/en-us/news/politics/commerce-dept-issuing-aid-to-build-computer-chip-plants/ar-AA181QXX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/commerce-dept-issuing-aid-to-build-computer-chip-plants/ar-AA181QXX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 11:24:16.365996+00:00



## Hong Kong police hunt for evidence in case of slain and dismembered model
 - [http://www.msn.com/en-us/news/crime/hong-kong-police-hunt-for-evidence-in-case-of-slain-and-dismembered-model/ar-AA1820Wk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/hong-kong-police-hunt-for-evidence-in-case-of-slain-and-dismembered-model/ar-AA1820Wk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 11:24:16.357948+00:00



## Missing Man Found in Shark's Stomach Identified by His Tattoos
 - [http://www.msn.com/en-us/news/world/missing-man-found-in-shark-s-stomach-identified-by-his-tattoos/ar-AA181IuH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/missing-man-found-in-shark-s-stomach-identified-by-his-tattoos/ar-AA181IuH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 11:24:16.350976+00:00



## Love Annihilated
 - [http://www.msn.com/en-us/news/world/love-annihilated/ar-AA181RoN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/love-annihilated/ar-AA181RoN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 11:24:16.344013+00:00



## The Supreme Court and Biden's Student Debt Forgiveness Plan. What You Need to Know
 - [http://www.msn.com/en-us/news/technology/the-supreme-court-and-biden-s-student-debt-forgiveness-plan-what-you-need-to-know/ar-AA17Z7BD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-supreme-court-and-biden-s-student-debt-forgiveness-plan-what-you-need-to-know/ar-AA17Z7BD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 11:24:16.336412+00:00



## As Russian forces bear down on Bakhmut, Ukraine admits situation there is 'more and more difficult'
 - [http://www.msn.com/en-us/news/world/as-russian-forces-bear-down-on-bakhmut-ukraine-admits-situation-there-is-more-and-more-difficult/ar-AA182cZ8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/as-russian-forces-bear-down-on-bakhmut-ukraine-admits-situation-there-is-more-and-more-difficult/ar-AA182cZ8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 11:24:16.328275+00:00



## Arrest warrant issued for Kodak Black, rapper once pardoned by Trump
 - [http://www.msn.com/en-us/news/us/arrest-warrant-issued-for-kodak-black-rapper-once-pardoned-by-trump/ar-AA182aMm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/arrest-warrant-issued-for-kodak-black-rapper-once-pardoned-by-trump/ar-AA182aMm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 11:24:16.320406+00:00



## Marjorie Taylor Greene Votes Against Mourning Turkey Earthquake Victims
 - [http://www.msn.com/en-us/news/world/marjorie-taylor-greene-votes-against-mourning-turkey-earthquake-victims/ar-AA181BEo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/marjorie-taylor-greene-votes-against-mourning-turkey-earthquake-victims/ar-AA181BEo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 10:24:15.261651+00:00



## Republicans start to hit back against Biden's Social Security and Medicare attacks
 - [http://www.msn.com/en-us/news/politics/republicans-start-to-hit-back-against-biden-s-social-security-and-medicare-attacks/ar-AA181Qk2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-start-to-hit-back-against-biden-s-social-security-and-medicare-attacks/ar-AA181Qk2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 10:24:15.254242+00:00



## We Have a Real UFO Problem. And It’s Not Balloons
 - [http://www.msn.com/en-us/news/technology/we-have-a-real-ufo-problem-and-it-s-not-balloons/ar-AA181NGz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/we-have-a-real-ufo-problem-and-it-s-not-balloons/ar-AA181NGz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 10:24:15.246930+00:00



## Feds Inadvertently Reveal They’re Looking Into Trump’s Shady ‘Recount’ Campaign
 - [http://www.msn.com/en-us/news/politics/feds-inadvertently-reveal-they-re-looking-into-trump-s-shady-recount-campaign/ar-AA181LXd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/feds-inadvertently-reveal-they-re-looking-into-trump-s-shady-recount-campaign/ar-AA181LXd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 10:24:15.239180+00:00



## Biden to go on offensive against Republicans over budget fight in Virginia speech
 - [http://www.msn.com/en-us/news/politics/biden-to-go-on-offensive-against-republicans-over-budget-fight-in-virginia-speech/ar-AA181Qs1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-to-go-on-offensive-against-republicans-over-budget-fight-in-virginia-speech/ar-AA181Qs1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 10:24:15.231874+00:00



## New TikTok ban is poised to advance in Congress
 - [http://www.msn.com/en-us/news/politics/new-tiktok-ban-is-poised-to-advance-in-congress/ar-AA1820cR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/new-tiktok-ban-is-poised-to-advance-in-congress/ar-AA1820cR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 10:24:15.224051+00:00



## Danish parliament urges to remove TikTok over cybersecurity
 - [http://www.msn.com/en-us/news/world/danish-parliament-urges-to-remove-tiktok-over-cybersecurity/ar-AA181W2Z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/danish-parliament-urges-to-remove-tiktok-over-cybersecurity/ar-AA181W2Z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 10:24:15.216498+00:00



## Today's Wordle #619 Answer, Hints and Tips for Tuesday, February 28 Enigma
 - [http://www.msn.com/en-us/news/technology/today-s-wordle-619-answer-hints-and-tips-for-tuesday-february-28-enigma/ar-AA181NeP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/today-s-wordle-619-answer-hints-and-tips-for-tuesday-february-28-enigma/ar-AA181NeP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 09:24:13.875692+00:00



## After losing billions of dollars on the metaverse, Mark Zuckerberg's launching a 'top-level' team at Meta to develop AI products for WhatsApp, Messenger, and Instagram
 - [http://www.msn.com/en-us/news/technology/after-losing-billions-of-dollars-on-the-metaverse-mark-zuckerberg-s-launching-a-top-level-team-at-meta-to-develop-ai-products-for-whatsapp-messenger-and-instagram/ar-AA181HX8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/after-losing-billions-of-dollars-on-the-metaverse-mark-zuckerberg-s-launching-a-top-level-team-at-meta-to-develop-ai-products-for-whatsapp-messenger-and-instagram/ar-AA181HX8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 09:24:13.867859+00:00



## The U.S. and China have a culture clash around their telephone hotline
 - [http://www.msn.com/en-us/news/world/the-u-s-and-china-have-a-culture-clash-around-their-telephone-hotline/ar-AA181HE7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-u-s-and-china-have-a-culture-clash-around-their-telephone-hotline/ar-AA181HE7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 09:24:13.859976+00:00



## A wave of teddy bears flooded a soccer field in Turkey after fans came out in force for kids left orphaned or homeless by the earthquake
 - [http://www.msn.com/en-us/news/world/a-wave-of-teddy-bears-flooded-a-soccer-field-in-turkey-after-fans-came-out-in-force-for-kids-left-orphaned-or-homeless-by-the-earthquake/ar-AA181HZf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-wave-of-teddy-bears-flooded-a-soccer-field-in-turkey-after-fans-came-out-in-force-for-kids-left-orphaned-or-homeless-by-the-earthquake/ar-AA181HZf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 09:24:13.852800+00:00



## Gators in Prospect Park — all in a day’s work for NYC Animal Care and Control field officer
 - [http://www.msn.com/en-us/news/us/gators-in-prospect-park-all-in-a-day-s-work-for-nyc-animal-care-and-control-field-officer/ar-AA181jVg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/gators-in-prospect-park-all-in-a-day-s-work-for-nyc-animal-care-and-control-field-officer/ar-AA181jVg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 09:24:13.845095+00:00



## Ex-etiquette: Be clear with boundaries
 - [http://www.msn.com/en-us/news/us/ex-etiquette-be-clear-with-boundaries/ar-AA181BlS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/ex-etiquette-be-clear-with-boundaries/ar-AA181BlS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 09:24:13.837080+00:00



## House GOP picks permitting reform back up after Manchin bill floundered
 - [http://www.msn.com/en-us/news/politics/house-gop-picks-permitting-reform-back-up-after-manchin-bill-floundered/ar-AA181UQq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-gop-picks-permitting-reform-back-up-after-manchin-bill-floundered/ar-AA181UQq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 09:24:13.829692+00:00



## Japan OKs new budget incl. hefty arms cost to deter China
 - [http://www.msn.com/en-us/news/world/japan-oks-new-budget-incl-hefty-arms-cost-to-deter-china/ar-AA181Sj4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/japan-oks-new-budget-incl-hefty-arms-cost-to-deter-china/ar-AA181Sj4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 09:24:13.822120+00:00



## Police urgently search for ‘at risk’ DJ who suddenly vanished last week
 - [http://www.msn.com/en-us/news/crime/police-urgently-search-for-at-risk-dj-who-suddenly-vanished-last-week/ar-AA181jgv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/police-urgently-search-for-at-risk-dj-who-suddenly-vanished-last-week/ar-AA181jgv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 08:24:12.290879+00:00



## Israeli PM's ultranationalist ally quits as deputy minister
 - [http://www.msn.com/en-us/news/world/israeli-pm-s-ultranationalist-ally-quits-as-deputy-minister/ar-AA181KpZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israeli-pm-s-ultranationalist-ally-quits-as-deputy-minister/ar-AA181KpZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 08:24:12.283833+00:00



## New Jersey man attempted to board plane with handguns, AR-15, Taser, fake US Marshal badge
 - [http://www.msn.com/en-us/news/us/new-jersey-man-attempted-to-board-plane-with-handguns-ar-15-taser-fake-us-marshal-badge/ar-AA181yPd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/new-jersey-man-attempted-to-board-plane-with-handguns-ar-15-taser-fake-us-marshal-badge/ar-AA181yPd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 08:24:11.946090+00:00



## Are we on the brink of creating a machine with a human BRAIN?
 - [http://www.msn.com/en-us/news/technology/are-we-on-the-brink-of-creating-a-machine-with-a-human-brain/ar-AA181oD6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/are-we-on-the-brink-of-creating-a-machine-with-a-human-brain/ar-AA181oD6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 07:24:15.433325+00:00



## Alec Baldwin faces new lawsuit after three Rust crew members claim they suffered 'blast injuries' in shooting
 - [http://www.msn.com/en-us/news/crime/alec-baldwin-faces-new-lawsuit-after-three-rust-crew-members-claim-they-suffered-blast-injuries-in-shooting/ar-AA181vCr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/alec-baldwin-faces-new-lawsuit-after-three-rust-crew-members-claim-they-suffered-blast-injuries-in-shooting/ar-AA181vCr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 07:24:15.426109+00:00



## Turkey aid mission 'overwhelming' said councillor
 - [http://www.msn.com/en-us/news/world/turkey-aid-mission-overwhelming-said-councillor/ar-AA181t8w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/turkey-aid-mission-overwhelming-said-councillor/ar-AA181t8w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 07:24:15.418441+00:00



## Supreme Court will hear arguments in student loan case: What to expect
 - [http://www.msn.com/en-us/news/politics/supreme-court-will-hear-arguments-in-student-loan-case-what-to-expect/ar-AA181iYy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/supreme-court-will-hear-arguments-in-student-loan-case-what-to-expect/ar-AA181iYy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 07:24:15.410827+00:00



## Rupert Murdoch said Sean Hannity was 'privately disgusted' by Donald Trump for weeks after the election: court filing
 - [http://www.msn.com/en-us/news/politics/rupert-murdoch-said-sean-hannity-was-privately-disgusted-by-donald-trump-for-weeks-after-the-election-court-filing/ar-AA181A77?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rupert-murdoch-said-sean-hannity-was-privately-disgusted-by-donald-trump-for-weeks-after-the-election-court-filing/ar-AA181A77?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 07:24:15.403191+00:00



## Sun, wind aplenty, Spain vies to lead EU in green hydrogen
 - [http://www.msn.com/en-us/news/world/sun-wind-aplenty-spain-vies-to-lead-eu-in-green-hydrogen/ar-AA181oS0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/sun-wind-aplenty-spain-vies-to-lead-eu-in-green-hydrogen/ar-AA181oS0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 07:24:15.395694+00:00



## Never forget those who shut down COVID-19 debate to protect China
 - [http://www.msn.com/en-us/news/world/never-forget-those-who-shut-down-covid-19-debate-to-protect-china/ar-AA1816Jq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/never-forget-those-who-shut-down-covid-19-debate-to-protect-china/ar-AA1816Jq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 06:23:59.270331+00:00



## Aussies outraged: Arnott's announce the 'end of double coat Tim Tams'
 - [http://www.msn.com/en-us/news/technology/aussies-outraged-arnott-s-announce-the-end-of-double-coat-tim-tams/ar-AA181721?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/aussies-outraged-arnott-s-announce-the-end-of-double-coat-tim-tams/ar-AA181721?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 06:23:59.262406+00:00



## Kelis Details How Her Car 'Almost Fell off a Cliff' During a Calif. Blizzard with Her Kids
 - [http://www.msn.com/en-us/news/us/kelis-details-how-her-car-almost-fell-off-a-cliff-during-a-calif-blizzard-with-her-kids/ar-AA181lZy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/kelis-details-how-her-car-almost-fell-off-a-cliff-during-a-calif-blizzard-with-her-kids/ar-AA181lZy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 06:23:59.255082+00:00



## LAURA INGRAHAM: Worry within the Democratic party is building
 - [http://www.msn.com/en-us/news/politics/laura-ingraham-worry-within-the-democratic-party-is-building/ar-AA181h7R?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/laura-ingraham-worry-within-the-democratic-party-is-building/ar-AA181h7R?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 06:23:59.247292+00:00



## The Mobile Industry Is Increasingly Powered by Renewable Energy
 - [http://www.msn.com/en-us/news/technology/the-mobile-industry-is-increasingly-powered-by-renewable-energy/ar-AA181meq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-mobile-industry-is-increasingly-powered-by-renewable-energy/ar-AA181meq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 06:23:59.240114+00:00



## Police look for evidence for slain Hong Kong model’s case
 - [http://www.msn.com/en-us/news/world/police-look-for-evidence-for-slain-hong-kong-model-s-case/ar-AA181hgH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/police-look-for-evidence-for-slain-hong-kong-model-s-case/ar-AA181hgH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 06:23:59.231082+00:00



## Alec Baldwin hit with new 'Rust' lawsuit by three crew members who suffered 'blast injuries'
 - [http://www.msn.com/en-us/news/crime/alec-baldwin-hit-with-new-rust-lawsuit-by-three-crew-members-who-suffered-blast-injuries/ar-AA181mXI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/alec-baldwin-hit-with-new-rust-lawsuit-by-three-crew-members-who-suffered-blast-injuries/ar-AA181mXI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 05:24:03.632425+00:00



## White House Says U.S. Not Ready to Reach Consensus on Covid Origins
 - [http://www.msn.com/en-us/news/politics/white-house-says-u-s-not-ready-to-reach-consensus-on-covid-origins/vi-AA181s9M?srcref=rss](http://www.msn.com/en-us/news/politics/white-house-says-u-s-not-ready-to-reach-consensus-on-covid-origins/vi-AA181s9M?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 05:24:03.623709+00:00



## Lottery says $2B Powerball winner is legitimate, amid claim ticket was stolen
 - [http://www.msn.com/en-us/news/us/lottery-says-2b-powerball-winner-is-legitimate-amid-claim-ticket-was-stolen/ar-AA181pzT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/lottery-says-2b-powerball-winner-is-legitimate-amid-claim-ticket-was-stolen/ar-AA181pzT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 05:24:03.616434+00:00



## Fox hosts endorsed false election claims - Murdoch
 - [http://www.msn.com/en-us/news/world/fox-hosts-endorsed-false-election-claims-murdoch/ar-AA181gq1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fox-hosts-endorsed-false-election-claims-murdoch/ar-AA181gq1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 05:24:03.609078+00:00



## 'They turned into demons': MTG claims she was 'attacked' in a restaurant
 - [http://www.msn.com/en-us/news/politics/they-turned-into-demons-mtg-claims-she-was-attacked-in-a-restaurant/ar-AA181npq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/they-turned-into-demons-mtg-claims-she-was-attacked-in-a-restaurant/ar-AA181npq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 05:24:03.601830+00:00



## Alec Baldwin, Rust Producers Sued by Three Crew Members Dealing with Anxiety, Depression, PTSD
 - [http://www.msn.com/en-us/news/crime/alec-baldwin-rust-producers-sued-by-three-crew-members-dealing-with-anxiety-depression-ptsd/ar-AA181gwA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/alec-baldwin-rust-producers-sued-by-three-crew-members-dealing-with-anxiety-depression-ptsd/ar-AA181gwA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 05:24:03.593717+00:00



## Supreme Court weighs Biden student loan plan worth billions
 - [http://www.msn.com/en-us/news/us/supreme-court-weighs-biden-student-loan-plan-worth-billions/ar-AA181nyJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/supreme-court-weighs-biden-student-loan-plan-worth-billions/ar-AA181nyJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 05:24:03.584921+00:00



## US attaches childcare strings to chip-maker subsidies
 - [http://www.msn.com/en-us/news/world/us-attaches-childcare-strings-to-chip-maker-subsidies/ar-AA18162W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-attaches-childcare-strings-to-chip-maker-subsidies/ar-AA18162W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 04:23:56.573377+00:00



## WGA asks members to vote on key demands in bargaining with studios
 - [http://www.msn.com/en-us/news/world/wga-asks-members-to-vote-on-key-demands-in-bargaining-with-studios/ar-AA181g1E?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/wga-asks-members-to-vote-on-key-demands-in-bargaining-with-studios/ar-AA181g1E?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 04:23:56.566152+00:00



## Transportation Department watchdog to audit Buttigieg's use of government aircraft
 - [http://www.msn.com/en-us/news/politics/transportation-department-watchdog-to-audit-buttigieg-s-use-of-government-aircraft/ar-AA1816js?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/transportation-department-watchdog-to-audit-buttigieg-s-use-of-government-aircraft/ar-AA1816js?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 04:23:56.558205+00:00



## WrestleMania 2023: Match Card, How to Watch, Start Times
 - [http://www.msn.com/en-us/news/technology/wrestlemania-2023-match-card-how-to-watch-start-times/ar-AA181dzX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/wrestlemania-2023-match-card-how-to-watch-start-times/ar-AA181dzX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 04:23:56.550182+00:00



## Tennessee Abortion Ban a ‘Nightmare’ for Woman With Doomed Pregnancy
 - [http://www.msn.com/en-us/news/us/tennessee-abortion-ban-a-nightmare-for-woman-with-doomed-pregnancy/ar-AA1819jd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tennessee-abortion-ban-a-nightmare-for-woman-with-doomed-pregnancy/ar-AA1819jd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 04:23:56.542601+00:00



## Kevin McCarthy raises money off Liz Cheney's possible 2024 White House bid
 - [http://www.msn.com/en-us/news/politics/kevin-mccarthy-raises-money-off-liz-cheney-s-possible-2024-white-house-bid/ar-AA180W8N?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kevin-mccarthy-raises-money-off-liz-cheney-s-possible-2024-white-house-bid/ar-AA180W8N?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 03:23:58.273065+00:00



## Two missing Maine women discovered alive in their Jeep - after getting stuck in the snow for 5 DAYS
 - [http://www.msn.com/en-us/news/crime/two-missing-maine-women-discovered-alive-in-their-jeep-after-getting-stuck-in-the-snow-for-5-days/ar-AA1818Np?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/two-missing-maine-women-discovered-alive-in-their-jeep-after-getting-stuck-in-the-snow-for-5-days/ar-AA1818Np?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 03:23:58.263781+00:00



## George Santos Deserves Expulsion, Fellow New York Republican Says
 - [http://www.msn.com/en-us/news/politics/george-santos-deserves-expulsion-fellow-new-york-republican-says/ar-AA181fAF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/george-santos-deserves-expulsion-fellow-new-york-republican-says/ar-AA181fAF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 03:23:58.256092+00:00



## Joaquin Castro undergoes surgery for cancer
 - [http://www.msn.com/en-us/news/politics/joaquin-castro-undergoes-surgery-for-cancer/ar-AA180Bjz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/joaquin-castro-undergoes-surgery-for-cancer/ar-AA180Bjz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 03:23:58.248829+00:00



## Pennsylvania district considers bringing 'feelings' into math curriculum as some community members balk
 - [http://www.msn.com/en-us/news/us/pennsylvania-district-considers-bringing-feelings-into-math-curriculum-as-some-community-members-balk/ar-AA181djF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/pennsylvania-district-considers-bringing-feelings-into-math-curriculum-as-some-community-members-balk/ar-AA181djF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 03:23:58.241198+00:00



## India revives civil militia after Hindu killings in Kashmir
 - [http://www.msn.com/en-us/news/world/india-revives-civil-militia-after-hindu-killings-in-kashmir/ar-AA180Mtl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/india-revives-civil-militia-after-hindu-killings-in-kashmir/ar-AA180Mtl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 03:23:58.233275+00:00



## 'Serious ethical baggage': NRCC blasts Democrat running for Senate
 - [http://www.msn.com/en-us/news/politics/serious-ethical-baggage-nrcc-blasts-democrat-running-for-senate/ar-AA1813CO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/serious-ethical-baggage-nrcc-blasts-democrat-running-for-senate/ar-AA1813CO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 02:23:58.994574+00:00



## North Korea's Kim calls for unity to boost grain production
 - [http://www.msn.com/en-us/news/world/north-korea-s-kim-calls-for-unity-to-boost-grain-production/ar-AA180RaV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/north-korea-s-kim-calls-for-unity-to-boost-grain-production/ar-AA180RaV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 02:23:58.987701+00:00



## Honors Student, 17, Killed After Offering Teenagers a Ride: 'Thought He Was Doing the Right Thing'
 - [http://www.msn.com/en-us/news/crime/honors-student-17-killed-after-offering-teenagers-a-ride-thought-he-was-doing-the-right-thing/ar-AA180LSX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/honors-student-17-killed-after-offering-teenagers-a-ride-thought-he-was-doing-the-right-thing/ar-AA180LSX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 02:23:58.980749+00:00



## House holds moment of silence to honor victims of Michigan State shooting
 - [http://www.msn.com/en-us/news/politics/house-holds-moment-of-silence-to-honor-victims-of-michigan-state-shooting/ar-AA180VPx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-holds-moment-of-silence-to-honor-victims-of-michigan-state-shooting/ar-AA180VPx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 02:23:58.973651+00:00



## Bill to defang N.J. campaign finance watchdog stalls
 - [http://www.msn.com/en-us/news/politics/bill-to-defang-n-j-campaign-finance-watchdog-stalls/ar-AA180VQ7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bill-to-defang-n-j-campaign-finance-watchdog-stalls/ar-AA180VQ7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 02:23:58.965784+00:00



## 'Lady in the fridge' is identified nearly 3 decades after she was found in California
 - [http://www.msn.com/en-us/news/crime/lady-in-the-fridge-is-identified-nearly-3-decades-after-she-was-found-in-california/ar-AA180Ys2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/lady-in-the-fridge-is-identified-nearly-3-decades-after-she-was-found-in-california/ar-AA180Ys2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 02:23:58.958747+00:00



## CBP releases, ICE later arrests Brazilian fugitive wanted for murder who illegally entered the US
 - [http://www.msn.com/en-us/news/crime/cbp-releases-ice-later-arrests-brazilian-fugitive-wanted-for-murder-who-illegally-entered-the-us/ar-AA1810Y8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/cbp-releases-ice-later-arrests-brazilian-fugitive-wanted-for-murder-who-illegally-entered-the-us/ar-AA1810Y8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 02:23:58.949511+00:00



## Biden admin gives federal agencies 30 days to ban TikTok
 - [http://www.msn.com/en-us/news/politics/biden-admin-gives-federal-agencies-30-days-to-ban-tiktok/ar-AA1813Sn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-admin-gives-federal-agencies-30-days-to-ban-tiktok/ar-AA1813Sn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 02:23:58.941586+00:00



## One House Republican's unique anti-Santos pitch: Block him from profiting off his lies
 - [http://www.msn.com/en-us/news/politics/one-house-republican-s-unique-anti-santos-pitch-block-him-from-profiting-off-his-lies/ar-AA180O5I?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/one-house-republican-s-unique-anti-santos-pitch-block-him-from-profiting-off-his-lies/ar-AA180O5I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 01:23:56.972295+00:00



## San Francisco DJ 'JV' missing for days and is 'at-risk', police and station say
 - [http://www.msn.com/en-us/news/crime/san-francisco-dj-jv-missing-for-days-and-is-at-risk-police-and-station-say/ar-AA1812X0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/san-francisco-dj-jv-missing-for-days-and-is-at-risk-police-and-station-say/ar-AA1812X0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 01:23:56.965295+00:00



## New warning about the 'dire' impact of the 'climate crisis' on nursing homes
 - [http://www.msn.com/en-us/news/us/new-warning-about-the-dire-impact-of-the-climate-crisis-on-nursing-homes/ar-AA18131x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/new-warning-about-the-dire-impact-of-the-climate-crisis-on-nursing-homes/ar-AA18131x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 01:23:56.958319+00:00



## Rupert Murdoch Reveals Which Fox News Hosts 'Endorsed' Election Fraud
 - [http://www.msn.com/en-us/news/politics/rupert-murdoch-reveals-which-fox-news-hosts-endorsed-election-fraud/ar-AA18139N?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rupert-murdoch-reveals-which-fox-news-hosts-endorsed-election-fraud/ar-AA18139N?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 01:23:56.950491+00:00



## Paramedic issues warning over innocent summer item fatal for parents
 - [http://www.msn.com/en-us/news/world/paramedic-issues-warning-over-innocent-summer-item-fatal-for-parents/ar-AA1815jW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/paramedic-issues-warning-over-innocent-summer-item-fatal-for-parents/ar-AA1815jW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 01:23:56.943054+00:00



## White House: No more TikTok on gov't devices within 30 days
 - [http://www.msn.com/en-us/news/politics/white-house-no-more-tiktok-on-gov-t-devices-within-30-days/ar-AA1810kv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/white-house-no-more-tiktok-on-gov-t-devices-within-30-days/ar-AA1810kv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 01:23:56.935502+00:00



## Missing Levi case probed by Spanish crime unit
 - [http://www.msn.com/en-us/news/world/missing-levi-case-probed-by-spanish-crime-unit/ar-AA180Sp8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/missing-levi-case-probed-by-spanish-crime-unit/ar-AA180Sp8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 01:23:56.927721+00:00



## Trump officials complained to Disney about Jimmy Kimmel jokes on ABC: report
 - [http://www.msn.com/en-us/news/politics/trump-officials-complained-to-disney-about-jimmy-kimmel-jokes-on-abc-report/ar-AA180Vwb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-officials-complained-to-disney-about-jimmy-kimmel-jokes-on-abc-report/ar-AA180Vwb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 01:23:56.919285+00:00



## U.S. Marshals Service suffers 'major' security breach that compromises sensitive info
 - [http://www.msn.com/en-us/news/politics/u-s-marshals-service-suffers-major-security-breach-that-compromises-sensitive-info/ar-AA180JjI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/u-s-marshals-service-suffers-major-security-breach-that-compromises-sensitive-info/ar-AA180JjI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 00:20:31.053384+00:00



## Grandfather of pilot killed in Nevada crash flew WWII planes
 - [http://www.msn.com/en-us/news/us/grandfather-of-pilot-killed-in-nevada-crash-flew-wwii-planes/ar-AA180Jkb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/grandfather-of-pilot-killed-in-nevada-crash-flew-wwii-planes/ar-AA180Jkb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 00:20:31.046367+00:00



## To Save Ukraine, Defeat Russia and Deter China
 - [http://www.msn.com/en-us/news/world/to-save-ukraine-defeat-russia-and-deter-china/ar-AA180ZV5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/to-save-ukraine-defeat-russia-and-deter-china/ar-AA180ZV5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 00:20:31.038893+00:00



## Vermont woman escapes kidnappers by driving off in their truck with hands bound, face covered, police say
 - [http://www.msn.com/en-us/news/crime/vermont-woman-escapes-kidnappers-by-driving-off-in-their-truck-with-hands-bound-face-covered-police-say/ar-AA180QaM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/vermont-woman-escapes-kidnappers-by-driving-off-in-their-truck-with-hands-bound-face-covered-police-say/ar-AA180QaM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 00:20:31.031478+00:00



## China Panics in Email Over U.S. Delegation’s Trip to Taiwan
 - [http://www.msn.com/en-us/news/world/china-panics-in-email-over-u-s-delegation-s-trip-to-taiwan/ar-AA180ZVT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-panics-in-email-over-u-s-delegation-s-trip-to-taiwan/ar-AA180ZVT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 00:20:31.020502+00:00



## Rupert Murdoch says Fox hosts 'endorsed' election claims, court filing says
 - [http://www.msn.com/en-us/news/politics/rupert-murdoch-says-fox-hosts-endorsed-election-claims-court-filing-says/ar-AA180INj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rupert-murdoch-says-fox-hosts-endorsed-election-claims-court-filing-says/ar-AA180INj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 00:20:31.003778+00:00



## DeSantis accuses congressional Republicans of 'flagrantly' ignoring voters on immigration, leading to Trump election: Book
 - [http://www.msn.com/en-us/news/politics/desantis-accuses-congressional-republicans-of-flagrantly-ignoring-voters-on-immigration-leading-to-trump-election-book/ar-AA180Qj0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/desantis-accuses-congressional-republicans-of-flagrantly-ignoring-voters-on-immigration-leading-to-trump-election-book/ar-AA180Qj0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 00:20:30.991250+00:00



## Musk pledges ‘very significant’ stock awards to remaining Twitter staffers after layoffs
 - [http://www.msn.com/en-us/news/politics/musk-pledges-very-significant-stock-awards-to-remaining-twitter-staffers-after-layoffs/ar-AA180Jw2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/musk-pledges-very-significant-stock-awards-to-remaining-twitter-staffers-after-layoffs/ar-AA180Jw2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-28 00:20:30.795440+00:00



