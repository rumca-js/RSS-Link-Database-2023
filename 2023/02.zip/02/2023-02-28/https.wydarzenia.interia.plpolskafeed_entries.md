# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Sprawa Włodzimierza Karpińskiego. Były minister trafi do aresztu
 - [https://wydarzenia.interia.pl/kraj/news-sprawa-wlodzimierza-karpinskiego-byly-minister-trafi-do-ares,nId,6625422](https://wydarzenia.interia.pl/kraj/news-sprawa-wlodzimierza-karpinskiego-byly-minister-trafi-do-ares,nId,6625422)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-02-28 15:49:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sprawa-wlodzimierza-karpinskiego-byly-minister-trafi-do-ares,nId,6625422"><img align="left" alt="Sprawa Włodzimierza Karpińskiego. Były minister trafi do aresztu" src="https://i.iplsc.com/sprawa-wlodzimierza-karpinskiego-byly-minister-trafi-do-ares/000GTMTNU8IW0AHL-C321.jpg" /></a>Na 90 dni trafi do aresztu trafi Włodzimierz Karpiński, były minister skarbu w rządzie PO - zdecydował Sąd Rejonowy Katowice-Wschód. Byłemu politykowi postawiono zarzut dotyczący żądania i przyjęcia korzyści majątkowej.
</p><br clear="all" />

## Tusk: Energetyka jądrowa jest dzisiaj bezalternatywna
 - [https://wydarzenia.interia.pl/kraj/news-tusk-energetyka-jadrowa-jest-dzisiaj-bezalternatywna,nId,6625724](https://wydarzenia.interia.pl/kraj/news-tusk-energetyka-jadrowa-jest-dzisiaj-bezalternatywna,nId,6625724)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-02-28 13:20:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-energetyka-jadrowa-jest-dzisiaj-bezalternatywna,nId,6625724"><img align="left" alt="Tusk: Energetyka jądrowa jest dzisiaj bezalternatywna" src="https://i.iplsc.com/tusk-energetyka-jadrowa-jest-dzisiaj-bezalternatywna/000GTOXEBS31VFG1-C321.jpg" /></a>We wtorek Donald Tusk zorganizował spotkanie otwarte w Łodzi, gdzie odpowiadał na pytania młodzieży. Odpowiadał między innymi ws. energetyki jądrowej. - Dzisiaj, przynajmniej częściowo, jest bezalternatywna - ocenił szef PO.</p><br clear="all" />

## 1400 Borsuków dla Polski. Mariusz Błaszczak podpisał umowę
 - [https://wydarzenia.interia.pl/kraj/news-1400-borsukow-dla-polski-mariusz-blaszczak-podpisal-umowe,nId,6625633](https://wydarzenia.interia.pl/kraj/news-1400-borsukow-dla-polski-mariusz-blaszczak-podpisal-umowe,nId,6625633)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-02-28 11:25:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-1400-borsukow-dla-polski-mariusz-blaszczak-podpisal-umowe,nId,6625633"><img align="left" alt="1400 Borsuków dla Polski. Mariusz Błaszczak podpisał umowę" src="https://i.iplsc.com/1400-borsukow-dla-polski-mariusz-blaszczak-podpisal-umowe/000GTOH2JK7C5NWJ-C321.jpg" /></a>Wicepremier i szef resortu obrony Mariusz Błaszczak podpisał umowę ramową na dostawy bojowych wozów piechoty Borsuk. Umowa zawarta została między Agencją Uzbrojenia a konsorcjum Polska Grupa Zbrojeniowa oraz Hutą Stalowa Wola.</p><br clear="all" />

