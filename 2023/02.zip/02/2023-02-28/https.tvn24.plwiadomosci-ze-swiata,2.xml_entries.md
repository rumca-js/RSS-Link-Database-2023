# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Jeden z braci ukrywał narkotyki, drugi nielegalną broń. Obaj usłyszeli zarzuty
 - [https://tvn24.pl/pomorze/bydgoszcz-jeden-z-braci-ukrywal-narkotyki-drugi-nielegalna-bron-obaj-uslyszeli-zarzuty-6784394?source=rss](https://tvn24.pl/pomorze/bydgoszcz-jeden-z-braci-ukrywal-narkotyki-drugi-nielegalna-bron-obaj-uslyszeli-zarzuty-6784394?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-02-28 15:23:08+00:00

<img alt="Jeden z braci ukrywał narkotyki, drugi nielegalną broń. Obaj usłyszeli zarzuty" src="https://tvn24.pl/pomorze/cdn-zdjecie-15kr6w-jeden-z-braci-ukrywal-narkotyki-drugi-nielegalna-bron-6784442/alternates/LANDSCAPE_1280" />
    Bydgoscy policjanci zwalczający przestępczość narkotykową zatrzymali mężczyznę posiadającego znaczną ilość narkotyków oraz jego starszego brata, który na strychu domu ukrywał ponad 1400 sztuk różnego rodzaju broni oraz amunicji. Obaj usłyszeli zarzuty, a młodszy mężczyzna trafił do aresztu.

