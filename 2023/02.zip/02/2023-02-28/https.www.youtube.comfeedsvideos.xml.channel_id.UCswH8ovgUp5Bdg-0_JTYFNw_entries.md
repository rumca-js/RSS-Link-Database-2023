# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## “WE AREN’T ALONE” | Brand New UFO Footage Revealed with Jeremy Corbell
 - [https://www.youtube.com/watch?v=Gln8vVUcOrc](https://www.youtube.com/watch?v=Gln8vVUcOrc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-02-28 18:00:06+00:00

Here's my conversation with Jeremy Corbell where we discussed the brand new 'Mosul Orb' UFO footage released by the Pentagon. #UFO #jeremycorbell #USA 
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble
Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community
Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/
Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

