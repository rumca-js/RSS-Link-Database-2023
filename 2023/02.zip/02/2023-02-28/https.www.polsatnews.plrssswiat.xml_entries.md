# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Pomylił gaz z hamulcem i skasował ferrari. Zapadł wyrok w sprawie 55-latka
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/pomylil-gaz-z-hamulcem-i-skasowal-ferrari-zapadl-wyrok-w-sprawie-55-latka/](https://www.polsatnews.pl/wiadomosc/2023-02-28/pomylil-gaz-z-hamulcem-i-skasowal-ferrari-zapadl-wyrok-w-sprawie-55-latka/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 21:26:00+00:00

Na grzywnę w wysokości 10 tys. funtów skazał sąd w Birmingham 55-latka, który wjechał swoim ferrari w samochody stojące przy drodze, a następnie uciekł z miejsca zdarzenia. Richard Cullen usłyszał także zakaz prowadzenia pojazdów mechanicznych. W sumie uszkodził pięć zaparkowanych pojazdów.

## Władimir Sołowjow straszy przemarszem wojsk przez Europę. Warszawę nazwał rosyjskim miastem
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/wladimir-solowjow-straszy-przemarszem-wojsk-przez-europe-warszawe-nazwal-rosyjskim-miastem/](https://www.polsatnews.pl/wiadomosc/2023-02-28/wladimir-solowjow-straszy-przemarszem-wojsk-przez-europe-warszawe-nazwal-rosyjskim-miastem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 20:52:00+00:00

- Powinniśmy przywrócić wszystkie swoje odwieczne ziemie - grzmiał w państwowej telewizji propagandysta Kremla Władimir Sołowjow. Według niego do Rosji powinny należeć tereny nie tylko Ukrainy, ale i Polski. W emocjonalnym tonie mówił też, że rosyjscy żołnierze w przeszłości przemierzali Europę, a w Mediolanie całowali im ręce.

## Przygarnęła bezpańskiego psa. Pitbull zagryzł nową opiekunkę
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/przygarnela-bezpanskiego-psa-pitbull-zagryzl-nowa-opiekunke/](https://www.polsatnews.pl/wiadomosc/2023-02-28/przygarnela-bezpanskiego-psa-pitbull-zagryzl-nowa-opiekunke/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 20:43:00+00:00

Obywatelka Wielkiej Brytanii została zaatakowana przez psa, którego przygarnęła pod swój dach kilka dni wcześniej. Przybyli na miejsce funkcjonariusze zastrzelili agresywne zwierzę. 67-latka w stanie krytycznym trafiła do szpitala, ale lekarze nie byli w stanie jej pomóc.

## Asteroida "Janusz". Nazwa na cześć polskiego astronoma
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/asteroida-janusz-nazwa-na-czesc-polskiego-astronoma/](https://www.polsatnews.pl/wiadomosc/2023-02-28/asteroida-janusz-nazwa-na-czesc-polskiego-astronoma/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 20:33:00+00:00

Międzynarodowa Unia Astronomiczna opublikowała wykaz nazw nadanych planetoidom. Wśród nich znalazła się asteroida Janusz - nazwana tak na cześć polskiego naukowca i księdza jezuity Roberta Janusza.

## Niezwykłe zdjęcie z Wielkiej Brytanii. "Może to królowa Elżbieta?"
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/niezwykle-zdjecie-z-wielkiej-brytanii-moze-to-krolowa-elzbieta/](https://www.polsatnews.pl/wiadomosc/2023-02-28/niezwykle-zdjecie-z-wielkiej-brytanii-moze-to-krolowa-elzbieta/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 19:13:00+00:00

Fotograf z Wielkiej Brytanii uchwycił na zdjęciu falę o niezwykłym kształcie. Woda rozbijająca się o pomost budzi skojarzenia z głową kobiety. Może to bogini morza Amfitryta albo nasza ukochana królowa Elżbieta? - zaczął zastanawiać się autor fotografii.

## Wielka Brytania: Zamiast pomóc pasierbowi zaczęła nagrywać. 3-letni chłopiec zmarł
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/wielka-brytania-zamiast-pomoc-pasierbowi-zaczela-nagrywac-3-letni-chlopiec-zmarl/](https://www.polsatnews.pl/wiadomosc/2023-02-28/wielka-brytania-zamiast-pomoc-pasierbowi-zaczela-nagrywac-3-letni-chlopiec-zmarl/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 18:59:00+00:00

Leila Borrington została skazana za nieumyślne spowodowanie śmierci 3-letniego pasierba - powiadomiła policja w Nottinghamshire. Kobieta zamiast wezwać pomoc do dziecka zaczęła nagrywać zdarzenie i wysłała wiadomość do jego ojca. Dlaczego to mi się przytrafia - pisała.

## Zaginął kilka dni temu. Znaleźli jego szczątki w brzuchu rekina
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/zaginal-kilka-dni-temu-znalezli-jego-szczatki-w-brzuchu-rekina/](https://www.polsatnews.pl/wiadomosc/2023-02-28/zaginal-kilka-dni-temu-znalezli-jego-szczatki-w-brzuchu-rekina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 18:31:00+00:00

Rybacy odnaleźli szczątki 32-letniego Diego Barii, który zaginął kilka dni temu na południu Argentyny. Zwłoki ojca trójki dzieci wyciągnięto z brzucha rekina. Na plaży natrafiono także na quada, którym wcześniej podróżował mężczyzna.

## Zamość: 16-latek śmiertelnie pobity na osiedlu. Policja szuka sprawców
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/zamosc-16-latek-smiertelnie-pobity-na-osiedlu-policja-szuka-sprawcow/](https://www.polsatnews.pl/wiadomosc/2023-02-28/zamosc-16-latek-smiertelnie-pobity-na-osiedlu-policja-szuka-sprawcow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 17:37:00+00:00

Zmarł 16-letni chłopiec, pobity na śmierć najpewniej przez swoich rówieśników w Zamościu (woj. lubelskie). Funkcjonariusze policji szukają 16- i 17-latka, którzy - według dotychczasowych ustaleń - mają związek ze sprawą.

## Szkocja: Zapadł wyrok. Transseksualny gwałciciel spędzi osiem lat w więzieniu
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/szkocja-zapadl-wyrok-transseksualny-gwalciciel-spedzi-osiem-lat-w-wiezieniu/](https://www.polsatnews.pl/wiadomosc/2023-02-28/szkocja-zapadl-wyrok-transseksualny-gwalciciel-spedzi-osiem-lat-w-wiezieniu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 17:24:00+00:00

Isla Bryson została skazana na osiem lat więzienia za zgwałcenie dwóch kobiet. Do gwałtów doszło, gdy Bryson identyfikowała się jako mężczyzna. Sprawa wywołała oburzenie i dyskusję, czy oskarżona powinna przebywać w więzieniu dla kobiet.

## "Atak dronów" 100 kilometrów od Moskwy. Pierwszy raz tak blisko stolicy Rosji
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/atak-dronow-100-kilometrow-od-moskwy-pierwszy-raz-tak-blisko-stolicy-rosji/](https://www.polsatnews.pl/wiadomosc/2023-02-28/atak-dronow-100-kilometrow-od-moskwy-pierwszy-raz-tak-blisko-stolicy-rosji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 16:54:00+00:00

Rosjanie przyznali: 110 kilometrów od Moskwy rozbiły się we wtorek militarne drony. Zdaniem gubernatora obwodu Andrieja Worobjowa doszło do nieudanego ataku w pobliżu miasta Kołomna. Media zauważają, że jeśli za zdarzeniem stoi Ukraina, byłby to najbliższy rosyjskiej stolicy atak od początku inwazji.

## W Chinach opracowano urządzenie do "całowania" na odległość
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/w-chinach-opracowano-urzadzenie-do-calowania-na-odleglosc/](https://www.polsatnews.pl/wiadomosc/2023-02-28/w-chinach-opracowano-urzadzenie-do-calowania-na-odleglosc/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 15:55:00+00:00

Chińscy naukowcy opracowali urządzenie służące do zdalnego całowania. Przedmiot ma kształt ust i może naśladować prawdziwy pocałunek. Producenci przekonują, że jest przeznaczony głównie dla par żyjących w związkach na odległość.

## Rosja: Generał Ołeksandr Matownikow w erotycznym tańcu. Wypłynęło nagranie
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/rosja-general-oleksandr-matownikow-w-erotycznym-tancu-wyplynelo-nagranie/](https://www.polsatnews.pl/wiadomosc/2023-02-28/rosja-general-oleksandr-matownikow-w-erotycznym-tancu-wyplynelo-nagranie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 15:05:00+00:00

Nagranie miała zobaczyć wyłącznie jego partnerka, a ujrzały je miliony osób. Erotyczne wideo z rosyjskim generałem Ołeksandrem Matownikowem w roli głównej błyskawicznie rozchodzi się w sieci. Wojskowy, który na oficjalnych zdjęciach pokazywany był z Władimirem Putinem, prezentuje taniec, podczas którego co chwila ściąga ręcznik i się obnaża.

## FIFA Puskás Award. Marcin Oleksy: Radość, duma, że się idzie przed tyloma gwiazdami
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/zdobywca-nagrody-ferenca-puskasa-marcin-oleksy-radosc-duma-ze-sie-idzie-przed-tyloma-gwiazdami/](https://www.polsatnews.pl/wiadomosc/2023-02-28/zdobywca-nagrody-ferenca-puskasa-marcin-oleksy-radosc-duma-ze-sie-idzie-przed-tyloma-gwiazdami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 14:08:00+00:00

- Udało się zostawić w tyle Payeta i Richarlisona, Mbappe - także jest Marcin Oleksy - podsumował swoje osiągnięcie zdobywca nagrody Ferenca Puskasa, po przylocie do Warszawy. Oleksy podkreślił, że jest bardzo dumny ze swojego osiągnięcia, które jest wyróżnieniem nie tylko dla niego, ale i całego świata amp futbolu.

## Chiny: Odnalazł się dziewięć lat po kremacji. Rodzina myślała, że zginął w wypadku
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/chiny-odnalazl-sie-dziewiec-lat-po-kremacji-rodzina-myslala-ze-zginal-w-wypadku/](https://www.polsatnews.pl/wiadomosc/2023-02-28/chiny-odnalazl-sie-dziewiec-lat-po-kremacji-rodzina-myslala-ze-zginal-w-wypadku/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 13:05:00+00:00

Przez lata rodzina Zhou Kangluo była przekonana, że ich krewny zginął w wypadku samochodowym. Ciało, które miało należeć do starszego mężczyzny znaleziono przy drodze, a następnie - skremowano je. Po blisko dekadzie okazało się, że doszło do pomyłki i uznany za zmarłego nadal żyje.

## Mołdawia. Prorosyjskie protesty w Mołdawii. Tysiące osób na ulicach
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/moladawia-prorosyjskie-protesty-w-moldawii-tysiace-osob-na-ulicach/](https://www.polsatnews.pl/wiadomosc/2023-02-28/moladawia-prorosyjskie-protesty-w-moldawii-tysiace-osob-na-ulicach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 12:30:00+00:00

Paraliż stolicy Mołdawii. Z inicjatywy prorosyjskiej partii Szor, w Kiszyniowie na ulice wyszło tysiące ludzi. Miasto jest sparaliżowane, interweniują służby.

## Białoruś. Służby szukają sprawcy sabotażu na lotnisku pod Mińskiem. Wytypowali sprawcę
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/bialorus-sluzby-szukaja-sprawcy-zamachu-na-lotnisku-pod-minskiem-wytypowali-sprawce/](https://www.polsatnews.pl/wiadomosc/2023-02-28/bialorus-sluzby-szukaja-sprawcy-zamachu-na-lotnisku-pod-minskiem-wytypowali-sprawce/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 09:39:00+00:00

Poszukiwany za popełnienie szczególnie niebezpiecznego przestępstwa - taki status białoruskie służby nadały mężczyźnie podejrzanemu o ostrzelanie z drona rosyjskiego samolotu pod Mińskiem. Portal zeerkalo.website ustalił, że poszukiwany to Mykola Szewc. Zdaniem Aleksandera Azarau, lidera organizacji BYPOL walczącej z Alaksandrem Łukaszenką poszukiwany nie jest związany z atakiem.

## Rosja: Zamknięta przestrzeń powietrzna nad Sankt Petersburgiem
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/rosja-zamknieta-przestrzen-powietrzna-nad-sankt-petersburgiem/](https://www.polsatnews.pl/wiadomosc/2023-02-28/rosja-zamknieta-przestrzen-powietrzna-nad-sankt-petersburgiem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 08:39:00+00:00

Przestrzeń lotnicza nad rosyjskim lotniskiem Petersburg-Pułkowo została zamknięta - informuje agencja Reutera. Według nieoficjalnych informacji nad lotniskiem pojawił się niezidentyfikowany obiekt. Poderwano wojskowe myśliwce.

## Rosja: Eksplozje na terenie składu ropy naftowej. Media: Atak dronów
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/rosja-eksplozje-na-terenie-skladu-ropy-naftowej-media-atak/](https://www.polsatnews.pl/wiadomosc/2023-02-28/rosja-eksplozje-na-terenie-skladu-ropy-naftowej-media-atak/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 08:03:00+00:00

Do pożaru w składzie ropy naftowej doszło w Tupase w Kraju Krasnodarskim - informują lokalne władze. Mieszkańcy miasta słyszeli dwie eksplozje w odstępie kilku sekund. Lokalne media twierdzą, że doszło do ataku dronów wypełnionych materiałami wybuchowymi.

## USA: Biały Dom daje rządowym agencjom 30 dni na usunięcie TikToka z urządzeń federalnych
 - [https://www.polsatnews.pl/wiadomosc/2023-02-28/usa-bialy-dom-daje-rzadowym-agencjom-30-dni-na-usuniecie-tiktoka-z-urzadzen-federalnych/](https://www.polsatnews.pl/wiadomosc/2023-02-28/usa-bialy-dom-daje-rzadowym-agencjom-30-dni-na-usuniecie-tiktoka-z-urzadzen-federalnych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-28 05:58:00+00:00

Amerykańskie agencje rządowe muszą w ciągu 30 dni usunąć chińską aplikację TikTok z systemów i urządzeń federalnych - taki nakaz wydał w poniedziałek Biały Dom. Wszystko przez obawy o bezpieczeństwo ważnych danych dotyczących państwa. Decyzja nie obejmuje Amerykanów korzystających z aplikacji na prywatnych lub firmowych urządzeniach.

