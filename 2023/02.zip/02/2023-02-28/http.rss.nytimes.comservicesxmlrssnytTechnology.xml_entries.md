# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Rivian Lost $6.8 Billion Last Year as Production Fell Short
 - [https://www.nytimes.com/2023/02/28/business/rivian-fourth-quarter-earnings.html](https://www.nytimes.com/2023/02/28/business/rivian-fourth-quarter-earnings.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-02-28 22:07:53+00:00

The maker of electric trucks said it expected to double production in 2023 as the supply of parts became more reliable.

## Third Top FTX Executive Pleads Guilty in Fraud Investigation
 - [https://www.nytimes.com/2023/02/28/technology/ftx-guilty-plea-fraud.html](https://www.nytimes.com/2023/02/28/technology/ftx-guilty-plea-fraud.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-02-28 18:07:22+00:00

Nishad Singh, an FTX founder, pleaded guilty to criminal charges and agreed to cooperate with prosecutors investigating Sam Bankman-Fried.

## ‘Sometimes Things Break’: Twitter Outages Are on the Rise
 - [https://www.nytimes.com/2023/02/28/technology/twitter-outages-elon-musk.html](https://www.nytimes.com/2023/02/28/technology/twitter-outages-elon-musk.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-02-28 17:15:16+00:00

Elon Musk’s repeated job cuts are stoking new fears that there aren’t enough people to triage Twitter’s problems.

