# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## An Apple Store Worker Is the New Face of US Labor Law Reform
 - [https://www.wired.com/story/an-apple-store-worker-is-the-new-face-of-us-labor-law-reform/](https://www.wired.com/story/an-apple-store-worker-is-the-new-face-of-us-labor-law-reform/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-28 21:06:32+00:00

The company's anti-union tactics at retail outlets have drawn government scrutiny and are fueling a drive to get a new labor bill through Congress.

## Uber and Lyft Are More Likely to Fire Drivers of Color
 - [https://www.wired.com/story/uber-and-lyft-are-more-likely-to-fire-drivers-of-color/](https://www.wired.com/story/uber-and-lyft-are-more-likely-to-fire-drivers-of-color/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-28 17:36:14+00:00

After passenger complaints, non-white drivers are suspended or deactivated more often than their white counterparts, according to new research.

## India’s YouTube Vigilante Is Wanted for Murder
 - [https://www.wired.com/story/indias-youtube-vigilante-monu-manesar-murder/](https://www.wired.com/story/indias-youtube-vigilante-monu-manesar-murder/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-28 17:00:00+00:00

Monu Manesar built a huge audience with violent content, but he’s far from the only sectarian streamer in Modi’s India.

## Face Recognition Software Led to His Arrest. It Was Dead Wrong
 - [https://www.wired.com/story/face-recognition-software-led-to-his-arrest-it-was-dead-wrong/](https://www.wired.com/story/face-recognition-software-led-to-his-arrest-it-was-dead-wrong/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-28 12:00:00+00:00

Alonzo Sawyer’s misidentification by algorithm made him a suspect for a crime police now say was committed by someone else—feeding debate over regulation.

