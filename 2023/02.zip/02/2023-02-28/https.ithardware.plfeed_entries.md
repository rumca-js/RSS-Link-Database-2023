# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Polecane zestawy komputerowe do gier marzec 2023
 - [https://ithardware.pl/poradniki/polecane_zestawy_komputerowe_do_gier_marzec_2023-26047.html](https://ithardware.pl/poradniki/polecane_zestawy_komputerowe_do_gier_marzec_2023-26047.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 23:00:01+00:00

<img src="https://ithardware.pl/artykuly/min/26047_1.jpg" />            Polecane zestawy komputerowe do gier marzec 2023

Jaki komputer kupić? Jak dobrać komponenty komputera? Nie musisz się martwić, na kolejnych stronach znajdziesz gotowe propozycje polecanych zestaw&oacute;w komputerowych do gier w r&oacute;żnych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/poradniki/polecane_zestawy_komputerowe_do_gier_marzec_2023-26047.html">https://ithardware.pl/poradniki/polecane_zestawy_komputerowe_do_gier_marzec_2023-26047.html</a></p>

## Cyberpunk 2077 przeszedł weryfikację na Steam Deck
 - [https://ithardware.pl/aktualnosci/cyberpunk_2077_przeszedl_weryfikacje_na_steam_deck-26068.html](https://ithardware.pl/aktualnosci/cyberpunk_2077_przeszedl_weryfikacje_na_steam_deck-26068.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 21:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/26068_1.jpg" />            CD Projekt RED poinformował, że Cyberpunk 2077 został zweryfikowany na Steam Deck i można w niego oficjalnie grać na sprzęcie Valve bez większego problemu. Jest to dobra wiadomość dla os&oacute;b, kt&oacute;re chciały pograć na tym przenośnym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cyberpunk_2077_przeszedl_weryfikacje_na_steam_deck-26068.html">https://ithardware.pl/aktualnosci/cyberpunk_2077_przeszedl_weryfikacje_na_steam_deck-26068.html</a></p>

## Składany smartfon od OnePlusa już w tym roku
 - [https://ithardware.pl/aktualnosci/skladany_smartfon_od_oneplusa_juz_w_tym_roku-26066.html](https://ithardware.pl/aktualnosci/skladany_smartfon_od_oneplusa_juz_w_tym_roku-26066.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 20:04:30+00:00

<img src="https://ithardware.pl/artykuly/min/26066_1.jpg" />            Firma OnePlus ogłosiła dziś w trakcie MWC 2023, że pracuje nad składanym smartfonem. Urządzenie ma pojawić się już w tym roku. OnePlus nie sprecyzował jednak, kiedy dokładnie możemy spodziewać się premiery. Pierwszy składak tej chińskiej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/skladany_smartfon_od_oneplusa_juz_w_tym_roku-26066.html">https://ithardware.pl/aktualnosci/skladany_smartfon_od_oneplusa_juz_w_tym_roku-26066.html</a></p>

## Valorant przestanie wspierać starsze systemy Windows
 - [https://ithardware.pl/aktualnosci/valorant_przestanie_wspierac_starsze_systemy_windows-26067.html](https://ithardware.pl/aktualnosci/valorant_przestanie_wspierac_starsze_systemy_windows-26067.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 19:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/26067_1.jpg" />            Valorant niebawem przestanie działać na starszych systemach operacyjnych Microsoftu. Według Riot Games chodzi o względy bezpieczeństwa, co nie dziwi, ponieważ oprogramowanie firmy z Redmond nie jest już wspierane i łatane.

Valorant działa...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/valorant_przestanie_wspierac_starsze_systemy_windows-26067.html">https://ithardware.pl/aktualnosci/valorant_przestanie_wspierac_starsze_systemy_windows-26067.html</a></p>

## iPhone SE 4. generacji jednak powstanie? Budżetowiec od Apple wreszcie z nowoczesnym wyglądem
 - [https://ithardware.pl/aktualnosci/iphone_se_4_generacji_jednak_powstanie_budzetowiec_od_apple_wreszcie_z_nowoczesnym_wygladem-26064.html](https://ithardware.pl/aktualnosci/iphone_se_4_generacji_jednak_powstanie_budzetowiec_od_apple_wreszcie_z_nowoczesnym_wygladem-26064.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 18:05:40+00:00

<img src="https://ithardware.pl/artykuly/min/26064_1.jpg" />            Ming-Chi Kuo twierdzi, że Apple ponownie uruchomiło prace nad kolejnym wydaniem swojego &quot;budżetowego&quot; smartfona. Według analityka, iPhone SE 4. generacji powstanie i będzie pierwszym smartfonem Apple, kt&oacute;ry wykorzysta ich autorski...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/iphone_se_4_generacji_jednak_powstanie_budzetowiec_od_apple_wreszcie_z_nowoczesnym_wygladem-26064.html">https://ithardware.pl/aktualnosci/iphone_se_4_generacji_jednak_powstanie_budzetowiec_od_apple_wreszcie_z_nowoczesnym_wygladem-26064.html</a></p>

## Forspoken pogrążył swoich twórców. Luminous Productions przechodzi do historii
 - [https://ithardware.pl/aktualnosci/forspoken_pograzyl_swoich_tworcow_luminous_productions_przechodzi_do_historii-26065.html](https://ithardware.pl/aktualnosci/forspoken_pograzyl_swoich_tworcow_luminous_productions_przechodzi_do_historii-26065.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 17:40:30+00:00

<img src="https://ithardware.pl/artykuly/min/26065_1.jpg" />            Forspoken zbiera średnie oceny, podobnie jak nie notuje świetnej sprzedaży. Gra w wersji PC cierpiała na błędy czy problemy z wydajnością, ale do wad należy zaliczyć r&oacute;wnież mało ciekawą fabułę czy zwyczajną nudę. Produkcja,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/forspoken_pograzyl_swoich_tworcow_luminous_productions_przechodzi_do_historii-26065.html">https://ithardware.pl/aktualnosci/forspoken_pograzyl_swoich_tworcow_luminous_productions_przechodzi_do_historii-26065.html</a></p>

## Jak Samsung może nazywać 45 W szybkim ładowaniem, skoro Redmi zapowiedziało już 300 W!
 - [https://ithardware.pl/aktualnosci/jak_samsung_moze_nazywac_45_w_szybkim_ladowaniem_skoro_redmi_zapowiedzialo_juz_300_w-26063.html](https://ithardware.pl/aktualnosci/jak_samsung_moze_nazywac_45_w_szybkim_ladowaniem_skoro_redmi_zapowiedzialo_juz_300_w-26063.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 16:50:20+00:00

<img src="https://ithardware.pl/artykuly/min/26063_1.jpg" />            Ta funkcja&nbsp;może okazać się zbawienna, jeśli chwilę przed wyjściem z domu zorientujemy się, że nasz smartfon potrzebuje ładowania. Podmarka Xiaomi, Redmi, zademonstrowała technologię szybkiego ładowania z mocą aż 300 W. Dzięki temu,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/jak_samsung_moze_nazywac_45_w_szybkim_ladowaniem_skoro_redmi_zapowiedzialo_juz_300_w-26063.html">https://ithardware.pl/aktualnosci/jak_samsung_moze_nazywac_45_w_szybkim_ladowaniem_skoro_redmi_zapowiedzialo_juz_300_w-26063.html</a></p>

## AMD Ryzen 9 7950X3D i Ryzen 9 7900X3D już dostępne. Szykuje się hicior?
 - [https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x3d_i_ryzen_9_7900x3d_juz_dostepne_szykuje_sie_hicior-26062.html](https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x3d_i_ryzen_9_7900x3d_juz_dostepne_szykuje_sie_hicior-26062.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 16:06:00+00:00

<img src="https://ithardware.pl/artykuly/min/26062_1.jpg" />            Dziś, 28 lutego, na sklepowych p&oacute;łkach oficjalnie zagościły najnowsze procesory AMD z pamięcią 3D V-Cache. W pierwszej kolejności zadebiutowały 2 najwydajniejsze modele - Ryzen 9 7950X3D i Ryzen 9 7900X3D. W sieci pojawiły się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x3d_i_ryzen_9_7900x3d_juz_dostepne_szykuje_sie_hicior-26062.html">https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x3d_i_ryzen_9_7900x3d_juz_dostepne_szykuje_sie_hicior-26062.html</a></p>

## Test be quiet! Dark Power 13 1000 W - tak dobry, że nie nadążają z produkcją
 - [https://ithardware.pl/testyirecenzje/test_be_quiet_dark_power_13_1000_w-25820.html](https://ithardware.pl/testyirecenzje/test_be_quiet_dark_power_13_1000_w-25820.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/25820_1.jpg" />            Test be quiet! Dark Power 13 1000 W - ATX 3.0 z 80 PLUS Titanium

Test be quiet! Dark Power 13 1000 W&nbsp;miał być pierwotnie przygotowany na premierę, niestety producent zanotował mały poślizg i zasilacz nie dotarł do mnie na czas, ale jak to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/test_be_quiet_dark_power_13_1000_w-25820.html">https://ithardware.pl/testyirecenzje/test_be_quiet_dark_power_13_1000_w-25820.html</a></p>

## Chiny prawdopodobnie ukradły plany maszyn litograficznych ASML
 - [https://ithardware.pl/aktualnosci/chiny_prawdopodobnie_ukradly_plany_maszyn_litograficznych_asml-26061.html](https://ithardware.pl/aktualnosci/chiny_prawdopodobnie_ukradly_plany_maszyn_litograficznych_asml-26061.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 13:14:00+00:00

<img src="https://ithardware.pl/artykuly/min/26061_1.jpg" />            ASML donosi o kolejnej kradzieży tajemnic związanych z maszynami litograficznymi. To już drugi taki przypadek w ciągu roku.

Pracownik, kt&oacute;ry został oskarżony o kradzież tajemnic handlowych zaawansowanego sprzętu do produkcji...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chiny_prawdopodobnie_ukradly_plany_maszyn_litograficznych_asml-26061.html">https://ithardware.pl/aktualnosci/chiny_prawdopodobnie_ukradly_plany_maszyn_litograficznych_asml-26061.html</a></p>

## Facebook i Instagram pomogą nastolatkom w blokowaniu ich nagich zdjęć
 - [https://ithardware.pl/aktualnosci/facebook_i_instagram_pomoga_nastolatkom_w_blokowaniu_ich_nagich_zdjec-26056.html](https://ithardware.pl/aktualnosci/facebook_i_instagram_pomoga_nastolatkom_w_blokowaniu_ich_nagich_zdjec-26056.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 12:16:01+00:00

<img src="https://ithardware.pl/artykuly/min/26056_1.jpg" />            Meta podejmuje dalsze kroki w ramach swojej obietnicy zwalczania sextortion i innych form materiał&oacute;w przedstawiających seksualne wykorzystywanie dzieci.&nbsp;

Firma ujawniła, że ​​Facebook i Instagram są członkami-założycielami Take...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/facebook_i_instagram_pomoga_nastolatkom_w_blokowaniu_ich_nagich_zdjec-26056.html">https://ithardware.pl/aktualnosci/facebook_i_instagram_pomoga_nastolatkom_w_blokowaniu_ich_nagich_zdjec-26056.html</a></p>

## Chiny mają swojego chatbota. Nie radzi sobie z... chińskim
 - [https://ithardware.pl/aktualnosci/chiny_maja_swojego_chatbota_nie_radzi_sobie_z_chinskim-26060.html](https://ithardware.pl/aktualnosci/chiny_maja_swojego_chatbota_nie_radzi_sobie_z_chinskim-26060.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 12:09:50+00:00

<img src="https://ithardware.pl/artykuly/min/26060_1.jpg" />            Chatboty to ostatnio niesamowicie popularne narzędzia.&nbsp;W Chinach opracowywany jest r&oacute;wnież system, kt&oacute;ry ma być lokalnym konkurentem dla ChatGPT, jednak jak dotąd jego możliwości są daleko za algorytmami OpenAi, a dodatkowo chat...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chiny_maja_swojego_chatbota_nie_radzi_sobie_z_chinskim-26060.html">https://ithardware.pl/aktualnosci/chiny_maja_swojego_chatbota_nie_radzi_sobie_z_chinskim-26060.html</a></p>

## Procesory Intel Meteor Lake-S nadal niepewne. Nowe przecieki i szczegóły chipsetu Intel Z890
 - [https://ithardware.pl/aktualnosci/procesory_intel_meteor_lake_s_nadal_niepewne_nowe_przecieki_i_szczegoly_chipsetu_intel_z890-26055.html](https://ithardware.pl/aktualnosci/procesory_intel_meteor_lake_s_nadal_niepewne_nowe_przecieki_i_szczegoly_chipsetu_intel_z890-26055.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 11:25:01+00:00

<img src="https://ithardware.pl/artykuly/min/26055_1.jpg" />            Od kilku tygodni docierają do nas sprzeczne informacje na temat desktopowych procesor&oacute;w Meteor Lake-S. Część informator&oacute;w twierdzi, że te zostały skasowane i nie ujrzą światła dziennego, inni z kolei dostarczają nam kolejnych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/procesory_intel_meteor_lake_s_nadal_niepewne_nowe_przecieki_i_szczegoly_chipsetu_intel_z890-26055.html">https://ithardware.pl/aktualnosci/procesory_intel_meteor_lake_s_nadal_niepewne_nowe_przecieki_i_szczegoly_chipsetu_intel_z890-26055.html</a></p>

## AI ma promować "równość". Biden podpisał rozporządzenie wspierające kulturę "woke"
 - [https://ithardware.pl/aktualnosci/ai_ma_promowac_rownosc_biden_podpisal_rozporzadzenie_wspierajace_kulture_woke-26059.html](https://ithardware.pl/aktualnosci/ai_ma_promowac_rownosc_biden_podpisal_rozporzadzenie_wspierajace_kulture_woke-26059.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 10:16:50+00:00

<img src="https://ithardware.pl/artykuly/min/26059_1.jpg" />            W zeszłym tygodniu prezydent&nbsp;Joe Biden&nbsp;podpisał&nbsp;dekret, kt&oacute;ry, jak ostrzegają krytycy, wskazuje na rozw&oacute;j stronniczej&nbsp;sztucznej inteligencji.

Rozporządzenie ma na celu ustanowienie rocznego &bdquo;planu działania...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ai_ma_promowac_rownosc_biden_podpisal_rozporzadzenie_wspierajace_kulture_woke-26059.html">https://ithardware.pl/aktualnosci/ai_ma_promowac_rownosc_biden_podpisal_rozporzadzenie_wspierajace_kulture_woke-26059.html</a></p>

## OnePlus zaprezentował smartfon z chłodzeniem cieczą niczym w PC
 - [https://ithardware.pl/aktualnosci/oneplus_zaprezentowal_smartfon_z_chlodzeniem_ciecza_niczym_w_pc-26054.html](https://ithardware.pl/aktualnosci/oneplus_zaprezentowal_smartfon_z_chlodzeniem_ciecza_niczym_w_pc-26054.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 10:10:01+00:00

<img src="https://ithardware.pl/artykuly/min/26054_1.jpg" />            Po licznych zwiastunach OnePlus zaprezentowało sw&oacute;j najnowszy eksperymentalny telefon i tym razem zdaje się on oferować bardziej praktyczne funkcje niż podobne projekty tego producenta w przeszłości.&nbsp;

Najważniejszą funkcją OnePlus...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/oneplus_zaprezentowal_smartfon_z_chlodzeniem_ciecza_niczym_w_pc-26054.html">https://ithardware.pl/aktualnosci/oneplus_zaprezentowal_smartfon_z_chlodzeniem_ciecza_niczym_w_pc-26054.html</a></p>

## Honor opracował pierwszy w branży  krzemowo-węglowy akumulator dla smartfonów
 - [https://ithardware.pl/aktualnosci/honor_opracowal_pierwszy_w_branzy_krzemowo_weglowy_akumulator_dla_smartfonow-26053.html](https://ithardware.pl/aktualnosci/honor_opracowal_pierwszy_w_branzy_krzemowo_weglowy_akumulator_dla_smartfonow-26053.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 09:36:02+00:00

<img src="https://ithardware.pl/artykuly/min/26053_1.jpg" />            O ile większość smartfonowych technologii rozwija się w relatywnie szybkim tempie (wystarczy spojrzeć na postępy w zakresie procesor&oacute;w, wyświetlaczy czy aparat&oacute;w), tak jeden z ich kluczowych element&oacute;w od wielu lat pozostaje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/honor_opracowal_pierwszy_w_branzy_krzemowo_weglowy_akumulator_dla_smartfonow-26053.html">https://ithardware.pl/aktualnosci/honor_opracowal_pierwszy_w_branzy_krzemowo_weglowy_akumulator_dla_smartfonow-26053.html</a></p>

## Cyberatak na podatki.gov.pl. Podejrzewani Rosjanie. Co z rozliczeniami PIT?
 - [https://ithardware.pl/aktualnosci/cyberatak_na_podatki_gov_pl_podejrzewani_rosjanie_co_z_rozliczeniami_pit-26057.html](https://ithardware.pl/aktualnosci/cyberatak_na_podatki_gov_pl_podejrzewani_rosjanie_co_z_rozliczeniami_pit-26057.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 08:50:50+00:00

<img src="https://ithardware.pl/artykuly/min/26057_1.jpg" />            Od ponad godziny nie działa strona internetowa podatki.gov.pl, kt&oacute;ra pozwala składać rozliczenia PIT. RMF24.pl informuje o ataku hakerskim, a nieoficjalnie m&oacute;wi się o ataku Rosjan, kt&oacute;rzy umawiali się na ataki na polskie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cyberatak_na_podatki_gov_pl_podejrzewani_rosjanie_co_z_rozliczeniami_pit-26057.html">https://ithardware.pl/aktualnosci/cyberatak_na_podatki_gov_pl_podejrzewani_rosjanie_co_z_rozliczeniami_pit-26057.html</a></p>

## Zablokowany Ryzen 9 7950X3D podkręcony do 5,9 GHz. Procesor został już nawet oskalpowany
 - [https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x3d_podkrecony_do_5_9_ghz_procesor_zostal_juz_nawet_oskalpowany-26052.html](https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x3d_podkrecony_do_5_9_ghz_procesor_zostal_juz_nawet_oskalpowany-26052.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 08:46:10+00:00

<img src="https://ithardware.pl/artykuly/min/26052_1.jpg" />            SkatterBencher opublikował obszerny artykuł o podkręcaniu nowego flagowego CPU AMD, czyli Ryzena 9 7950X3D, z kolei der8auer nie marnował czasu i od razu zabrał się za skalpowanie układu Zen 4 z pamięcią podręczną 3D...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x3d_podkrecony_do_5_9_ghz_procesor_zostal_juz_nawet_oskalpowany-26052.html">https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x3d_podkrecony_do_5_9_ghz_procesor_zostal_juz_nawet_oskalpowany-26052.html</a></p>

## Kolejna chińska firma zapowiada swoją kartę graficzną. Wydajność na poziomie GeForce GTX 1650
 - [https://ithardware.pl/aktualnosci/kolejna_chinska_firma_zapowiada_swoja_karte_graficzna_wydajnosc_na_poziomie_geforce_gtx_1650-26051.html](https://ithardware.pl/aktualnosci/kolejna_chinska_firma_zapowiada_swoja_karte_graficzna_wydajnosc_na_poziomie_geforce_gtx_1650-26051.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 08:04:32+00:00

<img src="https://ithardware.pl/artykuly/min/26051_1.jpg" />            Zhihui Microelectronics, chiński producent układ&oacute;w graficznych, zaprezentował swoje pierwsze GPU. To celuje w poziom wydajności zbliżony do GeForce GTX 1650 od NVIDII, jednocześnie obiecując wyższą efektywność energetyczną. Jest to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kolejna_chinska_firma_zapowiada_swoja_karte_graficzna_wydajnosc_na_poziomie_geforce_gtx_1650-26051.html">https://ithardware.pl/aktualnosci/kolejna_chinska_firma_zapowiada_swoja_karte_graficzna_wydajnosc_na_poziomie_geforce_gtx_1650-26051.html</a></p>

## Procesory AMD Ryzen 7040 "Phoenix" zaliczają downgrade przed samą premierą
 - [https://ithardware.pl/aktualnosci/procesory_amd_ryzen_7040_phoenix_zaliczaja_downgrade_przed_sama_premiera-26050.html](https://ithardware.pl/aktualnosci/procesory_amd_ryzen_7040_phoenix_zaliczaja_downgrade_przed_sama_premiera-26050.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 07:17:27+00:00

<img src="https://ithardware.pl/artykuly/min/26050_1.jpg" />            AMD właśnie zaktualizowało strony produktowe swoich nowych nadchodzących procesor&oacute;w mobilnych z serii Ryzen 7040 &quot;Phoenix&quot; i okazało się, że przy okazji producent po cichu wprowadził zmiany w ich specyfikacji.

Seria AMD...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/procesory_amd_ryzen_7040_phoenix_zaliczaja_downgrade_przed_sama_premiera-26050.html">https://ithardware.pl/aktualnosci/procesory_amd_ryzen_7040_phoenix_zaliczaja_downgrade_przed_sama_premiera-26050.html</a></p>

## Podsumowanie newsów ITHardware - tydzień 94. Sprawdź co Cię ominęło
 - [https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_dziewiecdziesiaty_czwarty_luty_2023-26049.html](https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_dziewiecdziesiaty_czwarty_luty_2023-26049.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-28 06:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26049_1.jpg" />            Jak co tydzień zapraszamy naszych czytelnik&oacute;w do odwiedzenia kanału&nbsp;ITHardware na YouTube i do zapoznania się z materiałem prezentującym najważniejsze wydarzenia minionych 7 dni.

Za powstanie wideo odpowiada&nbsp;nasz redakcyjny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_dziewiecdziesiaty_czwarty_luty_2023-26049.html">https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_dziewiecdziesiaty_czwarty_luty_2023-26049.html</a></p>

