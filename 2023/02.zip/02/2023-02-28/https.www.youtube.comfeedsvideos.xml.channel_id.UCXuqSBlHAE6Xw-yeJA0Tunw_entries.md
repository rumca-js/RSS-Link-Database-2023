# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I'm NOT Stupid
 - [https://www.youtube.com/watch?v=d8bZCve_ZKA](https://www.youtube.com/watch?v=d8bZCve_ZKA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-02-28 00:12:12+00:00

White noise is the right noise! Check out the SNOOZ Pro at https://lmg.gg/SNOOZ

Get 69% off any of XSplit’s video tools. Use code LINUS at https://lmg.gg/XSplit

Things at the lab are going GREAT, and we can't wait to show you! Come take a tour and check out some cool new features like the metal 3D printer, submersion tank, and more before we move the writers over.

Discuss on the forum: https://linustechtips.com/topic/1490997-im-not-stupid/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:05 Keyboard Update
2:35 Submersion Testing
4:43 Component Testing
5:54 RF Chamber Plan
8:10 Home Theater
9:16 Metal 3D Printer
12:16 PSU Tester
13:37 Logistics Update
14:25 Dan Update
16:55 Expensive Foam
17:58 We Don't Know
19:47 Writers' Area
22:18 Conclusion
24:11 Outro

