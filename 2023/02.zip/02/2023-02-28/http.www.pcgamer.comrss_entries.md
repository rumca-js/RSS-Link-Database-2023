# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Naoki Yoshida says Final Fantasy 16 won't be on PC 6 months after release
 - [https://www.pcgamer.com/naoki-yoshida-says-final-fantasy-16-wont-be-on-pc-6-months-after-release](https://www.pcgamer.com/naoki-yoshida-says-final-fantasy-16-wont-be-on-pc-6-months-after-release)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 23:09:19+00:00

We thought so, but we're still sad about it.

## Somebody tossed at least $100K of Magic: The Gathering cards in a landfill
 - [https://www.pcgamer.com/somebody-tossed-at-least-dollar100k-of-magic-the-gathering-cards-in-a-landfill](https://www.pcgamer.com/somebody-tossed-at-least-dollar100k-of-magic-the-gathering-cards-in-a-landfill)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 22:04:38+00:00

"For dust you are, and to dust you shall return."
– Emrakul or somebody.

## How to get Defiant Keys in Destiny 2's Season of Defiance
 - [https://www.pcgamer.com/destiny-2-defiant-keys](https://www.pcgamer.com/destiny-2-defiant-keys)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 21:42:36+00:00

Crack open Defiant Battleground chests for seasonal loot.

## Diablo 4 beta start dates and times
 - [https://www.pcgamer.com/diablo-4-beta-dates-early-access](https://www.pcgamer.com/diablo-4-beta-dates-early-access)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 21:11:33+00:00

The Diablo 4 beta weekends include the prologue and the first act.

## Where to find the flashlight in Sons of the Forest
 - [https://www.pcgamer.com/sons-of-the-forest-flashlight](https://www.pcgamer.com/sons-of-the-forest-flashlight)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 20:52:50+00:00

An illuminating piece of gear should be one of your first goals in Sons of the Forest.

## Heck yeah, Sons of the Forest update adds weapon hotkeys
 - [https://www.pcgamer.com/heck-yeah-sons-of-the-forest-update-adds-weapon-hotkeys](https://www.pcgamer.com/heck-yeah-sons-of-the-forest-update-adds-weapon-hotkeys)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 20:22:52+00:00

No more fumbling with your backback. Today's hotfix adds a few small but important improvements to the early access survival game.

## After 4 years, Destiny 2's Cayde-6 finally gets the memorial he deserves
 - [https://www.pcgamer.com/after-4-years-destiny-2s-cayde-6-finally-gets-the-memorial-he-deserves](https://www.pcgamer.com/after-4-years-destiny-2s-cayde-6-finally-gets-the-memorial-he-deserves)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 19:53:45+00:00

Lightfall commemorates a fan favourite NPC.

## How to get water and a water flask in Sons of the Forest
 - [https://www.pcgamer.com/sons-of-the-forest-water-collector-flask](https://www.pcgamer.com/sons-of-the-forest-water-collector-flask)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 19:47:03+00:00

Remember to stay hydrated, folks; craft a flask and set up camp by a stream.

## All Destiny 2 Season of Defiance Eververse items and Lightfall exotics
 - [https://www.pcgamer.com/destiny-2-season-of-defiance-eververse-items-lightfall-exotics](https://www.pcgamer.com/destiny-2-season-of-defiance-eververse-items-lightfall-exotics)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 19:26:04+00:00

Sleek styles in exchange for Silver.

## A Stalker board game is coming and of course I want miniatures of the little zone men
 - [https://www.pcgamer.com/a-stalker-board-game-is-coming-and-of-course-i-want-miniatures-of-the-little-zone-men](https://www.pcgamer.com/a-stalker-board-game-is-coming-and-of-course-i-want-miniatures-of-the-little-zone-men)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 19:18:36+00:00

It's a cooperative "zone-crawling" game according to its creator.

## Xbox boss Phil Spencer somehow managed to 100% Vampire Survivors while managing the biggest videogame acquisition in history
 - [https://www.pcgamer.com/xbox-boss-phil-spencer-somehow-managed-to-100-vampire-survivors-while-managing-the-biggest-videogame-acquisition-in-history](https://www.pcgamer.com/xbox-boss-phil-spencer-somehow-managed-to-100-vampire-survivors-while-managing-the-biggest-videogame-acquisition-in-history)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 18:04:36+00:00

He's just like me. For real.

## Let's speculate way too much about the Elden Ring expansion image
 - [https://www.pcgamer.com/lets-speculate-way-too-much-about-the-elden-ring-expansion-image](https://www.pcgamer.com/lets-speculate-way-too-much-about-the-elden-ring-expansion-image)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 18:00:27+00:00

Enhance that Erdtree!

## Phantom Brigade review
 - [https://www.pcgamer.com/phantom-brigade-review](https://www.pcgamer.com/phantom-brigade-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 18:00:22+00:00

A bare-bones foundation for future mech wars.

## Where to find the GPS locators in Sons of the Forest
 - [https://www.pcgamer.com/sons-of-the-forest-gps-locators](https://www.pcgamer.com/sons-of-the-forest-gps-locators)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 17:01:22+00:00

And how to use the small trackers.

## After 10 years of killing dragons, Guild Wars 2's new update is a hint at what comes next
 - [https://www.pcgamer.com/after-10-years-of-killing-dragons-guild-wars-2s-new-update-is-a-hint-at-what-comes-next](https://www.pcgamer.com/after-10-years-of-killing-dragons-guild-wars-2s-new-update-is-a-hint-at-what-comes-next)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 17:00:27+00:00

What Lies Beneath is out now, with a new map and a new threat.

## I'm 100% enabling Nvidia's new AI upscaling tech for Twitch streams but it's no DLSS for video
 - [https://www.pcgamer.com/nvidia-rtx-vsr-tested-streaming-performance](https://www.pcgamer.com/nvidia-rtx-vsr-tested-streaming-performance)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 16:59:24+00:00

RTX Video Super Resolution is a neat new tool, but don't go expecting miracles—480p still looks a lot like 480p.

## Intel is already matching AMD for gaming graphics market share
 - [https://www.pcgamer.com/intel-is-already-matching-amd-for-gaming-graphics-market-share](https://www.pcgamer.com/intel-is-already-matching-amd-for-gaming-graphics-market-share)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 16:40:01+00:00

Intel and AMD on an equal 9% of the market share with Nvidia hoovering up the rest according to JPR.

## Graphics card shipments cratered by 50% at the end of 2022
 - [https://www.pcgamer.com/graphics-card-shipments-cratered-by-50-at-the-end-of-2022](https://www.pcgamer.com/graphics-card-shipments-cratered-by-50-at-the-end-of-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 16:38:24+00:00

We just died of not surprise.

## Hitman's developer just announced its next project: an 'online fantasy RPG'
 - [https://www.pcgamer.com/hitmans-developer-just-announced-its-next-project-an-online-fantasy-rpg](https://www.pcgamer.com/hitmans-developer-just-announced-its-next-project-an-online-fantasy-rpg)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 16:23:57+00:00

Please god let it star Agent 47 disguised as an elf.

## 14 years later Resident Evil 5 finally removes Games for Windows Live and restores splitscreen
 - [https://www.pcgamer.com/14-years-later-resident-evil-5-finally-removes-games-for-windows-live-and-restores-splitscreen](https://www.pcgamer.com/14-years-later-resident-evil-5-finally-removes-games-for-windows-live-and-restores-splitscreen)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 14:17:09+00:00

"Well isn't this one big family reunion."

## Chainsaw Man X Goddess of Victory: Nikke is now live on PC
 - [https://www.pcgamer.com/chainsaw-man-x-goddess-of-victory-nikke-is-now-live-on-pc](https://www.pcgamer.com/chainsaw-man-x-goddess-of-victory-nikke-is-now-live-on-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 14:00:51+00:00

Having recently topped 25 million downloads on Android and iOS, sci-fi RPG shooter Goddess of Victory: Nikke is coming to PC with full cross-platform play. To commemorate the launch, publisher Level Infinite announced a crossover with one of the world's most popular manga properties — the iconic Chainsaw Man.

## Inside the F1 team treating esports like a Formula One Grand Prix
 - [https://www.pcgamer.com/alpine-esports-sim-racing-formula-one-data](https://www.pcgamer.com/alpine-esports-sim-racing-formula-one-data)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 14:00:42+00:00

I've seen the technical heart of Alpine, the F1 team bringing Formula One's obsession over data to sim racing tournaments.

## Elden Ring's creator says he's been checking out Escape from Tarkov for a little multiplayer inspiration
 - [https://www.pcgamer.com/elden-rings-creator-says-hes-been-checking-out-escape-from-tarkov-for-a-little-multiplayer-inspiration](https://www.pcgamer.com/elden-rings-creator-says-hes-been-checking-out-escape-from-tarkov-for-a-little-multiplayer-inspiration)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 13:33:45+00:00

Hidetaka Miyazaki has been keeping one eye on Norvinsk.

## The Dwarf Fortress devs once made a comedy revolution simulator, and it's time for heads to roll once more
 - [https://www.pcgamer.com/the-dwarf-fortress-devs-first-game-was-a-comedy-revolution-simulator-and-its-time-for-heads-to-roll-once-more](https://www.pcgamer.com/the-dwarf-fortress-devs-first-game-was-a-comedy-revolution-simulator-and-its-time-for-heads-to-roll-once-more)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 12:21:25+00:00

Liberal Crime Squad risks being left behind after Dwarf Fortress' Steam release.

## Staff at Ubisoft's Beyond Good and Evil 2 studio are reportedly at breaking point
 - [https://www.pcgamer.com/staff-at-ubisofts-beyond-good-and-evil-2-studio-are-reportedly-at-breaking-point](https://www.pcgamer.com/staff-at-ubisofts-beyond-good-and-evil-2-studio-are-reportedly-at-breaking-point)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 12:09:49+00:00

Numerous staff have taken extended leave recently, and some never returned.

## Where to find the winter jacket in Sons of the Forest
 - [https://www.pcgamer.com/sons-of-the-forest-winter-jacket-location](https://www.pcgamer.com/sons-of-the-forest-winter-jacket-location)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 11:57:02+00:00

It will help you survive the snow.

## Elden Ring's first expansion looks like it takes place before the events of the game
 - [https://www.pcgamer.com/elden-ring-announces-first-expansion](https://www.pcgamer.com/elden-ring-announces-first-expansion)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 11:36:50+00:00

May feature Malenia's little bro.

## Wordle hint and answer #619: Tuesday, February 28
 - [https://www.pcgamer.com/wordle-hint-answer-today-619-february-28](https://www.pcgamer.com/wordle-hint-answer-today-619-february-28)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 08:00:44+00:00

Trouble solving today's Wordle? Here's the help you need.

## Gen5 SSDs listings finally show up on Amazon and Newegg
 - [https://www.pcgamer.com/gen5-ssds-listings-finally-show-up-on-amazon-and-newegg](https://www.pcgamer.com/gen5-ssds-listings-finally-show-up-on-amazon-and-newegg)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 04:34:27+00:00

2TBs worth of 10GB/s write speeds.

## These new wooden panels give Corsair's PC cases a retro makeover
 - [https://www.pcgamer.com/these-new-wooden-panels-give-corsairs-pc-cases-a-retro-makeover](https://www.pcgamer.com/these-new-wooden-panels-give-corsairs-pc-cases-a-retro-makeover)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 03:14:27+00:00

It'll go great with your wicker gaming chair.

## One of Korea's best indie studios released a free-to-play game about a bus ride to hell
 - [https://www.pcgamer.com/one-of-koreas-best-indie-studios-released-a-free-to-play-game-about-a-bus-ride-to-hell](https://www.pcgamer.com/one-of-koreas-best-indie-studios-released-a-free-to-play-game-about-a-bus-ride-to-hell)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 02:35:44+00:00

The devs behind Lobotomy Corporation and Library of Ruina are at it again.

## Sons of the Forest cheats: How to spawn every item, including extra Kelvins
 - [https://www.pcgamer.com/sons-of-the-forest-cheats-console-commands](https://www.pcgamer.com/sons-of-the-forest-cheats-console-commands)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-28 00:04:49+00:00

Turn on godmode, give yourself every item and weapon, add extra followers, and more with Sons of the Forest console commands.

