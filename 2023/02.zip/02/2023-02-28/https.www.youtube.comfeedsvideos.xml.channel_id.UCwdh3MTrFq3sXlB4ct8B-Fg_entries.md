# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## The Long, Robotic Arm of the Law – Necromunda
 - [https://www.youtube.com/watch?v=cfasiXsVEy8](https://www.youtube.com/watch?v=cfasiXsVEy8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-02-28 13:00:25+00:00

The law is no longer black and white – it's now '1's and '0's. Meet the robotic law enforcement for Necromunda.

https://bit.ly/41ycxyz

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Learn to Paint: Stormcast Eternals Vindictors
 - [https://www.youtube.com/watch?v=B6-0bseBO9Q](https://www.youtube.com/watch?v=B6-0bseBO9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-02-28 10:00:38+00:00

Follow our step by step tutorial, using just the contents of the Stormcast Eternals Vindictors + Paints Set, to get your miniatures looking great in no time at all! 

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it: warhammer.me/3Vkojs6

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

