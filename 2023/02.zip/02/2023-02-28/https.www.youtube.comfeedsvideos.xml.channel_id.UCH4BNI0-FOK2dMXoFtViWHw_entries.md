# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## How Nature Creates Colors That Aren't Really There
 - [https://www.youtube.com/watch?v=wK7XjHbt4Z0](https://www.youtube.com/watch?v=wK7XjHbt4Z0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2023-02-28 14:40:38+00:00

Thank you to Brilliant for supporting PBS. To learn more, go to: https://brilliant.org/BeSmart/
↓↓↓ More info and sources below ↓↓↓


Why do we see rainbows in soap bubbles? What makes an oil slick so oddly beautiful? Iridescent colors, which transform depending on the angle you look at them, are all over nature. How does physics make these shifting rainbows? We’re going to find out with the help of the National Museum of Natural History's most spectacular specimens – from bird feathers and beetle wings to fossils and gemstones.

Check out some of my other videos about color in nature:
In search of the blackest thing on Earth https://youtu.be/86P03RlegBM 
Why is blue so rare in nature? https://youtu.be/3g246c6Bv58

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart

-----------

High fives to all our Brain Trust Patrons:

paul andre bouis
Mark Littlehale
Ali Freiburger
Mehdi Damou
Barbora Bei
Burt Humburg
Roy Lasris
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Eric Meer
Dustin
Karen Haskell

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

