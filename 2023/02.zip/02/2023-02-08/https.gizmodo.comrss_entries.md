# Source Gizmodo, Source URL:https://gizmodo.com/rss, Source language: en-US

## Disney’s Splash Remake Is Still Happening, With a New Writer
 - [https://gizmodo.com/disney-splash-remake-new-writer-jillian-bell-channing-t-1850089738](https://gizmodo.com/disney-splash-remake-new-writer-jillian-bell-channing-t-1850089738)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-09 00:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--oNVkxHUn--/c_fit,fl_progressive,q_80,w_636/1000fa116a9d67c52b5affd4babc1207.png" /><p>It’s been awhile since there’s been <a href="https://gizmodo.com/disney-is-remaking-splash-with-channing-tatum-but-not-1784657664">an update</a> on Disney’s planned <a href="https://gizmodo.com/the-disney-version-of-splash-includes-a-hilarious-hair-1842840864"><em>Splash</em></a> remake, and amid all <a href="https://gizmodo.com/disney-sequels-frozen-3-zootopia-2-toy-story-5-bob-iger-1850090994">the big studio news today</a>, there’s been some traction on the sea front. </p><p><a href="https://gizmodo.com/disney-splash-remake-new-writer-jillian-bell-channing-t-1850089738">Read more...</a></p>

## Disney Sets Its Sights on Toy Story, Frozen, and Zootopia Sequels
 - [https://gizmodo.com/disney-sequels-frozen-3-zootopia-2-toy-story-5-bob-iger-1850090994](https://gizmodo.com/disney-sequels-frozen-3-zootopia-2-toy-story-5-bob-iger-1850090994)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 23:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_hBWCTdA--/c_fit,fl_progressive,q_80,w_636/cbd6fcd742a2d4cc30a099e9f18b0731.jpg" /><p>During the <a href="https://gizmodo.com/disney100-cinematic-experiences-disneyland-disney-parks-1850049090">Walt Disney Company</a>’s Q1 call today, Disney CEO <a href="https://gizmodo.com/disney-ceo-bob-iger-replace-chapek-lucasfilm-marvel-1849807049">Bob Iger</a> announced the return of some major players in the studio’s franchise department: future installments of <a href="https://gizmodo.com/frozen-kingdom-named-at-fantasy-springs-tokyo-disneysea-1849721188"><em>Frozen</em></a><em>, Zootopia, </em>and <em>Toy Story </em>are on the way.<br /></p><p><a href="https://gizmodo.com/disney-sequels-frozen-3-zootopia-2-toy-story-5-bob-iger-1850090994">Read more...</a></p>

## Does the New DC Movie Universe Really Need to Be Connected?
 - [https://gizmodo.com/dc-movie-universe-james-gunn-dcu-superman-authority-1850089674](https://gizmodo.com/dc-movie-universe-james-gunn-dcu-superman-authority-1850089674)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 22:15:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--pdmVq-hG--/c_fit,fl_progressive,q_80,w_636/aec19fbb3f11dc0b63cc8dcfffced919.jpg" /><p>Since <a href="https://gizmodo.com/zack-snyders-grand-embellishments-make-justice-league-a-1846472019">Zack Snyder</a>’s <a href="https://gizmodo.com/the-most-important-scenes-from-man-of-steel-as-i-remem-516405346"><em>Man of Steel</em> </a>debuted back in 2013, Warner Bros.’ vision for a DC version of Marvel’s densely inter-connected, massively profitable MCU has been… haphazard to say the least. But now James Gunn and Peter Safran have been hired to shepherd an entirely (well, mostly) new DC cinematic universe, and they…</p><p><a href="https://gizmodo.com/dc-movie-universe-james-gunn-dcu-superman-authority-1850089674">Read more...</a></p>

## John Deere Takes Another Step in the Right Direction With Its First Electric Ride-on Mower
 - [https://gizmodo.com/john-deere-electric-ride-on-lawn-mower-z370r-price-orde-1850087894](https://gizmodo.com/john-deere-electric-ride-on-lawn-mower-z370r-price-orde-1850087894)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 21:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--iOaMXgZV--/c_fit,fl_progressive,q_80,w_636/97af5f78670ba24b77b8356b532e36ce.jpg" /><p>Sometimes, the convenience of a ride-on mower you don’t have to push is outweighed by the inconvenience of maintaining what is essentially another vehicle. But John Deere is promising no more oil changes, no more gas cans, and no more spark plugs with its <a href="https://www.deere.com/en/mowers/zero-turn-mowers/z300-series/z370r-ztrak-mower/" rel="noopener noreferrer" target="_blank">first all-electric zero turn mower</a>.<br /></p><p><a href="https://gizmodo.com/john-deere-electric-ride-on-lawn-mower-z370r-price-orde-1850087894">Read more...</a></p>

## Netflix Begins The Password Sharing Crackdown
 - [https://gizmodo.com/netflix-streaming-password-sharing-you-people-1850090698](https://gizmodo.com/netflix-streaming-password-sharing-you-people-1850090698)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 21:53:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--vBLOyk4K--/c_fit,fl_progressive,q_80,w_636/270959d4b247f31d5b5d22571dbf2074.jpg" /><p>For the past year, Netflix has remained incredibly cagey about how its password sharing restrictions will shape out in the coming months. Now, new restrictions on accounts in several worldwide markets might offer a small fraction of a squinting glimpse into how the company plans to stop users from sharing a password…</p><p><a href="https://gizmodo.com/netflix-streaming-password-sharing-you-people-1850090698">Read more...</a></p>

## Photos Show Aftermath of Toxic Train Derailment in Ohio
 - [https://gizmodo.com/ohio-train-derailment-photos-toxic-chemicals-1850087501](https://gizmodo.com/ohio-train-derailment-photos-toxic-chemicals-1850087501)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 21:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--miMBabmg--/c_fit,fl_progressive,q_80,w_636/bca9eef873786e2cb43fbd0f5fcd623c.jpg" /><p>Officials are continuing air and water quality tests near a derailed train in northeastern Ohio as evacuated area residents wait for news on when they can return, <a href="https://www.cleveland19.com/2023/02/08/east-palestine-residents-wait-see-when-they-can-return-home/" rel="noopener noreferrer" target="_blank">Cleveland 19 News reports</a>.</p><p><a href="https://gizmodo.com/ohio-train-derailment-photos-toxic-chemicals-1850087501">Read more...</a></p>

## Luxury Handbag Maker Wins Trademark Lawsuit Against ‘MetaBirkin’ NFT Maker
 - [https://gizmodo.com/nft-crypto-metabirkin-trademark-hermes-1850089765](https://gizmodo.com/nft-crypto-metabirkin-trademark-hermes-1850089765)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 21:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s---pvdJKaP--/c_fit,fl_progressive,q_80,w_636/5168155f4406b8593b9d246196aea882.jpg" /><p>Look to your left, and see an image of a famed, extremely expensive luxury Birkin-brand handbag. On your right, is a non-fungible token, a digital image whose rights of ownership are recorded on a blockchain. On Wednesday, a jury in New York decided that these MetaBirkin NFTs were indeed a big ripoff of the famous…</p><p><a href="https://gizmodo.com/nft-crypto-metabirkin-trademark-hermes-1850089765">Read more...</a></p>

## Virgin Orbit Suspects a $100 Part Took Down Its LauncherOne Rocket Last Month
 - [https://gizmodo.com/virgin-orbit-launcherone-rocket-filter-anomaly-1850088235](https://gizmodo.com/virgin-orbit-launcherone-rocket-filter-anomaly-1850088235)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 21:10:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--lhBDXZO5--/c_fit,fl_progressive,q_80,w_636/a6f97246e9a7df9cb302c770f24b959c.jpg" /><p>Last month, Virgin Orbit ran into trouble when its LauncherOne rocket crashed, destroying seven payloads on board in an attempt to deploy satellites in low Earth orbit. Now, the company suspects that the cause of the anomaly could have been a pesky filter that only cost around $100.<br /></p><p><a href="https://gizmodo.com/virgin-orbit-launcherone-rocket-filter-anomaly-1850088235">Read more...</a></p>

## Why Ant-Man and the Wasp: Quantumania Was Chosen as the First Film in Phase 5 of the MCU
 - [https://gizmodo.com/ant-man-3-phase-5-kevin-feige-kang-mcu-marvel-studios-1850089279](https://gizmodo.com/ant-man-3-phase-5-kevin-feige-kang-mcu-marvel-studios-1850089279)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 21:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--wKRPvqJq--/c_fit,fl_progressive,q_80,w_636/a3a66c3f9da375066113d4f4433404b2.jpg" /><p>Thanos may have been <a href="https://gizmodo.com/yes-thanos-is-hot-1825931804">big, powerful, and evil</a>, but imagine if there were billions of him. That’s just a taste of what makes Kang, played by Jonathan Majors, such a formidable villain for the future of the Marvel Cinematic Universe. First <a href="https://gizmodo.com/io9s-many-variants-chat-about-loki-season-2-and-the-f-1847300875">appearing in <em>Loki</em></a> as one version of himself, and soon to appear in <a href="https://gizmodo.com/ant-man-quantumania-villain-kang-jonathan-majors-mcu-1850085210"><em>Ant-Man and the</em>…</a></p><p><a href="https://gizmodo.com/ant-man-3-phase-5-kevin-feige-kang-mcu-marvel-studios-1850089279">Read more...</a></p>

## Donald Trump Begged Twitter to Delete a Tweet From Chrissy Teigen Calling Him a 'Pussy Ass Bitch'
 - [https://gizmodo.com/donald-trump-chrissy-teigen-tweet-hunter-biden-hearing-1850089753](https://gizmodo.com/donald-trump-chrissy-teigen-tweet-hunter-biden-hearing-1850089753)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 20:26:04+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--o2wAX8m7--/c_fit,fl_progressive,q_80,w_636/652bb0e2effc9b221a1b896f5e1bd7ab.jpg" /><p>House Republicans on Tuesday used their <a href="https://www.usnews.com/news/elections/articles/2022-11-16/republicans-take-control-of-house" rel="noopener noreferrer" target="_blank">newly won</a> majority to hold a hearing on one of their paramount issues: Hunter Biden’s <a href="https://gizmodo.com/twitter-files-hunter-biden-elon-musk-taibbi-explained-1849851303">laptop</a> and Twitter’s <a href="https://gizmodo.com/house-committee-weaponization-government-set-hearings-1849967024">alleged</a> efforts to censor conservative viewpoints at the behest of the federal government. The event was a disaster, filled with raucous lawmakers, real-time…</p><p><a href="https://gizmodo.com/donald-trump-chrissy-teigen-tweet-hunter-biden-hearing-1850089753">Read more...</a></p>

## Indie Games Get the Spotlight During Zine Month
 - [https://gizmodo.com/zine-month-indie-games-ttrpgs-horror-fantasy-scifi-1850082416](https://gizmodo.com/zine-month-indie-games-ttrpgs-horror-fantasy-scifi-1850082416)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 20:20:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--RwpBltmY--/c_fit,fl_progressive,q_80,w_636/7745ad5f7e727c293d4afc8ef8e1a8dd.jpg" /><p>It’s hard to describe the scope of the <a href="https://gizmodo.com/prime-day-table-top-role-playing-games-indie-ttrpg-1849168553">indie</a> <a href="https://gizmodo.com/gaming-shelf-new-indie-rpgs-crowdfunding-kickstarter-1850053821">tabletop roleplaying</a> scene during an average month, but it’s never more difficult than in February. For the past three years, February has been home to <a href="https://gizmodo.com/as-zine-month-wraps-up-game-designers-ponder-a-future-1848628186">Zine Month</a>—or ZiMo—during which indie TTRPGs attempt to crowdfund books and games.</p><p><a href="https://gizmodo.com/zine-month-indie-games-ttrpgs-horror-fantasy-scifi-1850082416">Read more...</a></p>

## Florida Man vs Florida Man: Trump Suggests DeSantis Was 'Grooming' and Partying With Underage Girls
 - [https://gizmodo.com/donald-trump-ron-desantis-truth-social-florida-man-1850089596](https://gizmodo.com/donald-trump-ron-desantis-truth-social-florida-man-1850089596)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 19:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--VeY-Yqbb--/c_fit,fl_progressive,q_80,w_636/cd36a6d5556ee26bd14ee05a42edb774.jpg" /><p>Former President <a href="https://gizmodo.com/donald-trump-truth-social-twitter-facebook-tmtg-1850017818">Donald Trump</a> appeared to accuse Gov. Ron DeSantis (R-Florida) of “grooming” and partying with underage high school girls in a Truth Social post on Tuesday. <a href="https://truthsocial.com/@realDonaldTrump/posts/109825049366738123" rel="noopener noreferrer" target="_blank">Trump “reTruthed” the photo</a> from a post by Dong-Chan Lee who is a self-described “paleoconservative” and a supporter of Trump, who had attached a…</p><p><a href="https://gizmodo.com/donald-trump-ron-desantis-truth-social-florida-man-1850089596">Read more...</a></p>

## Everything Introduced Into the Marvel Cinematic Universe in Phase 4
 - [https://gizmodo.com/marvel-phase-4-new-characters-wandavision-black-panther-1850078196](https://gizmodo.com/marvel-phase-4-new-characters-wandavision-black-panther-1850078196)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 19:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--2hCkWcX---/c_fit,fl_progressive,q_80,w_636/1c339a48b61d9a88d4fd4faaf4e98829.jpg" /><p>With Phase Four of the <a href="https://gizmodo.com/guardians-of-the-galaxy-holiday-special-review-marvel-1849812929">Marvel Cinematic Universe now over</a>, you might be wondering exactly what it accomplished. From January 2021 to November 2022, Marvel Studios released 18 projects, an output almost equal to the <a href="https://gizmodo.com/avengers-endgame-is-overwhelmingly-epic-and-immensely-1834240218">entire 11-year MCU before it</a>. But, without an Avengers film to wrap everything up in the end, it’s hard…</p><p><a href="https://gizmodo.com/marvel-phase-4-new-characters-wandavision-black-panther-1850078196">Read more...</a></p>

## Apple Could Fix a Major HomeKit Bug in Next iOS Beta
 - [https://gizmodo.com/apple-homekit-bug-ios-beta-fix-when-smart-home-link-new-1850089093](https://gizmodo.com/apple-homekit-bug-ios-beta-fix-when-smart-home-link-new-1850089093)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 19:05:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--LPcT5kk2--/c_fit,fl_progressive,q_80,w_636/mdvgcmm12mav5qjwhlny.jpg" /><p>Were you one of the many users affected by the iOS 16.2 HomeKit architecture bug that, among other issues, prevented users from adding new devices to their network? The good news is that Apple will likely send a fix for it in the next software update.<br /></p><p><a href="https://gizmodo.com/apple-homekit-bug-ios-beta-fix-when-smart-home-link-new-1850089093">Read more...</a></p>

## Hospitals Sell Your Medical Data to Advertisers. A New Lawsuit Wants to Hold One Accountable.
 - [https://gizmodo.com/cedars-sinai-data-lawsuit-google-facebook-microsoft-1850088263](https://gizmodo.com/cedars-sinai-data-lawsuit-google-facebook-microsoft-1850088263)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 18:53:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Y3R5b7mu--/c_fit,fl_progressive,q_80,w_636/f94345999b749e906fc8d961e7e5cfc2.jpg" /><p>Cedars-Sinai Medical Center, the 886-bed hospital where I was born in Los Angeles, has a privacy problem. If you head to the Cedars website today you’ll be greeted by six ad trackers and 17 third-party cookies—according to <a href="https://themarkup.org/blacklight?url=www.cedars-sinai.org" rel="noopener noreferrer" target="_blank">the Markup’s Backlight</a> tool—and, apparently, that’s an improvement. A class action lawsuit filed…</p><p><a href="https://gizmodo.com/cedars-sinai-data-lawsuit-google-facebook-microsoft-1850088263">Read more...</a></p>

## How The Purge Series Holds a Mirror Up to America
 - [https://gizmodo.com/horror-noire-the-black-guy-dies-first-film-book-excerpt-1850006853](https://gizmodo.com/horror-noire-the-black-guy-dies-first-film-book-excerpt-1850006853)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 18:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ljibSEtW--/c_fit,fl_progressive,q_80,w_636/59a734fa443d83a233577cb345c4fec6.jpg" /><p>From two of the film experts behind the excellent <a href="https://gizmodo.com/10-frightful-picks-to-get-you-started-with-that-free-sh-1842756268">Shudder documentary<em> Horror Noire</em></a>—Dr. Robin R. Means Coleman, who wrote the book the doc is based on: <em>Horror Noire: Blacks in American Horror Films from the 1890s to Present</em>; and entertainment journalist Mark H. Harris—comes <em>The Black Guy Dies First</em>, a look at <a href="https://gizmodo.com/shudders-horror-noire-combines-6-tales-of-terror-in-a-s-1847867916">Black…</a></p><p><a href="https://gizmodo.com/horror-noire-the-black-guy-dies-first-film-book-excerpt-1850006853">Read more...</a></p>

## Whoa: Astronomers Find New Ring System in the Outer Solar System
 - [https://gizmodo.com/astronomers-discover-ring-system-dwarf-planet-quaoar-1850087651](https://gizmodo.com/astronomers-discover-ring-system-dwarf-planet-quaoar-1850087651)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 18:06:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--gPBvxY6o--/c_fit,fl_progressive,q_80,w_636/49ba19c261ff8e01068c2d378dcec069.jpg" /><p>Researchers observing a background star pass behind Quaoar, a dwarf planet in the Kuiper belt, found that the distant object has a ring system unlike any previously found in our solar system.</p><p><a href="https://gizmodo.com/astronomers-discover-ring-system-dwarf-planet-quaoar-1850087651">Read more...</a></p>

## Becoming Besties with Rachel and Sarah | YOLO: Silver Destiny
 - [https://gizmodo.com/becoming-besties-rachel-and-sarah-yolo-silver-destiny-1850023101](https://gizmodo.com/becoming-besties-rachel-and-sarah-yolo-silver-destiny-1850023101)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 18:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Z9gBPSX7--/c_fit,fl_progressive,q_80,w_636/17d4ab7d3f14535203a0cf206edf02aa.jpg" /><p><a href="https://gizmodo.com/becoming-besties-rachel-and-sarah-yolo-silver-destiny-1850023101">Read more...</a></p>

## Uber Drivers Completed 2.1 Million Trips as Company Reports 'Strongest Quarter Ever'
 - [https://gizmodo.com/uber-ride-share-uber-eats-ride-hail-1850088458](https://gizmodo.com/uber-ride-share-uber-eats-ride-hail-1850088458)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 17:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--IcpXf_mc--/c_fit,fl_progressive,q_80,w_636/8175c3eb2d987e3c8aa7cc630dd744f5.jpg" /><p><a href="https://gizmodo.com/uber-ads-ride-share-uber-eats-1849678092">Uber</a> announced it reached a record revenue last year<strong>, </strong>overcoming the <a href="https://gizmodo.com/the-12-biggest-tech-layoffs-of-the-year-so-far-1849372352">economic downturn many companies have faced</a> in recent months. The company released its <a href="https://s23.q4cdn.com/407969754/files/doc_financials/2022/q4/Uber-Q4-22-Earnings-Press-Release.pdf" rel="noopener noreferrer" target="_blank">report</a> announcing the results from its fourth quarter and for all of 2022, saying its revenue grew by 49% between 2021 and last year. </p><p><a href="https://gizmodo.com/uber-ride-share-uber-eats-ride-hail-1850088458">Read more...</a></p>

## Secret Russian Satellite Breaks Apart for Second Time, Spawning Debris Cloud
 - [https://gizmodo.com/russian-satellite-breaks-up-orbit-kosmos-2499-1850088333](https://gizmodo.com/russian-satellite-breaks-up-orbit-kosmos-2499-1850088333)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 17:25:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_72nAnhI--/c_fit,fl_progressive,q_80,w_636/30e5a5790d4f75f218855f5d38d4720a.jpg" /><p>A mysterious Russian satellite that launched to space in 2014 has experienced its second breakup event. The cause of Kosmos-2499’s demise is unknown, and we may never find out the truth, given the satellite’s veiled and suspicious history.<br /></p><p><a href="https://gizmodo.com/russian-satellite-breaks-up-orbit-kosmos-2499-1850088333">Read more...</a></p>

## A Man’s Prostate Cancer Gave Him An 'Uncontrollable' Irish Accent
 - [https://gizmodo.com/prostate-cancer-caused-irish-accent-medical-case-1850088239](https://gizmodo.com/prostate-cancer-caused-irish-accent-medical-case-1850088239)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 17:05:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--zuf4bUNa--/c_fit,fl_progressive,q_80,w_636/1882f3df692ec42469e16d898b319923.jpg" /><p>A man’s prostate cancer came with a bizarre complication: an Irish accent. The case is one of the few documented reports of the condition, and reportedly the first ever associated with this form of cancer. Tragically, the man ultimately died from his illness.<br /></p><p><a href="https://gizmodo.com/prostate-cancer-caused-irish-accent-medical-case-1850088239">Read more...</a></p>

## Japan's Spirited Away Stage Play Is Coming to America, Basically
 - [https://gizmodo.com/spirited-away-live-on-stage-play-us-miyazaki-ghibli-1850088096](https://gizmodo.com/spirited-away-live-on-stage-play-us-miyazaki-ghibli-1850088096)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 17:03:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--O9DwYvZR--/c_fit,fl_progressive,q_80,w_636/7c747270b402e51c7730a7dc9ca9904b.jpg" /><p>If you heard the news that Japan would be getting a <a href="https://gizmodo.com/hayao-miyazaki-s-spirited-away-stage-play-looks-fantast-1848732915">live, theatrical stage play</a> version of <a href="https://gizmodo.com/hayao-miyazaki-ghibli-how-do-you-live-release-date-1849887285">Hayao Miyazaki</a>’s acclaimed, Academy Award-winning film <a href="https://gizmodo.com/its-time-to-dive-into-the-beautiful-world-of-studio-ghi-1845169591"><em>Spirited Away</em></a><em> </em>and burned with a longing to see it... well, I have mostly good news. The stageplay is finally coming to America, it just won’t be quite as live as if you had…</p><p><a href="https://gizmodo.com/spirited-away-live-on-stage-play-us-miyazaki-ghibli-1850088096">Read more...</a></p>

## Teenage Engineering Now Has a $1,600 Desk To Hold Its $1,200 Mixer and $2,000 Musical Toys
 - [https://gizmodo.com/teenage-engineering-field-desk-1600-plywood-expensive-1850088339](https://gizmodo.com/teenage-engineering-field-desk-1600-plywood-expensive-1850088339)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 16:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--uO3zCFI3--/c_fit,fl_progressive,q_80,w_636/ee157245b87faac8d711cbfcb19787be.jpg" /><p>If you’ve decided your tastes are too refined to work on a sheet of plywood precariously balanced on a couple stacks of cinderblocks, Teenage Engineering is back with another peculiar product with a barebones design: the <a href="https://teenage.engineering/products/field-desk" rel="noopener noreferrer" target="_blank">minimalist Field Desk</a> you build yourself using a modular aluminum rail system.</p><p><a href="https://gizmodo.com/teenage-engineering-field-desk-1600-plywood-expensive-1850088339">Read more...</a></p>

## Google Bungles AI Reveal With Incorrect Webb Telescope Facts
 - [https://gizmodo.com/google-bard-ai-ad-incorrect-webb-telescope-facts-1850087798](https://gizmodo.com/google-bard-ai-ad-incorrect-webb-telescope-facts-1850087798)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 16:42:00+00:00
 - user: None

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--IbfnJctk--/c_fit,fl_progressive,q_80,w_636/f5319d5b880b9e836cba01f84a195488.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--SNddTa_k--/c_fit,fl_progressive,q_80,w_636/f5319d5b880b9e836cba01f84a195488.mp4" type="video/mp4" /></video><p>Google announced its <a href="https://gizmodo.com/bard-google-chatgpt-ai-microsoft-bing-1850079014">much-hyped AI-powered chatbot</a> this week as part of a rapidly intensifying AI arms race between tech heavy-hitters. The tool is the company’s response to <a href="https://gizmodo.com/chatgpt-apps-ai-microsoft-google-1850065429">OpenAI’s ChatGPT</a> and <a href="https://gizmodo.com/microsoft-openai-chatgpt-bing-1850019904">Microsoft’s swift maneuvering</a> to incorporate that large language tool into <a href="https://gizmodo.com/bing-microsoft-chatgpt-ai-microsoft-edge-1850084072">its Bing search engine</a>. But there’s one big…</p><p><a href="https://gizmodo.com/google-bard-ai-ad-incorrect-webb-telescope-facts-1850087798">Read more...</a></p>

## Who’s the Next Killer in the Disney Creative Commons Murderverse?
 - [https://gizmodo.com/winnie-the-pooh-blood-and-honey-murder-slasher-film-1850088134](https://gizmodo.com/winnie-the-pooh-blood-and-honey-murder-slasher-film-1850088134)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 16:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--P3JjPhdL--/c_fit,fl_progressive,q_80,w_636/7020d47705930fb4c7c31f3b50522284.png" /><p>The global release of <a href="https://gizmodo.com/winnie-the-pooh-horror-movie-trailer-blood-and-honey-1849479054"><em>Winnie-the-Pooh: Blood and Honey</em></a> is happening in a week, and ahead of the premiere, writer/director Rhys Frake-Waterfield told <a href="https://www.hollywoodreporter.com/movies/movie-news/winnie-the-pooh-bood-honey-bambi-peter-pan-horror-universe-1235320371/" rel="noopener noreferrer" target="_blank"><em>The Hollywood Reporter</em></a> that “he’s planning to create an <a href="https://gizmodo.com/bambi-the-reckoning-horror-movie-1849824011">entire universe</a> filled with bloodied X-rated adaptations of beloved childhood stories.”<br /></p><p><a href="https://gizmodo.com/winnie-the-pooh-blood-and-honey-murder-slasher-film-1850088134">Read more...</a></p>

## Ghostface Plays a Deadly Game of Chutes & Ladders in New Scream VI Teaser
 - [https://gizmodo.com/scream-vi-ghostface-trailer-big-game-teaser-1850087866](https://gizmodo.com/scream-vi-ghostface-trailer-big-game-teaser-1850087866)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 16:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--pAVrg3pN--/c_fit,fl_progressive,q_80,w_636/f8bcac7c7d83587f1bad9b2d62313732.jpg" /><p>There’s only a little more than a month before the sixth installment of the <a href="https://gizmodo.com/scream-6-is-officially-a-go-from-the-team-behind-scream-1848476087"><em>Scream</em></a> franchise stalks its way into New York City and theaters, but no movie with a generously-sized budget would miss the chance to promote itself during what sponsors have to generically call “the big game.” But rather than discuss the <a href="https://gizmodo.com/scream-6-trailer-horror-nyc-courtney-cox-jenna-ortega-1850005866">…</a></p><p><a href="https://gizmodo.com/scream-vi-ghostface-trailer-big-game-teaser-1850087866">Read more...</a></p>

## Elon Musk Unlocks Twitter Account of Senator Who Made a Dead Antelope His Profile Pic
 - [https://gizmodo.com/twitter-reinstates-steve-daines-antelope-hunting-pic-1850087534](https://gizmodo.com/twitter-reinstates-steve-daines-antelope-hunting-pic-1850087534)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 15:38:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KaL-MTva--/c_fit,fl_progressive,q_80,w_636/49bc6678e4d73e7d4a1281d3a422d569.png" /><p>Twitter owner and <a href="https://gizmodo.com/elon-musk-twitter-private-tweet-1850061253?_ga=2.82998678.1091534379.1675081309-274569629.1674562446">chief micromanager Elon Musk</a> stepped in to unlock the account of Republican Sen. Steve Daines of Montana, who got sent to blue bird jail after changing his profile picture to a selfie of him and his wife with a dead antelope on a hunting trip. </p><p><a href="https://gizmodo.com/twitter-reinstates-steve-daines-antelope-hunting-pic-1850087534">Read more...</a></p>

## This Plant-Based Salmon Looks, Tastes, Cooks, and Flakes Like the Real Thing
 - [https://gizmodo.com/vegan-salmon-plant-based-meat-impossible-beyond-burger-1850087658](https://gizmodo.com/vegan-salmon-plant-based-meat-impossible-beyond-burger-1850087658)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 15:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s---Ulkjy-8--/c_fit,fl_progressive,q_80,w_636/a4cced90568d0db72924742bf7484081.jpg" /><p>We can chalk up <a href="https://gizmodo.com/vegan-poached-eggs-high-prices-us-california-yo-egg-1850082229">another victory</a> for food scientists this month as Toronto-based <a href="https://www.newschoolfoods.co/" rel="noopener noreferrer" target="_blank">New School Foods</a> debuted a plant-based salmon alternative that <a href="https://techcrunch.com/2023/02/02/new-school-foods-salmon-foodtech/" rel="noopener noreferrer" target="_blank">delivers the experience of eating the fish</a>—including the flavor and texture of a cooked filet—without needing you to consume any actual salmon.</p><p><a href="https://gizmodo.com/vegan-salmon-plant-based-meat-impossible-beyond-burger-1850087658">Read more...</a></p>

## Google Shows Off AI Advancements, in Search Results and Beyond
 - [https://gizmodo.com/google-ai-bard-maps-chatgpt-microsoft-1850087406](https://gizmodo.com/google-ai-bard-maps-chatgpt-microsoft-1850087406)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 15:25:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--P3T6MgDK--/c_fit,fl_progressive,q_80,w_636/8d07e7fe131d628a3da602b3f6730e1e.jpg" /><p>Google plans to begin including AI-generated text answers to search queries in the coming months. The announcement came at the company’s (kind of slapdash) live event in Paris on Wednesday, along with numerous other updates to Search, Maps, and more.<br /></p><p><a href="https://gizmodo.com/google-ai-bard-maps-chatgpt-microsoft-1850087406">Read more...</a></p>

## Users Claim Twitter Isn’t Deleting Their DM Data When Asked
 - [https://gizmodo.com/twitter-dm-end-to-end-encryption-elon-musk-1850087497](https://gizmodo.com/twitter-dm-end-to-end-encryption-elon-musk-1850087497)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 15:15:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--6YTSkB14--/c_fit,fl_progressive,q_80,w_636/00f866c92ff16ef5675eb0ffb2f4c7f4.jpg" /><p>Remember last August, when an ex-Twitter executive Peiter “Mudge” Zatko accused the blue bird app of routinely <a href="https://gizmodo.com/twitter-whistleblower-security-elon-musk-1849445911">failing to delete users’ information</a> from the platform when they deleted their accounts? Well, it seems under the new stewardship of billionaire Elon Musk, Twitter is still failing to delete users’…</p><p><a href="https://gizmodo.com/twitter-dm-end-to-end-encryption-elon-musk-1850087497">Read more...</a></p>

## Keanu Reeves' Constantine 2 Still in the Works Despite DC Shakeup
 - [https://gizmodo.com/constantine-2-keanu-reeves-dc-harley-quinn-madam-web-1850082564](https://gizmodo.com/constantine-2-keanu-reeves-dc-harley-quinn-madam-web-1850082564)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 15:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--dUbKVS-h--/c_fit,fl_progressive,q_80,w_636/ce42bb090223d5e47ea250d49521dfe2.png" /><p>Will I ever truly understand why I love <a href="https://gizmodo.com/constantine-gabriel-tilda-swinton-keanu-reeves-angel-1849575770"><em>Constantine </em>(2005)</a> so much? No. But this was a weird time for a lot of comic films, nestled in between awkward, over-CGI’d family films like <em>Hulk</em> and rated-R weirdness like <a href="https://gizmodo.com/blade-marvel-lovecraft-country-director-yann-demange-1849810031"><em>Blade</em></a> and <em>Blade 2</em>. Something about <a href="https://gizmodo.com/constantine-was-rated-r-mostly-because-it-was-moody-1844506582"><em>Constantine</em></a>, which merged a hardboiled detective story and an eternal…</p><p><a href="https://gizmodo.com/constantine-2-keanu-reeves-dc-harley-quinn-madam-web-1850082564">Read more...</a></p>

## Scientists Discover Molten Layer of Rock Beneath Earth's Crust
 - [https://gizmodo.com/scientists-find-molten-layer-rock-beneath-earths-crust-1850084167](https://gizmodo.com/scientists-find-molten-layer-rock-beneath-earths-crust-1850084167)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 14:35:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Ba_XEWhy--/c_fit,fl_progressive,q_80,w_636/56a4963728c89d1079503b71bcd43a49.jpg" /><p>Earthquakes and volcanic eruptions are a result of the movement of large swaths of Earth’s crust, but while the theory of plate tectonics has been widely accepted as a fundamental law of geology, there are still things to be discovered. New research from the University of Texas Austin points to the presence of a…</p><p><a href="https://gizmodo.com/scientists-find-molten-layer-rock-beneath-earths-crust-1850084167">Read more...</a></p>

## Google Will Blur Explicit Images Even When SafeSearch Is Turned Off
 - [https://gizmodo.com/google-safe-search-porn-explicit-content-ai-1850087307](https://gizmodo.com/google-safe-search-porn-explicit-content-ai-1850087307)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 14:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--3ijzL2Vj--/c_fit,fl_progressive,q_80,w_636/163161833459a22511c3b263fa3e4894.jpg" /><p>Google’s search engine is getting an upgrade—<a href="https://gizmodo.com/bard-google-chatgpt-ai-microsoft-bing-1850079014">yes with AI</a>, but also with a blur filter. In a bid to shield its user’s eyes, <a href="https://gizmodo.com/google-alphabet-mental-health-well-being-layoffs-1850048313">Google</a> announced yesterday that it will blur explicit images in search results, even when SafeSearch isn’t turned on.<br /></p><p><a href="https://gizmodo.com/google-safe-search-porn-explicit-content-ai-1850087307">Read more...</a></p>

## If You’ve Ever Posted Anything Online, ChatGPT Has Probably Seen It
 - [https://gizmodo.com/chatgpt-free-ai-privacy-policy-posts-google-bard-bing-1850087438](https://gizmodo.com/chatgpt-free-ai-privacy-policy-posts-google-bard-bing-1850087438)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 14:25:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--FP2P0eWH--/c_fit,fl_progressive,q_80,w_636/8b77f14107ecdec613275d345ff7da10.jpg" /><p>ChatGPT has taken the world by storm. Within two months of its release it reached 100 million <a href="https://news.yahoo.com/chatgpt-100-million-users-january-130619073.html" rel="noopener noreferrer" target="_blank">active users</a>, making it the fastest-growing consumer <a href="https://www.reuters.com/technology/chatgpt-sets-record-fastest-growing-user-base-analyst-note-2023-02-01/" rel="noopener noreferrer" target="_blank">application ever launched</a>. Users are attracted to the tool’s <a href="https://oneusefulthing.substack.com/p/chatgtp-is-my-co-founder" rel="noopener noreferrer" target="_blank">advanced capabilities</a> – and concerned by its potential to cause disruption in <a href="https://theconversation.com/chatgpt-students-could-use-ai-to-cheat-but-its-a-chance-to-rethink-assessment-altogether-198019" rel="noopener noreferrer" target="_blank">various sectors</a>.<br /></p><p><a href="https://gizmodo.com/chatgpt-free-ai-privacy-policy-posts-google-bard-bing-1850087438">Read more...</a></p>

## Wikipedia Worries Its Volunteer Editors Could Be Liable to Lawsuits Without Section 230
 - [https://gizmodo.com/wikipedia-section-230-scotus-encyclopedia-1850085090](https://gizmodo.com/wikipedia-section-230-scotus-encyclopedia-1850085090)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 13:15:00+00:00
 - user: rumpel
 - tags: censorship,law,wikipedia

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--MNrJ0rg7--/c_fit,fl_progressive,q_80,w_636/4fde4c6bef9bffc156863c2854ea9d7c.jpg" /><p>Where does Wikipedia, the world’s most-visited repository of information on the internet, stand without guaranteed digital liability protections? It’s a question weighing heavy on the people who make up the Wikimedia Foundation, the nonprofit organization that administers the site containing 58 million articles in…</p><p><a href="https://gizmodo.com/wikipedia-section-230-scotus-encyclopedia-1850085090">Read more...</a></p>

## Thanks I Hate It: Twitter Starts Testing Out 4,000 Character Tweets
 - [https://gizmodo.com/twitter-tweets-character-limit-elon-musk-1850084557](https://gizmodo.com/twitter-tweets-character-limit-elon-musk-1850084557)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 13:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--R7cW9BXz--/c_fit,fl_progressive,q_80,w_636/04a9741b2d3ffc5ca8aacc386b721bb3.jpg" /><p>If you’ve ever been scrolling through Twitter and thought to yourself, ‘I wish all of these posts were SO MUCH longer,” then today is your lucky day. If, however, you are a reasonably well-adjusted internet-user, I unfortunately come bearing bad news. Twitter appears to be officially experimenting with 4,000 character…</p><p><a href="https://gizmodo.com/twitter-tweets-character-limit-elon-musk-1850084557">Read more...</a></p>

## Zoo Says Ape’s Mysterious Pregnancy Occurred Through a Hole in the Wall, Literally
 - [https://gizmodo.com/gibbon-japan-mystery-pregnancy-solved-hole-in-the-wall-1850087026](https://gizmodo.com/gibbon-japan-mystery-pregnancy-solved-hole-in-the-wall-1850087026)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 13:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--qrimLnRb--/c_fit,fl_progressive,q_80,w_636/d9385a9e5cd30b533220e5cf36389254.jpg" /><p>Japanese zookeepers have finally how Momo, their 12-year-old white-handed gibbon, got pregnant even though she lived by herself and had never had a male visitor. The key? A literal hole in the wall. </p><p><a href="https://gizmodo.com/gibbon-japan-mystery-pregnancy-solved-hole-in-the-wall-1850087026">Read more...</a></p>

## Top Android Phones From China Are Packed With Spyware, Research Finds
 - [https://gizmodo.com/android-xiamoi-oneplus-phones-personal-info-study-1850082989](https://gizmodo.com/android-xiamoi-oneplus-phones-personal-info-study-1850082989)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 11:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--vcH0it_o--/c_fit,fl_progressive,q_80,w_636/d65d3022a3961722f02097fc29d8feb9.jpg" /><p>New research suggests that users of top-of-the-line Android devices sold in China are getting their personal data pilfered left, right and center, according to new research. The collection, which is happening without notification or consent, could easily lead to the persistent tracking of users and the easy unmasking…</p><p><a href="https://gizmodo.com/android-xiamoi-oneplus-phones-personal-info-study-1850082989">Read more...</a></p>

## Joe Biden Says Tech Needs Washington’s Parental Oversight in State of the Union
 - [https://gizmodo.com/joe-biden-state-of-the-union-facebook-amazon-apple-goog-1850085467](https://gizmodo.com/joe-biden-state-of-the-union-facebook-amazon-apple-goog-1850085467)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 04:43:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--gbU46v1I--/c_fit,fl_progressive,q_80,w_636/7d4252460029aa0ffe09f864af76591e.jpg" /><p>President Joe Biden took direct aim at tech companies during his second State of the Union address Tuesday evening. Over the course of an hour, the president railed against Big Tech’s  data collection practices, its use of targeting ads on young users and anti-competitive business practices. For all of those issues,…</p><p><a href="https://gizmodo.com/joe-biden-state-of-the-union-facebook-amazon-apple-goog-1850085467">Read more...</a></p>

## Researchers Decrypt Coded Letters Written by Mary, Queen of Scots
 - [https://gizmodo.com/coded-letters-mary-queen-scots-decrypted-1850084477](https://gizmodo.com/coded-letters-mary-queen-scots-decrypted-1850084477)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 00:01:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--lwGyT8cy--/c_fit,fl_progressive,q_80,w_636/62a4c1fd727d5c34f283396a73ea35eb.jpg" /><p>A computer scientist, a musician, and a physicist enter the archives of a national library. It sounds like the beginning of a joke, but the punchline is a serious one: Researchers of various backgrounds managed to find and decipher 57 letters written by Mary, Queen of Scots during her imprisonment by her cousin Queen…</p><p><a href="https://gizmodo.com/coded-letters-mary-queen-scots-decrypted-1850084477">Read more...</a></p>

## Jonathan Majors Breaks Down the Essence of Kang in the Marvel Cinematic Universe
 - [https://gizmodo.com/ant-man-quantumania-villain-kang-jonathan-majors-mcu-1850085210](https://gizmodo.com/ant-man-quantumania-villain-kang-jonathan-majors-mcu-1850085210)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-08 00:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--yqDdvrse--/c_fit,fl_progressive,q_80,w_636/b62f8499e2b3a868f0405d2ed84264a3.jpg" /><p>With the release of <a href="https://gizmodo.com/ant-man-and-wasp-quantumania-reactions-marvel-paul-rudd-1850077940"><em>Ant-Man and the Wasp: Quantumania</em></a>, audiences are about to really get a glimpse of <a href="https://gizmodo.com/antman-and-the-wasp-phase-5-kevin-feige-marvel-studios-1850031832">the future of the Marvel Cinematic Universe</a>. <a href="https://gizmodo.com/ant-man-3-trailer-the-wasp-quantumania-marvel-studios-1849965595">His name is Kang</a> and he’s played by Jonathan Majors. Majors made his Marvel debut last year in <a href="https://gizmodo.com/lokis-finale-asks-if-time-is-inevitable-or-just-marvel-1847288500"><em>Loki</em></a> as He Who Remains, a version of a supervillain who is going to have such…</p><p><a href="https://gizmodo.com/ant-man-quantumania-villain-kang-jonathan-majors-mcu-1850085210">Read more...</a></p>
