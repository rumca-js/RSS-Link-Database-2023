# Source Washington Examiner - politics, Source URL:https://feeds.feedburner.com/dcexaminer/Politics, Source language: en-US

## Sanders says Biden administration 'doubling down on crazy'
 - [https://www.washingtonexaminer.com/news/sanders-says-biden-administration-doubling-down-on-crazy](https://www.washingtonexaminer.com/news/sanders-says-biden-administration-doubling-down-on-crazy)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-02-08 16:48:16+00:00
 - user: None

(The Center Square) - Arkansas Gov. Sarah Huckabee Sanders said President Joe Biden's administration is hijacked by the "radical left" and called for a new generation of Republican leadership in the GOP response to the president's State of the Union address.
