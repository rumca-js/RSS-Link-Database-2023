# Source NBC tech, Source URL:https://feeds.nbcnews.com/nbcnews/public/tech, Source language: en-US

## Twitter experiences widespread disruption as users get error message trying to post
 - [https://www.nbcnews.com/tech/tech-news/twitter-disruption-users-get-error-message-rcna69822](https://www.nbcnews.com/tech/tech-news/twitter-disruption-users-get-error-message-rcna69822)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-02-08 22:30:36+00:00
 - user: None

SAN FRANCISCO — Twitter experienced widespread problems Wednesday as users trying to post instead got error messages, the most serious disruption in the service since Elon Musk bought it in October.

## Disney to cut 7,000 jobs as it slashes costs and reorganizes
 - [https://www.nbcnews.com/business/business-news/disney-cut-7000-jobs-slashes-costs-reorganizes-rcna69817](https://www.nbcnews.com/business/business-news/disney-cut-7000-jobs-slashes-costs-reorganizes-rcna69817)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-02-08 22:28:57+00:00
 - user: None

Disney said Wednesday it is planning to reorganize into three segments.

## Microsoft’s new Bing chatbot is fun but sometimes more cautious than ChatGPT
 - [https://www.nbcnews.com/tech/tech-news/microsofts-bing-chatbot-fun-cautious-chatgpt-rcna69689](https://www.nbcnews.com/tech/tech-news/microsofts-bing-chatbot-fun-cautious-chatgpt-rcna69689)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-02-08 14:16:01+00:00
 - user: None

Microsoft has given a small group of people early access to the new version of its Bing search engine boosted with artificial intelligence courtesy of startup OpenAI, the maker of ChatGPT.
