# Source BBC tech, Source URL:http://feeds.bbci.co.uk/news/technology/rss.xml, Source language: en-US

## Google's Bard AI bot mistake wipes $100bn off shares
 - [https://www.bbc.co.uk/news/business-64576225?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64576225?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-02-08 23:32:27+00:00
 - user: None

An advert to promote the new Bard software shows it answering a query incorrectly.

## Netflix limits account sharing in four more countries
 - [https://www.bbc.co.uk/news/business-64573517?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64573517?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-02-08 22:35:45+00:00
 - user: None

New rules are being introduced in Canada, New Zealand, Portugal and Spain, before further roll out.

## NFT images of furry Birkin bags violated trademark rules
 - [https://www.bbc.co.uk/news/business-64573513?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64573513?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-02-08 20:01:51+00:00
 - user: None

Hermes, which owns the brand, has won a landmark case against an artist who created NFTs of the famous bag.
