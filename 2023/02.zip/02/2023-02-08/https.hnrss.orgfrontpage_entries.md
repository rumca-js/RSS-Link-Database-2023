# Source Hacker News - frontpage, Source URL:https://hnrss.org/frontpage, Source language: en-US

## Covid drug drives viral mutations – and now some want to halt its use
 - [https://www.nature.com/articles/d41586-023-00347-z](https://www.nature.com/articles/d41586-023-00347-z)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 23:51:19+00:00
 - user: None

<p>Article URL: <a href="https://www.nature.com/articles/d41586-023-00347-z">https://www.nature.com/articles/d41586-023-00347-z</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34717514">https://news.ycombinator.com/item?id=34717514</a></p>
<p>Points: 19</p>
<p># Comments: 2</p>

## Photoprism – open-source Google Photos Alternative
 - [https://www.photoprism.app/](https://www.photoprism.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 23:06:04+00:00
 - user: None

<p>Article URL: <a href="https://www.photoprism.app/">https://www.photoprism.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34716924">https://news.ycombinator.com/item?id=34716924</a></p>
<p>Points: 40</p>
<p># Comments: 13</p>

## Apache Kafka Beyond the Basics: Windowing
 - [https://www.confluent.io/blog/windowing-in-kafka-streams/](https://www.confluent.io/blog/windowing-in-kafka-streams/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 22:56:29+00:00
 - user: None

<p>Article URL: <a href="https://www.confluent.io/blog/windowing-in-kafka-streams/">https://www.confluent.io/blog/windowing-in-kafka-streams/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34716797">https://news.ycombinator.com/item?id=34716797</a></p>
<p>Points: 23</p>
<p># Comments: 0</p>

## Vestas unveils solution to end landfill disposal for wind turbine blades
 - [https://www.vestas.com/en/media/company-news/2023/vestas-unveils-circularity-solution-to-end-landfill-for-c3710818](https://www.vestas.com/en/media/company-news/2023/vestas-unveils-circularity-solution-to-end-landfill-for-c3710818)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 22:52:20+00:00
 - user: None

<p>Article URL: <a href="https://www.vestas.com/en/media/company-news/2023/vestas-unveils-circularity-solution-to-end-landfill-for-c3710818">https://www.vestas.com/en/media/company-news/2023/vestas-unveils-circularity-solution-to-end-landfill-for-c3710818</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34716743">https://news.ycombinator.com/item?id=34716743</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Twitter starts limiting how many Tweets you can post per Day
 - [https://forum.cktn.de/t/twitter-starts-limiting-how-many-tweets-you-can-post-per-day/493](https://forum.cktn.de/t/twitter-starts-limiting-how-many-tweets-you-can-post-per-day/493)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 21:55:32+00:00
 - user: None

<p>Article URL: <a href="https://forum.cktn.de/t/twitter-starts-limiting-how-many-tweets-you-can-post-per-day/493">https://forum.cktn.de/t/twitter-starts-limiting-how-many-tweets-you-can-post-per-day/493</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34715890">https://news.ycombinator.com/item?id=34715890</a></p>
<p>Points: 53</p>
<p># Comments: 36</p>

## Top Byte Ignore for Fun and Memory Savings
 - [https://www.linaro.org/blog/top-byte-ignore-for-fun-and-memory-savings/](https://www.linaro.org/blog/top-byte-ignore-for-fun-and-memory-savings/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 21:31:49+00:00
 - user: None

<p>Article URL: <a href="https://www.linaro.org/blog/top-byte-ignore-for-fun-and-memory-savings/">https://www.linaro.org/blog/top-byte-ignore-for-fun-and-memory-savings/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34715517">https://news.ycombinator.com/item?id=34715517</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Show HN: StackOverflow.gg – AI-generated answers to every coding question
 - [https://stackoverflow.gg/](https://stackoverflow.gg/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 20:58:47+00:00
 - user: None

<p>Article URL: <a href="https://stackoverflow.gg/">https://stackoverflow.gg/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34715033">https://news.ycombinator.com/item?id=34715033</a></p>
<p>Points: 32</p>
<p># Comments: 4</p>

## Is Google’s 20-year search dominance about to end?
 - [https://www.economist.com/business/2023/02/08/is-googles-20-year-search-dominance-about-to-end](https://www.economist.com/business/2023/02/08/is-googles-20-year-search-dominance-about-to-end)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 20:57:27+00:00
 - user: None

<p>Article URL: <a href="https://www.economist.com/business/2023/02/08/is-googles-20-year-search-dominance-about-to-end">https://www.economist.com/business/2023/02/08/is-googles-20-year-search-dominance-about-to-end</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34715003">https://news.ycombinator.com/item?id=34715003</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Reddit Mods and Scaling Problems in Social Control
 - [https://maximumeffort.substack.com/p/scaling-problems-in-social-control](https://maximumeffort.substack.com/p/scaling-problems-in-social-control)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 19:31:27+00:00
 - user: None

<p>Article URL: <a href="https://maximumeffort.substack.com/p/scaling-problems-in-social-control">https://maximumeffort.substack.com/p/scaling-problems-in-social-control</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34713553">https://news.ycombinator.com/item?id=34713553</a></p>
<p>Points: 14</p>
<p># Comments: 27</p>

## ChatGPT lied to me and then tried to deny it
 - [https://qfabgtpxazxxnoc5h5rdcorsw4sivkmmte2kkpki5ejxuzqgq3eq.arweave.net/gUATTfcGb3a4XT9iMToytySKqYyZNKU9SOkTemYGhsk](https://qfabgtpxazxxnoc5h5rdcorsw4sivkmmte2kkpki5ejxuzqgq3eq.arweave.net/gUATTfcGb3a4XT9iMToytySKqYyZNKU9SOkTemYGhsk)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 19:30:03+00:00
 - user: None

<p>Article URL: <a href="https://qfabgtpxazxxnoc5h5rdcorsw4sivkmmte2kkpki5ejxuzqgq3eq.arweave.net/gUATTfcGb3a4XT9iMToytySKqYyZNKU9SOkTemYGhsk">https://qfabgtpxazxxnoc5h5rdcorsw4sivkmmte2kkpki5ejxuzqgq3eq.arweave.net/gUATTfcGb3a4XT9iMToytySKqYyZNKU9SOkTemYGhsk</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34713521">https://news.ycombinator.com/item?id=34713521</a></p>
<p>Points: 27</p>
<p># Comments: 11</p>

## Probiotic blocks staph bacteria from colonizing people
 - [https://www.nih.gov/news-events/nih-research-matters/probiotic-blocks-staph-bacteria-colonizing-people](https://www.nih.gov/news-events/nih-research-matters/probiotic-blocks-staph-bacteria-colonizing-people)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 19:25:51+00:00
 - user: None

<p>Article URL: <a href="https://www.nih.gov/news-events/nih-research-matters/probiotic-blocks-staph-bacteria-colonizing-people">https://www.nih.gov/news-events/nih-research-matters/probiotic-blocks-staph-bacteria-colonizing-people</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34713431">https://news.ycombinator.com/item?id=34713431</a></p>
<p>Points: 38</p>
<p># Comments: 2</p>

## Show HN: Filmbox, physically accurate film emulation, now on Linux and Windows
 - [https://videovillage.co/filmbox/](https://videovillage.co/filmbox/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 19:13:06+00:00
 - user: None

<p>We released Filmbox two years ago, and it has gotten a great response. It's been used in huge movies like "Everything Everywhere All At Once".<p>It's been a huge rewrite to get this working on Linux and Windows from our original Mac and Metal code.<p>We also have some interesting uses of cross-platform Swift + Electron in our plugin manager app, and cross-platform Swift generally in the plugin. Hopefully we can detail that in a blog post at some point.<p>There's a free Filmbox Lite version to try, if you're interested.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34713202">https://news.ycombinator.com/item?id=34713202</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## FDroid debating Aves Libre app TOS as reason for removal
 - [https://gitlab.com/fdroid/fdroiddata/-/issues/2893](https://gitlab.com/fdroid/fdroiddata/-/issues/2893)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 19:09:56+00:00
 - user: None

<p>Article URL: <a href="https://gitlab.com/fdroid/fdroiddata/-/issues/2893">https://gitlab.com/fdroid/fdroiddata/-/issues/2893</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34713133">https://news.ycombinator.com/item?id=34713133</a></p>
<p>Points: 65</p>
<p># Comments: 30</p>

## NIST Selects ‘Lightweight Cryptography’ Algorithms to Protect Small Devices
 - [https://www.nist.gov/news-events/news/2023/02/nist-selects-lightweight-cryptography-algorithms-protect-small-devices](https://www.nist.gov/news-events/news/2023/02/nist-selects-lightweight-cryptography-algorithms-protect-small-devices)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 18:44:56+00:00
 - user: None

<p>Article URL: <a href="https://www.nist.gov/news-events/news/2023/02/nist-selects-lightweight-cryptography-algorithms-protect-small-devices">https://www.nist.gov/news-events/news/2023/02/nist-selects-lightweight-cryptography-algorithms-protect-small-devices</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34712729">https://news.ycombinator.com/item?id=34712729</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

## Windows 11: a spyware machine out of users' control
 - [https://www.techspot.com/news/97535-windows-11-spyware-machine-out-users-control.html](https://www.techspot.com/news/97535-windows-11-spyware-machine-out-users-control.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 18:39:54+00:00
 - user: None

<p>Article URL: <a href="https://www.techspot.com/news/97535-windows-11-spyware-machine-out-users-control.html">https://www.techspot.com/news/97535-windows-11-spyware-machine-out-users-control.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34712640">https://news.ycombinator.com/item?id=34712640</a></p>
<p>Points: 60</p>
<p># Comments: 19</p>

## Buckminster Fuller’s Hall of Mirrors
 - [https://www.thenation.com/article/culture/buckminster-fuller-alec-nevela-lee-biography/](https://www.thenation.com/article/culture/buckminster-fuller-alec-nevela-lee-biography/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 18:21:13+00:00
 - user: None

<p>Article URL: <a href="https://www.thenation.com/article/culture/buckminster-fuller-alec-nevela-lee-biography/">https://www.thenation.com/article/culture/buckminster-fuller-alec-nevela-lee-biography/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34712332">https://news.ycombinator.com/item?id=34712332</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Why Wyndly raised $2M and things we wished we'd known
 - [https://www.wyndly.com/blogs/learn/why-wyndly-raised-2m](https://www.wyndly.com/blogs/learn/why-wyndly-raised-2m)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 18:04:58+00:00
 - user: None

<p>Article URL: <a href="https://www.wyndly.com/blogs/learn/why-wyndly-raised-2m">https://www.wyndly.com/blogs/learn/why-wyndly-raised-2m</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34712078">https://news.ycombinator.com/item?id=34712078</a></p>
<p>Points: 20</p>
<p># Comments: 2</p>

## White House says blog post on Nord Stream explosion 'utterly false'
 - [https://www.reuters.com/world/us/white-house-says-blog-post-nord-stream-explosion-is-utterly-false-2023-02-08/](https://www.reuters.com/world/us/white-house-says-blog-post-nord-stream-explosion-is-utterly-false-2023-02-08/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 17:51:39+00:00
 - user: None

<p>Article URL: <a href="https://www.reuters.com/world/us/white-house-says-blog-post-nord-stream-explosion-is-utterly-false-2023-02-08/">https://www.reuters.com/world/us/white-house-says-blog-post-nord-stream-explosion-is-utterly-false-2023-02-08/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34711848">https://news.ycombinator.com/item?id=34711848</a></p>
<p>Points: 13</p>
<p># Comments: 11</p>

## Public broadcasters want to reclaim online spaces with “Public Spaces Incubator”
 - [https://finance.yahoo.com/news/public-broadcasters-collaborate-reclaim-online-150000237.html](https://finance.yahoo.com/news/public-broadcasters-collaborate-reclaim-online-150000237.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 17:46:38+00:00
 - user: None

<p>Article URL: <a href="https://finance.yahoo.com/news/public-broadcasters-collaborate-reclaim-online-150000237.html">https://finance.yahoo.com/news/public-broadcasters-collaborate-reclaim-online-150000237.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34711758">https://news.ycombinator.com/item?id=34711758</a></p>
<p>Points: 19</p>
<p># Comments: 9</p>

## OpenSSH Pre-Auth Double Free – CVE-2023-25136 – Writeup and Proof-of-Concept
 - [https://jfrog.com/blog/openssh-pre-auth-double-free-cve-2023-25136-writeup-and-proof-of-concept/](https://jfrog.com/blog/openssh-pre-auth-double-free-cve-2023-25136-writeup-and-proof-of-concept/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 17:34:31+00:00
 - user: None

<p>Article URL: <a href="https://jfrog.com/blog/openssh-pre-auth-double-free-cve-2023-25136-writeup-and-proof-of-concept/">https://jfrog.com/blog/openssh-pre-auth-double-free-cve-2023-25136-writeup-and-proof-of-concept/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34711565">https://news.ycombinator.com/item?id=34711565</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Acrobat PDF rendering engine added to Microsoft Edge
 - [https://blog.adobe.com/en/publish/2023/02/08/adobe-microsoft-bring-industry-leading-acrobat-pdf-experience-window-users-microsoft-edge](https://blog.adobe.com/en/publish/2023/02/08/adobe-microsoft-bring-industry-leading-acrobat-pdf-experience-window-users-microsoft-edge)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 17:22:39+00:00
 - user: None

<p>Article URL: <a href="https://blog.adobe.com/en/publish/2023/02/08/adobe-microsoft-bring-industry-leading-acrobat-pdf-experience-window-users-microsoft-edge">https://blog.adobe.com/en/publish/2023/02/08/adobe-microsoft-bring-industry-leading-acrobat-pdf-experience-window-users-microsoft-edge</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34711367">https://news.ycombinator.com/item?id=34711367</a></p>
<p>Points: 25</p>
<p># Comments: 25</p>

## Google Stock Tumbles 8% After Its Bard AI Ad Shows Inaccurate Answer
 - [https://www.investors.com/news/google-stock-falls-after-googles-bard-ai-ad-shows-inaccurate-answer/](https://www.investors.com/news/google-stock-falls-after-googles-bard-ai-ad-shows-inaccurate-answer/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 17:16:08+00:00
 - user: None

<p>Article URL: <a href="https://www.investors.com/news/google-stock-falls-after-googles-bard-ai-ad-shows-inaccurate-answer/">https://www.investors.com/news/google-stock-falls-after-googles-bard-ai-ad-shows-inaccurate-answer/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34711244">https://news.ycombinator.com/item?id=34711244</a></p>
<p>Points: 68</p>
<p># Comments: 34</p>

## Boss' Dilemma: Taking Responsibility Signals Cooperation
 - [https://tidyfirst.substack.com/p/signaling-cooperation-employees-dilemma](https://tidyfirst.substack.com/p/signaling-cooperation-employees-dilemma)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 17:05:48+00:00
 - user: None

<p>Article URL: <a href="https://tidyfirst.substack.com/p/signaling-cooperation-employees-dilemma">https://tidyfirst.substack.com/p/signaling-cooperation-employees-dilemma</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34711054">https://news.ycombinator.com/item?id=34711054</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Ask HN: How do you deal with information and internet addiction?
 - [https://news.ycombinator.com/item?id=34710830](https://news.ycombinator.com/item?id=34710830)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 16:52:44+00:00
 - user: None

<p>I have noticed that I am getting more and more addicted to consuming information so I am listening to podcasts while working and I watch Youtube videos in my free time. This is all fun and interesting but I feel this makes me want to do things less and less. Instead of working on my own problems I distract myself by listening to ever more information. I get a lot of benefit from this information but somehow it feels shallow.<p>I think part of it is that my work is quite uninteresting and doesn't really keep my mind engaged. But the work is tedious enough that I am too tried in the evening to do something interesting. After a few years everything feels like it's a repeat.<p>Does anybody else feel that way? Have you been able to detach yourself from the constant flow of information and focus on your own stuff?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34710830">https://news.ycombinator.com/item?id=34710830</a></p>
<p>Points: 10</p>
<p># Comments: 5</p>

## Fungi and bacteria are binging on burned soil
 - [https://news.ucr.edu/articles/2023/02/07/fungi-and-bacteria-are-binging-burned-soil](https://news.ucr.edu/articles/2023/02/07/fungi-and-bacteria-are-binging-burned-soil)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 16:46:26+00:00
 - user: None

<p>Article URL: <a href="https://news.ucr.edu/articles/2023/02/07/fungi-and-bacteria-are-binging-burned-soil">https://news.ucr.edu/articles/2023/02/07/fungi-and-bacteria-are-binging-burned-soil</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34710725">https://news.ycombinator.com/item?id=34710725</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## Ask HN: How do you celebrate failures at work?
 - [https://news.ycombinator.com/item?id=34710403](https://news.ycombinator.com/item?id=34710403)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 16:27:32+00:00
 - user: None

<p>Hello folks!<p>Do you have any process, ritual, etc.. that you use at work to embrace and celebrate failures?<p>E.g. I've recently learned that for a period at Airbnb there was an award for the biggest failed project and feature.<p>How have these practices impacted your work?<p>Do you feel that failures at work are accepted by the leadership and are used to create value (personal growth and business level)?<p>Curious to hear your opinions and experiences.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34710403">https://news.ycombinator.com/item?id=34710403</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Apple signs union agreement for Glasgow Apple Store staff
 - [https://appleinsider.com/articles/23/02/08/apple-signs-union-agreement-for-glasgow-apple-store-staff](https://appleinsider.com/articles/23/02/08/apple-signs-union-agreement-for-glasgow-apple-store-staff)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 16:26:36+00:00
 - user: None

<p>Article URL: <a href="https://appleinsider.com/articles/23/02/08/apple-signs-union-agreement-for-glasgow-apple-store-staff">https://appleinsider.com/articles/23/02/08/apple-signs-union-agreement-for-glasgow-apple-store-staff</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34710379">https://news.ycombinator.com/item?id=34710379</a></p>
<p>Points: 39</p>
<p># Comments: 5</p>

## Barry Diller: The Oscars Are over and the Movie Business Is Finished
 - [https://www.lamag.com/culturefiles/barry-diller-the-oscars-are-over-and-the-movie-business-is-finished/](https://www.lamag.com/culturefiles/barry-diller-the-oscars-are-over-and-the-movie-business-is-finished/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 16:25:51+00:00
 - user: None

<p>Article URL: <a href="https://www.lamag.com/culturefiles/barry-diller-the-oscars-are-over-and-the-movie-business-is-finished/">https://www.lamag.com/culturefiles/barry-diller-the-oscars-are-over-and-the-movie-business-is-finished/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34710371">https://news.ycombinator.com/item?id=34710371</a></p>
<p>Points: 27</p>
<p># Comments: 58</p>

## Keybase.pub Shutting Down on March 1 2023
 - [https://keybase.pub/](https://keybase.pub/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 15:49:26+00:00
 - user: None

<p>Article URL: <a href="https://keybase.pub/">https://keybase.pub/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34709699">https://news.ycombinator.com/item?id=34709699</a></p>
<p>Points: 14</p>
<p># Comments: 5</p>

## Zrok: Open-Source Peer to Peer
 - [https://zrok.io/](https://zrok.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 15:36:41+00:00
 - user: None

<p>Article URL: <a href="https://zrok.io/">https://zrok.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34709487">https://news.ycombinator.com/item?id=34709487</a></p>
<p>Points: 15</p>
<p># Comments: 0</p>

## The Chemistry of ‘Yes Minister’ (2017)
 - [https://sphericalbullshit.wordpress.com/2017/05/13/the-chemistry-of-yes-minister/](https://sphericalbullshit.wordpress.com/2017/05/13/the-chemistry-of-yes-minister/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 15:23:24+00:00
 - user: None

<p>Article URL: <a href="https://sphericalbullshit.wordpress.com/2017/05/13/the-chemistry-of-yes-minister/">https://sphericalbullshit.wordpress.com/2017/05/13/the-chemistry-of-yes-minister/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34709279">https://news.ycombinator.com/item?id=34709279</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Godot 4 Release Candidate 1
 - [https://godotengine.org/article/release-candidate-godot-4-0-rc-1/](https://godotengine.org/article/release-candidate-godot-4-0-rc-1/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 15:21:30+00:00
 - user: None

<p>Article URL: <a href="https://godotengine.org/article/release-candidate-godot-4-0-rc-1/">https://godotengine.org/article/release-candidate-godot-4-0-rc-1/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34709249">https://news.ycombinator.com/item?id=34709249</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Telemetry in the Go Toolchain
 - [https://github.com/golang/go/discussions/58409](https://github.com/golang/go/discussions/58409)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 15:10:15+00:00
 - user: None

<p>Article URL: <a href="https://github.com/golang/go/discussions/58409">https://github.com/golang/go/discussions/58409</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34709078">https://news.ycombinator.com/item?id=34709078</a></p>
<p>Points: 35</p>
<p># Comments: 5</p>

## Why does 0.1 and 0.2 = 0.30000000000000004?
 - [https://jvns.ca/blog/2023/02/08/why-does-0-1-plus-0-2-equal-0-30000000000000004/](https://jvns.ca/blog/2023/02/08/why-does-0-1-plus-0-2-equal-0-30000000000000004/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 14:50:26+00:00
 - user: None

<p>Article URL: <a href="https://jvns.ca/blog/2023/02/08/why-does-0-1-plus-0-2-equal-0-30000000000000004/">https://jvns.ca/blog/2023/02/08/why-does-0-1-plus-0-2-equal-0-30000000000000004/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34708756">https://news.ycombinator.com/item?id=34708756</a></p>
<p>Points: 9</p>
<p># Comments: 3</p>

## George Orwell's 6 rules for writing (2018; originally published in 1946)
 - [https://infusion.media/blog/george-orwells-six-rules-for-writing/](https://infusion.media/blog/george-orwells-six-rules-for-writing/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 14:45:53+00:00
 - user: None

<p>Article URL: <a href="https://infusion.media/blog/george-orwells-six-rules-for-writing/">https://infusion.media/blog/george-orwells-six-rules-for-writing/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34708685">https://news.ycombinator.com/item?id=34708685</a></p>
<p>Points: 19</p>
<p># Comments: 12</p>

## Google will blur explicit image results for all users, requires login to disable
 - [https://arstechnica.com/gadgets/2023/02/google-will-soon-default-to-blurring-explicit-image-search-results/](https://arstechnica.com/gadgets/2023/02/google-will-soon-default-to-blurring-explicit-image-search-results/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 14:33:35+00:00
 - user: None

<p>Article URL: <a href="https://arstechnica.com/gadgets/2023/02/google-will-soon-default-to-blurring-explicit-image-search-results/">https://arstechnica.com/gadgets/2023/02/google-will-soon-default-to-blurring-explicit-image-search-results/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34708518">https://news.ycombinator.com/item?id=34708518</a></p>
<p>Points: 40</p>
<p># Comments: 21</p>

## Google is still drip-feeding AI into Search, Maps, and Translate
 - [https://www.theverge.com/2023/2/8/23589886/google-search-maps-translate-features-updates-live-from-paris-event](https://www.theverge.com/2023/2/8/23589886/google-search-maps-translate-features-updates-live-from-paris-event)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 14:22:58+00:00
 - user: None

<p>Article URL: <a href="https://www.theverge.com/2023/2/8/23589886/google-search-maps-translate-features-updates-live-from-paris-event">https://www.theverge.com/2023/2/8/23589886/google-search-maps-translate-features-updates-live-from-paris-event</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34708381">https://news.ycombinator.com/item?id=34708381</a></p>
<p>Points: 19</p>
<p># Comments: 8</p>

## Google's Live from Paris Event Private/Deleted Immediately
 - [https://news.ycombinator.com/item?id=34708255](https://news.ycombinator.com/item?id=34708255)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 14:14:46+00:00
 - user: None

<p>Just watched the 'Google Live from Paris' event and it looked like a non-event to me.<p>It seems that the livestream event was set private after it ended. (It was unlisted to begin with) They even forgot the phone used to demonstrate multisearch.<p>This suggests to me that Google is finally getting disrupted and are scrambling of desperation because of the release of ChatGPT.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34708255">https://news.ycombinator.com/item?id=34708255</a></p>
<p>Points: 56</p>
<p># Comments: 32</p>

## What 2023 will bring for PeerTube
 - [https://joinpeertube.org/news/roadmap-v6](https://joinpeertube.org/news/roadmap-v6)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 14:13:13+00:00
 - user: None

<p>Article URL: <a href="https://joinpeertube.org/news/roadmap-v6">https://joinpeertube.org/news/roadmap-v6</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34708233">https://news.ycombinator.com/item?id=34708233</a></p>
<p>Points: 88</p>
<p># Comments: 22</p>

## Heat pumps are defying Maine’s winters and oil industry pushback
 - [https://www.washingtonpost.com/climate-environment/2023/02/07/maine-gas-industry-heat-pumps/](https://www.washingtonpost.com/climate-environment/2023/02/07/maine-gas-industry-heat-pumps/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 14:07:27+00:00
 - user: None

<p>Article URL: <a href="https://www.washingtonpost.com/climate-environment/2023/02/07/maine-gas-industry-heat-pumps/">https://www.washingtonpost.com/climate-environment/2023/02/07/maine-gas-industry-heat-pumps/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34708161">https://news.ycombinator.com/item?id=34708161</a></p>
<p>Points: 61</p>
<p># Comments: 64</p>

## Ask HN: DNS redundancy, how to do it right?
 - [https://news.ycombinator.com/item?id=34708066](https://news.ycombinator.com/item?id=34708066)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 13:58:55+00:00
 - user: None

<p>I hope I'm doing this right, since it's my first submission. It is a question directed to sysadmins of HN:<p>How do I reach nameserver redundancy?<p>Right now our provider is getting DdoS'ed, so my employer is not reachable by mail, web etc. If I do a whois on the affected domain, I'll get multiple nameservers (which the provider owns).<p>Looks like this:<p>nserver ns01.provider.tld
nserver ns02.provider.tld
nserver ns03.provider.tld
nserver ns04.provider.tld
nserver ns05.provider.tld<p>Actually two questions arise from this:<p>- Is it a good idea to setup my own nameserver which basically just "copies" the entries from my current provider and specify it (wherever that may be). By doing this I won't have to maintain 2 different NS, only the one from the provider since the 'secondary' will simply be a copy of the primary?<p>- Is it a good idea to simply increase the TTL of the important A/MX-Records?
Will for example, 1.1.1.1 still resolve my domain correctly, even if my providers nameserver is down for an hour? (assumed I have a TTL of 3 hours for example)<p>Thankfully, I'm not the CTO, but since he mentioned to me that this happens regularly to the provider (being DdoSed), it got me really curious what the right mitigation to being unreachable is.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34708066">https://news.ycombinator.com/item?id=34708066</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Turkey blocks Twitter after the earthquake
 - [https://netblocks.org/reports/twitter-restricted-in-turkey-in-aftermath-of-earthquake-oy9LJ9B3](https://netblocks.org/reports/twitter-restricted-in-turkey-in-aftermath-of-earthquake-oy9LJ9B3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 13:51:14+00:00
 - user: None

<p>Article URL: <a href="https://netblocks.org/reports/twitter-restricted-in-turkey-in-aftermath-of-earthquake-oy9LJ9B3">https://netblocks.org/reports/twitter-restricted-in-turkey-in-aftermath-of-earthquake-oy9LJ9B3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34707974">https://news.ycombinator.com/item?id=34707974</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Why Steam Deck Is One of the Most Significant PC Gaming Moments in Years
 - [https://www.techspot.com/article/2620-steam-deck-pc-gaming-moment/](https://www.techspot.com/article/2620-steam-deck-pc-gaming-moment/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 13:39:17+00:00
 - user: None

<p>Article URL: <a href="https://www.techspot.com/article/2620-steam-deck-pc-gaming-moment/">https://www.techspot.com/article/2620-steam-deck-pc-gaming-moment/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34707816">https://news.ycombinator.com/item?id=34707816</a></p>
<p>Points: 48</p>
<p># Comments: 40</p>

## The Teen Mental Illness Epidemic Began Around 2012
 - [https://jonathanhaidt.substack.com/p/the-teen-mental-illness-epidemic](https://jonathanhaidt.substack.com/p/the-teen-mental-illness-epidemic)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 13:32:35+00:00
 - user: None

<p>Article URL: <a href="https://jonathanhaidt.substack.com/p/the-teen-mental-illness-epidemic">https://jonathanhaidt.substack.com/p/the-teen-mental-illness-epidemic</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34707734">https://news.ycombinator.com/item?id=34707734</a></p>
<p>Points: 44</p>
<p># Comments: 23</p>

## Meilisearch v1.0 – the open-source Rust alternative to Algolia and Elasticsearch
 - [https://blog.meilisearch.com/v1-enterprise-ready-stable/](https://blog.meilisearch.com/v1-enterprise-ready-stable/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 13:31:56+00:00
 - user: None

<p>Article URL: <a href="https://blog.meilisearch.com/v1-enterprise-ready-stable/">https://blog.meilisearch.com/v1-enterprise-ready-stable/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34707727">https://news.ycombinator.com/item?id=34707727</a></p>
<p>Points: 27</p>
<p># Comments: 0</p>

## Transparent Telemetry for Open-Source Projects
 - [https://research.swtch.com/telemetry-intro](https://research.swtch.com/telemetry-intro)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 13:19:39+00:00
 - user: None

<p>Article URL: <a href="https://research.swtch.com/telemetry-intro">https://research.swtch.com/telemetry-intro</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34707583">https://news.ycombinator.com/item?id=34707583</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Linux 6.1 Officially Promoted to Being an LTS Kernel
 - [https://www.phoronix.com/news/Linux-6.1-LTS-Official](https://www.phoronix.com/news/Linux-6.1-LTS-Official)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 13:04:48+00:00
 - user: None

<p>Article URL: <a href="https://www.phoronix.com/news/Linux-6.1-LTS-Official">https://www.phoronix.com/news/Linux-6.1-LTS-Official</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34707435">https://news.ycombinator.com/item?id=34707435</a></p>
<p>Points: 17</p>
<p># Comments: 0</p>

## Toxic Exposure: The True Story Behind the Monsanto Trials
 - [https://www.press.jhu.edu/books/title/12717/toxic-exposure](https://www.press.jhu.edu/books/title/12717/toxic-exposure)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 13:04:41+00:00
 - user: None

<p>Article URL: <a href="https://www.press.jhu.edu/books/title/12717/toxic-exposure">https://www.press.jhu.edu/books/title/12717/toxic-exposure</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34707433">https://news.ycombinator.com/item?id=34707433</a></p>
<p>Points: 44</p>
<p># Comments: 11</p>

## Etsy is awash with illicit products and mass produced goods
 - [https://www.businessinsider.com/etsy-sells-ivory-weapons-poisonous-plants-mass-produced-products-2021-4](https://www.businessinsider.com/etsy-sells-ivory-weapons-poisonous-plants-mass-produced-products-2021-4)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 12:12:16+00:00
 - user: None

<p>Article URL: <a href="https://www.businessinsider.com/etsy-sells-ivory-weapons-poisonous-plants-mass-produced-products-2021-4">https://www.businessinsider.com/etsy-sells-ivory-weapons-poisonous-plants-mass-produced-products-2021-4</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34707024">https://news.ycombinator.com/item?id=34707024</a></p>
<p>Points: 24</p>
<p># Comments: 13</p>

## ChatGPT is a data privacy nightmare
 - [https://theconversation.com/chatgpt-is-a-data-privacy-nightmare-if-youve-ever-posted-online-you-ought-to-be-concerned-199283](https://theconversation.com/chatgpt-is-a-data-privacy-nightmare-if-youve-ever-posted-online-you-ought-to-be-concerned-199283)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 12:10:12+00:00
 - user: rumpel
 - tags: chatgpt,privacy

<p>Article URL: <a href="https://theconversation.com/chatgpt-is-a-data-privacy-nightmare-if-youve-ever-posted-online-you-ought-to-be-concerned-199283">https://theconversation.com/chatgpt-is-a-data-privacy-nightmare-if-youve-ever-posted-online-you-ought-to-be-concerned-199283</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34707007">https://news.ycombinator.com/item?id=34707007</a></p>
<p>Points: 60</p>
<p># Comments: 17</p>

## Ask HN: I just want to have fun programming again
 - [https://news.ycombinator.com/item?id=34706991](https://news.ycombinator.com/item?id=34706991)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 12:07:58+00:00
 - user: None

<p>I've written in many very different languages in a professional full-time capacity in my many-year career. Now I'm interested in building something new and I have a clear idea in mind with some code already in C++ to proof-of-concept it for myself, but I'm struggling to find a direction forward that would be... fun. I don't mind challenging work, but I like an environment that feels sane and logical and where I am not facing loads of incidental complexity along the way. I'm also attracted to implementing my app cross-platform.<p>I just want to have some fun writing something without headaches, and that is seemingly less and less easy to achieve today. I'm not a fan of the complexity of either JavaScript or C++, and while I very much like Swift and working in the UIKit world, it's not so portable to platforms that many use.<p>I feel like there aren't really any good options in software development any more. It's always one big compromise with lots of possible decision fatigue. Every direction has drawbacks.<p>If I could write an app in a good static-compiled language that did not require extraneous expertise in CSS but that shipped on a web page and looked good using tools only in that language, with good interop with an HTML Canvas, that would be one possibility, but it is again a compromise -- no <i>easy</i> multithreading, dealing with all the front-end baggage to bundle or deploy such an app, etc.<p>Any recommendations? I'm not afraid of learning an entirely new language too.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706991">https://news.ycombinator.com/item?id=34706991</a></p>
<p>Points: 26</p>
<p># Comments: 27</p>

## Chromium's impact on root DNS traffic (2020)
 - [https://blog.apnic.net/2020/08/21/chromiums-impact-on-root-dns-traffic/](https://blog.apnic.net/2020/08/21/chromiums-impact-on-root-dns-traffic/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 11:45:22+00:00
 - user: None

<p>Article URL: <a href="https://blog.apnic.net/2020/08/21/chromiums-impact-on-root-dns-traffic/">https://blog.apnic.net/2020/08/21/chromiums-impact-on-root-dns-traffic/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706857">https://news.ycombinator.com/item?id=34706857</a></p>
<p>Points: 49</p>
<p># Comments: 36</p>

## Ask HN: Best practices for self-healing apps?
 - [https://news.ycombinator.com/item?id=34706624](https://news.ycombinator.com/item?id=34706624)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 11:13:01+00:00
 - user: None

<p>What are your best practices for self-healing apps for low  maintenance of servers for a solo founder? I use go but general patterns are welcome.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706624">https://news.ycombinator.com/item?id=34706624</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Ask HN: HN for Finance?
 - [https://news.ycombinator.com/item?id=34706550](https://news.ycombinator.com/item?id=34706550)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 11:02:12+00:00
 - user: None

<p>Love Hacker News. 
But, is there one for Finance?
Not: seekingalpha, wilmott, zerohedge, etc.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706550">https://news.ycombinator.com/item?id=34706550</a></p>
<p>Points: 9</p>
<p># Comments: 5</p>

## Value-Oriented Programming
 - [https://accu.org/journals/overload/31/173/teodorescu/](https://accu.org/journals/overload/31/173/teodorescu/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 10:59:18+00:00
 - user: None

<p>Article URL: <a href="https://accu.org/journals/overload/31/173/teodorescu/">https://accu.org/journals/overload/31/173/teodorescu/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706532">https://news.ycombinator.com/item?id=34706532</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## The digital pound: A new form of money for households and businesses?
 - [https://www.bankofengland.co.uk/paper/2023/the-digital-pound-consultation-paper](https://www.bankofengland.co.uk/paper/2023/the-digital-pound-consultation-paper)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 10:34:37+00:00
 - user: None

<p>Article URL: <a href="https://www.bankofengland.co.uk/paper/2023/the-digital-pound-consultation-paper">https://www.bankofengland.co.uk/paper/2023/the-digital-pound-consultation-paper</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706390">https://news.ycombinator.com/item?id=34706390</a></p>
<p>Points: 35</p>
<p># Comments: 86</p>

## Estonian Foreign Intelligence Service's 2023 Security Report
 - [https://raport.valisluureamet.ee/2023/en/](https://raport.valisluureamet.ee/2023/en/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 10:30:02+00:00
 - user: None

<p>Article URL: <a href="https://raport.valisluureamet.ee/2023/en/">https://raport.valisluureamet.ee/2023/en/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706360">https://news.ycombinator.com/item?id=34706360</a></p>
<p>Points: 19</p>
<p># Comments: 1</p>

## Open source cloud file system. Posix, HDFS and S3 compatible
 - [https://juicefs.com/en/](https://juicefs.com/en/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 10:05:42+00:00
 - user: None

<p>Article URL: <a href="https://juicefs.com/en/">https://juicefs.com/en/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706227">https://news.ycombinator.com/item?id=34706227</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Show HN: Kuboble.com – minimalistic sliding pieces puzzle game
 - [https://kuboble.com](https://kuboble.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 09:44:44+00:00
 - user: None

<p>Hi,<p>I wanted to share a simple game I wrote.<p>It's a sliding pieces puzzle like many others. I have focused a lot on making the experience smooth and
 minimalistic and the levels being challenging in a way a sudoku or chess puzzles could be.<p>I had no prior knowledge of game development and while it feels like someone competent could build this game in a week I spent over two years and hundreds of hours to bring this game to life.<p>My journey went through:<p><pre><code>    - thinking it will be a PC game
    - being overwhelmed by the amount of different game frameworks
    - hiring an indie dev to bootstrap the game in Unity for me
    - realize the small levels are actually cool and it might fit on a phone
    - generating levels and playing through thousands of them myself to curate a smaller list
    - realizing the Unity wasn't a good choice
    - rewriting the game in html + js drawing on canvas + React
    - hiring a bunch of fiverr artists and testers to polish it up
</code></pre>
I think I am finally satisfied with the result enough to be willing to share it with the world.<p>If you're a fan of minimalist sliding pieces puzzles I'd be happy if you give it a try!<p>the game has:
- no ads
- no tracking of any kind
- fully offline after first load</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706098">https://news.ycombinator.com/item?id=34706098</a></p>
<p>Points: 54</p>
<p># Comments: 11</p>

## Can sanitizers find the two bugs I wrote in C++?
 - [https://ahelwer.ca/post/2023-02-07-cpp-bugs-sanitized/](https://ahelwer.ca/post/2023-02-07-cpp-bugs-sanitized/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 09:42:28+00:00
 - user: None

<p>Article URL: <a href="https://ahelwer.ca/post/2023-02-07-cpp-bugs-sanitized/">https://ahelwer.ca/post/2023-02-07-cpp-bugs-sanitized/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34706080">https://news.ycombinator.com/item?id=34706080</a></p>
<p>Points: 20</p>
<p># Comments: 6</p>

## Reverse engineer Stable Diffusion images
 - [https://www.img2prompt.io/](https://www.img2prompt.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 08:46:12+00:00
 - user: None

<p>Article URL: <a href="https://www.img2prompt.io/">https://www.img2prompt.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34705706">https://news.ycombinator.com/item?id=34705706</a></p>
<p>Points: 15</p>
<p># Comments: 6</p>

## Incident: Qatar B788 at Doha on Jan 10th 2023, steep descent after takeoff
 - [https://avherald.com/h?article=504d75c7](https://avherald.com/h?article=504d75c7)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 06:53:48+00:00
 - user: None

<p>Article URL: <a href="https://avherald.com/h?article=504d75c7">https://avherald.com/h?article=504d75c7</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34705002">https://news.ycombinator.com/item?id=34705002</a></p>
<p>Points: 23</p>
<p># Comments: 8</p>

## Browsers are essential and how operating systems are holding them back (2022) [pdf]
 - [https://research.mozilla.org/files/2022/10/Mozilla-Five-Walled-Gardens.pdf](https://research.mozilla.org/files/2022/10/Mozilla-Five-Walled-Gardens.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 06:43:41+00:00
 - user: None

<p>Article URL: <a href="https://research.mozilla.org/files/2022/10/Mozilla-Five-Walled-Gardens.pdf">https://research.mozilla.org/files/2022/10/Mozilla-Five-Walled-Gardens.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34704948">https://news.ycombinator.com/item?id=34704948</a></p>
<p>Points: 27</p>
<p># Comments: 14</p>

## The Artist Who Collaborates with Ants
 - [https://www.newyorker.com/culture/persons-of-interest/the-artist-who-collaborates-with-ants](https://www.newyorker.com/culture/persons-of-interest/the-artist-who-collaborates-with-ants)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 05:59:07+00:00
 - user: None

<p>Article URL: <a href="https://www.newyorker.com/culture/persons-of-interest/the-artist-who-collaborates-with-ants">https://www.newyorker.com/culture/persons-of-interest/the-artist-who-collaborates-with-ants</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34704669">https://news.ycombinator.com/item?id=34704669</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## FlexiRaft: Flexible Quorums with Raft [pdf]
 - [https://www.cidrdb.org/cidr2023/papers/p83-yadav.pdf](https://www.cidrdb.org/cidr2023/papers/p83-yadav.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 05:29:30+00:00
 - user: None

<p>Article URL: <a href="https://www.cidrdb.org/cidr2023/papers/p83-yadav.pdf">https://www.cidrdb.org/cidr2023/papers/p83-yadav.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34704488">https://news.ycombinator.com/item?id=34704488</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Posix Compatibility Comparison: GCP Filestore, Amazon EFS, and Azure Files
 - [https://juicefs.com/en/blog/engineering/posix-compatibility-comparison-among-four-file-system-on-the-cloud](https://juicefs.com/en/blog/engineering/posix-compatibility-comparison-among-four-file-system-on-the-cloud)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 04:11:35+00:00
 - user: None

<p>Article URL: <a href="https://juicefs.com/en/blog/engineering/posix-compatibility-comparison-among-four-file-system-on-the-cloud">https://juicefs.com/en/blog/engineering/posix-compatibility-comparison-among-four-file-system-on-the-cloud</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34704029">https://news.ycombinator.com/item?id=34704029</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Why the Austin airport situation was so dangerous
 - [https://fallows.substack.com/p/as-bad-as-it-gets-without-body-bags](https://fallows.substack.com/p/as-bad-as-it-gets-without-body-bags)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 03:12:03+00:00
 - user: None

<p>Article URL: <a href="https://fallows.substack.com/p/as-bad-as-it-gets-without-body-bags">https://fallows.substack.com/p/as-bad-as-it-gets-without-body-bags</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34703626">https://news.ycombinator.com/item?id=34703626</a></p>
<p>Points: 82</p>
<p># Comments: 11</p>

## Transmission v4.0
 - [https://github.com/transmission/transmission/releases/tag/4.0.0](https://github.com/transmission/transmission/releases/tag/4.0.0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 02:52:22+00:00
 - user: None

<p>Article URL: <a href="https://github.com/transmission/transmission/releases/tag/4.0.0">https://github.com/transmission/transmission/releases/tag/4.0.0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34703478">https://news.ycombinator.com/item?id=34703478</a></p>
<p>Points: 34</p>
<p># Comments: 1</p>

## CBMC: The C Bounded Model Checker
 - [https://arxiv.org/abs/2302.02384](https://arxiv.org/abs/2302.02384)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 01:46:40+00:00
 - user: None

<p>Article URL: <a href="https://arxiv.org/abs/2302.02384">https://arxiv.org/abs/2302.02384</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34703004">https://news.ycombinator.com/item?id=34703004</a></p>
<p>Points: 15</p>
<p># Comments: 0</p>

## Discovery of an Exceptionally Rare Nearby and Energetic Gamma-Ray Burst
 - [https://arxiv.org/abs/2302.03642](https://arxiv.org/abs/2302.03642)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 01:44:54+00:00
 - user: None

<p>Article URL: <a href="https://arxiv.org/abs/2302.03642">https://arxiv.org/abs/2302.03642</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34702988">https://news.ycombinator.com/item?id=34702988</a></p>
<p>Points: 21</p>
<p># Comments: 5</p>

## GitHub: Guide on how to make ChatGPT prompts and a collection of prompts to use
 - [https://github.com/mattnigh/ChatGPT3-Free-Prompt-List](https://github.com/mattnigh/ChatGPT3-Free-Prompt-List)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 01:35:12+00:00
 - user: None

<p>Article URL: <a href="https://github.com/mattnigh/ChatGPT3-Free-Prompt-List">https://github.com/mattnigh/ChatGPT3-Free-Prompt-List</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34702915">https://news.ycombinator.com/item?id=34702915</a></p>
<p>Points: 21</p>
<p># Comments: 2</p>

## Intelligence is everywhere: From AI to cephalopods
 - [https://newhumanist.org.uk/articles/6068/intelligence-is-everywhere](https://newhumanist.org.uk/articles/6068/intelligence-is-everywhere)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 01:30:53+00:00
 - user: None

<p>Article URL: <a href="https://newhumanist.org.uk/articles/6068/intelligence-is-everywhere">https://newhumanist.org.uk/articles/6068/intelligence-is-everywhere</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34702866">https://news.ycombinator.com/item?id=34702866</a></p>
<p>Points: 26</p>
<p># Comments: 13</p>

## Ask HN: How to know if laptop enrolled in Intel Management Engine?
 - [https://news.ycombinator.com/item?id=34702825](https://news.ycombinator.com/item?id=34702825)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 01:27:16+00:00
 - user: None

<p>I am looking to purchase a old laptop from what seems to be a reseller of decommissioned laptops.<p>I read about Intel Management Engine and how it is a backdoor at the CPU level and does is not installed at the operating system level.<p>I tried googling this but how would I know if the laptop is still enrolled into some network? I would hate if some sysadmin could remotely do stuff to my PC.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34702825">https://news.ycombinator.com/item?id=34702825</a></p>
<p>Points: 21</p>
<p># Comments: 4</p>

## A lightweight (~5000 LOC) Python interpreter for game engines
 - [https://github.com/blueloveTH/pocketpy](https://github.com/blueloveTH/pocketpy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 00:49:49+00:00
 - user: None

<p>Article URL: <a href="https://github.com/blueloveTH/pocketpy">https://github.com/blueloveTH/pocketpy</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34702386">https://news.ycombinator.com/item?id=34702386</a></p>
<p>Points: 21</p>
<p># Comments: 5</p>

## Use GPT-3 incorrectly: reduce costs 40x and increase speed by 5x
 - [https://www.buildt.ai/blog/incorrectusage](https://www.buildt.ai/blog/incorrectusage)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 00:47:03+00:00
 - user: None

<p>Article URL: <a href="https://www.buildt.ai/blog/incorrectusage">https://www.buildt.ai/blog/incorrectusage</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34702349">https://news.ycombinator.com/item?id=34702349</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## Play Runescape Classic Again
 - [https://rsc.vet/](https://rsc.vet/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 00:42:52+00:00
 - user: None

<p>Article URL: <a href="https://rsc.vet/">https://rsc.vet/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34702294">https://news.ycombinator.com/item?id=34702294</a></p>
<p>Points: 36</p>
<p># Comments: 13</p>

## First Builder’s Remedy Plan for Bay Area Revealed in Los Altos Hills
 - [https://sfyimby.com/2023/02/yimby-exclusive-first-builders-remedy-plan-for-bay-area-revealed-in-los-altos-hills.html](https://sfyimby.com/2023/02/yimby-exclusive-first-builders-remedy-plan-for-bay-area-revealed-in-los-altos-hills.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-08 00:05:53+00:00
 - user: None

<p>Article URL: <a href="https://sfyimby.com/2023/02/yimby-exclusive-first-builders-remedy-plan-for-bay-area-revealed-in-los-altos-hills.html">https://sfyimby.com/2023/02/yimby-exclusive-first-builders-remedy-plan-for-bay-area-revealed-in-los-altos-hills.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34701907">https://news.ycombinator.com/item?id=34701907</a></p>
<p>Points: 40</p>
<p># Comments: 42</p>
