# Source Money PL, Source URL:https://www.money.pl/rss/, Source language: pl-PL

## Nie będzie niższego VAT-u na ciepło, prąd i gaz. Sejm odrzucił poprawkę Senatu
 - [https://www.money.pl/podatki/nie-bedzie-nizszego-vat-u-na-cieplo-prad-i-gaz-sejm-odrzucil-poprawke-senatu-6864430722640768a.html](https://www.money.pl/podatki/nie-bedzie-nizszego-vat-u-na-cieplo-prad-i-gaz-sejm-odrzucil-poprawke-senatu-6864430722640768a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 21:04:54+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/010ae836-6bb6-46dc-be3c-89f886be74c1" width="308" /> W ustawie dotyczącej maksymalnych podwyżek cen za ciepło, Senat zaproponował obniżkę VAT-u dla energetyki. Senatorowie chcieli, by podatek za ciepło, prąd i gaz był na poziomie 5-procentowym. To najniższy próg dopuszczalny przez UE. Sejm jednak nie przystał na ten pomysł i przywrócił 23-procentową stawkę.

## Unijna komisarz burzy spokój premiera. Pieniądze pod jednym warunkiem [NEWS MONEY.PL]
 - [https://www.money.pl/pieniadze/unijna-komisarz-burzy-spokoj-premiera-pieniadze-pod-jednym-warunkiem-news-money-pl-6864419721341792a.html](https://www.money.pl/pieniadze/unijna-komisarz-burzy-spokoj-premiera-pieniadze-pod-jednym-warunkiem-news-money-pl-6864419721341792a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 19:27:56+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4905dabf-1b10-4920-b796-7788b21a83ac" width="308" /> Warunkiem wypłaty pieniędzy z nowego budżetu UE jest zagwarantowanie przestrzegania zapisów Karty Praw Podstawowych, w tym tych dotyczących niezależności sądownictwa - powiedziała unijna komisarz ds. spójności i reform Elisa Ferreira. Jeśli wkrótce rząd Mateusza Morawieckiego nie dogada się z Brukselą, to wypłata unijnych miliardów stanie pod dużym znakiem zapytania.

## Chiński zakaz uderzy w europejską fotowoltaikę. "Polska i Unia nie są na to gotowe"
 - [https://www.money.pl/podatki/chinski-zakaz-uderzy-w-europejska-fotowoltaike-polska-i-unia-nie-sa-na-to-gotowe-6864377844771712a.html](https://www.money.pl/podatki/chinski-zakaz-uderzy-w-europejska-fotowoltaike-polska-i-unia-nie-sa-na-to-gotowe-6864377844771712a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 18:54:50+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/185b0ab2-244f-4b16-8749-a7294f931f36" width="308" /> Chiny chcą zakazać eksportu technologii dla fotowoltaiki. Zdaniem ekspertów uderzy to w tę branżę i inne sektory przemysłu, nie tylko w Polsce, ale także w Europie. Brak komponentów z Chin przełoży się także na wzrost cen. – Unia jest na to nieprzygotowana – mówią nasi rozmówcy.

## Ustawa o Sądzie Najwyższym. Sejm zdecydował o poprawkach Senatu
 - [https://www.money.pl/gospodarka/ustawa-o-sadzie-najwyzszym-sejm-zdecydowal-o-poprawkach-senatu-6864385252490080a.html](https://www.money.pl/gospodarka/ustawa-o-sadzie-najwyzszym-sejm-zdecydowal-o-poprawkach-senatu-6864385252490080a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 18:09:47+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a84c1cb5-1828-47c6-9481-c1c63aab379f" width="308" /> Sejm nie zgodził się na propozycję Senatu, by zlikwidować Izbę Odpowiedzialności Zawodowej, a sprawy dyscyplinarne przenieść do Izby Sądu Najwyższego. PiS nie posłuchało też apelu Zbigniewa Ziobry, który domagał się wstrzymania prac nad ustawą. Tym samym trafi ona teraz do prezydenta.

## Ustawa wiatrakowa. Sejm zdecydował o przyszłości energetyki wiatrowej
 - [https://www.money.pl/gospodarka/ustawa-wiatrakowa-sejm-zdecydowal-o-przyszlosci-energetyki-wiatrowej-6864339899190048a.html](https://www.money.pl/gospodarka/ustawa-wiatrakowa-sejm-zdecydowal-o-przyszlosci-energetyki-wiatrowej-6864339899190048a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 17:45:43+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf13fcd7-111d-4f61-893d-fbf576af1057" width="308" /> Sejm zdecydował się na złagodzenie przepisów dotyczących stawiania farm wiatrowych na lądzie. Zgodnie z przyjętą ustawą wiatraki będą mogły stanąć w odległości co najmniej 700 m od zabudowań mieszkalnych. Teraz nad rządowym pomysłem pochylą się senatorowie.

## Zmiany w Kodeksie pracy przegłosowane. Będzie więcej dni wolnych od pracy
 - [https://www.money.pl/gospodarka/zmiany-w-kodeksie-pracy-przeglosowane-bedzie-wiecej-dni-wolnych-od-pracy-6859389971413664a.html](https://www.money.pl/gospodarka/zmiany-w-kodeksie-pracy-przeglosowane-bedzie-wiecej-dni-wolnych-od-pracy-6859389971413664a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 17:41:02+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/787eee28-8bf9-40ff-be11-94e0ef51a1bd" width="308" /> Sejm przyjął nowelizację Kodeksu pracy, która wprowadza dłuższy urlop rodzicielski oraz nowy urlop opiekuńczy. Będą też specjalne rozwiązania dla rodziców dzieci do lat ośmiu.

## PiS przejmie władzę w samorządach? Oto możliwy scenariusz
 - [https://www.money.pl/gospodarka/pis-przejmie-wladze-w-samorzadach-oto-mozliwy-scenariusz-6864285933599424a.html](https://www.money.pl/gospodarka/pis-przejmie-wladze-w-samorzadach-oto-mozliwy-scenariusz-6864285933599424a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 15:58:14+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f983631f-0192-4a25-b699-050beb281493" width="308" /> Ruch Tak! Dla Polski założony przez prezydenta Warszawy Rafała Trzaskowskiego ma listę 50 samorządowców, którzy są gotowi jesienią startować do Sejmu. Ich start w wyborach i ewentualna wygrana oznacza jednak, że stracą dotychczasowe funkcje. W samorządach władzę przejmą komisarze wskazani przez premiera.

## Oto jak kurs złotego zareagował na decyzję NBP ws. stóp
 - [https://www.money.pl/pieniadze/stopy-procentowe-dolar-euro-oto-jak-kurs-zlotego-zareagowal-na-kluczowa-decyzje-nbp-6864257740180160a.html](https://www.money.pl/pieniadze/stopy-procentowe-dolar-euro-oto-jak-kurs-zlotego-zareagowal-na-kluczowa-decyzje-nbp-6864257740180160a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 14:40:08+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0676353a-8271-441a-8e1d-5f6c6d41483a" width="308" /> Polski złoty nieznacznie umocnił się w stosunku do głównych walut tuż po środowej decyzji RPP o wstrzymaniu się po raz kolejny od podwyżek stóp procentowych.

## Stopy procentowe po raz piąty z rzędu bez zmian. To oznacza, że raty kredytów będą niższe
 - [https://www.money.pl/banki/stopy-procentowe-po-raz-piaty-z-rzedu-bez-zmian-to-oznacza-ze-raty-kredytow-beda-nizsze-6864348916378464a.html](https://www.money.pl/banki/stopy-procentowe-po-raz-piaty-z-rzedu-bez-zmian-to-oznacza-ze-raty-kredytow-beda-nizsze-6864348916378464a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 14:27:08+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/dfeb258c-ca5f-4a82-9a1d-a12723f5424b" width="308" /> W tym miesiącu rynek nie brał pod uwagę innego scenariusza jak ten, że RPP pozostawi stopy procentowe na niezmienionym poziomie. Tak też się stało. Jednak WIBOR pozostaje w tendencji spadkowej. Kredytobiorcy mogą więc liczyć na to, że raty ich zobowiązań będą delikatnie niższe.

## Zadośćuczynienie dla syna rotmistrza Witolda Pileckiego. Sąd podjął decyzję
 - [https://www.money.pl/gospodarka/zadoscuczynienie-dla-syna-rotmistrza-witolda-pileckiego-sad-podjal-decyzje-6864327197850304a.html](https://www.money.pl/gospodarka/zadoscuczynienie-dla-syna-rotmistrza-witolda-pileckiego-sad-podjal-decyzje-6864327197850304a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 12:58:49+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/efe65109-8eb9-4cfb-a0ad-35f4a9744a2b" width="308" /> Potomek rotmistrza Witolda Pileckiego doczeka się zadośćuczynienia od państwa za krzywdę doznaną przez jego ojca. Sąd Okręgowy w Warszawie w środę przyznał Piotrowi Pileckiemu 1,5 mln złotych.

## Będą specjalne kredyty dla rolników. "Oferta unikalna i atrakcyjna"
 - [https://www.money.pl/banki/wsparcie-dla-rolnikow-rzad-proponuje-specjalne-kredyty-6864282086968000a.html](https://www.money.pl/banki/wsparcie-dla-rolnikow-rzad-proponuje-specjalne-kredyty-6864282086968000a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 09:55:17+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e3f9fb74-a059-455a-b8a0-a017e5169b41" width="308" /> Rząd proponuje nowe wsparcie dla rolników. Jego głównym elementem ma być pożyczka oferowana przez PKO BP na pięć lat w kwocie do 300 tys. zł. - To oferta unikalna i atrakcyjna - powiedział podczas konferencji prasowej wicepremier, minister aktywów państwowych Jacek Sasin.

## Wynagrodzenie z zakazu konkurencji po ustaniu stosunku pracy
 - [https://www.money.pl/gospodarka/wynagrodzenie-z-zakazu-konkurencji-po-ustaniu-stosunku-pracy-6864257585351264a.html](https://www.money.pl/gospodarka/wynagrodzenie-z-zakazu-konkurencji-po-ustaniu-stosunku-pracy-6864257585351264a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 08:15:34+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/780f6ab2-eed1-4ab7-b2e4-172f1de287e4" width="308" /> Zatrudniający może ustalić w umowie o pracę tzw. klauzulę konkurencji, czyli zakaz konkurencji trwający w czasie trwania tej umowy, ale również w okresie już po ustaniu stosunku pracy. Oznacza to, że pracownik nie może zatrudnić się u konkurencji. W zamian za zgodę na taką umowę lojalnościową ma zapewnione pewne świadczenie. Jak jest ono wypłacane?

## Kursy walut 08.02.2023. Środowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-08-02-2023-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6864224906705504a.html](https://www.money.pl/pieniadze/kursy-walut-08-02-2023-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6864224906705504a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 06:02:37+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 08.02.2023. W środę za jednego dolara (USD) zapłacimy 4.42 zł. Cena jednego funta szterlinga (GBP) to 5.33 zł, a franka szwajcarskiego (CHF) 4.80 zł. Z kolei euro (EUR) możemy zakupić za 4.74 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 08.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-08-02-2023-6864224731978336a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-08-02-2023-6864224731978336a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 06:01:57+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 08.02.2023. W środę za jedno euro (EUR) trzeba zapłacić 4.7476 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 08.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-08-02-2023-6864224694188736a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-08-02-2023-6864224694188736a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 06:01:48+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 08.02.2023. W środę za jednego dolara (USD) trzeba zapłacić 4.4236 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 08.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-08-02-2023-6864224661150304a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-08-02-2023-6864224661150304a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 06:01:40+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 08.02.2023. W środę za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.3313 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 08.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-08-02-2023-6864224578878144a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-08-02-2023-6864224578878144a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 06:01:20+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 08.02.2023. W środę za jednego franka (CHF) trzeba zapłacić 4.7984 zł.

## Biden chce uniknąć gospodarczej katastrofy. Wezwał Kongres, by "zapłacił rachunki Ameryki"
 - [https://www.money.pl/gospodarka/biden-chce-uniknac-gospodarczej-katastrofy-wezwal-kongres-by-zaplacil-rachunki-ameryki-6864222505806432a.html](https://www.money.pl/gospodarka/biden-chce-uniknac-gospodarczej-katastrofy-wezwal-kongres-by-zaplacil-rachunki-ameryki-6864222505806432a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 05:52:51+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3763e620-1c5a-48d0-977e-48245471ee97" width="308" /> Wzywam Kongres, by zrobił to, co robił podczas poprzedniej kadencji: zapłacił rachunki Ameryki, by uniknąć gospodarczej katastrofy dla naszego kraju - powiedział we wtorek prezydent USA Joe Biden podczas orędzia o stanie państwa w Kongresie.

## Premier zapewnia: wzrost emerytur znacząco przekroczy 20 procent
 - [https://www.money.pl/emerytury/premier-zapewnia-wzrost-emerytur-znaczaco-przekroczy-20-procent-6864220993534656a.html](https://www.money.pl/emerytury/premier-zapewnia-wzrost-emerytur-znaczaco-przekroczy-20-procent-6864220993534656a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-08 05:46:41+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0bf509f3-7137-45b8-b924-064e91abc081" width="308" /> Nie o niespełna 15, lecz o ponad 20 procent wzrosną świadczenia emerytów w 2023 roku - przekonuje premier Mateusz Morawiecki. Zdaniem szefa rządu seniorzy odczują tak znaczący wzrost uposażeń dzięki marcowej waloryzacji oraz wypłacie 13. i 14. emerytury.
