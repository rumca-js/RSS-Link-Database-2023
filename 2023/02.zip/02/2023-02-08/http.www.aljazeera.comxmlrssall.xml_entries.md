# Source Aljazeera, Source URL:http://www.aljazeera.com/xml/rss/all.xml, Source language: en-US

## Blinken says US to share info on alleged spy balloon with allies
 - [https://www.aljazeera.com/news/2023/2/8/blinken-says-us-to-share-info-on-alleged-spy-balloon-with-allies](https://www.aljazeera.com/news/2023/2/8/blinken-says-us-to-share-info-on-alleged-spy-balloon-with-allies)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 22:16:08+00:00
 - user: None

Antony Blinken met with NATO chief Jens Stoltenberg to discuss the alliance, Ukraine and the Chinese balloon.

## Suspect in Texas anti-immigrant shooting changes plea to guilty
 - [https://www.aljazeera.com/news/2023/2/8/suspect-in-texas-anti-immigrant-massacre-changes-plea-to-guilty](https://www.aljazeera.com/news/2023/2/8/suspect-in-texas-anti-immigrant-massacre-changes-plea-to-guilty)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 22:04:50+00:00
 - user: None

Patrick Crusius faces hate crime charges for a mass shooting in the US city of El Paso in 2019 that killed 23 people.

## Hope fades in Turkey, Syria with time running out on the buried
 - [https://www.aljazeera.com/news/2023/2/8/hope-fades-in-turkey-syria-with-time-running-out-on-the-buried](https://www.aljazeera.com/news/2023/2/8/hope-fades-in-turkey-syria-with-time-running-out-on-the-buried)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 21:21:55+00:00
 - user: None

With the possibility of finding victims alive fading fast, survivors express frustration over the slow rescue effort.

## Syrians denounce failed aid response after devastating quake
 - [https://www.aljazeera.com/news/2023/2/8/no-aid-received-for-quake-victims-in-n-west-syria-activists-say](https://www.aljazeera.com/news/2023/2/8/no-aid-received-for-quake-victims-in-n-west-syria-activists-say)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 21:01:51+00:00
 - user: None

Syrian activists decry the lack of international assistance to quake victims in its hard-hit northwest region.

## Photos: Syrians in quake-hit Gaziantep displaced again
 - [https://www.aljazeera.com/gallery/2023/2/8/photos-syrians-who-have-lost-their-homes-twice](https://www.aljazeera.com/gallery/2023/2/8/photos-syrians-who-have-lost-their-homes-twice)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 20:45:29+00:00
 - user: None

Refugees in the Turkish city say they are reliving past traumas after surviving devastating earthquakes.

## Is politics hampering the delivery of aid to Syria after quakes?
 - [https://www.aljazeera.com/program/inside-story/2023/2/8/is-politics-hampering-the-delivery-of-aid-to-syria-after-quakes](https://www.aljazeera.com/program/inside-story/2023/2/8/is-politics-hampering-the-delivery-of-aid-to-syria-after-quakes)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 20:40:53+00:00
 - user: None

Damascus says it should control aid and rescue efforts amid widespread devastation.

## US has questions to answer over Nord Stream blasts, Russia says
 - [https://www.aljazeera.com/news/2023/2/8/us-has-questions-to-answer-over-nord-stream-blasts-russia-says](https://www.aljazeera.com/news/2023/2/8/us-has-questions-to-answer-over-nord-stream-blasts-russia-says)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 20:12:08+00:00
 - user: None

Comments by foreign ministry come after a story alleges the US military was behind Nord Steam pipeline attacks.

## Google shares tank 8% as AI chatbot Bard flubs answer in ad
 - [https://www.aljazeera.com/economy/2023/2/8/google-shares-tank-8-as-ai-chatbot-bard-flubs-answer-in-ad](https://www.aljazeera.com/economy/2023/2/8/google-shares-tank-8-as-ai-chatbot-bard-flubs-answer-in-ad)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 19:01:37+00:00
 - user: None

Shares of Google&#039;s parent company lost more than $100bn after its Bard chatbot ad showed inaccurate information.

## Brazil launches raids to oust illegal miners from Indigenous land
 - [https://www.aljazeera.com/news/2023/2/8/brazil-launches-raids-to-oust-illegal-miners-from-indigenous-land](https://www.aljazeera.com/news/2023/2/8/brazil-launches-raids-to-oust-illegal-miners-from-indigenous-land)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 17:22:49+00:00
 - user: None

Yanomami Indigenous leaders in Brazil&#039;s Amazon blame illegal gold miners for a health crisis and surge in violence.

## Grief-stricken Palestinians recount deadly Israeli raids
 - [https://www.aljazeera.com/news/2023/2/8/israel-forces-leaves-aqabet-jaber-refugee-camp-grief-stricken](https://www.aljazeera.com/news/2023/2/8/israel-forces-leaves-aqabet-jaber-refugee-camp-grief-stricken)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 16:18:34+00:00
 - user: None

Residents of Aqabet Jaber refugee camp accuse Israeli soldiers of excessive force during &#039;barbaric&#039; incursions.

## US foreign policy reduced to an afterthought
 - [https://www.aljazeera.com/opinions/2023/2/8/us-foreign-policy-reduced-to-an-afterthought](https://www.aljazeera.com/opinions/2023/2/8/us-foreign-policy-reduced-to-an-afterthought)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 15:31:13+00:00
 - user: None

Joe Biden’s State of the Union speech skipped foreign policy for a reason.

## Earthquake survivors: ‘Worse than the bombardment in Syria’
 - [https://www.aljazeera.com/news/2023/2/8/turkey-earthquake-worse-than-the-bombardment-in](https://www.aljazeera.com/news/2023/2/8/turkey-earthquake-worse-than-the-bombardment-in)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 15:28:39+00:00
 - user: None

Al Jazeera spoke to two Syrian women who survived the earthquake in Hatay province.

## Infrastructure to blame for high Syria earthquake death toll
 - [https://www.aljazeera.com/news/2023/2/8/time-running-out-for-earthquake-victims-in-northwest-syria](https://www.aljazeera.com/news/2023/2/8/time-running-out-for-earthquake-victims-in-northwest-syria)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 15:26:48+00:00
 - user: None

In northwestern Syria, civil defence teams are working round the clock to save people trapped under earthquake debris.

## Devastation in Turkey’s Hatay as rescue workers slowly arrive
 - [https://www.aljazeera.com/news/2023/2/8/devastation-in-turkeys-hatay-as-rescue-workers-slowly-arrive](https://www.aljazeera.com/news/2023/2/8/devastation-in-turkeys-hatay-as-rescue-workers-slowly-arrive)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 15:14:21+00:00
 - user: None

The Turkish city of Antakya, in Hatay, has emerged as one of the worst hit after Monday&#039;s earthquake.

## Q&A: Colorado River crisis brings ‘very dry’ reality to US West
 - [https://www.aljazeera.com/news/2023/2/8/qa-colorado-river-crisis-brings-very-dry-reality-to-us-west](https://www.aljazeera.com/news/2023/2/8/qa-colorado-river-crisis-brings-very-dry-reality-to-us-west)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 15:05:12+00:00
 - user: None

Al Jazeera speaks to UN expert Lis Mullin Bernhardt about need to adapt to historic drought&#039;s impact on key US waterway.

## NY Philharmonic lures LA’s star conductor Gustavo Dudamel
 - [https://www.aljazeera.com/news/2023/2/8/ny-philharmonic-lures-las-star-conductor-gustavo-dudamel](https://www.aljazeera.com/news/2023/2/8/ny-philharmonic-lures-las-star-conductor-gustavo-dudamel)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 14:57:05+00:00
 - user: None

The move by the famed Venezuelan conductor from LA to NYC marks a major shake-up in the world of classical music.

## Nigeria’s Supreme Court suspends Friday deadline for cash swap
 - [https://www.aljazeera.com/news/2023/2/8/nigerian-court-suspends-friday-deadline-to-swap-banknotes](https://www.aljazeera.com/news/2023/2/8/nigerian-court-suspends-friday-deadline-to-swap-banknotes)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 14:01:35+00:00
 - user: None

Central bank wants to reduce cash in circulation to fight inflation but new bills are in short supply ahead of the vote.

## For Palestine, justice is not a question of law
 - [https://www.aljazeera.com/opinions/2023/2/8/it-will-be-justice-not-law-that-liberates-the-palestinians](https://www.aljazeera.com/opinions/2023/2/8/it-will-be-justice-not-law-that-liberates-the-palestinians)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 13:57:08+00:00
 - user: None

As we work towards Palestinian liberation, we should not forget international law itself is a form of imperial violence.

## UK High Court rules against Bahrain in spyware case
 - [https://www.aljazeera.com/news/2023/2/8/uk-high-court-rules-against-bahrain-in-spyware-case](https://www.aljazeera.com/news/2023/2/8/uk-high-court-rules-against-bahrain-in-spyware-case)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 13:56:49+00:00
 - user: None

Dissidents working to support Bahraini political prisoners allege their laptops were hacked with spyware.

## Outrage over Charlie Hebdo’s Turkey-Syria earthquake cartoon
 - [https://www.aljazeera.com/news/2023/2/8/outrage-over-charlie-hebdos-turkey-syria-earthquake-cartoon](https://www.aljazeera.com/news/2023/2/8/outrage-over-charlie-hebdos-turkey-syria-earthquake-cartoon)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 13:29:05+00:00
 - user: None

The French satirical magazine has once again come under fire for its provocative comic strips.

## South Korea parliament votes to impeach minister over crowd crush
 - [https://www.aljazeera.com/news/2023/2/8/south-korea-parliament-votes-to-impeach-minister-over-crowd-crush](https://www.aljazeera.com/news/2023/2/8/south-korea-parliament-votes-to-impeach-minister-over-crowd-crush)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 12:47:28+00:00
 - user: None

Lee Sang-min held responsible for alleged bungled response to Halloween crowd crush that killed 159 people.

## How to donate to Turkey and Syria earthquake disaster response
 - [https://www.aljazeera.com/news/2023/2/8/how-to-donate-to-turkey-and-syria-earthquake-disaster-response](https://www.aljazeera.com/news/2023/2/8/how-to-donate-to-turkey-and-syria-earthquake-disaster-response)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 12:14:11+00:00
 - user: None

Watchdogs recommend researching before you give money, with several compiling lists of the most effective charities.

## What’s behind Iran and Russia’s efforts to link banking systems?
 - [https://www.aljazeera.com/news/2023/2/8/whats-behind-iran-and-russias-efforts-to-link-banking-systems](https://www.aljazeera.com/news/2023/2/8/whats-behind-iran-and-russias-efforts-to-link-banking-systems)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 12:05:34+00:00
 - user: None

Tehran and Moscow have shown serious political will to expand economic ties, but challenges remain.

## Infographic: How big were the earthquakes in Turkey, Syria?
 - [https://www.aljazeera.com/news/2023/2/8/infographic-how-big-were-the-earthquakes-in-turkey-syria](https://www.aljazeera.com/news/2023/2/8/infographic-how-big-were-the-earthquakes-in-turkey-syria)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 11:37:41+00:00
 - user: None

The magnitude 7.8 and 7.6 quakes are classified as &#039;major&#039; on the Richter scale. Al Jazeera explains what this means.

## Hope, heartbreak as children pulled from rubble in Turkey, Syria
 - [https://www.aljazeera.com/news/2023/2/8/hope-heartbreak-as-children-pulled-from-rubble-in-turkey-syria](https://www.aljazeera.com/news/2023/2/8/hope-heartbreak-as-children-pulled-from-rubble-in-turkey-syria)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 11:01:55+00:00
 - user: None

Millions of children and their families have been impacted by the devastating magnitude 7.8 earthquake.

## Russia’s Lavrov vows aid for W Africa fight against armed groups
 - [https://www.aljazeera.com/news/2023/2/8/russias-lavrov-vows-aid-for-w-africas-jihadist-fight](https://www.aljazeera.com/news/2023/2/8/russias-lavrov-vows-aid-for-w-africas-jihadist-fight)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 10:50:46+00:00
 - user: None

Moscow is seeking to expand its influence in Africa as a diplomatic tug-of-war between global powers continues.

## Zimbabwe is losing doctors, teachers to British hypocrisy
 - [https://www.aljazeera.com/opinions/2023/2/8/zimbabwe-is-bleeding-doctors-teachers-to-the-uk-whos-to-blame](https://www.aljazeera.com/opinions/2023/2/8/zimbabwe-is-bleeding-doctors-teachers-to-the-uk-whos-to-blame)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 09:46:48+00:00
 - user: None

Instead of addressing the concerns of NHS workers and teachers, Britain is plundering talent from Zimbabwe.

## Disney cuts Simpsons China ‘forced labour’ episode in Hong Kong
 - [https://www.aljazeera.com/news/2023/2/8/disney-cuts-simpsons-china-forced-labour-episode-in-hong-kong](https://www.aljazeera.com/news/2023/2/8/disney-cuts-simpsons-china-forced-labour-episode-in-hong-kong)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 09:34:27+00:00
 - user: None

Removal marks the second time Disney has dropped a Simpsons episode from its service in Hong Kong.

## Pakistan’s top rights group raises ‘alarm’ on religious freedom
 - [https://www.aljazeera.com/news/2023/2/8/pakistans-top-rights-group-raises-alarm-on-religious-freedom](https://www.aljazeera.com/news/2023/2/8/pakistans-top-rights-group-raises-alarm-on-religious-freedom)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 09:27:27+00:00
 - user: None

The HRCP report focuses on forced conversions, desecration of places of worship and marginalisation of Ahmadi community.

## Uganda says it will not renew mandate of UN human rights office
 - [https://www.aljazeera.com/news/2023/2/8/uganda-says-it-will-not-renew-mandate-of-u-n-human-rights-office](https://www.aljazeera.com/news/2023/2/8/uganda-says-it-will-not-renew-mandate-of-u-n-human-rights-office)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 09:24:46+00:00
 - user: None

Yoweri Museveni&#039;s government has, over the years, been criticised by the opposition and activists for rights violations.

## The Last Monarch of Tunisia: Power and politics
 - [https://www.aljazeera.com/program/al-jazeera-world/2023/2/8/the-last-monarch-of-tunisia-power-and-politics](https://www.aljazeera.com/program/al-jazeera-world/2023/2/8/the-last-monarch-of-tunisia-power-and-politics)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 09:23:56+00:00
 - user: None

How Tunisia&#039;s last monarch was deposed by its first president - a power struggle remembered on Tunisian Republic Day.

## Turkey-Syria earthquakes day three: What do we know so far?
 - [https://www.aljazeera.com/news/2023/2/8/turkey-syria-earthquakes-day-three-what-do-we-know-so-far](https://www.aljazeera.com/news/2023/2/8/turkey-syria-earthquakes-day-three-what-do-we-know-so-far)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 09:12:10+00:00
 - user: None

Rescuers warn window is closing to find survivors under rubble as death toll passes 9,600.

## Ukraine’s Zelenskyy to meet PM Sunak in first wartime trip to UK
 - [https://www.aljazeera.com/news/2023/2/8/ukraines-zelenskyy-to-meet-pm-sunak-in-first-wartime-trip-to-uk](https://www.aljazeera.com/news/2023/2/8/ukraines-zelenskyy-to-meet-pm-sunak-in-first-wartime-trip-to-uk)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 08:57:54+00:00
 - user: None

The Ukrainian president to meet Rishi Sunak in the first wartime foreign trip to the UK, according to British PM office.

## More than 9000 dead as Turkey, Syria earthquake search continues
 - [https://www.aljazeera.com/news/2023/2/8/turkey-syria-earthquake-search-intensifies-as-death-toll-climbs](https://www.aljazeera.com/news/2023/2/8/turkey-syria-earthquake-search-intensifies-as-death-toll-climbs)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 08:49:06+00:00
 - user: None

The death toll has surpassed 9,000 people and could yet increase dramatically if worst fears of experts are realised.

## Satellite images show scale of destruction in Turkey-Syria quakes
 - [https://www.aljazeera.com/news/longform/2023/2/8/satellite-images-show-scale-of-destruction-in-turkey-syria-earthquake](https://www.aljazeera.com/news/longform/2023/2/8/satellite-images-show-scale-of-destruction-in-turkey-syria-earthquake)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 07:56:45+00:00
 - user: None

Satellite images show the before and after of swaths of Turkey left in ruins by a series of devastating quakes.

## LeBron James breaks NBA all-time points-scoring record
 - [https://www.aljazeera.com/sports/2023/2/8/lebron-james-breaks-nba-all-time-points-scoring-record](https://www.aljazeera.com/sports/2023/2/8/lebron-james-breaks-nba-all-time-points-scoring-record)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 07:48:39+00:00
 - user: None

Los Angeles Lakers star, in his 20th NBA season, passes Kareem Abdul-Jabbar&#039;s 39-year record of 38,387 points.

## Sri Lanka may return to growth by yearend, says president
 - [https://www.aljazeera.com/news/2023/2/8/sri-lanka-may-return-to-growth-by-year-end-says-president](https://www.aljazeera.com/news/2023/2/8/sri-lanka-may-return-to-growth-by-year-end-says-president)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 07:32:34+00:00
 - user: None

The government wants the country to exit bankruptcy by 2026, President Ranil Wickremesinghe tells Parliament.

## North Korea’s Kim lauds army before expected military parade
 - [https://www.aljazeera.com/news/2023/2/8/north-koreas-kim-lauds-army-ahead-of-expected-military-parade](https://www.aljazeera.com/news/2023/2/8/north-koreas-kim-lauds-army-ahead-of-expected-military-parade)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 07:17:34+00:00
 - user: None

Kim visited military officials with his daughter to mark the 75th anniversary of the founding of North Korea&#039;s army.

## Russia-Ukraine war: List of key events, day 350
 - [https://www.aljazeera.com/news/2023/2/8/russia-ukraine-war-list-of-key-events-day-350](https://www.aljazeera.com/news/2023/2/8/russia-ukraine-war-list-of-key-events-day-350)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 07:16:18+00:00
 - user: None

As the Russia-Ukraine war enters its 350th day, we take a look at the main developments.

## Thai children ‘face jail time’ after protest arrests: Amnesty
 - [https://www.aljazeera.com/news/2023/2/8/thai-children-face-jail-time-after-protest-arrests-amnesty](https://www.aljazeera.com/news/2023/2/8/thai-children-face-jail-time-after-protest-arrests-amnesty)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 06:30:56+00:00
 - user: None

Rights group says nearly 300 criminal cases filed against defendants who were children at the time of their arrests.

## Five key takeaways from Joe Biden’s 2023 State of the Union
 - [https://www.aljazeera.com/news/2023/2/8/5-key-takeaways-from-us-president-bidens-2023-state-of-the-union](https://www.aljazeera.com/news/2023/2/8/5-key-takeaways-from-us-president-bidens-2023-state-of-the-union)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 06:01:21+00:00
 - user: None

Biden addressed his legislative agenda for the coming year, including economic goals, China relations and police reform.

## New Zealand recovers 3 tonnes of cocaine floating in the sea
 - [https://www.aljazeera.com/news/2023/2/8/new-zealand-recovers-3-tonnes-of-cocaine-floating-in-the-sea](https://www.aljazeera.com/news/2023/2/8/new-zealand-recovers-3-tonnes-of-cocaine-floating-in-the-sea)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 05:16:19+00:00
 - user: None

Police say the drugs - enough to supply New Zealand for 30 years- were probably destined for Australia.

## Philippine President Marcos visits Japan with focus on security
 - [https://www.aljazeera.com/news/2023/2/8/philippine-president-marcos-visits-japan-with-security-in-focus](https://www.aljazeera.com/news/2023/2/8/philippine-president-marcos-visits-japan-with-security-in-focus)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 05:00:55+00:00
 - user: None

Philippine president and Japanese PM Fumio Kishida are expected to sign an agreement allowing for closer security ties.

## Indonesian video-on-demand films take world by storm
 - [https://www.aljazeera.com/news/2023/2/8/indonesian-video-on-demand-films-take-world-by-storm](https://www.aljazeera.com/news/2023/2/8/indonesian-video-on-demand-films-take-world-by-storm)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 02:00:00+00:00
 - user: None

A series of Netflix Originals is helping cinema from Southeast Asia’s largest nation win global appreciation.

## How is TikTok changing the way we talk about mental health?
 - [https://www.aljazeera.com/program/the-stream/2023/2/8/how-is-tiktok-changing-the-way-we-talk-about-mental-health](https://www.aljazeera.com/program/the-stream/2023/2/8/how-is-tiktok-changing-the-way-we-talk-about-mental-health)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-08 01:18:10+00:00
 - user: None

Health professionals concerned over misinformation in online mental health content.
