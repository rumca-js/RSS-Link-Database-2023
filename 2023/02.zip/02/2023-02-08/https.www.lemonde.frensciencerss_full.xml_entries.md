# Source Le Monde - science, Source URL:https://www.lemonde.fr/en/science/rss_full.xml, Source language: en-US

## Coded letters by Mary, Queen of Scots, discovered and deciphered
 - [https://www.lemonde.fr/en/science/article/2023/02/08/coded-letters-by-mary-queen-of-scots-discovered-and-deciphered_6014885_10.html](https://www.lemonde.fr/en/science/article/2023/02/08/coded-letters-by-mary-queen-of-scots-discovered-and-deciphered_6014885_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-02-08 11:57:35+00:00
 - user: None

These communications with the French ambassador to England were left untouched in the National Library of France. Their author was unknown, but a trio of researchers broke their code: The cursed Queen Mary of Scots who wrote them.
