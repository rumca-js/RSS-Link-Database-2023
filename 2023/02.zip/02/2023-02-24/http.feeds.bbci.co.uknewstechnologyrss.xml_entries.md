# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Netflix cuts prices for subscribers in more than 30 countries
 - [https://www.bbc.co.uk/news/business-64753499?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64753499?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-02-24 04:14:34+00:00

The streaming giant has faced increasing competition from rivals including Amazon, HBO and Disney.

