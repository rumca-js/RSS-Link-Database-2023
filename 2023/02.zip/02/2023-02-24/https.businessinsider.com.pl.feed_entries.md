# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Słynną fabrykę porcelany dobiły ceny gazu. Znów działa sklep internetowy
 - [https://businessinsider.com.pl/biznes/fabryke-porcelany-krzysztof-dobily-ceny-gazu-znow-dziala-sklep-internetowy/rjljvmn](https://businessinsider.com.pl/biznes/fabryke-porcelany-krzysztof-dobily-ceny-gazu-znow-dziala-sklep-internetowy/rjljvmn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 20:52:06+00:00

Fabryka porcelany Krzysztof z Wałbrzycha zakończyła swoją działalność, głównie z powodu podwyżek cen gazu. W piątek poinformowała, że ponownie uruchomiła swój sklep internetowy. Piece zdobnicze nie pracują. Wyprzedaży podlegają stany magazynowe fabryki.

## Dyrektor generalny Hiltona o najgorszej decyzji finansowej. "Wydałem wszystko"
 - [https://businessinsider.com.pl/lifestyle/ceo-hiltona-o-najgorszym-zakupie-wydalem-wszystko-na-glupi-samochod/3dt4c46](https://businessinsider.com.pl/lifestyle/ceo-hiltona-o-najgorszym-zakupie-wydalem-wszystko-na-glupi-samochod/3dt4c46)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 20:28:58+00:00

— Wydałem wszystkie pieniądze na ten głupi samochód — powiedział Chris Nassetta. Dyrektor generalny sieci hoteli Hilton przyznał, że jego najgorszym zakupem było Porsche.

## Zamek w Łapalicach. Wiadomo, co dalej ze słynną samowolą budowlaną
 - [https://businessinsider.com.pl/wiadomosci/zamek-w-lapalicach-zwrot-w-sprawie-najslynnejszej-samowoli-budowlanej/v7xs4xb](https://businessinsider.com.pl/wiadomosci/zamek-w-lapalicach-zwrot-w-sprawie-najslynnejszej-samowoli-budowlanej/v7xs4xb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 19:30:28+00:00

Zamek w Łapalicach to pewnie najsłynniejsza samowola budowlana. Budowa nietypowego obiektu w sercu Kaszub rozpoczęła się jeszcze na początku lat 80., ale w pewnym momencie się zatrzymała. Teraz okazało się, że budowa zamku będzie mogła zostać legalnie dokończona — poinformowały lokalne władze.

## Apele o bojkot nic nie dały. Hogwarts Legacy rozbił bank
 - [https://businessinsider.com.pl/technologie/apele-o-bojkot-nic-nie-daly-hogwarts-legacy-rozbil-bank/6rgrpgm](https://businessinsider.com.pl/technologie/apele-o-bojkot-nic-nie-daly-hogwarts-legacy-rozbil-bank/6rgrpgm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 18:53:41+00:00

Koncern Warner Bros. Discovery poinformował, że osadzona w świecie znanym z książek o Harrym Potterze gra "Hogwarts Legacy" sprzedaje się znacznie lepiej, niż oczekiwano.

## Transgraniczna praca zdalna. Ważny wyrok Trybunału Sprawiedliwości UE
 - [https://businessinsider.com.pl/prawo/praca/praca-transgraniczna-kto-wyplaca-pracownikowi-zalegle-pensje/87qt7q0](https://businessinsider.com.pl/prawo/praca/praca-transgraniczna-kto-wyplaca-pracownikowi-zalegle-pensje/87qt7q0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 18:29:05+00:00

Menedżer z austriackiej firmy pracował w modelu hybrydowym. Jeden tydzień spędzał w siedzibie firmy w Austrii, a w kolejnym pracował zdalnie ze swojego domu w Niemczech. Podlegał niemieckiemu ZUS-owi. Kto ma wypłacić mu zaległe pensje w związku z upadłością pracodawcy? Na to pytanie odpowiedział Trybunał Sprawiedliwości UE.

## Nie tylko terminale Starlink. Polska zbudowała mobilną serwerownię dla Ukrainy
 - [https://businessinsider.com.pl/technologie/nie-tylko-terminale-starlink-polska-zbudowala-mobilna-serwerownie-dla-ukrainy/2cs2jym](https://businessinsider.com.pl/technologie/nie-tylko-terminale-starlink-polska-zbudowala-mobilna-serwerownie-dla-ukrainy/2cs2jym)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 18:25:19+00:00

Polska nie tylko dostarczyła Ukrainie dwie trzecie z funkcjonujących tam terminali Starlink, ale również stworzyła "mobilną, kontenerową serwerownię" — wynika z informacji przekazanych przez pełnomocnika rządu ds. cyberbezpieczeństwa Janusza Cieszyńskiego.

## Uchodźcy z Ukrainy pobierają świadczenia, ale też płacą podatki. Bilans w rok od inwazji
 - [https://businessinsider.com.pl/gospodarka/budzet-05-mld-zl-do-przodu-dzieki-uchodzcom-w-ukrainy/83q2vpx](https://businessinsider.com.pl/gospodarka/budzet-05-mld-zl-do-przodu-dzieki-uchodzcom-w-ukrainy/83q2vpx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 17:53:21+00:00

Można szacować, że ok. 50-55 proc. uchodźców z Ukrainy pracuje. W tym roku z samych podatków i składek z ich pensji wpłynie do budżetu ok. 5,5 mld zł. Patrząc na wydatki i wpływy do budżetu, w 2023 r. bilans pobytu uchodźców w Polsce będzie pozytywny i wyniesie około 0,5 mld zł na plusie — wylicza Bartosz Marczuk z PFR.

## W tych polskich miastach najchętniej osiedlają się uchodźcy z Ukrainy
 - [https://businessinsider.com.pl/gospodarka/te-polskie-miasta-najbardziej-upodobali-sobie-uchodzcy-z-ukrainy/2l7epqs](https://businessinsider.com.pl/gospodarka/te-polskie-miasta-najbardziej-upodobali-sobie-uchodzcy-z-ukrainy/2l7epqs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 17:39:13+00:00

Polska stała się podstawowym kierunkiem ucieczki Ukraińców zagrożonych wojną. Nasi wschodni sąsiedzi najchętniej osiedlają się w największych polskich miastach.

## Ukraina otrzymała czołgi z Polski. Andrzej Duda podbija stawkę
 - [https://businessinsider.com.pl/wiadomosci/ukraina-otrzymala-czolgi-z-polski-andrzej-duda-podbija-stawke/wv7wm1c](https://businessinsider.com.pl/wiadomosci/ukraina-otrzymala-czolgi-z-polski-andrzej-duda-podbija-stawke/wv7wm1c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 17:09:56+00:00

Mam nadzieję, że Niemcy nie tylko przekażą czołgi, ale będą przekazywały także części zamienne — powiedział w piątek prezydent Andrzej Duda po posiedzeniu Rady Bezpieczeństwa Narodowego.

## Rosja znów uderzona sankcjami. Oto lista nowych firm na liście
 - [https://businessinsider.com.pl/gospodarka/rosja-znow-uderzona-sankcjami-oto-lista-nowych-firm-na-liscie/tmlrxjs](https://businessinsider.com.pl/gospodarka/rosja-znow-uderzona-sankcjami-oto-lista-nowych-firm-na-liscie/tmlrxjs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 16:30:40+00:00

Kilkanaście rosyjskich banków i firm z sektorów wojskowego, metalurgicznego oraz górniczego zostało objętych nowymi amerykańskimi sankcjami. Oto najważniejsze z nich.

## Elon Musk znalazł winnego wojny w Ukrainie. Nie chodzi o Władimira Putina
 - [https://businessinsider.com.pl/wiadomosci/elon-musk-znalazl-winnego-wojny-w-ukrainie-nie-chodzi-o-wladimira-putina/7nn7ycj](https://businessinsider.com.pl/wiadomosci/elon-musk-znalazl-winnego-wojny-w-ukrainie-nie-chodzi-o-wladimira-putina/7nn7ycj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 16:20:09+00:00

Twórca Tesli, SpaceX i projektu Starlink Elon Musk wypowiedział się w mediach społecznościowych na temat rosyjskiej inwazji w Ukrainie. Jego wpis na Twitterze wywołał kontrowersje wśród internautów. Miliarder oskarżył bowiem o podsycanie rosyjskiej agresji bynajmniej nie prezydenta Rosji Władimira Putina, ale amerykańską dyplomatkę Victorię Nuland.

## Pierwsze Leopardy z Polski na rocznicę wojny. Światowe media o naszej pomocy dla Ukrainy
 - [https://businessinsider.com.pl/biznes/pierwsze-leopardy-z-polski-na-rocznice-wojny-na-ukrainie/dld8k8s](https://businessinsider.com.pl/biznes/pierwsze-leopardy-z-polski-na-rocznice-wojny-na-ukrainie/dld8k8s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 16:17:09+00:00

Polska jako pierwszy kraj w Europie dostarczyła cztery czołgi Leopard 2A4 na Ukrainę w ramach gestu symbolizującego pierwszą rocznicę wojny z Rosji — donosi agencja Bloomberga. Nasz kraj był liderem grupy państw nawołujących do dostarczenia Ukrainie nowoczesnych zachodnich czołgów.

## Co chiński plan pokojowy oznaczałby dla polskiej gospodarki? "Pekin stosuje strategię ruchu węża"
 - [https://businessinsider.com.pl/international/w-co-graja-chiny-ich-plan-konca-wojny-w-ukrainie-to-pozory-chodzi-o-usa/s3cnj6q](https://businessinsider.com.pl/international/w-co-graja-chiny-ich-plan-konca-wojny-w-ukrainie-to-pozory-chodzi-o-usa/s3cnj6q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 16:08:15+00:00

W rocznicę wybuchu wojny w Ukrainie Chiny ogłosiły swój własny plan pokojowy. Pekin wezwał w nim do zawieszenia walk i natychmiastowych rozmów. W dwunastopunktowym dokumencie nie brak też deklaracji gospodarczych, które wpłynęłyby zarówno na Polskę, jak i Europę. Czy pozytywnie? Eksperci mają wątpliwości.

## Inflacja tak łatwo nie odpuści. Nerwowa reakcja rynku na nowe dane
 - [https://businessinsider.com.pl/gielda/wiadomosci/kiepskie-informacje-o-amerykanskiej-inflacji-tak-wplyna-na-sile-dolara/j6r0slc](https://businessinsider.com.pl/gielda/wiadomosci/kiepskie-informacje-o-amerykanskiej-inflacji-tak-wplyna-na-sile-dolara/j6r0slc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 15:35:01+00:00

Inwestorzy reagują na najnowsze dane płynące z największej gospodarki świata. Wynika z nich, że inflacja w USA tak prędko nie opadnie do wymaganych poziomów, co zwiastuje wyższe stopy procentowe przez dłuższy czas. To niekorzystne warunki dla rynków akcji. Giełdy zniżkują, dolar zyskuje.

## Biura podróży szykują się już do wakacji. Przewoźnik przyznaje: więcej chętnych niż samolotów
 - [https://businessinsider.com.pl/gielda/wiadomosci/oni-juz-szykuja-sie-do-wakacji-przewoznik-wiecej-chetnych-niz-samolotow/nbj5gvq](https://businessinsider.com.pl/gielda/wiadomosci/oni-juz-szykuja-sie-do-wakacji-przewoznik-wiecej-chetnych-niz-samolotow/nbj5gvq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 15:23:04+00:00

Biuro podróży Rainbow Tours podpisało umowę czarteru z największą prywatną linią lotniczą działającą w Polsce. Kontrakt opiewa na kwotę prawie 200 mln zł — o blisko 25 proc. większą niż rok wcześniej. Przewoźnik przyznaje, że popyt, który zgłaszają touroperatorzy, przewyższa liczbę samolotów we flocie Enter Air.

## Oferują możliwość zamrożenia ciała po śmierci. Za połowę ceny – samą głowę
 - [https://businessinsider.com.pl/wideo/oferuja-mozliwosc-zamrozenia-ciala-po-smierci-za-polowe-ceny-sama-glowe/b41b3rd](https://businessinsider.com.pl/wideo/oferuja-mozliwosc-zamrozenia-ciala-po-smierci-za-polowe-ceny-sama-glowe/b41b3rd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 15:02:00+00:00

Za około 140 tys. zł firma KrioRus oferuje możliwość zamrożenia ciała po śmierci. Za połowę ceny można zamrozić samą głowę. Chodzi o to, żeby pewnego dnia w przyszłości odmrozić mózg i przenieść go do awatara, w którym będziesz żyć wiecznie.

## Wiceprezes Grupy ORLEN: „bez dostaw 20 mln ton ropy z Arabii Saudyjskiej połowa Polski mogłaby nie mieć paliwa”
 - [https://businessinsider.com.pl/finanse/wiceprezes-grupy-orlen-bez-dostaw-20-mln-ton-ropy-z-arabii-saudyjskiej-polowa-polski/lfd2x0h](https://businessinsider.com.pl/finanse/wiceprezes-grupy-orlen-bez-dostaw-20-mln-ton-ropy-z-arabii-saudyjskiej-polowa-polski/lfd2x0h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 15:00:00+00:00

ORLEN opublikował wyniki za ostatnie trzy miesiące ubiegłego roku i za cały 2022 rok. Paliwowy gigant zarobił w czwartym kwartale na czysto ponad 8 mld zł a w całym 2022 roku 21,5 mld zł. Janusz Szewczak wiceprezes spółki odniósł się do europejskiego embarga na dostawy ropy z Rosji. Jego zdaniem umowa na dostawy ropy od Saudi Aramco pozwoliła na uniknięcie paliwowego kryzysu w Polsce.

## Lot w kosmos nie tylko dla milionerów. Startup pokazał swój wynalazek i podał cenę
 - [https://businessinsider.com.pl/technologie/lot-w-kosmos-w-kapsule-z-balonem-poleciec-moze-kazdy-za-ile/wdz5kcl](https://businessinsider.com.pl/technologie/lot-w-kosmos-w-kapsule-z-balonem-poleciec-moze-kazdy-za-ile/wdz5kcl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 14:58:45+00:00

Japoński startup zapewnia, że podróż w kosmos może stać się dostępna nawet dla osób, które nie są milionerami lub miliarderami. Wszystko dzięki zaprezentowanej w tym tygodniu hermetycznej kabinie z dwoma miejscami unoszonej przez balon napędzany helem. Oczywiście nie będzie to tania przygoda, choć prezes startupu zapowiada obniżkę ceny. Zainteresowani pierwszymi lotami mogą zgłaszać się do końca sierpnia.

## Nowe biuro P&G – inspiruje, integruje i wykorzystuje rozwiązania przyjazne dla środowiska
 - [https://businessinsider.com.pl/twoje-pieniadze/nieruchomosci/nowe-biuro-pandg-inspiruje-integruje-i-wykorzystuje-rozwiazania-przyjazne-dla/862n6ef](https://businessinsider.com.pl/twoje-pieniadze/nieruchomosci/nowe-biuro-pandg-inspiruje-integruje-i-wykorzystuje-rozwiazania-przyjazne-dla/862n6ef)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 14:53:17+00:00

Procter &amp; Gamble od początku swojej działalności w Polsce jest jednym z cenionych pracodawców, oferującym nie tylko możliwości rozwoju zawodowego, ale także dbającym o to, by tworzone przez firmę środowisko pracy było otwarte dla różnorodnych grup pracowników. Dlatego też stale przygląda się ich potrzebom. Zmieniające się w ostatnich latach modele pracy oraz oczekiwania co do miejsca jej wykonywania sprawiły, że P&amp;G postanowiła przyjrzeć się swojej przestrzeni biurowej.

## Długo opierali się inflacji. Gdy na świecie drożyzna odpuszcza, tam pobiła 41-letni rekord
 - [https://businessinsider.com.pl/gospodarka/ten-kraj-to-fenomen-na-swiecie-drozyzna-odpuszcza-a-tam-bije-41-letni-rekord/s42lw8p](https://businessinsider.com.pl/gospodarka/ten-kraj-to-fenomen-na-swiecie-drozyzna-odpuszcza-a-tam-bije-41-letni-rekord/s42lw8p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 14:47:40+00:00

Na razie nieosiągalnym marzeniem jest dla Polski spadek inflacji do 4,3 proc. Jest ponad czterokrotnie wyższa. Tymczasem na dokładnie taki wzrost cen wskazały w piątek odczyty w Japonii. To najszybszy wzrost w tym kraju od ponad 40 lat. Może to oznaczać koniec ery ujemnych stóp procentowych.

## Ten rodzaj sera ma w sobie żywe larwy owadów
 - [https://businessinsider.com.pl/wideo/ten-rodzaj-sera-ma-w-sobie-zywe-larwy-owadow/68k0k2y](https://businessinsider.com.pl/wideo/ten-rodzaj-sera-ma-w-sobie-zywe-larwy-owadow/68k0k2y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 14:30:00+00:00

Casu marzu z Sardynii to ser dla największych koneserów, których nie odstraszają nawet larwy. Te są zeskrobywane tuż przed jedzeniem.

## Wyjątkowe miejsca na odpoczynek od zimowej szarugi — hotele z basenami, jacuzzi i SPA
 - [https://businessinsider.com.pl/lifestyle/podroze/wyjatkowe-miejsca-na-odpoczynek-od-zimowej-szarugi-hotele-z-basenami-jacuzzi-i-spa/3k824c4](https://businessinsider.com.pl/lifestyle/podroze/wyjatkowe-miejsca-na-odpoczynek-od-zimowej-szarugi-hotele-z-basenami-jacuzzi-i-spa/3k824c4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 14:23:39+00:00

Zima w Polsce trwa już długo, bywa szaro bura i zniechęcająca do wychodzenia z domu. Dlatego dziś proponujemy hotele z pięknie zaprojektowanymi designerskimi basenami, w których pobyt pozwoli zapomnieć o pogodzie za oknem. Takie obiekty to doskonałe miejsca na zimowy i wiosenny urlop w Polsce. Jeśli więc szukasz miejsca, gdzie się zrelaksujesz i odpoczniesz w ciepłym, przyjemnym dla oka otoczeniu, to zachęcamy do zwrócenia uwagi na trzy dzisiejsze propozycje. Na stronie serwisu www.triverna.pl, istnieje możliwość dokonania rezerwacji. Zapraszamy!

## "Nie można ich zostawić, żeby po prostu zgnili w polu". Był ranny 18 razy, teraz identyfikuje ciała poległych
 - [https://businessinsider.com.pl/wiadomosci/identyfikuja-ciala-z-masowych-grobow-to-sprawia-ze-jeszcze-bardziej-czuje-sie/tmwhkye](https://businessinsider.com.pl/wiadomosci/identyfikuja-ciala-z-masowych-grobow-to-sprawia-ze-jeszcze-bardziej-czuje-sie/tmwhkye)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 14:11:57+00:00

Słowańsk, Ukraina. Odkąd rok temu, 24 lutego 2022 r., prezydent Rosji Władimir Putin rozpoczął na pełną skalę inwazję na Ukrainę, w zaminowanych lasach i na zniszczonych polach wzdłuż linii frontu ukraińskiego piętrzą się zwłoki cywilów i żołnierzy. Zadanie odnalezienia i zabrania ciał często spada na cywilów, takich jak Ołeksij Jukow.

## Rosja w pierwszych dniach wojny zestrzeliła własne samoloty
 - [https://businessinsider.com.pl/technologie/rosja-w-pierwszych-dniach-wojny-zestrzelila-wlasne-samoloty/ed3g51t](https://businessinsider.com.pl/technologie/rosja-w-pierwszych-dniach-wojny-zestrzelila-wlasne-samoloty/ed3g51t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 14:05:53+00:00

W pierwszych dniach inwazji na Ukrainę Rosja zestrzeliła kilka własnych samolotów, co zaowocowało brakiem chętnych pilotów, których Moskwa potrzebowała do zdobycia przewagi powietrznej — donosi "The Financial Times".

## Co sprawia, że jesteś nieszczęśliwy? Oto trzy główne powody
 - [https://businessinsider.com.pl/wideo/co-sprawia-ze-jestes-nieszczesliwy-oto-trzy-glowne-powody/zvccv7j](https://businessinsider.com.pl/wideo/co-sprawia-ze-jestes-nieszczesliwy-oto-trzy-glowne-powody/zvccv7j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 13:45:00+00:00

"Pułapki myślenia", brak reakcji "opieki-zaprzyjaźniania" oraz ignorowanie własnego ciała — to główne powody, przez które czujemy się nieszczęśliwi. Psycholog z Uniwerystetu Nowojorskiego tłumaczy nasze wahania nastrojów.

## Eleganckie kuchenki mikrofalowe do zabudowy — którą wybrać?
 - [https://businessinsider.com.pl/technologie/eleganckie-kuchenki-mikrofalowe-do-zabudowy-ktora-wybrac/wy6xxd5](https://businessinsider.com.pl/technologie/eleganckie-kuchenki-mikrofalowe-do-zabudowy-ktora-wybrac/wy6xxd5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 13:35:00+00:00

Szukasz kuchenki mikrofalowej do zabudowy? Dobrze się składa, bo znajdziesz tutaj pięć wybranych przez nas modeli, które wyróżniają się eleganckim wyglądem. Design to przecież bardzo istotna kwestia, bo taki sprzęt będzie na widoku w naszej kuchni przez wiele lat. Oprócz tego te urządzenia mają również przyzwoite parametry.

## W Orlenie przyznają, że są problemy z ropą i gazem w Polsce. Jest im łatwiej w innym kraju
 - [https://businessinsider.com.pl/biznes/orlen-pakuje-duze-pieniadze-w-wydobycie-przyznaje-ze-w-polsce-jest-trudno/l4xwhvt](https://businessinsider.com.pl/biznes/orlen-pakuje-duze-pieniadze-w-wydobycie-przyznaje-ze-w-polsce-jest-trudno/l4xwhvt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 13:32:50+00:00

Orlen chce zainwestować w 2023 r. nawet 36 mld zł. Jedna szósta tej kwoty ma pójść na wydobycie ropy naftowej i gazu w Polsce i Norwegii. Dyrektor płockiego koncernu przyznaje jednak, że u nas jest ono trudniejsze i droższe.

## Zachód wymierzył kolejny cios rosyjskiej gospodarce
 - [https://businessinsider.com.pl/gospodarka/w-rocznice-inwazji-na-ukraine-zachod-udzerza-w-gospodarke-rosji/z4pvlxx](https://businessinsider.com.pl/gospodarka/w-rocznice-inwazji-na-ukraine-zachod-udzerza-w-gospodarke-rosji/z4pvlxx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 13:24:14+00:00

W rocznicę inwazji Kremla na Ukrainę USA ogłosiły nowe sankcje wobec Rosji, które mają uderzyć w gospodarkę agresora. Administracja Joe Bidena wymierzyła je w instytucje finansowe, przemysł obronny oraz sektor metali i górnictwa.

## Wojna zdewastowała ukraiński przemysł. Odrabianie strat idzie mozolnie
 - [https://businessinsider.com.pl/gospodarka/fatalne-skutki-rosyjskiej-agresji-tak-skurczyl-sie-ukrainski-przemysl/nedtqby](https://businessinsider.com.pl/gospodarka/fatalne-skutki-rosyjskiej-agresji-tak-skurczyl-sie-ukrainski-przemysl/nedtqby)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 13:22:39+00:00

Wybuch wojny, rozpoczętej przez Rosję równo rok temu, fatalnie odbił się na ukraińskiej gospodarce. Przede wszystkim tąpnięcie odczuwa przemysł, najważniejsza jej gałąź. Nakłady niezbędne do odbudowy będą gigantyczne.

## Boeing wstrzymuje dostawy dreamlinerów. Odkrył błąd
 - [https://businessinsider.com.pl/biznes/koszmar-dreamlinerow-boeing-wstrzymuje-dostawy-odkryl-blad/y4ddw1j](https://businessinsider.com.pl/biznes/koszmar-dreamlinerow-boeing-wstrzymuje-dostawy-odkryl-blad/y4ddw1j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 12:50:37+00:00

Jeden z największych na świecie producentów samolotów odkrył problem w dokumentacji dotyczącej samolotu Dreamliner. W związku z tym w najbliższym czasie żadna nowa maszyna nie trafi do użytku. Trop w sprawie winnego pada na jednego z dostawców. "Nie ma żadnych bezpośrednich obaw dotyczących bezpieczeństwa dla floty w służbie" — podkreśla Boeing.

## Ukraina się broni. Tak wygląda wojskowe wsparcie z Polski, kwota robi wrażenie
 - [https://businessinsider.com.pl/technologie/ukraina-sie-broni-tak-wyglada-wojskowe-wsparcie-z-polski/r2dssmy](https://businessinsider.com.pl/technologie/ukraina-sie-broni-tak-wyglada-wojskowe-wsparcie-z-polski/r2dssmy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 12:18:38+00:00

Sprzęt wojskowy, który Polska przekazała walczącej z rosyjską agresją Ukrainie był, jest wart więcej niż 2,2 mld zł. W dodatku to wyliczenia nieuwzględniające czołgów Leopard 2, które mają już znajdować się za naszą wschodnią granicą.

## Inflacja w USA spada, ale jedna rzecz ciągle martwi. Yellen: wciąż jest dużo do zrobienia
 - [https://businessinsider.com.pl/gospodarka/tego-mozemy-pozazdroscic-amerykanom-yellen-jest-duzo-do-zrobienia/mndgw1x](https://businessinsider.com.pl/gospodarka/tego-mozemy-pozazdroscic-amerykanom-yellen-jest-duzo-do-zrobienia/mndgw1x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 11:56:31+00:00

Podwyżki cen w USA systematycznie odpuszczają, ale ciągle jest daleka droga do powrotu kluczowego wskaźnika cenowego do docelowego poziomu. Sekretarz skarbu USA podkreśla, że jest dużo do zrobienia. Ocenia, że "miękkie lądowanie" bez recesji jest możliwe dzięki dwóm czynnikom.

## Kredytobiorcy mieszkaniowi popadają w tarapaty. Tutaj sięgają po pomoc
 - [https://businessinsider.com.pl/finanse/wiecej-pomocy-dla-kredytobiorcow-mieszkaniowych-oto-nowe-dane/g8fvxs8](https://businessinsider.com.pl/finanse/wiecej-pomocy-dla-kredytobiorcow-mieszkaniowych-oto-nowe-dane/g8fvxs8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 11:34:08+00:00

Trudniejsza sytuacja gospodarcza, przede wszystkim wzrost inflacji i stóp procentowych, zaczyna odbijać się na zdolności kredytobiorców do spłaty zobowiązań finansowych wobec banków. Wyraźnie przybywa pomocy udzielanej w ramach Funduszu Wsparcia Kredytobiorców.

## Polska bramą dla ukraińskiego handlu. Obroty tymi produktami były największe
 - [https://businessinsider.com.pl/gospodarka/polska-brama-dla-ukrainskiego-handlu-tak-rosnie-import-i-eksport/8qlnqrn](https://businessinsider.com.pl/gospodarka/polska-brama-dla-ukrainskiego-handlu-tak-rosnie-import-i-eksport/8qlnqrn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 11:06:04+00:00

Polska infrastruktura kolejowa, drogowa i porty morskie stały się dla Ukrainy bramą do światowego rynku. Import towarów z Ukrainy urósł w ubiegłym roku o 52 proc. Wartość eksportu do naszych wschodnich sąsiadów zwiększyła się o 59 proc.

## Przerażająca cena papryki. Co się wydarzyło, że zdrożała o 150 proc.
 - [https://businessinsider.com.pl/finanse/handel/przerazajaca-cena-papryki-co-sie-wydarzylo-ze-zdrozala-o-150-proc/2tbp2nh](https://businessinsider.com.pl/finanse/handel/przerazajaca-cena-papryki-co-sie-wydarzylo-ze-zdrozala-o-150-proc/2tbp2nh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 11:03:19+00:00

Papryka osiąga tak zawrotne ceny, że wielu Polaków jej sobie po prostu odmawia. Obecnie kosztuje w hurcie 20 zł za kilogram, a w sklepach nawet 35 zł — informuje serwis dlahandlu.pl. TyJeszcze rok temu, w lutym za paprykę płaciliśmy od 7,5 do 13,5 zł.

## Z niemiecką gospodarką jest gorzej, niż się wydawało. Kryzys zbiera żniwo
 - [https://businessinsider.com.pl/gospodarka/niemcy-odczuli-kryzys-zbiera-zniwo-i-prowadzi-gospodarke-w-recesje/z9gfnkj](https://businessinsider.com.pl/gospodarka/niemcy-odczuli-kryzys-zbiera-zniwo-i-prowadzi-gospodarke-w-recesje/z9gfnkj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 10:54:45+00:00

Niemiecka gospodarka skurczyła się w końcówce 2022 r. Kwartał do kwartału PKB zmniejszył się o 0,4 proc., czyli dwukrotnie mocniej od oczekiwań — wynika z piątkowej publikacji Destatis. Eksperci wskazują największe słabości.

## Popularny sklep rozwija biznes w internecie. Można skorzystać w 70 lokalizacjach
 - [https://businessinsider.com.pl/finanse/handel/popularny-sklep-rozwija-biznes-w-internecie-mozna-skorzystac-w-70-lokalizacjach/41d3ql0](https://businessinsider.com.pl/finanse/handel/popularny-sklep-rozwija-biznes-w-internecie-mozna-skorzystac-w-70-lokalizacjach/41d3ql0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 10:04:21+00:00

Kolejna sieć rozwija się w branży e-commerce. Stokrotka poszerza liczbę miast, w których zakupy będzie można zrobić przez internet. E-sklep sieci będzie już dostępny w 70 miastach.

## McDonald's znowu podniósł ceny w Polsce. Ile trzeba zapłacić za kanapkę?
 - [https://businessinsider.com.pl/wiadomosci/mcdonalds-znowu-podniosl-ceny-w-polsce-ile-trzeba-zaplacic-za-kanapke/ej0q0pb](https://businessinsider.com.pl/wiadomosci/mcdonalds-znowu-podniosl-ceny-w-polsce-ile-trzeba-zaplacic-za-kanapke/ej0q0pb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 09:50:41+00:00

Nieco ponad 3 zł — taka była przed ponad 20 laty cena cheeseburgera w McDonald's. W promocji można go było dorwań nawet za niecałe 2 zł. A dziś? To już tylko wspomnienie, bo sieć właśnie po raz kolejny podniosła cenę.

## Orlen ma konkretne oczekiwania wobec ropy, gazu i energii w 2023 r. Podał ceny
 - [https://businessinsider.com.pl/gielda/wiadomosci/ile-bedzie-kosztowac-ropa-gaz-i-energia-w-2023-r-orlen-podal-ceny/4qrd3rf](https://businessinsider.com.pl/gielda/wiadomosci/ile-bedzie-kosztowac-ropa-gaz-i-energia-w-2023-r-orlen-podal-ceny/4qrd3rf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 09:42:22+00:00

PKN Orlen prognozuje spadki cen ropy naftowej, gazu ziemnego i energii elektrycznej w 2023 r. względem poprzedniego roku. Wskazuje na istotną rolę USA i Chin w ich kształtowaniu. Można też oczekiwać stopniowego wzrostu produkcji paliw z sukcesywnie oddawanych do użytku nowych rafinerii w USA, w Afryce, na Bliskim Wschodzie i w Azji.

## Rekompensaty za maluchy i duże fiaty. Państwo wciąż oddaje pieniądze
 - [https://businessinsider.com.pl/poradnik-finansowy/rekompensaty-za-maluchy-i-duze-fiaty-panstwo-wciaz-oddaje-pieniadze/kdctnmt](https://businessinsider.com.pl/poradnik-finansowy/rekompensaty-za-maluchy-i-duze-fiaty-panstwo-wciaz-oddaje-pieniadze/kdctnmt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 09:25:33+00:00

Choć poprzeszło 40 latach może to być zaskoczenie, to wciąż można odzyskać pieniądze wyłożone w PRL-u na malucha lub dużego fiata. Mowa o nawet przeszło 20 tys. zł.

## Rozliczyłeś już PIT? Skarbówka mogła już zwrócić nadpłatę
 - [https://businessinsider.com.pl/gospodarka/podatki/rozliczyles-juz-pit-skarbowka-mogla-juz-zwrocic-nadplate/rqlgxd9](https://businessinsider.com.pl/gospodarka/podatki/rozliczyles-juz-pit-skarbowka-mogla-juz-zwrocic-nadplate/rqlgxd9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 09:17:58+00:00

Podatnicy złożyli już ponad dwa miliony deklaracji przygotowanych dla nich przez KAS w usłudze Twój e-PIT. Wwypłacono też pierwsze zwroty. Dotychczas urzędy skarbowe zwróciły podatnikom łącznie ponad 370 mln zł – podało Ministerstwo Finansów w piątek.

## Auchan, Leroy Merlin i Decathlon obrywały za pozostanie w Rosji. Co dziś zostało z bojkotu?
 - [https://businessinsider.com.pl/firmy/auchan-leroy-merlin-i-decathlon-obrywaly-za-pozostanie-w-rosji-co-dzis-zostalo-z/36qre94](https://businessinsider.com.pl/firmy/auchan-leroy-merlin-i-decathlon-obrywaly-za-pozostanie-w-rosji-co-dzis-zostalo-z/36qre94)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 08:33:48+00:00

Znajdujące się we francuskich rękach sieci Auchan, Leroy Merlin i Decathlon nie zdecydowały się na opuszczenie Rosji zaraz po jej inwazji na Ukrainę. Wielu klientów w Polsce deklarowało wówczas ich bojkot. Co z tego zostało? Mamy najnowsze dane.

## Rekordowa sprzedaż Orlenu. Przekroczyła połowę dochodów budżetowych państwa
 - [https://businessinsider.com.pl/gielda/wiadomosci/rekordowa-sprzedaz-orlenu-przekroczyla-polowe-dochodow-budzetowych-panstwa/mh6z6ty](https://businessinsider.com.pl/gielda/wiadomosci/rekordowa-sprzedaz-orlenu-przekroczyla-polowe-dochodow-budzetowych-panstwa/mh6z6ty)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 08:17:06+00:00

Pierwszy raz możemy zobaczyć imperium Obajtka w pełnej krasie. Połączona grupa Orlen pochwaliła się rekordowymi wynikami finansowymi. Tylko w ostatnim kwartale miała przychody przekraczające 100 mld zł i 8 mld zł czystego zysku. W całym 2022 r. sprzedaż była na poziomie około 60 proc. dochodów budżetowych państwa, a zysk netto wyniósł 21,5 mld zł.

## Rekordowa sprzedaż Orlenu. Przekroczyła połowę dochodów budżetowych państwa
 - [https://businessinsider.com.pl/gielda/wiadomosci/imperium-obajtka-pierwszy-raz-w-pelnej-krasie-rekordowe-wyniki/mh6z6ty](https://businessinsider.com.pl/gielda/wiadomosci/imperium-obajtka-pierwszy-raz-w-pelnej-krasie-rekordowe-wyniki/mh6z6ty)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 08:17:06+00:00

Pierwszy raz możemy zobaczyć imperium zarządzane przed Daniela Obajtka w pełnej krasie. Połączona grupa Orlen pochwaliła się rekordowymi wynikami finansowymi. Tylko w ostatnim kwartale miała przychody przekraczające 100 mld zł i 8 mld zł czystego zysku. W całym 2022 r. sprzedaż była na poziomie około 60 proc. dochodów budżetowych państwa, a zysk netto wyniósł 21,5 mld zł.

## Mateusz Morawiecki z niespodziewaną wizytą w Kijowie
 - [https://businessinsider.com.pl/wiadomosci/mateusz-morawiecki-z-niespodziewana-wizyta-w-kijowie/4qff55b](https://businessinsider.com.pl/wiadomosci/mateusz-morawiecki-z-niespodziewana-wizyta-w-kijowie/4qff55b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 08:16:04+00:00

Premier Morawiecki pojechał do Kijowa w pierwszą rocznicę rosyjskiej napaści na Ukrainę.

## Wybierz się w rejs najpiękniejszymi rzekami Europy — Mozela, Ren, Dunaj
 - [https://businessinsider.com.pl/lifestyle/podroze/wybierz-sie-w-rejs-najpiekniejszymi-rzekami-europy-mozela-ren-dunaj/ntc0m7k](https://businessinsider.com.pl/lifestyle/podroze/wybierz-sie-w-rejs-najpiekniejszymi-rzekami-europy-mozela-ren-dunaj/ntc0m7k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 08:12:00+00:00

Rejs jedną z najpiękniejszych europejskich rzek może być doskonałą alternatywą dla urlopu, podczas którego większość czasu spędzamy na plaży, opuszczając ją jedynie na posiłki w bogatej formule all inclusive. Rzeczne rejsy pasażerskie to interesująca forma wypoczynku dla wszystkich, którym znudziły się tradycyjne urlopy i potrzebują przeżyć coś nowego. Rejsy wycieczkowe to połączenie innej perspektyw zwiedzania, poznawania zabytków, architektury, historii, kultury z jednoczesną wygodą i relaksem. Widok kameralnych wiosek położonych wzdłuż Renu, wspaniałej architektury Wiednia, Budapesztu i Bratysławy, który towarzyszy podczas rejsu Dunajem to tylko część atrakcji, jakie można podziwiać z pokładu statku. W artykule polecamy sprawdzone i docenione przez klientów rejsy wycieczkowe biura podróży Albatros. Zapraszamy!

## Kurs franka 24 lutego poniżej 4,8
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-24-lutego-2023/0293qy3](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-24-lutego-2023/0293qy3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 08:03:25+00:00

Frank szwajcarskiponiżej 4,8. W piątek rano 24 lutego 2022 r. kurs tej waluty wobec polskiego złotego wynosi 4,7678.

## Kurs dolara 24 lutego poniżej 4,5
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-24-lutego-2023/fl1h3m0](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-24-lutego-2023/fl1h3m0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 08:00:03+00:00

Kurs dolara poniżej 4,5. W piątek rano 24 lutego 2022 r. kurs USD/PLN wynosi 4,4590.

## Kurs euro 24 lutego poniżej 4,75
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-24-lutego-2023/ssekzm3](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-24-lutego-2023/ssekzm3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 07:57:55+00:00

Kurs euro poniżej 4,75. W piątek rano 24 lutego 2022 r. kurs EUR/PLN wynosił 4,7224 zł.

## Chiny chcą dostarczać Rosji drony kamikadze. Mają fałszować dokumenty
 - [https://businessinsider.com.pl/wiadomosci/chiny-chca-dostarczac-rosji-drony-kamikadze-maja-falszowac-dokumenty/tek5q1x](https://businessinsider.com.pl/wiadomosci/chiny-chca-dostarczac-rosji-drony-kamikadze-maja-falszowac-dokumenty/tek5q1x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 06:56:54+00:00

Rosyjska armia prowadzi z Chinami rozmowy o produkcji dronów kamikadze. Do Moskwy mają one trafić dzięki sfałszowanym dokumentom przewozowym — poinformował w piątek portal tygodnika "Der Spiegel".

## Warszawa nie uznaje jego 157 lokali. Deweloper od "Hongkongu" ostro odpowiada
 - [https://businessinsider.com.pl/twoje-pieniadze/nieruchomosci/warszawa-nie-uznaje-jego-157-lokali-deweloper-od-hongkongu-ostro-odpowiada/qptk222](https://businessinsider.com.pl/twoje-pieniadze/nieruchomosci/warszawa-nie-uznaje-jego-157-lokali-deweloper-od-hongkongu-ostro-odpowiada/qptk222)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 06:43:36+00:00

Urzędnicy z Warszawy uznali, że 157 lokali w inwestycji na Woli miało być pokojami hotelowymi, a nie mieszkaniami i odmawiają wydania tzw. zaświadczenia o ich samodzielności. Józef Wojciechowski, przewodniczący Rady Nadzorczej spółki J.W. Construction, odpowiada, że to "przykład urzędniczej niekompetencji, niewiedzy i potwierdza uciążliwość postępowania urzędników warszawskiego ratusza".

## Na te promocje klienci Biedronki trafiają najczęściej
 - [https://businessinsider.com.pl/finanse/handel/na-te-promocje-klienci-biedronki-trafiaja-najczesciej/jgyd03q](https://businessinsider.com.pl/finanse/handel/na-te-promocje-klienci-biedronki-trafiaja-najczesciej/jgyd03q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 06:39:14+00:00

Biedronka ujawniła dane dot. swojej aplikacji lojalnościowej. Obecnie korzysta z niej 7 mln Polaków.

## Chiny chcą negocjacji Rosji i Ukrainy. Jest apel
 - [https://businessinsider.com.pl/wiadomosci/chiny-chca-negocjacji-rosji-i-ukrainy-jest-apel/8pbtgy0](https://businessinsider.com.pl/wiadomosci/chiny-chca-negocjacji-rosji-i-ukrainy-jest-apel/8pbtgy0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 06:06:47+00:00

Chiński rząd wezwał Rosję i Ukrainę do wznowienia dialogu i odrzucił wszelkie próby użycia broni jądrowej w 12-punktowym dokumencie opublikowanym w piątek, rok po ataku Rosji na Ukrainę.

## Chiny chcą negocjacji Rosji i Ukrainy. Jest apel
 - [https://businessinsider.com.pl/wiadomosci/chinska-propozycja-pokojowa-apel-ws-wojny-w-ukrainie/8pbtgy0](https://businessinsider.com.pl/wiadomosci/chinska-propozycja-pokojowa-apel-ws-wojny-w-ukrainie/8pbtgy0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 06:06:47+00:00

Chiński rząd wezwał Rosję i Ukrainę do wznowienia dialogu i odrzucił wszelkie próby użycia broni jądrowej w 12-punktowym dokumencie opublikowanym w piątek, rok po ataku Rosji na Ukrainę.

## Bijemy w Polsce rekordy aktywności zawodowej. Na 1000 pracujących przypada 786 niepracujących
 - [https://businessinsider.com.pl/gospodarka/bijemy-w-polsce-rekordy-aktywnosci-zawodowej-na-1000-pracujacych-przypada-786/nm8kbnh](https://businessinsider.com.pl/gospodarka/bijemy-w-polsce-rekordy-aktywnosci-zawodowej-na-1000-pracujacych-przypada-786/nm8kbnh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:55:35+00:00

Coraz mniejsza liczba ludności na razie nie robi krzywdy gospodarce, bo jednocześnie rośnie nasza aktywność zawodowa i to rośnie do poziomów rekordowych. Rekordowo małą aktywność mamy za to na rynku kredytów mieszkaniowych, chociaż to się być może zmieni, bo rząd robi postępy w pracach nad "kredytem 2 proc.". W strefie euro inflacja spada, ale inflacja bazowa dalej rośnie, natomiast Netflix obniża ceny abonamentów. Jednak tylko w niektórych krajach, a Polska do tej grupy się nie zalicza. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Wyjście z Rosji jest ryzykowne. Nieprzestrzeganie sankcji też
 - [https://businessinsider.com.pl/prawo/wyjscie-z-rosji-jest-ryzykowne-nieprzestrzeganie-sankcji-przez-firmy-tez/hpy716h](https://businessinsider.com.pl/prawo/wyjscie-z-rosji-jest-ryzykowne-nieprzestrzeganie-sankcji-przez-firmy-tez/hpy716h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:41:09+00:00

Wyjścia z Rosji, choć są działaniem oczekiwanym przez społeczeństwa zachodnie, przypominają często stąpanie po kruchym lodzie – mówi w rozmowie z Business Insiderem Piotr Jaśkiewicz, adwokat polski i amerykański z kancelarii Baker McKenzie. Różne kraje różnie interpretują takie działania. Z drugiej strony, działając w Rosji, też trzeba przestrzegać sankcji. Ich omijanie grozi wysokimi karami.

## W tym specjalizują się Ukraińcy w Polsce. Założyli tysiące firm
 - [https://businessinsider.com.pl/wiadomosci/w-tym-specjalizuja-sie-ukraincy-w-polsce/8kljkf1](https://businessinsider.com.pl/wiadomosci/w-tym-specjalizuja-sie-ukraincy-w-polsce/8kljkf1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:37:18+00:00

Od wybuchu wojny systematycznie rośnie liczba firm zakładanych przez obywateli Ukrainy w Polsce — wskazała Aleksandra Wejt-Knyżewskiej z Polskiego Instytutu Ekonomicznego. Dodała, że od marca 2022 r. założyli oni u nas ponad 17,7 tys. jednoosobowych działalności gospodarczych.

## Harvey Weinstein skazany. Z więzienia wyjdzie przed 90-tką
 - [https://businessinsider.com.pl/wiadomosci/harvey-weinstein-skazany-z-wiezienia-wyjdzie-przed-90-tka/56jj19y](https://businessinsider.com.pl/wiadomosci/harvey-weinstein-skazany-z-wiezienia-wyjdzie-przed-90-tka/56jj19y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:28:22+00:00

Oskarżany przez wiele kobiet o molestowanie hollywoodzki producent Harvey Weinstein otrzymał w czwartek wyrok 16 lat więzienia za gwałt i napaść seksualną. Sąd w Los Angeles odrzucił petycję jego adwokatów o nowy proces.

## Koniec chorobowego eldorado. Więcej kontroli i wstrzymanych wypłat
 - [https://businessinsider.com.pl/prawo/praca/koniec-chorobowego-eldorado-wiecej-kontroli-i-wstrzymanych-wyplat/5eyt8l6](https://businessinsider.com.pl/prawo/praca/koniec-chorobowego-eldorado-wiecej-kontroli-i-wstrzymanych-wyplat/5eyt8l6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:25:30+00:00

Nadużywasz L4, aby zyskać dodatkowy czas wolny od pracy? Rośnie szansa, że sprawdzi cię ZUS. Tylko w ubiegłym roku inspektorzy przeprowadzili 430 tys. kontroli zwolnień lekarskich, czyli aż o 76,7 tys. więcej niż w 2021 r. W tym roku może być ich nawet 500 tys.

## "Powiedziałem żonie: drugi raz Rosjanie nie zniszczą nam domu, dopadnę ich wcześniej"
 - [https://businessinsider.com.pl/gospodarka/powiedzialem-zonie-drugi-raz-rosjanie-nie-zniszcza-nam-domu-dopadne-ich-wczesniej/f7e3k7v](https://businessinsider.com.pl/gospodarka/powiedzialem-zonie-drugi-raz-rosjanie-nie-zniszcza-nam-domu-dopadne-ich-wczesniej/f7e3k7v)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:17:07+00:00

— Musimy odbudować nasze domy i pokazać Rosji, że nie jesteśmy słabi, że się nie boimy. Wcześniej nie mogliśmy sobie tego nawet wyobrazić. Dziś mamy już wizję i jesteśmy na to gotowi — zapewnia w rozmowie z Business Insiderem Wadim Naumow z magistratu w podkijowskiej Buczy. Usuwanie wojennych zniszczeń trwa tam od miesięcy, ale wciąż jest wiele do zrobienia. Potrzebne są przede wszystkim pieniądze, a w skali całej Ukrainy rachunek ten z każdym dniem stale rośnie.

## Sankcje miały zmiażdżyć rosyjską gospodarkę. Po roku wojny niektóre liczby ma lepsze niż Polska
 - [https://businessinsider.com.pl/gospodarka/po-roku-wojny-rosyjska-gospodarka-zaskakuje-sprawdz-najwazniejsze-liczby/3dx5vgs](https://businessinsider.com.pl/gospodarka/po-roku-wojny-rosyjska-gospodarka-zaskakuje-sprawdz-najwazniejsze-liczby/3dx5vgs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:05:00+00:00

Po roku wojny w Ukrainie rosyjska gospodarka skurczyła się o ponad 2 proc. Podobny jest deficyt w państwowej kasie szacowany na ponad 3 bln rubli. Rosja notuje rekordowy odpływ kapitału, spadek realnych płac i emerytur, niższą konsumpcję i dwucyfrową inflację. Nie jest to wymarzona sytuacja dla Władimira Putina, ale eksperci przyznają, że scenariusze kreślone rok temu były dużo gorsze.

## Jeszcze rok temu wydawało się to nie do pomyślenia. Pięć faktów, które od wybuchu wojny zmieniły świat
 - [https://businessinsider.com.pl/wiadomosci/rok-od-wybuchu-wojny-w-ukrainie-te-piec-faktow-zmienilo-swiat/e6z5l4w](https://businessinsider.com.pl/wiadomosci/rok-od-wybuchu-wojny-w-ukrainie-te-piec-faktow-zmienilo-swiat/e6z5l4w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:04:00+00:00

Choć nadal nie wiemy, jak skończy się atak Rosji na Ukrainę, po roku trwania wojny można już wskazać na kilka najistotniejszych zjawisk, które zaskoczyły niejednego analityka. Oto pięć najważniejszych faktów, które jeszcze rok temu trudno było przewidzieć.

## Czy Putin jest chory? Uszkodził kręgosłup, gdy uczył latać młode żurawie
 - [https://businessinsider.com.pl/wiadomosci/putin-jest-chory-uszkodzil-kregoslup-gdy-uczyl-latac-mlode-zurawie/26vplnv](https://businessinsider.com.pl/wiadomosci/putin-jest-chory-uszkodzil-kregoslup-gdy-uczyl-latac-mlode-zurawie/26vplnv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

Ukraina nie radzi sobie na froncie tak dobrze, jak chciałyby tego zachodnie media, a sam Władimir Putin ma na Kremlu bardzo silną pozycję. Strach przed nim jest nadal ogromny, choć stan zdrowia prezydenta Rosji pozostawia wiele do życzenia — mówi w wywiadzie dla Business Insider Polska Krystyna Kurczab-Redlich, dziennikarka, autorka publikacji poświęconych Rosji i Putinowi. Opowiada też, jak w Rosji przedstawiana jest druga wojna światowa i przyznaje, że choć poświęciła Putinowi dużą część życia zawodowego, ona także uległa złudzeniom na temat dyktatora Rosji.

## Czy Putin jest chory? Uszkodził kręgosłup, gdy uczył latać młode żurawie
 - [https://businessinsider.com.pl/wiadomosci/tak-moze-skonczyc-putin-zamach-jest-mozliwy-ale-i-strach-przed-nim-wciaz-jest-wielki/26vplnv](https://businessinsider.com.pl/wiadomosci/tak-moze-skonczyc-putin-zamach-jest-mozliwy-ale-i-strach-przed-nim-wciaz-jest-wielki/26vplnv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

Ukraina nie radzi sobie na froncie tak dobrze, jak chciałyby tego zachodnie media, a sam Władimir Putin ma na Kremlu bardzo silną pozycję. Strach przed nim jest nadal ogromny, choć stan zdrowia prezydenta Rosji pozostawia wiele do życzenia — mówi w wywiadzie dla Business Insider Polska Krystyna Kurczab-Redlich, dziennikarka, autorka publikacji poświęconych Rosji i Putinowi. Opowiada też, jak w Rosji przedstawiana jest druga wojna światowa i przyznaje, że choć poświęciła Putinowi dużą część życia zawodowego, ona także uległa złudzeniom na temat dyktatora Rosji.

## Zjadła zęby na analizowaniu Rosji i Putina. Mówi, jaki może być jego koniec
 - [https://businessinsider.com.pl/wiadomosci/zjadla-zeby-na-analizowaniu-rosji-i-putina-mowi-jaki-moze-byc-jego-koniec/26vplnv](https://businessinsider.com.pl/wiadomosci/zjadla-zeby-na-analizowaniu-rosji-i-putina-mowi-jaki-moze-byc-jego-koniec/26vplnv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

Ukraina nie radzi sobie na froncie tak dobrze, jak chciałyby tego zachodnie media, a sam Władimir Putin ma na Kremlu bardzo silną pozycję. Strach przed nim jest nadal ogromny, choć stan zdrowia prezydenta Rosji pozostawia wiele do życzenia — mówi w wywiadzie dla Business Insider Polska Krystyna Kurczab-Redlich, dziennikarka, autorka publikacji poświęconych Rosji i Putinowi. Opowiada też, jak w Rosji przedstawiana jest druga wojna światowa i przyznaje, że choć poświęciła Putinowi dużą część życia zawodowego, ona także uległa złudzeniom na temat dyktatora Rosji.

