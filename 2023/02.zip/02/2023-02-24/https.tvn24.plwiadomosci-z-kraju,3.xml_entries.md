# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Unia Europejska przyjęła "najpotężniejsze i najdalej idące sankcje" wobec Rosji
 - [https://tvn24.pl/swiat/rosja-sankcje-unia-europejska-przyjela-10-pakiet-sankcji-wobec-rosji-6776341?source=rss](https://tvn24.pl/swiat/rosja-sankcje-unia-europejska-przyjela-10-pakiet-sankcji-wobec-rosji-6776341?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 21:47:24+00:00

<img alt="Unia Europejska przyjęła " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-gr6h1g-moskwa-rosja-6774117/alternates/LANDSCAPE_1280" />
    Państwa Unii Europejskiej wspólnie przyjęły 10. pakiet sankcji skierowanych przeciwko Rosji - przekazała szwedzka prezydencja. Jak dała w komunikacie, to "najpotężniejsze i najdalej idące do tej pory" środki, które "pomogą Ukrainie wygrać wojnę".

## Wyniki Eurojackpot z 24 lutego 2023. Jakie liczby padły podczas ostatniego losowania?
 - [https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia240223-czy-padla-glowna-wygrana-6776252?source=rss](https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia240223-czy-padla-glowna-wygrana-6776252?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 21:22:57+00:00

<img alt="Wyniki Eurojackpot z 24 lutego 2023. Jakie liczby padły podczas ostatniego losowania?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wn6i5w-eurojackpot-s-shutterstock743570785-4780960/alternates/LANDSCAPE_1280" />
    W piątkowym losowaniu Eurojackpot nie padła główna wygrana. W Polsce odnotowano wygrane czwartego stopnia. Oto wyniki Eurojackpot z 24 lutego 2023 roku.

## Współpraca przy produkcji czołgów i armatohaubic. Jest umowa z Koreańczykami
 - [https://tvn24.pl/biznes/z-kraju/polska-grupa-zbrojeniowa-podpisala-z-koreanskimi-producentami-uzbrojenia-umowy-o-wspolpracy-6776276?source=rss](https://tvn24.pl/biznes/z-kraju/polska-grupa-zbrojeniowa-podpisala-z-koreanskimi-producentami-uzbrojenia-umowy-o-wspolpracy-6776276?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 20:42:23+00:00

<img alt="Współpraca przy produkcji czołgów i armatohaubic. Jest umowa z Koreańczykami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6w8bui-morag-09122022-przekazanie-czolgow-k2-zolnierzom-wojska-polskiego-6776304/alternates/LANDSCAPE_1280" />
    Polska Grupa Zbrojeniowa podpisała z koreańskimi producentami uzbrojenia umowy o współpracy przy produkcji czołgów K2 i samobieżnych armatohaubic K9 - poinformowała PGZ w piątek.

## Tak wojna zmieniła Wołodymyra Zełenskiego
 - [https://tvn24.pl/swiat/wolodymyr-zelenski-zdjecia-prezydenta-ukrainy-tak-zmienila-go-wojna-6775817?source=rss](https://tvn24.pl/swiat/wolodymyr-zelenski-zdjecia-prezydenta-ukrainy-tak-zmienila-go-wojna-6775817?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 20:39:09+00:00

<img alt="Tak wojna zmieniła Wołodymyra Zełenskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-je9ec5-zelenski-sklej-16-6776273/alternates/LANDSCAPE_1280" />
    Od roku Rosjanie zabierają życie i sieją spustoszenie na skalę, jakiej w Europie nie doświadczano od II wojny światowej. Niszczą rodziny. Odbierają dzieciom niewinność. Rozpętana przez nich wojna zmienia świat i każdego człowieka, którego udziałem się staje. Wołodymyr Zełenski - jeszcze niedawno po prostu prezydent Ukrainy, a dziś lider walczącego z autorytaryzmem wolnego, demokratycznego świata - też się zmienił. Zestawione fotografie pokazują go rok temu, w kolejnych miesiącach bohaterskiej obrony Ukrainy i obecnie.

## Zderzenie samochodu osobowego z radiowozem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-samochodu-osobowego-z-radiowozem-przy-wale-miedzeszynskim-6776192?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-samochodu-osobowego-z-radiowozem-przy-wale-miedzeszynskim-6776192?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 19:30:51+00:00

<img alt="Zderzenie samochodu osobowego z radiowozem " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-uemvaz-zderzenie-samochodu-osobowego-i-radiowozu-6776204/alternates/LANDSCAPE_1280" />
    Na zjeździe z mostu Łazienkowskiego, w pobliżu Wału Miedzeszyńskiego, zderzyły się samochód osobowy i radiowóz policyjny. Nikomu nic się nie stało.

## Pogoda na jutro - sobota 25.02. W nocy popada deszcz i deszcz ze śniegiem, za dnia dołączy do nich śnieg
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sobota-2502-opady-sniegu-i-zawieje-w-czesci-polski-w-innych-regionach-deszcz-ze-sniegiem-i-deszcz-6776126?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sobota-2502-opady-sniegu-i-zawieje-w-czesci-polski-w-innych-regionach-deszcz-ze-sniegiem-i-deszcz-6776126?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 18:22:00+00:00

<img alt="Pogoda na jutro - sobota 25.02. W nocy popada deszcz i deszcz ze śniegiem, za dnia dołączy do nich śnieg" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9c4zkd-snieg-deszcz-ze-sniegiem-noc-6598774/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. Sobota 25.02 w całej Polsce przyniesie opady. Na przeważającym terenie kraju będzie to deszcz i deszcz ze śniegiem, a w części kraju lokalnie może spaść nawet 10 centymetrów śniegu. Wiatr w niektórych regionach powieje porywiście.

## Wypadek na budowie, poszkodowanego do szpitala zabrał helikopter LPR
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wieliszew-mezczyzna-spadl-podczas-prac-budowlanych-ladowal-helikopter-lpr-6776052?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wieliszew-mezczyzna-spadl-podczas-prac-budowlanych-ladowal-helikopter-lpr-6776052?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 17:55:50+00:00

<img alt="Wypadek na budowie, poszkodowanego do szpitala zabrał helikopter LPR" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bsqq5j-wypadek-przy-budowie-w-wieliszewie-6776089/alternates/LANDSCAPE_1280" />
    Mężczyzna spadł podczas prac prowadzonych na budowie koło Legionowa. Przyjechali strażacy, lądował też helikopter Lotniczego Pogotowia Ratunkowego, który przetransportował poszkodowanego do szpitala.

## Szeroki pakiet sankcji przeciwko Rosji. Jest decyzja USA
 - [https://tvn24.pl/biznes/ze-swiata/usa-nowy-pakiet-sankcji-dotykajacych-rosyjski-przemysl-wydobywczy-zbrojeniowy-jadrowy-i-kolejne-banki-6775973?source=rss](https://tvn24.pl/biznes/ze-swiata/usa-nowy-pakiet-sankcji-dotykajacych-rosyjski-przemysl-wydobywczy-zbrojeniowy-jadrowy-i-kolejne-banki-6775973?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 17:33:59+00:00

<img alt="Szeroki pakiet sankcji przeciwko Rosji. Jest decyzja USA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iey6wh-kreml-moskwa-6727745/alternates/LANDSCAPE_1280" />
    Administracja Joe Bidena ogłosiła w piątek szereg dodatkowych sankcji, dotykających rosyjski przemysł wydobywczy, zbrojeniowy, jądrowy, a także kolejne banki. Prezydent zdecydował też o radykalnym podniesieniu ceł między innymi na rosyjskie metale.

## Pogotowie przeciwpowodziowe w powiecie płockim
 - [https://tvn24.pl/tvnmeteo/polska/mazowieckie-wysoki-poziom-wisly-pogotowie-przeciwpowodziowe-w-powiecie-plockim-6775996?source=rss](https://tvn24.pl/tvnmeteo/polska/mazowieckie-wysoki-poziom-wisly-pogotowie-przeciwpowodziowe-w-powiecie-plockim-6775996?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 17:05:30+00:00

<img alt="Pogotowie przeciwpowodziowe w powiecie płockim" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-y2464w-wysoki-poziom-wody-ostrzezenia-hydrologiczne-4825135/alternates/LANDSCAPE_1280" />
    Na Wiśle w powiecie płockim w piątek zostały przekroczone stany ostrzegawcze. W związku z tym w miastach i gminach Wyszogród i Gąbin oraz gminach Mała Wieś, Bodzanów, Słupno, Słubice i Nowy Duninów wprowadzono pogotowie przeciwpowodziowe - poinformowało Starostwo Powiatowe w Płocku. Będzie ono obowiązywać do odwołania.

## "Czy przebyłbyś tysiące mil, żeby zobaczyć otyłego kota?" Gacek ze Szczecina przyciągnął uwagę świata
 - [https://tvn24.pl/ciekawostki/szczecin-swiatowe-media-pisza-o-kocie-gacku-6775715?source=rss](https://tvn24.pl/ciekawostki/szczecin-swiatowe-media-pisza-o-kocie-gacku-6775715?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 16:52:56+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ydiyjb-kot-ze-szczecina-6775990/alternates/LANDSCAPE_1280" />
    Kot Gacek, po tym jak otrzymał tysiące pozytywnych recenzji w Google, został okrzyknięty "największą atrakcją Szczecina". W ciągu ostatnich dni Gacek zyskał jednak prawdziwie światową sławę. Skąd to zainteresowanie?

## Podwyżki dla nauczycieli. O ile wzrosną wynagrodzenia?
 - [https://tvn24.pl/biznes/pieniadze/podwyzki-dla-nauczycieli-2023-kwoty-od-kiedy-wyzsze-pensje-6775988?source=rss](https://tvn24.pl/biznes/pieniadze/podwyzki-dla-nauczycieli-2023-kwoty-od-kiedy-wyzsze-pensje-6775988?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 16:47:33+00:00

<img alt="Podwyżki dla nauczycieli. O ile wzrosną wynagrodzenia?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-da7biz-nauczyciel-jest-oskarzony-o-naruszenie-nietykalnosci-cielesnej-uczennicy-3738350/alternates/LANDSCAPE_1280" />
    Minimalne wynagrodzenie zasadnicze nauczyciela z tytułem zawodowym magistra i przygotowaniem pedagogicznym w zależności od stopnia awansu zawodowego wzrasta o kwotę od 266 złotych brutto do 326 złotych brutto. W Dzienniku Ustaw opublikowano rozporządzenie dotyczące wynagrodzeń nauczycieli.

## 77-latek jechał autem po chodniku. Gdy przechodzień zwrócił mu uwagę, "przewiózł go na masce"
 - [https://tvn24.pl/pomorze/sopot-77-latek-jechal-autem-po-chodniku-gdy-przechodzien-zwrocil-mu-uwage-przewiozl-go-na-masce-6775904?source=rss](https://tvn24.pl/pomorze/sopot-77-latek-jechal-autem-po-chodniku-gdy-przechodzien-zwrocil-mu-uwage-przewiozl-go-na-masce-6775904?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 16:47:21+00:00

<img alt="77-latek jechał autem po chodniku. Gdy przechodzień zwrócił mu uwagę, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-41z783-nietrzezwa-matka-opiekowala-sie-6-letnim-synem-6758427/alternates/LANDSCAPE_1280" />
    77-latek przejechał samochodem po chodniku, a następnie przewiózł na masce mężczyznę, który zwrócił mu uwagę - informuje policja. Kierowca był trzeźwy. Dostał dwa mandaty i 16 punktów karnych.

## Wołodymyr Zełenski: państwa bałtyckie i Polska wspierają nas we wszystkim, o cokolwiek byśmy poprosili
 - [https://tvn24.pl/swiat/wolodymyr-zelenski-w-rocznice-wojny-panstwa-baltyckie-i-polska-wspieraja-nas-we-wszystkim-6775959?source=rss](https://tvn24.pl/swiat/wolodymyr-zelenski-w-rocznice-wojny-panstwa-baltyckie-i-polska-wspieraja-nas-we-wszystkim-6775959?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 16:33:29+00:00

<img alt="Wołodymyr Zełenski: państwa bałtyckie i Polska wspierają nas we wszystkim, o cokolwiek byśmy poprosili" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2mjbfw-24-1640-zelenski-konfa-0006-6775947/alternates/LANDSCAPE_1280" />
    Państwa bałtyckie i Polska wspierają nas we wszystkim, o cokolwiek byśmy poprosili - oświadczył w piątek prezydent Ukrainy Wołodymyr Zełenski. Ukraiński przywódca podkreślił podczas konferencji prasowej w dniu rocznicy pełnoskalowej inwazji Rosji, że chciałby, aby najeźdźca został zwyciężony jeszcze w tym roku.

## Właściciel odebrał Kubę ze schroniska
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-maly-kudlaty-piesek-odnalazl-sie-pomogli-straznicy-miejscy-6775901?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-maly-kudlaty-piesek-odnalazl-sie-pomogli-straznicy-miejscy-6775901?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 16:23:32+00:00

<img alt="Właściciel odebrał Kubę ze schroniska" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-7xu22f-kudlaty-piesek-znaleziony-przez-straz-miejska-wrocil-do-wlasciciela-6775922/alternates/LANDSCAPE_1280" />
    Małego pieska kilka dni temu znaleźli strażnicy miejscy. Poszukiwali wtedy też jego właściciela, ale bezskutecznie. Pies trafił do schroniska. Jeden ze strażników rozpowszechnił w sieci informację i udało się. Właściciel odebrał już Kubę.

## Nowy gazociąg w Polce. Jest zgoda na budowę
 - [https://tvn24.pl/biznes/z-kraju/gaz-system-ma-pozwolenie-na-budowe-gazociagu-raciborz-oswiecim-6775907?source=rss](https://tvn24.pl/biznes/z-kraju/gaz-system-ma-pozwolenie-na-budowe-gazociagu-raciborz-oswiecim-6775907?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 16:10:38+00:00

<img alt="Nowy gazociąg w Polce. Jest zgoda na budowę" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-pa41ve-gazociag-4229412/alternates/LANDSCAPE_1280" />
    Operator systemu przesyłowego gazu Gaz-System poinformował w piątek, że ma już komplet decyzji, pozwalających rozpocząć budowę gazociągu Racibórz-Oświęcim. Gazociąg umożliwi między innymi przyłączenie do sieci planowanego przez PGE 882 MW bloku gazowego w Rybniku.

## Pogoda na weekend. Uwaga na zawieje śnieżne!
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-zima-wroci-do-polski-snieg-zawieje-i-mroz-6775821?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-zima-wroci-do-polski-snieg-zawieje-i-mroz-6775821?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 15:43:10+00:00

<img alt="Pogoda na weekend. Uwaga na zawieje śnieżne!" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-1zeus1-snieg-6775846/alternates/LANDSCAPE_1280" />
    Pogoda w weekend przypomni nam o tym, że w kalendarzu wciąż jest zima. W niektórych częściach Polski pojawią się opady śniegu, którego może spaść naprawdę sporo. Silny wiatr lokalnie spowoduje zawieje. Po tym, jak opady odsuną się od naszego kraju, napłynie mroźne powietrze.

## Szczątki rakiet przywieźli wolontariusze, zrobił z nich instalację artystyczną. Stanęła przed ratuszem
 - [https://tvn24.pl/pomorze/olsztyn-instalacja-ze-szczatkow-rosyjskich-rakiet-stanela-przed-ratuszem-6775760?source=rss](https://tvn24.pl/pomorze/olsztyn-instalacja-ze-szczatkow-rosyjskich-rakiet-stanela-przed-ratuszem-6775760?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 15:42:10+00:00

<img alt="Szczątki rakiet przywieźli wolontariusze, zrobił z nich instalację artystyczną. Stanęła przed ratuszem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i0wnrw-olsztyn-24022023-odsloniecie-instalacji-artystycznej-autorstwa-prof-antoniego-grzybka-6775895/alternates/LANDSCAPE_1280" />
    Dokładnie w rok po rozpoczęciu inwazji Rosji na Ukrainę przed olsztyńskim ratuszem stanęła instalacja artystyczna zbudowana ze szczątków rakiet, które spadły w okolicach Charkowa. Do Polski przywieźli je wolontariusze z konwojów humanitarnych. Przed magistratem instalacja zostanie miesiąc, później trafi do osoby, która najhojniej wesprze zbiórkę na pomoc medyczną dla ofiar wojny.

## Pojemnik z promieniotwórczą substancją w szkole. Prokuratura wszczęła śledztwo
 - [https://tvn24.pl/tvnwarszawa/okolice/mlawa-pracownik-szkoly-znalazl-na-jej-terenie-pojemnik-z-promieniotworcza-substancja-sledztwo-prokuratury-6775871?source=rss](https://tvn24.pl/tvnwarszawa/okolice/mlawa-pracownik-szkoly-znalazl-na-jej-terenie-pojemnik-z-promieniotworcza-substancja-sledztwo-prokuratury-6775871?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 15:32:50+00:00

<img alt="Pojemnik z promieniotwórczą substancją w szkole. Prokuratura wszczęła śledztwo" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ela8af-na-miejscu-pracowala-straz-pozarna-zdjecie-ilustracyjne-6230251/alternates/LANDSCAPE_1280" />
    W sprawie odnalezienia pojemnika z cezem-137 w Zespole Szkół Nr 1 w Mławie tamtejsza Prokuratura Rejonowa wszczęła śledztwo. Dotyczy sprowadzenia zdarzenia, które zagraża życiu lub zdrowiu wielu osób. W ramach postępowania pojemnik z zawartością zostanie ponownie przebadany przez specjalistów.

## Wjechał do rowu, auto przewróciło się na bok. "Wyczuli od niego alkohol"
 - [https://tvn24.pl/bialystok/mokre-zdanow-zamosc-wjechal-do-rowu-auto-przewrocilo-sie-na-bok-byl-pijany-6775773?source=rss](https://tvn24.pl/bialystok/mokre-zdanow-zamosc-wjechal-do-rowu-auto-przewrocilo-sie-na-bok-byl-pijany-6775773?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 15:22:07+00:00

<img alt="Wjechał do rowu, auto przewróciło się na bok. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9migpc-kierowca-osobowki-wjechal-do-rowu-samochod-zatrzymal-sie-na-dachu-6775774/alternates/LANDSCAPE_1280" />
    Ponad półtora promila alkoholu miał w organizmie 62-latek, który między miejscowością Mokre a Żdanów (woj. lubelskie) wjechał osobówką do rowu. Tam jego auto przewróciło się na bok. Choć wypadek wyglądał groźnie, mężczyzna nie odniósł poważnych obrażeń. Ze swojego postępowania będzie tłumaczył się przed sądem.

## Musieli uciekać przed wojną, pomogli stworzyć kalendarz. "Rysunki, które nigdy nie powinny powstać"
 - [https://tvn24.pl/pomorze/koszalin-powstal-kalendarz-z-ilustracjami-dzieci-ktore-musialy-uciekac-przed-wojna-rysunki-ktore-nigdy-nie-powinny-powstac-6775703?source=rss](https://tvn24.pl/pomorze/koszalin-powstal-kalendarz-z-ilustracjami-dzieci-ktore-musialy-uciekac-przed-wojna-rysunki-ktore-nigdy-nie-powinny-powstac-6775703?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 14:52:13+00:00

<img alt="Musieli uciekać przed wojną, pomogli stworzyć kalendarz. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vw32wu-wyjatkowy-kalendarz-na-rocznice-rosyjskiej-inwazji-na-ukraine-6775700/alternates/LANDSCAPE_1280" />
    Od pierwszego dnia rosyjskiej inwazji w Ukrainie minął rok. Koszalińskie stowarzyszenie stworzyło kalendarz, który ma przypominać o tym, co dzieje się za naszą wschodnią granicą. Zilustrowali go najmłodsi, którzy schronienie znaleźli w Zachodniopomorskiem. Ich rysunki są wzruszającym obrazem wojny widzianej oczami dzieci. Cały dochód ze sprzedaży kalendarza przeznaczony zostanie na pomoc Ukrainie.

## Najpierw do kradzieży namówiła 89-letnią babcię, później na łowy poszła z matką. Kradły perfumy
 - [https://tvn24.pl/pomorze/szczytno-corka-matka-i-babcia-podejrzane-o-kradziez-perfum-6775531?source=rss](https://tvn24.pl/pomorze/szczytno-corka-matka-i-babcia-podejrzane-o-kradziez-perfum-6775531?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 14:40:21+00:00

<img alt="Najpierw do kradzieży namówiła 89-letnią babcię, później na łowy poszła z matką. Kradły perfumy " src="https://tvn24.pl/pomorze/cdn-zdjecie-tquvmi-trzypokoleniowa-rodzina-zostala-zatrzymana-przez-szczycienska-policje-6775535/alternates/LANDSCAPE_1280" />
    Trzy kobiety - w wieku od 34 do 89 lat - są podejrzane o kradzieże perfum, do których dochodziło w Szczytnie (woj. warmińsko-mazurskie). Jak informuje policja, 34-latka namówiła na kradzież swoją matkę i babcię. Teraz grozi im do pięciu lat więzienia.

## Spalony rosyjski czołg przed ambasadą w Berlinie. "Świadectwo porażki Rosjan"
 - [https://tvn24.pl/swiat/niemcy-spalony-rosyjski-czolg-przez-ambasada-rosji-w-berlinie-6775536?source=rss](https://tvn24.pl/swiat/niemcy-spalony-rosyjski-czolg-przez-ambasada-rosji-w-berlinie-6775536?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 14:08:27+00:00

<img alt="Spalony rosyjski czołg przed ambasadą w Berlinie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-iuhhth-zniszczony-rosyjski-czolg-przed-ambasada-rosji-w-berlinie-6775569/alternates/LANDSCAPE_1280" />
    Przed ambasadą Rosji w Berlinie w piątek pojawił się zniszczony w okolicach Kijowa rosyjski czołg. Akcja przeprowadzona w pierwszą rocznicę rozpoczęcia rosyjskiej inwazji na Ukrainę ma być wyrazem sprzeciwu niemieckich aktywistów wobec tej agresji. Spalone rosyjskie czołgi pojawiły się także w kilku innych europejskich stolicach.

## W Polsce krzywdzone jest co siódme dziecko. W tym miejscu znajdą wszystkich specjalistów
 - [https://tvn24.pl/katowice/sosnowiec-w-polsce-krzywdzone-jest-co-siodme-dziecko-w-tym-miejscu-znajda-wszystkich-specjalistow-6775451?source=rss](https://tvn24.pl/katowice/sosnowiec-w-polsce-krzywdzone-jest-co-siodme-dziecko-w-tym-miejscu-znajda-wszystkich-specjalistow-6775451?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 13:48:23+00:00

<img alt="W Polsce krzywdzone jest co siódme dziecko. W tym miejscu znajdą wszystkich specjalistów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pmbfjo-centrum-pomocy-dzieciom-w-sosnowcu-6775541/alternates/LANDSCAPE_1280" />
    W Sosnowcu otwarte zostało w piątek Centrum Pomocy Dzieciom, ósme w Polsce, pierwsze na południu kraju. Wyjątkowość tego miejsca polega na tym, że pod jednym dachem dzieci znajdą bezpłatną pomoc psychologiczną, terapeutyczną, prawną, medyczną. Nie będą stąd odsyłane, mogą być przesłuchane w przyjaznych warunkach i najpierw do tego przygotowane.

## Coraz więcej żubrów w Puszczy Białowieskiej. Doliczyli się aż 829 osobników
 - [https://tvn24.pl/bialystok/bialowieza-policzyli-zubry-w-puszczy-jest-ich-829-zubrow-to-o-50-wiecej-niz-w-rok-wczesniej-6774890?source=rss](https://tvn24.pl/bialystok/bialowieza-policzyli-zubry-w-puszczy-jest-ich-829-zubrow-to-o-50-wiecej-niz-w-rok-wczesniej-6774890?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 13:48:10+00:00

<img alt="Coraz więcej żubrów w Puszczy Białowieskiej. Doliczyli się aż 829 osobników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-439bbf-liczenie-bylo-prowadzona-na-przelomie-stycznia-i-lutego-6775260/alternates/LANDSCAPE_1280" />
    Pracownicy Białowieskiego Parku Narodowego, leśnicy, naukowcy i wolontariusze wybrali się jak co roku na przełomie stycznia i lutego w teren, by policzyć żubry bytujące po polskiej stronie puszczy. Po weryfikacji danych – przyjmuje się, że to stan na koniec 2022 roku – okazało się, że w leśnych ostępach bytuje 829 osobników, z czego 138 to cielęta. Porównując tę liczbę z danymi z 2021 i 2020 roku widać, że populacja się rozwija.

## Ruszyły konsultacje w sprawie uchwały krajobrazowej dla Warszawy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ruszyly-konsultacje-w-sprawie-uchwaly-krajobrazowej-6775546?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ruszyly-konsultacje-w-sprawie-uchwaly-krajobrazowej-6775546?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 13:28:22+00:00

<img alt="Ruszyły konsultacje w sprawie uchwały krajobrazowej dla Warszawy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qqq1ld-warszawa-a-uchwala-krajobrazowa-4648067/alternates/LANDSCAPE_1280" />
    Uchwała krajobrazowa dla Warszawy ma uporządkować przestrzeń miejską. 24 lutego rozpoczęły się konsultacje społeczne w sprawie projektu. Mieszkańcy mogą wypowiedzieć się na temat reklam, małej architektury czy ogrodzeń. Nie jest to pierwsze podejście do takiej uchwały. Pierwsza została przyjęta w 2020 roku, ale uchylił ją wojewoda.

## Vice News: Po zaostrzeniu prawa w USA rośnie podziemna sieć aborcyjna
 - [https://tvn24.pl/swiat/zakaz-aborcji-w-usa-rosnie-podziemna-siec-aborcyjna-vice-news-6775247?source=rss](https://tvn24.pl/swiat/zakaz-aborcji-w-usa-rosnie-podziemna-siec-aborcyjna-vice-news-6775247?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 13:05:13+00:00

<img alt="Vice News: Po zaostrzeniu prawa w USA rośnie podziemna sieć aborcyjna " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c9m57p-shutterstock2051271275-6775346/alternates/LANDSCAPE_1280" />
    Co najmniej 20 tysięcy tabletek poronnych zostało rozprowadzonych w Stanach Zjednoczonych w ciągu pół roku od zaostrzenia prawa aborcyjnego w USA - informuje portal Vice News. Jak ocenia, unieważnienie przez Sąd Najwyższy aborcji jako konstytucyjnego prawa doprowadziło do rozwoju antyaborcyjnego podziemia.

## Pomógł stanąć na nogi piekarni w Buczy. Teraz zachęca, by inwestować w Ukrainie
 - [https://tvn24.pl/poznan/poznan-piekarz-jacek-polewski-pomogl-stanac-na-nogi-piekarni-w-buczy-teraz-zacheca-by-inwestowac-w-ukrainie-6775270?source=rss](https://tvn24.pl/poznan/poznan-piekarz-jacek-polewski-pomogl-stanac-na-nogi-piekarni-w-buczy-teraz-zacheca-by-inwestowac-w-ukrainie-6775270?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 12:42:33+00:00

<img alt="Pomógł stanąć na nogi piekarni w Buczy. Teraz zachęca, by inwestować w Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z718dr-jacek-polewski-piekarz-z-poznania-w-rozmowie-z-reporterem-tvn24-6775466/alternates/LANDSCAPE_1280" />
    Jacek Polewski, piekarz z Poznania po rozpoczęciu rosyjskiej inwazji na Ukrainę pomógł mieszkańcom Buczy, był też w Kijowie i Charkowie. Dzięki niemu udało się odbudować i zmodernizować zniszczoną piekarnię. Teraz apeluje, by pomagać małym biznesom w Ukrainie. - Ukraina potrzebuje inwestycji, tego, że tam pojedziemy i zaczniemy coś robić, działać - podkreśla.

## Ile zapłacą kierowcy na stacjach? Małe szanse na dalsze obniżki
 - [https://tvn24.pl/biznes/moto/ceny-paliw-luty-2023-benzyna-olej-napedowy-autogaz-prognozy-e-petrol-i-bm-reflex-6775354?source=rss](https://tvn24.pl/biznes/moto/ceny-paliw-luty-2023-benzyna-olej-napedowy-autogaz-prognozy-e-petrol-i-bm-reflex-6775354?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 12:41:27+00:00

<img alt="Ile zapłacą kierowcy na stacjach? Małe szanse na dalsze obniżki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-38cx22-paliwo-stacja-benzynowa-tankowanie-6305586/alternates/LANDSCAPE_1280" />
    Olej napędowy w ciągu tygodnia potaniał średnio o 20 groszy na litrze - wynika z najnowszych danych Biura Maklerskiego Reflex. Zdaniem analityków w najbliższych dniach powtórzenie tego scenariusza wydaje się "mało prawdopodobne". "W najbliższych dniach obniżki cen paliw, a zwłaszcza oleju napędowego, o ile się jeszcze utrzymają, to będą o wiele mniejsze" - wskazali.

## Ponad 60 tysięcy złotych w biurze rzeczy znalezionych. 20 osób podało się za właścicieli
 - [https://tvn24.pl/katowice/katowice-42-9-tysiecy-zlotych-4-tysiace-euro-i-300-dolarow-w-biurze-rzeczy-znalezionych-20-osob-podalo-sie-za-wlascicieli-6774838?source=rss](https://tvn24.pl/katowice/katowice-42-9-tysiecy-zlotych-4-tysiace-euro-i-300-dolarow-w-biurze-rzeczy-znalezionych-20-osob-podalo-sie-za-wlascicieli-6774838?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 12:21:43+00:00

<img alt="Ponad 60 tysięcy złotych w biurze rzeczy znalezionych. 20 osób podało się za właścicieli" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qtmgyz-pieniadze-6555068/alternates/LANDSCAPE_1280" />
    Gotówka w trzech walutach została znaleziona ponad dwa lata temu i trafiła do biura rzeczy znalezionych Urzędu Miasta w Katowicach. Magistrat nie może rozstrzygnąć, do kogo należą pieniądze, ponieważ zgłosiło się po nie aż 20 osób. Dlatego zapadła decyzja, że sprawa zostanie oddana do sądu.

## Utrudnienia dla klientów kilku banków
 - [https://tvn24.pl/biznes/z-kraju/przerwy-w-bankach-ing-bank-slaski-bank-millennium-velo-bank-toyota-bank-credit-agricole-bnp-paribas-lista-6775068?source=rss](https://tvn24.pl/biznes/z-kraju/przerwy-w-bankach-ing-bank-slaski-bank-millennium-velo-bank-toyota-bank-credit-agricole-bnp-paribas-lista-6775068?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 12:16:10+00:00

<img alt="Utrudnienia dla klientów kilku banków" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-ft3jpg-w-tym-roku-wyniki-sprzedazy-podczas-promocji-z-okazji-black-friday-beda-zdecydowanie-slabsze-niz-w-roku-2019-4761841/alternates/LANDSCAPE_1280" />
    ING Bank Śląski, Bank Millennium, Velo Bank oraz Toyota Bank - to część banków, które zaplanowały prace serwisowe w najbliższych dniach. W związku z tym klienci muszą przygotować się na utrudnienia. Poniżej piszemy o szczegółach.

## W Wietnamie znaleziono prawie cztery tony zabitych kotów. Media: miały być wykorzystane w tradycyjnej medycynie
 - [https://tvn24.pl/swiat/wietn-zabite-koty-prawie-cztery-tony-media-mialy-byc-wykorzystane-w-tradycyjnej-medycynie-6774042?source=rss](https://tvn24.pl/swiat/wietn-zabite-koty-prawie-cztery-tony-media-mialy-byc-wykorzystane-w-tradycyjnej-medycynie-6774042?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 12:15:41+00:00

<img alt="W Wietnamie znaleziono prawie cztery tony zabitych kotów. Media: miały być wykorzystane w tradycyjnej medycynie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sdycfl-wietnam-6774050/alternates/LANDSCAPE_1280" />
    Śledczy w Wietnamie znaleźli w chłodni na południu kraju prawie cztery tony zabitych kotów, które miały być wykorzystane w tradycyjnej medycynie - poinformowała w środę amerykańska stacja Radio Wolna Azja. W stojącej nieopodal ciężarówce odkryto także 480 żywych zwierząt.

## Protest Greenpeace. Na moście Poniatowskiego zawisł ogromny baner
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-akcja-greenpeace-na-moscie-poniatowskiego-zawisl-baner-polska-nadal-kupuje-rope-z-rosji-6775188?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-akcja-greenpeace-na-moscie-poniatowskiego-zawisl-baner-polska-nadal-kupuje-rope-z-rosji-6775188?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 12:14:43+00:00

<img alt="Protest Greenpeace. Na moście Poniatowskiego zawisł ogromny baner " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-uiclea-akcja-aktywistow-z-greenpeace-polska-6775294/alternates/LANDSCAPE_1280" />
    W piątek aktywiści z Greenpeace Polska zawiesili na moście Poniatowskiego baner z hasłem "Polska nadal kupuje ropę z Rosji". Chcą zwrócić uwagę na to, że Polska wciąż jest uzależniona od rosyjskich surowców energetycznych.

## Lawina runęła na hotel we Włoszech, zginęło 29 osób. Zapadły wyroki
 - [https://tvn24.pl/swiat/wlochy-lawina-runela-na-hotel-w-abruzji-zginelo-29-osob-zapadly-wyroki-6774478?source=rss](https://tvn24.pl/swiat/wlochy-lawina-runela-na-hotel-w-abruzji-zginelo-29-osob-zapadly-wyroki-6774478?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 12:12:00+00:00

<img alt="Lawina runęła na hotel we Włoszech, zginęło 29 osób. Zapadły wyroki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z4hqtr-zawalony-hotel-w-abruzji-6774475/alternates/LANDSCAPE_1280" />
    We Włoszech zapadły wyroki w procesie związanym z katastrofą w górach w Abruzji, gdzie w 2017 roku na hotel runęła lawina, zabijając 29 osób. Skazanych zostało pięć osób. Wyroki uniewinniające dla pozostałych wywołały gwałtowny protest rodzin ofiar. Adwokaci zapowiedzieli apelację.

## Miał zaatakować kijem bejsbolowym i okraść przechodnia. Schował się przed policją w lodówce
 - [https://tvn24.pl/bialystok/lomza-schowal-sie-przed-policja-w-lodowce-zmiescil-sie-bo-byly-wyjete-polki-6774816?source=rss](https://tvn24.pl/bialystok/lomza-schowal-sie-przed-policja-w-lodowce-zmiescil-sie-bo-byly-wyjete-polki-6774816?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 11:56:46+00:00

<img alt="Miał zaatakować kijem bejsbolowym i okraść przechodnia. Schował się przed policją w lodówce " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mpz0a3-podejrzany-jest-o-zaatakowanie-kijem-bejsbolowym-32-latka-6774819/alternates/LANDSCAPE_1280" />
    Policja zatrzymała 27-latka, który miał na jednej z ulic w Łomży (woj. podlaskie) zaatakować kijem bejsbolowym 32-latka i zabrać mu telefon. Podejrzany przebywał w mieszkaniu swojej znajomej. Schował się w lodówce, z której wyjęte zostały półki.

## Nowa strategia Orlenu. Padła data jej ogłoszenia
 - [https://tvn24.pl/biznes/z-kraju/orlen-oglosi-nowa-strategie-we-wtorek-28-lutego-2023-zapowiedz-nowej-polityki-dywidendowej-6775137?source=rss](https://tvn24.pl/biznes/z-kraju/orlen-oglosi-nowa-strategie-we-wtorek-28-lutego-2023-zapowiedz-nowej-polityki-dywidendowej-6775137?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 11:53:02+00:00

<img alt="Nowa strategia Orlenu. Padła data jej ogłoszenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xwyp4g-shutterstock2152259391-6775314/alternates/LANDSCAPE_1280" />
    PKN Orlen przedstawi we wtorek 28 lutego nową strategię rozwoju - poinformował wiceprezes spółki Jan Szewczak. Dodał, że zostanie zaktualizowana polityka wypłaty dywidendy firmy, która wciąż ma mieć stabilny charakter. To w dniu, gdy spółka ogłosiła zysk za 2022 rok, który był trzy razy większy niż w 2021 roku.

## Prawdopodobnie zasłabł, wjechał na chodnik i przejście dla pieszych, uderzył w latarnię. Nie żyje
 - [https://tvn24.pl/krakow/jaroslaw-prawdopodobnie-zaslabl-wjechal-na-chodnik-i-przejscie-dla-pieszych-uderzyl-w-latarnie-61-latek-zmarl-w-szpitalu-6775127?source=rss](https://tvn24.pl/krakow/jaroslaw-prawdopodobnie-zaslabl-wjechal-na-chodnik-i-przejscie-dla-pieszych-uderzyl-w-latarnie-61-latek-zmarl-w-szpitalu-6775127?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 11:42:18+00:00

<img alt="Prawdopodobnie zasłabł, wjechał na chodnik i przejście dla pieszych, uderzył w latarnię. Nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g7lfpw-zycia-61-latka-ktory-kierowal-skoda-nie-udalo-sie-uratowac-6775228/alternates/LANDSCAPE_1280" />
    Policjanci pod nadzorem prokuratury wyjaśniają okoliczności zdarzenia, do którego doszło w Jarosławiu (woj. podkarpackie). Jak informują, 61-letni mężczyzna najprawdopodobniej zasłabł za kierownicą i uderzył w przydrożną latarnię. Nieprzytomny został przewieziony do szpitala, tam zmarł.

## Menadżerowie Orlenu z prezentacją dla ABW. Opowiadali o fuzji, sprzedaży rafinerii i stacji benzynowych
 - [https://tvn24.pl/polska/orlen-fuzja-z-lotosem-spotkanie-menedzerow-orlenu-z-funkcjonariuszami-abw-6774444?source=rss](https://tvn24.pl/polska/orlen-fuzja-z-lotosem-spotkanie-menedzerow-orlenu-z-funkcjonariuszami-abw-6774444?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 11:42:00+00:00

<img alt="Menadżerowie Orlenu z prezentacją dla ABW. Opowiadali o fuzji, sprzedaży rafinerii i stacji benzynowych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vi2bff-rafineria-gdanska-6510147/alternates/LANDSCAPE_1280" />
    Przedstawiciele koncernu Orlen pojawili się na spotkaniu z funkcjonariuszami Agencji Bezpieczeństwa Wewnętrznego, by opowiadać im o plusach fuzji z Lotosem, sprzedaży gdańskiej rafinerii saudyjskiemu kapitałowi, a stacji benzynowych kapitałowi węgierskiemu - dowiedział się tvn24.pl. - To jawny sygnał, że kierownictwo ABW nie życzy sobie żadnej pracy w tym kluczowym temacie dla bezpieczeństwa kraju - komentuje poseł Marek Biernacki, były minister koordynator służb.

## Nietrzeźwy mężczyzna jechał nierejestrowanym quadem. Wpadł, bo nie założył kasku
 - [https://tvn24.pl/polska/nisko-pijany-49-latek-jechal-niezarejestrowanym-quadem-6774892?source=rss](https://tvn24.pl/polska/nisko-pijany-49-latek-jechal-niezarejestrowanym-quadem-6774892?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 11:14:52+00:00

<img alt="Nietrzeźwy mężczyzna jechał nierejestrowanym quadem. Wpadł, bo nie założył kasku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b3txeb-mezczyzna-jechal-niezarejestrowanym-quadem-6774896/alternates/LANDSCAPE_1280" />
    Mieszkaniec Niska (woj. podkarpackie) został zatrzymany do kontroli przez policję. Mężczyzna jechał quadem bez tablic rejestracyjnych, nie miał też na głowie kasku. Badanie alkomatem wykazało z kolei promil alkoholu w jego organizmie.

## Nadzorowała "ludzkie komputery", na jej cześć właśnie nazwano górę na Księżycu
 - [https://tvn24.pl/tvnmeteo/nauka/nadzorowala-ludzkie-komputery-na-jej-czesc-wlasnie-nazwano-gore-na-ksiezycu-6775051?source=rss](https://tvn24.pl/tvnmeteo/nauka/nadzorowala-ludzkie-komputery-na-jej-czesc-wlasnie-nazwano-gore-na-ksiezycu-6775051?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 11:12:14+00:00

<img alt="Nadzorowała " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-wpszpo-melba-roy-mouton-6775186/alternates/LANDSCAPE_1280" />
    Międzynarodowa Unia Astronomiczna (IAU) wydała decyzję, by wysoka na sześć tysięcy metrów góra na Księżycu została nazwana nazwiskiem amerykańskiej matematyczki i programistki Melby Roy Mouton. Kobieta przez 14 lat pracowała dla NASA, uczestniczyła w pionierskich badaniach, a bez jej udziału dzisiejsza eksploracja kosmosu wyglądałaby zupełnie inaczej.

## Von der Leyen i Stoltenberg w Tallinie. "Putin nie osiągnął żadnego ze swoich strategicznych celów"
 - [https://tvn24.pl/swiat/rok-od-inwazji-rosji-na-ukraine-ursula-von-der-leyen-ukraina-zwyciezy-rowniez-dlatego-ze-nie-poddadza-sie-jej-sojusznicy-6775013?source=rss](https://tvn24.pl/swiat/rok-od-inwazji-rosji-na-ukraine-ursula-von-der-leyen-ukraina-zwyciezy-rowniez-dlatego-ze-nie-poddadza-sie-jej-sojusznicy-6775013?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 11:00:30+00:00

<img alt="Von der Leyen i Stoltenberg w Tallinie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kn2rvg-24-1125-reu-evc2746-ukraine-crisis-a-0002-6775144/alternates/LANDSCAPE_1280" />
    Unia Europejska jest zdeterminowana wspierać Ukrainę tak długo, jak będzie to potrzebne - powiedziała przewodnicząca Komisji Europejskiej Ursula von der Leyen, przemawiając w Tallinie z rocznicę rosyjskiej napaści na Ukrainę oraz z okazji Dnia Niepodległości Estonii. Sekretarz generalny NATO Jens Stoltenberg dodał, że Władimir Putin nie jest gotowy na pokój, dlatego należy dać Ukrainie to, czego potrzebuje.

## "365 dni bohaterstwa, 365 dni wsparcia". Manifestacja solidarności z walczącymi Ukraińcami
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-rocznica-rosyjskiej-agresji-na-ukraine-manifestacja-solidarnosci-6774986?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-rocznica-rosyjskiej-agresji-na-ukraine-manifestacja-solidarnosci-6774986?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 10:44:56+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ud3dk5-manifestacja-przed-ambasada-rosji-zdjecie-ilustracyjne-6775136/alternates/LANDSCAPE_1280" />
    W rocznicę rosyjskiej agresji na Ukrainę wieczorem sprzed rosyjskiej ambasady przy Belwederskiej pod gmach Sejmu przejdzie manifestacja w geście solidarności z walczącymi Ukraińcami. Należy spodziewać się utrudnień w ruchu.

## Kosmetyki wylądują w pudełkach po butach. Będą prezentami dla potrzebujących kobiet
 - [https://tvn24.pl/poznan/project-shoebox-kosmetyki-wyladuja-w-pudelkach-po-butach-beda-prezentami-dla-potrzebujacych-kobiet-trwa-zbiorka-6773603?source=rss](https://tvn24.pl/poznan/project-shoebox-kosmetyki-wyladuja-w-pudelkach-po-butach-beda-prezentami-dla-potrzebujacych-kobiet-trwa-zbiorka-6773603?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 10:44:55+00:00

<img alt="Kosmetyki wylądują w pudełkach po butach. Będą prezentami dla potrzebujących kobiet" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yxq9cz-do-kazdej-paczki-dolaczona-jest-karteczka-zyczeniami-5022354/alternates/LANDSCAPE_1280" />
    W kartony po butach pakują kosmetyki, które z okazji Dnia Kobiet trafiają do potrzebujących. A tych przybywa, choćby za sprawą uchodźczyń z Ukrainy. Z kolei tym, którzy im pomagali, w tym roku trudniej jest sięgnąć do portfela. - Widzimy, że ludzi dopadła inflacja - mówi Magdalena Owsiana, jedna z inicjatorek akcji.

## Tajemnicza kula usunięta z plaży w Japonii. Ekspert twierdzi, że wie, co to jest
 - [https://tvn24.pl/swiat/japonia-tajemnicza-kula-usunieta-z-plazy-ekspert-twierdzi-ze-wie-co-to-jest-6774888?source=rss](https://tvn24.pl/swiat/japonia-tajemnicza-kula-usunieta-z-plazy-ekspert-twierdzi-ze-wie-co-to-jest-6774888?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 10:27:34+00:00

<img alt="Tajemnicza kula usunięta z plaży w Japonii. Ekspert twierdzi, że wie, co to jest" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0dp79l-tajemnicza-kula-na-plazy-w-japonii-6772040/alternates/LANDSCAPE_1280" />
    Tajemnicza metalowa kula, którą znaleziono na wybrzeżu Japonii, została usunięta przez tamtejsze władze. Rząd w Tokio nadal nie potwierdził, czym był ten obiekt, ale najprawdopodobniej to boja wyrzucona przez morze na brzeg. - Jest bardzo łatwa do rozpoznania - twierdzi oceanograf, z którym rozmawiało BBC.

## Policja: przyjechał autem na włamanie. "Ma aktywny zakaz prowadzenia pojazdów"
 - [https://tvn24.pl/bialystok/gmina-terespol-zatrzymali-podejrzenego-o-wlamanie-przyjechal-autem-choc-ma-aktywny-zakaz-6774750?source=rss](https://tvn24.pl/bialystok/gmina-terespol-zatrzymali-podejrzenego-o-wlamanie-przyjechal-autem-choc-ma-aktywny-zakaz-6774750?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 10:24:39+00:00

<img alt="Policja: przyjechał autem na włamanie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-exyu90-mial-przy-sobie-woreczki-z-narkotykami-6774752/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali w gminie Terespol (woj. lubelskie) 32-latka podejrzanego o włamanie do pomieszczeń gospodarczych na terenie składu opału i kradzież elektronarzędzi oraz przewodów elektrycznych. Jak ustalili mundurowi, mężczyzna przyjechał tam autem, mimo że ma aktywny zakaz prowadzenia pojazdów.

## 62-latek jechał rowerem po zmroku, został potrącony. Zginął na miejscu
 - [https://tvn24.pl/pomorze/nowe-prusy-jechal-rowerem-zostal-potracony-zginal-na-miejscu-6774765?source=rss](https://tvn24.pl/pomorze/nowe-prusy-jechal-rowerem-zostal-potracony-zginal-na-miejscu-6774765?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 10:16:49+00:00

<img alt="62-latek jechał rowerem po zmroku, został potrącony. Zginął na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-90xg1f-w-wypadku-zginal-rowerzysta-6774679/alternates/LANDSCAPE_1280" />
    Tragiczny wypadek w miejscowości Nowe Prusy (woj. pomorskie). Kierowca samochodu osobowego potrącił rowerzystę. 62-letni mężczyzna zginął na miejscu. Policjanci pod nadzorem prokuratury wyjaśniają dokładne przyczyny i okoliczności tego zdarzenia.

## Brytyjski minister obrony: nie wyślemy myśliwców do Ukrainy w krótkim terminie
 - [https://tvn24.pl/najnowsze/samoloty-dla-ukrainy-brytyjski-minister-obrony-ben-wallace-nie-wyslemy-mysliwcow-w-krotkim-terminie-6775043?source=rss](https://tvn24.pl/najnowsze/samoloty-dla-ukrainy-brytyjski-minister-obrony-ben-wallace-nie-wyslemy-mysliwcow-w-krotkim-terminie-6775043?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 10:14:12+00:00

<img alt="Brytyjski minister obrony: nie wyślemy myśliwców do Ukrainy w krótkim terminie" src="https://tvn24.pl/najnowsze/cdn-zdjecied41d8cd98f00b204e9800998ecf8427e-f-35-w-eskorcie-mysliwcow-typhoon-brytyjskiego-raf-4161295/alternates/LANDSCAPE_1280" />
    Wielka Brytania nie wyśle w najbliższym czasie swoich myśliwców do Ukrainy - powiedział w rozmowie z dziennikarzami Sky News brytyjski minister obrony Ben Wallace. Dzień wcześniej szef kancelarii prezydenta Wołodymyra Zełenskiego Andrij Jermak wyraził nadzieję, że to właśnie Wielka Brytania jako pierwszy kraj Zachodu dostarczy Ukrainie samoloty.

## Pierwsze zwroty trafiły na konta podatników. "Nawet do 10 dni"
 - [https://tvn24.pl/biznes/pieniadze/pit-za-2022-rok-twoj-e-pit-sa-pierwsze-zwroty-podatkow-6774897?source=rss](https://tvn24.pl/biznes/pieniadze/pit-za-2022-rok-twoj-e-pit-sa-pierwsze-zwroty-podatkow-6774897?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 10:01:55+00:00

<img alt="Pierwsze zwroty trafiły na konta podatników. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dqjw19-shutterstock2105046560-6764841/alternates/LANDSCAPE_1280" />
    Za pomocą usługi Twój e-PIT złożono ponad 2 miliony formularzy - poinformowało w piątek Ministerstwo Finansów. Zdecydowana większość dotyczy deklaracji PIT-37. Resort przekazał, że na konta podatników trafiły już pierwsze zwroty podatku.

## Pędził autostradą ponad 220 km/h. Policji powiedział, że mu się śpieszyło. Nagranie
 - [https://tvn24.pl/pomorze/swiecie-pedzil-autostrada-ponad-200-kmh-policjantom-powiedzial-ze-mu-sie-spieszylo-6774637?source=rss](https://tvn24.pl/pomorze/swiecie-pedzil-autostrada-ponad-200-kmh-policjantom-powiedzial-ze-mu-sie-spieszylo-6774637?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 10:00:36+00:00

<img alt="Pędził autostradą ponad 220 km/h. Policji powiedział, że mu się śpieszyło. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n2auiw-kierowca-zostal-ukarany-mandatem-i-punktami-karnymi-6774629/alternates/LANDSCAPE_1280" />
    63-latek pędził autostradą A1 z prędkością 224 km/h. Namierzyli go policjanci ze Świecia (kujawsko-pomorskie). Kierowca został ukarany mandatem w wysokości 2500 złotych i piętnastoma punktami karnymi.

## Pędził autostradą ponad 220 km/h. Policji powiedział, że mu się śpieszyło. Nagranie
 - [https://tvn24.pl/pomorze/swiecie-pedzil-autostrada-ponad-220-kmh-policjantom-powiedzial-ze-mu-sie-spieszylo-nagranie-6774637?source=rss](https://tvn24.pl/pomorze/swiecie-pedzil-autostrada-ponad-220-kmh-policjantom-powiedzial-ze-mu-sie-spieszylo-nagranie-6774637?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 10:00:36+00:00

<img alt="Pędził autostradą ponad 220 km/h. Policji powiedział, że mu się śpieszyło. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n2auiw-kierowca-zostal-ukarany-mandatem-i-punktami-karnymi-6774629/alternates/LANDSCAPE_1280" />
    63-latek pędził autostradą A1 z prędkością 224 km/h. Namierzyli go policjanci ze Świecia (kujawsko-pomorskie). Kierowca został ukarany mandatem w wysokości 2500 złotych i piętnastoma punktami karnymi.

## Zapłacą ponad 700 zł każdemu turyście, który ich odwiedzi w tym roku
 - [https://tvn24.pl/ciekawostki/tajwan-zaplaci-ponad-700-zl-kazdemu-turyscie-ktory-odwiedzi-wyspe-w-tym-roku-6774725?source=rss](https://tvn24.pl/ciekawostki/tajwan-zaplaci-ponad-700-zl-kazdemu-turyscie-ktory-odwiedzi-wyspe-w-tym-roku-6774725?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 09:54:50+00:00

<img alt="Zapłacą ponad 700 zł każdemu turyście, który ich odwiedzi w tym roku" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie76620dc63a0a2482153863d6c4e15fb6-turysci-znajda-sie-pod-wieksza-ochrona-4606824/alternates/LANDSCAPE_1280" />
    Tajwan ogłosił, że zapłaci każdemu turyście, który pojawi się na wyspie, 165 dolarów, czyli około 735 zł. Kraj chce w ten sposób przyciągnąć odwiedzających i wzmocnić swoją gospodarkę. Na dofinansowanie wypoczynku mogą liczyć też grupy wycieczkowe.

## Zasłabł za kierownicą na autostradzie i uderzył w bariery. 52-latek nie żyje
 - [https://tvn24.pl/lodz/autostrada-a1-radomsko-zaslabl-za-kierownica-i-uderzyl-w-bariery-52-latek-nie-zyje-6774882?source=rss](https://tvn24.pl/lodz/autostrada-a1-radomsko-zaslabl-za-kierownica-i-uderzyl-w-bariery-52-latek-nie-zyje-6774882?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 09:53:17+00:00

<img alt="Zasłabł za kierownicą na autostradzie i uderzył w bariery. 52-latek nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ams3fv-smiertelny-wypadek-na-autostradzie-a1-pod-radomskiem-6774847/alternates/LANDSCAPE_1280" />
    52-letni mężczyzna zginął w wypadku na autostradzie A1 pod Radomskiem (woj. łódzkie). Jak informują służby, kierowca zasłabł za kierownicą, a następnie uderzył w bariery energochłonne rozdzielające pas jezdni. Okoliczności zdarzenia wyjaśnia policja pod nadzorem prokuratury.

## Setki tysięcy ludzi na ulicach, w pałacu Jeff Bezos. Macron krytykowany
 - [https://tvn24.pl/biznes/ze-swiata/francja-prezydent-emmanuel-macron-za-moment-wreczenia-orderu-narodowego-legii-honorowej-zalozycielowi-amazona-jeffowi-bezosowi-6774814?source=rss](https://tvn24.pl/biznes/ze-swiata/francja-prezydent-emmanuel-macron-za-moment-wreczenia-orderu-narodowego-legii-honorowej-zalozycielowi-amazona-jeffowi-bezosowi-6774814?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 09:48:55+00:00

<img alt="Setki tysięcy ludzi na ulicach, w pałacu Jeff Bezos. Macron krytykowany" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-h1apt9-emmanuel-macron-6774881/alternates/LANDSCAPE_1280" />
    Prezydent Emmanuel Macron krytykowany we Francji. Powodem jest ceremonia wręczenia orderu Narodowego Legii Honorowej założycielowi Amazona Jeffowi Bezosowi, w momencie kiedy setki tysięcy obywateli protestowało przeciwko reformie emerytalnej. Macron został nazwany "prezydentem bogaczy".

## Rozbito kobiecy gang, ale przemyt trwał. Centrum "dowodzenia" odkryto w więzieniach
 - [https://tvn24.pl/swiat/usa-rozbito-kobiecy-gang-las-senoritas-przemyt-byl-kierowany-z-wiezien-6774756?source=rss](https://tvn24.pl/swiat/usa-rozbito-kobiecy-gang-las-senoritas-przemyt-byl-kierowany-z-wiezien-6774756?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 09:36:58+00:00

<img alt="Rozbito kobiecy gang, ale przemyt trwał. Centrum " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7zaikw-pani-meksyk-6774852/alternates/LANDSCAPE_1280" />
    W stolicy Meksyku zatrzymana została jedna z Las Senoritas, członkini kobiecego gangu przemycającego narkotyki do USA - przekazała lokalna prokuratura. Choć niemal wszyscy członkowie tej grupy zostali aresztowani, to odkryto, że przemyt trwał nadal, bo był koordynowany z więzień.

## Policjanci szukają mężczyzny ze zdjęć. "Wypożyczał sprzęt elektroniczny, ale nigdy go nie zwrócił"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-policjanci-szukaja-mezczyzny-ze-zdjec-wypozyczal-sprzet-elektroniczny-ale-nigdy-go-nie-zwrocil-6774795?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-policjanci-szukaja-mezczyzny-ze-zdjec-wypozyczal-sprzet-elektroniczny-ale-nigdy-go-nie-zwrocil-6774795?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 09:23:44+00:00

<img alt="Policjanci szukają mężczyzny ze zdjęć. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-adfrr0-policja-szuka-mezczyzny-ze-zdjec-6774898/alternates/LANDSCAPE_1280" />
    Komenda policji w Śródmieściu prowadzi postępowanie dotyczące oszustwa na kwotę ponad 27 tysięcy złotych. Policjanci publikują wizerunek mężczyzny podejrzanego o dokonanie tego przestępstwa. Proszą też o pomoc w ustaleniu miejsca jego pobytu.

## Blisko 147 tysięcy żołnierzy, tysiące czołgów i pojazdów opancerzonych. Ukraińcy o rosyjskich stratach
 - [https://tvn24.pl/swiat/rocznica-inwazji-zbrojnej-rosji-na-ukraine-ukrainski-sztab-generalny-podaje-straty-rosyjskiej-armii-6774693?source=rss](https://tvn24.pl/swiat/rocznica-inwazji-zbrojnej-rosji-na-ukraine-ukrainski-sztab-generalny-podaje-straty-rosyjskiej-armii-6774693?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 09:14:57+00:00

<img alt="Blisko 147 tysięcy żołnierzy, tysiące czołgów i pojazdów opancerzonych. Ukraińcy o rosyjskich stratach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ei2z2-zniszczony-rosyjski-czolg-6592194/alternates/LANDSCAPE_1280" />
    Dokładnie rok temu Rosja dokonała inwazji zbrojnej na Ukrainę. W najnowszym sprawozdaniu sztab generalny ukraińskich sił zbrojnych podał dane dotyczące strat rosyjskiej armii od początku agresji.

## Rok od inwazji Rosji na Ukrainę. Wołodymyr Zełenski do żołnierzy: od was zależy, czy przetrwa Ukraina
 - [https://tvn24.pl/swiat/rok-od-inwazji-rosji-na-ukraine-wolodymyr-zelenski-do-zolnierzy-od-was-zalezy-czy-przetrwa-ukraina-6774824?source=rss](https://tvn24.pl/swiat/rok-od-inwazji-rosji-na-ukraine-wolodymyr-zelenski-do-zolnierzy-od-was-zalezy-czy-przetrwa-ukraina-6774824?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 08:55:00+00:00

<img alt="Rok od inwazji Rosji na Ukrainę. Wołodymyr Zełenski do żołnierzy: od was zależy, czy przetrwa Ukraina" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wjt3fc-zelenski-6774821/alternates/LANDSCAPE_1280" />
    To od was zależy, czy wszyscy będziemy istnieć, czy istnieć będzie Ukraina - powiedział prezydent Wołodymyr Zełenski, zwracając się do żołnierzy ukraińskich sił zbrojnych. W centrum Kijowa zorganizowano uroczystość w rocznicę rozpoczęcia rosyjskiej inwazji na Ukrainę.

## Kontrabanda warta ponad 6 mln zł. Zamiast płyt wiórowych w ciężarówce były papierosy
 - [https://tvn24.pl/bialystok/budzisko-udaremnili-kontrabande-warta-ponad-6-mln-zl-to-najwiekszy-w-tym-roku-przemyt-papierosow-6774683?source=rss](https://tvn24.pl/bialystok/budzisko-udaremnili-kontrabande-warta-ponad-6-mln-zl-to-najwiekszy-w-tym-roku-przemyt-papierosow-6774683?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 08:46:25+00:00

<img alt="Kontrabanda warta ponad 6 mln zł. Zamiast płyt wiórowych w ciężarówce były papierosy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-crsg2g-w-naczepie-byly-bialoruskie-papierosy-6774684/alternates/LANDSCAPE_1280" />
    Funkcjonariusze Krajowej Administracji Skarbowej udaremnili niedaleko Budziska (woj. podlaskie) przemyt 420 tysięcy paczek papierosów. Kontrabanda o szacunkowej wartości rynkowej przekraczającej 6 mln zł jechała w litewskiej ciężarówce zamiast deklarowanego ładunku płyt wiórowych. Kierowca trafił do aresztu.

## "Wieczne chemikalia" gromadzą się w naszych tkankach. "Zaczynamy rozumieć, jaki wpływ wywierają na zdrowie"
 - [https://tvn24.pl/tvnmeteo/nauka/wieczne-chemikalia-pfas-gromadza-sie-w-naszych-tkankach-jaki-wplyw-wywieraja-na-zdrowie-6774794?source=rss](https://tvn24.pl/tvnmeteo/nauka/wieczne-chemikalia-pfas-gromadza-sie-w-naszych-tkankach-jaki-wplyw-wywieraja-na-zdrowie-6774794?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 08:43:02+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-4dops7-pfas-znajduja-sie-na-przyklad-w-wodoodpornej-odziezy-czy-opakowaniach-na-zywnosc-6774827/alternates/LANDSCAPE_1280" />
    PFAS to syntetyczne związki chemiczne o szerokim zastosowaniu. Znajdują się na przykład w wodoodpornej odzieży czy opakowaniach na żywność. Substancje te nazywane są "wiecznymi chemikaliami", ponieważ rozkładają się bardzo powoli i gromadzą w środowisku oraz tkankach ludzkich. Jak podają najnowsze badania, konsekwencją narażenia na ich kombinację może być szereg różnych chorób - od zaburzeń rozwojowych aż po nowotwory. Najgroźniejsze są dla dzieci i młodzieży.

## Trefny olej napędowy sprzedawali po zaniżonych stawkach. Służby rozbiły gang paliwowy
 - [https://tvn24.pl/pomorze/pomorskie-trefny-olej-napedowy-sprzedawali-po-zanizonych-stawkach-sluzby-rozbily-gang-paliwowy-6774813?source=rss](https://tvn24.pl/pomorze/pomorskie-trefny-olej-napedowy-sprzedawali-po-zanizonych-stawkach-sluzby-rozbily-gang-paliwowy-6774813?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 08:41:27+00:00

<img alt="Trefny olej napędowy sprzedawali po zaniżonych stawkach. Służby rozbiły gang paliwowy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-45erwb-policjanci-zatrzymali-osmiu-podejrzanych-o-udzial-w-zorganizowanej-grupie-przestepczej-6774812/alternates/LANDSCAPE_1280" />
    Osiem osób z województwa pomorskiego zostało zatrzymanych przez funkcjonariuszy Krajowej Administracji Skarbowej i Centralnego Biura Śledczego Policji. Są podejrzewani o udział w zorganizowanej grupie przestępczej, która działała w obrocie paliwami.

## Ekologiczni aktywiści pozwali francuski bank. Działa też w Polce
 - [https://tvn24.pl/biznes/ze-swiata/francja-bnp-paribas-zostalo-pozwane-przez-klimatycznych-aktywistow-6774782?source=rss](https://tvn24.pl/biznes/ze-swiata/francja-bnp-paribas-zostalo-pozwane-przez-klimatycznych-aktywistow-6774782?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 08:33:37+00:00

<img alt="Ekologiczni aktywiści pozwali francuski bank. Działa też w Polce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-28frmw-shutterstock1903590994-6622991/alternates/LANDSCAPE_1280" />
    Aktywiści klimatyczni pozwali BNP Paribas, jeden z największych europejskich banków. Twierdzą, że pożyczki udzielane dużym koncernom gazowym i naftowym naruszają francuskie przepisy, a dokładniej obowiązek zapewnienia, że jego działalność nie szkodzi środowisku.

## Rok od rosyjskiego ataku na Ukrainę. Zełenski w orędziu: to był najtrudniejszy dzień naszej historii
 - [https://tvn24.pl/swiat/rosja-ukraina-rok-od-rozpoczecia-rosyjskiej-inwazji-zelenski-w-oredziu-najtrudniejszy-dzien-naszej-historii-6774760?source=rss](https://tvn24.pl/swiat/rosja-ukraina-rok-od-rozpoczecia-rosyjskiej-inwazji-zelenski-w-oredziu-najtrudniejszy-dzien-naszej-historii-6774760?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 07:46:48+00:00

<img alt="Rok od rosyjskiego ataku na Ukrainę. Zełenski w orędziu: to był najtrudniejszy dzień naszej historii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ppsm58-zelenski-6774748/alternates/LANDSCAPE_1280" />
    24 lutego 2022 roku to najtrudniejszy dzień naszej historii współczesnej, tego dnia obudziliśmy się rankiem i od tej pory nie zasypiamy - oświadczył prezydent Wołodymyr Zełenski w wystąpieniu wideo opublikowanym na oficjalnej stronie internetowej w piątek, w rocznicę inwazji rosyjskiej.

## Wsparcie dla firm energochłonnych. Fundusz podsumowuje wnioski o pomoc
 - [https://tvn24.pl/biznes/najnowsze/wsparcie-dla-firm-energochlonnych-w-polsce-ile-firm-zlozylo-wnioski-6774611?source=rss](https://tvn24.pl/biznes/najnowsze/wsparcie-dla-firm-energochlonnych-w-polsce-ile-firm-zlozylo-wnioski-6774611?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 07:45:39+00:00

<img alt="Wsparcie dla firm energochłonnych. Fundusz podsumowuje wnioski o pomoc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lpf16n-ceny-gazu-ida-w-gore-5553182/alternates/LANDSCAPE_1280" />
    Firmy energochłonne złożyły wnioski na ponad 3,8 miliardów złotych finansowego wsparcia - dowiedziała się PAP w Narodowym Funduszu Ochrony Środowiska i Gospodarki Wodnej. Najwięcej, bo 151 wniosków złożyły duże firmy. Przedsiębiorstwa wnioskowały głównie o pomoc w wysokości do 4 milionów euro.

## Na wielkim obszarze USA pogoda się załamała, śnieg nawet na wzgórzach Hollywood
 - [https://tvn24.pl/tvnmeteo/swiat/na-wielkim-obszarze-usa-pogoda-sie-zalamala-snieg-nawet-na-wzgorzach-hollywood-6774687?source=rss](https://tvn24.pl/tvnmeteo/swiat/na-wielkim-obszarze-usa-pogoda-sie-zalamala-snieg-nawet-na-wzgorzach-hollywood-6774687?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 07:32:56+00:00

<img alt="Na wielkim obszarze USA pogoda się załamała, śnieg nawet na wzgórzach Hollywood" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ira2vf-sniezyce-w-usa-6774616/alternates/LANDSCAPE_1280" />
    Bardzo silna burza śnieżna opanowała w czwartek ogromną część USA. W wyniku załamania pogody zginęła co najmniej jedna osoba, ponad 900 tysięcy mieszkańców zostało pozbawionych prądu, a na drogach zapanował paraliż komunikacyjny.

## Tragiczny pożar drewnianej przybudówki. Znaleziono zwłoki mężczyzny
 - [https://tvn24.pl/lodz/lodz-pozar-drewnianej-przybudowki-nie-zyje-mezczyzna-6774720?source=rss](https://tvn24.pl/lodz/lodz-pozar-drewnianej-przybudowki-nie-zyje-mezczyzna-6774720?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 07:28:26+00:00

<img alt="Tragiczny pożar drewnianej przybudówki. Znaleziono zwłoki mężczyzny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-udbulb-pozar-na-lodzkich-balutach-nie-zyje-mezczyzna-6774691/alternates/LANDSCAPE_1280" />
    Tragiczny pożar w Łodzi. W jednej z przybudówek przy ulicy Widok strażacy znaleźli ciało mężczyzny. Na razie nie ustalono tożsamości ofiary. Wstępną przyczyną było zaprószenie ognia. Okoliczności zdarzenia wyjaśnia policja pod nadzorem prokuratury.

## Koncert "Solidarni z Ukrainą". Prezydent Zełenski: polski honor zawsze będzie wśród podstawowych źródeł siły dla całej Europy
 - [https://tvn24.pl/polska/warszawa-koncert-solidarni-z-ukraina-prezydent-zelenski-napisal-list-do-polakow-6774450?source=rss](https://tvn24.pl/polska/warszawa-koncert-solidarni-z-ukraina-prezydent-zelenski-napisal-list-do-polakow-6774450?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 07:20:00+00:00

<img alt="Koncert " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8kkebh-koncert-solidarni-z-ukraina-6774452/alternates/LANDSCAPE_1280" />
    W przededniu rosyjskiej napaści na Ukrainę w Warszawie odbył się koncert "Solidarni z Ukrainą". W liście do uczestników wydarzenia prezydent Ukrainy Wołodymyr Zełenski napisał, że "polski honor zawsze będzie wśród podstawowych źródeł siły dla całej Europy". "Wspólnie musimy skierować całość tej siły na pokonanie rosyjskiej tyranii. I niech tak się stanie, razem zwyciężymy" - dodał. Minister kultury Piotr Gliński zaznaczył, że Ukraińcy "nie zgodzili się na zło". - Wolna wspólnota, wolni obywatele byli gotowi poświęcić swoje życie, żeby obronić wartości podstawowe - powiedział.

## Rezolucja Zgromadzenia Ogólnego ONZ w sprawie przywrócenia pokoju w Ukrainie. Zełenski komentuje
 - [https://tvn24.pl/swiat/ukraina-rezolucja-zgromadzenia-ogolnego-onz-w-sprawie-przywrocenia-pokoju-zelenski-komentuje-6774458?source=rss](https://tvn24.pl/swiat/ukraina-rezolucja-zgromadzenia-ogolnego-onz-w-sprawie-przywrocenia-pokoju-zelenski-komentuje-6774458?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 07:10:37+00:00

<img alt="Rezolucja Zgromadzenia Ogólnego ONZ w sprawie przywrócenia pokoju w Ukrainie. Zełenski komentuje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-91i8h2-rezolucja-zgromadzenia-ogolnego-onz-6774459/alternates/LANDSCAPE_1280" />
    Zgromadzenie Ogólne ONZ uchwaliło w czwartek niewiążącą rezolucję mającą na celu przywrócenie pokoju w Ukrainie. "To mocne świadectwo solidarności społeczności międzynarodowej z narodem ukraińskim w kontekście rocznicy agresji Federacji Rosyjskiej na pełną skalę" - napisał prezydent Wołodymyr Zełenski, odnosząc się do decyzji Organizacji Narodów Zjednoczonych.

## Szef ukraińskiej dyplomacji: nie mamy dowodów, że Chiny dostarczyły broń Rosji
 - [https://tvn24.pl/swiat/ukraina-szef-msz-dmytro-kuleba-o-doniesieniach-ze-chiny-dostarczyly-bron-rosji-6774508?source=rss](https://tvn24.pl/swiat/ukraina-szef-msz-dmytro-kuleba-o-doniesieniach-ze-chiny-dostarczyly-bron-rosji-6774508?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 07:08:02+00:00

<img alt="Szef ukraińskiej dyplomacji: nie mamy dowodów, że Chiny dostarczyły broń Rosji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-msdf6m-szef-ukrainskiego-msz-dmytro-kuleba-w-onz-6774697/alternates/LANDSCAPE_1280" />
    Szef ukraińskiej dyplomacji Dmytro Kułeba przekazał w czwartek, że Kijów nie ma dowodów na to, że Chiny dostarczały Rosji broń. - Myślę, że byłoby wielkim błędem, gdyby jakikolwiek kraj dostarczał Rosji broń, ponieważ oznaczałoby to promowanie agresji i rażące naruszenie Karty Narodów Zjednoczonych - dodał minister.

## Korea Północna przeprowadziła ćwiczenia z przygotowania ataku pociskami manewrującymi
 - [https://tvn24.pl/swiat/korea-polnocna-wystrzelila-kolejna-rakiete-cwiczenia-z-przygotowania-ataku-pociskami-manewrujacymi-6774527?source=rss](https://tvn24.pl/swiat/korea-polnocna-wystrzelila-kolejna-rakiete-cwiczenia-z-przygotowania-ataku-pociskami-manewrujacymi-6774527?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 07:00:21+00:00

<img alt="Korea Północna przeprowadziła ćwiczenia z przygotowania ataku pociskami manewrującymi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ec4cxd-proba-rakietowa-korei-polnocnej-6774528/alternates/LANDSCAPE_1280" />
    Korea Północna przeprowadziła w czwartek ćwiczenia rakietowe, w ramach których wystrzeliła próbnie cztery strategiczne pociski manewrujące. Miało to zademonstrować jej zdolność do przeprowadzenia kontrataku nuklearnego przeciwko wrogim siłom - poinformowała w piątek północnokoreańska oficjalna agencja KCNA, cytowana przez agencję Reutera.

## Ukraiński wolontariusz Iwan Bogdan: stałem nad łóżkiem i płakałem, bo nie wiedziałem, co robić
 - [https://tvn24.pl/swiat/rosja-ukraina-pierwsza-rocznica-rosyjskiej-inwazji-iwan-bogdan-wolontariusz-z-kijowa-opowiada-6774619?source=rss](https://tvn24.pl/swiat/rosja-ukraina-pierwsza-rocznica-rosyjskiej-inwazji-iwan-bogdan-wolontariusz-z-kijowa-opowiada-6774619?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 06:48:22+00:00

<img alt="Ukraiński wolontariusz Iwan Bogdan: stałem nad łóżkiem i płakałem, bo nie wiedziałem, co robić" src="https://tvn24.pl/najnowsze/cdn-zdjecie-caxdmn-wolontariusz-6774540/alternates/LANDSCAPE_1280" />
    Gdy blisko rok temu rozmawialiśmy z Iwanem Bogdanem, ukraińskim wolontariuszem z Kijowa, rosyjska inwazja na Ukrainę była jeszcze w początkowej fazie. W zamyśle Moskwy miała to być wojna błyskawiczna. Nikt na Kremlu nie spodziewał się, że 12 miesięcy później Ukraina dalej będzie się bronić. To w dużej mierze zasługa takich ludzi, jak pan Iwan, zwykłych Ukraińców, którzy pozostali w kraju, by wspierać ukraińskie wojsko w walce z najeźdźcą.

## Policyjny pościg za kierowcą auta dostawczego. "Nie zatrzymał się do kontroli"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/pruszkow-policyjny-poscig-za-kierowca-auta-dostawczego-6774608?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/pruszkow-policyjny-poscig-za-kierowca-auta-dostawczego-6774608?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 06:14:05+00:00

<img alt="Policyjny pościg za kierowcą auta dostawczego. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-lyj2th-policyjny-poscig-zakonczyl-sie-kolizja-6774571/alternates/LANDSCAPE_1280" />
    W czwartek wieczorem na ulicach Pruszkowa policja ścigała kierowcę auta dostawczego, który nie zatrzymał się do kontroli. W wyniku akcji policjantów uszkodzony został radiowóz.

## Lód skuje drogi w dużej części kraju. Lokalnie śniegu ma spaść tyle, że IMGW rozważa ogłoszenie alertów
 - [https://tvn24.pl/tvnmeteo/pogoda/mozliwe-alerty-imgw-niebezpieczna-pogoda-w-czesci-kraju-pogoda-na-piatek-i-weekend-6774529?source=rss](https://tvn24.pl/tvnmeteo/pogoda/mozliwe-alerty-imgw-niebezpieczna-pogoda-w-czesci-kraju-pogoda-na-piatek-i-weekend-6774529?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 05:24:55+00:00

<img alt="Lód skuje drogi w dużej części kraju. Lokalnie śniegu ma spaść tyle, że IMGW rozważa ogłoszenie alertów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-91rr16-intensywne-opady-sniegu-6442008/alternates/LANDSCAPE_1280" />
    Synoptycy IMGW wydali prognozę zagrożeń na piątek i kolejne dni. W komunikatach podają, że wystąpić mogą intensywne opady śniegu, silne porywy wiatru, a także oblodzenie. Sprawdź, gdzie mogą pojawić się ostrzeżenia.

## Pogoda na dziś - piątek 24.02. Deszcz, deszcz ze śniegiem i porywisty wiatr
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-2402-deszcz-deszcz-ze-sniegiem-i-porywisty-wiatr-6773897?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-2402-deszcz-deszcz-ze-sniegiem-i-porywisty-wiatr-6773897?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-24 01:00:00+00:00

<img alt="Pogoda na dziś - piątek 24.02. Deszcz, deszcz ze śniegiem i porywisty wiatr" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-wjw5ow-snieg-z-deszczem-6774206/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Piątek 24.07 upłynie pod znakiem opadów w całej Polsce. W większości kraju będzie to deszcz, a w godzinach popołudniowych w niektórych regionach pojawi się również deszcz ze śniegiem. Chwilami wiatr mocno się rozpędzi.

