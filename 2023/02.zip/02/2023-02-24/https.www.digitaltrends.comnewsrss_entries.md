# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## AMD might finally beat Intel for the fastest mobile gaming CPU
 - [https://www.digitaltrends.com/computing/amd-ryzen-7945hx-benchmarked/](https://www.digitaltrends.com/computing/amd-ryzen-7945hx-benchmarked/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2023-02-24 05:51:35.715129+00:00

AMD Dragon Range is coming to gaming laptops, and the first benchmarks of the Ryzen 9 7945HX bode well for Team Red.

