# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Uporczywa inflacja trapi inwestorów z Wall Street
 - [https://www.bankier.pl/wiadomosc/Uporczywa-inflacja-trapi-inwestorow-z-Wall-Street-8495754.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Uporczywa-inflacja-trapi-inwestorow-z-Wall-Street-8495754.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/8bb557ce76f19c-908-545-60-17-908-545.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inwestorów zaniepokoiły statystyki inflacyjne, które mogą doprowadzić
do serii kolejnych podwyżek stóp procentowych w Rezerwie Federalnej.</p>

## Wiatraki podzielą los ustawy o SN? Prezydencki minister zabrał głos
 - [https://www.bankier.pl/wiadomosc/Wiatraki-podziela-los-ustawy-o-SN-Prezydencki-minister-zabral-glos-8495710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiatraki-podziela-los-ustawy-o-SN-Prezydencki-minister-zabral-glos-8495710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 18:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/c197435430c97e-945-567-6-142-2705-1623.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liberalizacja ustawy wiatrakowej jest wbrew założeniom programowym PiS z 2015 i 2019 roku - powiedział w piątek w Studiu PAP doradca prezydenta Andrzeja Dudy Paweł Sałek.</p>

## Kraje G7 zapowiedziały nowe sankcje na Rosję. Ostrzegły też jej sojuszników
 - [https://www.bankier.pl/wiadomosc/Kraje-G7-zapowiedzialy-nowe-sankcje-na-Rosje-Ostrzegly-tez-jej-sojusznikow-8495701.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kraje-G7-zapowiedzialy-nowe-sankcje-na-Rosje-Ostrzegly-tez-jej-sojusznikow-8495701.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 17:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/f/ca9cf0ba106a77-948-568-0-60-1739-1043.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Państwa G7 podejmą kroki przeciw państwom wspierającym materialnie "rosyjską wojnę" - poinformowali przywódcy krajów grupy w komunikacie wydanym po piątkowym, wirtualnym szczycie. Zobowiązali się do "zintensyfikowania dyplomatycznego, finansowego i militarnego wsparcia dla Ukrainy".</p>

## Polskie wersje czołgów K2  będą produkowane w Poznaniu. Podpisano umowy z koreańskimi producentami
 - [https://www.bankier.pl/wiadomosc/Polskie-wersje-czolgow-K2-beda-produkowane-w-Poznaniu-Podpisano-umowy-z-koreanskimi-producentami-8495686.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-wersje-czolgow-K2-beda-produkowane-w-Poznaniu-Podpisano-umowy-z-koreanskimi-producentami-8495686.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 17:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/3cc3bbd3bb277c-948-568-31-26-1538-922.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska Grupa Zbrojeniowa podpisała z koreańskimi producentami uzbrojenia umowy o współpracy przy produkcji czołgów K2 i samobieżnych armatohaubic K9 – poinformowała PGZ w piątek.</p>

## Ciężki tydzień dla WIG20. Akcje Orlenu w dół mimo rekordowych wyników
 - [https://www.bankier.pl/wiadomosc/Ciezki-tydzien-dla-WIG20-Akcje-Orlenu-w-dol-mimo-rekordowych-wynikow-8495625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ciezki-tydzien-dla-WIG20-Akcje-Orlenu-w-dol-mimo-rekordowych-wynikow-8495625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 15:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/b86f474ab95658-948-568-0-99-4403-2642.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Piątek, jak i cały tydzień zakończył się pod kreską na najważniejszych indeksach w Warszawie. Na rynku pojawiły się rekordowe wyniki PKN Orlen, ale większy kaliber miały dane z USA. Tydzień przyniósł większą przecenę dużych i średnich spółek oraz lepsza postawę tych z sWIG80.</p>

## Polski i amerykański przemysł zbrojeniowy połączą siły? Duda: Rozmawiałem o tym z Bidenem
 - [https://www.bankier.pl/wiadomosc/Polski-i-amerykanski-przemysl-zbrojeniowy-polacza-sily-Duda-Rozmawialem-o-tym-z-Bidenem-8495612.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polski-i-amerykanski-przemysl-zbrojeniowy-polacza-sily-Duda-Rozmawialem-o-tym-z-Bidenem-8495612.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 15:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/d292024f826d75-948-568-20-160-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rozmawiałem z prezydentem USA Joe Bidenem o rozpoczęciu wspólnej produkcji militarnej np. amunicji, wiec można powiedzieć, że rozmowa na ten temat, na tym najwyższym prezydenckim poziomie ze Stanami Zjednoczonymi została rozpoczęta - powiedział w piątek prezydent Andrzej Duda po posiedzeniu RBN.</p>

## Kruk szacuje, że zysk netto grupy w IV kw. '22 wyniósł ok. 128 mln zł; powyżej konsensusu
 - [https://www.bankier.pl/wiadomosc/Kruk-szacuje-ze-zysk-netto-grupy-w-IV-kw-22-wyniosl-ok-128-mln-zl-powyzej-konsensusu-8495578.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kruk-szacuje-ze-zysk-netto-grupy-w-IV-kw-22-wyniosl-ok-128-mln-zl-powyzej-konsensusu-8495578.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 15:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/6/3decf92ef9dfdf-948-568-0-0-1019-611.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kruk szacuje, że zysk netto grupy w 2022 r. wyniósł 805 mln zł - poinformowała spółka w komunikacie. W samym IV kwartale - według wyliczeń PAP Biznes - zysk wyniósł ok. 128 mln zł. Konsensus PAP Biznes zakładał zysk na poziomie 121,8 mln zł.</p>

## Gaz-System ma pozwolenie na budowę gazociągu Racibórz-Oświęcim
 - [https://www.bankier.pl/wiadomosc/Gaz-System-ma-pozwolenie-na-budowe-gazociagu-Raciborz-Oswiecim-8495544.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gaz-System-ma-pozwolenie-na-budowe-gazociagu-Raciborz-Oswiecim-8495544.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 14:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/7e2335a7409313-945-567-0-35-926-556.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Operator systemu przesyłowego gazu Gaz-System poinformował w piątek, że ma już komplet decyzji, pozwalających rozpocząć budowę gazociągu Racibórz-Oświęcim. Gazociąg umożliwi m.in. przyłączenie do sieci planowanego przez PGE 882 MW bloku gazowego w Rybniku.</p>

## Morawiecki: Na dniach przekażemy Ukrainie kolejne czołgi PT-91
 - [https://www.bankier.pl/wiadomosc/Morawiecki-Na-dniach-przekazemy-Ukrainie-czolgi-PT-91-8495480.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morawiecki-Na-dniach-przekazemy-Ukrainie-czolgi-PT-91-8495480.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 13:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/57736190180872-948-568-60-20-1456-873.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na dniach przekażemy Ukrainie bardzo dobre czołgi PT-91 - powiedział w piątek w Kijowie premier Mateusz Morawiecki. Dodał, że w Polsce trwa obecnie bardzo intensywne szkolenie żołnierzy ukraińskich.</p>

## AI wskazała, Google zwolniło. Nowy wymiar cięć etatów
 - [https://www.bankier.pl/wiadomosc/AI-wskazala-Google-zwolnilo-Nowy-wymiar-ciec-etatow-8495351.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/AI-wskazala-Google-zwolnilo-Nowy-wymiar-ciec-etatow-8495351.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 12:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/d9f1acc389a7d9-948-568-0-240-1024-614.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Google zwolnił aż 12 tys. pracowników. Przy takiej skali cięć nie sposób, by dział HR wyrobił się z oceną każdego - podejrzewały osoby, które straciły pracę. Jedynym logicznym wytłumaczeniem byłaby AI, a więc jak napisali na czatach "bezduszny algorytm, który miał wybrać zwolnienie tak, by nie naruszać żadnych praw".</p>

## Ekspert: Ukraiński biznes może przyczynić się do wzrostu polskiego PKB
 - [https://www.bankier.pl/wiadomosc/Ekspert-Ukrainski-biznes-moze-przyczynic-sie-do-wzrostu-polskiego-PKB-8495276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekspert-Ukrainski-biznes-moze-przyczynic-sie-do-wzrostu-polskiego-PKB-8495276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 12:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/0a01a6552b0553-937-562-7-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraiński biznes może przyczynić się do wzrostu polskiego PKB - ocenił w rozmowie z PAP szef śląskiego oddziału Polsko-Ukraińskiej Izby Gospodarczej Roman Dryps. Dodał, że spółki z kapitałem ukraińskim mogą stać się ważnym "pasem transmisyjnym" dla polskich firm po rozpoczęciu odbudowy Ukrainy.</p>

## Leopardy od Polski już w Ukrainie. "Dzierżymy w tym zakresie palmę pierwszeństwa"
 - [https://www.bankier.pl/wiadomosc/Leopardy-od-Polski-juz-w-Ukrainie-Dzierzymy-w-tym-zakresie-palme-pierwszenstwa-8495389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Leopardy-od-Polski-juz-w-Ukrainie-Dzierzymy-w-tym-zakresie-palme-pierwszenstwa-8495389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 11:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/cf661a8135bf37-948-568-23-46-4632-2779.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Cieszę się, że dzierżymy także w tym zakresie palmę pierwszeństwa  - powiedział w piątek prezydent Andrzej Duda odnosząc się na posiedzeniu Rady Bezpieczeństwa Narodowego do przekazania przez Polskę czołgów Leopard Ukrainie.</p>

## Inflacja w Japonii najwyższa od 41 lat
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-Japonii-styczen-2023-8495384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-Japonii-styczen-2023-8495384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 11:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/7299fe15b0ff57-948-567-5-0-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Japońska inflacja CPI w styczniu osiągnęła
najwyższy poziom od 1981 roku, nasilając presję na prowadzący skrajnie luźną
politykę monetarną Bank Japonii.</p>

## Mikro i małe firmy z niepokojem patrzą w przyszłość. Zobacz 3 wykresy o nastrojach przedsiębiorców
 - [https://www.bankier.pl/wiadomosc/Male-firmy-z-niepokojem-patrza-w-przyszlosc-Zobacz-3-wykresy-o-przedsiebiorcach-8495326.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Male-firmy-z-niepokojem-patrza-w-przyszlosc-Zobacz-3-wykresy-o-przedsiebiorcach-8495326.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 11:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/7/c496be0b000c9c-948-568-0-0-1689-1013.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przedsiębiorcy z nieco większym optymizmem patrzą w przyszłość. Około 8,4 proc. osób decyzyjnych w firmach z sektora MŚP wskazuje na polepszenie się sytuacji ekonomicznej podmiotu w ciągu ostatnich trzech miesięcy. To wzrost o 4,2 pp. w porównaniu z analogicznym okresem w ubiegłym roku. Zobacz trzy wykresy o nastrojach przedsiębiorców.</p>

## Tym będą żyły rynki: czy potwierdzą się fatalne dane z polskiej gospodarki?
 - [https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-czy-potwierdza-sie-fatalne-dane-z-polskiej-gospodarki-8495317.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-czy-potwierdza-sie-fatalne-dane-z-polskiej-gospodarki-8495317.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 11:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/0d3a7981a4a9dd-945-560-8-116-1722-1033.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W nadchodzącym tygodniu przekonamy się, czy GUS 
podtrzyma fatalne pierwsze szacunki wzrostu gospodarczego pod koniec 
minionego roku. Wyniki opublikuje kilka dużych spółek z GPW.</p>

## Silna przecena oleju napędowego. Paliwa wciąż znacznie droższe niż rok temu
 - [https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Polsce-24-lutego-2023-8495353.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Polsce-24-lutego-2023-8495353.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 10:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/9/d1455bee3d1651-948-568-7-210-2200-1320.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ostatni pełny tydzień lutego przyniósł silne spadki
detalicznych cen oleju napędowego w Polsce. Bez większych zmian pozostały ceny
benzyn i autogazu.</p>

## "Jedźcie rzepę zamiast pomidorów". Reglamentacja w Wielkiej Brytanii potrwa cztery tygodnie
 - [https://www.bankier.pl/wiadomosc/Jedzcie-rzepe-zamiast-pomidorow-Reglamentacja-w-Wielkiej-Brytanii-potrwa-cztery-tygodnie-8495318.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jedzcie-rzepe-zamiast-pomidorow-Reglamentacja-w-Wielkiej-Brytanii-potrwa-cztery-tygodnie-8495318.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 10:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/2e67ebe3f5a11c-948-568-826-504-3205-1923.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Aby każdy mógł kupić to, czego potrzebuje. Limit 
trzech ogórków na klienta" - takie i podobne tabliczki pojawiły się przy
 brytyjskich stoiskach z warzywami. Po pustkach przed świętami i 
zdjęciami środków chemicznych zamiast rzeczywistych produktów, Wyspy 
ponownie stają przed problemem reglamentacji. Tym razem sprawa dotyczy 
głównie warzyw. </p>

## Złoty odzyskał siły. Kurs euro powrócił do 4,72 zł
 - [https://www.bankier.pl/wiadomosc/Zloty-odzyskal-sily-Kurs-euro-powrocil-do-4-72-zl-8495293.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zloty-odzyskal-sily-Kurs-euro-powrocil-do-4-72-zl-8495293.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 09:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/fdbefecae93b5d-945-560-15-12-985-590.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro powrócił do linii, która wyznaczała zakres
jesienno-zimowej konsolidacji. Dzięki temu złotemu udało się odrobić większość
lutowych strat.</p>

## Nie tylko cięcia. Te firmy z branży motoryzacyjnej dają podwyżki
 - [https://www.bankier.pl/wiadomosc/Nie-tylko-ciecia-Te-firmy-z-branzy-motoryzacyjnej-daja-podwyzki-8495285.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-tylko-ciecia-Te-firmy-z-branzy-motoryzacyjnej-daja-podwyzki-8495285.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 09:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/b80c454a760ea5-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To największe podwyżki wynagrodzeń od dziecięcioleci -
 tak w opublikowanych przez siebie komunikatach zapewnili japońscy 
giganci przemysłu motoryzacyjnego: Toyota i Honda. Tym samym chcą 
osłodzić swoim pracownikom najwyższą od ponad 40 lat inflację. </p>

## Weekend bez Blika, przelewów i płatności kartami. Pięć banków z przerwami
 - [https://www.bankier.pl/wiadomosc/Przerwa-techniczna-w-Millennium-Santanderze-VeloBanku-BPS-Nest-Banku-8495280.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przerwa-techniczna-w-Millennium-Santanderze-VeloBanku-BPS-Nest-Banku-8495280.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 09:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/e33bcb612cab92-948-568-0-133-1982-1189.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W nadchodzących dniach klienci kilku banków działających w Polsce nie będą mogli skorzystać z bankowości elektronicznej, mobilnej czy płatności Blikiem. Jak co tydzień, sprawdzamy, klientów których banków czekają weekendowe przerwy w dostępie do usług.
</p>

## Fabryka Broni Łucznik z rekordowym kontraktem. Szef MON: Zamówiliśmy w sumie 200 tys. karabinków GROT
 - [https://www.bankier.pl/wiadomosc/Fabryka-Broni-Lucznik-z-rekordowym-kontraktem-Szef-MON-Zamowilismy-w-sumie-200-tys-karabinkow-GROT-8495269.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fabryka-Broni-Lucznik-z-rekordowym-kontraktem-Szef-MON-Zamowilismy-w-sumie-200-tys-karabinkow-GROT-8495269.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 09:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/df959a40219895-948-568-20-225-2022-1213.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2023 r. zatwierdziłem już umowę w sprawie zamówienia karabinków GROT w radomskiej Fabryce Broni Łucznik, w sumie zostało zamówionych niemal 200 tys. karabinków za 2 mld 100 mln zł, dziś na niemal 90 tys. sztuk za 1 mld zł - powiedział w piątek w Radomiu wicepremier szef MON Mariusz Błaszczak.</p>

## Rok wojny w Ukrainie. Popkultura ją monetyzuje, Ukraina zyskuje, a Rosja bierze na przeczekanie
 - [https://www.bankier.pl/wiadomosc/Rok-wojny-na-Ukrainie-Popkultura-ja-monetyzuje-Ukraina-zyskuje-a-Rosja-bierze-na-przeczekanie-8494049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rok-wojny-na-Ukrainie-Popkultura-ja-monetyzuje-Ukraina-zyskuje-a-Rosja-bierze-na-przeczekanie-8494049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/5e5d07455806b8-948-568-0-187-3264-1958.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sean Penn jeszcze w lutym odwiedził Ukrainę, kolejne gwiazdy robią pokaźne przelewy na organizacje charytatywne pomagające uchodźcom, a koszulki ze słynną kwestią obrońców z Wyspy Wężowej sprzedają się na pniu - wojna wkroczyła do popkultury. </p>

## Wizz Air, Ryanair i Eurowings najgorszymi liniami lotniczymi w Europie
 - [https://www.bankier.pl/wiadomosc/Wizz-Air-Ryanair-i-Eurowings-najgorszymi-liniami-lotniczymi-w-Europie-8495252.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wizz-Air-Ryanair-i-Eurowings-najgorszymi-liniami-lotniczymi-w-Europie-8495252.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 08:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/d171a7c0092f5f-948-568-0-0-1988-1192.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wizz Air został uznany za najgorszą linię lotniczą w 
Europie w latach 2021-22 r. wynika z ankiety przeprowadzonej wśród 
pasażerów przez brytyjski portal „Which?”. W ogonie stawki znalazły się także inne linie latające z polskich lotnisk.</p>

## Cena miedzi na LME idzie w dół po największym spadku w tym roku w czwartek
 - [https://www.bankier.pl/wiadomosc/Cena-miedzi-na-LME-idzie-w-dol-po-najwiekszym-spadku-w-tym-roku-w-czwartek-8495243.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cena-miedzi-na-LME-idzie-w-dol-po-najwiekszym-spadku-w-tym-roku-w-czwartek-8495243.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 08:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/f5793e525ed31b-948-568-0-169-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny miedzi na giełdzie metali LME idą w dół po największym jednodniowym spadku w 2023 r. na zakończenie handlu w czwartek. Miedź w dostawach 3-miesięcznych jest wyceniana niżej o 0,21 proc. - po 8885,50 USD za tonę - podają maklerzy.</p>

## Polacy chętnie inwestują w siebie. Samorozwój coraz popularniejszy
 - [https://www.bankier.pl/wiadomosc/Polacy-chetnie-inwestuja-w-siebie-Samorozwoj-coraz-popularniejszy-8495240.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-chetnie-inwestuja-w-siebie-Samorozwoj-coraz-popularniejszy-8495240.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 08:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/276f25260dd9e4-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polacy chętnie inwestują w siebie - deklaruje to aż 68 proc. rodaków. Natomiast co 5. przyznaje, że tego nie robi – wynika z raportu platformy edukacyjnej Tutore Poland "Czy inwestujemy w siebie?", przekazanym PAP.</p>

## ISW ostrzega. Rosja może przeprowadzić prowokacje m.in. w Mołdawii
 - [https://www.bankier.pl/wiadomosc/ISW-ostrzega-Rosja-moze-przeprowadzic-prowokacje-m-in-w-Moldawii-8495236.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ISW-ostrzega-Rosja-moze-przeprowadzic-prowokacje-m-in-w-Moldawii-8495236.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 08:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/c61783e4146a4a-948-569-0-70-991-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W najbliższym czasie Kreml może przeprowadzić zbrojne prowokacje na granicy z ukraińskim obwodem czernihowskim i w kontrolowanym przez Moskwę regionie Naddniestrza w Mołdawii; celem tych działań byłoby wciągnięcie Białorusi w wojnę przeciwko Ukrainie i osłabienie państwa mołdawskiego - ostrzegł w najnowszym raporcie amerykański Instytut Studiów nad Wojną (ISW).</p>

## Uroczystości w centrum Kijowa. Zełenski podziękował żołnierzom
 - [https://www.bankier.pl/wiadomosc/Uroczystosci-w-centrum-Kijowa-Zelenski-podziekowal-zolnierzom-8495234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Uroczystosci-w-centrum-Kijowa-Zelenski-podziekowal-zolnierzom-8495234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 08:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/6d74a0ee562071-948-568-0-255-2841-1704.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od was zależy, czy przetrwa Ukraina - powiedział prezydent Wołodymyr Zełenski, zwracając się do żołnierzy ukraińskich sił zbrojnych podczas uroczystości rocznicowej w centrum Kijowa w piątek, gdy mija rok od inwazji rosyjskiej.</p>

## Prezes CPK: Latem ruszą prace budowlane. Bez wywłaszczeń
 - [https://www.bankier.pl/wiadomosc/Prezes-CPK-Latem-rusza-prace-budowlane-Bez-wywlaszczen-8495227.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezes-CPK-Latem-rusza-prace-budowlane-Bez-wywlaszczen-8495227.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 08:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/981bfc02e2b4bb-948-568-7-112-2992-1795.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wygląda na to, że latem tego roku rozpoczniemy pierwsze prace budowlane, bez żadnych przymusowych wywłaszczeń, tylko na gruntach, które zostały CPK sprzedane dobrowolnie – powiedział w piątek w Radiu Katowice pełnomocnik rządu ds. Centralnego Portu Komunikacyjnego Marcin Horała.</p>

## Panika na GPW, wystrzał cen paliw czy run na bankomaty i kantory... Rynki po inwazji na Ukrainę. "Zdania ekspertów są podzielone" - odcinek 8
 - [https://www.bankier.pl/wiadomosc/Rocznica-ataku-Rosji-na-Ukraine-Zdania-ekspertow-sa-podzielone-odcinek-8-8494821.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rocznica-ataku-Rosji-na-Ukraine-Zdania-ekspertow-sa-podzielone-odcinek-8-8494821.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/583924609bbf41-948-568-0-239-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ósmym odcinku programu Bankier.pl "Zdania ekspertów są podzielone" rozmawiamy o reakcji rynków na inwazję Rosji na Ukrainę.</p>

## Fabryka Porcelany „Krzysztof” wygasiła swoje piece. Znów uruchamia sklep internetowy
 - [https://www.bankier.pl/wiadomosc/Fabryka-Porcelany-Krzysztof-wygasila-swoje-piece-Uruchamia-sklep-internetowy-8495189.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fabryka-Porcelany-Krzysztof-wygasila-swoje-piece-Uruchamia-sklep-internetowy-8495189.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 07:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/59982228cce2b7-948-568-39-3-1161-696.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fabryka Porcelany „Krzysztof”
zakończyła swoją działalność z końcem 2022 r. głównie z powodu ogromnych podwyżek
cen gazu. Wygasiła już nawet swoje piece zdobnicze. Jednak od dziś ponownie
uruchamia sklep internetowy.</p>

## Ukraińcy nie załamali polskiego rynku pracy. Wręcz przeciwnie
 - [https://www.bankier.pl/wiadomosc/Ukraincy-nie-zalamali-polskiego-rynku-pracy-Wrecz-przeciwnie-8495020.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraincy-nie-zalamali-polskiego-rynku-pracy-Wrecz-przeciwnie-8495020.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/2/3b5802db55af33-948-568-18-12-2477-1486.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Według danych Ministerstwa Pracy i Polityki Społecznej, od początku wojny zatrudnienie w Polsce znalazło 900 tys. Ukraińców. Nie oznacza to jednak, że wyparli z rynku pracy Polaków. Według ekspertów jedynie uzupełnili istniejącą wcześniej lukę, związana z niskim bezrobociem, starzejącym się społeczeństwem i brakiem kompetencji polskich pracowników.</p>

## Największa polska firma pokazała najlepsze wyniki w historii
 - [https://www.bankier.pl/wiadomosc/Wyniki-Orlenu-Najwieksza-polska-firma-pokazala-najlepsze-wyniki-w-historii-8495088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyniki-Orlenu-Najwieksza-polska-firma-pokazala-najlepsze-wyniki-w-historii-8495088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 06:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/1011d3c1e5b2f0-948-568-0-82-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Największa polska firma pokazała najlepsze wyniki w historii. Dobra passa trwa, bo PKN Orlen z każdym kolejnym kwartałem tego roku bije poprzedni pod względem kluczowych pozycji raportu finansowego. To m.in. efekt przejęć kolejno Lotosu i PGNiG oraz wysokich marż na przerobie ropy.  </p>

## Oto jak Chiny chcą dostarczać Rosji drony kamikadze
 - [https://www.bankier.pl/wiadomosc/Oto-jak-Chiny-chca-dostarczac-Rosji-drony-kamikadze-8495174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oto-jak-Chiny-chca-dostarczac-Rosji-drony-kamikadze-8495174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 06:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/267901bcad747f-948-569-295-105-1566-940.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosyjska armia prowadzi z Chinami rozmowy o produkcji dronów kamikadze. Do Moskwy mają one trafić dzięki sfałszowanym dokumentom przewozowym - poinformował w piątek portal tygodnika "Der Spiegel".</p>

## Zamieszanie wokół szkół medycznych. MZ: Chodzi o standardy kształcenia, a nie nazwę
 - [https://www.bankier.pl/wiadomosc/Katolickie-Szkoly-Medyczne-MZ-Chodzi-o-standardy-ksztalcenia-a-nie-nazwe-8495127.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Katolickie-Szkoly-Medyczne-MZ-Chodzi-o-standardy-ksztalcenia-a-nie-nazwe-8495127.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 05:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/0/4bc891609f4564-948-568-0-0-1669-1001.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trwa zamieszkanie wokół Katolickich Szkół Medycznych. Część lekarzy zwróciła się do Komisji Europejskiej z pytaniem odnośnie do wymogów kształcenia lekarzy. Jak podaje Ministerstwo Zdrowia, na nowych uczelniach będzie chodziło o standardy kształcenia, a nie nazwę.</p>

## Prezes KredoBanku: Ukraińskie firmy muszą przetrwać wojnę, aby było z kim odbudowywać Ukrainę
 - [https://www.bankier.pl/wiadomosc/Prezes-KredoBanku-Ukrainskie-firmy-musza-przetrwac-wojne-aby-bylo-z-kim-odbudowywac-Ukraine-8495121.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezes-KredoBanku-Ukrainskie-firmy-musza-przetrwac-wojne-aby-bylo-z-kim-odbudowywac-Ukraine-8495121.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 05:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/9b38f55a771c3f-948-568-867-0-2533-1519.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraińskie firmy muszą przetrwać do zakończenia wojny, aby było z kim Ukrainę odbudowywać. Dlatego tak ważna jest każda linia gwarancyjna i wsparcie międzynarodowych instytucji – powiedział PAP prezes ukraińskiego KredoBanku Jacek Szugajew.</p>

## Wojna w Ukrainie wydrenowała portfele Polaków
 - [https://www.bankier.pl/wiadomosc/Wojna-w-Ukrainie-wydrenowala-portfele-Polakow-8495090.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wojna-w-Ukrainie-wydrenowala-portfele-Polakow-8495090.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 05:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/1/8382f95bb4a92f-948-568-49-138-3918-2351.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosyjska agresja na Ukrainę kosztowała podwyższoną
inflację, objawiającą się wyższymi cenami paliw, energii i żywności oraz osłabieniem złotego.</p>

## Rekordowy kontrakt dla Fabryki Broni Łucznik
 - [https://www.bankier.pl/wiadomosc/Rekordowy-kontrakt-dla-Fabryki-Broni-Lucznik-8495116.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rekordowy-kontrakt-dla-Fabryki-Broni-Lucznik-8495116.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 05:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/0/0e59d9143dfb81-948-568-0-116-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wicepremier, szef MON Mariusz Błaszczak zatwierdzi w piątek w Fabryce Broni Łucznik w Radomiu aneks do umowy na dostawy kolejnej partii karabinków MSBS GROT oraz umowę na dostawę karabinów wyborowych (7,62 mm SKBW) dla polskiego wojska. Fabryka podkreśla, że będzie to rekordowe zamówienie.</p>

## Chiny apelują o rozpoczęcie negocjacji pokojowych
 - [https://www.bankier.pl/wiadomosc/Chiny-apeluja-o-rozpoczecie-negocjacji-pokojowych-8495112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-apeluja-o-rozpoczecie-negocjacji-pokojowych-8495112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 05:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/eafc634b744221-948-568-0-48-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chiński rząd wezwał Rosję i Ukrainę do wznowienia dialogu i odrzucił wszelkie próby użycia broni jądrowej w 12-punktowym dokumencie opublikowanym w piątek, rok po ataku Rosji na Ukrainę.</p>

## Ekspertka: Rośnie liczba firm zakładanych przez obywateli Ukrainy w Polsce
 - [https://www.bankier.pl/wiadomosc/Ekspertka-Rosnie-liczba-firm-zakladanych-przez-obywateli-Ukrainy-w-Polsce-8495110.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekspertka-Rosnie-liczba-firm-zakladanych-przez-obywateli-Ukrainy-w-Polsce-8495110.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 05:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/5/cf5d341f7c2f55-948-568-437-288-3974-2384.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wciąż rośnie liczba firm zakładanych przez obywateli 
Ukrainy w Polsce - mówi Aleksandra Wejt-Knyżewska z Polskiego Instytutu 
Ekonomicznego. Od marca 2022 r. założyli oni u nas ponad 17,7 tys. 
jednoosobowych działalności gospodarczych.</p>

## Blisko 5 tys. rosyjskich ostrzałów. Rakietowy bilans wojny w Ukrainie
 - [https://www.bankier.pl/wiadomosc/Blisko-5-tys-rosyjskich-ostrzalow-Rakietowy-bilans-wojny-w-Ukrainie-8494755.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Blisko-5-tys-rosyjskich-ostrzalow-Rakietowy-bilans-wojny-w-Ukrainie-8494755.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/3/120e555867532e-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od początku inwazji na Ukrainę Rosja przeprowadziła prawie 5 tysięcy ostrzałów rakietowych i 3,5 tysiąca ostrzałów lotniczych - poinformował w czwartek przedstawiciel ukraińskiego sztabu generalnego gen. Ołeksij Hromow.</p>

## Rok po wojennej panice. Branżowa hossa, spekulacja i japoński przykład
 - [https://www.bankier.pl/wiadomosc/Rok-po-wojennej-panice-Branzowa-hossa-spekulacja-i-japonski-przyklad-8494767.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rok-po-wojennej-panice-Branzowa-hossa-spekulacja-i-japonski-przyklad-8494767.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/4/3547ef30379763-945-560-0-0-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mija rok od wybuchu wojny w Ukrainie. Inwestorzy najpierw zareagowali panicznie, nawiązując do największych przecen w historii GPW, by później poszukać inwestycyjnych szans. Ostatecznie o rynkowych nastrojach i tak decydowały banki centralne. Czy jednak WIG może być jak swego czasu Nikkei?</p>

## Rynek najmu na wojennej ścieżce. Tak zmienił się od wybuchu wojny w Ukrainie
 - [https://www.bankier.pl/wiadomosc/Rynek-najmu-na-wojennej-sciezce-Tak-zmienil-sie-od-wybuchu-wojny-na-Ukrainie-8494708.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rynek-najmu-na-wojennej-sciezce-Tak-zmienil-sie-od-wybuchu-wojny-na-Ukrainie-8494708.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/5/cacf28d33a701d-948-568-0-49-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 20 proc. do blisko 45 proc. wzrosły w ciągu roku średnie ceny ofertowe na rynku najmu mieszkań w największych miastach Polski – wynika z danych Otodom Analytics. W rocznicę inwazji Rosji na Ukrainę sprawdzamy, jak napływ uchodźców zza wschodniej granicy wpłynął na rynek najmu i czego spodziewać się w najbliższych miesiącach.
</p>

## USA zwiększają  pomoc wojskową dla Ukrainy o 2 miliardy dolarów
 - [https://www.bankier.pl/wiadomosc/USA-zwiekszaja-pomoc-wojskowa-dla-Ukrainy-o-2-miliardy-dolarow-8495100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-zwiekszaja-pomoc-wojskowa-dla-Ukrainy-o-2-miliardy-dolarow-8495100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-24 03:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/1a82b7bd62a04d-948-568-15-0-3169-1901.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stany Zjednoczone przekażą Ukrainie dodatkowe 2 miliardy dolarów na pomoc w zakresie bezpieczeństwa, powiedział w czwartek doradca Białego Domu ds. bezpieczeństwa narodowego Jake Sullivan.</p>

