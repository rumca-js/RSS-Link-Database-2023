# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## The nation’s cartoonists on the week in politics
 - [https://www.politico.com/gallery/2023/02/24/the-nations-cartoonists-on-the-week-in-politics-00084256](https://www.politico.com/gallery/2023/02/24/the-nations-cartoonists-on-the-week-in-politics-00084256)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-02-24 06:31:40+00:00

Every week political cartoonists throughout the country and across the political spectrum apply their ink-stained skills to capture the foibles, memes, hypocrisies and other head-slapping events in the world of politics. The fruits of these labors are hundreds of cartoons that entertain and enrage readers of all political stripes. Here's an offering of the best of this week's crop, picked fresh off the Toonosphere. Edited by Matt Wuerker.

