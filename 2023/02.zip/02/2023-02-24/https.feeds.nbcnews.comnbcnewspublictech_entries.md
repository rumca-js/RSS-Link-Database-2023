# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## Meet the $10,000 Nvidia chip powering the race for A.I.
 - [https://www.nbcnews.com/tech/tech-news/meet-10000-nvidia-chip-powering-race-rcna72155](https://www.nbcnews.com/tech/tech-news/meet-10000-nvidia-chip-powering-race-rcna72155)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-02-24 13:14:43+00:00

Software that can write passages of text or draw pictures that look like a human created them has kicked off a gold rush in the technology industry.

## YouTube creators can now dub their videos in multiple languages
 - [https://www.nbcnews.com/tech/tech-news/youtube-creators-can-now-dub-videos-multiple-languages-rcna72047](https://www.nbcnews.com/tech/tech-news/youtube-creators-can-now-dub-videos-multiple-languages-rcna72047)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-02-24 01:31:33+00:00

YouTube rolled out a new feature Thursday that allows creators to dub their content in other languages, making them accessible to viewers around the globe.

