# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Ktoś chciał zamówić u Daniela kampanię reklamową na FB w budżecie ~$100 000 na miesiąc. W szczegółach projektu… był malware, który miał zainfekować komputer.
 - [https://sekurak.pl/ktos-chcial-zamowic-u-daniela-kampanie-reklamowa-na-fb-w-budzecie-100-000-na-miesiac-w-szczegolach-projektu-byl-malware-ktory-mial-zainfekowac-komputer/](https://sekurak.pl/ktos-chcial-zamowic-u-daniela-kampanie-reklamowa-na-fb-w-budzecie-100-000-na-miesiac-w-szczegolach-projektu-byl-malware-ktory-mial-zainfekowac-komputer/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-02-24 14:52:51+00:00

<p>Daniel przesłał nam taką historię: Kilka dni temu otrzymałem propozycję współpracy w zakresie konsultacji dotyczącej płatnej kampanii na FB od tego gościa&#160;https://lnkd[.]in/dqG_ieqr W wielkim skrócie. Na początku zwyczajna rozmowa, linki do profili, strony www. Zaproponowałem spotkanie na Google Meet, w odpowiedzi dostałem link do iCloud z materiałami do zapoznania się....</p>
<p>Artykuł <a href="https://sekurak.pl/ktos-chcial-zamowic-u-daniela-kampanie-reklamowa-na-fb-w-budzecie-100-000-na-miesiac-w-szczegolach-projektu-byl-malware-ktory-mial-zainfekowac-komputer/" rel="nofollow">Ktoś chciał zamówić u Daniela kampanię reklamową na FB w budżecie ~$100 000 na miesiąc. W szczegółach projektu&#8230; był malware, który miał zainfekować komputer.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## OSINT kontra balon szpiegowski, czyli geolokalizacja na najwyższym poziomie
 - [https://sekurak.pl/osint-kontra-balon-szpiegowski-czyli-geolokalizacja-na-najwyzszym-poziomie/](https://sekurak.pl/osint-kontra-balon-szpiegowski-czyli-geolokalizacja-na-najwyzszym-poziomie/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-02-24 08:19:22+00:00

<p>W Stanach Zjednoczonych jednym z najpopularniejszych ostatnio tematów są niezidentyfikowane obiekty latające, zestrzeliwane nad terytorium USA. Jeden z nich, chiński balon szpie^H^H^H meteorologiczny, został uwieczniony 3 lutego 2023 roku na zdjęciu, wykonanym z kokpitu samolotu rozpoznawczego U-2. Departament Obrony USA potwierdził autentyczność zdjęcia, jednak nie podał ani danych pilota, ani...</p>
<p>Artykuł <a href="https://sekurak.pl/osint-kontra-balon-szpiegowski-czyli-geolokalizacja-na-najwyzszym-poziomie/" rel="nofollow">OSINT kontra balon szpiegowski, czyli geolokalizacja na najwyższym poziomie</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Darmowy pentest / audyt bezpieczeństwa od Securitum/sekuraka. ~Wyniki akcji.
 - [https://sekurak.pl/darmowy-pentest-audyt-bezpieczenstwa-od-securitum-sekuraka-wyniki-akcji/](https://sekurak.pl/darmowy-pentest-audyt-bezpieczenstwa-od-securitum-sekuraka-wyniki-akcji/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-02-24 08:08:14+00:00

<p>Dziękujemy wszystkim za liczny udział w akcji darmowy pentest / audyt bezpieczeństwa od sekuraka. TLDR: realizujemy pentest bezpłatnie, ale za zgodę na upublicznienie raportu po takich pracach (po załataniu podatności). Przykład takiego raportu tutaj (pentesty CANAL+) &#8211; mamy nadzieję, że takie raporty będą miały ciekawą wartość edukacyjną dla czytelników sekuraka....</p>
<p>Artykuł <a href="https://sekurak.pl/darmowy-pentest-audyt-bezpieczenstwa-od-securitum-sekuraka-wyniki-akcji/" rel="nofollow">Darmowy pentest / audyt bezpieczeństwa od Securitum/sekuraka. ~Wyniki akcji.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

