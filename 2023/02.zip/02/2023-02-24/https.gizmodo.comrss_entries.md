# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Ant-man’s Director on *That* End Credits Scene
 - [https://gizmodo.com/ant-man-s-director-on-that-end-credits-scene-1850147688](https://gizmodo.com/ant-man-s-director-on-that-end-credits-scene-1850147688)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 23:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--tAueJLjJ--/c_fit,fl_progressive,q_80,w_636/a1842abff749f542e13403d77d31f2ef.jpg" /><p><a href="https://gizmodo.com/ant-man-s-director-on-that-end-credits-scene-1850147688">Read more...</a></p>

## A Guide to the Messy, Divided Rights to The Lord of the Rings
 - [https://gizmodo.com/lord-of-the-rings-rights-explained-amazon-warner-bros-1850157744](https://gizmodo.com/lord-of-the-rings-rights-explained-amazon-warner-bros-1850157744)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 23:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--MT-QdoVG--/c_fit,fl_progressive,q_80,w_636/27cec08806f98a4939b9ae63aa42e877.jpg" /><p>Without one ring to rule them all, the rights for <a href="https://gizmodo.com/peter-jackson-lord-of-the-rings-return-warner-bros-1850154871">creators to tell stories</a> in Middle-earth have long been a confusing mess—a mess that has only gotten more confusing when <a href="https://gizmodo.com/lord-of-the-rings-rights-explained-embracer-group-amazo-1849428959">Embracer Group announced</a> it had acquired a <em>chunk</em> of <em>Lord of the Rings</em>’ rights. Not sure <a href="https://gizmodo.com/lord-of-the-rings-movies-new-more-warner-bros-1850152138">who exactly can do what</a>? Here’s our guide.<br /></p><p><a href="https://gizmodo.com/lord-of-the-rings-rights-explained-amazon-warner-bros-1850157744">Read more...</a></p>

## Vast Acquires Rocket Engine Firm to Speed Development of Space Station With Artificial Gravity
 - [https://gizmodo.com/vast-acquires-launcher-speed-development-space-station-1850156754](https://gizmodo.com/vast-acquires-launcher-speed-development-space-station-1850156754)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 22:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--fiuJleN8--/c_fit,fl_progressive,q_80,w_636/3bc25c593984207a53705eb138a5e90f.jpg" /><p>In Vast’s quest to build a space station complete with artificial gravity, the private space company has acquired startup Launcher in order to take a step toward making its plans a reality. Despite the news of the acquisition, both companies remain tightlipped on Vast’s plans for the space station. <br /></p><p><a href="https://gizmodo.com/vast-acquires-launcher-speed-development-space-station-1850156754">Read more...</a></p>

## The Latest News From Disney Parks, Universal Studios Resorts, and More Fan-tastical Destinations
 - [https://gizmodo.com/theme-park-news-disneyland-universal-studios-marvel-1850146838](https://gizmodo.com/theme-park-news-disneyland-universal-studios-marvel-1850146838)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 22:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--VGDLVZn0--/c_fit,fl_progressive,q_80,w_636/7d994615c8a95f266453950ece88d522.png" /><p>Cinema is in its awards season, and with that comes special screening engagements for nominated films like <a href="https://gizmodo.com/rrr-2-sequel-in-the-works-with-ntr-jr-ram-charan-teja-1849912864"><em>RRR</em></a>. Horror films <em>Scream VI</em> and <em>Cocaine Bear</em> are carving out fun with interactive pop-ups as they hit theaters. At the theme parks, <a href="https://gizmodo.com/super-nintendo-world-universal-studios-hollywood-mario-1849965867">Super Nintendo World</a> officially announces it is coming to Epic Universe; Disney…</p><p><a href="https://gizmodo.com/theme-park-news-disneyland-universal-studios-marvel-1850146838">Read more...</a></p>

## The Pros and Cons of Repairing Your Own Gadgets
 - [https://gizmodo.com/diy-self-repair-professional-repair-how-to-apple-samsun-1850138240](https://gizmodo.com/diy-self-repair-professional-repair-how-to-apple-samsun-1850138240)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 21:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--AqQcrMGX--/c_fit,fl_progressive,q_80,w_636/d737750a9e4c4a67d56940afd4f95241.jpg" /><p>When something goes wrong with one of your gadgets, you’re faced with a choice: Fix it yourself, or call in some professional help. With your options for these routes constantly changing (both <a href="https://gizmodo.com/apple-self-service-repair-program-macbooks-m1-air-pro-1849441900">Apple</a> and <a href="https://gizmodo.com/samsung-self-repair-kits-galaxy-s20-s21-ultra-tab-scree-1849360962">Samsung</a> have launched self-repair kits in recent years), we wanted to give you an up-to-date look at what you’ve got…</p><p><a href="https://gizmodo.com/diy-self-repair-professional-repair-how-to-apple-samsun-1850138240">Read more...</a></p>

## Live Nation Puts Fixing Ticket Sales on Performers and Lawmakers
 - [https://gizmodo.com/ticket-master-live-nation-taylor-swift-stubhub-1850156771](https://gizmodo.com/ticket-master-live-nation-taylor-swift-stubhub-1850156771)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 21:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--sdJZl_mp--/c_fit,fl_progressive,q_80,w_636/83f3d0c975f8b74d5243420b02c2060b.jpg" /><p>Live Nation Entertainment, the company that’s owned Ticketmaster since 2010, knows it’s hard out there for music fans. Really, it does. That’s why the company, which faced massive public pushback earlier this year in the aftermath of a <a href="https://gizmodo.com/taylor-swifts-tour-presale-breaks-ticketmaster-1849784615">Taylor Swift ticket sale meltdown</a>, has proposed a (kind of) solution.<br /></p><p><a href="https://gizmodo.com/ticket-master-live-nation-taylor-swift-stubhub-1850156771">Read more...</a></p>

## How To Print Anything From Your Phone or Tablet, No Laptop Required
 - [https://gizmodo.com/how-print-phone-tablet-ios-android-ipad-no-laptop-app-1850114790](https://gizmodo.com/how-print-phone-tablet-ios-android-ipad-no-laptop-app-1850114790)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Z_CDN2OO--/c_fit,fl_progressive,q_80,w_636/b6208777586bdec34b438825fef05844.jpg" /><p>We’re still not living in a fully paperless world, and all kinds of documents still need to be printed now and again: Application forms, quiz sheets, training materials, wedding speeches, and more all need to be in physical form for one reason or another. However, you don’t necessarily need to have a laptop or desktop…</p><p><a href="https://gizmodo.com/how-print-phone-tablet-ios-android-ipad-no-laptop-app-1850114790">Read more...</a></p>

## Terran Orbital Scores $2.4 Billion Deal to Develop 300 Satellites for Rivada
 - [https://gizmodo.com/terran-orbital-scores-lucrative-satellite-deal-rivada-1850156760](https://gizmodo.com/terran-orbital-scores-lucrative-satellite-deal-rivada-1850156760)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 21:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--MqkHO7Sw--/c_fit,fl_progressive,q_80,w_636/a20bed70749aa046a536d41701b3f64f.jpg" /><p>Satellite manufacturer Terran Orbital has been awarded a hefty contract by Rivada Space Networks to build  288 low Earth orbit satellites, and 12 spare satellites, for its communications constellation. </p><p><a href="https://gizmodo.com/terran-orbital-scores-lucrative-satellite-deal-rivada-1850156760">Read more...</a></p>

## The Best Apps and Tools For Enhancing Your Windows Taskbar
 - [https://gizmodo.com/windows-11-taskbar-fix-apps-tool-start-menu-settings-1850098368](https://gizmodo.com/windows-11-taskbar-fix-apps-tool-start-menu-settings-1850098368)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 21:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--V3MMN4-N--/c_fit,fl_progressive,q_80,w_636/ea7c83bb18294acc66908ce58cf411a5.jpg" /><p>The taskbar is at the center of everything you do on Microsoft’s operating system—launching and closing apps, switching between windows, personalizing the desktop—and has been around in some form since Windows 1.0. You’re definitely familiar with it. What you might not be familiar with is that you can actually…</p><p><a href="https://gizmodo.com/windows-11-taskbar-fix-apps-tool-start-menu-settings-1850098368">Read more...</a></p>

## Star Trek: Picard's Season 3 Premiere Is Streaming on YouTube For Free
 - [https://gizmodo.com/star-trek-picard-season-3-episode-1-watch-free-youtube-1850156313](https://gizmodo.com/star-trek-picard-season-3-episode-1-watch-free-youtube-1850156313)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--o7JyFyEY--/c_fit,fl_progressive,q_80,w_636/24774508ff43c92e938b909b7fc0ad72.jpg" /><p>Even if you’ve not watched the first two seasons of <a href="https://gizmodo.com/star-trek-picard-season-3-episode-2-recap-jack-crusher-1850150663"><em>Star Trek: Picard</em></a> (which is <em>not</em> entirely necessary, <a href="https://gizmodo.com/star-trek-picard-season-3-what-you-need-to-know-tng-1850119982">for better or worse</a>), the third season’s promise of a big <em>The Next Generation</em> reunion has <em>Trek</em> fans talking—and if you’ve not started it yet, Paramount’s giving you a tease for free.</p><p><a href="https://gizmodo.com/star-trek-picard-season-3-episode-1-watch-free-youtube-1850156313">Read more...</a></p>

## U.S. Man's Death Suggests Deadly Tick Virus Is Spreading to New Regions
 - [https://gizmodo.com/heartland-virus-death-maryland-virginia-ticks-1850157087](https://gizmodo.com/heartland-virus-death-maryland-virginia-ticks-1850157087)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 20:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--r2TFstT1--/c_fit,fl_progressive,q_80,w_636/3bb9f1f7305199058c8184428c2286e0.jpg" /><p>A rare but sometimes fatal tickborne infection may be expanding its range in the U.S., local and federal health officials warn in a report this week. They say that a case of Heartland virus  led to a man’s death in 2021. The infection is thought to have been caught in either Virginia or Maryland—a region of the…</p><p><a href="https://gizmodo.com/heartland-virus-death-maryland-virginia-ticks-1850157087">Read more...</a></p>

## How To Actually Choose a New Smartphone
 - [https://gizmodo.com/how-buy-smartphone-chose-ios-android-samsung-phone-mode-1850078990](https://gizmodo.com/how-buy-smartphone-chose-ios-android-samsung-phone-mode-1850078990)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 20:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--9-lENteZ--/c_fit,fl_progressive,q_80,w_636/d6645812806a71bf4516b80dc374fb52.jpg" /><p>If you’re in the market for a new smartphone, you’ve certainly got plenty of options to pick from—but it’s not necessarily all that easy to spot the differences between the dozens of glass-and-metal-and-plastic slabs that are out there. At the same time, certain specs and features that were once crucial are now less…</p><p><a href="https://gizmodo.com/how-buy-smartphone-chose-ios-android-samsung-phone-mode-1850078990">Read more...</a></p>

## Watch Out, Elon: China Could Launch 13,000 Satellites to Disrupt Starlink
 - [https://gizmodo.com/china-could-launch-13-000-satellites-disrupt-starlink-1850155775](https://gizmodo.com/china-could-launch-13-000-satellites-disrupt-starlink-1850155775)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 20:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--to-soTZQ--/c_fit,fl_progressive,q_80,w_636/6368b67ed65c1708cdcc4bba5721bc07.jpg" /><p>In an effort to stifle Elon Musk’s  Starlink, researchers in China are planning to launch their own fleet. The proposed megaconstellation has no set launch date, but is expected to consist of 12,992 satellites equipped with technologies to conduct surveillance on Starlink, among other capabilities. <br /></p><p><a href="https://gizmodo.com/china-could-launch-13-000-satellites-disrupt-starlink-1850155775">Read more...</a></p>

## Amazon Taking Heat for Inhumane Donkey Products Sold by Third-Party Vendors
 - [https://gizmodo.com/amazon-amazon-prime-peta-donkey-ejiao-1850156291](https://gizmodo.com/amazon-amazon-prime-peta-donkey-ejiao-1850156291)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 20:31:13+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--9mvabSiC--/c_fit,fl_progressive,q_80,w_636/09cb445ca5041b12495d760856d33945.jpg" /><p>Amazon is facing a stampede of protest over third-party vendors being allowed to sell donkey-based products. A few Donkey-based items, remedies, and snacks easily found on the digital marketplace are products of an international, inhumane slaughter of donkeys, and one California-based equine nonprofit wants Amazon to…</p><p><a href="https://gizmodo.com/amazon-amazon-prime-peta-donkey-ejiao-1850156291">Read more...</a></p>

## These AI-Generated Images of Climate Change Make Me Uncomfortable
 - [https://gizmodo.com/ai-generated-stock-images-of-climate-change-1850155713](https://gizmodo.com/ai-generated-stock-images-of-climate-change-1850155713)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 20:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--A0wx3WMZ--/c_fit,fl_progressive,q_80,w_636/ca8c497bfb955c38763c9699a57deec9.jpg" /><p>It’s getting harder to avoid AI-generated images and text—and harder to spot them in the first place—and that’s true even on Shutterstock, one of the world’s leading providers of stock photography. Last month, Shutterstock <a href="https://gizmodo.com/shutterstock-ai-art-open-ai-dall-e-1850028869">rolled out a tool</a> for paying users that allows them to generate AI images based on their…</p><p><a href="https://gizmodo.com/ai-generated-stock-images-of-climate-change-1850155713">Read more...</a></p>

## Teacher Charged After Crypto Mining Operation Discovered in School Crawl Space
 - [https://gizmodo.com/crypto-crypto-mining-teacher-digital-currency-1850156501](https://gizmodo.com/crypto-crypto-mining-teacher-digital-currency-1850156501)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--fabd_w0Y--/c_fit,fl_progressive,q_80,w_636/5c6b869d54a70eb531972b461913b275.jpg" /><p>A Massachusetts teacher is facing charges after authorities say he carried out an elaborate <a href="https://gizmodo.com/cash-cloud-bitcoin-atm-cryptocurrency-genesis-bankrupt-1850096095">cryptocurrency</a> mining operation out of the school where he worked. Nadeam Nahas, 39, was teaching at Cohasset High School when a town facilities inspector visited the school and found an unusual electrical setup in one room.</p><p><a href="https://gizmodo.com/crypto-crypto-mining-teacher-digital-currency-1850156501">Read more...</a></p>

## Puss in Boots: The Last Wish's Directors on Not Taking Life for Granted
 - [https://gizmodo.com/interview-directors-puss-in-boots-last-wish-animation-1850152460](https://gizmodo.com/interview-directors-puss-in-boots-last-wish-animation-1850152460)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--N8A38f2t--/c_fit,fl_progressive,q_80,w_636/fa5aaa129c58d4427fcf8adf6f4b6baa.jpg" /><p>The <em>Shrek</em> universe proves it still has stories to tell with <em>Puss in Boots: The Last Wish</em>. The sequel to the <a href="https://gizmodo.com/indiana-jones-dial-of-destiny-super-bowl-spot-1850097596">Antonio Banderas</a>-led <a href="https://gizmodo.com/puss-boots-bdsm-and-the-plutonic-ideal-5854639">spin-off</a> gives the <a href="https://gizmodo.com/how-to-train-your-dragon-live-action-adaptation-coming-1850120479">DreamWorks</a> franchise a soft reimagining that makes us excited for more.<br /></p><p><a href="https://gizmodo.com/interview-directors-puss-in-boots-last-wish-animation-1850152460">Read more...</a></p>

## Spring Has Sprung Way Early in Parts of the U.S.
 - [https://gizmodo.com/early-start-spring-usa-2023-warm-winter-1850154942](https://gizmodo.com/early-start-spring-usa-2023-warm-winter-1850154942)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 19:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Rk4Me_HM--/c_fit,fl_progressive,q_80,w_636/9f3856a547ba8e7dc8ef4f0da8437ee3.jpg" /><p>February 2023 has been especially warm, causing early spring-like conditions throughout the U.S.<br /></p><p><a href="https://gizmodo.com/early-start-spring-usa-2023-warm-winter-1850154942">Read more...</a></p>

## The Spider-Man of India Is Back With His Own Comic
 - [https://gizmodo.com/spider-man-india-marvel-comic-across-the-spider-verse-1850156042](https://gizmodo.com/spider-man-india-marvel-comic-across-the-spider-verse-1850156042)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--lsAdhkmc--/c_fit,fl_progressive,q_80,w_636/a254d56d15b7ebb43ab42177921df2d4.png" /><p>Pavitr Prabhakar is one of the most <a href="https://gizmodo.com/the-greatest-spider-men-of-all-time-ranked-1796693647">iconic alternate Spider-heroes</a> in Marvel’s long history of Spider-People—and his name is going to be on the lips of a lot more fans when he takes <a href="https://gizmodo.com/spiderman-across-spider-verse-concept-art-mayday-india-1849889586">a starring role</a> in <a href="https://gizmodo.com/spider-man-across-the-spider-verse-poster-cameos-1849915317"><em>Spider-Man: Across the Spider-Verse</em></a>. But io9 can exclusively reveal that this summer, Pavitr is getting his own comic…</p><p><a href="https://gizmodo.com/spider-man-india-marvel-comic-across-the-spider-verse-1850156042">Read more...</a></p>

## East Palestine Train Derailment Killed at Least 43,000 Animals
 - [https://gizmodo.com/east-palestine-train-derailment-43-000-dead-animal-fish-1850154433](https://gizmodo.com/east-palestine-train-derailment-43-000-dead-animal-fish-1850154433)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 18:56:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--UTrXgA62--/c_fit,fl_progressive,q_80,w_636/404f43eac2615f1bca8183209263ebb4.jpg" /><p>People in East Palestine, Ohio are still struggling <a href="https://gizmodo.com/health-risks-ohio-train-derailment-vinyl-chloride-1850130109">with uncertainty</a> <a href="https://gizmodo.com/ohio-train-latest-clinic-opens-for-residents-and-epa-d-1850140655">and fear</a> for their health and community in the aftermath of the <a href="https://gizmodo.com/ohio-train-derailment-chemicals-epa-explosion-1850078257">disastrous derailment</a> of a train carrying hazardous chemicals on February 6. This week, the extreme impacts of that spill on local wildlife became  clearer.<br /></p><p><a href="https://gizmodo.com/east-palestine-train-derailment-43-000-dead-animal-fish-1850154433">Read more...</a></p>

## The Best Phones You Can Buy
 - [https://gizmodo.com/the-best-phones-you-can-buy-1830552418](https://gizmodo.com/the-best-phones-you-can-buy-1830552418)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 18:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0GOz_JzG--/c_fit,fl_progressive,q_80,w_636/b5192d2f9957e1c3d86809226a69658b.jpg" /><p><small>Some of our posts include links to retailers. If you buy something from clicking on one, G/O Media may earn a commission. Because editorial staff is independent of commerce, affiliate linking does not influence our editorial content.</small></p><p>The best phone of 2023 might look very different to different people. Some of us are power users, and look for huge screens, fast processors, and tons of memory. Other people want the very best camera so they can share photos on social media. And then there’s the folks who want something simple and cheap that will…</p><p><a href="https://gizmodo.com/the-best-phones-you-can-buy-1830552418">Read more...</a></p>

## The Creators of That 3D-Printed Airless Basketball Can Now Make Custom Helmets That Perfectly Fit Your Head
 - [https://gizmodo.com/3d-printed-hockey-helmet-custom-perfect-fit-eos-1850155860](https://gizmodo.com/3d-printed-hockey-helmet-custom-perfect-fit-eos-1850155860)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 18:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--YX1uceuW--/c_fit,fl_progressive,q_80,w_636/6c024270c3ba80219a64375d85359e84.jpg" /><p>The biggest lie humanity has ever been told is that one size fits all. Every single one of us is different and unique, especially when it comes to the shape and size of our bodies. Bauer, a company that specializes in hockey gear, is finally taking that into account with a <a href="https://www.eos.info/en/presscenter/press-releases/mybauer-reakt-hockey-helmet-digital-foam" rel="noopener noreferrer" target="_blank">new partnership</a> that will allow it  produce…</p><p><a href="https://gizmodo.com/3d-printed-hockey-helmet-custom-perfect-fit-eos-1850155860">Read more...</a></p>

## DJ Right Winger Booted, Facebook Bites Twitter, and Four Day Work Weeks Work | Editor Picks
 - [https://gizmodo.com/dj-right-winger-booted-facebook-bites-twitter-four-da-1850154437](https://gizmodo.com/dj-right-winger-booted-facebook-bites-twitter-four-da-1850154437)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--mCjjBg07--/c_fit,fl_progressive,q_80,w_636/f94e50d56bc483426f7b23d246a1d25e.jpg" /><p><a href="https://gizmodo.com/dj-right-winger-booted-facebook-bites-twitter-four-da-1850154437">Read more...</a></p>

## Mandalorian Creator Jon Favreau Points Fans to YouTube to Catch Up Before Season 3
 - [https://gizmodo.com/mandalorian-season-3-jon-favreau-star-wars-boba-fett-1850155655](https://gizmodo.com/mandalorian-season-3-jon-favreau-star-wars-boba-fett-1850155655)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--M4Uoqrnn--/c_fit,fl_progressive,q_80,w_636/b770da23e10c22bc91138b26d409ce79.jpg" /><p>The mega-hit Star Wars Disney+ series <a href="https://gizmodo.com/mandalorian-season-3-trailer-breakdown-grogu-pedro-pasc-1849995825"><em>The Mandalorian</em> returns next week</a> and some fans might be a little confused when it does. <a href="https://gizmodo.com/the-mandalorians-explosive-finale-blew-our-minds-and-im-1845912360">Season two ended with</a> Grogu leaving the Mandalorian to go train with Luke Skywalker. <a href="https://gizmodo.com/mandalorian-season-3-trailer-baby-yoda-grogu-1849994230">Season three will begin with</a> Grogu already back by the Mandalorian’s side. And while the connective tissue…</p><p><a href="https://gizmodo.com/mandalorian-season-3-jon-favreau-star-wars-boba-fett-1850155655">Read more...</a></p>

## How the War on Terror Set the Stage for Today's Moderation Wars
 - [https://gizmodo.com/war-on-terror-moderation-wars-supreme-court-youtube-1850065691](https://gizmodo.com/war-on-terror-moderation-wars-supreme-court-youtube-1850065691)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 18:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--OCSWeHQD--/c_fit,fl_progressive,q_80,w_636/83440e4e5003ab2240f98fd423717704.jpg" /><p><em>This week, the Supreme Court is hearing two cases that could <a href="https://gizmodo.com/google-supreme-court-gonzalez-section-230-free-speech-1850130340">upend the way</a> we’ve come to understand freedom of speech on the internet. Both <a href="https://law.justia.com/cases/federal/appellate-courts/ca9/18-16700/18-16700-2021-06-22.html" rel="noopener noreferrer" target="_blank">Gonzalez v. Google</a> and <a href="https://www.supremecourt.gov/docket/docketfiles/html/public/21-1496.html" rel="noopener noreferrer" target="_blank">Twitter v. Taamneh</a> ask the court to reconsider how the law interprets Section 230, a regulation that protects companies from legal liability for</em>…</p><p><a href="https://gizmodo.com/war-on-terror-moderation-wars-supreme-court-youtube-1850065691">Read more...</a></p>

## Zuckerberg Introduces Meta’s Answer to ChatGPT, LLaMA
 - [https://gizmodo.com/facebook-chatgpt-google-ai-chatbot-google-bard-1850155514](https://gizmodo.com/facebook-chatgpt-google-ai-chatbot-google-bard-1850155514)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 18:09:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0DuWRoGr--/c_fit,fl_progressive,q_80,w_636/573acff95a104148d9ebf8eefb830f15.jpg" /><p>Move over OpenAI’s <a href="https://gizmodo.com/chat-gpt-openai-ai-finance-ai-everything-we-know-1850018307">ChatGPT</a>, <a href="https://gizmodo.com/google-bard-ai-ad-incorrect-webb-telescope-facts-1850087798">Google’s Bard</a>, and <a href="https://gizmodo.com/bing-ai-chatgpt-microsoft-alter-ego-sydney-dead-1850149974">Microsoft’s Prometheus</a>—there’s yet another large language model-powered artificial intelligence in town. Meta, the company formerly known as Facebook, introduced its own AI today, called LLaMA.<br /></p><p><a href="https://gizmodo.com/facebook-chatgpt-google-ai-chatbot-google-bard-1850155514">Read more...</a></p>

## Ant-Man 3 Writer Talks Its Ending, Avenger Murder, and the Puzzle of Avengers: Kang Dynasty
 - [https://gizmodo.com/avengers-5-writer-ant-man-3-kang-jeff-loveness-marvel-1850151460](https://gizmodo.com/avengers-5-writer-ant-man-3-kang-jeff-loveness-marvel-1850151460)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--QDviPMjy--/c_fit,fl_progressive,q_80,w_636/779d171a4e6a9c3e48389575fdc7f540.jpg" /><p>Right now, if you want to know about Kang’s future in the Marvel Cinematic Universe, the person to talk to is Jeff Loveness. Loveness, best known for his <a href="https://gizmodo.com/rick-and-morty-season-5-recap-adult-swim-justin-roiland-1849424478">work on <em>Rick &amp; Morty</em></a>, not only wrote Marvel’s current hit <a href="https://gizmodo.com/ant-man-3-review-quantumania-paul-rudd-evangeline-lilly-1850083664"><em>Ant-Man and the Wasp: Quantumania</em></a>, he’s also writing <a href="https://gizmodo.com/avengers-kang-dynasty-snags-ant-man-quantumania-writer-1849537343"><em>Avengers: The Kang Dynasty</em></a>, the fifth Avengers film…</p><p><a href="https://gizmodo.com/avengers-5-writer-ant-man-3-kang-jeff-loveness-marvel-1850151460">Read more...</a></p>

## Inaugural Launch of ULA's Vulcan Centaur Rocket Pushed to May
 - [https://gizmodo.com/inaugural-launch-ula-vulcan-centaur-rocket-pushed-may-1850154958](https://gizmodo.com/inaugural-launch-ula-vulcan-centaur-rocket-pushed-may-1850154958)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 17:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--llw_XEjP--/c_fit,fl_progressive,q_80,w_636/8a993db3ac6c4e9aed280d7d01beee0e.jpg" /><p>United Launch Alliance is hoping that the Force will be with them on May 4, a date the company is hoping to launch its Vulcan heavy-lift rocket for the very first time. </p><p><a href="https://gizmodo.com/inaugural-launch-ula-vulcan-centaur-rocket-pushed-may-1850154958">Read more...</a></p>

## But She's Got a New Hat
 - [https://gizmodo.com/pokemon-anime-captain-pikachu-ash-ketchum-2023-1850155106](https://gizmodo.com/pokemon-anime-captain-pikachu-ash-ketchum-2023-1850155106)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--rpiZjOB4--/c_fit,fl_progressive,q_80,w_636/b68386c59968428b14937fc737883dae.png" /><p><a href="https://gizmodo.com/pokemon-anime-ash-retires-new-protagonists-2023-1849903644">Late last year</a>, the Pokémon Company shocked the world with the announcement that Satoshi—better known in the west <a href="https://gizmodo.com/ash-ketchum-pokemon-world-champion-journeys-nintendo-1849770176">as Ash Ketchum</a>—would be bowing out as the enduring star of the long-running <em>Pokémon</em> anime. The company has started rolling out details about the anime’s new heroes... and by revealing that Pokémon could…</p><p><a href="https://gizmodo.com/pokemon-anime-captain-pikachu-ash-ketchum-2023-1850155106">Read more...</a></p>

## 'This Is Harassment': Alex Jones Says the DOJ Wants to Seize His $2,000 Cat
 - [https://gizmodo.com/alex-jones-sandy-hook-info-wars-ragdoll-cat-twitter-1850155315](https://gizmodo.com/alex-jones-sandy-hook-info-wars-ragdoll-cat-twitter-1850155315)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 17:21:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--uorl11pu--/c_fit,fl_progressive,q_80,w_636/8a543e175b8dae23a3c03094e5dc5e6c.png" /><p>The hits keep on coming for <a href="https://gizmodo.com/alex-jones-perjury-sandy-hook-trial-infowars-1849366019">Alex Jones</a>, the disgraced radio host who peddled lies and conspiracy theories on his show <em>Infowars</em> following the Sandy Hook Elementary School shooting. <a href="https://gizmodo.com/alex-jones-infowars-bankruptcy-1849846348">Now having declared bankruptcy</a> following his <a href="https://gizmodo.com/alex-jones-white-supremacy-sandy-hook-infowars-1849177759">repeated</a> <a href="https://gizmodo.com/alex-jones-infowars-sandy-hook-trial-1849530310">trials</a> for his misinformation about the mass shooting, Jones is sounding the alarm…</p><p><a href="https://gizmodo.com/alex-jones-sandy-hook-info-wars-ragdoll-cat-twitter-1850155315">Read more...</a></p>

## How the Ant-Man and the Wasp: Quantumania Post-Credits Scene Was Created
 - [https://gizmodo.com/ant-man-3-spoilers-post-credits-peyton-reed-kang-marvel-1850115572](https://gizmodo.com/ant-man-3-spoilers-post-credits-peyton-reed-kang-marvel-1850115572)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--E9DZdiJC--/c_fit,fl_progressive,q_80,w_636/e283d9264d77d146223ac720a3d88e68.jpg" /><p>No matter what you may have thought of <a href="https://gizmodo.com/ant-man-3-review-quantumania-paul-rudd-evangeline-lilly-1850083664"><em>Ant-Man and the Wasp: Quantumania</em></a>, you have to admit <a href="https://gizmodo.com/ant-man-quantumania-end-credits-explained-kang-loki-mcu-1850115422">the first end-credit scene</a>, in particular, was awesome. It beautifully put into motion <a href="https://gizmodo.com/ant-man-and-wasp-quantumania-spoilers-marvel-studios-1850115090">not just the future of</a> the Marvel Cinematic Universe, but tied up a few loose ends that had been set up in the film itself. When both of…</p><p><a href="https://gizmodo.com/ant-man-3-spoilers-post-credits-peyton-reed-kang-marvel-1850115572">Read more...</a></p>

## Uh-Oh: Feds Say Google 'Systematically Destroyed' Evidence for Years by Auto-Deleting Employee Chats
 - [https://gizmodo.com/google-employee-chats-deleted-evidence-justice-dept-1850155340](https://gizmodo.com/google-employee-chats-deleted-evidence-justice-dept-1850155340)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 16:45:19+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--yiZkcPoi--/c_fit,fl_progressive,q_80,w_636/6f6016bac8f03f626aecb573a5e3ebc0.jpg" /><p>Google’s reliance on commonly used messaging systems that automatically delete conversations after a day has landed the company in hot water with the Department of Justice.</p><p><a href="https://gizmodo.com/google-employee-chats-deleted-evidence-justice-dept-1850155340">Read more...</a></p>

## Peter Jackson Is 'In the Loop' On Those New Lord of the Rings Movie Plans
 - [https://gizmodo.com/peter-jackson-lord-of-the-rings-return-warner-bros-1850154871](https://gizmodo.com/peter-jackson-lord-of-the-rings-return-warner-bros-1850154871)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--tH1Qq5vd--/c_fit,fl_progressive,q_80,w_636/b979104b45ae324e58343ede066c2914.jpg" /><p>Last night when more <a href="https://gizmodo.com/lord-of-the-rings-movies-new-more-warner-bros-1850152138"><em>Lord of the Rings</em></a> movies were announced, everyone was deeply interested in what they could possibly be planning. After the beloved trilogy of films in the early 2000s and the less-than-beloved <a href="https://gizmodo.com/i-tried-giving-the-hobbit-trilogy-a-chance-but-it-just-1829119137">Hobbit trilogy,</a> what more can be done? (Well, there’s <a href="https://gizmodo.com/the-lord-of-the-rings-war-of-the-rohirrim-anime-rides-1848536439"><em>War of the Rohirrim</em></a>, but still!)<br /></p><p><a href="https://gizmodo.com/peter-jackson-lord-of-the-rings-return-warner-bros-1850154871">Read more...</a></p>

## TikTok Complains It's 'Under a Cloud' Following Its Most Recent Ban
 - [https://gizmodo.com/tiktok-tiktok-ban-eu-social-media-bytedance-china-1850154826](https://gizmodo.com/tiktok-tiktok-ban-eu-social-media-bytedance-china-1850154826)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 16:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--9fYlOS1W--/c_fit,fl_progressive,q_80,w_636/9b0529b121805bd021457aca030ab8e9.jpg" /><p><a href="https://gizmodo.com/tiktok-bans-are-dumb-1849958652">TikTok</a> is pushing back against the European Union for not informing the company that they were banning the app on all government devices. The EU also took steps to ban the Chinese-owned app on staff’s personal devices with corporate access, amid concerns that TikTok’s parent company <a href="https://gizmodo.com/tiktok-bytedance-track-americans-locations-forbes-data-1849687337">ByteDance is accessing user data.</a></p><p><a href="https://gizmodo.com/tiktok-tiktok-ban-eu-social-media-bytedance-china-1850154826">Read more...</a></p>

## Cupcakes and Passion Open a Gateway to Horror in Delilah S. Dawson's Bloom
 - [https://gizmodo.com/delilah-s-dawson-excerpt-new-novella-bloom-lbgtq-horro-1850145280](https://gizmodo.com/delilah-s-dawson-excerpt-new-novella-bloom-lbgtq-horro-1850145280)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s---LcOq-VF--/c_fit,fl_progressive,q_80,w_636/e1e71fa8d2782621656445601396f769.png" /><p>io9 has shared the work of Delilah S. Dawson before (check out <a href="https://gizmodo.com/delilah-s-dawsons-the-violence-first-look-a-terrifyin-1846869758">an excerpt</a> from her 2021 dystopian thriller <em>The Violence</em>), and we’ve got another <a href="https://gizmodo.com/stephen-graham-jones-book-interview-horror-reaper-1849951288">unsettling</a> exclusive for you today: a first look at <em>Bloom</em>, the tale of <a href="https://gizmodo.com/freya-marske-a-restless-truth-lesbian-romance-fantasy-1849686422">two women</a> whose powerful attraction evolves into something that’s supernaturally toxic.<br /></p><p><a href="https://gizmodo.com/delilah-s-dawson-excerpt-new-novella-bloom-lbgtq-horro-1850145280">Read more...</a></p>

## 11-Year-Old Girl Dies of Bird Flu as Officials Investigate Potential Spread
 - [https://gizmodo.com/cambodia-girl-bird-flu-death-h5n1-who-1850154892](https://gizmodo.com/cambodia-girl-bird-flu-death-h5n1-who-1850154892)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 15:57:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--IVDsd542--/c_fit,fl_progressive,q_80,w_636/032ff63d29caac835bb2e8f6c0bd8f42.jpg" /><p>An 11-year-old girl in Cambodia has reportedly died after contracting H5N1 avian influenza, also known as bird flu, while her father has also tested positive for the virus. It appears to be the second confirmed human death linked to a surge in cases among birds and mammals since 2020, and this is the first documented…</p><p><a href="https://gizmodo.com/cambodia-girl-bird-flu-death-h5n1-who-1850154892">Read more...</a></p>

## The Motorola Defy Brings Two-Way Satellite Messaging to iPhones and Androids
 - [https://gizmodo.com/motorola-defy-satellite-messaging-iphone-android-ios-1850154912](https://gizmodo.com/motorola-defy-satellite-messaging-iphone-android-ios-1850154912)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 15:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--rPHzN6SD--/c_fit,fl_progressive,q_80,w_636/85fefe20bab44d51d86d80f94796f0b3.jpg" /><p>As Apple continues to position its phones and watches as life-saving devices, the most compelling reason to upgrade to the iPhone 14 or 14 Pro is the <a href="https://gizmodo.com/what-its-like-to-use-apples-emergency-sos-feature-1849782706">Emergency SOS service</a> that uses satellite communications when wifi or cellular are MIA. It’s not a feature that’s coming to older iPhones, however, so for those not…</p><p><a href="https://gizmodo.com/motorola-defy-satellite-messaging-iphone-android-ios-1850154912">Read more...</a></p>

## Take a Shot, Apple's AR/VR Headset Just Got Delayed Again
 - [https://gizmodo.com/apple-ar-vr-headset-mixed-reality-delay-supply-chain-ku-1850154604](https://gizmodo.com/apple-ar-vr-headset-mixed-reality-delay-supply-chain-ku-1850154604)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 15:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0cSBlmzO--/c_fit,fl_progressive,q_80,w_636/893a4e1b1cb82dec4107658e9679b43f.jpg" /><p>The saga of Apple’s supposed mixed reality headset is starting to feel more like a ‘90s sitcom than a major tech release. Every time there’s a new episode, there’s a promise of real change to our beloved characters, and by the end of the episode it’s all undone. We return to where we began, and it starts all over…</p><p><a href="https://gizmodo.com/apple-ar-vr-headset-mixed-reality-delay-supply-chain-ku-1850154604">Read more...</a></p>

## Updates From Attack on Titan's Finale, and More
 - [https://gizmodo.com/attack-on-titan-final-episodes-bts-images-snk-1850151724](https://gizmodo.com/attack-on-titan-final-episodes-bts-images-snk-1850151724)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--qTprHldq--/c_fit,fl_progressive,q_80,w_636/b3d2f7183b45bb3258cfb267412515b4.png" /><p>New <em>Teenage Mutant Ninja Turtles</em> toys tease the mutants of <em>Mutant Mayhem</em>. <em>Shazam: Fury of the Gods</em> gets a bumper runtime. Plus, what’s coming on <em>Kung Fu</em> and <em>La Brea</em>’s season finale. To me, my spoilers!<br /></p><p><a href="https://gizmodo.com/attack-on-titan-final-episodes-bts-images-snk-1850151724">Read more...</a></p>

## Why a California Beach Town Just Banned Balloons
 - [https://gizmodo.com/why-a-california-beach-town-just-banned-balloons-1850154368](https://gizmodo.com/why-a-california-beach-town-just-banned-balloons-1850154368)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 13:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ExmvehTU--/c_fit,fl_progressive,q_80,w_636/c83c267c2611e17c684b2401a57619fe.jpg" /><p><em>This story was originally published by <a href="https://grist.org/" rel="noopener noreferrer" target="_blank">Grist</a>. You can <a href="https://go.grist.org/signup/weekly?utm_campaign=signup-page&amp;utm_medium=web&amp;utm_source=grist&amp;utm_content=weekly" rel="noopener noreferrer" target="_blank">subscribe to its weekly newsletter here</a>.<br /></em></p><p><a href="https://gizmodo.com/why-a-california-beach-town-just-banned-balloons-1850154368">Read more...</a></p>

## Meta Is Making It Harder to Wind Up in Facebook Jail
 - [https://gizmodo.com/facebook-jail-meta-relaxes-suspensions-1850152053](https://gizmodo.com/facebook-jail-meta-relaxes-suspensions-1850152053)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 11:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--sHrXQ97s--/c_fit,fl_progressive,q_80,w_636/74597d3cea53fdbe510aa848bb63dd3e.jpg" /><p>Facebook jail is about to get less crowded. Under a new set of policies revealed this Thursday, parent company Meta says it’s now harder for users to wind up with their Facebook accounts suspended for lesser violations of its rules. Those changes come after years of pushback from civil society groups and Meta’s…</p><p><a href="https://gizmodo.com/facebook-jail-meta-relaxes-suspensions-1850152053">Read more...</a></p>

## An AI-Illustrated Comic Has Lost a Key Copyright Case
 - [https://gizmodo.com/zarya-of-the-dawn-midjourney-comic-ai-art-copyright-1850149833](https://gizmodo.com/zarya-of-the-dawn-midjourney-comic-ai-art-copyright-1850149833)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-02-24 00:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--9Y_jCSDQ--/c_fit,fl_progressive,q_80,w_636/7ea4c1ea9ee79cf22f1e21e1ef79ab75.jpg" /><p>When Kris Kashtanova attempted to copyright their comic book <em>Zarya of the Dawn</em>, the United States Copyright Office originally granted them the rights. Later, the agency put the book under review because of Kashtanova’s social media, where they said that they had produced the <a href="https://gizmodo.com/ai-art-generator-midjourney-starry-ai-1849397263">images</a> using the <a href="https://gizmodo.com/ai-art-shutterstock-getty-fur-infinity-1849574917">AI-image generator</a> <a href="https://gizmodo.com/ai-chatgpt-dalle-midjourney-stable-diffusion-deepfake-1849910573">…</a></p><p><a href="https://gizmodo.com/zarya-of-the-dawn-midjourney-comic-ai-art-copyright-1850149833">Read more...</a></p>

