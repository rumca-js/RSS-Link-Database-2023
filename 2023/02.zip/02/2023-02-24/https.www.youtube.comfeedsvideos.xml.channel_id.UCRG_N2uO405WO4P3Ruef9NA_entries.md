# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## New Spotify AI, Notion AI, Skype AI & more!
 - [https://www.youtube.com/watch?v=01LNXQSrMco](https://www.youtube.com/watch?v=01LNXQSrMco)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2023-02-24 16:49:41+00:00

Get Nebula using my link for 40% off an annual subscription: https://go.nebula.tv/tfc

Podcast:
Nebula video (live now!): https://nebula.tv/chillout
Nebula audio (live now!):  https://nebula.tv/chilloutpod
Everywhere else (live on Saturdays, audio-only): https://art19.com/shows/the-friday-chillout
Pro tip: as a Nebula subscriber you can copy the RSS link of the Nebula audio podcast and paste it in most podcast players to play it from there!


 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  

This week we got Spotify AI DJ, Notion AI, Skype AI, Baidu AI, and more. AI everywhere! Then, Mercedes launched the e-class interior with a camera for Tiktok and zoom. And leaked iPhone 15 CAD files show USB-C, but with artificial limitations.

Episode 136
 
This video on Nebula: https://nebula.tv/videos/tfc-these-ai-tools-are-getting-crazy-good

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄  
 
Social media:  
https://mas.to/@techaltar
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  
 
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
►►► Attributions & Time stamps◄◄◄
 
Writing & Research: Tristan Rayner
Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:20 The Brief
2:25 AI everywhere
5:11 Mercedes gets TikTok camera
6:47 iPhone 15 to get "locked down" USB C

