# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Meet the International Legion, a band of foreign fighters bolstering Ukraine's forces
 - [https://www.cnn.com/2023/02/23/europe/ukraine-foreign-fighters-vuhledar-donbas-intl/index.html](https://www.cnn.com/2023/02/23/europe/ukraine-foreign-fighters-vuhledar-donbas-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-02-24 03:02:02+00:00

Under a blanket of stars, the only sound in the air is the deep hum of a pick-up truck, its headlights off. Fumes chug into frigid air from the exhaust. Only the taillights reveal the vehicle's outline; the remotest sliver of light could spell disaster this close to the frontline.

## Peru offers $13,000 to families who lost loved ones in protests
 - [https://www.cnn.com/2023/02/23/americas/peru-protest-financial-support-deaths-intl-latam/index.html](https://www.cnn.com/2023/02/23/americas/peru-protest-financial-support-deaths-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-02-24 00:03:00+00:00

Peru's government is offering families who lost a relative during nationwide protests between December 8 and February 10 around $13,000 in financial support, according to a decree published by the official newspaper "El Peruano" on Tuesday.

