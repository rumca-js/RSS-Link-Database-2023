# Source:Captain Midnight, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCROQqK3_z79JuTetNP3pIXQ, language:en-US

## Marvel Phase 5 Needs Better Than Ant-Man and the Wasp: Quantumania
 - [https://www.youtube.com/watch?v=-p7FSudLMHU](https://www.youtube.com/watch?v=-p7FSudLMHU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCROQqK3_z79JuTetNP3pIXQ
 - date published: 2023-02-24 23:58:32+00:00

This video was sponsored by Nordpass. Get one month free at https://nordpass.com/captainmidnightnordpass and use code "captainmidnightnordpass"
Ant-Man and the Wasp: Quantumania is the start of the MCU's new Phase 5...and it's not the most promising start. In this video, I break down what I like here and what I don't.
Music by Epidemic Sound (http://www.epidemicsound.com)
Follow me on Twitter: https://twitter.com/midnightcap
Follow me on Facebook: https://www.facebook.com/midnightcap
Special thanks to Andrew Elliott (Stalli111: https://www.youtube.com/user/Stalli111  ) for editing this video!

