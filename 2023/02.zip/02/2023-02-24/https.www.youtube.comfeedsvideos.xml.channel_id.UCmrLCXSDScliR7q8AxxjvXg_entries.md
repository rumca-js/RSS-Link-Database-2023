# Source:Black Pidgeon Speaks, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmrLCXSDScliR7q8AxxjvXg, language:en-US

## Till the Last Ukrainian: The Documentary
 - [https://www.youtube.com/watch?v=2vB6fAEQbpo](https://www.youtube.com/watch?v=2vB6fAEQbpo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmrLCXSDScliR7q8AxxjvXg
 - date published: 2023-02-24 14:23:39+00:00

I have been demonetized since 2018. If you think this kind or work resonates with you, please consider supporting this channel. Ways to do so are listed below:

✅ Support Directly: https://felixrex.net/membership-tiers/
✅ Support via SubscribeStar: https://www.subscribestar.com/black-pigeon-speaks
✅ Support via Locals: https://felixrex.locals.com
✅ Tip Jar: via PayPal to: navyhato@gmail.com

-------------------------------
⭐ Get BPS Stuff in Worldwide (Both North America, Europe and Worldwide): 
https://teespring.com/en-GB/stores/bps-north-america

🔵BTC (Bitcoin)
3NiWatW8cAdGQChcbL9tCickW9JvouTs3L
🔵BCH (Bitcoin Cash)
35GrMSvJHHQ5DvCcNfJNe6Pj46w6HbckoF
🔵LTC (Litecoin)
MLbo7xkPJjRX9wFYxHG9YajWwbB14rmpJx

-------------------------------

✅ Your SUPPORT of this Channel is GREATLY appreciated.
-------------------------------
🔴 All Social Media can be found at this link: linktr.ee/felixrex
🔴 Telegram: https://t.me/felixrex
🔴 Dlive Livestreaming: https://dlive.tv/Felix_Rex
🔴 Trovo Livestreaming: https://trovo.live/FelixRex
🔴 Rumble: https://rumble.com/user/FelixRex
🔴 Felix Rex Odysee: https://odysee.com/@felixrex:2
🔴 BPS Odysee: https://odysee.com/@BlackPigeonSpeaks:c
🔴 2nd Channel BPS: https://tinyurl.com/vbnywcw
🔴 BitChute: https://www.bitchute.com/profile/bBzmz0SCxhFG/
🔴 Gab: https://gab.ai/blackpigeon
🔴 Minds: https://www.minds.com/blackpigeonspeaks
🔴 Facebook: https://www.facebook.com/blackpigeonspeaks
🔴 Twitter: https://twitter.com/navyhato
🔴 Instagram: https://www.instagram.com/blackpigeonspeaks
🔴 Parler: https://parler.com/profile/FelixRex/posts
🔴 Lbry for Felix Rex: https://lbry.tv/@felixrex:2
🔴 Lbry for Black Pigeon: https://lbry.tv/@BlackPigeonSpeaks:c
🔴 DailyMotion: http://www.dailymotion.com/blackpigeonspeaks
🔴 Vomvos: shorturl.at/nstxI:
🔴 Related Channels

▶️ Black Pigeon Speaks: https://www.youtube.com/channel/UCmrLCXSDScliR7q8AxxjvXg
▶️ Felix Rex: https://www.youtube.com/user/TVShinjuku
-------------------------------
✅ Notes for this video: 


✅ Amazing Video Editor Materials can be found at:
http://www.digitaljuice.com/Intl

#FelixRex #BlackPigeonSpeaks

