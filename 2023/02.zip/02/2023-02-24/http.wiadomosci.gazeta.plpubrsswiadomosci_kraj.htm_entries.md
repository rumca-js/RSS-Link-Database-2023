# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Polska wyraziła zgodę na 10. pakiet sankcji wobec Rosji. Ale zgoda jest warunkowa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29501526,polska-wyrazila-zgode-na-10-pakiet-sankcji-wobec-rosji-ale.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29501526,polska-wyrazila-zgode-na-10-pakiet-sankcji-wobec-rosji-ale.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 20:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/72/22/1c/z29501554M,Mateusz-Morawiecki-i-Wolodymyr-Zelenski.jpg" vspace="2" />Polska wyraziła zgodę na przyjęcie dziesiątego pakietu sankcji Unii Europejskiej wobec Rosji - przekazał ambasador Andrzej Sadoś. Jak dodał, zgoda jest warunkowa.

## Szczecin. CBA weszło do gabinetu ginekologicznego. Zabrało dokumentację pacjentek z 30 lat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29499880,szczecin-cba-weszlo-do-gabinetu-ginekologicznego-zabralo-dokumentacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29499880,szczecin-cba-weszlo-do-gabinetu-ginekologicznego-zabralo-dokumentacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 16:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e4/1f/1c/z29490660M,Z-gabinetu-ginekologicznego-dr-Marii-Kubisy-agenci.jpg" vspace="2" />Agenci Centralnego Biura Antykorupcyjnego weszli do gabinetu ginekologicznego dr n. med. Marii Kubisy w Szczecinie. Na polecenie prokuratury zabrali stamtąd karty medyczne pacjentek z niemal 30 lat - podaje "Gazeta Wyborcza". - Moimi pacjentkami są również prokuratorki, policjantki, agentki CBA, kobiety, które są sędziami. I co? Prokurator będzie teraz to wszystko czytał? - pyta lekarka.

## Wypadek po zajęciach strzeleckich na poligonie. Ranni żołnierze GROM, jeden w stanie ciężkim
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29500297,mazowsze-wypadek-na-poligonie-ranni-zolnierze-grom-jeden.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29500297,mazowsze-wypadek-na-poligonie-ranni-zolnierze-grom-jeden.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 15:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />"Na poligonie jednostki GROM w Rembertowie doszło w czwartek do bardzo poważnego wypadku, w którym ucierpiało dwóch żołnierzy" - podaje Onet.

## 21-latka uważała, że może być zaginioną Madeleine McCann. To nie pierwszy taki przypadek w Polsce
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29499594,21-latka-uwazala-ze-moze-byc-zaginiona-madeleine-mccann-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29499594,21-latka-uwazala-ze-moze-byc-zaginiona-madeleine-mccann-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 14:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/13/20/1c/z29493779M,Madeleine-McCann.jpg" vspace="2" />Media w Polsce i na świecie informowały w ostatnich dniach o 21-letniej Polce, która twierdziła w mediach społecznościowych, że może być zaginioną w 2007 r. w Portugalii Madeleine McCann. Polska policja wykluczyła jednoznacznie tę wersję. Do Fundacji ITAKA, zajmującej się poszukiwaniami zaginionych, podobne zgłoszenia dotyczące spraw zaginionych dzieci trafiają raz na kilka lat.

## Rosyjscy dyplomaci w Warszawie obudzeni dźwiękami wybuchów i syren alarmowych [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29497918,rosyjscy-dyplomaci-obudzeni-dzwiekami-wybuchow-i-syren-alarmowych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29497918,rosyjscy-dyplomaci-obudzeni-dzwiekami-wybuchow-i-syren-alarmowych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 10:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6c/21/1c/z29498220M,Protest-przed-budynkiem--w-ktorym-mieszkaja-rosyjs.jpg" vspace="2" />Przy ulicy Beethovena 3 w Warszawie, przed budynkiem, w którym mieszkają rosyjscy dyplomaci, odbył się w piątek happening. Z okazji rocznicy inwazji Rosji na Ukrainę protestujący przeciwko wojnie postanowili sprawić, by przebywający w środku urzędnicy usłyszeli odgłosy, które stały się codziennością dla Ukraińców.

## Rada programowa TVP o "skandalicznej" piosence na Eurowizję 2023. "Dupa, dupa, dupa, dupa, dupa"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29497955,rada-programowa-tvp-o-skandalicznej-piosence-na-eurowizje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29497955,rada-programowa-tvp-o-skandalicznej-piosence-na-eurowizje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 09:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fe/85/18/z25712894M,Studio-telewizyjne--Zdjecie-ilustracyjne.jpg" vspace="2" />Rada programowa TVP uważa, że "skandalicznym niedopatrzeniem" jest dopuszczenie do konkursu piosenki "Booty" autorstwa Ahleny. - To jest po prostu piosenka o dupie, co tu dużo kryć. Skandal - mówił po czwartkowym posiedzeniu rady Janusz Daszczyński.

## Na granicy z Rosją pojawiły się "prewencyjne zabezpieczenia". "Mariusz, chcesz, żeby umarli ze śmiechu?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29497619,na-granicy-z-rosja-pojawily-sie-prewencyjne-zabezpieczenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29497619,na-granicy-z-rosja-pojawily-sie-prewencyjne-zabezpieczenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 08:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/21/1c/z29497745M,Zapory-na-granicy-z-Rosja-i-Bialorusia.jpg" vspace="2" />Minister obrony Mariusz Błaszczak udostępnił zdjęcia "prewencyjnych zabezpieczeń" na granicy z Rosją i Białorusią. Szef polskiego MON przekazał, że jest to element strategii "obrony i odstraszania". "W dobie myśliwców, rakiet i dronów odwalacie rekonstrukcje plaży w Normandii" - komentują użytkownicy mediów społecznościowych.

## Bruno wyjechał w podróż życia do Indii. Zaginął w dolinie śmierci. "Mówią, że ona zjada ludzi"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29497120,bruno-wyjechal-w-podroz-zycia-do-indii-zaginal-w-dolinie-smierci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29497120,bruno-wyjechal-w-podroz-zycia-do-indii-zaginal-w-dolinie-smierci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 06:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/51/21/1c/z29497169M,Zaginiony-Bruno-Muschalik.jpg" vspace="2" />24-letni Bruno Muschalik wybrał się w trzytygodniową podróż do Indii. Codziennie kontaktował się z rodziną i dziewczyną, opowiadając, co zwiedził i gdzie planuje wyruszyć kolejnego dnia. Tak było aż do momentu, gdy postanowił wybrać się do doliny Parvati - zwanej doliną śmierci czy indyjskim trójkątem bermudzkim. Jak się okazuje, w ostatnich latach w tajemniczych okolicznościach zaginęło tam dużo zagranicznych turystów. - Nic, co trafia do Parvati, nigdy nie wraca - dodaje Manu Mahajan, alpinista należący do Himalajskiej Misji Ratowniczej.

## Gazeta.pl rozmawia z Ukraińcami na granicy. "Nie mogę się przyzwyczaić do Polski"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29492413,gazeta-pl-rozmawia-z-ukraincami-na-granicy-nie-moge-sie-przyzwyczaic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29492413,gazeta-pl-rozmawia-z-ukraincami-na-granicy-nie-moge-sie-przyzwyczaic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 05:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/68/20/1c/z29493864M,Rozmawialismy-z-Ukrainkami-i-Ukraincami-na-dworcu-.jpg" vspace="2" />Minął rok od rosyjskiej agresji na Ukrainę, eskalacji wojny na cały kraj naszych wschodnich sąsiadów. Gazeta.pl porozmawiała z Ukrainkami i Ukraińcami w Przemyślu oraz na granicy. Pytaliśmy, jakie są ich największe obawy, jak wygląda teraz ich życie i co planują.

## Gazeta.pl w Przemyślu. "Wcale nie chcieli jechać do Polski. Nie chcą być ciężarem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29492398,gazeta-pl-w-przemyslu-wcale-nie-chcieli-jechac-do-polski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29492398,gazeta-pl-w-przemyslu-wcale-nie-chcieli-jechac-do-polski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 05:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/20/1c/z29493849M,Rozmawialismy-z-wolontariuszami-na-dworcu-w-Przemy.jpg" vspace="2" />Minął rok od eskalacji rosyjskiej agresji na Ukrainę. Gazeta.pl pojechała do Przemyśla, aby porozmawiać z wolontariuszami i dowiedzieć się, jak duży ruch migracyjny panuje na granicy z Ukrainą.

## Prowadził sprawę Madeleine McCann. Zabrał głos ws. Julii W. i danych biometrycznych zaginionej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29496857,prowadzil-sprawe-madeleine-mccann-zabral-glos-ws-julii-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29496857,prowadzil-sprawe-madeleine-mccann-zabral-glos-ws-julii-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 05:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fe/20/1c/z29493758M,Madeleine-McCann--Polka-twierdzi--ze-moze-byc-zagi.jpg" vspace="2" />- Myślę, że to oszustwo, ale nie mogę tego mówić bez dowodów - powiedział były śledczy, który prowadził sprawę zniknięcia Madeleine McCann. Jak dodał, przeszukał dane biometryczne i wątpi w to, że 21-letnia Polka jest zaginioną dziewczynką.

## Nadchodzi załamanie pogody. Lokalnie śnieżyce i opady marznące, temperatura do -10 stopni
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29496658,nadchodzi-zalamanie-pogody-lokalnie-sniezyce-i-opady-marznace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29496658,nadchodzi-zalamanie-pogody-lokalnie-sniezyce-i-opady-marznace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-24 04:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/21/21/1c/z29497121M,Pogoda-w-Polsce.jpg" vspace="2" />Za nami kilka dni łagodniejszej pogody. Stan ten nie będzie jednak trwał wiecznie, bo nad Polskę nadciąga właśnie gruntowne ochłodzenie. Spadek temperatury na powrót przywoła zimę, a lokalne śnieżyce mogą okazać się niezwykle intensywne.

