# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## The Street Fighter 6 trailers are getting me hyped to once again pretend I'm finally going to get good at Street Fighter
 - [https://www.pcgamer.com/street-fighter-6-cammy-zangief-lily](https://www.pcgamer.com/street-fighter-6-cammy-zangief-lily)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 23:51:03+00:00

The final character reveal shows us Cammy, Zangief, and newcomer Lily, all of whom I will be bad with.

## How to befriend Virginia in Sons of the Forest
 - [https://www.pcgamer.com/sons-of-the-forest-virginia](https://www.pcgamer.com/sons-of-the-forest-virginia)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 23:30:00+00:00

In a world that wants to kill you, Virginia is a helping hand.

## I tried the 'world's first crypto-backed energy drink,' and it tastes like it was secreted from the blockchain
 - [https://www.pcgamer.com/i-tried-the-worlds-first-crypto-backed-energy-drink-and-it-tastes-like-it-was-secreted-from-the-blockchain](https://www.pcgamer.com/i-tried-the-worlds-first-crypto-backed-energy-drink-and-it-tastes-like-it-was-secreted-from-the-blockchain)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 22:48:11+00:00

Despite all the passive income opportunities, I will pass on "FOMO Fuel."

## The new best boy of videogames is Kelvin in Sons of the Forest
 - [https://www.pcgamer.com/the-new-best-boy-of-videogames-is-kelvin-in-sons-of-the-forest](https://www.pcgamer.com/the-new-best-boy-of-videogames-is-kelvin-in-sons-of-the-forest)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 22:29:49+00:00

The single best thing about Sons of the Forest is my new NPC helper.

## Baldur's Gate 3 increases system requirements 'to better reflect the realities of the launch version'
 - [https://www.pcgamer.com/baldurs-gate-3-increases-system-requirements-to-better-reflect-the-realities-of-the-launch-version](https://www.pcgamer.com/baldurs-gate-3-increases-system-requirements-to-better-reflect-the-realities-of-the-launch-version)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 22:12:13+00:00

It's been four years since Baldur's Gate 3 was announced, and a lot has changed.

## Dark and Darker will hold one more playtest in April
 - [https://www.pcgamer.com/dark-and-darker-will-hold-one-more-playtest-in-april](https://www.pcgamer.com/dark-and-darker-will-hold-one-more-playtest-in-april)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 21:52:01+00:00

Developer Ironmace wants a little more shakedown time before Dark and Darker launches into early access.

## The secret to Elden Ring's open world success is uncopyable
 - [https://www.pcgamer.com/the-secret-to-elden-rings-open-world-success-is-uncopyable](https://www.pcgamer.com/the-secret-to-elden-rings-open-world-success-is-uncopyable)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 20:18:02+00:00

Don't expect big budget games to try to mimic Elden Ring, because they can't copy what made it a phenomenon.

## Where to find the rope gun for the zipline in Sons of the Forest
 - [https://www.pcgamer.com/sons-of-the-forest-rope-gun-zipline-location](https://www.pcgamer.com/sons-of-the-forest-rope-gun-zipline-location)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 20:05:44+00:00

The rope gun is the tool you'll need to grab if you want to zipline your way to that shovel.

## Where to find the rebreather in Sons of the Forest
 - [https://www.pcgamer.com/sons-of-the-forest-rebreather-location](https://www.pcgamer.com/sons-of-the-forest-rebreather-location)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 20:00:52+00:00

The rebreather is pretty easy to snatch early on in Sons of the Forest if you know which cave to look in.

## Hogwarts Legacy players have murdered more than 1 billion Dark Wizards
 - [https://www.pcgamer.com/hogwarts-legacy-players-have-murdered-more-than-1-billion-dark-wizards](https://www.pcgamer.com/hogwarts-legacy-players-have-murdered-more-than-1-billion-dark-wizards)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 19:19:13+00:00

The game about teenagers learning magic at a 19th-century wizard school is a big hit—and seriously bloody.

## Superheroes and live service is a dreadful combination
 - [https://www.pcgamer.com/superheroes-and-live-service-is-a-dreadful-combination](https://www.pcgamer.com/superheroes-and-live-service-is-a-dreadful-combination)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 18:21:27+00:00

Developers I am begging you, stop trying to make this happen.

## I accidentally turned on big head mode in Sons of the Forest and now I'm scarred for life
 - [https://www.pcgamer.com/i-accidentally-turned-on-big-head-mode-in-sons-of-the-forest-and-now-im-scarred-for-life](https://www.pcgamer.com/i-accidentally-turned-on-big-head-mode-in-sons-of-the-forest-and-now-im-scarred-for-life)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 17:20:54+00:00

Go big or go home (I'm going home).

## The Day Before's calendar app nemesis confirms it owns disputed copyright, would like you to know it's been around for 13 years
 - [https://www.pcgamer.com/the-day-befores-calendar-app-nemesis-confirms-it-owns-disputed-copyright-would-like-you-to-know-its-been-around-for-13-years](https://www.pcgamer.com/the-day-befores-calendar-app-nemesis-confirms-it-owns-disputed-copyright-would-like-you-to-know-its-been-around-for-13-years)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 17:05:47+00:00

TheDayBefore wants The Day Before to know TheDayBefore owns 'The Day Before'.

## Elden Ring and God of War: Ragnarok win big at the DICE Awards
 - [https://www.pcgamer.com/dice-award-winners-2022](https://www.pcgamer.com/dice-award-winners-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 16:31:18+00:00

Vampire Survivors claimed a title, too.

## Mini LED gaming monitors are a bad idea in theory and in practice they're even worse
 - [https://www.pcgamer.com/mini-led-gaming-monitors-are-a-bad-idea-in-theory-and-in-practice-theyre-even-worse](https://www.pcgamer.com/mini-led-gaming-monitors-are-a-bad-idea-in-theory-and-in-practice-theyre-even-worse)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 15:45:14+00:00

Don't be fooled, this is not the high-end screen tech we've been waiting for.

## iBUYPOWER celebrates the launch of the HYTE Y40 Case with two new RDY systems
 - [https://www.pcgamer.com/ibuypower-celebrates-the-launch-of-the-hyte-y40-case-with-two-new-rdy-systems](https://www.pcgamer.com/ibuypower-celebrates-the-launch-of-the-hyte-y40-case-with-two-new-rdy-systems)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 14:00:20+00:00

If you're thinking of celebrating the new year with an upgrade, we've got good news. High-end PC vendor iBUYPOWER rang in 2023 with not one, but two new additions to its product selection, both featuring the recently-released HYTE Y40 Case—the Gaming RDY Y40BG202 and the Creator RDY Y40BG201.

## I invited strangers into my home to try a VR treadmill. I survived, and they absolutely loved it
 - [https://www.pcgamer.com/i-invited-strangers-into-my-home-to-try-a-vr-treadmill-i-survived-and-they-absolutely-loved-it](https://www.pcgamer.com/i-invited-strangers-into-my-home-to-try-a-vr-treadmill-i-survived-and-they-absolutely-loved-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 13:59:44+00:00

"Where was this when VR came out!"

## Where to find the shovel in Sons of the Forest
 - [https://www.pcgamer.com/sons-of-the-forest-shovel-location](https://www.pcgamer.com/sons-of-the-forest-shovel-location)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 13:33:07+00:00

Make sure you're prepared.

## I'm excited that BioWare is 'trying something new' with Dragon Age: Dreadwolf, but for the love of god actually tell us something
 - [https://www.pcgamer.com/im-excited-that-bioware-is-trying-something-new-with-dragon-age-dreadwolf-but-for-the-love-of-god-actually-tell-us-something](https://www.pcgamer.com/im-excited-that-bioware-is-trying-something-new-with-dragon-age-dreadwolf-but-for-the-love-of-god-actually-tell-us-something)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 13:32:13+00:00

The latest developer blog is more a lesson in game design than a meaningful update.

## That postmodern Lemmings-like where a Shiba Inu saves humanity is getting a PC version and a limited-time demo
 - [https://www.pcgamer.com/that-postmodern-lemmings-like-where-a-shiba-inu-saves-humanity-is-getting-a-pc-version-and-a-limited-time-demo](https://www.pcgamer.com/that-postmodern-lemmings-like-where-a-shiba-inu-saves-humanity-is-getting-a-pc-version-and-a-limited-time-demo)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 13:18:17+00:00

You've got a little over a week to get some hands-on time with Humanity.

## John Romero honoured alongside the teacher who made world's first edutainment game
 - [https://www.pcgamer.com/john-romero-honoured-alongside-the-teacher-who-made-worlds-first-edutainment-game](https://www.pcgamer.com/john-romero-honoured-alongside-the-teacher-who-made-worlds-first-edutainment-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 11:58:33+00:00

I can't believe 1964's Sumerian Game hasn't gotten a remaster.

## The best Alien game that isn't an Alien game is free for a week
 - [https://www.pcgamer.com/the-best-alien-game-that-isnt-an-alien-game-is-free-for-a-week](https://www.pcgamer.com/the-best-alien-game-that-isnt-an-alien-game-is-free-for-a-week)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 11:46:16+00:00

Duskers is a perfect organism.

## ASRock B650E PG-ITX WiFi
 - [https://www.pcgamer.com/asrock-b650e-pg-itx-motherboard-review](https://www.pcgamer.com/asrock-b650e-pg-itx-motherboard-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 11:00:22+00:00

Mini ITX AM5 with full PCIe 5.0 support.

## Intel CEO slams Arrow Lake CPU delay rumours
 - [https://www.pcgamer.com/intel-ceo-slams-arrow-lake-cpu-delay-rumours](https://www.pcgamer.com/intel-ceo-slams-arrow-lake-cpu-delay-rumours)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 10:56:14+00:00

Pat Gelsinger gives the rumour mill a kicking.

## Wordle hint and answer #615: Friday, February 24
 - [https://www.pcgamer.com/wordle-hint-answer-today-615-february-24](https://www.pcgamer.com/wordle-hint-answer-today-615-february-24)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 08:06:44+00:00

Get some help with Friday's Wordle.

## Embracer and WB agreement means multiple new Lord of the Rings movies
 - [https://www.pcgamer.com/embracer-and-wb-agreement-means-multiple-new-lord-of-the-rings-movies](https://www.pcgamer.com/embracer-and-wb-agreement-means-multiple-new-lord-of-the-rings-movies)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 01:37:17+00:00

The road goes ever on and on. And on.

## Sons of the Forest: How to save your game
 - [https://www.pcgamer.com/sons-of-the-forest-how-to-save-your-game](https://www.pcgamer.com/sons-of-the-forest-how-to-save-your-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 00:09:34+00:00

With death around every corner in Sons of the Forest, you'll want to save your progress often. But you'll need to do a quick bit of building first.

## The Resident Evil 4 Remake messes with the timeline and teases Mercenaries return in its latest trailer
 - [https://www.pcgamer.com/the-resident-evil-4-remake-messes-with-the-timeline-and-teases-mercenaries-return-in-its-latest-trailer](https://www.pcgamer.com/the-resident-evil-4-remake-messes-with-the-timeline-and-teases-mercenaries-return-in-its-latest-trailer)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-24 00:08:39+00:00

The new game is also getting a demo like previous REmakes before it.

