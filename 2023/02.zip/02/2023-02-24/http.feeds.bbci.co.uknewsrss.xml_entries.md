# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Disabled actors patronised by TV industry, says artist
 - [https://www.bbc.co.uk/news/uk-wales-64458735?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-64458735?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 22:53:53+00:00

Actors with disabilities are often cast to make non-disabled people look inclusive, an artist says.

## Graham Potter: Chelsea boss says his family have received anonymous death threats
 - [https://www.bbc.co.uk/sport/football/64766580?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64766580?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 22:39:58+00:00

Chelsea boss Graham Potter says he and his family have received anonymous death threats following the club's poor run of form.

## Fulham 1-1 Wolverhampton Wanderers: Hosts held by Premier League strugglers
 - [https://www.bbc.co.uk/sport/football/64671841?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64671841?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 22:39:12+00:00

Substitute Manor Solomon scores for the third consecutive game as European hopefuls Fulham fight back to claim a Premier League draw against Wolves.

## Eurovision 2023: Government pledges £10m towards Liverpool song contest
 - [https://www.bbc.co.uk/news/entertainment-arts-64763717?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64763717?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 22:35:38+00:00

The money will go on operational costs like security and visas for the show, being held in Liverpool.

## The pub bosses that closed their kitchens to stay afloat
 - [https://www.bbc.co.uk/news/business-64557630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64557630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 22:33:41+00:00

Soaring gas, food and staffing costs have made some pubs move away hot meals.

## A million households can apply for £400 energy rebate
 - [https://www.bbc.co.uk/news/business-64760411?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64760411?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 22:31:17+00:00

Almost a million households can now apply for winter energy payments, but it could still take weeks.

## King had planned to meet EU chief
 - [https://www.bbc.co.uk/news/uk-politics-64765375?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64765375?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 22:25:18+00:00

Saturday's meeting between the King and Ursula von der Leyen has been cancelled due to operational reasons.

## Ukraine war: Zelensky keen to meet Xi following China's peace plan
 - [https://www.bbc.co.uk/news/world-europe-64762219?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64762219?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 21:49:01+00:00

Ukraine's leader said the call for talks and a ceasefire showed Beijing was "preparing to take part".

## Super League: Wigan Warriors 60-0 Wakefield Trinity - hosts cruise to first win of season
 - [https://www.bbc.co.uk/sport/rugby-league/64721577?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-league/64721577?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 21:48:05+00:00

Wigan recover in style from an opening-weekend loss in Super League, scoring 11 tries in a 60-0 home win against Wakefield.

## Celtic rout defending champions Rangers to go top of SWPL on goal difference
 - [https://www.bbc.co.uk/sport/football/64763074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64763074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 20:52:47+00:00

Caitlin Hayes scores twice as impressive Celtic rout Old Firm rivals Rangers 3-0 to move top of the SWPL on goal difference.

## Women's T20 World Cup: England's hopes unravel against hosts South Africa
 - [https://www.bbc.co.uk/sport/cricket/64765764?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64765764?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 20:18:02+00:00

England were heavy favourites against South Africa but lost their Women's T20 World Cup semi-final - where did it go wrong?

## Bird flu: UK health officials make contingency plans
 - [https://www.bbc.co.uk/news/health-64763625?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-64763625?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 18:24:57+00:00

There is no evidence bird flu will start spreading between people but experts are preparing for any scenario.

## Succession: Show's creator announces show will end after fourth season
 - [https://www.bbc.co.uk/news/entertainment-arts-64762465?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64762465?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 18:23:56+00:00

The Emmy-winning show's creator Jesse Armstrong says it feels like the right time for it to end.

## Qatar Open: Andy Murray saves five match points to reach Doha final
 - [https://www.bbc.co.uk/sport/tennis/64764087?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/64764087?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 17:27:42+00:00

Andy Murray produces yet another remarkable comeback, saving five match points to beat Jiri Lehecka and reach the Qatar Open final in Doha.

## Major rescue operation after tug capsizes off Greenock
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-64764145?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-64764145?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 17:20:36+00:00

Emergency services were called to East India Harbour off the coast of Greenock after the boat overturned.

## Brothers leave Guantanamo Bay without charge after almost 20 years
 - [https://www.bbc.co.uk/news/world-us-canada-64762215?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64762215?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 17:16:16+00:00

Abdul and Mohammed Ahmed Rabbani were arrested in Pakistan in 2002. They were never charged by the US.

## Protocol: Hopes raised for Brexit deal on Northern Ireland
 - [https://www.bbc.co.uk/news/uk-politics-64763303?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64763303?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 16:40:34+00:00

A deal could be announced in the coming days after more than a year of talks, sources tell the BBC.

## Women's T20 World Cup: England beaten by South Africa in tense semi-final
 - [https://www.bbc.co.uk/sport/cricket/64759605?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64759605?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 16:35:21+00:00

England are knocked out of the Women's T20 World Cup after inspired hosts South Africa win a gripping semi-final by six runs.

## Bernard Ingham: Margaret Thatcher's press chief dies aged 90
 - [https://www.bbc.co.uk/news/uk-politics-64763545?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64763545?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 16:34:14+00:00

The former journalist served as press secretary throughout Baroness Thatcher's 11-years as prime minister.

## Tees, Esk and Wear Valley NHS Trust prosecuted after three patients died
 - [https://www.bbc.co.uk/news/uk-england-tees-64762387?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tees-64762387?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 16:18:03+00:00

Christie Harnett, Emily Moore and a third person died while under the care of a mental health trust.

## Damages for Warwick student denied extension due to cancer
 - [https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-64758431?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-64758431?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 16:15:12+00:00

The University of Warwick says it has reversed its decision and offered its "sincere apologies".

## Britain's apple farmers issue food security warning
 - [https://www.bbc.co.uk/news/uk-england-kent-64751224?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-64751224?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 16:13:13+00:00

Kent apple growers say rising costs mean they can no longer afford to continue growing the fruit.

## Graham Potter: Chelsea boss says family and mental health have suffered because of criticism
 - [https://www.bbc.co.uk/sport/football/64762146?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64762146?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 15:38:51+00:00

Graham Potter says the criticism he faces as the Chelsea manager has caused his family and mental health to suffer.

## Women's T20 World Cup: Alice Capsey out to 'sensational' Tazmin Brits catch
 - [https://www.bbc.co.uk/sport/av/cricket/64762639?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/64762639?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 15:34:05+00:00

South Africa's Tazmin Brits takes a "sensational" catch to dismiss Alice Capsey for a duck at the Women's T20 World Cup.

## Six Nations 2023: 'No bigger game' as wounded Wales face England
 - [https://www.bbc.co.uk/sport/rugby-union/64761149?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64761149?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 15:29:40+00:00

After another turbulent week for Welsh rugby, the side is ready to let off some steam against a rebuilding England.

## Rod Stewart pays for scans at NHS hospital to cut waiting lists
 - [https://www.bbc.co.uk/news/uk-england-essex-64759060?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-64759060?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 15:16:12+00:00

The singer pays for a day's worth of scans and pledges to do more.

## TSSA rail union accepts pay deal from train companies
 - [https://www.bbc.co.uk/news/business-64756141?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64756141?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 15:15:46+00:00

The TSSA union says its 3,000 members have accepted an offer including a two-year 9% pay deal.

## TikTok under investigation by Canadian privacy authorities
 - [https://www.bbc.co.uk/news/technology-64759365?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64759365?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 15:14:33+00:00

The investigation into the video-sharing platform will have a particular focus on younger users.

## Vernon Kay 'over the moon' to replace Ken Bruce on Radio 2
 - [https://www.bbc.co.uk/news/entertainment-arts-64755872?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64755872?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 14:00:05+00:00

The presenter has said he is "over the moon" to take over the long-serving host's weekday show.

## Liverpool boss Jurgen Klopp says it is 'clear we have to do something in the summer'
 - [https://www.bbc.co.uk/sport/football/64754900?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64754900?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 13:59:40+00:00

Liverpool manager Jurgen Klopp says it is "clear we have to do something in the summer" amid his side's struggles this season.

## Poet Laureate marks 100 years of the Flying Scotsman
 - [https://www.bbc.co.uk/news/entertainment-arts-64760727?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64760727?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 13:30:31+00:00

Simon Armitage has written a poem about one of the country's most romantic trains.

## Roald Dahl: Original books to be printed by Penguin following criticism
 - [https://www.bbc.co.uk/news/entertainment-arts-64759118?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64759118?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 13:10:23+00:00

The original story books will now be available along with updated versions of his children's novels.

## Carabao Cup final 2023: Newcastle's Dan Burn gearing up for dream Wembley final against Manchester United
 - [https://www.bbc.co.uk/sport/av/football/64760271?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64760271?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 12:52:58+00:00

Newcastle United defender and lifelong Magpies fan Dan Burn tells Football Focus how winning the Carabao Cup on Sunday would fulfil his childhood dreams.

## F1: George Russell not expecting Mercedes to win in Bahrain
 - [https://www.bbc.co.uk/sport/formula1/64759159?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/64759159?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 12:27:18+00:00

George Russell says he does not expect Mercedes to be competing for victory at the start of the Formula 1 season in Bahrain next week.

## Family launches legal action over mother's death in Tenerife crash
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-64745928?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-64745928?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 12:03:29+00:00

Michelle Exton's daughter says the family wants to get her mother the justice she deserves.

## Ceremonies mark the anniversary of Russia's invasion of Ukraine
 - [https://www.bbc.co.uk/news/in-pictures-64757068?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-64757068?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 11:53:46+00:00

Ceremonies are taking place across the world to mark the anniversary of Russia's full-scale invasion.

## Junior doctors to strike on 13 to 15 March
 - [https://www.bbc.co.uk/news/health-64758661?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-64758661?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 11:43:33+00:00

They are walking out over pay and want an increase to make up for 15 years of inflation.

## Venus, Jupiter and the Moon pictured in celestial event
 - [https://www.bbc.co.uk/news/uk-wales-64756972?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-64756972?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 11:37:54+00:00

Venus, Jupiter and the Moon were aligned and could be seen with the naked eye on Wednesday night

## Europa League last 16: Man Utd to play Real Betis, Arsenal face Sporting Lisbon
 - [https://www.bbc.co.uk/sport/football/64755066?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64755066?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 11:33:32+00:00

Manchester United will play Real Betis in the Europa League last 16 after beating Barcelona, while Arsenal face Sporting Lisbon.

## New Zealand v England: Joe Root & Harry Brook in master-and-apprentice stand
 - [https://www.bbc.co.uk/sport/cricket/64754325?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64754325?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 11:00:20+00:00

A teenage Harry Brook once bowled Joe Root in the Yorkshire nets - now they are set to form a prolific middle-order partnership for England, writes Stephan Shemilt.

## China and the Ukraine war: The real reason for Beijing's charm offensive
 - [https://www.bbc.co.uk/news/world-asia-china-64754510?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-64754510?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 10:06:03+00:00

The West may come away unimpressed - but convincing them was never likely the main goal for Beijing.

## Tebbutt murder-kidnap: Kenyan freed on appeal after decade in jail
 - [https://www.bbc.co.uk/news/world-africa-64706938?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-64706938?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 10:05:25+00:00

A man walks free after 11 years, amid concerns about a Met detective's role in his conviction in Kenya.

## Merseyside pupils 'humiliated' by school skirt-length inspections
 - [https://www.bbc.co.uk/news/uk-england-merseyside-64743377?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-64743377?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 09:59:49+00:00

Students protest over how Rainford High School inspections are implemented, with some left in tears.

## Six Nations 2023: Scotland make one change as Hamish Watson set to face France
 - [https://www.bbc.co.uk/sport/rugby-union/64756630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64756630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 09:31:45+00:00

Hamish Watson is the only change to Scotland's line-up as Gregor Townsend's side travel to France in a mouth-watering Six Nations match in Paris.

## Jake Paul v Tommy Fury: Is Saudi Arabia fight 'entertainment' or 'proper' boxing?
 - [https://www.bbc.co.uk/sport/boxing/64734184?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/64734184?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 09:28:48+00:00

Is Jake Paul v Tommy Fury just entertainment or proper boxing and what does Fury gain by fighting the YouTuber-turned-boxer?

## Carabao Cup final: Inside Erik ten Hag's Manchester United revolution
 - [https://www.bbc.co.uk/sport/football/64730932?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64730932?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 09:01:03+00:00

BBC Sport's Simon Stone looks at how Erik ten Hag has turned Manchester United around ahead of Sunday's EFL Cup final.

## Nominations to close in SNP leadership race
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-64754523?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-64754523?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 08:51:35+00:00

Three MSPs - Kate Forbes, Humza Yousaf and Ash Regan - are expected to be confirmed as the contenders.

## Ruben Selles: Southampton appoint Spaniard as manager until end of season
 - [https://www.bbc.co.uk/sport/football/64755067?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64755067?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 08:43:38+00:00

Ruben Selles is appointed Southampton manager until the end of the season.

## University to return skulls to Irish island
 - [https://www.bbc.co.uk/news/articles/ck5y95394l8o?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/ck5y95394l8o?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 06:35:55+00:00

Two academics removed the remains of 13 people from Inishbofin without islanders' consent in 1890.

## Omagh police shooting: Fourth arrest after John Caldwell attack
 - [https://www.bbc.co.uk/news/uk-northern-ireland-64751458?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-64751458?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 06:28:20+00:00

Det Ch Insp John Caldwell remains in a serious condition in hospital after being shot several times.

## Swimmers 'ruined' by culture of fat-shaming and bullying
 - [https://www.bbc.co.uk/news/uk-england-64256659?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-64256659?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 06:21:15+00:00

Former athletes tell of mistreatment at clubs across England, with allegations stretching back more than a decade.

## Join the Ukrainian army or go to the UK, Dad told me
 - [https://www.bbc.co.uk/news/uk-england-london-64692538?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-64692538?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 06:19:39+00:00

Five refugees who left Ukraine and moved to London reflect on how their lives have changed.

## LGBT+ History Month: UFC's Molly McCann on how MMA gave her courage to be herself
 - [https://www.bbc.co.uk/sport/av/mixed-martial-arts/64724661?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/mixed-martial-arts/64724661?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 06:14:55+00:00

UFC fighter Molly McCann discusses the journey she's been on to discover and embrace her sexuality, and how MMA gave her the courage to be herself.

## Ukraine war: Vuhledar, the mining town Russia wants to take
 - [https://www.bbc.co.uk/news/world-europe-64744125?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64744125?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 05:55:22+00:00

Orla Guerin reports from Vuhledar, an eastern Ukrainian town Russia is desperate to capture.

## New Zealand vs England: Harry Brook hits sublime 184 to put tourists in control
 - [https://www.bbc.co.uk/sport/cricket/64753742?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64753742?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 04:50:40+00:00

A magnificent 184 not out from Harry Brook puts England in the ascendancy on day one of the second Test against New Zealand.

## England's archaeological history gathers dust as museums fill up
 - [https://www.bbc.co.uk/news/science-environment-64707488?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64707488?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 04:21:54+00:00

Experts say time is running out to solve the storage crisis that has long plagued archaeology.

## Los Angeles blizzard warning is first since 1989
 - [https://www.bbc.co.uk/news/world-us-canada-64753583?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64753583?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 04:20:18+00:00

Up to 8ft of snow is forecast to blanket parts of usually balmy southern California.

## UK phone repair apprenticeship needed, says firm
 - [https://www.bbc.co.uk/news/technology-64704104?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64704104?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 04:15:28+00:00

Repair firm says there is no industry standard training for fixing smartphones and other devices.

## Signal would 'walk' from UK if Online Safety Bill undermined encryption
 - [https://www.bbc.co.uk/news/technology-64584001?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64584001?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 03:22:49+00:00

Bosses of the messaging app fear the Online Safety Bill could force it to weaken its users' security.

## Forty years of monster raving loony wannabe MPs
 - [https://www.bbc.co.uk/news/uk-politics-64708154?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64708154?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 02:03:25+00:00

The party, with its garish outfits and garish policies, has become part of British political tradition.

## Is it cheaper to study in a coffee shop or at home?
 - [https://www.bbc.co.uk/news/business-64708230?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64708230?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 01:08:24+00:00

As prices rise, are there cheaper places than home to work or study?

## Ukraine war: The friends who fought Russia's invasion
 - [https://www.bbc.co.uk/news/world-europe-64733014?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64733014?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 00:49:16+00:00

Jeremy Bowen catches up with two Ukrainian students who chose to fight when Russia's invasion began.

## US ex-lawyer Alex Murdaugh admits lying but denies killing family
 - [https://www.bbc.co.uk/news/world-us-canada-64752755?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64752755?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 00:46:20+00:00

The South Carolina legal heir weeps as he recalls finding his wife and son dead, but denies murder.

## Ukraine war: How Putin's fate is tied to Russia's war
 - [https://www.bbc.co.uk/news/world-europe-64744197?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64744197?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 00:40:45+00:00

Steve Rosenberg looks at why Vladimir Putin set sail in a storm of his own making a year ago.

## The Papers: 'Ukraine's year of blood' and 'let them eat turnips'
 - [https://www.bbc.co.uk/news/blogs-the-papers-64752867?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-64752867?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 00:30:09+00:00

Many of Friday's papers reflect on the war in Ukraine on the anniversary of Russia's invasion and the UK's fruit and veg shortages.

## Nigeria election 2023: Charts that explain the nation
 - [https://www.bbc.co.uk/news/world-africa-64431962?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-64431962?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 00:25:28+00:00

The BBC tracks the issues facing Nigerians as the country chooses a new president on 25 February.

## Can technology clean up the shrimp farming business?
 - [https://www.bbc.co.uk/news/business-64496392?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64496392?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 00:08:38+00:00

Shrimp farming has been criticised for causing environmental damage - can tech clean it up?

## Pasta price doubles to 95p as cost of basics rises
 - [https://www.bbc.co.uk/news/business-64732404?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64732404?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 00:06:39+00:00

While overall price rises in the UK slow, food inflation may not have peaked yet, research suggests.

## Fruit and vegetable shortage could last until May, say growers
 - [https://www.bbc.co.uk/news/business-64743704?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64743704?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 00:05:44+00:00

UK growers delay planting crops due to high energy prices, producers say.

## Ukraine war: Six sporting lives lost - 'We will not forgive, or forget'
 - [https://www.bbc.co.uk/sport/64641089?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/64641089?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-24 00:02:43+00:00

Numerous Ukrainian sportspeople signed up to fight after Russia invaded a year ago. Not all those who swapped the sports field for the battlefield have survived the conflict.

