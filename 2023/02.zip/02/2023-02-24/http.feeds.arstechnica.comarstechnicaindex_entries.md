# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Signal CEO: We “1,000% won’t participate” in UK law to weaken encryption
 - [https://arstechnica.com/?p=1920090](https://arstechnica.com/?p=1920090)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 23:48:31+00:00

The UK's Safety Online Bill would require Signal to police user messages.

## Google has gotten so cheap, employees now have to share desks
 - [https://arstechnica.com/?p=1919813](https://arstechnica.com/?p=1919813)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 23:05:49+00:00

Google's cost-cutters take aim at the company's office space and workspace culture.

## As COVID vaccine patent dispute drags on, Moderna forks over $400M to NIH
 - [https://arstechnica.com/?p=1920085](https://arstechnica.com/?p=1920085)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 22:40:48+00:00

Moderna called the sum a "catch-up payment" for borrowing a molecular technique.

## Report: More Twitter drama after Slack shutdown; employees play hooky
 - [https://arstechnica.com/?p=1920032](https://arstechnica.com/?p=1920032)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 21:31:26+00:00

It’s possible that Twitter might be ditching Slack.

## These scientists lugged logs on their heads to resolve Chaco Canyon mystery
 - [https://arstechnica.com/?p=1919792](https://arstechnica.com/?p=1919792)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 21:00:09+00:00

“Tumplines allow one to carry heavier weights over larger distances without getting fatigued."

## Motorola brings $5-a-month satellite messaging to any phone with new hotspot
 - [https://arstechnica.com/?p=1919812](https://arstechnica.com/?p=1919812)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 20:46:48+00:00

Have a look at Android's first comprehensive satellite texting solution.

## Keyboard DIYing is moving outside hobbyist circles—and that’s a good thing
 - [https://arstechnica.com/?p=1919821](https://arstechnica.com/?p=1919821)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 20:23:17+00:00

Just ask Best Buy.

## Meta unveils a new large language model that can run on a single GPU
 - [https://arstechnica.com/?p=1919928](https://arstechnica.com/?p=1919928)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 20:02:02+00:00

LLaMA-13B reportedly outperforms ChatGPT-like tech despite being 10x smaller.

## Unexpected protein interactions needed to build flowers
 - [https://arstechnica.com/?p=1919874](https://arstechnica.com/?p=1919874)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 19:22:59+00:00

A protein made for destruction turns to cooperation to build flowers.

## An EV charger every 50 miles: Here’s the plan to keep them running
 - [https://arstechnica.com/?p=1919952](https://arstechnica.com/?p=1919952)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 19:12:52+00:00

Uptime and "Buy American": We look at Biden's $7.5 billion charging plan.

## Secret crawlspace cryptomine discovered in routine inspection of MA high school
 - [https://arstechnica.com/?p=1919905](https://arstechnica.com/?p=1919905)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 18:20:34+00:00

The Department of Homeland Security helped track the origins of the mining rig.

## Humanity is the reimagined 3D Lemmings we didn’t know we needed
 - [https://arstechnica.com/?p=1919808](https://arstechnica.com/?p=1919808)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 17:55:54+00:00

Trippy trailer, fun demo have us excited for <em>Tetris Effect</em> publisher's May game.

## US says Google routinely destroyed evidence and lied about use of auto-delete
 - [https://arstechnica.com/?p=1919839](https://arstechnica.com/?p=1919839)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 17:28:58+00:00

Filing: Google deleted chats for nearly four years despite requirement to keep them.

## Rovio delists pay-to-own Angry Birds because it hurt free-to-play earnings
 - [https://arstechnica.com/?p=1919848](https://arstechnica.com/?p=1919848)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 16:58:41+00:00

A sad end of an era for one of the original paid, viral mobile hits.

## Dealmaster: The best deals on Intel laptops
 - [https://arstechnica.com/?p=1919798](https://arstechnica.com/?p=1919798)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 16:18:21+00:00

Save up to $500 on Ultrabooks and gaming and convertible laptops.

## Don’t worry about AI breaking out of its box—worry about us breaking in
 - [https://arstechnica.com/?p=1919705](https://arstechnica.com/?p=1919705)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 15:23:34+00:00

Opinion: The worst human impulses will find plenty of uses for generative AI.

## After Vulcan comes online, ULA plans to dramatically increase launch cadence
 - [https://arstechnica.com/?p=1919758](https://arstechnica.com/?p=1919758)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 15:02:49+00:00

A Vulcan flying on May the 4th is the crossover we all needed.

## Why time is running out to restore animals existing only in captivity to the wild
 - [https://arstechnica.com/?p=1919774](https://arstechnica.com/?p=1919774)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 14:21:21+00:00

What does the future look like for extant species that are extinct in the wild?

## Rocket Report: SpaceX may see revenue spike in 2023; Terran 1 gets a date
 - [https://arstechnica.com/?p=1919514](https://arstechnica.com/?p=1919514)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-24 12:00:23+00:00

“Each Artemis mission will be properly characterized as a test mission."

