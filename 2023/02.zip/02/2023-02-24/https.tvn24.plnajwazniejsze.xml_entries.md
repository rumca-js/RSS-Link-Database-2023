# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Wiece, marsze, manifestacje. Solidarność z Ukrainą widać było w całej Polsce
 - [https://tvn24.pl/polska/atak-rosji-na-ukraine-wiece-i-manifestacje-poparcia-dla-ukrainy-w-polskich-miastach-6776326?source=rss](https://tvn24.pl/polska/atak-rosji-na-ukraine-wiece-i-manifestacje-poparcia-dla-ukrainy-w-polskich-miastach-6776326?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 22:00:02+00:00

<img alt="Wiece, marsze, manifestacje. Solidarność z Ukrainą widać było w całej Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-36cyjv-marsz-razem-dla-pokoju-w-krakowie-6776339/alternates/LANDSCAPE_1280" />
    Rok po inwazji Rosji.

## Unia Europejska przyjęła "najpotężniejsze i najdalej idące sankcje" wobec Rosji
 - [https://tvn24.pl/swiat/rosja-sankcje-unia-europejska-przyjelismy-najpotezniejsze-i-najdalej-idace-sankcje-wobec-rosji-6776341?source=rss](https://tvn24.pl/swiat/rosja-sankcje-unia-europejska-przyjelismy-najpotezniejsze-i-najdalej-idace-sankcje-wobec-rosji-6776341?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 21:47:24+00:00

<img alt="Unia Europejska przyjęła " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-5ewd6f-moskwa-rosja-6774117/alternates/LANDSCAPE_1280" />
    Poinformowała szwedzka prezydencja.

## "Myśliwce F-16 zapewniły dziś eskortę". B-52 nad Polską
 - [https://tvn24.pl/polska/polska-armia-mariusz-blaszczak-polskie-f-16-eskortowaly-amerykanski-bombowiec-b-52-6776288?source=rss](https://tvn24.pl/polska/polska-armia-mariusz-blaszczak-polskie-f-16-eskortowaly-amerykanski-bombowiec-b-52-6776288?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 21:17:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ed2c6-b-52-eskortowane-przez-polskie-f-16-6776295/alternates/LANDSCAPE_1280" />
    Poinformował szef resortu obrony Mariusz Błaszczak.

## Spojrzenie wrogowi w twarz było przerażające. Potem wiedział, że wykona każdy rozkaz swojego dowódcy
 - [https://tvn24.pl/go/programy,7/wiatr-ze-wschodu-odcinki,518052/odcinek-14,S01E14,1003642?source=rss](https://tvn24.pl/go/programy,7/wiatr-ze-wschodu-odcinki,518052/odcinek-14,S01E14,1003642?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 21:09:20+00:00

<img alt="Spojrzenie wrogowi w twarz było przerażające. Potem wiedział, że wykona każdy rozkaz swojego dowódcy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4lug38-hlib-stryzko-6776315/alternates/LANDSCAPE_1280" />
    Rozmowa Andrzeja Zauchy z Hlibem Stryżko, ukraińskim żołnierzem, obrońcą Mariupola, który trafił do rosyjskiej niewoli.

## "Wojna trwa, ale trzeba zawczasu pomyśleć o tym, co będzie na koniec"
 - [https://tvn24.pl/polska/atak-rosji-na-ukraine-rocznica-pelnoskalowej-inwazji-piotr-wawrzyk-i-pawel-kowal-komentuja-6776217?source=rss](https://tvn24.pl/polska/atak-rosji-na-ukraine-rocznica-pelnoskalowej-inwazji-piotr-wawrzyk-i-pawel-kowal-komentuja-6776217?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 21:02:53+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eytf52-kampania-bezkitu-6776263/alternates/LANDSCAPE_1280" />
    Dyskusja w programie "Kampania #BezKitu".

## Ostrzeżenie przed gwałtownym wzrostem stanów w Bałtyku i na Wiśle
 - [https://tvn24.pl/tvnmeteo/pogoda/pomorskie-wysoki-stan-wod-w-baltyku-i-na-wisle-alerty-imgw-6776306?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pomorskie-wysoki-stan-wod-w-baltyku-i-na-wisle-alerty-imgw-6776306?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 20:58:00+00:00

<img alt="Ostrzeżenie przed gwałtownym wzrostem stanów w Bałtyku i na Wiśle" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-kfi39r-silny-wiatr-noc-6686902/alternates/LANDSCAPE_1280" />
    Obowiązują alerty hydrologiczne IMGW.

## Krejcikova dołączyła do Świątek. W finale okazja do rewanżu
 - [https://eurosport.tvn24.pl/krejcikova-do--czy-a-do--wi-tek--w-finale-okazja-do-rewan-u,1137552.html?source=rss](https://eurosport.tvn24.pl/krejcikova-do--czy-a-do--wi-tek--w-finale-okazja-do-rewan-u,1137552.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 20:15:00+00:00

<img alt="Krejcikova dołączyła do Świątek. W finale okazja do rewanżu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mnnadk-krejcikova-zrewanzowala-sie-peguli-za-porazke-w-australian-open/alternates/LANDSCAPE_1280" />
    Barbora Krejcikova pokonała Jessicę Pegulę w drugim piątkowym półfinale w Dubaju.

## Kolejne miliardy dolarów dla Ukrainy. Zapowiedź Banku Światowego
 - [https://tvn24.pl/biznes/ze-swiata/wojna-w-ukrainie-bank-swiatowy-oglosil-ze-przeznacza-na-pomoc-dla-ukrainy-25-mld-dolarow-6776229?source=rss](https://tvn24.pl/biznes/ze-swiata/wojna-w-ukrainie-bank-swiatowy-oglosil-ze-przeznacza-na-pomoc-dla-ukrainy-25-mld-dolarow-6776229?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 20:12:41+00:00

<img alt="Kolejne miliardy dolarów dla Ukrainy. Zapowiedź Banku Światowego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mqfop7-stacja-metra-w-kijowie-ludzie-chronia-sie-przed-rosyjskimi-pociskami-6680389/alternates/LANDSCAPE_1280" />
    Środki mają wesprzeć budżet kraju i zapewnić Ukraińcom dostęp do podstawowych usług.

## Jeden europejski kraj nie wyklucza racjonowania wody, w innym ogłoszono stan wyjątkowy
 - [https://tvn24.pl/tvnmeteo/swiat/susza-w-europie-wlochy-nie-wykluczaja-racjonowania-wody-we-francji-stan-wyjatkowy-6776196?source=rss](https://tvn24.pl/tvnmeteo/swiat/susza-w-europie-wlochy-nie-wykluczaja-racjonowania-wody-we-francji-stan-wyjatkowy-6776196?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 20:03:16+00:00

<img alt="Jeden europejski kraj nie wyklucza racjonowania wody, w innym ogłoszono stan wyjątkowy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-us9wty-niski-poziom-wody-w-jeziorze-lac-du-broc-w-poludniowej-francji-6776234/alternates/LANDSCAPE_1280" />
    To odpowiedź na groźną suszę.

## "W środku nocy zadzwonił do mnie prezydent Zełenski". Andrzej Duda o najtrudniejszych chwilach wojny
 - [https://tvn24.pl/polska/atak-rosji-na-ukraine-rocznica-pelnoskalowej-inwazji-prezydent-andrzej-duda-o-najtrudniejszych-momentach-wojny-6775976?source=rss](https://tvn24.pl/polska/atak-rosji-na-ukraine-rocznica-pelnoskalowej-inwazji-prezydent-andrzej-duda-o-najtrudniejszych-momentach-wojny-6775976?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 19:51:27+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2q3c7c-prezydent-andrzej-duda-i-prezydent-wolodymyr-zelenski-w-radzie-najwyzszej-ukrainy-5721022/alternates/LANDSCAPE_1280" />
    Wymienił dwa takie momenty.

## "Ten rok to historia tworzenia się nowoczesnej Ukrainy"
 - [https://tvn24.pl/polska/atak-rosji-na-ukraine-rocznica-pelnoskalowej-inwazji-aleksander-kwasniewski-komentuje-6776184?source=rss](https://tvn24.pl/polska/atak-rosji-na-ukraine-rocznica-pelnoskalowej-inwazji-aleksander-kwasniewski-komentuje-6776184?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 19:30:40+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1ui9wr-kijow-ukraina-24022023-6776200/alternates/LANDSCAPE_1280" />
    Ocenił były prezydent Aleksander Kwaśniewski w TVN24.

## Setki zbrodni wojennych tylko w jednym miejscu. Dotarli do wstrząsających dowodów
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1225,S00E1225,1003644?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1225,S00E1225,1003644?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 19:21:34+00:00

<img alt="Setki zbrodni wojennych tylko w jednym miejscu. Dotarli do wstrząsających dowodów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ivj5qh-wladimir-putin-6776209/alternates/LANDSCAPE_1280" />
    Dziennikarze FRONTLINE i AP odkryli, jak zbrodnie wojenne w Buczy łączą się z jednym z najwyższych rosyjskich generałów.

## "WSJ": chiński myśliwiec uzbrojony w rakiety zbliżył się do samolotu USA
 - [https://tvn24.pl/swiat/usa-chiny-niebezpieczny-incydent-miedzy-samolotami-wojskowymi-na-morzu-poludniowochinskim-6776185?source=rss](https://tvn24.pl/swiat/usa-chiny-niebezpieczny-incydent-miedzy-samolotami-wojskowymi-na-morzu-poludniowochinskim-6776185?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 19:15:43+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wn1j7l-chinski-mysliwiec-j-11-6557520/alternates/LANDSCAPE_1280" />
    Takie zdarzenia są coraz częstsze i coraz bardziej niebezpieczne - twierdzą amerykańscy wojskowi

## Kraje G7 zapowiadają kroki przeciw państwom wspierającym "rosyjską wojnę"
 - [https://tvn24.pl/biznes/ze-swiata/ukraina-rosja-japonia-g7-podejmie-kroki-przeciw-panstwom-wspierajacym-rosyjska-wojne-6776125?source=rss](https://tvn24.pl/biznes/ze-swiata/ukraina-rosja-japonia-g7-podejmie-kroki-przeciw-panstwom-wspierajacym-rosyjska-wojne-6776125?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 18:52:55+00:00

<img alt="Kraje G7 zapowiadają kroki przeciw państwom wspierającym " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-cqrpj0-szczyt-g7-6776127/alternates/LANDSCAPE_1280" />
    W wirtualnym spotkaniu grupy wziął udział prezydent Ukrainy Wołodymyr Zełenski.

## "Jak mnie ścięło, to nie byłem w stanie się ruszać"
 - [https://eurosport.tvn24.pl/-jak-mnie--ci--o--to-nie-by-em-w-stanie-si--rusza--,1137562.html?source=rss](https://eurosport.tvn24.pl/-jak-mnie--ci--o--to-nie-by-em-w-stanie-si--rusza--,1137562.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 18:52:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x0dspj-dawid-kubacki/alternates/LANDSCAPE_1280" />
    Dawid Kubacki o swojej kontuzji.

## Blinken: pokój musi gwarantować, że Rosja nie będzie mogła odpocząć
 - [https://tvn24.pl/swiat/atak-rosji-na-ukraine-antony-blinken-sekretarz-stanu-usa-na-radzie-bezpieczenstwa-onz-pokoj-musi-gwarantowac-ze-rosja-nie-mogla-odpoczac-i-ponownie-rozpoczac-wojny-6776027?source=rss](https://tvn24.pl/swiat/atak-rosji-na-ukraine-antony-blinken-sekretarz-stanu-usa-na-radzie-bezpieczenstwa-onz-pokoj-musi-gwarantowac-ze-rosja-nie-mogla-odpoczac-i-ponownie-rozpoczac-wojny-6776027?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 18:13:14+00:00

<img alt="Blinken: pokój musi gwarantować, że Rosja nie będzie mogła odpocząć" src="https://tvn24.pl/najnowsze/cdn-zdjecie-18ur6p-antony-blinken-6776037/alternates/LANDSCAPE_1280" />
    Szef amerykańskiej dyplomacji na forum Rady Bezpieczeństwa ONZ.

## Ulicami polskich miast przeszły marsze poparcia dla Ukrainy
 - [https://fakty.tvn24.pl/ulicami-polskich-miast-przesz-y-marsze-poparcia-dla-ukrainy,1137558.html?source=rss](https://fakty.tvn24.pl/ulicami-polskich-miast-przesz-y-marsze-poparcia-dla-ukrainy,1137558.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 18:13:05+00:00

<img alt="Ulicami polskich miast przeszły marsze poparcia dla Ukrainy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sklh6m-2402--ulicami-polskich-miast-przeszly-marsze-poparcia-dla-ukrainy/alternates/LANDSCAPE_1280" />
    W Warszawie największą demonstrację zorganizowano przed rosyjską ambasadą.

## "Próbujemy żyć dalej, ale nie da się zapomnieć". Rok wojny oczami bohaterów materiałów "Faktów" TVN
 - [https://fakty.tvn24.pl/-pr-bujemy--y--dalej--ale-nie-da-si--zapomnie----rok-wojny-oczami-bohater-w-materia--w--fakt-w--tvn,1137561.html?source=rss](https://fakty.tvn24.pl/-pr-bujemy--y--dalej--ale-nie-da-si--zapomnie----rok-wojny-oczami-bohater-w-materia--w--fakt-w--tvn,1137561.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 18:12:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6v1i0a-2402--przezyli-okupacje-ale-codziennie-mierza-sie-z-trauma-rok-wojny-oczami-bohaterow-materialow-faktow-tvn/alternates/LANDSCAPE_1280" />
    Nie ma wielkiego, czy małego miasta w Ukrainie, które nie ucierpiałoby w czasie tej wojny.

## "Widziałem swoją rękę zbombardowaną. W kawałeczkach"
 - [https://fakty.tvn24.pl/-widzia-em-swoj--r-k--zbombardowan---w-kawa-eczkach----,1137585.html?source=rss](https://fakty.tvn24.pl/-widzia-em-swoj--r-k--zbombardowan---w-kawa-eczkach----,1137585.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 18:08:44+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3upfzu-24-6776227/alternates/LANDSCAPE_1280" />
    Przez ostatnich 12 miesięcy na Ukrainie zginęło osiem tysięcy cywilów, a ponad 13 tysięcy zostało rannych. Wśród nich jest także Dymian.

## Bieg łączony w Planicy pod dyktando Norwegów. Wzięli całe podium
 - [https://eurosport.tvn24.pl/bieg---czony-w-planicy-pod-dyktando-norweg-w--wzi-li-ca-e-podium,1137547.html?source=rss](https://eurosport.tvn24.pl/bieg---czony-w-planicy-pod-dyktando-norweg-w--wzi-li-ca-e-podium,1137547.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 18:08:00+00:00

<img alt="Bieg łączony w Planicy pod dyktando Norwegów. Wzięli całe podium" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aq3unx-norweskie-podium-w-biegu-laczonym-mezczyzn/alternates/LANDSCAPE_1280" />
    W Planicy.

## Kubacki kręcił głową, ale z Polaków był najlepszy. Kwalifikacje dla Laniszka
 - [https://eurosport.tvn24.pl/kubacki-kr-ci--g-ow---ale-z-polak-w-by--najlepszy--kwalifikacje-dla-laniska,1137540.html?source=rss](https://eurosport.tvn24.pl/kubacki-kr-ci--g-ow---ale-z-polak-w-by--najlepszy--kwalifikacje-dla-laniska,1137540.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 17:57:00+00:00

<img alt="Kubacki kręcił głową, ale z Polaków był najlepszy. Kwalifikacje dla Laniszka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q9waii-dawid-kubacki/alternates/LANDSCAPE_1280" />
    Konkurs w sobotę.

## Polacy walczą w kwalifikacjach na skoczni normalnej
 - [https://eurosport.tvn24.pl/mistrzostwa--wiata-w-planicy--kwalifikacje-na-skoczni-normalnej--wynik-na--ywo-i-relacja-live,1137534.html?source=rss](https://eurosport.tvn24.pl/mistrzostwa--wiata-w-planicy--kwalifikacje-na-skoczni-normalnej--wynik-na--ywo-i-relacja-live,1137534.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 17:33:00+00:00

<img alt="Polacy walczą w kwalifikacjach na skoczni normalnej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m9wh3i-planica-gosci-mistrzostwa-swiata-w-narciarstwie-klasycznym/alternates/LANDSCAPE_1280" />
    Transmisja w Eurosporcie 1 oraz Eurosporcie Extra w Playerze, relacja i wyniki na żywo w eurosport.pl.

## "To, co zobaczyłem...". Prezydent Ukrainy o najstraszniejszym dla niego momencie wojny
 - [https://tvn24.pl/swiat/rok-napasci-na-ukraine-zelenski-o-najstraszniejszym-momencie-wojny-6775992?source=rss](https://tvn24.pl/swiat/rok-napasci-na-ukraine-zelenski-o-najstraszniejszym-momencie-wojny-6775992?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 17:01:56+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1q05m4-wolodymyr-zelenski-w-buczy-po-jej-wyzwoleniu-04042022-6776048/alternates/LANDSCAPE_1280" />
    Wołodymyr Zełenski w rocznicę napaści Rosji.

## Dzieci zaśpiewały, by dodać otuchy Ukraińcom. "Wierzę, że te słowa dotrą do ludzi"
 - [https://tvn24.pl/poznan/poznan-dzieci-zaspiewaly-by-dodac-otuchy-ukraincom-wierze-ze-te-slowa-dotra-do-ludzi-6775566?source=rss](https://tvn24.pl/poznan/poznan-dzieci-zaspiewaly-by-dodac-otuchy-ukraincom-wierze-ze-te-slowa-dotra-do-ludzi-6775566?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 17:01:48+00:00

<img alt="Dzieci zaśpiewały, by dodać otuchy Ukraińcom. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ck11nx-wypuszczenie-golebi-6775738/alternates/LANDSCAPE_1280" />
    To prośba od dzieci, abyśmy my, dorośli, zadbali o pokój i ich bezpieczeństwo - mówi dyrektorka jednej z poznańskich szkół.

## Minuta ciszy dla zabitych reporterów. "Chcę podziękować tym, których z nami nie ma i już nie będzie"
 - [https://tvn24.pl/swiat/minuta-ciszy-dla-uczczenia-dziennikarzy-ktorzy-zgineli-w-ukrainie-wolodymyr-zelenski-pozostana-w-naszej-pamieci-6775927?source=rss](https://tvn24.pl/swiat/minuta-ciszy-dla-uczczenia-dziennikarzy-ktorzy-zgineli-w-ukrainie-wolodymyr-zelenski-pozostana-w-naszej-pamieci-6775927?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 16:59:45+00:00

<img alt="Minuta ciszy dla zabitych reporterów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-595y8a-zelenski-podczas-minuty-ciszy-dla-dziennikarzy-ktorzy-zgineli-w-ukrainie-6775908/alternates/LANDSCAPE_1280" />
    Powiedział Wołodymyr Zełenski podczas konferencji prasowej.

## Hurkacz wyszarpał półfinał w Marsylii
 - [https://eurosport.tvn24.pl/hurkacz-wyszarpa--p--fina--w-marsylii,1137545.html?source=rss](https://eurosport.tvn24.pl/hurkacz-wyszarpa--p--fina--w-marsylii,1137545.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 16:56:00+00:00

<img alt="Hurkacz wyszarpał półfinał w Marsylii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8zejs3-hubert-hurkacz-w-grze/alternates/LANDSCAPE_1280" />
    Hubert Hurkacz pokonał Szweda Mikaela Ymera.

## Samolot z Warszawy do Tallina zawrócił na Lotnisko Chopina
 - [https://tvn24.pl/tvnwarszawa/wlochy/warszawa-samolot-z-warszawy-do-tallina-zawrocil-z-powodu-usterki-technicznej-6775972?source=rss](https://tvn24.pl/tvnwarszawa/wlochy/warszawa-samolot-z-warszawy-do-tallina-zawrocil-z-powodu-usterki-technicznej-6775972?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 16:48:11+00:00

<img alt="Samolot z Warszawy do Tallina zawrócił na Lotnisko Chopina" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-y61l88-samolot-lecacy-z-warszawy-do-tallina-zwrocil-na-lotnisko-chopina-zdjecie-ilustracyjne-6775991/alternates/LANDSCAPE_1280" />
    Pasażerowie polecą innym samolotem.

## Zełenski: Rosja może napaść na jeszcze jeden kraj z obszaru wpływu byłego ZSRR
 - [https://tvn24.pl/swiat/wolodymyr-zelenski-w-rocznice-wojny-o-rosji-polsce-panstwach-baltyckich-chinach-moldawii-6775959?source=rss](https://tvn24.pl/swiat/wolodymyr-zelenski-w-rocznice-wojny-o-rosji-polsce-panstwach-baltyckich-chinach-moldawii-6775959?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 16:33:29+00:00

<img alt="Zełenski: Rosja może napaść na jeszcze jeden kraj z obszaru wpływu byłego ZSRR" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mi7vt2-24-1640-zelenski-konfa-0009-6775943/alternates/LANDSCAPE_1280" />
    Konferencja prasowa ukraińskiego prezydenta.

## Coraz więcej młodych osób umiera na zawał serca. Kardiolog o możliwych przyczynach
 - [https://tvn24.pl/ciekawostki/zdrowie-coraz-wiecej-mlodych-osob-umiera-na-zawal-serca-wynika-z-badan-6775460?source=rss](https://tvn24.pl/ciekawostki/zdrowie-coraz-wiecej-mlodych-osob-umiera-na-zawal-serca-wynika-z-badan-6775460?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 16:15:42+00:00

<img alt="Coraz więcej młodych osób umiera na zawał serca. Kardiolog o możliwych przyczynach" src="https://tvn24.pl/najnowsze/cdn-zdjecie0f0905eb6999c5ad50833900085612e3-kilkanascie-godzin-czekal-na-diagnoze-przeszedl-zawal-serca-zdjecie-ilustracyjne-4138582/alternates/LANDSCAPE_1280" />
    Wiele osób poniżej 45. roku życia nie zdaje sobie sprawy, że może być narażonych na schorzenia tego typu.

## "Dziękujemy za to, że nie jesteście zmęczeni tą wojną"
 - [https://tvn24.pl/polska/rok-wojny-w-ukrainie-dziennikarka-tvn24-z-ukrainy-alina-makarczuk-do-polakow-6775812?source=rss](https://tvn24.pl/polska/rok-wojny-w-ukrainie-dziennikarka-tvn24-z-ukrainy-alina-makarczuk-do-polakow-6775812?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 16:15:23+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d43c78-alina-6775763/alternates/LANDSCAPE_1280" />
    Alina Makarczuk, dziennikarka TVN24 z Ukrainy, dziękowała Polakom.

## Wspólne oświadczenie Dudy, Scholza i Macrona w sprawie Ukrainy
 - [https://tvn24.pl/swiat/ukraina-trojkat-weimarski-wspolne-oswiadczenie-andrzeja-dudy-emmanuela-macrona-i-olafa-scholza-6775899?source=rss](https://tvn24.pl/swiat/ukraina-trojkat-weimarski-wspolne-oswiadczenie-andrzeja-dudy-emmanuela-macrona-i-olafa-scholza-6775899?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 16:15:13+00:00

<img alt="Wspólne oświadczenie Dudy, Scholza i Macrona w sprawie Ukrainy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gpb1nz-emmanuel-macron-andrzej-duda-i-olaf-scholz-w-monachium-6765048/alternates/LANDSCAPE_1280" />
    Liderzy państw Trójkąta Weimarskiego "wyrażają swoją niezachwianą solidarność z Ukrainą".

## Norweżka sprostała roli faworytki. Obroniła tytuł
 - [https://eurosport.tvn24.pl/norwe-ka-sprosta-a-roli-faworytki--obroni-a-tytu-,1137536.html?source=rss](https://eurosport.tvn24.pl/norwe-ka-sprosta-a-roli-faworytki--obroni-a-tytu-,1137536.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 16:00:00+00:00

<img alt="Norweżka sprostała roli faworytki. Obroniła tytuł" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f2n510-gyda-westvold-hansen-zostala-w-planicy-mistrzynia-swiata/alternates/LANDSCAPE_1280" />
    W kombinacji norweskiej.

## Andrzej Duda: rozmawiałem z Joe Bidenem na temat wspólnej produkcji militarnej
 - [https://tvn24.pl/polska/andrzej-duda-rozmawialem-z-prezydentem-usa-joe-bidenem-na-temat-wspolnej-produkcji-militarnej-6775873?source=rss](https://tvn24.pl/polska/andrzej-duda-rozmawialem-z-prezydentem-usa-joe-bidenem-na-temat-wspolnej-produkcji-militarnej-6775873?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 15:31:06+00:00

<img alt="Andrzej Duda: rozmawiałem z Joe Bidenem na temat wspólnej produkcji militarnej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-itsa71-prezydent-polski-andrzej-duda-i-prezydent-usa-joe-biden-6771827/alternates/LANDSCAPE_1280" />
    Prezydent przekazał tę informację na konferencji prasowej po posiedzeniu Rady Bezpieczeństwa Narodowego.

## Froome chciał powtórzyć wyczyn sprzed lat
 - [https://eurosport.tvn24.pl/froome-chcia--powt-rzy--wyczyn-sprzed-lat--defekt-i-kraksa-przekre-li-y-te-plany,1137515.html?source=rss](https://eurosport.tvn24.pl/froome-chcia--powt-rzy--wyczyn-sprzed-lat--defekt-i-kraksa-przekre-li-y-te-plany,1137515.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 15:20:00+00:00

<img alt="Froome chciał powtórzyć wyczyn sprzed lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-accky1-christopher-froome/alternates/LANDSCAPE_1280" />
    Defekt i kraksa przekreśliły te plany.

## Dezinformacja po roku inwazji. Pierwszy taki raport i wnioski
 - [https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-zachod-jest-agresorem-a-sankcje-nie-dzialaja-dezinformacja-po-roku-wojny-6771833?source=rss](https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-zachod-jest-agresorem-a-sankcje-nie-dzialaja-dezinformacja-po-roku-wojny-6771833?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 15:12:00+00:00

<img alt="Dezinformacja po roku inwazji. Pierwszy taki raport i wnioski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gynz7c-unijny-raport-o-dzialaniach-fimi-rosja-glownym-graczem-6771412/alternates/LANDSCAPE_1280" />
    O dokumencie pisze Konkret24.

## Dezinformacja po roku inwazji. Pierwszy taki raport i wnioski
 - [https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-zachod-jest-agresorem-a-sankcje-nie-dzialaja-dezinformacja-po-od-inwazji-rosji-na-ukraine-6771833?source=rss](https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-zachod-jest-agresorem-a-sankcje-nie-dzialaja-dezinformacja-po-od-inwazji-rosji-na-ukraine-6771833?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 15:12:00+00:00

<img alt="Dezinformacja po roku inwazji. Pierwszy taki raport i wnioski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gynz7c-unijny-raport-o-dzialaniach-fimi-rosja-glownym-graczem-6771412/alternates/LANDSCAPE_1280" />
    O dokumencie pisze Konkret24.

## "Być może te czołgi są sygnałem, że ofensywa ze strony Ukrainy się rozpocznie"
 - [https://tvn24.pl/polska/polskie-leopardy-dla-ukrainy-ekspert-to-pierwszy-sygnal-o-poczatku-ukrainskiej-ofensywy-6775487?source=rss](https://tvn24.pl/polska/polskie-leopardy-dla-ukrainy-ekspert-to-pierwszy-sygnal-o-poczatku-ukrainskiej-ofensywy-6775487?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 15:07:12+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1pnvua-czolg-leopard-szkolenie-w-swietoszowie-6757398/alternates/LANDSCAPE_1280" />
    Informację o przekazaniu Leopardów przez Polskę komentował w TVN24 komandor porucznik rezerwy Maksymilian Dura.

## R. Kelly skazany na kolejne 20 lat więzienia
 - [https://tvn24.pl/swiat/usa-r-kelly-odsiadujacy-juz-wyrok-30-lat-wiezienia-zostal-skazany-na-kolejne-20-lat-6775792?source=rss](https://tvn24.pl/swiat/usa-r-kelly-odsiadujacy-juz-wyrok-30-lat-wiezienia-zostal-skazany-na-kolejne-20-lat-6775792?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 15:02:25+00:00

<img alt="R. Kelly skazany na kolejne 20 lat więzienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aggmv4-r-kelly-5769908/alternates/LANDSCAPE_1280" />
    Odsiaduje już wyrok 30 lat.

## Świątek ma finał w Dubaju
 - [https://eurosport.tvn24.pl/-wi-tek-z-patentem-na-amerykank---ma-fina--turnieju-w-dubaju,1137522.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-z-patentem-na-amerykank---ma-fina--turnieju-w-dubaju,1137522.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 14:41:00+00:00

<img alt="Świątek ma finał w Dubaju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-czbcde-iga-swiatek-6775768/alternates/LANDSCAPE_1280" />
    Iga Świątek zagra o tytuł w turnieju WTA 1000 w Dubaju. W półfinale polska tenisistka pokonała Amerykankę Coco Gauff 6:4, 6:2.

## Banki wprowadzają zmiany po rekomendacji KNF. "Widzimy znacznie większe zainteresowanie"
 - [https://tvn24.pl/biznes/pieniadze/kredyty-mieszkaniowe-banki-wprowadzaja-zmiany-po-rekomendacji-knf-zdolnosc-kredytowa-w-gore-6775226?source=rss](https://tvn24.pl/biznes/pieniadze/kredyty-mieszkaniowe-banki-wprowadzaja-zmiany-po-rekomendacji-knf-zdolnosc-kredytowa-w-gore-6775226?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 14:22:37+00:00

<img alt="Banki wprowadzają zmiany po rekomendacji KNF. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cdvf5l-bank-kredyt-umowa-6775501/alternates/LANDSCAPE_1280" />
    Dobre informacje dla osób zastanawiających się nad zakupem mieszkania.

## Pięć zasad dobrego snu, które mogą wydłużyć życie nawet o kilka lat
 - [https://tvn24.pl/ciekawostki/nauka-piec-zasad-dobrego-snu-moze-wydluzyc-zycie-nawet-o-kilka-lat-6775537?source=rss](https://tvn24.pl/ciekawostki/nauka-piec-zasad-dobrego-snu-moze-wydluzyc-zycie-nawet-o-kilka-lat-6775537?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 14:21:55+00:00

<img alt="Pięć zasad dobrego snu, które mogą wydłużyć życie nawet o kilka lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qb4vtf-problemy-ze-snem-i-bezsennosc-5723113/alternates/LANDSCAPE_1280" />
    Odnotowane korzyści są jednak różne zależnie od płci.

## 25-latka szukali śledczy z kilku miast. Zdradził go kot
 - [https://tvn24.pl/tvnwarszawa/praga-polnoc/szukali-go-sledczy-z-kilku-miast-zdradzil-kot-6775666?source=rss](https://tvn24.pl/tvnwarszawa/praga-polnoc/szukali-go-sledczy-z-kilku-miast-zdradzil-kot-6775666?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 14:11:42+00:00

<img alt="25-latka szukali śledczy z kilku miast. Zdradził go kot" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecieb4f39f8bd402c6cfe584f73e4197d949-koty-wcale-nie-sa-takimi-milutkimi-domowymi-pupilami-4780117/alternates/LANDSCAPE_1280" />
    Mężczyzna podejrzany jest o oszustwa internetowe.

## Rumuńskie media: lawina porwała Polaków, jedna osoba nie żyje
 - [https://tvn24.pl/tvnmeteo/swiat/rumunia-lawina-porwala-grupe-polskich-turystow-jeden-nie-zyje-6775576?source=rss](https://tvn24.pl/tvnmeteo/swiat/rumunia-lawina-porwala-grupe-polskich-turystow-jeden-nie-zyje-6775576?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:58:16+00:00

<img alt="Rumuńskie media: lawina porwała Polaków, jedna osoba nie żyje" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-0oxbeg-rumunscy-ratownicy-udzielali-pomocy-polskim-turystom-6775600/alternates/LANDSCAPE_1280" />
    Lawina zeszła w czwartek.

## Ilu cywilów zginęło w ciągu roku wojny w Ukrainie? ONZ podało szacunkowe dane
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-ilu-cywilow-zginelo-od-poczatku-pelnoskalowej-inwazji-rosji-na-ukraine-dane-onz-6775461?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-ilu-cywilow-zginelo-od-poczatku-pelnoskalowej-inwazji-rosji-na-ukraine-dane-onz-6775461?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:57:22+00:00

<img alt="Ilu cywilów zginęło w ciągu roku wojny w Ukrainie? ONZ podało szacunkowe dane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ndtil7-sektor-21-masowe-groby-na-cmentarzu-w-mariupolu-6217532/alternates/LANDSCAPE_1280" />
    Śmierć ludności cywilnej w dziewięciu na 10 przypadków była skutkiem wybuchów pocisków lub ataków lotniczych.

## Polska z Albanią może grać na Narodowym. "W ocenie ekspertów stadion jest miejscem bezpiecznym"
 - [https://tvn24.pl/tvnwarszawa/praga-poludnie/warszawa-reprezentacja-polski-z-albania-moze-grac-na-narodowym-6775571?source=rss](https://tvn24.pl/tvnwarszawa/praga-poludnie/warszawa-reprezentacja-polski-z-albania-moze-grac-na-narodowym-6775571?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:42:31+00:00

<img alt="Polska z Albanią może grać na Narodowym. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-oby7kp-stadion-narodowy-jest-wylaczony-z-uzytku-6239513/alternates/LANDSCAPE_1280" />
    "Żadne wydarzenie planowane na 2023 rok nie jest zagrożone".

## Świątek szybko przełamała rywalkę. Amerykanka od razu ma duże kłopoty
 - [https://eurosport.tvn24.pl/iga--wi-tek---coco-gauff-w-p--finale-turnieju-wta-w-dubaju--wynik-na--ywo-i-relacja,1137520.html?source=rss](https://eurosport.tvn24.pl/iga--wi-tek---coco-gauff-w-p--finale-turnieju-wta-w-dubaju--wynik-na--ywo-i-relacja,1137520.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:31:00+00:00

<img alt="Świątek szybko przełamała rywalkę. Amerykanka od razu ma duże kłopoty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4lwskb-iga-swiatek-rusza-do-walki-o-final-turnieju-w-dubaju-6775473/alternates/LANDSCAPE_1280" />
    Iga Świątek - Coco Gauff w półfinale turnieju WTA 1000 w Dubaju. Relacja z meczu i wynik na żywo w eurosport.pl.

## Ambasador USA: mam zaszczyt być świadkiem niezwykłej reakcji Polski na ten kryzys
 - [https://tvn24.pl/polska/rok-wojny-w-ukrainie-przeslanie-ambasadora-usa-w-polsce-marka-brzezinskiego-6775439?source=rss](https://tvn24.pl/polska/rok-wojny-w-ukrainie-przeslanie-ambasadora-usa-w-polsce-marka-brzezinskiego-6775439?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:30:40+00:00

<img alt="Ambasador USA: mam zaszczyt być świadkiem niezwykłej reakcji Polski na ten kryzys" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8v9s8h-ambasador-usa-w-polsce-mark-brzezinski-6775488/alternates/LANDSCAPE_1280" />
    Mija rok od dnia, w którym Rosja rozpoczęła barbarzyńską napaść na Ukrainę - powiedział Mark Brzezinski w nagraniu opublikowanym w piątek.

## Poszedł odpocząć i już się nie obudził. 40-letni ratownik medyczny zmarł w trakcie dyżuru
 - [https://tvn24.pl/poznan/gorzow-wielkopolski-40-letni-ratownik-medyczny-zmarl-podczas-dyzuru-w-szpitalu-sledztwo-prokuratury-6775462?source=rss](https://tvn24.pl/poznan/gorzow-wielkopolski-40-letni-ratownik-medyczny-zmarl-podczas-dyzuru-w-szpitalu-sledztwo-prokuratury-6775462?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:25:47+00:00

<img alt="Poszedł odpocząć i już się nie obudził. 40-letni ratownik medyczny zmarł w trakcie dyżuru" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n6nui7-40-latek-byl-kierownikiem-zmiany-na-szpitalnym-oddziale-ratunkowym-6775452/alternates/LANDSCAPE_1280" />
    Prokuratura bada, co się stało.

## "Parlament Europejski potępia atak USA na Nord Stream"? Wyjaśniamy, jak powstał fałszywy przekaz
 - [https://konkret24.tvn24.pl/swiat/parlament-europejski-potepia-atak-usa-na-nord-stream-wyjasniamy-jak-powstal-falszywy-przekaz-6773617?source=rss](https://konkret24.tvn24.pl/swiat/parlament-europejski-potepia-atak-usa-na-nord-stream-wyjasniamy-jak-powstal-falszywy-przekaz-6773617?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:19:35+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ex6og-parlament-europejski-potepil-atak-usa-na-nord-stream-6773893/alternates/LANDSCAPE_1280" />
    Europarlament wcale nie decydował w tej sprawie, a kwestia odpowiedzialności Stanów Zjednoczonych padła w debacie i oparta jest na jednym, wątpliwym źródle.

## "GW": prokuratura bada, czy na konferencji ministrów pokazywano "treści pornograficzne"
 - [https://tvn24.pl/polska/drastyczne-zdjecia-na-konferencji-blaszczaka-kaminskiego-i-zaryna-w-sprawie-migrantow-na-granicy-sledztwo-prokuratury-6775112?source=rss](https://tvn24.pl/polska/drastyczne-zdjecia-na-konferencji-blaszczaka-kaminskiego-i-zaryna-w-sprawie-migrantow-na-granicy-sledztwo-prokuratury-6775112?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:11:42+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qojis2-mariusz-kaminski-i-mariusz-blaszczak-podczas-konferencji-prasowej-we-wrzesniu-2021-roku-6775056/alternates/LANDSCAPE_1280" />
    Chodzi o konferencję prasową z 2021 roku.

## Dokumenty o wizycie Bidena na prywatnym mailu policjanta? Rzecznik: incydent teleinformatyczny
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dokumenty-o-zabezpieczeniu-wizyty-joe-bidena-na-prywatnym-mailu-policjanta-6773224?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dokumenty-o-zabezpieczeniu-wizyty-joe-bidena-na-prywatnym-mailu-policjanta-6773224?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:08:46+00:00

<img alt="Dokumenty o wizycie Bidena na prywatnym mailu policjanta? Rzecznik: incydent teleinformatyczny" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-l26wth-policjanci-zabezpieczali-wizyte-joe-bidena-zdjecie-ilustracyjne-6773313/alternates/LANDSCAPE_1280" />
    "Czynności w sprawie prowadzi właściwy przełożony dyscyplinarny".

## Polacy zbierali na Bayraktara, ale pieniądze pójdą na inny cel
 - [https://tvn24.pl/polska/polski-bayraktar-trafil-do-ukrainy-pieniadze-zbierane-na-niego-sfinansuja-centrum-szkoleniowe-6775484?source=rss](https://tvn24.pl/polska/polski-bayraktar-trafil-do-ukrainy-pieniadze-zbierane-na-niego-sfinansuja-centrum-szkoleniowe-6775484?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 13:00:19+00:00

<img alt="Polacy zbierali na Bayraktara, ale pieniądze pójdą na inny cel" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lj3vmd-bayraktar-na-ktorego-polacy-zbierali-pieniadze-6669374/alternates/LANDSCAPE_1280" />
    Zbiórka społecznościowa.

## Przyszła odebrać klucze, nie chcieli opuścić mieszkania. Są oskarżeni o usiłowanie zabójstwa
 - [https://tvn24.pl/krakow/rzeszow-probowala-wejsc-do-mieszkania-zostala-postrzelona-do-sadu-trafil-akt-oskarzenia-6775133?source=rss](https://tvn24.pl/krakow/rzeszow-probowala-wejsc-do-mieszkania-zostala-postrzelona-do-sadu-trafil-akt-oskarzenia-6775133?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 12:56:41+00:00

<img alt="Przyszła odebrać klucze, nie chcieli opuścić mieszkania. Są oskarżeni o usiłowanie zabójstwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ttdsiy-miejsce-gdzie-doszlo-do-zdarzenia-6775490/alternates/LANDSCAPE_1280" />
    Jeden postrzelił Zuzannę, drugi psiknął gazem.

## Stracił panowanie nad autem i wpadł na prywatną posesję. Policja publikuje nagranie
 - [https://tvn24.pl/polska/starachowice-kierowca-dachowal-na-prywatnej-posesji-nagranie-z-monitoringu-6775148?source=rss](https://tvn24.pl/polska/starachowice-kierowca-dachowal-na-prywatnej-posesji-nagranie-z-monitoringu-6775148?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 12:52:42+00:00

<img alt="Stracił panowanie nad autem i wpadł na prywatną posesję. Policja publikuje nagranie" src="https://tvn24.pl/krakow/cdn-zdjecie-gd0tfi-kierowca-stracil-panowanie-nad-samochodem-6775123/alternates/LANDSCAPE_1280" />
    Swoją podróż audi zakończyło na dachu.

## Pies spadł na beton z drugiego piętra. Cudem przeżył. Miała go wyrzucić właścicielka
 - [https://tvn24.pl/bialystok/bialystok-jest-podejrzana-o-wyrzucenie-psa-z-drugiego-pietra-tlumaczyla-ze-byla-caly-dzien-w-mieszkaniu-6775091?source=rss](https://tvn24.pl/bialystok/bialystok-jest-podejrzana-o-wyrzucenie-psa-z-drugiego-pietra-tlumaczyla-ze-byla-caly-dzien-w-mieszkaniu-6775091?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 12:35:19+00:00

<img alt="Pies spadł na beton z drugiego piętra. Cudem przeżył. Miała go wyrzucić właścicielka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2mrw2r-pies-upadl-na-chodnik-6775369/alternates/LANDSCAPE_1280" />
    Grozi jej do pięciu lat więzienia.

## "Wszyscy tu jesteśmy. Bronimy niepodległości". Zełenski na ulicach Kijowa dzień po rozpoczęciu inwazji
 - [https://tvn24.pl/swiat/rok-temu-rosja-zaatakowala-ukraine-wystapienie-wolodymyra-zelenskiego-z-ulic-kijowa-dzien-po-rozpoczeciu-ataku-6775189?source=rss](https://tvn24.pl/swiat/rok-temu-rosja-zaatakowala-ukraine-wystapienie-wolodymyra-zelenskiego-z-ulic-kijowa-dzien-po-rozpoczeciu-ataku-6775189?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 12:31:56+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p2czde-wolodymyr-zelenski-wraz-z-innymi-przedstawicielami-wladz-na-ulicach-kijowa-6775259/alternates/LANDSCAPE_1280" />
    Wystąpienie prezydenta Ukrainy zarejestrowane 25 lutego 2022 roku miało pokazać rodakom, że nie wyjechał ze stolicy kraju.

## Była najmłodszą zwyciężczynią loterii. Wydała fortunę i wylądowała na zasiłku, ale nie żałuje
 - [https://tvn24.pl/ciekawostki/wielka-brytania-byla-najmlodsza-zwyciezczynia-brytyjskiej-loterii-wydala-cala-sume-teraz-chce-zostac-pielegniarka-6775044?source=rss](https://tvn24.pl/ciekawostki/wielka-brytania-byla-najmlodsza-zwyciezczynia-brytyjskiej-loterii-wydala-cala-sume-teraz-chce-zostac-pielegniarka-6775044?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 12:25:39+00:00

<img alt="Była najmłodszą zwyciężczynią loterii. Wydała fortunę i wylądowała na zasiłku, ale nie żałuje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hfa6xa-callie-rogers-w-2003-roku-6775048/alternates/LANDSCAPE_1280" />
    "W tym wieku możesz otrzymać najlepszą radę, ale nie potrafisz słuchać".

## Ta prehistoryczna ryba zjadała naszych przodków
 - [https://tvn24.pl/tvnmeteo/ciekawostki/ta-prehistoryczna-ryba-zjadala-naszych-przodkow-6773434?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/ta-prehistoryczna-ryba-zjadala-naszych-przodkow-6773434?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 12:24:20+00:00

<img alt="Ta prehistoryczna ryba zjadała naszych przodków" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-t4q066-gigantyczna-prehistoryczna-ryba-odkryta-w-afryce-poludniowej-6775214/alternates/LANDSCAPE_1280" />
    Polowała w rzekach położonych na superkontynencie Gondwana.

## Szczęśliwe losowanie Lecha
 - [https://eurosport.tvn24.pl/lech-unikn---pot-g--zagra-w-szwecji,1137516.html?source=rss](https://eurosport.tvn24.pl/lech-unikn---pot-g--zagra-w-szwecji,1137516.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 12:22:00+00:00

<img alt="Szczęśliwe losowanie Lecha" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gldlxb-lech-poznan-zagra-w-18-finalu-ligi-konferencji/alternates/LANDSCAPE_1280" />
    Uniknął potęg i pojedzie do Skandynawii.

## "Wycięto spawarką kawałek szyny". Media: wstrzymany ruch na moście Krymskim
 - [https://tvn24.pl/swiat/krym-ukraina-rosja-ruch-na-moscie-krymskim-wstrzymany-ktos-uszkodzil-tory-podaja-ukrainskie-media-6775165?source=rss](https://tvn24.pl/swiat/krym-ukraina-rosja-ruch-na-moscie-krymskim-wstrzymany-ktos-uszkodzil-tory-podaja-ukrainskie-media-6775165?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 11:52:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3jit3x-most-krymski-laczacy-anektowany-polwysep-z-rosja-5646178/alternates/LANDSCAPE_1280" />
    Most łączy zaanektowany Krym z kontynentalną częścią Rosji.

## Media: z Krymu nie ma ucieczki, ruch na moście wstrzymany
 - [https://tvn24.pl/najnowsze/krym-ukraina-rosja-ruch-na-moscie-krymskim-wstrzymany-prace-remontowe-podaja-ukrainskie-media-6775165?source=rss](https://tvn24.pl/najnowsze/krym-ukraina-rosja-ruch-na-moscie-krymskim-wstrzymany-prace-remontowe-podaja-ukrainskie-media-6775165?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 11:52:00+00:00

<img alt="Media: z Krymu nie ma ucieczki, ruch na moście wstrzymany " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3jit3x-most-krymski-laczacy-anektowany-polwysep-z-rosja-5646178/alternates/LANDSCAPE_1280" />
    Most łączy zaanektowany Krym z kontynentalną częścią Rosji.

## Wybuchy, czarne worki, dzieci bez rąk i nóg. Polscy medycy o "drodze do piekła"
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2306,S00E2306,1003615?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2306,S00E2306,1003615?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 11:51:08+00:00

<img alt="Wybuchy, czarne worki, dzieci bez rąk i nóg. Polscy medycy o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rxzl42-droga-do-piekla-reportaz-filipa-folczaka-6775311/alternates/LANDSCAPE_1280" />
    Kulisy pracy frontowych medyków w reportażu Filipa Folczaka "Droga do piekła".

## Kubacki gotowy do skakania w mistrzostwach świata
 - [https://eurosport.tvn24.pl/ulga-w-kadrze--kubacki-gotowy-do-skakania-w-mistrzostwach--wiata,1137501.html?source=rss](https://eurosport.tvn24.pl/ulga-w-kadrze--kubacki-gotowy-do-skakania-w-mistrzostwach--wiata,1137501.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 11:43:00+00:00

<img alt="Kubacki gotowy do skakania w mistrzostwach świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aom5s5-dawid-kubacki-jest-jednym-z-kandydatow-do-medali-w-planicy/alternates/LANDSCAPE_1280" />
    Ulga w kadrze.

## Powstaną kolejne filmy z serii "Władca Pierścieni" i "Hobbit". Co wiadomo o nowych produkcjach
 - [https://tvn24.pl/kultura-i-styl/wladca-pierscieni-i-hobbit-powstana-kolejne-filmy-z-serii-co-wiadomo-o-nowych-produkcjach-6775177?source=rss](https://tvn24.pl/kultura-i-styl/wladca-pierscieni-i-hobbit-powstana-kolejne-filmy-z-serii-co-wiadomo-o-nowych-produkcjach-6775177?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 11:32:53+00:00

<img alt="Powstaną kolejne filmy z serii " src="https://tvn24.pl/najnowsze/cdn-zdjecied41d8cd98f00b204e9800998ecf8427e-kadr-z-filmu-wladca-pierscieni-powrot-krola-3828949/alternates/LANDSCAPE_1280" />
    Poprzednie okazały się ogromnym sukcesem i zdobyły wiele nagród.

## Budowa CPK ma ruszyć lada moment. Wiceminister obiecuje korzystne warunki wykupu ziemi
 - [https://tvn24.pl/biznes/z-kraju/budowa-cpk-pierwsze-prace-budowlane-maja-ruszyc-latem-2023-roku-marcin-horala-o-terminie-startu-budowy-6774851?source=rss](https://tvn24.pl/biznes/z-kraju/budowa-cpk-pierwsze-prace-budowlane-maja-ruszyc-latem-2023-roku-marcin-horala-o-terminie-startu-budowy-6774851?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 11:27:43+00:00

<img alt="Budowa CPK ma ruszyć lada moment. Wiceminister obiecuje korzystne warunki wykupu ziemi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jbqrto-cpk-ma-powstac-na-terenie-gminy-baranow-5530437/alternates/LANDSCAPE_1280" />
    Marcin Horała w Radiu Katowice.

## Awans i kolejna premia. Już prawie siedem milionów euro w kasie Lecha
 - [https://eurosport.tvn24.pl/awans-i-kolejna-premia--ju--prawie-siedem-milion-w-euro-w-kasie-lecha,1137505.html?source=rss](https://eurosport.tvn24.pl/awans-i-kolejna-premia--ju--prawie-siedem-milion-w-euro-w-kasie-lecha,1137505.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 11:16:00+00:00

<img alt="Awans i kolejna premia. Już prawie siedem milionów euro w kasie Lecha" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8kmcnf-lech-poznan-zagra-w-18-finalu-ligi-konferencji/alternates/LANDSCAPE_1280" />
    W poznańskim klubie mają prawo świętować.

## Prezydent po posiedzeniu RBN: w sprawie Ukrainy wszyscy de facto mówimy jednym głosem
 - [https://tvn24.pl/polska/rada-bezpieczenstwa-narodowego-w-palacu-prezydenckim-andrzej-duda-w-sprawie-ukrainy-mowimy-jednym-glosem-6775215?source=rss](https://tvn24.pl/polska/rada-bezpieczenstwa-narodowego-w-palacu-prezydenckim-andrzej-duda-w-sprawie-ukrainy-mowimy-jednym-glosem-6775215?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 11:15:42+00:00

<img alt="Prezydent po posiedzeniu RBN: w sprawie Ukrainy wszyscy de facto mówimy jednym głosem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3oywcn-prezydent-6775826/alternates/LANDSCAPE_1280" />
    Spotkanie odbyło się w Pałacu Prezydenckim.

## Prezydent: premier pojechał do Kijowa zawieźć nasze Leopardy
 - [https://tvn24.pl/polska/polskie-czolgi-dla-ukrainy-prezydent-duda-premier-morawiecki-pojechal-do-kijowa-zawiezc-nasze-leopardy-6775215?source=rss](https://tvn24.pl/polska/polskie-czolgi-dla-ukrainy-prezydent-duda-premier-morawiecki-pojechal-do-kijowa-zawiezc-nasze-leopardy-6775215?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 11:15:42+00:00

<img alt="Prezydent: premier pojechał do Kijowa zawieźć nasze Leopardy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bnbvho-plansza-pilne-szeroki-drv-4712015/alternates/LANDSCAPE_1280" />
    Andrzej Duda na posiedzeniu Rady Bezpieczeństwa Narodowego.

## Trepanacja czaszki przeprowadzona trzy i pół tysiąca lat temu. Na co chorowali dwaj bracia
 - [https://tvn24.pl/tvnmeteo/nauka/archeologia-trepanacja-czaszki-przeprowadzona-trzy-i-pol-tysiaca-lat-temu-na-co-chorowali-dwaj-bracia-6772613?source=rss](https://tvn24.pl/tvnmeteo/nauka/archeologia-trepanacja-czaszki-przeprowadzona-trzy-i-pol-tysiaca-lat-temu-na-co-chorowali-dwaj-bracia-6772613?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:59:08+00:00

<img alt="Trepanacja czaszki przeprowadzona trzy i pół tysiąca lat temu. Na co chorowali dwaj bracia" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-idy646-szkielety-mezczyzn-pochowanych-w-grobowcu-w-megiddo-6774991/alternates/LANDSCAPE_1280" />
    Zabieg mógł być elementem leczenia "nadprzyrodzonych lub nieziemskich schorzeń".

## Był głową prawniczej dynastii, przyznał się do kłamstwa
 - [https://tvn24.pl/swiat/usa-oskarzony-o-zabicie-zony-i-syna-alex-murdaugh-przyznal-sie-do-klamstwa-6774963?source=rss](https://tvn24.pl/swiat/usa-oskarzony-o-zabicie-zony-i-syna-alex-murdaugh-przyznal-sie-do-klamstwa-6774963?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:56:00+00:00

<img alt="Był głową prawniczej dynastii, przyznał się do kłamstwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ayj14r-alex-murdaugh-prawnik-oskarzony-o-zabicie-zony-i-syna-6775069/alternates/LANDSCAPE_1280" />
    "Nie zabiłem swojej żony ani syna, nigdy, przenigdy".

## Artyści, dziennikarze, sportowcy, którzy zginęli w rosyjskiej inwazji
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-dzialacze-artysci-dziennikarze-sportowcy-ktorzy-zgineli-w-trakcie-rosyjskiej-inwazji-6774573?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-dzialacze-artysci-dziennikarze-sportowcy-ktorzy-zgineli-w-trakcie-rosyjskiej-inwazji-6774573?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:53:45+00:00

<img alt="Artyści, dziennikarze, sportowcy, którzy zginęli w rosyjskiej inwazji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7mymdb-zgineli-na-wojnie-w-ukrainie-6775174/alternates/LANDSCAPE_1280" />
    Przypominamy sylwetki niektórych postaci, które zapisały się na kartach historii.

## 15 firm z 8 państw zostało oskarżonych o wspieranie Rosji. Ukraiński urząd opublikował listę
 - [https://tvn24.pl/biznes/ze-swiata/ukraina-narodowa-agencja-ds-zapobiegania-korupcji-auchan-leroy-merlin-proctor-and-gamble-oskarzone-o-wspieranie-rosji-6774713?source=rss](https://tvn24.pl/biznes/ze-swiata/ukraina-narodowa-agencja-ds-zapobiegania-korupcji-auchan-leroy-merlin-proctor-and-gamble-oskarzone-o-wspieranie-rosji-6774713?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:50:06+00:00

<img alt="15 firm z 8 państw zostało oskarżonych o wspieranie Rosji. Ukraiński urząd opublikował listę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tscqbu-shutterstock358749644-6764632/alternates/LANDSCAPE_1280" />
    Raport NACP.

## Miał dwa promile i kierował ciężarówką. "Nie mógł utrzymać prostego toru jazdy". Nagranie
 - [https://tvn24.pl/lodz/tomaszow-mazowiecki-mial-ponad-dwa-promile-alkoholu-i-kierowal-ciezarowka-nie-mogl-utrzymac-prostego-toru-jazdy-nagranie-6775104?source=rss](https://tvn24.pl/lodz/tomaszow-mazowiecki-mial-ponad-dwa-promile-alkoholu-i-kierowal-ciezarowka-nie-mogl-utrzymac-prostego-toru-jazdy-nagranie-6775104?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:46:00+00:00

<img alt="Miał dwa promile i kierował ciężarówką. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z8ic5f-kierowal-ciezarowka-pod-wplywem-alkoholu-6775072/alternates/LANDSCAPE_1280" />
    Grozi mu do dwóch lat pozbawienia wolności.

## Śpiewała w schronie, teraz wystąpiła w TVN24. "Ja nie rozumiałam, co to jest wojna"
 - [https://tvn24.pl/najnowsze/spiewala-w-schronie-w-kijowie-piosenke-z-filmu-kraina-lodu-amelia-anisowicz-w-tvn24-6775022?source=rss](https://tvn24.pl/najnowsze/spiewala-w-schronie-w-kijowie-piosenke-z-filmu-kraina-lodu-amelia-anisowicz-w-tvn24-6775022?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:45:52+00:00

<img alt="Śpiewała w schronie, teraz wystąpiła w TVN24. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xe53sh-mam-te-moc-6774789/alternates/LANDSCAPE_1280" />
    Amelia Anisowicz zawitała do studia TVN24 w rocznicę rosyjskiej agresji na Ukrainę.

## Brytyjski resort obrony: Rosja po raz kolejny zmienia taktykę
 - [https://tvn24.pl/najnowsze/rosja-ukraina-wielka-brytania-ministerstwo-obrony-rosja-zmienia-taktyke-6774952?source=rss](https://tvn24.pl/najnowsze/rosja-ukraina-wielka-brytania-ministerstwo-obrony-rosja-zmienia-taktyke-6774952?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:35:11+00:00

<img alt="Brytyjski resort obrony: Rosja po raz kolejny zmienia taktykę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-96x3mu-rosyjscy-zolnierze-6759559/alternates/LANDSCAPE_1280" />
    Najnowszy komunikat ministerstwa obrony Wielkiej Brytanii.

## Kolejny duży bank zawiesza oferowanie części kredytów hipotecznych
 - [https://tvn24.pl/biznes/pieniadze/kredyty-mieszkaniowe-bank-millennium-od-010323-zawiesza-oferowanie-kredytow-hipotecznych-ze-zmiennym-oprocentowaniem-6775031?source=rss](https://tvn24.pl/biznes/pieniadze/kredyty-mieszkaniowe-bank-millennium-od-010323-zawiesza-oferowanie-kredytow-hipotecznych-ze-zmiennym-oprocentowaniem-6775031?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:30:45+00:00

<img alt="Kolejny duży bank zawiesza oferowanie części kredytów hipotecznych" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecief7dfb9fb2ceabfa262398dc3f472001f-jak-wyjasniono-planowane-polaczenie-jest-drugim-etapem-transakcji-dotyczacej-przejecia-euro-banku-przez-bank-millennium-4938919/alternates/LANDSCAPE_1280" />
    Podano termin.

## Kosztowny gol Lewandowskiego. Barca musi głębiej sięgnąć do kieszeni
 - [https://eurosport.tvn24.pl/kosztowny-gol-lewandowskiego--barca-musi-g--biej-si-gn---do-kieszeni,1137496.html?source=rss](https://eurosport.tvn24.pl/kosztowny-gol-lewandowskiego--barca-musi-g--biej-si-gn---do-kieszeni,1137496.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:30:00+00:00

<img alt="Kosztowny gol Lewandowskiego. Barca musi głębiej sięgnąć do kieszeni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hz2d9f-robert-lewandowski-strzelil-w-manchesterze-25-gola-w-sezonie/alternates/LANDSCAPE_1280" />
    Duma Katalonii odpadła z europejskich pucharów, ale płacić Bayernowi i tak musi.

## "Rok łez". Nagranie na rocznicę inwazji
 - [https://tvn24.pl/najnowsze/wolodymyr-zelenski-opublikowal-nagranie-z-okazji-rocznicy-agresji-rosji-na-ukraine-rok-lez-rok-bolu-rok-nadziei-6774936?source=rss](https://tvn24.pl/najnowsze/wolodymyr-zelenski-opublikowal-nagranie-z-okazji-rocznicy-agresji-rosji-na-ukraine-rok-lez-rok-bolu-rok-nadziei-6774936?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:18:21+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ltlcxz-year-6775066/alternates/LANDSCAPE_1280" />
    Film podsumowuje 12 miesięcy zmagań Ukrainy z agresją Rosji.

## Jeden kraj, ta sama wojna, a kompletnie inna rzeczywistość. "Poproszę 17 pizz. Chłopaki w okopach chcieli..."
 - [https://tvn24.pl/premium/jeden-kraj-ta-sama-wojna-a-kompletnie-inna-rzeczywistosc-poprosze-17-pizz-chlopaki-w-okopach-chcieli-6772809?source=rss](https://tvn24.pl/premium/jeden-kraj-ta-sama-wojna-a-kompletnie-inna-rzeczywistosc-poprosze-17-pizz-chlopaki-w-okopach-chcieli-6772809?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:07:21+00:00

<img alt="Jeden kraj, ta sama wojna, a kompletnie inna rzeczywistość. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-i8d2oc-ukrainscy-zolnierze-w-odessie-6771566/alternates/LANDSCAPE_1280" />
    W Kramatorsku, na wschodzie Ukrainy, słychać artylerię strzelającą na froncie, a rosyjskie rakiety zabijają mieszańców. Niedawno jeszcze przyjemne miasto przekształciło się w bazę wojskową. W Rachowie, 1300 km na zachód, wojny nie słychać, a nawet nie czuć. Niektórzy twierdzą, że ta wojna to nie ich sprawa.

## Jeden kraj, ta sama wojna, a kompletnie inna rzeczywistość. "Poproszę 17 pizz. Chłopaki w okopach chcieli..."
 - [https://tvn24.pl/premium/rok-wojny-w-ukrainie-jeden-kraj-ta-sama-wojna-a-kompletnie-inna-rzeczywistosc-poprosze-17-pizz-chlopaki-w-okopach-chcieli-6772809?source=rss](https://tvn24.pl/premium/rok-wojny-w-ukrainie-jeden-kraj-ta-sama-wojna-a-kompletnie-inna-rzeczywistosc-poprosze-17-pizz-chlopaki-w-okopach-chcieli-6772809?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 10:07:21+00:00

<img alt="Jeden kraj, ta sama wojna, a kompletnie inna rzeczywistość. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4qqdw5-mikolajow-w-ukrainie-10-marca-2022-6774945/alternates/LANDSCAPE_1280" />
    W Kramatorsku, na wschodzie Ukrainy, słychać artylerię strzelającą na froncie, a rosyjskie rakiety zabijają mieszańców. Niedawno jeszcze przyjemne miasto przekształciło się w bazę wojskową. W Rachowie, 1300 km na zachód, wojny nie słychać, a nawet nie czuć. Niektórzy twierdzą, że ta wojna to nie ich sprawa.

## Od "operacji specjalnej" do "wojny ojczyźnianej". Ewolucja kremlowskiej propagandy
 - [https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-od-operacji-specjalnej-do-wojny-ojczyznianej-ewolucja-kremlowskiej-propagandy-6771416?source=rss](https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-od-operacji-specjalnej-do-wojny-ojczyznianej-ewolucja-kremlowskiej-propagandy-6771416?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 09:31:26+00:00

<img alt="Od " src="https://tvn24.pl/najnowsze/cdn-zdjecie-a18ft8-od-operacji-specjalnej-do-wojny-ojczyznianej-ewolucja-kremlowskiej-propagandy-6771411/alternates/LANDSCAPE_1280" />
    Przez rok od rozpoczęcia inwazji Rosji na Ukrainę wiele się zmieniło w rosyjskiej propagandzie.

## Kubacki po badaniach
 - [https://eurosport.tvn24.pl/kubacki-po-badaniach---szanse-na-start-mocno-uros-y-,1137510.html?source=rss](https://eurosport.tvn24.pl/kubacki-po-badaniach---szanse-na-start-mocno-uros-y-,1137510.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 09:25:00+00:00

<img alt="Kubacki po badaniach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nky5g5-dawid-kubacki-jest-jednym-z-kandydatow-do-medali-w-planicy/alternates/LANDSCAPE_1280" />
    Najnowsze informacje prosto z Planicy.

## Matka wierzy w rosyjską propagandę, gdy jej córka i wnuki chowają się przed bombami
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2278,S00E2278,800778?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2278,S00E2278,800778?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 09:12:00+00:00

<img alt="Matka wierzy w rosyjską propagandę, gdy jej córka i wnuki chowają się przed bombami " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yehdpb-wojna-w-rodzinie-reportaz-czarno-na-bialym-5759228/alternates/LANDSCAPE_1280" />
    Przypominamy reportaż "Wojna w rodzinie" Małgorzaty Prochal.

## Morawiecki: Polska przekazuje cztery pierwsze Leopardy. Zełenski: te czołgi są już w Ukrainie
 - [https://tvn24.pl/swiat/ukraina-morawiecki-w-kijowie-polska-przekazuje-ukrainie-cztery-pierwsze-czolgi-leopard-2-a4-wkrotce-dostarczymy-kolejne-6774831?source=rss](https://tvn24.pl/swiat/ukraina-morawiecki-w-kijowie-polska-przekazuje-ukrainie-cztery-pierwsze-czolgi-leopard-2-a4-wkrotce-dostarczymy-kolejne-6774831?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 08:28:30+00:00

<img alt="Morawiecki: Polska przekazuje cztery pierwsze Leopardy. Zełenski: te czołgi są już w Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-azx4cl-morawiecki-zelenski-6775454/alternates/LANDSCAPE_1280" />
    Spotkanie w Kijowie w pierwszą rocznicę rosyjskiej agresji.

## Premier Morawiecki w Kijowie
 - [https://tvn24.pl/polska/ukraina-morawiecki-w-kijowie-niezapowiedziana-wizyta-premiera-spotkanie-z-zelenskim-6774831?source=rss](https://tvn24.pl/polska/ukraina-morawiecki-w-kijowie-niezapowiedziana-wizyta-premiera-spotkanie-z-zelenskim-6774831?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 08:28:30+00:00

<img alt="Premier Morawiecki w Kijowie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tpombp-morawiecki-w-kijowie-6774854/alternates/LANDSCAPE_1280" />
    W pierwszą rocznicę agresji Rosji na Ukrainę.

## Pożar dwóch ciężarówek po zderzeniu. Nie żyje jeden z kierowców
 - [https://tvn24.pl/lodz/wieruszow-droga-ekspresowa-s8-pozar-dwoch-ciezarowek-nie-zyje-jeden-z-kierowcow-6774792?source=rss](https://tvn24.pl/lodz/wieruszow-droga-ekspresowa-s8-pozar-dwoch-ciezarowek-nie-zyje-jeden-z-kierowcow-6774792?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 08:08:18+00:00

<img alt="Pożar dwóch ciężarówek po zderzeniu. Nie żyje jeden z kierowców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-534i41-pozar-dwoch-ciezarowek-na-s8-nie-zyje-jeden-z-kierowcow-6774768/alternates/LANDSCAPE_1280" />
    Drugiemu z kierujących nic się nie stało.

## 12 punktów od Chin dla Moskwy i Kijowa. Opublikowano dokument
 - [https://tvn24.pl/swiat/chiny-apeluja-do-rosji-i-ukrainy-o-rozpoczecie-rozmow-chinskie-msz-wydalo-dokument-12-punktow-6774647?source=rss](https://tvn24.pl/swiat/chiny-apeluja-do-rosji-i-ukrainy-o-rozpoczecie-rozmow-chinskie-msz-wydalo-dokument-12-punktow-6774647?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 07:58:37+00:00

<img alt="12 punktów od Chin dla Moskwy i Kijowa. Opublikowano dokument" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h6ljtb-wang-yi-w-moskwie-6773960/alternates/LANDSCAPE_1280" />
    Chińskie władze wzywają między innymi do wznowienia dialogu.

## Deszczyca: nagle rano dostałem telefon od córki, że widzi wybuchy, ludzi, którzy wyjeżdżają
 - [https://tvn24.pl/swiat/rocznica-inwazji-rosji-na-ukraine-andrij-deszczyca-i-andrij-sadowy-wspominaja-dzien-rozpoczecia-agresji-6774696?source=rss](https://tvn24.pl/swiat/rocznica-inwazji-rosji-na-ukraine-andrij-deszczyca-i-andrij-sadowy-wspominaja-dzien-rozpoczecia-agresji-6774696?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 07:35:00+00:00

<img alt="Deszczyca: nagle rano dostałem telefon od córki, że widzi wybuchy, ludzi, którzy wyjeżdżają" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5qzfyu-1n1-2-6774671/alternates/LANDSCAPE_1280" />
    Były ambasador Ukrainy w Polsce Andrij Deszczyca i mer Lwowa Andrij Sadowy w "Jeden na jeden" w TVN24.

## Deszczyca: nagle rano dostałem telefon od córki, że widzi wybuchy, ludzi, którzy wyjeżdżają
 - [https://tvn24.pl/swiat/rocznica-inwazji-rosji-na-ukraine-andrij-deszczycia-i-andrij-sadowy-wspominaja-dzien-rozpoczecia-agresji-6774696?source=rss](https://tvn24.pl/swiat/rocznica-inwazji-rosji-na-ukraine-andrij-deszczycia-i-andrij-sadowy-wspominaja-dzien-rozpoczecia-agresji-6774696?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 07:35:00+00:00

<img alt="Deszczyca: nagle rano dostałem telefon od córki, że widzi wybuchy, ludzi, którzy wyjeżdżają" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5qzfyu-1n1-2-6774671/alternates/LANDSCAPE_1280" />
    Były ambasador Ukrainy w Polsce Andrij Deszczyca i mer Lwowa Andrij Sadowy w "Jeden na jeden" w TVN24.

## Skandal w Lidze Europy. Kibic rzucił się z pięściami na piłkarza
 - [https://eurosport.tvn24.pl/skandal-w-lidze-europy--kibic-rzuci--si--z-pi--ciami-na-pi-karza,1137497.html?source=rss](https://eurosport.tvn24.pl/skandal-w-lidze-europy--kibic-rzuci--si--z-pi--ciami-na-pi-karza,1137497.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 07:25:00+00:00

<img alt="Skandal w Lidze Europy. Kibic rzucił się z pięściami na piłkarza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a5uteq-marko-dmitrovic-zaatakowany-przez-kibica-psv/alternates/LANDSCAPE_1280" />
    Budzące grozę sceny w Eindhoven.

## "Amelka jak wraca ze szkoły, to siedzi w rękawiczkach"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-problem-ubostwa-energetycznego-narasta-6774640?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-problem-ubostwa-energetycznego-narasta-6774640?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 07:14:19+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6esopd-ubodzy-energetycznie-sa-wsrod-nas-takze-w-duzych-miastach-6774418/alternates/LANDSCAPE_1280" />
    Ubóstwo energetyczne w Warszawie.

## Śmiał się przed samym skokiem. Żyła wiedział, że zostanie mistrzem świata
 - [https://eurosport.tvn24.pl/skoki-narciarskie,408/skoki-narciarskie-oberstdorf-2021-konkurs-indywidualny-na-skoczni-normalnej-ms-2021-szalona-radosc-piotra-zyly,1137057.html?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie,408/skoki-narciarskie-oberstdorf-2021-konkurs-indywidualny-na-skoczni-normalnej-ms-2021-szalona-radosc-piotra-zyly,1137057.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 07:10:13+00:00

<img alt="Śmiał się przed samym skokiem. Żyła wiedział, że zostanie mistrzem świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ieykza-piotr-zyla-przed-skokiem-po-mistrzostwo-swiata-6774700/alternates/LANDSCAPE_1280" />
    Dwa lata temu w Oberstdorfie Piotr Żyła przed finałową próbą, gdy siedział na belce, długo się uśmiechał.

## Kłopoty założyciela upadłej giełdy. Miał dokonać ponad 300 nielegalnych darowizn dla polityków
 - [https://tvn24.pl/biznes/ze-swiata/sam-bankman-fried-kolejne-zarzuty-wobec-zalozyciela-upadlej-gieldy-ftx-mial-dokonac-ponad-300-nielegalnych-darowizn-politycznych-6774609?source=rss](https://tvn24.pl/biznes/ze-swiata/sam-bankman-fried-kolejne-zarzuty-wobec-zalozyciela-upadlej-gieldy-ftx-mial-dokonac-ponad-300-nielegalnych-darowizn-politycznych-6774609?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 07:09:38+00:00

<img alt="Kłopoty założyciela upadłej giełdy. Miał dokonać ponad 300 nielegalnych darowizn dla polityków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4ovdd7-sam-bankman-fried-6774620/alternates/LANDSCAPE_1280" />
    Cztery nowe zarzuty karne.

## Orlen podał wyniki finansowe za 2022 rok. Ogromny zysk
 - [https://tvn24.pl/biznes/z-kraju/orlen-wyniki-finansowe-za-2022-rok-ogromny-zysk-6774642?source=rss](https://tvn24.pl/biznes/z-kraju/orlen-wyniki-finansowe-za-2022-rok-ogromny-zysk-6774642?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 06:42:21+00:00

<img alt="Orlen podał wyniki finansowe za 2022 rok. Ogromny zysk" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-oxyg4r-orlen-olefiny-6171443/alternates/LANDSCAPE_1280" />
    Jest komentarz prezesa PKN Orlen Daniela Obajtka.

## "To zmieni dynamikę na polu bitwy"
 - [https://tvn24.pl/swiat/rosja-ukraina-rocznica-wojny-inwazji-zbrojnej-usa-zwiekszaja-pomoc-wojskowa-dla-ukrainy-6774614?source=rss](https://tvn24.pl/swiat/rosja-ukraina-rocznica-wojny-inwazji-zbrojnej-usa-zwiekszaja-pomoc-wojskowa-dla-ukrainy-6774614?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 06:41:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pptmkk-ukrainski-zolnierz-pod-mikolajowem-6772804/alternates/LANDSCAPE_1280" />
    Dwa dodatkowe miliardy dolarów.

## "Rok bólu, żalu, wiary i jedności". Przesłanie Zełenskiego
 - [https://tvn24.pl/swiat/rocznica-inwazji-rosji-na-ukraine-wolodymyr-zelenski-to-byl-rok-bolu-zalu-wiary-i-jednosci-6774634?source=rss](https://tvn24.pl/swiat/rocznica-inwazji-rosji-na-ukraine-wolodymyr-zelenski-to-byl-rok-bolu-zalu-wiary-i-jednosci-6774634?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 06:34:24+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j93o2t-prezydent-ukrainy-wolodymyr-zelenski-6768779/alternates/LANDSCAPE_1280" />
    Prezydent Ukrainy w rocznicę rozpoczęcia pełnoskalowej agresji Rosji na jego kraj.

## Dziewięć kopalń w Polsce do zamknięcia? Górniczy gigant boi się nowych przepisów
 - [https://tvn24.pl/biznes/najnowsze/polska-grupa-gornicza-boi-sie-nowych-unijnych-przepisow-6773799?source=rss](https://tvn24.pl/biznes/najnowsze/polska-grupa-gornicza-boi-sie-nowych-unijnych-przepisow-6773799?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 06:33:02+00:00

<img alt="Dziewięć kopalń w Polsce do zamknięcia? Górniczy gigant boi się nowych przepisów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dlxtoh-1211go-korczu-wegiel-arch-0035-1-6220894/alternates/LANDSCAPE_1280" />
    Szef PGG liczy, że proponowane przepisy nie wejdą w życie.

## "Kryzys w Europie trwa", " Lewandowski i koledzy będą mieć więcej czasu, by skupić się na lidze"
 - [https://eurosport.tvn24.pl/-kryzys-w-europie-trwa-----lewandowski-i-koledzy-b-d--mie--wi-cej-czasu--by-skupi--si--na-lidze-,1137493.html?source=rss](https://eurosport.tvn24.pl/-kryzys-w-europie-trwa-----lewandowski-i-koledzy-b-d--mie--wi-cej-czasu--by-skupi--si--na-lidze-,1137493.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 06:27:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dqkm4r-barcelona-przegrala-na-old-trafford-z-manchesterem/alternates/LANDSCAPE_1280" />
    FC Barcelona już poza pucharami na Starym Kontynencie. Czwartek w Manchesterze był dla niej fatalny.

## Koszmar na korcie. Rywalka Linette nie była w stanie dokończyć meczu
 - [https://eurosport.tvn24.pl/koszmar-na-korcie--rywalka-linette-nie-by-a-w-stanie-doko-czy--meczu,1137495.html?source=rss](https://eurosport.tvn24.pl/koszmar-na-korcie--rywalka-linette-nie-by-a-w-stanie-doko-czy--meczu,1137495.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 06:12:00+00:00

<img alt="Koszmar na korcie. Rywalka Linette nie była w stanie dokończyć meczu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0bid68-udvardy-nie-byla-w-stanie-grac-dalej/alternates/LANDSCAPE_1280" />
    Panna Udvardy z Węgier zaczęła świetnie grać i wtedy przydarzyła jej się bolesna kontuzja.

## Ukraińcy zakładają w Polsce firmy. Ponad 40 procent założyły kobiety
 - [https://tvn24.pl/biznes/z-kraju/ukraincy-zakladaja-w-polsce-firmy-w-ciagu-roku-ponad-177-tysiecy-6774547?source=rss](https://tvn24.pl/biznes/z-kraju/ukraincy-zakladaja-w-polsce-firmy-w-ciagu-roku-ponad-177-tysiecy-6774547?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:59:51+00:00

<img alt="Ukraińcy zakładają w Polsce firmy. Ponad 40 procent założyły kobiety" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wa3q7e-terakota-remont-shutterstock1211013052-6730377/alternates/LANDSCAPE_1280" />
    Dane CEIDG.

## Wojna i ataki wciąż trwają, ale są obrazy, które napawają optymizmem
 - [https://tvn24.pl/swiat/ukraina-rocznica-inwazji-rosji-fotografie-odbudowywanej-ukrainy-ktore-napawaja-optymizmem-6771306?source=rss](https://tvn24.pl/swiat/ukraina-rocznica-inwazji-rosji-fotografie-odbudowywanej-ukrainy-ktore-napawaja-optymizmem-6771306?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:45:00+00:00

<img alt="Wojna i ataki wciąż trwają, ale są obrazy, które napawają optymizmem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u4qerc-ola-drv-6774070/alternates/LANDSCAPE_1280" />
    Ukraina stara się stanąć na nogi. Pokazuje to między innymi tych kilkanaście fotografii.

## Seria produktu leczniczego wycofana z obrotu. Ryzyko zanieczyszczenia szkłem
 - [https://tvn24.pl/biznes/z-kraju/adrenalin-osel-gif-wycofuje-adrenaline-z-powodu-ryzyka-zanieczyszczenia-szklem-6774350?source=rss](https://tvn24.pl/biznes/z-kraju/adrenalin-osel-gif-wycofuje-adrenaline-z-powodu-ryzyka-zanieczyszczenia-szklem-6774350?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:33:04+00:00

<img alt="Seria produktu leczniczego wycofana z obrotu. Ryzyko zanieczyszczenia szkłem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-byaac7-apteki-narzekaja-na-zbyt-wysokie-oplaty-5689101/alternates/LANDSCAPE_1280" />
    Decyzja GIF.

## Bez głównej wygranej w Lotto. Kumulacja rośnie
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-zdnia-230223-liczby-z-ostatniego-losowania-6774535?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-zdnia-230223-liczby-z-ostatniego-losowania-6774535?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:28:04+00:00

<img alt="Bez głównej wygranej w Lotto. Kumulacja rośnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oslmyw-lotto-s-shutterstock275295956-5128640/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## Intensywne opady śniegu, lód na drogach, silny wiatr. Żółte alerty IMGW
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-sniegu-oblodzenie-silny-wiatr-pogoda-na-weekend-6774529?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-sniegu-oblodzenie-silny-wiatr-pogoda-na-weekend-6774529?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:24:55+00:00

<img alt="Intensywne opady śniegu, lód na drogach, silny wiatr. Żółte alerty IMGW" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-y0ugv8-intensywne-opady-sniegu-6722495/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie obowiązują ostrzeżenia.

## Opady marznące, gołoledź. Ślisko i niebezpiecznie w części kraju
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-oblodzenie-opady-marznace-niebezpieczna-pogoda-w-czesci-kraju-pogoda-w-piatek-2402-6774529?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-oblodzenie-opady-marznace-niebezpieczna-pogoda-w-czesci-kraju-pogoda-w-piatek-2402-6774529?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:24:55+00:00

<img alt="Opady marznące, gołoledź. Ślisko i niebezpiecznie w części kraju" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie433a1a2327cb97e0563f62692baee096-marznace-opady-i-gololedz-4540890/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie obowiązują alarmy.

## W części kraju może nasypać 20 centymetrów śniegu. Alerty IMGW
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-sniegu-i-sliskie-drogi-pogoda-na-weekend-6774529?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-sniegu-i-sliskie-drogi-pogoda-na-weekend-6774529?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:24:55+00:00

<img alt="W części kraju może nasypać 20 centymetrów śniegu. Alerty IMGW" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8fmov1-opady-sniegu-4292623/alternates/LANDSCAPE_1280" />
    Synoptycy ostrzegają również przed śliskimi nawierzchniami dróg.

## "Zimny prysznic". Norweskie media komentują sukces Lecha
 - [https://eurosport.tvn24.pl/-zimny-prysznic---norweskie-media-komentuj--sukces-lecha,1137491.html?source=rss](https://eurosport.tvn24.pl/-zimny-prysznic---norweskie-media-komentuj--sukces-lecha,1137491.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:14:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oryuse-lech-wyeliminowal-bodoeglimt-z-ligi-konferencji/alternates/LANDSCAPE_1280" />
    Nie kryją rozczarowania porażką Bodoe/Glimt w Poznaniu.

## Próbowali ukraść samochód na oczach policjantów
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wola-chcieli-ukrasc-honde-dzialali-na-oczach-policjantow-6773196?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wola-chcieli-ukrasc-honde-dzialali-na-oczach-policjantow-6773196?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:08:43+00:00

<img alt="Próbowali ukraść samochód na oczach policjantów " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-k9zyxo-policja-bada-sprawe-6062482/alternates/LANDSCAPE_1280" />
    W Warszawie.

## Rosyjskie zbrodnie, tragedia Ukrainy
 - [https://tvn24.pl/swiat/ukraina-rok-wojny-rosji-przeciw-ukrainie-6774521?source=rss](https://tvn24.pl/swiat/ukraina-rok-wojny-rosji-przeciw-ukrainie-6774521?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 05:00:00+00:00

<img alt="Rosyjskie zbrodnie, tragedia Ukrainy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ul1v8e-ulica-w-wyzwolonej-z-rak-rosjan-buczy-6-kwietnia-2022-6774514/alternates/LANDSCAPE_1280" />
    Rok od rozpoczęcia inwazji Rosji.

## Europejskie stolice solidarne z Ukrainą
 - [https://tvn24.pl/swiat/ukraina-rocznica-rosyjskiej-inwazji-europejskie-stolice-solidarne-z-ukraina-6774500?source=rss](https://tvn24.pl/swiat/ukraina-rocznica-rosyjskiej-inwazji-europejskie-stolice-solidarne-z-ukraina-6774500?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 04:42:39+00:00

<img alt="Europejskie stolice solidarne z Ukrainą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qggrjn-wieza-eiffla-w-pierwsza-rocznice-ataku-rosji-na-ukraine-6774488/alternates/LANDSCAPE_1280" />
    W rocznicę rosyjskiej inwazji.

## "Opowiadali: właśnie coś spadło mi na głowę", "niektórzy się rozklejali, bo jak długo możesz patrzeć na trupy?"
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2305,S00E2305,1002635?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2305,S00E2305,1002635?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 04:30:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f4k22n-poczatek-zbrodni-ekipa-tvn24-o-pracy-podczas-wojny-6774439/alternates/LANDSCAPE_1280" />
    Pokazujemy, jak wyglądała praca w TVN24 i tvn24.pl po tym, jak Putin rozpoczął inwazję w Ukrainie.

## "Doświadczenie ma być w cenie". Na razie nie jest, pielęgniarki protestują
 - [https://tvn24.pl/programy/tarnow-protest-pielegniarek-domagaja-sie-podwyzek-6774434?source=rss](https://tvn24.pl/programy/tarnow-protest-pielegniarek-domagaja-sie-podwyzek-6774434?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 04:26:15+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y5w5lp-protest-pielegniarek-6774417/alternates/LANDSCAPE_1280" />
    "Gdzie są nasze pieniądze" - pytają pielęgniarki z całej Polski.

## Kiedy śmierć daje życie
 - [https://tvn24.pl/programy/transplantologia-przeszczep-od-jednego-dawcy-do-dwoch-niespokrewnionych-biorcow-6774448?source=rss](https://tvn24.pl/programy/transplantologia-przeszczep-od-jednego-dawcy-do-dwoch-niespokrewnionych-biorcow-6774448?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 04:25:31+00:00

<img alt="Kiedy śmierć daje życie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z3nlg3-kiedy-smierc-daje-zycie-6774449/alternates/LANDSCAPE_1280" />
    Jeden dawca dla dwóch niespokrewnionych biorców. Taką transplantację udało się przeprowadzić w Warszawie.

## "Kierunek Mariupol nie jest już dla nas całkowicie nieosiągalny"
 - [https://tvn24.pl/swiat/ukraina-rosja-ukrainska-armia-kierunek-mariupol-nie-jest-juz-dla-nas-nieosiagalny-6774375?source=rss](https://tvn24.pl/swiat/ukraina-rosja-ukrainska-armia-kierunek-mariupol-nie-jest-juz-dla-nas-nieosiagalny-6774375?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 04:24:23+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jj4ke8-ukraina-wojsko-6754675/alternates/LANDSCAPE_1280" />
    Oświadczyła rzeczniczka ukraińskich sił zbrojnych na południu kraju Natalia Humeniuk.

## USA zwiększają pomoc wojskową dla Ukrainy
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-24-lutego-2023-6774523?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-24-lutego-2023-6774523?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 04:20:23+00:00

<img alt="USA zwiększają pomoc wojskową dla Ukrainy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pptmkk-ukrainski-zolnierz-pod-mikolajowem-6772804/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/atak-rosji-na-ukraine-najwazniejsze-wydarzenia-ostatnich-godzin-24-lutego-2023-6774519?source=rss](https://tvn24.pl/swiat/atak-rosji-na-ukraine-najwazniejsze-wydarzenia-ostatnich-godzin-24-lutego-2023-6774519?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-24 04:16:00+00:00

<img alt="Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zfrseo-szkolenie-zolnierzy-ukrainskiej-panstwowej-sluzby-granicznej-6774520/alternates/LANDSCAPE_1280" />
    Mija rok od początku pełnoskalowej agresji Rosji na Ukrainę

