# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## James Webb Telescope reveals massive galaxies formed shortly after the Big Bang
 - [https://www.lemonde.fr/en/science/article/2023/02/24/james-webb-telescope-reveals-massive-galaxies-formed-shortly-after-the-big-bang_6017122_10.html](https://www.lemonde.fr/en/science/article/2023/02/24/james-webb-telescope-reveals-massive-galaxies-formed-shortly-after-the-big-bang_6017122_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-02-24 10:56:33+00:00

The observation of 13 distant galaxies dated 500 to 700 million years after the birth of the universe contradicts theories on the formation of these particularly massive collections of stars.

