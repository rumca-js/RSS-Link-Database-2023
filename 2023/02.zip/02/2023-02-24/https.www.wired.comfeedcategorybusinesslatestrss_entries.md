# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Who Should You Believe When Chatbots Go Wild?
 - [https://www.wired.com/story/plaintext-who-should-you-believe-when-chatbots-go-wild/](https://www.wired.com/story/plaintext-who-should-you-believe-when-chatbots-go-wild/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-24 14:00:00+00:00

Microsoft and others ask us to ignore their glitchy bots’ pleas for personhood. But we need better explanations—and guardrails.

## Amazon Has a Donkey Meat Problem
 - [https://www.wired.com/story/amazon-donkey-meat-california/](https://www.wired.com/story/amazon-donkey-meat-california/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-24 12:00:00+00:00

The online retailer sells products meant for human consumption that contain donkey meat. A new lawsuit claims that’s illegal in California.

## Ukraine’s War Brings Autonomous Weapons to the Front Lines
 - [https://www.wired.com/story/ukraine-war-autonomous-weapons-frontlines/](https://www.wired.com/story/ukraine-war-autonomous-weapons-frontlines/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-24 12:00:00+00:00

Drones that can find their own targets already exist, making machine-versus-machine conflict just a software update away.

## How Ukraine’s Trains Kept Running Despite Bombs, Blackouts, and Biden
 - [https://www.wired.com/story/how-ukraines-trains-kept-running-despite-bombs-blackouts-and-biden/](https://www.wired.com/story/how-ukraines-trains-kept-running-despite-bombs-blackouts-and-biden/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-24 09:00:00+00:00

Since Russia’s full-scale assault began, Ukraine’s railways evacuated 4 million people and brought 300 foreign delegations to Kyiv.

