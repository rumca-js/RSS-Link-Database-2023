# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## New Lord Of The Rings Films🎥 A.I. Ruining Publishing🤖 Classic Literature Censored🔇 ~FANTASY NEWS
 - [https://www.youtube.com/watch?v=Z-EjCVww4Z8](https://www.youtube.com/watch?v=Z-EjCVww4Z8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2023-02-24 14:55:42+00:00

Let's Jump Into The Fantasy News! 
Use GREENE to get 55% off your first month at Scentbird https://sbird.co/3jCScHr 

This month I received...
Magnetic Wood EDP by The Harmonist https://sbird.co/3RJY4LK 
East 12th by Ash by Ashley Benson https://sbird.co/40AVYBJ 
Ormonde Man by Ormonde Jayne https://sbird.co/3jH1W3e 

 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene


Merch: https://www.danielbgreene.com 


Lawful Times Series: 
Breach of Peace: https://tinyurl.com/BoPTLT 
Rebels Creed: https://tinyurl.com/RCTLTDG


Equipment: 
Camera: https://amzn.to/3siqgHv  
Lens: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  


P.O. Box: PO Box 7874 Henrico, VA 23231


NEWS:


00:00 New Lord of The Rings Movies: https://www.hollywoodreporter.com/movies/movie-news/lord-of-the-rings-new-movies-in-the-works-1235332695/ 


01:45 Lilo and Stich Live Action: Lilo and Stich Live Action: https://www.hollywoodreporter.com/movies/movie-news/lilo-and-stitch-live-action-movie-remake-zach-galifianakis-1235328908/  


02:37 Scentbird: https://sbird.co/3jCScHr 


04:12 Shadow and Bone Trailer/ alleged art theft: https://erandraws.tumblr.com/post/709447709945380864/hi-netflix-thank-you-for-stealing-my-art-concept#notes 


https://www.youtube.com/watch?v=0dOmcdz-PN0


04:50 Wheel of Time Interview: https://www.leftlion.co.uk/read/2023/february/marcus-rutherford 


05:44 New Discworld books:  https://terrypratchett.com/discworld/brand-new-covers-revealed/


06:15 AI Ruining Publishing: https://twitter.com/clarkesworld/status/1627711728245960704?s=20 
https://archive.is/C5OOY 
https://twitter.com/ShackletonCI/status/1627730312925966336?t=sQeVIxuVGLlsYq3ibxB-PA&amp;s=19 


07:51 New LotR Games: https://twitter.com/FellowshipFans/status/1626209204624031746?t=FGO89FhiBGkSXHcxS5O9Rg&amp;s=19  


08:22 Censoring Classic Literature:

