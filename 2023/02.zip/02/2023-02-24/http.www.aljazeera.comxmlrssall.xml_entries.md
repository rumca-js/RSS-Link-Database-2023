# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Why is the Alex Murdaugh trial captivating US audiences?
 - [https://www.aljazeera.com/news/2023/2/24/why-is-the-alex-murdaugh-trial-captivating-audiences-in-the-us](https://www.aljazeera.com/news/2023/2/24/why-is-the-alex-murdaugh-trial-captivating-audiences-in-the-us)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 22:44:33+00:00

The 54-year-old South Carolina attorney has been accused of murdering his wife and son at their rural hunting lodge.

## Obi supporters in home state have high hopes for Nigeria election
 - [https://www.aljazeera.com/news/2023/2/24/obi-supporters-in-home-state-have-high-hopes-for-nigeria-election](https://www.aljazeera.com/news/2023/2/24/obi-supporters-in-home-state-have-high-hopes-for-nigeria-election)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 21:20:51+00:00

Peter Obi is being projected by multiple polls to win the race to replace outgoing President Muhammadu Buhari.

## Democrat-led states challenge US over abortion pill restrictions
 - [https://www.aljazeera.com/news/2023/2/24/democrat-led-states-challenge-us-over-abortion-pill-restrictions](https://www.aljazeera.com/news/2023/2/24/democrat-led-states-challenge-us-over-abortion-pill-restrictions)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 20:43:09+00:00

Twelve states join a lawsuit alleging the US government has placed unnecessary restrictions on mifepristone.

## One year into Russian invasion, Ukraine’s Zelenskyy vows victory
 - [https://www.aljazeera.com/news/2023/2/24/one-year-into-invasion-ukraine-mourns-vows-victory](https://www.aljazeera.com/news/2023/2/24/one-year-into-invasion-ukraine-mourns-vows-victory)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 20:38:27+00:00

President Volodymyr Zelenskyy says the beginning of the Russian invasion was &#039;the longest day of our lives&#039;.

## Who is behind Russia’s Wagner Group?
 - [https://www.aljazeera.com/program/inside-story/2023/2/24/who-is-behind-russias-wagner-group](https://www.aljazeera.com/program/inside-story/2023/2/24/who-is-behind-russias-wagner-group)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 19:39:49+00:00

A dispute with the Russian Ministry of Defence has revealed the extent of the mercenary group&#039;s role in Ukraine.

## Winter storm brings heavy rain, rare snow to parts of California
 - [https://www.aljazeera.com/news/2023/2/24/winter-storm-brings-snow-and-rain-to-california](https://www.aljazeera.com/news/2023/2/24/winter-storm-brings-snow-and-rain-to-california)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 18:17:43+00:00

Authorities warn residents that severe weather, including blizzards, could create dangerous driving conditions in US.

## Mozambicans seek shelter as storm Freddy makes landfall
 - [https://www.aljazeera.com/news/2023/2/24/mozambicans-seek-shelter-as-storm-freddy-makes-landfall](https://www.aljazeera.com/news/2023/2/24/mozambicans-seek-shelter-as-storm-freddy-makes-landfall)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 17:55:52+00:00

Heavy rains forecast in southern provinces, and neighbouring countries also expected to be impacted by tropical storm.

## Villagers mourn mosque destroyed by Syria’s earthquake
 - [https://www.aljazeera.com/gallery/2023/2/24/villagers-mourn-for-mosque-destroyed-by-syrias-earthquake](https://www.aljazeera.com/gallery/2023/2/24/villagers-mourn-for-mosque-destroyed-by-syrias-earthquake)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 17:54:08+00:00

&#039;People&#039;s hearts are attached to this mosque,&#039; says the imam of Maland&#039;s destroyed mosque.

## It’s time for a borderless Africa
 - [https://www.aljazeera.com/opinions/2023/2/24/its-time-for-a-borderless-africa](https://www.aljazeera.com/opinions/2023/2/24/its-time-for-a-borderless-africa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 17:34:31+00:00

No African should be treated like a foreigner in any African country.

## All you need to know about China’s plan for Russia-Ukraine talks
 - [https://www.aljazeera.com/news/2023/2/24/all-you-need-to-know-about-chinas-plan-for-russia-ukraine-war](https://www.aljazeera.com/news/2023/2/24/all-you-need-to-know-about-chinas-plan-for-russia-ukraine-war)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 17:24:03+00:00

Beijing has released a 12-point position paper, calling for a ceasefire between Kyiv and Moscow.

## US consumer spending surges in January, inflation heats up
 - [https://www.aljazeera.com/economy/2023/2/24/us-consumer-spending-surges-in-january-inflation-heats-up](https://www.aljazeera.com/economy/2023/2/24/us-consumer-spending-surges-in-january-inflation-heats-up)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 17:08:56+00:00

US consumer spending increased by the most in nearly two years in January amid a surge in wage gains.

## Syrian refugees in Turkey face return to quake-stricken areas
 - [https://www.aljazeera.com/news/2023/2/24/syrian-refugees-in-turkey-face-return-to-quake-stricken-areas](https://www.aljazeera.com/news/2023/2/24/syrian-refugees-in-turkey-face-return-to-quake-stricken-areas)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 17:04:22+00:00

Gov&#039;t directives issued after quakes allow refugees in affected provinces to move around, but only for a limited time.

## Estonian PM: ‘If aggression pays off, aggressors will take note’
 - [https://www.aljazeera.com/program/talk-to-al-jazeera/2023/2/24/estonian-pm-if-aggression-pays-off-aggressors-will-take-note](https://www.aljazeera.com/program/talk-to-al-jazeera/2023/2/24/estonian-pm-if-aggression-pays-off-aggressors-will-take-note)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 16:21:00+00:00

Prime Minister Kaja Kallas discusses what Europe has learned since last year’s invasion of Ukraine.

## US announces new Ukraine aid, Russia sanctions on war anniversary
 - [https://www.aljazeera.com/news/2023/2/24/us-announces-new-ukraine-aid-russia-sanctions-on-war-anniversary](https://www.aljazeera.com/news/2023/2/24/us-announces-new-ukraine-aid-russia-sanctions-on-war-anniversary)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 16:01:05+00:00

Pentagon to send more HIMARS ammunition and drones to Ukraine as Washington targets Russian firms and sanction evasion.

## Nigeria MP arrested with nearly $500,000 before election
 - [https://www.aljazeera.com/news/2023/2/24/nigeria-mp-arrested-with-nearly-500000-cash-ahead-of-election](https://www.aljazeera.com/news/2023/2/24/nigeria-mp-arrested-with-nearly-500000-cash-ahead-of-election)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 16:00:36+00:00

Chinyere Igwe was found travelling with the money and a distribution list, police say a day before Nigerian elections.

## Palestinian medic’s father hit by Israeli bullet dies in his lap
 - [https://www.aljazeera.com/gallery/2023/2/24/mourning-nabluss-dead-after-an-israeli-raid-killed-11](https://www.aljazeera.com/gallery/2023/2/24/mourning-nabluss-dead-after-an-israeli-raid-killed-11)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 15:48:38+00:00

Elias al-Ashqar cried after he could not save his father wounded in Israeli raid on Nablus on Wednesday.

## ‘I had no idea I’d never go back’: Mariupol survivors, a year on
 - [https://www.aljazeera.com/news/2023/2/24/never-wanted-to-leave-mariupol-residents-look-back-at-war](https://www.aljazeera.com/news/2023/2/24/never-wanted-to-leave-mariupol-residents-look-back-at-war)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 14:20:59+00:00

Al Jazeera catches up with former residents of the city where Russia is alleged to have carried out atrocities.

## ‘I was a prisoner of Mexico’s US-backed migrant detention regime’
 - [https://www.aljazeera.com/features/2023/2/24/i-was-a-prisoner-of-mexicos-us-backed-migrant-detention-regime](https://www.aljazeera.com/features/2023/2/24/i-was-a-prisoner-of-mexicos-us-backed-migrant-detention-regime)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 13:16:25+00:00

An American writes about her time in the migrant prison city of Tapachula, where she is threatened with deportation.

## Western leaders slam Russia on first anniversary of Ukraine war
 - [https://www.aljazeera.com/news/2023/2/24/west-voices-support-for-ukraine-a-year-into-russias-invasion](https://www.aljazeera.com/news/2023/2/24/west-voices-support-for-ukraine-a-year-into-russias-invasion)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 13:00:10+00:00

Ukraine&#039;s allies promise to stand with Kyiv as the conflict enters a second year, while China treads a careful line.

## Five key ways the US has supported Ukraine’s war effort
 - [https://www.aljazeera.com/news/2023/2/24/five-key-ways-the-us-has-supported-ukraines-war-effort](https://www.aljazeera.com/news/2023/2/24/five-key-ways-the-us-has-supported-ukraines-war-effort)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 12:49:24+00:00

Al Jazeera examines Washington&#039;s notable moves to help Kyiv fight against Moscow&#039;s invasion over the past year.

## Italy detains migrant rescue ship, fines charity
 - [https://www.aljazeera.com/news/2023/2/24/italy-detains-migrant-rescue-ship-fines-charity](https://www.aljazeera.com/news/2023/2/24/italy-detains-migrant-rescue-ship-fines-charity)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 11:54:58+00:00

Italy&#039;s far-right government is taking legal action against a vessel operated by MSF in the Mediterranean Sea.

## Tunisia arrests key opposition figure as crackdown escalates
 - [https://www.aljazeera.com/news/2023/2/24/tunisia-arrests-opposition-figure-ben-mbarek-family](https://www.aljazeera.com/news/2023/2/24/tunisia-arrests-opposition-figure-ben-mbarek-family)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 11:04:13+00:00

Jaouhar Ben Mbarek, a critic of the president, is a prominent member of the main opposition coalition.

## Ukraine’s Bravehearts: From filmmakers to war veterans
 - [https://www.aljazeera.com/program/witness/2023/2/24/ukraines-bravehearts-from-filmmakers-to-war-veterans](https://www.aljazeera.com/program/witness/2023/2/24/ukraines-bravehearts-from-filmmakers-to-war-veterans)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 10:52:41+00:00

Two Ukrainian filmmakers join the army and find themselves caught between worlds.

## Russia’s Medvedev floats idea of pushing back Poland’s borders
 - [https://www.aljazeera.com/news/2023/2/24/moscow-must-push-borders-back-as-far-as-possible-says-medvedev](https://www.aljazeera.com/news/2023/2/24/moscow-must-push-borders-back-as-far-as-possible-says-medvedev)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 10:43:04+00:00

Putin-ally says Russia will be victorious in Ukraine and is ready to fight until the Polish border to counter &#039;threats&#039;.

## Israeli forces kill Palestinian, thousands protest violent raids
 - [https://www.aljazeera.com/news/2023/2/24/israeli-forces-kill-palestinian-thousands-protest-violent-raids](https://www.aljazeera.com/news/2023/2/24/israeli-forces-kill-palestinian-thousands-protest-violent-raids)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 10:03:18+00:00

Israeli forces have killed 65 Palestinians, 13 of them children, so far this year, the bloodiest such period since 2000.

## Ukrainians on first anniversary of Russia’s war: ‘I worry a lot’
 - [https://www.aljazeera.com/news/2023/2/24/ukrainians-on-first-anniversary-of-russias-war-i-worry-a-lot](https://www.aljazeera.com/news/2023/2/24/ukrainians-on-first-anniversary-of-russias-war-i-worry-a-lot)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 09:56:38+00:00

Four Ukrainians in Kyiv on Russia&#039;s brutal war in Ukraine, which is barrelling into a second year.

## Ukraine war: Is more war the only solution?
 - [https://www.aljazeera.com/program/the-bottom-line/2023/2/24/ukraine-war-is-more-war-the-only-solution](https://www.aljazeera.com/program/the-bottom-line/2023/2/24/ukraine-war-is-more-war-the-only-solution)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 08:58:41+00:00

Two views on Russia&#039;s war in Ukraine paint different pictures of the road ahead.

## Explainer: Key voting blocs ahead of Nigeria election
 - [https://www.aljazeera.com/news/2023/2/24/explainer-the-key-voting-blocs-ahead-of-nigerias-national-election](https://www.aljazeera.com/news/2023/2/24/explainer-the-key-voting-blocs-ahead-of-nigerias-national-election)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 08:45:00+00:00

A close look at the four main voter constituencies and how they could affect Nigeria&#039;s upcoming election results.

## Indonesia boosts security in Papua after 9 killed in riot
 - [https://www.aljazeera.com/news/2023/2/24/indonesia-boosts-security-in-papua-after-9-killed-in-riot](https://www.aljazeera.com/news/2023/2/24/indonesia-boosts-security-in-papua-after-9-killed-in-riot)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 08:42:06+00:00

More than 200 security personnel sent to Wamena town after kidnap rumour sparks deadly riot and clashes with police.

## Is Europe really united in backing Ukraine and isolating Russia?
 - [https://www.aljazeera.com/news/2023/2/24/has-the-ukraine-war-strengthened-europe-or-weakened-it](https://www.aljazeera.com/news/2023/2/24/has-the-ukraine-war-strengthened-europe-or-weakened-it)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 08:42:06+00:00

Europe has shown solidarity with Zelenskyy&#039;s forces, but beneath the surface, divisions persist, say analysts.

## Two Pakistanis leave Guantanamo after 20 years without charges
 - [https://www.aljazeera.com/news/2023/2/24/two-pakistanis-leave-guantanamo-after-20-years-without-charges](https://www.aljazeera.com/news/2023/2/24/two-pakistanis-leave-guantanamo-after-20-years-without-charges)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 08:28:16+00:00

Abdul and Mohammed Rabbani, arrested from Karachi in 2002, are the latest inmates to be released from US custody.

## India’s Modi asks G20 finance heads to focus on ‘most vulnerable’
 - [https://www.aljazeera.com/news/2023/2/24/indias-modi-asks-g20-finance-heads-to-focus-on-most-vulnerable](https://www.aljazeera.com/news/2023/2/24/indias-modi-asks-g20-finance-heads-to-focus-on-most-vulnerable)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 07:41:21+00:00

Financial viability of many countries is being threatened by unsustainable debt, Indian PM says at two-day G20 meeting.

## Djibouti holds parliamentary vote branded as sham by opposition
 - [https://www.aljazeera.com/news/2023/2/24/djibouti-to-hold-parliamentary-vote-snubbed-by-opposition](https://www.aljazeera.com/news/2023/2/24/djibouti-to-hold-parliamentary-vote-snubbed-by-opposition)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 07:34:37+00:00

Only two parties are contesting seats in the 65-member National Assembly in Friday&#039;s election.

## Russia-Ukraine war: List of key events, day 366
 - [https://www.aljazeera.com/news/2023/2/24/russia-ukraine-war-list-of-key-events-day-366](https://www.aljazeera.com/news/2023/2/24/russia-ukraine-war-list-of-key-events-day-366)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 07:01:02+00:00

As the Russia-Ukraine war enters its 366th day, we take a look at the main developments.

## Australia uncovers Russian espionage ring, expels spies: Report
 - [https://www.aljazeera.com/news/2023/2/24/australia-uncovers-russian-espionage-ring-expels-spies-report](https://www.aljazeera.com/news/2023/2/24/australia-uncovers-russian-espionage-ring-expels-spies-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 06:40:08+00:00

Russian spy ring operated in Australia for 18 months before it was uncovered and its activities broken up, report says.

## Russia sends Soyuz rescue ship to International Space Station
 - [https://www.aljazeera.com/news/2023/2/24/russia-sends-soyuz-rescue-ship-to-international-space-station](https://www.aljazeera.com/news/2023/2/24/russia-sends-soyuz-rescue-ship-to-international-space-station)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 05:20:29+00:00

Soyuz MS-23 will transport Russian cosmonauts Dmitry Petelin, Sergei Prokopyev and NASA&#039;s Frank Rubio back to Earth.

## Photos: Death, destruction and displacement in a year of war
 - [https://www.aljazeera.com/gallery/2023/2/24/photos-russia-ukraine-war-images-capture-a-year-of-war-russia-u](https://www.aljazeera.com/gallery/2023/2/24/photos-russia-ukraine-war-images-capture-a-year-of-war-russia-u)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 05:15:09+00:00

A selection of images attesting to the tragedies inflicted on the Ukrainian people.

## Unbeaten, unbowed: Leila de Lima marks six years in detention
 - [https://www.aljazeera.com/news/2023/2/24/unbeaten-unbowed-leila-de-lima-marks-six-years-in-detention](https://www.aljazeera.com/news/2023/2/24/unbeaten-unbowed-leila-de-lima-marks-six-years-in-detention)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 05:02:45+00:00

Former Philippines senator and outspoken critic of ex-President Rodrigo Duterte sees hope for freedom.

## IMF unveils crypto plan, advising against legal tender status
 - [https://www.aljazeera.com/economy/2023/2/24/imf-unveils-crypto-plan-warning-against-legal-tender-status](https://www.aljazeera.com/economy/2023/2/24/imf-unveils-crypto-plan-warning-against-legal-tender-status)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 04:41:41+00:00

Global lender recommends countries craft crypto policies that &#039;safeguard monetary sovereignty and stability&#039;.

## China calls for Russia-Ukraine ceasefire, proposes path to peace
 - [https://www.aljazeera.com/news/2023/2/24/china-calls-for-russia-ukraine-cease-fire-proposes-peace-talks](https://www.aljazeera.com/news/2023/2/24/china-calls-for-russia-ukraine-cease-fire-proposes-peace-talks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 03:40:23+00:00

China&#039;s plan calls for end to Western sanctions on Russia and humanitarian corridors for civilians to escape fighting.

## Indonesia’s palm oil tycoon Darmadi gets 15 years for corruption
 - [https://www.aljazeera.com/economy/2023/2/24/indonesias-palm-oil-tycoon-darmadi-gets-15-years-for-corruption](https://www.aljazeera.com/economy/2023/2/24/indonesias-palm-oil-tycoon-darmadi-gets-15-years-for-corruption)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 03:31:54+00:00

Surya Darmadi ordered to repay the state equivalent of $2.6bn over corruption scheme that cleared protected forests.

## UN tells Russia to leave Ukraine: How did countries vote?
 - [https://www.aljazeera.com/news/2023/2/24/un-tells-russia-to-leave-ukraine-how-did-countries-vote](https://www.aljazeera.com/news/2023/2/24/un-tells-russia-to-leave-ukraine-how-did-countries-vote)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 02:48:08+00:00

A country breakdown of the UN General Assembly vote that demanded Moscow withdraw its troops and end the fighting.

## North Korea test fires four long-range cruise missiles
 - [https://www.aljazeera.com/news/2023/2/24/north-korea-test-fires-four-long-range-cruise-missiles](https://www.aljazeera.com/news/2023/2/24/north-korea-test-fires-four-long-range-cruise-missiles)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 02:10:09+00:00

Pyongyang has begun conducting more weapons tests as the United States and South Korea step up military training.

## A year into Ukraine war, Asia’s big brands sit out Russia boycott
 - [https://www.aljazeera.com/economy/2023/2/24/asian-brands-sit-out-russia-boycotts](https://www.aljazeera.com/economy/2023/2/24/asian-brands-sit-out-russia-boycotts)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 02:06:08+00:00

Fewer than 100 Asia-based firms have suspended or scaled back their Russia operations, according to database.

## Refugees on Australian detention island sew lips shut in protest
 - [https://www.aljazeera.com/news/2023/2/24/refugees-on-australian-detention-island-sew-lips-shut-in-protest](https://www.aljazeera.com/news/2023/2/24/refugees-on-australian-detention-island-sew-lips-shut-in-protest)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 01:42:03+00:00

Mohammad Shofiqul Islam and Mohammad Kaium have been held on the remote Pacific island of Nauru for nearly 10 years.

## How China and India’s appetite for oil and gas kept Russia afloat
 - [https://www.aljazeera.com/economy/2023/2/24/how-china-and-indias-appetite-for-oil-and-gas-kept-russia-afloat](https://www.aljazeera.com/economy/2023/2/24/how-china-and-indias-appetite-for-oil-and-gas-kept-russia-afloat)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 01:38:01+00:00

Russia’s economy has been able to weather Western-led sanctions in large part due to strong energy exports.

## Republican Party sets first presidential debate in US swing state
 - [https://www.aljazeera.com/news/2023/2/24/republican-party-sets-first-presidential-debate-in-swing-state](https://www.aljazeera.com/news/2023/2/24/republican-party-sets-first-presidential-debate-in-swing-state)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 01:13:38+00:00

The debate, to be held in Wisconsin, is expected to feature Republican candidates like Donald Trump and Nikki Haley.

## UN condemns Russia over Ukraine war, calls for withdrawal
 - [https://www.aljazeera.com/news/2023/2/24/un-condemns-russia-over-ukraine-war-calls-for-withdrawal](https://www.aljazeera.com/news/2023/2/24/un-condemns-russia-over-ukraine-war-calls-for-withdrawal)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-24 00:04:19+00:00

Some 141 members of the UN General Assembly back resolution, a year after Russia invaded its neighbour.

