# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Microsoft Reined in Bing and Reddit’s Chief Executive Steve Huffman Defends Section 230
 - [https://www.nytimes.com/2023/02/24/podcasts/hard-fork-bing-reddit-meta.html](https://www.nytimes.com/2023/02/24/podcasts/hard-fork-bing-reddit-meta.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-02-24 10:00:05+00:00

And what Meta’s new paid verification program means for the future of social media.

