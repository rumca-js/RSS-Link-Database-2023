# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## Apple iOS Shortcuts - How To Use Them
 - [https://www.forbes.com/sites/tjmccue/2023/02/24/apple-ios-shortcutshow-to-use-them/](https://www.forbes.com/sites/tjmccue/2023/02/24/apple-ios-shortcutshow-to-use-them/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 23:38:16+00:00

The Apple iOS Shortcuts App — it does what it says on the tin.

## Sheep As Urban Lawn Mowers Improve Environmental And Human Health
 - [https://www.forbes.com/sites/grrlscientist/2023/02/24/sheep-as-urban-lawn-mowers-improve-environmental-and-human-health/](https://www.forbes.com/sites/grrlscientist/2023/02/24/sheep-as-urban-lawn-mowers-improve-environmental-and-human-health/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 22:27:53+00:00

Sheepmowers provide environmentally-friendly and cost-effective urban landscape maintenance, whilst also reducing stress and improving peoples' moods

## Apple Loop: Massive iPhone 15 Pro Leak, Mac Pro Hints, Linux Cracks Open MacBook
 - [https://www.forbes.com/sites/ewanspence/2023/02/24/apple-headlines-iphone-15-pro-cad-leak-macbook-air-ar-headset-linux-apple-silicon/](https://www.forbes.com/sites/ewanspence/2023/02/24/apple-headlines-iphone-15-pro-cad-leak-macbook-air-ar-headset-linux-apple-silicon/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 22:03:57+00:00

This week’s Apple headlines; the leaked designs of the iPhone 15 and iPhone 15 Pro, a larger MacBook Air, hints of the new Mac Pro, Apple’s second AR headset, Linux heads to the Mac, and more...

## Android Circuit: Galaxy S23 Reviewed, Huge Pixel Fold Leaks, Angry Birds Goes Missing.
 - [https://www.forbes.com/sites/ewanspence/2023/02/24/android-headlines-galaxy-s23-review-tab-s9-pixel-fold-angry-brids-magic-eraser/](https://www.forbes.com/sites/ewanspence/2023/02/24/android-headlines-galaxy-s23-review-tab-s9-pixel-fold-angry-brids-magic-eraser/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 22:01:42+00:00

This week’s Android headlines; the Galaxy S23 review, leaked details on the Galaxy Tab S9, Google patches Pixel problems, Magic Eraser availability widens, Google’s oversized Pixel Fold, Angry Birds goes missing, and more...

## OnePlus TV 65 Q2 Pro Review: Wonderful Upgrade For Your Place
 - [https://www.forbes.com/sites/prakharkhanna/2023/02/24/oneplus-tv-65-q2-pro-review-wonderful-upgrade-for-your-place/](https://www.forbes.com/sites/prakharkhanna/2023/02/24/oneplus-tv-65-q2-pro-review-wonderful-upgrade-for-your-place/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 21:31:32+00:00

If you are looking for a 65-inch QLED TV for consuming content or playing games on the PS5, the new OnePlus TV might be just what you need.

## Apple iPhone 15: New Leak Reveals Sensational Upgrade
 - [https://www.forbes.com/sites/davidphelan/2023/02/24/apple-iphone-15-new-leak-reveals-sensational-upgrade-iphone-15-pro/](https://www.forbes.com/sites/davidphelan/2023/02/24/apple-iphone-15-new-leak-reveals-sensational-upgrade-iphone-15-pro/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 20:47:07+00:00

The next iPhone may have a performance increase that every user will want.

## New Meteorite Crater Discovered Hiding In Plain Sight Beneath French Vineyard
 - [https://www.forbes.com/sites/davidbressan/2023/02/24/new-meteorite-crater-discovered-hiding-in-plain-sight-beneath-french-vineyard/](https://www.forbes.com/sites/davidbressan/2023/02/24/new-meteorite-crater-discovered-hiding-in-plain-sight-beneath-french-vineyard/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 19:49:20+00:00

What began as a marketing gag for a wine grown in a peculiar geological feature in Southern France led to the discovery of a previously unrecognized impact crater.

## The Shadow Of ‘The Rings Of Power’ Hangs Over Warner Bros’ New ‘Lord Of The Rings’ Movies
 - [https://www.forbes.com/sites/erikkain/2023/02/24/the-shadow-of-the-rings-of-power-hangs-over-warner-bros-new-lord-of-the-rings-movies/](https://www.forbes.com/sites/erikkain/2023/02/24/the-shadow-of-the-rings-of-power-hangs-over-warner-bros-new-lord-of-the-rings-movies/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 19:34:36+00:00

New Lord Of The Rings movies are on the way. I have a bad feeling about this.

## Samsung Galaxy Watch 6 Design To Take Cues From The Pixel Watch
 - [https://www.forbes.com/sites/andrewwilliams/2023/02/24/samsung-galaxy-watch-6-design-to-take-cues-from-the-pixel-watch/](https://www.forbes.com/sites/andrewwilliams/2023/02/24/samsung-galaxy-watch-6-design-to-take-cues-from-the-pixel-watch/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 18:41:48+00:00

Samsung's Watch Watch 6 may use a curved glass top, like some older models.

## Elon Musk’s Twitter Quietly Fired Its Democracy And National Security Policy Lead
 - [https://www.forbes.com/sites/thomasbrewster/2023/02/24/elon-musk-twitter-democracy-and-human-rights-layoffs/](https://www.forbes.com/sites/thomasbrewster/2023/02/24/elon-musk-twitter-democracy-and-human-rights-layoffs/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 18:36:21+00:00

Twitter’s public policy team continues to be decimated under Elon Musk, signaling a retreat from engaging with democratic, national security and human rights concerns across the world.

## Roald Dahl Publisher Puffin Books Is Having Its Cake And Eating It, Too
 - [https://www.forbes.com/sites/erikkain/2023/02/24/roald-dahl-publisher-puffin-books-is-having-its-cake-and-eating-it-too/](https://www.forbes.com/sites/erikkain/2023/02/24/roald-dahl-publisher-puffin-books-is-having-its-cake-and-eating-it-too/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 18:35:26+00:00

Now you can choose which version of Roald Dahl's books you'd like to read. What a savvy business decision on Puffin's part. Consumer choice! It's what makes the world go round!

## Almost 50% Of Young Women Report Negative Healthcare Experiences, New Study Shows
 - [https://www.forbes.com/sites/debgordon/2023/02/24/almost-50-of-young-women-report-negative-healthcare-experiences-new-study-shows/](https://www.forbes.com/sites/debgordon/2023/02/24/almost-50-of-young-women-report-negative-healthcare-experiences-new-study-shows/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 17:25:01+00:00

A new report released this week from the Kaiser Family Foundation (KFF) starkly illustrates just how poorly many women feel they have been treated by their doctors.

## Abortion Pills: What To Know About Mifepristone As Biden Administration Defends It From Legal Attack
 - [https://www.forbes.com/sites/alisondurkee/2023/02/24/abortion-pills-what-to-know-about-mifepristone-as-biden-administration-defends-it-from-legal-attack/](https://www.forbes.com/sites/alisondurkee/2023/02/24/abortion-pills-what-to-know-about-mifepristone-as-biden-administration-defends-it-from-legal-attack/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 17:01:12+00:00

A Trump-appointed judge could soon issue a ruling that would bar abortion pills from being distributed even in states where abortion remains legal.

## Samsung Releases Essential Galaxy S23 Ultra Speed Upgrade
 - [https://www.forbes.com/sites/paulmonckton/2023/02/24/samsung-releases-essential-galaxy-s23-ultra-speed-upgrade/](https://www.forbes.com/sites/paulmonckton/2023/02/24/samsung-releases-essential-galaxy-s23-ultra-speed-upgrade/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 16:54:59+00:00

The update Galaxy S23 Ultra owners have been waiting for.

## Massive AMD Ryzen 9 7950X3D Leak Reveals Stunning Performance That Could Worry Intel
 - [https://www.forbes.com/sites/antonyleather/2023/02/24/massive-amd-ryzen-9-7950x3d-leak-reveals-stunning-performance-that-could-worry-intel/](https://www.forbes.com/sites/antonyleather/2023/02/24/massive-amd-ryzen-9-7950x3d-leak-reveals-stunning-performance-that-could-worry-intel/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 15:43:59+00:00

The Ryzen 9 7950X3D is 16 percent faster than the 7950X in games

## Group Works To Bring Broadband To Coal Country
 - [https://www.forbes.com/sites/lcarrel/2023/02/24/group-works-to-bring-broadband-to-coal-country/](https://www.forbes.com/sites/lcarrel/2023/02/24/group-works-to-bring-broadband-to-coal-country/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 15:19:10+00:00

One of the biggest roadblocks to closing coal companies is finding jobs for all the people who will be put out of work. The Just Transition Fund aims to bring broadband to coal country.

## Why Anti-Malware And Antivirus Ran Out Of Gas
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/why-anti-malware-and-antivirus-ran-out-of-gas/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/why-anti-malware-and-antivirus-ran-out-of-gas/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 15:15:00+00:00

With the number and intensity of high-value cyberattacks growing, technology is increasingly scrutinizing behaviors, sketching on a wider canvas and examining more variables. It’s past time for a changing of the guard because the guard has long lacked reinforcements.

## Gamers First Acquires Women’s Car Ball League, Revives All-Female Pro ‘Rocket League’ Series
 - [https://www.forbes.com/sites/maxthielmeyer/2023/02/24/gamers-first-acquires-womens-car-ball-league-revives-all-female-pro-rocket-league-series/](https://www.forbes.com/sites/maxthielmeyer/2023/02/24/gamers-first-acquires-womens-car-ball-league-revives-all-female-pro-rocket-league-series/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 15:08:02+00:00

G1 also shares plans to expand player development and host a world championship LAN event.

## How Artificial Intelligence Helps Protect Intellectual Property
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/how-artificial-intelligence-helps-protect-intellectual-property/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/how-artificial-intelligence-helps-protect-intellectual-property/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 15:00:00+00:00

Brands today have enough challenges: build great products, reach target customers cost-effectively, and increase sales and revenue. The last thing they want to contend with is finding out that someone somewhere is copying their products and selling them for profit.

## Reanalyzing Data Helps Unlock The Mysteries Of Flooding Rains In Africa
 - [https://www.forbes.com/sites/andrewwight/2023/02/24/reanalyzing-data-helps-unlock-the-mysteries-of-flooding-rains-in-africa/](https://www.forbes.com/sites/andrewwight/2023/02/24/reanalyzing-data-helps-unlock-the-mysteries-of-flooding-rains-in-africa/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 15:00:00+00:00

Wanjiru Thoithi, a Kenyan researcher based in South Africa, has reanalyzed weather data to help understand what was happening in the weather system that produced a storm that flooded Durban and other other parts of South Africa and  killed over 400 people in April 2022.

## This Startup Wants To Bring New Efficiency To Government In 2023.
 - [https://www.forbes.com/sites/garydrenik/2023/02/24/this-startup-wants-to-bring-new-efficiency-to-government-in-2023/](https://www.forbes.com/sites/garydrenik/2023/02/24/this-startup-wants-to-bring-new-efficiency-to-government-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 15:00:00+00:00

While it’s not something your average American pays much attention to, government procurement is an overlooked industry that affects virtually all citizens, yet it remains largely offline.

## Mediatek Democratizes Satellite And 5G At Mobile World Congress 2023
 - [https://www.forbes.com/sites/moorinsights/2023/02/24/mediatek-democratizes-satellite-and-5g-at-mobile-world-congress-2023/](https://www.forbes.com/sites/moorinsights/2023/02/24/mediatek-democratizes-satellite-and-5g-at-mobile-world-congress-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:59:01+00:00

Principal Analyst, Mobility & VR, Anshel Sag, gives his coverage of MediaTek's new Dimensity SoC, 5G Satellite-capable chipset and other innovations at Mobile World Congress 2023.

## ‘Hogwarts Legacy’ DLC, Sequel Should Be Guaranteed With These Sales Numbers
 - [https://www.forbes.com/sites/paultassi/2023/02/24/hogwarts-legacy-dlc-sequel-should-be-guaranteed-with-these-sales-numbers/](https://www.forbes.com/sites/paultassi/2023/02/24/hogwarts-legacy-dlc-sequel-should-be-guaranteed-with-these-sales-numbers/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:45:28+00:00

On Thursday, Warner Bros. revealed that Hogwarts Legacy sold 12 million copies in its first two weeks of release, absolutely colossal numbers for a brand new franchise, albeit one drawing on two decades worth of Harry Potter fandom.

## Three 2022 Federal And SLED IT Trends To Continue Watching In 2023
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/three-2022-federal-and-sled-it-trends-to-continue-watching-in-2023/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/three-2022-federal-and-sled-it-trends-to-continue-watching-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:45:00+00:00

Because compliance with federal and state, local and education (SLED) initiatives will continue into 2023 and beyond, so too will the technology issues that are part of this compliance.

## It’s Official: Twitter Is Trying To Destroy Itself
 - [https://www.forbes.com/sites/johnbbrandon/2023/02/24/its-official-twitter-is-trying-to-destroy-itself/](https://www.forbes.com/sites/johnbbrandon/2023/02/24/its-official-twitter-is-trying-to-destroy-itself/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:36:54+00:00

Almost once a day or more, a request comes in by text to authenticate my account, even though I’m not trying to login.

## Don’t Just Deactivate Facebook—Delete It Instead
 - [https://www.forbes.com/sites/kateoflahertyuk/2023/02/24/dont-just-deactivate-facebook-delete-it-instead/](https://www.forbes.com/sites/kateoflahertyuk/2023/02/24/dont-just-deactivate-facebook-delete-it-instead/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:33:44+00:00

Searches for "deactivate Facebook” have surged since Meta announced subscriptions. Here's why you shouldn't deactivate Facebook, but delete it instead.

## ‘Lightfall’ Trailer Reveals ‘Destiny 2’ Is About To Get As Dark As It’s Ever Been
 - [https://www.forbes.com/sites/paultassi/2023/02/24/lightfall-trailer-reveals-destiny-2-is-about-to-get-as-dark-as-its-ever-been/](https://www.forbes.com/sites/paultassi/2023/02/24/lightfall-trailer-reveals-destiny-2-is-about-to-get-as-dark-as-its-ever-been/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:31:24+00:00

We are just four days away from the launch of Destiny 2’s Lightfall expansion, but even though it’s mainly focused on the flashy neon lights of a cyberpunk city on Neptune, Neomuna, it seems as if the story is about to get as dark and terrifying as it’s ever been.

## Meta Makes It Easier To Avoid Facebook Jail
 - [https://www.forbes.com/sites/emmawoollacott/2023/02/24/meta-makes-it-easier-to-avoid-facebook-jail/](https://www.forbes.com/sites/emmawoollacott/2023/02/24/meta-makes-it-easier-to-avoid-facebook-jail/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:30:28+00:00

Following recommendations from the Facebook Oversight Board, Meta is overhauling its system for implementing penalties for policy violations.

## Healthcare Data Nerds Can Put This Debate To Rest
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/healthcare-data-nerds-can-put-this-debate-to-rest/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/healthcare-data-nerds-can-put-this-debate-to-rest/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:30:00+00:00

Payers must give up more of their data to help providers make better decisions. Providers must accept more risk—being paid more or less depending on patient health outcomes. The formula becomes shared data, shared risk and shared results.

## Who On Earth Is Steven Yeun Playing In The MCU's 'Thunderbolts'?
 - [https://www.forbes.com/sites/paultassi/2023/02/24/who-on-earth-is-steven-yeun-playing-in-the-mcus-thunderbolts/](https://www.forbes.com/sites/paultassi/2023/02/24/who-on-earth-is-steven-yeun-playing-in-the-mcus-thunderbolts/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:16:43+00:00

Some huge MCU news broke this week, as it’s been announced that Oscar nominee and Walking Dead alumni Steven Yeun would be joining the cast of Thunderbolts, the villain/anti-hero-centric feature about a team of mostly criminals tasked with doing dirty work for the government.

## How To Provide Superior Customer Service
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/how-to-provide-superior-customer-service/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/how-to-provide-superior-customer-service/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:15:00+00:00

Making it easy for your customers to get help, taking a proactive approach to customer support and understanding what frustrates and satisfies customers can help you achieve your business goals and deliver exceptional customer service.

## ‘Physical: 100’ Is The Best Netflix Show Of The Year So Far
 - [https://www.forbes.com/sites/paultassi/2023/02/24/physical-100-is-the-best-netflix-show-of-the-year-so-far/](https://www.forbes.com/sites/paultassi/2023/02/24/physical-100-is-the-best-netflix-show-of-the-year-so-far/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:01:12+00:00

While we’re only two months into the year now, I would declare Physical: 100 the best show I’ve seen on Netflix in 2023,

## CISOs: Here’s How You Can Navigate The 2023 Downturn
 - [https://www.forbes.com/sites/forrester/2023/02/24/cisos-heres-how-you-can-navigate-the-2023-downturn/](https://www.forbes.com/sites/forrester/2023/02/24/cisos-heres-how-you-can-navigate-the-2023-downturn/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:00:00+00:00

Companies across sectors — with a particular concentration in high tech — are shedding jobs and slashing costs to weather the next 12 months.

## The Death Of The Domain: Three Tips For Pursuing Domainless IT
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/the-death-of-the-domain-three-tips-for-pursuing-domainless-it/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/the-death-of-the-domain-three-tips-for-pursuing-domainless-it/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:00:00+00:00

Domainless differs from the traditional domain-bound enterprise by treating all users as untrusted and requiring them to assert their identity at each point of an access request—without adding friction to the user experience.

## The Promise And Future Of Startup Nation
 - [https://www.forbes.com/sites/gilpress/2023/02/24/the-future-and-promise-of-startup-nation/](https://www.forbes.com/sites/gilpress/2023/02/24/the-future-and-promise-of-startup-nation/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 14:00:00+00:00

The OurCrowd 2023 Summit demonstrated the resilience and potential of startup nation.

## Is Too Much Inventory A Good Thing For Your Company?
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/is-too-much-inventory-a-good-thing-for-your-company/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/is-too-much-inventory-a-good-thing-for-your-company/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 13:45:00+00:00

Do not think of inventory as cost; rather, it is a strategic tool that, if managed well, can provide growth, larger market share and much higher shareholder value.

## Rocksteady’s ‘Suicide Squad’ Looks Like Live Service Hell
 - [https://www.forbes.com/sites/paultassi/2023/02/24/rocksteadys-suicide-squad-looks-like-live-service-hell/](https://www.forbes.com/sites/paultassi/2023/02/24/rocksteadys-suicide-squad-looks-like-live-service-hell/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 13:43:44+00:00

After 10 minutes of Suicide Squad: Kill the Justice League footage and explanation from Rocksteady, the general takeaway seems to be: “Wait, that’s what this game is?”

## Hands On With MTG: Phyrexia: All Will Be One Expansion
 - [https://www.forbes.com/sites/curtissilver/2023/02/24/hands-on-with-mtg-phyrexia-all-will-be-one-expansion/](https://www.forbes.com/sites/curtissilver/2023/02/24/hands-on-with-mtg-phyrexia-all-will-be-one-expansion/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 13:36:05+00:00

The latest Magic: The Gathering expansion, Phyrexia: All Will Be One has hit stores and playmats.

## Mobile Site Personalization And Its Impact On Consumer Loyalty
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/mobile-site-personalization-and-its-impact-on-consumer-loyalty/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/mobile-site-personalization-and-its-impact-on-consumer-loyalty/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 13:30:00+00:00

It can be tricky to get design teams to change their mindset from being desktop-based to mobile-based, but doing so can help change their way of thinking and the language of the design process.

## 14 Smart Strategies For Establishing A Secure Software Supply Chain
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/14-smart-strategies-for-establishing-a-secure-software-supply-chain/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/14-smart-strategies-for-establishing-a-secure-software-supply-chain/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 13:15:00+00:00

Security vulnerabilities can be introduced at any point in the software supply chain, making it essential for tech leaders to establish practices to monitor and protect each link.

## The Role Of Technology In The Evolution Of The Office Of Finance
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/the-role-of-technology-in-the-evolution-of-the-office-of-finance/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/the-role-of-technology-in-the-evolution-of-the-office-of-finance/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 13:15:00+00:00

The role of financial professionals will continue to evolve and transform over the next decade and beyond—but with the right technology support, this critical operation is poised to become an even stronger business asset.

## 2023 Supply Chain Outlook: How To Navigate Through Uncertainty
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/2023-supply-chain-outlook-how-to-navigate-through-uncertainty/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/2023-supply-chain-outlook-how-to-navigate-through-uncertainty/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 13:00:00+00:00

While the headwinds are beyond the control of any individual buyer or supplier, business leaders can focus on being informed and being situationally aware and equipped with the right tools in their arsenal.

## Marijuana Use Could Increase Chances For Heart Disease, Study Suggests
 - [https://www.forbes.com/sites/tylerroush/2023/02/24/marijuana-use-could-increase-chances-for-heart-disease-study-suggests/](https://www.forbes.com/sites/tylerroush/2023/02/24/marijuana-use-could-increase-chances-for-heart-disease-study-suggests/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 13:00:00+00:00

Nearly 50 million people used the drug at least once in 2019.

## The Implications Of ChatGPT On Cybercrime
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/the-implications-of-chatgpt-on-cybercrime/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/the-implications-of-chatgpt-on-cybercrime/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 12:45:00+00:00

The excitement over ChatGPT comes with a number of caveats that concerns cybersecurity.

## Trending Now: Last-Mile Delivery Expectations For 2023
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/trending-now-last-mile-delivery-expectations-for-2023/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/trending-now-last-mile-delivery-expectations-for-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 12:30:00+00:00

The persistent and aggressive growth in e-commerce demands a seamless process to satisfy customers’ needs, but several challenges have made it more difficult.

## 3 Innovative Solutions Shaping The Future Of Agriculture
 - [https://www.forbes.com/sites/sap/2023/02/24/3-innovative-solutions-shaping-the-future-of-agriculture/](https://www.forbes.com/sites/sap/2023/02/24/3-innovative-solutions-shaping-the-future-of-agriculture/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 12:28:09+00:00

Using AI to improve the quality of crops, optimize farming strategies through personalization, and improve biological capital by managing soil more efficiently can all play a role in successfully feeding 9 billion people for the next decades.

## Eliminate Waste And Unlock Value In Healthcare Software Spend
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/eliminate-waste-and-unlock-value-in-healthcare-software-spend/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/eliminate-waste-and-unlock-value-in-healthcare-software-spend/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 12:15:00+00:00

One of the larger operational expenses in healthcare isn't scrutinized enough—software licensing and maintenance.

## How Brands Can Build Successful Online Communities
 - [https://www.forbes.com/sites/quora/2023/02/24/how-brands-can-build-successful-online-communities/](https://www.forbes.com/sites/quora/2023/02/24/how-brands-can-build-successful-online-communities/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 12:00:00+00:00

We outline why brands should invest in building a strong digital communities, as well as provide six tips for getting started.

## VR For Flight Training: Benefits And Challenges
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/vr-for-flight-training-benefits-and-challenges/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/vr-for-flight-training-benefits-and-challenges/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 12:00:00+00:00

VR is about nurturing relevant skills and practicing theoretical knowledge in virtual environments that replicate real ones. This is invaluable for pilot training.

## Looking Into 2023: Key Takeaways From Davos
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/looking-into-2023-key-takeaways-from-davos/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/looking-into-2023-key-takeaways-from-davos/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 11:45:00+00:00

There is now universal recognition by companies they need to act more deliberately and effectively. What are companies doing to drive sustainability that’s working?

## Managing Business Infrastructure And Operations: How To Overcome Uncertain Times
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/managing-business-infrastructure-and-operations-how-to-overcome-uncertain-times/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/managing-business-infrastructure-and-operations-how-to-overcome-uncertain-times/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 11:30:00+00:00

By optimizing your IT infrastructure, you can gain a competitive edge in the market and drive business growth.

## Companies Are Deploying Active Defense To Complement Traditional Denial-Based Cybersecurity Defenses
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/companies-are-deploying-active-defense-to-complement-traditional-denial-based-cybersecurity-defenses/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/companies-are-deploying-active-defense-to-complement-traditional-denial-based-cybersecurity-defenses/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 11:15:00+00:00

Increasingly, CEOs and members of the board are paying closer attention to what they can do to fully support and allocate proper funding toward technology that adequately protects the “Picasso” in everyone’s organization.

## Nvidia Beats Earning Expectations And Looks Towards AI, Stock Jumps 14% In Response
 - [https://www.forbes.com/sites/qai/2023/02/24/nvidia-beats-earning-expectations-and-looks-towards-ai-stock-jumps-14-in-response/](https://www.forbes.com/sites/qai/2023/02/24/nvidia-beats-earning-expectations-and-looks-towards-ai-stock-jumps-14-in-response/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 11:03:56+00:00

Alongside these numbers came a renewed commitment to its cloud AI endeavors, which has analysts and investors buzzing.

## How Outdated Software Can Cause Costly Glitches
 - [https://www.forbes.com/sites/forbestechcouncil/2023/02/24/how-outdated-software-can-cause-costly-glitches/](https://www.forbes.com/sites/forbestechcouncil/2023/02/24/how-outdated-software-can-cause-costly-glitches/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 11:00:00+00:00

It is becoming clear that digital modernization is essential and not optional for systems to keep up with real-world demands.

## ‘Akka Arrh’ Review: Nothing Makes Sense, And It’s Wonderful
 - [https://www.forbes.com/sites/mattgardner1/2023/02/24/akka-arrh-review-nothing-makes-sense-and-its-wonderful/](https://www.forbes.com/sites/mattgardner1/2023/02/24/akka-arrh-review-nothing-makes-sense-and-its-wonderful/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 10:36:30+00:00

‘Akka Arrh’ does its best to confound you, and you’ll have a great time trying to figure it out.

## End-To-End Success: How To Effectively Build, Manage And Measure Customer Journeys
 - [https://www.forbes.com/sites/mikehughes1/2023/02/24/end-to-end-success-how-to-effectively-build-manage-and-measure-customer-journeys/](https://www.forbes.com/sites/mikehughes1/2023/02/24/end-to-end-success-how-to-effectively-build-manage-and-measure-customer-journeys/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 10:23:58+00:00

Brick-and-mortar shopping has made an impressive comeback since the end of lockdown, but e-commerce is still retail’s dominant new force. B2B businesses must pivot to a lucrative direct-to-consumer (DTC) model to capitalise on these opportunities.

## ESA Biomass Satellite Set To Map Earth’s Essential Old Growth Forests
 - [https://www.forbes.com/sites/brucedorminey/2023/02/24/esa-biomass-satellite-set-to-map-earths-essential-old-growth-forests/](https://www.forbes.com/sites/brucedorminey/2023/02/24/esa-biomass-satellite-set-to-map-earths-essential-old-growth-forests/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 10:07:03+00:00

The European Space Agency (ESA) is putting the final touches on an innovative new Earth Explorer satellite that will provide the best maps and measurements of our planet’s remaining old growth forests. Carbon sequestration by forests remains one of our best natural defenses against climate change.

## MediaTek Brings Practical Satellite Communications To Mobile Devices
 - [https://www.forbes.com/sites/tiriasresearch/2023/02/24/mediatek-brings-practical-satellite-communications-to-mobile-devices/](https://www.forbes.com/sites/tiriasresearch/2023/02/24/mediatek-brings-practical-satellite-communications-to-mobile-devices/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 10:00:00+00:00

Over the past six months, several smartphone OEMs, chipset providers, and wireless carriers have announced new developments for linking phones to satellites for emergency communications.

## Why The World Bank Supports Developing A Growth Mindset In Schools
 - [https://www.forbes.com/sites/charlestowersclark/2023/02/24/why-the-world-bank-supports-developing-a-growth-mindset-in-schools/](https://www.forbes.com/sites/charlestowersclark/2023/02/24/why-the-world-bank-supports-developing-a-growth-mindset-in-schools/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 08:55:59+00:00

The World Bank alongside education ministries are proving the benefits of a teaching a growth mindset to students

## England Nursing Strike Called Off After Ministers Agree To Talks
 - [https://www.forbes.com/sites/katherinehignett/2023/02/24/england-nursing-strike-called-off-after-ministers-agree-to-talks/](https://www.forbes.com/sites/katherinehignett/2023/02/24/england-nursing-strike-called-off-after-ministers-agree-to-talks/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 08:54:08+00:00

A planned 48-hour nursing strike has been canceled after U.K. ministers agreed to formal negotiations with union leaders.

## US States Reconsider $230M On Restricted Lexmark, Lenovo Products
 - [https://www.forbes.com/sites/roslynlayton/2023/02/24/us-states-reconsider-230m-on-restricted-lexmark-lenovo-products/](https://www.forbes.com/sites/roslynlayton/2023/02/24/us-states-reconsider-230m-on-restricted-lexmark-lenovo-products/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 08:05:20+00:00

New report suggests US state government contracts could give China easy access for spying, stealing, and cyberattacks.

## GPT-4 Is Coming – What We Know So Far
 - [https://www.forbes.com/sites/bernardmarr/2023/02/24/gpt-4-is-coming--what-we-know-so-far/](https://www.forbes.com/sites/bernardmarr/2023/02/24/gpt-4-is-coming--what-we-know-so-far/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 07:21:48+00:00

GPT-3 is the AI model underpinning the super-popular AI tool ChatGPT. OpenAI, the creator of GPT-3, is working on developing the next version of their model (GPT-4). Here we explore the many rumors and speculations.

## Artificial Intelligence Opens Up The World Of Financial Services
 - [https://www.forbes.com/sites/joemckendrick/2023/02/24/artificial-intelligence-opens-up-the-world-of-financial-services/](https://www.forbes.com/sites/joemckendrick/2023/02/24/artificial-intelligence-opens-up-the-world-of-financial-services/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 06:21:57+00:00

6 changes on the banking and FinTech horizon

## Lee County, Florida, Republican Party Passes Resolution To Ban Covid-19 Vaccines
 - [https://www.forbes.com/sites/brucelee/2023/02/24/lee-county-florida-republican-party-passes-resolution-to-ban-covid-19-vaccines/](https://www.forbes.com/sites/brucelee/2023/02/24/lee-county-florida-republican-party-passes-resolution-to-ban-covid-19-vaccines/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 05:00:36+00:00

This “Ban the jab” resolution will now go to the desk of Florida Governor Ron DeSantis (R) for his consideration.

## Telsa CCS ‘Magic Docks’ Revealed, But With Short Cords, Can Non-Tesla Cars Really Charge At Them?
 - [https://www.forbes.com/sites/bradtempleton/2023/02/23/telsa-ccs-magic-docks-revealed-but-with-short-cords-can-non-tesla-cars-really-charge-at-them/](https://www.forbes.com/sites/bradtempleton/2023/02/23/telsa-ccs-magic-docks-revealed-but-with-short-cords-can-non-tesla-cars-really-charge-at-them/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 04:52:59+00:00

These stalls have the built in CCS adapter known as the "Magic Dock" but otherwise have the same short charging cord common to Tesla Superchargers — a cord that can’t readily reach the charging ports on many non-Tesla cars.  We may see some fights.

## Today’s ‘Heardle’ Answer And Clues For Friday, February 24
 - [https://www.forbes.com/sites/krisholt/2023/02/23/todays-heardle-answer-and-clues-for-friday-february-24/](https://www.forbes.com/sites/krisholt/2023/02/23/todays-heardle-answer-and-clues-for-friday-february-24/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 04:24:12+00:00

Here's today's 'Heardle' song, along with some hints.

## Today’s ‘Quordle’ Answers And Clues For Friday, February 24
 - [https://www.forbes.com/sites/krisholt/2023/02/23/todays-quordle-answers-and-clues-for-friday-february-24/](https://www.forbes.com/sites/krisholt/2023/02/23/todays-quordle-answers-and-clues-for-friday-february-24/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 04:09:54+00:00

Some hints and the solution for today's 'Quordle' are just ahead.

## Mind-Bending Midjourney AI Art And Images From Simple Prompts
 - [https://www.forbes.com/sites/tjmccue/2023/02/23/mind-bending-midjourney-ai-art-and-images-from-simple-prompts/](https://www.forbes.com/sites/tjmccue/2023/02/23/mind-bending-midjourney-ai-art-and-images-from-simple-prompts/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 04:07:05+00:00

Here is Rob Lennon with another amazing Twitter thread about using specific keywords, everyday sorts of terms, nothing too technical like aspect ratio or art styles or software version codes, to come up with that stunning image you see in the post. He shares 16 new keywords that will energize your..

## AI Startups Boom In San Francisco Amid $100 Billion Google Mistake
 - [https://www.forbes.com/sites/martineparis/2023/02/23/ai-startups-boom-in-san-francisco-amid-100-billion-google-mistake/](https://www.forbes.com/sites/martineparis/2023/02/23/ai-startups-boom-in-san-francisco-amid-100-billion-google-mistake/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 04:05:51+00:00

San Francisco’s AI startup scene is blowing up thanks to the ChatGPT craze and investors including Y Combinator, Bessemer Venture Partners, Coatue, Andreessen Horowitz, Tiger Global, Mark Benioff's Time Ventures and Ashton Kutcher's Sound Ventures. Meet the players waking up the City by the Bay.

## Today’s Wordle #615 Hint, Clues And Answer For Friday, February 24th
 - [https://www.forbes.com/sites/erikkain/2023/02/23/todays-wordle-615-hint-clues-and-answer-for-friday-february-24th/](https://www.forbes.com/sites/erikkain/2023/02/23/todays-wordle-615-hint-clues-and-answer-for-friday-february-24th/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 03:30:00+00:00

Hints and clues to help you with today's Wordle.

## Samsung Galaxy S23 Ultra Review: 200 Megapixel Powerhouse
 - [https://www.forbes.com/sites/bensin/2023/02/23/samsung-galaxy-s23-ultra-review-200-megapixel-powerhouse/](https://www.forbes.com/sites/bensin/2023/02/23/samsung-galaxy-s23-ultra-review-200-megapixel-powerhouse/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 02:40:04+00:00

Samsung’s Galaxy S23 Ultra has a 200-megapixel camera that can produce some superb photos.

## The Magic Band
 - [https://www.forbes.com/sites/richkarlgaard/2023/02/23/the-magic-band/](https://www.forbes.com/sites/richkarlgaard/2023/02/23/the-magic-band/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 01:30:00+00:00

Investors looking for outperformance in emerging markets should keep an eye on India.

## The Unexpected Winners Of The ChatGPT Generative AI Revolution
 - [https://www.forbes.com/sites/alexzhavoronkov/2023/02/23/the-unexpected-winners-of-the-chatgpt-generative-ai-revolution/](https://www.forbes.com/sites/alexzhavoronkov/2023/02/23/the-unexpected-winners-of-the-chatgpt-generative-ai-revolution/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 00:13:24+00:00

Generative AI is taking the world by the storm with billions invested in infrastructure, data, and people. The ability to generate human-level responses to complex queries is expected to transform publishing. But publishers may be the biggest winners of the generative AI revolution.

## Data Democratization In A Hybrid World
 - [https://www.forbes.com/sites/patrickmoorhead/2023/02/23/data-democratization-in-a-hybrid-world/](https://www.forbes.com/sites/patrickmoorhead/2023/02/23/data-democratization-in-a-hybrid-world/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-24 00:03:47+00:00

#1-Ranked Industry Analyst Patrick Moorhead gives his insights on data democritization in a hybrid world.

