# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## UE zatwierdziła 10. pakiet sankcji wobec Rosji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ue-zatwierdzila-10-pakiet-sankcji-wobec-rosji,nId,6618481](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ue-zatwierdzila-10-pakiet-sankcji-wobec-rosji,nId,6618481)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 21:40:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ue-zatwierdzila-10-pakiet-sankcji-wobec-rosji,nId,6618481"><img align="left" alt="UE zatwierdziła 10. pakiet sankcji wobec Rosji  " src="https://i.iplsc.com/ue-zatwierdzila-10-pakiet-sankcji-wobec-rosji/000GT54DX06VVSCC-C321.jpg" /></a>Unia Europejska zatwierdziła w rocznicę inwazji na Ukrainę 10. pakiet sankcji wobec Rosji - poinformowała w piątek późnym wieczorem szwedzka prezydencja UE. </p><br clear="all" />

## Trzęsienie ziemi w Turcji i Syrii. Ponad 50 tys. ofiar
 - [https://wydarzenia.interia.pl/zagranica/news-trzesienie-ziemi-w-turcji-i-syrii-ponad-50-tys-ofiar,nId,6618478](https://wydarzenia.interia.pl/zagranica/news-trzesienie-ziemi-w-turcji-i-syrii-ponad-50-tys-ofiar,nId,6618478)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 21:13:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-trzesienie-ziemi-w-turcji-i-syrii-ponad-50-tys-ofiar,nId,6618478"><img align="left" alt="Trzęsienie ziemi w Turcji i Syrii. Ponad 50 tys. ofiar" src="https://i.iplsc.com/trzesienie-ziemi-w-turcji-i-syrii-ponad-50-tys-ofiar/000GT4Z5IC4MPSSN-C321.jpg" /></a>Liczba ofiar trzęsienia ziemi w Turcji i Syrii, które miało miejsce 6 lutego, przekroczyła 50 tysięcy. Mimo wielu &quot;cudów&quot;, jakie miały miejsce, czyli odnalezieniu po wielu godzinach żywych osób, teraz coraz rzadziej docierają takie informacje. W poniedziałek, 20 lutego doszło do kolejnego trzęsienia ziemi w południowej Turcji.</p><br clear="all" />

## Christo Grozew: Były realne plany zamachu na mnie
 - [https://wydarzenia.interia.pl/zagranica/news-christo-grozew-byly-realne-plany-zamachu-na-mnie,nId,6618472](https://wydarzenia.interia.pl/zagranica/news-christo-grozew-byly-realne-plany-zamachu-na-mnie,nId,6618472)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 21:02:52+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-christo-grozew-byly-realne-plany-zamachu-na-mnie,nId,6618472"><img align="left" alt="Christo Grozew: Były realne plany zamachu na mnie" src="https://i.iplsc.com/christo-grozew-byly-realne-plany-zamachu-na-mnie/000GT4YBNBNAHKD6-C321.jpg" /></a>- W Londynie zatrzymano osoby podejrzane o przygotowywanie zamachu na mnie - poinformował współtwórca portalu Belingcat, bułgarski dziennikarz śledczy Christo Grozew. Jest on autorem artykułów na temat działalności rosyjskiego wywiadu wojskowego w Europie Wschodniej.</p><br clear="all" />

## Media: Macron i Scholz mieli nakłaniać Zełenskiego do pokojowych rozmów z Rosją
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-macron-i-scholz-mieli-naklaniac-zelenskiego-do-pokojow,nId,6618468](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-macron-i-scholz-mieli-naklaniac-zelenskiego-do-pokojow,nId,6618468)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 20:44:27+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-macron-i-scholz-mieli-naklaniac-zelenskiego-do-pokojow,nId,6618468"><img align="left" alt="Media: Macron i Scholz mieli nakłaniać Zełenskiego do pokojowych rozmów z Rosją " src="https://i.iplsc.com/media-macron-i-scholz-mieli-naklaniac-zelenskiego-do-pokojow/000GT4YCXY03ERQC-C321.jpg" /></a>Prezydent Francji i kanclerz Niemiec podczas spotkania w Paryżu na początku lutego mieli powiedzieć przywódcy Ukrainy, że powinien zacząć rozważać rozmowy pokojowe z Moską - twierdzi amerykański dziennik &quot;The Wall Street Journal&quot;. </p><br clear="all" />

## Poślubiła szmacianką lalkę, z którą ma dziecko. Ktoś porwał je dla okupu
 - [https://wydarzenia.interia.pl/zagranica/news-poslubila-szmacianka-lalke-z-ktora-ma-dziecko-ktos-porwal-je,nId,6618403](https://wydarzenia.interia.pl/zagranica/news-poslubila-szmacianka-lalke-z-ktora-ma-dziecko-ktos-porwal-je,nId,6618403)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 20:26:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-poslubila-szmacianka-lalke-z-ktora-ma-dziecko-ktos-porwal-je,nId,6618403"><img align="left" alt="Poślubiła szmacianką lalkę, z którą ma dziecko. Ktoś porwał je dla okupu" src="https://i.iplsc.com/poslubila-szmacianka-lalke-z-ktora-ma-dziecko-ktos-porwal-je/000GT49N9PV9MF92-C321.jpg" /></a>37-letnia Meirivone Rocha Moraes z Brazylii zadziwiła świat swoim związkiem ze szmacianą lalką, którą poślubiła w zeszłym roku. Od tamtego czasu para przeżywała zarówno wzloty, jak i upadki. Mąż miał ją zdradzić, gdy kobieta przebywała w szpitalu, ale mimo kryzysu udało się im pogodzić i teraz są rodzicami małej, równie szmacianej - co tata - lalki. Jak się jednak okazuje, i tutaj sielanka nie trwała długo. Zrozpaczona matka poinformowała tym razem swoich obserwatorów na TikToku, że ktoś porwał ich syna dla okupu.</p><br clear="all" />

## Gesty solidarności z Ukrainą nawet w Rosji. Zatrzymano ponad 20 protestujących
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-gesty-solidarnosci-z-ukraina-nawet-w-rosji-zatrzymano-ponad-,nId,6618460](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-gesty-solidarnosci-z-ukraina-nawet-w-rosji-zatrzymano-ponad-,nId,6618460)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 20:12:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-gesty-solidarnosci-z-ukraina-nawet-w-rosji-zatrzymano-ponad-,nId,6618460"><img align="left" alt="Gesty solidarności z Ukrainą nawet w Rosji. Zatrzymano ponad 20 protestujących" src="https://i.iplsc.com/gesty-solidarnosci-z-ukraina-nawet-w-rosji-zatrzymano-ponad/000GT4PFILIQ8X1B-C321.jpg" /></a>W rocznicę rosyjskiej inwazji na Ukrainę w wielu miastach na świecie odbyły się manifestacje symbolizujące solidarność z Ukrainą. Również w Rosji odbyły się antywojenne protesty. Policja zatrzymała ponad 20 uczestników akcji, które odbyły się m.in. w Petersburgu i Irkucku. Ludzie wyszli na jednoosobowe pikiety, bądź składali kwiaty pod pomnikami związanymi z Ukrainą. Na ulicach można było zobaczyć takie hasła jak: &quot;Dość milczenia&quot;, czy &quot;Wybacz, Ukraino&quot;.</p><br clear="all" />

## Nieprzyzwoite zachowanie pasażerów. Krzyczeli w stronę stewardessy, że ją kochają
 - [https://wydarzenia.interia.pl/zagranica/news-nieprzyzwoite-zachowanie-pasazerow-krzyczeli-w-strone-stewar,nId,6618426](https://wydarzenia.interia.pl/zagranica/news-nieprzyzwoite-zachowanie-pasazerow-krzyczeli-w-strone-stewar,nId,6618426)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 20:07:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nieprzyzwoite-zachowanie-pasazerow-krzyczeli-w-strone-stewar,nId,6618426"><img align="left" alt="Nieprzyzwoite zachowanie pasażerów. Krzyczeli w stronę stewardessy, że ją kochają" src="https://i.iplsc.com/nieprzyzwoite-zachowanie-pasazerow-krzyczeli-w-strone-stewar/000GT4H73XE6Q7SE-C321.jpg" /></a>&quot;Chloe, kochamy Cię&quot;, &quot;pokaż piersi&quot; - takie hasła podczas lotu wykrzykiwali kibice w stronę jednej ze stewardess. Mężczyźni byli pod wpływem alkoholu, a za &quot;ofiarę&quot; obrali sobie pracownicę linii lotniczych. Kobieta jednak stwierdza, że ich zachowanie było &quot;nieszkodliwą zabawą&quot;.</p><br clear="all" />

## Negocjacje Londynu z Brukselą przedłużają się. Mają trwać także w weekend
 - [https://wydarzenia.interia.pl/zagranica/news-negocjacje-londynu-z-bruksela-przedluzaja-sie-maja-trwac-tak,nId,6618410](https://wydarzenia.interia.pl/zagranica/news-negocjacje-londynu-z-bruksela-przedluzaja-sie-maja-trwac-tak,nId,6618410)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 19:53:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-negocjacje-londynu-z-bruksela-przedluzaja-sie-maja-trwac-tak,nId,6618410"><img align="left" alt="Negocjacje Londynu z Brukselą przedłużają się. Mają trwać także w weekend" src="https://i.iplsc.com/negocjacje-londynu-z-bruksela-przedluzaja-sie-maja-trwac-tak/000G90JLUY9E93O5-C321.jpg" /></a>Intensywne negocjacje Londynu z Brukselą, dotyczące nowych przepisów pobrexitowych dla Irlandii Północnej, postępują z godziny na godzinę - donoszą brytyjskie media. Wynik trwających ponad rok rozmów miał być pierwotnie znany w poniedziałek. Pertraktacje przedłużyły się jednak z powodu wątpliwości parlamentarzystów Partii Konserwatywnej, którzy nie zgadzają się na znaczącą rolę Europejskiego Trybunału Sprawiedliwości w nowych prawodawstwie.</p><br clear="all" />

## Prezydent Gruzji krytykuje rząd. Mówi o "odseparowaniu się" w sprawie wojny
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prezydent-gruzji-krytykuje-rzad-mowi-o-odseparowaniu-sie-w-s,nId,6618397](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prezydent-gruzji-krytykuje-rzad-mowi-o-odseparowaniu-sie-w-s,nId,6618397)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 19:02:20+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prezydent-gruzji-krytykuje-rzad-mowi-o-odseparowaniu-sie-w-s,nId,6618397"><img align="left" alt="Prezydent Gruzji krytykuje rząd. Mówi o &quot;odseparowaniu się&quot; w sprawie wojny" src="https://i.iplsc.com/prezydent-gruzji-krytykuje-rzad-mowi-o-odseparowaniu-sie-w-s/000GT46137SDG9WT-C321.jpg" /></a>Prezydent Gruzji Salome Zurabiszwili wyraziła w piątek ubolewanie z powodu postawy rządu jej kraju wobec inwazji Rosji na Ukrainę. Polityk stwierdziła, że rząd &quot;odizolował się i odseparował od wspólnoty demokratycznej i usiłuje usprawiedliwić swoje jakoby neutralne i zrównoważone stanowisko&quot;. Jak dodała, jest ono &quot;dla wszystkich niezrozumiałe&quot;.</p><br clear="all" />

## Duda o wojnie w Ukrainie: Żołnierz na froncie żyje średnio pięć godzin
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-duda-o-wojnie-w-ukrainie-zolnierz-na-froncie-zyje-srednio-pi,nId,6618202](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-duda-o-wojnie-w-ukrainie-zolnierz-na-froncie-zyje-srednio-pi,nId,6618202)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 18:43:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-duda-o-wojnie-w-ukrainie-zolnierz-na-froncie-zyje-srednio-pi,nId,6618202"><img align="left" alt="Duda o wojnie w Ukrainie: Żołnierz na froncie żyje średnio pięć godzin" src="https://i.iplsc.com/duda-o-wojnie-w-ukrainie-zolnierz-na-froncie-zyje-srednio-pi/000GT45W0YT9SA3H-C321.jpg" /></a>24 lutego, w rocznicę wybuchu pełnoskalowej inwazji Federacji Rosyjskiej na Ukrainę, gośćmi Bogdana Rymanowskiego na antenie Polsat News byli prezydenci: Andrzej Duda i Wołodymyr Zełenski. Wśród poruszanych przez prowadzącego program tematów był m.in. stosunek obu głów państw do Władimira Putina, warunki, które Rosja musiałaby spełnić, aby negocjować zawarcie pokoju oraz emocje, jakie towarzyszą prezydentowi zaatakowanego kraju podczas czytania meldunków o zabitych.</p><br clear="all" />

## Prezydent Zełenski dla Polsatu: Odbicie okupowanych terenów to nasze główne zadanie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prezydent-zelenski-dla-polsatu-odbicie-okupowanych-terenow-t,nId,6618205](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prezydent-zelenski-dla-polsatu-odbicie-okupowanych-terenow-t,nId,6618205)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 18:34:46+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prezydent-zelenski-dla-polsatu-odbicie-okupowanych-terenow-t,nId,6618205"><img align="left" alt="Prezydent Zełenski dla Polsatu: Odbicie okupowanych terenów to nasze główne zadanie" src="https://i.iplsc.com/prezydent-zelenski-dla-polsatu-odbicie-okupowanych-terenow-t/000GT464OL07Y9C1-C321.jpg" /></a>- Odbicie okupowanych terenów to nasze główne zadanie - powiedział prezydent Wołodymyr Zełenski w programie &quot;Gość Wydarzeń&quot; na antenie telewizji Polsat i Polsat News. Był to wspólny wywiad z udziałem prezydenta Andrzeja Dudy.  Ukraiński przywódca wskazał, że dla jego państwa kluczowe jest tempo zachodnich dostaw sprzętu wojskowego. - Do obrony naszego nieba potrzebujemy również samolotów, ale oczywiście potrzebny jest bolesny czas - być może od czterech do pięciu miesięcy - niezbędny na szkolenia ukraińskich pilotów - zaznaczył Wołodymyr...</p><br clear="all" />

## Zełenski zapytany o Chiny. Padły zaskakujące słowa
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-zapytany-o-chiny-padly-zaskakujace-slowa,nId,6618399](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-zapytany-o-chiny-padly-zaskakujace-slowa,nId,6618399)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 18:03:53+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-zapytany-o-chiny-padly-zaskakujace-slowa,nId,6618399"><img align="left" alt="Zełenski zapytany o Chiny. Padły zaskakujące słowa" src="https://i.iplsc.com/zelenski-zapytany-o-chiny-padly-zaskakujace-slowa/000GT45B8MF8X3IE-C321.jpg" /></a>W rocznicę rosyjskiej agresji na Ukrainę prezydent Wołodymyr Zełenski wziął udział w specjalnej konferencji prasowej dla mediów z całego świata. W czasie spotkania z dziennikarzami ukraiński przywódca pytany był m.in. o swoje odczucia względem Rosji i Władimira Putina, a także rolę Polski i państw bałtyckich w trwającej od roku wojnie na pełną skalę. Na konferencji nie zabrakło też pytań o nowy &quot;pokojowy plan&quot;, który zaproponowały Chiny, jak również o osobiste wspomnienia z ostatnich 365 dni. Zełenski miał też niecodzienną wymianę zdań z...</p><br clear="all" />

## Pasażerka próbowała wtargnąć do kokpitu. Samolot musiał awaryjnie lądować
 - [https://wydarzenia.interia.pl/zagranica/news-pasazerka-probowala-wtargnac-do-kokpitu-samolot-musial-awary,nId,6618364](https://wydarzenia.interia.pl/zagranica/news-pasazerka-probowala-wtargnac-do-kokpitu-samolot-musial-awary,nId,6618364)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 17:54:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pasazerka-probowala-wtargnac-do-kokpitu-samolot-musial-awary,nId,6618364"><img align="left" alt="Pasażerka próbowała wtargnąć do kokpitu. Samolot musiał awaryjnie lądować" src="https://i.iplsc.com/pasazerka-probowala-wtargnac-do-kokpitu-samolot-musial-awary/000GT40M2BCRV531-C321.jpg" /></a>Samolot pasażerski, lecący z Jacksonville na Florydzie do Waszyngtonu, musiał awaryjnie lądować w Karolinie Północnej. Wszystko przez &quot;niesforną&quot; pasażerkę, która próbowała wtargnąć do kokpitu pilota. Kobieta zdenerwowała się, ponieważ nie podano jej napoju. 36-latkę próbowali uspokoić pasażerowie i załoga samolotu.</p><br clear="all" />

## Zełenski zapytany o Chiny. Padły zaskakujące słowa
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-zapytany-o-chiny-padly-zaskakujace-slowa,nId,6618382](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-zapytany-o-chiny-padly-zaskakujace-slowa,nId,6618382)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 17:39:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-zapytany-o-chiny-padly-zaskakujace-slowa,nId,6618382"><img align="left" alt="Zełenski zapytany o Chiny. Padły zaskakujące słowa" src="https://i.iplsc.com/zelenski-zapytany-o-chiny-padly-zaskakujace-slowa/000GT45B8MF8X3IE-C321.jpg" /></a>W rocznicę rosyjskiej agresji na Ukrainę prezydent Wołodymyr Zełenski wziął udział w specjalnej konferencji prasowej dla mediów z całego świata. W czasie spotkania z dziennikarzami ukraiński przywódca pytany był m.in. o swoje odczucia względem Rosji i Władimira Putina, a także rolę Polski i państw bałtyckich w trwająceh od roku wojnie. Na konferencji nie zabrakło też pytań o nowy &quot;pokojowy plan&quot;, który zaproponowały Chiny, jak również o osobiste wspomnienia z ostatnich 365 dni.</p><br clear="all" />

## "365 dni bohaterstwa, 365 dni wsparcia". Manifestacja solidarności z Ukrainą [ZDJĘCIA]
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/zdjecie,iId,3297741,iAId,443213](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/zdjecie,iId,3297741,iAId,443213)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 17:23:02+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/zdjecie,iId,3297741,iAId,443213"><img align="left" alt="&quot;365 dni bohaterstwa, 365 dni wsparcia&quot;. Manifestacja solidarności z Ukrainą [ZDJĘCIA]" src="https://i.iplsc.com/365-dni-bohaterstwa-365-dni-wsparcia-manifestacja-solidarnos/000GT43UT7HTOWL8-C321.jpg" /></a>Przed ambasadą Rosji w Warszawie rozpoczęła się demonstracja, która poprzedza marsz solidarności pod hasłem &quot;365 dni bohaterstwa, 365 dni wsparcia&quot;. Uczestnicy w ten sposób chcą oddać hołd bohaterom oraz uczcić pamięć ofiar w pierwszą rocznicę pełnowymiarowej rosyjskiej inwazji na Ukrainę.</p><br clear="all" />

## We Lwowie kochają Andrzeja Dudę. Reporter zapytał o niego dwie Ukrainki
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-we-lwowie-kochaja-andrzeja-dude-reporter-zapytal-o-niego-dwi,nId,6618166](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-we-lwowie-kochaja-andrzeja-dude-reporter-zapytal-o-niego-dwi,nId,6618166)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 16:20:43+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-we-lwowie-kochaja-andrzeja-dude-reporter-zapytal-o-niego-dwi,nId,6618166"><img align="left" alt="We Lwowie kochają Andrzeja Dudę. Reporter zapytał o niego dwie Ukrainki" src="https://i.iplsc.com/we-lwowie-kochaja-andrzeja-dude-reporter-zapytal-o-niego-dwi/000GT3DRESUW087C-C321.jpg" /></a>Rocznica brutalnej inwazji Rosji na wolną Ukrainę stała się okazją do zapytania mieszkańców ogarniętego wojną kraju o ich odczucia dotyczące roli Polaków i polskiego rządu w tym trudnym dla nich okresie. Na ten temat rozmawiał z napotkanymi ludźmi w piątek we Lwowie reporter Polsat News. Jednym z poruszonych przez niego wątków była opinia dotycząca naszego prezydenta. Trudno nie odnieść wrażenia, że Andrzej Duda jest tam uwielbiany.</p><br clear="all" />

## Mołdawia ostrzega przed wzrostem napięcia. "Rosja chce naszego upadku"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-moldawia-ostrzega-przed-wzrostem-napiecia-rosja-chce-naszego,nId,6618113](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-moldawia-ostrzega-przed-wzrostem-napiecia-rosja-chce-naszego,nId,6618113)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 16:02:20+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-moldawia-ostrzega-przed-wzrostem-napiecia-rosja-chce-naszego,nId,6618113"><img align="left" alt="Mołdawia ostrzega przed wzrostem napięcia. &quot;Rosja chce naszego upadku&quot;" src="https://i.iplsc.com/moldawia-ostrzega-przed-wzrostem-napiecia-rosja-chce-naszego/000GSPDH6AWQ0QQJ-C321.jpg" /></a>Rosja stosuje wobec nas operację psychologiczną. Ostrzegamy wszystkich przed wzrostem napięcia w Naddniestrzu - oświadczył rząd w Kiszyniowie, odpowiadając na rosyjskie prowokacje na granicy Mołdawii z Ukrainą. Prezydent Maia Sandu podkreśliła również, że celem Rosji jest destabilizacja jej państwa i wprowadzenie tam proroyjskiego rządu marionetkowego.</p><br clear="all" />

## Potężny cios dla Rosji. USA ogłosiły nowe sankcje
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-potezny-cios-dla-rosji-usa-oglosily-nowe-sankcje,nId,6618152](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-potezny-cios-dla-rosji-usa-oglosily-nowe-sankcje,nId,6618152)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 15:36:50+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-potezny-cios-dla-rosji-usa-oglosily-nowe-sankcje,nId,6618152"><img align="left" alt="Potężny cios dla Rosji. USA ogłosiły nowe sankcje" src="https://i.iplsc.com/potezny-cios-dla-rosji-usa-oglosily-nowe-sankcje/000GT38QLVPVD4JC-C321.jpg" /></a>W pierwszą rocznicę rosyjskiej agresji na Ukrainę USA ogłosiły kolejny &quot;pakiet szerokich sankcji&quot; przeciwko Rosji i jej sojusznikom. Te mają uderzyć w rosyjską gospoarkę i osłabić zdolności Moskwy do prowadzenia wojny.  </p><br clear="all" />

## Rocznica wojny w Ukrainie. Pilny komunikat liderów Trójkąta Weimarskiego
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rocznica-wojny-w-ukrainie-pilny-komunikat-liderow-trojkata-w,nId,6618172](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rocznica-wojny-w-ukrainie-pilny-komunikat-liderow-trojkata-w,nId,6618172)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 15:36:17+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rocznica-wojny-w-ukrainie-pilny-komunikat-liderow-trojkata-w,nId,6618172"><img align="left" alt="Rocznica wojny w Ukrainie. Pilny komunikat liderów Trójkąta Weimarskiego" src="https://i.iplsc.com/rocznica-wojny-w-ukrainie-pilny-komunikat-liderow-trojkata-w/000GDJY4YCVFG1QO-C321.jpg" /></a>Liderzy państ Trójkąta Weimarskiego (Polska-Niemcy-Francja) wydali wspólny komunikat w rocznicę wybuchu rosyjskiej agresji na Ukrainę. Przywódcy podkreślili, że będą mocno wspierać Ukrainę i jej naród tak długo, jak będzie to konieczne.</p><br clear="all" />

## Chiny murem za Białorusią. Mówią o "nielegalnych sankcjach"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-chiny-murem-za-bialorusia-mowia-o-nielegalnych-sankcjach,nId,6618165](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-chiny-murem-za-bialorusia-mowia-o-nielegalnych-sankcjach,nId,6618165)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 15:23:09+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-chiny-murem-za-bialorusia-mowia-o-nielegalnych-sankcjach,nId,6618165"><img align="left" alt="Chiny murem za Białorusią. Mówią o &quot;nielegalnych sankcjach&quot;" src="https://i.iplsc.com/chiny-murem-za-bialorusia-mowia-o-nielegalnych-sankcjach/000DN1BWVUNQQIB3-C321.jpg" /></a>Nie spada poparcie Chin dla rządów Alaksandra Łukaszenki na Białorusi. Jak poinformował szef MSZ ChRL, Pekin będzie dalej popierały Białoruś w wysiłkach na rzecz &quot;utrzymania stabilności&quot; w regionie. Dodatakowo Chiny sprzeciwiają się jakimkolwiek &quot;nielegalnym sankcjom&quot;, jakie Zachód narzuca na kraj Łukaszenki oraz Rosję Władimira Putina. </p><br clear="all" />

## Rok wojny w Ukrainie. Groteskowe szaleństwo Rosji tylko zjednoczyło jej wrogów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rok-wojny-w-ukrainie-groteskowe-szalenstwo-rosji-tylko-zjedn,nId,6618095](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rok-wojny-w-ukrainie-groteskowe-szalenstwo-rosji-tylko-zjedn,nId,6618095)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 15:08:47+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rok-wojny-w-ukrainie-groteskowe-szalenstwo-rosji-tylko-zjedn,nId,6618095"><img align="left" alt="Rok wojny w Ukrainie. Groteskowe szaleństwo Rosji tylko zjednoczyło jej wrogów" src="https://i.iplsc.com/rok-wojny-w-ukrainie-groteskowe-szalenstwo-rosji-tylko-zjedn/000GT35RFCF4B73V-C321.jpg" /></a>Godną miarą wojen nie powinny być geopolityczne żetony czy zawahania w sojuszach, a jednostkowe momenty osobistych cierpień i horrorów. Minął rok od rozpoczęcia rosyjskiej agresji na Ukrainę, a ja wciąż myślę o Jekaterinie i Walentynie. Dzięki policji udało im się wydostać spod ostrzału wokół ich maleńkiego mieszkania w Łysyczańsku, zanim ostatniego lata miasto padło łupem Rosjan - pisze specjalnie dla Interii Nick Paton Walsh, główny korespondent CNN ds. bezpieczeństwa międzynarodowego.</p><br clear="all" />

## Julia uważa, że jest zaginioną Madeleine. Wcześniej twierdziła co innego
 - [https://wydarzenia.interia.pl/zagranica/news-julia-uwaza-ze-jest-zaginiona-madeleine-wczesniej-twierdzila,nId,6618073](https://wydarzenia.interia.pl/zagranica/news-julia-uwaza-ze-jest-zaginiona-madeleine-wczesniej-twierdzila,nId,6618073)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 14:44:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-julia-uwaza-ze-jest-zaginiona-madeleine-wczesniej-twierdzila,nId,6618073"><img align="left" alt="Julia uważa, że jest zaginioną Madeleine. Wcześniej twierdziła co innego" src="https://i.iplsc.com/julia-uwaza-ze-jest-zaginiona-madeleine-wczesniej-twierdzila/000GT21YSB73SP94-C321.jpg" /></a>Świat z uwagą śledzi informacje dotyczące 21-letniej Polki, Julii Faustyny. Jakiś czas temu na swoim instagramowym koncie pokazała zdjęcia mające przekonać opinię publiczną do jej rzekomej tożsamości - kobieta uważa się za zaginioną przed 15 laty w portugalskim kurorcie Brytyjkę, Madeleine McCann. Do tych rewelacji z rezerwą podchodzą rodzice Madeleine, którzy jednak zgodzili się na test DNA. Zupełnie innego zdania są bliscy Julii, którzy stanowczo zaprzeczają jej internetowym doniesieniom. Teraz na temat 21-latki wypowiedziało się...</p><br clear="all" />

## Adam Niedzielski dla Interii: Ukraina chce wzorować się na polskim systemie ochrony zdrowia
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-adam-niedzielski-dla-interii-ukraina-chce-wzorowac-sie-na-po,nId,6615878](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-adam-niedzielski-dla-interii-ukraina-chce-wzorowac-sie-na-po,nId,6615878)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 14:15:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-adam-niedzielski-dla-interii-ukraina-chce-wzorowac-sie-na-po,nId,6615878"><img align="left" alt="Adam Niedzielski dla Interii: Ukraina chce wzorować się na polskim systemie ochrony zdrowia" src="https://i.iplsc.com/adam-niedzielski-dla-interii-ukraina-chce-wzorowac-sie-na-po/000GSX33GA1BJQ5G-C321.jpg" /></a>Mimo trwającej wojny Ukraina pracuje nad odbudową swojego systemu ochrony zdrowia. I chce wzorować się na Polsce. - Wiemy, że Ukraina chce iść w kierunku systemu polskiego, z centralnym płatnikiem i kontraktowaniem usług. Jesteśmy też bardzo dobrym przykładem na informatyzację opieki zdrowotnej i z tych doświadczeń nasi sąsiedzi też chcą korzystać. Przekazujemy również nasze standardy i wzorce wykorzystywane przy budowie nowoczesnych szpitali - mówi w rozmowie z Interią minister zdrowia Adam Niedzielski. Podsumowuje też rok pomocy medycznej...</p><br clear="all" />

## Ukraina: Ujawnił SMS do Wołodymyra Zełenskiego. "To nie jest prowokacja"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-ujawnil-sms-do-wolodymyra-zelenskiego-to-nie-jest-pr,nId,6618075](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-ujawnil-sms-do-wolodymyra-zelenskiego-to-nie-jest-pr,nId,6618075)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 13:49:45+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-ujawnil-sms-do-wolodymyra-zelenskiego-to-nie-jest-pr,nId,6618075"><img align="left" alt="Ukraina: Ujawnił SMS do Wołodymyra Zełenskiego. &quot;To nie jest prowokacja&quot;" src="https://i.iplsc.com/ukraina-ujawnil-sms-do-wolodymyra-zelenskiego-to-nie-jest-pr/000GT23HUK7DBDYQ-C321.jpg" /></a>- Inwazja rozpoczęła się o godzinie 3:40 na ługańskim odcinku oddziału straży granicznej - Powiedział Serhij Dejneko, generał dywizji Państwowej Służby Granicznej Ukrainy i jej dowódca w rozmowie z portalem Ukraińska Prawda. Dejneko po ataku Rosjan wysłał wiadomość do prezydenta Ukrainy Wołodymyra Zełenskiego o rozpoczęciu inwazji Rosji na Ukrainę. Treść SMS została ujawniona.</p><br clear="all" />

## Polscy wolontariusze w Charkowie. "Strach pojawiał się w nocy"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polscy-wolontariusze-w-charkowie-strach-pojawial-sie-w-nocy,nId,6616188](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polscy-wolontariusze-w-charkowie-strach-pojawial-sie-w-nocy,nId,6616188)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 13:36:11+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polscy-wolontariusze-w-charkowie-strach-pojawial-sie-w-nocy,nId,6616188"><img align="left" alt="Polscy wolontariusze w Charkowie. &quot;Strach pojawiał się w nocy&quot;" src="https://i.iplsc.com/polscy-wolontariusze-w-charkowie-strach-pojawial-sie-w-nocy/000GSYSYOXON9CYS-C321.jpg" /></a>Z własnej woli ruszyli do ogarniętej wojną Ukrainy. Czuli, że właśnie to jest ich miejsce, że ich powołaniem jest nieść pomoc tym najbardziej bezradnym. Być oparciem, dawać nadzieję, nalać gorącą zupę, pomóc wyjść z piwnicy, gdy skończy się nalot. W Ukrainie zobaczyli tych, których świat nie chciał przyjąć i tych, którzy nie byli w stanie uciekać. Ta podróż kosztowała ich wiele: Grażyna w Bachmucie straciła nogę, przeżyła dzięki Kamilowi. Wolontariusze opowiadają Interii, jak dziś wygląda ich życie - w Polsce i w Ukrainie.</p><br clear="all" />

## Pogoda na weekend. Znowu wróci śnieg i zima. Ale nie na długo
 - [https://wydarzenia.interia.pl/kraj/news-pogoda-na-weekend-znowu-wroci-snieg-i-zima-ale-nie-na-dlugo,nId,6617954](https://wydarzenia.interia.pl/kraj/news-pogoda-na-weekend-znowu-wroci-snieg-i-zima-ale-nie-na-dlugo,nId,6617954)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 13:13:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogoda-na-weekend-znowu-wroci-snieg-i-zima-ale-nie-na-dlugo,nId,6617954"><img align="left" alt="Pogoda na weekend. Znowu wróci śnieg i zima. Ale nie na długo" src="https://i.iplsc.com/pogoda-na-weekend-znowu-wroci-snieg-i-zima-ale-nie-na-dlugo/000GT1Q5LT9TFO4K-C321.jpg" /></a>Luty powoli dobiega końca, ale czy oznacza to również definitywny koniec najchłodniejszej pory roku? Jak się okazuje, jeszcze w weekend pogoda znów namiesza i doświadczymy prawdziwej zimowej aury. - Śnieg wróci i przez weekend będzie obserwowany właściwie w całym kraju - mówi Interii Grzegorz Walijewski z Instytutu Meteorologii i Gospodarki Wodnej. W sobotę i niedzielę na północy kraju możliwe będą także rzadko spotykane o tej porze roku zjawiska atmosferyczne - mogą tam bowiem wystąpić wyładowania atmosferyczne i burze śnieżne. Synoptyk...</p><br clear="all" />

## Jechał tirem i miał ponad dwa promile alkoholu. Policja zatrzymała kierowcę
 - [https://wydarzenia.interia.pl/lodzkie/news-jechal-tirem-i-mial-ponad-dwa-promile-alkoholu-policja-zatrz,nId,6617974](https://wydarzenia.interia.pl/lodzkie/news-jechal-tirem-i-mial-ponad-dwa-promile-alkoholu-policja-zatrz,nId,6617974)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 12:59:00+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-jechal-tirem-i-mial-ponad-dwa-promile-alkoholu-policja-zatrz,nId,6617974"><img align="left" alt="Jechał tirem i miał ponad dwa promile alkoholu. Policja zatrzymała kierowcę" src="https://i.iplsc.com/jechal-tirem-i-mial-ponad-dwa-promile-alkoholu-policja-zatrz/000GT1HRYD0VDBGB-C321.jpg" /></a>Dzięki zgłoszeniu na policję, zatrzymano pijanego kierowcę tira. Mężczyzna miał w organizmie ponad 2 promile alkoholu. Za jazdę w stanie nietrzeźwości kierowca usłyszy zarzuty. Grozi mu kara do dwóch lat pozbawienia wolności.</p><br clear="all" />

## Lwów w rocznicę wojny. "Jesteś z Polski, prawda? Proszę, zadzwoń do mojego syna"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-lwow-w-rocznice-wojny-jestes-z-polski-prawda-prosze-zadzwon-,nId,6617950](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-lwow-w-rocznice-wojny-jestes-z-polski-prawda-prosze-zadzwon-,nId,6617950)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 12:40:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-lwow-w-rocznice-wojny-jestes-z-polski-prawda-prosze-zadzwon-,nId,6617950"><img align="left" alt="Lwów w rocznicę wojny. &quot;Jesteś z Polski, prawda? Proszę, zadzwoń do mojego syna&quot;" src="https://i.iplsc.com/lwow-w-rocznice-wojny-jestes-z-polski-prawda-prosze-zadzwon/000GT1FAUFID99GI-C321.jpg" /></a>Na pytanie: &quot;czy widać wojnę we Lwowie?&quot; trudno odpowiedzieć jednoznacznie. Na pierwszy rzut oka wszystko wydaje się normalne. Jest prąd, działają sklepy i kawiarnie. Tu jednak każdy ma kogoś, kto walczy. Oto pięć historii, które pokazują ciche cierpienie i tęsknotę, które umykają wśród wojennych statystyk i kolejnych informacji o dostawach sprzętu. Zobaczyć je można dopiero na miejscu, wśród ludzi.</p><br clear="all" />

## Wołodymyr Zełenski dziękuje Polsce: Otrzymaliśmy pierwsze czołgi
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wolodymyr-zelenski-dziekuje-polsce-otrzymalismy-pierwsze-czo,nId,6618001](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wolodymyr-zelenski-dziekuje-polsce-otrzymalismy-pierwsze-czo,nId,6618001)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 12:18:09+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wolodymyr-zelenski-dziekuje-polsce-otrzymalismy-pierwsze-czo,nId,6618001"><img align="left" alt="Wołodymyr Zełenski dziękuje Polsce: Otrzymaliśmy pierwsze czołgi" src="https://i.iplsc.com/wolodymyr-zelenski-dziekuje-polsce-otrzymalismy-pierwsze-czo/000GT1QLLGH1ODRS-C321.jpg" /></a>- Otrzymaliśmy pierwsze czołgi z Polski, będą wzmacniać naszą obronę - powiedział prezydent Ukrainy Wołodymyr Zełenski podczas konferencji prasowej z premierem Mateuszem Morawieckim. - Polska jest liderem międzynarodowej koalicji w tej sprawie - zaznaczył Zełenski. - Chcę Tobie Wołodymyrze przekazać cztery pierwsze Leopardy, cztery 2A4 - przekazał premier. </p><br clear="all" />

## Dmitrij Miedwiediew: Trzeba przesunąć granicę, nawet do Polski
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dmitrij-miedwiediew-trzeba-przesunac-granice-nawet-do-polski,nId,6617962](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dmitrij-miedwiediew-trzeba-przesunac-granice-nawet-do-polski,nId,6617962)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 12:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dmitrij-miedwiediew-trzeba-przesunac-granice-nawet-do-polski,nId,6617962"><img align="left" alt="Dmitrij Miedwiediew: Trzeba przesunąć granicę, nawet do Polski" src="https://i.iplsc.com/dmitrij-miedwiediew-trzeba-przesunac-granice-nawet-do-polski/000GT1GZG1RRLON9-C321.jpg" /></a>Trzeba przesunąć granice zagrożeń dla Rosji jak najdalej, nawet do Polski - ocenił wiceprzewodniczący Rady Bezpieczeństwa Rosji Dmitrij Miedwiediew. W rocznicę rosyjskiej inwazji na Ukrainę rosyjski polityk, wpisując się w kremlowską propagandę opisał miniony rok i przedstawił, co dalej może się wydarzyć. &quot;Trzeba zniszczyć neonazizm do gruntu. Żeby później nie tracić czasu na łapanie niedobitków banderowców w lasach. Aby na świecie nastał długo wyczekiwany pokój&quot; - napisał. </p><br clear="all" />

## Polscy policjanci w Ukrainie. Rozbroili prawie dwa tysiące bomb
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polscy-policjanci-w-ukrainie-rozbroili-prawie-dwa-tysiace-bo,nId,6617904](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polscy-policjanci-w-ukrainie-rozbroili-prawie-dwa-tysiace-bo,nId,6617904)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 11:37:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polscy-policjanci-w-ukrainie-rozbroili-prawie-dwa-tysiace-bo,nId,6617904"><img align="left" alt="Polscy policjanci w Ukrainie. Rozbroili prawie dwa tysiące bomb" src="https://i.iplsc.com/polscy-policjanci-w-ukrainie-rozbroili-prawie-dwa-tysiace-bo/000GT185PBF9X1DQ-C321.jpg" /></a>Polscy policjanci przez pięć miesięcy zneutralizowali blisko dwa tysiące różnego rodzaju urządzeń i ładunków wybuchowych - przekazał Komendant Główny Policji gen. insp. Jarosław Szymczyk. Dodał, że ładunki były skonstruowane tak, by zabić jak najwięcej ludzi i były umieszczane np. w dziecięcych zabawkach, lodówkach czy w pianinie. Kontyngent humanitarny policji, który wyruszył do Ukrainy w październiku, w czwartek wrócił do Polski.</p><br clear="all" />

## Whiskey odnaleziona we wraku. Jest warta miliony
 - [https://wydarzenia.interia.pl/zagranica/news-whiskey-odnaleziona-we-wraku-jest-warta-miliony,nId,6617851](https://wydarzenia.interia.pl/zagranica/news-whiskey-odnaleziona-we-wraku-jest-warta-miliony,nId,6617851)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 11:28:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-whiskey-odnaleziona-we-wraku-jest-warta-miliony,nId,6617851"><img align="left" alt="Whiskey odnaleziona we wraku. Jest warta miliony" src="https://i.iplsc.com/whiskey-odnaleziona-we-wraku-jest-warta-miliony/000GT0UU9FEOBIOT-C321.jpg" /></a>Amerykańska whiskey została odnaleziona we wraku parowca, który 169 lat temu zatonął na dnie jeziora Michigan - podał portal Forbes. Odnaleziony alkohol może być wart nawet 871 milionów dolarów.  </p><br clear="all" />

## Scholz wobec wojny w Ukrainie. Bierność, fatalna komunikacja, niekompetentna minister. I pytanie - co dalej?
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-scholz-wobec-wojny-w-ukrainie-biernosc-fatalna-komunikacja-n,nId,6617911](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-scholz-wobec-wojny-w-ukrainie-biernosc-fatalna-komunikacja-n,nId,6617911)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 11:10:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-scholz-wobec-wojny-w-ukrainie-biernosc-fatalna-komunikacja-n,nId,6617911"><img align="left" alt="Scholz wobec wojny w Ukrainie. Bierność, fatalna komunikacja, niekompetentna minister. I pytanie - co dalej?" src="https://i.iplsc.com/scholz-wobec-wojny-w-ukrainie-biernosc-fatalna-komunikacja-n/000G8GHFSH1N71JN-C321.jpg" /></a>Dla wielu w Niemczech i na arenie międzynarodowej postawa kanclerza Olafa Scholza wobec Ukrainy jest rozczarowaniem. Ostatni rok to była polityka bierności i braku własnych inicjatyw, które mogły przyczynić się do wzmocnienia pozycji jego kraju na świecie. Tymczasem niemiecki kanclerz, co potwierdziła tutejsza prasa w swoich komentarzach po wizycie Bidena w Kijowie i Warszawie, przyczynił się do tego, że punkt ciężkości amerykańskiej polityki w Europie przesunął się na wschód - pisze Tomasz Lejman, korespondent Interii w Niemczech.</p><br clear="all" />

## W kościele na klęczkach. Krótko był anonimowy
 - [https://wydarzenia.interia.pl/lubuskie/news-w-kosciele-na-kleczkach-krotko-byl-anonimowy,nId,6617938](https://wydarzenia.interia.pl/lubuskie/news-w-kosciele-na-kleczkach-krotko-byl-anonimowy,nId,6617938)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 11:05:55+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-w-kosciele-na-kleczkach-krotko-byl-anonimowy,nId,6617938"><img align="left" alt="W kościele na klęczkach. Krótko był anonimowy" src="https://i.iplsc.com/w-kosciele-na-kleczkach-krotko-byl-anonimowy/000GT1CD84UYDU8M-C321.jpg" /></a>Udawał że się modli na klęczkach, w tym czasie próbował rozbroić kościelną skarbonkę. Mężczyzna nie był świadom, że jest nagrywany przez kościelny monitoring. Teraz grozi mu do 10 lat więzienia.</p><br clear="all" />

## Posiedzenie RBN. "Pierwsze Leopardy z Polski dotarły do Ukrainy"
 - [https://wydarzenia.interia.pl/kraj/news-posiedzenie-rbn-pierwsze-leopardy-z-polski-dotarly-do-ukrain,nId,6617635](https://wydarzenia.interia.pl/kraj/news-posiedzenie-rbn-pierwsze-leopardy-z-polski-dotarly-do-ukrain,nId,6617635)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 11:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-posiedzenie-rbn-pierwsze-leopardy-z-polski-dotarly-do-ukrain,nId,6617635"><img align="left" alt="Posiedzenie RBN. &quot;Pierwsze Leopardy z Polski dotarły do Ukrainy&quot;" src="https://i.iplsc.com/posiedzenie-rbn-pierwsze-leopardy-z-polski-dotarly-do-ukrain/000GT1EX05NUC7W1-C321.jpg" /></a>Rozpoczęło się posiedzenie Rady Bezpieczeństwa Narodowego, zwołane przez prezydenta Andrzeja Dudę. Przedmiotem spotkania będzie aktualna sytuacja bezpieczeństwa w kraju w związku z rosyjską inwazją na Ukrainę, a także wizyta prezydenta USA Joe Bidena w Polsce i spotkanie Bukaresztańskiej Dziewiątki. - Pierwsze czołgi Leopard z Polski dotarły do Ukrainy - przekazał Mariusz Błaszczak. - Premier pojechał do Kijowa zawieźć Leopardy - mówił prezydent Andrzej Duda. </p><br clear="all" />

## Rada Bezpieczeństwa Narodowego. Rozpoczyna się posiedzenie w Pałacu Prezydenckim
 - [https://wydarzenia.interia.pl/kraj/news-rada-bezpieczenstwa-narodowego-rozpoczyna-sie-posiedzenie-w-,nId,6617635](https://wydarzenia.interia.pl/kraj/news-rada-bezpieczenstwa-narodowego-rozpoczyna-sie-posiedzenie-w-,nId,6617635)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 11:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rada-bezpieczenstwa-narodowego-rozpoczyna-sie-posiedzenie-w-,nId,6617635"><img align="left" alt="Rada Bezpieczeństwa Narodowego. Rozpoczyna się posiedzenie w Pałacu Prezydenckim" src="https://i.iplsc.com/rada-bezpieczenstwa-narodowego-rozpoczyna-sie-posiedzenie-w/000GS0OGQMUFKLBQ-C321.jpg" /></a>Rozpoczyna się posiedzenie Rady Bezpieczeństwa Narodowego, zwołane przez prezydenta Andrzeja Dudę. Przedmiotem spotkania będzie aktualna sytuacja bezpieczeństwa w kraju w związku z rosyjską inwazją na Ukrainę, a także wizyta prezydenta USA Joe Bidena w Polsce.</p><br clear="all" />

## Wszystkie choroby Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wszystkie-choroby-putina,nId,6575054](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wszystkie-choroby-putina,nId,6575054)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 10:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wszystkie-choroby-putina,nId,6575054"><img align="left" alt="Wszystkie choroby Putina" src="https://i.iplsc.com/wszystkie-choroby-putina/000GPIJUA9GKEDM1-C321.jpg" /></a>Tu przytrzymał stół, tam zadrżała mu noga. Twarz jakby napuchnięta. Lista rzekomych chorób, na jakie cierpi rosyjski przywódca, rośnie z tygodnia na tydzień. Właściwie to już dawno powinien nie żyć. Oto Władimir Putin - starzec, którego zdrowiem interesuje się cały świat. </p><br clear="all" />

## Kraby, Osy i Dziki. Polskie uzbrojenie, które niszczy wojska Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kraby-osy-i-dziki-polskie-uzbrojenie-ktore-niszczy-wojska-pu,nId,6615620](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kraby-osy-i-dziki-polskie-uzbrojenie-ktore-niszczy-wojska-pu,nId,6615620)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 10:40:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kraby-osy-i-dziki-polskie-uzbrojenie-ktore-niszczy-wojska-pu,nId,6615620"><img align="left" alt="Kraby, Osy i Dziki. Polskie uzbrojenie, które niszczy wojska Putina" src="https://i.iplsc.com/kraby-osy-i-dziki-polskie-uzbrojenie-ktore-niszczy-wojska-pu/000GSYWQH1OEXHLM-C321.jpg" /></a>24 lutego 2022 wojska rosyjskie rozpoczęły inwazję na Ukrainę. Od samego początku Polska niezwykle aktywnie włączyła się w pomoc wschodniemu sąsiadowi. Nie tylko w formie pomocy humanitarnej, ale także wojskowej. W rocznicę wybuchu wojny przybliżamy liczby i rodzaj uzbrojenia, jakie Polska przekazała Ukrainie dla obrony jej niepodległości.</p><br clear="all" />

## 2023 będzie ciężkim rokiem dla Putina. Dopiero teraz odczuje pełną moc zachodnich sankcji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-2023-bedzie-ciezkim-rokiem-dla-putina-dopiero-teraz-odczuje-,nId,6617806](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-2023-bedzie-ciezkim-rokiem-dla-putina-dopiero-teraz-odczuje-,nId,6617806)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 10:39:33+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-2023-bedzie-ciezkim-rokiem-dla-putina-dopiero-teraz-odczuje-,nId,6617806"><img align="left" alt="2023 będzie ciężkim rokiem dla Putina. Dopiero teraz odczuje pełną moc zachodnich sankcji" src="https://i.iplsc.com/2023-bedzie-ciezkim-rokiem-dla-putina-dopiero-teraz-odczuje/000GT0O17LGI57MJ-C321.jpg" /></a>- Europa dostała nauczkę i odrabia swoją pracę domową - o gospodarczej wojnie Unii Europejskiej z Rosją mówi w rozmowie z Interią szwedzki ekonomista Anders Åslund. Były doradca gospodarczy rządów Ukrainy i Rosji podkreśla, że &quot;ekonomiczna dominacja Zachodu jest dzisiaj niepodważalna&quot;, a być albo nie być rosyjskiej gospodarki zależy dzisiaj de facto od trzech państw.</p><br clear="all" />

## Liceum postawiło szafki dla uczniów. Za ich wynajem trzeba zapłacić
 - [https://wydarzenia.interia.pl/slaskie/news-liceum-postawilo-szafki-dla-uczniow-za-ich-wynajem-trzeba-za,nId,6617826](https://wydarzenia.interia.pl/slaskie/news-liceum-postawilo-szafki-dla-uczniow-za-ich-wynajem-trzeba-za,nId,6617826)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 10:37:00+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-liceum-postawilo-szafki-dla-uczniow-za-ich-wynajem-trzeba-za,nId,6617826"><img align="left" alt="Liceum postawiło szafki dla uczniów. Za ich wynajem trzeba zapłacić" src="https://i.iplsc.com/liceum-postawilo-szafki-dla-uczniow-za-ich-wynajem-trzeba-za/000GT168SNYS6ELP-C321.jpg" /></a>Liceum w Dąbrowie Górniczej wprowadziło możliwość wynajęcia szafek za pieniądze. Jak przekazała szkoła w mediach społecznościowych, miejsca te &quot;są wartością dodaną do już istniejącego darmowego miejsca do przechowywania rzeczy dla uczniów&quot;. Pod postem ludzie skrytykowali inicjatywę placówki.</p><br clear="all" />

## Nadzieja przesiąknięta rozpaczą. "Przetrwają ci, którzy żyją tym co tu i teraz"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nadzieja-przesiaknieta-rozpacza-przetrwaja-ci-ktorzy-zyja-ty,nId,6615948](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nadzieja-przesiaknieta-rozpacza-przetrwaja-ci-ktorzy-zyja-ty,nId,6615948)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 10:32:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nadzieja-przesiaknieta-rozpacza-przetrwaja-ci-ktorzy-zyja-ty,nId,6615948"><img align="left" alt="Nadzieja przesiąknięta rozpaczą. &quot;Przetrwają ci, którzy żyją tym co tu i teraz&quot;" src="https://i.iplsc.com/nadzieja-przesiaknieta-rozpacza-przetrwaja-ci-ktorzy-zyja-ty/000GSXVBTQ95VY9D-C321.jpg" /></a>- Lekarze, czy szerzej cały system ochrony zdrowia, to dzisiaj drugi front tej wojny. Dwie najważniejsze służby w kraju to żołnierze i lekarze - mówi w rozmowie z Interią prof. Borys Todurow, wybitny ukraiński kardiochirurg. Dyrektor Instytutu Serca w Kijowie wspomina m.in. trudne pożegnanie z córką, która z powodu wojny wyjechała z Ukrainy do Wrocławia. - Wtedy nie wytrzymałem, dużo płakałem. Nerwy i emocje wzięły górę - mówi Todurow. Pytany o to, czy zająłby się pacjentem z Rosji, odpowiada bez wahania: - Jestem lekarzem od 35 lat i w tym...</p><br clear="all" />

## Amerykańska dziennikarka ranna na froncie. Jest sanitariuszką w ukraińskiej armii
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanska-dziennikarka-ranna-na-froncie-jest-sanitariuszka,nId,6617811](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanska-dziennikarka-ranna-na-froncie-jest-sanitariuszka,nId,6617811)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 10:23:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanska-dziennikarka-ranna-na-froncie-jest-sanitariuszka,nId,6617811"><img align="left" alt="Amerykańska dziennikarka ranna na froncie. Jest sanitariuszką w ukraińskiej armii" src="https://i.iplsc.com/amerykanska-dziennikarka-ranna-na-froncie-jest-sanitariuszka/000GT0UDQFV69R5D-C321.jpg" /></a>&quot;Dziś rano zostałam trafiona. Moje obrażenia są nieodwracalne. Straciłam część ręki i mam blizny na twarzy. Jednak wygraliśmy tę bitwę&quot; - napisała w czwartek na Twitterze amerykańska dziennikarka Sarah Ashton-Cirillo, która do sił zbrojnych Ukrainy wstąpiła jako sanitariuszka. Niedługo potem udzieliła krótkiego wywiadu dla CBS News z okopów. W czasie jego trwania powiedziała: Chcieliśmy przekazać wiadomość, że Ukraina jest silniejsza niż kiedykolwiek.</p><br clear="all" />

## "Teściowa Putina" w tarapatach. Wielka Brytania ogłasza sankcje
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tesciowa-putina-w-tarapatach-wielka-brytania-oglasza-sankcje,nId,6617866](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tesciowa-putina-w-tarapatach-wielka-brytania-oglasza-sankcje,nId,6617866)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 10:11:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tesciowa-putina-w-tarapatach-wielka-brytania-oglasza-sankcje,nId,6617866"><img align="left" alt="&quot;Teściowa Putina&quot; w tarapatach. Wielka Brytania ogłasza sankcje" src="https://i.iplsc.com/tesciowa-putina-w-tarapatach-wielka-brytania-oglasza-sankcje/000GT0Y30PJK8HSJ-C321.jpg" /></a>W pierwszą rocznicę wybuchu wojny Wielka Brytania rozszerzyła listę sankcyjną o 92 osoby i firmy z Rosji. Umieszczono na niej m.in. kierownictwo Gazpromu, Rosatomu, Rostechu i czterech banków. Na liście znalazła się też Lubow Kabajewa - matka byłej gimnastyczki i domniemanej kochanki Władimira Putina, Aliny. </p><br clear="all" />

## Bloomberg: Polska dostarczy dziś pierwsze Leopardy na Ukrainę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bloomberg-polska-dostarczy-dzis-pierwsze-leopardy-na-ukraine,nId,6617852](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bloomberg-polska-dostarczy-dzis-pierwsze-leopardy-na-ukraine,nId,6617852)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 09:35:01+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bloomberg-polska-dostarczy-dzis-pierwsze-leopardy-na-ukraine,nId,6617852"><img align="left" alt="Bloomberg: Polska dostarczy dziś pierwsze Leopardy na Ukrainę" src="https://i.iplsc.com/bloomberg-polska-dostarczy-dzis-pierwsze-leopardy-na-ukraine/000G7T8X5FSNVGMR-C321.jpg" /></a>Polska dostarczy w piątek pierwsze czołgi Leopard 2 na Ukrainę - podał Bloomberg. Portal cytuje anonimowego urzędnika. To pierwszy z 14 czołgów, które trafią do władz w Kijowie.</p><br clear="all" />

## Leopardy 2 dla Ukrainy. Polska jako pierwsza przekazała czołgi
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-leopardy-2-dla-ukrainy-polska-jako-pierwsza-przekazala-czolg,nId,6617852](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-leopardy-2-dla-ukrainy-polska-jako-pierwsza-przekazala-czolg,nId,6617852)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 09:35:01+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-leopardy-2-dla-ukrainy-polska-jako-pierwsza-przekazala-czolg,nId,6617852"><img align="left" alt="Leopardy 2 dla Ukrainy. Polska jako pierwsza przekazała czołgi " src="https://i.iplsc.com/leopardy-2-dla-ukrainy-polska-jako-pierwsza-przekazala-czolg/000GT11RG7MIOYR1-C321.jpg" /></a>Polska dostarczy w piątek pierwsze czołgi Leopard 2 na Ukrainę - podał Bloomberg. To pierwsze z 14 czołgów, które trafią do władz w Kijowie. Źródło zbliżone do rządu potwierdziło Interii, że pierwsze czołgi już dotarły do Ukrainy. </p><br clear="all" />

## Polska dostarczy dziś pierwsze Leopardy na Ukrainę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polska-dostarczy-dzis-pierwsze-leopardy-na-ukraine,nId,6617852](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polska-dostarczy-dzis-pierwsze-leopardy-na-ukraine,nId,6617852)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 09:35:01+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polska-dostarczy-dzis-pierwsze-leopardy-na-ukraine,nId,6617852"><img align="left" alt="Polska dostarczy dziś pierwsze Leopardy na Ukrainę" src="https://i.iplsc.com/polska-dostarczy-dzis-pierwsze-leopardy-na-ukraine/000G7T8X5FSNVGMR-C321.jpg" /></a>Polska dostarczy w piątek pierwsze czołgi Leopard 2 na Ukrainę. Chodzi o dwa Leopardy - potwierdza Interii źródło zbliżone do rządu. </p><br clear="all" />

## Życie seksualne żyraf. Naukowcy odkryli nietypowy rytuał
 - [https://wydarzenia.interia.pl/nauka/news-zycie-seksualne-zyraf-naukowcy-odkryli-nietypowy-rytual,nId,6617836](https://wydarzenia.interia.pl/nauka/news-zycie-seksualne-zyraf-naukowcy-odkryli-nietypowy-rytual,nId,6617836)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 09:18:07+00:00

<p><a href="https://wydarzenia.interia.pl/nauka/news-zycie-seksualne-zyraf-naukowcy-odkryli-nietypowy-rytual,nId,6617836"><img align="left" alt="Życie seksualne żyraf. Naukowcy odkryli nietypowy rytuał " src="https://i.iplsc.com/zycie-seksualne-zyraf-naukowcy-odkryli-nietypowy-rytual/000GT0SNX742YPM2-C321.jpg" /></a>Żyrafy nie mają ustalonego sezonu rozroczego. Nie przechodzą rui, jak psy czy koty. Nie wykonują wezwań godowych ani nie dostarczają wizualnych wskazówek świadczących o gotowości do odbycia stosunku. Skąd więc samiec żyrafy może wiedzieć, że jego zaloty zostaną zaakceptowane? W skrócie: przez mocz, feromony i delikatne szturchnięcia.</p><br clear="all" />

## "Myślałem, że być może widzę go po raz ostatni". Kulisy przyjaźni Andrzeja Dudy i Wołodymyra Zełenskiego
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-myslalem-ze-byc-moze-widze-go-po-raz-ostatni-kulisy-przyjazn,nId,6617667](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-myslalem-ze-byc-moze-widze-go-po-raz-ostatni-kulisy-przyjazn,nId,6617667)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 09:08:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-myslalem-ze-byc-moze-widze-go-po-raz-ostatni-kulisy-przyjazn,nId,6617667"><img align="left" alt="&quot;Myślałem, że być może widzę go po raz ostatni&quot;. Kulisy przyjaźni Andrzeja Dudy i Wołodymyra Zełenskiego" src="https://i.iplsc.com/myslalem-ze-byc-moze-widze-go-po-raz-ostatni-kulisy-przyjazn/000GT0NRYL5UTNT5-C321.jpg" /></a>Miesiąc przed wybuchem wojny Wołodymyr Zełenski przyjechał do Wisły na półprywatne spotkanie z Andrzejem Dudą. Przegadali wtedy długie godziny, omawiając różne scenariusze. - Mogę uczciwie powiedzieć, że właśnie wtedy, w Wiśle, na kilka tygodni przed rosyjską agresją narodziła się nasza przyjaźń. Długo i szczerze rozmawialiśmy - opowiada w rozmowie z Interią prezydent Andrzej Duda. W Interii opisujemy, jak osobiste relacje obu prezydentów przełożyły się na relacje między ich krajami.</p><br clear="all" />

## Rosja: Dyskusja w propagandowym programie. "Próbują przekonać siebie nawzajem, że wszystko idzie zgodnie z planem"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-dyskusja-w-propagandowym-programie-probuja-przekonac-s,nId,6617639](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-dyskusja-w-propagandowym-programie-probuja-przekonac-s,nId,6617639)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 09:02:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-dyskusja-w-propagandowym-programie-probuja-przekonac-s,nId,6617639"><img align="left" alt="Rosja: Dyskusja w propagandowym programie. &quot;Próbują przekonać siebie nawzajem, że wszystko idzie zgodnie z planem&quot;" src="https://i.iplsc.com/rosja-dyskusja-w-propagandowym-programie-probuja-przekonac-s/000GT0O33CHFN3G1-C321.jpg" /></a>- Wszystkie zadania służą osiągnięciom celów. Zadania mogą się zmieniać, wszystko zmienia się w zależności od warunków - padło w propagandowym programie w rosyjskiej telewizji, podczas dyskusji o wojnie w Ukrainie. &quot;Rosyjscy propagandyści próbują przekonać siebie nawzajem, że wszystko idzie zgodnie z planem&quot; - ocenił Anton Heraszczenko, doradca MSW Ukrainy. </p><br clear="all" />

## Tragiczny wypadek na S8. W kabinie ciężarówki odnaleziono zwęglone zwłoki
 - [https://wydarzenia.interia.pl/lodzkie/news-tragiczny-wypadek-na-s8-w-kabinie-ciezarowki-odnaleziono-zwe,nId,6617676](https://wydarzenia.interia.pl/lodzkie/news-tragiczny-wypadek-na-s8-w-kabinie-ciezarowki-odnaleziono-zwe,nId,6617676)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 08:42:00+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-tragiczny-wypadek-na-s8-w-kabinie-ciezarowki-odnaleziono-zwe,nId,6617676"><img align="left" alt="Tragiczny wypadek na S8. W kabinie ciężarówki odnaleziono zwęglone zwłoki" src="https://i.iplsc.com/tragiczny-wypadek-na-s8-w-kabinie-ciezarowki-odnaleziono-zwe/000GT0F80SW9L50K-C321.jpg" /></a>W nocy zderzyły się dwa samochody ciężarowe. Podczas wypadku pojazdy zajęły się ogniem. Jeden z kierowców nie przeżył, jego zwęglone ciało zostało ujawnione w kabinie  - powiadomiły w piątek lokalne media.</p><br clear="all" />

## Zastrzelił siedem osób, bo przegrał zakład. Oddał się w ręce policji
 - [https://wydarzenia.interia.pl/zagranica/news-zastrzelil-siedem-osob-bo-przegral-zaklad-oddal-sie-w-rece-p,nId,6617631](https://wydarzenia.interia.pl/zagranica/news-zastrzelil-siedem-osob-bo-przegral-zaklad-oddal-sie-w-rece-p,nId,6617631)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 08:37:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zastrzelil-siedem-osob-bo-przegral-zaklad-oddal-sie-w-rece-p,nId,6617631"><img align="left" alt="Zastrzelił siedem osób, bo przegrał zakład. Oddał się w ręce policji" src="https://i.iplsc.com/zastrzelil-siedem-osob-bo-przegral-zaklad-oddal-sie-w-rece-p/000GT046YE6NRXCV-C321.jpg" /></a>30-letni Edgar Ricardo de Oliveira przegrał w bilard 4 000 reali (3 500 złotych). Zażądał rewanżu, a gdy i ten mecz przegrał wpadł we wściekłość i zabił siedem osób - przekazały media. 30-letni zabójca uciekł wraz z 27-letnim wspólnikiem. Podczas policyjnej obławy zginął młodszy z mężczyzn. Sprawca strzelaniny ostatecznie oddał się w ręce policji.</p><br clear="all" />

## Szkoła zabrania noszenia dresów i legginsów. Rodzice oburzeni
 - [https://wydarzenia.interia.pl/wielkopolskie/news-szkola-zabrania-noszenia-dresow-i-legginsow-rodzice-oburzeni,nId,6617664](https://wydarzenia.interia.pl/wielkopolskie/news-szkola-zabrania-noszenia-dresow-i-legginsow-rodzice-oburzeni,nId,6617664)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 08:33:00+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-szkola-zabrania-noszenia-dresow-i-legginsow-rodzice-oburzeni,nId,6617664"><img align="left" alt="Szkoła zabrania noszenia dresów i legginsów. Rodzice oburzeni" src="https://i.iplsc.com/szkola-zabrania-noszenia-dresow-i-legginsow-rodzice-oburzeni/000GT0HO6MNCQRMU-C321.jpg" /></a>Statut Zespołu Szkół nr 9 w Kaliszu dokładnie określa to, jak ubrani powinni być uczniowie podczas zajęć w placówce. W szkole obowiązują mundurki, aby każdy wyglądał &quot;jednolicie, czysto i schludnie&quot;. Chłopcy z klas V-VIII mają zakaz noszenia spodni dresowych, a dziewczynki - legginsów. To nie podoba się rodzicom, którzy starają się o zmianę regulaminu szkoły. - Mój syn ma nadwagę. Dla niego najwygodniejsze są spodnie dresowe. Inne go obcierają i powodują rany - mówi jedna z matek.</p><br clear="all" />

## Jens Stoltenberg: Chciałbym pochwalić Polskę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-jens-stoltenberg-chcialbym-pochwalic-polske,nId,6617669](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-jens-stoltenberg-chcialbym-pochwalic-polske,nId,6617669)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 08:22:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-jens-stoltenberg-chcialbym-pochwalic-polske,nId,6617669"><img align="left" alt="Jens Stoltenberg: Chciałbym pochwalić Polskę" src="https://i.iplsc.com/jens-stoltenberg-chcialbym-pochwalic-polske/000G86KNK4UX4RIA-C321.jpg" /></a>Sekretarz generalny NATO Jens Stoltenberg zabrał głos w sprawie wsparcia Ukrainy przez Polskę. - Chciałbym pochwalić Polskę za to, że jest kluczowym i wiodącym sojusznikiem w udzielaniu wsparcia Ukrainie - zarówno jeśli chodzi o ilość, jak i zaawansowane systemy, które Polska dostarczyła, i które napędzają niektóre procesy Sojuszu i wśród partnerów - mówił. Tłumaczył także, jak wojna zmieniła Sojusz Północnoatlantycki przez rok od początku inwazji.</p><br clear="all" />

## 165 dolarów dla turystów. Tak chcą zachęcić gości do przyjazdu
 - [https://wydarzenia.interia.pl/zagranica/news-165-dolarow-dla-turystow-tak-chca-zachecic-gosci-do-przyjazd,nId,6617647](https://wydarzenia.interia.pl/zagranica/news-165-dolarow-dla-turystow-tak-chca-zachecic-gosci-do-przyjazd,nId,6617647)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 08:14:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-165-dolarow-dla-turystow-tak-chca-zachecic-gosci-do-przyjazd,nId,6617647"><img align="left" alt="165 dolarów dla turystów. Tak chcą zachęcić gości do przyjazdu" src="https://i.iplsc.com/165-dolarow-dla-turystow-tak-chca-zachecic-gosci-do-przyjazd/000GT08C4XAOLVPV-C321.jpg" /></a>Po wielomiesięcznych obostrzeniach spowodowanych pandemią koronawirusa ludzie na całym świecie zaczynają w końcu wracać do podróżowania. Nie wszędzie jednak sytuacja wygląda tak dobrze, jak przed rokiem 2020. Władze kolejnych regionów podejmują kolejne próby, aby z powrotem przyciągnąć do siebie turystów. Jednym z pomysłów jest oferta jednorazowej wypłaty środków dla turystów, które goście będą mogli wykorzystać m.in. na opłacenie zakwaterowania. Wynosić ma ono 165 dolarów.</p><br clear="all" />

## Premier Mateusz Morawiecki udaje się do Kijowa
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-mateusz-morawiecki-udaje-sie-do-kijowa,nId,6617651](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-mateusz-morawiecki-udaje-sie-do-kijowa,nId,6617651)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 07:44:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-mateusz-morawiecki-udaje-sie-do-kijowa,nId,6617651"><img align="left" alt="Premier Mateusz Morawiecki udaje się do Kijowa" src="https://i.iplsc.com/premier-mateusz-morawiecki-udaje-sie-do-kijowa/000794Q5F8UNQSO5-C321.jpg" /></a>Z moich informacji wynika, że premier Mateusz Morawiecki udaje się w piątek do Kijowa i tam prawdopodobnie weźmie udział w posiedzeniu Rady Najwyższej Ukrainy - przekazał sekretarz generalny PiS Krzysztof Sobolewski.</p><br clear="all" />

## Premier Mateusz Morawiecki z wizytą w Kijowie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-mateusz-morawiecki-z-wizyta-w-kijowie,nId,6617651](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-mateusz-morawiecki-z-wizyta-w-kijowie,nId,6617651)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 07:44:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-mateusz-morawiecki-z-wizyta-w-kijowie,nId,6617651"><img align="left" alt="Premier Mateusz Morawiecki z wizytą w Kijowie" src="https://i.iplsc.com/premier-mateusz-morawiecki-z-wizyta-w-kijowie/000GT09JQ6ML4SP4-C321.jpg" /></a>Premier Mateusz Morawiecki w piątek przebywa z wizytą w Kijowie. Złożył wieniec przy ścianie pamięci poległych. Według informacji sekretarza generalnego PiS Krzysztofa Sobolewskiego szef rządu weźmie udział w posiedzeniu Rady Najwyższej Ukrainy.</p><br clear="all" />

## Premier Mateusz Morawiecki z wizytą w Kijowie. Spotkał się z Zełenskim
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-mateusz-morawiecki-z-wizyta-w-kijowie-spotkal-sie-z-,nId,6617651](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-mateusz-morawiecki-z-wizyta-w-kijowie-spotkal-sie-z-,nId,6617651)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 07:44:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-mateusz-morawiecki-z-wizyta-w-kijowie-spotkal-sie-z-,nId,6617651"><img align="left" alt="Premier Mateusz Morawiecki z wizytą w Kijowie. Spotkał się z Zełenskim" src="https://i.iplsc.com/premier-mateusz-morawiecki-z-wizyta-w-kijowie-spotkal-sie-z/000GT1AXO7VUOT3W-C321.jpg" /></a>Premier Mateusz Morawiecki w piątek przebywa z wizytą w Kijowie, złożył wieniec przy ścianie pamięci poległych. Szef polskiego rządu został oficjalnie powitany przez premiera Denysa Szmyhala, spotkał się z prezydentem Wołodymyrem Zełenskim.</p><br clear="all" />

## "Le Monde": Walka o wpływy w Afryce. USA chcą wyprzeć najemników z grupy Wagnera
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-le-monde-walka-o-wplywy-w-afryce-usa-chca-wyprzec-najemnikow,nId,6613553](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-le-monde-walka-o-wplywy-w-afryce-usa-chca-wyprzec-najemnikow,nId,6613553)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 06:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-le-monde-walka-o-wplywy-w-afryce-usa-chca-wyprzec-najemnikow,nId,6613553"><img align="left" alt="&quot;Le Monde&quot;: Walka o wpływy w Afryce. USA chcą wyprzeć najemników z grupy Wagnera" src="https://i.iplsc.com/le-monde-walka-o-wplywy-w-afryce-usa-chca-wyprzec-najemnikow/000GSUFAGCDU8J1J-C321.jpg" /></a>USA zmieniają strategię wobec Afryki. Chcą zablokować rosnące wpływy Chin i Rosji na kontynencie. Waszyngton w grudniu zorganizował szczyt liderów USA–Afryka. Białemu Domowi zależy w pierwszej kolejności na ograniczeniu wpływów tzw. grupy Wagnera. Rosyjscy najemnicy poza walką w Ukrainie są obecni także w Afryce, gdzie ich zadaniem jest zwiększanie wpływów Kremla. </p><br clear="all" />

## "El Pais": Postpraca. Nadchodzi era czasu wolnego
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-el-pais-postpraca-nadchodzi-era-czasu-wolnego,nId,6613336](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-el-pais-postpraca-nadchodzi-era-czasu-wolnego,nId,6613336)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 06:56:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-el-pais-postpraca-nadchodzi-era-czasu-wolnego,nId,6613336"><img align="left" alt="&quot;El Pais&quot;: Postpraca. Nadchodzi era czasu wolnego" src="https://i.iplsc.com/el-pais-postpraca-nadchodzi-era-czasu-wolnego/000GSUSPVIYAIR92-C321.jpg" /></a>Rozwój technologii może być groźny dla wielu z nas. Według ekspertów roboty oraz sztuczna inteligencja przyczynią się do wpędzenia w bezrobocie wielu grup zawodowych. Jednocześnie technologia stwarza szanse dla powstania nowych zawodów oraz zaoferowania ludziom większej ilości czasu wolnego. Przez ostatnie dekady praca zrosła się z tożsamością człowieka i nadała mu sens. W obliczu szybko postępujących zmian, gdy maszyny przejmują kolejne zawody - wkrótce będą one wykonywać już prawie połowę wszystkich zadań - przed ludźmi stoi ogromne...</p><br clear="all" />

## Zełenski: Rok temu dokonaliśmy wyboru: nie biała flaga, a błękitno-żółta
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-rok-temu-dokonalismy-wyboru-nie-biala-flaga-a-bleki,nId,6617606](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-rok-temu-dokonalismy-wyboru-nie-biala-flaga-a-bleki,nId,6617606)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 06:34:32+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-rok-temu-dokonalismy-wyboru-nie-biala-flaga-a-bleki,nId,6617606"><img align="left" alt="Zełenski: Rok temu dokonaliśmy wyboru: nie biała flaga, a błękitno-żółta" src="https://i.iplsc.com/zelenski-rok-temu-dokonalismy-wyboru-nie-biala-flaga-a-bleki/000F38U9HW655C87-C321.jpg" /></a>To był rok bólu, żalu, wiary i jedności - oświadczył prezydent Ukrainy w piątek, w rocznicę rozpoczęcia pełnoskalowej agresji Rosji na Ukrainę. Wołodymyr Zełenski podzielił się krótkim filmem, który obrazuje rok działań wojennych. Rosja napadła na Ukrainę 24 lutego 2022 roku tuż przed godziną 5.00 (godz. 4.00 w Polsce).</p><br clear="all" />

## Darmowe leki i specjalne zasiłki. Z czego jeszcze mogą skorzystać emeryci?
 - [https://wydarzenia.interia.pl/kraj/news-darmowe-leki-i-specjalne-zasilki-z-czego-jeszcze-moga-skorzy,nId,6613383](https://wydarzenia.interia.pl/kraj/news-darmowe-leki-i-specjalne-zasilki-z-czego-jeszcze-moga-skorzy,nId,6613383)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 06:27:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-darmowe-leki-i-specjalne-zasilki-z-czego-jeszcze-moga-skorzy,nId,6613383"><img align="left" alt="Darmowe leki i specjalne zasiłki. Z czego jeszcze mogą skorzystać emeryci?" src="https://i.iplsc.com/darmowe-leki-i-specjalne-zasilki-z-czego-jeszcze-moga-skorzy/000GNLA37YAHMNF5-C321.jpg" /></a>Ulgi dla emerytów obejmują m.in. komunikację miejską, kolej, czy abonament RTV. Seniorzy mogą też skorzystać z Ogólnopolskiej Karty Seniora. Jakie jeszcze inne zniżki przysługują emerytom?</p><br clear="all" />

## USA: Dodatkowe dwa miliardy dolarów pomocy wojskowej dla Ukrainy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-usa-dodatkowe-dwa-miliardy-dolarow-pomocy-wojskowej-dla-ukra,nId,6617601](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-usa-dodatkowe-dwa-miliardy-dolarow-pomocy-wojskowej-dla-ukra,nId,6617601)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 06:15:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-usa-dodatkowe-dwa-miliardy-dolarow-pomocy-wojskowej-dla-ukra,nId,6617601"><img align="left" alt="USA: Dodatkowe dwa miliardy dolarów pomocy wojskowej dla Ukrainy" src="https://i.iplsc.com/usa-dodatkowe-dwa-miliardy-dolarow-pomocy-wojskowej-dla-ukra/000F1YGCDIHTQ6Q5-C321.jpg" /></a>Dodatkowe dwa miliardy dolarów przekażą Ukrainie Stany Zjednoczone na pomoc w zakresie bezpieczeństwa - poinformował w czwartek doradca Białego Domu ds. bezpieczeństwa narodowego Jake Sullivan. Jak z kolei przekazał sekretarz obrony USA Lloyd Austin, USA uważają, że dostarczenie broni Ukrainie oraz szkolenie Sił Zbrojnych Ukrainy &quot;zmieni dynamikę na polu bitwy&quot;. </p><br clear="all" />

## Wojna, która obrasta w legendy. Duch z Kijowa i inne opowieści z Ukrainy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-ktora-obrasta-w-legendy-duch-z-kijowa-i-inne-opowiesci,nId,6615487](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-ktora-obrasta-w-legendy-duch-z-kijowa-i-inne-opowiesci,nId,6615487)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 06:00:22+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-ktora-obrasta-w-legendy-duch-z-kijowa-i-inne-opowiesci,nId,6615487"><img align="left" alt="Wojna, która obrasta w legendy. Duch z Kijowa i inne opowieści z Ukrainy" src="https://i.iplsc.com/wojna-ktora-obrasta-w-legendy-duch-z-kijowa-i-inne-opowiesci/000GSX1GTOUC3ETX-C321.jpg" /></a>Duch z Kijowa, słoik z przetworami, który strącił nadlatującego drona czy rolnicy przechwytujący rosyjskie czołgi. Inwazji Rosji na Ukrainę od samego początku towarzyszą historie, które z czasem obrastają w legendy o ukraińskiej waleczności i niemożliwym do złamania oporze. </p><br clear="all" />

## Chiny wystąpiły z "planem pokojowym". Ma zakończyć wojnę w Ukrainie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-chiny-wystapily-z-planem-pokojowym-ma-zakonczyc-wojne-w-ukra,nId,6617596](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-chiny-wystapily-z-planem-pokojowym-ma-zakonczyc-wojne-w-ukra,nId,6617596)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 05:54:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-chiny-wystapily-z-planem-pokojowym-ma-zakonczyc-wojne-w-ukra,nId,6617596"><img align="left" alt="Chiny wystąpiły z &quot;planem pokojowym&quot;. Ma zakończyć wojnę w Ukrainie" src="https://i.iplsc.com/chiny-wystapily-z-planem-pokojowym-ma-zakonczyc-wojne-w-ukra/000GB93IJUMJTML3-C321.jpg" /></a>Pekin wezwał Moskwę i Kijów do wznowienia dialogu i zaproponował 12-punktowy dokument. &quot;Wszystkie strony powinny wspierać Rosję i Ukrainę, aby działały w tym samym kierunku i jak najszybciej wznowiły bezpośredni dialog w celu znalezienia pokojowego rozwiązania&quot; - oświadczyło chińskie Ministerstwo Spraw Zagranicznych. &quot;Pekin nadal konsekwentnie przerzuca winę za wojnę z Rosji na Europę i USA&quot; - skomentowały media.</p><br clear="all" />

## Kułeba o dostarczaniu Rosji broni przez Chiny: Nie mamy dowodów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kuleba-o-dostarczaniu-rosji-broni-przez-chiny-nie-mamy-dowod,nId,6617597](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kuleba-o-dostarczaniu-rosji-broni-przez-chiny-nie-mamy-dowod,nId,6617597)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 05:35:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kuleba-o-dostarczaniu-rosji-broni-przez-chiny-nie-mamy-dowod,nId,6617597"><img align="left" alt="Kułeba o dostarczaniu Rosji broni przez Chiny: Nie mamy dowodów" src="https://i.iplsc.com/kuleba-o-dostarczaniu-rosji-broni-przez-chiny-nie-mamy-dowod/000F2ATYS8TELR1V-C321.jpg" /></a>Nie mamy dowodów, że Chiny dostarczały Rosji śmiercionośną broń - przekazał w czwartek Dmytro Kułeba. Szef ukraińskiej dyplomacji odpowiadał na pytania ukraińskich dziennikarzy po głosowaniu w Zgromadzeniu Ogólnym ONZ. Ocenił także, że &quot;gdyby jakikolwiek kraj dostarczał Rosji broń&quot;, byłoby to &quot;wielkim błędem&quot;.</p><br clear="all" />

## Rocznica inwazji Rosji na Ukrainę. Wojna pochłonęła tysiące ofiar
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rocznica-inwazji-rosji-na-ukraine-wojna-pochlonela-tysiace-o,nId,6617599](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rocznica-inwazji-rosji-na-ukraine-wojna-pochlonela-tysiace-o,nId,6617599)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 05:23:12+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rocznica-inwazji-rosji-na-ukraine-wojna-pochlonela-tysiace-o,nId,6617599"><img align="left" alt="Rocznica inwazji Rosji na Ukrainę. Wojna pochłonęła tysiące ofiar" src="https://i.iplsc.com/rocznica-inwazji-rosji-na-ukraine-wojna-pochlonela-tysiace-o/000GSZX9WVMIP391-C321.jpg" /></a>Mija rok od początku rosyjskiej inwazji na Ukrainę. 24 lutego 2022 r. niesprowokowane rosyjskie wojska rozpoczęły ofensywę w ogromnej skali. Ukraina obroniła swoją suwerenność kosztem tysięcy ofiar. Podsumowujemy, co działo się w ostatnich miesiącach.</p><br clear="all" />

## Matki na wojnie. "Córka bawiła się w pokoju, gdy zatrzęsło domem"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-matki-na-wojnie-corka-bawila-sie-w-pokoju-gdy-zatrzeslo-dome,nId,6613779](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-matki-na-wojnie-corka-bawila-sie-w-pokoju-gdy-zatrzeslo-dome,nId,6613779)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 05:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-matki-na-wojnie-corka-bawila-sie-w-pokoju-gdy-zatrzeslo-dome,nId,6613779"><img align="left" alt="Matki na wojnie. &quot;Córka bawiła się w pokoju, gdy zatrzęsło domem&quot;" src="https://i.iplsc.com/matki-na-wojnie-corka-bawila-sie-w-pokoju-gdy-zatrzeslo-dome/000GST2SEAAITJ9N-C321.jpg" /></a>- Lato. Wraz z Sołomiją wróciłyśmy z wieczornego spaceru. Posadziłam ją na podłodze i poszłam do kuchni. Wracając, usłyszałam potężny huk. Dom zatrząsł się w posadach. Myślałam, że rakieta uderzyła w nasz ogród. Chwyciłam dziecko, uciekłyśmy na korytarz. Kolejna eksplozja. Zaczęłam płakać, nie wiedziałam, co robić. Dwa pociski uderzyły w lotnisko, półtora kilometra od nas - opowiada Aleksandra. 24 lutego 2022 roku jej córka miała cztery miesiące. 29-latka jest jedną z młodych mam mierzących się z wychowaniem potomstwa w cieniu wojny, pod...</p><br clear="all" />

## Wojna w Ukrainie. 366. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240551](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240551)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 04:29:12+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240551"><img align="left" alt="Wojna w Ukrainie. 366. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo/000GSZVSKGMS6FLQ-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 366. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240643](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240643)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 04:29:12+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240643"><img align="left" alt="Wojna w Ukrainie. 366. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo/000GSZVSKGMS6FLQ-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 366. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240734](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240734)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-24 04:29:12+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240734"><img align="left" alt="Wojna w Ukrainie. 366. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo/000GSZVSKGMS6FLQ-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

