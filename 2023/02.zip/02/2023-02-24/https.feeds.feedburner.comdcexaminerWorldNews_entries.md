# Source:Washington Examiner - world, URL:https://feeds.feedburner.com/dcexaminer/WorldNews, language:en-US

## From Putin to Queen Elizabeth II, U.S. reveals Biden's biggest gifts received in 2021
 - [https://www.washingtonexaminer.com/policy/foreign/bidens-biggest-state-gifts](https://www.washingtonexaminer.com/policy/foreign/bidens-biggest-state-gifts)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/WorldNews
 - date published: 2023-02-24 05:18:26+00:00

Gift-giving has been a central part of diplomacy since the advent of states. The Biden administration has seen the continuation of this tradition, with world leaders presenting the president of the United States with lavish gifts as showings of goodwill, often unique to their countries.

