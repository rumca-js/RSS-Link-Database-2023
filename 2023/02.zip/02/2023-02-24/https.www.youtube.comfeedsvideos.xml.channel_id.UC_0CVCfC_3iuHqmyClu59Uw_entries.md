# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## You Can Build A Cheap Linux Gaming PC Powered By ChimeraOS! An Edge Over Steam Deck OS?
 - [https://www.youtube.com/watch?v=E2NIGPpz_vY](https://www.youtube.com/watch?v=E2NIGPpz_vY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-02-24 15:06:00+00:00

Turn A Cheap PC into a gaming console like the Steam deck with ChimeraOS!
ChimeraOS is based on ArchLinux and now with the latest update Steam GamepadUi " Steam Deck Ui" is standard so we have access to Gamescope and all the great setting that come along with it! the dev has also added a desktop interface so this is a full blown linux gaming Distro and it rocks! Controller first
fully controller compatible interface, use any controller, support for Xbox, PlayStation, Steam controllers and more, play all your favorite games support for Steam, Epic Games Store, GOG, and dozens of console platforms

Download ChimeraOS Here: https://chimeraos.org/

Buy The Radeon 6600 On eBay: https://ebay.us/tNGBZB
HP Pavilion Ryzen 3500: https://ebay.us/rMIsdN
AMD Ryzen 5 5600 CPU: https://ebay.us/gzshzZ
AM4 B450 Mini ItX Motherboard: https://ebay.us/aMlHFC
16GB DDR4 3200MHz Ram: https://ebay.us/DMEkcT
NVMe SSD: https://amzn.to/3YqzAcv
500 Watt PSU: https://amzn.to/3XZsHPo
Learn More About The AMD Radeon™ RX 6600 Challenger D 8GB: https://www.asrock.com/Graphics-Card/AMD/Radeon%20RX%206600%20Challenger%20D%208GB/

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME 
12520 Capital Blvd Ste 401 Number 108
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#linux #steamdeck #etaprime
00:00 Introduction
00:19 ChimeraOs Overview
00:58 PC Specs
02:10 Checking Out ChimeraOS
07:00 Gaming Test
09:14 Final Thoughts

