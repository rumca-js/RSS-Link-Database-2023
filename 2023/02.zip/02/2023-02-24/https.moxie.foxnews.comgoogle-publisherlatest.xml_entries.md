# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Teen who shot 3 people in Texas mall charged with murder
 - [https://www.foxnews.com/us/teen-shot-3-people-texas-mall-charged-murder](https://www.foxnews.com/us/teen-shot-3-people-texas-mall-charged-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:59:56+00:00

The 16-year-old El Paso, Texas, boy who shot and killed 17-year-old Angeles Zaragoza and wounded two others has been charged with murder and three aggravated assault counts

## Mississippi pastor accused of sexual battery held without bond
 - [https://www.foxnews.com/us/mississippi-pastor-accused-sexual-battery-held-bond](https://www.foxnews.com/us/mississippi-pastor-accused-sexual-battery-held-bond)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:58:52+00:00

A Mississippi youth pastor accused of sexual battery is being held without bond. The pastor was accused of having sex with a 16-year-old church member on two occasions.

## Florida teacher's aide violently attacked after taking student's Nintendo Switch
 - [https://www.foxnews.com/us/florida-teachers-aide-violently-attacked-taking-students-nintendo-switch](https://www.foxnews.com/us/florida-teachers-aide-violently-attacked-taking-students-nintendo-switch)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:52:58+00:00

Florida deputies released surveillance video of a student attacking a high school teacher's aide who took away his Nintendo Switch during class time.

## Commissioner joins Reno mayor in lawsuit accusing PI of vehicle tracking
 - [https://www.foxnews.com/us/commissioner-joins-reno-mayor-lawsuit-accusing-pi-vehicle-tracking](https://www.foxnews.com/us/commissioner-joins-reno-mayor-lawsuit-accusing-pi-vehicle-tracking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:52:26+00:00

A Nevada commissioner joined the Reno mayor in a lawsuit alleging a private investigator put tracking devices on their vehicles. The mayor said the tracking caused severe distress.

## Padres' Manny Machado becomes first victim of MLB's new pitch clock
 - [https://www.foxnews.com/sports/padres-manny-machado-becomes-first-victim-mlbs-new-pitch-clock](https://www.foxnews.com/sports/padres-manny-machado-becomes-first-victim-mlbs-new-pitch-clock)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:51:17+00:00

Major League Baseball spring training is underway, and so are the new rules in the sport, including a pitch clock. Well, it's going to take the San Diego Padres' Manny Machado some getting used to.

## Rhode Island man caught with 665,000 meth-laced fake Adderall pills gets 10 years
 - [https://www.foxnews.com/us/rhode-island-man-caught-665000-meth-laced-fake-adderall-pills-10-years](https://www.foxnews.com/us/rhode-island-man-caught-665000-meth-laced-fake-adderall-pills-10-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:49:36+00:00

Dylan Rodas of Cumberland, Rhode Island, was sentenced to ten years in prison after pleading guilty to possession of nearly 700,000 fake Adderall pills laced with methamphetamine.

## Paris Hilton says she had her baby via surrogate because of teenage abuse, other 'trauma': 'I want a family'
 - [https://www.foxnews.com/entertainment/paris-hilton-says-had-baby-surrogate-teenage-abuse-trauma](https://www.foxnews.com/entertainment/paris-hilton-says-had-baby-surrogate-teenage-abuse-trauma)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:47:10+00:00

Paris Hilton said after suffering sexual abuse, including late-night gynecological exams at a boarding school as a teen, she decided to have her first baby via surrogate.

## Yemeni rebels frustrated by leader's calls to delay seccession
 - [https://www.foxnews.com/world/yemeni-rebels-frustrated-leaders-calls-delay-seccession](https://www.foxnews.com/world/yemeni-rebels-frustrated-leaders-calls-delay-seccession)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:36:34+00:00

Southern separatists in Yemen condemned statements by a close ally insinuating that secession from the Houthi rebel-dominated north of the country should be delayed.

## Sixers' Georges Niang dishes on ex-teammate Ben Simmons' drama: He ‘kind of handicapped us’
 - [https://www.foxnews.com/sports/sixers-georges-niang-dishes-on-ex-teammate-ben-simmons-drama-he-kind-of-handicapped-us](https://www.foxnews.com/sports/sixers-georges-niang-dishes-on-ex-teammate-ben-simmons-drama-he-kind-of-handicapped-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:32:53+00:00

Georges Niang of the Philadelphia 76ers says former teammate Ben Simmons, now with the Brooklyn Nets, handicapped the Sixers at the beginning of the 2021-22 season.

## University of Kent in UK encourages gender-neutral pronouns among students, staff: Consider ‘ze’ and ‘fae’
 - [https://www.foxnews.com/media/university-kent-uk-encourages-gender-neutral-pronouns-among-students-staff-consider-ze-fae](https://www.foxnews.com/media/university-kent-uk-encourages-gender-neutral-pronouns-among-students-staff-consider-ze-fae)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:30:13+00:00

The University of Kent in the UK released a set of guidelines on gender pronouns, warning that proper pronoun usage is a matter of “human dignity."

## New York City employee who killed alleged robber has murder charge dropped
 - [https://www.foxnews.com/us/new-york-city-employee-killed-alleged-robber-murder-charge-dropped](https://www.foxnews.com/us/new-york-city-employee-killed-alleged-robber-murder-charge-dropped)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:21:29+00:00

New York City fish market employee Junior Aquino Hernandez is no longer being charged with murder after stabbing and killing an alleged robber during an altercation Tuesday night.

## Biden to draw health care contrast with GOP in Virginia
 - [https://www.foxnews.com/politics/biden-draw-health-care-contrast-gop-virginia](https://www.foxnews.com/politics/biden-draw-health-care-contrast-gop-virginia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:19:59+00:00

Biden is trying to draw a contrast of health care priorities with the Republicans in Virginia. The administration claims GOP plans will raise health care prices.

## Indiana authorities identify cause of October fire that razed neighborhood
 - [https://www.foxnews.com/us/indiana-authorities-identify-cause-october-fire-razed-neighborhood](https://www.foxnews.com/us/indiana-authorities-identify-cause-october-fire-razed-neighborhood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:17:01+00:00

The cause of an October fire that destroyed an Evansville, Indiana, warehouse and several surrounding homes was likely electrical, authorities say.

## Troubled boxer Gervonta Davis hit with lawsuit; his punch allegedly injured parking attendant
 - [https://www.foxnews.com/sports/troubled-boxer-gervonta-davis-hit-lawsuit-allegedly-caused-multiple-injuries-to-parking-attendant](https://www.foxnews.com/sports/troubled-boxer-gervonta-davis-hit-lawsuit-allegedly-caused-multiple-injuries-to-parking-attendant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:12:39+00:00

On the same day it was announced he would fight fellow undefeated boxer Ryan Garcia, Gervonta Davis is being sued for allegedly sucker-punching a parking attendant.

## Chicago man charged in slain police officer Ella French's death claims no bail condition is 'excessive'
 - [https://www.foxnews.com/us/chicago-man-charged-slain-police-officer-ella-frenchs-death-claims-no-bail-condition-excessive](https://www.foxnews.com/us/chicago-man-charged-slain-police-officer-ella-frenchs-death-claims-no-bail-condition-excessive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:11:10+00:00

A man linked to the killing of a Chicago police officer is asking to be released on bond after a court petition claimed no bail prior to his trial in "excessive."

## Montana man charged for violent threats to Democratic US senator
 - [https://www.foxnews.com/us/montana-man-charged-violent-threats-democratic-us-senator](https://www.foxnews.com/us/montana-man-charged-violent-threats-democratic-us-senator)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:10:11+00:00

A Montana man has been charged with with threatening the life of a Democratic U.S. senator. The man left muliple voicemail threats to injure and murder the U.S. Senator.

## Ex-felon accidently shoots himself at Las Vegas Strip casino
 - [https://www.foxnews.com/us/ex-felon-accidently-shoots-himself-las-vegas-strip-casino](https://www.foxnews.com/us/ex-felon-accidently-shoots-himself-las-vegas-strip-casino)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:04:47+00:00

An ex-felon accidentally shot himself at a Las Vegas Strip casino on Tuesday. The man had an unregistered handgun in his pants which left him hospitalized and in critical condition.

## China unveils peace plan to wary Zelenskyy
 - [https://www.foxnews.com/world/china-unveil-peace-plan-wary-zelenskyy](https://www.foxnews.com/world/china-unveil-peace-plan-wary-zelenskyy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 23:03:30+00:00

Ukrainian President Volodymyr Zelenskyy is cautiously welcoming of prospective Chinese involvement in brokering a peace deal in the ongoing Russo-Ukrainian conflict.

## Erin Brockovich visits East Palestine after toxic train derailment: 'All clear my a--!'
 - [https://www.foxnews.com/politics/erin-brockovich-visits-east-palestine-toxic-train-derailment-clear-a](https://www.foxnews.com/politics/erin-brockovich-visits-east-palestine-toxic-train-derailment-clear-a)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:57:08+00:00

Environmental activist Erin Brockovich is hosting a town hall on Friday evening following the disastrous train derailment in East Palestine, Ohio.

## Florida man sentenced to 7 years for stealing $2.6M of COVID-19 relief funds
 - [https://www.foxnews.com/us/florida-man-sentenced-7-years-stealing-2-6m-covid-19-relief-funds](https://www.foxnews.com/us/florida-man-sentenced-7-years-stealing-2-6m-covid-19-relief-funds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:53:40+00:00

A Florida man was sentenced to seven years for stealing $2.6 million in COVID-19 relief funds. The man pleaded guilty to wire and bank fraud, along with illegal monetary transaction.

## Lisa Marie Presley's daughter Riley Keough stuns at first red carpet since mom's death
 - [https://www.foxnews.com/entertainment/lisa-marie-presleys-daughter-riley-keough-stuns-first-red-carpet-moms-death](https://www.foxnews.com/entertainment/lisa-marie-presleys-daughter-riley-keough-stuns-first-red-carpet-moms-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:53:02+00:00

Lisa Marie's daughter Riley Keough stunned as she attended the premiere of "Daisy Jones & the Six" in Hollywood on Thursday. It was her first red carpet appearance since her mother's death in January.

## California school district presentation divides students into categories of 'privilege' or 'oppression'
 - [https://www.foxnews.com/media/california-school-district-presentation-divides-students-categories-privilege-oppression](https://www.foxnews.com/media/california-school-district-presentation-divides-students-categories-privilege-oppression)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:47:09+00:00

Students at a California school district were given a presentation on oppression that listed groups who would be considered part of an oppressed 'target group.'

## Italy's high court upholds tough prison regime for militant
 - [https://www.foxnews.com/world/italys-high-court-upholds-tough-prison-regime-militant](https://www.foxnews.com/world/italys-high-court-upholds-tough-prison-regime-militant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:40:00+00:00

Italy's high court has upheld a tough prison regime for an Italian left-wing militant. The man has been on hunger strike since October to protest the prison regime for terrorists.

## Drone strike in Syria kills 2 al-Qaida-linked operatives
 - [https://www.foxnews.com/world/drone-strike-syria-kills-2-al-qaida-linked-operatives](https://www.foxnews.com/world/drone-strike-syria-kills-2-al-qaida-linked-operatives)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:38:01+00:00

A drone strike in Syria has killed two al-Qaida-linked operatives riding a motorcycle. The attack was believed to have been carried out by the U.S.-led coalition.

## Kentucky Senate approves liability insurance coverage for teachers
 - [https://www.foxnews.com/politics/kentucky-senate-approves-liability-insurance-coverage-teachers](https://www.foxnews.com/politics/kentucky-senate-approves-liability-insurance-coverage-teachers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:36:43+00:00

The Kentucky Senate voted to provide liability insurance coverage for teachers. School districts will provides coverage amounting to at least $1 million.

## Georgia ex-teacher sexually assaulted and 'groomed' minors: authorities
 - [https://www.foxnews.com/us/georgia-ex-teacher-sexually-assaulted-groomed-minors-authorities](https://www.foxnews.com/us/georgia-ex-teacher-sexually-assaulted-groomed-minors-authorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:36:13+00:00

A former Georgia choir teacher received a 20-year sentence after pleading guilty to sexually assaulting several students who were minors.

## Retired judge selected to review Arizona’s execution process
 - [https://www.foxnews.com/us/retired-judge-selected-review-arizonas-execution-process](https://www.foxnews.com/us/retired-judge-selected-review-arizonas-execution-process)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:35:30+00:00

It was announced that a retired judge will review Arizona’s execution process ordered by Gov. Katie Hobbs. This examination follows the state's history of mismanaging executions.

## Boston officials warn of fentanyl-laced cocaine, overdose spike
 - [https://www.foxnews.com/us/boston-officials-warn-fentanyl-laced-cocaine-overdose-spike](https://www.foxnews.com/us/boston-officials-warn-fentanyl-laced-cocaine-overdose-spike)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:34:23+00:00

Boston public health officials are warning care providers about a sudden spike in drug overdoses that may be attributable to fentanyl-laced cocaine.

## 'Friends' star Courteney Cox shows off fit figure as a 'Gen Z girl'
 - [https://www.foxnews.com/entertainment/friends-star-courteney-cox-shows-off-fit-figure-gen-z-girl](https://www.foxnews.com/entertainment/friends-star-courteney-cox-shows-off-fit-figure-gen-z-girl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:34:10+00:00

Baby Boomer and "Friends" star Courteney Cox wore a crop top and flashed a peace sign in her humorous attempt to look like a "Gen Z girl" on Instagram.

## Trump's stance on ending Ukraine aid could box in DeSantis: WSJ columnist
 - [https://www.foxnews.com/media/trumps-stance-ending-ukraine-aid-box-desantis-wsj-columnist](https://www.foxnews.com/media/trumps-stance-ending-ukraine-aid-box-desantis-wsj-columnist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:33:38+00:00

An editorial board member from the Wall Street Journal blasted both Trump's foreign policy record and his messaging, urging future GOP leaders to try another geopolitical route.

## 2 Wisconsin officers charged in prisoner's overdose death
 - [https://www.foxnews.com/us/2-wisconsin-officers-charged-prisoners-overdose-death](https://www.foxnews.com/us/2-wisconsin-officers-charged-prisoners-overdose-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:32:58+00:00

Milwaukee police officers Donald Krueger and Marco Lopez are facing separate charges over the overdose death of a 21-year-old man they took into custody.

## UN condemns Haitian gang violence spike
 - [https://www.foxnews.com/world/un-condemns-haitian-gang-violence-spike](https://www.foxnews.com/world/un-condemns-haitian-gang-violence-spike)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:31:27+00:00

Haitian gang Baz Gran Grif has taken control of numerous communities, killing at least 69 people and leaving several police stations abandoned as a result.

## Virginia Tech crowd goes nuts as missed free throws trigger promo: 'Bacon for everybody!'
 - [https://www.foxnews.com/sports/virginia-tech-crowd-goes-nuts-missed-free-throws-trigger-promo-bacon-everybody](https://www.foxnews.com/sports/virginia-tech-crowd-goes-nuts-missed-free-throws-trigger-promo-bacon-everybody)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:30:20+00:00

The Virginia Tech home crowd took home free bacon after two missed free throws by Miami late in the second half of their ACC conference game on Tuesday triggered a promotion. The Hurricanes defeated the Hokies 76-70.

## Could a urine test detect pancreatic and prostate cancer? Study shows 99% success rate
 - [https://www.foxnews.com/health/urine-test-detect-pancreatic-prostate-cancer-study-success-rate](https://www.foxnews.com/health/urine-test-detect-pancreatic-prostate-cancer-study-success-rate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:26:37+00:00

A simple urine test could detect pancreatic and prostate cancer with up to a 99% rate of accuracy, says a new study from the Korea Institute of Materials Science. Other experts weigh in.

## Fallout from toxic Ohio train crash could be a preview of 2024 presidential race
 - [https://www.foxnews.com/politics/fallout-toxic-ohio-train-crash-preview-2024-presidential-campaign](https://www.foxnews.com/politics/fallout-toxic-ohio-train-crash-preview-2024-presidential-campaign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:22:36+00:00

The tragedy surrounding the train derailment in East Palestine, Ohio has become the backdrop in the 2024 presidential race, giving Americans a preview of what to expect as it heats up.

## Reporter's Notebook: What Russia can and can't afford
 - [https://www.foxnews.com/world/reporters-notebook-what-russia-can-and-cant-afford](https://www.foxnews.com/world/reporters-notebook-what-russia-can-and-cant-afford)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:17:49+00:00

Vladimir Putin wants Russians to feel like there is no war and life is normal. But how long can it last? Economic editor Peter Mironenko on Putin’s purse strings.

## California man who accused twin brother of 2 rapes in 1990s is convicted of crimes
 - [https://www.foxnews.com/us/california-man-who-accused-twin-brother-2-rapes-1990s-convicted-crimes](https://www.foxnews.com/us/california-man-who-accused-twin-brother-2-rapes-1990s-convicted-crimes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:16:54+00:00

Kevin Konther was convicted of two rapes in the 1990s after he accused his twin brother of committing the crimes. DNA evidence linked both brothers to the rapes.

## 'The Shining' star Shelley Duvall shares stories about working with the 'classic' Jack Nicholson
 - [https://www.foxnews.com/entertainment/the-shining-star-shelley-duvall-stories-working-jack-nicholson](https://www.foxnews.com/entertainment/the-shining-star-shelley-duvall-stories-working-jack-nicholson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:14:21+00:00

Shelley Duvall shared with Fox News Digital what it was like to work alongside Jack Nicholson in "The Shining" in 1980 as she returns to the big screen for the first time in 20 years.

## University of North Carolina moves to ban ‘diversity, equity and inclusion’ statements in anti-woke backlash
 - [https://www.foxnews.com/media/university-north-carolina-moves-ban-diversity-equity-inclusion-statements-anti-woke-backlash](https://www.foxnews.com/media/university-north-carolina-moves-ban-diversity-equity-inclusion-statements-anti-woke-backlash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 22:00:39+00:00

The University of North Carolina this week voted to ban 'diversity, equity and inclusion statements' and politically preferential hiring.

## Judge appointed in Missouri case to remove Dem attorney Kim Gardner from office
 - [https://www.foxnews.com/politics/whats-next-legal-battle-fire-embattled-dem-attorney-kim-gardner](https://www.foxnews.com/politics/whats-next-legal-battle-fire-embattled-dem-attorney-kim-gardner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:55:58+00:00

The Missouri Supreme Court appointed judge John P. Torbitzky to preside over the Missouri Attorney General's case to have the St. Louis circuit attorney removed from office.

## Alabama's Nate Oats defends playing Brandon Miller amid link to deadly shooting: 'We've done the right thing'
 - [https://www.foxnews.com/sports/alabamas-nate-oats-defends-playing-brandon-miller-amid-link-deadly-shooting-weve-done-right-thing](https://www.foxnews.com/sports/alabamas-nate-oats-defends-playing-brandon-miller-amid-link-deadly-shooting-weve-done-right-thing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:53:39+00:00

Police have said they will not be charging Brandon Miller with any crime based on evidence they have. So he continues to play for the University of Alabama basketball team.

## Laxatives taken on consistent basis could increase dementia risk, new study finds
 - [https://www.foxnews.com/health/laxatives-taken-consistent-basis-could-increase-dementia-risk-new-study-finds](https://www.foxnews.com/health/laxatives-taken-consistent-basis-could-increase-dementia-risk-new-study-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:38:35+00:00

Older adults who take laxatives on a regular basis could face a 51% higher risk of developing dementia compared to those who do not use them, a new study indicates.

## ‘Harry Potter’ actress defends JK Rowling’s views, warns about cancel culture: ‘Next step is violence’
 - [https://www.foxnews.com/media/harry-potter-actress-defends-jk-rowlings-views-warns-about-cancel-culture-next-step-violence](https://www.foxnews.com/media/harry-potter-actress-defends-jk-rowlings-views-warns-about-cancel-culture-next-step-violence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:32:32+00:00

"Harry Potter" actress Evanna Lynch spoke out against cancel culture and defended author J.K. Rowling in a recent interview with U.K. outlet The Telegraph.

## Shakira scorches ex Gerard Piqué in song after being ‘hurt’ over his new girlfriend
 - [https://www.foxnews.com/entertainment/shakira-scorches-ex-gerard-pique-song-hurt-girlfriend](https://www.foxnews.com/entertainment/shakira-scorches-ex-gerard-pique-song-hurt-girlfriend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:30:26+00:00

Colombian singer Shakira teamed up with artist Karol G for the new single titled "TQG." The track slams Shakira's ex Gerard Piqué for having a new girlfriend.

## Idaho murders: Bryan Kohberger leaks 'huge issue' with 'potential to compromise' prosecution, lawyer warns
 - [https://www.foxnews.com/us/idaho-murders-bryan-kohberger-leaks-huge-issue-potential-compromise-prosecution-lawyer-warns](https://www.foxnews.com/us/idaho-murders-bryan-kohberger-leaks-huge-issue-potential-compromise-prosecution-lawyer-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:23:10+00:00

A lawyer warns that the case against Idaho murders suspect Bryan Kohberger could be compromised because of sources leaking information in the investigation.

## California Gov. Newsom's latest war on oil is off to a rough start
 - [https://www.foxnews.com/politics/california-gov-newsoms-war-oil-rough-start](https://www.foxnews.com/politics/california-gov-newsoms-war-oil-rough-start)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:11:26+00:00

California Gov. Gavin Newsom's plan to limit oil companies' profits was met with criticism by Democrats, Republicans and experts alike at a state hearing earlier this week.

## Alaska's ACLU sues corrections agency for violating the rights of incarcerated people
 - [https://www.foxnews.com/us/alaskas-aclu-sues-corrections-agency-violating-rights-incarcerated-people](https://www.foxnews.com/us/alaskas-aclu-sues-corrections-agency-violating-rights-incarcerated-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:11:24+00:00

Alaska's ACLU is suing the corrections agency on behalf of four plaintiffs who claim they were denied access to transitional programs after their release date was moved up.

## Minor league club Indianapolis Indians announce team name will not be changed
 - [https://www.foxnews.com/sports/minor-league-club-indianapolis-indians-announce-team-name-will-not-be-changed](https://www.foxnews.com/sports/minor-league-club-indianapolis-indians-announce-team-name-will-not-be-changed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:09:12+00:00

The Indianapolis Indians, the Triple-A affiliate of the Pittsburgh Pirates, announced they will not be changing their controversial name.

## Former WNBA MVP Nneka Ogwumike returning to Los Angeles Sparks on 1-year deal: report
 - [https://www.foxnews.com/sports/former-wnba-mvp-nneka-ogwumike-returning-to-los-angeles-sparks-on-1-year-deal-report](https://www.foxnews.com/sports/former-wnba-mvp-nneka-ogwumike-returning-to-los-angeles-sparks-on-1-year-deal-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:08:15+00:00

After last year's final Sparks game, Nneka Ogwumike said she would be back. On Friday, the former MVP delivered on her promise by signing a one-year contract with LA.

## New 'historical character' American Girl dolls from the 1990s have millennials feeling old and 'disrespected'
 - [https://www.foxnews.com/lifestyle/new-historical-character-american-girl-dolls-1990s-millennials-feeling-old-disrespected](https://www.foxnews.com/lifestyle/new-historical-character-american-girl-dolls-1990s-millennials-feeling-old-disrespected)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:07:56+00:00

The release of two "historical" American Girl dolls from the 1990s — dolls named Isabel and Nicki Hoffman — is making some millennial women feel quite old.

## North Carolina juvenile with AR-15 detained at high school basketball game
 - [https://www.foxnews.com/us/north-carolina-juvenile-ar-15-detained-high-school-basketball-game](https://www.foxnews.com/us/north-carolina-juvenile-ar-15-detained-high-school-basketball-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:06:51+00:00

A North Carolina juvenile with an AR-15 was detained Thursday night at a high school basketball game. Police responded to a call saying the suspect brought the gun to school.

## US Court strikes down rule requiring charter boats to have tracking
 - [https://www.foxnews.com/us/us-court-strikes-down-rule-requiring-charter-boats-tracking](https://www.foxnews.com/us/us-court-strikes-down-rule-requiring-charter-boats-tracking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:03:34+00:00

The U.S. Court voted down a rule that would have required charter boats to be equipped with tracking. This was a victory for charter operators who challenged the rule with a 2020 lawsuit.

## North Carolina House Speaker and lawmaker uninjured after SUV rammed
 - [https://www.foxnews.com/us/north-carolina-house-speaker-lawmaker-uninjured-suv-rammed](https://www.foxnews.com/us/north-carolina-house-speaker-lawmaker-uninjured-suv-rammed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:01:53+00:00

The North Carolina House Speaker and another lawmaker were uninjured after their SUV was rammed on the highway. The driver was charged with impaired driving and other counts.

## Rental scams: How to recognize and avoid being a victim
 - [https://www.foxnews.com/tech/rental-scams-avoid-being-victim](https://www.foxnews.com/tech/rental-scams-avoid-being-victim)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:00:32+00:00

Scammers will try to finagle you if you fail to pay attention to rental listings, ensure that the monthly rent is legitimate and more. Here's what to know.

## Parents erupt, successfully defend conservative school board member facing ouster: 'He speaks for us'
 - [https://www.foxnews.com/media/parents-erupt-defend-conservative-school-board-member-facing-ouster-speaks](https://www.foxnews.com/media/parents-erupt-defend-conservative-school-board-member-facing-ouster-speaks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 21:00:11+00:00

Wisconsin parents sound off during a Kenosha Unified School District virtual board meeting Thursday in defense of conservative board member Eric Meadows.

## Judge releases Michigan man who claimed wrongful double homicide conviction
 - [https://www.foxnews.com/us/judge-releases-michigan-man-claimed-wrongful-double-homicide-conviction](https://www.foxnews.com/us/judge-releases-michigan-man-claimed-wrongful-double-homicide-conviction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:59:13+00:00

Jeff Titus, 71, was released from a Michigan prison after a judge voided a 2002 double homicide conviction that Titus long maintained was erroneous.

## Pennsylvania House passes bill waiving statute of limitations for child sex abuse cases
 - [https://www.foxnews.com/politics/pennsylvania-house-passes-bill-waiving-statute-limitations-child-sex-abuse-cases](https://www.foxnews.com/politics/pennsylvania-house-passes-bill-waiving-statute-limitations-child-sex-abuse-cases)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:57:47+00:00

The Pennsylvania House passed two pieces of legislation Friday that would allow victims to sue over currently-outdated child sex abuse claims.

## Wrestler Jeff Hardy avoids jail time but gets driver's license suspended for 10 years following DUI: report
 - [https://www.foxnews.com/sports/wrestler-jeff-hardy-avoids-jail-time-gets-drivers-license-suspended-10-years-dui-report](https://www.foxnews.com/sports/wrestler-jeff-hardy-avoids-jail-time-gets-drivers-license-suspended-10-years-dui-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:50:47+00:00

Jeff Hardy was charged with his third DUI within the last decade, but he pleaded no contest, which helped him avoid jail time. His driver's license is suspended for a decade.

## DC fights back, urges Senate not to reject the eased criminal penalties and allowance for non-citizen voting
 - [https://www.foxnews.com/politics/dc-council-urges-senate-not-reject-eased-criminal-penalties-non-citizen-voting](https://www.foxnews.com/politics/dc-council-urges-senate-not-reject-eased-criminal-penalties-non-citizen-voting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:38:50+00:00

The Washington, D.C., city council sent a letter to Senate leadership urging them to oppose congressional efforts to disapprove of two controversial laws on the chopping block.

## Ex-Cowboys wideout Sam Hurd released from prison after serving nearly a decade for drug trafficking: report
 - [https://www.foxnews.com/sports/ex-cowboys-wideout-sam-hurd-released-from-prison-serving-nearly-decade-drug-trafficking-report](https://www.foxnews.com/sports/ex-cowboys-wideout-sam-hurd-released-from-prison-serving-nearly-decade-drug-trafficking-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:34:31+00:00

Former NFL wide receiver Sam Hurd was released from federal prison late last month after serving nearly a decade on drug trafficking charges, according to one report.

## Cardi B live-tweeting her community service goes viral: 'DON'T COMMIT CRIMES!'
 - [https://www.foxnews.com/media/cardi-b-live-tweeting-community-service-goes-viral-dont-commit-crimes](https://www.foxnews.com/media/cardi-b-live-tweeting-community-service-goes-viral-dont-commit-crimes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:30:09+00:00

Cardi B, a rap and pop superstar, exhorted her millions of followers on Twitter this week to obey the laws or risk punishment from the criminal justice system.

## FDA proposes plant-based, dairy-free milk can be called 'milk' and asks for public feedback
 - [https://www.foxnews.com/lifestyle/fda-proposes-plant-based-dairy-free-milk-called-milk-asks-public-feedback](https://www.foxnews.com/lifestyle/fda-proposes-plant-based-dairy-free-milk-called-milk-asks-public-feedback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:23:14+00:00

A new draft guidance issued by the Food and Drug Administration says plant-based milk companies can call their products milk because people already refer to the drinks as milk.

## Red Sox teammates reportedly unamused by rookie's unorthodox pregame rituals, including shirtless sunbathing
 - [https://www.foxnews.com/sports/red-sox-teammates-reportedly-unamused-rookies-unorthodox-pregame-rituals-including-shirtless-sunbathing](https://www.foxnews.com/sports/red-sox-teammates-reportedly-unamused-rookies-unorthodox-pregame-rituals-including-shirtless-sunbathing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:14:11+00:00

Boston Red Sox first baseman Triston Casas rankled a few feathers last season with his pregame routine which included sunbathing shirtless in the outfield.

## Renewed focus on San Francisco 'Doodler' serial killer sought in murders of gay White men
 - [https://www.foxnews.com/us/renewed-focus-san-francisco-doodler-serial-killer-sought-murders-gay-white-men](https://www.foxnews.com/us/renewed-focus-san-francisco-doodler-serial-killer-sought-murders-gay-white-men)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:12:26+00:00

San Francisco authorities have renewed effort to catch the "Doodler" killer who is believed to have killed several people in the 1970s.

## LA man charged with hacking Instagram influencers' accounts, demanding money and sex videos
 - [https://www.foxnews.com/us/la-man-charged-hacking-instagram-influencers-accounts-demanding-money-sex-vids](https://www.foxnews.com/us/la-man-charged-hacking-instagram-influencers-accounts-demanding-money-sex-vids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:07:14+00:00

An LA man is facing charges after he allegedly hijacked the cell phones of female Instagram influencers and extorted their friends for money and video sex chats.

## Madison Brooks death: Leaked video of LSU student triggers family outrage
 - [https://www.foxnews.com/us/madison-brooks-death-leaked-video-lsu-student-triggers-family-outrage](https://www.foxnews.com/us/madison-brooks-death-leaked-video-lsu-student-triggers-family-outrage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:06:16+00:00

Lawyers for suspects who allegedly raped LSU sophomore Madison Brooks the night she died released a short video showing Brooks slurring her words and getting out of their car.

## NoKo defector describes being mugged in Chicago and called a 'racist': 'It was crazier than North Korea'
 - [https://www.foxnews.com/media/noko-defector-describes-mugged-chicago-called-racist-crazier-north-korea](https://www.foxnews.com/media/noko-defector-describes-mugged-chicago-called-racist-crazier-north-korea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:00:36+00:00

Human rights activist Yeonmi Park said Friday that bystanders refused to help and called her a racist for calling the police on her attackers in Chicago.

## ‘View’ host Sunny Hostin compares Alex Murdaugh to Kyle Rittenhouse: 'Wealthy white guy dynasty'
 - [https://www.foxnews.com/media/view-host-sunny-hostin-compares-alex-murdaugh-kyle-rittenhouse-wealthy-white-guy-dynasty](https://www.foxnews.com/media/view-host-sunny-hostin-compares-alex-murdaugh-kyle-rittenhouse-wealthy-white-guy-dynasty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 20:00:22+00:00

"The View" co-host Sunny Hostin claimed that murder trial defendant Alex Murdaugh reminded her of Kyle Rittenhouse, because both men testified in their own trials.

## VA hired hundreds of employees with drug-related criminal history, putting veterans at risk: watchdog
 - [https://www.foxnews.com/politics/va-hired-hundreds-employees-drug-related-criminal-history-putting-veterans-at-risk-watchdog](https://www.foxnews.com/politics/va-hired-hundreds-employees-drug-related-criminal-history-putting-veterans-at-risk-watchdog)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:49:41+00:00

A report from a federal watchdog says the Department of Veterans Affairs has failed for years to review job applicants, and has hired hundreds with criminal drug convictions.

## Missing Florida 2-year-old boy found safe 24 hours after going missing during naptime: 'It's a miracle'
 - [https://www.foxnews.com/us/missing-florida-2-year-old-boy-found-safe-24-hours-going-missing-naptime-miracle](https://www.foxnews.com/us/missing-florida-2-year-old-boy-found-safe-24-hours-going-missing-naptime-miracle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:49:10+00:00

Joshua “JJ” Rowland, a 2-year-old who vanished from his home in Brooksville, Florida, Thursday, was found safe a day later, the Hernando County Sheriff’s Office says.

## Cher's co-star reacts to 40-year age gap with boyfriend: 'I'm all for her getting some action'
 - [https://www.foxnews.com/entertainment/chers-co-star-reacts-to-40-year-age-gap-with-boyfriend-im-all-for-her-getting-some-action](https://www.foxnews.com/entertainment/chers-co-star-reacts-to-40-year-age-gap-with-boyfriend-im-all-for-her-getting-some-action)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:37:20+00:00

Cher's "Burlesque" co-star Alan Cumming shared his thoughts on her relationship with boyfriend Alexander Edwards, who is nearly 40 years younger than the pop singer.

## 10 killed in riots in Indonesia’s restive Papua province
 - [https://www.foxnews.com/world/10-killed-riots-indonesias-restive-papua-province](https://www.foxnews.com/world/10-killed-riots-indonesias-restive-papua-province)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:36:22+00:00

Ten people have been killed and over 20 others injured in riots in Indonesia’s restive Papua province. The protests started Thursday afternoon amid rumors of a child kidnapping.

## Schizophrenic Wisconsin man charged with attempted homicide after attacking mother with hammer
 - [https://www.foxnews.com/us/schizophrenic-wisconsin-man-charged-attempted-homicide-attacking-mother-hammer](https://www.foxnews.com/us/schizophrenic-wisconsin-man-charged-attempted-homicide-attacking-mother-hammer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:35:08+00:00

A schizophrenic Wisconsin man was charged with attempted homicide after he attacked his mother with hammer Jan.26. The man's bail has been set at $1 million in cash.

## TikTok claims EU didn't notify them of continent-wide employee ban
 - [https://www.foxnews.com/world/tiktok-claims-eu-didnt-notify-them-continent-wide-employee-ban](https://www.foxnews.com/world/tiktok-claims-eu-didnt-notify-them-continent-wide-employee-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:34:06+00:00

TikTok representatives claim that the European Commission never consulted them regarding a temporary ban on the Chinese-owned app for all employees' work devices.

## Indiana ditches plan that would grant illegals driving privileges
 - [https://www.foxnews.com/politics/indiana-ditches-plan-would-grant-illegals-driving-privileges](https://www.foxnews.com/politics/indiana-ditches-plan-would-grant-illegals-driving-privileges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:31:40+00:00

Indiana lawmakers have abandoned a proposal that would have allowed illegal immigrants to obtain state-issued cards granting them driving privileges.

## M23 rebels gain more ground in Congo
 - [https://www.foxnews.com/world/m23-rebels-gain-more-ground-congo](https://www.foxnews.com/world/m23-rebels-gain-more-ground-congo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:30:19+00:00

The Congo's M23 rebel group, which identifies itself as a Rwandan affiliate, has captured the village of Mushaki in the nation's North Kivu province.

## Ronald Dahl’s publisher backs down after anti-woke backlash: ‘Classic’ language version to stay in print
 - [https://www.foxnews.com/media/ronald-dahls-publisher-backs-down-anti-woke-backlash-classic-language-version-stay-print](https://www.foxnews.com/media/ronald-dahls-publisher-backs-down-anti-woke-backlash-classic-language-version-stay-print)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:30:16+00:00

The UK publisher of the classic Ronald Dahl books has relented and will keep the "classic" language version of his stories in print, along with an "inclusive" edition.

## GOP reps to launch Northern Border Security Caucus, as officials tackle surge in migrant encounters
 - [https://www.foxnews.com/politics/gop-reps-launch-northern-border-security-caucus-officials-tackle-surge-migrant-encounters](https://www.foxnews.com/politics/gop-reps-launch-northern-border-security-caucus-officials-tackle-surge-migrant-encounters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:24:54+00:00

Republicans are forming a Northern Border Security Caucus, with 28 members joining the group to deal with an ongoing increase in encounters at the border with Canada,

## Missouri AG rejects Kim Gardner's 'ridiculous' attempt to inject race into legal fight to fire her
 - [https://www.foxnews.com/politics/missouri-ag-rejects-kim-gardners-ridiculous-attempt-inject-race-legal-fight-fire-her](https://www.foxnews.com/politics/missouri-ag-rejects-kim-gardners-ridiculous-attempt-inject-race-legal-fight-fire-her)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:18:16+00:00

Missouri attorney general says that Democratic St. Louis attorney's attempts to inject "race and politics" into his court legal battle to have her removed form her post is "ridiculous."

## Los Angeles DA violates own policy in Catholic bishop murder case: 'Doesn't know the basic ethical rules'
 - [https://www.foxnews.com/us/los-angeles-da-violates-own-policy-catholic-bishop-murder-case-doesnt-know-basic-ethical-rules](https://www.foxnews.com/us/los-angeles-da-violates-own-policy-catholic-bishop-murder-case-doesnt-know-basic-ethical-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:10:13+00:00

Los Angeles DA George Gascon told reporters Wednesday the suspect “admitted” to the crime — but his own policy manual prohibits discussions of confessions in public.

## Living together: More parents are moving in with their adult children, survey finds
 - [https://www.foxnews.com/lifestyle/living-together-more-parents-moving-in-adult-children-survey-finds](https://www.foxnews.com/lifestyle/living-together-more-parents-moving-in-adult-children-survey-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:06:22+00:00

An increase in parents moving in with their adult children is prominent in Americans. One family shares their experience with it and explains why it's working.

## Kamala Harris mocked for repeatedly sharing love of Venn diagrams: 'This is just bizarre'
 - [https://www.foxnews.com/media/kamala-harris-mocked-repeatedly-sharing-love-venn-diagrams-bizarre](https://www.foxnews.com/media/kamala-harris-mocked-repeatedly-sharing-love-venn-diagrams-bizarre)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:00:21+00:00

"Fox & Friends" explores the vice president's affection for the elementary school tool after Harris once again gushed over Venn diagrams at a White House event Thursday.

## Florida teacher on leave after accusation he had White students bow to Black students in his classroom
 - [https://www.foxnews.com/media/florida-teacher-leave-after-accusation-white-students-bow-black-students-classroom](https://www.foxnews.com/media/florida-teacher-leave-after-accusation-white-students-bow-black-students-classroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 19:00:10+00:00

A Florida teacher was put on leave after a video showed White students bowing to Black students in his middle school classroom.

## Biden 'pretty much' ready to announce re-election, Jill Biden says
 - [https://www.foxnews.com/politics/biden-pretty-much-ready-announce-re-election-jill-biden-says](https://www.foxnews.com/politics/biden-pretty-much-ready-announce-re-election-jill-biden-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:56:12+00:00

First lady Jill Biden on Friday said that President Biden is "pretty much" prepared to announce his intention to seek re-election.

## Biden admin's regulations would ban 96% of gas stoves, Republican senator warns
 - [https://www.foxnews.com/politics/biden-admins-regulations-ban-96-percent-gas-stoves-republican-senator-warns](https://www.foxnews.com/politics/biden-admins-regulations-ban-96-percent-gas-stoves-republican-senator-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:42:08+00:00

GOP Sen. Steve Daines warned in a letter to Energy Secretary Jennifer Granholm that her agency's regulations would ban up to 96% of the gas stoves currently available.

## George W. Bush pushes back on GOP criticism of Ukraine funding: 'not going to constrain' helping US citizens
 - [https://www.foxnews.com/politics/george-w-bush-pushes-back-gop-criticism-ukraine-funding-helping-us-citizens](https://www.foxnews.com/politics/george-w-bush-pushes-back-gop-criticism-ukraine-funding-helping-us-citizens)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:32:45+00:00

Former President George W. Bush fired back on Republican criticism of U.S. funds going to help Ukraine in its war with Russia during an event commemorating the anniversary of PEPFAR.

## MSNBC historian suggests Georgia grand juror's media tour was conspiracy to help Trump
 - [https://www.foxnews.com/media/msnbc-historian-suggests-georgia-grand-jurors-media-tour-conspiracy-help-trump](https://www.foxnews.com/media/msnbc-historian-suggests-georgia-grand-jurors-media-tour-conspiracy-help-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:30:39+00:00

NBC News presidential historian Michael Beschloss floated a conspiracy theory that the media tour of Georgia special grand jury forewoman Emily Kohrs was concocted to save Donald Trump.

## Florida woman accused of killing ill husband seeks release from jail
 - [https://www.foxnews.com/us/florida-woman-accused-killing-ill-husband-seeks-release-jail](https://www.foxnews.com/us/florida-woman-accused-killing-ill-husband-seeks-release-jail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:22:06+00:00

A Florida woman who has been accused of fatally shooting her terminally ill husband is seeking to be released from jail.The woman said she and her husband had a suicide pact.

## Suspect confesses to murder of LA bishop, prosecutor says
 - [https://www.foxnews.com/us/suspect-confesses-murder-la-bishop-prosecutor-says](https://www.foxnews.com/us/suspect-confesses-murder-la-bishop-prosecutor-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:21:44+00:00

The suspect in the killing of Los Angeles Auxiliary Bishop David O’Connell has confessed to the homicide, Los Angeles District Attorney George Gascón said Wednesday.

## White House says 'no indication' of misused Ukraine funds after Marjorie Taylor Greene calls for audit
 - [https://www.foxnews.com/politics/white-house-says-no-indication-misused-ukraine-funds-marjorie-taylor-greene-calls-audit](https://www.foxnews.com/politics/white-house-says-no-indication-misused-ukraine-funds-marjorie-taylor-greene-calls-audit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:21:28+00:00

The White House said Friday that there is "no indication" that any of the billions of dollars in security assistance sent to Ukraine has been misspent or misplaced as Republicans push for an audit.

## Arizona Gov. Hobbs' second pick for head of child welfare agency drops out
 - [https://www.foxnews.com/politics/arizona-gov-hobbs-second-pick-head-child-welfare-agency-drops](https://www.foxnews.com/politics/arizona-gov-hobbs-second-pick-head-child-welfare-agency-drops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:20:07+00:00

Arizona Gov. Katie Hobbs' second pick for the head of the child welfare agency has dropped out. Matthew Stewart left the position saying it was 'best for all parties involved.'

## Second West Virginia hospital fails to complete background checks
 - [https://www.foxnews.com/us/second-west-virginia-hospital-fails-complete-background-checks](https://www.foxnews.com/us/second-west-virginia-hospital-fails-complete-background-checks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:18:17+00:00

A second hospital in West Virginia failed to complete background checks for employees. A former nurses assistant admitted to killing seven veterans at one of the hospitals.

## Madeleine McCann disappearance: Polish police reportedly dispute woman's claims she is missing British girl
 - [https://www.foxnews.com/world/madeleine-mccann-disappearance-polish-police-reportedly-dispute-womans-claims-she-is-missing-british-girl](https://www.foxnews.com/world/madeleine-mccann-disappearance-polish-police-reportedly-dispute-womans-claims-she-is-missing-british-girl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:16:37+00:00

Polish police are disputing a young woman's claims that she may be missing British toddler Madeleine McCann, who disappeared from a vacation in Portugal in 2007.

## Federal agency proposes California spotted owl protection
 - [https://www.foxnews.com/us/federal-agency-proposes-california-spotted-owl-protection](https://www.foxnews.com/us/federal-agency-proposes-california-spotted-owl-protection)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:16:17+00:00

A federal wildlife agency has introduced a protection proposal for the California spotted owl. This comes after a lawsuit to assess the decision not to protect the brown and white birds.

## News photographer dies after stabbing assault in northern Mexico
 - [https://www.foxnews.com/us/news-photographer-dies-stabbing-assault-northern-mexico](https://www.foxnews.com/us/news-photographer-dies-stabbing-assault-northern-mexico)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:14:44+00:00

A news photographer died Tuesday after a stabbing in northern Mexico. Police arrested two youths and believe the attack could have been an attempted robbery.

## US Olympic rower Patricia Spratlen Etem calls Biden administration's proposed Title IX changes ‘awful threat'
 - [https://www.foxnews.com/sports/us-olympic-rower-patricia-spratlen-etem-calls-biden-administrations-proposed-title-ix-changes-awful-threat](https://www.foxnews.com/sports/us-olympic-rower-patricia-spratlen-etem-calls-biden-administrations-proposed-title-ix-changes-awful-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:13:25+00:00

Two-time Olympic rower Patricia Spratlen Etem spoke to Fox News Digital about the ongoing debate surrounding transgender athletes in women’s sports and the proposed changes to Title IX.

## Alex Murdaugh is 'outsmarting' prosecutors on witness stand, says Ted Williams
 - [https://www.foxnews.com/media/alex-murdaugh-outsmarting-prosecutors-witness-stand-ted-williams](https://www.foxnews.com/media/alex-murdaugh-outsmarting-prosecutors-witness-stand-ted-williams)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:02:23+00:00

Criminal defense attorney Ted Williams says Alex Murdaugh trial prosecutors are 'digging a hole for themselves' during the defendant's murder trial testimony.

## DOJ officer training 'defines important terms,' 'clarifies language related to transgender individuals'
 - [https://www.foxnews.com/media/doj-training-defines-important-terms-clarifies-language-related-transgender-individuals](https://www.foxnews.com/media/doj-training-defines-important-terms-clarifies-language-related-transgender-individuals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 18:00:27+00:00

A DOJ law enforcement training program "defines important terms and clarifies language related to transgender individuals" to build awareness and understanding of the community.

## Atlanta Braves reveal next PA announcer, informing emotional winner of audition in heartwarming video
 - [https://www.foxnews.com/sports/atlanta-braves-reveal-pa-announcer-informing-emotional-winner-audition-heartwarming-video](https://www.foxnews.com/sports/atlanta-braves-reveal-pa-announcer-informing-emotional-winner-audition-heartwarming-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:54:53+00:00

The Atlanta Braves announced the next PA announcer at Truist Park on Friday, informing the winner of the audition in a video posted to social media,

## Ole Miss basketball parts ways with head coach amid SEC-worst 2-13 record
 - [https://www.foxnews.com/sports/ole-miss-basketball-parts-ways-head-coach-amid-sec-worst-2-13-record](https://www.foxnews.com/sports/ole-miss-basketball-parts-ways-head-coach-amid-sec-worst-2-13-record)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:49:58+00:00

Ole Miss basketball and head coach Kermit Davis mutually agreed to part ways on Friday after five seasons. Davis compiled a record of 74-79, going to the NCAA tournament one time.

## Evangeline Lilly recalls making Michael Douglas a provocative proposal
 - [https://www.foxnews.com/entertainment/evangeline-lilly-recalls-making-michael-douglas-provocative-proposal](https://www.foxnews.com/entertainment/evangeline-lilly-recalls-making-michael-douglas-provocative-proposal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:46:43+00:00

Marvel actress Evangeline Lilly candidly had a naughty moment with her “Ant-Man and the Wasp: Quantumania” co-star Michael Douglas while filming in front of kids on set.

## Red flags: China, North Korea flex military capabilities as fears over new conflicts continue to rise in Asia
 - [https://www.foxnews.com/world/red-flags-china-north-korea-flex-military-capabilities-fears-new-conflicts-continue-rise-asia](https://www.foxnews.com/world/red-flags-china-north-korea-flex-military-capabilities-fears-new-conflicts-continue-rise-asia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:45:37+00:00

Taiwan detected some 37 Chinese aircraft and six navy vessels, while the Philippines found over two dozen Chinese navy vessels in the South China Sea on Friday.

## Arizona rancher George Alan Kelly's murder charge downgraded to second-degree in shooting of Mexican migrant
 - [https://www.foxnews.com/us/arizona-rancher-george-alan-kelly-murder-charge-downgraded-second-degree-shooting-mexican-man](https://www.foxnews.com/us/arizona-rancher-george-alan-kelly-murder-charge-downgraded-second-degree-shooting-mexican-man)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:44:10+00:00

George Alan Kelly, the 73-year-old rancher accused of shooting and killing a Mexican man on his Arizona property on Jan. 30, has had his murder charge downgraded.

## Former Obama economist says 'little if any progress' made on inflation under Biden
 - [https://www.foxnews.com/politics/former-obama-economist-says-little-progress-made-inflation-biden](https://www.foxnews.com/politics/former-obama-economist-says-little-progress-made-inflation-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:38:24+00:00

A former Obama economist is warning that the economy is "overheated" and ther has been little "if any" progress made on tackling inflation, after a tough January report.

## Michigan woman charged in college student's hit-and-run death returns to U.S. after fleeing to Thailand
 - [https://www.foxnews.com/us/michigan-woman-charged-college-students-hit-run-death-returns-us-fleeing-thailand](https://www.foxnews.com/us/michigan-woman-charged-college-students-hit-run-death-returns-us-fleeing-thailand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:34:46+00:00

The Michigan woman charged in the fatal hit-and-run death of a college student has returned to the U.S. and is in federal custody, an FBI spokesperson tells Fox News Digital.

## Alec Baldwin's 'Rust' armorer Hannah Gutierrez-Reed appears in court for fatal shooting of Halyna Hutchins
 - [https://www.foxnews.com/entertainment/alec-baldwins-rust-armorer-hannah-gutierrez-reed-appears-court-fatal-shooting-halyna-hutchins](https://www.foxnews.com/entertainment/alec-baldwins-rust-armorer-hannah-gutierrez-reed-appears-court-fatal-shooting-halyna-hutchins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:34:07+00:00

Hannah Gutierrez-Reed made her first court appearance Friday. The "Rust" armorer was charged with involuntary manslaughter in connection to the death of Halyna Hutchins.

## Protest responding to Massachusetts Democrat's comments about disabled unborn babies announced
 - [https://www.foxnews.com/politics/protest-responding-massachusetts-democrats-comments-disabled-unborn-babies-announced](https://www.foxnews.com/politics/protest-responding-massachusetts-democrats-comments-disabled-unborn-babies-announced)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:30:47+00:00

A protest is planned in Framingham, Massachusetts, in response to Michael Hugo's saying disabled babies not aborted become a strain on the school system.

## Florida Dem drops proposal to ban dogs from sticking their heads out the car window
 - [https://www.foxnews.com/politics/florida-dem-drops-proposal-ban-dogs-from-sticking-heads-out-car-window](https://www.foxnews.com/politics/florida-dem-drops-proposal-ban-dogs-from-sticking-heads-out-car-window)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:26:20+00:00

A Florida Democrat says she won't push for legislation that bans drivers from allowing their dogs to stick their heads out the car window while they drive.

## Tropical Cyclone Freddy drops dangerous rainfall over Mozambique
 - [https://www.foxnews.com/weather/tropical-cyclone-freddy-drops-dangerous-rainfall-mozambique](https://www.foxnews.com/weather/tropical-cyclone-freddy-drops-dangerous-rainfall-mozambique)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:09:36+00:00

Mozambique was hit with Tropical Cyclone Freddy on Friday. The storm dumped dangerous amounts of rain and wreaked havoc across southern Africa.

## House GOP votes next week to kill Biden’s ‘woke’ ESG investing rule
 - [https://www.foxnews.com/politics/house-gop-votes-next-week-kill-bidens-woke-esg-investing-rule](https://www.foxnews.com/politics/house-gop-votes-next-week-kill-bidens-woke-esg-investing-rule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:07:34+00:00

House Republicans next week will call up a bill to kill the Biden administration's ESG rule, which they say threatens the retirement saves of millions of Americans.

## Father of girl who died from bird flu also contracts the virus, health officials say risk of spreading is low
 - [https://www.foxnews.com/world/father-girl-who-died-bird-flu-contracts-virus-health-officials-say-risk-spreading-low](https://www.foxnews.com/world/father-girl-who-died-bird-flu-contracts-virus-health-officials-say-risk-spreading-low)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:07:22+00:00

A Cambodian girl died after contracting bird flu earlier this week. The girl's father recently tested positive for the illness but has mild symptoms.

## Herschel Walker's curious case of $595k in private jets and a donor-owned car wash
 - [https://www.foxnews.com/politics/herschel-walkers-curious-case-595k-private-jets-donor-owned-car-wash](https://www.foxnews.com/politics/herschel-walkers-curious-case-595k-private-jets-donor-owned-car-wash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:02:49+00:00

Former Republican Senate candidate Herschel Walker's campaign shelled out hundreds of thousands of dollars for private jet travel to a defunct car wash owned by a donor over the course of just nine months last year.

## Nigerian police arrest lawmaker accused of carrying $500K in cash the day before elections
 - [https://www.foxnews.com/world/nigerian-police-arrest-lawmaker-accused-carrying-500k-cash-day-before-elections](https://www.foxnews.com/world/nigerian-police-arrest-lawmaker-accused-carrying-500k-cash-day-before-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:01:44+00:00

Nigerian police arrested Chinyere Igwe, a lawmaker who allegedly carried $500,000 in cash a day before elections. It is illegal to move over $10,000 of undeclared cash in Nigeria.

## Alex Murdaugh murder trial: Friday marks 4 years since Mallory Beach’s boat crash death
 - [https://www.foxnews.com/us/alex-murdaugh-murder-trial-friday-marks-4-years-mallory-beach-boat-crash-death](https://www.foxnews.com/us/alex-murdaugh-murder-trial-friday-marks-4-years-mallory-beach-boat-crash-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:01:27+00:00

Paul Murdaugh had a blood-alcohol level three times the legal limit when he slammed his father's boat into the Archers Creek Bridge, while Beach and others were aboard.

## Yale professor suggesting ‘mass suicide’ of elderly 'inappropriate' but understandable: Japanese commentator
 - [https://www.foxnews.com/world/yale-professor-suggesting-mass-suicide-elderly-inappropriate-understandable-japanese-commentator](https://www.foxnews.com/world/yale-professor-suggesting-mass-suicide-elderly-inappropriate-understandable-japanese-commentator)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:00:56+00:00

Japanese commentator Yoko Ishii weighed in on a Yale professor's suggestion that Japan's elderly commit mass suicide to alleviate its aging population burdens.

## Putin issues nuclear warning, as Russia’s assault on Ukraine hits second year
 - [https://www.foxnews.com/opinion/putin-issues-nuclear-warning-as-russias-assault-on-ukraine-hits-second-year](https://www.foxnews.com/opinion/putin-issues-nuclear-warning-as-russias-assault-on-ukraine-hits-second-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 17:00:46+00:00

With nuclear card in his back pocket, Russian President Vladimir Putin believes Russia will out-suffer and outlast its adversary as Friday marks the first anniversary of Russia's invasion of Ukraine.

## Dutch parliamentary inquiry releases damning report into government's handling of natural gas extraction
 - [https://www.foxnews.com/world/dutch-parliamentary-inquiry-releases-damning-report-governments-handling-natural-gas-extraction](https://www.foxnews.com/world/dutch-parliamentary-inquiry-releases-damning-report-governments-handling-natural-gas-extraction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:55:46+00:00

A report into the Dutch government's handling of natural gas extraction that caused multiple earthquakes was released by the country's parliamentary inquiry.

## MI GOP Rep. John James opts out Senate campaign, will run for reelection to his Detroit-area House seat
 - [https://www.foxnews.com/politics/mi-gop-rep-john-james-opts-out-senate-campaign-run-reelection-detroit-area-house-seat](https://www.foxnews.com/politics/mi-gop-rep-john-james-opts-out-senate-campaign-run-reelection-detroit-area-house-seat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:52:04+00:00

John James is opting out a campaign for senate and has filed paperwork to run for reelection to his Detroit-area House seat. James is a rising star in the Republican party.

## Retired Navy SEAL addresses 'victimhood epidemic' and how to break that chain
 - [https://www.foxnews.com/lifestyle/retired-navy-seal-addresses-victimhood-epidemic-break-chain](https://www.foxnews.com/lifestyle/retired-navy-seal-addresses-victimhood-epidemic-break-chain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:50:37+00:00

Former Navy SEAL Mike Sarraille joined "Fox & Friends" to discuss his new book "The Everyday Warrior" and how to address the victimhood mindset in America today.

## Meghan Markle mocked mercilessly by sister over 'South Park' episode
 - [https://www.foxnews.com/entertainment/meghan-markle-mocked-mercilessly-by-sister-over-south-park-episode](https://www.foxnews.com/entertainment/meghan-markle-mocked-mercilessly-by-sister-over-south-park-episode)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:46:13+00:00

Meghan Markle gets skewered by her sister Samantha, who says the recent "South Park" episode got Meghan "just right."

## Outer shell of Venus may be resurfacing the planet, NASA says
 - [https://www.foxnews.com/science/outer-shell-venus-resurfacing-planet-nasa-says](https://www.foxnews.com/science/outer-shell-venus-resurfacing-planet-nasa-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:42:14+00:00

NASA scientists found that the outer shell of Venus may be resurfacing the planet. The team studied geological features called "coronae" in Magellan mission images.

## Idaho murders: King Road home where Bryan Kohberger allegedly stabbed four students boarded up, photos show
 - [https://www.foxnews.com/us/idaho-murders-king-road-home-where-bryan-kohberger-allegedly-stabbed-four-students-boarded-up-photos-show](https://www.foxnews.com/us/idaho-murders-king-road-home-where-bryan-kohberger-allegedly-stabbed-four-students-boarded-up-photos-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:39:46+00:00

The King Road home near the University of Idaho campus where four students were killed in November has been boarded up and fenced in as the suspect remains jailed.

## Georgia police rescue 17 pit bulls from dog fighting property kept in 'heinous' conditions
 - [https://www.foxnews.com/us/georgia-police-rescue-17-pit-bulls-dog-fighting-property-kept-heinous-conditions](https://www.foxnews.com/us/georgia-police-rescue-17-pit-bulls-dog-fighting-property-kept-heinous-conditions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:37:30+00:00

Georgia police showed up at the property of a suspected dog fighting facility and recovered more than a dozen pit bulls who they say were being groomed to fight prior to sale.

## AOC rebuked for 'demanding' Japan 'embrace LGBTQ alphabet wokeness' during controversial Asia trip
 - [https://www.foxnews.com/media/aoc-rebuked-demanding-japan-embrace-lgbtq-alphabet-wokeness-during-controversial-asia-trip](https://www.foxnews.com/media/aoc-rebuked-demanding-japan-embrace-lgbtq-alphabet-wokeness-during-controversial-asia-trip)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:33:56+00:00

Alexandria Ocasio-Cortez advised that Japan shape up on "LGBT protections" in a nearly 40-minute-long Instagram video and accused the government of being "very discriminatory."

## LIV Golf’s Sergio Garcia faults Rory McIlroy for ‘lacking maturity’ as friendship sours
 - [https://www.foxnews.com/sports/liv-golfs-sergio-garcia-faults-rory-mcilroy-lacking-maturity-friendship-sours](https://www.foxnews.com/sports/liv-golfs-sergio-garcia-faults-rory-mcilroy-lacking-maturity-friendship-sours)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:32:36+00:00

LIV Golf has done more than just disrupt the status quo of golf – it also seems to have created a wedge between old friends

## Alex Murdaugh admits he first claimed he was at dog kennels in court
 - [https://www.foxnews.com/us/alex-murdaugh-admits-first-claimed-dog-kennels-court](https://www.foxnews.com/us/alex-murdaugh-admits-first-claimed-dog-kennels-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:20:27+00:00

Cross-examination of Alex Murdaugh continued Friday, with prosecutor Creighton Waters confronting the disbarred attorney about his inconsistent statements.

## DeSantis team slams HuffPo for touting cop-killer's attack on governor: 'This monster killed a police officer'
 - [https://www.foxnews.com/media/desantis-team-slams-huffpo-touting-cop-killers-attack-governor-monster-killed-police-officer](https://www.foxnews.com/media/desantis-team-slams-huffpo-touting-cop-killers-attack-governor-monster-killed-police-officer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:07:56+00:00

Twitter users slammed a Huffington Post piece for appearing to side with a Florida murder convict who used his last words before execution to slam Ron DeSantis.

## Trump's ambassador to Mexico 'hit the roof' after Mexican gov't changed migrant policies: book
 - [https://www.foxnews.com/politics/trumps-ambassador-mexico-hit-roof-mexican-govt-changed-migrant-policies-book](https://www.foxnews.com/politics/trumps-ambassador-mexico-hit-roof-mexican-govt-changed-migrant-policies-book)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 16:01:10+00:00

President Trump's ambassador to Mexico "hit the roof" in the final days of the Trump administration when Mexico pushed through a controversial immigration reform measure.

## Accused Florida ‘Killer Clown’ seeks to drop case, citing lack of surviving witnesses or new evidence
 - [https://www.foxnews.com/us/accused-florida-killer-clown-seeks-drop-case-citing-lack-surviving-witnesses-new-evidence](https://www.foxnews.com/us/accused-florida-killer-clown-seeks-drop-case-citing-lack-surviving-witnesses-new-evidence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:55:07+00:00

Prosecutors chose to delay Sheila Keen-Warren's indictment, and charged her with the murder of Marlene Warren in 2017 despite a lack of new evidence, the defense said.

## West hit by winter storm as California sees rare blizzard warning
 - [https://www.foxnews.com/us/west-hit-winter-storm-california-rare-blizzard-warning](https://www.foxnews.com/us/west-hit-winter-storm-california-rare-blizzard-warning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:51:19+00:00

A rare blizzard warning has been issued in southern California on Friday, and the slow-moving winter weather system is forecast to shift eastward over the weekend.

## Woman who lives near Ohio train derailment site sends message to Joy Behar: 'Not the time to play politics'
 - [https://www.foxnews.com/media/woman-lives-near-ohio-train-derailment-site-sends-message-joy-behar-time-play-politics](https://www.foxnews.com/media/woman-lives-near-ohio-train-derailment-site-sends-message-joy-behar-time-play-politics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:41:41+00:00

Ashley Bennett said on "Fox & Friends" Friday that she's not surprised by Behar's comments, but she stressed the need to put politics aside.

## Senior Russian official threatens Polish borders as Moscow mounts aggression against other European nations
 - [https://www.foxnews.com/world/senior-russian-official-threatens-polish-borders-moscow-mounts-aggression-against-european-nations](https://www.foxnews.com/world/senior-russian-official-threatens-polish-borders-moscow-mounts-aggression-against-european-nations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:39:44+00:00

Former Russian President Dmitry Medvedev issued a direct threat against NATO on the anniversary of the war in Ukraine by calling on Moscow to push Western defenses across Polish borders.

## LeBron James' quick hands save costly camera from damage in win over Warriors
 - [https://www.foxnews.com/sports/lebron-james-quick-hands-save-costly-camera-damage-win-over-warriors](https://www.foxnews.com/sports/lebron-james-quick-hands-save-costly-camera-damage-win-over-warriors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:35:00+00:00

LeBron James saved a camera from crashing to the floor Thursday night as the Los Angeles Lakers beat the Golden State Warriors in the first game after the All-Star break.

## Democrats hammered for no-showing border hearing in Arizona: 'Shameful'
 - [https://www.foxnews.com/media/democrats-hammered-no-showing-border-hearing-arizona-shameful](https://www.foxnews.com/media/democrats-hammered-no-showing-border-hearing-arizona-shameful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:30:36+00:00

Rep. Troy Nehls, R-Texas, blasts House Democrats for refusing to join GOP representatives in Yuma, Arizona for an in-person hearing on the border crisis.

## LA DA Gascon suspends prosecutor for misgendering and 'deadnaming' trans child molester accused of murder
 - [https://www.foxnews.com/us/la-da-gascon-suspends-prosecutor-misgendering-deadnaming-trans-child-molester-accused-murder](https://www.foxnews.com/us/la-da-gascon-suspends-prosecutor-misgendering-deadnaming-trans-child-molester-accused-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:25:05+00:00

Los Angeles DA George Gascon has punished a prosecutor for allegedly "deadnaming" a convicted child molester accused of identifying as trans to game the system.

## Former Massachusetts youth minister pleads guilty to sexually assaulting 3 vulnerable boys
 - [https://www.foxnews.com/us/former-massachusetts-youth-minister-pleads-guilty-sexually-assaulting-3-vulnerable-boys](https://www.foxnews.com/us/former-massachusetts-youth-minister-pleads-guilty-sexually-assaulting-3-vulnerable-boys)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:18:02+00:00

Russel David, a youth minister from Massachusetts, pleaded guilty to sexually assaulting three boys. He will serve up to four years for child rape and other charges.

## Kate Middleton, Prince William’s rare PDA ‘love tap,’ Meghan Markle, Prince Harry’s wild lawsuit
 - [https://www.foxnews.com/entertainment/kate-middleton-prince-williams-rare-pda-love-tap-meghan-markle-prince-harrys-wild-lawsuit](https://www.foxnews.com/entertainment/kate-middleton-prince-williams-rare-pda-love-tap-meghan-markle-prince-harrys-wild-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:18:00+00:00

The Fox News Entertainment newsletter brings you the latest Hollywood headlines, celebrity interviews and stories from Los Angeles and beyond.

## Russian tank destroyed in Ukraine is put on display outside Russian embassy in Germany
 - [https://www.foxnews.com/world/russian-tank-destroyed-ukraine-displayes-outside-russian-embassy-berlin-germany](https://www.foxnews.com/world/russian-tank-destroyed-ukraine-displayes-outside-russian-embassy-berlin-germany)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:16:12+00:00

Activists in Berlin, Germany have parked a Russian tank destroyed in Ukraine outside its embassy there on the one-year anniversary of the conflict.

## North Carolina bill that would make medical marijuana consumption legal set to reach Senate next week
 - [https://www.foxnews.com/politics/north-carolina-bill-would-make-medical-marijuana-consumption-legal-reach-senate-next-week](https://www.foxnews.com/politics/north-carolina-bill-would-make-medical-marijuana-consumption-legal-reach-senate-next-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:14:35+00:00

A bill that would make medical marijuana use in North Carolina legal will reach the state Senate floor next week. Medical marijuana use will still be under tight controls.

## What's really killing your laptop battery?
 - [https://www.foxnews.com/tech/whats-really-killing-your-laptop-battery](https://www.foxnews.com/tech/whats-really-killing-your-laptop-battery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:13:56+00:00

Worried about your laptop's battery life? Kurt "The CyberGuy" Knutsson provides advice on how you should be charging your devices to maximize their effectiveness.

## Trump, Haley and potential 2024 contenders like DeSantis court big donors as GOP's White House race heats up
 - [https://www.foxnews.com/politics/trump-desantis-pence-haley-others-court-big-donors-2024-gop-race-heats-up](https://www.foxnews.com/politics/trump-desantis-pence-haley-others-court-big-donors-2024-gop-race-heats-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:05:47+00:00

Donald Trump, Ron DeSantis, Nikki Haley, Mike Pence and Tim Scott gather with top Republican Party donors at three separate events in Florida and Texas.

## 2023 Oscars hires ‘crisis team’ after Will Smith slap: A look at who else is banned from the Academy
 - [https://www.foxnews.com/entertainment/2023-oscars-hires-crisis-team-after-will-smith-slap-who-else-banned-from-academy](https://www.foxnews.com/entertainment/2023-oscars-hires-crisis-team-after-will-smith-slap-who-else-banned-from-academy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:00:52+00:00

Ahead of the 95th Oscars, here's a look back at the award show's storied history including if an Oscar has been revoked, who has refused a statuette and stars like Will Smith who've been blacklisted.

## A dog and his soldier: Lieutenant's prayers answered after beloved pup he bonded with overseas is rescued
 - [https://www.foxnews.com/lifestyle/dog-soldier-lieutenants-prayers-answered-beloved-pup-bonded-overseas-rescued](https://www.foxnews.com/lifestyle/dog-soldier-lieutenants-prayers-answered-beloved-pup-bonded-overseas-rescued)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:00:41+00:00

A stray dog found and cared for overseas by U.S. Army First Lt. Tad has been brought to safety in Indiana, thanks to the help of New York nonprofit Paws of War.

## Ohio pizzeria goes viral with blunt sign seeking 'non-stupid people' to hire
 - [https://www.foxnews.com/media/ohio-pizzeria-goes-viral-blunt-sign-seeking-non-stupid-people-hire](https://www.foxnews.com/media/ohio-pizzeria-goes-viral-blunt-sign-seeking-non-stupid-people-hire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:00:40+00:00

Santino's Pizzeria owner Rob joined "Fox & Friends" Friday to discuss his latest effort to get more quality applicants at his Columbus, Ohio restaurant.

## Pro-life leaders react to heightened celebrity embrace of motherhood: 'Now the baby bump is accentuated'
 - [https://www.foxnews.com/media/pro-life-leaders-heightened-celebrity-embrace-motherhood-baby-bump-accentuated](https://www.foxnews.com/media/pro-life-leaders-heightened-celebrity-embrace-motherhood-baby-bump-accentuated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:00:18+00:00

Pro-life leaders respond to the trend in recent years of more high-profile celebrities publicly celebrating their pregnancies and motherhood.

## Here’s how DeSantis schooled top Democrats in their own blue states
 - [https://www.foxnews.com/opinion/heres-how-desantis-schooled-top-democrats-their-own-blue-states](https://www.foxnews.com/opinion/heres-how-desantis-schooled-top-democrats-their-own-blue-states)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 15:00:04+00:00

Here’s how Florida Gov. DeSantis schooled top Democrats in their blue states. He caught Democrats going woke, but outsmarted them on what voters care about.

## Netflix's tofu-for-toddlers, Don Lemon's penance, and more from Fox News Opinion
 - [https://www.foxnews.com/opinion/netflix-tofu-toddlers-don-lemon-penance-more-fox-news-opinion](https://www.foxnews.com/opinion/netflix-tofu-toddlers-don-lemon-penance-more-fox-news-opinion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:49:14+00:00

Read the latest from Fox News Opinion & watch videos from Tucker Carlson, Sean Hannity, Laura Ingraham & more.

## Russell Wilson denies report he called for Pete Carroll's job in Seattle, lawyer says 'entirely fabricated'
 - [https://www.foxnews.com/sports/russell-wilson-denies-report-called-pete-carrolls-job-seattle-lawyer-says-entirely-fabricated](https://www.foxnews.com/sports/russell-wilson-denies-report-called-pete-carrolls-job-seattle-lawyer-says-entirely-fabricated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:46:13+00:00

Denver Broncos quarterback Russell Wilson denied a Friday report that he called for the firing of Pete Carroll in Seattle before his trade to Denver.

## Alex Murdaugh trial: Murder charges against the disgraced South Carolina legal scion
 - [https://www.foxnews.com/us/alex-murdaugh-trial-murder-charges-against-disgraced-south-carolina-legal-scion](https://www.foxnews.com/us/alex-murdaugh-trial-murder-charges-against-disgraced-south-carolina-legal-scion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:41:01+00:00

A Colleton County grand jury in 2022 indicted Alex Murdaugh on four counts in connection with his wife and son's murders. These are the charges against him.

## Winter storm shuts down Portland, hammers Midwest; San Diego hit with first-ever blizzard warning
 - [https://www.foxnews.com/us/winter-storm-portland-hammers-midwest-san-diego-blizzard-warning](https://www.foxnews.com/us/winter-storm-portland-hammers-midwest-san-diego-blizzard-warning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:31:27+00:00

A coast-to-coast winter storm is continuing to impact much of the U.S. on Friday and into the weekend, bringing widespread power outages and heavy snowfall.

## Bill to ban sex change procedures for minors in Tennessee heads to governor's desk
 - [https://www.foxnews.com/politics/bill-ban-sex-change-procedures-minors-tennessee-heads-governors-desk](https://www.foxnews.com/politics/bill-ban-sex-change-procedures-minors-tennessee-heads-governors-desk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:20:24+00:00

A bill to ban sex change operations for minors was passed by the Tennessee House and sent to Governor Bill Lee's desk.

## Katy Perry ‘traumatized’ ‘American Idol’ contestant with harsh critique: ‘In my nightmares’
 - [https://www.foxnews.com/entertainment/katy-perry-traumatized-american-idol-contestant-harsh-critique-nightmares](https://www.foxnews.com/entertainment/katy-perry-traumatized-american-idol-contestant-harsh-critique-nightmares)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:15:24+00:00

An "American Idol" auditioner Adriel Carrion opened up about his experience on the show and confessed that judge Katy Perry "traumatized" him.

## Georgia senators want to require cash bail for more crimes than under current law
 - [https://www.foxnews.com/politics/georgia-senators-require-cash-bail-crimes-current-law](https://www.foxnews.com/politics/georgia-senators-require-cash-bail-crimes-current-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:15:07+00:00

Senators in Georgia want to prevent people from committing additional crimes by requiring cash bail for more crimes than under current law.

## Lord of the Rings reboot inspires outrage from fans: 'We get it already y'all hate Tolkien'
 - [https://www.foxnews.com/media/lord-rings-reboot-inspires-outrage-from-fans-we-get-yall-hate-tolkien](https://www.foxnews.com/media/lord-rings-reboot-inspires-outrage-from-fans-we-get-yall-hate-tolkien)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:13:50+00:00

The announcement that a movie studio is rebooting the beloved Lord of the Rings franchise sparked outrage and creative ideas from Twitter users.

## Ex-Oakland police chief files appeal to what he claims was his wrongful termination
 - [https://www.foxnews.com/us/ex-oakland-police-chief-files-appeal-claims-wrongful-termination](https://www.foxnews.com/us/ex-oakland-police-chief-files-appeal-claims-wrongful-termination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:12:06+00:00

LeRonne Armstrong, the former police chief of Oakland, California, filed an appeal to his alleged wrongful termination. The officer was accused of covering up an officer's misconduct.

## China releases 12-point peace plan for Russia-Ukraine war
 - [https://www.foxnews.com/world/china-releases-12-point-peace-plan-russia-ukraine-war](https://www.foxnews.com/world/china-releases-12-point-peace-plan-russia-ukraine-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:09:50+00:00

The People's Republic of China called for a cease-fire Friday and released a 12-point plan for peace between Russia and Ukraine on the one year anniversary of the invasion.

## Washington teen accidently shoots, kills 15-year-old boy
 - [https://www.foxnews.com/us/washington-teen-accidently-shoots-kills-15-year-old-boy](https://www.foxnews.com/us/washington-teen-accidently-shoots-kills-15-year-old-boy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:06:05+00:00

A teen accidently fatally shot a 15-year-old boy at a home west of Spokane, Washington. A group of teens were playing video games when one of them revealed a gun.

## Florida photojournalist speaks from hospital bed about TV news reporter's killing: 'You're losing a friend'
 - [https://www.foxnews.com/us/florida-photojournalist-speaks-hospital-bed-tv-news-reporter-killing-youre-losing-a-friend](https://www.foxnews.com/us/florida-photojournalist-speaks-hospital-bed-tv-news-reporter-killing-youre-losing-a-friend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 14:05:01+00:00

Jesse Walden, the 29-year-old Florida photojournalist who was shot alongside Dylan Lyons Wednesday near Orlando, is speaking out about the death of his friend and colleague.

## Seattle child's body found in Ballard neighborhood
 - [https://www.foxnews.com/us/seattle-childs-body-found-ballard-neighborhood](https://www.foxnews.com/us/seattle-childs-body-found-ballard-neighborhood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:57:09+00:00

A Washington child's body was found in a Seattle neighborhood. Police have not released the age or any other details related to the child's death.

## Illinois woman ran over by thief who stole her SUV with 2-year-old inside
 - [https://www.foxnews.com/us/illinois-woman-ran-over-thief-stole-suv-2-year-old-inside](https://www.foxnews.com/us/illinois-woman-ran-over-thief-stole-suv-2-year-old-inside)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:55:39+00:00

A man stole a woman's SUV and ran over the Chicago resident as she tried to rescue her 2-year-old child. The man then fled with the woman's child.

## Sister of Colorado girl who went missing at 14 became investigator in already bungled case
 - [https://www.foxnews.com/us/sister-colorado-girl-who-went-missing-14-became-investigator-already-bungled-case](https://www.foxnews.com/us/sister-colorado-girl-who-went-missing-14-became-investigator-already-bungled-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:54:34+00:00

Beth Miller, 14, went for a run on Aug. 16, 1983, and never returned home. Her sister became an investigator in her case years later in an effort to find answers.

## Illinois Gov. JB Pritzker will announce a plan to give children access to mental health treatment
 - [https://www.foxnews.com/politics/illinois-gov-jb-pritzker-will-announce-plan-give-children-access-mental-health-treatment](https://www.foxnews.com/politics/illinois-gov-jb-pritzker-will-announce-plan-give-children-access-mental-health-treatment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:47:33+00:00

Illinois Gov. J.B. Pritzker will announce his plan to give residents, especially younger people, better access to mental health support.

## WA authorities have no plans to attempt to recover the bodies of 3 climbers killed in avalanche
 - [https://www.foxnews.com/us/wa-authorities-no-plans-attempt-recover-bodies-3-climbers-killed-avalanche](https://www.foxnews.com/us/wa-authorities-no-plans-attempt-recover-bodies-3-climbers-killed-avalanche)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:41:17+00:00

Three people died in an avalanche on Colchuck Peak in Washington. Authorities in the state have no plans of attempting to recover the bodies of the climbers.

## Bruce Arians reflects on Bucs' woes: 'It wasn’t the real Tom Brady out there'
 - [https://www.foxnews.com/sports/bruce-arians-reflects-bucs-woes-it-wasnt-real-tom-brady-out-there](https://www.foxnews.com/sports/bruce-arians-reflects-bucs-woes-it-wasnt-real-tom-brady-out-there)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:39:19+00:00

Former Tampa Bay Buccaneers head coach Bruce Arians said injurers to "key leaders" and Tom Brady's issues both on and off the field led to uncharacteristic season for the Bucs.

## 13 leaders of international gang MS-13 accused of directing criminal activities including murder
 - [https://www.foxnews.com/us/13-leaders-international-gang-ms-13-accused-directing-criminal-activities-including-murder](https://www.foxnews.com/us/13-leaders-international-gang-ms-13-accused-directing-criminal-activities-including-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:36:08+00:00

Over a dozen MS-13 members have been accused of directing criminal activity including murder in the United States, Mexico, EL Salvador, and other countries.

## Weather-beaten flotsam washes up on NY shoreline after tropical storm, some believe it's part of SS Savannah
 - [https://www.foxnews.com/us/weather-beaten-flotsam-washes-ny-shoreline-tropical-storm-some-believe-ss-savannah](https://www.foxnews.com/us/weather-beaten-flotsam-washes-ny-shoreline-tropical-storm-some-believe-ss-savannah)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:32:21+00:00

Experts believe a washed-up flotsam found along the New York shoreline belongs to the SS Savannah. The SS Savannah ran aground and broke apart in 1821.

## Biden prioritizing diversity when selecting next Fed Vice Chair sparks criticism: 'Sad & discriminatory'
 - [https://www.foxnews.com/media/biden-prioritizing-diversity-selecting-next-fed-vice-chair-sparks-criticism-sad-discriminatory](https://www.foxnews.com/media/biden-prioritizing-diversity-selecting-next-fed-vice-chair-sparks-criticism-sad-discriminatory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:30:47+00:00

White House press secretary Karine Jean-Pierre faced criticism Thursday after she said President Biden will prioritize diversity when selecting a Fed Vice Chair nominee.

## Growing number of states across the US looking into ways to curb the frequency of wrong-way accidents
 - [https://www.foxnews.com/us/growing-number-states-across-us-looking-ways-curb-frequency-wrong-way-accidents](https://www.foxnews.com/us/growing-number-states-across-us-looking-ways-curb-frequency-wrong-way-accidents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:27:54+00:00

More and more states are looking into ways to curb the frequency of wrong-way car accidents. The states are turning to new crash prevention technologies.

## Ukraine's Zelenskyy vows to 'defeat everyone' in remarks on 1-year mark of Russian invasion
 - [https://www.foxnews.com/world/ukraines-zelenskyy-vows-to-defeat-everyone-remarks-1-year-mark-russian-invasion](https://www.foxnews.com/world/ukraines-zelenskyy-vows-to-defeat-everyone-remarks-1-year-mark-russian-invasion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:06:34+00:00

Ukrainian President Volodymyr Zelenskyy delivered a 15-minute address on the one-year anniversary of Russia's invasion, calling it the "year of invincibility."

## Alec Baldwin sends message by skipping first court appearance in fatal 'Rust' shooting: legal expert
 - [https://www.foxnews.com/entertainment/alec-baldwin-sends-message-skipping-first-court-appearance-fatal-rust-shooting-legal-expert](https://www.foxnews.com/entertainment/alec-baldwin-sends-message-skipping-first-court-appearance-fatal-rust-shooting-legal-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:00:55+00:00

Alec Baldwin's choice to skip his first appearance in court sends a "signal" about the case, according to a legal expert. Baldwin faces charges of involuntary manslaughter.

## Ukraine war: One year later... and the years ahead
 - [https://www.foxnews.com/opinion/ukraine-war-one-year-later-and-the-years-ahead](https://www.foxnews.com/opinion/ukraine-war-one-year-later-and-the-years-ahead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:00:55+00:00

Russia and China want NATO, which protects the U.S. and our interests, gone and America out of Europe. The invasion of Ukraine was their biggest, boldest step toward that goal.

## China ramping up persecution of Christians as it demands 'worship and allegiance' of Xi Jinping: watchdog
 - [https://www.foxnews.com/world/china-ramping-up-persecution-christians-it-demands-worship-allegiance-xi-jinping-watchdog](https://www.foxnews.com/world/china-ramping-up-persecution-christians-it-demands-worship-allegiance-xi-jinping-watchdog)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:00:53+00:00

The Chinese government has been ramping up its persecution of Christians and house churches while also clamping down on Christianity online as it demands allegiance to Xi Jinping.

## Reporter's Notebook: Ukraine war one year on, human tragedies and triumphs
 - [https://www.foxnews.com/world/reporters-notebook-ukraine-war-one-year-on-human-tragedies-and-triumphs](https://www.foxnews.com/world/reporters-notebook-ukraine-war-one-year-on-human-tragedies-and-triumphs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:00:18+00:00

Senior Fox News foreign affairs correspondent Greg Palkot reviews a year of reporting from the frontlines of Russia's war against Ukraine.

## Zuckerberg-funded group violated Georgia law with $2M for elections board: watchdog
 - [https://www.foxnews.com/politics/zuckerberg-funded-group-violated-georgia-law-with-2m-for-elections-board-watchdog](https://www.foxnews.com/politics/zuckerberg-funded-group-violated-georgia-law-with-2m-for-elections-board-watchdog)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 13:00:03+00:00

An election integrity group is calling on Georgia election officials to investigate a donation from a Zuckerberg-linked group that they believe violates state law.

## Seattle kids forced to walk past junkies on their way to school: 'Living through America's slums'
 - [https://www.foxnews.com/media/seattle-kids-forced-walk-past-junkies-way-school-living-americas-slums](https://www.foxnews.com/media/seattle-kids-forced-walk-past-junkies-way-school-living-americas-slums)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:55:20+00:00

Discovery Institute journalist Jonathan Choe discusses Seattle’s rampant addiction problem and how drug addicts are shooting up outside schools on ‘Jesse Watters Primetime.’

## XFL owner Dwayne Johnson praises ex-NFL quarterback for taking ‘less money’ to ‘create memories’ for kids
 - [https://www.foxnews.com/sports/xfl-owner-dwayne-johnson-praises-ex-nfl-quarterback-taking-less-money-create-memories-kids](https://www.foxnews.com/sports/xfl-owner-dwayne-johnson-praises-ex-nfl-quarterback-taking-less-money-create-memories-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:35:15+00:00

Ex-NFL quarterback A. J. McCarron is off to strong start in his XFL debut and he received praise from owner Dwayne Johnson over his decision pursue a career in the XFL over the NFL.

## Non-profit organization vows to fight racial discrimination in workplace: 'There is no good form of racism'
 - [https://www.foxnews.com/media/non-profit-organization-vows-fight-racial-discrimination-workplace-no-good-form-racism](https://www.foxnews.com/media/non-profit-organization-vows-fight-racial-discrimination-workplace-no-good-form-racism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:30:55+00:00

President of the Equal Protection Project Bill Jacobson shares why his organization is dedicated to fighting racial discrimination in the workplace on 'Tucker Carlson Tonight.'

## CNN, MSNBC pan Trump grand jury foreperson’s media blitz after bolstering her profile with interviews
 - [https://www.foxnews.com/media/cnn-msnbc-pan-trump-grand-jury-forepersons-media-blitz-after-bolstering-profile-interviews](https://www.foxnews.com/media/cnn-msnbc-pan-trump-grand-jury-forepersons-media-blitz-after-bolstering-profile-interviews)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:29:49+00:00

After giving Trump grand jury forewoman Emily Kohrs airtime, members of CNN and MSNBC have panned her bizarre media blitz some say could jeopardize pending criminal charges.

## Pentagon sending Ukraine these weapons in $2B package on war's 1-year mark
 - [https://www.foxnews.com/politics/pentagon-sending-ukraine-these-weapons-2b-package-war-1-year-mark](https://www.foxnews.com/politics/pentagon-sending-ukraine-these-weapons-2b-package-war-1-year-mark)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:17:02+00:00

The Department of Defense announced Friday an additional $2 billion in military aid for Ukraine, pledging ammunition, defense systems, artillery and more.

## Casey DeSantis is rethinking 'Florida’s approach to combating cancer' after her own battle with the disease
 - [https://www.foxnews.com/politics/casey-desantis-rethinking-floridas-approach-combating-cancer-after-her-own-battle-disease](https://www.foxnews.com/politics/casey-desantis-rethinking-floridas-approach-combating-cancer-after-her-own-battle-disease)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:09:31+00:00

Casey DeSantis, wife to Florida Governor Ron DeSantis, launched the Cancer Connect Collaborative initiative to expand research and treatment for cancer.

## Buttigieg allies 'exasperated' by criticism over response to Ohio train disaster: Report
 - [https://www.foxnews.com/media/buttigieg-allies-exasperated-criticism-response-ohio-train-disaster-report](https://www.foxnews.com/media/buttigieg-allies-exasperated-criticism-response-ohio-train-disaster-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:00:52+00:00

A Politico report from Thursday claimed that Buttigieg and his allies have been growing "exasperated" with conservatives criticizing him over the train derailment.

## House China Committee lawmakers say sending delegations to Taiwan could 'improve the chances of peace'
 - [https://www.foxnews.com/politics/house-china-committee-lawmakers-sending-delegations-taiwan-improve-chances-peace](https://www.foxnews.com/politics/house-china-committee-lawmakers-sending-delegations-taiwan-improve-chances-peace)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:00:47+00:00

Bipartisan leadership of the House China Select Committee believe that sending congressional delegations to Taiwan could “improve the chances of peace” in the Taiwan Strait.

## Mom in liberal state urges parents to ditch public schools for homeschooling: 'Change the lives' of your kids
 - [https://www.foxnews.com/media/mom-liberal-state-urges-parents-ditch-public-schools-homeschooling-change-lives-kids](https://www.foxnews.com/media/mom-liberal-state-urges-parents-ditch-public-schools-homeschooling-change-lives-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:00:35+00:00

A Washington mom has joined the growing trend of parents homeschooling since the COVID-19 pandemic as Seattle considers closing some schools due to falling public school attendance.

## Periodic table quiz: How well do you know these scientific elements?
 - [https://www.foxnews.com/lifestyle/periodic-table-quiz-how-well-know-scientific-elements](https://www.foxnews.com/lifestyle/periodic-table-quiz-how-well-know-scientific-elements)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:00:33+00:00

Periodic table quiz! How well do you know these scientific facts about the table of elements? Test your science knowledge in this fun and engaging lifestyle quiz!

## Alex Murdaugh expected back on the stand Friday for grueling cross-examination
 - [https://www.foxnews.com/us/alex-murdaugh-expected-back-stand-friday-grueling-cross-examination](https://www.foxnews.com/us/alex-murdaugh-expected-back-stand-friday-grueling-cross-examination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 12:00:26+00:00

Disbarred South Carolina attorney Alex Murdaugh is expected back on the witness stand Thursday to endure several more hours of cross-examination in his double murder trial.

## Dem under fire for abortion comments, Ukraine 1 year later and more top headlines
 - [https://www.foxnews.com/us/dem-under-fire-for-abortion-comments-cop-killer-uses-last-words-to-trash-desantis-and-more-top-headlines](https://www.foxnews.com/us/dem-under-fire-for-abortion-comments-cop-killer-uses-last-words-to-trash-desantis-and-more-top-headlines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:51:17+00:00

Dem under fire for abortion comments, Ukraine 1 year later and more top headlines

## Member of MLB 3,000-hit club says ‘most’ players want to participate in ‘great’ World Baseball Classic
 - [https://www.foxnews.com/sports/member-mlb-3000-hit-club-says-most-players-want-participate-great-world-baseball-classic](https://www.foxnews.com/sports/member-mlb-3000-hit-club-says-most-players-want-participate-great-world-baseball-classic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:35:50+00:00

While the World Baseball Classic has not grown the popularity Major League Baseball wants, the players certainly feel the importance of it.

## Reporter says Buttigieg's team ran when she tried to ask for 'accountability'
 - [https://www.foxnews.com/media/reporter-says-buttigiegs-team-ran-tried-ask-accountability](https://www.foxnews.com/media/reporter-says-buttigiegs-team-ran-tried-ask-accountability)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:30:41+00:00

Turning Point USA reporter Savanah Hernandez shares what transpired when she tried to ask Transportation Secretary Pete Buttigieg questions on "The Ingraham Angle."

## Damian Lillard freestyles in Trail Blazers' music video after being stuck on plane for seven hours
 - [https://www.foxnews.com/sports/damian-lillard-freestyles-trail-blazers-music-video-stuck-plane-seven-hours](https://www.foxnews.com/sports/damian-lillard-freestyles-trail-blazers-music-video-stuck-plane-seven-hours)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:29:08+00:00

Portland Trail Blazers star guard Damian Lillard was star of the team's music video that was made as their airplane was stuck on the ground for hours

## Pink says Madonna ‘doesn't like’ her after ‘silly’ 'Regis and Kelly' meeting when she made 'fangirling' joke
 - [https://www.foxnews.com/entertainment/pink-says-madonna-doesnt-like-her-silly-regis-kelly-meeting-fangirling-joke](https://www.foxnews.com/entertainment/pink-says-madonna-doesnt-like-her-silly-regis-kelly-meeting-fangirling-joke)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:06:29+00:00

Pink said this week that Madonna, who she called an "inspiration" to her, "doesn't like" her. She said the two had a "silly" incident the first time they met in 2003.

## East Palestine residents suffer from Biden’s ‘America Last’ policies
 - [https://www.foxnews.com/opinion/east-palestine-residents-suffer-bidens-america-last-policies](https://www.foxnews.com/opinion/east-palestine-residents-suffer-bidens-america-last-policies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:00:52+00:00

East Palestine residents suffer from Biden’s ‘America Last’ policies. FEMA didn’t rush to their aid, but it’s a welcome wagon for illegal immigrants.

## Federal government internships paying $50K, $60K, even more for ‘student trainees’
 - [https://www.foxnews.com/politics/federal-government-internships-paying-50k-60k-even-more-student-trainees](https://www.foxnews.com/politics/federal-government-internships-paying-50k-60k-even-more-student-trainees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:00:48+00:00

The federal government is advertising top-tier internships with salaries as high as $50,000 and $60,000 and more, on par with the median U.S. income in late 2022.

## Nevada's Moonlite BunnyRanch: Sex, chaos, rock 'n' roll scandals over the years
 - [https://www.foxnews.com/us/nevadas-moonlite-bunnyranch-sex-chaos-rock-roll-scandals-years](https://www.foxnews.com/us/nevadas-moonlite-bunnyranch-sex-chaos-rock-roll-scandals-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:00:15+00:00

Nevada's Moonlite BunnyRanch brothel, formerly owned by Dennis Hof, has been rocked by tragedies and headline-grabbing incidents since its 1950s opening.

## Russia Ukraine war photo gallery: One year since the invasion
 - [https://www.foxnews.com/world/russia-ukraine-war-photo-gallery-one-year-since-the-invasion](https://www.foxnews.com/world/russia-ukraine-war-photo-gallery-one-year-since-the-invasion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:00:07+00:00

A look at some key moments of Russia's invasion of Ukraine on the first anniversary of the war. Russia's invasion began on February 24th, 2022.

## Mama Bears on free speech win over GA school district after ‘exposing highly sexualized pornographic books’
 - [https://www.foxnews.com/media/mama-bears-founder-winning-first-amendment-case-after-exposing-highly-sexualized-pornographic-books](https://www.foxnews.com/media/mama-bears-founder-winning-first-amendment-case-after-exposing-highly-sexualized-pornographic-books)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:00:06+00:00

A Georgia school district was forced to pay over $100,000 in legal fees after banning moms Alison Hair and Cindy Martin from exposing pornographic material at their school board meetings.

## Ukraine war wouldn’t take so long if Biden would commit to victory
 - [https://www.foxnews.com/opinion/ukraine-war-wouldnt-take-long-biden-would-commit-victory](https://www.foxnews.com/opinion/ukraine-war-wouldnt-take-long-biden-would-commit-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:00:05+00:00

Ukraine war wouldn’t take so long if Biden would commit to victory. Administration has been too slow getting critical weapon systems to the battlefield.

## Critics riff on Kamala after audience apparently neglects applause
 - [https://www.foxnews.com/media/critics-riff-kamala-audience-apparently-neglects-applause](https://www.foxnews.com/media/critics-riff-kamala-audience-apparently-neglects-applause)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 11:00:00+00:00

A "Hannity" panel riffed on Vice President Kamala Harris initially not receiving applause during an event with students from historically Black colleges and universities.

## Apparent editing error in 'Last of Us' TV show ripped by viewers: ‘HBO editors are always slacking’
 - [https://www.foxnews.com/media/apparent-editing-error-last-of-us-tv-show-ripped-viewers-hbo-editors-always-slacking](https://www.foxnews.com/media/apparent-editing-error-last-of-us-tv-show-ripped-viewers-hbo-editors-always-slacking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 10:54:57+00:00

HBO show "The Last of Us" is trending after TikTok users pointed out an apparent film gaffe in a recent episode, with some comparing it to another viral moment from 2019.

## Pakistani brothers released from Guantánamo Bay after 20 years in custody without charges
 - [https://www.foxnews.com/world/pakistani-brothers-released-guantanamo-bay-20-years-custody-without-charges](https://www.foxnews.com/world/pakistani-brothers-released-guantanamo-bay-20-years-custody-without-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 10:37:38+00:00

Two Pakistani brothers accused of helping al-Qaida members with low-level logistical support almost 20 years ago were released from Guantánamo Bay and sent back to their home country.

## Karine Jean-Pierre accused of 'Freudian slip' for calling Biden 'President Obama'
 - [https://www.foxnews.com/media/karine-jean-pierre-accused-freudian-slip-calling-biden-president-obama](https://www.foxnews.com/media/karine-jean-pierre-accused-freudian-slip-calling-biden-president-obama)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 10:30:24+00:00

White House Press Secretary Karine Jean-Pierre accidentally called President Biden "President Obama,” causing an eruption of humor among political commentators on Twitter.

## Ukrainian refugees speak out on anniversary of Russian invasion: 'Do not forget us'
 - [https://www.foxnews.com/world/ukrainian-refugees-speak-out-anniversary-russian-invasion-do-not-forget-us](https://www.foxnews.com/world/ukrainian-refugees-speak-out-anniversary-russian-invasion-do-not-forget-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 10:27:46+00:00

After Russia's invasion of Ukraine Fox News Digital spoke with a dozen Ukrainian refugees and civilians. One year later we have reached out to them to discuss their lives.

## M1 Abrams tanks Biden promised Ukraine may not be sent this year or next, defense official says
 - [https://www.foxnews.com/world/m1-abrams-tanks-biden-promised-ukraine-may-not-sent-year-defense-official](https://www.foxnews.com/world/m1-abrams-tanks-biden-promised-ukraine-may-not-sent-year-defense-official)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 10:12:35+00:00

Tanks that President Joe Biden promised to send to Ukraine's military are still in limbo as the war between Russia and Ukraine reached its one-year anniversary on Feb. 24.

## The world's best cars revealed and more autos stories
 - [https://www.foxnews.com/auto/worlds-best-cars-revealed-autos-stories](https://www.foxnews.com/auto/worlds-best-cars-revealed-autos-stories)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 10:02:56+00:00

The Fox News Autos newsletter brings you the latest developments in the world of cars, trucks, performance vehicles and collectible automobiles.

## New York Democrats in chaos with progressive left calling state party nearly as undemocratic as 'North Korea'
 - [https://www.foxnews.com/politics/new-york-democrats-chaos-progressive-left-compares-party-leadership-north-korea](https://www.foxnews.com/politics/new-york-democrats-chaos-progressive-left-compares-party-leadership-north-korea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 10:00:41+00:00

Some members of the New York Democratic Party are calling for new state leadership going into the next election cycle after the party underperformed in 2022 midterm elections.

## ChatGTP confession: Global warming? Not much since 2016
 - [https://www.foxnews.com/media/chatgtp-confession-global-warming-much-since-2016](https://www.foxnews.com/media/chatgtp-confession-global-warming-much-since-2016)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 10:00:27+00:00

The viral AI chatbot was grilled on its assertion that global temperatures have increased in recent years despite data from NOAA that suggests otherwise.

## Massachusetts Democrat told to step down after abortion comments leave parents irate
 - [https://www.foxnews.com/politics/massachusetts-democrat-told-step-down-abortion-comments-leave-parents-irate](https://www.foxnews.com/politics/massachusetts-democrat-told-step-down-abortion-comments-leave-parents-irate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 09:30:25+00:00

A local democratic official in Framingham, Massachusetts is under fire for comments made about babies born with disabilities who need access to special education.

## Asbury University student tells emotional story about regaining Christian faith amid revival: ‘I resented God’
 - [https://www.foxnews.com/media/asbury-university-student-emotional-story-regaining-christian-faith-revival-god](https://www.foxnews.com/media/asbury-university-student-emotional-story-regaining-christian-faith-revival-god)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 09:00:46+00:00

Asbury University senior student Gracie Turner says she found community and regained her lost faith during the two-week Christian revival in the heart of Kentucky.

## We need an 'Omelet Price Index' to show real pain caused by Biden inflation
 - [https://www.foxnews.com/opinion/we-need-omelet-price-index-show-real-pain-caused-biden-inflation](https://www.foxnews.com/opinion/we-need-omelet-price-index-show-real-pain-caused-biden-inflation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 09:00:12+00:00

We need an 'Omelet Price Index' to show real pain caused by Biden inflation. Reality of families’ financial struggles poorly measured by government economists.

## Country music icon Brad Paisley releases new song 'Same Here' featuring Ukraine President Zelenskyy
 - [https://www.foxnews.com/entertainment/country-music-icon-brad-paisley-releases-new-song-same-here-ukraine-president-zelenskyy](https://www.foxnews.com/entertainment/country-music-icon-brad-paisley-releases-new-song-same-here-ukraine-president-zelenskyy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 08:57:20+00:00

Country star Brad Paisley released a new song Friday called 'Same Here,' which compares life between Americans and Ukraines on the one-year of the Russian invasion.

## Beatles' Paul McCartney, Rolling Stones collaborate as surviving bandmates recapture glory days
 - [https://www.foxnews.com/entertainment/beatles-paul-mccartney-rolling-stones-collaborate-as-surviving-bandmates-recapture-glory-days](https://www.foxnews.com/entertainment/beatles-paul-mccartney-rolling-stones-collaborate-as-surviving-bandmates-recapture-glory-days)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 07:00:43+00:00

The Beatles' Paul McCartney laid down a bass track for the Rolling Stones' upcoming album. It marks a rare collaboration between members of the two legendary bands.

## Meet the American who created NASCAR: Bill France Sr., Daytona speed demon and racetrack pioneer
 - [https://www.foxnews.com/lifestyle/meet-american-who-created-nascar-daytona-bill-france-daytona-racetrack-pioneer](https://www.foxnews.com/lifestyle/meet-american-who-created-nascar-daytona-bill-france-daytona-racetrack-pioneer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 07:00:20+00:00

Bill France Sr., the American who created NASCAR, did so 75 years ago, on Feb. 21, 1948, in Daytona Beach, Florida — and today it's the world's premiere stock car racing circuit.

## New Florida law will help college athletes take their name and likeness to the bank
 - [https://www.foxnews.com/sports/new-florida-law-help-college-athletes-take-name-likeness-bank](https://www.foxnews.com/sports/new-florida-law-help-college-athletes-take-name-likeness-bank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 07:00:15+00:00

College athletes in Florida can now profit off of their name, image and likeness with the help of coaches and faculty after Gov. Ron DeSantis signed a new law.

## Biden’s weakness emboldened Putin’s Ukraine invasion. One year later, we’re more at risk
 - [https://www.foxnews.com/opinion/bidens-weakness-emboldened-putins-ukraine-invasion-one-year-later-were-more-risk](https://www.foxnews.com/opinion/bidens-weakness-emboldened-putins-ukraine-invasion-one-year-later-were-more-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 07:00:13+00:00

Biden’s weakness emboldened Putin’s Ukraine invasion. One year later, we’re more at risk with America leading from behind as the president sends piecemeal.

## Russia's war in Ukraine hits one-year mark as Putin digs in, Zelenskyy pushes victory. What’s next?
 - [https://www.foxnews.com/world/russias-war-ukraine-hits-one-year-mark-putin-digs-in-zelenskyy-pushes-victory-whats-next](https://www.foxnews.com/world/russias-war-ukraine-hits-one-year-mark-putin-digs-in-zelenskyy-pushes-victory-whats-next)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 07:00:02+00:00

It has been one year since Russia invaded Ukraine with no apparent end in sight and experts are divided on where the war will go from here and how it will end.

## Jansen Panettiere 'sounded okay' on phone with dad before he unexpectedly died: police report
 - [https://www.foxnews.com/entertainment/jansen-panettiere-sounded-okay-phone-dad-before-unexpectedly-died-police-report](https://www.foxnews.com/entertainment/jansen-panettiere-sounded-okay-phone-dad-before-unexpectedly-died-police-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 06:53:18+00:00

Orangetown police revealed more details in the sudden death of 28-year-old actor Jansen Panettiere who was found unresponsive at his Nyack, New York apartment on Feb. 19.

## Defending Heisman Trophy winner Caleb Williams reveals his 'No. 1' NFL destination
 - [https://www.foxnews.com/sports/defending-heisman-trophy-winner-caleb-williams-reveals-no-1-nfl-destination](https://www.foxnews.com/sports/defending-heisman-trophy-winner-caleb-williams-reveals-no-1-nfl-destination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 06:22:46+00:00

Caleb Williams is likely going to be the first pick in next year's NFL Draft, so it's unlikely that his "No. 1" choice to play for will actually land him.

## Florida death row inmate Donald Dillbeck uses last words to trash Gov. Ron DeSantis
 - [https://www.foxnews.com/us/florida-death-row-inmate-donald-dillbeck-last-words-gov-ron-desantis](https://www.foxnews.com/us/florida-death-row-inmate-donald-dillbeck-last-words-gov-ron-desantis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 06:15:07+00:00

Donald Dillbeck, a death row inmate and convicted cop killer, called out Republican Florida Gov. Ron DeSantis in his final moments before his execution.

## 76ers' James Harden sends generous gifts, FaceTimes MSU student paralyzed in shooting: 'I'm with you'
 - [https://www.foxnews.com/sports/76ers-james-harden-generous-gifts-facetimes-msu-student-paralyzed-shooting](https://www.foxnews.com/sports/76ers-james-harden-generous-gifts-facetimes-msu-student-paralyzed-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 05:49:41+00:00

Philadelphia 76ers guard James Harden caught wind that one of the students wounded in the Michigan State University shooting was a fan. He did all he could to brighten his day.

## Pennsylvania police officer arrested for allegedly buying cocaine: 'It is extremely disappointing'
 - [https://www.foxnews.com/us/pennsylvania-police-officer-arrested-allegedly-buying-cocaine-extremely-disappointing](https://www.foxnews.com/us/pennsylvania-police-officer-arrested-allegedly-buying-cocaine-extremely-disappointing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 05:19:12+00:00

A 28-year-old Harrisburg, Pennsylvania, police officer allegedly tried to buy cocaine before getting arrested by the Cumberland County Drug Task Force.

## UN ambassador says vote on 1 year anniversary of Russia's invasion 'will go down in history'
 - [https://www.foxnews.com/world/un-ambassador-says-vote-year-anniversary-russias-invasion-down-history](https://www.foxnews.com/world/un-ambassador-says-vote-year-anniversary-russias-invasion-down-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 05:11:12+00:00

United Nations Ambassador Linda Thomas-Greenfield said the vote on signaling the one-year anniversary of the Ukraine-Russia war will 'go down in history.'

## On this day in history, Feb. 24, 1914, Joshua L. Chamberlain dies, college professor turned Civil War hero
 - [https://www.foxnews.com/lifestyle/this-day-history-feb-24-1914-joshua-chamberlain-dies-professor-civil-war-hero](https://www.foxnews.com/lifestyle/this-day-history-feb-24-1914-joshua-chamberlain-dies-professor-civil-war-hero)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 05:02:02+00:00

Brig. Gen. Joshua Lawrence Chamberlain, a Bowdoin College professor who became one of the great heroes of the Civil War, died on this day in history, Feb. 24, 1914.

## LAURA INGRAHAM: How does America's chief salesman measure up?
 - [https://www.foxnews.com/media/laura-ingraham-does-americas-chief-salesman-measure-up](https://www.foxnews.com/media/laura-ingraham-does-americas-chief-salesman-measure-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 04:59:45+00:00

Laura Ingraham discusses how President Biden is a "poor salesman" for garnering support from other countries regarding the war in Ukraine on "The Ingraham Angle."

## SEAN HANNITY: Pothole Pete and his team didn't have much to offer
 - [https://www.foxnews.com/media/sean-hannity-pothole-pete-team-didnt-have-much-offer](https://www.foxnews.com/media/sean-hannity-pothole-pete-team-didnt-have-much-offer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 04:41:58+00:00

Fox News host Sean Hannity says Pete Buttigieg is deflecting criticism and refusing to take any responsibility for the train wreck response in Ohio on "Hannity."

## TUCKER CARLSON: There is no limit to the war in Ukraine
 - [https://www.foxnews.com/opinion/tucker-carlson-no-limit-war-ukraine](https://www.foxnews.com/opinion/tucker-carlson-no-limit-war-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 03:30:10+00:00

Fox News host Tucker Carlson reveals how many resources the Biden administration is actually giving to Ukraine on Thursday's "Tucker Carlson Tonight."

## Karine Jean-Pierre announces two more White House press office departures
 - [https://www.foxnews.com/politics/karine-jean-pierre-announces-two-more-white-house-press-office-departures](https://www.foxnews.com/politics/karine-jean-pierre-announces-two-more-white-house-press-office-departures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:57:19+00:00

White House Press Secretary Karine Jean-Pierre announced on Wednesday that two staffers are simultaneously departing the White House Press Office.

## Two-time Super Bowl winner Eli Manning reenacts iconic Odell Beckham catch with Hollywood star
 - [https://www.foxnews.com/sports/two-time-super-bowl-winner-eli-manning-reenacts-odell-beckham-catch-michael-b-jordan-hollywood-star](https://www.foxnews.com/sports/two-time-super-bowl-winner-eli-manning-reenacts-odell-beckham-catch-michael-b-jordan-hollywood-star)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:57:19+00:00

Actor Michael B. Jordan, with some help from former Giants quarterback Eli Manning, recreated one of the most memorable catches in the franchise's history.

## Fan punches soccer goalie during match; keeper wrestles him to ground before security steps in
 - [https://www.foxnews.com/sports/fan-punches-soccer-goalie-keeper-wrestles-him-before-security-steps-in](https://www.foxnews.com/sports/fan-punches-soccer-goalie-keeper-wrestles-him-before-security-steps-in)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:54:42+00:00

Marko Dmitrović of Sevilla FC was playing against PSV of the Netherlands when he was approached by a fan who punched him. He was quick to defend himself.

## Texas man who blamed elderly neighbor's killing on 'Lucifer' charged with murder
 - [https://www.foxnews.com/us/texas-man-blamed-elderly-neighbor-killing-lucifer-charged-murder](https://www.foxnews.com/us/texas-man-blamed-elderly-neighbor-killing-lucifer-charged-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:48:54+00:00

A man accused of murdering his elderly neighbor in Austin, Texas, reportedly told police that he blacked out and "Lucifer" actually killed the victim.

## Seattle high school teacher charged with having sexual relationship with 16-year-old student
 - [https://www.foxnews.com/us/seattle-high-school-teacher-charged-having-sexual-relationship-16-year-old-student](https://www.foxnews.com/us/seattle-high-school-teacher-charged-having-sexual-relationship-16-year-old-student)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:43:07+00:00

A Seattle high school science teacher arrested last week for allegedly having a sexual relationship with a student was formally charged in court on Wednesday.

## Arkansas firm identifies executives dead from plane crash
 - [https://www.foxnews.com/us/arkansas-firm-identifies-executives-dead-plane-crash](https://www.foxnews.com/us/arkansas-firm-identifies-executives-dead-plane-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:34:25+00:00

Arkansas environmental consulting firm CTEH identified the five people who died in a plane crash in Little Rock on Wednesday, some of whom were executives.

## Buttigieg blames Trump, Rubio amidst East Palestine derailment backlash: 'Now that it's campaign season'
 - [https://www.foxnews.com/media/buttigieg-blames-trump-rubio-amidst-east-palestine-derailment-backlash-campaign-season](https://www.foxnews.com/media/buttigieg-blames-trump-rubio-amidst-east-palestine-derailment-backlash-campaign-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:25:20+00:00

Transportation Secretary Pete Buttigieg defended his response to the East Palestine train derailment by attacking Republicans on MSNBC’s “The ReidOut” Thursday night.

## Philadelphia police say 7 shot near school yard, including 5 teens and 2-year-old
 - [https://www.foxnews.com/us/philadelphia-police-say-7-people-shot-school-yard-including-5-teens-2-year-old](https://www.foxnews.com/us/philadelphia-police-say-7-people-shot-school-yard-including-5-teens-2-year-old)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:16:06+00:00

Philadelphia Police Department officials say that seven people were shot on Thursday evening near a school yard, including five teenagers and a two-year-old.

## Six countries join Russia in opposing UN's resolution for peace in Ukraine
 - [https://www.foxnews.com/politics/six-countries-join-russia-opposing-uns-resolution-peace-ukraine](https://www.foxnews.com/politics/six-countries-join-russia-opposing-uns-resolution-peace-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:14:34+00:00

Belarus, North Korea, Syria, Eritrea, Mali and Nicaragua all voted aside Russia in opposing the United Nations General Assembly's resolution endorsing peace in Ukraine.

## JESSE WATTERS: How did Pete Buttigieg screw this job up?
 - [https://www.foxnews.com/media/jesse-watters-pete-buttigieg-screw-job-up](https://www.foxnews.com/media/jesse-watters-pete-buttigieg-screw-job-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 02:11:14+00:00

Fox News host Jesse Watters gives his take on Pete Buttigieg's visit to East Palestine, Ohio on 'Jesse Watters Primetime.'

## Orlando FreeFall: Ride maker performs 'final inspection' on Florida attraction after Missouri teen's death
 - [https://www.foxnews.com/us/orlando-freefall-ride-maker-performs-final-inspection-florida-attraction-missouri-teens-death](https://www.foxnews.com/us/orlando-freefall-ride-maker-performs-final-inspection-florida-attraction-missouri-teens-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:54:57+00:00

The maker of the Orlando FreeFall, the ride where 14-year-old Tyre Sampson died after falling off on March 24, 2022, had a "final inspection" on Thursday.

## Austin City Council passes temporary ordinance to fund police after contract negotiations break down
 - [https://www.foxnews.com/us/austin-city-council-passes-temporary-ordinance-fund-police-contract-negotiations-break-down](https://www.foxnews.com/us/austin-city-council-passes-temporary-ordinance-fund-police-contract-negotiations-break-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:54:13+00:00

Austin passed a temporary ordinance guaranteeing pay for police on Thursday after contract negotiations for a long term deal broke down with the union earlier this month.

## Khloe Kardashian's ex-household assistant suing for unpaid wages, says he was 'wrongfully' fired after injury
 - [https://www.foxnews.com/entertainment/khloe-kardashians-ex-household-assistant-suing-unpaid-wages-says-wrongfully-fired-injury](https://www.foxnews.com/entertainment/khloe-kardashians-ex-household-assistant-suing-unpaid-wages-says-wrongfully-fired-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:47:42+00:00

A former household assistant of Khloe Kardashian is suing for unpaid wages, claiming the star violated California labor laws by not paying overtime or allowing him rest and meal breaks.

## White House pushes higher rail company fines after Ohio visit
 - [https://www.foxnews.com/politics/white-house-pushes-higher-rail-company-fines-ohio-visit](https://www.foxnews.com/politics/white-house-pushes-higher-rail-company-fines-ohio-visit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:40:58+00:00

The Biden administration is demanding congressional Republicans pass legislation increasing fines for rail safety violations following the catastrophic crash in East Palestine, Ohio.

## Rams, Bobby Wagner part ways one year after signing $50M deal: report
 - [https://www.foxnews.com/sports/rams-bobby-wagner-part-ways-one-year-signing-50m-deal-report](https://www.foxnews.com/sports/rams-bobby-wagner-part-ways-one-year-signing-50m-deal-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:38:15+00:00

Veteran linebacker Bobby Wagner is back on the free agent market just one year after agreeing to a five-year, $50 million deal with the Los Angeles Rams.

## California business burglarized days before its grand opening — just two blocks from City Hall
 - [https://www.foxnews.com/us/california-business-burglarized-days-grand-opening-two-blocks-city-hall](https://www.foxnews.com/us/california-business-burglarized-days-grand-opening-two-blocks-city-hall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:35:14+00:00

The Suit Lounge, a new business in Oakland, was burglarized by two thieves who stole 75% of its merchandise before it even opened, according to owner Kevin Greene.

## Protect your phone: Steps to take if your device is lost, stolen, or broken
 - [https://www.foxnews.com/tech/protect-your-phone-steps-take-your-device-lost-stolen-broken](https://www.foxnews.com/tech/protect-your-phone-steps-take-your-device-lost-stolen-broken)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:28:34+00:00

Simple and easy steps to ensure your smart phone's security in the event it gets lost, stolen, or damaged.

## Kansas Legislature likely to eliminate 3-day 'grace period' for mail-in ballots
 - [https://www.foxnews.com/politics/kansas-legislature-likely-eliminate-3-day-grace-period-mail-ballots](https://www.foxnews.com/politics/kansas-legislature-likely-eliminate-3-day-grace-period-mail-ballots)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:27:10+00:00

Kansas' Republican-dominated Legislature is likely to pass a bill that would eliminate the three-day "grace period" the state allows for mail-in ballots after elections.

## Meghan McCain torches Joy Behar for ‘cruelty and elitism’ toward East Palestine residents
 - [https://www.foxnews.com/media/meghan-mccain-torches-joy-behar-cruelty-elitism-train-victims-east-palestine-residents](https://www.foxnews.com/media/meghan-mccain-torches-joy-behar-cruelty-elitism-train-victims-east-palestine-residents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:23:06+00:00

Meghan McCain slammed her former co-host Joy Behar for victim-blaming citizens of East Palestine, Ohio, following former President Trump's visit.

## Judge Jeanine dissects Alex Murdaugh's testimony in double murder trial: 'What he's doing there is brilliant'
 - [https://www.foxnews.com/media/judge-jeanine-dissects-alex-murdaughs-testimony-double-murder-trial-what-hes-doing-brilliant](https://www.foxnews.com/media/judge-jeanine-dissects-alex-murdaughs-testimony-double-murder-trial-what-hes-doing-brilliant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:23:04+00:00

'The Five' co-hosts react to the explosive testimony from disgraced South Carolina lawyer Alex Murdaugh and his claims he did not 'intentionally' kill his wife and son.

## Kansas House passes bill that would require birth names, biological sex on ID
 - [https://www.foxnews.com/politics/kansas-house-passes-bill-would-require-birth-names-biological-sex-id](https://www.foxnews.com/politics/kansas-house-passes-bill-would-require-birth-names-biological-sex-id)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:17:58+00:00

The Kansas House has passed a bill that would ban sex-change procedures for minors and require individuals to use their birth name and biological sex on government ID.

## Morgan Wallen’s ex KT Smith shares facial injuries after she's involved in car crash: ‘Thankful to be alive’
 - [https://www.foxnews.com/entertainment/morgan-wallen-ex-kt-smith-shares-facial-injuries-involved-car-crash](https://www.foxnews.com/entertainment/morgan-wallen-ex-kt-smith-shares-facial-injuries-involved-car-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:17:32+00:00

Morgan Wallen's ex and mother to his child, influencer KT Smith, was in a bad car crash in Nashville on Wednesday night.

## Mom of woman allegedly killed by ex-Alabama player says it's 'unimaginable' Brandon Miller continues to play
 - [https://www.foxnews.com/sports/mother-woman-killed-former-alabama-player-says-its-unimaginable-brandon-miller-continues-to-play](https://www.foxnews.com/sports/mother-woman-killed-former-alabama-player-says-its-unimaginable-brandon-miller-continues-to-play)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:08:24+00:00

Brandon Miller continues to play for the Alabama Crimson Tide despite being linked to the shooting death of a woman last month. Miller has not been charged.

## German mayor reaches agreement with road-blocking climate protestors
 - [https://www.foxnews.com/world/german-mayor-reaches-agreement-road-blocking-climate-protestors](https://www.foxnews.com/world/german-mayor-reaches-agreement-road-blocking-climate-protestors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:04:46+00:00

Mayor Belit Onay of Hannover, Germany, brokered a deal to end climate activists roadblocks in exchange for agreeing to several of their demands.

## New Jersey shore town fined $12M for building own dunes
 - [https://www.foxnews.com/us/new-jersey-shore-town-fined-12m-building-own-dunes](https://www.foxnews.com/us/new-jersey-shore-town-fined-12m-building-own-dunes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:01:32+00:00

North Wildwood, New Jersey, was fined $12 million by the state Department of Environmental Protection for several unauthorized beachfront constructions.

## Alabama bill proposed to change 'good time' law named for slain deputy
 - [https://www.foxnews.com/us/alabama-bill-proposed-change-good-time-law-named-slain-deputy](https://www.foxnews.com/us/alabama-bill-proposed-change-good-time-law-named-slain-deputy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 01:00:27+00:00

An Alabama bill was proposed that will cut the amount of time that inmates can shave off their sentences. The bill also states that under certain circumstances inmates can lose their credit.

## DC mayor blames 'social media challenge' for carjackings, offers free steering wheel locks for some vehicles
 - [https://www.foxnews.com/politics/dc-mayor-blames-social-media-challenge-carjackings-offers-free-steering-wheel-locks-some-vehicles](https://www.foxnews.com/politics/dc-mayor-blames-social-media-challenge-carjackings-offers-free-steering-wheel-locks-some-vehicles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:55:20+00:00

Washington, D.C. Mayor Muriel Bowser announced on Thursday that the city will be handing out free steering wheel locks for certain cars.

## Bruins land Dmitry Orlov, Garnet Hathaway in blockbuster trade with Capitals
 - [https://www.foxnews.com/sports/bruins-land-dmitry-orlov-garnet-hathaway-blockbuster-trade-capitals](https://www.foxnews.com/sports/bruins-land-dmitry-orlov-garnet-hathaway-blockbuster-trade-capitals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:45:58+00:00

The Boston Bruins are the NHL's best team in the standings, and their front office is all in after its blockbuster trade with the Washington Capitals.

## Illinois worker dies after becoming trapped in flooded underground vault
 - [https://www.foxnews.com/us/illinois-worker-dies-becoming-trapped-flooded-underground-vault](https://www.foxnews.com/us/illinois-worker-dies-becoming-trapped-flooded-underground-vault)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:43:59+00:00

A Chicago-area public employee died Thursday while trying to repair a pipe break when a hole he was in flooded

## Israel to build 7,000 new settlements in West Bank
 - [https://www.foxnews.com/world/israel-build-7000-new-settlements-west-bank](https://www.foxnews.com/world/israel-build-7000-new-settlements-west-bank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:42:58+00:00

The Israeli government has given its approval to 7,000 new home constructions in Jewish settlements in the West Bank, defying the objections of many international critics.

## George Santos cosponsors bill to make AR-15 the National Gun of the US
 - [https://www.foxnews.com/politics/george-santos-cosponsors-bill-make-ar-15-national-gun-us](https://www.foxnews.com/politics/george-santos-cosponsors-bill-make-ar-15-national-gun-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:39:33+00:00

Rep. George Santos is co-sponsoring a bill to make the AR-15 the National Gun of the United States.

## Photos of ex-Biden official wearing dress designer alleges was stolen spotted in Vanity Fair 'style' feature
 - [https://www.foxnews.com/media/photos-ex-biden-official-wearing-dress-designer-alleges-stolen-spotted-vanity-fair-style-feature](https://www.foxnews.com/media/photos-ex-biden-official-wearing-dress-designer-alleges-stolen-spotted-vanity-fair-style-feature)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:34:33+00:00

Vanity Fair published an article in 2022 featuring former Biden energy official Sam Brinton wearing a dress one fashion designer said was stolen from her luggage.

## North Korea test fires four cruise missiles to demonstrate 'nuclear combat force,' state media claims
 - [https://www.foxnews.com/world/north-korea-test-fires-four-cruise-missiles-demonstrate-nuclear-combat-force-state-media-claims](https://www.foxnews.com/world/north-korea-test-fires-four-cruise-missiles-demonstrate-nuclear-combat-force-state-media-claims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:34:00+00:00

North Korean state media said that the hermit kingdom test fired four strategic cruise missiles off its eastern coast on Friday to demonstrate its "nuclear combat force."

## North Korea says it test-fired long-range cruise missiles
 - [https://www.foxnews.com/world/north-korea-says-it-test-fired-long-range-cruise-missiles](https://www.foxnews.com/world/north-korea-says-it-test-fired-long-range-cruise-missiles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:32:34+00:00

North Korea has test-fired long-range cruise missiles off their eastern coastal waters. The launches come in the wake of joint US-South Korean military maneuvers.

## South Carolina 'Chucky' inspired kindergartner brings knife to school, threatens to kill classmates: Sheriff
 - [https://www.foxnews.com/us/south-carolina-chucky-inspired-kindergartner-brings-knife-school-threatens-kill-classmates-sheriff](https://www.foxnews.com/us/south-carolina-chucky-inspired-kindergartner-brings-knife-school-threatens-kill-classmates-sheriff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:31:40+00:00

A kindergartner in South Carolina allegedly brought a knife to school on Wednesday and threatened to kill his classmates and teacher, stating he was inspired by the movie "Chucky."

## California bakery reopens after owner was killed in violent Oakland robbery
 - [https://www.foxnews.com/us/california-bakery-reopens-after-owner-killed-violent-oakland-robbery](https://www.foxnews.com/us/california-bakery-reopens-after-owner-killed-violent-oakland-robbery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:31:10+00:00

California bakery Angel Cakes opened its door to customers on Wednesday, weeks after its owner Jen Angel was killed during a robbery in downtown Oakland amid the city's crime crisis.

## Jihadist NYC bike path killer's father, uncle express shame, unload on ISIS at death penalty trial
 - [https://www.foxnews.com/us/jihadist-nyc-bike-path-killers-father-uncle-express-shame-unload-isis-death-penalty-trial](https://www.foxnews.com/us/jihadist-nyc-bike-path-killers-father-uncle-express-shame-unload-isis-death-penalty-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:28:53+00:00

Relatives of Sayfullo Saipov, an ISIS sympathizer who in 2017 killed eight people in New York, testified at his sentencing hearing, where he is facing the possibility of the death penalty.

## New York City thief in Amazon Prime jacket caught on camera in $500K jewelry heist
 - [https://www.foxnews.com/us/new-york-city-thief-amazon-prime-jacket-caught-camera-500k-jewelry-heist](https://www.foxnews.com/us/new-york-city-thief-amazon-prime-jacket-caught-camera-500k-jewelry-heist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:23:43+00:00

New York City police are searching for two men, one was wearing an Amazon Prime jacket, who stole around $500,000 in jewelry from a Queens location during a violent armed robbery.

## China edges closer to sending lethal aid to Russia as UN votes to condemn invasion of Ukraine: report
 - [https://www.foxnews.com/world/china-edges-closer-sending-lethal-aid-russia-un-votes-condemn-invasion-ukraine-report](https://www.foxnews.com/world/china-edges-closer-sending-lethal-aid-russia-un-votes-condemn-invasion-ukraine-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:14:33+00:00

Russia is in talks with China to purchase combat drones for use against Ukraine, according to a report published after the US said it had evidence such a move was being considered.

## Puerto Rican Miss Universe pageant announces first transgender participant
 - [https://www.foxnews.com/us/puerto-rican-miss-universe-pageant-announces-first-transgender-participant](https://www.foxnews.com/us/puerto-rican-miss-universe-pageant-announces-first-transgender-participant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:12:14+00:00

Puerto Rico's Miss Universe pageant will feature contestant Daniela Arroyo González, a prominent activist and the island territory's first transgender competitor.

## What Richard Belzer 'taught' Mariska Hargitay: ‘It was such a privilege to know him’
 - [https://www.foxnews.com/entertainment/what-richard-belzer-taught-mariska-hargitay](https://www.foxnews.com/entertainment/what-richard-belzer-taught-mariska-hargitay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:11:37+00:00

Mariska Hargitay spoke about her special friendship with former "Law & Order: SVU" co-star and late comedian Richard Belzer, calling him "a beautiful and complex" person.

## Karine Jean-Pierre defends Buttigieg by invoking Elaine Chao, mistakenly calls her head of the EPA
 - [https://www.foxnews.com/media/karine-jean-pierre-defends-buttigieg-invoking-elaine-chao-mistakenly-calls-head-epa](https://www.foxnews.com/media/karine-jean-pierre-defends-buttigieg-invoking-elaine-chao-mistakenly-calls-head-epa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:06:25+00:00

White House press secretary Karine Jean-Pierre accidentally referred to Elaine Chao as the former head of the EPA while defending Pete Buttigieg Thursday.

## Texas man charged in 4-month-old' death, pregnant woman's assault
 - [https://www.foxnews.com/us/texas-man-charged-4-month-old-death-pregnant-womans-assault](https://www.foxnews.com/us/texas-man-charged-4-month-old-death-pregnant-womans-assault)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-24 00:03:22+00:00

A Texas man was arrested last week for his alleged connection to a 4-month-old infant's death, and he was charged with causing serious bodily injury to a child.

