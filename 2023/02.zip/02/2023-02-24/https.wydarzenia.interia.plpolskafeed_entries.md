# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Ucieczka pod czerwonym niebem
 - [https://wydarzenia.interia.pl/kraj/news-ucieczka-pod-czerwonym-niebem,nId,6613672](https://wydarzenia.interia.pl/kraj/news-ucieczka-pod-czerwonym-niebem,nId,6613672)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-02-24 14:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ucieczka-pod-czerwonym-niebem,nId,6613672"><img align="left" alt="Ucieczka pod czerwonym niebem" src="https://i.iplsc.com/ucieczka-pod-czerwonym-niebem/000GT3DT8J1JMHLL-C321.jpg" /></a>Ze swoich domów wychodzili z myślą: &quot;wrócimy za kilka dni&quot;. Tymczasem mija rok od wybuchu wojny. Jeden drugiego zobaczył na stołówce. &quot;Wołodymyr, tse ty?&quot;. Oleksandr nie mógł uwierzyć - co tu robi Wołodymyr, sąsiad z tego samego bloku? Przecież ten blok był prawie tysiąc kilometrów od stołówki, w której się zobaczyli. Rzucili się sobie w objęcia. Dom zamienił się w gruzy, ale oni są, żyją. Stali, patrzyli na siebie i nie wierzyli. To Wołodymyr. Sąsiad.
</p><br clear="all" />

## Jechał tirem i miał ponad dwa promile alkoholu. Policja zatrzymała kierowcę
 - [https://wydarzenia.interia.pl/kraj/video,vId,3297586](https://wydarzenia.interia.pl/kraj/video,vId,3297586)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-02-24 12:38:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/video,vId,3297586"><img align="left" alt="Jechał tirem i miał ponad dwa promile alkoholu. Policja zatrzymała kierowcę" src="https://i.iplsc.com/jechal-tirem-i-mial-ponad-dwa-promile-alkoholu-policja-zatrz/000GT1OOGA19BQTV-C321.jpg" /></a>Dzięki zgłoszeniu na policję, zatrzymano pijanego kierowcę tira. Mężczyzna miał w organizmie ponad 2 promile alkoholu. Za jazdę w stanie nietrzeźwości kierowca usłyszy zarzuty. Grozi mu kara do dwóch lat pozbawienia wolności.</p><br clear="all" />

## Prezydent po RBN: Rozmawiałem z Joe Bidenem o wspólnej produkcji amunicji
 - [https://wydarzenia.interia.pl/kraj/news-prezydent-po-rbn-rozmawialem-z-joe-bidenem-o-wspolnej-produk,nId,6617635](https://wydarzenia.interia.pl/kraj/news-prezydent-po-rbn-rozmawialem-z-joe-bidenem-o-wspolnej-produk,nId,6617635)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-02-24 11:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydent-po-rbn-rozmawialem-z-joe-bidenem-o-wspolnej-produk,nId,6617635"><img align="left" alt="Prezydent po RBN: Rozmawiałem z Joe Bidenem o wspólnej produkcji amunicji" src="https://i.iplsc.com/prezydent-po-rbn-rozmawialem-z-joe-bidenem-o-wspolnej-produk/000GT1EX05NUC7W1-C321.jpg" /></a>Rozmawiałem z prezydentem Joe Bidenem o rozpoczęciu wspólnej produkcji amunicji - powiedział po posiedzeniu Rady Bezpieczeństwa Narodowego prezydent Andrzej Duda.
Przedmiotem spotkania była aktualna sytuacja bezpieczeństwa w kraju w związku z rosyjską inwazją na Ukrainę, a także wizyta prezydenta USA Joe Bidena w Polsce i spotkanie Bukaresztańskiej Dziewiątki. </p><br clear="all" />

## Wschodnia flanka NATO. Potencjał, który broni naszego terytorium
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wschodnia-flanka-nato-potencjal-ktory-broni-naszego-terytori,nId,6615614](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wschodnia-flanka-nato-potencjal-ktory-broni-naszego-terytori,nId,6615614)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-02-24 07:29:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wschodnia-flanka-nato-potencjal-ktory-broni-naszego-terytori,nId,6615614"><img align="left" alt="Wschodnia flanka NATO. Potencjał, który broni naszego terytorium" src="https://i.iplsc.com/wschodnia-flanka-nato-potencjal-ktory-broni-naszego-terytori/000GSXXEFV3V3V40-C321.jpg" /></a>Po roku od wybuchu wojny w Ukrainie wschodnia flanka NATO zmieniła się nie do poznania. Niemal wszystkie jej państwa poszły na bezprecedensowe zakupy i modernizują własne siły zbrojne. Liderem jest Polska, ale pozostali chcą dotrzymać nam kroku. Jednocześnie zwiększyła się obecność wojsk sojuszniczych w regionie. Sprawdzamy, co agresja Rosji na Ukrainę zmieniła w kwestii potencjału wschodniej flanki NATO. </p><br clear="all" />

