# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Biden Admin Proposes New Rules That Would Make It Harder For Americans To Get Certain Medications
 - [https://www.dailywire.com/news/biden-admin-proposes-new-rules-that-would-make-it-harder-for-americans-to-get-certain-medications](https://www.dailywire.com/news/biden-admin-proposes-new-rules-that-would-make-it-harder-for-americans-to-get-certain-medications)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 22:20:43+00:00

President Joe Biden&#8217;s administration is proposing implementing greater restrictions that would make it harder for Americans to get certain medications. The proposal from the DEA would make it harder for Americans to get Adderall and opioid pain killers if the patient is trying to get on those medications through the use of telehealth services, which ...

## Tim Pool Praises Matt Walsh For The Attention He’s Brought To The Transgender Issue
 - [https://www.dailywire.com/news/tim-pool-praises-matt-walsh-for-the-attention-hes-brought-to-the-transgender-issue](https://www.dailywire.com/news/tim-pool-praises-matt-walsh-for-the-attention-hes-brought-to-the-transgender-issue)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 21:56:40+00:00

YouTuber Tim Pool praised Daily Wire podcast host Matt Walsh on Friday for the good that has come from Walsh bringing attention to the subject of leftists trying to force transgenderism on America&#8217;s youth. &#8220;All these people are talking to Matt Walsh, saying, &#8216;You shouldn&#8217;t be mean to people and blah, blah,&#8217; and Matt&#8217;s like, ...

## Leftists Promise To Rewrite The Classic Works Of Roald Dahl As They Redesign Western Culture
 - [https://www.dailywire.com/news/leftists-promise-to-rewrite-the-classic-works-of-roald-dahl-as-they-redesign-western-culture](https://www.dailywire.com/news/leftists-promise-to-rewrite-the-classic-works-of-roald-dahl-as-they-redesign-western-culture)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 21:03:52+00:00

The following is the opening satirical monologue from “The Andrew Klavan Show.“ The bestselling children’s books by the late, great British novelist Roald Dahl are being rewritten by a concerned group of crap-faced cultural locusts with no sense of humor so they will no longer be offensive to crap-faced cultural locusts with no sense of ...

## Chinese Fighter Jet Harasses U.S. Navy Plane With CNN Camera Crew Inside
 - [https://www.dailywire.com/news/chinese-fighter-jet-harasses-u-s-navy-plane-with-cnn-camera-crew-inside](https://www.dailywire.com/news/chinese-fighter-jet-harasses-u-s-navy-plane-with-cnn-camera-crew-inside)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 20:48:21+00:00

A CNN camera crew that was on a U.S. Navy plane over the South China Sea on Friday captured a fighter jet from communist China harassing the aircraft while it made a routine flight. The U.S. Navy P-8A reconnaissance plane was flying at 21,500 feet about 30 miles from the contested Paracel Islands where China ...

## Senator Fetterman’s Wife Slammed For ‘Abandoning Her Husband In The Hospital And Fleeing The Country On Vacation’
 - [https://www.dailywire.com/news/senator-fettermans-wife-slammed-for-abandoning-her-husband-in-the-hospital-and-fleeing-the-country-on-vacation](https://www.dailywire.com/news/senator-fettermans-wife-slammed-for-abandoning-her-husband-in-the-hospital-and-fleeing-the-country-on-vacation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 20:13:14+00:00

Sen. John Fetterman&#8217;s (D-PA) wife was slammed on social media Friday after she revealed that the first thing she did after her husband was hospitalized with severe depression was flee the country to go on a vacation. Fetterman checked himself into a hospital last week for a multi-week inpatient treatment regimen after the attending physician ...

## Publisher Walks Back Woke Rewrites Of Roald Dahl’s Classic Stories, Will Release Original Text As Well
 - [https://www.dailywire.com/news/publisher-walks-back-woke-rewrites-of-roald-dahls-classic-stories-will-release-original-text-as-well](https://www.dailywire.com/news/publisher-walks-back-woke-rewrites-of-roald-dahls-classic-stories-will-release-original-text-as-well)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 19:23:24+00:00

Book publisher Puffin has announced a walkback of its woke rewrites of Roald Dahl&#8217;s classic children&#8217;s books after backlash. Earlier this week, the Roald Dahl Story Company, which manages the works of the British author, announced changes to his classic children&#8217;s stories, including “Charlie and the Chocolate Factory,” “Matilda,” “James and the Giant Peach,” and ...

## Kansas Senate Passes First Bill Defining ‘Woman’ As A Biological Female
 - [https://www.dailywire.com/news/kansas-senate-passes-first-bill-defining-woman-as-a-biological-female](https://www.dailywire.com/news/kansas-senate-passes-first-bill-defining-woman-as-a-biological-female)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 19:23:05+00:00

In a groundbreaking move, Kansas has become the first state to pass a bill that defines a &#8220;woman&#8221; as someone who is biologically born female, laying the groundwork for potential bans on males who identify as transgender women from using single-sex areas designated for females. The Women&#8217;s Bill of Rights was approved by legislators in ...

## Biden Will Not Visit East Palestine Following Train Catastrophe
 - [https://www.dailywire.com/news/biden-will-not-visit-east-palestine-following-train-catastrophe](https://www.dailywire.com/news/biden-will-not-visit-east-palestine-following-train-catastrophe)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 18:04:39+00:00

President Joe Biden told reporters Friday that he has no plans to visit East Palestine after the community experienced a serious toxic train wreck earlier this month. The catastrophic February 3 train derailment in the small Ohio community was caused by an overheated wheel bearing on the 23rd of 149 rail cars. Local officials subsequently ...

## Friday Afternoon Update: Aaron Rodgers Ends Darkness Retreat, Harvey Weinstein Sentenced, Air Fryer Recall
 - [https://www.dailywire.com/news/friday-afternoon-update-aaron-rodgers-ends-darkness-retreat-harvey-weinstein-sentenced-air-fryer-recall](https://www.dailywire.com/news/friday-afternoon-update-aaron-rodgers-ends-darkness-retreat-harvey-weinstein-sentenced-air-fryer-recall)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 17:31:12+00:00

This article is a companion piece to today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. Harvey Weinstein Sentenced A Los Angeles judge sentenced Harvey Weinstein to 16 years in prison on Thursday after a jury convicted him of the 2013 rape and sexual assault of an Italian actor and model. The ...

## Transsexuals Pen Letter Asking U.S.-Based Medical Organizations To Reject Ideology In Favor Of Evidence
 - [https://www.dailywire.com/news/transsexuals-pen-letter-asking-u-s-based-medical-organizations-to-reject-ideology-in-favor-of-evidence](https://www.dailywire.com/news/transsexuals-pen-letter-asking-u-s-based-medical-organizations-to-reject-ideology-in-favor-of-evidence)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 17:20:15+00:00

Transsexuals want to reclaim the narrative on gender dysphoria as a meaningful diagnosis from radical transgender activists who wish to eradicate it and other so-called &#8220;barriers&#8221; to sex change services. In an open letter to 29 major medical organizations based in the U.S., a group of transsexuals (a term they prefer) belonging to the Gender ...

## BREAKING: Class-Action Lawsuit Filed By Residents Against Norfolk Southern
 - [https://www.dailywire.com/news/breaking-class-action-lawsuit-filed-by-residents-against-norfolk-southern](https://www.dailywire.com/news/breaking-class-action-lawsuit-filed-by-residents-against-norfolk-southern)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 17:14:22+00:00

A class-action lawsuit has been filed against the Norfolk Southern Railway Co. on behalf of all residents within 30 miles of the site in East Palestine, Ohio, where a train derailment occurred earlier this month, prompting a &#8220;controlled burn&#8221; of thousands of gallons of toxic chemicals. Johnson and Johnson has joined with class-action law firm ...

## Convicted Murderer Uses His Last Words Before Execution To Attack DeSantis; Victim’s Children Release Statement
 - [https://www.dailywire.com/news/convicted-murderer-uses-his-last-words-before-execution-to-attack-desantis-victims-children-release-statement](https://www.dailywire.com/news/convicted-murderer-uses-his-last-words-before-execution-to-attack-desantis-victims-children-release-statement)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 16:54:36+00:00

A convicted murderer who was executed in the state of Florida on Thursday used his final words to attack Florida Republican Governor Ron DeSantis while the family of the victim praised the governor for delivering justice. Donald Dillbeck murdered Faye Lamb Vann in 1990 after escaping from a work-release job in Gadsden County where he ...

## ‘Ant-Man And The Wasp: Quantumania’ Can’t Hide Disney’s Fake Populism
 - [https://www.dailywire.com/news/ant-man-and-the-wasp-quantumania-cant-hide-disneys-fake-populism](https://www.dailywire.com/news/ant-man-and-the-wasp-quantumania-cant-hide-disneys-fake-populism)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 16:49:39+00:00

Audiences are getting fed up with the Marvel Cinematic Universe’s woke makeover. The saga that once gave us Iron Man, Captain America, and the Hulk now pummels viewers with uber-diverse casts, woke lectures, and stories that put ideology over escapism. Did anyone actually like “Eternals?” The new “Ant-Man and the Wasp: Quantumania” continues that new ...

## Rihanna’s Super Bowl Performance Compared To Pornography In FCC Complaints About Broadcast
 - [https://www.dailywire.com/news/rihannas-super-bowl-performance-compared-to-pornography-in-fcc-complaints-about-broadcast](https://www.dailywire.com/news/rihannas-super-bowl-performance-compared-to-pornography-in-fcc-complaints-about-broadcast)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 16:47:28+00:00

Rihanna&#8217;s half-time performance at Super Bowl LVII has been compared to pornography and more in over 100 FCC complaints about the broadcast on February 12 in Arizona. The 35-year-old singer&#8217;s Super Bowl performance was labeled &#8220;indecent&#8221; and &#8220;pornographic&#8221; in the dozens of complaints to the Federal Communications Commission that were reviewed by TMZ, the outlet reported on ...

## ‘He’s Not Finished What He’s Started’: Jill Biden Says Joe Biden Is Ready To Run Again
 - [https://www.dailywire.com/news/hes-not-finished-what-hes-started-jill-biden-says-joe-biden-is-ready-to-run-again](https://www.dailywire.com/news/hes-not-finished-what-hes-started-jill-biden-says-joe-biden-is-ready-to-run-again)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 16:39:51+00:00

First lady Jill Biden said on Friday that President Joe Biden intends to run for a second term. Speculation has mounted over the past two years as to whether President Biden, who is 80 years old, would launch another campaign for the White House. His wife nevertheless confirmed during an interview with the Associated Press ...

## Ted Cruz Rips Democrats For Toting Ukraine Flags: ‘A Ukrainian Flag Is Like A COVID Mask’
 - [https://www.dailywire.com/news/ted-cruz-rips-democrats-for-toting-ukraine-flags-a-ukrainian-flag-is-like-a-covid-mask](https://www.dailywire.com/news/ted-cruz-rips-democrats-for-toting-ukraine-flags-a-ukrainian-flag-is-like-a-covid-mask)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 16:30:39+00:00

Sen. Ted Cruz (R-TX) ripped leftists during an episode of his podcast this week for virtue signaling by toting around Ukrainian flags, saying that the Ukrainian flag had turned into the new COVID mask. Cruz made the remarks while speaking on his podcast &#8220;Verdict&#8221; with co-host Ben Ferguson while discussing the need to hold the ...

## ‘It’s Not Surprising’: Jordan Slams Dems For Not Attending Border Crisis Meeting
 - [https://www.dailywire.com/news/its-not-surprising-jordan-slams-dems-for-not-attending-border-crisis-meeting](https://www.dailywire.com/news/its-not-surprising-jordan-slams-dems-for-not-attending-border-crisis-meeting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 16:22:59+00:00

Rep. Jim Jordan (R-OH), chairman of the House Judiciary Committee, slammed Democrats who would not show up for an in-person hearing held by the House Judiciary Committee in Yuma, Arizona, on Thursday regarding the southern border. Last week, House Democrats openly dismissed the hearing as a stunt and declared they would boycott the event. House Democrats ...

## Canada Moves Toward Assisted Suicide For Minors, Critics Erupt
 - [https://www.dailywire.com/news/canada-moves-toward-assisted-suicide-for-minors-critics-erupt](https://www.dailywire.com/news/canada-moves-toward-assisted-suicide-for-minors-critics-erupt)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 16:13:12+00:00

Canada is considering allowing terminally ill children to end their lives through assisted suicide, prompting outrage from critics, who called the plan &#8220;horrible.&#8221; This month, a Canadian parliamentary committee recommended that &#8220;mature minors&#8221; should be able to euthanize themselves, even without parental consent, through Canada&#8217;s Medical Assistance in Dying (MAiD) program if their deaths are &#8220;reasonably foreseeable.&#8221; ...

## Nearly 50% Of Gas Stoves Could Be Removed From Market Under Potential New Energy Standard: Report
 - [https://www.dailywire.com/news/nearly-50-of-gas-stoves-could-be-removed-from-market-under-potential-new-energy-standard-report](https://www.dailywire.com/news/nearly-50-of-gas-stoves-could-be-removed-from-market-under-potential-new-energy-standard-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 16:04:55+00:00

The Biden administration has quietly admitted that a new proposed energy efficiency rule from the Department of Energy (DOE) could remove up to 50% of current gas stoves from the U.S. market if it is enacted. On Friday, E&amp;E News reported that DOE did not include that fact once the proposed rule was online, but ...

## ‘She Persisted’: Children’s Book For Little Girls Will Feature Trans-Identifying Rachel Levine’s Story
 - [https://www.dailywire.com/news/she-persisted-childrens-book-for-little-girls-will-feature-trans-identifying-rachel-levines-story](https://www.dailywire.com/news/she-persisted-childrens-book-for-little-girls-will-feature-trans-identifying-rachel-levines-story)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 15:49:54+00:00

A new children&#8217;s book series geared toward girls between the ages of 6-9 will feature the story of trans-identifying Rachel Levine overcoming &#8220;obstacles.&#8221; In the &#8220;chapter book series about women who spoke up and rose up against the odds,&#8221; a book titled &#8220;She Persisted: Rachel Levin” by author Lisa Bunker tells the story of how ...

## A Billionaire Committed Suicide. No One Knows Why.
 - [https://www.dailywire.com/news/a-billionaire-committed-suicide-no-one-knows-why](https://www.dailywire.com/news/a-billionaire-committed-suicide-no-one-knows-why)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 15:32:55+00:00

Famed billionaire financier Thomas H. Lee was found dead in his office bathroom on Thursday with a single gunshot wound to his head. Lee, 78, was discovered shortly after 11 a.m. by an assistant who went looking for him when people hadn’t heard from him. First responders found Lee lying on his side with a ...

## Zelensky Challenges American Voters: If U.S. Doesn’t Support Ukraine, It ‘Will Lose Leadership Position In The World’
 - [https://www.dailywire.com/news/zelensky-challenges-american-voters-if-u-s-doesnt-support-ukraine-it-will-lose-leadership-position-in-the-world](https://www.dailywire.com/news/zelensky-challenges-american-voters-if-u-s-doesnt-support-ukraine-it-will-lose-leadership-position-in-the-world)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 15:28:19+00:00

As the U.S. continues to send billions to prop up Ukraine’s defense against Russian invaders, President Volodymyr Zelensky is challenging the growing number of Americans who question that support. On the one-year anniversary of Russia’s invasion, the Ukrainian leader responded to a question about American voters becoming less supportive of aiding Ukraine. Zelensky first thanked ...

## L.A.’s Gascón Embarrasses Himself Again With The Help Of A Very Bad Man
 - [https://www.dailywire.com/news/l-a-s-gascon-embarrass-himself-again-with-the-help-of-a-very-bad-man](https://www.dailywire.com/news/l-a-s-gascon-embarrass-himself-again-with-the-help-of-a-very-bad-man)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 15:22:51+00:00

I’m far enough away from Los Angeles that I don’t have to worry about offending District Attorney George Gascón by “misgendering” or “deadnaming” James Tubbs, who is not only a child-molesting monster, but also a man pretending to be a woman. Tubbs has played Gascón for a fool ever since he was busted for sexually ...

## Joe Rogan Says Trans Activists Don’t Allow For ‘Possibility Of Crazy People’
 - [https://www.dailywire.com/news/joe-rogan-says-trans-issue-doesnt-allow-for-possibility-of-crazy-people](https://www.dailywire.com/news/joe-rogan-says-trans-issue-doesnt-allow-for-possibility-of-crazy-people)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 15:22:02+00:00

Podcast host Joe Rogan said transgender activists don&#8217;t allow for the &#8220;possibility of crazy people&#8221; as he explained that if people don&#8217;t leave room for that, then they are basically in &#8220;a cult.&#8221; During a Tuesday episode of Spotify&#8217;s &#8220;The Joe Rogan Experience&#8221; podcast, the host and his guest, stand-up comedian and filmmaker Ryan Long, ...

## Florida Senior Community Removes All Gators Living In Its Ponds After 85-Year-Old Woman Killed
 - [https://www.dailywire.com/news/florida-senior-community-removes-all-gators-living-in-its-ponds-after-85-year-old-woman-killed](https://www.dailywire.com/news/florida-senior-community-removes-all-gators-living-in-its-ponds-after-85-year-old-woman-killed)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 14:56:59+00:00

The retirement community where an 85-year-old woman was killed by an alligator this week is now taking steps to remove all of the remaining alligators living in its ponds to prevent future attacks. Gloria Serge was walking her small dog around midday on Monday at a community retention pond at the Spanish Lakes Fairways when ...

## East Palestine Residents Could See Long-Term Health Risks From ‘Highly Toxic’ Chemicals, Analysis Says
 - [https://www.dailywire.com/news/east-palestine-residents-could-see-long-term-health-risks-from-highly-toxic-chemicals-analysis-says](https://www.dailywire.com/news/east-palestine-residents-could-see-long-term-health-risks-from-highly-toxic-chemicals-analysis-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 14:39:54+00:00

Residents affected by the train derailment and subsequent chemical fallout in East Palestine, Ohio, could be subject to a number of long-term health complications as a result of prolonged exposure to toxic substances despite officials&#8217; assurances that the air and water in the town is safe, researchers from Texas A&amp;M University and Carnegie Mellon University ...

## ‘Reality Has Set In’: Majority Of Firms See Resistance From Employees Who Do Not Want Remote Work To End
 - [https://www.dailywire.com/news/reality-has-set-in-majority-of-firms-see-resistance-from-employees-who-do-not-want-remote-work-to-end](https://www.dailywire.com/news/reality-has-set-in-majority-of-firms-see-resistance-from-employees-who-do-not-want-remote-work-to-end)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 14:18:43+00:00

Employees at many companies are shirking efforts from management to end remote work and introduce a return to physical office spaces, according to a new survey from Payscale. The workforce software company revealed in its most recent Compensation Best Practices Report that 51% of surveyed companies are experiencing resistance from employees who do not want ...

## Disney+ Cartoon Doubles-Down On Woke Push With CRT, LGBTQ Agenda In Second Season
 - [https://www.dailywire.com/news/disney-cartoon-doubles-down-on-woke-push-with-crt-lgbtq-agenda-in-second-season](https://www.dailywire.com/news/disney-cartoon-doubles-down-on-woke-push-with-crt-lgbtq-agenda-in-second-season)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 14:10:30+00:00

Disney+ animated series &#8220;The Proud Family: Louder and Prouder&#8221; doubles down on its woke agenda in the second season pushing a CRT (Critical Race Theory) and an LGBTQ agenda. The second season of the Disney cartoon hit the streaming site on February 1, 2023, and it introduced its young audience to words like &#8220;sexist&#8221; and ...

## Paris Hilton Reveals She Had An Abortion In Her 20s, Calls Pro-Life Initiatives ‘Mind-Boggling’
 - [https://www.dailywire.com/news/paris-hilton-reveals-she-had-an-abortion-in-her-20s-calls-pro-life-initiatives-mind-boggling](https://www.dailywire.com/news/paris-hilton-reveals-she-had-an-abortion-in-her-20s-calls-pro-life-initiatives-mind-boggling)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 13:59:50+00:00

Socialite and reality star Paris Hilton opened up about her previous abortion, her thoughts on abortion access, and the real reason she chose surrogacy in an interview published Thursday. The 42-year-old celebrity made the remarks during a recent interview with Glamour UK. Hilton explained she got pregnant in her early 20s but claimed she wasn’t ...

## Biden Claims Families Have ‘A Little Bit More Breathing Room’ After Another Dismal Inflation Report
 - [https://www.dailywire.com/news/biden-claims-families-have-a-little-bit-more-breathing-room-after-another-dismal-inflation-report](https://www.dailywire.com/news/biden-claims-families-have-a-little-bit-more-breathing-room-after-another-dismal-inflation-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 13:43:19+00:00

President Joe Biden sounded a note of considerable economic optimism on Friday after the inflation metric most utilized by the Federal Reserve continued to increase. The Personal Consumption Expenditures Price Index rose 5.4% between January 2022 and January 2023, while the version of the measure excluding more volatile food and energy categories rose 4.7% over ...

## Queen Consort Camilla Supports ‘Freedom’ Amid Roald Dahl Controversy, Tells Writers: ‘Remain True To Your Calling’
 - [https://www.dailywire.com/news/queen-consort-camilla-supports-freedom-amid-roald-dahl-controversy-tells-writers-remain-true-to-your-calling](https://www.dailywire.com/news/queen-consort-camilla-supports-freedom-amid-roald-dahl-controversy-tells-writers-remain-true-to-your-calling)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 13:35:22+00:00

King Charles’s wife Camilla, Queen Consort, expressed her aversion to censorship during a reception to celebrate the second anniversary of her popular online book club amid the controversy surrounding politically correct rewrites to Roald Dahl&#8217;s books. The Queen Consort addressed the room of writers and told them, “Please remain true to your calling, unimpeded by ...

## ‘Free Steering Wheel Locks’: D.C.’s Latest Handout
 - [https://www.dailywire.com/news/free-steering-wheel-locks-d-c-s-latest-handout](https://www.dailywire.com/news/free-steering-wheel-locks-d-c-s-latest-handout)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 13:34:57+00:00

&#8220;I went to the nation&#8217;s capital and all I got was this lousy steering wheel lock.&#8221; Washington, D.C.&#8217;s had a bit of a problem with carjackings over the last five years, and that trend has continued into 2023. To help prevent the problem, Democratic Mayor Muriel Bowser announced that Hyundai and Kia have donated 1,000 ...

## Biden Admin Blames Trump For Ohio Train Derailment. Even The NTSB Chair Calls That ‘Misinformation.’
 - [https://www.dailywire.com/news/biden-admin-blames-trump-for-ohio-train-derailment-even-the-ntsb-chair-calls-that-misinformation](https://www.dailywire.com/news/biden-admin-blames-trump-for-ohio-train-derailment-even-the-ntsb-chair-calls-that-misinformation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 13:01:28+00:00

Senior officials in the Biden administration have tried to pin the blame for the train derailment and subsequent chemical fallout in East Palestine, Ohio, on deregulation efforts from former President Donald Trump, but the head of the National Transportation Safety Board (NTSB) has called those efforts “misinformation.” Local and state authorities previously evacuated all residents ...

## Understanding Vision: Transforming The Chaotic Potential Of The Future
 - [https://www.dailywire.com/news/understanding-vision-transforming-the-chaotic-potential-of-the-future](https://www.dailywire.com/news/understanding-vision-transforming-the-chaotic-potential-of-the-future)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 12:46:21+00:00

The following is an excerpt from Dr. Jordan Peterson’s new series Vision and Destiny. You can watch the special on DailyWire+. Let us speak about vision a bit. We can start by thinking about vision technically. Vision is what occurs when you look out at the world. You see the world array itself in front ...

## Inflation, Immigration Most Important Issues For GOP Primary Voters: Poll
 - [https://www.dailywire.com/news/inflation-immigration-most-important-issues-for-gop-primary-voters-poll](https://www.dailywire.com/news/inflation-immigration-most-important-issues-for-gop-primary-voters-poll)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 12:39:38+00:00

Inflation and illegal immigration are top of mind for Republican primary voters, according to a new poll asking what they most want presidential candidates to tackle.  The WPA Intelligence poll showed 1,000 Republican primary voters a list of 13 issues facing the U.S., and asked respondents to choose which of the issues was the most ...

## Dr Jordan Peterson Takes On Gender Madness In New Episode Of ‘Vision & Destiny’
 - [https://www.dailywire.com/news/dr-jordan-peterson-takes-on-gender-madness-in-new-episode-of-vision-destiny](https://www.dailywire.com/news/dr-jordan-peterson-takes-on-gender-madness-in-new-episode-of-vision-destiny)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 12:26:42+00:00

Dr Jordan B Peterson’s second episode of “Vision &amp; Destiny” on DailyWire+ features the best-selling author and clinical psychologist exploring the ongoing identity crisis in the West and how radical gender ideology is adding fuel to the fire. Peterson first came to international attention in September of 2016 when he posted a series of videos ...

## WATCH: Florida Teacher Suspended Over TikTok Video Of White Kids Bowing To Black Children
 - [https://www.dailywire.com/news/watch-florida-teacher-suspended-over-tiktok-video-of-white-kids-bowing-to-black-children](https://www.dailywire.com/news/watch-florida-teacher-suspended-over-tiktok-video-of-white-kids-bowing-to-black-children)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 12:05:05+00:00

A Florida sixth-grade teacher is under fire after posting TikTok videos of white students bowing to their black peers and of himself mocking the state&#8217;s “Stop Woke Act,” which bars Critical Race Theory and other discriminatory lessons in public schools. Ethan Hooper, a teacher at Howard Middle School in Orlando, was slammed by parents and ...

## WATCH: Good Samaritan Chases Fleeing Drunk Driver Who Killed Cop, Pins Him Down
 - [https://www.dailywire.com/news/watch-good-samaritan-chases-fleeing-drunk-driver-who-killed-cop-pins-him-down](https://www.dailywire.com/news/watch-good-samaritan-chases-fleeing-drunk-driver-who-killed-cop-pins-him-down)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 12:04:07+00:00

A newly released video shows a Good Samaritan in Texas chasing down and restraining a drunk driver who bolted on foot after fatally striking an off-duty police officer.  Dylan Molina, 27, drove through a red light and crashed into an off-duty police officer’s family car, killing the officer and injuring his family. But instead of ...

## ‘Pretty Little Liars’ Star Lucy Hale Details Alcohol Addiction Struggle: ‘The Depths Of Hell’
 - [https://www.dailywire.com/news/pretty-little-liars-star-lucy-hale-details-alcohol-addiction-struggle-the-depths-of-hell](https://www.dailywire.com/news/pretty-little-liars-star-lucy-hale-details-alcohol-addiction-struggle-the-depths-of-hell)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 11:42:39+00:00

“Pretty Little Liars” actress Lucy Hale discussed Thursday her battle with alcohol addiction now that she’s gotten sober. The 33-year-old actress revealed private details about her struggle during an appearance on &#8220;The Diary of a CEO&#8221; podcast. Hale recalled how she started drinking alcohol at the age of 14 and things spiraled out of control ...

## The Equal Rights Amendment Died Over 40 Years Ago. Democrats Are Trying To Raise It From The Dead.
 - [https://www.dailywire.com/news/the-equal-rights-amendment-died-over-40-years-ago-democrats-are-trying-to-raise-it-from-the-dead](https://www.dailywire.com/news/the-equal-rights-amendment-died-over-40-years-ago-democrats-are-trying-to-raise-it-from-the-dead)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 11:09:38+00:00

Wishful thinking is alive and well on Capitol Hill. Case in point: The Senate Judiciary Committee will hold a hearing on February 28 titled “The Equal Rights Amendment: How Congress Can Recognize Ratification and Enshrine Equality in Our Constitution.” This hearing is intended to push the fiction that Congress has any authority to resurrect the ...

## Alex Murdaugh Testified In His Own Defense – And Immediately Admitted To Lying
 - [https://www.dailywire.com/news/alex-murdaugh-testified-in-his-own-defense-and-immediately-admitted-to-lying](https://www.dailywire.com/news/alex-murdaugh-testified-in-his-own-defense-and-immediately-admitted-to-lying)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 11:05:07+00:00

Alex Murdaugh took the stand on Thursday in his own defense, and immediately admitted to lying for years about his whereabouts on the day his wife, Maggie, and son, Paul, were murdered. Murdaugh is currently on trial for their murders. The prosecution had already argued that Murdaugh had lied about not going to the dog ...

## Musk Appears With Newsom To Announce New Tesla HQ In California
 - [https://www.dailywire.com/news/musk-appears-with-newsom-to-announce-new-tesla-hq-in-california](https://www.dailywire.com/news/musk-appears-with-newsom-to-announce-new-tesla-hq-in-california)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 10:57:46+00:00

Tesla CEO Elon Musk and Gov. Gavin Newsom (D-CA) appeared together on Wednesday as the electric automaker unveiled a new hub for its technology employees in Silicon Valley. Tesla will transform the former headquarters of personal computing company HP into its global headquarters for engineering operations. The billionaire entrepreneur and prominent Democratic politician hosted a ...

## ‘Of Course They Need To Ruin It’: Fans Rebel Against New ‘Lord Of The Rings’ Movies Announced By Warner Bros.
 - [https://www.dailywire.com/news/of-course-they-need-to-ruin-it-fans-rebel-against-new-lord-of-the-rings-movies-announced-by-warner-bros](https://www.dailywire.com/news/of-course-they-need-to-ruin-it-fans-rebel-against-new-lord-of-the-rings-movies-announced-by-warner-bros)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 10:40:15+00:00

“Lord of the Rings” fans are less than thrilled about the Thursday announcement from Warner Bros. that indicates the company plans to make more films based on the franchise. The decision comes less than a year after the big-budget Amazon TV series “The Lord of the Rings: Rings of Power” was released to mixed reviews. ...

## Musk Rebukes White House Over Plans To Choose New Federal Reserve Vice Chair With ‘Diversity’ In Mind
 - [https://www.dailywire.com/news/musk-rebukes-white-house-over-plans-to-choose-new-federal-reserve-vice-chair-with-diversity-in-mind](https://www.dailywire.com/news/musk-rebukes-white-house-over-plans-to-choose-new-federal-reserve-vice-chair-with-diversity-in-mind)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 10:27:52+00:00

Elon Musk balked at remarks from the Biden administration that diversity would play an important role in the appointment of the next vice chair of the Federal Reserve. White House Press Secretary Karine Jean-Pierre remarked during a Thursday press briefing that “diversity and representation is really important” to President Joe Biden and confirmed that he will ...

## China’s Plan To End Ukraine-Russia War Met With Skepticism In West
 - [https://www.dailywire.com/news/chinas-plan-to-end-ukraine-russia-war-met-with-skepticism-in-west](https://www.dailywire.com/news/chinas-plan-to-end-ukraine-russia-war-met-with-skepticism-in-west)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 10:04:12+00:00

China put forward a plan for peace in Ukraine on the one-year anniversary of the embattled nation’s grueling war with Russia, but Western leaders were initially cool to the proposal, which includes likely concessions to Moscow and a retreat by NATO. The proposal, in the form of a 12-point position paper from China’s foreign ministry, ...

## The Ukraine War A Year Later
 - [https://www.dailywire.com/news/the-ukraine-war-a-year-later](https://www.dailywire.com/news/the-ukraine-war-a-year-later)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 10:02:16+00:00

One year ago today, Ukraine’s early morning quiet was shattered by Russian shelling and bombing after months of diplomacy attempts failed. Russian President Vladimir Putin launched a sinister “special military operation” to “demilitarize” Ukraine but supposedly not occupy the former Soviet state. Almost immediately, the powers of the West sprang to action.  The Biden administration ...

## Suspect In Murders Of 3, Including 9-Year-Old Girl, Shouts Black Lives Matter Slogan When Handcuffed
 - [https://www.dailywire.com/news/suspect-in-murders-of-3-including-9-year-old-girl-shouts-black-lives-matter-slogan-when-handcuffed](https://www.dailywire.com/news/suspect-in-murders-of-3-including-9-year-old-girl-shouts-black-lives-matter-slogan-when-handcuffed)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-24 09:15:56+00:00

A Florida triple murder suspect appeared to invoke a phrase associated with Black Lives Matter when police arrested him, shouting, &#8220;I can&#8217;t breathe&#8221; as he was handcuffed by police. Keith Moses, 19, allegedly shot his acquaintance Nathacha Augustin, 38, in Orlando as they sat in a car. Hours later, Florida photographer Jesse Walden and Spectrum News ...

