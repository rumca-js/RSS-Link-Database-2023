# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## JK Rowling supporter steps down from £55m company he founded, Spitfire Audio, amid trans row
 - [https://www.dailymail.co.uk/news/article-11790813/JK-Rowling-supporter-steps-55m-company-founded-Spitfire-Audio-amid-trans-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790813/JK-Rowling-supporter-steps-55m-company-founded-Spitfire-Audio-amid-trans-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:58:22+00:00

Christian Henson, 50, who created music for television hits including Top Gear, backed the Harry Potter author in a since-deleted Tweet. Today, he announced he'd be stepping down.

## Man at centre of Shrove Tuesday 'medieval football' game brawl is 23-year-old labourer
 - [https://www.dailymail.co.uk/news/article-11790461/Man-centre-Shrove-Tuesday-medieval-football-game-brawl-23-year-old-labourer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790461/Man-centre-Shrove-Tuesday-medieval-football-game-brawl-23-year-old-labourer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:54:26+00:00

Today one man at the centre of that violence can be identified as Reece Johnston, a 23-year-old labourer from the town of Atherstone where the annual game is held.

## DAILY MAIL COMMENT: True justice means putting victims first
 - [https://www.dailymail.co.uk/news/article-11791275/DAILY-MAIL-COMMENT-True-justice-means-putting-victims-first.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791275/DAILY-MAIL-COMMENT-True-justice-means-putting-victims-first.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:49:25+00:00

DAILY MAIL COMMENT: There are some crimes so callous that it is an affront to justice that the perpetrator should serve as little as half their sentence before being freed on parole.

## Attorney for family of LSU student Madison Brooks slam release of 'hurtful and shameful' video
 - [https://www.dailymail.co.uk/news/article-11791031/Attorney-family-LSU-student-Madison-Brooks-slam-release-hurtful-shameful-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791031/Attorney-family-LSU-student-Madison-Brooks-slam-release-hurtful-shameful-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:45:00+00:00

Kerry Miller, a lawyer for Madison Brook's mother, blasted the new video of the LSU student slurring her speech surrounded by her accused rapists before her death on January 15.

## Property investor tycoon shares tips on how to break into the market and build an empire
 - [https://www.dailymail.co.uk/news/article-11790791/Property-investor-tycoon-shares-tips-break-market-build-empire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790791/Property-investor-tycoon-shares-tips-break-market-build-empire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:44:13+00:00

Ryan Beck, 35, began investing in properties in 2016 and has quickly built an impressive portfolio owning 14 houses and making $250,000 in rent each year.

## Did Alex Murdaugh's decision to take the stand against his own lawyers' advice backfire?
 - [https://www.dailymail.co.uk/news/article-11791173/Did-Alex-Murdaughs-decision-stand-against-lawyers-advice-backfire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791173/Did-Alex-Murdaughs-decision-stand-against-lawyers-advice-backfire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:43:07+00:00

In the latest twist in the Murdaugh saga, Alex, 54, decided to testify, stunning those both inside and outside the courtroom - with his own lawyer conceding that he was 'hurt' by the move.

## Crocodile attacks Alistair MacPhee and his dog Molly at boat ramp at Bloomfield near Cooktown, QLD
 - [https://www.dailymail.co.uk/news/article-11790967/Crocodile-attacks-Alistair-MacPhee-dog-Molly-boat-ramp-Bloomfield-near-Cooktown-QLD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790967/Crocodile-attacks-Alistair-MacPhee-dog-Molly-boat-ramp-Bloomfield-near-Cooktown-QLD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:39:17+00:00

Alister MacPhee, 37, was bitten on the leg by a croc which suddenly lurched out of the water to attack him on Wednesday and then turned its attention to his dog Molly, mauling it to death.

## Teachers told my 15-year-old daughter to cover her ANKLES because they were sexually attractive
 - [https://www.dailymail.co.uk/news/article-11790747/Teachers-told-15-year-old-daughter-cover-ANKLES-sexually-attractive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790747/Teachers-told-15-year-old-daughter-cover-ANKLES-sexually-attractive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:37:16+00:00

Trinity Academy Cathedral school in Wakefield, West Yorkshire, told Olivia Williams, 15, (pictured) her trousers should not be tight and she had to cover her ankles to avoid 'drawing sexual attraction'.

## Veteran DJ Ken Bruce savages BBC after finding he's being kicked off Radio 2 a month EARLY
 - [https://www.dailymail.co.uk/news/article-11791193/Veteran-DJ-Ken-Bruce-savages-BBC-finding-hes-kicked-Radio-2-month-EARLY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791193/Veteran-DJ-Ken-Bruce-savages-BBC-finding-hes-kicked-Radio-2-month-EARLY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:31:27+00:00

Speaking to the Daily Mail, Bruce, 72, said he was 'surprised and disappointed' by the BBC's decision, which paves the way for his younger replacement Vernon Kay.

## Hundreds march on Russia's embassy in London to mark a year of Putin's barbaric invasion
 - [https://www.dailymail.co.uk/news/article-11790653/Hundreds-march-Russias-embassy-London-mark-year-Putins-barbaric-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790653/Hundreds-march-Russias-embassy-London-mark-year-Putins-barbaric-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:25:50+00:00

Chants of 'Putin is a criminal' echoed along the street outside the Russian consulate in Kensington, as the devastating war in Ukraine continues.

## Five go woke: Enid Blyton's books get modern overhaul to avoid causing offence
 - [https://www.dailymail.co.uk/news/article-11791187/Five-woke-Enid-Blytons-books-modern-overhaul-avoid-causing-offence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791187/Five-woke-Enid-Blytons-books-modern-overhaul-avoid-causing-offence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:25:38+00:00

Daily Mail analysis has found the books have been stripped of many of the much-loved author's key words , such as  'queer', 'gay' and 'brown', with reference to tanned faces.

## Man, 28, arrested after woman in her 30s dies in alleged domestic violence incident at Greystanes
 - [https://www.dailymail.co.uk/news/article-11791215/Man-28-arrested-woman-30s-dies-alleged-domestic-violence-incident-Greystanes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791215/Man-28-arrested-woman-30s-dies-alleged-domestic-violence-incident-Greystanes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:23:31+00:00

A 28-year-old man has been arrested after a woman's body was discovered inside a home at Greystanes, in Sydney's west, following reports of a domestic violence incident at the property.

## White House warns Putin may give fighter jets and attack helicopters to Iran
 - [https://www.dailymail.co.uk/news/article-11791195/White-House-warns-Putin-fighter-jets-attack-helicopters-Iran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791195/White-House-warns-Putin-fighter-jets-attack-helicopters-Iran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:10:31+00:00

Adm. John Kirby told reporters that Russia has offered 'unprecedented defense cooperation' to Iran, who has been supplying armed drones as Russia levies war on Ukraine.

## The secret to making you richer? Put your cards away and pay for everything in CASH!
 - [https://www.dailymail.co.uk/femail/article-11791045/The-secret-making-richer-cards-away-pay-CASH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11791045/The-secret-making-richer-cards-away-pay-CASH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:08:48+00:00

Budget is not a dirty word. So why is it that, when we think of budgeting, we immediately feel restricted and deprived?

## End the pothole plague: Motorists and MPs demand action as 1,400 drivers a DAY are hit by breakdowns
 - [https://www.dailymail.co.uk/news/article-11791029/End-pothole-plague-Motorists-MPs-demand-action-1-400-drivers-DAY-hit-breakdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791029/End-pothole-plague-Motorists-MPs-demand-action-1-400-drivers-DAY-hit-breakdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 23:02:21+00:00

Holly Bryant (pictured) has unsuccessfully battled to fix a pothole covering the width of her village road.

## FBI investigating how box of Trump classified documents was moved to Mar-a-Lago months AFTER search
 - [https://www.dailymail.co.uk/news/article-11789831/FBI-investigating-box-Trump-classified-documents-moved-Mar-Lago-months-search.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789831/FBI-investigating-box-Trump-classified-documents-moved-Mar-Lago-months-search.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:52:51+00:00

Investigators to the special counsel spoke to a Trump aide who was involved in scanning a box of materials with her phone. Some of the documents were marked classified, and were returned.

## Alexei Navalny: The truth teller Putin is trying to kill, day by torturous day...
 - [https://www.dailymail.co.uk/news/article-11790983/Alexei-Navalny-truth-teller-Putin-trying-kill-day-torturous-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790983/Alexei-Navalny-truth-teller-Putin-trying-kill-day-torturous-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:46:12+00:00

He is 46-year-old Alexei Navalny - lawyer, opposition leader and the man who has done more than any to document the dictator's shocking corruption.

## Runaway aristocrat and rapist lover: Fears grow for baby nearly 50 days after the last sighting
 - [https://www.dailymail.co.uk/news/article-11791041/Runaway-aristocrat-rapist-lover-Fears-grow-baby-nearly-50-days-sighting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791041/Runaway-aristocrat-rapist-lover-Fears-grow-baby-nearly-50-days-sighting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:46:08+00:00

Tomorrow marks the 50th day since the last sighting of the trio. Fifty days in which Constance Marten, her partner Mark Gordon and their child have seemingly vanished into thin air.

## BREAKING NEWS: Man 80, is killed and three others are injured in dog attack in San Antonio
 - [https://www.dailymail.co.uk/news/article-11791057/Man-80-killed-three-injured-dog-attack-San-Antonio.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791057/Man-80-killed-three-injured-dog-attack-San-Antonio.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:40:54+00:00

An elderly man in his 80s was killed and two other women were hospitalized following a severe dog assault on the West Side of the city of San Antonio on Friday afternoon.

## Mesa Airlines flight is forced to ABORT landing at Hollywood Burbank Airport in latest near-miss
 - [https://www.dailymail.co.uk/news/article-11790759/Mesa-Airlines-flight-forced-ABORT-landing-Hollywood-Burbank-Airport-latest-near-miss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790759/Mesa-Airlines-flight-forced-ABORT-landing-Hollywood-Burbank-Airport-latest-near-miss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:38:13+00:00

In the latest of a string of near-disasters on America's runways, a Mesa Airlines flight was forced to abort its landing at the last minute this week, as another plane was taking off into its path.

## Rockstar Energy founder lists stunning Utah ski property for $50 MILLION
 - [https://www.dailymail.co.uk/news/article-11790221/Rockstar-Energy-founder-lists-stunning-Utah-ski-property-50-MILLION.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790221/Rockstar-Energy-founder-lists-stunning-Utah-ski-property-50-MILLION.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:37:04+00:00

The billionaire creator of Rockstar Energy has listed for sale a property in Utah for $50 million - less than a year after he officially acquired it for $39.4 million.

## Unmasked: The TikTok ghoul who covertly filmed Nicola Bulley's body being lifted from the river
 - [https://www.dailymail.co.uk/news/article-11790883/Unmasked-TikTok-ghoul-covertly-filmed-Nicola-Bulleys-body-lifted-river.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790883/Unmasked-TikTok-ghoul-covertly-filmed-Nicola-Bulleys-body-lifted-river.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:36:46+00:00

Curtis Arnold (pictured), 34, posted the shocking video on YouTube and TikTok on an account called Nicola Bulley Case -later rebranded as Curtis Media.

## How Roald Dahl's family kept their £370 million gravy train on track, writes ALISON BOSHOFF
 - [https://www.dailymail.co.uk/news/article-11791077/How-Roald-Dahls-family-kept-370-million-gravy-train-track-writes-ALISON-BOSHOFF.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11791077/How-Roald-Dahls-family-kept-370-million-gravy-train-track-writes-ALISON-BOSHOFF.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:29:12+00:00

His betrayed first wife called him 'Roald the Rotten' and it is easy to see why the author Roald Dahl is considered controversial in the era of cancel culture.

## Mega-prison in El Salvador for gangsters, which has 80 beds per 100 people, welcomes first inmates
 - [https://www.dailymail.co.uk/news/article-11790981/Mega-prison-El-Salvador-gangsters-80-beds-100-people-welcomes-inmates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790981/Mega-prison-El-Salvador-gangsters-80-beds-100-people-welcomes-inmates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:24:10+00:00

A mega-prison in El Salvador has opened its doors for its first 2,000 inmates of suspected gang members - who upon their arrival found out there are not enough beds and no mattresses at all.

## A vaccine to end Covid for good? Early results show nasal spray reduced risk of severe covid by 86%
 - [https://www.dailymail.co.uk/health/article-11790943/A-vaccine-end-Covid-good-Early-results-nasal-spray-reduced-risk-severe-covid-86.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11790943/A-vaccine-end-Covid-good-Early-results-nasal-spray-reduced-risk-severe-covid-86.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:22:11+00:00

Inhalable nasal vaccines could be a gamechanger in defeating Covid for good. Georgia-based researchers are developing such a vaccine which was a highly effective booster dose.

## Women's rights protesters line streets outside police station as Kellie-Jay Keen is quizzed
 - [https://www.dailymail.co.uk/news/article-11790255/Womens-rights-protesters-line-streets-outside-police-station-Kellie-Jay-Keen-quizzed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790255/Womens-rights-protesters-line-streets-outside-police-station-Kellie-Jay-Keen-quizzed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:22:10+00:00

Protesters massed outside a police station in Trowbridge today after officers hauled in a women's rights campaigner over a rally where her group were attacked by rival activists.

## Lunar Electric cancelled: Gold Coast festival with Doja Cat, Swae Lee cut after The Veronicas rant
 - [https://www.dailymail.co.uk/news/article-11782663/Lunar-Electric-cancelled-Gold-Coast-festival-Doja-Cat-Swae-Lee-cut-Veronicas-rant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11782663/Lunar-Electric-cancelled-Gold-Coast-festival-Doja-Cat-Swae-Lee-cut-Veronicas-rant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:21:56+00:00

Lunar Electric festival was scheduled to be held on the Gold Coast on March 11 but organisers announced on Thursday it would be postponed to September.

## Prosecutors seek death penalty for Athena Strand,7, murderer
 - [https://www.dailymail.co.uk/news/article-11790739/Prosecutors-seek-death-penalty-Athena-Strand-7-murderer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790739/Prosecutors-seek-death-penalty-Athena-Strand-7-murderer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:19:47+00:00

Prosecutors are seeking the death penalty against the Texas FedEx driver accused of kidnapping and strangling a seven-year-old girl while delivering her Barbie Doll Christmas gifts.

## Downing Street is accused of plotting to drag the King into Brexit storm
 - [https://www.dailymail.co.uk/news/article-11790899/Downing-Street-accused-plotting-drag-King-Brexit-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790899/Downing-Street-accused-plotting-drag-King-Brexit-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:04:38+00:00

Details emerged of a plan for the King to host the European Commission president at Windsor today as negotiations with Rishi Sunak over Northern Ireland reached a critical stage.

## Family of Joanna Simpson make plea over her BA pilot husband who bludgeoned her to death with hammer
 - [https://www.dailymail.co.uk/news/article-11790817/Family-Joanna-Simpson-make-plea-BA-pilot-husband-bludgeoned-death-hammer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790817/Family-Joanna-Simpson-make-plea-BA-pilot-husband-bludgeoned-death-hammer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 22:00:19+00:00

Grieving mother Diana Parkes begged the Justice Secretary to keep her daughter Joanna Simpson's (pictured) killer husband behind bars.

## CNN is 'making real progress' to win back viewers by interviewing GOP guests, CEO claims
 - [https://www.dailymail.co.uk/news/article-11790691/CNN-making-real-progress-win-viewers-interviewing-GOP-guests-CEO-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790691/CNN-making-real-progress-win-viewers-interviewing-GOP-guests-CEO-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 21:53:57+00:00

Warner Bros. Discovery boss David Zaslav has insisted flailing CNN is 'making real progress' in winning back viewers by including more Republican voices on its shows.

## Disney exec blames FANS for Lightyear flopping at the box office
 - [https://www.dailymail.co.uk/news/article-11790663/Disney-exec-blames-FANS-Lightyear-flopping-box-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790663/Disney-exec-blames-FANS-Lightyear-flopping-box-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 21:50:56+00:00

Pixar's chief creative officer admitted this week that the producers of the 2022 flop Lightyear 'asked too much of the audience.'

## Hollywood royalty Catherine Zeta-Jones and Michael Douglas are now living in St James's Palace
 - [https://www.dailymail.co.uk/news/article-11790829/Hollywood-royalty-Catherine-Zeta-Jones-Michael-Douglas-living-St-Jamess-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790829/Hollywood-royalty-Catherine-Zeta-Jones-Michael-Douglas-living-St-Jamess-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 21:35:17+00:00

The Hollywood superstars are now a stone's throw from the home of the King and Queen Consort, while Princesses Anne and Beatrice are even closer neighbours.

## Pete Buttigieg's 'slow' East Palestine response under investigation
 - [https://www.dailymail.co.uk/news/article-11790737/Pete-Buttigiegs-slow-East-Palestine-response-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790737/Pete-Buttigiegs-slow-East-Palestine-response-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 21:33:22+00:00

The House Committee on Oversight and Accountability has written to the embattled Transportation Secretary, asking for an explanation for his alleged 'apathy' towards East Palestine.

## DIsabled woman dies of stroke in back of cop car after being arrested for refusing to leave hospital
 - [https://www.dailymail.co.uk/news/article-11790681/DIsabled-woman-dies-stroke-cop-car-arrested-refusing-leave-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790681/DIsabled-woman-dies-stroke-cop-car-arrested-refusing-leave-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 21:31:24+00:00

Knoxville Police have released their body camera video of the harrowing incident which happened at Fort Sanders Regional Medical Center, on February 6.

## Could bird flu cause a Covid-like pandemic? Everything you need to know about H5N1
 - [https://www.dailymail.co.uk/health/article-11789315/Could-bird-flu-cause-Covid-like-pandemic-need-know-H5N1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11789315/Could-bird-flu-cause-Covid-like-pandemic-need-know-H5N1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 21:31:08+00:00

The father of an 11-year-old girl who died from bird flu in Cambodia this week has also tested positive for the virus. Eleven more suspected cases are awaiting tests, bolstering concerns.

## 'Glory to the Heroes!' rang out as a trumpet sounded beneath golden dome, writes Ian Birrell in Kyiv
 - [https://www.dailymail.co.uk/news/article-11790775/Glory-Heroes-rang-trumpet-sounded-beneath-golden-dome-writes-Ian-Birrell-Kyiv.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790775/Glory-Heroes-rang-trumpet-sounded-beneath-golden-dome-writes-Ian-Birrell-Kyiv.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 21:26:12+00:00

'Slava Ukraini (Glory to Ukraine)!' said Volodymyr Zelensky, the nation's battle-cry. Hundreds of soldiers, holding their guns to their chests, thundered back: 'Heroyam Slava (Glory to the Heroes)!'

## 'Roald Dahl was a bigot... but really?' Salman Rushdie note to PEN America CEO that started backlash
 - [https://www.dailymail.co.uk/news/article-11790501/Roald-Dahl-bigot-really-Salman-Rushdie-note-PEN-America-CEO-started-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790501/Roald-Dahl-bigot-really-Salman-Rushdie-note-PEN-America-CEO-started-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:53:18+00:00

Salman Rushdie, pictured left, has waded into the debate over the woke censorship of Roald Dahl's classic children's books, slamming the decision as 'insane' to PEN America CEO Suzanne Nossel.

## Pietro Addis sobs as trial hears how close he was to grandmother he stabbed to death
 - [https://www.dailymail.co.uk/news/article-11790459/Pietro-Addis-sobs-trial-hears-close-grandmother-stabbed-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790459/Pietro-Addis-sobs-trial-hears-close-grandmother-stabbed-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:53:07+00:00

Pietro Addis, now 19, is on trial accused of murdering popular restaurateur Sue Addis, 69, at her £1 million home in Brighton on January 7, 2021.

## Tinkerbell the chihuahua clings to post in a marina after falling off boat
 - [https://www.dailymail.co.uk/news/article-11790421/Tinkerbell-chihuahua-clings-post-marina-Florida-falling-boat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790421/Tinkerbell-chihuahua-clings-post-marina-Florida-falling-boat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:44:38+00:00

A tiny chihuahua named Tinkerbell got her very own fairytale ending after falling from a boat into the sea when she was found sheltering underneath a jetty.

## Mental health advocate launches defense for 6'6" boy, 17, who attacked teaching aide
 - [https://www.dailymail.co.uk/news/article-11790563/Mental-health-advocate-launches-defense-66-boy-17-attacked-teaching-aide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790563/Mental-health-advocate-launches-defense-66-boy-17-attacked-teaching-aide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:41:37+00:00

Sue Urban, who has a special needs stepson at the school, said the child, 17, of Palm Coast, should have been taken to a mental health facility, not jail.

## Rust armorer Hannah Gutierrez-Reed convinces judge to let her keep gun at home
 - [https://www.dailymail.co.uk/news/article-11790595/Rust-armorer-Hannah-Gutierrez-Reed-convinces-judge-let-gun-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790595/Rust-armorer-Hannah-Gutierrez-Reed-convinces-judge-let-gun-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:41:01+00:00

Rust armorer Hannah Gutierrez-Reed convinced a judge to allow her to keep a gun at home while on bail. Halyna Hutchins was shot and killed by Alec Baldwin on the film set in October 2021.

## Man stole nearly $18K in electricity in crypto mining operation
 - [https://www.dailymail.co.uk/news/article-11790153/Man-stole-nearly-18K-electricity-crypto-mining-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790153/Man-stole-nearly-18K-electricity-crypto-mining-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:30:39+00:00

Nadeam Nahas, 39, of Norwell, MA is facing charges of allegedly running a secret cryptocurrency mining operation out of a crawlspace at a middle school.

## Historic Winter Storm Olive zeroes in on California as blizzard and flood warnings hit LA
 - [https://www.dailymail.co.uk/news/article-11790531/Historic-Winter-Storm-Olive-zeroes-California-blizzard-flood-warnings-hit-LA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790531/Historic-Winter-Storm-Olive-zeroes-California-blizzard-flood-warnings-hit-LA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:18:53+00:00

Heavy snow and rain battered large swathes of California on Friday while thousands of households in Michigan suffered power outages as the country was hit by one of the worst ice storms in decades.

## BBC bosses axed Radio 2 DJ Ken Bruce's contract a month EARLY ahead of Vernon Kay takeover
 - [https://www.dailymail.co.uk/news/article-11790555/BBC-bosses-axed-Radio-2-DJ-Ken-Bruces-contract-month-EARLY-ahead-Vernon-Kay-takeover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790555/BBC-bosses-axed-Radio-2-DJ-Ken-Bruces-contract-month-EARLY-ahead-Vernon-Kay-takeover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:05:46+00:00

Bruce, 72, today issued a short statement revealing he intended to work right up until the end of his contract at the end of March, but his final show will now be next Friday.

## Richard Sackler to sell a third luxury property for $20M as Purdue Pharma is hit with lawsuits
 - [https://www.dailymail.co.uk/news/article-11789939/Richard-Sackler-sell-luxury-property-20M-Purdue-Pharma-hit-lawsuits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789939/Richard-Sackler-sell-luxury-property-20M-Purdue-Pharma-hit-lawsuits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:04:58+00:00

Richard Sackler, 77, has put his Beverly Hills four-bed, four-bath mansion on the market for just shy of $20million. It is the third luxury property he has offloaded in recent years.

## Neonatal nurse Lucy Letby 'tried to kill premature twin baby by adding insulin to intravenous bags'
 - [https://www.dailymail.co.uk/news/article-11790433/Neonatal-nurse-Lucy-Letby-tried-kill-premature-twin-baby-adding-insulin-intravenous-bags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790433/Neonatal-nurse-Lucy-Letby-tried-kill-premature-twin-baby-adding-insulin-intravenous-bags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:03:45+00:00

Neonatal nurse Lucy Letby tried to kill a premature baby by secretly adding lethal doses of insulin to at least three intravenous bags being used to feed him, a jury at Manchester Crown Court heard today.

## Prison reform boss who subjected husband to 15 years of abuse is jailed for four years
 - [https://www.dailymail.co.uk/news/article-11790319/Prison-reform-boss-subjected-husband-15-years-abuse-jailed-four-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790319/Prison-reform-boss-subjected-husband-15-years-abuse-jailed-four-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 20:01:24+00:00

Sheree Spencer, 45, was jailed for four years for making husband Richard's life a living hell with daily beatings and verbal attacks that left him cowering on the floor in the foetal position.

## Celebrity surgeon dubbed the 'Boob God' has accused ex-patient of running smear campaign against him
 - [https://www.dailymail.co.uk/news/article-11790345/Celebrity-surgeon-dubbed-Boob-God-accused-ex-patient-running-smear-campaign-against-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790345/Celebrity-surgeon-dubbed-Boob-God-accused-ex-patient-running-smear-campaign-against-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:55:33+00:00

Dr Riccardo Frati alleged art dealer Karen Bowen-Carter led an online smear campaign against him, following her claims the medic provided cheap surgeries to celebrities for fake reviews.

## Three US nationals tried to smuggle £1.7m worth of cannabis through Heathrow Airport
 - [https://www.dailymail.co.uk/news/article-11790395/Three-nationals-tried-smuggle-1-7m-worth-cannabis-Heathrow-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790395/Three-nationals-tried-smuggle-1-7m-worth-cannabis-Heathrow-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:55:02+00:00

Barrington Walters, 24, from Los Angeles, and Mandy Silowka, 34, from Princeton, New Jersey, were caught with a total of nearly 60 kilos -9.45st- of marijuana.

## T.J. Holmes and Amy Robach look loved up in Puerto Vallarta
 - [https://www.dailymail.co.uk/news/article-11790151/T-J-Holmes-Amy-Robach-look-loved-Puerto-Vallarta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790151/T-J-Holmes-Amy-Robach-look-loved-Puerto-Vallarta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:44:17+00:00

T.J. Holmes and Amy Robach are enjoying their second week of their Puerto Vallarta vacation, almost a month after they were fired from ABC, exclusive DailyMail.com photos show.

## 'Governor' of Skid Row slams LA for demolishing her tent home that had kitchen and HOT TUB
 - [https://www.dailymail.co.uk/news/article-11790289/Governor-Skid-Row-slams-LA-demolishing-tent-home-kitchen-HOT-TUB.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790289/Governor-Skid-Row-slams-LA-demolishing-tent-home-kitchen-HOT-TUB.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:44:12+00:00

A woman known as the 'Governor' of downtown Los Angeles' notorious Skid Row section has slammed city officials who destroyed her luxurious tent last week.

## Drone footage reveals Murdaugh's brother and son removing guns three months after murders
 - [https://www.dailymail.co.uk/news/article-11782643/Drone-footage-reveals-Murdaughs-brother-son-removing-guns-three-months-murders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11782643/Drone-footage-reveals-Murdaughs-brother-son-removing-guns-three-months-murders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:44:10+00:00

In a new Netflix show drone footage taken by an amateur sleuth showed John Marvin and Alex's surviving son Buster removing eight weapons from the 1,800-acre estate in Moselle, South Carolina.

## Idaho murders house to be demolished: Moscow home boarded up
 - [https://www.dailymail.co.uk/news/article-11790307/Idaho-murders-house-demolished-Moscow-home-boarded-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790307/Idaho-murders-house-demolished-Moscow-home-boarded-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:44:09+00:00

President of the University Scott Green confirmed on Friday that the home on King Street is set to be demolished as a 'healing step'.

## Chinese-American Democrat Rep. slams 'racist' Republican who questioned her 'loyalty'
 - [https://www.dailymail.co.uk/news/article-11790479/Chinese-American-Democrat-Rep-slams-racist-Republican-questioned-loyalty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790479/Chinese-American-Democrat-Rep-slams-racist-Republican-questioned-loyalty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:43:59+00:00

House Democrats are revolting after Texas Republican Rep. Lance Gooden suggested Chinese-American Rep. Judy Chu shouldn't have a security clearance.

## How 'tough, blunt' Bernard Ingham stood by Margaret Thatcher's side for 11 years as press secretary
 - [https://www.dailymail.co.uk/news/article-11790415/How-tough-blunt-Bernard-Ingham-stood-Margaret-Thatchers-11-years-press-secretary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790415/How-tough-blunt-Bernard-Ingham-stood-Margaret-Thatchers-11-years-press-secretary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:41:59+00:00

Dubbed the forerunner to New Labour's 'master of spin' Alastair Campbell, he was an abrasive gatekeeper of information for the British media.

## 'Re-educate' children who make non-politically correct comments, Christian trust tells teachers
 - [https://www.dailymail.co.uk/news/article-11790419/Re-educate-children-make-non-politically-correct-comments-Christian-trust-tells-teachers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790419/Re-educate-children-make-non-politically-correct-comments-Christian-trust-tells-teachers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:38:36+00:00

The Aquinas Church of England Education Trust was today warned by a former Downing Street adviser that its approach appeared 'very sinister'.

## President Zelensky says he 'plans to meet Xi Jinping' following China's peace proposal
 - [https://www.dailymail.co.uk/news/article-11790397/President-Zelensky-says-plans-meet-Xi-Jinping-following-Chinas-peace-proposal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790397/President-Zelensky-says-plans-meet-Xi-Jinping-following-Chinas-peace-proposal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:36:09+00:00

'I plan to meet Xi Jinping and believe this will be beneficial for our countries and for security in the world,' Mr Zelensky told a news conference on the anniversary of Russia's invasion of Ukraine.

## 21 miles in Malibu: America's most dangerous stretch of road?
 - [https://www.dailymail.co.uk/news/article-11781877/21-Miles-Malibu-Americas-deadliest-road-pacific-coast-highway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11781877/21-Miles-Malibu-Americas-deadliest-road-pacific-coast-highway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:25:41+00:00

Filmmaker Michel Shane, who produced Catch Me If You Can, created 21 Miles in Malibu in tribute to his daughter Emily, 13, who was mowed down by a manic driver while walking on the strip in 2010.

## Gymnastics coach accused of separating girls into 'fat' groups is barred from unsupervised training
 - [https://www.dailymail.co.uk/news/article-11789847/Gymnastics-coach-accused-separating-girls-fat-groups-barred-unsupervised-training.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789847/Gymnastics-coach-accused-separating-girls-fat-groups-barred-unsupervised-training.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:23:30+00:00

A top gymnastics coach has been barred from training without supervision amid accusations he abused girls as young as nine, splitting them into 'fat' groups.

## Prince Harry and Meghan Markle would 'overshadow King Charles' at coronation, expert claims
 - [https://www.dailymail.co.uk/femail/article-11790193/Prince-Harry-Meghan-Markle-overshadow-King-Charles-coronation-expert-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11790193/Prince-Harry-Meghan-Markle-overshadow-King-Charles-coronation-expert-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 19:09:35+00:00

Appearing on GB News earlier this week, royal author Tom Bower discussed whether or not the Duke and Duchess will attend the upcoming royal occasion.

## Deliveroo customer slammed for having 'no humanity' after collecting order from collapsed driver
 - [https://www.dailymail.co.uk/news/article-11790057/Deliveroo-customer-slammed-having-no-humanity-collecting-order-collapsed-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790057/Deliveroo-customer-slammed-having-no-humanity-collecting-order-collapsed-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:41:58+00:00

Mohammed was making a delivery at the front door of  Meranti House in London when he collapsed at around 10:30pm last night, according to James Farrar, who reported the issue on Twitter.

## Meghan could bring back The Tig blog if Sussexes' multi-million pound TV and podcast deals dry up
 - [https://www.dailymail.co.uk/news/article-11790253/Meghan-bring-Tig-blog-Sussexes-multi-million-pound-TV-podcast-deals-dry-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790253/Meghan-bring-Tig-blog-Sussexes-multi-million-pound-TV-podcast-deals-dry-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:39:06+00:00

Brand and culture expert Nick Ede today suggested the Duchess could see her old lifestyle blog The Tig as the key to future success.

## Man accused of killing pregnant woman Natalie McNally remanded in custody for another four weeks
 - [https://www.dailymail.co.uk/news/article-11790375/Man-accused-killing-pregnant-woman-Natalie-McNally-remanded-custody-four-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790375/Man-accused-killing-pregnant-woman-Natalie-McNally-remanded-custody-four-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:36:54+00:00

Stephen McCullagh (pictured), 32, from Woodland Gardens, Lisburn, was previously arrested on December 19 but released and ruled out as a suspect. He was rearrested on January 31.

## 'Migrant' shot dead by rancher was cartel drug smuggler, says ex-Border Patrol chief
 - [https://www.dailymail.co.uk/news/article-11789783/Migrant-shot-dead-rancher-cartel-drug-smuggler-says-ex-Border-Patrol-chief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789783/Migrant-shot-dead-rancher-cartel-drug-smuggler-says-ex-Border-Patrol-chief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:35:12+00:00

George Alan Kelly, 73, was arrested on charges of first degree murder for shooting Gabriel Cuen-Butimea on January 30 at his home.

## Finding Michael trailer: Spencer Matthews tries to recover brother's body
 - [https://www.dailymail.co.uk/tvshowbiz/article-11790147/Finding-Michael-trailer-Spencer-Matthews-tries-recover-brothers-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11790147/Finding-Michael-trailer-Spencer-Matthews-tries-recover-brothers-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:33:31+00:00

Spencer Matthews, 34, tries to retrace the steps of his brother Michael with  survivalist Bear Grylls and mountaineer Nirmal Purja in the trailer for  Finding Michael.

## Experts are baffled as giant 30ft-wide and 9ft deep sinkhole crater opens just feet from busy road
 - [https://www.dailymail.co.uk/news/article-11790127/Experts-baffled-giant-30ft-wide-9ft-deep-sinkhole-crater-opens-just-feet-busy-road.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790127/Experts-baffled-giant-30ft-wide-9ft-deep-sinkhole-crater-opens-just-feet-busy-road.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:32:01+00:00

Experts are baffled by a giant 30ft-wide sinkhole crater in South Wales, with some fearing that it could be the result of old mining works or even a UFO landing.

## Put word WOMAN back into health advice, NHS told
 - [https://www.dailymail.co.uk/health/article-11790047/Put-word-WOMAN-health-advice-NHS-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11790047/Put-word-WOMAN-health-advice-NHS-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:30:08+00:00

Gender-specific terms have been quietly scrubbed on official NHS England advice sites under a woke inclusivity drive.

## Conservative moms force Georgia school board to pay $100k legal fees after banning x-rated book
 - [https://www.dailymail.co.uk/news/article-11789623/Conservative-moms-force-Georgia-school-board-pay-100k-legal-fees-banning-x-rated-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789623/Conservative-moms-force-Georgia-school-board-pay-100k-legal-fees-banning-x-rated-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:29:36+00:00

Alison Hair, left, was barred from school board meetings after reading a sexually explicit book available in her son's school library - leading to a lawsuit that her group Mama Bears won.

## Volunteer finds missing two-year-old boy in woods a day after he wandered from his Florida home
 - [https://www.dailymail.co.uk/news/article-11789753/Volunteer-finds-missing-two-year-old-boy-woods-day-wandered-Florida-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789753/Volunteer-finds-missing-two-year-old-boy-woods-day-wandered-Florida-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:25:33+00:00

A missing two-year-old boy was found in the woods more than 24 hours after he disappeared from the the yard of his family home in Florida.

## Man accused of murdering partner's son tells court toddler was 'jealous of him' as he denies killing
 - [https://www.dailymail.co.uk/news/article-11790131/Man-accused-murdering-partners-son-tells-court-toddler-jealous-denies-killing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790131/Man-accused-murdering-partners-son-tells-court-toddler-jealous-denies-killing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:23:34+00:00

Jacob Lennon died of serious head injuries in August 2019 and had dozens of other injuries consistent with horrific long-term abuse at his home in Putney, south west London.

## LA Lawyer who swindled firm out of $10.2million stole $10k from her best friend WEEKS before lawsuit
 - [https://www.dailymail.co.uk/news/article-11786151/LA-Lawyer-swindled-firm-10-2million-stole-10k-best-friend-WEEKS-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786151/LA-Lawyer-swindled-firm-10-2million-stole-10k-best-friend-WEEKS-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:22:17+00:00

The attorney had been carrying out her schemes to get more money up to the point the lawsuit was filed by LDR International in February.

## 'Professor Lockdown' Neil Ferguson once warned 200MILLION people could die during bird flu crisis
 - [https://www.dailymail.co.uk/health/article-11789787/Professor-Lockdown-Neil-Ferguson-warned-200MILLION-people-die-bird-flu-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11789787/Professor-Lockdown-Neil-Ferguson-warned-200MILLION-people-die-bird-flu-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:21:48+00:00

Professor Neil Ferguson, tasked with forecasting Covid-style scenarios about bird flu in the UK, made the dire prediction in 2005 when fears of an avian influenza crisis were similarly high.

## Roald Dahl fans blast Puffin for 'Orwellian' censoring as it says it WILL print edited versions
 - [https://www.dailymail.co.uk/news/article-11790257/Roald-Dahl-fans-blast-Puffin-Orwellian-censoring-says-print-edited-versions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790257/Roald-Dahl-fans-blast-Puffin-Orwellian-censoring-says-print-edited-versions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 18:05:35+00:00

Public debate of the 'Orwellian' censoring even saw the King's wife Camilla demand they do not put curbs on 'freedom of expression'.

## Russia INTERRUPTS minute's silence for victims of Ukraine at the UN
 - [https://www.dailymail.co.uk/news/article-11790027/Russia-INTERRUPTS-minutes-silence-victims-Ukraine-UN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11790027/Russia-INTERRUPTS-minutes-silence-victims-Ukraine-UN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 17:43:20+00:00

As members of the UN assembly stood up, the Russian ambassador tapped on his microphone. 'We are getting up on our feet to honour the memory of all victims,' he insisted.

## Mark Cusack consulted GP to confirm he is still alive after 'getting bizarre message'
 - [https://www.dailymail.co.uk/news/article-11788903/Mark-Cusack-consulted-GP-confirm-alive-getting-bizarre-message.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788903/Mark-Cusack-consulted-GP-confirm-alive-getting-bizarre-message.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 17:43:03+00:00

Mark Cusack, 48, claims that an ominous letter from the Government left him with no National Insurance number and no possible way to pay his council tax bill.

## King Charles and Prince of Wales 'have no intention of giving Prince Harry  apology he is demanding'
 - [https://www.dailymail.co.uk/news/article-11789969/King-Charles-Prince-Wales-no-intention-giving-Prince-Harry-apology-demanding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789969/King-Charles-Prince-Wales-no-intention-giving-Prince-Harry-apology-demanding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 17:42:56+00:00

King Charles and Prince William have 'no intention' of giving Prince Harry the apology he wants if he is to attend the Coronation, as 'save the date' cards are set to be sent out in two weeks.

## Long Island NICU nurse fired after father films her slamming newborn face-first into bassinet
 - [https://www.dailymail.co.uk/news/article-11789519/Long-Island-NICU-nurse-fired-father-films-slamming-newborn-face-bassinet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789519/Long-Island-NICU-nurse-fired-father-films-slamming-newborn-face-bassinet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 17:41:45+00:00

A Long Island nurse was fired after baby's father videos horrifying footage of the nurse slamming his newborn baby boy - face first - into the bassinet in the hospital's neonatal intensive care unit.

## Donald Trump promises action 'radical left garbage' investment 'scams' and woke capitalism
 - [https://www.dailymail.co.uk/news/article-11789655/Donald-Trump-promises-action-radical-left-garbage-investment-scams-woke-capitalism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789655/Donald-Trump-promises-action-radical-left-garbage-investment-scams-woke-capitalism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 17:39:56+00:00

Donald Trump on Friday trumpeted his record of restricting retirement funds from investing in environmental, social and governance-focused assets during his time in office.

## Cold winds to hit Britain tonight with temperatures plunging to -2C
 - [https://www.dailymail.co.uk/news/article-11789667/Cold-winds-hit-Britain-tonight-temperatures-plunging-2C.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789667/Cold-winds-hit-Britain-tonight-temperatures-plunging-2C.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 17:33:23+00:00

The Met Office has forecast below freezing temperatures and patches of snow as a cold front from mainland Europe crosses across Britain.

## Prosecutor tears into Murdaugh's 'new story' about why he was at the murder scene
 - [https://www.dailymail.co.uk/news/article-11789891/Prosecutor-tears-Murdaughs-new-story-murder-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789891/Prosecutor-tears-Murdaughs-new-story-murder-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 17:20:14+00:00

The disgraced legal scion, 54, told cops he had never been at the kennels that night but yesterday admitted he had lied because his opioid addiction made him paranoid.

## Is thrifty rock legend Rod Stewart becoming a big generous softy?
 - [https://www.dailymail.co.uk/news/article-11789581/Is-thrifty-rock-legend-Rod-Stewart-big-generous-softy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789581/Is-thrifty-rock-legend-Rod-Stewart-big-generous-softy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 17:11:58+00:00

After years of penny-pinching, thrifty music legend Sir Rod Stewart appears to be transforming into a generous softy in his golden years, having paid for patient scans at a hospital in Essex.

## Billionaire financier Thomas H. Lee found by female assistant with gunshot wound to the head
 - [https://www.dailymail.co.uk/news/article-11789931/Billionaire-financier-Thomas-E-Lee-shot-head.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789931/Billionaire-financier-Thomas-E-Lee-shot-head.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:43:44+00:00

Billionaire financier Thomas H. Lee was discovered by his female assistant in his office bathroom with a gunshot wound to his head and his Smith & Wesson revolver by his side.

## Ukraine Russia war: Zelensky thanks 'Rishi Sunak and the people of Britain for steadfast support'
 - [https://www.dailymail.co.uk/news/article-11789749/Ukraine-Russia-war-Zelensky-thanks-Rishi-Sunak-people-Britain-steadfast-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789749/Ukraine-Russia-war-Zelensky-thanks-Rishi-Sunak-people-Britain-steadfast-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:41:51+00:00

Volodymyr Zelensky said the UK's support in these 'difficult times is invaluable', as he marked a year since Vladimir Putin launched his barbaric invasion of Ukraine.

## Man takes 137-mile journey from Derby to Whitby using five buses all capped at £2 each
 - [https://www.dailymail.co.uk/news/article-11788845/Man-takes-137-mile-journey-Derby-Whitby-using-five-buses-capped-2-each.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788845/Man-takes-137-mile-journey-Derby-Whitby-using-five-buses-capped-2-each.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:40:53+00:00

Andrew Cowell, 47, travelled 137 miles on buses from his home in Derby, Derbyshire, to Whitby, North Yorkshire, on Thursday.

## Margaret Thatcher's press secretary Sir Bernard Ingham dies at age 90
 - [https://www.dailymail.co.uk/news/article-11789803/Margaret-Thatchers-press-secretary-Sir-Bernard-Ingham-dies-age-90.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789803/Margaret-Thatchers-press-secretary-Sir-Bernard-Ingham-dies-age-90.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:39:56+00:00

Sir Bernard Ingham, the long-serving press secretary for Margaret Thatcher, has died aged 90 after a short illness, his family said.

## Inside Stephen Spielberg's 20-year feud with Tom Cruise that ended at recent Oscars lunch
 - [https://www.dailymail.co.uk/news/article-11789433/Inside-Stephen-Spielbergs-20-year-feud-Tom-Cruise-ended-recent-Oscars-lunch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789433/Inside-Stephen-Spielbergs-20-year-feud-Tom-Cruise-ended-recent-Oscars-lunch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:38:45+00:00

The pair have not always had such a happy relationship - with their terms souring after working together on War of the Worlds in 2005 and Minority Report in 2002.

## Lorry driver killed bride-to-be, 28, whose car had broken down and two motorists helping her
 - [https://www.dailymail.co.uk/news/article-11789671/Lorry-driver-killed-bride-28-car-broken-two-motorists-helping-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789671/Lorry-driver-killed-bride-28-car-broken-two-motorists-helping-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:34:58+00:00

Michal Kopaniarz, 39, smashed his nine-ton lorry into mother-of-two Alex Britton, 28, and two other motorists who had stopped to help her after her car broke down on the A303 near Andover, Hampshire

## I'm a Celebrity, Get Me Out of Here! castle becomes centre of row - 200-year-old wall knocked down
 - [https://www.dailymail.co.uk/news/article-11789693/Im-Celebrity-castle-centre-row-200-year-old-wall-knocked-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789693/Im-Celebrity-castle-centre-row-200-year-old-wall-knocked-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:31:59+00:00

The I'm A Celebrity... Get Me Out of Here! Gwrych Castle in Wales is embroiled in a planning row after a 200-year-old wall was knocked down.

## Rapper who wrote a song boasting about killing another teenager is jailed for life for the murder
 - [https://www.dailymail.co.uk/news/article-11789765/Rapper-wrote-song-boasting-killing-teenager-jailed-life-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789765/Rapper-wrote-song-boasting-killing-teenager-jailed-life-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:27:00+00:00

Abdirahaman Yussuf was sentenced following the death of 18-year-old Yahya Sharif who was killed just seconds after getting out of his car on December 10, 2021 in Small Heath, Birmingham.

## Mum-of-three TikTok star whose cash budgeting trick could save you HUNDREDS of pounds
 - [https://www.dailymail.co.uk/news/article-11789501/Mum-three-TikTok-star-cash-budgeting-trick-save-HUNDREDS-pounds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789501/Mum-three-TikTok-star-cash-budgeting-trick-save-HUNDREDS-pounds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:26:28+00:00

A mum-of-three has revealed her secret to beating the cost of living squeeze - paying for as much as possible using cash that she sets aside in dedicated envelopes.

## Boy, 13, appears in court accused of stabbing teen as three more youngsters are arrested
 - [https://www.dailymail.co.uk/news/article-11789751/Boy-13-appears-court-accused-stabbing-teen-three-youngsters-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789751/Boy-13-appears-court-accused-stabbing-teen-three-youngsters-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:25:10+00:00

A 13 year-old boy appeared before a magistrates court today, after being accused of attempted murder on a schoolboy on Wednesday evening in West Howe, Bournemouth.

## Motorists need to watch out for this blank red road sign - do you know what it means?
 - [https://www.dailymail.co.uk/money/cars/article-11789373/Motorists-need-watch-blank-red-road-sign-know-means.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/cars/article-11789373/Motorists-need-watch-blank-red-road-sign-know-means.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:19:42+00:00

Drivers may be confused by a blank circular sign with a red border and unless you're a motorist who recently passed their theory test you might need a reminder.

## Iceland boss warned they'd halt openings amid energy bills rise as stores set to close from tomorrow
 - [https://www.dailymail.co.uk/news/article-11789805/Iceland-boss-warned-theyd-halt-openings-amid-energy-bills-rise-stores-set-close-tomorrow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789805/Iceland-boss-warned-theyd-halt-openings-amid-energy-bills-rise-stores-set-close-tomorrow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 16:18:34+00:00

Boss Richard Walker had said his group was 'fighting to keep the lights on' and called for an energy price cap for British businesses after his recent bill doubled.

## Steve Allen, 68, quits LBC after 44 years
 - [https://www.dailymail.co.uk/news/article-11789579/Steve-Allen-68-quits-LBC-44-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789579/Steve-Allen-68-quits-LBC-44-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:42:33+00:00

Mr Allen, renowned for his monologues and dry humour, is currently hosting the early breakfast show between 4am and 7am.

## Naomi Biden helps hold down Jill's dress upon windy arrival in Kenya
 - [https://www.dailymail.co.uk/news/article-11789577/Naomi-Biden-helps-hold-Jills-dress-windy-arrival-Kenya.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789577/Naomi-Biden-helps-hold-Jills-dress-windy-arrival-Kenya.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:42:16+00:00

Naomi Biden helped Jill Biden hold down her dress upon their windy arrival in Kenya  on Friday, keeping her grandmother from experiencing an embarassing moment in front of the cameras.

## Italian tourist who shot friend dead in pigeon-hunting trip accident is cleared of culpable homicide
 - [https://www.dailymail.co.uk/news/article-11789195/Italian-tourist-shot-friend-dead-pigeon-hunting-trip-accident-cleared-culpable-homicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789195/Italian-tourist-shot-friend-dead-pigeon-hunting-trip-accident-cleared-culpable-homicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:39:43+00:00

Franco Moroni who admitted killing Marco Cavola by blasting a shotgun at his head at point-blank range - wept and embraced a supporter after the jury ruled it was a catastrophic accident.

## Billy Bragg reveals he has dropped singing 'boys' from Which Side Are You On?
 - [https://www.dailymail.co.uk/tvshowbiz/article-11788873/Billy-Bragg-reveals-dropped-singing-boys-On.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11788873/Billy-Bragg-reveals-dropped-singing-boys-On.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:36:21+00:00

The singer, 65, has revealed he has dropped 'boys' from Which Side Are You On? to be more 'inclusive'.

## 'It made everything better': Alex Murdaugh claims he stole over $10m to fund opioid habit
 - [https://www.dailymail.co.uk/news/article-11781873/Murdaugh-claims-stole-10m-buy-opioids-120-years-consume-pills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11781873/Murdaugh-claims-stole-10m-buy-opioids-120-years-consume-pills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:35:52+00:00

Alex Murdaugh, 54, told cops he was spending $60,000 a week on drugs - that would buy 750 of the best pills at $80 each. It is physically impossible to consume that many pills.

## Therese Coffey mocked on social media after urging Brits to eat turnips
 - [https://www.dailymail.co.uk/news/article-11789253/Therese-Coffey-mocked-social-media-urging-Brits-eat-turnips.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789253/Therese-Coffey-mocked-social-media-urging-Brits-eat-turnips.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:35:10+00:00

When Therese Coffey urged Brits to 'cherish' our nation's turnips, social media went into a frenzy, mercilessly mocking the MP for her bold suggestions.

## Wounded photographer describes the shooting in Florida that killed his journalist friend
 - [https://www.dailymail.co.uk/news/article-11789313/Wounded-photographer-describes-shooting-Florida-killed-journalist-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789313/Wounded-photographer-describes-shooting-Florida-killed-journalist-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:32:29+00:00

Jesse Walden, 29, was injured in a shooting in Florida that killed his fellow reporter and a nine-year-old girl described how he 'played cat and mouse' with the gunman.

## Kansas becomes first state to define 'woman' as someone who is 'biologically born female'
 - [https://www.dailymail.co.uk/news/article-11789269/Kansas-state-define-woman-biologically-born-female.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789269/Kansas-state-define-woman-biologically-born-female.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:29:40+00:00

Kansas has become the first state to pass a bill that defines 'woman' as someone who is biologically born female, paving the way for banning transgender people from single-sex spaces.

## Iraqi immigrant stabbed university student because he wanted to be deported, court hears
 - [https://www.dailymail.co.uk/news/article-11789375/Iraqi-immigrant-stabbed-university-student-wanted-deported-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789375/Iraqi-immigrant-stabbed-university-student-wanted-deported-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:25:49+00:00

Teenager Ellis Wheeler, a fresher at Solent University student, was left fighting for his life after Rebaz Mohammed attacked him in December 2022, Southampton Crown Court heard

## Now Bisto is £5.50! Stunned shoppers say gravy is the 'new Lurpak' after price hikes by 50.9%
 - [https://www.dailymail.co.uk/news/article-11789563/Now-Bisto-5-50-Stunned-shoppers-say-gravy-new-Lurpak-price-hikes-50-9.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789563/Now-Bisto-5-50-Stunned-shoppers-say-gravy-new-Lurpak-price-hikes-50-9.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:18:08+00:00

Figures showed around 50 Bisto products have seen sharp increases in price since the new year across leading supermarkets such as Sainsbury's, Morrisons and Asda.

## How Ukrainians are adapting to Britain one year on while knowing their home will 'never be the same'
 - [https://www.dailymail.co.uk/news/article-11789149/How-Ukrainians-adapting-Britain-one-year-knowing-home-never-same.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789149/How-Ukrainians-adapting-Britain-one-year-knowing-home-never-same.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:10:14+00:00

Twelve months on, many who fled Ukraine still don't know when they will return and what 'home' will be like if they do.

## Canada steps closer to euthanizing CHILDREN: panel says sick kids should have suicide rights
 - [https://www.dailymail.co.uk/news/article-11786697/Canada-steps-closer-euthanizing-CHILDREN-panel-says-sick-kids-suicide-rights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786697/Canada-steps-closer-euthanizing-CHILDREN-panel-says-sick-kids-suicide-rights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 15:06:46+00:00

Sick and disabled kids could soon be joining the roughly 10,000 adults who end their lives each year under Canada's euthanasia scheme: the world's most permissive such program.

## Florida schoolboy, 17, beats female teaching aide to a pulp after she took his Nintendo Switch away
 - [https://www.dailymail.co.uk/news/article-11789215/Florida-schoolboy-17-beats-female-teaching-aide-pulp-took-Nintendo-Switch-away.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789215/Florida-schoolboy-17-beats-female-teaching-aide-pulp-took-Nintendo-Switch-away.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:57:44+00:00

The student, who was not named due to his age, 17, of Palm Coast, violently attacked the teaching aide after telling another student he was 'going to kill her' for taking his game away on Tuesday.

## Massachusetts Democrat faces calls to resign after suggesting disabled children should be aborted
 - [https://www.dailymail.co.uk/news/article-11789223/Massachusetts-Democrat-faces-calls-resign-suggesting-disabled-children-aborted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789223/Massachusetts-Democrat-faces-calls-resign-suggesting-disabled-children-aborted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:51:38+00:00

Michael Hugo, pictured top right, is facing calls to resign after he suggested disabled children should have been aborted to save his city's school budget. The Massachusetts official has refused to do so.

## Campbelltown, Sydney: Fire erupts at a petrol station as 60 firefighters battle the blaze
 - [https://www.dailymail.co.uk/news/article-11789255/Campbelltown-Sydney-Fire-erupts-petrol-station-60-firefighters-battle-blaze.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789255/Campbelltown-Sydney-Fire-erupts-petrol-station-60-firefighters-battle-blaze.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:45:52+00:00

NSW Fire and Rescue said the major blaze erupted at a petrol station on Lindesay Street in Campbelltown, just after 10.15pm on Friday, with more than 60 firefighters battling the blaze.

## Railway union TSSA accepts train companies' offers in long-running dispute over pay and conditions
 - [https://www.dailymail.co.uk/news/article-11789475/Railway-union-TSSA-accepts-train-companies-offers-long-running-dispute-pay-conditions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789475/Railway-union-TSSA-accepts-train-companies-offers-long-running-dispute-pay-conditions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:44:01+00:00

Members of the Transport Salaried Staffs Association (TSSA) have voted to accept offers by train companies in the long-running dispute over pay, job security and conditions.

## Harvey Weinstein rape victim actress Evgeniya Chernyshova comes forward
 - [https://www.dailymail.co.uk/news/article-11789435/Harvey-Weinstein-rape-victim-actress-Evgeniya-Chernyshova-comes-forward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789435/Harvey-Weinstein-rape-victim-actress-Evgeniya-Chernyshova-comes-forward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:43:51+00:00

Evgeniya Chernyshova has previously only been referred to as 'Jane Doe 1', a nameless Italian actress who Weinstein attacked in Beverly Hills ten years ago.

## Alex Jones angrily slams DoJ 'for asking about his $2,000 ragdoll Mushu'
 - [https://www.dailymail.co.uk/news/article-11789301/Alex-Jones-angrily-slams-DoJ-asking-2-000-ragdoll-Mushu.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789301/Alex-Jones-angrily-slams-DoJ-asking-2-000-ragdoll-Mushu.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:43:40+00:00

Conspiracy theorist Alex Jones claims in a new video that the Department of Justice is coming after his beloved $2,000 cat Mushu. Jones is bankrupt and owes $1.5 billion to the Sandy Hook families.

## Watch as Latvian politician tells Putin delegation 'Russian warship, go f*** yourself'
 - [https://www.dailymail.co.uk/news/article-11789171/Watch-Latvian-politician-tells-Putin-delegation-Russian-warship-f-yourself.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789171/Watch-Latvian-politician-tells-Putin-delegation-Russian-warship-f-yourself.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:39:14+00:00

During his extraordinary and passionate speech, Rihards Kols said it was 'a disgrace' that Vladimir Putin's delegates were allowed to attend the gathering in Vienna.

## Murdaugh's testimony will continue today as he goes head to head with prosecutors in murder trial
 - [https://www.dailymail.co.uk/news/article-11789383/Murdaughs-testimony-continue-today-goes-head-head-prosecutors-murder-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789383/Murdaughs-testimony-continue-today-goes-head-head-prosecutors-murder-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:36:05+00:00

Alex Murdaugh, 54, defied his own legal team to take the stand yesterday to deny killing his wife Maggie, 52, and son Paul, 22, at their home in Moselle, SC.

## No vegetable crisis here! Rishi Sunak hosts Tory fundraiser at Savoy
 - [https://www.dailymail.co.uk/news/article-11789351/No-vegetable-crisis-Rishi-Sunak-hosts-Tory-fundraiser-Savoy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789351/No-vegetable-crisis-Rishi-Sunak-hosts-Tory-fundraiser-Savoy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:27:31+00:00

Wealthy donors and senior party figures including the PM gathered at the five-star Savoy Hotel in London for the Conservative Winter Party,  amid vegetable rationing in supermarkets.

## Where is the leopard in this image? Predator is perfectly camouflaged in this test for your eyes
 - [https://www.dailymail.co.uk/news/article-11789465/Where-leopard-image-Predator-perfectly-camouflaged-test-eyes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789465/Where-leopard-image-Predator-perfectly-camouflaged-test-eyes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:24:54+00:00

Can you spot the snow leopard perfectly camouflaged in its rocky surroundings in the Altai Mountains in western Mongolia?

## Bali influencer Alexandra Saper aka thewayfaress in hiding after stalker flies from UK to kidnap her
 - [https://www.dailymail.co.uk/news/article-11768821/Bali-influencer-Alexandra-Saper-aka-thewayfaress-hiding-stalker-flies-UK-kidnap-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11768821/Bali-influencer-Alexandra-Saper-aka-thewayfaress-hiding-stalker-flies-UK-kidnap-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:22:29+00:00

American Alexandra Saper, 31, had been living an glamorous life based on the Indonesian island since 2018, but has now fled to an undisclosed location.

## Moruya dog attack: Rottweilers who mauled five-week-old baby to death are put down
 - [https://www.dailymail.co.uk/news/article-11789021/Moruya-dog-attack-Rottweilers-mauled-five-week-old-baby-death-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789021/Moruya-dog-attack-Rottweilers-mauled-five-week-old-baby-death-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:06:00+00:00

Five-week-old Mia Jade Riley was killed in a vicious dog attack in Moruya, on the NSW south coast, on Saturday. On Friday, a local council confirmed two Rottweilers had been euthanised.

## Biden announces sweeping sanctions against Russian AND Chinese companies helping Putin's war
 - [https://www.dailymail.co.uk/news/article-11789257/Biden-announces-sweeping-sanctions-against-Russian-Chinese-companies-helping-Putins-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789257/Biden-announces-sweeping-sanctions-against-Russian-Chinese-companies-helping-Putins-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 14:02:11+00:00

The White House is announcing new sanctions on 200 individuals and entities as well as key sectors in an announcement timed with the anniversary of Russia's Ukraine invasion.

## Handyman 'who gunned down LA bishop in his bed' pictured
 - [https://www.dailymail.co.uk/news/article-11786465/Handyman-gunned-LA-bishop-bed-pictured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786465/Handyman-gunned-LA-bishop-bed-pictured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:52:19+00:00

The alleged killer of  Bishop David O'Connell, who was found dead from a single gunshot wound, is handyman Carlos Medina Vallejo, 61, the husband of the bishop's housekeeper

## Kate Forbes, Humza Yousaf and Ash Regan battle to succeed Nicola Sturgeon
 - [https://www.dailymail.co.uk/news/article-11789371/Kate-Forbes-Humza-Yousaf-Ash-Regan-battle-succeed-Nicola-Sturgeon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789371/Kate-Forbes-Humza-Yousaf-Ash-Regan-battle-succeed-Nicola-Sturgeon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:52:13+00:00

The trio were the only candidates when nominations closed this lunchtime, ending the possibility of a surprise challenger entering.

## Violent protests break out at schools in Cornwall, Yorkshire and Lincolnshire
 - [https://www.dailymail.co.uk/news/article-11789183/Violent-protests-break-schools-Cornwall-Yorkshire-Lincolnshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789183/Violent-protests-break-schools-Cornwall-Yorkshire-Lincolnshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:45:11+00:00

Pupils were seen at schools in Cornwall, Yorkshire and Lincolnshire demanding an end to bans on using toilets during class times.

## Gangster's moll is targeted in arson attack at her home after being jailed for arranging ex's murder
 - [https://www.dailymail.co.uk/news/article-11788909/Gangsters-moll-targeted-arson-attack-home-jailed-arranging-exs-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788909/Gangsters-moll-targeted-arson-attack-home-jailed-arranging-exs-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:44:37+00:00

Police have confirmed that they are probing Colleen Campbell's, 38, home after it was subject to an arson attack just hours after she was locked up for 13 years for the manslaughter of Thomas Campbell.

## Queensland: Young girl is forced to cling to the side of an amusement ride at Mount Isa event
 - [https://www.dailymail.co.uk/news/article-11788911/Queensland-Young-girl-forced-cling-amusement-ride-Mount-Isa-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788911/Queensland-Young-girl-forced-cling-amusement-ride-Mount-Isa-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:42:31+00:00

The girl, whose age is unknown, was attending the Mount Isa 100 Years Celebration event on Thursday evening in Queensland.

## Junior doctors announce 72-HOUR strike dates in March in pursuit of 30% pay rise
 - [https://www.dailymail.co.uk/health/article-11788871/Junior-doctors-announce-72-HOUR-strike-dates-March-pursuit-30-pay-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11788871/Junior-doctors-announce-72-HOUR-strike-dates-March-pursuit-30-pay-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:40:56+00:00

Junior doctors in England have confirmed the dates of their massive 72-hour strike with medics to take to the picket line for a continuous three-day industrial action from March 13.

## Drunk Manchester United fans caught chanting for air hostess to 'get her t**s out'
 - [https://www.dailymail.co.uk/news/article-11789039/Drunk-Manchester-United-fans-caught-chanting-air-hostess-t-s-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789039/Drunk-Manchester-United-fans-caught-chanting-air-hostess-t-s-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:38:43+00:00

Chloe Harrison had been in the job for three months when she was forced to deal with the lewd gaggle of fans on flight from Manchester, with some even inviting her into the toilet with them.

## Devon and Cornwall police officer accused of sex offences to appear in court with two more charges
 - [https://www.dailymail.co.uk/news/article-11789173/Devon-Cornwall-police-officer-accused-sex-offences-appear-court-two-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789173/Devon-Cornwall-police-officer-accused-sex-offences-appear-court-two-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:35:55+00:00

Devon and Cornwall PC Matthew Tregale, 33, is due to appear before Bristol Crown Court on Monday 27 February in connection a further two charges against the same woman.

## Predators are cleared from lake near retirement community after woman savaged to death by reptile
 - [https://www.dailymail.co.uk/news/article-11789131/Predators-cleared-lake-near-retirement-community-woman-savaged-death-reptile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789131/Predators-cleared-lake-near-retirement-community-woman-savaged-death-reptile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:34:29+00:00

The Florida Fish and Wildlife Conservation Commission removed all of the reptiles from the gated communities' lakes after Gloria Serge, 85, died in a brutal attack.

## Texas mother-of-two, 29, has her hands and feet amputated after septic shock from C-section
 - [https://www.dailymail.co.uk/news/article-11789075/Texas-mother-two-29-hands-feet-amputated-septic-shock-C-section.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789075/Texas-mother-two-29-hands-feet-amputated-septic-shock-C-section.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:32:35+00:00

Krysten Pacheco, 29, lost both her hands and feet as a result of the infection in October. She spent four months in the hospital and rehab centers in Texas before finally going home on February 11.

## £665million Crypto firm backed by MPs, Lords and ex-Premier League footballer 'vanishes'
 - [https://www.dailymail.co.uk/news/article-11788667/665million-Crypto-firm-backed-MPs-Lords-ex-Premier-League-footballer-vanishes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788667/665million-Crypto-firm-backed-MPs-Lords-ex-Premier-League-footballer-vanishes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:32:28+00:00

Luke Sullivan, from Kent, founded Phoenix Community Capital, began last year as a cryptocurrency project and investment scheme.

## Vivek Ramaswamy: Candidates must be able to face Trump's name-calling on campaign trail
 - [https://www.dailymail.co.uk/news/article-11787721/Vivek-Ramaswamy-Candidates-able-face-Trumps-calling-campaign-trail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787721/Vivek-Ramaswamy-Candidates-able-face-Trumps-calling-campaign-trail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:32:12+00:00

The biotech millionaire who announced his candidacy for president on Tuesday said that he recognizes Trump was able to bring light to larger issues in the U.S.

## Tesco run out of turnips: Supermarkets empty as shoppers scrabble to buy in-season produce
 - [https://www.dailymail.co.uk/news/article-11789109/Tesco-run-turnips-Supermarkets-shoppers-scrabble-buy-season-produce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789109/Tesco-run-turnips-Supermarkets-shoppers-scrabble-buy-season-produce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:31:46+00:00

Environment Secretary Therese Coffey suggested turnips as an alternative while other items - such as cucumbers, tomatoes and peppers - remain in short supply due to poor weather abroad

## LatitudePay closes down: Warning signs popular service was about to collapse
 - [https://www.dailymail.co.uk/news/article-11788049/LatitudePay-closes-Warning-signs-popular-service-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788049/LatitudePay-closes-Warning-signs-popular-service-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:30:11+00:00

In an email to customers on Friday, popular buy now pay later service LatitudePay announced it was shutting up shop from April 1, impacting more than 500,000 customers across Australia.

## Cornwall hit by 1.5 magnitude earthquake which woke up locals who felt a 'rumble' and houses 'shake'
 - [https://www.dailymail.co.uk/news/article-11788941/Cornwall-hit-1-5-magnitude-earthquake-woke-locals-felt-rumble-houses-shake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788941/Cornwall-hit-1-5-magnitude-earthquake-woke-locals-felt-rumble-houses-shake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:27:18+00:00

Cornwall was hit by an earthquake this morning as locals said they felt a 'rumble' and houses 'shake' as the earth moved beneath them. The quake had a magnitude of 1.5 of the Richter scale.

## Councillor appears naked in the SHOWER while WFH during meeting in Romania [Video]
 - [https://www.dailymail.co.uk/news/article-11788915/Councillor-appears-naked-SHOWER-WFH-meeting-Romania.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788915/Councillor-appears-naked-SHOWER-WFH-meeting-Romania.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:25:34+00:00

When the chairman of the meeting called for attendance, Social Democratic (PSD) councillor Alberto-Iosif Caraian (pictured) appeared live from a shower, naked and wet.

## Sadiq Khan faces backlash: Mayor blasted for allowing 'Turkey teeth' and 'face shot' ads on Tubes
 - [https://www.dailymail.co.uk/news/article-11788525/Sadiq-Khan-faces-backlash-Mayor-blasted-allowing-Turkey-teeth-face-shot-ads-Tubes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788525/Sadiq-Khan-faces-backlash-Mayor-blasted-allowing-Turkey-teeth-face-shot-ads-Tubes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 13:16:57+00:00

Posters containing strong sexual innuendo, advertising plastic surgery and even 'Turkey teeth' abroad have been questioned by MPs and London Assembly Members.

## Putin: How Russian president's physical and mental state has deteriorated during year of war
 - [https://www.dailymail.co.uk/news/article-11788913/Putin-Russian-presidents-physical-mental-state-deteriorated-year-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788913/Putin-Russian-presidents-physical-mental-state-deteriorated-year-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 12:56:43+00:00

Rumours about Putin's declining health, poor mental acumen and unstable position have swirled since long before he ordered the invasion on February 24, 2022.

## A sheepskin coat and microphone will be placed in John Motson's old Wembley commentary position
 - [https://www.dailymail.co.uk/sport/football/article-11789077/A-sheepskin-coat-microphone-placed-John-Motsons-old-Wembley-commentary-position.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-11789077/A-sheepskin-coat-microphone-placed-John-Motsons-old-Wembley-commentary-position.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 12:54:36+00:00

The legendary commentator, who became synonymous with English football during his distinguished 50-year career with the BBC, died yesterday aged 77.

## Puffin in Roald Dahl u-turn: Publisher announces it WON'T edit author's beloved books
 - [https://www.dailymail.co.uk/news/article-11789025/Puffin-Roald-Dahl-u-turn-Publisher-announces-WONT-edit-authors-beloved-books.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789025/Puffin-Roald-Dahl-u-turn-Publisher-announces-WONT-edit-authors-beloved-books.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 12:44:49+00:00

Puffin has been under fire over ' woke ' changes to many of his most famous children's classics as critics including the Queen Consort demanded they do not put curbs on 'freedom of expression'.

## Tesco and Co-op run out of turnips: Supermarkets empty as shoppers scrabble to buy in-season produce
 - [https://www.dailymail.co.uk/news/article-11789109/Tesco-op-run-turnips-Supermarkets-shoppers-scrabble-buy-season-produce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11789109/Tesco-op-run-turnips-Supermarkets-shoppers-scrabble-buy-season-produce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 12:44:41+00:00

Environment Secretary Therese Coffey suggested turnips as an alternative while other items - such as cucumbers, tomatoes and peppers - remain in short supply due to poor weather abroad

## Rod Stewart meets patients benefitting from scans he paid for after singer blasted NHS backlog
 - [https://www.dailymail.co.uk/news/article-11788991/Rod-Stewart-meets-patients-benefitting-scans-paid-singer-blasted-NHS-backlog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788991/Rod-Stewart-meets-patients-benefitting-scans-paid-singer-blasted-NHS-backlog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 12:43:31+00:00

Sir Rod Stewart (left) visited an NHS hospital in Harlow, Essex, after previously offering to pay for patients' scans amid criticism over the length of NHS waiting lists.

## From male model and T4 to Radio 2: Tracking Vernon Kay's rise to stardom
 - [https://www.dailymail.co.uk/news/article-11788747/From-male-model-T4-Radio-2-Tracking-Vernon-Kays-rise-stardom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788747/From-male-model-T4-Radio-2-Tracking-Vernon-Kays-rise-stardom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 12:40:32+00:00

Vernon Kay's career is back on the up this week after the 48-year-old was handed his own show on BBC Radio 2 - replacing the much-loved Ken Bruce on his coveted morning slot

## Mark Cusack consulted GP to confirm he is still alive after 'getting bizarre message from DWP'
 - [https://www.dailymail.co.uk/news/article-11788903/Mark-Cusack-consulted-GP-confirm-alive-getting-bizarre-message-DWP.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788903/Mark-Cusack-consulted-GP-confirm-alive-getting-bizarre-message-DWP.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 12:37:50+00:00

Mark Cusack, 48, says that the ominous letter from the Department of Work and Pensions left him with no National Insurance number.

## Student is found NOT GUILTY of murdering transgender sex worker
 - [https://www.dailymail.co.uk/news/article-11788073/Student-NOT-GUILTY-murdering-transgender-sex-worker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788073/Student-NOT-GUILTY-murdering-transgender-sex-worker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 12:36:35+00:00

WARNING GRAPHIC CONTENT: Hector Enrique Valencia Valencia, 23, killed Kimberley McRae, 69, in January 2020.

## NYC jewelry store owner, 79, is beaten and pistol whipped during $500,000 heist in broad daylight
 - [https://www.dailymail.co.uk/news/article-11788875/NYC-jewelry-store-owner-79-beaten-pistol-whipped-500-000-heist-broad-daylight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788875/NYC-jewelry-store-owner-79-beaten-pistol-whipped-500-000-heist-broad-daylight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 12:31:00+00:00

Two unidentified men entered the Queens jewelry shop at 2.30pm, before striking the store owner in the head with a weapon and taking off with $500,000 worth of stolen goods.

## Kent University says pronouns 'Xe/Xem' are 'valid' in guide for staff and students
 - [https://www.dailymail.co.uk/news/article-11788657/Kent-University-says-pronouns-Xe-Xem-valid-guide-staff-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788657/Kent-University-says-pronouns-Xe-Xem-valid-guide-staff-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 11:45:47+00:00

The University of Kent produced a three-page guide on gender-neutral pronouns that people can be called by until their 'preferred pronouns' are confirmed.

## What is China's REAL aim with its 'peace plan'? Western leaders say the nation lacks 'credibility'
 - [https://www.dailymail.co.uk/news/article-11788739/What-Chinas-REAL-aim-peace-plan-Western-leaders-say-nation-lacks-credibility.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788739/What-Chinas-REAL-aim-peace-plan-Western-leaders-say-nation-lacks-credibility.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 11:43:36+00:00

Western leaders have questioned what the real motive behind China's 12-point peace plan is - given that Beijing has stood shoulder-to-shoulder with Russia and parroted the Kremlin's talking points.

## Boris Johnson's VERY sweary reaction to Putin's invasion
 - [https://www.dailymail.co.uk/news/article-11788757/Boris-Johnsons-sweary-reaction-Putins-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788757/Boris-Johnsons-sweary-reaction-Putins-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 11:38:22+00:00

After the then-PM was roused by aides in the middle of the night and informed the 'special military operation' had begun, he swiped: 'That f***ing c***.'

## Labor MP Daniel Repacholi leaves cheeky comment on Aldi ad promoting face roller
 - [https://www.dailymail.co.uk/news/article-11788413/Labor-MP-Daniel-Repacholi-leaves-cheeky-comment-Aldi-ad-promoting-face-roller.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788413/Labor-MP-Daniel-Repacholi-leaves-cheeky-comment-Aldi-ad-promoting-face-roller.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 11:36:32+00:00

Daniel Repacholi, the MP for NSW's Hunter Region, left a cheeky remark on an Aldi advertisement promoting a phallic-shaped face roller for $19.99 - leaving

## New poll: Ron DeSantis wins in a 9-candidate GOP primary field with 40% support
 - [https://www.dailymail.co.uk/news/article-11787659/New-poll-Ron-DeSantis-wins-9-candidate-GOP-primary-field-40-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787659/New-poll-Ron-DeSantis-wins-9-candidate-GOP-primary-field-40-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 11:23:04+00:00

A new poll shows the GOP preference for voters in the 2024 primary is still for Florida Governor Ron DeSantis to be the nominee - even when put up against eight other candidates.

## Prince Harry's digger driver ex Sasha Walpole gets  back to work
 - [https://www.dailymail.co.uk/news/article-11788711/Prince-Harrys-digger-driver-ex-Sasha-Walpole-gets-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788711/Prince-Harrys-digger-driver-ex-Sasha-Walpole-gets-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 11:19:41+00:00

Sasha Walpole - the woman who Prince Harry outed as taking his virginity in a field behind a pub - was expertly driving a digger and a dumper truck on a building site in Wiltshire this morning.

## Boris Johnson lights one of 52 candles - each marking a week of Russia's war on Ukraine - at service
 - [https://www.dailymail.co.uk/news/article-11788539/Boris-Johnson-lights-one-52-candles-marking-week-Russias-war-Ukraine-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788539/Boris-Johnson-lights-one-52-candles-marking-week-Russias-war-Ukraine-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 11:13:13+00:00

Boris Johnson, who was PM when the war began and when few believed Ukraine could hold out against Russia, described the prayer service at the Ukrainian Catholic Cathedral as 'powerful'.

## Cocker Spaniel nicknamed 'Eddie the Eagle' after plunging 131ft down a sheer cliff face
 - [https://www.dailymail.co.uk/news/article-11788603/Cocker-Spaniel-nicknamed-Eddie-Eagle-plunging-131ft-sheer-cliff-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788603/Cocker-Spaniel-nicknamed-Eddie-Eagle-plunging-131ft-sheer-cliff-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 11:02:56+00:00

Eddie, a one-year-old Cocker Spaniel, plunged to the ground after toppling over the edge of Whitestone Cliff, North Yorkshire, in January.

## No cost-of-living crisis here! Tories auction off glittering Swarovski Rishi Sunak portrait for £25k
 - [https://www.dailymail.co.uk/news/article-11788549/No-cost-living-crisis-Tories-auction-glittering-Swarovski-Rishi-Sunak-portrait-25k.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788549/No-cost-living-crisis-Tories-auction-glittering-Swarovski-Rishi-Sunak-portrait-25k.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 10:53:27+00:00

The shimmering portrait of the Prime Minister was the showpiece of the auction at the Conservative Winter Ball at London's opulent Savoy hotel.

## British woman 'lucky to be alive' after catching disease 'from Airbnb hot-tub' on holiday in Florida
 - [https://www.dailymail.co.uk/news/article-11788423/British-woman-lucky-alive-catching-disease-Airbnb-hot-tub-holiday-Florida.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788423/British-woman-lucky-alive-catching-disease-Airbnb-hot-tub-holiday-Florida.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 10:49:53+00:00

Pamela Farman, 75, from Somerleyton, Suffolk, was having the holiday of a lifetime with her family in Florida when she began having difficulty breathing.

## NHS accused of 'institutional racism' by 'sidelined' black nurse
 - [https://www.dailymail.co.uk/news/article-11788587/NHS-accused-institutional-racism-sidelined-black-nurse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788587/NHS-accused-institutional-racism-sidelined-black-nurse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 10:45:08+00:00

Michelle Cox, 55, was harassed and victimised 'because of her race' when she challenged decisions and 'blew the whistle' on manager Gill Paxton, an employment tribunal in Manchester has found.

## Prince Andrew 'is playing with fire' after 'refusing' to move out of  Windsor Royal lodge
 - [https://www.dailymail.co.uk/news/article-11788503/Prince-Andrew-playing-fire-refusing-Windsor-Royal-lodge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788503/Prince-Andrew-playing-fire-refusing-Windsor-Royal-lodge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 10:34:35+00:00

The disgraced Duke of York has told friends he will not be able to afford the upkeep at Royal Lodge in Windsor when his annual £249,000 grant is slashed from April.

## Wagner mercenary chief got around UK money laundering checks by submitting his mother's gas bill
 - [https://www.dailymail.co.uk/news/article-11788519/Wagner-mercenary-chief-got-UK-money-laundering-checks-submitting-mothers-gas-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788519/Wagner-mercenary-chief-got-UK-money-laundering-checks-submitting-mothers-gas-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 10:31:15+00:00

Yevgeny Prigozhin was under sanctions in 2021 by the US, EU and US when British law firm Discreet Law requested identification documents from him as part of anti-money laundering checks.

## Perth father brutally bashed to death in Bali after drunken argument
 - [https://www.dailymail.co.uk/news/article-11788521/Perth-father-brutally-bashed-death-Bali-drunken-argument.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788521/Perth-father-brutally-bashed-death-Bali-drunken-argument.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 10:29:24+00:00

Troy Scott Johnston, 40, was found by his wife at the Uncle Benz Cafe in South Kuta, Indonesia. He was lying in a pool of his own blood and was rushed to hospital.

## How you can cook turnips to liven up your dinner (amid a drought of other options)
 - [https://www.dailymail.co.uk/news/article-11788401/How-cook-turnips-liven-dinner-amid-drought-options.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788401/How-cook-turnips-liven-dinner-amid-drought-options.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 10:20:33+00:00

Therese Coffey emphasised that it was 'important' to 'cherish' turnips amid a national food shortage. So, MailOnline took to compiling a list of the most unexpected recipes.

## Couple face £160,000 bill after losing legal battle against 'monstrous' millionaire neighbours
 - [https://www.dailymail.co.uk/news/article-11788527/Couple-face-160-000-bill-losing-legal-battle-against-monstrous-millionaire-neighbours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788527/Couple-face-160-000-bill-losing-legal-battle-against-monstrous-millionaire-neighbours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:59:28+00:00

Gary and Kerry Hambling have lost a long-running bitter legal battle with their millionaire neighbours over  a fence erected along the side of their property near Polstead, Suffolk.

## Greengrocers have 'queues out the door' despite vegetable crisis
 - [https://www.dailymail.co.uk/news/article-11788317/Greengrocers-queues-door-despite-vegetable-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788317/Greengrocers-queues-door-despite-vegetable-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:56:25+00:00

Thomas Hagon, 39, from Reg The Veg green grocers in Clifton, Bristol, claimed 'the produce is there for supermarkets to purchase but higher prices have turned the chains off'.

## Putin 'knows he is in trouble' after a year-long conflict with Ukraine, says former FSB chief
 - [https://www.dailymail.co.uk/news/article-11788309/Putin-knows-trouble-year-long-conflict-Ukraine-says-former-FSB-chief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788309/Putin-knows-trouble-year-long-conflict-Ukraine-says-former-FSB-chief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:52:53+00:00

The Russian dictator has badly misread the West's resolve to stand up to him, and did not realise his army's incompetence, according to the former chief of the Moscow division of the FSB.

## Nicola Bulley's friends hold emotional candlelit vigil in Essex after her body is found
 - [https://www.dailymail.co.uk/news/article-11788307/Nicola-Bulleys-friends-hold-emotional-candlelit-vigil-Essex-body-found.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788307/Nicola-Bulleys-friends-hold-emotional-candlelit-vigil-Essex-body-found.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:44:43+00:00

A crowd of about 250 mourners gathered  at the bandstand in South Woodham, Ferrers, Essex, where Nicola Bulley grew up, lighting candles and leaving flowers in honour of the 45-year-old mother.

## Large stretch of the M25 is blocked after horror multi-vehicle collision
 - [https://www.dailymail.co.uk/news/article-11788515/Large-stretch-M25-blocked-horror-multi-vehicle-collision.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788515/Large-stretch-M25-blocked-horror-multi-vehicle-collision.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:26:06+00:00

The M25 motorway is closed off this morning following a multi-vehicle pile-up. The anti-clockwise carriageway has been closed between junction 23 at South Mimms and junction 22 at St Albans.

## Brits warned over popular air fryers as models costing £98-£115 are recalled
 - [https://www.dailymail.co.uk/news/article-11788363/Brits-warned-popular-air-fryers-models-costing-98-115-recalled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788363/Brits-warned-popular-air-fryers-models-costing-98-115-recalled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:26:03+00:00

Two million Cosori air fryers are being recalled. MailOnline has found two of the recalled models were available on the UK Amazon site.

## Woman bites off rapist's TONGUE and hands it in to police as evidence
 - [https://www.dailymail.co.uk/news/article-11788465/Woman-bites-rapists-TONGUE-hands-police-evidence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788465/Woman-bites-rapists-TONGUE-hands-police-evidence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:25:03+00:00

The 57-year-old woman was walking her dog at 4am on Sunday 19 February in the Saint-Jean district in Avignon, France, when a man in his thirties sexually assaulted her. Pictured: File image

## Councillor in meeting with Jackie Weaver says life has been 'hell' since viral clip
 - [https://www.dailymail.co.uk/news/article-11788345/Councillor-meeting-Jackie-Weaver-says-life-hell-viral-clip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788345/Councillor-meeting-Jackie-Weaver-says-life-hell-viral-clip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:18:38+00:00

Aled Brewerton, 46, who represented the West Ward and has since resigned from his position, claims he received death threats in the aftermath of the Jackie Weaver Zoom meeting row

## Brittany Higgins receives an 'unreserved apology' from Liberal Party veteran Robyn Nolan
 - [https://www.dailymail.co.uk/news/article-11788153/Brittany-Higgins-receives-unreserved-apology-Liberal-Party-veteran-Robyn-Nolan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788153/Brittany-Higgins-receives-unreserved-apology-Liberal-Party-veteran-Robyn-Nolan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:17:47+00:00

Former politician Robyn Nolan said she was 'deeply sorry' for  'inappropriate' remarks made towards Ms Higgins, who has faced vitriol since her high profile rape case against Bruce Lehrmann.

## Poll of SNP supporters finds Kate Forbes is STILL favourite
 - [https://www.dailymail.co.uk/news/article-11788473/Poll-SNP-supporters-finds-Kate-Forbes-favourite.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788473/Poll-SNP-supporters-finds-Kate-Forbes-favourite.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:16:59+00:00

With nominations in the contest closing at noon, a poll of party supporters found 28 per cent backed Kate Forbes as the next leader.

## Mummified ancestor of Boris Johnson did NOT die of syphilis
 - [https://www.dailymail.co.uk/sciencetech/article-11788365/Mummified-ancestor-Boris-Johnson-did-NOT-die-syphilis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-11788365/Mummified-ancestor-Boris-Johnson-did-NOT-die-syphilis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 09:04:31+00:00

Branded 'Switzerland's most famous mummy', the corpse made headlines in 2018 when it was identified as Anna Catharina Bischoff, Johnson's sixth great-grandmother.

## Father slams NHS after cancer surgery refusal forcing him to raise £80k for treatment in Turkey
 - [https://www.dailymail.co.uk/news/article-11788319/Father-slams-NHS-cancer-surgery-refusal-forcing-raise-80k-treatment-Turkey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788319/Father-slams-NHS-cancer-surgery-refusal-forcing-raise-80k-treatment-Turkey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 08:59:26+00:00

Cancer-stricken father Don Jackson (pictured), 50s and from York, who was 'left to die' after being refused an NHS liver transplant says he'd been forced to fly to Turkey for £80,000 treatment.

## UK could give Typhoons to NATO countries that offer Kyiv MiGs
 - [https://www.dailymail.co.uk/news/article-11788289/UK-Typhoons-NATO-countries-offer-Kyiv-MiGs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788289/UK-Typhoons-NATO-countries-offer-Kyiv-MiGs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 08:32:50+00:00

Defence Secretary Ben Wallace confirmed the idea of a 'swap' is in play on the first anniversary of the Russian invasion.

## Price of pasta DOUBLES in two years to 95p as shopping basket of essentials soars to more than £21
 - [https://www.dailymail.co.uk/news/article-11788221/Price-pasta-DOUBLES-two-years-95p-shopping-basket-essentials-soars-21.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788221/Price-pasta-DOUBLES-two-years-95p-shopping-basket-essentials-soars-21.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 08:25:15+00:00

Changes in the average cost of 15 food items, including oven chips and a jar of jam, have been monitored by retail research firm Assosia at supermarkets such as Asda and Tesco.

## UVA board member's text messages reveal rants against anti-Jefferson faction
 - [https://www.dailymail.co.uk/news/article-11788023/UVA-board-members-text-messages-reveal-rants-against-anti-Jefferson-faction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788023/UVA-board-members-text-messages-reveal-rants-against-anti-Jefferson-faction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 07:45:25+00:00

Ellis in the messages declared a 'battle royale for the soul of UVA' and slammed attempts to distance the school from Thomas Jefferson, the third US president and UVA's founder.

## Ukraine war: President Zelensky marks the anniversary of Russia's invasion with a defiant message
 - [https://www.dailymail.co.uk/news/article-11788139/Ukraine-war-President-Zelensky-marks-anniversary-Russias-invasion-defiant-message.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788139/Ukraine-war-President-Zelensky-marks-anniversary-Russias-invasion-defiant-message.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 07:44:24+00:00

Ukrainian President Volodymyr Zelensky today marked  the first anniversary of Russia's full-scale invasion  with a sombre message of defiance to his people.

## Roselands stabbing: Man, 24, stabbed to death in horror playground brawl at Leonard Reserve
 - [https://www.dailymail.co.uk/news/article-11787965/Roselands-stabbing-Man-24-stabbed-death-horror-playground-brawl-Leonard-Reserve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787965/Roselands-stabbing-Man-24-stabbed-death-horror-playground-brawl-Leonard-Reserve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 07:43:10+00:00

Ghassan Mohammed, 24, suffered multiple stab wounds before he died at Leonard Reserve in Roselands, south-west Sydney, just before 10pm on Thursday night.

## Winter storm: 730K without power in Michigan as LA faces blizzard warning in mountain regions
 - [https://www.dailymail.co.uk/news/article-11787939/Winter-storm-730K-without-power-Michigan-LA-faces-blizzard-warning-mountain-regions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787939/Winter-storm-730K-without-power-Michigan-LA-faces-blizzard-warning-mountain-regions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 07:40:05+00:00

At least one person has died as a result of the 2,000 mile wide storm that swept across the United States this week, with a potential hypothermia death being reported in Oregon.

## Radio 2 fans vow to switch off with Vernon Kay, 48, 'set to take over' from Ken Bruce
 - [https://www.dailymail.co.uk/news/article-11788103/Radio-2-fans-vow-switch-Vernon-Kay-48-set-Ken-Bruce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788103/Radio-2-fans-vow-switch-Vernon-Kay-48-set-Ken-Bruce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 07:39:10+00:00

The veteran DJ, 72, will step down from his show in just over a month before moving over to rival Greatest Hits radio, with Kay signing a lucrative two-year deal to take his place in the job.

## Ambulance crews, health and social care workers stage final day of strike action
 - [https://www.dailymail.co.uk/news/article-11784473/Ambulance-crews-health-social-care-workers-stage-final-day-strike-action.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11784473/Ambulance-crews-health-social-care-workers-stage-final-day-strike-action.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 07:36:57+00:00

Strikes across the country continue today (February 24) as everyone from ambulance workers to DVLA staff walk out in protest of stagnating pay and poor working conditions

## PICTURED: Five co-workers killed as twin-engine plane crashed shortly after takeoff in Arkansas
 - [https://www.dailymail.co.uk/news/article-11788005/PICTURED-Five-workers-killed-twin-engine-plane-crashed-shortly-takeoff-Arkansas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11788005/PICTURED-Five-workers-killed-twin-engine-plane-crashed-shortly-takeoff-Arkansas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 07:29:47+00:00

Five consultants killed in the plane crash worked at The Center for Toxicology and Environmental Health, and were traveling to Ohio to respond to a deadly explosion at a manufacturing plant.

## Arizona rancher is released from custody on $1M bond with money from Christian donation website
 - [https://www.dailymail.co.uk/news/article-11787835/Arizona-rancher-released-custody-1M-bond-money-Christian-donation-website.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787835/Arizona-rancher-released-custody-1M-bond-money-Christian-donation-website.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 06:46:08+00:00

Arizona rancher George Alan Kelly - who is charged with murdering a migrant by shooting him dead on his land last month - was released from custody Thursday on a $1million bond.

## The Biden administration's $113 billion aid to Ukraine: How it has been spent
 - [https://www.dailymail.co.uk/news/article-11785537/The-Biden-administrations-113-billion-aid-Ukraine-spent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11785537/The-Biden-administrations-113-billion-aid-Ukraine-spent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 06:39:05+00:00

The bill on the first anniversary of Vladimir Putin's invasion confirms the U.S. is by far the world's biggest contributor to Volodymyr Zelensky's war effort.

## Doubleview Primary School, Perth cancels Year 6 camp due to 'teacher workloads'
 - [https://www.dailymail.co.uk/news/article-11787521/Doubleview-Primary-School-Perth-cancels-Year-6-camp-teacher-workloads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787521/Doubleview-Primary-School-Perth-cancels-Year-6-camp-teacher-workloads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 06:22:39+00:00

The Doubleview Primary School, in Perth, told parents last week the annual two-night excursion at Ern Halliday Recreation Camp would not go ahead.

## PICTURED: Photographer wounded in Florida shooting rampage which killed his journalist co-worker
 - [https://www.dailymail.co.uk/news/article-11787893/PICTURED-Photographer-wounded-Florida-shooting-rampage-killed-journalist-worker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787893/PICTURED-Photographer-wounded-Florida-shooting-rampage-killed-journalist-worker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 06:19:07+00:00

Jesse Walden is a photojournalist who was injured in a Florida shooting rampage that took the life of his reporter colleague Dylan Lyons and a nine-year-old girl.

## Business Council boss Tim Reed on impact of falling education standards on Australian businesses
 - [https://www.dailymail.co.uk/news/article-11787633/Business-Council-boss-Tim-Reed-impact-falling-education-standards-Australian-businesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787633/Business-Council-boss-Tim-Reed-impact-falling-education-standards-Australian-businesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 06:07:04+00:00

Business Council of Australia President Tim Reed has told a conference the nation's businesses are having to bring school leavers up to speed due to falling education standards.

## Spy hive busted by ASIO reportedly linked to Russia
 - [https://www.dailymail.co.uk/news/article-11787807/Spy-hive-busted-ASIO-reportedly-linked-Russia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787807/Spy-hive-busted-ASIO-reportedly-linked-Russia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 05:57:04+00:00

The agents were trying to recruit Australians with access to classified information to steal data.

## Mum fined for holding Bluey toy phone while driving by a traffic camera at Princess Highway Tempe
 - [https://www.dailymail.co.uk/news/article-11787699/Mum-fined-holding-Bluey-toy-phone-driving-traffic-camera-Princess-Highway-Tempe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787699/Mum-fined-holding-Bluey-toy-phone-driving-traffic-camera-Princess-Highway-Tempe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 05:52:22+00:00

A mother has been slapped with a $362 fine after being captured by a mobile phone camera for holding her daughter's Bluey toy phone while on the Princess Highway at Tempe in inner Sydney.

## Prisoner who killed body-in-the-barrel murderer Zlatko Sikorsky causes a scene in court
 - [https://www.dailymail.co.uk/news/article-11787733/zlatko-sikorsky-larissa-beilby-isaac-james-martin-bizarre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787733/zlatko-sikorsky-larissa-beilby-isaac-james-martin-bizarre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 05:50:23+00:00

Zlatko Sikorsky, 37, was on remand at Wolston Correctional Centre in Queensland awaiting trial for killing his teenage girlfriend Larissa Beilby when he was attacked.

## Warner Bros. Discovery posts $217M loss in its streaming business
 - [https://www.dailymail.co.uk/news/article-11787823/Warner-Bros-Discovery-posts-217M-loss-streaming-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787823/Warner-Bros-Discovery-posts-217M-loss-streaming-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 05:48:50+00:00

CEO David Zaslav said that after completing 10 months of restructuring, the media company now looks to 'take full advantage' of its roster of globally recognized franchises.

## Crocodile shot dead after attacking Alister MacPhee at Bloomfield boat ramp, near Cairns
 - [https://www.dailymail.co.uk/news/article-11787825/Crocodile-shot-dead-attacking-Alister-MacPhee-Bloomfield-boat-ramp-near-Cairns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787825/Crocodile-shot-dead-attacking-Alister-MacPhee-Bloomfield-boat-ramp-near-Cairns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 05:32:04+00:00

Alister MacPhee and his dog were going for a Wednesday evening dip at Bloomfield boat ramp, north of Cairns, when the reptile erupted from the shallows, latched onto his leg and knocked him over.

## Good Samaritan tackles drunk driver who tried to flee scene of deadly crash in shocking video
 - [https://www.dailymail.co.uk/news/article-11787695/Good-Samaritan-tackles-drunk-driver-tried-flee-scene-deadly-crash-shocking-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787695/Good-Samaritan-tackles-drunk-driver-tried-flee-scene-deadly-crash-shocking-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 05:31:05+00:00

Shocking video from the scene of a crash in Texas shows the moments a Good Samaritan chased down a drunk driver who ran a red light and slammed into a car, killing an off-duty police officer.

## Fashion label Alice McCall owes more than $1million with ATO its biggest debtor
 - [https://www.dailymail.co.uk/news/article-11787223/Fashion-label-Alice-McCall-owes-1million-ATO-biggest-debtor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787223/Fashion-label-Alice-McCall-owes-1million-ATO-biggest-debtor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 05:26:32+00:00

The Australian fashion label went into liquidation last Friday with Matthew Kucianski of Worrells  appointed as the liquidator.

## Powerful photo of homeless man sleeping near Sydney Harbour divides internet
 - [https://www.dailymail.co.uk/news/article-11787503/Powerful-photo-homeless-man-sleeping-near-Sydney-Harbour-divides-internet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787503/Powerful-photo-homeless-man-sleeping-near-Sydney-Harbour-divides-internet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 05:24:34+00:00

A powerful photo of a homeless person sleeping rough in one of Australia's most recognisable parks has divided the internet.

## Face of Alice Springs crisis in 7-month campaign of hate against rival
 - [https://www.dailymail.co.uk/news/article-11786911/Face-Alice-Springs-crisis-7-month-campaign-hate-against-rival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786911/Face-Alice-Springs-crisis-7-month-campaign-hate-against-rival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 04:43:45+00:00

Controversial Outback nurse Rachel Hale has narrowly avoided jail for terrorising a beauty salon rival with menacing messages and a torrent of fake damaging reviews on Facebook and Instagram.

## Adriana Kuch: Teen attacker hit with additional charge of conspiracy to commit aggravated assault
 - [https://www.dailymail.co.uk/news/article-11787443/Adriana-Kuch-Teen-attacker-hit-additional-charge-conspiracy-commit-aggravated-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787443/Adriana-Kuch-Teen-attacker-hit-additional-charge-conspiracy-commit-aggravated-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 04:38:27+00:00

One of four girls accused of brutally attacking a New Jersey teen who later committed suicide is facing a conspiracy to commit aggravated assault charge on top of a previous harassment charge.

## Tennessee county that includes Memphis launches slavery reparations study
 - [https://www.dailymail.co.uk/news/article-11787549/Tennessee-county-includes-Memphis-launches-slavery-reparations-study.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787549/Tennessee-county-includes-Memphis-launches-slavery-reparations-study.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 04:38:12+00:00

The Shelby County Board of Commissioners voted on the measure on Wednesday, which allocates $5 million to fund a feasibility study to 'establish, develop, and implement reparations.'

## Cop who slammed lockdown protestor to the ground at Melbourne's Flinders Street station cleared
 - [https://www.dailymail.co.uk/news/article-11787341/Cop-slammed-lockdown-protestor-ground-Melbournes-Flinders-Street-station-cleared.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787341/Cop-slammed-lockdown-protestor-ground-Melbournes-Flinders-Street-station-cleared.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 04:34:09+00:00

Victorian police officer Beau Barrett has been cleared after a magistrate threw his case out. The acting sergeant faced charges after he slammed a lockdown protester to the ground in Melbourne.

## Margaret River Western Australia: Rider and horse encounter dolphins on beach
 - [https://www.dailymail.co.uk/news/article-11787297/Margaret-River-Western-Australia-Rider-horse-encounter-dolphins-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787297/Margaret-River-Western-Australia-Rider-horse-encounter-dolphins-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 04:29:17+00:00

Tour guide Emma Gibbons and her mare Wolfy encountered three dolphins at Forrest Beach near Busselton in Western Australia's Margaret River region.

## Bestselling author and 2020 candidate Marianne Williamson to challenge Joe Biden in Democrat primary
 - [https://www.dailymail.co.uk/news/article-11787353/Bestselling-author-2020-candidate-Marianne-Williamson-challenge-Joe-Biden-Democrat-primary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787353/Bestselling-author-2020-candidate-Marianne-Williamson-challenge-Joe-Biden-Democrat-primary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 04:11:04+00:00

Author and self-help guru Marianne Williamson is set to take another run at the White House , with the 2020 candidate challenging President Joe Biden in the Democratic Primary.

## China urges for the END of Russia's invasion of Ukraine as it calls for a cease-fire and peace talks
 - [https://www.dailymail.co.uk/news/article-11787489/China-urges-END-Russias-invasion-Ukraine-calls-cease-fire-peace-talks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787489/China-urges-END-Russias-invasion-Ukraine-calls-cease-fire-peace-talks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 03:48:09+00:00

On the one-year anniversary of Russia invading Ukraine, China called for a comprehensive ceasefire to the fighting and gradually promotes de-escalation and easing of the situation.

## Two million popular air fryer models are being recalled
 - [https://www.dailymail.co.uk/news/article-11787481/Two-million-popular-air-fryer-models-recalled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787481/Two-million-popular-air-fryer-models-recalled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 03:46:44+00:00

Two million Cosori air fryers, sold in the U.S., Canada and Mexico between 2018 and 2022 are being recalled after wire connections have cause hundreds of them to overheat and catch fire.

## LatitudePay closes down impacting JB HiFi, The Good Guys and Kogan customers
 - [https://www.dailymail.co.uk/news/article-11787643/LatitudePay-closes-impacting-JB-HiFi-Good-Guys-Kogan-customers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787643/LatitudePay-closes-impacting-JB-HiFi-Good-Guys-Kogan-customers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 03:46:18+00:00

Popular buy now pay later service LatitudePay is closing down.

## South Australian cleaner Tegan Martin jailed after tasering ex-boyfriend in violent home invasion
 - [https://www.dailymail.co.uk/news/article-11787013/South-Australian-cleaner-Tegan-Martin-jailed-tasering-ex-boyfriend-violent-home-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787013/South-Australian-cleaner-Tegan-Martin-jailed-tasering-ex-boyfriend-violent-home-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 03:28:31+00:00

Tegan Lee Martin, 24, rushed through the unlocked sliding doors of her ex Jacob Tiller's home in Port Lincoln, in South Australia, on October 6, 2021.

## How an empty block of land in Perth's City Beach earnt $4,000 a week over the past three years
 - [https://www.dailymail.co.uk/news/article-11786751/How-block-land-Perths-City-Beach-earnt-4-000-week-past-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786751/How-block-land-Perths-City-Beach-earnt-4-000-week-past-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 03:13:24+00:00

The 975 square-metre block of land on Chipping Rd in Perth's ritzy City Beach made a cool $620,000 for its owner, renowned builder Rob Spadaccini.

## Mysterious yellow watercraft stranded on Queensland's Double Island Point still unidentified
 - [https://www.dailymail.co.uk/news/article-11787167/Mysterious-yellow-watercraft-stranded-Queenslands-Double-Island-Point-unidentified.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787167/Mysterious-yellow-watercraft-stranded-Queenslands-Double-Island-Point-unidentified.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:58:26+00:00

The yellow object was found on the shore at Double Island Point, a beach in the Great Sandy National Park north of Queensland's Sunshine Coast on Thursday morning.

## How Anthony Albanese has been secretly trolling Penny Wong for two years
 - [https://www.dailymail.co.uk/news/article-11787025/How-Anthony-Albanese-secretly-trolling-Penny-Wong-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787025/How-Anthony-Albanese-secretly-trolling-Penny-Wong-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:45:52+00:00

Australia's foreign minister and the Prime Minister are the closest of friends as parliamentary Labor colleagues for more than two decades, even though he hadn't always had her back

## Fishmonger loses teeth in fight with brothers over stolen shrimp
 - [https://www.dailymail.co.uk/news/article-11786871/Fishmonger-loses-teeth-fight-brothers-stolen-shrimp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786871/Fishmonger-loses-teeth-fight-brothers-stolen-shrimp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:36:00+00:00

Francisco Morales had his teeth knocked out during the ordeal - but his colleague Junior Aquino Hernandez quickly rushed to his defense, grabbing a fish knife and allegedly stabbed the two brothers.

## Tesla bringing HQ back to California less than 2 years after leaving
 - [https://www.dailymail.co.uk/news/article-11787055/Tesla-bringing-HQ-California-2-years-leaving.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787055/Tesla-bringing-HQ-California-2-years-leaving.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:22:32+00:00

After less than two years in Texas, Tesla is moving its engineering headquarters back up to northern California, CEO Elon Musk announced Wednesday.

## Humza Yousaf 'skipped key vote on gay marriage' because of his religious views, source claims
 - [https://www.dailymail.co.uk/news/article-11787283/Humza-Yousaf-skipped-vote-gay-marriage-religious-views-former-colleague-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787283/Humza-Yousaf-skipped-vote-gay-marriage-religious-views-former-colleague-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:15:05+00:00

SNP leadership frontrunner Humza Yousaf has repeatedly said this week that while Islam opposes gay marriage, he does not use his faith as the basis for legislating.

## Black healthcare worker was discriminated against by NHS managers, tribunal finds
 - [https://www.dailymail.co.uk/news/article-11787393/Black-healthcare-worker-discriminated-against-NHS-managers-tribunal-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787393/Black-healthcare-worker-discriminated-against-NHS-managers-tribunal-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:13:50+00:00

Annette 'Michelle' Cox was the only black nurse working in NHS England's north region when she was discriminated against by manager Gill Paxton, a tribunal found.

## Zachary Rolfe who fatally shot Indigenous man Kumanjayi Walker says he should have got a medal
 - [https://www.dailymail.co.uk/news/article-11787023/Zachary-Rolfe-fatally-shot-Indigenous-man-Kumanjayi-Walker-says-got-medal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787023/Zachary-Rolfe-fatally-shot-Indigenous-man-Kumanjayi-Walker-says-got-medal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:10:29+00:00

Northern Territory Constable Zachary Rolfe, who fatally shot Indigenous man Kumanjayi Walker, believes he would have 'got a medal' if it had occurred in another state.

## Massive fire in Inglewood burns dozens of vintage cars
 - [https://www.dailymail.co.uk/news/article-11787389/Massive-fire-Inglewood-burns-dozens-vintage-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787389/Massive-fire-Inglewood-burns-dozens-vintage-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:03:17+00:00

The premises was reportedly home to dozens of vintage, veteran and collectors cars, which have all been burnt in the blaze.

## Only 41 per cent of UK thinks British war planes should go to Ukraine, new survey finds
 - [https://www.dailymail.co.uk/news/article-11787329/Only-41-cent-UK-thinks-British-war-planes-Ukraine-new-survey-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787329/Only-41-cent-UK-thinks-British-war-planes-Ukraine-new-survey-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:01:55+00:00

A survey found just 41 per cent of British people supported sending the planes President Zelensky pleaded for when he visited the UK earlier this month (pictured with PM Rishi Sunak in London).

## Iran-supported killer gangs are marking British Jews for potential assassination plots
 - [https://www.dailymail.co.uk/news/article-11787301/Iran-supported-killer-gangs-marking-British-Jews-potential-assassination-plots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787301/Iran-supported-killer-gangs-marking-British-Jews-potential-assassination-plots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 02:01:15+00:00

Security Minister Tom Tugendhat confirmed reports that high-profile members of the Jewish community were being tracked as revenge killings by Tehran.

## Australia Post customers are warned over new scam that's hard to detct
 - [https://www.dailymail.co.uk/news/article-11787105/Australia-Post-customers-warned-new-scam-thats-hard-detct.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787105/Australia-Post-customers-warned-new-scam-thats-hard-detct.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:56:50+00:00

Australia Post customers waiting for a parcel to arrive have been warned to look out for a new scam email that asks them to pay a 'correction service' fee for wrong address information.

## Kaz Crossley breaks her silence after being arrested and held in a Dubai prison
 - [https://www.dailymail.co.uk/tvshowbiz/article-11786375/Kaz-Crossley-breaks-silence-arrested-held-Dubai-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11786375/Kaz-Crossley-breaks-silence-arrested-held-Dubai-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:49:52+00:00

The British reality star, 27, has broken her silence after being arrested in the United Arab Emirates on suspicion of drug offences and held in a Dubai prison.

## Orlando teacher slammed after posting video showing white students bowing down to black students
 - [https://www.dailymail.co.uk/news/article-11786709/Orlando-teacher-slammed-posting-video-showing-white-students-bowing-black-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786709/Orlando-teacher-slammed-posting-video-showing-white-students-bowing-black-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:39:49+00:00

A sixth-grade teacher in Florida is being slammed after he posted a video showing white students bowing down to black students during a Black History Month skit.

## Prince Andrew says he's going nowhere after signing a £250-a-week lease for the next 75 YEARS
 - [https://www.dailymail.co.uk/news/article-11787137/Prince-Andrew-says-hes-going-signing-250-week-lease-75-YEARS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787137/Prince-Andrew-says-hes-going-signing-250-week-lease-75-YEARS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:38:42+00:00

There are mounting reports he may be forced out after the King indicated he would slash Andrew's allowance of £250,000 by April as part of his plan to reduce costs.

## Joe Rogan causes a stir as he slams the bald eagle - 'a f***ing soulless, evil creature'
 - [https://www.dailymail.co.uk/news/article-11786965/Joe-Rogan-causes-stir-slams-bald-eagle-f-ing-soulless-evil-creature.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786965/Joe-Rogan-causes-stir-slams-bald-eagle-f-ing-soulless-evil-creature.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:38:05+00:00

Comedian Joe Rogan went after the official symbol of America, the bald eagle, during a riff on his wildly successful podcast - which has been controversial as ever lately - on Thursday.

## Hollywood Sign gets a dusting of snow as twin winter storms barrel across the US
 - [https://www.dailymail.co.uk/news/article-11786799/Hollywood-Sign-gets-dusting-snow-twin-winter-storms-barrel-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786799/Hollywood-Sign-gets-dusting-snow-twin-winter-storms-barrel-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:36:03+00:00

The famed Hollywood Sign got a dusting of snow on Thursday morning, as a storm that paralyzed Portland, Oregon with almost a foot of snow bore down on Los Angeles.

## Health chiefs are modelling worst-case bird flu scenarios in case killer virus jumps to humans
 - [https://www.dailymail.co.uk/health/article-11786059/Health-chiefs-modelling-worst-case-bird-flu-scenarios-case-killer-virus-jumps-humans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11786059/Health-chiefs-modelling-worst-case-bird-flu-scenarios-case-killer-virus-jumps-humans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:32:56+00:00

UK scientists are modelling a worst-case scenario bird flu outbreak amid reports that an 11-year-old girl died of the disease in Cambodia - while a dozen others are believed to be infected.

## Tegan George lodges new claims against Network Ten Canberra bureau and Peter van Onselen
 - [https://www.dailymail.co.uk/news/article-11783183/Tegan-George-lodges-new-claims-against-Network-Ten-Canberra-bureau-Peter-van-Onselen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11783183/Tegan-George-lodges-new-claims-against-Network-Ten-Canberra-bureau-Peter-van-Onselen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:28:54+00:00

The legal stoush between political reporter Tegan George and Network Ten took another turn today as she made fresh allegations against her employer and its network's star political editor Peter van Onselen.

## Bronze Age child's shoe suggests problem of toddlers dropping things stretches back 3,000 years
 - [https://www.dailymail.co.uk/news/article-11787153/Bronze-Age-childs-shoe-suggests-problem-toddlers-dropping-things-stretches-3-000-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787153/Bronze-Age-childs-shoe-suggests-problem-toddlers-dropping-things-stretches-3-000-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:14:42+00:00

A 3,000-year-old toddler's shoe (pictured) from the Bronze Age, dating from between 888 and 781BC, was discovered in a north Kent riverbed by archaeologist Steve Tomlinson, 51.

## Greens MP Amy MacMahon called out by Annastacia Palaszczuk over Raymond Park Brisbane Olympics post
 - [https://www.dailymail.co.uk/news/article-11786787/Greens-MP-Amy-MacMahon-called-Annastacia-Palaszczuk-Raymond-Park-Brisbane-Olympics-post.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786787/Greens-MP-Amy-MacMahon-called-Annastacia-Palaszczuk-Raymond-Park-Brisbane-Olympics-post.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:08:15+00:00

Greens MP for South Brisbane Amy MacMahon took a potshot at Queensland Premier Annastacia Palaszczuk's government on Thursday - but it backfired badly.

## DAILY MAIL COMMENT: Make this Ukraine's last year of horror
 - [https://www.dailymail.co.uk/news/article-11787239/DAILY-MAIL-COMMENT-Make-Ukraines-year-horror.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787239/DAILY-MAIL-COMMENT-Make-Ukraines-year-horror.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 01:07:59+00:00

DAILY MAIL COMMENT: A year on from the unleashing of horrors so recently unthinkable in Europe, the war hangs in the balance. The free world is at a fork in the track.

## 'Greenwashing' power plant operator Drax sparks fury after its profits soar to £730 million
 - [https://www.dailymail.co.uk/news/article-11787033/Greenwashing-power-plant-operator-Drax-sparks-fury-profits-soar-730-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787033/Greenwashing-power-plant-operator-Drax-sparks-fury-profits-soar-730-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:57:56+00:00

Drax, which runs a biomass power plant in Selby, North Yorkshire, burning wood pellets, reported a profit of £731million for last year - up from £398million in 2021.

## Rental Market Crisis: Tenants at Meriton Suites Waterloo in Sydney see rent increased by 45 per cent
 - [https://www.dailymail.co.uk/news/article-11786669/Rental-Market-Crisis-Tenants-Meriton-Suites-Waterloo-Sydney-rent-increased-45-cent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786669/Rental-Market-Crisis-Tenants-Meriton-Suites-Waterloo-Sydney-rent-increased-45-cent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:53:42+00:00

Residential development giant, Meriton, sent tenants of its apartment complex at Waterloo in inner Sydney a notice on Tuesday that their rent would be increasing by 45 per cent.

## Party leaders back Queen Consort Camilla's plan to honour Britain's volunteers at the coronation
 - [https://www.dailymail.co.uk/news/article-11787213/Party-leaders-Queen-Consort-Camillas-plan-honour-Britains-volunteers-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787213/Party-leaders-Queen-Consort-Camillas-plan-honour-Britains-volunteers-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:49:42+00:00

Prime Minister Rishi Sunak, Labour leader Sir Keir Starmer and the Lib Dem's Sir Ed Davey all praised the 'fantastic' Coronation Champions Awards to celebrate those who go the extra mile.

## Diana's 'favourite designer' picked by Queen Camilla to make her gown for King Charles's coronation
 - [https://www.dailymail.co.uk/news/article-11787129/Dianas-favourite-designer-picked-Queen-Camilla-make-gown-King-Charless-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787129/Dianas-favourite-designer-picked-Queen-Camilla-make-gown-King-Charless-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:48:07+00:00

Oldfield, 72, had a professional relationship with Diana for 10 years and designed some of her most well known outfits.

## NYC billionaire financier Thomas H. Lee, 78, found dead of a self-inflicted gunshot wound
 - [https://www.dailymail.co.uk/news/article-11787061/NYC-billionaire-financier-Thomas-H-Lee-78-dead-self-inflicted-gunshot-wound.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787061/NYC-billionaire-financier-Thomas-H-Lee-78-dead-self-inflicted-gunshot-wound.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:40:54+00:00

Billionaire financier and investor Thomas H. Lee, 78, was found dead of a self-inflicted gunshot wound at his office on Fifth Avenue in Manhattan.

## Superannuation: Assistant treasurer Stephen Jones refers to Aussies' retirement savings as honey
 - [https://www.dailymail.co.uk/news/article-11786549/Superannuation-Assistant-treasurer-Stephen-Jones-refers-Aussies-retirement-savings-honey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786549/Superannuation-Assistant-treasurer-Stephen-Jones-refers-Aussies-retirement-savings-honey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:40:33+00:00

The assistant treasurer compared retirement savings of Australians to honey that should be managed 'in the best interests of the hive' at a conference in Melbourne.

## Westpac expecting three more interest rate rises and a 4.1 per cent Reserve Bank cash rate by May
 - [https://www.dailymail.co.uk/news/article-11786947/Westpac-expecting-three-rate-rises-4-1-cent-Reserve-Bank-cash-rate-May.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786947/Westpac-expecting-three-rate-rises-4-1-cent-Reserve-Bank-cash-rate-May.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:40:23+00:00

Westpac has become the latest of the Big Four banks to now be expecting three more rate rises by May that will take the Reserve Bank cash rate to an 11-year high of 4.1 per cent.

## More than 25,000 children have rotting teeth removed in 2022 as extractions increase by 83 per cent
 - [https://www.dailymail.co.uk/news/article-11787041/More-25-000-children-rotting-teeth-removed-2022-extractions-increase-83-cent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787041/More-25-000-children-rotting-teeth-removed-2022-extractions-increase-83-cent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:39:16+00:00

Data from the Government's Office for Health Improvement and Disparities shows 42,180 extraction operations took place in NHS hospitals in England in 2021/22 for those aged 19 and under.

## Australia Post is called out over major fail that's annoying customers
 - [https://www.dailymail.co.uk/news/article-11786341/Australia-Post-called-major-fail-thats-annoying-customers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786341/Australia-Post-called-major-fail-thats-annoying-customers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:34:24+00:00

Frustrated Aussies slammed Australia Post for its long queues, 'slow' staff and leaving parcel slips instead of their packages.

## Danny Dyer hints at a secret feud with his EastEnders co-stars
 - [https://www.dailymail.co.uk/tvshowbiz/article-11787007/Danny-Dyer-hints-secret-feud-EastEnders-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11787007/Danny-Dyer-hints-secret-feud-EastEnders-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:33:51+00:00

Speaking on The Jonathan Ross Show, which airs on Saturday, the soap actor adds that 'does miss' many of the stars he worked with on the show, and he 'loves them dearly.'

## Let them eat turnips! Therese Coffey tells families to buy British veg to battle food shortages
 - [https://www.dailymail.co.uk/news/article-11787127/Let-eat-turnips-Therese-Coffey-tells-families-buy-British-veg-battle-food-shortages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11787127/Let-eat-turnips-Therese-Coffey-tells-families-buy-British-veg-battle-food-shortages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:24:47+00:00

Therese Coffey told MPs the 'temporary' shortages were caused by 'very unusual weather' but were expected to end in another four weeks.

## Uterus transplant at Sydney's Royal Hospital for Women: Michelle Hayton gives womb to Kirsty Bryant
 - [https://www.dailymail.co.uk/news/article-11786473/Uterus-transplant-Sydneys-Royal-Hospital-Women-Michelle-Hayton-gives-womb-Kirsty-Bryant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786473/Uterus-transplant-Sydneys-Royal-Hospital-Women-Michelle-Hayton-gives-womb-Kirsty-Bryant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:10:56+00:00

Kirsty Bryant, 29, and her mum Michelle Hayton, 53, from Coffs Harbour on NSW's Central Coast, underwent the successful surgery at Sydney's Royal Hospital for Women on January 10.

## Rolls-Royce and BAE Systems join the calls for Jeremy Hunt to scrap planned hike on corporation tax
 - [https://www.dailymail.co.uk/news/article-11786981/Rolls-Royce-BAE-Systems-join-calls-Jeremy-Hunt-scrap-planned-hike-corporation-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786981/Rolls-Royce-BAE-Systems-join-calls-Jeremy-Hunt-scrap-planned-hike-corporation-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:07:40+00:00

Industrial giants Rolls-Royce and BAE Systems yesterday called on Jeremy Hunt to deliver 'the right tax policy' on business to boost the economy.

## Budget supermarket food sees annual price rises soar by 21.5 per cent as families struggle
 - [https://www.dailymail.co.uk/news/article-11786973/Budget-supermarket-food-sees-annual-price-rises-soar-21-5-cent-families-struggle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11786973/Budget-supermarket-food-sees-annual-price-rises-soar-21-5-cent-families-struggle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-24 00:07:28+00:00

The figures come from consumer champions at Which?, who say they demonstrate that it is the poorest households which are being worst hit by soaring food bills.

