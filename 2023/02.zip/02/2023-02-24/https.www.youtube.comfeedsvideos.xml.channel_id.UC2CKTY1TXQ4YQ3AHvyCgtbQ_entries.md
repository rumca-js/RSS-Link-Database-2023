# Source:Tabletop Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ, language:en-US

## Why Big Battle Reports are a BAD IDEA
 - [https://www.youtube.com/watch?v=7MoQXN6JxMg](https://www.youtube.com/watch?v=7MoQXN6JxMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ
 - date published: 2023-02-24 08:00:03+00:00

I don't think the idea of big-sized battle reports make sense, and I'll tell you why.

This episode's shirt is available here: https://shop.snarlingbadger.com/products/space-station-zero-yellow-logo

Vince Venturella and I made another game! Check out Space Station Zero at http://www.spacestationzerogame.com

I'm now a partner on Twitch! I paint minis every Friday morning and Monday night, and sometimes take paint breaks (play video games poorly). Follow me: http://www.twitch.tv/tabletopminions

Official Tabletop Minions t-shirts: http://bit.ly/merchbunker

Help support the channel on Patreon, and get access to the Discord: http://www.patreon.com/tabletopminions

Twitter: http://www.twitter.com/tabletopminions
Instagram: http://www.instagram.com/tabletopminions

