# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Pentagon to China: Arming Russia in Ukraine ‘Would Cause Needless Suffering’
 - [http://www.msn.com/en-us/news/world/pentagon-to-china-arming-russia-in-ukraine-would-cause-needless-suffering/ar-AA17U5T2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pentagon-to-china-arming-russia-in-ukraine-would-cause-needless-suffering/ar-AA17U5T2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 23:48:30.996925+00:00



## I told friends I'd play football, but war broke out
 - [http://www.msn.com/en-us/news/world/i-told-friends-i-d-play-football-but-war-broke-out/ar-AA17U3py?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/i-told-friends-i-d-play-football-but-war-broke-out/ar-AA17U3py?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 23:48:30.987718+00:00



## Harvey Weinstein timeline: How allegations came to trial, resulting in prison for the rest of the ex-producer's life.
 - [http://www.msn.com/en-us/news/crime/harvey-weinstein-timeline-how-allegations-came-to-trial-resulting-in-prison-for-the-rest-of-the-ex-producer-s-life/ar-AA17UsZT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/harvey-weinstein-timeline-how-allegations-came-to-trial-resulting-in-prison-for-the-rest-of-the-ex-producer-s-life/ar-AA17UsZT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 23:48:30.979987+00:00



## Black TikToker Says Woman Called the Cops on Him for Shoveling Snow
 - [http://www.msn.com/en-us/news/world/black-tiktoker-says-woman-called-the-cops-on-him-for-shoveling-snow/ar-AA17U601?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/black-tiktoker-says-woman-called-the-cops-on-him-for-shoveling-snow/ar-AA17U601?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 23:48:30.972706+00:00



## How Jimmy Carter put Habitat for Humanity ‘on the map’
 - [http://www.msn.com/en-us/news/politics/how-jimmy-carter-put-habitat-for-humanity-on-the-map/ar-AA17UgTk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/how-jimmy-carter-put-habitat-for-humanity-on-the-map/ar-AA17UgTk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 23:48:30.965385+00:00



## Florida Democrats look to stave off irrelevance with new leader
 - [http://www.msn.com/en-us/news/politics/florida-democrats-look-to-stave-off-irrelevance-with-new-leader/ar-AA17UmhY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/florida-democrats-look-to-stave-off-irrelevance-with-new-leader/ar-AA17UmhY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 23:48:30.957764+00:00



## Pence says he is nearing a decision on 2024 presidential bid
 - [http://www.msn.com/en-us/news/politics/pence-says-he-is-nearing-a-decision-on-2024-presidential-bid/ar-AA17UtdS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pence-says-he-is-nearing-a-decision-on-2024-presidential-bid/ar-AA17UtdS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 23:48:30.950513+00:00



## Ozy Media head Carlos Watson: ‘I am not now and never have been a “con man”‘
 - [http://www.msn.com/en-us/news/politics/ozy-media-head-carlos-watson-i-am-not-now-and-never-have-been-a-con-man/ar-AA17UgYb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ozy-media-head-carlos-watson-i-am-not-now-and-never-have-been-a-con-man/ar-AA17UgYb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 23:48:30.942900+00:00



## Commentary: Bing and other AI programs are meant to behave like humans. Why we're shocked when they do
 - [http://www.msn.com/en-us/news/technology/commentary-bing-and-other-ai-programs-are-meant-to-behave-like-humans-why-we-re-shocked-when-they-do/ar-AA17Uajs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/commentary-bing-and-other-ai-programs-are-meant-to-behave-like-humans-why-we-re-shocked-when-they-do/ar-AA17Uajs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 22:48:47.080826+00:00



## Nurse captured on video allegedly slamming newborn onto bassinet fired from Long Island hospital
 - [http://www.msn.com/en-us/news/us/nurse-captured-on-video-allegedly-slamming-newborn-onto-bassinet-fired-from-long-island-hospital/ar-AA17UfZD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nurse-captured-on-video-allegedly-slamming-newborn-onto-bassinet-fired-from-long-island-hospital/ar-AA17UfZD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 22:48:47.073822+00:00



## Smartphones Emerge as Key Tool for War in Ukraine
 - [http://www.msn.com/en-us/news/technology/smartphones-emerge-as-key-tool-for-war-in-ukraine/vi-AA17Usor?srcref=rss](http://www.msn.com/en-us/news/technology/smartphones-emerge-as-key-tool-for-war-in-ukraine/vi-AA17Usor?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 22:48:47.066804+00:00



## California man who accused twin brother of 2 rapes in 1990s is convicted of crimes
 - [http://www.msn.com/en-us/news/crime/california-man-who-accused-twin-brother-of-2-rapes-in-1990s-is-convicted-of-crimes/ar-AA17Ucx5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/california-man-who-accused-twin-brother-of-2-rapes-in-1990s-is-convicted-of-crimes/ar-AA17Ucx5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 22:48:47.057523+00:00



## Out in Space Lies a Mysterious, Massive Planet That Shouldn't Exist
 - [http://www.msn.com/en-us/news/technology/out-in-space-lies-a-mysterious-massive-planet-that-shouldn-t-exist/ar-AA17U8TO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/out-in-space-lies-a-mysterious-massive-planet-that-shouldn-t-exist/ar-AA17U8TO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 22:48:47.050532+00:00



## Pence calls for quicker pace of getting US military aid to Ukraine
 - [http://www.msn.com/en-us/news/politics/pence-calls-for-quicker-pace-of-getting-us-military-aid-to-ukraine/ar-AA17U8TJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pence-calls-for-quicker-pace-of-getting-us-military-aid-to-ukraine/ar-AA17U8TJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 22:48:47.043425+00:00



## West Virginia MMA fighters volunteer as security for local drag show
 - [http://www.msn.com/en-us/news/us/west-virginia-mma-fighters-volunteer-as-security-for-local-drag-show/ar-AA17Ulwg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/west-virginia-mma-fighters-volunteer-as-security-for-local-drag-show/ar-AA17Ulwg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 22:48:47.035967+00:00



## 12 US states sue to expand access to abortion pill
 - [http://www.msn.com/en-us/news/world/12-us-states-sue-to-expand-access-to-abortion-pill/ar-AA17TYwi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/12-us-states-sue-to-expand-access-to-abortion-pill/ar-AA17TYwi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 21:48:27.427989+00:00



## China reminds us why the Space Force was created
 - [http://www.msn.com/en-us/news/world/china-reminds-us-why-the-space-force-was-created/ar-AA17UfDa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-reminds-us-why-the-space-force-was-created/ar-AA17UfDa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 21:48:27.420354+00:00



## Florida's new education bill would force state colleges to shut down diversity programs and remove some majors entirely
 - [http://www.msn.com/en-us/news/us/florida-s-new-education-bill-would-force-state-colleges-to-shut-down-diversity-programs-and-remove-some-majors-entirely/ar-AA17Tydc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/florida-s-new-education-bill-would-force-state-colleges-to-shut-down-diversity-programs-and-remove-some-majors-entirely/ar-AA17Tydc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 21:48:27.412426+00:00



## Boxed Mac and Cheese Doesn't Have to Be Boring, Try This
 - [http://www.msn.com/en-us/news/technology/boxed-mac-and-cheese-doesn-t-have-to-be-boring-try-this/ar-AA17QHCc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/boxed-mac-and-cheese-doesn-t-have-to-be-boring-try-this/ar-AA17QHCc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 21:48:27.405217+00:00



## Florida chihuahua named Tinkerbell rescued after 40 minutes in ocean bay
 - [http://www.msn.com/en-us/news/us/florida-chihuahua-named-tinkerbell-rescued-after-40-minutes-in-ocean-bay/ar-AA17UrT0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/florida-chihuahua-named-tinkerbell-rescued-after-40-minutes-in-ocean-bay/ar-AA17UrT0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 21:48:27.397908+00:00



## All 25 U.S. extremism-related murders last year were linked to right-wing extremists
 - [http://www.msn.com/en-us/news/crime/all-25-u-s-extremism-related-murders-last-year-were-linked-to-right-wing-extremists/ar-AA17UkKj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/all-25-u-s-extremism-related-murders-last-year-were-linked-to-right-wing-extremists/ar-AA17UkKj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 21:48:27.389387+00:00



## Wintry weather could worsen California’s sewage influx from Tijuana
 - [http://www.msn.com/en-us/news/us/wintry-weather-could-worsen-california-s-sewage-influx-from-tijuana/ar-AA17U5pW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/wintry-weather-could-worsen-california-s-sewage-influx-from-tijuana/ar-AA17U5pW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 21:48:27.381348+00:00



## Two major crypto exchanges failed to block sanctioned Russians
 - [http://www.msn.com/en-us/money/news/two-major-crypto-exchanges-failed-to-block-sanctioned-russians/ar-AA17Uig5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/money/news/two-major-crypto-exchanges-failed-to-block-sanctioned-russians/ar-AA17Uig5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 21:48:27.373818+00:00



## Florida Democrats set to pick new leader amid party turmoil
 - [http://www.msn.com/en-us/news/politics/florida-democrats-set-to-pick-new-leader-amid-party-turmoil/ar-AA17TOjq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/florida-democrats-set-to-pick-new-leader-amid-party-turmoil/ar-AA17TOjq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 20:48:25.576377+00:00



## Ohio train derailment: Joe Manchin demands answers from Buttigieg on rail safety
 - [http://www.msn.com/en-us/news/us/ohio-train-derailment-joe-manchin-demands-answers-from-buttigieg-on-rail-safety/ar-AA17TOvu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/ohio-train-derailment-joe-manchin-demands-answers-from-buttigieg-on-rail-safety/ar-AA17TOvu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 20:48:25.569140+00:00



## 5 times scientists thought they may have discovered aliens
 - [http://www.msn.com/en-us/news/technology/5-times-scientists-thought-they-may-have-discovered-aliens/ar-AA17RajD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/5-times-scientists-thought-they-may-have-discovered-aliens/ar-AA17RajD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 20:48:25.561952+00:00



## Florida bill would target diversity studies at state universities
 - [http://www.msn.com/en-us/news/us/florida-bill-would-target-diversity-studies-at-state-universities/ar-AA17UeYD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/florida-bill-would-target-diversity-studies-at-state-universities/ar-AA17UeYD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 20:48:25.554677+00:00



## A mysterious iron ball washed up on a beach in Japan. What could it be?
 - [http://www.msn.com/en-us/news/world/a-mysterious-iron-ball-washed-up-on-a-beach-in-japan-what-could-it-be/ar-AA17TYe6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-mysterious-iron-ball-washed-up-on-a-beach-in-japan-what-could-it-be/ar-AA17TYe6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 20:48:25.547021+00:00



## Facebook Parent Meta Wants to Show It's Still a Big Contender in AI Race
 - [http://www.msn.com/en-us/news/technology/facebook-parent-meta-wants-to-show-it-s-still-a-big-contender-in-ai-race/ar-AA17Uhv2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/facebook-parent-meta-wants-to-show-it-s-still-a-big-contender-in-ai-race/ar-AA17Uhv2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 20:48:25.539742+00:00



## First lady Jill Biden, on trip to Africa, maintains Biden will run again
 - [http://www.msn.com/en-us/news/politics/first-lady-jill-biden-on-trip-to-africa-maintains-biden-will-run-again/ar-AA17U1bA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/first-lady-jill-biden-on-trip-to-africa-maintains-biden-will-run-again/ar-AA17U1bA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 20:48:25.530197+00:00



## Ex-Cowboys wideout Sam Hurd released from prison after serving nearly a decade for drug trafficking: report
 - [http://www.msn.com/en-us/news/crime/ex-cowboys-wideout-sam-hurd-released-from-prison-after-serving-nearly-a-decade-for-drug-trafficking-report/ar-AA17U9QQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ex-cowboys-wideout-sam-hurd-released-from-prison-after-serving-nearly-a-decade-for-drug-trafficking-report/ar-AA17U9QQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 20:48:25.521849+00:00



## The politics of Medicare funding
 - [http://www.msn.com/en-us/news/politics/the-politics-of-medicare-funding/ar-AA17U4AS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-politics-of-medicare-funding/ar-AA17U4AS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 19:48:30.036053+00:00



## China's self-defeating economic policy
 - [http://www.msn.com/en-us/news/world/china-s-self-defeating-economic-policy/ar-AA17TTnf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-s-self-defeating-economic-policy/ar-AA17TTnf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 19:48:30.029025+00:00



## Biden immigration policy aides to depart amid criticism of new migration policy
 - [http://www.msn.com/en-us/news/politics/biden-immigration-policy-aides-to-depart-amid-criticism-of-new-migration-policy/ar-AA17TTm7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-immigration-policy-aides-to-depart-amid-criticism-of-new-migration-policy/ar-AA17TTm7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 19:48:30.021983+00:00



## Special counsel investigating Trump asks federal judge to compel Pence to testify before grand jury
 - [http://www.msn.com/en-us/news/politics/special-counsel-investigating-trump-asks-federal-judge-to-compel-pence-to-testify-before-grand-jury/ar-AA17TTvE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/special-counsel-investigating-trump-asks-federal-judge-to-compel-pence-to-testify-before-grand-jury/ar-AA17TTvE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 19:48:30.014260+00:00



## Closure of 730-job chicken factory confirmed
 - [http://www.msn.com/en-us/news/world/closure-of-730-job-chicken-factory-confirmed/ar-AA17TNXU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/closure-of-730-job-chicken-factory-confirmed/ar-AA17TNXU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 19:48:30.007284+00:00



## Navajo community wins fight to replace crumbling campus
 - [http://www.msn.com/en-us/news/us/navajo-community-wins-fight-to-replace-crumbling-campus/ar-AA17TR5w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/navajo-community-wins-fight-to-replace-crumbling-campus/ar-AA17TR5w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 19:48:30.000220+00:00



## Meta's metaverse division leaders are reportedly gathering for a summit that includes a meeting called 'Must Go Faster'
 - [http://www.msn.com/en-us/news/technology/meta-s-metaverse-division-leaders-are-reportedly-gathering-for-a-summit-that-includes-a-meeting-called-must-go-faster/ar-AA17U7hx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/meta-s-metaverse-division-leaders-are-reportedly-gathering-for-a-summit-that-includes-a-meeting-called-must-go-faster/ar-AA17U7hx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 19:48:29.991689+00:00



## It’s time to unleash the ‘Abundance Agenda’
 - [http://www.msn.com/en-us/news/politics/it-s-time-to-unleash-the-abundance-agenda/ar-AA17U7kj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/it-s-time-to-unleash-the-abundance-agenda/ar-AA17U7kj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 19:48:29.983582+00:00



## Alex Murdaugh is 'outsmarting' prosecutors on witness stand, says Ted Williams
 - [http://www.msn.com/en-us/news/crime/alex-murdaugh-is-outsmarting-prosecutors-on-witness-stand-says-ted-williams/ar-AA17TSFw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/alex-murdaugh-is-outsmarting-prosecutors-on-witness-stand-says-ted-williams/ar-AA17TSFw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 18:48:23.876352+00:00



## Wordle Today 615: Wordle Hints and Answer for February 24
 - [http://www.msn.com/en-us/news/technology/wordle-today-615-wordle-hints-and-answer-for-february-24/ar-AA179ZBN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/wordle-today-615-wordle-hints-and-answer-for-february-24/ar-AA179ZBN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 18:48:23.868457+00:00



## 'A miracle': Missing 2-year-old boy found alive in woods after 24 hours
 - [http://www.msn.com/en-us/news/crime/a-miracle-missing-2-year-old-boy-found-alive-in-woods-after-24-hours/ar-AA17TSbW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-miracle-missing-2-year-old-boy-found-alive-in-woods-after-24-hours/ar-AA17TSbW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 18:48:23.860845+00:00



## Mark Zuckerberg just announced a new AI model 'LLaMA,' designed to help researchers make chatbots less 'toxic'
 - [http://www.msn.com/en-us/news/technology/mark-zuckerberg-just-announced-a-new-ai-model-llama-designed-to-help-researchers-make-chatbots-less-toxic/ar-AA17TQdC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/mark-zuckerberg-just-announced-a-new-ai-model-llama-designed-to-help-researchers-make-chatbots-less-toxic/ar-AA17TQdC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 18:48:23.853065+00:00



## Black LGBTQ representation has more than quadrupled over five years, report finds
 - [http://www.msn.com/en-us/news/us/black-lgbtq-representation-has-more-than-quadrupled-over-five-years-report-finds/ar-AA17TlD1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/black-lgbtq-representation-has-more-than-quadrupled-over-five-years-report-finds/ar-AA17TlD1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 18:48:23.844933+00:00



## Mother's arduous walk out of Ukraine to give birth
 - [http://www.msn.com/en-us/news/world/mother-s-arduous-walk-out-of-ukraine-to-give-birth/ar-AA17TX9K?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/mother-s-arduous-walk-out-of-ukraine-to-give-birth/ar-AA17TX9K?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 18:48:23.837976+00:00



## White House braces for ruling on abortion pill's fate
 - [http://www.msn.com/en-us/news/politics/white-house-braces-for-ruling-on-abortion-pill-s-fate/ar-AA17TBF1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/white-house-braces-for-ruling-on-abortion-pill-s-fate/ar-AA17TBF1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 18:48:23.830248+00:00



## Nasal Covid vaccine shows promise in early clinical trial
 - [http://www.msn.com/en-us/health/other/nasal-covid-vaccine-shows-promise-in-early-clinical-trial/ar-AA17Tj7Q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/other/nasal-covid-vaccine-shows-promise-in-early-clinical-trial/ar-AA17Tj7Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 18:48:23.822457+00:00



## More parents moving in with their kids amid inflation
 - [http://www.msn.com/en-us/news/us/more-parents-moving-in-with-their-kids-amid-inflation/ar-AA17TRVF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/more-parents-moving-in-with-their-kids-amid-inflation/ar-AA17TRVF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 17:48:25.762493+00:00



## 'The Last of Us' Fan in Hysterics As Hotel Honors Bizarre Request: 'Sorry'
 - [http://www.msn.com/en-us/news/world/the-last-of-us-fan-in-hysterics-as-hotel-honors-bizarre-request-sorry/ar-AA17Tz2j?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-last-of-us-fan-in-hysterics-as-hotel-honors-bizarre-request-sorry/ar-AA17Tz2j?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 17:48:25.754767+00:00



## Stop Your Food From Exploding in the Microwave. Here's How
 - [http://www.msn.com/en-us/news/technology/stop-your-food-from-exploding-in-the-microwave-here-s-how/ar-AA17O0HC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/stop-your-food-from-exploding-in-the-microwave-here-s-how/ar-AA17O0HC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 17:48:25.747824+00:00



## Judge rejects media outlet requests to unseal Trump Jan. 6 probe documents
 - [http://www.msn.com/en-us/news/politics/judge-rejects-media-outlet-requests-to-unseal-trump-jan-6-probe-documents/ar-AA17TyWs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/judge-rejects-media-outlet-requests-to-unseal-trump-jan-6-probe-documents/ar-AA17TyWs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 17:48:25.740945+00:00



## Authorities in New York and Chicago warn Jewish communities to stay alert after neo-Nazi groups declare 'Day of Hate'
 - [http://www.msn.com/en-us/news/world/authorities-in-new-york-and-chicago-warn-jewish-communities-to-stay-alert-after-neo-nazi-groups-declare-day-of-hate/ar-AA17TTXq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/authorities-in-new-york-and-chicago-warn-jewish-communities-to-stay-alert-after-neo-nazi-groups-declare-day-of-hate/ar-AA17TTXq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 17:48:25.731496+00:00



## “Incredible negligence”: More classified docs found at Trump's Mar-a-Lago — months after FBI search
 - [http://www.msn.com/en-us/news/politics/incredible-negligence-more-classified-docs-found-at-trump-s-mar-a-lago-months-after-fbi-search/ar-AA17TS1z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/incredible-negligence-more-classified-docs-found-at-trump-s-mar-a-lago-months-after-fbi-search/ar-AA17TS1z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 17:48:25.723667+00:00



## Timelapse map shows how close Russia came to taking Kyiv and how Ukraine reclaimed its land over a year of war
 - [http://www.msn.com/en-us/news/world/timelapse-map-shows-how-close-russia-came-to-taking-kyiv-and-how-ukraine-reclaimed-its-land-over-a-year-of-war/ar-AA17TPsT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/timelapse-map-shows-how-close-russia-came-to-taking-kyiv-and-how-ukraine-reclaimed-its-land-over-a-year-of-war/ar-AA17TPsT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 17:48:25.715435+00:00



## United States to limit South Korean chip exports as part of tech war with China
 - [http://www.msn.com/en-us/news/technology/united-states-to-limit-south-korean-chip-exports-as-part-of-tech-war-with-china/ar-AA17THPN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/united-states-to-limit-south-korean-chip-exports-as-part-of-tech-war-with-china/ar-AA17THPN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 16:48:18.505991+00:00



## Video shows bystander chase down fleeing drunk driver who fatally hit Texas detective
 - [http://www.msn.com/en-us/news/crime/video-shows-bystander-chase-down-fleeing-drunk-driver-who-fatally-hit-texas-detective/ar-AA17TD7T?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/video-shows-bystander-chase-down-fleeing-drunk-driver-who-fatally-hit-texas-detective/ar-AA17TD7T?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 16:48:18.498869+00:00



## Ukrainian delegates welcomed by twinned university
 - [http://www.msn.com/en-us/news/world/ukrainian-delegates-welcomed-by-twinned-university/ar-AA17TKfy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukrainian-delegates-welcomed-by-twinned-university/ar-AA17TKfy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 16:48:18.488807+00:00



## DeSantis team slams HuffPo for touting cop-killer's attack on governor: 'This monster killed a police officer'
 - [http://www.msn.com/en-us/news/crime/desantis-team-slams-huffpo-for-touting-cop-killer-s-attack-on-governor-this-monster-killed-a-police-officer/ar-AA17Tijs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/desantis-team-slams-huffpo-for-touting-cop-killer-s-attack-on-governor-this-monster-killed-a-police-officer/ar-AA17Tijs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 16:48:18.481131+00:00



## 'I really want to go back to fight:' A wounded Ukrainian soldier reflects on his recovery
 - [http://www.msn.com/en-us/news/world/i-really-want-to-go-back-to-fight-a-wounded-ukrainian-soldier-reflects-on-his-recovery/ar-AA17TKkn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/i-really-want-to-go-back-to-fight-a-wounded-ukrainian-soldier-reflects-on-his-recovery/ar-AA17TKkn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 16:48:18.473915+00:00



## Kim Jong Un may be prepping his daughter as his successor because he wants a woman in charge to modernize North Korea's image, experts say
 - [http://www.msn.com/en-us/news/world/kim-jong-un-may-be-prepping-his-daughter-as-his-successor-because-he-wants-a-woman-in-charge-to-modernize-north-korea-s-image-experts-say/ar-AA17TKwx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/kim-jong-un-may-be-prepping-his-daughter-as-his-successor-because-he-wants-a-woman-in-charge-to-modernize-north-korea-s-image-experts-say/ar-AA17TKwx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 16:48:18.466594+00:00



## Rihanna’s Super Bowl show clocks more FCC complaints than Sam Smith’s ‘Satanic Mass’ at the Grammys
 - [http://www.msn.com/en-us/news/politics/rihanna-s-super-bowl-show-clocks-more-fcc-complaints-than-sam-smith-s-satanic-mass-at-the-grammys/ar-AA17THRq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rihanna-s-super-bowl-show-clocks-more-fcc-complaints-than-sam-smith-s-satanic-mass-at-the-grammys/ar-AA17THRq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 16:48:18.458582+00:00



## Russia and Ukraine: the tangled history that connects—and divides—them
 - [http://www.msn.com/en-us/news/world/russia-and-ukraine-the-tangled-history-that-connects-and-divides-them/ar-AA17TsAc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-and-ukraine-the-tangled-history-that-connects-and-divides-them/ar-AA17TsAc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 15:48:19.589209+00:00



## Ukrainians tell of hardest year of their lives
 - [http://www.msn.com/en-us/news/world/ukrainians-tell-of-hardest-year-of-their-lives/ar-AA17TGVS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukrainians-tell-of-hardest-year-of-their-lives/ar-AA17TGVS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 15:48:19.581965+00:00



## Republicans schedule first 2024 primary presidential debate for August in Milwaukee
 - [http://www.msn.com/en-us/news/politics/republicans-schedule-first-2024-primary-presidential-debate-for-august-in-milwaukee/ar-AA17Tvfm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-schedule-first-2024-primary-presidential-debate-for-august-in-milwaukee/ar-AA17Tvfm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 15:48:19.574619+00:00



## King Charles condemns Russia's 'unprovoked full-scale attack' on Ukraine. It's a huge shift from the subtle statements his mother, the Queen, made.
 - [http://www.msn.com/en-us/news/world/king-charles-condemns-russia-s-unprovoked-full-scale-attack-on-ukraine-it-s-a-huge-shift-from-the-subtle-statements-his-mother-the-queen-made/ar-AA17TEyr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/king-charles-condemns-russia-s-unprovoked-full-scale-attack-on-ukraine-it-s-a-huge-shift-from-the-subtle-statements-his-mother-the-queen-made/ar-AA17TEyr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 15:48:19.567357+00:00



## Poland sends first batch of Leopard 2 tanks to Ukraine
 - [http://www.msn.com/en-us/news/world/poland-sends-first-batch-of-leopard-2-tanks-to-ukraine/ar-AA17TzYX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/poland-sends-first-batch-of-leopard-2-tanks-to-ukraine/ar-AA17TzYX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 15:48:19.560324+00:00



## Q&A: Austin Butler on what 'Elvis' taught him about fear
 - [http://www.msn.com/en-us/news/us/q-a-austin-butler-on-what-elvis-taught-him-about-fear/ar-AA17TJt9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/q-a-austin-butler-on-what-elvis-taught-him-about-fear/ar-AA17TJt9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 15:48:19.551298+00:00



## After wasting thousands of taxpayer dollars, one Massachusetts school finally turns off its lights — left on for over a year
 - [http://www.msn.com/en-us/news/us/after-wasting-thousands-of-taxpayer-dollars-one-massachusetts-school-finally-turns-off-its-lights-left-on-for-over-a-year/ar-AA16wB39?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/after-wasting-thousands-of-taxpayer-dollars-one-massachusetts-school-finally-turns-off-its-lights-left-on-for-over-a-year/ar-AA16wB39?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 15:48:19.543618+00:00



## “Targeted for retribution”: Trump’s brag badly backfires as judge orders him to sit for deposition
 - [http://www.msn.com/en-us/news/politics/targeted-for-retribution-trump-s-brag-badly-backfires-as-judge-orders-him-to-sit-for-deposition/ar-AA17Trma?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/targeted-for-retribution-trump-s-brag-badly-backfires-as-judge-orders-him-to-sit-for-deposition/ar-AA17Trma?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 14:48:16.817525+00:00



## Marilyn Manson Abuse Accuser Backtracks: Evan Rachel Wood 'Manipulated' Me
 - [http://www.msn.com/en-us/news/crime/marilyn-manson-abuse-accuser-backtracks-evan-rachel-wood-manipulated-me/ar-AA17T8Bg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/marilyn-manson-abuse-accuser-backtracks-evan-rachel-wood-manipulated-me/ar-AA17T8Bg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 14:48:16.809879+00:00



## Former Marilyn Manson accuser alleges Evan Rachel Wood pressured her into making abuse allegations
 - [http://www.msn.com/en-us/news/crime/former-marilyn-manson-accuser-alleges-evan-rachel-wood-pressured-her-into-making-abuse-allegations/ar-AA17RCIe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/former-marilyn-manson-accuser-alleges-evan-rachel-wood-pressured-her-into-making-abuse-allegations/ar-AA17RCIe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 14:48:16.802599+00:00



## Biden ‘in trouble,’ losing to Trump 48%-44%
 - [http://www.msn.com/en-us/news/politics/biden-in-trouble-losing-to-trump-48-44/ar-AA17TfwI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-in-trouble-losing-to-trump-48-44/ar-AA17TfwI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 14:48:16.795532+00:00



## Some Starlink customers say they're nervous that SpaceX will continue hiking prices after their subscription cost jumped to $120 a month
 - [http://www.msn.com/en-us/news/technology/some-starlink-customers-say-they-re-nervous-that-spacex-will-continue-hiking-prices-after-their-subscription-cost-jumped-to-120-a-month/ar-AA17TpOw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/some-starlink-customers-say-they-re-nervous-that-spacex-will-continue-hiking-prices-after-their-subscription-cost-jumped-to-120-a-month/ar-AA17TpOw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 14:48:16.786269+00:00



## Debt-ceiling brinksmanship weakens US national security
 - [http://www.msn.com/en-us/news/politics/debt-ceiling-brinksmanship-weakens-us-national-security/ar-AA17TrWG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/debt-ceiling-brinksmanship-weakens-us-national-security/ar-AA17TrWG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 14:48:16.778419+00:00



## GOP Rep. John James won't seek Michigan's open Senate seat
 - [http://www.msn.com/en-us/news/politics/gop-rep-john-james-won-t-seek-michigan-s-open-senate-seat/ar-AA17TwNf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-rep-john-james-won-t-seek-michigan-s-open-senate-seat/ar-AA17TwNf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 14:48:16.769452+00:00



## White House announces new sanctions against Russia on invasion anniversary
 - [http://www.msn.com/en-us/news/world/white-house-announces-new-sanctions-against-russia-on-invasion-anniversary/ar-AA17T09T?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/white-house-announces-new-sanctions-against-russia-on-invasion-anniversary/ar-AA17T09T?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 13:48:15.685202+00:00



## Biden student loan Supreme Court battle revives legal test that doomed Obama climate rules
 - [http://www.msn.com/en-us/news/politics/biden-student-loan-supreme-court-battle-revives-legal-test-that-doomed-obama-climate-rules/ar-AA17SzB5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-student-loan-supreme-court-battle-revives-legal-test-that-doomed-obama-climate-rules/ar-AA17SzB5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 13:48:15.677899+00:00



## The Webb telescope may have discovered six galaxies that shouldn't exist
 - [http://www.msn.com/en-us/news/technology/the-webb-telescope-may-have-discovered-six-galaxies-that-shouldn-t-exist/ar-AA17Tdds?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-webb-telescope-may-have-discovered-six-galaxies-that-shouldn-t-exist/ar-AA17Tdds?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 13:48:15.670640+00:00



## Ukraine war: One year later... and the years ahead
 - [http://www.msn.com/en-us/news/world/ukraine-war-one-year-later-and-the-years-ahead/ar-AA17TcN6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-war-one-year-later-and-the-years-ahead/ar-AA17TcN6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 13:48:15.663504+00:00



## Russian Troops Given Unusable Shells as Ammunition Shortage Hits
 - [http://www.msn.com/en-us/news/world/russian-troops-given-unusable-shells-as-ammunition-shortage-hits/ar-AA17TmhU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-troops-given-unusable-shells-as-ammunition-shortage-hits/ar-AA17TmhU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 13:48:15.655857+00:00



## Russia-Ukraine live updates: Blinken warns China is 'contemplating lethal assistance'
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-blinken-warns-china-is-contemplating-lethal-assistance/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-blinken-warns-china-is-contemplating-lethal-assistance/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 13:48:15.648572+00:00



## US marks war anniversary with new Russia sanctions
 - [http://www.msn.com/en-us/news/world/us-marks-war-anniversary-with-new-russia-sanctions/ar-AA17SY7m?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-marks-war-anniversary-with-new-russia-sanctions/ar-AA17SY7m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 13:48:15.640804+00:00



## Meet the woman helping preserve the legacy of Black cowboys and cowgirls
 - [http://www.msn.com/en-us/news/us/meet-the-woman-helping-preserve-the-legacy-of-black-cowboys-and-cowgirls/ar-AA17T65u?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/meet-the-woman-helping-preserve-the-legacy-of-black-cowboys-and-cowgirls/ar-AA17T65u?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 13:48:15.633103+00:00



## Can this 25-year-old help solve North Carolina Democrats' problems?
 - [http://www.msn.com/en-us/news/politics/can-this-25-year-old-help-solve-north-carolina-democrats-problems/ar-AA17Sysz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/can-this-25-year-old-help-solve-north-carolina-democrats-problems/ar-AA17Sysz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 12:48:15.911676+00:00



## South Africa: Fallout over power utility CEO's graft claims
 - [http://www.msn.com/en-us/news/world/south-africa-fallout-over-power-utility-ceo-s-graft-claims/ar-AA17T6RS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/south-africa-fallout-over-power-utility-ceo-s-graft-claims/ar-AA17T6RS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 12:48:15.904486+00:00



## One year later: On grim anniversary, Zelensky declares, ‘We see the light of this victory’
 - [http://www.msn.com/en-us/news/world/one-year-later-on-grim-anniversary-zelensky-declares-we-see-the-light-of-this-victory/ar-AA17SG2N?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/one-year-later-on-grim-anniversary-zelensky-declares-we-see-the-light-of-this-victory/ar-AA17SG2N?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 12:48:15.897149+00:00



## Marilyn Manson accuser Ashley Smithline says she felt 'pressure' from Evan Rachel Wood to accuse him of 'rape and assault': report
 - [http://www.msn.com/en-us/news/crime/marilyn-manson-accuser-ashley-smithline-says-she-felt-pressure-from-evan-rachel-wood-to-accuse-him-of-rape-and-assault-report/ar-AA17T9ze?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/marilyn-manson-accuser-ashley-smithline-says-she-felt-pressure-from-evan-rachel-wood-to-accuse-him-of-rape-and-assault-report/ar-AA17T9ze?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 12:48:15.889338+00:00



## How Six Ordinary Ukrainians Have Lived Through the War
 - [http://www.msn.com/en-us/news/world/how-six-ordinary-ukrainians-have-lived-through-the-war/ar-AA17SZMM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/how-six-ordinary-ukrainians-have-lived-through-the-war/ar-AA17SZMM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 12:48:15.880927+00:00



## Lithuania's prime minister says Ukrainians should get all the weapons they want because they are dying for Europe's safety: 'We're just losing some money'
 - [http://www.msn.com/en-us/news/world/lithuania-s-prime-minister-says-ukrainians-should-get-all-the-weapons-they-want-because-they-are-dying-for-europe-s-safety-we-re-just-losing-some-money/ar-AA17T4Jy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/lithuania-s-prime-minister-says-ukrainians-should-get-all-the-weapons-they-want-because-they-are-dying-for-europe-s-safety-we-re-just-losing-some-money/ar-AA17T4Jy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 12:48:15.873154+00:00



## How to Unsend an Accidental Email on Your iPhone
 - [http://www.msn.com/en-us/news/technology/how-to-unsend-an-accidental-email-on-your-iphone/ar-AA12SkfJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-to-unsend-an-accidental-email-on-your-iphone/ar-AA12SkfJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 12:48:15.865788+00:00



## Adult training course threatened by funding cuts
 - [http://www.msn.com/en-us/news/world/adult-training-course-threatened-by-funding-cuts/ar-AA17T4TL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/adult-training-course-threatened-by-funding-cuts/ar-AA17T4TL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 12:48:15.858195+00:00



## ChatGPT is ominous, but the pen is mightier
 - [http://www.msn.com/en-us/news/us/chatgpt-is-ominous-but-the-pen-is-mightier/ar-AA17SIwt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/chatgpt-is-ominous-but-the-pen-is-mightier/ar-AA17SIwt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:51:28.578997+00:00



## Editorial: Carvalho's first report card as LAUSD superintendent: a few stumbles, but he can do better
 - [http://www.msn.com/en-us/news/us/editorial-carvalho-s-first-report-card-as-lausd-superintendent-a-few-stumbles-but-he-can-do-better/ar-AA17SAKx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/editorial-carvalho-s-first-report-card-as-lausd-superintendent-a-few-stumbles-but-he-can-do-better/ar-AA17SAKx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:51:28.569269+00:00



## What Happened to Samantha Humphrey? Body Found Amid Search for NY Teenager
 - [http://www.msn.com/en-us/news/crime/what-happened-to-samantha-humphrey-body-found-amid-search-for-ny-teenager/ar-AA17SQmT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/what-happened-to-samantha-humphrey-body-found-amid-search-for-ny-teenager/ar-AA17SQmT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:51:28.561168+00:00



## Club Q shooting suspect to be held without bond ahead of jury trial
 - [http://www.msn.com/en-us/news/politics/club-q-shooting-suspect-to-be-held-without-bond-ahead-of-jury-trial/ar-AA17SYRQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/club-q-shooting-suspect-to-be-held-without-bond-ahead-of-jury-trial/ar-AA17SYRQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:51:28.552553+00:00



## The Gravedigger of Bucha
 - [http://www.msn.com/en-us/news/world/the-gravedigger-of-bucha/ar-AA17SNJG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-gravedigger-of-bucha/ar-AA17SNJG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:24:54.516245+00:00



## A growing group of lawmakers think TikTok is 'digital fentanyl' and want to ban it. Many others remain skeptical.
 - [http://www.msn.com/en-us/news/politics/a-growing-group-of-lawmakers-think-tiktok-is-digital-fentanyl-and-want-to-ban-it-many-others-remain-skeptical/ar-AA17SLdq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/a-growing-group-of-lawmakers-think-tiktok-is-digital-fentanyl-and-want-to-ban-it-many-others-remain-skeptical/ar-AA17SLdq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:24:54.508305+00:00



## Four systemic safety issues the East Palestine crash report may point to
 - [http://www.msn.com/en-us/news/politics/four-systemic-safety-issues-the-east-palestine-crash-report-may-point-to/ar-AA17SLdb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/four-systemic-safety-issues-the-east-palestine-crash-report-may-point-to/ar-AA17SLdb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:24:54.500908+00:00



## Ukraine war wouldn’t take so long if Biden would commit to victory
 - [http://www.msn.com/en-us/news/world/ukraine-war-wouldn-t-take-so-long-if-biden-would-commit-to-victory/ar-AA17SLea?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-war-wouldn-t-take-so-long-if-biden-would-commit-to-victory/ar-AA17SLea?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:24:54.493225+00:00



## Sentencing of the Buffalo shooter: Black people don't have to forgive white supremacists
 - [http://www.msn.com/en-us/news/us/sentencing-of-the-buffalo-shooter-black-people-don-t-have-to-forgive-white-supremacists/ar-AA17SRWU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/sentencing-of-the-buffalo-shooter-black-people-don-t-have-to-forgive-white-supremacists/ar-AA17SRWU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:08:14.535194+00:00



## Karine Jean-Pierre accused of 'Freudian slip' for calling Biden 'President Obama'
 - [http://www.msn.com/en-us/news/politics/karine-jean-pierre-accused-of-freudian-slip-for-calling-biden-president-obama/ar-AA17Syqz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/karine-jean-pierre-accused-of-freudian-slip-for-calling-biden-president-obama/ar-AA17Syqz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:08:14.524843+00:00



## After 20 years in Guantanamo, two Pakistanis are released without charges
 - [http://www.msn.com/en-us/news/world/after-20-years-in-guantanamo-two-pakistanis-are-released-without-charges/ar-AA17Sw0s?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/after-20-years-in-guantanamo-two-pakistanis-are-released-without-charges/ar-AA17Sw0s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:08:14.515803+00:00



## Gondolas left stranded as Venice's canals run dry amid low tides and lack of rainfall
 - [http://www.msn.com/en-us/news/world/gondolas-left-stranded-as-venice-s-canals-run-dry-amid-low-tides-and-lack-of-rainfall/ar-AA17SF1s?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/gondolas-left-stranded-as-venice-s-canals-run-dry-amid-low-tides-and-lack-of-rainfall/ar-AA17SF1s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:08:14.507483+00:00



## McCarthy walks debt ceiling tightrope in first major test of speakership
 - [http://www.msn.com/en-us/news/politics/mccarthy-walks-debt-ceiling-tightrope-in-first-major-test-of-speakership/ar-AA17SfK3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccarthy-walks-debt-ceiling-tightrope-in-first-major-test-of-speakership/ar-AA17SfK3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:08:14.498780+00:00



## Blinken heads to Asia, with China, Russia tensions soaring
 - [http://www.msn.com/en-us/news/world/blinken-heads-to-asia-with-china-russia-tensions-soaring/ar-AA17SPCW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/blinken-heads-to-asia-with-china-russia-tensions-soaring/ar-AA17SPCW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:08:14.490358+00:00



## Republicans eye culture wars on trans community, education as 2024 election looms
 - [http://www.msn.com/en-us/news/politics/republicans-eye-culture-wars-on-trans-community-education-as-2024-election-looms/ar-AA17SRAG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-eye-culture-wars-on-trans-community-education-as-2024-election-looms/ar-AA17SRAG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:08:14.481651+00:00



## Canada, one year into the Ukraine war: ‘It’s not time to talk about peace’
 - [http://www.msn.com/en-us/news/world/canada-one-year-into-the-ukraine-war-it-s-not-time-to-talk-about-peace/ar-AA17SL90?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/canada-one-year-into-the-ukraine-war-it-s-not-time-to-talk-about-peace/ar-AA17SL90?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 11:08:14.472320+00:00



## White House announces additional Russia sanctions, Ukraine aid on anniversary of invasion
 - [http://www.msn.com/en-us/news/politics/white-house-announces-additional-russia-sanctions-ukraine-aid-on-anniversary-of-invasion/ar-AA17SzZc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/white-house-announces-additional-russia-sanctions-ukraine-aid-on-anniversary-of-invasion/ar-AA17SzZc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:29:55.320554+00:00



## How to investigate the president, his predecessor & keep your job
 - [http://www.msn.com/en-us/news/politics/how-to-investigate-the-president-his-predecessor-keep-your-job/ar-AA17SKdt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/how-to-investigate-the-president-his-predecessor-keep-your-job/ar-AA17SKdt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:29:55.301908+00:00



## Why China launched a charm offensive over Ukraine
 - [http://www.msn.com/en-us/news/world/why-china-launched-a-charm-offensive-over-ukraine/ar-AA17SR13?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/why-china-launched-a-charm-offensive-over-ukraine/ar-AA17SR13?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:29:55.293618+00:00



## US commits $2 billion in drones, ammunition, aid to Ukraine
 - [http://www.msn.com/en-us/news/world/us-commits-2-billion-in-drones-ammunition-aid-to-ukraine/ar-AA17SMJp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-commits-2-billion-in-drones-ammunition-aid-to-ukraine/ar-AA17SMJp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:29:55.282342+00:00



## Putin 'must be under immense pressure' on anniversary of Ukraine invasion
 - [http://www.msn.com/en-us/news/world/putin-must-be-under-immense-pressure-on-anniversary-of-ukraine-invasion/ar-AA17SDzE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-must-be-under-immense-pressure-on-anniversary-of-ukraine-invasion/ar-AA17SDzE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:18:33.398166+00:00



## 'Michelle and I Grew up Poor but Our Dad Inspired Us'
 - [http://www.msn.com/en-us/news/us/michelle-and-i-grew-up-poor-but-our-dad-inspired-us/ar-AA17SvlY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/michelle-and-i-grew-up-poor-but-our-dad-inspired-us/ar-AA17SvlY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:18:33.379271+00:00



## Former Bush aide says Marjorie Taylor Greene has become so powerful in the GOP that she can't be dismissed as a fringe figure anymore
 - [http://www.msn.com/en-us/news/politics/former-bush-aide-says-marjorie-taylor-greene-has-become-so-powerful-in-the-gop-that-she-can-t-be-dismissed-as-a-fringe-figure-anymore/ar-AA17SMtO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/former-bush-aide-says-marjorie-taylor-greene-has-become-so-powerful-in-the-gop-that-she-can-t-be-dismissed-as-a-fringe-figure-anymore/ar-AA17SMtO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:18:33.370106+00:00



## Russia-Ukraine live updates: Brutal war reaches 1-year milestone
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-brutal-war-reaches-1-year-milestone/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-brutal-war-reaches-1-year-milestone/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:18:33.353127+00:00



## My Year of Living Under Constant Attack in Kyiv
 - [http://www.msn.com/en-us/news/world/my-year-of-living-under-constant-attack-in-kyiv/ar-AA17SOCs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/my-year-of-living-under-constant-attack-in-kyiv/ar-AA17SOCs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:04:32.356973+00:00



## The GOP’s Church Committee Wannabes
 - [http://www.msn.com/en-us/news/politics/the-gop-s-church-committee-wannabes/ar-AA17SJNh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-gop-s-church-committee-wannabes/ar-AA17SJNh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:04:32.348367+00:00



## GOP shies away from sweeping health overhauls in post-Obamacare repeal era
 - [http://www.msn.com/en-us/news/politics/gop-shies-away-from-sweeping-health-overhauls-in-post-obamacare-repeal-era/ar-AA17SDyZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-shies-away-from-sweeping-health-overhauls-in-post-obamacare-repeal-era/ar-AA17SDyZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:04:32.340297+00:00



## 'The longest day of our lives': Ukraine reflects on the anniversary of Russia's invasion
 - [http://www.msn.com/en-us/news/world/the-longest-day-of-our-lives-ukraine-reflects-on-the-anniversary-of-russia-s-invasion/ar-AA17SDyW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-longest-day-of-our-lives-ukraine-reflects-on-the-anniversary-of-russia-s-invasion/ar-AA17SDyW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:04:32.333235+00:00



## Juvenile arrested with AR-15 at high school basketball game
 - [http://www.msn.com/en-us/news/crime/juvenile-arrested-with-ar-15-at-high-school-basketball-game/ar-AA17SHa2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/juvenile-arrested-with-ar-15-at-high-school-basketball-game/ar-AA17SHa2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:04:32.326032+00:00



## Even astrophysicist Neil deGrasse Tyson has 'no idea' what the large metal ball that washed up on a Japanese beach really is
 - [http://www.msn.com/en-us/news/technology/even-astrophysicist-neil-degrasse-tyson-has-no-idea-what-the-large-metal-ball-that-washed-up-on-a-japanese-beach-really-is/ar-AA17SMh9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/even-astrophysicist-neil-degrasse-tyson-has-no-idea-what-the-large-metal-ball-that-washed-up-on-a-japanese-beach-really-is/ar-AA17SMh9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 10:04:32.316956+00:00



## North Korea Launches Third Missile Test in Less Than a Week
 - [http://www.msn.com/en-us/news/world/north-korea-launches-third-missile-test-in-less-than-a-week/vi-AA17SzAg?srcref=rss](http://www.msn.com/en-us/news/world/north-korea-launches-third-missile-test-in-less-than-a-week/vi-AA17SzAg?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 09:34:07.715818+00:00



## Commentary: Reviving the Southern Black labor movement
 - [http://www.msn.com/en-us/news/us/commentary-reviving-the-southern-black-labor-movement/ar-AA17SCU7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/commentary-reviving-the-southern-black-labor-movement/ar-AA17SCU7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 09:34:07.702646+00:00



## 'One Year of War in Ukraine Brings Back My Own Horrific Memories'
 - [http://www.msn.com/en-us/news/world/one-year-of-war-in-ukraine-brings-back-my-own-horrific-memories/ar-AA17SxrX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/one-year-of-war-in-ukraine-brings-back-my-own-horrific-memories/ar-AA17SxrX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 09:34:07.690354+00:00



## Asbury University student tells emotional story about regaining Christian faith amid revival: ‘I resented God’
 - [http://www.msn.com/en-us/news/us/asbury-university-student-tells-emotional-story-about-regaining-christian-faith-amid-revival-i-resented-god/ar-AA17SJvn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/asbury-university-student-tells-emotional-story-about-regaining-christian-faith-amid-revival-i-resented-god/ar-AA17SJvn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 09:34:07.678949+00:00



## Jill Biden to Namibian youth: Protect your democracy
 - [http://www.msn.com/en-us/news/us/jill-biden-to-namibian-youth-protect-your-democracy/ar-AA17Skhm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jill-biden-to-namibian-youth-protect-your-democracy/ar-AA17Skhm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 09:34:07.669122+00:00



## US seeks strategy for Ukraine war that manages fear of Crimea showdown
 - [http://www.msn.com/en-us/news/world/us-seeks-strategy-for-ukraine-war-that-manages-fear-of-crimea-showdown/ar-AA17SH0R?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-seeks-strategy-for-ukraine-war-that-manages-fear-of-crimea-showdown/ar-AA17SH0R?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 09:16:57.813670+00:00



## MediaTek's New Chip Lets Any Phone Send Texts Through Satellites
 - [http://www.msn.com/en-us/news/technology/mediatek-s-new-chip-lets-any-phone-send-texts-through-satellites/ar-AA17SCGK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/mediatek-s-new-chip-lets-any-phone-send-texts-through-satellites/ar-AA17SCGK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 09:16:57.803943+00:00



## Live updates | Russia Ukraine War Anniversary
 - [http://www.msn.com/en-us/news/world/live-updates-russia-ukraine-war-anniversary/ar-AA17SJlm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/live-updates-russia-ukraine-war-anniversary/ar-AA17SJlm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 09:16:57.794981+00:00



## Iran calls 84% uranium enrichment allegation a 'conspiracy'
 - [http://www.msn.com/en-us/news/world/iran-calls-84-uranium-enrichment-allegation-a-conspiracy/ar-AA17SqxC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/iran-calls-84-uranium-enrichment-allegation-a-conspiracy/ar-AA17SqxC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 09:03:26.936821+00:00



## You've been washing up all wrong!
 - [http://www.msn.com/en-us/news/technology/you-ve-been-washing-up-all-wrong/ar-AA17SnVl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/you-ve-been-washing-up-all-wrong/ar-AA17SnVl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 08:49:33.578784+00:00



## How writers make it work now
 - [http://www.msn.com/en-us/news/technology/how-writers-make-it-work-now/ar-AA17SnUe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-writers-make-it-work-now/ar-AA17SnUe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 08:49:33.570873+00:00



## Putin's Catastrophic War Against Ukraine by the Numbers
 - [http://www.msn.com/en-us/news/world/putin-s-catastrophic-war-against-ukraine-by-the-numbers/ar-AA17SC1i?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-s-catastrophic-war-against-ukraine-by-the-numbers/ar-AA17SC1i?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 08:49:33.563724+00:00



## Beijing official in Hong Kong warns US envoy after speech
 - [http://www.msn.com/en-us/news/world/beijing-official-in-hong-kong-warns-us-envoy-after-speech/ar-AA17Sq3b?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/beijing-official-in-hong-kong-warns-us-envoy-after-speech/ar-AA17Sq3b?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 08:49:33.553634+00:00



## Professor wants answers about mum's Ukraine death
 - [http://www.msn.com/en-us/news/world/professor-wants-answers-about-mum-s-ukraine-death/ar-AA17S8qs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/professor-wants-answers-about-mum-s-ukraine-death/ar-AA17S8qs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 07:52:45.513112+00:00



## Biden’s weakness emboldened Putin’s Ukraine invasion. One year later, we’re more at risk
 - [http://www.msn.com/en-us/news/world/biden-s-weakness-emboldened-putin-s-ukraine-invasion-one-year-later-we-re-more-at-risk/ar-AA17StEo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/biden-s-weakness-emboldened-putin-s-ukraine-invasion-one-year-later-we-re-more-at-risk/ar-AA17StEo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 07:52:45.505316+00:00



## Joy amid sorrow: 1st birthdays muted for Ukrainian parents
 - [http://www.msn.com/en-us/news/us/joy-amid-sorrow-1st-birthdays-muted-for-ukrainian-parents/ar-AA17Swi3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/joy-amid-sorrow-1st-birthdays-muted-for-ukrainian-parents/ar-AA17Swi3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 07:52:45.496640+00:00



## A Chinese city is offering couples almost $2,900 to have a third child and some others are giving newlyweds paid marriage leave to help boost the birth rate
 - [http://www.msn.com/en-us/news/world/a-chinese-city-is-offering-couples-almost-2-900-to-have-a-third-child-and-some-others-are-giving-newlyweds-paid-marriage-leave-to-help-boost-the-birth-rate/ar-AA17S9Bd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-chinese-city-is-offering-couples-almost-2-900-to-have-a-third-child-and-some-others-are-giving-newlyweds-paid-marriage-leave-to-help-boost-the-birth-rate/ar-AA17S9Bd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 06:52:41.901274+00:00



## China’s Cease-Fire Proposal for Ukraine Gets Quick Dismissal
 - [http://www.msn.com/en-us/news/world/china-s-cease-fire-proposal-for-ukraine-gets-quick-dismissal/ar-AA17RPcy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-s-cease-fire-proposal-for-ukraine-gets-quick-dismissal/ar-AA17RPcy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 06:52:41.894116+00:00



## Florida death row inmate Donald Dillbeck uses last words to trash Gov. Ron DeSantis
 - [http://www.msn.com/en-us/news/crime/florida-death-row-inmate-donald-dillbeck-uses-last-words-to-trash-gov-ron-desantis/ar-AA17SoAx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/florida-death-row-inmate-donald-dillbeck-uses-last-words-to-trash-gov-ron-desantis/ar-AA17SoAx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 06:52:41.886889+00:00



## California faces threat of blizzards and floods as ‘slow-moving’ winter storm lingers
 - [http://www.msn.com/en-us/news/us/california-faces-threat-of-blizzards-and-floods-as-slow-moving-winter-storm-lingers/ar-AA17SgHh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/california-faces-threat-of-blizzards-and-floods-as-slow-moving-winter-storm-lingers/ar-AA17SgHh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 06:52:41.879654+00:00



## After a year of death and destruction, Ukraine braces itself for a major escalation in the war
 - [http://www.msn.com/en-us/news/world/after-a-year-of-death-and-destruction-ukraine-braces-itself-for-a-major-escalation-in-the-war/ar-AA17Si1j?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/after-a-year-of-death-and-destruction-ukraine-braces-itself-for-a-major-escalation-in-the-war/ar-AA17Si1j?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 06:52:41.871914+00:00



## Workers dig by layers in search for 47 missing at China mine
 - [http://www.msn.com/en-us/news/world/workers-dig-by-layers-in-search-for-47-missing-at-china-mine/ar-AA17SoG2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/workers-dig-by-layers-in-search-for-47-missing-at-china-mine/ar-AA17SoG2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 06:52:41.864650+00:00



## The Supreme Court case that could fundamentally change the internet
 - [http://www.msn.com/en-us/news/technology/the-supreme-court-case-that-could-fundamentally-change-the-internet/ar-AA17StrY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-supreme-court-case-that-could-fundamentally-change-the-internet/ar-AA17StrY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 06:52:41.856800+00:00



## University to return skulls to Irish island
 - [http://www.msn.com/en-us/news/world/university-to-return-skulls-to-irish-island/ar-AA17Stta?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/university-to-return-skulls-to-irish-island/ar-AA17Stta?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 06:52:41.848075+00:00



## SEAN HANNITY: Pothole Pete and his team didn't have much to offer
 - [http://www.msn.com/en-us/news/politics/sean-hannity-pothole-pete-and-his-team-didn-t-have-much-to-offer/ar-AA17RZKP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/sean-hannity-pothole-pete-and-his-team-didn-t-have-much-to-offer/ar-AA17RZKP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 05:52:43.776295+00:00



## Russia Planning 'False Flag' Attacks on Eve of Ukraine War Anniversary: ISW
 - [http://www.msn.com/en-us/news/world/russia-planning-false-flag-attacks-on-eve-of-ukraine-war-anniversary-isw/ar-AA17S9bW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-planning-false-flag-attacks-on-eve-of-ukraine-war-anniversary-isw/ar-AA17S9bW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 05:52:43.754282+00:00



## India abstains from UN vote on Ukraine war
 - [http://www.msn.com/en-us/news/world/india-abstains-from-un-vote-on-ukraine-war/ar-AA17S7oJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/india-abstains-from-un-vote-on-ukraine-war/ar-AA17S7oJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 05:52:43.746966+00:00



## The Ukraine war has killed hundreds of thousands of people. His job is to collect the bodies.
 - [http://www.msn.com/en-us/news/world/the-ukraine-war-has-killed-hundreds-of-thousands-of-people-his-job-is-to-collect-the-bodies/ar-AA17S2UM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-ukraine-war-has-killed-hundreds-of-thousands-of-people-his-job-is-to-collect-the-bodies/ar-AA17S2UM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 05:52:43.738686+00:00



## Congress should help protect Ukraine's border and ours
 - [http://www.msn.com/en-us/news/world/congress-should-help-protect-ukraine-s-border-and-ours/ar-AA17Shbs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/congress-should-help-protect-ukraine-s-border-and-ours/ar-AA17Shbs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 05:52:43.730426+00:00



## Hannity Just Can't Seem to Get This Answer From 2024 GOP Candidates
 - [http://www.msn.com/en-us/news/politics/hannity-just-can-t-seem-to-get-this-answer-from-2024-gop-candidates/ar-AA17S30f?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hannity-just-can-t-seem-to-get-this-answer-from-2024-gop-candidates/ar-AA17S30f?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 05:52:43.723279+00:00



## California faces threat of blizzards, floods as ‘slow-moving’ winter storm lingers
 - [http://www.msn.com/en-us/news/us/california-faces-threat-of-blizzards-floods-as-slow-moving-winter-storm-lingers/ar-AA17RZUQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/california-faces-threat-of-blizzards-floods-as-slow-moving-winter-storm-lingers/ar-AA17RZUQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 05:52:43.716052+00:00



## Texans who have run for president over the last 7 decades
 - [http://www.msn.com/en-us/news/politics/texans-who-have-run-for-president-over-the-last-7-decades/ar-AA17S02F?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/texans-who-have-run-for-president-over-the-last-7-decades/ar-AA17S02F?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 05:52:43.708386+00:00



## TUCKER CARLSON: There is no limit to the war in Ukraine
 - [http://www.msn.com/en-us/news/world/tucker-carlson-there-is-no-limit-to-the-war-in-ukraine/ar-AA17RAvL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/tucker-carlson-there-is-no-limit-to-the-war-in-ukraine/ar-AA17RAvL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 04:52:40.917332+00:00



## Russia Doesn’t Belong in the United Nations
 - [http://www.msn.com/en-us/news/world/russia-doesn-t-belong-in-the-united-nations/ar-AA17S6Ql?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-doesn-t-belong-in-the-united-nations/ar-AA17S6Ql?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 04:52:40.910224+00:00



## US Readies New $2 Billion Aid Package for Ukraine
 - [http://www.msn.com/en-us/news/world/us-readies-new-2-billion-aid-package-for-ukraine/ar-AA17R5xx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-readies-new-2-billion-aid-package-for-ukraine/ar-AA17R5xx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 04:52:40.900748+00:00



## Ukrainian teenager seeks refuge from California schools
 - [http://www.msn.com/en-us/news/us/ukrainian-teenager-seeks-refuge-from-california-schools/ar-AA17RXxH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/ukrainian-teenager-seeks-refuge-from-california-schools/ar-AA17RXxH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 04:52:40.892364+00:00



## Biden official says there’s no evidence that Ukraine is misusing US assistance
 - [http://www.msn.com/en-us/news/politics/biden-official-says-there-s-no-evidence-that-ukraine-is-misusing-us-assistance/ar-AA17RUTZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-official-says-there-s-no-evidence-that-ukraine-is-misusing-us-assistance/ar-AA17RUTZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 04:52:40.884450+00:00



## Los Angeles under first blizzard warning since 1989
 - [http://www.msn.com/en-us/news/world/los-angeles-under-first-blizzard-warning-since-1989/ar-AA17Sgt9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/los-angeles-under-first-blizzard-warning-since-1989/ar-AA17Sgt9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 04:52:40.876645+00:00



## Donald Trump Jr. says no one has eaten more McDonald's 'per capita' than his father
 - [http://www.msn.com/en-us/news/politics/donald-trump-jr-says-no-one-has-eaten-more-mcdonald-s-per-capita-than-his-father/ar-AA17S90h?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donald-trump-jr-says-no-one-has-eaten-more-mcdonald-s-per-capita-than-his-father/ar-AA17S90h?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 04:52:40.868479+00:00



## Israel approves more than 7,000 settlement homes, groups say
 - [http://www.msn.com/en-us/news/world/israel-approves-more-than-7-000-settlement-homes-groups-say/ar-AA17RAcA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-approves-more-than-7-000-settlement-homes-groups-say/ar-AA17RAcA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 03:52:40.623153+00:00



## Ohio Train Derailment ‘Was 100% Preventable,’ NTSB Says
 - [http://www.msn.com/en-us/video/peopleandplaces/ohio-train-derailment-was-100-preventable-ntsb-says/vi-AA17RIhD?srcref=rss](http://www.msn.com/en-us/video/peopleandplaces/ohio-train-derailment-was-100-preventable-ntsb-says/vi-AA17RIhD?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 03:52:40.614238+00:00



## 2 Pakistanis leave Guantanamo after 20 years without charges
 - [http://www.msn.com/en-us/news/world/2-pakistanis-leave-guantanamo-after-20-years-without-charges/ar-AA17RAck?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/2-pakistanis-leave-guantanamo-after-20-years-without-charges/ar-AA17RAck?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 03:52:40.607127+00:00



## China calls for a ceasefire in Ukraine, attempting to play the role of mediator days after saying its ties with Russia are 'solid as a mountain'
 - [http://www.msn.com/en-us/news/world/china-calls-for-a-ceasefire-in-ukraine-attempting-to-play-the-role-of-mediator-days-after-saying-its-ties-with-russia-are-solid-as-a-mountain/ar-AA17S6qU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-calls-for-a-ceasefire-in-ukraine-attempting-to-play-the-role-of-mediator-days-after-saying-its-ties-with-russia-are-solid-as-a-mountain/ar-AA17S6qU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 03:52:40.513508+00:00



## Americans are split on whether US should raise debt ceiling to avoid default: poll
 - [http://www.msn.com/en-us/news/politics/americans-are-split-on-whether-us-should-raise-debt-ceiling-to-avoid-default-poll/ar-AA17RUAx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/americans-are-split-on-whether-us-should-raise-debt-ceiling-to-avoid-default-poll/ar-AA17RUAx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 03:52:40.504819+00:00



## 5 teens, 2-year-old among injured in schoolyard shooting
 - [http://www.msn.com/en-us/news/crime/5-teens-2-year-old-among-injured-in-schoolyard-shooting/ar-AA17RK7u?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/5-teens-2-year-old-among-injured-in-schoolyard-shooting/ar-AA17RK7u?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 03:52:40.496481+00:00



## Weird winter weather stumps North Americans
 - [http://www.msn.com/en-us/news/world/weird-winter-weather-stumps-north-americans/ar-AA17S0UC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/weird-winter-weather-stumps-north-americans/ar-AA17S0UC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 02:52:39.516552+00:00



## China Calls for Cease-Fire as War in Ukraine Enters Second Year
 - [http://www.msn.com/en-us/news/world/china-calls-for-cease-fire-as-war-in-ukraine-enters-second-year/ar-AA17RPcy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-calls-for-cease-fire-as-war-in-ukraine-enters-second-year/ar-AA17RPcy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 02:52:39.509205+00:00



## Billionaire investor Thomas H. Lee dead at 78, family says
 - [http://www.msn.com/en-us/news/crime/billionaire-investor-thomas-h-lee-dead-at-78-family-says/ar-AA17RQUg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/billionaire-investor-thomas-h-lee-dead-at-78-family-says/ar-AA17RQUg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 02:52:39.501986+00:00



## China calls for Russia-Ukraine cease-fire, peace talks
 - [http://www.msn.com/en-us/news/world/china-calls-for-russia-ukraine-cease-fire-peace-talks/ar-AA17S62g?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-calls-for-russia-ukraine-cease-fire-peace-talks/ar-AA17S62g?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 02:52:39.494779+00:00



## Conservative group urges lawmakers’ offices to blacklist former Jan. 6 committee staffers
 - [http://www.msn.com/en-us/news/politics/conservative-group-urges-lawmakers-offices-to-blacklist-former-jan-6-committee-staffers/ar-AA17RMxX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/conservative-group-urges-lawmakers-offices-to-blacklist-former-jan-6-committee-staffers/ar-AA17RMxX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 02:52:39.487594+00:00



## Rep. Judy Chu hits back at Texas Republican over 'racist' remarks questioning her loyalty to U.S.
 - [http://www.msn.com/en-us/news/politics/rep-judy-chu-hits-back-at-texas-republican-over-racist-remarks-questioning-her-loyalty-to-u-s/ar-AA17RKp2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-judy-chu-hits-back-at-texas-republican-over-racist-remarks-questioning-her-loyalty-to-u-s/ar-AA17RKp2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 02:52:39.479674+00:00



## Buttigieg blames Trump, Rubio amidst East Palestine derailment backlash: 'Now that it's campaign season'
 - [http://www.msn.com/en-us/news/politics/buttigieg-blames-trump-rubio-amidst-east-palestine-derailment-backlash-now-that-it-s-campaign-season/ar-AA17RI6n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/buttigieg-blames-trump-rubio-amidst-east-palestine-derailment-backlash-now-that-it-s-campaign-season/ar-AA17RI6n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 02:52:39.471460+00:00



## Harvey Weinstein sentenced to 16 years for rape conviction in LA
 - [http://www.msn.com/en-us/news/crime/harvey-weinstein-sentenced-to-16-years-for-rape-conviction-in-la/ar-AA17QMwh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/harvey-weinstein-sentenced-to-16-years-for-rape-conviction-in-la/ar-AA17QMwh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 01:52:42.190136+00:00



## Two friends changed by a year of war
 - [http://www.msn.com/en-us/news/world/two-friends-changed-by-a-year-of-war/ar-AA17RM63?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/two-friends-changed-by-a-year-of-war/ar-AA17RM63?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 01:52:42.182955+00:00



## Biden administration slammed for border surge at GOP-only hearing in Yuma
 - [http://www.msn.com/en-us/news/politics/biden-administration-slammed-for-border-surge-at-gop-only-hearing-in-yuma/ar-AA17ROYH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-administration-slammed-for-border-surge-at-gop-only-hearing-in-yuma/ar-AA17ROYH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 01:52:42.175571+00:00



## Putin’s American Hostage Reveals One Sentence Kept Him Alive
 - [http://www.msn.com/en-us/news/world/putin-s-american-hostage-reveals-one-sentence-kept-him-alive/ar-AA17RJS4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-s-american-hostage-reveals-one-sentence-kept-him-alive/ar-AA17RJS4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 01:52:42.168302+00:00



## Putin gave Biden a $12,000 writing set in 2021. It was among the unusual presents world leaders offered the US president that year.
 - [http://www.msn.com/en-us/news/world/putin-gave-biden-a-12-000-writing-set-in-2021-it-was-among-the-unusual-presents-world-leaders-offered-the-us-president-that-year/ar-AA17Ry66?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-gave-biden-a-12-000-writing-set-in-2021-it-was-among-the-unusual-presents-world-leaders-offered-the-us-president-that-year/ar-AA17Ry66?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 01:52:42.161087+00:00



## Meghan McCain torches Joy Behar for ‘cruelty and elitism’ toward East Palestine residents
 - [http://www.msn.com/en-us/news/us/meghan-mccain-torches-joy-behar-for-cruelty-and-elitism-toward-east-palestine-residents/ar-AA17RMje?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/meghan-mccain-torches-joy-behar-for-cruelty-and-elitism-toward-east-palestine-residents/ar-AA17RMje?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 01:52:42.153899+00:00



## All the 2023 Video Game Release Dates You Need to Know
 - [http://www.msn.com/en-us/news/technology/all-the-2023-video-game-release-dates-you-need-to-know/ar-AA16aQ5F?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/all-the-2023-video-game-release-dates-you-need-to-know/ar-AA16aQ5F?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 01:52:42.146578+00:00



## The high cost of citizenship hurts our economy
 - [http://www.msn.com/en-us/news/politics/the-high-cost-of-citizenship-hurts-our-economy/ar-AA17RW8K?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-high-cost-of-citizenship-hurts-our-economy/ar-AA17RW8K?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 01:52:42.139009+00:00



## ‘Train Wreck’: Will Murdaugh’s Surprise Testimony Sink Him?
 - [http://www.msn.com/en-us/news/crime/train-wreck-will-murdaugh-s-surprise-testimony-sink-him/ar-AA17RzrT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/train-wreck-will-murdaugh-s-surprise-testimony-sink-him/ar-AA17RzrT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 00:49:02.457817+00:00



## How Biden could decide if Trump can be deposed in case of ex-FBI agents
 - [http://www.msn.com/en-us/news/politics/how-biden-could-decide-if-trump-can-be-deposed-in-case-of-ex-fbi-agents/ar-AA17ROAK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/how-biden-could-decide-if-trump-can-be-deposed-in-case-of-ex-fbi-agents/ar-AA17ROAK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 00:49:02.450621+00:00



## Oman to allow Israeli planes through its airspace
 - [http://www.msn.com/en-us/news/world/oman-to-allow-israeli-planes-through-its-airspace/ar-AA17RzxP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/oman-to-allow-israeli-planes-through-its-airspace/ar-AA17RzxP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 00:49:02.443478+00:00



## US, South Korea Discuss Plans for North Korea Nuclear Attack
 - [http://www.msn.com/en-us/news/world/us-south-korea-discuss-plans-for-north-korea-nuclear-attack/ar-AA17RxHz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-south-korea-discuss-plans-for-north-korea-nuclear-attack/ar-AA17RxHz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 00:49:02.434791+00:00



## Can technology clean up the shrimp farming business?
 - [http://www.msn.com/en-us/news/world/can-technology-clean-up-the-shrimp-farming-business/ar-AA17ROsC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/can-technology-clean-up-the-shrimp-farming-business/ar-AA17ROsC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 00:49:02.427207+00:00



## Netflix: More People Should Watch This Mind-blowing Dystopian Sci-Fi Show
 - [http://www.msn.com/en-us/news/technology/netflix-more-people-should-watch-this-mind-blowing-dystopian-sci-fi-show/ar-AA145wiT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/netflix-more-people-should-watch-this-mind-blowing-dystopian-sci-fi-show/ar-AA145wiT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 00:49:02.420018+00:00



## Former Marilyn Manson accuser alleges that Evan Rachel Wood pressured her into making abuse allegations
 - [http://www.msn.com/en-us/news/crime/former-marilyn-manson-accuser-alleges-that-evan-rachel-wood-pressured-her-into-making-abuse-allegations/ar-AA17RCIe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/former-marilyn-manson-accuser-alleges-that-evan-rachel-wood-pressured-her-into-making-abuse-allegations/ar-AA17RCIe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 00:49:02.412711+00:00



## South Carolina 'Chucky' inspired kindergartner brings knife to school, threatens to kill classmates: Sheriff
 - [http://www.msn.com/en-us/news/us/south-carolina-chucky-inspired-kindergartner-brings-knife-to-school-threatens-to-kill-classmates-sheriff/ar-AA17RxI0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/south-carolina-chucky-inspired-kindergartner-brings-knife-to-school-threatens-to-kill-classmates-sheriff/ar-AA17RxI0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-24 00:49:02.395317+00:00



