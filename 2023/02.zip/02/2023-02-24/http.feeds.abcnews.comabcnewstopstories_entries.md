# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Biden 'ruling out' for now sending F-16s to Ukraine, he tells ABC's David Muir
 - [https://abcnews.go.com/Politics/biden-ruling-now-ukraines-request-16s-tells-abcs/story?id=97447640](https://abcnews.go.com/Politics/biden-ruling-now-ukraines-request-16s-tells-abcs/story?id=97447640)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 23:41:58+00:00

Ukraine's President Zelenskyy has made repeated public requests for the advanced American fighter jets.

## Nursing home chief acquitted in patients' hurricane deaths
 - [https://abcnews.go.com/US/wireStory/nursing-home-chief-acquitted-patients-hurricane-deaths-97455160](https://abcnews.go.com/US/wireStory/nursing-home-chief-acquitted-patients-hurricane-deaths-97455160)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 23:39:24+00:00

A judge has acquitted a Florida nursing home administrator of causing the overheating deaths of nine patients after Hurricane Irma in 2017

## Train derails in North Dakota without hazardous spills
 - [https://abcnews.go.com/US/wireStory/train-derails-north-dakota-hazardous-spills-97456066](https://abcnews.go.com/US/wireStory/train-derails-north-dakota-hazardous-spills-97456066)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 23:35:38+00:00

A train has derailed near Burlington, North Dakota

## Ransomware part of attack that compromised 2,000 LA student records
 - [https://abcnews.go.com/US/ransomware-part-attack-compromised-2000-la-student-records/story?id=97443420](https://abcnews.go.com/US/ransomware-part-attack-compromised-2000-la-student-records/story?id=97443420)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 19:46:20+00:00

The Los Angeles Unified School District revealed a cyberattack compromised the data of about 2,000 students.

## WATCH:  High school students raise money to help elderly custodian who had to unretire
 - [https://abcnews.go.com/GMA/Living/video/high-school-students-raise-money-elderly-custodian-unretire-97451119](https://abcnews.go.com/GMA/Living/video/high-school-students-raise-money-elderly-custodian-unretire-97451119)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 19:31:35+00:00

Three Callisburg, Texas students saw Mr. James back at work and wanted to help make ends meet.

## Telecom maker Ericsson to cut 8% of its global workforce
 - [https://abcnews.go.com/Technology/wireStory/telecom-maker-ericsson-cut-8-global-workforce-97450550](https://abcnews.go.com/Technology/wireStory/telecom-maker-ericsson-cut-8-global-workforce-97450550)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 19:16:05+00:00

Swedish telecom equipment maker Ericsson has announced it&rsquo;s cutting 8% of its global workforce as it looks to reduce costs

## Special counsel investigating Trump asks judge to compel Mike Pence to testify
 - [https://abcnews.go.com/Politics/special-counsel-investigating-trump-asks-judge-compel-mike/story?id=97446986](https://abcnews.go.com/Politics/special-counsel-investigating-trump-asks-judge-compel-mike/story?id=97446986)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 18:05:04+00:00

Donald Trump's legal team has challenged the subpoena issued to Pence.

## Measles outbreak that sickened 85 kids -- almost all unvaccinated -- is over in Ohio
 - [https://abcnews.go.com/Health/measles-outbreak-sickened-85-children-declared-ohio/story?id=97443408](https://abcnews.go.com/Health/measles-outbreak-sickened-85-children-declared-ohio/story?id=97443408)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 18:02:29+00:00

The measles outbreak that infected 85 children in central Ohio has been declared over, according to health officials. Nearly all the cases were among unvaccinated kids.

## Judge releases man in 1990 slayings of 2 Michigan hunters
 - [https://abcnews.go.com/US/wireStory/judge-releases-man-1990-slayings-2-michigan-hunters-97446732](https://abcnews.go.com/US/wireStory/judge-releases-man-1990-slayings-2-michigan-hunters-97446732)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 17:47:11+00:00

A judge has thrown out convictions and ordered the release of a man who has long claimed innocence in the slayings of two Michigan deer hunters in 1990

## Fed's rate hikes likely to cause a recession, research says
 - [https://abcnews.go.com/Business/wireStory/feds-rate-hikes-cause-recession-research-97446015](https://abcnews.go.com/Business/wireStory/feds-rate-hikes-cause-recession-research-97446015)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 17:44:31+00:00

Can the Federal Reserve keep raising interest rates and defeat the nation&rsquo;s worst bout of inflation in 40 years without causing a recession

## 2-year-old boy found alive in woods about 24 hours after he went missing
 - [https://abcnews.go.com/US/2-year-boy-found-alive-florida-woods-24/story?id=97447153](https://abcnews.go.com/US/2-year-boy-found-alive-florida-woods-24/story?id=97447153)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 17:34:00+00:00

A 2-year-old Brooksville, Florida, boy has been found alive in the woods about 24 hours after he went missing, authorities said.

## Runway incidents have risen but serious close calls have decreased over 20 years: FAA
 - [https://abcnews.go.com/Politics/airport-runway-incidents-risen-close-calls-decreased-20/story?id=97358077](https://abcnews.go.com/Politics/airport-runway-incidents-risen-close-calls-decreased-20/story?id=97358077)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 17:13:42+00:00

The number of runway incursions in 2022, including general and commercial aircraft, is up from the 1,397 incursions reported  in 2012 and 987 reported in 2002

## Man arrested after hiding cryptocurrency miner in school crawl space
 - [https://abcnews.go.com/US/massachusetts-man-charged-after-hiding-cryptocurrency-mining-rig/story?id=97440173](https://abcnews.go.com/US/massachusetts-man-charged-after-hiding-cryptocurrency-mining-rig/story?id=97440173)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 17:02:35+00:00

A small Massachusetts town enlisted the help of the Department of Homeland Security to track down the person who illegally installed a cryptocurrency mining operation.

## Since invasion, more than a quarter million Ukrainians have relocated to US
 - [https://abcnews.go.com/Politics/invasion-quarter-million-ukrainians-relocated-us/story?id=97442418](https://abcnews.go.com/Politics/invasion-quarter-million-ukrainians-relocated-us/story?id=97442418)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 16:53:59+00:00

Since the start of Russia's invasion began one year ago, more than a quarter million Ukrainians have relocated to the U.S.

## Turkey starts work to build homes in 2 earthquake-hit towns
 - [https://abcnews.go.com/Business/wireStory/turkey-starts-work-build-homes-2-earthquake-hit-97445641](https://abcnews.go.com/Business/wireStory/turkey-starts-work-build-homes-2-earthquake-hit-97445641)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 16:32:02+00:00

Turkish authorities say preliminary work has started to build housing for people left homeless by the massive earthquake that hit parts of the country and neighboring Syria, killing tens of thousands

## Key US inflation measure surges at fastest rate since June
 - [https://abcnews.go.com/Politics/wireStory/inflation-gauge-tracked-fed-accelerated-january-97442055](https://abcnews.go.com/Politics/wireStory/inflation-gauge-tracked-fed-accelerated-january-97442055)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 14:45:18+00:00

The Federal Reserve&rsquo;s preferred inflation gauge rose last month at its fastest pace since June, an alarming sign that price pressures remain entrenched in the U.S. economy and could lead the Fed to keep raising interest rates well into this year

## US announces sweeping new Russia sanctions 1 year into war
 - [https://abcnews.go.com/Business/wireStory/us-announces-sweeping-new-russia-sanctions-1-year-97442860](https://abcnews.go.com/Business/wireStory/us-announces-sweeping-new-russia-sanctions-1-year-97442860)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 14:44:18+00:00

The U.S. has announced a new round of sanctions on Russian firms, banks, manufacturers and people

## How the war in Ukraine is affecting food supplies, prices around the world
 - [https://abcnews.go.com/International/1-year-war-ukraine-affecting-food-supplies-prices/story?id=97320422](https://abcnews.go.com/International/1-year-war-ukraine-affecting-food-supplies-prices/story?id=97320422)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 12:21:34+00:00

Here is how the war in Ukraine has complicated issues of food security around the globe.

## Israeli settlers shoot, wound 2 Palestinians in West Bank
 - [https://abcnews.go.com/International/wireStory/israeli-settlers-shoot-wound-2-palestinians-west-bank-97438706](https://abcnews.go.com/International/wireStory/israeli-settlers-shoot-wound-2-palestinians-west-bank-97438706)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 11:48:36+00:00

Palestinian health officials say Israeli settlers have shot and seriously wounded two Palestinians in the northern occupied West Bank, in what officials describe as the latest incident in a wave of settler violence

## Despite opposition, Gov. Sarah Sanders the latest Republican to push 'school choice'
 - [https://abcnews.go.com/Politics/despite-opposition-arkansas-gov-sarah-sanders-latest-republican/story?id=97362940](https://abcnews.go.com/Politics/despite-opposition-arkansas-gov-sarah-sanders-latest-republican/story?id=97362940)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 11:16:39+00:00

Arkansas Gov. Sarah Huckabee Sanders has promised to pass the country's "most far-reaching bold, conservative, education reform," but critics have organized to defeat it.

## Tens of thousands dead in 1st year of Russian war, but true toll remains elusive
 - [https://abcnews.go.com/International/russia-ukraine-war-tens-thousands-dead-1st-year/story?id=97247372](https://abcnews.go.com/International/russia-ukraine-war-tens-thousands-dead-1st-year/story?id=97247372)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 11:05:40+00:00

As Russia's war in Ukraine begins its second year, a full accounting of its casualties remains elusive.

## Republicans eye culture wars on trans community, education as 2024 election looms
 - [https://abcnews.go.com/Politics/republicans-eye-culture-wars-trans-community-education-2024/story?id=97013356](https://abcnews.go.com/Politics/republicans-eye-culture-wars-trans-community-education-2024/story?id=97013356)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 10:52:22+00:00

Trump and at least two possible 2024 candidates are increasingly focused on battles around LGBTQ issues and education -- which operatives say is likely only to intensify

## Russia-Ukraine live updates: Brutal war reaches 1-year milestone
 - [https://abcnews.go.com/International/live-updates/russia-ukraine/?id=97380473](https://abcnews.go.com/International/live-updates/russia-ukraine/?id=97380473)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 09:58:00+00:00

Live updates on Russia's war in neighboring Ukraine.

## What is China's peace proposal for Ukraine War?
 - [https://abcnews.go.com/International/wireStory/chinas-peace-proposal-ukraine-war-97437590](https://abcnews.go.com/International/wireStory/chinas-peace-proposal-ukraine-war-97437590)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 09:36:05+00:00

On the first anniversary of Russia&rsquo;s invasion of Ukraine, China offered a 12-point proposal to end the war, which a senior diplomat had teased in Munich earlier this week

## WATCH:  Man loses eye to cancer, turns prosthetic eye into flashlight
 - [https://abcnews.go.com/GMA/Living/video/man-loses-eye-cancer-turns-prosthetic-eye-flashlight-97430265](https://abcnews.go.com/GMA/Living/video/man-loses-eye-cancer-turns-prosthetic-eye-flashlight-97430265)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 09:27:43+00:00

Brian Stanley was diagnosed with retinoblastoma when he was 6 years old. After years of wearing a prosthetic eye, Stanley used his skills as an engineer to create what he calls a "cyborg eye."

## Juvenile arrested with AR-15 at high school basketball game
 - [https://abcnews.go.com/US/juvenile-arrested-ar-15-high-school-basketball-game/story?id=97438317](https://abcnews.go.com/US/juvenile-arrested-ar-15-high-school-basketball-game/story?id=97438317)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 08:39:02+00:00

A male juvenile suspect has been arrested at a high school basketball game after he was found carrying an AR-15, police said.

## China calls for Russia-Ukraine cease-fire, peace talks
 - [https://abcnews.go.com/International/wireStory/china-calls-russia-ukraine-cease-fire-peace-talks-97433032](https://abcnews.go.com/International/wireStory/china-calls-russia-ukraine-cease-fire-peace-talks-97433032)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 03:20:06+00:00

China has called for a cease-fire between Ukraine and Russia and the opening of peace talks as part of a 12-point proposal to end the conflict

## 6 children, 1 woman injured in shooting at schoolyard in Philadelphia
 - [https://abcnews.go.com/US/6-children-1-woman-injured-shooting-schoolyard-philadelphia/story?id=97432728](https://abcnews.go.com/US/6-children-1-woman-injured-shooting-schoolyard-philadelphia/story?id=97432728)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 02:42:43+00:00

Seven people were shot and injured in Philadelphia Thursday, police said.

## 5 children, 1 woman injured in shooting at schoolyard in Philadelphia
 - [https://abcnews.go.com/US/5-children-1-woman-injured-shooting-schoolyard-philadelphia/story?id=97432728](https://abcnews.go.com/US/5-children-1-woman-injured-shooting-schoolyard-philadelphia/story?id=97432728)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 01:46:20+00:00

Six people were shot and injured in Philadelphia Thursday, police said.

## North Korea says it test-fired long-range cruise missiles
 - [https://abcnews.go.com/International/wireStory/north-korea-test-fired-long-range-cruise-missiles-97430956](https://abcnews.go.com/International/wireStory/north-korea-test-fired-long-range-cruise-missiles-97430956)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 00:43:56+00:00

North Korea says it test-fired long-range cruise missiles in waters off its eastern coast a day earlier, adding to a provocative streak in weapons demonstrations as its rivals step up military training

## Republicans set opening presidential debate for August
 - [https://abcnews.go.com/Politics/wireStory/republicans-set-opening-presidential-debate-august-97430639](https://abcnews.go.com/Politics/wireStory/republicans-set-opening-presidential-debate-august-97430639)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-24 00:28:31+00:00

The Republican National Committee has decided that the opening Republican presidential debate of the 2024 election season will take place in Milwaukee this August

