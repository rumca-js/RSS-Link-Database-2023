# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Wojna w Ukrainie. Na jej dom spadły bomby. Straciła wzrok, słyszała krzyki swoich dzieci
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-na-jej-dom-spadly-bomy-stracila-wzrok-slyszala-krzyki-swoich-dzieci/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-na-jej-dom-spadly-bomy-stracila-wzrok-slyszala-krzyki-swoich-dzieci/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 19:47:00+00:00

Choć po roku blizny powoli znikają z twarzy Oleny i jej synów, te w środku nigdy się nie zagoją. Rok temu podczas ostrzału chwyciła po omacku zakrwawione dzieci i niewiele widząc, ruszyła po pomoc. Tę uzyskała dopiero w szpitalu w Lublinie. Wiemy, jak potoczyły się ich losy.

## Wielka Brytania: Były pediatra skazany za posiadanie dziecięcej pornografii. "Skala była szokująca"
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wielka-brytania-byly-pediatra-skazany-za-posiadanie-dzieciecej-pornografii-skala-byla-szokujaca/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wielka-brytania-byly-pediatra-skazany-za-posiadanie-dzieciecej-pornografii-skala-byla-szokujaca/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 16:51:00+00:00

Były pediatra David Shaw został złapany z jednym z największych zbiorów obrazów seksualnego wykorzystywania najmłodszych, z jakimi brytyjskie służby miały do czynienia. Mężczyznę skazano za posiadanie dziecięcej pornografii.

## Francja. 57-latka odgryzła język mężczyźnie, który ją napadł. "Dowód" zaniosła policji
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/francja-57-latka-odgryzla-jezyk-mezczyznie-ktory-ja-napadl-dowod-zaniosla-policji/](https://www.polsatnews.pl/wiadomosc/2023-02-24/francja-57-latka-odgryzla-jezyk-mezczyznie-ktory-ja-napadl-dowod-zaniosla-policji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 15:20:00+00:00

57-latka z Francji - jak twierdzi - broniąc się przed mężczyzną, który ją napadł, odgryzła mu... język. Przestępca miał najpierw ją śledzić, kiedy spacerowała z psem, a następnie próbować wykorzystać seksualnie.

## Iga Świątek wygrała z amerykańską tenisistką Cori Gauff. Awansowała do finału WTA w Dubaju
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/iga-swiatek-wygrala-z-amerykanska-tenisistka-cori-gauff-awansowala-do-finalu/](https://www.polsatnews.pl/wiadomosc/2023-02-24/iga-swiatek-wygrala-z-amerykanska-tenisistka-cori-gauff-awansowala-do-finalu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 14:43:00+00:00

Iga Świątek w półfinale wygrała z amerykańską tenisistką - Cori Gauff - awansując tym samym do wielkiego finału WTA w Dubaju.

## Niemcy. Przez samochodowy wyścig zginęło dwoje małych dzieci. 40-latka stanęła przed sądem
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/niemcy-przez-samochodowy-wyscig-zginelo-dwoje-malych-dzieci-40-latka-stanela-przed-sadem/](https://www.polsatnews.pl/wiadomosc/2023-02-24/niemcy-przez-samochodowy-wyscig-zginelo-dwoje-malych-dzieci-40-latka-stanela-przed-sadem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 13:00:00+00:00

Dwoje dzieci w wieku dwóch i sześciu lat zginęło w wyniku wypadku, do którego doszło podczas nielegalnego wyścigu samochodowego. W piątek przed sądem w Hanowerze stanęła 40-latka, która jest oskarżona o spowodowanie śmierci dzieci oraz ciężkich obrażeń, jakich doznali ich rodzice.

## Mateusz Morawiecki w Kijowie. Zełenski: Polska była z nami jeszcze zanim rozpoczęła się wojna
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/mateusz-morawiecki-w-kijowie-zelenski-polska-byla-z-nami-jeszcze-zanim-rozpoczela-sie-wojna/](https://www.polsatnews.pl/wiadomosc/2023-02-24/mateusz-morawiecki-w-kijowie-zelenski-polska-byla-z-nami-jeszcze-zanim-rozpoczela-sie-wojna/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 12:18:00+00:00

- Pana obecność dzisiaj w Ukrainie jest prawdziwym symbolem dla nas. To symbol naszej solidarności i niezłomności. Polska była z nami jeszcze zanim rozpoczęła się wojna i jestem pewien, że Polska pozostanie z nami aż do naszego zwycięstwa, wspólnego zwycięstwa - powiedział prezydent Ukrainy Wołodymyr Zełenski.

## Wojna w Ukrainie. Sondaż: 90 proc. Ukraińców popiera atak na Rosję
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/sondaz-90-proc-ukraincow-popiera-atak-na-rosje/](https://www.polsatnews.pl/wiadomosc/2023-02-24/sondaz-90-proc-ukraincow-popiera-atak-na-rosje/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 11:30:00+00:00

90 proc. Ukraińców uważa, że atak na Rosję jest konieczny - wynika z sondażu przeprowadzonego przez Kijowski Międzynarodowy Instytut Socjologii (KIIS). O wynikach badania poinformowała ukraińska agencja Unian. Część Ukraińców popierających szturm na Rosję chce, aby ostrzeliwać cele cywilne, tak jak robią to wojska nieprzyjaciela.

## Wojna w Ukrainie. Ochotniczka na wojnie. Front oczami kobiety
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-ochotniczka-na-wojnie-front-oczami-kobiety/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-ochotniczka-na-wojnie-front-oczami-kobiety/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 11:17:00+00:00

Walczą, opatrują rannych, dowodzą oddziałami - na ukraińskim froncie kobiet nie brakuje. Wśród nich jest Rina, ochotniczka, która operuje dronami wojskowymi w Donbasie. Walczyła w najniebezpieczniejszych miejscach tej wojny, między innymi pod Bachmutem. Polsat News opowiedziała o tym, dlaczego wstąpiła do armii i jak wygląda codzienność kobiety w męskim oddziale.

## Rocznica wojny na Ukrainie. Akcje pod rosyjskimi ambasadami
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/rocznica-wojny-na-ukrainie-akcje-pod-rosyjskimi-ambasadami/](https://www.polsatnews.pl/wiadomosc/2023-02-24/rocznica-wojny-na-ukrainie-akcje-pod-rosyjskimi-ambasadami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 10:50:00+00:00

Pomalowana ulica w barwach ukraińskiej flagi, ukraiński hymn, dźwięki syren i wybuchów, a nawet zniszczony rosyjski czołg - taki widok czekał dziś na pracowników rosyjskich ambasad w Europie. Aktywiści w wielu krajach zorganizowali specjalne akcje, upamiętniające wybuch wojny w Ukrainie, od którego mija właśnie rok.

## Wojna w Ukrainie. Polskie ofiary rosyjskiej inwazji
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-polskie-ofiary-rosyjskiej-inwazji/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-polskie-ofiary-rosyjskiej-inwazji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 10:24:00+00:00

Dokładnie rok temu rozpoczęła się rosyjska inwazja na Ukrainę. W tym czasie zginęły tysiące żołnierzy i cywilów - wśród nich Polacy. Śmierć na froncie poniósł m.in. ochotnik Janusz Szeremeta, a eksplozja rakiety na Lubelszczyźnie zabiła dwóch polskich cywilów. Ranni w wyniku ostrzału zostali również Polacy, którzy pracowali w Ukrainie jako wolontariusze.

## USA. Niemal 170-letnia whiskey czeka na wydobycie. Ten skarb może być wart prawie miliard dolarów
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/usa-niemal-170-letnia-whiskey-czeka-na-wydobycie-ten-skarb-moze-byc-wart-prawie-miliard-dolarow/](https://www.polsatnews.pl/wiadomosc/2023-02-24/usa-niemal-170-letnia-whiskey-czeka-na-wydobycie-ten-skarb-moze-byc-wart-prawie-miliard-dolarow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 10:23:00+00:00

871 milionów dolarów może być wart burbon, leżący w beczkach we wraku parowca, który 169 lat temu zatonął na jeziorze Michigan w USA. Nurek natrafił na wrak w 2010 roku. Ale na wydobycie cennego trunku trzeba będzie poczekać prawdopodobnie co najmniej kilka lat, bo wyciągnięcie zawartości wraku wymaga uzyskania odpowiednich zezwoleń.

## Wojna w Ukrainie. Pierwsze czołgi Leopard z Polski trafiły na Ukrainę
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/pierwsze-czolgi-leopard-trafily-na-ukraine/](https://www.polsatnews.pl/wiadomosc/2023-02-24/pierwsze-czolgi-leopard-trafily-na-ukraine/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 09:57:00+00:00

Polska przekaże Ukrainie w piątek pierwsze czołgi Leopard - podał Bloomberg, powołując się na swoje źródła. Nasz kraj zadeklarował, że za wschodnią granicę ma trafić łącznie 14 sztuk tego sprzętu.

## Wojna w Ukrainie. Mariupol - wizytówka wschodniej Ukrainy niemal zrównana z ziemią
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-mariupol-wizytowka-wschodniej-ukrainy-niemal-zrownana-z-ziemia/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-mariupol-wizytowka-wschodniej-ukrainy-niemal-zrownana-z-ziemia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 09:50:00+00:00

Zaledwie rok temu Mariupol był wizytówką wschodniej Ukrainy. Port nad Morzem Azowskim, potężny ośrodek przemysłowy, ale i pełna atrakcji stolica kultury. W wyniku rosyjskiej inwazji miasto zostało niemal zrównane z ziemią. Na Mariupol spadły tysiące rosyjskich pocisków. Materiał Katarzyny Pyssy.

## Wojna w Ukrainie. 365 twarzy prezydenta Wołodymyra Zełenskiego
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-365-twarzy-prezydenta-wolodymyra-zelenskiego/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-365-twarzy-prezydenta-wolodymyra-zelenskiego/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 09:36:00+00:00

Od prezydenta, który był aktorem, do narodowego bohatera i światowego symbolu heroicznej walki o wolność i demokrację. Wołodymyr Zełenski od 365 dni nie ustaje w wysiłkach, by odeprzeć wrogie siły Rosji i znaleźć sprzymierzeńców w świecie Zachodu.

## Niemcy. Koty z całego miasta w areszcie domowym. Wina pośmieciuszki
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/niemcy-koty-z-calego-miasta-w-areszcie-domowym-wina-posmieciuszki/](https://www.polsatnews.pl/wiadomosc/2023-02-24/niemcy-koty-z-calego-miasta-w-areszcie-domowym-wina-posmieciuszki/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 09:25:00+00:00

Grzywna wysokości 50 tys. euro będzie grozić za wypuszczenie kota na dwór w niemieckim miasteczku w Badenii-Wirtembergii. W przeliczeniu to dziś niemal 240 tys. zł. Władze chcą chronić w ten sposób przed pożarciem trzy lęgowe pary zagrożonego wyginięciem gatunku ptaka. Zakaz ma obowiązywać przez pięć miesięcy. Koty można wyprowadzać na smyczy - piszą lokalne władze.

## Wojna w Ukrainie. Straty Rosjan w rocznicę inwazji. Niemal 150 tys. wyeliminowanych żołnierzy
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-straty-rosjan-w-rocznice-inwazji-niemal-150-tys-wyeliminowanych-zolnierzy/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-straty-rosjan-w-rocznice-inwazji-niemal-150-tys-wyeliminowanych-zolnierzy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 07:55:00+00:00

Sztab Generalny Sił Zbrojnych Ukrainy podał, że od początku pełnoskalowej agresji Kremla Rosja straciła co najmniej 146 tys. 820 żołnierzy. Agresor ponosi ogromne straty w sprzęcie pancerny. Ukraińcy zniszczyli w ciągu roku działań obronnych

## Wojna w Ukrainie. Dowództwo ukraińskiej armii: Dziesięć największych sukcesów w wojnie z Rosjanami
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-dowodztwo-ukrainskiej-armii-dziesiec-najwiekszych-sukcesow-w-wojnie-z-rosjanami/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-dowodztwo-ukrainskiej-armii-dziesiec-najwiekszych-sukcesow-w-wojnie-z-rosjanami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 07:22:00+00:00

Sztab Generalny Sił Zbrojnych Ukrainy wymienił dziesięć największych sukcesów w obronie kraju przed rosyjską inwazją, której Kreml nie chce nazywać wojną i określa ją wciąż jako operację specjalną. Wśród największych dokonań są: udana obrona Kijowa, wypchnięcie Rosjan z rejonu Charkowa, zatopienie flagowego krążownika Moskwa i odbicie Wyspy Wężowej. A ostatnio - skuteczna obrona na wschodzie.

## Rocznica wybychu wojny na Ukrainie. Wołodymyr Zełenski: 24 lutego miliony z nas dokonały wyboru
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/rocznica-wybychu-wojny-na-ukrainie-wolodymyr-zelenski-24-lutego-miliony-z-nas-dokonaly-wyboru/](https://www.polsatnews.pl/wiadomosc/2023-02-24/rocznica-wybychu-wojny-na-ukrainie-wolodymyr-zelenski-24-lutego-miliony-z-nas-dokonaly-wyboru/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 07:17:00+00:00

24 lutego miliony z nas dokonały wyboru. Nie biała flaga, ale niebiesko-żółta. Nie uciekając, ale stawiając czoła - napisał prezydent Wołodymir Zełesnki w pierwszą rocznicę wybuchu wojny w Ukrainie. Do wpisu dołączył nagranie, które pokazuje trudy wojny i dramat milionów Ukraińców.

## Wojna w Ukrainie. Rok pełnoskalowej inwazji Rosji. Niepowodzenie planu Putina
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-rok-pelnoskalowej-inwazji-rosji-na-ukraine-niepowodzenie-planu-putina/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-rok-pelnoskalowej-inwazji-rosji-na-ukraine-niepowodzenie-planu-putina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 06:25:00+00:00

Mija rok inwazji Rosji na Ukrainę. Kraj obronił niepodległość, ale część jego terytorium znajduje się pod okupacją rosyjską. Kreml nie ustaje w atakach i kolejnych groźbach wobec Kijowa i całego demokratycznego świata. Wojska agresora spustoszyły dużą część Ukrainy, powodując śmierć tysięcy osób i ucieczkę milionów. Inwazja wywołała największy kryzys uchodźczy od czasów II wojny światowej.

## Wojna w Ukrainie. Dodatkowe 2 miliardy dolarów pomocy wojskowej dla Ukrainy. W rocznicę inwazji
 - [https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-dodatkowe-2-miliardy-dolarow-pomocy-wojskowej-dla-ukrainy/](https://www.polsatnews.pl/wiadomosc/2023-02-24/wojna-w-ukrainie-dodatkowe-2-miliardy-dolarow-pomocy-wojskowej-dla-ukrainy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-24 05:20:00+00:00

W przeddzień rocznicy rosyjskiej inwazji na Ukrainę Stany Zjednoczone ogłosiły wartą 2 mld dolarów dodatkową pomoc wojskową dla Kijowa. - Samoloty F-16 to nie kwestia walki krótkoterminowej. F-16 to kwestia długoterminowej obrony Ukrainy - powiedział w CNN doradca Białego Domu ds. bezpieczeństwa narodowego Jake Sullivan pytany o apel Ukrainy dotyczący dostarczenia jej amerykańskich myśliwców.

