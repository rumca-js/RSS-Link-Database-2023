# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Kolejny gazociąg w Polsce. Gaz-System ma zgodę na połączenie Raciborza i Oświęcimia
 - [https://www.money.pl/gospodarka/kolejny-gazociag-w-polsce-gaz-system-ma-zgode-na-polaczenie-raciborza-i-oswiecimia-6870094659910240a.html](https://www.money.pl/gospodarka/kolejny-gazociag-w-polsce-gaz-system-ma-zgode-na-polaczenie-raciborza-i-oswiecimia-6870094659910240a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 20:06:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fd6c87a2-4acf-45e5-bb26-0e9276117c02" width="308" /> Gaz-System ma już komplet decyzji, pozwalających rozpocząć budowę gazociągu Racibórz-Oświęcim. Inwestycja umożliwi m.in. przyłączenie do sieci planowanego przez PGE nowego bloku gazowego w Rybniku, który będzie jednym z największych tego typu instalacji w Polsce.

## Rosja wylatuje z kolejnej organizacji. "Odnieśliśmy znaczące zwycięstwo"
 - [https://www.money.pl/gospodarka/rosja-wylatuje-z-kolejnej-organizacji-odnieslismy-znaczace-zwyciestwo-6870082548869728a.html](https://www.money.pl/gospodarka/rosja-wylatuje-z-kolejnej-organizacji-odnieslismy-znaczace-zwyciestwo-6870082548869728a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 19:27:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b6992187-b4db-4b38-b006-14cd9092b245" width="308" /> Grupa Specjalna ds. Przeciwdziałania Praniu Pieniędzy (FATF) zawiesiła w piątek prawa członkowskie Rosji na czas nieokreślony. To organizacja powołana przez grupę G7. Z tej decyzji cieszą się politycy Ukrainy. "Odnieśliśmy znaczące zwycięstwo" – przekonuje szef Kancelarii Prezydenta Ukrainy Andrij Jermak.

## Tego już się nie da zatuszować. Rząd ma duży problem
 - [https://www.money.pl/gospodarka/tego-juz-sie-nie-da-zatuszowac-rzad-ma-duzy-problem-6869944566884960a.html](https://www.money.pl/gospodarka/tego-juz-sie-nie-da-zatuszowac-rzad-ma-duzy-problem-6869944566884960a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 18:33:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2ec270ed-3962-4b7d-b2f2-666550b2ce47" width="308" /> Przez drugą połowę 2022 r. konsumpcja, czyli główne koło zamachowe polskiej gospodarki, radziła sobie całkiem nieźle. Problemy z portfelami Polaków tuszowali uchodźcy, którzy kupowali u nas podstawowe produkty spożywcze. Teraz jednak sytuacja się odwróciła. Polski konsument jest w recesji i nie da się już tego ukryć. A rząd będzie miał z tym duży problem.

## Fabryka Porcelany "Krzysztof" wygasiła piece. Ponownie uruchamia sklep internetowy
 - [https://www.money.pl/gospodarka/fabryka-porcelany-krzysztof-wygasila-piece-ponownie-uruchamia-sklep-internetowy-6870057024621184a.html](https://www.money.pl/gospodarka/fabryka-porcelany-krzysztof-wygasila-piece-ponownie-uruchamia-sklep-internetowy-6870057024621184a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 17:33:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/96666325-fccd-416e-98b6-eb035801e2ab" width="308" /> Fabryka Porcelany "Krzysztof" zakończyła działalność pod koniec 2022 r. Do tej decyzji firmę pchnęły ceny gazu. Zresztą wytwórnia wygasiła już swoje piece zdobnicze. Jednak ponownie uruchomiła swój sklep internetowy.

## Oto "lista wstydu" po roku wojny. Są polskie firmy, które wciąż działają w Rosji
 - [https://www.money.pl/gospodarka/oto-lista-wstydu-po-roku-wojny-sa-polskie-firmy-ktore-wciaz-dzialaja-w-rosji-6869960293722752a.html](https://www.money.pl/gospodarka/oto-lista-wstydu-po-roku-wojny-sa-polskie-firmy-ktore-wciaz-dzialaja-w-rosji-6869960293722752a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 16:27:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/eb8b6a5d-e458-43c1-8ab6-2aab52461adc" width="308" /> Po wybuchu wojny w Ukrainie wiele międzynarodowych (głównie zachodnich) firm zdecydowało się opuścić Rosję, by nie dokładać ręki do inwazji. "Exodus" nie był jednak pełny. Po roku konfliktu w reżimie Putina wciąż działają niektóre firmy z Polski.

## Wprowadzili czterodniowy tydzień pracy. Z przymusu, bo nie mają zleceń
 - [https://www.money.pl/gospodarka/wprowadzili-czterodniowy-tydzien-pracy-z-przymusu-bo-nie-maja-zlecen-6870019300596320a.html](https://www.money.pl/gospodarka/wprowadzili-czterodniowy-tydzien-pracy-z-przymusu-bo-nie-maja-zlecen-6870019300596320a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 15:37:02+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/80e24e91-83bb-438e-8b20-7f4556464bfd" width="308" /> Newag, firma produkująca i modernizująca m.in. pociągi, wprowadziła czterodniowy tydzień pracy. W co drugim tygodniu pracownicy mają wolne piątki. Spółka nie zrobiła tego jednak, aby badać efektywność takiego rozwiązania. Jak przyznał jej prezes, decyzja ta jest efektem optymalizacji kosztów.

## Rekordowe marże i zyski Orlenu. Oto dlaczego państwowy koncern zarobił tak dużo
 - [https://www.money.pl/gielda/orlen-wyniki-finansowe-2022-r-rekordowe-marze-i-zyski-oto-na-czym-zarobil-koncern-6869996480662112a.html](https://www.money.pl/gielda/orlen-wyniki-finansowe-2022-r-rekordowe-marze-i-zyski-oto-na-czym-zarobil-koncern-6869996480662112a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 15:33:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1c982e3e-0150-4f64-9611-11625bc0db03" width="308" /> Orlen chwali się rekordowymi zyskami. Jak wskazują w komentarzach dla money.pl eksperci, to przede wszystkim efekt konsolidacji wyników Lotosu i skutek niespotykanego wzrostu marży, którą koncern zawdzięcza skokom cen na rynku paliw po inwazji Rosji na Ukrainę.

## "Rzeki" ropy i gazu zmieniły bieg. Rok wojny przekreślił mapy energetyczne świata
 - [https://www.money.pl/gielda/rzeki-ropy-i-gazu-zmienily-bieg-rok-wojny-przekreslil-mapy-energetyczne-swiata-6867175105616480a.html](https://www.money.pl/gielda/rzeki-ropy-i-gazu-zmienily-bieg-rok-wojny-przekreslil-mapy-energetyczne-swiata-6867175105616480a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 14:13:14+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/924f37c5-20bd-410e-866e-2373dd70e42c" width="308" /> Decyzja Putina o rozpoczęciu wojny okazała się bardziej kosztowna, niż rosyjski przywódca mógł się spodziewać. Rok wojny drastycznie zmienił mapy energetyczne świata. Putin przejdzie do historii jako ten, który w ogniu wojny spalił realizowane przez dekady kosztowne inwestycje w rynek europejski.

## Obniżki cen paliw będą hamować. Oto prognozy na nadchodzący tydzień
 - [https://www.money.pl/gospodarka/obnizki-cen-paliw-beda-hamowac-oto-prognozy-na-nadchodzacy-tydzien-6870004334451328a.html](https://www.money.pl/gospodarka/obnizki-cen-paliw-beda-hamowac-oto-prognozy-na-nadchodzacy-tydzien-6870004334451328a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 13:59:05+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9507f9ba-9d2e-435b-82dd-114caf5562d8" width="308" /> W nadchodzącym tygodniu najpewniej nie będzie już kolejnej obniżki średnich cen diesla. Stabilne powinny być też ceny Pb98, 95 i autogazu – prognozują analitycy e-petrol.pl. Z kolei eksperci BM Reflex dodają, że nawet jeżeli dojdzie do obniżek cen paliw, to będą one w znacznie mniejszej skali niż dotychczas.

## CEO Hiltona żałuje zakupu Porsche. "Wydałem wszystko na ten głupi samochód"
 - [https://www.money.pl/gospodarka/ceo-hiltona-zaluje-zakupu-porsche-wydalem-wszystko-na-ten-glupi-samochod-6869991890983520a.html](https://www.money.pl/gospodarka/ceo-hiltona-zaluje-zakupu-porsche-wydalem-wszystko-na-ten-glupi-samochod-6869991890983520a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 13:08:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5ef92ab0-e0ef-469e-9ad8-36aeb6449f0f" width="308" /> Chris Nassetta, CEO Hiltona, opowiedział o zakupie swojego pierwszego samochodu. Wybrał czarnego Porsche 944, co było, jak sam twierdzi, najgorszą decyzją inwestycyjną w jego życiu. – Wydałem wszystkie moje pieniądze na ten głupi samochód – przyznał.

## Po roku wojny w Polsce pracę znalazło blisko milion Ukraińców
 - [https://www.money.pl/gospodarka/po-roku-wojny-w-polsce-prace-znalazlo-blisko-milion-ukraincow-6869970828999296a.html](https://www.money.pl/gospodarka/po-roku-wojny-w-polsce-prace-znalazlo-blisko-milion-ukraincow-6869970828999296a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 11:42:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/595d2ea5-5075-40e5-93e2-e12b52685582" width="308" /> Na mocy specustawy zatrudnienie w Polsce znalazło ponad 900 tys. obywateli Ukrainy - najnowsze dane przekazała minister rodziny i polityki społecznej Marlena Maląg. Dodała, że ponad 9 tys. obywateli Ukrainy podjęło pracę na Podkarpaciu, a ponad 16 tys. firm założyli w Polce obywateli Ukrainy.

## Wielki powrót kontrowersyjnego jachtu. "I Love Poland" w czołówce prestiżowych regat
 - [https://www.money.pl/gospodarka/wielki-powrot-kontrowersyjnego-jachtu-i-love-poland-w-czolowce-prestizowych-regat-6869954571205216a.html](https://www.money.pl/gospodarka/wielki-powrot-kontrowersyjnego-jachtu-i-love-poland-w-czolowce-prestizowych-regat-6869954571205216a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 10:36:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/76c4383a-d93b-4e7c-89ab-a4cf3c27546d" width="308" /> Promujący Polskę jacht "I Love Poland" jako drugi wśród jednokadłubowców dopłynął do mety karaibskich regat - poinformował w piątek PAP Temistokles Brodowski z Polskiej Fundacji Narodowej, która jest właścicielem łodzi.

## Kolejny problem z węglem. Są nowe propozycje
 - [https://www.money.pl/gielda/kolejny-problem-z-weglem-sa-nowe-propozycje-6869947133687425v.html](https://www.money.pl/gielda/kolejny-problem-z-weglem-sa-nowe-propozycje-6869947133687425v.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 10:07:24+00:00

<img src="https://i.wpimg.pl/308x/wptv-upload-api.wpcdn.pl/be17fc7d-c99c-4c6f-9bc0-8fec55346208.jpg" width="308" /> Ministerstwo Aktywów Państwowych zapowiedziało wprowadzenie rozwiązań, które pozwolą samorządom zagospodarować nadwyżki węgla. - Martwimy się o to, co będzie, jak mieszkańcy go od nas nie odbiorą - mówił w programie "Money.pl" Marek Wójcik ze Związku Miast Polskich. Jak zaznaczył, rozmowy z rządem w tej sprawie, póki co, "wyglądają dobrze". - Po pierwsze będziemy mogli sprzedawać więcej niż trzy tony. Zależy nam też, żeby można było do sprzedaży podchodzić elastycznie i żebyśmy mogli np. zachować ten węgiel dla własnych spółek komunalnych czy przekazać innemu samorządowi, który go potrzebuje. Chcemy też prosić o wydłużenie czasu na sprzedaż. Wstępnie umówiliśmy się na okres do połowy roku. Obecnie o węgiel można wnioskować do 15 kwietnia - wyjaśnił. Dodał, że samorządy myślą też o przyszłości. - Pytamy, czy rząd chce, abyśmy dalej sprzedawali węgiel. Zależy nam też na przedsiębiorcach. Po doświadczeniach z tej zimy prosimy, aby rząd nie ingerował w rynek, żeby pozwolił przedsiębiorcom sprzedawać, a samorządy traktował jako swego rodzaju bezpiecznik przygotowany na sytuację kryzysową - wyjaśnił Marek Wójcik.

## W Moskwie rośnie stos pieniędzy z Zachodu. Inwestorzy są w potrzasku
 - [https://www.money.pl/gospodarka/w-moskwie-rosnie-stos-pieniedzy-z-zachodu-inwestorzy-sa-w-potrzasku-6869947338766976a.html](https://www.money.pl/gospodarka/w-moskwie-rosnie-stos-pieniedzy-z-zachodu-inwestorzy-sa-w-potrzasku-6869947338766976a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 10:07:09+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3a7d18de-3514-4ddd-ba2b-d0fb661747ab" width="308" /> Dywidendy z akcji, odsetki od obligacji i wszystko inne, czego zachodni inwestorzy nie sprzedali przed wojną - to wszystko jest częścią stosu pieniędzy, które zostały uwięzione przez sankcje w Moskwie - informuje Bloomberg. Zagraniczni inwestorzy uważają,  że nigdy nie będą w stanie uzyskać dostępu do gotówki.

## Latarnik wyborczy – czym jest i jak z niego skorzystać?
 - [https://www.money.pl/gospodarka/latarnik-wyborczy-czym-jest-i-jak-z-niego-skorzystac-6869624815340128a.html](https://www.money.pl/gospodarka/latarnik-wyborczy-czym-jest-i-jak-z-niego-skorzystac-6869624815340128a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 09:56:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fc7a1978-21bd-4d9f-83a9-66e75dd38f76" width="308" /> Osoby mające czynne prawo wyborcze, uprawnione do głosowania, spełniając swój obywatelski obowiązek, oddają głos na wybranego kandydata, partię czy ugrupowanie polityczne. Swój głos zaznaczony prawidłowo na karcie do głosowania wrzucają do urny w trakcie m.in. wyborów parlamentarnych, prezydenckich czy samorządowych i do Parlamentu Europejskiego. Jeśli nie do końca wiesz, na kogo oddać swój głos, wsparciem dla Ciebie może okazać się latarnik wyborczy. Co to jest?

## O tych ulgach  podatkowych lepiej pamiętać. Można sporo zyskać
 - [https://www.money.pl/podatki/o-tych-ulgach-podatkowych-lepiej-pamietac-mozna-sporo-zyskac-6869925487266400a.html](https://www.money.pl/podatki/o-tych-ulgach-podatkowych-lepiej-pamietac-mozna-sporo-zyskac-6869925487266400a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 08:38:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/57175119-df47-4d39-8c95-9597d8192d81" width="308" /> Podatnicy, rozliczając się z fiskusem, mogą sobie odliczyć nie tylko wydatki na leki, ale także koszty internetu. Na liście ulg  jest także  500 plus dla związkowca, ulga za oddaną krew, czy za oszczędzanie na prywatną emeryturę - przypomina serwis wyborcza.biz.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 24.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-24-02-2023-6869924816312928a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-24-02-2023-6869924816312928a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 08:35:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 24.02.2023. W piątek za jednego dolara (USD) trzeba zapłacić 4.4569 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 24.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-24-02-2023-6869924752611936a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-24-02-2023-6869924752611936a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 08:35:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 24.02.2023. W piątek za jedno euro (EUR) trzeba zapłacić 4.7236 zł.

## 100 mld zł przychodów i 8 mld zł zysku. To najnowsze wyniki Orlenu
 - [https://www.money.pl/gospodarka/100-mld-zl-przychodow-i-8-mld-zl-zysku-to-najnowsze-wyniki-orlenu-6869898356820576a.html](https://www.money.pl/gospodarka/100-mld-zl-przychodow-i-8-mld-zl-zysku-to-najnowsze-wyniki-orlenu-6869898356820576a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 06:47:55+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0b8423b0-4ed8-4251-a3e1-b9b3259cfe60" width="308" /> Połączona Grupa Orlen wypracowała w czwartym kwartale 2022 roku przychody na poziomie ponad 100 miliardów złotych, z których 8 proc. to zysk netto w wysokości 8,1 miliarda złotych - poinformowała spółka.

## Najlepsze wyniki finansowe Orlenu w historii. Spółka liczy zyski
 - [https://www.money.pl/gielda/orlen-wyniki-finansowe-iv-kwartal-2022-r-100-mld-zl-przychodow-i-8-mld-zl-zysku-6869898356820576a.html](https://www.money.pl/gielda/orlen-wyniki-finansowe-iv-kwartal-2022-r-100-mld-zl-przychodow-i-8-mld-zl-zysku-6869898356820576a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 06:47:55+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0b8423b0-4ed8-4251-a3e1-b9b3259cfe60" width="308" /> Grupa Orlen wypracowała w IV kwartale 2022 r. zysk netto w wysokości 8,1 miliarda złotych. Zysk za cały 2022 r. przekroczył 21 miliardów zł. To najlepsze wyniki w historii. Podobne rekordy z powodu kryzysu energetycznego odnotowały jednak spółki z sektora na całym świecie.

## Kursy walut 24.02.2023. Piątkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-24-02-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6869893243939456a.html](https://www.money.pl/pieniadze/kursy-walut-24-02-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6869893243939456a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 06:27:08+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 24.02.2023. W piątek za jednego dolara (USD) zapłacimy 4.46 zł. Cena jednego funta szterlinga (GBP) to 5.36 zł, a franka szwajcarskiego (CHF) 4.77 zł. Z kolei euro (EUR) możemy zakupić za 4.72 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 24.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-24-02-2023-6869886911007328a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-24-02-2023-6869886911007328a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 06:01:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 24.02.2023. W piątek za jednego franka (CHF) trzeba zapłacić 4.7717 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 24.02.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-24-02-2023-6869886911089248a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-24-02-2023-6869886911089248a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 06:01:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 24.02.2023. W piątek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.359 zł.

## Tusk zapowiada program "Cela plus". "Dla tych, którzy zbudowali system dojenia państwa"
 - [https://www.money.pl/gospodarka/tusk-zapowiada-program-cela-plus-dla-tych-ktorzy-zbudowali-system-dojenia-panstwa-6869879942236768a.html](https://www.money.pl/gospodarka/tusk-zapowiada-program-cela-plus-dla-tych-ktorzy-zbudowali-system-dojenia-panstwa-6869879942236768a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 05:32:59+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8916a729-3e05-43f1-91bc-0d473c145343" width="308" /> Cela+ będzie programem przygotowanym dla tych wszystkich, którzy w sposób tak bezprzykładny, tak świetnie zorganizowany zbudowali system dojenia państwa i publicznych pieniędzy - powiedział w TVN24 szef PO Donald Tusk.

## Wyższe rachunki za prąd i gaz. Firmy zawnioskowały o ponad 3,8 mld zł wsparcia
 - [https://www.money.pl/gospodarka/wyzsze-rachunki-za-prad-i-gaz-firmy-zawnioskowaly-o-ponad-3-8-mld-zl-wsparcia-6869876474358400a.html](https://www.money.pl/gospodarka/wyzsze-rachunki-za-prad-i-gaz-firmy-zawnioskowaly-o-ponad-3-8-mld-zl-wsparcia-6869876474358400a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-24 05:18:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bba6dd06-c82d-40d4-9b54-b35e56e8d846" width="308" /> Firmy energochłonne złożyły wnioski na ponad 3,8 mld zł finansowego wsparcia - dowiedziała się PAP w Narodowym Funduszu Ochrony Środowiska i Gospodarki Wodnej. Najwięcej, bo 151 wniosków złożyły duże firmy. Przedsiębiorstwa wnioskowały głównie o pomoc w wysokości do 4 mln euro.

