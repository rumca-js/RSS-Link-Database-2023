# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## UE zatwierdziła 10. pakiet sankcji wobec Rosji. "Najpotężniejsze i najdalej idące"
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8667460,ue-10-pakiet-sankcji-wobec-rosji.html](https://forsal.pl/swiat/unia-europejska/artykuly/8667460,ue-10-pakiet-sankcji-wobec-rosji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 21:51:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/f7iktkuTURBXy83OWYyY2E2OS1kZGVjLTRkMGMtYjY2Mi03ZWU5NTcwODViYjUuanBlZ5GTBc0BHcyg" />Unia Europejska zatwierdziła w rocznicę inwazji Moskwy na Ukrainę 10. pakiet sankcji wobec Rosji - poinformowała w piątek późnym wieczorem szwedzka prezydencja UE.

## Egzamin czasu wojny zdaliśmy. Przed nami egzamin czasu pokoju
 - [https://forsal.pl/swiat/ukraina/artykuly/8667034,egzamin-czasu-wojny-zdalismy-egzamin-z-czasu-pokoju.html](https://forsal.pl/swiat/ukraina/artykuly/8667034,egzamin-czasu-wojny-zdalismy-egzamin-z-czasu-pokoju.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 21:19:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QPoktkuTURBXy84ZTc5NzJkMC1mMTQzLTRkODUtYWJhNi01M2M2ZDkzYjNkMjAuanBlZ5GTBc0BHcyg" />Wojna nam powszednieje, ale to nie znaczy, że przestaliśmy pomagać Ukraińcom. Tak, pojawiają się animozje, ale na mniejszą skalę, niż można się było spodziewać.

## Ukraina nie walczy sama. Wojna zmieniła realia światowej polityki
 - [https://forsal.pl/swiat/ukraina/artykuly/8667103,ukraina-nie-walczy-samarealia-swiatowej-polityki.html](https://forsal.pl/swiat/ukraina/artykuly/8667103,ukraina-nie-walczy-samarealia-swiatowej-polityki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 21:18:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_AfktkuTURBXy9jYzg2YTA4NC1kYmYyLTQyNWItYjYyMC05ZmNjZDAwYjkyNmMuanBlZ5GTBc0BHcyg" />Wolny świat mówi „nie” rosyjskiej agresji.

## Kazharski: Zwolennicy teorii realizmu na Zachodzie nie rozumieją Rosji [WYWIAD]
 - [https://forsal.pl/swiat/ukraina/artykuly/8667272,kazharski-postzachodni-lad-to-zludzenie.html](https://forsal.pl/swiat/ukraina/artykuly/8667272,kazharski-postzachodni-lad-to-zludzenie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 21:17:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sm2ktkuTURBXy80NGI4NzBkMS0zY2VjLTQ5MzctODA2Ny1hZmRjM2RjZDhmN2EuanBlZ5GTBc0BHcyg" />Z punktu widzenia Rosji Ukraina to trofeum w maczystowskiej grze wielkich mocarstw. Ludzie w Moskwie uważają, że mają prawo do podporządkowywania sobie sąsiednich krajów, a Zachód powinien to uznać - mówi w wywiadzie Aliaksei Kazharski.

## Buda: Intensywnie działamy na rzecz rozwoju współpracy
 - [https://forsal.pl/biznes/artykuly/8667022,buda-dzialamy-na-rzecz-rozwoju-wspolpracy.html](https://forsal.pl/biznes/artykuly/8667022,buda-dzialamy-na-rzecz-rozwoju-wspolpracy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 21:15:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tRpktkuTURBXy84YjdjYWU3MS0wMWE1LTQ0NjctOWFjNS05MzM1ZjNlZGFhMjAuanBlZ5GTBc0BHcyg" />Ukraina jest teraz naszym 9. partnerem w eksporcie i zajmuje 15. miejsce pod względem importu. W początkowych miesiącach wojny nikt nie spodziewałby się tak dobrych wyników. Nawiązane pozytywne relacje będą przynosiły długofalowe korzyści, a współpraca będzie kontynuowana także w przyszłości, przy projektach odbudowy – mówi w wywiadzie Waldemar Buda, minister rozwoju i technologii.

## Błędne kalkulacje Zachodu. Zatrzymanie rosyjskiej inwazji to był dopiero początek
 - [https://forsal.pl/swiat/ukraina/artykuly/8666997,zatrzymanie-rosyjskiej-inwazji-to-byl-dopiero-poczatek.html](https://forsal.pl/swiat/ukraina/artykuly/8666997,zatrzymanie-rosyjskiej-inwazji-to-byl-dopiero-poczatek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 21:14:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bEpktkuTURBXy83NTU5ZGQ4NS1kNWJlLTRhMmEtOGNkZS00MDZjOTIzNzliYjUuanBlZ5GTBc0BHcyg" />Jeśli Rosja zajmie Ukrainę, następnie anektuje Białoruś i Mołdawię. A jednocześnie przekieruje wszystkie siły do prowadzenia wojny hybrydowej przeciwko Polsce, Rumunii i państwom bałtyckim - mówi w wywiadzie Krzysztof Wojczal.

## "WSJ": Scholz i Macron powiedzieli Zełenskiemu, że powinien rozważać rozmowy z Moskwą
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667444,wsj-scholz-i-macron-zelenski-rozmowy-z-moskwa.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667444,wsj-scholz-i-macron-zelenski-rozmowy-z-moskwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 20:04:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eo0ktkuTURBXy85NmI4OTliMy1lNGFiLTRjMzUtOTEzYi04YjM3ODQwNDQ2ZDguanBlZ5GTBc0BHcyg" />Prezydent Francji Emmanuel Macron i kanclerz Niemiec Olaf Scholz mieli powiedzieć prezydentowi Ukrainy Wołodymyrowi Zełenskiemu, że musi zacząć rozważać rozmowy pokojowe z Moskwą, nawet jeśli Rosja nadal będzie okupować ukraińskie terytorium - twierdzi &quot;Wall Street Journal&quot; (&quot;WSJ&quot;). Miało do tego dojść podczas spotkania trzech polityków w Paryżu na początku lutego.

## Dodatkowe 2,5 mld dol. dla Ukrainy. Bank Światowy wesprze Kijów
 - [https://forsal.pl/swiat/ukraina/artykuly/8667436,bank-swiatowy-25-mld-dol-dla-ukrainy.html](https://forsal.pl/swiat/ukraina/artykuly/8667436,bank-swiatowy-25-mld-dol-dla-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 19:14:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FYmktkuTURBXy8xNjViMDBkMi0xY2QzLTRmOGUtYmEzNy1mOTE3NjE2MjQzY2QuanBlZ5GTBc0BHcyg" />Bank Światowy poinformował w piątek, że przeznacza 2,5 mld dolarów w postaci grantów na dodatkową pomoc dla Ukrainy, aby wesprzeć budżet kraju i zapewnić Ukraińcom dostęp do podstawowych usług.

## 2/3 działających w Ukrainie terminali Starlink dostarczyła Polska
 - [https://forsal.pl/swiat/ukraina/artykuly/8667425,polska-terminale-starlink-ukraina.html](https://forsal.pl/swiat/ukraina/artykuly/8667425,polska-terminale-starlink-ukraina.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 18:05:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9PDktkuTURBXy83OTVhNTEyYi0wNmNlLTQwOGEtOGNmMi0zN2Q4MjM3MWQ3OGQuanBlZ5GTBc0BHcyg" />W ramach pomocy, w ciągu minionego roku, dostarczyliśmy Ukrainie dwie trzecie terminali Starlink, która tam dziś funkcjonują – powiedział w piątek na antenie Radia Wrocław pełnomocnik rządu ds. cyberbezpieczeństwa Janusz Cieszyński.

## "Rosja może napaść na jeszcze jeden kraj". Niepokojące słowa Zełenskiego
 - [https://forsal.pl/swiat/rosja/artykuly/8667421,zelenski-rosja-moze-napasc-na-jeszcze-jeden-kraj.html](https://forsal.pl/swiat/rosja/artykuly/8667421,zelenski-rosja-moze-napasc-na-jeszcze-jeden-kraj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 17:42:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5sVktkuTURBXy83MDE1YzY4Zi0yNzhmLTRmZTMtYTJiMy1kOWNlODY3ODkyZmMuanBlZ5GTBc0BHcyg" />Rosja może napaść na jeszcze jeden kraj - ostrzegł w piątek na konferencji prasowej prezydent Ukrainy Wołodymyr Zełenski. Putin musi pokazać jakiś sukces - dodał.

## Byli szefowie i pracownicy KNF chcą umorzenia sprawy o zaniedbania wobec SKOK Wołomin
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8667419,skok-wolomin-byli-szefowie-i-pracownicy-knf-chca-umorzenia.html](https://forsal.pl/finanse/aktualnosci/artykuly/8667419,skok-wolomin-byli-szefowie-i-pracownicy-knf-chca-umorzenia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 17:36:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0hNktkuTURBXy9jYTVhMGE0My0yNTc5LTQxZTUtOWE0NC05NTE3ZDdkMmNhZDcuanBlZ5GTBc0BHcyg" />W piątek w warszawskim sądzie odbyło się posiedzenie organizacyjne dotyczące sprawy urzędników Komisji Nadzoru Finansowego, w tym jej byłego szefa Andrzeja Jakubiaka i jego zastępcy Wojciecha Kwaśniaka.

## Współpraca przy produkcji czołgów K2 i armatohaubic K9. PGZ ma umowy
 - [https://forsal.pl/biznes/przemysl/artykuly/8667414,pgz-produkcja-czolgow-k2-i-armatohaubic-k9.html](https://forsal.pl/biznes/przemysl/artykuly/8667414,pgz-produkcja-czolgow-k2-i-armatohaubic-k9.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 17:28:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4JLktkuTURBXy9kMjE5NjM5ZS0yMmZiLTRhZjQtOTM2My0zZjZhMmU3Zjc5Y2UuanBlZ5GTBc0BHcyg" />Polska Grupa Zbrojeniowa podpisała z koreańskimi producentami uzbrojenia umowy o współpracy przy produkcji czołgów K2 i samobieżnych armatohaubic K9 – poinformowała PGZ w piątek.

## Niemcy skomentowały chiński plan pokojowy dla Ukrainy
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667411,niemcy-chinski-plan-pokojowy-dla-ukrainy.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667411,niemcy-chinski-plan-pokojowy-dla-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 17:09:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6wKktkuTURBXy85ZGMwMThjOS01NGYxLTQzMzUtYjQ2My01NjJlYzk3NjdhOTMuanBlZ5GTBc0BHcyg" />Minister spraw zagranicznych Niemiec, Annalena Baerbock, odnosząc się w piątek w Radzie Bezpieczeństwa ONZ do chińskiego planu pokojowego dla Ukrainy, podkreśliła, że ci, którzy mówią o pokoju, &quot;nie mogą pod tym słowem rozumieć podległości&quot;. Dodała, że Chiny mogłyby wpłynąć na Rosję, by wypełniła w stosunku do Ukrainy postanowienia rezolucji Narodów Zjednoczonych.

## GPW pod kreską. WIG20 spadł o 0,96 proc.
 - [https://forsal.pl/finanse/gielda/artykuly/8667404,gpw-pod-kreska-wig20-spadl-o-096-proc.html](https://forsal.pl/finanse/gielda/artykuly/8667404,gpw-pod-kreska-wig20-spadl-o-096-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 16:53:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1cWktkuTURBXy81N2ZmN2JhYi04ZjFmLTRiYjEtYTU1Ni0wNmRiZTI4OWU2Y2UuanBlZ5GTBc0BHcyg" />undefined

## Niemcy przekażą Ukrainie kolejne cztery czołgi Leopard 2 A6
 - [https://forsal.pl/swiat/ukraina/artykuly/8667398,niemcy-ukraina-leopard.html](https://forsal.pl/swiat/ukraina/artykuly/8667398,niemcy-ukraina-leopard.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 16:28:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/E3ektkuTURBXy8xNDA5YzNmMS0zNDY5LTRjNGEtYWJkNy0zYjViODdjNmM0YmQuanBlZ5GTBc0BHcyg" />Minister obrony RFN Boris Pistorius podjął decyzję o przekazaniu Ukrainie kolejnych czterech czołgów Leopard 2 A6 z niemieckich zapasów wojskowych - poinformował w piątek resort obrony w Berlinie. &quot;Niemcy zwiększają tym samym liczbę przekazanych czołgów z 14 do 18&quot; - dodało ministerstwo.

## Zełenski: Państwa bałtyckie i Polska wspierają nas we wszystkim, o cokolwiek byśmy poprosili
 - [https://forsal.pl/swiat/ukraina/artykuly/8667394,zelenski-panstwa-baltyckie-i-polska-wspieraja-nas-we-wszystkim.html](https://forsal.pl/swiat/ukraina/artykuly/8667394,zelenski-panstwa-baltyckie-i-polska-wspieraja-nas-we-wszystkim.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 16:17:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Dz4ktkuTURBXy83MDgzNWE0YS1jYzg5LTQyMTMtYThiYi02ZTIxNjZmMWM5NDcuanBlZ5GTBc0BHcyg" />Państwa bałtyckie i Polska wspierają nas we wszystkim, o cokolwiek byśmy poprosili - oświadczył w piątek prezydent Ukrainy Wołodymyr Zełenski podczas konferencji prasowej.

## Ukraina chce się wzorować na Polsce. Chodzi o system ochrony zdrowia
 - [https://forsal.pl/swiat/ukraina/artykuly/8667393,ukraina-chce-sie-wzorowac-na-polsce-system-ochrony-zdrowia.html](https://forsal.pl/swiat/ukraina/artykuly/8667393,ukraina-chce-sie-wzorowac-na-polsce-system-ochrony-zdrowia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 16:08:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AROktkuTURBXy9jMDE1MmFiNi1kMTY0LTRiMmUtODFlNC01NWVhODdlZjA0OGEuanBlZ5GTBc0BHcyg" />Mimo trwającej wojny Ukraina pracuje nad odbudową swojego systemu ochrony zdrowia. I chce wzorować się na Polsce - powiedział w rozmowie z Interią minister zdrowia Adam Niedzielski.

## Liderzy Trójkąta Weimarskiego zadeklarowali wsparcie dla Ukrainy
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667390,trojkat-weimarski-wsparcie-dla-ukrainy.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667390,trojkat-weimarski-wsparcie-dla-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 16:00:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/d5lktkuTURBXy8yN2M2MDZjZC04ZDkwLTRkNjMtYjRhMy1jZTVlZmM2Zjg4ZGUuanBlZ5GTBc0BHcyg" />Państwa Trójkąta Weimarskiego będą nadal mocno wspierać Ukrainę i jej naród tak długo, jak będzie to konieczne. Wzywają Rosję do bezwarunkowego zaprzestania działań wojennych i wycofania swoich sił z całego terytorium Ukrainy - czytamy we wspólnym oświadczeniu przywódców Polski, Francji i Niemiec.

## Wspólna produkcja militarna z USA? Prezydent Duda zabrał głos
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667388,wspolna-produkcja-militarna-z-usa-prezydent-duda.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667388,wspolna-produkcja-militarna-z-usa-prezydent-duda.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 15:57:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rJ_ktkuTURBXy9mOGI0MzY0Zi1jMTg3LTQ4OWEtYWE3ZC02MTUwMGM1Y2ViZWMuanBlZ5GTBc0BHcyg" />Rozmawiałem z prezydentem USA Joe Bidenem o rozpoczęciu wspólnej produkcji militarnej np. amunicji, wiec można powiedzieć, że rozmowa na ten temat, na tym najwyższym prezydenckim poziomie ze Stanami Zjednoczonymi została rozpoczęta - powiedział w piątek prezydent Andrzej Duda po posiedzeniu RBN.

## Prezydent po posiedzeniu RBN: Wszyscy de facto mówimy jednym głosem
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667383,prezydent-po-posiedzeniu-rbn-wszyscy-mowimy-jednym-glosem.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667383,prezydent-po-posiedzeniu-rbn-wszyscy-mowimy-jednym-glosem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 15:42:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rJ_ktkuTURBXy9mOGI0MzY0Zi1jMTg3LTQ4OWEtYWE3ZC02MTUwMGM1Y2ViZWMuanBlZ5GTBc0BHcyg" />Widać, że gremium obecne na RBN poważnie podchodzi do polskich spraw i kwestii na Ukrainie; ta sprawa nie jest przedmiotem politycznych sporów, a podejście wszystkich uczestników debaty jest niezwykle konstruktywne - powiedział prezydent Andrzej Duda po posiedzeniu Rady Bezpieczeństwa Narodowego.

## Ukraina otrzyma myśliwce F-16 od USA? "Analizujemy możliwość"
 - [https://forsal.pl/swiat/usa/artykuly/8667379,ukraina-mysliwce-f-16-od-usa-nuland.html](https://forsal.pl/swiat/usa/artykuly/8667379,ukraina-mysliwce-f-16-od-usa-nuland.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 15:37:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-hkktkuTURBXy85MGQxOTBkNi03MmZkLTRjM2UtYjVkOS0wMjc0ZDVkMWQ1MTYuanBlZ5GTBc0BHcyg" />Analizujemy możliwość przekazania Ukrainie samolotów bojowych czwartej generacji, takich jak F-16, a także nowszych maszyn; jednak w tej kwestii nie zapadły jeszcze żadne wiążące decyzje - poinformowała w rozmowie z dziennikiem &quot;Washington Post&quot; podsekretarz stanu USA Victoria Nuland.

## Chiny udzieliły wsparcia Białorusi: Sprzeciwstawiamy się „ingerencjom obcych sił”
 - [https://forsal.pl/swiat/chiny/artykuly/8667375,chiny-bialorus-sprzeciwstawiamy-sie-ingerencjom-obcych-sil.html](https://forsal.pl/swiat/chiny/artykuly/8667375,chiny-bialorus-sprzeciwstawiamy-sie-ingerencjom-obcych-sil.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 15:18:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SpiktkuTURBXy9mYWI5ZDM1YS0wMDBlLTQ5NzEtYjE4YS1iOTMxMzg0ODBjODAuanBlZ5GTBc0BHcyg" />Chiny będą dalej popierały Białoruś w wysiłkach na rzecz &quot;utrzymania stabilności&quot; oraz sprzeciwiały się „obcym siłom” ingerującym w wewnętrzne sprawy tego kraju, jak również nakładaniu na niego „nielegalnych sankcji” – oświadczył w piątek szef chińskiego MSZ Qin Gang.

## Yellen o nowych "znaczących" sankcjach na Rosję: Trudne do ominięcia
 - [https://forsal.pl/swiat/usa/artykuly/8667369,yellen-sankcje-na-rosje-trudne-do-ominiecia.html](https://forsal.pl/swiat/usa/artykuly/8667369,yellen-sankcje-na-rosje-trudne-do-ominiecia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 14:55:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/N0qktkuTURBXy9iYjZkOTVlZC05Nzg5LTQ4ZTYtYTg5OS01ZWVhYTE3ZmQ4OWYuanBlZ5GTBc0BHcyg" />Minister finansów USA Janet Yellen poinformowała w piątek, w rocznicę rosyjskiej napaści na Ukrainę, że jej resort nakłada nowe, &quot;znaczące&quot; sankcje na Rosję. Restrykcje będą wymierzone w konkretne osoby, firmy i instytucje finansowe. Kolejne sankcje zapowiedział też Departament Stanu.

## Szwedzkie Leopardy dla Ukrainy. Jest decyzja Sztokholmu
 - [https://forsal.pl/swiat/ukraina/artykuly/8667359,szwecja-czolgi-leopard-dla-ukrainy.html](https://forsal.pl/swiat/ukraina/artykuly/8667359,szwecja-czolgi-leopard-dla-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 14:37:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YCNktkuTURBXy80ZTU4OTA4Ni04MzRhLTRiODEtYjI5NC02ZTM5YmMxZmFlNDMuanBlZ5GTBc0BHcyg" />Zdecydowaliśmy o przekazaniu Ukrainie do 10 czołgów Leopard 2 - poinformowali w piątek premier Szwecji Ulf Kristersson oraz minister obrony Pal Jonson. Dostawa ma zostać zrealizowana &quot;najszybciej jak to możliwe&quot; w koordynacji z Niemcami.

## Kolejny kraj może przekazać myśliwce Ukrainie. "Rozważamy"
 - [https://forsal.pl/swiat/ukraina/artykuly/8667357,hiszpania-mysliwce-dla-ukrainy.html](https://forsal.pl/swiat/ukraina/artykuly/8667357,hiszpania-mysliwce-dla-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 14:29:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6NfktkuTURBXy8wMmE1MWU2NS1iMGEzLTQ0YzUtOWVmYy02Y2NhOWFlZWRjZmMuanBlZ5GTBc0BHcyg" />Hiszpańskie władze nie wykluczają możliwości przekazania myśliwców Ukrainie, która od roku odpiera rosyjską inwazję - poinformował w piątek w rozmowie z dziennikarzami premier Hiszpanii Pedro Sanchez.

## Zełenski: Dotarły do nas pierwsze czołgi z Polski
 - [https://forsal.pl/swiat/ukraina/artykuly/8667348,zelenski-dotarly-do-nas-pierwsze-czolgi-z-polski.html](https://forsal.pl/swiat/ukraina/artykuly/8667348,zelenski-dotarly-do-nas-pierwsze-czolgi-z-polski.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 14:19:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/db3ktkuTURBXy9iZWVhZWE4Mi1mNGRjLTQ4ZTctODc2ZC1kYzdjZTAzYTU4ZTguanBlZ5GTBc0BHcyg" />Dzisiaj możemy poinformować o pierwszych czołgach, które otrzymaliśmy z Polski; te czołgi są już na Ukrainie i będą wzmacniać naszą obronę - oświadczył w piątek w Kijowie prezydent Ukrainy Wołodymyr Zełenski podczas wspólnej konferencji z premierem Mateuszem Morawieckim w pierwszą rocznicę rosyjskiej agresji.

## Gen. Polko: Rosyjska „druga armia świata” to mit z defilad
 - [https://forsal.pl/swiat/ukraina/artykuly/8667344,gen-polko-rosyjska-druga-armia-swiata-to-mit-z-defilad.html](https://forsal.pl/swiat/ukraina/artykuly/8667344,gen-polko-rosyjska-druga-armia-swiata-to-mit-z-defilad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 14:12:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1cXktkuTURBXy83ZjA5ODZkNy0zMTNiLTRkOWYtYmY2ZS0wZjdmYzEwMzJkMjguanBlZ5GTBc0BHcyg" />Ukraińcy pokazali, że „druga armia świata” to mit z defilad - ocenił w pierwszą rocznicę pełnoskalowej agresji Rosji na Ukrainę były dowódca GROM gen. Roman Polko. Wyraził nadzieję, że Ukraina wkrótce otrzyma broń, która umożliwi jej wyparcie okupanta z jej terytorium. Ocenił, że wojna potrwa jeszcze 2-3 lata.

## Historyk: Ukraina jest już bardziej zintegrowana z NATO niż kraje członkowskie
 - [https://forsal.pl/swiat/ukraina/artykuly/8667339,historyk-ukraina-nato.html](https://forsal.pl/swiat/ukraina/artykuly/8667339,historyk-ukraina-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 14:00:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KF-ktkuTURBXy8wZTc5ZjUzMy1iZjBkLTQ1ZDYtYjMxNy01ZDkzMjFlMmE5ZGIuanBlZ5GTBc0BHcyg" />Ukraina jest chyba bardziej zintegrowana z NATO niż kraje, które już są członkami Sojuszu – stwierdził w wywiadzie dla francuskiego dziennika „Le Figaro” Serhij Płochij, ukraiński historyk z Uniwersytetu Harvarda.

## PKN Orlen nie zmienia planów dot. rozwoju morskiej energetyki wiatrowej
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8667332,pkn-orlen-plany-dot-rozwoju-morskiej-energetyki-wiatrowej.html](https://forsal.pl/biznes/aktualnosci/artykuly/8667332,pkn-orlen-plany-dot-rozwoju-morskiej-energetyki-wiatrowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 13:45:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_FSktkuTURBXy9mZWYwMTYwOS02Y2UxLTQyYzktYTVkMy1iYjA5NGU4YWZhMzUuanBlZ5GTBc0BHcyg" />undefined

## KNF zgodziła się na wycofanie z obrotu na GPW akcji ZPUE i Atlas Estates
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8667330,knf-wycofanie-z-obrotu-na-gpw-akcji-zpue-i-atlas-estates.html](https://forsal.pl/biznes/aktualnosci/artykuly/8667330,knf-wycofanie-z-obrotu-na-gpw-akcji-zpue-i-atlas-estates.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 13:43:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fhiktkuTURBXy9kNzM5MjRmZi00MGMyLTQ2ODUtOWI3YS0wNzg5ODIwMzZiMzUuanBlZ5GTBc0BHcyg" />undefined

## Morawiecki: Polska na dniach przekaże Ukrainie czołgi PT-91
 - [https://forsal.pl/swiat/ukraina/artykuly/8667328,morawiecki-polska-czolgi-pt-91-ukraina.html](https://forsal.pl/swiat/ukraina/artykuly/8667328,morawiecki-polska-czolgi-pt-91-ukraina.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 13:39:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/384ktkuTURBXy9mYjNmMmFkNC1mOGNiLTQ1NTQtYWQ0Yy05ZmU1Njg0YTEyNjAuanBlZ5GTBc0BHcyg" />Na dniach przekażemy Ukrainie bardzo dobre czołgi PT-91 - powiedział w piątek w Kijowie premier Mateusz Morawiecki. Dodał, że w Polsce trwa obecnie bardzo intensywne szkolenie żołnierzy ukraińskich.

## Prezydent Niemiec: Putin chce wygrać, ale już przegrał
 - [https://forsal.pl/swiat/rosja/artykuly/8667324,steinmeier-putin-chce-wygrac-ale-juz-przegral.html](https://forsal.pl/swiat/rosja/artykuly/8667324,steinmeier-putin-chce-wygrac-ale-juz-przegral.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 13:37:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TyEktkuTURBXy80NGRjOWYyYy1lOTZlLTRjOWItOWRjYy05YjFmODc5OTNjY2QuanBlZ5GTBc0BHcyg" />Podczas uroczystości w rocznicę inwazji Rosji na Ukrainę prezydent Niemiec Frank-Walter Steinmeier obiecał Ukrainie dalszą solidarność i wsparcie. Władimir Putin chce wygrać, ale już przegrał - stwierdził Steinmeier w piątek w Pałacu Bellevue w Berlinie.

## Morawiecki: 10. pakiet sankcji UE jest zbyt miękki
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8667316,morawiecki-10-pakiet-sankcji-ue-jest-zbyt-miekki.html](https://forsal.pl/swiat/unia-europejska/artykuly/8667316,morawiecki-10-pakiet-sankcji-ue-jest-zbyt-miekki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 13:17:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/384ktkuTURBXy9mYjNmMmFkNC1mOGNiLTQ1NTQtYWQ0Yy05ZmU1Njg0YTEyNjAuanBlZ5GTBc0BHcyg" />10. pakiet sankcji UE jest zbyt miękki. Dzisiaj skieruję prośbę do szefowej Komisji Europejskiej o dodanie do niego kilku nazwisk rosyjskich propagandystów - powiedział w piątek w Kijowie premier Mateusz Morawiecki.

## W przyszłym tygodniu nie będzie kolejnej obniżki cen ON
 - [https://forsal.pl/transport/artykuly/8667314,w-przyszlym-tygodniu-nie-bedzie-kolejnej-obnizki-cen-on.html](https://forsal.pl/transport/artykuly/8667314,w-przyszlym-tygodniu-nie-bedzie-kolejnej-obnizki-cen-on.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 13:15:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hWBktkuTURBXy9hM2QyMjU5OS1kYWZhLTRlYzgtOTI0YS02YzkwMjNhNjg4ZmUuanBlZ5GTBc0BHcyg" />W nadchodzącym tygodniu nie będzie już kolejnej obniżki średnich cen diesla, który może kosztować 7,23-7,34 zł za litr - prognozują analitycy portalu e-eptrol.pl. Ich zdaniem między 27 lutego a 5 marca ceny na stacjach paliw będą stabilne.

## USA ogłosiły kolejne sankcje wobec Rosji. Obejmą 200 osób lub firm
 - [https://forsal.pl/swiat/usa/artykuly/8667306,usa-oglosily-kolejne-sankcje-wobec-rosji-obejma-200-osob-lub-firm.html](https://forsal.pl/swiat/usa/artykuly/8667306,usa-oglosily-kolejne-sankcje-wobec-rosji-obejma-200-osob-lub-firm.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 12:48:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nrVktkuTURBXy80OWZjM2E4YS02OTQ1LTRiODktYTQ3YS00OWMwMjJkNDViZjEuanBlZ5GTBc0BHcyg" />Administracja prezydenta USA Joe Bidena w dniu rocznicy napaści Rosji na Ukrainę ogłosiła kolejne sankcje wobec Rosji i zapowiedziała dalsze wsparcie dla Ukrainy - poinformowała w piątek stacja Sky News.

## Rekordowy zysk Orlenu. Na co gigant wyda pieniądze?
 - [https://forsal.pl/biznes/energetyka/artykuly/8667305,pkn-orlen-rekordowy-zysk-inwestycje.html](https://forsal.pl/biznes/energetyka/artykuly/8667305,pkn-orlen-rekordowy-zysk-inwestycje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 12:48:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fCvktkuTURBXy9hMWNjM2M2OS1lMjFmLTQ4YzEtOGFlMS1kMmI4ZGZhZmRlY2QuanBlZ5GTBc0BHcyg" />- Zamierzamy pozostać spółką płacącą atrakcyjną dywidendę – mówił na konferencji prasowej członek zarządu ds. finansowych Jan Szewczak.

## Jak Polacy oceniają ogólną sytuację w kraju? [SONDAŻ]
 - [https://forsal.pl/gospodarka/artykuly/8667299,jak-polacy-oceniaja-ogolna-sytuacje-w-kraju-sondaz.html](https://forsal.pl/gospodarka/artykuly/8667299,jak-polacy-oceniaja-ogolna-sytuacje-w-kraju-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 12:20:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Q1WktkuTURBXy9jYTU0OTJhNy1iYTY3LTRlZGQtYWMyNS1hMmYxZTc0NzcyMGIuanBlZ5GTBc0BHcyg" />29 proc. Polaków ocenia ogólną sytuację w Polsce jako dobrą, przeciwne zdanie ma 55 proc. ankietowanych. W lutym poprawiły się wszystkie wskaźniki nastrojów społecznych - wynika z lutowego badania Centrum Badania Opinii Społecznej.

## Nowa strategia PKN Orlen: firma stawia na sieć punktów ładowania elektryków
 - [https://forsal.pl/biznes/artykuly/8667270,nowa-strategia-pkn-orlen.html](https://forsal.pl/biznes/artykuly/8667270,nowa-strategia-pkn-orlen.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 11:27:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lD8ktkuTURBXy9mNzMyNjRmYS0xNDM0LTQwM2MtOTIzMS01Y2ExMmRiNzdlYWEuanBlZ5GTBc0BHcyg" />PKN Orlen w nowej strategii zapowie przyśpieszenie inwestycji w sieć punktów ładowania elektryków - powiedziała w rozmowie z PAP członek Zarządu ds. Sprzedaży Detalicznej PKN Orlen Patrycja Klarecka. Dodała, że poprzednie plany &quot;są nieadekwatne&quot; do tego co dzieje się na rynku.

## Brand24 miał wstępnie ok. 5,88 mln zł EBITDA w 2022 r.
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8667262,brand24-mial-wstepnie-ok-588-mln-zl-ebitda-w-2022-r.html](https://forsal.pl/biznes/aktualnosci/artykuly/8667262,brand24-mial-wstepnie-ok-588-mln-zl-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 11:14:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />undefined

## Mercor miał 11,59 mln zł zysku netto, 24,64 mln zł EBITDA w III kw. r.obr. 2022/2023
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8667260,mercor-wyniki-finansowe-zysku-netto-ebitda-w-3-kw-robr-20222023.html](https://forsal.pl/biznes/aktualnosci/artykuly/8667260,mercor-wyniki-finansowe-zysku-netto-ebitda-w-3-kw-robr-20222023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 11:12:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/34-ktkuTURBXy80ZmI5ZjBjMS0zZTc1LTRjN2QtYjJkMS00M2YzMzg4M2E3ZjUuanBlZ5GTBc0BHcyg" />undefined

## PKN Orlen planuje capex w wysokości 36,2 mld zł w 2023 r.
 - [https://forsal.pl/biznes/przemysl/artykuly/8667258,pkn-orlen-capex-naklady-na-inwestycje-w-2023-r.html](https://forsal.pl/biznes/przemysl/artykuly/8667258,pkn-orlen-capex-naklady-na-inwestycje-w-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 11:09:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IcTktkuTURBXy9kZjEyZTkyMS04YmJkLTRmZmUtODExYy05MDc4MmQ0NWVmY2UuanBlZ5GTBc0BHcyg" />undefined

## PKN Orlen miał 16,37 mld zł zysku netto, 16,06 mld zł zysku EBITDA LIFO w IV kw. 2022 r.
 - [https://forsal.pl/biznes/przemysl/artykuly/8667255,pkn-orlen-wyniki-finansowe-zysk-netto-ebitda-lifo-w-4-kw-2022-r.html](https://forsal.pl/biznes/przemysl/artykuly/8667255,pkn-orlen-wyniki-finansowe-zysk-netto-ebitda-lifo-w-4-kw-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 11:06:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wOTktkuTURBXy8xZDkyNTVlMy03ZjI1LTQ4NzUtYTBkOS1hNjlhNDVmZTc3YzIuanBlZ5GTBc0BHcyg" />undefined

## Ekspert rynku nieruchomości: Skutki wojny widoczne przede wszystkim na rynku najmu
 - [https://forsal.pl/nieruchomosci/artykuly/8667238,ekspert-rynku-nieruchomosci-skutki-wojny-widoczne-przede-wszystkim-na-rynku-najmu.html](https://forsal.pl/nieruchomosci/artykuly/8667238,ekspert-rynku-nieruchomosci-skutki-wojny-widoczne-przede-wszystkim-na-rynku-najmu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 10:03:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w46ktkuTURBXy8zYzM3MDQ4Mi0zMGZkLTRiMDItYjFmNS1iMzU0ZmQ2NjgyMzEuanBlZ5GTBc0BHcyg" />Wojna i napływ uchodźców wpłynęły przede wszystkim na rynek najmu, gdzie skokowo zmalała liczba ofert i wzrosły czynsze - ocenił ekspert portali RynekPierwotny.pl i GetHome.pl Marek Wielgo. Jeśli chodzi o sprzedaż mieszkań, wojna pogłębiła obserwowane już wcześniej spadki - dodał.

## Rok od wybuchu wojny. Zobacz, jak zmieniła się Ukraina [ZDJĘCIA]
 - [https://forsal.pl/swiat/ukraina/galeria/8667205,wojna-ukraina-przed-i-po-odbudowa-zniszczen-zdjecia.html](https://forsal.pl/swiat/ukraina/galeria/8667205,wojna-ukraina-przed-i-po-odbudowa-zniszczen-zdjecia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 09:39:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lRpktkuTURBXy9kMGNmZWU5OC1kODExLTRlYzYtYTY2ZS1mYmI4ODk4YTg5ZDguanBlZ5GTBc0BHcyg" />24 lutego mija rok od wkroczenia rosyjskich wojsk na terytorium Ukrainy. Po 12 miesiącach walki wciąż toczą się w wielu regionach kraju, ale odbudowa zniszczeń już trwa. Zobacz, jak w ciągu roku zmieniła się Ukraina.

## Rosja po raz kolejny zmieniła swoją taktykę. Celem jest wyczerpanie ukraińskiej armii
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667210,rosja-po-raz-kolejny-zmienila-swoja-taktyke-celem-jest-wyczerpanie-ukrainskiej-armii.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667210,rosja-po-raz-kolejny-zmienila-swoja-taktyke-celem-jest-wyczerpanie-ukrainskiej-armii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 09:23:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yMQktkuTURBXy85ZWZkZTZhZS1iMjc4LTRhZTctODY5ZS00MDgwYmM1Y2VmMzcuanBlZ5GTBc0BHcyg" />W ostatnich tygodniach Rosja prawdopodobnie po raz kolejny zmieniła swoją taktykę w wojnie z Ukrainą; obecnie wysiłki Kremla nie koncentrują się na zajęciu nowych terytoriów, ale na wyczerpaniu ukraińskiej armii - ocenił w piątkowym raporcie resort obrony Wielkiej Brytanii.

## Szef MON: W przyszłym tygodniu zawrzemy kontrakt ws. bojowych wozów piechoty Borsuk
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667208,szef-mon-w-przyszlym-tygodniu-zawrzemy-kontrakt-ws-bojowych-wozow-piechoty-borsuk.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667208,szef-mon-w-przyszlym-tygodniu-zawrzemy-kontrakt-ws-bojowych-wozow-piechoty-borsuk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 09:21:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5OMktkuTURBXy9kNGQ0ODczYi1jMWVmLTQ5ZDktOTU5My1hYzJjMWU5NTgxN2MuanBlZ5GTBc0BHcyg" />W przyszłym tygodniu w Hucie Stalowa Wola zawarty zostanie kontrakt w sprawie bojowych wozów piechoty Borsuk; będzie to duży kontrakt w sensie zarówno wartości, jak i przede wszystkim, na czym nam najbardziej zależy, w sensie ilości - podkreślił w piątek w Radomiu wicepremier, szef MON Mariusz Błaszczak.

## Producent filmowy Harvey Weinstein skazany na 16 lat więzienia
 - [https://forsal.pl/gospodarka/prawo/artykuly/8667177,harvey-weinstein-skazany-na-16-lat-wiezienia.html](https://forsal.pl/gospodarka/prawo/artykuly/8667177,harvey-weinstein-skazany-na-16-lat-wiezienia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 08:46:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kFmktkuTURBXy84MmU1OTc1Ni1kMzAxLTQwNTMtYWMyNy0wMDM3MjIwZDY3ZjYuanBlZ5GTBc0BHcyg" />Oskarżany przez wiele kobiet o molestowanie hollywoodzki producent Harvey Weinstein otrzymał w czwartek wyrok 16 lat więzienia za gwałt i napaść seksualną. Sąd w Los Angeles odrzucił petycję jego adwokatów o nowy proces.

## Rok wojny w Ukrainie. Dla Kijowian rocznica to czas gorzkich refleksji
 - [https://forsal.pl/swiat/ukraina/artykuly/8667172,dla-kijowian-rocznica-to-czas-gorzkich-refleksji.html](https://forsal.pl/swiat/ukraina/artykuly/8667172,dla-kijowian-rocznica-to-czas-gorzkich-refleksji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 08:40:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_0CktkuTURBXy9lYThjZDk4Ni02NjRhLTQ1MDYtYTI5YS03YzBiYWY3MmJkNzYuanBlZ5GTBc0BHcyg" />Ukraińcy wspominają o tym, jak spędzili ostatni dzień i noc przed rosyjską inwazją, co zmieniło się w ich życiu. We wspomnieniach jest dużo emocji, bólu i wiary. Wielu z nich przyznaje, że nie mogą zasnąć tej historycznie „feralnej nocy”.

## Kułeba na forum ONZ: Brak jest dowodów, że Chiny dostarczyły  broń Rosji
 - [https://forsal.pl/swiat/ukraina/artykuly/8667166,kuleba-onz-brak-dowodow-chiny-dostarczyly-bron-rosji.html](https://forsal.pl/swiat/ukraina/artykuly/8667166,kuleba-onz-brak-dowodow-chiny-dostarczyly-bron-rosji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 08:35:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fJKktkuTURBXy9jNTUzYjMxZC0xYmJjLTQ1OTYtYThmOC1jOGFkYWVlNTY0NjAuanBlZ5GTBc0BHcyg" />Ukraina nie ma dowodów na to, że Chiny dostarczały Federacji Rosyjskiej śmiercionośną broń, powiedział w czwartek Dmytro Kułeba, odpowiadając na pytania ukraińskich dziennikarzy po głosowaniu w Zgromadzeniu Ogólnym ONZ.

## 365 dni wojny.  Ukraińcy w Polsce: To było jak sen, jak koszmar
 - [https://forsal.pl/swiat/ukraina/artykuly/8667159,wojna-w-ukrainie-wspomnienia-ukraincow-w-polsce.html](https://forsal.pl/swiat/ukraina/artykuly/8667159,wojna-w-ukrainie-wspomnienia-ukraincow-w-polsce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 08:32:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/v40ktkuTURBXy85YzI3ODY3ZC00MzVlLTRmODAtOGIyZi03MzE0OGIyYjJkMjQuanBlZ5GTBc0BHcyg" />„To było jak sen, koszmar” - wspomina dzień wybuchu wojny Daria. Od początku inwazji Rosji na niepodległą Ukrainę mija rok. 365 dni strachu, smutku, cierpienia i niezrozumienia. O minionych dwunastu miesiącach, wojnie i nadziei rozmawiamy z Ukrainkami i Ukraińcami.

## USA: Czołgi Abrams mogą w tym roku nie dotrzeć na Ukrainę
 - [https://forsal.pl/artykuly/8667154,usa-czolgi-abrams-moga-w-tym-roku-nie-dotrzec-na-ukraine.html](https://forsal.pl/artykuly/8667154,usa-czolgi-abrams-moga-w-tym-roku-nie-dotrzec-na-ukraine.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 08:17:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5gektkuTURBXy8xN2VlYWU1MS0xYjgxLTRlOTItYjNhNy1kNjg2ZGVjZmZmMDcuanBlZ5GTBc0BHcyg" />Armia amerykańska zastanawia się, w jaki sposób dostarczyć czołgi M1 Abrams na Ukrainę; mogą one nie dotrzeć na Ukrainę nawet przed końcem roku - powiedziała wysoka przedstawicielka amerykańskiej armii Christine Wormuth, cytowana przez portal defencenews.com.

## ONZ: Rezolucja wzywającą do przywrócenia pokoju na Ukrainie została przyjęta
 - [https://forsal.pl/swiat/ukraina/artykuly/8667153,onz-rezolucja-przywrocenie-pokoju-na-ukrainie.html](https://forsal.pl/swiat/ukraina/artykuly/8667153,onz-rezolucja-przywrocenie-pokoju-na-ukrainie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 08:15:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CI9ktkuTURBXy9iNGFjOGZmNy0yMzFkLTQ2MjMtOWY4OC01OGI0MjZmZGMyNGMuanBlZ5GTBc0BHcyg" />W czwartek, w przeddzień pierwszej rocznicy napaści Rosji na Ukrainę, Zgromadzenie Ogólne Narodów Zjednoczonych przyjęło rezolucję: „Zasady Karty Narodów Zjednoczonych leżące u podstaw wszechstronnego, sprawiedliwego i trwałego pokoju na Ukrainie”.

## Wzrosty na Wall Street. S&amp;P 500 przerwał serię czterech dni spadków
 - [https://forsal.pl/finanse/gielda/artykuly/8667151,usa-wzrosty-na-wall-street-sp-500-na-plusie.html](https://forsal.pl/finanse/gielda/artykuly/8667151,usa-wzrosty-na-wall-street-sp-500-na-plusie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 08:09:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fx8ktkuTURBXy8yNDcwMTMzOS03MTZmLTQ2MzQtODAyNS1kYTY3ZGFlN2YwNzQuanBlZ5GTBc0BHcyg" />Czwartkowa sesja na Wall Street zakończyła się umiarkowanymi wzrostami głównych indeksów, a S&amp;amp;P 500 przerwał serię czterech spadkowych sesji z rzędu. W centrum uwagi inwestorów pozostają przyszłe decyzje Fed w sprawie podwyżek stóp proc.

## Korea Północna przećwiczyła przygotowania ataku pociskami  manewrującymi
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667145,korea-polnocna-cwiczenia-przygotowania-atak-pociskami-manewrujacymi.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667145,korea-polnocna-cwiczenia-przygotowania-atak-pociskami-manewrujacymi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 08:05:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ngcktkuTURBXy8zMDA3YTBmNC0yYjA2LTRmNGItYWExMC01ZWU4YTI4NWQ3ODkuanBlZ5GTBc0BHcyg" />Korea Północna przeprowadziła w czwartek ćwiczenia wystrzeliwania pocisków manewrujących, poinformowała północnokoreańska oficjalna agencja KCNA.

## "Der Spiegel": Chiny chcą dostarczać Rosji drony kamikadze, używając fałszywych dokumentów przewozowych
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667142,der-spiegel-chiny-chca-dostarczac-rosji-drony-kamikadze-uzywajac-falszywych-dokumentow-przewozowych.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8667142,der-spiegel-chiny-chca-dostarczac-rosji-drony-kamikadze-uzywajac-falszywych-dokumentow-przewozowych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 08:00:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-lbktkuTURBXy81NmRiYWEzOS0xYzJiLTQ1MGUtYmM5NS0xNTJkYmQ0ZWExYTIuanBlZ5GTBc0BHcyg" />Rosyjska armia prowadzi z Chinami rozmowy o produkcji dronów kamikadze. Do Moskwy mają one trafić dzięki sfałszowanym dokumentom przewozowym - poinformował w piątek portal tygodnika &quot;Der Spiegel&quot;.

## USA zwiększają  pomoc wojskową dla Ukrainy o 2 miliardy dolarów
 - [https://forsal.pl/swiat/usa/artykuly/8667140,usa-zwiekszaja-pomoc-wojskowa-dla-ukrainy-o-2-miliardy-dolarow.html](https://forsal.pl/swiat/usa/artykuly/8667140,usa-zwiekszaja-pomoc-wojskowa-dla-ukrainy-o-2-miliardy-dolarow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:58:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Q9AktkuTURBXy9jNzQ2MDk1ZC03NDBhLTRjMzctYWJiYS0yNmI4ZjJjOWJlZDQuanBlZ5GTBc0BHcyg" />Stany Zjednoczone przekażą Ukrainie dodatkowe 2 miliardy dolarów na pomoc w zakresie bezpieczeństwa, powiedział w czwartek doradca Białego Domu ds. bezpieczeństwa narodowego Jake Sullivan.

## Mamy przełom w leczeniu AIDS? Kluczem przeszczep szpiku
 - [https://forsal.pl/lifestyle/nauka/artykuly/8667139,leczenie-aids-przeszczep-szpiku.html](https://forsal.pl/lifestyle/nauka/artykuly/8667139,leczenie-aids-przeszczep-szpiku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:56:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6qHktkuTURBXy9mYmVjN2YzZC1hMTRlLTRiMWQtYmYyZS01MzU4YTM3ZjU5YmYuanBlZ5GTBc0BHcyg" />Przeszczep szpiku kostnego pozwolił całkowicie uwolnić od wirusa HIV kolejnego zakażonego tym patogenem pacjenta – informuje „Nature”. To co najmniej trzecia taka osoba na świecie.

## Naukowy dogmat złamany. Telomery kodują jednak ważne białka
 - [https://forsal.pl/lifestyle/nauka/artykuly/8667136,telomery-kodowanie-waznych-bialek.html](https://forsal.pl/lifestyle/nauka/artykuly/8667136,telomery-kodowanie-waznych-bialek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:52:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AW1ktkuTURBXy9jNDNlY2UwNi0yYzg4LTQwNzgtYjMwNy02NWJiMWFlNmU2OTkuanBlZ5GTBc0BHcyg" />Końcówki chromosomów - telomery, wbrew wcześniejszym przekonaniom, mogą nieść genetyczną informację przynajmniej dla dwóch niedużych białek - donoszą biolodzy. Odkrycie może mieć znaczenie dla rozumienia procesu starzenia, zapaleń i raka.

## Błaszczak: Mamy nadzieję, że zamówione wyrzutnie HIMARS pojawią się jeszcze w tym roku
 - [https://forsal.pl/swiat/usa/artykuly/8667132,blaszczak-usa-szybko-przesle-wyrzutnie-himars.html](https://forsal.pl/swiat/usa/artykuly/8667132,blaszczak-usa-szybko-przesle-wyrzutnie-himars.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:45:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5OMktkuTURBXy9kNGQ0ODczYi1jMWVmLTQ5ZDktOTU5My1hYzJjMWU5NTgxN2MuanBlZ5GTBc0BHcyg" />Zamówione w 2019 r. wyrzutnie HIMARS będą w Polsce w tym roku; mamy nadzieję, że w maksymalnie krótkim czasie pojawią się w Polsce też te wyrzutnie na sprzedaż, których zgodził się teraz Kongres USA - mówił wicepremier, szef MON Mariusz Błaszczak. Są też rozmowy o budowie w Polsce fabryki pocisków do tych wyrzutni - dodał.

## Skrzypczak: Zachód zaprzepaścił okazję, by w ubiegłym roku "dobić" armię rosyjską
 - [https://forsal.pl/swiat/ukraina/artykuly/8667128,skrzypczak-zachod-zaprzepascil-okazje-by-w-ubieglym-roku-dobic-armie-rosyjska.html](https://forsal.pl/swiat/ukraina/artykuly/8667128,skrzypczak-zachod-zaprzepascil-okazje-by-w-ubieglym-roku-dobic-armie-rosyjska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:38:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xPVktkuTURBXy8xODczNWJkYi01ZTZiLTQwN2UtYjg4ZS0xNGVjYjVjNjcwMWMuanBlZ5GTBc0BHcyg" />Z powodu strategii Zachodu, by przekazywać Ukrainie tylko broń defensywną, stracono okazję, by w ubiegłym roku &quot;dobić&quot; armię rosyjską; jeśli Europa pochłonięta sporami politycznymi i rywalizacją, dalej będzie miała takie podejście, Ukraina straci wschodnią część swego terytorium - uważa gen. broni rez. Waldemar Skrzypczak.

## Rosyjska agresja doprowadziła do dewastacji połowy ukraińskiego przemysłu
 - [https://forsal.pl/gospodarka/artykuly/8667125,rosyjska-agresja-doprowadzila-do-dewastacji-polowy-ukrainskiego-przemyslu.html](https://forsal.pl/gospodarka/artykuly/8667125,rosyjska-agresja-doprowadzila-do-dewastacji-polowy-ukrainskiego-przemyslu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:35:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/m0PktkuTURBXy82NzM5M2YwNC00YzNiLTQ5NjEtYjZkMy0xZjA0NjdlZjdjZTEuanBlZ5GTBc0BHcyg" />Rosyjska agresja doprowadziła do dewastacji połowy ukraińskiego przemysłu, który poniósł bezpośrednie straty szacowane na 13 mld dol. - stwierdzili eksperci Polskiego Instytutu Ekonomicznego. Ich zdaniem odbudowa może być jednak szansą na radykalną modernizację w kierunku neutralności klimatycznej.

## Gen. Polko: W Ukrainie trwa wojna pozycyjna. To przełomowy moment
 - [https://forsal.pl/swiat/ukraina/artykuly/8667121,gen-polko-w-ukrainie-trwa-wojna-pozycyjna-to-przelomowy-moment.html](https://forsal.pl/swiat/ukraina/artykuly/8667121,gen-polko-w-ukrainie-trwa-wojna-pozycyjna-to-przelomowy-moment.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:32:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1nkktkuTURBXy84MmU3ZDVhZi0wMDkyLTQ2YTItYmU0Ni1kZjU3N2RhNjZlYTguanBlZ5GTBc0BHcyg" />Obecnie w Ukrainie trwa wojna pozycyjna, jest to poniekąd moment przełomowy, bo Rosja choć zapowiada wielką ofensywę, nie ma ani sił, ani środków, ani przeszkolonych ludzi, by ją przeprowadzić - powiedział PAP były dowódca GROM generał Roman Polko.

## Tusk: Cela+ to program dla tych, którzy zbudowali system dojenia państwa
 - [https://forsal.pl/gospodarka/polityka/artykuly/8667119,tusk-cela-dla-tych-co-doili-panstwo.html](https://forsal.pl/gospodarka/polityka/artykuly/8667119,tusk-cela-dla-tych-co-doili-panstwo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:31:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7cuktkuTURBXy85ODViYzBkNC1mZjMyLTQ2OGItOGRhMy03NTdlNjJkZmFjNjAuanBlZ5GTBc0BHcyg" />Cela+ będzie programem przygotowanym dla tych wszystkich, którzy w sposób tak bezprzykładny, tak świetnie zorganizowany zbudowali system dojenia państwa i publicznych pieniędzy - powiedział w czwartek w TVN24 szef PO Donald Tusk.

## Orlen zaprezentował wyniki finansowe. Jak na spółkę wpłynęła wielka fuzja?
 - [https://forsal.pl/biznes/energetyka/artykuly/8667116,zysk-netto-grupy-orlen-iv-kwartal-2022.html](https://forsal.pl/biznes/energetyka/artykuly/8667116,zysk-netto-grupy-orlen-iv-kwartal-2022.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:29:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4DSktkuTURBXy83OGZhZDFmMS01OThlLTQ0MTMtOTczYi0xZDFlMDlmNmI3NzAuanBlZ5GTBc0BHcyg" />Połączona Grupa Orlen wypracowała w czwartym kwartale 2022 przychody na poziomie ponad 100 mld zł, z których 8 proc. to zysk netto w wysokości 8,1 mld zł - poinformowała w piątek spółka. Po raz pierwszy zaprezentowano wyniki uwzględniające działalność czterech firm: PKN Orlen, Energi, Lotosu oraz PGNiG.

## Rzeczkowska: Nasza gospodarka już nieraz zaskoczyła
 - [https://forsal.pl/swiat/ukraina/artykuly/8666981,rzeczkowska-gospodarka-juz-nieraz-zaskoczyla.html](https://forsal.pl/swiat/ukraina/artykuly/8666981,rzeczkowska-gospodarka-juz-nieraz-zaskoczyla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:27:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gRPktkuTURBXy8zODNjOWQ2YS1lNzIzLTRmNmUtYWViZi01OTM0MWQ2NmMxMzMuanBlZ5GTBc0BHcyg" />Ponad 420 tys. Ukraińców dostało już pozwolenia na pracę według prostszych przepisów. Ponad 14 tys. założyło w Polsce firmy. I to jest ich wkład w naszą gospodarkę

## Niemcy na geopolitycznym rozdrożu. Od ich decyzji zależy nie tylko dalszy los wojny w Ukrainie
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8667108,niemcy-na-geopolitycznym-rozdrozu-wojna-w-ukrainie.html](https://forsal.pl/swiat/unia-europejska/artykuly/8667108,niemcy-na-geopolitycznym-rozdrozu-wojna-w-ukrainie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 07:07:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Mi8ktkuTURBXy8yN2ZhYTc5YS1jMzJjLTQyOTktYWY1Ny0zYTRkY2M0NTEwN2EuanBlZ5GTBc0BHcyg" />Wojna w Ukrainie powinna doprowadzić do przełomu w niemieckiej polityce na miarę upadku muru berlińskiego. Biada Niemcom, biada Europie i biada NATO, jeśli tak się nie stanie, jeśli nie dojdzie w końcu do deputinizacji elit i nie pojawi się nowa jakość

## Doświadczenie wspólnotowe. Jak wojna w Ukrainie połączyła Polaków?
 - [https://forsal.pl/swiat/ukraina/artykuly/8667001,doswiadczenie-wspolnotowe-wojna-w-ukrainie-polaczyla-polakow.html](https://forsal.pl/swiat/ukraina/artykuly/8667001,doswiadczenie-wspolnotowe-wojna-w-ukrainie-polaczyla-polakow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 06:44:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rZektkuTURBXy82OTMyZjRjYy1kNTE1LTQ3YzktYTljZS0yNzA0YTJkNmZmZmYuanBlZ5GTBc0BHcyg" />Nasi rozmówcy bardzo często sami o tym mówią – dla wielu z nich wojna to moment, w którym poczuli się w pełni częścią ukraińskiego narodu politycznego

## Nowy, (wspaniały?) świat. Parowóz dziejów zmienił się w superszybkie TGV
 - [https://forsal.pl/swiat/ukraina/artykuly/8667009,nowy-wspanialy-swiat-pedzi-jak-superszybkie-tgv.html](https://forsal.pl/swiat/ukraina/artykuly/8667009,nowy-wspanialy-swiat-pedzi-jak-superszybkie-tgv.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 06:36:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oxSktkuTURBXy80OWQ3YzY0OS1kMjVkLTQ2OWUtODAxOS0zZmZjNDg2MmMyYTcuanBlZ5GTBc0BHcyg" />Pauza strategiczna, z którą mieliśmy do czynienia po upadku muru berlińskiego, bezpowrotnie odeszła do historii. Wydarzenia z ostatnich 12 miesięcy to tylko preludium do przeróżnych ciągów dalszych

## Hrabski: Wojny wygrywa gospodarka
 - [https://forsal.pl/swiat/ukraina/artykuly/8666985,wojny-wygrywa-gospodarka.html](https://forsal.pl/swiat/ukraina/artykuly/8666985,wojny-wygrywa-gospodarka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 06:30:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6k8ktkuTURBXy8xNDEzZDhjYy0xMDZlLTRlZTQtYTBjOC1hMWZlOWQ1MmQzNWQuanBlZ5GTBc0BHcyg" />Rosja nie szykowała się do takiej wojny, jej możliwości się kurczą. A my cieszymy się wsparciem cywilizowanego świata. Ale będzie jeszcze bardzo ciężko

## Polskie CO2 musi pójść pod ziemię zamiast do atmosfery
 - [https://forsal.pl/biznes/energetyka/artykuly/8666755,polskie-co2-musi-pojsc-pod-ziemie-zamiast-do-atmosfery.html](https://forsal.pl/biznes/energetyka/artykuly/8666755,polskie-co2-musi-pojsc-pod-ziemie-zamiast-do-atmosfery.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 05:00:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zZaktkuTURBXy8zZWQwMTlmOC05NmM2LTQzMDYtYjhiYy00NjUxNTU3ZGQ2YjUuanBlZ5GTBc0BHcyg" />Nie jest częstym widokiem, gdy wiceminister publicznie apeluje do przemysłu o to, aby ten wsparł u premiera jego wysiłki o przyspieszenie prac nad jakąś ustawą. A tak jest w przypadku nowelizacji Prawa geologicznego i górniczego, bez której dla projektów podziemnego składowania dwutlenku węgla nie zapali się zielone światło.

## Bartuś: Wolność non olet. Czy Zachód zrobi to, co głosi? [FELIETON]
 - [https://forsal.pl/swiat/ukraina/artykuly/8666826,ukraina-wolnosc-non-olet-czy-zachod-zrobi-to-co-glosi-zbigniew-bartus.html](https://forsal.pl/swiat/ukraina/artykuly/8666826,ukraina-wolnosc-non-olet-czy-zachod-zrobi-to-co-glosi-zbigniew-bartus.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0anktkuTURBXy9lNDQ4OTE0MC03MDNlLTRmZGQtYmNlZS05Mjc3M2ZhOGRmYTQuanBlZ5GTBc0BHcyg" />Dawno nic tak nie obnażyło totalnej hipokryzji politycznych i gospodarczych elit Zachodu, jak ta wojna - pisze w felietonie Zbigniew Bartuś.

## Jak wojna w Ukrainie wpłynęła na rynek nieruchomości?
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/8666768,wojna-w-ukrainie-a-rynek-nieruchomosci-ceny-mieszkan.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/8666768,wojna-w-ukrainie-a-rynek-nieruchomosci-ceny-mieszkan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0IZktkuTURBXy82OTczYWEwZS05M2VjLTQ3MDctOTIxMy1iNWE4ODdhZTNlNGYuanBlZ5GTBc0BHcyg" />24 lutego minie rok od napaści Rosji na Ukrainę. Eksperci portali RynekPierwotny.pl i GetHome.pl zbadali, jak wojna w Ukrainie wpłynęła na nasz rynek mieszkaniowy, zarówno na sprzedaż, jak i wynajem.

## Jedlak: Dlaczego lepiej niż inni rozumiemy Ukraińców [OPINIA]
 - [https://forsal.pl/swiat/ukraina/artykuly/8666808,jedlak-dlaczego-lepiej-niz-inni-rozumiemy-ukraincow-opinia.html](https://forsal.pl/swiat/ukraina/artykuly/8666808,jedlak-dlaczego-lepiej-niz-inni-rozumiemy-ukraincow-opinia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AiJktkuTURBXy85ZjBiODY5MS05MjQyLTRjMTktOGZlMS04MTY1NTZhM2NjOTEuanBlZ5GTBc0BHcyg" />Polacy rozumieją Ukraińców. Nie tylko dlatego, że przez stulecia żyliśmy w jednym państwie, karmiąc się po części tą samą, bogatą kulturą. Ani dlatego, że i później nasze losy stale się zazębiały. Polska jest największą ofiarą dwóch najpotworniejszych totalitaryzmów w historii, na dodatek działających – przynajmniej w polskiej sprawie – ręka w rękę - pisze Krzysztof Jedlak, redaktor naczelny Dziennika Gazety Prawnej.

## Kto dzisiaj da pieniądze na naturalny wodór, być może jutro zostanie ogłoszony wybawcą (i sporo zarobi) [OPINIA]
 - [https://forsal.pl/biznes/ekologia/artykuly/8666291,naturalny-wodor-odwierty-inwestorzy.html](https://forsal.pl/biznes/ekologia/artykuly/8666291,naturalny-wodor-odwierty-inwestorzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Wg5ktkuTURBXy9jMDk0Nzg2My0wNjljLTQxNWYtYWE3OC1kZDhmZGE2ZGYyYWEuanBlZ5GTBc0BHcyg" />Podczas gdy Unia Europejska, Chiny i USA prześcigają się w tym, kto dostarczy światu najlepsze elektrolizery do produkcji wodoru, złoża tego pierwiastka – czystego i odnawialnego – leżą sobie, podobnie jak ropa naftowa czy węgiel, pod ziemią. Leżą i czekają na inwestorów, którzy sfinansują opracowanie i wdrożenie technologii pozwalających na ich wydobycie.

## Tak starzeje się Europa. Mediana wieku ludności w krajach UE [MAPA]
 - [https://forsal.pl/gospodarka/demografia/artykuly/8666101,demografia-mediana-wieku-panstwa-ue-polska-eurostat.html](https://forsal.pl/gospodarka/demografia/artykuly/8666101,demografia-mediana-wieku-panstwa-ue-polska-eurostat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aWqktkuTURBXy8zM2I1M2ZiZC00MmNjLTRhYTUtYjY1NS04Mjg4MDRlYWI2OTkuanBlZ5GTBc0BHcyg" />Starzenie się europejskiego społeczeństwa widoczne jest od lat. Od 2012 roku mediana wieku Europejczyków wzrosła o 2,5 roku.

## Wszyscy Rosjanie powinni ponosić konsekwencje tej wojny [WYWIAD]
 - [https://forsal.pl/swiat/ukraina/artykuly/8666786,olha-menko-wszyscy-rosjanie-powinni-ponosic-konsekwencje-tej-wojny.html](https://forsal.pl/swiat/ukraina/artykuly/8666786,olha-menko-wszyscy-rosjanie-powinni-ponosic-konsekwencje-tej-wojny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LwCktkuTURBXy8xODY5NmUzYS05NTg3LTQ3ZTEtOTUwYS1iZTkxOWZkOTVlZWIuanBlZ5GTBc0BHcyg" />- Dlaczego rosyjska młodzież może – jak gdyby nigdy nic – korzystać z międzynarodowych programów wymiany, jak Erasmus? Mówi się: ci młodzi ludzie nie są winni i przekonuje nas, że jeśli oni będą przyjeżdżać na Zachód na wymianę, to my ich szybciej nauczymy demokracji. To wielkie nieporozumienie! Ich rodacy dokonują w Ukrainie niewyobrażalnych zbrodni, a oni jeżdżą sobie, jak gdyby nigdy nic. Trzeba z tym skończyć – apeluje Olha Menko, prezeska Fundacji Instytut Polska-Ukraina.

## Wyzwania związane z usługami DeFi w kontekście regulacji europejskich
 - [https://forsal.pl/finanse/artykuly/8665259,wyzwania-zwiazane-z-uslugami-defi-w-kontekscie-regulacji-europejskich.html](https://forsal.pl/finanse/artykuly/8665259,wyzwania-zwiazane-z-uslugami-defi-w-kontekscie-regulacji-europejskich.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MnfktkuTURBXy9lMTc2NThkNi0yZDYxLTQyY2QtOGNiMi0zZDZlOTRiMjg4OTIuanBlZ5GTBc0BHcyg" />Rynek kryptoaktywów ma przede wszystkim charakter spekulacyjny, a jego rola dla gospodarki realnej jest minimalna. Niezależnie od takiego stanu rzeczy, na tym rynku można zaobserwować rozwój interesujących rozwiązań technologicznych służących do świadczenia usług o charakterze zbliżonym do usług finansowych.

## Zełeński i jego goście. Kto w ciągu ostatniego roku najczęściej odwiedzał Ukrainę?
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8666850,ukraina-wizyty-zagranicznych-przywodcow-zelenski.html](https://forsal.pl/swiat/unia-europejska/artykuly/8666850,ukraina-wizyty-zagranicznych-przywodcow-zelenski.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-24 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gNjktkuTURBXy82MDRhODZmNy0wNzU1LTQ5NGItOTQ1NC1lMzY5N2Q0MTYyMzIuanBlZ5GTBc0BHcyg" />Tuż przed pierwszą rocznicą agresji Rosji na Ukrainę do Kijowa zaczęli zjeżdżać światowi przywódcy. W poniedziałek niespodziewaną wizytę złożył prezydent USA Joe Biden. Premier Włoch Giorgia Meloni przyleciała we wtorek. A premier Hiszpanii Pedro Sanchez zaplanował spotkanie z prezydentem Wołodymyrem Zełenskim na czwartek 23 lutego. Miał to być sygnał dla Moskwy, że Zachód nadal wspiera Ukrainę.

