# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Ernie, what is censorship? China’s chatbots face additional challenges.
 - [https://www.washingtonpost.com/world/2023/02/24/china-baidu-ernie-chatbot-chatgpt/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/world/2023/02/24/china-baidu-ernie-chatbot-chatgpt/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-24 23:26:39+00:00

Chinese tech companies have been working on chatbots like ChatGPT for years, but they've been slow to release them. Strict political controls are partly why.

## The money saving deals Apple and Google are hiding from you
 - [https://www.washingtonpost.com/technology/2023/02/24/apps-subscription-costs/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/02/24/apps-subscription-costs/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-24 12:30:00+00:00

You can’t buy a Netflix subscription in the app. Audible is cheaper if you don’t pay in the app. Why should this be kept secret from you?

## The right’s new culture-war target: ‘Woke AI’
 - [https://www.washingtonpost.com/technology/2023/02/24/woke-ai-chatgpt-culture-war/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/02/24/woke-ai-chatgpt-culture-war/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-02-24 06:00:26+00:00

ChatGPT, Google’s Bard, Microsoft’s Bing and DALL-E are causing the far right to decry “woke AI.”

