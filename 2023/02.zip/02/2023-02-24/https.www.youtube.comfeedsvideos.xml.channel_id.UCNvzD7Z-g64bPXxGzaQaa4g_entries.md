# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## GAMESTOP HAS A BIG PROBLEM, WHAT'S UP WITH ROCKSTEADY'S NEW GAME? & MORE
 - [https://www.youtube.com/watch?v=QJVKWon9m0Q](https://www.youtube.com/watch?v=QJVKWon9m0Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-02-24 22:16:39+00:00

Thank you Vessi for sponsoring this video. Click https://vessi.com/gameranx and use our code gameranx for 15% off your entire order! Free shipping to CA, US, AU,JP, TW, KR, SGP



~~~~~SOURCES~~~~~




Gamestop problems?
https://www.dailydot.com/irl/gamestop-corporate-layoffs/
https://gamerant.com/gamestop-manager-claims-layoffs/


Elden Ring 20 million
https://www.gematsu.com/2023/02/elden-ring-shipments-and-digital-sales-top-20-million


Suicide Squad 
Gameplay
https://youtu.be/CaOYwBawqS8



Xbox
https://kotaku.com/microsoft-nintendo-activision-call-of-duty-xbox-switch-1850140199

State of Play: https://www.youtube.com/live/GGkP6D5lJcw?feature=share


Syndicate update lol
https://www.eurogamer.net/ubisoft-patches-2015-game-assassins-creed-syndicate?fbclid=IwAR2K8eV4j-wkUU5Ft7CatriKxC98qGRL1pl2eBs6-pQ2ooedNleTHT8dU4w


Lies of P coming August 2023
https://youtu.be/gtxW7OZg3_U






Half Life ray traced (via Sultim t)
https://youtu.be/LQCZTxzW6A0

Cool watch
https://youtu.be/xOijnEZjb0s

MGS rumors 
https://lnk.to/VGC
https://comicbook.com/gaming/news/metal-gear-solid-3-mgs3-remake-reveal-report/


Shinji Mikami leaves Tango
https://www.theverge.com/2023/2/23/23611792/tango-gameworks-ceo-leaves-bethesda-xbox

## Sons of the Forest - Before You Buy
 - [https://www.youtube.com/watch?v=LqmmjHEyiHM](https://www.youtube.com/watch?v=LqmmjHEyiHM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-02-24 19:58:54+00:00

Sons of the Forest (PC) is an early access game with solid survival gameplay and good scares. Let's talk about it. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#sonsoftheforest

