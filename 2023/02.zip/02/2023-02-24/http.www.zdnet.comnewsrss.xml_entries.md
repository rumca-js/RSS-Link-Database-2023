# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## What is Microsoft's new Bing with ChatGPT? Here's everything we know
 - [https://www.zdnet.com/article/what-is-microsofts-new-bing-with-chatgpt-heres-everything-we-know/#ftag=RSSbaffb68](https://www.zdnet.com/article/what-is-microsofts-new-bing-with-chatgpt-heres-everything-we-know/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 21:14:00+00:00

Microsoft's AI chatbot has been making headlines because of its advanced capabilities and its memorable outbursts. Here's everything you need to know.

## Meta's little LLaMA model comes with big benefits for AI researchers
 - [https://www.zdnet.com/article/metas-little-llama-model-comes-with-big-benefits-for-ai-researchers/#ftag=RSSbaffb68](https://www.zdnet.com/article/metas-little-llama-model-comes-with-big-benefits-for-ai-researchers/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 21:05:00+00:00

Facebook's parent company has released LLaMA, a relatively small but powerful model that should help researchers address the potentially harmful and sometimes wacky pitfalls of AI.

## How to unsend an email in Gmail
 - [https://www.zdnet.com/article/how-to-unsend-an-email-in-gmail/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-unsend-an-email-in-gmail/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 19:52:00+00:00

With this Gmail feature, you have up to 30 seconds to catch and unsend a grammar mistake, a misspelled name, or even the wrong recipient before it's cast into someone's inbox abyss.

## Galaxy S23 Plus review: The Goldilocks of Samsung's 2023 smartphone lineup
 - [https://www.zdnet.com/article/samsung-galaxy-s23-plus-review-the-goldilocks-of-samsungs-2023-smartphone-lineup/#ftag=RSSbaffb68](https://www.zdnet.com/article/samsung-galaxy-s23-plus-review-the-goldilocks-of-samsungs-2023-smartphone-lineup/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 18:46:00+00:00

The Samsung Galaxy S23 Plus hits the sweet spot of performance and photography at a price that's just right.

## I asked ChatGPT to write a short Star Trek episode. It actually succeeded
 - [https://www.zdnet.com/article/i-asked-chatgpt-to-write-a-short-star-trek-episode-it-actually-succeeded/#ftag=RSSbaffb68](https://www.zdnet.com/article/i-asked-chatgpt-to-write-a-short-star-trek-episode-it-actually-succeeded/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 18:27:00+00:00

Score another point for things ChatGPT does surprisingly well. But for how long? Not everyone is going to be happy about what ChatGPT can produce, especially the lawyers.

## Proton VPN review: A very solid VPN with robust leak protection
 - [https://www.zdnet.com/article/proton-vpn-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/proton-vpn-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 17:21:32+00:00

We tested connections to every continent except Antarctica. The big takeaway was how robust Proton VPN is at providing leak protection. But there's more. Read on.

## Google Pixel's Magic Eraser is finally coming to iPhones (and other Android phones)
 - [https://www.zdnet.com/article/google-pixels-magic-eraser-is-finally-coming-to-iphones-and-other-android-phones/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-pixels-magic-eraser-is-finally-coming-to-iphones-and-other-android-phones/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 15:29:00+00:00

Magic Eraser is arguably Google's most highly-touted camera feature of recent years. Now, other phone users can get in on the action, as long as they meet one requirement.

## Microsoft: Here's how our technology disrupts ransomware and phishing attacks
 - [https://www.zdnet.com/article/microsoft-heres-how-our-technology-disrupts-ransomware-and-phishing-attacks/#ftag=RSSbaffb68](https://www.zdnet.com/article/microsoft-heres-how-our-technology-disrupts-ransomware-and-phishing-attacks/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 14:57:17+00:00

Microsoft 365 Defender has AI-based capabilities, which the company says can detect and disable compromised accounts and services attackers are trying to use.

## These are the most secure countries for remote workers in 2023
 - [https://www.zdnet.com/home-and-office/these-are-the-most-secure-countries-for-remote-workers-in-2023/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/these-are-the-most-secure-countries-for-remote-workers-in-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 14:54:48+00:00

Here are the countries considered the 'safest' for remote workers, as well as the best countries for connectivity and VPN access.

## Raspberry Pi Pico just got this handy new Windows Installer
 - [https://www.zdnet.com/article/raspberry-pi-pico-just-got-this-handy-new-windows-installer/#ftag=RSSbaffb68](https://www.zdnet.com/article/raspberry-pi-pico-just-got-this-handy-new-windows-installer/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 12:36:58+00:00

Developers using Windows PCs to build for the Raspberry Pi Pico now have a single installer that provides all the tools required.

## Samsung is looking at satellite connectivity for 5G smartphones
 - [https://www.zdnet.com/article/samsung-is-looking-at-satellite-connectivity-for-5g-smartphones/#ftag=RSSbaffb68](https://www.zdnet.com/article/samsung-is-looking-at-satellite-connectivity-for-5g-smartphones/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 11:42:17+00:00

Samsung will be integrating the 'non-terrestrial networks' tech into its Exynos modems.

## Microsoft: This is how we integrated ChatGPT-style tech into Bing search
 - [https://www.zdnet.com/article/microsoft-this-is-how-we-integrated-chatgpt-style-tech-into-bing-search/#ftag=RSSbaffb68](https://www.zdnet.com/article/microsoft-this-is-how-we-integrated-chatgpt-style-tech-into-bing-search/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 11:09:36+00:00

Microsoft explains how it 'grounded' the GPT language model behind Bing Chat with Bing search results.

## AI art generator: Qualcomm gets Stable Diffusion running on a smartphone
 - [https://www.zdnet.com/article/ai-art-generator-qualcomm-gets-stable-diffusion-running-on-a-smartphone/#ftag=RSSbaffb68](https://www.zdnet.com/article/ai-art-generator-qualcomm-gets-stable-diffusion-running-on-a-smartphone/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 10:17:52+00:00

As smartphones become increasingly capable, more workloads are moving on-device and off the cloud. Qualcomm's MWC demo showcases the work of its AI research team.

## Motorola's handy Bluetooth device adds satellite messaging to your iPhone or Android smartphone
 - [https://www.zdnet.com/article/motorolas-handy-bluetooth-device-adds-satellite-messaging-to-your-iphone-or-android-smartphone/#ftag=RSSbaffb68](https://www.zdnet.com/article/motorolas-handy-bluetooth-device-adds-satellite-messaging-to-your-iphone-or-android-smartphone/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 09:58:19+00:00

Need to communicate, but out of Wi-Fi and cellular range? Fear not -- this affordable device could come to your rescue.

## Rugged Cat S75 and Motorola Defy 2: Android smartphones with two-way satellite connectivity
 - [https://www.zdnet.com/article/rugged-cat-s75-and-motorola-defy-2-android-smartphones-with-two-way-satellite-connectivity/#ftag=RSSbaffb68](https://www.zdnet.com/article/rugged-cat-s75-and-motorola-defy-2-android-smartphones-with-two-way-satellite-connectivity/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 09:43:33+00:00

Satellite tech is going mainstream, and Bullitt Group has a head start over its Big Tech rivals, for now.

## Save $200 on a Shark AI robot vacuum at Amazon
 - [https://www.zdnet.com/home-and-office/save-on-a-shark-ai-robot-vacuum-at-amazon-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/save-on-a-shark-ai-robot-vacuum-at-amazon-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 08:05:02+00:00

Turn your household chore hands-free with the range of robot vacuums on sale at Amazon.

## Save $200 on a Shark AI robot vacuum at Amazon
 - [https://www.zdnet.com/home-and-office/kitchen-household/save-on-a-shark-ai-robot-vacuum-at-amazon-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/kitchen-household/save-on-a-shark-ai-robot-vacuum-at-amazon-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 08:05:00+00:00

Turn your household chore hands-free with the range of robot vacuums on sale at Amazon.

## Australia retailer's customer data compromised in third-party breach
 - [https://www.zdnet.com/article/australia-retailers-customer-data-compromised-in-third-party-breach/#ftag=RSSbaffb68](https://www.zdnet.com/article/australia-retailers-customer-data-compromised-in-third-party-breach/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 07:19:00+00:00

The Good Guys' customer data, including phone numbers and email addresses, have been compromised in a third-party breach that industry observers say is yet another reminder for businesses to scrutinise their suppliers' security practices.

## The 5 best Apple Watch Series 8 bands of 2023
 - [https://www.zdnet.com/article/best-apple-watch-series-8-band/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-apple-watch-series-8-band/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 05:07:00+00:00

These top Apple Watch bands for Series 8 deliver superior comfort, vibrant styles, and a secure fit.

## Snag the PlayStation 5 while it's still in stock
 - [https://www.zdnet.com/home-and-office/as-shortages-resolve-now-is-the-time-to-grab-a-playstation-5/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/as-shortages-resolve-now-is-the-time-to-grab-a-playstation-5/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 04:27:00+00:00

As stock shortages have subsided, it's now easier to pre-order or purchase the next-generation PlayStation 5. Here's why you should take the plunge, and tips and tricks to get the most out of your new gaming console.

## The 5 best massage chairs of 2023
 - [https://www.zdnet.com/home-and-office/best-massage-chair/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-massage-chair/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 04:04:00+00:00

Work out those kinks and massage away your stress. We compare value, performance, and affordability to find the best massage chairs for your home -- and the Osaki 4D Pro Maestro LE wins our pick for the best massage chair.

## The Govee smart electric kettle is $20 off right now
 - [https://www.zdnet.com/home-and-office/kitchen-household/this-smart-electric-kettle-deal-is-so-good-i-just-bought-it/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/kitchen-household/this-smart-electric-kettle-deal-is-so-good-i-just-bought-it/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-24 03:45:00+00:00

Jump-start your day with a hot cup of water for your tea or pour-over coffee with this great $20 discount.

