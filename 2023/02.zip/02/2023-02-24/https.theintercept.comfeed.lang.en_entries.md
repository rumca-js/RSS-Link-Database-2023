# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Bristling Under Progressive Mayor, St. Louis Police Seek State Takeover
 - [https://theintercept.com/2023/02/24/st-louis-missouri-police-department/](https://theintercept.com/2023/02/24/st-louis-missouri-police-department/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-02-24 17:21:14+00:00

<p>Police unions have rallied around Missouri Senate Bill 78, which would reinstate a Civil War-era system of state oversight.</p>
<p>The post <a href="https://theintercept.com/2023/02/24/st-louis-missouri-police-department/" rel="nofollow">Bristling Under Progressive Mayor, St. Louis Police Seek State Takeover</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

