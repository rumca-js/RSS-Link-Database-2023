# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## BC Teacher Fired After Comment on Residential School Deaths
 - [https://www.theepochtimes.com/bc-teacher-fired-after-comment-on-residential-school-deaths_5081651.html](https://www.theepochtimes.com/bc-teacher-fired-after-comment-on-residential-school-deaths_5081651.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 23:39:28+00:00

Jim McMurtry, formerly a teacher for the Abbotsford School District in Abbotsford, B.C. (Courtesy of Jim McMurtry)

## New York Man Arrested for Assaulting Falun Gong Adherent
 - [https://www.theepochtimes.com/new-york-man-arrested-for-assaulting-falun-gong-adherent_5081929.html](https://www.theepochtimes.com/new-york-man-arrested-for-assaulting-falun-gong-adherent_5081929.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 23:33:40+00:00

Police arrest Qi Zhongping, who faces charges for assaulting Falun Gong practitioners in Flushing, New York, on Feb. 18, 2023. (Screenshot via The Epoch Times)

## Madeleine McCann’s Parents Agree to DNA Test Polish Woman Who Claims to Be Their Missing Daughter
 - [https://www.theepochtimes.com/madeleine-mccanns-parents-agree-to-dna-test-polish-woman-who-claims-to-be-their-missing-daughter_5075664.html](https://www.theepochtimes.com/madeleine-mccanns-parents-agree-to-dna-test-polish-woman-who-claims-to-be-their-missing-daughter_5075664.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 23:16:30+00:00

Parents of missing girl Madeleine McCann, Kate (L) and Gerry McCann (R) pose with an artist's impression of how their daughter might look now at the age of nine ahead of a press conference in central London on May 2, 2012, five years after Madeleine's disappearance while on a family holiday in Portugal. (Leon Neal/AFP/GettyImages)

## Watchdog Says Youth Laws Will ‘Erode Basic Rights’ in Australian State
 - [https://www.theepochtimes.com/watchdog-says-youth-laws-will-erode-basic-rights-in-australian-state_5081972.html](https://www.theepochtimes.com/watchdog-says-youth-laws-will-erode-basic-rights-in-australian-state_5081972.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 23:00:53+00:00

Brisbane Youth Detention Centre at Wacol, Queensland in Australia on Aug. 24, 2020. (Glenn Hunt/Getty Images)

## China Empowers Russia in Ukraine, Risks Nuclear War With US, Says Former General
 - [https://www.theepochtimes.com/china-empowers-russia-in-ukraine-risks-nuclear-war-with-us-says-former-general_5081976.html](https://www.theepochtimes.com/china-empowers-russia-in-ukraine-risks-nuclear-war-with-us-says-former-general_5081976.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 22:55:02+00:00

A Russian soldier patrols a street in Mariupol, Ukraine, on April 12, 2022. (Alexander Nemenov/AFP via Getty Images)

## ‘Shocking and Scary’: Woman Who Fell Victim to Robodebt Scheme Revisits Experience
 - [https://www.theepochtimes.com/shocking-and-scary-woman-who-fell-victim-to-robodebt-scheme-revisits-experience_5080324.html](https://www.theepochtimes.com/shocking-and-scary-woman-who-fell-victim-to-robodebt-scheme-revisits-experience_5080324.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 22:15:30+00:00

Australian banknotes in Melbourne, on Nov. 7, 2017. (Paul Crocker/AFP via Getty Images)

## Trudeau Addresses Comment of ‘Inaccuracies’ in CSIS Leaks on Beijing Interference
 - [https://www.theepochtimes.com/trudeau-addresses-comment-of-inaccuracies-in-csis-leaks-on-beijing-interference_5081885.html](https://www.theepochtimes.com/trudeau-addresses-comment-of-inaccuracies-in-csis-leaks-on-beijing-interference_5081885.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 22:12:09+00:00

Prime Minister Justin Trudeau listens to a question during a news conference, in Ottawa, Feb.17, 2023. (The Canadian Press/Adrian Wyld)

## Zelenskyy: China’s ‘Peace Plan’ Implies Russian Troops Must Leave Ukraine
 - [https://www.theepochtimes.com/zelenskyy-chinas-peace-plan-implies-russian-troops-must-leave-ukraine_5081801.html](https://www.theepochtimes.com/zelenskyy-chinas-peace-plan-implies-russian-troops-must-leave-ukraine_5081801.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 22:08:48+00:00

Ukainian President Volodymyr Zelenskyy stands in the town of Bucha, northwest of the Ukrainian capital Kyiv, on April 4, 2022. (Ronaldo Schemidt//AFP via Getty Images)

## World’s Speedboat Record Holder Mourned
 - [https://www.theepochtimes.com/worlds-speedboat-record-holder-mourned_5081810.html](https://www.theepochtimes.com/worlds-speedboat-record-holder-mourned_5081810.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 22:00:53+00:00

Water speed record holder Ken Warby displays his new boat 'Aussie Spirit' in which he hopes to break his own record on Lake Blowering in NSW. Ken set the record in 1978 on Lake Blowering with a speed of 317.60 mph / 511.11km/h.  Mar. 9, 2004. (AAP Image/Alan Porritt)

## Federal Labor’s Affordable Housing Plan Under Threat by Coalition and Greens
 - [https://www.theepochtimes.com/federal-labors-affordable-housing-plan-under-threat-by-coalition-and-greens_5080276.html](https://www.theepochtimes.com/federal-labors-affordable-housing-plan-under-threat-by-coalition-and-greens_5080276.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 21:55:34+00:00

An auctioneer counts down a bid during an auction of a residential property in Sydney, Australia, on May 8, 2021. (Lisa Maree Williams/Getty Images)

## NTD Business (Feb. 24): White House Announces New Sanctions Against Russia; Feds Say Inflation Surprisingly Rose in January
 - [https://www.theepochtimes.com/ntd-business-feb-24-wh-announces-new-sanctions-against-russia-feds-say-inflation-surprisingly-rose-in-jan_5079789.html](https://www.theepochtimes.com/ntd-business-feb-24-wh-announces-new-sanctions-against-russia-feds-say-inflation-surprisingly-rose-in-jan_5079789.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 21:50:45+00:00



## On Anniversary of Russian Invasion, Trudeau Says 4 More Tanks Will Be Sent to Ukraine
 - [https://www.theepochtimes.com/on-anniversary-of-russian-invasion-trudeau-says-4-more-tanks-will-be-sent-to-ukraine_5081606.html](https://www.theepochtimes.com/on-anniversary-of-russian-invasion-trudeau-says-4-more-tanks-will-be-sent-to-ukraine_5081606.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 21:22:33+00:00

A Polish soldier walks next to Leopard 2 tanks during a training at a military base and test range in Swietoszow, Poland, on Feb. 13, 2023. (Michal Dyjuk/AP Photo)

## IMF Opposes Making Cryptocurrency Legal Tender
 - [https://www.theepochtimes.com/imf-opposes-making-cryptocurrency-legal-tender_5081334.html](https://www.theepochtimes.com/imf-opposes-making-cryptocurrency-legal-tender_5081334.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 21:16:40+00:00

The International Monetary Fund headquarters in Washington. (Yuri Gripas/Reuters)

## Métis Groups in 3 Provinces Sign Self-Governance Deals with Ottawa
 - [https://www.theepochtimes.com/metis-groups-in-3-provinces-sign-self-governance-deals-with-ottawa_5081400.html](https://www.theepochtimes.com/metis-groups-in-3-provinces-sign-self-governance-deals-with-ottawa_5081400.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 21:11:04+00:00

Minister of Crown-Indigenous Relations Marc Miller participates in a news conference in Ottawa on Oct. 29, 2021. (The Canadian Press/Justin Tang)

## China’s Lethal Aid to Russia Would Help ‘Extinguish Ukraine as a Nation’: Pentagon
 - [https://www.theepochtimes.com/chinas-lethal-aid-to-russia-would-help-extinguish-ukraine-as-a-nation-pentagon_5081643.html](https://www.theepochtimes.com/chinas-lethal-aid-to-russia-would-help-extinguish-ukraine-as-a-nation-pentagon_5081643.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 21:04:53+00:00

Emergency workers clear the rubble after a Russian rocket hit a multistory building leaving many people under debris in the southeastern city of Dnipro, Ukraine, on Jan. 14, 2023. (Evgeniy Maloletka/AP Photo)

## Senate Bill Condemns Chinese Aggression Toward Indian Border State
 - [https://www.theepochtimes.com/senate-bill-condemns-chinese-aggression-toward-indian-border-state_5075203.html](https://www.theepochtimes.com/senate-bill-condemns-chinese-aggression-toward-indian-border-state_5075203.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 20:48:43+00:00

An Indian Buddhist monk approaches the Thupten Gatsal Ling Gunpa, a branch of Tawang Monastery, in Itanagar, capital of Arunachal Pradesh, on October 11, 2009. (Diptendu Dutta/AFP via Getty Images)

## Former Chief Electoral Officer Calls for Independent Inquiry Into Chinese Interference in 2019 and 2021 Elections
 - [https://www.theepochtimes.com/former-chief-electoral-officer-calls-for-independent-inquiry-into-ccps-interference-in-2019-and-2021-federal-elections_5081502.html](https://www.theepochtimes.com/former-chief-electoral-officer-calls-for-independent-inquiry-into-ccps-interference-in-2019-and-2021-federal-elections_5081502.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 20:47:54+00:00

Jean-Pierre Kingsley, former chief electoral officer, appears at the Commons House Affairs Committee on Parliament Hill in Ottawa on Nov. 29, 2012. (Sean Kilpatrick/The Canadian Press)

## Blinken Calls on UN to Unite Behind Ukraine, Downplays China’s Peace Plan
 - [https://www.theepochtimes.com/blinken-calls-on-un-to-unite-behind-ukraine-downplays-chinas-peace-plan_5081512.html](https://www.theepochtimes.com/blinken-calls-on-un-to-unite-behind-ukraine-downplays-chinas-peace-plan_5081512.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 20:31:45+00:00

Secretary of State Antony Blinken speaks at the State Department in Washington on Jan. 4, 2023. (Sarah Silbiger/Reuters)

## Monopoly Case Gives Australian Port Operator Win
 - [https://www.theepochtimes.com/monopoly-case-gives-australian-port-operator-win_5080228.html](https://www.theepochtimes.com/monopoly-case-gives-australian-port-operator-win_5080228.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 20:28:34+00:00

Containers are loaded onto cargo ships at Port Botany in Sydney, Australia, on June 4, 2021. (Saeed Khan/AFP via Getty Images)

## High Court in London Says UK Company is Liable for Beirut Explosion That Killed Over 200
 - [https://www.theepochtimes.com/high-court-in-london-says-uk-company-is-liable-for-beirut-explosion-that-killed-over-200_5080803.html](https://www.theepochtimes.com/high-court-in-london-says-uk-company-is-liable-for-beirut-explosion-that-killed-over-200_5080803.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 20:18:51+00:00

This still image from a video shows smoke and dust rising from collapsing silos damaged during the massive explosion in the port of Beirut, on Aug. 23, 2022. (Lujain Jo/AP Photo)

## Tanks, Not Fighter Jets, Will Help Ukraine in Counteroffensive: Jake Sullivan
 - [https://www.theepochtimes.com/tanks-not-fighter-jets-will-help-ukraine-in-counteroffensive-jake-sullivan_5081030.html](https://www.theepochtimes.com/tanks-not-fighter-jets-will-help-ukraine-in-counteroffensive-jake-sullivan_5081030.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 20:07:23+00:00

National Security Adviser Jake Sullivan speaks during the daily press briefing at the White House in Washington on Dec. 12, 2022. (Drew Angerer/Getty Images)

## Brittany Higgins’ Case Shouldn’t Have Gone to Trial to Begin With, so Why Did It?
 - [https://www.theepochtimes.com/brittany-higgins-case-shouldnt-have-gone-to-trial-to-begin-with-so-why-did-it_5080172.html](https://www.theepochtimes.com/brittany-higgins-case-shouldnt-have-gone-to-trial-to-begin-with-so-why-did-it_5080172.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 20:06:26+00:00

Brittany Higgins leaves courtin Canberra, Australia, on Oct. 14, 2022. (Martin Ollman/Getty Images)

## Man Accused of Crashing Bus Into Quebec Daycare and Killing 2 Kids Fit to Stand Trial
 - [https://www.theepochtimes.com/man-accused-of-crashing-bus-into-quebec-daycare-and-killing-2-kids-fit-to-stand-trial_5081551.html](https://www.theepochtimes.com/man-accused-of-crashing-bus-into-quebec-daycare-and-killing-2-kids-fit-to-stand-trial_5081551.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 19:55:38+00:00

Police are shown outside the home of Pierre Ny St-Amand in Laval, Que, Feb. 8, 2023. (The Canadian Press/Graham Hughes)

## UK Prison Service ‘In Meltdown,’ Says Union Chief
 - [https://www.theepochtimes.com/uk-prison-service-in-meltdown-says-union-chief_5076136.html](https://www.theepochtimes.com/uk-prison-service-in-meltdown-says-union-chief_5076136.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 19:31:44+00:00

A view through the bars of Birmingham Prison in Winson Green in Birmingham, England, on Aug. 20, 2018.  (Christopher Furlong/Getty Images)

## 6 Countries Vote Against UN Resolution Calling for Russia to Withdraw From Ukraine
 - [https://www.theepochtimes.com/6-countries-vote-against-un-resolution-calling-for-russia-to-withdraw-from-ukraine_5080413.html](https://www.theepochtimes.com/6-countries-vote-against-un-resolution-calling-for-russia-to-withdraw-from-ukraine_5080413.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 19:30:21+00:00

A general view shows voting results during a U.N. General Assembly meeting at the United Nations headquarters in New York City on Oct. 12, 2022. (Ed Jones/AFP via Getty Images)

## UK’s Sunak Calls for Long-Term Security Assurance for Ukraine on War Anniversary
 - [https://www.theepochtimes.com/uks-sunak-calls-for-long-term-security-assurance-for-ukraine-on-war-anniversary_5080887.html](https://www.theepochtimes.com/uks-sunak-calls-for-long-term-security-assurance-for-ukraine-on-war-anniversary_5080887.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 19:29:11+00:00

Prime Minister Rishi Sunak and his wife Akshata Murty with members of the Ukrainian Armed Forces, as they observe a minute's silence to mark the one-year anniversary of the Russian invasion of Ukraine, outside 10 Downing Street, London, on Feb. 24, 2023. (Jordan Pettitt/PA Media)

## Ottawa Increases Funding to Ukraine With $32 Million Pledge
 - [https://www.theepochtimes.com/ottawa-increases-funding-to-ukraine-with-32-million-pledge_5081176.html](https://www.theepochtimes.com/ottawa-increases-funding-to-ukraine-with-32-million-pledge_5081176.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 19:27:33+00:00

Foreign Affairs Minister Melanie Joly speaks to the media at the Hamilton Convention Centre in Hamilton, Ont., on Jan. 23, 2023. (The Canadian Press/Nick Iwanyshyn)

## How the WEF Spends Millions in Canadian Taxpayer Money
 - [https://www.theepochtimes.com/how-the-wef-spends-millions-in-canadians-taxpayer-money_5081321.html](https://www.theepochtimes.com/how-the-wef-spends-millions-in-canadians-taxpayer-money_5081321.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 19:15:09+00:00

A sign of the World Economic Forum is seen at the Congress centre during its annual meeting in Davos on May 23, 2022. (Fabrice Coffrini/AFP via Getty Images)

## Russia Working with Iran, North Korea on New Arms Deals: White House
 - [https://www.theepochtimes.com/russia-working-with-iran-north-korea-on-new-arms-deals-white-house_5081225.html](https://www.theepochtimes.com/russia-working-with-iran-north-korea-on-new-arms-deals-white-house_5081225.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 19:03:53+00:00

Russia's President Vladimir Putin (L), who arrived to attend the Gas Exporting Countries Forum (GECF), meets with Iran's Supreme Leader Ayatollah Ali Khamenei in Tehran, Iran, Nov. 23, 2015. (REUTERS/Alexei Druzhinin/Sputnik/Kremlin/File Photo}

## Academics Argue for World War II-Style Rationing of Food and Fuel to Fight ‘Climate Change’
 - [https://www.theepochtimes.com/academics-argue-for-world-war-ii-style-rationing-of-food-and-fuel-to-fight-climate-change_5080518.html](https://www.theepochtimes.com/academics-argue-for-world-war-ii-style-rationing-of-food-and-fuel-to-fight-climate-change_5080518.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 18:57:18+00:00

An egg display case is seen nearly empty at a Giant Food grocery store in Washington on Jan. 9, 2022. (Sarah Silbiger/Reuters)

## ULEZ Advert Probed After Hundreds Complained Over ‘Misleading’ Claims
 - [https://www.theepochtimes.com/ulez-advert-probed-after-hundreds-complained-over-misleading-claims_5080584.html](https://www.theepochtimes.com/ulez-advert-probed-after-hundreds-complained-over-misleading-claims_5080584.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 18:44:15+00:00

A sign at the expanded boundary of London’s ULEZ pollution charge zone for older vehicles on Oct. 25, 2021. (Yui Mok/PA)

## Mozambicans Seek Shelter as Storm Freddy Makes Landfall
 - [https://www.theepochtimes.com/mozambicans-seek-shelter-as-storm-freddy-makes-landfall_5073482.html](https://www.theepochtimes.com/mozambicans-seek-shelter-as-storm-freddy-makes-landfall_5073482.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 18:39:48+00:00

Winds and rain continue to increase in strength as Cyclone Freddy makes landfall over Vilankulos, Mozambique, on Feb. 24, 2023, in this screen grab obtained from a social media video. (UNICEF Mozambique/2023/Guy Taylor via Reuters)

## Northern Ireland Politicians and Police Unite ‘As One Voice’ Over Detective Shooting
 - [https://www.theepochtimes.com/northern-ireland-politicians-and-police-unite-as-one-voice-over-detective-shooting_5080645.html](https://www.theepochtimes.com/northern-ireland-politicians-and-police-unite-as-one-voice-over-detective-shooting_5080645.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 18:29:43+00:00

From left: SDLP leader Colum Eastwood, DUP leader Jeffrey Donaldson, Police Service of Northern Ireland (PSNI) Chief Constable Simon Byrne, Sinn Fein deputy leader Michelle O'Neill, Ulster Unionist Party (UUP) leader Doug Beattie, and Stephen Farry from the Alliance party, speak to the media outside PSNI HQ in Belfast, on Feb. 24, 2023. (PA Media)

## Residents Battle Bath Council Anti-Car Policies: ‘It’s the Rationing of Movement’
 - [https://www.theepochtimes.com/residents-battle-bath-council-anti-car-policies-its-the-rationing-of-movement_5077942.html](https://www.theepochtimes.com/residents-battle-bath-council-anti-car-policies-its-the-rationing-of-movement_5077942.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 18:26:14+00:00

Local woman Caroline Horsford campaigning and protesting for Free Bath Streets in Bath, England. (Photo courtesy of Caroline Horsford)

## Hall of Fame Member Stephenson Diagnosed With Stage 3 Breast Cancer
 - [https://www.theepochtimes.com/hall-of-fame-member-stephenson-diagnosed-with-stage-3-breast-cancer_5081130.html](https://www.theepochtimes.com/hall-of-fame-member-stephenson-diagnosed-with-stage-3-breast-cancer_5081130.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 17:56:52+00:00

World Golf Hall of Fame inductee Jan Stephenson gives her acceptance speech during the 2019 World Golf Hall of Fame Induction Ceremony at the Sunset Center in Carmel-By-The-Sea, Calif., on June 10, 2019. (Daniel Shirey/Getty Images)

## Turkey Begins to Rebuild for 1.5 Million Left Homeless by Earthquakes
 - [https://www.theepochtimes.com/turkey-begins-to-rebuild-for-1-5-million-left-homeless-by-earthquakes_5080713.html](https://www.theepochtimes.com/turkey-begins-to-rebuild-for-1-5-million-left-homeless-by-earthquakes_5080713.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 17:47:11+00:00

People affected by the deadly earthquake queue for aid in Hatay, Turkey, on Feb. 24, 2023. (Eloisa Lopez/Reuters)

## Bank of Japan’s Next Chief Says Monetary Easing Policy Still Necessary
 - [https://www.theepochtimes.com/bank-of-japans-next-chief-says-monetary-easing-policy-still-necessary_5080265.html](https://www.theepochtimes.com/bank-of-japans-next-chief-says-monetary-easing-policy-still-necessary_5080265.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 17:19:14+00:00

A man walks past Bank of Japan's headquarters in Tokyo on June 17, 2022. (Kim Kyung-Hoon/Reuters)

## Canada Sending Another $30M in Aid to Turkey, Syria, as Rebuild Begins
 - [https://www.theepochtimes.com/canada-sending-another-30m-in-aid-to-turkey-syria-as-rebuild-begins_5081164.html](https://www.theepochtimes.com/canada-sending-another-30m-in-aid-to-turkey-syria-as-rebuild-begins_5081164.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 17:11:53+00:00

Excavators work at the site of buildings that collapsed during the earthquake in Kahramanmaras, Turkey, Feb. 17, 2023. (The Canadian Press/AP-Bernat Armangue)

## Unrecoverable Federal Student Loans Up 34% This Fiscal Year: PBO
 - [https://www.theepochtimes.com/unrecoverable-federal-student-loans-up-34-this-fiscal-year-pbo_5080707.html](https://www.theepochtimes.com/unrecoverable-federal-student-loans-up-34-this-fiscal-year-pbo_5080707.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 16:55:24+00:00

Students gather at an outdoor university commencement ceremony in this file photo. (Dreamstime)

## Manitoba, Federal Government Reach $6.7B Health-Care Deal
 - [https://www.theepochtimes.com/manitoba-federal-government-reach-6-7b-health-care-deal_5081123.html](https://www.theepochtimes.com/manitoba-federal-government-reach-6-7b-health-care-deal_5081123.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 16:52:29+00:00

Health Minister Jean-Yves Duclos makes an announcement on ending vaccine mandates for domestic travellers, transportation workers, and federal employees, in Ottawa on June 14, 2022. (The Canadian Press/Patrick Doyle)

## Assisted Suicide: Legalize First, Ask Questions Later
 - [https://www.theepochtimes.com/assisted-suicide-legalize-first-ask-questions-later_5080679.html](https://www.theepochtimes.com/assisted-suicide-legalize-first-ask-questions-later_5080679.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 16:51:22+00:00

MAiD is irreversible, and the federal government must recognize the inherent problems with any further expansion.(Pascal Pochard-Casabianca/AFP)

## Head of Canada’s Drug Price Regulator Resigns Same Week as Colleague Steps Down
 - [https://www.theepochtimes.com/head-of-canadas-drug-price-regulator-resigns-same-week-as-colleague-steps-down_5081114.html](https://www.theepochtimes.com/head-of-canadas-drug-price-regulator-resigns-same-week-as-colleague-steps-down_5081114.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 16:48:46+00:00

Federal Health Minister Jean-Yves Duclos speaks to the media at the Hamilton Convention Centre, in Hamilton, Ont., during the Liberal cabinet retreat, on Jan. 23, 2023. (The Canadian Press/Nick Iwanyshyn)

## Police Will No Longer Be the Default Responders to UK Mental Health Incidents
 - [https://www.theepochtimes.com/police-will-no-longer-be-the-default-responders-to-uk-mental-health-incidents_5080485.html](https://www.theepochtimes.com/police-will-no-longer-be-the-default-responders-to-uk-mental-health-incidents_5080485.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 16:42:19+00:00

Officers of the Metropolitan Police patrol in Victoria Park, east London, on April 11, 2020. (Tolga Akmen/AFP via Getty Images)

## 10 Killed in Riots in Indonesia’s Restive Papua Province
 - [https://www.theepochtimes.com/10-killed-in-riots-in-indonesias-restive-papua-province_5081009.html](https://www.theepochtimes.com/10-killed-in-riots-in-indonesias-restive-papua-province_5081009.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 16:22:19+00:00

Indonesian riot police take positions as fresh unrest broke out in Indonesia's restive Papua region in provincial capital Jayapura on Sept. 23, 2019. (Faisal Narwawan/AFP via Getty Images)

## North Korea Tests 4 Cruise Missiles as US, South Korea Hold Tabletop Drill
 - [https://www.theepochtimes.com/north-korea-tests-4-cruise-missiles-as-us-south-korea-hold-tabletop-drill_5079919.html](https://www.theepochtimes.com/north-korea-tests-4-cruise-missiles-as-us-south-korea-hold-tabletop-drill_5079919.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 16:11:54+00:00

People watch a television news broadcast showing file footage of a North Korean missile test, at a railway station in Seoul on April 14, 2020. (Jung Yeon-je/AFP via Getty Images)

## Biden Gives $2 Billion More in Military Aid to Ukraine on War Anniversary
 - [https://www.theepochtimes.com/biden-gives-2-billion-more-in-military-aid-to-ukraine-on-war-anniversary_5080515.html](https://www.theepochtimes.com/biden-gives-2-billion-more-in-military-aid-to-ukraine-on-war-anniversary_5080515.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 15:53:33+00:00

President Joe Biden, left, meets with Ukrainian President Volodymyr Zelenskyy at Mariinsky Palace during an unannounced visit in Kyiv, Ukraine, on Feb. 20, 2023. (Evan Vucci, Pool/AP Photo)

## German Economy Shrinks 0.4 Percent in 4th Quarter, Weak Start to 2023 Seen
 - [https://www.theepochtimes.com/german-economy-shrinks-0-4-percent-in-4th-quarter-weak-start-to-2023-seen_5080827.html](https://www.theepochtimes.com/german-economy-shrinks-0-4-percent-in-4th-quarter-weak-start-to-2023-seen_5080827.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 15:52:15+00:00

The sun sets behind the skyline of Frankfurt, Germany, on July 5, 2022. (Kai Pfaffenbach/Reuters)

## Convicted Gene-Editing Scientist Has Hong Kong Visa Revoked After Public Outrage
 - [https://www.theepochtimes.com/convicted-gene-editing-scientist-has-hong-kong-visa-revoked-after-public-outrage_5079798.html](https://www.theepochtimes.com/convicted-gene-editing-scientist-has-hong-kong-visa-revoked-after-public-outrage_5079798.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 15:40:17+00:00

He Jiankui speaking at the second international summit on human genome editing in Hong Kong in November 2018. (Sung Pi-Lung/The Epoch Times)

## US Unveils New Sanctions, Tariffs on Russia on Ukraine War Anniversary
 - [https://www.theepochtimes.com/us-unveils-new-sanctions-tariffs-on-russia-on-ukraine-war-anniversary_5080788.html](https://www.theepochtimes.com/us-unveils-new-sanctions-tariffs-on-russia-on-ukraine-war-anniversary_5080788.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 15:23:40+00:00

The U.S. President Joe Biden delivers a speech at the Royal Castle Arcades in Warsaw, Poland, on Feb. 21, 2023. (Omar Marques/Getty Images)

## Japan’s Consumer Inflation Hits 41-year High, Keeps BOJ Under Pressure
 - [https://www.theepochtimes.com/japans-consumer-inflation-hits-41-year-high-keeps-boj-under-pressure_5080756.html](https://www.theepochtimes.com/japans-consumer-inflation-hits-41-year-high-keeps-boj-under-pressure_5080756.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 14:49:01+00:00

Shoppers check food items at a supermarket in Tokyo, Japan, on Jan. 20, 2023. (Issei Kato/Reuters)

## German Chemical Giant BASF to Close Factories Without Cheap Russian Gas
 - [https://www.theepochtimes.com/german-chemical-giant-basf-to-close-factories-without-cheap-russian-gas_5080493.html](https://www.theepochtimes.com/german-chemical-giant-basf-to-close-factories-without-cheap-russian-gas_5080493.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 14:39:00+00:00

A man walks past tanks of German chemicals giant BASF at the company's headquarters in Ludwigshafen, Germany, on Feb. 26, 2019. (Uwe Anspach/DPA/AFP via Getty Images)

## Bitter Legacy Hangs Over Today’s Energy Discussions Between Quebec and NL Premiers
 - [https://www.theepochtimes.com/bitter-legacy-hangs-over-todays-energy-discussions-between-quebec-and-nl-premiers_5080730.html](https://www.theepochtimes.com/bitter-legacy-hangs-over-todays-energy-discussions-between-quebec-and-nl-premiers_5080730.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 14:28:56+00:00

Quebec Premier François Legault responds during question period at the legislature in Quebec City on Feb. 16, 2023. (The Canadian Press/Jacques Boissinot)

## Previously Undisclosed COVID Vaccine Agreements Between Pfizer and Israel Released
 - [https://www.theepochtimes.com/previously-undisclosed-covid-vaccine-agreements-between-pfizer-and-israel-released_5078628.html](https://www.theepochtimes.com/previously-undisclosed-covid-vaccine-agreements-between-pfizer-and-israel-released_5078628.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 14:28:13+00:00

A medic prepares a dose of the Pfizer-BioNTech COVID-19 vaccine in Netanya, Israel, on Jan. 5, 2022. (Jack Guez/AFP via Getty Images)

## Canadians ‘Stand With Ukraine’ on One-Year Anniversary of Russian Invasion
 - [https://www.theepochtimes.com/canadians-stand-with-ukraine-on-one-year-anniversary-of-russian-invasion_5080712.html](https://www.theepochtimes.com/canadians-stand-with-ukraine-on-one-year-anniversary-of-russian-invasion_5080712.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 14:19:13+00:00

The flag of Ukraine is seen beside the Peace Tower, on the same day as Ukrainian President Volodymyr Zelenskyy’s address to Parliament in the House of Commons on Parliament Hill in Ottawa, on March 15, 2022. (The Canadian Press/Justin Tang)

## TikTok Under Joint Investigation by Canadian Privacy Protection Authorities
 - [https://www.theepochtimes.com/tiktok-under-joint-investigation-by-canadian-privacy-protection-authorities_5080596.html](https://www.theepochtimes.com/tiktok-under-joint-investigation-by-canadian-privacy-protection-authorities_5080596.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 14:19:03+00:00

A visitor passes the TikTok exhibition stands at the Gamescom computer gaming fair in Cologne, Germany, on Aug. 25, 2022. (Martin Meissner/AP Photo)

## Core Inflation Soars to Record High in Eurozone
 - [https://www.theepochtimes.com/core-inflation-soars-to-record-high-in-eurozone_5079376.html](https://www.theepochtimes.com/core-inflation-soars-to-record-high-in-eurozone_5079376.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 14:12:52+00:00

The south facade of the European Central Bank (ECB) headquarters in Frankfurt, Germany, on Dec. 30, 2021. (Reuters/Wolfgang Rattay

## Biden Nominates Wall Street Veteran Ajay Banga as World Bank President
 - [https://www.theepochtimes.com/biden-nominates-wall-street-veteran-ajay-banga-as-world-bank-president_5079775.html](https://www.theepochtimes.com/biden-nominates-wall-street-veteran-ajay-banga-as-world-bank-president_5079775.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 14:03:00+00:00

Ajay Banga, former president and CEO of MasterCard, speaks during a press conference at the National Press Club in Washington, on Dec. 17, 2018. (Win McNamee/Getty Images)

## Making Money Is Good for Customers, Workers: CEO Stands by Airline’s Billion-Dollar Profit
 - [https://www.theepochtimes.com/making-money-is-good-for-customers-workers-ceo-stands-by-airlines-billion-dollar-profit_5080026.html](https://www.theepochtimes.com/making-money-is-good-for-customers-workers-ceo-stands-by-airlines-billion-dollar-profit_5080026.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 12:32:34+00:00

A line of Qantas aircraft sits at Kingsford Smith Airport in Sydney, Australia, on Oct. 31, 2021. (James D. Morgan/Getty Images)

## Blinken Says Beijing ‘Almost Certainly’ Provided Russia With Dual-Use Aid
 - [https://www.theepochtimes.com/blinken-says-beijing-almost-certainly-provided-russia-with-dual-use-aid_5080438.html](https://www.theepochtimes.com/blinken-says-beijing-almost-certainly-provided-russia-with-dual-use-aid_5080438.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 11:51:23+00:00

Secretary of State Antony Blinken speaks at the 2023 Munich Security Conference (MSC) in Munich, Germany, on Feb. 18, 2023. (Johannes Simon/Getty Images)

## Nearly 1 Million Asylum Requests in the EU in 2022
 - [https://www.theepochtimes.com/nearly-1-million-asylum-requests-in-the-eu-in-2022_5078098.html](https://www.theepochtimes.com/nearly-1-million-asylum-requests-in-the-eu-in-2022_5078098.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 11:32:25+00:00

Refugees wait in a crowd for transportation after fleeing from the Ukraine and arriving at the border crossing in Medyka, Poland, on March 7, 2022. (Markus Schreiber/AP Photo)

## Ukraine War Could Last Another 12 Months, Says UK Defence Chief Ahead of Anniversary
 - [https://www.theepochtimes.com/ukraine-war-could-last-another-12-months-says-uk-defence-chief-ahead-of-anniversary_5078626.html](https://www.theepochtimes.com/ukraine-war-could-last-another-12-months-says-uk-defence-chief-ahead-of-anniversary_5078626.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 09:53:30+00:00

Britain's Secretary of State for Defence, Ben Wallace, poses for a group picture on the second day of a NATO Defence Ministers meeting at NATO Headquarters in Brussels on Oct. 13, 2022. (Kenzo Tribouillard/AFP via Getty Images)

## US to Target Chinese Companies in Upcoming Sanctions on Russia: State Department
 - [https://www.theepochtimes.com/us-to-target-chinese-companies-in-upcoming-sanctions-on-russia-state-department_5079420.html](https://www.theepochtimes.com/us-to-target-chinese-companies-in-upcoming-sanctions-on-russia-state-department_5079420.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 05:54:28+00:00

Undersecretary of State for Political Affairs Victoria Nuland testifies before a Senate Foreign Relations Committee hearing on Ukraine in Washington, D.C., on March 8, 2022. (Kevin Dietsch/Getty Images)

## Stockholm Police Head Found Dead After Report Criticized Him
 - [https://www.theepochtimes.com/stockholm-police-head-found-dead-after-report-criticized-him_5078700.html](https://www.theepochtimes.com/stockholm-police-head-found-dead-after-report-criticized-him_5078700.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 05:31:28+00:00

Stockholm regional police chief Mats Lofving on Sept. 30, 2022. (Henrik Montgomery/TT News Agency via AP)

## Accused Extremist Recruiter Awso Peshdary Pleads Guilty to Terrorism-Related Charges
 - [https://www.theepochtimes.com/accused-extremist-recruiter-awso-peshdary-pleads-guilty-to-terrorism-related-charges_5080166.html](https://www.theepochtimes.com/accused-extremist-recruiter-awso-peshdary-pleads-guilty-to-terrorism-related-charges_5080166.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 05:15:55+00:00

Awso Peshdary, who is accused of recruiting for ISIL, is escorted by police as he arrives for a hearing at the Supreme Court of Canada in Ottawa on Aug. 13, 2018. (The Canadian Press/Justin Tang)

## Ontario Explores Possibility of New, Large-Scale Nuclear Plants
 - [https://www.theepochtimes.com/ontario-explores-possibility-of-new-large-scale-nuclear-plants_5080155.html](https://www.theepochtimes.com/ontario-explores-possibility-of-new-large-scale-nuclear-plants_5080155.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 05:09:29+00:00

The Pickering Nuclear Generating Station, in Pickering, Ont., is seen Jan. 12, 2020. (The Canadian Press/Frank Gunn)

## Australia’s Largest Supermarket Chains Overcome Challenging Economic Conditions
 - [https://www.theepochtimes.com/australias-two-largest-supermarket-chains-report-significant-profit-growth-amid-challenging-economic-conditions_5080002.html](https://www.theepochtimes.com/australias-two-largest-supermarket-chains-report-significant-profit-growth-amid-challenging-economic-conditions_5080002.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 05:08:41+00:00

Coles and Woolworths signs are seen outside a shopping centre in Melbourne, Australia, on May 25, 2015.  (Quinn Rooney/Getty Images)

## Federal Disaster Aid Program for 2021 BC Floods Now Tops $1 Billion
 - [https://www.theepochtimes.com/federal-disaster-aid-program-for-2021-bc-floods-now-tops-1-billion_5080144.html](https://www.theepochtimes.com/federal-disaster-aid-program-for-2021-bc-floods-now-tops-1-billion_5080144.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 05:02:58+00:00

President of the Queen’s Privy Council for Canada and Emergency Preparedness Minister Bill Blair rises during Question Period, on April 25, 2022 in Ottawa. (The Canadian Press/Adrian Wyld)

## Danish Queen Recovering From ‘Extensive’ Back Surgery
 - [https://www.theepochtimes.com/danish-queen-recovering-from-extensive-back-surgery_5078336.html](https://www.theepochtimes.com/danish-queen-recovering-from-extensive-back-surgery_5078336.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 04:41:10+00:00

Queen Margrethe II attends the church service in Copenhagen Cathedral to mark the 50th anniversary of her accession to the throne in Copenhagen, Denmark, on Sept. 11, 2022. (Martin Sylvest/Ritzau Scanpix via AP)

## Labor Fails Farming Communities as Deadline for Murray Darling Basin Plan Looms
 - [https://www.theepochtimes.com/labor-fails-farming-communities-as-deadline-for-murray-darling-basin-plan-looms_5080009.html](https://www.theepochtimes.com/labor-fails-farming-communities-as-deadline-for-murray-darling-basin-plan-looms_5080009.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 04:16:45+00:00

Australian Environment Minister Tanya Plibersek speaks during House of Representatives Question Time at Parliament House in Canberra on Feb. 15, 2023. (AAP Image/Lukas Coch)

## Minister Concerned ‘Strain’ Facing Aged Care Sector
 - [https://www.theepochtimes.com/minister-concerned-strain-facing-aged-care-sector_5080010.html](https://www.theepochtimes.com/minister-concerned-strain-facing-aged-care-sector_5080010.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 03:59:41+00:00

Australia's Minister for Sport Anika Wells during Question Time in the House of Representatives at Parliament House in Canberra on Nov. 8, 2022. (AAP Image/Mick Tsikas)

## Coles, Woolworths Takes Responsibility for 12,000 Tonnes of Unrecycled Plastics
 - [https://www.theepochtimes.com/coles-woolworths-takes-responsibility-for-12000-tonnes-of-unrecycled-plastics_5080027.html](https://www.theepochtimes.com/coles-woolworths-takes-responsibility-for-12000-tonnes-of-unrecycled-plastics_5080027.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 03:53:52+00:00

(Amy Yip/The Epoch Times)

## Putin Gifted Biden a $12,000 Pen Months Before Invading Ukraine
 - [https://www.theepochtimes.com/putin-gifted-biden-a-12000-pen-months-before-invading-ukraine_5078932.html](https://www.theepochtimes.com/putin-gifted-biden-a-12000-pen-months-before-invading-ukraine_5078932.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 03:36:32+00:00

Russian President Vladimir Putin holds a meeting with Chinese President Xi Jinping via a video link at the Kremlin in Moscow on Dec. 30, 2022. (Mikhail Klimentyev/SPUTNIK/AFP via Getty Images)

## US Urges All Governments to Respect Religious Freedom After European Court Rules in Favor of Falun Gong in Russia
 - [https://www.theepochtimes.com/us-urges-all-governments-to-respect-religious-freedom-after-european-court-rules-in-favor-of-falun-gong-in-russia_5079699.html](https://www.theepochtimes.com/us-urges-all-governments-to-respect-religious-freedom-after-european-court-rules-in-favor-of-falun-gong-in-russia_5079699.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 03:36:24+00:00

The State Department in Washington on Sept. 19, 2018. (Samira Bouaou/The Epoch Times)

## Energy Infrastructure Payments a ‘Slap in the Face’
 - [https://www.theepochtimes.com/energy-infrastructure-payments-a-slap-in-the-face_5079999.html](https://www.theepochtimes.com/energy-infrastructure-payments-a-slap-in-the-face_5079999.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 02:47:24+00:00

Premier Daniel Andrews of Victoria speaks to media during an announcement at PowerPlus Energy, in Melbourne, Australia on Oct. 21, 2022. (AAP Image/Diego Fedele)

## New Incentives Look to Attract Cops to Regional Australia
 - [https://www.theepochtimes.com/new-incentives-look-to-attract-cops-to-regional-australia_5079980.html](https://www.theepochtimes.com/new-incentives-look-to-attract-cops-to-regional-australia_5079980.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 02:33:32+00:00

NSW police stop vehicles at the Hume Highway checkpoint at the Victorian border in Albury, Australia on November 22, 2020. (Lisa Maree Williams/Getty Images)

## Canada-Wide Warrant Issued for 31-Year-Old Male Known to Frequent Toronto
 - [https://www.theepochtimes.com/canada-wide-warrant-issued-for-31-year-old-male-known-to-frequent-toronto_5079863.html](https://www.theepochtimes.com/canada-wide-warrant-issued-for-31-year-old-male-known-to-frequent-toronto_5079863.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 02:23:28+00:00

An Ontario Provincial Police logo is shown during a press conference in Barrie, Ont., on April 3, 2019. (Nathan Denette/The Canadian Press)

## Twitter, TikTok, Google Face Questions Over Child Abuse Material
 - [https://www.theepochtimes.com/twitter-tiktok-google-face-questions-over-child-abuse-material_5079936.html](https://www.theepochtimes.com/twitter-tiktok-google-face-questions-over-child-abuse-material_5079936.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 02:18:01+00:00

A young girl looking at social media apps, including TikTok, Instagram, Snapchat, and WhatsApp, on a smartphone on Nov. 12, 2019. (Peter Byrne/PA)

## Trudeau Promises Federal Money to Provinces That Host Roxham Asylum Seekers
 - [https://www.theepochtimes.com/trudeau-promises-federal-money-to-provinces-that-house-illegal-refugees_5079872.html](https://www.theepochtimes.com/trudeau-promises-federal-money-to-provinces-that-house-illegal-refugees_5079872.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 02:12:23+00:00

An RCMP officer informs a migrant couple of the location of an official border station, shortly before they illegally crossed from New York to Quebec via Roxham Road, on Aug. 7, 2017. (Charles Krupa, File/AP Photo)

## Confucius Institutes Are ‘Propaganda Centres,’ Says Former PM, Foreign Minister Urged to Shut Centres Down
 - [https://www.theepochtimes.com/confucius-institutes-are-propaganda-centres-says-former-pm-foreign-minister-urged-to-shut-centres-down_5079892.html](https://www.theepochtimes.com/confucius-institutes-are-propaganda-centres-says-former-pm-foreign-minister-urged-to-shut-centres-down_5079892.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 02:03:22+00:00

Then-Chinese vice chair Xi Jinping unveils a plaque at the opening of Australia's first Chinese Medicine Confucius Institute at the RMIT University in Melbourne on June 20, 2010. (William West/AFP via Getty Images)

## US Deems Australia in the ‘Frontline’ of Tension With Beijing: Former Ambassador
 - [https://www.theepochtimes.com/us-now-deems-australia-the-frontline-of-tension-with-beijing-former-ambassador_5071890.html](https://www.theepochtimes.com/us-now-deems-australia-the-frontline-of-tension-with-beijing-former-ambassador_5071890.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 01:38:29+00:00

A U.S military HH-60 Pave Hawk Helicopter is seen flying over a simulated crash site during Exercise Angel Reign on July 1, 2016 in Townsville, Australia. (Ian Hitchcock/Getty Images)

## Struggle For Chinese Democracy Erupts at University of Sydney
 - [https://www.theepochtimes.com/chinas-struggle-for-democracy-erupts-at-university-of-sydney_5077165.html](https://www.theepochtimes.com/chinas-struggle-for-democracy-erupts-at-university-of-sydney_5077165.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-24 00:32:42+00:00

A peaceful protest by Aaron Chang at the University of Sydney was smashed by pro-Beijing youths for several days (Supplied).

