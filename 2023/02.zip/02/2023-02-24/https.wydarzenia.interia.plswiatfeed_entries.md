# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Zełenski dziękuje Morawieckiemu. "Polska będzie z nami do zwycięstwa"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-dziekuje-morawieckiemu-polska-bedzie-z-nami-do-zwyc,nId,6618199](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-dziekuje-morawieckiemu-polska-bedzie-z-nami-do-zwyc,nId,6618199)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-02-24 16:44:20+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-dziekuje-morawieckiemu-polska-bedzie-z-nami-do-zwyc,nId,6618199"><img align="left" alt="Zełenski dziękuje Morawieckiemu. &quot;Polska będzie z nami do zwycięstwa&quot;" src="https://i.iplsc.com/zelenski-dziekuje-morawieckiemu-polska-bedzie-z-nami-do-zwyc/000GT3MLHCBJRA2H-C321.jpg" /></a>&quot;Polska była z nami jeszcze przed rozpoczęciem pełnoskalowej wojny, była z nami w każdej minucie tego roku i jestem pewien, że będzie z nami aż do naszego zwycięstwa. Naszego wspólnego zwycięstwa!&quot; - napisał prezydent Wołodymyr Zełenski w mediach społecznościowych. Ukraiński przywódca odniósł się w ten sposób do wizyty premiera Mateusza Morawieckiego w Kijowie. &quot;Jestem wdzięczny naszym polskim braciom za zrozumienie sytuacji i potrzeb Ukrainy&quot; - zaznaczył.</p><br clear="all" />

## Polska dostarczy dziś pierwsze czołgi Leopard 2 na Ukrainę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polska-dostarczy-dzis-pierwsze-czolgi-leopard-2-na-ukraine,nId,6617852](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polska-dostarczy-dzis-pierwsze-czolgi-leopard-2-na-ukraine,nId,6617852)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-02-24 09:35:01+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polska-dostarczy-dzis-pierwsze-czolgi-leopard-2-na-ukraine,nId,6617852"><img align="left" alt="Polska dostarczy dziś pierwsze czołgi Leopard 2 na Ukrainę" src="https://i.iplsc.com/polska-dostarczy-dzis-pierwsze-czolgi-leopard-2-na-ukraine/000GT11RG7MIOYR1-C321.jpg" /></a>Polska dostarczy w piątek pierwsze czołgi Leopard 2 na Ukrainę - podał Bloomberg. To pierwsze z 14 czołgów, które trafią do władz w Kijowie. Źródło zbliżone do rządu potwierdziło Interii, że pierwsze czołgi już dotarły do Ukrainy. </p><br clear="all" />

## "The Washington Post": Chcesz żyć dłużej? Jedz jak stulatek
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-chcesz-zyc-dluzej-jedz-jak-stulatek,nId,6615640](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-chcesz-zyc-dluzej-jedz-jak-stulatek,nId,6615640)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-02-24 06:52:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-chcesz-zyc-dluzej-jedz-jak-stulatek,nId,6615640"><img align="left" alt="&quot;The Washington Post&quot;: Chcesz żyć dłużej? Jedz jak stulatek" src="https://i.iplsc.com/the-washington-post-chcesz-zyc-dluzej-jedz-jak-stulatek/000GSVRRDHAY2BIJ-C321.jpg" /></a>Nikt nam nie zagwarantuje osiągnięcia 100 lat. Możemy jednak wiele się nauczyć, obserwując nawyki żywieniowe stulatków z innych miejsc na świecie. Mieszkańcy włoskiej Sardynii, japońskiej Okinawy czy greckiej Ikarii stosują się do kilku prostych zasad żywieniowych. Efekty są imponujące. Miejsca te słyną z wyjątkowo wysokiej oczekiwanej długości życia. Ich przykład pokazuje, że niewiele potrzeba, by żyć długo i zdrowo. Przyjrzyjmy się przepisowi na długowieczność. </p><br clear="all" />

## Wojna w Ukrainie. 366. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240529](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240529)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-02-24 04:29:12+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo,nzId,3824,akt,240529"><img align="left" alt="Wojna w Ukrainie. 366. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-366-dzien-inwazji-rosji-relacja-na-zywo/000GSZVSKGMS6FLQ-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

