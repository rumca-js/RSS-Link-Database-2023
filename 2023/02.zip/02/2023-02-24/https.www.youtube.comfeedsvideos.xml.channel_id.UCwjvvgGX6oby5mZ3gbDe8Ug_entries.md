# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## China: Foreign trade manufacturing industry faces an avalanche & its economy is in a major setback
 - [https://www.youtube.com/watch?v=4zQPpOGD6f4](https://www.youtube.com/watch?v=4zQPpOGD6f4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-02-24 14:30:01+00:00

#chinainsights 
Saving the boss is saving the job. A Chinese media outlet described it this way, " What is feared now is not that employees quietly go to a job interview, but that the boss quietly leaves to find a job." The Pearl River Delta and the Yangtze River Delta are the two major processing and manufacturing centers of China's foreign trade exports, and many bosses here have fallen on hard times because of the lack of international orders.

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

