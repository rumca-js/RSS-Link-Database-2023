# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Flathub Plans to Evolve as the Universal Linux App Store
 - [https://news.itsfoss.com/flathub-app-store-plans/](https://news.itsfoss.com/flathub-app-store-plans/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-02-24 10:26:23+00:00

Flathub is gearing up for changes and improvements across the board. Here's what you need to know about it.

