# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Cocaine Bear - Movie Review
 - [https://www.youtube.com/watch?v=AYUJrUQP30M](https://www.youtube.com/watch?v=AYUJrUQP30M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2023-02-24 14:00:10+00:00

Well, the trailer looked fun. There's that. Here's my review for COCAINE BEAR!

#CocaineBear

## Creed 3 - Movie Review
 - [https://www.youtube.com/watch?v=NBPSOi1-wsU](https://www.youtube.com/watch?v=NBPSOi1-wsU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2023-02-24 03:00:09+00:00

Adonis Creed (Michael B. Jordan) is reunited with an old friend from his past (Jonathan Majors) who wants a shot at the title. Here's my review for CREED 3!

#Creed3

