# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Brazil’s President rails against online “hate speech” and “disinformation,” calls for global action
 - [https://reclaimthenet.org/brazil-lula-online-hate-speech-disinformation](https://reclaimthenet.org/brazil-lula-online-hate-speech-disinformation)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-24 19:21:44+00:00

<a href="https://reclaimthenet.org/brazil-lula-online-hate-speech-disinformation" rel="nofollow" title="Brazil&#8217;s President rails against online &#8220;hate speech&#8221; and &#8220;disinformation,&#8221; calls for global action"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/lula-censor.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>To protect "democracy."</p>
<p>The post <a href="https://reclaimthenet.org/brazil-lula-online-hate-speech-disinformation" rel="nofollow">Brazil&#8217;s President rails against online &#8220;hate speech&#8221; and &#8220;disinformation,&#8221; calls for global action</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Private and secure two-factor authentication tools
 - [https://reclaimthenet.org/private-and-secure-2fa-tools](https://reclaimthenet.org/private-and-secure-2fa-tools)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-24 18:30:56+00:00

<a href="https://reclaimthenet.org/private-and-secure-2fa-tools" rel="nofollow" title="Private and secure two-factor authentication tools"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/secure-two-factor-authentication-tools.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Use these tools to protect your online accounts.</p>
<p>The post <a href="https://reclaimthenet.org/private-and-secure-2fa-tools" rel="nofollow">Private and secure two-factor authentication tools</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Store face scanner age estimator wants to get into collecting data for advertising
 - [https://reclaimthenet.org/face-scanner-age-estimator-collecting-data-for-advertising](https://reclaimthenet.org/face-scanner-age-estimator-collecting-data-for-advertising)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-24 18:05:14+00:00

<a href="https://reclaimthenet.org/face-scanner-age-estimator-collecting-data-for-advertising" rel="nofollow" title="Store face scanner age estimator wants to get into collecting data for advertising"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/ag-verify.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>As expected.</p>
<p>The post <a href="https://reclaimthenet.org/face-scanner-age-estimator-collecting-data-for-advertising" rel="nofollow">Store face scanner age estimator wants to get into collecting data for advertising</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Microsoft tests using ChatGPT to control robots
 - [https://reclaimthenet.org/microsoft-tests-using-chatgpt-to-control-robots](https://reclaimthenet.org/microsoft-tests-using-chatgpt-to-control-robots)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-24 17:36:57+00:00

<a href="https://reclaimthenet.org/microsoft-tests-using-chatgpt-to-control-robots" rel="nofollow" title="Microsoft tests using ChatGPT to control robots"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/air-robot.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Robot arms, drones, and home assistants.</p>
<p>The post <a href="https://reclaimthenet.org/microsoft-tests-using-chatgpt-to-control-robots" rel="nofollow">Microsoft tests using ChatGPT to control robots</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Iceland’s PM says the country is working to counter “hate speech” and “disinformation”
 - [https://reclaimthenet.org/iceland-pm-hate-speech-and-disinformation](https://reclaimthenet.org/iceland-pm-hate-speech-and-disinformation)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-24 16:56:24+00:00

<a href="https://reclaimthenet.org/iceland-pm-hate-speech-and-disinformation" rel="nofollow" title="Iceland&#8217;s PM says the country is working to counter &#8220;hate speech&#8221; and &#8220;disinformation&#8221;"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/iceland-pm.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>While addressing a UN group.</p>
<p>The post <a href="https://reclaimthenet.org/iceland-pm-hate-speech-and-disinformation" rel="nofollow">Iceland&#8217;s PM says the country is working to counter &#8220;hate speech&#8221; and &#8220;disinformation&#8221;</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

