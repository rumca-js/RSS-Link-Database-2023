# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Samsung pozwany za przegrzewający się sprzęt
 - [https://ithardware.pl/aktualnosci/samsung_pozwany_za_przegrzewajacy_sie_sprzet-26010.html](https://ithardware.pl/aktualnosci/samsung_pozwany_za_przegrzewajacy_sie_sprzet-26010.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 22:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/26010_1.jpg" />            Samsung&nbsp;Electronics został pozwany. Nie chodzi tym razem o smartfony a laptopy, kt&oacute;re mają się przegrzewać i w konsekwencji ulegać poważnej awarii. Dokument w tej sprawie trafił już do amerykańskiego sądu.

Samsung mierzy się z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_pozwany_za_przegrzewajacy_sie_sprzet-26010.html">https://ithardware.pl/aktualnosci/samsung_pozwany_za_przegrzewajacy_sie_sprzet-26010.html</a></p>

## Składany smartfon Huawei Mate X3 pozuje na renderach
 - [https://ithardware.pl/aktualnosci/skladany_smartfon_huawei_mate_x3_pozuje_na_renderach-26008.html](https://ithardware.pl/aktualnosci/skladany_smartfon_huawei_mate_x3_pozuje_na_renderach-26008.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 21:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/26008_1.jpg" />            Huawei pracuje nad nowym składanym smartfonem Mate X3, o kt&oacute;rym wiemy coraz więcej. W sieci pojawiły się rendery urządzenia a my wiemy, iż otrzyma aparat peryskopowy kamerę schowaną pod wyświetlacze.

Huawei Mate X3 zaprezentował się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/skladany_smartfon_huawei_mate_x3_pozuje_na_renderach-26008.html">https://ithardware.pl/aktualnosci/skladany_smartfon_huawei_mate_x3_pozuje_na_renderach-26008.html</a></p>

## Wielki powrót mistrzostw świata w podkręcaniu G.SKILL. Pula nagród to aż 40 tysięcy dolarów!
 - [https://ithardware.pl/aktualnosci/wielki_powrot_mistrzostw_swiata_w_podkrecaniu_g_skill_pula_nagrod_to_az_40_tysiecy_dolarow-26007.html](https://ithardware.pl/aktualnosci/wielki_powrot_mistrzostw_swiata_w_podkrecaniu_g_skill_pula_nagrod_to_az_40_tysiecy_dolarow-26007.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 19:53:30+00:00

<img src="https://ithardware.pl/artykuly/min/26007_1.jpg" />            Coroczne mistrzostwa świata w podkręcaniu, organizowane przez firmę G.SKILL, wracają po 3-letniej przerwie!&nbsp;To już 7. edycja tego wydarzenia. Na topową dziewiątkę&nbsp;uczestnik&oacute;w z kwalifikacji online czekać będzie pula 40 tysięcy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wielki_powrot_mistrzostw_swiata_w_podkrecaniu_g_skill_pula_nagrod_to_az_40_tysiecy_dolarow-26007.html">https://ithardware.pl/aktualnosci/wielki_powrot_mistrzostw_swiata_w_podkrecaniu_g_skill_pula_nagrod_to_az_40_tysiecy_dolarow-26007.html</a></p>

## Baldur's Gate 3 z oficjalną datą premiery i wymaganiami sprzętowymi
 - [https://ithardware.pl/aktualnosci/baldur_s_gate_3_z_oficjalna_data_premiery_i_wymaganiami_sprzetowymi-26005.html](https://ithardware.pl/aktualnosci/baldur_s_gate_3_z_oficjalna_data_premiery_i_wymaganiami_sprzetowymi-26005.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 18:22:30+00:00

<img src="https://ithardware.pl/artykuly/min/26005_1.jpg" />            Baldur's Gate 3 zadebiutował na PC we wczesnym dostępie w 2020 roku i na start dostał tylko pierwsze etapy rozgrywki. Deweloperzy od blisko trzech lat rozwijają sw&oacute;j projekt, kt&oacute;ry wreszcie otrzymał datę premiery. Gra pojawi się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/baldur_s_gate_3_z_oficjalna_data_premiery_i_wymaganiami_sprzetowymi-26005.html">https://ithardware.pl/aktualnosci/baldur_s_gate_3_z_oficjalna_data_premiery_i_wymaganiami_sprzetowymi-26005.html</a></p>

## Nastolatek zaatakował pracownicę szkoły, bo zabrała mu Nintendo Switch
 - [https://ithardware.pl/aktualnosci/nastolatek_zaatakowal_pracownice_szkoly_bo_zabrala_mu_nintendo_switch-26004.html](https://ithardware.pl/aktualnosci/nastolatek_zaatakowal_pracownice_szkoly_bo_zabrala_mu_nintendo_switch-26004.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 16:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/26004_1.jpg" />            Niejednokrotnie gry były oskarżane o wywołanie r&oacute;żnych tragedii. Nie inaczej jest w przypadku zdarzenia, do kt&oacute;rego doszło w jednej&nbsp;z amerykańskich szk&oacute;ł. 17-latek zaatakował pracownicę szkoły, bo ta zabrała mu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nastolatek_zaatakowal_pracownice_szkoly_bo_zabrala_mu_nintendo_switch-26004.html">https://ithardware.pl/aktualnosci/nastolatek_zaatakowal_pracownice_szkoly_bo_zabrala_mu_nintendo_switch-26004.html</a></p>

## Lenovo startuje z przedsprzedażą laptopa Lenovo Legion Pro 7 (8. generacji)
 - [https://ithardware.pl/aktualnosci/lenovo_startuje_z_przedsprzedaza_laptopa_lenovo_legion_pro_7_8_generacji-26003.html](https://ithardware.pl/aktualnosci/lenovo_startuje_z_przedsprzedaza_laptopa_lenovo_legion_pro_7_8_generacji-26003.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 15:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26003_1.jpg" />            W piątek 24 lutego o 12:00 ruszyła&nbsp;przedsprzedaż najnowszego Legiona Pro 7 (8. generacji). Producent przygotował specjalną promocję, w ramach kt&oacute;rej Klienci, kt&oacute;rzy zam&oacute;wią komputer w przedsprzedaży, będą mogli...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/lenovo_startuje_z_przedsprzedaza_laptopa_lenovo_legion_pro_7_8_generacji-26003.html">https://ithardware.pl/aktualnosci/lenovo_startuje_z_przedsprzedaza_laptopa_lenovo_legion_pro_7_8_generacji-26003.html</a></p>

## Test pięciu laptopów z GeForce RTX 3060 na pokładzie, czyli jak TGP przekłada się na wydajność
 - [https://ithardware.pl/testyirecenzje/rtx_3060_laptop_tgp_test_opinia-25877.html](https://ithardware.pl/testyirecenzje/rtx_3060_laptop_tgp_test_opinia-25877.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 13:00:01+00:00

<img src="https://ithardware.pl/artykuly/min/25877_1.jpg" />            

Test pięciu laptop&oacute;w z GeForce RTX 3060 na pokładzie, czyli jak TGP przekłada się na wydajność

Wyb&oacute;r laptopa do gier to niełatwa sprawa. Nie dosyć, że gamingowe notebooki przeważnie kosztują krocie, to na dodatek...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/rtx_3060_laptop_tgp_test_opinia-25877.html">https://ithardware.pl/testyirecenzje/rtx_3060_laptop_tgp_test_opinia-25877.html</a></p>

## AMD Ryzen 9 7945HX na równo z flagowym CPU Intela w popularnym benchmarku
 - [https://ithardware.pl/aktualnosci/amd_ryzen_9_7945hx_na_rowno_z_flagowym_cpu_intela_w_popularnym_benchmarku-25998.html](https://ithardware.pl/aktualnosci/amd_ryzen_9_7945hx_na_rowno_z_flagowym_cpu_intela_w_popularnym_benchmarku-25998.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 12:36:01+00:00

<img src="https://ithardware.pl/artykuly/min/25998_1.png" />            Jak wynika z najnowszych przeciek&oacute;w, mobilne procesory AMD z serii Dragon Range nie tylko są dwa razy szybsze od modeli Rembrandt, ale i rywalizują jak r&oacute;wny z r&oacute;wnym z flagową serią Intela HX.&nbsp;&nbsp;

Pierwszy wynik...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ryzen_9_7945hx_na_rowno_z_flagowym_cpu_intela_w_popularnym_benchmarku-25998.html">https://ithardware.pl/aktualnosci/amd_ryzen_9_7945hx_na_rowno_z_flagowym_cpu_intela_w_popularnym_benchmarku-25998.html</a></p>

## Mortal Kombat 12 oficjalnie potwierdzone. Wiemy, na kiedy planowana jest premiera
 - [https://ithardware.pl/aktualnosci/mortal_kombat_12_oficjalnie_potwierdzone_wiemy_na_kiedy_planowana_jest_premiera-25997.html](https://ithardware.pl/aktualnosci/mortal_kombat_12_oficjalnie_potwierdzone_wiemy_na_kiedy_planowana_jest_premiera-25997.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 11:25:01+00:00

<img src="https://ithardware.pl/artykuly/min/25997_1.jpg" />            Mamy świetne wieści dla fan&oacute;w jednej z najpopularniejszych na świecie serii bijatyk, czyli Mortal Kombat. Podczas prezentacji swoich kwartalnych wynik&oacute;w finansowych inwestorom, Warner Bros Discovery ogłosiło nie tylko, że trwają już...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mortal_kombat_12_oficjalnie_potwierdzone_wiemy_na_kiedy_planowana_jest_premiera-25997.html">https://ithardware.pl/aktualnosci/mortal_kombat_12_oficjalnie_potwierdzone_wiemy_na_kiedy_planowana_jest_premiera-25997.html</a></p>

## ONZ: Cenzurowanie „dezinformacji” i „mowy nienawiści” ochroni „wolność słowa”
 - [https://ithardware.pl/aktualnosci/onz_cenzurowanie_dezinformacji_i_mowy_nienawisci_ochroni_wolnosc_slowa-26001.html](https://ithardware.pl/aktualnosci/onz_cenzurowanie_dezinformacji_i_mowy_nienawisci_ochroni_wolnosc_slowa-26001.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 10:40:30+00:00

<img src="https://ithardware.pl/artykuly/min/26001_1.jpg" />            ONZ otwarcie przyjmuje program mobilizacji do walki z&nbsp;mową nienawiści i dezinformacją w internecie. Jedna z agencji organizacji - UNESCO &ndash; kt&oacute;ra ma promować pok&oacute;j i bezpieczeństwo na świecie poprzez międzynarodową...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/onz_cenzurowanie_dezinformacji_i_mowy_nienawisci_ochroni_wolnosc_slowa-26001.html">https://ithardware.pl/aktualnosci/onz_cenzurowanie_dezinformacji_i_mowy_nienawisci_ochroni_wolnosc_slowa-26001.html</a></p>

## Corsair wprowadza do sprzedaży drewniane panele na obudowy
 - [https://ithardware.pl/aktualnosci/corsair_wprowadza_do_sprzedazy_drewniane_panele_na_obudowy-25996.html](https://ithardware.pl/aktualnosci/corsair_wprowadza_do_sprzedazy_drewniane_panele_na_obudowy-25996.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 10:12:01+00:00

<img src="https://ithardware.pl/artykuly/min/25996_1.jpg" />            Wybierając nową obudowę do naszego PC celujemy przeważnie w panele przednie wykonane z hartowanego szkła, stawiając na wrażenie estetyczne lub siatkę, kt&oacute;ra ułatwia przepływ powietrza, a tym samym poprawia chłodzenie. Corsair oferuje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/corsair_wprowadza_do_sprzedazy_drewniane_panele_na_obudowy-25996.html">https://ithardware.pl/aktualnosci/corsair_wprowadza_do_sprzedazy_drewniane_panele_na_obudowy-25996.html</a></p>

## Galax prezentuje superszybkie pamięci DDR5 z serii HOF Pro
 - [https://ithardware.pl/aktualnosci/galax_prezentuje_superszybkie_pamieci_ddr5_z_serii_hof_pro-25995.html](https://ithardware.pl/aktualnosci/galax_prezentuje_superszybkie_pamieci_ddr5_z_serii_hof_pro-25995.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 09:35:01+00:00

<img src="https://ithardware.pl/artykuly/min/25995_1.jpg" />            GALAX właśnie zapowiedziała moduły pamięci DDR5-8000 HOF Pro dla platform Intel 700. Zupełnie nowa seria HOF PRO skierowana będzie do wymagających użytkownik&oacute;w i ma obsługiwać profile XMP 7200, 7600 i 8000 MT/s.

Nowy zestaw jest...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/galax_prezentuje_superszybkie_pamieci_ddr5_z_serii_hof_pro-25995.html">https://ithardware.pl/aktualnosci/galax_prezentuje_superszybkie_pamieci_ddr5_z_serii_hof_pro-25995.html</a></p>

## Netflix obniża ceny w 30 krajach. Co z abonamentem w Polsce?
 - [https://ithardware.pl/aktualnosci/netflix_obniza_ceny_w_30_krajach_co_z_abonamentem_w_polsce-25994.html](https://ithardware.pl/aktualnosci/netflix_obniza_ceny_w_30_krajach_co_z_abonamentem_w_polsce-25994.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 08:19:00+00:00

<img src="https://ithardware.pl/artykuly/min/25994_1.jpg" />            A to niespodzianka. Netflix ostatnio kojarzy nam się raczej z podwyżkami cen i wprowadzaniem dodatkowych opłat, tymczasem usługa tanieje w ponad 30 krajach. Najwyraźniej firma zaczyna mocniej odczuwać coraz większą i ostrzejszą konkurencję w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/netflix_obniza_ceny_w_30_krajach_co_z_abonamentem_w_polsce-25994.html">https://ithardware.pl/aktualnosci/netflix_obniza_ceny_w_30_krajach_co_z_abonamentem_w_polsce-25994.html</a></p>

## Hogwarts Legacy z kapitalnym wynikiem sprzedaży i nowymi rekordami
 - [https://ithardware.pl/aktualnosci/hogwarts_legacy_z_kapitalnym_wynikiem_sprzedazy_i_nowymi_rekordami-25993.html](https://ithardware.pl/aktualnosci/hogwarts_legacy_z_kapitalnym_wynikiem_sprzedazy_i_nowymi_rekordami-25993.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 07:44:11+00:00

<img src="https://ithardware.pl/artykuly/min/25993_1.jpg" />            Hogwarts Legacy, gra stworzona przez Avalanche Software i wydana przez Warner Bros. Games, osadzona w czarodziejskim uniwersum Harry'ego Pottera, sprzedała się już w ponad 12 milionach egzemplarzy. Osiągnęła ten niezwykle imponujący wynik...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hogwarts_legacy_z_kapitalnym_wynikiem_sprzedazy_i_nowymi_rekordami-25993.html">https://ithardware.pl/aktualnosci/hogwarts_legacy_z_kapitalnym_wynikiem_sprzedazy_i_nowymi_rekordami-25993.html</a></p>

## Suicide Squad: Kill the Justice League nie zachwyca na rozgrywce. Gra idzie w kierunku usługi
 - [https://ithardware.pl/aktualnosci/suicide_squad_kill_the_justice_league_nie_zachwyca_na_rozgrywce_gra_idzie_w_kierunku_uslugi-25992.html](https://ithardware.pl/aktualnosci/suicide_squad_kill_the_justice_league_nie_zachwyca_na_rozgrywce_gra_idzie_w_kierunku_uslugi-25992.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-24 07:21:52+00:00

<img src="https://ithardware.pl/artykuly/min/25992_1.jpg" />            Rocksteady pojawiło się na wczorajszym pokazie State of Play od PlayStation z prezentacją rozgrywki w trybie wsp&oacute;łpracy w Suicide Squad: Kill the Justice League, czyli jednego z najbardziej wyczekiwanych tytuł&oacute;w tego roku.&nbsp;

W...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/suicide_squad_kill_the_justice_league_nie_zachwyca_na_rozgrywce_gra_idzie_w_kierunku_uslugi-25992.html">https://ithardware.pl/aktualnosci/suicide_squad_kill_the_justice_league_nie_zachwyca_na_rozgrywce_gra_idzie_w_kierunku_uslugi-25992.html</a></p>

