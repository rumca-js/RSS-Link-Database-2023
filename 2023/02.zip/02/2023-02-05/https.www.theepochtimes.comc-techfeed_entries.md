# Source Epoch Times Tech, Source URL:https://www.theepochtimes.com/c-tech/feed/, Source language: en-US

## Italy Suffers Widespread Internet Outages
 - [https://www.theepochtimes.com/italy-suffers-widespread-internet-outages_5035255.html](https://www.theepochtimes.com/italy-suffers-widespread-internet-outages_5035255.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-02-05 17:51:47+00:00
 - user: None

The TIM logo at its headquarters in Rome on Nov. 22, 2021. (Yara Nardi/Reuters)
