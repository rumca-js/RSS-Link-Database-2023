# Source Polsat News, Source URL:https://www.polsatnews.pl/rss/swiat.xml, Source language: pl-PL

## Papież Franciszek jest gotowy do spotkania z Wołodymyrem Zełenskim i Władimirem Putinem
 - [https://www.polsatnews.pl/wiadomosc/2023-02-05/papiez-franciszek-jest-gotowy-do-spotkania-z-wolodymyrem-zelenskim-i-wladimirem-putinem/](https://www.polsatnews.pl/wiadomosc/2023-02-05/papiez-franciszek-jest-gotowy-do-spotkania-z-wolodymyrem-zelenskim-i-wladimirem-putinem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-05 21:27:00+00:00
 - user: None

- Jestem otwarty na spotkanie z oboma prezydentami - zadeklarował w niedzielę w rozmowie z dziennikarzami papież Franciszek cytowany przez Corriere della Sera. Te słowa były odpowiedzią na pytanie o możliwość spotkania z Władimirem Putinem w celu omówienia pokoju.

## Ołeksij Reznikow przestanie być ministrem obrony Ukrainy
 - [https://www.polsatnews.pl/wiadomosc/2023-02-05/oleksij-reznikow-przestanie-byc-ministrem-obrony-ukrainy/](https://www.polsatnews.pl/wiadomosc/2023-02-05/oleksij-reznikow-przestanie-byc-ministrem-obrony-ukrainy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-05 20:38:00+00:00
 - user: None

Minister obrony Ukrainy Ołeksij Reznikow, pod presją skandalu korupcyjnego w swoim ministerstwie, ma zostać przeniesiony na inne stanowisko rządowe, przekazał w niedzielę wieczorem David Arakhamia. Słowa szefa bloku parlamentarnego prezydenta Wołodymyra Zełenskiego cytuje Reuters.

## Jeden samolot lądował, inny startował z tego samego pasa. Szokująca pomyłka w USA
 - [https://www.polsatnews.pl/wiadomosc/2023-02-05/jeden-samolot-ladowal-inny-startowal-z-tego-samego-pasa-szokujaca-pomylka-w-usa/](https://www.polsatnews.pl/wiadomosc/2023-02-05/jeden-samolot-ladowal-inny-startowal-z-tego-samego-pasa-szokujaca-pomylka-w-usa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-05 18:55:00+00:00
 - user: None

Pilot samolotu towarowego FedEx podczas lądowania na lotnisku Austin-Bergstrom w USA musiał w ostatniej chwili poderwać maszynę, bo drugi samolot otrzymał zgodę na odlot z tego samego pasa - podaje abcnews.go.com. Trwa dochodzenie mające wyjaśnić pomyłkę, która o mały włos nie doprowadziła do katastrofy.

## Rosyjski najemnik ciężko ranny. Wcześniej wygrażał trzymając ludzką czaszkę
 - [https://www.polsatnews.pl/wiadomosc/2023-02-05/rosyjski-najemnik-ciezko-ranny-wczesniej-wygrazal-trzymajac-ludzka-czaszke/](https://www.polsatnews.pl/wiadomosc/2023-02-05/rosyjski-najemnik-ciezko-ranny-wczesniej-wygrazal-trzymajac-ludzka-czaszke/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-05 17:15:00+00:00
 - user: None

Rosyjski najemnik Igor Manguszew został ciężko ranny w obwodzie ługańskim. Głośno zrobiło się o nim w sierpniu zeszłego roku, gdy wystąpił na scenie z ludzką czaszką i nawoływał do zabijania Ukraińców.

## USA: Zabiła przyjaciółkę i zabrała jej dziecko. Usłyszała wyrok
 - [https://www.polsatnews.pl/wiadomosc/2023-02-05/usa-zabila-przyjaciolke-i-zabrala-jej-dziecko-uslyszala-wyrok/](https://www.polsatnews.pl/wiadomosc/2023-02-05/usa-zabila-przyjaciolke-i-zabrala-jej-dziecko-uslyszala-wyrok/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-05 12:49:00+00:00
 - user: None

Kobieta z Teksasu oskarżona o zabicie swojej przyjaciółki i porwanie jej dziecka została skazana na 55 lat więzienia. 37-latka przyznała się do morderstwa.

## Media: Wołodymyr Zełenski odwoła ministra obrony Ołeksija Reznikowa
 - [https://www.polsatnews.pl/wiadomosc/2023-02-05/media-wolodymyr-zelenski-odwola-ministra-obrony-oleksija-reznikowa/](https://www.polsatnews.pl/wiadomosc/2023-02-05/media-wolodymyr-zelenski-odwola-ministra-obrony-oleksija-reznikowa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-05 11:29:00+00:00
 - user: None

Minister obrony Ukrainy Ołeksij Reznikow prawdopodobnie zostanie odwołany ze stanowiska w przyszłym tygodniu - poinformował w niedzielę ukraiński serwis informacyjny Ukrainska Prawda, powołując się na źródła rządowe i wojskowe.

## Wojna na Ukrainie. Scholz: Władimir Putin w rozmowach telefonicznych nie groził ani mi, ani Niemcom
 - [https://www.polsatnews.pl/wiadomosc/2023-02-05/wojna-na-ukrainie-scholz-wladimir-putin-w-rozmowach-telefonicznych-nie-grozil-ani-mi-ani-niemcom/](https://www.polsatnews.pl/wiadomosc/2023-02-05/wojna-na-ukrainie-scholz-wladimir-putin-w-rozmowach-telefonicznych-nie-grozil-ani-mi-ani-niemcom/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-05 08:04:00+00:00
 - user: None

Prezydent Rosji Władimir Putin w rozmowach telefonicznych nie groził ani mi, ani Niemcom – powiedział kanclerz Niemiec Olaf Scholz w wywiadzie dla gazety Bild am Sonntag.

## Wojna w Ukrainie. Zełenski odbiera obywatelstwo politykom. Za wspieranie Rosjan
 - [https://www.polsatnews.pl/wiadomosc/2023-02-05/wojna-w-ukrainie-zelenski-odbiera-obywatelstwo-politykom-za-wspieranie-rosjan/](https://www.polsatnews.pl/wiadomosc/2023-02-05/wojna-w-ukrainie-zelenski-odbiera-obywatelstwo-politykom-za-wspieranie-rosjan/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-05 06:16:00+00:00
 - user: None

Prezydent Ukrainy odebrał obywatelstwo byłym ministrom: spraw wewnętrznych, finansów oraz edukacji i nauki, byłemu szefowi administracji prezydenta i byłemu szefowi Służby Bezpieczeństwa Ukrainy. Maja oni obywatelstwo Rosji. Podpisałem odpowiednie dokumenty, aby zrobić kolejny krok w celu ochrony i oczyszczania naszego państwa z osób po stronie agresora - powiedział Wołodymyr Zełenski.

## Chile. Co najmniej 23 ofiary pożarów lasów. Stan klęski żywiołowej
 - [https://www.polsatnews.pl/wiadomosc/2023-02-05/chile-co-najmniej-23-ofiary-pozarow-lasow-stan-kleski-zywiolowej/](https://www.polsatnews.pl/wiadomosc/2023-02-05/chile-co-najmniej-23-ofiary-pozarow-lasow-stan-kleski-zywiolowej/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-02-05 06:04:00+00:00
 - user: None

Liczne pożary lasów w Chile zmusiły władze do wprowadzenia stanu klęski żywiołowej, by ułatwić działania ratownicze. Dotąd ogień spowodował śmierć co najmniej 23 osób - informuje Reuters. Ewakuowano ponad tysiąc osób, podczas gdy rannych było do soboty co najmniej 979 ludzi. Najtrudniejsza sytuacja panuje w regionach Araucania, Biobio i Buble w centralnej części południowoamerykańskiego państwa.
