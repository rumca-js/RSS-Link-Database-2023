# Source Thrillseeker, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, Source language: en-US

## IT GOT EVEN WORSE.
 - [https://www.youtube.com/watch?v=aj6UWDMRX54](https://www.youtube.com/watch?v=aj6UWDMRX54)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2023-02-05 20:01:12+00:00
 - user: None

So the Echo VR situation has gotten worse; Meta announced in an AMA that they absolutely will NOT be doing anything to keep Echo around. It will be removed from Quest 2 and PCVR Aug 1st no matter what.. So here is the response video to Andrew Bosworth's AMA. 

This is where VR is going.

There IS actually a way to maybe save Echo. All we'll need is to emulate the servers; Here is the link:
https://www.vegapatch.ml/articles/EVR


Not that this will do anything.. but here's a change petition: 
https://www.change.org/p/save-echo-vr...

GAMES AS A SERVICE IS A FRAUD:
https://youtu.be/tUAX0gnZ3Nw

Here are my links to join my discord server to chat and have an awesome VR community- or if you'd want to support my channel:
My links:
Support Content Like this on Patreon:
https://www.patreon.com/Thrillseeker
Discord: 
https://discord.gg/thrill
Twitter:
https://twitter.com/Thrilluwu
Outro Music:
https://www.youtube.com/watch?v=u6Jwg...

“Game that Changed VR Forever” montage video:

https://youtu.be/rHHn6cWtD0o
