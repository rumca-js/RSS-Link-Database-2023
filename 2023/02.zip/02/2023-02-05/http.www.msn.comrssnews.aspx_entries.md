# Source MSN, Source URL:http://www.msn.com/rss/news.aspx, Source language: en-US

## Epsom College head found dead with husband and daughter, 7
 - [http://www.msn.com/en-us/news/world/epsom-college-head-found-dead-with-husband-and-daughter-7/ar-AA178IAX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/epsom-college-head-found-dead-with-husband-and-daughter-7/ar-AA178IAX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 23:52:22.753996+00:00
 - user: None



## Skull found in Alaska linked to New York man nearly 47 years after he was likely mauled by bear
 - [http://www.msn.com/en-us/news/crime/skull-found-in-alaska-linked-to-new-york-man-nearly-47-years-after-he-was-likely-mauled-by-bear/ar-AA178PA2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/skull-found-in-alaska-linked-to-new-york-man-nearly-47-years-after-he-was-likely-mauled-by-bear/ar-AA178PA2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 23:52:22.747165+00:00
 - user: None



## Florida cat given away by owner for being 'too affectionate' finds new home
 - [http://www.msn.com/en-us/news/us/florida-cat-given-away-by-owner-for-being-too-affectionate-finds-new-home/ar-AA178RZm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/florida-cat-given-away-by-owner-for-being-too-affectionate-finds-new-home/ar-AA178RZm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 23:52:22.738206+00:00
 - user: None



## WSJ Opinion: America's Greatest Puzzle Is Its Economy
 - [http://www.msn.com/en-us/news/offbeat/wsj-opinion-america-s-greatest-puzzle-is-its-economy/vi-AA178Sky?srcref=rss](http://www.msn.com/en-us/news/offbeat/wsj-opinion-america-s-greatest-puzzle-is-its-economy/vi-AA178Sky?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 23:52:22.729449+00:00
 - user: None



## Cory Booker in talks with GOP Sens. Tim Scott, Lindsey Graham on police reform deal
 - [http://www.msn.com/en-us/news/politics/cory-booker-in-talks-with-gop-sens-tim-scott-lindsey-graham-on-police-reform-deal/ar-AA178N6N?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/cory-booker-in-talks-with-gop-sens-tim-scott-lindsey-graham-on-police-reform-deal/ar-AA178N6N?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 23:52:22.721701+00:00
 - user: None



## Ukraine to remove defense minister ahead of expected Russian offensive: lawmaker
 - [http://www.msn.com/en-us/news/politics/ukraine-to-remove-defense-minister-ahead-of-expected-russian-offensive-lawmaker/ar-AA178jN5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ukraine-to-remove-defense-minister-ahead-of-expected-russian-offensive-lawmaker/ar-AA178jN5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 23:52:22.713948+00:00
 - user: None



## A Cheesemonger's Guide to Finding the Best Cheese for Cheap
 - [http://www.msn.com/en-us/news/technology/a-cheesemonger-s-guide-to-finding-the-best-cheese-for-cheap/ar-AA16WBGU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/a-cheesemonger-s-guide-to-finding-the-best-cheese-for-cheap/ar-AA16WBGU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 22:52:16.607203+00:00
 - user: None



## Ukraine’s Defense Minister to Be Replaced, Top Lawmaker Says
 - [http://www.msn.com/en-us/news/world/ukraine-s-defense-minister-to-be-replaced-top-lawmaker-says/ar-AA178yOY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-s-defense-minister-to-be-replaced-top-lawmaker-says/ar-AA178yOY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 22:52:16.599900+00:00
 - user: None



## Cubans respond with zeal to new U.S. migration policy
 - [http://www.msn.com/en-us/news/world/cubans-respond-with-zeal-to-new-u-s-migration-policy/ar-AA178znU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/cubans-respond-with-zeal-to-new-u-s-migration-policy/ar-AA178znU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 22:52:16.592646+00:00
 - user: None



## NBC's Chuck Todd asks Pete Buttigieg why Biden's accomplishments aren't being celebrated by the public
 - [http://www.msn.com/en-us/news/politics/nbc-s-chuck-todd-asks-pete-buttigieg-why-biden-s-accomplishments-aren-t-being-celebrated-by-the-public/ar-AA178G13?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/nbc-s-chuck-todd-asks-pete-buttigieg-why-biden-s-accomplishments-aren-t-being-celebrated-by-the-public/ar-AA178G13?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 22:52:16.583411+00:00
 - user: None



## Arrest made in stolen yacht rescue, ‘Goonies’ fish incident
 - [http://www.msn.com/en-us/news/crime/arrest-made-in-stolen-yacht-rescue-goonies-fish-incident/ar-AA178Bvu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/arrest-made-in-stolen-yacht-rescue-goonies-fish-incident/ar-AA178Bvu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 22:52:16.576037+00:00
 - user: None



## Cotton suggests Biden administration delayed shooting down balloon to ‘salvage’ Blinken trip to China
 - [http://www.msn.com/en-us/news/politics/cotton-suggests-biden-administration-delayed-shooting-down-balloon-to-salvage-blinken-trip-to-china/ar-AA178MMi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/cotton-suggests-biden-administration-delayed-shooting-down-balloon-to-salvage-blinken-trip-to-china/ar-AA178MMi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 22:52:16.566008+00:00
 - user: None



## Trump officials deny Chinese spy balloons flew above U.S. on their watch
 - [http://www.msn.com/en-us/news/us/trump-officials-deny-chinese-spy-balloons-flew-above-u-s-on-their-watch/ar-AA178Ixz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/trump-officials-deny-chinese-spy-balloons-flew-above-u-s-on-their-watch/ar-AA178Ixz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 22:52:16.557714+00:00
 - user: None



## Mike Turner says Congress will receive Biden, Pence, Trump classified docs assessment
 - [http://www.msn.com/en-us/news/politics/mike-turner-says-congress-will-receive-biden-pence-trump-classified-docs-assessment/ar-AA178mcZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mike-turner-says-congress-will-receive-biden-pence-trump-classified-docs-assessment/ar-AA178mcZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 21:52:21.029988+00:00
 - user: None



## Ukraine’s Defense Minister Will Be Replaced, Top Lawmaker Says
 - [http://www.msn.com/en-us/news/world/ukraine-s-defense-minister-will-be-replaced-top-lawmaker-says/ar-AA178yOY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-s-defense-minister-will-be-replaced-top-lawmaker-says/ar-AA178yOY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 21:52:21.022426+00:00
 - user: None



## Republicans struggle to get their act together for a debt limit deal
 - [http://www.msn.com/en-us/news/politics/republicans-struggle-to-get-their-act-together-for-a-debt-limit-deal/ar-AA178j1J?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-struggle-to-get-their-act-together-for-a-debt-limit-deal/ar-AA178j1J?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 21:52:21.014818+00:00
 - user: None



## Jill Biden to present Grammy award Sunday night
 - [http://www.msn.com/en-us/news/us/jill-biden-to-present-grammy-award-sunday-night/ar-AA178rBd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jill-biden-to-present-grammy-award-sunday-night/ar-AA178rBd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 21:52:21.005998+00:00
 - user: None



## Ride at Iowa amusement park where boy died will never reopen
 - [http://www.msn.com/en-us/news/us/ride-at-iowa-amusement-park-where-boy-died-will-never-reopen/ar-AA178e3p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/ride-at-iowa-amusement-park-where-boy-died-will-never-reopen/ar-AA178e3p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 21:52:20.998059+00:00
 - user: None



## Chris Christie says Biden is 'not capable of running a traditional American race' in 2024: 'He's old. He's boring.'
 - [http://www.msn.com/en-us/news/politics/chris-christie-says-biden-is-not-capable-of-running-a-traditional-american-race-in-2024-he-s-old-he-s-boring/ar-AA178B9E?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/chris-christie-says-biden-is-not-capable-of-running-a-traditional-american-race-in-2024-he-s-old-he-s-boring/ar-AA178B9E?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 21:52:20.987359+00:00
 - user: None



## Liberals falsely attack DeSantis using Associated Press fact-check that vindicates him: 'Authoritarianism'
 - [http://www.msn.com/en-us/news/politics/liberals-falsely-attack-desantis-using-associated-press-fact-check-that-vindicates-him-authoritarianism/ar-AA178w30?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/liberals-falsely-attack-desantis-using-associated-press-fact-check-that-vindicates-him-authoritarianism/ar-AA178w30?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 21:52:20.977990+00:00
 - user: None



## Biden’s botched response to China’s spy balloon was a national security ‘blunder’ of ‘incalculable damage’
 - [http://www.msn.com/en-us/news/world/biden-s-botched-response-to-china-s-spy-balloon-was-a-national-security-blunder-of-incalculable-damage/ar-AA178y81?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/biden-s-botched-response-to-china-s-spy-balloon-was-a-national-security-blunder-of-incalculable-damage/ar-AA178y81?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 20:52:16.466881+00:00
 - user: None



## US-China Relations: A Long History of Balloons, Bombs and Drones
 - [http://www.msn.com/en-us/news/world/us-china-relations-a-long-history-of-balloons-bombs-and-drones/ar-AA178vO5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-china-relations-a-long-history-of-balloons-bombs-and-drones/ar-AA178vO5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 20:52:16.459678+00:00
 - user: None



## Ted Cruz says Biden shot Chinese balloon 'because it made it into the news'
 - [http://www.msn.com/en-us/news/politics/ted-cruz-says-biden-shot-chinese-balloon-because-it-made-it-into-the-news/ar-AA178yr2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ted-cruz-says-biden-shot-chinese-balloon-because-it-made-it-into-the-news/ar-AA178yr2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 20:52:16.451672+00:00
 - user: None



## Pope, Anglican and Presbyterian leaders denounce anti-gay laws
 - [http://www.msn.com/en-us/news/world/pope-anglican-and-presbyterian-leaders-denounce-anti-gay-laws/ar-AA178tRr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pope-anglican-and-presbyterian-leaders-denounce-anti-gay-laws/ar-AA178tRr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 20:52:16.442628+00:00
 - user: None



## What to know about education savings accounts, the school choice measure making waves in states
 - [http://www.msn.com/en-us/news/us/what-to-know-about-education-savings-accounts-the-school-choice-measure-making-waves-in-states/ar-AA178ysh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-to-know-about-education-savings-accounts-the-school-choice-measure-making-waves-in-states/ar-AA178ysh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 20:52:16.435275+00:00
 - user: None



## Ukraine's defense minister says its military has received everything on its 'wish list to Santa' as Western allies supply weapons, tanks and warplanes: report
 - [http://www.msn.com/en-us/news/world/ukraine-s-defense-minister-says-its-military-has-received-everything-on-its-wish-list-to-santa-as-western-allies-supply-weapons-tanks-and-warplanes-report/ar-AA178ATt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-s-defense-minister-says-its-military-has-received-everything-on-its-wish-list-to-santa-as-western-allies-supply-weapons-tanks-and-warplanes-report/ar-AA178ATt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 20:52:16.426565+00:00
 - user: None



## Schumer: All senators to receive briefing on spy balloon Feb. 15
 - [http://www.msn.com/en-us/news/politics/schumer-all-senators-to-receive-briefing-on-spy-balloon-feb-15/ar-AA178yty?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/schumer-all-senators-to-receive-briefing-on-spy-balloon-feb-15/ar-AA178yty?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 20:52:16.418481+00:00
 - user: None



## Russia-Ukraine live updates: Netanyahu considers 'Iron Dome' for Ukraine
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-netanyahu-considers-iron-dome-for-ukraine/ar-AA11dhnl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-netanyahu-considers-iron-dome-for-ukraine/ar-AA11dhnl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 20:52:16.410528+00:00
 - user: None



## How this laughable sci-fi flick embarrassed Hollywood into doing better science
 - [http://www.msn.com/en-us/news/technology/how-this-laughable-sci-fi-flick-embarrassed-hollywood-into-doing-better-science/ar-AA178AhH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-this-laughable-sci-fi-flick-embarrassed-hollywood-into-doing-better-science/ar-AA178AhH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 19:52:21.660419+00:00
 - user: None



## Americans’ views of US economy tick up: poll
 - [http://www.msn.com/en-us/news/politics/americans-views-of-us-economy-tick-up-poll/ar-AA178g5Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/americans-views-of-us-economy-tick-up-poll/ar-AA178g5Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 19:52:21.653190+00:00
 - user: None



## US officials offer Congress briefing on Trump documents
 - [http://www.msn.com/en-us/news/politics/us-officials-offer-congress-briefing-on-trump-documents/ar-AA178xGJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/us-officials-offer-congress-briefing-on-trump-documents/ar-AA178xGJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 19:52:21.645977+00:00
 - user: None



## Not All Windows 11 Default Settings Are Worth Keeping
 - [http://www.msn.com/en-us/news/technology/not-all-windows-11-default-settings-are-worth-keeping/ar-AA16Z4pR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/not-all-windows-11-default-settings-are-worth-keeping/ar-AA16Z4pR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 19:52:21.637426+00:00
 - user: None



## Bickering over China balloon's intentions, Biden's actions
 - [http://www.msn.com/en-us/news/world/bickering-over-china-balloon-s-intentions-biden-s-actions/ar-AA178AmZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/bickering-over-china-balloon-s-intentions-biden-s-actions/ar-AA178AmZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 19:52:21.629638+00:00
 - user: None



## House Republicans consider resolution to condemn Biden over Chinese balloon: Report
 - [http://www.msn.com/en-us/news/world/house-republicans-consider-resolution-to-condemn-biden-over-chinese-balloon-report/ar-AA178FeJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/house-republicans-consider-resolution-to-condemn-biden-over-chinese-balloon-report/ar-AA178FeJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 19:52:21.621790+00:00
 - user: None



## Navy divers working to recover China spy balloon debris with Coast Guard, Navy ships on site
 - [http://www.msn.com/en-us/news/us/navy-divers-working-to-recover-china-spy-balloon-debris-with-coast-guard-navy-ships-on-site/ar-AA178g6c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/navy-divers-working-to-recover-china-spy-balloon-debris-with-coast-guard-navy-ships-on-site/ar-AA178g6c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 19:52:21.612118+00:00
 - user: None



## Pope, Anglican, Presbyterian leaders denounce anti-gay laws
 - [http://www.msn.com/en-us/news/world/pope-anglican-presbyterian-leaders-denounce-anti-gay-laws/ar-AA1784bA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pope-anglican-presbyterian-leaders-denounce-anti-gay-laws/ar-AA1784bA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 18:52:20.769005+00:00
 - user: None



## Pete Buttigieg Deflects When Asked if He Wants Joe Biden to Run Again
 - [http://www.msn.com/en-us/news/politics/pete-buttigieg-deflects-when-asked-if-he-wants-joe-biden-to-run-again/ar-AA178i8O?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pete-buttigieg-deflects-when-asked-if-he-wants-joe-biden-to-run-again/ar-AA178i8O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 18:52:20.761803+00:00
 - user: None



## GOP Rep. Mike Turner said Biden admin lacked 'urgency' in addressing Chinese balloon, which 'completed its mission'
 - [http://www.msn.com/en-us/news/politics/gop-rep-mike-turner-said-biden-admin-lacked-urgency-in-addressing-chinese-balloon-which-completed-its-mission/ar-AA178Hh1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-rep-mike-turner-said-biden-admin-lacked-urgency-in-addressing-chinese-balloon-which-completed-its-mission/ar-AA178Hh1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 18:52:20.752662+00:00
 - user: None



## Most Americans in new survey say police reforms necessary
 - [http://www.msn.com/en-us/news/politics/most-americans-in-new-survey-say-police-reforms-necessary/ar-AA178zYJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/most-americans-in-new-survey-say-police-reforms-necessary/ar-AA178zYJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 18:52:20.745418+00:00
 - user: None



## School food vendor apologizes for 'inexcusable' Black History Month menu, and it's not the first time
 - [http://www.msn.com/en-us/news/us/school-food-vendor-apologizes-for-inexcusable-black-history-month-menu-and-it-s-not-the-first-time/ar-AA178xnX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/school-food-vendor-apologizes-for-inexcusable-black-history-month-menu-and-it-s-not-the-first-time/ar-AA178xnX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 18:52:20.737508+00:00
 - user: None



## US searches sea for China balloon wreckage
 - [http://www.msn.com/en-us/news/world/us-searches-sea-for-china-balloon-wreckage/ar-AA178ibd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-searches-sea-for-china-balloon-wreckage/ar-AA178ibd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 18:52:20.729371+00:00
 - user: None



## New Hampshire Gov. Chris Sununu 'definitely thinking about' 2024 presidential run
 - [http://www.msn.com/en-us/news/politics/new-hampshire-gov-chris-sununu-definitely-thinking-about-2024-presidential-run/ar-AA178pee?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/new-hampshire-gov-chris-sununu-definitely-thinking-about-2024-presidential-run/ar-AA178pee?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 18:52:20.719914+00:00
 - user: None



## Maria Bartiromo breaks down CCP espionage with Sen. Rand Paul, Rep. Mike Gallagher, former DNI John Ratcliffe
 - [http://www.msn.com/en-us/news/world/maria-bartiromo-breaks-down-ccp-espionage-with-sen-rand-paul-rep-mike-gallagher-former-dni-john-ratcliffe/ar-AA178HrW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/maria-bartiromo-breaks-down-ccp-espionage-with-sen-rand-paul-rep-mike-gallagher-former-dni-john-ratcliffe/ar-AA178HrW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 18:52:20.711566+00:00
 - user: None



## Booker: TikTok working with US intelligence to ensure China cannot use platform for spying
 - [http://www.msn.com/en-us/news/politics/booker-tiktok-working-with-us-intelligence-to-ensure-china-cannot-use-platform-for-spying/ar-AA178oS8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/booker-tiktok-working-with-us-intelligence-to-ensure-china-cannot-use-platform-for-spying/ar-AA178oS8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 17:52:15.643887+00:00
 - user: None



## Rep. Mike Turner says Biden administration "lacks urgency" after Chinese spy balloon fiasco
 - [http://www.msn.com/en-us/news/politics/rep-mike-turner-says-biden-administration-lacks-urgency-after-chinese-spy-balloon-fiasco/ar-AA178uRs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-mike-turner-says-biden-administration-lacks-urgency-after-chinese-spy-balloon-fiasco/ar-AA178uRs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 17:52:15.633889+00:00
 - user: None



## The Institutional Arsonist Turns on His Own Party
 - [http://www.msn.com/en-us/news/politics/the-institutional-arsonist-turns-on-his-own-party/ar-AA178uQ0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-institutional-arsonist-turns-on-his-own-party/ar-AA178uQ0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 17:52:15.626598+00:00
 - user: None



## Soup Recall: See if You're Affected by Rao's Labeling Mishap
 - [http://www.msn.com/en-us/news/technology/soup-recall-see-if-you-re-affected-by-rao-s-labeling-mishap/ar-AA171Ysy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/soup-recall-see-if-you-re-affected-by-rao-s-labeling-mishap/ar-AA171Ysy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 17:52:15.619454+00:00
 - user: None



## Downed spy balloon leads to rise in diplomatic tensions between U.S. and China
 - [http://www.msn.com/en-us/news/world/downed-spy-balloon-leads-to-rise-in-diplomatic-tensions-between-u-s-and-china/ar-AA178hWa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/downed-spy-balloon-leads-to-rise-in-diplomatic-tensions-between-u-s-and-china/ar-AA178hWa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 17:52:15.611772+00:00
 - user: None



## Russia-Ukraine live updates: American volunteer medic killed in Ukraine
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-american-volunteer-medic-killed-in-ukraine/ar-AA11dhnl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-american-volunteer-medic-killed-in-ukraine/ar-AA11dhnl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 17:52:15.601100+00:00
 - user: None



## Koch network looking away from Trump in GOP presidential primary
 - [http://www.msn.com/en-us/news/politics/koch-network-looking-away-from-trump-in-gop-presidential-primary/ar-AA178wW5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/koch-network-looking-away-from-trump-in-gop-presidential-primary/ar-AA178wW5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 17:52:15.591121+00:00
 - user: None



## Pieces of the shot-down Chinese spy balloon are expected to wash up near North Carolina and local police are warning residents not to touch it
 - [http://www.msn.com/en-us/news/us/pieces-of-the-shot-down-chinese-spy-balloon-are-expected-to-wash-up-near-north-carolina-and-local-police-are-warning-residents-not-to-touch-it/ar-AA178zsI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/pieces-of-the-shot-down-chinese-spy-balloon-are-expected-to-wash-up-near-north-carolina-and-local-police-are-warning-residents-not-to-touch-it/ar-AA178zsI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 17:52:15.582446+00:00
 - user: None



## Donald Trump Tries to Deny That Spy Balloons Also Flew Over U.S. During His Presidency
 - [http://www.msn.com/en-us/news/politics/donald-trump-tries-to-deny-that-spy-balloons-also-flew-over-u-s-during-his-presidency/ar-AA178nXI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donald-trump-tries-to-deny-that-spy-balloons-also-flew-over-u-s-during-his-presidency/ar-AA178nXI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 16:52:13.532539+00:00
 - user: None



## Cubans respond with zeal to new US migration policy
 - [http://www.msn.com/en-us/news/world/cubans-respond-with-zeal-to-new-us-migration-policy/ar-AA177Tos?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/cubans-respond-with-zeal-to-new-us-migration-policy/ar-AA177Tos?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 16:52:13.525283+00:00
 - user: None



## China 'strongly disapproves of' US shooting down spy balloon, dangles retaliation
 - [http://www.msn.com/en-us/news/world/china-strongly-disapproves-of-us-shooting-down-spy-balloon-dangles-retaliation/ar-AA178pSb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-strongly-disapproves-of-us-shooting-down-spy-balloon-dangles-retaliation/ar-AA178pSb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 16:52:13.518196+00:00
 - user: None



## Fisherman dies after falling overboard in County Donegal
 - [http://www.msn.com/en-us/news/world/fisherman-dies-after-falling-overboard-in-county-donegal/ar-AA177Tt3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fisherman-dies-after-falling-overboard-in-county-donegal/ar-AA177Tt3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 16:52:13.510800+00:00
 - user: None



## Elon Musk says bots making 'good content' will be exempt from Twitter's plan to charge for API access
 - [http://www.msn.com/en-us/news/technology/elon-musk-says-bots-making-good-content-will-be-exempt-from-twitter-s-plan-to-charge-for-api-access/ar-AA1781fq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-says-bots-making-good-content-will-be-exempt-from-twitter-s-plan-to-charge-for-api-access/ar-AA1781fq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 16:52:13.501593+00:00
 - user: None



## GOP voter suppression measures are working, despite Democratic wins
 - [http://www.msn.com/en-us/news/politics/gop-voter-suppression-measures-are-working-despite-democratic-wins/ar-AA178pVc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-voter-suppression-measures-are-working-despite-democratic-wins/ar-AA178pVc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 16:52:13.493513+00:00
 - user: None



## South Carolina deputies fatally shoot barricaded suspect after he repeatedly stabs police dog
 - [http://www.msn.com/en-us/news/crime/south-carolina-deputies-fatally-shoot-barricaded-suspect-after-he-repeatedly-stabs-police-dog/ar-AA1786yu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/south-carolina-deputies-fatally-shoot-barricaded-suspect-after-he-repeatedly-stabs-police-dog/ar-AA1786yu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 16:52:13.484284+00:00
 - user: None



## Pete Buttigieg Says He Will Not Run For Michigan Senate in 2024
 - [http://www.msn.com/en-us/news/politics/pete-buttigieg-says-he-will-not-run-for-michigan-senate-in-2024/ar-AA1785Ww?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pete-buttigieg-says-he-will-not-run-for-michigan-senate-in-2024/ar-AA1785Ww?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 15:52:14.820598+00:00
 - user: None



## Trump wouldn't beat Biden, Sununu says
 - [http://www.msn.com/en-us/news/politics/trump-wouldn-t-beat-biden-sununu-says/ar-AA178nnk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-wouldn-t-beat-biden-sununu-says/ar-AA178nnk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 15:52:14.812851+00:00
 - user: None



## Pete Buttigieg argues Chinese spy balloon was 'handled appropriately'
 - [http://www.msn.com/en-us/news/world/pete-buttigieg-argues-chinese-spy-balloon-was-handled-appropriately/ar-AA17839u?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pete-buttigieg-argues-chinese-spy-balloon-was-handled-appropriately/ar-AA17839u?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 15:52:14.805826+00:00
 - user: None



## How the cases in Alex Murdaugh's murder trial are shaping up
 - [http://www.msn.com/en-us/news/crime/how-the-cases-in-alex-murdaugh-s-murder-trial-are-shaping-up/ar-AA1780Wf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/how-the-cases-in-alex-murdaugh-s-murder-trial-are-shaping-up/ar-AA1780Wf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 15:52:14.798745+00:00
 - user: None



## The stealth F-22, the top US air superiority fighter, just got its first known air-to-air kill taking out a Chinese balloon.
 - [http://www.msn.com/en-us/news/world/the-stealth-f-22-the-top-us-air-superiority-fighter-just-got-its-first-known-air-to-air-kill-taking-out-a-chinese-balloon/ar-AA178nvj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-stealth-f-22-the-top-us-air-superiority-fighter-just-got-its-first-known-air-to-air-kill-taking-out-a-chinese-balloon/ar-AA178nvj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 15:52:14.791301+00:00
 - user: None



## Timeline: Where the Chinese surveillance balloon was spotted before being shot down
 - [http://www.msn.com/en-us/news/world/timeline-where-the-chinese-surveillance-balloon-was-spotted-before-being-shot-down/ar-AA175xfy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/timeline-where-the-chinese-surveillance-balloon-was-spotted-before-being-shot-down/ar-AA175xfy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 15:52:14.782419+00:00
 - user: None



## Montana rancher predicts Biden policies could diminish beef supply: 'Government tape'
 - [http://www.msn.com/en-us/news/us/montana-rancher-predicts-biden-policies-could-diminish-beef-supply-government-tape/ar-AA177T9K?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/montana-rancher-predicts-biden-policies-could-diminish-beef-supply-government-tape/ar-AA177T9K?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 15:52:14.774003+00:00
 - user: None



## Rubio criticizes Biden delay in addressing suspected Chinese spy balloon
 - [http://www.msn.com/en-us/news/politics/rubio-criticizes-biden-delay-in-addressing-suspected-chinese-spy-balloon/ar-AA177Tca?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rubio-criticizes-biden-delay-in-addressing-suspected-chinese-spy-balloon/ar-AA177Tca?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 15:52:14.766802+00:00
 - user: None



## The Creator of ChatGPT Thinks AI Should Be Regulated
 - [http://www.msn.com/en-us/news/technology/the-creator-of-chatgpt-thinks-ai-should-be-regulated/ar-AA178hrB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-creator-of-chatgpt-thinks-ai-should-be-regulated/ar-AA178hrB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 14:52:10.661462+00:00
 - user: None



## Chinese spy balloon is a Sputnik moment for America
 - [http://www.msn.com/en-us/news/world/chinese-spy-balloon-is-a-sputnik-moment-for-america/ar-AA1789pD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/chinese-spy-balloon-is-a-sputnik-moment-for-america/ar-AA1789pD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 14:52:10.652358+00:00
 - user: None



## Record numbers of people are worse off, a recipe for political discontent: POLL
 - [http://www.msn.com/en-us/news/politics/record-numbers-of-people-are-worse-off-a-recipe-for-political-discontent-poll/ar-AA177xIz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/record-numbers-of-people-are-worse-off-a-recipe-for-political-discontent-poll/ar-AA177xIz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 14:52:10.645110+00:00
 - user: None



## Here's how you can tell Joe Manchin is spineless
 - [http://www.msn.com/en-us/news/us/here-s-how-you-can-tell-joe-manchin-is-spineless/ar-AA1780F0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/here-s-how-you-can-tell-joe-manchin-is-spineless/ar-AA1780F0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 14:52:10.637848+00:00
 - user: None



## How to watch the Grammys live (including the red carpet)
 - [http://www.msn.com/en-us/news/us/how-to-watch-the-grammys-live-including-the-red-carpet/ar-AA178b0D?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/how-to-watch-the-grammys-live-including-the-red-carpet/ar-AA178b0D?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 14:52:10.628860+00:00
 - user: None



## A Texas 'Dreamer' found out during an immigration meeting that his dad wasn't his biological father. Now he could be trapped in Mexico for a decade.
 - [http://www.msn.com/en-us/news/us/a-texas-dreamer-found-out-during-an-immigration-meeting-that-his-dad-wasn-t-his-biological-father-now-he-could-be-trapped-in-mexico-for-a-decade/ar-AA177VH1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-texas-dreamer-found-out-during-an-immigration-meeting-that-his-dad-wasn-t-his-biological-father-now-he-could-be-trapped-in-mexico-for-a-decade/ar-AA177VH1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 14:52:10.619853+00:00
 - user: None



## For Trump, one step forward, two steps back
 - [http://www.msn.com/en-us/news/politics/for-trump-one-step-forward-two-steps-back/ar-AA1780I7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/for-trump-one-step-forward-two-steps-back/ar-AA1780I7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 14:52:10.612449+00:00
 - user: None



## Betsy DeVos and former GOP lawmakers who helped construct versions of the legislation Biden is using to cancel student debt just told the Supreme Court his plan 'obviously violates' the law
 - [http://www.msn.com/en-us/news/politics/betsy-devos-and-former-gop-lawmakers-who-helped-construct-versions-of-the-legislation-biden-is-using-to-cancel-student-debt-just-told-the-supreme-court-his-plan-obviously-violates-the-law/ar-AA1788jL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/betsy-devos-and-former-gop-lawmakers-who-helped-construct-versions-of-the-legislation-biden-is-using-to-cancel-student-debt-just-told-the-supreme-court-his-plan-obviously-violates-the-law/ar-AA1788jL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 13:52:31.652865+00:00
 - user: None



## The U.S. has a long history of environmental protests. Police had never killed an activist — until now.
 - [http://www.msn.com/en-us/news/us/the-u-s-has-a-long-history-of-environmental-protests-police-had-never-killed-an-activist-until-now/ar-AA1788GY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-u-s-has-a-long-history-of-environmental-protests-police-had-never-killed-an-activist-until-now/ar-AA1788GY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 13:52:31.645230+00:00
 - user: None



## Editorial: Are California school kids drinking water tainted with lead? We don't know, and that's the problem
 - [http://www.msn.com/en-us/news/us/editorial-are-california-school-kids-drinking-water-tainted-with-lead-we-don-t-know-and-that-s-the-problem/ar-AA1788AE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/editorial-are-california-school-kids-drinking-water-tainted-with-lead-we-don-t-know-and-that-s-the-problem/ar-AA1788AE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 13:52:31.636993+00:00
 - user: None



## Georgia House Democrats drop gun bills
 - [http://www.msn.com/en-us/news/us/georgia-house-democrats-drop-gun-bills/ar-AA1788QM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/georgia-house-democrats-drop-gun-bills/ar-AA1788QM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 13:52:31.629266+00:00
 - user: None



## Ukraine: 5 injured in rocket attacks on 2nd-largest city
 - [http://www.msn.com/en-us/news/world/ukraine-5-injured-in-rocket-attacks-on-2nd-largest-city/ar-AA1780mc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-5-injured-in-rocket-attacks-on-2nd-largest-city/ar-AA1780mc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 13:52:31.619875+00:00
 - user: None



## An ambitious, bipartisan pro-life legislative agenda
 - [http://www.msn.com/en-us/news/politics/an-ambitious-bipartisan-pro-life-legislative-agenda/ar-AA1788Sm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/an-ambitious-bipartisan-pro-life-legislative-agenda/ar-AA1788Sm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 13:52:31.610925+00:00
 - user: None



## Coffee shop named 'Woke' defended after receiving backlash, boycott calls: 'It's disgusting'
 - [http://www.msn.com/en-us/news/us/coffee-shop-named-woke-defended-after-receiving-backlash-boycott-calls-it-s-disgusting/ar-AA1780o9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/coffee-shop-named-woke-defended-after-receiving-backlash-boycott-calls-it-s-disgusting/ar-AA1780o9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 13:52:31.602959+00:00
 - user: None



## 'You're fired! You're hired!': Trump's final acting Pentagon chief recounts how he got the job
 - [http://www.msn.com/en-us/news/politics/you-re-fired-you-re-hired-trump-s-final-acting-pentagon-chief-recounts-how-he-got-the-job/ar-AA1787T7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/you-re-fired-you-re-hired-trump-s-final-acting-pentagon-chief-recounts-how-he-got-the-job/ar-AA1787T7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 12:52:20.490674+00:00
 - user: None



## Flexing his wins and eyeing a 2nd term, Biden will lay out contrasts with GOP in State of the Union
 - [http://www.msn.com/en-us/news/politics/flexing-his-wins-and-eyeing-a-2nd-term-biden-will-lay-out-contrasts-with-gop-in-state-of-the-union/ar-AA177E53?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/flexing-his-wins-and-eyeing-a-2nd-term-biden-will-lay-out-contrasts-with-gop-in-state-of-the-union/ar-AA177E53?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 12:52:20.482419+00:00
 - user: None



## Crank Down the Thermostat and Use a Space Heater at Night: Here's How Much You'll Save
 - [http://www.msn.com/en-us/news/technology/crank-down-the-thermostat-and-use-a-space-heater-at-night-here-s-how-much-you-ll-save/ar-AA12fIQB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/crank-down-the-thermostat-and-use-a-space-heater-at-night-here-s-how-much-you-ll-save/ar-AA12fIQB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 12:52:20.474948+00:00
 - user: None



## Situation in east Ukraine getting tough - Zelensky
 - [http://www.msn.com/en-us/news/world/situation-in-east-ukraine-getting-tough-zelensky/ar-AA1782hU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/situation-in-east-ukraine-getting-tough-zelensky/ar-AA1782hU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 12:52:20.468030+00:00
 - user: None



## Election skeptics slow to get sweeping changes in GOP states
 - [http://www.msn.com/en-us/news/politics/election-skeptics-slow-to-get-sweeping-changes-in-gop-states/ar-AA177Slp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/election-skeptics-slow-to-get-sweeping-changes-in-gop-states/ar-AA177Slp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 12:52:20.461046+00:00
 - user: None



## Koch Political Machine Vows to Fight to Deny Trump GOP Nomination in 2024
 - [http://www.msn.com/en-us/news/politics/koch-political-machine-vows-to-fight-to-deny-trump-gop-nomination-in-2024/ar-AA1784Z7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/koch-political-machine-vows-to-fight-to-deny-trump-gop-nomination-in-2024/ar-AA1784Z7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 12:52:20.452531+00:00
 - user: None



## Little enthusiasm for Biden-Trump rematch seen in new poll
 - [http://www.msn.com/en-us/news/politics/little-enthusiasm-for-biden-trump-rematch-seen-in-new-poll/ar-AA1789Vp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/little-enthusiasm-for-biden-trump-rematch-seen-in-new-poll/ar-AA1789Vp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 12:52:20.443539+00:00
 - user: None



## Rep. Marjorie Taylor Greene complained about her low salary and said that working in Congress has made her 'miserable'
 - [http://www.msn.com/en-us/news/politics/rep-marjorie-taylor-greene-complained-about-her-low-salary-and-said-that-working-in-congress-has-made-her-miserable/ar-AA177YnD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-marjorie-taylor-greene-complained-about-her-low-salary-and-said-that-working-in-congress-has-made-her-miserable/ar-AA177YnD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 12:52:20.435675+00:00
 - user: None



## Virginia AG Jason Miyares leads GOP efforts to oust liberal district attorneys
 - [http://www.msn.com/en-us/news/politics/virginia-ag-jason-miyares-leads-gop-efforts-to-oust-liberal-district-attorneys/ar-AA1786ZV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/virginia-ag-jason-miyares-leads-gop-efforts-to-oust-liberal-district-attorneys/ar-AA1786ZV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 11:52:04.338968+00:00
 - user: None



## Is a Florida pastor accused of fraud feigning illness to avoid prison?
 - [http://www.msn.com/en-us/news/crime/is-a-florida-pastor-accused-of-fraud-feigning-illness-to-avoid-prison/ar-AA177R6w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/is-a-florida-pastor-accused-of-fraud-feigning-illness-to-avoid-prison/ar-AA177R6w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 11:52:04.329515+00:00
 - user: None



## Five things Biden is likely to say and not say in the State of the Union
 - [http://www.msn.com/en-us/news/politics/five-things-biden-is-likely-to-say-and-not-say-in-the-state-of-the-union/ar-AA1770Xx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/five-things-biden-is-likely-to-say-and-not-say-in-the-state-of-the-union/ar-AA1770Xx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 11:52:04.322315+00:00
 - user: None



## Uncle Joe faces the right-wing zealots: State of the Union will be a tightrope walk
 - [http://www.msn.com/en-us/news/politics/uncle-joe-faces-the-right-wing-zealots-state-of-the-union-will-be-a-tightrope-walk/ar-AA177RSQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/uncle-joe-faces-the-right-wing-zealots-state-of-the-union-will-be-a-tightrope-walk/ar-AA177RSQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 11:52:04.314252+00:00
 - user: None



## Letters to the Editor: Hey, Metro, no one wants more digital ads in L.A.
 - [http://www.msn.com/en-us/news/us/letters-to-the-editor-hey-metro-no-one-wants-more-digital-ads-in-l-a/ar-AA1786Tr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/letters-to-the-editor-hey-metro-no-one-wants-more-digital-ads-in-l-a/ar-AA1786Tr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 11:52:04.307057+00:00
 - user: None



## Russian army officer says he saw Ukrainian POWs tortured
 - [http://www.msn.com/en-us/news/world/russian-army-officer-says-he-saw-ukrainian-pows-tortured/ar-AA177XyB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-army-officer-says-he-saw-ukrainian-pows-tortured/ar-AA177XyB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 11:52:04.299906+00:00
 - user: None



## Elon Musk says SpaceX is planning to attempt a launch of its Starship spacecraft in March
 - [http://www.msn.com/en-us/news/technology/elon-musk-says-spacex-is-planning-to-attempt-a-launch-of-its-starship-spacecraft-in-march/ar-AA17872i?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-says-spacex-is-planning-to-attempt-a-launch-of-its-starship-spacecraft-in-march/ar-AA17872i?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 11:52:04.290282+00:00
 - user: None



## Thousands join Pope for Mass in South Sudan
 - [http://www.msn.com/en-us/news/world/thousands-join-pope-for-mass-in-south-sudan/ar-AA177LHX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/thousands-join-pope-for-mass-in-south-sudan/ar-AA177LHX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 11:52:04.282039+00:00
 - user: None



## Hollywood Stars Could Be Next for Netflix K-Dramas
 - [http://www.msn.com/en-us/news/technology/hollywood-stars-could-be-next-for-netflix-k-dramas/ar-AA177DJo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/hollywood-stars-could-be-next-for-netflix-k-dramas/ar-AA177DJo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 10:52:39.000060+00:00
 - user: None



## 'Praying for a Miracle': The Americans Detained in China
 - [http://www.msn.com/en-us/news/world/praying-for-a-miracle-the-americans-detained-in-china/ar-AA177PPJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/praying-for-a-miracle-the-americans-detained-in-china/ar-AA177PPJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 09:52:32.406471+00:00
 - user: None



## EU migration impasse leaves many refugees out in the cold
 - [http://www.msn.com/en-us/news/world/eu-migration-impasse-leaves-many-refugees-out-in-the-cold/ar-AA177tFS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/eu-migration-impasse-leaves-many-refugees-out-in-the-cold/ar-AA177tFS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 09:52:32.398689+00:00
 - user: None



## Maryland middle schooler brings loaded gun into classroom
 - [http://www.msn.com/en-us/news/us/maryland-middle-schooler-brings-loaded-gun-into-classroom/ar-AA177I2v?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/maryland-middle-schooler-brings-loaded-gun-into-classroom/ar-AA177I2v?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 09:52:32.390662+00:00
 - user: None



## Pope says South Sudan's future depends on treatment of women
 - [http://www.msn.com/en-us/news/world/pope-says-south-sudan-s-future-depends-on-treatment-of-women/ar-AA177B1t?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pope-says-south-sudan-s-future-depends-on-treatment-of-women/ar-AA177B1t?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 08:52:16.568135+00:00
 - user: None



## Co-owner of popular Atlanta nightclub Republic Lounge shot to death outside the establishment
 - [http://www.msn.com/en-us/news/crime/co-owner-of-popular-atlanta-nightclub-republic-lounge-shot-to-death-outside-the-establishment/ar-AA177yHT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/co-owner-of-popular-atlanta-nightclub-republic-lounge-shot-to-death-outside-the-establishment/ar-AA177yHT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 08:52:16.559425+00:00
 - user: None



## Voting starts for Cyprus' presidency, with 3 front-runners
 - [http://www.msn.com/en-us/news/world/voting-starts-for-cyprus-presidency-with-3-front-runners/ar-AA177HWh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/voting-starts-for-cyprus-presidency-with-3-front-runners/ar-AA177HWh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 08:52:16.550988+00:00
 - user: None



## China condemns US ‘attack’ on surveillance balloon as ‘overreaction’
 - [http://www.msn.com/en-us/news/world/china-condemns-us-attack-on-surveillance-balloon-as-overreaction/ar-AA177xA1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-condemns-us-attack-on-surveillance-balloon-as-overreaction/ar-AA177xA1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 07:44:23.188205+00:00
 - user: None



## Close call avoided between two planes at a Texas airport
 - [http://www.msn.com/en-us/news/us/close-call-avoided-between-two-planes-at-a-texas-airport/ar-AA177xDt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/close-call-avoided-between-two-planes-at-a-texas-airport/ar-AA177xDt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 07:44:23.179401+00:00
 - user: None



## SNL Lands Exclusive Interview with the Chinese Spy Balloon
 - [http://www.msn.com/en-us/news/us/snl-lands-exclusive-interview-with-the-chinese-spy-balloon/ar-AA177uBn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/snl-lands-exclusive-interview-with-the-chinese-spy-balloon/ar-AA177uBn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 07:44:23.172278+00:00
 - user: None



## Record numbers are worse off, a recipe for political discontent: POLL
 - [http://www.msn.com/en-us/news/politics/record-numbers-are-worse-off-a-recipe-for-political-discontent-poll/ar-AA177xIz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/record-numbers-are-worse-off-a-recipe-for-political-discontent-poll/ar-AA177xIz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 07:44:23.165047+00:00
 - user: None



## New York school apologizes served watermelon and chicken waffles on first day of Black History Month
 - [http://www.msn.com/en-us/news/us/new-york-school-apologizes-served-watermelon-and-chicken-waffles-on-first-day-of-black-history-month/ar-AA177Ccg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/new-york-school-apologizes-served-watermelon-and-chicken-waffles-on-first-day-of-black-history-month/ar-AA177Ccg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 07:44:23.157864+00:00
 - user: None



## Pervez Musharraf, Pakistan martial ruler in 9/11 wars, dies
 - [http://www.msn.com/en-us/news/world/pervez-musharraf-pakistan-martial-ruler-in-9-11-wars-dies/ar-AA177FYo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pervez-musharraf-pakistan-martial-ruler-in-9-11-wars-dies/ar-AA177FYo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 07:44:21.919373+00:00
 - user: None



## Famed LA cougar gets sendoff by celebs, politicians and thousands of fans at memorial
 - [http://www.msn.com/en-us/news/us/famed-la-cougar-gets-sendoff-by-celebs-politicians-and-thousands-of-fans-at-memorial/ar-AA177Cyz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/famed-la-cougar-gets-sendoff-by-celebs-politicians-and-thousands-of-fans-at-memorial/ar-AA177Cyz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 07:44:21.911786+00:00
 - user: None



## Obituary: Pervez Musharraf
 - [http://www.msn.com/en-us/news/world/obituary-pervez-musharraf/ar-AA177JVv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/obituary-pervez-musharraf/ar-AA177JVv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-02-05 07:44:21.869277+00:00
 - user: None


