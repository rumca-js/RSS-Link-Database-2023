# Source Money PL, Source URL:https://www.money.pl/rss/, Source language: pl-PL

## EuCO ma do oddania miliony. Mówi, na czym chce zarabiać, by jak najszybciej spłacić dług
 - [https://www.money.pl/ubezpieczenia/euco-ma-do-oddania-miliony-mowi-na-czym-chce-zarabiac-by-jak-najszybciej-splacic-dlug-6862257903290976a.html](https://www.money.pl/ubezpieczenia/euco-ma-do-oddania-miliony-mowi-na-czym-chce-zarabiac-by-jak-najszybciej-splacic-dlug-6862257903290976a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-05 13:30:16+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/69efaa5d-1472-4a39-9113-afa3db84e2c4" width="308" /> Kancelaria odszkodowawcza EuCO, która straciła płynność i przestała płacić zobowiązania w terminie, opracowała właśnie plan naprawczy i czeka na akceptację sądu. W pierwszej kolejności chce spłacić klientów - winna jest im ok. 37 mln zł, ale to nie wszystko.

## Prognozy dla rynku kredytowego w 2023 roku
 - [https://www.money.pl/banki/prognozy-dla-rynku-kredytowego-w-2023-roku-6863229559560800a.html](https://www.money.pl/banki/prognozy-dla-rynku-kredytowego-w-2023-roku-6863229559560800a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-05 10:32:29+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3daa478f-e625-4058-b5da-0aae66e3f435" width="308" /> Wysokie stopy procentowe NBP, wysoki, choć obniżający się WIBOR, agresja Rosji na Ukrainę, wysoki poziom inflacji - te czynniki sprawiły, że w 2022 r. na rynek kredytowy nie można było patrzeć z optymizmem. Sprawdziliśmy, jakie są prognozy dla tego rynku na 2023 r. i w jakim otoczeniu gospodarczym przyjdzie mu działać.

## Odszkodowanie za złamanie zakazu konkurencji
 - [https://www.money.pl/gospodarka/odszkodowanie-za-zlamanie-zakazu-konkurencji-6862523982580288a.html](https://www.money.pl/gospodarka/odszkodowanie-za-zlamanie-zakazu-konkurencji-6862523982580288a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-05 09:40:07+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8770a65b-c577-4ca7-82a0-ea872388b85b" width="308" /> Umowa o pracę jest podstawowym dokumentem pozwalającym na nawiązanie stosunku pracy pomiędzy. Zdarza się, że jej integralnym elementem jest umowa o zakazie konkurencji. Pracodawca wymaga jej podpisania dla zabezpieczenia swoich interesów. Jednak umowie o zakaz konkurencji towarzyszyć muszą zapisy dotyczące ewentualnego odszkodowania. Ile może ono wynosić?

## Dzieci dostaną od rządu laptopy na własność. A co z podatkiem od darowizny?
 - [https://www.money.pl/podatki/dzieci-dostana-od-rzadu-laptopy-na-wlasnosc-a-co-z-podatkiem-od-darowizny-6862571758455392a.html](https://www.money.pl/podatki/dzieci-dostana-od-rzadu-laptopy-na-wlasnosc-a-co-z-podatkiem-od-darowizny-6862571758455392a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-05 09:25:21+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5b22c8f2-779b-4a9f-948f-919d08b95e03" width="308" /> Rząd kupi wszystkim uczniom czwartych klas laptopy i podaruje je rodzinom na własność. Zapłaci za to w sumie 760 mln zł. Średnia wartość laptopa wynosi 2054 zł. "Czy będziemy musieli zapłacić podatek od takiej darowizny?" – dopytują rodzice 10. latków. Otóż nie każdy rodzic będzie zwolniony z podatku od darowizny. Chyba, że rząd zmieni wcześniej obowiązujące przepisy.

## Nadciąga kolejne uderzenie? "To dopiero początek kłopotów"
 - [https://www.money.pl/gospodarka/nadciaga-kolejne-uderzenie-to-dopiero-poczatek-klopotow-6862564131665537v.html](https://www.money.pl/gospodarka/nadciaga-kolejne-uderzenie-to-dopiero-poczatek-klopotow-6862564131665537v.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-05 08:55:07+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/wptv-upload-api.wpcdn.pl/04510749-6f1f-4f80-a1be-593e92bf754c.jpg" width="308" /> - Uważam, że to dopiero początek problemów w gospodarce USA, a co za tym idzie również w Europie i Polsce. Historia pokazuje, że początki recesji zazwyczaj wyglądają na miękkie lądowanie, a później sytuacja się pogarsza. Tak może być i w tym przypadku - mówił w programie Money.pl Damian Rosiński, główny ekonomista Domu Maklerskiego AFS. Według niego będzie to miało wpływ na zachowanie banków centralnych oraz inflacji. Czy w takim razie musimy szykować się na kolejne wstrząsy?

## Węgry obawiają się, że sankcje wobec Rosji dotkną także ich
 - [https://www.money.pl/gospodarka/wegry-obawiaja-sie-ze-sankcje-wobec-rosji-dotkna-takze-ich-6863200940767808a.html](https://www.money.pl/gospodarka/wegry-obawiaja-sie-ze-sankcje-wobec-rosji-dotkna-takze-ich-6863200940767808a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-05 08:36:04+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/25302780-8a78-4ae5-abd1-2fe02096ab31" width="308" /> Choć Węgry uzyskały wyjątek w zakresie unijnego embarga na rosyjską ropę, to konsekwencje wchodzącego w życie w niedzielę, 5 lutego zakazu importu produktów ropopochodnych z Rosji mogą w dłuższej perspektywie dotknąć również nasz kraj – poinformowało w sobotę węgierskie ministerstwo energii.

## Wiek emerytalny. Blisko połowa Polaków nie chce żadnych zmian
 - [https://www.money.pl/emerytury/wiek-emerytalny-blisko-polowa-polakow-nie-chce-zadnych-zmian-6863181062175296a.html](https://www.money.pl/emerytury/wiek-emerytalny-blisko-polowa-polakow-nie-chce-zadnych-zmian-6863181062175296a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-05 07:15:11+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fb566c21-e3c9-456e-8342-5584e7cf21ae" width="308" /> 41,4 proc. ankietowanych w sondażu SW Research dla "Rzeczpospolitej" opowiedziało się za zachowaniem obecnego wieku emerytalnego. 26,8 proc. było zdania, że korzystniejsze jest dla nich podniesienie wieku emerytalnego, co wiąże się z otrzymaniem wyższej emerytury.

## Rosyjska gospodarka ma się gorzej, niż pokazują to dane. Putin wie, że ma problem
 - [https://www.money.pl/gospodarka/rosyjska-gospodarka-ma-sie-gorzej-niz-pokazuja-to-dane-putin-wie-ze-ma-problem-6863175390476864a.html](https://www.money.pl/gospodarka/rosyjska-gospodarka-ma-sie-gorzej-niz-pokazuja-to-dane-putin-wie-ze-ma-problem-6863175390476864a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-05 06:52:06+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/72e587ba-8f2f-4b47-bb63-5aa1de322038" width="308" /> Rozpowszechnił się szkodliwy pogląd, że restrykcje nałożone na Moskwę nie przyniosły rezultatów. A jednak sankcje te są skuteczne,  trzeba tylko cierpliwości, by ocenić ich pełne konsekwencje - pisze Władimir Miłow z Fundacji Wolna Rosja na łamach amerykańskiego magazynu "Foreign Affairs".

## Ponad połowa pokolenia Z odczuwa samotność. Media społecznościowe zniszczyły młodych?
 - [https://www.money.pl/gospodarka/ponad-polowa-pokolenia-z-odczuwa-samotnosc-media-spolecznosciowe-zniszczyly-mlodych-6862296098212448a.html](https://www.money.pl/gospodarka/ponad-polowa-pokolenia-z-odczuwa-samotnosc-media-spolecznosciowe-zniszczyly-mlodych-6862296098212448a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-02-05 06:27:11+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/be63b985-f5c5-4315-a168-89dc58f8e80f" width="308" /> Oddani w pełni życiu w sieci młodzi ludzie w większości czują się samotni. Z ankiety wynika, że problem ten może dotykać nawet 60 proc. przedstawicieli pokolenia Z. Przyczyniają się do tego głównie media społecznościowe. Pojawił się jednak pomysł na to, jak je wykorzystać, by pomóc samotnej młodzieży.
