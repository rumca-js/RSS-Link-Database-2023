# Source Android Authority, Source URL:https://www.androidauthority.com/feed/, Source language: en-US

## MagSafe cases are coming for our Android phones; bring them on!
 - [https://www.androidauthority.com/magsafe-cases-android-phones-3275280/](https://www.androidauthority.com/magsafe-cases-android-phones-3275280/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-02-05 17:00:59+00:00
 - user: None

I'd put the famous Breaking Bad magnets quote here, but we're a family-friendly site.

## I’m training for a 250K race with an Apple Watch Ultra. It’s perfect.
 - [https://www.androidauthority.com/apple-watch-ultra-marathon-3273730/](https://www.androidauthority.com/apple-watch-ultra-marathon-3273730/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-02-05 15:00:54+00:00
 - user: None

It's a long race, but the training period is longer still. My fitness tracker needs to be a constant companion.
