# Source Wired business, Source URL:https://www.wired.com/feed/category/business/latest/rss, Source language: en-US

## Meta’s Gruesome Content Broke Him. Now He Wants It to Pay
 - [https://www.wired.com/story/meta-kenya-lawsuit-outsourcing-content-moderation/](https://www.wired.com/story/meta-kenya-lawsuit-outsourcing-content-moderation/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-05 12:00:00+00:00
 - user: None

A Kenyan moderator sued the company for work-related PTSD. Next week, a new ruling on his case could signal a global reckoning for Big Tech outsourcing.

## These Apps Will Keep Your EV from Running Out of Juice
 - [https://www.wired.com/story/apps-find-electric-vehicle-battery-charge-locations/](https://www.wired.com/story/apps-find-electric-vehicle-battery-charge-locations/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-02-05 12:00:00+00:00
 - user: None

Stay charged from point A to point B.
