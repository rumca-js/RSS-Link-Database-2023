# Source Louder With Crowder, Source URL:http://louderwithcrowder.com/feed/, Source language: en-US

## Watch: Spirit Airlines brawl leaves woman shirtless, wigless, and probably facing charges
 - [https://www.louderwithcrowder.com/spirit-airlines-brawl](https://www.louderwithcrowder.com/spirit-airlines-brawl)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-02-05 16:21:37+00:00
 - user: None

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32981539&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Ah, Spirit Airlines. Dubbed the "Waffle House of the Sky" by Twitter fanatics, the airline is known for its frequent brawls. The most recent spat took place at a Philadelphia airport when a 39-year-old mom and her 17-year-old daughter were given extra baggage fees because their carry-on luggage was too large. Naturally, they reacted to this minor inconvenience with outright violence. It is Spirit, after all. </p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;">\u201cSpirit Airlines agents are seen trading blows with passengers at Philly airport https://t.co/IpbXCdumfs\u201d</div> — Daily Mail US (@Daily Mail US)
        <a href="https://twitter.com/DailyMail/status/1622136751971078146">1675582514</a>
</blockquote>

<p>Though the mom and daughter launched the attack, the airline workers could also be in some hot water. When the teenager let go, a male agent punched her several times in the face, even though she was being restrained. At one point, a young boy believed to be part of the family began hitting an employee before running away in tears. The mother somehow lost her shoes and shirt in the scuffle, leaving her in just a bra. Her wig was later torn off right before a security guard came in to break it up, after nearly 2.5 minutes of brawling. No arrests have yet been made. </p><p>There, unfortunately, doesn't seem to be a full-length video of the soaring wig in all its glory, but there is this brief snippet uncovered by a Twitter sleuth:</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;">\u201c@HarmlessYardDog "How would you feel if you used the proper sized luggage?\nMother and daughter are seen trading blows with Spirit Airlines agents in video of wild airport brawl after they were hit with extra fees at the gate for their oversized carry-on baggage\u201d</div> — DosXXMaquina (@DosXXMaquina)
        <a href="https://twitter.com/DuosEquis/status/1622145762267205633">1675584662</a>
</blockquote>

<p>As we are all well aware, this isn't the first time Spirit has had a massive brawl on its airline, and it won't be the last. Last <a href="https://www.louderwithcrowder.com/spirit-airlines-dfw-brawl" target="_blank">August</a>, an agent was suspended after an angry customer sucker-punched him and he pushed her back. The woman was allegedly angry over a seat and called the agent a "f**got" before things escalated and turned violent. </p><p>Besides the brawlin' problem, Spirit Airlines also has a free speech problem. Last year, a flight attendant <a href="https://www.louderwithcrowder.com/lets-go-brandon-led-mask" target="_blank">harassed</a> a based passenger for wearing a "Let's Go Brandon" mask. They made him put on a new, less "offensive" mask. </p><p>I will say, the one upside to Spirit Airlines can have some cheap flights. But you might just get dragged into a massive brawl over luggage fees. It's the price of doin' business. </p>

## LeBron James deletes video once he realizes what Morgan Freeman was REALLY saying about black history month
 - [https://www.louderwithcrowder.com/lebron-james-morgan-freeman-tweet](https://www.louderwithcrowder.com/lebron-james-morgan-freeman-tweet)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-02-05 15:06:03+00:00
 - user: None

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32981465&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p>Is <a href="https://www.louderwithcrowder.com/lebron-james-media-jerry-jones" target="_blank">Lebron James</a> secretly based? Probably not, given that he routinely kneels for the National Anthem. Y'know, because the country that helped him amass a $1B net worth is also evil and racist and horrible. But Lebron had a slightly based moment over the weekend, before promptly scrubbing the internet of any evidence. That's how you know it really <em>was</em> based. </p><p>On Friday, Lebron shared a video on Instagram of Morgan Freeman criticizing Black History Month. In it, Freeman said Black History Month is "ridiculous." He further explained, "You're gonna relegate my history to a month?" and stated, "I don't want a Black history month. Black history is American history."</p><p>This video was originally posted by Turning Point USA's Charlie Kirk. Kirk noticed Lebron shared and deleted the clip, and tweeted, ""LeBron James shared a video I posted of Morgan Freeman saying we should get rid of black history month, then he deleted it. Why?"</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;">\u201cHere's the full video I posted.\u201d</div> — Charlie Kirk (@Charlie Kirk)
        <a href="https://twitter.com/charliekirk11/status/1621668554260234240">1675469989</a>
</blockquote>

<p>In the full clip posted by Kirk, Freeman asked the CBS anchor "which month is white history month" and which is "Jewish history month." He also said America could get rid of racism if we "stop talking about it," adding, "I'm going to stop calling you a white man. And I'm going to ask you to stop calling me a black man. I know you as Mike Wallace. You know me as Morgan Freeman."</p><p>My guess is that Lebron hadn't watched the full clip, and once he did, decided to delete it since he is definitely not a fan of not talking about race. Or perhaps he was made aware that Charlie Kirk originally posted it, and had to delete it since Kirk is clearly a violent right-wing white supremacist racist extremist. Plus, he says China is bad. That's a big <a href="https://www.louderwithcrowder.com/nba-cancels-press-conferences-says-china-questions-are-unfairlebro" target="_blank">no-no</a> for the NBA. </p>
