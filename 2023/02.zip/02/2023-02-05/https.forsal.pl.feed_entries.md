# Source Forsal.pl, Source URL:https://forsal.pl/.feed, Source language: pl-PL

## Zmasowany atak hakerski na dziesiątki krajowych systemów. Dotknął m.in. Włoch i Francji
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8653969,atak-hakerski-systemy-krajowe-wlochy-francja.html](https://forsal.pl/swiat/aktualnosci/artykuly/8653969,atak-hakerski-systemy-krajowe-wlochy-francja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 19:03:10+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EMWktkuTURBXy84OTI5MGIwZC0yYmJmLTQ0NGItYjZhNy0xYjdmMDliNzAwN2IuanBlZ5GTBc0BHcyg" />Włoska agencja do spraw cyberbezpieczeństwa poinformowała w niedzielę o zmasowanym ataku hakerskim na tysiące serwerów i dziesiątki krajowych systemów. Jak wyjaśniono, atak dotyczy też Francji, Finlandii, Kanady i USA. Nie podano skąd pochodzi atak.

## Papież Franciszek chce się spotkać się z Zełenskim i Putinem
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8653859,papiez-franciszek-zelenski-putin-spotkanie.html](https://forsal.pl/swiat/aktualnosci/artykuly/8653859,papiez-franciszek-zelenski-putin-spotkanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 18:31:57+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zJjktkuTURBXy81MGZlOTM5Ni0wYzRmLTRkMDUtYWU2Zi1lY2UzZDk5ZmU4ZGQuanBlZ5GTBc0BHcyg" />Papież Franciszek powiedział w niedzielę dziennikarzom, że jest gotów spotkać się z prezydentami Ukrainy i Rosji, Wołodymyrem Zełenskim i Władimirem Putinem. Wyjaśnił, że nie pojechał dotąd do Kijowa, ponieważ nie ma możliwości udania się również do Moskwy.

## W poniedziałek ukraińscy żołnierze zaczną się szkolić z obsługi czołgów Leopard
 - [https://forsal.pl/swiat/ukraina/artykuly/8653855,ukraina-szkolenie-zolnierzy-czolgi-leopard.html](https://forsal.pl/swiat/ukraina/artykuly/8653855,ukraina-szkolenie-zolnierzy-czolgi-leopard.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 17:46:47+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Q12ktkuTURBXy9mOWE1ZTJiNi00N2M1LTQ4YTUtYWMzYi1iNmViZWMzYWY4NDMuanBlZ5GTBc0BHcyg" />W najbliższy poniedziałek, 6 lutego, rozpoczną się szkolenia ukraińskich załóg czołgów Leopard – powiadomił w niedzielę minister obrony Ukrainy Ołeksij Reznikow. Szkolenia będą się odbywać poza granicami naszego kraju - dodał.

## Wielotysięczne manifestacje w Hiszpanii. Ich powód może zaskakiwać
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8653721,hiszpania-manifestacje-w-obronie-chartow-mysliwskich.html](https://forsal.pl/swiat/aktualnosci/artykuly/8653721,hiszpania-manifestacje-w-obronie-chartow-mysliwskich.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 17:28:09+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/__vktkuTURBXy8xOGJhNGYxZi1hNDU2LTQ2YTEtOGE2Ni1kMDQ0MzU5MDFiOTkuanBlZ5GTBc0BHcyg" />Tysiące osób wzięły udział w niedzielnych manifestacjach w całej Hiszpanii, szczególnie w stolicach prowincji, domagając się ochrony prawnej dla psów używanych podczas polowań, głównie chartów.

## Ukraińscy sabotażyści działają w Rosji. Rosyjskie dowództwo musi poczuć ogień walki na swoim terytorium
 - [https://forsal.pl/swiat/rosja/artykuly/8653701,rosja-dzialania-ukrainskich-sabotazystow.html](https://forsal.pl/swiat/rosja/artykuly/8653701,rosja-dzialania-ukrainskich-sabotazystow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 14:25:16+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MzOktkuTURBXy80YjMwNDhlZi05OGJmLTRlYzctOTMxYS1lMGNhOTg0MGI0OTMuanBlZ5GTBc0BHcyg" />Rząd w Kijowie oficjalnie temu zaprzecza, a władze państw zachodnich aż wzdrygają się na samą myśl o takich operacjach, ale ukraińscy sabotażyści działają na terytorium Rosji i dokonują tam ataków - powiadomił w niedzielę brytyjski magazyn &quot;The Observer&quot;.

## Ajatollah Chamenei ułaskawił dziesiątki tysięcy irańskich więźniów
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8653699,iran-ajatollach-chamenei-ulaskawienie-wiezniow.html](https://forsal.pl/swiat/aktualnosci/artykuly/8653699,iran-ajatollach-chamenei-ulaskawienie-wiezniow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 14:15:15+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8FLktkuTURBXy9iN2UxZmZiYi1jNzNjLTRhOGQtODgwZi1iMDJhNDJhYWM3ZTAuanBlZ5GTBc0BHcyg" />Z okazji rocznicy rewolucji islamskiej najwyższy przywódca duchowo-polityczny Iranu ajatollah Ali Chamenei ułaskawił dziesiątki tysięcy więźniów, w tym wielu aresztowanych w ostatnich antyrządowych protestach - poinformowała w niedzielę państwowa agencja IRNA.

## Mityng w Bostonie - Holenderka Bol najszybsza w historii na 500 m, Kiełbasińska druga na 300 m
 - [https://forsal.pl/artykuly/8653695,mityng-w-bostonie-holenderka-bol-najszybsza-w-historii-na-500-m-kielbasinska-druga-na-300-m.html](https://forsal.pl/artykuly/8653695,mityng-w-bostonie-holenderka-bol-najszybsza-w-historii-na-500-m-kielbasinska-druga-na-300-m.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 13:42:07+00:00
 - user: None



## Jak Polacy Polakom
 - [https://forsal.pl/gospodarka/polityka/artykuly/8652389,jak-polacy-polakom.html](https://forsal.pl/gospodarka/polityka/artykuly/8652389,jak-polacy-polakom.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 12:33:39+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TJTktkuTURBXy84NmYxNjg4Ni1iZmNlLTRhZjYtYTgyMS0yYjM4ZWU2YmNmZTAuanBlZ5GTBc0BHcyg" />Z grubsza ludzie starsi dzielą się na tych, których poruszał Jan Krzysztof Kelus, i na tych, którzy reagowali tak dzisiaj popularnym „ale o co chodzi?”.

## Zasiłek pogrzebowy 2023. Komu przysługuje, ile wynosi
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8653128,zasilek-pogrzebowy-swiadczenie-pogrzeb-zus-uprawnieni.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8653128,zasilek-pogrzebowy-swiadczenie-pogrzeb-zus-uprawnieni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 12:30:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/e0TktkuTURBXy80ODFmYzcxNS1jY2Y5LTRjYTMtOGY1My1iNjYzZmFkODcyYjkuanBlZ5GTBc0BHcyg" />Zasiłek pogrzebowy jest jednorazowym świadczeniem przysługującym w przypadku śmierci osoby, a także związanej z nią koniecznością dokonania pochówku. Komu przysługuje? Ile wynosi?

## Awaria ciepłownicza w Jastrzębiu-Zdroju. Zimne kaloryfery w ponad 23 tys. mieszkań
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8653688,jastrzebie-zdroj-awaria-cieplownicza.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8653688,jastrzebie-zdroj-awaria-cieplownicza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 12:28:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1HrktkuTURBXy8wZjU1MzcxZi0yNDZmLTQzZjktYjg3Yi00YTBhOTU4M2UwYWIuanBlZ5GTBc0BHcyg" />Mieszkańcy ponad 23 tys. mieszkań w Jastrzębiu-Zdroju mają w niedzielę zimne kaloryfery na skutek dwóch awarii ciepłowniczych. Trwa ponowne napełnianie sieci i w niedzielę wieczorem powinny zostać wznowione dostawy ciepła - zapewnia spółka PGNiG Termika Energetyka Przemysłowa.

## Polskie wyrzutnie Patriot staną na lotnisku na Bemowie
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8653687,wyrzutnie-patriot-lotnisko-bemowo-szkolenie.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8653687,wyrzutnie-patriot-lotnisko-bemowo-szkolenie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 12:22:14+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UiVktkuTURBXy85MDZlN2ExMS1lNTY0LTRkZTYtYmYzMC1jMDk1ZTkzYWUyZjguanBlZ5GTBc0BHcyg" />Polskie wyrzutnie Patriot przemieszczają się z Sochaczewa na lotnisko na warszawskim Bemowie, gdzie zostaną rozstawione. To ważny element szkolenia żołnierzy z 3. Warszawskiej Brygady Rakietowej Obrony Powietrznej - poinformował w niedzielę rano szef MON Mariusz Błaszczak.

## Protesty w Izraelu. Chodzi o reformy wymiaru sprawiedliwości
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8653637,izrael-reformy-wymiaru-sprawiedliwosci-protesty.html](https://forsal.pl/swiat/aktualnosci/artykuly/8653637,izrael-reformy-wymiaru-sprawiedliwosci-protesty.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 08:10:01+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UifktkuTURBXy8wNTUyNzViOS1mYWFiLTRmMzItOWM1OS1mOWM3Nzg1NmFkYmQuanBlZ5GTBc0BHcyg" />Ponad 100 tysięcy osób protestuje w sobotę wieczorem na ulicach izraelskich miast przeciwko rządowym planom reformy wymiaru sprawiedliwości - poinformował portal dziennika &quot;Jerusalem Post&quot;. Demonstracje odbywają się już piątą sobotę z rzędu.

## Amerykanie zestrzelili chiński balon. Państwo Środka niezadowolone
 - [https://forsal.pl/swiat/chiny/artykuly/8653636,chiny-usa-balon-szpiegowski-zestrzelony.html](https://forsal.pl/swiat/chiny/artykuly/8653636,chiny-usa-balon-szpiegowski-zestrzelony.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 08:03:25+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/K5SktkuTURBXy9lNmU0Yzg5Zi04OGFlLTRhNDItOTEyNy1iNTIxZDY2Nzk3MGYuanBlZ5GTBc0BHcyg" />Ministerstwo spraw zagranicznych Chin oświadczyło w niedzielę, że wyraża zdecydowane niezadowolenie i sprzeciw wobec użycia siły przez Stany Zjednoczone w celu zaatakowania ich statku powietrznego.

## Weszło w życie embargo Unii Europejskiej na produkty ropopochodne z Rosji
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8653634,unia-europejska-embargo-produkty-ropopochodne-rosja.html](https://forsal.pl/swiat/unia-europejska/artykuly/8653634,unia-europejska-embargo-produkty-ropopochodne-rosja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 07:50:03+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lkRktkuTURBXy81Y2I2OWMwYi1hNzk5LTRhZWQtYjhkYy0yMjhhN2NkMmY1Y2QuanBlZ5GTBc0BHcyg" />W niedzielę, 5 lutego br. weszło w życie embargo Unii Europejskiej na produkty z ropy, w tym paliwa gotowe z Rosji, nałożone w związku z rosyjską napaścią na Ukrainę. Eksperci nie spodziewają się zakłóceń na rynku po wprowadzeniu embarga.

## To nie pomnik, to żywa osoba. "Człowiek z Fener" oznaczony na mapie
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8653631,czlowiek-z-fener-oznaczony-na-mapie.html](https://forsal.pl/lifestyle/turystyka/artykuly/8653631,czlowiek-z-fener-oznaczony-na-mapie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 07:36:57+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/D5CktkuTURBXy9lMzkwMTk5My0zMTg3LTRiZjAtYmIxMS1lZTI0MTZlZjJmNGUuanBlZ5GTBc0BHcyg" />Mężczyzna, który od 30 lat pozdrawia kierowców przy drodze w miejscowości koło Belluno na północy Włoch, został niczym atrakcja turystyczna umieszczony na popularnej mapie internetowej. „Człowiek z Fener”- tak oznaczono miejsce, w którym często stoi.

## W marcu rozpocznie się budowa bariery elektronicznej na granicy z obwodem kaliningradzkim
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8653628,obwod-kaliningradzki-bariera-elektroniczna.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8653628,obwod-kaliningradzki-bariera-elektroniczna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 07:27:30+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wPxktkuTURBXy9iODA1MjQxNi1hZGI2LTRjMzgtOWRkMS05ZjBmZjRhYzE3NTUuanBlZ5GTBc0BHcyg" />Budowa bariery elektronicznej na granicy z obwodem kaliningradzkim powinna się rozpocząć w marcu - poinformowała PAP por. Straży Granicznej Anna Michalska z Komendy Głównej SG. System elektroniczny na odcinku z obwodem kaliningradzkim będzie przebiegał na ok. 200 km granicy lądowej.

## Cypr i Grecja kontra Turcja... Czy jest szansa na zakończenie wieloletniego kryzysu?
 - [https://forsal.pl/swiat/artykuly/8652749,cypr-i-grecja-kontra-turcja-szansa-na-zakonczenie-wieloletniego-kryzysu.html](https://forsal.pl/swiat/artykuly/8652749,cypr-i-grecja-kontra-turcja-szansa-na-zakonczenie-wieloletniego-kryzysu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 07:01:36+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EjmktkuTURBXy85NjAwMmNjOC03Yzg0LTQzZTMtYTQxOC03NTgxMmFkNDc2ZDIuanBlZ5GTBc0BHcyg" />Wiosną do urn pójdą Grecy oraz Turcy. Ale już w tę niedzielę prezydenta wybiorą Cypryjczycy, których wyspa to jedno z głównych źródeł napięć między Atenami a Ankarą

## Pieniądze szczęścia nie dają, ale pomagają zdobyć uznanie innych
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8652379,pieniadze-szczescia-nie-daja-ale-pomagaja-zdobyc-uznanie-innych.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8652379,pieniadze-szczescia-nie-daja-ale-pomagaja-zdobyc-uznanie-innych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 07:00:18+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/y4rktkuTURBXy83NGY0ODliZC1jYTAyLTQ3NGUtOTI2MS00ZTdkNzQ5YWE4MzAuanBlZ5GTBc0BHcyg" />Czy pensja tak wielka, że bez problemu wystarczy na kupno sporego jachtu (i późniejsze jego tankowanie), jest sensownym sposobem motywowania prezesa korporacji? Czy może nie chodzi o sam jacht? Tylko o to, że jego brak zostałby uznany przez prezesa za wyraz braku szacunku dla jego pracy i kompetencji? Wierzcie lub nie, ale istnieje wiele poważnych prac ekonomicznych, których przedmiotem zainteresowania jest właśnie „teoria sprawiedliwej płacy prezesa korpo”.

## Jak zbudowano "intelekutalną fawelę". Rzecz o pozornym sukcesie polskich naukowców
 - [https://forsal.pl/lifestyle/nauka/artykuly/8652399,jak-zbudowac-intelektualna-fawele-pozorny-sukces-polskich-naukowcow.html](https://forsal.pl/lifestyle/nauka/artykuly/8652399,jak-zbudowac-intelektualna-fawele-pozorny-sukces-polskich-naukowcow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 06:55:49+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oX_ktkuTURBXy9iYzRlYTU4YS1iOWQ2LTQyNjQtOGQ5NC0wYmYwZmFhYTYxZGEuanBlZ5GTBc0BHcyg" />Konieczność zdobywania punktów i grantów nie zrobi z adepta naukowca. A co innego robi przeciętny polski akademik?

## Polityka kontra demografia. Błędne decyzje mszczą się niską dzietnością
 - [https://forsal.pl/gospodarka/demografia/artykuly/8652507,polityka-kontra-demografia-bledne-decyzje-mszcza-sie-niska-dzietnoscia.html](https://forsal.pl/gospodarka/demografia/artykuly/8652507,polityka-kontra-demografia-bledne-decyzje-mszcza-sie-niska-dzietnoscia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 06:47:15+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Oi_ktkuTURBXy9kNDU0OGY4Yy0zNzRhLTQ0OTgtOTBiYi0yYzQ5MjFlMjMxYjcuanBlZ5GTBc0BHcyg" />Skuteczna polityka prorodzinna powinna pomagać Polkom w łączeniu pracy z rodzicielstwem. Wymaga to skupienia się na instytucjach i legislacji, co niestety naszym politykom niespecjalnie wychodzi

## Możemy pracować krócej i bardziej efektywnie. Spróbujmy, to się opłaca
 - [https://forsal.pl/praca/kariera/artykuly/8652505,mozemy-pracowac-krocej-i-bardziej-efektywnie-sprobujmy-to-sie-oplaca.html](https://forsal.pl/praca/kariera/artykuly/8652505,mozemy-pracowac-krocej-i-bardziej-efektywnie-sprobujmy-to-sie-oplaca.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 06:45:05+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gyMktkuTURBXy9iYWEwZTZhMC0wOGQxLTRhOGEtOWNjNS1jNmVlNjBmYWFhYTguanBlZ5GTBc0BHcyg" />Czterodniowy tydzień pracy bez obniżenia wynagrodzenia nie jest pomysłem tak rewolucyjnym, jak się wydaje. Bo już został wypróbowany i częściowo wprowadzony w Niemczech, Japonii, Nowej Zelandii, Islandii, Belgii i Wielkiej Brytanii

## Gospodarka, polityka klimatyczna i tanie źródła energii
 - [https://forsal.pl/biznes/energetyka/artykuly/8650068,gospodarka-polityka-klimatyczna-i-tanie-zrodla-energii.html](https://forsal.pl/biznes/energetyka/artykuly/8650068,gospodarka-polityka-klimatyczna-i-tanie-zrodla-energii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 06:43:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eElktkuTURBXy8xNjQyOTViYi01MDQ2LTRhMDktOWJlYy0wNzQ1ZjkxNmVmODYuanBlZ5GTBc0BHcyg" />Pierwszym problemem dla gospodarki niemieckiej jest brak tanich surowców. Drugim jest polityka klimatyczna, gdyż staje się coraz bardziej ambitna i w zasadzie – co sygnalizują niemieccy przedsiębiorcy – niemożliwa do zrealizowania w tej obecnej postaci – mówi prof. dr hab. Tomasz Grzegorz Grosse, wykładowca Uniwersytetu Warszawskiego.

## Oto jak wygląda ruski mir. Zdjęcia z Kramatorska
 - [https://forsal.pl/swiat/ukraina/galeria/8652676,tak-wyglada-ruski-mir-zdjecia-z-kramatorska.html](https://forsal.pl/swiat/ukraina/galeria/8652676,tak-wyglada-ruski-mir-zdjecia-z-kramatorska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 06:40:22+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sl_ktkuTURBXy9iZTM0Zjg2My1kNTgzLTQxYzEtYWRlNS1hY2Q4ZmRhNWZjMmYuanBlZ5GTBc0BHcyg" />Ruski mir to koncepcja Kremla zakładająca, że Rosja ma stanowić centrum świata wschodniosłowiańskiego. Ma też usprawiedliwić agresywną politykę podboju sąsiadów. Zobacz, jak w rzeczywistości wygląda wprowadzanie ruskiego miru. Oto zdjęcia z Kramatorska w Ukrainie

## Inflacja stygnie. Nowe prognozy wzrostu gospodarczego na świecie
 - [https://forsal.pl/gospodarka/artykuly/8650971,nowe-prognozy-wzrostu-pkb-i-inflacji-na-swiecie-mfw.html](https://forsal.pl/gospodarka/artykuly/8650971,nowe-prognozy-wzrostu-pkb-i-inflacji-na-swiecie-mfw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-02-05 06:38:44+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GCQktkuTURBXy9mYTU4NDljYi1mZTFhLTQxODktOWIwZC0zZThjNDQyOTExZjUuanBlZ5GTBc0BHcyg" />Wydaje się, że inflacja osiągnęła szczyt w 2022 r., wydatki konsumpcyjne pozostają solidne, a kryzys energetyczny po inwazji Rosji na Ukrainę był mniej dotkliwy, niż początkowo się obawiano. Taki obraz wyłania się z najnowszego raportu Międzynarodowego Funduszu Walutowego.
