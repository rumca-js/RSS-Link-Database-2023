# Source Sky News, Source URL:http://feeds.skynews.com/feeds/rss/world.xml, Source language: en-US

## Protests in Iraq after YouTube star allegedly strangled in 'honour killing'
 - [https://news.sky.com/story/protests-in-iraq-after-youtube-star-tiba-ali-allegedly-strangled-by-her-father-in-honour-killing-12804022](https://news.sky.com/story/protests-in-iraq-after-youtube-star-tiba-ali-allegedly-strangled-by-her-father-in-honour-killing-12804022)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-02-05 15:04:00+00:00
 - user: None

Dozens of Iraqi protesters gathered on Sunday to stand against the "honour killing" of a 22-year-old YouTube star - who was allegedly strangled by her father.

## Ukraine expecting 'symbolic' Russian offensive later this month
 - [https://news.sky.com/story/ukraine-war-kyiv-expecting-symbolic-russian-offensive-later-this-month-12804034](https://news.sky.com/story/ukraine-war-kyiv-expecting-symbolic-russian-offensive-later-this-month-12804034)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-02-05 15:04:00+00:00
 - user: None

Ukraine is expecting a possible major Russian offensive launched for "symbolic" reasons around the anniversary of its invasion later this month, the country's defence minister has said.

## Iran 'to pardon tens of thousands of prisoners' jailed during protests
 - [https://news.sky.com/story/iran-to-pardon-tens-of-thousands-of-prisoners-jailed-during-protests-state-media-reports-12803955](https://news.sky.com/story/iran-to-pardon-tens-of-thousands-of-prisoners-jailed-during-protests-state-media-reports-12803955)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-02-05 14:07:00+00:00
 - user: None

Tens of thousands of prisoners detained in Iran amid vast anti-government protests will be pardoned, state media reports.

## How US shot down China's 'spy balloon' with a single missile - and what was likely on it
 - [https://news.sky.com/story/how-did-the-us-successfully-shoot-down-chinas-spy-balloon-with-a-single-missile-and-what-was-on-it-12803882](https://news.sky.com/story/how-did-the-us-successfully-shoot-down-chinas-spy-balloon-with-a-single-missile-and-what-was-on-it-12803882)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-02-05 12:47:00+00:00
 - user: None

A US military operation to shoot down a Chinese "spy balloon" that had been hovering in American airspace came at a tense time for the two superpowers, whose relationship has been on rocky ground for years.

## China threatens 'further actions' over US downing of suspected spy balloon
 - [https://news.sky.com/story/china-threatens-further-actions-over-us-downing-of-suspected-spy-balloon-12803705](https://news.sky.com/story/china-threatens-further-actions-over-us-downing-of-suspected-spy-balloon-12803705)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-02-05 07:40:00+00:00
 - user: None

China has threatened "further actions" in response to America's "serious overreaction" in the downing of a suspected spy balloon.

## Former president of Pakistan General Pervez Musharraf dies after long illness
 - [https://news.sky.com/story/general-pervez-musharraf-former-president-of-pakistan-dies-after-long-illness-12803682](https://news.sky.com/story/general-pervez-musharraf-former-president-of-pakistan-dies-after-long-illness-12803682)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-02-05 06:08:00+00:00
 - user: None

Former president of Pakistan General Pervez Musharraf, who backed the US-led invasion of neighbouring Afghanistan during his tenure, has died after a prolonged illness at the age of 79.

## Beyond the 'balloon watch' gimmicks this is an extremely serious moment
 - [https://news.sky.com/story/beyond-the-balloon-watch-gimmicks-this-is-an-extremely-serious-moment-for-the-us-and-china-12803667](https://news.sky.com/story/beyond-the-balloon-watch-gimmicks-this-is-an-extremely-serious-moment-for-the-us-and-china-12803667)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-02-05 03:36:00+00:00
 - user: None

For beach-walking South Carolinians, it would have been quite the Saturday afternoon spectacle.&#160;
