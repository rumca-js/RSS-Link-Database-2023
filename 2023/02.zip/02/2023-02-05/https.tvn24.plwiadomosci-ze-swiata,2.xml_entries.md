# Source TVN24 Ze świata, Source URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, Source language: pl-PL

## Apel Papieża na zakończenie pielgrzymki w Sudanie: odłóżmy broń nienawiści i zemsty
 - [https://tvn24.pl/swiat/sudan-poludniowy-pielgrzymka-papieza-franciszka-odlozmy-bron-nienawisci-i-zemsty-6727403?source=rss](https://tvn24.pl/swiat/sudan-poludniowy-pielgrzymka-papieza-franciszka-odlozmy-bron-nienawisci-i-zemsty-6727403?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-02-05 10:49:35+00:00
 - user: None

<img alt="Apel Papieża na zakończenie pielgrzymki w Sudanie: odłóżmy broń nienawiści i zemsty  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dsq4t3-papiez-sudan-6727444/alternates/LANDSCAPE_1280" />
    W imię Jezusa, odłóżmy broń nienawiści i zemsty - apelował na zakończenie wizyty w Sudanie Południowym papież Franciszek. W mszy, którą odprawił w niedzielę w stolicy kraju Dżubie, uczestniczyło ponad 100 tysięcy osób. Po liturgii papież odleciał ze stołecznego lotniska do Rzymu. Pożegnał go prezydent Salva Kiir Mayardit.
