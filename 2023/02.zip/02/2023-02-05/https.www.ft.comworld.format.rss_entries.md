# Source Financial Times World, Source URL:https://www.ft.com/world?format=rss, Source language: en-US

## Billionaire Koch’s donor network says it opposes Trump’s re-election
 - [https://www.ft.com/content/72d8a8b3-6ac4-45a9-ab5a-53dc1c6c4998](https://www.ft.com/content/72d8a8b3-6ac4-45a9-ab5a-53dc1c6c4998)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 20:30:23+00:00
 - user: None

Americans for Prosperity joins other conservative groups in calling for Republicans to look beyond ex-president

## No signs of a thaw
 - [https://www.ft.com/content/b793807f-804d-49d6-8907-acb4f5ceb6a9](https://www.ft.com/content/b793807f-804d-49d6-8907-acb4f5ceb6a9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 18:15:54+00:00
 - user: None

US-China relations back in the deep freeze, no let up on UK strikes, and Beijing lifts more travel restrictions

## Sunak warned of Tory backlash if he tries to take UK out of ECHR
 - [https://www.ft.com/content/2117480f-a9e5-4768-b365-1eedc666bc40](https://www.ft.com/content/2117480f-a9e5-4768-b365-1eedc666bc40)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 17:53:36+00:00
 - user: None

PM told plans to ‘push boundaries’ of human rights law over migrant boats would lead to Commons rebellion

## Breakdown of gas storage talks leaves UK exposed to price surges, say experts
 - [https://www.ft.com/content/0ebf0cf1-af77-4670-90d6-ec060fd94f66](https://www.ft.com/content/0ebf0cf1-af77-4670-90d6-ec060fd94f66)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 17:00:20+00:00
 - user: None

Impasse over subsidies increases country’s dependence on expensive LNG imports

## Hong Kong: low base offers upside for local stocks
 - [https://www.ft.com/content/ec58f123-67bc-420e-946b-5fb550d3a411](https://www.ft.com/content/ec58f123-67bc-420e-946b-5fb550d3a411)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 17:00:20+00:00
 - user: None

Profit expectations are now low enough for Hong Kong companies to easily beat forecasts this year

## Peers seek public-interest clause for UK spy bill
 - [https://www.ft.com/content/7dd780a3-6e66-499f-9484-86f28547eb87](https://www.ft.com/content/7dd780a3-6e66-499f-9484-86f28547eb87)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 17:00:20+00:00
 - user: None

Amendment that aims to protect press freedom is attracting cross-party support

## Iran agrees to pardon ‘tens of thousands’ of prisoners
 - [https://www.ft.com/content/d1dd960b-5ada-4536-bf8d-ce81b70f9555](https://www.ft.com/content/d1dd960b-5ada-4536-bf8d-ce81b70f9555)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 15:17:36+00:00
 - user: None

Regime has been rocked by sustained period of civil unrest that erupted after death of woman in custody

## Did the UK economy dodge a recession last year?
 - [https://www.ft.com/content/3ac972af-6dea-43f5-b7e1-624fdb059e44](https://www.ft.com/content/3ac972af-6dea-43f5-b7e1-624fdb059e44)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 15:00:20+00:00
 - user: None

Market Questions is the FT’s guide to the week ahead

## France and Germany set to push back against US green tech poaching
 - [https://www.ft.com/content/bea6f909-b26f-46cb-8d55-7d5d282555b3](https://www.ft.com/content/bea6f909-b26f-46cb-8d55-7d5d282555b3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 14:56:32+00:00
 - user: None

Bruno Le Maire and Robert Habeck prepare to meet US officials amid tensions over subsidies

## How the spy balloon popped a US-China rapprochement
 - [https://www.ft.com/content/c993c00f-a6e7-413c-8396-09a38479eacd](https://www.ft.com/content/c993c00f-a6e7-413c-8396-09a38479eacd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 14:53:05+00:00
 - user: None

Relations between Washington and Beijing remain trapped in a downward spiral

## Pakistan is on the brink
 - [https://www.ft.com/content/9ea7f155-3c4e-48f0-8125-3f64faacf0eb](https://www.ft.com/content/9ea7f155-3c4e-48f0-8125-3f64faacf0eb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 14:00:20+00:00
 - user: None

Stark choices face the nuclear power and its creditors if it is to avoid default

## Truss draws fire after blaming ‘economic establishment’ for her downfall
 - [https://www.ft.com/content/88be6209-95e8-4ea1-ab39-ad5cdb678359](https://www.ft.com/content/88be6209-95e8-4ea1-ab39-ad5cdb678359)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 13:04:09+00:00
 - user: None

Tory minister joins market experts in dismissing former PM’s claims

## Workplace bullying should have no place in politics
 - [https://www.ft.com/content/043528e0-6273-4d91-8699-67a649b9dea2](https://www.ft.com/content/043528e0-6273-4d91-8699-67a649b9dea2)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 13:00:20+00:00
 - user: None

Civil servants who challenge the harmful behaviour of aggressive ministers are brave, not ‘snowflakey’

## Ukraine prepares for renewed Russian offensive
 - [https://www.ft.com/content/268bd522-4794-4f3d-895f-f58a55536af9](https://www.ft.com/content/268bd522-4794-4f3d-895f-f58a55536af9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 12:13:33+00:00
 - user: None

Warnings multiply of Kremlin’s plans for imminent attack in eastern Donbas region

## A bipolar currency regime will replace the dollar’s exorbitant privilege
 - [https://www.ft.com/content/e03d277a-e697-4220-a0ca-1f8a3dbecb75](https://www.ft.com/content/e03d277a-e697-4220-a0ca-1f8a3dbecb75)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 12:00:20+00:00
 - user: None

The greenback is bound sooner or later to feel the effects of intensifying geopolitical rivalry between the US and China

## Investors pile into market rally as economic slowdown risk ebbs
 - [https://www.ft.com/content/53b883de-decf-4d84-bb5e-661bb855b1fd](https://www.ft.com/content/53b883de-decf-4d84-bb5e-661bb855b1fd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 12:00:20+00:00
 - user: None

Improving outlook boosts demand for riskier assets as ‘fear of missing out’ returns

## The case for a land value tax is overwhelming
 - [https://www.ft.com/content/fadfbd9e-29ca-4d53-b69a-2497cc3ed95d](https://www.ft.com/content/fadfbd9e-29ca-4d53-b69a-2497cc3ed95d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 12:00:20+00:00
 - user: None

Natural resources are quite different from the capital stock created out of human effort

## US companies say EU climate goals are deterring new gas deals
 - [https://www.ft.com/content/5f13fee7-dc04-4f47-bd06-cfbb3c444011](https://www.ft.com/content/5f13fee7-dc04-4f47-bd06-cfbb3c444011)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 12:00:20+00:00
 - user: None

Buyers fear long-term supply contracts will conflict with carbon-neutral targets, according to executives

## A problem of logistics: is the US sending Ukraine the wrong tank?
 - [https://www.ft.com/content/679ba852-1d7e-4d17-890d-2bc6152c96b0](https://www.ft.com/content/679ba852-1d7e-4d17-890d-2bc6152c96b0)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 11:00:20+00:00
 - user: None

The Abrams demonstrates the pitfalls of Washington’s overcomplicated defence procurement system

## Electric vehicles defy price war after Ford and Tesla discounts
 - [https://www.ft.com/content/ffb0f01d-e341-4402-817e-087074312862](https://www.ft.com/content/ffb0f01d-e341-4402-817e-087074312862)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 11:00:20+00:00
 - user: None

GM, Volkswagen, Hyundai and Kia decline to follow competitors as customer demand persists

## Adani ditched Big Four auditor for UK subsidiaries
 - [https://www.ft.com/content/dd03f08a-a7e5-4120-bff0-30e910191695](https://www.ft.com/content/dd03f08a-a7e5-4120-bff0-30e910191695)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 10:29:50+00:00
 - user: None

Indian conglomerate’s accounting practices have drawn scrutiny after short-selling report

## Violent end to spy balloon flight dashes chance of US-China reset
 - [https://www.ft.com/content/e155b6e1-66ab-4fa4-b390-ac72a1d66d4c](https://www.ft.com/content/e155b6e1-66ab-4fa4-b390-ac72a1d66d4c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 10:00:20+00:00
 - user: None

Uncertainty in Washington over whether Xi Jinping was aware of surveillance mission

## Former Pakistan military ruler Pervez Musharraf dies
 - [https://www.ft.com/content/c40a370b-4369-4e95-90fd-dbd0464d6bd3](https://www.ft.com/content/c40a370b-4369-4e95-90fd-dbd0464d6bd3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 09:02:48+00:00
 - user: None

General led country through aftermath of 9/11 attacks

## Baillie Gifford sheds more than £100bn in assets in 2022
 - [https://www.ft.com/content/ad70bffc-78e1-4370-87e4-9dfe63d5e987](https://www.ft.com/content/ad70bffc-78e1-4370-87e4-9dfe63d5e987)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 05:00:21+00:00
 - user: None

Growth investor suffers as interest rates rises prompt sell-off in tech stocks

## Cradle to grave: is Britain’s NHS broken?
 - [https://www.ft.com/content/d9db05e7-bb1c-4f38-9a02-bd6b66c9c99b](https://www.ft.com/content/d9db05e7-bb1c-4f38-9a02-bd6b66c9c99b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 05:00:21+00:00
 - user: None

The UK’s national health system is showing signs of frailty as it nears its 75th birthday

## Plight of Saakashvili casts shadow on Georgia’s EU aspirations
 - [https://www.ft.com/content/8a3b2307-7e5e-4ec6-8913-834e3d13921e](https://www.ft.com/content/8a3b2307-7e5e-4ec6-8913-834e3d13921e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 05:00:21+00:00
 - user: None

Health of former president has deteriorated rapidly in detention, amid allegations of poisoning

## Turkey and Syria face challenge to mend ties after years of ‘zero trust’
 - [https://www.ft.com/content/2658b1e8-8623-48be-a8aa-40c59feaab92](https://www.ft.com/content/2658b1e8-8623-48be-a8aa-40c59feaab92)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 05:00:21+00:00
 - user: None

Ankara’s cross-border incursions and control over northern areas complicate talks

## La Bayadère boys
 - [https://www.ft.com/content/4f930550-fe78-46aa-b32b-9495519600a7](https://www.ft.com/content/4f930550-fe78-46aa-b32b-9495519600a7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 04:55:20+00:00
 - user: None

In their restaging of the Bolshoi classic, dancer Benjamin Pech and artist Ignasi Monreal have created the perfect pas de deux

## Toyota’s new chief set to steer conventional course towards electric future
 - [https://www.ft.com/content/0e8c0bfe-3783-46d3-a740-8a9cba7724b3](https://www.ft.com/content/0e8c0bfe-3783-46d3-a740-8a9cba7724b3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 01:00:20+00:00
 - user: None

‘Car guy’ Koji Sato tasked with reshaping strategy of world’s biggest carmaker

## Covid fears kill Japan’s travel bug
 - [https://www.ft.com/content/86f5f643-149b-46ed-acb5-9bbc1d53a027](https://www.ft.com/content/86f5f643-149b-46ed-acb5-9bbc1d53a027)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 00:30:20+00:00
 - user: None

Taboos around spreading coronavirus and weak yen keep travellers home and industry ailing

## Death and Japan’s nuclear shelter salesman
 - [https://www.ft.com/content/5dbd0e08-5eec-4486-a1ba-fe1948d11159](https://www.ft.com/content/5dbd0e08-5eec-4486-a1ba-fe1948d11159)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-02-05 00:01:22+00:00
 - user: None

Khrushchev once speculated that the survivors of the apocalypse would envy the dead. I agree
