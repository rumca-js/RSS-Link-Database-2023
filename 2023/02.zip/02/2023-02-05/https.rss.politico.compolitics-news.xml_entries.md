# Source Politico, Source URL:https://rss.politico.com/politics-news.xml, Source language: en-US

## Koch network looking away from Trump in GOP presidential primary
 - [https://www.politico.com/news/2023/02/05/koch-network-donald-trump-endorse-00081237](https://www.politico.com/news/2023/02/05/koch-network-donald-trump-endorse-00081237)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-02-05 12:25:58+00:00
 - user: None

"The best thing for the country would be to have a president in 2025 who represents a new chapter," a letter from the organization's CEO, Emily Seidel, said.
