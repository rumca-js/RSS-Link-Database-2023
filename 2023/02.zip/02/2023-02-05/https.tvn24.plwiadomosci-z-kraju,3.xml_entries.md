# Source TVN24 Z kraju, Source URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, Source language: pl-PL

## Reznikow przestaje być ministrem obrony, znany jest jego następca
 - [https://tvn24.pl/swiat/ukraina-oleksij-reznikow-juz-nie-bedzie-ministrem-obrony-jego-nastepca-ma-byc-kyrylo-budanow-6728111?source=rss](https://tvn24.pl/swiat/ukraina-oleksij-reznikow-juz-nie-bedzie-ministrem-obrony-jego-nastepca-ma-byc-kyrylo-budanow-6728111?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 21:38:24+00:00
 - user: None

<img alt="Reznikow przestaje być ministrem obrony, znany jest jego następca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vc60uj-oleksij-reznikow-6728113/alternates/LANDSCAPE_1280" />
    Ołeksij Reznikow, dotychczasowy minister obrony Ukrainy, żegna się z tym stanowiskiem - przekazał w mediach społecznościowych szef frakcji prezydenckiej partii Sługa Narodu Dawid Arachamija. Jednocześnie poinformował, że jego miejsce zajmie obecny szef ukraińskiego wywiadu wojskowego (HUR) generał Kyryło Budanow. Reznikow pozostanie jednak w rządzie jako minister do spraw strategicznych gałęzi gospodarki.

## Papież: jestem gotów spotkać się z prezydentami Rosji i Ukrainy
 - [https://tvn24.pl/swiat/ukraina-rosja-watykan-papiez-jestem-gotow-spotkac-sie-z-prezydentami-rosji-i-ukrainy-6728019?source=rss](https://tvn24.pl/swiat/ukraina-rosja-watykan-papiez-jestem-gotow-spotkac-sie-z-prezydentami-rosji-i-ukrainy-6728019?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 21:08:58+00:00
 - user: None

<img alt="Papież: jestem gotów spotkać się z prezydentami Rosji i Ukrainy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fax1no-papiez-franciszek-6728017/alternates/LANDSCAPE_1280" />
    Jestem otwarty na spotkanie z dwoma prezydentami, Ukrainy i Rosji - przekazał w niedzielę dziennikarzom papież Franciszek. Wyjaśnił, że nie pojechał dotąd do Kijowa, ponieważ nie ma możliwości udania się również do Moskwy

## Lawiny w Austrii. Znaleziono ciała pięciu ofiar
 - [https://tvn24.pl/tvnmeteo/swiat/lawiny-w-austrii-tyrol-znaleziono-ciala-pieciu-ofiar-6727940?source=rss](https://tvn24.pl/tvnmeteo/swiat/lawiny-w-austrii-tyrol-znaleziono-ciala-pieciu-ofiar-6727940?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 20:30:15+00:00
 - user: None

<img alt="Lawiny w Austrii. Znaleziono ciała pięciu ofiar" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-0xm7sk-dolina-oetztal-austria-6725997/alternates/LANDSCAPE_1280" />
    Ciała pięciu ofiar lawin odnaleziono w niedzielę w Tyrolu w południowo-zachodniej Austrii. W ciągu weekendu zginęło w tym regionie łącznie ośmiu turystów i narciarzy, a wcześniej, w piątek - jedna osoba. Jak podkreślają miejscowe służby, część urlopowiczów lekceważy komunikaty i ostrzeżenia dotyczące sytuacji pogodowej i możliwych zagrożeń.

## Zmasowany atak hakerski we Włoszech
 - [https://tvn24.pl/swiat/wlochy-zmasowany-atak-hakerski-6728034?source=rss](https://tvn24.pl/swiat/wlochy-zmasowany-atak-hakerski-6728034?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 19:25:44+00:00
 - user: None

<img alt="Zmasowany atak hakerski we Włoszech" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3l1438-rzym-5814598/alternates/LANDSCAPE_1280" />
    We Włoszech doszło do zmasowanego ataku hakerskiego na tysiące serwerów i dziesiątki krajowych systemów - przekazała włoska agencja do spraw cyberbezpieczeństwa. Nie podano, skąd pochodzi atak.

## Szewach Weiss został pochowany na cmentarzu w Jerozolimie
 - [https://tvn24.pl/swiat/izrael-szewach-weiss-zostal-pochowany-na-cmentarzu-w-jerozolimie-6727943?source=rss](https://tvn24.pl/swiat/izrael-szewach-weiss-zostal-pochowany-na-cmentarzu-w-jerozolimie-6727943?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 19:15:34+00:00
 - user: None

<img alt="Szewach Weiss został pochowany na cmentarzu w Jerozolimie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c9gpyl-szewach-weiss-6726800/alternates/LANDSCAPE_1280" />
    Szewach Weiss, były ambasador Izraela w Polsce i były przewodniczący Knesetu, został w niedzielę pochowany na cmentarzu na Wzgórzu Herzla w Jerozolimie, w kwaterze najważniejszych przywódców izraelskich. Zmarł w piątek w wieku 87 lat.

## Pogoda na jutro - poniedziałek 6.02. Bardzo mroźna noc, za dnia jest szansa na chwile ze słońcem
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-poniedzialek-602-bardzo-mrozna-noc-za-dnia-jest-szansa-na-chwile-ze-sloncem-6728012?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-poniedzialek-602-bardzo-mrozna-noc-za-dnia-jest-szansa-na-chwile-ze-sloncem-6728012?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 18:10:26+00:00
 - user: None

<img alt="Pogoda na jutro - poniedziałek 6.02. Bardzo mroźna noc, za dnia jest szansa na chwile ze słońcem" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-grzaai-mrozna-noc-6728024/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. W nocy możemy spodziewać się bardzo dużego mrozu. Poniedziałek przyniesie nam chmury, ale w wieku regionach kraju prognozowane są przejaśnienia. Za dnia termometry wskażą od -5 do 3 stopni Celsjusza.

## Problemy na drogach, wstrzymane rejsy. Front Barbara przyniósł Grecji ogromne śnieżyce
 - [https://tvn24.pl/tvnmeteo/swiat/problemy-na-drogach-wstrzymane-rejsy-front-barbara-przyniosl-grecji-ogromne-sniezyce-6727944?source=rss](https://tvn24.pl/tvnmeteo/swiat/problemy-na-drogach-wstrzymane-rejsy-front-barbara-przyniosl-grecji-ogromne-sniezyce-6727944?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 17:25:08+00:00
 - user: None

<img alt="Problemy na drogach, wstrzymane rejsy. Front Barbara przyniósł Grecji ogromne śnieżyce" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-1mu8y3-front-barbara-szaleje-w-grecji-6727976/alternates/LANDSCAPE_1280" />
    Zima gwałtownie wtargnęła do Grecji. Stało się to za sprawą frontu atmosferycznego Barbara, który przyniósł wielu regionom kraju intensywne opady śniegu i porywisty wiatr. Transport - zarówno drogowy, jaki i morski - jest znacząco utrudniony.

## Wikingowie mogli podróżować z psami, końmi, świniami. Naukowcy znaleźli pierwszy dowód
 - [https://tvn24.pl/tvnmeteo/nauka/wikingowie-mogli-podrozowac-z-psami-konmi-swiniami-naukowcy-znalezli-pierwszy-dowod-6727912?source=rss](https://tvn24.pl/tvnmeteo/nauka/wikingowie-mogli-podrozowac-z-psami-konmi-swiniami-naukowcy-znalezli-pierwszy-dowod-6727912?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 16:52:30+00:00
 - user: None

<img alt="Wikingowie mogli podróżować z psami, końmi, świniami. Naukowcy znaleźli pierwszy dowód" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-cwxb8o-wikingowie-mogli-podrozowac-z-zywym-inwentarzem-6727913/alternates/LANDSCAPE_1280" />
    Wikingowie od IX wieku mogli zabierać ze sobą na wyprawy żywe zwierzęta, w tym konie i psy. Do takiego wniosku doszedł międzynarodowy zespół naukowców, który przeanalizował szczątki znalezione w miejscu pochówku w angielskim hrabstwie Derbyshire. Wyniki, jakie uzyskano, to - podkreślają badacze - pierwszy dowód takiej praktyki.

## Chciała uniknąć zderzenia z innym autem, wjechała na chodnik. "Potrąciła stojącą przed przejściem 65-latkę"
 - [https://tvn24.pl/bialystok/zamosc-chciala-uniknac-zderzenia-z-innym-autem-wjechala-na-chodnik-potracila-piesza-policja-apeluje-o-ostroznosc-6727929?source=rss](https://tvn24.pl/bialystok/zamosc-chciala-uniknac-zderzenia-z-innym-autem-wjechala-na-chodnik-potracila-piesza-policja-apeluje-o-ostroznosc-6727929?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 16:09:58+00:00
 - user: None

<img alt="Chciała uniknąć zderzenia z innym autem, wjechała na chodnik. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vvrz6c-chciala-uniknac-zderzenia-z-innym-autem-wjechala-na-chodnik-i-uderzyla-w-piesza-6727904/alternates/LANDSCAPE_1280" />
    Było ślisko, a 34-latka, która w Zamościu (woj. lubelskie) jechała suzuki, chciała uniknąć zderzenia z jadącym przed nią autem. Wjechała na chodnik i potrąciła stojącą przed przejściem 65-latkę. Kobieta trafiła do szpitala. Policja apeluje o ostrożność. - Zwłaszcza teraz, gdy warunki drogowe są trudne. Na jezdniach jest ślisko i bardzo niebezpiecznie - podkreślają funkcjonariusze.

## Rosja "lubi symbole". Ukraińcy spodziewają się ofensywy w związku z rocznicą inwazji zbrojnej
 - [https://tvn24.pl/swiat/ukraina-oleksij-reznikow-rosjanie-lubia-symbole-ukraincy-spodziewaja-sie-ofensywy-w-zwiazku-z-rocznica-inwazji-6727871?source=rss](https://tvn24.pl/swiat/ukraina-oleksij-reznikow-rosjanie-lubia-symbole-ukraincy-spodziewaja-sie-ofensywy-w-zwiazku-z-rocznica-inwazji-6727871?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 15:42:18+00:00
 - user: None

<img alt="Rosja " src="https://tvn24.pl/najnowsze/cdn-zdjecie-agm33k-ukraina-wojsko-6727882/alternates/LANDSCAPE_1280" />
    W lutym może dojść do ofensywy wojsk rosyjskich, ponieważ Rosjanie lubią symbole - powiedział w niedzielę minister obrony Ołeksij Reznikow. 24 lutego minie rok od rozpoczęcia inwazji zbrojnej Rosji na Ukrainę.

## Iran. Władze informują o dziesiątkach tysięcy ułaskawień
 - [https://tvn24.pl/swiat/iran-wladze-informuja-o-dziesiatkach-tysiecy-ulaskawien-takze-dla-uczestnikow-antyrzadowych-protestow-6727768?source=rss](https://tvn24.pl/swiat/iran-wladze-informuja-o-dziesiatkach-tysiecy-ulaskawien-takze-dla-uczestnikow-antyrzadowych-protestow-6727768?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 15:01:02+00:00
 - user: None

<img alt="Iran. Władze informują o dziesiątkach tysięcy ułaskawień" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bo426z-ajatollah-ali-chamenei-5133156/alternates/LANDSCAPE_1280" />
    Państwowa irańska agencja IRNA poinformowała w niedzielę, że ajatollah Ali Chamenei, duchowy oraz polityczny przywódca Iranu, ułaskawił dziesiątki tysięcy skazanych, w tym także wielu aresztowanych podczas ostatnich antyrządowych protestów. Decyzję ogłoszono na cześć rocznicy rewolucji islamskiej z 1979 roku, a ułaskawienie obarczone jest warunkami.

## Na budowie dworca odnaleźli części pieca kaflowego z XVIII wieku
 - [https://tvn24.pl/tvnwarszawa/ochota/warszawa-na-dworcu-zachodnim-znaleziono-czesci-pieca-kaflowego-6725843?source=rss](https://tvn24.pl/tvnwarszawa/ochota/warszawa-na-dworcu-zachodnim-znaleziono-czesci-pieca-kaflowego-6725843?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 15:00:11+00:00
 - user: None

<img alt="Na budowie dworca odnaleźli części pieca kaflowego z XVIII wieku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-is1db7-czesci-pieca-kaflowego-znalezione-na-dworcu-zachodnim-6725855/alternates/LANDSCAPE_1280" />
    Niezwykłe znalezisko odkryto podczas prac budowlanych, prowadzonych na Dworcu Zachodnim. Odkopano części pieca kaflowego, pochodzącego prawdopodobnie z XVIII wieku. Zostały przekazane konserwatorowi zabytków.

## Ratownicy przyjechali pomóc 77-latkowi. Ten w zamian obrzucił ich obelgami, jednego kopnął w brzuch
 - [https://tvn24.pl/pomorze/gdansk-atak-na-ratownikow-medycznych-zniewazyl-ich-jednego-kopnal-w-brzuch-zarzuty-dla-77-latka-6727777?source=rss](https://tvn24.pl/pomorze/gdansk-atak-na-ratownikow-medycznych-zniewazyl-ich-jednego-kopnal-w-brzuch-zarzuty-dla-77-latka-6727777?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 14:42:21+00:00
 - user: None

<img alt="Ratownicy przyjechali pomóc 77-latkowi. Ten w zamian obrzucił ich obelgami, jednego kopnął w brzuch" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qacfhp-77-latek-uslyszal-zarzuty-po-ataku-na-ratownikow-medycznych-6727767/alternates/LANDSCAPE_1280" />
    Pogotowie zostało wezwane na pomoc leżącemu na przystanku w Gdańsku mężczyźnie. Jak informuje policja, podczas badania w ambulansie 77-latek zaczął ubliżać ratownikom, a jednego kopnął. Był pijany. Mężczyzna usłyszał zarzuty znieważenia ratowników i naruszenia nietykalności cielesnej jednego z nich.

## "Miękki reset" w branży. "Liczby i tak są ogromne"
 - [https://tvn24.pl/biznes/tech/gaming-2022-2023-premiery-komentarze-jane-knap-grzegorz-bobrek-maciej-kietlinski-6683496?source=rss](https://tvn24.pl/biznes/tech/gaming-2022-2023-premiery-komentarze-jane-knap-grzegorz-bobrek-maciej-kietlinski-6683496?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 13:44:55+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ciq6hp-shutterstock625912973-6727753/alternates/LANDSCAPE_1280" />
    Dwa lata temu wystarczyło wziąć listę spółek gamingowych z polskiego rynku, rzucić w nią kamieniem. W co by się nie trafiło, to to rosło. Dziś wszyscy chcą, aby sektor się odbił - stwierdza w rozmowie z TVN24 Biznes Maciej Kietliński z Domu Maklerskiego XTB. W 2022 roku sektor zaliczył miękki reset. - Chociaż te liczby i tak są ogromne - zaznacza Grzegorz Bobrek, były szef TVgry, współzałożyciel kanału To Znowu Oni dodając, że na świecie oczy zwrócone są na największe przejęcie w historii branży za 68 miliardów dolarów.

## Jechał za szybko, policjant chciał go zatrzymać do kontroli.  "Potrącił funkcjonariusza i uciekł"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/ostroleka-policjant-chcial-go-zatrzymac-do-kontroli-kierujacy-mazda-potracil-funkcjonariusza-uciekl-oblawa-i-zatrzymanie-6727709?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/ostroleka-policjant-chcial-go-zatrzymac-do-kontroli-kierujacy-mazda-potracil-funkcjonariusza-uciekl-oblawa-i-zatrzymanie-6727709?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 13:11:45+00:00
 - user: None

<img alt="Jechał za szybko, policjant chciał go zatrzymać do kontroli.  " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-k9zyxo-policja-bada-sprawe-6062482/alternates/LANDSCAPE_1280" />
    Potrącenie policjanta, ucieczka, a później policyjna obława. Funkcjonariusze zatrzymali młodego mężczyznę, który nie chciał zatrzymać się do kontroli. Ranił mundurowego i uciekł, był pijany.

## Aleje w centrum Krakowa zapierają dech. Polski Alarm Smogowy: to miejsce o najgorszym powietrzu w Polsce
 - [https://tvn24.pl/krakow/krakow-aleje-trzech-wieszczow-z-najgorszym-powietrzem-w-polsce-polski-alarm-smogowy-pomoze-strefa-czystego-transportu-6725635?source=rss](https://tvn24.pl/krakow/krakow-aleje-trzech-wieszczow-z-najgorszym-powietrzem-w-polsce-polski-alarm-smogowy-pomoze-strefa-czystego-transportu-6725635?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 12:57:35+00:00
 - user: None

<img alt="Aleje w centrum Krakowa zapierają dech. Polski Alarm Smogowy: to miejsce o najgorszym powietrzu w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecief2b25e8e977ddfef1e885d7824e11545-smog-wisi-nad-krakowem-4279924/alternates/LANDSCAPE_1280" />
    Aleje Trzech Wieszczów w Krakowie są miejscem o najbardziej zanieczyszczonym powietrzu w Polsce - wynika z informacji przekazanych przez Polski Alarm Smogowy. Poziom smogu był tam przekroczony w 2022 roku aż 96 razy, podczas gdy przepisy dopuszczają 35 takich "smogowych" dni w skali roku. Zdaniem aktywistów sytuację może uratować zapowiadana Strefa Czystego Transportu.

## Usunięto awarie ciepłownicze w Jastrzębiu-Zdroju. Ponad 23 tysiące mieszkań było bez ciepła
 - [https://tvn24.pl/katowice/jastrzebie-zdroj-awaria-cieplownicza-usunieta-ponad-23-tys-mieszkan-pozostawalo-bez-ciepla-6727625?source=rss](https://tvn24.pl/katowice/jastrzebie-zdroj-awaria-cieplownicza-usunieta-ponad-23-tys-mieszkan-pozostawalo-bez-ciepla-6727625?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 12:05:50+00:00
 - user: None

<img alt="Usunięto awarie ciepłownicze w Jastrzębiu-Zdroju. Ponad 23 tysiące mieszkań było bez ciepła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tw0gns-kaloryfer-shutterstock781785535-5028810/alternates/LANDSCAPE_1280" />
    Lokatorzy ponad 23 tysięcy mieszkań w Jastrzębiu-Zdroju (woj. śląskie) mieli w niedzielę zimne kaloryfery. To efekt awarii ciepłowniczych, do których doszło w mieście. Problemy dotyczyły mieszkańców ponad 70 ulic. Rzecznik spółki PGNiG Termika Energetyka poinformował wieczorem, że usunięto obie awarie. Dodał, że jeszcze najbliższej nocy dostawy ciepła powinny zostać przywrócone do wszystkich mieszkań.

## Szlabany były opuszczone, pieszy wszedł na tory. Nagrał go policyjny dron
 - [https://tvn24.pl/katowice/gliwice-pieszy-wszedl-na-zamkniety-przejazd-kolejowy-nagral-go-dron-moze-zaplacic-wysoki-mandat-6727534?source=rss](https://tvn24.pl/katowice/gliwice-pieszy-wszedl-na-zamkniety-przejazd-kolejowy-nagral-go-dron-moze-zaplacic-wysoki-mandat-6727534?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 11:43:05+00:00
 - user: None

<img alt="Szlabany były opuszczone, pieszy wszedł na tory. Nagrał go policyjny dron" src="https://tvn24.pl/krakow/cdn-zdjecie-1wnsg8-szlabany-byly-opuszczone-pieszy-wszedl-na-tory-6727511/alternates/LANDSCAPE_1280" />
    Policjanci z Gliwic (woj. śląskie) kontrolowali przy pomocy drona zachowanie kierowców w rejonie przejazdów kolejowych. Przy okazji nagrali pieszego, który przeszedł pod zamkniętym szlabanem, żeby pokonać tory. Teraz grozi mu mandat w wysokości dwóch tysięcy złotych.

## Oficjalnie otwarta, ale jeszcze nieprzejezdna. Kiedy kierowcy pojadą obwodnicą Grodziska?
 - [https://tvn24.pl/tvnwarszawa/najnowsze/grodzisk-mazowiecki-obwodnica-oficjalnie-otwarta-ale-jeszcze-nieprzejezdna-kiedy-kierowcy-pojada-obwodnica-grodziska-6727249?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/grodzisk-mazowiecki-obwodnica-oficjalnie-otwarta-ale-jeszcze-nieprzejezdna-kiedy-kierowcy-pojada-obwodnica-grodziska-6727249?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 11:19:13+00:00
 - user: None

<img alt="Oficjalnie otwarta, ale jeszcze nieprzejezdna. Kiedy kierowcy pojadą obwodnicą Grodziska? " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5rvzr2-obwodnica-grodziska-mazowieckiego-6727425/alternates/LANDSCAPE_1280" />
    W sobotę oficjalnie została otwarta obwodnica Grodziska Mazowieckiego. Przy przecięciu symbolicznej wstęgi byli nie tylko urzędnicy, ale również mieszkańcy, dla których przygotowano wiele atrakcji. Dla kierowców jednak trasa będzie przejezdna od poniedziałku.

## Zapora elektroniczna na granicy z Rosją. Rzecznika Straży Granicznej: prace powinny ruszyć w marcu
 - [https://tvn24.pl/polska/rosja-granica-z-obwodem-kaliningradzkim-rzecznika-strazy-granicznej-prace-nad-budowa-zapory-powinny-ruszyc-w-marcu-6727525?source=rss](https://tvn24.pl/polska/rosja-granica-z-obwodem-kaliningradzkim-rzecznika-strazy-granicznej-prace-nad-budowa-zapory-powinny-ruszyc-w-marcu-6727525?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 11:13:57+00:00
 - user: None

<img alt="Zapora elektroniczna na granicy z Rosją. Rzecznika Straży Granicznej: prace powinny ruszyć w marcu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d4t2al-granica-polski-z-obwodem-kaliningradzkim-6727529/alternates/LANDSCAPE_1280" />
    Na granicy Polski z rosyjskim obwodem kaliningradzkim stanie bariera elektroniczna, której budowa powinna rozpocząć się w marcu - przekazała rzecznika Straży Granicznej porucznik Anna Michalska. System elektroniczny na tym odcinku będzie przebiegał na około 200 kilometrach granicy lądowej.

## Wymienią zepsute wyświetlacze w tramwajach
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-tramwaje-jazz-wymienia-zepsute-wyswietlacze-kiedy-6727304?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-tramwaje-jazz-wymienia-zepsute-wyswietlacze-kiedy-6727304?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 10:50:36+00:00
 - user: None

<img alt="Wymienią zepsute wyświetlacze w tramwajach" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ikio6i-tramwaj-jazz-134n-45183/alternates/LANDSCAPE_1280" />
    Tramwaje Warszawskie poinformowały, że wiosną producent składów typu Jazz rozpocznie wymianę zepsutych wyświetlaczy. Prace zakończą się w 2024 roku.

## "Mieliśmy wypadek, mojemu tacie leci krew z ust". 10-letni Miłosz wezwał pomoc. "Uratował mi życie"
 - [https://tvn24.pl/lodz/radomsko-lodz-rozbite-auto-na-autostradzie-a1-w-srodku-10-letni-milosz-i-nieprzytomny-tata-chlopiec-zostal-bohaterem-6724798?source=rss](https://tvn24.pl/lodz/radomsko-lodz-rozbite-auto-na-autostradzie-a1-w-srodku-10-letni-milosz-i-nieprzytomny-tata-chlopiec-zostal-bohaterem-6724798?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 09:39:03+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xmx545-10-letni-milosz-pomogl-swojemu-ojcu-po-zdarzeniu-na-a1-6727405/alternates/LANDSCAPE_1280" />
    10-letni Miłosz z Radomska (Łódzkie) uratował życie swojemu ojczymowi po tym, jak ten stracił przytomność, a samochód, którym jechali autostradą A1, uderzył w przydrożne barierki. Chłopiec zadzwonił pod numer alarmowy 112 i przez blisko pół godziny rozmawiał z operatorką, która instruowała go, co ma robić do czasu przyjazdu służb.

## Tąpnięcie w liczbie zdjęć z fotoradarów. Rekordzista z "zakrętu mistrzów"
 - [https://tvn24.pl/biznes/moto/fotoradary-2022-fotoradary-zrobily-mniej-zdjec-najbardziej-zapracowany-fotoradar-w-polsce-gitd-podal-nowe-dane-6727314?source=rss](https://tvn24.pl/biznes/moto/fotoradary-2022-fotoradary-zrobily-mniej-zdjec-najbardziej-zapracowany-fotoradar-w-polsce-gitd-podal-nowe-dane-6727314?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 09:35:19+00:00
 - user: None

<img alt="Tąpnięcie w liczbie zdjęć z fotoradarów. Rekordzista z " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v7lbs2-droga-samochody-6683460/alternates/LANDSCAPE_1280" />
    Fotoradary w Polsce w 2022 roku zrobiły znacznie mniej zdjęć niż rok wcześniej. - Statystyki są bardzo pozytywne. W ubiegłym roku zarejestrowaliśmy o blisko pół miliona naruszeń mniej - poinformowała Monika Niżniak, rzeczniczka prasowa Głównego Inspektoratu Transportu Drogowego (GITD). Materiał z programu "Raport" w TVN Turbo.

## Aleje Jerozolimskie: pięć aut rozbitych, jedno na barierach
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-aleje-jerozolimskie-piec-aut-rozbitych-jedno-na-barierach-6727358?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-aleje-jerozolimskie-piec-aut-rozbitych-jedno-na-barierach-6727358?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 09:34:46+00:00
 - user: None

<img alt="Aleje Jerozolimskie: pięć aut rozbitych, jedno na barierach " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-iszmtx-kolizja-w-alejach-jerozolimskich-6727366/alternates/LANDSCAPE_1280" />
    Do poważnie wyglądającej kolizji doszło w sobotę wieczorem w Alejach Jerozolimskich. Jak informuje policja, uczestniczyło w niej pięć samochodów osobowych.

## Biegacze inaugurują sezon. Kierowcy pojadą objazdami, zmiany w rozkładach komunikacji miejskiej
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-bieg-chomiczowki-i-bieg-o-puchar-bielan-trasa-mapy-utrudnienia-w-ruchu-6726276?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-bieg-chomiczowki-i-bieg-o-puchar-bielan-trasa-mapy-utrudnienia-w-ruchu-6726276?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 08:29:27+00:00
 - user: None

<img alt="Biegacze inaugurują sezon. Kierowcy pojadą objazdami, zmiany w rozkładach komunikacji miejskiej " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-uzifye-bieg-chomiczowki-6726416/alternates/LANDSCAPE_1280" />
    Dwa tysiące osób wystartuje w niedzielę, w 40. Biegu Chomiczówki na dystansie 15 km oraz w 16. Biegu o Puchar Bielan na 5 kilometrów Imprezy inaugurują sezon biegowy w stolicy. Będą utrudnienia dla kierowców i pasażerów komunikacji miejskiej.

## To ma być kolejny cios w Kreml. Nowe przepisy weszły w życie
 - [https://tvn24.pl/biznes/ze-swiata/rosja-unia-europejska-embargo-na-paliwa-olej-napedowy-z-rosji-weszlo-w-zycie-6727254?source=rss](https://tvn24.pl/biznes/ze-swiata/rosja-unia-europejska-embargo-na-paliwa-olej-napedowy-z-rosji-weszlo-w-zycie-6727254?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 07:41:24+00:00
 - user: None

<img alt="To ma być kolejny cios w Kreml. Nowe przepisy weszły w życie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4p2c7l-mid-epa10444686-6727275/alternates/LANDSCAPE_1280" />
    Unijne embargo na import rosyjskich paliw gotowych weszło w życie. Eksperci nie spodziewają się zakłóceń na rynku po wprowadzeniu zakazu. - Wprowadzenie embarga na paliwa z Rosji zapowiedziano bowiem ponad pół roku temu. Dlatego był odpowiedni czas, by wszyscy się do tego przygotowali - stwierdził główny ekonomista PKN Orlen Adam Czyżewski.

## Niemieckie Patrioty w Polsce. Bundeswehra pokazała zdjęcia w "zimowej scenerii"
 - [https://tvn24.pl/swiat/systemy-patriot-w-polsce-niemiecka-armia-pokazala-zdjecia-w-zimowej-scenerii-6727264?source=rss](https://tvn24.pl/swiat/systemy-patriot-w-polsce-niemiecka-armia-pokazala-zdjecia-w-zimowej-scenerii-6727264?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 07:38:08+00:00
 - user: None

<img alt="Niemieckie Patrioty w Polsce. Bundeswehra pokazała zdjęcia w " src="https://tvn24.pl/najnowsze/cdn-zdjecie-anuo02-niemieckie-patrioty-w-polsce-6727266/alternates/LANDSCAPE_1280" />
    Siły zbrojne Niemiec pokazały zdjęcia niemieckich systemów obrony powietrznej Patriot, które pod koniec stycznia rozlokowano w okolicach Zamościa, niedaleko granicy z Ukrainą. Wyrzutnie wraz z systemami dowodzenia sfotografowano na zaśnieżonym polu. Patrioty Bundeswehry zostały włączone do polskiego systemu dowodzenia.

## Pogoda na dziś - niedziela 5.02. Mroźno w wielu regionach, lokalnie możliwy śnieg
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-niedziela-502-mrozno-w-wielu-regionach-lokalnie-mozliwy-snieg-6727172?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-niedziela-502-mrozno-w-wielu-regionach-lokalnie-mozliwy-snieg-6727172?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-02-05 01:00:00+00:00
 - user: None

<img alt="Pogoda na dziś - niedziela 5.02. Mroźno w wielu regionach, lokalnie możliwy śnieg" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i63817-mroz-szron-5009366/alternates/LANDSCAPE_1280" />
    Pogoda na dziś, czyli niedzielę 5.02, przyniesie mróz w wielu regionach. Temperatura spadnie nawet do -5 stopni Celsjusza. Lokalnie mogą wystąpić opady śniegu. W całym kraju aura nie będzie sprzyjała naszemu samopoczuciu.
