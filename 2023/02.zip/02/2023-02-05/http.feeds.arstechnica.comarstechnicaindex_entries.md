# Source ArsTechnica, Source URL:http://feeds.arstechnica.com/arstechnica/index/, Source language: en-US

## Proposals but no consensus on curbing water shortages in Colorado River basin
 - [https://arstechnica.com/?p=1915001](https://arstechnica.com/?p=1915001)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-05 12:21:46+00:00
 - user: None

6 of 7 states proposed downstream reductions, but California wants to avoid cuts.

## Vanpowers City Vanture e-bike review: Sleek, streamlined, and hard to define
 - [https://arstechnica.com/?p=1912001](https://arstechnica.com/?p=1912001)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-02-05 12:00:42+00:00
 - user: None

There aren't many e-bikes like it—partly because you can build it yourself.
