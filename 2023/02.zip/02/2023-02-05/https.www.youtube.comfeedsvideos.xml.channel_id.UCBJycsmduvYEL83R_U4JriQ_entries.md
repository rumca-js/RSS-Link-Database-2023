# Source Marques Brownlee, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, Source language: en-US

## AI-Generated Music is Wild!
 - [https://www.youtube.com/watch?v=gyXjazZnJAU](https://www.youtube.com/watch?v=gyXjazZnJAU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2023-02-05 01:38:57+00:00
 - user: None

AI is incredible, but it's not taking anyone's jobs... yet
