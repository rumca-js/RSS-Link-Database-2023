# Source Bankier, Source URL:https://www.bankier.pl/rss/wiadomosci.xml, Source language: pl-PL

## Siemens podpisał deklarację antyizraelską, by prowadzić biznes w Turcji
 - [https://www.bankier.pl/wiadomosc/Siemens-podpisal-deklaracje-antyizraelska-by-prowadzic-biznes-w-Turcji-8483906.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Siemens-podpisal-deklaracje-antyizraelska-by-prowadzic-biznes-w-Turcji-8483906.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 17:45:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/a/d76e420313eb12-945-560-0-9-1221-732.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niemiecki koncern Siemens będzie sprzedawał pociągi tureckim kolejom, a warunkiem było podpisanie deklaracji związanej z bojkotem Izraela – informuje w piątek portal dziennika telewizyjnego Tagesschau, powołując się na ustalenia stacji SWR.</p>

## Wypożyczasz auto? Sprawdź, czy ma OC. W razie kolizji zapłacisz
 - [https://www.bankier.pl/wiadomosc/Wypozyczasz-auto-Sprawdz-czy-ma-OC-W-razie-kolizji-zaplacisz-8484262.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wypozyczasz-auto-Sprawdz-czy-ma-OC-W-razie-kolizji-zaplacisz-8484262.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 17:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/9703d03d28206d-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W razie kolizji pożyczonym autem, które nie ma ważnej polisy OC, odpowiedzialność finansową ponoszą solidarnie właściciel pojazdu oraz kierujący – wskazał ekspert Ubezpieczeniowego Funduszu Gwarancyjnego. Dodał, że średni koszt odszkodowania sięga 20 tys. zł, a rekord to 2,25 mln zł.</p>

## Szef Międzynarodowej Agencji Energii: Limit cen na ropę uderzył finansowo w Rosję
 - [https://www.bankier.pl/wiadomosc/Szef-Miedzynarodowej-Agencji-Energii-Limit-cen-na-rope-uderzyl-finansowo-w-Rosje-8484355.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szef-Miedzynarodowej-Agencji-Energii-Limit-cen-na-rope-uderzyl-finansowo-w-Rosje-8484355.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 15:37:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/1/e28a36ca736a44-858-515-641-71-858-515.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Limit cen na ropę uderzył finansowo w Rosję; w styczniu kraj ten zanotował przychody o 30 procent, tzn. o 8 mld USD, mniejsze w porównaniu z takim samym okresem 2022 roku - poinformował w niedzielę szef Międzynarodowej Agencji Energii (MAE) Fatih Birol.</p>

## Pieniądze za szczepienie? Takie zachęty mogą zwiększyć liczbę chętnych
 - [https://www.bankier.pl/wiadomosc/Pieniadze-za-szczepienie-Takie-zachety-moga-zwiekszyc-liczbe-chetnych-8482657.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pieniadze-za-szczepienie-Takie-zachety-moga-zwiekszyc-liczbe-chetnych-8482657.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 13:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/8e8ce76734e2e8-948-568-0-70-1767-1060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ludzie, którzy otrzymają niewielką kwotę za przyjęcie szczepionki, chętniej korzystają z takiej ochrony przeciw zakażeniom - dowodzą naukowcy z Uniwersytetu w Lozannie. Wyniki dwóch eksperymentów...</p>

## Rusza piąty nabór wniosków firm, które ucierpiały na brexicie
 - [https://www.bankier.pl/wiadomosc/Rusza-piaty-nabor-wnioskow-firm-ktore-ucierpialy-na-brexicie-8483639.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rusza-piaty-nabor-wnioskow-firm-ktore-ucierpialy-na-brexicie-8483639.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 12:43:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/8/97b0df33989a3d-945-567-0-131-3473-2084.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />7 lutego ruszy 5. nabór wniosków w programie Re_Open UK; o wsparcie mogą aplikować przedsiębiorcy, którzy ucierpieli na brexicie - mówił w piątek minister funduszy i polityki regionalnej Grzegorz Puda. Szacujemy, że do wsparcia kwalifikuje się ponad 20 tys. polskich firm - dodał.</p>

## Hongkong chce przyciągnąć turystów po pandemii. Władze rozdadzą pół miliona biletów lotniczych
 - [https://www.bankier.pl/wiadomosc/Hongkong-chce-przyciagnac-turystow-po-pandemii-Wladze-rozdadza-pol-miliona-biletow-lotniczych-8482845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hongkong-chce-przyciagnac-turystow-po-pandemii-Wladze-rozdadza-pol-miliona-biletow-lotniczych-8482845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 12:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/b410d105e56f1d-948-567-0-62-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze Hongkongu zaoferują nawet pół miliona 
darmowych biletów lotniczych w ramach kampanii promocyjnej, która ma 
przyciągnąć turystów, biznes i inwestycje po trzech latach restrykcji 
związanych z koronawirusem – oświadczył szef administracji John Lee.</p>

## Duża awaria ciepłownicza na Śląsku. Zimne kaloryfery w ponad 23 tys. mieszkań
 - [https://www.bankier.pl/wiadomosc/Duza-awaria-cieplownicza-na-Slasku-Zimne-kaloryfery-w-ponad-23-tys-mieszkan-8484322.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Duza-awaria-cieplownicza-na-Slasku-Zimne-kaloryfery-w-ponad-23-tys-mieszkan-8484322.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 11:38:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/9/4888701f56ab8b-948-568-0-34-1723-1034.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mieszkańcy ponad 23 tys. mieszkań w Jastrzębiu-Zdroju mają w niedzielę zimne kaloryfery na skutek dwóch awarii ciepłowniczych. Trwa ponowne napełnianie sieci i w niedzielę wieczorem powinny zostać wznowione dostawy ciepła - zapewnia spółka PGNiG Termika Energetyka Przemysłowa.</p>

## Inflacja nie powstrzymuje Polaków przed podróżowaniem. Jak można upolować tanie loty?
 - [https://www.bankier.pl/wiadomosc/Jak-mozna-upolowac-tanie-loty-8483382.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jak-mozna-upolowac-tanie-loty-8483382.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 11:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/c/216fc0c89fde08-948-568-0-53-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inflacja dotyka także branżę turystyczną - w ubiegłym roku odnotowano wzrost cen paliwa lotniczego, w wielu krajach rosły też koszty żywności i noclegów, co przełożyło się na wyższe ceny wycieczek, biletów...</p>

## Jak Holendrzy radzą sobie z bankowością cyfrową? "Przerażające wyniki". W kraju działa tylko 420 placówek
 - [https://www.bankier.pl/wiadomosc/Jak-Holendrzy-radza-sobie-z-bankowoscia-cyfrowa-Przerazajace-wyniki-W-kraju-dziala-tylko-420-placowek-8480816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jak-Holendrzy-radza-sobie-z-bankowoscia-cyfrowa-Przerazajace-wyniki-W-kraju-dziala-tylko-420-placowek-8480816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 11:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/a25d31f395943f-948-568-0-119-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />2,6 mln mieszkańców Niderlandów (18 proc.) nie potrafi samodzielnie korzystać z bankowości internetowej - informuje Holenderski Bank Centralny (DNB). „Byliśmy przerażeni wynikami badania” – powiedział Inge van Dijk, dyrektor działu płatności DNB.</p>

## Testy zderzeniowe nie brały pod uwagę kobiet. Teraz ma się to zmienić
 - [https://www.bankier.pl/wiadomosc/Testy-zderzeniowe-nie-braly-pod-uwage-kobiet-Teraz-ma-sie-to-zmienic-8484251.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Testy-zderzeniowe-nie-braly-pod-uwage-kobiet-Teraz-ma-sie-to-zmienic-8484251.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 09:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/0/c826ba0f748dff-948-568-33-33-4419-2651.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Producenci aut przy projektowaniu zabezpieczeń przez 
lata brali za wzór do badań męską postać. Naukowcy udowadniają jednak, 
że aby skuteczniej chronić kobiety za kierownicą, trzeba tę zasadę 
zmodyfikować.</p>

## "Oglądają nas jak zwierzęta w zoo". Kilkumilionowy spór między apartamentowcem a londyńską galerią
 - [https://www.bankier.pl/wiadomosc/Ogladaja-nas-jak-zwierzeta-w-zoo-Kilkumilionowy-spor-miedzy-apartamentowcem-a-londynska-galeria-8482156.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ogladaja-nas-jak-zwierzeta-w-zoo-Kilkumilionowy-spor-miedzy-apartamentowcem-a-londynska-galeria-8482156.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 09:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/6/453c4812a62f15-948-567-0-42-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Oglądają nas jak zwierzęta w zoo" - grzmią właściciele luksusowych mieszkań nad Tamizą, za które średnio zapłacili 2 mln funtów. Wszystko przez taras widokowy Tate Modern, z którego odwiedzający muzeum mogli dokładnie zajrzeć im w okna. Spór dotarł aż do Sądu Najwyższego Wielkiej Brytanii. </p>

## Coraz więcej bezdomnych we Francji. Wzrost o 130 proc. w dekadę
 - [https://www.bankier.pl/wiadomosc/Coraz-wiecej-bezdomnych-we-Francji-Wzrost-o-130-proc-w-dekade-8482075.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-wiecej-bezdomnych-we-Francji-Wzrost-o-130-proc-w-dekade-8482075.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 09:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/4/10c88163e88877-948-568-0-237-4100-2460.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />We Francji żyje ponad 330 tysięcy bezdomnych, co oznacza wzrost tej liczby o 130 procent w ciągu 10 lat - alarmuje w swoim corocznym raporcie fundacja Abbe Pierre.</p>

## Ekspertka: Hodowla owadów nie degraduje środowska tak jak tradycyjna hodowla zwierząt
 - [https://www.bankier.pl/wiadomosc/Ekspertka-Hodowla-owadow-nie-degraduje-srodowska-tak-jak-tradycyjna-hodowla-zwierzat-8484255.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekspertka-Hodowla-owadow-nie-degraduje-srodowska-tak-jak-tradycyjna-hodowla-zwierzat-8484255.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 09:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/5/cb5b7620957ce2-948-568-0-159-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Hodowla owadów ma niewielki wpływ na środowisko naturalne w porównaniu z tradycyjną hodowlą zwierząt - uważa prof. SGGW dr hab. Małgorzata Nowacka. Jej zdaniem potrzeba kilku czy kilkunastu lat, by produkty z insektów były dostępne w szerokiej ofercie na rynku.</p>

## Inwestycje w OZE kontra nieprzyzwoicie wysokie zyski koncernów naftowych
 - [https://www.bankier.pl/wiadomosc/Inwestycje-w-OZE-kontra-nieprzyzwoicie-wysokie-zyski-koncernow-naftowych-8484015.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inwestycje-w-OZE-kontra-nieprzyzwoicie-wysokie-zyski-koncernow-naftowych-8484015.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 09:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/f/104e64a07a4ab1-945-560-0-971-2114-1268.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inwestycje w czystą energię muszą być podwojone do 
2030 r.  - uważają eksperci Polskiego Instytutu Ekonomicznego. Tymczasem
 największe koncerny naftowe chwalą się gigantycznymi zyskami.</p>

## Kary za posiadanie narkotyków w Belgii wzrosną. "Mają być jak mandaty drogowe"
 - [https://www.bankier.pl/wiadomosc/Kary-za-posiadanie-narkotykow-w-Belgii-wzrosna-Maja-byc-jak-mandaty-drogowe-8480617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kary-za-posiadanie-narkotykow-w-Belgii-wzrosna-Maja-byc-jak-mandaty-drogowe-8480617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 09:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/534d6b0d7bc052-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Belgii kary za zażywanie lub posiadanie na własny użytek takich narkotyków jak kokaina, ketamina czy LSD wzrosną ze 150 do 1000 euro - zdecydował minister sprawiedliwości Vincent Van Quickenborne. Chce on także, by grzywny z tego powodu były egzekwowane podobnie jak mandaty drogowe tj. ściągane z pensji w przypadku braku zapłaty.</p>

## Ekspert: W Unii zaczyna brakować rąk do pracy w rolnictwie
 - [https://www.bankier.pl/wiadomosc/Ekspert-W-Unii-zaczyna-brakowac-rak-do-pracy-w-rolnictwie-8484264.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekspert-W-Unii-zaczyna-brakowac-rak-do-pracy-w-rolnictwie-8484264.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 08:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/bb79f51acdf2df-948-568-31-148-2058-1235.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W całej Unii Europejskiej zaczyna brakować rąk do pracy w rolnictwie, w tym ogrodnictwie – mówi prezes Agroekoton Mirosław Korzeniowski.</p>

## Ekspert: Wielkiego bezrobocia w Polsce nie będzie. Dzięki demografii
 - [https://www.bankier.pl/wiadomosc/Ekspert-Wielkiego-bezrobocia-w-Polsce-nie-bedzie-Dzieki-demografii-8484017.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekspert-Wielkiego-bezrobocia-w-Polsce-nie-bedzie-Dzieki-demografii-8484017.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 08:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/f9e7473c2f739b-948-568-19-263-3885-2331.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polsce nie grozi znaczący wzrost bezrobocia. Wszystko dzięki - de facto - pogarszającej się sytuacji demograficznej - mówi prof. Marek Bednarski, ekspert Instytutu Pracy i Spraw Socjalnych. </p>

## Średniowieczne zamki w Hiszpanii na sprzedaż. Niektóre kosztują mniej niż mieszkanie w mieście
 - [https://www.bankier.pl/wiadomosc/Sredniowieczne-zamki-w-Hiszpanii-na-sprzedaz-Niektore-kosztuja-mniej-niz-mieszkanie-w-miescie-8480937.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sredniowieczne-zamki-w-Hiszpanii-na-sprzedaz-Niektore-kosztuja-mniej-niz-mieszkanie-w-miescie-8480937.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 07:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/e/f9bdc69fff2281-948-568-0-207-2372-1423.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Hiszpanii w sprzedaży znajdują się średniowieczne zamki, a niektóre z nich można kupić za cenę niższą od mieszkania w dużym mieście - podał w raporcie portal specjalizujący się w sprzedaży nieruchomości Idealista. Najczęściej do sprzedaży zmuszają prywatnych właścicieli koszty utrzymania posiadłości.</p>

## Chcą szybko zapomnieć i nie płacą za pobyt. Izba wytrzeźwień pod kreską
 - [https://www.bankier.pl/wiadomosc/Chca-szybko-zapomniec-i-nie-placa-za-pobyt-Izba-wytrzezwien-pod-kreska-8482109.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chca-szybko-zapomniec-i-nie-placa-za-pobyt-Izba-wytrzezwien-pod-kreska-8482109.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/6/697d0eaa105d29-948-568-0-0-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chłodna woda pod prysznicem, a także pokoje 
wieloosobowe i często z problematycznymi współlokatorami - 
pięciogwiazdkowy hotel to nie jest, a mimo to nocleg kosztuje 343 zł za 
dobę. Szczecińska izba wytrzeźwień zakończyła rok na sporym minusie. 
"Goście" nie chcą płacić za pobyt.</p>

## Embargo na produkty ropopochodne z Rosji już obowiązuje. Będą problemy na stacjach?
 - [https://www.bankier.pl/wiadomosc/Embargo-na-produkty-ropopochodne-z-Rosji-juz-obowiazuje-8484252.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Embargo-na-produkty-ropopochodne-z-Rosji-juz-obowiazuje-8484252.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/e/fb49277a6bec00-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W niedzielę, 5 lutego br. weszło w życie embargo Unii Europejskiej na produkty z ropy, w tym paliwa gotowe z Rosji, nałożone w związku z rosyjską napaścią na Ukrainę. </p>

## Tak powstaje polski komputer gamingowy Hiro. Zaglądamy do fabryki NTT
 - [https://www.bankier.pl/wiadomosc/Tak-powstaje-polski-komputer-gamingowy-Hiro-Zagladamy-do-fabryki-NTT-8481211.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-powstaje-polski-komputer-gamingowy-Hiro-Zagladamy-do-fabryki-NTT-8481211.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/1/9d786ee9b97fc4-948-568-11-7-1487-892.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Co jest potrzebne, aby powstał dobrej jakości 
komputer gamingowy? Jak wygląda cały proces produkcji, od dobrania 
podzespołów, przez montaż, aż po instalację oprogramowania? Zapraszamy 
na wirtualną wycieczkę do fabryki firmy NTT, twórcy komputera Hiro.</p>

## Wynajmujesz swoje mieszkanie? Czasem należy wypowiedzieć umowę lokatorom... aż 3 lata wcześniej
 - [https://www.bankier.pl/wiadomosc/Wynajmujesz-swoje-mieszkanie-Czasem-nalezy-wypowiedziec-umowe-lokatorom-az-3-lata-wczesniej-8480648.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wynajmujesz-swoje-mieszkanie-Czasem-nalezy-wypowiedziec-umowe-lokatorom-az-3-lata-wczesniej-8480648.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-02-05 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/cf8ade26506f48-948-568-35-165-1625-975.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W pewnych sytuacjach
przepisy nakazują zastosowanie aż trzyletniego okresu wypowiedzenia przy najmie
mieszkania. Wyjaśniamy, jak omijany jest ten przepis.</p>
