# Source TNV24 Najważniejsze, Source URL:https://tvn24.pl/najwazniejsze.xml, Source language: pl-PL

## Wyborcza dogrywka na Cyprze
 - [https://tvn24.pl/swiat/cypr-wyory-prezydenckie-w-drugiej-turze-zmierza-sie-nikos-christodulides-i-andreas-mawrojannis-6728118?source=rss](https://tvn24.pl/swiat/cypr-wyory-prezydenckie-w-drugiej-turze-zmierza-sie-nikos-christodulides-i-andreas-mawrojannis-6728118?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 22:08:39+00:00
 - user: None

<img alt="Wyborcza dogrywka na Cyprze " src="https://tvn24.pl/najnowsze/cdn-zdjecie-0fv40f-wybory-prezydenckie-na-cyprze-6728120/alternates/LANDSCAPE_1280" />
    Druga tura wyborów odbędzie się 12 lutego.

## Barcelona zachwyciła po przerwie. Powiększyła przewagę nad Realem
 - [https://eurosport.tvn24.pl/barcelona-zachwyci-a-po-przerwie--jeszcze-wi-ksza-przewaga-nad-realem,1135518.html?source=rss](https://eurosport.tvn24.pl/barcelona-zachwyci-a-po-przerwie--jeszcze-wi-ksza-przewaga-nad-realem,1135518.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 21:53:16+00:00
 - user: None

<img alt="Barcelona zachwyciła po przerwie. Powiększyła przewagę nad Realem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vovt2r-barcelona-powiekszyla-przewage-nad-realem-madryt-pokonala-seville/alternates/LANDSCAPE_1280" />
    Nie zmarnowała okazji.

## "Coś się wydarzyło po drodze". Kolumna rosyjskiego sprzętu nie dotarła do celu
 - [https://tvn24.pl/swiat/wladze-kolumna-rosyjskiego-sprzetu-jadaca-przez-mariupol-nie-dotarla-do-celu-6728061?source=rss](https://tvn24.pl/swiat/wladze-kolumna-rosyjskiego-sprzetu-jadaca-przez-mariupol-nie-dotarla-do-celu-6728061?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 20:37:50+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wx94a0-rosyjska-ciezarowka-6627564/alternates/LANDSCAPE_1280" />
    Przekazał doradca mera Mariupola Petro Andriuszczenko.

## Usiadła po przedostatnim okrążeniu, a i tak pobiła rekord. "Surrealistyczne"
 - [https://eurosport.tvn24.pl/usiad-a-po-przedostatnim-okr--eniu--a-i-tak-pobi-a-rekord---surrealistyczne-,1135474.html?source=rss](https://eurosport.tvn24.pl/usiad-a-po-przedostatnim-okr--eniu--a-i-tak-pobi-a-rekord---surrealistyczne-,1135474.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 20:34:00+00:00
 - user: None

<img alt="Usiadła po przedostatnim okrążeniu, a i tak pobiła rekord. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ha0qac-diribe-welteji-jest-jedna-z-najlepszych-biegaczek-mlodego-pokolenia/alternates/LANDSCAPE_1280" />
    Przytomna reakcja innych zawodniczek i kibiców.

## "Przecieram oczy ze zdumienia"
 - [https://tvn24.pl/polska/willa-plus-komentarze-dzialaczy-opozycji-antykomunistycznej-i-pozarzadowych-6728013?source=rss](https://tvn24.pl/polska/willa-plus-komentarze-dzialaczy-opozycji-antykomunistycznej-i-pozarzadowych-6728013?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 19:40:35+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g2sqw9-staniszewska-fpf-6728059/alternates/LANDSCAPE_1280" />
    Działacze opozycji antykomunistycznej o Willi plus.

## Lewandowski w meczu ligowym, Barcelona chce uciec Realowi
 - [https://eurosport.tvn24.pl/fc-barcelona---sevilla-fc--wynik-meczu-i-relacja-na--ywo,1135483.html?source=rss](https://eurosport.tvn24.pl/fc-barcelona---sevilla-fc--wynik-meczu-i-relacja-na--ywo,1135483.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 19:40:00+00:00
 - user: None

<img alt="Lewandowski w meczu ligowym, Barcelona chce uciec Realowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fxxk1c-relacja-lewandowski-6626852/alternates/LANDSCAPE_1280" />
    Wynik i relacja z meczu w eurosport.pl.

## Lech z pierwszym zwycięstwem
 - [https://eurosport.tvn24.pl/lech-z-pierwszym-zwyci-stwem--niespodzianka-w-szczecinie,1135502.html?source=rss](https://eurosport.tvn24.pl/lech-z-pierwszym-zwyci-stwem--niespodzianka-w-szczecinie,1135502.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 19:12:00+00:00
 - user: None

<img alt="Lech z pierwszym zwycięstwem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lpt4db-mikael-ishak-strzelil-gola-w-meczu-z-miedzia/alternates/LANDSCAPE_1280" />
     Niespodzianka w Szczecinie.

## Manchester City pokonany w Londynie
 - [https://eurosport.tvn24.pl/manchester-city-pokonany-w-londynie--historyczne-chwile-harry-ego-kane-a,1135491.html?source=rss](https://eurosport.tvn24.pl/manchester-city-pokonany-w-londynie--historyczne-chwile-harry-ego-kane-a,1135491.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 18:34:32+00:00
 - user: None

<img alt="Manchester City pokonany w Londynie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-976h42-harry-kane-jest-katem-manchesteru-city/alternates/LANDSCAPE_1280" />
    Historyczne chwile Harry'ego Kane'a.

## Reprezentant Polski strzelił Bayernowi
 - [https://eurosport.tvn24.pl/reprezentant-polski-doczeka--si---debiutancki-gol-z-bayernem,1135484.html?source=rss](https://eurosport.tvn24.pl/reprezentant-polski-doczeka--si---debiutancki-gol-z-bayernem,1135484.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 18:30:36+00:00
 - user: None

<img alt="Reprezentant Polski strzelił Bayernowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6kbi6b-jakub-kaminski-pokonal-bramkarza-bayernu/alternates/LANDSCAPE_1280" />
    Debiutancki gol w Bundeslidze.

## "Napisy na obiekcie przeznaczonym na kościół". Akt wandalizmu w Rzeszowie
 - [https://tvn24.pl/polska/kosciol-w-rzeszowie-namalowane-napisy-na-scianach-6727953?source=rss](https://tvn24.pl/polska/kosciol-w-rzeszowie-namalowane-napisy-na-scianach-6727953?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 18:21:57+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-svklcr-napisy-na-scianie-kosciola-w-rzeszowie-zdjecie-otrzymalismy-na-kontakt-24-6727978/alternates/LANDSCAPE_1280" />
    Informację o zniszczeniu mienia potwierdziła rzeszowska policja.

## Od lat te same problemy na niemieckiej skoczni
 - [https://eurosport.tvn24.pl/zn-w-te-same-problemy-na-niemieckiej-skoczni---to-nie-wygl-da-jak-profesjonalna-dyscyplina-,1135463.html?source=rss](https://eurosport.tvn24.pl/zn-w-te-same-problemy-na-niemieckiej-skoczni---to-nie-wygl-da-jak-profesjonalna-dyscyplina-,1135463.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 18:04:00+00:00
 - user: None

<img alt="Od lat te same problemy na niemieckiej skoczni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-63zz0y-warunki-na-skoczni-w-willingen-pozostawialy-wiele-do-zyczenia/alternates/LANDSCAPE_1280" />
     "To nie wygląda jak profesjonalna dyscyplina".

## Zignorowali apele, zatopili lotniskowiec
 - [https://tvn24.pl/swiat/brazylia-lotniskowiec-sao-paulo-zatopiony-na-oceanie-atlantyckim-pomimo-apeli-minister-srodowiska-i-prokuratury-6727834?source=rss](https://tvn24.pl/swiat/brazylia-lotniskowiec-sao-paulo-zatopiony-na-oceanie-atlantyckim-pomimo-apeli-minister-srodowiska-i-prokuratury-6727834?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 17:20:18+00:00
 - user: None

<img alt="Zignorowali apele, zatopili lotniskowiec " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9nwyrk-lotniskowiec-sao-paulo-6727869/alternates/LANDSCAPE_1280" />
    Lotniskowiec Sao Paulo został zatopiony na Oceanie Atlantyckim.

## Po katastrofie siedmiu górników pozostało na dole. "Zakończył się pierwszy etap akcji poszukiwawczej"
 - [https://tvn24.pl/katowice/katastrofa-w-kopalni-pniowek-chca-odnalezc-siedmiu-gornikow-jsw-zakonczyl-sie-pierwszy-etap-akcji-poszukiwawczej-6727993?source=rss](https://tvn24.pl/katowice/katastrofa-w-kopalni-pniowek-chca-odnalezc-siedmiu-gornikow-jsw-zakonczyl-sie-pierwszy-etap-akcji-poszukiwawczej-6727993?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 17:12:26+00:00
 - user: None

<img alt="Po katastrofie siedmiu górników pozostało na dole. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n5zthf-znicze-przed-kopalnia-pniowek-zdjecie-z-kwietnia-2022-roku-6727966/alternates/LANDSCAPE_1280" />
    Do serii wybuchów metanu w kopalni Pniówek doszło w kwietniu 2022 roku. Zginęło 16 górników i ratowników górniczych.

## Dreamliner lecący z Warszawy do Zanzibaru zawrócony
 - [https://tvn24.pl/polska/dreamliner-lecacy-z-warszawy-do-zanzibaru-zostal-zawrocony-z-powodu-usterki-przekazal-rzecznik-lot-krzysztof-moczulski-6727934?source=rss](https://tvn24.pl/polska/dreamliner-lecacy-z-warszawy-do-zanzibaru-zostal-zawrocony-z-powodu-usterki-przekazal-rzecznik-lot-krzysztof-moczulski-6727934?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 17:08:25+00:00
 - user: None

<img alt="Dreamliner lecący z Warszawy do Zanzibaru zawrócony " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-j43bwk-usterka-dreamlinera-ktory-lecial-z-dominikany-do-warszawy-5585931/alternates/LANDSCAPE_1280" />
    Z powodu usterki.

## Kamil Stoch wycofany z kolejnych zawodów Pucharu Świata
 - [https://eurosport.tvn24.pl/kamil-stoch-wycofany-z-kolejnych-zawod-w-pucharu--wiata,1135477.html?source=rss](https://eurosport.tvn24.pl/kamil-stoch-wycofany-z-kolejnych-zawod-w-pucharu--wiata,1135477.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 16:56:51+00:00
 - user: None

<img alt="Kamil Stoch wycofany z kolejnych zawodów Pucharu Świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sthmkh-stoch-odpocznie-od-skakania/alternates/LANDSCAPE_1280" />
    Mówił o tym trener polskich skoczków w rozmowie z Eurosportem.

## Granerud zmiażdżył najgroźniejszych rywali. Tylko jeden Polak w pierwszej dziesiątce
 - [https://eurosport.tvn24.pl/granerud-zmia-d-y--najgro-niejszych-rywali--tylko-jeden-polak-w-pierwszej-dziesi-tce,1135455.html?source=rss](https://eurosport.tvn24.pl/granerud-zmia-d-y--najgro-niejszych-rywali--tylko-jeden-polak-w-pierwszej-dziesi-tce,1135455.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 16:42:07+00:00
 - user: None

<img alt="Granerud zmiażdżył najgroźniejszych rywali. Tylko jeden Polak w pierwszej dziesiątce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pavx49-piotr-zyla/alternates/LANDSCAPE_1280" />
    Norweg zakpił z warunków, które nie należały do najłatwiejszych.

## "Wszystkie rosyjskie peryferia, łącznie nawet z Jakucją, mogą się odłączyć"
 - [https://tvn24.pl/swiat/rosyjski-politolog-wladislaw-inoziemcew-o-rosji-jej-mozliwym-rozpadzie-imperializmie-i-przyszlosci-6727659?source=rss](https://tvn24.pl/swiat/rosyjski-politolog-wladislaw-inoziemcew-o-rosji-jej-mozliwym-rozpadzie-imperializmie-i-przyszlosci-6727659?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 15:55:01+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-11ufbl-kreml-moskwa-6727745/alternates/LANDSCAPE_1280" />
    Rosyjski politolog i ekonomista Władisław Inoziemcew w wywiadzie.

## Czas jest dla nich bezcenny, a tygodniami muszą czekać na diagnozę
 - [https://tvn24.pl/lodz/onkologia-chorzy-tygodniami-czekaja-na-diagnoze-eksperci-o-tym-czemu-system-dziala-zle-6722916?source=rss](https://tvn24.pl/lodz/onkologia-chorzy-tygodniami-czekaja-na-diagnoze-eksperci-o-tym-czemu-system-dziala-zle-6722916?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 15:03:56+00:00
 - user: None

<img alt="Czas jest dla nich bezcenny, a tygodniami muszą czekać na diagnozę " src="https://tvn24.pl/najnowsze/cdn-zdjecie-l39ysz-badanie-4705289/alternates/LANDSCAPE_1280" />
    Z danych NFZ wynika, że zeszłym roku liczba badań diagnostycznych chorych z podejrzeniem nowotworu wyniosła ponad 60 tysięcy.

## Stoch brutalnie szczery. "Ta sytuacja mnie dobija"
 - [https://eurosport.tvn24.pl/stoch-nie-przebrn---kwalifikacji---ta-sytuacja-mnie-dobija-,1135452.html?source=rss](https://eurosport.tvn24.pl/stoch-nie-przebrn---kwalifikacji---ta-sytuacja-mnie-dobija-,1135452.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 14:59:48+00:00
 - user: None

<img alt="Stoch brutalnie szczery. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2dc0cw-kamil-stoch-po-kwalifikacjach-w-willingen/alternates/LANDSCAPE_1280" />
    Tuż po kwalifikacjach rozmawiał z Eurosportem.

## Katastrofa Kamila Stocha
 - [https://eurosport.tvn24.pl/kamil-stoch-nie-awansowa--do-niedzielnego-konkursu-w-willingen,1135443.html?source=rss](https://eurosport.tvn24.pl/kamil-stoch-nie-awansowa--do-niedzielnego-konkursu-w-willingen,1135443.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 14:30:21+00:00
 - user: None

<img alt="Katastrofa Kamila Stocha" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7xoyjh-kamil-stoch-6727843/alternates/LANDSCAPE_1280" />
    Katastrofa naszego najbardziej utytułowanego zawodnika.

## "Trzęsienia mrozu" takie, że pękały drzewa. Padły stuletnie rekordy zimna
 - [https://tvn24.pl/tvnmeteo/swiat/usa-atak-srogiej-zimy-w-nowej-anglii-trzesienia-mrozu-dziecko-zginelo-w-aucie-przywalonym-przez-drzewo-6727397?source=rss](https://tvn24.pl/tvnmeteo/swiat/usa-atak-srogiej-zimy-w-nowej-anglii-trzesienia-mrozu-dziecko-zginelo-w-aucie-przywalonym-przez-drzewo-6727397?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 14:28:00+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7rgg7t-atak-zimy-w-stanie-maine-usa-6727828/alternates/LANDSCAPE_1280" />
    Arktyczne warunki w części USA. Dziecko śmiertelną ofiarą ataku zimy.

## "Kosmiczny" skok cen wakacji. Oto najpopularniejsze kierunki
 - [https://tvn24.pl/biznes/turystyka/wakacje-2022-ceny-jakie-kierunki-byly-najpopularniejsze-lista-6727651?source=rss](https://tvn24.pl/biznes/turystyka/wakacje-2022-ceny-jakie-kierunki-byly-najpopularniejsze-lista-6727651?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 14:27:12+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w648r7-antalya-w-turcji-5704928/alternates/LANDSCAPE_1280" />
    Raport za 2022 rok.

## Eksplozja i pożar w mieszkaniu. Matka i dziecko trafili do szpitali
 - [https://tvn24.pl/najnowsze/katowice-ulica-krzyzowa-eksplozja-i-pozar-w-mieszkaniu-ranna-matka-i-dziecko-6727715?source=rss](https://tvn24.pl/najnowsze/katowice-ulica-krzyzowa-eksplozja-i-pozar-w-mieszkaniu-ranna-matka-i-dziecko-6727715?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 14:09:51+00:00
 - user: None

<img alt="Eksplozja i pożar w mieszkaniu. Matka i dziecko trafili do szpitali" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1ps6dm-wybuch-w-mieszkaniu-w-katowicach-6727714/alternates/LANDSCAPE_1280" />
    Nagranie z miejsca zdarzenia otrzymaliśmy na Kontakt 24.

## Ile Rosja straciła na limicie cenowym na ropę? Są wstępne szacunki
 - [https://tvn24.pl/biznes/ze-swiata/ropa-naftowa-z-rosji-limit-cenowy-o-ile-spadly-dochody-rosji-fatih-birol-szef-iea-komentuje-6727729?source=rss](https://tvn24.pl/biznes/ze-swiata/ropa-naftowa-z-rosji-limit-cenowy-o-ile-spadly-dochody-rosji-fatih-birol-szef-iea-komentuje-6727729?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 13:53:29+00:00
 - user: None

<img alt="Ile Rosja straciła na limicie cenowym na ropę? Są wstępne szacunki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cjpy3j-shutterstock526676863-6727788/alternates/LANDSCAPE_1280" />
    Wypowiedź szefa Międzynarodowej Agencji Energetycznej.

## Pod naporem śniegu zawalił się dach domu. W środku była pięcioosobowa rodzina
 - [https://tvn24.pl/krakow/rdzawka-dach-domu-zawalil-sie-pod-naporem-sniegu-zima-w-malopolsce-6727755?source=rss](https://tvn24.pl/krakow/rdzawka-dach-domu-zawalil-sie-pod-naporem-sniegu-zima-w-malopolsce-6727755?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 13:27:21+00:00
 - user: None

<img alt="Pod naporem śniegu zawalił się dach domu. W środku była pięcioosobowa rodzina" src="https://tvn24.pl/krakow/cdn-zdjecie-zlcf02-rodzina-stracila-dom-6727710/alternates/LANDSCAPE_1280" />
    Zdjęcia otrzymaliśmy na Kontakt 24.

## Najmroźniejsze noce przed nami. Pogoda na 16 dni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-16-dni-prognoza-dlugoterminowa-pogoda-na-luty-mroz-scisnal-i-jeszcze-potrzyma-6727551?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-16-dni-prognoza-dlugoterminowa-pogoda-na-luty-mroz-scisnal-i-jeszcze-potrzyma-6727551?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 13:27:11+00:00
 - user: None

<img alt="Najmroźniejsze noce przed nami. Pogoda na 16 dni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jybug9-pogoda-na-16-dni-drv-6727588/alternates/LANDSCAPE_1280" />
    Sprawdź prognozę pogody przygotowaną przez Tomasza Wasilewskiego.

## Kwalifikacje w Willingen. Zaraz po nich konkurs
 - [https://eurosport.tvn24.pl/skoki-narciarskie-willingen-2023--wyniki-na--ywo-i-relacja-live-z-kwalifikacji,1135435.html?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie-willingen-2023--wyniki-na--ywo-i-relacja-live-z-kwalifikacji,1135435.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 13:26:00+00:00
 - user: None

<img alt="Kwalifikacje w Willingen. Zaraz po nich konkurs" src="https://tvn24.pl/najnowsze/cdn-zdjecie-og5uh3-kubacki-bedzie-w-stanie-zagrozic-granerudowi/alternates/LANDSCAPE_1280" />
    Relacja i wyniki na żywo w eurosport.pl.

## Jeden opadł z sił i nie mógł iść dalej, inni spędzili noc w śnieżnej jamie. Turyści na górskich szlakach
 - [https://tvn24.pl/wroclaw/sniezka-babia-gora-jeden-opadl-z-sil-i-nie-mogl-isc-dalej-inni-spedzili-noc-w-snieznej-jamie-turysci-na-gorskich-szlakach-ratownicy-gopr-w-akcji-6727575?source=rss](https://tvn24.pl/wroclaw/sniezka-babia-gora-jeden-opadl-z-sil-i-nie-mogl-isc-dalej-inni-spedzili-noc-w-snieznej-jamie-turysci-na-gorskich-szlakach-ratownicy-gopr-w-akcji-6727575?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 12:23:59+00:00
 - user: None

<img alt="Jeden opadł z sił i nie mógł iść dalej, inni spędzili noc w śnieżnej jamie. Turyści na górskich szlakach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d37ra3-ratownicy-musieli-sciagac-turystow-z-gor-6727550/alternates/LANDSCAPE_1280" />
    Karkonoskie i beskidzkie grupy Górskiego Ochotniczego Pogotowia Ratunkowego miały w ciągu ostatnich kilkudziesięciu godzin ręce pełne roboty.

## Ważny termin dla pracowników
 - [https://tvn24.pl/biznes/dla-pracownika/ppk-autozapis-2023-coraz-blizej-wazny-termin-dla-pracownikow-wyjasnia-deloitte-termin-6727558?source=rss](https://tvn24.pl/biznes/dla-pracownika/ppk-autozapis-2023-coraz-blizej-wazny-termin-dla-pracownikow-wyjasnia-deloitte-termin-6727558?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 12:21:36+00:00
 - user: None

<img alt="Ważny termin dla pracowników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qxh38m-praca-biuro-shutterstock321792839-4691440/alternates/LANDSCAPE_1280" />
    Decyzja ma wpływ na pensję na rękę.

## Mnożą się pytania o bezpieczeństwo w Willingen. Groźne sceny przed niedzielnym konkursem
 - [https://eurosport.tvn24.pl/mno---si--pytania-o-bezpiecze-stwo-w-willingen--gro-ne-sceny-przed-niedzielnym-konkursem,1135436.html?source=rss](https://eurosport.tvn24.pl/mno---si--pytania-o-bezpiecze-stwo-w-willingen--gro-ne-sceny-przed-niedzielnym-konkursem,1135436.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 12:17:00+00:00
 - user: None

<img alt="Mnożą się pytania o bezpieczeństwo w Willingen. Groźne sceny przed niedzielnym konkursem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wrhyac-upadek-katry-komar/alternates/LANDSCAPE_1280" />
    Seria upadków na Muehlenkopfschanze.

## Duża awaria. Problemy mieszkańców 70 ulic, ponad 23 tysiące mieszkań bez ciepła
 - [https://tvn24.pl/katowice/jastrzebie-zdroj-awaria-cieplownicza-problemy-mieszkancow-70-ulic-ponad-23-tys-mieszkan-bez-ciepla-6727625?source=rss](https://tvn24.pl/katowice/jastrzebie-zdroj-awaria-cieplownicza-problemy-mieszkancow-70-ulic-ponad-23-tys-mieszkan-bez-ciepla-6727625?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 12:05:50+00:00
 - user: None

<img alt="Duża awaria. Problemy mieszkańców 70 ulic, ponad 23 tysiące mieszkań bez ciepła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tg1lst-drastycznie-wrosnie-cena-oplat-za-miejskie-ogrzewanie-zdj-ilustracyjne-6062448/alternates/LANDSCAPE_1280" />
    W Jastrzębiu-Zdroju (woj. śląskie).

## Po 11 miesiącach w rosyjskiej niewoli nie mógł uwierzyć, że trzyma jabłko
 - [https://tvn24.pl/swiat/ukraina-maksym-kolesnikow-nie-trzymal-jablka-w-rekach-od-roku-wrocil-z-rosyjskiej-niewoli-6727516?source=rss](https://tvn24.pl/swiat/ukraina-maksym-kolesnikow-nie-trzymal-jablka-w-rekach-od-roku-wrocil-z-rosyjskiej-niewoli-6727516?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 11:58:10+00:00
 - user: None

<img alt="Po 11 miesiącach w rosyjskiej niewoli nie mógł uwierzyć, że trzyma jabłko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fiicdb-ukraina-wiezien-jablko-6727499/alternates/LANDSCAPE_1280" />
    W ramach wymiany jeńców z Rosją na Ukrainę wróciło 116 osób.

## Przerwy w dostawach prądu, zablokowane drogi. Potrzebny "ciężki sprzęt do odśnieżania"
 - [https://tvn24.pl/tvnmeteo/polska/pogodowy-kryzys-na-zywiecczyznie-klopoty-na-drogach-6727541?source=rss](https://tvn24.pl/tvnmeteo/polska/pogodowy-kryzys-na-zywiecczyznie-klopoty-na-drogach-6727541?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 11:57:07+00:00
 - user: None

<img alt="Przerwy w dostawach prądu, zablokowane drogi. Potrzebny " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6i8ex0-plug-wirnikowy-walczy-z-zaspami-na-drogach-opolszczyzny-6546411/alternates/LANDSCAPE_1280" />
    Pogodowy kryzys na Żywiecczyźnie.

## "Zmienili prawo tak, że właściwe dzisiaj korupcję można uznać za zgodną z przepisami prawa"
 - [https://tvn24.pl/polska/willa-plus-dyskusja-w-kawie-na-lawe-o-milionach-od-ministra-przemyslawa-czarnka-dla-fundacji-zwiazanych-z-pis-6727391?source=rss](https://tvn24.pl/polska/willa-plus-dyskusja-w-kawie-na-lawe-o-milionach-od-ministra-przemyslawa-czarnka-dla-fundacji-zwiazanych-z-pis-6727391?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 11:41:06+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8zqu5q-05-1045-kawa-cl-0004-6727457/alternates/LANDSCAPE_1280" />
    Dyskusja polityków w "Kawie na ławę".

## Starsze małżeństwo zginęło w wypadku
 - [https://tvn24.pl/krakow/mielec-wypadek-nie-zyje-starsze-malzenstwo-ich-auto-zderzylo-sie-czolowo-z-innym-samochodem-6727535?source=rss](https://tvn24.pl/krakow/mielec-wypadek-nie-zyje-starsze-malzenstwo-ich-auto-zderzylo-sie-czolowo-z-innym-samochodem-6727535?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 11:24:39+00:00
 - user: None

<img alt="Starsze małżeństwo zginęło w wypadku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-32gtdc-mielec-woj-podkarpackie-6727519/alternates/LANDSCAPE_1280" />
    Wypadek w Mielcu (woj. podkarpackie).

## Zderzyli się czołowo z innym samochodem. Zginęli 79-latek i 77-latka
 - [https://tvn24.pl/krakow/mielec-wypadek-nie-zyje-79-latek-i-77-latka-ich-auto-zderzylo-sie-czolowo-z-innym-samochodem-6727535?source=rss](https://tvn24.pl/krakow/mielec-wypadek-nie-zyje-79-latek-i-77-latka-ich-auto-zderzylo-sie-czolowo-z-innym-samochodem-6727535?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 11:24:39+00:00
 - user: None

<img alt="Zderzyli się czołowo z innym samochodem. Zginęli 79-latek i 77-latka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-32gtdc-mielec-woj-podkarpackie-6727519/alternates/LANDSCAPE_1280" />
    Wypadek w Mielcu (woj. podkarpackie).

## Zaniżone emerytury przez błąd ZUS. Pokrzywdzeni seniorzy i odpowiedź ministerstwa
 - [https://tvn24.pl/biznes/dla-seniora/zanizone-emerytury-przez-blad-zus-pokrzywdzeni-seniorzy-i-odpowiedz-ministerstwa-6727521?source=rss](https://tvn24.pl/biznes/dla-seniora/zanizone-emerytury-przez-blad-zus-pokrzywdzeni-seniorzy-i-odpowiedz-ministerstwa-6727521?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 11:23:48+00:00
 - user: None

<img alt="Zaniżone emerytury przez błąd ZUS. Pokrzywdzeni seniorzy i odpowiedź ministerstwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-11wnxk-shutterstock2080436497-5515615/alternates/LANDSCAPE_1280" />
    W reakcji na interpelację poselską.

## Polskie wyrzutnie Patriot jadą do Warszawy. Błaszczak: staną na Bemowie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-polskie-wyrzutnie-patriot-jada-do-warszawy-stana-na-lotnisku-na-bemowie-6727524?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-polskie-wyrzutnie-patriot-jada-do-warszawy-stana-na-lotnisku-na-bemowie-6727524?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 11:15:14+00:00
 - user: None

<img alt="Polskie wyrzutnie Patriot jadą do Warszawy. Błaszczak: staną na Bemowie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-15s7fb-polskie-wyrzutnie-patriot-stana-na-lotnisku-na-bemowie-6727527/alternates/LANDSCAPE_1280" />
    "Przemieszczają się z Sochaczewa".

## Polskie wyrzutnie Patriot przyjechały do Warszawy. Błaszczak: staną na Bemowie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/polskie-wyrzutnie-patriot-w-warszawie-stana-na-lotnisku-na-bemowie-6727524?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/polskie-wyrzutnie-patriot-w-warszawie-stana-na-lotnisku-na-bemowie-6727524?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 11:15:14+00:00
 - user: None

<img alt="Polskie wyrzutnie Patriot przyjechały do Warszawy. Błaszczak: staną na Bemowie " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ggwah7-polskie-wyrzutnie-patriot-dotarly-do-warszawy-6727724/alternates/LANDSCAPE_1280" />
    Sprzęt będzie rozstawiony na lotnisku.

## W budynkach i na chodnikach, ponad 350 osób podawało sobie książki. "Powstał łańcuch dobrych rąk"
 - [https://tvn24.pl/bialystok/hrubieszow-mieszkancy-pomogli-w-przenosinach-biblioteki-6727053?source=rss](https://tvn24.pl/bialystok/hrubieszow-mieszkancy-pomogli-w-przenosinach-biblioteki-6727053?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 10:55:33+00:00
 - user: None

<img alt="W budynkach i na chodnikach, ponad 350 osób podawało sobie książki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-d1qu8i-policja-kierowala-ruchem-6727062/alternates/LANDSCAPE_1280" />
    W Hrubieszowie (woj. lubelskie).

## Podczas 31. Finału WOŚP uczyli pierwszej pomocy, w tym czasie ktoś ich okradł
 - [https://tvn24.pl/pomorze/gdansk-kradziez-rowerow-nalezacych-do-ratownikow-medycznych-wczesniej-uczestniczyli-w-31-finale-wosp-6727459?source=rss](https://tvn24.pl/pomorze/gdansk-kradziez-rowerow-nalezacych-do-ratownikow-medycznych-wczesniej-uczestniczyli-w-31-finale-wosp-6727459?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 10:37:48+00:00
 - user: None

<img alt="Podczas 31. Finału WOŚP uczyli pierwszej pomocy, w tym czasie ktoś ich okradł" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bbkc9u-skradzione-rowery-ratownikow-medycznych-6727429/alternates/LANDSCAPE_1280" />
    Dwa rowery ratunkowe zniknęły z garażu ratowników medycznych z Gdańska.

## Zieliński i Kubot nie pomogli. Polacy utknęli w Grupie II
 - [https://eurosport.tvn24.pl/zieli-ski-i-kubot-nie-pomogli--polacy-utkn-li-w-grupie-ii,1135428.html?source=rss](https://eurosport.tvn24.pl/zieli-ski-i-kubot-nie-pomogli--polacy-utkn-li-w-grupie-ii,1135428.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 10:36:00+00:00
 - user: None

<img alt="Zieliński i Kubot nie pomogli. Polacy utknęli w Grupie II" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gpokud-jan-zielinski-i-lukasz-kubot/alternates/LANDSCAPE_1280" />
    Polska przegrała z Japonią 0:4 spotkanie o awans do Grupy Światowej I w Pucharze Davisa. We wrześniu ponownie zagrają w Grupie II, której stawką będzie miejsce w barażach o awans do Grupy I za rok.

## Chcieli skontrolować kierowcę jaguara, zaczął uciekać. Padł strzał ostrzegawczy
 - [https://tvn24.pl/polska/kalisz-chcieli-skontrolowac-kierowce-jaguara-zaczal-uciekac-padl-strzal-ostrzegawczy-trzy-osoby-zatrzymane-6727482?source=rss](https://tvn24.pl/polska/kalisz-chcieli-skontrolowac-kierowce-jaguara-zaczal-uciekac-padl-strzal-ostrzegawczy-trzy-osoby-zatrzymane-6727482?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 10:22:25+00:00
 - user: None

<img alt="Chcieli skontrolować kierowcę jaguara, zaczął uciekać. Padł strzał ostrzegawczy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-682tbm-policja-policyjny-kogut-6722449/alternates/LANDSCAPE_1280" />
    Trzy osoby zostały zatrzymane i trafiły do policyjnego aresztu.

## Pilot "przerwał lądowanie i przystąpił do wznoszenia". Niebezpieczny incydent na lotnisku
 - [https://tvn24.pl/swiat/usa-teksas-niebezpieczny-incydent-na-lotnisku-w-austin-6727431?source=rss](https://tvn24.pl/swiat/usa-teksas-niebezpieczny-incydent-na-lotnisku-w-austin-6727431?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 10:15:56+00:00
 - user: None

<img alt="Pilot " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ijwgwh-lotnisko-w-austin-6727447/alternates/LANDSCAPE_1280" />
    W teksańskim Austin.

## Alarmujące dane GUS. Wiceminster: takie spadki będziemy widzieć przez następne lata
 - [https://tvn24.pl/biznes/z-kraju/polakow-jest-coraz-mniej-w-2022-roku-najmniej-urodzen-od-ii-wojny-swiatowej-wiceminister-rodziny-i-polityki-spolecznej-barbara-socha-komentuje-dane-gus-6727393?source=rss](https://tvn24.pl/biznes/z-kraju/polakow-jest-coraz-mniej-w-2022-roku-najmniej-urodzen-od-ii-wojny-swiatowej-wiceminister-rodziny-i-polityki-spolecznej-barbara-socha-komentuje-dane-gus-6727393?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 10:06:02+00:00
 - user: None

<img alt="Alarmujące dane GUS. Wiceminster: takie spadki będziemy widzieć przez następne lata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tmtpjs-warszawa-ludzie-przejscie-dla-pieszych-grand-warszawski-shutterstock22409554771-6622946/alternates/LANDSCAPE_1280" />
    Komentuje wiceminister rodziny i polityki społecznej.

## Wojownicy zadrżeli. Kontuzjowany Curry zmuszony do zejścia z parkietu
 - [https://eurosport.tvn24.pl/wojownicy-zadr-eli--kontuzjowany-curry-zmuszony-do-zej-cia-z-parkietu,1135431.html?source=rss](https://eurosport.tvn24.pl/wojownicy-zadr-eli--kontuzjowany-curry-zmuszony-do-zej-cia-z-parkietu,1135431.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 09:48:00+00:00
 - user: None

<img alt="Wojownicy zadrżeli. Kontuzjowany Curry zmuszony do zejścia z parkietu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lqnjeb-stephen-curry-6727475/alternates/LANDSCAPE_1280" />
    Koszykarze Golden State Warriors wygrali we własnej hali z Dallas Mavericks 119:113, ale ich radość ze zwycięstwa przyćmił niepokój o stan kolana Stephena Curry'ego. Koszykarz Wojowników zderzył się lewym kolanem z zawodnikiem rywali pod koniec trzeciej kwarty i musiał opuścić plac gry.

## Ponad dwa miliony złotych na willę pod Elblągiem. Mimo "braku dużego doświadczenia na polu edukacji"
 - [https://tvn24.pl/polska/willa-plus-dofinansowanie-dla-fundacji-dumni-z-elblaga-michal-istel-z-konkret24-komentuje-6727263?source=rss](https://tvn24.pl/polska/willa-plus-dofinansowanie-dla-fundacji-dumni-z-elblaga-michal-istel-z-konkret24-komentuje-6727263?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 08:56:38+00:00
 - user: None

<img alt="Ponad dwa miliony złotych na willę pod Elblągiem. Mimo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4klhby-michal-istel-6727296/alternates/LANDSCAPE_1280" />
    Michał Istel z Konkret24 we "Wstajesz i weekend".

## Kolejne konkursy bez Stocha? "Wolałbym posłać w jego miejsce młodego zawodnika"
 - [https://eurosport.tvn24.pl/kolejne-konkursy-bez-stocha---wola-bym-pos-a--w-jego-miejsce-m-odego-zawodnika-,1135387.html?source=rss](https://eurosport.tvn24.pl/kolejne-konkursy-bez-stocha---wola-bym-pos-a--w-jego-miejsce-m-odego-zawodnika-,1135387.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 08:45:00+00:00
 - user: None

<img alt="Kolejne konkursy bez Stocha? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-66ptrn-stochowi-przyda-sie-przerwa/alternates/LANDSCAPE_1280" />
    Taka przerwa wyszłaby mu "tylko na dobre".

## Kuriozum to mało powiedziane. Zszedł z boiska, dopiero potem mógł cieszyć się ze swojego gola
 - [https://eurosport.tvn24.pl/kuriozum-to-ma-o-powiedziane--zszed--z-boiska--dopiero-potem-cieszy--si--ze-swojego-gola,1135426.html?source=rss](https://eurosport.tvn24.pl/kuriozum-to-ma-o-powiedziane--zszed--z-boiska--dopiero-potem-cieszy--si--ze-swojego-gola,1135426.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 08:32:00+00:00
 - user: None

<img alt="Kuriozum to mało powiedziane. Zszedł z boiska, dopiero potem mógł cieszyć się ze swojego gola" src="https://tvn24.pl/najnowsze/cdn-zdjecie-934gbs-angel-correa-od-osmiu-lat-wystepuje-w-atletico/alternates/LANDSCAPE_1280" />
    W Hiszpanii "pierwszy gol w historii po zmianie".

## Mocny rubel to zasłona. Ekspert o tym, co ukrywa Moskwa
 - [https://tvn24.pl/swiat/sankcje-jak-wplynely-na-gospodarke-rosji-ekspert-wyjasnia-6727280?source=rss](https://tvn24.pl/swiat/sankcje-jak-wplynely-na-gospodarke-rosji-ekspert-wyjasnia-6727280?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 08:24:43+00:00
 - user: None

<img alt="Mocny rubel to zasłona. Ekspert o tym, co ukrywa Moskwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kdeike-lada-2107-w-tle-mural-z-wizerunkiem-wladimira-putina-w-kaszyrze-w-poblizu-moskwy-6628394/alternates/LANDSCAPE_1280" />
    Władimir Miłow z Fundacji Wolna Rosja na łamach "Foreign Affairs".

## Czy w lutym zrobimy większe zakupy w niedziele?
 - [https://tvn24.pl/biznes/z-kraju/niedziele-handlowe-luty-2023-czy-w-tym-miesiacu-w-niedziele-beda-otwarte-sklepy-6727279?source=rss](https://tvn24.pl/biznes/z-kraju/niedziele-handlowe-luty-2023-czy-w-tym-miesiacu-w-niedziele-beda-otwarte-sklepy-6727279?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 08:23:56+00:00
 - user: None

<img alt="Czy w lutym zrobimy większe zakupy w niedziele?" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-u5fbv3-zakaz-handlu-w-niedziele-4163327/alternates/LANDSCAPE_1280" />
    Kalendarz handlowy.

## Produkty z insektów niedługo szeroko dostępne na rynku. Ekspertka: to źródło białka i tłuszczu
 - [https://tvn24.pl/tvnmeteo/nauka/produkty-z-insektow-szeroko-dostepne-na-rynku-za-kilka-kilkanascie-lat-ekspertka-owady-sa-zrodlem-pelnowartosciowego-bialka-i-tluszczu-6727245?source=rss](https://tvn24.pl/tvnmeteo/nauka/produkty-z-insektow-szeroko-dostepne-na-rynku-za-kilka-kilkanascie-lat-ekspertka-owady-sa-zrodlem-pelnowartosciowego-bialka-i-tluszczu-6727245?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 07:58:22+00:00
 - user: None

<img alt="Produkty z insektów niedługo szeroko dostępne na rynku. Ekspertka: to źródło białka i tłuszczu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9lacm7-chleb-6727320/alternates/LANDSCAPE_1280" />
    Profesor Małgorzata Nowacka o produktach powstałych z owadów.

## Kumulacja w Lotto rośnie
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia040223-liczby-z-ostatniego-losowania-6727273?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia040223-liczby-z-ostatniego-losowania-6727273?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 07:54:34+00:00
 - user: None

<img alt="Kumulacja w Lotto rośnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oslmyw-lotto-s-shutterstock275295956-5128640/alternates/LANDSCAPE_1280" />
    Padło 41 piątek.

## "Zaciągnęli hamulec w pociągu", zaczęli malować graffiti. Dwie godziny utrudnień w metrze
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-utrudnienia-w-metrze-akt-wandalizmu-zniszczony-pociag-6727274?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-utrudnienia-w-metrze-akt-wandalizmu-zniszczony-pociag-6727274?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 07:46:41+00:00
 - user: None

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c338rc-stacja-raclawicka-6727337/alternates/LANDSCAPE_1280" />
    Na stacji Racławicka.

## Przed skoczkami kolejna pracowita niedziela
 - [https://eurosport.tvn24.pl/skoki-narciarskie-willingen-2023--o-kt-rej-godzinie-niedzielne-kwalifikacje-i-konkurs-,1135423.html?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie-willingen-2023--o-kt-rej-godzinie-niedzielne-kwalifikacje-i-konkurs-,1135423.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 06:59:00+00:00
 - user: None

<img alt="Przed skoczkami kolejna pracowita niedziela" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2vo0ng-jak-spisza-sie-polacy-podczas-niedzielnych-zmagan-w-willingen/alternates/LANDSCAPE_1280" />
    O której godzinie niedzielne kwalifikacje i konkurs?

## Pervez Musharraf nie żyje
 - [https://tvn24.pl/swiat/pervez-musharraf-nie-zyje-byly-prezydent-pakistanu-zmarl-po-dlugiej-chorobie-mial-79-lat-6727238?source=rss](https://tvn24.pl/swiat/pervez-musharraf-nie-zyje-byly-prezydent-pakistanu-zmarl-po-dlugiej-chorobie-mial-79-lat-6727238?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 06:39:57+00:00
 - user: None

<img alt="Pervez Musharraf nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6mtmte-pervez-musharraf-przejal-wladze-w-pakistanie-w-1999-roku-byl-prezydentem-w-latach-2001-2008-6727268/alternates/LANDSCAPE_1280" />
    Zmarł po długiej chorobie.

## Dlaczego balon? Wojskowi lubią je coraz bardziej
 - [https://tvn24.pl/swiat/chinski-balon-nad-usa-dlaczego-do-szpiegowania-wykorzystali-balon-eksperci-komentuja-6727227?source=rss](https://tvn24.pl/swiat/chinski-balon-nad-usa-dlaczego-do-szpiegowania-wykorzystali-balon-eksperci-komentuja-6727227?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 06:34:10+00:00
 - user: None

<img alt="Dlaczego balon? Wojskowi lubią je coraz bardziej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4kf6m8-domniemany-chinski-balon-szpiegowski-nad-usa-6724370/alternates/LANDSCAPE_1280" />
    Eksperci w rozmowie z "Washington Post".

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-5-lutego-2023-6727213?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-5-lutego-2023-6727213?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 06:29:45+00:00
 - user: None

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ez29a-ukrainscy-zolnierze-strzelaja-z-dziala-przeciwlotniczego-w-poblizu-bachmutu-6727212/alternates/LANDSCAPE_1280" />
    Inwazja Rosji trwa od 347 dni.

## Nie żyją 23 osoby, około 1000 rannych, 83 pożary "poza kontrolą"
 - [https://tvn24.pl/tvnmeteo/swiat/chile-ofiary-smiertelne-pozarow-ogien-strawil-obszar-wiekszy-niz-filadelfia-6727132?source=rss](https://tvn24.pl/tvnmeteo/swiat/chile-ofiary-smiertelne-pozarow-ogien-strawil-obszar-wiekszy-niz-filadelfia-6727132?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 06:10:19+00:00
 - user: None

<img alt="Nie żyją 23 osoby, około 1000 rannych, 83 pożary " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k6cyxu-pozary-trawia-chile-sa-ofiary-smiertelne-6727129/alternates/LANDSCAPE_1280" />
    Ogień trawi kolejne tereny w Chile.

## Pakistan zablokował jeden z największych serwisów internetowych za "bluźniercze treści"
 - [https://tvn24.pl/swiat/pakistan-zablokowal-wikipedie-za-bluzniercze-tresci-6727193?source=rss](https://tvn24.pl/swiat/pakistan-zablokowal-wikipedie-za-bluzniercze-tresci-6727193?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 05:40:41+00:00
 - user: None

<img alt="Pakistan zablokował jeden z największych serwisów internetowych za " src="https://tvn24.pl/najnowsze/cdn-zdjecie-07fldb-ludzie-czytaja-koran-na-ulicy-w-pakistanie-6724127/alternates/LANDSCAPE_1280" />
    Szczegółów nie ujawniono.

## Lokalnie możliwe -22 stopnie. IMGW ostrzega
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-mroz-mozliwy-spadek-temperatury-do-22-stopni-mrozu-sa-alarmy-imgw-6727220?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-mroz-mozliwy-spadek-temperatury-do-22-stopni-mrozu-sa-alarmy-imgw-6727220?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 05:34:07+00:00
 - user: None

<img alt="Lokalnie możliwe -22 stopnie. IMGW ostrzega" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fdv1wi-mrozna-aura-w-polsce-5005322/alternates/LANDSCAPE_1280" />
    Przewidywane są także alarmy w kolejnych dniach.

## W części kraju ściśnie silny mróz. Prognoza zagrożeń IMGW
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-mroz-w-czesci-kraju-scisnie-silny-mroz-imgw-wydal-prognoze-pogodowych-zagrozen-6727220?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-mroz-w-czesci-kraju-scisnie-silny-mroz-imgw-wydal-prognoze-pogodowych-zagrozen-6727220?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 05:34:07+00:00
 - user: None

<img alt="W części kraju ściśnie silny mróz. Prognoza zagrożeń IMGW" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-v2d664-mrozno-w-polsce-5539847/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie aura da się we znaki.

## Martwi słaba forma Stocha. "Kamil się męczy"
 - [https://eurosport.tvn24.pl/martwi-s-aba-forma-stocha---kamil-si--m-czy-,1135398.html?source=rss](https://eurosport.tvn24.pl/martwi-s-aba-forma-stocha---kamil-si--m-czy-,1135398.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 05:22:00+00:00
 - user: None

<img alt="Martwi słaba forma Stocha. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6unzoh-kamil-stoch/alternates/LANDSCAPE_1280" />
    Thomas Thurnbichler zaniepokojony występem Kamila Stocha w sobotnim konkursie Pucharu Świata w Willingen.

## "Ocalimy nasz kraj". Media: ponad 100 tysięcy osób na ulicach izraelskich miast
 - [https://tvn24.pl/swiat/protesty-w-izraelu-przeciwko-reformom-wymiaru-sprawiedliwosci-6727188?source=rss](https://tvn24.pl/swiat/protesty-w-izraelu-przeciwko-reformom-wymiaru-sprawiedliwosci-6727188?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 05:18:24+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bj8tx4-ludzie-bioracy-udzial-w-protescie-przeciwko-rzadowi-w-tel-awiwie-0402-6727189/alternates/LANDSCAPE_1280" />
    Demonstracje przeciwko planom reformy sądownictwa odbywają się już piątą sobotę z rzędu.

## Choroba zmusiła go do wycofania się. "Gdzieś tam wewnątrz było cierpienie"
 - [https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-118,S00E118,983644?source=rss](https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-118,S00E118,983644?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 05:00:00+00:00
 - user: None

<img alt="Choroba zmusiła go do wycofania się. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7jukr9-bez-polityki-dziedziel-6727158/alternates/LANDSCAPE_1280" />
    Marian Dziędziel w rozmowie z Piotrem Jaconiem.

## "Jeszcze jedna ofensywa i Ukraina się załamie". Ekspertka o "wielkiej bańce" Putina
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-dyskusja-ekspertow-w-faktach-po-faktach-6727199?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-dyskusja-ekspertow-w-faktach-po-faktach-6727199?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 04:28:16+00:00
 - user: None

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-z0nme0-wladimir-putin-6630872/alternates/LANDSCAPE_1280" />
    Doktor Katarzyna Pisarska i doktor Ludwika Włodek w "Faktach po Faktach".

## "Jest co do tego zgoda". Scholz o deklaracji Zełenskiego
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-5-lutego-2023-6727194?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-5-lutego-2023-6727194?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-02-05 04:23:21+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9nu53h-ukraina-wojsko-6679179/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.
