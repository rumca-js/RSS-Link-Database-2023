# Source The Intercept, Source URL:https://theintercept.com/feed/?lang=en, Source language: en-US

## Missouri Is About to Kill a Man Who Witnesses Say Was 2,000 Miles Away at the Time of the Crime
 - [https://theintercept.com/2023/02/05/missouri-leonard-raheem-taylor-execution/](https://theintercept.com/2023/02/05/missouri-leonard-raheem-taylor-execution/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-02-05 18:50:09+00:00
 - user: None

<p>Leonard “Raheem” Taylor is scheduled for execution on Tuesday, but the state’s case against him doesn’t add up.</p>
<p>The post <a href="https://theintercept.com/2023/02/05/missouri-leonard-raheem-taylor-execution/" rel="nofollow">Missouri Is About to Kill a Man Who Witnesses Say Was 2,000 Miles Away at the Time of the Crime</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>
