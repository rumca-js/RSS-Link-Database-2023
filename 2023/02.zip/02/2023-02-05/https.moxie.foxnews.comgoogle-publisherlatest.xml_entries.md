# Source Fox News, Source URL:https://moxie.foxnews.com/google-publisher/latest.xml, Source language: en-US

## South Korea boat capsizes, 9 fishermen missing
 - [https://www.foxnews.com/world/south-korea-boat-capsizes-fishermen-missing](https://www.foxnews.com/world/south-korea-boat-capsizes-fishermen-missing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 23:31:44+00:00
 - user: None

Nine fishermen remain missing after a 24-ton South Korean vessel capsized off the country's southwestern coast Saturday evening, authorities said.

## Columbia journalism dean suggests a 'self-hating dynamic' from the officers played role in Tyre Nichols death
 - [https://www.foxnews.com/media/columbia-journalism-dean-suggests-self-hating-dynamic-officers-played-role-tyre-nichols-death](https://www.foxnews.com/media/columbia-journalism-dean-suggests-self-hating-dynamic-officers-played-role-tyre-nichols-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 23:24:03+00:00
 - user: None

Columbia journalism dean Jelani Cobb suggested on PBS' Amanpour & Co. that the Black officers in Tyre Nichols death could have been driven by 'white supremacy.'

## Charles Barkley reveals why Tom Brady's 'career is unparalleled'
 - [https://www.foxnews.com/sports/charles-barkley-reveals-why-tom-bradys-career-unparalleled](https://www.foxnews.com/sports/charles-barkley-reveals-why-tom-bradys-career-unparalleled)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 23:15:35+00:00
 - user: None

Charles Barkley was asked about the comparison of careers between Tom Brady and LeBron James and gave a surprising answer to the question.

## Peyton Manning's son, Marshall, looks just like dad in the pocket at 2023 Pro Bowl
 - [https://www.foxnews.com/sports/peyton-mannings-son-marshall-looks-like-dad-pocket-2023-pro-bowl](https://www.foxnews.com/sports/peyton-mannings-son-marshall-looks-like-dad-pocket-2023-pro-bowl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 23:06:44+00:00
 - user: None

Peyton Manning's 11-year-old son, Marshall, takes after his Hall of Fame father as he was seen throwing dimes to Pro Bowlers in Las Vegas on Sunday.

## Florida cat given away by owner for being 'too affectionate' finds new home
 - [https://www.foxnews.com/us/florida-cat-given-away-owner-being-too-affectionate-finds-new-home](https://www.foxnews.com/us/florida-cat-given-away-owner-being-too-affectionate-finds-new-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 22:53:35+00:00
 - user: None

A cat named Jerry was surrendered to the Humane Society of Broward County in December for being "too affectionate," according to representatives.

## Nikole Hannah-Jones suggests '1619 Project' criticism is 'not legitimate'
 - [https://www.foxnews.com/media/nikole-hannah-jones-suggests-1619-project-criticism-not-legitimate](https://www.foxnews.com/media/nikole-hannah-jones-suggests-1619-project-criticism-not-legitimate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 22:53:02+00:00
 - user: None

The “1619 Project” author Nikole Hannah-Jones suggested that criticism for her work is “not legitimate” while defending it on MSNBC’s “Velshi” Saturday.

## Grammys red carpet: Hollywood stars dare to bare on music's biggest night
 - [https://www.foxnews.com/entertainment/grammys-red-carpet-hollywood-stars-dare-to-bare-music-biggest-night](https://www.foxnews.com/entertainment/grammys-red-carpet-hollywood-stars-dare-to-bare-music-biggest-night)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 22:44:07+00:00
 - user: None

2023 Grammys begin with the hottest fashions at the Crypto Arena in Los Angeles as Grammy nominated musicians flaunt wild outfits ahead of award show.

## WWE legend 'Superstar' Billy Graham 'dealing with a myriad of very serious health issues,' family says
 - [https://www.foxnews.com/sports/wwe-legend-superstar-billy-graham-dealing-myriad-very-serious-health-issues-family-says](https://www.foxnews.com/sports/wwe-legend-superstar-billy-graham-dealing-myriad-very-serious-health-issues-family-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 22:41:53+00:00
 - user: None

"Superstar" Billy Graham is dealing with a myriad of health issues, according to his family. He nearly lost 50 pounds in a few weeks and will need intense rehab.

## Charles Kimbrough, 'Murphy Brown' actor, dead at 86
 - [https://www.foxnews.com/entertainment/charles-kimbrough-murphy-brown-actor-dead-86](https://www.foxnews.com/entertainment/charles-kimbrough-murphy-brown-actor-dead-86)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 22:07:39+00:00
 - user: None

Charles Kimbrough played anchor Jim Dial for 10 seasons on the hit CBS sitcom "Murphy Brown" opposite Candice Bergen. He died in January at the age of 86.

## 49ers should bring back Jimmy Garoppolo as starting quarterback, NFL legend says
 - [https://www.foxnews.com/sports/49ers-should-bring-back-jimmy-garoppolo-starting-quarterback-nfl-legend-joe-montana-says](https://www.foxnews.com/sports/49ers-should-bring-back-jimmy-garoppolo-starting-quarterback-nfl-legend-joe-montana-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 22:02:58+00:00
 - user: None

San Francisco 49ers legend Joe Montana said he believes the team should bring Jimmy Garoppolo back as the team's starting quarterback.

## Iranian security forces accused of shooting eyes of young female protesters
 - [https://www.foxnews.com/world/iranian-security-forces-accused-shooting-eyes-young-female-protesters](https://www.foxnews.com/world/iranian-security-forces-accused-shooting-eyes-young-female-protesters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 22:02:18+00:00
 - user: None

A Norwegian-based human rights group is accusing Iranian security forces of deliberately shooting protesters -- particularly young women -- in the eye.

## NBC's Chuck Todd asks Pete Buttigieg why Biden's accomplishments aren't being celebrated by the public
 - [https://www.foxnews.com/media/nbcs-chuck-todd-pete-buttigieg-bidens-accomplishments-celebrated-public](https://www.foxnews.com/media/nbcs-chuck-todd-pete-buttigieg-bidens-accomplishments-celebrated-public)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 22:00:18+00:00
 - user: None

'Meet the Press' anchor Chuck Todd asked Pete Buttigieg why President Biden's achievements in office haven't been 'penetrating' the American public.

## Spy balloon likely sent extensive intelligence to China, experts say
 - [https://www.foxnews.com/politics/spy-balloon-likely-sent-extensive-intelligence-to-china-experts-say](https://www.foxnews.com/politics/spy-balloon-likely-sent-extensive-intelligence-to-china-experts-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:46:03+00:00
 - user: None

The Chinese spy balloon was likely able to send sensitive data to China before it was shot down by the U.S. military Saturday, foreign policy experts told Fox News Digital.

## Christie slams Trump as 'only man to lose to Biden outside Delaware' after Trump calls him 'sloppy'
 - [https://www.foxnews.com/politics/christie-slams-trump-only-man-lose-biden-outside-delaware-trump-calls-sloppy](https://www.foxnews.com/politics/christie-slams-trump-only-man-lose-biden-outside-delaware-trump-calls-sloppy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:44:51+00:00
 - user: None

Former New Jersey Gov. Chris Christie said Sunday that former President Donald Trump is still scorned from his 2020 loss to President Biden.

## San Jose police officer shot, wounded after suspect flees traffic stop
 - [https://www.foxnews.com/us/san-jose-police-officer-shot-wounded-suspect-flees-traffic-stop](https://www.foxnews.com/us/san-jose-police-officer-shot-wounded-suspect-flees-traffic-stop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:32:43+00:00
 - user: None

A San Jose police officer was shot and wounded in an exchange of gunfire after a suspect fled a traffic stop earlier in the evening, according to the department.

## Liberals falsely attack DeSantis using Associated Press fact-check that vindicates him: 'Authoritarianism'
 - [https://www.foxnews.com/media/liberals-falsely-attack-desantis-using-associated-press-fact-check-vindicates](https://www.foxnews.com/media/liberals-falsely-attack-desantis-using-associated-press-fact-check-vindicates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:30:03+00:00
 - user: None

Left-wing activists and figures attacked Gov. Ron DeSantis for allegedly “mandating menstrual cycle details” by using an Associated Press fact-check that debunks the claim.

## NHL legend Dominik Hasek slams league for allowing Alex Ovechkin's son to skate at All-Star event
 - [https://www.foxnews.com/sports/nhl-legend-dominik-hasek-slams-league-allowing-alex-ovechkins-son-skate-all-star-event](https://www.foxnews.com/sports/nhl-legend-dominik-hasek-slams-league-allowing-alex-ovechkins-son-skate-all-star-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:24:50+00:00
 - user: None

Hockey Hall of Famer Dominik Hasek slammed the NHL for allowing Alexander Ovechkin's son to take part in All-Star Game festivities on Friday night.

## Dodgers announce Fernando Valenzuela's No 34 to be retired this season
 - [https://www.foxnews.com/sports/dodgers-announce-fernando-valenzuelas-no-34-retired-this-season](https://www.foxnews.com/sports/dodgers-announce-fernando-valenzuelas-no-34-retired-this-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:19:30+00:00
 - user: None

The Los Angeles Dodgers announced Saturday that legendary pitcher Fernando Valenzuela will have his No. 34 retired this August.

## Idaho Satanists plan 'gender affirmation ritual' to protest ban on surgeries for children: 'I praise myself'
 - [https://www.foxnews.com/us/idaho-satanists-plan-gender-affirmation-ritual-to-protest-ban-surgeries-children-i-praise-myself](https://www.foxnews.com/us/idaho-satanists-plan-gender-affirmation-ritual-to-protest-ban-surgeries-children-i-praise-myself)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:18:03+00:00
 - user: None

The Satanic Temple plans to oppose a proposed Idaho bill that would prohibit sex-change surgery and drugs for minors by holding a ritual at the state Capitol.

## Biden only mentioned China 3 times in 2022 State of the Union address
 - [https://www.foxnews.com/politics/biden-mentioned-china-3-times-2022-state-union-address](https://www.foxnews.com/politics/biden-mentioned-china-3-times-2022-state-union-address)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:16:42+00:00
 - user: None

President Joe Biden only mentioned China and Chinese President Xi Jinping three times during his last State of the Union address on March 1, 2022.

## North Carolina man's remains found in 55-gallon barrel filled with concrete
 - [https://www.foxnews.com/us/north-carolina-mans-remains-found-in-55-gallon-barrel-filled-with-concrete](https://www.foxnews.com/us/north-carolina-mans-remains-found-in-55-gallon-barrel-filled-with-concrete)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:15:54+00:00
 - user: None

Lee County Sheriff's Department in North Carolina announced it located the dismembered remains of a man who went missing in December 2022, in a barrel with concrete.

## Green groups targeting blue-collar lobstermen are largely funded by dark money
 - [https://www.foxnews.com/politics/green-groups-targeting-blue-collar-lobstermen-funded-dark-money](https://www.foxnews.com/politics/green-groups-targeting-blue-collar-lobstermen-funded-dark-money)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 21:00:24+00:00
 - user: None

Multiple groups that have for years partnered to sue the federal government have raked in millions of dollars from dark money networks fueled by undisclosed liberal donors.

## Chinese spy balloons over US during Trump admin 'discovered after' he left office: senior Biden official
 - [https://www.foxnews.com/politics/chinese-spy-balloons-over-us-during-trump-admin-discovered-after-he-left-office-senior-biden-official](https://www.foxnews.com/politics/chinese-spy-balloons-over-us-during-trump-admin-discovered-after-he-left-office-senior-biden-official)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 20:59:23+00:00
 - user: None

Information suggesting that Chinese spy balloons traveled over the continental United States during the Trump administration was “discovered after” former President Trump left office, a senior administration official told Fox News.

## Chinese surveillance balloon: Pentagon to brief US Senate on Feb. 15, Schumer says
 - [https://www.foxnews.com/politics/chinese-surveillance-balloon-pentagon-brief-us-senate-feb-15-schumer-says](https://www.foxnews.com/politics/chinese-surveillance-balloon-pentagon-brief-us-senate-feb-15-schumer-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 20:52:18+00:00
 - user: None

The Department of Defense's Office of Net Assessment will brief the full U.S. Senate some time next week on the Chinese surveillance balloon that was shot down on Saturday.

## Our country 'cannot go another two years' with Secretary Mayorkas in charge of the border: Rep. Biggs
 - [https://www.foxnews.com/media/country-cannot-go-another-two-years-secretary-mayorkas-charge-border-rep-biggs](https://www.foxnews.com/media/country-cannot-go-another-two-years-secretary-mayorkas-charge-border-rep-biggs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 20:50:43+00:00
 - user: None

Rep. Andy Biggs, R-Ariz., declared that our country couldn't handle another two year years under Department of Homeland Security Secretary Alejandro Mayorkas' leadership.

## Marijuana users have a constitutional right to own firearms, judge rules
 - [https://www.foxnews.com/us/marijuana-users-constitutional-right-own-firearms-judge-rules](https://www.foxnews.com/us/marijuana-users-constitutional-right-own-firearms-judge-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 20:49:11+00:00
 - user: None

Marijuana users have a constitutional right to own firearms, a federal judge in Oklahoma City ruled on Friday, marking the latest challenge to firearms regulations.

## Illinois family creates kid-friendly content that makes other parents laugh: 'Can never go wrong'
 - [https://www.foxnews.com/lifestyle/illinois-family-creates-kid-friendly-content-makes-parents-laugh-never-go-wrong](https://www.foxnews.com/lifestyle/illinois-family-creates-kid-friendly-content-makes-parents-laugh-never-go-wrong)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 20:41:11+00:00
 - user: None

The Younes family of Illinois creates funny, relatable videos that scores of other families can enjoy. Ali Younes explains the family makes between 3-5 videos a week to make others laugh.

## Arizona Border Patrol: man takes off on horseback after smuggling illegal immigrants into US
 - [https://www.foxnews.com/us/arizona-border-patrol-man-takes-horseback-smuggling-illegal-immigrants-us](https://www.foxnews.com/us/arizona-border-patrol-man-takes-horseback-smuggling-illegal-immigrants-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 20:21:01+00:00
 - user: None

A man suspected of smuggling seven illegal immigrants into the US under hay bales tried to evade Border Patrol agents by taking off on horseback, authorities say.

## Nets trade Kyrie Irving to Mavericks in blockbuster deal: reports
 - [https://www.foxnews.com/sports/nets-trade-kyrie-irving-mavericks-blockbuster-deal](https://www.foxnews.com/sports/nets-trade-kyrie-irving-mavericks-blockbuster-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 20:12:07+00:00
 - user: None

The Brooklyn Nets have reportedly fulfilled Kyrie Irving's trade request, as multiple reports have him being sent to the Dallas Mavericks in a blockbuster move.

## Biden’s botched response to China’s spy balloon was a national security ‘blunder’ of ‘incalculable damage’
 - [https://www.foxnews.com/media/bidens-botched-response-chinas-spy-balloon-national-security-blunder-incalculable-damage](https://www.foxnews.com/media/bidens-botched-response-chinas-spy-balloon-national-security-blunder-incalculable-damage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 20:00:43+00:00
 - user: None

Former Director of National Intelligence John Ratcliffe reacts to the Biden administration's highly controversial handling of China's spy balloon.

## Warriors superstar Steph Curry expected to miss 'multiple weeks' with leg injury: report
 - [https://www.foxnews.com/sports/warriors-superstar-steph-curry-expected-miss-multiple-weeks-leg-injury](https://www.foxnews.com/sports/warriors-superstar-steph-curry-expected-miss-multiple-weeks-leg-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:56:59+00:00
 - user: None

Golden State Warriors superstar guard Steph Curry is expected to miss "multiple weeks" after colliding knees with a Dallas Mavericks player on Saturday night.

## NFL legend Lawrence Taylor lists top 5 defensive players of all time, leaves off one notable current star
 - [https://www.foxnews.com/sports/nfl-legend-lawrence-taylor-lists-top-5-defensive-players-all-time-leaves-notable-current-star](https://www.foxnews.com/sports/nfl-legend-lawrence-taylor-lists-top-5-defensive-players-all-time-leaves-notable-current-star)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:56:10+00:00
 - user: None

Former New York Giants linebacker Lawrence Taylor listed his top five defensive players of all time in a recent podcast interview but didn't put Aaron Donald on it.

## Hunter Biden's former business associate has raked in over $500K from pro-Biden super PAC
 - [https://www.foxnews.com/politics/hunter-bidens-former-business-associate-raked-500k-pro-biden-super-pac](https://www.foxnews.com/politics/hunter-bidens-former-business-associate-raked-500k-pro-biden-super-pac)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:46:36+00:00
 - user: None

The consulting firm co-founded by Hunter Biden’s former business associate raked in over $500,000 from a super PAC that helped elect President Biden.

## British journalist cheered on BBC for blasting politicians who have 'given up' on belief that 'sex is real'
 - [https://www.foxnews.com/media/british-journalist-cheered-bbc-blasting-politicians-who-given-up-belief-sex-real](https://www.foxnews.com/media/british-journalist-cheered-bbc-blasting-politicians-who-given-up-belief-sex-real)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:30:54+00:00
 - user: None

A British journalist is cheered by politicians and activists for blasting UK politicians who she said had "given up" on the belief that "sex is real."

## Navy divers working to recover China spy balloon debris with Coast Guard, Navy ships on site
 - [https://www.foxnews.com/us/navy-divers-working-recover-china-spy-balloon-debris-coast-guard-navy-ships-site](https://www.foxnews.com/us/navy-divers-working-recover-china-spy-balloon-debris-coast-guard-navy-ships-site)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:23:37+00:00
 - user: None

The U.S. Navy is working to recover the debris from the suspected Chinese spy balloon shot down off the coast of South Carolina. Navy divers are working at depths of 50 feet.

## Rep. Clyburn expects positive response to Biden's reelection bid, despite negative poll ratings
 - [https://www.foxnews.com/politics/rep-clyburn-expects-positive-response-bidens-reelection-bid-despite-negative-poll-ratings](https://www.foxnews.com/politics/rep-clyburn-expects-positive-response-bidens-reelection-bid-despite-negative-poll-ratings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:19:45+00:00
 - user: None

Rep. James Clyburn said Sunday he expects the U.S. will respond positively to President Biden's candidacy despite staggering poll numbers showing Americans' dissatisfaction.

## Raiders' Josh Jacobs called out for blunt critique of Pro Bowl Games: 'Am I missing something?'
 - [https://www.foxnews.com/sports/raiders-josh-jacobs-called-out-blunt-critique-pro-bowl-games-missing-something](https://www.foxnews.com/sports/raiders-josh-jacobs-called-out-blunt-critique-pro-bowl-games-missing-something)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:17:05+00:00
 - user: None

Las Vegas Raiders running back Josh Jacobs received some backlash from an NFL colleague on Saturday after he called the new Pro Bowl Games format "stupid."

## 'Fox News Sunday' on February 5, 2022
 - [https://www.foxnews.com/transcript/fox-news-sunday-february-5-2022](https://www.foxnews.com/transcript/fox-news-sunday-february-5-2022)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:15:19+00:00
 - user: None

This week, 'Fox News Sunday' welcomed Sen. Tom Cotton, White House Chief Economist Jared Bernstein, and more to discuss this week's top political news.

## Change this hidden setting, or anyone can get into your iPhone
 - [https://www.foxnews.com/tech/change-hidden-setting-anyone-can-get-your-iphone](https://www.foxnews.com/tech/change-hidden-setting-anyone-can-get-your-iphone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:15:17+00:00
 - user: None

Face ID is easy to use and automatically adapts to changes in your appearance; however, you should take the following measures to increase your security.

## Four hurt, 1 killed following shooting in Colorado
 - [https://www.foxnews.com/us/four-hurt-1-killed-following-shooting-colorado](https://www.foxnews.com/us/four-hurt-1-killed-following-shooting-colorado)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:07:36+00:00
 - user: None

Four wounded, one dead following a shooting in El Paso County, Colo. early Sunday morning, local reports say. The FBI and Colorado Springs Police Department are assisting in the investigation.

## Lakers legend Magic Johnson knows where Kyrie Irving should be dealt
 - [https://www.foxnews.com/sports/lakers-legend-magic-johnson-knows-where-kyrie-irving-should-be-dealt](https://www.foxnews.com/sports/lakers-legend-magic-johnson-knows-where-kyrie-irving-should-be-dealt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 19:02:34+00:00
 - user: None

After requesting the Brooklyn Nets trade him prior to the deadline, Kyrie Irving is the biggest name on the NBA trade block. Magic Johnson knows where he wants the guard to land.

## NH GOP Gov. Sununu says Trump would lose to Biden in 2024
 - [https://www.foxnews.com/politics/nh-gop-gov-sununu-trump-lose-biden-2024](https://www.foxnews.com/politics/nh-gop-gov-sununu-trump-lose-biden-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 18:45:51+00:00
 - user: None

Republican New Hampshire Gov. Chris Sununu said that former President Donald Trump would be unable to defeat President Biden in an election rematch in 2024.

## Surfer Bethany Hamilton speaks out against new rule allowing transgender women to compete with females
 - [https://www.foxnews.com/lifestyle/bethany-hamilton-surfer-speaks-against-rule-transgender-compete-females](https://www.foxnews.com/lifestyle/bethany-hamilton-surfer-speaks-against-rule-transgender-compete-females)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 18:45:31+00:00
 - user: None

Bethany Hamilton, mom, author and professional surfer, is speaking out against a new policy by the World Surf League that will allow trans women to complete against biological females in surfing.

## Republican Gov. Chris Sununu issues bold prediction about Trump's 2024 chances: 'He can't get it done'
 - [https://www.foxnews.com/politics/republican-gov-chris-sununu-issues-bold-prediction-trumps-2024-chances-cant-get-done](https://www.foxnews.com/politics/republican-gov-chris-sununu-issues-bold-prediction-trumps-2024-chances-cant-get-done)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 18:35:48+00:00
 - user: None

Former President Donald Trump doesn't have what it takes to beat President Biden in the 2024 presidential race, Republican New Hampshire Gov. Chris Sununu said Sunday.

## Maria Bartiromo breaks down CCP espionage with Sen. Rand Paul, Rep. Mike Gallagher, former DNI John Ratcliffe
 - [https://www.foxnews.com/media/maria-bartiromo-breaks-down-ccp-espionage-with-rep-mike-gallagher-john-ratcliffe-sen-rand-paul-and-more](https://www.foxnews.com/media/maria-bartiromo-breaks-down-ccp-espionage-with-rep-mike-gallagher-john-ratcliffe-sen-rand-paul-and-more)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 18:31:59+00:00
 - user: None

Maria Bartiromo speaks exclusively with Former DNI John Ratcliffe, Rep. Mike Gallagher, Sen. Rand Paul, and Rep. Jason Smith to break down the latest on CCP espionage.

## 49ers' Brandon Aiyuk on NFC Championship loss: Eagles got 'extremely lucky'
 - [https://www.foxnews.com/sports/49ers-brandon-aiyuk-nfc-championship-loss-eagles-extremely-lucky](https://www.foxnews.com/sports/49ers-brandon-aiyuk-nfc-championship-loss-eagles-extremely-lucky)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 18:31:31+00:00
 - user: None

San Francisco 49ers wide receiver Brandon Aiyuk opened up about the NFC Championship loss to the Philadelphia Eagles in a podcast interview.

## 'Top Gun 3' trends on Twitter following military takedown of Chinese spy balloon
 - [https://www.foxnews.com/media/top-gun-3-trends-twitter-following-military-takedown-chinese-spy-balloon](https://www.foxnews.com/media/top-gun-3-trends-twitter-following-military-takedown-chinese-spy-balloon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 18:30:52+00:00
 - user: None

Twitter users made "Top Gun 3" trend with a barrage of jokes and memes surrounding the missile takedown of the suspected Chinese spy balloon Saturday.

## Eric Adams spends coldest winter night in shelter after migrants refused to leave hotel
 - [https://www.foxnews.com/politics/eric-adams-spends-coldest-winter-night-tent-city-migrants-refused-leave-hotel](https://www.foxnews.com/politics/eric-adams-spends-coldest-winter-night-tent-city-migrants-refused-leave-hotel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 18:23:46+00:00
 - user: None

Democratic New York City Mayor Eric Adams slept at the Brooklyn Cruise Terminal, where a housing facility for migrants was set up, to show how warm and welcoming the housing is.

## Giants' Logan Webb admits team was 'butthurt' after learning Aaron Judge re-signed with Yankees
 - [https://www.foxnews.com/sports/giants-logan-webb-admits-team-butthurt-learning-aaron-judge-re-signed-yankees](https://www.foxnews.com/sports/giants-logan-webb-admits-team-butthurt-learning-aaron-judge-re-signed-yankees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 18:02:33+00:00
 - user: None

San Francisco Giants pitcher Logan Webb came clean about the reaction to Aaron Judge deciding to stay with the New York Yankees amid reports to the contrary.

## GOP senator calls for investigation into spy balloon handling: 'The American people deserve answers'
 - [https://www.foxnews.com/media/gop-senator-calls-for-investigation-into-spy-balloon-handling-american-people-deserve-answers](https://www.foxnews.com/media/gop-senator-calls-for-investigation-into-spy-balloon-handling-american-people-deserve-answers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 18:00:15+00:00
 - user: None

Senator Eric Schmitt, R-Mo., discusses the need for an investigation into the Biden administration's handling of the Chinese spy balloon.

## US intel assesses Chinese spy balloons transited US several times, went 'undetected': Senior admin official
 - [https://www.foxnews.com/politics/us-intel-assesses-chinese-spy-balloons-transited-us-several-times-went-undetected-senior-admin-official](https://www.foxnews.com/politics/us-intel-assesses-chinese-spy-balloons-transited-us-several-times-went-undetected-senior-admin-official)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:59:27+00:00
 - user: None

U.S. intelligence assesses that Chinese government surveillance balloons have transited the continental United States several times but went “undetected,” a senior administration official told Fox News Digital.

## California man arrested in shooting of 15-year-old girl near high school, police say
 - [https://www.foxnews.com/us/california-man-arrested-shooting-15-year-old-girl-high-school-police-say](https://www.foxnews.com/us/california-man-arrested-shooting-15-year-old-girl-high-school-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:58:51+00:00
 - user: None

Leon Arreguin, 36, was arrested in connection with a shooting that injured a 15-year-old girl on Tuesday near Vallejo High School in California, authorities said.

## Nets benching Kyrie Irving until trade is finalized before deadline: report
 - [https://www.foxnews.com/sports/nets-benching-kyrie-irving-trade-finalized-before-deadline-report](https://www.foxnews.com/sports/nets-benching-kyrie-irving-trade-finalized-before-deadline-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:54:19+00:00
 - user: None

The Brooklyn Nets are reportedly planning on benching star guard Kyrie Irving, who requested a trade, until they can finalize one before the deadline.

## Chinese spy balloon crashed off the coast of Hawaii 4 months ago, U.S. officials say
 - [https://www.foxnews.com/politics/chinese-spy-balloon-crashed-off-coast-of-hawaii-4-months-ago](https://www.foxnews.com/politics/chinese-spy-balloon-crashed-off-coast-of-hawaii-4-months-ago)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:51:49+00:00
 - user: None

A Chinese spy balloon crashed off the coast of Hawaii four months ago, and at least one Chinese spy balloon flew over portions of Texas and Florida during the Trump administration.

## House Republicans to get briefing on Biden, Trump, Pence classified documents this week
 - [https://www.foxnews.com/politics/house-republicans-get-briefing-biden-trump-pence-classified-documents-week](https://www.foxnews.com/politics/house-republicans-get-briefing-biden-trump-pence-classified-documents-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:50:23+00:00
 - user: None

Congress will receive a briefing on the contents of classified material found at the homes of President Biden, frmr. President Trump and fmr. Vice President Pence this week.

## Reporter's Notebook: Does the near death of the Iran nuclear deal mean the end of diplomacy?
 - [https://www.foxnews.com/world/reporters-notebook-does-near-death-iran-nuclear-deal-mean-end-diplomacy](https://www.foxnews.com/world/reporters-notebook-does-near-death-iran-nuclear-deal-mean-end-diplomacy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:41:31+00:00
 - user: None

Fox News correspondent Amy Kellogg delves into the latest on the floundering Iran nuclear deal and discusses with two analysts the present state of affairs.

## Arizona hospital on brink of collapse after spending $20 million on migrant care: 'Nobody has a solution'
 - [https://www.foxnews.com/media/arizona-hospital-brink-collapse-spending-20-million-migrant-care-nobody-has-solution](https://www.foxnews.com/media/arizona-hospital-brink-collapse-spending-20-million-migrant-care-nobody-has-solution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:30:32+00:00
 - user: None

Yuma Regional Medical Center CEO Dr. Robert Transchel relayed his concerns about an influx of migrant patients receiving care while being unable to cover the costs.

## Tom Hanks and Rita Wilson joke they have the $17 billion dollar secret to a successful marriage
 - [https://www.foxnews.com/entertainment/tom-hanks-rita-wilson-joke-have-17-billion-dollar-secret-successful-marriage](https://www.foxnews.com/entertainment/tom-hanks-rita-wilson-joke-have-17-billion-dollar-secret-successful-marriage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:09:52+00:00
 - user: None

Tom Hanks and Rita Wilson walked the red carpet at Clive Davis' Pre-Grammy Gala, explaining if there really is a secret to a successful marriage.

## Tom Hanks and Rita Wilson joke they have the $17 billion secret to a successful marriage
 - [https://www.foxnews.com/entertainment/tom-hanks-rita-wilson-joke-have-17-billion-secret-successful-marriage](https://www.foxnews.com/entertainment/tom-hanks-rita-wilson-joke-have-17-billion-secret-successful-marriage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:09:52+00:00
 - user: None

Tom Hanks and Rita Wilson walked the red carpet at Clive Davis' Pre-Grammy Gala, explaining if there really is a secret to a successful marriage.

## Rand Paul warns Biden's 'weak' response to China's balloon is 'damaging,' urges him to 'demand an explanation'
 - [https://www.foxnews.com/media/rand-paul-warns-biden-weak-response-china-spy-balloon-damaging-urges-president-demand-explanation](https://www.foxnews.com/media/rand-paul-warns-biden-weak-response-china-spy-balloon-damaging-urges-president-demand-explanation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:06:41+00:00
 - user: None

Sen. Rand Paul, R-Ky., blasted the Biden administration's 'ineptitude' on the Chinese spy balloon dustup, saying the balloon should have been taken down sooner.

## 5 things Jesus never said
 - [https://www.foxnews.com/opinion/5-things-jesus-never-said](https://www.foxnews.com/opinion/5-things-jesus-never-said)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:00:58+00:00
 - user: None

Not everything the world tells us about God is true. For instance, Jesus gets credited with a lot of statements or ideas that He never said.

## Potential fentanyl vaccine, test kits a 'great breakthrough' to combat synthetic opioid deaths
 - [https://www.foxnews.com/media/potential-fentanyl-vaccine-test-kits-great-breakthrough-combat-synthetic-opioid-deaths](https://www.foxnews.com/media/potential-fentanyl-vaccine-test-kits-great-breakthrough-combat-synthetic-opioid-deaths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:00:47+00:00
 - user: None

Certified physician Dr. Frita Fisher discusses the recent advancement made by researchers in their development of a potential fentanyl vaccine.

## Jennifer Lopez’s plunging green Versace dress: Grammys' head-turning and sexiest fashion over the years
 - [https://www.foxnews.com/entertainment/jennifer-lopez-plunging-green-versace-dress-grammys-head-turning-sexiest-fashion-over-years](https://www.foxnews.com/entertainment/jennifer-lopez-plunging-green-versace-dress-grammys-head-turning-sexiest-fashion-over-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 17:00:04+00:00
 - user: None

The Grammy Awards red carpet is a place for Hollywood stars to showcase their fashion sense. Dolly Parton, Dua Lipa and Jennifer Lopez are among the celebs who have turned heads.

## Miami Black leaders apologize to Gov. Ron DeSantis after a member called him racist
 - [https://www.foxnews.com/politics/miami-black-leaders-apologize-gov-ron-desantis-member-called-him-racist](https://www.foxnews.com/politics/miami-black-leaders-apologize-gov-ron-desantis-member-called-him-racist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:52:25+00:00
 - user: None

Black leaders in Miami apologized to Florida Gov. Ron DeSantis after one of its members called him a racist in response to his actions related to content in schools.

## Colorado State student section heard chanting 'Russia!' at Utah State player from Ukraine
 - [https://www.foxnews.com/sports/colorado-state-student-section-chanting-russia-utah-state-player-ukraine](https://www.foxnews.com/sports/colorado-state-student-section-chanting-russia-utah-state-player-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:48:54+00:00
 - user: None

Utah State guard Max Shulga, a native of Ukraine, heard the Colorado State student section chanting "Russia!" at him during a college basketball game on Saturday night.

## White House economic advisor cites job report as proof U.S. is 'not recessionary'
 - [https://www.foxnews.com/politics/white-house-economic-advisor-cites-job-report-proof-not-recessionary](https://www.foxnews.com/politics/white-house-economic-advisor-cites-job-report-proof-not-recessionary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:45:16+00:00
 - user: None

In an interview with "Fox News Sunday," White House Economic Adviser Jared Bernstein said that the January job report proves the U.S. is not in a recession.

## South Carolina deputies fatally shoot barricaded suspect after he repeatedly stabs police dog
 - [https://www.foxnews.com/us/south-carolina-deputies-fatally-shoot-barricaded-suspect-after-repeatedly-stabs-police-dogk9](https://www.foxnews.com/us/south-carolina-deputies-fatally-shoot-barricaded-suspect-after-repeatedly-stabs-police-dogk9)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:37:53+00:00
 - user: None

A South Carolina suspect who barricaded himself in a home was shot dead by at least one deputy after he repeatedly stabbed a police K9, according to authorities.

## Pete Buttigieg says Biden handled Chinese spy balloon 'appropriately' amid backlash from Republicans
 - [https://www.foxnews.com/politics/pete-buttigieg-says-biden-handled-chinese-spy-balloon-appropriately-backlash-republicans](https://www.foxnews.com/politics/pete-buttigieg-says-biden-handled-chinese-spy-balloon-appropriately-backlash-republicans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:32:46+00:00
 - user: None

Transportation Secretary Pete Buttigieg came to President Biden's defense on Sunday when asked about the Chinese spy balloon, saying it was "handled appropriately."

## Former Levi's exec blasts NY Times over apparent flip on school closures: 'I feel enraged'
 - [https://www.foxnews.com/media/former-levis-exec-blasts-ny-times-apparent-flip-school-closures-feel-enraged](https://www.foxnews.com/media/former-levis-exec-blasts-ny-times-apparent-flip-school-closures-feel-enraged)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:30:24+00:00
 - user: None

Former Levi's executive Jennifer Sey ripped The New York Times for allegedly changing its rhetoric on COVID-19 school closures in wake of new evidence.

## Democrat-run tourist town sees 200% surge in break-ins amid violent crime spike: 'Wildly frustrating'
 - [https://www.foxnews.com/us/democrat-run-tourist-town-sees-200-surge-break-ins-violent-crime-spike-wildly-frustrating](https://www.foxnews.com/us/democrat-run-tourist-town-sees-200-surge-break-ins-violent-crime-spike-wildly-frustrating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:28:47+00:00
 - user: None

Asheville, North Carolina, has seen a 200% monthly increase in break-ins amid a violent crime spike that comes as its police department has been hemorrhaging officers.

## California teen arrested after violent puppy-snatching; pet returned to owner
 - [https://www.foxnews.com/us/california-teen-arrested-violent-puppy-snatching-pet-returned-owner](https://www.foxnews.com/us/california-teen-arrested-violent-puppy-snatching-pet-returned-owner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:20:56+00:00
 - user: None

Police in Bell Gardens, California, have arrested a teen girl suspected of stealing a one-month-old Maltipoo puppy during a violent robbery in broad daylight last week.

## China doubles down on its spy balloon story by firing national weather service chief
 - [https://www.foxnews.com/world/china-backs-its-spy-balloon-story-firing-national-weather-service-chief](https://www.foxnews.com/world/china-backs-its-spy-balloon-story-firing-national-weather-service-chief)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:15:59+00:00
 - user: None

China fired the head of its national weather service on Saturday, backing up its claim that the balloon floating across the U.S. this weekend was a weather craft

## Man arrested after punching teenage girls, brandishing gun during high school basketball game
 - [https://www.foxnews.com/sports/man-arrested-punching-teenage-girls-brandishing-gun-high-school-basketball-game](https://www.foxnews.com/sports/man-arrested-punching-teenage-girls-brandishing-gun-high-school-basketball-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:15:40+00:00
 - user: None

A California man was arrested in connection with an incident at a girls' high school basketball game where he punched several girls on the court and brandished a handgun.

## Rubio says Biden waiting to tell American public about Chinese balloon a ‘dereliction of duty’
 - [https://www.foxnews.com/politics/rubio-says-biden-waiting-tell-american-public-chinese-balloon-dereliction-duty](https://www.foxnews.com/politics/rubio-says-biden-waiting-tell-american-public-chinese-balloon-dereliction-duty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:15:13+00:00
 - user: None

Senator Marco Rubio said Sunday that President Biden's "dereliction of duty" on dealing with the Chinese spy balloon started with his failure to inform the American public.

## Virginia GOP star vows to end Democrat 'roadblock' of Gov. Glenn Youngkin's agenda
 - [https://www.foxnews.com/politics/virginia-gop-star-vows-end-democrat-roadblock-governor-glenn-youngkin-agenda](https://www.foxnews.com/politics/virginia-gop-star-vows-end-democrat-roadblock-governor-glenn-youngkin-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:00:43+00:00
 - user: None

Republican Virginia Delegate and state Senate candidate Emily Brewer has is vowing to end Democrats' roadblock of Gov. Glenn Youngkin's agenda.

## Women share how accepting Jesus helped them to forgive abuser, find courage in public forum: 'God is working'
 - [https://www.foxnews.com/media/women-share-how-accepting-jesus-helped-them-forgive-abuser-find-courage-public-forum-god-working](https://www.foxnews.com/media/women-share-how-accepting-jesus-helped-them-forgive-abuser-find-courage-public-forum-god-working)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 16:00:35+00:00
 - user: None

Three young Christian women joined 'Ainsley's Bible Study' on Fox Nation to share how they came to accept Jesus Christ during their trying college years.

## Trump, top national security officials refute claim that Chinese spy balloons transited US under last admin
 - [https://www.foxnews.com/politics/trump-top-national-security-officials-refute-claim-chinese-spy-balloons-transited-us-under-last-admin](https://www.foxnews.com/politics/trump-top-national-security-officials-refute-claim-chinese-spy-balloons-transited-us-under-last-admin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:54:31+00:00
 - user: None

EXCLUSIVE: Former President Trump and a number of his top national security and defense officials refuted Biden administration officials' claims that Chinese surveillance balloons briefly transited the continental United States during the Trump administration, saying it “never happened.”

## Cotton says spy balloon morphed into trial balloon testing Biden's strength: 'the president failed'
 - [https://www.foxnews.com/politics/cotton-says-spy-balloon-morphed-trial-balloon-testing-bidens-strength-president-failed](https://www.foxnews.com/politics/cotton-says-spy-balloon-morphed-trial-balloon-testing-bidens-strength-president-failed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:50:26+00:00
 - user: None

Senate Intellifence Committee member Sen. Tom Cotton warned that President Biden failed a test of his strength by allowing a Chinese spy balloon to fly across the U.S.

## Connecticut armed robbers shoot store owner who pulls out legal firearms and kills suspect: cops
 - [https://www.foxnews.com/us/connecticut-armed-robbers-shoot-store-owner-pulls-legal-firearms-kills-suspect-cops](https://www.foxnews.com/us/connecticut-armed-robbers-shoot-store-owner-pulls-legal-firearms-kills-suspect-cops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:47:58+00:00
 - user: None

The owner of a Connecticut clothing store used two legally owned firearms to fatally shoot a suspected armed robber who opened fire on the owner and hit him in the back, police say.

## Montana rancher predicts Biden policies could diminish beef supply: 'Government tape'
 - [https://www.foxnews.com/media/montana-rancher-predicts-biden-policies-diminish-beef-supply-government-tape](https://www.foxnews.com/media/montana-rancher-predicts-biden-policies-diminish-beef-supply-government-tape)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:30:39+00:00
 - user: None

Dusty Smith, a rancher in northwest Montana, said the Biden administration is creating red tape, and should focus instead on incentivizing sustainability.

## Joe Biden must address the crises he created at this year’s SOTU
 - [https://www.foxnews.com/opinion/joe-biden-must-address-crises-he-created-this-years-sotu](https://www.foxnews.com/opinion/joe-biden-must-address-crises-he-created-this-years-sotu)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:30:36+00:00
 - user: None

Over the past two years of single-party Democrat rule, every American suffered from surging prices at the grocery store and the gas pump, skyrocketing crime, and a southern border crisis.

## Former NFL Pro Bowler Vontae Davis arrested for DUI in Florida
 - [https://www.foxnews.com/sports/former-nfl-pro-bowler-vontae-davis-arrested-dui-florida-report](https://www.foxnews.com/sports/former-nfl-pro-bowler-vontae-davis-arrested-dui-florida-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:28:04+00:00
 - user: None

Former Pro Bowl cornerback Vontae Davis, who infamously retired at halftime with the Buffalo Bills in 2018, was reportedly arrested for DUI on Saturday in South Florida.

## Arrests made following NYC 90-year-old candy store owner attack
 - [https://www.foxnews.com/us/arrests-made-following-nyc-90-year-old-candy-store-owner-attack](https://www.foxnews.com/us/arrests-made-following-nyc-90-year-old-candy-store-owner-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:22:59+00:00
 - user: None

Two men have reportedly been arrested for attacking a 90-year-old candy shop owner in New York City. Luis Peroza, 39, and Gerald Barth, 55, were arrested for the assault of Ray Alvarez.

## China's spy balloon was a test the US 'played right into,' says former Special Ops Analyst
 - [https://www.foxnews.com/media/chinas-spy-balloon-test-us-played-right-into-former-special-ops-analyst](https://www.foxnews.com/media/chinas-spy-balloon-test-us-played-right-into-former-special-ops-analyst)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:21:09+00:00
 - user: None

Former Special Operations Intel Analyst Brett Velicovich and Gatestone Institute Senior Fellow Gordon Chang react to the shooting down of the Chinese spy balloon.

## Scam Alert: That parking ticket might not be real
 - [https://www.foxnews.com/tech/scam-alert-parking-ticket-might-not-real](https://www.foxnews.com/tech/scam-alert-parking-ticket-might-not-real)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:13:30+00:00
 - user: None

If you have ever parked your car on the street and returned to find a parking ticket on the windshield, you know how frustrating and expensive that can be

## Miranda Lambert says her gift of music is like husband's gift of hot body: 'Take that to the people'
 - [https://www.foxnews.com/entertainment/miranda-lambert-gift-music-like-husbands-gift-hot-body-take-that-people](https://www.foxnews.com/entertainment/miranda-lambert-gift-music-like-husbands-gift-hot-body-take-that-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:05:41+00:00
 - user: None

Miranda Lambert and her husband Brendan McLoughlin talked about their marriage as well as their excitement for their second Grammy Awards together as a couple.

## A PayPal ban 'ruined' Freedom Phone founder's life for a year
 - [https://www.foxnews.com/tech/paypal-ban-ruined-freedom-phone-founders-life-year](https://www.foxnews.com/tech/paypal-ban-ruined-freedom-phone-founders-life-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:00:43+00:00
 - user: None

Freedom Phone Founder Erik Finman shared how PayPal's decision to ban his account four days after his startup launched destroyed the company's future success.

## Women's shot put champion warns against initial World Athletics' proposal for transgender athletes
 - [https://www.foxnews.com/media/womens-shot-put-champion-warns-initial-world-athletics-proposal-transgender-athletes](https://www.foxnews.com/media/womens-shot-put-champion-warns-initial-world-athletics-proposal-transgender-athletes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:00:35+00:00
 - user: None

Shot put champion Amelia Strickler warned Fox News host Tucker Carlson against an initial proposal by the World Athletics for transgender female athletes on "Tucker Carlson Tonight."

## ‘Accused’ showrunner Howard Gordon on why people are obsessed with crime shows: 'They want order'
 - [https://www.foxnews.com/entertainment/accused-showrunner-howard-gordon-why-people-obsessed-crime-shows](https://www.foxnews.com/entertainment/accused-showrunner-howard-gordon-why-people-obsessed-crime-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 15:00:33+00:00
 - user: None

In FOX's "Accused," "each week you have someone who's a new person, new cast, new place," and viewers are "always" following the accused, Howard Gordon notes.

## Missing kayaker found dead in California bay after going crabbing with friends, sheriff says
 - [https://www.foxnews.com/us/missing-kayaker-found-dead-california-bay-going-crabbing-friends-sheriff-says](https://www.foxnews.com/us/missing-kayaker-found-dead-california-bay-going-crabbing-friends-sheriff-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 14:09:50+00:00
 - user: None

Clinton Yoshio Koga, 39, was found dead 100 yards off shore of Lawson's Landing in Tomales Bay nearly a week after he went missing during a fishing trip with friends.

## Chinese spy balloon is a Sputnik moment for America
 - [https://www.foxnews.com/opinion/chinese-spy-balloon-is-sputnik-moment-america](https://www.foxnews.com/opinion/chinese-spy-balloon-is-sputnik-moment-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 14:07:40+00:00
 - user: None

The United States has been under an espionage assault from China for years, but much of it has been behind the scenes. Not anymore, after the spy balloon..

## St. Louis mom lays down law with son, turns him into cops for carjacking pastor
 - [https://www.foxnews.com/us/st-louis-mom-lays-law-son-turns-him-cops-carjacking-pastor](https://www.foxnews.com/us/st-louis-mom-lays-law-son-turns-him-cops-carjacking-pastor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 14:04:04+00:00
 - user: None

A mom turned her 13-year-old son into police after he allegedly carried out a carjacking against a St. Louis pastor. The pastor welcomed the teen to his church.

## Doug Flutie shares how Tom Brady weathered lengthy NFL career as quarterback
 - [https://www.foxnews.com/media/doug-flutie-shares-tom-brady-weathered-lengthy-nfl-career-quarterback](https://www.foxnews.com/media/doug-flutie-shares-tom-brady-weathered-lengthy-nfl-career-quarterback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 14:00:03+00:00
 - user: None

Former NFL quarterback Doug Flutie speaks on Tom Brady's football career on "Unfiltered with Dan Bongino" after he announced his retirement for a second time.

## JCPenney spotlights senior pit bull mix named Popcorn, available for adoption in Atlanta
 - [https://www.foxnews.com/lifestyle/jcpenney-spotlights-senior-pit-bull-mix-popcorn-available-adoption-atlanta](https://www.foxnews.com/lifestyle/jcpenney-spotlights-senior-pit-bull-mix-popcorn-available-adoption-atlanta)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:50:14+00:00
 - user: None

A 12-year-old terrier-pit bull mix named Popcorn is a featured dog in JCPenney's "Portrait for Pups" campaign. She's currently up for adoption at PAWS Atlanta.

## The end of free rides: How Netflix is tackling account sharing
 - [https://www.foxnews.com/tech/end-free-rides-netflix-tackling-account-sharing](https://www.foxnews.com/tech/end-free-rides-netflix-tackling-account-sharing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:44:43+00:00
 - user: None

Netflix is cracking down on password sharing, Kurt "CyberGuy" Knutsson explains what the streaming service's plans are to stop sharing streaming accounts.

## Best Desktop Computers of 2023
 - [https://www.foxnews.com/tech/best-desktop-computers-2023](https://www.foxnews.com/tech/best-desktop-computers-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:42:35+00:00
 - user: None

Kurt "Cyberguy" Knutsson outlines his top picks for the best computers on the market that will meet your individual work and personal needs, making your search for a new computer easier.

## Rep. Mike Rogers offers succinct GOP assessment of Chinese spy flight
 - [https://www.foxnews.com/politics/rep-mike-rogers-offers-succinct-gop-assessment-chinese-spy-flight](https://www.foxnews.com/politics/rep-mike-rogers-offers-succinct-gop-assessment-chinese-spy-flight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:37:36+00:00
 - user: None

House Armed Services Committee chairman Mike Rogers blasted President Biden for his handling of the Chinese spy balloon incident Sunday, demanding answers from the White House.

## Coffee shop named 'Woke' defended after receiving backlash, boycott calls: 'It's disgusting'
 - [https://www.foxnews.com/media/coffee-shop-named-woke-defended-receiving-backlash-boycott-calls-its-disgusting](https://www.foxnews.com/media/coffee-shop-named-woke-defended-receiving-backlash-boycott-calls-its-disgusting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:30:57+00:00
 - user: None

A diner in Coventry, Conn., called Woke Breakfast & Coffee received online hate and boycott calls from critics who thought it espoused a political message.

## Kate Middleton discusses raising children in todays world amid British royal family drama: 'It is tough'
 - [https://www.foxnews.com/entertainment/kate-middleton-discusses-raising-children-todays-world-british-royal-family-drama-tough](https://www.foxnews.com/entertainment/kate-middleton-discusses-raising-children-todays-world-british-royal-family-drama-tough)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:30:37+00:00
 - user: None

In an effort to promote her #ShapingUs campaign, Kate Middleton opened up on the importance of early childhood development, while noting that raising children is "tough."

## UK's shortest-serving PM Liz Truss blames economic 'orthodoxy' for downfall
 - [https://www.foxnews.com/world/uks-shortest-serving-pm-liz-truss-blames-economic-orthodoxy-downfall](https://www.foxnews.com/world/uks-shortest-serving-pm-liz-truss-blames-economic-orthodoxy-downfall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:20:37+00:00
 - user: None

Former British Prime Minister Liz Truss blamed England's economic "orthodoxy" for her unsuccessful economic policies during her short tenure in Parliament.

## DC kidnapping suspect dies hours after arrest in jail cell, police say
 - [https://www.foxnews.com/us/dc-kidnapping-suspect-dies-hours-arrest-jail-cell-police-say](https://www.foxnews.com/us/dc-kidnapping-suspect-dies-hours-arrest-jail-cell-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:03:41+00:00
 - user: None

A man accused of abducting his girlfriend at gunpoint last summer has died hours after being arrested in Washington, D.C. Metropolitan Police Department's standard operating procedures says those in custody are searched.

## Meet the congressional comeback kids: GOP lawmakers who left the House and returned to positions of power
 - [https://www.foxnews.com/politics/meet-the-congressional-comeback-kids-gop-house-members-who-secured-top-committees-after-leaving-congress](https://www.foxnews.com/politics/meet-the-congressional-comeback-kids-gop-house-members-who-secured-top-committees-after-leaving-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:00:53+00:00
 - user: None

Darrell Issa, R-Calif.; Pete Sessions, R-Texas; and Claudia Tenney, R-N.Y., begin the 118th Congress on powerful committees and with advice for freshman members.

## Parents of 6 slain children speak out: 'Absence of God,' peer pressure, lack of strictness to blame
 - [https://www.foxnews.com/media/parents-6-slain-children-speak-absence-god-peer-pressure-lack-strictness-blame](https://www.foxnews.com/media/parents-6-slain-children-speak-absence-god-peer-pressure-lack-strictness-blame)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:00:53+00:00
 - user: None

Lawrence Jones joins a group of parents who lost their children to homicide to discuss the root causes of violence among America's youth on "Cross Country."

## Brain teaser: Can you find 3 cats hidden in a sea of penguins?
 - [https://www.foxnews.com/lifestyle/brain-teaser-can-find-3-cats-hidden-sea-penguins](https://www.foxnews.com/lifestyle/brain-teaser-can-find-3-cats-hidden-sea-penguins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:00:46+00:00
 - user: None

Test your vision and attention to detail with this cat and penguin seek-and-find brain teaser created by Gergely Dudás, a graphic artist from Budapest, Hungary.

## Grammys 2023: Beyoncé sets a record, Shania Twain presenting and Luke Combs to perform
 - [https://www.foxnews.com/entertainment/grammys-2023-beyonce-sets-record-shania-twain-presenting-luke-combs-perform](https://www.foxnews.com/entertainment/grammys-2023-beyonce-sets-record-shania-twain-presenting-luke-combs-perform)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:00:41+00:00
 - user: None

Beyoncé is leading the nominations, Shania Twain is set to present and Luke Combs is performing. Here's what to know about the 2023 Grammys hosted by Trevor Noah in Los Angeles, airing Sunday night on CBS.

## Brain-dead women should be kept alive and used as surrogates, proferssor suggests
 - [https://www.foxnews.com/media/brain-dead-women-should-kept-alive-used-surrogates-proferssor-suggests](https://www.foxnews.com/media/brain-dead-women-should-kept-alive-used-surrogates-proferssor-suggests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:00:23+00:00
 - user: None

Philosopher argues that using braindead people as 'whole body gestational' surrogates should be an option for anyone who wishes to avoid the risks and burdens of pregnancy.

## I talked to two ex-homeless people about Newsom's 'investment' in homelessness. Their answers will shock you
 - [https://www.foxnews.com/opinion/talked-two-ex-homeless-people-about-newsoms-investment-homelessness-answers-shock](https://www.foxnews.com/opinion/talked-two-ex-homeless-people-about-newsoms-investment-homelessness-answers-shock)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:00:23+00:00
 - user: None

I talked to two ex-homeless people about Newsom's 'investment' in homelessness. Their answers will shock you about California, but they do offer some hope.

## What can I use Nutella with? Some recipes for the chocolatey treat
 - [https://www.foxnews.com/food-drink/use-nutella-recipes-chocolate-treat](https://www.foxnews.com/food-drink/use-nutella-recipes-chocolate-treat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 13:00:07+00:00
 - user: None

The uses of Nutella are endless — as a dip, as a spread and even on pizza. The hazelnut snack quickly gained popularity, and Feb. 5 is now World Nutella Day.

## Police arrest two 18-year-olds who reportedly threatened workers with fully automatic handgun over membership
 - [https://www.foxnews.com/us/police-arrest-two-18-year-olds-reportedly-threatened-workers-fully-automatic-handgun-membership](https://www.foxnews.com/us/police-arrest-two-18-year-olds-reportedly-threatened-workers-fully-automatic-handgun-membership)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:59:59+00:00
 - user: None

Seattle police seized a modified handgun from two suspects who allegedly threatened to kill a worker at a business over being asked to leave for not having memberships.

## 'Toxic masculinity' fear, media portrayal as 'fools' contributing to men leaving workforce: Mikhaila Peterson
 - [https://www.foxnews.com/media/portrayal-masculinity-strained-relationships-women-forcing-men-out-workforce-mikhaila-peterson](https://www.foxnews.com/media/portrayal-masculinity-strained-relationships-women-forcing-men-out-workforce-mikhaila-peterson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:30:52+00:00
 - user: None

Podcast host Mikhaila Peterson joined "Fox & Friends Weekend" to discuss the decline in men participating in the workforce, and the factors contributing to the decline.

## Military experts provide frank assessment of US shortcomings in potential China conflict
 - [https://www.foxnews.com/world/military-experts-provide-frank-assessment-us-shortcomings-potential-china-conflict](https://www.foxnews.com/world/military-experts-provide-frank-assessment-us-shortcomings-potential-china-conflict)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:30:51+00:00
 - user: None

The main issues the U.S. military would face are the "tyranny of distance," which hands China a major "home-field advantage" and a potential shortage of munitions.

## Push for a 4-day work week picks up steam — and critics
 - [https://www.foxnews.com/politics/push-4-day-work-week-picks-steam-critics](https://www.foxnews.com/politics/push-4-day-work-week-picks-steam-critics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:30:48+00:00
 - user: None

A growing number of voices are pushing for the U.S. to embrace a four-day work week, leading critics to question the wisdom of what would be a cultural sea change.

## US firms pumping billions into China's AI sector
 - [https://www.foxnews.com/politics/us-firms-pumping-billions-chinas-ai-sector](https://www.foxnews.com/politics/us-firms-pumping-billions-chinas-ai-sector)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:30:36+00:00
 - user: None

U.S. investors were involved in investment transactions in China's artificial intelligence sector totaling $40.2 billion sector between 2015 and 2021, according to a new report.

## Bible verse of the week: The message of Jesus on love is 'confrontational,' faith leader says
 - [https://www.foxnews.com/lifestyle/bible-verse-week-message-jesus-love-confrontational-faith-leader-says](https://www.foxnews.com/lifestyle/bible-verse-week-message-jesus-love-confrontational-faith-leader-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:00:33+00:00
 - user: None

The command to "love your enemies" is "convicting and confrontational" — and should be an example that all Christians follow, a Texas pastor told Fox News Digital.

## Biden should project ‘positive message’ on policing in State of the Union speech: law enforcement leader
 - [https://www.foxnews.com/politics/biden-project-positive-message-policing-state-union-speech-law-enforcement-group-leader](https://www.foxnews.com/politics/biden-project-positive-message-policing-state-union-speech-law-enforcement-group-leader)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:00:28+00:00
 - user: None

Law enforcement groups are encouraging President Biden to strike a "positive" tone on policing during his upcoming State of the Union address following recent events.

## Critics see Chinese spy balloon as Biden's latest policy blunder
 - [https://www.foxnews.com/politics/critics-see-chinese-spy-balloon-bidens-latest-policy-blunder-see-problem-shrug](https://www.foxnews.com/politics/critics-see-chinese-spy-balloon-bidens-latest-policy-blunder-see-problem-shrug)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:00:17+00:00
 - user: None

The Chinese spy balloon saga is being presented by critics of the administration as the latest blow to the U.S. foreign policy under the leadership of President Biden.

## Trillion-dollar coin, 14th Amendment: Dems, academics float radical options for Biden in debt ceiling standoff
 - [https://www.foxnews.com/politics/trillion-dollar-coin-14th-amendment-dems-academics-float-radical-options-biden-debt-ceiling-standoff](https://www.foxnews.com/politics/trillion-dollar-coin-14th-amendment-dems-academics-float-radical-options-biden-debt-ceiling-standoff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:00:01+00:00
 - user: None

Democrats in Congress and liberal academics are pushing ideas to address the debt ceiling without needing to hear Republicans' concerns.

## The establishment is leading the 'top-down, woke revolution': Victor Davis Hanson
 - [https://www.foxnews.com/media/establishment-leading-top-down-woke-revolution-victor-davis-hanson](https://www.foxnews.com/media/establishment-leading-top-down-woke-revolution-victor-davis-hanson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 12:00:00+00:00
 - user: None

Historian and Hoover Institution senior fellow Victor Davis Hanson sounded off about how the establishment leads the woke revolution on "Life, Liberty & Levin."

## Woman who killed Netflix's 'Dirty John' held his head 'like a zombie,' stabbed him through the eye
 - [https://www.foxnews.com/us/woman-killed-netflix-dirty-john-held-his-head-like-zombie-stabbed-him-through-eye](https://www.foxnews.com/us/woman-killed-netflix-dirty-john-held-his-head-like-zombie-stabbed-him-through-eye)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 11:30:43+00:00
 - user: None

Terra Newell was 25 Aug. 20, 2016, when her stepfather John Meehan attacked her from behind with a knife and she fought him off and ultimately killed him.

## Fun facts about Nutella in honor of World Nutella Day
 - [https://www.foxnews.com/food-drink/fun-facts-world-nutella-day](https://www.foxnews.com/food-drink/fun-facts-world-nutella-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 11:00:41+00:00
 - user: None

World Nutella Day is Feb. 5 every year. The chocolatey treat used for dipping, spreading and baking was created after World War II but has evolved since then.

## South Carolina Dem James Clyburn funneled six figures from campaign funds to family last cycle, filings show
 - [https://www.foxnews.com/politics/south-carolina-dem-james-clyburn-funneled-six-figures-campaign-funds-family-last-cycle-filings-show](https://www.foxnews.com/politics/south-carolina-dem-james-clyburn-funneled-six-figures-campaign-funds-family-last-cycle-filings-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 11:00:01+00:00
 - user: None

South Carolina Democrat James Clyburn paid out tens of thousands of dollars from his campaign funds to a company registered to his son-in-law and even more to his grandson.

## Boston 'Impractical Jokers' shows postponed after freezing temps burst venue's sprinkler system
 - [https://www.foxnews.com/us/boston-impactical-jokers-shows-postponed-freezing-temps-burst-venues-sprinkler-system](https://www.foxnews.com/us/boston-impactical-jokers-shows-postponed-freezing-temps-burst-venues-sprinkler-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 10:58:43+00:00
 - user: None

The "Impractical Jokers" show at the Boch Center Wang Theatre in Boston, Massachusetts was postponed after bitterly cold temperatures busted the historic venue's sprinkler system.

## Texas Gov. Greg Abbott issues emergency declaration amid winter weather
 - [https://www.foxnews.com/weather/texas-gov-greg-abbott-issues-emergency-declaration-amid-winter-weather](https://www.foxnews.com/weather/texas-gov-greg-abbott-issues-emergency-declaration-amid-winter-weather)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 10:11:07+00:00
 - user: None

Texas Republican Gov. Greg Abbott issued an emergency declaration in several counties on Saturday to address the ice storm that has impacted the state.

## Former Arizona state trooper sentenced after sexually assaulting women during traffic stops
 - [https://www.foxnews.com/us/former-arizona-state-trooper-sentenced-after-sexually-assaulting-women-during-traffic-stops](https://www.foxnews.com/us/former-arizona-state-trooper-sentenced-after-sexually-assaulting-women-during-traffic-stops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 10:04:12+00:00
 - user: None

Ex-Arizona State Trooper Tremaine Jackson was sentenced to five years in prison and lifetime probation after pleading guilty to multiple sex-related crimes during traffic stops.

## Matt Gaetz calls for Biden to 'blow up TikTok' after US military shoots down suspected Chinese spy balloon
 - [https://www.foxnews.com/politics/matt-gaetz-calls-biden-blow-up-tiktok-us-military-shoots-down-suspected-chinese-spy-balloon](https://www.foxnews.com/politics/matt-gaetz-calls-biden-blow-up-tiktok-us-military-shoots-down-suspected-chinese-spy-balloon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 09:06:20+00:00
 - user: None

Republican Matt Gaetz is calling on President Joe Biden to take action on TikTok after he authorized the U.S. military to shoot down a suspected Chinese spy balloon.

## Maryland middle schooler brings loaded gun into classroom
 - [https://www.foxnews.com/us/maryland-middle-schooler-brings-loaded-gun-classroom](https://www.foxnews.com/us/maryland-middle-schooler-brings-loaded-gun-classroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 08:48:10+00:00
 - user: None

A 13-year-old Maryland middle schooler brought a loaded gun into their classroom, according to police. No injuries were reported in the incident.

## Rep. George Santos' New York office window vandalized: 'Beyond unacceptable'
 - [https://www.foxnews.com/politics/rep-george-santos-new-york-office-window-vandalized-beyond-unacceptable](https://www.foxnews.com/politics/rep-george-santos-new-york-office-window-vandalized-beyond-unacceptable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 08:17:22+00:00
 - user: None

New York GOP Rep. George Santos' district office in Queens was vandalized, but police have not reported any arrests. The graffiti had been washed off by Friday afternoon.

## Co-owner of popular Atlanta nightclub Republic Lounge shot to death outside the establishment
 - [https://www.foxnews.com/us/co-owner-popular-atlanta-nightclub-republic-lounge-shot-death-outside-establishment](https://www.foxnews.com/us/co-owner-popular-atlanta-nightclub-republic-lounge-shot-death-outside-establishment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 07:50:04+00:00
 - user: None

Michael Gidewon, co-owner of popular Atlanta nightclub Republic Lounge, was shot and killed outside his establishment. Atlanta police have not yet announced a suspect or motive.

## Virginia police seeking public's help after unidentified body found at Williamsburg pond
 - [https://www.foxnews.com/us/virginia-police-seeking-publics-help-unidentified-body-found-williamsburg-pond](https://www.foxnews.com/us/virginia-police-seeking-publics-help-unidentified-body-found-williamsburg-pond)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 07:02:19+00:00
 - user: None

Authorities are requesting help in identifying a body that was found in a Williamsburg retention pond on Jan. 25. The individual's cause of death was not released.

## George Santos' former staffer accuses congressman of sexual harassment, violating pay rules
 - [https://www.foxnews.com/politics/george-santos-former-staffer-accuses-congressman-sexual-harassment-violating-pay-rules](https://www.foxnews.com/politics/george-santos-former-staffer-accuses-congressman-sexual-harassment-violating-pay-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 06:52:56+00:00
 - user: None

George Santos' former staffer said in an ethics complaint that the congressman sexually harassed him and violated House ethics' pay rules regarding his employment.

## 'Close Encounters of the Third Kind' and 'A Christmas Story' star Melinda Dillon dies at 83
 - [https://www.foxnews.com/entertainment/close-encounters-third-kind-christmas-story-star-melinda-dillon-dies-83](https://www.foxnews.com/entertainment/close-encounters-third-kind-christmas-story-star-melinda-dillon-dies-83)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 05:33:56+00:00
 - user: None

"A Christmas Story" star Melinda Dillon died at the age of 83 on Jan. 9. She was a two-time Academy Award nominee for her roles in "Close Encounters of the Third Kind" and "Absence of Malice."

## NYPD off-duty officer 'fighting for his life' after used vehicle purchase turns into armed robbery: officials
 - [https://www.foxnews.com/us/nypd-off-duty-officer-fighting-life-used-vehicle-purchase-turns-armed-robbery-officials](https://www.foxnews.com/us/nypd-off-duty-officer-fighting-life-used-vehicle-purchase-turns-armed-robbery-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 05:13:17+00:00
 - user: None

An off-duty NYPD officer remains in critical condition after a shooting incident took place late Saturday night, said Mayor Eric Adams and NYPD Police Commissioner Keechant L. Sewell.

## On this day in history, Feb. 5, 1937, FDR announces plan to pack the Supreme Court
 - [https://www.foxnews.com/lifestyle/day-history-feb-5-1937-fdr-announces-plan-pack-supreme-court](https://www.foxnews.com/lifestyle/day-history-feb-5-1937-fdr-announces-plan-pack-supreme-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 05:02:12+00:00
 - user: None

On this day in history, Feb. 5, 1937, FDR planned to pack the Supreme Court to create support for his New Deal agenda, which sought to give government broader authority to help Americans recover post-Depression.

## Kate Middleton shares photo of herself as a baby as part of early childhood campaign
 - [https://www.foxnews.com/entertainment/kate-middleton-shares-photo-herself-baby-part-early-childhood-campaign](https://www.foxnews.com/entertainment/kate-middleton-shares-photo-herself-baby-part-early-childhood-campaign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 03:37:51+00:00
 - user: None

Kate Middleton shared a baby photo of herself as part of a new campaign to raise awareness about the importance of early childhood years.

## Smokey Robinson shares the secret to his decades of success as he's honored with Berry Gordy at MusiCares Gala
 - [https://www.foxnews.com/entertainment/sheryl-crow-talks-performing-song-she-sang-at-the-white-house-at-musicares-persons-of-the-year-gala](https://www.foxnews.com/entertainment/sheryl-crow-talks-performing-song-she-sang-at-the-white-house-at-musicares-persons-of-the-year-gala)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 03:28:18+00:00
 - user: None

Motown icons Smokey Robinson and Berry Gordy were honored at the MusiCares Persons of the Year Gala on Friday night, ahead of the 65th Annual Grammy Awards.

## Richard Sherman, NFL players rip potential rule change that would ban ‘hip-drop' tackle
 - [https://www.foxnews.com/sports/richard-sherman-nfl-players-react-to-possible-implementation-of-hip-drop-tackle-rule](https://www.foxnews.com/sports/richard-sherman-nfl-players-react-to-possible-implementation-of-hip-drop-tackle-rule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 03:02:08+00:00
 - user: None

Past and present NFL players have not taken kindly to the notion the league may be considering a rule which would make "hip-drop" style tackles illegal.

## Japan fires aide for anti-LGBTQ comments: 'Outrageous'
 - [https://www.foxnews.com/world/japan-fires-aide-anti-lgbtq-comments-outrageous](https://www.foxnews.com/world/japan-fires-aide-anti-lgbtq-comments-outrageous)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 02:54:41+00:00
 - user: None

Japan's prime minister fired a top aide on Saturday after the aide reportedly said he wouldn't want to live next to gay or lesbian couples or even look at them.

## Missing mom's husband considered 'person of interest' faces extradition to Indiana on unrelated charges
 - [https://www.foxnews.com/us/missing-moms-husband-considered-person-interest-faces-extradition-indiana-unrelated-charges](https://www.foxnews.com/us/missing-moms-husband-considered-person-interest-faces-extradition-indiana-unrelated-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 02:50:14+00:00
 - user: None

Xavier Breland - a person of interest in his wife Ciera Breland's disappearance - is being extradited back to Indiana from Georgia on unrelated charges.

## New York school, food vendor apologize for serving chicken and waffles on first day of Black History Month
 - [https://www.foxnews.com/us/new-york-school-food-vendor-apologize-serving-chicken-waffles-first-day-black-history-month](https://www.foxnews.com/us/new-york-school-food-vendor-apologize-serving-chicken-waffles-first-day-black-history-month)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 02:37:58+00:00
 - user: None

A New York middle school and its food vendor have both apologized for serving chicken and waffles on the first day of Black History Month which upset some parents.

## James Harrison responds to Antonio Brown's claims Harrison caused receiver's 'CTE,' 'aggressive behavior'
 - [https://www.foxnews.com/sports/james-harrison-responds-antonio-browns-claims-caused-receivers-cte-aggressive-behavior](https://www.foxnews.com/sports/james-harrison-responds-antonio-browns-claims-caused-receivers-cte-aggressive-behavior)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 02:16:47+00:00
 - user: None

Shortly after free agent receiver Antonio Brown blamed former Pittsburgh Steeler James Harrison for giving him CTE, the Super Bowl XLIII hero had quite the response.

## China fumes after US pops its balloon, warns of possible ‘responses’ to ‘clear overreaction’
 - [https://www.foxnews.com/politics/china-fumes-us-pops-balloon-clear-overreaction-warns-possible-responses](https://www.foxnews.com/politics/china-fumes-us-pops-balloon-clear-overreaction-warns-possible-responses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 02:13:56+00:00
 - user: None

The Chinese government said it disapproves of the U.S. decision to shoot down an unmanned surveillance balloon and warned it may have "responses" to that action.

## California 5-year-old remains upbeat despite mountain lion attack: 'His spirit remains intact'
 - [https://www.foxnews.com/us/california-5-year-old-remains-upbeat-despite-mountain-lion-attack-his-spirit-remains-intact](https://www.foxnews.com/us/california-5-year-old-remains-upbeat-despite-mountain-lion-attack-his-spirit-remains-intact)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 02:01:38+00:00
 - user: None

A California five-year-old is said to be in good spirits despite being attacked by a mountain lion resulting in lacerations, a facial fracture, and a hospital visit.

## Aaron Rodgers has message for former teammate Davante Adams as the receiver tries to recruit him to Raiders
 - [https://www.foxnews.com/sports/aaron-rodgers-has-message-former-teammate-davante-adams-trying-recruit-him-raiders](https://www.foxnews.com/sports/aaron-rodgers-has-message-former-teammate-davante-adams-trying-recruit-him-raiders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 01:53:14+00:00
 - user: None

If Packers quarterback Aaron Rodgers is going to reunite with star receiver Davante Adams, he's going to need some help from the current Las Vegas Raider.

## Florida state trooper hospitalized following pursuit, shootout; 1 suspect dead
 - [https://www.foxnews.com/us/florida-state-trooper-hospitalized-following-pursuit-shootout-suspect-dead](https://www.foxnews.com/us/florida-state-trooper-hospitalized-following-pursuit-shootout-suspect-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 01:40:04+00:00
 - user: None

A state trooper in Florida was shot by a suspect after a police pursuit on Interstate 75 near Tampa early Saturday morning. A second suspect was taken into custody.

## Republican demands Joe Biden, Kamala Harris resign after 'catastrophic Chinese spy balloon spectacle'
 - [https://www.foxnews.com/politics/republican-demands-joe-biden-kamala-harris-resign-catastrophic-chinese-spy-balloon-spectacle](https://www.foxnews.com/politics/republican-demands-joe-biden-kamala-harris-resign-catastrophic-chinese-spy-balloon-spectacle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 01:31:22+00:00
 - user: None

Rep. Joe Wilson, R-S.C., demanded Saturday that both president Biden and Vice President Kamala Harris should resign after allowing a Chinese spy balloon to fly over America.

## Geno Smith gives update on contract talks with Seahawks: 'It's looking very good'
 - [https://www.foxnews.com/sports/geno-smith-gives-update-on-contract-talks-with-seahawks-its-looking-very-good](https://www.foxnews.com/sports/geno-smith-gives-update-on-contract-talks-with-seahawks-its-looking-very-good)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 01:25:38+00:00
 - user: None

Geno Smith appears optimistic about his prospects to return to Seattle. The pending free agent quarterback had a resurgent year in his first season as a starter since 2014.

## China experts predict Beijing’s next move after spy balloon shot down
 - [https://www.foxnews.com/politics/china-experts-predict-beijings-next-move-after-spy-balloon-shot-down](https://www.foxnews.com/politics/china-experts-predict-beijings-next-move-after-spy-balloon-shot-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 01:14:29+00:00
 - user: None

Several China experts predicted what Beijing's next move would be after their spy balloon that flew across America over several days was blown up by the U.S. military on Saturday.

## Biden's decision to 'allow' Chinese spy balloon over US is 'a joke,' Homeland Security committee member says
 - [https://www.foxnews.com/politics/bidens-decision-allow-chinese-spy-balloon-us-joke-homeland-security-committee-member-says](https://www.foxnews.com/politics/bidens-decision-allow-chinese-spy-balloon-us-joke-homeland-security-committee-member-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 01:06:28+00:00
 - user: None

A member of the House Committee on Homeland Security said that President Biden allowing the Chinese spy balloon to travel over the United States is a "joke."

## Pentagon working to recover Chinese spy balloon, expects valuable intel from it
 - [https://www.foxnews.com/politics/pentagon-working-recover-chinese-spy-balloon-expects-valuable-intel-officials-say](https://www.foxnews.com/politics/pentagon-working-recover-chinese-spy-balloon-expects-valuable-intel-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 00:53:10+00:00
 - user: None

Defense officials said Saturday that the mission to recover a shot-down Chinese spy balloon was underway and was being conducted by U.S. Navy and Coast Guard personnel.

## Kentucky mom says Bryan Kohberger is her 'divine masculine' and claims she sent him letters and dolled up pics
 - [https://www.foxnews.com/us/kentucky-mom-says-bryan-kohberger-divine-masculine-claims-sent-letters-dolled-pics](https://www.foxnews.com/us/kentucky-mom-says-bryan-kohberger-divine-masculine-claims-sent-letters-dolled-pics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 00:51:29+00:00
 - user: None

A Kentucky woman, who goes by the name Brittney J. Hislope on Facebook, wrote about her "love" for Bryan Kohberger, who's accused of killing four University of Idaho students.

## China's reaction to balloon takedown will offer 'very important clues' to how it operates: Gordon Chang
 - [https://www.foxnews.com/media/chinas-reaction-balloon-takedown-offer-very-important-clues-operates-gordon-chang](https://www.foxnews.com/media/chinas-reaction-balloon-takedown-offer-very-important-clues-operates-gordon-chang)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 00:45:12+00:00
 - user: None

China expert Gordon Chang weighs in on the Chinese spy balloon shot down by U.S. fighter jets off the coast of South Carolina as U.S.-China tensions grow on "Fox News Live."

## Nets' Kyrie Irving booed by home crowd after reportedly requesting trade
 - [https://www.foxnews.com/sports/nets-kyrie-irving-booed-home-crowd-reportedly-requesting-trade](https://www.foxnews.com/sports/nets-kyrie-irving-booed-home-crowd-reportedly-requesting-trade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 00:37:34+00:00
 - user: None

Just one day after reports emerged that Kyrie Irving requested a trade from the Brooklyn Nets, the Barclays Center crowd let him know how it felt about his demands.

## Antonio Brown claims former teammate James Harrison caused his 'CTE' and 'super aggressive' behavior
 - [https://www.foxnews.com/sports/antonio-brown-claims-james-harrison-for-his-cte-and-super-aggressive-behavior](https://www.foxnews.com/sports/antonio-brown-claims-james-harrison-for-his-cte-and-super-aggressive-behavior)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-02-05 00:26:21+00:00
 - user: None

NFL free agent receiver Antonio Brown blamed his "super aggressive'" behavior on a hit he said he took from one of his former Pittsburgh Steelers teammates.
