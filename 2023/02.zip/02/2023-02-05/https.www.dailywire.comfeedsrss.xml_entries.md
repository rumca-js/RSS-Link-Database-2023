# Source Daily Wire, Source URL:https://www.dailywire.com/feeds/rss.xml, Source language: en-US

## Tom Cotton: Biden Was ‘Paralyzed For Entire Week By A Balloon’ Because He’s Afraid Of ‘Chinese Communists’
 - [https://www.dailywire.com/news/tom-cotton-biden-was-paralyzed-for-entire-week-by-a-balloon-because-hes-afraid-of-chinese-communists](https://www.dailywire.com/news/tom-cotton-biden-was-paralyzed-for-entire-week-by-a-balloon-because-hes-afraid-of-chinese-communists)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 17:35:28+00:00
 - user: None

Sen. Tom Cotton (R-AR) slammed President Joe Biden Sunday for his botched handling of the Chinese spy balloon that crossed over multiple U.S. states last week. Cotton made the remarks on &#8220;Fox News Sunday&#8221; with host Shannon Bream when asked to weigh in on the matter. &#8220;What began as a spy balloon has become a ...

## Reese Witherspoon Admits She Bombed An Audition With De Niro — And 10 Years Later, He Still Remembered
 - [https://www.dailywire.com/news/reese-witherspoon-admits-she-bombed-an-audition-with-de-niro-and-10-years-later-he-still-remembered](https://www.dailywire.com/news/reese-witherspoon-admits-she-bombed-an-audition-with-de-niro-and-10-years-later-he-still-remembered)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 17:30:15+00:00
 - user: None

Actress Reese Witherspoon revealed during a recent interview that she had once &#8220;bricked&#8221; an audition with Academy Award winner Robert De Niro — and to make matters worse, when he saw her again a decade later, he remembered it. Witherspoon joined the Thursday evening broadcast of &#8220;Jimmy Kimmel Live!&#8221; and she explained to the host ...

## ‘I Get So Much Flack For Saying This’: Ana Kasparian Talks Failed Leftist Policies With Ben Shapiro
 - [https://www.dailywire.com/news/i-get-so-much-flack-for-saying-this-ana-kasparian-talks-failed-leftist-policies-with-ben-shapiro](https://www.dailywire.com/news/i-get-so-much-flack-for-saying-this-ana-kasparian-talks-failed-leftist-policies-with-ben-shapiro)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 16:34:53+00:00
 - user: None

Liberal political commentator and host Ana Kasparian said policies from the Left that have not worked, especially policy related to homelessness and crime in Los Angeles, need to be discussed so an &#8220;actual solution&#8221; can be found. Kasparian, an open and unapologetic member of the Left, caught flack from some extremists on the Left for ...

## Man Who Left Dead Fish At ‘Goonies’ House Rescued After Stolen Yacht Capsized, Arrested, Police Say
 - [https://www.dailywire.com/news/man-who-left-dead-fish-at-goonies-house-rescued-after-stolen-yacht-capsized-arrested-police-say](https://www.dailywire.com/news/man-who-left-dead-fish-at-goonies-house-rescued-after-stolen-yacht-capsized-arrested-police-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 16:21:01+00:00
 - user: None

The man who allegedly left a dead fish at “The Goonies” house then had to be rescued by the U.S. Coast Guard after a yacht he stole capsized has been arrested, according to authorities.  Law enforcement had reportedly been searching for the suspect since Wednesday when they were alerted to a video apparently posted to ...

## University Apologizes For ‘Russia’ Chant At Ukrainian Basketball Player
 - [https://www.dailywire.com/news/university-apologizes-for-russia-chant-at-ukrainian-basketball-player](https://www.dailywire.com/news/university-apologizes-for-russia-chant-at-ukrainian-basketball-player)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 15:23:19+00:00
 - user: None

Colorado State University apologized to a Utah State basketball player from Ukraine after some fans chanted &#8220;Russia&#8221; at him during a game Saturday. The player, Max Shulga, is a guard for Utah State and a native of Kyiv. Russia invaded his home country roughly one year ago in a conflict that continues to this day. ...

## Marco Rubio: China Delivered A ‘Message Embedded In’ Sending Spy Balloon To U.S.
 - [https://www.dailywire.com/news/marco-rubio-china-delivered-a-message-embedded-in-sending-spy-balloon-to-u-s](https://www.dailywire.com/news/marco-rubio-china-delivered-a-message-embedded-in-sending-spy-balloon-to-u-s)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 14:04:04+00:00
 - user: None

Sen. Marco Rubio (R-FL) criticized President Joe Biden during an interview on Sunday over his controversial handling of the Chinese spy balloon that flew over the U.S. during the last several days. Rubio told CNN&#8217;s Jake Tapper on &#8220;State of the Union&#8221; that the American people need answers about why it took the administration so ...

## Ted Cruz Explains The ‘Bad Message’ Biden Conveyed To Communist China Over Spy Balloon
 - [https://www.dailywire.com/news/ted-cruz-explains-the-bad-message-biden-conveyed-to-communist-china-over-spy-balloon](https://www.dailywire.com/news/ted-cruz-explains-the-bad-message-biden-conveyed-to-communist-china-over-spy-balloon)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 13:09:57+00:00
 - user: None

Sen. Ted Cruz (R-TX) slammed President Joe Biden after the president allowed a Chinese spy balloon to fly over the U.S. for several days before shooting it down over the Atlantic Ocean. Cruz made the remarks during a Sunday interview on CBS News&#8217;s &#8220;Face The Nation,&#8221; where he gave Biden credit for eventually downing the ...

## Ratcliffe Shoots Down Claim That Three Chinese Balloons Crossed Over U.S. Under Trump
 - [https://www.dailywire.com/news/ratcliffe-shoots-down-claim-that-three-chinese-balloons-crossed-over-u-s-under-trump](https://www.dailywire.com/news/ratcliffe-shoots-down-claim-that-three-chinese-balloons-crossed-over-u-s-under-trump)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 13:02:49+00:00
 - user: None

Former Director of National Intelligence John Ratcliffe rejected the claim that three Chinese spy balloons &#8220;transited&#8221; the United States during Donald Trump&#8217;s presidency. The suspected Chinese balloon that traversed across the lower 48 states before being shot down off the coast of the Carolinas on Saturday represented an &#8220;unprecedented national security blunder of incalculable damage,&#8221; ...

## Jake Tapper Grills Pete Buttigieg Over Biden’s Handling Of Chinese Spy Balloon
 - [https://www.dailywire.com/news/jake-tapper-grills-pete-buttigieg-over-bidens-handling-of-chinese-spy-balloon](https://www.dailywire.com/news/jake-tapper-grills-pete-buttigieg-over-bidens-handling-of-chinese-spy-balloon)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 12:22:48+00:00
 - user: None

CNN&#8217;s Jake Tapper grilled Biden Transportation Secretary Pete Buttigieg on Sunday about the administration&#8217;s controversial handling of the Chinese spy balloon that traversed across the U.S. over the last several days. Buttigieg made the remarks during an interview broadcast on CNN&#8217;s &#8220;State of the Union.&#8221; Tapper wanted to know why the spy balloon was not ...

## DeSantis Admin Moves To Punish Florida Venue That Hosted ‘Sexually Explicit’ Drag Show Open To Kids
 - [https://www.dailywire.com/news/desantis-admin-moves-to-punish-florida-venue-that-hosted-sexually-explicit-drag-show-open-to-kids](https://www.dailywire.com/news/desantis-admin-moves-to-punish-florida-venue-that-hosted-sexually-explicit-drag-show-open-to-kids)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 12:03:01+00:00
 - user: None

The administration of Gov. Ron DeSantis (R-FL) moved to revoke the liquor license of a Florida venue that hosted a &#8220;sexually explicit&#8221; drag show that was open to children, according to a complaint filed Friday.  The Orlando Philharmonic Plaza Foundation, a performance art center, had hosted a performance of “A Drag Queen Christmas” on December ...

## NYPD Officer ‘Fighting For His Life’ After Being Shot In Head
 - [https://www.dailywire.com/news/nypd-officer-fighting-for-his-life-after-being-shot-in-head](https://www.dailywire.com/news/nypd-officer-fighting-for-his-life-after-being-shot-in-head)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 11:46:16+00:00
 - user: None

An off-duty New York City police officer is in critical condition after being shot in the head during a robbery attempt Saturday evening, according to authorities. The officer, identified as a 26-year-old and five-year veteran of the New York Police Department, travelled with a relative to Ruby Street in Brooklyn to purchase a vehicle in ...

## Chinese Spy Balloon Crashed Near Hawaii Last Year; One Flew Over Southern U.S. States Under Trump: Report
 - [https://www.dailywire.com/news/chinese-spy-balloon-crashed-near-hawaii-last-year-one-flew-over-southern-u-s-states-under-trump-report](https://www.dailywire.com/news/chinese-spy-balloon-crashed-near-hawaii-last-year-one-flew-over-southern-u-s-states-under-trump-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 11:14:11+00:00
 - user: None

A new report released Sunday revealed at least two separate incidents of Chinese spy balloons flying over or near U.S. states over the last several years. &#8220;A Chinese spy balloon crashed into the Pacific off the coast of Hawaii four months ago,&#8221; reported Fox News correspondent Lucas Tomlinson. &#8220;Fox News has also learned at least ...

## Scientific Community Should Admit It Was Wrong About COVID, Medical Researcher Says
 - [https://www.dailywire.com/news/scientific-community-should-admit-it-was-wrong-about-covid-medical-researcher-says](https://www.dailywire.com/news/scientific-community-should-admit-it-was-wrong-about-covid-medical-researcher-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 09:27:45+00:00
 - user: None

Could the experts be starting to admit, three years later, that they were wrong about COVID? At least one medical researcher is calling on the scientific community to admit mistakes were made. &#8220;I was wrong. We in the scientific community were wrong. And it cost lives,&#8221; wrote Kevin Bass, an MD/PhD student, in a recent op-ed ...

## A Third Chinese Spy Balloon Likely Discovered By U.S. Officials Who Don’t Reveal Its Location: Report
 - [https://www.dailywire.com/news/a-third-chinese-spy-balloon-likely-discovered-by-u-s-officials-who-dont-reveal-its-location-report](https://www.dailywire.com/news/a-third-chinese-spy-balloon-likely-discovered-by-u-s-officials-who-dont-reveal-its-location-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 08:54:24+00:00
 - user: None

U.S. officials reportedly believe that they have identified a third Chinese spy balloon that is likely operating in the air right now, but they did not reveal its location. The news comes after the U.S. military used an F-22 Raptor to take out a Chinese spy balloon off the coast of South Carolina on Saturday ...

## South American Nation Detects Another Possible Chinese Spy Balloon
 - [https://www.dailywire.com/news/south-american-nation-detects-another-possible-chinese-spy-balloon](https://www.dailywire.com/news/south-american-nation-detects-another-possible-chinese-spy-balloon)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 08:52:02+00:00
 - user: None

A South American nation revealed late on Saturday that it detected a possible Chinese spy balloon operating in its airspace last week. The Colombian Air Force said in a statement that on Friday morning, &#8220;the National Air Defense System detected an object above 55,000 feet, which entered Colombian airspace in the northern sector of the ...

## How We Got Here: Biden’s Think Tank And How It Sought To ‘Advance The World Order’
 - [https://www.dailywire.com/news/how-we-got-here-bidens-think-tank-and-how-it-sought-to-advance-the-world-order](https://www.dailywire.com/news/how-we-got-here-bidens-think-tank-and-how-it-sought-to-advance-the-world-order)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-02-05 08:17:58+00:00
 - user: None

When the Penn Biden Center for Diplomacy and Global Engagement opened five years ago, University of Pennsylvania (UPenn) President Amy Gutmann bragged of how Joe Biden&#8217;s &#8220;unmatched personal connections&#8221; would help &#8220;advance the world order.&#8221; Now, after classified documents were discovered at the Washington, D.C., think tank, concerns are being raised about foreign benefactors, particularly ...
