# Source Daily Mail, Source URL:https://www.dailymail.co.uk/news/index.rss, Source language: en-US

## Peter FitzSimons and Lisa Wilkinson cancel Australia Day party after 'year from hell'
 - [https://www.dailymail.co.uk/news/article-11716029/Peter-FitzSimons-Lisa-Wilkinson-cancel-Australia-Day-party-year-hell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716029/Peter-FitzSimons-Lisa-Wilkinson-cancel-Australia-Day-party-year-hell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 23:47:40+00:00
 - user: None

The high profile couple's annual January 26 barbecue at their harbourside mansion on Sydney's lower north shore was once one of biggest events of the year for Sydney's A-list.

## Eggs are now so expensive Americans are smuggling them from MEXICO with 300% jump in number seized
 - [https://www.dailymail.co.uk/news/article-11716253/Eggs-expensive-Americans-smuggling-MEXICO-300-jump-number-seized.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716253/Eggs-expensive-Americans-smuggling-MEXICO-300-jump-number-seized.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 23:46:43+00:00
 - user: None

As egg prices rise in the US some Americans are attempting to save money by  purchasing them in Mexico and bringing them back across the border.

## Calls to ban Cool Cabanas from beaches as Australian invention takes over popular spots
 - [https://www.dailymail.co.uk/news/article-11715969/Calls-ban-Cool-Cabanas-beaches-Australian-invention-takes-popular-spots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715969/Calls-ban-Cool-Cabanas-beaches-Australian-invention-takes-popular-spots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 23:45:56+00:00
 - user: None

Beaches across the country have recently been filled with cabanas as Aussies become more sun-safe, but some complain the shelters are an eye-sore and block the views of the ocean.

## China FIRES its weather service chief as it doubles down on claim spy balloon was blown off course
 - [https://www.dailymail.co.uk/news/article-11716217/China-FIRES-weather-service-chief-doubles-claim-spy-balloon-blown-course.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716217/China-FIRES-weather-service-chief-doubles-claim-spy-balloon-blown-course.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 23:45:48+00:00
 - user: None

China has fired Zhuang Guotai, the head of the China Meteorological Administration, and insists the spy balloon was simply weather monitoring. Debris was being recovered on Sunday.

## Newspoll: 'Quiet majority' of Australians support Anthony Albanese's Indigenous Voice to Parliament
 - [https://www.dailymail.co.uk/news/article-11716067/Newspoll-Quiet-majority-Australians-support-Anthony-Albaneses-Indigenous-Voice-Parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716067/Newspoll-Quiet-majority-Australians-support-Anthony-Albaneses-Indigenous-Voice-Parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 23:28:33+00:00
 - user: None

Most Australians are in favour of an Indigenous Voice to Parliament, according to the latest Newspoll.

## New Australian passport is revealed - after it was named one of the most powerful in the world
 - [https://www.dailymail.co.uk/news/article-11715971/New-Australian-passport-revealed-named-one-powerful-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715971/New-Australian-passport-revealed-named-one-powerful-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 23:24:07+00:00
 - user: None

Australia has a redesigned passport featuring a raft of changes including pages more resistant to wear and tear and that change colour under UV light.

## Epic battle that became a slaughterhouse of tanks
 - [https://www.dailymail.co.uk/news/article-11716285/Epic-battle-slaughterhouse-tanks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716285/Epic-battle-slaughterhouse-tanks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:56:04+00:00
 - user: None

Eighty years on from the battle that decisively pushed the Nazis back from the eastern front, German panzers are about to meet a new generation of Russian tanks.

## Sasha Walpole, the mystery lover in Duke of Sussex's memoir, recalls the fallout from their romp
 - [https://www.dailymail.co.uk/news/article-11716117/Sasha-Walpole-mystery-lover-Duke-Sussexs-memoir-recalls-fallout-romp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716117/Sasha-Walpole-mystery-lover-Duke-Sussexs-memoir-recalls-fallout-romp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:45:11+00:00
 - user: None

Sasha Walpole, now 40, laughed with her sister the morning after the five-minute sex session in a pub field in July 2001, and confessed what happened to her mother at the time.

## Skull found in Alaska linked to New York man nearly 47 years after he was likely mauled by bear
 - [https://www.dailymail.co.uk/news/article-11716057/Skull-Alaska-Linked-New-York-Man-Missing-1976.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716057/Skull-Alaska-Linked-New-York-Man-Missing-1976.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:45:07+00:00
 - user: None

Gary Frank Sotherden, then 25, traveled to the Arctic Circle in 1976 but never made it out as investigators later determined he died after being mauled by a bear.

## ITV show reveals how convincing - and therefore dangerous - 'deepfake' videos can be
 - [https://www.dailymail.co.uk/news/article-11716211/ITV-reveals-convincing-dangerous-deepfake-videos-be.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716211/ITV-reveals-convincing-dangerous-deepfake-videos-be.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:44:06+00:00
 - user: None

If this all sounds like the ingredients of an extended suburban nightmare, that is entirely the intention of a new ITV series which constitutes the world's first 'deepfake' comedy series.

## Head of Epsom College is found dead alongside daughter, seven, and husband at independent school
 - [https://www.dailymail.co.uk/news/article-11716183/Head-Epsom-College-dead-alongside-daughter-seven-husband-independent-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716183/Head-Epsom-College-dead-alongside-daughter-seven-husband-independent-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:43:29+00:00
 - user: None

Emma Pattinson, 45, and her husband George, 39, were found dead alongside her seven-year-old daughter, Lettie after police were called to the £42,000 school at 1am on Sunday.

## NHS spends £400,000 A DAY on private ambulances and taxis for patients
 - [https://www.dailymail.co.uk/news/article-11716215/NHS-spends-400-000-DAY-private-ambulances-taxis-patients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716215/NHS-spends-400-000-DAY-private-ambulances-taxis-patients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:41:02+00:00
 - user: None

The NHS is spending £400,000 a day on private ambulances and taxis to plug gaps in emergency care amid the biggest industrial action in health service history starting tomorrow.

## Massive 50-car train derailment causes inferno and the spillage of hazardous chemicals
 - [https://www.dailymail.co.uk/news/article-11715973/Massive-50-car-train-derailment-causes-inferno-spillage-hazardous-chemicals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715973/Massive-50-car-train-derailment-causes-inferno-spillage-hazardous-chemicals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:39:46+00:00
 - user: None

The derailment of a cargo train triggered a huge fire and the spillage of hazardous chemicals, forcing the evacuation of 2,000 people from their homes in Ohio.

## Aussie rips into Woolworths over a very annoying new feature
 - [https://www.dailymail.co.uk/news/article-11715953/Aussie-rips-Woolworths-annoying-new-feature.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715953/Aussie-rips-Woolworths-annoying-new-feature.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:27:17+00:00
 - user: None

An angry Woolworths customers has slammed its new carparks reserved for eco-friendly vehicles as 'discrimination'.

## End delay to trans advice for teachers so they are not left in the dark, ministers are told
 - [https://www.dailymail.co.uk/news/article-11716259/End-delay-trans-advice-teachers-not-left-dark-ministers-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716259/End-delay-trans-advice-teachers-not-left-dark-ministers-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:24:28+00:00
 - user: None

Ministers were last night facing urgent calls to publish guidance for teachers which would help them block children from changing gender if they believe they are too young.

## Donald Trump Jr mocks his father by retweeting a picture of a giant BABY blimp
 - [https://www.dailymail.co.uk/news/article-11716061/Donald-Trump-Jr-mocks-father-retweeting-picture-giant-BABY-blimp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716061/Donald-Trump-Jr-mocks-father-retweeting-picture-giant-BABY-blimp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:24:02+00:00
 - user: None

The 45-year-old retweeted the picture of the Trump Baby Blimp after someone joked that it should be flown over Beijing after US authorities shot down China's spy balloon.

## Zombie Nation: Shocking images lay bare America's drug crisis
 - [https://www.dailymail.co.uk/news/article-11701187/Zombie-Nation-Shocking-images-lay-bare-Americas-drug-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11701187/Zombie-Nation-Shocking-images-lay-bare-Americas-drug-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:15:17+00:00
 - user: None

Just two milligrams of fentanyl - the amount that fits on the top of a pencil - is a deadly dose. And despite nationwide stings, many authorities admit there's no end in sight to the narcotic epidemic.

## Horrifying moment Florida police drag a 69-year-old man into elevator after shooting him
 - [https://www.dailymail.co.uk/news/article-11716007/Horrifying-moment-Florida-police-drag-69-year-old-man-elevator-shooting-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716007/Horrifying-moment-Florida-police-drag-69-year-old-man-elevator-shooting-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:14:25+00:00
 - user: None

A shocking new video has been released showing the moment police in Florida dragged a gravely wounded elderly man into an elevator after they had shot him in 2022.

## 'This rides roughshod over the village': Locals are at war with £2bn pandemic tycoon over plans
 - [https://www.dailymail.co.uk/news/article-11716105/This-rides-roughshod-village-Locals-war-2bn-pandemic-tycoon-plans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716105/This-rides-roughshod-village-Locals-war-2bn-pandemic-tycoon-plans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:03:30+00:00
 - user: None

Sarah Stoute, 49, has planned to erect 411 stables near thatched cottages and a medieval church, horrifying neighbours in Keysoe village, Bedfordshire.

## BBC journalist Laura Trevelyan's family will apologise and pay reparations for ancestors slave links
 - [https://www.dailymail.co.uk/news/article-11716093/BBC-journalist-Laura-Trevelyans-family-apologise-pay-reparations-ancestors-slave-links.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716093/BBC-journalist-Laura-Trevelyans-family-apologise-pay-reparations-ancestors-slave-links.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:02:04+00:00
 - user: None

Laura Trevelyan's aristocratic relatives had more than 1,000 slaves across six sugar plantations on the Caribbean island in the 19th century.

## Cancelling long-term plan to tackle cancer will put thousands more lives at risk, experts warn
 - [https://www.dailymail.co.uk/news/article-11716139/Cancelling-long-term-plan-tackle-cancer-thousands-lives-risk-experts-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716139/Cancelling-long-term-plan-tackle-cancer-thousands-lives-risk-experts-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 22:01:47+00:00
 - user: None

Cancer survival will go from 'bad to worse' unless the Government reverses its decision to scrap a long-term plan dedicated to fighting the disease, leading doctors have warned.

## Debt limit: Republican and Democrat say they'll have a 'failsafe' if Biden's talks with McCarthy die
 - [https://www.dailymail.co.uk/news/article-11715893/Debt-limit-Republican-Democrat-say-theyll-failsafe-Bidens-talks-McCarthy-die.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715893/Debt-limit-Republican-Democrat-say-theyll-failsafe-Bidens-talks-McCarthy-die.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 21:39:19+00:00
 - user: None

House Republicans have been in a stalemate with the White House and Senate Democrats amid urgent warnings from the Treasury that action needs to be taken to raise the debt ceiling.

## Koch network releases plan to defeat Trump for GOP nomination in 2024
 - [https://www.dailymail.co.uk/news/article-11715841/Koch-network-releases-plan-defeat-Trump-GOP-nomination-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715841/Koch-network-releases-plan-defeat-Trump-GOP-nomination-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 21:38:22+00:00
 - user: None

The declaration, released in a memo to staffers and activists Sunday, did not specify which candidate would receive the prospective funding, but vowed that it would  not be the ex-head of state.

## Serial killer dubbed The Serpent, 78, denies being responsible for string of deaths in the 1970s
 - [https://www.dailymail.co.uk/news/article-11716039/Serial-killer-dubbed-Serpent-78-denies-responsible-string-deaths-1970s.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11716039/Serial-killer-dubbed-Serpent-78-denies-responsible-string-deaths-1970s.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 21:37:59+00:00
 - user: None

Charles Sobhraj, the 78-year-old Frenchman dubbed 'The Serpent' in the hit BBC TV drama of the same name, was on Sunday speaking for the first time since being released from prison.

## Dog owner facing £20,000 vet bills says he will 'sell his house' to keep his Weimaraner alive
 - [https://www.dailymail.co.uk/news/article-11715917/Dog-owner-facing-20-000-vet-bills-says-sell-house-Weimaraner-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715917/Dog-owner-facing-20-000-vet-bills-says-sell-house-Weimaraner-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 21:36:07+00:00
 - user: None

Jaxon Feeley said on January 20, his two-year-old Weimaraner called Rambo went into hypovolemic shock and had also contracted gastroenteritis. Her health rapidly declined.

## Ukrainians flock to Kyiv ski slopes as missile strikes ease amid fresh calls for warplanes
 - [https://www.dailymail.co.uk/news/article-11715859/Ukrainians-flock-Kyiv-ski-slopes-missile-strikes-ease-amid-fresh-calls-warplanes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715859/Ukrainians-flock-Kyiv-ski-slopes-missile-strikes-ease-amid-fresh-calls-warplanes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 21:30:49+00:00
 - user: None

As Ukraine enters its first full winter since Russia's catastrophic invasion last year, many flocked to Protasiv Yar ski resort near to downtown Kyiv. It comes just as missile strikes have died down.

## Channel 9 reporter Shuba Krishnan harassed by anti-vaxxers in Melbourne
 - [https://www.dailymail.co.uk/news/article-11715995/Channel-9-reporter-Shuba-Krishnan-harassed-anti-vaxxers-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715995/Channel-9-reporter-Shuba-Krishnan-harassed-anti-vaxxers-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 21:30:06+00:00
 - user: None

Reporter Shuba Krishnan had been covering a protest unfolding outside Parliament House in Melbourne on Saturday.

## House GOP considers resolution condemning Biden's handling of Chinese spy balloon fiasco
 - [https://www.dailymail.co.uk/news/article-11715867/House-GOP-considers-resolution-condemning-Bidens-handling-Chinese-spy-balloon-fiasco.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715867/House-GOP-considers-resolution-condemning-Bidens-handling-Chinese-spy-balloon-fiasco.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:48:41+00:00
 - user: None

Republicans on Capitol Hill are considering bringing a resolution that would condemn President Joe Biden for his handling of the Chinese spy balloon fiasco.

## The Met's professionalism chief issues apology to victims of rapist cop David Carrick
 - [https://www.dailymail.co.uk/news/article-11715793/The-Mets-professionalism-chief-issues-apology-victims-rapist-cop-David-Carrick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715793/The-Mets-professionalism-chief-issues-apology-victims-rapist-cop-David-Carrick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:47:29+00:00
 - user: None

Assistant Commander Barbara Gray, said on Sunday that she was 'truly sorry for the harm and devastation' David Carrick caused. The serial rapist will be sentenced for his crimes on Monday.

## Twitter considers charging businesses $1k a month for a gold verification badge
 - [https://www.dailymail.co.uk/news/article-11715823/Twitter-considers-charging-businesses-1k-month-gold-verification-badge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715823/Twitter-considers-charging-businesses-1k-month-gold-verification-badge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:47:03+00:00
 - user: None

Twitter is considering charging businesses on the platform $1,000 per month to retain their gold verified checkmarks.

## Family of Ethan Chapin question why surviving roommate Dylan Mortensen didn't call the cops
 - [https://www.dailymail.co.uk/news/article-11715673/Family-Ethan-Chapin-question-surviving-roommate-Dylan-Mortensen-didnt-call-cops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715673/Family-Ethan-Chapin-question-surviving-roommate-Dylan-Mortensen-didnt-call-cops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:46:15+00:00
 - user: None

Ethan's sister-in-law made several posts online before the arrest affidavit was unsealed for suspected quadruple killer Bryan Kohberger.

## Urgent search is launched for missing boy and girl in Australia
 - [https://www.dailymail.co.uk/news/article-11715943/Urgent-search-launched-missing-boy-girl-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715943/Urgent-search-launched-missing-boy-girl-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:45:12+00:00
 - user: None

A search for two children who went missing in Western Australia is over after they were found safe and well.

## South Carolina cops order locals to steer clear of debris from Chinese spy balloon
 - [https://www.dailymail.co.uk/news/article-11715781/South-Carolina-cops-order-locals-steer-clear-debris-Chinese-spy-balloon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715781/South-Carolina-cops-order-locals-steer-clear-debris-Chinese-spy-balloon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:38:55+00:00
 - user: None

South Carolina officials warned residents to stay away from fallen Chinese spy balloon debris that is expected to wash to ashore after it was blown out of the sky by an F22 missile on Saturday.

## Trans North Dakota doctor is opening gender-affirming clinic for LGBTQ+ people of ALL AGES
 - [https://www.dailymail.co.uk/news/article-11715821/Trans-North-Dakota-doctor-opening-gender-affirming-clinic-LGBTQ-people-AGES.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715821/Trans-North-Dakota-doctor-opening-gender-affirming-clinic-LGBTQ-people-AGES.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:37:45+00:00
 - user: None

A trans doctor who is based in North Dakota is opening a clinic to provide a gender-affirming clinic for all LGBTQ+ people as state legislators push a bill banning the practice for minors in the state.

## Perth teens recall moment 16-year-old Stella Berry mauled by shark at Swan River
 - [https://www.dailymail.co.uk/news/article-11715857/Perth-teens-recall-moment-16-year-old-Stella-Berry-mauled-shark-Swan-River.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715857/Perth-teens-recall-moment-16-year-old-Stella-Berry-mauled-shark-Swan-River.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:37:06+00:00
 - user: None

Luke Smith and Joshua Warwick relived the terrifying moment the attack unfolded along the Swan River in North Fremantle, at about 3.30pm on Saturday.

## Huge change coming to pokies in Australia
 - [https://www.dailymail.co.uk/news/article-11715963/Huge-change-coming-pokies-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715963/Huge-change-coming-pokies-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:24:17+00:00
 - user: None

Every poker machine in NSW will be cashless within five years under an ambitious plan to overhaul the gaming industry.

## Commuters fear impact of scrapping return train tickets and having to pay for two single trips
 - [https://www.dailymail.co.uk/news/article-11715911/Commuters-fear-impact-scrapping-return-train-tickets-having-pay-two-single-trips.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715911/Commuters-fear-impact-scrapping-return-train-tickets-having-pay-two-single-trips.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 20:13:31+00:00
 - user: None

Transport secretary Mark Harper will announce the changes in a speech on Tuesday evening, having been given the green light by Prime Minister Rishi Sunak amid an overhaul of the railway.

## Trump calls Chris Christie 'sloppy' after he predicts ex-president will LOSE to Biden again
 - [https://www.dailymail.co.uk/news/article-11715749/Trump-calls-Chris-Christie-sloppy-predicts-ex-president-LOSE-Biden-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715749/Trump-calls-Chris-Christie-sloppy-predicts-ex-president-LOSE-Biden-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 19:29:04+00:00
 - user: None

Former Republican Governor and 2016 White House candidate Christie told ABC News' This Week when asked if Trump could beat President Joe Biden in the next race: 'I don't think so.'

## Don Lemon escapes to California with his partner after CNN anchor had SECOND blowout at staff
 - [https://www.dailymail.co.uk/news/article-11715575/Don-Lemon-escapes-California-partner-CNN-anchor-SECOND-blowout-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715575/Don-Lemon-escapes-California-partner-CNN-anchor-SECOND-blowout-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 18:45:28+00:00
 - user: None

Lemon is now enjoying a vacation in Beverly Hills with his partner Tim Moloney, who posted a picture of the pair - ignoring the claims Lemon flew into a rage.

## California kayaker, 39, found dead 100 yards from the shore five days
 - [https://www.dailymail.co.uk/news/article-11715437/California-kayaker-39-dead-100-yards-shore-five-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715437/California-kayaker-39-dead-100-yards-shore-five-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 18:43:45+00:00
 - user: None

The discovery, made Wednesday, comes nearly a week after the disappearance of Clinton Koga (pictured with daughter Kailey), some miles north of South Francisco.

## Melania Trump took central role in al-Baghdadi killing
 - [https://www.dailymail.co.uk/news/article-11715631/Melania-Trump-took-central-role-al-Baghdadi-killing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715631/Melania-Trump-took-central-role-al-Baghdadi-killing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 18:40:28+00:00
 - user: None

Melania Trump played a central role during the October 2019 raid to kill ISIS leader Abu Bakr al-Baghdadi, sitting in Situation Room and suggesting Donald Trump feature Conan, hero dog.

## Florida pastor, 64, arrested over $8.4M COVID loans scam is accused of faking illness
 - [https://www.dailymail.co.uk/news/article-11715513/Florida-pastor-64-arrested-8-4M-COVID-loans-scam-accused-faking-illness.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715513/Florida-pastor-64-arrested-8-4M-COVID-loans-scam-accused-faking-illness.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 18:38:01+00:00
 - user: None

A Florida pastor accused of fraudulently obtaining $8.4 million in COVID loads is accused of faking an illness to avoid prison time. Evan Edwards, 64, was arrested in December along with his son.

## Apprentice winner Alana Spencer faces legal action after van is left on promenade for three months
 - [https://www.dailymail.co.uk/news/article-11715659/Apprentice-winner-Alana-Spencer-faces-legal-action-van-left-promenade-three-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715659/Apprentice-winner-Alana-Spencer-faces-legal-action-van-left-promenade-three-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 18:29:01+00:00
 - user: None

The 2016 winner Alana Spencer had parked the bright blue vehicle outside her cafe in the coastal town of Llandudno, North Wales, before council highways bosses issued the caution.

## Marco Rubio: Chinese spy balloon was 'a message' Beijing believes U.S. is 'in decline'
 - [https://www.dailymail.co.uk/news/article-11715577/Marco-Rubio-Chinese-spy-balloon-message-Beijing-believes-U-S-decline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715577/Marco-Rubio-Chinese-spy-balloon-message-Beijing-believes-U-S-decline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 18:20:21+00:00
 - user: None

Marco Rubio said that the Chinese spy balloon appearance was purposefully planned to appear in U.S. airspace just days ahead of Secretary of State Antony Blinken's trip to China

## Parents demand answers over daughter's death in Pakistan - and disappearance of their grandchildren
 - [https://www.dailymail.co.uk/news/article-11715087/Parents-demand-answers-daughters-death-Pakistan-disappearance-grandchildren.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715087/Parents-demand-answers-daughters-death-Pakistan-disappearance-grandchildren.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 18:07:23+00:00
 - user: None

Kelsey Devlin, 27, died in 2021 after flying to Islamabad with children Zara and Zain, after receiving news that her mother-in-law was dying - but died three weeks later.

## Trump DENIES Pentagon's claim that three 'Chinese balloons' entered US airspace under his watch
 - [https://www.dailymail.co.uk/news/article-11715549/Trump-DENIES-Pentagons-claim-three-Chinese-balloons-entered-airspace-watch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715549/Trump-DENIES-Pentagons-claim-three-Chinese-balloons-entered-airspace-watch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 18:03:25+00:00
 - user: None

'The Chinese Balloon situation is a disgrace, just like the Afghanistan horror show, and everything else surrounding the grossly incompetent Biden Administration,' Trump wrote on Truth Social.

## Ex-US Marine, 33, is killed in Russian missile attack in Ukraine while evacuating wounded civilians
 - [https://www.dailymail.co.uk/news/article-11715509/Ex-Marine-33-killed-Russian-missile-attack-Ukraine-evacuating-wounded-civilians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715509/Ex-Marine-33-killed-Russian-missile-attack-Ukraine-evacuating-wounded-civilians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 17:45:04+00:00
 - user: None

A former US Marine working as a volunteer medic in Ukraine was killed while evacuating civilians from Bakhmut in the east of the country.

## Lisa Marie Presley 'couldn't handle the stress' of appearing at Golden Globes days before she died
 - [https://www.dailymail.co.uk/news/article-11715475/Lisa-Marie-Presley-handle-stress-appearing-Golden-Globes-days-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715475/Lisa-Marie-Presley-handle-stress-appearing-Golden-Globes-days-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 17:44:36+00:00
 - user: None

Lisa Marie Presley was struggling to cope with the pressure of appearing at the 2023 Golden Globe Awards.

## Missing mother Nicola Bulley is captured on CCTV doing the school run on the day she vanished
 - [https://www.dailymail.co.uk/news/article-11715619/Missing-mother-Nicola-Bulley-captured-CCTV-doing-school-run-day-vanished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715619/Missing-mother-Nicola-Bulley-captured-CCTV-doing-school-run-day-vanished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 17:43:34+00:00
 - user: None

Peter Faulding, a world-renowned forensics expert who is a diver for the police and has worked on hundreds of cases across the southeast, believes it is unlikely the river bank is the correct answer.

## Women's rights campaigner Kellie-Jay Keen thanks Nicola Sturgeon for 'waking up Scotland' in Glasgow
 - [https://www.dailymail.co.uk/news/article-11715379/Womens-rights-campaigner-Kellie-Jay-Keen-thanks-Nicola-Sturgeon-waking-Scotland-Glasgow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715379/Womens-rights-campaigner-Kellie-Jay-Keen-thanks-Nicola-Sturgeon-waking-Scotland-Glasgow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 17:34:17+00:00
 - user: None

Standing for Women, led by Kellie-Jay Keen, staged a protest today against the SNP's gender reforms, which were passed by MSPs in December but blocked by the UK Government.

## America's worst colleges for free speech: Hamline University makes top 10 list
 - [https://www.dailymail.co.uk/news/article-11715299/Americas-worst-colleges-free-speech-Hamline-University-makes-10-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715299/Americas-worst-colleges-free-speech-Hamline-University-makes-10-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 17:33:11+00:00
 - user: None

Hamline University has been named as one of the worst colleges in the United States for free speech after the school fired a professor for showing a painting of the prophet Muhammad.

## Rags and riches: Larry Fink's photos lay bare 1970s America's wealth gap
 - [https://www.dailymail.co.uk/news/article-11702555/Rags-riches-Larry-Finks-photos-lay-bare-1970s-Americas-wealth-gap.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11702555/Rags-riches-Larry-Finks-photos-lay-bare-1970s-Americas-wealth-gap.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 16:46:36+00:00
 - user: None

Larry Fink photoseries shows the contrast between wealth and povery in 1970s America. Fink split his time between Manhattan discoes and 
the Martins Creek farm in Pennsylvania.

## Screaming diners flee restaurant which erupted in flames 'due to sparkler in alcoholic drink'
 - [https://www.dailymail.co.uk/news/article-11715453/Screaming-diners-flee-restaurant-erupted-flames-sparkler-alcoholic-drink.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715453/Screaming-diners-flee-restaurant-erupted-flames-sparkler-alcoholic-drink.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 16:46:12+00:00
 - user: None

Screaming diners fled a restaurant which erupted into flames 'due to a sparkler' in a drink. Footage posted to TikTok shows the blaze at Caffe Milano Di in Birmingham.

## Father brings his six-year-old daughter to protest Gary Glitter's bail hostel
 - [https://www.dailymail.co.uk/news/article-11715387/Father-brings-six-year-old-daughter-protest-Gary-Glitters-bail-hostel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715387/Father-brings-six-year-old-daughter-protest-Gary-Glitters-bail-hostel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 16:37:12+00:00
 - user: None

A father brought his six-year-old daughter to protest outside Gary Glitter's bail hostel today, demanding: 'Why are they protecting a paedophile?'

## Disgraced congressman George Santos has been accused of sexually harassing an aide who he fired
 - [https://www.dailymail.co.uk/news/article-11715373/Disgraced-congressman-George-Santos-accused-sexually-harassing-aide-fired.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715373/Disgraced-congressman-George-Santos-accused-sexually-harassing-aide-fired.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 16:29:58+00:00
 - user: None

The pair had been going through letters from constituents on January 25 when the allegations took place, according to the letter sent to the House Committee on Ethics.

## Biden offered Congress a classified files briefing when China spy balloon became public: Mike Turner
 - [https://www.dailymail.co.uk/news/article-11715405/Biden-offered-Congress-classified-files-briefing-China-spy-balloon-public-Mike-Turner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715405/Biden-offered-Congress-classified-files-briefing-China-spy-balloon-public-Mike-Turner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 16:21:49+00:00
 - user: None

Additionally, Turner said Biden officials would brief lawmakers on classified documents recovered from former Vice President Mike Pence, as well as from the president himself.

## Young off-duty cop is shot in the head while accompanying his brother to buy a car
 - [https://www.dailymail.co.uk/news/article-11715347/Young-duty-cop-shot-head-accompanying-brother-buy-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715347/Young-duty-cop-shot-head-accompanying-brother-buy-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 16:21:32+00:00
 - user: None

A 26-year-old NYPD officer was shot in the head while accompanying his brother to buy a car off Facebook Marketplace in a Brooklyn neighborhood.

## Rugby fan whose ancestor wrote famous hymn wades into row over banning of Tom Jones' hit Delila
 - [https://www.dailymail.co.uk/news/article-11715343/Rugby-fan-ancestor-wrote-famous-hymn-wades-row-banning-Tom-Jones-hit-Delila.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715343/Rugby-fan-ancestor-wrote-famous-hymn-wades-row-banning-Tom-Jones-hit-Delila.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 16:20:08+00:00
 - user: None

John Wilesmith is distantly related to William Williams Pantycelyn, who wrote what would become Bread of Heaven.

## Man in his 40s is arrested after two people died at an apartment in Belfast
 - [https://www.dailymail.co.uk/news/article-11715451/Man-40s-arrested-two-people-died-apartment-Belfast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715451/Man-40s-arrested-two-people-died-apartment-Belfast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 16:17:49+00:00
 - user: None

Police have launched an investigation following the deaths of two people at an apartment in Belfast. The deaths occurred at a property in the Annadale Crescent area of Belfast.

## Horrified husband finds his wife has died after she went to bed complaining of a sore shoulder
 - [https://www.dailymail.co.uk/news/article-11715409/Horrified-husband-finds-wife-died-went-bed-complaining-sore-shoulder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715409/Horrified-husband-finds-wife-died-went-bed-complaining-sore-shoulder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 15:58:03+00:00
 - user: None

Mother-of-two Clare Duffy died from a pulmonary embolism aged 41 after going to bed with a sore shoulder. The family, devastated, are looking for support with funeral costs for Clare and her mother.

## Six-in-10 voters want a general election this year - and more than half want one within SIX WEEKS
 - [https://www.dailymail.co.uk/news/article-11715449/Six-10-voters-want-general-election-year-half-want-one-SIX-WEEKS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715449/Six-10-voters-want-general-election-year-half-want-one-SIX-WEEKS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 15:54:58+00:00
 - user: None

Some 61 per cent of those polled supported an election this year. And some 52 per cent said they wanted Mr Sunak to call an immediate election and hold it within six weeks, before Easter.

## New poll finds Americans DON'T want a 2020 Trump v. Biden rematch
 - [https://www.dailymail.co.uk/news/article-11715295/New-poll-finds-Americans-DONT-want-2020-Trump-v-Biden-rematch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715295/New-poll-finds-Americans-DONT-want-2020-Trump-v-Biden-rematch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 15:40:07+00:00
 - user: None

Most Americans are not looking forward to a rematch between Donald Trump and Joe Biden in 2024 and want other candidates instead, a new poll reveals.

## Colombia releases more details about second Chinese spy balloon hovering over Latin America
 - [https://www.dailymail.co.uk/news/article-11715291/Colombia-releases-details-second-Chinese-spy-balloon-hovering-Latin-America.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715291/Colombia-releases-details-second-Chinese-spy-balloon-hovering-Latin-America.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 15:35:56+00:00
 - user: None

The Colombian Air Force has released additional information about another high-altitude Chinese spy balloon, seen hovering over parts of Latin America.

## Is America's love affair with Harry and Meghan over? Sussexes' star 'is waning' following Spare
 - [https://www.dailymail.co.uk/news/article-11715297/Is-Americas-love-affair-Harry-Meghan-Sussexes-star-waning-following-Spare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715297/Is-Americas-love-affair-Harry-Meghan-Sussexes-star-waning-following-Spare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 15:11:08+00:00
 - user: None

America's infatuation with Prince Harry and Meghan Markle appears to have hit a rough patch following the release of the their Netflix docuseries and the Duke of Sussex's bombshell memoir Spare.

## Russia is 'press-ganging women convicts in occupied Ukraine into joining Putin's army', Kyiv claims
 - [https://www.dailymail.co.uk/news/article-11715351/Russia-press-ganging-women-convicts-occupied-Ukraine-joining-Putins-army-Kyiv-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715351/Russia-press-ganging-women-convicts-occupied-Ukraine-joining-Putins-army-Kyiv-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 15:07:26+00:00
 - user: None

Ukrainian intelligence suggests Russia is preparing to deploy women in combat roles in Ukraine to reinforce lines broken by relentless 'human wave' attacks.

## How US housewife Jane Burrell was a CIA pioneer but did not get recognition
 - [https://www.dailymail.co.uk/news/us-news-weekend-features-project/article-11696867/How-housewife-Jane-Burrell-CIA-pioneer-did-not-recognition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/us-news-weekend-features-project/article-11696867/How-housewife-Jane-Burrell-CIA-pioneer-did-not-recognition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 15:06:45+00:00
 - user: None

Jane Burrell (pictured) was one of a cast of female spies who helped shape America's Central Intelligence Agency (CIA) and its wartime predecessor organisations.

## Becks and Guinness prices skyrocket as cost-of-living crisis hits beer market
 - [https://www.dailymail.co.uk/news/us-news-weekend-features-project/article-11709513/Becks-Guinness-prices-skyrocket-cost-living-crisis-hits-beer-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/us-news-weekend-features-project/article-11709513/Becks-Guinness-prices-skyrocket-cost-living-crisis-hits-beer-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 15:06:08+00:00
 - user: None

MailOnline analysts determined cash-strapped shoppers are now paying, on average, 6.92 per cent more for bottled beer and 9.03 per cent for cans than in they did in early 2022.

## Mosman, Sydney, locals fight against developer application to demolition 1906 Raglan St home
 - [https://www.dailymail.co.uk/news/article-11703799/Mosman-Sydney-locals-fight-against-developer-application-demolition-1906-Raglan-St-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11703799/Mosman-Sydney-locals-fight-against-developer-application-demolition-1906-Raglan-St-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 15:05:27+00:00
 - user: None

Sydney's ultra-rich residents in harbourside Mosman are fighting to keep developers away from their suburb amid  plans to demolish a 117-year-old home.

## Promising Ukrainian decathlon champion who 'could have gone to Paris Olympics' dies in battle
 - [https://www.dailymail.co.uk/news/article-11715277/Promising-Ukrainian-decathlon-champion-gone-Paris-Olympics-dies-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715277/Promising-Ukrainian-decathlon-champion-gone-Paris-Olympics-dies-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 14:41:07+00:00
 - user: None

Promising Ukrainian decathlon champion and 'true hero' Volodymyr Androshchuk, who 'could have gone to the Paris Olympics', has died in battle near Bahmut.

## Black Columbia University professor sues white wealthy banker's widow after she froze $2.8M funding
 - [https://www.dailymail.co.uk/news/article-11715221/Black-Columbia-University-professor-sues-white-wealthy-bankers-widow-froze-2-8M-funding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715221/Black-Columbia-University-professor-sues-white-wealthy-bankers-widow-froze-2-8M-funding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 14:38:42+00:00
 - user: None

Dr Marti Slaten (left) created the Harry T. Burleigh Society in 2017 with her then-student Lynne Foote (right) with the aim of honoring the musician.

## Beijing's mouthpiece China Daily accuses Biden of overreacting to spy balloon incident
 - [https://www.dailymail.co.uk/news/article-11715213/Beijings-mouthpiece-China-Daily-accuses-Biden-overreacting-spy-balloon-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715213/Beijings-mouthpiece-China-Daily-accuses-Biden-overreacting-spy-balloon-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 14:38:27+00:00
 - user: None

Beijing mouthpiece the China Daily made the claim in a scathing editorial  Wednesday, one which charged that Joe Biden and his administration 'overreacted' to the scare - and used it to their benefit.

## Chinese spy balloon: GOP urges Biden to 'blow up TikTok' as US prepares for 'fairly easy' recovery
 - [https://www.dailymail.co.uk/news/article-11715265/Chinese-spy-balloon-GOP-urges-Biden-blow-TikTok-prepares-fairly-easy-recovery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715265/Chinese-spy-balloon-GOP-urges-Biden-blow-TikTok-prepares-fairly-easy-recovery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 14:37:18+00:00
 - user: None

Beijing's government said on Sunday afternoon local time that the U.S.'s response to the balloon was an 'overreaction' and threatened a 'similar' situation if Americans were caught spying.

## Victorian Premier Dan Andrews clashes with Covid anti-vaccine mandate heckler
 - [https://www.dailymail.co.uk/news/article-11715197/Victorian-Premier-Dan-Andrews-clashes-Covid-anti-vaccine-mandate-heckler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715197/Victorian-Premier-Dan-Andrews-clashes-Covid-anti-vaccine-mandate-heckler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 14:32:42+00:00
 - user: None

The disgruntled man on Sunday called the Victorian Premier 'a fraud' during the heated exchange after asking when jab requirements would be dropped for frontline workers.

## Two people are rushed to hospital after crash involving bus and a car in the middle of a street
 - [https://www.dailymail.co.uk/news/article-11715309/Two-people-rushed-hospital-crash-involving-bus-car-middle-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715309/Two-people-rushed-hospital-crash-involving-bus-car-middle-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 14:23:05+00:00
 - user: None

BREAKING NEWS: Two people have been rushed to hospital after a car crash involving a bus and a car in the middle of the street in Addiscombe, Croydon.

## Pub is investigated after death of mother who fell 12 feet into Stag and pheasant's cullar
 - [https://www.dailymail.co.uk/news/article-11715223/Pub-investigated-death-mother-fell-12-feet-Stag-pheasants-cullar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715223/Pub-investigated-death-mother-fell-12-feet-Stag-pheasants-cullar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 13:42:04+00:00
 - user: None

Olwen Collier, tumbled to her death at the Stag and Pheasant in the village of Carmel, Carmarthenshire while she tried to make her daughter's birthday 'extra special'

## MIKE GONZALEZ: Huckster Nikole Hannah-Jones turns white guilt into green bucks in new 1619 Project
 - [https://www.dailymail.co.uk/news/article-11711567/MIKE-GONZALEZ-Huckster-Nikole-Hannah-Jones-turns-white-guilt-green-bucks-new-1619-Project.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11711567/MIKE-GONZALEZ-Huckster-Nikole-Hannah-Jones-turns-white-guilt-green-bucks-new-1619-Project.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 13:35:00+00:00
 - user: None

GONZALEZ: Hardcore woke leftists think that if they can alter America's perception of the past, they can control the present, own the future… and make a whole lot of money in the process.

## Oregon secession movement hopes to inspire national campaign against wokeness
 - [https://www.dailymail.co.uk/news/article-11698713/Oregon-secession-movement-hopes-inspire-national-campaign-against-wokeness.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11698713/Oregon-secession-movement-hopes-inspire-national-campaign-against-wokeness.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 13:33:47+00:00
 - user: None

Leaders of the Greater Idaho Movement say their plan to leave liberal Oregon is making rapid progress, and fear failure could increase the risk of violent struggle.

## Pro-Putin mercenary who waved the 'skull of a dead Ukrainian' is shot in possible 'warning hit'
 - [https://www.dailymail.co.uk/news/article-11715259/Pro-Putin-mercenary-waved-skull-dead-Ukrainian-shot-possible-warning-hit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715259/Pro-Putin-mercenary-waved-skull-dead-Ukrainian-shot-possible-warning-hit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 13:27:39+00:00
 - user: None

WARNING GRAPHIC CONTENT: Igor Mangushev, 36, was famed as one of Russia's most recognisable TV spin doctors before going into the army using the call name of Bereg.

## Sasha Walpole received mocking text messages after Duke wrote about his encounter with 'older' woman
 - [https://www.dailymail.co.uk/news/article-11715169/Sasha-Walpole-received-mocking-text-messages-Duke-wrote-encounter-older-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715169/Sasha-Walpole-received-mocking-text-messages-Duke-wrote-encounter-older-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 12:51:38+00:00
 - user: None

Sasha Walpole, 40, was faced with laugh-out-loud texts and emojis from friends when Prince Harry described the 'humiliating experience' of losing his virginity in his memoirs Spare.

## The 'older women' rumoured to have been in the frame before Sasha Walpole stepped forward
 - [https://www.dailymail.co.uk/news/article-11715095/The-older-women-rumoured-frame-Sasha-Walpole-stepped-forward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715095/The-older-women-rumoured-frame-Sasha-Walpole-stepped-forward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 12:38:23+00:00
 - user: None

MailOnline reveals the women rumoured to be the mystery horse-lover said in Spare to have taken Prince Harry's virginity, before Sasha Walpole stepped forward.

## £250million superprison wins a 'five star' rating in glowing review from paedophile inmate
 - [https://www.dailymail.co.uk/news/article-11715141/250million-superprison-wins-five-star-rating-glowing-review-paedophile-inmate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715141/250million-superprison-wins-five-star-rating-glowing-review-paedophile-inmate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 12:37:25+00:00
 - user: None

Convicted paedophile Michael Thurman wrote a most positive review of Britain's new £253mn superprison in Northamptonshire but says it could use more pillows

## Engine erupts in flames on tourist plane carrying 321 people in Thailand
 - [https://www.dailymail.co.uk/news/article-11715185/Engine-erupts-flames-tourist-plane-carrying-321-people-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715185/Engine-erupts-flames-tourist-plane-carrying-321-people-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 12:36:29+00:00
 - user: None

In the emergency 309 passengers and 12 crew on a Russian tourist plane in Phuket, Thailand, were offloaded and forced to await a new aircraft.

## How close friendship between Sasha Walpole and Prince Harry faded after illicit field encounter
 - [https://www.dailymail.co.uk/news/article-11715133/How-close-friendship-Sasha-Walpole-Prince-Harry-faded-illicit-field-encounter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715133/How-close-friendship-Sasha-Walpole-Prince-Harry-faded-illicit-field-encounter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 12:16:37+00:00
 - user: None

Sasha Walpole, 40, a digger driver from Wiltshire, revealed she was the mystery woman who had sex with Prince Harry in a field - before parting ways to never see each other again.

## Thirty British lottery players are among 100 people who won £1million
 - [https://www.dailymail.co.uk/news/article-11715167/Thirty-British-lottery-players-100-people-won-1million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715167/Thirty-British-lottery-players-100-people-won-1million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 12:03:52+00:00
 - user: None

The 30 UK winners were part of 100 punters who won £1 million in the European Millionaire Maker draw.

## New details emerge of Sea World helicopter crash as survivors break down in tears
 - [https://www.dailymail.co.uk/news/article-11714861/New-details-emerge-Sea-World-helicopter-crash-survivors-break-tears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714861/New-details-emerge-Sea-World-helicopter-crash-survivors-break-tears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 11:48:59+00:00
 - user: None

New details of the January Sea World helicopter crash have emerged as survivors break down in tears recalling the event, and two victims reveal they are still finding glass in their bodies.

## Fire erupts at Hoa Nghiem Buddhist Temple in Melbourne, Springvale South
 - [https://www.dailymail.co.uk/news/article-11715105/Fire-erupts-Hoa-Nghiem-Buddhist-Temple-Melbourne-Springvale-South.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715105/Fire-erupts-Hoa-Nghiem-Buddhist-Temple-Melbourne-Springvale-South.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 11:48:35+00:00
 - user: None

A huge fire has engulfed a popular Buddhist temple in the south-east of Melbourne with flames shooting high in the air and smoke from the inferno being seen 15km away.

## Finance worker, 47, siphoned £24,000 from her 91-year-old grandmother and wasted money
 - [https://www.dailymail.co.uk/news/article-11715115/Finance-worker-47-siphoned-24-000-91-year-old-grandmother-wasted-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715115/Finance-worker-47-siphoned-24-000-91-year-old-grandmother-wasted-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 11:46:39+00:00
 - user: None

Amanda Farr, 47, of Whitstable, Kent, defrauded her 91-year-old grandmother Joyce Hutchings out of £24,069 by siphoning her cash into her own account.

## Police searching for missing Nicola Bulley continue to scour river as 'key witness' comes forward
 - [https://www.dailymail.co.uk/news/article-11715111/Police-searching-missing-Nicola-Bulley-continue-scour-river-key-witness-comes-forward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715111/Police-searching-missing-Nicola-Bulley-continue-scour-river-key-witness-comes-forward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 11:41:00+00:00
 - user: None

On Saturday, police released an image of a potential witness who was spotted in the area at the time of Ms Bulley's disappearance.

## Rishi Sunak prepares to quit human rights convention amid warning of 65,000 Channel migrants in 2023
 - [https://www.dailymail.co.uk/news/article-11715127/Rishi-Sunak-prepares-quit-human-rights-convention-amid-warning-65-000-Channel-migrants-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715127/Rishi-Sunak-prepares-quit-human-rights-convention-amid-warning-65-000-Channel-migrants-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 11:25:12+00:00
 - user: None

The Prime Minister was today reported to be preparing for the extreme move after being told that 65,000 could make the hazardous journey this year, a 50 per cent increase on 2022 record.

## Jalal Homsi jailed for five and a half years for machete injuries inflicted on partner
 - [https://www.dailymail.co.uk/news/article-11714771/Jalal-Homsi-jailed-five-half-years-machete-injuries-inflicted-partner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714771/Jalal-Homsi-jailed-five-half-years-machete-injuries-inflicted-partner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 11:23:05+00:00
 - user: None

Adelaide man Jalal Homsi has been sentenced to spend the next five years in jail over a terrifying attack on his partner when he held a machete to her throat and caused a deep gash to her hand.

## Former soldier, 33, deafened by explosion during a training exercise, wins £350,000 payout from MoD
 - [https://www.dailymail.co.uk/news/article-11715061/Former-soldier-33-deafened-explosion-training-exercise-wins-350-000-payout-MoD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715061/Former-soldier-33-deafened-explosion-training-exercise-wins-350-000-payout-MoD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 11:16:12+00:00
 - user: None

A former British soldier will be able to access therapy for a hearing injury following a successful £350k pay-out from the MoD. The soldier lost his hearing after an explosion at a demo in 2016

## Fast food customer pays £666.50 for a veggie burger and chips which should have cost £6.50
 - [https://www.dailymail.co.uk/news/article-11715077/Fast-food-customer-pays-666-50-veggie-burger-chips-cost-6-50.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715077/Fast-food-customer-pays-666-50-veggie-burger-chips-cost-6-50.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 11:03:29+00:00
 - user: None

Toby Wilson, 35, from Manchester, unknowingly spent hundreds of pounds on the veggie burger and chips at food truck Efe's Kebab Kitchen on his way home from a night out in York

## Rapist, 21, who claimed evidence which linked him to the offence was witchcraft is jailed
 - [https://www.dailymail.co.uk/news/article-11715079/Rapist-21-claimed-evidence-linked-offence-witchcraft-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715079/Rapist-21-claimed-evidence-linked-offence-witchcraft-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 10:48:17+00:00
 - user: None

Demba Embalo, who claimed evidence linking him to the rape of a girl in Peterborough was witchcraft has been jailed. Embalo, 21, attacked the teenager in 2019.

## Mourners line the street for funeral of tragic 18-year-old who was stabbed
 - [https://www.dailymail.co.uk/news/article-11715035/Mourners-line-street-funeral-tragic-18-year-old-stabbed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715035/Mourners-line-street-funeral-tragic-18-year-old-stabbed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 10:46:08+00:00
 - user: None

Owen Dunn, 18, was approached by two youngsters in Swindon, Wiltshire, on Sunday December 4, and suffered a fatal knife wound.

## Stag-gering! Beautiful images capture bellowing stags roaring in morning mist
 - [https://www.dailymail.co.uk/news/article-11714963/Stag-gering-Beautiful-images-capture-bellowing-stags-roaring-morning-mist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714963/Stag-gering-Beautiful-images-capture-bellowing-stags-roaring-morning-mist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 10:44:08+00:00
 - user: None

Images show the stags of Bushy Park, London, bellowing for attention in the first light of dawn. Bushy Park has housed free roaming deer since the land was given to Henry VIII to hunt in.

## Mother of 'fantasist' who lied 'Asian gang' has 'not returned £22,000 donated by well-wishers'
 - [https://www.dailymail.co.uk/news/article-11715013/Mother-fantasist-lied-Asian-gang-not-returned-22-000-donated-wishers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11715013/Mother-fantasist-lied-Asian-gang-not-returned-22-000-donated-wishers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 09:45:47+00:00
 - user: None

The mother of a fantasist who lied about being gang-raped by an Asian 'grooming gang' has still not handed back £22,000 fundraised by well-wishers, it is claimed.

## Return train tickets will be scrapped as 'single-leg pricing' is unveiled
 - [https://www.dailymail.co.uk/news/article-11714979/Return-train-tickets-scrapped-single-leg-pricing-unveiled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714979/Return-train-tickets-scrapped-single-leg-pricing-unveiled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 09:36:00+00:00
 - user: None

Transport secretary Mark Harper will announce the changes this week after Rishi Sunak gave a green light to the proposed changes.

## Who is Sasha Walpole the woman who says she took Prince Harry's virginity?
 - [https://www.dailymail.co.uk/news/article-11714969/Who-Sasha-Walpole-Horse-loving-digger-driver-says-took-Prince-Harrys-virginity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714969/Who-Sasha-Walpole-Horse-loving-digger-driver-says-took-Prince-Harrys-virginity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 09:33:27+00:00
 - user: None

The identity of the mystery 'older woman' who took Prince Harry's virginity was revealed last night as Sasha Walpole, 40, who spoke out following the Duke of Sussex's recent memoir Spare.

## Eyewatering cost of Guy Sebastian's 'monstrous' 'Fort Guy'
 - [https://www.dailymail.co.uk/news/article-11708013/Fort-Guy-Guy-Sebastians-enormous-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11708013/Fort-Guy-Guy-Sebastians-enormous-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 09:20:25+00:00
 - user: None

Guy Sebastian's house has been a point of tension between the singer and his neighbour Phillip Hanslow, 66, since its inception. The pair are now embroiled in a legal battle.

## Living on the EDGE: The families whose homes inch ever closer to falling into the sea
 - [https://www.dailymail.co.uk/news/uk-news-weekend-features-project/article-11709571/Living-EDGE-families-homes-inch-closer-falling-sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/uk-news-weekend-features-project/article-11709571/Living-EDGE-families-homes-inch-closer-falling-sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 09:05:20+00:00
 - user: None

Dozens of families on the east coast could be forced to abandon their homes as coastal erosion threaten their properties. A recent report suggests more than 2,000 homes are under threat.

## The terror tactics of Mexico's cocaine cartels - from public hangings to cannibalism
 - [https://www.dailymail.co.uk/news/uk-news-weekend-features-project/article-11671717/The-terror-tactics-Mexicos-cocaine-cartels-public-hangings-cannibalism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/uk-news-weekend-features-project/article-11671717/The-terror-tactics-Mexicos-cocaine-cartels-public-hangings-cannibalism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 09:04:35+00:00
 - user: None

Heads left to rot in bags, sadistic cannibal initiation rituals, children kidnapped and killed by men who dissolve bodies in acid - the horrifying reality for millions in Mexico

## Salisbury house where retired Russian spy was poisoned with Novichok is bought
 - [https://www.dailymail.co.uk/news/article-11714927/Salisbury-house-retired-Russian-spy-poisoned-Novichok-bought.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714927/Salisbury-house-retired-Russian-spy-poisoned-Novichok-bought.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 09:00:35+00:00
 - user: None

The Salisbury house where Russian spy Sergei Skirpal and his daughter Yulia were poisoned with Novichok in 2018 has been bought five years after the attack.

## Proposed ban on importing fur and foie gras will be dropped
 - [https://www.dailymail.co.uk/news/article-11714955/Proposed-ban-importing-fur-foie-gras-dropped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714955/Proposed-ban-importing-fur-foie-gras-dropped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 08:52:03+00:00
 - user: None

Environment Secretary Therese Coffey claims that although animal welfare is important, the government need to consider their priorities.

## Laneway Festival Sydney: Thousands of party-goers don colourful outfits
 - [https://www.dailymail.co.uk/news/article-11714741/Laneway-Festival-Sydney-Thousands-party-goers-don-colourful-outfits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714741/Laneway-Festival-Sydney-Thousands-party-goers-don-colourful-outfits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 08:47:51+00:00
 - user: None

Thousands of excited revellers took to the Sydney Showgrounds on Sunday for the St. Jerome's Laneway Festival, with the perfect weather bringing out many impressive outfits.

## Grant Shapps tells Ofgem to toughen up on energy suppliers in the wake of prepayment meter scandal
 - [https://www.dailymail.co.uk/news/article-11714933/Grant-Shapps-tells-Ofgem-toughen-energy-suppliers-wake-prepayment-meter-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714933/Grant-Shapps-tells-Ofgem-toughen-energy-suppliers-wake-prepayment-meter-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 08:33:38+00:00
 - user: None

Business Secretary Grant Shapps has told Ofgem to toughen up its regulation after an outcry over struggling families being force-fitted with prepayment meters by British Gas.

## Greg Jenkins finds his mother Anna Jenkins' remains dumped in Penang Malaysia after three year hunt
 - [https://www.dailymail.co.uk/news/article-11699351/Greg-Jenkins-finds-mother-Anna-Jenkins-remains-dumped-Penang-Malaysia-three-year-hunt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11699351/Greg-Jenkins-finds-mother-Anna-Jenkins-remains-dumped-Penang-Malaysia-three-year-hunt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 08:14:35+00:00
 - user: None

Australian grandmother Anna Jenkins, 65, is believed to have been snatched off the streets of Penang in 2017 and never seen again - until her son found her remains dumped in rubble at a building site.

## Geelong night stalker: Hunt for masked man snooping around people's homes
 - [https://www.dailymail.co.uk/news/article-11714445/Geelong-night-stalker-Hunt-masked-man-snooping-peoples-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714445/Geelong-night-stalker-Hunt-masked-man-snooping-peoples-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 08:05:52+00:00
 - user: None

A serial stalker has been filmed peering into windows and trying to break into family homes in the early hours of the morning.

## US braces for Beijing's response as experts warn they will attempt to shift blame for spy balloon
 - [https://www.dailymail.co.uk/news/article-11714735/US-braces-Beijings-response-experts-warn-attempt-shift-blame-spy-balloon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714735/US-braces-Beijings-response-experts-warn-attempt-shift-blame-spy-balloon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 07:39:44+00:00
 - user: None

Beijing warned of 'responses' to come after America shot down a Chinese spy balloon on Saturday that hovered over U.S. nuclear silos, with experts warning of salvage interference.

## Shark attack victim Stella Berry pictures emerge after Swan River tragedy
 - [https://www.dailymail.co.uk/news/article-11714829/Shark-attack-victim-Stella-Berry-pictures-emerge-Swan-River-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714829/Shark-attack-victim-Stella-Berry-pictures-emerge-Swan-River-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 07:39:14+00:00
 - user: None

The first images have emerged of Stella Berry, the fun-loving 16-year-old schoolgirl who was fatally attacked by a shark in WA's Swan River after jumping in to swim with a pod of dolphins.

## Brisbane tradie taking a smoker's break maintains composure as brown snake slithers past
 - [https://www.dailymail.co.uk/news/article-11714725/Brisbane-tradie-taking-smokers-break-maintains-composure-brown-snake-slithers-past.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714725/Brisbane-tradie-taking-smokers-break-maintains-composure-brown-snake-slithers-past.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 07:17:21+00:00
 - user: None

Ayla Manson was taking a cigarette break from her job with Harrison's Gold Coast and Brisbane Snake Catcher when an Eastern Brown Snake crawled past.

## SNL cold open features exclusive interview with the balloon: 'Can't believe I'm Joe's Osama'
 - [https://www.dailymail.co.uk/news/article-11714777/SNL-cold-open-features-exclusive-interview-balloon-believe-Im-Joes-Osama.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714777/SNL-cold-open-features-exclusive-interview-balloon-believe-Im-Joes-Osama.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 07:15:00+00:00
 - user: None

SNL's cold open was a hastily arranged sketch  based on the U.S. military's downing of a Chinese balloon earlier on Saturday. The skit poked fun at the nation's fixation with the suspected spycraft

## FedEx cargo plane almost crashing into Southwest Airlines plane taxiing on runway at Austin Airport
 - [https://www.dailymail.co.uk/news/article-11714511/FedEx-cargo-plane-crashing-Southwest-Airlines-plane-taxiing-runway-Austin-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714511/FedEx-cargo-plane-crashing-Southwest-Airlines-plane-taxiing-runway-Austin-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 07:11:15+00:00
 - user: None

The FAA is investigating aborted landing in Austin, Texas, after a FedEx cargo plane almost landed on a runway on which a Southwest plane was about to takeoff.

## Nine-year-old PA boy graduates HIGH SCHOOL after taking accelerated online courses
 - [https://www.dailymail.co.uk/news/article-11714723/Nine-year-old-PA-boy-graduates-HIGH-SCHOOL-taking-accelerated-online-courses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714723/Nine-year-old-PA-boy-graduates-HIGH-SCHOOL-taking-accelerated-online-courses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 06:58:14+00:00
 - user: None

David Balogun, of Bensalem, has become the youngest graduate from the Reach Cyber Charter School after he completed the program in third grade.

## New York school apologizes served watermelon and chicken waffles on first day of Black History Month
 - [https://www.dailymail.co.uk/news/article-11714563/New-York-school-apologizes-served-watermelon-chicken-waffles-day-Black-History-Month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714563/New-York-school-apologizes-served-watermelon-chicken-waffles-day-Black-History-Month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 06:56:25+00:00
 - user: None

A food vendor  issued an apology after the lunch they gave students at Nyack Middle School on the first day of Black History Month was deemed insensitive.

## Spirit Airlines agents are seen trading blows with passengers at Philly airport
 - [https://www.dailymail.co.uk/news/article-11707233/Spirit-Airlines-agents-seen-trading-blows-passengers-Philly-airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11707233/Spirit-Airlines-agents-seen-trading-blows-passengers-Philly-airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 06:53:04+00:00
 - user: None

The fight erupted at Philadelphia International Airport Monday when a mom, 39, and her 17-year-old daughter were told they had to pay more for their extra-large luggage.

## Teenage girl, 16, mauled to death by a shark s is identified, Swan River, WA
 - [https://www.dailymail.co.uk/news/article-11714561/Teenage-girl-16-mauled-death-shark-s-identified-Swan-River-WA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714561/Teenage-girl-16-mauled-death-shark-s-identified-Swan-River-WA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 06:51:52+00:00
 - user: None

The teenager was jet skiing with her friends when she spotted a pod of dolphins in the Swan River in North Fremantle, Western Australia , at 3.30pm on Saturday.

## How $200m F-22 Raptor shot down Chinese spy balloon with $400k Sidewinder missile
 - [https://www.dailymail.co.uk/news/article-11714125/How-200m-F-22-Raptor-shot-Chinese-spy-balloon-400k-Sidewinder-missile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714125/How-200m-F-22-Raptor-shot-Chinese-spy-balloon-400k-Sidewinder-missile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 06:31:36+00:00
 - user: None

An F-22 Raptor fighter jet fired a single AIM-9X missile to take down a Chinese spy balloon, which was equipped with cameras, sensors and radars, over the coast of South Carolina.

## Kanye West's $2.2M LA Sunday Service HQ looks worse for wear
 - [https://www.dailymail.co.uk/news/article-11714365/Kanye-Wests-2-2M-LA-Sunday-Service-HQ-left-Kim-Kardashian-looks-worse-wear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714365/Kanye-Wests-2-2M-LA-Sunday-Service-HQ-left-Kim-Kardashian-looks-worse-wear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 06:22:31+00:00
 - user: None

Kanye West's $2.2million Los Angeles ranch has deteriorated since he divorced his wife Kim Kardashian in November. He started to board up the property in September 2020.

## Common road rule about overtaking that could see a motorist hit with a $370 on-the-spot fine
 - [https://www.dailymail.co.uk/news/article-11714499/Common-road-rule-overtaking-motorist-hit-370-spot-fine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714499/Common-road-rule-overtaking-motorist-hit-370-spot-fine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 05:53:59+00:00
 - user: None

A common driving act that infuriates Australian motorists is actually against the law and those wo do it can be immediately fined.

## Canina high school boy Levi Hanna dies in hospital three days after he was hit by car
 - [https://www.dailymail.co.uk/news/article-11714523/Canina-high-school-boy-Levi-Hanna-dies-hospital-three-days-hit-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714523/Canina-high-school-boy-Levi-Hanna-dies-hospital-three-days-hit-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 05:43:57+00:00
 - user: None

Levi Hanna, 14, was hit by a Hyundai i30 on Tin Can Bay Rd at Canina, near Gympie, Queensland on Wednesday afternoon.

## Bargains galore at Sydney Airport lost property online auction, LAPTOPS, JEWELLERY among 3,000 items
 - [https://www.dailymail.co.uk/news/article-11714679/Bargains-galore-Sydney-Airport-lost-property-online-auction-LAPTOPS-JEWELLERY-3-000-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714679/Bargains-galore-Sydney-Airport-lost-property-online-auction-LAPTOPS-JEWELLERY-3-000-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 05:37:48+00:00
 - user: None

Thousands of items abandoned at Sydney Airport over the past year are up for grabs in an online auction, with bids starting at just $5 - and it's all for a good cause.

## West Pennant Hills fisherman tries to refill boat with fuel but makes costly mistake
 - [https://www.dailymail.co.uk/news/article-11714573/West-Pennant-Hills-fisherman-tries-refill-boat-fuel-makes-costly-mistake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714573/West-Pennant-Hills-fisherman-tries-refill-boat-fuel-makes-costly-mistake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 05:36:28+00:00
 - user: None

An absent-minded fisherman who set his 'fuel tank' to fill got the shock of his life to find he'd stuck the fuel nozzle in the rod holder, leading to an embarrassing and unforgettable servo gaffe.

## Oregon becomes America's first 'death tourism' destination for the terminally ill
 - [https://www.dailymail.co.uk/news/article-11706335/Oregon-Americas-death-tourism-destination-terminally-ill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11706335/Oregon-Americas-death-tourism-destination-terminally-ill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 05:32:19+00:00
 - user: None

Dr Nicholas Gideonse of Portland is already accepting out-of-state patients, despite the risk of prosecution, and even as politicians debate changes to Oregon's assisted-suicide law.

## FDNY cancels annual 'calendar of heroes' featuring hot New York firefighters after lukewarm sales
 - [https://www.dailymail.co.uk/news/article-11714589/FDNY-cancels-annual-calendar-heroes-featuring-hot-New-York-firefighters-lukewarm-sales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714589/FDNY-cancels-annual-calendar-heroes-featuring-hot-New-York-firefighters-lukewarm-sales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 05:22:57+00:00
 - user: None

t debuted in 2003 as an all-male calendar and remained that way until 2014 when women were added to the mix.

## US secures perimeter around spy balloon to stop China from reaching it first
 - [https://www.dailymail.co.uk/news/article-11713943/Fears-grow-China-reach-spy-balloon-wreckage-ahead-Navy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11713943/Fears-grow-China-reach-spy-balloon-wreckage-ahead-Navy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 05:19:01+00:00
 - user: None

US Navy and Coast Guard  ships are securing the perimeter off the coast of South Carolina where a fighter jet shot down a Chinese spy balloon, but a salvage vessel won't be on the scene for days.

## Three Chinese spy balloons infiltrated the US during Trump administration
 - [https://www.dailymail.co.uk/news/article-11714657/Three-Chinese-spy-balloons-infiltrated-Trump-administration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714657/Three-Chinese-spy-balloons-infiltrated-Trump-administration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 05:07:38+00:00
 - user: None

The Department of Defense reported that three Chinese spy balloons entered US airspace during the Trump administration, something that was not previously disclosed.

## Two men arrested in brutal beating of Ray's Candy Store owner, 90
 - [https://www.dailymail.co.uk/news/article-11714415/Two-men-arrested-brutal-beating-Rays-Candy-Store-owner-90.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714415/Two-men-arrested-brutal-beating-Rays-Candy-Store-owner-90.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 05:02:52+00:00
 - user: None

Luis Peroza, 39, and Gerald Barth, 55, were arrested on Saturday over the horrific attack that left Ray Alvarez with a black eye and eating through a straw after an attempted robbery at his store.

## NSW cop stole thousands of dollars from elderly lady who he was meant to help in $30,000 fraud case
 - [https://www.dailymail.co.uk/news/article-11714519/NSW-cop-stole-thousands-dollars-elderly-lady-meant-help-30-000-fraud-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714519/NSW-cop-stole-thousands-dollars-elderly-lady-meant-help-30-000-fraud-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 04:58:06+00:00
 - user: None

A New South Wales policeman who was meant to help to catch the criminals who stole $30,000 from an elderly woman instead also robbed her himself.

## Wallaby head is found impaled on a stick along Hubert Rivulet
 - [https://www.dailymail.co.uk/news/article-11714501/Wallaby-head-impaled-stick-Hubert-Rivulet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714501/Wallaby-head-impaled-stick-Hubert-Rivulet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 04:18:35+00:00
 - user: None

A shocked resident walking along the Hobart Rivulet park, which runs through the CBD, over the weekend stumbled onto the wallaby head and called authorities.

## Hungry Jacks Darwin ute passenger corned by police was subject of manhunt
 - [https://www.dailymail.co.uk/news/article-11714199/Hungry-Jacks-Darwin-ute-passenger-corned-police-subject-manhunt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714199/Hungry-Jacks-Darwin-ute-passenger-corned-police-subject-manhunt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 03:06:31+00:00
 - user: None

New allegations surrounding the passenger of a ute that was swarmed by heavily-armed plain clothes police last month in a Hungry Jacks driver-through say the man was the subject of a manhunt.

## ABC Alice Springs coverage: Ex-journalist and senator Sarah Henderson slams ABC over apology
 - [https://www.dailymail.co.uk/news/article-11714049/ABC-Alice-Springs-coverage-Ex-journalist-senator-Sarah-Henderson-slams-ABC-apology.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714049/ABC-Alice-Springs-coverage-Ex-journalist-senator-Sarah-Henderson-slams-ABC-apology.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:54:40+00:00
 - user: None

A former ABC presenter has rubbished the public broadcaster's apology over its 'biased' coverage of the Alice Springs crisis meeting and has reiterated her intention to file a complaint.

## Two children foiled an attempted abduction of a five-year-old boy in Darwin
 - [https://www.dailymail.co.uk/news/article-11714223/Two-children-foiled-attempted-abduction-five-year-old-boy-Darwin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714223/Two-children-foiled-attempted-abduction-five-year-old-boy-Darwin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:48:25+00:00
 - user: None

Two quick thinking children have been praised for their 'incredible actions' after seeing the alleged abduction of a five-year-old boy in a northern suburb of Darwin.

## How many of these Royal toddlers can YOU name?
 - [https://www.dailymail.co.uk/femail/article-11714301/How-Royal-toddlers-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11714301/How-Royal-toddlers-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:42:29+00:00
 - user: None

The Princess of Wales shared a new childhood image of herself with her father to promote her new early years campaign. But how many royal toddlers can you identify?

## Joe and Hunter Biden pay respects to the family of his late brother-in-law in Central New York
 - [https://www.dailymail.co.uk/news/article-11711799/Joe-Hunter-Biden-pay-respects-family-late-brother-law-Central-New-York.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11711799/Joe-Hunter-Biden-pay-respects-family-late-brother-law-Central-New-York.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:42:16+00:00
 - user: None

President Joe Biden traveled to Central New York on Saturday to spend time with his family following the passing of his brother-in-law, Michael Hunter.

## Head of US bishops brands Joe Biden a 'fake' Catholic warns religious leaders across country
 - [https://www.dailymail.co.uk/news/article-11714277/Head-bishops-brands-Joe-Biden-fake-Catholic-warns-religious-leaders-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714277/Head-bishops-brands-Joe-Biden-fake-Catholic-warns-religious-leaders-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:37:22+00:00
 - user: None

The Archbishop of the U.S. Conference of Catholic Bishops has taken to task Joe Biden's assertion some bishops are comfortable using taxpayer funds for abortion.

## WA shark attack: Swan River swimmer reveals final moments of girl before she was mauled to death
 - [https://www.dailymail.co.uk/news/article-11713801/WA-shark-attack-Swan-River-swimmer-reveals-final-moments-girl-mauled-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11713801/WA-shark-attack-Swan-River-swimmer-reveals-final-moments-girl-mauled-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:28:53+00:00
 - user: None

A witness to the tragic death of a teenage girl who was mauled to death by a shark says the terrifying attack was 'completely random' and happened abruptly.

## Police searching for aristocrat and sex offender boyfriend raise fears about their newborn baby
 - [https://www.dailymail.co.uk/news/article-11714351/Police-searching-aristocrat-sex-offender-boyfriend-raise-fears-newborn-baby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714351/Police-searching-aristocrat-sex-offender-boyfriend-raise-fears-newborn-baby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:14:15+00:00
 - user: None

Officers are increasingly concerned about the newborn, pleading with Constance Marten, 35, and Mark Gordon, 48, to let them know they are safe.

## Rest in Peeps: 'Father of Peeps' Bob Born dies age 98
 - [https://www.dailymail.co.uk/news/article-11714179/Rest-Peeps-Father-Peeps-Bob-Born-dies-age-98.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714179/Rest-Peeps-Father-Peeps-Bob-Born-dies-age-98.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:02:14+00:00
 - user: None

Ira 'Bob' Born died in his home in Conshohocken, Pennsylvania, on Sunday. He was known as the 'Father of Peeps' for creating the machinery to automate the marshmallow process.

## Sovereign citizen: Man is dragged out of Ballarat courthouse before he launches into bizarre rant
 - [https://www.dailymail.co.uk/news/article-11713795/Sovereign-citizen-dragged-Ballarat-courthouse-launches-bizarre-rant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11713795/Sovereign-citizen-dragged-Ballarat-courthouse-launches-bizarre-rant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:01:38+00:00
 - user: None

An Australian man has launched into a bizarre rant about why the authority of a court doesn't apply to him, while in the same moment complaining he is being denied his 'right to law'.

## Sex scientists accused of 'normalising' porn in 10,000-strong survey of people's private habits
 - [https://www.dailymail.co.uk/news/article-11714411/Sex-scientists-accused-normalising-porn-10-000-strong-survey-peoples-private-habits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714411/Sex-scientists-accused-normalising-porn-10-000-strong-survey-peoples-private-habits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 02:00:39+00:00
 - user: None

Researchers from University College London are dedicating a whole section to porn in the National Survey of Sexual Attitudes and Lifestyles (Natsal), carried out every decade.

## First Monday of February typically sees the highest number of Brits call in sick
 - [https://www.dailymail.co.uk/news/article-11714451/First-Monday-February-typically-sees-highest-number-Brits-call-sick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714451/First-Monday-February-typically-sees-highest-number-Brits-call-sick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:59:08+00:00
 - user: None

Tomorrow is National Sickie Day, the first Monday in February and the day of the year when British employees are statistically most likely to call in claiming to be under the weather.

## Steering wheel locks are flying off the shelves amid rise in thieves targeting modern, keyless cars
 - [https://www.dailymail.co.uk/news/article-11714417/Steering-wheel-locks-flying-shelves-amid-rise-thieves-targeting-modern-keyless-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714417/Steering-wheel-locks-flying-shelves-amid-rise-thieves-targeting-modern-keyless-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:54:10+00:00
 - user: None

Sales of steering wheel locks have risen 23 per cent in the last year as drivers try to stop criminals targeting their modern, keyless cars, according to leading motoring retailer Halfords.

## Massive $250 handout on offer to millions of Australians and their electricity bills
 - [https://www.dailymail.co.uk/news/article-11714111/Massive-250-handout-offer-millions-Australians-electricity-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714111/Massive-250-handout-offer-millions-Australians-electricity-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:51:20+00:00
 - user: None

Premier Dominic Perrottet unveiled the scheme as he campaigns ahead of the March NSW election, saying electricity companies would be forced to keep prices down to remain competitive.

## The Crown star Lesley Manville says she owes much of her success to her divorce
 - [https://www.dailymail.co.uk/news/article-11714409/The-Crown-star-Lesley-Manville-says-owes-success-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714409/The-Crown-star-Lesley-Manville-says-owes-success-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:50:49+00:00
 - user: None

66-year-old Lesley Manville was married to fellow star Gary Oldman, who walked out on her when their son Alfie was just three months old.

## Health Secretary Steve Barclay makes 11th hour appeal to union bosses
 - [https://www.dailymail.co.uk/news/article-11714419/Health-Secretary-Steve-Barclay-makes-11th-hour-appeal-union-bosses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714419/Health-Secretary-Steve-Barclay-makes-11th-hour-appeal-union-bosses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:50:09+00:00
 - user: None

Steve Barclay made an 11th-hour appeal to union bosses last night to 'call off the strikes'. Thousands of ambulance workers and nurses will take to picket lines across England tomorrow.

## ITV deletes Prince Andrew's ex attack on 'sex abuse' victim
 - [https://www.dailymail.co.uk/news/article-11714353/ITV-deletes-Prince-Andrews-ex-attack-sex-abuse-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714353/ITV-deletes-Prince-Andrews-ex-attack-sex-abuse-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:40:55+00:00
 - user: None

Lady Victoria Hervey (pictured), who dated Andrew in 1999, provoked outrage after branding Virginia Roberts a 'con-artist' and 'liar' during an inflamatory appearance on Good Morning Britain.

## The doggy bag is back: Diners in Britain are increasingly taking their restaurant leftovers home
 - [https://www.dailymail.co.uk/news/article-11714357/The-doggy-bag-Diners-Britain-increasingly-taking-restaurant-leftovers-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714357/The-doggy-bag-Diners-Britain-increasingly-taking-restaurant-leftovers-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:38:11+00:00
 - user: None

It was long shunned as a vulgar Americanism. But now increasing numbers of British diners are asking for doggy bags so they can take leftovers home, with high-end restaurants also happy to comply.

## Kate's Kensington 'shake-up': Princess of Wales hires new 'ball-breaker' PR guru
 - [https://www.dailymail.co.uk/news/article-11714193/Kates-Kensington-shake-Princess-Wales-hires-new-ball-breaker-PR-guru.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714193/Kates-Kensington-shake-Princess-Wales-hires-new-ball-breaker-PR-guru.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:33:21+00:00
 - user: None

Alison Corfield joins the royals as a veteran public relations expert to aid Kate as her right-hand woman. She takes over from her predecessor Hannah Cockburn-Logie (pictured with the Waleses)

## The Masked Singer: Daisy May Cooper and Claire Richards are unmasked in double elimination
 - [https://www.dailymail.co.uk/tvshowbiz/article-11713581/The-Masked-Singer-Daisy-Cooper-Claire-Richards-unmasked-double-elimination.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11713581/The-Masked-Singer-Daisy-Cooper-Claire-Richards-unmasked-double-elimination.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:32:05+00:00
 - user: None

It was a double elimination for the show, as both Daisy May Cooper and Claire Richards were revealed as Otter and Knitting.

## British Gas ignored watchdog's warnings about force-fitting pre-pay meters FIVE YEARS ago
 - [https://www.dailymail.co.uk/news/article-11714391/British-Gas-ignored-watchdogs-warnings-force-fitting-pre-pay-meters-FIVE-YEARS-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714391/British-Gas-ignored-watchdogs-warnings-force-fitting-pre-pay-meters-FIVE-YEARS-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:30:15+00:00
 - user: None

The energy giant is under fire after it emerged last week it had sent debt collectors to break into the homes of vulnerable customers who had fallen behind on bills.

## The facial recognition virus detector that could herald the end of intrusive Covid tests
 - [https://www.dailymail.co.uk/news/article-11714389/The-facial-recognition-virus-detector-herald-end-intrusive-Covid-tests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714389/The-facial-recognition-virus-detector-herald-end-intrusive-Covid-tests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:29:15+00:00
 - user: None

A series of tests has shown that the Pictura Bio invention can distinguish between the different viruses that cause Covid, flu and colds with 97 per cent accuracy.

## Report calls for a new focus on the threat end to 'false equivalence' with far-Right extremism
 - [https://www.dailymail.co.uk/news/article-11714405/Report-calls-new-focus-threat-end-false-equivalence-far-Right-extremism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714405/Report-calls-new-focus-threat-end-false-equivalence-far-Right-extremism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:27:28+00:00
 - user: None

A new report by William Shawcross will argue that tackling extremist ideology ought to take precedence over finding reasons to absolve terrorists of their crimes, it is understood.

## Starmer accused of 'rank hypocrisy' as comedian Shazia Mirza hosts major Labour diversity event
 - [https://www.dailymail.co.uk/news/article-11714377/Starmer-accused-rank-hypocrisy-comedian-Shazia-Mirza-hosts-major-Labour-diversity-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714377/Starmer-accused-rank-hypocrisy-comedian-Shazia-Mirza-hosts-major-Labour-diversity-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:19:38+00:00
 - user: None

Shazia Mirza was the compere at last week's Labour gala dinner to celebrate the South Asian community. But the performer has previously branded Sajid Javid and Priti Patel 'coconuts'

## Defector from Kremlin's most sinister militia The Wagner Group tells of frontline horrors in Ukraine
 - [https://www.dailymail.co.uk/news/article-11713961/Defector-Kremlins-sinister-militia-Wagner-Group-tells-frontline-horrors-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11713961/Defector-Kremlins-sinister-militia-Wagner-Group-tells-frontline-horrors-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:15:55+00:00
 - user: None

EXCLUSIVE: Andrey Medvedev is determined to blow the whistle on the group's atrocities and war crimes in Ukraine.

## Ministry of Defence spent £230MILLION on accommodation while soldiers endure appalling conditions
 - [https://www.dailymail.co.uk/news/article-11714285/Ministry-Defence-spent-230MILLION-accommodation-soldiers-endure-appalling-conditions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714285/Ministry-Defence-spent-230MILLION-accommodation-soldiers-endure-appalling-conditions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:12:02+00:00
 - user: None

The taxpayer-funded outlay includes hundreds of senior officers and officials staying in luxury hotels in exotic locations, documents obtained in a Freedom of Information (FoI) request reveal.

## Ellie Bamber rocks a striking £1,500 jacket after bagging role as Kate Moss in new biopic
 - [https://www.dailymail.co.uk/tvshowbiz/article-11714281/Ellie-Bamber-rocks-striking-1-500-jacket-bagging-role-Kate-Moss-new-biopic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11714281/Ellie-Bamber-rocks-striking-1-500-jacket-bagging-role-Kate-Moss-new-biopic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:11:39+00:00
 - user: None

Ellie Bamber, 26, will play Kate Moss in a new film. She looked striking on her birthday in a Barrie cashmere and cotton jacket worth £1,500, and emerald trousers

## Prince Harry served court papers by Meghan Markle's sister Samantha
 - [https://www.dailymail.co.uk/news/article-11714235/Prince-Harry-served-court-papers-Meghan-Markles-sister-Samantha.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714235/Prince-Harry-served-court-papers-Meghan-Markles-sister-Samantha.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:03:50+00:00
 - user: None

In legal papers filed in Florida on Friday, Ms Markle has called on the Duke of Sussex to take part in deposition proceedings under oath.

## Pioneering stem cell trial hopes to transform the lives of Parkinson's sufferers
 - [https://www.dailymail.co.uk/news/article-11714295/Pioneering-stem-cell-trial-hopes-transform-lives-Parkinsons-sufferers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714295/Pioneering-stem-cell-trial-hopes-transform-lives-Parkinsons-sufferers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 01:03:40+00:00
 - user: None

Their brains will be infused with millions of the cells in a trial aimed at demonstrating if the technique can slow, stop or even reverse the course of the devastating condition.

## Sea World helicopter crash survivors relive final moments before choppers collided on Gold Coast
 - [https://www.dailymail.co.uk/news/article-11713811/Sea-World-helicopter-crash-survivors-relive-final-moments-choppers-collided-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11713811/Sea-World-helicopter-crash-survivors-relive-final-moments-choppers-collided-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:54:42+00:00
 - user: None

Terrified, bloodied and in fear for her life, Gold Coast helicopter crash survivor Elmarie Steenberg recalled how she got through the terrifying moments before and after the fatal crash.

## Anthony Albanese accuses Voice critics of inciting 'culture war' - 'open to improving' proposal
 - [https://www.dailymail.co.uk/news/article-11714047/Anthony-Albanese-accuses-Voice-critics-inciting-culture-war-open-improving-proposal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714047/Anthony-Albanese-accuses-Voice-critics-inciting-culture-war-open-improving-proposal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:51:16+00:00
 - user: None

The Prime Minister is going on the front foot in his campaign for an Indigenous Voice to Parliament by accusing opponents of 'trying to start a culture war'.

## MAIL ON SUNDAY COMMENT: Radical Liz Truss ideas still have their value
 - [https://www.dailymail.co.uk/news/article-11714259/MAIL-SUNDAY-COMMENT-Radical-Liz-Truss-ideas-value.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714259/MAIL-SUNDAY-COMMENT-Radical-Liz-Truss-ideas-value.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:48:18+00:00
 - user: None

MAIL ON SUNDAY COMMENT: Many people will be more than a little surprised to find that Liz Truss is still contemplating some sort of political comeback.

## Eddie Redmayne forced to dismount during cycle to ask a passerby for directions in Notting Hill
 - [https://www.dailymail.co.uk/tvshowbiz/article-11714283/Eddie-Redmayne-forced-dismount-cycle-ask-passerby-directions-Notting-Hill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11714283/Eddie-Redmayne-forced-dismount-cycle-ask-passerby-directions-Notting-Hill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:47:58+00:00
 - user: None

London-born actor Eddie Redmayne (pictured) was spotted apparently asking for directions during a lunchtime cycle in the capital's Notting Hill area last Wednesday.

## Eat more chocolate, take more naps and gorge on dandelion leaves
 - [https://www.dailymail.co.uk/health/article-11713669/Eat-chocolate-naps-gorge-dandelion-leaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11713669/Eat-chocolate-naps-gorge-dandelion-leaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:47:00+00:00
 - user: None

In yesterday's Daily Mail, mind specialist Dr Richard Restak explored the importance of keeping memories alive in order to ward off the threat of dementia in old age.

## Zara Phillips's husband Mike Tindall rules out Strictly Come Dancing over 'Strictly Curse'
 - [https://www.dailymail.co.uk/tvshowbiz/article-11713953/Zara-Phillipss-husband-Mike-Tindall-rules-Strictly-Come-Dancing-Strictly-Curse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11713953/Zara-Phillipss-husband-Mike-Tindall-rules-Strictly-Come-Dancing-Strictly-Curse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:46:40+00:00
 - user: None

EMILY PRESCOTT: He braved the jungle in I'm A Celebrity but don't expect to see Mike Tindall (pictured with wife Zara Phillips) on the Strictly Come Dancing dancefloor any time soon.

## In her own words... watch Prince Harry's 'older woman' reveal how she took his virginity
 - [https://www.dailymail.co.uk/news/article-11714013/In-words-watch-Prince-Harrys-older-woman-reveal-took-virginity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714013/In-words-watch-Prince-Harrys-older-woman-reveal-took-virginity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:44:07+00:00
 - user: None

There have been weeks of speculation as to who the mystery 'older woman' could be, with big names including Liz Hurley forced to deny it was them.

## Missing Nicola Bulley's daughters attend clubs and a sleepover in bid to keep 'sense of routine'
 - [https://www.dailymail.co.uk/news/article-11714153/Missing-Nicola-Bulleys-daughters-attend-clubs-sleepover-bid-sense-routine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714153/Missing-Nicola-Bulleys-daughters-attend-clubs-sleepover-bid-sense-routine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:43:28+00:00
 - user: None

Everyone was trying their best yesterday to keep things as normal as possible for missing Nicola Bulley's daughters. Friends took the nine and six-year-old to their usual clubs after a sleepover.

## LIZ JONES: White van man was a lockdown hero. But now he's gone back to delivering total chaos
 - [https://www.dailymail.co.uk/columnists/article-11714275/LIZ-JONES-White-van-man-lockdown-hero-hes-gone-delivering-total-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/columnists/article-11714275/LIZ-JONES-White-van-man-lockdown-hero-hes-gone-delivering-total-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:32:19+00:00
 - user: None

We clapped for delivery drivers, along with health workers and the men who collect the recycling even if they sometimes manage to leave a few bottle tops, cardboard boxes and yogurt pots.

## Tamara Beckwith shares 'sheer outrage' after NatWest closed her business account without explanation
 - [https://www.dailymail.co.uk/news/article-11714205/Tamara-Beckwith-shares-sheer-outrage-NatWest-closed-business-account-without-explanation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714205/Tamara-Beckwith-shares-sheer-outrage-NatWest-closed-business-account-without-explanation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:31:49+00:00
 - user: None

Across all banks, complaints of closed business accounts are steadily rising each year, according to figures uncovered by The Mail on Sunday.

## Tory MPs urge Rishi Sunak to fill chairman role and get 'battle ready' as local elections loom
 - [https://www.dailymail.co.uk/news/article-11714221/Tory-MPs-urge-Rishi-Sunak-chairman-role-battle-ready-local-elections-loom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714221/Tory-MPs-urge-Rishi-Sunak-chairman-role-battle-ready-local-elections-loom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:21:26+00:00
 - user: None

There has been speculation that the chairman role will be difficult to fill with Labour 20 points ahead in the opinion polls and bruising local election results expected in May.

## Third Chinese spy balloon is 'operating near US interests' - but officials won't say where
 - [https://www.dailymail.co.uk/news/article-11713963/Third-Chinese-spy-balloon-operating-near-interests-officials-wont-say-where.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11713963/Third-Chinese-spy-balloon-operating-near-interests-officials-wont-say-where.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:20:40+00:00
 - user: None

An anonymous source said a third balloon is likely operating near the US, but did not reveal its location. The first balloon discovered in the US was shot down today at 2.30pm.

## King Charles and Queen Consort Camilla will sit on brand new thrones at the King's coronation
 - [https://www.dailymail.co.uk/news/article-11714213/King-Charles-Queen-Consort-Camilla-sit-brand-new-thrones-Kings-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714213/King-Charles-Queen-Consort-Camilla-sit-brand-new-thrones-Kings-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:12:56+00:00
 - user: None

Two thrones will be made for the coronation ceremony at Westminster Abbey. Each monarch also has a Throne Chair - unique to them - for the enthronement part of the ancient ritual

## 10 awkward questions you should throw at the next EU 'Rejoiner' who corners you at a dinner party
 - [https://www.dailymail.co.uk/columnists/article-11714171/10-awkward-questions-throw-EU-Rejoiner-corners-dinner-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/columnists/article-11714171/10-awkward-questions-throw-EU-Rejoiner-corners-dinner-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:08:51+00:00
 - user: None

Last week, on the third anniversary of our departure from the EU, a survey found that some 57 per cent of Britons were now in favour of rejoining. And little wonder!

## Latest phrases to be branded offensive due to their 'violent' undertones
 - [https://www.dailymail.co.uk/news/article-11714189/Latest-phrases-branded-offensive-violent-undertones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714189/Latest-phrases-branded-offensive-violent-undertones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:08:05+00:00
 - user: None

Instead, safer alternatives are suggested with, for example, 'that'll kill two birds with one stone' being replaced with 'that'll feed two birds with one scone'.

## New details emerge of Andrew 'Freddie' Flintoff  horror crash while filming BBC's Top Gear
 - [https://www.dailymail.co.uk/news/article-11714039/New-details-emerge-Andrew-Freddie-Flintoff-horror-crash-filming-BBCs-Gear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11714039/New-details-emerge-Andrew-Freddie-Flintoff-horror-crash-filming-BBCs-Gear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:06:01+00:00
 - user: None

The former England ace, 45, was airlifted to hospital with facial injuries and broken ribs following a collision at the Dunsfold Aerodrome in Surrey on December 13 last year.

## She's back! Barely four months after her disastrous stint as PM, Liz Truss has returned to the fray
 - [https://www.dailymail.co.uk/columnists/article-11714151/Shes-Barely-four-months-disastrous-stint-PM-Liz-Truss-returned-fray.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/columnists/article-11714151/Shes-Barely-four-months-disastrous-stint-PM-Liz-Truss-returned-fray.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-02-05 00:03:11+00:00
 - user: None

GLEN OWEN: The return of Liz Truss, after barely four months in political exile, prompts MPs who are loyal to Rishi Sunak to sink their heads into their hands.
