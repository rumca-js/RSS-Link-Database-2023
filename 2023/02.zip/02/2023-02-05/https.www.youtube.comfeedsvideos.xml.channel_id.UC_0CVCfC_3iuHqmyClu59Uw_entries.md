# Source ETA PRIME, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, Source language: en-US

## Nuc Box 9 First Look, A Fast Super Tiny Ryzen Powered 4K Mini PC
 - [https://www.youtube.com/watch?v=ZZUlhX44O10](https://www.youtube.com/watch?v=ZZUlhX44O10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-02-05 15:30:11+00:00
 - user: None

In this video, we take look at the new GMKtec Nuc Box 9 Ryzen-powered mini PC. We do an unboxing, run some benchmarks, Test some PC games in windows.

Buy It on Amazon: https://amzn.to/40yG8rs

15% OFF
Code:  DERA6J77
Period: Valid for a week when your video is up

Or Buy It Here:
https://www.gmktec.com/products/amd-ryzen%E2%84%A2-5-5600u-mini-pc-nucbox-9

$63 OFF
Code: ETA-KB9-$63OFF
Period: Valid for a week when your video is up

 
Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

00:00 Introduction
00:17 Nucbox 9 Unboxing
01:22 Overview
02:05 Specs
02:54 Overall Performance
03:39 Youtube 4K video Playback
04:12 Nucbox 9 benchmarks
04:49 Genshin Impact Test
05:02 MK11 Test
05:29 Forza Horizon 5 Test
05:59 Doom Eternal Test
06:24 Cyberpunk 2077 Test
06:49 God Of War Test
07:13 Spiderman Remastered Test
07:38 Power Consumption and CPU Temps

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME 
12520 Capital Blvd Ste 401 Number 108
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#ryzen #amd #minipc #etaprime
