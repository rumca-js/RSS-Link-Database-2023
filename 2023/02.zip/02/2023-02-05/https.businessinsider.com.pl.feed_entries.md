# Source Business insider, Source URL:https://businessinsider.com.pl/.feed, Source language: en-US

## Czarna prognoza: ceny ropy znów drastycznie wzrosną
 - [https://businessinsider.com.pl/gospodarka/czarna-prognoza-ceny-ropy-znow-drastycznie-wzrosna/dpjm12z](https://businessinsider.com.pl/gospodarka/czarna-prognoza-ceny-ropy-znow-drastycznie-wzrosna/dpjm12z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 15:34:35+00:00
 - user: None

Cena ropa wzrośnie w tym roku z powrotem powyżej 100 dol. za baryłkę. W 2024 r. może stanąć przed poważnym problemem związanym z podażą, bo wyczerpią się moce produkcyjne — ocenia Goldman Sachs, o czym w niedzielę pisze Bloomberg.

## Tysiące Polaków nie skorzystają z nowych urlopów. Przez opieszałość rządu
 - [https://businessinsider.com.pl/twoje-pieniadze/dodatkowe-urlopy-juz-wywoluja-burze-rodzice-czuja-sie-pokrzywdzeni/rglgg31](https://businessinsider.com.pl/twoje-pieniadze/dodatkowe-urlopy-juz-wywoluja-burze-rodzice-czuja-sie-pokrzywdzeni/rglgg31)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 15:01:20+00:00
 - user: None

Choć wejście w życie dyrektywy work-life balance może jeszcze potrwać, bo Sejm dopiero zaczął nad nią pracę, to już budzi ona kontrowersje. Opieszałość rządu sprawia, że blisko 100 tys. osób nie skorzysta z dodatkowych urlopów. Z kolei politycy opozycji dopatrują się w nowych przepisach dyskryminacji mężczyzn.

## Szalony miesiąc energetyki wiatrowej. Od rekordów prawie do zera
 - [https://businessinsider.com.pl/gospodarka/szalony-miesiac-energetyki-wiatrowej-od-rekordow-prawie-do-zera/bqzbk9n](https://businessinsider.com.pl/gospodarka/szalony-miesiac-energetyki-wiatrowej-od-rekordow-prawie-do-zera/bqzbk9n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 14:28:49+00:00
 - user: None

Powiedzieć, że energetyka wiatrowa jest niestabilna, to mało powiedzieć. Gdyby sama miała zapewniać całość energii w systemie, trzeba by nabudować ponad dwieście razy więcej wiatraków niż stoi obecnie. Wtedy zresztą byłby kłopot z potężnym nadmiarem energii w czasie, gdy już wieje. Tak wynika z danych styczniowych, kiedy wiatraki potrafiły dać ponad jedną trzecią prądu w systemie, a zdarzył się też dzień z zaledwie 0,4 proc.

## "Ludzie drugiej, a nawet trzeciej kategorii" w Niemczech. To też pracownicy z Polski
 - [https://businessinsider.com.pl/prawo/praca/ludzie-drugiej-a-nawet-trzeciej-kategorii-w-niemczech-to-tez-pracownicy-z-polski/c20qgmt](https://businessinsider.com.pl/prawo/praca/ludzie-drugiej-a-nawet-trzeciej-kategorii-w-niemczech-to-tez-pracownicy-z-polski/c20qgmt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 13:22:23+00:00
 - user: None

Pracownicy sezonowi z Europy Środkowej i Wschodniej traktowani są przez pracodawców w Niemczech jak ludzie drugiej kategorii — pisze niemiecki dziennik "Sueddeutsche Zeitung", który cytuje serwis dw.com.

## Urlop pełen słońca na Fuerteventurze. Pokoje z widokiem na ocean
 - [https://businessinsider.com.pl/lifestyle/podroze/urlop-pelen-slonca-na-fuerteventurze-pokoje-z-widokiem-na-ocean/zw7b54y](https://businessinsider.com.pl/lifestyle/podroze/urlop-pelen-slonca-na-fuerteventurze-pokoje-z-widokiem-na-ocean/zw7b54y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 13:17:00+00:00
 - user: None

Fuerteventura jest niewielką hiszpańską wyspą na Oceanie Atlantyckim. Należy do archipelagu Wysp Kanaryjskich i położona jest zaledwie 100 km od Afryki. Fuerteventurę charakteryzują rajskie plaże z drobnym jasnym piaskiem, malownicze wydmy, kaniony i kratery dawnych wulkanów. Wyspa jest rajem dla turystów ceniących relaks na plaży i sporty wodne. Średnia temperatura w lutym na wyspie to 19 stopni, a 29 dni to dni słoneczne (przypadające na miesiąc). W artykule polecamy sprawdzone hotele, które mają dostępne terminy, a jednocześnie są różnorodne pod względem standardu i ceny. Zapraszamy!

## Srogi mandat za nieodśnieżony chodnik. A co, jeśli śnieg spadnie w nocy?
 - [https://businessinsider.com.pl/srogi-mandat-za-nieodsniezony-chodnik-a-co-jesli-snieg-spadnie-w-nocy/nh13z99](https://businessinsider.com.pl/srogi-mandat-za-nieodsniezony-chodnik-a-co-jesli-snieg-spadnie-w-nocy/nh13z99)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 13:01:46+00:00
 - user: None

Mało kto lubi odśnieżać chodnik, jednak będąc właścicielami nieruchomości, musimy zadbać o przylegający do niej fragment drogi, przeznaczony dla pieszych. Za niedopełnienie obowiązków możemy otrzymać wysoki mandat. Jeśli z powodu naszego zaniedbania ktoś, idąc chodnikiem, poślizgnie się i odniesie uszczerbek na zdrowiu, sprawa może mieć swój finał w sądzie.

## Największa rewolucja w polskiej bankowości. Dwaj wizjonerzy spotkali się "w chmurach"
 - [https://businessinsider.com.pl/wiadomosci/rewolucja-w-polskiej-bankowosci-dwaj-wizjonerzy-spotkali-sie-w-chmurach/3cckhy6](https://businessinsider.com.pl/wiadomosci/rewolucja-w-polskiej-bankowosci-dwaj-wizjonerzy-spotkali-sie-w-chmurach/3cckhy6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 12:49:46+00:00
 - user: None

Minęły już niemal 22 lata od dnia, kiedy pierwszy w Polsce bank internetowy Inteligo zmienił oblicze krajowego rynku finansowego. Przejęty rok po powstaniu przez PKO BP, w portfolio firmy istnieje do dzisiaj, ale stopniowo jego usługi są wygaszane. Wkrótce Inteligo prawdopodobnie przestanie istnieć. Jak powstała firma, dzięki której dokonała się w Polsce bankowa rewolucja? Urodziła się "w chmurach" - dosłownie i w przenośni.

## Polska na szarym końcu w realizacji unijnego celu. Zostało mało czasu
 - [https://businessinsider.com.pl/gospodarka/zrodla-odnawialne-w-transporcie-polska-na-szarym-koncu-w-realizacji-unijnego-celu/9h4pbzk](https://businessinsider.com.pl/gospodarka/zrodla-odnawialne-w-transporcie-polska-na-szarym-koncu-w-realizacji-unijnego-celu/9h4pbzk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 12:11:00+00:00
 - user: None

Po Warszawie mają nie jeździć wkrótce najstarsze diesle i "benzyniaki". W Krakowie za półtora roku będzie obowiązywać strefa czystego transportu. Co więcej, rząd chce wypełniać kamienie milowe w KPO, a wśród nich jest podatek od emisyjności samochodu. Wygląda na to, że cały mainstream polityczny chce nas zmotywować do przechodzenia na nowsze, mniej emisyjne auta. To skutek niedomagań Polski w wypełnianiu unijnych limitów. Jesteśmy trzeci od końca, jeśli chodzi o udział transportu napędzanego odnawialnymi źródłami energii.

## Na ferie koleją? Zmieniły się nie tylko ceny biletów. To warto wiedzieć
 - [https://businessinsider.com.pl/twoje-pieniadze/na-ferie-koleja-zmienily-sie-nie-tylko-ceny-biletow-to-warto-wiedziec/8lejqqd](https://businessinsider.com.pl/twoje-pieniadze/na-ferie-koleja-zmienily-sie-nie-tylko-ceny-biletow-to-warto-wiedziec/8lejqqd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 11:30:05+00:00
 - user: None

Początek roku na kolei jest gorący. 16 stycznia zaczęły się ferie, a od 11 stycznia obowiązuje nowy cennik, za sprawą którego bilety na pociągi Pendolino i EIC podrożały o ponad 17 proc., a TLK/IC o blisko 12 proc. Rządzący przyznają, że wzrosty cen były zbyt drastyczne i zapowiadają wycofanie się z tych podwyżek. Z kolei z początkiem lutego działać przestała aplikacja IC Mobile Navigator, którą zastąpiła nowa — PKP Intercity. Równolegle do niej powstała PKP.appka, której funkcjonalność wykracza daleko poza zakup biletów.

## Już wkrótce autozapis do PPK. Kogo dotyczy i co trzeba zrobić, jeśli nie chce być się w programie?
 - [https://businessinsider.com.pl/twoje-pieniadze/niedlugo-wszyscy-znow-beda-zapisani-do-ppk-tyle-mozna-zyskac/hgsmpm8](https://businessinsider.com.pl/twoje-pieniadze/niedlugo-wszyscy-znow-beda-zapisani-do-ppk-tyle-mozna-zyskac/hgsmpm8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 10:25:12+00:00
 - user: None

W 2023 r. czeka nas pierwszy autozapis do PPK. To oznacza, że pracodawca z automatu wpisze każdego pracownika w wieku 18-55 lat do Pracowniczych Planów Kapitałowych i nie musi mieć na to żadnej zgody.

## Wychował córkę w 18-metrowym domku. Teraz go sprzedaje, żeby miała wreszcie swój pokój
 - [https://businessinsider.com.pl/wiadomosci/wychowal-dziecko-w-18-m-domku-teraz-go-sprzedaje-bo-corka-potrzebuje-pokoju/b5rete2](https://businessinsider.com.pl/wiadomosci/wychowal-dziecko-w-18-m-domku-teraz-go-sprzedaje-bo-corka-potrzebuje-pokoju/b5rete2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 09:45:00+00:00
 - user: None

Ojciec wychowywał córkę w malutkim domu na farmie w Tennessee. Teraz sprzedaje go za 69 500 dol., aby mogła mieć więcej przestrzeni jako nastolatka.

## Ustawa zakazująca wjazdu diesli pełna absurdów. "Spod prawa wyjęte są pojazdy, które nie powinny rzucać się w oczy"
 - [https://businessinsider.com.pl/technologie/motoryzacja/wkrotce-stary-diesel-z-zakazem-w-wielu-miastach-ekspert-wskazuje-na-absurd/hqp9mhm](https://businessinsider.com.pl/technologie/motoryzacja/wkrotce-stary-diesel-z-zakazem-w-wielu-miastach-ekspert-wskazuje-na-absurd/hqp9mhm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 09:38:33+00:00
 - user: None

Warszawa i Kraków już wkrótce wprowadzą strefy czystego transportu, do których wjazd najstarszymi samochodami, zwłaszcza z silnikiem diesla, będzie zakazany. A to dopiero początek – zgodnie z unijnymi wymogami, kierowcy najbardziej kopcących aut nie wjadą również do centrów nawet średniej wielkości miast. I to już niedługo. Eksperci wskazują jednak na absurdy obecnych rozwiązań.

## Będzie bariera elektroniczna na granicy z Rosją. Budowa rusza już niedługo
 - [https://businessinsider.com.pl/wiadomosci/bariera-elektroniczna-na-granicy-z-rosja-budowa-rusza-juz-niedlugo/symq5sk](https://businessinsider.com.pl/wiadomosci/bariera-elektroniczna-na-granicy-z-rosja-budowa-rusza-juz-niedlugo/symq5sk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 08:55:12+00:00
 - user: None

Budowa bariery elektronicznej na granicy z obwodem kaliningradzkim powinna się rozpocząć w marcu — poinformowała por. Straży Granicznej Anna Michalska z Komendy Głównej SG. System elektroniczny na odcinku z obwodem kaliningradzkim będzie przebiegał na ok. 200 km granicy lądowej.

## Co dalej z wiekiem emerytalnym? Polacy mają jasne zdanie
 - [https://businessinsider.com.pl/twoje-pieniadze/emerytury/wiek-emerytalny-w-polsce-co-sadza-polacy-sondaz/4leelq8](https://businessinsider.com.pl/twoje-pieniadze/emerytury/wiek-emerytalny-w-polsce-co-sadza-polacy-sondaz/4leelq8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 08:31:42+00:00
 - user: None

41,4 proc. ankietowanych w sondażu SW Research dla "Rzeczpospolitej" opowiedziało się za zachowaniem obecnego wieku emerytalnego. 26,8 proc. było zdania, że korzystniejsze jest dla nich podniesienie wieku emerytalnego, co wiąże się z otrzymaniem wyższej emerytury.

## Trzy wskazówki, jak szukać pracy od dyrektorki z LinkedIn
 - [https://businessinsider.com.pl/twoje-pieniadze/praca/trzy-wskazowki-jak-szukac-pracy-od-dyrektorki-z-linkedin/gv30ne0](https://businessinsider.com.pl/twoje-pieniadze/praca/trzy-wskazowki-jak-szukac-pracy-od-dyrektorki-z-linkedin/gv30ne0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 08:03:00+00:00
 - user: None

Monica Lewis jest starszą dyrektorką ds. zarządzania produktem w serwisie LinkedIn. Często jest proszona o porady dotyczące zdobycia pracy, zwłaszcza teraz, gdy w wielu branżach, takich jak nieruchomości, technologie i handel detaliczny, panuje niepewność ekonomiczna. Oto jej wskazówki.

## To on stworzył firmę od thermomixa. Oto "niemiecki geniusz" Adolf Vorwerk
 - [https://businessinsider.com.pl/gospodarka/stworzyl-firme-od-thermomixa-oto-niemiecki-geniusz-adolf-vorwerk/3n8vz40](https://businessinsider.com.pl/gospodarka/stworzyl-firme-od-thermomixa-oto-niemiecki-geniusz-adolf-vorwerk/3n8vz40)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 07:58:00+00:00
 - user: None

Robot kuchenny Thermomix dla jednych jest cudownym rozwiązaniem, dla innych – zbędnym i zbyt drogim gadżetem. Na pewno jednak urządzenie odniosło gigantyczny sukces i stało się marką samą w sobie. Znacznie bardziej rozpoznawalną niż sama firma Vorwerk, która za nim stoi. Warto poznać jej historię – to opowieść o uporze, innowacjach, ale i o rodzinnych sporach.

## Rządzą ropą od czasów Rockefellera, a na wojnie zbijają fortunę. "Exxon zarobił więcej niż Bóg"
 - [https://businessinsider.com.pl/firmy/rockefeller-powraca-wojna-putina-i-droga-ropa-daly-miliardy-gigantom-z-usa/z5k2tcp](https://businessinsider.com.pl/firmy/rockefeller-powraca-wojna-putina-i-droga-ropa-daly-miliardy-gigantom-z-usa/z5k2tcp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-02-05 07:57:00+00:00
 - user: None

— Exxon zarobił w tym roku więcej pieniędzy niż Bóg – przyznawał w czerwcu zirytowany prezydent USA Joe Biden. Imperium stworzone przez legendarnego Johna Rockefellera przed blisko 150 laty wciąż ma się dobrze. ExxonMobil i Chevron, czyli firmy oskarżane o monopolizację, niszczenie klimatu, interesy z Putinem i łamanie praw człowieka, właśnie chwalą się rekordowymi zyskami dzięki wojnie i zawirowaniom na rynku ropy. "Big oil" znów spadł na cztery łapy. Jak to się stało?
