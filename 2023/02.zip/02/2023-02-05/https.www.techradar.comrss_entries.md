# Source Techradar, Source URL:https://www.techradar.com/rss, Source language: en-US

## Here's how ChatGPT could look as part of Microsoft Bing
 - [https://www.techradar.com/news/heres-how-chatgpt-could-look-as-part-of-microsoft-bing](https://www.techradar.com/news/heres-how-chatgpt-could-look-as-part-of-microsoft-bing)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-02-05 14:30:08+00:00
 - user: None

We've got leaked screenshots of how ChatGPT looks in Bing, and it could change the way we interact with the web.

## China reveals huge blockchain cluster that could be a taste of our dystopian future
 - [https://www.techradar.com/news/china-reveals-huge-blockchain-cluster-that-could-be-a-taste-of-the-dystopian-future-to-come](https://www.techradar.com/news/china-reveals-huge-blockchain-cluster-that-could-be-a-taste-of-the-dystopian-future-to-come)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-02-05 12:21:18+00:00
 - user: None

A thousand servers have formed a cluster in Beijing, capable of processing 240 million smart contract transactions a second.

## Don't make the same mistake I did with an expensive 4K laser projector
 - [https://www.techradar.com/news/dont-make-the-same-mistake-i-did-with-an-expensive-4k-laser-projector](https://www.techradar.com/news/dont-make-the-same-mistake-i-did-with-an-expensive-4k-laser-projector)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-02-05 12:00:35+00:00
 - user: None

Don't do what I did and get a 4K laser projector only to realize it has no internal speakers, rendering your setup useless.

## Original, unopened iPhone 1 from 2007 could fetch $50,000 at auction
 - [https://www.techradar.com/news/original-unopened-iphone-1-from-2007-could-fetch-dollar50000-at-auction](https://www.techradar.com/news/original-unopened-iphone-1-from-2007-could-fetch-dollar50000-at-auction)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-02-05 10:30:09+00:00
 - user: None

The auction price of a still-sealed iPhone continues to rise, and it's only going to become more appealing to collectors.
