# Source The Wall Street - Tech, Source URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, Source language: en-US

## Judge Releases Decision Approving Meta's Virtual-Reality Deal
 - [https://www.wsj.com/articles/judge-releases-decision-approving-metas-virtual-reality-deal-11675624589?mod=rss_Technology](https://www.wsj.com/articles/judge-releases-decision-approving-metas-virtual-reality-deal-11675624589?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-02-05 19:16:00+00:00
 - user: None

The unsealed ruling lays out the FTC’s loss of its bid to block the Facebook parent company’s acquisition.

## How to Reduce Your Email Mess and Stress
 - [https://www.wsj.com/articles/your-inbox-runneth-over-how-to-reduce-email-mess-and-stress-11675610344?mod=rss_Technology](https://www.wsj.com/articles/your-inbox-runneth-over-how-to-reduce-email-mess-and-stress-11675610344?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-02-05 15:19:00+00:00
 - user: None

Heed these productivity-boosting tech tips for Gmail and Outlook users.

## Sam Bankman-Fried's Psychiatrist Became Key Player at FTX
 - [https://www.wsj.com/articles/how-sam-bankman-frieds-psychiatrist-became-a-key-player-at-crypto-exchange-ftx-11675605200?mod=rss_Technology](https://www.wsj.com/articles/how-sam-bankman-frieds-psychiatrist-became-a-key-player-at-crypto-exchange-ftx-11675605200?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-02-05 15:00:00+00:00
 - user: None

Hired as a coach at the crypto exchange, George Lerner was there for its dramatic downfall.

## When Does Elon Musk Sleep? Billionaire Speaks of Limits to Fixing Twitter and His Back Pain
 - [https://www.wsj.com/articles/when-does-elon-musk-sleep-billionaire-speaks-of-limits-to-fixing-twitter-and-his-back-pain-11675604800?mod=rss_Technology](https://www.wsj.com/articles/when-does-elon-musk-sleep-billionaire-speaks-of-limits-to-fixing-twitter-and-his-back-pain-11675604800?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-02-05 14:00:00+00:00
 - user: None

At Tesla trial and in tweets, the executive gives a glimpse into his personal challenges.
