# Source Wydarzenia Interia, Source URL:https://wydarzenia.interia.pl/feed, Source language: pl-PL

## Zełenski ogłosił ukraińskie sankcje wobec rosyjskiego sektora atomowego
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-oglosil-ukrainskie-sankcje-wobec-rosyjskiego-sektor,nId,6579146](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-oglosil-ukrainskie-sankcje-wobec-rosyjskiego-sektor,nId,6579146)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 21:44:44+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-oglosil-ukrainskie-sankcje-wobec-rosyjskiego-sektor,nId,6579146"><img align="left" alt="Zełenski ogłosił ukraińskie sankcje wobec rosyjskiego sektora atomowego" src="https://i.iplsc.com/zelenski-oglosil-ukrainskie-sankcje-wobec-rosyjskiego-sektor/000ERO1GH5B73RLP-C321.jpg" /></a>Ukraina wprowadziła sankcje wobec rosyjskiego sektora atomowego - powiadomił w niedzielę prezydent Wołodymyr Zełenski. Władze w Kijowie zwróciły się też do firm sponsorujących igrzyska olimpijskie, by nie dopuścić do udziału w imprezie rosyjskich sportowców. Mówiąc o sytuacji na froncie, Zełenski przyznał, że sytuacja jest trudna, zwłaszcza w obwodzie donieckim, gdzie toczą się zacięte walki.
</p><br clear="all" />

## Zełenski: Rosjanie nie powinni uczestniczyć w olimpiadzie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-rosjanie-nie-powinni-uczestniczyc-w-olimpiadzie,nId,6579146](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-rosjanie-nie-powinni-uczestniczyc-w-olimpiadzie,nId,6579146)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 21:44:44+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-rosjanie-nie-powinni-uczestniczyc-w-olimpiadzie,nId,6579146"><img align="left" alt="Zełenski: Rosjanie nie powinni uczestniczyć w olimpiadzie" src="https://i.iplsc.com/zelenski-rosjanie-nie-powinni-uczestniczyc-w-olimpiadzie/000ERO1GH5B73RLP-C321.jpg" /></a>Ukraina wprowadziła sankcje wobec rosyjskiego sektora atomowego - powiadomił w niedzielę prezydent Wołodymyr Zełenski. Władze w Kijowie zwróciły się też do firm sponsorujących igrzyska olimpijskie, by nie dopuścić do udziału w imprezie rosyjskich sportowców. Mówiąc o sytuacji na froncie, Zełenski przyznał, że sytuacja jest trudna, zwłaszcza w obwodzie donieckim, gdzie toczą się zacięte walki.
</p><br clear="all" />

## Ukraina: Rosjanie atakują na pięciu kierunkach
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-rosjanie-atakuja-na-pieciu-kierunkach,nId,6579135](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-rosjanie-atakuja-na-pieciu-kierunkach,nId,6579135)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 20:49:44+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-rosjanie-atakuja-na-pieciu-kierunkach,nId,6579135"><img align="left" alt="Ukraina: Rosjanie atakują na pięciu kierunkach" src="https://i.iplsc.com/ukraina-rosjanie-atakuja-na-pieciu-kierunkach/000GPW8T2JJ1JPVC-C321.jpg" /></a>Wojska rosyjskie podejmują działania ofensywne na pięciu kierunkach na wschodzie Ukrainy - powiadomił w niedzielę wieczorem Sztab Generalny Sił Zbrojnych Ukrainy. W Tokmaku w obwodzie zaporoskim okupanci wysiedlają mieszkańców; do domów wprowadzają się kolaboranci. Wcześniej podano informację o ostrzale Charkowa, w którym zostało rannych czterech cywilów.</p><br clear="all" />

## Kyryło Budanow ma być nowym ministrem obrony Ukrainy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kyrylo-budanow-ma-byc-nowym-ministrem-obrony-ukrainy,nId,6579132](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kyrylo-budanow-ma-byc-nowym-ministrem-obrony-ukrainy,nId,6579132)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 20:25:29+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kyrylo-budanow-ma-byc-nowym-ministrem-obrony-ukrainy,nId,6579132"><img align="left" alt="Kyryło Budanow ma być nowym ministrem obrony Ukrainy" src="https://i.iplsc.com/kyrylo-budanow-ma-byc-nowym-ministrem-obrony-ukrainy/000GPW40DN70HDF1-C321.jpg" /></a>Kyryło Budanow zostanie nowym ministrem obrony Ukrainy - poinformowała agencja Reutera, powołując się na ukraińskie władze. Budanow był do tej pory szefem ukraińskiego wywiadu wojskowego (HUR). Nie przekazano, kiedy ruch ten zostanie sformalizowany. </p><br clear="all" />

## Wywróciła się łódź z migrantami. Nie żyje kobieta i troje dzieci
 - [https://wydarzenia.interia.pl/zagranica/news-wywrocila-sie-lodz-z-migrantami-nie-zyje-kobieta-i-troje-dzi,nId,6579123](https://wydarzenia.interia.pl/zagranica/news-wywrocila-sie-lodz-z-migrantami-nie-zyje-kobieta-i-troje-dzi,nId,6579123)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 19:57:06+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wywrocila-sie-lodz-z-migrantami-nie-zyje-kobieta-i-troje-dzi,nId,6579123"><img align="left" alt="Wywróciła się łódź z migrantami. Nie żyje kobieta i troje dzieci" src="https://i.iplsc.com/wywrocila-sie-lodz-z-migrantami-nie-zyje-kobieta-i-troje-dzi/000GPVW0WY4NWOOE-C321.jpg" /></a>Cztery osoby, w tym troje dzieci, poniosły śmierć w niedzielę w wyniku wypadku łodzi z migrantami, która zatonęła u wybrzeży greckiej wyspy Leros na południowym wschodzie Morza Egejskiego - poinformowała straż przybrzeżna Grecji. Udało się uratować 39 osób.</p><br clear="all" />

## Pożary lasów w Chile. Zginęły co najmniej 23 osoby
 - [https://wydarzenia.interia.pl/zagranica/news-pozary-lasow-w-chile-zginely-co-najmniej-23-osoby,nId,6579077](https://wydarzenia.interia.pl/zagranica/news-pozary-lasow-w-chile-zginely-co-najmniej-23-osoby,nId,6579077)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 19:40:45+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pozary-lasow-w-chile-zginely-co-najmniej-23-osoby,nId,6579077"><img align="left" alt="Pożary lasów w Chile. Zginęły co najmniej 23 osoby" src="https://i.iplsc.com/pozary-lasow-w-chile-zginely-co-najmniej-23-osoby/000GPUZXQFYM5W5X-C321.jpg" /></a>Chile zmaga się ze sporymi pożarami lasów. W akcji gaśniczej i zatrzymania rozprzestrzeniania się ognia nie pomagają wysokie temperatury, które sięgają 40 stopni Celsjusza. Żywioł przyczynił się do śmierci co najmniej 23 osób, zniszczył 800 domów. W trzech regionach obowiązuje stan wyjątkowy.</p><br clear="all" />

## Zniszczył nagrobek teściowej. Płyta nagrobna przygniotła mu nogę
 - [https://wydarzenia.interia.pl/lodzkie/news-zniszczyl-nagrobek-tesciowej-plyta-nagrobna-przygniotla-mu-n,nId,6579115](https://wydarzenia.interia.pl/lodzkie/news-zniszczyl-nagrobek-tesciowej-plyta-nagrobna-przygniotla-mu-n,nId,6579115)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 19:06:12+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-zniszczyl-nagrobek-tesciowej-plyta-nagrobna-przygniotla-mu-n,nId,6579115"><img align="left" alt="Zniszczył nagrobek teściowej. Płyta nagrobna przygniotła mu nogę" src="https://i.iplsc.com/zniszczyl-nagrobek-tesciowej-plyta-nagrobna-przygniotla-mu-n/000GEXV5EA77ECKU-C321.jpg" /></a>40-letni mężczyzna, będąc pod wpływem alkoholu, zniszczył nagrobek należący do jego teściowej. W trakcie aktu wandalizmu spadła na niego płyta nagrobna, która przygniotła mu nogę. Na miejsce wezwano służby, a po udzieleniu pomocy, mężczyzna trafił w ręce policjantów.</p><br clear="all" />

## Porozumienie zdecydowało o połączeniu z AgroUnią
 - [https://wydarzenia.interia.pl/kraj/news-porozumienie-zdecydowalo-o-polaczeniu-z-agrounia,nId,6579108](https://wydarzenia.interia.pl/kraj/news-porozumienie-zdecydowalo-o-polaczeniu-z-agrounia,nId,6579108)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 18:50:07+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-porozumienie-zdecydowalo-o-polaczeniu-z-agrounia,nId,6579108"><img align="left" alt="Porozumienie zdecydowało o połączeniu z AgroUnią" src="https://i.iplsc.com/porozumienie-zdecydowalo-o-polaczeniu-z-agrounia/000GPVQA2SV2N2CL-C321.jpg" /></a>Jak ustaliła Interia, na niedzielnym posiedzeniu zarządu Porozumienia zdecydowano o połączeniu z AgroUnią w jedno ugrupowanie. Za głosowało 17 osób, siedem było przeciw, a cztery się wstrzymały. </p><br clear="all" />

## Papież "jest gotowy na spotkanie z prezydentami Rosji i Ukrainy"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-papiez-jest-gotowy-na-spotkanie-z-prezydentami-rosji-i-ukrai,nId,6579093](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-papiez-jest-gotowy-na-spotkanie-z-prezydentami-rosji-i-ukrai,nId,6579093)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 18:16:03+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-papiez-jest-gotowy-na-spotkanie-z-prezydentami-rosji-i-ukrai,nId,6579093"><img align="left" alt="Papież &quot;jest gotowy na spotkanie z prezydentami Rosji i Ukrainy&quot;" src="https://i.iplsc.com/papiez-jest-gotowy-na-spotkanie-z-prezydentami-rosji-i-ukrai/000FJC1MT7J41RUV-C321.jpg" /></a>- Jestem gotów spotkać się z prezydentami Ukrainy i Rosji Wołodymyrem Zełenskim i Władimirem Putinem - powiedział w rozmowie z dziennikarzami papież Franciszek. Wyjaśnił, że nie pojechał dotąd do Kijowa, ponieważ nie ma możliwości udania się również do Moskwy. Później dodał, że wojna w Ukrainie &quot;nie jest jedyną wojną&quot;, wskazując na Syrię, Jemen czy konflikt w Birmie.</p><br clear="all" />

## Łukasz Warzecha odpowiada Piotrowi Zarembie
 - [https://wydarzenia.interia.pl/kraj/news-lukasz-warzecha-odpowiada-piotrowi-zarembie,nId,6579100](https://wydarzenia.interia.pl/kraj/news-lukasz-warzecha-odpowiada-piotrowi-zarembie,nId,6579100)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 18:15:03+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-lukasz-warzecha-odpowiada-piotrowi-zarembie,nId,6579100"><img align="left" alt="Łukasz Warzecha odpowiada Piotrowi Zarembie" src="https://i.iplsc.com/lukasz-warzecha-odpowiada-piotrowi-zarembie/000GPVK3SRKIVUOU-C321.jpg" /></a>Nie przypominam sobie, abyśmy w naszym tygodniku wykazywali &quot;bezsens wsparcia wojskowego dla Ukrainy&quot; lub &quot;przebąkiwali o winie Ameryki&quot; - pisze Łukasz Warzecha w odpowiedzi na felieton Piotra Zaremby.</p><br clear="all" />

## Ekstremalnie w Tatrach. Poruszający apel córki zmarłego ratownika
 - [https://wydarzenia.interia.pl/malopolskie/news-ekstremalnie-w-tatrach-poruszajacy-apel-corki-zmarlego-ratow,nId,6579079](https://wydarzenia.interia.pl/malopolskie/news-ekstremalnie-w-tatrach-poruszajacy-apel-corki-zmarlego-ratow,nId,6579079)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 17:27:14+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-ekstremalnie-w-tatrach-poruszajacy-apel-corki-zmarlego-ratow,nId,6579079"><img align="left" alt="Ekstremalnie w Tatrach. Poruszający apel córki zmarłego ratownika" src="https://i.iplsc.com/ekstremalnie-w-tatrach-poruszajacy-apel-corki-zmarlego-ratow/000GPV6LIYAIQ7SF-C321.jpg" /></a>W niedzielę w Tatrach panują bardzo trudne warunki, na Kasprowym Wierchu było nawet 180 centymetrów śniegu. W Zakopanem warstwa &quot;białego puchu&quot; sięga ponad 80 centymetrów. TOPR zdecydował o zamknięciu szlaków narciarskich i turystycznych i apeluje do turystów: zrezygnujcie z wypraw. &quot;Jesteś samobójcą? Śmiało - idź. Ale nie powinieneś liczyć, że ktoś po ciebie przyjdzie&quot; - pisze w poruszającym apelu córka ratownika TOPR, który zginął podczas akcji ratunkowej.</p><br clear="all" />

## Pogrzeb Szewacha Weissa. Andrzej Duda: "Dziękuję za odwagę i życzliwość"
 - [https://wydarzenia.interia.pl/kraj/news-pogrzeb-szewacha-weissa-andrzej-duda-dziekuje-za-odwage-i-zy,nId,6579085](https://wydarzenia.interia.pl/kraj/news-pogrzeb-szewacha-weissa-andrzej-duda-dziekuje-za-odwage-i-zy,nId,6579085)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 17:25:39+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogrzeb-szewacha-weissa-andrzej-duda-dziekuje-za-odwage-i-zy,nId,6579085"><img align="left" alt="Pogrzeb Szewacha Weissa. Andrzej Duda: &quot;Dziękuję za odwagę i życzliwość&quot;" src="https://i.iplsc.com/pogrzeb-szewacha-weissa-andrzej-duda-dziekuje-za-odwage-i-zy/000GPVBKP0RV3V54-C321.jpg" /></a>Żegnamy dziś wybitnego męża stanu i wspaniałego człowieka; w imieniu mojego narodu dziękuję za wszystko, co Szewach Weiss uczynił dla rozwijania polsko–izraelskiej przyjaźni, dialogu i współpracy - podkreślił prezydent Andrzej Duda w liście przekazanym uczestnikom uroczystości pogrzebowych w Jerozolimie. Szewach Weiss zmarł w piątek w wieku 87 lat. W niedzielę został pochowany na cmentarzu na Wzgórzu Herzla w Kwaterze Wielkich Narodu przeznaczonej dla przywódców państwowych i osób szczególnie zasłużonych.</p><br clear="all" />

## Ukraińskie władze: Rosja szykuje się do ofensywy. Jesteśmy gotowi
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainskie-wladze-rosja-szykuje-sie-do-ofensywy-jestesmy-got,nId,6579064](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainskie-wladze-rosja-szykuje-sie-do-ofensywy-jestesmy-got,nId,6579064)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 16:30:43+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainskie-wladze-rosja-szykuje-sie-do-ofensywy-jestesmy-got,nId,6579064"><img align="left" alt="Ukraińskie władze: Rosja szykuje się do ofensywy. Jesteśmy gotowi" src="https://i.iplsc.com/ukrainskie-wladze-rosja-szykuje-sie-do-ofensywy-jestesmy-got/000F2NPUHX9EBDYO-C321.jpg" /></a>Władze Ukrainy spodziewają się, że w lutym może dojść do ofensywy wojsk rosyjskich, bo &quot;oni lubią symbole&quot;, a 24 lutego minie rok od rozpoczęcia pełnoskalowej rosyjskiej inwazji - oświadczył w niedzielę minister obrony Ukrainy Ołeksij Reznikow. Armia ukraińska &quot;jest gotowa&quot; – zapewnił. Kilka dni temu, eksperci z amerykańskiego Instytutu Studiów na Wojną wskazywali, że  &quot;decydująca operacja ofensywna będzie przeprowadzona w obwodach donieckim i ługańskim&quot;.</p><br clear="all" />

## Lecieli do Zanzibaru. Samolot zawrócił do Warszawy z powodu usterki
 - [https://wydarzenia.interia.pl/kraj/news-lecieli-do-zanzibaru-samolot-zawrocil-do-warszawy-z-powodu-u,nId,6579066](https://wydarzenia.interia.pl/kraj/news-lecieli-do-zanzibaru-samolot-zawrocil-do-warszawy-z-powodu-u,nId,6579066)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 16:13:02+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-lecieli-do-zanzibaru-samolot-zawrocil-do-warszawy-z-powodu-u,nId,6579066"><img align="left" alt="Lecieli do Zanzibaru. Samolot zawrócił do Warszawy z powodu usterki " src="https://i.iplsc.com/lecieli-do-zanzibaru-samolot-zawrocil-do-warszawy-z-powodu-u/000GPUXDJD98BVK5-C321.jpg" /></a>Dreamliner PLL LOT, który w niedzielę wyleciał z Lotniska Chopina do Zanzibaru, został zawrócony na Lotnisko w Warszawie - poinformował rzecznik LOT Krzysztof Moczulski. Powodem była usterka wskazania instalacji przeciwoblodzeniowej. Rzecznik dodał, że po jej usunięciu samolot kontynuuje rejs do Zanzibaru. </p><br clear="all" />

## Iran: Z okazji rocznicy rewolucji islamskiej ułaskawiono tysiące więźniów
 - [https://wydarzenia.interia.pl/zagranica/news-iran-z-okazji-rocznicy-rewolucji-islamskiej-ulaskawiono-tysi,nId,6579049](https://wydarzenia.interia.pl/zagranica/news-iran-z-okazji-rocznicy-rewolucji-islamskiej-ulaskawiono-tysi,nId,6579049)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 15:51:25+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-iran-z-okazji-rocznicy-rewolucji-islamskiej-ulaskawiono-tysi,nId,6579049"><img align="left" alt="Iran: Z okazji rocznicy rewolucji islamskiej ułaskawiono tysiące więźniów" src="https://i.iplsc.com/iran-z-okazji-rocznicy-rewolucji-islamskiej-ulaskawiono-tysi/0007CMBHDG6FO4KJ-C321.jpg" /></a>Ajatollah Ali Chamenei, przywódca duchowo-polityczny Iranu ułaskawił dziesiątki tysięcy więźniów. Wielu z nich zostało wcześniej aresztowanych po tym, jak wzięli udział w antyrządowych protestach, które zawładnęły krajem po śmierci młodej Kurdyjki Mashy Amini. Państwowa agencja IRNA poinformowała, że ułaskawienia ogłoszono z okazji rocznicy rewolucji islamskiej z 1979 roku.</p><br clear="all" />

## Rada Naczelna PPS zdecydowała. Wycofuje zgodę na posługiwanie się nazwą
 - [https://wydarzenia.interia.pl/kraj/news-rada-naczelna-pps-zdecydowala-wycofuje-zgode-na-poslugiwanie,nId,6579048](https://wydarzenia.interia.pl/kraj/news-rada-naczelna-pps-zdecydowala-wycofuje-zgode-na-poslugiwanie,nId,6579048)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 15:31:20+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-rada-naczelna-pps-zdecydowala-wycofuje-zgode-na-poslugiwanie,nId,6579048"><img align="left" alt="Rada Naczelna PPS zdecydowała. Wycofuje zgodę na posługiwanie się nazwą" src="https://i.iplsc.com/rada-naczelna-pps-zdecydowala-wycofuje-zgode-na-poslugiwanie/000GPUPWUJ558S9W-C321.jpg" /></a>Rada Naczelna Polskiej Partii Socjalistycznej wycofała zgodę na posługiwanie się nazwą, znakami, symbolami, a także skrótami Polskiej Partii Socjalistycznej dotychczasowemu Kołu Parlamentarnemu PPS. Uchwała wchodzi w życie z dniem podjęcia, czyli od 5 lutego 2023r. Jak wynika z nieoficjalnych informacji, koło będzie nadal działać, tylko pod inną nazwą.</p><br clear="all" />

## Były premier Izraela twierdzi, że "uratował" Zełenskiego. Ukraińcy reagują
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-byly-premier-izraela-twierdzi-ze-uratowal-zelenskiego-ukrain,nId,6579041](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-byly-premier-izraela-twierdzi-ze-uratowal-zelenskiego-ukrain,nId,6579041)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 14:51:57+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-byly-premier-izraela-twierdzi-ze-uratowal-zelenskiego-ukrain,nId,6579041"><img align="left" alt="Były premier Izraela twierdzi, że &quot;uratował&quot; Zełenskiego. Ukraińcy reagują" src="https://i.iplsc.com/byly-premier-izraela-twierdzi-ze-uratowal-zelenskiego-ukrain/000DUWEG7EFYL4P8-C321.jpg" /></a>Były premier Izraela Naftali Bennett przekazał, że podczas pierwszych dni wojny w Ukrainie prezydent Rosji Władimir Putin zapewnił go, że nie wyda rozkazu zabicia Włodymyra Zełenskiego - donoszą media. Po tych słowach Zełenski miał nagrać filmik ze swojego biura. Strona ukraińska mówi jednak wprost, że to kłamstwo, a prezydent Ukrainy nagrał wideo już 25 lutego 2022 r., czyli zanim otrzymał taką informację.</p><br clear="all" />

## Nieudany start rosyjskiego samolotu. Zapalił się silnik
 - [https://wydarzenia.interia.pl/zagranica/news-nieudany-start-rosyjskiego-samolotu-zapalil-sie-silnik,nId,6579028](https://wydarzenia.interia.pl/zagranica/news-nieudany-start-rosyjskiego-samolotu-zapalil-sie-silnik,nId,6579028)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 14:09:44+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nieudany-start-rosyjskiego-samolotu-zapalil-sie-silnik,nId,6579028"><img align="left" alt="Nieudany start rosyjskiego samolotu. Zapalił się silnik" src="https://i.iplsc.com/nieudany-start-rosyjskiego-samolotu-zapalil-sie-silnik/000GPTVFAXVMGEN6-C321.jpg" /></a>Silnik rosyjskiego samolotu zapalił się, gdy startował z lotniska w Phukecie w Tajlandii. Na pokładzie było 321 osób, które zostały ewakuowane z maszyny. Wśród podróżujących do Moskwy znajdowały się rodziny mężczyzn ukrywających się przed mobilizacją. </p><br clear="all" />

## Jastrzębie-Zdrój: Zimne kaloryfery w ponad 23 tys. mieszkań
 - [https://wydarzenia.interia.pl/slaskie/news-jastrzebie-zdroj-zimne-kaloryfery-w-ponad-23-tys-mieszkan,nId,6579024](https://wydarzenia.interia.pl/slaskie/news-jastrzebie-zdroj-zimne-kaloryfery-w-ponad-23-tys-mieszkan,nId,6579024)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 14:02:04+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/slaskie/news-jastrzebie-zdroj-zimne-kaloryfery-w-ponad-23-tys-mieszkan,nId,6579024"><img align="left" alt="Jastrzębie-Zdrój: Zimne kaloryfery w ponad 23 tys. mieszkań" src="https://i.iplsc.com/jastrzebie-zdroj-zimne-kaloryfery-w-ponad-23-tys-mieszkan/000G5C1UIAVK68MH-C321.jpg" /></a>Mieszkańcy ponad 23 tys. mieszkań w Jastrzębiu-Zdroju (woj. śląskie) mają w niedzielę zimne kaloryfery na skutek dwóch awarii ciepłowniczych. Jak zapewnia zapewnia spółka PGNiG Termika Energetyka Przemysłowa, trwa ponowne napełnianie sieci i w niedzielę wieczorem powinny zostać wznowione dostawy ciepła.</p><br clear="all" />

## Krystyna Pawłowicz uderza w "zagraniczne firmy" i WOŚP
 - [https://wydarzenia.interia.pl/kraj/news-krystyna-pawlowicz-uderza-w-zagraniczne-firmy-i-wosp,nId,6579005](https://wydarzenia.interia.pl/kraj/news-krystyna-pawlowicz-uderza-w-zagraniczne-firmy-i-wosp,nId,6579005)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 13:10:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-krystyna-pawlowicz-uderza-w-zagraniczne-firmy-i-wosp,nId,6579005"><img align="left" alt="Krystyna Pawłowicz uderza w &quot;zagraniczne firmy&quot; i WOŚP" src="https://i.iplsc.com/krystyna-pawlowicz-uderza-w-zagraniczne-firmy-i-wosp/000F7OLC26OUB2AB-C321.jpg" /></a>Sędzia Trybunału Konstytucyjnego Krystyna Pawłowicz postanowiła zabrać głos w sprawie tegorocznej zbiórki Wielkiej Orkiestry Świątecznej Pomocy. Była posłanka PiS uderzyła w swoim wpisie w zagraniczne firmy. &quot;Towary i usługi tych firm mniej bystrych klientów, często nie popierających WOŚP zmuszały do wpłat na jej rzecz&quot; - głosi post. Nie jest to pierwszy raz, kiedy Pawłowicz krytykuje zbiórkę.</p><br clear="all" />

## Gerard Depardieu: Dla mnie nic się nie zmieniło. Nadal jestem Rosjaninem
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-gerard-depardieu-dla-mnie-nic-sie-nie-zmienilo-nadal-jestem-,nId,6579000](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-gerard-depardieu-dla-mnie-nic-sie-nie-zmienilo-nadal-jestem-,nId,6579000)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 12:53:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-gerard-depardieu-dla-mnie-nic-sie-nie-zmienilo-nadal-jestem-,nId,6579000"><img align="left" alt="Gerard Depardieu: Dla mnie nic się nie zmieniło. Nadal jestem Rosjaninem" src="https://i.iplsc.com/gerard-depardieu-dla-mnie-nic-sie-nie-zmienilo-nadal-jestem/000GPTLQBQRO2BCU-C321.jpg" /></a>- Nadal jestem Rosjaninem. Kocham rosyjską kulturę. Kiedy kocham jakiś kraj, to zawsze ze względu na jego kulturę - powiedział Gerard Depardieu w rozmowie z niemieckimi mediami. Aktor zaznaczył, że nie chce rozmawiać na temat wojny w Ukrainie. - Nie mogę znieść, kiedy miesza się politykę i aktorstwo - dodał. Jeszcze kilka miesięcy temu Depardieu nawoływał do zakończenia &quot;bratobójczych walk&quot;.</p><br clear="all" />

## Lawina zeszła na szlak do Morskiego Oka. Leśniczy pokazał nagranie
 - [https://wydarzenia.interia.pl/malopolskie/news-lawina-zeszla-na-szlak-do-morskiego-oka-lesniczy-pokazal-nag,nId,6579002](https://wydarzenia.interia.pl/malopolskie/news-lawina-zeszla-na-szlak-do-morskiego-oka-lesniczy-pokazal-nag,nId,6579002)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 12:38:25+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-lawina-zeszla-na-szlak-do-morskiego-oka-lesniczy-pokazal-nag,nId,6579002"><img align="left" alt="Lawina zeszła na szlak do Morskiego Oka. Leśniczy pokazał nagranie" src="https://i.iplsc.com/lawina-zeszla-na-szlak-do-morskiego-oka-lesniczy-pokazal-nag/000GPTLMABOJNNCS-C321.jpg" /></a>Kolejna potężna lawina śnieżna zeszła na drogę do Morskiego Oka wyłamując las. Zwały śniegu całkowicie zasypały popularny szlak nad tatrzańskie jezioro - przekazał leśniczy znad Morskiego Oka Grzegorz Bryniarski. Tatrzański Park Narodowy pokazał nagranie z terenu.</p><br clear="all" />

## Politycy odpowiadają premierowi ws. zmiany konstytucji. Czarzasty: Małpie brzytwy się nie daje
 - [https://wydarzenia.interia.pl/kraj/news-politycy-odpowiadaja-premierowi-ws-zmiany-konstytucji-czarza,nId,6578983](https://wydarzenia.interia.pl/kraj/news-politycy-odpowiadaja-premierowi-ws-zmiany-konstytucji-czarza,nId,6578983)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 12:21:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-politycy-odpowiadaja-premierowi-ws-zmiany-konstytucji-czarza,nId,6578983"><img align="left" alt="Politycy odpowiadają premierowi ws. zmiany konstytucji. Czarzasty: Małpie brzytwy się nie daje" src="https://i.iplsc.com/politycy-odpowiadaja-premierowi-ws-zmiany-konstytucji-czarza/000GPTIRR6I431WK-C321.jpg" /></a>- Nigdy nie będziemy zmieniali konstytucji z ludźmi, którzy łamią konstytucję. Absolutnie nie ma takiej możliwości, małpie brzytwy się nie daje - mówił w niedzielę w Polsat News Włodzimierz Czarzasty. - Nie ma potrzeby zmieniać konstytucji - dodawał poseł PSL Piotr Zgorzelski. Politycy odnieśli się w ten sposób do wezwania Mateusza Morawieckiego w Interii do zmian, dzięki którym możliwe będzie odebranie rosyjskich majątków.</p><br clear="all" />

## Media: Ołeksij Reznikow straci stanowisko ministra obrony Ukrainy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-oleksij-reznikow-straci-stanowisko-ministra-obrony-ukr,nId,6578968](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-oleksij-reznikow-straci-stanowisko-ministra-obrony-ukr,nId,6578968)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 11:20:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-oleksij-reznikow-straci-stanowisko-ministra-obrony-ukr,nId,6578968"><img align="left" alt="Media: Ołeksij Reznikow straci stanowisko ministra obrony Ukrainy" src="https://i.iplsc.com/media-oleksij-reznikow-straci-stanowisko-ministra-obrony-ukr/000GPT8VQU68MIOX-C321.jpg" /></a>Ołeksij Reznikow może stracić stanowisko ministra obrony Ukrainy w przyszłym tygodniu. Reznikowa zastąpić ma szef ukraińskiego wywiadu wojskowego Kyryło Budanow - przekazał portal Ukraińska Prawda. Według nieoficjalnych informacji, Reznikow najprawdopodobniej stanie na czele ministerstwa sprawiedliwości.</p><br clear="all" />

## Patrioty zmierzają do Warszawy. Zostaną rozstawione na lotnisku
 - [https://wydarzenia.interia.pl/kraj/news-patrioty-zmierzaja-do-warszawy-zostana-rozstawione-na-lotnis,nId,6578954](https://wydarzenia.interia.pl/kraj/news-patrioty-zmierzaja-do-warszawy-zostana-rozstawione-na-lotnis,nId,6578954)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 10:26:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-patrioty-zmierzaja-do-warszawy-zostana-rozstawione-na-lotnis,nId,6578954"><img align="left" alt="Patrioty zmierzają do Warszawy. Zostaną rozstawione na lotnisku" src="https://i.iplsc.com/patrioty-zmierzaja-do-warszawy-zostana-rozstawione-na-lotnis/000GPT2GUDA9IUNR-C321.jpg" /></a>Wyrzutnie Patriot są transportowane z Sochaczewa na lotnisko na warszawskim Bemowie. Zostaną tam rozstawione - powiadomił w niedzielę minister obrony narodowej Mariusz Błaszczak.</p><br clear="all" />

## Warszawa: "Akt wandalizmu" w metrze. Występowały duże utrudnienia
 - [https://wydarzenia.interia.pl/mazowieckie/news-warszawa-akt-wandalizmu-w-metrze-wystepowaly-duze-utrudnieni,nId,6578947](https://wydarzenia.interia.pl/mazowieckie/news-warszawa-akt-wandalizmu-w-metrze-wystepowaly-duze-utrudnieni,nId,6578947)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 10:07:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-warszawa-akt-wandalizmu-w-metrze-wystepowaly-duze-utrudnieni,nId,6578947"><img align="left" alt="Warszawa: &quot;Akt wandalizmu&quot; w metrze. Występowały duże utrudnienia" src="https://i.iplsc.com/warszawa-akt-wandalizmu-w-metrze-wystepowaly-duze-utrudnieni/000GPSZAOG906UTL-C321.jpg" /></a>Przez niemal dwie godziny trwały utrudnienia w warszawskim metrze. Jak przekazała Interii rzeczniczka Metra Warszawskiego Anna Bartoń na jednej ze stacji doszło do &quot;aktu wandalizmu&quot;. - Grafficiarze wymazali jeden z pociągów - powiedziała Bartoń.</p><br clear="all" />

## Sochaczew: Ukradł batonik i wino. Chciał zakpić z policji, srogo się pomylił
 - [https://wydarzenia.interia.pl/mazowieckie/news-sochaczew-ukradl-batonik-i-wino-chcial-zakpic-z-policji-srog,nId,6578955](https://wydarzenia.interia.pl/mazowieckie/news-sochaczew-ukradl-batonik-i-wino-chcial-zakpic-z-policji-srog,nId,6578955)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 10:06:12+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-sochaczew-ukradl-batonik-i-wino-chcial-zakpic-z-policji-srog,nId,6578955"><img align="left" alt="Sochaczew: Ukradł batonik i wino. Chciał zakpić z policji, srogo się pomylił" src="https://i.iplsc.com/sochaczew-ukradl-batonik-i-wino-chcial-zakpic-z-policji-srog/000GPT2R9VMIR908-C321.jpg" /></a>Najpierw 33-latek odwiedził komisariat policji w Sosnowcu. Dopytywał się, co grozi za drobne kradzieże i od jakiej kwoty wykroczenie staje się przestępstwem. Po rozmowie z funkcjonariuszami, niemal natychmiast ruszył do pobliskiego sklepu. Bezceremonialnie ukradł batonik i dwie butelki wina po czym skonsumował je na oczach ekspedientki. Myślał, że nic mu nie grozi - srogo się pomylił.</p><br clear="all" />

## USA: Mężczyzna uciekał przed policją. Wbiegł na ruchliwą autostradę
 - [https://wydarzenia.interia.pl/zagranica/news-usa-mezczyzna-uciekal-przed-policja-wbiegl-na-ruchliwa-autos,nId,6578937](https://wydarzenia.interia.pl/zagranica/news-usa-mezczyzna-uciekal-przed-policja-wbiegl-na-ruchliwa-autos,nId,6578937)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 09:11:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-mezczyzna-uciekal-przed-policja-wbiegl-na-ruchliwa-autos,nId,6578937"><img align="left" alt="USA: Mężczyzna uciekał przed policją. Wbiegł na ruchliwą autostradę" src="https://i.iplsc.com/usa-mezczyzna-uciekal-przed-policja-wbiegl-na-ruchliwa-autos/000GPSW5IX88HTMQ-C321.jpg" /></a>Do sieci trafiło nagranie z kamery samochodowej, na którym widać osobę wbiegającą na ruchliwą autostradę w Arizonie. Mężczyzna przecina drogę, po której pędzą rozpędzone pojazdy. Nagle zatrzymuje się na środku, tuż przed nadjeżdżającymi ciężarówkami. Policja poinformowała, że osoba nagrania uciekała przed patrolem.</p><br clear="all" />

## Seryjny gwałciciel może wyjść na wolność mimo apelu brytyjskiego wicepremiera
 - [https://wydarzenia.interia.pl/zagranica/news-seryjny-gwalciciel-moze-wyjsc-na-wolnosc-mimo-apelu-brytyjsk,nId,6578921](https://wydarzenia.interia.pl/zagranica/news-seryjny-gwalciciel-moze-wyjsc-na-wolnosc-mimo-apelu-brytyjsk,nId,6578921)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 08:36:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-seryjny-gwalciciel-moze-wyjsc-na-wolnosc-mimo-apelu-brytyjsk,nId,6578921"><img align="left" alt="Seryjny gwałciciel może wyjść na wolność mimo apelu brytyjskiego wicepremiera" src="https://i.iplsc.com/seryjny-gwalciciel-moze-wyjsc-na-wolnosc-mimo-apelu-brytyjsk/000GPSTXAL4TRCGB-C321.jpg" /></a>66-letni Andrew Barlow skazany na dożywocie w 1988 roku m.in. za 11 gwałtów, może wyjść na wolność. W piątek komisja ds. zwolnień warunkowych odrzuciła wniosek wicepremiera i sekretarza sprawiedliwości Wielkiej Brytanii Dominica Raaba o anulowanie zaplanowanego wypuszczenia seryjnego gwałciciela.</p><br clear="all" />

## USA: Pożar wykolejonego pociągu. Stan wyjątkowy i ewakuacja mieszkańców
 - [https://wydarzenia.interia.pl/zagranica/news-usa-pozar-wykolejonego-pociagu-stan-wyjatkowy-i-ewakuacja-mi,nId,6578933](https://wydarzenia.interia.pl/zagranica/news-usa-pozar-wykolejonego-pociagu-stan-wyjatkowy-i-ewakuacja-mi,nId,6578933)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 08:27:17+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-pozar-wykolejonego-pociagu-stan-wyjatkowy-i-ewakuacja-mi,nId,6578933"><img align="left" alt="USA: Pożar wykolejonego pociągu. Stan wyjątkowy i ewakuacja mieszkańców" src="https://i.iplsc.com/usa-pozar-wykolejonego-pociagu-stan-wyjatkowy-i-ewakuacja-mi/000GPSTCI2QKNKXY-C321.jpg" /></a>Stan wyjątkowy wprowadzono w wiosce East Palestine w amerykańskim stanie Ohio po wykolejeniu się pociągu przewożącego niebezpieczne substancje. Wiele wagonów stanęło w płomieniach. Miejscowe władze zdecydowały o ewakuacji mieszkańców.</p><br clear="all" />

## Ta kawa kosztuje ponad 1000 zł za pół kilo. Czy jest tego warta?
 - [https://wydarzenia.interia.pl/zagranica/news-ta-kawa-kosztuje-ponad-1000-zl-za-pol-kilo-czy-jest-tego-war,nId,6554239](https://wydarzenia.interia.pl/zagranica/news-ta-kawa-kosztuje-ponad-1000-zl-za-pol-kilo-czy-jest-tego-war,nId,6554239)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 08:24:01+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ta-kawa-kosztuje-ponad-1000-zl-za-pol-kilo-czy-jest-tego-war,nId,6554239"><img align="left" alt="Ta kawa kosztuje ponad 1000 zł za pół kilo. Czy jest tego warta?" src="https://i.iplsc.com/ta-kawa-kosztuje-ponad-1000-zl-za-pol-kilo-czy-jest-tego-war/000D8UVYLY1977HS-C321.jpg" /></a>Wstajesz rano i zaczynasz dzień od kubka ulubionej kawy. Przerwę w pracy wykorzystujesz na kolejną dawkę kofeiny - czarna, latte albo cappuccino z delikatną pianką… A co powiesz na kawę kopi luwak z odchodów azjatyckich cywet?</p><br clear="all" />

## Olaf Scholz o ustaleniach z Zełenskim w sprawie broni: Jest zgoda
 - [https://wydarzenia.interia.pl/zagranica/news-olaf-scholz-o-ustaleniach-z-zelenskim-w-sprawie-broni-jest-z,nId,6578907](https://wydarzenia.interia.pl/zagranica/news-olaf-scholz-o-ustaleniach-z-zelenskim-w-sprawie-broni-jest-z,nId,6578907)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 07:35:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-olaf-scholz-o-ustaleniach-z-zelenskim-w-sprawie-broni-jest-z,nId,6578907"><img align="left" alt="Olaf Scholz o ustaleniach z Zełenskim w sprawie broni: Jest zgoda" src="https://i.iplsc.com/olaf-scholz-o-ustaleniach-z-zelenskim-w-sprawie-broni-jest-z/000EZF9OQRKNHI6B-C321.jpg" /></a>Kanclerz Niemiec Olaf Scholz poinformował, że rozmawiał z Wołodymyrem Zełenskim o użyciu broni, którą Zachód dostarcza broniącej się Ukrainie. Wyjaśnił, że między nim a prezydentem &quot;jest zgoda&quot;, że zachodnie uzbrojenie nie zostanie użyte do ataków na terytorium Rosji.</p><br clear="all" />

## Te osoby mogą podwyższyć sobie emeryturę. Trzeba tylko złożyć jeden wniosek
 - [https://wydarzenia.interia.pl/kraj/news-te-osoby-moga-podwyzszyc-sobie-emeryture-trzeba-tylko-zlozyc,nId,6573155](https://wydarzenia.interia.pl/kraj/news-te-osoby-moga-podwyzszyc-sobie-emeryture-trzeba-tylko-zlozyc,nId,6573155)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 07:23:27+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-te-osoby-moga-podwyzszyc-sobie-emeryture-trzeba-tylko-zlozyc,nId,6573155"><img align="left" alt="Te osoby mogą podwyższyć sobie emeryturę. Trzeba tylko złożyć jeden wniosek" src="https://i.iplsc.com/te-osoby-moga-podwyzszyc-sobie-emeryture-trzeba-tylko-zlozyc/000GPAUGP128Y5V0-C321.jpg" /></a>Twoje świadczenie emerytalne jest niskie? A może w ostatnim czasie dorabiałeś, aby podwyższyć swój dochód, bądź udało ci się znaleźć świadectwo pracy sprzed kilku lat? Wykorzystaj sytuację i złóż wniosek do ZUS z prośbą o ponowne przeliczenie twojej emerytury. Dzięki tej opcji możesz zyskać co miesiąc nawet kilkadziesiąt złotych więcej.
</p><br clear="all" />

## Chiński balon szpiegowski zestrzelony przez USA. Pekin potępia
 - [https://wydarzenia.interia.pl/zagranica/news-chinski-balon-szpiegowski-zestrzelony-przez-usa-pekin-potepi,nId,6578911](https://wydarzenia.interia.pl/zagranica/news-chinski-balon-szpiegowski-zestrzelony-przez-usa-pekin-potepi,nId,6578911)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 07:22:11+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chinski-balon-szpiegowski-zestrzelony-przez-usa-pekin-potepi,nId,6578911"><img align="left" alt="Chiński balon szpiegowski zestrzelony przez USA. Pekin potępia" src="https://i.iplsc.com/chinski-balon-szpiegowski-zestrzelony-przez-usa-pekin-potepi/000GPSO6XOKSCBL0-C321.jpg" /></a>Chiny zdecydowanie nie pochwalają i protestują przeciwko amerykańskiemu siłowemu atakowi na cywilny bezzałogowy statek powietrzny - przekazało chińskie ministerstwo spraw zagranicznych po tym, jak amerykańskie władze zestrzeliły ich balon szpiegowski. Dodano, że reakcja Waszyngtonu byłą &quot;przesadzona&quot; i stanowi ona &quot;poważne naruszenie&quot; praktyki międzynarodowej.</p><br clear="all" />

## Embargo na produkty ropopochodne z Rosji wchodzi w życie
 - [https://wydarzenia.interia.pl/kraj/news-embargo-na-produkty-ropopochodne-z-rosji-wchodzi-w-zycie,nId,6578903](https://wydarzenia.interia.pl/kraj/news-embargo-na-produkty-ropopochodne-z-rosji-wchodzi-w-zycie,nId,6578903)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 06:54:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-embargo-na-produkty-ropopochodne-z-rosji-wchodzi-w-zycie,nId,6578903"><img align="left" alt="Embargo na produkty ropopochodne z Rosji wchodzi w życie" src="https://i.iplsc.com/embargo-na-produkty-ropopochodne-z-rosji-wchodzi-w-zycie/000GPSMO2JGRG0M5-C321.jpg" /></a>W niedzielę weszło w życie embargo Unii Europejskiej na produkty z ropy, w tym paliwa gotowe z Rosji. Zakaz nałożono w związku z rosyjską napaścią na Ukrainę. Eksperci uspokajają, że nie spowoduje to gwałtownego wzrostu cen paliw, a diesla na stacjach nie zabraknie.</p><br clear="all" />

## Rosja: 600 rezerwistów odmówiło walki w Ukrainie i wróciło do kraju
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-600-rezerwistow-odmowilo-walki-w-ukrainie-i-wrocilo-do,nId,6578906](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-600-rezerwistow-odmowilo-walki-w-ukrainie-i-wrocilo-do,nId,6578906)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 06:43:18+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-600-rezerwistow-odmowilo-walki-w-ukrainie-i-wrocilo-do,nId,6578906"><img align="left" alt="Rosja: 600 rezerwistów odmówiło walki w Ukrainie i wróciło do kraju" src="https://i.iplsc.com/rosja-600-rezerwistow-odmowilo-walki-w-ukrainie-i-wrocilo-do/000GPSMGXE6NRYIO-C321.jpg" /></a>Ponad 600 rezerwistów odmówiło udziału w walkach w obwodzie ługańskim  - przekazał sztab generalny ukraińskiej armii. Żołnierze wrócili do Rosji. Ukraińcy informują też o problemach wroga z zapewnieniem opieki medycznej rannym.</p><br clear="all" />

## Bywało nawet -41 stopni Celsjusza. A co przyniesie "bestia ze wschodu"?
 - [https://wydarzenia.interia.pl/kraj/news-bywalo-nawet-41-stopni-celsjusza-a-co-przyniesie-bestia-ze-w,nId,6575142](https://wydarzenia.interia.pl/kraj/news-bywalo-nawet-41-stopni-celsjusza-a-co-przyniesie-bestia-ze-w,nId,6575142)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 06:10:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-bywalo-nawet-41-stopni-celsjusza-a-co-przyniesie-bestia-ze-w,nId,6575142"><img align="left" alt="Bywało nawet -41 stopni Celsjusza. A co przyniesie &quot;bestia ze wschodu&quot;?" src="https://i.iplsc.com/bywalo-nawet-41-stopni-celsjusza-a-co-przyniesie-bestia-ze-w/000GPKBNVIUTKFDO-C321.jpg" /></a>Jaką pogodę przyniesie luty 2023 roku? Biorąc pod uwagę rekordy ciepła ze stycznia, możemy spodziewać się wszystkiego. Sprawdzamy, jaka do tej pory bywała pogoda w lutym oraz czy tzw. bestia ze wschodu faktycznie sprowadzi do Polski siarczyste mrozy.</p><br clear="all" />

## WSJ: Turcja sprzedaje Rosji sprzęt objęty sankcjami
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wsj-turcja-sprzedaje-rosji-sprzet-objety-sankcjami,nId,6577574](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wsj-turcja-sprzedaje-rosji-sprzet-objety-sankcjami,nId,6577574)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 06:09:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wsj-turcja-sprzedaje-rosji-sprzet-objety-sankcjami,nId,6577574"><img align="left" alt="WSJ: Turcja sprzedaje Rosji sprzęt objęty sankcjami" src="https://i.iplsc.com/wsj-turcja-sprzedaje-rosji-sprzet-objety-sankcjami/000EM5E478LD0VGN-C321.jpg" /></a>W ubiegłym roku trafiły z Turcji do co najmniej 10 rosyjskich firm objętych sankcjami USA towary o wartości ponad 30 mln USD. Do Rosji wysyłano również towary produkcji amerykańskiej - poinformował dziennik &quot;Wall Street Journal&quot; na podstawie analizy danych handlowych. Amerykańscy urzędnicy próbują odciąć Kremlowi dostawy materiałów używanych do produkcji sprzętu wojskowego, np. gumy używanej do produkcji płyt, które chronią rosyjskie czołgi T-80. Sankcje i kontrole eksportu dotyczą także tworzyw sztucznych, których Rosja potrzebuje do...</p><br clear="all" />

## Czy 5 lutego to niedziela handlowa? Sprawdź, gdzie zrobisz zakupy
 - [https://wydarzenia.interia.pl/kraj/news-czy-5-lutego-to-niedziela-handlowa-sprawdz-gdzie-zrobisz-zak,nId,6570966](https://wydarzenia.interia.pl/kraj/news-czy-5-lutego-to-niedziela-handlowa-sprawdz-gdzie-zrobisz-zak,nId,6570966)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 05:13:14+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-czy-5-lutego-to-niedziela-handlowa-sprawdz-gdzie-zrobisz-zak,nId,6570966"><img align="left" alt="Czy 5 lutego to niedziela handlowa? Sprawdź, gdzie zrobisz zakupy" src="https://i.iplsc.com/czy-5-lutego-to-niedziela-handlowa-sprawdz-gdzie-zrobisz-zak/000GJKXIV3QIB06R-C321.jpg" /></a>W tym roku przypada 7 niedziel handlowych. W ubiegłym tygodniu Polacy mogli zrobić zakupy w niedzielę, ponieważ był to jeden z tych dni, gdy nie obowiązuje zakaz handlu. Jednak wiele osób zastanawia się, czy 5 lutego także przypada niedziela handlowa. Sprawdź, czy dziś zrobisz zakupy.</p><br clear="all" />

## Pełnia Księżyca już dziś. O której i gdzie ją obserwować?
 - [https://wydarzenia.interia.pl/nauka/news-pelnia-ksiezyca-juz-dzis-o-ktorej-i-gdzie-ja-obserwowac,nId,6575099](https://wydarzenia.interia.pl/nauka/news-pelnia-ksiezyca-juz-dzis-o-ktorej-i-gdzie-ja-obserwowac,nId,6575099)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-02-05 05:01:40+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/nauka/news-pelnia-ksiezyca-juz-dzis-o-ktorej-i-gdzie-ja-obserwowac,nId,6575099"><img align="left" alt="Pełnia Księżyca już dziś. O której i gdzie ją obserwować?" src="https://i.iplsc.com/pelnia-ksiezyca-juz-dzis-o-ktorej-i-gdzie-ja-obserwowac/000GL0EIK4SRFV4V-C321.jpg" /></a>Pełnia Księżyca to zjawisko bardzo chętnie obserwowane i badane przez wiele osób. Udowodniono, że wpływa też na nasze samopoczucie. Sprawdź, o której zacznie się dzisiejsza Pełnia Śnieżnego Księżyca i gdzie można ją zaobserwować.</p><br clear="all" />
