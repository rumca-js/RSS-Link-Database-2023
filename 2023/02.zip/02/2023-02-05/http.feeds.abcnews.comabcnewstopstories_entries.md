# Source ABC News, Source URL:http://feeds.abcnews.com/abcnews/topstories, Source language: en-US

## Ride at Iowa amusement park where boy died will never reopen
 - [https://abcnews.go.com/Business/wireStory/ride-iowa-amusement-park-boy-died-reopen-96908086](https://abcnews.go.com/Business/wireStory/ride-iowa-amusement-park-boy-died-reopen-96908086)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 21:39:14+00:00
 - user: None

The managers of an Iowa amusement park say they will never reopen a ride where an 11-year-old boy was killed

## Evacuations urged in Ohio town as train wreck smolders
 - [https://abcnews.go.com/US/wireStory/evacuations-urged-ohio-town-train-wreck-smolders-96906707](https://abcnews.go.com/US/wireStory/evacuations-urged-ohio-town-train-wreck-smolders-96906707)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 19:40:46+00:00
 - user: None

A smoldering fire has persisted in a tangle of dozens of freight cars, some carrying hazardous materials, that derailed in Ohio near the Pennsylvania state line

## Tony Hawk to donate photo proceeds to Tyre Nichols fund
 - [https://abcnews.go.com/Sports/wireStory/tony-hawk-donate-photo-proceeds-tyre-nichols-fund-96898885](https://abcnews.go.com/Sports/wireStory/tony-hawk-donate-photo-proceeds-tyre-nichols-fund-96898885)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 18:22:11+00:00
 - user: None

Skateboard legend Tony Hawk says he will donate half of the proceeds of autographed photos of himself and BMX rider Rick Thorne to the memorial fund for Tyre Nichols

## 2 Indiana officers shot, suspect dead after gunfire exchange
 - [https://abcnews.go.com/US/wireStory/2-indiana-officers-shot-suspect-dead-after-gunfire-96905094](https://abcnews.go.com/US/wireStory/2-indiana-officers-shot-suspect-dead-after-gunfire-96905094)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 17:23:37+00:00
 - user: None

Police say two southern Indiana law enforcement officers were shot and wounded early Sunday during an exchange of gunfire with a suspect who fled a traffic stop on foot and fired at officers before he was fatally shot

## Rubio says China sent balloon to send 'a message': They believe US is 'in decline'
 - [https://abcnews.go.com/Politics/rubio-china-balloon-send-message-us-decline/story?id=96898184](https://abcnews.go.com/Politics/rubio-china-balloon-send-message-us-decline/story?id=96898184)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 17:18:32+00:00
 - user: None

China sent a balloon over U.S. airspace last week to send a message about the country's sway across the globe, Sen. Marco Rubio said on "This Week"

## 2 abducted Missouri children found in a Florida supermarket
 - [https://abcnews.go.com/US/wireStory/2-abducted-missouri-children-found-florida-supermarket-96904000](https://abcnews.go.com/US/wireStory/2-abducted-missouri-children-found-florida-supermarket-96904000)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 15:42:09+00:00
 - user: None

Two abducted children who had been missing from Missouri for almost a year were found in a central Florida grocery store with their non-custodial mother, who was taken into police custody

## Woman dies as migrant boat sinks off Greek island
 - [https://abcnews.go.com/International/wireStory/woman-dies-migrant-boat-sinks-off-greek-island-96902863](https://abcnews.go.com/International/wireStory/woman-dies-migrant-boat-sinks-off-greek-island-96902863)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 15:11:55+00:00
 - user: None

Authorities say a woman has died after a boat carrying at least 41 migrants crashed on a rocky coast on the Greek island of Leros

## Record numbers of people are worse off, a recipe for political discontent: POLL
 - [https://abcnews.go.com/Politics/record-numbers-worse-off-recipe-political-discontent-poll/story?id=96884607](https://abcnews.go.com/Politics/record-numbers-worse-off-recipe-political-discontent-poll/story?id=96884607)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 14:13:33+00:00
 - user: None

There is record dissatisfaction with Biden and Trump ahead of the 2024 election, according to a new poll.

## Europe bans Russian diesel, other oil products over Ukraine
 - [https://abcnews.go.com/Business/wireStory/europe-bans-russian-diesel-oil-products-ukraine-96902761](https://abcnews.go.com/Business/wireStory/europe-bans-russian-diesel-oil-products-ukraine-96902761)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 13:28:30+00:00
 - user: None

The European Union is launching its ban on imports of Russian diesel fuel

## It wasn’t me: Ex-UK PM Truss blames 'system' for her failure
 - [https://abcnews.go.com/International/wireStory/wasnt-uk-pm-truss-blames-system-failure-96902397](https://abcnews.go.com/International/wireStory/wasnt-uk-pm-truss-blames-system-failure-96902397)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 12:39:00+00:00
 - user: None

Former British Prime Minister Liz Truss says her failure wasn&rsquo;t her fault

## Bus crash kills at least 8, injures dozens in western Turkey
 - [https://abcnews.go.com/International/wireStory/bus-crash-kills-8-injures-dozens-western-turkey-96902291](https://abcnews.go.com/International/wireStory/bus-crash-kills-8-injures-dozens-western-turkey-96902291)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 11:13:09+00:00
 - user: None

A passenger bus has crashed off a road and overturned in western Turkey, killing at least eight people and injuring dozens

## Former Israeli PM: Putin promised not to kill Zelenskyy
 - [https://abcnews.go.com/International/wireStory/former-israeli-pm-putin-promised-kill-zelenskyy-96901897](https://abcnews.go.com/International/wireStory/former-israeli-pm-putin-promised-kill-zelenskyy-96901897)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 08:39:05+00:00
 - user: None

A former Israeli prime minister who served briefly as a mediator at the start of Russia&rsquo;s war with Ukraine says he drew a promise from the Russian president not to kill his Ukrainian counterpart

## US states take control of abortion debate with funding focus
 - [https://abcnews.go.com/Politics/wireStory/us-states-control-abortion-debate-funding-focus-96901806](https://abcnews.go.com/Politics/wireStory/us-states-control-abortion-debate-funding-focus-96901806)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 07:39:11+00:00
 - user: None

The U.S. abortion debate is shifting to funding as states take control of policymaking

## 9 missing after fishing boat capsizes in South Korea
 - [https://abcnews.go.com/International/wireStory/9-missing-after-fishing-boat-capsizes-south-korea-96901302](https://abcnews.go.com/International/wireStory/9-missing-after-fishing-boat-capsizes-south-korea-96901302)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 07:38:54+00:00
 - user: None

South Korean coast guard vessels and aircraft are searching in waters off the country&rsquo;s southwestern coast for nine fishermen who disappeared after their boat capsized

## Off-duty NYPD officer fighting for his life after being shot during robbery
 - [https://abcnews.go.com/US/off-duty-nypd-officer-fighting-life-after-shot/story?id=96901136](https://abcnews.go.com/US/off-duty-nypd-officer-fighting-life-after-shot/story?id=96901136)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 04:59:30+00:00
 - user: None

An off-duty NYPD officer is fighting for his life after being shot during a robbery.

## Crash averted at Austin airport; FAA, NTSB to investigate
 - [https://abcnews.go.com/US/wireStory/crash-averted-austin-airport-faa-ntsb-investigate-96899395](https://abcnews.go.com/US/wireStory/crash-averted-austin-airport-faa-ntsb-investigate-96899395)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 04:53:37+00:00
 - user: None

A landing cargo plane reversed course to avoid another plane on the same runway

## Biden met with praise, criticism over balloon downing
 - [https://abcnews.go.com/Politics/lawmakers-praise-successful-downing-suspected-chinese-spy-balloon/story?id=96897346](https://abcnews.go.com/Politics/lawmakers-praise-successful-downing-suspected-chinese-spy-balloon/story?id=96897346)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-02-05 04:08:38+00:00
 - user: None

The downing of a suspected Chinese surveillance balloon was met by lawmakers with a mix of praise, criticism and concern.
