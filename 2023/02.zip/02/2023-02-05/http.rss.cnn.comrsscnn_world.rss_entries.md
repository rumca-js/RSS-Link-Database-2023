# Source CNN World, Source URL:http://rss.cnn.com/rss/cnn_world.rss, Source language: en-US

## Iran pardons or commutes sentence of 'large' number of prisoners, state media reports
 - [https://www.cnn.com/2023/02/05/middleeast/iran-pardons-prisoners-intl/index.html](https://www.cnn.com/2023/02/05/middleeast/iran-pardons-prisoners-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-02-05 15:40:09+00:00
 - user: None

Iran will pardon or commute the sentences of a large number of prisoners as part of an annual amnesty, state media reported Sunday, although it is unclear how this will apply to people arrested in the recent wave of protests.
