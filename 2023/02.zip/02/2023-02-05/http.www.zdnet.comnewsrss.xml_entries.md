# Source ZDNET, Source URL:http://www.zdnet.com/news/rss.xml, Source language: en-US

## Your iPhone videos will never look like the ones Apple shows you
 - [https://www.zdnet.com/article/your-iphone-videos-will-never-look-like-the-ones-apple-shows-you/#ftag=RSSbaffb68](https://www.zdnet.com/article/your-iphone-videos-will-never-look-like-the-ones-apple-shows-you/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-05 17:54:00+00:00
 - user: None

Sorry. A $1000+ smartphone doesn't turn you into Steven Spielberg.

## Before Kevin Costner hit it big, he starred in a very 80s Apple commercial
 - [https://www.zdnet.com/article/before-kevin-costner-hit-it-big-he-starred-in-a-very-80s-apple-commercial/#ftag=RSSbaffb68](https://www.zdnet.com/article/before-kevin-costner-hit-it-big-he-starred-in-a-very-80s-apple-commercial/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-05 17:32:10+00:00
 - user: None

Forty years later, we take a quick look back at one of Apple's biggest failures…and the future movie star who helped promote it.

## I tried Delta's new free inflight Wi-Fi. Here's how fast it was
 - [https://www.zdnet.com/home-and-office/networking/i-tried-deltas-new-free-inflight-wi-fi-heres-how-fast-it-was/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/networking/i-tried-deltas-new-free-inflight-wi-fi-heres-how-fast-it-was/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-05 15:48:28+00:00
 - user: None

Delta's new free inflight internet service is better and more stable than earlier services and free to all SkyMiles members.

## Amazon thinks these are the best Valentine's gadgets and I'm not in love
 - [https://www.zdnet.com/article/amazon-thinks-these-are-the-best-valentines-gadgets-and-im-not-in-love/#ftag=RSSbaffb68](https://www.zdnet.com/article/amazon-thinks-these-are-the-best-valentines-gadgets-and-im-not-in-love/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-05 14:00:16+00:00
 - user: None

I fear Amazon struggles with the idea of romance. And love. And, perhaps, humanity.

## Apple couldn't fix it, AT&T couldn't fix it. One man's descent into iPhone torment
 - [https://www.zdnet.com/article/apple-couldnt-fix-it-at-t-couldnt-fix-it-one-mans-descent-into-iphone-torment/#ftag=RSSbaffb68](https://www.zdnet.com/article/apple-couldnt-fix-it-at-t-couldnt-fix-it-one-mans-descent-into-iphone-torment/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-05 13:00:17+00:00
 - user: None

Let's add T-Mobile's role in this mess. Oh, and Tim Cook's. You'll be glad this didn't happen to you.

## Stop doomscrolling: How to set screen time limits on your iPhone
 - [https://www.zdnet.com/article/how-to-set-screen-time-limits-on-your-iphone/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-set-screen-time-limits-on-your-iphone/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-05 12:15:00+00:00
 - user: None

Save yourself from endlessly scrolling by setting app limits on your iPhone.

## Microsoft says I should be more creative with Excel, so I took the bait
 - [https://www.zdnet.com/article/microsoft-says-i-should-be-more-creative-with-excel-so-i-took-the-bait/#ftag=RSSbaffb68](https://www.zdnet.com/article/microsoft-says-i-should-be-more-creative-with-excel-so-i-took-the-bait/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-02-05 12:00:16+00:00
 - user: None

Are these Microsoft suggestions really things you'd ever do? Except for, perhaps, one of them.
