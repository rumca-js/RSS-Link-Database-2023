# Source BBC, Source URL:http://feeds.bbci.co.uk/news/rss.xml, Source language: en-US

## German Masters: Ali Carter beats Tom Ford - with a bit of help from Whitney Houston
 - [https://www.bbc.co.uk/sport/snooker/64533013?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/64533013?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 23:32:04+00:00
 - user: None

Ali Carter suggests that Whitney Houston inspired him to a first ranking title in seven years as he wins the German Masters.

## Epsom College head found dead with husband and daughter, 7
 - [https://www.bbc.co.uk/news/uk-64533429?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64533429?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 22:43:35+00:00
 - user: None

Head of Epsom College found dead alongside husband and seven-year-old daughter in property on school grounds

## Grammy Awards 2023: Viola Davis becomes an EGOT
 - [https://www.bbc.co.uk/news/entertainment-arts-64533271?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64533271?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 22:17:41+00:00
 - user: None

The star is only the 18th person to win each of an Emmy, Grammy, Oscar and Tony Award.

## Garth Crooks' Team of the Week: Kane, Rashford, Mitoma, Dawson, Tarkowski, Tete, Onana
 - [https://www.bbc.co.uk/sport/football/64526671?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64526671?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 21:44:57+00:00
 - user: None

Who has been turbocharged by a new manager, and whose stunning display got Leicester back on track? It's Garth Crooks' Team of the Week.

## Gareth Bale in Pebble Beach Pro-Am: Ex-Wales footballer finishes in top 20
 - [https://www.bbc.co.uk/sport/golf/64528948?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/64528948?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 21:21:10+00:00
 - user: None

Gareth Bale finishes in joint-16th at the Pebble Beach Pro-Am after missing out on the final round because of strong winds in California.

## West Ham United 0-0 Arsenal: Gunners falter in WSL title race
 - [https://www.bbc.co.uk/sport/football/64442925?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64442925?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 20:45:26+00:00
 - user: None

Arsenal dropped points for the second successive Women's Super League match after being held to a goalless draw by West Ham United on Sunday evening.

## Pope and protestant leaders denounce anti-gay laws
 - [https://www.bbc.co.uk/news/world-64532639?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-64532639?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 19:44:26+00:00
 - user: None

Pope Francis said laws which criminalise homosexuality were a sin and "an injustice".

## Six Nations highlights: Italy 24-29 France
 - [https://www.bbc.co.uk/sport/av/rugby-union/64496986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/rugby-union/64496986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 18:54:17+00:00
 - user: None

Watch the highlights as defending champions France come from behind to avoid a shock defeat against Italy in a thrilling Six Nations game.

## Tottenham Hotspur 1-0 Manchester City: Harry Kane passes Jimmy Greaves as Spurs' all-time top scorer
 - [https://www.bbc.co.uk/sport/football/64442953?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64442953?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 18:39:36+00:00
 - user: None

Harry Kane becomes Tottenham's all-time record scorer, surpassing the great Jimmy Greaves, as his 267th goal for the club dents Manchester City's title ambitions at a raucous Tottenham Hotspur Stadium.

## China balloon: US searches in Atlantic for wreckage
 - [https://www.bbc.co.uk/news/world-us-canada-64530102?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64530102?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 18:26:13+00:00
 - user: None

The US is trying recover debris from the suspected spy balloon that fell in shallow waters off South Carolina.

## Watch: Hearts' Stephen Humphrys scores stunner from own half against Dundee Utd
 - [https://www.bbc.co.uk/sport/av/football/64530518?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64530518?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 18:00:11+00:00
 - user: None

Watch Hearts' Stephen Humphrys score a remarkable goal from his own half to seal a 3-1 Scottish Premiership victory over Dundee United.

## Italy 24-29 France: Six Nations champions avoid shock defeat
 - [https://www.bbc.co.uk/sport/rugby-union/64531379?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64531379?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 17:38:05+00:00
 - user: None

Defending champions France come from behind to avoid a shock defeat against Italy in a thrilling Six Nations game in Rome.

## Harry Kane: Tottenham striker overtakes Jimmy Greaves as Spurs' all-time top scorer
 - [https://www.bbc.co.uk/sport/football/64532175?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64532175?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 17:30:16+00:00
 - user: None

Harry Kane moves ahead of Jimmy Greaves to become Tottenham's all-time top goalscorer with his 267th goal for the club.

## How NHS strikes on Monday 6 February will affect you
 - [https://www.bbc.co.uk/news/business-64513077?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64513077?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 17:10:15+00:00
 - user: None

What you need to know about strikes by nurses and ambulance workers by the BBC's Zoe Conway.

## New images show Nicola Bulley on day she disappeared
 - [https://www.bbc.co.uk/news/uk-england-lancashire-64530529?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-64530529?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 16:45:45+00:00
 - user: None

Nicola Bulley is seen loading her car before taking her children to school on the day she disappeared.

## Nottingham Forest 1-0 Leeds United: Brennan Johnson strike raises pressure on Jesse Marsch
 - [https://www.bbc.co.uk/sport/football/64442954?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64442954?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 16:32:04+00:00
 - user: None

Brennan Johnson scores the only goal as Nottingham Forest beat Leeds to move six points clear of the Premier League relegation places.

## IBSF World Championships 2023: Great Britain win joint silver in four-man bobsleigh
 - [https://www.bbc.co.uk/sport/winter-sports/64531183?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-sports/64531183?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 15:37:16+00:00
 - user: None

Brad Hall, Taylor Lawrence, Greg Cackett and Arran Gulliver finish joint second to claim Britain's first four-man medal at the World Championships since 1939.

## Tottenham Hotspur 2-3 Chelsea: Lauren James scores superb strike as Blues move top of WSL
 - [https://www.bbc.co.uk/sport/football/64442928?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64442928?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 14:48:04+00:00
 - user: None

Chelsea move back to the top of the Women's Super League and extend their unbeaten run to 19 games in all competitions by beating Tottenham at Brisbane Road.

## Weekend avalanches kill 10 in Austria and Switzerland
 - [https://www.bbc.co.uk/news/world-europe-64530672?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64530672?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 14:38:16+00:00
 - user: None

Officials in western Austria warned winter sports enthusiasts of dangerous conditions in the area.

## St Johnstone 1-4 Celtic: Champions restore nine-point lead in Scottish Premiership
 - [https://www.bbc.co.uk/sport/football/64442918?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64442918?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 13:57:09+00:00
 - user: None

Celtic "won't put a ceiling on what they can achieve" after restoring their nine-point Scottish Premiership lead with a routine win at St Johnstone.

## Iran protests: Protesters among prisoners pardoned by leader
 - [https://www.bbc.co.uk/news/world-middle-east-64529927?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-64529927?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 13:32:03+00:00
 - user: None

Iranians involved in anti-government demos are among those set to be released.

## Bradford: Plans for 'Brit School North' proposed
 - [https://www.bbc.co.uk/news/uk-england-leeds-64529230?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-64529230?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 13:13:05+00:00
 - user: None

The Brit School in Croydon has nurtured a host of international music stars, including Adele.

## Truss's tax cuts clearly wrong approach, says Shapps
 - [https://www.bbc.co.uk/news/uk-64530150?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64530150?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 13:12:10+00:00
 - user: None

Grant Shapps, who briefly served in Liz Truss's cabinet, said inflation must fall before taxes are cut.

## Situation in east Ukraine getting tougher, says Zelensky
 - [https://www.bbc.co.uk/news/world-europe-64528580?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64528580?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 12:35:52+00:00
 - user: None

Ukrainian troops in the Donetsk region are facing difficult conditions, the country's president says.

## Balloon saga deflates efforts to mend US-China relations
 - [https://www.bbc.co.uk/news/world-asia-china-64529922?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-64529922?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 12:14:30+00:00
 - user: None

Concerns about the balloon have derailed a vital visit to China this week by the US's top diplomat.

## Vile speculation hurtful to Nicola Bulley's family, friend says
 - [https://www.bbc.co.uk/news/uk-england-lancashire-64529251?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-64529251?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 12:12:02+00:00
 - user: None

Nicola Bulley’s friend says speculation online is hurtful as police condemn social media abuse.

## Matt Dawson column: Steve Borthwick has boxed himself in with Owen Farrell
 - [https://www.bbc.co.uk/sport/rugby-union/64528772?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64528772?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 12:07:48+00:00
 - user: None

Ex-England captain Matt Dawson explains why new head coach Steve Borthwick is in a bind with captain Owen Farrell.

## Six Nations: Scotland's bits and pieces cause Calcutta Cup sensation
 - [https://www.bbc.co.uk/sport/rugby-union/64529089?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64529089?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 12:04:34+00:00
 - user: None

Tom English reflects on an exceptional Calcutta Cup victory for Scotland over England at Twickenham in the Six Nations opening weekend.

## Union boss Sharon Graham calls on Sunak to intervene on NHS pay
 - [https://www.bbc.co.uk/news/uk-politics-64529438?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64529438?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 11:46:27+00:00
 - user: None

Sharon Graham urged the PM to break the deadlock ahead of the biggest week of strikes in NHS history.

## How beavers are reviving wetlands
 - [https://www.bbc.co.uk/news/science-environment-64502365?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64502365?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 09:50:56+00:00
 - user: None

Wetlands are being lost at a faster rate than forests, but in some regions beavers are part of the solution.

## Dad completes charity run along entire length of M1
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-64500092?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-64500092?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 09:43:43+00:00
 - user: None

Jamie Austin finishes the last leg of his challenge after setting off from Leeds 10 days ago.

## Amanda Serrano sets up Katie Taylor rematch in Dublin with win over Erika Cruz
 - [https://www.bbc.co.uk/sport/boxing/64528253?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/64528253?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 08:18:55+00:00
 - user: None

Amanda Serrano beats Erika Cruz to become undisputed featherweight champion and set up a rematch with Katie Taylor.

## Pervez Musharraf, Pakistan's ex-president, dies aged 79
 - [https://www.bbc.co.uk/news/world-asia-64528348?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-64528348?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 07:24:23+00:00
 - user: None

The former president, who seized power in a coup in 1999, survived numerous assassination attempts.

## Obituary: Pervez Musharraf
 - [https://www.bbc.co.uk/news/world-asia-22248479?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-22248479?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 07:19:02+00:00
 - user: None

Pakistan's military ruler found himself on the front line between militant Islamists and the West.

## ‘We want our murals to show that there’s hope’
 - [https://www.bbc.co.uk/news/uk-northern-ireland-64329302?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-64329302?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 06:22:35+00:00
 - user: None

Two artists from County Antrim are painting murals to raises awareness of mental health issues.

## Hanif Kureishi says life 'completely changed' after collapse
 - [https://www.bbc.co.uk/news/entertainment-arts-64524922?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64524922?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 06:18:33+00:00
 - user: None

The My Beautiful Launderette author said losing the use of his limbs had been "illuminating as well as terrible".

## Farewell radiators? Testing out electric infrared wallpaper
 - [https://www.bbc.co.uk/news/business-64402524?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64402524?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 06:17:59+00:00
 - user: None

Pilots are being run around the UK to see if electric wallpaper could be an efficient way to heat homes.

## The papers: Truss 'never given a chance' and 'zero chance' of meeting hospital pledge
 - [https://www.bbc.co.uk/news/blogs-the-papers-64527254?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-64527254?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 05:30:49+00:00
 - user: None

Liz Truss's first account of her time as PM and questions over new hospitals being built lead the front pages.

## Wealthy UK family to apologise in Grenada over slave-owning past
 - [https://www.bbc.co.uk/news/world-latin-america-64527709?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-64527709?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 05:22:09+00:00
 - user: None

The Trevelyan family, who owned more than 1,000 African slaves in the 19th Century, will also pay reparations.

## Truss: I was never given realistic chance to cut taxes
 - [https://www.bbc.co.uk/news/uk-64527252?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64527252?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 05:14:40+00:00
 - user: None

The ex-PM's comments are the first detailed remarks she has made since she was forced out of No 10.

## Constance Marten: Missing couple and baby thought to be camping in Sussex
 - [https://www.bbc.co.uk/news/uk-64527545?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64527545?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 02:58:10+00:00
 - user: None

Police say their concern over the whereabouts of the couple and their newborn 'continues to grow'.

## Israel protests: Tens of thousands in anti-government rally
 - [https://www.bbc.co.uk/news/world-middle-east-64527567?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-64527567?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 02:37:39+00:00
 - user: None

It's the fifth week of mass protests across Israel over government plans to curb the judiciary's powers.

## Happy Valley: What's life really like living on Sgt Cawood's beat?
 - [https://www.bbc.co.uk/news/uk-england-leeds-64514356?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-64514356?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 01:57:03+00:00
 - user: None

The hit TV series has left its mark on those living on the fictional beat of Sgt Catherine Cawood.

## Jasvir Singh: 'I'm a devout Sikh - and married to a man'
 - [https://www.bbc.co.uk/news/uk-64496456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64496456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 01:34:20+00:00
 - user: None

Jasvir Singh is a prominent Sikh voice in the UK. He is also gay, and sees no conflict between his sexuality and religion.

## Turkey elections: Biggest test for Erdogan amid cost of living crisis
 - [https://www.bbc.co.uk/news/world-europe-64413620?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64413620?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 01:31:49+00:00
 - user: None

Rampant inflation is a key issue for voters as Turkey’s President Erdogan faces elections in May.

## Grammy Awards 2023: How to watch and who will win
 - [https://www.bbc.co.uk/news/entertainment-arts-64510239?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64510239?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 01:26:25+00:00
 - user: None

Adele, Beyoncé, Kendrick Lamar and Harry Styles are up for prizes at the 65th annual Grammys in LA.

## How to cook Spanish tortilla: Salmonella outbreak sparks national debate
 - [https://www.bbc.co.uk/news/world-europe-64510001?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64510001?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 00:36:13+00:00
 - user: None

A bout of food poisoning at a Madrid restaurant stirs debate about how to cook a Spanish tortilla.

## Andrew Tate: Inside the Romanian town where brothers' empire began
 - [https://www.bbc.co.uk/news/world-europe-64523028?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64523028?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 00:32:54+00:00
 - user: None

"Arrogant", "discreet" - Lucy Williamson visits the apartment block where the brothers first settled.

## 'Now I deliver food, but once I played football for my country'
 - [https://www.bbc.co.uk/news/world-asia-india-64513558?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-64513558?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 00:18:05+00:00
 - user: None

Poulami Adhikari played in India's under-16 team, but had to stop when her family fell on hard times.

## Energy firms given Tuesday deadline for prepayment meter action
 - [https://www.bbc.co.uk/news/uk-64526939?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64526939?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-02-05 00:09:42+00:00
 - user: None

Business Secretary Grant Shapps said energy firms need to refocus their efforts on customers who had prepayment meters forcibly installed
