# Source wiadomości.gazeta.pl, Source URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, Source language: pl-PL

## Córka zmarłego toprowca do lekceważących ostrzeżenia. "Chcesz ryzykować? Idź, ale nie wzywaj pomocy!"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29434437,corka-zmarlego-toprowca-zwrocila-sie-do-lekcewazacych-ostrzezenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29434437,corka-zmarlego-toprowca-zwrocila-sie-do-lekcewazacych-ostrzezenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-05 16:50:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6f/12/1c/z29434479M,Symboliczny-cmentarz.jpg" vspace="2" />Córka ratownika TOPR Marka Łabunowicza, który w 2001 r. zginął w trakcie akcji ratowniczej, zwróciła się z apelem do turystów wychodzących w góry mimo trudnych warunków pogodowych. "Idź, tylko nie powinieneś liczyć, że ktoś po ciebie przyjdzie, chyba że na wiosnę po twoje ciało. Ratownicy też mają rodziny" - napisała w mediach społecznościowych.

## Samolot LOT do Zanzibaru zawrócił na lotnisko w Warszawie. Doszło do usterki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29434235,samolot-lot-do-zanzibaru-zawrocil-na-lotnisko-w-warszawie-doszlo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29434235,samolot-lot-do-zanzibaru-zawrocil-na-lotnisko-w-warszawie-doszlo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-05 14:35:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7d/12/1c/z29434237M,Samolot-do-Zanzibaru-zawrocil-na-lotnisko-w-Warsza.jpg" vspace="2" />Samolot Boeing 787 Dreamliner należący do Polskich Linii Lotniczych LOT lecący do Zanzibaru musiał zawrócić w niedzielę na lotnisko w Warszawie. Powodem była usterka wskaźnika instalacji przeciwoblodzeniowej.

## Fala mrozów także w Polsce. Temperatura może spaść do -22 stopni! [OSTRZEŻENIA IMGW]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433962,fala-mrozow-takze-w-polsce-temperatura-moze-spasc-do-22-stopni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433962,fala-mrozow-takze-w-polsce-temperatura-moze-spasc-do-22-stopni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-05 12:57:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d8/12/1c/z29434072M,Mapa-z-temperatura---noc-5-lutego-2023.jpg" vspace="2" />Synoptycy IMGW wydali ostrzeżenia pierwszego stopnia dla południowej Polski. W części powiatów temperatura może spaść poniżej -20 stopni Celsjusza. W kolejnych dniach również należy spodziewać się siarczystego mrozu.

## Tatry. W rejonie Morskiego Oka zeszła potężna lawina. "Las w tym rejonie właściwie przestał istnieć"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433967,tatry-w-rejonie-morskiego-oka-zeszla-potezna-lawina-las-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433967,tatry-w-rejonie-morskiego-oka-zeszla-potezna-lawina-las-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-05 12:31:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/94/12/1c/z29434004M,Tatry--W-rejonie-Morskiego-Oka-zeszla-lawina.jpg" vspace="2" />W rejonie Morskiego Oka zeszła kolejna lawina. "Widać bardzo duże zniszczenia lasu, las zniszczyły również lawiny z rejonu Białego Żlebu. Na drodze pomiędzy Włosienicą a Morskim Okiem są co najmniej trzy lawiniska" - pisze Tatrzański Park Narodowy.

## Śląsk. Duża awaria ciepłownicza. Ponad 23 tys. mieszkań bez ciepłych kaloryferów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433869,slask-duza-awaria-cieplownicza-ponad-23-tys-mieszkan-bez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433869,slask-duza-awaria-cieplownicza-ponad-23-tys-mieszkan-bez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-05 12:05:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/61/0f/1c/z29421665M,Grzejnik.jpg" vspace="2" />Na skutek dwóch awarii ciepłowniczych mieszkańcy ponad 23 tys. mieszkań w Jastrzębiu-Zdroju mają w niedzielę zimne kaloryfery - podaje PAP. PGNiG Termika Energetyka Przemysłowa informuje, że dostawy ciepła będą wznowione do wieczora.

## 10-letni Miłosz zadzwonił na 112 i uratował tatę. "Zobaczyłem, że leci krew"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433783,10-letni-milosz-zadzwonil-na-112-i-uratowal-tate-zobaczylem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433783,10-letni-milosz-zadzwonil-na-112-i-uratowal-tate-zobaczylem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-05 11:59:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3f/0d/1c/z29415231M.jpg" vspace="2" />10-letni Miłosz z Radomska zadzwonił po pomoc, gdy na autostradzie A1 samochód, w którym jechał z ojczymem, uderzył w przydrożne barierki. Chłopiec przez blisko pół godziny rozmawiał z operatorką. - Miłosz uratował mi życie - mówił potem wzruszony pan Kamil w rozmowie z TVN24. W przyszłym tygodniu chłopiec i pani Ewelina, która odebrała zgłoszenie, zostaną nagrodzeni przez wojewodę łódzkiego.

## Andżelika zaginęła w 1997 roku - wyznaczono 70 tys. zł nagrody. Archiwum X typowało 13-letniego sprawcę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433621,andzelika-w-1997-roku-wyszla-z-domu-dziadkow-i-zniknela-anonimowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433621,andzelika-w-1997-roku-wyszla-z-domu-dziadkow-i-zniknela-anonimowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-05 10:53:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fc/d7/1a/z28147196M,Andzelika-Rutkowska-zaginela-25-lat-temu.jpg" vspace="2" />Andżelika Rutkowska w styczniu 1997 roku wyszła z domu dziadków w Kole i już nie wróciła. Chociaż Archiwum X wytypowało podejrzanego w sprawie, który miałby wówczas zaledwie 13 lat, sąd nie nakazał wszczynać śledztwa. Teraz anonimowy darczyńca wyznaczył wysoką nagrodę dla osób, które pomogą rozwikłać tę sprawę.

## Turyści idą w góry mimo skrajnie niebezpiecznych warunków. "To zdjęcie powinno być przestrogą"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433660,szalenie-niebezpiecznie-w-gorach-kolejne-akcje-ratunkowe-mimo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29433660,szalenie-niebezpiecznie-w-gorach-kolejne-akcje-ratunkowe-mimo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-02-05 10:33:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5e/11/1c/z29433694M,Szalenie-niebezpiecznie-w-gorach--Kolejne-akcje-ra.jpg" vspace="2" />Mimo kolejnych ostrzeżeń i zamkniętych szlaków turyści nadal idą w góry. W nocy ratownicy przeprowadzali kolejne akcje ratunkowe. Grupa GOPR pokazała zdjęcia z dramatycznej akcji ratunkowej.
