# Source pcgamer, Source URL:http://www.pcgamer.com/rss, Source language: en-US

## This adorable, Wind Waker-inspired platformer casts you as a friendly delivery witch
 - [https://www.pcgamer.com/this-adorable-wind-waker-inspired-platformer-casts-you-as-a-friendly-delivery-witch](https://www.pcgamer.com/this-adorable-wind-waker-inspired-platformer-casts-you-as-a-friendly-delivery-witch)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-05 23:27:14+00:00
 - user: None

Kiki's Delivery Service 2: Special Delivery.

## Activision Blizzard will pay a $35M fine to the SEC
 - [https://www.pcgamer.com/activision-blizzard-will-pay-a-dollar35m-fine-to-the-sec](https://www.pcgamer.com/activision-blizzard-will-pay-a-dollar35m-fine-to-the-sec)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-05 22:21:03+00:00
 - user: None

Activision Blizzard's fine will cover breaking whistleblower protection and investor disclosure laws.

## Purported Dragon Age: Dreadwolf leak shows actionized combat in a part of Thedas we've never seen before
 - [https://www.pcgamer.com/purported-dragon-age-dreadwolf-leak-shows-actionized-combat-in-a-part-of-thedas-weve-never-seen-before](https://www.pcgamer.com/purported-dragon-age-dreadwolf-leak-shows-actionized-combat-in-a-part-of-thedas-weve-never-seen-before)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-05 18:00:13+00:00
 - user: None

The screenshots and brief video supposedly originate with a playtest of the game.

## Wordle hint and answer today: Let's solve #596, February 5
 - [https://www.pcgamer.com/wordle-hint-answer-today-596-february-5](https://www.pcgamer.com/wordle-hint-answer-today-596-february-5)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-05 08:05:44+00:00
 - user: None

Here's a Wordle hint to help you out and the full answer if you need it.

## Evil Dead: The Game gets a new 'Splatter Royale' mode
 - [https://www.pcgamer.com/evil-dead-the-game-gets-a-new-splatter-royale-mode](https://www.pcgamer.com/evil-dead-the-game-gets-a-new-splatter-royale-mode)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-05 05:07:26+00:00
 - user: None

Get ready. Get set. Get dead.

## Explore a vast industrial hulk with your trusty climbing axes in this eerie first person platformer
 - [https://www.pcgamer.com/explore-a-vast-industrial-hulk-with-your-trusty-climbing-axes-in-this-eerie-first-person-platformer](https://www.pcgamer.com/explore-a-vast-industrial-hulk-with-your-trusty-climbing-axes-in-this-eerie-first-person-platformer)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-05 03:47:44+00:00
 - user: None

Imagine the climbing from Breath of the Wild as the basis of an entire platformer.

## Great moments in PC gaming: Blasting off the wall of death in Motocross Madness
 - [https://www.pcgamer.com/great-moments-in-pc-gaming-blasting-off-the-wall-of-death-in-motocross-madness](https://www.pcgamer.com/great-moments-in-pc-gaming-blasting-off-the-wall-of-death-in-motocross-madness)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-05 03:27:06+00:00
 - user: None

Sometimes you have to make your own fun.

## Shocking no one, real-life Squid Game seems to have been a bad idea
 - [https://www.pcgamer.com/shocking-no-one-real-life-squid-game-seems-to-have-been-a-bad-idea](https://www.pcgamer.com/shocking-no-one-real-life-squid-game-seems-to-have-been-a-bad-idea)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-02-05 01:13:33+00:00
 - user: None

Who could possibly have guessed.
