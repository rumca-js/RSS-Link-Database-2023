# Source Aljazeera, Source URL:http://www.aljazeera.com/xml/rss/all.xml, Source language: en-US

## ‘Mission completed’: Ukraine minister says warplanes on the way
 - [https://www.aljazeera.com/news/2023/2/5/mission-completed-ukraine-minister-says-warplanes-on-the-way](https://www.aljazeera.com/news/2023/2/5/mission-completed-ukraine-minister-says-warplanes-on-the-way)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 21:01:47+00:00
 - user: None

Russia may launch a major offensive in coming weeks, but Ukraine says it has troops and resources to repel the attack.

## What will changes in the US Democratic primary calendar mean?
 - [https://www.aljazeera.com/program/inside-story/2023/2/5/will-changes-in-the-us-democratic-primary-calendar-better-refle](https://www.aljazeera.com/program/inside-story/2023/2/5/will-changes-in-the-us-democratic-primary-calendar-better-refle)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 19:37:03+00:00
 - user: None

South Carolina is replacing Iowa as the first US state to vote in primary elections.

## European Union bans Russian diesel, oil products over Ukraine
 - [https://www.aljazeera.com/news/2023/2/5/europe-bans-russian-diesel-and-other-oil-products-over-ukraine](https://www.aljazeera.com/news/2023/2/5/europe-bans-russian-diesel-and-other-oil-products-over-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 18:33:40+00:00
 - user: None

Move comes after the bloc found new supplies of diesel from the US, Middle East and India to replace Russian energy.

## The ‘Twitter Files’ are a distraction
 - [https://www.aljazeera.com/opinions/2023/2/5/the-twitter-files-are-a-distraction](https://www.aljazeera.com/opinions/2023/2/5/the-twitter-files-are-a-distraction)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 17:48:09+00:00
 - user: None

Musk&#039;s controlled release of Twitter files in the name of &#039;freedom of speech&#039; obfuscates the real problem with Twitter.

## Iraqis protest over killing of YouTube star by her father
 - [https://www.aljazeera.com/news/2023/2/5/iraqis-protest-after-father-kills-youtuber-daughter](https://www.aljazeera.com/news/2023/2/5/iraqis-protest-after-father-kills-youtuber-daughter)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 17:44:56+00:00
 - user: None

Demonstrators hold placards saying &#039;stop killing women&#039; and &#039;Tiba&#039;s killer must be held to account&#039;.

## Austria avalanches kill at least 8 people
 - [https://www.aljazeera.com/news/2023/2/5/several-dead-in-austria-weekend-avalanches](https://www.aljazeera.com/news/2023/2/5/several-dead-in-austria-weekend-avalanches)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 16:55:30+00:00
 - user: None

Authorities say five people killed on Sunday after three other deaths were reported in the mountains the previous day.

## Will China exercise restraint after US downing of ‘spy’ balloon?
 - [https://www.aljazeera.com/news/2023/2/5/china-holds-off-on-responding-to-us-downing-of-balloon-for-now](https://www.aljazeera.com/news/2023/2/5/china-holds-off-on-responding-to-us-downing-of-balloon-for-now)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 16:25:12+00:00
 - user: None

While bilateral tension has risen over the balloon incident, China and the US have been seeking to improve ties.

## What is the ‘Arctic blast’ deep-freezing the US and Canada?
 - [https://www.aljazeera.com/news/2023/2/5/arctic-blast-barrels-into-us-canada-threatening-record-lows](https://www.aljazeera.com/news/2023/2/5/arctic-blast-barrels-into-us-canada-threatening-record-lows)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 16:22:23+00:00
 - user: None

Recent temperatures of -78 Celsius (-108 Fahrenheit) are reportedly the lowest ever recorded in the United States.

## Putin promised not to kill Zelenskyy: Ex-Israeli PM
 - [https://www.aljazeera.com/news/2023/2/5/putin-promised-not-to-kill-zelenskyy-former-israeli-pm](https://www.aljazeera.com/news/2023/2/5/putin-promised-not-to-kill-zelenskyy-former-israeli-pm)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 15:29:53+00:00
 - user: None

Former Israeli leader says he received a pledge from Russian president: ‘I won’t kill Zelenskyy.’

## Iran supreme leader pardons ‘tens of thousands’ of prisoners
 - [https://www.aljazeera.com/news/2023/2/5/iran-supreme-leader-pardons-tens-of-thousands-of-prisoners](https://www.aljazeera.com/news/2023/2/5/iran-supreme-leader-pardons-tens-of-thousands-of-prisoners)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 15:28:16+00:00
 - user: None

Those released from prison include some arrested in recent anti-government protests.

## Pope makes final appeal for peace at end of South Sudan trip
 - [https://www.aljazeera.com/news/2023/2/5/pope-makes-final-appeal-for-peace-at-end-of-south-sudan-trip](https://www.aljazeera.com/news/2023/2/5/pope-makes-final-appeal-for-peace-at-end-of-south-sudan-trip)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 12:02:03+00:00
 - user: None

Catholic church head and other Christian leaders called for recommitment to the 2018 peace deal during the Africa trip.

## Cyprus votes in presidential election as run-off expected
 - [https://www.aljazeera.com/news/2023/2/5/cyprus-votes-presidential-election](https://www.aljazeera.com/news/2023/2/5/cyprus-votes-presidential-election)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 10:21:07+00:00
 - user: None

With 14 candidates in the running, opinion polls point to a race between three frontrunners.

## What are ‘spy balloons’ and why are they used?
 - [https://www.aljazeera.com/news/2023/2/5/explainer-what-are-spy-balloons-and-why-are-they-used](https://www.aljazeera.com/news/2023/2/5/explainer-what-are-spy-balloons-and-why-are-they-used)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 09:59:52+00:00
 - user: None

Surveillance balloons have a long history in espionage, and continue to provide some spying advantages, experts say.

## Cost of living: An Indian family’s struggle to escape their slum
 - [https://www.aljazeera.com/features/2023/2/5/cost-of-living-indian-waste-picking-couple-struggles-with-debt](https://www.aljazeera.com/features/2023/2/5/cost-of-living-indian-waste-picking-couple-struggles-with-debt)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 08:46:44+00:00
 - user: None

Gunja and Chand saved and sacrificed for years to build a new home but now find themselves overwhelmed by debt.

## Brutal cold snap hits northeastern US, shattering record lows
 - [https://www.aljazeera.com/gallery/2023/2/5/photos-brutal-cold-snap-northeastern-us-record-lows](https://www.aljazeera.com/gallery/2023/2/5/photos-brutal-cold-snap-northeastern-us-record-lows)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 08:33:13+00:00
 - user: None

The Arctic air that descended on the northeastern US has brought record-setting sub-zero temperatures and wind chills.

## Pervez Musharraf: The Pakistani ex-president’s chequered legacy
 - [https://www.aljazeera.com/news/2023/2/5/obituary-pakistans-former-president-pervez-musharraf-dies](https://www.aljazeera.com/news/2023/2/5/obituary-pakistans-former-president-pervez-musharraf-dies)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 08:28:53+00:00
 - user: None

The former army chief, who seized power in a coup, died at the age of 79 in Dubai after a prolonged illness.

## Chile wildfires spread as death toll rises
 - [https://www.aljazeera.com/gallery/2023/2/5/photos-chile-wildfires-spread-as-death-toll-rises](https://www.aljazeera.com/gallery/2023/2/5/photos-chile-wildfires-spread-as-death-toll-rises)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 07:21:57+00:00
 - user: None

Firefighters in Chile continued to struggle to control dozens of raging wildfires that have killed at least 23 people.

## Russia-Ukraine war: List of key events, day 347
 - [https://www.aljazeera.com/news/2023/2/5/russia-ukraine-war-list-of-key-events-day-347](https://www.aljazeera.com/news/2023/2/5/russia-ukraine-war-list-of-key-events-day-347)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 06:54:10+00:00
 - user: None

As the Russia-Ukraine war enters its 347th day, we take a look at the main developments.

## Pakistani former President Pervez Musharraf dies aged 79
 - [https://www.aljazeera.com/news/2023/2/5/pakistan-former-president-pervez-musharraf-dies](https://www.aljazeera.com/news/2023/2/5/pakistan-former-president-pervez-musharraf-dies)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 06:30:03+00:00
 - user: None

Former military ruler of Pakistan died at a hospital in Dubai following a prolonged illness.

## Zelenskyy says situation in Ukraine’s east ‘getting tougher’
 - [https://www.aljazeera.com/news/2023/2/5/zelenskyy-says-situation-in-ukraines-east-getting-tougher](https://www.aljazeera.com/news/2023/2/5/zelenskyy-says-situation-in-ukraines-east-getting-tougher)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 05:07:23+00:00
 - user: None

Ukrainian leader says Russia is throwing more and more troops into battle on the eastern front lines.

## Chile expands emergency as deaths from wildfires rise
 - [https://www.aljazeera.com/news/2023/2/5/chile-expands-emergency-as-toll-from-wildfires-rises](https://www.aljazeera.com/news/2023/2/5/chile-expands-emergency-as-toll-from-wildfires-rises)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 04:18:00+00:00
 - user: None

At least 23 people killed as dozens of wildfires torch forests in Chile.

## Israelis rally for fifth week against Netanyahu’s judicial plans
 - [https://www.aljazeera.com/news/2023/2/5/israelis-rally-for-fifth-week-against-netanyahus-judicial-plans](https://www.aljazeera.com/news/2023/2/5/israelis-rally-for-fifth-week-against-netanyahus-judicial-plans)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-02-05 03:05:19+00:00
 - user: None

Tens of thousands brave heavy rain in Tel Aviv to protest against government plans to weaken Israel&#039;s Supreme Court.
