# Source Reclaim The Net, Source URL:https://reclaimthenet.org/feed/, Source language: en-US

## The tracking of the unvaccinated
 - [https://reclaimthenet.org/the-tracking-of-the-unvaccinated](https://reclaimthenet.org/the-tracking-of-the-unvaccinated)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-05 17:24:55+00:00
 - user: None

<a href="https://reclaimthenet.org/the-tracking-of-the-unvaccinated" rel="nofollow" title="The tracking of the unvaccinated"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/vax-986.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Collected for insurance providers.</p>
<p>The post <a href="https://reclaimthenet.org/the-tracking-of-the-unvaccinated" rel="nofollow">The tracking of the unvaccinated</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Member of Church of England’s general synod is reported over tweets
 - [https://reclaimthenet.org/member-of-church-of-englands-general-synod-is-reported-over-tweets](https://reclaimthenet.org/member-of-church-of-englands-general-synod-is-reported-over-tweets)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-05 16:27:47+00:00
 - user: None

<a href="https://reclaimthenet.org/member-of-church-of-englands-general-synod-is-reported-over-tweets" rel="nofollow" title="Member of Church of England’s general synod is reported over tweets"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/Sam-Margrave.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Sam Margrave is accused of being critical of gender ideology.</p>
<p>The post <a href="https://reclaimthenet.org/member-of-church-of-englands-general-synod-is-reported-over-tweets" rel="nofollow">Member of Church of England’s general synod is reported over tweets</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## The strange censorship of HBO movie posters
 - [https://reclaimthenet.org/the-strange-censorship-of-hbo-movie-posters](https://reclaimthenet.org/the-strange-censorship-of-hbo-movie-posters)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-02-05 16:16:25+00:00
 - user: None

<a href="https://reclaimthenet.org/the-strange-censorship-of-hbo-movie-posters" rel="nofollow" title="The strange censorship of HBO movie posters"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/02/hbo-cig-censor.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>HBO Max is yet to give a reason.</p>
<p>The post <a href="https://reclaimthenet.org/the-strange-censorship-of-hbo-movie-posters" rel="nofollow">The strange censorship of HBO movie posters</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>
