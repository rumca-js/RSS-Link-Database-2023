# Source Epoch times world, Source URL:https://www.theepochtimes.com/c-world/feed/, Source language: en-US

## Australia Becomes First Country to Reclassify MDMA and ‘Magic Mushrooms’ for Medical Use
 - [https://www.theepochtimes.com/australia-becomes-first-country-to-reclassify-mdma-and-magic-mushrooms-for-medical-use_5033908.html](https://www.theepochtimes.com/australia-becomes-first-country-to-reclassify-mdma-and-magic-mushrooms-for-medical-use_5033908.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 23:26:32+00:00
 - user: None

Ecstasy tablets which may contain MDMA (DEA)

## Cutting Red Tape Could Let Canadian Doctors Provide 55.6 Million More Patient Visits per Year: Report
 - [https://www.theepochtimes.com/cutting-red-tape-could-let-canadian-doctors-provide-55-6-million-more-patient-visits-per-year-report_5035647.html](https://www.theepochtimes.com/cutting-red-tape-could-let-canadian-doctors-provide-55-6-million-more-patient-visits-per-year-report_5035647.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 23:26:08+00:00
 - user: None

A health-care worker makes his way into the Emergency Department of the Vancouver General Hospital in Vancouver on March 30, 2020. (The Canadian Press/Jonathan Hayward)

## Toronto Police Seek Homicide Suspect in Assault That Killed Former CBC Producer
 - [https://www.theepochtimes.com/toronto-police-seek-homicide-suspect-in-assault-that-killed-former-cbc-producer_5035427.html](https://www.theepochtimes.com/toronto-police-seek-homicide-suspect-in-assault-that-killed-former-cbc-producer_5035427.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 21:49:40+00:00
 - user: None

Toronto police issued the photograph of a suspect wanted for manslaughter in the death of 73-year-old former CBC producer Michael Finlay, who died on Jan. 31, 2023, after a random assault in Toronto on Jan. 24, 2023. (Photo Courtesy Toronto Police Handout)

## Another Possible Chinese Spy Balloon Detected by Latin American Country
 - [https://www.theepochtimes.com/another-possible-chinese-spy-balloon-detected-by-latin-american-county_5035518.html](https://www.theepochtimes.com/another-possible-chinese-spy-balloon-detected-by-latin-american-county_5035518.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 20:59:18+00:00
 - user: None

A high altitude balloon floats over Billings, Mont., on Feb. 1, 2023. (Larry Mayer/The Billings Gazette via AP)

## Police Release Video of Apprehension of Suspects in Armed Robberies, Ask Public for Witnesses
 - [https://www.theepochtimes.com/police-release-video-of-apprehension-of-suspects-in-armed-robberies-ask-public-for-witnesses_5035302.html](https://www.theepochtimes.com/police-release-video-of-apprehension-of-suspects-in-armed-robberies-ask-public-for-witnesses_5035302.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 19:31:53+00:00
 - user: None

The sign outside a Scotiabank (Bank of Nova Scotia) in Vancouver, B.C., in a file photo. (Robert MacPherson/AFP via Getty Images)

## 9 Missing After Fishing Boat Capsizes in South Korea
 - [https://www.theepochtimes.com/9-missing-after-fishing-boat-capsizes-in-south-korea_5035107.html](https://www.theepochtimes.com/9-missing-after-fishing-boat-capsizes-in-south-korea_5035107.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 19:21:50+00:00
 - user: None

Members of the rescue team search for people from a capsized boat in waters off the country's southwestern coast in South Korea on Feb. 5, 2023. (Jung Hee-sung/Yonhap via AP)

## Pakistan’s Former President Musharraf, Key US Ally Against al-Qaeda, Dies at 79
 - [https://www.theepochtimes.com/pakistans-former-president-musharraf-key-us-ally-against-al-qaeda-dies-at-79_5035053.html](https://www.theepochtimes.com/pakistans-former-president-musharraf-key-us-ally-against-al-qaeda-dies-at-79_5035053.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 18:38:48+00:00
 - user: None

Pakistan's General Pervez Musharraf salutes during the playing of Pakistan's national anthem at the Joint Staff Headquarters in Rawalpindi, Pakistan, on Nov. 27, 2007. (Mian Khursheed/Reuters)

## WestJet Temporarily Suspends Summer Transatlantic Flights Between Halifax and Europe
 - [https://www.theepochtimes.com/westjet-temporarily-suspends-summer-transatlantic-flights-between-halifax-and-europe_5035221.html](https://www.theepochtimes.com/westjet-temporarily-suspends-summer-transatlantic-flights-between-halifax-and-europe_5035221.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 18:14:47+00:00
 - user: None

A WestJet flight from Calgary arrives at Halifax Stanfield International Airport in Enfield, N.S., Canada, on July 6, 2020. (The Canadian Press/Andrew Vaughan)

## Just Stop Oil Protests Cost London Metropolitan Police £7.5 Million
 - [https://www.theepochtimes.com/just-stop-oil-protests-cost-london-metropolitan-police-7-5-million_5035191.html](https://www.theepochtimes.com/just-stop-oil-protests-cost-london-metropolitan-police-7-5-million_5035191.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 17:40:00+00:00
 - user: None

Police officers detain a Just Stop Oil protester outside New Scotland Yard in London on Oct. 14, 2022. (Stefan Rousseau/PA Media)

## Cory Morgan: A Dangerous Double Standard Appears to Be at Play in Canada’s Justice System
 - [https://www.theepochtimes.com/cory-morgan-a-dangerous-double-standard-appears-to-be-at-play-in-canadas-justice-system_5034293.html](https://www.theepochtimes.com/cory-morgan-a-dangerous-double-standard-appears-to-be-at-play-in-canadas-justice-system_5034293.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 16:26:33+00:00
 - user: None

People opposed to COVID-19 restrictions are given a police escort as they march in Vancouver on Feb. 20, 2021. (The Canadian Press/Darryl Dyck)

## Former Prime Minister Truss Says She Was Not Given ‘Realistic Chance’ to Enact Tax-Cutting Policy
 - [https://www.theepochtimes.com/uks-ex-pm-truss-says-she-was-not-given-realistic-chance-to-enact-tax-cutting-policy_5035072.html](https://www.theepochtimes.com/uks-ex-pm-truss-says-she-was-not-given-realistic-chance-to-enact-tax-cutting-policy_5035072.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 14:40:58+00:00
 - user: None

Former Prime Minister Liz Truss leaves her house in southeast London on Feb, 5, 2023. (Jonathan Brady/PA Media)

## Canada’s Doctors Coerced into Promoting Euthanasia Call the Practice ‘Illegal’ and ‘Unethical’
 - [https://www.theepochtimes.com/health/canadas-doctors-coerced-into-promoting-euthanasia-call-the-practice-illegal-and-unethical_5007069.html](https://www.theepochtimes.com/health/canadas-doctors-coerced-into-promoting-euthanasia-call-the-practice-illegal-and-unethical_5007069.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 13:01:43+00:00
 - user: None

People rally against Bill C-14, the medically assisted dying bill, during a protest organized by the Euthanasia Prevention Coalition on Parliament Hill in Ottawa, Canada, on June 1, 2016. (Justin Tang/The Canadian Press)

## Companies Continue to Exit China Despite CCP’s Overture of Strengthening Economy: Observers
 - [https://www.theepochtimes.com/companies-continue-to-exit-china-despite-ccps-overture-of-strengthening-economy-observers_5034780.html](https://www.theepochtimes.com/companies-continue-to-exit-china-despite-ccps-overture-of-strengthening-economy-observers_5034780.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 07:55:22+00:00
 - user: None

Chinese workers assemble electronic components at the Taiwanese technology giant Foxconn's factory in Shenzhen City, Guangdong Province, China, on May 26, 2010. (AFP/Getty Images)

## ABC Apologises for Biased Report That Town Meeting on Alice Springs Crime Wave Was ‘Show of White Supremacy’
 - [https://www.theepochtimes.com/abc-apologises-for-biased-report-that-town-meeting-on-alice-springs-crime-wave-was-show-of-white-supremacy_5034692.html](https://www.theepochtimes.com/abc-apologises-for-biased-report-that-town-meeting-on-alice-springs-crime-wave-was-show-of-white-supremacy_5034692.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 06:15:33+00:00
 - user: None

The logo for Australia's public broadcaster ABC is seen on its head office building in Sydney on Sept. 27, 2018. (Saeed Khan/AFP via Getty Images)

## ASEAN Vows to Conclude Pact With China on Disputed Territory
 - [https://www.theepochtimes.com/asean-vows-to-conclude-pact-with-china-on-disputed-territory_5034304.html](https://www.theepochtimes.com/asean-vows-to-conclude-pact-with-china-on-disputed-territory_5034304.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 05:48:39+00:00
 - user: None

(L–R) Malaysian Foreign Minister Zambry Abdul Kadir, Philippine's Foreign Secretary Enrique Manalo, Singaporean Foreign Minister Vivian Balakrishnan, Thailand's Foreign Minister Don Pramudwinai, Vietnam's Foreign Minister Bui Thanh Son, Indonesian Foreign Minister Retno Marsudi, Laotian Foreign Minister Saleumxay Kommasith, Brunei's Second Minister of Foreign Affair Erywan Yusof, Cambodia's Foreign Minister Prak Sokhonn, East Timor's Foreign Minister Adaljiza Magno, and ASEAN Secretary General Kao Kim Hourn pose for a group photo during the Association of Southeast Asian Nations (ASEAN) foreign ministers retreat in Jakarta, Indonesia, on Feb. 4, 2023. (Achmad Ibrahim/AP Photo)

## Toronto Named as Host City for 2024 NHL All-Star Game
 - [https://www.theepochtimes.com/toronto-named-as-host-city-for-2024-nhl-all-star-game_5034818.html](https://www.theepochtimes.com/toronto-named-as-host-city-for-2024-nhl-all-star-game_5034818.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 05:27:37+00:00
 - user: None

Montreal Canadiens' Nick Suzuki (14) and Toronto Maple Leafs' Mitchell Marner (16) congratulate Canadian hockey player Sarah Nurse after she scored a goal during the NHL All Star Skills Showcase, Feb. 3, 2023, in Sunrise, Fla. (The Canadian Press/AP -Marta Lavandier)

## At Least 23 Dead as Dozens of Wildfires Torch Forests in Chile
 - [https://www.theepochtimes.com/firefighters-battle-dozens-of-wildfires-in-chile-as-emergency-extended_5034381.html](https://www.theepochtimes.com/firefighters-battle-dozens-of-wildfires-in-chile-as-emergency-extended_5034381.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 04:59:50+00:00
 - user: None

A wildfire burns areas in Santa Juana, near Concepcion, Chile, on Feb. 4, 2023. (Ailen Diaz/Reuters)

## Iraqi Currency Crash Halts After Meeting With US Official
 - [https://www.theepochtimes.com/iraqi-currency-crash-halts-after-meeting-with-us-official_5034342.html](https://www.theepochtimes.com/iraqi-currency-crash-halts-after-meeting-with-us-official_5034342.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 04:59:23+00:00
 - user: None

This aerial view shows the headquarters of the Central Bank of Iraq (CBI), designed by the late architect Zaha Hadid, on the banks of the Tigris river in the capital Baghdad, on Feb. 2, 2023. (AFP via Getty Images)

## Defence Minister Says Canada Supports US Downing of Suspected Chinese Spy Balloon
 - [https://www.theepochtimes.com/defence-minister-says-canada-supports-us-downing-of-suspected-chinese-spy-balloon_5034773.html](https://www.theepochtimes.com/defence-minister-says-canada-supports-us-downing-of-suspected-chinese-spy-balloon_5034773.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 04:35:49+00:00
 - user: None

Defence Minister Anita Anand rises during question period in the House of Commons in Ottawa on April 5, 2022. (The Canadian Press/Adrian Wyld)

## Federal Court Rejects AG’s Attempt to Dismiss Motion Seeking to Admit More Evidence Concerning Emergencies Act Invocation
 - [https://www.theepochtimes.com/federal-court-rejects-ags-attempt-to-dismiss-motion-seeking-to-admit-more-evidence-concerning-emergencies-act-invocation_5034024.html](https://www.theepochtimes.com/federal-court-rejects-ags-attempt-to-dismiss-motion-seeking-to-admit-more-evidence-concerning-emergencies-act-invocation_5034024.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 03:18:46+00:00
 - user: None

Armed police officers deploy to remove demonstrators against COVID-19 mandates, in Ottawa on Feb. 18, 2022. (Dave Chan/AFP via Getty Images)

## 95-Year-Old Ice Rink, ‘Catwalk’: Sask Village’s Video Goes Viral Amid Fundraiser
 - [https://www.theepochtimes.com/95-year-old-ice-rink-catwalk-sask-villages-video-goes-viral-amid-fundraiser_5034320.html](https://www.theepochtimes.com/95-year-old-ice-rink-catwalk-sask-villages-video-goes-viral-amid-fundraiser_5034320.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 03:06:03+00:00
 - user: None

A drawbridge style staircase is used to get players on and off the ice at the ice rink in Lang, Saskatchewan. (Courtesy Mike Williams.)

## World Economic Forum Agenda; A Manufactured Energy Crisis
 - [https://www.theepochtimes.com/world-economic-forum-agenda-a-manufactured-energy-crisis_5034465.html](https://www.theepochtimes.com/world-economic-forum-agenda-a-manufactured-energy-crisis_5034465.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 00:54:03+00:00
 - user: None



## Struggle to Survive in Australia’s Torres Strait Island ‘Paradise’
 - [https://www.theepochtimes.com/struggle-to-survive-in-australias-torres-strait-island-paradise_5034548.html](https://www.theepochtimes.com/struggle-to-survive-in-australias-torres-strait-island-paradise_5034548.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 00:50:49+00:00
 - user: None

A general view on Saibai Island on March 26, 2021 in Saibai Island, Australia.  More than 250 Islands make up the Torres Strait, a body of water separating the Cape York Peninsula and the southern coast of Papua New Guinea. (Photo by Brook Mitchell/Getty Images)

## ‘Spongiest’ City Auckland Still No Match for Floods
 - [https://www.theepochtimes.com/spongiest-city-auckland-still-no-match-for-floods_5034570.html](https://www.theepochtimes.com/spongiest-city-auckland-still-no-match-for-floods_5034570.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-02-05 00:41:32+00:00
 - user: None

Emergency workers and a man wade through flood waters in Auckland, New Zealand, on Jan. 27, 2023. (Hayden Woodward/New Zealand Herald via AP)
