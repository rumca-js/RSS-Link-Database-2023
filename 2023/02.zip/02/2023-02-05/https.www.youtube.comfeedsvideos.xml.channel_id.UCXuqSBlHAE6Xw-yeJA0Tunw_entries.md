# Source Linus Tech Tips, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, Source language: en-US

## AliExpress Wouldn't Lie... Right?
 - [https://www.youtube.com/watch?v=eVf7NLBj0y0](https://www.youtube.com/watch?v=eVf7NLBj0y0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-02-05 18:00:25+00:00
 - user: None

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Create your build at https://www.buildredux.com/linus

The Crelander Dual Screen laptop looks like an absolutely incredible deal at $750... if it actually is what they claim.

Discuss on the forum: https://linustechtips.com/topic/1486320-aliexpress-wouldnt-lie-right/

Buy an ASUS 14” UX481 ZenBook Duo: https://geni.us/oYgx
Buy an Hp 13.5” Elite Dragonfly: https://geni.us/oAxxlpJ
Check out the Crelander Dual Screen Laptop: https://lmg.gg/uWUje

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► COME TO LTX 2023: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► OUR WAN PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - Crelander wouldn't lie
0:38 - Build Redux!
0:54 - LTT Intro
1:02 - Linus has high expectations
3:20 - Screens (first reaction)
4:18 - Trackpad, keyboard
5:56 - Stated vs. real specs
8:01 - Cinebench
9:30 - Screens (labs report)
11:28 - Webcam
12:08 - Teardown
14:44 - Speakers
15:14 - Squarespace!
16:08 - Outro
