# Source Forbs - innovation, Source URL:https://www.forbes.com/innovation/feed2, Source language: en-US

## 18 Jokes Elon Musk Stole From His Fans On Twitter
 - [https://www.forbes.com/sites/mattnovak/2023/02/05/18-jokes-elon-musk-stole-from-his-fans-on-twitter/](https://www.forbes.com/sites/mattnovak/2023/02/05/18-jokes-elon-musk-stole-from-his-fans-on-twitter/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 19:27:27+00:00
 - user: None

Elon Musk loves to make jokes on Twitter, but I’m starting to wonder whether he’s ever made an original joke on the social media platform.

## How Covid-19 Vaccines May Affect Your Menstrual Cycle, Periods
 - [https://www.forbes.com/sites/brucelee/2023/02/05/how-covid-19-vaccines-may-affect-your-menstrual-cycle-periods/](https://www.forbes.com/sites/brucelee/2023/02/05/how-covid-19-vaccines-may-affect-your-menstrual-cycle-periods/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 18:32:11+00:00
 - user: None

With so much bloody misinformation out there, it's a good time to cycle back and do a "period piece" on what real scientific studies have said to date.

## Science-Fiction Film Festival Lands At London Science Museum In IMAX 70mm Format
 - [https://www.forbes.com/sites/bennyhareven/2023/02/05/science-fiction-film-festival-lands-at-london-science-museum-in-imax-70mm-format/](https://www.forbes.com/sites/bennyhareven/2023/02/05/science-fiction-film-festival-lands-at-london-science-museum-in-imax-70mm-format/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 16:47:12+00:00
 - user: None

The sci-fi film festival is offered to celebrate the museum’s exhibition, Science Fiction: Voyage to the Edge of Imagination, and a very good thing it is too.

## Everything We Know About ‘Lockwood And Co’ Season 2 On Netflix
 - [https://www.forbes.com/sites/paultassi/2023/02/05/everything-we-know-about-lockwood-and-co-season-2-on-netflix/](https://www.forbes.com/sites/paultassi/2023/02/05/everything-we-know-about-lockwood-and-co-season-2-on-netflix/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 16:15:12+00:00
 - user: None

If you’re a fan of the new ghost-hunting drama Lockwood and Co. on Neflix, I think it may be time to start being at least a little bit concerned about its potential season 2 renewal.

## EA Didn’t Cancel ‘Titanfall 3,’ But ‘Titanfall Legends’ Did Have A Playable Titan
 - [https://www.forbes.com/sites/paultassi/2023/02/05/ea-didnt-cancel-titanfall-3-but-titanfall-legends-did-have-a-playable-titan/](https://www.forbes.com/sites/paultassi/2023/02/05/ea-didnt-cancel-titanfall-3-but-titanfall-legends-did-have-a-playable-titan/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 15:53:56+00:00
 - user: None

There seems to be some concern that EA actually cancelled Titanfall 3, which fans have been demanding for years now, but that was not what it was, according to insiders.

## Reviewed: FiiO’s BTR7 Is A Superb  For Listening To Music On The Move
 - [https://www.forbes.com/sites/marksparrow/2023/02/05/reviewed-fiios-btr7-is-a-superb--for-listening-to-music-on-the-move/](https://www.forbes.com/sites/marksparrow/2023/02/05/reviewed-fiios-btr7-is-a-superb--for-listening-to-music-on-the-move/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 15:45:28+00:00
 - user: None

This handy little music player in incredibly versatile and can work with USB and Bluetooth connections. It supports a wide range of audio codecs and features advanced amplifiers and DACs.

## AI Art Accidentally Wins Destiny 2’s ‘Art Of The Week’ Fanart Contest
 - [https://www.forbes.com/sites/paultassi/2023/02/05/ai-art-accidentally-wins-destiny-2s-art-of-the-week-fanart-contest/](https://www.forbes.com/sites/paultassi/2023/02/05/ai-art-accidentally-wins-destiny-2s-art-of-the-week-fanart-contest/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 15:36:23+00:00
 - user: None

The Destiny 2 community has run into a situation where a piece of AI art actually won one of the slot’s in Bungie’s “Art of the Week” contest in the TWAB.

## Here’s Pedro Pascal Starring In HBO’s ‘Mario Kart,’ For SNL
 - [https://www.forbes.com/sites/paultassi/2023/02/05/heres-pedro-pascal-starring-in-hbos-mario-kart-for-snl/](https://www.forbes.com/sites/paultassi/2023/02/05/heres-pedro-pascal-starring-in-hbos-mario-kart-for-snl/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 15:15:00+00:00
 - user: None

SNL took that idea and ran with it by casting Pedro Pascal as Mario in a gritty, HBO-ified version of Mario Kart. In it, Pascal’s Mario must escort a former princess across a desolate Rainbow Road while being pursued by Bowser and sentient fungus…Goombas. Clever.

## ‘Hogwarts Legacy’ Reviews Drop Tomorrow, Answering Its Biggest Question
 - [https://www.forbes.com/sites/paultassi/2023/02/05/hogwarts-legacy-reviews-drop-tomorrow-answering-its-biggest-question/](https://www.forbes.com/sites/paultassi/2023/02/05/hogwarts-legacy-reviews-drop-tomorrow-answering-its-biggest-question/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 14:36:04+00:00
 - user: None

Hogwarts Legacy reviews will be live tomorrow across outlets that got codes, which is four days before release on Friday the 10th, but just one day before early access, where the Deluxe/Collector’s Editions will let everyone play on Tuesday.

## A Psychologist Suggests 2 Ways To Care For A Loved One Who Is Struggling With Anxiety
 - [https://www.forbes.com/sites/traversmark/2023/02/05/a-psychologist-suggests-2-ways-to-care-for-a-loved-one-who-is-struggling-with-anxiety/](https://www.forbes.com/sites/traversmark/2023/02/05/a-psychologist-suggests-2-ways-to-care-for-a-loved-one-who-is-struggling-with-anxiety/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 14:35:27+00:00
 - user: None

Not letting a loved one’s anxiety disorder derail your relationship with them is not easy. Here’s how to be there for them through thick and thin.

## Netflix Account Sharing May Still Be Safe For The Time Being
 - [https://www.forbes.com/sites/davidphelan/2023/02/05/netflix-account-sharing-may-still-be-safe-for-the-time-being-password-crackdown/](https://www.forbes.com/sites/davidphelan/2023/02/05/netflix-account-sharing-may-still-be-safe-for-the-time-being-password-crackdown/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 14:04:56+00:00
 - user: None

Good news for password sharers, for now at least.

## Netflix ‘Squid Game’ Reality TV Show Contestants Shocked That ‘Squid Game’ Isn’t Actually Fun
 - [https://www.forbes.com/sites/erikkain/2023/02/05/netflix-squid-game-reality-tv-show-contestants-shocked-that-squid-game-isnt-actually-fun/](https://www.forbes.com/sites/erikkain/2023/02/05/netflix-squid-game-reality-tv-show-contestants-shocked-that-squid-game-isnt-actually-fun/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 14:00:00+00:00
 - user: None

Contestants in the Squid Game reality TV show that's being filmed for Netflix report that it's not all sunshine and roses after all. Shocking!

## How Hard Should We Push Generative AI ChatGPT Into Spewing Hate Speech, Asks AI Ethics And AI Law
 - [https://www.forbes.com/sites/lanceeliot/2023/02/05/how-hard-should-we-push-generative-ai-chatgpt-into-spewing-hate-speech-asks-ai-ethics-and-ai-law/](https://www.forbes.com/sites/lanceeliot/2023/02/05/how-hard-should-we-push-generative-ai-chatgpt-into-spewing-hate-speech-asks-ai-ethics-and-ai-law/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 13:00:00+00:00
 - user: None

There is an effort afoot to try and get generative AI ChatGPT to produce foul essays that include hate speech and the like. This seems on the surface gallant but we might want to consider how far this ought to go. Here's the scoop.

## ‘Hogwarts Legacy’ PC System Requirements Explained: Minimum And Recommended Specs
 - [https://www.forbes.com/sites/erikkain/2023/02/05/hogwarts-legacy-pc-system-requirements-explained-minimum-and-recommended-specs/](https://www.forbes.com/sites/erikkain/2023/02/05/hogwarts-legacy-pc-system-requirements-explained-minimum-and-recommended-specs/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 13:00:00+00:00
 - user: None

Hogwarts Legacy PC minimum and recommended settings explained.

## Three Things That ‘Armored Core VI’ Really Needs To Get Right
 - [https://www.forbes.com/sites/olliebarder/2023/02/05/three-things-that-armored-core-vi-really-needs-to-get-right/](https://www.forbes.com/sites/olliebarder/2023/02/05/three-things-that-armored-core-vi-really-needs-to-get-right/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 07:34:47+00:00
 - user: None

Now that 'Armored Core VI' is very much a real thing, it’s worth looking back at the series as a whole and what this new game needs to get right.

## S.H.Figuarts Celebrates Its 15th Anniversary With A New Event In Akihabara
 - [https://www.forbes.com/sites/olliebarder/2023/02/05/shfiguarts-celebrates-its-15th-anniversary-with-a-new-event-in-akihabara/](https://www.forbes.com/sites/olliebarder/2023/02/05/shfiguarts-celebrates-its-15th-anniversary-with-a-new-event-in-akihabara/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 05:18:03+00:00
 - user: None

Since the launch of the S.H.Figuarts toyline back in 2008, it has had a surprisingly varied line-up of figures since then. So it seems only fitting to have its 15th anniversary celebrated with a new event in Akihabara.

## New ‘Armored Core VI’ Interview With Producer Yasunori Ogura Proves This Will Be No ‘Soulsborne’ Spin-Off
 - [https://www.forbes.com/sites/olliebarder/2023/02/04/new-armored-core-vi-interview-with-producer-yasunori-ogura-proves-this-will-be-no-soulsborne-spin-off/](https://www.forbes.com/sites/olliebarder/2023/02/04/new-armored-core-vi-interview-with-producer-yasunori-ogura-proves-this-will-be-no-soulsborne-spin-off/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 04:54:07+00:00
 - user: None

Following the interview at IGN shortly after 'Armored Core VI’s' announcement, producer Yasunori Ogura has spoken at the recent Taipei Game Show and reiterated that this will be very much a proper 'Armored Core' game.

## Today’s Wordle #596 Hint, Clues And Answer For Sunday, February 5th
 - [https://www.forbes.com/sites/erikkain/2023/02/04/todays-wordle-596-hint-clues-and-answer-for-sunday-february-5th/](https://www.forbes.com/sites/erikkain/2023/02/04/todays-wordle-596-hint-clues-and-answer-for-sunday-february-5th/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 03:30:00+00:00
 - user: None

How to solve today's Wordle. Hints, clues and everything you need to get your guessing game on.

## Today’s ‘Heardle’ Answer And Clues For Sunday, February 5
 - [https://www.forbes.com/sites/krisholt/2023/02/04/todays-heardle-answer-and-clues-for-sunday-february-5/](https://www.forbes.com/sites/krisholt/2023/02/04/todays-heardle-answer-and-clues-for-sunday-february-5/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 01:15:36+00:00
 - user: None

Here's today's 'Heardle' song, along with some hints.

## Today’s ‘Quordle’ Answers And Clues For Sunday, February 5
 - [https://www.forbes.com/sites/krisholt/2023/02/04/todays-quordle-answers-and-clues-for-sunday-february-5/](https://www.forbes.com/sites/krisholt/2023/02/04/todays-quordle-answers-and-clues-for-sunday-february-5/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 01:00:25+00:00
 - user: None

Some hints and the solution for today's 'Quordle' are just ahead.

## Webb Telescope Switched Off And On Again After Strike By Galactic Rays, Says NASA
 - [https://www.forbes.com/sites/jamiecartereurope/2023/02/04/webb-telescope-switched-off-and-on-again-after-strike-by-galactic-rays-says-nasa/](https://www.forbes.com/sites/jamiecartereurope/2023/02/04/webb-telescope-switched-off-and-on-again-after-strike-by-galactic-rays-says-nasa/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-02-05 00:15:00+00:00
 - user: None

A science instrument on the James Webb Space Telescope (JWST) has been switched off and on again by NASA engineers after the spacecraft was struck by galactic rays.
