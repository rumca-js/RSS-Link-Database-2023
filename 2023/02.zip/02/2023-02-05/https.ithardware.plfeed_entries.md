# Source IT hardware PL, Source URL:https://ithardware.pl/feed, Source language: pl-PL

## Lepsza jakość wideo dzięki AI. Chrome 110 dodaje wsparcie dla NVIDIA RTX Video Super Resolution
 - [https://ithardware.pl/aktualnosci/lepsza_jakosc_wideo_dzieki_ai_chrome_110_dodaje_wsparcie_dla_nvidia_rtx_video_super_resolution-25681.html](https://ithardware.pl/aktualnosci/lepsza_jakosc_wideo_dzieki_ai_chrome_110_dodaje_wsparcie_dla_nvidia_rtx_video_super_resolution-25681.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 21:30:50+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25681_1.jpg" />            Przeglądarka Google Chrome w wydaniu 110 dodaje obsługę funkcji NVIDIA RTX Video Super Resolution (via VideoCardz). Zieloni ogłosili, że technologia pozwoli na upscaling do 4K z wykorzystaniem AI na przeglądarkach Chrome oraz Edge. Mimo wspierania...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/lepsza_jakosc_wideo_dzieki_ai_chrome_110_dodaje_wsparcie_dla_nvidia_rtx_video_super_resolution-25681.html">https://ithardware.pl/aktualnosci/lepsza_jakosc_wideo_dzieki_ai_chrome_110_dodaje_wsparcie_dla_nvidia_rtx_video_super_resolution-25681.html</a></p>

## vivo X90 i X90 Pro debiutują globalnie. Na liście krajów jest też Polska
 - [https://ithardware.pl/aktualnosci/vivo_x90_i_x90_pro_debiutuja_globalnie_na_liscie_krajow_jest_tez_polska-25685.html](https://ithardware.pl/aktualnosci/vivo_x90_i_x90_pro_debiutuja_globalnie_na_liscie_krajow_jest_tez_polska-25685.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 21:00:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25685_1.jpg" />            Seria vivo X90 została zaprezentowana w listopadzie zeszłego roku w Chinach. Kilka miesięcy po tym wydarzeniu smartfony debiutują globalnie a jeden z nich&nbsp;trafi&nbsp;r&oacute;wnież do Polski. Oto co oferują wspomniane urządzenia.

Seria...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/vivo_x90_i_x90_pro_debiutuja_globalnie_na_liscie_krajow_jest_tez_polska-25685.html">https://ithardware.pl/aktualnosci/vivo_x90_i_x90_pro_debiutuja_globalnie_na_liscie_krajow_jest_tez_polska-25685.html</a></p>

## Windows 11 bez bloatware działa z 2 GB RAM i 8 GB HDD. Gdzie Microsoft nie może...
 - [https://ithardware.pl/aktualnosci/windows_11_bez_bloatware_dziala_z_2_gb_ram_i_8_gb_hdd_gdzie_microsoft_nie_moze-25684.html](https://ithardware.pl/aktualnosci/windows_11_bez_bloatware_dziala_z_2_gb_ram_i_8_gb_hdd_gdzie_microsoft_nie_moze-25684.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 20:18:50+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25684_1.jpg" />            Gdzie Microsoft nie może (albo nie chce), tam pojawia się społeczność. Starsze wersje&nbsp;Windowsa już wielokrotnie były modyfikowane (niekt&oacute;rzy mogą pamiętać świetne narzędzie nLite, pomagające odchudzać Windowsa XP), a modderzy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/windows_11_bez_bloatware_dziala_z_2_gb_ram_i_8_gb_hdd_gdzie_microsoft_nie_moze-25684.html">https://ithardware.pl/aktualnosci/windows_11_bez_bloatware_dziala_z_2_gb_ram_i_8_gb_hdd_gdzie_microsoft_nie_moze-25684.html</a></p>

## To będzie hit! Cyberpunk 2077 otrzyma znaczne graficzne usprawnienia
 - [https://ithardware.pl/aktualnosci/to_bedzie_hit_najpopularniejszy_modder_wiedzmina_3_bierze_sie_za_cyberpunk_2077-25683.html](https://ithardware.pl/aktualnosci/to_bedzie_hit_najpopularniejszy_modder_wiedzmina_3_bierze_sie_za_cyberpunk_2077-25683.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 19:24:50+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25683_1.jpg" />            Cyberpunk&nbsp;2077&nbsp;otrzyma ogromną aktualizację wizualną, kt&oacute;ra wcale nie pochodzi od CDPR. Najpopularnieszy modder Wiedźmina 3 ogłosił, że teraz na warsztat bierze najnowszą grę naszego rodzimego studia i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/to_bedzie_hit_najpopularniejszy_modder_wiedzmina_3_bierze_sie_za_cyberpunk_2077-25683.html">https://ithardware.pl/aktualnosci/to_bedzie_hit_najpopularniejszy_modder_wiedzmina_3_bierze_sie_za_cyberpunk_2077-25683.html</a></p>

## Dragon Age: Dreadwolf. Do sieci wyciekł fragment rozgrywki
 - [https://ithardware.pl/aktualnosci/dragon_age_dreadwolf_do_sieci_wyciekl_fragment_rozgrywki-25682.html](https://ithardware.pl/aktualnosci/dragon_age_dreadwolf_do_sieci_wyciekl_fragment_rozgrywki-25682.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 17:30:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25682_1.jpg" />            Dragon Age: Dreadwolf powstaje od dłuższego czasu, lecz BioWare nadal nie ujawnia konkret&oacute;w dotyczących gry. Studio wyręczyli leakerzy, kt&oacute;rzy wrzucili do sieci nowe informacje o produkcji i fragment rozgrywki.

Do sieci trafiły nowe...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dragon_age_dreadwolf_do_sieci_wyciekl_fragment_rozgrywki-25682.html">https://ithardware.pl/aktualnosci/dragon_age_dreadwolf_do_sieci_wyciekl_fragment_rozgrywki-25682.html</a></p>

## Najlepsza pamięć RAM 2022 – TOP 10
 - [https://ithardware.pl/rankingi/najlepsza_pamiec_ram_2022_top_10-25472.html](https://ithardware.pl/rankingi/najlepsza_pamiec_ram_2022_top_10-25472.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 16:15:30+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25472_1.jpg" />            W 2022 roku na łamach serwisu ITHardware pojawiło się sporo naprawdę ciekawych zestaw&oacute;w pamięci RAM. Był to rok wielkich premier moduł&oacute;w DDR5, kt&oacute;re &ndash; powoli, bo powoli &ndash; wypierają starszy standard DDR4....
            <p>Pełna wersja strony <a href="https://ithardware.pl/rankingi/najlepsza_pamiec_ram_2022_top_10-25472.html">https://ithardware.pl/rankingi/najlepsza_pamiec_ram_2022_top_10-25472.html</a></p>

## Microsoft wyświetla więcej reklam na swojej platformie z aplikacjami
 - [https://ithardware.pl/aktualnosci/microsoft_wyswietla_wiecej_reklam_na_swojej_platformie_z_aplikacjami-25680.html](https://ithardware.pl/aktualnosci/microsoft_wyswietla_wiecej_reklam_na_swojej_platformie_z_aplikacjami-25680.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 15:00:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25680_1.jpg" />            Microsoft wprowadza jeszcze więcej reklam w Microsoft Store, dzięki kt&oacute;rym będzie zarabiał na wyświetlaniu promowanych aplikacji. Z pewnością ucieszą się użytkownicy, kt&oacute;rym brakowało tego rodzaju treści na platformie z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_wyswietla_wiecej_reklam_na_swojej_platformie_z_aplikacjami-25680.html">https://ithardware.pl/aktualnosci/microsoft_wyswietla_wiecej_reklam_na_swojej_platformie_z_aplikacjami-25680.html</a></p>

## Wykorzystał ponad 3,5-kilogramowy blok miedzi do chłodzenia Intel Core i9. Oto rezultaty
 - [https://ithardware.pl/aktualnosci/wykorzystal_ponad_3_5_kilogramowy_blok_miedzi_do_chlodzenia_intel_core_i9_oto_rezultaty-25678.html](https://ithardware.pl/aktualnosci/wykorzystal_ponad_3_5_kilogramowy_blok_miedzi_do_chlodzenia_intel_core_i9_oto_rezultaty-25678.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 12:10:10+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25678_1.jpg" />            Członek Reddita, znany na platformie pod pseudonimem&nbsp;That-Desktop-User, udostępnił zdjęcie komputera z gigantycznym blokiem miedzi w miejscu chłodzenia CPU. Jak się okazuje, autor wszedł w posiadanie ponad 3,5-kilogramowego bloku miedzi,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wykorzystal_ponad_3_5_kilogramowy_blok_miedzi_do_chlodzenia_intel_core_i9_oto_rezultaty-25678.html">https://ithardware.pl/aktualnosci/wykorzystal_ponad_3_5_kilogramowy_blok_miedzi_do_chlodzenia_intel_core_i9_oto_rezultaty-25678.html</a></p>

## Najlepsze głośniki 2022 - TOP 10
 - [https://ithardware.pl/rankingi/najlepsze_glosniki_2022_top_10-25670.html](https://ithardware.pl/rankingi/najlepsze_glosniki_2022_top_10-25670.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 11:50:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25670_1.jpg" />            Jakiś czas temu opublikowaliśmy artykuł koncentrujący się na polecanych słuchawkach dla graczy, ale na naszym portalu testujemy także inne produkty z kategorii audio, więc postanowiliśmy zrobić r&oacute;wnież listę rekomendowanych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/rankingi/najlepsze_glosniki_2022_top_10-25670.html">https://ithardware.pl/rankingi/najlepsze_glosniki_2022_top_10-25670.html</a></p>

## Crysis działa na chińskiej karcie graficznej. Konkurencja może się już obawiać?
 - [https://ithardware.pl/aktualnosci/crysis_dziala_na_chinskiej_karcie_graficznej_konkurencja_moze_sie_juz_obawiac-25674.html](https://ithardware.pl/aktualnosci/crysis_dziala_na_chinskiej_karcie_graficznej_konkurencja_moze_sie_juz_obawiac-25674.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 11:07:10+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25674_1.jpg" />            Na Twitterze pojawił się wpis, w kt&oacute;ry posiadacz chińskiej karty MTT S80 chwali się uruchomieniem na niej oryginalnego Crysisa. Gra działała na DirectX 9. Wygląda zatem na to, że obsługa starszych wersji API Microsoftu nie stanowi...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/crysis_dziala_na_chinskiej_karcie_graficznej_konkurencja_moze_sie_juz_obawiac-25674.html">https://ithardware.pl/aktualnosci/crysis_dziala_na_chinskiej_karcie_graficznej_konkurencja_moze_sie_juz_obawiac-25674.html</a></p>

## Zobaczcie jak skręcają wszystkie 4 koła w Tesli Cybertruck
 - [https://ithardware.pl/aktualnosci/zobaczcie_jak_skrecaja_wszystkie_4_kola_w_tesli_cybertruck-25677.html](https://ithardware.pl/aktualnosci/zobaczcie_jak_skrecaja_wszystkie_4_kola_w_tesli_cybertruck-25677.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 10:37:10+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25677_1.jpg" />            Ujawniono nowe wideo przedstawiające imponujący układ kierowniczy Tesli Cybertruck podczas jazdy &ndash; dając nam najlepszy jak dotąd podgląd, jak działają w tym przypadku&nbsp;wszystkie 4 skrętne koła.

Niekt&oacute;re auta oferują...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/zobaczcie_jak_skrecaja_wszystkie_4_kola_w_tesli_cybertruck-25677.html">https://ithardware.pl/aktualnosci/zobaczcie_jak_skrecaja_wszystkie_4_kola_w_tesli_cybertruck-25677.html</a></p>

## Google pracuje nad własną technologią zbliżoną do ChatGPT
 - [https://ithardware.pl/aktualnosci/google_pracuje_nad_wlasna_technologia_zblizona_do_chatgpt-25675.html](https://ithardware.pl/aktualnosci/google_pracuje_nad_wlasna_technologia_zblizona_do_chatgpt-25675.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-02-05 10:00:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25675_1.jpg" />            ChatGPT nowe narzędzie, kt&oacute;re wstrząsnęło samym Google rozwija się w ekspresowym tempie. Według danych w styczniu osiągnęło 100 milion&oacute;w aktywnych użytkownik&oacute;w. Google jednak już szykuje odpowiedź...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/google_pracuje_nad_wlasna_technologia_zblizona_do_chatgpt-25675.html">https://ithardware.pl/aktualnosci/google_pracuje_nad_wlasna_technologia_zblizona_do_chatgpt-25675.html</a></p>
