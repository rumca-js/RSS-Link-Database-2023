# Source CNBC, Source URL:https://www.cnbc.com/id/100727362/device/rss/rss.html, Source language: en-US

## Optimism on Chinese stocks soars to five-year highs
 - [https://www.cnbc.com/2023/02/06/optimism-on-chinese-stocks-soars-to-five-year-highs.html](https://www.cnbc.com/2023/02/06/optimism-on-chinese-stocks-soars-to-five-year-highs.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-02-05 23:45:35+00:00
 - user: None

Money is flowing into mainland Chinese and Hong Kong stocks in ways not seen since 2018, according to research firm EPFR Global.

## Elon Musk says Twitter is ‘trending to breakeven’ after near bankruptcy
 - [https://www.cnbc.com/2023/02/05/elon-musk-says-twitter-trending-to-breakeven-after-near-bankruptcy.html](https://www.cnbc.com/2023/02/05/elon-musk-says-twitter-trending-to-breakeven-after-near-bankruptcy.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-02-05 23:28:58+00:00
 - user: None

Elon Musk tweeted Sunday that the last few months have been "extremely tough," but said that Twitter is "now trending to break even."

## The 7 most in-demand tech skills for freelancers—many pay more than $125 an hour
 - [https://www.cnbc.com/2023/02/05/most-in-demand-tech-skills-for-freelancersmany-pay-more-than-125-an-hour.html](https://www.cnbc.com/2023/02/05/most-in-demand-tech-skills-for-freelancersmany-pay-more-than-125-an-hour.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-02-05 15:00:01+00:00
 - user: None

Tech skills are in high demand, and many can pay more than $100 per hour. These include full stack developer, mobile app developer and web designer.

## U.S. military shoots down suspected Chinese surveillance balloon
 - [https://www.cnbc.com/2023/02/04/us-military-prepares-to-take-down-suspected-chinese-surveillance-balloon.html](https://www.cnbc.com/2023/02/04/us-military-prepares-to-take-down-suspected-chinese-surveillance-balloon.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-02-05 07:14:40+00:00
 - user: None

The U.S. military on Saturday shot down a suspected Chinese surveillance balloon, according to media reports.
