# Source Hacker News - frontpage, Source URL:https://hnrss.org/frontpage, Source language: en-US

## Stable Attribution
 - [https://www.stableattribution.com](https://www.stableattribution.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 22:11:01+00:00
 - user: None

<p>Article URL: <a href="https://www.stableattribution.com">https://www.stableattribution.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34670136">https://news.ycombinator.com/item?id=34670136</a></p>
<p>Points: 52</p>
<p># Comments: 27</p>

## The rise of universities’ diversity bureaucrats (2018)
 - [https://www.economist.com/the-economist-explains/2018/05/08/the-rise-of-universities-diversity-bureaucrats](https://www.economist.com/the-economist-explains/2018/05/08/the-rise-of-universities-diversity-bureaucrats)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 21:14:33+00:00
 - user: None

<p>Article URL: <a href="https://www.economist.com/the-economist-explains/2018/05/08/the-rise-of-universities-diversity-bureaucrats">https://www.economist.com/the-economist-explains/2018/05/08/the-rise-of-universities-diversity-bureaucrats</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34669481">https://news.ycombinator.com/item?id=34669481</a></p>
<p>Points: 37</p>
<p># Comments: 11</p>

## Artificial intelligence just lost a leader
 - [https://rjlipton.wpcomstaging.com/2023/02/05/artificial-intelligence-just-lost-a-leader/](https://rjlipton.wpcomstaging.com/2023/02/05/artificial-intelligence-just-lost-a-leader/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 20:48:05+00:00
 - user: None

<p>Article URL: <a href="https://rjlipton.wpcomstaging.com/2023/02/05/artificial-intelligence-just-lost-a-leader/">https://rjlipton.wpcomstaging.com/2023/02/05/artificial-intelligence-just-lost-a-leader/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34669171">https://news.ycombinator.com/item?id=34669171</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Finland’s most-wanted hacker nabbed in France
 - [https://krebsonsecurity.com/2023/02/finlands-most-wanted-hacker-nabbed-in-france/](https://krebsonsecurity.com/2023/02/finlands-most-wanted-hacker-nabbed-in-france/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 20:44:09+00:00
 - user: None

<p>Article URL: <a href="https://krebsonsecurity.com/2023/02/finlands-most-wanted-hacker-nabbed-in-france/">https://krebsonsecurity.com/2023/02/finlands-most-wanted-hacker-nabbed-in-france/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34669124">https://news.ycombinator.com/item?id=34669124</a></p>
<p>Points: 61</p>
<p># Comments: 22</p>

## Liquid modernity? (2014)
 - [https://understandingsociety.blogspot.com/2014/05/liquid-modernity.html](https://understandingsociety.blogspot.com/2014/05/liquid-modernity.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 20:36:25+00:00
 - user: None

<p>Article URL: <a href="https://understandingsociety.blogspot.com/2014/05/liquid-modernity.html">https://understandingsociety.blogspot.com/2014/05/liquid-modernity.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34669043">https://news.ycombinator.com/item?id=34669043</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Intel’s Dunnington: Core 2 Goes Dun Dun Dun
 - [https://chipsandcheese.com/2023/02/05/intels-dunnington-core-2-goes-dun-dun-dun/](https://chipsandcheese.com/2023/02/05/intels-dunnington-core-2-goes-dun-dun-dun/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 20:15:16+00:00
 - user: None

<p>Article URL: <a href="https://chipsandcheese.com/2023/02/05/intels-dunnington-core-2-goes-dun-dun-dun/">https://chipsandcheese.com/2023/02/05/intels-dunnington-core-2-goes-dun-dun-dun/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34668791">https://news.ycombinator.com/item?id=34668791</a></p>
<p>Points: 11</p>
<p># Comments: 5</p>

## Getty Images v. Stability AI – Complaint
 - [https://copyrightlately.com/pdfviewer/getty-images-v-stability-ai-complaint/](https://copyrightlately.com/pdfviewer/getty-images-v-stability-ai-complaint/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 19:58:33+00:00
 - user: None

<p>Article URL: <a href="https://copyrightlately.com/pdfviewer/getty-images-v-stability-ai-complaint/">https://copyrightlately.com/pdfviewer/getty-images-v-stability-ai-complaint/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34668565">https://news.ycombinator.com/item?id=34668565</a></p>
<p>Points: 65</p>
<p># Comments: 36</p>

## The cult of conformity in Silicon Valley [video]
 - [https://www.youtube.com/watch?v=ia7IKW0yuG0](https://www.youtube.com/watch?v=ia7IKW0yuG0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 19:25:59+00:00
 - user: None

<p>Article URL: <a href="https://www.youtube.com/watch?v=ia7IKW0yuG0">https://www.youtube.com/watch?v=ia7IKW0yuG0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34668098">https://news.ycombinator.com/item?id=34668098</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## FreeCAD Day 2023: Report and Continued Discussion
 - [https://forum.freecad.org/viewtopic.php?t=75768](https://forum.freecad.org/viewtopic.php?t=75768)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 19:19:24+00:00
 - user: None

<p>Article URL: <a href="https://forum.freecad.org/viewtopic.php?t=75768">https://forum.freecad.org/viewtopic.php?t=75768</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34668001">https://news.ycombinator.com/item?id=34668001</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Don’t teach during code reviews
 - [https://www.michaelagreiler.com/teach-during-code-reviews/](https://www.michaelagreiler.com/teach-during-code-reviews/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 18:55:32+00:00
 - user: None

<p>Article URL: <a href="https://www.michaelagreiler.com/teach-during-code-reviews/">https://www.michaelagreiler.com/teach-during-code-reviews/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34667708">https://news.ycombinator.com/item?id=34667708</a></p>
<p>Points: 42</p>
<p># Comments: 23</p>

## A Brief History of Parafilm
 - [https://cell.substack.com/p/parafilm](https://cell.substack.com/p/parafilm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 18:37:00+00:00
 - user: None

<p>Article URL: <a href="https://cell.substack.com/p/parafilm">https://cell.substack.com/p/parafilm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34667465">https://news.ycombinator.com/item?id=34667465</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Ask HN: Employers, why do you want us back in the office?
 - [https://news.ycombinator.com/item?id=34667411](https://news.ycombinator.com/item?id=34667411)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 18:32:32+00:00
 - user: None

<p>Many of us were remote, and now many of us are being asked to come back?  Knowing office workers all work with remote people in other offices, and there’s not much in-office dynamic like maybe there was 20 years ago, what are your primary motivations dragging us back into the office?  Nearly every meeting I’ve had in an office since 2014 has been a video conference with remote people.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34667411">https://news.ycombinator.com/item?id=34667411</a></p>
<p>Points: 96</p>
<p># Comments: 167</p>

## Ask HN: Share Your YouTube Channel
 - [https://news.ycombinator.com/item?id=34667378](https://news.ycombinator.com/item?id=34667378)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 18:29:49+00:00
 - user: None

<p>Anyone have their own channel?<p>Would love to discover some interesting new YouTube channels from hacker news members.<p>Edit: (Please post a brief description too)</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34667378">https://news.ycombinator.com/item?id=34667378</a></p>
<p>Points: 28</p>
<p># Comments: 25</p>

## What We Learned from Building GovSlack
 - [https://slack.engineering/what-we-learned-from-building-govslack/](https://slack.engineering/what-we-learned-from-building-govslack/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 18:00:58+00:00
 - user: None

<p>Article URL: <a href="https://slack.engineering/what-we-learned-from-building-govslack/">https://slack.engineering/what-we-learned-from-building-govslack/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34667077">https://news.ycombinator.com/item?id=34667077</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Gattaca is still pertinent 25 years later
 - [https://www.nature.com/articles/s41588-022-01242-5](https://www.nature.com/articles/s41588-022-01242-5)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 17:59:59+00:00
 - user: None

<p>Article URL: <a href="https://www.nature.com/articles/s41588-022-01242-5">https://www.nature.com/articles/s41588-022-01242-5</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34667067">https://news.ycombinator.com/item?id=34667067</a></p>
<p>Points: 141</p>
<p># Comments: 129</p>

## Ask HN: Share your favorite YouTube channels focused on mastering a skill/craft
 - [https://news.ycombinator.com/item?id=34666777](https://news.ycombinator.com/item?id=34666777)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 17:35:29+00:00
 - user: None

<p>I've just discovered channels with restoration videos on Youtube and these guys are true masters at their craft!
https://www.youtube.com/watch?v=U2jNeObHnZY<p>Any other authentic channels I should check out about the mastery of a skill or craft?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34666777">https://news.ycombinator.com/item?id=34666777</a></p>
<p>Points: 56</p>
<p># Comments: 42</p>

## The Circumnavigators: Amateur radio balloons flying around the world
 - [https://qrp-labs.com/circumnavigators.html](https://qrp-labs.com/circumnavigators.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 16:42:36+00:00
 - user: None

<p>Article URL: <a href="https://qrp-labs.com/circumnavigators.html">https://qrp-labs.com/circumnavigators.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34666311">https://news.ycombinator.com/item?id=34666311</a></p>
<p>Points: 22</p>
<p># Comments: 3</p>

## If you're happy with OpenBSD, probably any computer is good enough
 - [http://muezza.ca/thoughts/openbsd_imac_g4/](http://muezza.ca/thoughts/openbsd_imac_g4/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 16:42:11+00:00
 - user: None

<p>Article URL: <a href="http://muezza.ca/thoughts/openbsd_imac_g4/">http://muezza.ca/thoughts/openbsd_imac_g4/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34666305">https://news.ycombinator.com/item?id=34666305</a></p>
<p>Points: 108</p>
<p># Comments: 37</p>

## US Physician Blasts 'Lucrative System of For-Profit Medicine'
 - [https://www.commondreams.org/news/physician-for-profit-healthcare](https://www.commondreams.org/news/physician-for-profit-healthcare)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 16:37:17+00:00
 - user: None

<p>Article URL: <a href="https://www.commondreams.org/news/physician-for-profit-healthcare">https://www.commondreams.org/news/physician-for-profit-healthcare</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34666241">https://news.ycombinator.com/item?id=34666241</a></p>
<p>Points: 25</p>
<p># Comments: 5</p>

## Build a Linux wireless router out of spare parts in 1998
 - [http://www.rage.net/wireless/wireless_howto.html](http://www.rage.net/wireless/wireless_howto.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 16:27:20+00:00
 - user: None

<p>Article URL: <a href="http://www.rage.net/wireless/wireless_howto.html">http://www.rage.net/wireless/wireless_howto.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34666142">https://news.ycombinator.com/item?id=34666142</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Archiving in the Time of Streaming
 - [http://ascii.textfiles.com/archives/5443](http://ascii.textfiles.com/archives/5443)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 15:58:27+00:00
 - user: None

<p>Article URL: <a href="http://ascii.textfiles.com/archives/5443">http://ascii.textfiles.com/archives/5443</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665878">https://news.ycombinator.com/item?id=34665878</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Ghost Boat with Garmin GPS Leads Father-Son Duo to Man Overboard
 - [https://www.garmin.com/en-US/blog/marine/ghost-boat-with-garmin-gps-leads-father-son-duo-to-man-overboard/](https://www.garmin.com/en-US/blog/marine/ghost-boat-with-garmin-gps-leads-father-son-duo-to-man-overboard/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 15:47:49+00:00
 - user: None

<p>Article URL: <a href="https://www.garmin.com/en-US/blog/marine/ghost-boat-with-garmin-gps-leads-father-son-duo-to-man-overboard/">https://www.garmin.com/en-US/blog/marine/ghost-boat-with-garmin-gps-leads-father-son-duo-to-man-overboard/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665800">https://news.ycombinator.com/item?id=34665800</a></p>
<p>Points: 49</p>
<p># Comments: 35</p>

## NSA wooing thousands of laid-off Big Tech workers for spy agency's hiring spree
 - [https://www.washingtontimes.com/news/2023/feb/3/nsa-wooing-thousands-laid-big-tech-workers-spy-age/](https://www.washingtontimes.com/news/2023/feb/3/nsa-wooing-thousands-laid-big-tech-workers-spy-age/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 15:47:38+00:00
 - user: None

<p>Article URL: <a href="https://www.washingtontimes.com/news/2023/feb/3/nsa-wooing-thousands-laid-big-tech-workers-spy-age/">https://www.washingtontimes.com/news/2023/feb/3/nsa-wooing-thousands-laid-big-tech-workers-spy-age/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665797">https://news.ycombinator.com/item?id=34665797</a></p>
<p>Points: 64</p>
<p># Comments: 60</p>

## Balloon Wars (2010)
 - [https://steveblank.com/2010/01/28/balloon-wars/](https://steveblank.com/2010/01/28/balloon-wars/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 15:41:17+00:00
 - user: None

<p>Article URL: <a href="https://steveblank.com/2010/01/28/balloon-wars/">https://steveblank.com/2010/01/28/balloon-wars/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665748">https://news.ycombinator.com/item?id=34665748</a></p>
<p>Points: 15</p>
<p># Comments: 5</p>

## HSBC's Money Laundering Scandal 2012, money laudering for Mexican Drug gangs
 - [https://www.investopedia.com/stock-analysis/2013/investing-news-for-jan-29-hsbcs-money-laundering-scandal-hbc-scbff-ing-cs-rbs0129.aspx](https://www.investopedia.com/stock-analysis/2013/investing-news-for-jan-29-hsbcs-money-laundering-scandal-hbc-scbff-ing-cs-rbs0129.aspx)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 15:16:57+00:00
 - user: None

<p>Article URL: <a href="https://www.investopedia.com/stock-analysis/2013/investing-news-for-jan-29-hsbcs-money-laundering-scandal-hbc-scbff-ing-cs-rbs0129.aspx">https://www.investopedia.com/stock-analysis/2013/investing-news-for-jan-29-hsbcs-money-laundering-scandal-hbc-scbff-ing-cs-rbs0129.aspx</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665532">https://news.ycombinator.com/item?id=34665532</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Ask HN: Longer Discussions in HN?
 - [https://news.ycombinator.com/item?id=34665272](https://news.ycombinator.com/item?id=34665272)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 14:44:23+00:00
 - user: None

<p>I follow posts from Hacker News using RSS, specifically <a href="https://hnrss.github.io/" rel="nofollow">https://hnrss.github.io/</a>. It's great to consume posts at my own pace, but often a discussion is already dead when I participate.<p>It's an acceptable trade-off to me. But I wonder if others would also be interested in longer term discussions, and if there could be a way to have them. I thought about old forums, where old threads get bumped even if they were created years ago, and wondered if an hybrid model could be of interest to HN users.<p>Just a thought, I'm glad to have this site as is. Enjoy your Sunday everyone!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665272">https://news.ycombinator.com/item?id=34665272</a></p>
<p>Points: 27</p>
<p># Comments: 18</p>

## Ask HN: Feeling Hopeless and Lost at 23
 - [https://news.ycombinator.com/item?id=34665256](https://news.ycombinator.com/item?id=34665256)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 14:42:21+00:00
 - user: None

<p>Friends keep telling me I should stfu and stop complaining but I'm genuinely depressed and looking for constructive feedback. I failed out of my universities CS program and ended up doing philosophy with a double minor in math and stats. It's my fault. I got cocky. My university is extremely cut throat when it comes to the CS program so even if I wouldn't have gotten in with really pushing myself, I would not be complaining right now. I failed intro to CS twice and passed on the 3rd try with a 52. Switched to philosophy after taking being put on suspension. Recovered my GPA (a bit) and finished university last year. Even though I shat the bed with university, I did a lot of hackathons, audited courses because of pure interest (through MIT open courseware), and getting internships. I ended up joining Shopify as a fullstack. But now, I really want to go back to school and learn things the traditional way because it feels too overwhelming. I can't work in the states because of tn visa regulations. My gpa is pathetic because of the failed courses in early years. I really don't have the patience to start a second degree at a third tier college/university because it's pointless to do so. I want to get into one of those online masters programs but let's be honest, with a pathetic 2.44 cgpa there is no way any masters program is gonna let me in. Seeking advice on what to do at this point</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665256">https://news.ycombinator.com/item?id=34665256</a></p>
<p>Points: 18</p>
<p># Comments: 26</p>

## Minimum viable process
 - [https://themarketplace.guide/minimum-viable-process](https://themarketplace.guide/minimum-viable-process)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 14:38:43+00:00
 - user: None

<p>Article URL: <a href="https://themarketplace.guide/minimum-viable-process">https://themarketplace.guide/minimum-viable-process</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665227">https://news.ycombinator.com/item?id=34665227</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## South Pole Topography
 - [https://brr.fyi/posts/south-pole-topography](https://brr.fyi/posts/south-pole-topography)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 14:31:23+00:00
 - user: None

<p>Article URL: <a href="https://brr.fyi/posts/south-pole-topography">https://brr.fyi/posts/south-pole-topography</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665174">https://news.ycombinator.com/item?id=34665174</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## All Circuits are Busy Now: The 1990 AT&T Long Distance Network Collapse (1995)
 - [https://users.csc.calpoly.edu/~jdalbey/SWE/Papers/att_collapse](https://users.csc.calpoly.edu/~jdalbey/SWE/Papers/att_collapse)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 14:13:29+00:00
 - user: None

<p>Article URL: <a href="https://users.csc.calpoly.edu/~jdalbey/SWE/Papers/att_collapse">https://users.csc.calpoly.edu/~jdalbey/SWE/Papers/att_collapse</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34665023">https://news.ycombinator.com/item?id=34665023</a></p>
<p>Points: 25</p>
<p># Comments: 4</p>

## Isn't ChatGPT unfair to the sources it scraped data from?
 - [https://news.ycombinator.com/item?id=34664998](https://news.ycombinator.com/item?id=34664998)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 14:08:54+00:00
 - user: None

<p>ChatGPT scraped data from various sources on the internet.<p>> The model was trained using text databases from the internet. This included a whopping 570GB of data obtained from books, webtexts, Wikipedia, articles and other pieces of writing on the internet. To be even more exact, 300 billion words were fed into the system.<p>I believe it's unfair to these sources that ChatGPT drives away their clicks, and in turn the ad income that would come with them.<p>Scraping data seems fine in contexts where clicks aren't driven away from the very site the data was scraped from. But in ChatGPT's case, it seems really unfair to these sources and the work that the authors put, as people would no longer even to attempt to go to these sources.<p>Can this start breaking the ad-based model of the internet, where a lot of sites rely upon the ad income to run servers?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34664998">https://news.ycombinator.com/item?id=34664998</a></p>
<p>Points: 35</p>
<p># Comments: 54</p>

## 10 Years of Scala.js
 - [https://www.scala-lang.org/blog-detail/2023/02/05/ten-years-of-scala-js.html](https://www.scala-lang.org/blog-detail/2023/02/05/ten-years-of-scala-js.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 14:04:04+00:00
 - user: None

<p>Article URL: <a href="https://www.scala-lang.org/blog-detail/2023/02/05/ten-years-of-scala-js.html">https://www.scala-lang.org/blog-detail/2023/02/05/ten-years-of-scala-js.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34664970">https://news.ycombinator.com/item?id=34664970</a></p>
<p>Points: 24</p>
<p># Comments: 5</p>

## Debian Reference (2021)
 - [https://www.debian.org/doc/manuals/debian-reference/index.en.html](https://www.debian.org/doc/manuals/debian-reference/index.en.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 13:49:48+00:00
 - user: None

<p>Article URL: <a href="https://www.debian.org/doc/manuals/debian-reference/index.en.html">https://www.debian.org/doc/manuals/debian-reference/index.en.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34664868">https://news.ycombinator.com/item?id=34664868</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Reimagining Matrices
 - [http://conal.net/blog/posts/reimagining-matrices](http://conal.net/blog/posts/reimagining-matrices)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 13:44:08+00:00
 - user: None

<p>Article URL: <a href="http://conal.net/blog/posts/reimagining-matrices">http://conal.net/blog/posts/reimagining-matrices</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34664826">https://news.ycombinator.com/item?id=34664826</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The founder of Teenage Engineering opens up to his creative space
 - [https://scandinavianmind.com/feature/human-touch-interview-jesper-kouthoofd-teenage-engineering](https://scandinavianmind.com/feature/human-touch-interview-jesper-kouthoofd-teenage-engineering)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 12:50:29+00:00
 - user: None

<p>Article URL: <a href="https://scandinavianmind.com/feature/human-touch-interview-jesper-kouthoofd-teenage-engineering">https://scandinavianmind.com/feature/human-touch-interview-jesper-kouthoofd-teenage-engineering</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34664513">https://news.ycombinator.com/item?id=34664513</a></p>
<p>Points: 24</p>
<p># Comments: 13</p>

## C Port of Ken Thompson's Space Travel
 - [https://github.com/mohd-akram/st](https://github.com/mohd-akram/st)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 12:37:27+00:00
 - user: None

<p>Article URL: <a href="https://github.com/mohd-akram/st">https://github.com/mohd-akram/st</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34664433">https://news.ycombinator.com/item?id=34664433</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Structured Concurrency Definition
 - [https://gavinhoward.com/2019/12/structured-concurrency-definition/](https://gavinhoward.com/2019/12/structured-concurrency-definition/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 12:28:57+00:00
 - user: None

<p>Article URL: <a href="https://gavinhoward.com/2019/12/structured-concurrency-definition/">https://gavinhoward.com/2019/12/structured-concurrency-definition/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34664373">https://news.ycombinator.com/item?id=34664373</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Make WSA (Windows Subsystem for Android) Run on Windows 10
 - [https://github.com/cinit/WSAPatch](https://github.com/cinit/WSAPatch)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 12:06:33+00:00
 - user: None

<p>Article URL: <a href="https://github.com/cinit/WSAPatch">https://github.com/cinit/WSAPatch</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34664223">https://news.ycombinator.com/item?id=34664223</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## Reversing UK ticket smart cards
 - [https://lobi.to/talks/papertickets/](https://lobi.to/talks/papertickets/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 11:54:50+00:00
 - user: None

<p>Article URL: <a href="https://lobi.to/talks/papertickets/">https://lobi.to/talks/papertickets/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34664146">https://news.ycombinator.com/item?id=34664146</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Lightweight Kubernetes Operators with WebAssembly – FOSDEM 2023 [video]
 - [https://www.youtube.com/watch?v=E5o81Wldshk](https://www.youtube.com/watch?v=E5o81Wldshk)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 11:24:51+00:00
 - user: None

<p>Article URL: <a href="https://www.youtube.com/watch?v=E5o81Wldshk">https://www.youtube.com/watch?v=E5o81Wldshk</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34663968">https://news.ycombinator.com/item?id=34663968</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Safe Foreign Callouts from Racket to Swift
 - [https://defn.io/2023/02/04/racket-foreign-callouts-to-swift/](https://defn.io/2023/02/04/racket-foreign-callouts-to-swift/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 11:13:41+00:00
 - user: None

<p>Article URL: <a href="https://defn.io/2023/02/04/racket-foreign-callouts-to-swift/">https://defn.io/2023/02/04/racket-foreign-callouts-to-swift/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34663895">https://news.ycombinator.com/item?id=34663895</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## How New Ideas Arise
 - [https://thereader.mitpress.mit.edu/how-new-ideas-arise/](https://thereader.mitpress.mit.edu/how-new-ideas-arise/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 09:59:12+00:00
 - user: None

<p>Article URL: <a href="https://thereader.mitpress.mit.edu/how-new-ideas-arise/">https://thereader.mitpress.mit.edu/how-new-ideas-arise/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34663494">https://news.ycombinator.com/item?id=34663494</a></p>
<p>Points: 10</p>
<p># Comments: 2</p>

## The Coming AI Hackers
 - [https://www.schneier.com/academic/archives/2021/04/the-coming-ai-hackers.html](https://www.schneier.com/academic/archives/2021/04/the-coming-ai-hackers.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 09:54:37+00:00
 - user: None

<p>Article URL: <a href="https://www.schneier.com/academic/archives/2021/04/the-coming-ai-hackers.html">https://www.schneier.com/academic/archives/2021/04/the-coming-ai-hackers.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34663465">https://news.ycombinator.com/item?id=34663465</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Google Invests Almost $400M in ChatGPT Rival Anthropic
 - [https://www.bloomberg.com/news/articles/2023-02-03/google-invests-almost-400-million-in-ai-startup-anthropic](https://www.bloomberg.com/news/articles/2023-02-03/google-invests-almost-400-million-in-ai-startup-anthropic)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 09:50:43+00:00
 - user: None

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-02-03/google-invests-almost-400-million-in-ai-startup-anthropic">https://www.bloomberg.com/news/articles/2023-02-03/google-invests-almost-400-million-in-ai-startup-anthropic</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34663438">https://news.ycombinator.com/item?id=34663438</a></p>
<p>Points: 40</p>
<p># Comments: 23</p>

## Jülich quantum computer solves protein puzzle
 - [https://www.eurekalert.org/news-releases/977133](https://www.eurekalert.org/news-releases/977133)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 09:32:10+00:00
 - user: None

<p>Article URL: <a href="https://www.eurekalert.org/news-releases/977133">https://www.eurekalert.org/news-releases/977133</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34663352">https://news.ycombinator.com/item?id=34663352</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## Gen Z Netiquettes
 - [https://manyonepercents.substack.com/p/productive-online-communication-gen-z](https://manyonepercents.substack.com/p/productive-online-communication-gen-z)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 08:58:30+00:00
 - user: None

<p>Article URL: <a href="https://manyonepercents.substack.com/p/productive-online-communication-gen-z">https://manyonepercents.substack.com/p/productive-online-communication-gen-z</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34663175">https://news.ycombinator.com/item?id=34663175</a></p>
<p>Points: 35</p>
<p># Comments: 29</p>

## I'm Going to Scale My Foot Up Your Ass (2008)
 - [http://widgetsandshit.com/teddziuba/2008/04/im-going-to-scale-my-foot-up-y.html](http://widgetsandshit.com/teddziuba/2008/04/im-going-to-scale-my-foot-up-y.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 08:55:56+00:00
 - user: None

<p>Article URL: <a href="http://widgetsandshit.com/teddziuba/2008/04/im-going-to-scale-my-foot-up-y.html">http://widgetsandshit.com/teddziuba/2008/04/im-going-to-scale-my-foot-up-y.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34663164">https://news.ycombinator.com/item?id=34663164</a></p>
<p>Points: 21</p>
<p># Comments: 15</p>

## Map-vectorizer – Map polygon and feature extractor
 - [https://github.com/nypl-spacetime/map-vectorizer](https://github.com/nypl-spacetime/map-vectorizer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 08:39:59+00:00
 - user: None

<p>Article URL: <a href="https://github.com/nypl-spacetime/map-vectorizer">https://github.com/nypl-spacetime/map-vectorizer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34663087">https://news.ycombinator.com/item?id=34663087</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Stride – Open-source C# Game Engine
 - [https://www.stride3d.net/](https://www.stride3d.net/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 08:05:45+00:00
 - user: None

<p>Article URL: <a href="https://www.stride3d.net/">https://www.stride3d.net/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34662916">https://news.ycombinator.com/item?id=34662916</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Poline – esoteric color palette generator
 - [https://meodai.github.io/poline/](https://meodai.github.io/poline/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 07:21:05+00:00
 - user: None

<p>Article URL: <a href="https://meodai.github.io/poline/">https://meodai.github.io/poline/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34662722">https://news.ycombinator.com/item?id=34662722</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Why I Use C When I Believe in Memory Safety
 - [https://gavinhoward.com/2023/02/why-i-use-c-when-i-believe-in-memory-safety/](https://gavinhoward.com/2023/02/why-i-use-c-when-i-believe-in-memory-safety/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 07:05:29+00:00
 - user: None

<p>Article URL: <a href="https://gavinhoward.com/2023/02/why-i-use-c-when-i-believe-in-memory-safety/">https://gavinhoward.com/2023/02/why-i-use-c-when-i-believe-in-memory-safety/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34662666">https://news.ycombinator.com/item?id=34662666</a></p>
<p>Points: 42</p>
<p># Comments: 21</p>

## What can I do for Arch Linux?
 - [https://whatcanidofor.archlinux.org/](https://whatcanidofor.archlinux.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 06:44:07+00:00
 - user: None

<p>Article URL: <a href="https://whatcanidofor.archlinux.org/">https://whatcanidofor.archlinux.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34662590">https://news.ycombinator.com/item?id=34662590</a></p>
<p>Points: 20</p>
<p># Comments: 0</p>

## Curta
 - [https://en.wikipedia.org/wiki/Curta](https://en.wikipedia.org/wiki/Curta)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 03:15:08+00:00
 - user: None

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Curta">https://en.wikipedia.org/wiki/Curta</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34661411">https://news.ycombinator.com/item?id=34661411</a></p>
<p>Points: 29</p>
<p># Comments: 8</p>

## Near-miss between FedEx and Southwest flights in Austin
 - [https://twitter.com/winglets747/status/1622038080680038400](https://twitter.com/winglets747/status/1622038080680038400)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 02:12:32+00:00
 - user: None

<p>Article URL: <a href="https://twitter.com/winglets747/status/1622038080680038400">https://twitter.com/winglets747/status/1622038080680038400</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34660938">https://news.ycombinator.com/item?id=34660938</a></p>
<p>Points: 79</p>
<p># Comments: 44</p>

## The cheapest flash microcontroller you can buy is actually an Arm Cortex-M0+
 - [https://jaycarlson.net/2023/02/04/the-cheapest-flash-microcontroller-you-can-buy-is-actually-an-arm-cortex-m0/](https://jaycarlson.net/2023/02/04/the-cheapest-flash-microcontroller-you-can-buy-is-actually-an-arm-cortex-m0/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 00:38:54+00:00
 - user: None

<p>Article URL: <a href="https://jaycarlson.net/2023/02/04/the-cheapest-flash-microcontroller-you-can-buy-is-actually-an-arm-cortex-m0/">https://jaycarlson.net/2023/02/04/the-cheapest-flash-microcontroller-you-can-buy-is-actually-an-arm-cortex-m0/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34660204">https://news.ycombinator.com/item?id=34660204</a></p>
<p>Points: 71</p>
<p># Comments: 10</p>

## The Market for Lemons
 - [https://infrequently.org/2023/02/the-market-for-lemons/](https://infrequently.org/2023/02/the-market-for-lemons/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 00:25:07+00:00
 - user: None

<p>Article URL: <a href="https://infrequently.org/2023/02/the-market-for-lemons/">https://infrequently.org/2023/02/the-market-for-lemons/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34660100">https://news.ycombinator.com/item?id=34660100</a></p>
<p>Points: 77</p>
<p># Comments: 45</p>

## The Packing Chromatic Number of the Infinite Grid is 15: the story behind it
 - [https://bsubercaseaux.github.io/blog/2023/packingchromatic/](https://bsubercaseaux.github.io/blog/2023/packingchromatic/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-02-05 00:19:53+00:00
 - user: None

<p>Article URL: <a href="https://bsubercaseaux.github.io/blog/2023/packingchromatic/">https://bsubercaseaux.github.io/blog/2023/packingchromatic/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34660065">https://news.ycombinator.com/item?id=34660065</a></p>
<p>Points: 41</p>
<p># Comments: 4</p>
