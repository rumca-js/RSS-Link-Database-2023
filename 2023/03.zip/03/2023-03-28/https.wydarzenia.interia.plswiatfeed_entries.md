# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Ukraina: Wypadek autokaru z Warszawy. Znamy liczbę rannych
 - [https://wydarzenia.interia.pl/zagranica/news-ukraina-wypadek-autokaru-z-warszawy-znamy-liczbe-rannych,nId,6683009](https://wydarzenia.interia.pl/zagranica/news-ukraina-wypadek-autokaru-z-warszawy-znamy-liczbe-rannych,nId,6683009)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-03-28 12:01:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ukraina-wypadek-autokaru-z-warszawy-znamy-liczbe-rannych,nId,6683009"><img align="left" alt="Ukraina: Wypadek autokaru z Warszawy. Znamy liczbę rannych" src="https://i.iplsc.com/ukraina-wypadek-autokaru-z-warszawy-znamy-liczbe-rannych/000GYCW4F6KECHGR-C321.jpg" /></a>Autokar, który jechał z Warszawy do Odessy, przewrócił się w obwodzie chmielnickim. 18 osób zostało rannych, trzy a nich trafiły na oddział intensywnej terapii. Autobusem podróżowało łącznie 25 osób i dwóch kierowców.

 
</p><br clear="all" />

## Kim Dzong Un znowu straszy. Pokazał nowe głowice
 - [https://wydarzenia.interia.pl/zagranica/news-kim-dzong-un-znowu-straszy-pokazal-nowe-glowice,nId,6682672](https://wydarzenia.interia.pl/zagranica/news-kim-dzong-un-znowu-straszy-pokazal-nowe-glowice,nId,6682672)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-03-28 06:17:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kim-dzong-un-znowu-straszy-pokazal-nowe-glowice,nId,6682672"><img align="left" alt="Kim Dzong Un znowu straszy. Pokazał nowe głowice" src="https://i.iplsc.com/kim-dzong-un-znowu-straszy-pokazal-nowe-glowice/000GYAKXPWHOXPPF-C321.jpg" /></a>Kim Dzong Un zaprezentował nowe, mniejsze głowice nuklearne. Przywódca Korei Północnej podkreślił przy tym, że nie chodzi o atak na żadne konkretne państwo, ale gotowość w razie &quot;wojny i nuklearnej katastrofy&quot;.</p><br clear="all" />

## Rosja wystrzeliła dwa pociski hipersoniczne. Ćwiczenia na Morzu Japońskim
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-wystrzelila-dwa-pociski-hipersoniczne-cwiczenia-na-mor,nId,6682662](https://wydarzenia.interia.pl/zagranica/news-rosja-wystrzelila-dwa-pociski-hipersoniczne-cwiczenia-na-mor,nId,6682662)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-03-28 05:10:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-wystrzelila-dwa-pociski-hipersoniczne-cwiczenia-na-mor,nId,6682662"><img align="left" alt="Rosja wystrzeliła dwa pociski hipersoniczne. Ćwiczenia na Morzu Japońskim" src="https://i.iplsc.com/rosja-wystrzelila-dwa-pociski-hipersoniczne-cwiczenia-na-mor/000GYAHZVWWVMJUP-C321.jpg" /></a>Rosja wystrzeliła pociski hipersoniczne Moskit na wodach Morza Japońskiego - podało Ministerstwo Obrony Federacji Rosyjskiej w czwartek. Jak przekazano, podczas ćwiczeń dwa okręty przeprowadziły wspólny na oddalony o 100 kilometrów cel.</p><br clear="all" />

## Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280715](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280715)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-03-28 03:31:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280715"><img align="left" alt="Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo/000GYAFTAXTCACXP-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280817](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280817)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-03-28 03:31:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280817"><img align="left" alt="Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo/000GYAFTAXTCACXP-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280908](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280908)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-03-28 03:31:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280908"><img align="left" alt="Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo/000GYAFTAXTCACXP-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280959](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280959)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-03-28 03:31:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,280959"><img align="left" alt="Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo/000GYAFTAXTCACXP-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,281102](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,281102)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-03-28 03:31:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo,nzId,3975,akt,281102"><img align="left" alt="Wojna w Ukrainie. 398. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-398-dzien-inwazji-rosji-relacja-na-zywo/000GYAFTAXTCACXP-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

