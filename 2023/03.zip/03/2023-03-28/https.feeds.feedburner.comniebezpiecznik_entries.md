# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik/, language:pl-PL

## Twój bezpieczny eCommerce
 - [https://niebezpiecznik.pl/post/twoj-bezpieczny-ecommerce/](https://niebezpiecznik.pl/post/twoj-bezpieczny-ecommerce/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2023-03-28 17:42:10+00:00

<a href="https://niebezpiecznik.pl/post/twoj-bezpieczny-ecommerce/"><img align="left" alt="" class="alignleft wp-post-image tfe" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2023/03/fw2-150x150.jpg" title="" width="100" /></a>Ci, którzy sprzedają w internecie, rzadko kiedy zwracają uwagę na bezpieczeństwo. Dopóki jest dobrze, to nie ma się czym przejmować, a kiedy coś się wydarzy, to… na myślenie o bezpieczeństwie jest już za późno. Ryzykowne to zachowanie, bo sklepy przechowują sporo wrażliwych danych osobowych oraz korzystają z bramek płatności, więc są dość częstym celem ataków [&#8230;]

## Morele ostatecznie wygrało w sądzie! Kary nie będzie, a na dodatek to UODO musi zapłacić 65 000 PLN.
 - [https://niebezpiecznik.pl/post/morele-wyrok-nsa-uodo-65000/](https://niebezpiecznik.pl/post/morele-wyrok-nsa-uodo-65000/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2023-03-28 09:59:45+00:00

<a href="https://niebezpiecznik.pl/post/morele-wyrok-nsa-uodo-65000/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2023/03/morelemj-150x150.jpg" width="100" /></a>Co za plot twist! Naczelny Sąd Administracyjny właśnie uchylił wyrok w sprawie Morele i zasądził od UODO (nie od Morele!) 65 000 złotych tytułem zwrotu kosztów postępowania sądowego. Bo – w skrócie – zabrakło opinii biegłego. Tym samym zakończył się wieloletni spór i pierwsza sprawa dotycząca naruszenia RODO w Polsce. Zanim wytłumaczymy rozumowanie sądu, przypomnijmy [&#8230;]

