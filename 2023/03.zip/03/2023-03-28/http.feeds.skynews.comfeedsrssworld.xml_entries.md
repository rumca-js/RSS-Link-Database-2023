# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Russian whose daughter drew anti-war picture flees after being sentenced to jail
 - [https://news.sky.com/story/russian-whose-daughter-drew-anti-war-picture-flees-after-being-sentenced-to-jail-12844470](https://news.sky.com/story/russian-whose-daughter-drew-anti-war-picture-flees-after-being-sentenced-to-jail-12844470)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 19:41:00+00:00

A Russian man sentenced to two years in a penal colony on charges of discrediting the armed forces has fled from house arrest, a court has said.

## Paris pensions protests are fast becoming a major crisis for Macron
 - [https://news.sky.com/story/the-paris-pensions-protests-are-fast-becoming-a-major-crisis-for-macron-12844436](https://news.sky.com/story/the-paris-pensions-protests-are-fast-becoming-a-major-crisis-for-macron-12844436)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 19:04:00+00:00

The boulevards of central Paris were once again choking up with the fog of tear gas.

## Olympic chiefs provide pathway for Russians to compete at Paris 2024 games
 - [https://news.sky.com/story/olympic-chiefs-provide-pathway-for-russians-to-compete-at-paris-2024-games-12844366](https://news.sky.com/story/olympic-chiefs-provide-pathway-for-russians-to-compete-at-paris-2024-games-12844366)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 17:15:00+00:00

Olympic chiefs today provided a clearer pathway for Russians being allowed to compete at Paris 2024, in defiance of Ukraine, while stalling on a decision.

## First pictures emerge of Nashville school shooting victims
 - [https://news.sky.com/story/nashville-school-shooting-first-pictures-emerge-of-victims-of-attack-including-nine-year-old-girl-and-headteacher-12844282](https://news.sky.com/story/nashville-school-shooting-first-pictures-emerge-of-victims-of-attack-including-nine-year-old-girl-and-headteacher-12844282)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 14:57:00+00:00

Images of four victims of a shooting at a school in Nashville have been released.

## Bodycam video shows moment Nashville school attacker was shot dead by police
 - [https://news.sky.com/story/nashville-school-shooting-bodycam-video-shows-moment-attacker-was-shot-dead-by-police-12844267](https://news.sky.com/story/nashville-school-shooting-bodycam-video-shows-moment-attacker-was-shot-dead-by-police-12844267)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 14:41:00+00:00

Graphic video has been released of the moment the Nashville school attacker was shot dead by police.

## Last governor of Hong Kong says 'demeaning and delusional' for UK to soften China criticism over trade fears
 - [https://news.sky.com/story/hong-kongs-last-governor-lord-patten-says-demeaning-and-delusional-for-uk-to-soften-china-criticism-over-trade-fears-12844257](https://news.sky.com/story/hong-kongs-last-governor-lord-patten-says-demeaning-and-delusional-for-uk-to-soften-china-criticism-over-trade-fears-12844257)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 14:33:00+00:00

The last governor of Hong Kong, Lord Patten, has said it is "demeaning and delusional" for the UK to not call out China's behaviour over trade fears.

## How a US aircraft carrier is part of a high-stakes stand-off in the South China Sea
 - [https://news.sky.com/story/how-a-us-aircraft-carrier-is-part-of-a-high-stakes-stand-off-in-the-south-china-sea-12844159](https://news.sky.com/story/how-a-us-aircraft-carrier-is-part-of-a-high-stakes-stand-off-in-the-south-china-sea-12844159)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 12:10:00+00:00

There are few greater displays of US military might than its aircraft carriers - when they move, the world pays attention. They are huge floating cities of sorts.

## Two women stabbed to death at Ismaili Muslim centre in Lisbon
 - [https://news.sky.com/story/two-women-stabbed-to-death-at-ismaili-muslim-centre-in-lisbon-12844137](https://news.sky.com/story/two-women-stabbed-to-death-at-ismaili-muslim-centre-in-lisbon-12844137)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 11:38:00+00:00

Two women have been stabbed to death at an Ismaili Muslim centre in Lisbon.

## Plastic surgeon accused of murdering missing lawyer
 - [https://news.sky.com/story/florida-plastic-surgeon-accused-of-murdering-missing-lawyer-12844068](https://news.sky.com/story/florida-plastic-surgeon-accused-of-murdering-missing-lawyer-12844068)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 09:49:00+00:00

A plastic surgeon in Florida has been charged with murdering a lawyer who was representing his ex-colleagues.

## Pepsi changes recipe of its classic cola drink
 - [https://news.sky.com/story/pepsi-dramatically-cuts-sugar-content-in-its-classic-drink-12844011](https://news.sky.com/story/pepsi-dramatically-cuts-sugar-content-in-its-classic-drink-12844011)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 08:25:00+00:00

Pepsi has slashed the sugar content of its classic drink by more than half.

## Woolly mammoth meatball - would you eat one?
 - [https://news.sky.com/story/woolly-mammoth-meatball-would-you-eat-one-12844004](https://news.sky.com/story/woolly-mammoth-meatball-would-you-eat-one-12844004)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 08:09:00+00:00

A meatball has been made from the recreated flesh of the long-extinct woolly mammoth as part of a project to demonstrate the potential of growing flesh 
 from cells.

## At least 10 dead after fire at migrant facility in northern Mexico near US border
 - [https://news.sky.com/story/at-least-10-dead-after-fire-at-migrant-facility-in-northern-mexico-near-us-border-12843966](https://news.sky.com/story/at-least-10-dead-after-fire-at-migrant-facility-in-northern-mexico-near-us-border-12843966)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 06:57:00+00:00

Several people have died in a fire at a migrant facility in Mexico's Ciudad Juarez, near to the US border, according to reports.

## UN calls on Taliban to explain after 'Afghan girls' education activist arrested in Kabul
 - [https://news.sky.com/story/un-calls-on-taliban-to-explain-after-afghan-girls-education-activist-arrested-in-kabul-12843965](https://news.sky.com/story/un-calls-on-taliban-to-explain-after-afghan-girls-education-activist-arrested-in-kabul-12843965)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-28 06:55:00+00:00

The United Nations has called on the Taliban to explain why an Afghan girls' education activist was reportedly arrested in Kabul.

