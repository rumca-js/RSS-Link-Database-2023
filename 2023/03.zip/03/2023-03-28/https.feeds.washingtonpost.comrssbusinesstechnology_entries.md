# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Ernie Bot, China’s answer to ChatGPT, is delayed — again
 - [https://www.washingtonpost.com/world/2023/03/28/china-baidu-chatbot-ai-ernie/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/world/2023/03/28/china-baidu-chatbot-ai-ernie/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-28 16:18:40+00:00

Baidu's Ernie Bot is not being rolled out to the public. But we found Ernie Bot shuts down the conversation when asked about anything remotely sensitive.

## Now you can ‘buy now, pay later’ with Apple Wallet
 - [https://www.washingtonpost.com/technology/2023/03/28/apple-buy-now-pay-later/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/03/28/apple-buy-now-pay-later/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-28 12:34:25+00:00

iPhone users can request loans from Apple to "buy now, pay later" and repay in four installments over six weeks with no interest.

## AI doesn’t belong everywhere. Stop using a hammer to make lasagna.
 - [https://www.washingtonpost.com/technology/2023/03/28/silly-uses-ai-are-giving-me-flashbacks-flatulence-apps/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/03/28/silly-uses-ai-are-giving-me-flashbacks-flatulence-apps/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-28 12:30:00+00:00

Just because you can apply AI to a task, it doesn't mean that you should.

## Microsoft’s latest use for GPT4: Stopping hackers
 - [https://www.washingtonpost.com/technology/2023/03/28/microsoft-copilot-security-ai/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/03/28/microsoft-copilot-security-ai/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-28 11:30:00+00:00

Microsoft has been putting generative AI into many of its products. Now it's adding cybersecurity tools to the list.

## Water in video games has never looked wetter. Er, better.
 - [https://www.washingtonpost.com/video-games/2023/03/28/video-game-water/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2023/03/28/video-game-water/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-28 08:00:55+00:00

Video games don't simulate water. They create an illusion — one that needs to work right in “about five thousandths of a second.”

## Congress had a lot to say about TikTok. Much of it was wrong.
 - [https://www.washingtonpost.com/technology/2023/03/28/tiktok-challenges-congress-misinformation/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/03/28/tiktok-challenges-congress-misinformation/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-28 06:00:30+00:00

‘Nyquil chicken’ and the ‘blackout challenge’ were phenomena before TikTok existed.

## Apple illegally fired five labor activists, union says
 - [https://www.washingtonpost.com/technology/2023/03/28/apple-union-firings/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/03/28/apple-union-firings/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-28 06:00:00+00:00

The workers, who were disciplined and fired for attendance-related issues, believe they were let go because of their union organizing.

## Biden stuck between China hawks, young voters as TikTok pressure mounts
 - [https://www.washingtonpost.com/us-policy/2023/03/28/tiktok-biden-ban-china-congress/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/us-policy/2023/03/28/tiktok-biden-ban-china-congress/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-28 06:00:00+00:00

The administration faces national security concerns over the app’s ownership — and a possible backlash over a ban.

