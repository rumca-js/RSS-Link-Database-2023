# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Kolejne kłopoty Tesli. Tym razem z odpinającymi się pasami
 - [https://www.money.pl/gospodarka/kolejne-klopoty-tesli-tym-razem-z-odpinajacymi-sie-pasami-6881411998600000a.html](https://www.money.pl/gospodarka/kolejne-klopoty-tesli-tym-razem-z-odpinajacymi-sie-pasami-6881411998600000a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 19:37:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/510493fa-bde2-4bde-ac7c-de6385800590" width="308" /> Amerykański urząd ds. bezpieczeństwa ruchu drogowego (NHTSA) bada samochody marki Tesla. Powód? Doniesienia o pasach bezpieczeństwa, które same się rozpinają w trakcie jazdy. To kolejne kłopoty producenta samochodów. Wcześniej w jednym z modeli pojazdów... miała odpaść kierownica.

## W środę zapadnie decyzja. W Polsce pojawi się Akademia Policji
 - [https://www.money.pl/gospodarka/w-srode-zapadnie-decyzja-w-polsce-pojawi-sie-akademia-policji-6881390260374336a.html](https://www.money.pl/gospodarka/w-srode-zapadnie-decyzja-w-polsce-pojawi-sie-akademia-policji-6881390260374336a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 18:08:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0cac6803-bce1-45f4-83fa-7842ba686b88" width="308" /> Rząd w środę pochyli się nad projektem ustawy o zmianie nazw uczelni służb państwowych nadzorowanych przez MSWiA. Zgodnie z nim Szkoła Główna Służby Pożarniczej stanie się Akademią Pożarniczą, a Wyższa Szkoła Policji w Szczytnie – Akademią Policji w Szczytnie.

## "W dwa lata pokonamy inflację". Donald Tusk założył się o to, ale tylko o jedno euro
 - [https://www.money.pl/gospodarka/w-dwa-lata-pokonamy-inflacje-donald-tusk-zalozyl-sie-o-to-ale-tylko-o-jedno-euro-6881352634809152a.html](https://www.money.pl/gospodarka/w-dwa-lata-pokonamy-inflacje-donald-tusk-zalozyl-sie-o-to-ale-tylko-o-jedno-euro-6881352634809152a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 16:34:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5cadce39-48ad-4923-9cc5-5770a07e2f3e" width="308" /> Donald Tusk ma receptę na pokonanie inflacji. Lider Platformy Obywatelskiej jest przekonany, że jeżeli w Polsce przywróci się zasady wydawania publicznych pieniędzy i działania NBP z czasów rządów PO, to w ciągu dwóch lat wskaźnik wzrostu cen znacznie wyhamuje. Postawił na tę tezę "symboliczne jedno euro".

## Polska przeciwko zakazowi aut spalinowych do 2035 r. Premier Morawiecki: "dziękuję pani minister"
 - [https://www.money.pl/gospodarka/polska-przeciwko-zakazowi-aut-spalinowych-do-2035-r-premier-morawiecki-dziekuje-pani-minister-6881359503612704a.html](https://www.money.pl/gospodarka/polska-przeciwko-zakazowi-aut-spalinowych-do-2035-r-premier-morawiecki-dziekuje-pani-minister-6881359503612704a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 16:03:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c2c3cef6-c0f4-4e4e-a2fa-dc91d9781b44" width="308" /> Polska jako jedyne państwo unijne zagłosowała przeciwko zakazowi sprzedaży samochodów spalinowych do 2035 r. Premier Mateusz Morawiecki na Twitterze potwierdził, że to on wydał polecenie, by tak zagłosować. I podziękował za to minister klimatu Annie Moskwie.

## Cena jak hotel. Izba wytrzeźwień w Rzeszowie podnosi stawki
 - [https://www.money.pl/pieniadze/cena-jak-hotel-izba-wytrzezwien-w-rzeszowie-podnosi-stawki-6881339505429312a.html](https://www.money.pl/pieniadze/cena-jak-hotel-izba-wytrzezwien-w-rzeszowie-podnosi-stawki-6881339505429312a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 14:29:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/51163861-e698-4856-811e-1decc5366c42" width="308" /> 393 złotych będzie kosztował pobyt w izbie wytrzeźwień w Rzeszowie. Radni miasta zgodzili się na podniesienie dotychczasowej stawki o 50 złotych. Za takie pieniądze można spędzić noc w hotelu w centrum Warszawy.

## Jack Ma wraca i od razu zmienia się Alibaba. Gigant rozpadnie się na sześć podmiotów
 - [https://www.money.pl/gielda/jack-ma-wraca-i-od-razu-zmienia-sie-alibaba-gigant-rozpadnie-sie-na-szesc-podmiotow-6881326867864384a.html](https://www.money.pl/gielda/jack-ma-wraca-i-od-razu-zmienia-sie-alibaba-gigant-rozpadnie-sie-na-szesc-podmiotow-6881326867864384a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 13:50:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/16cc220e-e9db-42b7-a197-2911379316e0" width="308" /> Alibaba chce rozdzielić swoją działalność na sześć niezależnie zarządzanych podmiotów. Tym samym szykuje się największe strukturalne przetasowanie w historii chińskiego giganta – podały amerykańskie media. Decyzja ta została ogłoszona dzień po tym, jak publicznie pokazał się Jack Ma, założyciel koncernu.

## Nowa prognoza wzrostu PKB. Ekonomiści Citi skorygowali założenia
 - [https://www.money.pl/gospodarka/nowa-prognoza-wzrostu-pkb-ekonomisci-citi-skorygowali-zalozenia-6881323499584288a.html](https://www.money.pl/gospodarka/nowa-prognoza-wzrostu-pkb-ekonomisci-citi-skorygowali-zalozenia-6881323499584288a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 13:36:57+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5a7a2cae-68f4-4bba-8e0d-24eab4ded83c" width="308" /> Ekonomiści Citi podali, że nawet przy dynamicznym odbiciu PKB w ujęciu kwartał do kwartału, całoroczny wzrost gospodarczy w 2023 roku pozostanie niski. Skorygowali swoją prognozę wzrostu PKB w 2023 roku do 0,3 proc. wobec 1,0 proc. przed miesiącem.

## Amerykański bank mówi, co stanie się po wygranej PO w wyborach parlamentarnych
 - [https://www.money.pl/gospodarka/goldman-sachs-prognozuje-co-stanie-sie-po-wygranej-po-w-wyborach-parlamentarnych-6881286092577568a.html](https://www.money.pl/gospodarka/goldman-sachs-prognozuje-co-stanie-sie-po-wygranej-po-w-wyborach-parlamentarnych-6881286092577568a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 12:42:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/59c9dae6-a11b-4466-bb34-67c4912f1a3a" width="308" /> Jak zauważają analitycy Goldman Sachs, w Polsce na jesieni realnie w grę wchodzi scenariusz zmiany rządu. Jeśli tak się stanie i do władzy dojdą partie opozycji na czele z PO, to w ich ocenie najważniejszą, pozytywną gospodarczo konsekwencją będzie poprawa relacji z Unią.

## Kolejki do deweloperów w oczekiwaniu na rządowy program. "Podsuwają umowy"
 - [https://www.money.pl/banki/kolejki-do-deweloperow-w-oczekiwaniu-na-rzadowy-program-podsuwaja-umowy-6881039414627136a.html](https://www.money.pl/banki/kolejki-do-deweloperow-w-oczekiwaniu-na-rzadowy-program-podsuwaja-umowy-6881039414627136a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 12:31:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b8d7622d-0755-434f-88d1-e1215cd7a54d" width="308" /> Mimo że rządowy program "Bezpieczny kredyt 2 proc." na zakup pierwszego mieszkania jeszcze nie wystartował, to klienci już ustawiają się w kolejkach do deweloperów. Jest ryzyko, że ceny nieruchomości wystrzelą, gdy tylko stopy proc. zaczną spadać.

## Sieć dm otwiera kolejne dwie drogerie w Polsce. Podaje ich lokalizacje
 - [https://www.money.pl/gospodarka/siec-dm-otwiera-kolejne-dwie-drogerie-w-polsce-podaje-ich-lokalizacje-6881298038573888a.html](https://www.money.pl/gospodarka/siec-dm-otwiera-kolejne-dwie-drogerie-w-polsce-podaje-ich-lokalizacje-6881298038573888a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 11:53:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fe880c27-b65d-4f3d-9c98-75c1e9d69bb8" width="308" /> Sieć drogerii dm w Polsce powiększy się o kolejne dwa punkty. Firma otworzy placówki w Krakowie i Gogolinie. Klienci będą mogli zrobić w nich zakupy już od czwartku 30 marca. Detalista znalazł też sposób na zachęcenie ich do tego. Odwiedzający mogą liczyć na spory rabat na zakupy i specjalny prezent.

## Zbigniew Ziobro chce nałożenia ceł ochronnych na zboże z Ukrainy. Jest wniosek
 - [https://www.money.pl/gospodarka/zbigniew-ziobro-chce-nalozenia-cel-ochronnych-na-zboze-z-ukrainy-6881290591148864a.html](https://www.money.pl/gospodarka/zbigniew-ziobro-chce-nalozenia-cel-ochronnych-na-zboze-z-ukrainy-6881290591148864a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 11:23:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/37ba05d7-afd5-4dd0-bdc0-e96ff1fc8d67" width="308" /> Zbigniew Ziobro wystąpi do rządu o "pilne uruchomienie procedury" umożliwiającej nałożenie ceł na zboże z Ukrainy. Taka decyzja jest w gestii Komisji Europejskiej. - Egoistycznie KE tego nie robi, nie chroni interesu polskich rolników - powiedział. Wniosek złoży w środę na posiedzeniu rządu.

## Wiceminister zachęcał do PPK, a sam się wypisał? Zamieszanie wokół słów Artura Sobonia
 - [https://www.money.pl/emerytury/wiceminister-zachecal-do-ppk-a-sam-sie-wypisal-zamieszanie-wokol-slow-artura-sobonia-6881247272807200a.html](https://www.money.pl/emerytury/wiceminister-zachecal-do-ppk-a-sam-sie-wypisal-zamieszanie-wokol-slow-artura-sobonia-6881247272807200a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 08:26:46+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/dc16d4c4-6df1-4774-8b50-b390f7bb68a8" width="308" /> Wiceminister finansów Artur Soboń w Polsat News stwierdził, że nie zapisywał się do PPK. Komentujący szybko wytknęli mu, że sam zachęcał Polaków do oszczędzania w ten sposób na emeryturę. Jest reakcja samego Artura Sobonia.

## Oto jakie Polacy mają przeciętne dochody. Są najnowsze dane
 - [https://www.money.pl/gospodarka/przecietny-miesieczny-dochod-rozporzadzalny-na-1-osobe-ogolem-w-2022-r-dane-gus-6881236334476096a.html](https://www.money.pl/gospodarka/przecietny-miesieczny-dochod-rozporzadzalny-na-1-osobe-ogolem-w-2022-r-dane-gus-6881236334476096a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 08:01:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/def5085e-d59f-434b-a1e5-f9891861900f" width="308" /> Przeciętny miesięczny dochód rozporządzalny na osobę w 2022 r. wyniósł 2249,79 zł – poinformował GUS.

## Chiny na potęgę dają kredyty innym krajom. To jasny sygnał dla USA
 - [https://www.money.pl/banki/chiny-na-potege-daja-kredyty-innym-krajom-to-jasny-sygnal-dla-usa-6881212548356928a.html](https://www.money.pl/banki/chiny-na-potege-daja-kredyty-innym-krajom-to-jasny-sygnal-dla-usa-6881212548356928a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 07:51:46+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f04aaa39-281f-41e2-a46a-a6562ca69f6f" width="308" /> Ludowy Bank Chin od 2000 roku przeznaczył co najmniej 240 mld dol. na pomoc zagranicznym kredytobiorcom. Pieniądze trafiły do 22 krajów rozwijających się. W ten sposób Pekin poszerza swoją strefę wpływów i wysyła sygnał do Waszyngtonu.

## Najnowsze dane niepokoją. Polska gospodarka spychana na skraj recesji
 - [https://www.money.pl/gospodarka/wwk-marzec-2023-r-najnowsze-dane-niepokoja-polska-gospodarka-spychana-na-skraj-recesji-6881230418414368a.html](https://www.money.pl/gospodarka/wwk-marzec-2023-r-najnowsze-dane-niepokoja-polska-gospodarka-spychana-na-skraj-recesji-6881230418414368a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 07:35:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/52f3be46-c1c4-4564-b44d-97ed4b0c8928" width="308" /> Wskaźnik Wyprzedzający Koniunktury (WWK), który informuje o przyszłych tendencjach w polskiej gospodarce, w marcu 2023 r. spadł o 0,8 pkt. wobec wartości ze stycznia i lutego – podało Biuro Inwestycji i Cykli Ekonomicznych. "Gospodarka w dalszym ciągu hamuje" – komentuje BIEC.

## Przyszli emeryci mogą dostać mniej pieniędzy. Oto wyliczenia ZUS-u
 - [https://www.money.pl/emerytury/przyszli-emeryci-moga-dostac-mniej-pieniedzy-oto-wyliczenia-zus-u-6881207233354528a.html](https://www.money.pl/emerytury/przyszli-emeryci-moga-dostac-mniej-pieniedzy-oto-wyliczenia-zus-u-6881207233354528a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 05:43:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6455882f-1a56-4dc5-8c40-c4f3b47dabe3" width="308" /> Od 1 kwietnia ZUS będzie korzystał z nowych tablic średniego dalszego trwania życia, ogłoszonych przez GUS. Co do zasady nie dotyczą one osób, które już przeszły na emeryturę - podkreśliła prof. Gertruda Uścińska, prezes Zakładu Ubezpieczeń Społecznych.

## Kursy walut 28.03.2023. Wtorkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-28-03-2023-wtorkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6881201493199648a.html](https://www.money.pl/pieniadze/kursy-walut-28-03-2023-wtorkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6881201493199648a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 05:20:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 28.03.2023. We wtorek za jednego dolara (USD) zapłacimy 4.33 zł. Cena jednego funta szterlinga (GBP) to 5.33 zł, a franka szwajcarskiego (CHF) 4.74 zł. Z kolei euro (EUR) możemy zakupić za 4.68 zł.

## Batalia frankowiczów z bankami. Piotr Patkowski mówi o najlepszym rozwiązaniu problemu
 - [https://www.money.pl/banki/batalia-frankowiczow-z-bankami-piotr-patkowski-mowi-o-najlepszym-rozwiazaniu-problemu-6881196034976576a.html](https://www.money.pl/banki/batalia-frankowiczow-z-bankami-piotr-patkowski-mowi-o-najlepszym-rozwiazaniu-problemu-6881196034976576a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 05:17:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/02715ab3-ada5-448c-8deb-63d2eeb223e9" width="308" /> Banki wciąż mają w swoich rękach silne instrumenty, by problem frankowy sprawiedliwie uregulować, czyli ugody. One są obecnie zawierane, ale ich potencjał nie jest wykorzystany - uważa Piotr Patkowski. Wiceminister finansów w rozmowie "Rzeczpospolitą" mówi o sprawiedliwości społecznej.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 28.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-28-03-2023-6881196783348544a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-28-03-2023-6881196783348544a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 05:01:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 28.03.2023. We wtorek za jednego dolara (USD) trzeba zapłacić 4.3312 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 28.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-28-03-2023-6881196781931296a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-28-03-2023-6881196781931296a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 05:01:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 28.03.2023. We wtorek za jednego franka (CHF) trzeba zapłacić 4.7373 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 28.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-28-03-2023-6881196767492896a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-28-03-2023-6881196767492896a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 05:01:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 28.03.2023. We wtorek za jedno euro (EUR) trzeba zapłacić 4.6824 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 28.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-28-03-2023-6881196767247168a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-28-03-2023-6881196767247168a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 05:01:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 28.03.2023. We wtorek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.3341 zł.

## Skarbówka zwróci firmom pieniądze. Jest uchwała NSA
 - [https://www.money.pl/podatki/skarbowka-zwroci-firmom-pieniadze-jest-uchwala-nsa-6881191416589120a.html](https://www.money.pl/podatki/skarbowka-zwroci-firmom-pieniadze-jest-uchwala-nsa-6881191416589120a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 04:39:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/97c85443-11b2-49f5-baed-c9de7644eef6" width="308" /> Część firm odzyska pieniądze, które zapłaciły fiskusowi. Naczelny Sąd Administracyjny uznał, że ustawa covidowa nie dała skarbówce więcej czasu na dokonywanie kontroli i postępowań wobec podatników. O sprawie pisze "Puls Biznesu".

## Zygmunt Solorz odkupi ukraiński bank od oligarchów? Jest reakcja firmy miliardera
 - [https://www.money.pl/banki/zygmunt-solorz-odkupi-ukrainski-bank-od-oligarchow-jest-reakcja-firmy-miliardera-6881190798793536a.html](https://www.money.pl/banki/zygmunt-solorz-odkupi-ukrainski-bank-od-oligarchow-jest-reakcja-firmy-miliardera-6881190798793536a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-28 04:36:59+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8488eaf9-4d57-4f0f-9f7f-bc043da51cb1" width="308" /> Według ukraińskiej edycji "Forbesa" kontrolowana przez Zygmunta Solorza Grupa Polsat chce kupić ukraiński Sense Bank. Dziś jest on w rękach rosyjskich oligarchów. Należąca do polskiego miliardera firma odniosła się do tych doniesień i stanowczo im zaprzecza.

