# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Spółki technologiczne „autorami” spadków na Wall Street
 - [https://www.bankier.pl/wiadomosc/Spolki-technologiczne-autorami-spadkow-na-Wall-Street-8513423.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spolki-technologiczne-autorami-spadkow-na-Wall-Street-8513423.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/43c2cca87ba06c-948-568-5-140-1991-1195.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W centrum uwagi inwestorów cały czas
znajduje się kwestia kryzysu bankowego i stóp procentowych w USA.</p>

## EBITDA Ten Square Games w IV kw. wyniosła 35,3 mln zł, powyżej konsensusu
 - [https://www.bankier.pl/wiadomosc/EBITDA-Ten-Square-Games-w-IV-kw-wyniosla-35-3-mln-zl-powyzej-konsensusu-8513282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/EBITDA-Ten-Square-Games-w-IV-kw-wyniosla-35-3-mln-zl-powyzej-konsensusu-8513282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 17:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/0/49dbe3c431812e-948-568-117-0-1803-1082.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ten Square Games wypracował w czwartym kwartale 2022 roku 35,3 mln zł skorygowanej EBITDA wobec 67,4 mln zł rok wcześniej - poinformowała spółka w raporcie. Konsensus zakładał 27,9 mln zł skorygowanej EBITDA (przedział 26,2 - 30,5 mln zł).</p>

## Powstaje zapora elektroniczna na granicy z Rosja. Koszt to ponad 350 mln zł
 - [https://www.bankier.pl/wiadomosc/Powstaje-zapora-elektroniczna-na-granicy-z-Rosja-Koszt-to-ponad-350-mln-zl-8513277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powstaje-zapora-elektroniczna-na-granicy-z-Rosja-Koszt-to-ponad-350-mln-zl-8513277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 16:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/b/7d04e776dc7541-948-568-0-60-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W komendzie Warmińsko-Mazurskiego Oddziału Straży Granicznej w Kętrzynie ruszyły prace nad Centrum Nadzoru, do którego będą docierały sygnały z zapory elektronicznej na granicy z Rosją. W tym tygodniu zaczną się też przygotowania do prac na granicy - powiedziała rzeczniczka SG por. Anna Michalska.</p>

## Narodowy Bank Ukrainy wydał czasowy zakaz wykonywania prawa głosu z akcji Idea Bank Ukraina przez Getin Holding
 - [https://www.bankier.pl/wiadomosc/NBU-wydal-czasowy-zakaz-wykonywania-prawa-glosu-z-akcji-Idea-Bank-Ukraina-przez-Getin-Holding-8513263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBU-wydal-czasowy-zakaz-wykonywania-prawa-glosu-z-akcji-Idea-Bank-Ukraina-przez-Getin-Holding-8513263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 16:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/8ddb9cb0af6f16-948-567-0-57-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Narodowy Bank Ukrainy wydał decyzję czasowego zakazu wykonywania prawa głosu z akcji Idea Bank Ukraina przez Getin Holding - poinformował Getin Holding w komunikacie.</p>

## Coraz droższa Mierzeja Wiślana. Rząd zapłaci ponad 2 mld
 - [https://www.bankier.pl/wiadomosc/Coraz-drozsza-Mierzeja-Wislana-Rzad-zaplaci-ponad-2-mld-8513261.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-drozsza-Mierzeja-Wislana-Rzad-zaplaci-ponad-2-mld-8513261.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 16:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/64e0d8c9a54fe6-948-568-68-0-1488-892.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Flagowy projekt rządu PiS robi się coraz droższy. Wieloletni plan budowy drogi wodnej łączącej Zalew Wiślany z Zatoką Gdańską właśnie otrzymał dodatkowy zastrzyk gotówki. Rząd zwiększył jego budżet do 2 mld 127 mln 494 tys. zł. </p>

## Utrzymane wzrosty na GPW. „Akcje banków mogą już być tylko w mocnych rękach”
 - [https://www.bankier.pl/wiadomosc/Utrzymane-wzrosty-na-GPW-Akcje-bankow-moga-juz-byc-tylko-w-mocnych-rekach-8513235.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Utrzymane-wzrosty-na-GPW-Akcje-bankow-moga-juz-byc-tylko-w-mocnych-rekach-8513235.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 16:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/6002bf98f2266b-945-560-25-56-1706-1023.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wtorkowa sesja na GPW znów zakończyła się wzrostami. Zwłaszcza notujący drugi dzień giełdowej ulgi sektor bankowy był szczególnie mocny. Na parkiecie w Warszawie także z uwagi na kilka pozytywnych rekomendacji dla banków, które, razem z raportami wynikowymi innych spółek, zapewniły sporą zmienność na cenach wielu akcji.</p>

## Wielkie polowanie na banki we Francji. Śledczy weszli do placówek
 - [https://www.bankier.pl/wiadomosc/Wielkie-polowanie-na-oszustow-we-Francji-Banki-sa-przeszukiwane-8513205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wielkie-polowanie-na-oszustow-we-Francji-Banki-sa-przeszukiwane-8513205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 16:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/f4d437248b147f-945-567-123-26-1375-825.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Banki Societe Generale, BNP Paribas, Exane (spółka zależna BNP), Natixis oraz HSBC w Paryżu oraz La Defense znalazły się pod lupą śledczych. Francuscy inspektorzy podejrzewają je o uchylanie się od płacenia podatków. </p>

## Zarząd Tauronu nie rekomenduje wypłaty dywidendy za 2022. Chce przeznaczyć cały zysk na kapitał
 - [https://www.bankier.pl/wiadomosc/Zarzad-Tauronu-nie-rekomenduje-wyplaty-dywidendy-za-22-chce-przeznaczyc-caly-zysk-na-kapital-8513204.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zarzad-Tauronu-nie-rekomenduje-wyplaty-dywidendy-za-22-chce-przeznaczyc-caly-zysk-na-kapital-8513204.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 16:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/d/2279bbc6a3b34f-948-568-7-2-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zarząd Tauronu rekomenduje Zwyczajnemu Walnemu Zgromadzeniu przeznaczenie całego zysku netto osiągniętego w 2022 roku w wysokości 67.102.592,85 zł na kapitał zapasowy - podała spółka w komunikacie.</p>

## USA popiera plan prezydenta Zełenskiego. "Zapewni trwały pokój"
 - [https://www.bankier.pl/wiadomosc/USA-popiera-plan-prezydenta-Zelenskiego-Zapewni-trwaly-pokoj-8513202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-popiera-plan-prezydenta-Zelenskiego-Zapewni-trwaly-pokoj-8513202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 15:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/4/fb4e73ae0c6fce-948-568-0-22-1778-1066.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Plan prezydenta Ukrainy Wołodymyra Zełenskiego zapewni trwały pokój i uniemożliwi Rosji ponowny atak - powiedział sekretarz stanu USA Antony Blinken podczas wirtualnego spotkania z okazji rozpoczętego we wtorek Szczytu dla Demokracji. </p>

## Tusk zakłada się o 1 euro. Sprawa dotyczy polskiej inflacji
 - [https://www.bankier.pl/wiadomosc/Tusk-zaklada-sie-o-1-euro-Sprawa-dotyczy-polskiej-inflacji-8513186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tusk-zaklada-sie-o-1-euro-Sprawa-dotyczy-polskiej-inflacji-8513186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 15:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/25211034e4366b-948-568-0-17-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lider PO Donald Tusk stwierdził, że aby obniżyć w Polsce inflację tak, by znalazła się wśród 5-6 europejskich państw z najniższym wskaźnikiem wystarczą trzy składniki. Założył się o to o symboliczne jedno euro. </p>

## Dąbrowski (RPP): Nie będzie pochopnego obniżania stóp procentowych w Polsce
 - [https://www.bankier.pl/wiadomosc/Dabrowski-RPP-Nie-bedzie-pochopnego-obnizania-stop-procentowych-w-Polsce-8513174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dabrowski-RPP-Nie-bedzie-pochopnego-obnizania-stop-procentowych-w-Polsce-8513174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 15:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/79e40c4f1c744a-948-568-0-169-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie będzie pochopnego obniżania stóp procentowych w Polsce - zaznacza członek RPP, Ireneusz Dąbrowski, w kuluarach Forum Suwerenności Monetarnej w Warszawie. Jego zdaniem obecne zaburzenia na rynkach wskazują, że ogłoszenie ostatecznej pauzy w cyklu podwyżek stóp jest stanowczo przedwczesne.</p>

## "Ryzyko systemowe". KSF wydała komunikat m.in. o WIBOR-ze
 - [https://www.bankier.pl/wiadomosc/Ryzyko-systemowe-KSF-wydala-komunikat-m-in-o-WIBOR-ze-8513147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ryzyko-systemowe-KSF-wydala-komunikat-m-in-o-WIBOR-ze-8513147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 15:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/a1684d5afa548c-948-568-0-207-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komitet Stabilności Finansowej dot. nadzoru makroostrożnościowego (KSF-M) uznał kwestionowanie wskaźnika WIBOR w umowach kredytowych za ryzyko systemowe - podał Komitet w komunikacie po posiedzeniu.</p>

## Bank Pekao wiąże duże nadzieje z Programem "Pierwsze mieszkanie"
 - [https://www.bankier.pl/wiadomosc/Bank-Pekao-wiaze-duze-nadzieje-z-Programem-Pierwsze-mieszkanie-8513133.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bank-Pekao-wiaze-duze-nadzieje-z-Programem-Pierwsze-mieszkanie-8513133.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 14:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/b/25d1b82465ba40-948-568-0-52-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Program "Pierwsze mieszkanie" umożliwi odwrócenie trendu na rynku budowlanym - napisali w raporcie analitycy Banku Pekao. Teraz oceniany jest on na negatywny. Sytuacja branży pogardza się z każdym dniem. </p>

## Orlen wyda swoje centrum badań 3 mld złotych
 - [https://www.bankier.pl/wiadomosc/Orlen-wyda-swoje-centrum-badan-3-mld-zlotych-8513124.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orlen-wyda-swoje-centrum-badan-3-mld-zlotych-8513124.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 14:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/2/1d8c1194f1e541-948-568-11-70-4656-2793.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Orlen wyda 3 mld zł na siebie, a dokładnie Centrum Badawczo - Rozwojowe w Płocku, które pracuje nad innowacjami dla nowoczesnej rafinerii i petrochemii. Prezes PKN Orlen Daniel Obajtek potwierdził to na Twitterze. </p>

## Resort rolnictwa chce ugasić gniew rolników. Daje 250 zł do tony zboża
 - [https://www.bankier.pl/wiadomosc/Resort-rolnictwa-chce-ugasic-gniew-rolnikow-Daje-250-zl-za-tone-zboza-8513080.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Resort-rolnictwa-chce-ugasic-gniew-rolnikow-Daje-250-zl-za-tone-zboza-8513080.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 14:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/a99310009c2906-948-568-0-44-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 150 do 250 zł - dopłaty w takiej wysokości mają otrzymać rolnicy w związku z sytuacją na rynku w związku z magazynowiem zboża z Ukrainy. Łącznie na ten cel przeznaczonych będzie 600 mln zł. </p>

## Zła passa kopalni Turów. Niemieckie miasto kolejny raz idzie do sądu
 - [https://www.bankier.pl/wiadomosc/Zla-passa-kopalni-Turow-Zytawa-kolejny-raz-idzie-do-sadu-8512937.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zla-passa-kopalni-Turow-Zytawa-kolejny-raz-idzie-do-sadu-8512937.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/b436a6f847ca67-948-567-0-45-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To nie koniec problemów Turowa. Niemieckie miasto Żytawa planuje wnieść kolejną skargę przeciwko kopalni węgla brunatnego, która w lutym uzyskała od resortu klimatu koncesję na dalsze wydobycie. 






</p>

## 2249,79 zł miesięcznie. Za tyle żyli Polacy w 2022 roku
 - [https://www.bankier.pl/wiadomosc/2249-79-zl-miesiecznie-Dochod-rozporzadzalny-w-2022-roku-8513001.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/2249-79-zl-miesiecznie-Dochod-rozporzadzalny-w-2022-roku-8513001.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 13:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/f/a2aefdc024f86e-948-568-0-0-2074-1244.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />GUS pokazał najnowsze dane o miesięcznym dochodzie rozporządzalnym w 2022 roku, który wyniósł 2249,79 zł. Zaskoczenia nie ma - ten wzrósł (bo i wszystko wzrosło), ale tylko nominalnie. Realnie nie mamy się już z czego cieszyć. </p>

## Eurocash liczy na lepszy rok rdr i wzrost EBITDA. Wyzwaniem osłabienie popytu konsumenckiego
 - [https://www.bankier.pl/wiadomosc/Eurocash-liczy-na-lepszy-rok-rdr-i-wzrost-EBITDA-wyzwaniem-oslabienie-popytu-konsumenckiego-wywiad-8513004.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Eurocash-liczy-na-lepszy-rok-rdr-i-wzrost-EBITDA-wyzwaniem-oslabienie-popytu-konsumenckiego-wywiad-8513004.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 13:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/e09d3e25d07bda-948-568-2-2-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa Eurocash liczy na lepszy rok rdr i wzrost EBITDA. Wyzwaniem będzie widoczne w pierwszym kwartale osłabienie popytu konsumenckiego - poinformował PAP Biznes prezes Paweł Surówka. Grupa chce dalej poprawiać efektywność kosztową, rozmawia z dostawcami.</p>

## Zakaz rejestracji aut spalinowych po 2035 r. Jest ostateczna decyzja Rady UE
 - [https://www.bankier.pl/wiadomosc/Zakaz-aut-spalinowych-do-2035-r-Jest-ostateczna-decyzja-Rady-UE-8512988.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zakaz-aut-spalinowych-do-2035-r-Jest-ostateczna-decyzja-Rady-UE-8512988.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 12:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/939030a1ee4806-948-568-9-119-1974-1184.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada UE przyjęła we wtorek rozporządzenie określające bardziej rygorystyczne normy emisji CO2 dla nowych samochodów osobowych i dostawczych. Regulacja zakłada 100 proc. redukcji emisji dwutlenku węgla w przypadku nowych pojazdów po 2035 roku.</p>

## Rząd chwali siebie za niskie podatki. "Efektywna stawka PIT wynosi 8,47 proc"
 - [https://www.bankier.pl/wiadomosc/Rzad-chwali-siebie-za-niskie-podatki-Efektywna-stawka-PIT-wynosi-8-47-proc-8512969.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-chwali-siebie-za-niskie-podatki-Efektywna-stawka-PIT-wynosi-8-47-proc-8512969.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 12:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/c/b2f2c039e8e536-948-568-4-417-1288-772.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polacy płacą niskie podatki? Taki wniosek można wysnuć ze słów wiceministra finansów Artura Sobonia, który zaznaczył,  że po zmianach podatkowych efektywna stawka PIT wynosi w Polsce 8,47 proc.</p>

## RPO pyta MF o stan prac nad zmianami w tzw. podatku Belki
 - [https://www.bankier.pl/wiadomosc/RPO-pyta-MF-o-stan-prac-nad-zmianami-w-tzw-podatku-Belki-8512953.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/RPO-pyta-MF-o-stan-prac-nad-zmianami-w-tzw-podatku-Belki-8512953.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 11:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/6a5bf61f11c4fa-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rzecznik Praw Obywatelskich pyta resort finansów o stan prac nad zmianami w tzw. podatku Belki.</p>

## Soboń zdradził, ile kosztowała obniżka VAT w ramach tarczy antyinflacyjnej
 - [https://www.bankier.pl/wiadomosc/Sobon-zdradzil-ile-kosztowala-obnizka-VAT-w-ramach-tarczy-antyinflacyjnej-8512951.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sobon-zdradzil-ile-kosztowala-obnizka-VAT-w-ramach-tarczy-antyinflacyjnej-8512951.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 11:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/b35d5260d8f705-948-568-0-17-1773-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obniżka VAT-u zawarta w tarczy antyinflacyjnej, która została wprowadzona w ubiegłym roku, kosztowała budżet 37 mld zł – powiedział we wtorek wiceminister finansów Artur Soboń.</p>

## Dotacja warunkowa, czyli co? Wszystko, o czym musisz wiedzieć
 - [https://www.bankier.pl/wiadomosc/Dotacja-warunkowa-czyli-co-Wszystko-o-czym-musisz-wiedziec-8512844.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dotacja-warunkowa-czyli-co-Wszystko-o-czym-musisz-wiedziec-8512844.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 11:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/2/994f22e481fe4b-948-568-4-49-989-593.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oprócz dostępnych dotąd w ramach Funduszy Europejskich bezzwrotnych oraz zwrotnych form finansowania w nowej perspektywie 2021-2027 dostępna będzie trzecia opcja – dotacja warunkowa.</p>

## Europejczycy ruszyli do banków. Rekordowe wypłaty depozytów
 - [https://www.bankier.pl/wiadomosc/Europejczycy-ruszyli-do-bankow-Rekordowe-wyplaty-depozytow-8512856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Europejczycy-ruszyli-do-bankow-Rekordowe-wyplaty-depozytow-8512856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 11:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/7df0d6ca66fccb-948-568-0-87-2500-1499.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeszcze przed tym, jak wraz z plajtami Silicon Valey 
Banku i Credit Suisse zaczęła się materializować wizja kryzysu 
bankowego, mieszkańcy strefy euro wypłacili z banków rekordową kwotę.</p>

## Giełdowy deweloper planuje odwołać politykę dywidendową
 - [https://www.bankier.pl/wiadomosc/Marvipol-Development-planuje-odwolac-polityke-dywidendowa-8512906.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Marvipol-Development-planuje-odwolac-polityke-dywidendowa-8512906.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 11:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/4/117fb5d7f274a4-948-568-0-210-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Akcjonariusze Marvipol Development zdecydują w sprawie odwołania polityki dywidendowej - podała spółka w projektach uchwał na NWZ, zwołane na 25 kwietnia.</p>

## Kolejne rekordy wykupionych polis zdrowotnych. Polacy ubezpieczają się na potęgę
 - [https://www.bankier.pl/wiadomosc/Polacy-kupuja-coraz-wiecej-prywatnych-ubezpieczen-zdrowotnych-Kolejny-rekord-8512845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-kupuja-coraz-wiecej-prywatnych-ubezpieczen-zdrowotnych-Kolejny-rekord-8512845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 10:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/2/2cf4d6d5b1964d-948-568-0-19-1973-1184.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba prywatnych ubezpieczeń zdrowotnych wzrosła o 9,2 proc. w ciągu roku. Blisko 4,23 mln Polaków posiadało wykupione dodatkowe polisy zdrowotne na koniec 2022 r. – wynika z danych Polskiej Izby Ubezpieczeń.</p>

## USA wyparły Rosję z pozycji największego dostawcy ropy do UE w 2022 r.
 - [https://www.bankier.pl/wiadomosc/USA-wyparly-Rosje-z-pozycji-najwiekszego-dostawcy-ropy-do-UE-w-2022-r-8512865.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-wyparly-Rosje-z-pozycji-najwiekszego-dostawcy-ropy-do-UE-w-2022-r-8512865.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 10:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/c08f9702dec0d8-948-568-0-84-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />USA wyparły Rosję z pozycji największego dostawcy ropy do UE w 2022 roku - wynika z danych Eurostatu.</p>

## Glapiński: Nie powinniśmy i nie możemy zrezygnować ze złotego. Jest elementem polskiego sukcesu gospodarczego
 - [https://www.bankier.pl/wiadomosc/Glapinski-Nie-powinnismy-i-nie-mozemy-zrezygnowac-ze-zlotego-Jest-elementem-polskiego-sukcesu-gospodarczego-8512863.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Glapinski-Nie-powinnismy-i-nie-mozemy-zrezygnowac-ze-zlotego-Jest-elementem-polskiego-sukcesu-gospodarczego-8512863.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 10:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/146908ac572f9c-948-568-0-138-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Złoty jest jedną ze składowych polskiego sukcesu gospodarczego. Nie powinniśmy i nie możemy zrezygnować ze złotego – napisał prezes NBP Adam Glapiński w liście do uczestników wtorkowej konferencji poświęconej suwerenności monetarnej.</p>

## Tak PiS omija prawo. Legalizuje wydanie 200 mln złotych wrzutką do ustawy
 - [https://www.bankier.pl/wiadomosc/Wrzutka-do-ustawy-PiS-legalizuje-wydanie-200-mln-zlotych-na-sprzet-medyczny-8512840.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wrzutka-do-ustawy-PiS-legalizuje-wydanie-200-mln-zlotych-na-sprzet-medyczny-8512840.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 10:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/8cc04897c6ec9f-948-568-71-368-3925-2355.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wrzutka do ustawy - to ulubiona forma legislacji obecnego rządu. Tym razem chodzi o 200 mln złotych, które wydała Rządowa Agencja Rezerw Strategicznych na zakup sprzętu medycznego i to bez żadnego przetargu. </p>

## Długi wobec pracowników i nieopłacone rachunki. Tymi danymi rząd nie chce się dzielić
 - [https://www.bankier.pl/wiadomosc/Szpitale-z-duzymi-dlugami-Winny-m-in-Polski-lad-8512764.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szpitale-z-duzymi-dlugami-Winny-m-in-Polski-lad-8512764.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 10:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/17a4f652e4b1e9-945-560-22-105-1477-886.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Straty finansowe sięgające 782 milionów złotych, nieuregulowane rachunki za prąd, gaz czy wodę i długi wobec pracowników. Taki obraz wyłania się z danych, które Związek Powiatów Polskich pozyskał z blisko 200 szpitali. 
</p>

## Prognozy S&P dla Polski. Brak obniżek stóp i dwucyfrowa średnioroczna inflacja w 2023 roku
 - [https://www.bankier.pl/wiadomosc/Prognozy-S-P-dla-Polski-Brak-obnizek-stop-i-dwucyfrowa-srednioroczna-inflacja-w-2023-roku-8512833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prognozy-S-P-dla-Polski-Brak-obnizek-stop-i-dwucyfrowa-srednioroczna-inflacja-w-2023-roku-8512833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 09:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/9/b76336bf4e3529-948-568-0-271-3427-2056.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Agencja S&amp;P Global Ratings podtrzymała prognozę wzrostu gospodarczego w Polsce w 2023 r. na poziomie 0,9 proc. rdr., a na 2024 r. podwyższyła o 0,2 pp. do 3,4 proc. - podano w raporcie S&amp;P. Agencja nie spodziewa się obniżek stóp przez RPP w 2023 r.</p>

## Korea Północna się zbroi. Kim nakazał zwiększenie produkcji materiału do głowic jądrowych
 - [https://www.bankier.pl/wiadomosc/Korea-Polnocna-sie-zbroi-Kim-nakazal-zwiekszenie-produkcji-materialu-do-glowic-jadrowych-8512825.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Korea-Polnocna-sie-zbroi-Kim-nakazal-zwiekszenie-produkcji-materialu-do-glowic-jadrowych-8512825.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/8211444fe087c1-948-568-0-7-1024-614.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przywódca Korei Północnej Kim Dzong Un zarządził zwiększenie produkcji materiału do bomb jądrowych podczas inspekcji prac związanych z montowaniem głowic nuklearnych na pociskach balistycznych – podały we wtorek państwowe media.</p>

## Twój e-PIT nie działa. Trwa awaria rządowej domeny
 - [https://www.bankier.pl/wiadomosc/Twoj-e-PIT-nie-dziala-Trwa-awaria-rzadowej-domeny-8512821.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Twoj-e-PIT-nie-dziala-Trwa-awaria-rzadowej-domeny-8512821.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 09:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/29e973452d533f-948-568-0-22-1313-787.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Logowanie do serwisu Twój e-PIT danymi podatkowymi jest czasowo 
niedostępne - podało Ministerstwo Finansów. Awaria dotyczy tylko jednego
 sposobu logowania do e-Urzedu Skarbowego. Pozostałe opcje są dostępne.</p>

## Złoty trzyma się nieźle. Kurs euro wciąż idzie w bok
 - [https://www.bankier.pl/wiadomosc/Zloty-trzyma-sie-niezle-Kurs-euro-wciaz-idzie-w-bok-8512811.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zloty-trzyma-sie-niezle-Kurs-euro-wciaz-idzie-w-bok-8512811.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 09:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/5/cbd49580b9f131-948-568-0-0-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od kilku dni kurs euro pozostaje w wąskiej konsolidacji, w
pobliżu tegorocznych minimów. Analitycy nie dostrzegają w najbliższym czasie
czynników, które mogłyby wytrącić złotego z równowagi.</p>

## Ministerstwo Finansów planuje emisję obligacji nominowanych w dolarze amerykańskim
 - [https://www.bankier.pl/wiadomosc/Ministerstwo-Finansow-planuje-emisje-obligacji-nominowanych-w-dolarze-amerykanskim-8512807.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ministerstwo-Finansow-planuje-emisje-obligacji-nominowanych-w-dolarze-amerykanskim-8512807.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 09:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/3/bb7da2367d4aff-945-560-0-43-1706-1023.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Finansów planuje emisję 10-letnich i 30-letnich obligacji benchmarkowych nominowanych w dolarze amerykańskim - wynika w komunikatu resortu finansów.</p>

## Zasięgi, lajki, suby... Oto najpopularniejsi influencerzy w Polsce
 - [https://www.bankier.pl/wiadomosc/Oto-najpopularniejsi-influencerzy-w-Polsce-8512750.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oto-najpopularniejsi-influencerzy-w-Polsce-8512750.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 08:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/c/24e16afa47f126-880-527-120-147-880-527.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Robert Lewandowski, Wersow i Anna Lewandowska - to trójka 
najpopularniejszych influencerów w Polsce. Tuż za podium znalazł się 
Friz, czyli Karol Wiśniewski, twórca Ekipy. See Bloggers z Influ Tool 
zaprezentowali najnowszy ranking polskich influencerów za 2022 rok.</p>

## Gospodarka w dalszym ciągu hamuje. Spadł kolejny wskaźnik
 - [https://www.bankier.pl/wiadomosc/Gospodarka-w-dalszym-ciagu-hamuje-Wskaznik-Wyprzedzajacy-Koniunktury-znow-spadl-8512767.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gospodarka-w-dalszym-ciagu-hamuje-Wskaznik-Wyprzedzajacy-Koniunktury-znow-spadl-8512767.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 08:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/d/3b1fb35b430c68-948-568-420-0-1125-675.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z gospodarki płynie coraz więcej złych wieści. Tym razem Wskaźnik Wyprzedzający Koniunktury (WWK), informujący o przyszłych tendencjach w gospodarce, w marcu br. spadł o 0,8 pkt. wobec wartości ze stycznia i lutego - podało Biuro Inwestycji i Cykli Ekonomicznych BIEC.</p>

## Disney szuka oszczędności i zwalnia. Pracę straci kilka tysięcy osób
 - [https://www.bankier.pl/wiadomosc/Zwolnienia-grupowe-w-Disney-Firma-chce-poprawic-finanse-8512732.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zwolnienia-grupowe-w-Disney-Firma-chce-poprawic-finanse-8512732.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 07:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/d5a9240d636e60-948-568-0-121-1950-1169.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stało się to, co zapowiadano na początku lutego. Disney rozpoczął zwolnienia grupowe, co ma poprawić kondycję finansową firmy. Disney stara się kontrolować koszty i "usprawnić" biznes - napisał w liście do pracowników Bob Iger dyrektor generalny Walt Disneya, cytowany przez agencję Reuters.</p>

## Wysokie ceny ropy. Spór Turcji z Irakiem podbija notowania
 - [https://www.bankier.pl/wiadomosc/Wysokie-ceny-ropy-Spor-Turcji-z-Irakiem-podbija-notowania-8512737.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wysokie-ceny-ropy-Spor-Turcji-z-Irakiem-podbija-notowania-8512737.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 07:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/3/cce5a5d57082f9-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku są blisko 73 USD za baryłkę po zwyżce na koniec poprzedniej sesji o ponad 5 proc., najmocniejszej od października 2022 r.  informują maklerzy. Inwestorów zaniepokoiły zakłócenia w dostawach ropy z Turcji.</p>

## Revolut rozszerza swoją ofertę o kolejne produkty finansowe. Ma być sporo tańszy od konkurencji
 - [https://www.bankier.pl/wiadomosc/Revolut-wchodzi-w-ubezpieczenia-komunikacyjne-8512720.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Revolut-wchodzi-w-ubezpieczenia-komunikacyjne-8512720.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 06:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/acca85ed73891d-948-568-7-27-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Revolut rozszerza swoją ofertę o kolejne produkty finansowe. Tym razem zamierza zaoferować ubezpieczenia komunikacyjne. Zacznie do Irlandii, ale prawdopodobnie produkty te pojawią się wkrótce na innych rynkach. Przekonuje, że jego oferta może być nawet 30 proc. tańsza.</p>

## Sygnaliści w martwym punkcie. Polsce grożą kary od KE
 - [https://www.bankier.pl/wiadomosc/Sygnalisci-w-martwym-punkcie-Polsce-groza-kary-od-KE-8512682.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sygnalisci-w-martwym-punkcie-Polsce-groza-kary-od-KE-8512682.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 06:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/1c5e97ffff0400-948-568-34-0-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska jest już o ponad dwa lata opóźniona we wdrażaniu dyrektywy o sygnalistach. Do TSUE trafiła już skarga Komisji Europejskiej w tej sprawie. - Coraz bardziej realna staje się perspektywa płacenia przez Polskę...</p>

## Droga i chuda Wielkanoc. Polacy planują oszczędzać podczas świąt
 - [https://www.bankier.pl/wiadomosc/Droga-i-chuda-Wielkanoc-Polacy-planuja-oszczedzac-podczas-swiat-8512690.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Droga-i-chuda-Wielkanoc-Polacy-planuja-oszczedzac-podczas-swiat-8512690.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/a5627f94a7f6c4-948-568-0-116-3327-1996.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W tym roku czeka nas droga Wielkanoc. W związku z 
inflacją oszczędzać zamierza aż 70 proc. z na 65 proc. Polaków planuje 
oszczędności do poziomu 30 proc. - pisze wtorkowa "Rzeczpospolita".</p>

## Zakaz sprzedaży aut spalinowych coraz bliżej. Niemcy ustępują, Polska wręcz przeciwnie
 - [https://www.bankier.pl/wiadomosc/Zakaz-sprzedazy-aut-spalinowych-coraz-blizej-Niemcy-ustepuja-Polska-wrecz-przeciwnie-8512688.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zakaz-sprzedazy-aut-spalinowych-coraz-blizej-Niemcy-ustepuja-Polska-wrecz-przeciwnie-8512688.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/5a9d84f9c66ab9-948-568-0-14-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Unia Europejska zakaże sprzedaży nowych samochodów z silnikami spalinowymi po 2035 roku. Niemcy wycofali swoje obiekcje co do zakazu, ale Polska nadal się sprzeciwia - zwraca uwagę wtorkowa "Rzeczpospolita".</p>

## Patkowski: Ugody to najlepsze rozwiązanie i dla frankowców, i dla banków
 - [https://www.bankier.pl/wiadomosc/Patkowski-Ugody-to-najlepsze-rozwiazanie-i-dla-frankowcow-i-dla-bankow-8512685.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Patkowski-Ugody-to-najlepsze-rozwiazanie-i-dla-frankowcow-i-dla-bankow-8512685.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/5/1c9274c7fa36c7-948-568-34-22-4505-2703.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Banki wciąż mają w swoich rękach silne instrumenty, by problem frankowy sprawiedliwie uregulować, czyli ugody. One są obecnie zawierane, ale ich potencjał nie jest wykorzystany – mówi w rozmowie z wtorkową "Rzeczpospolitą" Piotr Patkowski, wiceminister finansów.</p>

## Przed nami dekada wysokich cen energii? "Polska będzie droga względem reszty Europy"
 - [https://www.bankier.pl/wiadomosc/Przed-nami-dekada-wysokich-cen-energii-Polska-bedzie-droga-wzgledem-reszty-Europy-8512675.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przed-nami-dekada-wysokich-cen-energii-Polska-bedzie-droga-wzgledem-reszty-Europy-8512675.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/20e1a66f65952c-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rozwój OZE w krajach bałtyckich jest obecnie bardzo szybki, natomiast polskie regulacje raczej hamują źródła odnawialne - mówi prezes Enefit Polska Maciej Kowalski. Jak dodaje, bez dużych wolumenów zielonej energii ceny w Polsce pozostaną wyższe względem innych krajów UE.</p>

## Większość Polaków zaciska pasa, jednak nie wszyscy. Na to wydadzą większe pieniądze
 - [https://www.bankier.pl/wiadomosc/Wiekszosc-Polakow-zaciska-pasa-jednak-nie-wszyscy-Na-to-wydadza-wieksze-pieniadze-8512669.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiekszosc-Polakow-zaciska-pasa-jednak-nie-wszyscy-Na-to-wydadza-wieksze-pieniadze-8512669.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/c/f1c95820b677fa-948-568-0-48-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dużych wydatków nie planuje w tym roku 67 proc. rodaków – wynika z badania „Polaków Portfel Własny: czas oszczędzania”. Co trzecia osoba, która chce przeznaczyć w najbliższym czasie "istotną sumę" na jakiś cel, wskazuje na podróże.</p>

## "T-shirt z butelek PET" czy "opakowanie z recyklingu". UE chce skończyć z ekościemą
 - [https://www.bankier.pl/wiadomosc/UE-chce-skonczyc-z-ekosciema-Konsumenci-beda-zadowoleni-8512130.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UE-chce-skonczyc-z-ekosciema-Konsumenci-beda-zadowoleni-8512130.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/b/269ae3f5c877f1-948-568-0-157-4210-2525.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gdy liczba oznaczeń ekologicznych na unijnym rynku dobija do 230, to znak, że coś jest nie tak. Zwłaszcza gdy wiele takich produktów z ekologią łączy jedynie nazwa.  Komisja Europejska zamierza uporządkować ten rozgardiasz, wprowadzając m.in. bardziej restrykcyjne zasady dotyczące etykiet.
</p>

## Im dłużej żyjemy, tym mniej dostajemy. Niższa śmiertelność pogorszyła emerytalny przelicznik
 - [https://www.bankier.pl/wiadomosc/Nizsza-smiertelnosc-pogorszyla-emerytalny-przelicznik-8512318.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nizsza-smiertelnosc-pogorszyla-emerytalny-przelicznik-8512318.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/d47e9cd68d7a34-948-568-0-24-2472-1483.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tegoroczne emerytury będą wyliczane w oparciu o mniej
korzystny dla seniorów parametr demograficzny. To efekt nieco mniejszej
śmiertelności odnotowanej w 2022 roku.

 
  
 

 
  Normal
  0
  
  
  21
  
  
  false
  false
  false
  
  PL
  X-NONE
  X-NONE
  
   
   
   
   
   
   
   
   
   
  
  
   
   
   
   
   
   
   
   
   
   
   
  

 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 


</p>

## Jak otrzymać większy zwrot od fiskusa, czyli PIT za 2022 r.  Zapisz się na webinar Bankier.pl i PIT.pl
 - [https://www.bankier.pl/wiadomosc/Jak-otrzymac-wiekszy-zwrot-od-fiskusa-czyli-PIT-za-2022-r-Zapisz-sie-na-webinar-Bankier-pl-i-PIT-pl-8509190.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jak-otrzymac-wiekszy-zwrot-od-fiskusa-czyli-PIT-za-2022-r-Zapisz-sie-na-webinar-Bankier-pl-i-PIT-pl-8509190.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/c4b780fc00e412-948-568-0-116-3899-2339.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie dokonałeś jeszcze rozliczenia z urzędem skarbowym za 2022 rok? A 
może wysłałeś PIT, ale nie ująłeś wszystkich odliczeń? Masz pytania na 
ten temat? Ekspert odpowie na nie w nowym webinarze Bankier.pl i PIT.pl.
 Zapisz się, żeby poznać proste i praktyczne sposoby na zwiększenie 
kwoty zwrotu od fiskusa w 2023 roku.</p>

## Kryzys bankowy: kto będzie następny? Czy polskie banki są zagrożone? "Zdania ekspertów są podzielone" - odc. 13
 - [https://www.bankier.pl/wiadomosc/Kryzys-bankowy-kto-bedzie-nastepny-Czy-polskie-banki-sa-zagrozone-Zdania-ekspertow-sa-podzielone-odc-13-8512276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kryzys-bankowy-kto-bedzie-nastepny-Czy-polskie-banki-sa-zagrozone-Zdania-ekspertow-sa-podzielone-odc-13-8512276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/774fce95dbb119-948-568-0-153-3072-1843.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W trzynastym i ostatnim odcinku programu "Zdania ekspertów są podzielone" rozmawiamy o kryzysie bankowym.</p>

## Megagroźna sztuczna inteligencja? Potrzebne pilne regulacje
 - [https://www.bankier.pl/wiadomosc/Megagrozna-sztuczna-inteligencja-Potrzebne-pilne-regulacje-8512068.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Megagrozna-sztuczna-inteligencja-Potrzebne-pilne-regulacje-8512068.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/8/cb5cadb64d6224-948-568-0-0-1500-900.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ostatnim czasie internet obiegły zdjęcia rzekomo 
aresztowanego Donalda Trumpa czy Angeli Merkel jedzącej lody z Barackiem
 Obamą na plaży. Co je łączy? Zostały wygenerowane przez sztuczną 
inteligencję i są bardzo realistyczne. Chyba tylko sprawne oko i duże 
powiększenie pozwala ocenić, że nie są to prawdziwe fotografie. Czy jest
 się czego obawiać? </p>

## Najlepsze lokaty na rok. Tu wciąż króluje stawka wyższa niż 8 proc.
 - [https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-12-miesiecy-marzec-2023-Ranking-Bankier-pl-8512184.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-12-miesiecy-marzec-2023-Ranking-Bankier-pl-8512184.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/ba7b86e607edbc-948-568-262-344-2737-1642.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poszukujący korzystnej oferty na 12 miesięcy mogą liczyć na stawkę sięgającą 8,20 proc. w skali roku. Poza liderem tylko jeden bank jest skłonny wynagrodzić oszczędzających oprocentowaniem wynoszącym co najmniej 8 proc.</p>

## Ważny termin dla przedsiębiorców. Na wsparcie przeznaczono ponad pół miliarda euro
 - [https://www.bankier.pl/wiadomosc/Wazny-termin-dla-przedsiebiorcow-Na-wsparcie-przeznaczono-ponad-pol-miliarda-euro-8510987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wazny-termin-dla-przedsiebiorcow-Na-wsparcie-przeznaczono-ponad-pol-miliarda-euro-8510987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/e/462ad3c18b5ab7-948-568-45-82-2955-1772.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już od czwartku 23 marca przedsiębiorcy mogą ubiegać się o unijne środki na innowacje w ramach kredytu technologicznego, na który przeznaczono łącznie aż 578 mln euro. Nowe rozdanie to kontynuacja cieszącej się dużym zainteresowaniem oferty Kredyt na innowacje technologiczne będącej częścią Programu Operacyjnego Inteligentny Rozwój (PIOR). Tym razem jednak wsparcie finansowe popłynie z innego źródła, bo z programu Fundusze Europejskie dla Nowoczesnej Gospodarki (FENG).


</p>

## Firmy mają problem z niesolidnymi klientami. W tych branżach jest najgorzej
 - [https://www.bankier.pl/wiadomosc/Firmy-maja-problem-z-niesolidnymi-klientami-W-tych-branzach-jest-najgorzej-8512667.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Firmy-maja-problem-z-niesolidnymi-klientami-W-tych-branzach-jest-najgorzej-8512667.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 04:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/b4559e8d064930-948-568-0-112-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 88 proc. małych i średnich przedsiębiorców wskazuje, że ich klienci płacą faktury po terminie - wskazano w badaniu Skaner MŚP. Rozliczenia między badanymi firmami najbardziej pogorszyły się w branży handlowej i transportowej, a poprawa widoczna jest tylko w budownictwie - dodano.</p>

## Policja w Peru przechwyciła kokainę o wartości 20 mln dolarów
 - [https://www.bankier.pl/wiadomosc/Policja-w-Peru-przechwycila-kokaine-o-wartosci-20-mln-dolarow-8512656.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Policja-w-Peru-przechwycila-kokaine-o-wartosci-20-mln-dolarow-8512656.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-28 02:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/83d7f5149142f7-945-560-0-95-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze peruwiańskie poinformowały w poniedziałek, że przejęły w piątek ponad 2 tony kokainy w największym porcie Peru, El Callao, na obrzeżach stolicy Limy, która miała trafić do Turcji  szlakiem morskim.</p>

