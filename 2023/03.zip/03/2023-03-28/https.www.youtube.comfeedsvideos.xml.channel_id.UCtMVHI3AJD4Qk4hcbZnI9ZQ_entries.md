# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## So... Chris Chan Got Freed From Prison...
 - [https://www.youtube.com/watch?v=zx4THF_9nUs](https://www.youtube.com/watch?v=zx4THF_9nUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-03-28 21:51:02+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at the newest development when it comes to the most documented person on the Internet. With Chris Chan finally being released just what comes next in this saga of the Internet's most infamous influencer? Let's find out! Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the newest Podcast episode: https://youtu.be/ab4VwqGgVkE

