# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## DeSantis office slams Forbes contributor's inquiry for being 'cheap,' 'partisan activism
 - [https://www.foxnews.com/media/desantis-office-slams-forbes-contributors-inquiry-being-chearp-partisan-activism](https://www.foxnews.com/media/desantis-office-slams-forbes-contributors-inquiry-being-chearp-partisan-activism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 19:00:11+00:00

A Forbes contributor allegedly sent an inquiry to Florida Gov. DeSantis’ Press Secretary Bryan Griffin for an article claiming &quot;woke&quot; is am anti-equity &quot;slur.&quot;

## Whatever happened to the global chip shortage?
 - [https://www.foxnews.com/politics/whatever-happened-global-chip-shortage](https://www.foxnews.com/politics/whatever-happened-global-chip-shortage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:57:47+00:00

Lawmakers and experts agree that semiconductor manufacturing in the U.S. need to match the production or else it will go underutilized in an attempt to compete with others.

## Ford just made this type of vehicle extinct
 - [https://www.foxnews.com/auto/ford-made-type-vehicle-extinct](https://www.foxnews.com/auto/ford-made-type-vehicle-extinct)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:54:03+00:00

Ford is discontinuing the Transit Connect compact van in the United States at the end of 2023 due to falling demand for this type of vehicle.

## Florida university hosts 'gender-affirming clothes swap'
 - [https://www.foxnews.com/us/florida-university-hosts-gender-affirming-clothes-swap](https://www.foxnews.com/us/florida-university-hosts-gender-affirming-clothes-swap)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:53:20+00:00

A transgendered student group at the University of South Florida hosted a Gender Affirming Clothing Swap in an effort to create a safe space for students.

## Paige Spiranac says 'disgusting sexual' rumors keep her guarded at golf events with male celebrities
 - [https://www.foxnews.com/sports/paige-spiranac-says-disgusting-sexual-rumors-keep-her-guarded-golf-events-male-celebrities](https://www.foxnews.com/sports/paige-spiranac-says-disgusting-sexual-rumors-keep-her-guarded-golf-events-male-celebrities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:52:48+00:00

Paige Spiranac has become one of the most popular social media influencers, especially in the golf world, but that has come at a price with constant dating rumors.

## DeSantis press secretary says Fidel Castro children's book not 'true history,' blames progressives
 - [https://www.foxnews.com/politics/desantis-press-secretary-fidel-castro-childrens-book-true-history-blames-progressives](https://www.foxnews.com/politics/desantis-press-secretary-fidel-castro-childrens-book-true-history-blames-progressives)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:50:01+00:00

A children&apos;s book about deceased Cuban leader Fidel Castro was criticized by the spokesperson for Florida Gov. Ron DeSantis.

## Real faith requires thinking and gathering knowledge, says one of the most famous preachers in the world
 - [https://www.foxnews.com/lifestyle/faith-requires-thinking-gathering-knowledge-says-one-most-famous-preachers-world](https://www.foxnews.com/lifestyle/faith-requires-thinking-gathering-knowledge-says-one-most-famous-preachers-world)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:45:16+00:00

Lauren Green, chief religion correspondent for Fox News Channel, spoke with Collin Hansen, whose new book is &quot;Timothy Keller: His Spiritual and Intellectual Formation&quot; — and shares highlights.

## Gwyneth Paltrow's children Apple and Moses used in star's defense during ski collision trial
 - [https://www.foxnews.com/entertainment/gwyneth-paltrow-children-apple-moses-used-stars-defense-during-ski-collision-trial](https://www.foxnews.com/entertainment/gwyneth-paltrow-children-apple-moses-used-stars-defense-during-ski-collision-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:38:26+00:00

Gwyneth Paltrow&apos;s two kids were supposed to take the stand in the civil trial. The actress is being sued for $300,000 over a 2016 ski collision at Utah&apos;s Deer Valley Resort.

## Missing Georgia girl is home safe, but 'there are many unanswered questions': Cops
 - [https://www.foxnews.com/us/missing-georgia-girl-home-safe-there-are-many-unanswered-questions-cops](https://www.foxnews.com/us/missing-georgia-girl-home-safe-there-are-many-unanswered-questions-cops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:36:25+00:00

Havana Alexander, 11, was missing Thursday to Saturday, when she returned to her Georgia family on her own, Walker County Sheriff Steve Wilson said.

## Nashville Covenant school headmaster hailed as hero in wake of shooting: 'She protected her children'
 - [https://www.foxnews.com/us/nashville-covenant-school-headmaster-hailed-hero-wake-shooting-she-protected-children](https://www.foxnews.com/us/nashville-covenant-school-headmaster-hailed-hero-wake-shooting-she-protected-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:34:26+00:00

Local leaders and law enforcement experts are praising school administrators and teachers for their response to Monday&apos;s shooting at the Convenant School in Nashville, Tennessee.

## GOP lawmakers accuse Pentagon doctors of advocating 'chemical castration' of military-connected trans minors
 - [https://www.foxnews.com/media/gop-reps-accuse-pentagon-doctors-advocating-chemical-castration-military-connected-minors-radical-agenda](https://www.foxnews.com/media/gop-reps-accuse-pentagon-doctors-advocating-chemical-castration-military-connected-minors-radical-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:30:23+00:00

GOP representatives demanded answers from Secretary of Defense Lloyd Austin after a Fox News Digital report on its doctors beliefs on gender-affirming care for military-connected children.

## New Hampshire man accused of 5-year-old daughter's murder faces new gun charges
 - [https://www.foxnews.com/us/new-hampshire-man-accused-5-year-old-daughters-murder-faces-new-gun-charges](https://www.foxnews.com/us/new-hampshire-man-accused-5-year-old-daughters-murder-faces-new-gun-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:29:44+00:00

Adam Montgomery, already accused of killing his five-year-old daughter, has been indicted again by the Hillsborough County, New Hampshire Grand Jury on gun charges.

## France refuses to extradite far-left Italian terrorists who have eluded justice since 1980s
 - [https://www.foxnews.com/world/france-refuses-extradite-far-left-italian-terrorists-eluded-justice-since-1980s](https://www.foxnews.com/world/france-refuses-extradite-far-left-italian-terrorists-eluded-justice-since-1980s)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:28:34+00:00

A French court has declined to extradite ten convicted left-wing terrorists to their native Italy for their roles in decades-old attacks.

## Biden falsely claims it's illegal to own a flamethrower while calling for action against 'weapons of war'
 - [https://www.foxnews.com/politics/biden-falsely-claims-illegal-own-flamethrower-while-calling-for-action-against-weapons-of-war](https://www.foxnews.com/politics/biden-falsely-claims-illegal-own-flamethrower-while-calling-for-action-against-weapons-of-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:26:34+00:00

President Biden on Tuesday said flamethrowers are illegal in the United States while calling for action against &quot;weapons of war.&quot; Flamethrowers, however, are not illegal.

## European boxing champion, 22, killed while defending Ukraine in war: official
 - [https://www.foxnews.com/sports/european-boxing-champion-22-killed-defending-ukraine-war-official](https://www.foxnews.com/sports/european-boxing-champion-22-killed-defending-ukraine-war-official)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:19:10+00:00

Officials in Ukraine announced Friday that European Youth Boxing champion Maksym Galinichev died while &quot;defending Ukraine.&quot; He was 22.

## Pennsylvania authorities rule out utility natural gas in blast that killed 5
 - [https://www.foxnews.com/us/pennsylvania-authorities-rule-utility-natural-gas-blast-killed-5](https://www.foxnews.com/us/pennsylvania-authorities-rule-utility-natural-gas-blast-killed-5)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:04:01+00:00

Pennsylvania investigators ruled out utility natural gas as the cause in a home explosion that killed five people last year. Officials said PECO wasn&apos;t supplying gas to home.

## Military members sue US government over Pearl Harbor jet fuel spill
 - [https://www.foxnews.com/us/military-members-sue-us-government-pearl-harbor-jet-fuel-spill](https://www.foxnews.com/us/military-members-sue-us-government-pearl-harbor-jet-fuel-spill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:02:27+00:00

Military members filed a claim against the government over jet fuel that contaminated drinking water in Hawaii. This is the first step that will allow them to file a federal lawsuit.

## Rockets coach Stephen Silas 'broke down in tears' amid another woeful season: report
 - [https://www.foxnews.com/sports/rockets-coach-stephen-silas-broke-down-tears-another-woeful-season-report](https://www.foxnews.com/sports/rockets-coach-stephen-silas-broke-down-tears-another-woeful-season-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 18:01:06+00:00

Houston Rockets head coach Stephen Silas is going through another rough season, and a new report says that it got to the point where he &quot;broke down in tears.&quot;

## Nashville school shooting highlights America's 'soul problem': Trey Gowdy
 - [https://www.foxnews.com/media/nashville-school-shooting-highlights-americas-soul-problem-trey-gowdy](https://www.foxnews.com/media/nashville-school-shooting-highlights-americas-soul-problem-trey-gowdy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:59:59+00:00

&apos;Sunday Night in America&apos; host Trey Gowdy responds to The Covenant School shooting Monday where three children and three adults were killed.

## Ohio legislators introduce bill abolishing death penalty
 - [https://www.foxnews.com/politics/ohio-legislators-introduce-bill-abolishing-death-penalty](https://www.foxnews.com/politics/ohio-legislators-introduce-bill-abolishing-death-penalty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:59:11+00:00

Ohio state senators have introduced a bipartisan bill that would abolish the death penalty in the Buckeye State, though some Republican legislators and officials have concerns.

## US stops sharing nuke data with Russia over Moscow’s noncompliance with New START treaty, officials say
 - [https://www.foxnews.com/politics/us-stops-sharing-nuke-data-russia-moscows-noncompliance-new-start-treaty-officials-say](https://www.foxnews.com/politics/us-stops-sharing-nuke-data-russia-moscows-noncompliance-new-start-treaty-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:58:50+00:00

The United States is no longer sharing nuclear information with Russia following Russian President Vladimir Putin to suspend his country&apos;s participation in the New START Treaty.

## US Supreme Court won't review GOP-controlled Kansas congressional map
 - [https://www.foxnews.com/politics/us-supreme-court-wont-review-gop-controlled-kansas-congressional-map](https://www.foxnews.com/politics/us-supreme-court-wont-review-gop-controlled-kansas-congressional-map)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:56:55+00:00

The U.S. Supreme Court will not review the GOP-controlled Kansas congressional map. Democrats viewed the congressional map as political gerrymandering.

## Biden makes multiple false Second Amendment claims in wake of Nashville Covenant school tragedy
 - [https://www.foxnews.com/politics/biden-makes-false-second-amendment-claims-wake-nashville-covenant-school-tragedy](https://www.foxnews.com/politics/biden-makes-false-second-amendment-claims-wake-nashville-covenant-school-tragedy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:55:55+00:00

President Biden addressed the Nashville, Tennessee shooting during a speech on Tuesday, which was filled with multiple false claims like the leading cause of death of children.

## ESPN's Stephen A. Smith fires back on criticism of sports debate TV: 'You ain't innocent'
 - [https://www.foxnews.com/sports/espn-stephen-a-smith-fires-back-criticism-sports-debate-tv-you-aint-innocent](https://www.foxnews.com/sports/espn-stephen-a-smith-fires-back-criticism-sports-debate-tv-you-aint-innocent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:54:01+00:00

ESPN personality Stephen A. Smith fired back at podcast host Dan Le Batard when confronted with criticism for what Smith has done to sports debate television.

## Pasta product pulled from Midwestern grocery stores over 'undeclared milk'
 - [https://www.foxnews.com/us/pasta-product-pulled-midwestern-grocery-stores-undeclared-milk](https://www.foxnews.com/us/pasta-product-pulled-midwestern-grocery-stores-undeclared-milk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:49:04+00:00

Iowa-based grocery chain HyVee is recalling its Hamburger Chili Macaroni Skillets from store shelves in eight Midwestern states over &quot;undeclared milk&quot; being included in the product.

## Maryland appellate court reinstates Adnan Syed’s murder conviction, orders new hearing
 - [https://www.foxnews.com/us/maryland-appellate-court-reinstates-adnan-syeds-murder-conviction-orders-new-hearing](https://www.foxnews.com/us/maryland-appellate-court-reinstates-adnan-syeds-murder-conviction-orders-new-hearing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:47:31+00:00

A Maryland court backed the victim&apos;s family Tuesday in reinstating Adnan Syed&apos;s murder conviction. A judge ordered a new hearing, but he won&apos;t be taken back into custody immediately.

## Ballot problems in Pennsylvania's Luzerne County examined
 - [https://www.foxnews.com/politics/ballot-problems-pennsylvanias-luzerne-county-examined](https://www.foxnews.com/politics/ballot-problems-pennsylvanias-luzerne-county-examined)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:45:44+00:00

The House Administration Committee heard testimony Tuesday on what Democratic New York Rep. Joe Morelle called the &quot;complete breakdown&quot; of Luzerne County, PA&apos;s voting infrastrucure.

## Michigan AG Nessel says income tax cut temporary
 - [https://www.foxnews.com/politics/michigan-ag-nessel-says-income-tax-cut-temporary](https://www.foxnews.com/politics/michigan-ag-nessel-says-income-tax-cut-temporary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:44:23+00:00

Democratic Michigan Attorney General Dana Nessel said Tuesday that an income tax cut expected to be levied this year is impermanent, and rates will revert back to normal in 2024.

## Coast Guard to investigate Boston Harbor cruise ship fire
 - [https://www.foxnews.com/us/coast-guard-investigate-boston-harbor-cruise-ship-fire](https://www.foxnews.com/us/coast-guard-investigate-boston-harbor-cruise-ship-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:43:10+00:00

The Coast Guard is investigating a fire aboard the 153-foot Spirit of Boston cruise ship at the Massachusetts capital&apos;s Commonwealth Pier.

## Fox News crushes Q1 cable news viewership, CNN has smallest primetime audience in key demo since 1991
 - [https://www.foxnews.com/media/fox-news-crushes-q1-cable-news-viewership-cnn-smallest-primetime-audience-key-demo-since-1991](https://www.foxnews.com/media/fox-news-crushes-q1-cable-news-viewership-cnn-smallest-primetime-audience-key-demo-since-1991)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:34:18+00:00

Fox News continued to dominate cable news viewership during the first quarter of 2023 while CNN had its smallest audience since 1991 among viewers sought by advertisers.

## Italians push back against U.S. parents who called Michaellangelo's statue of David 'pornographic'
 - [https://www.foxnews.com/media/italians-push-back-against-us-parents-called-statue-david-pornographic](https://www.foxnews.com/media/italians-push-back-against-us-parents-called-statue-david-pornographic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:30:59+00:00

The Florence museum housing Michelangelo’s statue of David invited parents and students from a Florida charter school to come and see the masterpiece in person following complaints that the sculpture was &apos;pornographic.&apos;

## Fox News' Greg Gutfeld reveals the cover of his upcoming new book 'The King Of Late Night'
 - [https://www.foxnews.com/media/fox-news-greg-gutfeld-reveals-cover-his-upcoming-new-book-king-late-night](https://www.foxnews.com/media/fox-news-greg-gutfeld-reveals-cover-his-upcoming-new-book-king-late-night)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:28:06+00:00

Fox News Channel host Greg Gutfeld unveiled the hysterical cover for his upcoming book, &quot;The King Of Late Night,&quot; Monday on his eponymous program &quot;Gutfeld!&quot;

## Florida ice cream man found guilty in double revenge homicide of two brothers
 - [https://www.foxnews.com/us/florida-ice-cream-man-found-guilty-double-revenge-homicide-brothers](https://www.foxnews.com/us/florida-ice-cream-man-found-guilty-double-revenge-homicide-brothers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:26:17+00:00

A former Florida ice cream truck driver was found guilty Tuesday morning of killing two brothers and attempting to murder four others, more than 12 years ago.

## Rand Paul smacks down bipartisan TikTok ban bills: 'Goes against the First Amendment'
 - [https://www.foxnews.com/politics/rand-paul-bipartisan-tiktok-ban-first-amendment](https://www.foxnews.com/politics/rand-paul-bipartisan-tiktok-ban-first-amendment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:17:37+00:00

Sen. Rand Paul is among the few Republicans opposing Congress&apos; efforts to ban China-based social media app TikTok, arguing it runs afoul of the First Amendment.

## Drag queen straddles girl at North Carolina public school, video shows
 - [https://www.foxnews.com/politics/drag-queen-straddles-girl-north-carolina-public-school-video-shows](https://www.foxnews.com/politics/drag-queen-straddles-girl-north-carolina-public-school-video-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:16:53+00:00

A North Carolina public school that enrolls children as young as 14 hosted a LGBTQ pride festival last week that featured drag performances.

## Ex-Vermont governor sues Middlebury College for changing name of its chapel based on ‘grossly distorted claim’
 - [https://www.foxnews.com/media/ex-vermont-governor-sues-middlebury-college-changing-name-its-chapel-based-grossly-distorted-claim](https://www.foxnews.com/media/ex-vermont-governor-sues-middlebury-college-changing-name-its-chapel-based-grossly-distorted-claim)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:12:15+00:00

Former Vermont Governor James Douglas sued his alma mater Middlebury College on Friday for removing former Governor John Mead as the school chapel&apos;s namesake.

## Giants fans send off three-time World Series champion with standing ovation in final career game
 - [https://www.foxnews.com/sports/giants-fans-send-three-time-world-series-champion-standing-ovation-final-career-game](https://www.foxnews.com/sports/giants-fans-send-three-time-world-series-champion-standing-ovation-final-career-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:08:53+00:00

San Francisco Giants reliever Sergio Romo received a standing ovation from the Giants crowd on Monday as he pitched one final time before retiring.

## Jen Shah's prison sentence reduced by one year
 - [https://www.foxnews.com/entertainment/jen-shah-prison-sentence-reduced-one-year](https://www.foxnews.com/entertainment/jen-shah-prison-sentence-reduced-one-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:01:29+00:00

Jen Shah of &quot;The Real Housewives of Salt Lake City&quot; had her prison sentenced reduced from 78 to 66 months, meaning she&apos;ll be out in 2028.

## Iowa Wesleyan University to close after nearly 2 centuries
 - [https://www.foxnews.com/us/iowa-wesleyan-university-close-nearly-2-centuries](https://www.foxnews.com/us/iowa-wesleyan-university-close-nearly-2-centuries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:01:00+00:00

Iowa Wesleyan University will close in May, with this year&apos;s graduating class being the last in the Mount Pleasant school&apos;s 181-year history.

## Athlete Riley Gaines protested at University of Pittsburgh: 'I'm doing something right'
 - [https://www.foxnews.com/media/athlete-riley-gaines-protested-university-pittsburgh-im-doing-something-right](https://www.foxnews.com/media/athlete-riley-gaines-protested-university-pittsburgh-im-doing-something-right)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 17:00:11+00:00

Athlete Riley Gaines notes the difference in how Dylan Mulvaney was supported on campus, while she faces mass protests and alleged violent threats.

## 49ers' Kyle Shanahan addresses Brock Purdy return, quarterback situation: 'We'll see what happens'
 - [https://www.foxnews.com/sports/49ers-kyle-shanahan-addresses-brock-purdy-return-quarterback-situation-well-see-what-happens](https://www.foxnews.com/sports/49ers-kyle-shanahan-addresses-brock-purdy-return-quarterback-situation-well-see-what-happens)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:59:19+00:00

San Francisco 49ers head coach Kyle Shanahan expressed optimism about the team&apos;s quarterback situation but couldn&apos;t offer a clear timeline on Brock Purdy&apos;s return date.

## GOP opens investigation into Biden admin for obstructing US energy producers with 'radical eco-agenda'
 - [https://www.foxnews.com/politics/gop-opens-investigation-biden-admin-obstructing-us-energy-producers-radical-eco-agenda](https://www.foxnews.com/politics/gop-opens-investigation-biden-admin-obstructing-us-energy-producers-radical-eco-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:56:43+00:00

Two House committees are conducting a joint probe into the Biden administration&apos;s continued oil and gas leasing delays after a leaked memo showed it prioritizing climate.

## Kate Middleton tried seafood dish known as "Viagra"
 - [https://www.foxnews.com/entertainment/kate-middleton-tried-seafood-dish-known-viagra](https://www.foxnews.com/entertainment/kate-middleton-tried-seafood-dish-known-viagra)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:53:24+00:00

A resurfaced clip of Kate Middleton trying a aphrodisiacal seafood in the Bahamas has gone viral, showing a cute exchange between her and Prince William.

## Mayorkas backs assault weapons ban but won't give definition
 - [https://www.foxnews.com/politics/mayorkas-backs-assault-weapons-ban-wont-give-definition](https://www.foxnews.com/politics/mayorkas-backs-assault-weapons-ban-wont-give-definition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:46:33+00:00

Sen. John Kennedy, R-La., on Tuesday quizzed DHS Secretary Alejandro Mayorkas on his support for an assault weapons ban and if he could define what weapons he would ban.

## Yankees' Nestor Cortes Jr. trolls umpire after violating new pitch clock rule
 - [https://www.foxnews.com/sports/yankees-nestor-cortes-jr-trolls-umpire-violating-new-pitch-clock-rule](https://www.foxnews.com/sports/yankees-nestor-cortes-jr-trolls-umpire-violating-new-pitch-clock-rule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:45:57+00:00

New York Yankees starter Nestor Cortes Jr. was called for a bad quick pitch Tuesday because a hitter wasn&apos;t &quot;alert&quot; to him under new pitch clock rules.

## Garland: Too early to say if Nashville school shooting was a hate crime
 - [https://www.foxnews.com/politics/garland-too-early-nashville-school-shooting-hate-crime](https://www.foxnews.com/politics/garland-too-early-nashville-school-shooting-hate-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:44:11+00:00

Attorney General Merrick Garland said Tuesday it&apos;s too soon to say whether DOJ will open up a hate crime investigation into the Nashville school shooting this week.

## Rex Engelbert and Michael Collazo: Who are the Nashville officers who took down Covenant School shooter?
 - [https://www.foxnews.com/us/rex-engelbert-michael-collazo-who-are-nashville-officers-who-took-down-covenant-school-shooter](https://www.foxnews.com/us/rex-engelbert-michael-collazo-who-are-nashville-officers-who-took-down-covenant-school-shooter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:38:32+00:00

Who are the Nashville cops who put down an active shooter in a Christian elementary school Monday?

## German police arrest man who attacked 3 people with hand grenade, knife
 - [https://www.foxnews.com/world/german-police-arrest-man-attacked-3-people-hand-grenade-knife](https://www.foxnews.com/world/german-police-arrest-man-attacked-3-people-hand-grenade-knife)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:37:23+00:00

German police officers arrested a man Saturday who attacked three people with a hand grenade and a knife. The man detonated the grenade in the entrance of an apartment on Friday night.

## Man released from federal prison stabs Rand Paul staffer on second day out
 - [https://www.foxnews.com/us/man-released-federal-prison-stabs-rand-paul-staffer-second-day-out](https://www.foxnews.com/us/man-released-federal-prison-stabs-rand-paul-staffer-second-day-out)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:36:06+00:00

A man who was released from federal prison stabbed U.S. Senate staffer Rand Paul on his second day out. The man was arrested on a charge of assault with intent to kill after the attack.

## WI's Protasiewicz outraises opponent by $10.2M as Soros, Pritzker donations roll in
 - [https://www.foxnews.com/politics/wis-protasiewicz-outraises-opponent-10-2m-soros-pritzker-donations-roll](https://www.foxnews.com/politics/wis-protasiewicz-outraises-opponent-10-2m-soros-pritzker-donations-roll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:33:22+00:00

Liberal Wisconsin Supreme Court candidate Janet Protasiewicz has opened up an eight-figure fundraising lead over conservative opponent and former Justice Dan Kelly.

## Nashville shooting victim Hallie Scruggs, 9, honored in prayer service at family’s former Texas church
 - [https://www.foxnews.com/us/nashville-shooting-victim-hallie-scruggs-honored-prayer-service-familys-former-texas-church](https://www.foxnews.com/us/nashville-shooting-victim-hallie-scruggs-honored-prayer-service-familys-former-texas-church)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:32:26+00:00

A Nashville shooting victim was honored with a prayer service at her family&apos;s former church in Dallas, Texas. The victim was the daughter of lead Covenant Church pastor Scruggs.

## Mossad thwarts 'imminent' attack on Jewish restaurant in Greece, 'extensive' loss of life
 - [https://www.foxnews.com/world/mossad-thwarts-imminent-attack-jewish-restaurant-greece-extensive-loss-life](https://www.foxnews.com/world/mossad-thwarts-imminent-attack-jewish-restaurant-greece-extensive-loss-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:30:47+00:00

Israeli Prime Minister Benjamin Netanyahu said Tuesday that Mossad helped Greek authorities thwart a planned attack on at least one Jewish site in Athens.

## ‘Squid Game’ actor claims he was ‘assaulted’ at Dutch McDonalds: ‘Did not want to serve an American’
 - [https://www.foxnews.com/media/squid-game-actor-claims-assaulted-dutch-mcdonalds-did-not-want-serve-american](https://www.foxnews.com/media/squid-game-actor-claims-assaulted-dutch-mcdonalds-did-not-want-serve-american)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:30:27+00:00

Video footage shows &quot;Squid Game&quot; actor Geoffrey Giuliano have an altercation with staff at a McDonalds in Amsterdam after they refused to serve him.

## Lionel Richie says his 'All Night Long' is 'down to a fierce 15 minutes'
 - [https://www.foxnews.com/entertainment/lionel-richie-says-all-night-long-down-fierce-15-minutes](https://www.foxnews.com/entertainment/lionel-richie-says-all-night-long-down-fierce-15-minutes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:27:59+00:00

Lionel Richie is giving some intimate information on his sex life in a new interview, referencing his hit song &quot;All Night Long.&quot;

## NFL to allow players to wear No. 0 among uniform rule changes, Calvin Ridley jumps at opportunity
 - [https://www.foxnews.com/sports/nfl-allow-players-wear-no-0-uniform-rule-changes-calvin-ridley-jumps-opportunity](https://www.foxnews.com/sports/nfl-allow-players-wear-no-0-uniform-rule-changes-calvin-ridley-jumps-opportunity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:27:12+00:00

National Football League owners have approved a proposal that will allow most of its players to wear the number zero, which had previously been banned from circulation.

## Wisconsin man charged with firebombing offices of pro-life group
 - [https://www.foxnews.com/politics/wisconsin-man-charged-firebombing-offices-pro-life-group](https://www.foxnews.com/politics/wisconsin-man-charged-firebombing-offices-pro-life-group)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:19:18+00:00

The DOJ announced it made an arrest in the case of last year&apos;s firebombing of pro-life group Wisconsin Family Action&apos;s office in Madison, Wisconsin.

## Texas authorities find 29 migrants inside train car days after 3 others died
 - [https://www.foxnews.com/us/texas-authorities-find-migrants-train-car-died](https://www.foxnews.com/us/texas-authorities-find-migrants-train-car-died)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:14:13+00:00

Texas authorities found 29 illegal immigrants aboard a railcar days after other migrants were found on trains elsewhere.

## Impaired semi driver kills 4 males changing tire in Tennessee
 - [https://www.foxnews.com/us/impaired-semi-driver-kills-4-males-changing-tire-tennessee](https://www.foxnews.com/us/impaired-semi-driver-kills-4-males-changing-tire-tennessee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:09:25+00:00

A man who was impaired while driving a tractor-trailer in Tennessee killed four men who were changing tire. The man was charged with four counts of vehicular homicide by intoxication.

## Durham report should be finished 'relatively soon,' Garland says
 - [https://www.foxnews.com/politics/durham-report-finished-relatively-soon-garland](https://www.foxnews.com/politics/durham-report-finished-relatively-soon-garland)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:09:23+00:00

Special Counsel John Durham is expected to finish his report &quot;relatively soon,&quot; after years of investigating the origins of the Trump-Russia probe, Merrick Garland said Tuesday.

## Minnesota man arrested after allegedly running DMT lab out of basement: 'Extremely rare'
 - [https://www.foxnews.com/us/minnesota-man-arrested-allegedly-running-dmt-lab-basement-extremely-rare](https://www.foxnews.com/us/minnesota-man-arrested-allegedly-running-dmt-lab-basement-extremely-rare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:09:10+00:00

Victor Wang, 46, was arrested after law enforcement reportedly found evidence that he was cooking dimethyltryptamine in the basement of his home in Nerstrand, Minnesota.

## New Mexico court upholds Native American actor convictions
 - [https://www.foxnews.com/us/new-mexico-court-upholds-native-american-actor-convictions](https://www.foxnews.com/us/new-mexico-court-upholds-native-american-actor-convictions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:07:34+00:00

The New Mexico court is upholding the convictions of Native American actor Redwolf Pope. Pope was found guilty in 2020 for taking photos of himself sexually assaulting a woman.

## Louisiana helicopter crash victims identified as veteran police officers
 - [https://www.foxnews.com/us/louisiana-helicopter-crash-victims-identified-veteran-police-officers](https://www.foxnews.com/us/louisiana-helicopter-crash-victims-identified-veteran-police-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:06:21+00:00

Louisiana helicopter crash victims have been identified as veteran police officers on Monday. The officers aboard the Robinson R-44 helicopter were called to help in a pursuit, and they never returned.

## Uber vs Lyft: Which ride service comes out on top?
 - [https://www.foxnews.com/tech/uber-vs-lyft-ride-service-comes-out-top](https://www.foxnews.com/tech/uber-vs-lyft-ride-service-comes-out-top)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:04:51+00:00

With Uber and Lyft being the two top ride-share options, Kurt &quot;CyberGuy&quot; Knutsson outlines the pros and cons of both apps for your own transportation needs.

## African pirates hijack oil tanker, capture 16 crewmembers off Congolese coast
 - [https://www.foxnews.com/world/african-pirates-hijack-oil-tanker-capture-16-crewmembers-congolese-coast](https://www.foxnews.com/world/african-pirates-hijack-oil-tanker-capture-16-crewmembers-congolese-coast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:04:49+00:00

Pirates have reportedly seized a Liberian-flagged oil tanker off the coast of Port Pointe-Noire, Congo, with 16 crewmembers aboard. Its current location is unknown.

## Queen and Adam Lambert eager to start post-pandemic tour
 - [https://www.foxnews.com/entertainment/queen-adam-lambert-eager-start-post-pandemic-tour](https://www.foxnews.com/entertainment/queen-adam-lambert-eager-start-post-pandemic-tour)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:03:46+00:00

Queen and Adam Lambert are headed to North America this fall for an expansion of their Rhapsody Tour. The concerts are being billed as a continuation of Queen’s 2017-2019 Rhapsody Tour.

## Manhattan grand jury will not meet on Trump case for the rest of the week: sources
 - [https://www.foxnews.com/politics/manhattan-grand-jury-will-not-meet-on-trump-case-for-the-rest-of-the-week-sources](https://www.foxnews.com/politics/manhattan-grand-jury-will-not-meet-on-trump-case-for-the-rest-of-the-week-sources)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:03:16+00:00

The grand jury hearing evidence in the Manhattan District Attorney’s investigation into former President Donald Trump will not sit on the case again for the rest of the week, multiple sources told Fox News Tuesday.

## Rand Paul speaks out on attacker who stabbed staffer as victim clings to life
 - [https://www.foxnews.com/politics/rand-paul-speaks-out-on-attacker-who-stabbed-staffer-as-victim-clings-to-life](https://www.foxnews.com/politics/rand-paul-speaks-out-on-attacker-who-stabbed-staffer-as-victim-clings-to-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 16:00:57+00:00

Sen. Rand Paul said he is &quot;praying&quot; for staffer Phillip Todd, who was brutally stabbed in Washington, D.C., by a man he reportedly did not know.

## Texas Sen. Cornyn tears into Mayorkas over fentanyl, border crisis: ‘You should be fired’
 - [https://www.foxnews.com/politics/texas-sen-cornyn-tears-mayorkas-fentanyl-border-crisis-you-should-fired](https://www.foxnews.com/politics/texas-sen-cornyn-tears-mayorkas-fentanyl-border-crisis-you-should-fired)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:57:52+00:00

Sen. John Cornyn, R-Texas, hit DHS Secretary Alejandro Mayorkas over his handling of the crisis at the southern border and the continued fentanyl flow into the U.S.

## El Salvador’s gang crackdown stretches to one-year mark with no sign of slowing
 - [https://www.foxnews.com/world/el-salvadors-gang-crackdown-stretches-one-year-mark-no-sign-slowing](https://www.foxnews.com/world/el-salvadors-gang-crackdown-stretches-one-year-mark-no-sign-slowing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:57:28+00:00

El Salvador on Tuesday surpassed the one year mark since the gang-ridden nation began cracking down on organized crime under emergency powers originally intended to last just one month.

## Minneapolis oversight police panel gets record amount of applicants: 'Seems unbelievable'
 - [https://www.foxnews.com/media/minneapolis-oversight-police-panel-record-amount-applicants-seems-unbelievable](https://www.foxnews.com/media/minneapolis-oversight-police-panel-record-amount-applicants-seems-unbelievable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:55:27+00:00

Nearly 200 people apply to an oversight panel for the Minneapolis police department, breaking a record.

## MLB Commissioner Rob Manfred vows rule changes will 'restore baseball to when it was the most popular'
 - [https://www.foxnews.com/sports/mlb-commissioner-rob-manfred-vows-rule-changes-restore-baseball-when-most-popular](https://www.foxnews.com/sports/mlb-commissioner-rob-manfred-vows-rule-changes-restore-baseball-when-most-popular)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:49:03+00:00

Opening Day is two days away, and it will mark the official beginning of new-look baseball with pitch clocks and larger bases, which Rob Manfred thinks will be positive.

## Ex-NFL star believes Patrick Mahomes, Josh Allen to blame for Lamar Jackson's contract dilemma
 - [https://www.foxnews.com/sports/ex-nfl-star-believes-patrick-mahomes-josh-allen-blame-lamar-jacksons-contract-dilemma](https://www.foxnews.com/sports/ex-nfl-star-believes-patrick-mahomes-josh-allen-blame-lamar-jacksons-contract-dilemma)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:47:08+00:00

Former NFL cornerback and current analyst Richard Sherman says Patrick Mahomes and Josh Allen can be blamed for Lamar Jackson&apos;s current contract predicament.

## White House: 'Impossible' to stay away from 'partisan politics' after Nashville school shooting
 - [https://www.foxnews.com/politics/white-house-impossible-stay-partisan-politics-nashville-school-shooting](https://www.foxnews.com/politics/white-house-impossible-stay-partisan-politics-nashville-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:43:44+00:00

It is impossible for the White House to stay away from partisan politics after the school shooting in Nashville on Monday. Officials say Republicans need to endorse gun control.

## DHS chief Mayorkas is willing to 'let children be raped,' Cruz charges in heated Senate border crisis hearing
 - [https://www.foxnews.com/politics/dhs-chief-mayorkas-willing-let-children-raped-cruz-charges-heated-senate-border-crisis-hearing](https://www.foxnews.com/politics/dhs-chief-mayorkas-willing-let-children-raped-cruz-charges-heated-senate-border-crisis-hearing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:39:11+00:00

Sen. Ted Cruz took aim at Homeland Security Secretary Alejandro Mayorkas for the ongoing situation at the border, saying Mayorkas was willing &quot;to let children be raped.&quot;

## LSU student arrested after allegedly stealing $1,500 worth of beer from Tiger Stadium: reports
 - [https://www.foxnews.com/sports/lsu-student-arrested-allegedly-stealing-1500-worth-beer-tiger-stadium-reports](https://www.foxnews.com/sports/lsu-student-arrested-allegedly-stealing-1500-worth-beer-tiger-stadium-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:33:04+00:00

LSUPD arrested a 19-year-old student after he was caught with approximately $1,500 worth of beer in his room that was allegedly stolen from the football stadium, according to reports.

## Lindsey Graham fires back at Biden for 'offensive' tweet: Things are going to 'hell in a handbasket'
 - [https://www.foxnews.com/media/lindsey-graham-fires-back-biden-offensive-tweet-hell-handbasket](https://www.foxnews.com/media/lindsey-graham-fires-back-biden-offensive-tweet-hell-handbasket)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:30:03+00:00

Sen. Lindsey Graham, R-S.C., responds to President Biden&apos;s tweet claiming Republican policies will worsen the border crisis and fentanyl trafficking.

## Radical group's 'Trans Day of Vengeance' moves forward in wake of Nashville school shooting
 - [https://www.foxnews.com/us/radical-groups-trans-day-of-vengeance-moves-forward-wake-nashville-school-shooting](https://www.foxnews.com/us/radical-groups-trans-day-of-vengeance-moves-forward-wake-nashville-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:28:26+00:00

The Trans Radical Activist Network is promoting a &quot;Trans Day of Vengeance&quot; protest at SCOTUS on its website, after a trans school shooter killed six in Nashville this week.

## Nets shutting down Ben Simmons, ending three-time All-Star’s worst statistical season
 - [https://www.foxnews.com/sports/nets-shutting-down-ben-simmons-ending-three-time-all-stars-worst-statistical-season](https://www.foxnews.com/sports/nets-shutting-down-ben-simmons-ending-three-time-all-stars-worst-statistical-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:28:09+00:00

The Brooklyn Nets announced Tuesday they are shutting down Ben Simmons for the rest of the 2022-23 season as he begins rehab on his back.

## USMNT goalie Matt Turner pulls off epic gender reveal, celebrates with teammates on the field
 - [https://www.foxnews.com/sports/usmnt-goalie-matt-turner-pulls-off-epic-gender-reveal-celebrates-with-teammates-field](https://www.foxnews.com/sports/usmnt-goalie-matt-turner-pulls-off-epic-gender-reveal-celebrates-with-teammates-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:28:08+00:00

The U.S. men&apos;s national team got a kick out of their goalkeeper&apos;s unique gender reveal. Matt Turner kicked a mini prop soccer ball after the team’s win over El Salvador.

## Bianca Andreescu exits Miami Open in wheelchair after suffering agonizing injury: ‘Worst pain I’ve ever felt’
 - [https://www.foxnews.com/sports/bianca-andreescu-exits-miami-open-wheelchair-after-suffering-agonizing-injury-worst-pain-ive-ever-felt](https://www.foxnews.com/sports/bianca-andreescu-exits-miami-open-wheelchair-after-suffering-agonizing-injury-worst-pain-ive-ever-felt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:19:57+00:00

Bianca Andreescu, the 2019 U.S. Open champion, was forced to retire from her fourth-round match at the Miami Open on Monday after suffering a lower leg injury.

## Trent Lehrkamp hazing: FBI joins Georgia probe as depraved new details of abuse emerge
 - [https://www.foxnews.com/us/trent-lehrkamp-hazing-fbi-joins-georgia-probe-depraved-new-details-abuse-emerge](https://www.foxnews.com/us/trent-lehrkamp-hazing-fbi-joins-georgia-probe-depraved-new-details-abuse-emerge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:14:26+00:00

The FBI and the Georgia Bureau of Investigation have joined the probe into the assault of 19-year-old Trent Lehrkamp that has left him in the intensive care unit on a ventilator.

## Indiana boy, 16, gets 65 years for murder in vape deal gone wrong
 - [https://www.foxnews.com/us/indiana-boy-16-gets-65-years-murder-vape-deal-gone-wrong](https://www.foxnews.com/us/indiana-boy-16-gets-65-years-murder-vape-deal-gone-wrong)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:13:47+00:00

Aung San Oo, 16, of Fort Wayne, Indiana, was sentenced to 65 years for killing Luke Borror outside a church, where an apparent vape product deal was taking place.

## Fox News Politics: Nashville shooting sparks familiar political battles — and new ones
 - [https://www.foxnews.com/politics/fox-news-politics-nashville-shooting-sparks-familiar-political-battles-new-ones](https://www.foxnews.com/politics/fox-news-politics-nashville-shooting-sparks-familiar-political-battles-new-ones)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:08:09+00:00

Get the latest updates from the 2024 campaign trail, exclusive interviews and more Fox News politics content

## Jeremy Renner credits one person’s love for helping him heal ‘incredibly fast' from snowplow accident
 - [https://www.foxnews.com/entertainment/jeremy-renner-credits-one-persons-love-helping-him-heal-incredibly-fast-snowplow-accident](https://www.foxnews.com/entertainment/jeremy-renner-credits-one-persons-love-helping-him-heal-incredibly-fast-snowplow-accident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:06:36+00:00

Jeremy Renner is still recovering from his horrific snowplow accident and credits one person in particular for helping him to heal quickly.

## Tennessee highway crash death toll rises to 4 youths, 2 adults
 - [https://www.foxnews.com/us/tennessee-highway-crash-death-toll-rises-4-youths-2-adults](https://www.foxnews.com/us/tennessee-highway-crash-death-toll-rises-4-youths-2-adults)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:05:51+00:00

The death toll of a Tennessee crash has risen to four youths and two adults. First responders found six females who were thrown from the car.

## Nashville school shooter legally purchased weapons, suffered emotional disorder: police
 - [https://www.foxnews.com/us/nashville-school-shooter-legally-purchased-weapons-suffered-emotional-disorder-police](https://www.foxnews.com/us/nashville-school-shooter-legally-purchased-weapons-suffered-emotional-disorder-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:05:05+00:00

Nashville school shooter Audrey Hale bought seven guns from five local stores legally, including three used in Monday&apos;s attack on a Christian elementary.

## Nashville anchors break down in tears during school shooting coverage: ‘My heart is just hurting’
 - [https://www.foxnews.com/media/nashville-anchors-break-down-tears-school-shooting-coverage-my-heart-hurting](https://www.foxnews.com/media/nashville-anchors-break-down-tears-school-shooting-coverage-my-heart-hurting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 15:00:30+00:00

Holly Thompson and Amanda Hara of WSMV broke down on-air while reporting on various aspects of the Nashville, Tennessee Christian grade school shooting.

## Taxpayers fund 'radical gender ideology to create psychopaths,' 2024 candidate says after Nashville shooting
 - [https://www.foxnews.com/politics/taxpayers-fund-radical-gender-ideology-to-create-psychopaths-2024-candidate-says-nashville-shooting](https://www.foxnews.com/politics/taxpayers-fund-radical-gender-ideology-to-create-psychopaths-2024-candidate-says-nashville-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:57:26+00:00

Vivek Ramaswamy, 2024 Republican presidential candidate, questioned the amount of security in schools across the nation after a mass shooter took six lives in Nashville Monday.

## China installs new ambassador in North Korea, one of few in the country
 - [https://www.foxnews.com/world/china-installs-new-ambassador-north-korea-one-few-country](https://www.foxnews.com/world/china-installs-new-ambassador-north-korea-one-few-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:57:12+00:00

The People&apos;s Republic of China has appointed a new ambassador to North Korea, one of the few foreign ministries with the privilege of operating out of Pyongyang.

## Maine's Acadia national park raises entrance fee
 - [https://www.foxnews.com/us/maines-acadia-national-park-raises-entrance-fee](https://www.foxnews.com/us/maines-acadia-national-park-raises-entrance-fee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:56:46+00:00

Acadia National Park, just outside Bar Harbor, Maine, will see its first entry fee increase in five years, officials announced Tuesday.

## Maine student injured when tractor-trailer strikes school bus
 - [https://www.foxnews.com/us/maine-student-injured-when-tractor-trailer-strikes-school-bus](https://www.foxnews.com/us/maine-student-injured-when-tractor-trailer-strikes-school-bus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:50:34+00:00

A student was injured Tuesday when a tractor-trailer struck a school bus from behind. The student had injuries that were not life threatening, and was sent to Maine Medical Center.

## Colorado teenage girl robs mailman at gunpoint, is shot by police
 - [https://www.foxnews.com/us/colorado-teenage-girl-robs-mailman-gunpoint-shot-police](https://www.foxnews.com/us/colorado-teenage-girl-robs-mailman-gunpoint-shot-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:49:21+00:00

Colorado teenage girl robbed a mailman at gunpoint on Monday and was shot dead by police. The girl who died pointed a gun at police, and one officer was injured.

## New Mexico, feds owed $6.2M from oil company in pollution settlement
 - [https://www.foxnews.com/politics/new-mexico-feds-owed-6-2m-oil-company-pollution-settlement](https://www.foxnews.com/politics/new-mexico-feds-owed-6-2m-oil-company-pollution-settlement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:47:51+00:00

Matador Production Co., a Texas-based oil company, has reached a $6.2 million settlement with New Mexico and federal authorities over alleged air pollution violations.

## Pizza receipt leads Milwaukee police to 12-year-old murder suspect
 - [https://www.foxnews.com/us/pizza-receipt-leads-milwaukee-police-12-year-old-murder-suspect](https://www.foxnews.com/us/pizza-receipt-leads-milwaukee-police-12-year-old-murder-suspect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:46:05+00:00

A 12-year-old Milwaukee boy will be charged as an adult in the alleged killing of 34-year-old Brandon Felton after Felton allegedly wouldn&apos;t sell him guns.

## Graham says 'America is under attack' from Mexican drug cartels: 'We need to be at war with them'
 - [https://www.foxnews.com/politics/graham-says-america-under-attack-from-mexican-drug-cartels-need-war-them](https://www.foxnews.com/politics/graham-says-america-under-attack-from-mexican-drug-cartels-need-war-them)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:41:58+00:00

Sen. Lindsey Graham said the U.S. needs to be &quot;at war&quot; with Mexican cartels over the smuggling of fentanyl in the U.S. – urging for officials to &quot;take the gloves off.&quot;

## French protests intensify in test for Macron; police bolster security amid warnings radicals seek 'to destroy'
 - [https://www.foxnews.com/world/french-protests-intensify-test-macron-police-bolster-security-warnings-radicals-seek-destroy](https://www.foxnews.com/world/french-protests-intensify-test-macron-police-bolster-security-warnings-radicals-seek-destroy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:36:56+00:00

More than 13,000 police were deployed across France Tuesday amid warnings radicals among those protesting President Emmanuel Macron&apos;s pension reforms seek &quot;to destroy, injure and kill.&quot;

## Nashville shooter felt 'no other effective way to be seen,' radical trans group says
 - [https://www.foxnews.com/politics/nashville-shooter-felt-no-other-effective-way-seen-radical-trans-group-says](https://www.foxnews.com/politics/nashville-shooter-felt-no-other-effective-way-seen-radical-trans-group-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:36:31+00:00

A radical transgender group said the Nashville shooter felt &quot;no other effective way to be seen&quot; than to shoot up a Presbyterian school and kill six people.

## Water found in moon samples from China mission
 - [https://www.foxnews.com/science/water-found-moon-samples-china-mission](https://www.foxnews.com/science/water-found-moon-samples-china-mission)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:30:45+00:00

Scientists in China discovered a new and renewable source of water on the moon in lunar samples recovered from the Chang&apos;e-5 lunar mission. The samples were returned in 2020.

## Biden admin accused of 'stonewalling' GOP on key Afghanistan withdrawal cable: 'It raises my suspicion'
 - [https://www.foxnews.com/media/biden-admin-accused-stonewalling-gop-key-afghanistan-withdrawal-cable-raises-suspicion](https://www.foxnews.com/media/biden-admin-accused-stonewalling-gop-key-afghanistan-withdrawal-cable-raises-suspicion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:30:04+00:00

Rep. Michael McCaul, R-Texas, issued a subpoena Tuesday targeting Secretary of State Antony Blinken over a &apos;dissent cable&apos; related to the Afghanistan withdrawal.

## GOP states side with parents in lawsuit against school that ‘shut parents out’ of kids’ gender transition
 - [https://www.foxnews.com/politics/gop-states-side-parents-lawsuit-against-school-shut-parents-out-kids-gender-transition](https://www.foxnews.com/politics/gop-states-side-parents-lawsuit-against-school-shut-parents-out-kids-gender-transition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:24:45+00:00

Nineteen GOP AGs filed amicus brief in support of parents fighting a school district they claim deliberately hid information about their kids&apos; gender transition.

## Apple likely updating AirPod Pro charging case port: reports
 - [https://www.foxnews.com/tech/apple-likely-updating-airpod-pro-charging-case-port](https://www.foxnews.com/tech/apple-likely-updating-airpod-pro-charging-case-port)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:21:42+00:00

An analyst said last week that Apple might soon alter the port on its AirPod Pro case, changing from Lightning to USB-C compatibility. Apple switched Apple TV&apos;s Siri Remote to USB-C.

## French prosecutors raid Paris big banks in tax fraud sweep
 - [https://www.foxnews.com/world/france-prosecutors-raid-paris-big-banks-tax-fraud-sweep](https://www.foxnews.com/world/france-prosecutors-raid-paris-big-banks-tax-fraud-sweep)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:18:15+00:00

French authorities searched the headquarters of five banks in Paris Tuesday as part of a sweeping tax fraud probe authorities say spans four continents and could involve 1,500 suspects.

## School shooting in Nashville: 'As a nation, we can do better,' faith leader insists
 - [https://www.foxnews.com/lifestyle/school-shooting-nashville-nation-we-can-do-better-faith-leader](https://www.foxnews.com/lifestyle/school-shooting-nashville-nation-we-can-do-better-faith-leader)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:16:38+00:00

As the nation reels from the school shooting in Nashville, four faith leaders offer spiritual comfort and admonishments about straying away from biblical principles.

## Rev. Al Sharpton to deliver eulogy at funeral of Irvo Otieno
 - [https://www.foxnews.com/us/rev-al-sharpton-deliever-eulogy-funeral-irvo-otieno](https://www.foxnews.com/us/rev-al-sharpton-deliever-eulogy-funeral-irvo-otieno)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:14:45+00:00

The Rev. Al Sharpton will deliver the eulogy at the funeral of Irvo Otieno, a Black man who died after officers pinnned him to the floor while being admitted to a mental hospital.

## Shooting on Interstate 5 shuts down traffic north of Los Angeles, trucker wounded
 - [https://www.foxnews.com/us/shooting-interstate-5-shuts-traffic-north-los-angeles-trucker-wounded](https://www.foxnews.com/us/shooting-interstate-5-shuts-traffic-north-los-angeles-trucker-wounded)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:13:17+00:00

An overnight shooting on Interstate 5 shut down traffic north of Los Angeles until around sunrise on Tuesday. Authorities recieved calls about someone waving a firearm at a trucker.

## Ethiopia’s PM announces outreach to outlawed rebel group in Oromia
 - [https://www.foxnews.com/world/ethiopias-pm-announces-outreach-outlawed-rebel-group-oromia](https://www.foxnews.com/world/ethiopias-pm-announces-outreach-outlawed-rebel-group-oromia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:11:10+00:00

Ethiopia’s Prime Minister announced Tuesday his administration is attempting to talk to an outlawed rebel group in Oromia. The Ethiopian government is seeking to end the conflict.

## Bomb threats close dozens of Bulgaria schools for 2nd consecutive day
 - [https://www.foxnews.com/world/bomb-threats-close-dozens-bulgaria-schools-2nd-consecutive-day](https://www.foxnews.com/world/bomb-threats-close-dozens-bulgaria-schools-2nd-consecutive-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:08:58+00:00

Bomb threats in Bulgaria led to closing dozens of schools for a second consecutive day. The bomb threats are believed to be linked to a hacker group involved in political extremism.

## Sunny Hostin suggests Chinese internment of Muslims not as bad as U.S. mass incarceration
 - [https://www.foxnews.com/media/sunny-hostin-suggests-chinese-internment-muslims-not-bad-us-mass-incarceration](https://www.foxnews.com/media/sunny-hostin-suggests-chinese-internment-muslims-not-bad-us-mass-incarceration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:08:43+00:00

&quot;The View&quot; co-host Sunny Hostin compared the Chinese forced internment of Ugyhur Muslims to the U.S. imprisoning Black Americans, saying the latter was worse.

## Judge orders Phoenix to clean up large homeless encampment
 - [https://www.foxnews.com/us/judge-orders-phoenix-clean-large-homeless-encampment](https://www.foxnews.com/us/judge-orders-phoenix-clean-large-homeless-encampment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:07:05+00:00

A judge has ordered the city of Phoenix to clean up a large homeless encampment in the downtown area. The judge ruled that the city is maintaining a &quot;public nuisance.&quot;

## Graham grills Navy on budget that shrinks the fleet as China grows: ‘Doesn’t make sense’
 - [https://www.foxnews.com/politics/graham-grills-navy-budget-shrinks-fleet-china-grows-doesnt-make-sense](https://www.foxnews.com/politics/graham-grills-navy-budget-shrinks-fleet-china-grows-doesnt-make-sense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:00:38+00:00

Sen. Lindsey Graham, R-S.C., tore into top Navy officials on Tuesday for supporting a budget plan that would shrink the fleet, even as China adds ships.

## Biden Cabinet official forced to admit climate agenda is strengthening China
 - [https://www.foxnews.com/politics/biden-cabinet-official-forced-admit-climate-agenda-strengthening-china](https://www.foxnews.com/politics/biden-cabinet-official-forced-admit-climate-agenda-strengthening-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 14:00:24+00:00

Interior Secretary Deb Haaland, who oversees major federal energy and land management decisions, acknowledged Tuesday that China benefits from the global green energy push.

## Boat capsizes off Caribbean island of St. Kitts kills1, 16 others missing
 - [https://www.foxnews.com/world/boat-capsizes-off-caribbean-island-st-kitts-kills-1-16-others-missing](https://www.foxnews.com/world/boat-capsizes-off-caribbean-island-st-kitts-kills-1-16-others-missing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:59:26+00:00

A boat carrying 32 passengers capsized off the coast of St. Kitts, an island in the Caribbean. The accident lead to one person&apos;s death, and 16 others are still missing.

## Utah 'powercloud' avalanche caught on camera: 'It's gonna pummel us'
 - [https://www.foxnews.com/us/utah-powercloud-avalanche-caught-camera-gonna-pummel-us](https://www.foxnews.com/us/utah-powercloud-avalanche-caught-camera-gonna-pummel-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:54:14+00:00

A natural &quot;powercloud&quot; avalanche was caught on video approaching a group of skiers at Sundance Resort in Utah. The Timpanogos avalanche was one of three reported in the state.

## LGBT group sues Texas university after president cancels 'divisive' drag show he compared to 'blackface'
 - [https://www.foxnews.com/us/lgbt-group-sues-texas-university-president-cancels-divisive-drag-show-he-compared-blackface](https://www.foxnews.com/us/lgbt-group-sues-texas-university-president-cancels-divisive-drag-show-he-compared-blackface)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:54:04+00:00

An LGBTQ student group at West Texas A&amp;M University filed a lawsuit against its president after he canceled an on-campus charity drag show that he claimed was demeaning to women.

## Russian court sentences single father to 2 years in prison for criticizing the war in Ukraine on social media
 - [https://www.foxnews.com/world/russian-court-sentences-single-father-2-years-prison-criticizing-war-ukraine-social-media](https://www.foxnews.com/world/russian-court-sentences-single-father-2-years-prison-criticizing-war-ukraine-social-media)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:46:46+00:00

Alexei Moskalyov was sentenced to two years in prison for social media posts criticizing the war in Ukraine. Moskalyov wasn&apos;t present for the trials outcome after fleeing house arrest.

## Kentucky Gov. Andy Beshear clears way for bill that gives parents ability to challenge school curriculum
 - [https://www.foxnews.com/politics/kentucky-gov-andy-beshear-clears-gives-parents-ability-challenge-school-curriculum](https://www.foxnews.com/politics/kentucky-gov-andy-beshear-clears-gives-parents-ability-challenge-school-curriculum)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:43:18+00:00

A bill to give parents in Kentucky a pathway to challenge school curriculum that they believe is unfit for children was cleared by Gov. Andy Beshear.

## Minnesota nuclear power plant leak repaired, will return to service next week
 - [https://www.foxnews.com/us/minnesota-nuclear-power-plant-leak-repaired-return-service-next-week](https://www.foxnews.com/us/minnesota-nuclear-power-plant-leak-repaired-return-service-next-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:41:49+00:00

A broken pipe that caused a leak at a Minnesota nuclear power plant has been repaired and the plant is set to return to service next week.

## Vermont man dies after falling through ice while riding ATV on Lake Champlain
 - [https://www.foxnews.com/us/vermont-man-dies-after-falling-ice-riding-atv-lake-champlain](https://www.foxnews.com/us/vermont-man-dies-after-falling-ice-riding-atv-lake-champlain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:40:17+00:00

Donald Jones, 82, died after falling through the ice while driving an ATV on Lake Champlain in Vermont. Rescuers brought him to the shore 30 minutes after the accident.

## Doctors warn against 'beezin'' trend as people apply lip balm to eyelids: Why it's dangerous
 - [https://www.foxnews.com/lifestyle/doctors-warn-against-beezin-trend-people-apply-lip-balm-eyelids-why-dangerous](https://www.foxnews.com/lifestyle/doctors-warn-against-beezin-trend-people-apply-lip-balm-eyelids-why-dangerous)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:39:22+00:00

&quot;Beezin&apos;&quot; which has appeared on TikTok, involves users applying lip balm to their eyelids. Experts, however, are warning people to steer clear as it could cause infections.

## Rhode Island Army sergeant's body accounted for, will be buried in Arlington National Cemetery
 - [https://www.foxnews.com/us/rhode-island-army-sergeants-body-accounted-buried-arlington-national-cemetery](https://www.foxnews.com/us/rhode-island-army-sergeants-body-accounted-buried-arlington-national-cemetery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:38:30+00:00

The body of Sgt. Lawrence Robidoux, an Army sergeant form Rhode Island, was identified using DNA analysis. The sergeant died of starvation in a POW camp in 1951.

## Nashville school shooting victim was Presbyterian pastor's daughter
 - [https://www.foxnews.com/us/nashville-school-shooting-victim-was-presbyterian-pastor-daughter](https://www.foxnews.com/us/nashville-school-shooting-victim-was-presbyterian-pastor-daughter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:38:26+00:00

The 9-year-old child of Covenant Presbyterian Church&apos;s pastor, Chad Scruggs, was among the victims of Monday&apos;s heinous mass shooting in Nashville, Tennessee.

## Scientists name rare beetle species after former California Gov. Jerry Brown
 - [https://www.foxnews.com/us/scientists-name-rare-beetle-species-former-california-gov-jerry-brown](https://www.foxnews.com/us/scientists-name-rare-beetle-species-former-california-gov-jerry-brown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:36:19+00:00

Bembidion brownorum, a rare species of beetle, has been named after former California Gov. Jerry Brown. One of the rare beetles was found on Brown&apos;s ranch.

## LSU star Angel Reese's mom has young men messaging her thinking she's her daughter
 - [https://www.foxnews.com/sports/lsu-star-angel-reeses-mom-young-men-messaging-thinking-shes-her-daughter](https://www.foxnews.com/sports/lsu-star-angel-reeses-mom-young-men-messaging-thinking-shes-her-daughter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:32:15+00:00

The mother of LSU Tigers women&apos;s basketball star Angel Reese is making sure young men know who they&apos;re messaging on social media as her daughter takes center stage.

## Here's how that Kia driver survived being flipped into the air
 - [https://www.foxnews.com/auto/heres-how-kia-driver-survived-flipped](https://www.foxnews.com/auto/heres-how-kia-driver-survived-flipped)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:20:44+00:00

The Kia Soul has a stronger than average roof compared to other small vehicles, which allowed one to protect its driver as it was flipped in the air by a runaway tire.

## Shohei Ohtani's estimated 2023 total earnings are an MLB record: report
 - [https://www.foxnews.com/sports/shohei-ohtanis-estimated-2023-total-earnings-mlb-record-report](https://www.foxnews.com/sports/shohei-ohtanis-estimated-2023-total-earnings-mlb-record-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:17:45+00:00

Los Angeles Angels two-way star Shohei Ohtani will make an estimated $65 million in combined earnings for the 2023 Major League Baseball season.

## After Nashville school shooting, Biden says no more unilateral gun control orders available to him
 - [https://www.foxnews.com/politics/after-nashville-school-shooting-biden-says-no-more-unilateral-gun-control-orders-available-him](https://www.foxnews.com/politics/after-nashville-school-shooting-biden-says-no-more-unilateral-gun-control-orders-available-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:16:02+00:00

President Biden said Tuesday that he cannot issue any more executive actions on gun control, after the deadly shooting at a Christian school in Nashville, Tennessee.

## Mom of fentanyl victim outraged by California Democrat's refusal to consider bill cracking down on dealers
 - [https://www.foxnews.com/media/mom-fentanyl-victim-outraged-california-democrats-refusal-consider-bill-cracking-down-dealers](https://www.foxnews.com/media/mom-fentanyl-victim-outraged-california-democrats-refusal-consider-bill-cracking-down-dealers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:12:43+00:00

Pamela Smith, whose son died in 2016, called out the &apos;outrageous&apos; disregard by the California State Assembly committee on combating the opioid epidemic.

## Man jailed for stabbing pregnant girlfriend injures guard in violent escape, remains at large: sheriff
 - [https://www.foxnews.com/us/man-jailed-stabbing-pregnant-girlfriend-injures-guard-violent-escape-remains-at-large-sheriff](https://www.foxnews.com/us/man-jailed-stabbing-pregnant-girlfriend-injures-guard-violent-escape-remains-at-large-sheriff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:07:32+00:00

Justin Robinson and another prisoner stabbed a jailer with a homemade shank and fled, with authorities able to apprehend the other escapee within an hour.

## Stephen Smith probe: Hear the 911 call reporting dead body just miles from Murdaughs' South Carolina estate
 - [https://www.foxnews.com/us/stephen-smith-probe-hear-911-call-reporting-dead-body-miles-murdaughs-south-carolina-hunting-estate](https://www.foxnews.com/us/stephen-smith-probe-hear-911-call-reporting-dead-body-miles-murdaughs-south-carolina-hunting-estate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 13:05:05+00:00

Hear the 911 call made on July 8, 2015, reporting a body found on the side of a rural South Carolina road later identified as Stephen Smith, Buster Murdaugh&apos;s classmate.

## Rand Paul staffer suffered 'deep knife wound' to head, required surgery after DC attack, uncle says
 - [https://www.foxnews.com/politics/rand-paul-staffer-suffered-deep-knife-wound-required-surgery-dc-attack-uncle-says](https://www.foxnews.com/politics/rand-paul-staffer-suffered-deep-knife-wound-required-surgery-dc-attack-uncle-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:57:55+00:00

Phillip Todd, the Rand Paul staff member who was attacked over the weekend in Washington, D.C., had to undergo surgery, his uncle says.

## Matt Damon makes rare appearance with daughters as Ben Affleck, Jennifer Lopez heat up 'Air' premiere
 - [https://www.foxnews.com/entertainment/matt-damon-rare-appearance-daughters-ben-affleck-jennifer-lopez-heat-up-air-premiere](https://www.foxnews.com/entertainment/matt-damon-rare-appearance-daughters-ben-affleck-jennifer-lopez-heat-up-air-premiere)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:51:42+00:00

Matt Damon posed with three of his four daughters at the premiere of his movie &quot;Air&quot; with Ben Affleck, who brought wife Jennifer Lopez to the event.

## Family of Americans kidnapped by gang in Haiti urged them not to make the trip amid spike in violence
 - [https://www.foxnews.com/world/family-of-americans-kidnapped-by-gang-haiti-urged-them-not-make-the-trip-amid-spike-violence](https://www.foxnews.com/world/family-of-americans-kidnapped-by-gang-haiti-urged-them-not-make-the-trip-amid-spike-violence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:47:12+00:00

The family of an American couple kidnapped by a gang in Haiti earlier this month says they warned the couple not to travel to the country before they were kidnapped by a gang.

## 'Jeopardy!' host Ken Jennings slammed for questionable ruling against contestant: 'Robbed of his points'
 - [https://www.foxnews.com/entertainment/jeopardy-host-ken-jennings-slammed-questionable-ruling-against-contestant](https://www.foxnews.com/entertainment/jeopardy-host-ken-jennings-slammed-questionable-ruling-against-contestant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:43:06+00:00

Ken Jennings is facing backlash for ruling against a &quot;Jeopardy!&quot; contestant for mispronouncing a correct answer. He then ruled in favor of another contestant who also mispronounced the answer.

## Yemen billionaire's son reportedly admits involvement in London rape, murder of Norwegian student 15 years ago
 - [https://www.foxnews.com/world/yemen-billionaires-son-reportedly-admits-involvement-london-rape-murder-norwegian-student-15-years-ago](https://www.foxnews.com/world/yemen-billionaires-son-reportedly-admits-involvement-london-rape-murder-norwegian-student-15-years-ago)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:41:03+00:00

Farouk Abdulhak, the son of a Yemeni billionaire, reportedly admitted to being involved in the 2008 rape and murder of 23-year-old Martine Vik Magnussen in London 15 years ago.

## Russian forces stalled in eastern and southern Ukraine as Kyiv claims to be ‘stabilizing’ Bakhmut sector
 - [https://www.foxnews.com/world/russian-forces-stalled-in-eastern-and-southern-ukraine-as-kyiv-claims-to-be-stabilizing-bakhmut-sector](https://www.foxnews.com/world/russian-forces-stalled-in-eastern-and-southern-ukraine-as-kyiv-claims-to-be-stabilizing-bakhmut-sector)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:33:25+00:00

Russian progression in eastern and southern Ukraine have again stalled as it continues to grapple with high casualty rates, under-trained men and low morale.

## Sen. Cotton blasts Sec. Lloyd Austin over Iran proxy attack: ‘I don’t believe you’
 - [https://www.foxnews.com/politics/sen-cotton-blasts-sec-lloyd-austin-iran-proxy-attack-dont-believe-you](https://www.foxnews.com/politics/sen-cotton-blasts-sec-lloyd-austin-iran-proxy-attack-dont-believe-you)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:33:00+00:00

Sen. Tom Cotton blasted Sec. Lloyd Austin for not immediately notifying senators of an Iranian proxy attack in Syria. Cotton argued Austin &quot;consciously&quot; delayed the message.

## Family finds 'closure' 80 years after remains are discovered
 - [https://www.foxnews.com/lifestyle/family-finds-closure-80-years-remains-discovered](https://www.foxnews.com/lifestyle/family-finds-closure-80-years-remains-discovered)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:31:57+00:00

The Fox News Lifestyle Newsletter brings you trending stories on family, travel, food, neighbors helping neighbors, pets, autos, military veterans, heroes, faith and American values.

## Reparations advocate has no idea how San Francisco can give Black residents $5 million each
 - [https://www.foxnews.com/media/reparations-advocate-has-no-idea-how-san-francisco-can-give-black-residents-5-million-each](https://www.foxnews.com/media/reparations-advocate-has-no-idea-how-san-francisco-can-give-black-residents-5-million-each)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:30:36+00:00

A reparations advocate from Evanston, Illinois, told CNN on Tuesday that she doesn&apos;t know how San Francisco will award their Black residents $5 million each.

## DeSantis is ‘living rent-free in Trump’s head’ according to Florida governor's allies
 - [https://www.foxnews.com/politics/desantis-living-rent-free-in-trumps-head-according-florida-governors-allies](https://www.foxnews.com/politics/desantis-living-rent-free-in-trumps-head-according-florida-governors-allies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:27:46+00:00

As former President Trump&apos;s attacks on Ron DeSantis increase in frequency as the 2024 GOP presidential nomination race heats up, there&apos;s concern and confidence from the Florida governor&apos;s camp

## Cotton slams Jean-Pierre's 'shameful' comment 'blaming Republicans' for Nashville Christian school shooting
 - [https://www.foxnews.com/politics/cotton-slams-jean-pierres-shameful-comment-blaming-republicans-nashville-christian-school-shooting](https://www.foxnews.com/politics/cotton-slams-jean-pierres-shameful-comment-blaming-republicans-nashville-christian-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:23:36+00:00

Sen. Tom Cotton slammed White House press secretary Karine Jean-Pierre for blaming Republican in Congress for the Covenant School shooting in Nashville Monday.

## Louisville star Hailey Van Lith gets candid about motivation: 'God doesn't think I'm an honorable mention'
 - [https://www.foxnews.com/sports/louisville-star-hailey-van-lith-gets-candid-motivation-god-doesnt-think-honorable-mention](https://www.foxnews.com/sports/louisville-star-hailey-van-lith-gets-candid-motivation-god-doesnt-think-honorable-mention)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:20:57+00:00

Louisville star Hailey Van Lith gave a blunt response about motivation after the Cardinals lost a close Elite Eight game to Iowa and Caitlin Clark.

## McCarthy says Biden 'completely missing in action' on debt limit negotiations
 - [https://www.foxnews.com/politics/mccarthy-biden-completely-missing-action-debt-limit-negotiations](https://www.foxnews.com/politics/mccarthy-biden-completely-missing-action-debt-limit-negotiations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:18:01+00:00

House Speaker Kevin McCarthy accused President Biden of being “completely missing in action&quot; on the debt limit negotiations and urged him to work with Republicans on an answer.

## Josh Allen’s style not a ‘healthy way to play quarterback,' Bills coach says
 - [https://www.foxnews.com/sports/josh-allens-play-style-not-healthy-way-play-quarterback-bills-coach-says](https://www.foxnews.com/sports/josh-allens-play-style-not-healthy-way-play-quarterback-bills-coach-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:14:36+00:00

Josh Allen is dual threat QB, but Bills head coach Sean McDermott is looking for the veteran signal caller to adjust his style of play to protect him from unnecessary hits next season.

## 'Even Democrats are voting for Trump' if THIS happens: Trump voters weigh in on ex-president's legal fight
 - [https://www.foxnews.com/politics/even-democrats-voting-trump-happens-trump-voters-weigh-ex-presidents-legal-fight](https://www.foxnews.com/politics/even-democrats-voting-trump-happens-trump-voters-weigh-ex-presidents-legal-fight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:12:13+00:00

Attendees of Donald Trump&apos;s first 2024 campaign rally predicted how a potential criminal indictment would affect the former president&apos;s reelection bid.

## Revolutionizing breast cancer detection: The power of AI
 - [https://www.foxnews.com/tech/revolutionizing-breast-cancer-detection-power-ai](https://www.foxnews.com/tech/revolutionizing-breast-cancer-detection-power-ai)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:11:13+00:00

Doctors are using AI technology to detect signs of breast cancer, which could help lessen radiologists&apos; workloads. Here&apos;s the artificial intelligence breakthrough.

## North Korea reveals new nuclear warheads as US carrier strike group docks in South Korea
 - [https://www.foxnews.com/world/north-korea-new-nuclear-warheads-us-carrier-strike-group-docks-south-korea](https://www.foxnews.com/world/north-korea-new-nuclear-warheads-us-carrier-strike-group-docks-south-korea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:06:56+00:00

North Korean leader Kim Jong Un has been photographed observing new, smaller nuclear warheads as the USS Nimitz carrier strike group docked in South Korea.

## Most Americans don't believe the US is the greatest country in the world, poll finds
 - [https://www.foxnews.com/us/most-americans-dont-believe-us-greatest-country-world-poll-finds](https://www.foxnews.com/us/most-americans-dont-believe-us-greatest-country-world-poll-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:06:51+00:00

Most Americans do not believe the U.S. is the greatest country in the world, with only 21% of respondents in a recent WSJ/NORC poll saying America was the best.

## Nashville school shooting: Journalists mock prayer, drag show ban after Christian school massacre
 - [https://www.foxnews.com/media/nashville-school-shooting-journalists-mock-prayer-drag-show-ban-christian-school-massacre](https://www.foxnews.com/media/nashville-school-shooting-journalists-mock-prayer-drag-show-ban-christian-school-massacre)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 12:00:02+00:00

Journalists blamed Christians and conservatives for focusing on banning drag shows in Tennessee after a Christian school was attacked by a transgender shooter.

## Nashville Christian school shooting: Leftists mock prayer as community reels from tragedy
 - [https://www.foxnews.com/politics/nashville-christian-school-shooting-leftists-mock-prayer-community-reels-tragedy](https://www.foxnews.com/politics/nashville-christian-school-shooting-leftists-mock-prayer-community-reels-tragedy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:57:24+00:00

Following the horrific mass shooting at a Nashville Christian school, progressives blasted those who encouraged people to pray for the community and families of the victims.

## Gwyneth Paltrow's ski accident trial drops bombshells and 'blood-curdling' testimony
 - [https://www.foxnews.com/entertainment/gwyneth-paltrows-ski-accident-trial-drops-bombshells-blood-curdling-testimony](https://www.foxnews.com/entertainment/gwyneth-paltrows-ski-accident-trial-drops-bombshells-blood-curdling-testimony)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:56:49+00:00

The Fox News Entertainment newsletter brings you the latest Hollywood headlines, celebrity interviews and stories from Los Angeles and beyond.

## Tap water deemed 'safe' to drink in Philadelphia at least through Wednesday night, officials say
 - [https://www.foxnews.com/us/tap-water-deemed-safe-drink-philadelphia-least-wednesday-night-officials-say](https://www.foxnews.com/us/tap-water-deemed-safe-drink-philadelphia-least-wednesday-night-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:55:55+00:00

Philadelphia water officials updated residents Tuesday, saying tap water was deemed &quot;safe to drink&quot; through Wednesday following a chemical spill last week.

## DCCC went back on hacked materials pledge with military record leaks: 'Peak self-righteous indignation'
 - [https://www.foxnews.com/politics/dccc-hacked-materials-pledge-medical-record-leaks](https://www.foxnews.com/politics/dccc-hacked-materials-pledge-medical-record-leaks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:52:37+00:00

The DCCC appeared to go back on its hacked materials policy by paying Due Diligence, the firm behind the leaks of several GOP candidates’ military records during the 2022 midterms.

## George Soros pushes $1 million to Wisconsin Democrats ahead of pivotal state Supreme Court election
 - [https://www.foxnews.com/politics/george-soros-pushes-1m-wisconsin-democrats-ahead-pivotal-state-supreme-court-election](https://www.foxnews.com/politics/george-soros-pushes-1m-wisconsin-democrats-ahead-pivotal-state-supreme-court-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:51:43+00:00

Liberal billionaire George Soros provided the Wisconsin Democratic Party with one of its biggest contributions in recent months ahead of a pivotal election.

## Bill Belichick won’t name Mac Jones starting Patriots quarterback: ‘We’ll play the best player’
 - [https://www.foxnews.com/sports/bill-belichick-wont-name-mac-jones-starting-patriots-quarterback-well-play-best-player](https://www.foxnews.com/sports/bill-belichick-wont-name-mac-jones-starting-patriots-quarterback-well-play-best-player)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:49:03+00:00

New England Patriots head coach Bill Belichick refused to name Mac Jones as the starter heading into the 2023 season, saying New England will &quot;play the best player.&quot;

## Cotton accuses Pentagon of ‘conscious decision’ to withhold info from Congress to influence vote
 - [https://www.foxnews.com/politics/cotton-accuses-pentagon-conscious-decision-withhold-info-congress-influence-vote](https://www.foxnews.com/politics/cotton-accuses-pentagon-conscious-decision-withhold-info-congress-influence-vote)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:46:26+00:00

Sen. Tom Cotton accused Defense Secretary Lloyd Austin of withholding information from Congress about a military incident in Syria in order to avoid influencing a vote.

## Anti-CRT curriculum: California school board pushes to get 'divisive ideology' out of K-12 education
 - [https://www.foxnews.com/media/anti-crt-curriculum-california-school-board-pushes-divisive-ideology-out-k-12-education](https://www.foxnews.com/media/anti-crt-curriculum-california-school-board-pushes-divisive-ideology-out-k-12-education)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:42:26+00:00

A California city garnered national attention after protesters took over a school board meeting detailing the dangers and history of critical race theory.

## Arkansas sues social media giants for 'addictive' effect on kids: 'Rewiring how our children think'
 - [https://www.foxnews.com/politics/arkansas-sues-social-media-giants-addictive-effect-kids-rewiring-how-our-children-think](https://www.foxnews.com/politics/arkansas-sues-social-media-giants-addictive-effect-kids-rewiring-how-our-children-think)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:40:55+00:00

Arkansas will file three lawsuits against TikTok and Meta in an effort to protect residents in the state, specifically children, from what Gov. Sarah Sanders calls &apos;addictive&apos; effects

## Tom Brady posts snaps of his beach day, Rob Gronkowski gets a little cheeky
 - [https://www.foxnews.com/sports/tom-brady-posts-snaps-beach-day-rob-gronkowski-gets-little-cheeky](https://www.foxnews.com/sports/tom-brady-posts-snaps-beach-day-rob-gronkowski-gets-little-cheeky)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:39:33+00:00

Tom Brady posted a few photos of his beach trip over the weekend onto his social media accounts, showing pics of his children and former NFL teammates.

## Video of fighter jets shooting down UFOs over Alaska is classified, won't be released: Pentagon
 - [https://www.foxnews.com/us/video-fighter-jets-shooting-down-ufos-alaska-is-classified-wont-be-released-pentagon](https://www.foxnews.com/us/video-fighter-jets-shooting-down-ufos-alaska-is-classified-wont-be-released-pentagon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:35:11+00:00

The Pentagon currently has no plans to release footage of UFOs that were shot down over Alaska last month, though as spokesperson acknowledged such footage exists.

## Wizards star Bradley Beal faces probe over incident after game vs Magic: reports
 - [https://www.foxnews.com/sports/wizards-star-bradley-beal-faces-probe-incident-game-vs-magic-reports](https://www.foxnews.com/sports/wizards-star-bradley-beal-faces-probe-incident-game-vs-magic-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:33:38+00:00

Washington Wizards star Bradley Beal is facing accusations stemming from an alleged incident with a fan at the Amway Center last week.

## Buster Murdaugh, Stephen Smith homicide investigation, secret to a happy marriage and more Fox News Opinion
 - [https://www.foxnews.com/opinion/buster-murdaugh-stephen-smith-homicide-investigation-secret-happy-marriage](https://www.foxnews.com/opinion/buster-murdaugh-stephen-smith-homicide-investigation-secret-happy-marriage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:33:13+00:00

Read the latest Fox News Opinion columns and watch videos from Tucker Carlson, Sean Hannity, Laura Ingraham and more.

## Newborn tragically dies from amateur medical procedure popular among some migrants
 - [https://www.foxnews.com/world/newborn-tragically-dies-amateur-medical-procedure-popular-among-some-migrants](https://www.foxnews.com/world/newborn-tragically-dies-amateur-medical-procedure-popular-among-some-migrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:31:38+00:00

The procedure is said to be common among some of the Muslim immigrant population of Italy, where doctors refuse to administer it to children under the age of 4 and the cost proves prohibitive.

## 18-year-old New Hampshire man pointed what appeared to be gun at officer who shot him
 - [https://www.foxnews.com/us/18-year-old-new-hampshire-man-pointed-appeared-gun-officer-shot-him](https://www.foxnews.com/us/18-year-old-new-hampshire-man-pointed-appeared-gun-officer-shot-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:25:58+00:00

A New Hampshire teen reportedly pointed what appeared to be a gun at a police officer prior to being shot. The teen was allegedly doing donuts in the middle of the road.

## Gwyneth Paltrow ski collision recreated in new video intended to prove fault in Utah crash
 - [https://www.foxnews.com/entertainment/gwyneth-paltrow-ski-collision-recreated-new-video-intended-prove-fault-utah-crash](https://www.foxnews.com/entertainment/gwyneth-paltrow-ski-collision-recreated-new-video-intended-prove-fault-utah-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:25:39+00:00

Gwyneth Paltrow&apos;s lawyer used animated video footage to illustrate ski instructor Eric Christiansen&apos;s account of what happened the day Paltrow and plaintiff Terry Sanderson collided.

## Texas carbon monoxide leak hospitalizes 6, including 5 children
 - [https://www.foxnews.com/us/texas-carbon-monoxide-leak-hospitalizes-6-including-5-children](https://www.foxnews.com/us/texas-carbon-monoxide-leak-hospitalizes-6-including-5-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:24:12+00:00

A carbon monoxide leak in Fort Worth, Texas, caused by a vehicle that was running hospitalized six people. The victims included five children.

## Minnesota murder suspect allegedly dismembered man, told girlfriend they had to leave ‘due to their mistake’
 - [https://www.foxnews.com/us/minnesota-murder-suspect-allegedly-dismembered-man-told-girlfriend-they-had-leave-due-their-mistake](https://www.foxnews.com/us/minnesota-murder-suspect-allegedly-dismembered-man-told-girlfriend-they-had-leave-due-their-mistake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:23:13+00:00

A Minnesota resident was charged with killing a man, severing his foot and dumping his body in a tote, and the suspect&apos;s girlfriend allegedly helped him cover up the crime.

## 'We make the laws': Tuberville holds the line against DOD's abortion policies despite pushback from Dems, GOP
 - [https://www.foxnews.com/politics/make-laws-tuberville-holds-line-against-dods-abortion-policies-despite-pushback-dems-gop](https://www.foxnews.com/politics/make-laws-tuberville-holds-line-against-dods-abortion-policies-despite-pushback-dems-gop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:10:00+00:00

Sen. Tommy Tuberville, R-Ala., is refusing to give up his hold on President Biden&apos;s DOD nominees over the Pentagon&apos;s &quot;illegal&quot; policy of providing reimbursements for service members receiving abortions.

## Wind gusts pick up NC inflatable rides, injuring at least 7 children during little league opening day
 - [https://www.foxnews.com/us/wind-gusts-pick-up-nc-inflatable-rides-injuring-least-7-children-little-league-opening-day](https://www.foxnews.com/us/wind-gusts-pick-up-nc-inflatable-rides-injuring-least-7-children-little-league-opening-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:08:20+00:00

During the opening day for the Transylvania Little League wind gusts caused two inflatable rides to fly across the sports complex. At least seven children where injured in the incident.

## IRS silent on timing of visit to journalist Matt Taibbi’s home, how often it makes house calls
 - [https://www.foxnews.com/media/irs-silent-timing-visit-journalist-matt-taibbis-home-often-makes-house-calls](https://www.foxnews.com/media/irs-silent-timing-visit-journalist-matt-taibbis-home-often-makes-house-calls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:07:30+00:00

The IRS was silent Tuesday about how often it sends agents to people’s homes on the heels of journalist Matt Taibbi saying he received an unannounced visit.

## Former deputy U.S. marshal convicted in fake 'rape fantasy' plot to frame ex
 - [https://www.foxnews.com/us/former-deputy-us-marshal-convicted-fake-rape-fantasy-plot-frame-ex](https://www.foxnews.com/us/former-deputy-us-marshal-convicted-fake-rape-fantasy-plot-frame-ex)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:07:26+00:00

A former California law enforcement officer was convicted Thursday of a sick &quot;rape fantasy&quot; plot to frame his ex-girlfriend for trying to have his then-wife sexually assaulted.

## Millions of daffodils bloom suddenly in NYC: Tribute to 9/11 victims is world's 'largest living memorial'
 - [https://www.foxnews.com/lifestyle/millions-daffodils-bloom-suddenly-nyc-tribute-9/11-victims-worlds-largest-living-memorial](https://www.foxnews.com/lifestyle/millions-daffodils-bloom-suddenly-nyc-tribute-9/11-victims-worlds-largest-living-memorial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 11:00:00+00:00

The Daffodil Project in New York City, which began in the weeks after the Sept. 11, 2001, terror attacks, has grown into &quot;the world&apos;s largest living memorial.&quot;

## Texas study finds thousands of pounds of 'forever chemicals' have been injected into oil and gas wells
 - [https://www.foxnews.com/us/texas-study-finds-thousands-pounds-forever-chemicals-injected-oil-gas-wells](https://www.foxnews.com/us/texas-study-finds-thousands-pounds-forever-chemicals-injected-oil-gas-wells)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:58:18+00:00

A study by Physicians for Social Responsibility found that 43,000 pounds of PFAS &quot;forever chemicals&quot; have been used in the hydraulic fracturing of oil and gas wells in Texas since 2013.

## Family game changer? Why moms and dads are turning to a viral '5-second' parenting tip
 - [https://www.foxnews.com/lifestyle/family-game-changer-moms-dads-turning-viral-5-second-parenting](https://www.foxnews.com/lifestyle/family-game-changer-moms-dads-turning-viral-5-second-parenting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:57:13+00:00

A 5-second parenting tip has gone viral on social media and it&apos;s receiving responses — some saying a &apos;one-size-fits-all&apos; concept isn&apos;t necessarily the answer.

## North Carolina Gov. Roy Cooper signs Medicaid expansion law giving Democrats legacy-setting victory
 - [https://www.foxnews.com/politics/north-carolina-gov-roy-cooper-signs-medicaid-expansion-law-giving-democrats-legacy-setting-victory](https://www.foxnews.com/politics/north-carolina-gov-roy-cooper-signs-medicaid-expansion-law-giving-democrats-legacy-setting-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:56:16+00:00

A Medicaid expansion law was signed by North Carolina&apos;s governor on Monday. The law is a legacy-victory for Democrats but one significant hurdle remains thanks to a GOP-back provision.

## Who are the Nashville school shooting victims?
 - [https://www.foxnews.com/us/who-are-nashville-school-shooting-victims](https://www.foxnews.com/us/who-are-nashville-school-shooting-victims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:53:05+00:00

Metropolitan Nashville Police identified six victims of Monday&apos;s school shooting: Evelyn Dieckhaus, William Kinney, Hallie Scruggs, Mike Hill, Cynthia Peak and Katherine Koonce.

## Man hit, killed by coach bus at Boston Logan International Airport identified
 - [https://www.foxnews.com/us/man-hit-killed-coach-bus-boston-logan-international-airport-identified](https://www.foxnews.com/us/man-hit-killed-coach-bus-boston-logan-international-airport-identified)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:51:09+00:00

Massachusetts State Police have identified the man struck, killed by a coach bus at Boston Logan International Airport Monday evening as 47-year-old Vishwachand Kolla.

## Nashville transgender school shooter's messages to friend show 'much deeper issues,' says ex-FBI special agent
 - [https://www.foxnews.com/media/nashville-transgender-school-shooter-messages-friend-show-deeper-issues-fbi-special-agent](https://www.foxnews.com/media/nashville-transgender-school-shooter-messages-friend-show-deeper-issues-fbi-special-agent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:35:30+00:00

A former FBI special agent said on Tuesday that the Covenant shooting in Nashville is part of a pattern of mass shooters having &quot;sexual identity dysfunctions.&quot;

## Dems push transgender rights in the military so people can serve ‘authentically’
 - [https://www.foxnews.com/politics/dems-push-transgender-rights-military-people-serve-authentically](https://www.foxnews.com/politics/dems-push-transgender-rights-military-people-serve-authentically)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:31:03+00:00

More than 20 House Democrats proposed legislation to prevent the DOD from imposing a ban on transgender service and say everyone should be allowed to serve &quot;authentically.&quot;

## Prosecutors quit over Soros-funded DA's radical agenda as families vow to fight back
 - [https://www.foxnews.com/media/prosecutors-quit-over-soros-funded-das-radical-agenda-families-vow-fight-back](https://www.foxnews.com/media/prosecutors-quit-over-soros-funded-das-radical-agenda-families-vow-fight-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:30:43+00:00

Alameda County District Attorney Pamela Price is facing fierce scrutiny after she proposed a plea deal to slash the sentence in a triple murder case.

## Nashville school shooting: Audrey Hale police bodycams released
 - [https://www.foxnews.com/us/nashville-school-shooting-audrey-hale-police-bodycams-released](https://www.foxnews.com/us/nashville-school-shooting-audrey-hale-police-bodycams-released)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:26:12+00:00

Nashville police have released bodycam video of the Covenant School shooting response Monday morning, as they took down an active shooter in a Christian school.

## FBI releases 190 pages on ‘secret’ investigation into Ivana Trump
 - [https://www.foxnews.com/us/fbi-releases-190-pages-secret-investigation-ivana-trump](https://www.foxnews.com/us/fbi-releases-190-pages-secret-investigation-ivana-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:25:56+00:00

The FBI released 190 pages of documents relating to a &quot;secret&quot; inquiry into Ivana Trump, the now-deceased ex-wife of former President Donald Trump, according to reports.

## Gary Player ranks the Masters last among golf's four major tournaments
 - [https://www.foxnews.com/sports/gary-player-ranks-masters-last-golfs-four-major-tournaments](https://www.foxnews.com/sports/gary-player-ranks-masters-last-golfs-four-major-tournaments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:11:24+00:00

Nine-time major winner Gary Player said he ranks the Masters last of the four golf major tournaments. Player won the Masters three times in his career.

## This is how we win a new Cold War with China
 - [https://www.foxnews.com/opinion/how-we-win-new-cold-war-china](https://www.foxnews.com/opinion/how-we-win-new-cold-war-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 10:00:48+00:00

The U.S. is locked in a new Cold War with China, an adversary even more capable and dangerous than the Soviet Union was at the height of its power.

## Vail Ski Resort settles lawsuit after New Jersey father suffocated to death in chairlift accident
 - [https://www.foxnews.com/us/vail-ski-resort-settles-lawsuit-jason-varnish-new-jersey-father-suffocated-death-chairlift-accident](https://www.foxnews.com/us/vail-ski-resort-settles-lawsuit-jason-varnish-new-jersey-father-suffocated-death-chairlift-accident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 09:52:12+00:00

The children of New Jersey father Jason Varnish, who an attorney says died in an “unnecessary and preventable tragedy&quot; in Colorado three years ago, have settled with Vail Ski Resort.

## Nashville school shooting should be investigated as hate crime, Hawley says
 - [https://www.foxnews.com/politics/nashville-school-shooting-should-investigated-hate-crime-hawley-says](https://www.foxnews.com/politics/nashville-school-shooting-should-investigated-hate-crime-hawley-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 09:43:28+00:00

Sen. Josh Hawley, a Republican from Missouri, said the Nashville school shooting that claimed the lives of three children and three adults should be categorized as a hate crime.

## CNN analyst calls shooter's identity a 'distraction': 'Pronouns do not kill children, people with guns kill’
 - [https://www.foxnews.com/media/cnn-analyst-calls-shooters-identity-distraction-pronouns-do-not-kill-children-people-guns-kill](https://www.foxnews.com/media/cnn-analyst-calls-shooters-identity-distraction-pronouns-do-not-kill-children-people-guns-kill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 09:41:30+00:00

CNN National Security Analyst Juliette Kayyem claimed discussion over the Nashville school shooter&apos;s transgender identity is a &quot;distraction&quot; from the guns used in the killings.

## Prince Harry arrives in London court for day two of privacy invasion hearing
 - [https://www.foxnews.com/entertainment/prince-harry-arrives-court-day-two-privacy-invasion-hearing](https://www.foxnews.com/entertainment/prince-harry-arrives-court-day-two-privacy-invasion-hearing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 09:41:21+00:00

Prince Harry arrived at court on Tuesday for his second appearance in his case against Associated Newspapers for phone hacking charges.

## Hunter's business partner who paid Biden family $1M was frequent WH visitor during Biden vice presidency
 - [https://www.foxnews.com/politics/hunters-business-partner-who-paid-biden-family-1m-was-frequent-wh-visitor-bid-vice-presidency](https://www.foxnews.com/politics/hunters-business-partner-who-paid-biden-family-1m-was-frequent-wh-visitor-bid-vice-presidency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 09:33:53+00:00

Hunter Biden’s former business partner recently named in an investigation by House Oversight Committee Republicans visited the White House 16 times during Joe Biden&apos;s vice presidency.

## Seminaries, denomination associated with The Covenant School release statements, prayers: 'Deeply grieved'
 - [https://www.foxnews.com/us/seminaries-denomination-associated-covenant-school-release-statements-prayers-deeply-grieved](https://www.foxnews.com/us/seminaries-denomination-associated-covenant-school-release-statements-prayers-deeply-grieved)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 09:30:25+00:00

The denomination and seminaries associated with The Covenant School in Nashville, Tennessee, released statements and prayers in the wake of a mass shooting that left six dead.

## Fishermen plead guilty to charges in tournament cheating scandal
 - [https://www.foxnews.com/sports/fishermen-plead-guilty-charges-tournament-cheating-scandal](https://www.foxnews.com/sports/fishermen-plead-guilty-charges-tournament-cheating-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 09:22:56+00:00

Jacob Runyan and Chase Cominsky pleaded guilty to cheating and unlawful ownership of wild animals as part of a plea deal over a scandal at a walleye tournament.

## Trump insists he was transparent with FBI about classified docs, says Biden has 'boxes stored in Chinatown'
 - [https://www.foxnews.com/politics/trump-insists-transparent-fbi-classified-docs-says-biden-boxes-stored-chinatown](https://www.foxnews.com/politics/trump-insists-transparent-fbi-classified-docs-says-biden-boxes-stored-chinatown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 09:20:22+00:00

Former President Donald Trump says he was transparent with the FBI about his handling of classified documents and accused President Biden of having boxes &quot;stored in Chinatown.&quot;

## Heritage Foundation declares new Cold War with China: ‘More capable and dangerous’ than Soviet Union
 - [https://www.foxnews.com/politics/heritage-foundation-declares-new-cold-war-with-china-more-capable-and-dangerous-than-soviet-union](https://www.foxnews.com/politics/heritage-foundation-declares-new-cold-war-with-china-more-capable-and-dangerous-than-soviet-union)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 09:00:01+00:00

The Heritage Foundation said in a new report the U.S. is in a Cold War with China and outlined several steps to compete with China on military and economic matters.

## Matt Taibbi's visit by IRS after testimony about 'Twitter Files' raises eyebrows: 'Stinks to high heaven'
 - [https://www.foxnews.com/media/matt-taibbis-visit-irs-after-testimony-about-twitter-files-raises-eyebrows-stinks-high-heaven](https://www.foxnews.com/media/matt-taibbis-visit-irs-after-testimony-about-twitter-files-raises-eyebrows-stinks-high-heaven)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:55:58+00:00

News that an IRS agent visited journalist Matt Taibbi&apos;s home the same day he testified about the &quot;Twitter Files&quot; raised accusations of government intimidation.

## Georgia lawmakers tell counties they must enforce bans on homeless camp
 - [https://www.foxnews.com/politics/georgia-lawmakers-tell-counties-must-enforce-bans-homeless-camp](https://www.foxnews.com/politics/georgia-lawmakers-tell-counties-must-enforce-bans-homeless-camp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:55:27+00:00

Georgia counties must enforce homeless camp bans and can&apos;t dump homeless people in other counties, according to lawmakers. The bill is being sent to Gov. Kemp for his signature or veto.

## XFL officials penalize player for squirting water at down judge
 - [https://www.foxnews.com/sports/xfl-officials-penalize-player-squirting-water-down-judge](https://www.foxnews.com/sports/xfl-officials-penalize-player-squirting-water-down-judge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:52:31+00:00

XFL officials had to throw a penalty flag for a strange reason on Monday night during the third quarter of a game between the DC Defenders and Houston Roughnecks.

## US states looking to boost minimum wage to $20 as inflation issue continues
 - [https://www.foxnews.com/politics/us-states-looking-boost-minimum-wage-20-inflation-issue-continues](https://www.foxnews.com/politics/us-states-looking-boost-minimum-wage-20-inflation-issue-continues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:52:24+00:00

U.S. states are considering raising the minimum wage to $20. A handful of states considered raising their minimum wage to $15 per hour but the gains were nearly erased due to inflation.

## Vermont community welcomes refugees to the US with handmade blankets
 - [https://www.foxnews.com/us/vermont-community-welcomes-refugees-us-handmade-blankets](https://www.foxnews.com/us/vermont-community-welcomes-refugees-us-handmade-blankets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:48:00+00:00

A group of refugees were welcomed to Vermont with homemade blankets. At least 86 blankets were made for the refugees and immigrants arriving in Vermont.

## Pregnant women in New Jersey ate poppy seeds, then tested positive for opioid drug use: 'Extremely stressful'
 - [https://www.foxnews.com/health/pregnant-women-new-jersey-ate-poppy-seeds-tested-positive-opioid-drug-use](https://www.foxnews.com/health/pregnant-women-new-jersey-ate-poppy-seeds-tested-positive-opioid-drug-use)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:45:47+00:00

After two pregnant women in New Jersey ate bagels with poppy seeds, their hospitals administered drug tests that found them to be positive for opioids — leading to investigations.

## New Mexico's governor signs legislation to provide free school meals to all students regardless of income
 - [https://www.foxnews.com/politics/new-mexicos-governor-signs-legislation-provide-free-school-meals-students-regardless-income](https://www.foxnews.com/politics/new-mexicos-governor-signs-legislation-provide-free-school-meals-students-regardless-income)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:45:33+00:00

Legislation to provide students in New Mexico with free school lunches regardless of income was signed by Gov. Michelle Grisham. Lawmakers set aside $22 million to pay for the program.

## Renewable electricity surpasses coal in the United States for first time in 2022
 - [https://www.foxnews.com/us/renewable-electricity-surpasses-coal-united-states-first-time-2022](https://www.foxnews.com/us/renewable-electricity-surpasses-coal-united-states-first-time-2022)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:42:47+00:00

The U.S. Energy Information Administration announced that renewable electricity surpassed coal in the United States for the first time in 2022.

## Prominent civil rights attorney Lee Merritt among group arrested in Texas during protest
 - [https://www.foxnews.com/us/prominent-civil-rights-attorney-lee-merritt-among-group-arrested-texas-during-protest](https://www.foxnews.com/us/prominent-civil-rights-attorney-lee-merritt-among-group-arrested-texas-during-protest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:41:17+00:00

Lee Merritt, a prominent attorney, was arrested in Texas during a demonstration. The demonstration was in memory of a Black man who died during a struggle with jail guards.

## Wet weather to soak California again as Northeast, Great Lakes see cold temperatures
 - [https://www.foxnews.com/us/wet-weather-soak-california-northeast-great-lakes-cold-temperatures](https://www.foxnews.com/us/wet-weather-soak-california-northeast-great-lakes-cold-temperatures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:40:29+00:00

Heavy rain and flooding risks continue for the Gulf Coast and Southeast as wintry weather is forecast to spread over parts of the interior Northeast and Great Lakes regions.

## JD Vance says 'extreme left' needs to do some 'soul-searching' after Nashville school shooting
 - [https://www.foxnews.com/politics/jd-vance-says-extreme-left-needs-soul-searching-nashville-school-shooting](https://www.foxnews.com/politics/jd-vance-says-extreme-left-needs-soul-searching-nashville-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:39:42+00:00

Sen. JD Vanc, R-Ohio, slammed the “extreme left&quot; Monday evening, saying the group needs to do “a lot of soul searching&quot; after the school shooting in Nashville, Tennessee, left six victims dead.

## Wisconsin woman arrested after her suspected child was found dead in an abandoned field
 - [https://www.foxnews.com/us/wisconsin-woman-arrested-suspected-child-dead-abandoned-field](https://www.foxnews.com/us/wisconsin-woman-arrested-suspected-child-dead-abandoned-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:39:19+00:00

The suspected mother of a baby that was found dead in a southern Wisconsin field has been arrested. The baby had been in the field for less than 48 hours before being found.

## Arkansas Gov. Sarah Huckabee Sanders sets aside $470 million for 3,000 new prison beds, public safety measures
 - [https://www.foxnews.com/us/arkansas-gov-sarah-huckabee-sanders-sets-aside-470-million-3000-new-prison-beds-safety-measures](https://www.foxnews.com/us/arkansas-gov-sarah-huckabee-sanders-sets-aside-470-million-3000-new-prison-beds-safety-measures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:37:28+00:00

The governor of Arkansas set aside $470 million for 3,000 new prison beds and other measures in the state. Sanders said the project will require around $31 million in annual operating costs.

## Canadian crypto prodigy accused of scamming investors out of millions was kidnapped, 'tortured': reports
 - [https://www.foxnews.com/world/canadian-crypto-prodigy-accused-scamming-investors-millons-kidnapped-tortured-reports](https://www.foxnews.com/world/canadian-crypto-prodigy-accused-scamming-investors-millons-kidnapped-tortured-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:30:21+00:00

Self-proclaimed Crypto King Aiden Pleterski was allegedly kidnapped in Toronto and driven around and tortured for days while begging his landlord to pay $3 million ransom, reports say

## Florida sheriff greets New Jersey man accused of making threat against him
 - [https://www.foxnews.com/us/florida-sheriff-greets-new-jersey-man-accused-making-threat](https://www.foxnews.com/us/florida-sheriff-greets-new-jersey-man-accused-making-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:25:38+00:00

Volusia County Sheriff Mike Chitwood greeted a man who is accused of posting a death threat against him online when he was extradited to Florida from New Jersey.

## Bronny James dunks over brother at Powerade JamFest
 - [https://www.foxnews.com/sports/bronny-james-dunks-brother-powerade-jamfest](https://www.foxnews.com/sports/bronny-james-dunks-brother-powerade-jamfest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:21:08+00:00

Bronny James, a McDonald&apos;s All-American, wowed the crowd at the Powerade JamFest as he completed a dunk over his brother. LeBron James called it &quot;insane.&quot;

## Immigration law faces First Amendment challenge brought before Supreme Court
 - [https://www.foxnews.com/politics/immigration-law-faces-first-amendment-challenge-brought-supreme-court](https://www.foxnews.com/politics/immigration-law-faces-first-amendment-challenge-brought-supreme-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:17:09+00:00

The Supreme Court on Monday weighed whether giving immigration advice risks prosecution under a law making it a crime to &quot;encourage and induce&quot; illegal immigrants to stay in the U.S.

## TikTok: McCaul says he 'can't think of a greater propaganda tool' for China
 - [https://www.foxnews.com/politics/tiktok-mccaul-cant-think-greater-propaganda-tool-china](https://www.foxnews.com/politics/tiktok-mccaul-cant-think-greater-propaganda-tool-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:03:45+00:00

EXCLUSIVE: House Foreign Affairs Committee Chairman Michael McCaul said he “can’t think of a greater propaganda tool&quot; for China than TikTok, the app some are looking to ban.

## FDA admits to knowing about deadly bacteria found in baby formula months before it was recalled
 - [https://www.foxnews.com/politics/fda-admits-knowing-deadly-bacteria-baby-formula-months-before-recalled](https://www.foxnews.com/politics/fda-admits-knowing-deadly-bacteria-baby-formula-months-before-recalled)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:01:42+00:00

The FDA admitted to knowing that Cronobacter was detected in Enfamil baby formula, months before 145,000 cans were removed from the shelf due to safety concerns.

## Honey, Biden just shrunk our pension
 - [https://www.foxnews.com/opinion/honey-joe-biden-just-shrunk-our-pension](https://www.foxnews.com/opinion/honey-joe-biden-just-shrunk-our-pension)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 08:00:14+00:00

President Joe Biden recently issued his first veto since taking office.

## Alex Perez reveals he pulled out of UFC fight vs Manel Kape after suffering seizure
 - [https://www.foxnews.com/sports/alex-perez-reveals-pulled-out-ufc-fight-vs-manel-kape-suffering-seizure](https://www.foxnews.com/sports/alex-perez-reveals-pulled-out-ufc-fight-vs-manel-kape-suffering-seizure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 07:53:23+00:00

Alex Perez revealed he had to pull out of his flyweight fight against Manel Kape on Saturday because of a health issue during his pre-fight warm-up.

## Fire at Mexico migrant facility near US border leaves 39 dead, officials say
 - [https://www.foxnews.com/world/fire-mexico-migrant-facility-us-border-dead-officials-say](https://www.foxnews.com/world/fire-mexico-migrant-facility-us-border-dead-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 07:25:46+00:00

A fire at a migrant detention facility in Ciudad Juarez, across the U.S.-Mexico border from El Paso, Texas, has claimed the lives of at least 39 migrants, Mexican authorities said.

## Officers who took out school shooting suspect identified, Biden's tone-deaf statement and more top headlines
 - [https://www.foxnews.com/us/police-identify-officers-who-took-out-nashville-school-shooting-suspect](https://www.foxnews.com/us/police-identify-officers-who-took-out-nashville-school-shooting-suspect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 07:08:52+00:00

Officers who took out school shooting suspect identified, Biden&apos;s tone-deaf statement and more top headlines

## Kamala Harris stumbles over her words in Ghana speech: 'A lot of that work is the work that I am here to do'
 - [https://www.foxnews.com/media/kamala-harris-stumbles-words-ghana-speech-work-i-am-here-do](https://www.foxnews.com/media/kamala-harris-stumbles-words-ghana-speech-work-i-am-here-do)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 07:08:24+00:00

Kamala Harris delivered another halting, repetitive speech, this time in Ghana as part of the Biden administration&apos;s push to build closer ties with Africa.

## College professor suspended after saying it would be 'far more admirable to kill' racist speaker than protest
 - [https://www.foxnews.com/media/college-professor-suspended-far-more-admirable-kill-racist-speaker-protest](https://www.foxnews.com/media/college-professor-suspended-far-more-admirable-kill-racist-speaker-protest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 07:00:45+00:00

A professor at Wayne State University was suspended without pay after he said that it would be better to &quot;kill&quot; speakers he deems racist or transphobic rather than protest them.

## Top New York Republican scorches state Dems' effort to ban gas stoves: 'An attack on working people'
 - [https://www.foxnews.com/politics/top-new-york-republican-scorches-state-dems-effort-ban-gas-stoves-attack-working-people](https://www.foxnews.com/politics/top-new-york-republican-scorches-state-dems-effort-ban-gas-stoves-attack-working-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:50:13+00:00

The Republican leader of the New York state Senate blasted state Democrats for pushing policies banning gas stoves, arguing it was an &quot;attack&quot; on the working class.

## Martina Navratilova calls World Athletics' decision on transgender females 'step in the right direction'
 - [https://www.foxnews.com/sports/martina-navratilova-calls-world-athletics-decision-transgender-females-step-right-direction](https://www.foxnews.com/sports/martina-navratilova-calls-world-athletics-decision-transgender-females-step-right-direction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:45:30+00:00

Martina Navratilova expressed support for World Athletics in its decision to ban transgender females from competing against biological females in events.

## Cavinder twins reveal family dealt with 'health problems' during March Madness
 - [https://www.foxnews.com/sports/cavinder-twins-reveal-family-dealt-health-problems-during-march-madness](https://www.foxnews.com/sports/cavinder-twins-reveal-family-dealt-health-problems-during-march-madness)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:21:04+00:00

The Miami Hurricanes made it to the Elite Eight but nearly had to do it without the Cavinder twins as they revealed their family had a health issue.

## Tom Brady back in the field after Gisele Bündchen divorce: report
 - [https://www.foxnews.com/sports/tom-brady-back-field-gisele-bundchen-divorce-report](https://www.foxnews.com/sports/tom-brady-back-field-gisele-bundchen-divorce-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:08:03+00:00

Tom Brady is reportedly back in the dating pool after nearly a dozen years of marriage but does not appear to be connected to just one person.

## Aaron Rodgers went radio silent on Packers in offseason before trade request, GM suggests
 - [https://www.foxnews.com/sports/aaron-rodgers-went-radio-silent-packers-offseason-before-trade-request-gm-suggests](https://www.foxnews.com/sports/aaron-rodgers-went-radio-silent-packers-offseason-before-trade-request-gm-suggests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:03:50+00:00

Green Bay Packers general manager Brian Gutekunst said Monday his inability to reach Aaron Rodgers in the offseason led to trade discussions.

## Musk invites Twitter fact-checker community to check Biden's condemnation of 'MAGA' Republicans
 - [https://www.foxnews.com/media/musk-invites-twitter-fact-checker-community-check-bidens-condemnation-maga-republicans](https://www.foxnews.com/media/musk-invites-twitter-fact-checker-community-check-bidens-condemnation-maga-republicans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:00:46+00:00

Twitter CEO Elon Musk called upon Twitter&apos;s Community Notes feature to fact-check President Biden&apos;s tweet slamming &quot;MAGA House Republicans&apos;&quot; budget proposal.

## Sharks' James Reimer talks refusal to wear Pride-themed warmup, believes 'everyone has value and worth'
 - [https://www.foxnews.com/sports/sharks-james-reimer-talks-refusal-wear-pride-themed-warmup-believes-everyone-value-worth](https://www.foxnews.com/sports/sharks-james-reimer-talks-refusal-wear-pride-themed-warmup-believes-everyone-value-worth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:00:39+00:00

San Jose Sharks goaltender James Reimer opened up about his decision to skip wearing a Pride-themed jersey for a game earlier this month.

## This state just reclaimed the school choice crown
 - [https://www.foxnews.com/opinion/this-state-just-reclaimed-school-choice-crown](https://www.foxnews.com/opinion/this-state-just-reclaimed-school-choice-crown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:00:23+00:00

West Virginia and Arizona seized the school choice crown by passing universal school choice legislation.

## Nikki Haley to visit southern border in Texas after unveiling plan to tackle migrant crisis
 - [https://www.foxnews.com/politics/nikki-haley-visit-southern-border-texas-unveiling-plan-tackle-migrant-crisis](https://www.foxnews.com/politics/nikki-haley-visit-southern-border-texas-unveiling-plan-tackle-migrant-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:00:20+00:00

Former South Carolina governor and 2024 presidential hopeful Nikki Haley will visit the southern border in Texas next month to see the ongoing border crisis in-person.

## AOC ripped for posting on TikTok after House hearing: 'Thirsty for attention'
 - [https://www.foxnews.com/media/aoc-ripped-posting-tiktok-house-hearing-dangers-app-thirsty-for-attention](https://www.foxnews.com/media/aoc-ripped-posting-tiktok-house-hearing-dangers-app-thirsty-for-attention)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:00:19+00:00

Rep. Kat Cammack, R-Fla., slams Alexandria Ocasio-Cortez for posting a video on TikTok after attending a congressional hearing on the dangers of the social media app on &apos;The Faulkner Focus.&apos;

## Matt Gaetz introduces Somalia war powers resolution, forcing vote on removing armed forces
 - [https://www.foxnews.com/politics/matt-gaetz-introduces-somalia-war-powers-resolution-forcing-vote-to-remove-armed-forces](https://www.foxnews.com/politics/matt-gaetz-introduces-somalia-war-powers-resolution-forcing-vote-to-remove-armed-forces)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 06:00:13+00:00

Rep. Matt Gaetz is pushing the House of Representatives to vote on a war powers resolution that would remove United States armed forces from Somalia.

## Schumer swipes DeSantis as Russia prepares to position tactical nuclear weapons in Belarus: 'Excusing Putin'
 - [https://www.foxnews.com/politics/schumer-swipes-desantis-russia-prepares-position-tactical-nuclear-weapons-belarus-excusing-putin](https://www.foxnews.com/politics/schumer-swipes-desantis-russia-prepares-position-tactical-nuclear-weapons-belarus-excusing-putin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 05:55:34+00:00

Senate Majority Leader Chuck Schumer swiped Ron DeSantis in a tweet Monday evening, where he recalled the Republican&apos;s previous comments on Russia and Ukraine.

## ‘Lawless’ Haiti plagued by corruption, and deadly gang violence fuels humanitarian crisis
 - [https://www.foxnews.com/world/lawless-haiti-plagued-corruption-deadly-gang-violence-fuels-humanitarian-crisis](https://www.foxnews.com/world/lawless-haiti-plagued-corruption-deadly-gang-violence-fuels-humanitarian-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 05:00:56+00:00

The violence in Haiti has become so dire that the U.N. has called on the international community to send specialized forces to curtail gangs as kidnappings, torture and deaths spike.

## Gwyneth Paltrow's ski crash testimony may give her advantage with jury as legal experts dissect trial
 - [https://www.foxnews.com/entertainment/gwyneth-paltrow-ski-crash-testimony-may-give-advantage-jury-legal-experts-dissect-trial](https://www.foxnews.com/entertainment/gwyneth-paltrow-ski-crash-testimony-may-give-advantage-jury-legal-experts-dissect-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 04:00:45+00:00

Goop founder Gwyneth Paltrow was &quot;believable&quot; on the stand with recollection of the accident and could win $300,000 negligence suit despite celebrity status, according to legal experts.

## FLASHBACK: Army Rangers engage in 300-round shootout with Crips gang on US soil
 - [https://www.foxnews.com/us/flashback-army-rangers-engage-300-round-shootout-crips-gang-us-soil](https://www.foxnews.com/us/flashback-army-rangers-engage-300-round-shootout-crips-gang-us-soil)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 04:00:43+00:00

When violent crime threatened his Tacoma neighborhood, Bill Foulk enlisted the help of his fellow Army Rangers. The gangs weren&apos;t prepared for what came next.

## DA Alvin Bragg's chief prosecutor said criminals aren't 'bad dudes,' ripped 'racist' justice system
 - [https://www.foxnews.com/media/da-alvin-braggs-chief-prosecutor-criminals-arent-bad-dudes-ripped-racist-justice-system](https://www.foxnews.com/media/da-alvin-braggs-chief-prosecutor-criminals-arent-bad-dudes-ripped-racist-justice-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 04:00:08+00:00

Manhattan District Attorney Alvin Bragg&apos;s chief prosecutor has been spearheading critical race theory ideology in the criminal justice field at John Jay College of Criminal Justice.

## The one thing Biden could do right now to turn our economy around
 - [https://www.foxnews.com/opinion/thing-biden-do-turn-economy-around](https://www.foxnews.com/opinion/thing-biden-do-turn-economy-around)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 04:00:06+00:00

President Joe Biden claims he supports our economy. But he has neglected to tend to trade as an engine to create jobs and drive America&apos;s economy. Instead, Biden almost ignores it.

## Russia fires nuclear-capable, anti-ship missiles in Sea of Japan during simulated attack
 - [https://www.foxnews.com/world/russia-fires-nuclear-capable-anti-ship-missiles-sea-japan-during-simulated-attack](https://www.foxnews.com/world/russia-fires-nuclear-capable-anti-ship-missiles-sea-japan-during-simulated-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 03:39:24+00:00

Russia&apos;s Defense Ministry announces it has launched a simulated attack in the Sea of Japan, which included two boats firing several nuclear-capable missiles.

## Georgia man charged with murder after allegedly killing ex-girlfriend, burning her body
 - [https://www.foxnews.com/us/georgia-man-charged-murder-after-allegedly-killing-ex-girlfriend-burning-her-body](https://www.foxnews.com/us/georgia-man-charged-murder-after-allegedly-killing-ex-girlfriend-burning-her-body)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 03:24:31+00:00

A Georgia man is accused of killing his ex-girlfriend and burning her body in a vehicle. He faces multiple charges, including felony murder and aggravated assault.

## Forget the latest polls: A state marathon could boost DeSantis against Trump
 - [https://www.foxnews.com/media/forget-latest-polls-state-marathon-could-boost-desantis-against-trump](https://www.foxnews.com/media/forget-latest-polls-state-marathon-could-boost-desantis-against-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 03:00:43+00:00

Trump is the overwhelming favorite in the GOP primaries against DeSantis, but primaries are a state-by-state marathon, not a national election.

## Chip Roy pushes to amend Respect for Marriage Act, include stronger religious protections
 - [https://www.foxnews.com/politics/chip-roy-pushes-amend-respect-marriage-act-include-stronger-religious-protections](https://www.foxnews.com/politics/chip-roy-pushes-amend-respect-marriage-act-include-stronger-religious-protections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 02:00:56+00:00

Rep. Chip Roy and Republican colleagues are asking a House Appropriations subcommittee to approve language that would amend the Respect for Marriage Act.

## Prince Harry in London: Prince William, King Charles have zero plans to give royal 'warm reception': experts
 - [https://www.foxnews.com/entertainment/prince-harry-london-prince-william-king-charles-zero-plans-give-royal-warm-reception](https://www.foxnews.com/entertainment/prince-harry-london-prince-william-king-charles-zero-plans-give-royal-warm-reception)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 02:00:43+00:00

In his memoir, &quot;Spare,&quot; Prince Harry blamed an overly aggressive press for the 1997 death of his mother, Princess Diana, and also accused the media of hounding his wife Meghan Markle.

## Life-changing cold therapy helps Pennsylvania mom with awful back pain: 'Could pick up my daughter' again
 - [https://www.foxnews.com/health/life-changing-cold-therapy-helps-pennsylvania-mom-awful-back-pain-could-pick-up-daughter-again](https://www.foxnews.com/health/life-changing-cold-therapy-helps-pennsylvania-mom-awful-back-pain-could-pick-up-daughter-again)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 02:00:39+00:00

Dannie DeNovo, a 44-year-old mother from Pennsylvania, was living in excruciating pain from a ruptured disc — until she discovered the benefits of ice baths.

## Buster Murdaugh and Stephen Smith homicide investigation includes these 5 things to know
 - [https://www.foxnews.com/opinion/buster-murdaugh-stephen-smith-5-things-know-where-homicide-investigation](https://www.foxnews.com/opinion/buster-murdaugh-stephen-smith-5-things-know-where-homicide-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 02:00:26+00:00

The death of Buster Murdaugh&apos;s classmate Stephen Smith in 2015 has been reclassified as a homicide by the South Carolina Law Enforcement Division. Could Buster be implicated?

## CS Lewis, Tolkien, Orwell among works tagged as triggers for 'far-right' extremism by anti-terrorism group
 - [https://www.foxnews.com/world/cs-lewis-tolkien-orwell-among-works-tagged-triggers-far-right-extremism-anti-terrorism-group](https://www.foxnews.com/world/cs-lewis-tolkien-orwell-among-works-tagged-triggers-far-right-extremism-anti-terrorism-group)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 02:00:10+00:00

Prevent, which polices allegations of terrorism in the U.K., listed major English authors on their list of texts that could potentially trigger right-wing extremism.

## Nashville school shooting: Officers who took out suspected Covenant shooter identified
 - [https://www.foxnews.com/us/nashville-school-shooting-officers-took-out-suspected-covenant-shooter-identified](https://www.foxnews.com/us/nashville-school-shooting-officers-took-out-suspected-covenant-shooter-identified)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 01:49:48+00:00

Metropolitan Nashville Police Chief John Drake identified the two police officers who were responsible for stopping the suspected shooter at the Covenant School.

## FIRE calls on George Mason students to resist censorship after demands to cancel Youngkin commencement speech
 - [https://www.foxnews.com/politics/fire-calls-george-mason-students-resist-censorship-after-demands-cancel-youngkin-commencement-speech](https://www.foxnews.com/politics/fire-calls-george-mason-students-resist-censorship-after-demands-cancel-youngkin-commencement-speech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 01:06:16+00:00

Civil liberties group FIRE is asking George Mason University students attempting to disinvite Gov. Glenn Youngkin as commencement speaker to engage with differing views.

## LAURA INGRAHAM: This killer's identity didn't match the media's 'preferred criteria'
 - [https://www.foxnews.com/media/laura-ingraham-killers-identity-medias-preferred-criteria](https://www.foxnews.com/media/laura-ingraham-killers-identity-medias-preferred-criteria)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 00:42:24+00:00

Laura Ingraham discusses how the identity of the Nashville school shooter being a transgender female was slowly revealed on &quot;The Ingraham Angle.&quot;

## Greg Gutfeld: Here's why school choice legislation can 'reshape the country'
 - [https://www.foxnews.com/opinion/greg-gutfeld-heres-why-school-choice-legislation-can-reshape-countr](https://www.foxnews.com/opinion/greg-gutfeld-heres-why-school-choice-legislation-can-reshape-countr)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 00:11:49+00:00

Fox News host Greg Gutfeld reacts to Florida becoming the sixth state nationwide to pass universal school choice legislation and why more parents are in favor of it on &apos;Gutfeld!&apos;

## On this day in history, March 28, 1866, first US ambulance service rolls through Cincinnati
 - [https://www.foxnews.com/lifestyle/this-day-history-march-28-1866-first-us-ambulance-service-rolls-through-cincinnati](https://www.foxnews.com/lifestyle/this-day-history-march-28-1866-first-us-ambulance-service-rolls-through-cincinnati)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-28 00:02:19+00:00

The U.S. welcomed the first civilian ambulance care in Cincinnati, Ohio, on this day in history, March 28, 1866. It was inspired by medical advances during the Civil War.

