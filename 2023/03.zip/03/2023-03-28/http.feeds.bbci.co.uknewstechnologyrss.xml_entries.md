# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## AI could replace equivalent of 300 million jobs - report
 - [https://www.bbc.co.uk/news/technology-65102150?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65102150?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-03-28 16:25:14+00:00

ChatGPT-style AI will have a large impact but new jobs could emerge, a Goldman Sachs report says.

## Elon Musk: Twitter boss announces blue tick shake-up
 - [https://www.bbc.co.uk/news/business-65095684?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65095684?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-03-28 03:57:10+00:00

Only paying users will have their content recommended and be allowed to vote in polls from 15 April.

