# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## Last Of Us Part 1 On The Steam Deck, How Well Does It Run?
 - [https://www.youtube.com/watch?v=wQeOsgx41Ac](https://www.youtube.com/watch?v=wQeOsgx41Ac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-03-28 23:00:32+00:00

How well does the Last Of Us Part 1 PC port run on the Steam Deck? lets find out
AT the time of making this video the last of us Part 1 is not steam deck verified but it does work and in this video we take look at what settings i use for it and talk about upcoming optimizations that could be had. Should you buy the Last Of Us Part 1 for the steam deck?

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME 
12520 Capital Blvd Ste 401 Number 108
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY

#steamdeck #sony #etaprime

## The All New RED Magic 4K Monitor Turns Your Phone Into A Gaming PC! Hands-On Review
 - [https://www.youtube.com/watch?v=rvhtEwiu6PE](https://www.youtube.com/watch?v=rvhtEwiu6PE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-03-28 14:06:00+00:00

The all new Red Magic 4K Mini LED gaming monitor is amazing!
27" with 2000 Mini LEDs USB C video in, HDMI, Display port and a ton of gaming centric features make this monitor a must have! it works with any device that supports vidoe out like the Red Magic 8 pro, Samsung Galaxy S22, Steam Deck, Xbox series X, Series S, PS5, PC and many many more!

https://na.redmagic.gg/pages/redmagic-4k-gaming-monitor

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME 
12520 Capital Blvd Ste 401 Number 108
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#gaming #redmagic #etaprime
00:00 Introduction
00:53 Unboxing
01:52 Specs and features
05:08 4K PC gaming Test
05:56 Red Magic 8 Pro Console Mode
07:53 Steam Deck Testing

