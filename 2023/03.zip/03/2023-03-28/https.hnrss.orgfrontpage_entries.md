# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Is Babylon 5 the most influential TV show of the past 25 years? (2021)
 - [https://www.techradar.com/news/is-babylon-5-secretly-the-most-influential-tv-show-of-the-past-25-years](https://www.techradar.com/news/is-babylon-5-secretly-the-most-influential-tv-show-of-the-past-25-years)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 20:52:08+00:00

<p>Article URL: <a href="https://www.techradar.com/news/is-babylon-5-secretly-the-most-influential-tv-show-of-the-past-25-years">https://www.techradar.com/news/is-babylon-5-secretly-the-most-influential-tv-show-of-the-past-25-years</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35347648">https://news.ycombinator.com/item?id=35347648</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## New health insurance “transparency data” looks suspiciously wrong
 - [https://www.dolthub.com/blog/2023-03-23-illusion-of-transparency/](https://www.dolthub.com/blog/2023-03-23-illusion-of-transparency/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 20:51:51+00:00

<p>Article URL: <a href="https://www.dolthub.com/blog/2023-03-23-illusion-of-transparency/">https://www.dolthub.com/blog/2023-03-23-illusion-of-transparency/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35347647">https://news.ycombinator.com/item?id=35347647</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Open Flamingo – open framework to train multimodal LLMs
 - [https://laion.ai/blog/open-flamingo/](https://laion.ai/blog/open-flamingo/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 20:47:28+00:00

<p>Article URL: <a href="https://laion.ai/blog/open-flamingo/">https://laion.ai/blog/open-flamingo/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35347588">https://news.ycombinator.com/item?id=35347588</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## China reports human case of H3N8 bird flu
 - [https://bnonews.com/index.php/2023/03/china-reports-human-case-of-h3n8-bird-flu/](https://bnonews.com/index.php/2023/03/china-reports-human-case-of-h3n8-bird-flu/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 20:45:00+00:00

<p>Article URL: <a href="https://bnonews.com/index.php/2023/03/china-reports-human-case-of-h3n8-bird-flu/">https://bnonews.com/index.php/2023/03/china-reports-human-case-of-h3n8-bird-flu/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35347557">https://news.ycombinator.com/item?id=35347557</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Microsoft's Software Is Malware
 - [https://www.gnu.org/proprietary/malware-microsoft.en.html](https://www.gnu.org/proprietary/malware-microsoft.en.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 20:43:18+00:00

<p>Article URL: <a href="https://www.gnu.org/proprietary/malware-microsoft.en.html">https://www.gnu.org/proprietary/malware-microsoft.en.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35347540">https://news.ycombinator.com/item?id=35347540</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Ivy League Prices Are Pushing $90k a Year
 - [https://www.msn.com/en-us/money/careersandeducation/ivy-league-prices-are-pushing-90-000-a-year/ar-AA19bXsb](https://www.msn.com/en-us/money/careersandeducation/ivy-league-prices-are-pushing-90-000-a-year/ar-AA19bXsb)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 20:09:48+00:00

<p>Article URL: <a href="https://www.msn.com/en-us/money/careersandeducation/ivy-league-prices-are-pushing-90-000-a-year/ar-AA19bXsb">https://www.msn.com/en-us/money/careersandeducation/ivy-league-prices-are-pushing-90-000-a-year/ar-AA19bXsb</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35347092">https://news.ycombinator.com/item?id=35347092</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## 'Tylenol Lite' – Will a Safer New Useless Painkiller Replace a Dangerous Old One
 - [https://www.acsh.org/news/2022/08/22/tylenol-lite-will-safer-new-useless-painkiller-replace-dangerous-old-one-16500](https://www.acsh.org/news/2022/08/22/tylenol-lite-will-safer-new-useless-painkiller-replace-dangerous-old-one-16500)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 19:16:19+00:00

<p>Article URL: <a href="https://www.acsh.org/news/2022/08/22/tylenol-lite-will-safer-new-useless-painkiller-replace-dangerous-old-one-16500">https://www.acsh.org/news/2022/08/22/tylenol-lite-will-safer-new-useless-painkiller-replace-dangerous-old-one-16500</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35346352">https://news.ycombinator.com/item?id=35346352</a></p>
<p>Points: 10</p>
<p># Comments: 9</p>

## Windows 11 KB5023778 update adds promotions to the Start menu
 - [https://www.bleepingcomputer.com/news/microsoft/windows-11-kb5023778-update-adds-promotions-to-the-start-menu/](https://www.bleepingcomputer.com/news/microsoft/windows-11-kb5023778-update-adds-promotions-to-the-start-menu/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 19:00:44+00:00

<p>Article URL: <a href="https://www.bleepingcomputer.com/news/microsoft/windows-11-kb5023778-update-adds-promotions-to-the-start-menu/">https://www.bleepingcomputer.com/news/microsoft/windows-11-kb5023778-update-adds-promotions-to-the-start-menu/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35346137">https://news.ycombinator.com/item?id=35346137</a></p>
<p>Points: 29</p>
<p># Comments: 7</p>

## EU Commission Doesn't Understand What's Written in Its Own Chat Control Bill
 - [https://mullvad.net/en/blog/2023/3/28/the-european-commission-does-not-understand-what-is-written-in-its-own-chat-control-bill/](https://mullvad.net/en/blog/2023/3/28/the-european-commission-does-not-understand-what-is-written-in-its-own-chat-control-bill/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 18:25:13+00:00

<p>Article URL: <a href="https://mullvad.net/en/blog/2023/3/28/the-european-commission-does-not-understand-what-is-written-in-its-own-chat-control-bill/">https://mullvad.net/en/blog/2023/3/28/the-european-commission-does-not-understand-what-is-written-in-its-own-chat-control-bill/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35345612">https://news.ycombinator.com/item?id=35345612</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Infinite Mac: Infinitemac.org
 - [https://blog.persistent.info/2023/03/infinitemac-dot-org.html](https://blog.persistent.info/2023/03/infinitemac-dot-org.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 17:53:51+00:00

<p>Article URL: <a href="https://blog.persistent.info/2023/03/infinitemac-dot-org.html">https://blog.persistent.info/2023/03/infinitemac-dot-org.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35345117">https://news.ycombinator.com/item?id=35345117</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## AI vs. AGI vs. Consciousness vs. Super-Intelligence vs. Agency
 - [https://secondbreakfast.co/ai-vs-agi-vs-consciousness-vs-super-intelligence-vs-agency](https://secondbreakfast.co/ai-vs-agi-vs-consciousness-vs-super-intelligence-vs-agency)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 17:41:50+00:00

<p>Article URL: <a href="https://secondbreakfast.co/ai-vs-agi-vs-consciousness-vs-super-intelligence-vs-agency">https://secondbreakfast.co/ai-vs-agi-vs-consciousness-vs-super-intelligence-vs-agency</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35344923">https://news.ycombinator.com/item?id=35344923</a></p>
<p>Points: 20</p>
<p># Comments: 8</p>

## UK Sets Up Fake Booter Sites to Muddy DDoS Market
 - [https://krebsonsecurity.com/2023/03/uk-sets-up-fake-booter-sites-to-muddy-ddos-market/](https://krebsonsecurity.com/2023/03/uk-sets-up-fake-booter-sites-to-muddy-ddos-market/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 17:36:02+00:00

<p>Article URL: <a href="https://krebsonsecurity.com/2023/03/uk-sets-up-fake-booter-sites-to-muddy-ddos-market/">https://krebsonsecurity.com/2023/03/uk-sets-up-fake-booter-sites-to-muddy-ddos-market/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35344831">https://news.ycombinator.com/item?id=35344831</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Keeping up with the overwhelming pace of AI innovation
 - [https://ryanshannon.substack.com/p/keeping-up-with-the-overwhelming](https://ryanshannon.substack.com/p/keeping-up-with-the-overwhelming)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 17:35:47+00:00

<p>Article URL: <a href="https://ryanshannon.substack.com/p/keeping-up-with-the-overwhelming">https://ryanshannon.substack.com/p/keeping-up-with-the-overwhelming</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35344825">https://news.ycombinator.com/item?id=35344825</a></p>
<p>Points: 46</p>
<p># Comments: 44</p>

## Show HN: A fully open-source (Apache 2.0)implementation of llama
 - [https://github.com/Lightning-AI/lit-llama](https://github.com/Lightning-AI/lit-llama)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 17:33:08+00:00

<p>We believe that AI should be fully open source and part of the collective knowledge.<p>The original LLaMA code is GPL licensed which means any project using it must also be released under GPL.<p>This "taints" any other code and prevents meaningful academic and commercial use.<p>Lit-LLaMA solves that for good.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35344787">https://news.ycombinator.com/item?id=35344787</a></p>
<p>Points: 27</p>
<p># Comments: 9</p>

## Interaction Nets, Combinators, and Calculus – HVM
 - [https://zicklag.github.io/blog/interaction-nets-combinators-calculus/](https://zicklag.github.io/blog/interaction-nets-combinators-calculus/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 17:17:56+00:00

<p>Article URL: <a href="https://zicklag.github.io/blog/interaction-nets-combinators-calculus/">https://zicklag.github.io/blog/interaction-nets-combinators-calculus/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35344514">https://news.ycombinator.com/item?id=35344514</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## TaxyAI: Open-source browser automation with GPT-4
 - [https://github.com/TaxyAI/browser-extension](https://github.com/TaxyAI/browser-extension)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 17:07:56+00:00

<p>Article URL: <a href="https://github.com/TaxyAI/browser-extension">https://github.com/TaxyAI/browser-extension</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35344354">https://news.ycombinator.com/item?id=35344354</a></p>
<p>Points: 34</p>
<p># Comments: 6</p>

## My4TH – A minimalistic FORTH computer with discrete CPU
 - [http://mynor.org/my4th](http://mynor.org/my4th)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 17:00:11+00:00

<p>Article URL: <a href="http://mynor.org/my4th">http://mynor.org/my4th</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35344227">https://news.ycombinator.com/item?id=35344227</a></p>
<p>Points: 38</p>
<p># Comments: 0</p>

## Snippyly (YC W22) Is Hiring Front end SWEs to make the web multiplayer
 - [https://www.ycombinator.com/companies/snippyly/jobs](https://www.ycombinator.com/companies/snippyly/jobs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 17:00:10+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/snippyly/jobs">https://www.ycombinator.com/companies/snippyly/jobs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35344225">https://news.ycombinator.com/item?id=35344225</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Belgian man dies by suicide following exchanges with ChatGPT
 - [https://www.brusselstimes.com/430098/belgian-man-commits-suicide-following-exchanges-with-chatgpt](https://www.brusselstimes.com/430098/belgian-man-commits-suicide-following-exchanges-with-chatgpt)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 16:37:30+00:00

<p>Article URL: <a href="https://www.brusselstimes.com/430098/belgian-man-commits-suicide-following-exchanges-with-chatgpt">https://www.brusselstimes.com/430098/belgian-man-commits-suicide-following-exchanges-with-chatgpt</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35343825">https://news.ycombinator.com/item?id=35343825</a></p>
<p>Points: 19</p>
<p># Comments: 15</p>

## LLMs and GPT: Some of my favorite learning materials
 - [https://gist.github.com/rain-1/eebd5e5eb2784feecf450324e3341c8d](https://gist.github.com/rain-1/eebd5e5eb2784feecf450324e3341c8d)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 16:36:23+00:00

<p>Article URL: <a href="https://gist.github.com/rain-1/eebd5e5eb2784feecf450324e3341c8d">https://gist.github.com/rain-1/eebd5e5eb2784feecf450324e3341c8d</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35343791">https://news.ycombinator.com/item?id=35343791</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Cerebras-GPT: A Family of Open, Compute-Efficient, Large Language Models
 - [https://www.cerebras.net/blog/cerebras-gpt-a-family-of-open-compute-efficient-large-language-models/](https://www.cerebras.net/blog/cerebras-gpt-a-family-of-open-compute-efficient-large-language-models/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 16:34:15+00:00

<p>Article URL: <a href="https://www.cerebras.net/blog/cerebras-gpt-a-family-of-open-compute-efficient-large-language-models/">https://www.cerebras.net/blog/cerebras-gpt-a-family-of-open-compute-efficient-large-language-models/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35343763">https://news.ycombinator.com/item?id=35343763</a></p>
<p>Points: 39</p>
<p># Comments: 6</p>

## Bicycle
 - [https://ciechanow.ski/bicycle/](https://ciechanow.ski/bicycle/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 16:19:48+00:00

<p>Article URL: <a href="https://ciechanow.ski/bicycle/">https://ciechanow.ski/bicycle/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35343495">https://news.ycombinator.com/item?id=35343495</a></p>
<p>Points: 230</p>
<p># Comments: 22</p>

## JWST gets best view yet of planet in hotly pursued star system
 - [https://www.nature.com/articles/d41586-023-00876-7](https://www.nature.com/articles/d41586-023-00876-7)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 15:40:16+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-023-00876-7">https://www.nature.com/articles/d41586-023-00876-7</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35342838">https://news.ycombinator.com/item?id=35342838</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Spin Wave
 - [https://en.wikipedia.org/wiki/Spin_wave](https://en.wikipedia.org/wiki/Spin_wave)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 15:35:09+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Spin_wave">https://en.wikipedia.org/wiki/Spin_wave</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35342755">https://news.ycombinator.com/item?id=35342755</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Iceland long term visa for remote workers
 - [https://island.is/en/get-long-term-visa-for-remote-workers](https://island.is/en/get-long-term-visa-for-remote-workers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 15:32:35+00:00

<p>Article URL: <a href="https://island.is/en/get-long-term-visa-for-remote-workers">https://island.is/en/get-long-term-visa-for-remote-workers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35342708">https://news.ycombinator.com/item?id=35342708</a></p>
<p>Points: 45</p>
<p># Comments: 33</p>

## Apple introduces Apple Pay Later
 - [https://www.apple.com/newsroom/2023/03/apple-introduces-apple-pay-later/](https://www.apple.com/newsroom/2023/03/apple-introduces-apple-pay-later/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 15:31:21+00:00

<p>Article URL: <a href="https://www.apple.com/newsroom/2023/03/apple-introduces-apple-pay-later/">https://www.apple.com/newsroom/2023/03/apple-introduces-apple-pay-later/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35342691">https://news.ycombinator.com/item?id=35342691</a></p>
<p>Points: 64</p>
<p># Comments: 117</p>

## Quicker Serverless Postgres Connections
 - [https://neon.tech/blog/quicker-serverless-postgres](https://neon.tech/blog/quicker-serverless-postgres)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 15:17:25+00:00

<p>Article URL: <a href="https://neon.tech/blog/quicker-serverless-postgres">https://neon.tech/blog/quicker-serverless-postgres</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35342464">https://news.ycombinator.com/item?id=35342464</a></p>
<p>Points: 31</p>
<p># Comments: 1</p>

## A non-federated decentralized social protocol based on Git
 - [https://github.com/social4git/social4git](https://github.com/social4git/social4git)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 15:17:04+00:00

<p>Article URL: <a href="https://github.com/social4git/social4git">https://github.com/social4git/social4git</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35342457">https://news.ycombinator.com/item?id=35342457</a></p>
<p>Points: 21</p>
<p># Comments: 17</p>

## Nuenv: An experimental Nushell builder for Nix packages
 - [https://determinate.systems/posts/nuenv](https://determinate.systems/posts/nuenv)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 15:01:43+00:00

<p>Article URL: <a href="https://determinate.systems/posts/nuenv">https://determinate.systems/posts/nuenv</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35342195">https://news.ycombinator.com/item?id=35342195</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Amazon starts flagging frequently returned products that you maybe shouldn’t buy
 - [https://www.theverge.com/2023/3/28/23659868/amazon-returns-warning-product-reviews-tag-feature](https://www.theverge.com/2023/3/28/23659868/amazon-returns-warning-product-reviews-tag-feature)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 14:51:35+00:00

<p>Article URL: <a href="https://www.theverge.com/2023/3/28/23659868/amazon-returns-warning-product-reviews-tag-feature">https://www.theverge.com/2023/3/28/23659868/amazon-returns-warning-product-reviews-tag-feature</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35342056">https://news.ycombinator.com/item?id=35342056</a></p>
<p>Points: 21</p>
<p># Comments: 1</p>

## I made $3k in 16 attempts to launch my SaaS
 - [https://www.indiehackers.com/post/i-made-3-000-in-16-attempts-to-launch-my-saas-06ab0a9f2a](https://www.indiehackers.com/post/i-made-3-000-in-16-attempts-to-launch-my-saas-06ab0a9f2a)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 14:43:47+00:00

<p>Article URL: <a href="https://www.indiehackers.com/post/i-made-3-000-in-16-attempts-to-launch-my-saas-06ab0a9f2a">https://www.indiehackers.com/post/i-made-3-000-in-16-attempts-to-launch-my-saas-06ab0a9f2a</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35341943">https://news.ycombinator.com/item?id=35341943</a></p>
<p>Points: 21</p>
<p># Comments: 9</p>

## Starbucks Illegally Withheld Raises and Tips from Union Workers, NLRB Says
 - [https://perfectunion.us/starbucks-nlrb-credit-card-tip-complaint/](https://perfectunion.us/starbucks-nlrb-credit-card-tip-complaint/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 14:28:22+00:00

<p>Article URL: <a href="https://perfectunion.us/starbucks-nlrb-credit-card-tip-complaint/">https://perfectunion.us/starbucks-nlrb-credit-card-tip-complaint/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35341680">https://news.ycombinator.com/item?id=35341680</a></p>
<p>Points: 39</p>
<p># Comments: 3</p>

## Launch HN: Metal (YC W23) – Embeddings as a Service
 - [https://news.ycombinator.com/item?id=35341514](https://news.ycombinator.com/item?id=35341514)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 14:18:40+00:00

<p>Hey HN! We’re Taylor, James and Sergio – the founders of Metal (<a href="https://www.getmetal.io/">https://www.getmetal.io/</a>). You can think of Metal as embeddings as a service. We help developers use embeddings without needing to build out infrastructure, storage, or tooling. Here’s a 2-minute overview: <a href="https://www.loom.com/share/39fb6df7fd73469eaf20b37248ceed0f" rel="nofollow">https://www.loom.com/share/39fb6df7fd73469eaf20b37248ceed0f</a><p>If you’re unfamiliar with embeddings, they are representations of real world data expressed as a vector, where the position of the vector can be compared to other vectors – thereby deriving <i>meaning</i> from the data. They can be used to create things like semantic search, recommender systems, clustering analysis, classification, and more.<p>Working at companies like Datadog, Meta, and Spotify, we found it frustrating to build ML apps. Lack of tooling, infrastructure, and proper abstraction made working with ML tedious and slow. To get features out the door we’ve had to build data ingestion pipelines from scratch, manually maintain live customer datasets, build observability to measure drift, manage no-downtime deployments, and the list goes on. It took months to get simple features in front of users and the developer experience was terrible.<p>OpenAI, Hugging Face and others have brought models to the masses, but the developer experience still needs to be improved. To actually use embeddings, hitting APIs like OpenAI is just one piece of the puzzle. You also need to figure out storage, create indexes, maintain data quality through fine-tuning, manage versions, code operations on top of your data, and create APIs to consume it. All of this friction makes it a pain to ship live applications.<p>Metal solves these problems by providing an end-to-end platform for embeddings. Here’s how it works:<p><i>Data In:</i> You send data to our system via our SDK or API. Data can be text, images, PDFs, or raw embeddings. When data hits our pipeline we preprocess by extracting the text from documents and chunking when necessary. We then generate embeddings using the selected model. If the index has fine-tuning transformation, we transform the embedding into the new vector space so it matches the target data. We then store the embeddings in cold storage for any needed async jobs.<p>From there we index the embeddings for querying. We use HSNW right now, but are planning to support FLAT indexes as well. We currently index in Redis, but plan to make this configurable and provide more options for datastores.<p><i>Data Out:</i> We provide querying endpoints to hit the indexes, finding the ANN. For fine-tuned indexes, we generate embeddings from the base model used and then transform the embedding into the new vector space during the pre-query phase.<p>Additionally, we provide methods to run clustering jobs on the stored embeddings and visualizations in the UI. We are experimenting with zero-shot classification, by embedding the classes and matching to each embedding in the closest class, allowing us to provide a “classify” method in our SDK. We would love feedback on what other async job types would be useful!<p>Examples of what users have built so far include embedding product catalogs for improved similarity search, personalized in-app messaging with user behavior clusters, and similarity search on images for content creators.<p>Metal has a free tier that anyone can use, a developer tier for $20/month, and an enterprise tier with custom pricing. We’re currently building an open source product that will be released soon.<p>Most importantly, we’re sharing Metal with the HN community because we want to build the best developer experience possible, and the only metric we care about is live apps on prod. We’d love to hear your feedback, experiences with embeddings, and your ideas for how we can improve the product. Looking forward to your comments, thank you!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35341514">https://news.ycombinator.com/item?id=35341514</a></p>
<p>Points: 22</p>
<p># Comments: 5</p>

## How to Polis, 101, Part IIb: Archons
 - [https://acoup.blog/2023/03/24/collections-how-to-polis-101-part-iib-archons/](https://acoup.blog/2023/03/24/collections-how-to-polis-101-part-iib-archons/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 14:16:24+00:00

<p>Article URL: <a href="https://acoup.blog/2023/03/24/collections-how-to-polis-101-part-iib-archons/">https://acoup.blog/2023/03/24/collections-how-to-polis-101-part-iib-archons/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35341471">https://news.ycombinator.com/item?id=35341471</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Alibaba to Split into Six Units
 - [https://www.reuters.com/technology/alibaba-split-into-six-units-2023-03-28/](https://www.reuters.com/technology/alibaba-split-into-six-units-2023-03-28/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 14:09:04+00:00

<p>Article URL: <a href="https://www.reuters.com/technology/alibaba-split-into-six-units-2023-03-28/">https://www.reuters.com/technology/alibaba-split-into-six-units-2023-03-28/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35341354">https://news.ycombinator.com/item?id=35341354</a></p>
<p>Points: 10</p>
<p># Comments: 3</p>

## Banksy ship saving migrants at sea detained in Italy for 'breaking rules'
 - [https://www.express.co.uk/news/world/1751594/banksy-ship-migrants-italy-detained](https://www.express.co.uk/news/world/1751594/banksy-ship-migrants-italy-detained)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 13:53:25+00:00

<p>Article URL: <a href="https://www.express.co.uk/news/world/1751594/banksy-ship-migrants-italy-detained">https://www.express.co.uk/news/world/1751594/banksy-ship-migrants-italy-detained</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35341101">https://news.ycombinator.com/item?id=35341101</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Current causes of death in children and adolescents in the United States (2022)
 - [https://www.nejm.org/doi/full/10.1056/nejmc2201761](https://www.nejm.org/doi/full/10.1056/nejmc2201761)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 13:28:25+00:00

<p>Article URL: <a href="https://www.nejm.org/doi/full/10.1056/nejmc2201761">https://www.nejm.org/doi/full/10.1056/nejmc2201761</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35340721">https://news.ycombinator.com/item?id=35340721</a></p>
<p>Points: 36</p>
<p># Comments: 31</p>

## Android app from China executed 0-day exploit on millions of devices
 - [https://arstechnica.com/information-technology/2023/03/android-app-from-china-executed-0-day-exploit-on-millions-of-devices/](https://arstechnica.com/information-technology/2023/03/android-app-from-china-executed-0-day-exploit-on-millions-of-devices/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 12:54:03+00:00

<p>Article URL: <a href="https://arstechnica.com/information-technology/2023/03/android-app-from-china-executed-0-day-exploit-on-millions-of-devices/">https://arstechnica.com/information-technology/2023/03/android-app-from-china-executed-0-day-exploit-on-millions-of-devices/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35340171">https://news.ycombinator.com/item?id=35340171</a></p>
<p>Points: 19</p>
<p># Comments: 3</p>

## Show HN: I built developer tooling for the Airtable API that I needed
 - [https://airwalker.io](https://airwalker.io)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 12:54:01+00:00

<p>As a software engineer, I've experienced firsthand the challenges of working with the Airtable API.<p>As more non-technical users began using the platform in our growing business, the need for engineering to automate processes and sync data into Airtable grew. However, keeping track of process failures and ensuring that no unresolved failures slipped by was difficult and required significant effort.<p>That's why I created Airwalker, a toolkit that improves the reliability of processes using the Airtable API and helps you correct issues quickly and with minimal effort.<p>Here are some of the features Airwalker offers:<p>* Base schema timeline<p>* Request/response logging<p>* Edit & replay<p>* Custom automatically maintained TypeScript types<p>Airwalker is free to use right now, and I welcome any feedback or suggestions.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35340169">https://news.ycombinator.com/item?id=35340169</a></p>
<p>Points: 11</p>
<p># Comments: 7</p>

## Show HN: An all-in-one app designed for deep work and to build atomic habits
 - [https://www.floutwork.com](https://www.floutwork.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 12:42:03+00:00

<p>Article URL: <a href="https://www.floutwork.com">https://www.floutwork.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35339968">https://news.ycombinator.com/item?id=35339968</a></p>
<p>Points: 22</p>
<p># Comments: 13</p>

## Random Fuzzy Thoughts
 - [https://tigerbeetle.com/blog/2023-03-28-random-fuzzy-thoughts/](https://tigerbeetle.com/blog/2023-03-28-random-fuzzy-thoughts/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 12:11:08+00:00

<p>Article URL: <a href="https://tigerbeetle.com/blog/2023-03-28-random-fuzzy-thoughts/">https://tigerbeetle.com/blog/2023-03-28-random-fuzzy-thoughts/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35339521">https://news.ycombinator.com/item?id=35339521</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## Toko (YC W22) Is Hiring a Founding Engineer to Teach English with AI
 - [https://news.ycombinator.com/item?id=35339377](https://news.ycombinator.com/item?id=35339377)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 12:01:06+00:00

<p>Toko (YC W22) is on a mission to make English fluency accessible to the world's 1.5B English learners. With our app, learners talk with an AI like it's a real person, and get feedback on their grammar/pronunciation.<p>We are in the top 3 apps for education in Taiwan, with ~3k paying subscribers (and growing fast)! Many users have reported landing new jobs and confidently moving overseas since using Toko.<p>Founding team has 10+ years of ed-tech experience at MIT, Quizlet, Codecademy (+ experience at Google, Palantir, and Stripe).<p>As a Founding Engineer, you’ll have an outsized equity stake and impact on the product, culture & future of language learning.<p>Learn more & apply here: <a href="https://www.ycombinator.com/companies/toko/jobs/hXNmmpi-founding-product-engineer" rel="nofollow">https://www.ycombinator.com/companies/toko/jobs/hXNmmpi-foun...</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35339377">https://news.ycombinator.com/item?id=35339377</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## EU countries approve 2035 phaseout of CO2-emitting cars
 - [https://www.reuters.com/business/autos-transportation/eu-countries-poised-approve-2035-phaseout-co2-emitting-cars-2023-03-28/](https://www.reuters.com/business/autos-transportation/eu-countries-poised-approve-2035-phaseout-co2-emitting-cars-2023-03-28/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 11:59:15+00:00

<p>Article URL: <a href="https://www.reuters.com/business/autos-transportation/eu-countries-poised-approve-2035-phaseout-co2-emitting-cars-2023-03-28/">https://www.reuters.com/business/autos-transportation/eu-countries-poised-approve-2035-phaseout-co2-emitting-cars-2023-03-28/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35339347">https://news.ycombinator.com/item?id=35339347</a></p>
<p>Points: 103</p>
<p># Comments: 164</p>

## Open Sourcing Cody – Sourcegraph's AI-enabled editor assistant
 - [https://about.sourcegraph.com/blog/open-sourcing-cody](https://about.sourcegraph.com/blog/open-sourcing-cody)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 11:33:03+00:00

<p>Article URL: <a href="https://about.sourcegraph.com/blog/open-sourcing-cody">https://about.sourcegraph.com/blog/open-sourcing-cody</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35339010">https://news.ycombinator.com/item?id=35339010</a></p>
<p>Points: 15</p>
<p># Comments: 13</p>

## Why the Myers-Briggs test is meaningless
 - [https://www.vox.com/2014/7/15/5881947/myers-briggs-personality-test-meaningless](https://www.vox.com/2014/7/15/5881947/myers-briggs-personality-test-meaningless)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 11:30:49+00:00

<p>Article URL: <a href="https://www.vox.com/2014/7/15/5881947/myers-briggs-personality-test-meaningless">https://www.vox.com/2014/7/15/5881947/myers-briggs-personality-test-meaningless</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35338984">https://news.ycombinator.com/item?id=35338984</a></p>
<p>Points: 17</p>
<p># Comments: 9</p>

## You're making me buy a new phone
 - [https://www.kooslooijesteijn.net/blog/you-are-making-me-buy-a-new-phone?pk_campaign=rss](https://www.kooslooijesteijn.net/blog/you-are-making-me-buy-a-new-phone?pk_campaign=rss)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 11:13:21+00:00

<p>Article URL: <a href="https://www.kooslooijesteijn.net/blog/you-are-making-me-buy-a-new-phone?pk_campaign=rss">https://www.kooslooijesteijn.net/blog/you-are-making-me-buy-a-new-phone?pk_campaign=rss</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35338823">https://news.ycombinator.com/item?id=35338823</a></p>
<p>Points: 63</p>
<p># Comments: 66</p>

## Smart urinals stuck on boot at a gas station in Germany
 - [https://old.reddit.com/r/PBSOD/comments/1244p9k/smart_urinals_stuck_on_boot_at_a_gas_station_in/](https://old.reddit.com/r/PBSOD/comments/1244p9k/smart_urinals_stuck_on_boot_at_a_gas_station_in/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 11:05:10+00:00

<p>Article URL: <a href="https://old.reddit.com/r/PBSOD/comments/1244p9k/smart_urinals_stuck_on_boot_at_a_gas_station_in/">https://old.reddit.com/r/PBSOD/comments/1244p9k/smart_urinals_stuck_on_boot_at_a_gas_station_in/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35338757">https://news.ycombinator.com/item?id=35338757</a></p>
<p>Points: 17</p>
<p># Comments: 16</p>

## Initialization in Modern C++ (295 pages)
 - [https://old.reddit.com/r/cpp/comments/1242djf/295_pages_on_initialization_in_modern_c/](https://old.reddit.com/r/cpp/comments/1242djf/295_pages_on_initialization_in_modern_c/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 09:55:14+00:00

<p>Article URL: <a href="https://old.reddit.com/r/cpp/comments/1242djf/295_pages_on_initialization_in_modern_c/">https://old.reddit.com/r/cpp/comments/1242djf/295_pages_on_initialization_in_modern_c/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35338151">https://news.ycombinator.com/item?id=35338151</a></p>
<p>Points: 15</p>
<p># Comments: 2</p>

## Swipe (YC S21) Is Hiring
 - [https://www.ycombinator.com/companies/swipe-2/jobs/VA7o3OW-android-intern](https://www.ycombinator.com/companies/swipe-2/jobs/VA7o3OW-android-intern)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 09:54:03+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/swipe-2/jobs/VA7o3OW-android-intern">https://www.ycombinator.com/companies/swipe-2/jobs/VA7o3OW-android-intern</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35338138">https://news.ycombinator.com/item?id=35338138</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Push notifications are now supported cross-browser
 - [https://web.dev/push-notifications-in-all-modern-browsers/](https://web.dev/push-notifications-in-all-modern-browsers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 09:12:34+00:00

<p>Article URL: <a href="https://web.dev/push-notifications-in-all-modern-browsers/">https://web.dev/push-notifications-in-all-modern-browsers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35337798">https://news.ycombinator.com/item?id=35337798</a></p>
<p>Points: 36</p>
<p># Comments: 16</p>

## Taking Magnesium tablet everyday changes my life
 - [https://news.ycombinator.com/item?id=35337676](https://news.ycombinator.com/item?id=35337676)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 08:56:57+00:00

<p>Just like the title said - I have always been active & semi-fit but in recent years, I suddenly got struck with terrible muscle soreness. I would often get cramps when waking up, play sport or bad soreness after a light jog, lifting weight or doing any kind of exercise. The soreness won't go away for days, sometimes a week or two which made it really hard to do any kind of exercise and I feel sluggish all the time and this went on for ages without me knowing why and doctor just discard it as "you just need to get used to exercise and it will get better". A year ago, I was just looking for why I get these leg cramps every 2 days, someone suggested taking Magnesium and Vitamin B  - This was the turning point.<p>Now, 12 months later and i'm enjoying my life again! I am now able to run up the hills with my kids, wake up without leg cramps at all and the soreness from lifting weight heals within half of a day or a day. I just want to share this if someone is struggling with similar problem as I recently shared it with my dad and a couple of relatives and almost everyone were having great results so it seems like a not very well-known thing. :)</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35337676">https://news.ycombinator.com/item?id=35337676</a></p>
<p>Points: 31</p>
<p># Comments: 31</p>

## Where have all the sacked tech workers gone?
 - [https://www.economist.com/business/2023/03/27/where-have-all-the-sacked-tech-workers-gone](https://www.economist.com/business/2023/03/27/where-have-all-the-sacked-tech-workers-gone)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 08:09:06+00:00

<p>Article URL: <a href="https://www.economist.com/business/2023/03/27/where-have-all-the-sacked-tech-workers-gone">https://www.economist.com/business/2023/03/27/where-have-all-the-sacked-tech-workers-gone</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35337326">https://news.ycombinator.com/item?id=35337326</a></p>
<p>Points: 24</p>
<p># Comments: 15</p>

## Apple Music Classical
 - [https://learn.applemusic.apple/apple-music-classical](https://learn.applemusic.apple/apple-music-classical)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 08:03:45+00:00

<p>Article URL: <a href="https://learn.applemusic.apple/apple-music-classical">https://learn.applemusic.apple/apple-music-classical</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35337296">https://news.ycombinator.com/item?id=35337296</a></p>
<p>Points: 40</p>
<p># Comments: 13</p>

## Little Snitch: PayPal has restricted our business account, threatens to close
 - [https://twitter.com/littlesnitch/status/1640436716895870985](https://twitter.com/littlesnitch/status/1640436716895870985)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 07:48:38+00:00

<p>Article URL: <a href="https://twitter.com/littlesnitch/status/1640436716895870985">https://twitter.com/littlesnitch/status/1640436716895870985</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35337210">https://news.ycombinator.com/item?id=35337210</a></p>
<p>Points: 102</p>
<p># Comments: 39</p>

## Red Hat is 30 years old
 - [https://www.redhat.com/en/blog/red-hat-30th-anniversary-celebrating-red-hat-day-north-carolina](https://www.redhat.com/en/blog/red-hat-30th-anniversary-celebrating-red-hat-day-north-carolina)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 07:38:48+00:00

<p>Article URL: <a href="https://www.redhat.com/en/blog/red-hat-30th-anniversary-celebrating-red-hat-day-north-carolina">https://www.redhat.com/en/blog/red-hat-30th-anniversary-celebrating-red-hat-day-north-carolina</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35337146">https://news.ycombinator.com/item?id=35337146</a></p>
<p>Points: 40</p>
<p># Comments: 11</p>

## GitHub slashes engineering team in India
 - [https://techcrunch.com/2023/03/27/github-slashes-engineering-team-in-india/](https://techcrunch.com/2023/03/27/github-slashes-engineering-team-in-india/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 06:52:22+00:00

<p>Article URL: <a href="https://techcrunch.com/2023/03/27/github-slashes-engineering-team-in-india/">https://techcrunch.com/2023/03/27/github-slashes-engineering-team-in-india/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35336870">https://news.ycombinator.com/item?id=35336870</a></p>
<p>Points: 20</p>
<p># Comments: 4</p>

## Your Code Might Not Need State
 - [https://www.onsclom.net/posts/simulator-state](https://www.onsclom.net/posts/simulator-state)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 06:15:00+00:00

<p>Article URL: <a href="https://www.onsclom.net/posts/simulator-state">https://www.onsclom.net/posts/simulator-state</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35336632">https://news.ycombinator.com/item?id=35336632</a></p>
<p>Points: 19</p>
<p># Comments: 3</p>

## OpenPGP master key on Nitrokey Start
 - [https://blog.josefsson.org/2023/03/27/openpgp-master-key-on-nitrokey-start/](https://blog.josefsson.org/2023/03/27/openpgp-master-key-on-nitrokey-start/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 06:11:11+00:00

<p>Article URL: <a href="https://blog.josefsson.org/2023/03/27/openpgp-master-key-on-nitrokey-start/">https://blog.josefsson.org/2023/03/27/openpgp-master-key-on-nitrokey-start/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35336610">https://news.ycombinator.com/item?id=35336610</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Trigonometric Functions in CSS
 - [https://web.dev/css-trig-functions/](https://web.dev/css-trig-functions/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 05:43:08+00:00

<p>Article URL: <a href="https://web.dev/css-trig-functions/">https://web.dev/css-trig-functions/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35336402">https://news.ycombinator.com/item?id=35336402</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## Higher-Order Virtual Machine (HVM)
 - [https://github.com/HigherOrderCO/HVM](https://github.com/HigherOrderCO/HVM)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 04:57:58+00:00

<p>Article URL: <a href="https://github.com/HigherOrderCO/HVM">https://github.com/HigherOrderCO/HVM</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35336113">https://news.ycombinator.com/item?id=35336113</a></p>
<p>Points: 31</p>
<p># Comments: 2</p>

## The meat industry blocked the IPCC’s attempt to recommend a plant-based diet
 - [https://qz.com/ipcc-report-on-climate-change-meat-industry-1850261179](https://qz.com/ipcc-report-on-climate-change-meat-industry-1850261179)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 03:14:47+00:00

<p>Article URL: <a href="https://qz.com/ipcc-report-on-climate-change-meat-industry-1850261179">https://qz.com/ipcc-report-on-climate-change-meat-industry-1850261179</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35335442">https://news.ycombinator.com/item?id=35335442</a></p>
<p>Points: 25</p>
<p># Comments: 5</p>

## Can you buy the same flight for less if you use a VPN?
 - [https://travel.stackexchange.com/questions/180321/can-you-buy-the-same-ticket-with-a-lower-price-if-you-buy-it-from-another-countr](https://travel.stackexchange.com/questions/180321/can-you-buy-the-same-ticket-with-a-lower-price-if-you-buy-it-from-another-countr)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 02:48:21+00:00

<p>Article URL: <a href="https://travel.stackexchange.com/questions/180321/can-you-buy-the-same-ticket-with-a-lower-price-if-you-buy-it-from-another-countr">https://travel.stackexchange.com/questions/180321/can-you-buy-the-same-ticket-with-a-lower-price-if-you-buy-it-from-another-countr</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35335240">https://news.ycombinator.com/item?id=35335240</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## A brief history of APFS (Apple File System) in honour of its fifth birthday
 - [https://eclecticlight.co/2022/04/01/a-brief-history-of-apfs-in-honour-of-its-fifth-birthday/](https://eclecticlight.co/2022/04/01/a-brief-history-of-apfs-in-honour-of-its-fifth-birthday/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 02:39:32+00:00

<p>Article URL: <a href="https://eclecticlight.co/2022/04/01/a-brief-history-of-apfs-in-honour-of-its-fifth-birthday/">https://eclecticlight.co/2022/04/01/a-brief-history-of-apfs-in-honour-of-its-fifth-birthday/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35335165">https://news.ycombinator.com/item?id=35335165</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## For the First Time, the Fed Is Losing Money
 - [https://www.wsj.com/articles/for-the-first-time-the-fed-is-losing-money-mortage-backed-securities-treasurys-interest-rate-risk-svb-ad92e96f](https://www.wsj.com/articles/for-the-first-time-the-fed-is-losing-money-mortage-backed-securities-treasurys-interest-rate-risk-svb-ad92e96f)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 02:31:07+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/for-the-first-time-the-fed-is-losing-money-mortage-backed-securities-treasurys-interest-rate-risk-svb-ad92e96f">https://www.wsj.com/articles/for-the-first-time-the-fed-is-losing-money-mortage-backed-securities-treasurys-interest-rate-risk-svb-ad92e96f</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35335097">https://news.ycombinator.com/item?id=35335097</a></p>
<p>Points: 29</p>
<p># Comments: 3</p>

## Procedural 3D mesh generation in a 64kB intro
 - [https://www.ctrl-alt-test.fr/2023/procedural-3d-mesh-generation-in-a-64kb-intro/](https://www.ctrl-alt-test.fr/2023/procedural-3d-mesh-generation-in-a-64kb-intro/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 02:22:19+00:00

<p>Article URL: <a href="https://www.ctrl-alt-test.fr/2023/procedural-3d-mesh-generation-in-a-64kb-intro/">https://www.ctrl-alt-test.fr/2023/procedural-3d-mesh-generation-in-a-64kb-intro/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35335037">https://news.ycombinator.com/item?id=35335037</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Patriot Act on steroids: anti-TikTok Trojan horse for censorship, surveillance
 - [https://dossier.substack.com/p/the-patriot-act-on-steroids-dc-uniparty](https://dossier.substack.com/p/the-patriot-act-on-steroids-dc-uniparty)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 01:55:53+00:00

<p>Article URL: <a href="https://dossier.substack.com/p/the-patriot-act-on-steroids-dc-uniparty">https://dossier.substack.com/p/the-patriot-act-on-steroids-dc-uniparty</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334851">https://news.ycombinator.com/item?id=35334851</a></p>
<p>Points: 45</p>
<p># Comments: 6</p>

## Show HN: Regex.ai – AI-powered regular expression generator
 - [https://regex.ai/](https://regex.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 01:55:44+00:00

<p>Regex.ai is an AI-powered tool that generates regular expressions. It can accurately generate regular expressions that match specific patterns in text with precision. Whether you're a novice or an expert, Regex.ai's intuitive interface makes it easy to input sample text and generate complex regular expressions quickly and efficiently. Overall, Regex.ai is a game-changer that will save you time and streamline your workflow.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334848">https://news.ycombinator.com/item?id=35334848</a></p>
<p>Points: 33</p>
<p># Comments: 8</p>

## Show HN: Document Q&A with GPT: web, .pdf, .docx, etc.
 - [https://klavier.ai/](https://klavier.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 01:47:20+00:00

<p>Hello fellow hackers,
we made a site that gets GPT to answer your question using the info on a webpage you specify or document you upload (e.g., a large textbook .pdf file).<p>Background:
When ChatGPT came out, I had the idea of having it pull answers from my stereo receiver's annoyingly dense 32 page manual. My weekend project prototype proceeded to surprise with great answers—just like what we've all experienced by now. My co-founder thought we should productize it, and make it easy to use online. So here we are with a very early beta! (Try it on a HN thread...)</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334792">https://news.ycombinator.com/item?id=35334792</a></p>
<p>Points: 16</p>
<p># Comments: 14</p>

## Gladys Kessler, Judge Who Curbed Deceptive Tobacco Ads, Dies at 85
 - [https://www.nytimes.com/2023/03/27/us/gladys-kessler-dead.htm](https://www.nytimes.com/2023/03/27/us/gladys-kessler-dead.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 01:45:18+00:00

<p>Article URL: <a href="https://www.nytimes.com/2023/03/27/us/gladys-kessler-dead.htm">https://www.nytimes.com/2023/03/27/us/gladys-kessler-dead.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334770">https://news.ycombinator.com/item?id=35334770</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## ChatGPT Outperforms Crowd-Workers for Text-Annotation Tasks
 - [https://arxiv.org/abs/2303.15056](https://arxiv.org/abs/2303.15056)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 01:39:02+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2303.15056">https://arxiv.org/abs/2303.15056</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334719">https://news.ycombinator.com/item?id=35334719</a></p>
<p>Points: 19</p>
<p># Comments: 6</p>

## Wavelength
 - [https://daringfireball.net/2023/03/wavelength](https://daringfireball.net/2023/03/wavelength)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 01:26:06+00:00

<p>Article URL: <a href="https://daringfireball.net/2023/03/wavelength">https://daringfireball.net/2023/03/wavelength</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334613">https://news.ycombinator.com/item?id=35334613</a></p>
<p>Points: 37</p>
<p># Comments: 16</p>

## Tech Companies Are Ruining Their Apps, Websites, Internet
 - [https://www.businessinsider.com/tech-companies-ruining-apps-websites-internet-worse-google-facebook-amazon-2023-3](https://www.businessinsider.com/tech-companies-ruining-apps-websites-internet-worse-google-facebook-amazon-2023-3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 01:08:25+00:00

<p>Article URL: <a href="https://www.businessinsider.com/tech-companies-ruining-apps-websites-internet-worse-google-facebook-amazon-2023-3">https://www.businessinsider.com/tech-companies-ruining-apps-websites-internet-worse-google-facebook-amazon-2023-3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334470">https://news.ycombinator.com/item?id=35334470</a></p>
<p>Points: 29</p>
<p># Comments: 10</p>

## The Perils of Polishing (old Fortran libraries)
 - [https://fortran-lang.discourse.group/t/the-perils-of-polishing-long/5444](https://fortran-lang.discourse.group/t/the-perils-of-polishing-long/5444)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 00:48:33+00:00

<p>Article URL: <a href="https://fortran-lang.discourse.group/t/the-perils-of-polishing-long/5444">https://fortran-lang.discourse.group/t/the-perils-of-polishing-long/5444</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334299">https://news.ycombinator.com/item?id=35334299</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Clearview AI used nearly 1M times by US police, it tells the BBC
 - [https://www.bbc.com/news/technology-65057011](https://www.bbc.com/news/technology-65057011)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 00:25:31+00:00

<p>Article URL: <a href="https://www.bbc.com/news/technology-65057011">https://www.bbc.com/news/technology-65057011</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334135">https://news.ycombinator.com/item?id=35334135</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Parsing the .DS_Store File Format
 - [https://0day.work/parsing-the-ds_store-file-format/](https://0day.work/parsing-the-ds_store-file-format/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-28 00:23:20+00:00

<p>Article URL: <a href="https://0day.work/parsing-the-ds_store-file-format/">https://0day.work/parsing-the-ds_store-file-format/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35334124">https://news.ycombinator.com/item?id=35334124</a></p>
<p>Points: 22</p>
<p># Comments: 12</p>

