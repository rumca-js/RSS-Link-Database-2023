# Source:Le Monde, URL:https://www.lemonde.fr/en/rss/une.xml, language:en-US

## Russia overtakes China as leading arms seller in sub-Saharan Africa
 - [https://www.lemonde.fr/en/le-monde-africa/article/2023/03/28/russia-overtakes-china-as-leading-arms-seller-in-sub-saharan-africa_6021018_124.html](https://www.lemonde.fr/en/le-monde-africa/article/2023/03/28/russia-overtakes-china-as-leading-arms-seller-in-sub-saharan-africa_6021018_124.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 21:51:21+00:00

South of the Sahara, a quarter of the arms purchased by African states come from Moscow, amidst the presence of the paramilitary group Wagner in the region.

## Mike Pence ordered to testify in January 6 investigation
 - [https://www.lemonde.fr/en/international/article/2023/03/28/mike-pence-ordered-to-testify-in-january-6-investigation_6021015_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/mike-pence-ordered-to-testify-in-january-6-investigation_6021015_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 21:13:50+00:00

The US judge has ruled that the former Vice President will have to testify before a grand jury in the Justice Department's investigation into efforts by former President Donald Trump and his allies to overturn the results of the 2020 election.

## Demonstrators in Israel wonder what to do next
 - [https://www.lemonde.fr/en/international/article/2023/03/28/demonstrators-in-israel-wonder-what-to-do-next_6021005_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/demonstrators-in-israel-wonder-what-to-do-next_6021005_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 17:06:27+00:00

Two of the country's most powerful institutions, the army and the national trade union center, played a key role in the protest. After the prime minister agreed to 'pause' the reform on Monday evening, the general strike was lifted.

## 740,000 protesters take to the streets across France: Interior Ministry
 - [https://www.lemonde.fr/en/france/article/2023/03/28/france-takes-to-the-streets-for-10th-day-of-strike-action-against-pension-reform_6021002_7.html](https://www.lemonde.fr/en/france/article/2023/03/28/france-takes-to-the-streets-for-10th-day-of-strike-action-against-pension-reform_6021002_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 16:21:06+00:00

Police were braced for violent protests as the 10th nationwide day of action against the divisive new French pension law, which includes raising the retirement age from 62 to 64, takes place across France.

## Olympic Committee recommends Russian athletes can compete as individuals
 - [https://www.lemonde.fr/en/international/article/2023/03/28/olympic-committee-recommends-russian-athletes-can-compete-as-individuals_6020997_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/olympic-committee-recommends-russian-athletes-can-compete-as-individuals_6020997_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 15:17:31+00:00

Poland, Ukraine and the Baltic states reiterated their call to maintain the ban on Russian and Belarusian athletes at the Olympics, saying 'not a single reason' existed to lift the restrictions.

## Germany faces significant strike action in demand for wage increases
 - [https://www.lemonde.fr/en/international/article/2023/03/28/germany-faces-significant-strike-action-in-demand-for-wage-increases_6020996_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/germany-faces-significant-strike-action-in-demand-for-wage-increases_6020996_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 15:00:53+00:00

Transportation was at a standstill on Monday, while hospitals and garbage collection were partially affected. Faced with 9% inflation, unions are demanding a 10.5% pay rise.

## French pension reform: Among the most affected, working-class communities often can't afford to protest
 - [https://www.lemonde.fr/en/france/article/2023/03/28/french-pension-reform-among-the-most-affected-working-class-communities-often-can-t-afford-to-protest_6020993_7.html](https://www.lemonde.fr/en/france/article/2023/03/28/french-pension-reform-among-the-most-affected-working-class-communities-often-can-t-afford-to-protest_6020993_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 14:20:40+00:00

In Stains, a working-class suburb outside of Paris, few inhabitants participate in the days of demonstrations against the controversial reform. The economic instability so prevalent in neighborhoods like this has constrained the strike effort.

## Six months of public consultations on the European project to ban 'forever chemicals'
 - [https://www.lemonde.fr/en/europe/article/2023/03/28/six-months-of-public-consultations-on-the-european-project-to-ban-forever-chemicals_6020992_143.html](https://www.lemonde.fr/en/europe/article/2023/03/28/six-months-of-public-consultations-on-the-european-project-to-ban-forever-chemicals_6020992_143.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 14:12:04+00:00

The biggest manufacturers and users of PFAS are opposing a complete ban and seeking exemptions.

## French court refuses to extradite former far-left Italian militants
 - [https://www.lemonde.fr/en/police-and-justice/article/2023/03/28/french-court-refuses-to-extradite-former-far-left-italian-militants_6020988_105.html](https://www.lemonde.fr/en/police-and-justice/article/2023/03/28/french-court-refuses-to-extradite-former-far-left-italian-militants_6020988_105.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 13:45:57+00:00

The two women and eight men were convicted of attacks in Italy carried out in the 1970s and 1980s and have lived freely in France for decades.

## UK raises Northern Ireland terrorism threat level to 'severe'
 - [https://www.lemonde.fr/en/united-kingdom/article/2023/03/28/uk-raises-northern-ireland-terrorism-threat-level-to-severe_6020986_135.html](https://www.lemonde.fr/en/united-kingdom/article/2023/03/28/uk-raises-northern-ireland-terrorism-threat-level-to-severe_6020986_135.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 13:41:04+00:00

The move comes a month after senior police officer John Caldwell was shot by masked gunmen in County Tyrone.

## BNP Paribas, Societe Générale, Exane, Natixis and HSBC offices searched as part of tax fraud scandal
 - [https://www.lemonde.fr/en/les-decodeurs/article/2023/03/28/bnp-paribas-societe-generale-exane-natixis-and-hsbc-offices-searched-as-part-of-tax-fraud-scandal_6020972_8.html](https://www.lemonde.fr/en/les-decodeurs/article/2023/03/28/bnp-paribas-societe-generale-exane-natixis-and-hsbc-offices-searched-as-part-of-tax-fraud-scandal_6020972_8.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 12:43:37+00:00

France's financial prosecutor suspects the banks of having allowed foreign clients to escape dividend taxation using "CumCum," a practice revealed by 'Le Monde' in 2018.

## Knife attack in Lisbon Muslim center leaves 2 dead, several injured
 - [https://www.lemonde.fr/en/europe/article/2023/03/28/knife-attack-in-lisbon-muslim-center-leaves-2-dead-several-injured_6020971_143.html](https://www.lemonde.fr/en/europe/article/2023/03/28/knife-attack-in-lisbon-muslim-center-leaves-2-dead-several-injured_6020971_143.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 12:02:31+00:00

The suspect 'armed with a large knife' was shot by police officers and taken to hospital.

## Fire at Mexico-US border migrant center kills at least 39
 - [https://www.lemonde.fr/en/international/article/2023/03/28/fire-at-mexico-us-border-migrant-center-kills-at-least-39_6020966_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/fire-at-mexico-us-border-migrant-center-kills-at-least-39_6020966_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 11:53:31+00:00

The fire broke out at a migrant detention center in Ciudad Juarez which neighbors El Paso, Texas.

## Confronted with widespread protests, Israeli PM 'pauses' controversial reform, without abandoning it
 - [https://www.lemonde.fr/en/international/article/2023/03/28/confronted-with-widespread-protests-israeli-pm-pauses-controversial-reform-without-abandoning-it_6020961_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/confronted-with-widespread-protests-israeli-pm-pauses-controversial-reform-without-abandoning-it_6020961_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 10:55:49+00:00

Benyamin Netanyahu said he wants to leave room for dialogue to avoid civil war. The parliamentary debates on the judicial system reform, which aims to abolish the Supreme Court's political independence, will resume in May.

## French debt nears €3 trillion with more spending in sight
 - [https://www.lemonde.fr/en/europe/article/2023/03/28/french-debt-nears-3-trillion-with-more-spending-in-sight_6020957_143.html](https://www.lemonde.fr/en/europe/article/2023/03/28/french-debt-nears-3-trillion-with-more-spending-in-sight_6020957_143.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 10:14:48+00:00

At €2.95 trillion at the end of 2022, public debt remains a concern for the French government as public spending is expected to keep rising.

## France braces for tenth nationwide day of action against pension bill
 - [https://www.lemonde.fr/en/france/article/2023/03/28/france-braces-for-tenth-nationwide-day-of-action-against-pension-bill_6020955_7.html](https://www.lemonde.fr/en/france/article/2023/03/28/france-braces-for-tenth-nationwide-day-of-action-against-pension-bill_6020955_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 09:58:30+00:00

Protests against President Emmanuel Macron's plans to raise retirement age by two years have been mostly peaceful so far. But anger has been building since the government pushed the bill through Parliament without a vote earlier this month.

## Robert Bilott: 'The battle is going to be big, but companies must pay for forever pollution from PFAS'
 - [https://www.lemonde.fr/en/environment/article/2023/03/28/robert-bilott-the-battle-is-going-to-be-big-but-companies-must-pay-for-forever-pollution-from-pfas_6020951_114.html](https://www.lemonde.fr/en/environment/article/2023/03/28/robert-bilott-the-battle-is-going-to-be-big-but-companies-must-pay-for-forever-pollution-from-pfas_6020951_114.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 09:50:33+00:00

The American lawyer has been warning about the dangers of per- and polyfluoroalkyl substances for nearly 25 years. He believes that immediate measures must be taken to protect public health.

## Greek prime minister calls general election for May 21
 - [https://www.lemonde.fr/en/international/article/2023/03/28/greek-prime-minister-calls-general-election-for-may-21_6020949_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/greek-prime-minister-calls-general-election-for-may-21_6020949_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 09:30:32+00:00

Kyriakos Mitsotakis's decision comes in the aftermath of a train disaster that has reduced his party’s long-standing majority in opinion polls.

## Nashville school shooting reminds us of the American plague of military-style war
 - [https://www.lemonde.fr/en/international/article/2023/03/28/nashville-school-massacre-reminds-us-of-the-american-plague-of-military-style-war_6020947_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/nashville-school-massacre-reminds-us-of-the-american-plague-of-military-style-war_6020947_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 09:19:08+00:00

In the United States, a shooter killed six people, including three 9-year-old children, on Monday in a Presbyterian school. Joe Biden once again called for a ban on assault rifles.

## Paris Olympics 2024: Could exceptional measures become the norm?
 - [https://www.lemonde.fr/en/france/article/2023/03/28/paris-olympics-2024-could-exceptional-measures-become-the-norm_6020941_7.html](https://www.lemonde.fr/en/france/article/2023/03/28/paris-olympics-2024-could-exceptional-measures-become-the-norm_6020941_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 09:13:44+00:00

The French government has passed legislative 'adjustments' depicted as 'unavoidable' for the hosting of the 2024 Games. Lawmakers worry about a 'law of exception' that could become the norm.

## 'Oh I'll have to put that back': Supermarket cashiers are at the forefront of soaring prices
 - [https://www.lemonde.fr/en/economy/article/2023/03/28/oh-i-ll-have-to-put-that-back-supermarket-cashiers-are-at-the-forefront-of-soaring-prices_6020937_19.html](https://www.lemonde.fr/en/economy/article/2023/03/28/oh-i-ll-have-to-put-that-back-supermarket-cashiers-are-at-the-forefront-of-soaring-prices_6020937_19.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 08:21:23+00:00

French retail employees witness scenes of everyday life that testify to consumers' anxieties and strategies in the face of inflation.

## Migrant shipwrecks off the Tunisian coast: 'By the time they pulled us out of the water, I saw at least six dead'
 - [https://www.lemonde.fr/en/tunisia/article/2023/03/28/migrant-shipwrecks-off-the-tunisian-coast-by-the-time-they-pulled-us-out-of-the-water-i-saw-at-least-six-dead_6020935_232.html](https://www.lemonde.fr/en/tunisia/article/2023/03/28/migrant-shipwrecks-off-the-tunisian-coast-by-the-time-they-pulled-us-out-of-the-water-i-saw-at-least-six-dead_6020935_232.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 08:09:15+00:00

At least 30 sub-Saharan Africans drowned last week near Sfax, as attempts to flee Tunisia's anti-migrant climate intensify.

## Russia fires anti-ship missiles at mock target in Sea of Japan
 - [https://www.lemonde.fr/en/international/article/2023/03/28/russia-fires-anti-ship-missiles-at-mock-target-in-sea-of-japan_6020926_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/russia-fires-anti-ship-missiles-at-mock-target-in-sea-of-japan_6020926_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 06:53:49+00:00

Russia's Pacific fleet drills came a week after Japanese Prime Minister Fumio Kishida visited Ukraine.

## The United States and Japan reach deal on critical EV battery minerals
 - [https://www.lemonde.fr/en/united-states/article/2023/03/28/the-united-states-and-japan-reach-deal-on-critical-ev-battery-minerals_6020921_133.html](https://www.lemonde.fr/en/united-states/article/2023/03/28/the-united-states-and-japan-reach-deal-on-critical-ev-battery-minerals_6020921_133.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 03:52:47+00:00

The agreement marks 'a welcome moment' as Washington continues to work with allies and partners to boost supply chains, including through the Inflation Reduction Act (IRA).

## French pension reform: Macron wants to renew dialogue but remains unyielding
 - [https://www.lemonde.fr/en/politics/article/2023/03/28/french-pension-reform-macron-wants-to-renew-dialogue-but-remains-unyielding_6020916_5.html](https://www.lemonde.fr/en/politics/article/2023/03/28/french-pension-reform-macron-wants-to-renew-dialogue-but-remains-unyielding_6020916_5.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 03:30:23+00:00

In a climate of tension and violence, the French president is trying to appease the trade unions. But the withdrawal of the pension reform is not envisaged.

## Opponents of French pension reform block garbage collection amidst requisition of workers
 - [https://www.lemonde.fr/en/economy/article/2023/03/28/opponents-of-french-pension-reform-block-garbage-collection-despite-requisition-of-workers_6020915_19.html](https://www.lemonde.fr/en/economy/article/2023/03/28/opponents-of-french-pension-reform-block-garbage-collection-despite-requisition-of-workers_6020915_19.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 03:28:23+00:00

The requisitioning of garbage workers has posed a new challenge for the opposition, yet blockades of refineries and incinerators have persisted with the participation of demonstrators from all sectors.

## In supermarkets across Europe, inflation is leading to a surge in food theft
 - [https://www.lemonde.fr/en/economy/article/2023/03/28/in-supermarkets-across-europe-inflation-is-leading-to-a-surge-in-food-theft_6020914_19.html](https://www.lemonde.fr/en/economy/article/2023/03/28/in-supermarkets-across-europe-inflation-is-leading-to-a-surge-in-food-theft_6020914_19.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 03:00:26+00:00

In countries like Greece, the UK and France, rising prices and the spread of automatic checkout machines have led to a surge in shoplifting. In response, retail stores are reinforcing their security measures.

## French lawmakers introduce bill to regulate influencers
 - [https://www.lemonde.fr/en/france/article/2023/03/28/french-lawmakers-introduce-bill-to-regulate-influencers_6020911_7.html](https://www.lemonde.fr/en/france/article/2023/03/28/french-lawmakers-introduce-bill-to-regulate-influencers_6020911_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 01:56:26+00:00

From Tuesday, March 28 the Assemblée Nationale will attempt to define the contours of the often-criticized profession of influencer.

## Humza Yousaf, a progressive pro-independence voice, will be Scotland's next first minister
 - [https://www.lemonde.fr/en/international/article/2023/03/28/humza-yousaf-a-progressive-pro-independence-voice-will-be-scotland-s-next-first-minister_6020908_4.html](https://www.lemonde.fr/en/international/article/2023/03/28/humza-yousaf-a-progressive-pro-independence-voice-will-be-scotland-s-next-first-minister_6020908_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-03-28 00:22:02+00:00

The new leader of the pro-independence party, who is of Indo-Pakistani origin, has been elected to replace Nicola Sturgeon, who resigned unexpectedly in mid-February.

