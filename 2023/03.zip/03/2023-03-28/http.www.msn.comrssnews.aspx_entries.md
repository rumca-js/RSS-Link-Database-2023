# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Nashville school shooter hid guns in parents' home
 - [http://www.msn.com/en-us/news/world/nashville-school-shooter-hid-guns-in-parents-home/ar-AA19bX8A?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nashville-school-shooter-hid-guns-in-parents-home/ar-AA19bX8A?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 23:16:16.440979+00:00



## Missing Georgia girl is home safe, but 'there are many unanswered questions': Cops
 - [http://www.msn.com/en-us/news/crime/missing-georgia-girl-is-home-safe-but-there-are-many-unanswered-questions-cops/ar-AA19bZiO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/missing-georgia-girl-is-home-safe-but-there-are-many-unanswered-questions-cops/ar-AA19bZiO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 23:16:16.430288+00:00



## Prince Harry testifies that he was kept in the dark about phone-tapping allegations
 - [http://www.msn.com/en-us/news/world/prince-harry-testifies-that-he-was-kept-in-the-dark-about-phone-tapping-allegations/ar-AA19bZs1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/prince-harry-testifies-that-he-was-kept-in-the-dark-about-phone-tapping-allegations/ar-AA19bZs1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 23:16:16.422094+00:00



## Nashville Shooting Fuels the Right’s Engine of Anti-Trans Hate
 - [http://www.msn.com/en-us/news/us/nashville-shooting-fuels-the-right-s-engine-of-anti-trans-hate/ar-AA19bMnH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nashville-shooting-fuels-the-right-s-engine-of-anti-trans-hate/ar-AA19bMnH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 23:16:16.414051+00:00



## Marjorie Taylor Greene Twitter Suspended After Trans 'Vengeance' Warning
 - [http://www.msn.com/en-us/news/us/marjorie-taylor-greene-twitter-suspended-after-trans-vengeance-warning/ar-AA19cdFf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/marjorie-taylor-greene-twitter-suspended-after-trans-vengeance-warning/ar-AA19cdFf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 23:16:16.405376+00:00



## Israel isn't 'out of the woods' even though Netanyahu paused the plan that pushed his country into chaos
 - [http://www.msn.com/en-us/news/world/israel-isn-t-out-of-the-woods-even-though-netanyahu-paused-the-plan-that-pushed-his-country-into-chaos/ar-AA19c4DF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-isn-t-out-of-the-woods-even-though-netanyahu-paused-the-plan-that-pushed-his-country-into-chaos/ar-AA19c4DF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 23:16:16.397119+00:00



## Loose barge carrying toxic alcohol compound partially submerged at Ohio River dam
 - [http://www.msn.com/en-us/news/us/loose-barge-carrying-toxic-alcohol-compound-partially-submerged-at-ohio-river-dam/ar-AA19c96E?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/loose-barge-carrying-toxic-alcohol-compound-partially-submerged-at-ohio-river-dam/ar-AA19c96E?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 23:16:16.386695+00:00



## States fret over 2024 election as threats rise and workers quit
 - [http://www.msn.com/en-us/news/politics/states-fret-over-2024-election-as-threats-rise-and-workers-quit/ar-AA19bPCS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/states-fret-over-2024-election-as-threats-rise-and-workers-quit/ar-AA19bPCS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 23:16:16.376455+00:00



## McConnell opposes as Senate nears repeal of Iraq war powers
 - [http://www.msn.com/en-us/news/politics/mcconnell-opposes-as-senate-nears-repeal-of-iraq-war-powers/ar-AA19bM1v?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mcconnell-opposes-as-senate-nears-repeal-of-iraq-war-powers/ar-AA19bM1v?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 22:16:29.566974+00:00



## Iran isn't worried about the US attacking it, but Biden has other ways to cut a deal with Tehran
 - [http://www.msn.com/en-us/news/world/iran-isn-t-worried-about-the-us-attacking-it-but-biden-has-other-ways-to-cut-a-deal-with-tehran/ar-AA19bP2B?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/iran-isn-t-worried-about-the-us-attacking-it-but-biden-has-other-ways-to-cut-a-deal-with-tehran/ar-AA19bP2B?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 22:16:29.558348+00:00



## Liberal Wisconsin Supreme Court candidate dubbed 'No Jail Janet' for letting violent felons off easy
 - [http://www.msn.com/en-us/news/crime/liberal-wisconsin-supreme-court-candidate-dubbed-no-jail-janet-for-letting-violent-felons-off-easy/ar-AA19caFR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/liberal-wisconsin-supreme-court-candidate-dubbed-no-jail-janet-for-letting-violent-felons-off-easy/ar-AA19caFR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 22:16:29.550762+00:00



## How is bitcoin still trading (for now) at $27,000?
 - [http://www.msn.com/en-us/news/technology/how-is-bitcoin-still-trading-for-now-at-27-000/ar-AA19c458?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-is-bitcoin-still-trading-for-now-at-27-000/ar-AA19c458?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 22:16:29.543344+00:00



## 'Nashville shooter sent me messages before attack'
 - [http://www.msn.com/en-us/news/world/nashville-shooter-sent-me-messages-before-attack/ar-AA19bPfj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nashville-shooter-sent-me-messages-before-attack/ar-AA19bPfj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 22:16:29.535870+00:00



## ESPN's Stephen A. Smith fires back on criticism of sports debate TV: 'You ain't innocent'
 - [http://www.msn.com/en-us/news/us/espn-s-stephen-a-smith-fires-back-on-criticism-of-sports-debate-tv-you-ain-t-innocent/ar-AA19bRgp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/espn-s-stephen-a-smith-fires-back-on-criticism-of-sports-debate-tv-you-ain-t-innocent/ar-AA19bRgp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 22:16:29.527645+00:00



## Nashville suspect's friend got message threatening suicide before shooting
 - [http://www.msn.com/en-us/news/crime/nashville-suspect-s-friend-got-message-threatening-suicide-before-shooting/ar-AA19bJFu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-suspect-s-friend-got-message-threatening-suicide-before-shooting/ar-AA19bJFu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 22:16:29.519989+00:00



## Twitter restricts Greene’s congressional account over ‘vengeance’ post
 - [http://www.msn.com/en-us/news/politics/twitter-restricts-greene-s-congressional-account-over-vengeance-post/ar-AA19c1kH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/twitter-restricts-greene-s-congressional-account-over-vengeance-post/ar-AA19c1kH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 22:16:29.510767+00:00



## What we know about the Nashville school shooting
 - [http://www.msn.com/en-us/news/us/what-we-know-about-the-nashville-school-shooting/ar-AA198TOu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-we-know-about-the-nashville-school-shooting/ar-AA198TOu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 21:16:10.861265+00:00



## Pennsylvania progressive defends TikTok as ‘incredible organizing tactic’
 - [http://www.msn.com/en-us/news/politics/pennsylvania-progressive-defends-tiktok-as-incredible-organizing-tactic/ar-AA19bTvv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pennsylvania-progressive-defends-tiktok-as-incredible-organizing-tactic/ar-AA19bTvv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 21:16:10.853820+00:00



## Deadly chocolate factory blast highlights combustion risks
 - [http://www.msn.com/en-us/news/us/deadly-chocolate-factory-blast-highlights-combustion-risks/ar-AA19bYrr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/deadly-chocolate-factory-blast-highlights-combustion-risks/ar-AA19bYrr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 21:16:10.845177+00:00



## Juror in Oath Keepers trial reveals secrets from the deliberation room
 - [http://www.msn.com/en-us/news/crime/juror-in-oath-keepers-trial-reveals-secrets-from-the-deliberation-room/ar-AA19bVYI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/juror-in-oath-keepers-trial-reveals-secrets-from-the-deliberation-room/ar-AA19bVYI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 21:16:10.837811+00:00



## Biden says Netanyahu not welcome at White House in 'near term'
 - [http://www.msn.com/en-us/news/politics/biden-says-netanyahu-not-welcome-at-white-house-in-near-term/ar-AA19c7X2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-says-netanyahu-not-welcome-at-white-house-in-near-term/ar-AA19c7X2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 21:16:10.830007+00:00



## Here's How Much Buying Store-Brand Groceries Will Save You
 - [http://www.msn.com/en-us/news/technology/here-s-how-much-buying-store-brand-groceries-will-save-you/ar-AAZRCeH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/here-s-how-much-buying-store-brand-groceries-will-save-you/ar-AAZRCeH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 21:16:10.821422+00:00



## Russia-Ukraine live updates: 2 dead, 29 hurt in Russian missile strike on Sloviansk
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-2-dead-29-hurt-in-russian-missile-strike-on-sloviansk/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-2-dead-29-hurt-in-russian-missile-strike-on-sloviansk/ar-AA17Sv9Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 21:16:10.812482+00:00



## Victims of The Covenant School massacre included a 9-year-old who loved to perform and a school leader dedicated to her students
 - [http://www.msn.com/en-us/news/us/victims-of-the-covenant-school-massacre-included-a-9-year-old-who-loved-to-perform-and-a-school-leader-dedicated-to-her-students/ar-AA19c7TW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/victims-of-the-covenant-school-massacre-included-a-9-year-old-who-loved-to-perform-and-a-school-leader-dedicated-to-her-students/ar-AA19c7TW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 21:16:10.804091+00:00



## Maryland court reinstates Adnan Syed's murder conviction in 'Serial' case
 - [http://www.msn.com/en-us/news/crime/maryland-court-reinstates-adnan-syed-s-murder-conviction-in-serial-case/ar-AA19bucR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/maryland-court-reinstates-adnan-syed-s-murder-conviction-in-serial-case/ar-AA19bucR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 20:16:14.901095+00:00



## "That may be the ballgame": Experts say Pence testimony could doom Trump
 - [http://www.msn.com/en-us/news/politics/that-may-be-the-ballgame-experts-say-pence-testimony-could-doom-trump/ar-AA19bLhl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/that-may-be-the-ballgame-experts-say-pence-testimony-could-doom-trump/ar-AA19bLhl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 20:16:14.892578+00:00



## A Wharton professor had AI chatbots work on a business project for 30 minutes — Bing wrote 1,757 words in under 3 minutes, and ChatGPT wrote code to build an entire website
 - [http://www.msn.com/en-us/news/technology/a-wharton-professor-had-ai-chatbots-work-on-a-business-project-for-30-minutes-bing-wrote-1-757-words-in-under-3-minutes-and-chatgpt-wrote-code-to-build-an-entire-website/ar-AA19bOfv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/a-wharton-professor-had-ai-chatbots-work-on-a-business-project-for-30-minutes-bing-wrote-1-757-words-in-under-3-minutes-and-chatgpt-wrote-code-to-build-an-entire-website/ar-AA19bOfv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 20:16:14.884309+00:00



## Adnan Syed's murder conviction reinstated months after he was freed
 - [http://www.msn.com/en-us/news/world/adnan-syed-s-murder-conviction-reinstated-months-after-he-was-freed/ar-AA19bJlL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/adnan-syed-s-murder-conviction-reinstated-months-after-he-was-freed/ar-AA19bJlL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 20:16:14.874433+00:00



## Minneapolis oversight police panel gets record amount of applicants: 'Seems unbelievable'
 - [http://www.msn.com/en-us/news/us/minneapolis-oversight-police-panel-gets-record-amount-of-applicants-seems-unbelievable/ar-AA19c2Ti?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/minneapolis-oversight-police-panel-gets-record-amount-of-applicants-seems-unbelievable/ar-AA19c2Ti?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 20:16:14.865461+00:00



## The US must safeguard democracy by combatting corruption
 - [http://www.msn.com/en-us/news/politics/the-us-must-safeguard-democracy-by-combatting-corruption/ar-AA19bTaC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-us-must-safeguard-democracy-by-combatting-corruption/ar-AA19bTaC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 20:16:14.856606+00:00



## Spring Cleaning Your Closet? Here's How to Declutter and Organize Your Clothes
 - [http://www.msn.com/en-us/news/technology/spring-cleaning-your-closet-here-s-how-to-declutter-and-organize-your-clothes/ar-AASychj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/spring-cleaning-your-closet-here-s-how-to-declutter-and-organize-your-clothes/ar-AASychj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 20:16:14.847857+00:00



## Tennessee reels over school shooting as lawmakers debate loosening gun laws
 - [http://www.msn.com/en-us/news/crime/tennessee-reels-over-school-shooting-as-lawmakers-debate-loosening-gun-laws/ar-AA19bwSM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/tennessee-reels-over-school-shooting-as-lawmakers-debate-loosening-gun-laws/ar-AA19bwSM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 20:16:14.837504+00:00



## How to Spot an AI-Generated Image Like the 'Balenciaga Pope'
 - [http://www.msn.com/en-us/news/technology/how-to-spot-an-ai-generated-image-like-the-balenciaga-pope/ar-AA19bxjN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-to-spot-an-ai-generated-image-like-the-balenciaga-pope/ar-AA19bxjN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 19:16:05.458526+00:00



## Lloyd Austin slams Tuberville's abortion-related holds on Pentagon nominations
 - [http://www.msn.com/en-us/news/politics/lloyd-austin-slams-tuberville-s-abortion-related-holds-on-pentagon-nominations/ar-AA19bNQ8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lloyd-austin-slams-tuberville-s-abortion-related-holds-on-pentagon-nominations/ar-AA19bNQ8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 19:16:05.450130+00:00



## Judge rejects Trump's privilege claims over Pence testimony in Jan. 6 probe
 - [http://www.msn.com/en-us/news/politics/judge-rejects-trump-s-privilege-claims-over-pence-testimony-in-jan-6-probe/ar-AA19bDk0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/judge-rejects-trump-s-privilege-claims-over-pence-testimony-in-jan-6-probe/ar-AA19bDk0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 19:16:05.441617+00:00



## Nashville shooter was under care for emotional disorder and hid weapons at parents' home, police say
 - [http://www.msn.com/en-us/news/crime/nashville-shooter-was-under-care-for-emotional-disorder-and-hid-weapons-at-parents-home-police-say/ar-AA19bKPO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-shooter-was-under-care-for-emotional-disorder-and-hid-weapons-at-parents-home-police-say/ar-AA19bKPO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 19:16:05.433963+00:00



## A reporter covering the Nashville shooting revealed on live TV that she survived a school shooting as a teen. She said the 'chaotic' scene 'put me right back.'
 - [http://www.msn.com/en-us/news/crime/a-reporter-covering-the-nashville-shooting-revealed-on-live-tv-that-she-survived-a-school-shooting-as-a-teen-she-said-the-chaotic-scene-put-me-right-back/ar-AA19btvC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-reporter-covering-the-nashville-shooting-revealed-on-live-tv-that-she-survived-a-school-shooting-as-a-teen-she-said-the-chaotic-scene-put-me-right-back/ar-AA19btvC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 19:16:05.426214+00:00



## Wagner Boss Denies Deployment to 'Post Apocalyptic' Avdiivka Frontline
 - [http://www.msn.com/en-us/news/world/wagner-boss-denies-deployment-to-post-apocalyptic-avdiivka-frontline/ar-AA19bBSu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/wagner-boss-denies-deployment-to-post-apocalyptic-avdiivka-frontline/ar-AA19bBSu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 19:16:05.418875+00:00



## China installs new ambassador in North Korea, one of few in the country
 - [http://www.msn.com/en-us/news/world/china-installs-new-ambassador-in-north-korea-one-of-few-in-the-country/ar-AA19bNTs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-installs-new-ambassador-in-north-korea-one-of-few-in-the-country/ar-AA19bNTs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 19:16:05.410885+00:00



## The US needs India, and much more, to make inroads into the Global South
 - [http://www.msn.com/en-us/news/world/the-us-needs-india-and-much-more-to-make-inroads-into-the-global-south/ar-AA19bJky?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-us-needs-india-and-much-more-to-make-inroads-into-the-global-south/ar-AA19bJky?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 19:16:05.401814+00:00



## Head of Powerful Teachers Union Blasts Republican Attempts to Gut Public Education
 - [http://www.msn.com/en-us/news/politics/head-of-powerful-teachers-union-blasts-republican-attempts-to-gut-public-education/ar-AA19bI20?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/head-of-powerful-teachers-union-blasts-republican-attempts-to-gut-public-education/ar-AA19bI20?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 18:15:56.093226+00:00



## McConnell bashes Iraq AUMF repeal ahead of Senate passage
 - [http://www.msn.com/en-us/news/politics/mcconnell-bashes-iraq-aumf-repeal-ahead-of-senate-passage/ar-AA19bDSN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mcconnell-bashes-iraq-aumf-repeal-ahead-of-senate-passage/ar-AA19bDSN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 18:15:56.085208+00:00



## Trump hires a former Jeb! hand to lead his campaign in the Granite State
 - [http://www.msn.com/en-us/news/politics/trump-hires-a-former-jeb-hand-to-lead-his-campaign-in-the-granite-state/ar-AA19bImP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-hires-a-former-jeb-hand-to-lead-his-campaign-in-the-granite-state/ar-AA19bImP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 18:15:56.078126+00:00



## Some on the right blame gender identity and not guns for Nashville shooting
 - [http://www.msn.com/en-us/news/us/some-on-the-right-blame-gender-identity-and-not-guns-for-nashville-shooting/ar-AA19bps6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/some-on-the-right-blame-gender-identity-and-not-guns-for-nashville-shooting/ar-AA19bps6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 18:15:56.069016+00:00



## McConnell blasts proposal to wind down war authority in Iraq
 - [http://www.msn.com/en-us/news/politics/mcconnell-blasts-proposal-to-wind-down-war-authority-in-iraq/ar-AA19bttB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mcconnell-blasts-proposal-to-wind-down-war-authority-in-iraq/ar-AA19bttB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 18:15:56.059660+00:00



## Why Jonathan Majors’s assault arrest is so disturbing — and so complicated
 - [http://www.msn.com/en-us/news/crime/why-jonathan-majors-s-assault-arrest-is-so-disturbing-and-so-complicated/ar-AA19bzqA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/why-jonathan-majors-s-assault-arrest-is-so-disturbing-and-so-complicated/ar-AA19bzqA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 18:15:56.050639+00:00



## Elephant in the dining room: Startup makes mammoth meatball
 - [http://www.msn.com/en-us/news/world/elephant-in-the-dining-room-startup-makes-mammoth-meatball/ar-AA19bDXf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/elephant-in-the-dining-room-startup-makes-mammoth-meatball/ar-AA19bDXf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 18:15:56.042850+00:00



## UN hears Africa, its Sahel region, are new terrorism targets
 - [http://www.msn.com/en-us/news/world/un-hears-africa-its-sahel-region-are-new-terrorism-targets/ar-AA19bjVJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/un-hears-africa-its-sahel-region-are-new-terrorism-targets/ar-AA19bjVJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 17:15:57.092325+00:00



## UK raises terrorism threat level ahead of possible Biden visit to Northern Ireland
 - [http://www.msn.com/en-us/news/world/uk-raises-terrorism-threat-level-ahead-of-possible-biden-visit-to-northern-ireland/ar-AA19bvKp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/uk-raises-terrorism-threat-level-ahead-of-possible-biden-visit-to-northern-ireland/ar-AA19bvKp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 17:15:57.083066+00:00



## “I thought he was horrific:” Trump's allies on Fox News trash his "disturbing" Hannity interview
 - [http://www.msn.com/en-us/news/politics/i-thought-he-was-horrific-trump-s-allies-on-fox-news-trash-his-disturbing-hannity-interview/ar-AA19byjJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/i-thought-he-was-horrific-trump-s-allies-on-fox-news-trash-his-disturbing-hannity-interview/ar-AA19byjJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 17:15:57.074547+00:00



## Duckworth calls on FTC to look into abortion pill distributor
 - [http://www.msn.com/en-us/news/politics/duckworth-calls-on-ftc-to-look-into-abortion-pill-distributor/ar-AA19bw56?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/duckworth-calls-on-ftc-to-look-into-abortion-pill-distributor/ar-AA19bw56?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 17:15:57.064548+00:00



## Police release bodycam footage of Nashville school shooter: Here's everything we know
 - [http://www.msn.com/en-us/news/crime/police-release-bodycam-footage-of-nashville-school-shooter-here-s-everything-we-know/ar-AA19bhOE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/police-release-bodycam-footage-of-nashville-school-shooter-here-s-everything-we-know/ar-AA19bhOE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 17:15:57.055528+00:00



## Family of Americans kidnapped by gang in Haiti urged them not to make the trip amid spike in violence
 - [http://www.msn.com/en-us/news/world/family-of-americans-kidnapped-by-gang-in-haiti-urged-them-not-to-make-the-trip-amid-spike-in-violence/ar-AA19boAI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/family-of-americans-kidnapped-by-gang-in-haiti-urged-them-not-to-make-the-trip-amid-spike-in-violence/ar-AA19boAI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 17:15:57.048537+00:00



## Experts expose growing threat from hackers supporting North Korea
 - [http://www.msn.com/en-us/news/world/experts-expose-growing-threat-from-hackers-supporting-north-korea/ar-AA19bvVR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/experts-expose-growing-threat-from-hackers-supporting-north-korea/ar-AA19bvVR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 17:15:57.041079+00:00



## Nashville school shooter messaged former teammate shortly before massacre
 - [http://www.msn.com/en-us/news/us/nashville-school-shooter-messaged-former-teammate-shortly-before-massacre/ar-AA19be1R?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nashville-school-shooter-messaged-former-teammate-shortly-before-massacre/ar-AA19be1R?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 17:15:57.032448+00:00



## EPA pressured for transparency around dioxin testing after Ohio derailment
 - [http://www.msn.com/en-us/news/us/epa-pressured-for-transparency-around-dioxin-testing-after-ohio-derailment/ar-AA19bqsh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/epa-pressured-for-transparency-around-dioxin-testing-after-ohio-derailment/ar-AA19bqsh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 16:16:03.836727+00:00



## Google Products to Expect in 2023: Pixel 8, Pixel Fold and More
 - [http://www.msn.com/en-us/news/technology/google-products-to-expect-in-2023-pixel-8-pixel-fold-and-more/ar-AA19aPFe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/google-products-to-expect-in-2023-pixel-8-pixel-fold-and-more/ar-AA19aPFe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 16:16:03.829529+00:00



## Brueghel work found in dim French TV room sells for $845,000
 - [http://www.msn.com/en-us/news/world/brueghel-work-found-in-dim-french-tv-room-sells-for-845-000/ar-AA19bbwS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/brueghel-work-found-in-dim-french-tv-room-sells-for-845-000/ar-AA19bbwS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 16:16:03.822318+00:00



## Hundreds of deer carcasses dumped in Memphis lot
 - [http://www.msn.com/en-us/news/us/hundreds-of-deer-carcasses-dumped-in-memphis-lot/ar-AA19bj5a?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/hundreds-of-deer-carcasses-dumped-in-memphis-lot/ar-AA19bj5a?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 16:16:03.815087+00:00



## U.S. suspends sharing nuke information with Russia
 - [http://www.msn.com/en-us/news/politics/u-s-suspends-sharing-nuke-information-with-russia/ar-AA19b7ir?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/u-s-suspends-sharing-nuke-information-with-russia/ar-AA19b7ir?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 16:16:03.807861+00:00



## Nashville school shooting updates: Dramatic body camera footage released
 - [http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-dramatic-body-camera-footage-released/ar-AA19ayqt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-dramatic-body-camera-footage-released/ar-AA19ayqt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 16:16:03.800538+00:00



## Women barely tolerated in Irish Defence Forces, says report
 - [http://www.msn.com/en-us/news/world/women-barely-tolerated-in-irish-defence-forces-says-report/ar-AA19bxA5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/women-barely-tolerated-in-irish-defence-forces-says-report/ar-AA19bxA5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 16:16:03.792732+00:00



## Nashville school shooting: Journalists mock prayer, drag show ban after Christian school massacre
 - [http://www.msn.com/en-us/news/us/nashville-school-shooting-journalists-mock-prayer-drag-show-ban-after-christian-school-massacre/ar-AA19bsx7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nashville-school-shooting-journalists-mock-prayer-drag-show-ban-after-christian-school-massacre/ar-AA19bsx7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 16:16:03.784055+00:00



## Diane Marie Brown recommends 5 books to read after 'Black Candle Women'
 - [http://www.msn.com/en-us/news/us/diane-marie-brown-recommends-5-books-to-read-after-black-candle-women/ar-AA19bhXr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/diane-marie-brown-recommends-5-books-to-read-after-black-candle-women/ar-AA19bhXr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 15:15:56.561826+00:00



## Russia convicts and sentences father of teen who drew antiwar pictures
 - [http://www.msn.com/en-us/news/world/russia-convicts-and-sentences-father-of-teen-who-drew-antiwar-pictures/ar-AA19bpIR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-convicts-and-sentences-father-of-teen-who-drew-antiwar-pictures/ar-AA19bpIR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 15:15:56.554543+00:00



## Nashville school shooting victims include pastor's daughter
 - [http://www.msn.com/en-us/news/us/nashville-school-shooting-victims-include-pastor-s-daughter/ar-AA19baAS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nashville-school-shooting-victims-include-pastor-s-daughter/ar-AA19baAS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 15:15:56.547419+00:00



## Nashville school shooting updates: Body camera released as answers sought
 - [http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-body-camera-released-as-answers-sought/ar-AA19ayqt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-body-camera-released-as-answers-sought/ar-AA19ayqt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 15:15:56.540120+00:00



## Giant 700-Pound Bluefin Tuna Breaks Fishing Rod After Two-Hour Struggle
 - [http://www.msn.com/en-us/news/us/giant-700-pound-bluefin-tuna-breaks-fishing-rod-after-two-hour-struggle/ar-AA19aWH1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/giant-700-pound-bluefin-tuna-breaks-fishing-rod-after-two-hour-struggle/ar-AA19aWH1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 15:15:56.533067+00:00



## Biden's Education Department blasts the GOP's new plan to strike down student-loan forgiveness, saying it's a 'shame' for the borrowers who live in their districts
 - [http://www.msn.com/en-us/news/politics/biden-s-education-department-blasts-the-gop-s-new-plan-to-strike-down-student-loan-forgiveness-saying-it-s-a-shame-for-the-borrowers-who-live-in-their-districts/ar-AA19b3wV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-s-education-department-blasts-the-gop-s-new-plan-to-strike-down-student-loan-forgiveness-saying-it-s-a-shame-for-the-borrowers-who-live-in-their-districts/ar-AA19b3wV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 15:15:56.522729+00:00



## Democrats eye plan to force vote on gun reforms over GOP opposition
 - [http://www.msn.com/en-us/news/politics/democrats-eye-plan-to-force-vote-on-gun-reforms-over-gop-opposition/ar-AA19bpOA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/democrats-eye-plan-to-force-vote-on-gun-reforms-over-gop-opposition/ar-AA19bpOA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 15:15:56.514055+00:00



## Rep. Andy Ogles, whose district includes Nashville, criticized over gun-filled Christmas photo
 - [http://www.msn.com/en-us/news/us/rep-andy-ogles-whose-district-includes-nashville-criticized-over-gun-filled-christmas-photo/ar-AA19aLGA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/rep-andy-ogles-whose-district-includes-nashville-criticized-over-gun-filled-christmas-photo/ar-AA19aLGA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 14:15:50.388416+00:00



## Nashville shooting: Covenant School shooter Audrey Hale may have had sense of ‘resentment’ toward school, police chief says
 - [http://www.msn.com/en-us/news/crime/nashville-shooting-covenant-school-shooter-audrey-hale-may-have-had-sense-of-resentment-toward-school-police-chief-says/ar-AA19aOnY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-shooting-covenant-school-shooter-audrey-hale-may-have-had-sense-of-resentment-toward-school-police-chief-says/ar-AA19aOnY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 14:15:50.381122+00:00



## Prince Harry arrives in London court for day two of privacy invasion hearing
 - [http://www.msn.com/en-us/news/world/prince-harry-arrives-in-london-court-for-day-two-of-privacy-invasion-hearing/ar-AA19aTQH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/prince-harry-arrives-in-london-court-for-day-two-of-privacy-invasion-hearing/ar-AA19aTQH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 14:15:50.373937+00:00



## Russia convicts father of teen who drew antiwar pictures
 - [http://www.msn.com/en-us/news/world/russia-convicts-father-of-teen-who-drew-antiwar-pictures/ar-AA19b7MU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-convicts-father-of-teen-who-drew-antiwar-pictures/ar-AA19b7MU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 14:15:50.366175+00:00



## Rep. Andy Ogles, who represents the Nashville district involved in deadly school shooting, posted a gun-toting family photo for Christmas
 - [http://www.msn.com/en-us/news/crime/rep-andy-ogles-who-represents-the-nashville-district-involved-in-deadly-school-shooting-posted-a-gun-toting-family-photo-for-christmas/ar-AA198Uzj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/rep-andy-ogles-who-represents-the-nashville-district-involved-in-deadly-school-shooting-posted-a-gun-toting-family-photo-for-christmas/ar-AA198Uzj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 14:15:50.358514+00:00



## Russia says anti-ship missiles test-fired in Sea of Japan
 - [http://www.msn.com/en-us/news/world/russia-says-anti-ship-missiles-test-fired-in-sea-of-japan/ar-AA19aM25?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-says-anti-ship-missiles-test-fired-in-sea-of-japan/ar-AA19aM25?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 14:15:50.351535+00:00



## Russian father flees jail sentence for criticising army
 - [http://www.msn.com/en-us/news/world/russian-father-flees-jail-sentence-for-criticising-army/ar-AA19aOFq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-father-flees-jail-sentence-for-criticising-army/ar-AA19aOFq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 14:15:50.342426+00:00



## Scotland's 'oldest' tartan found in Highlands bog
 - [http://www.msn.com/en-us/news/world/scotland-s-oldest-tartan-found-in-highlands-bog/ar-AA19aIYd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/scotland-s-oldest-tartan-found-in-highlands-bog/ar-AA19aIYd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 13:15:50.811381+00:00



## Migrants account for ‘upwards of 90%’ of US population growth
 - [http://www.msn.com/en-us/news/us/migrants-account-for-upwards-of-90-of-us-population-growth/ar-AA19aXOB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/migrants-account-for-upwards-of-90-of-us-population-growth/ar-AA19aXOB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 13:15:50.803779+00:00



## Pregnant women in New Jersey ate poppy seeds, then tested positive for opioid drug use: 'Extremely stressful'
 - [http://www.msn.com/en-us/health/health-news/pregnant-women-in-new-jersey-ate-poppy-seeds-then-tested-positive-for-opioid-drug-use-extremely-stressful/ar-AA19aQia?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/pregnant-women-in-new-jersey-ate-poppy-seeds-then-tested-positive-for-opioid-drug-use-extremely-stressful/ar-AA19aQia?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 13:15:50.796420+00:00



## Royal Mail talks over pay on brink of collapse
 - [http://www.msn.com/en-us/news/world/royal-mail-talks-over-pay-on-brink-of-collapse/ar-AA19aBhw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/royal-mail-talks-over-pay-on-brink-of-collapse/ar-AA19aBhw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 13:15:50.789220+00:00



## 39 dead after fire breaks out at migrant detention center in Juarez, Mexico
 - [http://www.msn.com/en-us/news/world/39-dead-after-fire-breaks-out-at-migrant-detention-center-in-juarez-mexico/ar-AA19aD7m?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/39-dead-after-fire-breaks-out-at-migrant-detention-center-in-juarez-mexico/ar-AA19aD7m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 13:15:50.781945+00:00



## Dem AGs clash with Biden admin over abortion pill restrictions
 - [http://www.msn.com/en-us/news/politics/dem-ags-clash-with-biden-admin-over-abortion-pill-restrictions/ar-AA19aNNk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/dem-ags-clash-with-biden-admin-over-abortion-pill-restrictions/ar-AA19aNNk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 13:15:50.774207+00:00



## Watch live: Mayorkas testifies before Senate panel
 - [http://www.msn.com/en-us/news/politics/watch-live-mayorkas-testifies-before-senate-panel/ar-AA19b2lO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/watch-live-mayorkas-testifies-before-senate-panel/ar-AA19b2lO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 13:15:50.765771+00:00



## Mortgage Refinance Rates on March 28, 2023: Rate Rises
 - [http://www.msn.com/en-us/news/technology/mortgage-refinance-rates-on-march-28-2023-rate-rises/ar-AA19aLpV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/mortgage-refinance-rates-on-march-28-2023-rate-rises/ar-AA19aLpV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 13:15:50.758181+00:00



## 'Magical' nails found in a 2,000-year-old Roman tomb were meant to stop the restless dead from haunting the living, archaeologists say
 - [http://www.msn.com/en-us/news/world/magical-nails-found-in-a-2-000-year-old-roman-tomb-were-meant-to-stop-the-restless-dead-from-haunting-the-living-archaeologists-say/ar-AA19aFvG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/magical-nails-found-in-a-2-000-year-old-roman-tomb-were-meant-to-stop-the-restless-dead-from-haunting-the-living-archaeologists-say/ar-AA19aFvG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 12:15:53.601964+00:00



## Belarus State TV Declares 'Nuclear State,' Threatens Two NATO Countries
 - [http://www.msn.com/en-us/news/world/belarus-state-tv-declares-nuclear-state-threatens-two-nato-countries/ar-AA19awod?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/belarus-state-tv-declares-nuclear-state-threatens-two-nato-countries/ar-AA19awod?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 12:15:53.593760+00:00



## Jerry Brown gets a rare beetle species named after him
 - [http://www.msn.com/en-us/news/us/jerry-brown-gets-a-rare-beetle-species-named-after-him/ar-AA19awz0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jerry-brown-gets-a-rare-beetle-species-named-after-him/ar-AA19awz0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 12:15:53.585650+00:00



## There have been more mass shootings than days in 2023, database shows
 - [http://www.msn.com/en-us/news/crime/there-have-been-more-mass-shootings-than-days-in-2023-database-shows/ar-AA16FihC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/there-have-been-more-mass-shootings-than-days-in-2023-database-shows/ar-AA16FihC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 12:15:53.578426+00:00



## Nashville police release surveillance video of school attack
 - [http://www.msn.com/en-us/news/crime/nashville-police-release-surveillance-video-of-school-attack/ar-AA19aI7t?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-police-release-surveillance-video-of-school-attack/ar-AA19aI7t?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 12:15:53.570655+00:00



## Gucci and Bored Ape Creator Want to Take High Fashion to the Metaverse
 - [http://www.msn.com/en-us/news/technology/gucci-and-bored-ape-creator-want-to-take-high-fashion-to-the-metaverse/ar-AA19aS4P?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/gucci-and-bored-ape-creator-want-to-take-high-fashion-to-the-metaverse/ar-AA19aS4P?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 12:15:53.563432+00:00



## Ukraine president extends tour of war’s front-line areas
 - [http://www.msn.com/en-us/news/world/ukraine-president-extends-tour-of-war-s-front-line-areas/ar-AA19aDWI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-president-extends-tour-of-war-s-front-line-areas/ar-AA19aDWI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 12:15:53.556164+00:00



## India can’t find a separatist religious leader, but its manhunt has got the world’s attention
 - [http://www.msn.com/en-us/news/world/india-can-t-find-a-separatist-religious-leader-but-its-manhunt-has-got-the-world-s-attention/ar-AA19aN3y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/india-can-t-find-a-separatist-religious-leader-but-its-manhunt-has-got-the-world-s-attention/ar-AA19aN3y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 12:15:53.548664+00:00



## First foal of the season born at nature reserve
 - [http://www.msn.com/en-us/news/world/first-foal-of-the-season-born-at-nature-reserve/ar-AA19azZk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/first-foal-of-the-season-born-at-nature-reserve/ar-AA19azZk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 11:16:06.710648+00:00



## Nashville police release security footage showing shooter entering school
 - [http://www.msn.com/en-us/news/crime/nashville-police-release-security-footage-showing-shooter-entering-school/ar-AA19aop5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-police-release-security-footage-showing-shooter-entering-school/ar-AA19aop5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 11:16:06.703490+00:00



## China Officials Use Tim Cook Visit To Criticize U.S. Pressure on TikTok
 - [http://www.msn.com/en-us/news/world/china-officials-use-tim-cook-visit-to-criticize-u-s-pressure-on-tiktok/ar-AA19amiU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-officials-use-tim-cook-visit-to-criticize-u-s-pressure-on-tiktok/ar-AA19amiU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 11:16:06.695306+00:00



## Russian soldiers say they were sent into battle with 'blocking' units behind them to stop them retreating
 - [http://www.msn.com/en-us/news/world/russian-soldiers-say-they-were-sent-into-battle-with-blocking-units-behind-them-to-stop-them-retreating/ar-AA19axD1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-soldiers-say-they-were-sent-into-battle-with-blocking-units-behind-them-to-stop-them-retreating/ar-AA19axD1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 11:16:06.687027+00:00



## Official: 39 dead in fire at migrant facility in Mexico
 - [http://www.msn.com/en-us/news/world/official-39-dead-in-fire-at-migrant-facility-in-mexico/ar-AA19am8n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/official-39-dead-in-fire-at-migrant-facility-in-mexico/ar-AA19am8n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 11:16:06.679329+00:00



## The guy behind the viral fake photo of the Pope in a puffy coat says using AI to make images of celebrities 'might be the line' — and calls for greater regulation
 - [http://www.msn.com/en-us/news/world/the-guy-behind-the-viral-fake-photo-of-the-pope-in-a-puffy-coat-says-using-ai-to-make-images-of-celebrities-might-be-the-line-and-calls-for-greater-regulation/ar-AA19aD8y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-guy-behind-the-viral-fake-photo-of-the-pope-in-a-puffy-coat-says-using-ai-to-make-images-of-celebrities-might-be-the-line-and-calls-for-greater-regulation/ar-AA19aD8y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 11:16:06.671327+00:00



## China’s maritime strategy: To own the oceans by adverse possession
 - [http://www.msn.com/en-us/news/politics/china-s-maritime-strategy-to-own-the-oceans-by-adverse-possession/ar-AA19ammL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/china-s-maritime-strategy-to-own-the-oceans-by-adverse-possession/ar-AA19ammL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 11:16:06.664049+00:00



## ChatGPT Is the Wake-Up Call Schools Need to Limit Tech in Classrooms
 - [http://www.msn.com/en-us/news/technology/chatgpt-is-the-wake-up-call-schools-need-to-limit-tech-in-classrooms/ar-AA19amjs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/chatgpt-is-the-wake-up-call-schools-need-to-limit-tech-in-classrooms/ar-AA19amjs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 11:16:06.654275+00:00



## The Right Thing: Parents should support but not do a child's homework for them
 - [http://www.msn.com/en-us/news/us/the-right-thing-parents-should-support-but-not-do-a-child-s-homework-for-them/ar-AA19a6wv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-right-thing-parents-should-support-but-not-do-a-child-s-homework-for-them/ar-AA19a6wv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 10:15:52.954335+00:00



## Lawmakers: Expand federal aid for hungry troops
 - [http://www.msn.com/en-us/news/politics/lawmakers-expand-federal-aid-for-hungry-troops/ar-AA19ajTQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lawmakers-expand-federal-aid-for-hungry-troops/ar-AA19ajTQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 10:15:52.945626+00:00



## The House GOP’s investigations are flopping
 - [http://www.msn.com/en-us/news/politics/the-house-gop-s-investigations-are-flopping/ar-AA19abHm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-house-gop-s-investigations-are-flopping/ar-AA19abHm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 10:15:52.938408+00:00



## Senate holds its first hearing into SVB and Signature Bank failures
 - [http://www.msn.com/en-us/news/politics/senate-holds-its-first-hearing-into-svb-and-signature-bank-failures/ar-AA19auB6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-holds-its-first-hearing-into-svb-and-signature-bank-failures/ar-AA19auB6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 10:15:52.930314+00:00



## Dangers of fentanyl escalate US-Mexico tensions
 - [http://www.msn.com/en-us/news/politics/dangers-of-fentanyl-escalate-us-mexico-tensions/ar-AA19ae20?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/dangers-of-fentanyl-escalate-us-mexico-tensions/ar-AA19ae20?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 10:15:52.923025+00:00



## This state just reclaimed the school choice crown
 - [http://www.msn.com/en-us/news/us/this-state-just-reclaimed-the-school-choice-crown/ar-AA19a4hF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/this-state-just-reclaimed-the-school-choice-crown/ar-AA19a4hF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 10:15:52.915134+00:00



## Freed 'Hotel Rwanda' hero in Qatar, heading to family in US
 - [http://www.msn.com/en-us/news/world/freed-hotel-rwanda-hero-in-qatar-heading-to-family-in-us/ar-AA19anPn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/freed-hotel-rwanda-hero-in-qatar-heading-to-family-in-us/ar-AA19anPn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 10:15:52.907807+00:00



## Antigua wants to quickly auction off an 'abandoned' superyacht linked to a Russian oligarch after it ran up a $500,000 bill for fuel and food
 - [http://www.msn.com/en-us/news/world/antigua-wants-to-quickly-auction-off-an-abandoned-superyacht-linked-to-a-russian-oligarch-after-it-ran-up-a-500-000-bill-for-fuel-and-food/ar-AA19all5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/antigua-wants-to-quickly-auction-off-an-abandoned-superyacht-linked-to-a-russian-oligarch-after-it-ran-up-a-500-000-bill-for-fuel-and-food/ar-AA19all5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 10:15:52.899797+00:00



## A GOP Chairman’s Tricky Hypocrisy on ‘Political’ Probes
 - [http://www.msn.com/en-us/news/politics/a-gop-chairman-s-tricky-hypocrisy-on-political-probes/ar-AA19aijg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/a-gop-chairman-s-tricky-hypocrisy-on-political-probes/ar-AA19aijg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 09:15:50.123933+00:00



## Biden tries to halt Democrats' slide with the working class ahead of 2024
 - [http://www.msn.com/en-us/news/politics/biden-tries-to-halt-democrats-slide-with-the-working-class-ahead-of-2024/ar-AA199OGU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-tries-to-halt-democrats-slide-with-the-working-class-ahead-of-2024/ar-AA199OGU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 09:15:50.116739+00:00



## Mustangs Shooting Sees Multiple People Gunned Down Inside Adult Club
 - [http://www.msn.com/en-us/news/crime/mustangs-shooting-sees-multiple-people-gunned-down-inside-adult-club/ar-AA19aivi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/mustangs-shooting-sees-multiple-people-gunned-down-inside-adult-club/ar-AA19aivi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 09:15:50.109424+00:00



## Start-ups with strong basics will get funds: Vinod Khosla
 - [http://www.msn.com/en-us/news/world/start-ups-with-strong-basics-will-get-funds-vinod-khosla/ar-AA19aaMP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/start-ups-with-strong-basics-will-get-funds-vinod-khosla/ar-AA19aaMP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 09:15:50.101851+00:00



## Before releasing GPT-4, OpenAI's 'red team' asked the ChatGPT model how to murder people, build a bomb, and say antisemitic things. Read the chatbot's shocking answers.
 - [http://www.msn.com/en-us/news/technology/before-releasing-gpt-4-openai-s-red-team-asked-the-chatgpt-model-how-to-murder-people-build-a-bomb-and-say-antisemitic-things-read-the-chatbot-s-shocking-answers/ar-AA19apkg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/before-releasing-gpt-4-openai-s-red-team-asked-the-chatgpt-model-how-to-murder-people-build-a-bomb-and-say-antisemitic-things-read-the-chatbot-s-shocking-answers/ar-AA19apkg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 09:15:50.093269+00:00



## Biden to warn private sector investments at stake under GOP proposals
 - [http://www.msn.com/en-us/news/politics/biden-to-warn-private-sector-investments-at-stake-under-gop-proposals/ar-AA19a8Ry?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-to-warn-private-sector-investments-at-stake-under-gop-proposals/ar-AA19a8Ry?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 09:15:50.085520+00:00



## ‘Lawless’ Haiti plagued by corruption, and deadly gang violence fuels humanitarian crisis
 - [http://www.msn.com/en-us/news/world/lawless-haiti-plagued-by-corruption-and-deadly-gang-violence-fuels-humanitarian-crisis/ar-AA19akEy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/lawless-haiti-plagued-by-corruption-and-deadly-gang-violence-fuels-humanitarian-crisis/ar-AA19akEy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 09:15:50.078354+00:00



## France braces for violence in new wave of pension protests
 - [http://www.msn.com/en-us/news/world/france-braces-for-violence-in-new-wave-of-pension-protests/ar-AA19ag3L?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/france-braces-for-violence-in-new-wave-of-pension-protests/ar-AA19ag3L?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 09:15:50.070769+00:00



## Key Republican says House GOP border bill is 'absolutely dead'
 - [http://www.msn.com/en-us/news/politics/key-republican-says-house-gop-border-bill-is-absolutely-dead/ar-AA199O38?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/key-republican-says-house-gop-border-bill-is-absolutely-dead/ar-AA199O38?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 08:15:50.639263+00:00



## Ron DeSantis Pushes School Vouchers Up Culture War Agenda
 - [http://www.msn.com/en-us/news/us/ron-desantis-pushes-school-vouchers-up-culture-war-agenda/ar-AA19a7x1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/ron-desantis-pushes-school-vouchers-up-culture-war-agenda/ar-AA19a7x1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 08:15:50.630224+00:00



## Forget the latest polls: A state marathon could boost DeSantis against Trump
 - [http://www.msn.com/en-us/news/politics/forget-the-latest-polls-a-state-marathon-could-boost-desantis-against-trump/ar-AA199GTr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/forget-the-latest-polls-a-state-marathon-could-boost-desantis-against-trump/ar-AA199GTr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 08:15:50.622531+00:00



## The moon could have up to 297 billion tons of water stored in tiny glass beads on its surface, scientists say
 - [http://www.msn.com/en-us/news/technology/the-moon-could-have-up-to-297-billion-tons-of-water-stored-in-tiny-glass-beads-on-its-surface-scientists-say/ar-AA199ZZ5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-moon-could-have-up-to-297-billion-tons-of-water-stored-in-tiny-glass-beads-on-its-surface-scientists-say/ar-AA199ZZ5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 08:15:50.614802+00:00



## Israel Latest: Uproar Eases As Leaders Prepare for Talks
 - [http://www.msn.com/en-us/news/world/israel-latest-uproar-eases-as-leaders-prepare-for-talks/ar-AA199V4Q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-latest-uproar-eases-as-leaders-prepare-for-talks/ar-AA199V4Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 08:15:50.607515+00:00



## Former Taiwan leader Ma views Sun Yat-sen tomb in China tour
 - [http://www.msn.com/en-us/news/world/former-taiwan-leader-ma-views-sun-yat-sen-tomb-in-china-tour/ar-AA19a05m?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/former-taiwan-leader-ma-views-sun-yat-sen-tomb-in-china-tour/ar-AA19a05m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 08:15:50.599712+00:00



## Alibaba founder Jack Ma resurfaces in China in sign tech crackdown may be easing
 - [http://www.msn.com/en-us/news/world/alibaba-founder-jack-ma-resurfaces-in-china-in-sign-tech-crackdown-may-be-easing/ar-AA19aa32?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/alibaba-founder-jack-ma-resurfaces-in-china-in-sign-tech-crackdown-may-be-easing/ar-AA19aa32?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 08:15:50.591767+00:00



## Buster Murdaugh and Stephen Smith homicide investigation includes these 5 things to know
 - [http://www.msn.com/en-us/news/crime/buster-murdaugh-and-stephen-smith-homicide-investigation-includes-these-5-things-to-know/ar-AA199X43?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/buster-murdaugh-and-stephen-smith-homicide-investigation-includes-these-5-things-to-know/ar-AA199X43?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 07:15:40.693661+00:00



## Taliban arrests Afghan girls' education activist
 - [http://www.msn.com/en-us/news/world/taliban-arrests-afghan-girls-education-activist/ar-AA19a1T0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/taliban-arrests-afghan-girls-education-activist/ar-AA19a1T0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 07:15:40.685471+00:00



## Alone Australia ate over 10,000 calories a day to prep for show
 - [http://www.msn.com/en-us/news/world/alone-australia-ate-over-10-000-calories-a-day-to-prep-for-show/ar-AA19a73E?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/alone-australia-ate-over-10-000-calories-a-day-to-prep-for-show/ar-AA19a73E?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 07:15:40.678338+00:00



## Ron DeSantis is facing another ethics complaint — this time accusing him of accepting a $235,000, 3-day retreat to the Four Seasons Palm Beach
 - [http://www.msn.com/en-us/news/politics/ron-desantis-is-facing-another-ethics-complaint-this-time-accusing-him-of-accepting-a-235-000-3-day-retreat-to-the-four-seasons-palm-beach/ar-AA199TaQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ron-desantis-is-facing-another-ethics-complaint-this-time-accusing-him-of-accepting-a-235-000-3-day-retreat-to-the-four-seasons-palm-beach/ar-AA199TaQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 07:15:40.670753+00:00



## Feel the Force: Hamill carries 'Star Wars' voice to Ukraine
 - [http://www.msn.com/en-us/news/world/feel-the-force-hamill-carries-star-wars-voice-to-ukraine/ar-AA19a4vm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/feel-the-force-hamill-carries-star-wars-voice-to-ukraine/ar-AA19a4vm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 07:15:40.661979+00:00



## Israel Latest: President Urges Netanyahu to Talk to Rivals
 - [http://www.msn.com/en-us/news/world/israel-latest-president-urges-netanyahu-to-talk-to-rivals/ar-AA199V4Q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-latest-president-urges-netanyahu-to-talk-to-rivals/ar-AA199V4Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 07:15:40.654726+00:00



## Killer drones and multi-billion dollar deals: Turkey's rapidly-growing defense industry is boosting its global clout
 - [http://www.msn.com/en-us/news/world/killer-drones-and-multi-billion-dollar-deals-turkey-s-rapidly-growing-defense-industry-is-boosting-its-global-clout/ar-AA199GFl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/killer-drones-and-multi-billion-dollar-deals-turkey-s-rapidly-growing-defense-industry-is-boosting-its-global-clout/ar-AA199GFl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 07:15:40.646366+00:00



## Israel Latest: Protests Overnight, President Urges Talks
 - [http://www.msn.com/en-us/news/world/israel-latest-protests-overnight-president-urges-talks/ar-AA199V4Q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-latest-protests-overnight-president-urges-talks/ar-AA199V4Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 06:15:48.251192+00:00



## Government will examine airport expansion plans
 - [http://www.msn.com/en-us/news/world/government-will-examine-airport-expansion-plans/ar-AA199wiu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/government-will-examine-airport-expansion-plans/ar-AA199wiu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 06:15:48.242873+00:00



## Nashville school shooting: Officers who took out suspected Covenant shooter identified
 - [http://www.msn.com/en-us/news/crime/nashville-school-shooting-officers-who-took-out-suspected-covenant-shooter-identified/ar-AA199WTW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-school-shooting-officers-who-took-out-suspected-covenant-shooter-identified/ar-AA199WTW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 06:15:48.235613+00:00



## Harris to pledge support for African innovation in Ghana
 - [http://www.msn.com/en-us/news/us/harris-to-pledge-support-for-african-innovation-in-ghana/ar-AA19a1OD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/harris-to-pledge-support-for-african-innovation-in-ghana/ar-AA19a1OD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 06:15:48.227422+00:00



## Russia says it test-fired anti-ship missiles in Sea of Japan
 - [http://www.msn.com/en-us/news/world/russia-says-it-test-fired-anti-ship-missiles-in-sea-of-japan/ar-AA199HvX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-says-it-test-fired-anti-ship-missiles-in-sea-of-japan/ar-AA199HvX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 05:15:49.862403+00:00



## Only one-quarter of Democrats want Biden to run in 2024: Poll
 - [http://www.msn.com/en-us/news/politics/only-one-quarter-of-democrats-want-biden-to-run-in-2024-poll/ar-AA199UfK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/only-one-quarter-of-democrats-want-biden-to-run-in-2024-poll/ar-AA199UfK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 05:15:49.855158+00:00



## In his return to Fox News, Trump labels Manhattan DA probe a 'new way of cheating in elections'
 - [http://www.msn.com/en-us/news/politics/in-his-return-to-fox-news-trump-labels-manhattan-da-probe-a-new-way-of-cheating-in-elections/ar-AA199KlM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/in-his-return-to-fox-news-trump-labels-manhattan-da-probe-a-new-way-of-cheating-in-elections/ar-AA199KlM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 05:15:49.847921+00:00



## Maddow Roasts Trump ‘Pollster’ Named After Feline Excrement
 - [http://www.msn.com/en-us/news/politics/maddow-roasts-trump-pollster-named-after-feline-excrement/ar-AA199Kru?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/maddow-roasts-trump-pollster-named-after-feline-excrement/ar-AA199Kru?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 05:15:49.840659+00:00



## LAURA INGRAHAM: This killer's identity didn't match the media's 'preferred criteria'
 - [http://www.msn.com/en-us/news/crime/laura-ingraham-this-killer-s-identity-didn-t-match-the-media-s-preferred-criteria/ar-AA199S5U?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/laura-ingraham-this-killer-s-identity-didn-t-match-the-media-s-preferred-criteria/ar-AA199S5U?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 05:15:49.832743+00:00



## A mysterious shoe with a severed human foot still in it has washed up on a beach in New Zealand
 - [http://www.msn.com/en-us/news/world/a-mysterious-shoe-with-a-severed-human-foot-still-in-it-has-washed-up-on-a-beach-in-new-zealand/ar-AA199N4n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-mysterious-shoe-with-a-severed-human-foot-still-in-it-has-washed-up-on-a-beach-in-new-zealand/ar-AA199N4n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 05:15:49.825471+00:00



## Jim Jordan demands answers on low ICE deportations
 - [http://www.msn.com/en-us/news/us/jim-jordan-demands-answers-on-low-ice-deportations/ar-AA199AH7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jim-jordan-demands-answers-on-low-ice-deportations/ar-AA199AH7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 04:15:51.667753+00:00



## Trump says he was not a ‘big fan’ of Fed Chair Jerome Powell and ‘beat the hell out of him’
 - [http://www.msn.com/en-us/news/politics/trump-says-he-was-not-a-big-fan-of-fed-chair-jerome-powell-and-beat-the-hell-out-of-him/ar-AA199AwQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-says-he-was-not-a-big-fan-of-fed-chair-jerome-powell-and-beat-the-hell-out-of-him/ar-AA199AwQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 04:15:51.658452+00:00



## Former doctor gives teary testimony on Day 5 of the Gwyneth Paltrow ski-collision trial
 - [http://www.msn.com/en-us/news/crime/former-doctor-gives-teary-testimony-on-day-5-of-the-gwyneth-paltrow-ski-collision-trial/ar-AA199oEo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/former-doctor-gives-teary-testimony-on-day-5-of-the-gwyneth-paltrow-ski-collision-trial/ar-AA199oEo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 04:15:51.650348+00:00



## House GOP to subpoena Blinken over Afghanistan dissent cable
 - [http://www.msn.com/en-us/news/politics/house-gop-to-subpoena-blinken-over-afghanistan-dissent-cable/ar-AA199AHh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-gop-to-subpoena-blinken-over-afghanistan-dissent-cable/ar-AA199AHh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 04:15:51.642286+00:00



## Florida Sheriff Expertly Trolls ‘Nutball’ Charged With Threatening Him
 - [http://www.msn.com/en-us/news/crime/florida-sheriff-expertly-trolls-nutball-charged-with-threatening-him/ar-AA199RwM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/florida-sheriff-expertly-trolls-nutball-charged-with-threatening-him/ar-AA199RwM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 04:15:51.634065+00:00



## Google Asks Judge to Dismiss DOJ’s Digital Ad Antitrust Case
 - [http://www.msn.com/en-us/news/technology/google-asks-judge-to-dismiss-doj-s-digital-ad-antitrust-case/ar-AA199j48?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/google-asks-judge-to-dismiss-doj-s-digital-ad-antitrust-case/ar-AA199j48?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 03:15:51.031676+00:00



## Sen. Rand Paul staffer stabbed multiple times in DC, suspect arrested
 - [http://www.msn.com/en-us/news/crime/sen-rand-paul-staffer-stabbed-multiple-times-in-dc-suspect-arrested/ar-AA199jbv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/sen-rand-paul-staffer-stabbed-multiple-times-in-dc-suspect-arrested/ar-AA199jbv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 03:15:51.024748+00:00



## FBI Releases First Trove of Its Top Secret Ivana Trump Docs
 - [http://www.msn.com/en-us/news/politics/fbi-releases-first-trove-of-its-top-secret-ivana-trump-docs/ar-AA199lSa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fbi-releases-first-trove-of-its-top-secret-ivana-trump-docs/ar-AA199lSa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 03:15:51.016989+00:00



## TUCKER CARLSON: This is about introducing flat out totalitarianism into our system
 - [http://www.msn.com/en-us/news/us/tucker-carlson-this-is-about-introducing-flat-out-totalitarianism-into-our-system/ar-AA199BYO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tucker-carlson-this-is-about-introducing-flat-out-totalitarianism-into-our-system/ar-AA199BYO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 03:15:51.009436+00:00



## What I learnt searching for my roots in a cemetery
 - [http://www.msn.com/en-us/news/world/what-i-learnt-searching-for-my-roots-in-a-cemetery/ar-AA199bEv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/what-i-learnt-searching-for-my-roots-in-a-cemetery/ar-AA199bEv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 03:15:51.002445+00:00



## White House sees Netanyahu likely abandoning judicial overhaul to pursue compromise
 - [http://www.msn.com/en-us/news/politics/white-house-sees-netanyahu-likely-abandoning-judicial-overhaul-to-pursue-compromise/ar-AA199uZA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/white-house-sees-netanyahu-likely-abandoning-judicial-overhaul-to-pursue-compromise/ar-AA199uZA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 03:15:50.994690+00:00



## Kim wants N. Korea to make more nuclear material for bombs
 - [http://www.msn.com/en-us/news/world/kim-wants-n-korea-to-make-more-nuclear-material-for-bombs/ar-AA199jm6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/kim-wants-n-korea-to-make-more-nuclear-material-for-bombs/ar-AA199jm6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 03:15:50.986617+00:00



## Trump says DeSantis endorsement was ‘nuclear weapon,’ could be working in a pizza parlor without it
 - [http://www.msn.com/en-us/news/politics/trump-says-desantis-endorsement-was-nuclear-weapon-could-be-working-in-a-pizza-parlor-without-it/ar-AA199bGe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-says-desantis-endorsement-was-nuclear-weapon-could-be-working-in-a-pizza-parlor-without-it/ar-AA199bGe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 03:15:50.978652+00:00



## Shooting at Nashville Christian school leaves 3 children and 3 adults dead, officials say
 - [http://www.msn.com/en-us/news/us/shooting-at-nashville-christian-school-leaves-3-children-and-3-adults-dead-officials-say/ar-AA198Ess?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/shooting-at-nashville-christian-school-leaves-3-children-and-3-adults-dead-officials-say/ar-AA198Ess?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 02:15:44.292442+00:00



## Doctor decries gun violence after school shooting near miss
 - [http://www.msn.com/en-us/news/us/doctor-decries-gun-violence-after-school-shooting-near-miss/ar-AA199ztC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/doctor-decries-gun-violence-after-school-shooting-near-miss/ar-AA199ztC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 02:15:44.283639+00:00



## Texas scientists name newly discovered ancient beaver after Buc-ee’s, the state's wildly popular rest stop
 - [http://www.msn.com/en-us/news/technology/texas-scientists-name-newly-discovered-ancient-beaver-after-buc-ee-s-the-state-s-wildly-popular-rest-stop/ar-AA199zvJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/texas-scientists-name-newly-discovered-ancient-beaver-after-buc-ee-s-the-state-s-wildly-popular-rest-stop/ar-AA199zvJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 02:15:44.275424+00:00



## McCaul subpoenas State Department for Kabul dissent cable
 - [http://www.msn.com/en-us/news/politics/mccaul-subpoenas-state-department-for-kabul-dissent-cable/ar-AA199lFe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccaul-subpoenas-state-department-for-kabul-dissent-cable/ar-AA199lFe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 02:15:44.268218+00:00



## Christie sees a lane in the GOP primary: Trump destroyer
 - [http://www.msn.com/en-us/news/politics/christie-sees-a-lane-in-the-gop-primary-trump-destroyer/ar-AA199sC9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/christie-sees-a-lane-in-the-gop-primary-trump-destroyer/ar-AA199sC9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 02:15:44.260921+00:00



## ‘Equality is overdue’: Congressional Black women lead fight for ERA as 28th Amendment
 - [http://www.msn.com/en-us/news/politics/equality-is-overdue-congressional-black-women-lead-fight-for-era-as-28th-amendment/ar-AA1996sc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/equality-is-overdue-congressional-black-women-lead-fight-for-era-as-28th-amendment/ar-AA1996sc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 02:15:44.253301+00:00



## Nashville school shooting updates: Cops say attack was targeted
 - [http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-cops-say-attack-was-targeted/ar-AA198cRO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-cops-say-attack-was-targeted/ar-AA198cRO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 01:15:44.180176+00:00



## Nashville Christian school shooter was a former student, police chief says
 - [http://www.msn.com/en-us/news/crime/nashville-christian-school-shooter-was-a-former-student-police-chief-says/ar-AA198UUu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-christian-school-shooter-was-a-former-student-police-chief-says/ar-AA198UUu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 01:15:44.172681+00:00



## Republicans' AR-15 Lapel Pins Slammed in Wake of Nashville School Shooting
 - [http://www.msn.com/en-us/news/us/republicans-ar-15-lapel-pins-slammed-in-wake-of-nashville-school-shooting/ar-AA199nhI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/republicans-ar-15-lapel-pins-slammed-in-wake-of-nashville-school-shooting/ar-AA199nhI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 01:15:44.165160+00:00



## Russia warns Armenia against siding with ICC after Putin arrest warrant: 'serious consequences'
 - [http://www.msn.com/en-us/news/world/russia-warns-armenia-against-siding-with-icc-after-putin-arrest-warrant-serious-consequences/ar-AA199wCZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-warns-armenia-against-siding-with-icc-after-putin-arrest-warrant-serious-consequences/ar-AA199wCZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 01:15:44.157776+00:00



## Christie: GOP needs someone who can quickly take down Trump
 - [http://www.msn.com/en-us/news/politics/christie-gop-needs-someone-who-can-quickly-take-down-trump/ar-AA199uaJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/christie-gop-needs-someone-who-can-quickly-take-down-trump/ar-AA199uaJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 01:15:44.149049+00:00



## Philadelphia residents are snatching up bottled water after 8,100 gallons of toxic chemicals spilled into the Delaware River
 - [http://www.msn.com/en-us/news/us/philadelphia-residents-are-snatching-up-bottled-water-after-8-100-gallons-of-toxic-chemicals-spilled-into-the-delaware-river/ar-AA199ueC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/philadelphia-residents-are-snatching-up-bottled-water-after-8-100-gallons-of-toxic-chemicals-spilled-into-the-delaware-river/ar-AA199ueC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 01:15:44.141127+00:00



## Madonna adds Tennessee tour stop to protest anti-LGBTQ+ legislation
 - [http://www.msn.com/en-us/news/politics/madonna-adds-tennessee-tour-stop-to-protest-anti-lgbtq-legislation/ar-AA199sel?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/madonna-adds-tennessee-tour-stop-to-protest-anti-lgbtq-legislation/ar-AA199sel?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 01:15:44.133678+00:00



## 9-Year-Old Nashville Shooting Victim’s Father Is School’s Pastor
 - [http://www.msn.com/en-us/news/crime/9-year-old-nashville-shooting-victim-s-father-is-school-s-pastor/ar-AA199pnt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/9-year-old-nashville-shooting-victim-s-father-is-school-s-pastor/ar-AA199pnt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 01:15:44.124921+00:00



## Chilling photos taken over a decade apart show nearly-identical lines of kids evacuating in Nashville and Sandy Hook after deadly school shootings
 - [http://www.msn.com/en-us/news/crime/chilling-photos-taken-over-a-decade-apart-show-nearly-identical-lines-of-kids-evacuating-in-nashville-and-sandy-hook-after-deadly-school-shootings/ar-AA1993zB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/chilling-photos-taken-over-a-decade-apart-show-nearly-identical-lines-of-kids-evacuating-in-nashville-and-sandy-hook-after-deadly-school-shootings/ar-AA1993zB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 00:11:24.196723+00:00



## Jackie 'O' Henderson rocked by a robbery at her $13million home
 - [http://www.msn.com/en-us/news/crime/jackie-o-henderson-rocked-by-a-robbery-at-her-13million-home/ar-AA199fuB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/jackie-o-henderson-rocked-by-a-robbery-at-her-13million-home/ar-AA199fuB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 00:11:24.188660+00:00



## State, defense request another stay of execution for Glossip
 - [http://www.msn.com/en-us/news/crime/state-defense-request-another-stay-of-execution-for-glossip/ar-AA199fm1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/state-defense-request-another-stay-of-execution-for-glossip/ar-AA199fm1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 00:11:24.181376+00:00



## After Nashville, Let’s Admit Drag and Books Were Never the Real Threat to Kids
 - [http://www.msn.com/en-us/news/us/after-nashville-let-s-admit-drag-and-books-were-never-the-real-threat-to-kids/ar-AA1995H8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/after-nashville-let-s-admit-drag-and-books-were-never-the-real-threat-to-kids/ar-AA1995H8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 00:11:24.174380+00:00



## The Yahoo News Interview: John Kerry
 - [http://www.msn.com/en-us/news/politics/the-yahoo-news-interview-john-kerry/ar-AA199aGF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-yahoo-news-interview-john-kerry/ar-AA199aGF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 00:11:24.165081+00:00



## Possible TikTok ban raises alarm for Democrats ahead of 2024
 - [http://www.msn.com/en-us/news/politics/possible-tiktok-ban-raises-alarm-for-democrats-ahead-of-2024/ar-AA199aId?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/possible-tiktok-ban-raises-alarm-for-democrats-ahead-of-2024/ar-AA199aId?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 00:11:24.152049+00:00



## Reporter covering Nashville school shooting makes stunning on-air announcement: ‘I am a survivor’
 - [http://www.msn.com/en-us/news/crime/reporter-covering-nashville-school-shooting-makes-stunning-on-air-announcement-i-am-a-survivor/ar-AA199rKj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/reporter-covering-nashville-school-shooting-makes-stunning-on-air-announcement-i-am-a-survivor/ar-AA199rKj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-28 00:11:24.139147+00:00



