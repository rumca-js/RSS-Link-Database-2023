# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Why Does Every Animal Look Like This?
 - [https://www.youtube.com/watch?v=0ZhbURd6xvU](https://www.youtube.com/watch?v=0ZhbURd6xvU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2023-03-28 14:33:42+00:00

Thank you to Brilliant for supporting PBS
To learn more, go to: https://brilliant.org/BeSmart/
↓↓↓ More info and sources below ↓↓↓

In the race to survive, both predators and prey use visual tricks to get ahead. One nearly universal trick is countershading, a color pattern that helps animals erase their own shadows or blend into different backgrounds. It’s worked well enough that nature has produced this pattern over and over again, all over Earth, for at least tens of millions of years.

0:00 Why does every animal look like this?
0:52 A painter's big idea
1:49 Disappearing shadows
2:22 Testing the idea
3:48 Countershading everywhere!
6:10 What about water?
7:22 Making light to hide shadows
8:19 Outro

References: https://sites.google.com/view/countershading-references/home

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart

-----------

High fives to all our Brain Trust Patrons:

Millennial Glacier
paul andre bouis
Mark Littlehale
Ali Freiburger
Mehdi Damou
Barbora Bei
Burt Humburg
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Eric Meer
Dustin
Karen Haskell


Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/ 

This episode of Be Smart is licensed exclusively to YouTube.

