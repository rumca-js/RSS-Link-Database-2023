# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Chińczycy podłączyli elektrownie wodorowe do sieci. To przełomowe osiągnięcie w historii tego kraju
 - [https://www.chip.pl/2023/03/elektrownie-wodorowe-podlaczone-do-sieci-chiny](https://www.chip.pl/2023/03/elektrownie-wodorowe-podlaczone-do-sieci-chiny)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 19:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="688" src="https://konto.chip.pl/wp-content/uploads/2023/03/siec-energetyczna.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/siec-energetyczna.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Z Państwa Środka napływają wieści, jakoby tamtejsza China Southern Power Grid zaczęła wykorzystywać stały wodór do wytwarzania energii elektrycznej w dwóch elektrowniach. Pierwsza z nich, Nansha Smart Hydrogen Station, znajduje się w mieście Guangzhou w prowincji Guangdong na południu Chin. W jej skład wchodzi siedem magazynów służących do przechowywania stałego wodoru. Z kolei druga placówka, [&#8230;]</p>

## Vivo X Fold 2 ma szansę dotrzeć do Europy. Samsung już  powinien szykować się na ostrą konkurencję
 - [https://www.chip.pl/2023/03/vivo-x-fold-2-specyfikacja-wyglad-data-premiery](https://www.chip.pl/2023/03/vivo-x-fold-2-specyfikacja-wyglad-data-premiery)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 18:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="684" src="https://konto.chip.pl/wp-content/uploads/2022/04/vivo-x-fold-premiera-1.jpg" style="margin-bottom: 10px;" width="1200" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/04/vivo-x-fold-premiera-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Vivo intensywnie pracuje nad rozszerzeniem swojej oferty składanych urządzeń. Firma ma na swoim koncie już dwa takie smartfony – X Fold i X Fold + &#8211; a w przygotowaniach są kolejne dwa, w tym również model z klapką. Dzisiaj jednak przyjrzymy się bliżej Vivo X Fold 2, bo jest szansa, że zobaczymy go na europejskim [&#8230;]</p>

## O takich planetach się filozofom nie śniło. Badacze natrafili na coś dziwnego
 - [https://www.chip.pl/2023/03/ciemne-egzoplanety](https://www.chip.pl/2023/03/ciemne-egzoplanety)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 17:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/03/ciemna-egzoplaneta.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/ciemna-egzoplaneta.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jeszcze trzy dekady temu naukowcy nie mieli żadnych dowodów na to, że wokół innych gwiazd we wszechświecie także krążą jakieś planety. Część naukowców była przekonana, że planety powszechnie występują w przestrzeni kosmicznej, a część podchodziła do tego twierdzenia z rezerwą dopuszczając możliwość tego, że Układ Słoneczny jest ewenementem. Dzięki niestrudzonym astronomom, na początku jak dwudziestych [&#8230;]</p>

## Pogódźmy się z faktem, że smartfony będą tylko droższe. Jak chcesz kupić tanio, kupuj teraz
 - [https://www.chip.pl/2023/03/smartfony-beda-drozsze-arm-zmienia-model-licencjonowania](https://www.chip.pl/2023/03/smartfony-beda-drozsze-arm-zmienia-model-licencjonowania)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 16:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1281" src="https://konto.chip.pl/wp-content/uploads/2023/03/jaki-smartfon-wybrac-maly-smartfon-2023-2.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/jaki-smartfon-wybrac-maly-smartfon-2023-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Gdzie nie spojrzeć, tam widać podwyżki cen. Drożeje żywność i usługi, drożeje też elektronika – w tym smartfony &#8211; i czy tego chcemy, czy nie, ten stan rzeczy będzie się utrzymywał jeszcze przez dłuższy czas. Jeśli więc przymierzacie się do kupna nowego smartfona, lepiej zróbcie to teraz. Później będzie tylko gorzej. Tanio to już było [&#8230;]</p>

## Smartfony z Androidem będą szybsze, tylko… co z tego, skoro iPhone i tak będzie działał lepiej?
 - [https://www.chip.pl/2023/03/smartfony-z-androidem-beda-wydajniejsze-snapdragon-8-gen-4-apple](https://www.chip.pl/2023/03/smartfony-z-androidem-beda-wydajniejsze-snapdragon-8-gen-4-apple)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 15:47:40+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1200" src="https://konto.chip.pl/wp-content/uploads/2023/03/oneplus-11-5g-chip-10.jpg" style="margin-bottom: 10px;" width="1800" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/oneplus-11-5g-chip-10.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Qualcomm Snapdragon 8 Gen 4 ma znacznie przebijać układy Apple pod względem wydajności. Co oznacza, że smartfony z Androidem będą jeszcze wydajniejsze, tylko&#8230; czy komuś jest to potrzebne? Qualcomm Snapdragon 8 Gen 4 z własnymi rdzeniami Oryon W tym materiale mocno wybiegamy w przyszłość, bo Qualcomm dopiero szykuje się do premiery Snapdragona 8 Gen 3. [&#8230;]</p>

## Sprawdziłem Apple Music Classical. Za darmo to uczciwa cena
 - [https://www.chip.pl/2023/03/apple-music-classical-opinie-test](https://www.chip.pl/2023/03/apple-music-classical-opinie-test)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 14:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1281" src="https://konto.chip.pl/wp-content/uploads/2023/03/apple-music-classical-opinie-3.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/apple-music-classical-opinie-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Apple Music Classical jest już dostępne do pobrania dla każdego, kto posiada iPhone’a i opłaca abonament Apple One lub subskrybuje serwis Apple Music. Sprawdziłem tę aplikację i jestem w szoku, bo tak niedopracowanego produktu Gigant z Cupertino nie wypuścił od lat. To powinna być beta. Trzeba to powiedzieć na samym początku tego tekstu. Apple ogłosił [&#8230;]</p>

## Co potrafią współczesne ekspresy do kawy? Niektóre rzeczy robią lepiej niż profesjonalny barista
 - [https://www.chip.pl/2023/03/nivona-jaki-ekspres-do-kawy-wybrac-przyjaciele-kawy](https://www.chip.pl/2023/03/nivona-jaki-ekspres-do-kawy-wybrac-przyjaciele-kawy)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 13:52:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1032" src="https://konto.chip.pl/wp-content/uploads/2023/03/kawa-333.jpg" style="margin-bottom: 10px;" width="1552" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/kawa-333.jpg" style="display: block; margin: 1em auto;" /></p>
<p>W dzisiejszych czasach obserwujemy rozwój technologiczny postępujący na większą skalę niż kiedykolwiek wcześniej w historii ludzkości. Z roku na rok technologia potrafi coraz więcej i zastępuje nas w coraz większej liczbie czynności. Rzecz jasna ma to swoje pozytywne, jak i negatywne skutki. Do tych pierwszych z pewnością zaliczyć można zastąpienie nas przez maszyny w czynnościach [&#8230;]</p>

## Zakaz sprzedaży aut spalinowych przegłosowany. Sprzeciw Polaków nie pomógł, elektryki zwyciężyły
 - [https://www.chip.pl/2023/03/zakaz-sprzedazy-aut-spalinowych-2035-przeglosowane](https://www.chip.pl/2023/03/zakaz-sprzedazy-aut-spalinowych-2035-przeglosowane)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 13:49:14+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/03/tesla-model-y-zakaz-sprzedazy-aut-spalinowych.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/tesla-model-y-zakaz-sprzedazy-aut-spalinowych.jpg" style="display: block; margin: 1em auto;" /></p>
<p>No i pozamiatane. Nie pomogło tupanie nóżką polityków z Polski, nie pomogły sojusze Niemiec z innymi krajami. Unia Europejska właśnie przegłosowała zakaz sprzedaży samochodów spalinowych od 2035 roku. Jak donosi Reuters, spośród wszystkich krajów Unii Europejskiej tylko jeden zagłosował przeciwko wprowadzeniu zakazu rejestracji nowych aut spalinowych od 2035 roku i tak, dobrze myślicie – przeciw [&#8230;]</p>

## Czy fotowoltaika zimą ma sens? W tym kraju znaleźli wyjaśnienie, które zadowoli każdego niedowiarka
 - [https://www.chip.pl/2023/03/fotowoltaika-pionowe-panele-sloneczne-norwegia](https://www.chip.pl/2023/03/fotowoltaika-pionowe-panele-sloneczne-norwegia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 13:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1440" src="https://konto.chip.pl/wp-content/uploads/2023/03/pexels-braeson-holland-5987512-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/pexels-braeson-holland-5987512-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Wśród zarzutów przeciwko instalacjom fotowoltaicznym można usłyszeć te, że panele słoneczne są silnie zależne od warunków pogodowych, a zimą to już zupełnie nie spełniają swojej roli. Otóż może być odwrotnie i ostatnie doniesienia z Norwegii prowadzą do wniosków, że zimą też da się produkować dużo energii ze słońca. Norweska firma Over Easy prowadzi od początku [&#8230;]</p>

## Elektryczny rower enduro z potężnym silnikiem nie musi ważyć tony i kosztować majątku. Zobacz sam
 - [https://www.chip.pl/2023/03/elektryczny-rower-enduro-olympia-hammer](https://www.chip.pl/2023/03/elektryczny-rower-enduro-olympia-hammer)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 10:30:00+00:00

<img alt="Elektryczny rower enduro Hammer" class="attachment-full size-full wp-post-image" height="1018" src="https://konto.chip.pl/wp-content/uploads/2023/03/Elektryczny-rower-enduro-Olympia-Hammer-1.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/Elektryczny-rower-enduro-Olympia-Hammer-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Założona w 1893 roku włoska firma Olympia zapowiedziała właśnie swój najnowszy elektryczny rower enduro o nazwie Hammer, który doczekał się potężnego i bardzo wyjątkowego silnika. Względem innych e-bike wyróżnia go wiele szczegółów, jako że to połączenie wszystkiego tego, co najlepsze z przeszłości oraz przyszłości, bo tak się składa, że ten model bazuje na innym rowerze, [&#8230;]</p>

## Windows 12 nie dla każdego. Microsoft dokręci śrubę wymagań sprzętowych
 - [https://www.chip.pl/2023/03/wymagania-windows-12-plotki](https://www.chip.pl/2023/03/wymagania-windows-12-plotki)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 09:30:00+00:00

<img alt="Windows 12" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/03/Wymagania-Windows-12-.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/Wymagania-Windows-12-.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Co powiecie na kilka informacji co do tego, jak będą prezentować się wymagania Windows 12? Ta nowa wersja sytemu Microsoftu, która ma zastąpić walczącego o popularność Windowsa 11, staje się coraz częstszym gościem w mediach. Niedawno doszliśmy do momentu, w którym nawet kwestia sprzętu, który Windowsa 12 obsłuży, stała się poruszanym tematem.  Jakie wymagania może [&#8230;]</p>

## Stany Zjednoczone coś kręcą. Ostatni test superbroni chyba nie przebiegł po ich myśli
 - [https://www.chip.pl/2023/03/usa-superbron-pocisk-arrw](https://www.chip.pl/2023/03/usa-superbron-pocisk-arrw)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 09:00:00+00:00

<img alt="Drugi test pocisku ARRW zakończony wątpliwym sukcesem" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/03/USA-Pocisk-ARRW-superbron.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/USA-Pocisk-ARRW-superbron.jpg" style="display: block; margin: 1em auto;" /></p>
<p>W ostatnim czasie USA zrealizowały nowy test superbroni, ale nie dość, że ukrywały ten fakt przed światem przez długi czas, to finalnie opisały wymijająco całe wydarzenie. Innymi słowy, coś tu jest nie tak &#8211; i nawet wiemy co. Historia ARRW nie jest bowiem różami usłana. AGM-138A ARRW przetestowany po raz kolejny. USA nie mogą być [&#8230;]</p>

## Życie w układzie TRAPPIST-1? Teleskop Webba dostarczył zaskakujących informacji
 - [https://www.chip.pl/2023/03/trappist-1-uklad-planetarny-atmosfera-teleskop-webba](https://www.chip.pl/2023/03/trappist-1-uklad-planetarny-atmosfera-teleskop-webba)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 07:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1024" src="https://konto.chip.pl/wp-content/uploads/2023/03/trappist-1-uklad.jpg" style="margin-bottom: 10px;" width="2048" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/trappist-1-uklad.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Około 39 lat świetlnych od Ziemi znajduje się gwiazda TRAPPIST-1, wokół której krąży co najmniej siedem planet. W odniesieniu do trzech z nich mówiło się o możliwości utrzymywania wody w stanie ciekłym. Realizacja takiego scenariusza to oczywiście świetna wiadomość z punktu widzenia poszukiwania dowodów na istnienie życia pozaziemskiego. Planety krążące w obrębie ekosfer czy też [&#8230;]</p>

## Będzie podstawą nowoczesnej floty Turcji. Dron Bayraktar TB3 na pierwszych zdjęciach
 - [https://www.chip.pl/2023/03/dron-bayraktar-tb3-zdjecia](https://www.chip.pl/2023/03/dron-bayraktar-tb3-zdjecia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-03-28 03:59:41+00:00

<img alt="Tureckie pokładowe drony bojowe Bayraktar TB-3" class="attachment-full size-full wp-post-image" height="1067" src="https://konto.chip.pl/wp-content/uploads/2021/08/Tureckie-pokladowe-drony-bojowe-TB-3-od-Baykar-w-szczegolach-2.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/08/Tureckie-pokladowe-drony-bojowe-TB-3-od-Baykar-w-szczegolach-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Do tej pory turecki Bayraktar TB3 był jedynie zapowiadany i pokazywany na niedokładnych renderach okrętu TCG Anadolu, a więc lotniskowca z możliwościami desantowymi. Dziś jednak świat po raz pierwszy zobaczył tego okrętowego drona na oficjalnych zdjęciach. Turecki Bayraktar TB3 to pierwszy na świecie bojowy dron okrętowy ze zdolnością startu z krótkich pasów rozbiegowych Sam w [&#8230;]</p>

