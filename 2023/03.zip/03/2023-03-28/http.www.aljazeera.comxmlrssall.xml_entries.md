# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## US judge orders former Vice President Pence to testify in inquiry
 - [https://www.aljazeera.com/news/2023/3/28/us-judge-orders-former-vice-president-pence-to-testify-in-inquiry](https://www.aljazeera.com/news/2023/3/28/us-judge-orders-former-vice-president-pence-to-testify-in-inquiry)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 23:56:18+00:00

US media reports that the ruling may compel Mike Pence to speak about Donald Trump&#039;s actions after the 2020 election.

## Taiwan President Tsai’s controversial trip to Central America
 - [https://www.aljazeera.com/news/2023/3/28/taiwanese-president-tsai-ing-wen-on-a-10-day-diplomatic-tour](https://www.aljazeera.com/news/2023/3/28/taiwanese-president-tsai-ing-wen-on-a-10-day-diplomatic-tour)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 23:22:31+00:00

Taiwanese President Tsai Ing-wen is scheduled to depart on a 10-day tour of Central America with stopovers in the US.

## US bid to ban TikTok raises hypocrisy charge amid global spying
 - [https://www.aljazeera.com/economy/2023/3/28/bid-to-ban-tiktok-raises-hypocrisy-charge-amid-global-spying](https://www.aljazeera.com/economy/2023/3/28/bid-to-ban-tiktok-raises-hypocrisy-charge-amid-global-spying)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 22:49:44+00:00

Lawmakers&#039; push to ban app comes as they mull extending powers that force tech firms to enable mass snooping for the US.

## US announces sanctions against Assad cousins over drug trade
 - [https://www.aljazeera.com/news/2023/3/28/us-announces-sanctions-against-assad-associates-over-drug-trade](https://www.aljazeera.com/news/2023/3/28/us-announces-sanctions-against-assad-associates-over-drug-trade)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 22:25:40+00:00

US Treasury officials say that the Assad government has used drug trafficking as a source of illicit revenue.

## Senate committee questions federal regulators over US bank crisis
 - [https://www.aljazeera.com/news/2023/3/28/senate-committee-questions-federal-regulators-over-us-bank-crisis](https://www.aljazeera.com/news/2023/3/28/senate-committee-questions-federal-regulators-over-us-bank-crisis)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 21:58:51+00:00

Tuesday marked the US Senate&#039;s first public hearing into the collapse of Silicon Valley Bank in early March.

## For displaced Muslims in DRC, little food to break Ramadan fast
 - [https://www.aljazeera.com/gallery/2023/3/28/photos-for-displaced-muslims-in-eastern-drc-a-tough-ramadan](https://www.aljazeera.com/gallery/2023/3/28/photos-for-displaced-muslims-in-eastern-drc-a-tough-ramadan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 21:53:23+00:00

Some 500 Muslims displaced by the violence in eastern DR Congo have little water and food to break their Ramadan fast.

## COVID-19: WHO says no extra booster needed for medium-risk adults
 - [https://www.aljazeera.com/news/2023/3/28/covid-19-who-says-no-extra-booster-needed-for-medium-risk-adults](https://www.aljazeera.com/news/2023/3/28/covid-19-who-says-no-extra-booster-needed-for-medium-risk-adults)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 21:13:43+00:00

WHO recommends primary doses and a first booster in healthy adults, children and adolescents with comorbidities.

## Murder conviction of Adnan Syed reinstated by appeals court panel
 - [https://www.aljazeera.com/news/2023/3/28/murder-conviction-of-adnan-syed-reinstated-by-appeals-court-panel](https://www.aljazeera.com/news/2023/3/28/murder-conviction-of-adnan-syed-reinstated-by-appeals-court-panel)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 20:46:22+00:00

Syed, whose story was chronicled in the hit Serial podcast, had previously had his conviction vacated in September.

## US bears ‘moral weight’ of Mexico migrant tragedy: Advocates
 - [https://www.aljazeera.com/news/2023/3/28/us-bears-moral-weight-of-mexico-migrant-tragedy-advocates](https://www.aljazeera.com/news/2023/3/28/us-bears-moral-weight-of-mexico-migrant-tragedy-advocates)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 20:38:58+00:00

Ciudad Juarez blaze that killed at least 39 migrants comes amid increasingly restrictive policies at US-Mexico border.

## Will Netanyahu be able to press ahead with his judicial overhaul?
 - [https://www.aljazeera.com/program/inside-story/2023/3/28/will-netanyahu-be-able-to-press-ahead-with-his-judicial-overhaul](https://www.aljazeera.com/program/inside-story/2023/3/28/will-netanyahu-be-able-to-press-ahead-with-his-judicial-overhaul)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 20:25:29+00:00

Angry protests across Israel force Prime Minister Benjamin Netanyahu to delay his government&#039;s controversial proposals.

## One Mexican journalist attacked every 13 hours in 2022: Report
 - [https://www.aljazeera.com/news/2023/3/28/advocacy-group-says-2022-most-deadly-year-for-mexican-journalists](https://www.aljazeera.com/news/2023/3/28/advocacy-group-says-2022-most-deadly-year-for-mexican-journalists)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 19:45:07+00:00

A report by the group Article 19 has documented nearly 700 crimes against media workers, the most on record.

## US legislators voice concerns over Tunisia rights crackdown
 - [https://www.aljazeera.com/news/2023/3/28/us-legislators-voice-concerns-over-tunisia-rights-crackdown](https://www.aljazeera.com/news/2023/3/28/us-legislators-voice-concerns-over-tunisia-rights-crackdown)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 19:23:20+00:00

Congress members say &#039;autocratic consolidation&#039;, treatment of migrants threatens US-Tunisia relations.

## U-20 World Cup: Indonesia says no policy change in hosting Israel
 - [https://www.aljazeera.com/news/2023/3/28/u-20-world-cup-indonesia-says-no-change-in-stance-on-palestine](https://www.aljazeera.com/news/2023/3/28/u-20-world-cup-indonesia-says-no-change-in-stance-on-palestine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 18:57:04+00:00

Indonesia&#039;s president says Israel&#039;s participation in the Under-20 World Cup would bring no change to its foreign policy.

## Israel’s parties to hold first talks on justice reforms
 - [https://www.aljazeera.com/news/2023/3/28/israels-parties-to-hold-first-talks-on-justice-reform](https://www.aljazeera.com/news/2023/3/28/israels-parties-to-hold-first-talks-on-justice-reform)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 18:56:30+00:00

President Isaac Herzog has invited ruling parties and the opposition to meet Tuesday after judicial reforms were halted.

## Portugal: Two women stabbed to death at Lisbon’s Islamic centre
 - [https://www.aljazeera.com/news/2023/3/28/portugal-two-people-stabbed-to-death-in-lisbons-islamic-center](https://www.aljazeera.com/news/2023/3/28/portugal-two-people-stabbed-to-death-in-lisbons-islamic-center)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 18:17:47+00:00

Police say the attacker is in custody after he was shot and wounded for failing to put down his knife.

## IOC recommends return of Russian, Belarusian athletes as neutrals
 - [https://www.aljazeera.com/news/2023/3/28/ioc-recommends-return-of-russian-belarusian-athletes-as-neutrals](https://www.aljazeera.com/news/2023/3/28/ioc-recommends-return-of-russian-belarusian-athletes-as-neutrals)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 17:15:59+00:00

The Olympic committee has recommended that Russians and Belarusians be allowed to compete as neutrals.

## Nashville police search for clues after latest US school shooting
 - [https://www.aljazeera.com/news/2023/3/28/nashville-police-search-for-clues-after-latest-us-school-shooting](https://www.aljazeera.com/news/2023/3/28/nashville-police-search-for-clues-after-latest-us-school-shooting)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 16:29:34+00:00

Police release body camera footage of attack at Christian primary school that left three children, three adults dead.

## Russian whose child drew anti-war image gets jail term but flees
 - [https://www.aljazeera.com/news/2023/3/28/russian-whose-child-drew-anti-war-image-gets-jail-term-but-flees](https://www.aljazeera.com/news/2023/3/28/russian-whose-child-drew-anti-war-image-gets-jail-term-but-flees)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 15:59:14+00:00

Alexei Moskalyov&#039;s 13-year-old daughter has been placed in a children&#039;s home after making a drawing about Ukraine&#039;s war.

## Ex-crypto boss Bankman-Fried charged with bribing China officials
 - [https://www.aljazeera.com/news/2023/3/28/ex-crypto-boss-bankman-fried-charged-with-bribing-china-officials](https://www.aljazeera.com/news/2023/3/28/ex-crypto-boss-bankman-fried-charged-with-bribing-china-officials)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 15:25:43+00:00

US accuses founder of now-bankrupt FTX cryptocurrency exchange of conspiring to pay $40bn to Chinese officials.

## Protests rage in France for a 10th day, as Macron remains defiant
 - [https://www.aljazeera.com/gallery/2023/3/28/photos-protests-rage-in-france-for-a-10th-day-as-macron-remains-defiant](https://www.aljazeera.com/gallery/2023/3/28/photos-protests-rage-in-france-for-a-10th-day-as-macron-remains-defiant)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 15:08:08+00:00

Exit from the firestorm of protest triggered by Macron&#039;s changes looks as far away as ever.

## Bitter taste of kiwis: Indian fruit pickers in Italy allege abuse
 - [https://www.aljazeera.com/features/2023/3/28/bitter-taste-of-kiwis-migrant-worker-mistreatment-in-italy](https://www.aljazeera.com/features/2023/3/28/bitter-taste-of-kiwis-migrant-worker-mistreatment-in-italy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 14:48:35+00:00

Many farmhands hail from the Punjab and migrate for better salaries than they would earn in India&#039;s breadbasket.

## Myanmar military dissolves Aung San Suu Kyi’s NLD party
 - [https://www.aljazeera.com/news/2023/3/28/myanmar-junta-dissolves-suu-kyis-nld-party-state-media](https://www.aljazeera.com/news/2023/3/28/myanmar-junta-dissolves-suu-kyis-nld-party-state-media)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 14:44:24+00:00

NLD led by Suu Kyi among 40 parties dissolved after failing to meet registration deadline, according to state TV.

## Israelis need to see through the biggest lie of all
 - [https://www.aljazeera.com/opinions/2023/3/28/israelis-need-to-see-through-the-biggest-lie-of-all](https://www.aljazeera.com/opinions/2023/3/28/israelis-need-to-see-through-the-biggest-lie-of-all)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 14:36:12+00:00

Israel cannot be a ‘Jewish state’ and a democracy, an occupier and a liberal society.

## The Taliban needs to start an intra-Afghan dialogue but with who?
 - [https://www.aljazeera.com/opinions/2023/3/28/the-taliban-need-to-start-an-intra-afghan-dialogue-but-with-who](https://www.aljazeera.com/opinions/2023/3/28/the-taliban-need-to-start-an-intra-afghan-dialogue-but-with-who)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 14:04:19+00:00

Inclusivity is important, but more important is not to bring back corrupt officials from the previous government.

## Myanmar parades military and issues warning to “terrorists”
 - [https://www.aljazeera.com/program/newsfeed/2023/3/28/myanmar-parades-military-and-issues-warning-to-terrorists](https://www.aljazeera.com/program/newsfeed/2023/3/28/myanmar-parades-military-and-issues-warning-to-terrorists)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 12:53:58+00:00

An Al Jazeera crew was allowed into Myanmar to witness a huge military parade, as its leader issued a warning.

## Photos: Fire kills dozens at Mexico migrant centre near US border
 - [https://www.aljazeera.com/gallery/2023/3/28/photos-39-dead-in-fire-at-mexico-migrant-center-near-us-border](https://www.aljazeera.com/gallery/2023/3/28/photos-39-dead-in-fire-at-mexico-migrant-center-near-us-border)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 11:49:06+00:00

Ciudad Juarez is a major crossing point for refugees and migrants entering the United States.

## Pirates board Danish-owned ship in dreaded Gulf of Guinea
 - [https://www.aljazeera.com/news/2023/3/28/pirates-board-danish-owned-ship-in-gulf-of-guinea](https://www.aljazeera.com/news/2023/3/28/pirates-board-danish-owned-ship-in-gulf-of-guinea)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 11:44:10+00:00

The tanker was attacked in the Gulf of Guinea, seen as one of the world&#039;s most dangerous shipping routes.

## Bush did what Putin’s doing — so why is he getting away?
 - [https://www.aljazeera.com/opinions/2023/3/28/putin-should-be-punished-so-must-bush](https://www.aljazeera.com/opinions/2023/3/28/putin-should-be-punished-so-must-bush)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 11:21:38+00:00

The answer: hypocrisy, even in the way the West&#039;s narrative describes the Iraq invasion and Ukraine war.

## Philippines’ Marcos to shut out ICC after losing drug-war appeal
 - [https://www.aljazeera.com/news/2023/3/28/philippiness-marcos-to-shut-out-icc-after-losing-drug-war-appeal](https://www.aljazeera.com/news/2023/3/28/philippiness-marcos-to-shut-out-icc-after-losing-drug-war-appeal)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 11:02:46+00:00

The Philippines has argued its own institutions are capable of prosecuting crimes.

## 39 men killed in fire at migrant detention facility in Mexico
 - [https://www.aljazeera.com/news/2023/3/28/dozens-dead-in-fire-at-migrant-facility-in-mexico](https://www.aljazeera.com/news/2023/3/28/dozens-dead-in-fire-at-migrant-facility-in-mexico)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 10:49:39+00:00

Another 29 detainees were injured in the blaze that broke out at a holding centre in Ciudad Juarez near Texas.

## Israeli right-wing protesters attack Palestinians in Jerusalem
 - [https://www.aljazeera.com/news/2023/3/28/right-wing-protesters-attack-arabs-in-jerusalem](https://www.aljazeera.com/news/2023/3/28/right-wing-protesters-attack-arabs-in-jerusalem)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 10:21:29+00:00

Reports say that one man was &quot;savagely beaten&quot; in Jerusalem, after pro-government supporters had gathered.

## Israelis attack Palestinians in Huwara, despite army presence
 - [https://www.aljazeera.com/news/2023/3/28/israelis-attack-palestinians-huwara-army-watches-on](https://www.aljazeera.com/news/2023/3/28/israelis-attack-palestinians-huwara-army-watches-on)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 09:55:06+00:00

At least six Palestinians injured in an Israeli settler attack on Palestinians in Nablus in the occupied West Bank.

## Decades of deadly gun violence in US schools
 - [https://www.aljazeera.com/news/2023/3/28/decades-of-deadly-gun-violence-in-us-schools](https://www.aljazeera.com/news/2023/3/28/decades-of-deadly-gun-violence-in-us-schools)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 09:37:30+00:00

Nashville shooting that killed six is the latest school attack to raise questions about easy access to assault weapons.

## Russia says oil sales to India soared 22-fold last year
 - [https://www.aljazeera.com/news/2023/3/28/russia-says-oil-sales-to-india-soared-22-fold-last-year](https://www.aljazeera.com/news/2023/3/28/russia-says-oil-sales-to-india-soared-22-fold-last-year)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 09:34:01+00:00

Sales to India surged in 2022 as European buyers turned to other markets after the Ukraine war, Russian deputy PM says.

## Why does Russia want tactical nuclear weapons in Belarus?
 - [https://www.aljazeera.com/news/2023/3/28/why-does-russia-want-tactical-nuclear-weapons-in-belarus](https://www.aljazeera.com/news/2023/3/28/why-does-russia-want-tactical-nuclear-weapons-in-belarus)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 09:27:43+00:00

Minsk and Moscow have close military ties with Belarus a staging ground for the invasion of neighbouring Ukraine.

## UN says prominent Afghan girls’ education activist arrested
 - [https://www.aljazeera.com/news/2023/3/28/un-says-prominent-afghan-girls-education-activist-arrested](https://www.aljazeera.com/news/2023/3/28/un-says-prominent-afghan-girls-education-activist-arrested)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 09:23:28+00:00

Matiullah Wesa of Pen Path NGO that travels across Afghanistan with a mobile school arrested in Kabul, says UN mission.

## Freed Hotel Rwanda hero Rusesabagina arrives in Qatar from Rwanda
 - [https://www.aljazeera.com/news/2023/3/28/freed-hotel-rwanda-hero-rusesabagina-leaves-rwanda-reaches-qatar-source](https://www.aljazeera.com/news/2023/3/28/freed-hotel-rwanda-hero-rusesabagina-leaves-rwanda-reaches-qatar-source)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 09:11:24+00:00

Rusesabagina was sentenced in September 2021 to 25 years over ties to a group opposed to Rwanda&#039;s Paul Kagame.

## Tennis: Rafael Nadal unsure of comeback from injury
 - [https://www.aljazeera.com/sports/2023/3/28/tennis-nadal-unsure-of-participation-at-monte-carlo](https://www.aljazeera.com/sports/2023/3/28/tennis-nadal-unsure-of-participation-at-monte-carlo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 09:00:21+00:00

The 22-time grand slam champion has been struggling with an issue in his left hip.

## Despite inflation, Egyptians dig deep to give charity in Ramadan
 - [https://www.aljazeera.com/features/2023/3/28/despite-inflation-egyptians-dig-deep-to-give-charity-in-ramadan](https://www.aljazeera.com/features/2023/3/28/despite-inflation-egyptians-dig-deep-to-give-charity-in-ramadan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 08:29:10+00:00

An economic crisis means that many Egyptians will find it difficult to donate the amounts they usually do.

## ‘Conflicting feeling’, says India’s first woman Rohingya graduate
 - [https://www.aljazeera.com/news/2023/3/28/conflicting-feeling-says-indias-first-woman-rohingya-graduate](https://www.aljazeera.com/news/2023/3/28/conflicting-feeling-says-indias-first-woman-rohingya-graduate)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 08:06:50+00:00

Tasmida Johar is happy she was able to study despite the odds but wishes other Rohingya women also had the opportunity.

## Photos: Aftermath of the deadly landslide in Ecuador
 - [https://www.aljazeera.com/gallery/2023/3/28/photos-landslide-in-ecuador-kills-at-least-7-dozens-missing](https://www.aljazeera.com/gallery/2023/3/28/photos-landslide-in-ecuador-kills-at-least-7-dozens-missing)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 07:59:28+00:00

The number of people reported missing is 62 after the massive wave of mud crashed down onto the community.

## At least 20 killed after bus carrying pilgrims crashes in Saudi
 - [https://www.aljazeera.com/news/2023/3/28/bus-carrying-pilgrims-crashes-in-saudi-kills-20](https://www.aljazeera.com/news/2023/3/28/bus-carrying-pilgrims-crashes-in-saudi-kills-20)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 07:52:38+00:00

Dozens injured in the accident that took place in the southern province of Asir.

## Ukraine receives Leopard, Challenger battle tanks
 - [https://www.aljazeera.com/news/2023/3/28/military-art-ukraine-receives-leopard-challenger-battle-tanks](https://www.aljazeera.com/news/2023/3/28/military-art-ukraine-receives-leopard-challenger-battle-tanks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 07:48:00+00:00

New additions to Ukraine&#039;s military include tanks as well as infantry fighting vehicles and armoured personnel carriers.

## What is next for Egypt-Turkey rapprochement?
 - [https://www.aljazeera.com/news/2023/3/28/turkey-and-egypt-set-for-full-diplomatic-ties-after-fms-meet](https://www.aljazeera.com/news/2023/3/28/turkey-and-egypt-set-for-full-diplomatic-ties-after-fms-meet)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 07:37:58+00:00

Regional rivals have held two talks at the foreign minister level in less than a month.

## ‘At least $20m’ worth of cocaine headed for Turkey seized in Peru
 - [https://www.aljazeera.com/news/2023/3/28/peru-police-seize-20m-of-cocaine-headed-for-turkey](https://www.aljazeera.com/news/2023/3/28/peru-police-seize-20m-of-cocaine-headed-for-turkey)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 07:37:23+00:00

Police say the drug bust happened at a warehouse at Peru&#039;s biggest port El Callao.

## Israel protesters vow to continue until judicial ‘reform’ gone
 - [https://www.aljazeera.com/news/2023/3/28/israel-protesters-vow-to-continue-until-judicial-reform-gone](https://www.aljazeera.com/news/2023/3/28/israel-protesters-vow-to-continue-until-judicial-reform-gone)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 07:11:54+00:00

PM Benjamin Netanyahu&#039;s statement Monday hasn&#039;t appeased those opposing his perceived desire to control the judiciary.

## Russia-Ukraine war exposed human rights ‘double standards’
 - [https://www.aljazeera.com/news/2023/3/28/ukraine-war-excerbated-human-rights-double-standards-amnesty](https://www.aljazeera.com/news/2023/3/28/ukraine-war-excerbated-human-rights-double-standards-amnesty)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 06:56:56+00:00

Amnesty International publishes annual report highlighting the state of human rights in more than 150 countries.

## Will ChatGPT take your job — and millions of others?
 - [https://www.aljazeera.com/features/2023/3/28/will-chatgpt-take-your-job-and-millions-of-others](https://www.aljazeera.com/features/2023/3/28/will-chatgpt-take-your-job-and-millions-of-others)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 05:43:03+00:00

The latest AI wave will disrupt the workplace. Teachers could be most affected. But it could end up creating more jobs.

## Twitter celebs baulk at paying for blue check mark
 - [https://www.aljazeera.com/economy/2023/3/28/twitter-celebs-balk-at-paying-for-blue-check-mark](https://www.aljazeera.com/economy/2023/3/28/twitter-celebs-balk-at-paying-for-blue-check-mark)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 05:33:14+00:00

After months of delay, Elon Musk is promising that Saturday is deadline for people to pay or lose their legacy status.

## Tesla faces new race bias trial after $137m verdict cut
 - [https://www.aljazeera.com/economy/2023/3/28/tesla-faces-new-race-bias-trial-on-137m-verdict-that-was-cut](https://www.aljazeera.com/economy/2023/3/28/tesla-faces-new-race-bias-trial-on-137m-verdict-that-was-cut)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 05:30:11+00:00

A judge had slashed the amount awarded in 2021 to a Black worker, one of the largest workplace discrimination awards.

## Russia test fires supersonic missiles at target in Sea of Japan
 - [https://www.aljazeera.com/news/2023/3/28/russia-test-fires-supersonic-missiles-at-target-in-sea-of-japan](https://www.aljazeera.com/news/2023/3/28/russia-test-fires-supersonic-missiles-at-target-in-sea-of-japan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 05:19:47+00:00

Missile ships of Russia&#039;s Pacific Fleet fired Moskit cruise missiles at a mock enemy target in the Sea of Japan.

## Is there any hope of an end to Yemen’s war?
 - [https://www.aljazeera.com/program/the-stream/2023/3/28/is-there-any-hope-of-an-end-to-yemens-war](https://www.aljazeera.com/program/the-stream/2023/3/28/is-there-any-hope-of-an-end-to-yemens-war)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 04:48:30+00:00

The Stream also looks at protests in Kenya and the mood in Peru after historic demonstrations.

## China Premier Li tells Apple’s Tim Cook country to open further
 - [https://www.aljazeera.com/economy/2023/3/28/china-premier-li-tells-apples-tim-cook-country-to-open-further](https://www.aljazeera.com/economy/2023/3/28/china-premier-li-tells-apples-tim-cook-country-to-open-further)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 03:37:44+00:00

Beijing is courting foreign executives at China Development Forum as it tries to revive economy after &#039;zero COVID.&#039;

## Kim urges N Korean experts to produce ‘powerful nuclear weapons’
 - [https://www.aljazeera.com/news/2023/3/28/kim-urges-n-korean-experts-to-produce-powerful-nuclear-weapons](https://www.aljazeera.com/news/2023/3/28/kim-urges-n-korean-experts-to-produce-powerful-nuclear-weapons)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 03:33:37+00:00

Kim Jong Un maintains his nuclear weapons are focused on defending North Korea against a hostile US and South Korea.

## Russia-Ukraine war: List of key events, day 398
 - [https://www.aljazeera.com/news/2023/3/28/russia-ukraine-war-list-of-key-events-day-398](https://www.aljazeera.com/news/2023/3/28/russia-ukraine-war-list-of-key-events-day-398)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 02:20:56+00:00

As the Russia-Ukraine war enters its 398th day, we take a look at the main developments.

## Zelenskyy accuses Russia of ‘radiation blackmail’ at Zaporizhzhia
 - [https://www.aljazeera.com/news/2023/3/28/zelenskyy-accuses-russia-of-radiation-blackmail-at-zaporizhzhia](https://www.aljazeera.com/news/2023/3/28/zelenskyy-accuses-russia-of-radiation-blackmail-at-zaporizhzhia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 02:11:04+00:00

Ukraine&#039;s Zelenskyy tells the IAEA&#039;s Rafael Grossi that safety at Europe&#039;s largest nuclear facility was not assured.

## US regulator sues top crypto exchange Binance, CEO
 - [https://www.aljazeera.com/economy/2023/3/28/us-regulator-sues-top-crypto-exchange-binance-ceo](https://www.aljazeera.com/economy/2023/3/28/us-regulator-sues-top-crypto-exchange-binance-ceo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 01:59:08+00:00

US Commodity Futures Trading Commission claims world&#039;s biggest crypto exchange engaged in &quot;willful evasion&quot; of US law.

## Indonesia’s snack stalls pray for Ramadan bonanza after COVID
 - [https://www.aljazeera.com/economy/2023/3/28/indonesias-snack-sellers-eye-ramadan-bonanza-after-pandemic-lull](https://www.aljazeera.com/economy/2023/3/28/indonesias-snack-sellers-eye-ramadan-bonanza-after-pandemic-lull)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 01:45:19+00:00

Small business owners are hoping to do a roaring trade in snacks known as takjil after several tough years due to COVID.

## US Senate votes to advance repeal of Iraq War authorisation
 - [https://www.aljazeera.com/news/2023/3/28/us-senate-votes-to-advance-repeal-of-iraq-war-authorisation](https://www.aljazeera.com/news/2023/3/28/us-senate-votes-to-advance-repeal-of-iraq-war-authorisation)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-28 01:02:23+00:00

The final vote to end two Iraq war authorisations clears a key procedural hurdle, as the Senate decides to limit debate.

