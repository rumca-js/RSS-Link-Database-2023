# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Rosja: Propaganda chce "niszczyć polskie miasta rakietami"
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/rosja-propaganda-chce-niszczyc-polskie-miasta-rakietami/](https://www.polsatnews.pl/wiadomosc/2023-03-28/rosja-propaganda-chce-niszczyc-polskie-miasta-rakietami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 19:47:00+00:00

Czołowy rosyjski propagandysta chce ostrzeliwać polskie miasta. Władimir Sołowjow na antenie Rossija 1 pytał czy Polacy chcą być następni i powiedział, że Rosja zniszczy polskie miasta rakietami. Wcześniej groźby w stronę Warszawy kierowała propaganda Białorusi.

## USA. Został niesłusznie skazany za gwałt. Mężczyzna dostanie gigantyczne odszkodowanie
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/usa-zostal-nieslusznie-skazany-za-gwalt-mezczyzna-dostanie-gigantyczne-odszkodowanie/](https://www.polsatnews.pl/wiadomosc/2023-03-28/usa-zostal-nieslusznie-skazany-za-gwalt-mezczyzna-dostanie-gigantyczne-odszkodowanie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 19:18:00+00:00

Stan Nowy Jork zgodził się zapłacić 5,5 miliona dolarów odszkodowania mężczyźnie, który został niesłusznie skazany za gwałt i spędził w więzieniu 16 lat.

## Rosja: Dwa lata kolonii karnej dla ojca, którego córka narysowała antywojenny obrazek
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/rosja-dwa-lata-kolonii-karnej-dla-ojca-ktorego-corka-narysowala-antywojenny-rysunek/](https://www.polsatnews.pl/wiadomosc/2023-03-28/rosja-dwa-lata-kolonii-karnej-dla-ojca-ktorego-corka-narysowala-antywojenny-rysunek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 17:21:00+00:00

Nastoletnia Masza narysowała w szkole antywojenny rysunek. Wezwano jej ojca, przesłuchiwano i według jego relacji - bito. Ostatecznie mężczyzna usłyszał wyrok za dyskredytowanie armii. Rosjanin ma spędzić w kolonii karnej dwa lata. Córkę umieszczono w ośrodku dla nieletnich.

## Morze Japońskie: Rosja wystrzeliła pociski Moskit. Trafiły w cel
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/morze-japonskie-rosja-wystrzelila-pociski-moskit-trafily-w-cel/](https://www.polsatnews.pl/wiadomosc/2023-03-28/morze-japonskie-rosja-wystrzelila-pociski-moskit-trafily-w-cel/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 16:55:00+00:00

Rosyjska marynarka wojenna podczas ćwiczeń na Morzu Japońskim wystrzeliła manewrujące pociski przeciwokrętowe Moskit - przekazał resort obrony Rosji. Pociski trafiły w pozorowany wrogi cel. Na zwiększoną aktywność rosyjskich sił zareagował japoński minister spraw zagranicznych.

## Układ Słoneczny. We wtorek wieczorem na niebie pojawią się: Jowisz, Merkury, Uran, Mars i Wenus
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/uklad-sloneczny-we-wtorek-wieczorem-na-niebie-pojawia-sie-jowisz-merkury-uran-mars-i-wenus/](https://www.polsatnews.pl/wiadomosc/2023-03-28/uklad-sloneczny-we-wtorek-wieczorem-na-niebie-pojawia-sie-jowisz-merkury-uran-mars-i-wenus/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 16:22:00+00:00

We wtorek, chwilę po zachodzie słońca będzie można dostrzec niezwykłe zjawisko. Na naszym niebie pięć planet Układu Słonecznego ułoży się w taki sposób, że wszystkie będą dostrzegalne gołym okiem.

## MKOl. Thomas Bach jest za dopuszczeniem Rosjan i Białorusinów do IO 2024 w Paryżu
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/mkol-thomas-bach-jest-za-dopuszczeniem-rosjan-i-bialorusinow-do-io-2024-w-paryzu/](https://www.polsatnews.pl/wiadomosc/2023-03-28/mkol-thomas-bach-jest-za-dopuszczeniem-rosjan-i-bialorusinow-do-io-2024-w-paryzu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 15:31:00+00:00

Międzynarodowy Komitet Olimpijski we wtorek przywrócił możliwość startów Rosjan i Białorusinów w sportach indywidualnych pod flagą neutralną. Wcześniej przewodniczący organizacji Thomas Bach rekomendował takie rozwiązanie. Decyzja nie oznacza jeszcze zgody na udział w nadchodzących IO 2024 w Paryżu.

## Wielka Brytania: Dziewczynka zaatakowana przez stado psów
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/wielka-brytania-dziewczynka-zaatakowano-przez-stado-psow/](https://www.polsatnews.pl/wiadomosc/2023-03-28/wielka-brytania-dziewczynka-zaatakowano-przez-stado-psow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 13:59:00+00:00

Policja z Manchesteru przejęła 17 psów rasy American Bully. Wcześniej kilka z nich zaatakowało sześcioletnią dziewczynkę. Dziecko trafiło do szpitala. Zwierzęta pogryzły jej twarz.

## Strzelanina w szkole w Nashville. Policja opublikowała nagranie
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/strzelanina-w-szkole-w-nashville-policja-opublikowala-nagranie/](https://www.polsatnews.pl/wiadomosc/2023-03-28/strzelanina-w-szkole-w-nashville-policja-opublikowala-nagranie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 13:41:00+00:00

Sześć osób, w tym troje dzieci, zginęło w strzelaninie, do której doszło w szkole chrześcijańskiej w Nashville (USA). Atak przeprowadziła uzbrojona kobieta, która została zastrzelona przez policję. Motywy jej działania nie są znane. Policja opublikowała nagranie z kamer monitoringu.

## Ukraina. Wypadek autokaru relacji Warszawa-Odessa. Według policji podróżowało nim 25 osób
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/ukraina-wypadek-autokaru-relacji-warszawa-odessa/](https://www.polsatnews.pl/wiadomosc/2023-03-28/ukraina-wypadek-autokaru-relacji-warszawa-odessa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 13:25:00+00:00

W pobliżu miejscowości Wołoczyska w obwodzie chmielnickim z drogi wypadł autokar jadący z Warszawy do Odessy. Pojazdem podróżowało 25 osób, w tym dwoje dzieci. Ukraińska policja poinformowała o rannych, ale nie podała szczegółów.

## Zakaz sprzedaży aut spalinowych do 2035 r. Ostateczna decyzja UE
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/zakaz-sprzedazy-aut-spalinowych-do-2035-r-ostateczna-decyzja-ue/](https://www.polsatnews.pl/wiadomosc/2023-03-28/zakaz-sprzedazy-aut-spalinowych-do-2035-r-ostateczna-decyzja-ue/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 13:11:00+00:00

Zakaz rejestracji prawie wszystkich nowych aut spalinowych wejdzie w życie w 2035 r. w Unii Europejskiej - zadecydowały kraje unijne. Wyjątek będą stanowiły te auta, które będą jeździć tylko na paliwach neutralnych pod względem emisji CO2. Za przyjęciem nowych regulacji opowiedziały się 23 kraje, trzy wstrzymały się od głosu, a Polska - jako jedyna - zagłosowała przeciw.

## USA, Karolina Północna. Kierowca Amazona dostarczył paczkę. Obok policja negocjowała z bandytą
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/usa-karolina-polnocna-kierowca-amazona-dostarczyl-paczke-obok-policja-negocjowala-z-bandyta/](https://www.polsatnews.pl/wiadomosc/2023-03-28/usa-karolina-polnocna-kierowca-amazona-dostarczyl-paczke-obok-policja-negocjowala-z-bandyta/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 12:40:00+00:00

Kierowca Amazona w USA zszokował internautów. Nagrano go, jak dostarczał paczkę w chwili, gdy trwało niebezpieczne starcie policji z uzbrojonym bandytą. Film stał się hitem sieci.

## Francja: Przeszukania w największych bankach. Powodem podejrzenia o pranie pieniędzy
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/francja-przeszukania-w-najwiekszych-bankach-powodem-podejrzenia-o-pranie-pieniedzy/](https://www.polsatnews.pl/wiadomosc/2023-03-28/francja-przeszukania-w-najwiekszych-bankach-powodem-podejrzenia-o-pranie-pieniedzy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 12:13:00+00:00

Francuscy i niemieccy śledczy przeszukują pięć banków mających siedziby w paryskiej dzielnicy finansowej. Działania prowadzą w ramach śledztwa dotyczącego masowych oszustw podatkowych i prania pieniędzy. Według gazety Le Monde przeszukiwane banki to Societe Generale, BNP Paribas, Exane, Natixis i HSBC.

## Josef Fritzl napisał książkę w więzieniu. Twierdzi, że jest "dobrym człowiekiem"
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/josef-fritzl-napisal-ksiazke-w-wiezieniu-twierdzi-ze-jest-dobrym-czlowiekiem/](https://www.polsatnews.pl/wiadomosc/2023-03-28/josef-fritzl-napisal-ksiazke-w-wiezieniu-twierdzi-ze-jest-dobrym-czlowiekiem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 11:27:00+00:00

Josef Fritzl, który przez ponad dwie dekady więził swoją córkę w piwnicy i wykorzystywał ją seksualnie, napisał książkę. We fragmentach przytaczanych przez austriackie i niemieckie media można wyczytać, że potwór z Amstetten uważa się za dobrego i rodzinnego człowieka. Chwali się też miłosnymi podbojami.

## Portugalia: Atak nożownika w Lizbonie. Są ofiary
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/portugalia-atak-nozownika-w-lizbonie-sa-ofiary/](https://www.polsatnews.pl/wiadomosc/2023-03-28/portugalia-atak-nozownika-w-lizbonie-sa-ofiary/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 11:24:00+00:00

Co najmniej dwie osoby zginęły w wyniku ataku nożownika w centrum religijnym Ismaili Centre w Lizbonie. Napastnik został postrzelony przez policję. Funkcjonariusze mieli pojawić się na miejscu po minucie od odebrania zgłoszenia.

## Demokratyczna Republika Konga: Wypadek w kopalni złota. Górników odkopywano gołymi rękami
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/demokratyczna-republika-konga-wypadek-w-kopalni-zlota-gornikow-odkopywano-golymi-rekami/](https://www.polsatnews.pl/wiadomosc/2023-03-28/demokratyczna-republika-konga-wypadek-w-kopalni-zlota-gornikow-odkopywano-golymi-rekami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 10:48:00+00:00

W jednej z kopalni złota w Demokratycznej Republice Konga zawaliła się ziemia. Do sieci trafiło nagranie, na którym widać, jak mężczyźni gołymi rękami próbują uratować zasypanych. Dzięki ich heroicznej pracy udało się uratować dziewięć osób.

## Papież Franciszek w modnej kurtce. Zdjęcie wykonała sztuczna inteligencja
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/papiez-franciszek-w-modnej-kurtce-zdjecie-wykonala-sztuczna-inteligencja/](https://www.polsatnews.pl/wiadomosc/2023-03-28/papiez-franciszek-w-modnej-kurtce-zdjecie-wykonala-sztuczna-inteligencja/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 09:02:00+00:00

AI oszukuje internet. Dowodem na to jest zdjęcie papieża Franciszka w modnej, białej kurtce. Utworzono je przy użyciu generatora obrazów sztucznej inteligencji o nazwie Midjourney. Błyskawicznie rozeszło się w sieci, szokując internautów.

## Moskwa: Czarny pierścień nad Strogino. Nagrania obiegły sieć
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/moskwa-czarny-pierscien-nad-strogino-nagrania-obiegly-siec/](https://www.polsatnews.pl/wiadomosc/2023-03-28/moskwa-czarny-pierscien-nad-strogino-nagrania-obiegly-siec/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 08:25:00+00:00

Mieszkańcy moskiewskiej dzielnicy Strogino nagrali nietypowe zjawisko atmosferyczne. Nad ich głowami pojawił się pierścień czarnego dymu. Propagandowe media zapewniają, że to nic poważnego. Innego zdania są media ukraińskie. Zwracają uwagę, że niektórzy naoczni świadkowie słyszeli głośny huk.

## Ramzan Kadyrow spotkał się ze swoją córką. Chwaliła wkład Fundacji Kadyrowa
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/ramzan-kadyrow-spotkal-sie-ze-swoja-corka-chwalila-wklad-fundacji-kadyrowa/](https://www.polsatnews.pl/wiadomosc/2023-03-28/ramzan-kadyrow-spotkal-sie-ze-swoja-corka-chwalila-wklad-fundacji-kadyrowa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 07:41:00+00:00

Obsadzenie najważniejszych stanowisk w Czeczenii rodziną i przyjaciółmi Ramzana Kadyrowa doprowadza do niespotykanych wcześniej absurdów. Uwagę mediów i komentatorów przykuło niedawne spotkanie przywódcy ze jego córką. 20-letnia Khutmat Kadyrow, kuratorka służby zdrowia, opisywała zasługi Fundacji Achmata Kadyrowa dla republiki. Na czele organizacji stoi... matka Ramzana Kadyrowa.

## Ukraina: Atak irańskich dronów na Kijów. Zniszczono 12 urządzeń
 - [https://www.polsatnews.pl/wiadomosc/2023-03-28/ukraina-atak-iranskich-dronow-na-kijow-zniszczono-12-urzadzen/](https://www.polsatnews.pl/wiadomosc/2023-03-28/ukraina-atak-iranskich-dronow-na-kijow-zniszczono-12-urzadzen/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-28 04:41:00+00:00

W nocy z poniedziałku na wtorek w przestrzeni powietrznej Kijowa wykryto i zniszczono 12 dronów produkcji irańskiej Shahed. W poniedziałek wieczorem w stolicy Ukrainy doszło do wielu eksplozji.

