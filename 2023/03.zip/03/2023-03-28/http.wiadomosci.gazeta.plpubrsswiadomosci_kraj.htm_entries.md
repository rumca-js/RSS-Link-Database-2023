# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Zabójca 18-letniej Magdy spod Kamienia Pomorskiego usłyszał wyrok. Wcześniej popełnił tę samą zbrodnię
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29607346,zabojca-18-letniej-magdy-spod-kamienia-pomorskiego-uslyszal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29607346,zabojca-18-letniej-magdy-spod-kamienia-pomorskiego-uslyszal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 18:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6d/1f/1c/z29490029M.jpg" vspace="2" />Dawid J. usłyszał wyrok dożywotniego pozbawienia wolności z możliwością ubiegania się o wcześniejsze zwolnienie po upływie 35 lat. Mężczyzna został skazany za gwałt i zabójstwo 18-letniej Magdy spod Kamienia Pomorskiego. W wieku 14 lat dopuścił się takiej samej zbrodni.

## Rzecznik Praw Dziecka przerywa milczenie ws. rekolekcji w Toruniu. Aż 4 zdania na Twitterze
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29607212,rzecznik-praw-dziecka-przerywa-milczenie-ws-rekolekcji-w-toruniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29607212,rzecznik-praw-dziecka-przerywa-milczenie-ws-rekolekcji-w-toruniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 18:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/3c/1c/z29607911M,Rzecznik-praw-dziecka-Mikolaj-Pawlak.jpg" vspace="2" />W toruńskim kościele w czasie rekolekcji odegrano scenę, podczas której mężczyzna szarpał, wyzywał i ciągnął za smycz roznegliżowaną kobietę. Wszystko zostało nagrane, a film trafił do sieci. Rzecznik Praw Dziecka Mikołaj Pawlak skomentował sprawę na Twitterze.

## Karetka utknęła na oblodzonej drodze. Natychmiastowa reakcja kierowców. "Gdzie służby?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29607405,karetka-utknela-na-oblodzonej-drodze-w-malopolsce-natychmiastowa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29607405,karetka-utknela-na-oblodzonej-drodze-w-malopolsce-natychmiastowa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 16:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ce/3c/1c/z29607630M,Karetka-utknela-na-oblodzonej-drodze--Zareagowali-.jpg" vspace="2" />W związku z intensywnymi opadami śniegu, w wielu miejscach w Polsce panują trudne warunki na drogach. W województwie małopolskim karetka ugrzęzła w śniegu. "Gdzie są służby drogowe, piaskarki"? - pytają kierowcy.

## Ks. Kobyliński o rekolekcjach w Toruniu. "Takie praktyki są od lat promowane przez władze kościelne"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29607334,ks-kobylinski-o-rekolekcjach-w-toruniu-takie-praktyki-sa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29607334,ks-kobylinski-o-rekolekcjach-w-toruniu-takie-praktyki-sa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 15:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d0/4c/1a/z27576272M,Prof--Andrzej-Kobylinski.jpg" vspace="2" />- Jako katolik czuję się do żywego dotknięty tym bluźnierczym spektaklem - tak ks. prof. Andrzej Kobyliński komentuje w rozmowie z Gazeta.pl szokujące nagranie z rekolekcji w Toruniu. Duchowny podkreśla, że podobne praktyki od lat odbywają się za aprobatą władz kościelnych. - To kompromitacja religii - mówi.

## Wołodymyr Zełenski "w niedługim czasie" w Polsce? "Trwają prace nad traktatem polsko-ukraińskim"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29606880,wolodymyr-zelenski-w-polsce-wiceminister-msz-trwaja-prace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29606880,wolodymyr-zelenski-w-polsce-wiceminister-msz-trwaja-prace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 14:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/3c/1c/z29607235M,Prezydent-Ukrainy-Wolodymyr-Zelenski-w-Polsce--zdj.jpg" vspace="2" />W niedługim czasie może mieć miejsce wizyta Wołodymyra Zełenskiego w Polsce. Ze względów bezpieczeństwa nie będzie ona zapowiadana z wyprzedzeniem. Wiceminister MSZ Paweł Jabłoński opowiedział jedna o planach traktatu polsko-ukraińskiego.

## Czarnek zapowiada zmiany w szkołach. "Przystąpiliśmy do odchudzenia programu". Lekcje będą krótsze?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29606610,czarnek-zapowiada-zmiany-w-oswiacie-przystapilismy-energicznie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29606610,czarnek-zapowiada-zmiany-w-oswiacie-przystapilismy-energicznie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 14:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4e/c1/19/z27005774M,Minister-Czarnek-chce-zmian-w-sprawie-religii-w-sz.jpg" vspace="2" />Minister Przemysław Czarnek zapowiedział zmiany w szkolnictwie. Lekcje mogą zostać skrócone nawet o kilka godzin. - Przystąpiliśmy energicznie do odchudzenia podstawy programowej w rozmaitych obszarach. Po to, żeby było więcej czasu na wspólnotę, więcej czasu na kontakty między uczniami i mniejsze obciążenie dla uczniów - zapowiedział Czarnek.

## Lichocka pozwała Budkę. Jest decyzja sądu. "Domagała się przeprosin za swój słynny gest"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29606584,lichocka-pozwala-budke-jest-decyzja-sadu-domagala-sie-przeprosin.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29606584,lichocka-pozwala-budke-jest-decyzja-sadu-domagala-sie-przeprosin.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 13:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/14/5f/1b/z28700692M,Poslanka-Joanna-Lichocka--sejm-RP--13-luty-2020r-.jpg" vspace="2" />Sąd w Gliwicach oddalił powództwo Joanny Lichockiej, która wytoczyła proces Borysowi Budce. Chodzi o reakcje na gest, który posłanka PiS pokazała podczas jednego z głosowań. Szef klubu KO powództwo Lichockiej nazwał "absurdalnym". "Będę się odwoływać" - zapowiedziała z kolei posłanka.

## Toruńska kuria reaguje na rekolekcje. "Takie sceny nigdy nie powinny mieć miejsca. Wyrażamy żal"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29606046,torunska-kuria-reaguje-na-rekolekcje-takie-sceny-nigdy-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29606046,torunska-kuria-reaguje-na-rekolekcje-takie-sceny-nigdy-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 11:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />"Zdajemy sobie sprawę, że sceny, do jakich doszło w trakcie wydarzenia, nigdy nie powinny mieć miejsca. Młodzi ludzie spotkali się z obrazami, które na wydarzeniu religijnym z ich udziałem są nie do zaakceptowania" - czytamy w komunikacie toruńskiej kurii. To reakcja na kontrowersyjne rekolekcje.

## Błażej Kmieciak o autorze reportażu o Janie Pawle II: Nie można mieć do niego pretensji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29605619,blazej-kmieciak-o-autorze-reportazu-o-janie-pawle-ii-nie-mozna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29605619,blazej-kmieciak-o-autorze-reportazu-o-janie-pawle-ii-nie-mozna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 11:21:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/64/d4/1b/z29181540M,Blazej-Kmieciak---zdjecie-archiwalne.jpg" vspace="2" />- My pomyliliśmy sacrum ołtarza z profanum kurii - powiedział Błażej Kmieciak, pytany o reportaż TVN24, w którym ujawniono, że Karol Wojtyła wiedział o pedofilii wśród księży. - Jeżeli nie otworzymy archiwów kościelnych, o co państwowa komisja [ds. pedofilii - red.] z uporem maniaka upomina się od dłuższego czasu, to tego typu materiały mają pełne prawo powstawać. Nie można mieć pretensji do red. Gutowskiego, (...) że zadaje pytania i ma wątpliwości. Te pytania są w nas, ludziach wierzących - podkreślił ustępujący ze stanowiska przewodniczący Państwowej Komisji ds. Pedofilii.

## Kard. Sapieha molestował księży? "Rz": Obciążające dokumenty zostały sfałszowane przez UB
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604741,kard-sapieha-molestowal-ksiezy-rz-obciazajace-dokumenty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604741,kard-sapieha-molestowal-ksiezy-rz-obciazajace-dokumenty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 11:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/da/20/1c/z29493466M,Adam-Sapieha.jpg" vspace="2" />Czy kardynał Adam Sapieha molestował młodych księży? Podają to w wątpliwość dziennikarze "Rzeczpospolitej". Twierdzą, że dotarli do materiałów, które rzucają nowe światło na sprawę słynnego krakowskiego metropolity. Z ich analizy wynikać ma, że "dokumenty, w których opisano erotyczne wyczyny kard. Sapiehy, zostały z dużym prawdopodobieństwem sfałszowane" przez funkcjonariusza UB.

## Abp Gądecki nie chciał przekazać sądowi tajnych akt. Zrobił to Watykan. Pierwsza taka sytuacja w historii
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29605469,gw-watykan-przekazal-sadowi-tajne-akta-w-sprawie-procesu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29605469,gw-watykan-przekazal-sadowi-tajne-akta-w-sprawie-procesu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 10:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/3b/1c/z29605687M,Abp-Stanislaw-Gadecki.jpg" vspace="2" />Watykan przekazał sądowi w Chodzieży tajne akta w sprawie kościelnego procesu księdza pedofila, Krzysztofa G. - ustaliła "Gazeta Wyborcza". - Pierwszy raz Watykan przekazał akta polskiemu sądowi. Szlak został przetarty - ocenił prawnik i teolog oraz były ksiądz Piotr Szeląga w rozmowie z gazetą.

## Rekolekcje w Toruniu. W sieci burza. "Dawno nie widziałem czegoś tak okropnego", "Gdzie jest Episkopat?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29605084,rekolekcje-w-toruniu-w-sieci-burza-dawno-nie-widzialem-czegos.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29605084,rekolekcje-w-toruniu-w-sieci-burza-dawno-nie-widzialem-czegos.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 10:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/eb/3b/1c/z29605355M,Rekolekcje-w-Toruniu.jpg" vspace="2" />- Sprawa jest poważna. Na wideo widzimy nękaną kobietę w majtkach przez jakiegoś gościa, który traktuje ją jak zwierzę. Straszne to jest. Wszystko się dzieje przed ołtarzem. To jakaś katastrofa - powiedziała Joanna Scheuring-Wielgus, pytana o rekolekcje w Toruniu. Do sprawy odniosła się także toruńska kuria, a także kuratorium, które zapowiedziało, że interwencji w tej sprawie nie będzie. - Nie widzimy powodów do reakcji w tej sprawie - stwierdziła kujawsko-pomorska wicekurator oświaty.

## Pogoda. Zima wraca do Polski. We wtorek śnieżyce i mróz do nawet -13 st. C
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604788,pogoda-zima-wraca-do-polski-we-wtorek-sniezyce-i-mroz-do-nawet.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604788,pogoda-zima-wraca-do-polski-we-wtorek-sniezyce-i-mroz-do-nawet.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 09:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/88/3b/1c/z29605256M,Zima-wraca-do-Polski--zdjecie-ilustracyjne-.jpg" vspace="2" />Niż przemieszczający się na Wschód przynosi do Polski chłodne, arktyczne powietrze. Na wtorek prognozowany jest szczyt ochłodzenia. Niemal w całym kraju opady deszczu zostaną zastąpione przez śnieg, a miejscami możemy spodziewać się nawet śnieżyc. Mróz w nocy nasili się, powodując spadek temperatury do nawet -13 st. C. Zamiast wiosny czeka nas krótkotrwała, lecz intensywna zima.

## Pogoda na Wielkanoc - kiedy zrobi się ciepło? Są już pierwsze prognozy długoterminowe [MAPY]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604335,pogoda-na-wielkanoc-co-mowia-pierwsze-prognozy-dlugoterminowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604335,pogoda-na-wielkanoc-co-mowia-pierwsze-prognozy-dlugoterminowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 07:21:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0b/3b/1c/z29604363M,Prognoza-pogody-na-Wielkanoc.jpg" vspace="2" />Patrząc obecnie za okno można odnieść wrażenie, że pogoda zwariowała. Po pięknym, wiosennym tygodniu do Polski powróciła zima, a aura stała się bardzo niestabilna. Jakie będą tegoroczne święta wielkanocne? Odpowiedź można znaleźć w pierwszych prognozach długoterminowych.

## Rekolekcje w Toruniu jak "brutalne filmy". "Zamknij ryj, sz**to!". Ksiądz przeprasza
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604347,rekolekcje-w-toruniu-jak-brutalne-filmy-zamknij-ryj-sz-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604347,rekolekcje-w-toruniu-jak-brutalne-filmy-zamknij-ryj-sz-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 06:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/89/3b/1c/z29604489M,Rekolekcje-w-Toruniu.jpg" vspace="2" />"Zamknij ryj, sz**to! Ty nie jesteś człowiekiem, rozumiesz? Jesteś moim kundlem" - takie słowa miały paść podczas rekolekcji w toruńskim kościele. Przed ołtarzem odegrano tam scenkę, podczas której mężczyzna szarpał, wyzywał i ciągnął za smycz roznegliżowaną kobietę. Wszystko zostało nagrane, a film trafił do sieci. Z rekolekcji tłumaczy się teraz kuria, a Ośrodek Monitorowania Zachowań Rasistowskich i Ksenofobicznych zapowiada zgłoszenie sprawy do prokuratury.

## Pisał o "dzieciach znanej parlamentarzystki". Tomasz Duklanowski wrócił do pracy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604322,tomasz-duklanowski-wrocil-do-pracy-w-radiu-szczecin.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604322,tomasz-duklanowski-wrocil-do-pracy-w-radiu-szczecin.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 05:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/25/29/1c/z29531173M,Tomasz-Duklanowski.jpg" vspace="2" />Tomasz Duklanowski wrócił do pracy w Radiu Szczecin i aktywnie zajmuje się tematami politycznymi - podaje "Press". Redaktor naczelny rozgłośni jest autorem tekstu, który - zdaniem opozycji i mediów - pozwolił na identyfikację ofiar pedofila.

## Z Dunajca wyłowiono zwłoki. Tragiczny finał poszukiwań mężczyzny z Barcic
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604112,z-dunajca-wylowiono-zwloki-tragiczny-final-poszukiwan-mezczyzny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29604112,z-dunajca-wylowiono-zwloki-tragiczny-final-poszukiwan-mezczyzny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-28 04:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/50/3b/1c/z29604176M,Poszukiwania-w-Dunajcu.jpg" vspace="2" />Policja wraz ze strażą pożarną wyłowiła ciało z Dunajca. Jak się okazało, był to mężczyzna, który zaginął w lutym. Wstępnie wykluczono, by do śmierci 32-latka przyczyniły się osoby postronne.

