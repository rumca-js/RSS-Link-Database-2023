# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Apple może nie dać nam wyboru i sprzedawać iPhone 15 tylko z eSIM
 - [https://ithardware.pl/aktualnosci/apple_moze_nie_dac_nam_wyboru_i_sprzedawac_iphone_15_tylko_z_esim-26548.html](https://ithardware.pl/aktualnosci/apple_moze_nie_dac_nam_wyboru_i_sprzedawac_iphone_15_tylko_z_esim-26548.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 21:30:10+00:00

<img src="https://ithardware.pl/artykuly/min/26548_1.jpg" />            iPhone 14 to pierwsza seria smartfon&oacute;w Apple obecna&nbsp;w USA wyłącznie w wersji eSIM. Nie dotyczy to jednak rynku europejskiego, aczkolwiek nic nie trwa wiecznie i producent może zmusić Europejczyk&oacute;w do przesiadki na nowy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_moze_nie_dac_nam_wyboru_i_sprzedawac_iphone_15_tylko_z_esim-26548.html">https://ithardware.pl/aktualnosci/apple_moze_nie_dac_nam_wyboru_i_sprzedawac_iphone_15_tylko_z_esim-26548.html</a></p>

## Zakaz Chińczyków i Rosjan. Japońska agencja kosmiczna wprowadza nowe zasady
 - [https://ithardware.pl/aktualnosci/zakaz_chinczykow_i_rosjan_japonska_agencja_kosmiczna_wprowadza_nowe_zasady-26547.html](https://ithardware.pl/aktualnosci/zakaz_chinczykow_i_rosjan_japonska_agencja_kosmiczna_wprowadza_nowe_zasady-26547.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 20:58:30+00:00

<img src="https://ithardware.pl/artykuly/min/26547_1.jpg" />            Instytut naukowy należący do japońskiej agencji kosmicznej zabronił pracy chińskim i rosyjskim naukowcom, między innymi w celu ochrony wrażliwych informacji technologicznych, kt&oacute;re mogłyby być wykorzystane do cel&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/zakaz_chinczykow_i_rosjan_japonska_agencja_kosmiczna_wprowadza_nowe_zasady-26547.html">https://ithardware.pl/aktualnosci/zakaz_chinczykow_i_rosjan_japonska_agencja_kosmiczna_wprowadza_nowe_zasady-26547.html</a></p>

## Redmi Note 12 Turbo debiutuje na rynku. Jest też wersja dla fanów Harry'ego Pottera
 - [https://ithardware.pl/aktualnosci/redmi_note_12_turbo_debiutuje_na_rynku_jest_tez_wersja_dla_fanow_harry_ego_pottera-26546.html](https://ithardware.pl/aktualnosci/redmi_note_12_turbo_debiutuje_na_rynku_jest_tez_wersja_dla_fanow_harry_ego_pottera-26546.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 18:48:06+00:00

<img src="https://ithardware.pl/artykuly/min/26546_1.jpg" />            Redmi Note 12 Turbo trafił na rynek w Chinach, z kolei w innych krajach ma pojawić się pod nazwą&nbsp;POCO F5. Jest to urządzenie z najnowszym budżetowym Snapdragonem, kt&oacute;re dostało też wersję dla fan&oacute;w Harry'ego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/redmi_note_12_turbo_debiutuje_na_rynku_jest_tez_wersja_dla_fanow_harry_ego_pottera-26546.html">https://ithardware.pl/aktualnosci/redmi_note_12_turbo_debiutuje_na_rynku_jest_tez_wersja_dla_fanow_harry_ego_pottera-26546.html</a></p>

## Japonia dała zielone światło na przejęcie Activision Blizzard przez Microsoft. To duży cios dla Sony
 - [https://ithardware.pl/aktualnosci/japonia_dala_zielone_swiatlo_na_przejecie_activision_blizzard_przez_microsoft_to_duzy_cios_dla_sony-26545.html](https://ithardware.pl/aktualnosci/japonia_dala_zielone_swiatlo_na_przejecie_activision_blizzard_przez_microsoft_to_duzy_cios_dla_sony-26545.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 17:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/26545_1.jpg" />            Telenowela związana z przejęciem Activision Blizzard przed Microsoft trwa w najlepsze. Podczas gdy światowi regulatorzy zastanawiają się nad wydaniem zgody na fuzję, japoński odpowiednik Federalnej Komisji Handlu USA orzekł, że nie widzi...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/japonia_dala_zielone_swiatlo_na_przejecie_activision_blizzard_przez_microsoft_to_duzy_cios_dla_sony-26545.html">https://ithardware.pl/aktualnosci/japonia_dala_zielone_swiatlo_na_przejecie_activision_blizzard_przez_microsoft_to_duzy_cios_dla_sony-26545.html</a></p>

## AMD Ryzen 7 7800X3D przetestowany. Pojawił się w SiSoftware
 - [https://ithardware.pl/aktualnosci/amd_ryzen_7_7800x3d_przetestowany_pojawil_sie_w_sisoftware-26543.html](https://ithardware.pl/aktualnosci/amd_ryzen_7_7800x3d_przetestowany_pojawil_sie_w_sisoftware-26543.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 15:50:30+00:00

<img src="https://ithardware.pl/artykuly/min/26543_1.jpg" />            Wciąż czekamy na wprowadzenie do sprzedaży ostatniego modelu z serii Ryzen 7000X3D. Dziś, na kilka dni przez sklepową premierą, poznaliśmy wyniki testu modelu Ryzen 7 7800X3D w programie SiSoftware. W por&oacute;wnaniu do poprzednika, Ryzena 7...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ryzen_7_7800x3d_przetestowany_pojawil_sie_w_sisoftware-26543.html">https://ithardware.pl/aktualnosci/amd_ryzen_7_7800x3d_przetestowany_pojawil_sie_w_sisoftware-26543.html</a></p>

## Ubisoft odpuszcza targi E3. Firma zorganizuje własny pokaz
 - [https://ithardware.pl/aktualnosci/ubisoft_odpuszcza_targi_e3_firma_zorganizuje_wlasny_pokaz-26544.html](https://ithardware.pl/aktualnosci/ubisoft_odpuszcza_targi_e3_firma_zorganizuje_wlasny_pokaz-26544.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 15:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26544_1.jpg" />            Niegdyś popularne targi E3 odbywające się co roku w Los Angeles (Stany Zjednoczone), dziś tracą na znaczeniu. Dzieje się tak, bo z udziału w wydarzeniu rezygnuje kolejna firma, Ubisoft, kt&oacute;ra dołącza do Microsoftu, Sony oraz...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ubisoft_odpuszcza_targi_e3_firma_zorganizuje_wlasny_pokaz-26544.html">https://ithardware.pl/aktualnosci/ubisoft_odpuszcza_targi_e3_firma_zorganizuje_wlasny_pokaz-26544.html</a></p>

## Dominująca pozycja AMD Threadripper Pro. Sprzedaż Intel Xeon stanowiła tylko 5%
 - [https://ithardware.pl/aktualnosci/dominujaca_pozycja_amd_threadripper_pro_sprzedaz_intel_xeon_stanowila_tylko_5-26542.html](https://ithardware.pl/aktualnosci/dominujaca_pozycja_amd_threadripper_pro_sprzedaz_intel_xeon_stanowila_tylko_5-26542.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 14:33:30+00:00

<img src="https://ithardware.pl/artykuly/min/26542_1.jpg" />            Zagraniczna firma Puget Systems, zajmująca się budową komputer&oacute;w oraz stacji roboczych, udostępniła dane sprzedażowe za 2022 rok dla wybranych kategorii produkt&oacute;w. W sprzedaży konsumenckich CPU bez wątpienia rządził Intel,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dominujaca_pozycja_amd_threadripper_pro_sprzedaz_intel_xeon_stanowila_tylko_5-26542.html">https://ithardware.pl/aktualnosci/dominujaca_pozycja_amd_threadripper_pro_sprzedaz_intel_xeon_stanowila_tylko_5-26542.html</a></p>

## NVIDIA GeForce vs AMD Radeon. Jaką kartę graficzną kupić w marcu 2023?
 - [https://ithardware.pl/poradniki/jaka_karta_graficzna_marzec_2023-26539.html](https://ithardware.pl/poradniki/jaka_karta_graficzna_marzec_2023-26539.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 13:37:00+00:00

<img src="https://ithardware.pl/artykuly/min/26539_1.jpg" />            Rynek kart graficznych jest już ustabilizowany od dawna. Ceny nie szaleją, jak jeszcze podczas szału kryptowalutowego, a p&oacute;łki są zapełnione na tyle, że po wizycie w dowolnym sklepie z całą pewnością wyjdziecie z interesującym was...
            <p>Pełna wersja strony <a href="https://ithardware.pl/poradniki/jaka_karta_graficzna_marzec_2023-26539.html">https://ithardware.pl/poradniki/jaka_karta_graficzna_marzec_2023-26539.html</a></p>

## Przeciek ujawnia warianty karty GeForce RTX 4070 od MSI i Gigabyte i potwierdza pojemność VRAM
 - [https://ithardware.pl/aktualnosci/przeciek_ujawnia_warianty_karty_geforce_rtx_4070_od_msi_i_gigabyte_i_potwierdza_pojemnosc_vram-26537.html](https://ithardware.pl/aktualnosci/przeciek_ujawnia_warianty_karty_geforce_rtx_4070_od_msi_i_gigabyte_i_potwierdza_pojemnosc_vram-26537.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 12:28:01+00:00

<img src="https://ithardware.pl/artykuly/min/26537_1.jpg" />            Jak ujawnia portal VideoCardz, Gigabyte i MSI szykują co najmniej dziewięć modeli kart graficznych GeForce RTX 4070, a przynajmniej tak wynika ze zgłoszeń tych producent&oacute;w do organ&oacute;w regulacyjnych.

Przypominamy, że GeForce RTX 4070...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/przeciek_ujawnia_warianty_karty_geforce_rtx_4070_od_msi_i_gigabyte_i_potwierdza_pojemnosc_vram-26537.html">https://ithardware.pl/aktualnosci/przeciek_ujawnia_warianty_karty_geforce_rtx_4070_od_msi_i_gigabyte_i_potwierdza_pojemnosc_vram-26537.html</a></p>

## ChatGPT uruchomiony na blisko 40-letnim komputerze IBM
 - [https://ithardware.pl/aktualnosci/chatgpt_uruchomiony_na_blisko_40_letnim_komputerze_ibm-26534.html](https://ithardware.pl/aktualnosci/chatgpt_uruchomiony_na_blisko_40_letnim_komputerze_ibm-26534.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 11:42:01+00:00

<img src="https://ithardware.pl/artykuly/min/26534_1.jpg" />            ChatGPT OpenAI może reprezentować najnowocześniejszą technologię AI, ale doświadczenie użytkownika sprowadza się do wprowadzania i otrzymywania tekstu i połączenia z internetem. Jeden z modder&oacute;w doszedł do wniosku, że 39-letni komputer...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chatgpt_uruchomiony_na_blisko_40_letnim_komputerze_ibm-26534.html">https://ithardware.pl/aktualnosci/chatgpt_uruchomiony_na_blisko_40_letnim_komputerze_ibm-26534.html</a></p>

## Steam porzuca starsze wersje Windowsa. Na tych systemach już nie pogracie...
 - [https://ithardware.pl/aktualnosci/steam_porzuca_starsze_wersje_windowsa_na_tych_systemach_juz_nie_pogracie-26541.html](https://ithardware.pl/aktualnosci/steam_porzuca_starsze_wersje_windowsa_na_tych_systemach_juz_nie_pogracie-26541.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 11:00:20+00:00

<img src="https://ithardware.pl/artykuly/min/26541_1.jpg" />            Niekt&oacute;rzy jeszcze niedawno twierdzili, że Windows 7 będzie wiecznie żywy, jednak pojawiły się kolejne powody, żeby niezdecydowani przeszli jednak na nowsze systemy Microsoftu. Steam oświadczył, że kończy ze wsparciem dla Windows 7 i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/steam_porzuca_starsze_wersje_windowsa_na_tych_systemach_juz_nie_pogracie-26541.html">https://ithardware.pl/aktualnosci/steam_porzuca_starsze_wersje_windowsa_na_tych_systemach_juz_nie_pogracie-26541.html</a></p>

## Diablo 4 drugą grą AAA z obsługą technologii DirectStorage
 - [https://ithardware.pl/aktualnosci/diablo_4_druga_gra_aaa_z_obsluga_technologii_directstorage-26533.html](https://ithardware.pl/aktualnosci/diablo_4_druga_gra_aaa_z_obsluga_technologii_directstorage-26533.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 10:14:01+00:00

<img src="https://ithardware.pl/artykuly/min/26533_1.jpg" />            Kiedy Microsoft zapowiadał DirectStorage, prezentował tę technologię jako przełom, kt&oacute;ry odmieni oblicze pecetowych gier. Ta zadebiutowała już w pierwszej grze na początku tego roku, gdzie rzeczywiście przyniosła mocne przyspieszenie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/diablo_4_druga_gra_aaa_z_obsluga_technologii_directstorage-26533.html">https://ithardware.pl/aktualnosci/diablo_4_druga_gra_aaa_z_obsluga_technologii_directstorage-26533.html</a></p>

## Strażacy gasili płonącego "elektryka" przez 21 godzin. To rekord Polski...
 - [https://ithardware.pl/aktualnosci/strazacy_gasili_plonacego_elektryka_przez_21_godzin_to_rekord_polski-26540.html](https://ithardware.pl/aktualnosci/strazacy_gasili_plonacego_elektryka_przez_21_godzin_to_rekord_polski-26540.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 09:59:30+00:00

<img src="https://ithardware.pl/artykuly/min/26540_1.jpg" />            Jednym z częściej przytaczanych argument&oacute;w przeciwko autom elektrycznym, jest ryzyko pożaru i choć statystycznie pożary niekoniecznie występują częściej niż w autach spalinowych, to problem leży zupełnie gdzie indziej.

W przypadku...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/strazacy_gasili_plonacego_elektryka_przez_21_godzin_to_rekord_polski-26540.html">https://ithardware.pl/aktualnosci/strazacy_gasili_plonacego_elektryka_przez_21_godzin_to_rekord_polski-26540.html</a></p>

## Wyciekły zdjęcia płyty głównej AMD A620 od ASRock. Szczegóły supertanich modeli pod nowe Ryzeny
 - [https://ithardware.pl/aktualnosci/wyciekly_zdjecia_plyty_glownej_amd_a620_od_asrock_szczegoly_supertanich_modeli_pod_nowe_ryzeny-26535.html](https://ithardware.pl/aktualnosci/wyciekly_zdjecia_plyty_glownej_amd_a620_od_asrock_szczegoly_supertanich_modeli_pod_nowe_ryzeny-26535.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 09:34:01+00:00

<img src="https://ithardware.pl/artykuly/min/26535_1.jpg" />            AMD w trakcie ogłoszenia procesor&oacute;w Ryzen serii 7000 i platformy AM5 we wrześniu zeszłego roku obiecało, że ceny dedykowanych im płyt gł&oacute;wnych będą zaczynać się od 125 USD. Sześć miesięcy p&oacute;źniej nadal nie udało się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wyciekly_zdjecia_plyty_glownej_amd_a620_od_asrock_szczegoly_supertanich_modeli_pod_nowe_ryzeny-26535.html">https://ithardware.pl/aktualnosci/wyciekly_zdjecia_plyty_glownej_amd_a620_od_asrock_szczegoly_supertanich_modeli_pod_nowe_ryzeny-26535.html</a></p>

## Tim Cook znów wychwala Chiny. To "symbiotyczna" relacja
 - [https://ithardware.pl/aktualnosci/tim_cook_znow_wychwala_chiny_to_symbiotyczna_relacja-26538.html](https://ithardware.pl/aktualnosci/tim_cook_znow_wychwala_chiny_to_symbiotyczna_relacja-26538.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 09:14:50+00:00

<img src="https://ithardware.pl/artykuly/min/26538_1.jpg" />            Tim Cook pojawił się na tegorocznym&nbsp;China Development Forum, gdzie wbrew obecnemu trendowi, nie szczędził pochwał wobec kraju.

Apple wielokrotnie było w przeszłości krytykowane za sw&oacute;j związek z Chinami i często aż przesadne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tim_cook_znow_wychwala_chiny_to_symbiotyczna_relacja-26538.html">https://ithardware.pl/aktualnosci/tim_cook_znow_wychwala_chiny_to_symbiotyczna_relacja-26538.html</a></p>

## Firma nie może produkować pocisków artyleryjskich przez TikToka
 - [https://ithardware.pl/aktualnosci/firma_nie_moze_produkowac_pociskow_artyleryjskich_przez_tiktoka-26536.html](https://ithardware.pl/aktualnosci/firma_nie_moze_produkowac_pociskow_artyleryjskich_przez_tiktoka-26536.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 08:10:01+00:00

<img src="https://ithardware.pl/artykuly/min/26536_1.jpg" />            TikTok ostatnimi czasy często pojawia się w nagł&oacute;wkach portali internetowych, a to za sprawą ban&oacute;w rząd&oacute;w kolejnych kraj&oacute;w na tę aplikację czy oskarżeń o udostępnianie danych użytkownik&oacute;w chińskiemu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/firma_nie_moze_produkowac_pociskow_artyleryjskich_przez_tiktoka-26536.html">https://ithardware.pl/aktualnosci/firma_nie_moze_produkowac_pociskow_artyleryjskich_przez_tiktoka-26536.html</a></p>

## Papież Franciszek pochwala rozwój sztucznej inteligencji, choć sam stań się jej ofiarą
 - [https://ithardware.pl/aktualnosci/papiez_franciszek_pochwala_rozwoj_sztucznej_inteligencji_choc_sam_stan_sie_jej_ofiara-26532.html](https://ithardware.pl/aktualnosci/papiez_franciszek_pochwala_rozwoj_sztucznej_inteligencji_choc_sam_stan_sie_jej_ofiara-26532.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 07:01:35+00:00

<img src="https://ithardware.pl/artykuly/min/26532_1.jpg" />            Po uruchomieniu nowych generatywnych sztucznych inteligencji, takich jak ChatGPT, Bing Chat, Google Bard, DuckAssist i Brave Summarizer, papież Franciszek postanowił podzielić się swoimi przemyśleniami na temat tego typu technologii na dorocznym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/papiez_franciszek_pochwala_rozwoj_sztucznej_inteligencji_choc_sam_stan_sie_jej_ofiara-26532.html">https://ithardware.pl/aktualnosci/papiez_franciszek_pochwala_rozwoj_sztucznej_inteligencji_choc_sam_stan_sie_jej_ofiara-26532.html</a></p>

## Rekordzista próbował przemycić do Chin 239 procesorów Intela przyklejonych do swojego ciała
 - [https://ithardware.pl/aktualnosci/rekordzista_probowal_przemycic_do_chin_239_procesorow_intela_przyklejonych_do_swojego_ciala-26531.html](https://ithardware.pl/aktualnosci/rekordzista_probowal_przemycic_do_chin_239_procesorow_intela_przyklejonych_do_swojego_ciala-26531.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-28 06:16:43+00:00

<img src="https://ithardware.pl/artykuly/min/26531_1.jpg" />            Chińscy celnicy mają ostatnimi czasy ręce pełne roboty. Pisaliśmy już o mężczyźnie, kt&oacute;ry obkleił się 160 procesorami Intela z 12. generacji czy kobiecie, kt&oacute;ra w sztucznym ciążowym brzuchu pr&oacute;bowała przemycić do kraju...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rekordzista_probowal_przemycic_do_chin_239_procesorow_intela_przyklejonych_do_swojego_ciala-26531.html">https://ithardware.pl/aktualnosci/rekordzista_probowal_przemycic_do_chin_239_procesorow_intela_przyklejonych_do_swojego_ciala-26531.html</a></p>

