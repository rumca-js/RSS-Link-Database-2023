# Source:Screen Junkies, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A, language:en-US

## Honest Trailers | Dragon Ball Super: Super Hero
 - [https://www.youtube.com/watch?v=-ju1xmRL8tI](https://www.youtube.com/watch?v=-ju1xmRL8tI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A
 - date published: 2023-03-28 17:00:00+00:00

►►Subscribe to ScreenJunkies!► https://fandom.link/SJSubscribe

►►We're breaking down just how badass Vegeta is!► https://youtu.be/lgV_XwDUWkE

►►Watch the Honest Trailers Commentary with the Writers!► https://youtube.com/live/MC4slNGmhDs

Honest Trailers | Dragon Ball Super: Super Hero
Voice Narration: Jon Bailey aka Epic Voice Guy
Title Design: Robert Holtby
Written by: Spencer Gilbert, Danielle Radford, Lon Harris
Produced by: Spencer Gilbert
Edited by: Kevin Williamsen
Post-Production Manager: Emin Bassavand
Post-Production Coordinator: Mikołaj Kossakowski
Assistant Editor: Rebecca Castaneda
Director of Video Production: Max Dionne
#HonestTrailers

