# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Apple Rolls Out Buy Now, Pay Later Plan
 - [https://www.wsj.com/articles/apple-rolls-out-buy-now-pay-later-plan-640ae583?mod=rss_Technology](https://www.wsj.com/articles/apple-rolls-out-buy-now-pay-later-plan-640ae583?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-28 18:39:00+00:00

The tech company will let users apply for loans of as much $1,000 with no interest or fees.

## Why Are Flip-Up Sunglasses Suddenly Everywhere?
 - [https://www.wsj.com/articles/flip-up-sunglasses-are-suddenly-everywhere-80a86b56?mod=rss_Technology](https://www.wsj.com/articles/flip-up-sunglasses-are-suddenly-everywhere-80a86b56?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-28 17:15:00+00:00

Forget Dwayne Wayne. New styles from emergent adventuring companies like Pit Viper have made the dated design genuinely covetable. Here, three of our favorite versions.

## Concertgoers Are Behaving Badly. Blame TikTok.
 - [https://www.wsj.com/articles/concertgoers-are-behaving-badly-blame-tiktok-11ce4737?mod=rss_Technology](https://www.wsj.com/articles/concertgoers-are-behaving-badly-blame-tiktok-11ce4737?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-28 12:00:00+00:00

It isn’t just about the music anymore: Fans want their viral moment with a superstar.

## The Jobs Most Exposed to ChatGPT
 - [https://www.wsj.com/articles/the-jobs-most-exposed-to-chatgpt-e7ceebf0?mod=rss_Technology](https://www.wsj.com/articles/the-jobs-most-exposed-to-chatgpt-e7ceebf0?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-28 11:00:00+00:00

A new study finds that AI tools could more quickly handle at least half of the tasks that auditors, interpreters and writers do now.

## For Chip Makers, a Choice Between the U.S. and China Looms
 - [https://www.wsj.com/articles/for-chip-makers-a-choice-between-the-u-s-and-china-looms-5450df30?mod=rss_Technology](https://www.wsj.com/articles/for-chip-makers-a-choice-between-the-u-s-and-china-looms-5450df30?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-28 09:00:00+00:00

Washington seeks to steer the semiconductor supply chain using restrictions under the Chips Act.

## U.S., Japan Strike Deal on Minerals Used in Batteries for Electric Cars
 - [https://www.wsj.com/articles/u-s-and-japan-strike-deal-on-minerals-used-in-batteries-for-electric-cars-bbf8b8ee?mod=rss_Technology](https://www.wsj.com/articles/u-s-and-japan-strike-deal-on-minerals-used-in-batteries-for-electric-cars-bbf8b8ee?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-28 08:52:00+00:00

The move aims to address two of the Biden administration’s problems: its restrictions on EV subsidies and China’s supply-chain dominance.

## Facebook Parent Plans Lower Bonus Payouts for Some Staff
 - [https://www.wsj.com/articles/facebook-parent-plans-lower-bonus-payouts-for-some-staff-c7b0ddd?mod=rss_Technology](https://www.wsj.com/articles/facebook-parent-plans-lower-bonus-payouts-for-some-staff-c7b0ddd?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-28 05:57:00+00:00

Meta Platforms adjusts its performance review process, saying it is ‘optimizing’ for the year ahead.

