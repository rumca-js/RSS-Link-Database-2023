# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Rozmowy z rolnikami nie poszły po myśli rządu. "Rozpoczynamy strajk okupacyjny"
 - [https://businessinsider.com.pl/wiadomosci/strajk-rolnikow-rozmowy-nie-przyniosly-efektu/f210zc2](https://businessinsider.com.pl/wiadomosci/strajk-rolnikow-rozmowy-nie-przyniosly-efektu/f210zc2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 19:24:10+00:00

Wicepremier i minister rolnictwa Henryk Kowalczyk po spotkaniu z rolnikami poinformował, że rząd złoży w Brukseli wniosek o "zastosowanie klauzuli ochronnej dotyczącej granicy polsko-ukraińskiej". Rolnicy nie są jednak zadowoleni z efektów. Lider Agrounii poinformował o rozpoczęciu strajku okupacyjnego w budynku resortu.

## Litwa ostrzega, że Białoruś szykuje kolejną falę migracyjną
 - [https://businessinsider.com.pl/wiadomosci/ostrzezenie-z-wilna-bialorus-szykuje-kolejna-fale-migracyjna/k9glh7x](https://businessinsider.com.pl/wiadomosci/ostrzezenie-z-wilna-bialorus-szykuje-kolejna-fale-migracyjna/k9glh7x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 17:58:00+00:00

Białoruś wznowiła bezpośrednie połączenia lotnicze z Iranem. Pierwszy lot miał odbyć się w środę 29 marca. Szefowa litewskiego MSW ostrzegła przed kolejną "falą migracyjną"

## Elon Musk i setki biznesmenów wezwali do przerwy w rozwoju sztucznej inteligencji. "Niekontrolowany wyścig"
 - [https://businessinsider.com.pl/technologie/nowe-technologie/elon-musk-i-setki-biznesmenow-wezwali-do-przerwy-w-rozwoju-sztucznej-inteligencji/me2v3sn](https://businessinsider.com.pl/technologie/nowe-technologie/elon-musk-i-setki-biznesmenow-wezwali-do-przerwy-w-rozwoju-sztucznej-inteligencji/me2v3sn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 17:41:30+00:00

Setki biznesmenów, inwestorów i ekspertów od sztucznej inteligencji, w tym m.in. Elon Musk, wezwało we wspólnym liście do przynajmniej sześciomiesięcznej przerwy w rozwijaniu systemów AI zdolniejszych od opublikowanego w marcu GPT-4. Sygnatariusze ostrzegają przed nieprzewidywalnymi skutkami wyścigu o tworzenie coraz potężniejszych modeli.

## Produkują mąkę i idą na giełdę. Liczą na miliard dolarów
 - [https://businessinsider.com.pl/biznes/szykuje-sie-nietypowy-debiut-na-saudyjskiej-gieldzie-gra-o-miliard-za-mielenie-zboz/vkddf6l](https://businessinsider.com.pl/biznes/szykuje-sie-nietypowy-debiut-na-saudyjskiej-gieldzie-gra-o-miliard-za-mielenie-zboz/vkddf6l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 17:39:24+00:00

Miliardowe debiuty giełdowe kojarzą się przede wszystkim z nowymi technologiami. Okazuje się jednak, że tradycyjny przemysł sięgający czasów prehistorycznych, również może mieć takie ambicje. Dowodzą tego plany firmy z Arabii Saudyjskiej.

## Jest nowy prezes Pracodawców RP. To były prezydent Wrocławia
 - [https://businessinsider.com.pl/biznes/jest-nowy-prezes-pracodawcow-rp-to-znany-samorzadowiec/664w0t2](https://businessinsider.com.pl/biznes/jest-nowy-prezes-pracodawcow-rp-to-znany-samorzadowiec/664w0t2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 17:29:20+00:00

Rafał Dutkiewicz został wybrany nowym prezesem Pracodawców RP. Zmiana została wymuszona aresztowaniem poprzedniego prezesa Rafała Baniaka, który w efekcie zrezygnował ze stanowiska.

## Buda: rząd chce zniesienia pozwoleń na budowę domów jednorodzinnych
 - [https://businessinsider.com.pl/wiadomosci/buda-rzad-chce-zniesienia-pozwolen-na-budowe-domow-jednorodzinnych/2pm7q0n](https://businessinsider.com.pl/wiadomosci/buda-rzad-chce-zniesienia-pozwolen-na-budowe-domow-jednorodzinnych/2pm7q0n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 17:09:51+00:00

Rząd planuje wprowadzenie przepisów zakładających odejście od konieczności uzyskania pozwolenia na budowę przy budynkach jednorodzinnych, budowanych na własne potrzeby — wynika z wypowiedzi ministra rozwoju i technologii Waldemara Budy. Dzisiaj przyjął projekt przepisów w tej sprawie.

## Rząd chce zlikwidować pozwolenia na budowę domów. Planuje też ułatwienia dla schronów
 - [https://businessinsider.com.pl/wiadomosci/ida-zmiany-na-budowach-rzad-planuje-zniesc-pozwolenia-i-ulatwi-kopanie-schronow/2pm7q0n](https://businessinsider.com.pl/wiadomosci/ida-zmiany-na-budowach-rzad-planuje-zniesc-pozwolenia-i-ulatwi-kopanie-schronow/2pm7q0n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 17:09:51+00:00

Rząd planuje wprowadzenie przepisów zakładających odejście od konieczności uzyskania pozwolenia na budowę przy budynkach jednorodzinnych, budowanych na własne potrzeby — wynika z wypowiedzi ministra rozwoju i technologii Waldemara Budy. Dzisiaj przyjął projekt przepisów w tej sprawie.

## Inwestujesz w fundusze, na giełdzie lub Forex? Będą zmiany w podatkach. Sprawdź, ile zyskasz
 - [https://businessinsider.com.pl/prawo/podatki/podatek-od-zyskow-i-strat-z-inwestycji-kapitalowych-szykuje-sie-rewolucja/70lt2ex](https://businessinsider.com.pl/prawo/podatki/podatek-od-zyskow-i-strat-z-inwestycji-kapitalowych-szykuje-sie-rewolucja/70lt2ex)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 16:37:54+00:00

Szykuje się mała rewolucja podatkowa dla inwestorów. Dziś zysków z akcji nie można rozliczyć razem ze stratami np. z funduszy inwestycyjnych, funduszy pasywnych, czy strat z Foreksu, mimo że wszystko są to zyski kapitałowe. I to się zmieni. Ministerstwo Finansów poparło poprawki PiS korzystne dla inwestujących np. w fundusze. Wiemy też, co z podatkiem Belki.

## PGE i ZE PAK dostały zielone światło na utworzenie atomowej spółki
 - [https://businessinsider.com.pl/biznes/pge-i-ze-pak-dostaly-zielone-swiatlo-na-utworzenie-atomowej-spolki/4p5fwwf](https://businessinsider.com.pl/biznes/pge-i-ze-pak-dostaly-zielone-swiatlo-na-utworzenie-atomowej-spolki/4p5fwwf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 16:34:47+00:00

PGE i ZE PAK uzyskały zgodę Urzędu Ochrony Konkurencji i Konsumentów na utworzenie spółki, której zadaniem będzie proces przygotowań i analiz na potrzeby planowanej budowy elektrowni jądrowej.

## Skompromitowany założyciel FTX straci dostęp do swojej ulubionej gry "League of Legends"
 - [https://businessinsider.com.pl/wiadomosci/skompromitowany-zalozyciel-ftx-straci-dostep-do-swojej-ulubionej-gry-league-of/5d7vq15](https://businessinsider.com.pl/wiadomosci/skompromitowany-zalozyciel-ftx-straci-dostep-do-swojej-ulubionej-gry-league-of/5d7vq15)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 16:01:12+00:00

Sam Bankman-Fried był tak zapalonym graczem w "League of Legends", że grał podczas spotkań biznesowych. Teraz jego prawnicy mówią, że dla króla kryptowalut skończyło się granie w gry online.

## Pepco rozbudowuje nową markę na polskim rynku. Ma już 200 sklepów
 - [https://businessinsider.com.pl/firmy/marka-ze-stajni-pepco-rozpycha-sie-na-polskim-rynku-osiagnela-wlasnie-kolejny-poziom/rtw4sej](https://businessinsider.com.pl/firmy/marka-ze-stajni-pepco-rozpycha-sie-na-polskim-rynku-osiagnela-wlasnie-kolejny-poziom/rtw4sej)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 15:58:00+00:00

Notowany na giełdzie właściciel sieci sklepów Pepco poinformował, że otworzył w Kłodzku 200. sklep pod szyldem Dealz. Ma to być dopiero początek ekspansji.

## Nowy prezes Państwowej Agencji Atomistyki
 - [https://businessinsider.com.pl/wiadomosci/jest-nowy-prezes-panstwowej-agencji-atomistyki/6z5e5hv](https://businessinsider.com.pl/wiadomosci/jest-nowy-prezes-panstwowej-agencji-atomistyki/6z5e5hv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 15:35:38+00:00

Andrzej Głowacki stanął na czele Państwowej Agencji Atomistyki. Obowiązki szefa PAA wykonywał już od połowy grudnia 2022 r.

## Putin mówił o odnalezieniu "anteny". Ustalenia Duńczyków go ośmieszają
 - [https://businessinsider.com.pl/wiadomosci/uszkodzenie-nord-stream-dunczycy-wydobyli-obiekt-i-juz-wiedza-co-to-jest/bmh96hz](https://businessinsider.com.pl/wiadomosci/uszkodzenie-nord-stream-dunczycy-wydobyli-obiekt-i-juz-wiedza-co-to-jest/bmh96hz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 15:29:22+00:00

Najnowsze odkrycie duńskich ekspertów nie spodoba się Władimirowi Putinowi. Polityk przekonywał, że Gazprom znalazł dowód na sabotaż gazociągów Nord Stream. Duńska Agencja Energii przekreśliła te narrację, informując, że znaleziony przedmiot to "niegroźna boja dymna".

## Szef największego polskiego banku ma stracić stanowisko
 - [https://businessinsider.com.pl/biznes/szef-najwiekszego-polskiego-banku-ma-stracic-stanowisko-karuzela-nazwisk-ruszyla/gf9j6dw](https://businessinsider.com.pl/biznes/szef-najwiekszego-polskiego-banku-ma-stracic-stanowisko-karuzela-nazwisk-ruszyla/gf9j6dw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 15:04:19+00:00

W najbliższych dniach stanowisko ma stracić Paweł Gruza, prezes PKO BP — nieoficjalnie ustalili dziennikarze RMF FM. O tym, że jego pozycja jest zagrożona, Business Insider pisał pod koniec lutego.

## Masz umowę na czas określony? Przez zmianę przepisów możesz stracić pracę. Sprawdź, jak zachować etat
 - [https://businessinsider.com.pl/prawo/praca/umowa-na-czas-okreslony-jak-uniknac-zwolnienia-przez-zmiany-w-kodeksie-pracy/83l6dwy](https://businessinsider.com.pl/prawo/praca/umowa-na-czas-okreslony-jak-uniknac-zwolnienia-przez-zmiany-w-kodeksie-pracy/83l6dwy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 15:00:00+00:00

W firmach tworzone są właśnie listy osób zatrudnionych na czas określony, które dostaną wypowiedzenie. Pracodawcy się spieszą, bo już w kwietniu wejdą w życie przepisy, które utrudnią ich zwalnianie. Wyjaśniamy co zrobić, by zachować etat.

## Dobre wieści dla kierowców. Paliwa nie przestają tanieć
 - [https://businessinsider.com.pl/twoje-pieniadze/diesel-wciaz-tanieje-cena-zbliza-sie-do-benzyny/525z9fs](https://businessinsider.com.pl/twoje-pieniadze/diesel-wciaz-tanieje-cena-zbliza-sie-do-benzyny/525z9fs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 14:34:33+00:00

Analitycy mają dobre wiadomości dla kierowców. Paliwa tanieją kolejny tydzień z rzędu i dotyczy to zarówno benzyny, jak i oleju napędowego, którego cena zbliża się do ceny Pb95.

## Rekordowo dużo oddanych mieszkań. Ale hossa się kończy i rynek szuka punktu równowagi
 - [https://businessinsider.com.pl/gospodarka/hossa-sie-konczy-rynek-mieszkaniowy-szuka-punktu-rownowagi/h3vnsvd](https://businessinsider.com.pl/gospodarka/hossa-sie-konczy-rynek-mieszkaniowy-szuka-punktu-rownowagi/h3vnsvd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 14:15:09+00:00

W ostatnich miesiącach 2022 r. oddano do użytkowania w Polsce rekordowo wysoką liczbę mieszkań. Jednak mocno spada liczba wydawanych pozwoleń na budowę oraz rozpoczynanych inwestycji, co źle wróży ofercie mieszkań w kolejnych latach. Pozytywną informacją jest malejąca presja na wzrost cen materiałów budowlanych, robocizny i gruntów.

## Francuski koncern: Rosja intensyfikuje cyberataki na sojuszników Ukrainy. Celem m.in. Polska
 - [https://businessinsider.com.pl/wiadomosci/francuski-koncern-rosja-intensyfikuje-cyberataki-na-sojusznikow-ukrainy-celem-min/yehbqzq](https://businessinsider.com.pl/wiadomosci/francuski-koncern-rosja-intensyfikuje-cyberataki-na-sojusznikow-ukrainy-celem-min/yehbqzq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 14:10:34+00:00

Po niepowodzeniu cybernetycznej wojny przeciwko Ukrainie, Rosja intensyfikuje ataki na jej sojuszników — napisał w raporcie zamieszczonym na swojej stronie internetowej francuski koncern technologiczny Thales.

## Związkowcy zażądali rozmów w sprawie emerytur nauczycieli. Czarnek: proszę uprzejmie
 - [https://businessinsider.com.pl/poradnik-finansowy/zwiazkowcy-zazadali-rozmow-w-sprawie-emerytur-nauczycieli-czarnek-prosze-uprzejmie/cnhfmbe](https://businessinsider.com.pl/poradnik-finansowy/zwiazkowcy-zazadali-rozmow-w-sprawie-emerytur-nauczycieli-czarnek-prosze-uprzejmie/cnhfmbe)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 13:42:40+00:00

Minister edukacji i nauki Przemysław Czarnek poinformował w środę, że zaprasza Związek Nauczycielstwa Polskiego na rozmowy w sprawie emerytur po Wielkanocy. Zaznaczył, że resort jest gotowy do przedstawienia projektów rozwiązań legislacyjnych.

## Polskie statki pływają pod obcą banderą. Tak rząd chce z tym walczyć
 - [https://businessinsider.com.pl/gospodarka/polskie-statki-plywaja-pod-obca-bandera-tak-rzad-chce-z-tym-walczyc/ymb3cbl](https://businessinsider.com.pl/gospodarka/polskie-statki-plywaja-pod-obca-bandera-tak-rzad-chce-z-tym-walczyc/ymb3cbl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 13:21:36+00:00

"Lech Kaczyński" nie jest wyjątkiem. Właściwie każdy "polski" statek nie jest do końca polski – jednostki pływają bowiem pod obcymi, znacznie tańszymi banderami. – Powrót statków krajowych pod polską banderę pozostaje jednym z naszych priorytetów – mówi tymczasem Business Insiderowi rzecznik prasowy Ministerstwa Infrastruktury Szymon Huptyś. I tłumaczy, co ma skłonić armatorów do takiej decyzji.

## "Sztuczna inteligencja to ogromna szansa dla ludzkości". Ekspert AI tłumaczy fenomen ChatGPT
 - [https://businessinsider.com.pl/technologie/digital-poland/ekspert-ai-tlumaczy-fenomen-chatgpt/fqd59r9](https://businessinsider.com.pl/technologie/digital-poland/ekspert-ai-tlumaczy-fenomen-chatgpt/fqd59r9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 13:20:20+00:00

Choć programy i urządzenia oparte na sztucznej inteligencji (AI) mogą wykonywać wiele zadań za nas, nie oznacza to, że praca w każdym zawodzie straci sens. – Rozwój sztucznej inteligencji wymusi tworzenie nowych miejsc pracy, które będą wymagały umiejętności związanych z obsługą i rozwijaniem tych nowoczesnych technologii – mówi dr Przemysław Chojecki. Dlatego tak ważne jest, abyśmy dostosowali się do tych zmian, a jednym z kluczowych aspektów jest edukacja i stałe podnoszenie swoich umiejętności.

## Czesi kontynuują pauzę mimo wysokiej inflacji
 - [https://businessinsider.com.pl/finanse/czesi-maja-inflacje-rownie-wysoka-jak-nasza-ale-takze-oni-nie-chca-juz-podnosic-stop/ldvkxmj](https://businessinsider.com.pl/finanse/czesi-maja-inflacje-rownie-wysoka-jak-nasza-ale-takze-oni-nie-chca-juz-podnosic-stop/ldvkxmj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 13:19:21+00:00

Narodowy Bank Czeski utrzymał główną stopę procentową na poziomie 7 proc. - podał bank w komunikacie po zakończeniu środowego posiedzenia. To decyzja zgodna z oczekiwaniami.

## Firma córki Pieskowa zarobiła fortunę. Tak elity Kremla dorabiają się na wojnie
 - [https://businessinsider.com.pl/wiadomosci/elity-kremla-dorabiaja-sie-na-wojnie-firma-corki-pieskowa-zarobila-fortune/0msqm52](https://businessinsider.com.pl/wiadomosci/elity-kremla-dorabiaja-sie-na-wojnie-firma-corki-pieskowa-zarobila-fortune/0msqm52)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 12:50:43+00:00

Firma Centrum Moskwa działa od 2004 r. i do 2021 r. nie wykazywała zysków albo były one bliskie zera. Dopiero od niedawna wzrosła jej aktywność i przychody. Współwłaścicielką firmy jest Lizawieta Pieskowa, córka rzecznika Kremla. Ostatni rok – czyli okres inwazji Rosji na Ukrainę – okazał się dla niej wyjątkowo dochodowy.

## Będą wielkie inwestycje w amunicję. Pójdą na to miliardy
 - [https://businessinsider.com.pl/gospodarka/premier-zapowiada-wielkie-inwestycje-w-amunicje/fe4f1ld](https://businessinsider.com.pl/gospodarka/premier-zapowiada-wielkie-inwestycje-w-amunicje/fe4f1ld)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 12:43:34+00:00

Chcemy przeznaczyć w najbliższym czasie do 2 mld zł na inwestycje związane z produkcją amunicji – ogłosił premier Mateusz Morawiecki.

## Linie lotnicze ukarane. Narzucały stewardesom surowe zasady dotyczące obuwia i makijażu
 - [https://businessinsider.com.pl/wiadomosci/linie-lotnicze-ukarane-narzucaly-stewardesom-surowe-zasady-dotyczace-obuwia-i/pezrwr4](https://businessinsider.com.pl/wiadomosci/linie-lotnicze-ukarane-narzucaly-stewardesom-surowe-zasady-dotyczace-obuwia-i/pezrwr4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 12:43:12+00:00

Hiszpańskie linie lotnicze wprowadziły surowe zasady w stosunku do kobiet należących do załogi, dotyczące makijażu i wysokich obcasów. Po skardze związku zawodowego kataloński departament pracy ukarał przewoźnika grzywną w wysokości 30 tys. euro.

## Największy polski bank przedstawia prognozy. Najbliższe miesiące będą chude
 - [https://businessinsider.com.pl/gospodarka/najwiekszy-polski-bank-przedstawia-prognozy-najblizsze-miesiace-beda-chude/xfsqfrc](https://businessinsider.com.pl/gospodarka/najwiekszy-polski-bank-przedstawia-prognozy-najblizsze-miesiace-beda-chude/xfsqfrc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 12:30:48+00:00

Ekonomiści PKO Banku Polskiego spodziewają się technicznej recesji w tym roku. To oznacza, że dynamika PKB — liczona kwartał do kwartału — będzie ujemna w kwartałach pierwszym i drugim. Odbicie w zakresie konsumpcji spodziewane jest dopiero pod koniec roku.

## Netanjahu wstrzymał plan, który pogrążył Izrael w chaosie. To nie koniec problemów
 - [https://businessinsider.com.pl/wiadomosci/netanjahu-wstrzymal-plan-ktory-pograzyl-izrael-w-chaosie-to-nie-koniec-problemow/ksbd1hp](https://businessinsider.com.pl/wiadomosci/netanjahu-wstrzymal-plan-ktory-pograzyl-izrael-w-chaosie-to-nie-koniec-problemow/ksbd1hp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 12:10:48+00:00

W Izraelu narasta poważny kryzys, który w tym tygodniu przybrał na sile, kiedy to oburzeni ludzie zalali ulice w proteście. Premier Benjamin Netanjahu wstrzymał plan, który pogrążył jego kraj w chaosie, ale to nie koniec problemów Izraela.

## Premier chce ograniczyć napływ zboża z Ukrainy
 - [https://businessinsider.com.pl/gospodarka/premier-chce-ograniczyc-naplyw-zboza-z-ukrainy/z12tf8x](https://businessinsider.com.pl/gospodarka/premier-chce-ograniczyc-naplyw-zboza-z-ukrainy/z12tf8x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:50:12+00:00

Zleciłem wprowadzenie przepisów, które będą pozwalały ograniczyć wpływ zboża ukraińskiego do Polski – przekazał Mateusz Morawiecki.

## Chciwi szwajcarscy bankierzy. Druzgocąca diagnoza Amerykanów
 - [https://businessinsider.com.pl/finanse/chciwi-szwajcarscy-bankierzy-ale-chciwi-byli-tez-amerykanie-tak-wynika-z-komisji/wsqnvpp](https://businessinsider.com.pl/finanse/chciwi-szwajcarscy-bankierzy-ale-chciwi-byli-tez-amerykanie-tak-wynika-z-komisji/wsqnvpp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:49:16+00:00

Credit Suisse nadal pomaga bogatym Amerykanom ukrywać dochody i majątek przed skarbówką pomimo, że mija 10 lat odkąd oddział szwajcarskiego banku w USA przyznał się, że pomagał w unikaniu płacenia podatków — wynika komunikatu amerykańskiej senackiej komisji finansów.

## "Ostateczny" koniec użytkowania wieczystego. Rząd przyjął projekt
 - [https://businessinsider.com.pl/gospodarka/koniec-uzytkowania-wieczystego-rzad-przyjal-projekt/s3fz230](https://businessinsider.com.pl/gospodarka/koniec-uzytkowania-wieczystego-rzad-przyjal-projekt/s3fz230)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:40:22+00:00

Ustawa, której projekt przyjął rząd, ma dać możliwość m.in. firmom, osobom fizycznym czy spółdzielniom mieszkaniowym uzyskania na własność gruntów, które mają w użytkowaniu wieczystym.

## Koniec użytkowania wieczystego. Rząd zapowiada
 - [https://businessinsider.com.pl/gospodarka/koniec-uzytkowania-wieczystego-rzad-zapowiada/s3fz230](https://businessinsider.com.pl/gospodarka/koniec-uzytkowania-wieczystego-rzad-zapowiada/s3fz230)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:40:22+00:00

Ustawa, której projekt przyjął rząd, ma dać możliwość m.in. firmom, osobom fizycznym czy spółdzielniom mieszkaniowym uzyskania na własność gruntów, które mają w użytkowaniu wieczystym.

## Dzisiaj do prawie 2 mln Polaków został wysłany przelew na kwotę 240 zł. Padł rekord
 - [https://businessinsider.com.pl/poradnik-finansowy/prawie-2-mln-polakow-dostanie-przelew-na-240-zl-sprawdz-czy-sie-lapiesz/5xsmgtz](https://businessinsider.com.pl/poradnik-finansowy/prawie-2-mln-polakow-dostanie-przelew-na-240-zl-sprawdz-czy-sie-lapiesz/5xsmgtz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:23:38+00:00

Na konta około 1,7 mln uczestników Pracowniczych Planów Kapitałowych (PPK) trafi w najbliższych dniach po 240 zł dopłaty rocznej od państwa. Z informacji Business Insidera wynika, że przelew na łączną kwotę ponad 410 mln zł wyszedł właśnie dzisiaj. Wiceprezes PFR Bartosz Marczuk podkreśla, że to rekordowy wynik.

## Rząd chciał nam kontrolować piloty, ale projekt upadł
 - [https://businessinsider.com.pl/wiadomosci/rzad-chcial-nam-kontrolowac-piloty-ale-projekt-upadl/q76e5k5](https://businessinsider.com.pl/wiadomosci/rzad-chcial-nam-kontrolowac-piloty-ale-projekt-upadl/q76e5k5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:23:08+00:00

Opozycja wygrała głosowanie w Sejmie i komisja cyfryzacji odrzuciła projekt ustawy nazywanej "Lex pilot". To oznacza, że pierwsze miejsca na pilotach nie będą zarezerwowane dla TVP.

## Wybierz wideorejestrator na lusterko cofania — sprawdź, dlaczego nie pożałujesz
 - [https://businessinsider.com.pl/technologie/wybierz-wideorejestrator-na-lusterko-cofania-sprawdz-dlaczego-nie-pozalujesz/9kexmk8](https://businessinsider.com.pl/technologie/wybierz-wideorejestrator-na-lusterko-cofania-sprawdz-dlaczego-nie-pozalujesz/9kexmk8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:20:00+00:00

Chcesz kupić wideorejestrator do swojego samochodu? Koniecznie sprawdź modele montowane na lusterko cofania. Nie zajmują miejsca na szybie, a do tego mogą pełnić funkcję kamery cofania.

## Koniec taniego "prawka". Kolejny region ostro podnosi ceny
 - [https://businessinsider.com.pl/twoje-pieniadze/koniec-taniego-prawka-kolejny-region-ostro-podnosi-ceny/nwsec8v](https://businessinsider.com.pl/twoje-pieniadze/koniec-taniego-prawka-kolejny-region-ostro-podnosi-ceny/nwsec8v)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:10:58+00:00

Kolejne już województwo podnosi opłaty za egzaminy na prawo jazdy. Po Pomorzu Zachodnim teraz podjęto taką decyzję w woj. opolskim.

## Ktoś porzucił jacht wart 81 mln dol. Oligarcha się wypiera
 - [https://businessinsider.com.pl/wiadomosci/jacht-z-silownia-i-basenem-wart-81-mln-dol-zostal-porzucony-oligarcha-sie-wypiera/7yvttyr](https://businessinsider.com.pl/wiadomosci/jacht-z-silownia-i-basenem-wart-81-mln-dol-zostal-porzucony-oligarcha-sie-wypiera/7yvttyr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:08:02+00:00

Rząd Antigui i Barbudy chce, aby porzucony superjacht wart 81 mln dol. opuścił ich port. W zawiadomieniu z 21 marca rząd karaibskiego państwa ogłosił, że uważa statek za porzucony i poinformował, że jeśli nie zostanie usunięty, zamierza go sprzedać, aby spłacić należności za żywność i paliwo.

## W Policach stanie mikroreaktor jądrowy. Na razie w celach badawczych
 - [https://businessinsider.com.pl/biznes/w-policach-stanie-reaktor-jadrowy-podlaczony-zostanie-do-infrastruktury-grupy-azoty/ktzcl64](https://businessinsider.com.pl/biznes/w-policach-stanie-reaktor-jadrowy-podlaczony-zostanie-do-infrastruktury-grupy-azoty/ktzcl64)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 11:06:19+00:00

Grupa Azoty Police, Ultra Safe Nuclear Corporation oraz Zachodniopomorski Uniwersytet Technologiczny podpisały porozumienie o budowie reaktora MMR — poinformowały strony w środę. W najbliższym półroczu strony opracują program badawczy oraz przygotują plan budowy i eksploatacji instalacji mikroreaktora jądrowego.

## Uwaga na te trzy produkty. Wykryto niebezpieczne substancje
 - [https://businessinsider.com.pl/wiadomosci/uwaga-na-te-trzy-produkty-wykryto-niebezpieczne-substancje/jh0ykzw](https://businessinsider.com.pl/wiadomosci/uwaga-na-te-trzy-produkty-wykryto-niebezpieczne-substancje/jh0ykzw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 10:44:04+00:00

Główny Inspektorat Sanitarny wydał niedawno ostrzeżenia przed trzema produktami. Jest wśród nich popularny kefir i popkorn w opakowaniach.

## Pepsi zmienia logo. Zobacz, jak będzie wyglądać słynna puszka
 - [https://businessinsider.com.pl/biznes/pepsi-zmienia-logo-zobacz-jak-bedzie-wygladac-slynna-puszka/b1d0swp](https://businessinsider.com.pl/biznes/pepsi-zmienia-logo-zobacz-jak-bedzie-wygladac-slynna-puszka/b1d0swp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 10:43:10+00:00

Pepsi zaprezentowała nowe logo i system identyfikacji wizualnej. To pierwsza od 14 lat aktualizacja wizerunku marki. Firma wprowadzi nowe logo w Stanach Zjednoczonych jeszcze jesienią tego roku, z okazji 125. rocznicy powstania marki. W Polsce nowy logotyp będziemy mogli zobaczyć w sklepach w 2024 r.

## Mieszkania na razie dla najbardziej zamożnych. Zaskakujące dane NBP
 - [https://businessinsider.com.pl/gospodarka/coraz-czesciej-mieszkania-kupuja-osoby-finansujace-transakcje-tylko-gotowka/kkl4wcs](https://businessinsider.com.pl/gospodarka/coraz-czesciej-mieszkania-kupuja-osoby-finansujace-transakcje-tylko-gotowka/kkl4wcs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 10:36:39+00:00

Wzrost stóp procentowych i spadek zdolności kredytowej przy jednocześnie wciąż wysokich cenach mieszkań spowodował, że zwiększył się udział nabywców lokali w celach inwestycyjnych oraz tych, którzy finansowali zakupy gotówką.

## Kolejny kraj idzie na wojnę z TikTokiem. Będą blokady
 - [https://businessinsider.com.pl/gospodarka/ten-kraj-tez-idzie-na-wojne-z-tiktokiem/my0vsxn](https://businessinsider.com.pl/gospodarka/ten-kraj-tez-idzie-na-wojne-z-tiktokiem/my0vsxn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 09:59:47+00:00

Aplikacja TikTok zostanie zablokowana na wszystkich urządzeniach wydawanych urzędnikom przez państwo – mówi minister przedsiębiorczości i technologii Estonii Kristjan Jarvan.

## 300 zł dodatku emerytalnego dla sołtysów. Znamy szczegóły
 - [https://businessinsider.com.pl/prawo/praca/dodatek-do-emerytury-dla-soltysow-jakie-warunki-trzeba-spelnic/s35xgzz](https://businessinsider.com.pl/prawo/praca/dodatek-do-emerytury-dla-soltysow-jakie-warunki-trzeba-spelnic/s35xgzz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 09:44:19+00:00

Do końca czerwca rząd ma przyjąć projekt ustawy w sprawie specjalnego świadczenia dla sołtysów. Wyniesie ono 300 zł miesięcznie i będzie wypłacane po przejściu na emeryturę.

## Niemiecki gigant z rekordowymi obrotami. Dużo zawdzięcza Polsce
 - [https://businessinsider.com.pl/biznes/gigant-z-niemiec-z-ogromnymi-obrotami-duzo-zawdziecza-polsce/v96rc4d](https://businessinsider.com.pl/biznes/gigant-z-niemiec-z-ogromnymi-obrotami-duzo-zawdziecza-polsce/v96rc4d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 09:42:46+00:00

Grupa BSH, producent AGD i właściciel marek Bosch, Siemens oraz Gaggenau mogła pochwalić się rekordowym obrotem pomimo zauważalnego spadku popytu. Blisko 16 mld euro obrotu zawdzięcza inflacji, a także m.in. aktywności nad Wisłą. Sześć ulokowanych w naszym kraju fabryk sprawia, że to jedna z głównych baz produkcyjnych niemieckiego giganta.

## Tyle Polak może wydać na używane auto. Wiemy, na jakie modele starczy
 - [https://businessinsider.com.pl/twoje-pieniadze/tyle-polak-moze-wydac-na-uzywane-auto-wiemy-na-jakie-modele-starczy/936t1z6](https://businessinsider.com.pl/twoje-pieniadze/tyle-polak-moze-wydac-na-uzywane-auto-wiemy-na-jakie-modele-starczy/936t1z6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 09:36:33+00:00

Polscy kupujący najczęściej interesują się samochodami na wtórnym rynku, których cena wynosi około 40 tys. zł. To aż o niemal 10 tys. zł więcej niż wynosiła w lutym br. mediana ceny samochodów używanych.

## Firma zbrojeniowa nie nadąża z produkcją pocisków. Powód? Centrum danych TikTok zużywa cały prąd
 - [https://businessinsider.com.pl/biznes/firma-zbrojeniowa-nie-nadaza-z-produkcja-pociskow-powod-centrum-danych-tiktok-zuzywa/x8bww7b](https://businessinsider.com.pl/biznes/firma-zbrojeniowa-nie-nadaza-z-produkcja-pociskow-powod-centrum-danych-tiktok-zuzywa/x8bww7b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 09:23:26+00:00

Norweski producent broni twierdzi, że centrum danych TikToka zużywa całą energię elektryczną w regionie, co nie pozwala firmie nadążyć za rosnącym globalnym zapotrzebowaniem na amunicję.

## Ten Polak pracuje w Deutsche Bahn. PKP go nie chciały
 - [https://businessinsider.com.pl/wiadomosci/ten-polak-pracuje-w-deutsche-bahn-pkp-go-nie-chcialy/m23dtgr](https://businessinsider.com.pl/wiadomosci/ten-polak-pracuje-w-deutsche-bahn-pkp-go-nie-chcialy/m23dtgr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 09:19:24+00:00

Krzysztof Skrzypczyk ze Szczecina spełnił swoje marzenie i został maszynistą –  mimo lekkiego niedosłuchu. W Polsce pracy w tym fachu dostać jednak nie mógł.

## Rosyjska gospodarka zaczyna iść na dno. To będzie wieloletni kryzys
 - [https://businessinsider.com.pl/gospodarka/rosyjska-gospodarka-zaczyna-isc-na-dno-to-bedzie-wieloletni-kryzys/3nds0fv](https://businessinsider.com.pl/gospodarka/rosyjska-gospodarka-zaczyna-isc-na-dno-to-bedzie-wieloletni-kryzys/3nds0fv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 09:12:00+00:00

Inwestycje spadają, zaczyna brakować siły roboczej, dochody z eksportu surowców energetycznych maleją i sytuacja budżetowa staje się coraz bardziej napięta — pisze "The Wall Street Journal".

## Władimir Putin rozbudowuje armię kosztem gospodarki
 - [https://businessinsider.com.pl/gospodarka/wladimir-putin-rozbudowuje-armie-kosztem-gospodarki/grkl6f8](https://businessinsider.com.pl/gospodarka/wladimir-putin-rozbudowuje-armie-kosztem-gospodarki/grkl6f8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 08:49:56+00:00

Wojna w Ukrainie ściąga do rosyjskiego wojska setki tysięcy pracowników. W efekcie w kraju spada bezrobocie, ale też rosną niedobory siły roboczej. Dane Federalnej Służby Statystycznej wskazują na wzrost netto liczby wojskowych w ubiegłym roku o około 400 tys. przy rekordowo niskim bezrobociu — pisze Bloomberg.

## Firmy uwłaszczą się na gruntach. Rząd ma przyjąć ustawę kończącą z użytkowaniem wieczystym
 - [https://businessinsider.com.pl/prawo/firma/firmy-uwlaszcza-sie-na-gruntach-zmiany-w-uzytkowaniu-wieczystym-juz-2023-r/3nrxfvh](https://businessinsider.com.pl/prawo/firma/firmy-uwlaszcza-sie-na-gruntach-zmiany-w-uzytkowaniu-wieczystym-juz-2023-r/3nrxfvh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 08:06:59+00:00

We wtorek rzad ma przyjąć projekt ustawy kończącej reformę uwłaszczeniową. Przedsiębiorstwa będą mogły przekształcić prawo użytkowania nieruchomości komercyjnych we własność. Cena wykupu gruntu wyniesie co najmniej 20-krotność opłaty rocznej za użytkowanie wieczyste, ale nie więcej niż wartość gruntu.

## Kolejne uzbrojenie dla polskiego wojska. Umowa zatwierdzona
 - [https://businessinsider.com.pl/wiadomosci/radary-dla-polskiego-wojska-umowa-zatwierdzona/s4wr3w3](https://businessinsider.com.pl/wiadomosci/radary-dla-polskiego-wojska-umowa-zatwierdzona/s4wr3w3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 08:01:28+00:00

Szef MON Mariusz Błaszczak zatwierdził umowę wykonawczą na dostawę 22 mobilnych radarów przeciwlotniczych Bystra. Wartość umowy to 1 mld 100 mln zł.

## Koreańczycy zainwestują w polską spółkę. Kurs akcji na giełdzie mocno w górę
 - [https://businessinsider.com.pl/gielda/wiadomosci/koreanczycy-zainwestuja-w-polska-spolke-kurs-akcji-na-gieldzie-mocno-w-gore/4kyfy1n](https://businessinsider.com.pl/gielda/wiadomosci/koreanczycy-zainwestuja-w-polska-spolke-kurs-akcji-na-gieldzie-mocno-w-gore/4kyfy1n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 07:50:42+00:00

Komunikat o planowanej inwestycji koreańskiego akcjonariusza rozpalił notowania People Can Fly, polskiego studia produkującego gry komputerowe.

## W kwietniu nadal nie rozstaniemy się z maseczkami. Jest projekt rozporządzenia
 - [https://businessinsider.com.pl/wiadomosci/zakrywanie-nosa-i-ust-w-kwietniu-nadal-obowiazkowe-wynika-z-projektu-rozporzadzenia/ny488lz](https://businessinsider.com.pl/wiadomosci/zakrywanie-nosa-i-ust-w-kwietniu-nadal-obowiazkowe-wynika-z-projektu-rozporzadzenia/ny488lz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 07:45:34+00:00

Do końca kwietnia ma obowiązywać obowiązek zakrywania nosa i ust w aptekach, przychodniach i w szpitalach, przy pomocy maseczki — wynika z opublikowanego w środę na stronach Rządowego Centrum Legislacji projektu rozporządzenia. To efekt dużej liczby zachorowań zarówno na COVID-19, jak i grypę.

## 17-latkowi grozi więzienie za "kanapkowy przekręt". Zyskał na nim 5 zł
 - [https://businessinsider.com.pl/wiadomosci/17-latkowi-grozi-wiezienie-za-kanapkowy-przekret-zyskal-na-nim-5-zl/w5zee12](https://businessinsider.com.pl/wiadomosci/17-latkowi-grozi-wiezienie-za-kanapkowy-przekret-zyskal-na-nim-5-zl/w5zee12)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 07:38:14+00:00

Nawet 8 lat więzienia może grozić 17-latkowi, który w jednym z mieleckich sklepów nakleił na kanapkę z bagietki naklejkę "-50 proc." zapłacił za nią o ponad 5 zł mniej, niż powinien. Policja przypomina, że przy przestępstwie doprowadzenia do niekorzystnego rozporządzenia mieniem wartość przedmiotu nie ma znaczenia.

## Wiceminister finansów: na koniec roku możliwa 7-proc. inflacja
 - [https://businessinsider.com.pl/gospodarka/inflacja-w-2023-r-sobon-w-grudniu-moze-siegnac-7-procent/qcbvbw8](https://businessinsider.com.pl/gospodarka/inflacja-w-2023-r-sobon-w-grudniu-moze-siegnac-7-procent/qcbvbw8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 07:21:57+00:00

Wiceminister finansów Artur Soboń prognozuje, że na koniec roku inflacja konsumencka zejdzie do jednocyfrowego poziomu, a w optymistycznym scenariuszu już w grudniu może sięgnąć 7 proc.

## Ten wskaźnik pokazuje, co dalej może dziać się na polskim rynku pracy
 - [https://businessinsider.com.pl/gospodarka/co-dalej-z-polskim-rynkiem-pracy-ten-wskaznik-pokazuje-kierunek/20f2wnh](https://businessinsider.com.pl/gospodarka/co-dalej-z-polskim-rynkiem-pracy-ten-wskaznik-pokazuje-kierunek/20f2wnh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 07:19:23+00:00

Wskaźnik Rynku Pracy (WRP) informujący z wyprzedzeniem o przyszłych zmianach wielkości bezrobocia w marcu nieznacznie zmalał, co jest bez znaczenia z punktu widzenia średniego okresu oraz spodziewanych zmian na rynku pracy - podaje Biuro Inwestycji i Cykli Ekonomicznych (BIEC).

## Kluczowa decyzja w sprawie emerytury. To kwestia nawet 200 zł
 - [https://businessinsider.com.pl/poradnik-finansowy/kluczowa-decyzja-w-sprawie-emerytury-to-kwestia-nawet-200-zl/7ryv63s](https://businessinsider.com.pl/poradnik-finansowy/kluczowa-decyzja-w-sprawie-emerytury-to-kwestia-nawet-200-zl/7ryv63s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 07:16:16+00:00

Ok. 300 tys. osób będzie w tym roku podejmować decyzję o przejściu na emeryturę. Data jest tu kluczowa, bo może oznaczać różnicę nawet 200 zł w wysokości świadczenia — zauważa "Fakt".

## Kurs franka 29 marca w okolicy 4,7 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-29-marca-2023/dh8rlbe](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-29-marca-2023/dh8rlbe)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 07:05:34+00:00

Frank szwajcarski w okolicy 4,7 zł. W środę rano 29 marca 2023 r. kurs tej waluty wobec polskiego złotego wynosi 4,6900.

## Kurs dolara 29 marca powyżej 4,3 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-29-marca-2023/h082n7q](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-29-marca-2023/h082n7q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 07:02:47+00:00

Kurs dolara powyżej 4,3 zł. W środę rano 29 marca 2023 r. kurs USD/PLN wynosi 4,3227.

## Kurs euro 29 marca poniżej 4,7 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-29-marca-2023/6nwbezk](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-29-marca-2023/6nwbezk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 06:58:23+00:00

Kurs euro poniżej 4,7 zł. W środę rano 29 marca 2023 r. kurs EUR/PLN wynosił 4,6791 zł.

## Unijne przepisy uderzą w pompy ciepła. Problem dla branży i klientów
 - [https://businessinsider.com.pl/biznes/unijne-przepisy-uderza-w-pompy-ciepla-problem-dla-branzy-i-klientow/wzmzqke](https://businessinsider.com.pl/biznes/unijne-przepisy-uderza-w-pompy-ciepla-problem-dla-branzy-i-klientow/wzmzqke)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 06:11:14+00:00

Unia Europejska planuje zmniejszać emisję gazów cieplarnianych. Nie tylko dwutlenku węgla i metanu, ale także gazów fluorowanych. Problem w tym, że na nich opiera się działanie zdecydowanej większości obecnych na rynku pomp ciepła — pisze serwis interia.pl.

## Drożyzna zmusza Polaków do oszczędzania na świętach. "Nic pozytywnego się nie wydarzy"
 - [https://businessinsider.com.pl/wiadomosci/drozyzna-zmusza-polakow-do-oszczedzania-na-swietach-nic-pozytywnego-sie-nie-wydarzy/9wjzw3l](https://businessinsider.com.pl/wiadomosci/drozyzna-zmusza-polakow-do-oszczedzania-na-swietach-nic-pozytywnego-sie-nie-wydarzy/9wjzw3l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 05:51:06+00:00

Dwóch na trzech Polaków deklaruje w tym roku skromne święta. Eksperci komentujący te dane ostrzegają, że koszyk wielkanocnej żywności może być droższy rok do roku o nawet 30-40 proc.

## Polska zadłużyła się na 5 mld dol. Duża emisja obligacji
 - [https://businessinsider.com.pl/finanse/makroekonomia/polska-zadluzyla-sie-na-5-mld-dol-duza-emisja-obligacji/k366hk4](https://businessinsider.com.pl/finanse/makroekonomia/polska-zadluzyla-sie-na-5-mld-dol-duza-emisja-obligacji/k366hk4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 05:38:23+00:00

Ministerstwo Finansów dokonało wyceny 10-letnich i 30-letnich obligacji benchmarkowych nominowanych w dolarach amerykańskich o terminie wykupu 4 października 2033 r. oraz 4 kwietnia 2053 r. — podał resort finansów. Łączna wartość nominalna nowej emisji obligacji wyniosła 5 mld dol. (każda transza po 2,5 mld dol.).

## Tak wpada się w spiralę długów. Pożyczył 800 zł, do oddania ma 102 tys. zł
 - [https://businessinsider.com.pl/wiadomosci/tak-wpada-sie-w-spirale-dlugow-pozyczyl-800-zl-do-oddania-ma-102-tys-zl/9xmyqpf](https://businessinsider.com.pl/wiadomosci/tak-wpada-sie-w-spirale-dlugow-pozyczyl-800-zl-do-oddania-ma-102-tys-zl/9xmyqpf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 05:26:14+00:00

Niemal 20 lat temu mężczyzna pożyczył 800 zł, żeby utrzymać rodzinę. Nie spłacał rat w terminie. Dług rósł w błyskawicznym tempie. Po wyroku sądu dłużnik oddał już 41 tys. zł, a do spłaty pozostało jeszcze 102 tys. zł. Uchylenia nakazu zapłaty w tej sprawie chce prokurator generalny Zbigniew Ziobro.

## ZUS skontroluje 25 tys. firm. Co będzie sprawdzał?
 - [https://businessinsider.com.pl/biznes/zus-skontroluje-25-tys-firm-co-bedzie-sprawdzal/rqx25mb](https://businessinsider.com.pl/biznes/zus-skontroluje-25-tys-firm-co-bedzie-sprawdzal/rqx25mb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 05:07:26+00:00

W 2022 r. Zakład Ubezpieczeń Społecznych przeprowadził prawie 27 tys. kontroli płatników składek. W tym roku ma być ich mniej, bo 25 tys. Ubiegłoroczne kontrole wykazały, że najwięcej nieprawidłowości było w takich branżach jak handel hurtowy, działalność związana z oprogramowaniem i doradztwem w informatyce. Dużo do zarzucenia ZUS miał także firmom prowadzących działalność detektywistyczną i ochroniarską.

## Nasze realne dochody spadają najszybciej od lat
 - [https://businessinsider.com.pl/gospodarka/nasze-realne-dochody-spadaja-najszybciej-od-lat/v8hqrgj](https://businessinsider.com.pl/gospodarka/nasze-realne-dochody-spadaja-najszybciej-od-lat/v8hqrgj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 05:03:24+00:00

Nasze realne dochody w ubiegłym roku zaliczyły spektakularny spadek, czyli zbiednieliśmy. Coraz więcej firm narzeka na zatory płatnicze, a Komitet Stabilności Finansowej ogłasza, że podważanie stawki WIBOR w umowach kredytowych to systemowe ryzyko dla Polski. Rada Unii Europejskiej zatwierdziła zakaz nowych aut spalinowych po 2035 r., a unijny nadzór rynkowy dopatrzył się, że piątkową panikę na akcjach Deutsche Banku wywołała zaledwie jedna transakcja. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Zawodnik Manchesteru City "plądruje angielskie podatki"
 - [https://businessinsider.com.pl/wiadomosci/zawodnik-manchesteru-city-pladruje-angielskie-podatki/2znwpy9](https://businessinsider.com.pl/wiadomosci/zawodnik-manchesteru-city-pladruje-angielskie-podatki/2znwpy9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 04:50:21+00:00

Erling Haaland, norweski zawodnik Manchesteru City, założył firmę w Luksemburgu, aby  zmniejszyć wysokie podatki, które płaci w Wielkiej Brytanii i w swoim kraju. 22-letni piłkarz już w ubiegłym roku został najmłodszym miliarderem w swoim kraju.

## Masz auto w leasingu? Złamanie tych zasad grozi kosztami
 - [https://businessinsider.com.pl/prawo/firma/masz-auto-w-leasingu-uwazaj-zlamanie-tych-zasad-grozi-kosztami/nnelgpr](https://businessinsider.com.pl/prawo/firma/masz-auto-w-leasingu-uwazaj-zlamanie-tych-zasad-grozi-kosztami/nnelgpr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 04:40:00+00:00

Prowadzący działalność, zwłaszcza na tzw. samozatrudnieniu, chętnie biorą auta w leasing, bo opłaca się to podatkowo. Wielu z nich jednak zapomina, że to nie ich auto, a firmy finansującej zakup. Oznacza to ograniczenia, na które trzeba uważać. Złamanie zasad grozi bowiem dodatkowymi opłatami, ale też groźbą wypowiedzenia umowy.

## Biden zaprzecza spotkaniu z Netanjahu i ostrzega: nie może dalej iść tą drogą
 - [https://businessinsider.com.pl/wiadomosci/biden-zaprzecza-spotkaniu-z-netanjahu-i-ostrzega-nie-moze-dalej-isc-ta-droga/73s418e](https://businessinsider.com.pl/wiadomosci/biden-zaprzecza-spotkaniu-z-netanjahu-i-ostrzega-nie-moze-dalej-isc-ta-droga/73s418e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 04:35:07+00:00

Planowana przez rząd Izraela, kontrowersyjna reforma sądownictwa doprowadziła do masowych protestów w kraju. Prezydent Stanów Zjednoczonych, które są ważnym sojusznikiem Izraela na arenie międzynarodowej, wyraził nadzieję, że rząd zrobi krok w tył. Dodał, że premier Netanjahu "nie może iść dalej tą drogą".

## Dwa duże bloki węglowe w remoncie. Co z dostawami prądu?
 - [https://businessinsider.com.pl/wiadomosci/dwa-duze-bloki-weglowe-tymczasowo-wypadly-z-systemu-co-z-dostawami-pradu/cm73b25](https://businessinsider.com.pl/wiadomosci/dwa-duze-bloki-weglowe-tymczasowo-wypadly-z-systemu-co-z-dostawami-pradu/cm73b25)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 04:20:16+00:00

Koniec marca przyniósł ochłodzenie, tymczasem do remontu trafiły dwa duże bloki energetyczne, które są istotne dla stabilnych dostaw prądu do naszych domów. Szczęśliwie systemowi pomaga wysoka produkcja energii z farm wiatrowych i słonecznych. Wyzwaniem są jednak wieczory, kiedy nagle przestaje działać fotowoltaika, a jednocześnie zapotrzebowanie na energię rośnie.

## Joe Biden: kryzys bankowy jeszcze się nie skończył
 - [https://businessinsider.com.pl/gospodarka/joe-biden-kryzys-bankowy-jeszcze-sie-nie-skonczyl/l15z444](https://businessinsider.com.pl/gospodarka/joe-biden-kryzys-bankowy-jeszcze-sie-nie-skonczyl/l15z444)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 04:10:40+00:00

Joe Biden został zapytany o kryzys w sektorze bankowym wywołany upadłością Silicon Valley Bank. W opinii prezydenta USA niepewność jeszcze się nie skończyła. Jednocześnie Biden zapewnił, że zrobił tyle, ile mógł, by uspokoić sytuację.

## "To ogon merda psem". Wiceprezes mTFI o tym, co nas czeka w sektorze bankowym
 - [https://businessinsider.com.pl/finanse/czy-grozi-nam-kryzys-bankowy-mamy-sytuacje-ze-to-ogon-merda-psem/sxjb2jp](https://businessinsider.com.pl/finanse/czy-grozi-nam-kryzys-bankowy-mamy-sytuacje-ze-to-ogon-merda-psem/sxjb2jp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 04:08:00+00:00

System bankowy na świecie jest wciąż tak istotny, że ewentualne turbulencje mają bezpośrednie przełożenie na wzrost gospodarczy czy poziom bezrobocia. A przy takich poziomach podaży pieniądza w stosunku do wielkości gospodarek czy wielkości zadłużenia rządowego i prywatnego, mamy sytuację, że to ogon merda psem. Kiedyś było tak, że to rynek finansowy determinował, w którą stronę idzie gospodarka, a teraz często jest na odwrót — mówi Business Insider Polska wiceprezes mTFI Bartosz Pawłowski.

## Rząd chciał oprocentowania hipotek na stałą stopę. Wiemy, gdzie leży problem
 - [https://businessinsider.com.pl/finanse/rzad-chcial-oprocentowania-hipotek-na-stala-stope-wiemy-gdzie-lezy-problem/4z0nly2](https://businessinsider.com.pl/finanse/rzad-chcial-oprocentowania-hipotek-na-stala-stope-wiemy-gdzie-lezy-problem/4z0nly2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-29 04:03:00+00:00

Zgodnie z prawem banki mogą pobierać rekompensaty od klienta, gdy ten zdecyduje się na spłatę hipoteki o stałym oprocentowaniu wcześniej, niż wynika to z harmonogramu. W praktyce jednak tego nie robią, bo przepisy są nieprecyzyjne i sektor obawia się sporów prawnych. Szczególnie biorąc pod uwagę prokonsumenckie nastawienie urzędów i sądów. Urząd Komisji Nadzoru Finansowego chce, aby wreszcie przeciąć węzeł gordyjski i wskazać, czy i jak banki mogą pobierać rekompensaty, a jeśli nie, to jakie są inne opcje.

