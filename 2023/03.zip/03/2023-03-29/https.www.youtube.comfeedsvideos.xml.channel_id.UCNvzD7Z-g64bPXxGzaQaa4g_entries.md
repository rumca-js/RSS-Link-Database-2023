# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## The Last of Us Part 1 (PC) - Before You Buy
 - [https://www.youtube.com/watch?v=HhSCMGdq11Y](https://www.youtube.com/watch?v=HhSCMGdq11Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-03-29 20:33:30+00:00

The Last of Us Part 1 is finally on PC via Steam, but it has some significant problems for some players. Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼


Buy TLOU: https://amzn.to/3ntUE4w
 

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

