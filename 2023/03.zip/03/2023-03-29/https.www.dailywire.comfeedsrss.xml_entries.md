# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Black Democrat Slams Leftist Feds For Lying, Wasting Money In The Name Of ‘Equity’
 - [https://www.dailywire.com/news/black-democrat-slams-leftist-feds-for-lying-wasting-money-in-the-name-of-equity](https://www.dailywire.com/news/black-democrat-slams-leftist-feds-for-lying-wasting-money-in-the-name-of-equity)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 19:05:25+00:00

A key Democrat in Congress who is black on Wednesday excoriated a group of far-left, largely white technologists in the Biden administration for jeopardizing cybersecurity and potentially enabling fraud in the government by citing racial “equity.”

## Karine Jean-Pierre Dodges On Whether Biden’s Proposed Gun Ban Will Lead To Confiscation
 - [https://www.dailywire.com/news/karine-jean-pierre-dodges-on-whether-bidens-proposed-gun-ban-will-lead-to-confiscation](https://www.dailywire.com/news/karine-jean-pierre-dodges-on-whether-bidens-proposed-gun-ban-will-lead-to-confiscation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 19:02:38+00:00

White House press secretary Karine Jean-Pierre refused to answer a question on Wednesday over whether President Joe Biden&#8217;s proposed ban on some semi-automatic long guns will lead to the confiscation of millions of Americans&#8217; guns. The question comes after a transgender shooter murdered six people, including three children, at a Christian school in Nashville this ...

## Here Are The States With Restrictions On Medical Child Sex Changes
 - [https://www.dailywire.com/news/here-are-the-states-with-restrictions-on-medical-child-sex-changes](https://www.dailywire.com/news/here-are-the-states-with-restrictions-on-medical-child-sex-changes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 18:52:50+00:00

The transgender medicalization of children has exploded in popularity over the last few years, prompting red and purple states to respond with a wave of restrictions. Last year, about 300,000 American teens 13 to 17 identified as transgender, a sharp increase over the previous few years. From 2017 to 2021, gender dysphoria diagnoses in children ...

## Ex-CDC Head Finally Says What We’ve All Known Forever About The Source Of COVID-19
 - [https://www.dailywire.com/news/ex-cdc-head-finally-says-what-weve-all-known-forever-about-the-source-of-covid-19](https://www.dailywire.com/news/ex-cdc-head-finally-says-what-weve-all-known-forever-about-the-source-of-covid-19)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 18:50:53+00:00

So I was reading the transcript from former Centers for Disease Control and Prevention (CDC) Director Robert Redfield&#8217;s testimony from earlier this month before the House Select Subcommittee on the Coronavirus Pandemic (yes, this is what I do in my spare time). And I gotta&#8217; say, I missed something kinda&#8217; big. The headlines that came ...

## Target Of ‘Reconnaissance Tour’ Story Fires Back At January 6 Committee
 - [https://www.dailywire.com/news/target-of-reconnaissance-tour-story-fires-back-at-january-6-committee](https://www.dailywire.com/news/target-of-reconnaissance-tour-story-fires-back-at-january-6-committee)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 18:37:31+00:00

A House Republican leader accused the January 6 Committee of knowingly spreading false allegations about him giving a &#8220;reconnaissance tour&#8221; a day before the 2021 U.S. Capitol breach. Rep. Barry Loudermilk (R-GA), the target of those allegations, shared this week the initial findings of his inquiry into the January 6 panel in his capacity as ...

## Mark Hamill Uses ‘Star Wars’ Voice To Warn Ukrainians About Air-Raid On App
 - [https://www.dailywire.com/news/mark-hamill-uses-star-wars-voice-to-warn-ukrainians-about-air-raid-on-app](https://www.dailywire.com/news/mark-hamill-uses-star-wars-voice-to-warn-ukrainians-about-air-raid-on-app)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 17:56:13+00:00

Actor Mark Hamill has lent his voice as a Jedi from &#8220;Star Wars&#8221; to a new air-raid app being used in Ukraine to warn residents of an incoming aerial bombardment from Russia. The 71-year-old actor—best known for his role as Luke Skywalker in George Lucas&#8217; hit franchise—urges people to seek shelter in his familiar voice ...

## Ex-FBI Agent-Turned-Nashville Councilman Recalls Horror Of School Shooting
 - [https://www.dailywire.com/news/ex-fbi-agent-turned-nashville-councilman-recalls-horror-of-school-shooting](https://www.dailywire.com/news/ex-fbi-agent-turned-nashville-councilman-recalls-horror-of-school-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 17:45:25+00:00

Nashville City Councilman Russ Pulley struggled to override the instincts honed by a career in law enforcement when he learned there was a shooting in progress inside the Covenant School Monday. The 64-year-old former police officer and FBI agent was in his Green Hills office working on city business as the horrific incident began to ...

## ‘You Probably Need To Watch It Twice’: Chris Pratt Reacts To Criticism Over ‘Mario Bros’ Accent
 - [https://www.dailywire.com/news/you-probably-need-to-watch-it-twice-chris-pratt-reacts-to-criticism-over-mario-bros-accent](https://www.dailywire.com/news/you-probably-need-to-watch-it-twice-chris-pratt-reacts-to-criticism-over-mario-bros-accent)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 17:39:18+00:00

Actor Chris Pratt responded to backlash over his accent in his upcoming project, &#8220;The Super Mario Bros. Movie&#8221; — and he encouraged his would-be critics to see the movie before passing judgment. &#8220;You know what? In all honesty, I think you probably need to watch it twice,&#8221; he said. Pratt, who voices the titular character ...

## Biden Still Trying To Bully Netanyahu, Says He Won’t Invite Him ‘Near-Term’
 - [https://www.dailywire.com/news/biden-still-trying-to-bully-netanyahu-says-he-wont-invite-him-near-term](https://www.dailywire.com/news/biden-still-trying-to-bully-netanyahu-says-he-wont-invite-him-near-term)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 17:26:17+00:00

President Joe Biden snubbed Israel Prime Minister Benjamin Netanyahu on Tuesday when asked if he would invite him to the White House. Biden, speaking of Netanyahu, the political Right in Israel, and their attempt at reforming Israel’s one-sided judiciary by getting Israel to more clearly resemble the United States, said the developments in Israel were ...

## Marine Corps Vet And Commended Cop: Meet The Heroic Officers Who Took Down The Nashville Shooter
 - [https://www.dailywire.com/news/marine-corps-vet-and-commended-cop-meet-the-heroic-officers-who-took-down-the-nashville-shooter](https://www.dailywire.com/news/marine-corps-vet-and-commended-cop-meet-the-heroic-officers-who-took-down-the-nashville-shooter)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 17:16:20+00:00

Two Nashville Metro Police officers are being praised for their heroic actions that possibly saved the lives of numerous children and staff at a Nashville, Tennessee, Christian elementary school Monday morning. Minutes after a 28-year-old female shooter entered the Covenant School in Nashville where she murdered three adults and three children, a group of police ...

## Wednesday Afternoon Update: Pope Hospitalized, D.C. Crime Rate Under Scrutiny, Levi’s Will Use AI Fashion Models
 - [https://www.dailywire.com/news/wednesday-afternoon-update-pope-hospitalized-d-c-crime-rate-under-scrutiny-levis-will-use-ai-fashion-models](https://www.dailywire.com/news/wednesday-afternoon-update-pope-hospitalized-d-c-crime-rate-under-scrutiny-levis-will-use-ai-fashion-models)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 17:16:07+00:00

This article is adapted from today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. Pope Francis Hospitalized Pope Francis was hospitalized today with a lung infection, and according to the Vatican will remain admitted for several days of treatment. Vatican officials say the pope does not have COVID. A spokesman said the ...

## Joy Behar: ‘Trump Is The One Who Needs To Get The Nomination Because Then Democrats Will Win’
 - [https://www.dailywire.com/news/joy-behar-trump-is-the-one-who-needs-to-get-the-nomination-because-then-democrats-will-win](https://www.dailywire.com/news/joy-behar-trump-is-the-one-who-needs-to-get-the-nomination-because-then-democrats-will-win)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 16:48:30+00:00

Joy Behar, co-host of ABC&#8217;s &#8220;The View,&#8221; said on Wednesday that she hopes that former President Donald Trump beats Florida Governor Ron DeSantis in the 2024 Republican primary because Trump is the candidate that Democrats can beat. Behar made the remarks after other co-hosts on the leftist show took shots at DeSantis, who has not ...

## Newsom Signs Bill Banning Oil Company ‘Price Gouging’
 - [https://www.dailywire.com/news/newsom-signs-bill-banning-oil-company-price-gouging](https://www.dailywire.com/news/newsom-signs-bill-banning-oil-company-price-gouging)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 16:29:17+00:00

Gov. Gavin Newsom (D-CA) signed a bill on Tuesday that prohibits oil companies from “price gouging,” contending that the new law would protect the state’s climate and lower prices. The legislation, introduced by State Sen. Nancy Skinner (D-CA) at the end of last year, forces oil companies to reduce their profits in order to avoid ...

## FDA Approves First Over-The-Counter Narcan Nasal Spray Amid Ongoing Opioid Crisis
 - [https://www.dailywire.com/news/fda-approves-first-over-the-counter-narcan-nasal-spray-amid-ongoing-opioid-crisis](https://www.dailywire.com/news/fda-approves-first-over-the-counter-narcan-nasal-spray-amid-ongoing-opioid-crisis)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 16:18:15+00:00

The U.S. Food and Drug Administration on Wednesday approved the first over-the-counter Narcan nasal spray to reduce drug overdose deaths driven by illicit opioids amid an ongoing epidemic largely fueled by the southern border crisis. Federal officials approved Narcan, a naloxone hydrochloride nasal spray for over-the-counter, nonprescription use, as drug overdoses continue to plague the U.S, ...

## D.A. Steps Down In Alec Baldwin Case, Clears Path For Special Prosecutor
 - [https://www.dailywire.com/news/d-a-steps-down-in-alec-baldwin-case-clears-path-for-special-prosecutor](https://www.dailywire.com/news/d-a-steps-down-in-alec-baldwin-case-clears-path-for-special-prosecutor)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 16:16:03+00:00

The district attorney who charged actor Alec Baldwin has stepped down, clearing the way for special prosecutors to take over the case. Santa Fe District Attorney Mary Carmack-Altwies announced on Wednesday that she was stepping down from the case – and that she had appointed New Mexico attorneys Kari Morrissey and Jason Lewis to take over ...

## Disney Cuts Marvel Entertainment Chair Ike Perlmutter Following Massive Layoffs
 - [https://www.dailywire.com/news/disney-cuts-marvel-entertainment-chair-ike-perlmutter-following-massive-layoffs](https://www.dailywire.com/news/disney-cuts-marvel-entertainment-chair-ike-perlmutter-following-massive-layoffs)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 16:04:50+00:00

Disney has confirmed that Marvel Entertainment Chairman Issac &#8220;Ike&#8221; Perlmutter is out following massive layoffs by the House of Mouse as part of its cost-cutting efforts. Marvel Entertainment is a subsidiary of the Disney Company. Perlmutter was let go along with Marvel Entertainment&#8217;s co-president Rob Steffens and chief counsel John Turitzin, Variety reported. The ex-chairman ...

## Ben Shapiro Breaks Down Why Big Media Blames You For Nashville School Attack
 - [https://www.dailywire.com/news/ben-shapiro-breaks-down-why-big-media-blames-you-for-nashville-school-attack](https://www.dailywire.com/news/ben-shapiro-breaks-down-why-big-media-blames-you-for-nashville-school-attack)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 15:59:29+00:00

If you don’t believe gender dysphoric people can change their biological sex, big media thinks you share blame for Monday’s Nashville school shooting, Ben Shapiro said Wednesday. The shooting at a Christian elementary school, which left three children and three adults dead, was carried out by a 28-year-old woman who believed she was a man. ...

## California Is $777 Billion In Debt, But A Task Force Is Mulling An $800 Billion Reparations Package
 - [https://www.dailywire.com/news/california-is-777-billion-in-debt-but-a-task-force-is-mulling-an-800-billion-reparations-package](https://www.dailywire.com/news/california-is-777-billion-in-debt-but-a-task-force-is-mulling-an-800-billion-reparations-package)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 15:45:40+00:00

What are they smoking out in California? Don&#8217;t answer that question, we don&#8217;t want to know, but we do want to know how exactly the Golden State&#8216;s government is seriously considering a reparations package for its black citizens that would cost at least $800 billion. California is currently in roughly $777 billion in debt. Following ...

## Garland ‘More Than Willing’ To Appear Before Jordan’s Judiciary Committee
 - [https://www.dailywire.com/news/garland-more-than-willing-to-appear-before-jordans-judiciary-committee](https://www.dailywire.com/news/garland-more-than-willing-to-appear-before-jordans-judiciary-committee)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 15:39:45+00:00

Attorney General Merrick Garland said on Wednesday he is willing to appear before the House Judiciary Committee. Rep. Ben Cline (R-VA) brought up the issue during a House Appropriations Committee hearing, noting that he is also a member of the judiciary panel led by Chairman Jim Jordan (R-OH) that has oversight of the Justice Department. ...

## GOP Senators Lead Charge Against Biden Trying To Nix Rule Protecting Campus Religious Groups
 - [https://www.dailywire.com/news/gop-senators-lead-charge-against-biden-trying-to-nix-rule-protecting-campus-religious-groups](https://www.dailywire.com/news/gop-senators-lead-charge-against-biden-trying-to-nix-rule-protecting-campus-religious-groups)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 15:38:02+00:00

Senate Republicans introduced legislation to codify a rule protecting the freedom for religious groups to assemble on college campuses as the Biden administration seeks to reverse them. The Trump administration introduced the Religious Liberty and Free Inquiry Rule three years ago in order to ensure that public universities do not deny religious student organizations “any ...

## Attorneys In Gwyneth Paltrow Trial Couldn’t Access A Document. A Court TV Viewer Did It In ‘Like Two Minutes’
 - [https://www.dailywire.com/news/attorneys-in-gwyneth-paltrow-trial-couldnt-access-a-document-a-court-tv-viewer-did-it-in-like-two-minutes](https://www.dailywire.com/news/attorneys-in-gwyneth-paltrow-trial-couldnt-access-a-document-a-court-tv-viewer-did-it-in-like-two-minutes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 15:19:42+00:00

Oscar-winning actress Gwyneth Paltrow is facing a lawsuit by a retired optometrist who claims she collided with him on a ski slope in 2016, causing permanent brain damage. Paltrow’s attorneys were trying to open a link to documents containing messages between Terry Sanderson, the optometrist, and others involved in the trial, but apparently couldn’t figure ...

## Pope Francis Hospitalized In Rome, Will Stay A ‘Few Days,’ Vatican Says
 - [https://www.dailywire.com/news/pope-francis-hospitalized-in-rome-will-stay-a-few-days-vatican-says](https://www.dailywire.com/news/pope-francis-hospitalized-in-rome-will-stay-a-few-days-vatican-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 15:18:56+00:00

Pope Francis will be hospitalized in Rome for a &#8220;few days&#8221; after a scheduled checkup on Wednesday, according to the Vatican. Francis, 86, visited the Gemelli Hospital Wednesday afternoon for his checkup, Holy See spokesman Matteo Bruni said. The Vatican later said that Francis went to the hospital for a respiratory infection after experiencing breathing ...

## Tucker Carlson Responds After Dishonest Headlines Say He Called Trans People ‘The Enemy’ Of Christianity
 - [https://www.dailywire.com/news/tucker-carlson-responds-after-dishonest-headlines-say-he-called-trans-people-the-enemy-of-christianity](https://www.dailywire.com/news/tucker-carlson-responds-after-dishonest-headlines-say-he-called-trans-people-the-enemy-of-christianity)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 15:11:34+00:00

Tucker Carlson declared during his Tuesday monologue that the &#8220;trans movement&#8221; was the &#8220;mirror image&#8221; and therefore the &#8220;natural enemy&#8221; of Christianity – and it wasn&#8217;t long before media outlets had twisted his words to make it appear as though he was targeting people. Carlson addressed the tragic Monday shooting that took place at The ...

## NHL Reportedly Considering Dumping LGBTQ Pride Events At Games
 - [https://www.dailywire.com/news/nhl-reportedly-considering-dumping-lgbtq-pride-events-at-games](https://www.dailywire.com/news/nhl-reportedly-considering-dumping-lgbtq-pride-events-at-games)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 14:55:46+00:00

In the wake of several NHL players refusing to wear pride-themed attire, the league is reportedly considering shelving Pride night events at its games. Last week, two brothers who are teammates on the NHL’s Florida Panthers refused to wear a pride-themed sweater during the team’s warmup skate, citing their religious beliefs. Eric and Marc Staal ...

## Sec Def Austin Smirks, Denies Drag Events Held At Military Bases Were Supported By Defense Department
 - [https://www.dailywire.com/news/sec-def-austin-smirks-denies-drag-events-held-at-military-bases-were-supported-by-defense-department](https://www.dailywire.com/news/sec-def-austin-smirks-denies-drag-events-held-at-military-bases-were-supported-by-defense-department)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 14:39:00+00:00

Defense Secretary Lloyd Austin smirked when asked by Congressman Matt Gaetz (R-FL) why drag queen events at military bases were happening. Gaetz cited drag events at various military bases, including Malmstrom Air Force Base in Montana, Joint Base Langley-Eustis in Virginia, and Nellis Air Force Base northeast of Las Vegas, Nevada. “How much taxpayer money ...

## Katy Perry Celebrates Sobriety Milestone After Making No-Alcohol ‘Pact’ With Fiancé Orlando Bloom
 - [https://www.dailywire.com/news/katy-perry-celebrates-sobriety-milestone-after-making-no-alcohol-pact-with-fiance-orlando-bloom](https://www.dailywire.com/news/katy-perry-celebrates-sobriety-milestone-after-making-no-alcohol-pact-with-fiance-orlando-bloom)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 14:29:45+00:00

Katy Perry celebrated a sobriety milestone of five weeks sober this week after she made a no-alcohol &#8220;pact&#8221; with her fiancé Orlando Bloom. During the 38-year-old pop singer&#8217;s appearance on Monday at a cocktail event in New York City, Perry revealed that she&#8217;s been wanting to quit alcohol, People magazine reported. &#8220;I&#8217;ve been sober for ...

## Two Pro-Fisherman Plead Guilty To Felony Charges For Cheating In Tournament
 - [https://www.dailywire.com/news/two-pro-fisherman-plead-guilty-to-felony-charges-for-cheating-in-tournament](https://www.dailywire.com/news/two-pro-fisherman-plead-guilty-to-felony-charges-for-cheating-in-tournament)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 14:14:10+00:00

Two pro fishermen pleaded guilty this week to felony charges stemming from an Ohio fishing tournament last year where they were allegedly caught stuffing their fish with lead weights to win. Jacob Runyan and teammate Chase Cominsky were set to win $28,760 until an official at the tournament became suspicious and the fish were cut open. ...

## He Was Falsely Accused Of Rape By ‘The Lovely Bones’ Author. New York Will Pay Him $5.5 Million.
 - [https://www.dailywire.com/news/he-was-falsely-accused-of-rape-by-the-lovely-bones-author-new-york-will-pay-him-5-5-million](https://www.dailywire.com/news/he-was-falsely-accused-of-rape-by-the-lovely-bones-author-new-york-will-pay-him-5-5-million)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 14:13:11+00:00

The man wrongfully convicted of raping “The Lovely Bones” author Alice Sebold will receive $5.5 million in compensation from New York state. Anthony Broadwater spent 16 years in prison for allegedly raping Sebold, who detailed the alleged crime in her 1999 memoir, “Lucky,” The Daily Wire previously reported. Broadwater was exonerated on November 22, 2021, more ...

## Senate Votes To Repeal Iraq Military Authorizations
 - [https://www.dailywire.com/news/senate-votes-to-repeal-iraq-military-authorizations](https://www.dailywire.com/news/senate-votes-to-repeal-iraq-military-authorizations)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 14:10:07+00:00

The Senate voted on Wednesday to repeal the authorizations for the Iraq and Persian Gulf wars decades after they were instituted. Eighteen Republicans joined all voting Democrats and independents in supporting the measure. The final tally was 66-30, with four members not voting, according to C-SPAN. 66-30: Senate votes to repeal the 1991 and 2002 ...

## ‘Insulting Women’: Kate Spade Slammed For Promoting Women’s Spring Line With Dylan Mulvaney
 - [https://www.dailywire.com/news/insulting-women-kate-spade-slammed-for-promoting-womens-spring-line-with-dylan-mulvaney](https://www.dailywire.com/news/insulting-women-kate-spade-slammed-for-promoting-womens-spring-line-with-dylan-mulvaney)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 14:09:58+00:00

Designer fashion house Kate Spade has been slammed on social media for promoting its 2023 women&#8217;s spring line with biological male trans-identifying activist Dylan Mulvaney. In a TikTok video that has since gone viral, Mulvaney dons a blue and white floral dress while at the Kate Spade shop in New York. Mulvaney can be seen ...

## Feds Open Investigation Into Chocolate Factory Explosion That Left 7 Dead
 - [https://www.dailywire.com/news/feds-open-investigation-into-chocolate-factory-explosion-that-left-7-dead](https://www.dailywire.com/news/feds-open-investigation-into-chocolate-factory-explosion-that-left-7-dead)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 13:47:13+00:00

The National Transportation Safety Board has opened an investigation into the explosion last week at a Pennsylvania chocolate factory that left several people dead. The explosion, which occurred on March 24 at the R.M. Palmer Company chocolate factory in West Reading, Pennsylvania, led to the deaths of seven individuals and the hospitalization of 10 others. ...

## Troubled Swiss Bank Helped Americans Stash Massive Fortunes Abroad, Bombshell Senate Report And Whistleblowers Say
 - [https://www.dailywire.com/news/troubled-swiss-bank-helped-americans-stash-massive-fortunes-abroad-bombshell-senate-report-and-whistleblowers-say](https://www.dailywire.com/news/troubled-swiss-bank-helped-americans-stash-massive-fortunes-abroad-bombshell-senate-report-and-whistleblowers-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 13:40:55+00:00

Swiss investment bank Credit Suisse has helped American families hide at least $700 million from tax authorities over the past nine years in violation of a plea agreement with regulators, Senate investigators said Wednesday. Credit Suisse, which was acquired earlier this month by rival Swiss financial institution UBS with the assistance of the nation’s central ...

## Press Secretary For Gov. Katie Hobbs Resigns After Tweet Suggesting ‘Transphobes’ Should Be Shot
 - [https://www.dailywire.com/news/press-secretary-for-gov-katie-hobbs-resigns-after-tweet-suggesting-transphobes-should-be-shot](https://www.dailywire.com/news/press-secretary-for-gov-katie-hobbs-resigns-after-tweet-suggesting-transphobes-should-be-shot)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 13:11:59+00:00

Josselyn Berry, press secretary for Democratic Arizona Gov. Katie Hobbs, has resigned after posting an inflammatory tweet suggesting “transphobes” should be gunned down in the wake of a woman who identified as transgender killing six people at a Christian school in Nashville. Local Arizona media reported that Berry&#8217;s resignation came after she faced pressure from those ...

## ‘I’d Do It Again’: Jeremy Renner Gives First Interview Since Near-Fatal Accident
 - [https://www.dailywire.com/news/id-do-it-again-jeremy-renner-gives-first-interview-since-near-fatal-accident](https://www.dailywire.com/news/id-do-it-again-jeremy-renner-gives-first-interview-since-near-fatal-accident)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 13:09:42+00:00

In his first interview since his near-fatal snow plow accident, actor Jeremy Renner recalled jumping into action to save his nephew and declared: &#8220;I&#8217;d do it again.&#8221; Renner sat down with veteran journalist Diane Sawyer to discuss the accident and his recovery. The full interview — titled &#8220;Jeremy Renner: The Diane Sawyer Interview – A ...

## Manhattan Grand Jury Taking A Previously Scheduled Month-Long Break: Report
 - [https://www.dailywire.com/news/manhattan-grand-jury-taking-a-previously-scheduled-month-long-break-report](https://www.dailywire.com/news/manhattan-grand-jury-taking-a-previously-scheduled-month-long-break-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 12:56:33+00:00

The Manhattan grand jury investigating former President Donald Trump&#8217;s alleged $130,000 hush money payment to adult film actress Stormy Daniels won&#8217;t hear evidence in the case for a month as it goes on a previously scheduled break. POLITICO reported that any potential indictment of Trump would not happen until at least the end of April unless ...

## Feds Offer Big Reward In Manhunt For Top Aide To Ex-GOP Governor
 - [https://www.dailywire.com/news/feds-offer-big-reward-in-manhunt-for-top-aide-to-ex-gop-governor](https://www.dailywire.com/news/feds-offer-big-reward-in-manhunt-for-top-aide-to-ex-gop-governor)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 12:45:06+00:00

Federal law enforcement officials are offering up to $20,000 for information leading to the capture of former Maryland Governor Larry Hogan&#8216;s ex-chief of staff after he failed to appear in court for his criminal trial. Authorities began searching for fugitive Roy McGrath two weeks ago after he failed to show up for his corruption trial ...

## Jennifer Aniston Says ‘A Whole Generation Of People’ Think ‘Friends’ Is ‘Offensive’ Now
 - [https://www.dailywire.com/news/jennifer-aniston-says-a-whole-generation-of-people-think-friends-is-offensive-now](https://www.dailywire.com/news/jennifer-aniston-says-a-whole-generation-of-people-think-friends-is-offensive-now)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 12:39:28+00:00

Actress Jennifer Aniston says that modern audiences take issue with some of the jokes on the classic hit NBC comedy “Friends.” The iconic series premiered in 1994 during a very different time. “There’s a whole generation of people, kids, who are now going back to episodes of ‘Friends’ and find them offensive,” Aniston told the ...

## JPMorgan Chase CEO Jamie Dimon Will Be Deposed Under Oath About Bank’s Links To Jeffrey Epstein
 - [https://www.dailywire.com/news/jpmorgan-chase-ceo-jamie-dimon-will-be-deposed-under-oath-about-banks-links-to-jeffrey-epstein](https://www.dailywire.com/news/jpmorgan-chase-ceo-jamie-dimon-will-be-deposed-under-oath-about-banks-links-to-jeffrey-epstein)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 12:08:00+00:00

JPMorgan Chase CEO Jamie Dimon will be interviewed under oath about his company’s ties with deceased child sex predator and financier Jeffrey Epstein. Lawsuits from an unnamed victim of Epstein and the government of the U.S. Virgin Islands allege that JPMorgan Chase benefited financially from its relationship with the pedophile. Attorneys have uncovered communications from ...

## Tennessee GOP Rep Calls For National Religious Revival After Nashville Shooting
 - [https://www.dailywire.com/news/tennessee-gop-rep-calls-for-national-religious-revival-after-nashville-shooting](https://www.dailywire.com/news/tennessee-gop-rep-calls-for-national-religious-revival-after-nashville-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 11:51:13+00:00

A Tennessee congressman responded to the tragic Nashville school shooting by calling for a national religious revival, comments that came a few weeks after a campus revival in Kentucky inspired thousands of people from around the country to gather together in prayer and worship. GOP Rep. Tim Burchett from Knoxville spoke with reporters near the ...

## Family Expects Stabbed Rand Paul Staffer To Make Full Recovery
 - [https://www.dailywire.com/news/family-expects-stabbed-rand-paul-staffer-to-make-full-recovery](https://www.dailywire.com/news/family-expects-stabbed-rand-paul-staffer-to-make-full-recovery)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 11:49:14+00:00

Sen. Rand Paul&#8217;s (R-KY) staffer who was attacked by a knife-wielding man in Washington, D.C., last weekend is expected to make a full recovery, according to his parents. Chuck and Helen Todd released a statement on Wednesday providing an update on the health of their son, Phillip Todd, and asking for privacy so that they ...

## Why We Should All Be Happy At The Coming Death Of TikTok
 - [https://www.dailywire.com/news/why-we-should-all-be-happy-at-the-coming-death-of-tiktok](https://www.dailywire.com/news/why-we-should-all-be-happy-at-the-coming-death-of-tiktok)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 11:31:15+00:00

In his brilliant pandemic-inspired comedy special &#8220;Inside,&#8221; Bo Burnham muses about our children&#8217;s use of social media. &#8220;I don’t know about you guys, but, um, you know, I’ve been thinking recently that, that, you know, maybe, um, allowing giant digital media corporations to exploit the neurochemical drama of our children for profit,&#8221; Burnham says. &#8220;You ...

## Musk, Wozniak, Other Tech Leaders Call For Six-Month Pause On AI Development
 - [https://www.dailywire.com/news/musk-wozniak-other-tech-leaders-call-for-six-month-pause-on-ai-development](https://www.dailywire.com/news/musk-wozniak-other-tech-leaders-call-for-six-month-pause-on-ai-development)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 11:18:34+00:00

Tesla chief executive Elon Musk, Apple co-founder Steve Wozniak, and hundreds of other technology leaders called for a pause on the development of powerful artificial intelligence due to the “profound risks” that the nascent systems pose to mankind. ChatGPT, an AI language processing tool, has earned worldwide recognition in recent months as knowledge workers leverage ...

## More Taxpayer-Funded Freebies On The Table For Illegal Aliens In Maine
 - [https://www.dailywire.com/news/more-taxpayer-funded-freebies-on-the-table-for-illegal-aliens-in-maine](https://www.dailywire.com/news/more-taxpayer-funded-freebies-on-the-table-for-illegal-aliens-in-maine)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 11:00:43+00:00

The Pine Tree State has a poverty rate of about 10.6% but nonetheless, the ol&#8217; moonbats in Maine want to bring in more impoverished people from around the globe by offering taxpayer-funded healthcare to even more illegal aliens over the age of 21. Maine has become a bit of a hotspot for illegal aliens, many ...

## The Government’s Response To SVB’s Collapse Could Make Another Banking Crisis More Likely — And More Destructive
 - [https://www.dailywire.com/news/the-governments-response-to-svbs-collapse-could-make-another-banking-crisis-more-likely-and-more-destructive](https://www.dailywire.com/news/the-governments-response-to-svbs-collapse-could-make-another-banking-crisis-more-likely-and-more-destructive)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 11:00:42+00:00

On March 10, Silicon Valley Bank — which lends to almost half of all the publicly traded venture capital-backed tech and healthcare companies — collapsed. It was the second largest bank failure in U.S. history, second only to Washington Mutual&#8217;s downfall in 2008. The sudden meltdown of SVB, and the subsequent failure of Signature Bank, ...

## Priyanka Chopra Discusses Leaving Bollywood For Hollywood: ‘Tired Of The Politics’
 - [https://www.dailywire.com/news/priyanka-chopra-discusses-leaving-bollywood-for-hollywood-tired-of-the-politics](https://www.dailywire.com/news/priyanka-chopra-discusses-leaving-bollywood-for-hollywood-tired-of-the-politics)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 10:44:55+00:00

Actress Priyanka Chopra discussed making the switch from India&#8217;s Bollywood to the American movie industry. “I was being pushed into a corner in the industry. I had people not casting me for reasons. I had a beef with people. Again, I’m not good at playing that game. I was tired of the politics,” Chopra told ...

## Fired Marvel Exec Slams Disney, Said She ‘Refused To Do Something She Believed Was Reprehensible’
 - [https://www.dailywire.com/news/fired-marvel-exec-slams-disney-said-she-refused-to-do-something-she-believed-was-reprehensible](https://www.dailywire.com/news/fired-marvel-exec-slams-disney-said-she-refused-to-do-something-she-believed-was-reprehensible)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 10:36:46+00:00

Former Marvel Studios executive Victoria Alonso is now speaking out via her attorney, alluding that her firing was about more than just a breach of contract.  News of Alonso’s termination came with rumors that she’d been let go due to her promotion of the Oscar-nominated Amazon project “Argentina, 1985.” Now, she’s saying there’s more to ...

## ‘F***ing Sick Of The Knee Jerk ‘It’s The Guns”: Megyn Kelly Rips Gun Control Advocates After Nashville Shooting
 - [https://www.dailywire.com/news/fing-sick-of-the-knee-jerk-its-the-guns-megyn-kelly-rips-gun-control-advocates-after-nashville-shooting](https://www.dailywire.com/news/fing-sick-of-the-knee-jerk-its-the-guns-megyn-kelly-rips-gun-control-advocates-after-nashville-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 10:02:48+00:00

Former Fox News anchor and current podcast host Megyn Kelly, who has a nine-year-old child of her own, fired back at calls from gun control advocates after the Nashville school shooting in which three nine-year-olds were murdered. A 28-year-old woman who identified as a transgender man murdered three students and three adults on Monday at ...

## Michael Knowles Suspended From Twitter After Posting Bible Verse In Response To Nashville School Shooting
 - [https://www.dailywire.com/news/michael-knowles-suspended-from-twitter-after-posting-bible-verse-in-response-to-nashville-school-shooting](https://www.dailywire.com/news/michael-knowles-suspended-from-twitter-after-posting-bible-verse-in-response-to-nashville-school-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 10:01:08+00:00

Daily Wire host Michael Knowles was suspended from Twitter after he posted a Bible verse in response to the Monday shooting at The Covenant School in Nashville, Tennessee. Knowles appears to have been impacted by a widespread Twitter crackdown against conservative accounts criticizing or simply alluding to the Trans Radical Activist Network&#8217;s recent call for ...

## Melissa Joan Hart Tearfully Recounts Helping Kindergartners Escape Nashville Shooting
 - [https://www.dailywire.com/news/melissa-joan-hart-tearfully-recounts-helping-kindergartners-escape-nashville-shooting](https://www.dailywire.com/news/melissa-joan-hart-tearfully-recounts-helping-kindergartners-escape-nashville-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 08:58:06+00:00

Actress Melissa Joan Hart said in a tearful video Tuesday that she and her husband helped kindergartners flee the Nashville school shooting. Hart and her husband, Mark Wilkerson, have three sons, ages 17, 15, and 10. Hart is known for starring in the sitcoms “Clarissa Explains It All,” “Sabrina the Teenage Witch,” and “Melissa and Joey.” ...

## When A Trans Person Murders Christian Schoolchildren
 - [https://www.dailywire.com/news/when-a-trans-person-murders-christian-schoolchildren](https://www.dailywire.com/news/when-a-trans-person-murders-christian-schoolchildren)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 08:38:07+00:00

The legacy media have a pre-set narrative machine when it comes to mass shootings. That narrative machine takes into account the identities of the shooter and the victims, and then churns out an explanation for the shooting. White shooter, black victims: systemic racism. Black shooter, white victims: alienation caused by systemic racism. Muslim shooter, gay ...

## Head Of Nashville School Murdered When She Ran Toward Shooter: Report
 - [https://www.dailywire.com/news/head-of-nashville-school-murdered-when-she-ran-toward-shooter-report](https://www.dailywire.com/news/head-of-nashville-school-murdered-when-she-ran-toward-shooter-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 08:33:03+00:00

The headmistress of The Covenant School in Nashville, where a woman who identified as transgender shot and killed three 9-year-old children and three adults, reportedly ran toward the shooter before she herself was murdered. Dr. Katherine Koonce, 61, was gunned down by the shooter in the corridor after the shooter shot through the locked glass ...

## Katie Hobbs’ Spokeswoman Blasted For Horrific Tweet Following Nashville School Shooting
 - [https://www.dailywire.com/news/katie-hobbs-spokeswoman-blasted-for-horrific-tweet-following-nashville-school-shooting](https://www.dailywire.com/news/katie-hobbs-spokeswoman-blasted-for-horrific-tweet-following-nashville-school-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-29 07:10:11+00:00

Arizona Governor Katie Hobbs’ spokeswoman was blasted online after she tweeted an image suggesting “transphobes” should be gunned down hours after a woman who identified as transgender killed six people, including three young children inside a Nashville Christian school. The GIF, taken from the 1980 film “Gloria,” tweeted by Josselyn Berry, Hobbs’ press secretary, showed ...

