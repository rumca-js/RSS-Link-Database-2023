# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## ⛆ ChatGPT znów odkrywa tajemnice: tym razem własne
 - [https://www.youtube.com/watch?v=JwjxiH-mmQs](https://www.youtube.com/watch?v=JwjxiH-mmQs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-03-29 04:00:11+00:00

ChatGPT zawiesił swoją działalność na jeden ponury poniedziałek, ze względu na pewnego nieproszonego gościa - błąd, który dawał użytkownikom możliwość zaglądania w tytuły historii rozmów innych. Wskutek tego, OpenAI musiało się spieszyć, żeby naprawić ten mały, ale niebezpieczny szczegół.


Źródło:
http://bit.ly/3JB3wN3

#ai #chatgpt #bezpieczeństwo #luka

