# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## College Freshman Explains Socialism To Cuban Who Escaped On A Raft
 - [https://www.youtube.com/watch?v=c7vdtqcFrJ4](https://www.youtube.com/watch?v=c7vdtqcFrJ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2023-03-29 19:29:03+00:00

Brett is a college freshman. He knows all about socialism because his socialist professor told him all about it. And he's ready to share his knowledge with a man who escaped socialism on a raft.

#shorts

