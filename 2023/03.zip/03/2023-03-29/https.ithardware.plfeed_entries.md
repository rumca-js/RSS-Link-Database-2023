# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Mozilla Firefox zamierza dłużej wspierać Windowsa 7 i 8.1
 - [https://ithardware.pl/aktualnosci/mozilla_firefox_zamierza_dluzej_wspierac_windowsa_7_i_8_1-26565.html](https://ithardware.pl/aktualnosci/mozilla_firefox_zamierza_dluzej_wspierac_windowsa_7_i_8_1-26565.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 21:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26565_1.jpg" />            Mozilla Firefox wycofa&nbsp;wsparcie dla starszych system&oacute;w operacyjnych Windows 7 i 8.1, o czym pisaliśmy już w zeszłym roku, wskazując 2023 r. Okazuje się, że producent wydłuży ten okres o rok.

Windows 7 przestał być wspierany przez...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mozilla_firefox_zamierza_dluzej_wspierac_windowsa_7_i_8_1-26565.html">https://ithardware.pl/aktualnosci/mozilla_firefox_zamierza_dluzej_wspierac_windowsa_7_i_8_1-26565.html</a></p>

## GeForce RTX 4050 - znamy przybliżoną datę premiery i częściową specyfikację
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4050_znamy_przyblizona_date_premiery_i_czesciowa_specyfikacje-26563.html](https://ithardware.pl/aktualnosci/geforce_rtx_4050_znamy_przyblizona_date_premiery_i_czesciowa_specyfikacje-26563.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 18:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/26563_1.jpg" />            Poznaliśmy nieoficjalne informacje o specyfikacji i przypuszczalnej dacie premiery karty graficznej NVIDIA GeForce RTX 4050. Pierwsze wzmianki o tym układzie graficznym pojawiły się w zeszłym roku.

Leaker o pseudonimie&nbsp;MEGAsizeGPU ujawnił...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4050_znamy_przyblizona_date_premiery_i_czesciowa_specyfikacje-26563.html">https://ithardware.pl/aktualnosci/geforce_rtx_4050_znamy_przyblizona_date_premiery_i_czesciowa_specyfikacje-26563.html</a></p>

## Atomic Heart - test kart graficznych w dobrze zoptymalizowanej grze
 - [https://ithardware.pl/testyirecenzje/atomic_heart_test_kart_graficznych-26558.html](https://ithardware.pl/testyirecenzje/atomic_heart_test_kart_graficznych-26558.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 17:25:00+00:00

<img src="https://ithardware.pl/artykuly/min/26558_1.jpg" />            Atomic Heart - test kart graficznych

Dzisiejszy test poświęcony jest Atomic Heart, czyli drugiej grze w dorobku studia Mundfish, kt&oacute;rej postanowiliśmy przyjrzeć się od strony osiąg&oacute;w kart graficznych. Fabularnie omawiany tytuł...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/atomic_heart_test_kart_graficznych-26558.html">https://ithardware.pl/testyirecenzje/atomic_heart_test_kart_graficznych-26558.html</a></p>

## Lenovo rezygnuje z gamingowych smartfonów
 - [https://ithardware.pl/aktualnosci/lenovo_rezygnuje_z_gamingowych_smartfonow-26562.html](https://ithardware.pl/aktualnosci/lenovo_rezygnuje_z_gamingowych_smartfonow-26562.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 16:40:00+00:00

<img src="https://ithardware.pl/artykuly/min/26562_1.jpg" />            Lenovo jest gigantem na rynku laptop&oacute;w, ale nie każdemu kojarzy się z branżą smartfon&oacute;w i serią gamingowych telefon&oacute;w. Najwyraźniej firma nie odniosła na tym rynku sukces&oacute;w, bo postanowiła z niego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/lenovo_rezygnuje_z_gamingowych_smartfonow-26562.html">https://ithardware.pl/aktualnosci/lenovo_rezygnuje_z_gamingowych_smartfonow-26562.html</a></p>

## Poznaliśmy możliwe miejsce akcji Wiedźmina Sirius
 - [https://ithardware.pl/aktualnosci/poznalismy_mozliwe_miejsce_akcji_wiedzmina_sirius-26561.html](https://ithardware.pl/aktualnosci/poznalismy_mozliwe_miejsce_akcji_wiedzmina_sirius-26561.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 15:47:10+00:00

<img src="https://ithardware.pl/artykuly/min/26561_1.jpg" />            Nie tak dawno temu CD Projekt RED ogłosił,&nbsp;że&nbsp;redefiniuje Wiedźmina Sirius, co oznacza, iż projekt przechodzi głębokie zmiany i może nawet powstawać od zera. Taka sytuacja zrodziła plotkę według kt&oacute;rej miejscem akcji gry...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/poznalismy_mozliwe_miejsce_akcji_wiedzmina_sirius-26561.html">https://ithardware.pl/aktualnosci/poznalismy_mozliwe_miejsce_akcji_wiedzmina_sirius-26561.html</a></p>

## Morele.net nie musi płacić kary za wyciek danych klientów
 - [https://ithardware.pl/aktualnosci/morele_net_nie_musi_placic_kary_za_wyciek_danych_osobowych-26560.html](https://ithardware.pl/aktualnosci/morele_net_nie_musi_placic_kary_za_wyciek_danych_osobowych-26560.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 14:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/26560_1.jpg" />            W 2018 roku ze sklepu internetowego Morele.net wyciekły dane klient&oacute;w, kt&oacute;re zaczęły krążyć po sieci i być wykorzystywane do przestępstw w tym prześladowań innych ludzi. Na firmę nałożono rekordową karę, kt&oacute;rej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/morele_net_nie_musi_placic_kary_za_wyciek_danych_osobowych-26560.html">https://ithardware.pl/aktualnosci/morele_net_nie_musi_placic_kary_za_wyciek_danych_osobowych-26560.html</a></p>

## Endorfy Scrim – nowe fotele nie tylko dla graczy
 - [https://ithardware.pl/aktualnosci/endorfy_scrim_nowe_fotele_nie_tylko_dla_graczy-26559.html](https://ithardware.pl/aktualnosci/endorfy_scrim_nowe_fotele_nie_tylko_dla_graczy-26559.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 12:53:49+00:00

<img src="https://ithardware.pl/artykuly/min/26559_1.jpg" />            Marka Endorfy prezentuje nową serię foteli Scrim, kt&oacute;re są przeznaczone nie tylko dla graczy, ale r&oacute;wnież tw&oacute;rc&oacute;w spędzających długie godziny na siedzeniu przed komputerem.&nbsp;Scrimy kupimy&nbsp;w kilku wariantach...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/endorfy_scrim_nowe_fotele_nie_tylko_dla_graczy-26559.html">https://ithardware.pl/aktualnosci/endorfy_scrim_nowe_fotele_nie_tylko_dla_graczy-26559.html</a></p>

## Amazon zaczyna oznaczać często zwracane produkty
 - [https://ithardware.pl/aktualnosci/amazon_zaczyna_oznaczac_czesto_zwracane_produkty-26555.html](https://ithardware.pl/aktualnosci/amazon_zaczyna_oznaczac_czesto_zwracane_produkty-26555.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 11:50:01+00:00

<img src="https://ithardware.pl/artykuly/min/26555_1.jpg" />            Amazon zaczął wyświetlać ostrzeżenie o często zwracanych przedmiotach, ponieważ firma zaciska pasa w odpowiedzi na trudną sytuację gospodarczą. Zwroty zakupionych produkt&oacute;w w całej branży gwałtownie wzrosły podczas pandemii i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amazon_zaczyna_oznaczac_czesto_zwracane_produkty-26555.html">https://ithardware.pl/aktualnosci/amazon_zaczyna_oznaczac_czesto_zwracane_produkty-26555.html</a></p>

## Metal Gear Solid 3 - remake kultowej gry coraz bliżej. Nowe przecieki
 - [https://ithardware.pl/aktualnosci/metal_gear_solid_3_remake_kultowej_gry_coraz_blizej_nowe_przecieki-26554.html](https://ithardware.pl/aktualnosci/metal_gear_solid_3_remake_kultowej_gry_coraz_blizej_nowe_przecieki-26554.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 10:19:01+00:00

<img src="https://ithardware.pl/artykuly/min/26554_1.jpg" />            Wydaje się, że po latach posuchy ze strony Konami, japońska firma powoli wraca do branży gier wideo. Dotychczas wydawca skupiał się na przeniesieniu swoich starych klasyk&oacute;w 2D na nowoczesne systemy, tak jak miało to miejsce w przypadku...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/metal_gear_solid_3_remake_kultowej_gry_coraz_blizej_nowe_przecieki-26554.html">https://ithardware.pl/aktualnosci/metal_gear_solid_3_remake_kultowej_gry_coraz_blizej_nowe_przecieki-26554.html</a></p>

## Nawet drobna awaria "elektryka" często kończy się szkodą całkowitą. EV coraz mniej ekologiczne?
 - [https://ithardware.pl/aktualnosci/nawet_drobna_awaria_elektryka_czesto_konczy_sie_szkoda_calkowita_ev_coraz_mniej_ekologiczne-26557.html](https://ithardware.pl/aktualnosci/nawet_drobna_awaria_elektryka_czesto_konczy_sie_szkoda_calkowita_ev_coraz_mniej_ekologiczne-26557.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 09:42:50+00:00

<img src="https://ithardware.pl/artykuly/min/26557_1.jpg" />            Samochody elektryczne są często przedstawiane jako ekologiczna alternatywa dla transportu spalinowego, jednak nie wszystko wygląda tak r&oacute;żowo, jak się wydaje.&nbsp;Opr&oacute;cz większego zanieczyszczenia przy produkcji akumulator&oacute;w,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nawet_drobna_awaria_elektryka_czesto_konczy_sie_szkoda_calkowita_ev_coraz_mniej_ekologiczne-26557.html">https://ithardware.pl/aktualnosci/nawet_drobna_awaria_elektryka_czesto_konczy_sie_szkoda_calkowita_ev_coraz_mniej_ekologiczne-26557.html</a></p>

## AMD A620 w polskim sklepie. Poznaliśmy cenę budżetowej płyty głównej pod Ryzeny 7000
 - [https://ithardware.pl/aktualnosci/amd_a620_w_polskim_sklepie_poznalismy_cene_budzetowej_plyty_glownej_pod_ryzeny_7000-26553.html](https://ithardware.pl/aktualnosci/amd_a620_w_polskim_sklepie_poznalismy_cene_budzetowej_plyty_glownej_pod_ryzeny_7000-26553.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 09:25:01+00:00

<img src="https://ithardware.pl/artykuly/min/26553_1.jpg" />            W momencie zapowiedzi platformy Ryzen 7000 AMD obiecywało płyty gł&oacute;wne, kt&oacute;rych ceny zaczynać będą się od 125 USD i zdaje się, że producent będzie m&oacute;gł w końcu dotrzymać słowa, a to za sprawą modeli z chipsetem...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_a620_w_polskim_sklepie_poznalismy_cene_budzetowej_plyty_glownej_pod_ryzeny_7000-26553.html">https://ithardware.pl/aktualnosci/amd_a620_w_polskim_sklepie_poznalismy_cene_budzetowej_plyty_glownej_pod_ryzeny_7000-26553.html</a></p>

## GeForce RTX 4060 Ti i GeForce RTX 4060 - przybliżona data premiery i szczegóły specyfikacji
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_i_geforce_rtx_4060_przyblizona_data_premiery_i_szczegoly_specyfikacji-26552.html](https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_i_geforce_rtx_4060_przyblizona_data_premiery_i_szczegoly_specyfikacji-26552.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 08:40:01+00:00

<img src="https://ithardware.pl/artykuly/min/26552_1.jpg" />            Jak podaje Wccftech, powołując się na swoje źr&oacute;dła, GeForce RTX 4060 Ti i GeForce RTX 4060, czyli karty graficzne Ada Lovelace ze średniej p&oacute;łki cenowej od NVIDII, mają zostać wprowadzone na rynek w maju. Przypominamy, że w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_i_geforce_rtx_4060_przyblizona_data_premiery_i_szczegoly_specyfikacji-26552.html">https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_i_geforce_rtx_4060_przyblizona_data_premiery_i_szczegoly_specyfikacji-26552.html</a></p>

## Plebiscyt ITHardware For Gamers 2023. Wystartował drugi etap! Zagłosuj i wygraj!
 - [https://ithardware.pl/aktualnosci/plebiscyt_ithardware_for_gamers_2023_wystartowal_drugi_etap_zaglosuj_i_wygraj-26556.html](https://ithardware.pl/aktualnosci/plebiscyt_ithardware_for_gamers_2023_wystartowal_drugi_etap_zaglosuj_i_wygraj-26556.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 08:21:10+00:00

<img src="https://ithardware.pl/artykuly/min/26556_1.jpg" />            Drugi etap Plebiscytu ITHardware For Gamers 2023 właśnie wystartował. Po 14 dniach od pierwszego ogłoszenia i etapu, w kt&oacute;rym zbieraliśmy wszystkie propozycje z każdej kategorii produktowej nastąpił czas na głosowanie! Pamiętaj. Do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/plebiscyt_ithardware_for_gamers_2023_wystartowal_drugi_etap_zaglosuj_i_wygraj-26556.html">https://ithardware.pl/aktualnosci/plebiscyt_ithardware_for_gamers_2023_wystartowal_drugi_etap_zaglosuj_i_wygraj-26556.html</a></p>

## Pamięci RAM mocno tanieją, a będzie jeszcze taniej
 - [https://ithardware.pl/aktualnosci/pamieci_ram_mocno_tanieja_a_bedzie_jeszcze_taniej-26551.html](https://ithardware.pl/aktualnosci/pamieci_ram_mocno_tanieja_a_bedzie_jeszcze_taniej-26551.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 07:56:00+00:00

<img src="https://ithardware.pl/artykuly/min/26551_1.jpg" />            Ceny sprzętu komputerowego pozostawały bardzo wysokie w ciągu ostatnich kilku lat, ale spowolnienie sprzedaży komputer&oacute;w PC i komponent&oacute;w zaczyna przynosić efekty. Mocno tanieją bowiem nie tylko dyski SSD, ale i pamięć DRAM, a...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pamieci_ram_mocno_tanieja_a_bedzie_jeszcze_taniej-26551.html">https://ithardware.pl/aktualnosci/pamieci_ram_mocno_tanieja_a_bedzie_jeszcze_taniej-26551.html</a></p>

## The Last of Us Part I - gracze skarżą się na pecetowy port
 - [https://ithardware.pl/aktualnosci/the_last_of_us_part_i_gracze_skarza_sie_na_pecetowy_port-26550.html](https://ithardware.pl/aktualnosci/the_last_of_us_part_i_gracze_skarza_sie_na_pecetowy_port-26550.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 06:44:48+00:00

<img src="https://ithardware.pl/artykuly/min/26550_1.jpg" />            The Last of Us Part I zadebiutowało wczoraj na PC i wygląda na to, że komputerowi gracze nie są zadowoleni z portu, jaki przygotowało studio Iron Galaxy na zlecenie Sony. Jest to ekipa odpowiedzialna za pecetową wersję Uncharted, kt&oacute;ra...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/the_last_of_us_part_i_gracze_skarza_sie_na_pecetowy_port-26550.html">https://ithardware.pl/aktualnosci/the_last_of_us_part_i_gracze_skarza_sie_na_pecetowy_port-26550.html</a></p>

## XPG CYBERCORE II Platinum - nowe zasilacze z certyfikatem ATX3.0 i obsługą PCIe 5.0
 - [https://ithardware.pl/aktualnosci/xpg_cybercore_ii_platinum_nowe_zasilacze_z_certyfikatem_atx3_0_i_obsluga_pcie_5_0-26549.html](https://ithardware.pl/aktualnosci/xpg_cybercore_ii_platinum_nowe_zasilacze_z_certyfikatem_atx3_0_i_obsluga_pcie_5_0-26549.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-29 06:06:10+00:00

<img src="https://ithardware.pl/artykuly/min/26549_1.jpg" />            Gamingowa marka XPG, należąca do ADATA, ogłosiła globalną premierę najnowszej odsłony swojej modułowej serii zasilaczy z certyfikatem Platinum - XPG CYBERCORE II.

XPG oferuje dwa nowe modele zasilaczy o mocy odpowiednio 1000W i 1300W, dzięki...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/xpg_cybercore_ii_platinum_nowe_zasilacze_z_certyfikatem_atx3_0_i_obsluga_pcie_5_0-26549.html">https://ithardware.pl/aktualnosci/xpg_cybercore_ii_platinum_nowe_zasilacze_z_certyfikatem_atx3_0_i_obsluga_pcie_5_0-26549.html</a></p>

