# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Morawiecki pisze do prezesów Big Tech-ów. "Państwa wsparcie jest niezbędne"
 - [https://tvn24.pl/biznes/tech/morawiecki-pisze-do-prezesow-big-tech-ow-panstwa-wsparcie-jest-niezbedne-6876226?source=rss](https://tvn24.pl/biznes/tech/morawiecki-pisze-do-prezesow-big-tech-ow-panstwa-wsparcie-jest-niezbedne-6876226?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 19:45:58+00:00

<img alt="Morawiecki pisze do prezesów Big Tech-ów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sb4tdz-mateusz-morawiecki-6858678/alternates/LANDSCAPE_1280" />
    Premier Mateusz Morawiecki i liderzy państw regionu: Ukrainy, Litwy, Łotwy, Czech, Słowacji i Estonii piszą do prezesów spółek Big Tech w sprawie walki z dezinformacją i wskazują na pomocne dla wspólnej sprawy działania ze strony platform internetowych.

## Morawiecki pisze do prezesów Big Techów. "Państwa wsparcie jest niezbędne"
 - [https://tvn24.pl/biznes/tech/morawiecki-pisze-do-prezesow-big-techow-panstwa-wsparcie-jest-niezbedne-6876226?source=rss](https://tvn24.pl/biznes/tech/morawiecki-pisze-do-prezesow-big-techow-panstwa-wsparcie-jest-niezbedne-6876226?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 19:45:58+00:00

<img alt="Morawiecki pisze do prezesów Big Techów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sb4tdz-mateusz-morawiecki-6858678/alternates/LANDSCAPE_1280" />
    Premier Mateusz Morawiecki i liderzy państw regionu: Ukrainy, Litwy, Łotwy, Czech, Słowacji i Estonii piszą do prezesów spółek Big Tech w sprawie walki z dezinformacją i wskazują na pomocne dla wspólnej sprawy działania ze strony platform internetowych.

## Strata Tauronu. Powodem "wyjątkowo dynamiczna sytuacja na rynkach energii i paliw"
 - [https://tvn24.pl/biznes/z-kraju/grupa-tauron-wynik-finansowy-za-2022-rok-strata-netto-wyniosla-134-milionow-zlotych-6876377?source=rss](https://tvn24.pl/biznes/z-kraju/grupa-tauron-wynik-finansowy-za-2022-rok-strata-netto-wyniosla-134-milionow-zlotych-6876377?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 19:30:53+00:00

<img alt="Strata Tauronu. Powodem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z6m1k2-tauron-6876429/alternates/LANDSCAPE_1280" />
    Na wyniki finansowe za 2022 rok wpłynęła bezprecedensowa i wyjątkowo dynamiczna sytuacja na rynkach energii i paliw, zwłaszcza w zakresie dostępności węgla i jego rosnących cen - przekazał wiceprezes Taurona do spraw finansów Krzysztof Surma. Koncern podał, że strata netto Tauronu za 2022 rok wyniosła 134 milionów złotych. Wartość EBITDA - wyniku operacyjnego powiększonego o amortyzację i odpisy na aktywa niefinansowe – sięgnęła 4,016 mld zł.

## "Jesteśmy w olbrzymim dołku i dramacie". Piechociński o kłopotach producentów żywności
 - [https://tvn24.pl/biznes/z-kraju/janusz-piechocinski-jestesmy-w-olbrzymim-dolku-i-dramacie-6876250?source=rss](https://tvn24.pl/biznes/z-kraju/janusz-piechocinski-jestesmy-w-olbrzymim-dolku-i-dramacie-6876250?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 18:40:03+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pish9x-29-1925-fpf-cl-0030-6876198/alternates/LANDSCAPE_1280" />
    Jesteśmy w olbrzymim dołku i dramacie - powiedział w programie "Fakty po Faktach" były wicepremier i minister gospodarki Janusz Piechociński. Zauważył, że "jest zaledwie trzy i pół miesiąca do żniw". Zdaniem Piechocińskiego "nie ma reakcji rządu na sygnały środowiska, związków zawodowych, organizacji".

## Pieszy w szpitalu po potrąceniu w Jerozolimskich
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-pieszy-w-szpitalu-po-potraceniu-w-jerozolimskich-6876320?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-pieszy-w-szpitalu-po-potraceniu-w-jerozolimskich-6876320?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 18:37:06+00:00

<img alt="Pieszy w szpitalu po potrąceniu w Jerozolimskich" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-rbwqdu-potracenie-pieszego-w-alejach-jerozolimskich-6876311/alternates/LANDSCAPE_1280" />
    W Alejach Jerozolimskich, na skrzyżowaniu z Poznańską, doszło w środę wieczorem do potrącenia pieszego. Policja przekazała, że poszkodowana osoba trafiła do szpitala.

## Syryjczyk utknął na bagnach w Białowieskim Parku Narodowym. Akcja "w bardzo trudnym i niebezpiecznym terenie"
 - [https://tvn24.pl/polska/bialowieski-park-narodowy-granica-polsko-bialoruska-obywatel-syrii-utknal-na-bagnach-akcja-ratownicza-straz-graniczna-komentuje-6876067?source=rss](https://tvn24.pl/polska/bialowieski-park-narodowy-granica-polsko-bialoruska-obywatel-syrii-utknal-na-bagnach-akcja-ratownicza-straz-graniczna-komentuje-6876067?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 17:51:22+00:00

<img alt="Syryjczyk utknął na bagnach w Białowieskim Parku Narodowym. Akcja " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bsdkkl-cudzoziemiec-utknal-na-bagnach-6876081/alternates/LANDSCAPE_1280" />
    Straż Graniczna poinformowała, że we wtorek funkcjonariusze z placówki w Białowieży, wspólnie ze strażakami z Hajnówki ratowali cudzoziemca, który nielegalnie przekroczył białorusko-polską granicę. Akcję prowadzono na terenie Rezerwatu Ścisłego Białowieskiego Parku Narodowego. Ustalono, że cudzoziemiec to 17-letni Syryjczyk. Obecnie przebywa w placówce pograniczników w Białowieży. Ratownicy medyczni ocenili, że nie potrzebuje hospitalizacji. "Coraz częściej organizatorzy nielegalnego przekraczania granicy kierują cudzoziemców do przejścia przez Rezerwat Ścisły Białowieskiego Parku Narodowego, gdzie teren jest bardzo trudny i niebezpieczny" - wskazała w komunikacie Straż Graniczna.

## Po kolizji auto wylądowało na boku
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-po-kolizji-auto-wyladowalo-na-boku-6876176?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-po-kolizji-auto-wyladowalo-na-boku-6876176?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 17:42:16+00:00

<img alt="Po kolizji auto wylądowało na boku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-nw70il-do-zdarzenia-doszlo-na-marynarskiej-6876159/alternates/LANDSCAPE_1280" />
    Na Marynarskiej zderzyły się dwa samochody osobowe, jeden wylądował na boku. Strażacy przekazali, że w zdarzeniu nikt nie ucierpiał.

## Zełenski w czasie Szczytu dla Demokracji: musimy pozbyć się iluzji, że kompromis ze złem może coś dać wolności
 - [https://tvn24.pl/swiat/usa-szczyt-dla-demokracji-wolodymyr-zelenski-musimy-pozbyc-sie-iluzji-ze-kompromis-ze-zlem-moze-cos-dac-wolnosci-6876107?source=rss](https://tvn24.pl/swiat/usa-szczyt-dla-demokracji-wolodymyr-zelenski-musimy-pozbyc-sie-iluzji-ze-kompromis-ze-zlem-moze-cos-dac-wolnosci-6876107?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 17:36:45+00:00

<img alt="Zełenski w czasie Szczytu dla Demokracji: musimy pozbyć się iluzji, że kompromis ze złem może coś dać wolności" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1ekm1o-uczestnicy-wirtualnego-szczytu-dla-demokracji-6876144/alternates/LANDSCAPE_1280" />
    Wrogowie demokracji muszą przegrać - powiedział w czasie zorganizowanego przez władze USA wirtualnego Szczytu dla Demokracji prezydent Ukrainy Wołodymyr Zełenski. Musimy pozbyć się iluzji, że kompromis ze złem coś nam da - dodał ukraiński przywódca. Prezydent Joe Biden zapowiedział, że w ciągu najbliższych trzech lat jego administracja zamierza przeznaczyć 9,5 miliardów dolarów na promocję demokracji na całym świecie.

## "Należy spodziewać się kolejnych ograniczeń". Jak zakaz aut spalinowych wpłynie na rynek?
 - [https://tvn24.pl/biznes/z-kraju/rozporzadzenie-unii-europejskiej-o-samochodach-spalinowych-komentarze-macieja-mazura-i-krzysztofa-holowczyca-6875959?source=rss](https://tvn24.pl/biznes/z-kraju/rozporzadzenie-unii-europejskiej-o-samochodach-spalinowych-komentarze-macieja-mazura-i-krzysztofa-holowczyca-6875959?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 17:35:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e0s89m-ulica-droga-samochody-shutterstock1164370045-4684178/alternates/LANDSCAPE_1280" />
    Trzeba powiedzieć jedną niestety smutną rzecz dla samochodów elektrycznych, że baterie są najtrudniejszym elementem od strony ekologii - stwierdził w programie "Tak jest" Krzysztof Hołowczyc, kierowca rajdowy i były europoseł. Maciej Mazur, prezes Polskiego Stowarzyszenia Paliw Alternatywnych dodał, że należy się spodziewać, że w kolejnych miesiącach także zostaną wprowadzone coraz ostrzejsza normy rejestracyjne odnosząc się do rozporządzenia Unii Europejskiej o samochodach spalinowych.

## Pogoda na jutro - czwartek 30.03. Mglista noc, za dnia nawet 17 stopni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-czwartek-3003-mglista-noc-za-dnia-nawet-17-stopni-6876120?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-czwartek-3003-mglista-noc-za-dnia-nawet-17-stopni-6876120?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 17:16:20+00:00

<img alt="Pogoda na jutro - czwartek 30.03. Mglista noc, za dnia nawet 17 stopni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-mpwz1a-przed-nami-mglista-noc-6684566/alternates/LANDSCAPE_1280" />
    Pogoda na noc i czwartek 30.03. W nocy możemy spodziewać się mgieł, miejscami może zrobić się mroźnie. W ciągu dnia w większości kraju wystąpią przelotne opady deszczu. Zrobi się znacznie cieplej - termometry wskażą nawet 17 stopni.

## Przetarg na przebudowę Marszałkowskiej rozstrzygnięty
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-przetarg-na-przebudowe-marszalkowskiej-rozstrzygniety-6875822?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-przetarg-na-przebudowe-marszalkowskiej-rozstrzygniety-6875822?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 17:13:40+00:00

<img alt="Przetarg na przebudowę Marszałkowskiej rozstrzygnięty " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-n31csh-zielona-marszalkowska-wizualizacje-6596236/alternates/LANDSCAPE_1280" />
    Miasto rozstrzygnęło przetarg na modernizację ulicy Marszałkowskiej na odcinku między Królewską a placem Bankowym. - Wybrany wykonawca będzie miał za zadanie zmienić układ jezdni, wyremontować chodnik, uporządkować parkowanie, wybudować drogę dla rowerów i posadzić 63 drzewa. Koszt to ponad osiem milionów złotych - przekazał stołeczny ratusz.

## Duda: jeśli nie powstrzymamy Rosji, to Rosja pójdzie o wiele dalej
 - [https://tvn24.pl/polska/szczyt-dla-demokracji-2023-andrzej-duda-o-rosyjskiej-wojnie-na-ukrainie-6876044?source=rss](https://tvn24.pl/polska/szczyt-dla-demokracji-2023-andrzej-duda-o-rosyjskiej-wojnie-na-ukrainie-6876044?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 17:12:56+00:00

<img alt="Duda: jeśli nie powstrzymamy Rosji, to Rosja pójdzie o wiele dalej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-44zrso-andrzej-duda-6876009/alternates/LANDSCAPE_1280" />
    Rosyjska wojna w Ukrainie pokazała prawdziwą twarz reżimu Putina - powiedział w trakcie Drugiego Szczytu dla Demokracji prezydent Andrzej Duda. W swoim przemówieniu podkreślał skalę pomocy naszego kraju dla Ukraińców. - Polska dalej będzie wspierać Ukrainę, by zatrzymać ten imperializm rosyjski. Również będziemy kontynuować nasze wsparcie dla demokratycznej Białorusi - zadeklarował.

## Elon Musk i setki badaczy ostrzegają przed niekontrolowanym rozwojem sztucznej inteligencji
 - [https://tvn24.pl/biznes/ze-swiata/elon-musk-i-setki-badaczy-ai-wezwali-do-pauzy-w-rozwoju-sztucznej-inteligencji-6876050?source=rss](https://tvn24.pl/biznes/ze-swiata/elon-musk-i-setki-badaczy-ai-wezwali-do-pauzy-w-rozwoju-sztucznej-inteligencji-6876050?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 17:02:48+00:00

<img alt="Elon Musk i setki badaczy ostrzegają przed niekontrolowanym rozwojem sztucznej inteligencji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-512sc3-shutterstock_1218220324-6876043/alternates/LANDSCAPE_1280" />
    Setki biznesmenów, inwestorów i ekspertów od sztucznej inteligencji, w tym między innymi Elon Musk, wezwało we wspólnym liście do przynajmniej sześciomiesięcznej przerwy w rozwijaniu systemów AI zdolniejszych od opublikowanego w marcu GPT-4. Sygnatariusze ostrzegają przed nieprzewidywalnymi skutkami wyścigu o tworzenie coraz potężniejszych modeli.

## Trzy kobiety i dziecko w potrzasku. Ich auto porwała wezbrana rzeka
 - [https://tvn24.pl/tvnmeteo/swiat/ukraina-trzy-kobiety-i-dziecko-w-potrzasku-ich-auto-porwala-wezbrana-rzeka-6875973?source=rss](https://tvn24.pl/tvnmeteo/swiat/ukraina-trzy-kobiety-i-dziecko-w-potrzasku-ich-auto-porwala-wezbrana-rzeka-6875973?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 16:18:48+00:00

<img alt="Trzy kobiety i dziecko w potrzasku. Ich auto porwała wezbrana rzeka" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-32hy4m-trzy-kobiety-i-dziecko-uratowane-z-samochodu-na-srodku-rzeki-we-lwowie-6875946/alternates/LANDSCAPE_1280" />
    W poniedziałek w części Ukrainy panowały trudne warunki pogodowe. Strażacy z okolic Lwowa ocalili cztery osoby - w tym trzyletnie dziecko - z pojazdu porwanego przez nurt rzeki. Do kraju wróciła także zima wraz z opadami śniegu, gołoledzią i porywistym wiatrem.

## Samochód zjechał z drogi, uderzył w drzewo i spłonął. Nie żyje kierowca
 - [https://tvn24.pl/lodz/dabrowka-wielka-samochod-zjechal-z-drogi-uderzyl-w-drzewo-i-zapalil-sie-nie-zyje-kierowca-6876014?source=rss](https://tvn24.pl/lodz/dabrowka-wielka-samochod-zjechal-z-drogi-uderzyl-w-drzewo-i-zapalil-sie-nie-zyje-kierowca-6876014?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 16:13:12+00:00

<img alt="Samochód zjechał z drogi, uderzył w drzewo i spłonął. Nie żyje kierowca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a7xsw0-samochod-zjechal-z-drogi-uderzyl-w-drzewo-i-stanal-w-plomieniach-nie-zyje-kierowca-6876008/alternates/LANDSCAPE_1280" />
    W Dąbrowce Wielkiej koło Zgierza (woj. łódzkie) samochód osobowy zjechał z drogi i uderzył w drzewo. W wyniku zdarzenia pojazd stanął w płomieniach. Strażacy po ugaszeniu pożaru odnaleźli w środku zwęglone zwłoki kierowcy. Okoliczności wypadku wyjaśnia policja pod nadzorem prokuratury.

## Podczas prac budowlanych uszkodzili rurę z gazem. Autobusy na objazdach
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-rozszczelnienie-rury-z-gazem-w-ursusie-autobusy-na-objazdach-6876018?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-rozszczelnienie-rury-z-gazem-w-ursusie-autobusy-na-objazdach-6876018?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 16:11:27+00:00

<img alt="Podczas prac budowlanych uszkodzili rurę z gazem. Autobusy na objazdach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eee5dp-straz-pozarna-zdjecie-ilustracyjne-6814479/alternates/LANDSCAPE_1280" />
    Podczas prac budowlanych przy placu Czerwca 1976 roku doszło do rozszczelnienia rury z gazem. Nad usunięciem awarii pracują gazownicy, a teren zabezpieczają strażacy. Autobusy skierowano na objazdy.

## Zmiany na czele banku UBS. Powraca dawny dyrektor
 - [https://tvn24.pl/biznes/najnowsze/szwajcaria-zmiany-na-czele-banku-ubs-powraca-dawny-dyrektor-sergio-ermotti-6875921?source=rss](https://tvn24.pl/biznes/najnowsze/szwajcaria-zmiany-na-czele-banku-ubs-powraca-dawny-dyrektor-sergio-ermotti-6875921?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 15:49:29+00:00

<img alt="Zmiany na czele banku UBS. Powraca dawny dyrektor" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-7ab6y0-nowo-mianowany-dyrektor-generalny-grupy-swiss-bank-ubs-sergio-p-ermotti-6875924/alternates/LANDSCAPE_1280" />
    Dawny, wieloletni dyrektor szwajcarskiego banku UBS Sergio Ermotti powraca na swoje stanowisko - informuje Reuters. Doświadczony bankier ma odegrać kluczową rolę przy przejęciu Credit Suisse.

## Sześciolatek zawisł na płocie, przez który przechodził. W stanie ciężkim trafił do szpitala
 - [https://tvn24.pl/lodz/zytno-szesciolatek-zawisl-na-plocie-przez-ktory-przechodzil-w-stanie-ciezkim-trafil-do-szpitala-6875976?source=rss](https://tvn24.pl/lodz/zytno-szesciolatek-zawisl-na-plocie-przez-ktory-przechodzil-w-stanie-ciezkim-trafil-do-szpitala-6875976?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 15:45:17+00:00

<img alt="Sześciolatek zawisł na płocie, przez który przechodził. W stanie ciężkim trafił do szpitala" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5fp0ok-lpr-zdjecie-ilustracyjne-6759995/alternates/LANDSCAPE_1280" />
    Sześcioletni chłopiec w stanie ciężkim został zabrany śmigłowcem Lotniczego Pogotowia Ratunkowego do szpitala po tym, jak podczas przechodzenia przez płot jego kurtka zaczepiła o ogrodzenie. Dziecko miało się poddusić. Do zdarzenia doszło w małej wsi w powiecie radomszczańskim (woj. łódzkie).

## Pogrzebali kobietę żywcem na cmentarzu. Grabarz zauważył ślady krwi przy mogile
 - [https://tvn24.pl/swiat/brazylia-policja-uratowala-kobiete-pogrzebana-zywcem-na-cmentarzu-przez-gangsterow-w-tle-narkotyki-6875895?source=rss](https://tvn24.pl/swiat/brazylia-policja-uratowala-kobiete-pogrzebana-zywcem-na-cmentarzu-przez-gangsterow-w-tle-narkotyki-6875895?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 15:41:33+00:00

<img alt="Pogrzebali kobietę żywcem na cmentarzu. Grabarz zauważył ślady krwi przy mogile" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i9xq8k-brazylijska-policja-uratowala-kobiete-pogrzebana-zywcem-na-cmentarzu-przez-gangsterow-6875887/alternates/LANDSCAPE_1280" />
    Kobieta pogrzebana żywcem na cmentarzu w mieście Visconde do Rio Branco została uratowana przez funkcjonariuszy policji stanu Minas Gerais we wschodniej Brazylii. Porwana 36-latka przeżyła mimo zamurowania grobowca. Policja ustaliła, że padła ofiarą grupy przestępczej, z którą była powiązana.

## "Nieszczęście spotkało moją rodzinę". Wciąż szukają bliskich pod zwałami błota
 - [https://tvn24.pl/tvnmeteo/swiat/ekwador-osuwisko-kolejne-ofiary-smiertelne-nieszczescie-spotkalo-moja-rodzine-wciaz-szukaja-bliskich-pod-zwalami-blota-6875837?source=rss](https://tvn24.pl/tvnmeteo/swiat/ekwador-osuwisko-kolejne-ofiary-smiertelne-nieszczescie-spotkalo-moja-rodzine-wciaz-szukaja-bliskich-pod-zwalami-blota-6875837?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 15:23:57+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-alwbt3-osuwisko-w-ekwadorze-6875885/alternates/LANDSCAPE_1280" />
    Mieszkańcy Ekwadoru zaczęli już pochówki swoich najbliższych, których odebrało im niedzielne osuwisko. Poszukiwania zaginionych wciąż trwają. Do tej pory udało się ocalić 32 osoby. Wielu z nich ma nadzieję, że pod masami ziemi i gruzów znajdą swoich bliskich.

## Zgubił się w lesie i wpadł do bagna. Policjanci znaleźli go dzięki latarce w telefonie
 - [https://tvn24.pl/krakow/nisko-mezczyzna-zgubil-sie-w-lesie-i-wpadl-w-grzezawisko-6875852?source=rss](https://tvn24.pl/krakow/nisko-mezczyzna-zgubil-sie-w-lesie-i-wpadl-w-grzezawisko-6875852?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 15:19:34+00:00

<img alt="Zgubił się w lesie i wpadł do bagna. Policjanci znaleźli go dzięki latarce w telefonie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y4v0jn-shutterstock_1282926517-6875826/alternates/LANDSCAPE_1280" />
    59-latek z gminy Jeżowe (woj. podkarpackie) zadzwonił do niżańskich policjantów z informacją, że zgubił się w lesie. Mężczyzna nie mógł wydostać się z mokradła, w którym utknął. Ruszyła akcja ratunkowa.

## Zderzenie z udziałem motocyklisty i kolizja, utrudnienia na S2
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-z-udzialem-motocyklisty-i-utrudnienia-na-s2-6875835?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-z-udzialem-motocyklisty-i-utrudnienia-na-s2-6875835?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 14:53:26+00:00

<img alt="Zderzenie z udziałem motocyklisty i kolizja, utrudnienia na S2" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-grumoz-do-zdarzenia-doszlo-na-trasie-s2-6875829/alternates/LANDSCAPE_1280" />
    Na trasie S2, na wysokości Palucha, zderzyły się dwa auta osobowe i motocykl. W pobliżu doszło jeszcze do kolizji dwóch aut. Są utrudnienia.

## Luksusowy jacht rosyjskiego oligarchy trafi na licytację
 - [https://tvn24.pl/biznes/ze-swiata/antigua-i-barbuda-rzad-zlicytuje-jacht-z-ktorego-korzystal-przyjaciel-putina-6875771?source=rss](https://tvn24.pl/biznes/ze-swiata/antigua-i-barbuda-rzad-zlicytuje-jacht-z-ktorego-korzystal-przyjaciel-putina-6875771?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 14:52:20+00:00

<img alt="Luksusowy jacht rosyjskiego oligarchy trafi na licytację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mexboy-jacht-alfa-nero-6875672/alternates/LANDSCAPE_1280" />
    Rząd położonego na Karaibach państwa Antigua i Barbuda zdecydował, że zlicytuje luksusowy jacht, który cumuje w stołecznym porcie – St. John's. Jego właścicielem, jak przypuszczają lokalne władze, jest rosyjski oligarcha Andriej Guriew, działający w branży nawozów fosforowych. Jacht Alfa Nero ma 80 metrów długości i ma być wylicytowany za około 80 milionów dolarów.

## Archeolog: fragmenty kamienicy odkrytej na Muranowie są w złym stanie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-archeolog-fragmenty-kamienicy-odkrytej-na-muranowie-sa-w-zlym-stanie-6875304?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-archeolog-fragmenty-kamienicy-odkrytej-na-muranowie-sa-w-zlym-stanie-6875304?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 14:47:19+00:00

<img alt="Archeolog: fragmenty kamienicy odkrytej na Muranowie są w złym stanie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-nrqz6b-prace-archeologiczne-przy-anielewicza-6855226/alternates/LANDSCAPE_1280" />
    Niestety, relikty murów są w złym stanie, widać ślady po powstaniu w getcie i po działalności Niemców, którzy niszczyli dzielnicę żydowską - mówi Michał Grabowski, kierownik prac archeologicznych przy Anielewicza na Muranowie. Na odcinku od Karmelickiej do Jana Pawła II odsłonięto fragmenty kamienicy z przełomu XIX i XX wieku.

## 143 zgłoszenia o pozostawionym bagażu w metrze w rok
 - [https://tvn24.pl/tvnwarszawa/najnowsze/143-zgloszenia-o-pozostawionym-bagazu-w-metrze-w-rok-6875713?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/143-zgloszenia-o-pozostawionym-bagazu-w-metrze-w-rok-6875713?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 14:37:04+00:00

<img alt="143 zgłoszenia o pozostawionym bagażu w metrze w rok" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-yjp4u8-metro-w-warszawie-6875781/alternates/LANDSCAPE_1280" />
    Zgodnie z nowymi przepisami porządkowymi w pojazdach Warszawskiego Transportu Publicznego za pozostawienie bagażu bez opieki grozi kara pieniężna w wysokości 500 złotych. Regulamin wejdzie w życie 8 kwietnia.

## Posłowie KO chcą udostępnienia danych RARS w sprawie sprzętu medycznego za 200 milionów złotych
 - [https://tvn24.pl/polska/poslowie-ko-chca-udostepnienia-danych-rars-w-sprawie-sprzetu-medycznego-za-200-milionow-zlotych-6875707?source=rss](https://tvn24.pl/polska/poslowie-ko-chca-udostepnienia-danych-rars-w-sprawie-sprzetu-medycznego-za-200-milionow-zlotych-6875707?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 14:34:55+00:00

<img alt="Posłowie KO chcą udostępnienia danych RARS w sprawie sprzętu medycznego za 200 milionów złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mh2wmd-29-1005-sejm-konfa-0001-6875720/alternates/LANDSCAPE_1280" />
    Posłowie Koalicji Obywatelskiej chcą udostępnienia informacji przez prezesa Rządowej Agencji Rezerw Strategicznych dotyczących zakupu sprzętu medycznego za 200 milionów złotych - poinformowali na konferencji prasowej. - Wygląda na to, że wydatkowanie tych 200 milionów złotych w trybie tajnym jest dla swoich, a nie dla osób z niepełnosprawnościami - mówiła Marzena Okła-Drewnowicz.

## Watykan: papież Franciszek ma infekcję dróg oddechowych, zostanie w szpitalu kilka dni
 - [https://tvn24.pl/swiat/papiez-franciszek-w-szpitalu-watykan-zostanie-w-nim-kilka-dni-ma-infekcje-drog-oddechowych-6875796?source=rss](https://tvn24.pl/swiat/papiez-franciszek-w-szpitalu-watykan-zostanie-w-nim-kilka-dni-ma-infekcje-drog-oddechowych-6875796?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 14:24:15+00:00

<img alt="Watykan: papież Franciszek ma infekcję dróg oddechowych, zostanie w szpitalu kilka dni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9dymki-franciszek-na-placu-swietego-piotra-6875814/alternates/LANDSCAPE_1280" />
    Papież Franciszek ma infekcję dróg oddechowych i spędzi kilka dni w szpitalu - przekazał Watykan w oświadczeniu, zaznaczając, że test na COVID-19 dał wynik negatywny.

## Ojciec i syn złapani na kłusowaniu. Muszą zapłacić po ponad 35 tysięcy złotych
 - [https://tvn24.pl/pomorze/torun-ojciec-i-syn-zlapani-na-goracym-uczynku-musza-zaplacic-ponad-35-tysiecy-zlotych-nawiazki-6875441?source=rss](https://tvn24.pl/pomorze/torun-ojciec-i-syn-zlapani-na-goracym-uczynku-musza-zaplacic-ponad-35-tysiecy-zlotych-nawiazki-6875441?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 14:16:41+00:00

<img alt="Ojciec i syn złapani na kłusowaniu. Muszą zapłacić po ponad 35 tysięcy złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dcd0vx-mezczyzna-nielegalnie-pozyskiwal-ryby-za-pomoca-sieci-6850164/alternates/LANDSCAPE_1280" />
    Sąd Okręgowy w Toruniu (woj. kujawsko-pomorskie) zasądził po ponad 35 tysięcy złotych nawiązki na rzecz Okręgu Polskiego Związku Wędkarskiego w Toruniu od ojca i syna, którzy dokonali nielegalnego połowu ryb.

## Rosyjscy oligarchowie próbują odzyskać majątki zamrożone przez Włochy. Jest pierwsza decyzja sądu
 - [https://tvn24.pl/biznes/ze-swiata/rosyjscy-oligarchowie-probuja-odzyskac-majatki-zamrozone-przez-wlochy-jest-pierwsza-decyzja-sadu-6875688?source=rss](https://tvn24.pl/biznes/ze-swiata/rosyjscy-oligarchowie-probuja-odzyskac-majatki-zamrozone-przez-wlochy-jest-pierwsza-decyzja-sadu-6875688?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 13:45:34+00:00

<img alt="Rosyjscy oligarchowie próbują odzyskać majątki zamrożone przez Włochy. Jest pierwsza decyzja sądu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kk6ndt-jacht-sy-a-andrieja-mielniczenki-6875181/alternates/LANDSCAPE_1280" />
    Luksusowe jachty, pojazdy, ekskluzywne wille. Od początku agresji Rosji na Ukrainę państwo włoskie zarekwirowało majątki 28 rosyjskich oligarchów. Dziesięciu z nich, z pomocą swoich prawników, domaga się odmrożenia tych dóbr. Większość podstępowań jeszcze trwa. Włoski sąd administracyjny wypowiedział się na razie w jednym z przypadków, dotyczącym majątku Aleksieja Mordaszowa - do niedawna uważanego za najbogatszego człowieka w Rosji.

## Pierwszy portret Karola III po objęciu tronu. Król jest w garniturze, z bransoletką na ręku
 - [https://tvn24.pl/swiat/wielka-brytania-pierwszy-portret-karola-iii-po-objeciu-tronu-6875715?source=rss](https://tvn24.pl/swiat/wielka-brytania-pierwszy-portret-karola-iii-po-objeciu-tronu-6875715?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 13:31:50+00:00

<img alt="Pierwszy portret Karola III po objęciu tronu. Król jest w garniturze, z bransoletką na ręku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xllhtv-karol-iii-w-berlinie-6875712/alternates/LANDSCAPE_1280" />
    Jest pierwszy portret króla Karola III namalowany po objęciu przez niego tronu, informuje PAP. Brytyjski monarcha nie ma na nim żadnych symboli władzy, a jedynie bransoletkę na ręku. Jak się okazuje, ma ona specjalne znaczenie.

## "Chciał zrobić prezent przyjaciółce. Ukradł walizkę z luku bagażowego"
 - [https://tvn24.pl/tvnwarszawa/okolice/kozienice-chcial-zrobic-prezent-przyjaciolce-ukradl-walizke-z-luku-bagazowego-6875574?source=rss](https://tvn24.pl/tvnwarszawa/okolice/kozienice-chcial-zrobic-prezent-przyjaciolce-ukradl-walizke-z-luku-bagazowego-6875574?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 13:28:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wbksyt-mezczyzna-ukradl-walizke-z-luku-bagazowego-zdj-ilustracyjne-6875587/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali 37-latka, który ukradł z busa walizkę podróżną na trasie Kozienice - Warszawa. Jak się okazało, chciał zrobić prezent swojej przyjaciółce. Łupem złodzieja padły ubrania kobiety, aparat fotograficzny oraz kosmetyki - przekazała podkomisarz Ilona Tarczyńska, rzeczniczka policji w Kozienicach.

## Premier zapowiada "jeszcze więcej ułatwień" w budowie domów jednorodzinnych
 - [https://tvn24.pl/biznes/nieruchomosci/nieruchomosci-premier-jeszcze-wieksze-ulatwienia-w-budowie-domow-jednorodzinnych-dla-osob-indywidualnych-6875630?source=rss](https://tvn24.pl/biznes/nieruchomosci/nieruchomosci-premier-jeszcze-wieksze-ulatwienia-w-budowie-domow-jednorodzinnych-dla-osob-indywidualnych-6875630?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 13:18:40+00:00

<img alt="Premier zapowiada " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ntklz4-budowa-domu-5416665/alternates/LANDSCAPE_1280" />
    Premier Mateusz Morawiecki poinformował w środę, że rząd przyjął projekt ustawy, która ma na celu wprowadzenie "jeszcze większych ułatwień" w budowie domów jednorodzinnych, w procesie budowlanym. Zaznaczył, że nie będzie to dotyczyło deweloperów tylko osób indywidualnych. Budowa jednorodzinnych budynków mieszkalnych o powierzchni zabudowy powyżej i poniżej 70 m kw., będzie możliwa na podstawie jedynie zgłoszenia.

## "Warszawa jest miastem dwóch powstań. To dowodzi, jak silny jest polski imperatyw w dążeniu do wolności"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/bruksela-seminarium-z-okazji-80-rocznicy-powstania-w-getcie-warszawskim-6875339?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/bruksela-seminarium-z-okazji-80-rocznicy-powstania-w-getcie-warszawskim-6875339?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 13:09:01+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c6ej5s-powstanie-w-warszawskim-getcie-zdjecia-z-raportu-jurgena-stroopa-przygotowanego-dla-heinricha-himmlera-w-1943-roku-84840/alternates/LANDSCAPE_1280" />
    W Parlamencie Europejskim w Brukseli zorganizowano seminarium poświęcone 80. rocznicy powstania w getcie warszawskim. Jego elementem jest otwarcie wystawy upamiętniającej bohaterski zryw. Minister kultury i dziedzictwa narodowego Piotr Gliński mówił, że "Warszawa jest miastem dwóch powstań", a to dowodzi, "jak silny jest polski imperatyw w dążeniu do wolności".

## Rząd szykuje Narodowy Program Amunicyjny. "Zapraszam spółki Skarbu Państwa, podmioty prywatne"
 - [https://tvn24.pl/biznes/z-kraju/narodowy-program-amunicyjny-dzisiaj-rada-ministrow-przyjela-uchwale-6875623?source=rss](https://tvn24.pl/biznes/z-kraju/narodowy-program-amunicyjny-dzisiaj-rada-ministrow-przyjela-uchwale-6875623?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 13:02:00+00:00

<img alt="Rząd szykuje Narodowy Program Amunicyjny. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8todpg-pap_20230312_0cp-6875649/alternates/LANDSCAPE_1280" />
    Rząd przyjął Narodowy Program Amunicyjny, dotyczący zwiększenia produkcji amunicji artyleryjskiej. Zachęcamy spółki Skarbu Państwa, a także podmioty prywatne i sprawdzone podmioty z zagranicy do rozwijania zdolności produkcyjnych w Polsce - powiedział premier Mateusz Morawiecki.

## Pogoda na weekend. Po ciepłym epizodzie znów zrobi się zimowo. Kiedy spadnie śnieg?
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-po-cieplym-epizodzie-znow-zrobi-sie-zimowo-kiedy-spadnie-snieg-6875519?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-po-cieplym-epizodzie-znow-zrobi-sie-zimowo-kiedy-spadnie-snieg-6875519?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:56:28+00:00

<img alt="Pogoda na weekend. Po ciepłym epizodzie znów zrobi się zimowo. Kiedy spadnie śnieg?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7tnlc-wroci-snieg-6875593/alternates/LANDSCAPE_1280" />
    Pogoda w najbliższych dniach zapowiada się dynamicznie. Czwartek i piątek będą dość ciepłe, choć może przelotnie popadać. W weekend znów zacznie robić się chłodniej, a oprócz niższej temperatury spodziewane są też silne porywy wiatru. Na początku tygodnia będą regiony, w których może spaść śnieg.

## Wypadek na torach. Utrudnienia w kursowaniu drugiej linii metra
 - [https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-wypadek-na-torach-utrudnienia-na-drugiej-linii-metra-6875634?source=rss](https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-wypadek-na-torach-utrudnienia-na-drugiej-linii-metra-6875634?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:55:38+00:00

<img alt="Wypadek na torach. Utrudnienia w kursowaniu drugiej linii metra" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c4u0f6-wypadek-na-stacji-centrum-nauki-kopernik-6875631/alternates/LANDSCAPE_1280" />
    W środę na stacji Centrum Nauki Kopernik doszło do wypadku. - Osoba postronna wtargnęła na tory. Metro kursuje w pętlach Bemowo-Rondo ONZ i Dworzec Wileński-Bródno - powiedziała rzeczniczka Metra Warszawskiego Anna Bartoń.

## Ćwiczenia Dynamic Front-23. Polskie Kraby ćwiczą w terenie zurbanizowanym
 - [https://tvn24.pl/polska/nato-cwiczenia-dynamic-front-23-polskie-kraby-cwicza-w-terenie-zurbanizowanym-6875517?source=rss](https://tvn24.pl/polska/nato-cwiczenia-dynamic-front-23-polskie-kraby-cwicza-w-terenie-zurbanizowanym-6875517?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:41:46+00:00

<img alt="Ćwiczenia Dynamic Front-23. Polskie Kraby ćwiczą w terenie zurbanizowanym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d9we7o-cwiczenia-polskich-krabow-na-poligonie-w-danii-6875525/alternates/LANDSCAPE_1280" />
    W Danii odbywają się ćwiczenia NATO Dynamic Front-23, w których udział biorą polskie załogi obsługujące armatohaubice Krab. Działaniom artylerzystów w terenie zabudowanym przyglądał się reporter TVN24 Artur Molęda. - Jestem w stanie zaryzykować stwierdzenie, że jesteśmy pierwszą jednostką artylerii, która wykonuje zadania ogniowe w terenie zurbanizowanym - mówił porucznik Hubert Wyszkowski z 5. Lubuskiego Pułku Artylerii.

## Uciekał przed policją, "nie trafił" w drogę i uderzył w skarpę
 - [https://tvn24.pl/poznan/nowy-tomysl-uciekal-przed-policja-nie-trafil-w-droge-i-uderzyl-w-skarpe-6875253?source=rss](https://tvn24.pl/poznan/nowy-tomysl-uciekal-przed-policja-nie-trafil-w-droge-i-uderzyl-w-skarpe-6875253?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:39:50+00:00

<img alt="Uciekał przed policją, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-o8hgdn-uciekal-przed-policja-nie-trafil-w-droge-i-uderzyl-w-skarpe-6875451/alternates/LANDSCAPE_1280" />
    Nawet pięć lat więzienia grozi kierowcy, który uciekał przed policją w Nowym Tomyślu (Wielkopolska). Pościg zakończył się jego zatrzymaniem po tym, jak próbując skręcić w boczną leśną drogę uderzył w skarpę.

## Ceny biletów komunikacji w dużych miastach na świecie. Jak na tle innych wypada Warszawa?
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ceny-biletow-komunikacji-w-duzych-miastach-jak-na-tle-innych-wypada-stolica-polski-6874907?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ceny-biletow-komunikacji-w-duzych-miastach-jak-na-tle-innych-wypada-stolica-polski-6874907?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:39:21+00:00

<img alt="Ceny biletów komunikacji w dużych miastach na świecie. Jak na tle innych wypada Warszawa? " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-nnrlx2-metro-w-warszawie-6875213/alternates/LANDSCAPE_1280" />
    Dane na temat cen biletów w 45 dużych miastach na świecie zebrał międzynarodowy serwis Picodi.com. Z zestawienia wynika, że Warszawa znalazła się w czołówce metropolii, w których na bilet miesięczny wydaje się najmniej. Taki zakup stanowi zaledwie 1,8 procent przeciętnego wynagrodzenia.

## Rosjanin deportowany z Bali za pokazanie nagich pośladków na świętej górze
 - [https://tvn24.pl/swiat/indonezja-rosjanin-deportowany-z-bali-za-pokazanie-nagich-posladkow-na-swietej-gorze-6875449?source=rss](https://tvn24.pl/swiat/indonezja-rosjanin-deportowany-z-bali-za-pokazanie-nagich-posladkow-na-swietej-gorze-6875449?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:39:07+00:00

<img alt="Rosjanin deportowany z Bali za pokazanie nagich pośladków na świętej górze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vho40r-shutterstock_526956934-6875536/alternates/LANDSCAPE_1280" />
    Zdjęcie Rosjanina pozującego ze spodniami wokół kostek na świętej górze Agung w zeszłym tygodniu stało się wirusowe. Mężczyzna przeprosił, ale przez co najmniej pół roku będzie miał zakaz ponownego wjazdu do Indonezji. Władze na Bali coraz surowiej dyscyplinują zagranicznych turystów, którzy zachowali się nieobyczajnie lub złamali prawo. Często dotyczy to Rosjan.

## Popularna aplikacja na celowniku. Ograniczenia w kolejnym kraju
 - [https://tvn24.pl/biznes/z-kraju/estonia-zakaz-tiktoka-na-telefonach-pracownikow-administracji-6875453?source=rss](https://tvn24.pl/biznes/z-kraju/estonia-zakaz-tiktoka-na-telefonach-pracownikow-administracji-6875453?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:37:45+00:00

<img alt="Popularna aplikacja na celowniku. Ograniczenia w kolejnym kraju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ci5nyt-tallin-shutterstock_327732833-6875568/alternates/LANDSCAPE_1280" />
    Aplikacja TikTok jeszcze w tym miesiącu zostanie zablokowana na wszystkich urządzeniach wydawanych urzędnikom przez państwo - zapowiedział cytowany w środę przez estońskie media Kristjan Jarvan, minister przedsiębiorczości i technologii Estonii.

## Leżał na drodze bez oznak życia. W sprawie zatrzymano 23-latka, który przyjechał na miejsce zdarzenia
 - [https://tvn24.pl/bialystok/stara-rokitnia-69-latek-lezal-na-drodze-bez-oznak-zycia-w-sprawie-zatrzymano-23-latka-6875452?source=rss](https://tvn24.pl/bialystok/stara-rokitnia-69-latek-lezal-na-drodze-bez-oznak-zycia-w-sprawie-zatrzymano-23-latka-6875452?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:12:10+00:00

<img alt="Leżał na drodze bez oznak życia. W sprawie zatrzymano 23-latka, który przyjechał na miejsce zdarzenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-klcpt9-zabezpieczyli-uszkodzone-auto-6875457/alternates/LANDSCAPE_1280" />
    Na drodze w miejscowości Stara Rokitnia (woj. lubelskie) znaleziony został 69-latek, który nie dawał oznak życia. Nie udało się go uratować. Gdy na miejscu zdarzenia była policja, przyjechał tam 23-latek. Zdaniem funkcjonariuszy to najprawdopodobniej on potrącił pieszego i uciekł. Mężczyzna został zatrzymany, a jego pojazd zabezpieczony. Okoliczności zdarzenia są wyjaśniane.

## Uczniowie przed wyborem. Rekrutacja do szkół średnich w Krakowie. Najlepsze licea i technika
 - [https://tvn24.pl/krakow/krakow-rekrutacja-do-szkol-ponadpodstawowych-2023-jakie-sa-najlepsze-licea-i-technika-w-krakowie-ranking-szkol-jak-wybrac-szkole-srednia-ile-szkol-wybrac-jak-liczyc-punkty-po-egzaminie-osmoklasisty-6863044?source=rss](https://tvn24.pl/krakow/krakow-rekrutacja-do-szkol-ponadpodstawowych-2023-jakie-sa-najlepsze-licea-i-technika-w-krakowie-ranking-szkol-jak-wybrac-szkole-srednia-ile-szkol-wybrac-jak-liczyc-punkty-po-egzaminie-osmoklasisty-6863044?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:05:00+00:00

<img alt="Uczniowie przed wyborem. Rekrutacja do szkół średnich w Krakowie. Najlepsze licea i technika" src="https://tvn24.pl/najnowsze/cdn-zdjecie-crihon-klasa-w-liceum-zdjecie-pogladowe-6683642/alternates/LANDSCAPE_1280" />
    Zapowiada się kolejna trudna rekrutacja do szkół ponadpodstawowych. Do liceów, techników i szkół branżowych we wrześniu 2023 znów przyjdzie 1,5 rocznika. "Będzie to z pewnością konkurencyjna rekrutacja, bo sukces kandydata zależy nie tylko od jego wyników, ale także od wyników innych absolwentów szkół podstawowych" - mówi Dariusz Domajewski, wicedyrektor Wydziału Edukacji Urzędu Miasta Krakowa.

## "Najdłuższa podróż autobusem na świecie". Polska na trasie
 - [https://tvn24.pl/biznes/ze-swiata/najdluzsza-podroz-autobusem-na-swiecie-polska-na-trasie-6875278?source=rss](https://tvn24.pl/biznes/ze-swiata/najdluzsza-podroz-autobusem-na-swiecie-polska-na-trasie-6875278?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 12:01:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pby0at-droga-norwegia-nordkapp-przyladek-polnocny-6875501/alternates/LANDSCAPE_1280" />
    Ze Stambułu do Londynu w dwa miesiące - to oferta określana jako "najdłuższa podróż autobusem na świecie". Jak podaje CNN, podróż trwa dokładnie 56 dni, prowadzi przez 22 kraje i dostępna jest dla 30 pasażerów. Koszt to w przeliczeniu nieco ponad 100 tysięcy złotych.

## Był poszukiwany, ukrył się w szafie. Jego kryjówkę zdradził kot
 - [https://tvn24.pl/bialystok/lublin-20-latek-byl-poszukiwany-ukryl-sie-przed-policja-w-szafie-jego-kryjowke-zdradzil-kot-6875299?source=rss](https://tvn24.pl/bialystok/lublin-20-latek-byl-poszukiwany-ukryl-sie-przed-policja-w-szafie-jego-kryjowke-zdradzil-kot-6875299?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 11:57:12+00:00

<img alt="Był poszukiwany, ukrył się w szafie. Jego kryjówkę zdradził kot" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9316i1-kryjowke-zdradzil-kot-zdjecie-ilustracyjne-6875236/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali 20-latka, który był poszukiwany do odbycia kary więzienia. Gdy zapukali do jednego z mieszkań w Lublinie, w którym miał przebywać, jego matka twierdziła, że już od dawna nie widziała syna. Okazało się, że mężczyzna schował się w szafie, a jego kryjówkę zdradził kot, który  "siedział na podłodze jak zahipnotyzowany i patrzył na drzwi szafy".

## Wiózł siedmioro dzieci w samochodzie. Grozi mu 50 punktów karnych i pięć lat więzienia
 - [https://tvn24.pl/pomorze/lebork-wiozl-siedmioro-dzieci-w-piecioosobowym-aucie-bez-zapietych-pasow-jechali-do-babci-6875256?source=rss](https://tvn24.pl/pomorze/lebork-wiozl-siedmioro-dzieci-w-piecioosobowym-aucie-bez-zapietych-pasow-jechali-do-babci-6875256?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 11:47:20+00:00

<img alt="Wiózł siedmioro dzieci w samochodzie. Grozi mu 50 punktów karnych i pięć lat więzienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ml3omc-policja-drogowka-lizak-shutterstock2147933467-6156273/alternates/LANDSCAPE_1280" />
    Mieszkaniec Lęborka (Pomorze) chciał szybko przewieźć dzieci do babci. Zabrał więc siedmioro podopiecznych na raz. Autem pięcioosobowym. Gdy zatrzymał go policjant, okazało się, że nikt nie miał zapiętych pasów, a kierowca ma orzeczony zakaz prowadzenia pojazdów. Teraz mężczyznę czekają poważne konsekwencje.

## Jeden zasnął w kradzionym samochodzie, drugi przyjechał uszkodzonym autem na komendę. Obaj byli pijani
 - [https://tvn24.pl/krakow/bochnia-brzesko-jeden-pijany-zaparkowal-przed-komenda-inny-spal-w-kradzionym-samochodzie-6875404?source=rss](https://tvn24.pl/krakow/bochnia-brzesko-jeden-pijany-zaparkowal-przed-komenda-inny-spal-w-kradzionym-samochodzie-6875404?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 11:45:13+00:00

<img alt="Jeden zasnął w kradzionym samochodzie, drugi przyjechał uszkodzonym autem na komendę. Obaj byli pijani" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d4xp5k-pijany-kierowca-zaparkowal-samochod-przed-komenda-w-bochni-woj-malopolskie-6875300/alternates/LANDSCAPE_1280" />
    Jeden z nich zasnął na stacji benzynowej w kradzionym samochodzie, drugi przyjechał na komisariat, by zgłosić uszkodzenie pojazdu, którym przyjechał. Jak się okazało, obaj byli pijani. Jeden z mężczyzn odpowie za kradzież, z kolei drugi - za prowadzenie pojazdu pod wpływem alkoholu.

## Rozmowy na linii Węgry - Rosja. Jednym z tematów dostawy gazu
 - [https://tvn24.pl/biznes/ze-swiata/rosja-wegry-minister-spraw-zagranicznych-wegier-peter-szijjarto-rozmawial-z-wicepremierem-rosji-6874833?source=rss](https://tvn24.pl/biznes/ze-swiata/rosja-wegry-minister-spraw-zagranicznych-wegier-peter-szijjarto-rozmawial-z-wicepremierem-rosji-6874833?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 11:44:53+00:00

<img alt="Rozmowy na linii Węgry - Rosja. Jednym z tematów dostawy gazu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ofoe3i-budynek-parlamentu-w-budapeszcie-6103314/alternates/LANDSCAPE_1280" />
    Rosyjski gaz ma płynąć do Węgier bez zakłóceń po zakończeniu prac konserwacyjnych przy gazociągu Turkstream. Takie zapewnienia usłyszał minister spraw zagranicznych Węgier Peter Szijjarto w rozmowie telefonicznej z wicepremierem Rosji Aleksandrem Nowakiem. Szef węgierskiej dyplomacji podkreślił, że Budapeszt będzie blokować wszelkie unijne sankcje, które dotknęłyby energetyki jądrowej.

## Kaczyński "optymistą" wobec sytuacji w TK. "Próbują przekupić sędziów za funkcję prezesa Trybunału"
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-o-julii-przylebskiej-sporze-w-trybunale-konstytucyjnym-wokol-jej-kadencji-i-o-srodkach-z-kpo-politycy-komentuja-6875071?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-o-julii-przylebskiej-sporze-w-trybunale-konstytucyjnym-wokol-jej-kadencji-i-o-srodkach-z-kpo-politycy-komentuja-6875071?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 11:33:11+00:00

<img alt="Kaczyński " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5gaop8-julia-przylebska-6623337/alternates/LANDSCAPE_1280" />
    Jarosław Kaczyński stwierdził, że "nie jest do tego daleko", by zebrała się w Trybunale Konstytucyjnym wystarczająca liczba sędziów, aby zająć się ustawą o sądach. - Jego odkrycie towarzyskie, Julia Przyłębska, pewnie go poinformowała i zameldowała: panie prezesie, wszystko jest w porządku - komentował poseł Robert Kropiwnicki (PO). Poseł Kazimierz Smoliński (PiS) przekonywał, że "jest pewne", że Trybunał się zbierze. - Natomiast kiedy, to nie wiem - dodał.

## Przy tym porodzie asystowało ponad 20 medyków. W Łodzi urodziły się czworaczki
 - [https://tvn24.pl/lodz/lodz-czworaczki-przyszly-na-swiat-w-instytucie-centrum-zdrowia-matki-polki-przy-ich-porodzie-asystowalo-ponad-20-medykow-6875062?source=rss](https://tvn24.pl/lodz/lodz-czworaczki-przyszly-na-swiat-w-instytucie-centrum-zdrowia-matki-polki-przy-ich-porodzie-asystowalo-ponad-20-medykow-6875062?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 11:13:43+00:00

<img alt="Przy tym porodzie asystowało ponad 20 medyków. W Łodzi urodziły się czworaczki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x50roo-czworaczki-z-lodzi-dwoje-dzieci-opuscilo-dzisiaj-szpital-6875212/alternates/LANDSCAPE_1280" />
    Michalina, Dominika, Aleksander i Tymoteusz to czworaczki, które przyszły na świat w 30 tygodniu ciąży. Poród odbył się w Instytucie Centrum Zdrowia Matki Polki w Łodzi. Najmniejszy z czworga dzieci - Tymoteusz - ważył zaledwie 770 gramów. Aktualnie przebywają na oddziale neonatologii łódzkiej placówki. W środę pierwsza dwójka będzie mogła jechać do domu.

## Zakaz aut spalinowych. "One nie znikną nagle z naszego rynku"
 - [https://tvn24.pl/biznes/z-kraju/zakaz-aut-spalinowych-one-nie-znikna-nagle-z-naszego-rynku-6874963?source=rss](https://tvn24.pl/biznes/z-kraju/zakaz-aut-spalinowych-one-nie-znikna-nagle-z-naszego-rynku-6874963?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 11:11:11+00:00

<img alt="Zakaz aut spalinowych. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pzpny2-warszawa-samochody-auta-ulica-5108660/alternates/LANDSCAPE_1280" />
    Polska jest krajem z jednym z najwyższych współczynników liczby samochodów na liczbę mieszkańców. Powinniśmy dążyć do tego, żeby nie tylko zmienić silniki w samochodach, ale żeby uwolnić przestrzeń, zwłaszcza miejską od aut, których jest po prostu za dużo - oceniła w TVN24 Weronika Michalak, dyrektor polskiego oddziału Health and Environment Alliance. Jakub Faryś, prezes Polskiego Związku Przemysłu Motoryzacyjnego, zwrócił uwagę, że auta spalinowe nie znikną z naszego rynku w 2035 roku, ponieważ unijne ograniczenia dotyczą wyłącznie nowych samochodów.

## Budowa tramwaju do Wilanowa. Zmiany na Belwederskiej, Spacerowej i Gagarina
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zmiany-w-organizacji-ruchu-w-zwiazku-z-budowa-tramwaju-do-wilanowa-mapa-6875022?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zmiany-w-organizacji-ruchu-w-zwiazku-z-budowa-tramwaju-do-wilanowa-mapa-6875022?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 11:06:29+00:00

<img alt="Budowa tramwaju do Wilanowa. Zmiany na Belwederskiej, Spacerowej i Gagarina" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-e6z5cr-budowa-tramwaju-do-wilanowa-na-odcinku-mokotowskim-6875100/alternates/LANDSCAPE_1280" />
    Nowa organizacja ruchu zacznie obowiązywać od niedzieli, 2 kwietnia i potrwa do pierwszych tygodni maja. W związku z budową tramwaju do Wilanowa zmiany będą dotyczyły fragmentów ulic: Belwederskiej, Spacerowej i Gagarina. Zwężenia jezdni pojawią się już jednak w czwartek i piątek.

## Norweg podejrzany o zabójstwo Polki i porwanie dziecka trafi na obserwację
 - [https://tvn24.pl/krakow/oswiecim-norweg-podejrzany-o-zabojstwo-partnerki-trafi-na-obserwacje-psychiatryczna-6875125?source=rss](https://tvn24.pl/krakow/oswiecim-norweg-podejrzany-o-zabojstwo-partnerki-trafi-na-obserwacje-psychiatryczna-6875125?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 10:37:41+00:00

<img alt="Norweg podejrzany o zabójstwo Polki i porwanie dziecka trafi na obserwację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mniild-mezczyzna-zostal-aresztowany-zdj-ilustracyjne-5781098/alternates/LANDSCAPE_1280" />
    Ingebrigt G., obywatel Norwegii podejrzany o zamordowanie swojej 26-letniej partnerki, trafi na obserwację psychiatryczną – zdecydował krakowski sąd. Mężczyzna został zatrzymany w związku z zabójstwem kobiety i porwaniem ich wspólnego dziecka.

## Ten rozbłysk gamma mógł być najjaśniejszy "od początku cywilizacji". Oślepił czujniki
 - [https://tvn24.pl/tvnmeteo/nauka/rekordowo-jasny-rozblysk-gamma-najjasniejszy-od-poczatku-ludzkiej-cywilizacji-6874926?source=rss](https://tvn24.pl/tvnmeteo/nauka/rekordowo-jasny-rozblysk-gamma-najjasniejszy-od-poczatku-ludzkiej-cywilizacji-6874926?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 10:21:39+00:00

<img alt="Ten rozbłysk gamma mógł być najjaśniejszy " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jkw6c1-rozblysk-gamma-grb-221009a-podswietlil-chmury-kosmicznego-pylu-6874887/alternates/LANDSCAPE_1280" />
    Rozbłysk gamma, jaki zarejestrowano w październiku ubiegłego roku, mógł być najjaśniejszy w historii obserwacji. GRB 221009A "oślepił" nawet niektóre instrumenty pomiarowe, co utrudniło jego badania. Badacze twierdzą, że tak jasne zdarzenia mogą występować średnio raz na 10000 lat.

## Kompletnie pijany 32-latek za kierownicą. Właśnie jechał się oświadczyć
 - [https://tvn24.pl/wroclaw/olawa-kompletnie-pijany-32-latek-jechal-samochodem-oswiadczyc-sie-partnerce-6874994?source=rss](https://tvn24.pl/wroclaw/olawa-kompletnie-pijany-32-latek-jechal-samochodem-oswiadczyc-sie-partnerce-6874994?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 10:18:49+00:00

<img alt="Kompletnie pijany 32-latek za kierownicą. Właśnie jechał się oświadczyć" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j0jdvb-nietrzezwy-kierowca-jechal-sie-oswiadczyc-6874974/alternates/LANDSCAPE_1280" />
    Drogówka z Oławy na Dolnym Śląsku zatrzymała do kontroli 32-latka, który miał blisko 2,5 promila alkoholu w organizmie. Mężczyzna miał w kieszeni pierścionek, a w samochodzie kupione chwilę wcześniej kwiaty. Policjantom tłumaczył, że właśnie jedzie się oświadczyć.

## Kopali i uderzali po głowie leżącego na ziemi, ktoś dostarczył policji nagranie. Nastolatkowie aresztowani
 - [https://tvn24.pl/najnowsze/lubartow-17-i-19-latek-trafili-do-aresztu-mieli-kopac-i-uderzac-po-glowie-lezacego-na-ziemi-chlopaka-wszystko-nagrali-6874942?source=rss](https://tvn24.pl/najnowsze/lubartow-17-i-19-latek-trafili-do-aresztu-mieli-kopac-i-uderzac-po-glowie-lezacego-na-ziemi-chlopaka-wszystko-nagrali-6874942?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 10:17:54+00:00

<img alt="Kopali i uderzali po głowie leżącego na ziemi, ktoś dostarczył policji nagranie. Nastolatkowie aresztowani" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gfb8uv-policja-zatrzymala-nastolatkow-6874947/alternates/LANDSCAPE_1280" />
    Dwaj nastolatkowie zostali namierzeni dzięki nagraniu, które policji dostarczyła postronna osoba. Funkcjonariusze informują, że widać na nim jak w nocy w Lubartowie (woj. lubelskie) sprawcy kopali i uderzali po głowie leżącego na ziemi 19-latka. Obaj trafili do aresztu. Grozi im do trzech lat więzienia.

## Miał pobić, a potem udusić swoją matkę. Jej ciało znaleziono kilka dni później, sąd utrzymał wyrok
 - [https://tvn24.pl/bialystok/gizycko-syn-skazany-za-zabojstwo-matki-prokuratura-cialo-zawinal-w-folie-malarska-i-przelozyl-do-wanny-6874738?source=rss](https://tvn24.pl/bialystok/gizycko-syn-skazany-za-zabojstwo-matki-prokuratura-cialo-zawinal-w-folie-malarska-i-przelozyl-do-wanny-6874738?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 09:44:25+00:00

<img alt="Miał pobić, a potem udusić swoją matkę. Jej ciało znaleziono kilka dni później, sąd utrzymał wyrok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dbgx1m-sad-utrzymal-kare-15-lat-pozbawienia-wolnosci-zdjecie-ilustracyjne-6874814/alternates/LANDSCAPE_1280" />
    Sąd Apelacyjny w Białymstoku utrzymał wyrok 15 lat pozbawienia wolności dla mieszkańca Giżycka (woj. warmińsko-mazurskie), który miał pobić, a potem udusić swoją matkę. Ciało kobiety zostało znalezione dopiero po czterech dniach. Jak ustalili śledczy, mężczyzna owinął je w folię i przełożył do wanny. Rozstrzygnięcie jest prawomocne.

## Próbował zdetonować samochód przed komisariatem. Wyrok w sprawie usiłowania zabójstwa policjantów
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-probowal-zdetonowac-samochod-przed-komisariatem-sad-wydal-prawomocny-wyrok-6875000?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-probowal-zdetonowac-samochod-przed-komisariatem-sad-wydal-prawomocny-wyrok-6875000?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 09:43:36+00:00

<img alt="Próbował zdetonować samochód przed komisariatem. Wyrok w sprawie usiłowania zabójstwa policjantów" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-x6ecvs-sedziowie-przemyslaw-radzik-i-izabela-szumniak-na-sali-sadu-apelacyjnego-w-warszawie-papradek-pietruszka-6875075/alternates/LANDSCAPE_1280" />
    Przed komisariatem odkręcił gaz w aucie i próbował doprowadzić do eksplozji. Został oskarżony o próbę zabójstwa trzech policjantów. W tej sprawie zapadł właśnie prawomocny wyrok.

## Poszukiwany czerwoną notą za śmiertelny wypadek trafił do aresztu
 - [https://tvn24.pl/tvnwarszawa/mokotow/warszawa-policjanci-zatrzymali-mezczyzne-poszukiwanego-przez-interpol-6874931?source=rss](https://tvn24.pl/tvnwarszawa/mokotow/warszawa-policjanci-zatrzymali-mezczyzne-poszukiwanego-przez-interpol-6874931?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 09:29:27+00:00

<img alt="Poszukiwany czerwoną notą za śmiertelny wypadek trafił do aresztu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-sapg6o-17-latek-uslyszal-zarzuty-usilowania-zabojstwa-3795091/alternates/LANDSCAPE_1280" />
    Policjanci z Mokotowa zatrzymali 36-letniego obywatela Ukrainy. Mężczyzna był poszukiwany czerwoną notą Interpolu za spowodowanie śmiertelnego wypadku. Został tymczasowo aresztowany.

## Po skoku nie potrafiła wstać. Strażacy wyciągali kobietę z basenu piankowego
 - [https://tvn24.pl/krakow/krakow-interwencja-strazakow-w-basenie-pelnym-pianek-kobieta-doznala-urazu-plecow-6874964?source=rss](https://tvn24.pl/krakow/krakow-interwencja-strazakow-w-basenie-pelnym-pianek-kobieta-doznala-urazu-plecow-6874964?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 09:24:05+00:00

<img alt="Po skoku nie potrafiła wstać. Strażacy wyciągali kobietę z basenu piankowego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rflh8-interwencja-strazakow-w-basenie-piankowym-6874807/alternates/LANDSCAPE_1280" />
    Nietypowa interwencja straży pożarnej w centrum Krakowa. Strażacy wyciągali poszkodowaną kobietę z basenu pełnego pianek. Po wypadku w sali zabaw turystka trafiła do szpitala. - Kobieta wskoczyła do basenu na plecy i doznała, w ocenie ratowników, potencjalnie poważnych urazów pleców - powiedziała nam rzeczniczka Krakowskiego Pogotowia Ratunkowego Joanna Sieradzka.

## Francuski sąd odrzuca wniosek o ekstradycję do Włoch byłych skrajnie lewicowych bojówkarzy
 - [https://tvn24.pl/swiat/francja-ostatecznie-odrzucono-wniosek-o-ekstradycje-do-wloch-bylych-skrajnie-lewicowych-bojowkarzy-6873913?source=rss](https://tvn24.pl/swiat/francja-ostatecznie-odrzucono-wniosek-o-ekstradycje-do-wloch-bylych-skrajnie-lewicowych-bojowkarzy-6873913?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 09:23:57+00:00

<img alt="Francuski sąd odrzuca wniosek o ekstradycję do Włoch byłych skrajnie lewicowych bojówkarzy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-urm3pv-sad-we-francji-6873902/alternates/LANDSCAPE_1280" />
    Francuski Sąd Najwyższy ostatecznie odrzucił wniosek włoskiego rządu o ekstradycję grupy 10 byłych lewicowych bojowników za czyny, które miały miejsce ponad 30 lat temu.

## Pełnomocnik Magdaleny Filiks: złożymy do prokuratury zawiadomienie w sprawie upublicznienia niejawnych danych
 - [https://tvn24.pl/polska/syn-poslanki-magdaleny-filiks-nie-zyje-pelnomocnik-skladamy-do-prokuratury-zawiadomienie-w-sprawie-ujawnienia-niejawnych-danych-6874840?source=rss](https://tvn24.pl/polska/syn-poslanki-magdaleny-filiks-nie-zyje-pelnomocnik-skladamy-do-prokuratury-zawiadomienie-w-sprawie-ujawnienia-niejawnych-danych-6874840?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 09:22:25+00:00

<img alt="Pełnomocnik Magdaleny Filiks: złożymy do prokuratury zawiadomienie w sprawie upublicznienia niejawnych danych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4j3uuj-mikolaj-marecki-pelnomocnik-magdaleny-filiks-6874898/alternates/LANDSCAPE_1280" />
    Złożymy zawiadomienie do prokuratury w przedmiocie ujawnienia danych, które były niejawne, z procesu, w którym pokrzywdzone były dzieci Magdaleny Filiks - poinformował jej pełnomocnik, adwokat Mikołaj Marecki.

## Prezydent Tajwanu leci do USA. Chiny grożą "stanowczą odpowiedzią"
 - [https://tvn24.pl/swiat/tajwan-prezydent-leci-do-usa-chiny-groza-stanowcza-odpowiedzia-6874820?source=rss](https://tvn24.pl/swiat/tajwan-prezydent-leci-do-usa-chiny-groza-stanowcza-odpowiedzia-6874820?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 08:46:55+00:00

<img alt="Prezydent Tajwanu leci do USA. Chiny grożą " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k47bsx-prezydent-tajwanu-caj-ing-wen-6874850/alternates/LANDSCAPE_1280" />
    Prezydent Tajwanu Caj Ing-wen udaje się w środę do Ameryki Środkowej. W czasie podróży przewidziano międzylądowania w USA. - Zewnętrzna presja nie osłabi naszej determinacji wychodzenia do świata - oświadczyła przed wylotem, komentując groźby chińskich władz, które ostrzegły przed odwetem, jeśli spotka się tam ona ze spikerem Izby Reprezentantów Kevinem McCarthym.

## Jak liczyć punkty do liceum i technikum? Przeliczanie wyniku za egzamin ósmoklasisty. Kalkulator punktów
 - [https://tvn24.pl/pomorze/jak-liczyc-punkty-do-szkoly-sredniej-jak-obliczyc-procenty-za-egzamin-osmoklasisty-kalkulator-punktow-do-liceum-i-technikum-6870496?source=rss](https://tvn24.pl/pomorze/jak-liczyc-punkty-do-szkoly-sredniej-jak-obliczyc-procenty-za-egzamin-osmoklasisty-kalkulator-punktow-do-liceum-i-technikum-6870496?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 08:37:00+00:00

<img alt="Jak liczyć punkty do liceum i technikum? Przeliczanie wyniku za egzamin ósmoklasisty. Kalkulator punktów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g6f2q8-kalkulator-kredyt-pieniadze-rachunki-oplaty-6478492/alternates/LANDSCAPE_1280" />
    Liczenie punktów w czasie rekrutacji do szkół ponadpodstawowych na zakończenie ósmej klasy nie jest łatwym zadaniem zarówno dla uczniów jak i dla ich rodziców. Suma punktów za wynik egzaminu i świadectwo wydaje się łatwa do obliczenia. Sprawę komplikuje jednak przeliczenie za pomocą specjalnego wzoru wyniku egzaminu ósmoklasisty. Należy dodać do tego punkty za świadectwo oraz za osiągnięcia i zaangażowanie ucznia.

## Przed nami noc z niebezpieczną pogodą. Synoptycy IMGW wydali alarmy
 - [https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-roztopy-zimna-noc-w-czesci-kraju-6874828?source=rss](https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-roztopy-zimna-noc-w-czesci-kraju-6874828?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 08:24:42+00:00

<img alt="Przed nami noc z niebezpieczną pogodą. Synoptycy IMGW wydali alarmy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-17j01d-uwaga-na-przymrozki-4585248/alternates/LANDSCAPE_1280" />
    Synoptycy IMGW ostrzegają przed groźnymi warunkami pogodowymi. Obowiązują alarmy przed przymrozkami oraz roztopami. Sprawdź, gdzie aura będzie niebezpieczna dla życia i zdrowia.

## Siedem województw z zimnem "zagrażającym zdrowiu i życiu"
 - [https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-zimna-noc-w-czesci-kraju-6874828?source=rss](https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-zimna-noc-w-czesci-kraju-6874828?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 08:24:42+00:00

<img alt="Siedem województw z zimnem " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-lhngfl-przymrozki-w-czesci-kraju-5697931/alternates/LANDSCAPE_1280" />
    IMGW ostrzega przed przymrozkami. W siedmiu województwach obowiązują alerty, które będą towarzyszyły nam do czwartkowego poranka. Sprawdź, gdzie aura okaże się niebezpieczna.

## Miliony pracowników przed ważnym wyborem. "Dopóki nie sprawdzimy, to wiele osób nie ufa"
 - [https://tvn24.pl/biznes/pieniadze/ppk-emerytury-miliony-pracownikow-przed-waznym-wyborem-oskar-sobolewski-komentuje-6874742?source=rss](https://tvn24.pl/biznes/pieniadze/ppk-emerytury-miliony-pracownikow-przed-waznym-wyborem-oskar-sobolewski-komentuje-6874742?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 08:23:00+00:00

<img alt="Miliony pracowników przed ważnym wyborem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ra7iel-warszawa-ulica-tlum-ludzie-nataly-reinch-shutterstock523956709-6708831/alternates/LANDSCAPE_1280" />
    Deklaracje pracowników o rezygnacji z dokonywania wpłat do Pracowniczych Planów Kapitałowych (PPK) wygasły. Osoby, które podtrzymują tę decyzję, powinni złożyć rezygnację ponownie. Trzeba się jednak spieszyć. Od 1 kwietnia pracodawcy wznowią dokonywanie wpłat do PPK za osoby, których deklaracje wygasły z końcem lutego. - Często wiele osób mi powtarza i pokazuje, że oni nie ufali, ale spróbowali. Zrobili jeden, drugi, trzeci zwrot. Zobaczyli, że te środki są faktycznie prywatne, że to nie jest tylko suchy przepis w ustawie i zdecydowali się zostać - mówił we "Wstajesz i wiesz" w TVN24 Oskar Sobolewski, ekspert emerytalny i rynku pracy w HRK Payroll Consulting.

## Zełenski: nie możemy przegrać bitwy o Bachmut, żeby Putin nie poczuł krwi
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-walki-o-bachmut-wolodymyr-zelenski-o-sytuacji-i-zaproszeniu-dla-xi-jinpinga-do-kijowa-6874782?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-walki-o-bachmut-wolodymyr-zelenski-o-sytuacji-i-zaproszeniu-dla-xi-jinpinga-do-kijowa-6874782?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 08:19:13+00:00

<img alt="Zełenski: nie możemy przegrać bitwy o Bachmut, żeby Putin nie poczuł krwi " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hqpuji-ukrainscy-zolnierze-na-linii-frontu-pod-bachmutem-6865661/alternates/LANDSCAPE_1280" />
    Prezydent Ukrainy Wołodymyr Zełenski powiedział agencji Associated Press, że Ukraina nie może przegrać trwającej od siedmiu miesięcy bitwy o Bachmut, żeby Władimir Putin nie poczuł krwi. W wywiadzie mówił też o zaproszeniu dla przywódcy Chin Xi Jinpinga do Kijowa. - Jesteśmy gotowi, by go tu zobaczyć - oświadczył.

## Sprawa "Hossa" wróciła na wokandę. Chodzi o kradzieże metodą "na wnuczka"
 - [https://tvn24.pl/poznan/poznan-arkadiusz-l-pseudonim-hoss-znow-przed-sadem-odwolal-sie-od-wyroku-za-oszustwa-metoda-na-wnuczka-6871513?source=rss](https://tvn24.pl/poznan/poznan-arkadiusz-l-pseudonim-hoss-znow-przed-sadem-odwolal-sie-od-wyroku-za-oszustwa-metoda-na-wnuczka-6871513?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 08:09:36+00:00

<img alt="Sprawa " src="https://tvn24.pl/najnowsze/cdn-zdjecie-f6gp2s-arkadiusz-l-hoss-zatrzymany-w-warszawie-4551832/alternates/LANDSCAPE_1280" />
    W Sądzie Okręgowym w Poznaniu ruszyła apelacja w sprawie Arkadiusza Ł., pseudonim Hoss, skazanego na sześć i pół roku więzienia za oszustwa metodą "na wnuczka". Zdaniem śledczych mężczyzna od 2013 roku oszukiwał starsze, często zamożne osoby z różnych krajów Europy i wyłudzał od nich pieniądze oraz biżuterię. Od wyroku pierwszej instancji odwołała się prokuratura i obrońcy oskarżonego.

## Odkryto dwa nowe gatunki mięsożernych roślin. Tam, gdzie się ich nie spodziewano
 - [https://tvn24.pl/tvnmeteo/nauka/miesozerne-rosliny-odkryte-w-andach-sa-wrazliwe-na-zmiany-klimatu-6874682?source=rss](https://tvn24.pl/tvnmeteo/nauka/miesozerne-rosliny-odkryte-w-andach-sa-wrazliwe-na-zmiany-klimatu-6874682?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 07:44:37+00:00

<img alt="Odkryto dwa nowe gatunki mięsożernych roślin. Tam, gdzie się ich nie spodziewano" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vbhwos-pinguicula-ombrophila-6874693/alternates/LANDSCAPE_1280" />
    Mięsożerne rośliny należące do dwóch nowych gatunków zostały odkryte w Andach. Należą one do rodzaju tłustoszy i chwytają swoje ofiary za pomocą lepkich liści. Jak tłumaczą badacze, poszukiwanie i ochrona takich gatunków to wyścig z czasem, są one bowiem szczególnie narażone na wyginięcie.

## Grecka policja aresztowała osoby planujące atak na restaurację
 - [https://tvn24.pl/swiat/grecja-policja-aresztowala-dwoch-pakistanczykow-planujacych-zamach-na-restauracje-zydowska-w-atenach-6873634?source=rss](https://tvn24.pl/swiat/grecja-policja-aresztowala-dwoch-pakistanczykow-planujacych-zamach-na-restauracje-zydowska-w-atenach-6873634?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 07:40:33+00:00

<img alt="Grecka policja aresztowała osoby planujące atak na restaurację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1sba1u-grecka-policja-aresztowala-dwie-osoby-planujace-atak-na-restauracje-zydowska-w-atenach-6873591/alternates/LANDSCAPE_1280" />
    Grecka policja poinformowała we wtorek, że aresztowała dwóch mężczyzn podejrzewanych o przynależność do grupy planującej atak na restaurację żydowską w Atenach – przekazała agencja Reutera.

## Najstarsza czynszówka na Woli popada w ruinę. Burmistrz prosi wojewodę o środki na ratowanie zabytku
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-postepujaca-degradacja-kamienicy-przy-luckiej-8-burmistrz-prosi-wojewode-o-srodki-na-ratowanie-zabytku-6874713?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-postepujaca-degradacja-kamienicy-przy-luckiej-8-burmistrz-prosi-wojewode-o-srodki-na-ratowanie-zabytku-6874713?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 07:34:47+00:00

<img alt="Najstarsza czynszówka na Woli popada w ruinę. Burmistrz prosi wojewodę o środki na ratowanie zabytku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hcfi9c-zabytkowa-kamienica-przy-luckiej-5060993/alternates/LANDSCAPE_1280" />
    Władze Woli apelują do wojewody mazowieckiego o pieniądze na przeprowadzenie prac zabezpieczających XIX-wiecznej kamienicy przy ulicy Łuckiej 8. Wojewoda odpowiedział, że o takie środki może wnioskować konserwator zabytków.

## Albo amunicja, albo filmy o kotkach. Norweskiej fabryce uzbrojenia zabrakło prądu
 - [https://tvn24.pl/swiat/norwegia-zwiekszenie-produkcji-amunicji-hamowane-przez-centrum-tiktoka-6870109?source=rss](https://tvn24.pl/swiat/norwegia-zwiekszenie-produkcji-amunicji-hamowane-przez-centrum-tiktoka-6870109?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 07:16:35+00:00

<img alt="Albo amunicja, albo filmy o kotkach. Norweskiej fabryce uzbrojenia zabrakło prądu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5qg1eg-amunicja-fabryka-nammo-6874736/alternates/LANDSCAPE_1280" />
    Przechowywanie filmów o kotkach zagroziło zwiększaniu naszej produkcji amunicji - ostrzegł dyrektor Nammo, jednego z największych producentów amunicji w Europie. Przyczyną jest brak niezbędnej do rozbudowy fabryki energii elektrycznej, której nadwyżki miało zabrać powstające w pobliżu centrum danych aplikacji TikTok.

## Wychodził z budynku z dzieckiem na rękach. Najechał na nich mężczyzna na hulajnodze, szuka go policja
 - [https://tvn24.pl/bialystok/bialystok-wychodzil-z-budynku-z-dzieckiem-na-rekach-najechal-na-nich-mezczyzna-na-hulajnodze-szuka-go-policja-6874729?source=rss](https://tvn24.pl/bialystok/bialystok-wychodzil-z-budynku-z-dzieckiem-na-rekach-najechal-na-nich-mezczyzna-na-hulajnodze-szuka-go-policja-6874729?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 07:15:11+00:00

<img alt="Wychodził z budynku z dzieckiem na rękach. Najechał na nich mężczyzna na hulajnodze, szuka go policja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hfoxag-policja-szuka-mezczyzny-ktory-jechal-hulajnoga-6874750/alternates/LANDSCAPE_1280" />
    Policjanci z Białegostoku szukają mężczyzny, który najechał hulajnogą na mężczyznę z dzieckiem na rękach. Dziecko trafiło do szpitala. - Każdy, kto ma informację na temat jego tożsamości, proszony jest o kontakt - apelują funkcjonariusze, którzy pokazują wizerunek mężczyzny.

## Parkowanie płatne także w weekendy? Wykonali analizę przychodów
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-strefa-platnego-parkowania-w-weekendy-pomysl-dotyczy-srodmiescia-6857095?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-strefa-platnego-parkowania-w-weekendy-pomysl-dotyczy-srodmiescia-6857095?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 07:13:44+00:00

<img alt="Parkowanie płatne także w weekendy? Wykonali analizę przychodów" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2ld9tw-strefa-platnego-parkowania-6814546/alternates/LANDSCAPE_1280" />
    Około 20 milionów złotych rocznie więcej trafiałoby do miejskiej kasy, gdyby opłaty parkingowe w Śródmieściu obowiązywały także w weekendy. To wyliczenia Zarządu Dróg Miejskich w odpowiedzi na interpelację jednej ze stołecznych radnych. Pomysł jest na razie na etapie założeń. Nie ma żadnych decyzji.

## Sąd Apelacyjny w stanie Maryland przywraca wyrok skazujący za morderstwo
 - [https://tvn24.pl/swiat/usa-sad-apelacyjny-w-stanie-maryland-przywraca-wyrok-skazujacy-za-morderstwo-6873489?source=rss](https://tvn24.pl/swiat/usa-sad-apelacyjny-w-stanie-maryland-przywraca-wyrok-skazujacy-za-morderstwo-6873489?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 07:07:08+00:00

<img alt="Sąd Apelacyjny w stanie Maryland przywraca wyrok skazujący za morderstwo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6v5x12-kajdanki-wiezien-kara-smierci-6853104/alternates/LANDSCAPE_1280" />
    Z przyczyn proceduralnych wyrok skazujący dla Adnana Syeda został przywrócony. Skazany pierwotnie w 2000 roku na dożywocie mężczyzna, po 22 latach spędzonych w więzieniu i wypuszczeniu na wolność, nie wróci jednak za kratki.

## Karetka została podpalona, za pieniądze ze zbiórki kupili trzy kolejne. Wyjechały w konwoju do Charkowa
 - [https://tvn24.pl/krakow/radlow-charkow-karetka-zostala-podpalona-fundacja-kupila-trzy-kolejne-konwoj-humanitarny-do-ukrainy-6874689?source=rss](https://tvn24.pl/krakow/radlow-charkow-karetka-zostala-podpalona-fundacja-kupila-trzy-kolejne-konwoj-humanitarny-do-ukrainy-6874689?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 07:02:16+00:00

<img alt="Karetka została podpalona, za pieniądze ze zbiórki kupili trzy kolejne. Wyjechały w konwoju do Charkowa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2x1a6d-konwoj-karetek-organizowany-przez-fundacje-moc-przyszosci-6874648/alternates/LANDSCAPE_1280" />
    Jedna karetka spłonęła, jej miejsce zajęły trzy kolejne. Fundacja "Moc Przyszłości" kupiła ambulanse dzięki zbiórce uruchomionej po tym, jak jeden z pojazdów został podpalony. Druga karetka została w pożarze uszkodzona, jednak udało się ją naprawić. W konwoju humanitarnym z Radłowa (woj. małopolskie) do ukraińskiego Charkowa pojechały w środę rano cztery samochody.

## Kierowca śmiertelnie potrącił wilka
 - [https://tvn24.pl/tvnwarszawa/okolice/ostrow-mazowiecka-kierowca-smiertelnie-potracil-wilka-6874724?source=rss](https://tvn24.pl/tvnwarszawa/okolice/ostrow-mazowiecka-kierowca-smiertelnie-potracil-wilka-6874724?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 06:56:05+00:00

<img alt="Kierowca śmiertelnie potrącił wilka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kj6eay-wilk-6810247/alternates/LANDSCAPE_1280" />
    Policja dostała zgłoszenie o zderzeniu samochodu ze zwierzęciem. Na miejscu okazało się, że chodzi o wilka. Zwierzę nie przeżyło. Kierowcy auta nic się nie stało.

## Ciepło będzie tylko przez chwilę. Znów "wydarzy się coś zimowego"
 - [https://tvn24.pl/tvnmeteo/polska/pogoda-w-polsce-czy-wroci-wiosna-oaza-zimna-nad-polska-ale-idzie-do-nas-cieplo-6874607?source=rss](https://tvn24.pl/tvnmeteo/polska/pogoda-w-polsce-czy-wroci-wiosna-oaza-zimna-nad-polska-ale-idzie-do-nas-cieplo-6874607?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 06:17:10+00:00

<img alt="Ciepło będzie tylko przez chwilę. Znów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7a6t3z-wasyl-16-6874638/alternates/LANDSCAPE_1280" />
    Ostatnie dni przyniosły ze sobą znaczące ochłodzenie. Jak tłumaczył na antenie TVN24 prezenter tvnmeteo.pl Tomasz Wasilewski, w ciągu kolejnych dni zima odpuści przynajmniej na chwilę. Nie powinniśmy jednak nastawiać się na "spektakularny wybuch wiosny".

## Strzelanina w Stalowej Woli. Starły się dwie grupy, dwie osoby zostały ranne. Zapadły nieprawomocne wyroki
 - [https://tvn24.pl/krakow/stalowa-wola-w-strzelaninie-starly-sie-dwie-grupy-dwie-osoby-zostaly-ranne-zapadly-nieprawomocne-wyroki-6874615?source=rss](https://tvn24.pl/krakow/stalowa-wola-w-strzelaninie-starly-sie-dwie-grupy-dwie-osoby-zostaly-ranne-zapadly-nieprawomocne-wyroki-6874615?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 06:15:28+00:00

<img alt="Strzelanina w Stalowej Woli. Starły się dwie grupy, dwie osoby zostały ranne. Zapadły nieprawomocne wyroki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-glvkwk-strzelanina-w-stalowej-woli-ranne-dwie-osoby-4732819/alternates/LANDSCAPE_1280" />
    Sąd Okręgowy w Tarnobrzegu skazał sześciu mężczyzn, którzy w październiku 2020 roku brali udział w strzelaninie w Stalowej Woli (woj. podkarpackie). Rannych zostało dwóch mężczyzn. Główny oskarżony, 26-letni Filip S. za usiłowanie zabójstwa został skazany na 10 lat więzienia. Wyroki usłyszeli także pozostali oskarżeni. Rozstrzygnięcie nie jest prawomocne.

## Prowadzą śledztwo w sprawie wyłudzeń elektroniki. Podejrzany podczas próby ucieczki uszkodził kilka aut
 - [https://tvn24.pl/tvnwarszawa/ulice/raszyn-warszawa-wjechal-wsamochody-stojace-naswiatlach-w-alei-krakowskiej-byl-podejrzany-o-oszustwo-zaczal-uciekac-6874605?source=rss](https://tvn24.pl/tvnwarszawa/ulice/raszyn-warszawa-wjechal-wsamochody-stojace-naswiatlach-w-alei-krakowskiej-byl-podejrzany-o-oszustwo-zaczal-uciekac-6874605?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 05:49:34+00:00

<img alt="Prowadzą śledztwo w sprawie wyłudzeń elektroniki. Podejrzany podczas próby ucieczki uszkodził kilka aut" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-mnjitl-podejrzany-podczas-proby-ucieczki-uszkodzil-kilka-aut-6874630/alternates/LANDSCAPE_1280" />
    W ubiegłym tygodniu w alei Krakowskiej doszło do uszkodzenia kilku samochodów, stojących na światłach. Okazuje się, że policja ścigała wtedy mężczyznę podejrzanego o oszustwo i kradzież. Zaczął uciekać, gdy chcieli go wylegitymować.

## Śmiertelny wypadek na krajowej "50". Droga jest zablokowana
 - [https://tvn24.pl/tvnwarszawa/okolice/smiertelny-wypadek-na-krajowej-50-droga-jest-zablokowana-6874613?source=rss](https://tvn24.pl/tvnwarszawa/okolice/smiertelny-wypadek-na-krajowej-50-droga-jest-zablokowana-6874613?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 05:24:51+00:00

<img alt="Śmiertelny wypadek na krajowej " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5pgbsr-wypadek-na-s7-pod-mlawa-zdjecie-ilustracyjne-6842316/alternates/LANDSCAPE_1280" />
    Jedna osoba zginęła w wypadku z udziałem dwóch samochodów osobowych i ciężarówki na drodze krajowej numer 50 w miejscowości Rębowo - poinformował dyżurny punktu informacji drogowej Generalnej Dyrekcji Dróg Krajowych i Autostrad. Droga pomiędzy Wyszogrodem a Płońskiem jest zablokowana do odwołania.

## Szczepienia przeciwko COVID-19. WHO wydała nowe rekomendacje
 - [https://tvn24.pl/swiat/nowe-rekomendacje-who-ws-szczepien-przeciwko-covid-19-mlodzi-wykluczeni-z-grupy-wysokiego-priorytetu-6873352?source=rss](https://tvn24.pl/swiat/nowe-rekomendacje-who-ws-szczepien-przeciwko-covid-19-mlodzi-wykluczeni-z-grupy-wysokiego-priorytetu-6873352?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 05:18:57+00:00

<img alt="Szczepienia przeciwko COVID-19. WHO wydała nowe rekomendacje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ykmetk-szczepienia-6233204/alternates/LANDSCAPE_1280" />
    Światowa Organizacja Zdrowia (WHO) dostosowała swoje zalecenia dotyczące szczepień przeciwko COVID-19 do nowej fazy pandemii, sugerując, że zdrowe dzieci i młodzież nie muszą być szczepione, ale starsze grupy wysokiego ryzyka powinny otrzymać dawkę przypominającą w okresie od 6 do 12 miesięcy od ostatniego szczepienia.

## "Pewnie by mnie zepchnął, albo zderzył się czołowo z busem"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/brzostowiec-niebezpieczne-wyprzedzanie-6871552?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/brzostowiec-niebezpieczne-wyprzedzanie-6871552?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 04:58:46+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-xvlofz-niebezpieczne-wyprzedzanie-6871640/alternates/LANDSCAPE_1280" />
    W Brzostowcu (powiat grójecki) kierowca samochodu osobowego próbował wyprzedzić samochody. Niewiele brakowało do czołowego zderzenia z jadącym z naprzeciwka busem.

## Prezydent Izraela przewodniczył pierwszej turze rozmów między rządem i opozycją w sprawie reformy sądownictwa
 - [https://tvn24.pl/swiat/izrael-prezydent-przewodniczyl-pierwszej-turze-rozmow-miedzy-rzadem-i-opozycja-w-sprawie-reformy-sadownictwa-6873243?source=rss](https://tvn24.pl/swiat/izrael-prezydent-przewodniczyl-pierwszej-turze-rozmow-miedzy-rzadem-i-opozycja-w-sprawie-reformy-sadownictwa-6873243?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 04:46:53+00:00

<img alt="Prezydent Izraela przewodniczył pierwszej turze rozmów między rządem i opozycją w sprawie reformy sądownictwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j5dxcy-izrael-protesty-6859957/alternates/LANDSCAPE_1280" />
    Prezydent Izraela przewodniczył pierwszej turze rozmów przedstawicieli partii tworzących rząd i opozycji dotyczących rządowej reformy sądownictwa. Agencja Reutera przekazała, że szef resortu obrony, którego dymisja wywołała wzrost niepokojów w kraju, pozostaje na stanowisku do odwołania.

## "Nie mogą iść dalej tą drogą". Biden reaguje na sytuację w Izraelu
 - [https://tvn24.pl/swiat/usa-prezydent-joe-biden-izraelski-rzad-nie-moze-dalej-isc-ta-droga-6874477?source=rss](https://tvn24.pl/swiat/usa-prezydent-joe-biden-izraelski-rzad-nie-moze-dalej-isc-ta-droga-6874477?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 04:19:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ynjg85-protest-w-izraelu-6874434/alternates/LANDSCAPE_1280" />
    Prezydent USA Joe Biden wyraża nadzieję, że izraelski rząd zrezygnuje z kontrowersyjnych reform sądownictwa, które wywołały masowe protesty. Zaprzeczył doniesieniom, że premier Benjamin Netanjahu odwiedzi Waszyngton w "bliskim terminie".

## Są trzy, jest petycja w sprawie czwartego przejścia dla pieszych na tym ważnym skrzyżowaniu
 - [https://tvn24.pl/tvnwarszawa/praga-polnoc/warszawa-aktywisci-chca-wytyczenia-brakujacej-zebry-przy-placu-wilenskim-6863195?source=rss](https://tvn24.pl/tvnwarszawa/praga-polnoc/warszawa-aktywisci-chca-wytyczenia-brakujacej-zebry-przy-placu-wilenskim-6863195?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 04:14:21+00:00

<img alt="Są trzy, jest petycja w sprawie czwartego przejścia dla pieszych na tym ważnym skrzyżowaniu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1om1tt-skrzyzowanie-alei-solidarnosci-i-targowej-6871891/alternates/LANDSCAPE_1280" />
    Skrzyżowanie alei "Solidarności" i Targowej to jeden z najważniejszych węzłów przesiadkowych prawobrzeżnej Warszawy. Są tam trzy naziemne przejścia dla pieszych, ale do kompletu brakuje czwartego. Powstała petycja, w której aktywiści wskazują na konieczność jego wytyczenia.  Przedstawiciel drogowców wyjaśnia, że temu miejscu potrzebna jest większa reorganizacja, a to wymaga pieniędzy i czasu.

## Pogoda na dziś - środa, 29.03. Początkowo pogodne niebo będzie się zasnuwać chmurami
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-sroda-2903-poczatkowo-pogodne-niebo-bedzie-sie-zasnuwac-chmurami-6872397?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-sroda-2903-poczatkowo-pogodne-niebo-bedzie-sie-zasnuwac-chmurami-6872397?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-29 00:02:00+00:00

<img alt="Pogoda na dziś - środa, 29.03. Początkowo pogodne niebo będzie się zasnuwać chmurami" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vcmeaf-pogodny-dzien-6847295/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Na środę 29.03 synoptycy prognozują stopniowy wzrost zachmurzenia, który postępować będzie od zachodu. Termometry pokażą od 5 do 10 stopni. Biomet przeważnie będzie korzystny.

