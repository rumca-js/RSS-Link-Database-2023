# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## A Manhunt in India Left 27 Million People Without Mobile Internet
 - [https://www.wired.com/story/sandhu-manhunt-india-twitter-internet-blackout/](https://www.wired.com/story/sandhu-manhunt-india-twitter-internet-blackout/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-03-29 23:00:00+00:00

Authorities ordered Twitter accounts blocked and the internet shut down as they hunt for Sikh separatist Amritpal Singh Sandhu.

## How Good Smile, a Major Toy Company, Kept 4chan Online
 - [https://www.wired.com/story/4chan-good-smile/](https://www.wired.com/story/4chan-good-smile/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-03-29 14:26:10+00:00

Documents obtained by WIRED confirm that Good Smile, which licenses toy production for Disney, was an investor in the controversial image board.

## In Sudden Alarm, Tech Doyens Call for a Pause on ChatGPT
 - [https://www.wired.com/story/chatgpt-pause-ai-experiments-open-letter/](https://www.wired.com/story/chatgpt-pause-ai-experiments-open-letter/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-03-29 10:17:49+00:00

Tech luminaries, renowned scientists, and Elon Musk warn of an “out-of-control race” to develop and deploy ever-more-powerful AI systems.

