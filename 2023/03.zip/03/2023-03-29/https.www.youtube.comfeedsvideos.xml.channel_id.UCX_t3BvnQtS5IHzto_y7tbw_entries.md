# Source:Coreteks, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCX_t3BvnQtS5IHzto_y7tbw, language:en-US

## Real-time Path Tracing is FINALLY here!
 - [https://www.youtube.com/watch?v=-c-A3tqfUB8](https://www.youtube.com/watch?v=-c-A3tqfUB8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCX_t3BvnQtS5IHzto_y7tbw
 - date published: 2023-03-29 00:17:55+00:00

Urcdkeys Spring Sale
25% off code: C25
Win10 pro key（$15）：https://biitt.ly/pP7RN
Win10 home key（$14）：https://biitt.ly/nOmyP
Win11 pro key（$21）：https://biitt.ly/f3ojw
office2021 pro key（$60）：https://biitt.ly/DToFr

Affiliate links (I get a commission):
BUY an LG C1 OLED 48'': https://amzn.to/3DGI33I
BUY an LG C1 OLED 55'': https://amzn.to/3TTpQp9

Support me on Patreon: https://www.patreon.com/coreteks

Buy a mug: https://teespring.com/stores/coreteks

My channel on Odysee: https://odysee.com/@coreteks

I now stream at:​​
https://www.twitch.tv/coreteks_youtube

Follow me on Twitter: https://twitter.com/coreteks
And Instagram: https://www.instagram.com/hellocoreteks

Demo Sources:

Vladimir Komarov and his path tracing engine:
https://twitter.com/VrKomarov

Cordell Felix:
https://www.artstation.com/artwork/RynNwD

Pasquale Scionti
https://www.youtube.com/watch?v=JkA3eP4vHwg&amp;t=84s

JUMUN - Will on the Blade
https://twitter.com/jumungame?lang=en

Footage from various sources including official youtube channels from AMD, Intel, NVidia, Samsung, etc, as well as other creators are used for educational purposes, in a transformative manner. If you'd like to be credited please contact me

#graphics #unrealengine5  #ai

