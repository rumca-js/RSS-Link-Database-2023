# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## InjectGPT – przykład tego, co może pójść nie tak w dobie wysypu projektów opartych o AI
 - [https://sekurak.pl/injectgpt-przyklad-tego-co-moze-pojsc-nie-tak-w-dobie-wysypu-projektow-opartych-o-ai/](https://sekurak.pl/injectgpt-przyklad-tego-co-moze-pojsc-nie-tak-w-dobie-wysypu-projektow-opartych-o-ai/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-03-29 16:54:20+00:00

<p>Jak na szybko odpalić swój startup / projekt AI? Przygotować odpowiedni tematyczny frontend, a w tle użyć API Chat GPT. No więc jeden z badaczy wziął na warsztat projekt https://www.boxcars.ai/ Jak czytamy: BoxCars is an open-source Ruby gem that makes it easy for Rails developers to add AI-powered features to...</p>
<p>Artykuł <a href="https://sekurak.pl/injectgpt-przyklad-tego-co-moze-pojsc-nie-tak-w-dobie-wysypu-projektow-opartych-o-ai/" rel="nofollow">InjectGPT &#8211; przykład tego, co może pójść nie tak w dobie wysypu projektów opartych o AI</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Zobacz hackowanie sieci na żywo i zgarnij bezpłatnie rozdział z nowej książki sekuraka!
 - [https://sekurak.pl/zobacz-hackowanie-sieci-na-zywo-i-zgarnij-bezplatnie-rozdzial-z-nowej-ksiazki-sekuraka/](https://sekurak.pl/zobacz-hackowanie-sieci-na-zywo-i-zgarnij-bezplatnie-rozdzial-z-nowej-ksiazki-sekuraka/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-03-29 14:21:31+00:00

<p>Już za parę dni (3.04.2023, 19:30, on-line, dostępne będzie również nagranie) uruchamiamy dość nietypowy live stream. Pokażemy na żywo jak zhackować przykładową sieć / firmę. Całość oparta na faktach wydarzeniach autentycznych. W trakcie wydarzenia zaprezentujemy: Całość prezentowało będzie trzech prelegentów: Krzysztof Bierówka, Marek Rzepecki oraz Michał Sajdak. LIVE stream jest...</p>
<p>Artykuł <a href="https://sekurak.pl/zobacz-hackowanie-sieci-na-zywo-i-zgarnij-bezplatnie-rozdzial-z-nowej-ksiazki-sekuraka/" rel="nofollow">Zobacz hackowanie sieci na żywo i zgarnij bezpłatnie rozdział z nowej książki sekuraka!</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Google demaskuje exploity 0days użyte na Androida oraz iOS. „Obecnie nawet mniejsi dostawcy rozwiązań spyware mają dostęp do 0dayów”
 - [https://sekurak.pl/google-demaskuje-exploity-0days-uzyte-na-androida-oraz-ios-obecnie-nawet-mniejsi-dostawcy-rozwiazan-spyware-maja-dostep-do-0dayow/](https://sekurak.pl/google-demaskuje-exploity-0days-uzyte-na-androida-oraz-ios-obecnie-nawet-mniejsi-dostawcy-rozwiazan-spyware-maja-dostep-do-0dayow/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-03-29 13:35:15+00:00

<p>Zobaczcie na te dwie kampanie opisywane na blogu Google. W jednej z nich (koniec 2022 roku) ofiara otrzymywała SMSa z rzekomym problemem z paczką. Po kliknięciu była przekierowywana na stronę z exploitem, która po zainfekowaniu telefonu kierowała na prawdziwe serwisy firm kurierskich (to ostatnie oczywiście dla niepoznaki): When clicked, the...</p>
<p>Artykuł <a href="https://sekurak.pl/google-demaskuje-exploity-0days-uzyte-na-androida-oraz-ios-obecnie-nawet-mniejsi-dostawcy-rozwiazan-spyware-maja-dostep-do-0dayow/" rel="nofollow">Google demaskuje exploity 0days użyte na Androida oraz iOS. &#8222;Obecnie nawet mniejsi dostawcy rozwiązań spyware mają dostęp do 0dayów&#8221;</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

