# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## "We Need the Aliens!"
 - [https://www.youtube.com/watch?v=VghI_sdi3TM](https://www.youtube.com/watch?v=VghI_sdi3TM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2023-03-29 17:17:24+00:00

Taken from JRE #1962 w/Eddie Huang:
https://open.spotify.com/episode/3piWvugV9PHQyXZCfCsRlk?si=ef0b012272614a0b

## Eddie Huang Reflects on the Wild Days of Vice
 - [https://www.youtube.com/watch?v=6WR2jLdgGqg](https://www.youtube.com/watch?v=6WR2jLdgGqg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2023-03-29 17:17:15+00:00

Taken from JRE #1962 w/Eddie Huang:
https://open.spotify.com/episode/3piWvugV9PHQyXZCfCsRlk?si=f29ba70db12d4750

