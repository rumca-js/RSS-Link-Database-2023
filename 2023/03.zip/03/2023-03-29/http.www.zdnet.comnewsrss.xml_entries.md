# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## Apple sets June date for its biggest conference of 2023, with headset launch expected
 - [https://www.zdnet.com/article/apple-sets-june-date-for-its-biggest-conference-of-2023-with-headset-launch-expected/#ftag=RSSbaffb68](https://www.zdnet.com/article/apple-sets-june-date-for-its-biggest-conference-of-2023-with-headset-launch-expected/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 20:42:41+00:00

In addition to its usual software updates, we're looking for Apple to finally announce a long-awaited product. Here's what to expect.

## How to use window snapping on your Chromebook (and why you should)
 - [https://www.zdnet.com/home-and-office/work-life/how-to-use-window-snapping-on-your-chromebook-and-why-you-should/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/how-to-use-window-snapping-on-your-chromebook-and-why-you-should/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 20:10:56+00:00

Want to view two tabs side-by-side at the same time, but don't know how? Check this out.

## How to block senders in Apple Mail -- quickly and effectively
 - [https://www.zdnet.com/home-and-office/work-life/how-to-block-senders-in-apple-mail/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/how-to-block-senders-in-apple-mail/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 19:49:42+00:00

If you receive a constant barrage of emails from spam or senders you don't want to hear from, there's a simple way to block them in Apple Mail.

## The best smart rings of 2023: Oura and alternatives
 - [https://www.zdnet.com/article/best-smart-ring/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-smart-ring/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 19:39:00+00:00

I tested the Oura Ring 3 to see if it's still the best smart ring for tracking activity, recovery, sleep, and more. Here's how the best smart rings compare.

## Microsoft increases Bing chat limit -- again
 - [https://www.zdnet.com/article/microsoft-increases-bing-chat-limit-again/#ftag=RSSbaffb68](https://www.zdnet.com/article/microsoft-increases-bing-chat-limit-again/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 19:18:00+00:00

'Everything seems to be going well.'

## What is Lemon8 and why is everyone talking about it on TikTok?
 - [https://www.zdnet.com/article/what-is-lemon8-and-why-is-everyone-talking-about-it-on-tiktok/#ftag=RSSbaffb68](https://www.zdnet.com/article/what-is-lemon8-and-why-is-everyone-talking-about-it-on-tiktok/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 18:18:00+00:00

ByteDance is pushing a lifestyle app in the U.S. to compete with Instagram. Here's everything you need to know about it.

## How to create hidden files in Linux (and what not to use them for)
 - [https://www.zdnet.com/article/how-to-create-hidden-files-in-linux-and-what-not-to-use-them-for/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-create-hidden-files-in-linux-and-what-not-to-use-them-for/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 17:57:00+00:00

If you're looking to hide files from plain sight in Linux, it's much easier than you may think.

## How this $40 gadget helps runners, gardeners and back pain sufferers
 - [https://www.zdnet.com/article/how-this-40-gadget-helps-runners-gardeners-and-back-pain-sufferers/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-this-40-gadget-helps-runners-gardeners-and-back-pain-sufferers/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 16:46:00+00:00

If you experience muscle-related issues (such as back pain), the Auvon TENS unit is an inexpensive but effective remedy. Here's how to use it.

## How to automatically lock your Windows PC with Dynamic Lock
 - [https://www.zdnet.com/article/how-to-automatically-lock-your-windows-pc-with-dynamic-lock/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-automatically-lock-your-windows-pc-with-dynamic-lock/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 16:44:00+00:00

Walk away from your PC with your phone, and Dynamic Lock will lock Windows for you.

## Twitter moves free users to the spam folder and makes a risky bet on its future
 - [https://www.zdnet.com/article/twitter-to-put-new-restrictions-on-free-users-and-makes-a-risky-bet-on-its-future/#ftag=RSSbaffb68](https://www.zdnet.com/article/twitter-to-put-new-restrictions-on-free-users-and-makes-a-risky-bet-on-its-future/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 16:19:59+00:00

Less than 0.12% of current Twitter users are paid subscribers. Elon Musk is determined to change that.

## Musk, Wozniak, and other tech leaders sign petition to halt further AI developments
 - [https://www.zdnet.com/article/musk-wozniak-and-other-tech-leaders-sign-petition-to-halt-ai-developments/#ftag=RSSbaffb68](https://www.zdnet.com/article/musk-wozniak-and-other-tech-leaders-sign-petition-to-halt-ai-developments/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 16:15:43+00:00

A petition with over 1,000 signatures calls for a pause in giant AI experiments. Here's why.

## The best assistive technology of 2023
 - [https://www.zdnet.com/article/best-assistive-technology/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-assistive-technology/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 16:15:00+00:00

My picks for the best assistive technology can help employers accommodate disabilities in the workplace and foster a more inclusive environment.

## This $17 headlamp is as close to perfection as lights get
 - [https://www.zdnet.com/home-and-office/smart-office/this-17-headlamp-is-as-close-to-perfection-as-lights-get/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-office/this-17-headlamp-is-as-close-to-perfection-as-lights-get/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 14:46:00+00:00

The Klarus headlamp supports motion sensing and gets bright enough for all my illumination needs.

## How to use ChatGPT to write an essay
 - [https://www.zdnet.com/article/how-to-use-chatgpt-to-write-an-essay/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-use-chatgpt-to-write-an-essay/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 14:29:00+00:00

Using ChatGPT can improve your writing process. Here's how.

## This smart sprinkler system uses AI and inkjet printing tech to reduce water waste
 - [https://www.zdnet.com/home-and-office/smart-home/this-sprinkler-system-uses-ai-and-inkjet-printing-tech-to-reduce-water-waste/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/this-sprinkler-system-uses-ai-and-inkjet-printing-tech-to-reduce-water-waste/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 14:25:00+00:00

The average American family uses more than 300 gallons of water per day, with at least 30% of this amount being used outdoors, according to the EPA.

## Is the Oura Ring 3 worth buying in 2023? Yes, if you value these features
 - [https://www.zdnet.com/article/oura-ring-generation-3-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/oura-ring-generation-3-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 12:45:00+00:00

Review: The smart ring offers a wider range of health-tracking features than ever and remains a distraction-free alternative to smartwatches.

## How to simplify Flatpak app installation on the KDE Plasma desktop
 - [https://www.zdnet.com/article/how-to-simplify-flatpak-app-installation-on-the-kde-plasma-desktop/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-simplify-flatpak-app-installation-on-the-kde-plasma-desktop/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 12:41:54+00:00

Flatpak and Snap make it far easier to install the applications you need on Linux. Here's what you need to know.

## Alexa can now place your Panera delivery order for you
 - [https://www.zdnet.com/home-and-office/smart-home/alexa-can-now-place-your-panera-delivery-order-for-you/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/alexa-can-now-place-your-panera-delivery-order-for-you/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 12:00:21+00:00

There goes the food budget.

## How to send and receive iMessages on Windows
 - [https://www.zdnet.com/article/how-to-send-and-receive-imessages-on-windows/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-send-and-receive-imessages-on-windows/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 11:50:00+00:00

Microsoft is doing what Apple won't by bringing iMessage to the PC. Here's what you need to know.

## AI pioneer Cerebras opens up generative AI where OpenAI goes dark
 - [https://www.zdnet.com/article/ai-pioneer-cerebras-opens-up-generative-ai-where-openai-goes-dark/#ftag=RSSbaffb68](https://www.zdnet.com/article/ai-pioneer-cerebras-opens-up-generative-ai-where-openai-goes-dark/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-29 02:53:01+00:00

The AI computer maker released seven open-source models like OpenAI's GPT as a resource to the research community.

