# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Sen. Hawley’s Efforts to Fast-Track TikTok Ban Blocked by Sen. Paul
 - [https://www.theepochtimes.com/sen-hawleys-efforts-to-fast-track-tiktok-ban-blocked-by-sen-paul_5159258.html](https://www.theepochtimes.com/sen-hawleys-efforts-to-fast-track-tiktok-ban-blocked-by-sen-paul_5159258.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-29 23:49:03+00:00

Sen. Rand Paul (R-Ky.) speaks in Washington on Dec. 20, 2022. (Chip Somodevilla/Getty Images)

## AI Could Eliminate 300 Million Jobs, Warns Goldman Sachs
 - [https://www.theepochtimes.com/ai-could-eliminate-300-million-jobs-warns-goldman-sachs_5157862.html](https://www.theepochtimes.com/ai-could-eliminate-300-million-jobs-warns-goldman-sachs_5157862.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-29 21:05:27+00:00

A smartphone with a displayed ChatGPT logo is placed on a computer motherboard in this illustration taken on Feb. 23, 2023. (Dado Ruvic/Reuters)

## IRS Warns of Scams Spreading on Social Media That Could Get ‘Well-Meaning Taxpayers in Trouble’
 - [https://www.theepochtimes.com/irs-warns-of-scams-spreading-on-social-media-that-could-get-well-meaning-taxpayers-in-trouble_5156975.html](https://www.theepochtimes.com/irs-warns-of-scams-spreading-on-social-media-that-could-get-well-meaning-taxpayers-in-trouble_5156975.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-29 18:03:14+00:00

The Internal Revenue Service building is seen in Washington, on Sept. 28, 2020. (Erin Scott/Reuters)

## Federal Agency Warns Users to Upgrade iPhones as Soon as Possible
 - [https://www.theepochtimes.com/federal-agency-warns-users-to-upgrade-iphones-as-soon-as-possible_5152796.html](https://www.theepochtimes.com/federal-agency-warns-users-to-upgrade-iphones-as-soon-as-possible_5152796.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-29 14:15:09+00:00

An Israeli woman uses her iPhone in front of the building housing the Israeli NSO group in Herzliya, near Tel Aviv, on Aug. 28, 2016.  (Jack Guez/AFP via Getty Images)

## Europe to Ban Sale of New Gasoline Cars From 2035
 - [https://www.theepochtimes.com/europe-to-ban-sale-of-new-gasoline-cars-from-2035_5157098.html](https://www.theepochtimes.com/europe-to-ban-sale-of-new-gasoline-cars-from-2035_5157098.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-29 13:12:16+00:00

Tesla electric-powered sedan at a Tesla charging station in Rieden, Germany, on June 11, 2015. (Sean Gallup/Getty Images)

## Elon Musk Leads Joins Over 1,000 Experts Calling for Pause on Advanced AI Development
 - [https://www.theepochtimes.com/elon-musk-leads-joins-over-1000-experts-calling-for-pause-on-advanced-ai-development_5156849.html](https://www.theepochtimes.com/elon-musk-leads-joins-over-1000-experts-calling-for-pause-on-advanced-ai-development_5156849.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-29 13:04:38+00:00

Tesla CEO Elon Musk leaves the Phillip Burton Federal Building in San Francisco, Calif., on Jan. 24, 2023. (Justin Sullivan/Getty Images)

## Arkansas Sues Meta, TikTok for Designing ‘Addictive’ Platforms, Exposing Personal Data
 - [https://www.theepochtimes.com/arkansas-sues-meta-tiktok-for-designing-addictive-platforms-exposing-personal-data_5156774.html](https://www.theepochtimes.com/arkansas-sues-meta-tiktok-for-designing-addictive-platforms-exposing-personal-data_5156774.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-29 09:32:39+00:00

The logo for social media app TikTok is displayed on the screen of an iPhone on an American flag background in Arlington, Va., on Aug. 3, 2020. (Olivier Douliery/AFP via Getty Images)

## Japanese Lawmakers Eye Ban on TikTok, Others If Used Improperly
 - [https://www.theepochtimes.com/japanese-lawmakers-eye-ban-on-tiktok-others-if-used-improperly_5151478.html](https://www.theepochtimes.com/japanese-lawmakers-eye-ban-on-tiktok-others-if-used-improperly_5151478.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-29 03:55:40+00:00

A smartphone with a displayed TikTok logo is placed on a computer motherboard in this illustration taken on Feb. 23, 2023. (Dado Ruvic/Reuters)

