# Source:Eliminate, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCI7kKmUuSQOHUvSWIYFDf1Q, language:en-US

## BARS (酒吧)
 - [https://www.youtube.com/watch?v=3M2VnBie53A](https://www.youtube.com/watch?v=3M2VnBie53A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCI7kKmUuSQOHUvSWIYFDf1Q
 - date published: 2023-03-29 17:27:53+00:00

this the kinda beat that doesn't go

Madonkey:
https://soundcloud.com/madonkey
https://www.instagram.com/_madonkey_/

sample credit: https://www.tiktok.com/@bianlianwenhua/video/7198485365055900954

Stream my new single 'Mutation': https://bassrush.ffm.to/mutation

• TWITCH: https://www.twitch.tv/eliminatehq
• DISCORD: https://discord.gg/eliminatehq
• MY SAMPLE PACK: https://splice.com/sounds/disciple-samples/eliminate-cyber-trap-vol-1?sound_type=sample
• INSTAGRAM: https://www.instagram.com/eliminatemusic/
• TWITTER: https://twitter.com/eliminatemusic
• SUBREDDIT: https://www.reddit.com/r/EliminateHQ/


top secret burner account:
https://soundcloud.com/dubsteptractor

