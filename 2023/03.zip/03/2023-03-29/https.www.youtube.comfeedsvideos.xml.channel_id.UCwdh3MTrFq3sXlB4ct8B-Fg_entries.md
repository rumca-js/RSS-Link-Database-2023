# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## Why Do People Love Terminators? – Warhammer 40,000
 - [https://www.youtube.com/watch?v=W_gYJ7i9hmI](https://www.youtube.com/watch?v=W_gYJ7i9hmI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-03-29 14:00:51+00:00

The Warhammer 40,000 team look back at Terminators – the kit that everyone loves. https://bit.ly/3G001yX  #New40k

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## 40 Years of Warhammer – Space Marine Dreadnought
 - [https://www.youtube.com/watch?v=9nUw5z8LrdE](https://www.youtube.com/watch?v=9nUw5z8LrdE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-03-29 13:00:51+00:00

It's a big metal box representing a bigger metal box! Who remembers this classic Space Marines Dreadnought? https://bit.ly/3FTjnFK 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Get Triple the Blood in the First Three-Way Battle Report on Warhammer+ #Short
 - [https://www.youtube.com/watch?v=fA6fcJeaLs8](https://www.youtube.com/watch?v=fA6fcJeaLs8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-03-29 12:46:10+00:00

Blood begets blood begets blood in this week's three-way Battle Report. Who will come out on top – the World Eaters, Flesh Tearers, or Commander Farsight's T'au Empire force? warhammertv.com

