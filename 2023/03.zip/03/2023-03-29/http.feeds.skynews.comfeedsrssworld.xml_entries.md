# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## King's poignant first state visit reaffirming Anglo-German relations
 - [https://news.sky.com/story/kings-poignant-first-state-visit-reaffirming-anglo-german-relations-12845212](https://news.sky.com/story/kings-poignant-first-state-visit-reaffirming-anglo-german-relations-12845212)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 20:03:00+00:00

The King was still mid-flight when the military welcome began.

## Pope to spend 'few days' in hospital for respiratory infection
 - [https://news.sky.com/story/pope-to-spend-few-days-in-hospital-for-respiratory-infection-12845167](https://news.sky.com/story/pope-to-spend-few-days-in-hospital-for-respiratory-infection-12845167)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 18:36:00+00:00

Pope Francis will need to spend "a few days" in hospital for treatment for a respiratory infection, the Vatican says.

## Trans community fears backlash after Nashville school shooting
 - [https://news.sky.com/story/nashville-school-shooting-trans-community-fears-backlash-after-attack-by-audrey-hale-12845047](https://news.sky.com/story/nashville-school-shooting-trans-community-fears-backlash-after-attack-by-audrey-hale-12845047)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 14:57:00+00:00

The trans community is fearing a &#8220;backlash&#8221; following the school shooting in Nashville.

## Elon Musk and experts say AI development should be paused immediately
 - [https://news.sky.com/story/elon-musk-and-others-sign-open-letter-calling-for-pause-on-ai-development-12845039](https://news.sky.com/story/elon-musk-and-others-sign-open-letter-calling-for-pause-on-ai-development-12845039)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 14:49:00+00:00

Elon Musk and a group of artificial intelligence experts are calling for a pause in the training of powerful AI systems due to the potential risks to society and humanity.

## Killer plant fungus infects man in 'world-first case'
 - [https://news.sky.com/story/killer-plant-fungus-chondrostereum-purpureum-infects-man-in-india-in-world-first-case-12844978](https://news.sky.com/story/killer-plant-fungus-chondrostereum-purpureum-infects-man-in-india-in-world-first-case-12844978)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 13:43:00+00:00

A killer plant fungus infected a human and caused flu-like symptoms in what researchers say is a world-first case.

## King addresses state banquet after German president hails Charles's 'convictions'
 - [https://news.sky.com/story/king-charles-and-camilla-arrive-in-berlin-for-first-state-visit-12844936](https://news.sky.com/story/king-charles-and-camilla-arrive-in-berlin-for-first-state-visit-12844936)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 12:18:00+00:00

The King has addressed a banquet in Berlin on his first state visit since the start of the new monarch's reign.

## More than 220,000 Russian troops and mercenaries killed or injured in Ukraine, UK defence sec says
 - [https://news.sky.com/story/ukraine-war-more-than-220000-russian-troops-and-mercenaries-killed-or-injured-since-start-of-invasion-uk-defence-sec-says-12844916](https://news.sky.com/story/ukraine-war-more-than-220000-russian-troops-and-mercenaries-killed-or-injured-since-start-of-invasion-uk-defence-sec-says-12844916)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 11:55:00+00:00

More than 220,000 Russian troops and mercenaries have been killed or injured in Ukraine, according to the latest US assessment, Britain's defence secretary has revealed.

## Next wave of weight loss jabs could be coming - this time without the nausea
 - [https://news.sky.com/story/next-wave-of-weight-loss-jabs-could-be-coming-without-the-nausea-ozempic-and-wegovy-can-cause-12844910](https://news.sky.com/story/next-wave-of-weight-loss-jabs-could-be-coming-without-the-nausea-ozempic-and-wegovy-can-cause-12844910)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 11:43:00+00:00

Weight loss jabs such as Ozempic and Wegovy have been hailed as the future of obesity treatment - but some users are debilitated by nausea and regain the lost pounds as soon as they stop injections.&#160;

## US and South Korea staging biggest military drills for years as North ramps up tensions
 - [https://news.sky.com/story/us-and-south-korea-staging-biggest-military-drills-for-years-as-north-ramps-up-tensions-12844883](https://news.sky.com/story/us-and-south-korea-staging-biggest-military-drills-for-years-as-north-ramps-up-tensions-12844883)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 11:14:00+00:00

On the southeast coast of South Korea its military is rehearsing.

## Sabrina star Melissa Joan Hart helped children fleeing Nashville school shooting
 - [https://news.sky.com/story/sabrina-star-melissa-joan-hart-helped-children-fleeing-nashville-school-shooting-12844764](https://news.sky.com/story/sabrina-star-melissa-joan-hart-helped-children-fleeing-nashville-school-shooting-12844764)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 08:46:00+00:00

Actor Melissa Joan Hart helped children running away from the shooter who killed six people at a Nashville school.&#160;

## Biden and Netanyahu in icy exchange over Israel's controversial judicial reforms
 - [https://news.sky.com/story/joe-biden-and-benjamin-netanyahu-in-icy-exchange-over-israels-controversial-judicial-reforms-12844704](https://news.sky.com/story/joe-biden-and-benjamin-netanyahu-in-icy-exchange-over-israels-controversial-judicial-reforms-12844704)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 07:22:00+00:00

US President Joe Biden has openly criticised Israel's controversial judicial reforms and told Prime Minister Benjamin Netanyahu to "walk away" from them.

## Footage shows guards appearing to make no effort to help 38 migrants who died in Mexico detention centre fire
 - [https://news.sky.com/story/mexico-detention-centre-fire-footage-appears-to-show-guards-make-no-effort-to-help-38-migrants-who-died-12844712](https://news.sky.com/story/mexico-detention-centre-fire-footage-appears-to-show-guards-make-no-effort-to-help-38-migrants-who-died-12844712)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 07:20:00+00:00

Guards at a Mexico detention centre appeared to make no effort to help 38 migrants who died in a fire, surveillance footage shows.

## Star Wars star Mark Hamill helping warn Ukrainians of Russian air strikes
 - [https://news.sky.com/story/star-wars-star-mark-hamill-lends-voice-to-air-raid-alert-app-to-warn-ukrainians-of-russian-strikes-12844695](https://news.sky.com/story/star-wars-star-mark-hamill-lends-voice-to-air-raid-alert-app-to-warn-ukrainians-of-russian-strikes-12844695)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 07:08:00+00:00

Star Wars star Mark Hamill is lending his voice to an air raid alert app to warn Ukrainians of incoming Russian bombardments.

## Adnan Syed's murder conviction reinstated in Serial podcast case
 - [https://news.sky.com/story/adnan-syeds-murder-conviction-reinstated-in-serial-podcast-case-12844692](https://news.sky.com/story/adnan-syeds-murder-conviction-reinstated-in-serial-podcast-case-12844692)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-29 07:06:00+00:00

Adnan Syed's murder conviction has been reinstated in the latest development in the prolonged case featured in the hit podcast Serial.

