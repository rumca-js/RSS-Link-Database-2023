# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## The worst price war! Foreign brands are tasting the bitter fruit of joint ventures with China
 - [https://www.youtube.com/watch?v=tBxcJIjlQuA](https://www.youtube.com/watch?v=tBxcJIjlQuA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-03-29 00:00:10+00:00

#chinainsights 
From the mentioned background, we can see that the price war in the Chinese auto industry will not lead to any positive effects over the long term. But without price cuts, it is difficult for Chinese automakers to find a way out quickly.
A noteworthy phenomenon is that foreign automakers are also involved in the price war.

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

