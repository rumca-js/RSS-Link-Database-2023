# Source:Call Me Chato, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg, language:en-US

## How 3D animation killed Superhero movies.
 - [https://www.youtube.com/watch?v=v8tYMbZjDMw](https://www.youtube.com/watch?v=v8tYMbZjDMw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg
 - date published: 2023-03-29 23:19:15+00:00

#FormerNetworkExec #CallMeChato #superheroes 
Why comics and animation is way better than real life versions of superhero movies.
Thanks for watching my channel. Please subscribe, SHARE and touch yourselves.

Call Me Chato T-shirt
https://my-store-6121db.creator-spring.com/listing/ppc-cartoon-t-colour

https://twitter.com/PaulChato
http://www.paulchato.com

