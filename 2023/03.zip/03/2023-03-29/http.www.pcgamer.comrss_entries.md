# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## The Chinese versions of Blizzard's games may have been shut down over a big misunderstanding
 - [https://www.pcgamer.com/the-chinese-versions-of-blizzards-games-may-have-been-shut-down-over-a-big-misunderstanding](https://www.pcgamer.com/the-chinese-versions-of-blizzards-games-may-have-been-shut-down-over-a-big-misunderstanding)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 23:34:48+00:00

A New York Times report says the bad blood came to a boil over a perceived threat during a licensing negotiation.

## Electronic Arts is laying off 6% of its workforce
 - [https://www.pcgamer.com/electronic-arts-is-laying-off-6-of-its-workforce](https://www.pcgamer.com/electronic-arts-is-laying-off-6-of-its-workforce)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 21:32:50+00:00

Things are going really great at EA, so it's time to start firing people.

## I got to see PUBG creator Brendan Greene's next project: a digital world the size of a real planet
 - [https://www.pcgamer.com/i-got-to-see-pubg-creator-brendan-greenes-next-project-a-digital-world-the-size-of-a-real-planet](https://www.pcgamer.com/i-got-to-see-pubg-creator-brendan-greenes-next-project-a-digital-world-the-size-of-a-real-planet)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 21:16:18+00:00

Greene is building a virtual planet called Project Artemis to act as "a big emergent space," but he doesn't want to dictate what players do with it.

## Nightdive reassures fans about the Atari deal: 'Not only will we be doing as much as we ever did, but we'll be doing more of it'
 - [https://www.pcgamer.com/nightdive-reassures-fans-about-the-atari-deal-not-only-will-we-be-doing-as-much-as-we-ever-did-but-well-be-doing-more-of-it](https://www.pcgamer.com/nightdive-reassures-fans-about-the-atari-deal-not-only-will-we-be-doing-as-much-as-we-ever-did-but-well-be-doing-more-of-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 20:56:03+00:00

News of the buyout didn't go over very well with fans, but Nightdive and Atari both say they have shared goals in "innovative" retro gaming.

## You can try Nexon's new tactical shooter for free this week
 - [https://www.pcgamer.com/you-can-try-nexons-new-tactical-shooter-for-free-this-week](https://www.pcgamer.com/you-can-try-nexons-new-tactical-shooter-for-free-this-week)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 18:39:50+00:00

The final beta for the 5v5 shooter Veiled Experts kicks off at midnight tonight.

## Finally, a game that lets us fight the human menace as goblins
 - [https://www.pcgamer.com/finally-a-game-that-lets-us-fight-the-human-menace-as-goblins](https://www.pcgamer.com/finally-a-game-that-lets-us-fight-the-human-menace-as-goblins)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 18:09:35+00:00

Time to go goblin mode.

## Tony Hawk almost put his name on a 'more technically difficult' skating sim before Activision called
 - [https://www.pcgamer.com/tony-hawk-almost-put-his-name-on-a-more-technically-difficult-skating-sim-before-activision-called](https://www.pcgamer.com/tony-hawk-almost-put-his-name-on-a-more-technically-difficult-skating-sim-before-activision-called)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 17:48:24+00:00

What would gaming be like with no Tony Hawk's Pro Skater?

## D&D is coming to Minecraft
 - [https://www.pcgamer.com/dandd-is-coming-to-minecraft](https://www.pcgamer.com/dandd-is-coming-to-minecraft)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 16:34:49+00:00

The add-on includes a 10-hour adventure with customizable characters and 20-sided dice, and it's coming soon.

## I'm happy that Diablo 4 is just a prettier Diablo 3
 - [https://www.pcgamer.com/im-happy-that-diablo-4-is-just-a-prettier-diablo-3](https://www.pcgamer.com/im-happy-that-diablo-4-is-just-a-prettier-diablo-3)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 16:20:40+00:00

If it ain't broke, don't fix it.

## Diablo 4's story is intriguing, but I wish it didn't keep killing the momentum
 - [https://www.pcgamer.com/diablo-4s-story-is-intriguing-but-i-wish-it-didnt-keep-killing-the-momentum](https://www.pcgamer.com/diablo-4s-story-is-intriguing-but-i-wish-it-didnt-keep-killing-the-momentum)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 16:12:12+00:00

Don't talk to me, I'm looting.

## Bloober Team wants you to know it never said Silent Hill 2 is done, no matter what Google Translate says
 - [https://www.pcgamer.com/bloober-team-wants-you-to-know-it-never-said-silent-hill-2-is-done-no-matter-what-google-translate-says](https://www.pcgamer.com/bloober-team-wants-you-to-know-it-never-said-silent-hill-2-is-done-no-matter-what-google-translate-says)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 15:48:47+00:00

And it never said it'd sell 10 million copies of it, either.

## More than a decade after the MCU conquered cinema, why haven't superheroes taken over games?
 - [https://www.pcgamer.com/more-than-a-decade-after-the-mcu-conquered-cinema-why-havent-superheroes-taken-over-games](https://www.pcgamer.com/more-than-a-decade-after-the-mcu-conquered-cinema-why-havent-superheroes-taken-over-games)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 14:45:49+00:00

We should be in the middle of a superhero game renaissance, but it never arrived.

## Tech luminaries including Musk and Wozniak beg AI pioneers to hit the brakes
 - [https://www.pcgamer.com/tech-luminaries-including-musk-and-wozniak-beg-ai-pioneers-to-hit-the-brakes](https://www.pcgamer.com/tech-luminaries-including-musk-and-wozniak-beg-ai-pioneers-to-hit-the-brakes)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 14:03:16+00:00

Open letter calls for six month pause on the AI experiment.

## Endless Dungeon wants you to play with friends but a lack of shared progression doesn't make it easy
 - [https://www.pcgamer.com/endless-dungeon-wants-you-to-play-with-friends-but-a-lack-of-shared-progression-doesnt-make-it-easy](https://www.pcgamer.com/endless-dungeon-wants-you-to-play-with-friends-but-a-lack-of-shared-progression-doesnt-make-it-easy)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 14:00:00+00:00

Amplitude has developed the game with co-op in mind but is missing some crucial quality-of-life decisions.

## Disney CEO axes metaverse unit and almost everyone in it, with another 6,950 cuts to go
 - [https://www.pcgamer.com/disney-ceo-axes-metaverse-unit-and-almost-everyone-in-it-with-another-6950-cuts-to-go](https://www.pcgamer.com/disney-ceo-axes-metaverse-unit-and-almost-everyone-in-it-with-another-6950-cuts-to-go)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 13:06:43+00:00

Bob Iger once said the tech would democratise the internet, but apparently it's not right for Disney.

## It took the original Resident Evil 4 a year to hit 3 million sales, but the remake has done it in 2 days
 - [https://www.pcgamer.com/it-took-the-original-resident-evil-4-a-year-to-hit-3-million-sales-but-the-remake-has-done-it-in-2-days](https://www.pcgamer.com/it-took-the-original-resident-evil-4-a-year-to-hit-3-million-sales-but-the-remake-has-done-it-in-2-days)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 12:26:17+00:00

Our appetite for being chased by chainsaw-wielding maniacs has only grown.

## How to find Blue Medallions in Resident Evil 4 Remake
 - [https://www.pcgamer.com/resident-evil-4-remake-blue-medallions](https://www.pcgamer.com/resident-evil-4-remake-blue-medallions)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 11:17:23+00:00

Complete the Destroy the Blue Medallions requests by shooting these symbols.

## Nvidia's RTX 4060 and 4060 Ti rumoured to launch in May and could struggle even at 1080p
 - [https://www.pcgamer.com/nvidias-rtx-4060-and-4060-ti-rumoured-to-launch-in-may-and-could-struggle-even-at-1080p](https://www.pcgamer.com/nvidias-rtx-4060-and-4060-ti-rumoured-to-launch-in-may-and-could-struggle-even-at-1080p)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 11:12:35+00:00

Please, please tell us the rumoured specs for Nvidia's ever-GPUs aren't right...

## The Last of Us' PC port is bad, but the bugs are great
 - [https://www.pcgamer.com/the-last-of-us-pc-port-is-bad-but-the-bugs-are-great](https://www.pcgamer.com/the-last-of-us-pc-port-is-bad-but-the-bugs-are-great)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 11:10:22+00:00

I'm not saying the shoddy port was worth it, but I'm not NOT saying that, either.

## Man caught obviously smuggling CPUs under his clothes
 - [https://www.pcgamer.com/man-caught-obviously-smuggling-cpus-under-his-clothes](https://www.pcgamer.com/man-caught-obviously-smuggling-cpus-under-his-clothes)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 05:18:01+00:00

I heard under his shirt he has so many cores, like at least a ten pack.

## Wordle hint and answer #648: Wednesday, March 29
 - [https://www.pcgamer.com/wordle-hint-answer-today-648-march-29](https://www.pcgamer.com/wordle-hint-answer-today-648-march-29)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-29 04:07:44+00:00

Today's Wordle: Help with the #648 puzzle.

