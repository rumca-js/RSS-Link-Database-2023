# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Actress Melissa Joan Hart describes helping children flee campus after shooting
 - [https://edition.cnn.com/2023/03/29/entertainment/melissa-joan-hart-nashville-school-shooting/index.html](https://edition.cnn.com/2023/03/29/entertainment/melissa-joan-hart-nashville-school-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 20:48:43.937189+00:00

Actress Melissa Joan Hart says she was near Nashville's Covenant School soon after Monday's deadly shooting of six people, including three children, and helped some students get away from the scene.

## Trump made claim about endorsing DeSantis. Fact checker sets the record straight
 - [https://www.cnn.com/videos/politics/2023/03/29/fact-check-trump-desantis-florida-daniel-dale-newsroom-vpx.cnn](https://www.cnn.com/videos/politics/2023/03/29/fact-check-trump-desantis-florida-daniel-dale-newsroom-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 20:33:19+00:00

CNN's Daniel Dale fact checks multiple claims by former President Donald Trump about Florida Gov. Ron DeSantis.

## Fox News chief's messages made public as part of Dominion lawsuit
 - [https://www.cnn.com/2023/03/29/media/fox-news-dominion-messages/index.html](https://www.cnn.com/2023/03/29/media/fox-news-dominion-messages/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 20:23:40+00:00

Fox News chief executive Suzanne Scott internally sounded the alarm about the financial fallout that the right-wing network would suffer if it continued fact-checking then-President Donald Trump's lies after the 2020 election, according to messages that became public Wednesday.

## Watch tense exchange between Sanders and GOP senator during hearing
 - [https://www.cnn.com/videos/business/2023/03/29/bernie-sanders-howard-schultz-starbucks-senate-hearing-vpx.cnn](https://www.cnn.com/videos/business/2023/03/29/bernie-sanders-howard-schultz-starbucks-senate-hearing-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 20:13:27+00:00

Sen. Bernie Sanders (I-VT) questioned former Starbucks CEO Howard Schultz on the company's union-busting tactics and engaged in a tense exchange with Republican colleague Sen. Markwayne Mullin (R-OK).

## Doctor explains new over-the-counter medicine that's a 'complete antidote to opioids'
 - [https://www.cnn.com/videos/health/2023/03/29/fda-narcan-otc-naloxone-opiods-overdose-doctor-wen-nr-contd-vpx.cnn](https://www.cnn.com/videos/health/2023/03/29/fda-narcan-otc-naloxone-opiods-overdose-doctor-wen-nr-contd-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 20:09:52+00:00

With drug overdose deaths continuing to hover near record levels, the US Food and Drug Administration approved for the first time an over-the-counter version of the opioid overdose antidote Narcan. Dr. Leana Wen explains.

## Actor brings special treat for Fallon to taste on 'Tonight Show'
 - [https://www.cnn.com/videos/media/2023/03/29/nicholas-hoult-jimmy-fallon-renfield-orig-jc.cnn](https://www.cnn.com/videos/media/2023/03/29/nicholas-hoult-jimmy-fallon-renfield-orig-jc.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 19:42:53+00:00

British actor Nicholas Hoult will be starring alongside Nicolas Cage in the new film "Renfield," where Hoult's character gains special powers from eating bugs. The actor brought some of these special treats to NBC's "The Tonight Show with Jimmy Fallon."

## Pope Francis hospitalized for a respiratory infection, Vatican spokesperson says
 - [https://www.cnn.com/2023/03/29/europe/pope-francis-hospitalization-respiratory-infection-intl/index.html](https://www.cnn.com/2023/03/29/europe/pope-francis-hospitalization-respiratory-infection-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 19:34:43+00:00

Pope Francis has a respiratory infection and will need to spend "a few days" in the hospital, the Vatican spokesman Matteo Bruni said in a statement on Wednesday.

## Meet the titanosaur: Dinosaur giant goes on display in Europe for the first time
 - [https://www.cnn.com/travel/article/natural-history-museum-titanosaur-patagonia-mayorum-spc-intl-scn/index.html](https://www.cnn.com/travel/article/natural-history-museum-titanosaur-patagonia-mayorum-spc-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 18:36:02+00:00

In the venerated halls of London's Natural History Museum, one of the largest animals ever to walk the Earth is about to make its debut.

## Breakups suck, but our behavior doesn't have to
 - [https://www.cnn.com/2023/03/29/opinions/relationships-rejection-new-zealand-love-better-thomas-ctrp/index.html](https://www.cnn.com/2023/03/29/opinions/relationships-rejection-new-zealand-love-better-thomas-ctrp/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 18:19:55+00:00

In my early 20s, I agreed to accompany a man on a cruise to Iceland on a whim. At the 11th hour, I wavered. I wasn't romantically interested in him, and it occurred to me, embarrassingly late in the day, that embarking on such a trip might constitute a mixed signal. I vacillated and sent awkward, non-committal responses to his messages. To his credit, he called me on it. "Just say you're not interested," he said. "I can take it."

## Jeremy Renner talks tragedy and triumph with Diane Sawyer
 - [https://www.cnn.com/2023/03/29/entertainment/jeremy-renner-diana-sawyer/index.html](https://www.cnn.com/2023/03/29/entertainment/jeremy-renner-diana-sawyer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 18:13:25+00:00

Jeremy Renner has sat down for his first interview since the New Year's Day accident that could have killed him.

## Elon Musk, Bill Gates and other tech leaders call for pause in 'out of control' AI race
 - [https://www.cnn.com/2023/03/29/tech/ai-letter-elon-musk-tech-leaders/index.html](https://www.cnn.com/2023/03/29/tech/ai-letter-elon-musk-tech-leaders/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 16:18:36+00:00

Some of the biggest names in tech are calling for artificial intelligence labs to stop the training of the most powerful AI systems for at least six months, citing "profound risks to society and humanity."

## SE Cupp: What Candace Owens' attack on a Skims ad reveals
 - [https://www.cnn.com/videos/opinions/2023/03/29/se-cupp-unfiltered-candace-owens-skims-ad-reaction-vpx.cnn](https://www.cnn.com/videos/opinions/2023/03/29/se-cupp-unfiltered-candace-owens-skims-ad-reaction-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 16:13:37+00:00

In this week's episode of "Unfiltered," SE Cupp argues that right-wing commentator Candace Owens' criticism of a Skims ad featuring a model in a wheelchair is an attack on capitalism itself, which is ironic since Owens claims to believe capitalism is far superior to socialism.

## 'He's very protective of the rock': Eagle thinks rock is an egg
 - [https://www.cnn.com/videos/us/2023/03/29/bald-eagle-incubates-rock-moos-cprog-orig-bdk.cnn](https://www.cnn.com/videos/us/2023/03/29/bald-eagle-incubates-rock-moos-cprog-orig-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 16:08:59+00:00

Eagle shows great dad skills ... except he's trying to hatch a rock rather than an egg. CNN's Jeanne Moos reports.

## The Lamborghini Revuelto is a 1,001 horsepower hybrid supercar flagship
 - [https://www.cnn.com/2023/03/29/business/lamborghini-revuelto-hybrid/index.html](https://www.cnn.com/2023/03/29/business/lamborghini-revuelto-hybrid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 16:02:56+00:00

Soon, you'll be able to plug in your Lamborghini.

## Man hikes mountain almost daily for 3 years. See his dramatic transformation
 - [https://www.cnn.com/videos/us/2023/03/29/georgia-man-stone-mountain-hike-weight-loss-wxia-cprog-vpx.wxia](https://www.cnn.com/videos/us/2023/03/29/georgia-man-stone-mountain-hike-weight-loss-wxia-cprog-vpx.wxia)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 15:47:16+00:00

Zach Cross hiked Georgia's Stone Mountain nearly every day for three years and lost 200 pounds in the process. CNN affiliate WXIA reports on what he plans to do next.

## Russian conductor makes a comeback in China after he was fired for refusing to condemn the war
 - [https://www.cnn.com/collections/ukraine-intl-290323/](https://www.cnn.com/collections/ukraine-intl-290323/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 15:36:05+00:00



## Opinion: Russia's nuclear blackmail is a spectacular success for Putin
 - [https://www.cnn.com/2023/03/29/opinions/russia-putin-nuclear-blackmail-belarus-giles/index.html](https://www.cnn.com/2023/03/29/opinions/russia-putin-nuclear-blackmail-belarus-giles/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 15:24:57+00:00

Vladimir Putin last week gave details of Russia's stated intent to base tactical nuclear weapons in Belarus. The flurry of alarmist reporting on what this meant highlights much of what is wrong with Western responses to Russian nuclear intimidation.

## Adidas does rapid U-turn in Black Lives Matter logo dispute
 - [https://www.cnn.com/collections/intl-biz-290323/](https://www.cnn.com/collections/intl-biz-290323/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 15:21:13+00:00



## Neil Patrick Harris reprises role on 'How I Met Your Father'
 - [https://www.cnn.com/2023/03/29/entertainment/neil-patrick-harris-how-i-met-your-father/index.html](https://www.cnn.com/2023/03/29/entertainment/neil-patrick-harris-how-i-met-your-father/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 15:17:52+00:00

Neil Patrick Harris was back in the role of Barney Stinson in the mid-season finale of "How I Met Your Father."

## Astronomers discover ultramassive black hole using new technique
 - [https://www.cnn.com/2023/03/29/europe/ultramassive-black-hole-intl-gbr-scn/index.html](https://www.cnn.com/2023/03/29/europe/ultramassive-black-hole-intl-gbr-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 15:17:36+00:00

An ultramassive black hole, understood to be one of the largest ever detected, has been discovered by astronomers using a new technique.

## Netanyahu is backed into a corner. Here's what he may do next
 - [https://www.cnn.com/collections/intl-bibi-290323/](https://www.cnn.com/collections/intl-bibi-290323/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 15:14:38+00:00



## In pictures: King Charles III visits Germany
 - [https://www.cnn.com/2023/03/29/europe/gallery/king-charles-visits-germany/index.html](https://www.cnn.com/2023/03/29/europe/gallery/king-charles-visits-germany/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 15:09:18+00:00

Britain's King Charles III arrived in Germany on Wednesday for his first overseas state visit as monarch.

## Suspect arrested after staffer for Sen. Rand Paul stabbed in DC
 - [https://www.cnn.com/2023/03/29/politics/rand-paul-staffer-stabbed/index.html](https://www.cnn.com/2023/03/29/politics/rand-paul-staffer-stabbed/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 15:08:54+00:00

Republican Sen. Rand Paul of Kentucky said a stabbing attack for one of his staffers over the weekend in Washington, DC "was life threatening, but he will recover."

## Federal judge rules Google tried to 'hide the ball' by deleting chat logs in a big antitrust case
 - [https://www.cnn.com/2023/03/29/tech/judge-google-deleted-chat-logs-antitrust-case/index.html](https://www.cnn.com/2023/03/29/tech/judge-google-deleted-chat-logs-antitrust-case/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 14:34:12+00:00

Google intentionally sought to "hide the ball" in a high-profile antitrust case by automatically deleting employee chat messages that could have been used as evidence in the suit, a federal judge ruled Tuesday, dealing a blow to the tech giant.

## A day in the life of the first Gen Z Congressman
 - [https://www.cnn.com/videos/politics/2023/03/29/maxwell-frost-gen-z-congressman-mh-orig.cnn](https://www.cnn.com/videos/politics/2023/03/29/maxwell-frost-gen-z-congressman-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 14:00:46+00:00

Florida Rep. Maxwell Frost takes CNN inside a day on Capitol Hill where he speaks at a rally, attends a Committee hearing, and gives a tour of his office.

## Two fishermen involved in cheating scandal at Ohio tournament plead guilty
 - [https://www.cnn.com/2023/03/29/sport/ohio-fishing-cheat-scandal-guilty-spt-intl/index.html](https://www.cnn.com/2023/03/29/sport/ohio-fishing-cheat-scandal-guilty-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 13:57:02+00:00

Two men who allegedly cheated to win a competitive fishing competition have pleaded guilty to charges, including cheating, according to the Cuyahoga County Office of the Prosecutor.

## You can't cure dementia, but here are 4 ways to prevent it
 - [https://www.cnn.com/videos/health/2023/03/28/dementia-prevention-tips-lbb-orig.cnn](https://www.cnn.com/videos/health/2023/03/28/dementia-prevention-tips-lbb-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 13:37:44+00:00

Even with recent medical advancements, there is still no cure for dementia. Doctors point out that there are, however, recent discoveries and new research that can help prevent and delay its progression.

## Arkansas sues TikTok, ByteDance and Meta over mental health claims
 - [https://www.cnn.com/2023/03/29/tech/arkansas-lawsuit-tiktok-bytedance-meta-mental-health/index.html](https://www.cnn.com/2023/03/29/tech/arkansas-lawsuit-tiktok-bytedance-meta-mental-health/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 13:37:02+00:00

The state of Arkansas has sued TikTok, its parent ByteDance, and Facebook-parent Meta over claims the companies' products are harmful to users, in the latest effort by public officials to take social media companies to court over mental-health and privacy concerns.

## Keanu Reeves offers rare comment about his relationship
 - [https://www.cnn.com/2023/03/29/entertainment/keanu-reeves-relationship/index.html](https://www.cnn.com/2023/03/29/entertainment/keanu-reeves-relationship/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 13:26:27+00:00

Keanu Reeves is intensely private about is personal life. But when does have something to say, he makes it special.

## Adidas does rapid U-turn in Black Lives Matter logo dispute
 - [https://www.cnn.com/2023/03/29/business/adidas-black-lives-matter-trademark/index.html](https://www.cnn.com/2023/03/29/business/adidas-black-lives-matter-trademark/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 13:12:05+00:00

Adidas is backpedaling fast over its latest attempt to protect its iconic three-stripe mark.

## Bank of England calls for urgent action on funds that nearly toppled UK financial system
 - [https://www.cnn.com/2023/03/29/business/bank-of-england-pensions-risk/index.html](https://www.cnn.com/2023/03/29/business/bank-of-england-pensions-risk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 12:51:54+00:00

The Bank of England has called for urgent action to address a weak spot in the UK financial system as persistent worries about the global banking sector threaten to unleash fresh market turmoil.

## Children and teens in US are more likely to die by guns than anything else
 - [https://cnn.it/3TUaTUG](https://cnn.it/3TUaTUG)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 12:48:42.396578+00:00



## Boris Becker says best to 'make friends with the strong boys' as he recalls 'very scary' life in prison
 - [https://www.cnn.com/2023/03/29/tennis/boris-becker-alex-gibney-documentary-spt-intl/index.html](https://www.cnn.com/2023/03/29/tennis/boris-becker-alex-gibney-documentary-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 12:23:09+00:00

Tennis great Boris Becker says he's grateful just to be alive as he reflected on spending time in prison in an interview with CNN's Christiane Amanpour.

## This lizard species stress-eats to cope with noisy US Army aircraft
 - [https://www.cnn.com/2023/03/29/americas/lizards-stress-eat-scn/index.html](https://www.cnn.com/2023/03/29/americas/lizards-stress-eat-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 12:19:04+00:00

Living in a neighborhood with lots of noise can make you jittery, especially if you're a lizard that's just a few inches long.

## Atlanta's so-called 'Cop City' is igniting protests. Here's what we know about the foundation behind it
 - [https://www.cnn.com/2023/03/29/us/atlanta-cop-city-protests-police-foundation-dg/index.html](https://www.cnn.com/2023/03/29/us/atlanta-cop-city-protests-police-foundation-dg/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 12:15:00+00:00

Earlier this month, nearly two dozen people were arrested after demonstrations against a police and fire training center near Atlanta that opponents have dubbed "Cop City." But while critics of the facility say it will harm the environment and propagate police militarization, the controversy has seeped into the foundation behind it.

## 'They escaped from the woods': Witness describes scene outside of school
 - [https://www.cnn.com/videos/us/2023/03/29/nashville-school-shooting-witness-street-woods-cnntm-vpx.cnn](https://www.cnn.com/videos/us/2023/03/29/nashville-school-shooting-witness-street-woods-cnntm-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 12:14:11+00:00

CNN's Don Lemon speaks to Jason Hoffman, a witness who helped children cross the street during the shooting of a private Christian school in Nashville, Tennessee.

## 'Ultra-rare' pink diamond expected to sell for more than $35 million at auction
 - [https://www.cnn.com/style/article/pink-diamond-sale-june-2023-sothebys-new-york/index.html](https://www.cnn.com/style/article/pink-diamond-sale-june-2023-sothebys-new-york/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 12:06:06+00:00

A pink diamond of "unparalleled color and brightness" is expected to fetch over $35 million when it goes on sale in New York, auction house Sotheby's announced Wednesday.

## Credit Suisse is still helping ultra-wealthy Americans evade taxes, Senate panel says
 - [https://www.cnn.com/2023/03/29/investing/credit-suisse-american-tax-evasion/index.html](https://www.cnn.com/2023/03/29/investing/credit-suisse-american-tax-evasion/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 11:30:49+00:00

Credit Suisse is complicit in ongoing tax evasion by ultra-wealthy Americans, including a potentially criminal conspiracy involving the failure to disclose nearly $100 million in secret offshore accounts held by a single family, a Senate investigation released Wednesday finds.

## Hear how this small island nation got wrapped up in the US-China power struggle
 - [https://www.cnn.com/videos/world/2023/03/29/exp-vanuatu-climate-change-coren-pkg-032801aseg1-cnni-world.cnn](https://www.cnn.com/videos/world/2023/03/29/exp-vanuatu-climate-change-coren-pkg-032801aseg1-cnni-world.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 11:27:21+00:00

Anna Coren looks at Vanuatu's fight against climate change as the small island nation is getting caught in the middle of the US-China power struggle.

## Ghana's president softens country's stance on draconian anti-LGBTQ bill as Kamala Harris visits
 - [https://www.cnn.com/2023/03/29/africa/ghana-softens-lgbtq-stance-intl/index.html](https://www.cnn.com/2023/03/29/africa/ghana-softens-lgbtq-stance-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 11:26:07+00:00

Ghana's President Nana Akufo-Addo has said that "substantial elements" of a draconian anti-LGBTQ bill being considered by its parliament "have been modified" after an intervention by his government.

## Inspired by his daughter after her autism diagnosis, soccer star James McClean reveals he too is autistic
 - [https://www.cnn.com/2023/03/29/football/james-mcclean-autism-diagnosis-intl-spt/index.html](https://www.cnn.com/2023/03/29/football/james-mcclean-autism-diagnosis-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 11:22:48+00:00

Footballer James McClean has disclosed he has been diagnosed with autism, saying he is sharing his "journey" in part for his daughter, who is also autistic.

## Enter player zero: NFL stars excited by jersey number rule change
 - [https://www.cnn.com/2023/03/29/sport/nfl-jersey-number-zero-change-spt-intl/index.html](https://www.cnn.com/2023/03/29/sport/nfl-jersey-number-zero-change-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 10:58:05+00:00

The No. 0 is a famous one in the NBA. Russell Westbrook, Damian Lillard and Jayson Tatum all wear jerseys emblazoned with a number which appears to give them a certain level of inevitability.

## Amsterdam asks 'wild' young male British tourists to 'stay away'
 - [https://www.cnn.com/travel/article/young-male-british-tourists-amsterdam-intl-scli/index.html](https://www.cnn.com/travel/article/young-male-british-tourists-amsterdam-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 10:49:15+00:00

Amsterdam is asking young British men to "stay away" if they plan to visit the city to cut loose and "go wild".

## 12-year-old in Milwaukee charged with killing a man to steal his guns. Police say a pizza receipt led to the arrest
 - [https://www.cnn.com/2023/03/29/us/milwaukee-12-year-old-homicide-charge/index.html](https://www.cnn.com/2023/03/29/us/milwaukee-12-year-old-homicide-charge/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 10:45:30+00:00

A 12-year-old boy in Milwaukee was charged with first-degree intentional homicide after being accused of killing a man to steal his guns, court records show.

## Body camera footage provides grueling blow-by-blow of final moments of Nashville school shooting as new details about shooter continue to emerge
 - [https://www.cnn.com/2023/03/29/us/nashville-tennessee-school-shooting-what-happened/index.html](https://www.cnn.com/2023/03/29/us/nashville-tennessee-school-shooting-what-happened/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 10:42:55+00:00

The woman standing outside Nashville's Covenant School was calm and direct. The building was locked down, but two young students were still missing.

## Biden and Netanyahu trade barbs over plan to weaken courts as Israel rejects 'pressure' from White House
 - [https://www.cnn.com/2023/03/29/middleeast/israel-biden-netanyahu-judicial-overhaul-dispute-intl/index.html](https://www.cnn.com/2023/03/29/middleeast/israel-biden-netanyahu-judicial-overhaul-dispute-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 10:22:50+00:00

Israel's embattled Prime Minister Benjamin Netanyahu escalated a rare public dispute with US President Joe Biden on Tuesday, rejecting "pressure" from the White House after Biden criticized his controversial efforts to weaken the Israeli judiciary.

## Ten photographs that made the world wake up to climate change
 - [https://www.cnn.com/collections/intl-climate-290323/](https://www.cnn.com/collections/intl-climate-290323/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 10:17:08+00:00



## Ron DeSantis is targeting the free speech protections that might save Fox News
 - [https://www.cnn.com/2023/03/29/politics/desantis-free-speech/index.html](https://www.cnn.com/2023/03/29/politics/desantis-free-speech/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 10:01:04+00:00

As Fox News faces legal peril over its coverage of Donald Trump's 2020 election lies, one of its most featured Republicans, Florida Gov. Ron DeSantis, is trying to gut the free speech protections that may ultimately save the network from financial ruin.

## Paul O'Grady, beloved British TV host and comedian, dead at 67
 - [https://www.cnn.com/2023/03/29/entertainment/paul-ogrady-dead-gbr-scli-intl/index.html](https://www.cnn.com/2023/03/29/entertainment/paul-ogrady-dead-gbr-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 09:53:57+00:00

Paul O'Grady, one of Britain's most popular TV personalities, has died aged 67.

## Spain shocked by Scotland in Euro 2024 qualifying
 - [https://www.cnn.com/2023/03/29/football/scotland-beat-spain-euro-2024-qualifiers-spt-intl/index.html](https://www.cnn.com/2023/03/29/football/scotland-beat-spain-euro-2024-qualifiers-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 09:47:24+00:00

Scotland secured a historic 2-0 victory over Spain on Tuesday thanks to two goals from Manchester United's Scott McTominay on a wild night at Hampden Park.

## She fell in love with a podcast host and flew across the world to meet her
 - [https://www.cnn.com/travel/article/chance-encounters-podcast-romance/index.html](https://www.cnn.com/travel/article/chance-encounters-podcast-romance/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 09:47:18+00:00

Jemma Gregory stumbled across Denise Warner's podcast more or less by chance.

## Canadian teenager smashes 400m freestyle swimming world record
 - [https://www.cnn.com/2023/03/29/sport/teenager-summer-mcintosh-breaks-world-record-intl-spt/index.html](https://www.cnn.com/2023/03/29/sport/teenager-summer-mcintosh-breaks-world-record-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 09:33:05+00:00

Teenage swimmer Summer McIntosh smashed the 400m freestyle world record, shaving more than three-tenths of a second off the previous mark at the Canadian National Trials at the Toronto Pan Am Sports Center.

## Eastern Ukraine has seen some of the heaviest fighting. See what's it like
 - [https://www.cnn.com/videos/world/2023/03/29/russia-shelling-aftermath-eastern-ukraine-wedeman-pkg-ovn-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2023/03/29/russia-shelling-aftermath-eastern-ukraine-wedeman-pkg-ovn-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 09:15:48+00:00

According to Ukrainian military officials, several zones in the eastern Donetsk and Luhansk regions have seen some of the heaviest fighting. CNN's Ben Wedeman spoke to civilians who remain in those regions, trying to pick up the pieces.

## Biden co-hosting the second Summit for Democracy
 - [https://www.cnn.com/2023/03/29/politics/biden-second-summit-for-democracy/index.html](https://www.cnn.com/2023/03/29/politics/biden-second-summit-for-democracy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 09:02:16+00:00

President Joe Biden is co-hosting the second Summit for Democracy on Wednesday, expanding on the diplomatic initiatives he established in 2021 to bolster democracies around the world in the face of autocracies' growing global influence.

## Lionel Messi passes 100 international goals with hat-trick against Curaçao
 - [https://www.cnn.com/2023/03/29/football/lionel-messi-argentina-100-goals-spt-intl/index.html](https://www.cnn.com/2023/03/29/football/lionel-messi-argentina-100-goals-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 08:57:24+00:00

Lionel Messi passed 100 international goals as he scored a hat-trick in Argentina's emphatic 7-0 win against Curaçao on Tuesday.

## King Charles III to travel to Germany for first overseas visit as monarch
 - [https://www.cnn.com/2023/03/29/europe/king-charles-germany-visit-intl/index.html](https://www.cnn.com/2023/03/29/europe/king-charles-germany-visit-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 08:47:49+00:00

King Charles III's first overseas state visit will finally get underway on Wednesday when the British monarch lands in Germany with the Queen Consort for a three-day trip.

## What should people know about the Marburg virus? Our medical analyst explains
 - [https://www.cnn.com/2023/03/29/health/marburg-ebola-virus-africa-health-wellness/index.html](https://www.cnn.com/2023/03/29/health/marburg-ebola-virus-africa-health-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 08:47:22+00:00

The West African country of Equatorial Guinea declared an outbreak of the Marburg virus disease in mid-February. There have been at least nine laboratory-confirmed cases, seven of which resulted in death, and 20 probable cases of dead individuals in this outbreak, according to the World Health Organization.

## 300 million jobs could be affected by latest wave of AI, says Goldman Sachs
 - [https://www.cnn.com/2023/03/29/tech/chatgpt-ai-automation-jobs-impact-intl-hnk/index.html](https://www.cnn.com/2023/03/29/tech/chatgpt-ai-automation-jobs-impact-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 08:45:38+00:00

As many as 300 million full-time jobs around the world could be automated in some way by the newest wave of artificial intelligence that has spawned platforms like ChatGPT, according to Goldman Sachs economists.

## Alibaba's restructuring and Jack Ma's homecoming are all part of China's plan
 - [https://www.cnn.com/2023/03/29/economy/alibaba-restructuring-china-big-tech-future-intl-hnk/index.html](https://www.cnn.com/2023/03/29/economy/alibaba-restructuring-china-big-tech-future-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 08:40:24+00:00

Alibaba's landmark restructuring has sent its shares soaring in New York and Hong Kong, as investors bet on the return of regulatory support for China's tech industry and private businesses after more than two years of a brutal crackdown.

## Ten photographs that made the world wake up to climate change
 - [https://www.cnn.com/2023/03/29/world/climate-change-photography-paul-nicklen-cristina-mittermeier-c2e-spc-intl-scn-climate/index.html](https://www.cnn.com/2023/03/29/world/climate-change-photography-paul-nicklen-cristina-mittermeier-c2e-spc-intl-scn-climate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 08:34:38+00:00

Water cascading from a wall of ice with gray brushstrokes of clouds overhead makes for a beautiful image -- but the story behind it is one of destruction; Earth's glaciers are melting at an unprecedented rate due to human-caused climate change.

## Russian conductor makes a comeback in China after he was fired for refusing to condemn the war
 - [https://www.cnn.com/2023/03/29/asia/valery-gergiev-russian-conductor-china-intl-hnk/index.html](https://www.cnn.com/2023/03/29/asia/valery-gergiev-russian-conductor-china-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 08:28:19+00:00

Valery Gergiev, the star Russian conductor fired in Germany last year for his refusal to condemn the invasion of Ukraine, was given a warm welcome in China this week as he started a three-day performance at the country's top art center.

## Swiss women launch landmark lawsuit in Europe claiming weak climate action breaches their human rights
 - [https://www.cnn.com/2023/03/29/europe/climate-lawsuit-switzerland-european-court-intl/index.html](https://www.cnn.com/2023/03/29/europe/climate-lawsuit-switzerland-european-court-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 08:12:25+00:00

A group of older Swiss women are taking their government to Europe's top human rights court, claiming its failure to act on the climate crisis is violating their human rights.

## Sands United: The soccer club that's tackling grief
 - [https://www.cnn.com/2023/03/29/football/sands-united-soccer-club-grief-spt-intl/index.html](https://www.cnn.com/2023/03/29/football/sands-united-soccer-club-grief-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 08:03:37+00:00

Sands United is a soccer club much like many others. They play on Sundays and they go through the motions of the sport -- the ups and the downs that fans of all teams are familiar with -- every weekend. They lace up their boots and seek out victories, then usually retire for a drink or two afterwards.

## A defiant Taiwanese President Tsai Ing-wen departs for New York to start Central American trip
 - [https://www.cnn.com/2023/03/29/asia/tsai-ing-wen-taiwan-president-us-stopover-central-america-trip-intl-hnk/index.html](https://www.cnn.com/2023/03/29/asia/tsai-ing-wen-taiwan-president-us-stopover-central-america-trip-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 06:42:17+00:00

Taiwan has every right to "connect with the world," its President Tsai Ing-wen declared Wednesday as she embarked on a diplomatic mission to Central America, which will include transit in the United States -- and has already been condemned by China.

## WHO experts revise Covid-19 vaccine advice, say healthy kids and teens low risk
 - [https://www.cnn.com/2023/03/29/health/who-updates-covid-vaccine-recommendations-intl-hnk/index.html](https://www.cnn.com/2023/03/29/health/who-updates-covid-vaccine-recommendations-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 06:22:41+00:00

The World Health Organization's vaccine experts have revised their global Covid-19 vaccination recommendations, and healthy kids and teenagers considered low priority may not need to get a shot.

## See Marines storm beach in US-South Korea amphibious assault drill
 - [https://www.cnn.com/videos/world/2023/03/29/south-korea-us-drill-hancocks-pkg-ovn-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2023/03/29/south-korea-us-drill-hancocks-pkg-ovn-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 06:09:37+00:00

Thousands of South Korean and US troops have been conducting large-scale joint military exercises, including offensive action drills. Meanwhile, North Korean state media claimed the country had simulated a tactical nuclear missile launch. CNN's Paula Hancocks has an exclusive look.

## Ukraine says it repelled 24 Russian attacks over last day
 - [https://www.cnn.com/europe/live-news/russia-ukraine-war-news-03-29-23/index.html](https://www.cnn.com/europe/live-news/russia-ukraine-war-news-03-29-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 05:59:47+00:00

• 'I don't want people to feel sorry for me. I just want them to understand us'
• Russian man whose daughter made anti-war painting sentenced to 2 years in prison

## Mountain lion claws man's head while he sits in hot tub, officials say
 - [https://www.cnn.com/2023/03/27/us/mountain-lion-colorado-hot-tub-attack-trnd/index.html](https://www.cnn.com/2023/03/27/us/mountain-lion-colorado-hot-tub-attack-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 05:21:59+00:00

A man was attacked by a mountain lion while relaxing in a hot tub at a rental property in Colorado, according to Colorado Parks and Wildlife.

## 'I don't want people to feel sorry for me. I just want them to understand us'
 - [https://cnn.it/3TPQtfA](https://cnn.it/3TPQtfA)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 05:20:28.802924+00:00



## Biden 'concerned' about Russia's plans to station tactical nuclear weapons in Belarus
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-03-29-23/index.html](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-03-29-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 05:20:28.795974+00:00



## Firefighting in Australia relies on this surprising group of people
 - [https://www.cnn.com/videos/world/2023/03/28/australia-rural-fire-service-contd-lon-orig.cnn](https://www.cnn.com/videos/world/2023/03/28/australia-rural-fire-service-contd-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 05:03:35+00:00

Wildfires in Australia can be devastating, destroying homes and habitats across the country. CNN meets two members of the volunteer fire service in New South Wales to hear why they risk their lives to help their community.

## Taliban arrests prominent girls' education activist as repressive clampdown continues
 - [https://www.cnn.com/2023/03/29/asia/afghanistan-education-activist-arrest-taliban-intl-hnk/index.html](https://www.cnn.com/2023/03/29/asia/afghanistan-education-activist-arrest-taliban-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 05:03:08+00:00

A prominent activist for girls' education in Afghanistan was arrested by the Taliban on Monday, according to an official, the latest step in its repressive clampdown on the rights of Afghan women.

## An influential Chinese blogger disappeared from the internet. This woman says she knows why
 - [https://www.cnn.com/2023/03/29/china/china-blogger-sentenced-program-think-intl-mic-hnk/index.html](https://www.cnn.com/2023/03/29/china/china-blogger-sentenced-program-think-intl-mic-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 04:17:46+00:00

For 12 years, Program Think, an anonymous Chinese blogger, mounted an open challenge to China's tightening authoritarian grip and expanding surveillance state.

## The shooter's parents didn't think Hale owned any weapons, having sold the only one they were aware of, police chief says
 - [https://www.cnn.com/2023/03/29/us/covenant-school-shooting-nashville-tennessee-wednesday/index.html](https://www.cnn.com/2023/03/29/us/covenant-school-shooting-nashville-tennessee-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 04:00:15+00:00

Timeline of key events | What we know about the shooter

## China's happiest city among top destinations worth visiting in 2023
 - [https://www.cnn.com/travel/article/china-lesser-known-destinations/index.html](https://www.cnn.com/travel/article/china-lesser-known-destinations/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 03:40:34+00:00

With China finally reopening to the world, it's time to dust off that travel wish list and start planning.

## 'Should Congress take any action on gun violence?' McCarthy responds with silence
 - [https://www.cnn.com/videos/politics/2023/03/29/gop-lawmakers-response-nashville-covenant-shooting-orig-zt.cnn](https://www.cnn.com/videos/politics/2023/03/29/gop-lawmakers-response-nashville-covenant-shooting-orig-zt.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 02:44:40+00:00

CNN asked Republican lawmakers what Washington should do in the wake of the shooting in Nashville that killed six people, including three children. This is what they said.

## Myanmar junta dissolves Suu Kyi's party as election deadline passes
 - [https://www.cnn.com/2023/03/28/asia/myanmar-suu-kyi-nld-dissolved-intl-hnk/index.html](https://www.cnn.com/2023/03/28/asia/myanmar-suu-kyi-nld-dissolved-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 02:40:46+00:00

Myanmar's military government has dissolved the ousted ruling party of former leader Aung San Suu Kyi and 39 other parties, state media announced on Tuesday, over their failure to register for an election set to prolong the army's grip on power.

## An Old Master's secret ingredient? Egg yolk, new study suggests
 - [https://www.cnn.com/style/article/old-masters-da-vinci-egg-yolk-painting-scn/index.html](https://www.cnn.com/style/article/old-masters-da-vinci-egg-yolk-painting-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 02:08:49+00:00

"Old Masters" such as Leonardo da Vinci, Sandro Botticelli and Rembrandt may have used proteins, especially egg yolk, in their oil paintings, according to a new study.

## As North Korea ramps up missile tests, US and South Korean troops practice assaulting a beach
 - [https://www.cnn.com/2023/03/28/asia/us-marines-south-korea-amphibious-landing-intl-hnk-ml/index.html](https://www.cnn.com/2023/03/28/asia/us-marines-south-korea-amphibious-landing-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 01:59:12+00:00

North Korea has been building up a ballistic missile arsenal on the stated premise that it needs to deter an attack on it by US and South Korean forces.

## Mother reacts to school banning Miley Cyrus, Dolly Parton's 'Rainbowland' from concert
 - [https://www.cnn.com/videos/us/2023/03/29/rainbowland-ban-miley-cyrus-dolly-parton-wisconsin-affil-dnt-contd-vpx.wdjt](https://www.cnn.com/videos/us/2023/03/29/rainbowland-ban-miley-cyrus-dolly-parton-wisconsin-affil-dnt-contd-vpx.wdjt)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-29 01:48:19+00:00

Parents and students at Heyer Elementary School in Waukesha, Wisconsin, say they are confused after school officials banned Miley Cyrus and Dolly Parton's 2017 duet "Rainbowland" from a first-grade concert. CNN affiliate WDJT reports.

