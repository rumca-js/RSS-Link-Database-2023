# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Alibaba: China tech giant shares jump after breakup plan announced
 - [https://www.bbc.co.uk/news/business-65107923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65107923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-03-29 04:04:05+00:00

The Chinese technology giant will embark on the biggest restructuring in its history.

