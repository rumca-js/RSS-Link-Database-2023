# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Surprise delay to Indonesia elections labelled unconstitutional
 - [https://www.aljazeera.com/news/2023/3/29/surprise-delay-to-indonesia-elections-labelled-unconstitutional](https://www.aljazeera.com/news/2023/3/29/surprise-delay-to-indonesia-elections-labelled-unconstitutional)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 23:41:06+00:00

A Jakarta court ruled that elections set for 2024 cannot take place until at least 2025 but the constitution disagrees.

## Starbucks ex-CEO jostles with Bernie Sanders over anti-union push
 - [https://www.aljazeera.com/news/2023/3/29/starbucks-ex-ceo-jostles-with-bernie-sanders-over-anti-union-push](https://www.aljazeera.com/news/2023/3/29/starbucks-ex-ceo-jostles-with-bernie-sanders-over-anti-union-push)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 23:11:03+00:00

The coffee chain has been accused of retaliating against workers involved in unionisation efforts.

## US urges China against ‘overreacting’ toTaiwan president transit
 - [https://www.aljazeera.com/news/2023/3/29/us-urges-china-against-overreacting-totaiwan-president-transit](https://www.aljazeera.com/news/2023/3/29/us-urges-china-against-overreacting-totaiwan-president-transit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 21:57:53+00:00

Taiwan&#039;s Tsai Ing-wen&#039;s stopover in the US is &#039;normal&#039; and consistent with longstanding US policy, White House says.

## Medieval Swahilis had African and Asian ancestry: DNA study
 - [https://www.aljazeera.com/news/2023/3/29/medieval-swahilis-had-african-and-asian-ancestry-dna-study](https://www.aljazeera.com/news/2023/3/29/medieval-swahilis-had-african-and-asian-ancestry-dna-study)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 21:02:10+00:00

Researchers say up to half of the DNA of people from Swahili areas was from Persia (90 percent) and India (10 percent).

## Who will hold human rights abusers in Libya to account?
 - [https://www.aljazeera.com/program/inside-story/2023/3/29/who-will-hold-human-rights-abusers-in-libya-to-account](https://www.aljazeera.com/program/inside-story/2023/3/29/who-will-hold-human-rights-abusers-in-libya-to-account)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 20:58:10+00:00

UN investigators say security forces and armed militia groups in Libya have committed a wide range of war crimes.

## Adidas to withdraw trademark complaint against Black Lives Matter
 - [https://www.aljazeera.com/news/2023/3/29/adidas-to-withdraw-trademark-complaint-against-black-lives-matter](https://www.aljazeera.com/news/2023/3/29/adidas-to-withdraw-trademark-complaint-against-black-lives-matter)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 20:42:20+00:00

The sportswear company has taken frequent legal action since 2008 to defend its exclusive use of the three-stripe logo.

## ‘Friends’: White House downplays Biden-Netanyahu public spat
 - [https://www.aljazeera.com/news/2023/3/29/friends-white-house-downplays-biden-netanyahu-public-spat](https://www.aljazeera.com/news/2023/3/29/friends-white-house-downplays-biden-netanyahu-public-spat)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 20:38:10+00:00

White House spokesman says &#039;there&#039;s a lot to like&#039; about Israeli PM statement rejecting US president&#039;s criticism.

## UAE leader designates his son Khaled as crown prince
 - [https://www.aljazeera.com/news/2023/3/29/uae-leader-designates-his-son-khaled-as-crown-prince](https://www.aljazeera.com/news/2023/3/29/uae-leader-designates-his-son-khaled-as-crown-prince)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 20:24:48+00:00

UAE president names son Sheikh Khaled as crown prince of Abu Dhabi, and three brothers to top roles.

## Pope Francis admitted to hospital with respiratory infection
 - [https://www.aljazeera.com/news/2023/3/29/pope-francis-hospitalised-for-respiratory-treatment](https://www.aljazeera.com/news/2023/3/29/pope-francis-hospitalised-for-respiratory-treatment)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 20:16:33+00:00

The pope has a respiratory infection that will require several days of appropriate treatment at Rome&#039;s Gemelli Hospital.

## UN votes to ask world court to rule on countries’ climate duties
 - [https://www.aljazeera.com/news/2023/3/29/un-votes-to-ask-world-court-to-rule-on-countries-climate-duties](https://www.aljazeera.com/news/2023/3/29/un-votes-to-ask-world-court-to-rule-on-countries-climate-duties)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 20:07:46+00:00

Call for International Court of Justice to offer legal opinion on climate crisis follows campaign led by island Vanuatu.

## ‘Critical first step’: US Senate votes to repeal Iraq war powers
 - [https://www.aljazeera.com/news/2023/3/29/critical-first-step-us-senate-votes-to-repeal-iraq-war-powers](https://www.aljazeera.com/news/2023/3/29/critical-first-step-us-senate-votes-to-repeal-iraq-war-powers)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 19:53:51+00:00

Advocates say the vote shows progress in efforts to reform legal architecture of the US&#039;s post-9/11 &#039;war on terror&#039;.

## Musk, other tech experts urge halt to further AI developments
 - [https://www.aljazeera.com/news/2023/3/29/musk-other-tech-experts-urge-halt-to-further-ai-developments](https://www.aljazeera.com/news/2023/3/29/musk-other-tech-experts-urge-halt-to-further-ai-developments)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 18:45:50+00:00

Over 1,000 tech leaders sign petition calling for pause of &#039;giant AI experiments&#039; in response to the release of GPT-4.

## Colombian rebels kill nine soldiers in blow to peace talks
 - [https://www.aljazeera.com/news/2023/3/29/colombian-rebels-kill-nine-soldiers-in-blow-to-peace-talks](https://www.aljazeera.com/news/2023/3/29/colombian-rebels-kill-nine-soldiers-in-blow-to-peace-talks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 18:10:33+00:00

Preliminary military assessment has identified the left-wing ELN as responsible for the attack in a northern province.

## ‘No impunity’ for migrant detention centre fire: Mexico president
 - [https://www.aljazeera.com/news/2023/3/29/no-impunity-for-migrant-detention-centre-fire-mexico-president](https://www.aljazeera.com/news/2023/3/29/no-impunity-for-migrant-detention-centre-fire-mexico-president)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 18:02:42+00:00

&#039;How is it possible that the Mexican authorities left human beings locked up with no way to escape?&#039; Amnesty Int&#039;l asks.

## Biden kicks off Summit for Democracy with $690m funding pledge
 - [https://www.aljazeera.com/news/2023/3/29/biden-kicks-off-summit-for-democracy-with-690m-funding-pledge](https://www.aljazeera.com/news/2023/3/29/biden-kicks-off-summit-for-democracy-with-690m-funding-pledge)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 17:51:04+00:00

NATO allies Turkey and Hungary not invited to the summit; Israeli PM Benjamin Netanyahu addresses the event.

## FIFA strips Indonesia of U-20 World Cup hosting rights
 - [https://www.aljazeera.com/news/2023/3/29/fifa-strips-indonesia-of-u-20-world-cup-hosting-rights](https://www.aljazeera.com/news/2023/3/29/fifa-strips-indonesia-of-u-20-world-cup-hosting-rights)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 17:35:06+00:00

FIFA has removed Indonesia as host after Bali refused to host Israel for tournament draw; new host to be announced soon.

## Saudi partners with China-led security bloc as ties grow
 - [https://www.aljazeera.com/news/2023/3/29/saudi-partners-with-china-led-security-bloc-as-ties-grow](https://www.aljazeera.com/news/2023/3/29/saudi-partners-with-china-led-security-bloc-as-ties-grow)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 17:15:27+00:00

Saudi cabinet approves decision at a meeting chaired by King Salman in a move that could grant Riyadh dialogue partner.

## US approves sale of overdose reversal drug without prescription
 - [https://www.aljazeera.com/news/2023/3/29/us-approves-sale-of-overdose-reversal-drug-without-prescription](https://www.aljazeera.com/news/2023/3/29/us-approves-sale-of-overdose-reversal-drug-without-prescription)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 17:07:10+00:00

The decision comes as a bid to widen access to the life-saving drug as the US struggles with a wave of overdose deaths.

## Iran’s FM: Is China the stabilising factor the Middle East needs?
 - [https://www.aljazeera.com/program/talk-to-al-jazeera/2023/3/29/irans-fm-is-china-the-stabilising-factor-the-middle-east-needs](https://www.aljazeera.com/program/talk-to-al-jazeera/2023/3/29/irans-fm-is-china-the-stabilising-factor-the-middle-east-needs)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 16:57:56+00:00

Iranian Foreign Minister Hossein Amirabdollahian discusses his county&#039;s eastern-focused foreign policy.

## Iran may set deadline for nuclear talks, says FM Amirabdollahian
 - [https://www.aljazeera.com/news/2023/3/29/iran-may-set-deadline-for-nuclear-talks-says-fm-amirabdollahian](https://www.aljazeera.com/news/2023/3/29/iran-may-set-deadline-for-nuclear-talks-says-fm-amirabdollahian)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 16:42:44+00:00

Iran&#039;s parliament could pass more legislation making government efforts at talks difficult, says the foreign minister.

## Senegal’s gold rush brings hope and despair
 - [https://www.aljazeera.com/gallery/2023/3/29/photos-senegal-gold-rush-brings-hope-and-despair](https://www.aljazeera.com/gallery/2023/3/29/photos-senegal-gold-rush-brings-hope-and-despair)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 16:13:18+00:00

Search for precious metal has dramatically transformed Bantakokouta, a Senegalese town near Mali and Guinea.

## We need decisive climate action, can COP28 deliver?
 - [https://www.aljazeera.com/opinions/2023/3/29/we-need-decisive-climate-action-can-cop28-deliver](https://www.aljazeera.com/opinions/2023/3/29/we-need-decisive-climate-action-can-cop28-deliver)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 16:12:36+00:00

Climate scientists are warning yet again that we are off target on climate action; COP28 in Dubai must change that.

## India announces birth of cheetah cubs 70 years after extinction
 - [https://www.aljazeera.com/news/2023/3/29/india-announces-birth-of-cheetah-cubs-70-years-after-extinction](https://www.aljazeera.com/news/2023/3/29/india-announces-birth-of-cheetah-cubs-70-years-after-extinction)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 16:10:47+00:00

Four cubs were born to one of the eight Namibian cheetahs that were relocated to India last year.

## King Charles visits Germany in first foreign visit as UK monarch
 - [https://www.aljazeera.com/news/2023/3/29/king-charles-visits-germany-in-first-foreign-visit-as-uk-monarch](https://www.aljazeera.com/news/2023/3/29/king-charles-visits-germany-in-first-foreign-visit-as-uk-monarch)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 15:34:01+00:00

Accompanied by Queen Consort Camilla, Charles III arrives in Berlin days after planned trip to France was cancelled.

## German government to deploy troops to Niger as part of EU mission
 - [https://www.aljazeera.com/news/2023/3/29/german-government-to-deploy-troops-to-niger-as-part-of-eu-mission](https://www.aljazeera.com/news/2023/3/29/german-government-to-deploy-troops-to-niger-as-part-of-eu-mission)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 15:23:30+00:00

The decision to deploy troops as part of an EU operation designed to support Niger&#039;s forces will be voted on in April.

## Russia’s war in Ukraine exacts heavy toll on women, says UNFPA
 - [https://www.aljazeera.com/news/2023/3/29/russias-war-in-ukraine-exacts-heavy-toll-on-women-says-unfpa](https://www.aljazeera.com/news/2023/3/29/russias-war-in-ukraine-exacts-heavy-toll-on-women-says-unfpa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 15:04:49+00:00

As war rages, health services for women are perilous and they are particularly vulnerable to many layers of abuse.

## Bangladesh journalist arrested after report on high food prices
 - [https://www.aljazeera.com/news/2023/3/29/bangladesh-journalist-arrested-after-report-on-high-food-prices](https://www.aljazeera.com/news/2023/3/29/bangladesh-journalist-arrested-after-report-on-high-food-prices)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 14:53:54+00:00

Shamsuzzaman Shams, a correspondent for Prothom Alo, detained under the controversial Digital Security Act.

## EU removes Pakistan from list of high-risk countries
 - [https://www.aljazeera.com/news/2023/3/29/eu-removes-pakistan-from-list-of-high-risk-countries](https://www.aljazeera.com/news/2023/3/29/eu-removes-pakistan-from-list-of-high-risk-countries)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 14:14:02+00:00

Government says move will ease cost and time of legal and financial transactions by Pakistani entities and individuals.

## Despite sanctions, EU keeps on doing business with Russia
 - [https://www.aljazeera.com/news/2023/3/29/despite-sanctions-eu-keeps-on-doing-business-with-russia](https://www.aljazeera.com/news/2023/3/29/despite-sanctions-eu-keeps-on-doing-business-with-russia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 13:38:26+00:00

Much trade still flows between the bloc&#039;s 27 countries and Russia, partly because some are unwilling to take a hit.

## Lesotho lawmakers to debate reclaiming parts of South Africa
 - [https://www.aljazeera.com/news/2023/3/29/lesotho-lawmakers-to-debate-reclaiming-parts-of-south-africa](https://www.aljazeera.com/news/2023/3/29/lesotho-lawmakers-to-debate-reclaiming-parts-of-south-africa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 13:01:46+00:00

The motion, based on a 1962 UN resolution, aims to &#039;return&#039; South Africa&#039;s entire Free State and four other regions.

## ‘The empire strikes back’: Brits laud diversity in UK politics
 - [https://www.aljazeera.com/news/2023/3/29/the-empire-strikes-back-brits-laud-diversity-in-uk-politics](https://www.aljazeera.com/news/2023/3/29/the-empire-strikes-back-brits-laud-diversity-in-uk-politics)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 13:01:08+00:00

This week marked a new era, with Humza Yousaf in charge at Holyrood as Rishi Sunak leads at Westminster.

## Israel urged to release Palestine prisoner diagnosed with cancer
 - [https://www.aljazeera.com/news/2023/3/29/israel-urged-to-release-palestine-prisoner-diagnosed-with-cancer](https://www.aljazeera.com/news/2023/3/29/israel-urged-to-release-palestine-prisoner-diagnosed-with-cancer)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 12:55:35+00:00

Palestinian rights group Addameer says Walid Daqqa&#039;s health is deteriorating, accusing Israel of neglect.

## For real climate justice, it’s time for a food revolution
 - [https://www.aljazeera.com/opinions/2023/3/29/for-real-climate-justice-its-time-for-a-food-revolution](https://www.aljazeera.com/opinions/2023/3/29/for-real-climate-justice-its-time-for-a-food-revolution)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 11:54:37+00:00

Climate finance and innovation need to focus on agriculture - now - if the planet is to withstand global warming.

## Freed ‘Hotel Rwanda’ hero heads to US for family reunion
 - [https://www.aljazeera.com/news/2023/3/29/freed-hotel-rwanda-hero-departs-doha-for-houston-for-family-reunion](https://www.aljazeera.com/news/2023/3/29/freed-hotel-rwanda-hero-departs-doha-for-houston-for-family-reunion)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 11:31:52+00:00

Rusesabagina was released last Friday. President Kagame commuted his sentence after months of negotiation with the US.

## US VP Harris says ‘history must be learned’ at Ghana slave castle
 - [https://www.aljazeera.com/news/2023/3/29/kamala-harris-visits-ghana-slave-castle-says-history-must-be-learned](https://www.aljazeera.com/news/2023/3/29/kamala-harris-visits-ghana-slave-castle-says-history-must-be-learned)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 11:09:14+00:00

Harris is on an African tour, part of a charm offensive by Washington to counterbalance the growing influence of China.

## Sri Lanka slashes fuel prices after IMF bailout, says minister
 - [https://www.aljazeera.com/news/2023/3/29/sri-lanka-slashes-fuel-prices-after-imf-bailout-says-minister](https://www.aljazeera.com/news/2023/3/29/sri-lanka-slashes-fuel-prices-after-imf-bailout-says-minister)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 10:47:30+00:00

Energy minister says different categories of petrol and diesel to be sold at 8 percent to 26 percent lower prices.

## See Me As I Am: A courageous journey with autism
 - [https://www.aljazeera.com/program/witness/2023/3/29/see-me-as-i-am-a-courageous-journey-with-autism](https://www.aljazeera.com/program/witness/2023/3/29/see-me-as-i-am-a-courageous-journey-with-autism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 10:29:29+00:00

A coming-of-age story about a teenage girl diagnosed with autism who tries to find her place in the world.

## Giant meatball from extinct mammoth DNA unveiled by food firm
 - [https://www.aljazeera.com/news/2023/3/29/giant-meatball-from-extinct-mammoth-dna-unveiled-by-food-firm](https://www.aljazeera.com/news/2023/3/29/giant-meatball-from-extinct-mammoth-dna-unveiled-by-food-firm)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 10:09:24+00:00

The meatball was made of sheep cells inserted with a singular mammoth gene called myoglobin.

## Mosul’s St Michael’s Monastery holds mass 20 years after invasion
 - [https://www.aljazeera.com/gallery/2023/3/29/mass-held-at-st-michaels-monastery-in-mosul-northern-iraq](https://www.aljazeera.com/gallery/2023/3/29/mass-held-at-st-michaels-monastery-in-mosul-northern-iraq)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 10:05:24+00:00

The Iraqi city&#039;s Christian community was driven out by an ISIL occupation and successive waves of violence.

## Why is Pakistan government trying to clip Supreme Court’s powers?
 - [https://www.aljazeera.com/news/2023/3/29/why-is-pakistan-government-trying-to-clip-supreme-courts-powers](https://www.aljazeera.com/news/2023/3/29/why-is-pakistan-government-trying-to-clip-supreme-courts-powers)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 09:37:10+00:00

Government tables bill in National Assembly as PM Shehbaz Sharif accuses top court of creating &#039;political instability&#039;.

## Deadly migrant centre fire in Ciudad Juarez, Mexico: What we know
 - [https://www.aljazeera.com/news/2023/3/29/deadly-migrant-centre-fire-in-ciudad-juarez-mexico](https://www.aljazeera.com/news/2023/3/29/deadly-migrant-centre-fire-in-ciudad-juarez-mexico)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 09:35:44+00:00

At least 38 people were killed after a fire broke out at a detention facility in Mexico near the US border.

## Capture of Bakhmut means Putin will ‘smell’ weakness: Ukraine
 - [https://www.aljazeera.com/news/2023/3/29/zelenskyy-warns-of-drawn-out-war-invites-chinas-xi-to-ukraine](https://www.aljazeera.com/news/2023/3/29/zelenskyy-warns-of-drawn-out-war-invites-chinas-xi-to-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 09:18:32+00:00

Russia&#039;s Putin would &#039;sell this victory to the West, to his society, to China&#039;, Ukraine&#039;s Zelenskyy warns.

## French prosecutors raid five banks in massive tax fraud case
 - [https://www.aljazeera.com/news/2023/3/29/french-prosecutors-raid-five-banks-in-massive-tax-fraud-case](https://www.aljazeera.com/news/2023/3/29/french-prosecutors-raid-five-banks-in-massive-tax-fraud-case)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 09:11:02+00:00

Authorities said banks including Societe Generale, BNP Paribas and HSBC, face a compensation request of more than $1bn.

## Peru president, ex-president probed for alleged money laundering
 - [https://www.aljazeera.com/news/2023/3/29/peru-president-ex-president-probed-for-alleged-money-laundering](https://www.aljazeera.com/news/2023/3/29/peru-president-ex-president-probed-for-alleged-money-laundering)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 08:44:56+00:00

Probe is part of continuing investigation into alleged campaign finance crimes committed during 2021 presidential race.

## ‘Historic’ climate cases against governments at European court
 - [https://www.aljazeera.com/news/2023/3/29/europe-rights-court-hears-climate-cases-against-governments](https://www.aljazeera.com/news/2023/3/29/europe-rights-court-hears-climate-cases-against-governments)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 08:36:40+00:00

Lawsuits have been brought against France and Switzerland over alleged failings to take action against climate change.

## Displaced twice: Gay Ugandans on the run face upheaval in Kenya
 - [https://www.aljazeera.com/features/2023/3/29/displaced-twice-ugandan-queers-on-the-run-face-upheaval-in-kenya](https://www.aljazeera.com/features/2023/3/29/displaced-twice-ugandan-queers-on-the-run-face-upheaval-in-kenya)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 08:18:46+00:00

Ugandans on the run from their country due to the persecution of sexual minorities face discrimination in Kenya, too.

## Spanish PM to talk Ukraine war and peace with China’s Xi Jinping
 - [https://www.aljazeera.com/news/2023/3/29/spanish-pm-to-talk-ukraine-war-and-peace-with-chinas-xi-jinping](https://www.aljazeera.com/news/2023/3/29/spanish-pm-to-talk-ukraine-war-and-peace-with-chinas-xi-jinping)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 08:07:34+00:00

Spain’s Prime Minister Pedro Sánchez arrives in Beijing for a meeting with Xi and talks that will also focus on Ukraine.

## Russia intensifies cyberattacks on Ukraine allies
 - [https://www.aljazeera.com/news/2023/3/29/russia-intensifies-cyberattacks-on-ukraine-allies](https://www.aljazeera.com/news/2023/3/29/russia-intensifies-cyberattacks-on-ukraine-allies)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 08:03:50+00:00

Russian &#039;hacktivists&#039; are hitting Poland and Nordic and Baltic countries with an arsenal of cyberweapons, analysts say.

## Relatives recall Mexico immigration centre fire that killed 38
 - [https://www.aljazeera.com/news/2023/3/29/38-dead-in-mexico-fire-after-guards-didnt-let-migrants-out](https://www.aljazeera.com/news/2023/3/29/38-dead-in-mexico-fire-after-guards-didnt-let-migrants-out)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 08:02:13+00:00

Authorities said they released 15 women but have not explained why no men were released.

## India’s warm weather plans exclude the most vulnerable: Report
 - [https://www.aljazeera.com/news/2023/3/29/indias-warm-weather-plans-exclude-the-most-vulnerable-report](https://www.aljazeera.com/news/2023/3/29/indias-warm-weather-plans-exclude-the-most-vulnerable-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 07:51:33+00:00

Delhi-based think tank points out lack of funding and preparation after studying 37 regional and federal action plans.

## Why Rahul Gandhi’s parliament expulsion could backfire on Modi
 - [https://www.aljazeera.com/opinions/2023/3/29/why-rahul-gandhis-parliament-expulsion-could-backfire-on-modi](https://www.aljazeera.com/opinions/2023/3/29/why-rahul-gandhis-parliament-expulsion-could-backfire-on-modi)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 07:33:55+00:00

It has united India&#039;s opposition for the first time since Modi came to power. Gandhi must now unite the nation.

## Is Israel’s far-right government jeopardising Emirati ties?
 - [https://www.aljazeera.com/news/2023/3/29/hold-is-israels-far-right-government-jeopardizing-emirati-ties](https://www.aljazeera.com/news/2023/3/29/hold-is-israels-far-right-government-jeopardizing-emirati-ties)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 07:19:34+00:00

Israeli escalation with Palestinians caused tension between Israel and the UAE, but core relations are intact: Analysts.

## Ramadan 2023: Where do your dates come from?
 - [https://www.aljazeera.com/news/2023/3/29/ramadan-2023-where-do-your-dates-come-from](https://www.aljazeera.com/news/2023/3/29/ramadan-2023-where-do-your-dates-come-from)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 07:19:33+00:00

Egypt, Saudi Arabia and Iran produce half of the world’s dates.

## Lionel Messi scores his 100th goal for Argentina
 - [https://www.aljazeera.com/sports/2023/3/29/messi-reaches-century-of-goals-for-argentina](https://www.aljazeera.com/sports/2023/3/29/messi-reaches-century-of-goals-for-argentina)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 06:57:58+00:00

The Albiceleste captain, his country&#039;s all-time record goalscorer, netted a hat-trick in a 7-0 win against Curacao.

## Tibet dying a ‘slow death’ under Chinese rule, says exiled leader
 - [https://www.aljazeera.com/news/2023/3/29/tibet-dying-a-slow-death-under-chinese-rule-says-exiled-leader](https://www.aljazeera.com/news/2023/3/29/tibet-dying-a-slow-death-under-chinese-rule-says-exiled-leader)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 06:29:08+00:00

Exiled Tibetan leader addresses US Congress for first time, says Tibet&#039;s language, culture and religion facing erasure.

## How a single mum manages a household of nine on $100 a week
 - [https://www.aljazeera.com/features/longform/2023/3/29/how-a-single-mum-manages-a-household-of-nine-on-100-a-week](https://www.aljazeera.com/features/longform/2023/3/29/how-a-single-mum-manages-a-household-of-nine-on-100-a-week)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 06:26:31+00:00

In South Africa, a hairdresser&#039;s assistant supports many family members including her elderly mom and drug addict son.

## Alibaba breakup bid raises hopes of end to China’s tech crackdown
 - [https://www.aljazeera.com/economy/2023/3/29/alibaba-breakup-bid-raises-hopes-of-end-to-chinas-tech-crackdown](https://www.aljazeera.com/economy/2023/3/29/alibaba-breakup-bid-raises-hopes-of-end-to-chinas-tech-crackdown)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 05:12:37+00:00

Shares in top Chinese tech firms rise after Alibaba plan fuels hopes of letup in regulatory scrutiny of the sector.

## Ukraine Soviet-era famine recognised as ‘genocide’ by French MPs
 - [https://www.aljazeera.com/news/2023/3/29/french-mps-recognise-ukraine-soviet-era-famine-as-genocide](https://www.aljazeera.com/news/2023/3/29/french-mps-recognise-ukraine-soviet-era-famine-as-genocide)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 05:08:39+00:00

The 1930s starvation of millions in Ukraine under Soviet leader Stalin is considered an act of genocide by Ukrainians.

## UN considers role of Int’l Court of Justice in climate change
 - [https://www.aljazeera.com/news/2023/3/29/un-to-considers-role-for-intl-court-of-justice-in-climate-change](https://www.aljazeera.com/news/2023/3/29/un-to-considers-role-for-intl-court-of-justice-in-climate-change)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 05:03:13+00:00

Pacific island state Vanuatu - one of the world&#039;s most vulnerable to climate change - has led the UN initiative.

## China vows to ‘fight back’ if US speaker meets Taiwan’s president
 - [https://www.aljazeera.com/news/2023/3/29/china-vows-to-fight-back-if-us-speaker-meets-taiwans-president](https://www.aljazeera.com/news/2023/3/29/china-vows-to-fight-back-if-us-speaker-meets-taiwans-president)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 04:20:21+00:00

Taiwanese President Tsai Ing-wen is expected to meet US House Speaker Kevin McCarthy in California next month.

## Russia starts Yars intercontinental ballistic missile drills
 - [https://www.aljazeera.com/news/2023/3/29/russia-starts-yars-intercontinental-ballistic-missiles-drills](https://www.aljazeera.com/news/2023/3/29/russia-starts-yars-intercontinental-ballistic-missiles-drills)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 04:01:29+00:00

The Yars mobile ICBM system has a reported range of 12,000 km (7,500 miles) and can carry multiple nuclear warheads.

## JPMorgan CEO Jamie Dimon to be deposed in Epstein case
 - [https://www.aljazeera.com/economy/2023/3/29/jpmorgan-ceo-jamie-dimon-to-be-deposed-in-epstein-case](https://www.aljazeera.com/economy/2023/3/29/jpmorgan-ceo-jamie-dimon-to-be-deposed-in-epstein-case)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 03:47:10+00:00

Dimon will be interviewed in a case where women are suing the US bank for allegedly enabling Epstein&#039;s sex trafficking.

## What will the future of AI-powered disinformation look like?
 - [https://www.aljazeera.com/program/the-stream/2023/3/29/what-will-the-future-of-ai-powered-disinformation-look-like](https://www.aljazeera.com/program/the-stream/2023/3/29/what-will-the-future-of-ai-powered-disinformation-look-like)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 03:39:07+00:00

Advancements in generative AI are threatening our ability to distinguish fact from fiction.

## US stops sharing nuclear arms data with Russia under START Treaty
 - [https://www.aljazeera.com/news/2023/3/29/us-stops-sharing-nuclear-arms-data-with-russia-under-start-treaty](https://www.aljazeera.com/news/2023/3/29/us-stops-sharing-nuclear-arms-data-with-russia-under-start-treaty)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 03:29:56+00:00

Under terms of the New START treaty, both countries should share data on deployed nuclear warheads on a biannual basis.

## Russia-Ukraine war: List of key events, day 399
 - [https://www.aljazeera.com/news/2023/3/29/russia-ukraine-war-list-of-key-events-day-399](https://www.aljazeera.com/news/2023/3/29/russia-ukraine-war-list-of-key-events-day-399)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 02:44:22+00:00

As the Russia-Ukraine war enters its 399th day, we take a look at the main developments.

## US sanctions Chinese firms over alleged repression of Uighurs
 - [https://www.aljazeera.com/economy/2023/3/29/us-sanctions-chinese-firms-over-alleged-abuses-of-uyghurs](https://www.aljazeera.com/economy/2023/3/29/us-sanctions-chinese-firms-over-alleged-abuses-of-uyghurs)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 01:51:58+00:00

Commerce Department says companies are implicated in Beijing&#039;s &#039;campaign of repression&#039; against ethnic minority Muslims.

## US President Biden, Israel PM Netanyahu trade words over protests
 - [https://www.aljazeera.com/news/2023/3/29/us-president-biden-israel-pm-netanyahu-trade-words-over-protests](https://www.aljazeera.com/news/2023/3/29/us-president-biden-israel-pm-netanyahu-trade-words-over-protests)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-29 01:41:34+00:00

Biden tells Israel to &#039;walk away&#039; from judicial reforms, Netanyahu responds saying he rejected &#039;pressure from abroad&#039;.

