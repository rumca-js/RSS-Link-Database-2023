# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Rosja: Słowa niewygodne dla Kremla w telewizji. Gość wyliczył, o ile Zachód jest silniejszy
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/rosja-slowa-niewygodne-dla-kremla-w-telewizji-gosc-wyliczyl-o-ile-zachod-jest-silniejszy/](https://www.polsatnews.pl/wiadomosc/2023-03-29/rosja-slowa-niewygodne-dla-kremla-w-telewizji-gosc-wyliczyl-o-ile-zachod-jest-silniejszy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 19:04:00+00:00

On każe się poddać! - grzmiał ekspert zaproszony do rosyjskiej telewizji, gdy usłyszał, że jego współrozmówca Borys Nadieżdin obnaża kłamstwa Kremla i rozkłada je na części pierwsze. Opozycjonista wyliczał, ile środków na obronę ma Rosja, a czym dysponują Stany Zjednoczone. - Nie wierzcie w memy rozpowszechniane przez Bidena - apelował z kolei deputowany do Dumy. W studiu wybuchła kłótnia.

## Brazylia: Kobieta żywcem pogrzebana w grobie. "To zemsta"
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/brazylia-kobieta-zywcem-pogrzebana-w-grobie-to-zemsta/](https://www.polsatnews.pl/wiadomosc/2023-03-29/brazylia-kobieta-zywcem-pogrzebana-w-grobie-to-zemsta/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 16:39:00+00:00

Brazylijscy funkcjonariusze policji uratowali kobietę, która została pochowana żywcem na cmentarzu w mieście Visconde do Rio Branco. Jak donoszą tamtejsze media, 36-latka przeżyła pomimo zamurowanego grobu.

## Wielka Brytania: Ciało 23-latki w piwnicy Jemeńczyka. Kuriozalne tłumaczenia podejrzanego
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/wielka-brytania-cialo-23-latki-w-piwnicy-jemenczyka-kuriozalne-tlumaczenia-podejrzanego/](https://www.polsatnews.pl/wiadomosc/2023-03-29/wielka-brytania-cialo-23-latki-w-piwnicy-jemenczyka-kuriozalne-tlumaczenia-podejrzanego/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 15:39:00+00:00

Farouk Abdulhak, syn jemeńskiego bogacza, jest zamieszany w zabójstwo 23-letniej Norweżki w Londynie. Ktoś najpierw ją zgwałcił, a później udusił. Mężczyzna uciekł do swojego kraju i wykorzystuje rodzinne wpływy, by nie stanąć przed brytyjskim wymiarem sprawiedliwości. BBC przekazał, że na Wyspach jest za zimno, by wrócić, a kobieta nie żyje, bo doszło do wypadku podczas stosunku seksualnego.

## Papież Franciszek w szpitalu. Watykan: Ma przejść badania
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/papiez-franciszek-w-szpitalu-watykan-ma-przejsc-badania/](https://www.polsatnews.pl/wiadomosc/2023-03-29/papiez-franciszek-w-szpitalu-watykan-ma-przejsc-badania/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 15:34:00+00:00

Papież Franciszek przebywa obecnie w szpitalu w Rzymie. Tam ma przejść zaplanowane wcześniej badania - informuje rzecznik prasowy Watykanu Matteo Bruni.

## Daniel Walter Chorzempa nie żyje. Muzyk polskiego pochodzenia zmarł samotnie we Włoszech
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/daniel-walter-chorzempa-nie-zyje-muzyk-polskiego-pochodzenia-zmarl-samotnie-we-wloszech/](https://www.polsatnews.pl/wiadomosc/2023-03-29/daniel-walter-chorzempa-nie-zyje-muzyk-polskiego-pochodzenia-zmarl-samotnie-we-wloszech/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 13:55:00+00:00

Nie żyje muzyk Daniel Walter Chorzempa. Muzyk polskiego pochodzenia zmarł samotnie we Włoszech. Był rzadko spotykanym talentem. Niewielu było na świecie takich jak on - wspomina muzyka włoska prasa.

## USA. Ma 23 lata i wychowuje 17-latkę. Skarży się, że nauczyciele nie traktują jej poważnie
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/usa-ma-23-lata-i-wychowuje-17-latke-skarzy-sie-ze-nauczyciele-nie-traktuja-jej-powaznie/](https://www.polsatnews.pl/wiadomosc/2023-03-29/usa-ma-23-lata-i-wychowuje-17-latke-skarzy-sie-ze-nauczyciele-nie-traktuja-jej-powaznie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 12:35:00+00:00

Mieszkająca w Kentucky (USA) Hunter Nelson dwa lata temu przyznała się na TikToku, że wychowuje 15-letnią dziewczynkę. Nie byłoby w tym nic dziwnego, gdyby nie fakt, że autorka nagrania jest zaledwie o sześć lat starsza od swojej córki. Młoda kobieta przyznaje, że musiała podjąć w życiu kilka trudnych decyzji, a mimo to wciąż podczas niektórych sytuacji nie jest traktowana poważnie.

## Rosja. Deputowany potrącił dziecko i odjechał. Dostał kilka miesięcy prac społecznych
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/rosja-deputowany-potracil-dziecko-i-odjechal-dostal-kilka-miesiecy-prac-spolecznych/](https://www.polsatnews.pl/wiadomosc/2023-03-29/rosja-deputowany-potracil-dziecko-i-odjechal-dostal-kilka-miesiecy-prac-spolecznych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 12:22:00+00:00

Poseł Jednej Rosji, Siergiej Mamontow, potrącił samochodem sześcioletnie dziecko i odjechał. Polityk został skazany na 10 miesięcy prac społecznych. Mamontow zrzekł się mandatu i został wyrzucony z partii. Chłopiec, który został ranny w wyniku potrącenia, przeżył.

## Hiszpania: Akcja zatrzymania Polaka w Alicante. Czterech policjantów zostało rannych
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/hiszpania-akcja-zatrzymania-polaka-w-alicante-czterech-policjantow-zostalo-rannych/](https://www.polsatnews.pl/wiadomosc/2023-03-29/hiszpania-akcja-zatrzymania-polaka-w-alicante-czterech-policjantow-zostalo-rannych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 12:14:00+00:00

Czterech funkcjonariuszy hiszpańskiej Gwardii Cywilnej zostało rannych podczas operacji antynarkotykowej w prowincji Alicante (Hiszpania). Do mundurowych, którzy próbowali zatrzymać podejrzanego Polaka, zaczął strzelać jego ojciec. Mężczyźni zostali zatrzymani.

## Ambasador Rosji grozi Szwecji i Finlandii. "Staną się celem rosyjskich działań militarnych"
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/ambasador-rosji-grozi-szwecji-i-finlandii-stana-sie-celem-rosyjskich-dzialan-militarnych/](https://www.polsatnews.pl/wiadomosc/2023-03-29/ambasador-rosji-grozi-szwecji-i-finlandii-stana-sie-celem-rosyjskich-dzialan-militarnych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 10:10:00+00:00

Szwedzkie MSZ wezwało rosyjskiego ambasadora Wiktora Tatarincewa. Ma to związek z artykułem dyplomaty o planach Szwecji i Finlandii w sprawie przystąpienia do NATO. Nowi członkowie wrogiego bloku staną się uzasadnionym celem rosyjskich działań odwetowych, w tym o charakterze militarnym - napisał. Przyjęte ustawy akcesyjne nazwał krokiem w przepaść.

## USA: 20-letniej kobiecie usunięto torbiel. Narośl ważyła prawie 50 kilogramów
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/usa-20-letniej-kobiecie-usunieto-torbiel-narosl-wazyla-prawie-50-kilogramow/](https://www.polsatnews.pl/wiadomosc/2023-03-29/usa-20-letniej-kobiecie-usunieto-torbiel-narosl-wazyla-prawie-50-kilogramow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 08:46:00+00:00

U 20-letniej Allison Fisher z Florydy przeprowadzono zabieg usunięcia torbieli jajnika. Zmiana osiągnęła wielkości piłki o średnicy 50 centymetrów - przekazały media. Kobieta powiedziała przed operacją, że czuje się jakby była w ciąży z dziesięciorgiem dzieci.

## Pepsi ma nowe logo. Poprzednie miało 15 lat
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/pepsi-zmienilo-kultowe-logo-poprzednie-mialo-15-lat/](https://www.polsatnews.pl/wiadomosc/2023-03-29/pepsi-zmienilo-kultowe-logo-poprzednie-mialo-15-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 07:51:00+00:00

Popularna marka napojów obchodząca w tym roku swoje 125-lecie postanowiła zmienić logo. Nowe zastąpi używany od 2008 roku napis pepsi obok kultowego, czerwono-niebieskiego globusu z białą falą pośrodku. Teraz nazwa znajdzie się wewnątrz znaku. Zmieni się także krój czcionki. To powrót do tożsamości wizualnej marki z lat 90-tych.

## Czeczenia. Ramzan Kadyrow pokazał synowi ciała zabitych. "Przestępcy zostają ukarani"
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/czeczenia-ramzan-kadyrow-pokazal-synowi-ciala-zabitych-przestepcy-zostaja-ukarani/](https://www.polsatnews.pl/wiadomosc/2023-03-29/czeczenia-ramzan-kadyrow-pokazal-synowi-ciala-zabitych-przestepcy-zostaja-ukarani/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 07:40:00+00:00

W Czeczenii nieznani napastnicy otworzyli ogień do posterunku policji. Dwóch z nich zostało zabitych. Po akcji na miejscu zdarzenia pojawił się Ramzan Kadyrow ze swoim 15-letnim synem. Pokazywał mu ciała zabitych i pochwalił pracę służb.

## Australijscy naukowcy wyhodowali mięso z mamuta włochatego i zrobili z niego klopsa
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/australijscy-naukowcy-wyhodowali-mieso-z-mamuta-wlochatego-i-zrobili-z-niego-klopsa/](https://www.polsatnews.pl/wiadomosc/2023-03-29/australijscy-naukowcy-wyhodowali-mieso-z-mamuta-wlochatego-i-zrobili-z-niego-klopsa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 07:00:00+00:00

Firma wskrzeszająca mięso z wymarłych gatunków stworzyła klopsa z mamuta, demonstrując w ten sposób potencjał tworzenia żywności bez uboju zwierząt - podaje Reuters. Mięsna kula została zaprezentowana w holenderskim muzeum nauki w Nemo.

## Włochy. "Nudziłem się w domu spokojnej starości". 80-latek musi zapłacić 4 tys. euro
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/wlochy-nudzilem-sie-w-domu-spokojnej-starosci-80-latek-musi-zaplacic-4-tys-euro/](https://www.polsatnews.pl/wiadomosc/2023-03-29/wlochy-nudzilem-sie-w-domu-spokojnej-starosci-80-latek-musi-zaplacic-4-tys-euro/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 05:03:00+00:00

Przez dwa lata jeździł autostradami nie płacąc za nie. 80-letni Włoch z domu spokojnej starości tłumaczył, że to nuda motywowała go do przejażdżek. Po tym jak został namierzony przez prokuraturę, zapewnił, że nie ma zamiaru pokryć kosztów swoich podróży.

## Meksyk. Pożar w ośrodku dla migrantów na północy kraju. Zginęło wiele osób
 - [https://www.polsatnews.pl/wiadomosc/2023-03-29/meksyk-pozar-w-osrodku-dla-migrantow-na-polnocy-kraju-zginelo-wiele-osob/](https://www.polsatnews.pl/wiadomosc/2023-03-29/meksyk-pozar-w-osrodku-dla-migrantow-na-polnocy-kraju-zginelo-wiele-osob/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-29 04:12:00+00:00

Co najmniej 38 osób zginęło w pożarze w centrum dla migrantów w meksykańskim mieście Ciudad Juarez. Ogień mieli wywołać osadzeni w ośrodku, którzy w ten sposób chcieli zaprotestować przeciwko planowanej deportacji. - Nie sądzili, że to spowoduje tak straszną tragedię - powiedział prezydent Meksyku Lopez Obrador.

