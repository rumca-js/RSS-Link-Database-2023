# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## John Wick Chapter 4 - A (Mostly) Excellent Finale
 - [https://www.youtube.com/watch?v=xiz3THVwMkk](https://www.youtube.com/watch?v=xiz3THVwMkk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-03-29 13:30:31+00:00

After a long wait, John Wick 4 is finally with us. But was it worth the wait, and is it a fitting swan song for one of the best action heroes in recent memory? Let's find out. 

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker

