# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Mocne wzrosty na Wall Street. Liderem zwyżek sektor technologiczny
 - [https://www.bankier.pl/wiadomosc/Mocne-wzrosty-na-Wall-Street-Liderem-zwyzek-sektor-technologiczny-8514266.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mocne-wzrosty-na-Wall-Street-Liderem-zwyzek-sektor-technologiczny-8514266.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 21:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/e7b73eee37ca6b-948-568-122-321-3488-2093.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Środowa sesja na Wall Street zakończyła się mocnymi wzrostami głównych indeksów. Liderami zwyżek były spółki technologiczne, ale drożały też regionalne i największe amerykańskie banki.</p>

## Rolnicy niezadowoleni ze spotkania z ministrem. Kołodziejczak zapowiada okupację Ministerstwa Rolnictwa
 - [https://www.bankier.pl/wiadomosc/Rolnicy-niezadowoleni-ze-spotkania-z-ministrem-Kolodziejczak-zapowiada-okupacje-Ministerstwa-Rolnictwa-8514251.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rolnicy-niezadowoleni-ze-spotkania-z-ministrem-Kolodziejczak-zapowiada-okupacje-Ministerstwa-Rolnictwa-8514251.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 20:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/c/d6cb3a5d3b4447-948-568-15-307-2032-1219.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jestem od tego żeby rozwiązywać problemy; w tym momencie moja dymisja byłaby ucieczką od problemów - powiedział w środę wicepremier i minister rolnictwa Henryk Kowalczyk. Zauważył, że obecnie kluczowa jest finansowa stymulacja eksportu zboża z Polski.</p>

## Polska jako jedyna przeciwna zakazowi rejestracji aut spalinowych. "Wszelkie ekoideologie z gruntu odrzucamy"
 - [https://www.bankier.pl/wiadomosc/Polska-jako-jedyna-przeciwna-zakazowi-rejestracji-aut-spalinowych-Wszelkie-ekoideologie-z-gruntu-odrzucamy-8514040.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-jako-jedyna-przeciwna-zakazowi-rejestracji-aut-spalinowych-Wszelkie-ekoideologie-z-gruntu-odrzucamy-8514040.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 19:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/b/7c4c4d7fce2aaa-948-568-33-0-4466-2679.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Odrzucamy zakaz produkcji samochodów spalinowych, niech społeczeństwa same stopniowo decydują, kto czym chce jeździć; polityka klimatyczna ma służyć społeczeństwu, nie odwrotnie - powiedział premier Mateusz Morawiecki, komentując przepisy przyjęte we wtorek przez Radę UE w ramach pakietu Fit for 55.</p>

## Oszukał sklep na 5 zł przy zakupie kanapki. Może trafić do więzienia
 - [https://www.bankier.pl/wiadomosc/Oszukal-sklep-na-5-zl-przy-zakupie-kanapki-Moze-trafic-do-wiezienia-8513659.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oszukal-sklep-na-5-zl-przy-zakupie-kanapki-Moze-trafic-do-wiezienia-8513659.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 16:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/1/c68bc7a8ed7ad7-948-568-0-50-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nawet 8 lat więzienia może grozić 17-latkowi, który w
 jednym z mieleckich sklepów nakleił na kanapkę z bagietki naklejkę 
"-50%" i zapłacił za nią o ponad 5 zł mniej, niż powinien. Policja 
przypomina, że przy przestępstwie doprowadzenia do niekorzystnego 
rozporządzenia mieniem wartość przedmiotu nie ma znaczenia.</p>

## Elon Musk i setki badaczy wzywają do pauzy w rozwoju AI
 - [https://www.bankier.pl/wiadomosc/Elon-Musk-i-setki-badaczy-wezwali-do-pauzy-w-rozwoju-AI-8514148.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Elon-Musk-i-setki-badaczy-wezwali-do-pauzy-w-rozwoju-AI-8514148.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 16:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/fbc0d73f688e43-808-485-120-0-808-485.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Setki biznesmenów, inwestorów i ekspertów od sztucznej inteligencji, w tym m.in. Elon Musk, wezwało we wspólnym liście do przynajmniej sześciomiesięcznej przerwy w rozwijaniu systemów AI zdolniejszych od opublikowanego w marcu GPT-4. Sygnatariusze ostrzegają przed nieprzewidywalnymi skutkami wyścigu o tworzenie coraz potężniejszych modeli.</p>

## Umowa z Orlenem i 30 proc. wzrost kursu. Wyniki zatrzęsły notowaniami popularnych spółek
 - [https://www.bankier.pl/wiadomosc/Umowa-z-Orlenem-i-30-proc-wzrost-kursu-Wyniki-zatrzesly-notowaniami-popularnych-spolek-8514123.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Umowa-z-Orlenem-i-30-proc-wzrost-kursu-Wyniki-zatrzesly-notowaniami-popularnych-spolek-8514123.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 16:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/9e9105ed16dc3a-945-567-337-71-1710-1026.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kluczowy indeks GPW znalazła się na zamknięciu powyżej psychologicznego 1700 pkt., które utracił tydzień temu. Powyżej 20 000 pkt jest sWIG80 co oznacza, że indeks wchodzi w strefę historycznych maksimów. Skala wzrostów na warszawskim parkiecie była jednak mniejsza niż na rynkach bazowych, a sporą zmienność wykazały się kursy spółek, które zaraportowały wyniki, albo podpisały intratną umowę z PKN Orlen.</p>

## Pożyczył 800 zł, musi oddać 143 tys. Interweniuje Prokurator Generalny
 - [https://www.bankier.pl/wiadomosc/Pozyczyl-800-zl-musi-oddac-143-tys-Interweniuje-Prokurator-Generalny-8513489.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pozyczyl-800-zl-musi-oddac-143-tys-Interweniuje-Prokurator-Generalny-8513489.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 16:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/11afb5efdf9238-948-568-0-280-4672-2803.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mężczyzna 20 lat temu zaciągnął kredyt na kwotę 800 zł. Zapożyczał się coraz bardziej, wpadając w spiralę długów. Ponieważ nie spłacał w terminie, zobowiązanie rosło. Po wyroku sądu dłużnik oddał już 41 tys. zł, ale pozostało mu do spłaty 102 tys. Uchylenia nakazu zapłaty w tej sprawie chce prokurator generalny Zbigniew Ziobro.</p>

## Inspekcja Pracy wejdzie do magazynów Amazona. Po interwencji posłanki Lewicy
 - [https://www.bankier.pl/wiadomosc/Inspekcja-Pracy-wejdzie-do-magazynow-Amazona-Po-interwencji-poslanki-Lewicy-8513867.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inspekcja-Pracy-wejdzie-do-magazynow-Amazona-Po-interwencji-poslanki-Lewicy-8513867.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 14:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/2/4ea3d211b3eeef-945-560-18-112-1481-888.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Państwowa Inspekcja Pracy przeprowadzi kontrole w magazynach Amazona. To reakcja na doniesienia Onetu i późniejszy wniosek posłanki Lewicy Agnieszki Dziemianowicz-Bąk ws. skandalicznego traktowania jednej ze zwalnianych pracownic.
</p>

## BGK: RPP obniży stopy w listopadzie
 - [https://www.bankier.pl/wiadomosc/BGK-RPP-obnizy-stopy-w-listopadzie-8514019.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/BGK-RPP-obnizy-stopy-w-listopadzie-8514019.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 14:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/7a752f3f50105f-948-568-0-249-3696-2217.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />RPP obniży stopę referencyjną o 50 pb. w listopadzie i będzie to początek cyklu redukcji stóp procentowych w Polsce - prognozują ekonomiści BGK. Ich zdaniem, w 2024 r. Rada zetnie stopy o kolejne 150 pb., w efekcie czego na koniec przyszłego roku stopa referencyjna wyniesie 4,75 proc.</p>

## PiS przegrał głosowanie ws. kontrowersyjnej ustawy
 - [https://www.bankier.pl/wiadomosc/PiS-przegral-glosowanie-ws-kontrowersyjnej-ustawy-8513982.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PiS-przegral-glosowanie-ws-kontrowersyjnej-ustawy-8513982.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 13:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/eea9735c666f3f-945-560-22-116-1475-884.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jedyną intencją jest to, aby istotna dla obywateli informacja mogła docierać jak najszybciej, wszędzie - powiedział premier Mateusz Morawiecki pytany o projekt ustaw Prawo komunikacji elektronicznej oraz Przepisy wprowadzające tę ustawę.</p>

## Budowa domu powyżej 70 mkw. tylko na podstawie zgłoszenia. Kolejny krok w deregulacji prawa budowlanego
 - [https://www.bankier.pl/wiadomosc/Budowa-domu-powyzej-70-mkw-tylko-na-podstawie-zgloszenia-8513973.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Budowa-domu-powyzej-70-mkw-tylko-na-podstawie-zgloszenia-8513973.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 13:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/9c0f0cc455e7ad-948-568-24-74-1954-1172.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Budowa jednorodzinnych budynków mieszkalnych o powierzchni zabudowy powyżej i poniżej 70 m kw., będzie możliwa na podstawie jedynie zgłoszenia - zaznaczył minister rozwoju i technologii Waldemar Buda. Jego zdaniem to kolejny krok w deregulacji prawa budowlanego.</p>

## 2 mld zł na inwestycje w rozbudowę zdolności produkcji amunicji artyleryjskiej
 - [https://www.bankier.pl/wiadomosc/2-mld-zl-na-inwestycje-w-rozbudowe-zdolnosci-produkcji-amunicji-artyleryjskiej-8513957.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/2-mld-zl-na-inwestycje-w-rozbudowe-zdolnosci-produkcji-amunicji-artyleryjskiej-8513957.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 13:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/69df213923b15a-945-567-0-0-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd przeznaczy 2 mld zł na inwestycje w rozbudowie zdolności produkcji amunicji artyleryjskiej - poinformował na konferencji prasowej premier Mateusz Morawiecki.</p>

## Rząd reaguje. Polska ograniczy wpływ ukraińskiego zboża do Polski
 - [https://www.bankier.pl/wiadomosc/Rzad-reaguje-Polska-ograniczy-wplyw-ukrainskiego-zboza-do-Polski-8513955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-reaguje-Polska-ograniczy-wplyw-ukrainskiego-zboza-do-Polski-8513955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 13:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/dcdf235ec853d7-948-568-0-0-4032-2419.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wypracowanie odpowiednich zasad, które będą pozwalały na ograniczenie napływu ukraińskiego zboża do Polski ma przygotować wicepremier i minister rolnictwa Henryk Kowalczyk - poinformował w środę premier Mateusz Morawiecki na konferencji po posiedzeniu Rady Ministrów.</p>

## Logopeda, masażysta, dietetyk zawodami regulowanymi. Rząd uregulował aż 17 profesji
 - [https://www.bankier.pl/wiadomosc/Logopeda-masazysta-dietetyk-zawodami-regulowanymi-Rzad-uregulowal-az-17-profesji-8513945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Logopeda-masazysta-dietetyk-zawodami-regulowanymi-Rzad-uregulowal-az-17-profesji-8513945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 13:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/9/a7caa9a79d359a-948-567-5-0-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd przyjął w środę projekt ustawy regulującej funkcjonowanie 17 zawodów medycznych. Zapisy mają gwarantować dopływ profesjonalistów ze specjalistycznym wykształceniem i zapewniać pacjentom wysoki standard – przekazał minister zdrowia Adam Niedzielski.</p>

## Rosjanie na Igrzyskach Olimpijskich? Decyzja "skandaliczna i szokująca"
 - [https://www.bankier.pl/wiadomosc/Rosjanie-na-Igrzyskach-Olimpijskich-Decyzja-skandaliczna-i-szokujaca-8513939.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosjanie-na-Igrzyskach-Olimpijskich-Decyzja-skandaliczna-i-szokujaca-8513939.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 12:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/3f1cb27c47002c-948-567-0-65-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Decyzja MKOl skandaliczna i szokująca. Nie ma naszej zgody na dopuszczenie Rosjan i Białorusinów do rywalizacji międzynarodowej i będziemy jasno wyrażali swój sprzeciw - powiedziała w środę PAP wiceminister sportu i turystyki Anna Krupka.</p>

## Prezes Aliora: Alior Pay nie podwyższy kosztów ryzyka banku
 - [https://www.bankier.pl/wiadomosc/Usluga-Alior-Pay-nie-podwyzszy-kosztow-ryzyka-Alior-Banku-prezes-8513929.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Usluga-Alior-Pay-nie-podwyzszy-kosztow-ryzyka-Alior-Banku-prezes-8513929.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 12:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/e/fab9b89f7c7088-948-568-0-163-2512-1507.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Około 20 proc. klientów płatności odroczonych Alior Pay korzysta z możliwości rozłożenia płatności na raty, usługa ta nie podwyższy kosztów ryzyka w segmencie kredytów konsumpcyjnych banku - poinformował prezes Alior Banku Grzegorz Olszewski.</p>

## Rząd likwiduje użytkowanie wieczyste. Kto przejmie grunty?
 - [https://www.bankier.pl/wiadomosc/Rzad-likwiduje-uzytkowanie-wieczyste-Kto-przejmie-grunty-8513916.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-likwiduje-uzytkowanie-wieczyste-Kto-przejmie-grunty-8513916.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 12:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/15a0e0876fd0c4-948-568-0-227-3491-2094.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Umożliwienie m.in. firmom, osobom fizycznym czy spółdzielniom mieszkaniowym uzyskania na własność gruntów, które mają w użytkowaniu wieczystym, umożliwia ustawa, której projekt przyjął rząd - wskazał w środę PAP minister rozwoju Waldemar Buda. Eliminujemy użytkowanie wieczyste w Polsce - dodał.</p>

## Zuchwała kradzież biżuterii wartej milion euro. Rusza śledztwo
 - [https://www.bankier.pl/wiadomosc/Zuchwala-kradziez-bizuterii-wartej-milion-euro-Rusza-sledztwo-8513866.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zuchwala-kradziez-bizuterii-wartej-milion-euro-Rusza-sledztwo-8513866.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 12:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/2d51194d48aac6-948-568-0-158-3340-2004.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gdańska prokuratura wszczęła śledztwo w sprawie kradzieży biżuterii wartej milion euro jednemu z wystawców tegorocznych targów biżuterii Amberif w Gdańsku. Klejnoty padły łupem złodzieja, który wybił szybę samochodu zaparkowanego w pobliżu jednej z restauracji w Sopocie.</p>

## 5 mln dzieci objętych 500+ na nowy okres
 - [https://www.bankier.pl/wiadomosc/5-mln-dzieci-objetych-500-na-nowy-okres-8513862.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/5-mln-dzieci-objetych-500-na-nowy-okres-8513862.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 12:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/d62758a70db495-948-568-10-0-3990-2393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rodzice i opiekunowie złożyli 3,1 mln wniosków o 500 plus na kolejny okres świadczeniowy, co objęło już 5 mln dzieci. Przyznano 93,1 proc. świadczeń – poinformowała w środę PAP prezes Zakładu Ubezpieczeń Społecznych prof. Gertruda Uścińska.</p>

## AI wywoła lawinę grupowych zwolnień. "300 mln osób bez pracy"
 - [https://www.bankier.pl/wiadomosc/AI-wywola-lawine-grupowych-zwolnien-300-mln-osob-bez-pracy-8513835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/AI-wywola-lawine-grupowych-zwolnien-300-mln-osob-bez-pracy-8513835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 12:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/4b22907bb20dc9-948-568-2-117-1019-611.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Goldman Sachs nie ma dobrych wiadomości dla osób zatrudnionych. Zdaniem analityków sztuczna inteligencja będzie odpowiadać za największe zwolnienia grupowe na świecie. Zagrożonych jest 300 mln pełnoetatowych stanowisk pracy. </p>

## Próba generalna na lotnisku w Radomiu. Lada dzień obsłuży pierwszych pasażerów
 - [https://www.bankier.pl/wiadomosc/Proba-generalna-na-lotnisku-w-Radomiu-Lada-dzien-obsluzy-pierwszych-pasazerow-8513853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Proba-generalna-na-lotnisku-w-Radomiu-Lada-dzien-obsluzy-pierwszych-pasazerow-8513853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 12:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/d347b9183c1cef-948-568-12-87-1188-712.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę na lotnisku w Radomiu rozpoczęły się testy pasażerskie. To próba generalna przed udostępnieniem portu podróżnym – poinformowała PAP rzeczniczka Przedsiębiorstwa Państwowego "Porty Lotnicze" Anna Dermont. Pierwsze loty z portu mają się odbyć w kwietniu.</p>

## Spóźnione wezwanie do zapłaty podatku od nieruchomości. Ile trzeba zapłacić?
 - [https://www.bankier.pl/wiadomosc/Spozniony-podatek-od-nieruchomosci-Ile-trzeba-zaplacic-8513844.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spozniony-podatek-od-nieruchomosci-Ile-trzeba-zaplacic-8513844.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 12:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/ae792f74bc479c-948-568-0-96-1675-1004.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skończył się czas na zapłatę pierwszej raty podatku od nieruchomości. Część podatników otrzymała wezwanie do uiszczenia daniny po terminie płatności. Spóźniony list z gminy zmienia końcową datę, w której należy uregulować podatek.</p>

## Kurs euro walczy z linią trendu. Frank poniżej 4,70 zł
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-walczy-z-linia-trendu-Frank-ponizej-4-70-zl-8513836.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-walczy-z-linia-trendu-Frank-ponizej-4-70-zl-8513836.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 11:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/a/606ce2b6e05e17-948-568-136-13-2536-1521.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Środowy poranek przyniósł kolejną próbę ataku kursu euro na
linię „covidowego” trendu wzrostowego. Jak dotąd wszystkie poprzednie
zakończyły się fiaskiem.</p>

## NBP: Stabilizacja na rynku mieszkaniowym. W IV kw. 2022 r. oddano do użytku rekordową liczbę lokali
 - [https://www.bankier.pl/wiadomosc/NBP-Stablilizacja-na-rynku-mieszkaniowym-W-IV-kw-2022-r-oddano-do-uzytku-rekordowa-liczbe-lokali-8513814.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-Stablilizacja-na-rynku-mieszkaniowym-W-IV-kw-2022-r-oddano-do-uzytku-rekordowa-liczbe-lokali-8513814.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 11:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/b/c833fbbe2c1e60-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ostatnim kwartale 2022 r. oddano do użytkowania w Polsce rekordowo wysoką liczbę 71,6 tys. mieszkań - poinformował w opublikowanym w środę raporcie Narodowy Bank Polski. Dodał, że to o blisko 24,3 proc. więcej niż w poprzednim kwartale.</p>

## Twitter Blue znów narobił bałaganu. Musk: Zapłać albo będziesz niewidoczny
 - [https://www.bankier.pl/wiadomosc/Twitter-Blue-znow-narobil-balaganu-Musk-Zaplac-albo-bedziesz-niewidoczny-8513530.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Twitter-Blue-znow-narobil-balaganu-Musk-Zaplac-albo-bedziesz-niewidoczny-8513530.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 11:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/b44418f48bc2ed-948-568-12-37-987-592.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Jeśli nie zapłacicie za Niebieski Znacznik, wasza strona nie pojawi się w propozycjach" - to nowy argument, jakiego używa Elon Musk, by zachęcić do zapłacenia mu 45 zł. To oznacza ponowne zamieszanie w algorytmach. I jak się to ma do jego krucjaty na rzecz wolności słowa.
</p>

## Enea rozpoczęła budowę farmy fotowoltaicznej Darżyno
 - [https://www.bankier.pl/wiadomosc/Enea-rozpoczela-budowe-farmy-fotowoltaicznej-Darzyno-8513812.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Enea-rozpoczela-budowe-farmy-fotowoltaicznej-Darzyno-8513812.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 11:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/1/88f3f155dd34a8-948-568-0-360-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Enea Nowa Energia, spółka w grupy Enei, rozpoczęła budowę farmy fotowoltaicznej Darżyno. Łączna moc PV wyniesie 2 MW - poinformowała Enea w komunikacie prasowym.</p>

## Tyrowicz (RPP): Nic w komunikacji NBP nie uzasadnia obniżek stóp proc. w 2023 roku
 - [https://www.bankier.pl/wiadomosc/Tyrowicz-RPP-Nic-w-komunikacji-NBP-nie-uzasadnia-obnizek-stop-proc-w-2023-roku-8513806.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tyrowicz-RPP-Nic-w-komunikacji-NBP-nie-uzasadnia-obnizek-stop-proc-w-2023-roku-8513806.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 11:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/a3bb0eb90d9b81-948-568-0-266-3942-2365.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trzeba być ostrożnym w interpretowaniu bieżących wycen rynkowych jako przemyślanego sygnału co do dalszych decyzji RPP, nic w komunikacji NBP nie uzasadnia obniżek stóp w '23, a spadające stopy rynkowe powinny skłonić RPP do podniesienia stóp NBP – ocenia w rozmowie z PAP Biznes członkini RPP Joanna Tyrowicz.</p>

## Getin Holding podtrzymuje, że docelowo chciałby sprzedać Idea Bank Ukraina
 - [https://www.bankier.pl/wiadomosc/Getin-Holding-podtrzymuje-ze-docelowo-chcialby-sprzedac-Idea-Bank-Ukraina-8513802.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Getin-Holding-podtrzymuje-ze-docelowo-chcialby-sprzedac-Idea-Bank-Ukraina-8513802.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 10:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/4e633b730290cc-948-568-13-56-1720-1032.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Decyzja Narodowego Bank Ukrainy o tymczasowym zawieszeniu wykonywania prawa głosu z akcji Idea Bank Ukraina nie zmienia strategii Getin Holding, która zakłada docelowo wyjście z tego rynku - poinformował w środę Getin.</p>

## Polski atom coraz bliżej. PEJ, Westinghouse i Bechtel podpiszą umowę jeszcze w tym roku
 - [https://www.bankier.pl/wiadomosc/Polski-atom-coraz-blizej-PEJ-Westinghouse-i-Bechtel-podpisza-umowe-jeszcze-w-tym-roku-8513783.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polski-atom-coraz-blizej-PEJ-Westinghouse-i-Bechtel-podpisza-umowe-jeszcze-w-tym-roku-8513783.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 10:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/7/c1a3074addaafb-948-567-0-55-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PEJ, Westinghouse i Bechtel jeszcze w tym roku podpiszą umowę na usługi inżynieryjne - podały Polskie Elektrownie Jądrowe w komunikacie.</p>

## Kolejny kraj w Europie zablokuje TikToka
 - [https://www.bankier.pl/wiadomosc/Estonia-tez-zablokuje-TikToka-8513773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Estonia-tez-zablokuje-TikToka-8513773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 10:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/fc08bffd9a44ab-948-568-0-81-2507-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Aplikacja TikTok zostanie zablokowana na wszystkich urządzeniach wydawanych urzędnikom przez państwo - zapowiedział cytowany w środę przez estońskie media Kristjan Jarvan, minister przedsiębiorczości i technologii Estonii.</p>

## Analityk: NABE może mieć mniejszy wpływ na kursy spółek, niż oczekiwano
 - [https://www.bankier.pl/wiadomosc/NABE-moze-miec-mniejszy-niz-oczekiwano-wplyw-na-kursy-spolek-trudno-prognozowac-wycene-aktywow-opinia-8513743.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NABE-moze-miec-mniejszy-niz-oczekiwano-wplyw-na-kursy-spolek-trudno-prognozowac-wycene-aktywow-opinia-8513743.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 10:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/5061953afdd6ac-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Proces utworzenia NABE jest na ostatniej prostej, ale nieznana jest nadal wartość przekazywanych wytwórczych aktywów węglowych. Kamil Kliszcz z BM mBanku wskazuje, że rynek zakłada wycenę na kilkanaście mld zł, choć trudno o wiarygodne oceny, gdy brakuje szczegółów np. co do przyszłych regulacji. Jego zdaniem NABE ostatecznie może mieć mniejszy, niż oczekiwano wpływ na notowania spółek energetycznych.</p>

## Deweloperzy nie widzą dobrych perspektyw w 2023 roku
 - [https://www.bankier.pl/wiadomosc/Deweloperzy-nie-widza-dobrych-perspektyw-w-2023-roku-8513720.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Deweloperzy-nie-widza-dobrych-perspektyw-w-2023-roku-8513720.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 09:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/2f5bd1ad624b41-948-568-0-0-1938-1162.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Deweloperzy badani przez NBP nie widzieli dobrych perspektyw dla rynku mieszkaniowego w 2023 roku - wynika z sondażu przeprowadzonego przez NBP w grudniu 2022 roku.</p>

## Lisner chce przejąć kontroli nad Greenwich, właścicielem spólki Graal
 - [https://www.bankier.pl/wiadomosc/Lisner-chce-przejac-kontroli-nad-Greenwich-wlascicielem-spolki-Graal-8513713.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lisner-chce-przejac-kontroli-nad-Greenwich-wlascicielem-spolki-Graal-8513713.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 09:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/d/29364dbde866f6-770-462-0-0-770-462.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lisner zgłosił zamiar przejęcia kontroli nad Greenwich, właścicielem spółki Graal oraz części mienia należącego do spólki Koral - podał UOKiK.</p>

## 1500+, czyli "babciowe". Tak Polacy oceniają pomysł Donalda Tuska
 - [https://www.bankier.pl/wiadomosc/1500-czyli-babciowe-Tak-Polacy-oceniaja-pomysl-Donalda-Tuska-8513711.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/1500-czyli-babciowe-Tak-Polacy-oceniaja-pomysl-Donalda-Tuska-8513711.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 09:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/8/02792186b27537-948-568-42-17-957-574.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />United Surveys w najnowszym sondażu przeprowadzonym na zlecenie Wirtualnej Polski zapytał Polaków, co sądzą o "babciowym", czyli 1500 zł dla kobiet chcących wrócić do pracy po urlopie macierzyńskim. 51,7 proc. badanych dobrze ocenia "babciowe", a 33,8 proc. nie podoba się pomysł nowego świadczenia.</p>

## Ekonomiści PKO BP podtrzymują prognozę wzrostu PKB Polski  w 2023
 - [https://www.bankier.pl/wiadomosc/Ekonomisci-PKO-BP-podtrzymuja-prognoze-wzrostu-PKB-Polski-w-2023-8513707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekonomisci-PKO-BP-podtrzymuja-prognoze-wzrostu-PKB-Polski-w-2023-8513707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 09:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/e099421801b11d-948-568-0-106-1855-1113.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ekonomiści PKO BP podtrzymują prognozę wzrostu PKB Polski w 2023 r. o 0,1 proc. - wynika z najnowszych prognoz i wypowiedzi ekonomistów banku.</p>

## Pepsi wprowadza nowe logo. W Polsce pojawi się za rok
 - [https://www.bankier.pl/wiadomosc/Pepsi-wprowadza-nowe-logo-8513682.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pepsi-wprowadza-nowe-logo-8513682.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 08:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/1094826c5a6c88-948-568-0-84-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pepsi po piętnastu latach zmieni logo widniejące na puszkach i butelkach. Rebranding rozpocznie się w Stanach Zjednoczonych i Kanadzie jesienią 2023 r. – informuje serwis cnn.com. W pozostałych krajach nowe logo zacznie obowiązywać w przyszłym roku.
</p>

## Asbis chce wypłacić dodtakową dywidendę na akcję za 2022 rok
 - [https://www.bankier.pl/wiadomosc/Asbis-chce-wyplacic-jeszcze-0-25-USD-dywidendy-na-akcje-za-22-8513646.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Asbis-chce-wyplacic-jeszcze-0-25-USD-dywidendy-na-akcje-za-22-8513646.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 08:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/b/909c2448edd2ee-945-560-0-0-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada dyrektorów Asbis Enterprises rekomenduje wypłatę dywidendy z zysku netto za 2022 r. w wysokości 0,25 USD na akcję - podała spółka w komunikacie. Całościowa dywidenda z zysku za 2022 r. może więc wynieść 0,45 USD na akcję, uwzględniając wypłaconą wcześniej zaliczkę.</p>

## Polska kupi kolejne radary przeciwlotnicze Bystra
 - [https://www.bankier.pl/wiadomosc/Modernizacja-polskiej-armii-trwa-Umowa-na-kolejne-radary-przeciwlotnicze-Bystra-8513627.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Modernizacja-polskiej-armii-trwa-Umowa-na-kolejne-radary-przeciwlotnicze-Bystra-8513627.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 08:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/282cd8e23b52bb-948-568-0-168-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szef MON Mariusz Błaszczak zatwierdził w środę umowę na dostawę kolejnych 22 mobilnych radarów przeciwlotniczych Bystra. "Budujemy zdolności przeciwlotnicze i przeciwrakietowe Wojska Polskiego, wzmacniamy je o kolejne warstwy" - podkreślił Błaszczak. Zamówienie zrealizują polskie zakłady, a jego wartość to 1 mld 100 mln zł.</p>

## Najbliższe miesiące przyniosą stabilizację bezrobocia
 - [https://www.bankier.pl/wiadomosc/Raport-na-najblizsze-miesiace-mozna-prognozowac-stabilizacje-bezrobocia-8513561.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Raport-na-najblizsze-miesiace-mozna-prognozowac-stabilizacje-bezrobocia-8513561.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/c114dfd9e4f036-948-567-0-20-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wskaźnik Rynku Pracy w marcu spadł w Polsce o 0,2 pkt. do 65,4 pkt., co jest bez znaczenia z punktu widzenia średniego okresu. Zdecydowanie można więc prognozować stabilizację wielkości bezrobocia na najbliższe miesiące – przekazało Biuro Inwestycji i Cykli Ekonomicznych.</p>

## Duży spadek zapasów ropy w USA winduje ceny surowca w górę
 - [https://www.bankier.pl/wiadomosc/Duzy-spadek-zapasow-ropy-w-USA-winduje-ceny-surowca-w-gore-8513533.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Duzy-spadek-zapasow-ropy-w-USA-winduje-ceny-surowca-w-gore-8513533.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 07:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/297e659c27e5bd-948-568-0-69-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną kolejny dzień. Tym razem przyczyną zwyżek notowań są informacje o dużym spadku amerykańskich zapasów ropy - informują maklerzy. W środę oficjalne dane o zapasach ropy w USA poda po 16.30 Departament Energii (DoE).</p>

## DM BOŚ obniżył wycenę akcji JSW, ale podtrzymuje "kupuj"
 - [https://www.bankier.pl/wiadomosc/DM-BOS-obnizyl-wycene-akcji-JSW-do-100-zl-podtrzymuje-kupuj-8513531.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/DM-BOS-obnizyl-wycene-akcji-JSW-do-100-zl-podtrzymuje-kupuj-8513531.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 07:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/a8ec395bbe6c7b-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Analitycy DM BOŚ, w raporcie z 21 marca, obniżyli wycenę akcji JSW w horyzoncie 12-miesięcznym do 100 zł ze 130 zł wcześniej. Rekomendacja "kupuj" została podtrzymana.</p>

## Drago entertainment skupi akcje własne
 - [https://www.bankier.pl/wiadomosc/Drago-entertainment-skupi-do-20-084-akcji-wlasnych-8513527.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drago-entertainment-skupi-do-20-084-akcji-wlasnych-8513527.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 07:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/d6c63375d2df1a-948-568-192-0-1521-912.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Drago entertainment rozpoczyna skup akcji, w ramach którego nabędzie do 20084 akcji, czyli nie więcej niż 1,85 proc. kapitału zakładowego, po cenie nie niższej niż 33 zł oraz nie wyższej niż 100 zł za papier - podała spółka w komunikacie.</p>

## Kotecki: Niewielka podwyżka stóp potwierdziłaby, że inflacja wciąż niepokoi RPP
 - [https://www.bankier.pl/wiadomosc/Kotecki-Niewielka-podwyzka-stop-potwierdzilaby-ze-inflacja-wciaz-niepokoi-RPP-8513508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kotecki-Niewielka-podwyzka-stop-potwierdzilaby-ze-inflacja-wciaz-niepokoi-RPP-8513508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 06:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/30022ee961c083-948-568-0-120-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nawet niewielka podwyżka stóp procentowych byłaby potwierdzeniem, że inflacja wciąż niepokoi Radę Polityki Pieniężnej - ocenił w wywiadzie dla Dziennika Gazety Prawnej członek RPP Ludwik Kotecki.</p>

## Były premier Kazimierz M. uchyla się od alimentów. Postępowanie przed sądem ruszy od nowa
 - [https://www.bankier.pl/wiadomosc/Byly-premier-Kazimierz-M-uchyla-sie-od-alimentow-Postepowanie-przed-sadem-ruszy-od-nowa-8513491.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Byly-premier-Kazimierz-M-uchyla-sie-od-alimentow-Postepowanie-przed-sadem-ruszy-od-nowa-8513491.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 06:02:00+00:00

<p>Postępowanie w sprawie byłego premiera Kazimierza M. dotyczące uchylania się od obowiązku alimentacyjnego będzie się toczyć przed sądem od nowa - dowiedziała się PAP. Sprzeciw od wyroku nakazowego złożył obrońca byłego premiera.</p>

## "Puste" faktury VAT na 1,5 mld złotych. Zatrzymano kolejne 10 osób
 - [https://www.bankier.pl/wiadomosc/Puste-faktury-VAT-na-1-5-mld-zlotych-Zatrzymano-kolejne-10-osob-8513488.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Puste-faktury-VAT-na-1-5-mld-zlotych-Zatrzymano-kolejne-10-osob-8513488.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 06:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/a/9242a82737599a-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W sprawie "pustych" faktur VAT na 1,5 mld złotych śledztwo ciągle trwa. Zatrzymano kolejne 10 osób, a do tej pory zarzuty usłyszało 310 osób, w tym 44-letni Robert C., który był na liście najbardziej poszukiwanych ludzi w Europie.</p>

## Fotowoltaika wciąż na fali wzrostowej rok po zmianie systemu rozliczeń. Jest jednak problem
 - [https://www.bankier.pl/wiadomosc/Fotowoltaika-wciaz-na-fali-wzrostowej-rok-po-zmianie-systemu-rozliczen-Jest-jednak-problem-8513485.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fotowoltaika-wciaz-na-fali-wzrostowej-rok-po-zmianie-systemu-rozliczen-Jest-jednak-problem-8513485.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 06:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/e/af97f2319a20d6-948-568-0-133-1982-1189.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W kwietniu br. minie rok, odkąd zmieniły się zasady rozliczania nowych prosumentów za energię z przydomowych instalacji fotowoltaicznych przekazywaną do sieci i z niej pobieraną. - Sytuacja cenowa i geopolityczna...</p>

## ZUS zakasał rękawy. Sprawdzi rzetelność odprowadzania składek w firmach
 - [https://www.bankier.pl/wiadomosc/ZUS-zakasal-rekawy-Sprawdzi-rzetelnosc-odprowadzania-skladek-w-firmach-8513479.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ZUS-zakasal-rekawy-Sprawdzi-rzetelnosc-odprowadzania-skladek-w-firmach-8513479.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/2852f27b4b4bd8-948-568-0-130-1689-1013.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />ZUS w tym roku zamierza prześwietlić 25 tys. firm pod kątem prawidłowo odprowadzanych składek. Sprawdzi m.in. umowy o dzieło.</p>

## Echo Investment jednak z zyskiem. Ale IV '22 kwartał nie należał do łatwych
 - [https://www.bankier.pl/wiadomosc/Wyniki-Echo-Investment-w-IV-kw-2022-roku-vs-konsensus-PAP-tabela-8513470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyniki-Echo-Investment-w-IV-kw-2022-roku-vs-konsensus-PAP-tabela-8513470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 05:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/8/ad1e0c11bb78f9-945-560-0-0-960-575.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poniżej przedstawiamy wyniki Echo Investment w czwartym kwartale 2022 roku, według wyliczeń PAP Biznes, oraz ich odniesienie do konsensusu i wyników poprzednich okresów.</p>

## Zwalniani pracownicy Volvo mają szansę na pracę
 - [https://www.bankier.pl/wiadomosc/Zwalniani-pracownicy-Volvo-maja-szanse-na-prace-w-Vargas-Holding-8513469.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zwalniani-pracownicy-Volvo-maja-szanse-na-prace-w-Vargas-Holding-8513469.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 05:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/6/2e08195ce9c16b-945-567-96-113-3368-2021.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W związku z zamknięciem produkcji autobusów we wrocławskim zakładzie Volvo Buses pracę straci około 1500 osób. Już wiadomo, że część zwalnianych osób znajdzie zatrudnienie w Vargas Holding, z którą Volvo podpisało porozumienie w tej sprawie.</p>

## SARON już blisko 1 proc. Frankowiczów czeka wzrost rat
 - [https://www.bankier.pl/wiadomosc/SARON-juz-blisko-1-proc-Frankowiczow-czeka-wzrost-rat-8513089.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/SARON-juz-blisko-1-proc-Frankowiczow-czeka-wzrost-rat-8513089.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/5/cd298305e53f85-948-568-190-825-1810-1085.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wskaźnik, od którego zależy oprocentowanie kredytów opartych na frankach szwajcarskich, znowu ruszył w górę. Jeszcze jesienią był bliski zera, w styczniu przekroczył granicę 0,5 proc. Teraz zbliża się do symbolicznego, najwyższego od 2008 r. poziomu.</p>

## Smutny akcjonariusz JSW. Wszędzie dobrze gdzie nas nie ma
 - [https://www.bankier.pl/wiadomosc/Smutny-akcjonariusz-JSW-Wszedzie-dobrze-gdzie-nas-nie-ma-8512978.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Smutny-akcjonariusz-JSW-Wszedzie-dobrze-gdzie-nas-nie-ma-8512978.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/98ad1f2a3e946e-945-560-0-469-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />JSW okazuje się prawdziwym ewenementem na skalę światową, ponieważ zaliczając najlepszy rok pod względem finansowym, nie zamierza dzielić się wypracowanym astronomicznym zyskiem z akcjonariuszami. Na węglowej hossie skorzystają pracownicy, Skarb Państwa, ale indywidualni długoterminowi inwestorzy już nie bardzo.</p>

## Tak dużo kart jeszcze nie mieliśmy. Padły kolejne rekordy
 - [https://www.bankier.pl/wiadomosc/Tak-duzo-kart-jeszcze-nie-mielismy-Padly-kolejne-rekordy-8512849.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-duzo-kart-jeszcze-nie-mielismy-Padly-kolejne-rekordy-8512849.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/55c8fd3d807205-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pobiliśmy nowy rekord w segmencie kart płatniczych. Na koniec 2022 roku mieliśmy ich w portfelach już 44,5 mln – podaje Narodowy Bank Polski. Mimo iż kartami wykonaliśmy w IV kwartale mniej transakcji, to ich ogólna wartość wzrosła. Ponownie przybyło terminali POS i ubyło bankomatów.</p>

## Wojna handlowa USA trwa. Sankcje wobec 5 chińskich firm
 - [https://www.bankier.pl/wiadomosc/Wojna-handlowa-USA-trwa-Sankcje-wobec-5-chinskich-firm-8513444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wojna-handlowa-USA-trwa-Sankcje-wobec-5-chinskich-firm-8513444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-29 00:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/226f0b043737a7-948-568-102-80-1557-934.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wojna handlowa pomiędzy USA i Chinami trwa. Waszyngton nałożył we wtorek nowe ograniczenia handlowe na pięć chińskich podmiotów za rzekomą pomoc w represjach Pekinu wobec muzułmańskiej grupy Ujgurów - przekazał Reuters.</p>

