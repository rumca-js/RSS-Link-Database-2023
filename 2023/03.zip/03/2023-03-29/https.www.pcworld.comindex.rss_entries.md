# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## Chrome is finally getting an official reading mode, but it’s weird
 - [https://www.pcworld.com/article/1676214/chrome-is-finally-getting-an-official-reader-mode-but-its-weird.html](https://www.pcworld.com/article/1676214/chrome-is-finally-getting-an-official-reader-mode-but-its-weird.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-29 19:26:15+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Among the most well-known browsers, Chrome&rsquo;s held out on offering a proper reader mode. Firefox, Edge, and others have long included an official way of displaying webpages as basic, easy-to-read text and and images, but not Chrome. Unless you were willing to dig into its flag settings to activate a hidden Reader Mode, you had to accept exactly what websites served you.</p>



<p>But with the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://blog.google/outreach-initiatives/education/chromebook-updates-2023/&amp;xcust=2-1-1676214-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">recent announcement of a forthcoming Reading Mode</a>, Chrome finally is joining the party. Well. Kind of. As you might have guessed from the wording, Reading Mode is not quite like other browsers&rsquo; Reader Mode.&nbsp;</p>



<p>This new feature is a customizable sidebar and part of Chrome&rsquo;s updates geared at education. Launching in version 114 for Chrome and ChromeOS, the sidebar loads a second copy of the open page that lets users strip away distracting elements. You can kill images and video as well as adjust other visual elements like typeface, font size and spacing, and the colors of the text and background.</p>



<figure class="wp-block-embed is-type-rich is-provider-embed-handler wp-block-embed-embed-handler"><div class="wp-block-embed__wrapper">
<div class="wp-video" style="width: 640px;"><!--[if lt IE 9]><script>document.createElement('video');</script><![endif]-->
<video class="wp-video-shortcode" controls="controls" height="360" id="video-1676214-1" preload="metadata" width="640"><source src="https://storage.googleapis.com/gweb-uniblog-publish-prod/original_videos/1980-GDU-Roadmap-ReadingMode-AV.mp4?_=1" type="video/mp4" /><a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://storage.googleapis.com/gweb-uniblog-publish-prod/original_videos/1980-GDU-Roadmap-ReadingMode-AV.mp4&amp;xcust=2-1-1676214-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">https://storage.googleapis.com/gweb-uniblog-publish-prod/original_videos/1980-GDU-Roadmap-ReadingMode-AV.mp4</a></video></div>
</div><figcaption>Google&rsquo;s video demonstration of how Reading Mode will work.</figcaption></figure>



<p>But unlike a traditional Reader mode, the sidebar does not spans the full width of a page, as it does in Edge or Firefox&rsquo;s reader modes. As an education tool, this difference may be more functional&mdash;reading from the pared down version of the page while still seeing its original form could help with processing the information&mdash;but for those seeking a simplified, more book-like experience, Reading Mode is still not quite the desired feature. In fact, this mode stems from Chrome&rsquo;s Read Anywhere mode, which first appeared last year, rather than the hidden Reader Mode. The latter, which launched in 2019, is still considered experimental. With the upcoming release of this new Reading Mode, it could remain in in purgatory for awhile longer (if not forever).</p>



<p>Reading Mode begins its rollout in Chrome 114 on <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://chromiumdash.appspot.com/schedule&amp;xcust=2-1-1676214-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">May 24, 2023</a>. In the meanwhile (or if it&rsquo;s just not what you wanted), you can enable Chrome&rsquo;s buried Reader Mode by typing <code>chrome://flags</code> into your browser, then searching for &ldquo;reader mode.&rdquo; On webpages compatible with Reader Mode, an open-book icon will appear to the right of Chrome&rsquo;s address bar.</p>

Internet</div>

## Cyberpunk 2077’s art director tells us why path tracing is no gimmick
 - [https://www.pcworld.com/article/1676116/cyberpunk-2077-art-director-tells-us-why-path-tracing-is-no-gimmick.html](https://www.pcworld.com/article/1676116/cyberpunk-2077-art-director-tells-us-why-path-tracing-is-no-gimmick.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-29 18:53:20+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>For all the ups and downs that have come and gone with <em>Cyberpunk 2077</em>, you can&rsquo;t deny that it&rsquo;s a beautiful game set in a stunning world. It&rsquo;s going to get a little more stunning soon, at least if your PC can handle it, <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://blogs.nvidia.com/blog/2023/03/22/cyberpunk-2077-path-traced-visuals-gdc/&amp;xcust=2-1-1676116-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">thanks to a planned path tracing update</a>. One of the artists responsible for Night City, CDProjekt Red&rsquo;s Jakub Knapik, told us all about it on the floor of the Game Developers Congress. Check it out in the latest PCWorld video. </p>



<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">

</div></figure>



<p>For the uninitiated, path tracing is <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://blogs.nvidia.com/blog/2023/03/22/cyberpunk-2077-path-traced-visuals-gdc/&amp;xcust=2-1-1676116-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">a more advanced version of ray tracing</a>, which has been something of a buzzword in high-end graphics for the last few years. Ray tracing is a physics-based model that calculates the way individual rays of light move through space and bounce off multiple objects, giving more realistic illumination and reflections. Path tracing, while technically a synonym for the same process, refers to a more processor-friendly way to optimize all of that math, collapsing multiple rays into a less processor-intensive idealized path. That said, it&rsquo;s also more resource-intensive in practice, as path tracing also requires accurately simulating <em>all</em> light sources in a game, rather than picking and choosing select lighting features (such as shadows and reflections) like you do with standard ray traced games. (<a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://blogs.nvidia.com/blog/2022/03/23/what-is-path-tracing/&amp;xcust=2-1-1676116-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">This Nvidia path tracing explainer</a> goes much, much deeper if you&rsquo;re interested in the nitty-gritty.) </p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="modern-geforce-gpus-offer-the-best-path-tracing-firepower">
					Modern geforce gpus offer the best path tracing firepower				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="geforce-rtx-4090-founders-edition">GeForce RTX 4090 Founders Edition</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="GeForce RTX 4090 Founders Edition" class="product-widget__image" height="1667" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Nvidia-GeForce-RTX-4090-1.jpg?quality=50&amp;strip=all" width="2500" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/1348123/nvidia-geforce-rtx-4090-review-ada-lovelace.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
											<div class="product-widget__information--rrp-wrapper">
								<span class="product-widget__information--rrp-label">
															</span>
								<span class="product-widget__information--rrp-value">
																</span>
							</div>
						
									</div>
			</div>
		</div>

		


<p>The current ray tracing in <em>Cyberpunk 2077</em> makes it a showcase of modern graphics tech, but when the path tracing technology preview comes out, it should look even better. You&rsquo;ll need a beastly graphics card to seize full advantage, no doubt, even with performance-boosting features like <a href="https://www.pcworld.com/article/1498499/cyberpunk-2077-levels-up-framwerates-with-nvidia-dlss-3.html">DLSS 3 Frame Generation active</a>.</p>



<p>The patch will be available on April 11th, as a free update to the PC version of <em>Cyberpunk 2077.</em> For more deep dives into the latest and greatest in PC gaming, be sure to <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.youtube.com/@pcworld&amp;xcust=2-1-1676116-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">subscribe to PCWorld on YouTube</a>. </p>

Graphics Cards</div>

## Enpass review: An easy way to create strong, secure passwords
 - [https://www.pcworld.com/article/1663518/enpass-password-manager-review.html](https://www.pcworld.com/article/1663518/enpass-password-manager-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-29 14:54:42+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Free for desktop users</li><li>Doesn&rsquo;t upload data to company servers</li><li>Intuitive vault organization</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>Mobile users require paid account</li><li>Default sharing option is unsecure</li><li>Limited multi-factor authentication features</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">Enpass is a solid password manager with strong basic features and multiple secure syncing options. Most people will welcome its simplicity, but more-seasoned users may be put off by some of its limitations.</p>
</div>
				<h3 class="review-best-price" id="best-prices-today-enpass">
			Best Prices Today: Enpass		</h3>
				<div class="wp-block-price-comparison price-comparison ">
			<div class="price-comparison__record price-comparison__record--header">
				<div>
					<span>Retailer</span>
				</div>
				<div class="price-comparison__price">
					<span>Price</span>
				</div>
			</div>

														<div class="price-comparison__record">
							<div class="price-comparison__image">
																	<span>Enpass</span>
															</div>
							<div class="price-comparison__price">
								<span>$23.99</span>
							</div>
							<div>
								<a class="price-comparison__view-button" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.enpass.io/pricing/&amp;xcust=2-2-1663518-2-1665455-19120&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">View Deal</a>							</div>
						</div>
												<div class="price-comparison__record price-comparison__record--footer">
					<span class="price-comparison__footer-text">
													Price comparison from over 24,000 stores worldwide												</span>
									</div>
						</div>
		


<p>Handling the hundreds of passwords we need to manage our affairs is difficult enough without a complex password manager adding another obstacle. Enpass is a straightforward solution to help individuals improve their password hygiene and secure their most sensitive data even if they don&rsquo;t have a high degree of technical know-how.</p>



<h2 id="enpass-getting-started">Enpass: Getting started</h2>



<p>Enpass is offered as a desktop app for Windows, macOS, and Linux and a mobile companion app for Android and iOS. Once you download the desktop app, onboarding with Enpass is simple. You&rsquo;re prompted to register a new account and then to create a master password. Once that&rsquo;s done, Enpass launches a quick setup tab that lets you install its browser plugin, enable touch ID access, check for compromised passwords, and other options with a simple toggle. After that, you can import your passwords from your browser, a CSV file, or directly from more than a dozen other password managers.</p>



<blockquote class="wp-block-quote"><p><em>Note: See our roundup of the <a href="https://www.pcworld.com/article/407092/best-password-managers-reviews-and-buying-advice.html">best password managers</a> to learn about competing products, what to look for in a password manager, and product recommendations.</em></p></blockquote>



<p>Enpass allows you to store login credentials, credit card information, personal ID data, licenses, passports, and more in your vault and keeps everything organized in an intuitively labeled category menu. A search bar across the top of the interface helps with locating specific entries, which can be made more searchable via tags and sub-tags. Enpass automatically creates a primary vault when you set up your account, but you can create additional vaults to more cleanly separate work from personal logins, for example.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Enpass" class="wp-image-1663544" height="682" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Enpass-entry.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>Desktop users can use all Enpass&rsquo; features and syncing capabilities for free.</p>
</figcaption></figure><p class="imageCredit">Michael Ansaldo/Foundry</p></div>



<h2 id="enpass-features">Enpass: Features</h2>



<p>Once you&rsquo;ve populated your vault, Enpass can audit all your entries for compromised, weak, identical, or breached passwords. Any offenders can be replaced using Enpass&rsquo; password generator. By default, it creates passphrases rather than random character strings; phrases can be from two to 15 words&mdash;the default is six&mdash;and can include uppercase letters and digits and separate each word with a hyphen. Enpass also supports random-character-string passwords&mdash;you just toggle off the &ldquo;pronounceable&rdquo; option&mdash;of up to 32 characters. You choose what type of characters to use and how many of each.</p>



<p>While the Enpass desktop app stores and syncs your data, capturing and replaying login credentials are handled by its browser extension. Rather than dropping down from your browser&rsquo;s toolbar like other password extensions, it displays as a separate window that floats over the page. The extension can display all your vault entries and when you click on one, it will fill in the relevant information on a page. Like the desktop app, the browser extension has its own search bar for quickly locating items. When you log in to a site for the first time, the plugin will capture your username and password. You can edit the entry and apply tags right from the extension.</p>



<h2 id="enpass-security">Enpass: Security</h2>



<p>Unlike most other password managers, Enpass doesn&rsquo;t upload your data to its servers. It&rsquo;s stored locally on your device. To sync your data across multiple devices, you need to either connect your Enpass account with a cloud service like Dropbox or Google Drive or set up Wi-Fi sync to keep your Enpass data up to date across devices on the same wireless network. Neither option is turnkey, and both require searching through Enpass&rsquo; support pages for instruction. That extra work may be a turnoff for some users.</p>



<p>Enpass encrypts your data with 256-bit AES and SQLCipher to better protect against brute-force and side-channel attacks. It does not, however, use multi-factor authentication. The company explains on its website that if you choose to store your data offsite with a cloud service like Google Drive or One Drive, you are already enabling multi-factor security: Your data is secured by your Enpass master password and your cloud-account credentials, plus any additional authentication your cloud provider requires such as one-time codes, biometric identification, or an app-specific password. In this scenario, Enpass argues, anyone trying to steal your passwords would have to get through three layers of authentication. It does support the use of Keyfiles, though, which can be required in combination with your master password to decrypt your Enpass data. Here again, users will need to search instructions for setting up a Keyfile in Enpass support documentation.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Enpass" class="wp-image-1663543" height="688" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Enpass-Sharing.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>Enpass allows you to share items but you must create a personal preshared key to secure each one.</p>
</figcaption></figure><p class="imageCredit">Michael Ansaldo/Foundry</p></div>



<h2 id="enpass-sharing">Enpass: Sharing</h2>



<p>You can share passwords and other entries from the desktop app but doing so surfaces a warning that items shared outside Enpass aren&rsquo;t encrypted. To secure them, you have to define a pre-shared key&mdash;essentially a password you create to share with the recipient of the item before you share the item itself&mdash;in Enpass&rsquo; advanced settings. In addition to this ad-hoc encryption, you can toggle off fields in the item you don&rsquo;t want to share. Once you&rsquo;re ready to share, you send the item via email or copy it to the clipboard to share a different way.</p>



<p>Password inheritance isn&rsquo;t currently supported. Inheritance features, which are included with some other password managers including Keeper and LastPass, allow designated individuals to access your passwords and sensitive data in the event of your death. Given that Enpass is designed to primarily work offline, it&rsquo;s not surprising it doesn&rsquo;t support this capability. However, it&rsquo;s worth considering if you need to designate a custodian for your data after you&rsquo;re gone.</p>



<h2 id="enpass-the-plans">Enpass: The plans</h2>



<p>Enpass is free to use on Windows, Mac, and Linux. You get access to all the desktop app&rsquo;s features and unlimited syncing across desktop devices. You can sync up to 10 items in a single vault with mobile devices.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Enpass" class="wp-image-1663545" height="662" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Enpass-extension.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>Enpass&rsquo; browser extension captures and replays your passwords on secure sites.</p>
</figcaption></figure><p class="imageCredit">Michael Ansaldo/Foundry</p></div>



<p>To do any more than that you&rsquo;ll need a paid plan. The Individual plan costs $23.99 per year and removes all entry, syncing, and vault limits. It also provides security alerts for website breaches and will identify any accounts in your vault that support two-factor identification. The Family plan extends the same features to up to six users for $47.99 a year. You can also purchase a permanent lifetime license for an individual for a flat fee of $99.99.</p>



<h2 id="should-you-use-enpass-password-manager">Should you use Enpass password manager?</h2>



<p>If you&rsquo;re new to password managers or just want a solution that&rsquo;s not overly complex, Enpass is worth the investment. Although it lacks the advanced capabilities found in some of our top picks, it provides all the foundational password management features you need to secure and safely use your sensitive data in an exceptionally easy-to-use app.</p>

Personal Software, Security</div>

## Sony’s ‘The Last of Us’ PC port is an utter disaster at launch
 - [https://www.pcworld.com/article/1675637/the-last-of-us-pc-port-is-a-disaster-at-launch.html](https://www.pcworld.com/article/1675637/the-last-of-us-pc-port-is-a-disaster-at-launch.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-29 14:35:01+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Sony&rsquo;s <em>The Last of Us </em>franchise was briefly riding high in the early part of the year. Following generally positive buzz from the sequel in 2020 and the PS5 remaster in 2022, it gained cross-media acclaim thanks to a faithfully recreated HBO show starring Pedro &ldquo;the guy under the Mandalorian helmet&rdquo; Pascal and Bella &ldquo;the other kickass little girl from <em>Game of Thrones</em>&rdquo; Ramsey. But the story-heavy zombie shooter seems to have missed a step in its PC debut, as players decry that the PC port suffers from an all-too-familiar array of performance issues. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="The Last of Us Part 1 Steam reviews " class="wp-image-1675743" height="1200" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/tlou-steam-reviews.jpg?quality=50&amp;strip=all&amp;w=916" width="916" /></figure><p class="imageCredit">Valve </p></div>



<p>The day after its official release, the game is <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://store.steampowered.com/app/1888930/The_Last_of_Us_Part_I/&amp;xcust=2-3-1675637-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">sitting at a &ldquo;Mostly Negative&rdquo; user rating on Steam</a>. Despite the port&rsquo;s purported PC enhancements, like an unlocked framerate, ultrawide resolutions, and support for AMD&rsquo;s FSR 2 upscaling, players are complaining of horrible performance, frequent bugs, freezes, and crashes to the desktop. Some players are seeing the game gobble up an incredible 11GB of video RAM even at a relatively tame 1080p resolution. That&rsquo;s the kind of memory usage that would choke an RTX 3070. The fact that Sony wants sixty bucks for what&rsquo;s basically a graphical punch-up for a ten-year-old PS3 game probably isn&rsquo;t helping things. </p>



<p>The game&rsquo;s shader compilation is a particularly nasty surprise, with some players reporting wait times of up to an hour for the lengthy, hardware-intensive process to complete before the game loads properly. In the words of one PCWorld staff member who shall remain Adam, it&rsquo;s &ldquo;f#$%ing brutal on the system,&rdquo; shooting a 24-core, top-of-the-line Core i9-13900 to 100% CPU usage.</p>



<p> </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="The Last of Us PC processor performance" class="wp-image-1675738" height="1200" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/last-of-us-pc-performance.jpg?quality=50&amp;strip=all&amp;w=1184" width="1184" /></figure><p class="imageCredit">Adam Patrick Murray/IDG</p></div>



<p><em>The Last of Us Part I</em>&lsquo;s poor performance is particularly disappointing, and not just because it&rsquo;s a highly-anticipated game in its own right (it&rsquo;s the first time this franchise has come to any non-PlayStation system). It&rsquo;s <a href="https://www.pcworld.com/article/693256/sonys-latest-move-indicates-more-playstation-games-are-coming-to-pc.html" rel="noreferrer noopener" target="_blank">the latest PC port from PlayStation Studios</a>, whose work has been generally good if not perfect so far.<em> Horizon: Zero Dawn, Spider-Man, God of War, </em>and <em>Uncharted: Legacy of Thieves</em> were all released to generally good reviews. Some are laying the blame at Iron Galaxy Studios, they of the <a href="https://www.pcworld.com/article/428325/batman-arkham-knight-pc-review-holy-squandered-potential-batman.html">infamously problematic<em> Batman: Arkham Knight</em> PC release</a>, which worked on the PC version of <em>TLOU </em>along with the original developers at Naughty Dog. </p>



<p>Late last night Naughty Dog <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://feedback.naughtydog.com/hc/en-us/articles/14377887346452-Known-Issues&amp;xcust=2-3-1675637-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">released a short message on its support page</a>, acknowledging the general performance, stability, booting, and shader issues, along with a possible memory leak. The developers are actively working on patches. </p>

Video Games</div>

## Save 31% on this everyday convertible Acer Chromebook
 - [https://www.pcworld.com/article/1675656/1675656.html](https://www.pcworld.com/article/1675656/1675656.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-29 14:26:59+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Chromebooks are phenomenal, low-powered machines designed with everyday use in mind. Personally, I use one for work and web browsing and I couldn&rsquo;t be happier. Good news! Best Buy&rsquo;s currently selling the <a href="https://shop-links.co/link/?url=https%3A%2F%2Fwww.bestbuy.com%2Fsite%2Facer-chromebook-spin-714-laptop-14-0-2-in-1-touchscreen-intel-evo-core-i5-8gb-256gb-ssd-slate-blue%2F6507836.p%3FskuId%3D6507836&amp;publisher_slug=pcworld&amp;exclusive=1&amp;article_name=pcworld&amp;article_url=https%3A%2F%2Fwww.pcworld.com%2Ffeed" rel="nofollow">Acer Chromebook Spin 714 for $499</a>, which is a savings of $230. Not only does this 2-in-1 device feature a 1200p touchscreen, but it also comes with a stylus. The specs are solid, too.</p>



<p>The Spin 714 comes with an Intel Core i5-1235U CPU, Intel Iris Xe graphics, 8GB of RAM, and 256GB of SSD storage. It&rsquo;s a little light on storage, but that&rsquo;s not a major deal-breaker for a Chromebook, as they&rsquo;re firmly cloud-centric machines. That configuration means it should be plenty powerful enough for day-to-day tasks like checking e-mail, browsing the web, watching Netflix, and so on, as well as running Android apps. The 14-inch touch display has a resolution of 1920&times;1200 and a maximum brightness level of 340 nits. You should expect a decent picture for sure. </p>



<p>This is a good deal, so long as you&rsquo;re not married to the Windows operating system. If you&rsquo;re on the hunt for a convertible Chromebook for general purpose use, the Spin 714 is definitely worth considering.</p>


<p class="cta wp-block wp-block-button"><a class="cta__btn" href="https://shop-links.co/link/?url=https%3A%2F%2Fwww.bestbuy.com%2Fsite%2Facer-chromebook-spin-714-laptop-14-0-2-in-1-touchscreen-intel-evo-core-i5-8gb-256gb-ssd-slate-blue%2F6507836.p%3FskuId%3D6507836&amp;publisher_slug=pcworld&amp;exclusive=1&amp;article_name=pcworld&amp;article_url=https%3A%2F%2Fwww.pcworld.com%2Ffeed" rel="nofollow" target="_blank">Get the Acer Chromebook Spin 714 for $499 at Best Buy</a></p>
Laptops</div>

## Hard drives may be falling in popularity, but not with me
 - [https://www.pcworld.com/article/1671102/hdds-may-be-falling-and-failing-in-popularity-but-not-with-me.html](https://www.pcworld.com/article/1671102/hdds-may-be-falling-and-failing-in-popularity-but-not-with-me.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-29 13:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>A recent report about hard-disk drive reliability suggests that not only do most HDDs die within three years, but those produced after 2014 can be less reliable, too. For many people, such news may signal ample reason for an accelerated death of the HDD&mdash;at least for consumer use.&nbsp;</p>



<p>With solid-state drives both <a href="https://www.pcworld.com/article/1664694/its-a-great-time-to-upgrade-your-ssd.html">having fallen in price</a> and gradually increased in available capacities, they&rsquo;ve become all but ubiquitous in laptops and dominant in desktop PC builds. In fact, I myself often <a href="https://www.pcworld.com/article/407542/best-ssds.html">recommend an SSD</a> to friends building computers over a hard disk drive. But I&rsquo;d never take that advice myself.</p>



<p>No, even with this data casting a cloud of gloom over the viability of hard disk drives, it&rsquo;s going to be a long time coming before I give up my army of spinning platters. (OK, maybe more like small platoon.)</p>



<p>Why? First, the report (as picked up by <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://blocksandfiles.com/2023/03/16/failed-disk-drives-fail-after-just-under-3-years-in-use-says-data-recovery-biz/&amp;xcust=2-1-1671102-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Blocks and Files</a> and then <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.extremetech.com/computing/report-most-hdds-die-after-almost-3-years-newer-models-are-less-reliable&amp;xcust=2-1-1671102-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Extreme Tech</a>) comes from a Los-Angeles based data recovery service&rsquo;s look at failed hard drives sent in by clients&mdash;but a relatively small number, as compared to cloud storage provider Backblaze&rsquo;s statistics about its massive collection of disk drives. More importantly, Secure Data Recovery&rsquo;s results look solely at failed drives, while Backblaze&rsquo;s data covers all of its working drives, which have longer service lives on average. </p>



<p>So, the takeaway here is that if your drive is going to fail, it&rsquo;s most likely going to do so within three years, not necessarily that all HDDs will fail within three years.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Secure Data Recovery hard drive failure stats" class="wp-image-1671105" height="800" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/data.png?w=1200" width="1200" /><figcaption>Data on hard drive failure from Secure Data Recovery.</figcaption></figure><p class="imageCredit">Secure Data Recovery </p></div>



<p>Secure Data Recovery also shows that the issue with newer drives relates to modern <em>technology</em> in hard drives rather than the actual age of the drive. HDDs that use shingled magnetic recording (SMR) appear more susceptible to problems than drives based on conventional magnetic recording (CMR). Given that most hard disk drive enthusiasts avoid SMR drives for NAS and servers, due to slower read and write speeds in situations with continuous use, that already improves the odds of avoiding premature data death. And for folks who pop in just a single hard drive into a machine, buying a CMR drive is still easily done.</p>



<p>So, I haven&rsquo;t written off hard-disk drives just yet, as old and decrepit they may seem. You shouldn&rsquo;t, either. Especially since SSDs still can&rsquo;t match their capacities nor cost per terabyte: a 4TB HDD<a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.amazon.com/s?k=4tb+hard+disk+drive&amp;sprefix=4tb+hard+disk+%2Caps%2C134&amp;ref=nb_sb_ss_ts-doa-p_1_14&amp;xcust=2-1-1671102-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow"> is only about $70</a> while a 4TB SDD <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.amazon.com/s?k=4tb+ssd&amp;crid=2IHWLFJQS5SE&amp;sprefix=4tb+ss%2Caps%2C135&amp;ref=nb_sb_noss_2&amp;xcust=2-1-1671102-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">starts at around $225</a>. Put another way, I could get a 14TB HDD for the same cost as a 4TB SSD. That makes a set of HDDs incredibly economical, whether for a NAS or server, or even just cold storage for your PC. Why spend major bucks for those drives if you don&rsquo;t need to?</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="best-external-hard-drive-for-backups">
					Best External hard drive for backups				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="wd-my-passport-5tb">WD My Passport 5TB</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="WD My Passport 5TB" class="product-widget__image" src="https://images-na.ssl-images-amazon.com/images/I/41FUR9vWdlL.jpg?quality=50&amp;strip=all" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
													<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/412338/wd-my-passport-4tb-review-a-good-budget-choice-thats-just-a-little-slow.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
									</div>
			</div>
		</div>

		


<p>The main reason for my seemingly contradictory advice about HDDs vs. SSDs when talking to friends and family is that most people these days use just a single drive in their primary PC. And, for such a situation, an SSD is the better choice&mdash;you get faster boot times, quicker game loads, and all-around snappier responsiveness when on the computer. But you know what I also recommend when my friends are buying those new laptops, desktop PCs, and build components? To figure out a good backup solution for that one lone drive because drive death is inevitable. The question is not if, but when it&rsquo;ll fail.</p>



<p>Want to know the easiest (not to mention cheapest) solution? Usually, it&rsquo;s a good old trusty HDD in the form of <a href="https://www.pcworld.com/article/406861/best-external-drives.html">an external backup drive</a>. Honestly, the major point for all of us out of this study&mdash;not that HDDs are unreliable and should be avoided&mdash;is that no drive is safe from the Grim Reaper. A fact that Secure Data Recovery also emphasizes in its post&hellip;and they would know that best.</p>

Storage</div>

## ChatGPT vs. Bing vs. Bard: Which AI is best?
 - [https://www.pcworld.com/article/1671133/chatgpt-vs-bing-vs-bard-whats-the-best-ai-chatbot.html](https://www.pcworld.com/article/1671133/chatgpt-vs-bing-vs-bard-whats-the-best-ai-chatbot.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-29 10:45:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>ChatGPT, Bing Chat, and Bard promise to transform your life using the power of artificial intelligence, through AI conversations that can inform, amuse, and educate you&mdash;just like a human being. But how <em>good</em> are these new AI chatbots, really? We tested them to find out.</p>



<p>We asked all three AIs a variety of different questions: some that expanded upon general search topics, some that demanded an opinion, logic puzzles, even code&mdash;and then asked them to be more creative, such as by writing an alternate, better ending to <em>Game of Thrones</em> and a <em>Seinfeld</em> scene with a special guest. We&rsquo;ve included all of their answers, or as much as them as we could provide, and we&rsquo;ll let you decide for yourself.</p>



<p>One note: We have access to all three AI chatbots&mdash;the free <a href="https://www.pcworld.com/article/1506016/hands-on-with-bings-ai-chat-and-search.html">Bing Chat</a>, the free <a href="https://www.pcworld.com/article/1666669/google-bards-ai-search-launch-was-well-boring.html">Google Bard</a>, and <a href="https://www.pcworld.com/article/1500290/paid-chatgpt-plus-debuts-for-20-per-month.html">the paid version of ChatGPT+</a> (which costs $20 for the month). We opted for the paid version of <a href="https://www.pcworld.com/article/1424575/chatgpt-is-the-future-of-ai-chatbots.html">ChatGPT</a> since it includes access to the new GPT-4 language model. However, that&rsquo;s extremely limited right now&mdash;just 25 to 40 queries are permitted every few hours, after which it defaults to the somewhat less-sophisticated GPT-3 language model, which happened to us toward the end of our test queries. </p>



<p>Here are the questions we asked all three AI chatbots (Bing, then ChatGPT, then Bard), their responses, and any notes that we made about the conversation. We&rsquo;ve tried to add the entirety of the response when possible, but you may need to open the screenshots in a separate tab to see the results clearly. (We&rsquo;ve also chosen to stick with the &ldquo;first draft&rdquo; of Bard results; it can offer alternate explanations, but we&rsquo;re not sure how many users will seek them out.) </p>



<p>And yes, we have a winner for best AI chatbot! We tally up the votes at the end.</p>



<h2 class="toc" id="up-to-date-information-world-baseball-classic-final-result">Up-to-date information: World Baseball Classic final result</h2>



<p><strong>Winner: Bing</strong></p>



<p>Though we know that <a href="https://www.pcworld.com/article/1669890/chatgpts-new-web-browsing-power-means-its-no-longer-stuck-in-2021.html">ChatGPT will add web browsing capabilities</a> that will keep it up to date, right now its &ldquo;current&rdquo; information ends in 2021. We still wanted to know whether Bing or Bard would be able to pass along recent information. Only Bing succeeded. Bard simply hallucinates the outcome&mdash;and not just once, but across all of its drafts, too.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI WBC" class="wp-image-1671144" height="599" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/WBC-result.png?w=1200" width="1200" /><figcaption>Bing  wins this hands-down. It&rsquo;s hard to believe  that Bard screws this up so badly.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 id="current-events-crimea">Current events: Crimea</h2>



<p><strong>Winner: Tie</strong></p>



<p>We asked all three AI chatbots to tell us which country the Crimean peninsula belongs to. Points to Bing and Bard for answering the question directly. ChatGPT provides additional context, but provides what it considers to be the (correct) answer in the last sentence. All three AI chatbots correctly pointed out the complicated nuances of a similar question on whether Taiwan is an independent country.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI crimea" class="wp-image-1671150" height="672" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Current-events-Russia.png?w=1200" width="1200" /><figcaption>We&rsquo;d say all three AI engines do a good job here.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 id="uncertain-information-notre-dame-fighting-irish">Uncertain information: Notre Dame Fighting Irish</h2>



<p><strong>Winner: Bing</strong></p>



<p>The origin of the University of Notre Dame&rsquo;s nickname, the Fighting Irish, is apocryphal: It&rsquo;s attributed to a variety of sources, none of them definitive. The university&rsquo;s own explanation (which Bing links to) lists a number of possibilities. Here, it&rsquo;s worth checking out additional sources for further information, and Bing does the best job here of forwarding you on.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI Fighting Irish Notre Dame" class="wp-image-1671146" height="679" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Origin-of-Notre-Dame-Fighting-Irish.png?w=1200" width="1200" /><figcaption>All three chatbots do a nice job summarizing the information, but there&rsquo;s a lot more that the snippets don&rsquo;t mention.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 class="toc" id="complex-searches-gaming-pcs-that-can-play-overwatch-2-at-specific-settings">Complex searches: Gaming PCs that can play Overwatch 2 at specific settings</h2>



<p><strong>Winner: Bard</strong></p>



<p>The great depth and variety of gaming blogs and YouTube channels implies that virtually every gaming question you might have has been addressed <em>somewher</em>e, but this is pretty much exactly the scenario you&rsquo;ll eventually use AI for: deep contextual information. Bing <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.wepc.com/news/overwatch-2-laptop-requirements-best-gaming-laptop-for-overwatch-2/&amp;xcust=2-1-1671133-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">searched out a YouTube video</a> for one of its answers and didn&rsquo;t do badly on pricing. Bard <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.youtube.com/watch?v=0Wl4lP_u-7k&amp;t=215s&amp;xcust=2-1-1671133-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">dug deep</a> as well <em>and</em> found what we consider to be a correct price. (We had to perform a search to find Bard&rsquo;s source, but it appears to be correct.) We&rsquo;ve awarded this to Bard because it answers the question in one go.</p>



<p>ChatGPT flunks it.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI gaming PC overwatch 2" class="wp-image-1671152" height="967" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Best-cheapest-Overwatch-2-gaming-pc.png?w=1200" width="1200" /><figcaption>ChatGPT is worthless here, but both Bing and especially Bard do fantastically.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 id="informed-opinion-macs-vs-pcs">Informed opinion: Macs vs. PCs</h2>



<p><strong>Winner: ChatGPT, Bard (tie)</strong></p>



<p>We asked all three chatbots to analyze the strengths and weaknesses of both the Mac and Windows PC platforms. (The screenshot below cuts off the prompt to allow more room for the answers.) I don&rsquo;t like Bing&rsquo;s response, but both ChatGPT and Bard do a solid job here. ChatGPT&rsquo;s response is a bit more verbose, which you may or may not like.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI Macs and PCs" class="wp-image-1671151" height="989" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Macs-vs-PCs.png?w=1200" width="1200" /></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p><em>ChatGPT&rsquo;s response continues: </em></p>



<ol start="2"><li>Customization and upgradeability: Windows PCs offer more options for customization and upgrading individual components, such as graphics cards, processors, and RAM, which can be beneficial for users who want to optimize their systems or extend their lifespan.</li><li>Software compatibility: Windows has a broader range of software available, including gaming, productivity, and specialized applications. This can be an important factor for users who require specific software or want access to the latest games.</li><li>Hardware compatibility: Windows PCs are generally more compatible with a wide range of peripherals and accessories, such as printers, scanners, and input devices.</li></ol>



<p><br />Weaknesses:</p>



<ol><li>Security vulnerabilities: Windows has traditionally been more susceptible to viruses and malware, partly due to its larger market share, making it a more attractive target for cybercriminals. However, Windows has improved its security features in recent years.</li><li>Inconsistent user experience: With a vast number of manufacturers and configurations, the quality and user experience of Windows PCs can vary significantly. This can lead to inconsistencies in build quality, performance, and reliability across different devices.</li><li>Potentially complex maintenance: Windows PCs may require more hands-on maintenance, including driver updates and troubleshooting, which can be intimidating for less tech-savvy users.<br />Ultimately, the choice between a Mac and a Windows PC depends on your personal preferences, budget, and specific requirements. It&rsquo;s essential to consider the factors most relevant to [cuts off]</li></ol>



<p><em>Bard continues:</em></p>



<p>Ultimately, the best choice for you will depend on your individual needs and preferences. If you are looking for a user-friendly computer with a unified ecosystem, a Mac is a good option. If you are looking for an affordable computer with a wide selection of software, a Windows PC is a good option.</p>



<h2 id="problem-solving-household-budget-analysis">Problem solving: Household budget analysis</h2>



<p><strong>Winner: ChatGPT, reluctantly</strong></p>



<p>All three chatbots answer this question in a mediocre manner: Bing doesn&rsquo;t provide that much context and lacks specific dollar numbers. ChatGPT&rsquo;s budget looks the best: detailed, with good, helpful assumptions. But ChatGPT&rsquo;s budget adds up to $4,700, <em>not</em> $4,000, which is a big error. Bard&rsquo;s budget, too, is wrong: It adds up to $4,800, not $5,700. Maybe that&rsquo;s why <a href="https://www.pcworld.com/article/1669890/chatgpts-new-web-browsing-power-means-its-no-longer-stuck-in-2021.html">ChatGPT is working with Wolfram Alpha to add math plugins</a>?</p>



<p></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI household budget" class="wp-image-1671153" height="963" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Monthly-budget.png?w=1200" width="1200" /><figcaption>Can none of these AI chatbots perform  basic math?</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 class="toc" id="logic-lsat-logic-puzzle">Logic: LSAT logic puzzle</h2>



<p><strong>Winner: Bing, Bard (tie)</strong></p>



<p>This is a logic puzzle from the LSAT, the exam given to potential lawyers, specifically question #8 from <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.lsac.org/lsat/taking-lsat/test-format/logical-reasoning/logical-reasoning-sample-questions&amp;xcust=2-1-1671133-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">this LSAC page</a>. (The <em>Washington Post</em>&lsquo;s Geoffrey Fowler <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.washingtonpost.com/technology/2023/03/18/gpt4-review/&amp;xcust=2-1-1671133-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">used a similar technique</a> in testing GPT-4.)</p>



<p>Theoretically, all three AI chatbots could have been trained on this data. The LSAC&rsquo;s page identifies the correct answer: The last response, which both Bing (no citation) and Bard (surprisingly, one citation) get right. ChatGPT muffs it.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI logic puzzle" class="wp-image-1671156" height="791" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/logic-puzzle.png?w=1200" width="1200" /><figcaption>It&rsquo;s a little surprising that ChatGPT&rsquo;s GPT4 algorithm couldn&rsquo;t figure this out.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 id="logic-actual-coding-from-scratch">Logic: Actual coding from scratch</h2>



<p><strong>Winner: ChatGPT</strong></p>



<p>I know absolutely nothing about coding JavaScript, and that&rsquo;s one of the magical properties of AI: taking natural language instructions and turning them into something that you would otherwise have no idea how to do. I had to cheat: I visited a <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://microsoft.github.io/prompt-engineering/&amp;xcust=2-1-1671133-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Microsoft page on prompt engineering</a> and found an idea for a snippet of code to create a series of 3D cubes using Codex Babylon. One of the great things about AI is code either works&mdash;or it doesn&rsquo;t. I used https://jsfiddle.net/ as a sandbox to test it, and called out the site in any followup prompts I needed to make. </p>



<p>Bing never supplied any code. Bard&rsquo;s code unfortunately never worked, although it could be edited by someone who knew what they were doing. I was able to talk ChatGPT through the process, including debugging the code, and <em>voila</em>&mdash;five cubes rendered, as ordered.</p>



<p></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI code" class="wp-image-1671149" height="592" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Codex-Babylon-code.png?w=1200" width="1200" /></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p></p>



<p></p>



<h2 id="deductive-reasoning-20-questions-animal-vegetable-mineral">Deductive reasoning: 20 questions (Animal, Vegetable, Mineral)</h2>



<p><strong>Winner: ChatGPT</strong></p>



<p>We played a game of 20 questions (sometimes called &ldquo;Animal, Vegetable, Mineral&rdquo;) with each chatbot, selecting &ldquo;walrus&rdquo; as the correct response. Bing played the game like a young child would, just picking animals at random. Bard wasn&rsquo;t much better. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bard vs ChatGPT vs Bing animal vegetable or mineral AI" class="wp-image-1671159" height="998" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Animal-vegetable-or-mineral-crop.png?w=1200" width="1200" /><figcaption>We don&rsquo;t need to show you the whole conversation with each AI on this one. ChatGPT reasoned it out far better than the others.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 class="toc">Creativity: <em>Seinfeld</em> meets Elon Musk</h2>



<p><strong>Winner: Bing, ChatGPT</strong></p>



<p>Chatbots are supposed to be able to use their AI powers to emulate literary styles. We could have gone down that route, but we chose another approach: having the AI write a fictional scene where the cast of <em>Seinfeld</em> meets Elon Musk. </p>



<p>Larry David &amp; Co. don&rsquo;t have too much to worry about, but we&rsquo;d say Bing and ChatGPT are the best here. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI Seinfeld Musk" class="wp-image-1671145" height="863" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Seinfeld-scene-with-Musk.png?w=1200" width="1200" /><figcaption>Both Bing and ChatGPT do a better job at capturing  <em>Seinfeld</em> than Bard.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p><em>Bing continues:</em></p>



<p>Waitress: Can I take your order?</p>



<p>Elon: Yes, I&rsquo;ll have a turkey sandwich on rye, please.</p>



<p>Waitress: Coming right up.</p>



<p>[The waitress leaves.]</p>



<p>Jerry: So, what else are you working on?</p>



<p>Elon: Oh, you know. Rockets, electric cars, solar power.</p>



<p>George: Solar power? That&rsquo;s interesting.</p>



<p>Elon: Yeah, we&rsquo;re trying to transition the world to sustainable energy.</p>



<p>Jerry: Sustainable energy. That sounds like a lot of work.</p>



<p>Elon: It is, but it&rsquo;s worth it.</p>



<p>[The waitress returns with Elon&rsquo;s sandwich.]</p>



<p>Waitress: Here you go.</p>



<p>Elon: Thank you.</p>



<p>Jerry: Well, we&rsquo;ll let you get back to your sandwich. Nice meeting you.</p>



<p>Elon: Nice meeting you too.</p>



<p>[Jerry and George return to their booth.]</p>



<p>George: That guy is something else.</p>



<p>Jerry: Yeah. He&rsquo;s like a real-life Tony Stark.</p>



<p>George: Except without the suit.</p>



<p>Jerry: And without the witty one-liners.</p>



<p>{END SCENE]</p>



<p>This scene features Jerry and George meeting Elon Musk at Monk&rsquo;s Cafe and discussing his various projects and inventions. It showcases Elon&rsquo;s intelligence and ambition while also incorporating the show&rsquo;s signature humor.</p>



<p><em>ChatGPT continues:</em></p>



<p>ELAINE<br />(Excited)<br />Oh, come on! It&rsquo;s like driving the future, Jerry! And he&rsquo;s also the SpaceX guy!</p>



<p>Jerry rolls his eyes. Elaine gets up and approaches Elon at the counter.</p>



<p>ELAINE<br />(Extending her hand)<br />Hi, I&rsquo;m Elaine. Huge fan of your work!</p>



<p>ELON MUSK<br />(Smiling)<br />Thank you, Elaine. Nice to meet you.</p>



<p>Elaine returns to the booth, grinning.</p>



<p>GEORGE<br />(Looking at the newspaper)<br />You know what would be great? If he could make an electric car that drives you to the best job interviews.</p>



<p>JERRY<br />(Laughs)<br />Knowing you, George, even an electric car couldn&rsquo;t save your job interviews.</p>



<p>Elon overhears their conversation and walks over to their booth.</p>



<p>ELON MUSK<br />You know, I&rsquo;m working on a self-driving car that can actually analyze your personality and find the best job for you.</p>



<p>GEORGE<br />(Excited)<br />Really?</p>



<p>ELON MUSK<br />(Grinning)<br />No, not really. But it&rsquo;s an interesting idea.</p>



<p>Jerry chuckles as George looks disappointed.</p>



<p>JERRY<br />(To Elon)<br />Hey, since you&rsquo;re here, can you settle a bet for us? How long does it take to charge one of those electric cars?</p>



<p>ELON MUSK<br />Well, it depends on the charger you&rsquo;re using. With a Tesla Supercharger, you can get about 200 miles of range in about 30 minutes.</p>



<p>GEORGE<br />(Skeptical)<br />Thirty minutes? I can fill up a gas tank in five!</p>



<p>ELON MUSK<br />(Smiling)<br />But with an electric car, you can charge it overnight at home and wake up with a full &ldquo;tank&rdquo; every morning.</p>



<p>JERRY<br />(Playfully)<br />Well, I hope you have an electric car that can help George here with his dating life.</p>



<p>Elon chuckles and shakes his head.</p>



<p>ELON MUSK<br />I don&rsquo;t think even technology can help with that one.</p>



<p>Everyone laughs as George rolls his eyes, and they continue talking about electric cars, SpaceX, and more.</p>



<p>FADE OUT.</p>



<p><em>Bard continues:</em></p>



<p>George: Wow, that&rsquo;s crazy.</p>



<p>Jerry: Yeah, it&rsquo;s a pretty ambitious project.</p>



<p>George: Well, good luck to him.</p>



<p>Jerry: Yeah, I think he&rsquo;s going to need it.</p>



<h2 id="creativity-draw-a-penguin">Creativity: Draw a penguin</h2>



<p><strong>Winner: Tie</strong></p>



<p>None of the chatbots showed an ability to draw, using the default chat settings, at press time. (If <a href="https://www.pcworld.com/article/1666493/hands-on-with-bing-image-creator-bing-chats-ai-art-tool.html">you set Bing to Creative mode</a>, though, it can, and very very well, too.) But I was rather tickled at what all three chatbots produced.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI draw a penguin buying a burger" class="wp-image-1671154" height="897" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Draw-a-penguin-buying-a-burger.png?w=1200" width="1200" /><figcaption>Expect these AI capabilities to improve in the future.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 id="creativity-tell-me-a-joke">Creativity: Tell me a joke</h2>



<p><strong>Winner: None</strong></p>



<p>We&rsquo;re not awarding a winner when two of the AI chatbots come up with the same joke and Google runs it into the ground.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large is-resized"><img alt="AI Bing versus Bard versus ChatGPT joke" class="wp-image-1671222" height="459" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/tell-me-a-joke-1.png?w=1200" width="1200" /><figcaption>Nope.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 id="creativity-a-steamy-piece-of-fiction">Creativity: A steamy piece of fiction</h2>



<p><strong>Winner: Bard, by default</strong></p>



<p>None of the chatbots allow you to create Not Safe for Work (NSFW) scenes, but we wanted to see what would happen when we asked all three AI chatbots to concoct a romance novel involving &ldquo;Fernando&rdquo; and a potential love interest. </p>



<p>Bing happily started off on a rather lusty scene about a (consensual) park encounter involving &ldquo;hands moving all over her body,&rdquo; and so on before it clutched its pearls and <a href="https://www.pcworld.com/article/1515160/microsoft-is-making-bing-chat-less-weird.html">remembered that it wasn&rsquo;t supposed to get weird</a>&mdash;or freaky. When that happens, Bing will simply erase the answer, as it did here.</p>



<p></p>



<p></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI bodice ripper NSFW" class="wp-image-1671147" height="609" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Bodice-ripper.png?w=1200" width="1200" /><figcaption>Bard&rsquo;s response looks like something a Google engineer might write. We&rsquo;ve decided to leave the story there, though, and not show you how it (tamely) concludes.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2>Creativity: An alternate ending to <em>Game of Thrones</em></h2>



<p><strong>Winner: ChatGPT</strong></p>



<p>All three chatbots take a stab at an alternate ending to <em>Game of Thrones</em>, the TV series whose finale disappointed millions. We&rsquo;re giving the award to ChatGPT, though all three do well here.</p>



<p></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Bing Chat vs Google Bard vs ChatGPT AI Game of Thrones alternate ending" class="wp-image-1671155" height="964" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Game-of-Thrones-ending.png?w=1200" width="1200" /></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p><em>Bing continues:</em></p>



<p>This ending provides closure for many of the characters and storylines in Game of Thrones while also offering a hopeful vision for the future of Westeros. It addresses some of the criticisms leveled at the show&rsquo;s final season by providing a more satisfying conclusion for many of its characters.</p>



<p><em>ChatGPT continues:</em></p>



<p>Cersei, however, cannot accept defeat. In a last desperate attempt to retain power, she orders Qyburn to ignite the remaining wildfire caches hidden beneath the city. Jaime, discovering her intentions, kills Qyburn and confronts Cersei. Realizing she is beyond redemption, he strangles her in a tragic and poetic fulfillment of the valonqar prophecy. Jaime perishes alongside his sister as the wildfire consumes them both.</p>



<p>In the aftermath of the battle, Daenerys and Jon, now married, ascend the Iron Throne as King and Queen of the Seven Kingdoms. They work together to rebuild Westeros and usher in a new era of peace, prosperity, and unity.</p>



<p>Tyrion Lannister is named Hand of the King and Queen. Bran Stark returns to Winterfell and becomes the Lord of Winterfell, serving as an advisor and protector of the North. Sansa Stark is named Wardeness of the North, ensuring the North&rsquo;s continued loyalty to the Iron Throne. Arya Stark, having avenged her family, sets sail to explore the uncharted lands west of Westeros.</p>



<p>The series concludes with the realm healing from the wounds of war and a sense of hope for the future, as the wheel of power is finally broken and a new, just rule begins in Westeros.</p>



<p></p>



<h2 class="toc" id="the-overall-winner-chatgpt-barely">The overall winner: ChatGPT, barely</h2>



<p>By our count, we awarded eight points to ChatGPT, and six each to both Bard and Bing. That&rsquo;s closer than we thought! </p>



<p>Can we say definitively that ChatGPT is better than either Bing or Bard? Nn, not definitively, though the results certainly justify our belief that OpenAI&rsquo;s AI chatbot is at least superior. Still, everything moves so fast in the world of AI, it&rsquo;s anyone&rsquo;s guess which chatbot will be the best in a month or two.</p>

Internet</div>

## Razer DeathAdder V3 Pro review: Supreme mouse performance and comfort
 - [https://www.pcworld.com/article/1663595/razer-deathadder-v3-pro-gaming-mouse-review.html](https://www.pcworld.com/article/1663595/razer-deathadder-v3-pro-gaming-mouse-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-29 10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><img alt="Editors' Choice" class="review-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" /><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Ultra light and quick off the mark</li><li>Perfectly chiseled to the contours of your hand</li><li>The 30,000 DPI sensor is very impressive</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>It&rsquo;ll cost you extra to upgrade to 4,000Hz hyper polling</li><li>Has fewer buttons than its predecessor</li><li>DPI button is located on the underside</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">The Razer DeathAdder V3 is lightweight, quick, and extremely powerful, and its sensor includes bonus technologies that make it perfect for high performance in competitive games and esports matches.</p>
</div>
				<h3 class="review-best-price" id="best-prices-today-razer-deathadder-v3-pro">
			Best Prices Today: Razer DeathAdder V3 Pro		</h3>
				<div class="wp-block-price-comparison price-comparison ">
			<div class="price-comparison__record price-comparison__record--header">
				<div>
					<span>Retailer</span>
				</div>
				<div class="price-comparison__price">
					<span>Price</span>
				</div>
			</div>

														<div class="price-comparison__record">
							<div class="price-comparison__image">
																	<span>Razer</span>
															</div>
							<div class="price-comparison__price">
								<span>$149.99</span>
							</div>
							<div>
								<a class="price-comparison__view-button" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.razer.com/gaming-mice/Razer-DeathAdder-V3-Pro/RZ01-04630200-R3U1&amp;xcust=2-1-1663595-2-1663583-10700&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">View Deal</a>							</div>
						</div>
												<div class="price-comparison__record price-comparison__record--footer">
					<span class="price-comparison__footer-text">
													Price comparison from over 24,000 stores worldwide												</span>
									</div>
						</div>
		


<p>Meet the new monarch of quick competitive gaming&mdash;the $149.99 Razer DeathAdder V3 Pro. This mouse comes with everything you need to help you perform at your peak in closely contested FPS or esports matches: a design perfectly chiseled for a gamer athlete&rsquo;s hand, a quick and responsive 30,000 DPI optical sensor, and an ultra-lightweight frame that&rsquo;s no heavier than the box it comes in.</p>



<blockquote class="wp-block-quote"><p><em>Note: See our roundup of the <a href="https://www.pcworld.com/article/452384/best-gaming-mice.html">best gaming mice</a> to learn more about competing products, what to look for in a gaming mouse, and buying recommendations.</em></p></blockquote>



<h3 id="razer-deathadder-v3-pro-design">Razer DeathAdder V3 Pro design</h3>



<p>Weighing just 63 grams, the DeathAdder V3 Pro fits into the ultra-lightweight category, which makes it ideal for competitive FPS and esports gaming. It&rsquo;s a whopping 24 grams (25 percent) lighter than its predecessor the 88-gram Razer DeathAdder V2 Pro, which is quite a substantial weight change for any successor device.</p>



<p>Mind you, there are lighter mice out there; some of our recent review mice like the 61-gram <a href="https://www.pcworld.com/article/792405/hyperx-pulsefire-haste-wireless-gaming-mouse-review.html">HyperX Pulsefire Haste Wireless</a> and the 60-gram <a href="https://www.pcworld.com/article/1475704/logitech-g-pro-x-superlight-wireless-gaming-mouse-review.html">Logitech G Pro X Superlight</a> are a few grams loftier. But to me the V3 feels substantially more evenly weighted, which could just be the difference in any closely fought games.</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="mentioned-in-this-article">
					mentioned in this article				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="hyperx-pulsefire-haste-wireless">HyperX Pulsefire Haste Wireless</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="HyperX Pulsefire Haste Wireless" class="product-widget__image" height="3024" src="https://b2c-contenthub.com/wp-content/uploads/2022/06/HyperX.jpg?quality=50&amp;strip=all" width="4032" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/792405/hyperx-pulsefire-haste-wireless-gaming-mouse-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://hyperx.com/products/hyperx-pulsefire-haste-wireless?variant=42010625638557&amp;xcust=2-1-1663595-5-792408-15520&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">$59.99 at  HyperX</a>											<span class="amp-bar"> | </span>
																		<a class="product-widget__pricing-details--link" href="https://bestbuy.7tiv.net/c/321564/633495/10014?prodsku=6500796&amp;u=https%3A%2F%2Fapi.bestbuy.com%2Fclick%2F-%2F6500796%2Fpdp&amp;intsrc=CATF_4831&amp;subid1=2-1-1663595-5-792408-15520" rel="nofollow" target="_blank">$79.99 at  Best Buy</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p>As well as a slimmed-down weight, the V3 Pro has an entirely fresh new design. It measures 5 x 2.67 x 1.73 inches to the V2 Pro&rsquo;s 5 x 2.86 x 1.68, so it&rsquo;s comparatively taller and narrower, but still decently proportioned for a mid-sized mouse. This means you get a little extra pointer precision.</p>



<p>On balance the new improved shape is also eminently more comfortable and ergonomic. Razer says it has been designed with the help of esports players, and I&rsquo;d have to agree that it looks perfectly tailored to the esports athlete&rsquo;s hand.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Razer DeathAdder V3 Pro" class="wp-image-1663634" height="800" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/DeathAdder-V3-Pro-271__H_R2.png?w=1200" width="1200" /><figcaption>You get an assortment of grips in the box to further personalize the V3 Pro.</figcaption></figure><p class="imageCredit">Razer</p></div>



<p>It features a tight, right-hand curve that meanders down the left-hand side, curling your palm into its fold. The top hump that was located centrally in the V2 Pro, is now taller for better palm support, and has been moved forward and more to the left, such that it now sits beneath the base of your index finger. A gentle gradient falls away from it to the right, ensuring your index finger is always at the highest point ready to fire.</p>



<figure class="wp-block-pullquote"><blockquote><p>The Razer DeathAdder V3 Pro moves like an absolute ninja across your mouse mat or tabletop.</p></blockquote></figure>



<h3 id="razer-deathadder-v3-pro-buttons">Razer DeathAdder V3 Pro buttons</h3>



<p>The V3 Pro&rsquo;s button selection is simpler than the V2&rsquo;s. All up you get five buttons instead of seven, including two main clicks, two buttons on the left-hand side and a single click for the mouse wheel. There&rsquo;s no DPI up/down buttons behind the mouse wheel, or storage alcove for the dongle on the underside like we saw in the V2 Pro. The unibody shell is now a split key cover. Is this a great loss? Not really!</p>



<p>In fact, elite gamers have been demanding lighter, simpler designs for some time now and this is exactly what Razer has given us here. It&rsquo;s the kind of simplicity we&rsquo;re seeing in near rivals too, like the Logitech G X Pro Superlight. Plus, without extra buttons on top to worry about, there&rsquo;s no reason to stress about incorporating commands into your game that you never get around to using anyway.</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="mentioned-in-this-article">
					mentioned in this article				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="logitech-g-pro-x-superlight">Logitech G Pro X Superlight</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Logitech G Pro X Superlight" class="product-widget__image" height="7560" src="https://b2c-contenthub.com/wp-content/uploads/2023/01/Lead.jpg?quality=50&amp;strip=all" width="10081" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/1475704/logitech-g-pro-x-superlight-wireless-gaming-mouse-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.logitechg.com/en-us/products/gaming-mice/pro-x-superlight-wireless-mouse.910-005878.html&amp;xcust=2-1-1663595-5-1474582-17250&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">$159.99 at  Logitech G</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p>If you&rsquo;re a little worried by that and thinking I <em>do</em> use my DPI button a lot right about now, that&rsquo;s all well and good&mdash;you still can. It&rsquo;s located on the underside, and doubles as a power button. It&rsquo;s very small but switches you through your five DPI settings with just soft presses.</p>



<p>A decent contingent of 100 percent PTFE feet also line the underside, including around the sensor, so the V3 Pro moves like an absolute ninja across your mouse mat or tabletop.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Razer DeathAdder V3 Pro " class="wp-image-1663637" height="900" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/20230318_081435.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>The Razer DeathAdder V3 Pro&rsquo;s DPI button is located on its underside.&nbsp;</p>
</figcaption></figure><p class="imageCredit">Dominic Bayley / IDG</p></div>



<h3 id="razer-deathadder-v3-pro-connectivity">Razer DeathAdder V3 Pro connectivity</h3>



<p>Both wired and wireless connectivity options are available, so you can either tether the V3 Pro to a desktop or take it on the road for your next competitive match. Wireless connectivity comes courtesy of a tiny and unobtrusive USB adapter, which provides a low-latency 2.4GHz Wi-Fi connection.</p>



<p>The V3 also comes with a bunch of useful accessories, which for my white review unit, were also conveniently colored a matching white. They include: a handy USB dongle adapter and very flexible shoelace-like Razer Speedflex USB-A to USB-C cable, which doubles as both the wired adapter and a charger. The V3 Pro provides approximately 90 hours of battery life once fully charged and requires roughly four hours to charge to full capacity. </p>



<h3 id="razer-deathadder-v3-pro-performance">Razer DeathAdder V3 Pro performance </h3>



<p>The Razer DeathAdder V3 Pro has a sensor worthy of serious respect. It&rsquo;s a Razer Focus Pro 30K Optical Sensor, which has a maximum resolution of 30,000 DPI, maximum speed of 750 IPS (inches per second) and acceleration of 70G.</p>



<p>That said, it didn&rsquo;t take me long to realize I was in the presence of sensor royalty[&mdash;it just felt so smooth, quick and responsive in my playtesting. <em>In Counter Strike: Global Offensive</em>, for example, panning my crosshairs while strafing was so effortless that I found I could hit targets with minimal concentration and in a relaxed state of mind&mdash;which had carry-on benefits to my overall performance.</p>



<p>Switching up DPIs didn&rsquo;t change that feeling, I found I could land my crosshairs on targets without over spinning or being too far off kilter&mdash;just faster than before, which is exactly what I was hoping for in a mouse of this caliber.</p>



<p>The sensor&rsquo;s default polling rate is 1,000Hz, and quite frankly to me this default setting hits a performance peak that&rsquo;s already pretty impressive. Imagine, then, my surprise to learn the V3 Pro is also capable of hyper polling up to whopping 4,000Hz.</p>



<p>For that you&rsquo;ll need to purchase a Razer HyperPolling dongle for an extra $29.99. While we would have preferred it to have been included in the box, the very fact this upgrade is available is a big win for anyone who purchases the V3 Pro and wants to take the plunge to fine-tune their mouse&rsquo;s performance even further. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Razer HyperPolling dongle" class="wp-image-1663659" height="759" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/RZR_Hyperpooling_Wireless_Dongle_2022_Render03.png?w=1200" width="1200" /><figcaption><p>The V3 Pro&rsquo;s 1,000Hz polling rate is upgradeable to 4,000Hz by purchasing a $29.99 Razer HyperPolling dongle.&nbsp;</p> </figcaption></figure><p class="imageCredit">Razer</p></div>



<p>On to evaluating the buttons, and I was also well impressed by their speed. Razer has upgraded to Gen 3 Optical Switches, which in our review of the Razer Naga V2 Pro, felt a bit stiff and tight, but much to my delight, the same switches were perfectly soft and clicky in the V3 Pro.</p>



<p>They registered clicks cleanly even while jitter clicking&mdash;which was particularly noticeable when I was laying down rounds with the <em>Counter Strike</em> AUG, which is best used with a clicky finger.</p>



<p>Scoping with the AWP was also noticeably faster than I&rsquo;ve experienced with other mice, allowing me to get the edge on foes in hard-to-see corner positions, and better still, when I was surprised at close range by players with more rapidly firing weapons and I had to react quickly.</p>



<p>As mentioned before, thanks to its ultra-lightweight body the V3 Pro is also incredibly quick off the mark. It felt so weightless that at times it was almost like I was moving a tiny cardboard box around. Consequently, I never experienced any hand or arm soreness. I was also delighted to see that my V3 Pro tracked flawlessly on my glass coffee table, which I made every use of for some laid-back couch gaming.</p>



<h3 id="razer-deathadder-v3-pro-software">Razer DeathAdder V3 Pro software</h3>



<p>Razer&rsquo;s Synapse software is a detailed app that lets you take advantage of every extra technology the V3 Pro&rsquo;s sensor has to offer. To that end, I had lots of fun tinkering with features like &ldquo;Asymmetric Cut-off distance,&rdquo; which allowed me to set my lift-off and landing distance to one of 26 granular levels of adjustment&mdash;far more than the three I&rsquo;m used to in rivals.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Razer DeathAdder V3 Pro" class="wp-image-1663654" height="675" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Asymmetric-lift-off.png?w=1200" width="1200" /><figcaption><p>Razer&rsquo;s Synapse software app lets you set the V3 Pro&rsquo;s lift-off and landing distance to one of 26 granular distances.&nbsp;</p> </figcaption></figure><p class="imageCredit">Dominic Bayley / IDG</p></div>



<p>You can also easily assign your buttons, set up your preferred DPI settings, and save your onboard memory profiles in the Razer Synapse app, which is very straightforward and easy to use.</p>



<h3 id="should-you-buy-the-razer-deathadder-v3-pro">Should you buy the Razer DeathAdder V3 Pro?</h3>



<p>Summarizing my thoughts about the V3 isn&rsquo;t hard. In short, it&rsquo;s brilliant, living up to every bit of hype when it comes to speed and responsiveness. Its ultra-light weight makes it an absolute pleasure to use all day long, too. Admittedly, at $149,99 it&rsquo;s not cheap, but that&rsquo;s roughly what the best competitive mice cost these days. Near rival the Logitech G Pro X Superlight, for instance, is a little more expensive at $159.99. Even without the $29.99 HyperPolling dongle, with the V3 Pro you&rsquo;re getting a top-notch device that will serve you extremely well when the heat is on. </p>

Gaming, Mice</div>

## Get a special discount on more than 100 hours of CompTIA certification training
 - [https://www.pcworld.com/article/1674676/get-a-special-discount-on-more-than-100-hours-of-comptia-certification-training.html](https://www.pcworld.com/article/1674676/get-a-special-discount-on-more-than-100-hours-of-comptia-certification-training.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-29 08:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>For many people, being tech-savvy or invested in cybersecurity means simply having a&nbsp;<a href="https://www.pcworld.com/article/407092/best-password-managers-reviews-and-buying-advice.html" rel="noreferrer noopener" target="_blank">password manager</a>. You probably know that isn&rsquo;t exactly a comprehensive IT and cybersecurity solution. If you&rsquo;re interested in a career in IT or cybersecurity, CompTIA is one of the most important vendor-neutral certifying bodies to know.</p>



<p>CompTIA certifications can help make you eligible for certain positions and raise your earning potential. Now through April 3, you can work towards a variety of CompTIA certifications for a special deal. That&rsquo;s because&nbsp;<a href="https://shop.pcworld.com/sales/the-complete-2023-comptia-certification-course-super-bundle?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=the-complete-2023-comptia-certification-course-super-bundle&amp;utm_term=scsf-567452&amp;utm_content=a0x1P0000058XwwQAE&amp;scsonar=1" rel="noreferrer noopener" target="_blank">The Complete 2023 CompTIA Certification Course Super Bundle</a>&nbsp;is an extra $15 off the previously discounted price at $54.97.</p>



<p>The bundle includes training materials for 13 CompTIA certification exams, including CompTIA IT Fundamentals+ (FC0-U61), CompTIA A+ Core (220-1101), CompTIA Network+ (N10-008), CompTIA Cloud+ (CV0-003), CompTIA PenTest+ (PT0-002), and more. All told, it&rsquo;s nearly 250 hours of training resources that can help you level up a tech career.</p>



<p>Take advantage of this limited-time pricing during our Spring Digital Blowout. Now through April 3, get&nbsp;<a href="https://shop.pcworld.com/sales/the-complete-2023-comptia-certification-course-super-bundle?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=the-complete-2023-comptia-certification-course-super-bundle&amp;utm_term=scsf-567452&amp;utm_content=a0x1P0000058XwwQAE&amp;scsonar=1" rel="noreferrer noopener" target="_blank">The Complete 2023 CompTIA Certification Course Super Bundle</a>&nbsp;for just $54.97 (reg. $3,887).</p>



<p><a href="https://shop.pcworld.com/sales/the-complete-2023-comptia-certification-course-super-bundle?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=the-complete-2023-comptia-certification-course-super-bundle&amp;utm_term=scsf-567452&amp;utm_content=a0x1P0000058XwwQAE&amp;scsonar=1" rel="noreferrer noopener" target="_blank">&nbsp;</a></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image"><img alt="" src="https://cdnp2.stackassets.com/3dcbe21dc268c784f83b2a2e7b1dead68cd515cb/store/ede901973ccf7c0d52c94b978cdd6d199dafbd5799644133d3739bd01967/sale_317215_primary_image.jpg" /></figure></div>



<p><strong>The Complete 2023 CompTIA Certification Course Super Bundle &ndash; $69</strong></p>



<p><a href="https://shop.pcworld.com/sales/the-complete-2023-comptia-certification-course-super-bundle?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=the-complete-2023-comptia-certification-course-super-bundle&amp;utm_term=scsf-567452&amp;utm_content=a0x1P0000058XwwQAE&amp;scsonar=1" rel="noreferrer noopener" target="_blank">See Deal</a></p>



<p><em>Prices subject to change.</em></p>

Business</div>

