# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Pennsylvania DA hopeful that discovered remains belong to restaurant owner who went missing in 2017: 'closure'
 - [https://www.foxnews.com/us/pennsylvania-da-hopeful-discovered-remains-belong-restaurant-owner-went-missing](https://www.foxnews.com/us/pennsylvania-da-hopeful-discovered-remains-belong-restaurant-owner-went-missing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:44:15+00:00

Pennsylvania investigators discovered human remains on Tuesday and the DA is hopeful they belong to a restaurant owner who went missing in 2017.

## Israeli Defense Minister Yoav Gallant oversees launch of new spy satellite, raising questions about his future
 - [https://www.foxnews.com/world/israeli-defense-minister-yoav-gallant-oversees-launch-new-spy-satellite-raising-questions-future](https://www.foxnews.com/world/israeli-defense-minister-yoav-gallant-oversees-launch-new-spy-satellite-raising-questions-future)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:34:04+00:00

Israeli Defense Minister Yoav Gallant oversaw the launch of a new satellite on Wednesday, just days after Netanyahu said that he would dismiss Gallant from his post.

## Alabama police officer fatally shot, another wounded while responding to apartment shooting
 - [https://www.foxnews.com/us/alabama-police-officer-fatally-shot-another-wounded-while-responding-apartment-shooting](https://www.foxnews.com/us/alabama-police-officer-fatally-shot-another-wounded-while-responding-apartment-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:22:33+00:00

An Alabama police officer was fatally shot and another was wounded in a shooting on Tuesday afternoon. Officers were responding to a call of a woman being shot at an apartment complex.

## DOJ charges two more people for attacks against Florida pro-life pregnancy center
 - [https://www.foxnews.com/politics/doj-makes-two-more-arrests-attacks-against-florida-pro-life-pregnancy-center](https://www.foxnews.com/politics/doj-makes-two-more-arrests-attacks-against-florida-pro-life-pregnancy-center)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:20:57+00:00

The Justice Department charged two more people on Wednesday for carrying out a targeted attack on a pro-life pregnancy center in Winter Haven, Florida

## 7 California officers charged with involuntary manslaughter of man who died in custody
 - [https://www.foxnews.com/us/7-california-officers-charged-involuntary-manslaughter-man-who-died-custody](https://www.foxnews.com/us/7-california-officers-charged-involuntary-manslaughter-man-who-died-custody)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:20:38+00:00

Seven California police officers and a nurse have been charged in the death of a man who was in custody. Officials restrained the man as they tried to take a blood sample when he died.

## Florida man hides in insulation debris to evade arrest for alleged burglary: 'Stuck in an itchy situation'
 - [https://www.foxnews.com/us/florida-man-hides-insulation-debris-evade-arrest-for-alleged-burglary-stuck-itchy-situation](https://www.foxnews.com/us/florida-man-hides-insulation-debris-evade-arrest-for-alleged-burglary-stuck-itchy-situation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:19:21+00:00

An alleged burglar in Florida tried to hide from authorities under a pile of home insulation, with his face near an air duct so he could breathe

## Suspect in critical condition after Indianapolis police shooting
 - [https://www.foxnews.com/us/suspect-critical-condition-indianapolis-police-shooting](https://www.foxnews.com/us/suspect-critical-condition-indianapolis-police-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:19:14+00:00

A suspect is in critical condition after being shot by an Indianapolis police officer Wednesday afternoon. The circumstances surrounding the incident remain unclear.

## Georgia student warns of Taylor Swift 'Eras Tour' ticket scam after thief frames her for phony sales
 - [https://www.foxnews.com/us/georgia-student-warns-taylor-swift-eras-tour-ticket-scam-after-thief-frames-her-for-phony-sales](https://www.foxnews.com/us/georgia-student-warns-taylor-swift-eras-tour-ticket-scam-after-thief-frames-her-for-phony-sales)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:17:30+00:00

A Georgia college student&apos;s identity was stolen after she was scammed by a man who claimed he had extra tickets to Taylor Swift&apos;s The Eras Tour.

## Second NJ hitman sentenced in former Menendez consultant's murder-for-hire scheme
 - [https://www.foxnews.com/us/second-nj-hitman-sentenced-former-menendez-consultants-murder-hire-scheme](https://www.foxnews.com/us/second-nj-hitman-sentenced-former-menendez-consultants-murder-hire-scheme)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:17:07+00:00

George Bratsenis, 74, was sentenced to 16 years in prison for carrying out a hit on Michael Galdieri at Democratic political consultant Sean Caddle&apos;s direction.

## Mel King, Boston civil rights figurehead and former mayoral candidate, dead at 94
 - [https://www.foxnews.com/politics/mel-king-boston-civil-rights-figurehead-former-mayoral-candidate-dead-94](https://www.foxnews.com/politics/mel-king-boston-civil-rights-figurehead-former-mayoral-candidate-dead-94)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:15:53+00:00

Mel King, a prominent civil rights figurehead in Boston credited with much of the city&apos;s progress on integration in the 1970s and 1980s, died Tuesday. He was 94.

## Sen. Kennedy surprises Mayorkas by interrupting testimony for shoulder pat, handshake after tense exchange
 - [https://www.foxnews.com/politics/sen-kennedy-surprises-mayorkas-interrupting-testimony-shoulder-pat-handshake-tense-exchange](https://www.foxnews.com/politics/sen-kennedy-surprises-mayorkas-interrupting-testimony-shoulder-pat-handshake-tense-exchange)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:14:47+00:00

Secretary Alejandro Mayorkas was on the receiving end of a shoulder pat and firm handshake on Wednesday from Sen. John Kennedy after a tough exchange on assault weapons.

## Kansas man who tried to throw woman from bridge pleads no contest
 - [https://www.foxnews.com/us/kansas-man-tried-throw-woman-bridge-pleads-no-contest](https://www.foxnews.com/us/kansas-man-tried-throw-woman-bridge-pleads-no-contest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:14:44+00:00

Adam Amyx Jr. of Lawrence, Kansas, pleaded no contest to attempted second-degree murder Wednesday over a 2022 incident in which he attempted to throw a woman from a bridge.

## Padres coach diagnosed with cancer just before Opening Day
 - [https://www.foxnews.com/sports/matt-williams-padres-coach-diagnosed-cancer-just-before-opening-day](https://www.foxnews.com/sports/matt-williams-padres-coach-diagnosed-cancer-just-before-opening-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:12:41+00:00

San Diego Padres third base coach Matt Williams to take a leave of absence after Opening Day following a colon cancer diagnosis a few weeks ago.

## 49ers CEO Jed York says no regrets in drafting Trey Lance: 'I wouldn’t change anything'
 - [https://www.foxnews.com/sports/49ers-ceo-jed-york-says-no-regrets-drafting-trey-lance-i-wouldnt-change-anything](https://www.foxnews.com/sports/49ers-ceo-jed-york-says-no-regrets-drafting-trey-lance-i-wouldnt-change-anything)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 19:04:17+00:00

San Francisco 49ers rookie QB and last pick in the 2022 NFL Draft Brock Purdy is the likely starter next season, injury permitting, but CEO Jed York is still confident in Trey Lance.

## Jets’ Woody Johnson ‘anxious’ over potential Aaron Rodgers trade: ‘We’ve got to win’
 - [https://www.foxnews.com/sports/jets-woody-johnson-anxious-over-potential-aaron-rodgers-trade-weve-got-win](https://www.foxnews.com/sports/jets-woody-johnson-anxious-over-potential-aaron-rodgers-trade-weve-got-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:59:50+00:00

The waiting game continues between the New York Jets and the Green Bay Packers over a potential trade involving Aaron Rodgers, and it’s leaving owner Woody Johnson feeling “anxious.&quot;

## Plaintiff in Gwyneth Paltrow ski crash blames actress for three 'near-death experiences' post collision
 - [https://www.foxnews.com/entertainment/plaintiff-gwyneth-paltrow-ski-crash-blames-actress-three-near-death-experiences-post-collision](https://www.foxnews.com/entertainment/plaintiff-gwyneth-paltrow-ski-crash-blames-actress-three-near-death-experiences-post-collision)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:57:28+00:00

Gwyneth Paltrow&apos;s legal team called expert witnesses to testify against plaintiff&apos;s claims of permanent injuries on sixth day of ski collision trial in Park City, Utah.

## Kyra Sedgwick jokes Kevin Bacon, husband of 35 years, fell in love on first date after she made one comment
 - [https://www.foxnews.com/entertainment/kyra-sedgwick-jokes-kevin-bacon-husband-35-years-fell-in-love-first-date-after-one-comment](https://www.foxnews.com/entertainment/kyra-sedgwick-jokes-kevin-bacon-husband-35-years-fell-in-love-first-date-after-one-comment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:49:12+00:00

Kyra Sedgwick said she and Kevin Bacon both fell in love after their first date. The couple met on the set of 1987&apos;s &quot;Lemon Sky&quot; and married a year later.

## More than two dozen Democrats join GOP in opposing Biden gas stove ban
 - [https://www.foxnews.com/politics/democrats-republicans-gas-stove-ban](https://www.foxnews.com/politics/democrats-republicans-gas-stove-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:46:30+00:00

The House of Representatives passed an amendment to the GOP&apos;s big energy bill on Wednesday that would stop the Biden administration from enacting its proposed rule on gas stoves

## Florida alligator seemingly eats smaller alligator in rare wildlife encounter: 'Scary show'
 - [https://www.foxnews.com/lifestyle/florida-alligator-seemingly-eats-smaller-alligator-rare-wildlife-encounter-scary-show](https://www.foxnews.com/lifestyle/florida-alligator-seemingly-eats-smaller-alligator-rare-wildlife-encounter-scary-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:43:45+00:00

A woman photographs an alligator eating what she believes to be another alligator at Orlando Wetlands Park in Florida, but social media users think it could be something else.

## NFL owners vote to allow sportsbooks inside stadiums: report
 - [https://www.foxnews.com/sports/nfl-owners-vote-allow-sportsbooks-inside-stadiums-report](https://www.foxnews.com/sports/nfl-owners-vote-allow-sportsbooks-inside-stadiums-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:42:16+00:00

Once unthought of, NFL owners have voted to allow sportsbooks inside their own stadiums, and fans will be able to bet during the games.

## Biden admin led massive 'speech censorship operation,' former state AG will testify
 - [https://www.foxnews.com/politics/biden-admin-colluded-with-social-media-giants-to-censor-free-speech-missouri-louisiana-officials-to-say](https://www.foxnews.com/politics/biden-admin-colluded-with-social-media-giants-to-censor-free-speech-missouri-louisiana-officials-to-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:41:55+00:00

FIRST ON FOX: The Biden administration has led “the largest speech censorship operation in recent history&quot; by working with social media companies to suppress and censor information that was later admitted to be “truthful or credible,&quot; former Missouri attorney general, now-Sen. Eric Schmitt is expected to tell the House Weaponization Committee Thursday.

## Florida man, 67, bitten by shark while kitesurfing, wife heard his screams, officials say
 - [https://www.foxnews.com/us/florida-man-67-bitten-shark-while-kitesurfing-wife-heard-his-screams-officials-say](https://www.foxnews.com/us/florida-man-67-bitten-shark-while-kitesurfing-wife-heard-his-screams-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:39:27+00:00

A 67-year-old man was bitten by a shark over the weekend while kiteboarding six miles from the shore of Key West, Florida and his wife could hear his screams from their boat.

## GOP congressman, 80 pastors sing ‘Amazing Grace’ in Capitol Rotunda
 - [https://www.foxnews.com/politics/gop-congressman-80-pastors-sing-amazing-grace-capitol-rotunda](https://www.foxnews.com/politics/gop-congressman-80-pastors-sing-amazing-grace-capitol-rotunda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:38:27+00:00

Louisiana GOP Rep. Mike Johnson led a tour of 80 pastors and their spouses from 16 states that broke into a soulful rendition of &quot;Amazing Grace&quot; in the Capitol Rotunda.

## Lions reunite with veteran wide receiver on one-year deal: report
 - [https://www.foxnews.com/sports/lions-reunite-veteran-wide-receiver-one-year-deal-report](https://www.foxnews.com/sports/lions-reunite-veteran-wide-receiver-one-year-deal-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:38:20+00:00

The Detroit Lions are bringing a familiar face back into the building after veteran wide receiver Marvin Jones reportedly signed a one-year deal.

## New York Times union members stage major newsroom disruption to protest expired contract
 - [https://www.foxnews.com/media/new-york-times-union-members-stage-major-newsroom-disruption-protest-expired-contract](https://www.foxnews.com/media/new-york-times-union-members-stage-major-newsroom-disruption-protest-expired-contract)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:30:22+00:00

Unionized New York Times staffers made a lot of noise in the newsroom over the two-year anniversary of their expired contract and not having received raises in three years.

## Avian flu detected in California mountain lions as outbreak grows
 - [https://www.foxnews.com/us/avian-flu-detected-in-california-mountain-lions-as-outbreak-grows](https://www.foxnews.com/us/avian-flu-detected-in-california-mountain-lions-as-outbreak-grows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:25:25+00:00

California wildlife researchers have detected the presence of the highly pathogenic avian influenza in two mountain lions amid an ongoing outbreak.

## '$5 million is too little:' Activists tell California reparations committee to aim higher
 - [https://www.foxnews.com/politics/5-million-too-little-activists-tell-california-reparations-committee-aim-higher](https://www.foxnews.com/politics/5-million-too-little-activists-tell-california-reparations-committee-aim-higher)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:24:56+00:00

Activists demanded California pay millions of dollars to each Black resident in reparations, dismissing payments of $5 million per person as &quot;nothing&quot; and &quot;too little.&quot;

## Philadelphia teen told mom 'I love you' before being killed on the way to school
 - [https://www.foxnews.com/us/philadelphia-teen-told-mom-love-you-before-being-killed-way-school](https://www.foxnews.com/us/philadelphia-teen-told-mom-love-you-before-being-killed-way-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:24:15+00:00

15-year-old Devin Weedon told his mother he loved her shortly before he was shot and killed on his way to Simon Gratz High School in Philadelphia, Pennsylvania on Monday.

## Mississippi woman arrested after allegedly shooting gun into car full of children
 - [https://www.foxnews.com/us/mississippi-woman-arrested-allegedly-shooting-gun-car-full-children](https://www.foxnews.com/us/mississippi-woman-arrested-allegedly-shooting-gun-car-full-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:13:56+00:00

A Gulfport, Mississippi woman was arrested on Monday after allegedly getting into a fight with another woman and shooting a gun into a car full of children.

## Feds examine gas pipeline at Pennsylvania chocolate factory blast site
 - [https://www.foxnews.com/us/feds-examine-gas-pipeline-pennsylvania-chocolate-factory-blast-site](https://www.foxnews.com/us/feds-examine-gas-pipeline-pennsylvania-chocolate-factory-blast-site)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:05:10+00:00

National Transportation Safety Board investigators are examining a natural gas pipeline at the R.M. Palmer Co. factory explosion site in West Reading, Pennsylvania.

## Pro-life Wisconsin legislators eye Medicaid expansion for new moms
 - [https://www.foxnews.com/politics/pro-life-wisconsin-legislators-eye-medicaid-expansion-new-moms](https://www.foxnews.com/politics/pro-life-wisconsin-legislators-eye-medicaid-expansion-new-moms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:04:15+00:00

Anti-abortion Republican lawmakers in Wisconsin have expressed support for a proposal prolonging Medicaid eligibility and cutting some red tape for low-income mothers.

## Nevada woman arrested on suspicion of killing daughter, injuring son in house fire
 - [https://www.foxnews.com/us/nevada-woman-arrested-suspicion-killing-daughter-injuring-son-house-fire](https://www.foxnews.com/us/nevada-woman-arrested-suspicion-killing-daughter-injuring-son-house-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:03:10+00:00

A Nevada woman was arrested on suspicion of child abuse and killing her daughter in a Carson house fire. She left her children in a home which burned on Tuesday, injuring her son.

## Teen Pokémon player booted from tournament after laughing at pronoun question
 - [https://www.foxnews.com/media/teen-pokemon-player-booted-tournament-laughing-pronoun-question](https://www.foxnews.com/media/teen-pokemon-player-booted-tournament-laughing-pronoun-question)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:02:07+00:00

A Pokémon Trading Card Game player was allegedly disqualified from a tournament after letting out a nervous laugh after being asked his pronouns by a judge.

## Temple University union to proceed with no-confidence vote after president's resignation
 - [https://www.foxnews.com/us/temple-university-union-proceed-no-confidence-vote-presidents-resignation](https://www.foxnews.com/us/temple-university-union-proceed-no-confidence-vote-presidents-resignation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:01:55+00:00

Temple University&apos;s faculty union plans to proceed with a no-confidence vote on two top officials next month after the school&apos;s president, Jason Wingard, resigned.

## Fox News Poll: 4 in 10 think both Donald Trump & Hunter Biden broke the law
 - [https://www.foxnews.com/official-polls/fox-news-poll-4-in-10-think-both-donald-trump-hunter-biden-broke-law](https://www.foxnews.com/official-polls/fox-news-poll-4-in-10-think-both-donald-trump-hunter-biden-broke-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:00:07+00:00

As Hunter Biden and former President Donald Trump continue to face congressional investigations and legal challenges, large minorities of voters think each did something illegal.

## Fox News Poll: Trump’s lead grows in GOP primary race, now over 50% support
 - [https://www.foxnews.com/official-polls/fox-news-poll-trumps-lead-grows-in-gop-primary-race-now-over-50-support](https://www.foxnews.com/official-polls/fox-news-poll-trumps-lead-grows-in-gop-primary-race-now-over-50-support)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:00:05+00:00

Former President Donald Trump has expanded his lead in the Republican primary race, with Florida Governor Ron DeSantis being the only other Republican with double digit support.

## Fox News Poll: Top 5 takeaways on Biden’s economy problems
 - [https://www.foxnews.com/official-polls/fox-news-poll-top-5-takeaways-bidens-economy-problems](https://www.foxnews.com/official-polls/fox-news-poll-top-5-takeaways-bidens-economy-problems)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:00:02+00:00

35% of voters approve of President Biden&apos;s handling of the economy, 64% disapprove – with 35% of Democrats and 68% of independents giving a thumbs-down.

## Sunny Hostin on blast for latest controversial take putting US on 'same moral plateau' as China
 - [https://www.foxnews.com/media/sunny-hostin-blast-latest-controversial-take-putting-us-same-moral-plateau-china](https://www.foxnews.com/media/sunny-hostin-blast-latest-controversial-take-putting-us-same-moral-plateau-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 18:00:01+00:00

&apos;Outnumbered&apos; hosts discuss &apos;The View&apos; host Sunny Hostin comparing the U.S. and Chinese prison systems, despite claims of human rights abuses against Uyghurs.

## Kate Hudson says 'determined' mom Goldie Hawn unfairly labeled 'difficult' in 1970s, '80s Hollywood
 - [https://www.foxnews.com/entertainment/kate-hudson-says-determined-mom-goldie-hawn-unfairly-labeled-difficult-1970s-80s-hollywood](https://www.foxnews.com/entertainment/kate-hudson-says-determined-mom-goldie-hawn-unfairly-labeled-difficult-1970s-80s-hollywood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:57:29+00:00

Kate Hudson defended her mother, Goldie Hawn, this week, saying that what some had called her being &quot;difficult&quot; in working on a project, she would call &quot;determined.&quot;

## Brian Austin Green, Sharna Burgess reveal how they deal with their different parenting styles
 - [https://www.foxnews.com/entertainment/brian-austin-green-sharna-burgess-reveal-how-deal-different-parenting-styles](https://www.foxnews.com/entertainment/brian-austin-green-sharna-burgess-reveal-how-deal-different-parenting-styles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:56:53+00:00

Brian Austin Green and Sharna Burgess spoke with Fox News Digital about their lives as parents to their nine-month-old son, and revealed they have differing parenting styles.

## North Carolina's Outer Banks greeted by 13-foot great white shark named 'Breton'
 - [https://www.foxnews.com/science/north-carolinas-outer-banks-greeted-13-foot-great-white-shark-breton](https://www.foxnews.com/science/north-carolinas-outer-banks-greeted-13-foot-great-white-shark-breton)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:48:00+00:00

Researchers from the marine science non-profit OCEARCH are tracking a 13-foot great white shark named &quot;Breton&quot; off the coast of North Carolina this week.

## Chicago repeat offender charged with attacking, robbing bus employee
 - [https://www.foxnews.com/us/chicago-repeat-offender-charged-with-attacking-robbing-bus-employee](https://www.foxnews.com/us/chicago-repeat-offender-charged-with-attacking-robbing-bus-employee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:45:23+00:00

Chicago resident Pierre Lay, 35, is accused of attacking and robbing a Chicago Transportation Authority (CTA) worker on a bus. He faces felony counts of robbery and aggravated battery.

## Alabama police 'charge' elusive pony Ginuwine with resisting arrest, disorderly conduct
 - [https://www.foxnews.com/us/alabama-police-charge-elusive-pony-ginuwine-with-resisting-arrest-disorderly-conduct](https://www.foxnews.com/us/alabama-police-charge-elusive-pony-ginuwine-with-resisting-arrest-disorderly-conduct)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:39:06+00:00

A runaway pony in an Alabama neighborhood stirred up trouble for police who were attempting to capture the animal by luring the horse with pizza crust and peppermints.

## Tampa school board bans 'This Book Is Gay' from middle school libraries: Book detailed sex apps, hookups
 - [https://www.foxnews.com/media/tampa-school-board-bans-this-book-gay-from-middle-school-libraries-book-detailed-sex-apps-hookups](https://www.foxnews.com/media/tampa-school-board-bans-this-book-gay-from-middle-school-libraries-book-detailed-sex-apps-hookups)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:37:09+00:00

The Hillsborough County school board voted in favor of banning &quot;This Book Is Gay&quot; from middle schools in the district, amid a tense meeting.

## NBA champion hired to coach alma mater's rival: ‘Go Bears!’
 - [https://www.foxnews.com/sports/nba-champion-hired-coach-alma-maters-rival-go-bears](https://www.foxnews.com/sports/nba-champion-hired-coach-alma-maters-rival-go-bears)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:35:04+00:00

The Cal Golden Bears announced the hiring of Utah Valley coach Mark Madsen on Wednesday. Madsen won two NBA championships in his career after four years at Stanford.

## War over the corporate kingdom: DeSantis' new board spars for control with Disney
 - [https://www.foxnews.com/politics/war-corporate-kingdom-desantis-new-board-spars-control-disney](https://www.foxnews.com/politics/war-corporate-kingdom-desantis-new-board-spars-control-disney)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:28:34+00:00

Gov. Ron DeSantis&apos; new board controlling aspects of Disney World&apos;s land says the company attempted an 11th hour change to rules governing the property.

## Bronny James' McDonald's All-American performance has NBA scouts impressed: report
 - [https://www.foxnews.com/sports/bronny-james-mcdonalds-all-american-performance-nba-scouts-impressed-report](https://www.foxnews.com/sports/bronny-james-mcdonalds-all-american-performance-nba-scouts-impressed-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:26:01+00:00

There were some naysayers who said Bronny James, the son of LeBron James, might not fare well at the McDonald&apos;s All-American Game. He proved them wrong with NBA scouts liking his game.

## Florida sees fewer manatee starvation deaths as feeding ends
 - [https://www.foxnews.com/us/florida-sees-fewer-manatee-starvation-deaths-feeding-ends](https://www.foxnews.com/us/florida-sees-fewer-manatee-starvation-deaths-feeding-ends)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:22:54+00:00

Florida is seeing fewer deaths from manatee starvation as feeding for the winter season ends. Thousands of pounds of lettuce were provided to hundreds of manatees at a power plant site

## Manhattan grand jury won't meet on Trump case until April 24: source
 - [https://www.foxnews.com/politics/manhattan-grand-jury-wont-meet-trump-case-april-24-source](https://www.foxnews.com/politics/manhattan-grand-jury-wont-meet-trump-case-april-24-source)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:22:22+00:00

The grand jury hearing evidence in the Manhattan District Attorney’s investigation into former President Donald Trump will not sit on the case again until April 24, a court administration source told Fox News.

## Vermont deputy sheriff charged for upstate New York gunfight that injured 3
 - [https://www.foxnews.com/us/vermont-deputy-sheriff-charged-upstate-new-york-gunfight-injured-3](https://www.foxnews.com/us/vermont-deputy-sheriff-charged-upstate-new-york-gunfight-injured-3)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:20:18+00:00

Rutland County, Vermont deputy Vito Caselnova pleaded not guilty to attempted murder and gun possession charges over his alleged role in a New York State gunfight last year.

## Oil giants offer $264M for Gulf of Mexico drilling rights
 - [https://www.foxnews.com/politics/oil-giants-offer-264m-gulf-mexico-drilling-rights](https://www.foxnews.com/politics/oil-giants-offer-264m-gulf-mexico-drilling-rights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:18:10+00:00

Oil companies have offered a combined $264 million in a drilling rights auction, which was mandated under a compromise reached last year over a federal climate bill.

## Man indicted in death of still-missing Mississippi student
 - [https://www.foxnews.com/us/man-indicted-death-still-missing-mississippi-student](https://www.foxnews.com/us/man-indicted-death-still-missing-mississippi-student)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:16:55+00:00

A man has been indicted in the death of a still-missing University of Mississippi student. The LGBTQ student went missing last summer and his body has not been found.

## Maine's AG sues manufacturers over forever chemical contamination
 - [https://www.foxnews.com/us/maines-ag-sues-manufacturers-forever-chemical-contamination](https://www.foxnews.com/us/maines-ag-sues-manufacturers-forever-chemical-contamination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:14:37+00:00

Maine&apos;s Attorney General is suing manufacturers of a forever chemical that contaminated farms and wells. The lawsuit says the company knew about the toxicity for decades.

## Pennsylvania Sen. John Fetterman planning to return to Senate in mid-April after depression treatment
 - [https://www.foxnews.com/politics/pennsylvania-sen-john-fetterman-planning-return-senate-mid-april-depression-treatment](https://www.foxnews.com/politics/pennsylvania-sen-john-fetterman-planning-return-senate-mid-april-depression-treatment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:13:39+00:00

Senator John Fetterman is expected to return to work after being treated for depression at an inpatient facility, months after he beat Dr. Mehmet Oz in the election.

## US backs international court to prosecute Russian crimes in Ukraine
 - [https://www.foxnews.com/us/us-backs-international-court-prosecute-russian-crimes-ukraine](https://www.foxnews.com/us/us-backs-international-court-prosecute-russian-crimes-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:12:41+00:00

The U.S. has offered support for creation of an international court to investigate crimes perpetrated by Russia in the course of its invasion in Ukraine.

## MA pizzeria owner accused of verbally, physically abusing migrant workers faces new charges
 - [https://www.foxnews.com/us/ma-pizzeria-owner-accused-verbally-physically-abusing-migrant-workers-faces-new-charges](https://www.foxnews.com/us/ma-pizzeria-owner-accused-verbally-physically-abusing-migrant-workers-faces-new-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:08:45+00:00

Stavros Papantoniadis, who owns two Stash&apos;s Pizza locations in Boston, has been indicted on four counts of forced labor and three counts of attempted forced labor.

## Warriors’ Steve Kerr hopeful Andrew Wiggins will return this season, says he’s ‘working out every day’
 - [https://www.foxnews.com/sports/warriors-steve-kerr-hopeful-andrew-wiggins-return-season-says-working-every-day](https://www.foxnews.com/sports/warriors-steve-kerr-hopeful-andrew-wiggins-return-season-says-working-every-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:07:33+00:00

Golden State Warriors head coach Steve Kerr expressed hope that Andrew Wiggins would return this season, telling reporters the 2022 All-Star is working out every day.

## Nashville congressman responds to radical trans group: Turning shooter into 'martyr' is 'beyond disturbing'
 - [https://www.foxnews.com/politics/nashville-congressman-responds-to-radical-trans-group-turning-shooter-into-martyr-is-beyond-disturbing](https://www.foxnews.com/politics/nashville-congressman-responds-to-radical-trans-group-turning-shooter-into-martyr-is-beyond-disturbing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:06:58+00:00

Tennesee Republican Rep. Andy Ogles fired back at a trans group saying its attempts to turn the Nashville school shooter into a &quot;martyr&quot; is &quot;beyond disturbing.&quot;

## Georgia Tech's Brent Key makes emotional plea for 'everybody' to 'do something' after Nashville shooting
 - [https://www.foxnews.com/sports/georgia-techs-brent-key-makes-emotional-plea-everybody-do-something-nashville-shooting](https://www.foxnews.com/sports/georgia-techs-brent-key-makes-emotional-plea-everybody-do-something-nashville-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:06:50+00:00

Georgia Tech football coach Brent Key said he would not make a political or religious statement on the Nashville school shooting, but he did get emotional.

## Pennsylvania hit with wave of fake active-shooter calls, bomb threats to schools after Nashville tragedy
 - [https://www.foxnews.com/us/pennsylvania-hit-with-wave-fake-active-shooter-threats-to-schools-after-nashville-tragedy](https://www.foxnews.com/us/pennsylvania-hit-with-wave-fake-active-shooter-threats-to-schools-after-nashville-tragedy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:03:46+00:00

Pennsylvania State Police on Wednesday received a wave of calls from multiple schools in different countries reporting bomb and active-shooter threats

## White House dodges question on whether ‘assault weapons’ ban will lead to 'confiscation'
 - [https://www.foxnews.com/politics/white-house-dodges-question-whether-assault-weapons-ban-will-lead-confiscation](https://www.foxnews.com/politics/white-house-dodges-question-whether-assault-weapons-ban-will-lead-confiscation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:03:45+00:00

White House press secretary Karine Jean-Pierre dodged a question Wednesday on whether President Biden’s proposed &quot;assault weapons&quot; ban will lead to confiscation.

## Bill Clinton's political consultant says Hillary didn't win the presidency because she 'wasn't authentic'
 - [https://www.foxnews.com/media/bill-clintons-political-consultant-hillary-didnt-win-presidency-because-she-wasnt-authentic](https://www.foxnews.com/media/bill-clintons-political-consultant-hillary-didnt-win-presidency-because-she-wasnt-authentic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 17:00:15+00:00

Pollster Doug Schoen highlights noteworthy stories and powerful lessons from his nearly four-decade career working with some of the biggest names in politics.

## UK claims some 220,000 Russian casualties in war as Ukraine prepares counteroffensive
 - [https://www.foxnews.com/world/uk-claims-some-220000-russian-casualties-war-ukraine-prepares-counteroffensive](https://www.foxnews.com/world/uk-claims-some-220000-russian-casualties-war-ukraine-prepares-counteroffensive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:57:11+00:00

The U.K. on Wednesday said Russia has seen some 220,000 casualties since the war began, more than doubling the last estimate that was issued less than six months ago.

## Republicans move to dismantle DC’s police reform bill
 - [https://www.foxnews.com/politics/republicans-move-dismantle-dcs-police-reform-bill](https://www.foxnews.com/politics/republicans-move-dismantle-dcs-police-reform-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:55:10+00:00

House GOP lawmakers took a step toward gutting a DC law that was inspired by George Floyd&apos;s death, but which many Republicans say is anti-police.

## Marjorie Taylor Greene's Twitter account temporarily suspended for violating rules
 - [https://www.foxnews.com/politics/marjorie-taylor-greenes-twitter-account-temporarily-suspended-violating-rules](https://www.foxnews.com/politics/marjorie-taylor-greenes-twitter-account-temporarily-suspended-violating-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:49:26+00:00

U.S. Congress Rep. Marjorie Taylor Greene&apos;s Twitter account was suspended on Tuesday for allegedly breaking the rules when she posted about Trans Day of Vengeance.

## Minnesota mom's murder conviction overturned in death of boyfriend 'she wanted to stop talking'
 - [https://www.foxnews.com/us/minnesota-moms-murder-conviction-overturned-death-boyfriend-she-wanted-stop-talking](https://www.foxnews.com/us/minnesota-moms-murder-conviction-overturned-death-boyfriend-she-wanted-stop-talking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:44:53+00:00

A Minnesota appeals court has reversed the conviction of a Maple Grove mom who unloaded a handgun into her boyfriend, picked up another and emptied that one.

## Houston woman says squatters changed locks, took over her home with a phony lease
 - [https://www.foxnews.com/us/houston-woman-says-squatters-changed-locks-took-her-home-phony-lease](https://www.foxnews.com/us/houston-woman-says-squatters-changed-locks-took-her-home-phony-lease)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:41:40+00:00

A Houston woman says that several squatters have moved into her rental home claiming that they have a legal right to be there and the cops have said they can&apos;t help.

## Portland man arrested after terrorizing downtown area, 'chasing pedestrians' with stolen forklift: police
 - [https://www.foxnews.com/us/portland-man-arrested-after-terrorizing-downtown-area-chasing-pedestrians-stolen-forklift-police](https://www.foxnews.com/us/portland-man-arrested-after-terrorizing-downtown-area-chasing-pedestrians-stolen-forklift-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:39:02+00:00

A Portland man was arrested after allegedly chasing people in the downtown area while using a stolen forklift on Tuesday, according to the Portland Police Bureau.

## Indigenous elder says she feels 'shocked and distressed' after being removed from Obama event
 - [https://www.foxnews.com/politics/indigenous-elder-says-she-feels-shocked-distressed-after-removed-obama-event](https://www.foxnews.com/politics/indigenous-elder-says-she-feels-shocked-distressed-after-removed-obama-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:37:54+00:00

An indigenous elder was barred from performing during former President Obama&apos;s Australian speaking tour after allegedly being &quot;too difficult,&quot; according to event organizers.

## Philadelphia Police Commissioner Danielle Outlaw among four injured in car accident
 - [https://www.foxnews.com/us/philadelphia-police-commissioner-danielle-outlaw-injured-car-accident](https://www.foxnews.com/us/philadelphia-police-commissioner-danielle-outlaw-injured-car-accident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:35:23+00:00

Philadelphia&apos;s top cop was involved in a car accident Wednesday but it was not clear if anyone was injured.

## Crazy shapeshifting drone inspired by dragons forces itself around objects
 - [https://www.foxnews.com/tech/crazy-shapeshifting-drone-inspired-dragons-forces-itself-objects](https://www.foxnews.com/tech/crazy-shapeshifting-drone-inspired-dragons-forces-itself-objects)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:32:02+00:00

University of Tokyo graduate students have created drone prototypes that can change their structural shapes midair. Kurt &quot;CyberGuy&quot; Knutsson explains how they work.

## Berkeley school district pushes for reparations for Black students, creates task force
 - [https://www.foxnews.com/media/berkeley-school-district-pushes-reparations-black-students-creates-task-force](https://www.foxnews.com/media/berkeley-school-district-pushes-reparations-black-students-creates-task-force)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:30:02+00:00

A California school district is planning on forming a task force to recommend ways to pay reparations to African-American students who are descendants of slaves.

## Cyprus to crack down on fan violence at sporting events
 - [https://www.foxnews.com/world/cyprus-crack-down-fan-violence-sporting-events](https://www.foxnews.com/world/cyprus-crack-down-fan-violence-sporting-events)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:26:58+00:00

Cypriot Justice Minister Anna Koukkides-Procopiou unveiled various measures that the Mediterranean island nation plans on implementing to combat violent crowds at sporting events.

## Assad overhauls Syrian Cabinet as country's economy tanks
 - [https://www.foxnews.com/world/assad-overhauls-syrian-cabinet-countrys-economy-tanks](https://www.foxnews.com/world/assad-overhauls-syrian-cabinet-countrys-economy-tanks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:25:14+00:00

Syrian President Bashar al-Assad replaced multiple Cabinet ministers in a Wednesday shakeup, with the nation&apos;s economic crisis worsening as it enters the Muslim holy month of Ramadan.

## Memphis women’s basketball player pleads not guilty in assault case after appearing to punch BGSU player
 - [https://www.foxnews.com/sports/jamirah-shutes-memphis-womens-basketball-player-pleads-not-guilty-assault-case-appearing-punch-elissa-brett-bgsu-player](https://www.foxnews.com/sports/jamirah-shutes-memphis-womens-basketball-player-pleads-not-guilty-assault-case-appearing-punch-elissa-brett-bgsu-player)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:24:31+00:00

Bowling Green prosecutor&apos;s office confirmed Memphis guard Jamirah Shutes entered a not-guilty plea after being charged with assault following an incident at the WNIT last week.

## Georgia teens in Trent Lehrkamp torture identified by police, family asks for prayers
 - [https://www.foxnews.com/us/georgia-teens-trent-lehrkamp-torture-identified-police-family-asks-prayers](https://www.foxnews.com/us/georgia-teens-trent-lehrkamp-torture-identified-police-family-asks-prayers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:21:33+00:00

The Georgia teens involved in the horrific abuse of 19-year-old Trent Lehrkamp have been identified, police told reporters at a press conference Wednesday.

## Delta State University recruits South Carolina educator as its ninth president
 - [https://www.foxnews.com/us/delta-state-university-recruits-south-carolina-educator-its-ninth-president](https://www.foxnews.com/us/delta-state-university-recruits-south-carolina-educator-its-ninth-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:20:41+00:00

Delta State University in Mississippi is set to have a South Carolina educator as its ninth president. Daniel J. Ennis is scheduled to assume his new post on June 1.

## Musk’s push to halt AI development makes no sense unless China is on board, GOP senator says
 - [https://www.foxnews.com/politics/musks-push-halt-ai-development-no-sense-unless-china-onboard-gop-senator-says](https://www.foxnews.com/politics/musks-push-halt-ai-development-no-sense-unless-china-onboard-gop-senator-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:19:04+00:00

Several lawmakers sounded off about an open letter backed by several tech giants that calls for a six-month pause in advanced AI development

## Texas school board takes over unilateral control of book vetting process, will exclude parents
 - [https://www.foxnews.com/media/texas-school-board-takes-unilateral-control-book-vetting-process-will-exclude-parents](https://www.foxnews.com/media/texas-school-board-takes-unilateral-control-book-vetting-process-will-exclude-parents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:17:39+00:00

A Houston school board is taking over the district’s book vetting process for rest of the school year, which excludes parents, teachers and librarians.

## Senate votes to overturn Biden eco regulation, teeing up another likely veto
 - [https://www.foxnews.com/politics/senate-votes-overturn-biden-eco-regulation-teeing-up-another-likely-veto](https://www.foxnews.com/politics/senate-votes-overturn-biden-eco-regulation-teeing-up-another-likely-veto)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:13:49+00:00

The Senate approved a bill blocking a federal environmental regulation in a bipartisan rebuke of President Biden&apos;s climate agenda, setting up a likely veto.

## Missouri man arrested after circuit judge receives racist threats
 - [https://www.foxnews.com/us/missouri-man-arrested-circuit-judge-receives-racist-threats](https://www.foxnews.com/us/missouri-man-arrested-circuit-judge-receives-racist-threats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:13:37+00:00

A Missouri man was arrested after a circuit judge received racist and abusive threats. He was charged on Tuesday with tampering with a judicial officer and harassment.

## Florida sheriff's sergeant arrested after allegedly punching referee during kids soccer game
 - [https://www.foxnews.com/sports/florida-sergeant-arrested-allegedly-punching-referee-during-kids-soccer-game](https://www.foxnews.com/sports/florida-sergeant-arrested-allegedly-punching-referee-during-kids-soccer-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:06:20+00:00

A Jacksonville Sheriff&apos;s Office homicide sergeant was arrested and charged with battery of a sports official after punching a referee at a children&apos;s soccer game.

## Missing Georgia exec found dead, rolled in carpet in Baton Rouge had fentanyl in his system: coroner
 - [https://www.foxnews.com/us/georgia-man-found-dead-rolled-carpet-baton-rouge-disappearance-drugs-his-system-coroner](https://www.foxnews.com/us/georgia-man-found-dead-rolled-carpet-baton-rouge-disappearance-drugs-his-system-coroner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 16:00:27+00:00

Nathan Millard, a Georgia man who went missing from a business trip in Baton Rouge before he turned up dead in a vacant lot, had fentanyl in his system when he died.

## Kevin Durant fires back at Charles Barkley’s ‘very sensitive’ comment: ‘This ain’t gettin tiring chuck?’
 - [https://www.foxnews.com/sports/kevin-durant-fires-back-charles-barkleys-very-sensitive-comment-this-aint-gettin-tiring-chuck](https://www.foxnews.com/sports/kevin-durant-fires-back-charles-barkleys-very-sensitive-comment-this-aint-gettin-tiring-chuck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:57:52+00:00

Kevin Durant clapped back at Hall of Famer Charles Barkley, who called the Phoenix Star &quot;very sensitive&quot; in a recent interview with &quot;60 Minutes.&quot;

## Houston veteran in wheelchair, others fight back against would-be robbers, burglars, shoot 3 within 24 hours
 - [https://www.foxnews.com/us/houston-veteran-wheelchair-fight-back-robbers-burglars-shoot-3-24-hours](https://www.foxnews.com/us/houston-veteran-wheelchair-fight-back-robbers-burglars-shoot-3-24-hours)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:49:24+00:00

Three would-be thieves were either fatally shot or wounded within a 24-span this week in the Houston area.

## Russia lists member of dissident women's punk group as wanted criminal
 - [https://www.foxnews.com/world/russia-lists-member-dissident-womens-punk-group-wanted-criminal](https://www.foxnews.com/world/russia-lists-member-dissident-womens-punk-group-wanted-criminal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:42:32+00:00

Nadezhda Tolokonnikova of Pussy Riot, an outspoken Russian punk group known for its feminist and anti-Kremlin views, has been placed in a database for wanted individuals.

## Saudi Arabia grows closer to Beijing with step toward membership in China-led security bloc
 - [https://www.foxnews.com/world/saudi-arabia-grows-closer-beijing-step-toward-membership-china-led-security-bloc](https://www.foxnews.com/world/saudi-arabia-grows-closer-beijing-step-toward-membership-china-led-security-bloc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:32:34+00:00

Saudi Arabia is moving to join the China-led Shanghai Cooperation Organization as the kingdom and other Persian Gulf states grow wary of a diminished U.S. presence in the region.

## Federal judge refuses to allow West Texas A&M drag show to proceed amid legal battle
 - [https://www.foxnews.com/politics/federal-judge-refuses-allow-west-texas-am-drag-show-proceed-legal-battle](https://www.foxnews.com/politics/federal-judge-refuses-allow-west-texas-am-drag-show-proceed-legal-battle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:31:00+00:00

Following a lawsuit over the forced cancellation of a drag show at West Texas A&amp;M, a federal judge has denied students&apos; request for a preliminary injunction that would allow the show to continue.

## Bangladeshi journalist jailed for 'spreading false news'
 - [https://www.foxnews.com/world/bangladeshi-journalist-jailed-spreading-false-news](https://www.foxnews.com/world/bangladeshi-journalist-jailed-spreading-false-news)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:30:33+00:00

Bangladeshi police have arrested journalist Samsuzzaman Shams on charges that he spread misinformation in an Independence Day report, though authorities have yet to clarify why.

## Calais Campbell, 6-time Pro Bowler, to sign 1-year deal with Falcons: report
 - [https://www.foxnews.com/sports/six-time-pro-bowler-calais-campbell-sign-one-year-deal-falcons-report](https://www.foxnews.com/sports/six-time-pro-bowler-calais-campbell-sign-one-year-deal-falcons-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:28:34+00:00

The Falcons intend to sign free-agent defensive end Calais Campbell as the team continues to revamp its roster. Campbell is coming off a three-year stint with the Ravens.

## Police search for tiger stolen from home in northern Mexico
 - [https://www.foxnews.com/us/police-search-tiger-stolen-home-northern-mexico](https://www.foxnews.com/us/police-search-tiger-stolen-home-northern-mexico)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:21:31+00:00

Police are searching for a tiger that was stolen from a home on Monday in northern Mexico. The owners had the proper paperwork to keep the five-year-old male tiger.

## Italian government endorses lab-grown food ban
 - [https://www.foxnews.com/world/italian-government-endorses-lab-grown-food-ban](https://www.foxnews.com/world/italian-government-endorses-lab-grown-food-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:20:22+00:00

Italy&apos;s right-wing government has endorsed a nationwide ban on &quot;synthetic,&quot; lab-grown food products, planning to impose steep fines on distributors caught violating the proposed law.

## Musk's proposed AI pause means China would 'race' past US with 'most powerful' tech, expert says
 - [https://www.foxnews.com/world/musks-proposed-ai-pause-means-china-would-race-past-us-most-powerful-tech-expert-says](https://www.foxnews.com/world/musks-proposed-ai-pause-means-china-would-race-past-us-most-powerful-tech-expert-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:19:30+00:00

Sultan Meghji, formerly the chief innovation officer of the FDIC, accused signatories of the letter calling for an AI development pause of acting out of self-interest.

## Mississippi jury declines felony charges for masked day care workers who scared kids
 - [https://www.foxnews.com/us/mississippi-jury-declines-felony-charges-masked-day-care-workers-scared-kids](https://www.foxnews.com/us/mississippi-jury-declines-felony-charges-masked-day-care-workers-scared-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:16:27+00:00

A jury had declined to press felony charges for day care workers who were filmed wearing Halloween masks, scaring kids. The charges were sent to a judge as misdemeanors.

## Teen fight at Ohio mall leaves 17-year-old dead
 - [https://www.foxnews.com/us/teen-fight-ohio-mall-leaves-17-year-old-dead](https://www.foxnews.com/us/teen-fight-ohio-mall-leaves-17-year-old-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:15:50+00:00

Bryanna Barozzini, 18, has been arrested and charged with murder in the fatal Sunday stabbing of a 17-year-old girl in Columbus. She has been released on $750,000 bond.

## District attorney in Alec Baldwin 'Rust' fatal shooting steps down, makes major announcement about prosecution
 - [https://www.foxnews.com/entertainment/district-attorney-alec-baldwin-rust-fatal-shooting-steps-down-makes-major-announcement-prosecution](https://www.foxnews.com/entertainment/district-attorney-alec-baldwin-rust-fatal-shooting-steps-down-makes-major-announcement-prosecution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:15:36+00:00

New Mexico First Judicial District Attorney Mary Carmack-Altwies will not personally prosecute &quot;Rust&quot; case and involuntary manslaughter charges against Alec Baldwin.

## Poland promises relief as Ukrainian grain floods market, sinks prices
 - [https://www.foxnews.com/world/poland-promises-relief-ukrainian-grain-floods-market-sinks-prices](https://www.foxnews.com/world/poland-promises-relief-ukrainian-grain-floods-market-sinks-prices)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:11:57+00:00

Polish Agriculture Minister Henryk Kowalczyk pledged nearly $300 million in relief for grain farmers and traders experiencing hardship as Ukrainian grain floods markets.

## Tennessee Valley Authority takes steps to return ancestral remains of Native Americans
 - [https://www.foxnews.com/us/tennessee-valley-authority-takes-steps-return-ancestral-remains-native-americans](https://www.foxnews.com/us/tennessee-valley-authority-takes-steps-return-ancestral-remains-native-americans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:09:43+00:00

The Tennessee Valley Authority is taking steps to return ancestral remains of Native Americans. The remains were removed from their resting places in Tennessee, Kentucky and Alabama.

## UAE man fatally jumps off balcony after killing wife, 2 kids
 - [https://www.foxnews.com/world/uae-man-fatally-jumps-balcony-killing-wife-2-kids](https://www.foxnews.com/world/uae-man-fatally-jumps-balcony-killing-wife-2-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:08:41+00:00

A man who lives in the United Arab Emirates fatally jumped off a balcony after he killed his wife and two children. The man had a confession in his clothing admitting to the slayings.

## New York has the country's most burdensome taxes: study
 - [https://www.foxnews.com/politics/new-york-countrys-most-burdensome-taxes-study](https://www.foxnews.com/politics/new-york-countrys-most-burdensome-taxes-study)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:08:36+00:00

New York imposes the most burdensome taxes on its residents as a proportion of income compared to all the other states, according to a new study.

## Taiwan president's trip to US is 'consistent' with One China policy despite Beijing uproar, White House says
 - [https://www.foxnews.com/politics/taiwan-president-trip-us-consistent-one-china-policy-beijing-uproar-white-house-says](https://www.foxnews.com/politics/taiwan-president-trip-us-consistent-one-china-policy-beijing-uproar-white-house-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:06:22+00:00

National Security Council spokesman John Kirby urged China not to overreact as Taiwanese President Tsai Ing-wen transits the United States for the seventh time.

## Biden admin bucks climate activists, holds enormous Trump-era oil and gas lease sale
 - [https://www.foxnews.com/politics/biden-admin-bucks-climate-activists-holds-enormous-trump-era-oil-gas-lease-sale](https://www.foxnews.com/politics/biden-admin-bucks-climate-activists-holds-enormous-trump-era-oil-gas-lease-sale)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:03:27+00:00

The Biden administration moved forward with an enormous 73-million-acre Gulf of Mexico fossil fuel lease sale Wednesday, bucking climate activists who opposed the action.

## 'Defund' movement ravages Austin police force: 'We can't sustain this'
 - [https://www.foxnews.com/media/defund-movement-ravages-austin-police-force-sustain](https://www.foxnews.com/media/defund-movement-ravages-austin-police-force-sustain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 15:00:21+00:00

Austin Retired Officer Association President Dennis Farris joined &quot;Fox &amp; Friends First&quot; to react to the Texas DPS needing to step in amid police shortage crisis.

## Chiefs’ Andy Reid blanks on Packers quarterback: ‘I'm trying to remember Jordan Love’
 - [https://www.foxnews.com/sports/chiefs-andy-reid-blanks-packers-quarterback-im-trying-remember-jordan-love](https://www.foxnews.com/sports/chiefs-andy-reid-blanks-packers-quarterback-im-trying-remember-jordan-love)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:59:14+00:00

Andy Reid didn’t seem to remember the Green Bay Packers rookie quarterback who got his first NFL start against the Kansas City Chiefs in 2021 when asked about it this week.

## Pope Francis hospitalized for 'respiratory infection,' will require treatment
 - [https://www.foxnews.com/world/pope-francis-hospitalized-respiratory-infection-require-treatment](https://www.foxnews.com/world/pope-francis-hospitalized-respiratory-infection-require-treatment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:53:56+00:00

Pope Francis was hospitalized after having trouble breathing and tests concluded that he has a respiratory inspection, a spokesman for the Vatican said on Wednesday.

## Dutch researchers make giant meatball using mammoth DNA
 - [https://www.foxnews.com/science/dutch-researchers-make-giant-meatball-using-mammoth-dna](https://www.foxnews.com/science/dutch-researchers-make-giant-meatball-using-mammoth-dna)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:53:50+00:00

Researchers used extinct wooly mammoth DNA to cultivate a flesh glob, which it put on display at a museum in the Netherlands and indicated may be the future of food.

## King Charles, Camilla, Queen Consort, begin new reign with world debut in Germany
 - [https://www.foxnews.com/entertainment/king-charles-camilla-queen-consort-begin-new-reign-world-debut-germany](https://www.foxnews.com/entertainment/king-charles-camilla-queen-consort-begin-new-reign-world-debut-germany)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:36:54+00:00

King Charles and Camilla, the Queen Consort, arrived in Germany for their first foreign trip as Britain&apos;s new reigning monarchs.

## Rand Paul on staffer nearly stabbed to death in DC: 'Makes me think we're in the Third World'
 - [https://www.foxnews.com/media/rand-paul-staffer-nearly-stabbed-death-dc-makes-think-third-world](https://www.foxnews.com/media/rand-paul-staffer-nearly-stabbed-death-dc-makes-think-third-world)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:30:40+00:00

Sen. Rand Paul, R-Ky., joined &quot;Fox &amp; Friends&quot; to react to the latest details from the stabbing attack on his staffer, who is recovering from life-threatening injuries.

## Colorado dentist accused of fatally poisoning wife on verge of financial ruin: court papers
 - [https://www.foxnews.com/us/colorado-dentist-accused-fatally-poisoning-wife-verge-financial-ruin-court-papers](https://www.foxnews.com/us/colorado-dentist-accused-fatally-poisoning-wife-verge-financial-ruin-court-papers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:27:57+00:00

The Colorado dentist accused of murdering his wife, Angela Craig, with arsenic-spiked protein shakes was on the verge of financial ruin, bankruptcy court records reveal.

## Kyle Rittenhouse testifies in support of North Dakota self-defense bill bolstering Second Amendment rights
 - [https://www.foxnews.com/us/kyle-rittenhouse-testifies-support-north-dakota-self-defense-bill-bolstering-second-amendment-rights](https://www.foxnews.com/us/kyle-rittenhouse-testifies-support-north-dakota-self-defense-bill-bolstering-second-amendment-rights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:24:53+00:00

Kyle Rittenhouse testified before a North Dakota committee Tuesday in favor of HB 1213, which seeks restitution for defendants found not guilty of violent crimes due to self-defense.

## Human remains found in Lake Mead are from Las Vegas man who drowned in 1974, officials say
 - [https://www.foxnews.com/us/human-remains-found-lake-mead-identified-missing-las-vegas-man/](https://www.foxnews.com/us/human-remains-found-lake-mead-identified-missing-las-vegas-man/)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:24:16+00:00

The Clark County Office of the Coroner/Medical Examiner has identified human remains found in Lake Mead last October as those of a man who vanished in the 1970s.

## Democrats reintroduce gun safety legislation immediately following Nashville school shooting
 - [https://www.foxnews.com/politics/democrats-reintroduce-gun-safety-legislation-immediately-following-nashville-school-shooting](https://www.foxnews.com/politics/democrats-reintroduce-gun-safety-legislation-immediately-following-nashville-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:15:38+00:00

Democratic lawmakers have renewed an effort to fund research at the U.S. Centers for Disease Control and Prevention that would track gun violence and study firearm safety following the Nashville school shooting.

## California hit with another storm, forcing highway closure
 - [https://www.foxnews.com/weather/california-hit-another-storm-highway-closure](https://www.foxnews.com/weather/california-hit-another-storm-highway-closure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:06:58+00:00

California was hit with a storm that sent rain and snow to different sections of the state. Storm impacts were more modest in Southern California.

## Dolly Parton and Garth Brooks to host ACM Awards in May
 - [https://www.foxnews.com/entertainment/dolly-parton-garth-brooks-host-acm-awards-may](https://www.foxnews.com/entertainment/dolly-parton-garth-brooks-host-acm-awards-may)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:05:00+00:00

Dolly Parton and Garth Brooks are set to host the Academy of Country Music Awards in May. The awards show will stream live on Amazon Prime Video on May 11.

## Fort Lauderdale-Hollywood International Airport partially evacuated for security probe
 - [https://www.foxnews.com/us/fort-lauderdale-hollywood-international-airport-partially-evacuated-security-probe](https://www.foxnews.com/us/fort-lauderdale-hollywood-international-airport-partially-evacuated-security-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:03:56+00:00

Fort Lauderdale-Hollywood International Airport was partially evacuated Tuesday for a security-related investigation. Officials were probing the baggage claim area in Terminal 1.

## Portions of Rhode Island driver's manual being eliminated following objections from activists
 - [https://www.foxnews.com/us/portions-rhode-island-drivers-manual-being-eliminated-following-objections-activists](https://www.foxnews.com/us/portions-rhode-island-drivers-manual-being-eliminated-following-objections-activists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:02:58+00:00

Certain portions of a Rhode Island state driver&apos;s manual are being eliminated. A section advising drivers not to assume a traffic stop was based on race is being removed.

## Indiana 5-year-old child fatally shoots younger brother in Lafayette apartment
 - [https://www.foxnews.com/us/indiana-5-year-old-child-fatally-shoots-younger-brother-lafayette-apartment](https://www.foxnews.com/us/indiana-5-year-old-child-fatally-shoots-younger-brother-lafayette-apartment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:01:23+00:00

A 5-year-old child fatally shot his younger brother at their apartment in Lafayette, Indiana. There was an adult present at the time of the shooting.

## Whoopi Goldberg goes off on AR-15s, calls for ban of 'that damn rifle'
 - [https://www.foxnews.com/media/whoopi-goldberg-goes-ar-15s-calls-ban-that-damn-rifle](https://www.foxnews.com/media/whoopi-goldberg-goes-ar-15s-calls-ban-that-damn-rifle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:01:05+00:00

Whoopi Goldberg said Wednesday during &quot;The View&quot; that AR-15s needed to be banned permanently,

## Atlanta Falcons owner pushing for stronger DEI efforts has donated millions to Democrats
 - [https://www.foxnews.com/politics/atlanta-falcons-owner-pushing-for-stronger-dei-efforts-donated-millions-democrats](https://www.foxnews.com/politics/atlanta-falcons-owner-pushing-for-stronger-dei-efforts-donated-millions-democrats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 14:00:39+00:00

Arthur Blank, owner of the Atlanta Falcons, said diversity, equity, and inclusion efforts should be the nation&apos;s &quot;highest priority.&quot; He&apos;s a prolific Democratic backer.

## COVID vaccines are not needed for healthy kids and teens, says World Health Organization
 - [https://www.foxnews.com/health/covid-vaccines-not-needed-healthy-kids-teens-world-health-organization](https://www.foxnews.com/health/covid-vaccines-not-needed-healthy-kids-teens-world-health-organization)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:46:34+00:00

Healthy children and teens likely don’t need COVID-19 vaccinations, according to updated guidance posted on the World Health Organization&apos;s (WHO) website on Tuesday.

## Supreme Court justices face tighter disclosure rules as senator targets 'lavish lifestyles'
 - [https://www.foxnews.com/politics/supreme-court-justices-face-tighter-disclosure-rules-senator-targets-lavish-lifestyles](https://www.foxnews.com/politics/supreme-court-justices-face-tighter-disclosure-rules-senator-targets-lavish-lifestyles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:44:41+00:00

Supreme Court justices will be under tighter scrutiny in their financial disclosures after gift and hospitality regulations were updated earlier this month.

## Censured Texas Rep. Tony Gonzales says he's a 'NO' vote on debt ceiling if GOP brings up border security bill
 - [https://www.foxnews.com/politics/censured-texas-rep-tony-gonzales-no-vote-debt-ceiling-gop-border-security-bill](https://www.foxnews.com/politics/censured-texas-rep-tony-gonzales-no-vote-debt-ceiling-gop-border-security-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:36:52+00:00

Texas Congressman Tony Gonzales declared Wednesday that he will not vote for any debt ceiling increase if House Republicans bring up border security or immigration bills that are &quot;unchristian.&quot;

## Militants kill 9 soldiers in attack on Colombia's military
 - [https://www.foxnews.com/world/militants-kill-9-soldiers-attack-colombias-military](https://www.foxnews.com/world/militants-kill-9-soldiers-attack-colombias-military)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:35:42+00:00

Militants killed nine soldiers in an attack on Colombia&apos;s military early Wednesday. This is the most serious attack by the guerillas since they resumed peace talks with the government.

## Elon Musk's AI warning is 'unprecedented' and shows 'extraordinary' level of concern, says Douglas Murray
 - [https://www.foxnews.com/media/elon-musk-ai-warning-unprecedented-shows-extraordinary-level-concern-douglas-murray](https://www.foxnews.com/media/elon-musk-ai-warning-unprecedented-shows-extraordinary-level-concern-douglas-murray)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:30:32+00:00

Fox News contributor Douglas Murray warned on &quot;Fox &amp; Friends&quot; that artificial intelligence technology is already operating at a higher level than humans.

## Joe Rogan goes off on transgender female athletes competing against biological women: 'It's f---ing maddening'
 - [https://www.foxnews.com/sports/joe-rogan-goes-off-transgender-female-athletes-competing-against-biological-women-f-ing-maddening](https://www.foxnews.com/sports/joe-rogan-goes-off-transgender-female-athletes-competing-against-biological-women-f-ing-maddening)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:29:59+00:00

Joe Rogan ranted against the emergence of transgender women athletes competing against biological females on the latest episode of his podcast.

## The 1001 hp Lamborghini Revuelto supercar will scramble your brains with speed
 - [https://www.foxnews.com/auto/lamborghini-revuelto-supercar-scramble-brains-speed](https://www.foxnews.com/auto/lamborghini-revuelto-supercar-scramble-brains-speed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:26:46+00:00

The 2024 Lamborghi Revuelto is a 1,001 hp hybrid replacement for the Aventador supercar. It&apos;s powered by a V12 engine and three electric motors.

## 16-year-old Canadian swimming sensation sets world record at trials
 - [https://www.foxnews.com/sports/16-year-old-canadian-swimming-sensation-sets-world-record-trials](https://www.foxnews.com/sports/16-year-old-canadian-swimming-sensation-sets-world-record-trials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:20:12+00:00

Summer McIntosh, 16, broke a world record in the 400-meter free on Tuesday as she prepared to race for Canada in upcoming major swimming events.

## 38 dead in Mexico fire after guards allegedly didn't let male migrants out
 - [https://www.foxnews.com/us/38-dead-mexico-fire-after-guards-allegedly-didnt-let-male-migrants-out](https://www.foxnews.com/us/38-dead-mexico-fire-after-guards-allegedly-didnt-let-male-migrants-out)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:17:06+00:00

A fire in Mexico left 38 people dead after guards didn&apos;t let migrants out. Nearly 100 migrants gathered outside the immigration facility’s doors to demand information about relatives.

## Jeremy Renner 'chose to survive' snowplow accident: 'I was awake through every moment'
 - [https://www.foxnews.com/entertainment/jeremy-renner-chose-survive-snowplow-accident-awake-through-every-moment](https://www.foxnews.com/entertainment/jeremy-renner-chose-survive-snowplow-accident-awake-through-every-moment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:16:55+00:00

Jeremy Renner is sharing the emotional details behind his snowplow accident which occurred in January. The actor says he &quot;chose to survive,&quot; while recounting the horrific details.

## Rogan fumes at media not covering Biden's missteps: 'Can't form a f---ing sentence'
 - [https://www.foxnews.com/media/rogan-fumes-media-not-covering-bidens-missteps-cant-form-f-ing-sentence](https://www.foxnews.com/media/rogan-fumes-media-not-covering-bidens-missteps-cant-form-f-ing-sentence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:16:53+00:00

Joe Rogan criticized the media during his podcast on Tuesday for ignoring President Biden&apos;s missteps and gaffes, saying Biden &quot;can&apos;t form a f---ing sentence.&quot;

## Pamela Smart, convicted of plotting with teen lover to kill husband, has New Hampshire court petition denied
 - [https://www.foxnews.com/us/pamela-smart-convicted-plotting-teen-lover-kill-husband-new-hampshire-court-petition-denied](https://www.foxnews.com/us/pamela-smart-convicted-plotting-teen-lover-kill-husband-new-hampshire-court-petition-denied)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:15:47+00:00

New Hampshire’s Supreme Court rejected the latest attempt to get a sentence reduction for Pamela Smart, who was convicted of plotting with her teen lover to have her husband killed in 1990.

## Swedish court finds woman guilty of war crimes for posing with severed heads in Syria
 - [https://www.foxnews.com/world/swedish-court-finds-woman-guilty-war-crimes-posing-severed-heads-syria](https://www.foxnews.com/world/swedish-court-finds-woman-guilty-war-crimes-posing-severed-heads-syria)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:13:40+00:00

A Swedish court has found a woman guilty of war crimes after posting photos of herself with severed heads in 2014. She pleaded not guilty and was sentenced to three months in prison.

## AZ Gov. Hobbs' press secretary resigns after tweet suggesting gun violence against 'transphobes'
 - [https://www.foxnews.com/politics/az-gov-hobbs-press-secretary-resigns-after-tweet-suggesting-gun-violence-against-transphobes](https://www.foxnews.com/politics/az-gov-hobbs-press-secretary-resigns-after-tweet-suggesting-gun-violence-against-transphobes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:08:10+00:00

Josselyn Berry, the press secretary for Arizona Democratic Gov. Katie Hobbs, has resigned after appearing to threaten gun violence against &quot;transphobes.&quot;

## Sarah Ferguson reflects on 'terrifying' Prince Philip decades after alleged fallout
 - [https://www.foxnews.com/entertainment/sarah-ferguson-reflects-terrifying-prince-philip-decades-alleged-fallout](https://www.foxnews.com/entertainment/sarah-ferguson-reflects-terrifying-prince-philip-decades-alleged-fallout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:03:26+00:00

Prince Philip, the Duke of Edinburgh who was Britain&apos;s longest-serving consort as Queen Elizabeth II&apos;s husband, died in 2021 at age 99. The queen passed away in September at age 96.

## American shot at Mexico tourist hotspot amid spring break travel fears
 - [https://www.foxnews.com/world/american-shot-mexico-tourist-hotspot-spring-break-travel-fears](https://www.foxnews.com/world/american-shot-mexico-tourist-hotspot-spring-break-travel-fears)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 13:00:42+00:00

An American tourist has been shot in Mexico in a spring break hotspot where the U.S. State Department has been warning visitors to “exercise increased caution.&quot;

## Predators offer 'a little bit of inspiration' following Nashville school shooting in win over Bruins
 - [https://www.foxnews.com/sports/predators-offer-little-bit-inspiration-following-nashville-school-shooting-win-over-bruins](https://www.foxnews.com/sports/predators-offer-little-bit-inspiration-following-nashville-school-shooting-win-over-bruins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:55:56+00:00

The Nashville Predators defeated the first-place Boston Bruins on Tuesday, one day after the school shooting that took the lives of six people, including three children.

## WWE legend John Cena approves of Iowa’s Caitlin Clark ‘you can’t see me’ taunt in historic win over Louisville
 - [https://www.foxnews.com/sports/wwe-legend-john-cena-approves-iowas-caitlin-clark-you-cant-see-me-taunt-historic-win-over-louisville](https://www.foxnews.com/sports/wwe-legend-john-cena-approves-iowas-caitlin-clark-you-cant-see-me-taunt-historic-win-over-louisville)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:55:46+00:00

Iowa’s Caitlin Clark has the support of WWE legend John Cena as the Hawkeyes head to the Final Four on Friday night following a historic win over Louisville on Sunday.

## New York man who fatally shot mother of fiancée's ex-boyfriend in RI sentenced to 2 consecutive life terms
 - [https://www.foxnews.com/us/new-york-man-fatally-shot-mother-fiancees-ex-boyfriend-ri-sentenced-2-consecutive-life-terms](https://www.foxnews.com/us/new-york-man-fatally-shot-mother-fiancees-ex-boyfriend-ri-sentenced-2-consecutive-life-terms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:55:31+00:00

Jack Doherty has received two life sentences for fatally shooting the mother of his fiancée&apos;s ex-boyfriend in Rhode Island. He got engaged to his fiancée on the day before the killing.

## Trump holds big lead over DeSantis in '24 GOP race, but most voters say he should be disqualified if indicted
 - [https://www.foxnews.com/politics/trump-holds-big-lead-desantis-24-gop-race-most-voters-say-should-disqualified-if-indicted](https://www.foxnews.com/politics/trump-holds-big-lead-desantis-24-gop-race-most-voters-say-should-disqualified-if-indicted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:53:11+00:00

Former President Trump holds a double-digit lead on Florida Gov. Ron DeSantis in a hypothetical 2024 Republican presidential nomination matchup, according to a new national poll

## Indiana child porn suspect tied to Delphi murders expected to plead guilty, leaving 'questions unanswered'
 - [https://www.foxnews.com/us/delphi-murders-case-could-be-impacted-by-indiana-child-porn-suspects-expected-guilty-plea](https://www.foxnews.com/us/delphi-murders-case-could-be-impacted-by-indiana-child-porn-suspects-expected-guilty-plea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:49:48+00:00

Kegan Kline, an Indiana child porn suspect with possible ties to the 2017 Delphi murders of two teenage girls, is set to plead guilty, leaving &quot;questions&quot; in the Delphi case.

## Nikki Haley reveals playbook for beating Donald Trump and winning the GOP presidential nomination
 - [https://www.foxnews.com/politics/nikki-haley-reveals-playbook-beating-donald-trump-winning-gop-presidential-nomination](https://www.foxnews.com/politics/nikki-haley-reveals-playbook-beating-donald-trump-winning-gop-presidential-nomination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:48:13+00:00

Republican presidential candidate Nikki Haley says her emphasis on retail style politics will help her defeat former President Donald Trump for the 2024 GOP presidential nomination

## 5 Missouri police officers injured after being struck by SUV driven by suspected drunk driver
 - [https://www.foxnews.com/us/5-missouri-police-officers-injured-being-struck-suv-driven-suspected-drunk-driver](https://www.foxnews.com/us/5-missouri-police-officers-injured-being-struck-suv-driven-suspected-drunk-driver)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:44:48+00:00

A suspected drunk driver stuck multiple police officers who were handling wreckage from another accident on Wednesday. Five officers were injured in the accident.

## Senate votes to terminate Iraq, Gulf War military authorizations
 - [https://www.foxnews.com/politics/senate-votes-terminate-iraq-gulf-war-military-authorizations](https://www.foxnews.com/politics/senate-votes-terminate-iraq-gulf-war-military-authorizations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:44:09+00:00

The House of Representatives is now expected to take up the measure, which would formally end U.S. military operations in the Iraq and Gulf Wars.

## China on ‘disturbing’ path to eclipse US military by mid-century, Milley warns
 - [https://www.foxnews.com/politics/china-disturbing-path-eclipse-us-military-mid-century-milley-warns](https://www.foxnews.com/politics/china-disturbing-path-eclipse-us-military-mid-century-milley-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:38:34+00:00

China is on a “disturbing&quot; path to become militarily “superior&quot; to the United States by mid-century, Chairman of the Joint Chiefs of Staff Gen. Mark Milley testified Wednesday.

## Garland refuses to examine civil rights claims of Jan. 6 defendants: ‘I don’t know anything’
 - [https://www.foxnews.com/politics/garland-refuses-comment-civil-rights-jan-6-defendants-dont-know-anything](https://www.foxnews.com/politics/garland-refuses-comment-civil-rights-jan-6-defendants-dont-know-anything)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:35:34+00:00

Attorney General Merrick Garland declined a request to look at whether the civil rights of some Jan. 6 defendants have been violated after being held for so long.

## WI house fire kills 3, including 83-year-old man
 - [https://www.foxnews.com/us/wi-house-fire-kills-including-83-year-old-man](https://www.foxnews.com/us/wi-house-fire-kills-including-83-year-old-man)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:35:08+00:00

Three people were killed in a house fire in Wisconsin including an 83-year-old man. Milwaukee police are asking anybody with information to contact them.

## Virginia Democrat Lamont Bagby wins special election to fill Richmond-based state Senate seat
 - [https://www.foxnews.com/politics/virginia-democrat-lamont-bagby-wins-special-election-richmond-based-state-senate-seat](https://www.foxnews.com/politics/virginia-democrat-lamont-bagby-wins-special-election-richmond-based-state-senate-seat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:32:36+00:00

Lamont Bagby, a Democrat from Virginia, won a special election to fill a seat on the state Senate. About 90% of voters voted for Bagby in the contest against Republican Stephen Imholt.

## Youth UN adviser says climate change needs to be treated like COVID-19: 'An emergency'
 - [https://www.foxnews.com/politics/youth-un-adviser-says-climate-change-needs-treated-covid-19-emergency](https://www.foxnews.com/politics/youth-un-adviser-says-climate-change-needs-treated-covid-19-emergency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:23:55+00:00

Sophia Kianni, an youth climate activist recently hired by the United Nations as an adviser, is calling for governments to implement pandemic measures to fight global warming.

## Mexican immigration guards didn't release migrants as deadly fire raged, video appears to show
 - [https://www.foxnews.com/world/mexican-immigration-guards-release-migrants-deadly-fire-raged-video-appears-show](https://www.foxnews.com/world/mexican-immigration-guards-release-migrants-deadly-fire-raged-video-appears-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:23:00+00:00

Family members of the 38 migrant men who died in a fire at an immigration facility in Ciudad Juárez want to know why guards did not release the men after the blaze started.

## DC Council chairman claims 'there is no crime crisis' in nation's capital days after Senate staffer stabbed
 - [https://www.foxnews.com/politics/dc-council-chairman-claims-no-crime-crisis-nations-capital-days-after-senate-staffer-stabbed](https://www.foxnews.com/politics/dc-council-chairman-claims-no-crime-crisis-nations-capital-days-after-senate-staffer-stabbed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:14:44+00:00

The chairman of the Washington DC city council says there is no crime crisis despite perception as Congress takes more aggressive actions on the city&apos;s laws

## NC public school says it’s looking to ‘revise campus policies’ after student straddled by drag queen
 - [https://www.foxnews.com/politics/nc-public-school-says-looking-revise-campus-policies-student-straddled-drag-queen](https://www.foxnews.com/politics/nc-public-school-says-looking-revise-campus-policies-student-straddled-drag-queen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:14:25+00:00

A North Carolina public school says it&apos;s exploring ways to &quot;revise campus policies&quot; after a video showed a drag queen straddling a young girl during an LGBTQ Pride Festival at the school.

## Rep. Hinson grills Mayorkas on budget request that mentions 'cartels' zero times
 - [https://www.foxnews.com/politics/rep-hinson-grills-mayorkas-budget-request-mentions-cartels-zero-times](https://www.foxnews.com/politics/rep-hinson-grills-mayorkas-budget-request-mentions-cartels-zero-times)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:09:13+00:00

Rep. Ashley Hinson quizzed DHS Chief Mayorkas on the lack of use of &quot;cartel&quot; in the agency&apos;s funding request -- a line of questioning Mayorkas saw as a mischaracterization.

## US Marshals were told not to arrest protesters at Supreme Court justices' homes 'unless absolutely necessary'
 - [https://www.foxnews.com/politics/us-marshals-were-told-not-arrest-protesters-supreme-court-justices-homes-unless-absolutely-necessary](https://www.foxnews.com/politics/us-marshals-were-told-not-arrest-protesters-supreme-court-justices-homes-unless-absolutely-necessary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:07:27+00:00

U.S. Marshals were advised to refrain from arresting protesters “unless absolutely necessary,&quot; according to training documents obtained by a Republican senator.

## Melissa Joan Hart helped children escape from Nashville school shooting
 - [https://www.foxnews.com/entertainment/melissa-joan-hart-helped-children-escape-nashville-school-shooting](https://www.foxnews.com/entertainment/melissa-joan-hart-helped-children-escape-nashville-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:06:33+00:00

Melissa Joan Hart, a Nashville, Tennessee, resident and mother of three, tearfully explains how she and her husband helped children and teachers escape from The Covenant School shooting on Monday.

## Actor Guy Pearce apologizes after criticizing idea that only trans actors should play trans characters
 - [https://www.foxnews.com/media/actor-guy-pearce-apologizes-criticizing-idea-only-trans-actors-should-play-trans-characters](https://www.foxnews.com/media/actor-guy-pearce-apologizes-criticizing-idea-only-trans-actors-should-play-trans-characters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:04:40+00:00

Actor Guy Pearce composed an apology letter Tuesday for tweeting out his opinion that trans actors shouldn&apos;t be limited to only trans roles in Hollywood and vice versa.

## Armed grandma stops robber in his tracks when his gun jams while robbing her food truck
 - [https://www.foxnews.com/us/armed-grandma-stops-robber-his-tracks-when-his-gun-jams-while-robbing-her-food-truck](https://www.foxnews.com/us/armed-grandma-stops-robber-his-tracks-when-his-gun-jams-while-robbing-her-food-truck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 12:00:07+00:00

Keshondra Howard Turner, 53, shot and killed a man with her legally owned gun after he tried to rob her southwest Houston soul food truck at gunpoint on Tuesday.

## Nashville Christian school shooting timeline: Audrey Hale's 14 minutes of mayhem
 - [https://www.foxnews.com/us/nashville-christian-school-shooting-timeline-audrey-hales-14-minutes-of-mayhem](https://www.foxnews.com/us/nashville-christian-school-shooting-timeline-audrey-hales-14-minutes-of-mayhem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:59:39+00:00

Nashville police raced to stop an active shooter Monday, surgically searching the Covenant School before finding murderer Audrey Hale near an upstairs window.

## First-year Mississippi State head coach won’t ‘duplicate’ Mike Leach: ‘There’s no chance in hell’
 - [https://www.foxnews.com/sports/first-year-mississippi-state-head-coach-duplicate-mike-leach-theres-chance-hell](https://www.foxnews.com/sports/first-year-mississippi-state-head-coach-duplicate-mike-leach-theres-chance-hell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:55:44+00:00

Mississippi State head coach Zach Arnett will not try to &quot;duplicate&quot; Mike Leach after his sudden passing in December. Arnett will enter his first full season as head coach.

## Garland says he’s ‘more than willing’ to testify at House Judiciary Committee after Jordan subpoena
 - [https://www.foxnews.com/politics/garland-says-hes-more-than-willing-to-testify-at-house-judiciary-committee-after-jordan-subpoena](https://www.foxnews.com/politics/garland-says-hes-more-than-willing-to-testify-at-house-judiciary-committee-after-jordan-subpoena)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:49:46+00:00

Attorney General Merrick Garland said Wednesday he is &apos;more than willing&apos; to testify at the House Judiciary Committee, which has been seeking his testimony for weeks.

## Derek Jeter congratulates Yankees' Anthony Volpe on call-up ahead of Opening Day
 - [https://www.foxnews.com/sports/derek-jeter-congratulates-yankees-anthony-volpe-call-up-ahead-opening-day](https://www.foxnews.com/sports/derek-jeter-congratulates-yankees-anthony-volpe-call-up-ahead-opening-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:45:40+00:00

Anthony Volpe is only 21 years old and will be the starting shortstop on the New York Yankees this season. He earned a congratulations from Derek Jeter.

## Pastor bats down reporter dismissing 'prayers' after Nashville shooting: 'We need to love each other'
 - [https://www.foxnews.com/media/pastor-bats-down-reporter-dismissing-prayers-nashville-shooting-we-need-love-each-other](https://www.foxnews.com/media/pastor-bats-down-reporter-dismissing-prayers-nashville-shooting-we-need-love-each-other)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:40:20+00:00

A Nashville pastor declined a reporter&apos;s question about thoughts and prayers not being enough in the wake of the Christian school shooting in Nashville.

## Judge in Alex Murdaugh trial breaks silence for first time since sentencing
 - [https://www.foxnews.com/us/judge-alex-murdaugh-trial-breaks-silence-first-time-since-sentencing](https://www.foxnews.com/us/judge-alex-murdaugh-trial-breaks-silence-first-time-since-sentencing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:36:59+00:00

Judge Clifton Newman told more than 300 students at Cleveland State University that he believes Alex Murdaugh loved his wife, Maggie, and his son, Paul – even though he murdered them.

## Temple University president resigns as Philadelphia crime concerns wreak havoc on enrollment
 - [https://www.foxnews.com/us/temple-university-president-resigns-philadelphia-crime-concerns-wreak-havoc-enrollment](https://www.foxnews.com/us/temple-university-president-resigns-philadelphia-crime-concerns-wreak-havoc-enrollment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:34:37+00:00

Temple University&apos;s first Black President Jason Wingard is resigning amid safety concerns and dropping enrollment as crime plagues the northern Philadelphia campus.

## PBS reporter Jane Ferguson ‘violently assaulted’ on New York City subway: ‘Ear ringing and face on fire’
 - [https://www.foxnews.com/media/pbs-reporter-jane-ferguson-violently-assaulted-new-york-city-subway-ear-ringing-face-fire](https://www.foxnews.com/media/pbs-reporter-jane-ferguson-violently-assaulted-new-york-city-subway-ear-ringing-face-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:31:09+00:00

PBS News reporter Jane Ferguson said she was &quot;violently assaulted&quot; on the New York City subway on Monday and a good Samaritan helped get her to safety.

## NPR sparks backlash by disputing that trans athletes have an advantage over females: 'The science is clear'
 - [https://www.foxnews.com/media/npr-sparks-backlash-disputing-trans-athletes-advantage-females-science-clear](https://www.foxnews.com/media/npr-sparks-backlash-disputing-trans-athletes-advantage-females-science-clear)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:30:30+00:00

National Public Radio forced to issue a correction on Twitter after downplaying biological differences between biological males and biological females

## Ukrainian President Volodymyr Zelenskyy invites Chinese counterpart Xi Jinping to visit his country
 - [https://www.foxnews.com/world/ukrainian-president-volodymyr-zelenskyy-invites-chinese-countrpart-xi-jinping-visit-country](https://www.foxnews.com/world/ukrainian-president-volodymyr-zelenskyy-invites-chinese-countrpart-xi-jinping-visit-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:27:46+00:00

Ukrainian President Volodymyr Zelenskyy claims he has not been in contact with Xi Jinping since the war began. Zelenskyy invited Jinping to visit Ukraine.

## Crews still working to recover 3 barges loose in Ohio River, including one carrying methanol
 - [https://www.foxnews.com/us/crews-still-working-recover-3-barges-loose-ohio-river-including-one-carrying-methanol](https://www.foxnews.com/us/crews-still-working-recover-3-barges-loose-ohio-river-including-one-carrying-methanol)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:27:11+00:00

Ten barges got loose on the Ohio River, and crews are still working to recover three of them. One of the barges is carrying a large amount of methanol.

## North Carolina state Senate votes to override Democratic Gov. Roy Cooper's veto to loosen gun restrictions
 - [https://www.foxnews.com/politics/north-carolina-state-senate-votes-override-democratic-gov-roy-coopers-veto-loosen-gun-restrictions](https://www.foxnews.com/politics/north-carolina-state-senate-votes-override-democratic-gov-roy-coopers-veto-loosen-gun-restrictions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:26:03+00:00

The state Senate in North Carolina overrides Gov. Roy Cooper&apos;s veto to loosen gun restrictions in the state. Republicans hold a supermajority in the North Carolina Senate.

## George Mason president defends Youngkin as graduation speaker: We shouldn't 'silence' different opinions
 - [https://www.foxnews.com/media/george-mason-president-defends-youngkin-graduation-speaker-silence-different-opinions](https://www.foxnews.com/media/george-mason-president-defends-youngkin-graduation-speaker-silence-different-opinions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:23:09+00:00

George Mason University President Dr. Gregory Washington released a statement Monday defending Gov. Glenn Youngkin&apos;s inclusion on a list of commencement speakers.

## Holy month of Ramadan coincides with longest drought in Somalia's history, forcing some Muslims to break fast
 - [https://www.foxnews.com/world/holy-month-ramadan-coincides-longest-drought-somalias-history-muslims-forced-break-fast](https://www.foxnews.com/world/holy-month-ramadan-coincides-longest-drought-somalias-history-muslims-forced-break-fast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:17:41+00:00

Somalia is in the midst of the longest drought on record in the country&apos;s history. It is also Ramadan and some Muslims are having to break their daily fasts to survive.

## Delaware lawmakers give final approval to legalize recreational marijuana
 - [https://www.foxnews.com/politics/delaware-lawmakers-give-final-approval-legalize-recreational-marijuana](https://www.foxnews.com/politics/delaware-lawmakers-give-final-approval-legalize-recreational-marijuana)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:14:47+00:00

The Delaware Senate gave final approval to legalize recreational marijuana to those age 21 and older. The bill also allows the establishment of a regulated cannabis industry.

## US attorney declined to prosecute 67% of arrests in DC as nation's capital suffers crime spike
 - [https://www.foxnews.com/politics/us-attorney-declined-prosecute-67-arrests-dc-nation-capital-suffers-crime-spike](https://www.foxnews.com/politics/us-attorney-declined-prosecute-67-arrests-dc-nation-capital-suffers-crime-spike)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:10:41+00:00

U.S. Attorney Matthew Graves has declined to prosecute 67% of arrests made in Washington, D.C., an outlier compared to other major cities as D.C. struggles with a crime spike.

## Webb telescope captures warped space, galaxies billions of light-years away
 - [https://www.foxnews.com/science/webb-telescope-captures-warped-space-galaxies-billions-light-years-away](https://www.foxnews.com/science/webb-telescope-captures-warped-space-galaxies-billions-light-years-away)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:06:40+00:00

The James Webb Space Telescope has captured the fabric of space-time being warped, showing a galaxy cluster 6.3 billion light-years away and the distant Cosmic Seahorse galaxy.

## Lori Vallow trial: 5 murder defendants who pointed to unknown assailants
 - [https://www.foxnews.com/us/lori-vallow-trial-5-murder-defendants-pointed-unknown-assailants](https://www.foxnews.com/us/lori-vallow-trial-5-murder-defendants-pointed-unknown-assailants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:00:27+00:00

Five convicted killers and murder suspects, including Lori Vallow, have pointed fingers at unknown assailants in their efforts to prove their own innocence.

## Parkinson's disease symptoms disappeared with exercise, man claims: ‘Use it or lose it’
 - [https://www.foxnews.com/health/parkinsons-disease-symptoms-disappeared-exercise-man-claims-use-it-lose-it](https://www.foxnews.com/health/parkinsons-disease-symptoms-disappeared-exercise-man-claims-use-it-lose-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 11:00:11+00:00

Multiple studies have shown exercise can alleviate symptoms and slow the progression of Parkinson&apos;s disease. Scott Hanley, 57, is using fitness to fight back — as are others.

## Sweden becomes 'legitimate target' by joining NATO, Russian envoy says
 - [https://www.foxnews.com/world/sweden-becomes-legitimate-target-joining-nato-russian-envoy-says](https://www.foxnews.com/world/sweden-becomes-legitimate-target-joining-nato-russian-envoy-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:58:35+00:00

Russian Ambassador to Sweden Viktor Tatarintsev warned Sweden in a statement form the embassy that pursuing membership in NATO would make them a &quot;legitimate target&quot; for Russian aggression

## Gwyneth Paltrow jurors expected to hear from her husband Brad Falchuk in ski collision trial
 - [https://www.foxnews.com/entertainment/gwyneth-paltrow-jurors-expected-hear-husband-brad-falchuk-ski-collision-trial](https://www.foxnews.com/entertainment/gwyneth-paltrow-jurors-expected-hear-husband-brad-falchuk-ski-collision-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:58:17+00:00

The jury in Gwyneth Paltrow&apos;s ski collision trial is expected to hear from Brad Falchuk, the actress&apos; husband. Paltrow has been sued for $300,000 over a 2016 ski collision.

## Adam Sandler underwent hip surgery after 'Murdery Mystery 2' filming with Jennifer Aniston
 - [https://www.foxnews.com/entertainment/adam-sandler-underwent-hip-surgery-murdery-mystery-2-filming-jennifer-aniston](https://www.foxnews.com/entertainment/adam-sandler-underwent-hip-surgery-murdery-mystery-2-filming-jennifer-aniston)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:40:42+00:00

Adam Sandler reveals the massive physical &quot;change&quot; he had after filming wrapped for his action/comedy film with Jennifer Aniston, &quot;Murder Mystery 2.&quot;

## Mets NLCS hero signs with MLB partner league team
 - [https://www.foxnews.com/sports/mets-nlcs-hero-signs-mlb-partner-league-team](https://www.foxnews.com/sports/mets-nlcs-hero-signs-mlb-partner-league-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:38:36+00:00

Daniel Murphy, who crushed the Chicago Cubs in the 2015 NLCS with the New York Mets, signed with the Long Island Ducks on Wednesday.

## 'High-priority' repeat offender in Washington flees deputies, arrested after foot chase
 - [https://www.foxnews.com/us/high-priority-repeat-offender-washington-flees-deputies-arrested-foot-chase](https://www.foxnews.com/us/high-priority-repeat-offender-washington-flees-deputies-arrested-foot-chase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:36:13+00:00

The Pierce County Sheriff&apos;s Department in Washington state took a &quot;high priority&quot; repeat offender into custody earlier this month in connection with an armed carjacking.

## Air Force secretary says he's seen nothing 'more disturbing' in 50-year career than this move by China
 - [https://www.foxnews.com/politics/air-force-secretary-says-hes-seen-nothing-more-disturbing-50-year-career-this-move-china](https://www.foxnews.com/politics/air-force-secretary-says-hes-seen-nothing-more-disturbing-50-year-career-this-move-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:34:00+00:00

Air Force Secretary Frank Kendall says China&apos;s development of its nuclear arsenal is “disturbing,&quot; and could lead to a Cold War-level threat against the U.S.

## Parents of Rand Paul staffer brutally stabbed in DC give update on his condition
 - [https://www.foxnews.com/politics/parents-rand-paul-staffer-brutally-stabbed-dc-give-update-his-condition](https://www.foxnews.com/politics/parents-rand-paul-staffer-brutally-stabbed-dc-give-update-his-condition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:33:05+00:00

Chuck and Helen Todd, parents of Sen. Rand Paul staffer Phillip Todd, provided an update on his condition after he was brutally attacked by a man with a knife in Washington, D.C.

## Coconino County, Arizona, attorney Bill Ring won’t seek reelection in 2024
 - [https://www.foxnews.com/politics/coconino-county-arizona-attorney-bill-ring-wont-seek-reelection-2024](https://www.foxnews.com/politics/coconino-county-arizona-attorney-bill-ring-wont-seek-reelection-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:31:54+00:00

Bill Ring, the Coconino County attorney in Arizona, said he won’t seek reelection next year. However, Ring has not ruled out running for another political office.

## Media critics sound alarm on ‘very strange’ IRS visit to Matt Taibbi's home during Twitter Files testimony
 - [https://www.foxnews.com/media/media-critics-sound-alarm-irs-visit-matt-taibbi-home-during-twitter-files-testimony](https://www.foxnews.com/media/media-critics-sound-alarm-irs-visit-matt-taibbi-home-during-twitter-files-testimony)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:30:10+00:00

Critics are beginning to sound the alarm Twitter Files journalist Matt Taibbi&apos;s suspiciously-timed run-in with the IRS.

## South African police launch manhunt for convicted rapist, murder who escaped from prison
 - [https://www.foxnews.com/world/south-african-police-launch-manhunt-convicted-rapist-murder-escaped-prison](https://www.foxnews.com/world/south-african-police-launch-manhunt-convicted-rapist-murder-escaped-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:29:33+00:00

A manhunt has been launched in South Africa for a convicted murderer and rapist who escaped from prison. The man was convicted of raping two women and killing one.

## North Carolina board removes 2 election officials who refused to certify their county's election results
 - [https://www.foxnews.com/politics/north-carolina-board-removes-2-election-officials-refused-certify-countys-election-results](https://www.foxnews.com/politics/north-carolina-board-removes-2-election-officials-refused-certify-countys-election-results)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:28:48+00:00

Two North Carolina local election officials were removed from their positions by a state elections board for refusing to certify the 2022 election results.

## Oklahoma man spent 'several days' with decaying corpse of lover he allegedly killed: police
 - [https://www.foxnews.com/us/oklahoma-man-spent-several-days-decaying-corpse-lover-he-allegedly-killed-police](https://www.foxnews.com/us/oklahoma-man-spent-several-days-decaying-corpse-lover-he-allegedly-killed-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:25:45+00:00

Jake Harris allegedly killed his girlfriend, Amanda Miller, in an Oklahoma City home and stayed inside with her decaying body for &quot;several days,&quot; according to police.

## Democrat warns California moving toward 'state-sanctioned kidnapping' with mental health bill for minors
 - [https://www.foxnews.com/media/democrat-warns-california-moving-toward-state-sanctioned-kidnapping-mental-health-bill-minors](https://www.foxnews.com/media/democrat-warns-california-moving-toward-state-sanctioned-kidnapping-mental-health-bill-minors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:14:34+00:00

A new California bill would given children as young as 12 years old the power to place themselves in residential shelters with the help of a counselor.

## Biden's approval drops as vast majority of Americans worry about crime in their communities
 - [https://www.foxnews.com/politics/bidens-approval-drops-vast-majority-americans-worry-crime-communities](https://www.foxnews.com/politics/bidens-approval-drops-vast-majority-americans-worry-crime-communities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:12:47+00:00

President Joe Biden&apos;s national approval rating took a nosedive over the last month, according to a new Marist Polling survey highlighting growing concerns over crime.

## College baseball game canceled in fourth inning due to ‘unplayable sod conditions’
 - [https://www.foxnews.com/sports/college-baseball-game-canceled-fourth-inning-unplayable-sod-conditions](https://www.foxnews.com/sports/college-baseball-game-canceled-fourth-inning-unplayable-sod-conditions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:10:06+00:00

Tuesday&apos;s game between the Ole Miss Rebels and the Southern Miss Golden Eagles was canceled in the fourth inning due to unplayable field conditions.

## Nikki Haley says treating shootings as only a ‘gun issue is the lazy way out’ after Nashville school tragedy
 - [https://www.foxnews.com/politics/nikki-haley-says-treating-shootings-gun-issue-lazy-way-out-nashville-school-tragedy](https://www.foxnews.com/politics/nikki-haley-says-treating-shootings-gun-issue-lazy-way-out-nashville-school-tragedy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:07:27+00:00

Republican presidential candidate Nikki Haley says school shooting focus needs to be on combating the mental health crisis rather than on new legislation banning assault weapons.

## In D.C., an undaunted Kirk Cameron is holding a public library book reading despite pushback
 - [https://www.foxnews.com/lifestyle/dc-undaunted-kirk-cameron-holding-public-library-book-reading-despite-pushback](https://www.foxnews.com/lifestyle/dc-undaunted-kirk-cameron-holding-public-library-book-reading-despite-pushback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:06:46+00:00

Kirk Cameron, the actor and writer, is holding another series of story hour book events this week in both Washington, D.C., and New York City, along with his publisher, Brave Books.

## This little country will help deliver a major blow to Putin's war
 - [https://www.foxnews.com/opinion/little-country-help-deliver-major-blow-putin-war](https://www.foxnews.com/opinion/little-country-help-deliver-major-blow-putin-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 10:00:16+00:00

This young democracy shed the yoke of Soviet occupation just a mere 33 years ago.

## NHL's Gary Bettman suggests league will reevaluate Pride-themed jersey nights amid spate of opt-outs
 - [https://www.foxnews.com/sports/nhls-gary-bettman-suggests-league-reevaluate-pride-themed-jersey-nights-spate-opt-outs](https://www.foxnews.com/sports/nhls-gary-bettman-suggests-league-reevaluate-pride-themed-jersey-nights-spate-opt-outs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:59:57+00:00

NHL Commissioner Gary Bettman says the league will have to evaluate the its teams&apos; Pride-themed nights as players decide to opt-out of wearing the warmup jerseys.

## Sanitation workers in France set to return to work, number of pension protestors shrinks
 - [https://www.foxnews.com/world/sanitation-workers-france-set-return-work-number-pension-protestors-shrinks](https://www.foxnews.com/world/sanitation-workers-france-set-return-work-number-pension-protestors-shrinks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:59:02+00:00

The pension protests in France seem to be shrinking. Sanitation workers in the country will return to work today, as trash has piled up in the city of Paris.

## Nancy Pelosi instructs Americans to vote on how politics will impact 'your life,' not 'your religion'
 - [https://www.foxnews.com/media/nancy-pelosi-instructs-americans-vote-how-politics-impact-your-life-not-your-religion](https://www.foxnews.com/media/nancy-pelosi-instructs-americans-vote-how-politics-impact-your-life-not-your-religion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:52:24+00:00

Pelosi gave advice to Americans on how to vote according to the impact that politics has on their lives, not on their religion, in an interview Tuesday.

## Beware of new MacStealer Malware that can steal your iCloud keychain data and passwords
 - [https://www.foxnews.com/tech/beware-macstealer-malware-steal-icloud-keychain-data-passwords](https://www.foxnews.com/tech/beware-macstealer-malware-steal-icloud-keychain-data-passwords)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:52:15+00:00

A new malware is infecting Mac computers. Kurt &quot;CyberGuy&quot; Knutsson explains what MacStealer does and how to keep your Apple devices safe from cybercriminals.

## FBI, US Marshals offering $20K reward in manhunt for former Maryland Gov. Larry Hogan chief of staff
 - [https://www.foxnews.com/politics/fbi-us-marshals-offering-20k-reward-manhunt-former-maryland-gov-larry-hogan-chief-staff](https://www.foxnews.com/politics/fbi-us-marshals-offering-20k-reward-manhunt-former-maryland-gov-larry-hogan-chief-staff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:41:00+00:00

The reward for information leading to the whereabouts of Roy McGrath, the former chief of staff for Maryland Gov. Larry Hogan, has risen to $20,000.

## Group of Swiss retirees take country's government to court over failure to take action on climate change
 - [https://www.foxnews.com/world/group-swiss-retirees-countrys-government-court-over-failure-action-climate-change](https://www.foxnews.com/world/group-swiss-retirees-countrys-government-court-over-failure-action-climate-change)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:31:36+00:00

Members of the Senior Women for Climate Protection are taking Switzerland&apos;s government to court over what they claim is a failure to take stronger action towards climate change.

## Cowboys' Micah Parsons teases jersey-number change, upsets NFL fans
 - [https://www.foxnews.com/sports/cowboys-micah-parsons-teases-jersey-number-change-upsets-nfl-fans](https://www.foxnews.com/sports/cowboys-micah-parsons-teases-jersey-number-change-upsets-nfl-fans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:30:59+00:00

Dallas Cowboys linebacker Micah Parsons appeared to upset fans when he teased he would wear the No. 0 in 2023 instead of No. 11

## North Carolina Senate allows domestic violence victims to testify remotely, avoid in-person run-ins
 - [https://www.foxnews.com/politics/north-carolina-senate-allows-domestic-violence-victims-testify-remotely-avoid-person-run-ins](https://www.foxnews.com/politics/north-carolina-senate-allows-domestic-violence-victims-testify-remotely-avoid-person-run-ins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:30:52+00:00

The North Carolina Senate has approved legislation that would allow domestic violence victims to testify remotely and avoid meeting the accused in person.

## GOP demands medical evidence for HHS policy pushing ‘gender affirming’ care
 - [https://www.foxnews.com/politics/gop-demands-medical-evidence-hhs-policy-pushing-gender-affirming-care](https://www.foxnews.com/politics/gop-demands-medical-evidence-hhs-policy-pushing-gender-affirming-care)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:30:06+00:00

Senator Jim Risch, R-Idaho, is leading Republicans in a letter to HHS demanding the evidence they have to push medical providers to encourage “gender-affirming&quot; care for minors.

## 2 rescued after Utah avalanche overturns, buries snowcat
 - [https://www.foxnews.com/us/2-rescued-utah-avalanche-overturns-buries-snowcat](https://www.foxnews.com/us/2-rescued-utah-avalanche-overturns-buries-snowcat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:26:17+00:00

A snowcat carrying two individuals was caught in an avalanche near Gold Ridge in Morgan County, Utah, on Tuesday and was swept into a group of trees before overturning.

## Arizona Gov. Katie Hobbs vetoes a bill banning food tax
 - [https://www.foxnews.com/politics/arizona-gov-katie-hobbs-vetoes-bill-banning-food-tax](https://www.foxnews.com/politics/arizona-gov-katie-hobbs-vetoes-bill-banning-food-tax)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:25:27+00:00

Gov. Katie Hobbs has vetoed a bill that would have prevented cities from taxing groceries. Hobbs said the food tax bill would not have eliminated costs onto consumers.

## Vietnam's economic growth comes in much weaker than expected, exporters hit by rising costs, weaker demand
 - [https://www.foxnews.com/world/vietnams-economic-growth-comes-much-weaker-expected-exporters-hit-rising-costs-weaker-demand](https://www.foxnews.com/world/vietnams-economic-growth-comes-much-weaker-expected-exporters-hit-rising-costs-weaker-demand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:25:03+00:00

Vietnamese exporters were hit by a decrease in demand and rising costs. Due to this, the country&apos;s economy slowed in the first quarter of this year.

## 33 swimmers were harassing dolphins in Hawaii, authorities said
 - [https://www.foxnews.com/us/33-swimmers-harassing-dolphins-hawaii-authorities](https://www.foxnews.com/us/33-swimmers-harassing-dolphins-hawaii-authorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:24:39+00:00

Dozens of swimmers in Hawaii allegedly harassed a pod of wild dolphins. It is illegal to swim near spinner dolphins as it can disturb the nocturnal animal’s resting period.

## Drone video captures 33 swimmers in Hawaii harassing dolphins, authorities say
 - [https://www.foxnews.com/us/drone-video-captures-33-swimmers-hawaii-harassing-dolphins-authorities](https://www.foxnews.com/us/drone-video-captures-33-swimmers-hawaii-harassing-dolphins-authorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:24:39+00:00

Dozens of swimmers in Hawaii allegedly harassed a pod of wild dolphins. It is illegal to swim near spinner dolphins as it can disturb the nocturnal animal’s resting period.

## Runaway Kentucky barge carrying methanol, 2 others pinned against dam site
 - [https://www.foxnews.com/us/runaway-kentucky-barge-carrying-methanol-2-others-pinned-dam-site](https://www.foxnews.com/us/runaway-kentucky-barge-carrying-methanol-2-others-pinned-dam-site)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:24:26+00:00

Officials in Kentucky are expected to give an update about several barges currently loose on the Ohio River Wednesday afternoon. They broke loose from a tugboat.

## DNA from half-eaten burrito ties ex-Wisconsin doctoral student to pro-life center firebombing attack
 - [https://www.foxnews.com/us/dna-half-eaten-burrito-ties-wisconsin-doctoral-student-pro-life-center-firebombing-attack](https://www.foxnews.com/us/dna-half-eaten-burrito-ties-wisconsin-doctoral-student-pro-life-center-firebombing-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:14:33+00:00

The DOJ says DNA from a half-eaten burrito tied University of Wisconsin-Madison ex-doctoral student Hridindu Sankar Roychowdhury to the Mother&apos;s Day attack on Wisconsin Family Action.

## Seamus Gray disappearance: Police say search dogs showed interest in area of Waukegan Harbor
 - [https://www.foxnews.com/us/seamus-gray-navy-sailor-disappearance-search-dogs-waukegan-harbor](https://www.foxnews.com/us/seamus-gray-navy-sailor-disappearance-search-dogs-waukegan-harbor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:06:43+00:00

Dogs participating in search efforts to find missing Navy sailor Seamus Gray took “interest&quot; in an area of Waukegan Harbor, according to the Naval Criminal Investigative Service.

## Tennessee Rep. Tim Burchett says revival, not Congress, is needed after Nashville school shooting
 - [https://www.foxnews.com/politics/tennessee-rep-tim-burchett-revival-congress-needed-after-nashville-school-shooting](https://www.foxnews.com/politics/tennessee-rep-tim-burchett-revival-congress-needed-after-nashville-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:04:22+00:00

Republican Congressman Tim Burchett of Tennessee said that lawmakers would just &quot;mess things up&quot; if Congress were to pass gun control measures after a shooter killed six people at The Covenant School in Nashville, Tennessee.

## Russia holds nuclear missile forces drills in Siberia to practice secret deployment
 - [https://www.foxnews.com/world/russia-holds-nuclear-missile-forces-drills-siberia-practice-secret-deployment](https://www.foxnews.com/world/russia-holds-nuclear-missile-forces-drills-siberia-practice-secret-deployment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:01:49+00:00

The Russian military is conducting drills in Siberia involving the mobilization of nuclear-tipped Yars missile launchers alongside thousands of troops.

## Maurice Benard reflects on 'General Hospital' success for 60th anniversary: 'There's no fans like those fans'
 - [https://www.foxnews.com/entertainment/maurice-benard-reflects-on-general-hospital-success-60th-anniversary](https://www.foxnews.com/entertainment/maurice-benard-reflects-on-general-hospital-success-60th-anniversary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 09:00:50+00:00

Maurice Benard spoke with Fox News Digital about why &quot;General Hospital&quot; has been on the air for 60 years and how special the fans of the soap opera are.

## ‘Dungeons & Dragons’ star Hugh Grant thinks Hollywood affairs would be prevalent if phones weren't on set
 - [https://www.foxnews.com/entertainment/dungeons-dragons-star-hugh-grant-thinks-hollywood-affairs-prevalent-phones-werent-set](https://www.foxnews.com/entertainment/dungeons-dragons-star-hugh-grant-thinks-hollywood-affairs-prevalent-phones-werent-set)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:58:13+00:00

Hugh Grant revealed that affairs on movie-sets would be more frequent had the world not been introduced to smartphones. The &quot;Love, Actually&quot; actor shared his sadness for the changing industry.

## Falcons' Arthur Blank explains why team is out on Lamar Jackson, faces criticism
 - [https://www.foxnews.com/sports/falcons-arthur-blank-explains-why-team-out-lamar-jackson-faces-criticism](https://www.foxnews.com/sports/falcons-arthur-blank-explains-why-team-out-lamar-jackson-faces-criticism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:39:21+00:00

Lamar Jackson could elevate the Atlanta Falcons in a weak division but team owner Arthur Blank is putting his chips in Desmond Ridder&apos;s pot.

## Sri Lanka's government announces significant cuts in fuel prices amid economic crisis
 - [https://www.foxnews.com/world/sri-lankas-government-announces-significant-cuts-fuel-prices-economic-crisis](https://www.foxnews.com/world/sri-lankas-government-announces-significant-cuts-fuel-prices-economic-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:37:12+00:00

Sri Lanka is in the midst of the worst economic crisis in the countries history. The country&apos;s government announced that there would be a significant cut in fuel prices.

## 2 high school students fatally shot in Oregon triple homicide
 - [https://www.foxnews.com/us/2-high-school-students-fatally-shot-oregon-triple-homicide](https://www.foxnews.com/us/2-high-school-students-fatally-shot-oregon-triple-homicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:33:15+00:00

A triple homicide in Portland, Oregon, killed two high school students and a 20-year-old. The victims were found shot and dead inside a car.

## New breast cancer gene can predict likelihood of hereditary disease, study finds
 - [https://www.foxnews.com/health/new-breast-cancer-gene-can-predict-likelihood-disease-study-finds](https://www.foxnews.com/health/new-breast-cancer-gene-can-predict-likelihood-disease-study-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:32:42+00:00

In what researchers describe as a landmark study, mutations in the ATRIP gene have been found to predict the likelihood of women developing hereditary breast cancer.

## Former Southern California man sentenced for convincing troubled girls to perform masochistic acts
 - [https://www.foxnews.com/us/former-southern-california-man-sentenced-convincing-troubled-girls-perform-masochistic-acts](https://www.foxnews.com/us/former-southern-california-man-sentenced-convincing-troubled-girls-perform-masochistic-acts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:23:07+00:00

A former Southern California man was sentenced to 27 years in prison for convincing young girls suffering from mental health issues to perform masochistic acts.

## Falcons billionaire owner strongly backs DEI efforts: 'Should be the highest priority for our nation'
 - [https://www.foxnews.com/sports/falcons-billionaire-owner-strongly-backs-dei-efforts-should-highest-priority-our-nation](https://www.foxnews.com/sports/falcons-billionaire-owner-strongly-backs-dei-efforts-should-highest-priority-our-nation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:09:50+00:00

Atlanta Falcons team owner Arthur Blank said efforts to support diversity, equity and inclusion efforts should be a major priority in the United States.

## Reparations for Black Californians could cost $800B, economists warn
 - [https://www.foxnews.com/politics/reparations-black-californians-would-cost-800b-economists-warn](https://www.foxnews.com/politics/reparations-black-californians-would-cost-800b-economists-warn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:09:49+00:00

California&apos;s reparations task force was informed that compensating Black residents with reparations would cost the state $800 billion, according to economists they consulted.

## Doctors in training are unionizing in record numbers today: Here's what they want
 - [https://www.foxnews.com/health/doctors-training-unionizing-record-numbers-today-heres-what-they-want](https://www.foxnews.com/health/doctors-training-unionizing-record-numbers-today-heres-what-they-want)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:08:54+00:00

Medical residents in greater numbers are joining a union to help them advocate for better training and work environments for doctors; they want better work hours and fairer pay.

## More unsettled weather forecast for West, bringing heavy snow and rain
 - [https://www.foxnews.com/us/more-unsettled-weather-forecast-west-heavy-snow-rain](https://www.foxnews.com/us/more-unsettled-weather-forecast-west-heavy-snow-rain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:07:48+00:00

While more heavy mountain snow and frigid temperatures are forecast in the West, the Plains, Midwest and Mississippi Valley will see severe weather, including the threat of tornadoes.

## Enes Kanter Freedom torches TikTok, says app un-banned him during congressional grilling
 - [https://www.foxnews.com/media/enes-kanter-freedom-torches-tiktok-says-app-un-banned-congressional-grilling](https://www.foxnews.com/media/enes-kanter-freedom-torches-tiktok-says-app-un-banned-congressional-grilling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:00:42+00:00

Former NBA star Enes Kanter Freedom joined &quot;The Ingraham Angle&quot; to respond to TikTok CEO Shou Zi Chew&apos;s grilling before Congress and his own ban on the app.

## This Supreme Court ruling could upend everything about climate change lawsuits
 - [https://www.foxnews.com/opinion/supreme-court-ruling-could-upend-everything-climate-change-lawsuits](https://www.foxnews.com/opinion/supreme-court-ruling-could-upend-everything-climate-change-lawsuits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:00:38+00:00

Progressive states and cities have launched a new frenzy of lawsuits in state courts demanding billions of dollars for damages allegedly related to climate change.

## West Virginia AG Morrisey to make 'important announcement' as he considers challenging Sen. Joe Manchin
 - [https://www.foxnews.com/politics/west-virginia-ag-morrisey-to-make-important-announcement-considers-challenging-sen-joe-manchin](https://www.foxnews.com/politics/west-virginia-ag-morrisey-to-make-important-announcement-considers-challenging-sen-joe-manchin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:00:06+00:00

West Virginia Attorney General Patrick Morrisey, a Republican, will make an “important announcement&quot; next week as rumors about his future political ambitions swirl.

## Florida plastic surgeon may have murdered missing lawyer in law firm bathroom: police
 - [https://www.foxnews.com/us/florida-plastic-surgeon-murdered-missing-lawyer-law-firm-bathroom-police](https://www.foxnews.com/us/florida-plastic-surgeon-murdered-missing-lawyer-law-firm-bathroom-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 08:00:02+00:00

The Florida plastic surgeon charged with the murder of an attorney representing his former medical practice was allegedly caught on video hauling the victim&apos;s body from his law office.

## Florida first responders rescue elderly man, 2 dogs out of sinking SUV
 - [https://www.foxnews.com/us/florida-first-responders-rescue-elderly-man-2-dogs-sinking-suv](https://www.foxnews.com/us/florida-first-responders-rescue-elderly-man-2-dogs-sinking-suv)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:57:50+00:00

A heroic water rescue by police and fire crews in a suburb of Orlando, Florida, was caught on camera. A city mayor witnessed it all go down, and plans to honor those involved.

## Kansas moves to increase legal age for buying tobacco products from 18 to 21
 - [https://www.foxnews.com/us/kansas-moves-increase-legal-age-buying-tobacco-products-18-21](https://www.foxnews.com/us/kansas-moves-increase-legal-age-buying-tobacco-products-18-21)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:42:32+00:00

Kansas&apos; state Senate approved a bill to increase the legal age of buying tobacco products from 18 to 21. Most states across the country have already done this.

## Federal judge upholds $2.4 billion bankruptcy plan for the Boy Scouts of America
 - [https://www.foxnews.com/us/federal-judge-upholds-2-4-million-bankruptcy-plan-boy-scouts-america](https://www.foxnews.com/us/federal-judge-upholds-2-4-million-bankruptcy-plan-boy-scouts-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:41:37+00:00

A federal judge upheld a $2.4 billion bankruptcy plan for the Boy Scouts of America. The organization will continue to operate as it compensates sex abuse survivors.

## Toyota becomes a patent troll with new Tacoma truck teaser
 - [https://www.foxnews.com/auto/toyota-becomes-patent-troll-tacoma-truck-tease](https://www.foxnews.com/auto/toyota-becomes-patent-troll-tacoma-truck-tease)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:27:50+00:00

Toyota has released a photo on social media that appears to tease the upcoming reveal of the next-generation Tacoma midsize pickup with clues.

## Arkansas bathroom bill revamped after being criticized as too extreme
 - [https://www.foxnews.com/politics/arkansas-bathroom-bill-revamped-being-criticized-extreme](https://www.foxnews.com/politics/arkansas-bathroom-bill-revamped-being-criticized-extreme)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:25:10+00:00

A bathroom bill in Arkansas had to be revamped after being called too extreme. The bill would criminalize the use of public bathrooms for transgender people.

## Musk calls for action as AI tech grows stronger, media's smears against Christianity and more top headlines
 - [https://www.foxnews.com/us/musk-calls-for-action-as-ai-tech-grows-stronger](https://www.foxnews.com/us/musk-calls-for-action-as-ai-tech-grows-stronger)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:23:35+00:00

Prayer mocked by media in Nashville massacre coverage, China makes serious threats and more top headlines

## Lamar Jackson pushes back on injury-prone talk: 'Let's get real'
 - [https://www.foxnews.com/sports/lamar-jackson-pushes-back-injury-prone-talk-lets-get-real](https://www.foxnews.com/sports/lamar-jackson-pushes-back-injury-prone-talk-lets-get-real)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:23:34+00:00

Lamar Jackson pushed back on the notion he was injury prone and explained he rather be 100% on the field than put his teammates in a bad position.

## New York officials can issue licenses for some recreational marijuana dispensaries after key ruling
 - [https://www.foxnews.com/us/new-york-officials-issue-licenses-recreational-marijuana-dispensaries-key-ruling](https://www.foxnews.com/us/new-york-officials-issue-licenses-recreational-marijuana-dispensaries-key-ruling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:12:50+00:00

A ruling from a New York appeals court will allow officials to hand out licenses for recreational marijuana dispensaries in certain parts of the state.

## Indiana toddler dies from gunshot wound, no arrests have been made
 - [https://www.foxnews.com/us/indiana-toddler-dies-gunshot-wound-arrests-made](https://www.foxnews.com/us/indiana-toddler-dies-gunshot-wound-arrests-made)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:11:06+00:00

Isiah Johnson, a 16-month-old from Indiana, was killed by a gunshot wound at the Romney Meadows apartment complex. Indiana police have made no arrests in the shooting so far.

## Randi Weingarten calls for gun confiscation: Must 'have the courage to do' what Australia, New Zealand did
 - [https://www.foxnews.com/media/randi-weingarten-calls-gun-confiscation-courage-australia-new-zealand](https://www.foxnews.com/media/randi-weingarten-calls-gun-confiscation-courage-australia-new-zealand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 07:00:50+00:00

American Federation of Teachers president Randi Weingarten renewed the call for an assault weapons ban in the wake of the Nashville school shooting.

## WI Supreme Court candidate jailed man 2 years for raping veteran, said ‘part of me’ wanted to give probation
 - [https://www.foxnews.com/politics/wi-supreme-court-candidate-jailed-man-2-years-raping-veteran-said-wanted-give-probation](https://www.foxnews.com/politics/wi-supreme-court-candidate-jailed-man-2-years-raping-veteran-said-wanted-give-probation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:50:44+00:00

A Wisconsin judge running for a seat on the state’s Supreme Court sentenced a man to just over two years in prison after brutally raping a military veteran.

## Chinese college nudges students to 'enjoy love' during extended spring break amid falling birthrates
 - [https://www.foxnews.com/world/chinese-college-nudges-students-enjoy-love-extended-spring-break-falling-birthrates](https://www.foxnews.com/world/chinese-college-nudges-students-enjoy-love-extended-spring-break-falling-birthrates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:48:11+00:00

Amid a declining birth rate, the Chinese government is looking to boost ways to increase the communist country&apos;s lower birth rate and overcome its negative population growth.

## Elon Musk, Apple co-founder, other tech experts call for pause on 'giant AI experiments': 'Dangerous race'
 - [https://www.foxnews.com/politics/elon-musk-apple-co-founder-tech-experts-call-pause-giant-ai-experiments](https://www.foxnews.com/politics/elon-musk-apple-co-founder-tech-experts-call-pause-giant-ai-experiments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:44:33+00:00

Tesla CEO Elon Musk and Apple co-founder Steve Wozniak are among more than 1,000 tech entrepreneurs and artificial intelligence experts who are calling for a pause on the development of AI systems more powerful than OpenAI&apos;s GPT-4.

## WATCH: Sharks swarm offshore of popular tourist beach as beachgoers keep distance
 - [https://www.foxnews.com/world/watch-sharks-swarm-offshore-popular-tourist-beach-beachgoers-keep-distance](https://www.foxnews.com/world/watch-sharks-swarm-offshore-popular-tourist-beach-beachgoers-keep-distance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:39:13+00:00

A tourism ban in 2018 and the subsequent COVID-19 pandemic in 2020 helped the sharks native to the Maya Bay return and thrive, creating a problem for Thailand&apos;s tourism.

## California is run by politicians who are '100% pro-criminal,' 30-year law enforcement veteran says
 - [https://www.foxnews.com/politics/california-run-politicians-100-pro-criminal-30-year-law-enforcement-veteran-says](https://www.foxnews.com/politics/california-run-politicians-100-pro-criminal-30-year-law-enforcement-veteran-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:30:36+00:00

The Riverside County Sheriff argues liberal state lawmakers are giving in to a &quot;far-left agenda&quot; that is fueling rising crime across parts of California.

## Law school grad says he was suspended, forced to undergo psych eval for questioning school's COVID policies
 - [https://www.foxnews.com/media/law-school-grad-says-suspended-forced-undergo-psych-eval-questioning-schools-covid-policies](https://www.foxnews.com/media/law-school-grad-says-suspended-forced-undergo-psych-eval-questioning-schools-covid-policies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:30:32+00:00

Georgetown University law school graduate William Spruance shares how he was allegedly forced to undergo a psychiatric evaluation for questioning the school&apos;s COVID policies.

## Florida Atlantic's Dusty May recalls thinking he 'just committed career suicide' taking head coaching job
 - [https://www.foxnews.com/sports/florida-atlantics-dusty-may-recalls-thinking-committed-career-suicide-taking-head-coaching-job](https://www.foxnews.com/sports/florida-atlantics-dusty-may-recalls-thinking-committed-career-suicide-taking-head-coaching-job)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:30:09+00:00

Florida Atlantic&apos;s Dusty May revealed he made a gut decision to take the Owls&apos; job and recalled his reaction once he told his wife about the job.

## Giants' John Mara calls proposal to flex games to Thursday nights 'abusive'
 - [https://www.foxnews.com/sports/giants-john-mara-calls-proposal-flex-games-thursday-nights-abusive](https://www.foxnews.com/sports/giants-john-mara-calls-proposal-flex-games-thursday-nights-abusive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:18:53+00:00

New York Giants co-owner John Mara talked about the proposal to flex &quot;Thursday Night Football&quot; games, citing potential issues for season-ticket holders.

## Democratic press secretary's tweet removed after she slams ‘transphobes’ in wake of Nashville shooting: report
 - [https://www.foxnews.com/media/democratic-press-secretarys-tweet-removed-she-slams-transphobes-wake-nashville-shooting-report](https://www.foxnews.com/media/democratic-press-secretarys-tweet-removed-she-slams-transphobes-wake-nashville-shooting-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:18:51+00:00

Josselyn Berry, the press secretary for Arizona Governor Katie Hobbs, was criticized online after she reportedly posted an image of an armed woman in a tweet about &quot;transphobes.&quot;

## Red Wings coach gets ejected after expletive-filled rant following controversial play
 - [https://www.foxnews.com/sports/red-wings-coach-gets-ejected-expletive-filled-rant-controversial-play](https://www.foxnews.com/sports/red-wings-coach-gets-ejected-expletive-filled-rant-controversial-play)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:13:14+00:00

You could not hear Detroit Red Wings head coach Derek Lalonde freaking out on the bench after a controversial call, but body language and lip reading tells you why he was ejected.

## What's worse than Florida parents calling Michelangelo's David 'porn'
 - [https://www.foxnews.com/opinion/worse-florida-parents-calling-michelangelo-david-porn](https://www.foxnews.com/opinion/worse-florida-parents-calling-michelangelo-david-porn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:00:51+00:00

The story of the Florida charter school principal who apparently lost her job over a sixth grade class viewing Michelangelo&apos;s statue of David.

## JK Rowling confronted by critics over past trans comments, asks her opponents: 'What if you're wrong?'
 - [https://www.foxnews.com/media/jk-rowling-confronted-critics-past-trans-comments](https://www.foxnews.com/media/jk-rowling-confronted-critics-past-trans-comments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:00:49+00:00

On &quot;The Witch Trials of J.K. Rowling&quot; podcast, the British author was confronted with the biggest criticisms leveled against since she entered the trans debate.

## Weingarten 'among the most dangerous' people in US, Pompeo claims in war of words with teachers union boss
 - [https://www.foxnews.com/media/weingarten-most-dangerous-people-pompeo-claims-war-words-teachers-union-boss](https://www.foxnews.com/media/weingarten-most-dangerous-people-pompeo-claims-war-words-teachers-union-boss)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 06:00:37+00:00

American Federation of Teachers President Randi Weingarten and ex-Secretary of State Mike Pompeo continued their war of words Tuesday, on &apos;The Story.&apos;

## Kamala Harris set to unveil $1 billion plan in Ghana to promote women’s economic empowerment
 - [https://www.foxnews.com/world/kamala-harris-set-unveil-1-billion-plan-ghana-promote-womens-economic-empowerment](https://www.foxnews.com/world/kamala-harris-set-unveil-1-billion-plan-ghana-promote-womens-economic-empowerment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 05:59:19+00:00

In Ghana, Vice President Kamala Harris will reveal a $1 billion plan to help bolster the country&apos;s economy as Washington looks to build relationships across Africa.

## NBC News pummeled for suggesting Tennessee's trans community is in fear due to 'focus' on Nashville shooter
 - [https://www.foxnews.com/media/nbc-news-pummeled-suggesting-tennessees-trans-community-fear-due-focus-nashville-shooter](https://www.foxnews.com/media/nbc-news-pummeled-suggesting-tennessees-trans-community-fear-due-focus-nashville-shooter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 05:52:41+00:00

NBC News faced backlash on social media for a report suggesting the real victim following the Nashville mass shooting is &quot;Tennessee&apos;s trans community.&quot;

## Two North Carolina men charged after discovery of nearly 1,000 explicit photographs of children
 - [https://www.foxnews.com/us/two-north-carolina-men-charged-discovery-1000-explicit-photographs-children](https://www.foxnews.com/us/two-north-carolina-men-charged-discovery-1000-explicit-photographs-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 05:46:15+00:00

Two North Carolina men are facing multiple counts of Sexual Exploitation of a Minor after authorities discovered nearly 1,000 explicit photographs of children.

## Diversity professor accused of verbally attacking students after terrorism remark cleared of any wrongdoing
 - [https://www.foxnews.com/media/diversity-professor-verbally-attacked-students-terrorism-remark-cleared-wrongdoing](https://www.foxnews.com/media/diversity-professor-verbally-attacked-students-terrorism-remark-cleared-wrongdoing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 05:00:46+00:00

George Washington University said it was standing by its diversity professor, Lara Sheehi, after a civil rights complaint to the U.S. Department of Education alleged she fostered a hostile environment to Jewish people.

## George Mason students protest decision to host Youngkin as commencement speaker
 - [https://www.foxnews.com/politics/george-mason-students-protest-decision-host-youngkin-commencement-speaker](https://www.foxnews.com/politics/george-mason-students-protest-decision-host-youngkin-commencement-speaker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 04:52:37+00:00

George Mason University students gathered on campus Tuesday to protest the school&apos;s selection of Virginia Republican Governor Glenn Youngkin as commencement speaker.

## White House blames predecessors for Biden approving massive oil drilling project
 - [https://www.foxnews.com/politics/white-house-blames-predecessors-biden-approving-massive-oil-drilling-project](https://www.foxnews.com/politics/white-house-blames-predecessors-biden-approving-massive-oil-drilling-project)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 04:50:48+00:00

The Biden administration has repeatedly refused to take credit for approving the Willow Project despite its projected enormous economic benefits and popularity.

## China threatens to take 'resolute countermeasures' over meeting between Taiwan's Tsai, House Speaker McCarthy
 - [https://www.foxnews.com/world/china-threatens-take-resolute-countermeasures-meeting-between-taiwans-tsai-house-speaker-mccarthy](https://www.foxnews.com/world/china-threatens-take-resolute-countermeasures-meeting-between-taiwans-tsai-house-speaker-mccarthy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 04:13:01+00:00

The Chinese government has threatened to take action should the U.S. and Taiwan go through with allowing House Speaker Kevin McCarthy and Taiwanese President Tsai Ing-wen to meet.

## Gwyneth Paltrow ski trial highlights Taylor Swift, Tom Brady and Oprah
 - [https://www.foxnews.com/entertainment/gwyneth-paltrow-ski-trial-highlights-taylor-swift-tom-brady-oprah](https://www.foxnews.com/entertainment/gwyneth-paltrow-ski-trial-highlights-taylor-swift-tom-brady-oprah)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 04:00:30+00:00

Gwyneth Paltrow $300,000 ski collision trial has included testimony with names of high-profile celebrities. The lawsuit stems from 2016 crash in Utah.

## Media mockery of prayer, 'subtle smears' against Christianity marks coverage of Nashville massacre
 - [https://www.foxnews.com/media/media-mockery-prayer-subtle-smears-christianity-marks-coverage-nashville-massacre](https://www.foxnews.com/media/media-mockery-prayer-subtle-smears-christianity-marks-coverage-nashville-massacre)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 04:00:16+00:00

Faith leaders respond to the criticism by journalists, entertainers and activists who have mocked prayer after three adults and three children were killed in a school shooting.

## Biden's climate agenda makes us dangerously dependent on China. Here's what we must do
 - [https://www.foxnews.com/opinion/bidens-climate-agenda-dangerously-dependent-china](https://www.foxnews.com/opinion/bidens-climate-agenda-dangerously-dependent-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 04:00:03+00:00

The Biden administration has a climate agenda that relies on critical minerals to power its radical energy goals. The administration&apos;s ban on domestic mining means America needs China.

## Georgia Gov. Brian Kemp endorses $6,500 private school voucher bill
 - [https://www.foxnews.com/politics/georgia-gov-brian-kemp-endorses-6500-private-school-voucher-bill](https://www.foxnews.com/politics/georgia-gov-brian-kemp-endorses-6500-private-school-voucher-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 03:35:08+00:00

Georgia Republican Gov. Brian Kemp is backing a bill to expand funding for private school vouchers. The legislation passed the state Senate earlier this month.

## Nashville victims: Gov. Bill Lee reveals wife lost 'one of her best friends' in Covenant shooting
 - [https://www.foxnews.com/us/nashville-victims-gov-bill-lee-reveals-wife-lost-best-friends-covenant-shooting](https://www.foxnews.com/us/nashville-victims-gov-bill-lee-reveals-wife-lost-best-friends-covenant-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 02:58:18+00:00

Tennessee Gov. Bill Lee said in a video Tuesday evening that his family and many others were personally affected by the shooting at the Covenant School, which left six dead.

## Drop in patriotism, tolerance is US wake up call and a Christmas present to these key players
 - [https://www.foxnews.com/opinion/drop-patriotism-tolerance-us-wake-up-call-christmas-present-key-players](https://www.foxnews.com/opinion/drop-patriotism-tolerance-us-wake-up-call-christmas-present-key-players)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 02:00:53+00:00

New polling from the Wall Street Journal reveals that there has been a steep decline in patriotism, religious observance, tolerance and community involvement. It&apos;s a scary scenario.

## Prince Harry's past drug use revelations won't affect U.S. visa, but he 'should always be careful': experts
 - [https://www.foxnews.com/entertainment/prince-harrys-past-drug-use-revelations-wont-affect-u-s-visa-should-careful](https://www.foxnews.com/entertainment/prince-harrys-past-drug-use-revelations-wont-affect-u-s-visa-should-careful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 02:00:44+00:00

Prince Harry and Meghan Markle, Duke and Duchess of Sussex, stepped back as senior royals in 2020. They now live in the wealthy, coastal city of Montecito, California.

## University document seeks faculty that 'speaks, acts, and dresses' to connect with minority students
 - [https://www.foxnews.com/us/university-document-seeks-faculty-that-speaks-acts-and-dresses-to-connect-with-minority-students](https://www.foxnews.com/us/university-document-seeks-faculty-that-speaks-acts-and-dresses-to-connect-with-minority-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 02:00:41+00:00

Indiana University–Purdue University Indianapolis advises faculty search committees move away from hiring people based on merit and fit, instead focus on &quot;equity-minded&quot; professors.

## US Army specialist hopes to rescue helpless puppy found overseas: 'Struggling to survive'
 - [https://www.foxnews.com/lifestyle/us-army-specialist-hopes-rescue-helpless-puppy-overseas-struggling-survive](https://www.foxnews.com/lifestyle/us-army-specialist-hopes-rescue-helpless-puppy-overseas-struggling-survive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 02:00:37+00:00

U.S. Army Specialist Fay came across a hungry and struggling puppy while deployed in the Middle East. Now, she is attempting to bring the five-month-old Canaan mix home to safety.

## Nashville transgender school shooter possibly targeted Christians over 'hateful' rhetoric, senator says
 - [https://www.foxnews.com/politics/nashville-transgender-school-shooter-possibly-targeted-christians-hateful-rhetoric-senator-says](https://www.foxnews.com/politics/nashville-transgender-school-shooter-possibly-targeted-christians-hateful-rhetoric-senator-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 02:00:35+00:00

The Covenant School shooting in Nashville should be investigated as a hate crime since the shooter targeted Christian school children, Sen. Hawley says.

## LAURA INGRAHAM: It's incumbent upon us to teach kids their worth before it's too late
 - [https://www.foxnews.com/media/laura-ingraham-incumbent-upon-us-to-teach-kids-their-worth-before-its-too-late](https://www.foxnews.com/media/laura-ingraham-incumbent-upon-us-to-teach-kids-their-worth-before-its-too-late)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 01:26:29+00:00

Laura Ingraham discusses the &quot;twisted mind&quot; of the Nashville school shooter and how the Left&apos;s agenda impacts America&apos;s youth on &quot;The Ingraham Angle.&quot;

## Mother of slain Idaho student Ethan Chapin announces new foundation: 'Wonderful way to honor'
 - [https://www.foxnews.com/us/mother-slain-idaho-student-ethan-chapin-announces-new-foundation-honor-wonderful-way-honor](https://www.foxnews.com/us/mother-slain-idaho-student-ethan-chapin-announces-new-foundation-honor-wonderful-way-honor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 01:22:05+00:00

Stacy Wells Chapin, the mother of slain University of Idaho student Ethen Chapin, has created a new foundation in her son&apos;s honor to help her community and his former school.

## Huntsville police officer killed, another injured responding to domestic violence call; suspect arrested
 - [https://www.foxnews.com/us/huntsville-police-officer-killed-another-injured-responding-domestic-violence-call-suspect-arrested](https://www.foxnews.com/us/huntsville-police-officer-killed-another-injured-responding-domestic-violence-call-suspect-arrested)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 01:00:21+00:00

A Huntsville, Alabama police officer was killed in the line of duty Tuesday after responding a report of a woman shot. A second officer remains hospitalized in critical condition.

## Greg Gutfeld: Apparently memes are now a tool of White supremacy
 - [https://www.foxnews.com/opinion/greg-gutfeld-memes-now-tool-white-supremacy](https://www.foxnews.com/opinion/greg-gutfeld-memes-now-tool-white-supremacy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 00:43:19+00:00

Fox News host Greg Gutfeld explains a CNN article that accuses White people of &apos;contemporary racism&apos; if they use a meme of a Black person on &apos;Gutfeld!&apos;

## Massachusetts man indicted on murder charges for Apple store crash
 - [https://www.foxnews.com/us/massachusetts-man-indicted-murder-charges-apple-store-crash](https://www.foxnews.com/us/massachusetts-man-indicted-murder-charges-apple-store-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 00:27:41+00:00

A Massachusetts man was indicted for driving an SUV through an Apple Store&apos;s plate glass storefront window in November, killing one person and injuring 22 others.

## SEAN HANNITY: We need armed security at every school in the country
 - [https://www.foxnews.com/media/sean-hannity-calls-for-armed-security-at-every-school-in-the-country-in-wake-of-nashville-school-shooting](https://www.foxnews.com/media/sean-hannity-calls-for-armed-security-at-every-school-in-the-country-in-wake-of-nashville-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 00:27:31+00:00

Fox News host Sean Hannity reacts to the dramatic body cam footage showing moment Nashville police enter school to neutralize shooter in Tuesday&apos;s opening monologue.

## Sen. John Kennedy: Either Mayorkas believes in open borders or he is not qualified to manage Chuck E. Cheese
 - [https://www.foxnews.com/media/sen-john-kennedy-mayorkas-believes-open-borders-or-not-qualified](https://www.foxnews.com/media/sen-john-kennedy-mayorkas-believes-open-borders-or-not-qualified)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 00:13:27+00:00

Sen. John Kennedy responds to how he grilled secretary Mayorkas on the border crisis and shares what he would do to fix the border on &quot;Your World.&quot;

## On this day in history, March 29, 1982, Michael Jordan hits winning shot in NCAA final, launching legend
 - [https://www.foxnews.com/lifestyle/this-day-history-march-29-1982-michael-jordan-hits-winning-shot-ncaa-final-launching-legend](https://www.foxnews.com/lifestyle/this-day-history-march-29-1982-michael-jordan-hits-winning-shot-ncaa-final-launching-legend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-29 00:02:49+00:00

On this day in history, Michael Jordan, a 19-year-old freshman, hit the winning shot in the 1982 NCAA final, lifting North Carolina to a 63-62 win over Georgetown and launching his legend.

