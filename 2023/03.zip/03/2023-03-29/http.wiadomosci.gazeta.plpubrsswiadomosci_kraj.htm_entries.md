# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Marsz Papieski nie przejdzie ulicami Poznania. Organizatorzy napotkali przeszkody
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29611570,marsz-papieski-nie-przejdzie-ulicami-poznania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29611570,marsz-papieski-nie-przejdzie-ulicami-poznania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-29 17:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/52/3d/1c/z29611602M,Zdjecie-ilustracyjne.jpg" vspace="2" />Wbrew wcześniejszym zapowiedziom w Poznaniu nie odbędzie się w niedzielę Marsz Papieski, zostanie zastąpiony przez spotkanie modlitewne. Idea marszu nie spotkała się z poparciem abp Stanisława Gądeckiego, a na trasie wydarzenia zarejestrowano już kilka innych zgromadzeń.

## Zapadł drugi wyrok w sprawie Jerzego S. Aktor winny spowodowania niebezpieczeństwa w ruchu drogowym
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29610968,zapadl-drugi-wyrok-w-sprawie-jerzego-s-aktor-winny-spowodowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29610968,zapadl-drugi-wyrok-w-sprawie-jerzego-s-aktor-winny-spowodowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-29 13:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/73/26/1c/z29517171M,Jerzy-S-.jpg" vspace="2" />Sąd w Krakowie wydał drugi wyrok w sprawie Jerzego S. Aktor został uznany za winnego spowodowania niebezpieczeństwa w ruchu drogowym. Wcześniej aktor został skazany za jazdę po alkoholu.

## Wpadka polityka PiS w programie na żywo. Prowadzący nie mógł uwierzyć [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29609510,wpadka-polityka-pis-w-programie-na-zywo-prowadzacy-nie-mogl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29609510,wpadka-polityka-pis-w-programie-na-zywo-prowadzacy-nie-mogl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-29 12:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b4/3c/1c/z29609652M,Artur-Sobon-zaliczyl-wpadke-w-programie-na-zywo.jpg" vspace="2" />Podczas programu "Graffiti" emitowanego na żywo w telewizji Polsat News wiceminister finansów Artur Soboń zaliczył kłopotliwą wpadkę. Z wypowiedzi polityka PiS wynikło, że nie zna on zasad flagowego programu partii, do którego rząd zachęca swoich obywateli. Prowadzący nie krył swojego zdziwienia wypowiedzią posła, który po programie próbował się z niej tłumaczyć.

## Mateusz Morawiecki: "Zboże ukraińskie destabilizuje nasz rynek". Wyśle list do Ursuli von der Leyen
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29610122,mateusz-morawiecki-zboze-ukrainskie-destabilizuje-nasz-rynek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29610122,mateusz-morawiecki-zboze-ukrainskie-destabilizuje-nasz-rynek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-29 12:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b4/35/1b/z28529588M,Mateusz-Morawiecki--zdjecie-ilustracyjne-.jpg" vspace="2" />Zboże ukraińskie destabilizuje nasz rynek - powiedział Mateusz Morawiecki. Wystosujemy list do Ursuli von der Leyen, by ograniczyć wpływ zboża na rynki krajów sąsiadujących z Ukrainą - dodał podczas konferencji prasowej.

## Posłanka Lewicy odpowiada Konfederacji. "Wprowadzimy zakaz modlitw - pikiet z krwawymi banerami"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608393,poslanka-lewicy-odpowiada-konfederacji-wprowadzimy-zakaz-modlitw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608393,poslanka-lewicy-odpowiada-konfederacji-wprowadzimy-zakaz-modlitw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-29 09:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1e/3c/1c/z29608478M,Poslanka-Katarzyna-Kotula.jpg" vspace="2" />"Wprowadzimy zakaz modlitw - pikiet z krwawymi banerami przed szpitalami, w których są oddziały ginekologiczne, zaraz po wygranych wyborach" - zadeklarowała w swoich mediach społecznościowych posłanka Lewicy Katarzyna Kotula. Post polityczki był reakcją na wcześniejszy wpis Konfederacji dotyczący nowego prawa w Wielkiej Brytanii.

## Wrocław. Parafia wprowadza nocne dyżury przy pomniku Jana Pawła II. Zainstalowała też dodatkową kamerę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608386,wroclaw-parafia-wprowadza-nocne-dyzury-przy-pomniku-jana-pawla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608386,wroclaw-parafia-wprowadza-nocne-dyzury-przy-pomniku-jana-pawla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-29 07:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cd/3c/1c/z29608653M,Pomnik-Jana-Pawla-II-we-Wroclawiu.jpg" vspace="2" />Parafia św. Maksymiliana Kolbego we Wrocławiu zdecydowała się wprowadzić nocne dyżury przy pomniku Jana Pawła II z powodu obaw, że rzeźba zostanie zniszczona przez grupę mężczyzn. O takich planach poinformowała księży jedna z parafianek. Dla pilnujących pomnika dostępna będzie kawa i herbata. - Chodzi tylko o te kilka dni wokół 2 kwietnia, czyli wokół daty śmierci Jana Pawła II - powiedział "GW" proboszcz.

## Brutalne pobicie nastolatka w Lubartowie. Media: Kopali go i kazali szczekać
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608540,brutalne-pobicie-nastolatka-w-lubartowie-media-kopali-go-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608540,brutalne-pobicie-nastolatka-w-lubartowie-media-kopali-go-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-29 07:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/3c/1c/z29608287M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Do brutalnego pobicia 19-latka doszło w Lubartowie na Lubelszczyźnie. Dwaj napastnicy w wieku 17 i 19 lat kopali go, kazali mu szczekać, a atak nagrali telefonem. Zostali już zatrzymani. Najbliższe trzy miesiące spędzą w tymczasowym areszcie - informuje Radio ZET.

## Pogoda. Kiedy zrobi się cieplej? Gwałtowna zmiana, w czwartek nawet 17 stopni
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608253,pogoda-kiedy-zrobi-sie-cieplej-gwaltowna-zmiana-w-czwartek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608253,pogoda-kiedy-zrobi-sie-cieplej-gwaltowna-zmiana-w-czwartek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-29 07:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8c/3c/1c/z29608588M,Pogoda-na-najblizsze-dni--Kiedy-wroci-wiosna-.jpg" vspace="2" />Za nami najzimniejszy dzień w tym tygodniu, czyli wtorek. Gdy za oknem szalały zamiecie śnieżne, wiele osób zapewne zatęskniło za cieplejszymi dniami. Wszystko wskazuje na to, że po kilku gwałtownych podrygach zimy cieplej zrobi się już we czwartek.

## Kuria przeprasza za rekolekcje, ale wicekuratorka wie swoje. "Wyrwany z kontekstu fragment"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608236,wicekuratorka-oswiaty-o-rekolekcjach-w-toruniu-na-ten-chory.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29608236,wicekuratorka-oswiaty-o-rekolekcjach-w-toruniu-na-ten-chory.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-29 05:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9c/1d/18/z25284764M,Wybory-parlamentarne-2019--debata-w-hotelu-Bulwar-.jpg" vspace="2" />"Jezus mówił, że nie zdrowy potrzebuje lekarza, ale chory. Na ten chory świat również jest miejsce w kościele. Po to, by Jezus go uzdrowił" - w ten sposób kujawsko-pomorska wicekuratorka oświaty odniosła się do toruńskich rekolekcji. Jak dodała - według niej - scena, podczas której mężczyzna szarpał, wyzywał i ciągnął za smycz roznegliżowaną kobietę, "rozpala niezdrowe emocje w internetach". Mazurkiewicz, która jest również pełnomocniczką PiS w Toruniu, w swoim wpisie zdołała przy okazji zaatakować sędziego Piotra Gąciarka.

