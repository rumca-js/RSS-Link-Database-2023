# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## Voice an Important New Chapter for Australia: Dreyfus
 - [https://www.theepochtimes.com/voice-an-important-new-chapter-for-australia-dreyfus_5159190.html](https://www.theepochtimes.com/voice-an-important-new-chapter-for-australia-dreyfus_5159190.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 23:26:22+00:00

This picture shows the Opera House illuminated in the colours of the Aboriginal flag in Sydney on Australia Day on Jan. 26, 2023. (Robert Wallace/AFP via Getty Images)

## Russia Stops Sharing Missile Test Info With US, Opens Drills
 - [https://www.theepochtimes.com/russia-stops-sharing-missile-test-info-with-us-opens-drills_5157244.html](https://www.theepochtimes.com/russia-stops-sharing-missile-test-info-with-us-opens-drills_5157244.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 22:52:33+00:00

A Yars missile launcher of the Russian armed forces is driven from a shelter in an undisclosed location in Russia in a still from video provided on March 29, 2023. (Russian Defense Ministry Press Service via AP)

## Liberals Propose Regulation of Payday Loans With Cap on Borrowing Rates: Budget 2023
 - [https://www.theepochtimes.com/liberals-propose-regulation-of-payday-loans-with-cap-on-borrowing-rates-budget-2023_5158949.html](https://www.theepochtimes.com/liberals-propose-regulation-of-payday-loans-with-cap-on-borrowing-rates-budget-2023_5158949.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 22:13:04+00:00

A road side sign for a pay day loan store is shown in Oshawa, Ont., on May 13, 2017. (Doug Ives/The Canadian Press)

## Biden Says Democracies ‘Are Getting Stronger,’ Cites Midterm Elections as Example
 - [https://www.theepochtimes.com/biden-says-democracies-are-getting-stronger-cites-midterm-elections-as-example_5158394.html](https://www.theepochtimes.com/biden-says-democracies-are-getting-stronger-cites-midterm-elections-as-example_5158394.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 22:10:05+00:00

President Joe Biden delivers opening remarks for the virtual Summit for Democracy in the South Court Auditorium in Washington, D.C., on Dec. 9, 2021. (Chip Somodevilla/Getty Images)

## Russia ‘Has Lost’ War in Ukraine: Sen. Risch
 - [https://www.theepochtimes.com/russia-has-lost-war-in-ukraine-sen-risch_5158891.html](https://www.theepochtimes.com/russia-has-lost-war-in-ukraine-sen-risch_5158891.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 22:00:47+00:00

Sen. Jim Risch (R-Idaho) on Capitol Hill in Washington on April 27, 2021. (Susan Walsh-Pool/Getty Images)

## What’s Behind the Mass Protests in Israel
 - [https://www.theepochtimes.com/whats-behind-the-mass-protests-in-israel_5155434.html](https://www.theepochtimes.com/whats-behind-the-mass-protests-in-israel_5155434.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 21:56:05+00:00

Israeli Prime Minister Benjamin Netanyahu in Berlin, Germany, on March 16, 2023. (Photo by Sean Gallup/Getty Images)

## Edmonton Pizza Hut Shooting Victim Suffered Brain Injury and Lost Eye, Family Says
 - [https://www.theepochtimes.com/pizza-hut-shooting-victim-suffered-brain-injury-and-lost-eye-family-says_5158907.html](https://www.theepochtimes.com/pizza-hut-shooting-victim-suffered-brain-injury-and-lost-eye-family-says_5158907.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 21:53:43+00:00

Police tape is stretched across a street in a file photo. (Mark Makela/Getty Images)

## Richard Gere and House Reps Condemn Human Rights Abuses in Tibet
 - [https://www.theepochtimes.com/richard-gere-and-house-reps-condemn-human-rights-abuses-in-tibet_5156004.html](https://www.theepochtimes.com/richard-gere-and-house-reps-condemn-human-rights-abuses-in-tibet_5156004.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 21:38:48+00:00

Actor and Chair of the International Campaign for Tibet Richard Gere (C) speaks at a bipartisan press conference to highlight the plight of Tibetans, on Capitol Hill in Washington, on March 28, 2023. (STEFANI REYNOLDS/AFP via Getty Images)

## Deputy Commander of Ottawa Regiment Charged With Sexual Misconduct
 - [https://www.theepochtimes.com/deputy-commander-of-ottawa-regiment-charged-with-sexual-misconduct_5154446.html](https://www.theepochtimes.com/deputy-commander-of-ottawa-regiment-charged-with-sexual-misconduct_5154446.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 21:26:32+00:00

Members of the Canadian Armed Forces march at a parade in Calgary on July 8, 2016. (Jeff McIntosh/The Canadian Press)

## Family of Starbucks Stabbing Victim Asks People to Remove Graphic Video of His Murder From Social Media
 - [https://www.theepochtimes.com/family-of-starbucks-stabbing-victim-asks-people-to-remove-graphic-video-of-his-murder-from-social-media_5158637.html](https://www.theepochtimes.com/family-of-starbucks-stabbing-victim-asks-people-to-remove-graphic-video-of-his-murder-from-social-media_5158637.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 21:11:18+00:00

A woman pauses at a makeshift memorial for Paul Stanley Schmidt, 37, who died after being stabbed on Sunday outside a Starbucks in downtown Vancouver, on March 29, 2023. Vancouver police say Inderdeep Singh Gosal, 32, has been charged with second-degree murder and investigators do not believe the suspect and victim knew each other. (The Canadian Press/Darryl Dyck)

## PREMIERING 3/30 at 7:30PM ET: Natan Sharansky on Today’s ‘Evil Empires,’ the War in Ukraine, Soviet Communism, and the New Antisemitism
 - [https://www.theepochtimes.com/natan-sharansky-on-todays-evil-empires-the-war-in-ukraine-soviet-communism-and-the-new-antisemitism_5103919.html](https://www.theepochtimes.com/natan-sharansky-on-todays-evil-empires-the-war-in-ukraine-soviet-communism-and-the-new-antisemitism_5103919.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 20:57:47+00:00



## Oversight Groups Discover No Confirmed Fraud or Misuse of Ukraine Aid, Officials Testify
 - [https://www.theepochtimes.com/oversight-groups-discover-no-confirmed-fraud-or-misuse-of-ukraine-aid-officials-testify_5158407.html](https://www.theepochtimes.com/oversight-groups-discover-no-confirmed-fraud-or-misuse-of-ukraine-aid-officials-testify_5158407.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 20:54:26+00:00

Airmen with the 436th Aerial Port Squadron use a forklift to move 155mm shells ultimately bound for Ukraine, on April 29, 2022, at Dover Air Force Base, Delaware. (Alex Brandon/AP Photo)

## Clock Ticks on Liberal-NDP Deal as Budget Omits Pharmacare Bill Promised in 2023
 - [https://www.theepochtimes.com/clock-ticks-on-liberal-ndp-deal-as-budget-omits-pharmacare-bill-promised-in-2023_5158619.html](https://www.theepochtimes.com/clock-ticks-on-liberal-ndp-deal-as-budget-omits-pharmacare-bill-promised-in-2023_5158619.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 20:23:06+00:00

New Democratic Party leader Jagmeet Singh speaks before caucus, in Ottawa, Mar. 29, 2023. (The Canadian Press/Adrian Wyld)

## Canadian Supporters of Missing Chinese Human-Rights Defender Want More Information
 - [https://www.theepochtimes.com/canadian-supporters-of-missing-chinese-human-rights-defender-want-more-information_5158600.html](https://www.theepochtimes.com/canadian-supporters-of-missing-chinese-human-rights-defender-want-more-information_5158600.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 20:19:42+00:00

Katherine Dong listens to a question from a reporter as she takes part in a news conference for the release of her father Dong Guangping, on Parliament Hill, Nov. 17, 2022 in Ottawa. (The Canadian Press/Adrian Wyld)

## Taiwan, Japan, and Korea Reject Cooperation With CCP on Organ Sharing
 - [https://www.theepochtimes.com/taiwan-japan-and-korea-reject-cooperation-with-ccp-on-organ-sharing_5157414.html](https://www.theepochtimes.com/taiwan-japan-and-korea-reject-cooperation-with-ccp-on-organ-sharing_5157414.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 20:02:57+00:00

Doctors carry out surgery in China in 2007. A new program being trialed by the Ministry of Health has led netizens to suspect that it was announced as a form of damage control amid mounting international pressure over abusive organ transplantation practices in China. (China Photos/Getty Images)

## Feds Pledge to Reduce Cost of Canadian Delegation at Next Climate Change Conference
 - [https://www.theepochtimes.com/feds-pledge-to-reduce-cost-of-canadian-delegation-at-next-climate-change-conference_5157969.html](https://www.theepochtimes.com/feds-pledge-to-reduce-cost-of-canadian-delegation-at-next-climate-change-conference_5157969.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 19:52:48+00:00

Conference participants walk through an illuminated tunnel at the UNFCCC COP27 climate conference in Sharm El Sheikh, Egypt, on Nov. 8, 2022. (Sean Gallup/Getty Images)

## LIVE 4 PM ET: US Support for Ukraine’s Defense With Sens. Risch and Wicker: An Event by Hudson Institute
 - [https://www.theepochtimes.com/us-support-for-ukraines-defense-with-sens-risch-and-wicker-an-event-by-hudson-institute_5158121.html](https://www.theepochtimes.com/us-support-for-ukraines-defense-with-sens-risch-and-wicker-an-event-by-hudson-institute_5158121.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 19:43:13+00:00

Sen. Jim Risch (R-Idaho) on Capitol Hill in Washington on April 27, 2021. (Susan Walsh-Pool/Getty Images)

## Government Has Spent $700 Million on Clean Water on First Nation Reserves Since 2015
 - [https://www.theepochtimes.com/government-has-spent-700-million-on-clean-water-on-first-nation-reserves-since-2015_5157841.html](https://www.theepochtimes.com/government-has-spent-700-million-on-clean-water-on-first-nation-reserves-since-2015_5157841.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 19:40:13+00:00

Water bottles are seen on the Grassy Narrows First Nation in northwestern Ontario on Oct. 5, 2019. (The Canadian Press/Paul Chiasson)

## Federal Government Requested Removal of Online Content, Document Shows
 - [https://www.theepochtimes.com/federal-government-requested-removal-of-online-content-document-shows_5158136.html](https://www.theepochtimes.com/federal-government-requested-removal-of-online-content-document-shows_5158136.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 19:26:35+00:00

The Twitter logo is seen on a sign on the exterior of Twitter headquarters in San Francisco, Calif., on Oct. 28, 2022 (Constanza Hevia/AFP via Getty Images)

## Children Turning to Social Media for News, UK Regulator Finds
 - [https://www.theepochtimes.com/children-turning-to-social-media-for-news-uk-regulator-finds_5157991.html](https://www.theepochtimes.com/children-turning-to-social-media-for-news-uk-regulator-finds_5157991.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 19:21:29+00:00

A 3D printed Youtube and TikTok logo placed on keyboard on Sept. 15, 2020. (Dado Ruvic/Reuters)

## LIVE NOW: Taiwan President Tsai Ing-wen Arrives in New York City
 - [https://www.theepochtimes.com/taiwan-president-tsai-ing-wen-arrives-in-new-york-city_5158277.html](https://www.theepochtimes.com/taiwan-president-tsai-ing-wen-arrives-in-new-york-city_5158277.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 18:59:39+00:00

Taiwan's President Tsai Ing-wen speaks during a press conference at the presidential office in Taipei, Taiwan, on Dec. 27, 2022. (Sam Yeh/AFP via Getty Images)

## Tories Introduce Bill Aimed at Reforming Parole Sentencing in Criminal Code
 - [https://www.theepochtimes.com/tories-introduce-bill-aimed-at-reforming-parole-sentencing-in-criminal-code_5158128.html](https://www.theepochtimes.com/tories-introduce-bill-aimed-at-reforming-parole-sentencing-in-criminal-code_5158128.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 18:58:48+00:00

Conservative MP Pierre Paul-Hus rises during question period in the House of Commons on Parliament Hill in Ottawa on May 14, 2021. (The Canadian Press/Sean Kilpatrick)

## UK Plans to Move Asylum Seekers From Hotels to Disused Military Bases
 - [https://www.theepochtimes.com/uk-plans-to-move-asylum-seekers-from-hotels-to-disused-military-bases_5157600.html](https://www.theepochtimes.com/uk-plans-to-move-asylum-seekers-from-hotels-to-disused-military-bases_5157600.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 18:40:27+00:00

Detainees inside the Manston short-term holding centre for illegal immigrants wave to members of the media outside, near Ramsgate, Kent, southeast England, on Nov. 3, 2022. (Daniel Leal /AFP via Getty Images)

## Netanyahu Rejects Pressure From Biden to Halt Judicial Reform
 - [https://www.theepochtimes.com/netanyahu-rejects-pressure-from-biden-to-halt-judicial-reform_5157458.html](https://www.theepochtimes.com/netanyahu-rejects-pressure-from-biden-to-halt-judicial-reform_5157458.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 18:28:01+00:00

U.S. Vice President Joe Biden (L) and Israeli Prime Minister Benjamin Netanyahu sit down for dinner at the prime minister's residence in Jerusalem on March 9, 2023.  (David Furst/AFP/Getty Images)

## Quebec Police Conduct Anti-Drug Trafficking Raids Targeting Hells Angels, Mafia
 - [https://www.theepochtimes.com/quebec-police-conduct-anti-drug-trafficking-raids-targeting-hells-angels-mafia_5158113.html](https://www.theepochtimes.com/quebec-police-conduct-anti-drug-trafficking-raids-targeting-hells-angels-mafia_5158113.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 18:07:52+00:00

Members of the Hells Angels arrive at a property in Langley, B.C., on July 25, 2008. (The Canadian Press/Darryl Dyck)

## Budget 2023 Hikes Taxes on Wealthy Individuals and Corporations
 - [https://www.theepochtimes.com/budget-2023-hikes-taxes-on-wealthy-individuals-and-corporations_5157657.html](https://www.theepochtimes.com/budget-2023-hikes-taxes-on-wealthy-individuals-and-corporations_5157657.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 17:58:33+00:00

Deputy Prime Minister and Minister of Finance Chrystia Freeland delivers the federal budget in the House of Commons on Parliament Hill in Ottawa, on March 28, 2023. (The Canadian Press/Sean Kilpatrick)

## Public Accounts Committee MPs Vote to Review Unredacted COVID Vaccine Contracts
 - [https://www.theepochtimes.com/public-accounts-committee-mps-vote-to-review-unredacted-covid-vaccine-contracts_5157314.html](https://www.theepochtimes.com/public-accounts-committee-mps-vote-to-review-unredacted-covid-vaccine-contracts_5157314.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 17:54:49+00:00

A syringe is filled with the Pfizer COVID-19 vaccine in British Columbia on April 10, 2021. (Jonathan Hayward/The Canadian Press via AP, File)

## Air Force Secretary Says He’s Seen Nothing ‘More Disturbing’ Than Chinese Regime’s Latest Move
 - [https://www.theepochtimes.com/air-force-secretary-says-hes-seen-nothing-more-disturbing-than-chinese-regimes-latest-move_5157835.html](https://www.theepochtimes.com/air-force-secretary-says-hes-seen-nothing-more-disturbing-than-chinese-regimes-latest-move_5157835.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 17:40:52+00:00

Military vehicles carrying HHQ-9B surface-to-air missiles participate in a military parade at Tiananmen Square in Beijing on Oct. 1, 2019, to mark the 70th anniversary of the founding of the Peoples Republic of China. (Greg Baker/AFP via Getty Images)

## Senate Passes Bill to Repeal Iraq War Authorizations
 - [https://www.theepochtimes.com/senate-passes-bill-to-repeal-iraq-war-authorizations_5157255.html](https://www.theepochtimes.com/senate-passes-bill-to-repeal-iraq-war-authorizations_5157255.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 16:52:17+00:00

The U.S. Capitol building in Washington on Feb. 28, 2023. (Madalina Vasiliu/The Epoch Times)

## CRA Employees Shared Private Taxpayer Info in Facebook Chat: Federal Records
 - [https://www.theepochtimes.com/cra-employees-shared-private-taxpayer-info-in-facebook-chat-federal-records_5157386.html](https://www.theepochtimes.com/cra-employees-shared-private-taxpayer-info-in-facebook-chat-federal-records_5157386.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 16:51:52+00:00

A person looks at a Canada Revenue Agency homepage, in Montreal on Aug. 16, 2020. (The Canadian Press/Graham Hughes)

## Burma Junta Dissolves 40 Political Parties, Including Suu Kyi’s NLD
 - [https://www.theepochtimes.com/burma-junta-dissolves-40-political-parties-including-suu-kyis-nld_5156749.html](https://www.theepochtimes.com/burma-junta-dissolves-40-political-parties-including-suu-kyis-nld_5156749.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 16:38:15+00:00

Protesters hold up posters featuring Aung San Suu Kyi and make three-finger salutes in Yangon, Burma, on Feb. 8, 2021. (Stringer/Getty Images)

## Majority Disattisfied With NHS for 1st Time, Survey Finds
 - [https://www.theepochtimes.com/majority-disattisfied-with-nhs-for-1st-time-survey-finds_5149235.html](https://www.theepochtimes.com/majority-disattisfied-with-nhs-for-1st-time-survey-finds_5149235.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 16:19:31+00:00

Thank You banners and Union Jack flags are seen hanging across Oxford Street as tribute to the NHS workers during the CCP virus pandemic, in London, on June 4, 2020. (Lily Zhou/The Epoch Times)

## Violent Persecution of Christians in Nicaragua Part of Regional ‘Transformations’: Analyst
 - [https://www.theepochtimes.com/violent-persecution-of-christians-in-nicaragua-part-of-regional-transformations_5151832.html](https://www.theepochtimes.com/violent-persecution-of-christians-in-nicaragua-part-of-regional-transformations_5151832.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 15:54:43+00:00

Nicaraguan President Daniel Ortega attends a meeting with members of the Central American Integration System (SICA) in a hotel in Panama City on April 10, 2015. (Mandel Ngan/AFP via Getty Images)

## NS Mass Shooting Inquiry Report Must Deliver ‘Clear Commentary’: Family Lawyer
 - [https://www.theepochtimes.com/ns-mass-shooting-inquiry-report-must-deliver-clear-commentary-family-lawyer_5157685.html](https://www.theepochtimes.com/ns-mass-shooting-inquiry-report-must-deliver-clear-commentary-family-lawyer_5157685.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 15:51:52+00:00

Nick Beaton, whose wife Kristen Beaton was killed in the April mass shooting, attends a march organized by families of victims demanding an inquiry, in Bible Hill, N.S., July 22, 2020. (The Canadian Press/Andrew Vaughan)

## Canadian Air Passengers to Pay Government 33% More in Security Fees
 - [https://www.theepochtimes.com/canadian-air-passengers-to-pay-government-33-more-in-security-fees_5157490.html](https://www.theepochtimes.com/canadian-air-passengers-to-pay-government-33-more-in-security-fees_5157490.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 15:37:20+00:00

A file photo of an employee performing security checks of passengers and their carry-on luggage at Vancouver International Airport in Richmond, B.C.. (Jonathan Hayward/The Canadian Press)

## Vaccine Harm Analysis Finds $148 Billion in Economic Damage, Tens of Millions Injured
 - [https://www.theepochtimes.com/vaccine-harm-analysis-finds-148-billion-in-economic-damage-tens-of-millions-injured_5157087.html](https://www.theepochtimes.com/vaccine-harm-analysis-finds-148-billion-in-economic-damage-tens-of-millions-injured_5157087.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 15:23:24+00:00

Pfizer-BioNTech COVID-19 vaccines in Denmark in a 2021 file image. (Claus Fisker/Ritzau Scanpix/AFP via Getty Images)

## SAGE Advisors Blame COVID ‘Strategy of Fear’ on Government
 - [https://www.theepochtimes.com/sage-advisors-blame-covid-strategy-of-fear-on-government_5141489.html](https://www.theepochtimes.com/sage-advisors-blame-covid-strategy-of-fear-on-government_5141489.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 15:19:57+00:00

A sign asking people to stay at home stands on the sea front in Southend, England, on Jan. 08, 2021.  (Dan Kitwood/Getty Images)

## Suspicions Cloud Process to Prosecute Prominent Cameroonian Journalist’s Killers
 - [https://www.theepochtimes.com/suspicions-cloud-process-to-prosecute-prominent-cameroonian-journalists-killers_5152599.html](https://www.theepochtimes.com/suspicions-cloud-process-to-prosecute-prominent-cameroonian-journalists-killers_5152599.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 15:17:11+00:00

Mourners place candles in a room of Radio Amplitude FM where a portrait of murdered journalist Martinez Zogo has been placed to pay tribute to him, in  Yaounde on Jan. 23, 2023. (Daniel Beloumou Olomo/AFP via Getty Images)

## Ottawa School Board Meeting on Transgender Washroom Use Sparks Protest
 - [https://www.theepochtimes.com/ottawa-school-board-meeting-on-transgender-washroom-use-sparks-protest_5157263.html](https://www.theepochtimes.com/ottawa-school-board-meeting-on-transgender-washroom-use-sparks-protest_5157263.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 14:37:38+00:00

A file photo of a gender neutral washroom sign. (Jonathan Hayward/The Canadian Press)

## Home Office in Crisis Mode Over Spiralling Asylum Hotel Costs: Watchdog
 - [https://www.theepochtimes.com/home-office-in-crisis-mode-over-spiralling-asylum-hotel-costs-watchdog_5157203.html](https://www.theepochtimes.com/home-office-in-crisis-mode-over-spiralling-asylum-hotel-costs-watchdog_5157203.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 14:35:40+00:00

Residents of Napier Barracks, a former military barracks that is being used to house illegal immigrants, walk under the rain among the buildings, in Folkestone, southeast England, on March 9, 2023. (Ben Stansall/AFP via Getty Images)

## Taiwan President Vows Not to Cave Under ‘External Pressure’ From China Over Trip to US
 - [https://www.theepochtimes.com/taiwan-president-vows-not-to-cave-under-external-pressure-from-china-over-trip-to-us_5156890.html](https://www.theepochtimes.com/taiwan-president-vows-not-to-cave-under-external-pressure-from-china-over-trip-to-us_5156890.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 14:13:12+00:00

Taiwan President Tsai Ing-wen speaks during a news conference with the incoming Taiwan Premier Chen Chien-jen and outgoing Taiwan Premier Su Tseng-chang at the presidential office in Taipei, Taiwan, on Jan. 27, 2023. (Carlos Garcia Rawlins/Reuters)

## Toronto Councillor Brad Bradford Confirms Intention to Run for Mayor as Council Meets
 - [https://www.theepochtimes.com/toronto-councillor-brad-bradford-confirms-intention-to-run-for-mayor-as-council-meets_5157379.html](https://www.theepochtimes.com/toronto-councillor-brad-bradford-confirms-intention-to-run-for-mayor-as-council-meets_5157379.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 14:13:11+00:00

John Tory walks away from the Toronto city hall podium, as deputy mayor Jennifer McKelvie looks on, Feb. 17, 2023. (The Canadian Press/Chris Young)

## Some Coursework Should be Done in Class to Counter AI Cheats: Exam Boards
 - [https://www.theepochtimes.com/some-coursework-should-be-done-in-class-to-counter-ai-cheats-exam-boards_5157311.html](https://www.theepochtimes.com/some-coursework-should-be-done-in-class-to-counter-ai-cheats-exam-boards_5157311.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 13:49:52+00:00

Pupils at Williamwood High School sit exams in Glasgow, Scotland, on Feb. 5, 2010. (Jeff J Mitchell/Getty Images)

## Man Charged in Toronto Subway Stabbing Wanted in Newfoundland, Docs Suggest
 - [https://www.theepochtimes.com/man-charged-in-toronto-subway-stabbing-wanted-in-newfoundland-docs-suggest_5157228.html](https://www.theepochtimes.com/man-charged-in-toronto-subway-stabbing-wanted-in-newfoundland-docs-suggest_5157228.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 13:13:45+00:00

A memorial for 16-year-old Gabriel Magalhaes is shown at the Keele Street subway station in Toronto, on March 27, 2023. (The Canadian Press/Sharif Hassan)

## Ottawa Amends Foreign Home Buyers Ban to Increase Exceptions
 - [https://www.theepochtimes.com/ottawa-amends-foreign-home-buyers-ban-to-increase-exceptions_5157109.html](https://www.theepochtimes.com/ottawa-amends-foreign-home-buyers-ban-to-increase-exceptions_5157109.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 13:10:46+00:00

A sold sign outside a home in Vancouver, in a file photo.  (The Canadian Press/Jonathan Hayward)

## Sergio Ermotti Returns as UBS CEO to Steer Credit Suisse Takeover
 - [https://www.theepochtimes.com/sergio-ermotti-returns-as-ubs-ceo-to-steer-credit-suisse-takeover_5156850.html](https://www.theepochtimes.com/sergio-ermotti-returns-as-ubs-ceo-to-steer-credit-suisse-takeover_5156850.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 12:46:18+00:00

Sergio Ermotti, newly rehired CEO of UBS Group AG attends a news conference in Zurich on March 29, 2023. (Stefan Wermuth/Reuters)

## UK to Step up Regulation of Video Streaming Giants to ‘Level the Playing Field’
 - [https://www.theepochtimes.com/uk-to-step-up-regulation-of-video-streaming-giants-to-level-the-playing-field_5157074.html](https://www.theepochtimes.com/uk-to-step-up-regulation-of-video-streaming-giants-to-level-the-playing-field_5157074.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 12:08:38+00:00

File photo of programme viewing apps, including Amazon Video, BBC iPlayer, Netflix, Google Play, and Youview, on March 19, 2019. (Nicholas T. Ansell/PA Media)

## People Showing Nazi Symbols in Two Australian States to Face Jail
 - [https://www.theepochtimes.com/people-showing-nazi-symbols-in-two-australian-states-to-face-jail_5156831.html](https://www.theepochtimes.com/people-showing-nazi-symbols-in-two-australian-states-to-face-jail_5156831.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 12:06:39+00:00

A protester performs a Nazi salute at the Shrine of Remembrance during an anti-lockdown rally in Melbourne on Sept. 5, 2020. (William West/AFP via Getty Images)

## Expulsion or Suspension: A Distinction Without a Difference
 - [https://www.theepochtimes.com/expulsion-or-suspension-a-distinction-without-a-difference_5156775.html](https://www.theepochtimes.com/expulsion-or-suspension-a-distinction-without-a-difference_5156775.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 09:53:49+00:00

Victorian Opposition Leader Giovanni Pesutto addresses the media at the Parliament of Victoria in Melbourne in Australia, on March 27, 2023. (AAP Image/Diego Fedele)

## US Halts Nuclear Arsenal Information Exchange With Russia
 - [https://www.theepochtimes.com/us-halts-nuclear-arsenal-information-exchange-with-russia_5156599.html](https://www.theepochtimes.com/us-halts-nuclear-arsenal-information-exchange-with-russia_5156599.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 09:52:01+00:00

National Security Council Coordinator for Strategic Communications John Kirby speaks during the daily briefing in the Brady Press Briefing Room of the White House in Washington, on March 22, 2023. (Saul Loeb/AFP via Getty Images)

## War Crimes Investigator to Head New Integrity Body
 - [https://www.theepochtimes.com/war-crimes-investigator-to-head-new-integrity-body_5156820.html](https://www.theepochtimes.com/war-crimes-investigator-to-head-new-integrity-body_5156820.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 08:51:55+00:00

Shadow Attorney General Mark Dreyfus in Parliament on September 16, 2019 in Canberra, Australia. (Tracey Nearmy/Getty Images)

## Reforms to Start Fixing ‘Confusing’ Family Law System
 - [https://www.theepochtimes.com/reforms-to-start-fixing-confusing-family-law-system_5156672.html](https://www.theepochtimes.com/reforms-to-start-fixing-confusing-family-law-system_5156672.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 06:20:37+00:00

A statue of Themis, the Greek God of Justice stands outside the Supreme Court in Brisbane, Australia, on Oct. 20, 2016. (AAP Image/Dave Hunt)

## Philippines’ Marcos Cuts Off Contact With ICC Over Probe Into Drug-War Killings
 - [https://www.theepochtimes.com/philippines-marcos-cuts-off-contact-with-icc-over-probe-into-drug-war-killings_5156424.html](https://www.theepochtimes.com/philippines-marcos-cuts-off-contact-with-icc-over-probe-into-drug-war-killings_5156424.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 05:50:58+00:00

Philippine President Ferdinand Marcos Jr. speaks during the 126th founding anniversary of the Philippine Army at Fort Bonifacio in Taguig, Metro Manila, Philippines on March 22, 2023. (Ezra Acayan/Getty Images)

## Study Shows Evening Exercises Can Lower Blood Sugar and Insulin Levels
 - [https://www.theepochtimes.com/health/study-shows-evening-exercises-can-lower-blood-sugar-and-insulin-levels_5156413.html](https://www.theepochtimes.com/health/study-shows-evening-exercises-can-lower-blood-sugar-and-insulin-levels_5156413.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 05:27:13+00:00

Regular, gentle exercises in the evening found to meaningfully impact the health of participants in a new study. (Alexander Nilsen)

## Greens Senator Calls Out Climate Group During Emissions Reduction Negotiations
 - [https://www.theepochtimes.com/greens-senator-calls-out-climate-groups-over-safeguard-mechanism_5153856.html](https://www.theepochtimes.com/greens-senator-calls-out-climate-groups-over-safeguard-mechanism_5153856.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 05:21:31+00:00

Greens Senator Nick McKim addresses media at Parliament House in Canberra, Australia, on May 14, 2020. (Sam Mooy/Getty Images)

## The Guardian Newspaper Apologises for Slavery Links
 - [https://www.theepochtimes.com/the-guardian-newspaper-apologises-for-slavery-links_5156624.html](https://www.theepochtimes.com/the-guardian-newspaper-apologises-for-slavery-links_5156624.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 05:13:19+00:00

A man reads a copy of The Guardian newspaper in London, England, on Sept. 12, 2005. (Scott Barbour/Getty Images)

## Crossbench Under Pressure to Agree to Labor’s $10 Billion Social Housing Fund
 - [https://www.theepochtimes.com/crossbench-under-pressure-to-agree-to-labors-10-billion-social-housing-fund_5156620.html](https://www.theepochtimes.com/crossbench-under-pressure-to-agree-to-labors-10-billion-social-housing-fund_5156620.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 04:50:07+00:00

A resident stands on a balcony of a public housing apartment in Redfern in Sydney, Australia, on Sept. 16, 2021. (Lisa Maree Williams/Getty Images)

## Budget 2023: Liberals Add Foreign Interference Office, New Money-Laundering Rules
 - [https://www.theepochtimes.com/budget-2023-liberals-add-foreign-interference-office-new-money-laundering-rules_5156716.html](https://www.theepochtimes.com/budget-2023-liberals-add-foreign-interference-office-new-money-laundering-rules_5156716.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 04:37:25+00:00

Deputy Prime Minister and Finance Minister Chrystia Freeland makes her way to a cabinet meeting on March 28, 2023 in Ottawa. (The Canadian Press/Adrian Wyld)

## Luxury Tax on Cars, Planes, Boats Will Eliminate Hundreds of Jobs: Federal Finance Report
 - [https://www.theepochtimes.com/luxury-tax-on-cars-planes-boats-will-eliminate-hundreds-of-jobs-federal-finance-report_5156525.html](https://www.theepochtimes.com/luxury-tax-on-cars-planes-boats-will-eliminate-hundreds-of-jobs-federal-finance-report_5156525.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 04:25:50+00:00

Two people fish from a boat on the Detroit River across from Windsor, Ontario, in Detroit, Mich., on April 8, 2020. (Elaine Cromie/Getty Images)

## New Zealand Intelligence Chiefs Warn State-Backed Foreign Interference Increasing
 - [https://www.theepochtimes.com/new-zealand-intelligence-chiefs-warn-state-backed-foreign-interference-increasing_5156588.html](https://www.theepochtimes.com/new-zealand-intelligence-chiefs-warn-state-backed-foreign-interference-increasing_5156588.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 04:04:31+00:00

A voter casts his ballot in the general election at a polling center in Auckland, New Zealand, on Nov. 26, 2011. (Marty Melville/AFP via Getty Images)

## Family of US Couple Kidnapped in Haiti Pleads for Release
 - [https://www.theepochtimes.com/family-of-us-couple-kidnapped-in-haiti-pleads-for-release_5154359.html](https://www.theepochtimes.com/family-of-us-couple-kidnapped-in-haiti-pleads-for-release_5154359.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 03:59:15+00:00

Jean-Dickens Toussaint and his wife Abigail Michael Toussaint pose for a photo at their wedding in Pompano Beach, Fla., on Nov. 9, 2018. (Nikese Toussaint via AP)

## Barclays Calls Allegations Against Former CEO Staley ‘Serious and New’
 - [https://www.theepochtimes.com/barclays-calls-allegations-against-former-ceo-staley-serious-and-new_5154265.html](https://www.theepochtimes.com/barclays-calls-allegations-against-former-ceo-staley-serious-and-new_5154265.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 03:49:20+00:00

Then-Barclays' CEO Jes Staley arrives at 10 Downing Street in London on Jan. 11, 2018. (Peter Nicholls/Reuters)

## Alberta Government Says Feds’ Budget Lacks Fiscal Responsibility
 - [https://www.theepochtimes.com/alberta-concerned-with-level-of-national-debt-as-feds-table-budget_5156457.html](https://www.theepochtimes.com/alberta-concerned-with-level-of-national-debt-as-feds-table-budget_5156457.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 03:31:33+00:00

Alberta Finance Minister Travis Toews. (The Canadian Press)

## Fatal Weekend Snowmobile Crash Claims Life of 25-Year-Old Alberta Woman
 - [https://www.theepochtimes.com/fatal-weekend-snowmobile-crash-claims-life-of-25-year-old-alberta-woman_5156403.html](https://www.theepochtimes.com/fatal-weekend-snowmobile-crash-claims-life-of-25-year-old-alberta-woman_5156403.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 03:16:21+00:00

People ride snowmobiles in a file photo. (Kerem Yucel/AFP via Getty Images)

## Prime Minister Calls Out Greens Political Games
 - [https://www.theepochtimes.com/prime-minister-calls-out-greens-political-games_5156380.html](https://www.theepochtimes.com/prime-minister-calls-out-greens-political-games_5156380.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 03:08:00+00:00

Prime Minister Anthony Albanese at a press conference at Parliament House in Canberra, Australia, on Feb. 28, 2023. (AAP Image/Mick Tsikas)

## Top Court Rules Police Cannot Conduct Random Tests for Alcohol Intoxication on Private Property
 - [https://www.theepochtimes.com/top-court-rules-police-cannot-conduct-random-tests-for-alcohol-intoxication-on-private-property_5156361.html](https://www.theepochtimes.com/top-court-rules-police-cannot-conduct-random-tests-for-alcohol-intoxication-on-private-property_5156361.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 02:59:11+00:00

An RCMP constable holds a breathalyzer test in a file photo. (Darryl Dyck/The Canadian Press)

## Cory Morgan: Canada Can’t Afford Ottawa’s 2023 Budget
 - [https://www.theepochtimes.com/cory-morgan-canada-cant-afford-ottawas-2023-budget_5156419.html](https://www.theepochtimes.com/cory-morgan-canada-cant-afford-ottawas-2023-budget_5156419.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 01:22:56+00:00

Prime Minister Justin Trudeau and Finance Minister Chrystia Freeland arrive to deliver the federal budget in the House of Commons on Parliament Hill in Ottawa on March 28, 2023. (The Canadian Press/Justin Tang)

## Critics Want Bill 36 Recalled for Debate as BC Health-Care Professionals’ Anxiety Mounts
 - [https://www.theepochtimes.com/critics-want-bill-36-recalled-for-debate-as-bc-health-care-professionals-anxiety-mounts_5149954.html](https://www.theepochtimes.com/critics-want-bill-36-recalled-for-debate-as-bc-health-care-professionals-anxiety-mounts_5149954.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-29 00:13:09+00:00

The B.C. Legislature in Victoria is shown on June 10, 2020. (The Canadian Press/Chad Hipolito)

