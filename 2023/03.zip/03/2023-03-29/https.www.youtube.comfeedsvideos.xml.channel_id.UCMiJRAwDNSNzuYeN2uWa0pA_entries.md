# Source:Mrwhosetheboss, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCMiJRAwDNSNzuYeN2uWa0pA, language:en-US

## The AI-Powered Smartphone Gimbal 👀
 - [https://www.youtube.com/watch?v=oORJNIDy3B0](https://www.youtube.com/watch?v=oORJNIDy3B0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCMiJRAwDNSNzuYeN2uWa0pA
 - date published: 2023-03-29 13:00:28+00:00

One of the COOLEST Smartphone gadgets EVER! Check out the Insta360 Link here: https://store.insta360.com/product/flow?insrc=INRMMYI&amp;utm_source=youtube&amp;utm_medium=KOL&amp;utm_campaign=Mrwhosetheboss&amp;utm_content=date20230329FlowLaunch

I spend a LOT of time trying to make my videos as concise, polished and useful as possible for you - if you would like to support me on that mission then consider subscribing to the channel - you'd make my day 😁

Twitter - For my tech hot takes: https://goo.gl/EFhwqL
Instagram - For my personal posts: https://goo.gl/OUqBBa
Facebook - Does anyone still use this anymore?: https://goo.gl/Aluzl1

Amazon Affiliate links (if you buy anything through these it will support the channel and allow us to buy better gear!):
Amazon US: https://goo.gl/3yS2aP
Amazon UK: https://goo.gl/gvrsGZ

My Filming Gear:
https://bit.ly/35CuxwI

Music is from Epidemic sound:
http://share.epidemicsound.com/pHDFT

