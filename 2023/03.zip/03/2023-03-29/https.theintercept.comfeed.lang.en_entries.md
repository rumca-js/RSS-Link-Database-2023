# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Protect the Israeli Judiciary — but Don’t Let It Launder War Crimes Against Palestinians
 - [https://theintercept.com/2023/03/29/israel-judiciary-war-crimes-palestine/](https://theintercept.com/2023/03/29/israel-judiciary-war-crimes-palestine/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-03-29 21:20:05+00:00

<p>Protesters are hailing Israeli courts as the last bulwark of democracy, but democracy for whom?</p>
<p>The post <a href="https://theintercept.com/2023/03/29/israel-judiciary-war-crimes-palestine/" rel="nofollow">Protect the Israeli Judiciary — but Don’t Let It Launder War Crimes Against Palestinians</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Matt Gaetz’s Legislative Aide Is a Convicted War Criminal
 - [https://theintercept.com/2023/03/29/matt-gaetz-aide-war-criminal/](https://theintercept.com/2023/03/29/matt-gaetz-aide-war-criminal/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-03-29 19:46:12+00:00

<p>Derrick Miller, who works on military policy for Rep. Matt Gaetz, served eight years for shooting an Afghan civilian in the head during an interrogation.</p>
<p>The post <a href="https://theintercept.com/2023/03/29/matt-gaetz-aide-war-criminal/" rel="nofollow">Matt Gaetz’s Legislative Aide Is a Convicted War Criminal</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## The Atlantic Celebrates 20th Anniversary of Iraq War With Lavish Falsehoods About Iraq War
 - [https://theintercept.com/2023/03/29/iraq-war-atlantic-david-frum/](https://theintercept.com/2023/03/29/iraq-war-atlantic-david-frum/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-03-29 10:00:58+00:00

<p>When questioned, The Atlantic refused to correct a basic error about chemical weapons in Iraq.</p>
<p>The post <a href="https://theintercept.com/2023/03/29/iraq-war-atlantic-david-frum/" rel="nofollow">The Atlantic Celebrates 20th Anniversary of Iraq War With Lavish Falsehoods About Iraq War</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

