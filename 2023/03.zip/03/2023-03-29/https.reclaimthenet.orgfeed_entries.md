# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Australian senators refuse to investigate the WHO pandemic treaty
 - [https://reclaimthenet.org/autralian-senators-investigate-who-pandemic-treaty](https://reclaimthenet.org/autralian-senators-investigate-who-pandemic-treaty)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-03-29 18:38:01+00:00

<a href="https://reclaimthenet.org/autralian-senators-investigate-who-pandemic-treaty" rel="nofollow" title="Australian senators refuse to investigate the WHO pandemic treaty"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/03/autralian-senators-investigate-who-pandemic-treaty.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Labor and Greens voted against efforts to scrutinize the controversial treaty.</p>
<p>The post <a href="https://reclaimthenet.org/autralian-senators-investigate-who-pandemic-treaty" rel="nofollow">Australian senators refuse to investigate the WHO pandemic treaty</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Germany uses AI to target online content for removal, send data to police
 - [https://reclaimthenet.org/germany-uses-ai-to-target-online-content-for-removal-send-data-to-police](https://reclaimthenet.org/germany-uses-ai-to-target-online-content-for-removal-send-data-to-police)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-03-29 16:57:22+00:00

<a href="https://reclaimthenet.org/germany-uses-ai-to-target-online-content-for-removal-send-data-to-police" rel="nofollow" title="Germany uses AI to target online content for removal, send data to police"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/03/ai-p-cops.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>It's already being used to target adult content.</p>
<p>The post <a href="https://reclaimthenet.org/germany-uses-ai-to-target-online-content-for-removal-send-data-to-police" rel="nofollow">Germany uses AI to target online content for removal, send data to police</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Canada’s Conservative leader promises to repeal censorship bill if elected
 - [https://reclaimthenet.org/poilievre-promises-to-repeal-censorship-bill](https://reclaimthenet.org/poilievre-promises-to-repeal-censorship-bill)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-03-29 16:09:49+00:00

<a href="https://reclaimthenet.org/poilievre-promises-to-repeal-censorship-bill" rel="nofollow" title="Canada&#8217;s Conservative leader promises to repeal censorship bill if elected"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/03/Poilievre.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>One of the few pushing back against bill C-11.</p>
<p>The post <a href="https://reclaimthenet.org/poilievre-promises-to-repeal-censorship-bill" rel="nofollow">Canada&#8217;s Conservative leader promises to repeal censorship bill if elected</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Londoners push back against invasive traffic CCTV designed to enforce “low emission zones”
 - [https://reclaimthenet.org/londoners-push-back-against-invasive-traffic-cctv-designed-to-enforce-low-emission-zones](https://reclaimthenet.org/londoners-push-back-against-invasive-traffic-cctv-designed-to-enforce-low-emission-zones)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-03-29 15:27:55+00:00

<a href="https://reclaimthenet.org/londoners-push-back-against-invasive-traffic-cctv-designed-to-enforce-low-emission-zones" rel="nofollow" title="Londoners push back against invasive traffic CCTV designed to enforce &#8220;low emission zones&#8221;"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/03/london-cover-traffic-cc.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The cameras are being covered up and even vandalized.</p>
<p>The post <a href="https://reclaimthenet.org/londoners-push-back-against-invasive-traffic-cctv-designed-to-enforce-low-emission-zones" rel="nofollow">Londoners push back against invasive traffic CCTV designed to enforce &#8220;low emission zones&#8221;</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Politicians, journalists are locked out of Twitter for tweets about trans shooter targeting Nashville Christian school
 - [https://reclaimthenet.org/twitter-censors-tweets-nashville-shooter](https://reclaimthenet.org/twitter-censors-tweets-nashville-shooter)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-03-29 02:34:25+00:00

<a href="https://reclaimthenet.org/twitter-censors-tweets-nashville-shooter" rel="nofollow" title="Politicians, journalists are locked out of Twitter for tweets about trans shooter targeting Nashville Christian school"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/03/twitter-censor-nashville-shoot.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Twitter alleges the tweets broke its rules.</p>
<p>The post <a href="https://reclaimthenet.org/twitter-censors-tweets-nashville-shooter" rel="nofollow">Politicians, journalists are locked out of Twitter for tweets about trans shooter targeting Nashville Christian school</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

