# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:en-US

## Księga Przysłów || Rozdział 12
 - [https://www.youtube.com/watch?v=doKvcOeU2I8](https://www.youtube.com/watch?v=doKvcOeU2I8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2023-03-29 22:00:17+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## chwały w domu  || blisko
 - [https://www.youtube.com/watch?v=86Bf_kJAHeY](https://www.youtube.com/watch?v=86Bf_kJAHeY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2023-03-29 14:00:05+00:00

To właśnie dzieje się w uwielbieniu – Bóg zamienia nasze narzekanie w taniec, pretensje w dziękowanie, każdą ciemność w jasny dzień, serce z kamienia na serce z ciała. Brzmi nieprawdopodobnie? My tego doświadczamy! Naucz się grać blisko i bądź blisko! 🙌 
#chwaływdomu #chwałydwazero #blisko #najbliżej @Langustanapalmie 

Nie zliczymy ile razy zadaliście nam jedno z najmilszych pytań, które brzmiało: “a macie do tego akordy?” Wiecie dlaczego je lubimy? Bo to oznacza, ze chwały owcy są z Wami w domu. Wychodząc z największą przyjemnością naprzeciw temu pytaniu, dzięki wsparciu naszych Patronek i Patronów, prezentujemy Wam nową serię: chwały w domu, czyli jak zagrać ulubione melodie. Tutoriale prowadzi gitarowca Krzysiek Łochowicz! 
Nie możemy się doczekać Waszych wersji chwał. To co, będzie grane? ♡

🎼 NUTY znajdziecie tu:
→https://bit.ly/nutychwalydwazero

ZNAJDŹ nas na:
→ w serwisach streamingowych: https://lnk.to/chwalydwazero
→ fb: https://www.facebook.com/owcaowcaofficial
→ ig: instowca
→ tiktok : owcanatiktoku
→ https://www.chwalydwazero.com

płyta owcy w sklepie Fundacji Malak 
→https://www.sklepmalak.pl/pl/p/owca-Chwaly-2.0/803
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 5 Ran Chrystusa || [odc.2] Lewa Ręka
 - [https://www.youtube.com/watch?v=qk_i4KA2So8](https://www.youtube.com/watch?v=qk_i4KA2So8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2023-03-29 13:00:40+00:00

Zapraszamy Was na langustowe rekolekcje wielkopostne, w czasie których chcemy zajrzeć pod zasłonę i przyjrzeć się 5 Ranom Chrystusa. 
"W Jego ranach jest nasze zdrowie". 

​ @Langustanapalmie    #5RanChrystusa #rekolekcje 

produkcja: Sylwia Smoczyńska, Kamil Siciak
zdjęcia: Marcin Kopiec
montaż: Marcin Kopiec
________________________________________
Wydarzenie BŁOGOSŁAWIENI.
15.04.2023 r. (sobota). 
Ergo Arena Gdańsk. 

BILETY ☞ https://bit.ly/KupBiletNaBLOGOSLAWIONYCH
WYDARZENIE NA FB ☞ https://fb.me/e/3hkFuOLIr
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Pustyniaki [#1340] Złość
 - [https://www.youtube.com/watch?v=I3sLO4fWUZc](https://www.youtube.com/watch?v=I3sLO4fWUZc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2023-03-29 02:30:06+00:00

PUSTYNIAKI to Wstawaki w wielkopostnej odsłonie. 
W tym roku naszą inspiracją będą OJCOWIE PUSTYNI.

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Pustyniaki #ojcowiepustyni #Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Akcja “NIEWIDZIALNI” wspiera organizacje zajmujące się streetworkingiem oraz współpracujące z ośrodkami i organizacjami zajmującymi się psychoterapią dziecięcą.

Wszystkie informacje na temat zbiórki znajdziecie tutaj:
→ https://bit.ly/malak_niewidzialni
________________________________________

PRZEKAŻ 1.5 % W DOBRE RĘCE!
Chcesz wesprzeć działania MALAKA? Przekaż FUNDACJI MLEKO I MIÓD 1.5 % PODATKU!

→https://www.facebook.com/FundacjaMalak/posts/pfbid0DwpZn6KAbNJsdZ84dnH8yhVHfhm2FEt81W7dh16b1sPT6ZrhVYkiou7tbF1Z3rKhl
________________________________________
Wydarzenie BŁOGOSŁAWIENI.
15.04.2023 r. (sobota). 
Ergo Arena Gdańsk. 

BILETY ☞ https://bit.ly/KupBiletNaBLOGOSLAWIONYCH
WYDARZENIE NA FB ☞ https://fb.me/e/3hkFuOLIr
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

