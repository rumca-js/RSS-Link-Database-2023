# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## I Love Technology
 - [https://www.youtube.com/watch?v=ewBJ8uw0si4](https://www.youtube.com/watch?v=ewBJ8uw0si4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-03-29 18:00:15+00:00

Download OperaGX here: https://mtchm.de/swt8t
This is the greatest phone attachment of All Time
Merch https://moistglobal.com/
I stream every day https://www.twitch.tv/moistcr1tikal

## He's Doing It Again
 - [https://www.youtube.com/watch?v=NbrGm3RLuW0](https://www.youtube.com/watch?v=NbrGm3RLuW0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-03-29 00:00:14+00:00

This is the greatest method acting of All Time
Merch https://moistglobal.com/
I stream every day https://www.twitch.tv/moistcr1tikal

