# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Arrest made in fatal migrant smuggling incident on train
 - [https://abcnews.go.com/US/arrest-made-fatal-migrant-smuggling-incident-train-uvalde/story?id=98214849](https://abcnews.go.com/US/arrest-made-fatal-migrant-smuggling-incident-train-uvalde/story?id=98214849)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 22:22:20+00:00

One man has been arrested in connection with the smuggling incident that led to 17 migrants being found trapped on a train on in Uvalde County, Texas.

## John Fetterman set for return to Senate following treatment for depression
 - [https://abcnews.go.com/Politics/john-fetterman-returning-senate-treatment-depression/story?id=98218354](https://abcnews.go.com/Politics/john-fetterman-returning-senate-treatment-depression/story?id=98218354)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 21:27:59+00:00

John Fetterman is expected to return to the Senate the week of April 17, more than a month after checking into an inpatient facility with depression

## Ohio lawmakers OK rail safety rules after train derailment
 - [https://abcnews.go.com/Politics/wireStory/ohio-lawmakers-rail-safety-rules-after-train-derailment-98216364](https://abcnews.go.com/Politics/wireStory/ohio-lawmakers-rail-safety-rules-after-train-derailment-98216364)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 20:42:43+00:00

Rail safety measures proposed after the East Palestine train derailment are closer to becoming law in Ohio

## Officers faced uncertainty of where victims, suspect were in school shooting
 - [https://abcnews.go.com/US/lets-nashville-officers-faced-uncertainty-victims-suspect-nashville/story?id=98204410](https://abcnews.go.com/US/lets-nashville-officers-faced-uncertainty-victims-suspect-nashville/story?id=98204410)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 20:37:10+00:00

When the suspected shooter drove into the parking lot of Nashville's Covenant School at 9:53 a.m. local time on Monday, a group of children were at a playground.

## Neighbor files lawsuit against chocolate factory over deadly explosion
 - [https://abcnews.go.com/US/neighbor-files-lawsuit-pennsylvania-chocolate-factory-deadly-explosion/story?id=98204346](https://abcnews.go.com/US/neighbor-files-lawsuit-pennsylvania-chocolate-factory-deadly-explosion/story?id=98204346)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 20:19:10+00:00

A woman who lives near a chocolate factory that exploded has filed a lawsuit against R.M. Palmer accusing it of negligence. Seven people died in the explosion.

## Railroad will use Ohio-based firms for derailment cleanup
 - [https://abcnews.go.com/Business/wireStory/railroad-ohio-based-firms-derailment-cleanup-98216097](https://abcnews.go.com/Business/wireStory/railroad-ohio-based-firms-derailment-cleanup-98216097)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 20:18:05+00:00

Norfolk Southern has agreed to exclusively use Ohio-based businesses to clean up the site of a fiery train derailment last month in a small town near the Pennsylvania state line

## Starbucks' ex-CEO denies lawbreaking, Sen. Sanders accuses company of 'union busting'
 - [https://abcnews.go.com/Business/starbucks-former-ceo-denies-breaking-law-after-sen/story?id=98204349](https://abcnews.go.com/Business/starbucks-former-ceo-denies-breaking-law-after-sen/story?id=98204349)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 20:17:30+00:00

Howard Schultz faced sharp criticism over Starbucks' response to a union wave.

## Colorado man cites fear of homelessness in ax killings case
 - [https://abcnews.go.com/US/wireStory/colorado-man-cites-fear-homelessness-ax-killings-case-98214959](https://abcnews.go.com/US/wireStory/colorado-man-cites-fear-homelessness-ax-killings-case-98214959)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 20:03:28+00:00

An 81-year-old Colorado man accused of killing his wife and daughter with an ax told police he lost his job and was afraid that they would end up homeless

## Investigators examine pipeline in chocolate factory blast
 - [https://abcnews.go.com/Business/wireStory/investigators-examine-pipeline-chocolate-factory-blast-98214147](https://abcnews.go.com/Business/wireStory/investigators-examine-pipeline-chocolate-factory-blast-98214147)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 19:42:29+00:00

Federal safety investigators are looking at a natural gas pipeline for fractures and other damage as they gather evidence on the cause of a deadly explosion at a Pennsylvania chocolate factory

## Murdaugh judge Newman not surprised by jury's quick verdict
 - [https://abcnews.go.com/US/wireStory/murdaugh-judge-newman-surprised-jurys-quick-verdict-98213426](https://abcnews.go.com/US/wireStory/murdaugh-judge-newman-surprised-jurys-quick-verdict-98213426)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 19:17:54+00:00

The judge who presided over Alex Murdaugh&rsquo;s murder trial in South Carolina told his law school he wasn&rsquo;t surprised the jury came back with a guilty verdict in three hours

## Pope Francis taken to hospital with respiratory infection
 - [https://abcnews.go.com/International/pope-francis-hospital-respiratory-infection/story?id=98213196](https://abcnews.go.com/International/pope-francis-hospital-respiratory-infection/story?id=98213196)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 19:05:56+00:00

Pope Francis was diagnosed with a respiratory infection Wednesday and was rushed to the hospital, where he will remain for several days.

## Arizona governor's aide resigns after controversial tweet
 - [https://abcnews.go.com/US/wireStory/arizona-governors-aide-resigns-after-controversial-tweet-98212813](https://abcnews.go.com/US/wireStory/arizona-governors-aide-resigns-after-controversial-tweet-98212813)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 18:47:43+00:00

The press secretary of Arizona Gov. Katie Hobbs has resigned after a controversial social media post made in the wake of a fatal shooting at a Tennessee school

## Hitman in New Jersey murder-for-hire sentenced to 16 years
 - [https://abcnews.go.com/US/wireStory/hitman-new-jersey-murder-hire-sentenced-16-years-98212472](https://abcnews.go.com/US/wireStory/hitman-new-jersey-murder-hire-sentenced-16-years-98212472)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 18:32:35+00:00

A career criminal whose rap sheet includes bank robberies and a murder conspiracy was sentenced to 16 years for killing a New Jersey political consultant in exchange for money in 2014

## Transgender bill spurs competing rallies at Kentucky Capitol
 - [https://abcnews.go.com/US/wireStory/transgender-bill-spurs-competing-rallies-kentucky-capitol-98210612](https://abcnews.go.com/US/wireStory/transgender-bill-spurs-competing-rallies-kentucky-capitol-98210612)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 17:10:59+00:00

Activists on both sides of the transgender health care debate have gathered at Kentucky's Capitol to make competing appeals

## Congress to consider new no-fly list for unruly passengers
 - [https://abcnews.go.com/Business/wireStory/congress-new-fly-list-unruly-passengers-98209671](https://abcnews.go.com/Business/wireStory/congress-new-fly-list-unruly-passengers-98209671)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 16:50:36+00:00

Congress is taking another look at creating a new no-fly list for unruly passengers

## WATCH:  Watch the heartwarming moment this injured deputy walked his daughter down the aisle
 - [https://abcnews.go.com/GMA/Family/video/watch-heartwarming-moment-injured-deputy-walked-daughter-aisle-98210205](https://abcnews.go.com/GMA/Family/video/watch-heartwarming-moment-injured-deputy-walked-daughter-aisle-98210205)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 16:49:16+00:00

Master Deputy Harold ‘Hal’ Davis of Florida was left temporarily paralyzed after an accident last year, but was able to be there for his daughter on her big day following intense physical therapy.

## Capitol Riot: FBI informant testifies for Proud Boys defense
 - [https://abcnews.go.com/Politics/wireStory/capitol-riot-fbi-informant-testifies-proud-boys-defense-98207102](https://abcnews.go.com/Politics/wireStory/capitol-riot-fbi-informant-testifies-proud-boys-defense-98207102)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 16:28:04+00:00

An FBI informant who marched to the U.S. Capitol with fellow Proud Boys members has testified that he didn&rsquo;t know of any plans for the far-right extremist group to invade the building on Jan. 6

## UK to house thousands of asylum seekers in ex-military bases
 - [https://abcnews.go.com/International/wireStory/uk-house-thousands-asylum-seekers-military-bases-98206699](https://abcnews.go.com/International/wireStory/uk-house-thousands-asylum-seekers-military-bases-98206699)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 16:27:26+00:00

Britain&rsquo;s government says it is planning to house thousands of asylum seekers in two disused military bases

## WATCH:  Alabama bridge collapses after heavy rain and flooding
 - [https://abcnews.go.com/US/video/alabama-bridge-collapses-after-heavy-rain-flooding-98209108](https://abcnews.go.com/US/video/alabama-bridge-collapses-after-heavy-rain-flooding-98209108)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 16:24:22+00:00

A man in Alabama stopped driving and started recording when he noticed the ground was gone beneath a bridge—just in time for it to crumble into the creek below.

## 13 states on alert for strong winds, heavy snow as major storm heads east
 - [https://abcnews.go.com/US/13-states-alert-strong-winds-heavy-snow-major/story?id=98203478](https://abcnews.go.com/US/13-states-alert-strong-winds-heavy-snow-major/story?id=98203478)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 16:18:17+00:00

Storm hits the west leaving 13 states from Oregon to Texas on alert for strong winds and heavy snow.

## Reparations for Black Californians could top $800 billion
 - [https://abcnews.go.com/US/wireStory/reparations-black-californians-top-800-billion-98200116](https://abcnews.go.com/US/wireStory/reparations-black-californians-top-800-billion-98200116)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 16:17:18+00:00

The preliminary estimate is more than 2.5 times California's annual budget.

## New Hampshire high court rejects Pamela Smart's latest chance at freedom
 - [https://abcnews.go.com/US/pamela-smart-case-new-hampshire-high-court-rule/story?id=98187913](https://abcnews.go.com/US/pamela-smart-case-new-hampshire-high-court-rule/story?id=98187913)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 15:07:27+00:00

The New Hampshire Supreme Court court on Wednesday dismissed a petition that could have set Pamela Smart on a path to freedom.

## Vatican: Pope Francis goes to hospital for scheduled tests
 - [https://abcnews.go.com/International/wireStory/vatican-pope-francis-hospital-scheduled-tests-98205439](https://abcnews.go.com/International/wireStory/vatican-pope-francis-hospital-scheduled-tests-98205439)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 15:06:35+00:00

The Vatican says Pope Francis has gone to a Rome hospital for some scheduled tests

## FDA approves over-the-counter Narcan to reduce drug overdoses
 - [https://abcnews.go.com/US/fda-approves-counter-narcan-reduce-drug-overdoses/story?id=98203480](https://abcnews.go.com/US/fda-approves-counter-narcan-reduce-drug-overdoses/story?id=98203480)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 13:31:42+00:00

The FDA approved the overdose reversal drug Narcan for over-the-counter use Monday.

## Irvo Otieno funeral to be held amid outrage over his death
 - [https://abcnews.go.com/US/irvo-otieno-funeral-held-amid-outrage-death-police/story?id=98185443](https://abcnews.go.com/US/irvo-otieno-funeral-held-amid-outrage-death-police/story?id=98185443)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 12:45:17+00:00

Irvo Otieno’s funeral will be held Wednesday following outrage over his in-custody death.

## UN atomic watchdog chief returns to Ukraine nuclear plant
 - [https://abcnews.go.com/International/wireStory/atomic-watchdog-chief-returns-ukraine-nuclear-plant-98201816](https://abcnews.go.com/International/wireStory/atomic-watchdog-chief-returns-ukraine-nuclear-plant-98201816)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 12:38:05+00:00

The head of the U.N.&rsquo;s atomic energy watchdog has returned to the Zaporizhzhia Nuclear Power Plant in Ukraine

## United Airlines flight makes emergency landing in Houston
 - [https://abcnews.go.com/US/wireStory/united-airlines-flight-makes-emergency-landing-houston-98202239](https://abcnews.go.com/US/wireStory/united-airlines-flight-makes-emergency-landing-houston-98202239)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 12:32:15+00:00

A United Airlines flight bound from Houston to Rio De Janeiro returned to Bush Intercontinental Airport for an emergency landing shortly after takeoff

## Russia launches drills of its nuclear missile forces
 - [https://abcnews.go.com/International/wireStory/russia-launches-drills-nuclear-missile-forces-98199748](https://abcnews.go.com/International/wireStory/russia-launches-drills-nuclear-missile-forces-98199748)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 11:47:12+00:00

A senior Russian diplomat says Moscow has suspended sharing information about its nuclear forces with the United States, including notices about missile tests

## Germany's high court orders amendment of child marriage ban
 - [https://abcnews.go.com/International/wireStory/germanys-high-court-orders-amendment-child-marriage-ban-98200119](https://abcnews.go.com/International/wireStory/germanys-high-court-orders-amendment-child-marriage-ban-98200119)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 11:34:57+00:00

Germany&rsquo;s constitutional court ruled Wednesday that a law banning child marriages needs to be amended because it removes the possibility of continuing a marriage once both spouses become adults

## Mother of deceased cadet speaks out after police reopen case
 - [https://abcnews.go.com/US/mother-deceased-cadet-speaks-after-daytona-beach-police/story?id=98158451](https://abcnews.go.com/US/mother-deceased-cadet-speaks-after-daytona-beach-police/story?id=98158451)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 10:55:51+00:00

Alexander Bello-Ortiz’s mother spoke out Monday about the death of her son after the Daytona Beach Police Department reopened the case last year.

## Israeli PM, Biden exchange frosty words over legal overhaul
 - [https://abcnews.go.com/International/wireStory/israeli-pm-biden-exchange-frosty-words-legal-overhaul-98198338](https://abcnews.go.com/International/wireStory/israeli-pm-biden-exchange-frosty-words-legal-overhaul-98198338)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 10:17:28+00:00

Prime Minister Benjamin Netanyahu says Israel makes its own decisions, rebuffing President Joe Biden&rsquo;s suggestion that that the premier drop a contentious plan to overhaul the legal system

## Nashville school shooting updates: Tennessee governor calls for prayers
 - [https://abcnews.go.com/US/nashville-school-shooting-updates/story?id=98197927](https://abcnews.go.com/US/nashville-school-shooting-updates/story?id=98197927)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 10:12:09+00:00

Tennessee Gov. Bill Lee has called for prayers in the wake of a Nashville school shooting while noting that "there will be a time to talk about the legislation."

## UBS brings back Ermotti as CEO with Credit Suisse deal ahead
 - [https://abcnews.go.com/Business/wireStory/ubs-brings-back-ermotti-ceo-credit-suisse-deal-98198740](https://abcnews.go.com/Business/wireStory/ubs-brings-back-ermotti-ceo-credit-suisse-deal-98198740)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 10:12:02+00:00

UBS says it&rsquo;s bringing back former CEO Sergio Ermotti to lead the Swiss bank as it moves forward with a government-orchestrated plan to take over struggling rival Credit Suisse

## Biden starts summit with $690M pledge for democracy programs
 - [https://abcnews.go.com/Politics/wireStory/biden-starts-summit-690m-pledge-democracy-programs-98199647](https://abcnews.go.com/Politics/wireStory/biden-starts-summit-690m-pledge-democracy-programs-98199647)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 09:47:26+00:00

President Joe Biden is kicking off his second Summit for Democracy with a pledge for the U.S. to spend $690 million bolstering democracy programs around the globe

## Dolphin harassment cases opened against 33 swimmers in Hawaii
 - [https://abcnews.go.com/US/dolphin-harassment-cases-opened-33-swimmers-hawaii/story?id=98198737](https://abcnews.go.com/US/dolphin-harassment-cases-opened-33-swimmers-hawaii/story?id=98198737)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 07:50:35+00:00

Thirty-three swimmers are being accused of "pursuing, corralling, and harassing" a pod of dolphins in Hōnaunau Bay on Sunday

## How to watch the 5-planet alignment: Jupiter, Mercury, Venus, Uranus and Mars
 - [https://abcnews.go.com/GMA/Living/watch-5-planet-alignment-jupiter-mercury-venus-uranus-mars/story?id=98021315](https://abcnews.go.com/GMA/Living/watch-5-planet-alignment-jupiter-mercury-venus-uranus-mars/story?id=98021315)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 03:13:13+00:00

A five-planet alignment will be visible in the night sky on Tuesday, March 28.

## WATCH:  Unlikely duo: Dog, goat become best friends at animal shelter
 - [https://abcnews.go.com/Lifestyle/video/duo-dog-goat-become-best-friends-animal-shelter-98196042](https://abcnews.go.com/Lifestyle/video/duo-dog-goat-become-best-friends-animal-shelter-98196042)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 02:39:06+00:00

A North Carolina animal shelter is trying to find a forever home for a couple of unlikely best friends: a dog named Felix and a goat named Cinnamon.

## 2 officers shot while responding to call, hospitalized with life-threatening injuries
 - [https://abcnews.go.com/US/alabama-police-officers-shot-huntsville/story?id=98193357](https://abcnews.go.com/US/alabama-police-officers-shot-huntsville/story?id=98193357)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 01:41:16+00:00

Two police officers in Huntsville, Alabama, were shot while responding to a shooting call and have been hospitalized with life-threatening injuries, police said.

## Philadelphia water 'safe to drink and use' after nearby chemical spill, city says
 - [https://abcnews.go.com/US/philadelphia-water-safe-drink-after-nearby-chemical-spill/story?id=98192506](https://abcnews.go.com/US/philadelphia-water-safe-drink-after-nearby-chemical-spill/story?id=98192506)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-29 00:41:45+00:00

Residents in Philadelphia can safely drink the water following a nearby chemical spill, the city's water department said Tuesday evening.

