# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Ubuntu Cinnamon Gets Official Ubuntu Flavor Status
 - [https://news.itsfoss.com/ubuntu-cinnamon-official/](https://news.itsfoss.com/ubuntu-cinnamon-official/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-03-29 11:23:49+00:00

A Cinnamon edition to the mix of Ubuntu flavors. Perfect!

