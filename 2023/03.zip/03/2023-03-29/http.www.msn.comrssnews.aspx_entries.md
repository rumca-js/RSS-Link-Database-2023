# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## The Russian journalist refusing to be silenced
 - [http://www.msn.com/en-us/news/world/the-russian-journalist-refusing-to-be-silenced/ar-AA19f9Ln?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-russian-journalist-refusing-to-be-silenced/ar-AA19f9Ln?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 23:51:14.858815+00:00



## Biden to visit Mississippi on Friday after deadly tornado
 - [http://www.msn.com/en-us/news/us/biden-to-visit-mississippi-on-friday-after-deadly-tornado/ar-AA19f2tl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/biden-to-visit-mississippi-on-friday-after-deadly-tornado/ar-AA19f2tl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 23:51:14.849348+00:00



## Here’s what Fox News was trying to hide in its Dominion lawsuit redactions
 - [http://www.msn.com/en-us/news/politics/here-s-what-fox-news-was-trying-to-hide-in-its-dominion-lawsuit-redactions/ar-AA19eqoJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/here-s-what-fox-news-was-trying-to-hide-in-its-dominion-lawsuit-redactions/ar-AA19eqoJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 23:51:14.838389+00:00



## North Dakota aims at school curriculum to deter abortions
 - [http://www.msn.com/en-us/news/us/north-dakota-aims-at-school-curriculum-to-deter-abortions/ar-AA19f9Qz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/north-dakota-aims-at-school-curriculum-to-deter-abortions/ar-AA19f9Qz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 23:51:14.830520+00:00



## Arrest made in fatal migrant smuggling incident on train
 - [http://www.msn.com/en-us/news/us/arrest-made-in-fatal-migrant-smuggling-incident-on-train/ar-AA19eBiv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/arrest-made-in-fatal-migrant-smuggling-incident-on-train/ar-AA19eBiv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 23:51:14.822814+00:00



## China's growing influence threatens to undermine global human rights, new research finds
 - [http://www.msn.com/en-us/news/world/china-s-growing-influence-threatens-to-undermine-global-human-rights-new-research-finds/ar-AA19feCr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-s-growing-influence-threatens-to-undermine-global-human-rights-new-research-finds/ar-AA19feCr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 23:51:14.815108+00:00



## Israeli Defense Minister Yoav Gallant oversees launch of new spy satellite, raising questions about his future
 - [http://www.msn.com/en-us/news/world/israeli-defense-minister-yoav-gallant-oversees-launch-of-new-spy-satellite-raising-questions-about-his-future/ar-AA19eTj2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israeli-defense-minister-yoav-gallant-oversees-launch-of-new-spy-satellite-raising-questions-about-his-future/ar-AA19eTj2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 23:51:14.806954+00:00



## Hawley, Paul clash on floor over TikTok ban
 - [http://www.msn.com/en-us/news/politics/hawley-paul-clash-on-floor-over-tiktok-ban/ar-AA19fa3p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hawley-paul-clash-on-floor-over-tiktok-ban/ar-AA19fa3p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 23:51:14.798838+00:00



## 2 special prosecutors appointed in Alec Baldwin 'Rust' case after previous prosecutor steps down
 - [http://www.msn.com/en-us/news/crime/2-special-prosecutors-appointed-in-alec-baldwin-rust-case-after-previous-prosecutor-steps-down/ar-AA19f1X7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/2-special-prosecutors-appointed-in-alec-baldwin-rust-case-after-previous-prosecutor-steps-down/ar-AA19f1X7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 22:50:59.773598+00:00



## Assembly offers bail change proposal at budget talks
 - [http://www.msn.com/en-us/news/politics/assembly-offers-bail-change-proposal-at-budget-talks/ar-AA19eLKo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/assembly-offers-bail-change-proposal-at-budget-talks/ar-AA19eLKo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 22:50:59.765885+00:00



## Leftover burrito led to firebomber's arrest
 - [http://www.msn.com/en-us/news/world/leftover-burrito-led-to-firebomber-s-arrest/ar-AA19eQqk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/leftover-burrito-led-to-firebomber-s-arrest/ar-AA19eQqk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 22:50:59.758035+00:00



## Lawmaker Faces Violent Threats for Trying to Make California the First State of Ban Caste Discrimination
 - [http://www.msn.com/en-us/news/us/lawmaker-faces-violent-threats-for-trying-to-make-california-the-first-state-of-ban-caste-discrimination/ar-AA19f6XY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/lawmaker-faces-violent-threats-for-trying-to-make-california-the-first-state-of-ban-caste-discrimination/ar-AA19f6XY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 22:50:59.750258+00:00



## Trump appeals order directing Meadows, other aides to testify in Jan. 6 probe
 - [http://www.msn.com/en-us/news/politics/trump-appeals-order-directing-meadows-other-aides-to-testify-in-jan-6-probe/ar-AA19eSTS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-appeals-order-directing-meadows-other-aides-to-testify-in-jan-6-probe/ar-AA19eSTS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 22:50:59.742599+00:00



## A Great Day for The Atlantic
 - [http://www.msn.com/en-us/news/us/a-great-day-for-the-atlantic/ar-AA19fbRx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-great-day-for-the-atlantic/ar-AA19fbRx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 22:50:59.733905+00:00



## Biden celebrates Greek Independence Day at the White House
 - [http://www.msn.com/en-us/news/politics/biden-celebrates-greek-independence-day-at-the-white-house/ar-AA19f6Zf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-celebrates-greek-independence-day-at-the-white-house/ar-AA19f6Zf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 22:50:59.723076+00:00



## The 70s nuclear relic that may be about to open at last
 - [http://www.msn.com/en-us/news/world/the-70s-nuclear-relic-that-may-be-about-to-open-at-last/ar-AA19eAUh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-70s-nuclear-relic-that-may-be-about-to-open-at-last/ar-AA19eAUh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 21:51:11.805240+00:00



## Minneapolis council to discuss post-Floyd policing lawsuit
 - [http://www.msn.com/en-us/news/politics/minneapolis-council-to-discuss-post-floyd-policing-lawsuit/ar-AA19eL8c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/minneapolis-council-to-discuss-post-floyd-policing-lawsuit/ar-AA19eL8c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 21:51:11.796165+00:00



## Why CapCut Is Becoming Wildly Popular on TikTok
 - [http://www.msn.com/en-us/news/technology/why-capcut-is-becoming-wildly-popular-on-tiktok/ar-AA19ew2R?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/why-capcut-is-becoming-wildly-popular-on-tiktok/ar-AA19ew2R?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 21:51:11.788786+00:00



## Best young adult books, according to librarians
 - [http://www.msn.com/en-us/news/politics/best-young-adult-books-according-to-librarians/ar-AA19eNvf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/best-young-adult-books-according-to-librarians/ar-AA19eNvf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 21:51:11.779962+00:00



## Congress appropriated $500M for workers. Democrats can’t agree on whether to spend it.
 - [http://www.msn.com/en-us/news/politics/congress-appropriated-500m-for-workers-democrats-can-t-agree-on-whether-to-spend-it/ar-AA19eUpT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/congress-appropriated-500m-for-workers-democrats-can-t-agree-on-whether-to-spend-it/ar-AA19eUpT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 21:51:11.772892+00:00



## Cops rushed into school not knowing whereabouts of victims, suspect
 - [http://www.msn.com/en-us/news/crime/cops-rushed-into-school-not-knowing-whereabouts-of-victims-suspect/ar-AA19eGq4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/cops-rushed-into-school-not-knowing-whereabouts-of-victims-suspect/ar-AA19eGq4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 21:51:11.765542+00:00



## Rand Paul plans to block Josh Hawley bill to ban TikTok
 - [http://www.msn.com/en-us/news/politics/rand-paul-plans-to-block-josh-hawley-bill-to-ban-tiktok/ar-AA19eUtD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rand-paul-plans-to-block-josh-hawley-bill-to-ban-tiktok/ar-AA19eUtD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 21:51:11.758102+00:00



## An open letter signed by Elon Musk and AI experts warned of an 'out-of-control' AI race with potential risks to humanity. Here are the 4 key points.
 - [http://www.msn.com/en-us/news/technology/an-open-letter-signed-by-elon-musk-and-ai-experts-warned-of-an-out-of-control-ai-race-with-potential-risks-to-humanity-here-are-the-4-key-points/ar-AA19eQ5b?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/an-open-letter-signed-by-elon-musk-and-ai-experts-warned-of-an-out-of-control-ai-race-with-potential-risks-to-humanity-here-are-the-4-key-points/ar-AA19eQ5b?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 21:51:11.750253+00:00



## Fernández, Biden hold talks amid Argentina's economic strain
 - [http://www.msn.com/en-us/news/world/fernández-biden-hold-talks-amid-argentina-s-economic-strain/ar-AA19eI6W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fernández-biden-hold-talks-amid-argentina-s-economic-strain/ar-AA19eI6W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 20:51:02.175706+00:00



## The Search for Earth Look-alikes Is Getting Serious
 - [http://www.msn.com/en-us/news/technology/the-search-for-earth-look-alikes-is-getting-serious/ar-AA19eTVx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-search-for-earth-look-alikes-is-getting-serious/ar-AA19eTVx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 20:51:02.167535+00:00



## Elon Musk and other tech leaders warn AI poses 'profound risks'
 - [http://www.msn.com/en-us/news/technology/elon-musk-and-other-tech-leaders-warn-ai-poses-profound-risks/ar-AA19eI7r?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-and-other-tech-leaders-warn-ai-poses-profound-risks/ar-AA19eI7r?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 20:51:02.160044+00:00



## Fox News aired Dominion voting myths despite its 'Brain Room' saying they were wrong
 - [http://www.msn.com/en-us/news/politics/fox-news-aired-dominion-voting-myths-despite-its-brain-room-saying-they-were-wrong/ar-AA19eqoJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fox-news-aired-dominion-voting-myths-despite-its-brain-room-saying-they-were-wrong/ar-AA19eqoJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 20:51:02.152611+00:00



## Georgia teens in Trent Lehrkamp torture identified by police, family asks for prayers
 - [http://www.msn.com/en-us/news/crime/georgia-teens-in-trent-lehrkamp-torture-identified-by-police-family-asks-for-prayers/ar-AA19etpf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/georgia-teens-in-trent-lehrkamp-torture-identified-by-police-family-asks-for-prayers/ar-AA19etpf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 20:51:02.144156+00:00



## Melissa Joan Hart details involvement in harrowing scene near Nashville school shooting
 - [http://www.msn.com/en-us/news/crime/melissa-joan-hart-details-involvement-in-harrowing-scene-near-nashville-school-shooting/ar-AA19eDH5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/melissa-joan-hart-details-involvement-in-harrowing-scene-near-nashville-school-shooting/ar-AA19eDH5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 20:51:02.135363+00:00



## Ron DeSantis will spend up to $4 billion on school vouchers for Florida families to challenge 'woke' public schools
 - [http://www.msn.com/en-us/news/us/ron-desantis-will-spend-up-to-4-billion-on-school-vouchers-for-florida-families-to-challenge-woke-public-schools/ar-AA19eI8J?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/ron-desantis-will-spend-up-to-4-billion-on-school-vouchers-for-florida-families-to-challenge-woke-public-schools/ar-AA19eI8J?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 20:51:02.127815+00:00



## Double standard: Will Biden truly champion human rights?
 - [http://www.msn.com/en-us/news/politics/double-standard-will-biden-truly-champion-human-rights/ar-AA19eRYE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/double-standard-will-biden-truly-champion-human-rights/ar-AA19eRYE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 20:51:02.119478+00:00



## Senate moves to roll back Clean Water Rule, setting up second Biden veto
 - [http://www.msn.com/en-us/news/politics/senate-moves-to-roll-back-clean-water-rule-setting-up-second-biden-veto/ar-AA19eqOX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-moves-to-roll-back-clean-water-rule-setting-up-second-biden-veto/ar-AA19eqOX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 19:51:11.890654+00:00



## "His testimony could be explosive": Experts say Pence subpoena ruling shows prosecutors "closing in"
 - [http://www.msn.com/en-us/news/politics/his-testimony-could-be-explosive-experts-say-pence-subpoena-ruling-shows-prosecutors-closing-in/ar-AA19eP6O?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/his-testimony-could-be-explosive-experts-say-pence-subpoena-ruling-shows-prosecutors-closing-in/ar-AA19eP6O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 19:51:11.882537+00:00



## Santa Fe DA stepping down from prosecuting Alec Baldwin's on-set 'Rust' shooting
 - [http://www.msn.com/en-us/news/crime/santa-fe-da-stepping-down-from-prosecuting-alec-baldwin-s-on-set-rust-shooting/ar-AA19eqGG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/santa-fe-da-stepping-down-from-prosecuting-alec-baldwin-s-on-set-rust-shooting/ar-AA19eqGG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 19:51:11.875099+00:00



## Priyanka Chopra Jonas shares why she left Bollywood
 - [http://www.msn.com/en-us/news/world/priyanka-chopra-jonas-shares-why-she-left-bollywood/ar-AA19eCXJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/priyanka-chopra-jonas-shares-why-she-left-bollywood/ar-AA19eCXJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 19:51:11.867649+00:00



## Serial’s Adnan Syed was finally free. Zoom got his conviction reinstated.
 - [http://www.msn.com/en-us/news/crime/serial-s-adnan-syed-was-finally-free-zoom-got-his-conviction-reinstated/ar-AA19eAc9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/serial-s-adnan-syed-was-finally-free-zoom-got-his-conviction-reinstated/ar-AA19eAc9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 19:51:11.860225+00:00



## Saudi Arabia grows closer to Beijing with step toward membership in China-led security bloc
 - [http://www.msn.com/en-us/news/world/saudi-arabia-grows-closer-to-beijing-with-step-toward-membership-in-china-led-security-bloc/ar-AA19eAcu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/saudi-arabia-grows-closer-to-beijing-with-step-toward-membership-in-china-led-security-bloc/ar-AA19eAcu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 19:51:11.852187+00:00



## Biden World Bank nominee: massive private sector investment needed to alleviate poverty, fight climate change
 - [http://www.msn.com/en-us/news/politics/biden-world-bank-nominee-massive-private-sector-investment-needed-to-alleviate-poverty-fight-climate-change/ar-AA19ePaS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-world-bank-nominee-massive-private-sector-investment-needed-to-alleviate-poverty-fight-climate-change/ar-AA19ePaS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 19:51:11.843713+00:00



## Missouri Slams DEI Programs for Promoting White Guilt
 - [http://www.msn.com/en-us/news/us/missouri-slams-dei-programs-for-promoting-white-guilt/ar-AA19eFg4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/missouri-slams-dei-programs-for-promoting-white-guilt/ar-AA19eFg4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 18:51:08.746077+00:00



## Katie Hobbs’ Spokesperson Resigns Over Tweet Invoking Gun Violence Against ‘Transphobes’
 - [http://www.msn.com/en-us/news/politics/katie-hobbs-spokesperson-resigns-over-tweet-invoking-gun-violence-against-transphobes/ar-AA19ej70?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/katie-hobbs-spokesperson-resigns-over-tweet-invoking-gun-violence-against-transphobes/ar-AA19ej70?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 18:51:08.739134+00:00



## Atlanta Falcons owner pushing for stronger DEI efforts has donated millions to Democrats
 - [http://www.msn.com/en-us/news/politics/atlanta-falcons-owner-pushing-for-stronger-dei-efforts-has-donated-millions-to-democrats/ar-AA19eiUF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/atlanta-falcons-owner-pushing-for-stronger-dei-efforts-has-donated-millions-to-democrats/ar-AA19eiUF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 18:51:08.729305+00:00



## Katie Hobbs press secretary resigns after tweet suggesting violence against 'transphobes'
 - [http://www.msn.com/en-us/news/us/katie-hobbs-press-secretary-resigns-after-tweet-suggesting-violence-against-transphobes/ar-AA19eJlR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/katie-hobbs-press-secretary-resigns-after-tweet-suggesting-violence-against-transphobes/ar-AA19eJlR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 18:51:08.721451+00:00



## Katie Hobbs' Press Sec. Resigns Amid Backlash for 'Transphobes' Gun Post
 - [http://www.msn.com/en-us/news/politics/katie-hobbs-press-sec-resigns-amid-backlash-for-transphobes-gun-post/ar-AA19eFdx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/katie-hobbs-press-sec-resigns-amid-backlash-for-transphobes-gun-post/ar-AA19eFdx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 18:51:08.712398+00:00



## Hitman in New Jersey murder-for-hire sentenced to 16 years
 - [http://www.msn.com/en-us/news/crime/hitman-in-new-jersey-murder-for-hire-sentenced-to-16-years/ar-AA19eH25?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/hitman-in-new-jersey-murder-for-hire-sentenced-to-16-years/ar-AA19eH25?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 18:51:08.705038+00:00



## This should be the year for permitting reform
 - [http://www.msn.com/en-us/news/politics/this-should-be-the-year-for-permitting-reform/ar-AA19ezNN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/this-should-be-the-year-for-permitting-reform/ar-AA19ezNN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 18:51:08.697545+00:00



## Fox News aired Dominion voting myths despite its 'Brain Room' saying they were wrong
 - [http://www.msn.com/en-us/news/us/fox-news-aired-dominion-voting-myths-despite-its-brain-room-saying-they-were-wrong/ar-AA19eqoJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/fox-news-aired-dominion-voting-myths-despite-its-brain-room-saying-they-were-wrong/ar-AA19eqoJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 18:51:08.689706+00:00



## Transgender bill spurs competing rallies at Kentucky Capitol
 - [http://www.msn.com/en-us/news/us/transgender-bill-spurs-competing-rallies-at-kentucky-capitol/ar-AA19eigL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/transgender-bill-spurs-competing-rallies-at-kentucky-capitol/ar-AA19eigL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 17:51:14.589312+00:00



## DeSantis avoids texting and emailing as governor: Report
 - [http://www.msn.com/en-us/news/politics/desantis-avoids-texting-and-emailing-as-governor-report/ar-AA19eBxU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/desantis-avoids-texting-and-emailing-as-governor-report/ar-AA19eBxU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 17:51:14.580235+00:00



## Senate Votes to Repeal Iraq War Authorizations
 - [http://www.msn.com/en-us/news/politics/senate-votes-to-repeal-iraq-war-authorizations/ar-AA19etVq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-votes-to-repeal-iraq-war-authorizations/ar-AA19etVq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 17:51:14.572493+00:00



## Pamela Smart, convicted of plotting with teen lover to kill husband, has New Hampshire court petition denied
 - [http://www.msn.com/en-us/news/crime/pamela-smart-convicted-of-plotting-with-teen-lover-to-kill-husband-has-new-hampshire-court-petition-denied/ar-AA19ewBn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/pamela-smart-convicted-of-plotting-with-teen-lover-to-kill-husband-has-new-hampshire-court-petition-denied/ar-AA19ewBn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 17:51:14.564840+00:00



## Sen. Rand Paul staffer's parents speak out after he was 'brutally attacked' in DC
 - [http://www.msn.com/en-us/news/crime/sen-rand-paul-staffer-s-parents-speak-out-after-he-was-brutally-attacked-in-dc/ar-AA199jbv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/sen-rand-paul-staffer-s-parents-speak-out-after-he-was-brutally-attacked-in-dc/ar-AA199jbv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 17:51:14.555600+00:00



## Migrants were left for dead in a Mexican detention center. Was it a preventable tragedy?
 - [http://www.msn.com/en-us/news/world/migrants-were-left-for-dead-in-a-mexican-detention-center-was-it-a-preventable-tragedy/ar-AA19eEpl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/migrants-were-left-for-dead-in-a-mexican-detention-center-was-it-a-preventable-tragedy/ar-AA19eEpl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 17:51:14.547877+00:00



## Howard Schultz defends Starbucks' labor practices, bristles at being labeled a billionaire in Sanders-led hearing
 - [http://www.msn.com/en-us/news/politics/howard-schultz-defends-starbucks-labor-practices-bristles-at-being-labeled-a-billionaire-in-sanders-led-hearing/ar-AA19dlZG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/howard-schultz-defends-starbucks-labor-practices-bristles-at-being-labeled-a-billionaire-in-sanders-led-hearing/ar-AA19dlZG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 17:51:14.539295+00:00



## Most in new poll oppose laws restricting drag shows or performances
 - [http://www.msn.com/en-us/news/politics/most-in-new-poll-oppose-laws-restricting-drag-shows-or-performances/ar-AA19erXF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/most-in-new-poll-oppose-laws-restricting-drag-shows-or-performances/ar-AA19erXF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 17:51:14.531134+00:00



## Melissa Joan Hart helped children escape from Nashville school shooting
 - [http://www.msn.com/en-us/news/crime/melissa-joan-hart-helped-children-escape-from-nashville-school-shooting/ar-AA19eoTR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/melissa-joan-hart-helped-children-escape-from-nashville-school-shooting/ar-AA19eoTR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 16:50:58.113622+00:00



## Florida lawmakers are working at breakneck speed to pass DeSantis' agenda before a presidential run: 'Our colleagues are tripping over themselves'
 - [http://www.msn.com/en-us/news/politics/florida-lawmakers-are-working-at-breakneck-speed-to-pass-desantis-agenda-before-a-presidential-run-our-colleagues-are-tripping-over-themselves/ar-AA19eqX5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/florida-lawmakers-are-working-at-breakneck-speed-to-pass-desantis-agenda-before-a-presidential-run-our-colleagues-are-tripping-over-themselves/ar-AA19eqX5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 16:50:58.105685+00:00



## Movie review: 'A Thousand and One' a fascinating portrait of maternal instinct caught in unforgiving world
 - [http://www.msn.com/en-us/news/us/movie-review-a-thousand-and-one-a-fascinating-portrait-of-maternal-instinct-caught-in-unforgiving-world/ar-AA19e5Mx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/movie-review-a-thousand-and-one-a-fascinating-portrait-of-maternal-instinct-caught-in-unforgiving-world/ar-AA19e5Mx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 16:50:58.097262+00:00



## GOP lawmakers accuse Fed of being lax before bank failure
 - [http://www.msn.com/en-us/news/politics/gop-lawmakers-accuse-fed-of-being-lax-before-bank-failure/ar-AA19ed3p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-lawmakers-accuse-fed-of-being-lax-before-bank-failure/ar-AA19ed3p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 16:50:58.089894+00:00



## Russian Ally Warns Putin: Don’t Visit—or You’ll Get Arrested
 - [http://www.msn.com/en-us/news/world/russian-ally-warns-putin-don-t-visit-or-you-ll-get-arrested/ar-AA19eaJ2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-ally-warns-putin-don-t-visit-or-you-ll-get-arrested/ar-AA19eaJ2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 16:50:58.082523+00:00



## Catch a glimpse of a rare planetary alignment—before it’s too late
 - [http://www.msn.com/en-us/news/technology/catch-a-glimpse-of-a-rare-planetary-alignment-before-it-s-too-late/ar-AA19eaN9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/catch-a-glimpse-of-a-rare-planetary-alignment-before-it-s-too-late/ar-AA19eaN9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 16:50:58.073017+00:00



## How Nashville Shooting Bodycam Footage Compares With Uvalde Police Actions
 - [http://www.msn.com/en-us/news/crime/how-nashville-shooting-bodycam-footage-compares-with-uvalde-police-actions/ar-AA19efwI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/how-nashville-shooting-bodycam-footage-compares-with-uvalde-police-actions/ar-AA19efwI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 16:50:58.065502+00:00



## Biden administration auctions over 2,000 miles of Gulf of Mexico for oil leasing
 - [http://www.msn.com/en-us/news/politics/biden-administration-auctions-over-2-000-miles-of-gulf-of-mexico-for-oil-leasing/ar-AA19ehTi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-administration-auctions-over-2-000-miles-of-gulf-of-mexico-for-oil-leasing/ar-AA19ehTi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 16:50:58.057689+00:00



## 'Pro-Moscow' Monks Resist Zelensky's Eviction From Ukraine Monastery
 - [http://www.msn.com/en-us/news/world/pro-moscow-monks-resist-zelensky-s-eviction-from-ukraine-monastery/ar-AA19e04H?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pro-moscow-monks-resist-zelensky-s-eviction-from-ukraine-monastery/ar-AA19e04H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 15:51:04.116682+00:00



## There's a Lot of Fake Parmesan Cheese Out There. Here's How to Tell
 - [http://www.msn.com/en-us/news/technology/there-s-a-lot-of-fake-parmesan-cheese-out-there-here-s-how-to-tell/ar-AA19dMcX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/there-s-a-lot-of-fake-parmesan-cheese-out-there-here-s-how-to-tell/ar-AA19dMcX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 15:51:04.109472+00:00



## Nashville school head Katherine Koonce was on a Zoom call when the shooting began and hung up to run toward the gunfire, city councilman says
 - [http://www.msn.com/en-us/news/crime/nashville-school-head-katherine-koonce-was-on-a-zoom-call-when-the-shooting-began-and-hung-up-to-run-toward-the-gunfire-city-councilman-says/ar-AA19dYce?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-school-head-katherine-koonce-was-on-a-zoom-call-when-the-shooting-began-and-hung-up-to-run-toward-the-gunfire-city-councilman-says/ar-AA19dYce?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 15:51:04.102291+00:00



## Israeli PM Benjamin Netanyahu Promised to Give a Racist Security Minister His Own Government Militia
 - [http://www.msn.com/en-us/news/world/israeli-pm-benjamin-netanyahu-promised-to-give-a-racist-security-minister-his-own-government-militia/ar-AA19ecth?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israeli-pm-benjamin-netanyahu-promised-to-give-a-racist-security-minister-his-own-government-militia/ar-AA19ecth?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 15:51:04.094674+00:00



## Howard Schultz defends Starbucks labor practices at Sanders-led Senate hearing
 - [http://www.msn.com/en-us/news/politics/howard-schultz-defends-starbucks-labor-practices-at-sanders-led-senate-hearing/ar-AA19dlZG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/howard-schultz-defends-starbucks-labor-practices-at-sanders-led-senate-hearing/ar-AA19dlZG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 15:51:04.087405+00:00



## China’s economic coercion: Jujitsu required
 - [http://www.msn.com/en-us/news/world/china-s-economic-coercion-jujitsu-required/ar-AA19elMS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-s-economic-coercion-jujitsu-required/ar-AA19elMS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 15:51:04.079909+00:00



## Judge in Alex Murdaugh trial breaks silence for first time since sentencing
 - [http://www.msn.com/en-us/news/crime/judge-in-alex-murdaugh-trial-breaks-silence-for-first-time-since-sentencing/ar-AA19ehdo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/judge-in-alex-murdaugh-trial-breaks-silence-for-first-time-since-sentencing/ar-AA19ehdo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 15:51:04.070329+00:00



## GOP Sen. Mike Rounds suggests schools should use solar panel funding to beef up security since Congress has 'gone about as far as we're going to with gun control'
 - [http://www.msn.com/en-us/news/politics/gop-sen-mike-rounds-suggests-schools-should-use-solar-panel-funding-to-beef-up-security-since-congress-has-gone-about-as-far-as-we-re-going-to-with-gun-control/ar-AA19dUjy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-sen-mike-rounds-suggests-schools-should-use-solar-panel-funding-to-beef-up-security-since-congress-has-gone-about-as-far-as-we-re-going-to-with-gun-control/ar-AA19dUjy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 14:51:06.225758+00:00



## Google, others say Uganda anti-LGBTQ bill bad for business
 - [http://www.msn.com/en-us/news/us/google-others-say-uganda-anti-lgbtq-bill-bad-for-business/ar-AA19e6tR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/google-others-say-uganda-anti-lgbtq-bill-bad-for-business/ar-AA19e6tR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 14:51:06.217885+00:00



## Howard Schultz to defend Starbucks labor practices at Sanders-led Senate hearing
 - [http://www.msn.com/en-us/news/politics/howard-schultz-to-defend-starbucks-labor-practices-at-sanders-led-senate-hearing/ar-AA19dlZG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/howard-schultz-to-defend-starbucks-labor-practices-at-sanders-led-senate-hearing/ar-AA19dlZG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 14:51:06.208584+00:00



## AI leaders (and Elon Musk) urge all labs to press pause on powerful AI
 - [http://www.msn.com/en-us/news/technology/ai-leaders-and-elon-musk-urge-all-labs-to-press-pause-on-powerful-ai/ar-AA19e6GV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/ai-leaders-and-elon-musk-urge-all-labs-to-press-pause-on-powerful-ai/ar-AA19e6GV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 14:51:06.201268+00:00



## The US has set an ambitious refugee resettlement target. Now what?
 - [http://www.msn.com/en-us/news/politics/the-us-has-set-an-ambitious-refugee-resettlement-target-now-what/ar-AA19ebyc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-us-has-set-an-ambitious-refugee-resettlement-target-now-what/ar-AA19ebyc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 14:51:06.193469+00:00



## Family guide to new movie releases
 - [http://www.msn.com/en-us/news/us/family-guide-to-new-movie-releases/ar-AA19dSjr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/family-guide-to-new-movie-releases/ar-AA19dSjr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 14:51:06.185782+00:00



## New Hampshire high court rejects Pamela Smart's latest chance at freedom
 - [http://www.msn.com/en-us/news/crime/new-hampshire-high-court-rejects-pamela-smart-s-latest-chance-at-freedom/ar-AA19dVQD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/new-hampshire-high-court-rejects-pamela-smart-s-latest-chance-at-freedom/ar-AA19dVQD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 14:51:06.178481+00:00



## 'High-priority' repeat offender in Washington flees deputies, arrested after foot chase
 - [http://www.msn.com/en-us/news/crime/high-priority-repeat-offender-in-washington-flees-deputies-arrested-after-foot-chase/ar-AA19dXqS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/high-priority-repeat-offender-in-washington-flees-deputies-arrested-after-foot-chase/ar-AA19dXqS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 14:51:06.170416+00:00



## Ukraine's Zelenskyy is 'ready' for Chinese leader to visit
 - [http://www.msn.com/en-us/news/world/ukraine-s-zelenskyy-is-ready-for-chinese-leader-to-visit/ar-AA19dYCs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-s-zelenskyy-is-ready-for-chinese-leader-to-visit/ar-AA19dYCs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 13:50:58.163101+00:00



## DNA from half-eaten burrito ties ex-Wisconsin doctoral student to pro-life center firebombing attack
 - [http://www.msn.com/en-us/news/us/dna-from-half-eaten-burrito-ties-ex-wisconsin-doctoral-student-to-pro-life-center-firebombing-attack/ar-AA19dKEd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/dna-from-half-eaten-burrito-ties-ex-wisconsin-doctoral-student-to-pro-life-center-firebombing-attack/ar-AA19dKEd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 13:50:58.155860+00:00



## Joe Biden's 'Hot Mic' Moment While Visiting Factory Viewed 3M Times
 - [http://www.msn.com/en-us/news/politics/joe-biden-s-hot-mic-moment-while-visiting-factory-viewed-3m-times/ar-AA19e1nP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/joe-biden-s-hot-mic-moment-while-visiting-factory-viewed-3m-times/ar-AA19e1nP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 13:50:58.147102+00:00



## Star Wars star lends voice to Ukraine air raid app
 - [http://www.msn.com/en-us/news/world/star-wars-star-lends-voice-to-ukraine-air-raid-app/ar-AA19dPdA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/star-wars-star-lends-voice-to-ukraine-air-raid-app/ar-AA19dPdA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 13:50:58.139871+00:00



## The Atlantic Wins Top Honor of General Excellence for Second Straight Year at 2023 National Magazine Awards
 - [http://www.msn.com/en-us/news/us/the-atlantic-wins-top-honor-of-general-excellence-for-second-straight-year-at-2023-national-magazine-awards/ar-AA19dCYf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-atlantic-wins-top-honor-of-general-excellence-for-second-straight-year-at-2023-national-magazine-awards/ar-AA19dCYf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 13:50:58.132214+00:00



## New Hampshire high court dismisses Pamela Smart's challenge to life sentence
 - [http://www.msn.com/en-us/news/crime/new-hampshire-high-court-dismisses-pamela-smart-s-challenge-to-life-sentence/ar-AA19dVQD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/new-hampshire-high-court-dismisses-pamela-smart-s-challenge-to-life-sentence/ar-AA19dVQD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 13:50:58.124942+00:00



## ‘No deal, no crisis’ is no plan for Iran
 - [http://www.msn.com/en-us/news/politics/no-deal-no-crisis-is-no-plan-for-iran/ar-AA19dPdP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/no-deal-no-crisis-is-no-plan-for-iran/ar-AA19dPdP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 13:50:58.117659+00:00



## A veteran pilot jumps in to save young pilot when he saw something go very wrong
 - [http://www.msn.com/en-us/news/us/a-veteran-pilot-jumps-in-to-save-young-pilot-when-he-saw-something-go-very-wrong/ar-AA19dYNd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-veteran-pilot-jumps-in-to-save-young-pilot-when-he-saw-something-go-very-wrong/ar-AA19dYNd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 13:50:58.109404+00:00



## Doctors in training are unionizing in record numbers today: Here's what they want
 - [http://www.msn.com/en-us/health/health-news/doctors-in-training-are-unionizing-in-record-numbers-today-here-s-what-they-want/ar-AA19dO6v?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/doctors-in-training-are-unionizing-in-record-numbers-today-here-s-what-they-want/ar-AA19dO6v?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 12:50:57.499977+00:00



## Mexican migration center guards seen walking away from fire: Surveillance video
 - [http://www.msn.com/en-us/news/world/mexican-migration-center-guards-seen-walking-away-from-fire-surveillance-video/ar-AA19dCgl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/mexican-migration-center-guards-seen-walking-away-from-fire-surveillance-video/ar-AA19dCgl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 12:50:57.492344+00:00



## Ukraine Latest: Yellen to Make Case for Aid to Kyiv in Congress
 - [http://www.msn.com/en-us/news/world/ukraine-latest-yellen-to-make-case-for-aid-to-kyiv-in-congress/ar-AA19cH40?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-latest-yellen-to-make-case-for-aid-to-kyiv-in-congress/ar-AA19cH40?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 12:50:57.484601+00:00



## Republican Speaks Out on School Shootings: 'We're Not Gonna Fix It'
 - [http://www.msn.com/en-us/news/us/republican-speaks-out-on-school-shootings-we-re-not-gonna-fix-it/ar-AA19dEKx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/republican-speaks-out-on-school-shootings-we-re-not-gonna-fix-it/ar-AA19dEKx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 12:50:57.477332+00:00



## Outrage over deadly fire at Mexico migrant centre
 - [http://www.msn.com/en-us/news/world/outrage-over-deadly-fire-at-mexico-migrant-centre/ar-AA19dCh7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/outrage-over-deadly-fire-at-mexico-migrant-centre/ar-AA19dCh7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 12:50:57.469757+00:00



## Old Hoax Shows Up in Posts About Nashville School Shooter
 - [http://www.msn.com/en-us/news/other/old-hoax-shows-up-in-posts-about-nashville-school-shooter/ar-AA19dJUu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/other/old-hoax-shows-up-in-posts-about-nashville-school-shooter/ar-AA19dJUu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 12:50:57.461653+00:00



## U.S. troops left Vietnam 50 years ago: Here are 3 key questions American defense leaders must ask today
 - [http://www.msn.com/en-us/news/politics/u-s-troops-left-vietnam-50-years-ago-here-are-3-key-questions-american-defense-leaders-must-ask-today/ar-AA19dChb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/u-s-troops-left-vietnam-50-years-ago-here-are-3-key-questions-american-defense-leaders-must-ask-today/ar-AA19dChb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 12:50:57.451537+00:00



## Greece: Terror suspects offered money to target Jewish site
 - [http://www.msn.com/en-us/news/world/greece-terror-suspects-offered-money-to-target-jewish-site/ar-AA19dOul?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/greece-terror-suspects-offered-money-to-target-jewish-site/ar-AA19dOul?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 12:50:57.443575+00:00



## Russian Airforce Preparing for Ukraine Counteroffensive—Report
 - [http://www.msn.com/en-us/news/world/russian-airforce-preparing-for-ukraine-counteroffensive-report/ar-AA19dpqb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-airforce-preparing-for-ukraine-counteroffensive-report/ar-AA19dpqb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:51:03.850134+00:00



## Guten tag Charles! Meet the King's 'cherished' German cousins
 - [http://www.msn.com/en-us/news/world/guten-tag-charles-meet-the-king-s-cherished-german-cousins/ar-AA19dDIj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/guten-tag-charles-meet-the-king-s-cherished-german-cousins/ar-AA19dDIj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:51:03.842439+00:00



## Netanyahu rejects US call to drop judicial reforms
 - [http://www.msn.com/en-us/news/world/netanyahu-rejects-us-call-to-drop-judicial-reforms/ar-AA19dg4w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/netanyahu-rejects-us-call-to-drop-judicial-reforms/ar-AA19dg4w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:51:03.834114+00:00



## Trump boasted that he 'got rid of NATO' while president during a Fox News interview. (He meant NAFTA.)
 - [http://www.msn.com/en-us/news/politics/trump-boasted-that-he-got-rid-of-nato-while-president-during-a-fox-news-interview-he-meant-nafta/ar-AA19dwUO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-boasted-that-he-got-rid-of-nato-while-president-during-a-fox-news-interview-he-meant-nafta/ar-AA19dwUO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:51:03.826018+00:00



## Saudi Arabia takes step to join China-led security bloc, as ties with Beijing strengthen
 - [http://www.msn.com/en-us/news/world/saudi-arabia-takes-step-to-join-china-led-security-bloc-as-ties-with-beijing-strengthen/ar-AA19ddfH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/saudi-arabia-takes-step-to-join-china-led-security-bloc-as-ties-with-beijing-strengthen/ar-AA19ddfH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:51:03.818164+00:00



## No more ‘thoughts and prayers’ — pass the gun laws America needs
 - [http://www.msn.com/en-us/news/politics/no-more-thoughts-and-prayers-pass-the-gun-laws-america-needs/ar-AA19dz72?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/no-more-thoughts-and-prayers-pass-the-gun-laws-america-needs/ar-AA19dz72?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:51:03.810422+00:00



## UN atomic watchdog chief returns to Ukraine nuclear plant
 - [http://www.msn.com/en-us/news/world/un-atomic-watchdog-chief-returns-to-ukraine-nuclear-plant/ar-AA19duFk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/un-atomic-watchdog-chief-returns-to-ukraine-nuclear-plant/ar-AA19duFk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:51:03.801320+00:00



## Nashville school shooting updates: Governor says now's not time to talk legislation
 - [http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-governor-says-now-s-not-time-to-talk-legislation/ar-AA19df6n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-governor-says-now-s-not-time-to-talk-legislation/ar-AA19df6n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:51:03.793802+00:00



## U.S. 'Hurting' Americans by Probing TikTok, China Says
 - [http://www.msn.com/en-us/news/world/u-s-hurting-americans-by-probing-tiktok-china-says/ar-AA19dubZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/u-s-hurting-americans-by-probing-tiktok-china-says/ar-AA19dubZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:22:57.277951+00:00



## Senate set to pass repeal of authorizations for Gulf and Iraq wars
 - [http://www.msn.com/en-us/news/politics/senate-set-to-pass-repeal-of-authorizations-for-gulf-and-iraq-wars/ar-AA19dyzN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-set-to-pass-repeal-of-authorizations-for-gulf-and-iraq-wars/ar-AA19dyzN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:22:57.269168+00:00



## To make the present feel more meaningful, think beyond it
 - [http://www.msn.com/en-us/news/world/to-make-the-present-feel-more-meaningful-think-beyond-it/ar-AA19drR3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/to-make-the-present-feel-more-meaningful-think-beyond-it/ar-AA19drR3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:22:57.259907+00:00



## Why Christine Wilson’s resignation from the FTC matters
 - [http://www.msn.com/en-us/news/politics/why-christine-wilson-s-resignation-from-the-ftc-matters/ar-AA19dyCQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/why-christine-wilson-s-resignation-from-the-ftc-matters/ar-AA19dyCQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:22:57.251822+00:00



## Prisons Use Menstruation as a Form of Punishment
 - [http://www.msn.com/en-us/news/us/prisons-use-menstruation-as-a-form-of-punishment/ar-AA19ducr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/prisons-use-menstruation-as-a-form-of-punishment/ar-AA19ducr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:22:57.244178+00:00



## Zelenskyy says Ukraine had to change faulty air-defense equipment from a European ally 'again and again' because it didn't work
 - [http://www.msn.com/en-us/news/world/zelenskyy-says-ukraine-had-to-change-faulty-air-defense-equipment-from-a-european-ally-again-and-again-because-it-didn-t-work/ar-AA19dpim?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/zelenskyy-says-ukraine-had-to-change-faulty-air-defense-equipment-from-a-european-ally-again-and-again-because-it-didn-t-work/ar-AA19dpim?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 11:22:57.235305+00:00



## Secretary Mayorkas refuses to secure the border, but the House Homeland Security Committee has a plan
 - [http://www.msn.com/en-us/news/politics/secretary-mayorkas-refuses-to-secure-the-border-but-the-house-homeland-security-committee-has-a-plan/ar-AA19dbUX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/secretary-mayorkas-refuses-to-secure-the-border-but-the-house-homeland-security-committee-has-a-plan/ar-AA19dbUX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 10:23:00.959354+00:00



## UK risks losing investment in net-zero race, MPs warn
 - [http://www.msn.com/en-us/news/world/uk-risks-losing-investment-in-net-zero-race-mps-warn/ar-AA19dtgJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/uk-risks-losing-investment-in-net-zero-race-mps-warn/ar-AA19dtgJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 10:23:00.951663+00:00



## Ukraine Latest: Zelenskiy Warns of Implications if Bakhmut Falls
 - [http://www.msn.com/en-us/news/world/ukraine-latest-zelenskiy-warns-of-implications-if-bakhmut-falls/ar-AA19cH40?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-latest-zelenskiy-warns-of-implications-if-bakhmut-falls/ar-AA19cH40?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 10:23:00.944353+00:00



## Kari Lake Blasts 'Media Bias' Over Nashville 'Transphobes' Gun Post
 - [http://www.msn.com/en-us/news/politics/kari-lake-blasts-media-bias-over-nashville-transphobes-gun-post/ar-AA19d58l?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kari-lake-blasts-media-bias-over-nashville-transphobes-gun-post/ar-AA19d58l?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 10:23:00.936514+00:00



## NBC News pummeled for suggesting Tennessee's trans community is in fear due to 'focus' on Nashville shooter
 - [http://www.msn.com/en-us/news/us/nbc-news-pummeled-for-suggesting-tennessee-s-trans-community-is-in-fear-due-to-focus-on-nashville-shooter/ar-AA19dqVe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nbc-news-pummeled-for-suggesting-tennessee-s-trans-community-is-in-fear-due-to-focus-on-nashville-shooter/ar-AA19dqVe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 10:23:00.928716+00:00



## Irvo Otieno funeral to be held amid outrage over his death
 - [http://www.msn.com/en-us/news/crime/irvo-otieno-funeral-to-be-held-amid-outrage-over-his-death/ar-AA19d40e?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/irvo-otieno-funeral-to-be-held-amid-outrage-over-his-death/ar-AA19d40e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 10:23:00.920282+00:00



## American IQs rose 30 points in the last century. Now, they may be falling.
 - [http://www.msn.com/en-us/news/politics/american-iqs-rose-30-points-in-the-last-century-now-they-may-be-falling/ar-AA19d5cs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/american-iqs-rose-30-points-in-the-last-century-now-they-may-be-falling/ar-AA19d5cs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 10:23:00.911476+00:00



## Reparations for Black Californians could top $800 billion
 - [http://www.msn.com/en-us/news/politics/reparations-for-black-californians-could-top-800-billion/ar-AA19d5d0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/reparations-for-black-californians-could-top-800-billion/ar-AA19d5d0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 10:23:00.901813+00:00



## Netanyahu dismisses Biden's suggestion that he drop contentious judicial overhaul
 - [http://www.msn.com/en-us/news/politics/netanyahu-dismisses-biden-s-suggestion-that-he-drop-contentious-judicial-overhaul/ar-AA19d8UA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/netanyahu-dismisses-biden-s-suggestion-that-he-drop-contentious-judicial-overhaul/ar-AA19d8UA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 09:22:47.929901+00:00



## Netanyahu, the skunk at Biden's democracy party
 - [http://www.msn.com/en-us/news/politics/netanyahu-the-skunk-at-biden-s-democracy-party/ar-AA19cXCK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/netanyahu-the-skunk-at-biden-s-democracy-party/ar-AA19cXCK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 09:22:47.922450+00:00



## Biden reveals which states he is targeting in spending blitz — and 2024
 - [http://www.msn.com/en-us/news/politics/biden-reveals-which-states-he-is-targeting-in-spending-blitz-and-2024/ar-AA19d1ZH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-reveals-which-states-he-is-targeting-in-spending-blitz-and-2024/ar-AA19d1ZH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 09:22:47.912869+00:00



## Will Katie Porter’s Consumer Protection Record Be Undermined by Her Investments?
 - [http://www.msn.com/en-us/news/politics/will-katie-porter-s-consumer-protection-record-be-undermined-by-her-investments/ar-AA19d6T4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/will-katie-porter-s-consumer-protection-record-be-undermined-by-her-investments/ar-AA19d6T4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 09:22:47.903664+00:00



## Tucker Carlson Says Trans Movement 'Natural Enemy' of Christianity
 - [http://www.msn.com/en-us/news/us/tucker-carlson-says-trans-movement-natural-enemy-of-christianity/ar-AA19cNjR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tucker-carlson-says-trans-movement-natural-enemy-of-christianity/ar-AA19cNjR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 09:22:47.896197+00:00



## Rumours swirl as search for Indian preacher continues
 - [http://www.msn.com/en-us/news/world/rumours-swirl-as-search-for-indian-preacher-continues/ar-AA19d4wh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/rumours-swirl-as-search-for-indian-preacher-continues/ar-AA19d4wh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 09:22:47.888915+00:00



## Biden to announce funding to bolster democracy globally at second US-led summit
 - [http://www.msn.com/en-us/news/politics/biden-to-announce-funding-to-bolster-democracy-globally-at-second-us-led-summit/ar-AA19dbl5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-to-announce-funding-to-bolster-democracy-globally-at-second-us-led-summit/ar-AA19dbl5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 09:22:47.880014+00:00



## EXPLAINER: Mass shootings seldom shift partisan policies
 - [http://www.msn.com/en-us/news/politics/explainer-mass-shootings-seldom-shift-partisan-policies/ar-AA19d0ng?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/explainer-mass-shootings-seldom-shift-partisan-policies/ar-AA19d0ng?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 09:22:47.871891+00:00



## 'Wordle' Today #648 Answer, Hints and Tips for Wednesday, March 29 Game
 - [http://www.msn.com/en-us/news/technology/wordle-today-648-answer-hints-and-tips-for-wednesday-march-29-game/ar-AA19cORk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/wordle-today-648-answer-hints-and-tips-for-wednesday-march-29-game/ar-AA19cORk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 08:22:58.839431+00:00



## Crime is just the beginning as GOP seeks to rein in DC's liberal government
 - [http://www.msn.com/en-us/news/politics/crime-is-just-the-beginning-as-gop-seeks-to-rein-in-dc-s-liberal-government/ar-AA19cFpG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/crime-is-just-the-beginning-as-gop-seeks-to-rein-in-dc-s-liberal-government/ar-AA19cFpG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 08:22:58.831772+00:00



## Southern Lights unusually vivid over New Zealand
 - [http://www.msn.com/en-us/news/world/southern-lights-unusually-vivid-over-new-zealand/ar-AA19cCtP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/southern-lights-unusually-vivid-over-new-zealand/ar-AA19cCtP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 08:22:58.824047+00:00



## Biden Aide Speaks With China Counterpart as Tension Spikes
 - [http://www.msn.com/en-us/news/world/biden-aide-speaks-with-china-counterpart-as-tension-spikes/ar-AA19bHwL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/biden-aide-speaks-with-china-counterpart-as-tension-spikes/ar-AA19bHwL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 08:22:58.816200+00:00



## Dolphin harassment cases opened against 33 swimmers in Hawaii
 - [http://www.msn.com/en-us/news/us/dolphin-harassment-cases-opened-against-33-swimmers-in-hawaii/ar-AA19cZqV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/dolphin-harassment-cases-opened-against-33-swimmers-in-hawaii/ar-AA19cZqV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 08:22:58.808935+00:00



## Calls mount for Taliban to free girls' education activist
 - [http://www.msn.com/en-us/news/world/calls-mount-for-taliban-to-free-girls-education-activist/ar-AA19cMLQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/calls-mount-for-taliban-to-free-girls-education-activist/ar-AA19cMLQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 08:22:58.800934+00:00



## Erika Ettin: Why we want people we can’t have
 - [http://www.msn.com/en-us/news/technology/erika-ettin-why-we-want-people-we-can-t-have/ar-AA19cRV3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/erika-ettin-why-we-want-people-we-can-t-have/ar-AA19cRV3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 08:22:58.792214+00:00



## University document seeks faculty that 'speaks, acts, and dresses' to connect with minority students
 - [http://www.msn.com/en-us/news/us/university-document-seeks-faculty-that-speaks-acts-and-dresses-to-connect-with-minority-students/ar-AA19cQRk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/university-document-seeks-faculty-that-speaks-acts-and-dresses-to-connect-with-minority-students/ar-AA19cQRk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 07:22:58.490000+00:00



## Elon Musk Urges Top AI Labs To Pause Training of AI Beyond GPT-4
 - [http://www.msn.com/en-us/news/technology/elon-musk-urges-top-ai-labs-to-pause-training-of-ai-beyond-gpt-4/ar-AA19cOjU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-urges-top-ai-labs-to-pause-training-of-ai-beyond-gpt-4/ar-AA19cOjU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 07:22:58.482403+00:00



## Cartels took 'advantage' of northern border holes when agents went south: Stefanik
 - [http://www.msn.com/en-us/news/us/cartels-took-advantage-of-northern-border-holes-when-agents-went-south-stefanik/ar-AA19cCex?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/cartels-took-advantage-of-northern-border-holes-when-agents-went-south-stefanik/ar-AA19cCex?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 07:22:58.473183+00:00



## Spain clean energy case shakes confidence in EU investment
 - [http://www.msn.com/en-us/news/world/spain-clean-energy-case-shakes-confidence-in-eu-investment/ar-AA19cRgZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/spain-clean-energy-case-shakes-confidence-in-eu-investment/ar-AA19cRgZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 07:22:58.465172+00:00



## China threatens retaliation if Tsai and McCarthy meet
 - [http://www.msn.com/en-us/news/world/china-threatens-retaliation-if-tsai-and-mccarthy-meet/ar-AA19cAif?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-threatens-retaliation-if-tsai-and-mccarthy-meet/ar-AA19cAif?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 06:23:04.623050+00:00



## Mother of slain Idaho student Ethan Chapin announces new foundation: 'Wonderful way to honor'
 - [http://www.msn.com/en-us/news/crime/mother-of-slain-idaho-student-ethan-chapin-announces-new-foundation-wonderful-way-to-honor/ar-AA19cLvQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/mother-of-slain-idaho-student-ethan-chapin-announces-new-foundation-wonderful-way-to-honor/ar-AA19cLvQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 06:23:04.615046+00:00



## BTS star Jungkook bares sculpted abs for new Calvin Klein campaign
 - [http://www.msn.com/en-us/news/world/bts-star-jungkook-bares-sculpted-abs-for-new-calvin-klein-campaign/ar-AA19cxs1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/bts-star-jungkook-bares-sculpted-abs-for-new-calvin-klein-campaign/ar-AA19cxs1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 06:23:04.605983+00:00



## Ukraine Latest: Zelenskiy Warns of Dangers of Bakhmut Defeat
 - [http://www.msn.com/en-us/news/world/ukraine-latest-zelenskiy-warns-of-dangers-of-bakhmut-defeat/ar-AA19cH40?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-latest-zelenskiy-warns-of-dangers-of-bakhmut-defeat/ar-AA19cH40?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 06:23:04.596047+00:00



## Save lives by cutting off fentanyl at its source
 - [http://www.msn.com/en-us/news/us/save-lives-by-cutting-off-fentanyl-at-its-source/ar-AA19cpUq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/save-lives-by-cutting-off-fentanyl-at-its-source/ar-AA19cpUq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 06:23:04.587911+00:00



## AI Labs Urged to Pump the Brakes in Open Letter
 - [http://www.msn.com/en-us/news/technology/ai-labs-urged-to-pump-the-brakes-in-open-letter/ar-AA19cIME?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/ai-labs-urged-to-pump-the-brakes-in-open-letter/ar-AA19cIME?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 05:22:55.701203+00:00



## WATCH: Man driving stolen police car jumps out at 70 mph, smacks head, and gets back up
 - [http://www.msn.com/en-us/news/crime/watch-man-driving-stolen-police-car-jumps-out-at-70-mph-smacks-head-and-gets-back-up/ar-AA19cv4c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/watch-man-driving-stolen-police-car-jumps-out-at-70-mph-smacks-head-and-gets-back-up/ar-AA19cv4c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 05:22:55.691016+00:00



## SEAN HANNITY: We need armed security at every school in the country
 - [http://www.msn.com/en-us/news/us/sean-hannity-we-need-armed-security-at-every-school-in-the-country/ar-AA19cLbx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/sean-hannity-we-need-armed-security-at-every-school-in-the-country/ar-AA19cLbx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 05:22:55.683245+00:00



## Takeaways from AP's interview with Ukraine's Zelenskyy
 - [http://www.msn.com/en-us/news/world/takeaways-from-ap-s-interview-with-ukraine-s-zelenskyy/ar-AA19cDJ3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/takeaways-from-ap-s-interview-with-ukraine-s-zelenskyy/ar-AA19cDJ3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 05:22:55.675107+00:00



## Two Nashville Shooting Victims Were Friends of Tennessee Guv and His Wife
 - [http://www.msn.com/en-us/news/crime/two-nashville-shooting-victims-were-friends-of-tennessee-guv-and-his-wife/ar-AA19csAc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/two-nashville-shooting-victims-were-friends-of-tennessee-guv-and-his-wife/ar-AA19csAc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 05:22:55.667444+00:00



## Republican Lawmakers Question FBI on Nashville School Shooting
 - [http://www.msn.com/en-us/news/us/republican-lawmakers-question-fbi-on-nashville-school-shooting/ar-AA19cNw0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/republican-lawmakers-question-fbi-on-nashville-school-shooting/ar-AA19cNw0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 05:22:55.659594+00:00



## Grief and shock at Nashville vigils after school shooting
 - [http://www.msn.com/en-us/news/world/grief-and-shock-at-nashville-vigils-after-school-shooting/ar-AA19cAMB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/grief-and-shock-at-nashville-vigils-after-school-shooting/ar-AA19cAMB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 04:22:54.009239+00:00



## Tucker Turns Shooting Into Apocalyptic War Between Trans People and Christians
 - [http://www.msn.com/en-us/news/us/tucker-turns-shooting-into-apocalyptic-war-between-trans-people-and-christians/ar-AA19cFIt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tucker-turns-shooting-into-apocalyptic-war-between-trans-people-and-christians/ar-AA19cFIt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 04:22:54.001436+00:00



## Chris Christie says he will never back Trump again
 - [http://www.msn.com/en-us/news/politics/chris-christie-says-he-will-never-back-trump-again/ar-AA19crZ7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/chris-christie-says-he-will-never-back-trump-again/ar-AA19crZ7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 04:22:53.993710+00:00



## These are some of the students and adults killed in the Covenant School massacre
 - [http://www.msn.com/en-us/news/us/these-are-some-of-the-students-and-adults-killed-in-the-covenant-school-massacre/ar-AA19c7TW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/these-are-some-of-the-students-and-adults-killed-in-the-covenant-school-massacre/ar-AA19c7TW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 04:22:53.985889+00:00



## Asia's 'best restaurants' list is out — and it's no surprise which country made the list 17 times
 - [http://www.msn.com/en-us/news/world/asia-s-best-restaurants-list-is-out-and-it-s-no-surprise-which-country-made-the-list-17-times/ar-AA19chL7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/asia-s-best-restaurants-list-is-out-and-it-s-no-surprise-which-country-made-the-list-17-times/ar-AA19chL7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 04:22:53.978792+00:00



## Poll: Cut federal spending — but not big-ticket programs
 - [http://www.msn.com/en-us/news/politics/poll-cut-federal-spending-but-not-big-ticket-programs/ar-AA19cwMK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/poll-cut-federal-spending-but-not-big-ticket-programs/ar-AA19cwMK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 04:22:53.969142+00:00



## Idaho prosecutors disclosing info about 'internal affairs investigation' related to officer on Kohberger case
 - [http://www.msn.com/en-us/news/crime/idaho-prosecutors-disclosing-info-about-internal-affairs-investigation-related-to-officer-on-kohberger-case/ar-AA19c7ky?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/idaho-prosecutors-disclosing-info-about-internal-affairs-investigation-related-to-officer-on-kohberger-case/ar-AA19c7ky?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 03:22:54.359650+00:00



## DNA From Burrito Ties Wisconsin Man to Anti-Abortion Office Firebombing
 - [http://www.msn.com/en-us/news/crime/dna-from-burrito-ties-wisconsin-man-to-anti-abortion-office-firebombing/ar-AA19cfdy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/dna-from-burrito-ties-wisconsin-man-to-anti-abortion-office-firebombing/ar-AA19cfdy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 03:22:54.350839+00:00



## 10 barges, including one carrying methanol, break free from tugboat on the Ohio River
 - [http://www.msn.com/en-us/news/us/10-barges-including-one-carrying-methanol-break-free-from-tugboat-on-the-ohio-river/ar-AA19ctSe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/10-barges-including-one-carrying-methanol-break-free-from-tugboat-on-the-ohio-river/ar-AA19ctSe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 03:22:54.342250+00:00



## China sending body armor components to Russia, investigation finds
 - [http://www.msn.com/en-us/news/world/china-sending-body-armor-components-to-russia-investigation-finds/ar-AA19crio?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-sending-body-armor-components-to-russia-investigation-finds/ar-AA19crio?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 03:22:54.334453+00:00



## Man stops traffic to help teacher, children escape Nashville school shooting
 - [http://www.msn.com/en-us/news/us/man-stops-traffic-to-help-teacher-children-escape-nashville-school-shooting/ar-AA19cyA8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/man-stops-traffic-to-help-teacher-children-escape-nashville-school-shooting/ar-AA19cyA8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 03:22:54.327429+00:00



## 38 dead after fire breaks out at migrant center
 - [http://www.msn.com/en-us/news/world/38-dead-after-fire-breaks-out-at-migrant-center/ar-AA19aD7m?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/38-dead-after-fire-breaks-out-at-migrant-center/ar-AA19aD7m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 03:22:54.320306+00:00



## Video shows guards walking away during fire that killed 38 at migrants facility
 - [http://www.msn.com/en-us/news/world/video-shows-guards-walking-away-during-fire-that-killed-38-at-migrants-facility/ar-AA19cyDI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/video-shows-guards-walking-away-during-fire-that-killed-38-at-migrants-facility/ar-AA19cyDI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 03:22:54.312091+00:00



## A 267-foot yacht with a hair salon and infinity pool has been 'abandoned' in the Caribbean and could be sold off — but the Russian oligarch it's linked to says it isn't his
 - [http://www.msn.com/en-us/news/world/a-267-foot-yacht-with-a-hair-salon-and-infinity-pool-has-been-abandoned-in-the-caribbean-and-could-be-sold-off-but-the-russian-oligarch-it-s-linked-to-says-it-isn-t-his/ar-AA19all5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-267-foot-yacht-with-a-hair-salon-and-infinity-pool-has-been-abandoned-in-the-caribbean-and-could-be-sold-off-but-the-russian-oligarch-it-s-linked-to-says-it-isn-t-his/ar-AA19all5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 03:22:54.304307+00:00



## Garland looks to hand off security duty for Supreme Court justices
 - [http://www.msn.com/en-us/news/politics/garland-looks-to-hand-off-security-duty-for-supreme-court-justices/ar-AA19cgyw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/garland-looks-to-hand-off-security-duty-for-supreme-court-justices/ar-AA19cgyw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 02:22:54.201635+00:00



## Serial star Adnan Syed's murder conviction reinstated after appeal of victim's family
 - [http://www.msn.com/en-us/news/crime/serial-star-adnan-syed-s-murder-conviction-reinstated-after-appeal-of-victim-s-family/ar-AA19clzs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/serial-star-adnan-syed-s-murder-conviction-reinstated-after-appeal-of-victim-s-family/ar-AA19clzs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 02:22:54.193846+00:00



## Friend says Nashville shooter texted her ‘I’m planning to die today’ minutes before shooting
 - [http://www.msn.com/en-us/news/politics/friend-says-nashville-shooter-texted-her-i-m-planning-to-die-today-minutes-before-shooting/ar-AA19clzE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/friend-says-nashville-shooter-texted-her-i-m-planning-to-die-today-minutes-before-shooting/ar-AA19clzE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 02:22:54.185641+00:00



## 2 officers shot while responding to call, hospitalized with life-threatening injuries
 - [http://www.msn.com/en-us/news/crime/2-officers-shot-while-responding-to-call-hospitalized-with-life-threatening-injuries/ar-AA19capu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/2-officers-shot-while-responding-to-call-hospitalized-with-life-threatening-injuries/ar-AA19capu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 02:22:54.175350+00:00



## Myanmar Junta Dissolves Suu Kyi’s Party After Poll Boycott
 - [http://www.msn.com/en-us/news/world/myanmar-junta-dissolves-suu-kyi-s-party-after-poll-boycott/ar-AA19bb3D?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/myanmar-junta-dissolves-suu-kyi-s-party-after-poll-boycott/ar-AA19bb3D?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 02:22:54.167504+00:00



## TUCKER CARLSON: The trans movement is targeting Christians
 - [http://www.msn.com/en-us/news/us/tucker-carlson-the-trans-movement-is-targeting-christians/ar-AA19clJA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tucker-carlson-the-trans-movement-is-targeting-christians/ar-AA19clJA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 02:22:54.159972+00:00



## Pence on ruling that he must testify in Jan. 6 probe: ‘I have nothing to hide’
 - [http://www.msn.com/en-us/news/politics/pence-on-ruling-that-he-must-testify-in-jan-6-probe-i-have-nothing-to-hide/ar-AA19ciRG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pence-on-ruling-that-he-must-testify-in-jan-6-probe-i-have-nothing-to-hide/ar-AA19ciRG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 01:22:47.831964+00:00



## Israel Judicial Reform Protests: What You Need to Know
 - [http://www.msn.com/en-us/video/news/israel-judicial-reform-protests-what-you-need-to-know/vi-AA19bMRk?srcref=rss](http://www.msn.com/en-us/video/news/israel-judicial-reform-protests-what-you-need-to-know/vi-AA19bMRk?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 01:22:47.823028+00:00



## Probe of chocolate factory blast focuses on gas pipeline
 - [http://www.msn.com/en-us/news/us/probe-of-chocolate-factory-blast-focuses-on-gas-pipeline/ar-AA19cbyt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/probe-of-chocolate-factory-blast-focuses-on-gas-pipeline/ar-AA19cbyt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 01:22:47.815190+00:00



## Sam Bankman-Fried allegedly bribed one Chinese official with $40 million
 - [http://www.msn.com/en-us/news/us/sam-bankman-fried-allegedly-bribed-one-chinese-official-with-40-million/ar-AA19aMwU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/sam-bankman-fried-allegedly-bribed-one-chinese-official-with-40-million/ar-AA19aMwU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 01:22:47.807948+00:00



## JESSE WATTERS: Kamala Harris is in Africa to 'shatter'
 - [http://www.msn.com/en-us/news/us/jesse-watters-kamala-harris-is-in-africa-to-shatter/ar-AA19c27Q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jesse-watters-kamala-harris-is-in-africa-to-shatter/ar-AA19c27Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 01:22:47.800703+00:00



## Philadelphia water 'safe to drink and use' after nearby chemical spill, city says
 - [http://www.msn.com/en-us/news/us/philadelphia-water-safe-to-drink-and-use-after-nearby-chemical-spill-city-says/ar-AA19clgp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/philadelphia-water-safe-to-drink-and-use-after-nearby-chemical-spill-city-says/ar-AA19clgp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 01:22:47.793470+00:00



## Swiss court case ties human rights to climate change
 - [http://www.msn.com/en-us/news/world/swiss-court-case-ties-human-rights-to-climate-change/ar-AA19clk1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/swiss-court-case-ties-human-rights-to-climate-change/ar-AA19clk1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 01:22:47.785646+00:00



## Garland wants marshals off security duty for Supreme Court justices
 - [http://www.msn.com/en-us/news/politics/garland-wants-marshals-off-security-duty-for-supreme-court-justices/ar-AA19cgyw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/garland-wants-marshals-off-security-duty-for-supreme-court-justices/ar-AA19cgyw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 01:22:47.775726+00:00



## After yet another school shooting, familiar arguments from Biden, lawmakers
 - [http://www.msn.com/en-us/news/politics/after-yet-another-school-shooting-familiar-arguments-from-biden-lawmakers/ar-AA19c6do?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/after-yet-another-school-shooting-familiar-arguments-from-biden-lawmakers/ar-AA19c6do?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 00:18:43.633991+00:00



## At least 39 dead in fire at a migrant center in Mexico near the U.S. border
 - [http://www.msn.com/en-us/news/world/at-least-39-dead-in-fire-at-a-migrant-center-in-mexico-near-the-u-s-border/ar-AA19bBen?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/at-least-39-dead-in-fire-at-a-migrant-center-in-mexico-near-the-u-s-border/ar-AA19bBen?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 00:18:43.618975+00:00



## Blake Lively roasts Wrexham AFC fan asking her to send message to his girlfriend
 - [http://www.msn.com/en-us/news/us/blake-lively-roasts-wrexham-afc-fan-asking-her-to-send-message-to-his-girlfriend/ar-AA19bMF2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/blake-lively-roasts-wrexham-afc-fan-asking-her-to-send-message-to-his-girlfriend/ar-AA19bMF2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 00:18:43.607973+00:00



## Prince Harry testifies he was kept in the dark about phone-tapping allegations
 - [http://www.msn.com/en-us/news/us/prince-harry-testifies-he-was-kept-in-the-dark-about-phone-tapping-allegations/ar-AA19ce7A?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/prince-harry-testifies-he-was-kept-in-the-dark-about-phone-tapping-allegations/ar-AA19ce7A?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 00:18:43.591386+00:00



## California takes on oil companies again with law that could cap profits in state
 - [http://www.msn.com/en-us/news/politics/california-takes-on-oil-companies-again-with-law-that-could-cap-profits-in-state/ar-AA19ckYT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/california-takes-on-oil-companies-again-with-law-that-could-cap-profits-in-state/ar-AA19ckYT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 00:18:43.580266+00:00



## Fishermen frauds plead guilty in cheating scandal
 - [http://www.msn.com/en-us/news/world/fishermen-frauds-plead-guilty-in-cheating-scandal/ar-AA19c6pF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fishermen-frauds-plead-guilty-in-cheating-scandal/ar-AA19c6pF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 00:18:43.562622+00:00



## New California gas price law another defeat for oil industry
 - [http://www.msn.com/en-us/news/us/new-california-gas-price-law-another-defeat-for-oil-industry/ar-AA19c9AN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/new-california-gas-price-law-another-defeat-for-oil-industry/ar-AA19c9AN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-29 00:18:43.551848+00:00



