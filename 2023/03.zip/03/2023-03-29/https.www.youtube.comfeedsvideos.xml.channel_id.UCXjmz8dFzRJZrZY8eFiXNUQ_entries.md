# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## How The Chronicles Of Riddick Failed Into A Franchise
 - [https://www.youtube.com/watch?v=sLiV70lorIw](https://www.youtube.com/watch?v=sLiV70lorIw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-03-29 17:00:24+00:00

When Pitch Black first came out, it seemed Riddick movies were onto something new and special.  Though as Chronicles of Riddick came out along side other installments it was clear that Vin Diesels dream was becoming more of a nightmare.  But how exactly did the Riddick movies turn out this bad?

#vindiesel #pitchblack #nerdstalgic 

Written by Dave Baker
Edited by Paul Ritchey

