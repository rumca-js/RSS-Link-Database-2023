# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Rosjanie stracili ponad 220 tys. żołnierzy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-stracili-ponad-220-tys-zolnierzy,nId,6685725](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-stracili-ponad-220-tys-zolnierzy,nId,6685725)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 22:11:07+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-stracili-ponad-220-tys-zolnierzy,nId,6685725"><img align="left" alt="Rosjanie stracili ponad 220 tys. żołnierzy" src="https://i.iplsc.com/rosjanie-stracili-ponad-220-tys-zolnierzy/000GYND2SDII1LVN-C321.jpg" /></a>​Od początku inwazji na Ukrainę zginęło lub zostało rannych ponad 220 tys. rosyjskich żołnierzy i najemników – powiedział w środę brytyjski minister obrony Ben Wallace, przywołując najnowsze amerykańskie szacunki. Dodał też, że Rosjanie obecnie nie czynią &quot;prawie żadnych postępów&quot;. </p><br clear="all" />

## Słup ognia widziany z kilkudziesięciu kilometrów. Wybuch gazociągu w Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-slup-ognia-widziany-z-kilkudziesieciu-kilometrow-wybuch-gazo,nId,6685715](https://wydarzenia.interia.pl/zagranica/news-slup-ognia-widziany-z-kilkudziesieciu-kilometrow-wybuch-gazo,nId,6685715)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 20:50:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-slup-ognia-widziany-z-kilkudziesieciu-kilometrow-wybuch-gazo,nId,6685715"><img align="left" alt="Słup ognia widziany z kilkudziesięciu kilometrów. Wybuch gazociągu w Rosji" src="https://i.iplsc.com/slup-ognia-widziany-z-kilkudziesieciu-kilometrow-wybuch-gazo/000GYN5HXF91F2YP-C321.jpg" /></a>W centralnej części Rosji doszło do wybuchu gazociągu. Słup ognia było widać z kilkudziesięciu kilometrów. Przyczyną eksplozji miało być rozszczelnienie, a na miejscu oprócz strażaków pracowali specjaliści z Gazpromu.</p><br clear="all" />

## Brazylijskie miasto nad przepaścią: To skutek ulewnych deszczy
 - [https://wydarzenia.interia.pl/zagranica/news-brazylijskie-miasto-nad-przepascia-to-skutek-ulewnych-deszcz,nId,6685694](https://wydarzenia.interia.pl/zagranica/news-brazylijskie-miasto-nad-przepascia-to-skutek-ulewnych-deszcz,nId,6685694)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 20:23:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brazylijskie-miasto-nad-przepascia-to-skutek-ulewnych-deszcz,nId,6685694"><img align="left" alt="Brazylijskie miasto nad przepaścią: To skutek ulewnych deszczy " src="https://i.iplsc.com/brazylijskie-miasto-nad-przepascia-to-skutek-ulewnych-deszcz/000GYN0566DETYE4-C321.jpg" /></a>Brazylijskie Buriticupu w stanie Maranhao na północy kraju znalazło się nad przepaścią. Dosłownie. Poważne osunięcia ziemi w zamieszkałym przez 70 tys. osób mieście to efekt ulewnych deszczów. Jak donoszą lokalne media, jeden z kraterów, który pojawił się na granicy Buriticupu, ma objętość 600 metrów sześciennych i głębokość ponad 70 metrów. Ludzie żyją w strachu. </p><br clear="all" />

## Rolnicy nie chcą opuścić ministerstwa. Kowalczyk wrócił na rozmowy
 - [https://wydarzenia.interia.pl/kraj/news-rolnicy-nie-chca-opuscic-ministerstwa-kowalczyk-wrocil-na-ro,nId,6685709](https://wydarzenia.interia.pl/kraj/news-rolnicy-nie-chca-opuscic-ministerstwa-kowalczyk-wrocil-na-ro,nId,6685709)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 20:10:11+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rolnicy-nie-chca-opuscic-ministerstwa-kowalczyk-wrocil-na-ro,nId,6685709"><img align="left" alt="Rolnicy nie chcą opuścić ministerstwa. Kowalczyk wrócił na rozmowy" src="https://i.iplsc.com/rolnicy-nie-chca-opuscic-ministerstwa-kowalczyk-wrocil-na-ro/000GYN0B15MOM082-C321.jpg" /></a>Pięciogodzinne obrady rolniczego &quot;okrągłego stołu&quot; nie zakończyły się podpisaniem porozumienia. Henryk Kowalczyk opuścił gmach ministerstwa. Środowiska rolnicze zapowiedziały jednak, że budynku nie opuszczą, dopóki właściwy dokument nie zostanie podpisany. Wicepremier ostatecznie wrócił na rozmowy.</p><br clear="all" />

## Rolniczy "okrągły stół". Jest porozumienie
 - [https://wydarzenia.interia.pl/kraj/news-rolniczy-okragly-stol-jest-porozumienie,nId,6685709](https://wydarzenia.interia.pl/kraj/news-rolniczy-okragly-stol-jest-porozumienie,nId,6685709)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 20:10:11+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rolniczy-okragly-stol-jest-porozumienie,nId,6685709"><img align="left" alt="Rolniczy &quot;okrągły stół&quot;. Jest porozumienie " src="https://i.iplsc.com/rolniczy-okragly-stol-jest-porozumienie/000GYNAQGB88HNXR-C321.jpg" /></a>Jest porozumienie między środowiskami rolniczymi a Ministerstwem Rolnictwa i Rozwoju Wsi. - Udało się dojść do porozumienia i trzeba jak najszybciej wprowadzać je w życie - powiedział po spotkaniu Michał Kołodziejczak, prezes AGROunii.  Trwające wiele godzin środowe obrady zakończyły się późnym wieczorem. </p><br clear="all" />

## Dwa morderstwa w Wielkopolsce. Trwa policyjna obława
 - [https://wydarzenia.interia.pl/kraj/news-dwa-morderstwa-w-wielkopolsce-trwa-policyjna-oblawa,nId,6685708](https://wydarzenia.interia.pl/kraj/news-dwa-morderstwa-w-wielkopolsce-trwa-policyjna-oblawa,nId,6685708)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 20:08:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dwa-morderstwa-w-wielkopolsce-trwa-policyjna-oblawa,nId,6685708"><img align="left" alt="Dwa morderstwa w Wielkopolsce. Trwa policyjna obława " src="https://i.iplsc.com/dwa-morderstwa-w-wielkopolsce-trwa-policyjna-oblawa/000D5EFR2LTDCL3J-C321.jpg" /></a>W Muchocinie w Wielkopolsce trwa policyjna obława. Funkcjonariusze poszukują osoby podejrzewanej o zabójstwo dwóch osób w dwóch różnych miejscach - podaje RMF FM.</p><br clear="all" />

## Belgia: Popełnił samobójstwo po rozmowach z chatbotem
 - [https://wydarzenia.interia.pl/zagranica/news-belgia-popelnil-samobojstwo-po-rozmowach-z-chatbotem,nId,6685651](https://wydarzenia.interia.pl/zagranica/news-belgia-popelnil-samobojstwo-po-rozmowach-z-chatbotem,nId,6685651)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 19:31:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-belgia-popelnil-samobojstwo-po-rozmowach-z-chatbotem,nId,6685651"><img align="left" alt="Belgia: Popełnił samobójstwo po rozmowach z chatbotem" src="https://i.iplsc.com/belgia-popelnil-samobojstwo-po-rozmowach-z-chatbotem/000GNW9Q67K9K3PB-C321.jpg" /></a>Belgijski dziennik &quot;La Libre&quot; poinformował o samobójstwie, do którego doprowadzić miała wielotygodniowa rozmowa mężczyzny z chatbotem &quot;Elizą&quot; firmy Chai. Trzydziestokilkulatek stwierdził, że poświęci swoje życie, jeśli sztuczna inteligencja obieca, że pomoże uratować świat przed zagładą. 

</p><br clear="all" />

## Ciężkie walki w rejonie Kupiańska. Rosjanie chwalą się, że zniszczyli polski sprzęt
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ciezkie-walki-w-rejonie-kupianska-rosjanie-chwala-sie-ze-zni,nId,6685669](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ciezkie-walki-w-rejonie-kupianska-rosjanie-chwala-sie-ze-zni,nId,6685669)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 18:52:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ciezkie-walki-w-rejonie-kupianska-rosjanie-chwala-sie-ze-zni,nId,6685669"><img align="left" alt="Ciężkie walki w rejonie Kupiańska. Rosjanie chwalą się, że zniszczyli polski sprzęt" src="https://i.iplsc.com/ciezkie-walki-w-rejonie-kupianska-rosjanie-chwala-sie-ze-zni/000GYMNCKHP5LK4S-C321.jpg" /></a>Rosjanie twierdzą, że na froncie zniszczyli polską armatohaubicę, którą przekazaliśmy w ramach pomocy dla broniącej się Ukrainy. Poza komunikatem nie przedstawili dowodów. Wskazali jednak, że do zniszczenia pojazdu użyli specjalnej amunicji - Krasnopol.</p><br clear="all" />

## Górki: 13-latek pobity w szkole. "Wieczorem zasłabł, w karetce dostał drgawek"
 - [https://wydarzenia.interia.pl/kraj/news-gorki-13-latek-pobity-w-szkole-wieczorem-zaslabl-w-karetce-d,nId,6685626](https://wydarzenia.interia.pl/kraj/news-gorki-13-latek-pobity-w-szkole-wieczorem-zaslabl-w-karetce-d,nId,6685626)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 18:19:20+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-gorki-13-latek-pobity-w-szkole-wieczorem-zaslabl-w-karetce-d,nId,6685626"><img align="left" alt="Górki: 13-latek pobity w szkole. &quot;Wieczorem zasłabł, w karetce dostał drgawek&quot;" src="https://i.iplsc.com/gorki-13-latek-pobity-w-szkole-wieczorem-zaslabl-w-karetce-d/000GYM80WLANF4EK-C321.jpg" /></a>W szkole podstawowej w Górkach (woj. wielkopolskie) pobito 13-letniego Daniela. Starsi chłopcy zaatakowali go w czasie przerwy, kiedy dzieci powinny być pod opieką nauczycieli. Policja zdarzenie nazwała &quot;sprzeczką&quot;. Kilka godzin po nim Daniel poczuł się gorzej, nagle osunął się, tracąc równowagę. W karetce dostał drgawek. Chłopak trafił do szpitala, gdzie spędził sześć dni. </p><br clear="all" />

## Hodował w domu marihuanę. Niezwykłe zdjęcie z policyjnego pościgu
 - [https://wydarzenia.interia.pl/zagranica/news-hodowal-w-domu-marihuane-niezwykle-zdjecie-z-policyjnego-pos,nId,6685654](https://wydarzenia.interia.pl/zagranica/news-hodowal-w-domu-marihuane-niezwykle-zdjecie-z-policyjnego-pos,nId,6685654)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 18:18:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-hodowal-w-domu-marihuane-niezwykle-zdjecie-z-policyjnego-pos,nId,6685654"><img align="left" alt="Hodował w domu marihuanę. Niezwykłe zdjęcie z policyjnego pościgu" src="https://i.iplsc.com/hodowal-w-domu-marihuane-niezwykle-zdjecie-z-policyjnego-pos/000GYMGK3XHKHP3D-C321.jpg" /></a>Mieszkaniec Wielkiej Brytanii usłyszał zarzut przemysłowej hodowli marihuany. Media społecznościowe obiegło zdjęcie z policyjnego nalotu na jego lokum. Widać na nim, że 32-latek próbował ukryć się przed policjantami na dachu. Na fotografii zobaczyć można także znajdującego się kilkadziesiąt centymetrów niżej policjanta, wyglądającego za podejrzanym przez okno.</p><br clear="all" />

## Niemcy: Rosyjska artystka wraca do berlińskiej opery
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-rosyjska-artystka-wraca-do-berlinskiej-opery,nId,6685598](https://wydarzenia.interia.pl/zagranica/news-niemcy-rosyjska-artystka-wraca-do-berlinskiej-opery,nId,6685598)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 18:12:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-rosyjska-artystka-wraca-do-berlinskiej-opery,nId,6685598"><img align="left" alt="Niemcy: Rosyjska artystka wraca do berlińskiej opery " src="https://i.iplsc.com/niemcy-rosyjska-artystka-wraca-do-berlinskiej-opery/000GYM2UJI0HFQET-C321.jpg" /></a>Rosyjska sopranistka, której zarzuca się bliskie relacje z Władimirem Putinem, Anna Netrebko powraca do Staatsoper (Berlińska Opera Państwowa). Informację o tym przekazał sam dyrektor artystyczny Matthias Schulz, przy okazji prezentacji nowego programu. Komentując jej angaż do roli Lady Makbet w operze Verdiego, Schulz przyznał, że Rosjanka &quot;jest wielką artystką&quot;. </p><br clear="all" />

## Taktyczna broń jądrowa na Białorusi. Co to oznacza?
 - [https://wydarzenia.interia.pl/zagranica/news-taktyczna-bron-jadrowa-na-bialorusi-co-to-oznacza,nId,6685635](https://wydarzenia.interia.pl/zagranica/news-taktyczna-bron-jadrowa-na-bialorusi-co-to-oznacza,nId,6685635)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 17:28:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-taktyczna-bron-jadrowa-na-bialorusi-co-to-oznacza,nId,6685635"><img align="left" alt="Taktyczna broń jądrowa na Białorusi. Co to oznacza?" src="https://i.iplsc.com/taktyczna-bron-jadrowa-na-bialorusi-co-to-oznacza/0005O36PA3LQYK0A-C321.jpg" /></a>Rosja rozmieści taktyczną broń nuklearną na Białorusi, po raz pierwszy od dziesięcioleci. Eksperci ds. obronności ostrzegają, że może to skrócić czas, jaki NATO będzie miało na reakcję w przypadku ataku.</p><br clear="all" />

## Sześciolatek zawisł na ogrodzeniu i zaczął się dusić. Jest w ciężkim stanie
 - [https://wydarzenia.interia.pl/lodzkie/news-szesciolatek-zawisl-na-ogrodzeniu-i-zaczal-sie-dusic-jest-w-,nId,6685629](https://wydarzenia.interia.pl/lodzkie/news-szesciolatek-zawisl-na-ogrodzeniu-i-zaczal-sie-dusic-jest-w-,nId,6685629)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 17:16:21+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-szesciolatek-zawisl-na-ogrodzeniu-i-zaczal-sie-dusic-jest-w-,nId,6685629"><img align="left" alt="Sześciolatek zawisł na ogrodzeniu i zaczął się dusić. Jest w ciężkim stanie" src="https://i.iplsc.com/szesciolatek-zawisl-na-ogrodzeniu-i-zaczal-sie-dusic-jest-w/000GYMA4A88K4TVV-C321.jpg" /></a>Sześcioletni chłopiec z gminy Żytno w powiecie radomszczańskim trafił w ciężkim stanie do szpitala. Podczas przechodzenia przez ogrodzenie, chłopiec zawisł na nim w niefortunny sposób i zaczął się dusić. - Na miejscu lądował śmigłowiec Lotniczego Pogotowia Ratunkowego - przekazała w rozmowie z Interią rzecznik prasowy KWP w Łodzi Aneta Sobieraj.</p><br clear="all" />

## Bezdomny twierdził, że podpalili go nastolatkowie. Prawda była inna
 - [https://wydarzenia.interia.pl/lubuskie/news-bezdomny-twierdzil-ze-podpalili-go-nastolatkowie-prawda-byla,nId,6685623](https://wydarzenia.interia.pl/lubuskie/news-bezdomny-twierdzil-ze-podpalili-go-nastolatkowie-prawda-byla,nId,6685623)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 16:59:52+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-bezdomny-twierdzil-ze-podpalili-go-nastolatkowie-prawda-byla,nId,6685623"><img align="left" alt="Bezdomny twierdził, że podpalili go nastolatkowie. Prawda była inna" src="https://i.iplsc.com/bezdomny-twierdzil-ze-podpalili-go-nastolatkowie-prawda-byla/000GYM87QCGB9CXN-C321.jpg" /></a>64-letni bezdomny mężczyzna z Gorzowa Wielkopolskiego twierdził, że nastolatkowie skrępowali go, a następnie podpalili mu włosy. Wszystko mieli nagrać telefonem komórkowym. Sprawą zajęła się policja. Okazało się, że historia przedstawiona przez rzekomego pokrzywdzonego nie miała miejsca. Jego obrażenia były wynikiem nieszczęśliwego wypadku - pożaru w namiocie, w którym nocował. </p><br clear="all" />

## Rosyjskie medyczki jak seksualne niewolnice. "Będziesz polową żoną"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-medyczki-jak-seksualne-niewolnice-bedziesz-polowa-,nId,6685597](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-medyczki-jak-seksualne-niewolnice-bedziesz-polowa-,nId,6685597)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 16:29:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-medyczki-jak-seksualne-niewolnice-bedziesz-polowa-,nId,6685597"><img align="left" alt="Rosyjskie medyczki jak seksualne niewolnice. &quot;Będziesz polową żoną&quot;" src="https://i.iplsc.com/rosyjskie-medyczki-jak-seksualne-niewolnice-bedziesz-polowa/000GYLZKSKGKGOYW-C321.jpg" /></a>Według informacji opublikowanych przez Radio &quot;Swaboda&quot; rosyjskie medyczki są traktowane na froncie jak seksualne niewolnice. W rozmowie z &quot;Radiem Swaboda&quot; jedna z kobiet opisuje, że pułkownik dowodzący jej plutonem wybrał ją na swoją &quot;polową żonę&quot;. Doszło do tego już podczas szkolenia w Niżnym Nowogrodzie. Kobieta powiedziała, że gdy odrzuciła zaloty mężczyzny, ten nakazał swoim żołnierzom, by zaczęli utrudniać jej życie.</p><br clear="all" />

## Australia: Szokujące sceny na placu zabaw. Nastolatek skakał po głowie dziewczynki
 - [https://wydarzenia.interia.pl/zagranica/news-australia-szokujace-sceny-na-placu-zabaw-nastolatek-skakal-p,nId,6685442](https://wydarzenia.interia.pl/zagranica/news-australia-szokujace-sceny-na-placu-zabaw-nastolatek-skakal-p,nId,6685442)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 16:10:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-australia-szokujace-sceny-na-placu-zabaw-nastolatek-skakal-p,nId,6685442"><img align="left" alt="Australia: Szokujące sceny na placu zabaw. Nastolatek skakał po głowie dziewczynki" src="https://i.iplsc.com/australia-szokujace-sceny-na-placu-zabaw-nastolatek-skakal-p/000GYLQXEFV68NM4-C321.jpg" /></a>13-latek brutalnie zaatakował dziewczynkę na placu zabaw w australijskim Cairns. Matka pokrzywdzonej opisała, że jej córka wróciła do domu cała posiniaczona. Media obiegło wstrząsające nagranie, na którym napastnik skacze po głowie siedmiolatki. </p><br clear="all" />

## Simonjan uderza w dziennikarkę, która sprzeciwiła się Putinowi. Ta odpowiada
 - [https://wydarzenia.interia.pl/zagranica/news-simonjan-uderza-w-dziennikarke-ktora-sprzeciwila-sie-putinow,nId,6685440](https://wydarzenia.interia.pl/zagranica/news-simonjan-uderza-w-dziennikarke-ktora-sprzeciwila-sie-putinow,nId,6685440)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 15:42:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-simonjan-uderza-w-dziennikarke-ktora-sprzeciwila-sie-putinow,nId,6685440"><img align="left" alt="Simonjan uderza w dziennikarkę, która sprzeciwiła się Putinowi. Ta odpowiada" src="https://i.iplsc.com/simonjan-uderza-w-dziennikarke-ktora-sprzeciwila-sie-putinow/000GYLQ4GDIGO6RE-C321.jpg" /></a>Dziennikarka, która sprzeciwiła się propagandzie Putina i musiała uciekać z Rosji, postanowiła wydać książkę. Na to zareagowała Margarita Simonjan - czołowa propagandystka rosyjskiego reżimu. Opowiedziała, że Marina Owsiannikowa jako nastolatka rzekomo oddawała się starszym mężczyznom. Skrytykowała też jej angielski. Dziennikarka odpowiedziała, przypominając przezwisko Simonjan - &quot;bobroedka&quot;, czyli zjadaczka bobrów.</p><br clear="all" />

## Tajemniczy obiekt przy Nord Stream 2. Wydobyły go duńskie siły zbrojne
 - [https://wydarzenia.interia.pl/zagranica/news-tajemniczy-obiekt-przy-nord-stream-2-wydobyly-go-dunskie-sil,nId,6685423](https://wydarzenia.interia.pl/zagranica/news-tajemniczy-obiekt-przy-nord-stream-2-wydobyly-go-dunskie-sil,nId,6685423)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 15:11:23+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tajemniczy-obiekt-przy-nord-stream-2-wydobyly-go-dunskie-sil,nId,6685423"><img align="left" alt="Tajemniczy obiekt przy Nord Stream 2. Wydobyły go duńskie siły zbrojne" src="https://i.iplsc.com/tajemniczy-obiekt-przy-nord-stream-2-wydobyly-go-dunskie-sil/000GYLNGLD1293PC-C321.jpg" /></a>Duńska Agencja Energii wydobyła obiekt znaleziony przy Nord Stream 2. Według wstępnych badań jest nim niestanowiąca zagrożenia pusta boja dymna lub granat dymny. </p><br clear="all" />

## Brazylia: 36-latka żywcem zamurowana w grobie. "To zemsta"
 - [https://wydarzenia.interia.pl/zagranica/news-brazylia-36-latka-zywcem-zamurowana-w-grobie-to-zemsta,nId,6685390](https://wydarzenia.interia.pl/zagranica/news-brazylia-36-latka-zywcem-zamurowana-w-grobie-to-zemsta,nId,6685390)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 14:35:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brazylia-36-latka-zywcem-zamurowana-w-grobie-to-zemsta,nId,6685390"><img align="left" alt="Brazylia: 36-latka żywcem zamurowana w grobie. &quot;To zemsta&quot;" src="https://i.iplsc.com/brazylia-36-latka-zywcem-zamurowana-w-grobie-to-zemsta/000GYLNHME5H2T0I-C321.jpg" /></a>36-latka została &quot;pogrzebana&quot; żywcem przez członków jednego z gangu w brazylijskim Visconde do Rio Branco. Zamurowaną kobietę uratowali policjanci ze stanu Minas Gerais - przekazały lokalne media. Według nieoficjalnych informacji był to odwet jednego z gangów działających na wschodzie Brazylii za stratę narkotyków grupy. </p><br clear="all" />

## Jechał pod wpływem. Potrącił motocyklistę. Drugi wyrok w sprawie Stuhra
 - [https://wydarzenia.interia.pl/kraj/news-jechal-pod-wplywem-potracil-motocykliste-drugi-wyrok-w-spraw,nId,6685388](https://wydarzenia.interia.pl/kraj/news-jechal-pod-wplywem-potracil-motocykliste-drugi-wyrok-w-spraw,nId,6685388)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 14:33:11+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jechal-pod-wplywem-potracil-motocykliste-drugi-wyrok-w-spraw,nId,6685388"><img align="left" alt="Jechał pod wpływem. Potrącił motocyklistę. Drugi wyrok w sprawie Stuhra" src="https://i.iplsc.com/jechal-pod-wplywem-potracil-motocykliste-drugi-wyrok-w-spraw/000G9W8Z9WTFO6SJ-C321.jpg" /></a>Jerzy Stuhr jest winnym spowodowania niebezpieczeństwa w ruchu drogowym, do którego doprowadził pod wpływem alkoholu - taki wyrok wydał 29 marca w sprawie krakowski sąd. Do zdarzenia doszło 17 października 2022 roku. Na znanego aktora została nałożona kara grzywny w wysokości trzech tysięcy złotych. Wydany wyrok jest nakazowy i pozostaje nieprawomocny.</p><br clear="all" />

## Watykan: Papież Franciszek w szpitalu. Ma przejść badania
 - [https://wydarzenia.interia.pl/zagranica/news-watykan-papiez-franciszek-w-szpitalu-ma-przejsc-badania,nId,6685377](https://wydarzenia.interia.pl/zagranica/news-watykan-papiez-franciszek-w-szpitalu-ma-przejsc-badania,nId,6685377)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 14:20:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-watykan-papiez-franciszek-w-szpitalu-ma-przejsc-badania,nId,6685377"><img align="left" alt="Watykan: Papież Franciszek w szpitalu. Ma przejść badania" src="https://i.iplsc.com/watykan-papiez-franciszek-w-szpitalu-ma-przejsc-badania/000GYLA77SGSQ93P-C321.jpg" /></a>Papież Franciszek przebywa w szpitalu w Rzymie, gdzie ma przejść wcześniej zaplanowane badania - poinformował dyrektor biura prasowego Watykanu Matteo Bruni.</p><br clear="all" />

## Rolniczy "okrągły stół". Resort kazał oddać telefony
 - [https://wydarzenia.interia.pl/kraj/news-rolniczy-okragly-stol-resort-kazal-oddac-telefony,nId,6685273](https://wydarzenia.interia.pl/kraj/news-rolniczy-okragly-stol-resort-kazal-oddac-telefony,nId,6685273)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 13:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rolniczy-okragly-stol-resort-kazal-oddac-telefony,nId,6685273"><img align="left" alt="Rolniczy &quot;okrągły stół&quot;. Resort kazał oddać telefony" src="https://i.iplsc.com/rolniczy-okragly-stol-resort-kazal-oddac-telefony/000GYK2Q7W2H9THU-C321.jpg" /></a>Przed rozpoczęciem rozmów ministra rolnictwa ze środowiskami rolniczymi w sprawie sytuacji na rynku zbóż doszło do kłótni. Resort zabronił uczestnikom korzystania z telefonów i innych sprzętów elektronicznych w czasie spotkania. Zapytany o tę decyzję minister Henryk Kowalczyk tłumaczył, że &quot;nie chce, by podsłuchiwał nas czy wywiad rosyjski, czy nawet Komisja Europejska, czy choćby nasza zaprzyjaźniona strona ukraińska&quot;. Swój sprzeciw wyraził m.in. lider AgroUnii Michał Kołodziejczak. W jego ocenie &quot;to pokazywanie standardu tego spotkania&quot;.</p><br clear="all" />

## W sklepie znalazły pożegnalny list. Natychmiastowa reakcja
 - [https://wydarzenia.interia.pl/malopolskie/news-w-sklepie-znalazly-pozegnalny-list-natychmiastowa-reakcja,nId,6685340](https://wydarzenia.interia.pl/malopolskie/news-w-sklepie-znalazly-pozegnalny-list-natychmiastowa-reakcja,nId,6685340)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 13:39:21+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-w-sklepie-znalazly-pozegnalny-list-natychmiastowa-reakcja,nId,6685340"><img align="left" alt="W sklepie znalazły pożegnalny list. Natychmiastowa reakcja" src="https://i.iplsc.com/w-sklepie-znalazly-pozegnalny-list-natychmiastowa-reakcja/00076RCCQ5GXD13A-C321.jpg" /></a>Mieszkanka Kęt chciała popełnić samobójstwo. Życie 19-latki uratowały ekspedientki perfumerii. Znalazły list pożegnalny zgubiony przez dziewczynę. Natychmiast zawiadomiły policję. Funkcjonariuszom udało się udaremnić próbę samobójczą młodej kobiety. 
</p><br clear="all" />

## Król Karol III z wizytą w Berlinie. "Celem poprawa stosunków z Europą"
 - [https://wydarzenia.interia.pl/zagranica/news-krol-karol-iii-z-wizyta-w-berlinie-celem-poprawa-stosunkow-z,nId,6685316](https://wydarzenia.interia.pl/zagranica/news-krol-karol-iii-z-wizyta-w-berlinie-celem-poprawa-stosunkow-z,nId,6685316)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 13:13:58+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-krol-karol-iii-z-wizyta-w-berlinie-celem-poprawa-stosunkow-z,nId,6685316"><img align="left" alt="Król Karol III z wizytą w Berlinie. &quot;Celem poprawa stosunków z Europą&quot;" src="https://i.iplsc.com/krol-karol-iii-z-wizyta-w-berlinie-celem-poprawa-stosunkow-z/000GYK6K3YNE24EL-C321.jpg" /></a>Król Karol III wraz z Królową Małżonką wybrali się z oficjalną wizytą do Niemiec. To pierwsza zagraniczna podróż Karola III od momentu objęcia brytyjskiego tronu. Samolot Voyager wraz z królewską parą na pokładzie wylądował na lotnisku Berlin Brandenburg chwilę po godzinie 14.</p><br clear="all" />

## Pogoda długoterminowa na Wielkanoc 2023. Nie mamy dobrych wieści
 - [https://wydarzenia.interia.pl/kraj/news-pogoda-dlugoterminowa-na-wielkanoc-2023-nie-mamy-dobrych-wie,nId,6683567](https://wydarzenia.interia.pl/kraj/news-pogoda-dlugoterminowa-na-wielkanoc-2023-nie-mamy-dobrych-wie,nId,6683567)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 13:11:42+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogoda-dlugoterminowa-na-wielkanoc-2023-nie-mamy-dobrych-wie,nId,6683567"><img align="left" alt="Pogoda długoterminowa na Wielkanoc 2023. Nie mamy dobrych wieści" src="https://i.iplsc.com/pogoda-dlugoterminowa-na-wielkanoc-2023-nie-mamy-dobrych-wie/000GYK5NOF490AD1-C321.jpg" /></a>Pogoda na Święta Wielkanocne lubi zaskakiwać. Każdy z nas preferuje wiosenną aurę i dużo słońca w tym świątecznym czasie. Niestety ostatnio coraz częściej występują niskie temperatury i opady deszczu, a nawet śniegu. I tym razem nie mamy dobrych wieści. Sprawdź prognozę pogody na Wielkanoc. </p><br clear="all" />

## Konflikt między matką a jej sąsiadem. Powodem hałas, jaki robią dzieci
 - [https://wydarzenia.interia.pl/zagranica/news-konflikt-miedzy-matka-a-jej-sasiadem-powodem-halas-jaki-robi,nId,6685228](https://wydarzenia.interia.pl/zagranica/news-konflikt-miedzy-matka-a-jej-sasiadem-powodem-halas-jaki-robi,nId,6685228)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 12:12:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-konflikt-miedzy-matka-a-jej-sasiadem-powodem-halas-jaki-robi,nId,6685228"><img align="left" alt="Konflikt między matką a jej sąsiadem. Powodem hałas, jaki robią dzieci" src="https://i.iplsc.com/konflikt-miedzy-matka-a-jej-sasiadem-powodem-halas-jaki-robi/000GYJY0W4TUSGUW-C321.jpg" /></a>Matka z Wielkiej Brytanii otrzymała od sąsiada list. &quot;Prawie codziennie, od wczesnego ranka, słychać uderzenia&quot; - przeczytała. Nadawca skarży się na hałas, jaki robią dzieci kobiety. Zagroził, że jeśli sąsiadka nie jest w stanie go kontrolować, ten zawiadomi administratora budynku. Konflikt podzielił także internautów. Część broni matki, pozostali - autora listu.</p><br clear="all" />

## Premier: Ograniczymy napływ ukraińskiego zboża do Polski
 - [https://wydarzenia.interia.pl/kraj/news-premier-ograniczymy-naplyw-ukrainskiego-zboza-do-polski,nId,6685242](https://wydarzenia.interia.pl/kraj/news-premier-ograniczymy-naplyw-ukrainskiego-zboza-do-polski,nId,6685242)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 11:56:09+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-ograniczymy-naplyw-ukrainskiego-zboza-do-polski,nId,6685242"><img align="left" alt="Premier: Ograniczymy napływ ukraińskiego zboża do Polski" src="https://i.iplsc.com/premier-ograniczymy-naplyw-ukrainskiego-zboza-do-polski/000GYJU4EVAS6FMT-C321.jpg" /></a>- Zleciłem wprowadzenie przepisów, które będą pozwalały ograniczyć wpływ zboża ukraińskiego do Polski - przekazał w środę na konferencji prasowej premier Mateusz Morawiecki. - Domagamy się od KE użycia wszelkich regulacji, które ograniczą lub zablokują wwóz ukraińskiego zboża do Polski, jako kraju docelowego - podkreślił szef rządu.</p><br clear="all" />

## Rosja wstrzymuje dane i zaczyna ćwiczenia. Chodzi o broń nuklearną
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wstrzymuje-dane-i-zaczyna-cwiczenia-chodzi-o-bron-nukl,nId,6685239](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wstrzymuje-dane-i-zaczyna-cwiczenia-chodzi-o-bron-nukl,nId,6685239)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 11:55:17+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wstrzymuje-dane-i-zaczyna-cwiczenia-chodzi-o-bron-nukl,nId,6685239"><img align="left" alt="Rosja wstrzymuje dane i zaczyna ćwiczenia. Chodzi o broń nuklearną" src="https://i.iplsc.com/rosja-wstrzymuje-dane-i-zaczyna-cwiczenia-chodzi-o-bron-nukl/000GYJTWQMVLCUDB-C321.jpg" /></a>Rosja zdecydowała, że nie będzie więcej przekazywała informacji o strategicznych siłach jądrowych. Podobną decyzję podjął rząd USA. &quot;Naszym celem jest zachęcenie Rosji do powrotu do przestrzegania traktatu&quot; - podkreślał w rozmowie z &quot;WSJ&quot; urzędnik administracji Joe Bidena.</p><br clear="all" />

## To on zlecił bombardowanie teatru w Mariupolu. Ujawniono dane Rosjanina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-to-on-zlecil-bombardowanie-teatru-w-mariupolu-ujawniono-dane,nId,6685235](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-to-on-zlecil-bombardowanie-teatru-w-mariupolu-ujawniono-dane,nId,6685235)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 11:51:36+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-to-on-zlecil-bombardowanie-teatru-w-mariupolu-ujawniono-dane,nId,6685235"><img align="left" alt="To on zlecił bombardowanie teatru w Mariupolu. Ujawniono dane Rosjanina" src="https://i.iplsc.com/to-on-zlecil-bombardowanie-teatru-w-mariupolu-ujawniono-dane/000GYJTN4DGA070D-C321.jpg" /></a>Zidentyfikowano Rosjanina, który zlecił bombardowania Teatru Dramatycznego oraz szpitala położniczego w Mariupolu. Rozkazy o przeprowadzeniu nalotów wydał 41-letni dowódca rosyjskiego pułku lotnictwa szturmowego Siergiej Atroszczenko - poinformował doradca mera Mariupola Petro Andruszczenko.</p><br clear="all" />

## Donald Tusk łowi w Senacie. Wiemy, kogo wybrał
 - [https://wydarzenia.interia.pl/kraj/news-donald-tusk-lowi-w-senacie-wiemy-kogo-wybral,nId,6685203](https://wydarzenia.interia.pl/kraj/news-donald-tusk-lowi-w-senacie-wiemy-kogo-wybral,nId,6685203)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 11:51:14+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-donald-tusk-lowi-w-senacie-wiemy-kogo-wybral,nId,6685203"><img align="left" alt="Donald Tusk łowi w Senacie. Wiemy, kogo wybrał" src="https://i.iplsc.com/donald-tusk-lowi-w-senacie-wiemy-kogo-wybral/000GYJRA3O3DPDTX-C321.jpg" /></a>Senatorzy Bogdan Zdrojewski i Krzysztof Brejza mają startować w wyborach do Sejmu - dowiedziała się Interia. To nie koniec znanych nazwisk, którymi Donald Tusk będzie próbował uwieść wyborców opozycji. - Szef przywiązuje większą wagę do zwycięstwa w Sejmie, bo to trudniejsze niż Senat - usłyszeliśmy w Koalicji Obywatelskiej. Z tego powodu lider Platformy zamierza również sięgnąć po europosłów. A ci wcale nie mówią &quot;nie&quot;.</p><br clear="all" />

## Jest decyzja posłów ws. "lex pilot"
 - [https://wydarzenia.interia.pl/kraj/news-jest-decyzja-poslow-ws-lex-pilot,nId,6685231](https://wydarzenia.interia.pl/kraj/news-jest-decyzja-poslow-ws-lex-pilot,nId,6685231)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 11:49:20+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jest-decyzja-poslow-ws-lex-pilot,nId,6685231"><img align="left" alt="Jest decyzja posłów ws. &quot;lex pilot&quot;" src="https://i.iplsc.com/jest-decyzja-poslow-ws-lex-pilot/000AGXCSN2CIMM89-C321.jpg" /></a>- Opozycja wygrała głosowanie w Sejmie i komisja cyfryzacji odrzuciła projekt ustawy nazywanej &quot;lex pilot&quot; - napisał poseł Platformy Obywatelskiej Arkadiusz Marchewka na Twitterze.</p><br clear="all" />

## Indonezja deportuje Rosjanina. Zrobił sobie nagie zdjęcia na świętej górze
 - [https://wydarzenia.interia.pl/zagranica/news-indonezja-deportuje-rosjanina-zrobil-sobie-nagie-zdjecia-na-,nId,6685151](https://wydarzenia.interia.pl/zagranica/news-indonezja-deportuje-rosjanina-zrobil-sobie-nagie-zdjecia-na-,nId,6685151)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 11:00:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-indonezja-deportuje-rosjanina-zrobil-sobie-nagie-zdjecia-na-,nId,6685151"><img align="left" alt="Indonezja deportuje Rosjanina. Zrobił sobie nagie zdjęcia na świętej górze" src="https://i.iplsc.com/indonezja-deportuje-rosjanina-zrobil-sobie-nagie-zdjecia-na/000GYJLM3LS6I2RN-C321.jpg" /></a>Rosyjski turysta imieniem Jurij ma zostać deportowany z Indonezji za rozebranie się na szczycie świętej góry Agung na Bali. Zdjęcia mężczyzny pozującego ze spodniami wokół kostek trafiły do sieci. Jurij przeprosił, lecz będzie miał zakaz ponownego wjazdu do Indonezji przez co najmniej sześć miesięcy.</p><br clear="all" />

## Torbiel wielkości piłki gimnastycznej. 20-latka nie widziała własnych stóp
 - [https://wydarzenia.interia.pl/zagranica/news-torbiel-wielkosci-pilki-gimnastycznej-20-latka-nie-widziala-,nId,6685089](https://wydarzenia.interia.pl/zagranica/news-torbiel-wielkosci-pilki-gimnastycznej-20-latka-nie-widziala-,nId,6685089)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 10:59:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-torbiel-wielkosci-pilki-gimnastycznej-20-latka-nie-widziala-,nId,6685089"><img align="left" alt="Torbiel wielkości piłki gimnastycznej. 20-latka nie widziała własnych stóp" src="https://i.iplsc.com/torbiel-wielkosci-pilki-gimnastycznej-20-latka-nie-widziala/000GYJGN7VR6NRXD-C321.jpg" /></a>Ważyła 50 kilogramów, a rozmiarem przypominała &quot;piłkę gimnastyczną&quot; - to torbiel, którą usunięto 20-latce z USA. Wszystko z powodu lekceważenia problemu zdrowotnego. Alison Fischer liczyła na to, że &quot;torbiel po prostu zniknie&quot;, ten zaś rozrósł się do olbrzymich rozmiarów.</p><br clear="all" />

## Policja znalazła ciało. Rozkładało się kilka miesięcy
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-policja-znalazla-cialo-rozkladalo-sie-kilka-miesiecy,nId,6685028](https://wydarzenia.interia.pl/zachodniopomorskie/news-policja-znalazla-cialo-rozkladalo-sie-kilka-miesiecy,nId,6685028)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 10:46:50+00:00

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-policja-znalazla-cialo-rozkladalo-sie-kilka-miesiecy,nId,6685028"><img align="left" alt="Policja znalazła ciało. Rozkładało się kilka miesięcy " src="https://i.iplsc.com/policja-znalazla-cialo-rozkladalo-sie-kilka-miesiecy/000GYIZQI55DEXHO-C321.jpg" /></a>Ciało mężczyzny w stanie zaawansowanego rozkładu, pokryte pleśnią, odnaleziono w Grabowie nieopodal Kamienia Pomorskiego (woj. zachodniopomorskie). - Odkryto je po kilku miesiącach od śmierci - powiedziała Interii sierż. Katarzyna Jasion z Komendy Powiatowej Policji w Kamieniu Pomorskim.</p><br clear="all" />

## Stomatolog z wyrokiem za gwałt. Sąd zmienił decyzję ws. zakazu wykonywania zawodu
 - [https://wydarzenia.interia.pl/lubelskie/news-stomatolog-z-wyrokiem-za-gwalt-sad-zmienil-decyzje-ws-zakazu,nId,6685116](https://wydarzenia.interia.pl/lubelskie/news-stomatolog-z-wyrokiem-za-gwalt-sad-zmienil-decyzje-ws-zakazu,nId,6685116)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 10:34:53+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-stomatolog-z-wyrokiem-za-gwalt-sad-zmienil-decyzje-ws-zakazu,nId,6685116"><img align="left" alt="Stomatolog z wyrokiem za gwałt. Sąd zmienił decyzję ws. zakazu wykonywania zawodu" src="https://i.iplsc.com/stomatolog-z-wyrokiem-za-gwalt-sad-zmienil-decyzje-ws-zakazu/000GYJBDU7GP8X2F-C321.jpg" /></a>Stomatolog Grzegorz T., którego uznano winnym za gwałt na pacjentce i doprowadzenia dwóch kobiet do poddania się innej czynności seksualnej otrzymał skrócony okres zakazu wykonywania zawodu. Sąd Okręgowy w Lublinie podtrzymał jednak wyrok dwóch lat i 10 miesięcy więzienia dla dentysty. Podniesiono również kwotę orzeczonego zadośćuczynienia wobec jednej z pokrzywdzonych do 25 tys. złotych. Adwokat Grzegorza T. przekazał, że jego klient &quot;będzie szanował wyrok&quot;.</p><br clear="all" />

## Szwecja wzywa ambasadora Rosji. Powodem słowa o "działaniach odwetowych"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szwecja-wzywa-ambasadora-rosji-powodem-slowa-o-dzialaniach-o,nId,6685140](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szwecja-wzywa-ambasadora-rosji-powodem-slowa-o-dzialaniach-o,nId,6685140)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 10:14:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szwecja-wzywa-ambasadora-rosji-powodem-slowa-o-dzialaniach-o,nId,6685140"><img align="left" alt="Szwecja wzywa ambasadora Rosji. Powodem słowa o &quot;działaniach odwetowych&quot;" src="https://i.iplsc.com/szwecja-wzywa-ambasadora-rosji-powodem-slowa-o-dzialaniach-o/000GYJDQT2U57J52-C321.jpg" /></a>Ministerstwo Spraw Zagranicznych Szwecji wzywa ambasadora Rosji w tym kraju. Resort chce złożyć skargę na komunikat opublikowany przez rosyjskiego ambasadora, w którym ocenił, że &quot;przystąpienie krajów nordyckich do NATO uczyniło je uzasadnionym celem rosyjskich działań odwetowych&quot;. </p><br clear="all" />

## Bójka w McDonald's. Nastolatka oraz matka i jej córka pobiły inną dziewczynę
 - [https://wydarzenia.interia.pl/zagranica/news-bojka-w-mcdonald-s-nastolatka-oraz-matka-i-jej-corka-pobily-,nId,6685077](https://wydarzenia.interia.pl/zagranica/news-bojka-w-mcdonald-s-nastolatka-oraz-matka-i-jej-corka-pobily-,nId,6685077)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 09:58:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bojka-w-mcdonald-s-nastolatka-oraz-matka-i-jej-corka-pobily-,nId,6685077"><img align="left" alt="Bójka w McDonald's. Nastolatka oraz matka i jej córka pobiły inną dziewczynę" src="https://i.iplsc.com/bojka-w-mcdonald-s-nastolatka-oraz-matka-i-jej-corka-pobily/000GYJ9R4I7GO5LJ-C321.jpg" /></a>W niemieckim Ansbach doszło do bójki. Początkowa kłótnia w restauracji McDonald's między 15- a 16-latką przerodziła się w poważny incydent. Według policji, napastniczką była także 38-letnia matka i jej 12-letnia córka - koleżanka jednej z nastolatek.</p><br clear="all" />

## Francja: Zaczął strzelać z karabinu maszynowego. Dwie osoby zginęły
 - [https://wydarzenia.interia.pl/zagranica/news-francja-zaczal-strzelac-z-karabinu-maszynowego-dwie-osoby-zg,nId,6685073](https://wydarzenia.interia.pl/zagranica/news-francja-zaczal-strzelac-z-karabinu-maszynowego-dwie-osoby-zg,nId,6685073)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 09:47:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-francja-zaczal-strzelac-z-karabinu-maszynowego-dwie-osoby-zg,nId,6685073"><img align="left" alt="Francja: Zaczął strzelać z karabinu maszynowego. Dwie osoby zginęły " src="https://i.iplsc.com/francja-zaczal-strzelac-z-karabinu-maszynowego-dwie-osoby-zg/000GYJ8SRUYAIP38-C321.jpg" /></a>We francuskiej dzielnicy Rennes w północno-zachodniej części Francji mężczyzna zaczął strzelać z karabinu maszynowego do grupy młodych osób. Dwie zmarły na miejscu. Do zdarzenia doszło w momencie, w którym w kraju dochodzi do masowych i agresywnych protestów związanych z podwyższeniem wieku emerytalnego. </p><br clear="all" />

## Przełom w badaniu Księżyca? Szklane kulki mają zawierać wodę
 - [https://wydarzenia.interia.pl/zagranica/news-przelom-w-badaniu-ksiezyca-szklane-kulki-maja-zawierac-wode,nId,6685074](https://wydarzenia.interia.pl/zagranica/news-przelom-w-badaniu-ksiezyca-szklane-kulki-maja-zawierac-wode,nId,6685074)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 09:36:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-przelom-w-badaniu-ksiezyca-szklane-kulki-maja-zawierac-wode,nId,6685074"><img align="left" alt="Przełom w badaniu Księżyca? Szklane kulki mają zawierać wodę" src="https://i.iplsc.com/przelom-w-badaniu-ksiezyca-szklane-kulki-maja-zawierac-wode/000GYJ9QBNBNBNBN-C321.jpg" /></a>Naukowcy dokonali nowego odkrycia na powierzchni Księżyca. W przebadanych próbkach gleby z naturalnego satelity Ziemi znaleziono drobne kulki, które mogą zawierać nawet miliardy ton wody. Eksperci podkreślają, że ciecz będzie można wydobyć po wcześniejszym podgrzaniu kulek do temperatury powyżej 100 stopni Celsjusza.</p><br clear="all" />

## Dwóch nastolatków z Lubartowa pobiło znajomego. Kopali i kazali przepraszać
 - [https://wydarzenia.interia.pl/lubelskie/news-dwoch-nastolatkow-z-lubartowa-pobilo-znajomego-kopali-i-kaza,nId,6685042](https://wydarzenia.interia.pl/lubelskie/news-dwoch-nastolatkow-z-lubartowa-pobilo-znajomego-kopali-i-kaza,nId,6685042)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 09:06:36+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-dwoch-nastolatkow-z-lubartowa-pobilo-znajomego-kopali-i-kaza,nId,6685042"><img align="left" alt="Dwóch nastolatków z Lubartowa pobiło znajomego. Kopali i kazali przepraszać" src="https://i.iplsc.com/dwoch-nastolatkow-z-lubartowa-pobilo-znajomego-kopali-i-kaza/000GYJ02YUFMTB18-C321.jpg" /></a>W Lubartowie dwóch chłopców w wieku 17 i 19 lat pobiło swojego znajomego. Pokrzywdzony 19-latek nie zgłosił się na policję. Funkcjonariusze aresztowali sprawców dzięki nagraniu. Jak podały lokalne media, widać na nim leżącego na ziemi zakrwawionego chłopaka, którego napastnicy kopią po głowie i każą przepraszać.</p><br clear="all" />

## 23-latka z 17-letnią "córką". "Nikt nie traktuje mnie poważnie"
 - [https://wydarzenia.interia.pl/zagranica/news-23-latka-z-17-letnia-corka-nikt-nie-traktuje-mnie-powaznie,nId,6684994](https://wydarzenia.interia.pl/zagranica/news-23-latka-z-17-letnia-corka-nikt-nie-traktuje-mnie-powaznie,nId,6684994)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 08:37:18+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-23-latka-z-17-letnia-corka-nikt-nie-traktuje-mnie-powaznie,nId,6684994"><img align="left" alt="23-latka z 17-letnią &quot;córką&quot;. &quot;Nikt nie traktuje mnie poważnie&quot;" src="https://i.iplsc.com/23-latka-z-17-letnia-corka-nikt-nie-traktuje-mnie-powaznie/000GYIIUJIX9FDLW-C321.jpg" /></a>23-letnia studentka pedagogiki Hunter Nelson podzieliła się ostatnio szczerym wyznaniem na TikToku. Jak zdradza, ma ona 17-letnią &quot;córkę&quot; Gracie i &quot;nikt nie traktuje jej poważnie&quot;. - Czułam, że robię to, co dla niej najlepsze, nawet jeśli było to bardzo trudne dla nas obojga - zaznacza młoda kobieta.</p><br clear="all" />

## Nastolatek próbował oszukać sprzedawcę przy zakupie kanapki. Grozi mu 8 lat więzienia
 - [https://wydarzenia.interia.pl/podkarpackie/news-nastolatek-probowal-oszukac-sprzedawce-przy-zakupie-kanapki-,nId,6685002](https://wydarzenia.interia.pl/podkarpackie/news-nastolatek-probowal-oszukac-sprzedawce-przy-zakupie-kanapki-,nId,6685002)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 08:34:30+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-nastolatek-probowal-oszukac-sprzedawce-przy-zakupie-kanapki-,nId,6685002"><img align="left" alt="Nastolatek próbował oszukać sprzedawcę przy zakupie kanapki. Grozi mu 8 lat więzienia" src="https://i.iplsc.com/nastolatek-probowal-oszukac-sprzedawce-przy-zakupie-kanapki/000GYIRF8IUSFRKK-C321.jpg" /></a>17-latek postanowił oszukać sprzedawcę w jednym ze sklepów w Mielcu. Do kanapki przykleił naklejkę informującą o przecenie &quot;-50%&quot;. Podszedł do kasy i zapłacił o ponad 5 złotych mniej niż powinien. Teraz nastolatkowi grozi 8 lat więzienia.</p><br clear="all" />

## Zabiła trzyletnią córeczkę. Zapadł wyrok
 - [https://wydarzenia.interia.pl/wielkopolskie/news-zabila-trzyletnia-coreczke-zapadl-wyrok,nId,6685027](https://wydarzenia.interia.pl/wielkopolskie/news-zabila-trzyletnia-coreczke-zapadl-wyrok,nId,6685027)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 08:33:12+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-zabila-trzyletnia-coreczke-zapadl-wyrok,nId,6685027"><img align="left" alt="Zabiła trzyletnią córeczkę. Zapadł wyrok" src="https://i.iplsc.com/zabila-trzyletnia-coreczke-zapadl-wyrok/000GYIT9QV69QXK0-C321.jpg" /></a>Jest wyrok dla Magdaleny C. Sąd Okręgowy w Poznaniu skazał kobietę na dożywocie za zabójstwo trzyletniej córeczki. Zbrodnia miała miejsce w 2021 roku. Wyrok nie jest prawomocny.</p><br clear="all" />

## Walki o Bachmut. Zełenski: Putin nie może poczuć krwi
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-walki-o-bachmut-zelenski-putin-nie-moze-poczuc-krwi,nId,6684066](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-walki-o-bachmut-zelenski-putin-nie-moze-poczuc-krwi,nId,6684066)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 08:21:27+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-walki-o-bachmut-zelenski-putin-nie-moze-poczuc-krwi,nId,6684066"><img align="left" alt="Walki o Bachmut. Zełenski: Putin nie może poczuć krwi" src="https://i.iplsc.com/walki-o-bachmut-zelenski-putin-nie-moze-poczuc-krwi/000GYIS3657LC15K-C321.jpg" /></a>- Jeśli Putin poczuje jakąś krew, wyczuje, że jesteśmy słabi - stwierdził prezydent Wołodymyr Zełenski w rozmowie z Associated Press, zaznaczając, że nie mogą przegrać walki o Bachmut. Ukraiński przywódca zaprosił także prezydenta Chin Xi Jinpinga do swojego kraju i zaznaczył, że chce z nim porozmawiać.</p><br clear="all" />

## Leciał w kierunku Bachmutu. Rosyjski bombowiec Su-24M trafiony
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-lecial-w-kierunku-bachmutu-rosyjski-bombowiec-su-24m-trafion,nId,6683633](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-lecial-w-kierunku-bachmutu-rosyjski-bombowiec-su-24m-trafion,nId,6683633)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 08:12:08+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-lecial-w-kierunku-bachmutu-rosyjski-bombowiec-su-24m-trafion,nId,6683633"><img align="left" alt="Leciał w kierunku Bachmutu. Rosyjski bombowiec Su-24M trafiony " src="https://i.iplsc.com/lecial-w-kierunku-bachmutu-rosyjski-bombowiec-su-24m-trafion/000GYII1NJUOVC3E-C321.jpg" /></a>Ukraińskie Siły Lotnicze z kolejnym sukcesem. W okolicach Bachmutu rakiety zastrzeliły rosyjski bombowiec Su-24M. </p><br clear="all" />

## Wziął kredyt na dom. Przez drożyznę zabrakło mu 100 tysięcy złotych
 - [https://wydarzenia.interia.pl/kraj/news-wzial-kredyt-na-dom-przez-drozyzne-zabraklo-mu-100-tysiecy-z,nId,6683540](https://wydarzenia.interia.pl/kraj/news-wzial-kredyt-na-dom-przez-drozyzne-zabraklo-mu-100-tysiecy-z,nId,6683540)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 07:59:42+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wzial-kredyt-na-dom-przez-drozyzne-zabraklo-mu-100-tysiecy-z,nId,6683540"><img align="left" alt="Wziął kredyt na dom. Przez drożyznę zabrakło mu 100 tysięcy złotych" src="https://i.iplsc.com/wzial-kredyt-na-dom-przez-drozyzne-zabraklo-mu-100-tysiecy-z/000AH0LZX1ET2QLS-C321.jpg" /></a>100 tysięcy złotych - dokładnie tyle zabrakło Michałowi, by sfinansować budowę domu. Kosztorys, który dostał we wrześniu 2021 roku, zakładał ceny nawet o połowę niższe. - Trafiłem na najgorszy czas - podkreśla mężczyzna. Najbardziej wzrosły ceny pomp ciepła, okien, okablowania, klimatyzacji, drewna czy kostki brukowej - wyliczają eksperci.</p><br clear="all" />

## Wyjątkowe narodziny. Rzadka foka kapturowa na plaży w Holandii
 - [https://wydarzenia.interia.pl/zagranica/news-wyjatkowe-narodziny-rzadka-foka-kapturowa-na-plazy-w-holandi,nId,6683650](https://wydarzenia.interia.pl/zagranica/news-wyjatkowe-narodziny-rzadka-foka-kapturowa-na-plazy-w-holandi,nId,6683650)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 07:58:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wyjatkowe-narodziny-rzadka-foka-kapturowa-na-plazy-w-holandi,nId,6683650"><img align="left" alt="Wyjątkowe narodziny. Rzadka foka kapturowa na plaży w Holandii" src="https://i.iplsc.com/wyjatkowe-narodziny-rzadka-foka-kapturowa-na-plazy-w-holandi/000GYIB5DM1ABRV4-C321.jpg" /></a>Na holenderskiej plaży w Vlieland zauważono rzadki rodzaj foki. Na dodatek okazało się, że samica niedawno urodziła. Kapturnik morski, bo o nim mowa, to zagrożony gatunek, żyjący zwykle w Arktyce. Ten drapieżny ssak wyróżnia się niezwykle krótkim czasem karmienia młodych mlekiem matki.</p><br clear="all" />

## Wieś pod Radomiem odcięta od świata. Ale za to będzie lotnisko
 - [https://wydarzenia.interia.pl/raport-transport-publiczny/news-wies-pod-radomiem-odcieta-od-swiata-ale-za-to-bedzie-lotnisk,nId,6681234](https://wydarzenia.interia.pl/raport-transport-publiczny/news-wies-pod-radomiem-odcieta-od-swiata-ale-za-to-bedzie-lotnisk,nId,6681234)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 07:55:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-transport-publiczny/news-wies-pod-radomiem-odcieta-od-swiata-ale-za-to-bedzie-lotnisk,nId,6681234"><img align="left" alt="Wieś pod Radomiem odcięta od świata. Ale za to będzie lotnisko" src="https://i.iplsc.com/wies-pod-radomiem-odcieta-od-swiata-ale-za-to-bedzie-lotnisk/000GYCUOK65AXXVJ-C321.jpg" /></a>Terminal gotowy, państwowy LOT w blokach startowych - nic tylko otwierać lotnisko w Radomiu, skąd dolecimy do miast odległych o setki kilometrów. Okolicznym mieszkańcom brakuje jednak nie samolotów do Italii, a jakiegokolwiek busa do powiatowego miasteczka. W Ostrówce mają dość proszenia sąsiadów o przysługę, gdy chcą dostać się do lekarza czy urzędu pracy. - Dojazd organizuję sobie kilka dni wcześniej. Taksówka nie dojeżdża, była kiedyś jedna - mówi Interii mieszkający tam Janusz Skóra. </p><br clear="all" />

## Resztki leków trafiają do wód. Zagrożenia nie są ujawniane
 - [https://wydarzenia.interia.pl/news-resztki-lekow-trafiaja-do-wod-zagrozenia-nie-sa-ujawniane,nId,6683634](https://wydarzenia.interia.pl/news-resztki-lekow-trafiaja-do-wod-zagrozenia-nie-sa-ujawniane,nId,6683634)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 07:31:44+00:00

<p><a href="https://wydarzenia.interia.pl/news-resztki-lekow-trafiaja-do-wod-zagrozenia-nie-sa-ujawniane,nId,6683634"><img align="left" alt="Resztki leków trafiają do wód. Zagrożenia nie są ujawniane " src="https://i.iplsc.com/resztki-lekow-trafiaja-do-wod-zagrozenia-nie-sa-ujawniane/0005YDNWFRJFIAVM-C321.jpg" /></a>Resztki leków trafiają do środowiska, w tym również do wody, którą piją ludzie. Mimo że dane o ryzyku, jakie się z tym wiąże istnieją, to nie zawsze są podawane do wiadomości publicznej. W Unii Europejskiej trwają negocjacje dotyczące nowych uregulowań obejmujących produktów leczniczych.</p><br clear="all" />

## Rekolekcje w szkołach. Spowiedź w kantorku wuefistów
 - [https://wydarzenia.interia.pl/kraj/news-rekolekcje-w-szkolach-spowiedz-w-kantorku-wuefistow,nId,6682887](https://wydarzenia.interia.pl/kraj/news-rekolekcje-w-szkolach-spowiedz-w-kantorku-wuefistow,nId,6682887)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 07:26:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rekolekcje-w-szkolach-spowiedz-w-kantorku-wuefistow,nId,6682887"><img align="left" alt="Rekolekcje w szkołach. Spowiedź w kantorku wuefistów" src="https://i.iplsc.com/rekolekcje-w-szkolach-spowiedz-w-kantorku-wuefistow/000GYD6BXY1978I0-C321.jpg" /></a>Rodzice dzieci nieuczestniczących w rekolekcjach uważają, że ich pociechy traktowane są gorzej niż rówieśnicy. Domagają się w tym czasie normalnych lekcji. Zarzucają, że Kościół wchodzi między szkolne mury jak &quot;do siebie&quot;. Zdarza się bowiem, że rekolekcje organizowane są w auli, a spowiedź odbywa się w kantorku wuefistów.</p><br clear="all" />

## Holendrzy odstraszają Anglików. "Trzymajcie się z daleka od Amsterdamu"
 - [https://wydarzenia.interia.pl/zagranica/news-holendrzy-odstraszaja-anglikow-trzymajcie-sie-z-daleka-od-am,nId,6683596](https://wydarzenia.interia.pl/zagranica/news-holendrzy-odstraszaja-anglikow-trzymajcie-sie-z-daleka-od-am,nId,6683596)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 06:52:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-holendrzy-odstraszaja-anglikow-trzymajcie-sie-z-daleka-od-am,nId,6683596"><img align="left" alt="Holendrzy odstraszają Anglików. &quot;Trzymajcie się z daleka od Amsterdamu&quot;" src="https://i.iplsc.com/holendrzy-odstraszaja-anglikow-trzymajcie-sie-z-daleka-od-am/000GYI264UW1CQLT-C321.jpg" /></a>Amsterdam szuka sposobu na odstraszenie &quot;uciążliwych turystów&quot;. Chodzi szczególnie o mężczyzn z Anglii, którzy przyjeżdżają do Holandii, by m.in. skorzystać z usług seksualnych na znanej z tego dzielnicy czerwonych latarni czy zapalić marihuanę. </p><br clear="all" />

## Górażdże: Nastolatek huśtał się nad wyrobiskiem i spadł. Lądował śmigłowiec
 - [https://wydarzenia.interia.pl/opolskie/news-gorazdze-nastolatek-hustal-sie-nad-wyrobiskiem-i-spadl-ladow,nId,6683613](https://wydarzenia.interia.pl/opolskie/news-gorazdze-nastolatek-hustal-sie-nad-wyrobiskiem-i-spadl-ladow,nId,6683613)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 06:35:39+00:00

<p><a href="https://wydarzenia.interia.pl/opolskie/news-gorazdze-nastolatek-hustal-sie-nad-wyrobiskiem-i-spadl-ladow,nId,6683613"><img align="left" alt="Górażdże: Nastolatek huśtał się nad wyrobiskiem i spadł. Lądował śmigłowiec" src="https://i.iplsc.com/gorazdze-nastolatek-hustal-sie-nad-wyrobiskiem-i-spadl-ladow/000GYI0DR20S1PJK-C321.jpg" /></a>Grupa młodzieży huśtała się nad wyrobiskiem w Górażdżach. Nastolatkowie przymocowali stalową linę do gałęzi. W pewnym momencie 15-latek ześlizgnął się z niej i spadł w kilkumetrowy rów.</p><br clear="all" />

## Atak na policję w Czeczenii. Na miejscu Kadyrow z synem
 - [https://wydarzenia.interia.pl/zagranica/news-atak-na-policje-w-czeczenii-na-miejscu-kadyrow-z-synem,nId,6683601](https://wydarzenia.interia.pl/zagranica/news-atak-na-policje-w-czeczenii-na-miejscu-kadyrow-z-synem,nId,6683601)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 06:24:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-atak-na-policje-w-czeczenii-na-miejscu-kadyrow-z-synem,nId,6683601"><img align="left" alt="Atak na policję w Czeczenii. Na miejscu Kadyrow z synem" src="https://i.iplsc.com/atak-na-policje-w-czeczenii-na-miejscu-kadyrow-z-synem/000GYHY4C2A77FH9-C321.jpg" /></a>Nocny atak na posterunek policji na granicy Inguszetii i Czeczenii. Jak informują analitycy zajmujący się białym wywiadem, po kilkukugodzinnych walkach trzy osoby zostały zabite. W mediach społecznościowych pojawiają się nagrania przedstawiające brutalne obchodzenie się ze zwłokami zabitych przez kadyrowców. Na miejscu miał pojawić się sam Ramzan Kadyrow, który zabrał ze sobą... syna.</p><br clear="all" />

## Mike Pence musi złożyć zeznania. Chodzi o wysiłki Trumpa w unieważnieniu wyborów w 2020 roku
 - [https://wydarzenia.interia.pl/zagranica/news-mike-pence-musi-zlozyc-zeznania-chodzi-o-wysilki-trumpa-w-un,nId,6683609](https://wydarzenia.interia.pl/zagranica/news-mike-pence-musi-zlozyc-zeznania-chodzi-o-wysilki-trumpa-w-un,nId,6683609)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 06:17:09+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mike-pence-musi-zlozyc-zeznania-chodzi-o-wysilki-trumpa-w-un,nId,6683609"><img align="left" alt="Mike Pence musi złożyć zeznania. Chodzi o wysiłki Trumpa w unieważnieniu wyborów w 2020 roku" src="https://i.iplsc.com/mike-pence-musi-zlozyc-zeznania-chodzi-o-wysilki-trumpa-w-un/000GYH6QTEJHVWY4-C321.jpg" /></a>Były wiceprezydent USA Mike Pence musi złożyć zeznania przed wielką ławą przysięgłych w dochodzeniu specjalnego prokuratora Jacka Smitha w sprawie wysiłków prezydenta Donalda Trumpa zmierzających do unieważnienia wyborów 2020 roku - orzekł sędzia James Boasberg. Jego zdaniem immunitet nie zwalnia całkowicie Pence'a od zeznawania na temat rozmów związanych z domniemaną &quot;nielegalnością&quot; postępowania byłego prezydenta.</p><br clear="all" />

## Sankcje handlowe wobec 5 chińskich firm. Amerykanie reagują na los Ujgurów
 - [https://wydarzenia.interia.pl/zagranica/news-sankcje-handlowe-wobec-5-chinskich-firm-amerykanie-reaguja-n,nId,6683560](https://wydarzenia.interia.pl/zagranica/news-sankcje-handlowe-wobec-5-chinskich-firm-amerykanie-reaguja-n,nId,6683560)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 05:54:52+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sankcje-handlowe-wobec-5-chinskich-firm-amerykanie-reaguja-n,nId,6683560"><img align="left" alt="Sankcje handlowe wobec 5 chińskich firm. Amerykanie reagują na los Ujgurów" src="https://i.iplsc.com/sankcje-handlowe-wobec-5-chinskich-firm-amerykanie-reaguja-n/000GYH2572QJJ4V3-C321.jpg" /></a>Waszyngton nałożył ograniczenia handlowe na pięć chińskich firm za pomoc w represjach wobec mniejszościowej grupy Ujgurów. Według Stanów, Pekin dopuszcza się na nich ludobójstwa. Chiny zaprzeczają. </p><br clear="all" />

## Biały jeleń w Leżajsku. "Widzę go tutaj po raz pierwszy"
 - [https://wydarzenia.interia.pl/podkarpackie/news-bialy-jelen-w-lezajsku-widze-go-tutaj-po-raz-pierwszy,nId,6683589](https://wydarzenia.interia.pl/podkarpackie/news-bialy-jelen-w-lezajsku-widze-go-tutaj-po-raz-pierwszy,nId,6683589)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 05:42:27+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-bialy-jelen-w-lezajsku-widze-go-tutaj-po-raz-pierwszy,nId,6683589"><img align="left" alt="Biały jeleń w Leżajsku. &quot;Widzę go tutaj po raz pierwszy&quot;" src="https://i.iplsc.com/bialy-jelen-w-lezajsku-widze-go-tutaj-po-raz-pierwszy/000GYH226VVUKC12-C321.jpg" /></a>W lasach w okolicy Leżajska spotkano białego jelenia. Specjaliści są zgodni, że to sensacja, a fakt, żeby taki osobnik biegł w stadzie jest bardzo rzadki, zdarza się bowiem, że białe jelenie są wykluczane z grupy, właśnie przez swoją odmienność. Nadleśnictwo Leżajsk opublikowało nagranie, na którym widać to wyjątkowe &quot;spotkanie&quot;.</p><br clear="all" />

## Holenderska telewizja przeprasza za użycie zdjęcia z Auschwitz-Birkenau
 - [https://wydarzenia.interia.pl/zagranica/news-holenderska-telewizja-przeprasza-za-uzycie-zdjecia-z-auschwi,nId,6683563](https://wydarzenia.interia.pl/zagranica/news-holenderska-telewizja-przeprasza-za-uzycie-zdjecia-z-auschwi,nId,6683563)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 05:32:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-holenderska-telewizja-przeprasza-za-uzycie-zdjecia-z-auschwi,nId,6683563"><img align="left" alt="Holenderska telewizja przeprasza za użycie zdjęcia z Auschwitz-Birkenau" src="https://i.iplsc.com/holenderska-telewizja-przeprasza-za-uzycie-zdjecia-z-auschwi/000GYGZDJ7GLPSVY-C321.jpg" /></a>Holenderska stacja RTL News przeprasza za użycie zdjęcia z Oświęcimia. W materiale informacyjnym o systemie kolejowym w Holandii pokazano zdjęcie torów prowadzących do obozu koncentracyjnego Auschwitz-Birkenau. &quot;To się nigdy nie powinno wydarzyć&quot; - napisano na Twitterze.</p><br clear="all" />

## Kontrole w domach Polaków. Jeśli nie chcesz stracić 3 tys. zł, lepiej wpuść inspektora
 - [https://wydarzenia.interia.pl/kraj/news-kontrole-w-domach-polakow-jesli-nie-chcesz-stracic-3-tys-zl-,nId,6683033](https://wydarzenia.interia.pl/kraj/news-kontrole-w-domach-polakow-jesli-nie-chcesz-stracic-3-tys-zl-,nId,6683033)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 05:25:44+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kontrole-w-domach-polakow-jesli-nie-chcesz-stracic-3-tys-zl-,nId,6683033"><img align="left" alt="Kontrole w domach Polaków. Jeśli nie chcesz stracić 3 tys. zł, lepiej wpuść inspektora" src="https://i.iplsc.com/kontrole-w-domach-polakow-jesli-nie-chcesz-stracic-3-tys-zl/000GYF3STCACXPQL-C321.jpg" /></a>O przyznanie dodatku węglowego można ubiegać się już od sierpnia 2022. Świadczenie miało na celu pomóc Polakom z kosztami ogrzewania w zimie. Od tego czasu ustawa uległa nowelizacji już kilka razy. Obecnie przeprowadzane są kontrole. Czy twój dom także będzie sprawdzany?</p><br clear="all" />

## Reforma sądownictwa w Izraelu. Biden: Nie mogą dalej iść tą drogą
 - [https://wydarzenia.interia.pl/zagranica/news-reforma-sadownictwa-w-izraelu-biden-nie-moga-dalej-isc-ta-dr,nId,6683561](https://wydarzenia.interia.pl/zagranica/news-reforma-sadownictwa-w-izraelu-biden-nie-moga-dalej-isc-ta-dr,nId,6683561)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 05:05:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-reforma-sadownictwa-w-izraelu-biden-nie-moga-dalej-isc-ta-dr,nId,6683561"><img align="left" alt="Reforma sądownictwa w Izraelu. Biden: Nie mogą dalej iść tą drogą" src="https://i.iplsc.com/reforma-sadownictwa-w-izraelu-biden-nie-moga-dalej-isc-ta-dr/000GYH0KC2CJMM76-C321.jpg" /></a>Prezydent USA Joe Biden wyraził we wtorek nadzieję, że izraelski rząd zrezygnuje z kontrowersyjnych reform sądownictwa, które wywołały masowe protesty. - Nie mogą dalej iść tą drogą - zaznaczył amerykański przywódca i dodał, że ma nadzieję, że tamtejszy rząd &quot;odejdzie&quot; od zmian, które zostały zaproponowane.</p><br clear="all" />

## Niezwykłe odkrycie. Nawet chwilowa utrata wagi jest dobra dla zdrowia
 - [https://wydarzenia.interia.pl/zagranica/news-niezwykle-odkrycie-nawet-chwilowa-utrata-wagi-jest-dobra-dla,nId,6683546](https://wydarzenia.interia.pl/zagranica/news-niezwykle-odkrycie-nawet-chwilowa-utrata-wagi-jest-dobra-dla,nId,6683546)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 04:37:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niezwykle-odkrycie-nawet-chwilowa-utrata-wagi-jest-dobra-dla,nId,6683546"><img align="left" alt="Niezwykłe odkrycie. Nawet chwilowa utrata wagi jest dobra dla zdrowia" src="https://i.iplsc.com/niezwykle-odkrycie-nawet-chwilowa-utrata-wagi-jest-dobra-dla/000GYGVL3V7C6SGV-C321.jpg" /></a>Nie od dziś wiadomo, że utrata masy ciała zmniejsza ryzyko przewlekłych chorób związanych z otyłością. Naukowcy dokonali jednak kolejnego odkrycia. Okazuje się, że osoby otyłe, które schudły, choćby i ponownie przybrały na wadze, po latach są mniej narażone na choroby serca i cukrzycę typu 2.</p><br clear="all" />

## Poufna rozmowa Sullivana z chińskim dyplomatą
 - [https://wydarzenia.interia.pl/zagranica/news-poufna-rozmowa-sullivana-z-chinskim-dyplomata,nId,6683547](https://wydarzenia.interia.pl/zagranica/news-poufna-rozmowa-sullivana-z-chinskim-dyplomata,nId,6683547)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 04:19:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-poufna-rozmowa-sullivana-z-chinskim-dyplomata,nId,6683547"><img align="left" alt="Poufna rozmowa Sullivana z chińskim dyplomatą " src="https://i.iplsc.com/poufna-rozmowa-sullivana-z-chinskim-dyplomata/000GHA8GO4H30SYJ-C321.jpg" /></a>Doradca ds. bezpieczeństwa narodowego USA Jake Sullivan rozmawiał w miniony piątek z czołowym dyplomatą ChRL Wangiem Yi - podał we wtorek Bloomberg, powołując się na wtajemniczone źródła. Żadna ze stron nie informowała o rozmowie. Do kontaktu doszło na kilka dni przed wizytą prezydent Tajwanu w USA. </p><br clear="all" />

## Wojna w Ukrainie. 399. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo,nzId,3979,akt,290612](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo,nzId,3979,akt,290612)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 03:47:48+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo,nzId,3979,akt,290612"><img align="left" alt="Wojna w Ukrainie. 399. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo/000GYGUPDHDF338W-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 399. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo,nzId,3979,akt,290705](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo,nzId,3979,akt,290705)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 03:47:48+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo,nzId,3979,akt,290705"><img align="left" alt="Wojna w Ukrainie. 399. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo/000GYGUPDHDF338W-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

## Wojna w Ukrainie. 399. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo,nzId,3979,akt,290816](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo,nzId,3979,akt,290816)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-29 03:47:48+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo,nzId,3979,akt,290816"><img align="left" alt="Wojna w Ukrainie. 399. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-399-dzien-inwazji-rosji-relacja-na-zywo/000GYGUPDHDF338W-C321.jpg" /></a>Najnowsze informacje z Ukrainy. Śledź relację na żywo w Interii</p><br clear="all" />

