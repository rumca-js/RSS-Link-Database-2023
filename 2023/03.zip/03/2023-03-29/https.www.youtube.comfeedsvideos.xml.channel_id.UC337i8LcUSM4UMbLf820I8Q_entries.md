# Source:Just Some Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q, language:en-US

## Captain Marvel Gets Cancelled... Again
 - [https://www.youtube.com/watch?v=pV8-qoGyFSI](https://www.youtube.com/watch?v=pV8-qoGyFSI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q
 - date published: 2023-03-29 20:15:02+00:00

Captain Marvel Gets Cancelled... Again
----------------------------------------------------------------------------------------------
Art and Animation by Just Some Guy

Original trailer concept: FMA Brotherhood & Black Summoner

Music: "Enkon Hakuchuumu" by Sakagami Souichi - Copyright (C) 2015 Trial & Error/Sakagami Souichi All rights reserved.

Trial & Error: http://www.tandess.com/en/music/

