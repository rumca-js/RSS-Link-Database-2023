# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Sister of Christopher Alder on 25-year fight for answers
 - [https://www.bbc.co.uk/news/uk-england-humber-65087872?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-humber-65087872?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 23:45:40+00:00

Christopher Alder's sister on fighting for answers about her brother's death and burial mix-up.

## Paul O'Grady: How Lily Savage defied police who raided a pub with rubber gloves
 - [https://www.bbc.co.uk/news/entertainment-arts-65115059?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65115059?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 23:36:45+00:00

O'Grady was preparing to go on stage in 1987 when a police officer burst into his dressing room.

## Easter holiday travel: No repeat of airport chaos, industry says
 - [https://www.bbc.co.uk/news/business-65113682?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65113682?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 23:14:32+00:00

Airports and airlines say they have enough staff to cope as they expect near 2019 levels of travel.

## Camera lost 13 years ago found with pictures intact
 - [https://www.bbc.co.uk/news/world-us-canada-65059553?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65059553?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 23:10:33+00:00

Spencer Greiner saw the camera poking out of the mud and posted photos it contained on social media.

## Arsenal: How Gunners delivered on potential in Champions League
 - [https://www.bbc.co.uk/sport/football/65120035?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65120035?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 23:08:20+00:00

Arsenal manager Jonas Eidevall says his side's performance in the League Cup final showed their potential - then they took it to Europe.

## Dmitry Muratov: The Russian journalist refusing to be silenced
 - [https://www.bbc.co.uk/news/world-europe-65119595?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65119595?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 23:00:33+00:00

Nobel Peace Prize laureate Dmitry Muratov is looking for hope in his country's younger generation.

## The unlikely rise of Gaelic football on the fields of Cambodia
 - [https://www.bbc.co.uk/sport/gaelic-games/65064562?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/gaelic-games/65064562?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 22:54:36+00:00

Gaelic football has been an unlikely source of joy, adventure and boundary-breaking change for young people in Cambodia.

## 'What Bach told us was wrong' - athletes criticise IOC president
 - [https://www.bbc.co.uk/sport/olympics/65120064?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/olympics/65120064?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 22:50:16+00:00

A host of international athletes criticise IOC president Thomas Bach's claim that Russians and Belarusians competing as neutrals in their sport "works".

## The Papers: 'Ta-ra Paul' and 'gender ideology in schools'
 - [https://www.bbc.co.uk/news/blogs-the-papers-65120001?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-65120001?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 22:41:06+00:00

Thursday's front pages include tributes to TV star and comedian Paul O'Grady.

## London Underground: 'Reunited with hero who saved me from death'
 - [https://www.bbc.co.uk/news/uk-wales-65013854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-65013854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 22:02:13+00:00

Tegan finds the "life-saving" stranger who pulled her from the track just before a train arrived.

## Migration dilemma leaves Rishi Sunak confronting an expensive mess
 - [https://www.bbc.co.uk/news/uk-politics-65115212?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65115212?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 21:49:02+00:00

Critics of the government say a legacy of asylum mismanagement means problems are stacking up.

## The 70s nuclear relic that may be about to open at last
 - [https://www.bbc.co.uk/news/world-asia-64634816?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-64634816?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 21:07:57+00:00

Finished in 1986, the Bataan plant in the Philippines has never produced a kilowatt of electricity.

## King Charles praises Ukraine support on state visit to Germany
 - [https://www.bbc.co.uk/news/uk-65115192?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65115192?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 20:20:25+00:00

The King promises to "strengthen" relations with the country and says they stand together on Ukraine.

## Laura Muir & Jemma Reekie quit training camp but leave coach behind
 - [https://www.bbc.co.uk/sport/athletics/65119499?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/65119499?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 19:27:26+00:00

Laura Muir and Jemma Reekie have unexpectedly cut short their altitude training camp, leaving long-term coach Andy Young in South Africa.

## Watch: King Charles speaking German in Berlin
 - [https://www.bbc.co.uk/news/uk-65118773?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65118773?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 19:09:53+00:00

The King joked with his hosts as he impressed with his language skills at a lavish banquet.

## Women's Six Nations 2023: Liz Crake on juggling dentistry with an England debut
 - [https://www.bbc.co.uk/sport/rugby-union/65119254?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65119254?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 19:07:06+00:00

Liz Crake is in demand. England want her, numerous clubs are interested - and then there are her dentistry patients.

## British Swimming Championships: Adam Peaty to miss April event, citing mental health reasons
 - [https://www.bbc.co.uk/sport/swimming/65116313?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/swimming/65116313?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 18:37:53+00:00

Britain's three-time Olympic champion Adam Peaty withdraws from April's British Swimming Championships, citing mental health reasons.

## Melissa Joan Hart: I helped kids flee shooting
 - [https://www.bbc.co.uk/news/world-us-canada-65114339?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65114339?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 17:54:20+00:00

The actress says she was near the Nashville school where a shooter opened fire, killing six.

## Man guilty of murdering train passenger with horseshoe in Reading
 - [https://www.bbc.co.uk/news/uk-england-berkshire-65104602?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-berkshire-65104602?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 17:33:29+00:00

Kirkpatrick Virgo attacked Thomas Parker after an argument over music being played on their train.

## Rishi Sunak's wife holds shares in childcare firm given Budget boost
 - [https://www.bbc.co.uk/news/uk-politics-65115204?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65115204?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 16:35:30+00:00

Rishi Sunak faces questions over the shares and says his interests have been declared "in the normal way".

## Pope Francis kept in hospital for checks
 - [https://www.bbc.co.uk/news/world-europe-65117270?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65117270?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 16:34:40+00:00

The Pontiff, 86, attended a scheduled appointment on Wednesday, and is now staying in hospital.

## Paul O'Grady alter ego Lily Savage 'a voice for a queer generation'
 - [https://www.bbc.co.uk/news/uk-65110778?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65110778?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 16:25:22+00:00

Fellow drag queens praised the character for helping to pave the way for thousands of artists.

## Associated Newspapers says Prince Harry and other accusers are 'out of time'
 - [https://www.bbc.co.uk/news/uk-65117106?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65117106?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 16:17:47+00:00

The Duke of Sussex and six others are bringing a legal case against Associated Newspapers.

## Renting: 'We were kicked out because we complained'
 - [https://www.bbc.co.uk/news/business-65114284?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65114284?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 16:02:36+00:00

Renters tell the BBC how they have been evicted for complaining about the state of their homes.

## Fulham: Boss Marco Silva and striker Aleksandar Mitrovic 'regret' their actions after red cards
 - [https://www.bbc.co.uk/sport/football/65116229?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65116229?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 16:00:59+00:00

Fulham boss Marco Silva and striker Aleksandar Mitrovic say they regret their actions and have apologised to referee Chris Kavanagh after they were sent off in FA Cup loss at Manchester United.

## Julian Knight: Met Police drop sexual assault investigation into Tory MP
 - [https://www.bbc.co.uk/news/uk-politics-65115208?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65115208?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 15:20:13+00:00

Julian Knight, who was suspended as a Tory MP over the case, had always denied the allegations.

## Anthony Joshua v Jermaine Franklin: Briton says now is the 'worst time' to fight him
 - [https://www.bbc.co.uk/sport/boxing/65105636?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/65105636?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 15:09:46+00:00

Briton Anthony Joshua says now is "the worst time" to face him in the ring and describes the current heavyweight landscape as a "shambles".

## Philip Schofield's brother 'admitted sex acts with teen'
 - [https://www.bbc.co.uk/news/uk-england-bristol-65114533?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-65114533?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 14:53:57+00:00

Timothy Schofield, 54, told his famous brother about sex acts with a teen boy, a court hears.

## GB face Australia, France & Switzerland in Davis Cup
 - [https://www.bbc.co.uk/sport/tennis/65111808?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65111808?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 14:48:10+00:00

Great Britain will face Australia, France and Switzerland in the group stage of the Davis Cup Finals in September in Manchester.

## Tributes paid to 'remarkable' Speaker Betty Boothroyd at funeral
 - [https://www.bbc.co.uk/news/uk-england-leeds-65113102?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-65113102?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 14:36:36+00:00

Baroness Boothroyd, who served as Commons Speaker from 1992 to 2000, died aged 93 in late February.

## IPL 2023: From Ben Stokes to Virat Kohli to Jos Buttler - all you need to know before tournament
 - [https://www.bbc.co.uk/sport/cricket/65082836?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65082836?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 14:09:35+00:00

As the Indian Premier League returns, BBC Sport looks at the tournament format and the England players who are involved this year.

## Antoine Dupont: France captain named Six Nations player of the championship
 - [https://www.bbc.co.uk/sport/rugby-union/65115866?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65115866?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 14:04:19+00:00

France captain Antoine Dupont is named the Six Nations player of the championship for the third time in four years.

## Esports: The female Call of Duty gamer making history
 - [https://www.bbc.co.uk/news/newsbeat-65113514?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-65113514?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 14:01:05+00:00

Kelsie Grieg became the first female to qualify for the Call of Duty Challengers Elite tournament.

## Elon Musk among experts urging a halt to AI training
 - [https://www.bbc.co.uk/news/technology-65110030?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65110030?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 13:41:32+00:00

Elon Musk among those calling for training in powerful artificial intelligence to be suspended.

## First cheetah cubs born in India since extinction 70 years ago
 - [https://www.bbc.co.uk/news/world-asia-india-65113651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-65113651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 13:11:55+00:00

The four cubs are the first to be born in the country since the big cat was declared extinct there.

## PMQs: Angela Rayner accuses Dominic Raab of failing rape victims
 - [https://www.bbc.co.uk/news/uk-politics-65110768?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65110768?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 13:05:39+00:00

Angela Rayner calls on the justice secretary to apologise for the "collapse" in charge rate for rape.

## Barmouth: David Redfern guilty of bed mix-up murder
 - [https://www.bbc.co.uk/news/uk-wales-65062565?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-65062565?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 13:02:21+00:00

David Redfern murdered 71-year-old Margaret Barnes after she mistook his home for a B&amp;B.

## Police call handlers used fake system for eight years
 - [https://www.bbc.co.uk/news/uk-scotland-tayside-central-65086107?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-tayside-central-65086107?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 13:00:09+00:00

Thousands of calls to a control room were allocated to a fictitious call sign to manipulate response times.

## Watch: Raab and Rayner spar on bullying and rape convictions
 - [https://www.bbc.co.uk/news/uk-politics-65109059?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65109059?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 12:59:35+00:00

The deputy PM and deputy Labour leader face each other for PMQs in the Commons.

## Video of deadly fire at Mexico migrant centre causes outrage
 - [https://www.bbc.co.uk/news/world-latin-america-65111258?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-65111258?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 12:28:42+00:00

Footage emerges which appears to show officers failing to open a cell door as the fire erupted.

## Paul O'Grady obituary: From Lily Savage to TV national treasure, with a love of dogs
 - [https://www.bbc.co.uk/news/entertainment-arts-65108950?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65108950?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 12:15:20+00:00

How Paul O'Grady went from a mould-breaking drag comedian to a much-loved prime-time TV host.

## 'Boy in the Tent' Max Woosey sets Guinness World Record for charity camp-out
 - [https://www.bbc.co.uk/news/uk-england-devon-65110616?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-devon-65110616?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 11:35:15+00:00

Max Woosey, 13, has spent every night for three years under canvas, raising more than £750,000.

## Fabio Paratici: Fifa places worldwide ban on Tottenham managing director
 - [https://www.bbc.co.uk/sport/football/65112730?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65112730?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 11:30:25+00:00

Tottenham's managing director Fabio Paratici may have to step away from his current role after Fifa extended an initial ban in Italy worldwide.

## Local elections 2023: When are they and who can vote?
 - [https://www.bbc.co.uk/news/uk-politics-65013652?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65013652?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 11:26:37+00:00

Voters in parts of England and in Northern Ireland will be able to elect new councillors in May.

## Mortgage lending hits lowest level since 2016 excluding pandemic
 - [https://www.bbc.co.uk/news/business-65112278?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65112278?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 11:08:45+00:00

Borrowing falls sharply as rates rise but more mortgage applications are approved, says Bank of England

## Thomas Cashman: Jury considers Olivia murder trial verdict
 - [https://www.bbc.co.uk/news/uk-england-merseyside-65088176?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-65088176?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 11:06:10+00:00

Thomas Cashman, 34, accused of shooting Olivia Pratt-Korbel, denies being the gunman.

## Paul O'Grady: Camilla says she is 'deeply saddened' by TV star's death
 - [https://www.bbc.co.uk/news/entertainment-arts-65062542?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65062542?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 10:55:36+00:00

The Queen Consort says the late broadcaster's "infectious humour lit up the lives of so many".

## South Asian Scots hope new leader gives them a voice
 - [https://www.bbc.co.uk/news/newsbeat-65110350?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-65110350?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 10:10:28+00:00

Humza Yousaf has made history as the first Muslim to lead a country in western Europe.

## Jason Smyth: Six-time Paralympic champion retires aged 35
 - [https://www.bbc.co.uk/sport/disability-sport/65100668?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/disability-sport/65100668?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 10:01:25+00:00

Ireland's Jason Smyth, who won 21 major titles in an illustrious sprinting career, announces his retirement at the age of 35.

## Women's Six Nations 2023: England's Poppy Cleall and Amber Reed unavailable for Italy
 - [https://www.bbc.co.uk/sport/rugby-union/65111524?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65111524?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 09:38:52+00:00

England forward Poppy Cleall and centre Amber Reed will be unavailable for Sunday's Women's Six Nations match against Italy after sustaining knee injuries against Scotland.

## Climate change: UK risks losing investment in net-zero race, MPs warn
 - [https://www.bbc.co.uk/news/uk-politics-65110764?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65110764?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 09:37:02+00:00

Some Tories are among those who fear jobs could move elsewhere if the government is not ambitious enough.

## Baroness Casey urges Met Police chief to accept problems are institutional
 - [https://www.bbc.co.uk/news/uk-65110300?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65110300?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 09:12:14+00:00

Baroness Casey said it would "mean so much" if Met Police chief Sir Mark Rowley accepted the term.

## Paul O'Grady: TV career highlights for presenter and comedian who died aged 67
 - [https://www.bbc.co.uk/news/entertainment-arts-65110970?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65110970?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 08:42:05+00:00

The TV presenter and comedian died "unexpectedly but peacefully" on Tuesday, his husband says.

## Adidas backtracks on Black Lives Matter design opposition
 - [https://www.bbc.co.uk/news/business-65107924?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65107924?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 07:34:48+00:00

The firm previously said a Black Lives Matter design would create confusion with its famous three-stripe mark.

## Women's Ashes 2023: Australia include Phoebe Litchfield in 15-player squad
 - [https://www.bbc.co.uk/sport/cricket/65109348?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65109348?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 07:07:58+00:00

Australia include teenage batter Phoebe Litchfield in their 15-player squad for the Women's Ashes against England.

## Next says price rises will be less than expected this year
 - [https://www.bbc.co.uk/news/business-65109131?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65109131?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 06:51:35+00:00

Lower shipping costs and factory prices means price rises will be lower this year, retailer says.

## Do Instagram and TikTok mean banks are less safe?
 - [https://www.bbc.co.uk/news/business-65107122?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65107122?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 06:38:11+00:00

The fastest bank run in US history was enabled by the speed of social media combined with digital banking.

## Anthony Joshua v Jermaine Franklin: Behind the scenes at Texas training camp
 - [https://www.bbc.co.uk/sport/av/boxing/65065370?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/boxing/65065370?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 05:11:33+00:00

Tony Bellew visits Anthony Joshua and new trainer Derrick James at the fighter's camp as he prepares for his comeback bout against Jermaine Franklin.

## Sioned Harries column: Wales not getting carried away ahead of Scotland test
 - [https://www.bbc.co.uk/sport/rugby-union/65094911?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65094911?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 05:07:01+00:00

In her BBC Wales Sport column, Sioned Harries reflects on a convincing win over Ireland and predicts a stern test against Scotland.

## Plans to house migrants on ex-military bases, barges and ferries to be unveiled
 - [https://www.bbc.co.uk/news/uk-65107827?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65107827?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 04:21:33+00:00

Immigration minister Robert Jenrick is to unveil the plans, billed as a "move to rudimentary accommodation".

## Paul O'Grady: A life in pictures
 - [https://www.bbc.co.uk/news/entertainment-arts-65107949?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65107949?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 03:48:26+00:00

His career spanned more than three decades - from drag acts in London, to an MBE and beyond.

## Liberal Democrats call for 8,000 extra GPs at local elections launch
 - [https://www.bbc.co.uk/news/uk-politics-65106745?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65106745?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 02:32:13+00:00

May's local elections are the "final chance" to send a message to the government, the Lib Dems say.

## TV star Paul O'Grady dies aged 67
 - [https://www.bbc.co.uk/news/entertainment-arts-65108130?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65108130?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 02:08:54+00:00

The TV presenter and comedian Paul O'Grady has died at the age of 67, his partner says.

## Gwyneth Paltrow 'visibly upset' after ski crash, says daughter
 - [https://www.bbc.co.uk/news/world-us-canada-65107933?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65107933?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 01:26:36+00:00

Testimony from Apple and Moses Martin was read to jurors about the 2016 collision on the slopes in Utah.

## Government sets out 'adaptable' regulation for AI
 - [https://www.bbc.co.uk/news/technology-65102210?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65102210?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 01:10:34+00:00

It proposes a set of principles for the "responsible use" of the tech, which is worth £3.7bn to UK economy.

## Government lacks urgency on climate change, warn advisors
 - [https://www.bbc.co.uk/news/science-environment-65099546?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-65099546?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 00:35:40+00:00

The government's advisors urge a "step change" in climate adaptation policy to avoid an increased risk to life.

## King Charles's first state visit: What to expect from Germany trip
 - [https://www.bbc.co.uk/news/uk-64954731?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64954731?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-29 00:28:49+00:00

Improving relations with Europe is the priority as the King's first state visit heads for Germany.

