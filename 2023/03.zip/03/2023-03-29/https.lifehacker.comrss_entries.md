# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## You Can Argue Against a Rent Increase
 - [https://lifehacker.com/you-can-argue-against-a-rent-increase-1850278581](https://lifehacker.com/you-can-argue-against-a-rent-increase-1850278581)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--dfZDh_MI--/c_fit,fl_progressive,q_80,w_636/fc98b9a5c59c8682685ce24a20f9e787.png" /><p>My lease renewal arrived it the mail a few weeks ago, bringing with it a small but significant rent increase. I’m hardly alone: Nationwide, average rents <a href="https://www.creditkarma.com/insights/i/average-rent-increase" rel="noopener noreferrer" target="_blank">rose by a heart-clutching 14% last year</a>, and <a href="https://www.dallasfed.org/research/economics/2022/0816" rel="noopener noreferrer" target="_blank">financial forecasts have for months been warning</a> of additional increases in the first half of 2023. It sucks to learn …</p><p><a href="https://lifehacker.com/you-can-argue-against-a-rent-increase-1850278581">Read more...</a></p>

## These JBL Noise-Canceling Earbuds Are Only $50 Right Now
 - [https://lifehacker.com/these-jbl-noise-canceling-earbuds-are-only-50-right-no-1850278993](https://lifehacker.com/these-jbl-noise-canceling-earbuds-are-only-50-right-no-1850278993)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--i0oLPgC9--/c_fit,fl_progressive,q_80,w_636/1fe4e048f50d1d5837d4e1a8a68aa71b.jpg" /><p>Woot is having another of their <a href="https://www.woot.com/" rel="noopener noreferrer" target="_blank">massive sales</a>, but one specific deals is sticking out among the rest: The <a href="https://electronics.woot.com/offers/new-jbl-live-free-nc-anc-earbuds-w-wireless-charging" rel="noopener noreferrer" target="_blank">JBL Live Free NC+ True Wireless earbuds</a> are currently 67% off their $150 listing price. For $50, you can get <a href="https://www.cnet.com/tech/mobile/jbl-launches-new-wireless-earbuds-for-ces-2021-to-compete-with-airpods-pro/#:~:text=JBL%20Live%20Free%20NC%20Plus,Noise%20Canceling%20with%20Smart%20Ambient" rel="noopener noreferrer" target="_blank">this pair of noise canceling Bluetooth earbuds</a> from now until April 1 (or while supplies last). But…</p><p><a href="https://lifehacker.com/these-jbl-noise-canceling-earbuds-are-only-50-right-no-1850278993">Read more...</a></p>

## Make Cinnamon Extract With Only Two Ingredients
 - [https://lifehacker.com/make-cinnamon-extract-with-only-two-ingredients-1850278864](https://lifehacker.com/make-cinnamon-extract-with-only-two-ingredients-1850278864)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--505zLlYu--/c_fit,fl_progressive,q_80,w_636/4f6a63be1455f2f56b871a9a64c9fc2a.jpg" /><p>It’s somewhat common knowledge that <a href="https://lifehacker.com/upgrade-your-baked-goods-with-almond-extract-1849903982" target="_blank">I boost my baked goods with almond extract</a> instead of, or in tandem with, vanilla. But now I’ve added a third extract to the extravaganza: cinnamon. Beyond being an exciting addition to your flavor toolkit, you can make cinnamon extract at home on the cheap, and in two simple steps.<br /></p><p><a href="https://lifehacker.com/make-cinnamon-extract-with-only-two-ingredients-1850278864">Read more...</a></p>

## This Is How to Tell Whether a Recipe Really Is ‘Easy’
 - [https://lifehacker.com/this-is-how-to-tell-whether-a-recipe-really-is-easy-1850277957](https://lifehacker.com/this-is-how-to-tell-whether-a-recipe-really-is-easy-1850277957)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--31u_0meM--/c_fit,fl_progressive,q_80,w_636/070d655018fa405d423e31a9e4cfdf97.jpg" /><p>I’ve been fooled by the headline “Easiest (meal name) Ever.” It’s wasn’t pretty. The ingredients were purchased. The prep work was done. Sadly, the joke was on me–the recipe was, in fact, not easy at all. It’s an attractive word and hard to resist, and although the recipe may have been rote for the creator, “easy”…</p><p><a href="https://lifehacker.com/this-is-how-to-tell-whether-a-recipe-really-is-easy-1850277957">Read more...</a></p>

## Don't Buy 'The Last of Us, Part 1' on PC
 - [https://lifehacker.com/dont-buy-the-last-of-us-part-1-on-pc-1850278163](https://lifehacker.com/dont-buy-the-last-of-us-part-1-on-pc-1850278163)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ewfXbjLJ--/c_fit,fl_progressive,q_80,w_636/72f9be7b6489cc4a3c687d0a6ed39c11.png" /><p><em>The Last of Us</em>, and its subsequent remasters, are excellent games. Naughty Dog created a story and world so compelling, not only are we still talking about it a decade later, but a new audience is doing the same in the wake of the first season of the critically acclaimed HBO adaptation. While the game’s recent arrival…</p><p><a href="https://lifehacker.com/dont-buy-the-last-of-us-part-1-on-pc-1850278163">Read more...</a></p>

## The Best Apps You’ve Never Used to Sell Your Used Furniture
 - [https://lifehacker.com/the-best-apps-you-ve-never-used-to-sell-your-used-furni-1850278382](https://lifehacker.com/the-best-apps-you-ve-never-used-to-sell-your-used-furni-1850278382)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--AKfUQz2_--/c_fit,fl_progressive,q_80,w_636/788f3e17b8cf30ce7fae2fd1c60661bb.jpg" /><p>Selling furniture is a great way to clear out your space and make some extra cash (which, realistically, you’ll put toward new furniture), but it’s not really an intuitive process. While there are plenty of apps out there dedicated to managing the sale of whatever you want to sell, it’s hard to know which ones to…</p><p><a href="https://lifehacker.com/the-best-apps-you-ve-never-used-to-sell-your-used-furni-1850278382">Read more...</a></p>

## What Is Zone 2 Cardio and How Do I Actually Do It?
 - [https://lifehacker.com/what-is-zone-2-cardio-and-how-do-i-actually-do-it-1850275966](https://lifehacker.com/what-is-zone-2-cardio-and-how-do-i-actually-do-it-1850275966)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 15:34:09+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ON_vt-03--/c_fit,fl_progressive,q_80,w_636/9e7397451c22213a35f19a0d92a5da78.jpg" /><p>Low intensity cardio—sometimes called LISS or “zone 2”—is an underrated form of exercise. It’s finally coming back into fashion after spending years on the sidelines while <a href="https://lifehacker.com/most-hiit-workouts-arent-really-hiit-1846409560" target="_blank">HIIT</a> and lifting-only routines ran the field. But what <em>is</em> zone 2 cardio, exactly? Why should you do it? And how do you know if you’re doing it…</p><p><a href="https://lifehacker.com/what-is-zone-2-cardio-and-how-do-i-actually-do-it-1850275966">Read more...</a></p>

## Here's the Best Time to Book Your Summer Travel
 - [https://lifehacker.com/heres-the-best-time-to-book-your-summer-travel-1850273155](https://lifehacker.com/heres-the-best-time-to-book-your-summer-travel-1850273155)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1shrwPby--/c_fit,fl_progressive,q_80,w_636/149faa41e1d83d1255945424dfdd08b7.jpg" /><p>This summer has the potential to be a nightmare  for those looking to travel, domestically or abroad. A combination of pandemic-related problems that permanently changed airlines are coming back to haunt travelers who once enjoyed discounted prices in past summers, along with inflation and higher demand, are all…</p><p><a href="https://lifehacker.com/heres-the-best-time-to-book-your-summer-travel-1850273155">Read more...</a></p>

## How to Respond to Every Type of Annoying Airline Passenger
 - [https://lifehacker.com/how-to-respond-to-every-type-of-annoying-airline-passen-1850277050](https://lifehacker.com/how-to-respond-to-every-type-of-annoying-airline-passen-1850277050)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 14:40:03+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--bptH80G7--/c_fit,fl_progressive,q_80,w_636/266da8a9eba055e9508b9b5df353435d.jpg" /><p>YouTube <a href="https://www.youtube.com/watch?v=EKq6hNWmqQ8" rel="noopener noreferrer" target="_blank">videos of unruly airplane passengers</a> are amusing, but a real-life encounter with an unhinged flyer at 35,000 feet can be terrifying. Luckily, it’s rare: While life-or-death conflicts <a href="https://www.nytimes.com/2023/03/06/us/united-airlines-arrest-stab-flight-attendant-emergency-exit." rel="noopener noreferrer" target="_blank">occasionally happen</a> on airplanes, according to the FAA, out of more than 13 million flights in 2022, <a href="https://www.faa.gov/data_research/passengers_cargo/unruly_passengers" rel="noopener noreferrer" target="_blank">only 831 such incidents</a> …</p><p><a href="https://lifehacker.com/how-to-respond-to-every-type-of-annoying-airline-passen-1850277050">Read more...</a></p>

## Attention: I Have Revolutionized Cheese Fries
 - [https://lifehacker.com/attention-i-have-revolutionized-cheese-fries-1850276074](https://lifehacker.com/attention-i-have-revolutionized-cheese-fries-1850276074)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ItAK7tdw--/c_fit,fl_progressive,q_80,w_636/fb00947ac55b5e608593342b101d1ebe.jpg" /><p>People like to say that weed makes you stupider, and I’m sure it doesn’t help if you’re studying differential equations or polymer chemistry (both of which I opted out of in college), but I’ve never found it hindered me in my line of work. If I’m so stupid, how did I invent a new kind of cheese fry?</p><p><a href="https://lifehacker.com/attention-i-have-revolutionized-cheese-fries-1850276074">Read more...</a></p>

## Everything You Can Clean With a Hand-Steamer (but Aren't)
 - [https://lifehacker.com/everything-you-can-clean-with-a-hand-steamer-but-arent-1850275364](https://lifehacker.com/everything-you-can-clean-with-a-hand-steamer-but-arent-1850275364)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--6AE2c6tZ--/c_fit,fl_progressive,q_80,w_636/2735b89e6508619b73846a68cef5934d.jpg" /><p>A steamer is a great alternative to an iron for a number of reasons: You’re not going to scorch your clothes with it, it’s easier to maneuver, and you don’t need a big, flat space to use it. It’s a quick way to de-wrinkle clothes without taking up valuable storage space in your home. But beyond not necessitating the…</p><p><a href="https://lifehacker.com/everything-you-can-clean-with-a-hand-steamer-but-arent-1850275364">Read more...</a></p>

## There's a Better Way to Open That Bag of Snacks
 - [https://lifehacker.com/theres-a-better-way-to-open-that-bag-of-snacks-1850274532](https://lifehacker.com/theres-a-better-way-to-open-that-bag-of-snacks-1850274532)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-29 13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--FRHu2uTx--/c_fit,fl_progressive,q_80,w_636/d590b71b815797317dd6b9c5feba586a.jpg" /><p>There are a couple of bag opening styles you can use when you don’t have a bowl–<a href="https://lifehacker.com/create-an-instant-snack-bowl-from-any-snack-bag-5508789" target="_blank">the fold-under bowl</a>, or <a href="https://lifehacker.com/the-easiest-way-to-open-and-turn-a-bag-of-snacks-into-a-1448130895" target="_blank">the puncture-and-twist</a> method– but not all snacks are chips, and some come in smaller packaging that might not fare as well with those other techniques. When it comes to sharing a bag of snacks with friends in a…</p><p><a href="https://lifehacker.com/theres-a-better-way-to-open-that-bag-of-snacks-1850274532">Read more...</a></p>

