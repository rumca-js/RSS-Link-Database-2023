# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Rural children now grow slightly taller than city children in wealthy countries
 - [https://www.scientificamerican.com/article/rural-children-now-grow-slightly-taller-than-city-children-in-wealthy-countries/](https://www.scientificamerican.com/article/rural-children-now-grow-slightly-taller-than-city-children-in-wealthy-countries/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 21:55:18+00:00

<p>Article URL: <a href="https://www.scientificamerican.com/article/rural-children-now-grow-slightly-taller-than-city-children-in-wealthy-countries/">https://www.scientificamerican.com/article/rural-children-now-grow-slightly-taller-than-city-children-in-wealthy-countries/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35364338">https://news.ycombinator.com/item?id=35364338</a></p>
<p>Points: 65</p>
<p># Comments: 56</p>

## Problem Details for HTTP APIs
 - [https://www.rfc-editor.org/rfc/rfc7807](https://www.rfc-editor.org/rfc/rfc7807)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 21:47:11+00:00

<p>Article URL: <a href="https://www.rfc-editor.org/rfc/rfc7807">https://www.rfc-editor.org/rfc/rfc7807</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35364224">https://news.ycombinator.com/item?id=35364224</a></p>
<p>Points: 10</p>
<p># Comments: 3</p>

## Type system of Fortnite's Verse language
 - [https://brianmckenna.org/blog/verse_types](https://brianmckenna.org/blog/verse_types)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 21:29:37+00:00

<p>Article URL: <a href="https://brianmckenna.org/blog/verse_types">https://brianmckenna.org/blog/verse_types</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35363993">https://news.ycombinator.com/item?id=35363993</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Fireside Chat with Clem Delangue, CEO of Hugging Face
 - [https://blog.eladgil.com/p/video-and-transcript-fireside-chat](https://blog.eladgil.com/p/video-and-transcript-fireside-chat)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 21:27:49+00:00

<p>Article URL: <a href="https://blog.eladgil.com/p/video-and-transcript-fireside-chat">https://blog.eladgil.com/p/video-and-transcript-fireside-chat</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35363967">https://news.ycombinator.com/item?id=35363967</a></p>
<p>Points: 31</p>
<p># Comments: 3</p>

## Judge finds Google destroyed evidence and repeatedly lied to the court [pdf]
 - [https://storage.courtlistener.com/recap/gov.uscourts.cand.373179/gov.uscourts.cand.373179.469.0.pdf](https://storage.courtlistener.com/recap/gov.uscourts.cand.373179/gov.uscourts.cand.373179.469.0.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 20:32:46+00:00

<p>Article URL: <a href="https://storage.courtlistener.com/recap/gov.uscourts.cand.373179/gov.uscourts.cand.373179.469.0.pdf">https://storage.courtlistener.com/recap/gov.uscourts.cand.373179/gov.uscourts.cand.373179.469.0.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35363095">https://news.ycombinator.com/item?id=35363095</a></p>
<p>Points: 174</p>
<p># Comments: 65</p>

## Wat [video] (2012)
 - [https://www.destroyallsoftware.com/talks/wat](https://www.destroyallsoftware.com/talks/wat)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 20:29:53+00:00

<p>Article URL: <a href="https://www.destroyallsoftware.com/talks/wat">https://www.destroyallsoftware.com/talks/wat</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35363044">https://news.ycombinator.com/item?id=35363044</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Sex and the Citizenship Process: Why people keep sending nudes to immigration
 - [https://lux-magazine.com/article/sex-and-the-citizenship-process/](https://lux-magazine.com/article/sex-and-the-citizenship-process/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 19:47:38+00:00

<p>Article URL: <a href="https://lux-magazine.com/article/sex-and-the-citizenship-process/">https://lux-magazine.com/article/sex-and-the-citizenship-process/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35362353">https://news.ycombinator.com/item?id=35362353</a></p>
<p>Points: 15</p>
<p># Comments: 0</p>

## I built an iMessage bot using Beeper
 - [https://www.getclearspace.com/beeper](https://www.getclearspace.com/beeper)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 19:27:30+00:00

<p>Article URL: <a href="https://www.getclearspace.com/beeper">https://www.getclearspace.com/beeper</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35362063">https://news.ycombinator.com/item?id=35362063</a></p>
<p>Points: 11</p>
<p># Comments: 7</p>

## Cerebras-GPT vs. LLaMA AI Model Performance Comparison
 - [https://www.lunasec.io/docs/blog/cerebras-gpt-vs-llama-ai-model-comparison/](https://www.lunasec.io/docs/blog/cerebras-gpt-vs-llama-ai-model-comparison/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 19:26:17+00:00

<p>Article URL: <a href="https://www.lunasec.io/docs/blog/cerebras-gpt-vs-llama-ai-model-comparison/">https://www.lunasec.io/docs/blog/cerebras-gpt-vs-llama-ai-model-comparison/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35362048">https://news.ycombinator.com/item?id=35362048</a></p>
<p>Points: 28</p>
<p># Comments: 10</p>

## In the age of AI, don't let your skills atrophy
 - [https://www.cyberdemon.org/2023/03/29/age-of-ai-skill-atrophy.html](https://www.cyberdemon.org/2023/03/29/age-of-ai-skill-atrophy.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 19:21:51+00:00

<p>Article URL: <a href="https://www.cyberdemon.org/2023/03/29/age-of-ai-skill-atrophy.html">https://www.cyberdemon.org/2023/03/29/age-of-ai-skill-atrophy.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35361979">https://news.ycombinator.com/item?id=35361979</a></p>
<p>Points: 39</p>
<p># Comments: 9</p>

## What is really going on at Amazon Fresh?
 - [https://emaggiori.com/amazon-fresh/](https://emaggiori.com/amazon-fresh/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 19:16:58+00:00

<p>Article URL: <a href="https://emaggiori.com/amazon-fresh/">https://emaggiori.com/amazon-fresh/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35361907">https://news.ycombinator.com/item?id=35361907</a></p>
<p>Points: 11</p>
<p># Comments: 7</p>

## Dumb phones are on the rise in the U.S. as Gen Z looks to limit screen time
 - [https://www.cnbc.com/2023/03/29/dumb-phones-are-on-the-rise-in-the-us-as-gen-z-limits-screen-time.html](https://www.cnbc.com/2023/03/29/dumb-phones-are-on-the-rise-in-the-us-as-gen-z-limits-screen-time.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 19:04:30+00:00

<p>Article URL: <a href="https://www.cnbc.com/2023/03/29/dumb-phones-are-on-the-rise-in-the-us-as-gen-z-limits-screen-time.html">https://www.cnbc.com/2023/03/29/dumb-phones-are-on-the-rise-in-the-us-as-gen-z-limits-screen-time.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35361721">https://news.ycombinator.com/item?id=35361721</a></p>
<p>Points: 18</p>
<p># Comments: 9</p>

## CSS is hard no matter how good you are at it
 - [https://www.aha.io/engineering/articles/css-is-hard-no-matter-how-good-you-are-at-it](https://www.aha.io/engineering/articles/css-is-hard-no-matter-how-good-you-are-at-it)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 18:58:32+00:00

<p>Article URL: <a href="https://www.aha.io/engineering/articles/css-is-hard-no-matter-how-good-you-are-at-it">https://www.aha.io/engineering/articles/css-is-hard-no-matter-how-good-you-are-at-it</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35361628">https://news.ycombinator.com/item?id=35361628</a></p>
<p>Points: 14</p>
<p># Comments: 9</p>

## I wanted a beautiful computer and couldn't find one, so I made my own
 - [https://www.mythic.computer/essays/origins](https://www.mythic.computer/essays/origins)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 18:46:18+00:00

<p>Article URL: <a href="https://www.mythic.computer/essays/origins">https://www.mythic.computer/essays/origins</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35361473">https://news.ycombinator.com/item?id=35361473</a></p>
<p>Points: 43</p>
<p># Comments: 28</p>

## A VC bought the Flatiron Building and didn’t pay for it
 - [https://hellgatenyc.com/some-guy-bought-the-flatiron-building-and-didnt-pay-for-it](https://hellgatenyc.com/some-guy-bought-the-flatiron-building-and-didnt-pay-for-it)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 18:41:10+00:00

<p>Article URL: <a href="https://hellgatenyc.com/some-guy-bought-the-flatiron-building-and-didnt-pay-for-it">https://hellgatenyc.com/some-guy-bought-the-flatiron-building-and-didnt-pay-for-it</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35361403">https://news.ycombinator.com/item?id=35361403</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Gambas – open-source Basic for Linux inspired by VB
 - [https://gambas.sourceforge.net/en/main.html](https://gambas.sourceforge.net/en/main.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 18:25:15+00:00

<p>Article URL: <a href="https://gambas.sourceforge.net/en/main.html">https://gambas.sourceforge.net/en/main.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35361192">https://news.ycombinator.com/item?id=35361192</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Qt Creator 10 Released
 - [https://www.qt.io/blog/qt-creator-10-released](https://www.qt.io/blog/qt-creator-10-released)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 18:22:45+00:00

<p>Article URL: <a href="https://www.qt.io/blog/qt-creator-10-released">https://www.qt.io/blog/qt-creator-10-released</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35361163">https://news.ycombinator.com/item?id=35361163</a></p>
<p>Points: 56</p>
<p># Comments: 22</p>

## OneAmerica Insurance CEO: Deaths Increase 40% Among People Ages 18-64
 - [https://headlineusa.com/oneamerica-insurance-ceo-deaths-increase-40-among-people-ages-18-64/](https://headlineusa.com/oneamerica-insurance-ceo-deaths-increase-40-among-people-ages-18-64/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 18:06:31+00:00

<p>Article URL: <a href="https://headlineusa.com/oneamerica-insurance-ceo-deaths-increase-40-among-people-ages-18-64/">https://headlineusa.com/oneamerica-insurance-ceo-deaths-increase-40-among-people-ages-18-64/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35360961">https://news.ycombinator.com/item?id=35360961</a></p>
<p>Points: 9</p>
<p># Comments: 3</p>

## Open Source HTTP Reverse Proxy Built in Rust for Immutable Infrastructures
 - [https://www.sozu.io/](https://www.sozu.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 18:00:31+00:00

<p>Article URL: <a href="https://www.sozu.io/">https://www.sozu.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35360878">https://news.ycombinator.com/item?id=35360878</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Original Prusa MK4
 - [https://www.prusa3d.com/product/original-prusa-mk4-2/](https://www.prusa3d.com/product/original-prusa-mk4-2/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 17:15:57+00:00

<p>Article URL: <a href="https://www.prusa3d.com/product/original-prusa-mk4-2/">https://www.prusa3d.com/product/original-prusa-mk4-2/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35360219">https://news.ycombinator.com/item?id=35360219</a></p>
<p>Points: 35</p>
<p># Comments: 27</p>

## 'Ultramassive' black hole discovered – bigger than the majority of galaxies
 - [https://www.bbc.com/news/uk-england-tyne-65109663](https://www.bbc.com/news/uk-england-tyne-65109663)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 17:05:07+00:00

<p>Article URL: <a href="https://www.bbc.com/news/uk-england-tyne-65109663">https://www.bbc.com/news/uk-england-tyne-65109663</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35360081">https://news.ycombinator.com/item?id=35360081</a></p>
<p>Points: 27</p>
<p># Comments: 8</p>

## Blender 3.5
 - [https://www.blender.org/download/releases/3-5/](https://www.blender.org/download/releases/3-5/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 16:43:24+00:00

<p>Article URL: <a href="https://www.blender.org/download/releases/3-5/">https://www.blender.org/download/releases/3-5/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35359784">https://news.ycombinator.com/item?id=35359784</a></p>
<p>Points: 85</p>
<p># Comments: 29</p>

## Show HN: go-nbd – A Pure Go NBD Server and Client
 - [https://github.com/pojntfx/go-nbd](https://github.com/pojntfx/go-nbd)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 16:23:21+00:00

<p>Hey HN! I just released go-nbd, a lightweight Go library for effortlessly creating NBD servers and clients. Its a neat tool for creating custom Linux (network) block devices with arbitrary backends, such as a file, byte slice or what I'm planning to use it for, a tape drive. While there are a few partially abandoned projects like this out there already, this library tries to be as maintainable as possible by only implementing the most recent handshake revision and baseline functionality for both the client and the server, while still having enough support to be useful.<p>I'd love to get your feedback :)</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35359473">https://news.ycombinator.com/item?id=35359473</a></p>
<p>Points: 20</p>
<p># Comments: 2</p>

## Bing Chat now has Ads
 - [https://twitter.com/debarghya_das/status/1640892791923572737](https://twitter.com/debarghya_das/status/1640892791923572737)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 16:15:34+00:00

<p>Article URL: <a href="https://twitter.com/debarghya_das/status/1640892791923572737">https://twitter.com/debarghya_das/status/1640892791923572737</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35359338">https://news.ycombinator.com/item?id=35359338</a></p>
<p>Points: 15</p>
<p># Comments: 12</p>

## Clues to the Lives of North America’s First Inhabitants Are Hidden Underwater
 - [https://www.smithsonianmag.com/history/biggest-clues-lives-early-americans-hidden-underwater-submerged-prehistory-180981891/](https://www.smithsonianmag.com/history/biggest-clues-lives-early-americans-hidden-underwater-submerged-prehistory-180981891/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 16:12:42+00:00

<p>Article URL: <a href="https://www.smithsonianmag.com/history/biggest-clues-lives-early-americans-hidden-underwater-submerged-prehistory-180981891/">https://www.smithsonianmag.com/history/biggest-clues-lives-early-americans-hidden-underwater-submerged-prehistory-180981891/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35359295">https://news.ycombinator.com/item?id=35359295</a></p>
<p>Points: 16</p>
<p># Comments: 6</p>

## The Teen Mental Illness Epidemic Is International, Part 1: The Anglosphere
 - [https://jonathanhaidt.substack.com/p/international-mental-illness-part-one](https://jonathanhaidt.substack.com/p/international-mental-illness-part-one)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 16:11:04+00:00

<p>Article URL: <a href="https://jonathanhaidt.substack.com/p/international-mental-illness-part-one">https://jonathanhaidt.substack.com/p/international-mental-illness-part-one</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35359271">https://news.ycombinator.com/item?id=35359271</a></p>
<p>Points: 16</p>
<p># Comments: 7</p>

## Disney Lays Off Ike Perlmutter, Chairman of Marvel Entertainment
 - [https://www.nytimes.com/2023/03/29/business/media/disney-marvel-ike-perlmutter.html](https://www.nytimes.com/2023/03/29/business/media/disney-marvel-ike-perlmutter.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 15:46:24+00:00

<p>Article URL: <a href="https://www.nytimes.com/2023/03/29/business/media/disney-marvel-ike-perlmutter.html">https://www.nytimes.com/2023/03/29/business/media/disney-marvel-ike-perlmutter.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35358926">https://news.ycombinator.com/item?id=35358926</a></p>
<p>Points: 22</p>
<p># Comments: 11</p>

## Launch HN: Vocode (YC W23) – Library for realtime voice conversation with LLMs
 - [https://news.ycombinator.com/item?id=35358873](https://news.ycombinator.com/item?id=35358873)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 15:43:36+00:00

<p>Hey everyone! Kian and Ajay here from Vocode–an open source library for building LLM applications you can talk to. Vocode makes it easy to take any text-based LLM and make it voice-based. Our repo is at <a href="https://github.com/vocodedev/vocode-python">https://github.com/vocodedev/vocode-python</a> and our docs are at <a href="https://docs.vocode.dev">https://docs.vocode.dev</a>.<p>Building realtime voice apps with LLMs is powerful but hard. You have to orchestrate the speech recognition, LLM, and speech synthesis in real-time (all async)–while handling the complexity of conversation (like understanding when someone is finished speaking or handling interruptions).<p>Our library is easy to get up and running–you can set up a conversation in <15 lines of code. Check out our Gen Z GPT hotline demo: <a href="https://replit.com/@vocode/Gen-Z-Phone">https://replit.com/@vocode/Gen-Z-Phone</a> (try it out at +1-650-729-9536).<p>It all started with our PrankGPT project that we built for fun (quick demo at <a href="https://www.loom.com/share/0d0d68f1a62f409eb5ae24521293d2dc" rel="nofollow">https://www.loom.com/share/0d0d68f1a62f409eb5ae24521293d2dc</a>). We realized how powerful voice + LLMs are but that it was hard to build.<p>Once we got everything working, it was really cool and useful. Talking to LLMs is better than all the voice AI experiences we’ve had before. And, we imagined a host of cool applications that people can build on top of that.<p>So, we decided to build a developer tool to make it easy. Our library is open source and gives you everything you need in a single place.<p>We give you a bunch of integrations out-of-the-box to speech recognition/synthesis providers and let you swap them out easily. We have platform support across web and telephony (via Twilio), with mobile coming soon. We also provide abstractions for streaming conversation (this is good for realtime apps like phone calls) and for command-based/turn-based applications (like voice-based chess). And, we provide customizability around how the conversation is done—things like how to know when someone is finished speaking, changing emotion, sending filler audio if there are delays, etc.<p>In terms of “how do you make money” – we have a hosted version that we’re going to charge for (though right now you can get it for free! <a href="https://app.vocode.dev">https://app.vocode.dev</a>) and we're also going to build enterprise products in the future.<p>We’d love for you to try it out and give us some feedback! And, if you have any demos you'd like to see – let us know and we’ll take a crack at building them. We’re curious about your experiences using or building voice AI, what features or use cases you’d love to see, and any other ideas you have to share!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35358873">https://news.ycombinator.com/item?id=35358873</a></p>
<p>Points: 20</p>
<p># Comments: 13</p>

## Show HN: Mirrorful – A developer-first way to implement designs faster
 - [https://github.com/Mirrorful/mirrorful](https://github.com/Mirrorful/mirrorful)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 15:19:24+00:00

<p>Hey HN! Mirrorful (<a href="https://www.mirrorful.com/">https://www.mirrorful.com/</a>) is an open-source developer framework that helps front-end engineers manage their design systems. We’ve been building Mirrorful with the open-source community (<a href="https://github.com/Mirrorful/mirrorful">https://github.com/Mirrorful/mirrorful</a>) and wanted to share our beta with you. Check out our online demo to get the idea: <a href="https://app.mirrorful.com/">https://app.mirrorful.com/</a>.<p>Design systems can be thought of as the “building blocks of your app” which makes me think of Lego bricks. Mirrorful helps you manage your codebase’s Lego bricks and ensure that they are consistent across all of your apps and platforms.<p>We saw as product engineers how hard it is to get code to match Figma mock ups. High-quality design is a competitive advantage, so getting your UI pixel perfect can matter a lot, but is time-consuming and tedious.<p>When we worked for large public companies, we saw that good component libraries help, but engineers are often still dealing with tweaking small design decisions. There are a lot of inefficiencies. We also worked at a small startup and saw what it was like to not have a design system. No design system led to copy pasta code, and days of back-and-forth on simple things like “what hex should i be using for the hover state?”<p>Design systems are tricky to get right. Picking an out-of-the-box solution is easy to begin with, but one day you’ll be cursing yourself due to lack of flexibility (we did!). On the other hand, creating a design system from scratch is super time-consuming even for the best frontend engineers. Mirrorful is our way out of this dilemma.<p>Mirrorful is completely open-source and written in Typescript. We’re starting with basic design elements—commonly called “design tokens” — such as colors, typography, and shadows, but have plans to expand our scope into more complex components.<p>As frontend engineers ourselves, we wanted a tool that lives in code but is visual. It had to be super easy to set up, but also prepare you for scale so you and/or your team don’t end up copy-pasting everywhere. We decided to make it an NPM package (<a href="https://www.npmjs.com/package/mirrorful" rel="nofollow">https://www.npmjs.com/package/mirrorful</a>) that runs a localhost editor and exports out your design tokens into any configuration you want: .js, .ts, .css, .scss, .json. It’s lightweight with no design system lock-in.<p>Our product is completely self-serve: just install our NPM package. If you run Mirrorful locally, a visual dashboard will pop up at localhost:5050 that lets you manage your theme and export various configuration files directly into code.<p>Pricing is similar to other open-source companies—we charge for cloud-hosted features and for premium components.<p>We’ve built open-source/open-core projects before and love interacting with contributors from all over the world. If anyone has any opinions on what we’re building, we’re all ears. Check us out at mirrorful.com and at github.com/Mirrorful/mirrorful and give it a shot!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35358535">https://news.ycombinator.com/item?id=35358535</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## F2-NeRF: Fast Neural Radiance Field Training with Free Camera Trajectories
 - [https://totoro97.github.io/projects/f2-nerf/](https://totoro97.github.io/projects/f2-nerf/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 15:08:03+00:00

<p>Article URL: <a href="https://totoro97.github.io/projects/f2-nerf/">https://totoro97.github.io/projects/f2-nerf/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35358360">https://news.ycombinator.com/item?id=35358360</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Effing-mad, an effect library for Rust
 - [https://github.com/rosefromthedead/effing-mad](https://github.com/rosefromthedead/effing-mad)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 15:06:31+00:00

<p>Article URL: <a href="https://github.com/rosefromthedead/effing-mad">https://github.com/rosefromthedead/effing-mad</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35358336">https://news.ycombinator.com/item?id=35358336</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## $335,000 Pay for ‘AI Whisperer’ Jobs Appears in Red-Hot Market
 - [https://www.bloomberg.com/news/articles/2023-03-29/ai-chatgpt-related-prompt-engineer-jobs-pay-up-to-335-000](https://www.bloomberg.com/news/articles/2023-03-29/ai-chatgpt-related-prompt-engineer-jobs-pay-up-to-335-000)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 14:41:31+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-03-29/ai-chatgpt-related-prompt-engineer-jobs-pay-up-to-335-000">https://www.bloomberg.com/news/articles/2023-03-29/ai-chatgpt-related-prompt-engineer-jobs-pay-up-to-335-000</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35357978">https://news.ycombinator.com/item?id=35357978</a></p>
<p>Points: 35</p>
<p># Comments: 30</p>

## Ask HN: AI-generated spam pull requests?
 - [https://news.ycombinator.com/item?id=35357933](https://news.ycombinator.com/item?id=35357933)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 14:38:18+00:00

<p>Are you seeing pull requests in open source projects that are clearly AI-generated?<p>We recently had someone open a pull request to our open source project and the code and the explanation of the code was clearly AI generated. It was obvious that the code doesn't work and the person had not tested the code. We do not know what the end goal of the person was but we confronted the person and closed the pull requests.<p>Has any other open source projects experienced this? What did you do?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35357933">https://news.ycombinator.com/item?id=35357933</a></p>
<p>Points: 5</p>
<p># Comments: 2</p>

## GitHub Actions Incident 29.3
 - [https://www.githubstatus.com/incidents/z3c6q056q332](https://www.githubstatus.com/incidents/z3c6q056q332)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 14:32:02+00:00

<p>Article URL: <a href="https://www.githubstatus.com/incidents/z3c6q056q332">https://www.githubstatus.com/incidents/z3c6q056q332</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35357851">https://news.ycombinator.com/item?id=35357851</a></p>
<p>Points: 33</p>
<p># Comments: 5</p>

## AlloyDB Omni – run AlloyDB anywhere
 - [https://cloud.google.com/blog/products/databases/run-alloydb-anywhere](https://cloud.google.com/blog/products/databases/run-alloydb-anywhere)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 13:49:16+00:00

<p>Article URL: <a href="https://cloud.google.com/blog/products/databases/run-alloydb-anywhere">https://cloud.google.com/blog/products/databases/run-alloydb-anywhere</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35357252">https://news.ycombinator.com/item?id=35357252</a></p>
<p>Points: 31</p>
<p># Comments: 9</p>

## Marvel's Loki is secretly about org design
 - [https://idealgas.substack.com/p/fixing-the-tva-a-loki-perspective](https://idealgas.substack.com/p/fixing-the-tva-a-loki-perspective)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 13:25:30+00:00

<p>Article URL: <a href="https://idealgas.substack.com/p/fixing-the-tva-a-loki-perspective">https://idealgas.substack.com/p/fixing-the-tva-a-loki-perspective</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35356947">https://news.ycombinator.com/item?id=35356947</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Emergent Mind: AI News, Curated and Explained by AI
 - [https://www.emergentmind.com/](https://www.emergentmind.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 13:24:00+00:00

<p>Article URL: <a href="https://www.emergentmind.com/">https://www.emergentmind.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35356928">https://news.ycombinator.com/item?id=35356928</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## A surprising food may have been a staple of the real Paleo diet: rotten meat
 - [https://www.sciencenews.org/article/meat-rotten-putrid-paleo-diet-fire-neanderthal](https://www.sciencenews.org/article/meat-rotten-putrid-paleo-diet-fire-neanderthal)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 12:30:28+00:00

<p>Article URL: <a href="https://www.sciencenews.org/article/meat-rotten-putrid-paleo-diet-fire-neanderthal">https://www.sciencenews.org/article/meat-rotten-putrid-paleo-diet-fire-neanderthal</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35356256">https://news.ycombinator.com/item?id=35356256</a></p>
<p>Points: 17</p>
<p># Comments: 7</p>

## H26Forge: Exploiting Vulnerabilities in the H.264 Decoders of iOS, Firefox, VLC [pdf]
 - [https://wrv.github.io/h26forge.pdf](https://wrv.github.io/h26forge.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 12:25:45+00:00

<p>Article URL: <a href="https://wrv.github.io/h26forge.pdf">https://wrv.github.io/h26forge.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35356201">https://news.ycombinator.com/item?id=35356201</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Google finds more Android, iOS zero-days used to install spyware
 - [https://www.bleepingcomputer.com/news/security/google-finds-more-android-ios-zero-days-used-to-install-spyware/](https://www.bleepingcomputer.com/news/security/google-finds-more-android-ios-zero-days-used-to-install-spyware/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 12:20:34+00:00

<p>Article URL: <a href="https://www.bleepingcomputer.com/news/security/google-finds-more-android-ios-zero-days-used-to-install-spyware/">https://www.bleepingcomputer.com/news/security/google-finds-more-android-ios-zero-days-used-to-install-spyware/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35356149">https://news.ycombinator.com/item?id=35356149</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Spyware vendors use 0-days and n-days against Android, iOS and Chrome
 - [https://blog.google/threat-analysis-group/spyware-vendors-use-0-days-and-n-days-against-popular-platforms/](https://blog.google/threat-analysis-group/spyware-vendors-use-0-days-and-n-days-against-popular-platforms/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 12:20:34+00:00

<p>Article URL: <a href="https://blog.google/threat-analysis-group/spyware-vendors-use-0-days-and-n-days-against-popular-platforms/">https://blog.google/threat-analysis-group/spyware-vendors-use-0-days-and-n-days-against-popular-platforms/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35356149">https://news.ycombinator.com/item?id=35356149</a></p>
<p>Points: 121</p>
<p># Comments: 37</p>

## Become a 1000x engineer or die tryin
 - [https://kadekillary.work/posts/1000x-eng/](https://kadekillary.work/posts/1000x-eng/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 12:13:52+00:00

<p>Article URL: <a href="https://kadekillary.work/posts/1000x-eng/">https://kadekillary.work/posts/1000x-eng/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35356054">https://news.ycombinator.com/item?id=35356054</a></p>
<p>Points: 78</p>
<p># Comments: 53</p>

## Rice fuels diabetes and climate crises
 - [https://www.economist.com/asia/2023/03/28/there-is-a-global-rice-crisis](https://www.economist.com/asia/2023/03/28/there-is-a-global-rice-crisis)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 11:59:43+00:00

<p>Article URL: <a href="https://www.economist.com/asia/2023/03/28/there-is-a-global-rice-crisis">https://www.economist.com/asia/2023/03/28/there-is-a-global-rice-crisis</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35355880">https://news.ycombinator.com/item?id=35355880</a></p>
<p>Points: 16</p>
<p># Comments: 30</p>

## Italy moves to ban lab-grown meat to protect food heritage
 - [https://www.bbc.co.uk/news/world-europe-65110744](https://www.bbc.co.uk/news/world-europe-65110744)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 11:42:35+00:00

<p>Article URL: <a href="https://www.bbc.co.uk/news/world-europe-65110744">https://www.bbc.co.uk/news/world-europe-65110744</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35355729">https://news.ycombinator.com/item?id=35355729</a></p>
<p>Points: 93</p>
<p># Comments: 103</p>

## The age of average
 - [https://www.alexmurrell.co.uk/articles/the-age-of-average](https://www.alexmurrell.co.uk/articles/the-age-of-average)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 11:39:28+00:00

<p>Article URL: <a href="https://www.alexmurrell.co.uk/articles/the-age-of-average">https://www.alexmurrell.co.uk/articles/the-age-of-average</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35355703">https://news.ycombinator.com/item?id=35355703</a></p>
<p>Points: 40</p>
<p># Comments: 11</p>

## Mamihlapinatapai, Most Succinct Word
 - [https://en.wikipedia.org/wiki/Mamihlapinatapai](https://en.wikipedia.org/wiki/Mamihlapinatapai)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 11:08:45+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Mamihlapinatapai">https://en.wikipedia.org/wiki/Mamihlapinatapai</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35355437">https://news.ycombinator.com/item?id=35355437</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Ubuntu stops shipping Flatpak by default
 - [https://lwn.net/Articles/927262/](https://lwn.net/Articles/927262/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 09:37:38+00:00

<p>Article URL: <a href="https://lwn.net/Articles/927262/">https://lwn.net/Articles/927262/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35354729">https://news.ycombinator.com/item?id=35354729</a></p>
<p>Points: 20</p>
<p># Comments: 12</p>

## Ubuntu stops shipping Flatpak by default
 - [https://lwn.net/SubscriberLink/927262/6adb2350e2b0d2ce/](https://lwn.net/SubscriberLink/927262/6adb2350e2b0d2ce/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 09:37:38+00:00

<p>Article URL: <a href="https://lwn.net/SubscriberLink/927262/6adb2350e2b0d2ce/">https://lwn.net/SubscriberLink/927262/6adb2350e2b0d2ce/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35354729">https://news.ycombinator.com/item?id=35354729</a></p>
<p>Points: 95</p>
<p># Comments: 153</p>

## Ask HN: How many hours do you work on a daily basis?
 - [https://news.ycombinator.com/item?id=35354229](https://news.ycombinator.com/item?id=35354229)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 08:30:27+00:00

<p>Did the layoff wave push you to work more hours than expected? Does AI save you time already?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35354229">https://news.ycombinator.com/item?id=35354229</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## Show HN: Atmos – Everything you need to create color palettes
 - [https://atmos.style](https://atmos.style)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 07:38:43+00:00

<p>Article URL: <a href="https://atmos.style">https://atmos.style</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35353871">https://news.ycombinator.com/item?id=35353871</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Now ChatGPT is being (mis)used to do PeerReview
 - [https://mstdn.science/@ukrio/110100752908161183](https://mstdn.science/@ukrio/110100752908161183)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 07:34:29+00:00

<p>Article URL: <a href="https://mstdn.science/@ukrio/110100752908161183">https://mstdn.science/@ukrio/110100752908161183</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35353843">https://news.ycombinator.com/item?id=35353843</a></p>
<p>Points: 28</p>
<p># Comments: 11</p>

## DARC: Start a company on blockchain, write your own laws
 - [https://github.com/Project-DARC/DARC](https://github.com/Project-DARC/DARC)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 06:57:46+00:00

<p>Article URL: <a href="https://github.com/Project-DARC/DARC">https://github.com/Project-DARC/DARC</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35353606">https://news.ycombinator.com/item?id=35353606</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## WiFi protocol flaw allows attackers to hijack network traffic
 - [https://www.bleepingcomputer.com/news/security/wifi-protocol-flaw-allows-attackers-to-hijack-network-traffic/](https://www.bleepingcomputer.com/news/security/wifi-protocol-flaw-allows-attackers-to-hijack-network-traffic/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 06:08:29+00:00

<p>Article URL: <a href="https://www.bleepingcomputer.com/news/security/wifi-protocol-flaw-allows-attackers-to-hijack-network-traffic/">https://www.bleepingcomputer.com/news/security/wifi-protocol-flaw-allows-attackers-to-hijack-network-traffic/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35353264">https://news.ycombinator.com/item?id=35353264</a></p>
<p>Points: 16</p>
<p># Comments: 3</p>

## Tailwind CSS v3.3
 - [https://tailwindcss.com/blog/tailwindcss-v3-3](https://tailwindcss.com/blog/tailwindcss-v3-3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 05:55:41+00:00

<p>Article URL: <a href="https://tailwindcss.com/blog/tailwindcss-v3-3">https://tailwindcss.com/blog/tailwindcss-v3-3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35353182">https://news.ycombinator.com/item?id=35353182</a></p>
<p>Points: 38</p>
<p># Comments: 28</p>

## Establishing a UART Root Connection to a TP-Link Wireless Router
 - [https://staging.rickconsole.com/posts/hardware-hacking-tp-link/](https://staging.rickconsole.com/posts/hardware-hacking-tp-link/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 05:22:51+00:00

<p>Article URL: <a href="https://staging.rickconsole.com/posts/hardware-hacking-tp-link/">https://staging.rickconsole.com/posts/hardware-hacking-tp-link/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35352989">https://news.ycombinator.com/item?id=35352989</a></p>
<p>Points: 18</p>
<p># Comments: 6</p>

## Brainstorm Questions Not Ideas
 - [https://www.muledesign.com/blog/brainstorm-questions](https://www.muledesign.com/blog/brainstorm-questions)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 04:51:42+00:00

<p>Article URL: <a href="https://www.muledesign.com/blog/brainstorm-questions">https://www.muledesign.com/blog/brainstorm-questions</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35352771">https://news.ycombinator.com/item?id=35352771</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Text2Video-Zero Code and Weights Released by Picsart AI Research (12G VRAM)
 - [https://github.com/Picsart-AI-Research/Text2Video-Zero](https://github.com/Picsart-AI-Research/Text2Video-Zero)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 04:15:08+00:00

<p>Article URL: <a href="https://github.com/Picsart-AI-Research/Text2Video-Zero">https://github.com/Picsart-AI-Research/Text2Video-Zero</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35352452">https://news.ycombinator.com/item?id=35352452</a></p>
<p>Points: 59</p>
<p># Comments: 3</p>

## Show HN: GPT Calculator – Calculate the token count and cost of your GPT Prompt
 - [https://www.gptcalculator.xyz/](https://www.gptcalculator.xyz/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 03:55:42+00:00

<p>Article URL: <a href="https://www.gptcalculator.xyz/">https://www.gptcalculator.xyz/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35352247">https://news.ycombinator.com/item?id=35352247</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Scientists discover why aspirin works so well
 - [https://www.eurekalert.org/news-releases/983050](https://www.eurekalert.org/news-releases/983050)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 03:39:51+00:00

<p>Article URL: <a href="https://www.eurekalert.org/news-releases/983050">https://www.eurekalert.org/news-releases/983050?</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35352094">https://news.ycombinator.com/item?id=35352094</a></p>
<p>Points: 41</p>
<p># Comments: 9</p>

## Generative AI is good at cooperating with people and bad at full automation
 - [https://skybrian.substack.com/p/generative-ai-is-good-at-cooperating](https://skybrian.substack.com/p/generative-ai-is-good-at-cooperating)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 03:23:29+00:00

<p>Article URL: <a href="https://skybrian.substack.com/p/generative-ai-is-good-at-cooperating">https://skybrian.substack.com/p/generative-ai-is-good-at-cooperating</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35351933">https://news.ycombinator.com/item?id=35351933</a></p>
<p>Points: 28</p>
<p># Comments: 5</p>

## Show HN: Customizable, embeddable Chat GPT based on your own documents
 - [https://libraria.dev/](https://libraria.dev/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 01:11:18+00:00

<p>Article URL: <a href="https://libraria.dev/">https://libraria.dev/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35350662">https://news.ycombinator.com/item?id=35350662</a></p>
<p>Points: 104</p>
<p># Comments: 4</p>

## Introduction to Autoencoders
 - [https://www.pinecone.io/learn/autoencoders/](https://www.pinecone.io/learn/autoencoders/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-29 00:42:57+00:00

<p>Article URL: <a href="https://www.pinecone.io/learn/autoencoders/">https://www.pinecone.io/learn/autoencoders/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35350407">https://news.ycombinator.com/item?id=35350407</a></p>
<p>Points: 30</p>
<p># Comments: 0</p>

