# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Netanyahu is backed into a corner. Here's what he may do next
 - [https://www.cnn.com/2023/03/29/middleeast/netanyahu-options-israel-mime-intl/index.html](https://www.cnn.com/2023/03/29/middleeast/netanyahu-options-israel-mime-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-03-29 15:13:55+00:00

When Israeli Prime Minister Benjamin Netanyahu announced his decision to delay a controversial plan to weaken the country's judiciary on Monday, he invoked the biblical story of the Judgement of Solomon, where the king had to rule between two women, both claiming to be the mother of a child. Solomon ordered that the child be cut in two, and the woman who protested the ruling was determined to be the real mother.

## UBS brings back Sergio Ermotti as CEO to oversee Credit Suisse rescue
 - [https://www.cnn.com/2023/03/29/business/ubs-new-ceo-sergio-ermotti-intl-hnk/index.html](https://www.cnn.com/2023/03/29/business/ubs-new-ceo-sergio-ermotti-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-03-29 11:40:22+00:00

UBS is bringing back its former chief executive, Sergio Ermotti, to manage the hugely complex and risky task of completing the bank's emergency takeover of rival Credit Suisse.

## Corporate greed is jacking prices higher. It could push customers over the edge
 - [https://www.cnn.com/2023/03/29/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2023/03/29/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-03-29 10:48:03+00:00

Inflation is ravaging shoppers' wallets and the Federal Reserve has responded by instituting a regimen of painful interest rate hikes that could land the economy in a recession. But corporate profits are surging. US profit margins have reached record levels not seen since the immediate aftermath of World War II.

## 'History in the making': UN poised to take unprecedented vote on the climate crisis
 - [https://www.cnn.com/2023/03/29/world/un-advisory-opinion-vanuatu-climate-change/index.html](https://www.cnn.com/2023/03/29/world/un-advisory-opinion-vanuatu-climate-change/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-03-29 10:06:40+00:00

Pacific Island nation of Vanuatu on Wednesday is poised to win a historic vote at the United Nations that would call on the world's highest court to issue an unprecedented legal opinion on the obligation countries have to address the climate crisis.

## The US case against Binance calls out one of the worst-kept secrets in crypto
 - [https://www.cnn.com/2023/03/27/business/binance-cftc-lawsuit/index.html](https://www.cnn.com/2023/03/27/business/binance-cftc-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-03-29 02:41:21+00:00

If you live in America, you're not allowed to trade crypto derivatives. And if you're a big international platform for trading crypto derivatives, you can't let Americans trade those products if you haven't registered with the boring-sounding but not-to-be-trifled-with federal regulator known as the Commodity Futures Trading Commission, or CFTC.

