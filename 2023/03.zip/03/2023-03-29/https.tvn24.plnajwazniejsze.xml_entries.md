# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Polska drużyna nie dała szans faworytom. Genialny mecz Bednorza
 - [https://eurosport.tvn24.pl/polska-dru-yna-nie-da-a-szans-faworytom--genialny-mecz-bednorza,1141403.html?source=rss](https://eurosport.tvn24.pl/polska-dru-yna-nie-da-a-szans-faworytom--genialny-mecz-bednorza,1141403.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 20:45:00+00:00

<img alt="Polska drużyna nie dała szans faworytom. Genialny mecz Bednorza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-inkh6v-bartosz-bednorz-zagral-bardzo-dobrze-6876520/alternates/LANDSCAPE_1280" />
    To był wspaniały dzień dla polskiej siatkówki. Grupy Azoty i Jastrzębski Węgiel są o krok od finału Ligi Mistrzów.

## Niezapomniane widowisko i decydujące karne
 - [https://eurosport.tvn24.pl/niezapomniane-widowisko-i-decyduj-ce-karne--orlen-wis-a-p-ock-w-grze-o-final-four,1141393.html?source=rss](https://eurosport.tvn24.pl/niezapomniane-widowisko-i-decyduj-ce-karne--orlen-wis-a-p-ock-w-grze-o-final-four,1141393.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 20:39:43+00:00

<img alt="Niezapomniane widowisko i decydujące karne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v4z51r-orlen-wisla-plock-grala-pieknie-z-nantes-6876512/alternates/LANDSCAPE_1280" />
    Orlen Wisła Płock w grze o Final Four.

## Podwójne zabójstwo w Wielkopolsce
 - [https://tvn24.pl/poznan/wielkopolska-powiat-miedzychodzki-podwojne-zabojstwo-policyjna-oblawa-za-podejrzewanym-6876482?source=rss](https://tvn24.pl/poznan/wielkopolska-powiat-miedzychodzki-podwojne-zabojstwo-policyjna-oblawa-za-podejrzewanym-6876482?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 20:27:45+00:00

<img alt="Podwójne zabójstwo w Wielkopolsce " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z0q39u-policja-6876495/alternates/LANDSCAPE_1280" />
    Informacje przekazał rzecznik wielkopolskiej policji.

## Zaskakująca porażka Sabalenki. Rywalka czekała na taki wynik dekadę
 - [https://eurosport.tvn24.pl/zaskakuj-ca-pora-ka-sabalenki--rywalka-czeka-a-na-taki-wynik-dekad-,1141404.html?source=rss](https://eurosport.tvn24.pl/zaskakuj-ca-pora-ka-sabalenki--rywalka-czeka-a-na-taki-wynik-dekad-,1141404.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 19:45:02+00:00

<img alt="Zaskakująca porażka Sabalenki. Rywalka czekała na taki wynik dekadę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yrhbf0-aryna-sabalenka-podczas-miami-open-6876443/alternates/LANDSCAPE_1280" />
    Białorusinka nie zdołała awansować do półfinału w Miami.

## "Teraz zobaczymy, jak to działa". Status Przyłębskiej i wywiad "zwykłego obywatela Kaczyńskiego"
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-o-julii-przylebskiej-i-sporze-w-trybunale-konstytucyjnym-maciej-ferek-i-maria-ejchart-dubois-komentuja-6876338?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-o-julii-przylebskiej-i-sporze-w-trybunale-konstytucyjnym-maciej-ferek-i-maria-ejchart-dubois-komentuja-6876338?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 19:10:17+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8g5jd5-pap_20181110_1xl-6876352/alternates/LANDSCAPE_1280" />
    Krakowski sędzia Maciej Ferek i mecenas Maria Ejchart-Dubois z Inicjatywy "Wolne Sądy" w "Faktach po Faktach".

## Co się szczepi na antypce? Pytanie z "Milionerów" za 125 tysięcy złotych
 - [https://tvn24.pl/toteraz/milionerzy-co-sie-szczepi-na-antypce-odpowiedz-na-pytanie-za-125-tysiecy-zlotych-6875637?source=rss](https://tvn24.pl/toteraz/milionerzy-co-sie-szczepi-na-antypce-odpowiedz-na-pytanie-za-125-tysiecy-zlotych-6875637?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 19:10:00+00:00

<img alt="Co się szczepi na antypce? Pytanie z " src="https://tvn24.pl/toteraz/cdn-zdjecie-2jvbls-co-sie-szczepi-na-antypce-pytanie-z-milionerow-warte-125-tysiecy-zlotych-6875621/alternates/LANDSCAPE_1280" />
    Na antypce zazwyczaj szczepi się: ludzi, zwierzęta, wiśnie łutówki czy śliwki renklody?

## "Prezes zrobił to, z czym miał całe życie walczyć"
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-o-julii-przylebskiej-sporze-w-trybunale-konstytucyjnym-wokol-jej-kadencji-i-o-srodkach-z-kpo-artur-sobon-i-pawel-kowal-komentuja-6876179?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-o-julii-przylebskiej-sporze-w-trybunale-konstytucyjnym-wokol-jej-kadencji-i-o-srodkach-z-kpo-artur-sobon-i-pawel-kowal-komentuja-6876179?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 19:09:48+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1azd9o-kropka-nad-i-6876293/alternates/LANDSCAPE_1280" />
    Dyskusja w "Kropce nad i".

## Mieszkańcy tego 70-tysięcznego miasta żyją nad przepaścią. "Hałas jest taki, że aż okna się trzęsą"
 - [https://tvn24.pl/tvnmeteo/swiat/brazylia-mieszkancy-miasta-buriticupu-zyja-nad-przepascia-halas-jest-taki-ze-az-okna-sie-trzesa-6876167?source=rss](https://tvn24.pl/tvnmeteo/swiat/brazylia-mieszkancy-miasta-buriticupu-zyja-nad-przepascia-halas-jest-taki-ze-az-okna-sie-trzesa-6876167?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 18:20:36+00:00

<img alt="Mieszkańcy tego 70-tysięcznego miasta żyją nad przepaścią. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ko42in-osuwisko-w-brazylii-6876216/alternates/LANDSCAPE_1280" />
    W brazylijskim Buriticupu boją się o własne życie.

## Nowa godzina kwalifikacji w Planicy
 - [https://eurosport.tvn24.pl/nowa-godzina-czwartkowych-kwalifikacji-w-planicy,1141373.html?source=rss](https://eurosport.tvn24.pl/nowa-godzina-czwartkowych-kwalifikacji-w-planicy,1141373.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 18:20:28+00:00

<img alt="Nowa godzina kwalifikacji w Planicy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1lcgbm-skocznia-w-planicy-6876303/alternates/LANDSCAPE_1280" />
    Relacja na żywo w Eurosporcie 1 i Eurosporcie Extra w Playerze.

## Kapitalna gra w Turcji. Jastrzębski Węgiel o krok od finału
 - [https://eurosport.tvn24.pl/kapitalna-gra-w-turcji--jastrz-bski-w-giel-o-krok-od-fina-u,1141354.html?source=rss](https://eurosport.tvn24.pl/kapitalna-gra-w-turcji--jastrz-bski-w-giel-o-krok-od-fina-u,1141354.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 18:04:00+00:00

<img alt="Kapitalna gra w Turcji. Jastrzębski Węgiel o krok od finału" src="https://tvn24.pl/najnowsze/cdn-zdjecie-boje7y-jastrzebski-wegiel-walczy-w-polfinale-ligi-mistrzow-6876276/alternates/LANDSCAPE_1280" />
    Jeden słabszy set nie miał znaczenia.

## Nowe informacje o zdrowiu żony Kubackiego
 - [https://eurosport.tvn24.pl/nowe-informacje-o-zdrowiu--ony-kubackiego,1141369.html?source=rss](https://eurosport.tvn24.pl/nowe-informacje-o-zdrowiu--ony-kubackiego,1141369.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 17:49:57+00:00

<img alt="Nowe informacje o zdrowiu żony Kubackiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-geyx8x-dawid-kubacki-jest-jednym-z-kandydatow-do-medali-w-planicy-6852997/alternates/LANDSCAPE_1280" />
    Rafał Kot, były fizjoterapeuta polskiej kadry skoczków narciarskich, przekazał nowe informacje na temat stanu zdrowia żony Dawida Kubackiego.

## "Wojna dalej trwa, a my zapraszamy agresora z otwartymi ramionami"
 - [https://eurosport.tvn24.pl/-wojna-dalej-trwa--a-my-zapraszamy-agresora-z-otwartymi-ramionami-,1141358.html?source=rss](https://eurosport.tvn24.pl/-wojna-dalej-trwa--a-my-zapraszamy-agresora-z-otwartymi-ramionami-,1141358.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 17:35:13+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9znvul-michal-siess-w-tvn24-bis-6876191/alternates/LANDSCAPE_1280" />
    Powiedział na antenie TVN24 BiS Michał Siess, brązowy medalista mistrzostw Europy we florecie.

## 13-letnia Masza pisze do skazanego na kolonię karną taty
 - [https://tvn24.pl/swiat/rosja-aleksiej-moskalow-ojciec-dziewczynki-ktora-narysowala-antywojenny-obrazek-skazany-13-letnia-masza-napisala-do-niego-list-6875886?source=rss](https://tvn24.pl/swiat/rosja-aleksiej-moskalow-ojciec-dziewczynki-ktora-narysowala-antywojenny-obrazek-skazany-13-letnia-masza-napisala-do-niego-list-6875886?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 17:30:13+00:00

<img alt="13-letnia Masza pisze do skazanego na kolonię karną taty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p7lbrf-aleksiej-moskalow-6875984/alternates/LANDSCAPE_1280" />
    Rosyjski sąd odebrał wcześniej mężczyźnie prawo opieki nad córkę, bo ta narywała antywojenny obrazek.

## Aktorka została matką dzięki surogatce w wieku 68 lat. Ministrowie krytykują, w Hiszpanii poruszenie
 - [https://tvn24.pl/swiat/ana-obregon-zostala-w-usa-matka-dzieki-surogatce-aktorka-krytykowana-w-hiszpanii-6876095?source=rss](https://tvn24.pl/swiat/ana-obregon-zostala-w-usa-matka-dzieki-surogatce-aktorka-krytykowana-w-hiszpanii-6876095?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 17:26:43+00:00

<img alt="Aktorka została matką dzięki surogatce w wieku 68 lat. Ministrowie krytykują, w Hiszpanii poruszenie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1u2jml-ana-obregon-w-madrycie-6876061/alternates/LANDSCAPE_1280" />
    Surogacja w Hiszpanii jest nielegalna.

## "Niekonwencjonalne operacje", lepsi niż armia. Brytyjski raport o rosyjskich szpiegach
 - [https://tvn24.pl/swiat/rosyjscy-szpiedzy-w-ukrainie-raport-brytyjczykow-6875673?source=rss](https://tvn24.pl/swiat/rosyjscy-szpiedzy-w-ukrainie-raport-brytyjczykow-6875673?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 16:49:20+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vnlxcm-rosyjscy-zolnierze-przed-kachowska-elektrownia-wodna-maj-2022-r-6173309/alternates/LANDSCAPE_1280" />
    Byli skuteczniejsi niż wojsko, ale i oni popełnili błędy przed inwazją na Ukrainę.

## Amsterdam apeluje do uciążliwych brytyjskich turystów, by "trzymali się z daleka"
 - [https://tvn24.pl/swiat/amsterdam-kampania-trzymajcie-sie-z-daleka-skierowana-do-mlodych-brytyjczykow-6875903?source=rss](https://tvn24.pl/swiat/amsterdam-kampania-trzymajcie-sie-z-daleka-skierowana-do-mlodych-brytyjczykow-6875903?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 16:19:32+00:00

<img alt="Amsterdam apeluje do uciążliwych brytyjskich turystów, by " src="https://tvn24.pl/najnowsze/cdn-zdjecie-l4thrd-amsterdam-6876047/alternates/LANDSCAPE_1280" />
    "Odwiedzający są mile widziani, ale nie wtedy, gdy zachowują się niewłaściwie i są uciążliwi".

## Kreml "absolutnie wściekły na Chiny"
 - [https://tvn24.pl/swiat/ukraina-dmytro-kuleba-kreml-jest-wsciekly-na-chiny-za-ich-postawe-6875980?source=rss](https://tvn24.pl/swiat/ukraina-dmytro-kuleba-kreml-jest-wsciekly-na-chiny-za-ich-postawe-6875980?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 16:16:29+00:00

<img alt="Kreml " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ii6jjm-mid-epa10535036-6854043/alternates/LANDSCAPE_1280" />
    Szef ukraińskiej dyplomacji udzielił wywiadu dziennikowi "Financial Times".

## Ekstraklasa zaplanowała kolejny sezon
 - [https://eurosport.tvn24.pl/ekstraklasa-zaplanowa-a-kolejny-sezon--zaprezentowano-terminarz,1141333.html?source=rss](https://eurosport.tvn24.pl/ekstraklasa-zaplanowa-a-kolejny-sezon--zaprezentowano-terminarz,1141333.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 16:02:19+00:00

<img alt="Ekstraklasa zaplanowała kolejny sezon" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hv3tob-puchar-za-mistrzostwo-ekstraklasy-6876019/alternates/LANDSCAPE_1280" />
    Zaprezentowano terminarz.

## "Odszedł na oczach kolegów z III C". Ośmiolatek zasłabł w czasie lekcji. Nie żyje
 - [https://tvn24.pl/swiat/wlochy-neapol-8-letni-chlopiec-zaslabl-w-czasie-lekcji-zmarl-6875727?source=rss](https://tvn24.pl/swiat/wlochy-neapol-8-letni-chlopiec-zaslabl-w-czasie-lekcji-zmarl-6875727?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 15:24:20+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wgk5x6-szkola-do-ktorej-chodzil-8-latek-6875714/alternates/LANDSCAPE_1280" />
    O śmierci dziecka piszą włoskie media.

## 13 lat temu utonął jej aparat, teraz znajomi znaleźli w sieci jej prywatne zdjęcia
 - [https://tvn24.pl/ciekawostki/usa-coral-amayi-13-lat-temu-zgubila-aparat-teraz-znajomi-znalezli-w-sieci-jej-prywatne-zdjecia-6875717?source=rss](https://tvn24.pl/ciekawostki/usa-coral-amayi-13-lat-temu-zgubila-aparat-teraz-znajomi-znalezli-w-sieci-jej-prywatne-zdjecia-6875717?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 15:13:58+00:00

<img alt="13 lat temu utonął jej aparat, teraz znajomi znaleźli w sieci jej prywatne zdjęcia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lgb36a-coral-amayi-13-lat-temu-zgubila-aparat-teraz-znajomi-znalezli-w-sieci-jej-prywatne-zdjecia-6875277/alternates/LANDSCAPE_1280" />
    Pochodziły z karty pamięci.

## Zwolnienia w znanej firmie technologicznej. "Trudna decyzja o reorganizacji"
 - [https://tvn24.pl/biznes/tech/zwolnienia-w-netguru-trudna-decyzja-o-reorganizacji-6875786?source=rss](https://tvn24.pl/biznes/tech/zwolnienia-w-netguru-trudna-decyzja-o-reorganizacji-6875786?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 14:59:59+00:00

<img alt="Zwolnienia w znanej firmie technologicznej. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjeciea2be9203330c44206e89d8bb4c36835a-zarobki-programistow-roznia-sie-w-zaleznosci-od-umiejetnosci-doswiadczenia-i-pochodzenia-kapitalu-firm-w-ktorych-pracuja-4649093/alternates/LANDSCAPE_1280" />
    Informacje potwierdził Kuba Filipowski, współzałożyciel przedsiębiorstwa.

## Bosak o wyjściu Polski z UE: "Nigdy takiego celu nie postawiliśmy". A co mówili?
 - [https://konkret24.tvn24.pl/polityka/konfederacja-bosak-o-wyjsciu-polski-z-ue-nigdy-takiego-celu-nie-postawilismy-a-co-mowili-6871491?source=rss](https://konkret24.tvn24.pl/polityka/konfederacja-bosak-o-wyjsciu-polski-z-ue-nigdy-takiego-celu-nie-postawilismy-a-co-mowili-6871491?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 14:58:19+00:00

<img alt="Bosak o wyjściu Polski z UE: " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4vt7k8-krzysztof-bosak-o-wyjsciu-polski-z-ue-nigdy-takiego-celu-nie-postawilismy-6871130/alternates/LANDSCAPE_1280" />
    Jak politycy Konfederacji mówili o obecności Polski w UE i skąd się wziął hasztag #PolExit.

## Tylko jeden skok w historii był dłuższy. "Lądował z wysokości pierwszego piętra"
 - [https://eurosport.tvn24.pl/tylko-jeden-skok-w-historii-by--d-u-szy---l-dowa--z-wysoko-ci-pierwszego-pi-tra-,1141311.html?source=rss](https://eurosport.tvn24.pl/tylko-jeden-skok-w-historii-by--d-u-szy---l-dowa--z-wysoko-ci-pierwszego-pi-tra-,1141311.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 14:57:36+00:00

<img alt="Tylko jeden skok w historii był dłuższy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-si8fyo-ryoyu-kobayashi-to-aktualny-rekordzista-letalnicy-6875880/alternates/LANDSCAPE_1280" />
    Ten skok Ryoyu Kobayashiego można oglądać w nieskończoność.

## Papież Franciszek w szpitalu
 - [https://tvn24.pl/swiat/papiez-franciszek-w-szpitalu-na-badaniach-6875796?source=rss](https://tvn24.pl/swiat/papiez-franciszek-w-szpitalu-na-badaniach-6875796?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 14:24:15+00:00

<img alt="Papież Franciszek w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9dymki-franciszek-na-placu-swietego-piotra-6875814/alternates/LANDSCAPE_1280" />
    Informuje Reuters, powołując się na papieskiego rzecznika Matteo Bruniego.

## Papież Franciszek w szpitalu
 - [https://tvn24.pl/swiat/franciszek-w-szpitalu-na-badaniach-informacje-o-stanie-zdrowia-papieza-6875796?source=rss](https://tvn24.pl/swiat/franciszek-w-szpitalu-na-badaniach-informacje-o-stanie-zdrowia-papieza-6875796?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 14:24:15+00:00

<img alt="Papież Franciszek w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9dymki-franciszek-na-placu-swietego-piotra-6875814/alternates/LANDSCAPE_1280" />
    Informuje Reuters, powołując się na papieskiego rzecznika Matteo Bruniego.

## Obowiązkowa apteczka w aucie. Jest propozycja zmiany przepisów
 - [https://tvn24.pl/biznes/moto/obowiazkowa-apteczka-w-aucie-jest-propozycja-zmiany-przepisow-6875654?source=rss](https://tvn24.pl/biznes/moto/obowiazkowa-apteczka-w-aucie-jest-propozycja-zmiany-przepisow-6875654?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 14:17:43+00:00

<img alt="Obowiązkowa apteczka w aucie. Jest propozycja zmiany przepisów" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-qreavo-spadek-rejestracji-nowych-samochodow-wyhamowuje-4557688/alternates/LANDSCAPE_1280" />
    Nowelizacją zajmuje się obecnie Senat.

## Tajemniczy obiekt przy Nord Stream 2 zidentyfikowany
 - [https://tvn24.pl/swiat/dania-nord-stream-2-tajemniczy-obiekt-w-wodach-morza-baltyckiego-zidentyfikowany-6875776?source=rss](https://tvn24.pl/swiat/dania-nord-stream-2-tajemniczy-obiekt-w-wodach-morza-baltyckiego-zidentyfikowany-6875776?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 14:17:18+00:00

<img alt="Tajemniczy obiekt przy Nord Stream 2 zidentyfikowany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7oqu6f-morska-boja-dymna-przed-i-po-wydobyciu-z-morza-baltyckiego-6875765/alternates/LANDSCAPE_1280" />
    Duńska Agencja Energii opublikowała zdjęcia.

## Koniec z efektem jo-jo? Naukowcy odkryli, jak powstrzymać zwiększony głód po zakończeniu diety
 - [https://tvn24.pl/ciekawostki/diety-koniec-efektu-jo-jo-naukowcy-odkryli-jak-powstrzymac-zwiekszony-glod-po-zakonczeniu-diety-6875131?source=rss](https://tvn24.pl/ciekawostki/diety-koniec-efektu-jo-jo-naukowcy-odkryli-jak-powstrzymac-zwiekszony-glod-po-zakonczeniu-diety-6875131?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 14:16:38+00:00

<img alt="Koniec z efektem jo-jo? Naukowcy odkryli, jak powstrzymać zwiększony głód po zakończeniu diety" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4kuqw9-kontrola-wagi-otylosc-dieta-6218244/alternates/LANDSCAPE_1280" />
    Na razie u myszy.

## Igrzyska Europejskie bez sportowców z Rosji i Białorusi
 - [https://eurosport.tvn24.pl/igrzyska-europejskie-bez-sportowc-w-z-rosji-i-bia-orusi,1141324.html?source=rss](https://eurosport.tvn24.pl/igrzyska-europejskie-bez-sportowc-w-z-rosji-i-bia-orusi,1141324.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 13:59:16+00:00

<img alt="Igrzyska Europejskie bez sportowców z Rosji i Białorusi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o3gh1s-czas-ucieka-a-wykonawcy-znicza-na-igrzyska-europejskie-wciaz-nie-ma-6875774/alternates/LANDSCAPE_1280" />
    - Nie dopuścimy do tego bez względu na zabiegi dyplomatyczne, które obecnie się pojawiają - oświadczył prezes komitetu organizacyjnego Marcin Nowak.

## Termin minął. Mnisi patriarchatu podległego Moskwie nie chcą opuścić Ławry Peczerskiej
 - [https://tvn24.pl/swiat/ukraina-lawra-peczerska-mnisi-patriarchatu-podleglego-moskwie-nie-chca-jej-opuscic-6875483?source=rss](https://tvn24.pl/swiat/ukraina-lawra-peczerska-mnisi-patriarchatu-podleglego-moskwie-nie-chca-jej-opuscic-6875483?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 13:20:22+00:00

<img alt="Termin minął. Mnisi patriarchatu podległego Moskwie nie chcą opuścić Ławry Peczerskiej " src="https://tvn24.pl/najnowsze/cdn-zdjecie-b1egsk-cerkiew-kijow-6875591/alternates/LANDSCAPE_1280" />
    Miejsce to jest najważniejszym ośrodkiem prawosławia na ziemiach ukraińskich.

## Zapadł drugi wyrok w sprawie znanego aktora
 - [https://tvn24.pl/krakow/krakow-aktor-jerzy-s-winny-spowodowania-zagrozenia-na-drodze-6875553?source=rss](https://tvn24.pl/krakow/krakow-aktor-jerzy-s-winny-spowodowania-zagrozenia-na-drodze-6875553?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 13:17:04+00:00

<img alt="Zapadł drugi wyrok w sprawie znanego aktora" src="https://tvn24.pl/najnowsze/cdn-zdjecie-exb9bq-jerzy-s-winny-spowodowania-zagrozenia-na-drodze-zapadl-drugi-wyrok-w-sprawie-znanego-aktora-6875648/alternates/LANDSCAPE_1280" />
    Nie było go na sali rozpraw.

## Premier skrytykował decyzję MKOl. Odpowiedział, czy polscy sportowcy wezmą udział w igrzyskach
 - [https://eurosport.tvn24.pl/premier-skrytykowa--decyzj--mkol--odpowiedzia---czy-polscy-sportowcy-wezm--udzia--w-igrzyskach,1141321.html?source=rss](https://eurosport.tvn24.pl/premier-skrytykowa--decyzj--mkol--odpowiedzia---czy-polscy-sportowcy-wezm--udzia--w-igrzyskach,1141321.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 13:10:00+00:00

<img alt="Premier skrytykował decyzję MKOl. Odpowiedział, czy polscy sportowcy wezmą udział w igrzyskach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hc1xyu-polska-reprezentacja-podczas-otwarcia-igrzysk-w-tokio-6875686/alternates/LANDSCAPE_1280" />
    Międzynarodowy Komitet Olimpijski przywrócił możliwość startów Rosjan i Białorusinów w sportach indywidualnych.

## Poluzował śruby w rowerze 19-latka. Chłopak przewrócił się i połamał zęby
 - [https://tvn24.pl/poznan/gubin-poluzowal-sruby-w-rowerze-19-latka-chlopak-przewrocil-sie-i-polamal-zeby-6875394?source=rss](https://tvn24.pl/poznan/gubin-poluzowal-sruby-w-rowerze-19-latka-chlopak-przewrocil-sie-i-polamal-zeby-6875394?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 12:56:33+00:00

<img alt="Poluzował śruby w rowerze 19-latka. Chłopak przewrócił się i połamał zęby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-46i1ur-ukradl-rower-i-przewrocil-sie-na-nim-lamiac-noge-5519137/alternates/LANDSCAPE_1280" />
    16-latek odpowie za niebezpieczeństwo utraty życia lub spowodowania ciężkiego uszczerbku na zdrowiu.

## Pierwsza wizyta państwowa Karola III. "Ważny europejski gest"
 - [https://tvn24.pl/swiat/niemcy-krol-karol-iii-z-pierwsza-wizyta-panstwowa-od-objecia-tronu-wielkiej-brytanii-6875606?source=rss](https://tvn24.pl/swiat/niemcy-krol-karol-iii-z-pierwsza-wizyta-panstwowa-od-objecia-tronu-wielkiej-brytanii-6875606?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 12:53:36+00:00

<img alt="Pierwsza wizyta państwowa Karola III. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-98pypy-karol-iii-w-berlinie-6875612/alternates/LANDSCAPE_1280" />
    To część wysiłków na rzecz poprawy stosunków z Unią Europejską - komentuje agencja Reutera.

## PKW chce lokali wyborczych w kościołach i księdza w komisji? Wyjaśniamy
 - [https://konkret24.tvn24.pl/polska/pkw-chce-lokali-wyborczych-w-kosciolach-i-ksiedza-w-komisji-wyjasniamy-6874818?source=rss](https://konkret24.tvn24.pl/polska/pkw-chce-lokali-wyborczych-w-kosciolach-i-ksiedza-w-komisji-wyjasniamy-6874818?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 12:32:00+00:00

<img alt="PKW chce lokali wyborczych w kościołach i księdza w komisji? Wyjaśniamy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f42faa-konkret-wybory-bezfalsz-6874823/alternates/LANDSCAPE_1280" />
    Zalecenie o tworzeniu lokali wyborczych w kościołach rzekomo miał wydać przewodniczący PKW. Krążące w sieci pismo jest nieprawdziwe.

## Dwulatka poparzona wrzątkiem na chrzcinach
 - [https://tvn24.pl/poznan/wielkopolska-dwulatka-poparzona-wrzatkiem-na-chrzcinach-6875481?source=rss](https://tvn24.pl/poznan/wielkopolska-dwulatka-poparzona-wrzatkiem-na-chrzcinach-6875481?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 12:28:11+00:00

<img alt="Dwulatka poparzona wrzątkiem na chrzcinach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j3h1mr-szpital-w-ostrowie-wielkopolskim-6875533/alternates/LANDSCAPE_1280" />
    Policja podkreśla, że doszło do nieszczęśliwego wypadku.

## Szokujące rekolekcje w kościele. Rzecznik Praw Dziecka: Przemoc jest zawsze zła. Nie można jej promować
 - [https://tvn24.pl/pomorze/torun-kontrowersyjne-nagrania-z-rekolekcji-wyciekly-do-sieci-przedstawienie-wywolalo-burze-6875070?source=rss](https://tvn24.pl/pomorze/torun-kontrowersyjne-nagrania-z-rekolekcji-wyciekly-do-sieci-przedstawienie-wywolalo-burze-6875070?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 12:19:23+00:00

<img alt="Szokujące rekolekcje w kościele. Rzecznik Praw Dziecka: Przemoc jest zawsze zła. Nie można jej promować" src="https://tvn24.pl/najnowsze/cdn-zdjecie-92i02r-organizator-rekolekcji-przeprasza-kuria-informuje-o-odsunieciu-grupy-ewangelizacyjnej-od-prowadzenia-zajec-6869822/alternates/LANDSCAPE_1280" />
    Burza po kontrowersyjnym przedstawieniu.

## Szokujące rekolekcje w kościele. Rzecznik Praw Dziecka: Przemoc jest zawsze zła. Nie można jej promować
 - [https://tvn24.pl/pomorze/torun-rekolekcje-z-przeklenstwami-i-przemoca-wideo-i-komentarze-6875070?source=rss](https://tvn24.pl/pomorze/torun-rekolekcje-z-przeklenstwami-i-przemoca-wideo-i-komentarze-6875070?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 12:19:23+00:00

<img alt="Szokujące rekolekcje w kościele. Rzecznik Praw Dziecka: Przemoc jest zawsze zła. Nie można jej promować" src="https://tvn24.pl/najnowsze/cdn-zdjecie-92i02r-organizator-rekolekcji-przeprasza-kuria-informuje-o-odsunieciu-grupy-ewangelizacyjnej-od-prowadzenia-zajec-6869822/alternates/LANDSCAPE_1280" />
    Burza po kontrowersyjnym przedstawieniu.

## Rząd chce zlikwidować użytkowanie wieczyste. Nowy model odpłatności za grunt
 - [https://tvn24.pl/biznes/z-kraju/uzytkowanie-wieczyste-rzad-chce-zlikwidowac-uzytkowanie-wieczyste-minister-rozwoju-waldemar-buda-o-szczegolach-6875496?source=rss](https://tvn24.pl/biznes/z-kraju/uzytkowanie-wieczyste-rzad-chce-zlikwidowac-uzytkowanie-wieczyste-minister-rozwoju-waldemar-buda-o-szczegolach-6875496?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 12:17:47+00:00

<img alt="Rząd chce zlikwidować użytkowanie wieczyste. Nowy model odpłatności za grunt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pprn52-blok-mieszkania-osiedle-6797633/alternates/LANDSCAPE_1280" />
    Projekt ustawy przyjęty przez Radę Ministrów.

## Premier: nie zgadzamy się na to, by ukraińskie zboże trafiało do Polski, destabilizowało rynki lokalne
 - [https://tvn24.pl/polska/ukraina-zboze-premier-mateusz-morawiecki-nie-zgadzamy-sie-by-trafialo-do-polski-i-destabilizowalo-rynki-lokalne-6875508?source=rss](https://tvn24.pl/polska/ukraina-zboze-premier-mateusz-morawiecki-nie-zgadzamy-sie-by-trafialo-do-polski-i-destabilizowalo-rynki-lokalne-6875508?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 11:56:46+00:00

<img alt="Premier: nie zgadzamy się na to, by ukraińskie zboże trafiało do Polski, destabilizowało rynki lokalne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cuf99u-mateusz-morawiecki-6875518/alternates/LANDSCAPE_1280" />
    Oświadczenie w KPRM.

## Ukraińcy zestrzelili pod Bachmutem rosyjski bombowiec
 - [https://tvn24.pl/swiat/ukraina-baachmut-rosyjski-bombowiec-su-24m-zestrzelony-sily-powietrzne-ukrainy-6874976?source=rss](https://tvn24.pl/swiat/ukraina-baachmut-rosyjski-bombowiec-su-24m-zestrzelony-sily-powietrzne-ukrainy-6874976?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 11:50:20+00:00

<img alt="Ukraińcy zestrzelili pod Bachmutem rosyjski bombowiec " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kjdm3a-bombowiec-su-24m-6874830/alternates/LANDSCAPE_1280" />
    Według byłego ministra obrony Rosja panikuje z powodu niepowodzeń w okręgu bachmuckim.

## Lex pilot. Jest decyzja sejmowej komisji
 - [https://tvn24.pl/biznes/z-kraju/lex-pilot-sejm-komisja-cyfryzacji-przyjela-wnioski-o-odrzucenie-rzadowych-projektow-6875312?source=rss](https://tvn24.pl/biznes/z-kraju/lex-pilot-sejm-komisja-cyfryzacji-przyjela-wnioski-o-odrzucenie-rzadowych-projektow-6875312?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 11:32:19+00:00

<img alt="Lex pilot. Jest decyzja sejmowej komisji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6owc1m-telewizor-telewizja-media-5720676/alternates/LANDSCAPE_1280" />
    "Opozycja wygrywa głosowanie".

## Minister twierdzi, że "w zasadzie wszystko wyjaśnione". Kołodziejczak: rozpoczynamy strajk okupacyjny
 - [https://tvn24.pl/polska/rolnicy-w-ministerstwie-rozmowy-z-henrykiem-kowalczykiem-michal-kolodziejczak-zapowiada-strajk-okupacyjny-6875068?source=rss](https://tvn24.pl/polska/rolnicy-w-ministerstwie-rozmowy-z-henrykiem-kowalczykiem-michal-kolodziejczak-zapowiada-strajk-okupacyjny-6875068?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 11:23:56+00:00

<img alt="Minister twierdzi, że " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mwp74f-lider-agrounii-michal-kolodziejczak-w-siedzibie-ministerstwa-rolnictwa-i-rozwoju-wsi-po-spotkaniu-okraglego-stolu-6876294/alternates/LANDSCAPE_1280" />
    Rolnicy żądają działań Henryka Kowalczyka w związku z decyzję KE o zniesieniu ceł na produkty rolne sprowadzane z Ukrainy na kolejny rok.

## Rolnicy w ministerstwie. Kołodziejczak: nie zamierzam wychodzić ze spotkania bez dobrych rozwiązań
 - [https://tvn24.pl/polska/rolnicy-w-ministerstwie-rozmowy-z-henrykiem-kowalczykiem-6875068?source=rss](https://tvn24.pl/polska/rolnicy-w-ministerstwie-rozmowy-z-henrykiem-kowalczykiem-6875068?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 11:23:56+00:00

<img alt="Rolnicy w ministerstwie. Kołodziejczak: nie zamierzam wychodzić ze spotkania bez dobrych rozwiązań" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w43i6j-29-1205-agrounia-0003-6875216/alternates/LANDSCAPE_1280" />
    Rolnicy żądają działań Henryka Kowalczyka w związku z decyzję KE o zniesieniu ceł na produkty rolne sprowadzane z Ukrainy na kolejny rok.

## "Maleńkie, ale niezwykle miłe" spotkanie z noblistką w pociągu
 - [https://tvn24.pl/kultura-i-styl/olga-tokarczuk-zrobila-furore-zdjeciem-z-pociagu-malenkie-ale-niezwykle-mile-spotkanie-autorskie-z-czytelnikami-z-izraela-6875135?source=rss](https://tvn24.pl/kultura-i-styl/olga-tokarczuk-zrobila-furore-zdjeciem-z-pociagu-malenkie-ale-niezwykle-mile-spotkanie-autorskie-z-czytelnikami-z-izraela-6875135?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 11:07:04+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mzlhfd-fb-6875321/alternates/LANDSCAPE_1280" />
    Olga Tokarczuk w dalekiej podróży.

## "Maleńkie, ale niezwykle miłe" spotkanie z noblistką w pociągu
 - [https://tvn24.pl/kultura-i-styl/olga-tokarczuk-zdjeciem-z-pociagu-malenkie-ale-niezwykle-mile-spotkanie-autorskie-z-czytelnikami-z-izraela-6875135?source=rss](https://tvn24.pl/kultura-i-styl/olga-tokarczuk-zdjeciem-z-pociagu-malenkie-ale-niezwykle-mile-spotkanie-autorskie-z-czytelnikami-z-izraela-6875135?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 11:07:04+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mzlhfd-fb-6875321/alternates/LANDSCAPE_1280" />
    Olga Tokarczuk w dalekiej podróży.

## On wstał, koledze pocisk rozerwał pachwinę. Białoruski wioślarz walczy za Ukrainę
 - [https://tvn24.pl/premium/bialorusin-pawel-szurmiej-byl-wioslarzem-zostal-zolnierzem-walczy-za-ukraine-ojczyzne-swojej-zony-oleny-buriak-6834156?source=rss](https://tvn24.pl/premium/bialorusin-pawel-szurmiej-byl-wioslarzem-zostal-zolnierzem-walczy-za-ukraine-ojczyzne-swojej-zony-oleny-buriak-6834156?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 11:03:58+00:00

<img alt="On wstał, koledze pocisk rozerwał pachwinę. Białoruski wioślarz walczy za Ukrainę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5n0waw-do-wojska-pawel-zglosil-sie-na-ochotnika-6842553/alternates/LANDSCAPE_1280" />
    Był sportowcem, jest żołnierzem. Do obrony Ukrainy, ojczyzny swojej żony, ruszył jako ochotnik - on, Białorusin. Śmierć przemknęła tuż obok niego w Bachmucie, w tym piekle na ziemi, gdzie został ranny, kiedy do ludzi raz za razem strzelał rosyjski czołg. - To, co tam się dzieje, można porównać do okropieństw II wojny światowej. Do Stalingradu - opowiada Paweł Szurmiej, wioślarz, dwukrotny olimpijczyk.

## Obietnice minus. Jak PiS zapowiadał słuchanie obywateli, ale tego nie wprowadził
 - [https://konkret24.tvn24.pl/obietnice-minus/obietnice-minus-jak-pis-zapowiadal-sluchanie-obywateli-ale-tego-nie-wprowadzil-6875076?source=rss](https://konkret24.tvn24.pl/obietnice-minus/obietnice-minus-jak-pis-zapowiadal-sluchanie-obywateli-ale-tego-nie-wprowadzil-6875076?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 10:57:13+00:00

<img alt="Obietnice minus. Jak PiS zapowiadał słuchanie obywateli, ale tego nie wprowadził " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tpjzax-obietnice-minus-jak-pis-zapowiadal-sluchac-obywateli-ale-tego-nie-wprowadzil-6875155/alternates/LANDSCAPE_1280" />
    Idąc do władzy, PiS obiecało takie zmiany w Regulaminie Sejmu, które dadzą większą szansę obywatelskim projektom ustaw.

## Rodzina dwulatki zastrzelonej przez policyjnego snajpera składa pozew przeciwko władzom
 - [https://tvn24.pl/swiat/usa-rodzina-2-latki-zastrzelonej-przez-policyjnego-snajpera-sklada-pozew-przeciwko-wladzom-6875217?source=rss](https://tvn24.pl/swiat/usa-rodzina-2-latki-zastrzelonej-przez-policyjnego-snajpera-sklada-pozew-przeciwko-wladzom-6875217?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 10:48:10+00:00

<img alt="Rodzina dwulatki zastrzelonej przez policyjnego snajpera składa pozew przeciwko władzom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tqjmp5-usa-zatrzymana-20-latka-siedziala-w-radiowozie-uderzyl-w-niego-jadacy-pociag-6122194/alternates/LANDSCAPE_1280" />
    "Nie zrobiła nic złego, nie naruszyła żadnego prawa".

## Dentysta skazany za zgwałcenie pacjentki
 - [https://tvn24.pl/bialystok/lublin-dentysta-prawomocnie-skazany-za-zgwalcenie-pacjentki-6874954?source=rss](https://tvn24.pl/bialystok/lublin-dentysta-prawomocnie-skazany-za-zgwalcenie-pacjentki-6874954?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 10:37:49+00:00

<img alt="Dentysta skazany za zgwałcenie pacjentki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yo2nou-grzegorz-t-przyjmowal-w-jednym-z-gabinetow-stomatologicznych-w-lublinie-zdjecie-ilustracyjne-6875011/alternates/LANDSCAPE_1280" />
    Jego ofiarami miały paść też dwie inne kobiety.

## Uciekał przed policją, cudem ominął radiowóz. Pościg zakończył się kolizją
 - [https://tvn24.pl/poznan/ilowa-policyjny-poscig-za-motocyklista-dostal-6-tysiecy-zlotych-mandatow-i-56-punktow-karnych-6875126?source=rss](https://tvn24.pl/poznan/ilowa-policyjny-poscig-za-motocyklista-dostal-6-tysiecy-zlotych-mandatow-i-56-punktow-karnych-6875126?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 10:33:57+00:00

<img alt="Uciekał przed policją, cudem ominął radiowóz. Pościg zakończył się kolizją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bcglu2-uciekajacy-motocyklista-6874815/alternates/LANDSCAPE_1280" />
    Ucieczka - za którą dostał wysokie mandaty i 56 punktów karnych - w oku policyjnej kamery.

## Tyle faktycznie płacono za mieszkania. Nowy lider
 - [https://tvn24.pl/biznes/nieruchomosci/mieszkania-na-sprzedaz-gdynia-wyprzedzila-warszawe-raport-nbp-za-czwarty-kwartal-2022-6875013?source=rss](https://tvn24.pl/biznes/nieruchomosci/mieszkania-na-sprzedaz-gdynia-wyprzedzila-warszawe-raport-nbp-za-czwarty-kwartal-2022-6875013?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 10:26:52+00:00

<img alt="Tyle faktycznie płacono za mieszkania. Nowy lider" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pmx788-gdynia-6875174/alternates/LANDSCAPE_1280" />
    Raport Narodowego Banku Polskiego.

## Ogłoszono nazwisko nowego selekcjonera polskich piłkarzy ręcznych
 - [https://eurosport.tvn24.pl/og-oszono-nazwisko-nowego-selekcjonera-polskich-pi-karzy-r-cznych,1141280.html?source=rss](https://eurosport.tvn24.pl/og-oszono-nazwisko-nowego-selekcjonera-polskich-pi-karzy-r-cznych,1141280.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 10:04:00+00:00

<img alt="Ogłoszono nazwisko nowego selekcjonera polskich piłkarzy ręcznych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ceo6y8-marcin-lijewski-to-nowy-selekcjoner-polskich-pilkarzy-recznych-6875171/alternates/LANDSCAPE_1280" />
    Były kapitan kadry zastąpił na tym stanowisku Patryka Rombla.

## Jelenie przebiegły przez drogę, jeden zszokował leśników. "Po raz pierwszy widzę, żeby w Polsce był taki osobnik"
 - [https://tvn24.pl/tvnmeteo/polska/podkarpacie-lezajsk-bialy-jelen-przebiegl-przez-droge-po-raz-pierwszy-widze-zeby-w-polsce-byl-bialy-osobnik-6874602?source=rss](https://tvn24.pl/tvnmeteo/polska/podkarpacie-lezajsk-bialy-jelen-przebiegl-przez-droge-po-raz-pierwszy-widze-zeby-w-polsce-byl-bialy-osobnik-6874602?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 09:46:18+00:00

<img alt="Jelenie przebiegły przez drogę, jeden zszokował leśników. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-flkry6-bialy-jelen-z-nadlesnictwa-lezajsk-6875060/alternates/LANDSCAPE_1280" />
    Został zaobserwowany w Nadleśnictwie Leżajsk.

## Kupiła siedem sztuk broni, prawdopodobnie przeszła szkolenie, przed atakiem rozesłała SMS-y
 - [https://tvn24.pl/swiat/nashville-usa-atak-na-szkole-napastniczka-leczyla-sie-z-powodu-zaburzen-emocjonalnych-mimo-to-kupila-siedem-sztuk-broni-6874786?source=rss](https://tvn24.pl/swiat/nashville-usa-atak-na-szkole-napastniczka-leczyla-sie-z-powodu-zaburzen-emocjonalnych-mimo-to-kupila-siedem-sztuk-broni-6874786?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 09:36:25+00:00

<img alt="Kupiła siedem sztuk broni, prawdopodobnie przeszła szkolenie, przed atakiem rozesłała SMS-y" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a39rr0-atak-w-szkole-w-nashville-napastniczka-na-nagraniu-z-monitoringu-6869526/alternates/LANDSCAPE_1280" />
    Nowe informacje o napastniczce z Nashville.

## 300 milionów miejsc pracy pod znakiem zapytania
 - [https://tvn24.pl/biznes/ze-swiata/sztuczna-inteligencja-a-rynek-pracy-raport-goldman-sachs-300-milionow-miejsc-pracy-pod-znakiem-zapytania-6874681?source=rss](https://tvn24.pl/biznes/ze-swiata/sztuczna-inteligencja-a-rynek-pracy-raport-goldman-sachs-300-milionow-miejsc-pracy-pod-znakiem-zapytania-6874681?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 09:35:52+00:00

<img alt="300 milionów miejsc pracy pod znakiem zapytania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-et0fxg-shutterstock_160438778-6875033/alternates/LANDSCAPE_1280" />
    Analiza Goldman Sachs.

## "Jedyny sposób na pokój". Eksperci analizują, jak długo potrwa wojna
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-jak-dlugo-potrwa-czy-ukraina-odbije-krym-eksperci-odpowiadaja-6874906?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-jak-dlugo-potrwa-czy-ukraina-odbije-krym-eksperci-odpowiadaja-6874906?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 08:56:21+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tg2b7b-oficer-ukrainskiej-policji-po-atakach-rakietowych-rosjan-w-awdijiwce-w-donbasie-zdjecie-z-17-marca-6849022/alternates/LANDSCAPE_1280" />
    W Londynie odbyła się konferencja "Rosyjska inwazja na Ukrainę: dziennikarze, wojna, uchodźcy".

## Odkryto "tajny składnik" dzieł Leonarda da Vinci, Botticellego i Rembrandta
 - [https://tvn24.pl/ciekawostki/nauka-odkryto-tajny-skladnik-dziel-leonarda-da-vinci-i-botticellego-zoltko-jajka-6874707?source=rss](https://tvn24.pl/ciekawostki/nauka-odkryto-tajny-skladnik-dziel-leonarda-da-vinci-i-botticellego-zoltko-jajka-6874707?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 08:52:58+00:00

<img alt="Odkryto " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ycseae-ostatnia-wieczerza-leonardo-da-vinci-4784389/alternates/LANDSCAPE_1280" />
    To dzięki niemu ich dzieła przetrwały setki lat.

## Uderzył w bariery, "przeleciał przez torowisko" i dachował. Był pijany, jest nagranie
 - [https://tvn24.pl/bialystok/puchaczow-uderzyl-w-bariery-przelecial-przez-torowisko-i-dachowal-byl-pijany-jest-nagranie-6874675?source=rss](https://tvn24.pl/bialystok/puchaczow-uderzyl-w-bariery-przelecial-przez-torowisko-i-dachowal-byl-pijany-jest-nagranie-6874675?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 08:48:22+00:00

<img alt="Uderzył w bariery, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mx2ug3-uderzyl-w-barierki-przejechal-przez-tory-a-na-koniec-jeszcze-dachowal-byl-pijany-6874805/alternates/LANDSCAPE_1280" />
    Miał dużo szczęścia - podkreślają policjanci.

## Matka trzylatka i jej partner podejrzani o usiłowanie zabójstwa i gwałt. Trafią na obserwację psychiatryczną
 - [https://tvn24.pl/krakow/stalowa-wola-para-ktora-miala-znecac-sie-nad-dzieckiem-trafi-na-zamknieta-obserwacje-psychiatryczna-6874753?source=rss](https://tvn24.pl/krakow/stalowa-wola-para-ktora-miala-znecac-sie-nad-dzieckiem-trafi-na-zamknieta-obserwacje-psychiatryczna-6874753?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 08:42:31+00:00

<img alt="Matka trzylatka i jej partner podejrzani o usiłowanie zabójstwa i gwałt. Trafią na obserwację psychiatryczną   " src="https://tvn24.pl/najnowsze/cdn-zdjecie-erhixn-zaklad-karny-4689671/alternates/LANDSCAPE_1280" />
    Matce chłopca i jej partnerowi grozi dożywocie.

## Przejażdżka hulajnogami kosztowała ich 11 tysięcy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wyszkow-pijani-jezdzili-hulajnogami-jeden-mial-spowodowac-kolizje-dostali-wysoki-mandat-6874793?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wyszkow-pijani-jezdzili-hulajnogami-jeden-mial-spowodowac-kolizje-dostali-wysoki-mandat-6874793?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 08:37:59+00:00

<img alt="Przejażdżka hulajnogami kosztowała ich 11 tysięcy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4051ak-policja-interweniowala-wobec-mezczyzn-jezdzacych-na-hulajnogach-zdjecie-ilustracyjne-6874817/alternates/LANDSCAPE_1280" />
    Dostali mandaty i musieli pokryć straty.

## Świetna gra, wielkie zarobki. Policzono Świątek nagrody
 - [https://eurosport.tvn24.pl/-wietna-gra--wielkie-zarobki--policzno--wi-tek-nagrody,1141310.html?source=rss](https://eurosport.tvn24.pl/-wietna-gra--wielkie-zarobki--policzno--wi-tek-nagrody,1141310.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 08:33:00+00:00

<img alt="Świetna gra, wielkie zarobki. Policzono Świątek nagrody" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l7zw4j-iga-swiatek-to-obecnie-jedna-z-najwiekszych-gwiazd-tenisa-6874917/alternates/LANDSCAPE_1280" />
    Ile Polka zarobiła od początku swojej przygody na korcie.

## 17 minut szaleństwa Messiego
 - [https://eurosport.tvn24.pl/17-minut-szale-stwa-messiego--zosta--pierwszym-takim-pi-karzem-w-historii,1141309.html?source=rss](https://eurosport.tvn24.pl/17-minut-szale-stwa-messiego--zosta--pierwszym-takim-pi-karzem-w-historii,1141309.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 08:24:00+00:00

<img alt="17 minut szaleństwa Messiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ev16yh-lionel-messi-to-mistrz-swiata-z-argentyna-z-2022-roku-6874895/alternates/LANDSCAPE_1280" />
    Został pierwszym takim piłkarzem w historii.

## Trzyletnia Zuzia zginęła od ciosów nożem. Matka dziewczynki skazana na dożywocie
 - [https://tvn24.pl/poznan/poznan-zabojstwo-trzyletniej-zuzi-na-ul-winklera-wyrok-dla-matki-dziewczynki-magdalena-c-skazana-na-dozywocie-6871574?source=rss](https://tvn24.pl/poznan/poznan-zabojstwo-trzyletniej-zuzi-na-ul-winklera-wyrok-dla-matki-dziewczynki-magdalena-c-skazana-na-dozywocie-6871574?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 07:41:27+00:00

<img alt="Trzyletnia Zuzia zginęła od ciosów nożem. Matka dziewczynki skazana na dożywocie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rzkf5g-magdalena-c-zostala-skazana-na-dozywocie-6874811/alternates/LANDSCAPE_1280" />
    Wyrok jest nieprawomocny.

## Nakleił na kanapkę promocyjną naklejkę, "naraził sklep na stratę". 17-latkowi grozi osiem lat więzienia
 - [https://tvn24.pl/krakow/mielec-17-latek-z-zarzutem-za-oszustwo-przy-zakupie-kanapki-policja-nakleil-promocyjna-naklejke-narazil-sklep-na-straty-6874696?source=rss](https://tvn24.pl/krakow/mielec-17-latek-z-zarzutem-za-oszustwo-przy-zakupie-kanapki-policja-nakleil-promocyjna-naklejke-narazil-sklep-na-straty-6874696?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 07:36:22+00:00

<img alt="Nakleił na kanapkę promocyjną naklejkę, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9zxotp-kanapka-bagietka-pieczywo-sklep-6874776/alternates/LANDSCAPE_1280" />
    Dostał zarzut.

## Rosyjska skandalistka odpadła w Miami
 - [https://eurosport.tvn24.pl/rosyjska-skandalistka-odpad-a-w-miami--zmarnowa-a-dwie-pi-ki-meczowe,1141308.html?source=rss](https://eurosport.tvn24.pl/rosyjska-skandalistka-odpad-a-w-miami--zmarnowa-a-dwie-pi-ki-meczowe,1141308.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 07:31:40+00:00

<img alt="Rosyjska skandalistka odpadła w Miami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ncqni6-anastazja-potapowa-odpadla-w-cwiercfinale-turnieju-wta-1000-w-miami-6874784/alternates/LANDSCAPE_1280" />
    Zmarnowała dwie piłki meczowe.

## Maseczki w tych miejscach nadal będą obowiązkowe. Opublikowano projekt
 - [https://tvn24.pl/biznes/z-kraju/koronawirus-obowiazkowe-maseczki-w-szpitalach-i-aptekach-zostana-na-dluzej-projekt-6874763?source=rss](https://tvn24.pl/biznes/z-kraju/koronawirus-obowiazkowe-maseczki-w-szpitalach-i-aptekach-zostana-na-dluzej-projekt-6874763?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 07:31:05+00:00

<img alt="Maseczki w tych miejscach nadal będą obowiązkowe. Opublikowano projekt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-194spt-maska-maski-maseczki-covid-shutterstock_1827869810-6874773/alternates/LANDSCAPE_1280" />
    Podano termin.

## USA nakładają kolejne sankcje na chińskie firmy
 - [https://tvn24.pl/biznes/ze-swiata/usa-nakladaja-sankcje-na-piec-chinskich-firm-w-zwiazku-z-przesladowaniami-ujgrow-6874603?source=rss](https://tvn24.pl/biznes/ze-swiata/usa-nakladaja-sankcje-na-piec-chinskich-firm-w-zwiazku-z-przesladowaniami-ujgrow-6874603?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 06:53:25+00:00

<img alt="USA nakładają kolejne sankcje na chińskie firmy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uh9fv4-pekin-chiny-6179510/alternates/LANDSCAPE_1280" />
    Podał Reuters.

## Seryjny dawca nasienia stał się ojcem 550 dzieci. Teraz stanie przed sądem pod zarzutem oszustwa
 - [https://tvn24.pl/swiat/holandia-seryjny-dawca-nasienia-stal-sie-ojcem-550-dzieci-teraz-stanie-przed-sadem-pod-zarzutem-oszustwa-6871603?source=rss](https://tvn24.pl/swiat/holandia-seryjny-dawca-nasienia-stal-sie-ojcem-550-dzieci-teraz-stanie-przed-sadem-pod-zarzutem-oszustwa-6871603?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 06:48:02+00:00

<img alt="Seryjny dawca nasienia stał się ojcem 550 dzieci. Teraz stanie przed sądem pod zarzutem oszustwa" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie8d82c7f11887fbb31c3bacdf66b78c59-plemnikow-jest-coraz-mniej-sa-one-tez-gorszej-jakosci-4405866/alternates/LANDSCAPE_1280" />
    "Jak mam powiedzieć moim dzieciom, że mogą mieć 300 braci i sióstr?"

## "Zastraszony tyradą". Niemcy piszą o przyczynie zwolnienia w Bayernie
 - [https://eurosport.tvn24.pl/-zastraszony-tyrad----niemcy-pisz--o-przyczynie-zwolnienia-nagelsmanna,1141306.html?source=rss](https://eurosport.tvn24.pl/-zastraszony-tyrad----niemcy-pisz--o-przyczynie-zwolnienia-nagelsmanna,1141306.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 06:35:33+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9p91dz-nagelsmann-i-mane-ktory-zostal-zdjety-w-drugiej-polowie-meczu-z-augsburgiem-6874717/alternates/LANDSCAPE_1280" />
    Miało pójść o kłótnię Juliana Nagelsmanna z jednym z piłkarzy.

## Spotkania z inwestorami i analitykami pod lupą Glapińskiego? Członek RPP: na wejściu jest portiernia
 - [https://tvn24.pl/polska/rpp-spotkania-z-inwestorami-pod-lupa-glapinskiego-ludwik-kotecki-niepotrzebne-szkodliwe-na-wejsciu-do-nbp-jest-portiernia-6874624?source=rss](https://tvn24.pl/polska/rpp-spotkania-z-inwestorami-pod-lupa-glapinskiego-ludwik-kotecki-niepotrzebne-szkodliwe-na-wejsciu-do-nbp-jest-portiernia-6874624?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 06:33:21+00:00

<img alt="Spotkania z inwestorami i analitykami pod lupą Glapińskiego? Członek RPP: na wejściu jest portiernia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5xq5u9-zrzut-ekranu-2023-03-29-o-07-6874620/alternates/LANDSCAPE_1280" />
    Ludwik Kotecki, członek Rady Polityki Pieniężnej, w "Rozmowie Piaseckiego".

## W miejskim archiwum spłonęły kilometry akt. Kolejny ruch prokuratury
 - [https://tvn24.pl/krakow/krakow-pozar-miejskiego-archiwum-kolejne-osoby-z-zarzutami-prokuratura-o-sledztwie-6874639?source=rss](https://tvn24.pl/krakow/krakow-pozar-miejskiego-archiwum-kolejne-osoby-z-zarzutami-prokuratura-o-sledztwie-6874639?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 06:24:29+00:00

<img alt="W miejskim archiwum spłonęły kilometry akt. Kolejny ruch prokuratury" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j2azpj-pozar-archiwum-w-krakowie-zdjecie-z-lutego-2021-roku-6720055/alternates/LANDSCAPE_1280" />
    Grono osób podejrzanych się poszerza.

## "Tego rodzaju dezinflację będziemy mieć w Polsce". Członek RPP podaje przykład
 - [https://tvn24.pl/biznes/pieniadze/inflacja-w-polsce-2023-ludwik-kotecki-czlonek-rpp-o-efekcie-bazy-i-przykladzie-oleju-rzepakowego-6874640?source=rss](https://tvn24.pl/biznes/pieniadze/inflacja-w-polsce-2023-ludwik-kotecki-czlonek-rpp-o-efekcie-bazy-i-przykladzie-oleju-rzepakowego-6874640?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 06:16:38+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pkxbal-shutterstock_1958419594-6874919/alternates/LANDSCAPE_1280" />
    Gościem "Rozmowy Piaseckiego" w TVN24 był Ludwik Kotecki, członek Rady Polityki Pieniężnej.

## Inflacja w Polsce zacznie hamować? "To jest częściowo prawda"
 - [https://tvn24.pl/biznes/pieniadze/inflacja-w-polsce-2023-ludwik-kotecki-czlonek-rpp-o-efekcie-bazy-6874640?source=rss](https://tvn24.pl/biznes/pieniadze/inflacja-w-polsce-2023-ludwik-kotecki-czlonek-rpp-o-efekcie-bazy-6874640?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 06:16:38+00:00

<img alt="Inflacja w Polsce zacznie hamować? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-a2ihrz-inflacja-produkty-kurczflacja-zakupy-6842614/alternates/LANDSCAPE_1280" />
    Gościem "Rozmowy Piaseckiego" w TVN24 był Ludwik Kotecki, członek Rady Polityki Pieniężnej.

## Unia Europejska "nie wiedziała, co robić z regionem. Rosja wiedziała i rozwinęła tu swoją sieć"
 - [https://tvn24.pl/swiat/czarnogora-prezydent-dziukanovic-unia-europejska-pozwolila-rosji-rozsiewac-na-balkanach-swoja-propagande-6873986?source=rss](https://tvn24.pl/swiat/czarnogora-prezydent-dziukanovic-unia-europejska-pozwolila-rosji-rozsiewac-na-balkanach-swoja-propagande-6873986?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 05:55:06+00:00

<img alt="Unia Europejska " src="https://tvn24.pl/najnowsze/cdn-zdjecie-trmdtl-milo-dziukanovic-6849393/alternates/LANDSCAPE_1280" />
    Prezydent Czarnogóry ostrzegł, że przez "zaniedbania", Bałkany stały się platformą dla antyunijnych narracji wspieranych przez Rosję.

## Apel do Rosjan, by nie adoptowali "skradzionych" dzieci
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-deportacja-ukrainskich-dzieci-wicepremier-ukrainy-apeluje-do-rosjan-by-nie-adoptowali-skradzionych-dzieci-6874595?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-deportacja-ukrainskich-dzieci-wicepremier-ukrainy-apeluje-do-rosjan-by-nie-adoptowali-skradzionych-dzieci-6874595?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 05:54:25+00:00

<img alt="Apel do Rosjan, by nie adoptowali " src="https://tvn24.pl/najnowsze/cdn-zdjecie-h0r4ai-ukrainskie-dzieci-uciekly-przed-wojna-5631301/alternates/LANDSCAPE_1280" />
    Głos zabrała wicepremier Ukrainy Iryna Wereszczuk.

## Bolesna porażka Niemców. Pierwsza taka od 69 lat
 - [https://eurosport.tvn24.pl/bolesna-pora-ka-niemc-w--pierwsza-taka-od-69-lat,1141304.html?source=rss](https://eurosport.tvn24.pl/bolesna-pora-ka-niemc-w--pierwsza-taka-od-69-lat,1141304.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 05:52:20+00:00

<img alt="Bolesna porażka Niemców. Pierwsza taka od 69 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s3k5el-niemcy-przegrali-z-belgia-23-w-meczu-towarzyskim-6874635/alternates/LANDSCAPE_1280" />
    Przegrali z Belgią.

## ZUS skontroluje firmy. Na to będzie zwracać szczególną uwagę
 - [https://tvn24.pl/biznes/dlafirm/zus-przeprowadzi-kontrole-w-firmach-pod-wzgledem-platnosci-skladek-6874608?source=rss](https://tvn24.pl/biznes/dlafirm/zus-przeprowadzi-kontrole-w-firmach-pod-wzgledem-platnosci-skladek-6874608?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 05:46:51+00:00

<img alt="ZUS skontroluje firmy. Na to będzie zwracać szczególną uwagę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-89z49z-zus-kwestionuje-zwolnienia-wystawione-przez-teleporade-5557976/alternates/LANDSCAPE_1280" />
    Podaje "Rzeczpospolita".

## "To jest niepokojące". Biden o rosyjskich planach rozmieszczenia broni jądrowej na Białorusi
 - [https://tvn24.pl/swiat/usa-joe-biden-zaniepokojony-mozliwoscia-ze-rosja-wysle-taktyczna-bron-jadrowa-na-bialorus-6874188?source=rss](https://tvn24.pl/swiat/usa-joe-biden-zaniepokojony-mozliwoscia-ze-rosja-wysle-taktyczna-bron-jadrowa-na-bialorus-6874188?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 05:40:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-23gfoe-prezydent-usa-joe-biden-6874174/alternates/LANDSCAPE_1280" />
    Oświadczenie Putina wywołało sprzeciw wielu państw.

## "Katastrofa. Nowa Hiszpania zniszczona"
 - [https://eurosport.tvn24.pl/-katastrofa--nowa-hiszpania-zniszczona-,1141305.html?source=rss](https://eurosport.tvn24.pl/-katastrofa--nowa-hiszpania-zniszczona-,1141305.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 05:35:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5avqhh-hiszpanie-zdemolowani-6874622/alternates/LANDSCAPE_1280" />
    Hiszpańskie media nie mają litości nad piłkarzami i nowym selekcjonerem reprezentacji.

## Wyraźny spadek liczby wypadków drogowych w Polsce. Nowe dane policji
 - [https://tvn24.pl/biznes/moto/wypadki-drogowe-2022-policja-opublikowala-statystyki-nadkomisarz-robert-opas-komentuje-6874596?source=rss](https://tvn24.pl/biznes/moto/wypadki-drogowe-2022-policja-opublikowala-statystyki-nadkomisarz-robert-opas-komentuje-6874596?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 05:22:56+00:00

<img alt="Wyraźny spadek liczby wypadków drogowych w Polsce. Nowe dane policji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4z07t2-droga-samochody-6683460/alternates/LANDSCAPE_1280" />
    Raport za 2022 rok.

## Próbował taranować autem przypadkowe osoby
 - [https://tvn24.pl/tvnwarszawa/wesola/warszawa-wesola-wjezdzal-samochodem-w-przypadkowych-ludzi-odpowie-za-usilowanie-zabojstwa-6869767?source=rss](https://tvn24.pl/tvnwarszawa/wesola/warszawa-wesola-wjezdzal-samochodem-w-przypadkowych-ludzi-odpowie-za-usilowanie-zabojstwa-6869767?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 05:03:35+00:00

<img alt="Próbował taranować autem przypadkowe osoby" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4t8hcs-policja-zatrzymala-26-latka-ktory-probowal-taranowac-ludzi-6111203/alternates/LANDSCAPE_1280" />
    Grozi mu dożywocie.

## Kim Dzong Un przeprowadza inspekcję głowic. "Dysponuje czymś potężniejszym, ale mniejszym gabarytowo"
 - [https://tvn24.pl/swiat/korea-polnocna-kim-dzong-un-przeprowadzil-inspekcje-glowic-6873747?source=rss](https://tvn24.pl/swiat/korea-polnocna-kim-dzong-un-przeprowadzil-inspekcje-glowic-6873747?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 04:59:18+00:00

<img alt="Kim Dzong Un przeprowadza inspekcję głowic. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n6uz8b-kim-dzong-un-przeprowadzil-inspekcje-glowic-6873728/alternates/LANDSCAPE_1280" />
    Eksperci wyrażają zaniepokojenie.

## Kumulacja w Lotto dalej rośnie. Bez głównej wygranej od 11 marca
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia-280323-liczby-z-ostatniego-losowania-6874589?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia-280323-liczby-z-ostatniego-losowania-6874589?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 04:51:59+00:00

<img alt="Kumulacja w Lotto dalej rośnie. Bez głównej wygranej od 11 marca" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie63e089d459976179939fb237bec19518-wyniki-losowania-lotto-4430595/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## Skoczą ostatni raz w karierze
 - [https://eurosport.tvn24.pl/skocz--ostatni-raz-w-karierze--planica-pod-znakiem-po-egna-,1141236.html?source=rss](https://eurosport.tvn24.pl/skocz--ostatni-raz-w-karierze--planica-pod-znakiem-po-egna-,1141236.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 04:34:43+00:00

<img alt="Skoczą ostatni raz w karierze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q52ahd-bor-pavlovczic-zakonczy-kariere-w-planicy-6874597/alternates/LANDSCAPE_1280" />
    Planica pod znakiem pożegnań.

## "Martwię się o naszych sportowców i wszystkich Ukraińców"
 - [https://eurosport.tvn24.pl/-martwi--si--o-naszych-sportowc-w--reprezentacje-narodowe-i-wszystkich-ukrai-c-w-,1141285.html?source=rss](https://eurosport.tvn24.pl/-martwi--si--o-naszych-sportowc-w--reprezentacje-narodowe-i-wszystkich-ukrai-c-w-,1141285.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 04:12:10+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vci1wm-wadym-hutcajt-jest-ministrem-sportu-i-szefem-ukrainskiego-komitetu-olimpijskiego-6874591/alternates/LANDSCAPE_1280" />
    Wtorkowa decyzja Międzynarodowego Komitetu Olimpijskiego wzbudziła mnóstwo kontrowersji.

## Fala zamieszek we Francji, rannych zostało 175 funkcjonariuszy
 - [https://tvn24.pl/swiat/francja-na-skutek-protestow-przeciwko-reformie-emerytalnej-175-policjantow-zostalo-rannych-6874405?source=rss](https://tvn24.pl/swiat/francja-na-skutek-protestow-przeciwko-reformie-emerytalnej-175-policjantow-zostalo-rannych-6874405?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 04:07:48+00:00

<img alt="Fala zamieszek we Francji, rannych zostało 175 funkcjonariuszy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rgayaf-protesty-we-francji-6874574/alternates/LANDSCAPE_1280" />
    Setki tysięcy ludzi ponownie protestowały przeciwko reformie emerytalnej.

## Coraz droższe parkowanie. Kierowcy w dużych miastach muszą spodziewać się znacznych zmian
 - [https://tvn24.pl/polska/rosna-ceny-za-parkowanie-w-duzych-miastach-nawet-11-zlotych-za-godzine-postoju-6873095?source=rss](https://tvn24.pl/polska/rosna-ceny-za-parkowanie-w-duzych-miastach-nawet-11-zlotych-za-godzine-postoju-6873095?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 04:04:52+00:00

<img alt="Coraz droższe parkowanie. Kierowcy w dużych miastach muszą spodziewać się znacznych zmian" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8vb8sc-krakow-samochody-shutterstock1109057162-6510422/alternates/LANDSCAPE_1280" />
    Godzina postoju staje się droższa niż litr paliwa.

## Wysłali w kosmos rakietę z drukarki. To może być przełom w technologii używanej na Ziemi
 - [https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-66,S00E66,1030020?source=rss](https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-66,S00E66,1030020?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 04:00:00+00:00

<img alt="Wysłali w kosmos rakietę z drukarki. To może być przełom w technologii używanej na Ziemi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sr0z5i-terran-1-6872178/alternates/LANDSCAPE_1280" />
    Pierwsze efekty są bardzo obiecujące.

## "Wszystko jest w trakcie". Wielkie inwestycje i niespełnione obietnice rządu PiS
 - [https://tvn24.pl/polska/wielkie-inwestycje-i-niespelnione-obietnice-rzadu-pis-6872723?source=rss](https://tvn24.pl/polska/wielkie-inwestycje-i-niespelnione-obietnice-rzadu-pis-6872723?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 03:55:15+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-655708-konferencja-politykow-partii-rzadzacej-6873124/alternates/LANDSCAPE_1280" />
    Slajdów było sporo, obietnic wyborczych też.

## "Plan prezydenta Ukrainy zapewni trwały pokój i uniemożliwi Rosji ponowny atak"
 - [https://tvn24.pl/swiat/usa-szef-dyplomacji-blinken-plan-zelenskiego-zapewni-trwaly-pokoj-6874066?source=rss](https://tvn24.pl/swiat/usa-szef-dyplomacji-blinken-plan-zelenskiego-zapewni-trwaly-pokoj-6874066?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 03:38:20+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8lwj3-wolodymyr-zelenski-w-obwodzie-sumskim-na-polnocy-kraju-6871550/alternates/LANDSCAPE_1280" />
    Ukraina popierana podczas Szczytu dla Demokracji.

## Rozpoczęto montaż podstawy iglicy katedry Notre-Dame
 - [https://tvn24.pl/swiat/francja-rozpoczeto-montaz-podstawy-iglicy-katedry-notre-dame-6874139?source=rss](https://tvn24.pl/swiat/francja-rozpoczeto-montaz-podstawy-iglicy-katedry-notre-dame-6874139?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 03:26:42+00:00

<img alt="Rozpoczęto montaż podstawy iglicy katedry Notre-Dame" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rb0lzv-w-katedrze-notre-dame-trwaja-prace-konserwatorskie-5694871/alternates/LANDSCAPE_1280" />
    Ważąca 50 ton struktura została wykonana z 250-letnich dębów.

## Zacięte walki pod Bachmutem. Epicentrum działań w czterech miastach
 - [https://tvn24.pl/swiat/ukraina-wojsko-pod-bachmutem-w-ciagu-doby-zginelo-prawie-90-rosyjskich-zolnierzy-6874324?source=rss](https://tvn24.pl/swiat/ukraina-wojsko-pod-bachmutem-w-ciagu-doby-zginelo-prawie-90-rosyjskich-zolnierzy-6874324?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 03:19:57+00:00

<img alt="Zacięte walki pod Bachmutem. Epicentrum działań w czterech miastach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r8ig5t-bachmut-6860250/alternates/LANDSCAPE_1280" />
    Odcinek bachmucki został ostrzelany poprzedniego dnia łącznie 194 razy.

## "To jest niepokojące". Biden o rosyjskich planach rozmieszczenia broni jądrowej na Białorusi
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-29-marca-2023-6874252?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-29-marca-2023-6874252?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 03:11:06+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-23gfoe-prezydent-usa-joe-biden-6874174/alternates/LANDSCAPE_1280" />
    Relacjonujemy wydarzenia z i wokół Ukrainy.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-6874234?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-6874234?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-29 03:07:57+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-djhour-ukrainski-zolnierz-w-poblizu-bachmutu-6862985/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa 399. dzień.

