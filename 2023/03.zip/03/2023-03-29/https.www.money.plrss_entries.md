# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Polska w strefie euro? "Agresja Rosji na Ukrainę pokazuje, że lepiej w niej być"
 - [https://www.money.pl/pieniadze/polska-w-strefie-euro-agresja-rosji-na-ukraine-pokazuje-ze-lepiej-w-niej-byc-6881751031847840a.html](https://www.money.pl/pieniadze/polska-w-strefie-euro-agresja-rosji-na-ukraine-pokazuje-ze-lepiej-w-niej-byc-6881751031847840a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 19:52:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a97470d5-3306-4844-a9f6-7b8227458caa" width="308" /> Decyzja o wejściu do strefy euro jest polityczna, a nie ekonomiczna. Jednak przy silnym imperatywie politycznym to dzieło, a nią jest wspólna waluta w Unii Europejskiej, byłoby wzmacniane i poprawiane - stwierdzili zwolennicy przyjęcia euro w Polsce podczas debaty oksfordzkiej w Teatrze Polskim w Warszawie. Przeciwnicy podkreślali, że euro utrudnia walkę z inflacją.

## Strumień pieniędzy dla kobiet w Afryce. USA obiecują pomoc
 - [https://www.money.pl/gospodarka/strumien-pieniedzy-dla-kobiet-w-afryce-usa-obiecuja-pomoc-6881723381476288a.html](https://www.money.pl/gospodarka/strumien-pieniedzy-dla-kobiet-w-afryce-usa-obiecuja-pomoc-6881723381476288a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 16:44:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/09c40bcd-6978-4108-95e1-fd212c54693c" width="308" /> Wiceprezydent USA Kamala Harris, która gości w Ghanie, zapowiedziała przekazanie ponad jednego mld dolarów na aktywizację i wsparcie kobiet w Afryce. Reuters przypomina, że Ameryka zabiega o poprawę stosunków z krajami Afryki, gdzie swoje wpływy usiłują umocnić Chiny i Rosja.

## Rząd likwiduje użytkowanie wieczyste. Oto co się zmieni
 - [https://www.money.pl/gospodarka/rzad-likwiduje-uzytkowanie-wieczyste-oto-co-sie-zmieni-6881699233622976a.html](https://www.money.pl/gospodarka/rzad-likwiduje-uzytkowanie-wieczyste-oto-co-sie-zmieni-6881699233622976a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 15:11:05+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/05fa9f34-89a0-44ec-b63c-eeefe51ba235" width="308" /> Rząd ogłosił, że użytkowanie wieczyste ma zostać definitywnie zlikwidowane. Firmy i organizacje, które użytkują grunty należące do Skarbu Państwa i samorządów będą mogły wykupić je na własność.

## Na stacjach benzynowych trwa dobry trend dla kierowców
 - [https://www.money.pl/gospodarka/na-stacjach-benzynowych-trwa-dobry-trend-dla-kierowcow-6881689100676000a.html](https://www.money.pl/gospodarka/na-stacjach-benzynowych-trwa-dobry-trend-dla-kierowcow-6881689100676000a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 14:24:35+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/14c778b2-2b3c-498d-bd7e-1099f6b09ece" width="308" /> Paliwa na stacjach nadal tanieją - poinformowali  w środę analitycy portalu e-petrol.pl. Litr diesla kosztuje obecnie średnio 6,75 zł, co oznacza obniżkę o 14 gr. O 6 gr tańsza niż przed tygodniem jest też benzyna Pb95, która kosztuje aktualnie średnio 6,62 zł/l.

## PPK. Idzie wielki przelew. "Na konto każdego uczestnika trafi 240 zł"
 - [https://www.money.pl/emerytury/ppk-idzie-wielki-przelew-na-konto-kazdego-uczestnika-trafi-240-zl-6881682110155680a.html](https://www.money.pl/emerytury/ppk-idzie-wielki-przelew-na-konto-kazdego-uczestnika-trafi-240-zl-6881682110155680a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 13:56:07+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6e26d290-a018-49c2-b076-79adc223a5be" width="308" /> W ramach Pracowniczych Planów Kapitałowych przekazana została tzw. opłata roczna, co oznacza, że na konto każdego uczestnika trafi 240 zł - zapowiedział wiceprezes Polskiego Funduszu Rozwoju Bartosz Marczuk.

## Koniec z ubojem koni w UE? Jest nowa inicjatywa
 - [https://www.money.pl/gospodarka/koniec-z-ubojem-koni-w-ue-jest-nowa-inicjatywa-6881667773443008a.html](https://www.money.pl/gospodarka/koniec-z-ubojem-koni-w-ue-jest-nowa-inicjatywa-6881667773443008a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 12:57:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/869da759-5c61-4369-8a46-75fb8c609c17" width="308" /> Europejska inicjatywa obywatelska (EIO) "Koniec z ubojem koni" zostanie zarejestrowana przez Komisję Europejską. Organizatorzy inicjatywy wzywają Komisję Europejską do zaproponowania przepisów zakazujących uboju koni, w tym także ich hodowli i eksportu do celów produkcji futer, skór i mięsa.

## Produkcja amunicji w Polsce. Rząd przeznaczy na to 2 mld zł
 - [https://www.money.pl/gospodarka/produkcja-amunicji-w-polsce-rzad-przeznaczy-na-to-2-mld-zl-6881662835018688a.html](https://www.money.pl/gospodarka/produkcja-amunicji-w-polsce-rzad-przeznaczy-na-to-2-mld-zl-6881662835018688a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 12:37:42+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/195c0ad7-0292-43db-9baf-e1f55a830516" width="308" /> Rząd przeznaczy 2 mld zł na inwestycje w rozbudowie zdolności produkcji amunicji artyleryjskiej - poinformował na konferencji prasowej premier Mateusz Morawiecki. Rząd przyjął także uchwałę w sprawie programu zwiększenia produkcji amunicji w Polsce.

## Nieoficjalnie: będzie nowy prezes PKO BP. Paweł Gruza ma stracić stanowisko
 - [https://www.money.pl/banki/nieoficjalnie-bedzie-nowy-prezes-pko-bp-pawel-gruza-ma-stracic-stanowisko-6881628804238272a.html](https://www.money.pl/banki/nieoficjalnie-bedzie-nowy-prezes-pko-bp-pawel-gruza-ma-stracic-stanowisko-6881628804238272a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 10:19:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6e4dd571-cc5d-4082-bf80-6209d2e77a3f" width="308" /> Jak informuje portal RMF24.pl prezes PKO BP - największego banku w Polsce - Paweł Gruza ma wkrótce zostać pozbawiony stanowiska. Byłaby to już piąta zmiana prezesa w ciągu ostatnich dwóch.

## Tyle PiS daje na tacę o. Rydzykowi. Twórca TV Trwam nie może narzekać
 - [https://www.money.pl/gospodarka/tyle-pis-daje-na-tace-o-rydzykowi-tworca-tv-trwam-nie-moze-narzekac-6881622950357952a.html](https://www.money.pl/gospodarka/tyle-pis-daje-na-tace-o-rydzykowi-tworca-tv-trwam-nie-moze-narzekac-6881622950357952a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 09:55:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c0852816-3b49-469e-8446-21d4e6afd55b" width="308" /> W połowie 2022 r. weszły w życie przepisy, które zmuszają partie polityczne do spowiadania się z wszystkich zawieranych umów. Jak się okazało, PiS jest hojny dla o. Tadeusza Rydzyka. Fundacja toruńskiego redemptorysty może liczyć np. na blisko 500 tys. zł rocznie za transmisję mszy świętej.

## Czy wojna przyspiesza powojenny rozwój?
 - [https://www.money.pl/gospodarka/prosta-ekonomia/czy-wojna-przyspiesza-powojenny-rozwoj-6881615145806784a.html](https://www.money.pl/gospodarka/prosta-ekonomia/czy-wojna-przyspiesza-powojenny-rozwoj-6881615145806784a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 09:38:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c5516a4f-b97d-44b8-b39c-5531ebf0f78a" width="308" /> Omawiamy mit dobrodziejstw wojny, który brzmi mniej więcej tak: "Czy wojna, śmierci i zniszczenia, nie przynosi następstw korzystnych dla gospodarki? Wystarczy spojrzeć, ile osób ma pracę przy odbudowie zrujnowanych miast i infrastruktury".

## Co trzeci frankowicz nie może liczyć na ugodę. Ustawa tego nie zmieni
 - [https://www.money.pl/banki/co-trzeci-frankowicz-nie-moze-liczyc-na-ugode-ustawa-tego-nie-zmieni-6881612144704320a.html](https://www.money.pl/banki/co-trzeci-frankowicz-nie-moze-liczyc-na-ugode-ustawa-tego-nie-zmieni-6881612144704320a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 09:11:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9d62bb59-68f4-46e4-97c7-d83d11b863f4" width="308" /> Wielu kredytobiorców - nawet co trzeci frankowicz - nie może liczyć na ofertę ugodową ze strony banku, który udzielił kredytu hipotecznego we frankach szwajcarskich. Jak informuje "Rzeczpospolita", problemy będą mieć ci osoby, których kredytodawcy nie prowadzą aktywnej działalności w Polsce.

## Hiperautomatyzacja w e-commerce
 - [https://www.money.pl/gospodarka/hiperautomatyzacja-w-e-commerce-6881606134078272a.html](https://www.money.pl/gospodarka/hiperautomatyzacja-w-e-commerce-6881606134078272a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 08:46:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0aa4e0f3-e752-404d-a91a-caa1314942d0" width="308" /> U progu nowego tysiąclecia wizja zautomatyzowanego, pełnego robotów świata, w którym ludzie żyją tylko dzięki swoim cyfrowym awatarom, towarzyszyła jedynie filmom i książkom z kategorii science fiction. Jak pokazuje praktyka, cywilizacja zmierza jednak właśnie w kierunku już nie tylko automatyzacji, ale nawet hiperautomatyzacji. Jak przejawia się to w branży e-commerce?

## Tadeusz Cymański: wyborcy Platformy uciekają do Konfederacji. Polityk wskazał powód
 - [https://www.money.pl/gospodarka/tadeusz-cymanski-wyborcy-platformy-uciekaja-do-konfederacji-polityk-wskazal-powod-6881598018639489v.html](https://www.money.pl/gospodarka/tadeusz-cymanski-wyborcy-platformy-uciekaja-do-konfederacji-polityk-wskazal-powod-6881598018639489v.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 08:18:05+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/abf19c13-0d4c-4fc1-bd08-7fd1e3b33ba3" width="308" /> - Dlaczego wyborcy Platformy Obywatelskiej uciekają do Konfederacji? Bo esencją programów PO był wolnorynkowy liberalizm, a dziś nawet sam prof. Leszek Balcerowicz pisze, że Tusk i Platforma robią z ludzi idiotów - powiedział w programie "Newsroom" WP Tadeusz Cymański, poseł Solidarnej Polski. – Na spotkaniu wyborczym z Tuskiem głos zabrał ostatnio Paweł Tatajno, którego trudno posądzić o to, że kocha PiS. Zwrócił się do niego z pytaniem: co się stało, że nagle znienawidził pan przedsiębiorców? To pokazuje, dlaczego wyborcy odwracają się od PO – uważa polityk.

## Podatki uderzają w kieszenie Polaków. Tadeusz Cymański: słabością państwa jest nierównomierna poprawa sytuacji
 - [https://www.money.pl/gospodarka/podatki-uderzaja-w-kieszenie-polakow-tadeusz-cymanski-slaboscia-panstwa-jest-nierownomierna-poprawa-sytuacji-6881591183390337v.html](https://www.money.pl/gospodarka/podatki-uderzaja-w-kieszenie-polakow-tadeusz-cymanski-slaboscia-panstwa-jest-nierownomierna-poprawa-sytuacji-6881591183390337v.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 07:47:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0b32e12b-1aaf-4fe4-8688-5f7e8ec62d41" width="308" /> Rząd chwali się obniżaniem podatków. Money.pl na przykładzie rodziny z dwójką dzieci, gdzie rodzice są zatrudnieni na etatach i zarabiają po 5 tys. zł miesięcznie każde, policzył, jak wygląda to naprawdę. - Jeśli prawdą jest to, co napisało Money.pl, że większości społeczeństwa się pogorszyło, to za chwilę będą wybory, większość zdecyduje i odejdziemy. Można już ręce zacierać, bo w końcu będzie dobrze - powiedział w programie "Newsroom" WP Tadeusz Cymański, poseł Solidarnej Polski. – Ale nie mówimy o większości. Wyobrażacie sobie taką władzę, która sprawi, że wszystkim będzie lepiej i wszystkim się poprawi? Stare polskie porzekadło mówi: Bogatemu diabeł dzieci bawi, a biednemu wiatr w oczy. W sprawach społecznych mam poglądy bliskie środowiskom lewicowym i tego nie ukrywam. Analiza Money.pl jest wybiórcza. Na zmianach podatkowych tracą najsilniejsi ekonomicznie obywatele. W centrum uwagi, z czego ogromnie się cieszę, są najsłabsi. Były w naszym obozie politycznym błędy, zaniechania, wstydliwe sprawy – nie zaprzeczam, nie jesteśmy aniołami. Jednak w sprawach społecznych nie można nam nic zarzucić. Słabością państwa jest to, że wzrost i poprawa sytuacji są nierównomierne np. w stosunku do budżetówki. Są obszary, które wymagają poprawy – dodał polityk.

## Ci seniorzy dostaną "trzynastki" szybciej niż powinni. Oto powód
 - [https://www.money.pl/emerytury/ci-seniorzy-dostana-trzynastki-szybciej-niz-powinni-oto-powod-6881561295080256a.html](https://www.money.pl/emerytury/ci-seniorzy-dostana-trzynastki-szybciej-niz-powinni-oto-powod-6881561295080256a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 05:44:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0b2daf8f-f7c4-457a-9e9a-88f4ac4918f3" width="308" /> Tzw. trzynaste emerytury wkrótce trafią na konta seniorów. Nie wszyscy otrzymają je jednak w tym samym terminie. Niektórzy emeryci mogą spodziewać się szybszego przelewu niż w przypadku pozostałych świadczeniobiorców.

## Kursy walut 29.03.2023. Środowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-29-03-2023-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6881553448930112a.html](https://www.money.pl/pieniadze/kursy-walut-29-03-2023-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6881553448930112a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 05:12:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 29.03.2023. W środę za jednego dolara (USD) zapłacimy 4.31 zł. Cena jednego funta szterlinga (GBP) to 5.32 zł, a franka szwajcarskiego (CHF) 4.69 zł. Z kolei euro (EUR) możemy zakupić za 4.68 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 29.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-29-03-2023-6881550651870016a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-29-03-2023-6881550651870016a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 05:01:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 29.03.2023. W środę za jednego dolara (USD) trzeba zapłacić 4.3136 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 29.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-29-03-2023-6881550653643584a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-29-03-2023-6881550653643584a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 05:01:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 29.03.2023. W środę za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.3189 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 29.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-29-03-2023-6881550648961824a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-29-03-2023-6881550648961824a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 05:01:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 29.03.2023. W środę za jedno euro (EUR) trzeba zapłacić 4.6754 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 29.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-29-03-2023-6881550648453920a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-29-03-2023-6881550648453920a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 05:01:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 29.03.2023. W środę za jednego franka (CHF) trzeba zapłacić 4.6854 zł.

## Koniec kryzysu bankowego? Prezydent Joe Biden ostrzega
 - [https://www.money.pl/banki/koniec-kryzysu-bankowego-prezydent-joe-biden-ostrzega-6881542450764608a.html](https://www.money.pl/banki/koniec-kryzysu-bankowego-prezydent-joe-biden-ostrzega-6881542450764608a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 04:27:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/34347610-de2a-4c49-9308-fe8d525f8a20" width="308" /> W ostatnim czasie sektor bankowy na świece przeżywa kryzys, który zaczął się od upadku amerykańskiego Silicon Valley Bank. Prezydent USA Joe Biden zabrał głos w tej sprawie. Przywódca Stanów Zjednoczonych ostrzega, że problemy jeszcze się nie zakończyły.

## Rząd chwali się obniżaniem podatków. Policzyliśmy. Oto cała prawda
 - [https://www.money.pl/podatki/rzad-chwali-sie-obnizaniem-podatkow-policzylismy-oto-cala-prawda-6880944107703104a.html](https://www.money.pl/podatki/rzad-chwali-sie-obnizaniem-podatkow-policzylismy-oto-cala-prawda-6880944107703104a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-29 03:47:11+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0266bfbc-df0b-4db7-9735-74ef1b16f67e" width="308" /> Według rzecznika rządu bilans podwyżek i obniżek wszystkich danin wprowadzonych za rządów PiS wychodzi na korzyść podatników. Policzyliśmy więc, ile w ramach podatków płaci obecnie wspomniana przez Piotra Müllera rodzina. Sprawdziliśmy też, ile muszą płacić inne grupy społeczne.

