# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Private jet use in Britain soars by 75%: Figures reveal one aircraft takes off every SIX minutes
 - [https://www.dailymail.co.uk/news/article-11917881/Private-jet-use-Britain-soars-75-Figures-reveal-one-aircraft-takes-SIX-minutes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917881/Private-jet-use-Britain-soars-75-Figures-reveal-one-aircraft-takes-SIX-minutes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:44:40+00:00

Last year they increased by a staggering 75 per cent to 90,256 flights, according to research by Greenpeace.

## Manhattan hedge funder pays $1bn to ex-wife, 64, after she left him for FEMALE gallerist
 - [https://www.dailymail.co.uk/news/article-11917463/Manhattan-hedge-funder-pays-1bn-ex-wife-64-left-FEMALE-gallerist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917463/Manhattan-hedge-funder-pays-1bn-ex-wife-64-left-FEMALE-gallerist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:42:43+00:00

Israel Englander, 74, is said to have paid Caryl Englander, 64, upwards of $1billion after they privately settled their divorce following 40 years of marriage.

## Murder investigation is launched after woman in her 60s dies in quiet Cornwall village
 - [https://www.dailymail.co.uk/news/article-11917857/Murder-investigation-launched-woman-60s-dies-quiet-Cornwall-village.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917857/Murder-investigation-launched-woman-60s-dies-quiet-Cornwall-village.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:42:27+00:00

Officers and paramedics attended the scene at Penwithick, Cornwall  on Tuesday evening and found a woman in her 60s unresponsive and with serious facial injuries who was later declared dead.

## DAILY MAIL COMMENT: Lack of trans guidance is failing our schools
 - [https://www.dailymail.co.uk/news/article-11917835/DAILY-MAIL-COMMENT-Lack-trans-guidance-failing-schools.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917835/DAILY-MAIL-COMMENT-Lack-trans-guidance-failing-schools.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:41:38+00:00

DAILY MAIL COMMENT: Many secondary schools, fuelled by gender zealotry, stand accused of jeopardising children's (file photo) welfare by flagrantly breaking safeguarding rules.

## Barack Obama's Melbourne speech: Security guard clashes with 'cookers'
 - [https://www.dailymail.co.uk/news/article-11917427/Barack-Obamas-Melbourne-speech-Security-guard-clashes-cookers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917427/Barack-Obamas-Melbourne-speech-Security-guard-clashes-cookers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:39:19+00:00

A security guard armed with nothing more than his words has taken on a group of 'cookers' protesting outside a Barack Obama speaking event.

## Real estate agent's weird email to Aussie renter after property inspection
 - [https://www.dailymail.co.uk/news/article-11917563/Real-estate-agents-weird-email-Aussie-renter-property-inspection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917563/Real-estate-agents-weird-email-Aussie-renter-property-inspection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:36:09+00:00

A renter was left outraged after their real estate agent followed up a property inspection with an email demanding they do a common household chore, prompting others to share their tenant horror stories.

## Toddler left orphaned after her dad drowned off British Virgin Islands, a year after mom died
 - [https://www.dailymail.co.uk/news/article-11917657/Toddler-left-orphaned-dad-drowned-British-Virgin-Islands-year-mom-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917657/Toddler-left-orphaned-dad-drowned-British-Virgin-Islands-year-mom-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:35:34+00:00

Robert Safford, 33, was found dead off his boat in the British Virgin Islands on March 22, in what police confirmed was a boating accident. He leaves behind a young daughter, Isabella.

## Brits to be offered hundreds off energy bills if they agree to WIND FARM built near their homes
 - [https://www.dailymail.co.uk/news/article-11917843/Brits-offered-hundreds-energy-bills-agree-WIND-FARM-built-near-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917843/Brits-offered-hundreds-energy-bills-agree-WIND-FARM-built-near-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:34:26+00:00

Energy Secretary Grant Shapps is set to confirm that families who choose to support onshore wind can benefit directly through lower bills when he unveils his 'Powering Up Britain' plan.

## Law school grad says he was forced to undergo PSYCHIATRIC EVALUATION after questioning COVID policy
 - [https://www.dailymail.co.uk/news/article-11917465/Law-school-grad-says-forced-undergo-PSYCHIATRIC-EVALUATION-questioning-COVID-policy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917465/Law-school-grad-says-forced-undergo-PSYCHIATRIC-EVALUATION-questioning-COVID-policy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:28:26+00:00

A former Georgetown Law student said he was subjected to a psychiatric evaluation after questioning the university's ongoing COVID policy restrictions.

## Huge change to coming to MyGov today after major facelift of the system
 - [https://www.dailymail.co.uk/news/article-11917341/Huge-change-coming-MyGov-today-major-facelift-system.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917341/Huge-change-coming-MyGov-today-major-facelift-system.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:27:19+00:00

Australians can now access a digital version of their Medicare Card on their phone through the MyGov app.

## Woman faces criminal trial in France after referring to President Macron as 'garbage'
 - [https://www.dailymail.co.uk/news/article-11917739/Woman-faces-criminal-trial-France-referring-President-Macron-garbage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917739/Woman-faces-criminal-trial-France-referring-President-Macron-garbage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:25:36+00:00

Accusing the president of forcing striking binmen to leave piles of rubbish around her home in Saint-Omer, Valerie posted a picture of graffiti saying 'Macron Garbage'.

## Victoria premier Dan Andrews team hit back at claims the premier could be manipulated by China
 - [https://www.dailymail.co.uk/news/article-11914187/Victoria-premier-Dan-Andrews-team-hit-claims-premier-manipulated-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914187/Victoria-premier-Dan-Andrews-team-hit-claims-premier-manipulated-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:24:01+00:00

The Victorian government denies the premier could be manipulated by the Chinese government during his first visit to the country since the COVID-19 outbreak.

## Parents claim son was rejected from Whitsunday Christian College over its 'short hair policy'
 - [https://www.dailymail.co.uk/news/article-11913143/Parents-claim-son-rejected-Whitsunday-Christian-College-short-hair-policy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913143/Parents-claim-son-rejected-Whitsunday-Christian-College-short-hair-policy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:22:52+00:00

Whitsunday Christian College in Cannonvale, Queensland has denied the application of Robert and Tara Congoo's eldest son because, they claim, it insists he must wear short hair to attend the school.

## Aboriginal elder Joy Murphy gets apology after she was dumped from Barack Obama's Melbourne event
 - [https://www.dailymail.co.uk/news/article-11917733/Aboriginal-elder-Joy-Murphy-gets-apology-dumped-Barack-Obamas-Melbourne-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917733/Aboriginal-elder-Joy-Murphy-gets-apology-dumped-Barack-Obamas-Melbourne-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:17:52+00:00

An Aboriginal elder who was dumped from giving a Welcome to Country at Barack Obama's highly anticipated speech in Melbourne has received an apology from event organisers.

## Britain's ban on new petrol and diesel cars WILL still take effect from 2030, Government confirms
 - [https://www.dailymail.co.uk/news/article-11917649/Britains-ban-new-petrol-diesel-cars-effect-2030-Government-confirms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917649/Britains-ban-new-petrol-diesel-cars-effect-2030-Government-confirms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:08:21+00:00

Grant Shapps said the UK did not have to follow the EU, which has climbed down to allow sales of new internal combustion engine cars that only run on 'e-fuels' to continue after 2035.

## A staggering £21bn has been lost to fraudsters since the start of the pandemic, figures reveal
 - [https://www.dailymail.co.uk/news/article-11917671/A-staggering-21bn-lost-fraudsters-start-pandemic-figures-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917671/A-staggering-21bn-lost-fraudsters-start-pandemic-figures-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:05:54+00:00

According to the National Audit Office, fraud losses rose from £5.5 billion in the two years before the pandemic, to £21 billion in the following two years.

## Damning report exposes how children are being 'put at risk' by the gender ideology sweeping schools
 - [https://www.dailymail.co.uk/news/article-11917241/Damning-report-exposes-children-risk-gender-ideology-sweeping-schools.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917241/Damning-report-exposes-children-risk-gender-ideology-sweeping-schools.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:05:11+00:00

Most of the secondary schools surveyed by the Policy Exchange think-tank are also teaching the contested theory that individuals have a gender identity that can differ from their biological sex.

## Revealing depression left BBC's Huw Edwards getting 'funny looks' but he's 'excited' for  coronation
 - [https://www.dailymail.co.uk/news/article-11915833/Revealing-depression-left-BBCs-Huw-Edwards-getting-funny-looks-hes-excited-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915833/Revealing-depression-left-BBCs-Huw-Edwards-getting-funny-looks-hes-excited-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:02:57+00:00

While most people praised him for speaking out about his mental health, some have given him 'funny looks' and questioned his ability to do his job, the BBC's Huw Edwards (pictured) has said.

## Adelaide dog attack on Alaruh Rose sparks calls for ban of South African Boerbel
 - [https://www.dailymail.co.uk/news/article-11909221/Adelaide-dog-attack-Alaruh-Rose-sparks-calls-ban-South-African-Boerbel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909221/Adelaide-dog-attack-Alaruh-Rose-sparks-calls-ban-South-African-Boerbel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 23:02:03+00:00

Derek McNair has demanded a ban on the sale of the South African Boerboel following the horrifying attack on Camilla Avenue at Osborne, Adelaide, on Monday.

## Royal Navy probe into misogyny, bullying and sexual harassment on submarines branded a 'whitewash'
 - [https://www.dailymail.co.uk/news/article-11917663/Royal-Navy-probe-misogyny-bullying-sexual-harassment-submarines-branded-whitewash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917663/Royal-Navy-probe-misogyny-bullying-sexual-harassment-submarines-branded-whitewash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 22:52:26+00:00

First Sea Lord Admiral Sir Ben Key launched the inquiry after the Mail exposed claims of mistreatment up and down the chain of command in the submarine service last October.

## Rouse Hill man allegedly walks Sydney suburb with bong shaped like AK-47 assault rifle
 - [https://www.dailymail.co.uk/news/article-11917345/Rouse-Hill-man-allegedly-walks-Sydney-suburb-bong-shaped-like-AK-47-assault-rifle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917345/Rouse-Hill-man-allegedly-walks-Sydney-suburb-bong-shaped-like-AK-47-assault-rifle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 22:17:59+00:00

NSW Police rushed to Rouse Hill, in Sydney's northwest, at about 5:30pm on Wednesday night, after residents reported seeing a man allegedly wielding the gun.

## Captain Hannah Knapton becomes the first ever female Paras officer to earn a maroon beret
 - [https://www.dailymail.co.uk/news/article-11917517/Captain-Hannah-Knapton-female-Paras-officer-earn-maroon-beret.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917517/Captain-Hannah-Knapton-female-Paras-officer-earn-maroon-beret.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 22:09:53+00:00

The Paras' first ever female officer Captain Hannah Knapton (pictured) earned her coveted maroon beret after passing the regiment's exhaustive entry tests yesterday.

## Beloved Lucky grocery store in California closes doors after Whole Foods and Trader Joes move in
 - [https://www.dailymail.co.uk/news/article-11917285/Beloved-Lucky-grocery-store-California-closes-doors-Foods-Trader-Joes-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917285/Beloved-Lucky-grocery-store-California-closes-doors-Foods-Trader-Joes-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:58:53+00:00

After the Lucky budget supermarket closes, shoppers will be left with options like two nearby Trader Joes and three Whole Foods located within a five-mile radius of the local store.

## Locals go to war over accommodation centres for 5,000 new boat migrants
 - [https://www.dailymail.co.uk/news/article-11917473/Locals-war-accommodation-centres-5-000-new-boat-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917473/Locals-war-accommodation-centres-5-000-new-boat-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:53:55+00:00

One Tory council has already lodged a legal challenge aiming to stop the Home Office plan dead in its tracks after the immigration minister announced a new centre for Channel migrants.

## It'll take MUCH more than fantastic British Challenger 2 tanks for Ukraine to beat Vladimir Putin
 - [https://www.dailymail.co.uk/news/article-11917497/Itll-fantastic-British-Challenger-2-tanks-Ukraine-beat-Vladimir-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917497/Itll-fantastic-British-Challenger-2-tanks-Ukraine-beat-Vladimir-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:36:17+00:00

The first of 14 Challenger 2 tanks (pictured in Ukraine) supplied by Britain have arrived in Ukraine: part of the West's colossal commitment to defeat the Russian invasion.

## Texas House approves bill to remove sales tax from female hygiene products
 - [https://www.dailymail.co.uk/news/article-11917101/Texas-House-approves-bill-remove-sales-tax-female-hygiene-products.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917101/Texas-House-approves-bill-remove-sales-tax-female-hygiene-products.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:30:31+00:00

The Texas House of Representatives voted 145 to 2 during the vote on Wednesday, which would also exempt maternity clothes, breast pumps and diapers.

## Pepsi's nostalgic new logo is inspired by 90s glory days when cans cost just 50 cents
 - [https://www.dailymail.co.uk/news/article-11916891/Pepsis-nostalgic-new-logo-inspired-90s-glory-days-cans-cost-just-50-cents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916891/Pepsis-nostalgic-new-logo-inspired-90s-glory-days-cans-cost-just-50-cents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:30:08+00:00

Unveiled on Tuesday, the company's new emblem looks a great deal like the one it sported in the 90s -  still fresh in minds of millions thanks to ads featuring stars such as Cindy Crawford

## Iowa teen flips on classmate and agrees to testify against him at murder trial
 - [https://www.dailymail.co.uk/news/article-11917197/Iowa-teen-flips-classmate-agrees-testify-against-murder-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917197/Iowa-teen-flips-classmate-agrees-testify-against-murder-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:28:18+00:00

Murder suspect Jeremy Goodale has reached a deal with prosecutors and intends to testify against classmate Willard Miller, prosecutors said at a hearing on Wednesday in Iowa.

## Coffee shop mural critiqued for being 'too violent' for SoCal city with history of gang violence
 - [https://www.dailymail.co.uk/news/article-11916925/Coffee-shop-mural-critiqued-violent-SoCal-city-history-gang-violence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916925/Coffee-shop-mural-critiqued-violent-SoCal-city-history-gang-violence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:16:47+00:00

Residents of one SoCal neighborhood are up in arms over a 'violent' new mural outside a coffee shop that depicts black figures seemingly fighting and stabbing each other.

## Fuel duty tax could rise 'sharply' next year to help balance the books, Chancellor warns
 - [https://www.dailymail.co.uk/news/article-11917407/Fuel-duty-tax-rise-sharply-year-help-balance-books-Chancellor-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917407/Fuel-duty-tax-rise-sharply-year-help-balance-books-Chancellor-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:15:14+00:00

Jeremy Hunt (pictured today) said the state of the UK's finances meant a freeze in fuel duty since 2011 could not be extended indefinitely.

## Could AI destroy humanity? Experts warn of 'catastrophic consequences'
 - [https://www.dailymail.co.uk/news/article-11917259/Could-AI-destroy-humanity-Experts-warn-catastrophic-consequences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917259/Could-AI-destroy-humanity-Experts-warn-catastrophic-consequences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:05:25+00:00

If machines are allowed to become more intelligent, and so more powerful, than humans, the fundamental question of who will be in control - us or them? - should keep us all awake at night.

## Girl, 11, abducted from Dollar General near Pittsburgh is found thanks to iPad location
 - [https://www.dailymail.co.uk/news/article-11917211/Girl-11-abducted-Dollar-General-near-Pittsburgh-thanks-iPad-location.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917211/Girl-11-abducted-Dollar-General-near-Pittsburgh-thanks-iPad-location.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 21:03:05+00:00

Self-proclaimed born-again Christian Keith Lilliock, 43, was arrested for luring the 11-year-old girl into his car after targeting her inside a Dollar General in Pennsylvania.

## Woman who joined conservative dating site reveals she sent January 6 rioters' details to FBI
 - [https://www.dailymail.co.uk/news/article-11917043/Woman-joined-conservative-dating-site-reveals-sent-January-6-rioters-details-FBI.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917043/Woman-joined-conservative-dating-site-reveals-sent-January-6-rioters-details-FBI.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 20:46:12+00:00

A woman is claiming she was able to infiltrate a conservative-leaning dating app and ended up reporting several profiles to the FBI for saying they'd participated in the January 6 riots.

## Emily Ratajkowski's estranged husband is accused of sexual misconduct by multiple women
 - [https://www.dailymail.co.uk/news/article-11917265/Emily-Ratajkowskis-estranged-husband-accused-sexual-misconduct-multiple-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917265/Emily-Ratajkowskis-estranged-husband-accused-sexual-misconduct-multiple-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 20:43:53+00:00

Sebastian Bear-McClard, 42, allegedly reached out to the 17-year-old on Instagram in 2016 before meeting her at a Soho loft.

## Hilarious moment woman is caught on camera digging underneath Alex Murdaugh's sofa
 - [https://www.dailymail.co.uk/news/article-11916929/Hilarious-moment-woman-caught-camera-digging-underneath-Alex-Murdaughs-sofa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916929/Hilarious-moment-woman-caught-camera-digging-underneath-Alex-Murdaughs-sofa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 20:41:44+00:00

A curious consumer was seen digging around the brown leather cushions of a furniture set being sold among convicted killer Alex Murdaugh's possessions.

## Retired doctor suing Paltrow over ski crash dumps smiley-face tie as he prepares to take the stand
 - [https://www.dailymail.co.uk/news/article-11917109/Retired-doctor-suing-Paltrow-ski-crash-dumps-smiley-face-tie-prepares-stand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917109/Retired-doctor-suing-Paltrow-ski-crash-dumps-smiley-face-tie-prepares-stand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 20:41:20+00:00

Terry Sanderson, 76, who is suing Gwyneth Paltrow over a ski crash, arrived at the Park City courtroom on Wednesday wearing a brightly-colored tie with garish smiley faces on it, but later changed it.

## Alec Baldwin is slammed for reposting Peter Frampton's gun control message
 - [https://www.dailymail.co.uk/news/article-11917027/Alec-Baldwin-slammed-reposting-Peter-Framptons-gun-control-message.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917027/Alec-Baldwin-slammed-reposting-Peter-Framptons-gun-control-message.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 20:40:00+00:00

Alec Baldwin has been criticized on social media after reposting a message about gun control - after his own fatal shooting on the set of movie Rust.

## King Charles says 'it's very sad' that his state visit to France was cancelled amid pension riots
 - [https://www.dailymail.co.uk/news/article-11916445/King-Charles-says-sad-state-visit-France-cancelled-amid-pension-riots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916445/King-Charles-says-sad-state-visit-France-cancelled-amid-pension-riots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 20:38:31+00:00

King Charles today spoke for the first time about cancelling plans to make his first ever State Visit to France, as he began a three-day official visit to neighbouring Germany.

## John Fetterman to return to the Senate week of April 17
 - [https://www.dailymail.co.uk/news/article-11917281/John-Fetterman-return-Senate-week-April-17.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917281/John-Fetterman-return-Senate-week-April-17.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 20:34:18+00:00

Senator John Fetterman will return to the Senate next month after more than a month of inpatient treatment for depression at Walter Reed hospital, according to a new report on Wednesday.

## Chicago cops say sniffer dogs showed interest in harbor area in hunt for missing Navy sailor
 - [https://www.dailymail.co.uk/news/article-11917079/Chicago-cops-say-sniffer-dogs-showed-harbor-area-hunt-missing-Navy-sailor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917079/Chicago-cops-say-sniffer-dogs-showed-harbor-area-hunt-missing-Navy-sailor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 20:31:35+00:00

Police dogs helping the search for a missing Navy sailor in Illinois indicated an 'area of interest' at a harbor where he was last seen.

## LA reveals list of 33 buildings that are AT RISK from earthquakes that desperately need updates
 - [https://www.dailymail.co.uk/news/article-11916869/LA-reveals-list-33-buildings-RISK-earthquakes-desperately-need-updates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916869/LA-reveals-list-33-buildings-RISK-earthquakes-desperately-need-updates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 19:59:23+00:00

The list revealed which buildings made from non-ductile concrete may cause massive problems in a quake - and the majority house critical services that would be needed in an emergency.

## Man whose $190M bid won auction of New York's Flatiron Building has failed to make down payment
 - [https://www.dailymail.co.uk/news/article-11916739/Man-190M-bid-won-auction-New-Yorks-Flatiron-Building-failed-make-payment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916739/Man-190M-bid-won-auction-New-Yorks-Flatiron-Building-failed-make-payment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 19:46:57+00:00

The man who won ownership of the iconic Flatiron Building in NYC with a $190M bid now may have immediately lost the rights to it after failing to make the first $19M down payment.

## Connecticut priest chokes back tears as he claims a parishioner witnessed a MIRACLE
 - [https://www.dailymail.co.uk/news/article-11916765/Connecticut-priest-chokes-tears-claims-parishioner-witnessed-MIRACLE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916765/Connecticut-priest-chokes-tears-claims-parishioner-witnessed-MIRACLE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 19:46:08+00:00

The Reverend Joseph Crowley announced that a parishioner had witnessed the divine happening on March 5.

## Santa Fe DA who charged Alec Baldwin over Rust shooting STEPS DOWN from the case
 - [https://www.dailymail.co.uk/news/article-11917041/Santa-Fe-DA-charged-Alec-Baldwin-Rust-shooting-STEPS-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11917041/Santa-Fe-DA-charged-Alec-Baldwin-Rust-shooting-STEPS-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 19:43:31+00:00

First Judicial District Attorney Mary Carmack-Altwies announced today that she would be replaced by two special prosecutors. They will become the third and fourth on the case.

## Bernie Sanders denies he is worth $8M in fiery exchange with Republican senator
 - [https://www.dailymail.co.uk/news/article-11916741/Bernie-Sanders-denies-worth-8M-fiery-exchange-Republican-senator.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916741/Bernie-Sanders-denies-worth-8M-fiery-exchange-Republican-senator.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 19:33:12+00:00

The hearing was meant to focus on Starbucks and allegations that it illegally fired pro-union baristas or spied on workers during a labor mobilization push but degenerated into mud slinging.

## Watch moment thugs high-five each other after vicious attack as sick are jailed for 21 years each
 - [https://www.dailymail.co.uk/news/article-11916279/Watch-moment-thugs-high-five-vicious-attack-sick-jailed-21-years-each.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916279/Watch-moment-thugs-high-five-vicious-attack-sick-jailed-21-years-each.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 19:05:42+00:00

Jamie Elston, 32, (bottom right) and David Ratcliffe, 33, (top right) were caught on CCTV high-fiving and hugging each other after forcing their way into a property on Razia Court in Workington, Cumbria.

## Woke George Washington University stands by psychology professor accused of antisemitism
 - [https://www.dailymail.co.uk/news/article-11916633/Woke-George-Washington-University-stands-psychology-professor-accused-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916633/Woke-George-Washington-University-stands-psychology-professor-accused-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:54:34+00:00

Professor Lara Sheehi was accused of antisemitic behavior in her diversity class. George Washington University hired an outside law firm to conduct a probe.

## Archewell tax filings show Harry and Meghan worked one hour a week in 2021
 - [https://www.dailymail.co.uk/news/article-11916253/Archewell-tax-filings-Harry-Meghan-worked-one-hour-week-2021.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916253/Archewell-tax-filings-Harry-Meghan-worked-one-hour-week-2021.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:48:27+00:00

Tax filings for 2021 reveal Prince Harry and Meghan Markle only worked one hour a week at Archewell - which was almost entirely funded by a combined $13m donation from two wealthy donors.

## Moment Hawaii cops arrested Flash star Ezra Miller for assault
 - [https://www.dailymail.co.uk/news/article-11916557/Moment-Hawaii-cops-arrested-Flash-star-Ezra-Miller-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916557/Moment-Hawaii-cops-arrested-Flash-star-Ezra-Miller-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:47:48+00:00

This is the moment Ezra Miller appeared to slur their words as they were arrested for allegedly throwing a chair at a woman's head in Hawaii.

## US Treasury reveals it received a $7BILLION tax payment in 'estate and gift' receipts
 - [https://www.dailymail.co.uk/news/article-11916039/US-Treasury-reveals-received-7BILLION-tax-payment-estate-gift-receipts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916039/US-Treasury-reveals-received-7BILLION-tax-payment-estate-gift-receipts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:46:51+00:00

The Treasury Department reported it received $7billion in 'estate and gift' taxes on February 28, 2023. With that kind of money, the contributor would have been one of the world's richest.

## California reparations taskforce member is slammed as he Zooms in from Kamala's tour of Ghana
 - [https://www.dailymail.co.uk/news/article-11916819/California-reparations-taskforce-member-slammed-Zooms-Kamalas-tour-Ghana.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916819/California-reparations-taskforce-member-slammed-Zooms-Kamalas-tour-Ghana.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:46:07+00:00

A senior member of both the California and San Francisco reparation taskforces was accused of 'lining up his retirement fund' after he failed to attend a key meeting because he is in Ghana.

## 'What about our rights?' Fury in Braintree over plans to house thousands of migrants in barracks
 - [https://www.dailymail.co.uk/news/article-11916449/What-rights-Fury-Braintree-plans-house-thousands-migrants-barracks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916449/What-rights-Fury-Braintree-plans-house-thousands-migrants-barracks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:44:55+00:00

People living in the Essex town hit out at plans to put asylum seekers in former RAF Wethersfield - leaving some angry locals decrying 'what about our rights?'

## African grey parrot stolen from Santa Ana porch reunited with owners after two weeks
 - [https://www.dailymail.co.uk/news/article-11916517/African-grey-parrot-stolen-Santa-Ana-porch-reunited-owners-two-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916517/African-grey-parrot-stolen-Santa-Ana-porch-reunited-owners-two-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:43:14+00:00

A California parrot worth $2,500 was reunited with its family more than two weeks after brazen thieves were caught on video stealing the bird off a porch.

## King and Queen arrive for glittering State Banquet at Berlin's Bellevue Palace hosted by President
 - [https://www.dailymail.co.uk/news/article-11916857/King-Queen-arrive-glittering-State-Banquet-Berlins-Bellevue-Palace-hosted-President.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916857/King-Queen-arrive-glittering-State-Banquet-Berlins-Bellevue-Palace-hosted-President.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:39:27+00:00

The King and Queen Consort have been welcomed at a glittering state banquet in Berlin to mark their first official visit to Germany.

## Arizona governor's press secretary resigns after tweet about shooting transphobes
 - [https://www.dailymail.co.uk/news/article-11916957/Arizona-governors-press-secretary-resigns-tweet-shooting-transphobes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916957/Arizona-governors-press-secretary-resigns-tweet-shooting-transphobes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:33:05+00:00

Hobbs' office on Wednesday confirmed the resignation of Josselyn Berry, who had uploaded an image of a woman holding two handguns, captioned 'Us when we see transphobes.'

## 'Woke' barristers could be struck off after saying they will not prosecute climate change protesters
 - [https://www.dailymail.co.uk/news/article-11916727/Woke-barristers-struck-saying-not-prosecute-climate-change-protesters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916727/Woke-barristers-struck-saying-not-prosecute-climate-change-protesters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:32:40+00:00

The Lawyers are Responsible group comprises some 120 barristers and solicitors, including Jolyon Maugham (left), say they will object to prosecuting eco-groups like Just Stop Oil.

## Pence says he has 'nothing to hide,' but stays undecided on January 6 testimony
 - [https://www.dailymail.co.uk/news/article-11915943/Pence-says-hide-stays-undecided-January-6-testimony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915943/Pence-says-hide-stays-undecided-January-6-testimony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:31:51+00:00

Former Vice President Mike Pence said Wednesday that he's yet to make a decision on whether to testify in special counsel Jack Smith's investigation into January 6.

## Biden, 80, apologizes for having another cold
 - [https://www.dailymail.co.uk/news/article-11916545/Biden-80-apologizes-having-cold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916545/Biden-80-apologizes-having-cold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:17:47+00:00

President Joe Biden  apologized for having a cold as he addressed world leaders, including President Volodymyr Zelensky, during his second annual Summit for Democracy.

## Man arrested and 17 animals seized by police after girl, 6, in hospital after Manchester dog attack
 - [https://www.dailymail.co.uk/news/article-11916817/Man-arrested-17-animals-seized-police-girl-6-hospital-Manchester-dog-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916817/Man-arrested-17-animals-seized-police-girl-6-hospital-Manchester-dog-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 18:00:34+00:00

A 36-year-old man was detained today on suspicion of offences under Section 3 of the Dangerous Dogs Act 1991 relating to Sunday's incident in Greater Manchester.

## Plane passenger abused his own family and assaulted three officers after downing nearly litre of rum
 - [https://www.dailymail.co.uk/news/article-11916833/Plane-passenger-abused-family-assaulted-three-officers-downing-nearly-litre-rum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916833/Plane-passenger-abused-family-assaulted-three-officers-downing-nearly-litre-rum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:53:43+00:00

Edgars Emsins, 36, became so rowdy that he had to be restrained from other passengers on his flight from Tenerife to the UK on March 14. He bought a 750ml bottle of Captain Morgan's.

## Judge in Mail case warns Prince Harry over private detective
 - [https://www.dailymail.co.uk/news/article-11916173/Judge-Mail-case-warns-Prince-Harry-private-detective.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916173/Judge-Mail-case-warns-Prince-Harry-private-detective.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:44:59+00:00

A judge warned Prince Harry and others 'may have to adjust their expectations' of a private detective who has rebutted claims that he 'confessed' to hacking them for Associated Newspapers.

## Florida principal resigns after sending $100,000 in school funds to scammer posing as Elon Musk
 - [https://www.dailymail.co.uk/news/article-11916447/Florida-principal-resigns-sending-100-000-school-funds-scammer-posing-Elon-Musk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916447/Florida-principal-resigns-sending-100-000-school-funds-scammer-posing-Elon-Musk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:44:47+00:00

Long the principal of Burns Science and Technology in rural Central Florida, Jan McGee has since been subject to a storm of backlash - despite school staffers cancelling it before it went through.

## Dog thrown out of moving car and has spent 660 days in SC shelter still looking for forever home
 - [https://www.dailymail.co.uk/news/article-11916347/Dog-thrown-moving-car-spent-660-days-SC-shelter-looking-forever-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916347/Dog-thrown-moving-car-spent-660-days-SC-shelter-looking-forever-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:42:19+00:00

Perez has been waiting at a South Carolina Shelter for more than 660 days waiting for a forever home.

## Controversial group behind 'Trans Day of Vengeance' raised money for firearms training
 - [https://www.dailymail.co.uk/news/article-11915513/Controversial-group-Trans-Day-Vengeance-raised-money-firearms-training.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915513/Controversial-group-Trans-Day-Vengeance-raised-money-firearms-training.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:41:09+00:00

Despite rising political tensions across the country the Trans Radical Activist Network (TRAN) is pushing forward with their protest on Saturday in DC.

## Britain poised to join major trade bloc as UK's membership of CPTPP 'set to be approved TOMORROW'
 - [https://www.dailymail.co.uk/news/article-11916767/Britain-poised-join-major-trade-bloc-UKs-membership-CPTPP-set-approved-TOMORROW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916767/Britain-poised-join-major-trade-bloc-UKs-membership-CPTPP-set-approved-TOMORROW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:38:24+00:00

Negotiations between Britain and existing members of the CPTPP have been taking place since September 2021.

## Netanyahu rejects Biden's suggestion that he 'walk away' from judicial overhaul
 - [https://www.dailymail.co.uk/news/article-11916473/Netanyahu-rejects-Bidens-suggestion-walk-away-judicial-overhaul.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916473/Netanyahu-rejects-Bidens-suggestion-walk-away-judicial-overhaul.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:28:11+00:00

Israeli Prime Minister Benjamin Netanyahu issued a pointed tweet on standing up to 'pressures from abroad' after President Joe Biden called for him to step back from a judicial overhaul.

## Brutally hazed Georgia teen was attacked twice before 'by same boys,' says dad
 - [https://www.dailymail.co.uk/news/article-11912841/Brutally-hazed-Georgia-teen-attacked-twice-boys-says-dad.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11912841/Brutally-hazed-Georgia-teen-attacked-twice-boys-says-dad.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:16:37+00:00

Trenton Lehrkamp, 19, of Brunswick, Georgia was allegedly tortured and humiliated by the same group of teens at least twice earlier, before being hospitalized in the ICU last Tuesday, his dad revealed.

## Triple killer told police he watched Die Hard as he murdered his daughter
 - [https://www.dailymail.co.uk/news/article-11915761/Triple-killer-told-police-watched-Die-Hard-murdered-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915761/Triple-killer-told-police-watched-Die-Hard-murdered-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:16:28+00:00

New police CCTV footage from interviews of triple killer Jordan Monaghan shows him admitting he watched Die Hard before smothering his daughter in their Blackburn home on New Years day in 2013.

## Outrage from locals as visitors to Camber Sands will be charged £30 to park at beach this summer
 - [https://www.dailymail.co.uk/news/article-11916199/Outrage-locals-visitors-Camber-Sands-charged-30-park-beach-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916199/Outrage-locals-visitors-Camber-Sands-charged-30-park-beach-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 17:11:14+00:00

Rother District Council's cabinet agreed the new fees for Camber Sands Central car park on Monday, also adding that drivers arriving after 3pm will pay a reduced rate of £15.

## Trump grand jury to take a planned month-long 'hiatus'
 - [https://www.dailymail.co.uk/news/article-11916411/Manhattan-Trump-grand-jury-set-break-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916411/Manhattan-Trump-grand-jury-set-break-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:46:38+00:00

The Manhattan grand jury isn't expected to hear evidence in the case for the next month due to a previously scheduled hiatus, according to a person familiar with the proceedings.

## Mother relives moment when she was flung into the air when she was hit by Camaro sports car
 - [https://www.dailymail.co.uk/news/article-11916591/Mother-relives-moment-flung-air-hit-Camaro-sports-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916591/Mother-relives-moment-flung-air-hit-Camaro-sports-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:45:49+00:00

The woman, who has asked not be identified, was thrown into the air when struck by the Chevrolet Camaro sports car and lay motionless as the driver's passengers callously walked away.

## Drag queen performs lap dance on teen and gyrates in front of cheering children
 - [https://www.dailymail.co.uk/news/article-11916303/Drag-queen-performs-lap-dance-teen-gyrates-cheering-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916303/Drag-queen-performs-lap-dance-teen-gyrates-cheering-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:45:15+00:00

The drag queen, identified as Erica Chanel, was seen dancing on top of the student at Forsyth Technical Community College, which is a public school located in Winston-Salem, North Carolina.

## Fears for Russian girl, 13, taken away from her father for drawing an anti-war sketch
 - [https://www.dailymail.co.uk/news/article-11916345/Fears-Russian-girl-13-taken-away-father-drawing-anti-war-sketch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916345/Fears-Russian-girl-13-taken-away-father-drawing-anti-war-sketch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:44:32+00:00

Fears are growing for a Russian girl who was taken away from her father after she drew an anti-war picture, with the single dad now missing after fleeing house arrest under Vladimir Putin's regime.

## Iger's revenge: Disney fires Marvel Entertainment chairman Perlmutter
 - [https://www.dailymail.co.uk/news/article-11916493/Igers-revenge-Disney-fires-Marvel-Entertainment-chairman-Perlmutter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916493/Igers-revenge-Disney-fires-Marvel-Entertainment-chairman-Perlmutter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:42:57+00:00

Perlmutter, 80, had long feuded with Disney CEO Bob Iger, repeatedly backing activist investor Nelson Peltz's failed bid to join the company's board as part of a campaign to slash costs.

## Traveler tracks his stolen luggage containing using Apple AirTag
 - [https://www.dailymail.co.uk/news/article-11916035/Traveler-tracks-stolen-luggage-containing-using-Apple-AirTag.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916035/Traveler-tracks-stolen-luggage-containing-using-Apple-AirTag.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:38:32+00:00

Jameel Reid used a $29 Apple AirTag to recover $3000 worth of belongings. Reid's bag was stolen from the baggage claim at Atlanta International Airport.

## Nashville school shooter Audrey Hale would dress as trans star Elliot Page
 - [https://www.dailymail.co.uk/news/article-11912531/Nashville-school-shooter-Audrey-Hale-dress-trans-star-Elliot-Page.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11912531/Nashville-school-shooter-Audrey-Hale-dress-trans-star-Elliot-Page.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:36:30+00:00

A school friend of Hale has now revealed that she loved to dress up as Page's iconic character Juno during their time at The Nashville School of Arts.

## Ministers 'back off speeding up rise in pension age to 68'
 - [https://www.dailymail.co.uk/news/article-11916481/Ministers-speeding-rise-pension-age-68.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916481/Ministers-speeding-rise-pension-age-68.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:36:26+00:00

There has been growing speculation that the retirement age could be pushed up to 68 sooner than previously planned.

## Millionaire tech investor accused of sexual assault has prior conviction, trial hears
 - [https://www.dailymail.co.uk/news/article-11916149/Millionaire-tech-investor-accused-sexual-assault-prior-conviction-trial-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916149/Millionaire-tech-investor-accused-sexual-assault-prior-conviction-trial-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:34:32+00:00

Stefan Glanzer, 61, was convicted of sexually assaulting a 30-year-old passenger on a Tube train nearly 11 years ago. He is currently on trial for allegedly assaulting a woman at work in 2021.

## Rare pink diamond considered to be the 'most valuable' of its kind is expected to fetch over $35M
 - [https://www.dailymail.co.uk/news/article-11916027/Rare-pink-diamond-considered-valuable-kind-expected-fetch-35M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916027/Rare-pink-diamond-considered-valuable-kind-expected-fetch-35M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:32:31+00:00

Sotheby's in New York claims a pink diamond of 'unparalleled color and brightness' that may be the most significant of its type may sell at auction for over $35million when it goes up for bids in June.

## Succession super house: Tech tycoon, 28, who owns $83million mansion with 18 bathrooms
 - [https://www.dailymail.co.uk/news/article-11914881/Succession-super-house-Tech-tycoon-28-owns-83million-mansion-18-bathrooms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914881/Succession-super-house-Tech-tycoon-28-owns-83million-mansion-18-bathrooms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:31:56+00:00

One of the incredible homes used as a set for the HBO show is owned by a real-life mogul - 28-year-old Alex Russell who became a billionaire virtually overnight in December 2020.

## California reparations taskforce increases amount it is demanding to $800BN from $640BN
 - [https://www.dailymail.co.uk/news/article-11916145/California-reparations-taskforce-increases-demanding-800BN-640BN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916145/California-reparations-taskforce-increases-demanding-800BN-640BN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:29:01+00:00

Black Californians are owed $800 billion for reparations due to generations of over-policing, disproportionate incarceration and housing discrimination, according to economists.

## Ridiculous moment bungling arsonist sets fire to HIMSELF as he tries to torch parked car
 - [https://www.dailymail.co.uk/news/article-11916059/Ridiculous-moment-bungling-arsonist-sets-fire-tries-torch-parked-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916059/Ridiculous-moment-bungling-arsonist-sets-fire-tries-torch-parked-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:28:32+00:00

In the footage recorded in Bradford, a man is seen dousing the vehicle in petrol from a plastic jerry can when it suddenly bursts into flames, setting his trousers on fire.

## Cage cashier, 44, is arrested over $500,000 Monarch casino heist after being caught on CCTV
 - [https://www.dailymail.co.uk/news/article-11915691/Cage-cashier-44-arrested-500-000-Monarch-casino-heist-caught-CCTV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915691/Cage-cashier-44-arrested-500-000-Monarch-casino-heist-caught-CCTV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:27:49+00:00

Sabrina Eddy, 44, was jailed on suspicion of theft for the incident that took place on March 12 at Casino Resort and Spa in in Black Hawk, 34 miles west of Denver.

## First Minister Humza Yousaf poses with first cabinet made up of loyal supporters amid SNP civil war
 - [https://www.dailymail.co.uk/news/article-11916475/First-Minister-Humza-Yousaf-poses-cabinet-loyal-supporters-amid-SNP-civil-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916475/First-Minister-Humza-Yousaf-poses-cabinet-loyal-supporters-amid-SNP-civil-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 16:04:59+00:00

Mr Yousaf unveiled the country's first executive with a female majority after taking the oath to the King at the Court of Session in Edinburgh. But it was the absent faces that told the story of his ascent.

## Boy, 13, accidentally hanged himself in his bedroom while copying Snapchat video, inquest hears
 - [https://www.dailymail.co.uk/news/article-11916169/Boy-13-accidentally-hanged-bedroom-copying-Snapchat-video-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916169/Boy-13-accidentally-hanged-bedroom-copying-Snapchat-video-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:58:30+00:00

A schoolboy from Southsea hanged himself by accident after copying a Snapchat video he filmed of a friend with a ligature around his neck, an inquest was told.

## Mother told police 'I failed her' after boyfriend murdered her two-year-old daughter, court hears
 - [https://www.dailymail.co.uk/news/article-11916235/Mother-told-police-failed-boyfriend-murdered-two-year-old-daughter-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916235/Mother-told-police-failed-boyfriend-murdered-two-year-old-daughter-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:54:55+00:00

Sinead James, 30, (inset) sobbed as she told a jury she never thought her partner Kyle Bevan, 31, (right) would kill her daughter Lola James (left).

## Pensioner, 76, attacked by neighbour's out-of-control Staffordshire bull terrier
 - [https://www.dailymail.co.uk/news/article-11916243/Pensioner-76-attacked-neighbours-control-Staffordshire-bull-terrier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916243/Pensioner-76-attacked-neighbours-control-Staffordshire-bull-terrier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:45:38+00:00

Jacqueline McGrew, 76, suffered bite injuries across her body after she was attacked from behind by the dog in the garden of her neighbour's property in Blackburn, Lancashire, in June 14 last year.

## Thug beat ex-girlfriend's six-month-old cat so hard with mop handle it died from injuries
 - [https://www.dailymail.co.uk/news/article-11916175/Thug-beat-ex-girlfriends-six-month-old-cat-hard-mop-handle-died-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916175/Thug-beat-ex-girlfriends-six-month-old-cat-hard-mop-handle-died-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:43:12+00:00

WARNING: DISTRESSING IMAGES Sajad Hussain, 51, deliberately hit the moggy, known as Kia, while she was lying on a bed at his ex-girlfriend's flat in Darwen, Lancs.

## Dad stabbed to death in front of daughter and fiancée after asking attacker not to vape near toddler
 - [https://www.dailymail.co.uk/news/article-11916261/Dad-stabbed-death-daughter-fianc-e-asking-attacker-not-vape-near-toddler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916261/Dad-stabbed-death-daughter-fianc-e-asking-attacker-not-vape-near-toddler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:41:49+00:00

Paul Stanley Smith was standing outside with his daughter while his fiancée bought drinks at a Vancouver Starbucks when he was attacked by a man he asked not to vape near them.

## Twitter suspends sick 'killer cop' page that puts bounties on officers next to their pictures
 - [https://www.dailymail.co.uk/news/article-11915739/Twitter-suspends-sick-killer-cop-page-puts-bounties-officers-pictures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915739/Twitter-suspends-sick-killer-cop-page-puts-bounties-officers-pictures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:37:52+00:00

The Los Angeles Police Protective League is taking legal action against the owner of killercop.com claiming bounties were placed on cops after their headshots and personal information was released.

## Which countries have banned TikTok and why? UK, US and EU laws explained
 - [https://www.dailymail.co.uk/news/article-11915755/Which-countries-banned-TikTok-UK-EU-laws.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915755/Which-countries-banned-TikTok-UK-EU-laws.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:36:50+00:00

Despite the popularity of TikTok, countries have moved to ban the app on government-issued devices, with some governments blocking access to the app altogether.

## Gwyneth Paltrow's lawyers to grill retired doctor after he claimed she 'recklessly' plowed into him
 - [https://www.dailymail.co.uk/news/article-11916155/Gwyneth-Paltrows-lawyers-grill-retired-doctor-claimed-recklessly-plowed-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916155/Gwyneth-Paltrows-lawyers-grill-retired-doctor-claimed-recklessly-plowed-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:36:49+00:00

Gwyneth Paltrow, 50, and retired optometrist Terry Sanderson, 76, have been battling it out in court in Park City, Utah, for over a week - with both giving different versions of what happened.

## Greenpeace activists in swimming trunks queue outside PM's home in protest against national grid
 - [https://www.dailymail.co.uk/news/article-11915773/Greenpeace-activists-swimming-trunks-queue-outside-PMs-home-protest-against-national-grid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915773/Greenpeace-activists-swimming-trunks-queue-outside-PMs-home-protest-against-national-grid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:35:00+00:00

Greenpeace activists were seen demonstrating outside Rishi Sunak's Grade-II home in Richmond, North Yorkshire today ahead of the Government's 'Energy Security Day'.

## What next for Adnan Syed in Hae Min Lee murder case?
 - [https://www.dailymail.co.uk/news/article-11915793/What-Adnan-Syed-Hae-Min-Lee-murder-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915793/What-Adnan-Syed-Hae-Min-Lee-murder-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:27:32+00:00

Adnan Syed - the man who spent 23 years in jail for murdering his high school sweetheart before prosecutors admitted he might not be the killer - has had his conviction reinstated.

## Julian Knight MP says police have CLEARED him of 'malicious' allegation
 - [https://www.dailymail.co.uk/news/article-11916083/Julian-Knight-MP-says-police-CLEARED-malicious-allegation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916083/Julian-Knight-MP-says-police-CLEARED-malicious-allegation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:23:56+00:00

Commons Culture Committee chair Julian Knight said his name had been 'dragged through the mud' by the claim - details of which have not been revealed.

## SNP leader Humza Yousaf, the ex-health secretary, mocked after appointing 'NHS Recovery' minister
 - [https://www.dailymail.co.uk/news/article-11916259/SNP-leader-Humza-Yousaf-ex-health-secretary-mocked-appointing-NHS-Recovery-minister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916259/SNP-leader-Humza-Yousaf-ex-health-secretary-mocked-appointing-NHS-Recovery-minister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:23:22+00:00

Humza Yousaf this afternoon named Michael Matheson as his Cabinet Secretary for NHS Recovery, Health and Social Care.

## Grieving mother calls for change in law so killer cyclists face tougher punishments after son died
 - [https://www.dailymail.co.uk/news/article-11915675/Grieving-mother-calls-change-law-killer-cyclists-face-tougher-punishments-son-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915675/Grieving-mother-calls-change-law-killer-cyclists-face-tougher-punishments-son-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:22:08+00:00

23-year-old motorcyclist Callum Clements collided with cyclist after it failed to stop at crossroads and died when  thrown from his machine in Poole, Dorset.

## Church warden, 86, died of her wounds after she was attacked in house burglary
 - [https://www.dailymail.co.uk/news/article-11916007/Church-warden-86-died-wounds-attacked-house-burglary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11916007/Church-warden-86-died-wounds-attacked-house-burglary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:16:32+00:00

The victim, named locally as Beryl Purdy , was found following reports of a burglary at her country home where she lived with her invalid husband. Villagers felt 'anger and disgust' at her death.

## BBC faces backlash among Radio 2 listeners over Paul O'Grady tribute
 - [https://www.dailymail.co.uk/news/article-11915803/BBC-faces-backlash-Radio-2-listeners-Paul-OGrady-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915803/BBC-faces-backlash-Radio-2-listeners-Paul-OGrady-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 15:16:10+00:00

Paul O'Grady left his Sunday afternoon slot on Radio 2 in August last year after almost 14 years, following a schedule shake-up which saw him regularly swapping with Rob Beckett.

## Millionaire sues West End bookies for not protecting him from his gambling addiction
 - [https://www.dailymail.co.uk/news/article-11915901/Millionaire-sues-West-End-bookies-not-protecting-gambling-addiction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915901/Millionaire-sues-West-End-bookies-not-protecting-gambling-addiction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:54:01+00:00

Businessman Scott O'Brien claims he spent over £400,000 at Star Sports' flagship shop in Mayfair (right) between September 2018 and March 2019.

## Credit Suisse whistleblowers accuse bank of helping ultra-rich Americans evade taxes
 - [https://www.dailymail.co.uk/news/article-11915721/Credit-Suisse-whistleblowers-accuse-bank-helping-ultra-rich-Americans-evade-taxes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915721/Credit-Suisse-whistleblowers-accuse-bank-helping-ultra-rich-Americans-evade-taxes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:53:20+00:00

The US Senate Finance Committee made the claims in a report on Wednesday, after concluding a two-year investigation into Credit Suisse with the assistance of multiple whistleblowers.

## Will Adnan Syed go back to jail?
 - [https://www.dailymail.co.uk/news/article-11915793/Will-Adnan-Syed-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915793/Will-Adnan-Syed-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:43:27+00:00

Adnan Syed - the man who spent 23 years in jail for murdering his high school sweetheart before prosecutors admitted he might not be the killer - has had his conviction reinstated.

## Jeremy Renner says he'd get crushed by snowplow again to save his nephew
 - [https://www.dailymail.co.uk/news/article-11915847/Jeremy-Renner-says-hed-throw-snowplow-save-nephew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915847/Jeremy-Renner-says-hed-throw-snowplow-save-nephew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:43:10+00:00

Renner suffered 30 broken bones, a collapsed lung and had his liver pierced by a shattered rib in the horrific, death-defying accident on New Year's Day.

## Mother fears she will never see her son again after he vanished in Portugal with estranged father
 - [https://www.dailymail.co.uk/news/article-11915933/Mother-fears-never-son-vanished-Portugal-estranged-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915933/Mother-fears-never-son-vanished-Portugal-estranged-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:42:16+00:00

Rebecca Jones, 35, said her oldest boy Jayden (pictured), 13, was meant to return with Andrew Pearson, 33, following a ten-day trip to the Algarve last September.

## Scandal-hit Hunter makes video of him working on art with voiceover of quotes from Morgan Freeman
 - [https://www.dailymail.co.uk/news/article-11915525/Hunter-seen-working-art-garage-VO-inspirational-quotes-Morgan-Freeman-movie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915525/Hunter-seen-working-art-garage-VO-inspirational-quotes-Morgan-Freeman-movie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:35:07+00:00

Hunter Biden continues to distract from the investigations into his finances by pursuing his painting career, as a recent Instagram video showed him attempting to get artistic inspiration.

## Senate teeing up bipartisan vote to repeal Iraq war powers
 - [https://www.dailymail.co.uk/news/article-11915799/Senate-teeing-bipartisan-vote-repeal-Iraq-war-powers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915799/Senate-teeing-bipartisan-vote-repeal-Iraq-war-powers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:33:56+00:00

The bill would repeal the authorization for the use of military force, or AUMF, that dates back to 1991 during the Gulf War under President George H.W. Bush and the 2002 AUMF for the invasion in Iraq.

## Warehouse worker paid impersonator £800 to take his driving theory test after failing it 14 times
 - [https://www.dailymail.co.uk/news/article-11915541/Warehouse-worker-paid-impersonator-800-driving-theory-test-failing-14-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915541/Warehouse-worker-paid-impersonator-800-driving-theory-test-failing-14-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:33:44+00:00

Mohammad Shoaib, 38, of Luton, was sentenced to a 12 month community order. He will be subjected to a tagged curfew from 10am to 5pm starting tomorrow for one month.

## Is Bryan Kohberger's trial in jeopardy? Officer is implicated in 'internal affairs' probe
 - [https://www.dailymail.co.uk/news/article-11915565/Is-Bryan-Kohbergers-trial-jeopardy-Officer-implicated-internal-affairs-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915565/Is-Bryan-Kohbergers-trial-jeopardy-Officer-implicated-internal-affairs-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:30:02+00:00

Prosecutors have disclosed that a police officer involved in Bryan Kohberger's case is the subject of an 'internal affairs' probe that could affect the Idaho murders suspect's upcoming trial.

## Number of mortgages approved goes up for first time since mini-Budget chaos
 - [https://www.dailymail.co.uk/money/mortgageshome/article-11915253/Number-mortgages-approved-goes-time-mini-Budget-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mortgageshome/article-11915253/Number-mortgages-approved-goes-time-mini-Budget-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:27:49+00:00

However, total mortgage lending plummeted from £2billion to £0.7billion, the lowest level since April 2016, as mortgage rates remain significantly higher than a year ago.

## How Navy sailor Richard Dorrough confessed he was a serial killer in suicide note
 - [https://www.dailymail.co.uk/news/article-11915035/How-Navy-sailor-Richard-Dorrough-confessed-serial-killer-suicide-note.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915035/How-Navy-sailor-Richard-Dorrough-confessed-serial-killer-suicide-note.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:27:28+00:00

Richard Dorrough, 37, was engaged, had three young children and was working as a diver when he walked into a Perth gun range in 2014 and turned the pistol on himself.

## Judge who sentenced Alex Murdaugh to two life sentences has 'no doubt he loved his family'
 - [https://www.dailymail.co.uk/news/article-11915647/Judge-sentenced-Alex-Murdaugh-two-life-sentences-no-doubt-loved-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915647/Judge-sentenced-Alex-Murdaugh-two-life-sentences-no-doubt-loved-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:27:17+00:00

The judge who presided over Alex Murdaugh's murder trial has 'no doubt' the legal scion loved his wife and son - but says he'll never 'sleep peacefully' after killing them.

## Sydney and Melbourne taking the most migrants as immigration set to surge by 650,000
 - [https://www.dailymail.co.uk/news/article-11913969/Sydney-Melbourne-taking-migrants-immigration-set-surge-650-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913969/Sydney-Melbourne-taking-migrants-immigration-set-surge-650-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:19:14+00:00

The floodgates are being opened to skilled migrants,  international students and those coming for family reasons, even though Sydney and Melbourne have ultra-low one per cent rental vacancy rates.

## Australia's migration boom to fuel housing crisis say Sydney migrants in Harris Park Lakemba Burwood
 - [https://www.dailymail.co.uk/news/article-11914333/Australias-migration-boom-fuel-housing-crisis-say-Sydney-migrants-Harris-Park-Lakemba-Burwood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914333/Australias-migration-boom-fuel-housing-crisis-say-Sydney-migrants-Harris-Park-Lakemba-Burwood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:18:39+00:00

A record-breaking number of immigrants will arrive Down Under in the next few years, but even recent migrants are questioning where the newcomers will live.

## Man jailed for life for murdering Rikki Neave wins right to appeal against his conviction
 - [https://www.dailymail.co.uk/news/article-11915455/Man-jailed-life-murdering-Rikki-Neave-wins-right-appeal-against-conviction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915455/Man-jailed-life-murdering-Rikki-Neave-wins-right-appeal-against-conviction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:15:12+00:00

Last year, James Watson (pictured), who was 13 when Rikki died and is now 41, was jailed for the crime by a judge at the Old Bailey after damning new evidence came to light.

## Thug homeowner faces life in jail for murdering grandmother after dragging her into the street
 - [https://www.dailymail.co.uk/news/article-11915819/Thug-homeowner-faces-life-jail-murdering-grandmother-dragging-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915819/Thug-homeowner-faces-life-jail-murdering-grandmother-dragging-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:13:17+00:00

David Redfern, 46, dragged Margaret Barnes downstairs by her feet after he found her asleep in a bed at his seafront home in Barmouth, North Wales, on July 11 last year.

## Australians warned off Binance as it is charged with money laundering violations
 - [https://www.dailymail.co.uk/news/article-11914557/Australians-warned-Binance-charged-money-laundering-violations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914557/Australians-warned-Binance-charged-money-laundering-violations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:13:08+00:00

Binance has been charged by a US regulator for multiple breaches of money laundering regulations which it allegedly deliberately tried to evade. Australians have been warned to steer clear.

## Cashless Australia: Why you won't be able to withdraw your own money at some ANZ branches
 - [https://www.dailymail.co.uk/news/article-11915493/Cashless-Australia-wont-able-withdraw-money-ANZ-branches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915493/Cashless-Australia-wont-able-withdraw-money-ANZ-branches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 14:00:42+00:00

One of Australia's biggest banks has confirmed that some of its branches will no longer allow customers to withdraw money over the counter.

## YouTube star MrBeast is slammed for 'tipping' his server a new car covered in logos
 - [https://www.dailymail.co.uk/news/article-11915545/YouTube-star-MrBeast-slammed-tipping-server-new-car-covered-logos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915545/YouTube-star-MrBeast-slammed-tipping-server-new-car-covered-logos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:43:30+00:00

The unorthodox gratuity was seen in a TikTok video posted on March 27, and serves as only the latest in a string of wild, lavish gifts dished out by the widely popular YouTuber.

## Gwyneth Paltrow trial LIVE: Actress' lawyers set to grill retired doctor
 - [https://www.dailymail.co.uk/news/article-11915753/Gwyneth-Paltrow-trial-LIVE-updates-day-seven.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915753/Gwyneth-Paltrow-trial-LIVE-updates-day-seven.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:39:02+00:00

DailyMail.com reporters will bring you all the latest from the seventh day of the Gwyneth Paltrow trial, where retired optometrist Terry Sanderson is once again expected to take the stand.

## Phillip Schofield shouted 'f*** stop' at brother as he told of sex act with schoolboy,' court hears
 - [https://www.dailymail.co.uk/news/article-11915687/Phillip-Schofield-shouted-f-stop-brother-told-sex-act-schoolboy-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915687/Phillip-Schofield-shouted-f-stop-brother-told-sex-act-schoolboy-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:37:43+00:00

Timothy Schofield, 54, had travelled up to see his famous older sibling in a 'heightened state of agitation' threatening to kill himself.

## Biden to push new banking rules after Silicon Valley Bank collapse
 - [https://www.dailymail.co.uk/news/article-11915615/Biden-push-new-banking-rules-Silicon-Valley-Bank-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915615/Biden-push-new-banking-rules-Silicon-Valley-Bank-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:36:56+00:00

President Joe Biden will push for new banking regulations in the wake of the collapse of Silicon Valley Bank as Congress grills federal officials as it looks into how the financial giant went bust.

## Albanian hides from officer on roof of cannabis farm house before being caught and jailed
 - [https://www.dailymail.co.uk/news/article-11915801/Albanian-hides-officer-roof-cannabis-farm-house-caught-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915801/Albanian-hides-officer-roof-cannabis-farm-house-caught-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:36:06+00:00

Etmond Lika, 32, of no fixed abode, climbed through a skylight of the house in Liverpool and balanced precariously above the window as a policeman poked his head through.

## Woman who sexually abused foster daughter and allowed victim's uncle to join in is jailed
 - [https://www.dailymail.co.uk/news/article-11915077/Woman-sexually-abused-foster-daughter-allowed-victims-uncle-join-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915077/Woman-sexually-abused-foster-daughter-allowed-victims-uncle-join-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:22:35+00:00

Julie Townson, 62, from Ellesmere Port in Cheshire, started abusing Danielle Upton when she was just 15 after she was assigned to care for her under a private fostering arrangement.

## Fauci 'sells his memoir to Penguin Random for $5 MILLION' that will chart his life
 - [https://www.dailymail.co.uk/news/article-11915537/Fauci-sells-memoir-Penguin-Random-5-MILLION-chart-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915537/Fauci-sells-memoir-Penguin-Random-5-MILLION-chart-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:18:52+00:00

Dr Anthony Fauci, 82, has sold his memoir, which will chronicle his life, to Penguin Random House for $5million.This is not the first book Fauci has written off the back of the pandemic.

## No10 denies Rishi Sunak broke rules by failing to mention wife's shareholding in childcare business
 - [https://www.dailymail.co.uk/news/article-11915531/No10-denies-Rishi-Sunak-broke-rules-failing-mention-wifes-shareholding-childcare-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915531/No10-denies-Rishi-Sunak-broke-rules-failing-mention-wifes-shareholding-childcare-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:09:48+00:00

The Prime Minister did not declare Ms Murty's investment in Koru Kids when he was quizzed about his £4billion boost for the childcare sector at this month's Budget.

## Sadiq Khan issues warning to Ulez vandals launching guerrilla war against hated scheme
 - [https://www.dailymail.co.uk/news/article-11915169/Sadiq-Khan-issues-warning-Ulez-vandals-launching-guerrilla-war-against-hated-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915169/Sadiq-Khan-issues-warning-Ulez-vandals-launching-guerrilla-war-against-hated-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:07:50+00:00

Mayor of London Sadiq Khan say the vandalising of his money-spinning Ulez cameras will be taken very seriously.

## Andrew Tate will stay in Romanian prison as he loses another appeal
 - [https://www.dailymail.co.uk/news/article-11915633/Andrew-Tate-stay-Romanian-prison-loses-appeal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915633/Andrew-Tate-stay-Romanian-prison-loses-appeal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:06:58+00:00

Andrew Tate and his brother Tristan today lost their appeal against a Romanian court's decision to deny them bail and keep them behind bars on sex trafficking charges.

## Americans heed Mexico travel warning as Europeans, Canadians and Australians flock to Cancún
 - [https://www.dailymail.co.uk/news/article-11912121/Americans-heed-Mexico-travel-warning-Europeans-Canadians-Australians-flock-Canc-n.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11912121/Americans-heed-Mexico-travel-warning-Europeans-Canadians-Australians-flock-Canc-n.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:03:19+00:00

International sunseekers from Australia, Canada, and Europe have supplanted US college students and tourists in Cancun this Spring Break  after the US government's travel warning for Mexico.

## Baby, 7 months, died forgotten in car three months after her elder brother, 16 months, drowned
 - [https://www.dailymail.co.uk/news/article-11914899/Baby-7-months-died-forgotten-car-three-months-elder-brother-16-months-drowned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914899/Baby-7-months-died-forgotten-car-three-months-elder-brother-16-months-drowned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 13:01:18+00:00

Uriel's brother, Ezra, drowned in a pond aged 16-months-old while unattended at grandmother Tracey Nix's home just before Christmas in 2021. Nix was asleep when the boy died.

## Chris Christie vows to never again support 'old and out-of-touch' Donald Trump
 - [https://www.dailymail.co.uk/news/article-11915517/Chris-Christie-vows-never-support-old-touch-Donald-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915517/Chris-Christie-vows-never-support-old-touch-Donald-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:52:43+00:00

Former New Jersey Gov. Chris Christie said that he will not support Donald Trump ever again - even if he is the 2024 Republican nominee for president - as he weighs a bid of his own.

## Nathan Millard: Man who was found in a rolled-up rug died accidentally with drugs in his system
 - [https://www.dailymail.co.uk/news/article-11915457/Nathan-Millard-Man-rolled-rug-died-accidentally-drugs-system.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915457/Nathan-Millard-Man-rolled-rug-died-accidentally-drugs-system.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:49:58+00:00

Nathan Millard, 42, from Georgia, disappeared on February 23 and was found dead in a Louisiana lot on March 6 after a night out with an alleged drug dealer and 'prostitutes'.

## Dominic Raab throws 'scum' jibe at Angela Rayner after she brands bullying probe minister a 'thug'
 - [https://www.dailymail.co.uk/news/article-11915337/Dominic-Raab-throws-scum-jibe-Angela-Rayner-brands-bullying-probe-minister-thug.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915337/Dominic-Raab-throws-scum-jibe-Angela-Rayner-brands-bullying-probe-minister-thug.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:46:37+00:00

Labour's Rayner took aim at bullying allegation against the Deputy Prime Minister as she attacked the Government's anti-social behaviour clampdown.

## Driver, 22, 'killed passenger, 17, in crash while he was high on cocaine, ketamine and ecstasy'
 - [https://www.dailymail.co.uk/news/article-11915309/Driver-22-killed-passenger-17-crash-high-cocaine-ketamine-ecstasy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915309/Driver-22-killed-passenger-17-crash-high-cocaine-ketamine-ecstasy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:45:33+00:00

Passenger Chloe Hayman (pictured), 17, was killed in the crash last year after enjoying a night out with friends in south Wales.

## King Charles and Queen Consort Camilla arrive in Germany for the first State Visit of their reign
 - [https://www.dailymail.co.uk/news/article-11915307/King-Charles-Queen-Consort-Camilla-arrive-Germany-State-Visit-reign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915307/King-Charles-Queen-Consort-Camilla-arrive-Germany-State-Visit-reign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:42:50+00:00

Charles and Camilla landed on the British Government's Voyager plane at Berlin Brandenburg Airport shortly after 2pm.

## Worshippers say plan for new bronze Amazonian love god statue is 'offensive to Christians'
 - [https://www.dailymail.co.uk/news/article-11915279/Worshippers-say-plan-new-bronze-Amazonian-love-god-statue-offensive-Christians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915279/Worshippers-say-plan-new-bronze-Amazonian-love-god-statue-offensive-Christians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:40:51+00:00

A planning application to site the 'pagan statue' on Cathedral Walk, close to the historic Anglican cathedral's main entrance, has prompted more than 60 complaints from members of the public.

## Aussies leading the Republic Movement plan to confront King Charles
 - [https://www.dailymail.co.uk/news/article-11914339/Aussies-leading-Republic-Movement-plan-confront-King-Charles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914339/Aussies-leading-Republic-Movement-plan-confront-King-Charles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:30:34+00:00

Newly-appointed Australian Republic Movement co-chairs Nova Peris and Craig Foster say they want to sit down with the 74-year-old monarch.

## Elon Musk calls for pause on developing 'dangerous' AI
 - [https://www.dailymail.co.uk/news/article-11914149/Musk-experts-urge-pause-training-AI-systems-outperform-GPT-4.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914149/Musk-experts-urge-pause-training-AI-systems-outperform-GPT-4.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:22:29+00:00

Elon Musk and 1,000 other tech leaders signed a letter calling for independent oversight of the race to advance AI, and pleading with global tech leaders to stop rushing to develop it.

## Villagers fear fresh attacks after woman in her 80s dies from serious injuries during house burglary
 - [https://www.dailymail.co.uk/news/article-11915369/Villagers-fear-fresh-attacks-woman-80s-dies-injuries-house-burglary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915369/Villagers-fear-fresh-attacks-woman-80s-dies-injuries-house-burglary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:17:22+00:00

Residents of a 'usually quiet' Somerset village are fearful of fresh attacks after the death of a pensioner who was seriously injured during a house burglary.

## Ministers unveil plan to slash eye-watering £6m-a-day hotel bill for migrants
 - [https://www.dailymail.co.uk/news/article-11915509/Ministers-unveil-plan-slash-eye-watering-6m-day-hotel-bill-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915509/Ministers-unveil-plan-slash-eye-watering-6m-day-hotel-bill-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:14:05+00:00

Immigration minister Robert Jenrick laid out details of large-scale sites that will be used to accommodate arrivals, in a bid to cut the £6million-a-day-bill for hotels.

## Mother reveals shocking injuries to face and teeth after partner who smashed glass ashtray in face
 - [https://www.dailymail.co.uk/news/article-11915083/Mother-reveals-shocking-injuries-face-teeth-partner-smashed-glass-ashtray-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915083/Mother-reveals-shocking-injuries-face-teeth-partner-smashed-glass-ashtray-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 12:05:57+00:00

Kate Scott, 41, of Leighton Buzzard, Beds, had three teeth knocked back and her upper lip cut in half 'like a pizza cutter' by the attack.

## Estranged wife of union boss union boss John Setka charged over over plot to kill him
 - [https://www.dailymail.co.uk/news/article-11915377/Estranged-wife-union-boss-union-boss-John-Setka-charged-plot-kill-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915377/Estranged-wife-union-boss-union-boss-John-Setka-charged-plot-kill-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:56:13+00:00

Former lawyer Emma Walters was interviewed by police on Wednesday and charged with incitement to commit conspiracy to murder the Victorian secretary of the CFMEU.

## Remains found in Lake Mead at historic low water level identified as 39-year-old from Las Vegas
 - [https://www.dailymail.co.uk/news/article-11914923/Remains-Lake-Mead-historic-low-water-level-identified-39-year-old-Las-Vegas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914923/Remains-Lake-Mead-historic-low-water-level-identified-39-year-old-Las-Vegas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:42:26+00:00

Donald P. Smith's remains were discovered after a diver came across a human bone in Lake Mead's National Recreation Area's Callville Bay on October 17.

## Female Russian medics 'are being pressured into becoming sex slaves for officers
 - [https://www.dailymail.co.uk/news/article-11915161/Female-Russian-medics-pressured-sex-slaves-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915161/Female-Russian-medics-pressured-sex-slaves-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:42:23+00:00

The woman said those who refused to be sex slaves would face punishment. She said women would be made to cook, clean, and pleasure the male officers.

## Nick Cave sells Grade I listed Brighton seafront mansion to city high-fliers for £2.9m
 - [https://www.dailymail.co.uk/news/article-11914981/Nick-Cave-sells-Grade-listed-Brighton-seafront-mansion-city-high-fliers-2-9m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914981/Nick-Cave-sells-Grade-listed-Brighton-seafront-mansion-city-high-fliers-2-9m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:42:20+00:00

Nick Cave has now sold his seaside mansion in Lewes Crescent, Brighton, to a couple of city high-fliers for £2.9m. The Grade I-listed Regency house has four bathrooms, a gym and study.

## Number of nuclear warheads in the world rises to 9,576
 - [https://www.dailymail.co.uk/news/article-11915223/Number-nuclear-warheads-world-rises-9-576.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915223/Number-nuclear-warheads-world-rises-9-576.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:40:42+00:00

The nine official and unofficial nuclear powers hold 9,576 ready-to-use warheads in 2023 - up from 9,440 the year prior, according to the Nuclear Weapons Ban Monitor

## Blue badge holder slams police parking van in a disabled space claiming it caused a 'real struggle'
 - [https://www.dailymail.co.uk/news/article-11914851/Blue-badge-holder-slams-police-parking-van-disabled-space-claiming-caused-real-struggle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914851/Blue-badge-holder-slams-police-parking-van-disabled-space-claiming-caused-real-struggle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:36:33+00:00

Michael, 55, says he was forced to park further away than usual and struggled to reach his final destination after a police van parked in a disabled bay outside of Bradford City Hall

## Pictured: Ex-beauty queen, 25, who collapsed and died at Michael Owen's stables where she worked
 - [https://www.dailymail.co.uk/news/article-11915247/Pictured-Ex-beauty-queen-25-collapsed-died-Michael-Owens-stables-worked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915247/Pictured-Ex-beauty-queen-25-collapsed-died-Michael-Owens-stables-worked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:34:23+00:00

Jessica Whalley was a transport manager at the stables near Malpas, Cheshire, which are owned by the ex-footballer who was in tears over Jessica's sudden death

## Jeremy Hunt defends his 'stealth' tax raid and fails to rule out a huge hike in fuel duty next year
 - [https://www.dailymail.co.uk/news/article-11915317/Jeremy-Hunt-defends-stealth-tax-raid-fails-rule-huge-hike-fuel-duty-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915317/Jeremy-Hunt-defends-stealth-tax-raid-fails-rule-huge-hike-fuel-duty-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:28:27+00:00

The Chancellor defended his 'stealth' raid on working Britons - through the extension of a freeze on tax thresholds - as a 'better way' of hiking levies.

## Rishi Sunak leads tributes to Baroness Betty Boothroyd as mourners gather for funeral
 - [https://www.dailymail.co.uk/news/article-11915105/Rishi-Sunak-leads-tributes-Baroness-Betty-Boothroyd-mourners-gather-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915105/Rishi-Sunak-leads-tributes-Baroness-Betty-Boothroyd-mourners-gather-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:14:24+00:00

Lady Boothroyd, MP for 27 years before sitting in the Lords for Labour for two further decades, shattered more than 700 years of parliamentary tradition when she was elected speaker.

## How theft of 24st Stone of Scone sparked one of the biggest manhunts in British history
 - [https://www.dailymail.co.uk/news/article-11914623/How-theft-24st-Stone-Scone-sparked-one-biggest-manhunts-British-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914623/How-theft-24st-Stone-Scone-sparked-one-biggest-manhunts-British-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:09:34+00:00

On Christmas Day in 1950, the Stone of Scone was taken by four young Scottish nationalists, who broke into Westminster Abbey by a side door. Above: The stone being  recovered in 1951.

## Prison governor taken hostage by Charles Bronson says he should not be freed from jail
 - [https://www.dailymail.co.uk/news/article-11914969/Prison-governor-taken-hostage-Charles-Bronson-says-not-freed-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914969/Prison-governor-taken-hostage-Charles-Bronson-says-not-freed-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:09:10+00:00

Former prison governor Adrian Wallace, (pictured) who gave a statement to the Parole Board, fears Bronson will not be able to comply with whatever conditions are imposed if he is freed on licence.

## Madeleine McCann claim: Who is Julia Wendell?
 - [https://www.dailymail.co.uk/news/article-11914951/Madeleine-McCann-claim-Julia-Wendell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914951/Madeleine-McCann-claim-Julia-Wendell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:07:47+00:00

Julia Wendell, 21, became an internet sensation when she claimed she was the missing Madeleine McCann - despite her own parents branding her claims as 'lies and manipulation'.

## Former army veteran cleared of drink-driving charge after sleeping in van to escape his wife
 - [https://www.dailymail.co.uk/news/article-11914893/Former-army-veteran-cleared-drink-driving-charge-sleeping-van-escape-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914893/Former-army-veteran-cleared-drink-driving-charge-sleeping-van-escape-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:02:17+00:00

Former army veteran Peter Doherty, 61, from Halewood, Merseyside was today found not guilty of the offence after claiming he had been seeking refuge from his partner Carly O'Hare

## Flatmate 'kept 71-year-old's dead body in freezer for nearly two years while using his bank card'
 - [https://www.dailymail.co.uk/news/article-11915109/Flatmate-kept-71-year-olds-dead-body-freezer-nearly-two-years-using-bank-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915109/Flatmate-kept-71-year-olds-dead-body-freezer-nearly-two-years-using-bank-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 11:01:20+00:00

Damion Johnson, 52, from Derby, is alleged to have kept a dead body in his freezer for almost two years and used the victim's bank accounts.

## Brother of Mark Duggan is cleared of gang knife fight but his rapper son may face retrial
 - [https://www.dailymail.co.uk/news/article-11914877/Brother-Mark-Duggan-cleared-gang-knife-fight-rapper-son-face-retrial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914877/Brother-Mark-Duggan-cleared-gang-knife-fight-rapper-son-face-retrial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:57:32+00:00

Marlon Duggan (pictured), 38, and son Kemani Duggan, 21, a rapper who performs as Bandokay, were accused of taking part in the brawl in Selfridges on May 8, 2021.

## Canberra wedding venue Pialligo Estate suddenly goes under amid soaring costs
 - [https://www.dailymail.co.uk/news/article-11915039/Canberra-wedding-venue-Pialligo-Estate-suddenly-goes-amid-soaring-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915039/Canberra-wedding-venue-Pialligo-Estate-suddenly-goes-amid-soaring-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:56:42+00:00

Pialligo Estate, in Canberra, will close its doors after 10 years, with owner John Russell saying it has 'finally succumbed'.

## Girl, 18 months, dies in hospital after being found unresponsive at home as police investigate
 - [https://www.dailymail.co.uk/news/article-11914755/Girl-18-months-dies-hospital-unresponsive-home-police-investigate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914755/Girl-18-months-dies-hospital-unresponsive-home-police-investigate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:51:04+00:00

An 18-month-old girl has died in hospital after she was found unresponsive at home. Police are probing the 'cause and the circumstances' surrounding the toddler's death.

## British pensioner, 79, dies while diving in the sea off the Philippines
 - [https://www.dailymail.co.uk/news/article-11915099/British-pensioner-79-dies-diving-sea-Philippines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915099/British-pensioner-79-dies-diving-sea-Philippines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:39:32+00:00

Derek Arthur Silverthorne was last seen alive swimming in the crystal clear waters of the secluded Bisucay island in Cuyo, Palawan province on Saturday morning, March 25

## Labour frontbencher Wes Streeting says Jeremy Corbyn 'won't be missed' in row over election bar
 - [https://www.dailymail.co.uk/news/article-11915009/Labour-frontbencher-Wes-Streeting-says-Jeremy-Corbyn-wont-missed-row-election-bar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11915009/Labour-frontbencher-Wes-Streeting-says-Jeremy-Corbyn-wont-missed-row-election-bar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:32:23+00:00

Wes Streeting, the shadow health secretary, said Mr Corbyn had 'no one to blame but himself' for the decision by the party's ruling NEC to block him from representing it at the next election.

## Case of the ex! Princess Beatrice spotted at same private club as former boyfriend of 10 years
 - [https://www.dailymail.co.uk/femail/article-11914859/Case-ex-Princess-Beatrice-spotted-private-club-former-boyfriend-10-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11914859/Case-ex-Princess-Beatrice-spotted-private-club-former-boyfriend-10-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:16:47+00:00

The royal, 34, split from Dave Clark, 38, in 2016. Beatrice didn't appear in the least bit bothered to have crossed paths with her old flame at Lou Lou's in Mayfair last night

## Russian weight-loss influencer who infamously dumped husband for STEP-SON gives birth to their child
 - [https://www.dailymail.co.uk/news/article-11914483/Russian-weight-loss-influencer-infamously-dumped-husband-STEP-SON-gives-birth-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914483/Russian-weight-loss-influencer-infamously-dumped-husband-STEP-SON-gives-birth-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:14:19+00:00

Marina Balmasheva,has had a child with Vladimir Shavyrin, who she raised from the age of seven. She was previously married to Vladimir's father Alexey Shavyrin, 47, who she ditched for his son.

## Plan to house Channel migrants on BARGES is slammed as 'surreal' and 'gimmicky'
 - [https://www.dailymail.co.uk/news/article-11914613/Plan-house-Channel-migrants-BARGES-slammed-surreal-gimmicky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914613/Plan-house-Channel-migrants-BARGES-slammed-surreal-gimmicky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:08:23+00:00

Immigration minister Robert Jenrick is set to lay out details of large-scale sites that will be used to accommodate arrivals in the UK, in a bid to cut the eye-watering £6million-a-day-bill for hotels.

## Police launch desperate hunt to find missing 14-year-old schoolgirl last seen in her uniform
 - [https://www.dailymail.co.uk/news/article-11914659/Police-launch-desperate-hunt-missing-14-year-old-schoolgirl-seen-uniform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914659/Police-launch-desperate-hunt-missing-14-year-old-schoolgirl-seen-uniform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:04:51+00:00

West Yorkshire Police have issued an urgent appeal for information regarding the whereabouts of missing girl, Katelan Coates, 14 who was last known to be wearing school uniform.

## King Charles set to arrive in Germany for first overseas state visit
 - [https://www.dailymail.co.uk/news/article-11914573/King-Charles-set-arrive-Germany-overseas-state-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914573/King-Charles-set-arrive-Germany-overseas-state-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:04:44+00:00

Charles and Camilla are spending three days in Germany after their planned trip to France was postponed in the face of political protests against President Macron.

## French author, 67, loses legal battle to ban porn film he starred in
 - [https://www.dailymail.co.uk/news/article-11914745/French-author-67-loses-legal-battle-ban-porn-film-starred-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914745/French-author-67-loses-legal-battle-ban-porn-film-starred-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 10:00:38+00:00

A trailer released in January showed 67-year-old Michel Houellebecq kissing and fondling a young woman in bed in the movie, 'Kirac 27', by Dutch filmmaker Stefan Ruitenbeek

## National Lottery player locked in court fight with Camelot as she claims she's entitled to £1million
 - [https://www.dailymail.co.uk/news/article-11914819/National-Lottery-player-locked-court-fight-Camelot-claims-shes-entitled-1million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914819/National-Lottery-player-locked-court-fight-Camelot-claims-shes-entitled-1million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:58:51+00:00

A woman who is convinced she won £1million on a National Lottery game has taken operators Camelot to the High Court - who instead claim a 'technical error' means she only won £10.

## Nursery owner 'went to a dark place and has never been the same' after a bad Ofsted report
 - [https://www.dailymail.co.uk/news/article-11914829/Nursery-owner-went-dark-place-never-bad-Ofsted-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914829/Nursery-owner-went-dark-place-never-bad-Ofsted-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:50:24+00:00

Linda Jeho, 46, says she was left emotionally distressed after inspectors told her Little Limes Day Nursery in Hersham, Surrey would be rated 'inadequate'.

## Woman subjected boyfriend's father to vicious punishment beating because he 'hit her sister'
 - [https://www.dailymail.co.uk/news/article-11914731/Woman-subjected-boyfriends-father-vicious-punishment-beating-hit-sister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914731/Woman-subjected-boyfriends-father-vicious-punishment-beating-hit-sister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:36:45+00:00

Sarah Crowe, 25, and her father, Paul, 56, launched a 'prolonged, persistent and nasty' assault on Christopher Ellams at a social club in Cheshire after he allegedly hit Sarah's younger sister.

## Drunk Grand Designs star, 54, urinated on British Airways passenger and his child's teddy
 - [https://www.dailymail.co.uk/news/article-11914741/Drunk-Grand-Designs-star-54-urinated-British-Airways-passenger-childs-teddy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914741/Drunk-Grand-Designs-star-54-urinated-British-Airways-passenger-childs-teddy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:25:47+00:00

Stonemason Adam Purchase, who appeared on TV's Grand Designs in 2011, urinated on a passenger on a British Airways flight after becoming 'incoherent' from sinking rum and wine.

## Trailblazer whose drag act took him to Buckingham Palace: Paul O'Grady shot to fame as Lily Savage
 - [https://www.dailymail.co.uk/tvshowbiz/article-11914309/Trailblazer-drag-act-took-Buckingham-Palace-Paul-OGrady-shot-fame-Lily-Savage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11914309/Trailblazer-drag-act-took-Buckingham-Palace-Paul-OGrady-shot-fame-Lily-Savage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:16:35+00:00

The comedian and TV personality first rose to prominence as his drag queen persona Lily Savage in the 1980s and 1990s before going on to host a string of television programmes.

## Moment woman is hit by a car and sent flying into the air while under the bonnet of her vehicle
 - [https://www.dailymail.co.uk/news/article-11914601/Moment-woman-hit-car-sent-flying-air-bonnet-vehicle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914601/Moment-woman-hit-car-sent-flying-air-bonnet-vehicle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:16:18+00:00

WARNING: DISTRESSING CONTENT Shocking video shows the moment a woman working on her car outside her home is ploughed into by a car in Edgware, north London, on March 26.

## Council seek injunction to stop Dambusters HQ RAF Scampton being turned into migrant centre
 - [https://www.dailymail.co.uk/news/article-11914603/Council-seek-injunction-stop-Dambusters-HQ-RAF-Scampton-turned-migrant-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914603/Council-seek-injunction-stop-Dambusters-HQ-RAF-Scampton-turned-migrant-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:15:50+00:00

Local authorities in charge of RAF Wethersfield and RAF Scampton  are seeking high court injunctions to prevent the government transforming the bases into asylum seeker centres.

## Russia warns that joining NATO will make Sweden a 'legitimate target' for retaliatory measures
 - [https://www.dailymail.co.uk/news/article-11914849/Russia-warns-joining-NATO-make-Sweden-legitimate-target-retaliatory-measures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914849/Russia-warns-joining-NATO-make-Sweden-legitimate-target-retaliatory-measures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:15:40+00:00

Sweden said it was summoning the Russian ambassador to Stockholm, after he said the Nordic country would become a 'legitimate targes' of 'retaliatory measures,' after joining NATO.

## Man who kept his dead mother mummified on his sofa for 13 years was known locally as 'Vampire'
 - [https://www.dailymail.co.uk/news/poland/article-11914733/Man-kept-dead-mother-mummified-sofa-13-years-known-locally-Vampire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/poland/article-11914733/Man-kept-dead-mother-mummified-sofa-13-years-known-locally-Vampire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:15:11+00:00

The 76-year-old man, named only as Marian L., dug up his mother's grave in the small town of Radlin, southwest Poland, and took her body to his home and placed her on the sofa in front of his TV.

## Last photo of Paul O'Grady while performing in Annie - three days before his death
 - [https://www.dailymail.co.uk/tvshowbiz/article-11914447/Last-photo-Paul-OGrady-performing-Annie-three-days-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11914447/Last-photo-Paul-OGrady-performing-Annie-three-days-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:13:21+00:00

The last photo of Paul O'Grady shows the late TV star and drag actor posing with a dog in Edinburgh where he was performing in a stage production of the musical Annie before his death aged 67.

## Inside barges which will house migrants: Scandi-style cabins, 'relaxation rooms', and even theatres
 - [https://www.dailymail.co.uk/news/article-11914769/Inside-barges-house-migrants-Scandi-style-cabins-relaxation-rooms-theatres.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914769/Inside-barges-house-migrants-Scandi-style-cabins-relaxation-rooms-theatres.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:11:44+00:00

Ministers are turning to the floating hotels, commonly known as 'coastels' in a bid to end a 'hotel farce' that is currently costing taxpayers more than £6million a day.

## British parents fined £200 each after being found drunk at a Gibraltar bar with baby in a pram
 - [https://www.dailymail.co.uk/news/article-11914569/British-parents-fined-200-drunk-Gibraltar-bar-baby-pram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914569/British-parents-fined-200-drunk-Gibraltar-bar-baby-pram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:11:16+00:00

Rosie Richardson Jones, 35, and partner Bradley Skeats, 42, were each charged with 'being intoxicated while in charge of a child' after admitting their drunken state to Gibraltar police.

## Councils taking Sadiq Khan to court over his hated Ulez expansion slam 'lacklustre' £6m 'Superloop'
 - [https://www.dailymail.co.uk/news/article-11914563/Councils-taking-Sadiq-Khan-court-hated-Ulez-expansion-slam-lacklustre-6m-Superloop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914563/Councils-taking-Sadiq-Khan-court-hated-Ulez-expansion-slam-lacklustre-6m-Superloop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:03:50+00:00

Councils taking Sadiq Khan to court over his unpopular Ulez expansion say his so-called 'Superloop' bus route changes nothing and 'literally doesn't touch the sides'.

## Putin stages major nuclear missile exercises involving 3,000 troops in show of strength to the West
 - [https://www.dailymail.co.uk/news/article-11914565/Putin-stages-major-nuclear-missile-exercises-involving-3-000-troops-strength-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914565/Putin-stages-major-nuclear-missile-exercises-involving-3-000-troops-strength-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:02:34+00:00

Vladimir Putin's troops are staging war games with his 'invincible' Yars intercontinental ballistic missile system in three regions of Russia.

## Second giant hole 20 times larger than Earth rips through the surface of the SUN
 - [https://www.dailymail.co.uk/sciencetech/article-11912361/Second-giant-hole-20-times-larger-Earth-rips-surface-sun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-11912361/Second-giant-hole-20-times-larger-Earth-rips-surface-sun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 09:00:17+00:00

NASA detected a second hole in the sun's surface, a week after another was spotted. The recent gaping hole is 20 times the size of Earth and is unleashing solar winds set to hit our planet Friday.

## Richard Arnold fights back tears as he pays an emotional tribute to Paul O'Grady
 - [https://www.dailymail.co.uk/tvshowbiz/article-11914749/Richard-Arnold-fights-tears-pays-emotional-tribute-Paul-OGrady.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11914749/Richard-Arnold-fights-tears-pays-emotional-tribute-Paul-OGrady.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 08:58:52+00:00

Tributes have poured in for the legendary presenter and radio star after his partner Andre Portasio shared overnight that he had passed away 'unexpectedly but peacefully'.

## Woman dies in house fire in Essex after early hours blaze rips through mid-terrace home
 - [https://www.dailymail.co.uk/news/article-11914827/Woman-dies-house-fire-Essex-early-hours-blaze-rips-mid-terrace-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914827/Woman-dies-house-fire-Essex-early-hours-blaze-rips-mid-terrace-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 08:52:01+00:00

Firefighters were called to a house fire in a mid-terraced house in Mountdale Gardens, Leigh-on-Sea, Essex, at around 2.15am.

## Paul O'Grady's heartbreaking last Instagram post revealed following his unexpected death aged 67
 - [https://www.dailymail.co.uk/tvshowbiz/article-11914525/Paul-OGradys-heartbreaking-Instagram-post-revealed-amid-unexpected-death-aged-67.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11914525/Paul-OGradys-heartbreaking-Instagram-post-revealed-amid-unexpected-death-aged-67.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 08:48:29+00:00

Paul O'Grady's heartbreaking last Instagram post reveals he was devastated by the loss of his pet pig Tom Tom, just two weeks before his own unexpected death aged 67.

## Barack Obama speech: Fury as Aboriginal elder is axed from the event
 - [https://www.dailymail.co.uk/news/article-11914443/Barack-Obama-speech-Fury-Aboriginal-elder-axed-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914443/Barack-Obama-speech-Fury-Aboriginal-elder-axed-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 08:46:18+00:00

Wurundjeri Elder Joy Murphy, 78, was set to perform the Welcome to Country ceremony for the ex-US President's speech in Melbourne on Thursday night.

## 'Trans Day of Vengeance' protest to go ahead on Saturday despite Nashville school shooting
 - [https://www.dailymail.co.uk/news/article-11914611/Trans-Day-Vengeance-protest-ahead-Saturday-despite-Nashville-school-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914611/Trans-Day-Vengeance-protest-ahead-Saturday-despite-Nashville-school-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 08:41:49+00:00

Commentators have snapped back at the decision to go ahead with a 'Trans Day of Vengeance' protest this weekend after a shooter (pictured) killed six at a Nashville school Monday.

## Leicestershire Police launch urgent appeal to find 37-year-old woman who went missing yesterday
 - [https://www.dailymail.co.uk/news/article-11914655/Leicestershire-Police-launch-urgent-appeal-37-year-old-woman-went-missing-yesterday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914655/Leicestershire-Police-launch-urgent-appeal-37-year-old-woman-went-missing-yesterday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 08:25:41+00:00

Nareumol Herron was reported missing on Tuesday afternoon from the city centre area. She was last seen wearing a light coloured jumper and blue jeans (pictured).

## Putin may launch nuclear strike 'to cause misery amid Russian failure to conquer Ukraine'
 - [https://www.dailymail.co.uk/news/article-11914479/Putin-launch-nuclear-strike-cause-misery-amid-Russian-failure-conquer-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914479/Putin-launch-nuclear-strike-cause-misery-amid-Russian-failure-conquer-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 08:15:00+00:00

Moscow has prompted fresh concern over its willingness to deploy the devastating weapons, today commencing exercises with its Yars intercontinental ballistic missile (ICBM) systems

## Dan Andrews super-fan makes staggering claim about Australians wanting to know about his China trip
 - [https://www.dailymail.co.uk/news/article-11914313/Dan-Andrews-super-fan-makes-staggering-claim-Australians-wanting-know-China-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914313/Dan-Andrews-super-fan-makes-staggering-claim-Australians-wanting-know-China-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 08:09:02+00:00

The Victorian Premier has been roundly criticised over his 'secretive trip to China. But a super-fan has leapt to his defence.

## Losing weight cuts your risk of heart attacks and type 2 diabetes - even if you put it back on
 - [https://www.dailymail.co.uk/health/article-11914501/Losing-weight-cuts-risk-heart-attacks-type-2-diabetes-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11914501/Losing-weight-cuts-risk-heart-attacks-type-2-diabetes-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 08:04:23+00:00

Oxford University researchers found those who shed the pounds still enjoyed health benefits five years later, even if they regained a proportion of the weight.

## McDonald's adds 5 new items to its menu TODAY
 - [https://www.dailymail.co.uk/femail/article-11912567/McDonalds-adds-5-new-items-menu-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11912567/McDonalds-adds-5-new-items-menu-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 07:58:32+00:00

McDonald's stores around the UK are introducing  a brand new Steakhouse Stack, the Mighty McMuffin, and fan favourites Mozzarella Dippers, as well as Easter McFlurries.

## Pictured: Two women stabbed to death by knifeman during rampage at Muslim religious centre in Lisbon
 - [https://www.dailymail.co.uk/news/article-11914481/Pictured-Two-women-stabbed-death-knifeman-rampage-Muslim-religious-centre-Lisbon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914481/Pictured-Two-women-stabbed-death-knifeman-rampage-Muslim-religious-centre-Lisbon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 07:28:05+00:00

Portuguese nationals Mariana Jadaugy, 24, and Farana Sadrudin, 49, were killed in the knife attack at the Ismaili Centre in Lisbon.

## SNP civil war rages after Humza Yousaf tries to demote Kate Forbes
 - [https://www.dailymail.co.uk/news/article-11914465/SNP-civil-war-rages-Humza-Yousaf-tries-demote-Kate-Forbes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914465/SNP-civil-war-rages-Humza-Yousaf-tries-demote-Kate-Forbes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 07:15:51+00:00

Humza Yousaf was accused of 'pouring petrol' on the party by only offering leadership rival Kate Forbes a huge demotion to the Rural Affairs brief.

## Charlie Teo's lawyers warn disciplinary board of 'hindsight bias'
 - [https://www.dailymail.co.uk/news/article-11914403/Charlie-Teos-lawyers-warn-disciplinary-board-hindsight-bias.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914403/Charlie-Teos-lawyers-warn-disciplinary-board-hindsight-bias.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 07:13:59+00:00

Dr Teo faced a final Health Care Complaints Commission hearing in Sydney on Wednesday, as his supporters gathered outside.

## Trains from Maidenhead to London Paddington are cancelled after fire breaks next to railway track
 - [https://www.dailymail.co.uk/news/article-11914477/Trains-Maidenhead-London-Paddington-cancelled-fire-breaks-railway-track.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914477/Trains-Maidenhead-London-Paddington-cancelled-fire-breaks-railway-track.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 07:11:37+00:00

Trains from Maidenhead to London Paddington have been cancelled after a fire broke out next to the track.

## Commuter outrage as Sydney's transport system ranks among world's best
 - [https://www.dailymail.co.uk/news/article-11914093/Commuter-outrage-Sydneys-transport-ranks-worlds-best.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914093/Commuter-outrage-Sydneys-transport-ranks-worlds-best.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 07:01:14+00:00

Sydney's public transport system was ranked 14th  out of 60 cities in the study by the University of California, Berkeley - with Melbourne not even rating a mention.

## Court pushes ahead with rape trial for accused cop Ankit Thangasamy
 - [https://www.dailymail.co.uk/news/article-11914357/Court-pushes-ahead-rape-trial-accused-cop-Ankit-Thangasamy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914357/Court-pushes-ahead-rape-trial-accused-cop-Ankit-Thangasamy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 06:51:17+00:00

The alleged incident occurred at a Haymarket bar in Sydney's CBD on December 17, 2021. Ankit Thangasamy is defending himself in court.

## Sydney, Melbourne, Brisbane, weather: Prepare for more rain
 - [https://www.dailymail.co.uk/news/article-11914005/Sydney-Melbourne-Brisbane-weather-Prepare-rain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914005/Sydney-Melbourne-Brisbane-weather-Prepare-rain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 06:20:53+00:00

Large parts of Australia will need to brace for non-stop rain and thunderstorms this week amid grim predictions the downpours could last well into April as the country bids farewell to hot summer temperatures.

## Arizona Governor's press sec tweets meme about SHOOTING transphobes after trans killer massacred six
 - [https://www.dailymail.co.uk/news/article-11914027/Arizona-Governors-press-sec-tweets-meme-SHOOTING-transphobes-trans-killer-massacred-six.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914027/Arizona-Governors-press-sec-tweets-meme-SHOOTING-transphobes-trans-killer-massacred-six.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 06:15:45+00:00

The press secretary for Arizona governor Katie Hobbs blasted transphobes in a tweet featuring an armed woman just hours after a transgender shooter gunned down six.

## Australia's property crisis to get worse
 - [https://www.dailymail.co.uk/news/article-11913645/Australias-property-crisis-worse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913645/Australias-property-crisis-worse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 06:14:19+00:00

Australia's housing crisis is expected to get worse following a recent report that revealed a drastic fall in new home sales and a critical supply shortage.

## Measles warning for NSW and SA as baby and toddler return from overseas with disease
 - [https://www.dailymail.co.uk/news/article-11914161/Measles-warning-NSW-SA-baby-toddler-return-overseas-disease.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914161/Measles-warning-NSW-SA-baby-toddler-return-overseas-disease.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 06:10:39+00:00

Health authorities have issued an urgent health warning after a baby and a toddler were diagnosed with the highly-infectious illness measles in NSW and South Australia.

## St Peters, Sydney: Buyers at packed auction stunned after opening bid is $400,000 over price guide
 - [https://www.dailymail.co.uk/news/article-11913475/St-Peters-Sydney-Buyers-packed-auction-stunned-opening-bid-400-000-price-guide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913475/St-Peters-Sydney-Buyers-packed-auction-stunned-opening-bid-400-000-price-guide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 06:02:26+00:00

Hopeful homeowners at a packed auction in Sydney have been left stunned after the opening bid was a mind-boggling $400,000 over the price guide.

## Orphaned DOLPHIN thrives at Florida sanctuary after he was found gravely ill next to mom's corpse
 - [https://www.dailymail.co.uk/news/article-11914245/Orphaned-DOLPHIN-thrives-Florida-sanctuary-gravely-ill-moms-corpse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914245/Orphaned-DOLPHIN-thrives-Florida-sanctuary-gravely-ill-moms-corpse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:59:10+00:00

Ranger was found alone, dehydrated and with a respiratory infection in June 2021 in Texas. He was taken for veterinarian care and then transported to Florida a year ago, where he is now living.

## Scott Morrison breaks silence with furious five word insult at Anthony Albanese after PM trolled him
 - [https://www.dailymail.co.uk/news/article-11914249/Scott-Morrison-breaks-silence-furious-five-word-insult-Anthony-Albanese-PM-trolled-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914249/Scott-Morrison-breaks-silence-furious-five-word-insult-Anthony-Albanese-PM-trolled-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:58:32+00:00

A wisecrack over Scott Morrison's secret ministries saga had the former prime minister duking it out with Anthony Albanese on the floor of the house on Wednesday.

## Snake catcher's epic battle to remove a massive carpet python from Tallebudgera house
 - [https://www.dailymail.co.uk/news/article-11914145/Snake-catchers-epic-battle-remove-massive-carpet-python-Tallebudgera-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914145/Snake-catchers-epic-battle-remove-massive-carpet-python-Tallebudgera-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:57:23+00:00

A veteran snake removalist with 10 years' experience faced his 'toughest relocation ever' after a Tallebudgera local noticed an unwanted freeloader living in her roof.

## The rude tweet Brittany Higgins' fiance David Sharaz doesn't want you to see
 - [https://www.dailymail.co.uk/news/article-11913547/The-rude-tweet-Brittany-Higgins-fiance-David-Sharaz-doesnt-want-see.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913547/The-rude-tweet-Brittany-Higgins-fiance-David-Sharaz-doesnt-want-see.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:56:15+00:00

Daily Mail Australia has obtained an inflammatory Twitter post  David Sharaz wrote in response to a tweet by Sky News reporter Caroline Marcus on Thursday afternoon.

## Biden is slammed for cracking a JOKE when asked his views on transgender school shooter's motive
 - [https://www.dailymail.co.uk/news/article-11914119/Biden-slammed-cracking-JOKE-asked-views-transgender-school-shooters-motive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914119/Biden-slammed-cracking-JOKE-asked-views-transgender-school-shooters-motive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:55:20+00:00

President Joe Biden again approached his response to a question about the Nashville school shooting with humor.

## TikTok is blamed for ruining concerts as influencer wannabes try to OUTSING stars
 - [https://www.dailymail.co.uk/news/article-11914147/TikTok-blamed-ruining-concerts-influencer-wannabes-try-OUTSING-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914147/TikTok-blamed-ruining-concerts-influencer-wannabes-try-OUTSING-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:55:04+00:00

From pestering stars by sticking their fingers in their mouths to demanding singers play certain songs, disruptive fans are increasing and annoying others as more videos continue to pop up online.

## Australian DIY hardware store Bunnings called out over secret plot to buy up Mitre 10 stores
 - [https://www.dailymail.co.uk/news/article-11913481/Australian-DIY-hardware-store-Bunnings-called-secret-plot-buy-Mitre-10-stores.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913481/Australian-DIY-hardware-store-Bunnings-called-secret-plot-buy-Mitre-10-stores.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:53:00+00:00

The hardware juggernaut has been accused of 'anti-competitive' behaviour in its bid to convince owners of the independent cooperative to sell up.

## Cranbourne Turf Club in Melbourne fined $250,000 after death of apprentice jockey Mikaela Claridge
 - [https://www.dailymail.co.uk/news/article-11914105/Cranbourne-Turf-Club-Melbourne-fined-250-000-death-apprentice-jockey-Mikaela-Claridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914105/Cranbourne-Turf-Club-Melbourne-fined-250-000-death-apprentice-jockey-Mikaela-Claridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:43:33+00:00

The Cranbourne Turf Club was fined $250,000 after apprentice jockey Mikaela Claridge, 22, died when her horse was spooked during an early morning training ride and threw her off.

## Bali warning: Australian woman reveals sneaky coin scam targeting tourists
 - [https://www.dailymail.co.uk/news/article-11913965/Bali-warning-Australian-woman-reveals-sneaky-coin-scam-targeting-tourists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913965/Bali-warning-Australian-woman-reveals-sneaky-coin-scam-targeting-tourists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:38:35+00:00

An Australian woman has lifted the lid on a scam in the popular tourist destination Bali where scammers are grouping together to distract unwitting travellers to steal their money.

## Rebels bikie with dramatic tattoos arrested in Canley Heights, New South Wales, by riot cops
 - [https://www.dailymail.co.uk/news/article-11913999/Rebels-bikie-dramatic-tattoos-arrested-Canley-Heights-New-South-Wales-riot-cops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913999/Rebels-bikie-dramatic-tattoos-arrested-Canley-Heights-New-South-Wales-riot-cops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:22:00+00:00

Riot cops descended on a  house in Canley Heights, New South Wales, at 1.45pm on Tuesday where they arrested Rebels Bikie, Aleksandar Mahone,  on domestic violence-related charges.

## Gypsy Jokers bikie busted for more than $6,000 in unpaid cat registration fees during police raid
 - [https://www.dailymail.co.uk/news/article-11913929/Gypsy-Jokers-bikie-busted-6-000-unpaid-cat-registration-fees-police-raid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913929/Gypsy-Jokers-bikie-busted-6-000-unpaid-cat-registration-fees-police-raid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:20:10+00:00

A bikie has been busted for more than a decade of unpaid cat registration fees during a raid at the Victoria-NSW border, with police threatening to tow away his car if he did not pay up.

## Heiress daughter of billionaire pharma tycoon branded 'entitled' by judge who refuses to award $228m
 - [https://www.dailymail.co.uk/news/article-11914017/Heiress-daughter-billionaire-pharma-tycoon-branded-entitled-judge-refuses-award-228m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914017/Heiress-daughter-billionaire-pharma-tycoon-branded-entitled-judge-refuses-award-228m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:09:53+00:00

Serene Warren, the daughter of Minnesotan pharma tycoon Ken Everstad, took legal action against her family in 2018. The case was finally concluded last week, amid a bitter family feud.

## Cash transactions officially dying in Australia but Reserve Bank warns of tap-and-go hacking risks
 - [https://www.dailymail.co.uk/news/article-11913355/Cash-transactions-officially-dying-Australia-Reserve-Bank-warns-tap-hacking-risks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913355/Cash-transactions-officially-dying-Australia-Reserve-Bank-warns-tap-hacking-risks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 05:05:04+00:00

Just 13 per cent of Australian transactions are now done in cash, raising the risk of a cyber attack threatening everyday payments. But the Reserve Bank says it is prepared.

## Australian politics: Lidia Thorpe is accused of making elderly woman cry at Canberra Airport
 - [https://www.dailymail.co.uk/news/article-11914023/Australian-politics-Lidia-Thorpe-accused-making-elderly-woman-cry-Canberra-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914023/Australian-politics-Lidia-Thorpe-accused-making-elderly-woman-cry-Canberra-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:56:26+00:00

The outspoken independent Senator allegedly disrespected Uluru Dialogue co-chair Aunty Pat Anderson AO.

## Pauline Hanson slams Anthony Albanese's government over high immigration rate
 - [https://www.dailymail.co.uk/news/article-11914081/Pauline-Hanson-slams-Anthony-Albaneses-government-high-immigration-rate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914081/Pauline-Hanson-slams-Anthony-Albaneses-government-high-immigration-rate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:56:10+00:00

One Nation leader Pauline Hanson has taken aim at the Albanese government's high intake of migrants saying Australia is 'full' and does not have the housing, schools or hospitals to cope with the newcomers.

## Declan Laverty: Damian Crook, father of BWS worker killed at Darwin bottle shop, breaks his silence
 - [https://www.dailymail.co.uk/news/article-11913637/Declan-Laverty-Damian-Crook-father-BWS-worker-killed-Darwin-bottle-shop-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913637/Declan-Laverty-Damian-Crook-father-BWS-worker-killed-Darwin-bottle-shop-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:52:51+00:00

Damian Crook, the devastated father of BWS worker Declan Laverty, 20, who died after being stabbed during a shift has claimed his son was 'spat on' and called 'racist' after refusing to serve people.

## Gold Coast M1 Pacific Motorway: Dangerous moment man hangs out the window of a car
 - [https://www.dailymail.co.uk/news/article-11913925/Gold-Coast-M1-Pacific-Motorway-Dangerous-moment-man-hangs-window-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913925/Gold-Coast-M1-Pacific-Motorway-Dangerous-moment-man-hangs-window-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:47:20+00:00

Motorists driving along the M1 Pacific Motorway en route from Brisbane to the Gold Coast were shocked to spot the daredevil with more than half his body dangling out the window of a white sedan.

## Four men accused of bashing an Indigenous boy to death appear in court
 - [https://www.dailymail.co.uk/news/article-11913917/Cassius-Turvey-accused-killers-Brodie-Lee-Palmer-Mitchell-Colin-Forth-Aleesha-Louise-Gilmore.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913917/Cassius-Turvey-accused-killers-Brodie-Lee-Palmer-Mitchell-Colin-Forth-Aleesha-Louise-Gilmore.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:32:03+00:00

The four people accused of attacking Indigenous teenager Cassius Turvey, who died 10 days later, have returned to court in Perth.

## Hero Nashville cop who took down transgender school shooter is Marine Corps vet
 - [https://www.dailymail.co.uk/news/article-11913943/Hero-Nashville-cop-took-transgender-school-shooter-Marine-Corps-vet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913943/Hero-Nashville-cop-took-transgender-school-shooter-Marine-Corps-vet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:25:29+00:00

Officer Michael Collazo, 31, is a Marine Corps veteran who responded to the Christmas 2020 bombing. Rex Engelbert, 27, received an award last week for 'precision policing.'

## Barack Obama and Michelle Obama climb Sydney Harbour Bridge without safety harnesses
 - [https://www.dailymail.co.uk/news/article-11913803/Barack-Obama-Michelle-Obama-climb-Sydney-Harbour-Bridge-without-safety-harnesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913803/Barack-Obama-Michelle-Obama-climb-Sydney-Harbour-Bridge-without-safety-harnesses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:16:57+00:00

The casually-dressed couple scaled the world-famous landmark on Wednesday as they prepared to leave Sydney to continue Mr Obama's speaking tour in Melbourne.

## Balesh Dhankhar breaks down explaining fake job ad ruse to lure five Korean girls he allegedly raped
 - [https://www.dailymail.co.uk/news/article-11913861/Balesh-Dhankhar-breaks-explaining-fake-job-ad-ruse-lure-five-Korean-girls-allegedly-raped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913861/Balesh-Dhankhar-breaks-explaining-fake-job-ad-ruse-lure-five-Korean-girls-allegedly-raped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:13:18+00:00

Balesh Dhankhar is on trail facing 39 charges including drugging and raping five women in January to October 2018 and recording them on hidden cameras.

## Hillsong founder Brian Houston's shock statement admitting to criminal act in California
 - [https://www.dailymail.co.uk/news/article-11913877/Hillsong-founder-Brian-Houstons-shock-statement-admitting-criminal-act-California.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913877/Hillsong-founder-Brian-Houstons-shock-statement-admitting-criminal-act-California.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:11:22+00:00

Brian Houston, former leader of global Pentecostal mega church Hillsong has been charged with driving under the influence in the US.

## Paul O'Grady dead LATEST: Lily Savage star dies at 67 leaving TV world rocked
 - [https://www.dailymail.co.uk/news/article-11913957/Paul-OGrady-dead-LATEST-Lily-Savage-star-dies-67-leaving-TV-world-rocked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913957/Paul-OGrady-dead-LATEST-Lily-Savage-star-dies-67-leaving-TV-world-rocked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:05:18+00:00

MAILONLINE LIVEBLOG: TV presenter and comedian Paul O'Grady has died at the age of 67.

## linden Malayta-suspected-murder-north-queensland-townsville
 - [https://www.dailymail.co.uk/news/article-11909293/linden-Malayta-suspected-murder-north-queensland-townsville.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909293/linden-Malayta-suspected-murder-north-queensland-townsville.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:02:23+00:00

Queensland Police have announced a $500,000 reward for information about the suspected murder of a 15-year-old Linden Malayta who disappeared near Townsville in 2019.

## Melissa Joan Hart breaks down as she reveals she helped kindergartners flee Nashville shooting
 - [https://www.dailymail.co.uk/news/article-11913835/Melissa-Joan-Hart-breaks-reveals-helped-kindergartners-flee-Nashville-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913835/Melissa-Joan-Hart-breaks-reveals-helped-kindergartners-flee-Nashville-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 04:01:48+00:00

Melissa Joan Hart broke down in tears as she revealed she helped children fleeing from the Nashville school massacre.

## Barack Obama takes swipe at Rupert Murdoch over News Corp, Fox News, Sky coverage
 - [https://www.dailymail.co.uk/news/article-11913679/Barack-Obama-takes-swipe-Rupert-Murdoch-News-Corp-Fox-News-Sky-coverage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913679/Barack-Obama-takes-swipe-Rupert-Murdoch-News-Corp-Fox-News-Sky-coverage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 03:55:46+00:00

The former US President made the slight against the News Corp CEO while speaking with  former Australian foreign affairs minister Julie Bishop at Sydney's Aware Super Theatre on Tuesday night.

## Giant sperm whale skull is stolen from Eden Killer Whale Museum on NSW south coast
 - [https://www.dailymail.co.uk/news/article-11913733/Giant-sperm-whale-skull-stolen-Eden-Killer-Whale-Museum-NSW-south-coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913733/Giant-sperm-whale-skull-stolen-Eden-Killer-Whale-Museum-NSW-south-coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 03:51:40+00:00

The theft of the whale skull occurred sometime last month and has baffled staff at the Eden Killer Whale Museum on the NSW south coast, who said the thieves would have needed a truck.

## Coles' receipt from 1992 shows how expensive groceries have become due to inflation
 - [https://www.dailymail.co.uk/news/article-11913685/Coles-receipt-1992-shows-expensive-groceries-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913685/Coles-receipt-1992-shows-expensive-groceries-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 03:48:43+00:00

The Coles receipt, dated May 14, 1992, for white onions, sausages and a bag of potato chips has highlighted the soaring cost of groceries Aussie shoppers are dealing with due to inflation.

## Tennessee Governor reveals Nashville school shooting victim Cindy Peak was his wife's best friend
 - [https://www.dailymail.co.uk/news/article-11913789/Tennessee-Governor-reveals-Nashville-school-shooting-victim-Cindy-Peak-wifes-best-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913789/Tennessee-Governor-reveals-Nashville-school-shooting-victim-Cindy-Peak-wifes-best-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 03:20:36+00:00

Governor Bill Lee announced his wife Maria was best friends with victim Cindy Peak, 61, who died while standing in as a substitute teacher at the Christian school on Monday.

## Locals in Kiama, NSW, divided over uncut grass in beachside park as council halts roadside mowing
 - [https://www.dailymail.co.uk/news/article-11913105/Locals-Kiama-NSW-divided-uncut-grass-beachside-park-council-halts-roadside-mowing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913105/Locals-Kiama-NSW-divided-uncut-grass-beachside-park-council-halts-roadside-mowing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 03:09:25+00:00

Residents in a town on the South Coast of New South Wales are divided over a patch of uncut grass in a beachside park, as local council stops all roadside mowing.

## Online sleuth reveals how he embarrassed Gwyneth Paltrow lawyers by uncovering crucial evidence
 - [https://www.dailymail.co.uk/news/article-11913687/Online-sleuth-reveals-embarrassed-Gwyneth-Paltrow-lawyers-uncovering-crucial-evidence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913687/Online-sleuth-reveals-embarrassed-Gwyneth-Paltrow-lawyers-uncovering-crucial-evidence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 03:07:48+00:00

An online sleuth has revealed how he was able to crack into a crucial piece of evidence in Gwyneth Paltrow's ski crash trial and submit it to her lawyers.

## Dan Andrew's is blasted by Dr Nick Coatsworth as he jets off to China
 - [https://www.dailymail.co.uk/news/article-11913133/Dan-Andrews-blasted-Dr-Nick-Coatsworth-jets-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913133/Dan-Andrews-blasted-Dr-Nick-Coatsworth-jets-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 02:54:31+00:00

Dan Andrews flew out on his seventh trip to China on Monday night for meetings with officials - but is ignoring the plight of a Melbourne mum held in detention by the Chinese after a secret trial.

## Melbourne woman recalls moment she found stranger living in her garage unnoticed for months
 - [https://www.dailymail.co.uk/news/article-11913435/Melbourne-woman-recalls-moment-stranger-living-garage-unnoticed-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913435/Melbourne-woman-recalls-moment-stranger-living-garage-unnoticed-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 02:45:58+00:00

A renter has recalled the wild moment she discovered a stranger was living in the detached garage of her rental and how she had 'no idea' because a fear of spiders kept her out of the space.

## Ray Hadley: Why is Australia paying for Barack Obama's protection when he got $1m for two speeches
 - [https://www.dailymail.co.uk/news/article-11913175/Ray-Hadley-Australia-paying-Barack-Obamas-protection-got-1m-two-speeches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913175/Ray-Hadley-Australia-paying-Barack-Obamas-protection-got-1m-two-speeches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 02:40:57+00:00

A radio host has slammed the cost of police protection for Barack Obama's Australian speaking tour, saying it should have come out of his own $1million payday.

## Western Australia to ban plastic coffee cups
 - [https://www.dailymail.co.uk/news/article-11913285/Western-Australia-ban-plastic-coffee-cups.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913285/Western-Australia-ban-plastic-coffee-cups.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 02:40:49+00:00

Western Australia is banning all single-use coffee cups in favour of compostable alternatives by March 2024.

## TikTok poster breaks down the body language between Anthony Albanese and Barack Obama
 - [https://www.dailymail.co.uk/news/article-11913555/TikTok-poster-breaks-body-language-Anthony-Albanese-Barack-Obama.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913555/TikTok-poster-breaks-body-language-Anthony-Albanese-Barack-Obama.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 02:40:07+00:00

An amateur body language analyst has taken to TikTok to post his own interpretation of the picture of Prime Minister Anthony Albanese welcoming former US President Obama's to Sydney.

## Fugees star Pras Michel pictured outside court ahead of trial related to Malaysian scammer Jho Low
 - [https://www.dailymail.co.uk/news/article-11913723/Fugees-star-Pras-Michel-pictured-outside-court-ahead-trial-related-Malaysian-scammer-Jho-Low.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913723/Fugees-star-Pras-Michel-pictured-outside-court-ahead-trial-related-Malaysian-scammer-Jho-Low.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 02:39:59+00:00

Pras Michel, former member of The Fugees, was spotted in Washington DC on Tuesday outside the court where he is on trial for his work with Malaysian fraudster Jho Low.

## Cute video shows K9 sniffer dog swung around by cop as they play outside Cairns Airport, Queensland
 - [https://www.dailymail.co.uk/news/article-11913535/Cute-video-shows-K9-sniffer-dog-swung-cop-play-outside-Cairns-Airport-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913535/Cute-video-shows-K9-sniffer-dog-swung-cop-play-outside-Cairns-Airport-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 02:20:16+00:00

A video of a cop playfully swinging his K9 sniffer dog around with a toy in its mouth has gone viral and delighted viewers, with the officer's canine friend profusely wagging its tail as they play.

## TV star Paul O'Grady dies aged 67
 - [https://www.dailymail.co.uk/news/article-11913831/TV-star-Paul-OGrady-dies-aged-67.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913831/TV-star-Paul-OGrady-dies-aged-67.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 02:14:26+00:00

TV presenter and comedian Paul O'Grady has died at the age of 67, his partner Andre Portasio has said.

## LA property developer offering home buyers a free supercar if they buy $16.5M mansion
 - [https://www.dailymail.co.uk/news/article-11913649/LA-property-developer-offering-home-buyers-free-supercar-buy-16-5M-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913649/LA-property-developer-offering-home-buyers-free-supercar-buy-16-5M-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 02:07:47+00:00

Several agents and sellers are trying to bypass the Measure ULA - dubbed 'mansion tax' - which ups sales taxes at the end of the month by offer luxury products and dramatic price drops.

## Russian first major tank formation in Ukraine war is already hit 'with heavy losses' with low morale
 - [https://www.dailymail.co.uk/news/article-11913665/Russian-major-tank-formation-Ukraine-war-hit-heavy-losses-low-morale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913665/Russian-major-tank-formation-Ukraine-war-hit-heavy-losses-low-morale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:56:29+00:00

A Russian tank formation intended to cause devastation in Ukraine has been hit with heavy losses due to low morale and poor discipline, it has been reported.

## Horrifying moment thief who stole police car leaps from driver's seat of speeding cruiser
 - [https://www.dailymail.co.uk/news/article-11913609/Horrifying-moment-thief-stole-police-car-leaps-drivers-seat-speeding-cruiser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913609/Horrifying-moment-thief-stole-police-car-leaps-drivers-seat-speeding-cruiser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:54:59+00:00

A high-speed chase in California ended in tragedy Tuesday, when a suspect jumped from a stolen CHP vehicle and died after smashing into the middle of the freeway.

## Commando Heston Russell names the one group that is 'most marginalised' in society
 - [https://www.dailymail.co.uk/news/article-11913231/Commando-Heston-Russell-names-one-group-marginalised-society.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913231/Commando-Heston-Russell-names-one-group-marginalised-society.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:44:23+00:00

Heston Russell, who completed four deployments to Afghanistan, has taken aim at what he calls 'the most shameful and disgraceful treatment of our modern day heroes'.

## Mitsubishi Lancer in Bayswater, Perth could be Australia's most unroadworthy car
 - [https://www.dailymail.co.uk/news/article-11913193/Mitsubishi-Lancer-Bayswater-Perth-Australias-unroadworthy-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913193/Mitsubishi-Lancer-Bayswater-Perth-Australias-unroadworthy-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:39:51+00:00

A Mitsubishi Lancer owner was pulled over by police on Guildford Road in Bayswater north east of Perth on Tuesday before he was arrested and slapped with charges.

## Melanie O'Sullivan found dead on Mill Creek Road in the Hunter Valley
 - [https://www.dailymail.co.uk/news/article-11913729/Girl-17-dead-Creek-Road-Stroud-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913729/Girl-17-dead-Creek-Road-Stroud-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:15:54+00:00

A body has been located during the search for a girl reported missing from the Upper Hunter yesterday.

## Coalition MPs apologise after young Parliamentary worker was injured during 'disgusting' incident
 - [https://www.dailymail.co.uk/news/article-11913257/Coalition-MPs-apologise-young-Parliamentary-worker-injured-disgusting-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913257/Coalition-MPs-apologise-young-Parliamentary-worker-injured-disgusting-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:14:38+00:00

Dan Tehan, Angus Taylor, Zoe McKenzie and Andrew Hastie were among MPs to apologise in the House of Representatives over the fracas on Wednesday morning.

## Distressing moment at least 40 migrants are left to burn to death at Mexican detention center
 - [https://www.dailymail.co.uk/news/article-11913379/Distressing-moment-40-migrants-left-burn-death-Mexican-detention-center.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913379/Distressing-moment-40-migrants-left-burn-death-Mexican-detention-center.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:10:36+00:00

A distressing video has captured the moment guards at a Mexican detention center left at least 40 migrants to burn to death after they set mattresses ablaze to protest their conditions.

## Murdered Nashville headteacher ran TOWARDS trans shooter to protect her children
 - [https://www.dailymail.co.uk/news/article-11913503/Murdered-Nashville-headteacher-ran-trans-shooter-protect-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913503/Murdered-Nashville-headteacher-ran-trans-shooter-protect-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:10:17+00:00

Katherine Koonce, 60, ran towards the sound of gunfire, a member of Nashville city council has said. He said Koonce was on a Zoom call at the time, and went to help her students.

## Anger as Robert Smith is paroled 12 years after murder of Kiesha Weippeart by mum Kristi Abrahams
 - [https://www.dailymail.co.uk/news/article-11913127/Anger-Robert-Smith-paroled-12-years-murder-Kiesha-Weippeart-mum-Kristi-Abrahams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913127/Anger-Robert-Smith-paroled-12-years-murder-Kiesha-Weippeart-mum-Kristi-Abrahams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:09:25+00:00

Robert Smith, who is serving a minimum 12-year jail sentence for being an accessory to the murder of six-year-old Kiesha Weippeart in 2010, is set to be released as early as April 21.

## Victorian Native Title ruling grants Great Ocean Road tourist sites to Eastern Maar peoples
 - [https://www.dailymail.co.uk/news/article-11913219/Victorian-Native-Title-ruling-grants-Great-Ocean-Road-tourist-sites-Eastern-Maar-peoples.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913219/Victorian-Native-Title-ruling-grants-Great-Ocean-Road-tourist-sites-Eastern-Maar-peoples.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:08:49+00:00

A huge area taking in one of Australia's most famous tourist sites, the Twelve Apostles, has been recognised as Aboriginal land in a historic and very emotional Native Title decision.

## Fruit-flavoured disposable vapes targeted to children set to be banned, as ministers launch review
 - [https://www.dailymail.co.uk/news/article-11913627/Fruit-flavoured-disposable-vapes-targeted-children-set-banned-ministers-launch-review.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913627/Fruit-flavoured-disposable-vapes-targeted-children-set-banned-ministers-launch-review.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:07:46+00:00

Highly-addictive and brightly coloured nicotine-filled vapes such as Elf Bars (file photo) are set to be targeted in a clampdown in an announcement by ministers.

## Australian inflation drops for a second month ahead of another Reserve Bank interest rate call
 - [https://www.dailymail.co.uk/news/article-11913719/Australian-inflation-drops-second-month-ahead-Reserve-Bank-rate-call.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913719/Australian-inflation-drops-second-month-ahead-Reserve-Bank-rate-call.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:05:41+00:00

The Australian Bureau of Statistics said it was the second month in a row of lower annual inflation - down from a high of 8.4 per cent in December 2022.

## Charles Bronson tells his ex-wife he is confident he will walk free from jail this week
 - [https://www.dailymail.co.uk/news/article-11913543/Charles-Bronson-tells-ex-wife-confident-walk-free-jail-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913543/Charles-Bronson-tells-ex-wife-confident-walk-free-jail-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:03:58+00:00

Having been locked away for almost 50 years, 70-year-old Woodhill inmate Charles Bronson (pictured) will hear later this week whether his latest bid for parole has been successful.

## Sir David Jason's wife tells how the couple told their 'only child' Sophie he had ANOTHER daughter
 - [https://www.dailymail.co.uk/news/article-11913639/Sir-David-Jasons-wife-tells-couple-told-child-Sophie-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913639/Sir-David-Jasons-wife-tells-couple-told-child-Sophie-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 01:01:24+00:00

The couple revealed that after being confronted with the 'massive surprise' she had a half-sister 30 years older than her, Sophie had taken the revelation with 'great understanding and maturity'.

## NC woman sells 1920s Cartier purse for $7,500 after picking it up for a DOLLAR from online auction
 - [https://www.dailymail.co.uk/news/article-11913455/NC-woman-sells-1920s-Cartier-purse-7-500-picking-DOLLAR-online-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913455/NC-woman-sells-1920s-Cartier-purse-7-500-picking-DOLLAR-online-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:45:09+00:00

Chandler West, 29, of Charlotte, bought an antique 1920s Cartier Art Deco evening bag for a $1 in November 2021 at an online estate sale, having no idea what it was worth.

## Happiest cities in US revealed: Fremont, CA tops list with best wages, home prices and mental health
 - [https://www.dailymail.co.uk/news/article-11913011/Happiest-cities-revealed-Fremont-CA-tops-list-best-wages-home-prices-mental-health.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913011/Happiest-cities-revealed-Fremont-CA-tops-list-best-wages-home-prices-mental-health.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:18:02+00:00

The Golden State is listed 29 times out of the 182 cities ranked as being the happiest cities, with most of its entries being in the top 25. Fremont, California, ranked number one overall.

## Latitude Financial hack: legal firms launch investigation and potential class action seeking payouts
 - [https://www.dailymail.co.uk/news/article-11913263/Latitude-Financial-hack-legal-firms-launch-investigation-potential-class-action-seeking-payouts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913263/Latitude-Financial-hack-legal-firms-launch-investigation-potential-class-action-seeking-payouts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:10:17+00:00

An investigation into the Latitude Financial hack and a potential class action was announced on Tuesday by legal firms Hayden Stephenson and Associates and Gordon Legal.

## Lidia Thorpe brands Senator Hollie Hughes a racist for interrupting acknowledgement of country
 - [https://www.dailymail.co.uk/news/article-11913289/Lidia-Thorpe-brands-Senator-Hollie-Hughes-racist-interrupting-acknowledgement-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913289/Lidia-Thorpe-brands-Senator-Hollie-Hughes-racist-interrupting-acknowledgement-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:07:35+00:00

Lidia Thorpe has accused a Liberal politician of racism and vowed not to tolerate being 'racially vilified in her place of work'.

## Christie uses first New Hampshire visit to rail against Trump
 - [https://www.dailymail.co.uk/news/article-11913363/Christie-uses-New-Hampshire-visit-rail-against-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913363/Christie-uses-New-Hampshire-visit-rail-against-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:06:21+00:00

Former New Jersey Gov. Chris Christie returned to New Hampshire Tuesday as he mulls a 2024 presidential bid centered around taking out former President Donald Trump.

## Murdaugh family in happier times: True crime fan buys memory cards filled with family photos
 - [https://www.dailymail.co.uk/news/article-11913077/Murdaugh-family-happier-times-True-crime-fan-buys-memory-cards-filled-family-photos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913077/Murdaugh-family-happier-times-True-crime-fan-buys-memory-cards-filled-family-photos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:06:17+00:00

A true crime fan was astonished to find hundreds of never-before-seen vacation photos of the Murdaugh family on a memory card she bought at auction.

## Tewantin house where alleged teen torture occurred is destroyed in fire
 - [https://www.dailymail.co.uk/news/article-11913515/Tewantin-house-alleged-teen-torture-occurred-destroyed-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913515/Tewantin-house-alleged-teen-torture-occurred-destroyed-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:06:04+00:00

The Sunshine Coast home where a 13-year-old was allegedly attacked by three girls on March 11 was burst into flames about 1.30am on Wednesday morning, with the roof collapsing in.

## Texas squatters booted out of property after changing locks and forging lease
 - [https://www.dailymail.co.uk/news/article-11913211/Texas-squatters-booted-property-changing-locks-forging-lease.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913211/Texas-squatters-booted-property-changing-locks-forging-lease.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:04:37+00:00

Squatters who had moved into a Texas area home and changed the locks on the property's owners have been booted out after local media and police investigated.

## Now New York Times turns on Fauci: guest essay slams efforts to tamp down lab leak theory
 - [https://www.dailymail.co.uk/news/article-11913099/Now-New-York-Times-turns-Fauci-guest-essay-slams-efforts-tamp-lab-leak-theory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913099/Now-New-York-Times-turns-Fauci-guest-essay-slams-efforts-tamp-lab-leak-theory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:03:15+00:00

A New York Times columnist criticizes the way Dr. Fauci handled information during the COVID-19 pandemic.

## Lisa Wilkinson's cancer plea as she breaks cover posting on social media for first time in months
 - [https://www.dailymail.co.uk/news/article-11913113/Lisa-Wilkinsons-cancer-plea-breaks-cover-posting-social-media-time-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11913113/Lisa-Wilkinsons-cancer-plea-breaks-cover-posting-social-media-time-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-29 00:02:01+00:00

Lisa Wilkinson was a regular Instagram user until December last year, when she moved away from the limelight following a difficult 2022 that saw her publicly slammed for her Logies speech.

