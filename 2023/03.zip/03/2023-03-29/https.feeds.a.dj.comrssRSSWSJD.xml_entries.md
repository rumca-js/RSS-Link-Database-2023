# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Electronic Arts Says It Is Laying Off 6% of Workforce
 - [https://www.wsj.com/articles/electronic-arts-says-it-is-laying-off-6-of-workforce-d9c2b7e1?mod=rss_Technology](https://www.wsj.com/articles/electronic-arts-says-it-is-laying-off-6-of-workforce-d9c2b7e1?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-29 20:05:00+00:00

The company is also reducing its office-space footprint to focus its spending on the best growth opportunities in the videogame industry.

## Microsoft Patched Bing Vulnerability That Allowed Snooping on Email
 - [https://www.wsj.com/articles/microsoft-patched-bing-vulnerability-that-allowed-snooping-on-email-and-other-data-25b58831?mod=rss_Technology](https://www.wsj.com/articles/microsoft-patched-bing-vulnerability-that-allowed-snooping-on-email-and-other-data-25b58831?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-29 17:00:00+00:00

Microsoft patched a dangerous security issue in Bing last month just days before it launched a new artificial intelligence-powered version of the search engine.

## AI Bigwigs Call For Pause in Technology's Development
 - [https://www.wsj.com/articles/elon-musk-other-ai-bigwigs-call-for-pause-in-technologys-development-56327f?mod=rss_Technology](https://www.wsj.com/articles/elon-musk-other-ai-bigwigs-call-for-pause-in-technologys-development-56327f?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-29 12:33:00+00:00

Tesla CEO Elon Musk and AI pioneer Yoshua Bengio are among those calling for a pause in the breakneck development of powerful new artificial-intelligence tools.

## Don't Forget to Block Your Ex on Your Payment Apps
 - [https://www.wsj.com/articles/dont-forget-to-block-your-ex-on-your-payment-apps-207358bc?mod=rss_Technology](https://www.wsj.com/articles/dont-forget-to-block-your-ex-on-your-payment-apps-207358bc?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-29 12:00:00+00:00

Venmo, Cash App and Zelle can let undesirables send you messages—for a small fee.

## The Metaverse Is Quickly Turning Into the Meh-taverse
 - [https://www.wsj.com/articles/the-metaverse-is-quickly-turning-into-the-meh-taverse-1a8dc3d0?mod=rss_Technology](https://www.wsj.com/articles/the-metaverse-is-quickly-turning-into-the-meh-taverse-1a8dc3d0?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-03-29 09:30:00+00:00

Disney and Microsoft both closed projects tied to the metaverse this month, while Facebook parent Meta focuses on artificial intelligence.

