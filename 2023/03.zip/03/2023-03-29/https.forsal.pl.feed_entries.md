# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Vodafone likwiduje 1300 miejsc pracy w Niemczech
 - [https://forsal.pl/praca/aktualnosci/artykuly/8691151,vodafone-likwiduje-1300-miejsc-pracy-w-niemczech.html](https://forsal.pl/praca/aktualnosci/artykuly/8691151,vodafone-likwiduje-1300-miejsc-pracy-w-niemczech.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 20:01:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/E2-ktkuTURBXy9lMzIzOTQzNi0wMmQxLTQxYzgtYTEzMy1kZWQ1YzczODQ0OTQuanBlZ5GTBc0BHcyg" />Dostawca usług telekomunikacyjnych Vodafone chce zlikwidować około 1300 pełnoetatowych miejsc pracy w Niemczech. Dotyczy to głównie stanowisk administracyjnych i kierowniczych - poinformował w środę portal dziennika &quot;Handelsblatt&quot;, powołując się na nowego szefa firmy w Niemczech, Philippa Rogge.

## Polska minister wiceprzewodniczącą Rady Zarządzającej Międzynarodowej Agencji Energetycznej
 - [https://forsal.pl/biznes/energetyka/artykuly/8691133,a-moskwa-wybrana-na-wiceprzewodniczaca-rady-zarzadzajacej-miedzynarodowej-agencji-energetycznej.html](https://forsal.pl/biznes/energetyka/artykuly/8691133,a-moskwa-wybrana-na-wiceprzewodniczaca-rady-zarzadzajacej-miedzynarodowej-agencji-energetycznej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 18:34:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/c0FktkuTURBXy9lMzE2N2U1ZS0zMDkxLTQ2MDgtODlhMi1hNGNlMWM3YTc0NDcuanBlZ5GTBc0BHcyg" />Polska minister klimatu i środowiska Anna Moskwa została wybrana na wiceprzewodniczącą Rady Zarządzającej Międzynarodowej Agencji Energetycznej - wynika z informacji zamieszczonej w mediach społecznościowych szefowej resortu klimatu.

## Prezydent Czarnogóry: Serbia robi na Bałkanach to, co Rosja w swoim sąsiedztwie
 - [https://forsal.pl/artykuly/8691131,prezydent-czarnogory-serbia-robi-na-balkanach-to-co-rosja-w-swoim-sasiedztwie.html](https://forsal.pl/artykuly/8691131,prezydent-czarnogory-serbia-robi-na-balkanach-to-co-rosja-w-swoim-sasiedztwie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 18:28:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NU2ktkuTURBXy8wZjE0OGJlYS0xZDAyLTQ3YjctYTg0Ny0xNzEwMmJkNWRiNTcuanBlZ5GTBc0BHcyg" />Serbia stara się robić na Bałkanach to, co Rosja robi w swoim sąsiedztwie - powiedział w środę prezydent Czarnogóry Milo Dziukanović podczas zorganizowanego przez władze USA wirtualnego Szczytu dla Demokracji.

## Z Białorusi idzie nowa fala migracyjna? Litwa ostrzega
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8691127,litwa-msw-wznowienie-bezposrednich-lotow-z-iranu-do-minska-oznacza-nowa-fale-migracyjna.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8691127,litwa-msw-wznowienie-bezposrednich-lotow-z-iranu-do-minska-oznacza-nowa-fale-migracyjna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 18:01:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ejxktkuTURBXy9hNzg3NzA0ZS0wMjhiLTRkMzctOGZiNS1iODdhZGEyMWMyNjIuanBlZ5GTBc0BHcyg" />Wznowienie bezpośrednich lotów z Iranu do Mińska oznacza, że rozpoczyna się nowa fala nielegalnej migracji – oświadczyła w środę minister spraw wewnętrznych Litwy Agne Bilotaite. Według źródeł MSW pierwszy taki lot odbył się już we środę.

## Ukraina: Pilnie potrzebujemy nowoczesnych samolotów, takich jak F-16
 - [https://forsal.pl/swiat/ukraina/artykuly/8691125,ukraina-pilnie-potrzebujemy-nowoczesnych-samolotow-takich-jak-f-16.html](https://forsal.pl/swiat/ukraina/artykuly/8691125,ukraina-pilnie-potrzebujemy-nowoczesnych-samolotow-takich-jak-f-16.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 17:36:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FGkktkuTURBXy9jODZiY2IxYy1jMTVhLTRhYzktODMyZi0xNjVjNzZkOGRkZGUuanBlZ5GTBc0BHcyg" />Polskie lub czeskie myśliwce MiG-29 pomogą naszej armii, ale nie stanowią znaczącego wsparcia, podobnie jak francuskie Mirage 2000 lub brytyjsko-niemiecko-włoskie Tornado; pilnie potrzebujemy samolotów wielozadaniowych czwartej generacji i nowszych, takich jak amerykańskie F-16 - ocenił w środę rzecznik ukraińskich sił powietrznych Jurij Ihnat.

## Rafał Dutkiewicz wybrany na prezesa Pracodawców RP
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8691120,rafal-dutkiewicz-wybrany-na-prezesa-pracodawcow-rp.html](https://forsal.pl/biznes/aktualnosci/artykuly/8691120,rafal-dutkiewicz-wybrany-na-prezesa-pracodawcow-rp.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 17:31:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ig8ktkuTURBXy8zOTA4NmRmMy02M2IxLTRjNmUtODhkZC1kODA4NTIxNTdjYzEuanBlZ5GTBc0BHcyg" />Rada Pracodawców RP zdecydowała dziś o wyborze Rafała Dutkiewicza na stanowisko Prezesa Zarządu Pracodawców RP – podano w informacji prasowej.

## Polska wystąpi do UE o klauzulę ochronną dot. granicy z Ukrainą
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8691032,polska-wystapi-do-ue-o-klauzule-ochronna-dot-granicy-z-ukraina.html](https://forsal.pl/biznes/rolnictwo/artykuly/8691032,polska-wystapi-do-ue-o-klauzule-ochronna-dot-granicy-z-ukraina.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 16:55:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/np2ktkuTURBXy85YzA1YTBmNi0xOTM3LTRiMDktYWZjNC0wNmMyNTg2ZTgxMGUuanBlZ5GTBc0BHcyg" />Rząd, w związku z napływem ukraińskiego zboża, złoży na forum UE, wniosek o zastosowanie klauzuli ochronnej dotyczącej granicy polsko-ukraińskiej - poinformował podczas środowej konferencji prasowej po zakończeniu rolniczego &quot;okrągłego stołu&quot; szef resortu rolnictwa Henryk Kowalczyk.

## Alarm w Holandii. Hakerzy wykradli dane ponad 1,5 mln osób
 - [https://forsal.pl/lifestyle/technologie/artykuly/8690944,alarm-w-holandii-hakerzy-wykradli-dane-ponad-15-mln-osob.html](https://forsal.pl/lifestyle/technologie/artykuly/8690944,alarm-w-holandii-hakerzy-wykradli-dane-ponad-15-mln-osob.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 16:32:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YNzktkuTURBXy8wYmE3MTUwNi1iOTc5LTRhYjctYjJhOS0wYTdmYmFlYWRkYmQuanBlZ5GTBc0BHcyg" />Hakerzy wykradli dane klientów firmy telekomunikacyjnej VodafoneZiggo - alarmują niderlandzkie media. We wtorek o kradzieży danych poinformowały także holenderskie koleje (NS).

## Z hoteli do dawnych baz wojskowych. Brytyjczycy zmieniają politykę ws. nielegalnych imigrantów
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8690939,z-hoteli-do-dawnych-baz-wojskowych-brytyjczycy-zmieniaja-polityke-ws-nielegalnych-imigrantow.html](https://forsal.pl/swiat/aktualnosci/artykuly/8690939,z-hoteli-do-dawnych-baz-wojskowych-brytyjczycy-zmieniaja-polityke-ws-nielegalnych-imigrantow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 16:07:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/m6KktkuTURBXy8wOThiNDJhNy1hZDZiLTQ2MTctOWU4OS1iOTg1NzFhMzEyYmMuanBlZ5GTBc0BHcyg" />Brytyjski rząd ogłosił w środę, że kilka tysięcy nielegalnych imigrantów zostanie przekwaterowanych z hoteli do trzech dawnych baz wojskowych oraz że bada możliwość wykorzystywania do tego celu także nieużywanych promów, choć w tej sprawie nie zapadły jeszcze decyzje.

## "Utrata kontroli nad cywilizacją". Elon Musk i setki badaczy wzywają do wstrzymania prac nad sztuczną inteligencją
 - [https://forsal.pl/lifestyle/technologie/artykuly/8690938,utrata-kontroli-nad-cywilizacja-setki-badaczy-chca-pauzy-w-rozwoju-sztucznej-inteligencji.html](https://forsal.pl/lifestyle/technologie/artykuly/8690938,utrata-kontroli-nad-cywilizacja-setki-badaczy-chca-pauzy-w-rozwoju-sztucznej-inteligencji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 15:58:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qqIktkuTURBXy9kMWRkZWUzNy0xZWQ4LTQ1MTUtOGNlZS03YTdjN2MwODc3NzkuanBlZ5GTBc0BHcyg" />Setki biznesmenów, inwestorów i ekspertów od sztucznej inteligencji, w tym m.in. Elon Musk, wezwało we wspólnym liście do przynajmniej sześciomiesięcznej przerwy w rozwijaniu systemów AI zdolniejszych od opublikowanego w marcu GPT-4. Sygnatariusze ostrzegają przed nieprzewidywalnymi skutkami wyścigu o tworzenie coraz potężniejszych modeli.

## Zielono na GPW. WIG20 w górę 0,9 proc.
 - [https://forsal.pl/finanse/gielda/artykuly/8690932,zielono-na-gpw-wig20-w-gore-09-proc.html](https://forsal.pl/finanse/gielda/artykuly/8690932,zielono-na-gpw-wig20-w-gore-09-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 15:40:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1cWktkuTURBXy81N2ZmN2JhYi04ZjFmLTRiYjEtYTU1Ni0wNmRiZTI4OWU2Y2UuanBlZ5GTBc0BHcyg" />undefined

## „La Libre”: Chatbot namówił mężczyznę do popełnienia samobójstwa
 - [https://forsal.pl/lifestyle/technologie/artykuly/8690930,la-libre-chatbot-namowil-mezczyzne-do-popelnienia-samobojstwa.html](https://forsal.pl/lifestyle/technologie/artykuly/8690930,la-libre-chatbot-namowil-mezczyzne-do-popelnienia-samobojstwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 15:36:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AmjktkuTURBXy8zZWJiZmE2YS05Yjk3LTRkYjktYmNlZi1mYzllM2Y5OGQwZGEuanBlZ5GTBc0BHcyg" />Chatbot amerykańskiej firmy Chai namówił młodego Belga do samobójstwa - poinformował dziennik „La Libre”. Mężczyzna odebrał sobie życie po długich rozmowach z chatbotem.

## Kułeba dla "FT": Kreml jest „absolutnie wściekły na Chiny za ich postawę i brak wsparcia"
 - [https://forsal.pl/swiat/rosja/artykuly/8690929,kuleba-dla-ft-kreml-jest-absolutnie-wsciekly-na-chiny-za-ich-postawe-i-brak-wsparcia.html](https://forsal.pl/swiat/rosja/artykuly/8690929,kuleba-dla-ft-kreml-jest-absolutnie-wsciekly-na-chiny-za-ich-postawe-i-brak-wsparcia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 15:32:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SC6ktkuTURBXy8yMjIwZjJkNy1iNDY5LTQ1MzktOTBlNC0xZWM3NGI4M2VlNjYuanBlZ5GTBc0BHcyg" />W wywiadzie dla dziennika &quot;Financial Times&quot; opublikowanym w środę szef ukraińskiej dyplomacji Dmytro Kułeba ocenia, że Pekin zastanawia się jeszcze, czy zaangażować się w proces pokojowy, który zakończyłby rosyjską agresję na Ukrainie. Szef MSZ Chin Qin Gang miał powiedzieć Kułebie, że Pekin nie będzie dostarczać Rosji broni.

## Spółka do budowy elektrowni jądrowej. PGE i ZE PAK mają zgodę UOKiK
 - [https://forsal.pl/biznes/energetyka/artykuly/8690921,spolka-do-budowy-elektrowni-jadrowej-pge-i-ze-pak-maja-zgode-uokik.html](https://forsal.pl/biznes/energetyka/artykuly/8690921,spolka-do-budowy-elektrowni-jadrowej-pge-i-ze-pak-maja-zgode-uokik.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 15:15:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JgSktkuTURBXy9hOTZkOWVjNS02MThmLTRiN2UtYjg5Ny1jODA1MzVjYWFmMjMuanBlZ5GTBc0BHcyg" />undefined

## Ukraiński minister sportu: Nawet 70 proc. sportowców z Rosji i Białorusi to żołnierze
 - [https://forsal.pl/swiat/ukraina/artykuly/8690901,ukrainski-minister-sportu-nawet-70-proc-sportowcow-z-rosji-i-bialorusi-to-zolnierze.html](https://forsal.pl/swiat/ukraina/artykuly/8690901,ukrainski-minister-sportu-nawet-70-proc-sportowcow-z-rosji-i-bialorusi-to-zolnierze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 14:09:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/M-jktkuTURBXy8wZDllYmEyMi1mZjEzLTRjY2EtYWQwOC0yNGUzZmU1MmE1ODUuanBlZ5GTBc0BHcyg" />Wielokrotnie informowaliśmy Międzynarodowy Komitet Olimpijski (MKOl), że nawet 70 proc. sportowców z Rosji i Białorusi służy w armiach lub strukturach siłowych tych państw - oznajmił w środę ukraiński minister sportu Wadym Hutcajt, komentując wtorkową decyzję MKOl o częściowym przywróceniu udziału Rosjan i Białorusinów w międzynarodowych zawodach sportowych.

## Dobre wiadomości dla kierowców. Paliwa na stacjach nadal tanieją
 - [https://forsal.pl/biznes/energetyka/artykuly/8690896,dobre-wiadomosci-dla-kierowcow-paliwa-na-stacjach-nadal-tanieja.html](https://forsal.pl/biznes/energetyka/artykuly/8690896,dobre-wiadomosci-dla-kierowcow-paliwa-na-stacjach-nadal-tanieja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 14:01:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fl8ktkuTURBXy9mMzcwYjc4MS03NmI4LTQ1Y2UtYmFlYy0zYmUyY2MwOTI4ZGYuanBlZ5GTBc0BHcyg" />Paliwa na stacjach nadal tanieją - podali w środę analitycy portalu e-petrol.pl. Litr diesla kosztuje obecnie średnio 6,75 zł, co oznacza obniżkę o 14 gr. O 6 gr tańsza niż przed tygodniem jest też benzyna Pb95, która kosztuje średnio 6,62 zł/l - dodali.

## Kolejny przypadek zakażenia człowieka wirusem grypy ptaków H3N8 w Chinach
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8690895,kolejny-przypadek-zakazenia-czlowieka-wirusem-grypy-ptakow-h3n8-w-chinach.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8690895,kolejny-przypadek-zakazenia-czlowieka-wirusem-grypy-ptakow-h3n8-w-chinach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 13:59:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SpiktkuTURBXy9mYWI5ZDM1YS0wMDBlLTQ5NzEtYjE4YS1iOTMxMzg0ODBjODAuanBlZ5GTBc0BHcyg" />Chińskie służby medyczne zgłosiły trzeci w historii przypadek zakażenia człowieka wirusem grypy ptaków H3N8 – podał w środę dziennik „South China Morning Post”. Pierwszą taką infekcję odnotowano w Chinach w ubiegłym roku.

## Słynna leśniczówka, w której mieszkała prof. Simona Kossak, ma być przeniesiona
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8690852,slynna-lesniczowka-w-ktorej-mieszkala-prof-simona-kossak-ma-byc-przeniesiona.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8690852,slynna-lesniczowka-w-ktorej-mieszkala-prof-simona-kossak-ma-byc-przeniesiona.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 13:14:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2RCktkuTURBXy9jNWMyZWYyNS1mY2E5LTQ0ZmUtYTRiNS0zN2YyYjZiN2ZlNmMuanBlZ5GTBc0BHcyg" />Białowieski Park Narodowy szuka zewnętrznego finansowania, aby przenieść w inne miejsce leśniczówkę Dziedzinka w Puszczy Białowieskiej, w której mieszkała znana biolog prof. Simona Kossak. Leśniczówka jest od wiosny 2021 r. wpisana do rejestru zabytków.

## Oto miasta z największą płynnością na rynku mieszkań w Polsce
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/8690846,oto-miasta-z-najwieksza-plynnoscia-na-rynku-mieszkan-w-polsce.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/8690846,oto-miasta-z-najwieksza-plynnoscia-na-rynku-mieszkan-w-polsce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 13:06:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uNPktkuTURBXy8zZThkNzNiNC0wZGE0LTQ4ZjQtYjFhYi02MjgxMjk4ODAzOGUuanBlZ5GTBc0BHcyg" />To nie stolica jest miastem z największą płynnością na rynku mieszkaniowym w Polsce. Liderem aktywności jest mniejsze miasto na południu Polski.

## Narodowy Program Amunicyjny. Rząd podjął uchwałę
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8690845,narodowy-program-amunicyjny-rzad-podjal-uchwale.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8690845,narodowy-program-amunicyjny-rzad-podjal-uchwale.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 13:05:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WDxktkuTURBXy8xNjEwODZlZS0wYzUxLTQyZDAtYjJmNi00NjM0OTZhOGIzYjMuanBlZ5GTBc0BHcyg" />undefined

## Kowalczyk: Jest deklaracja KE ws. uruchomienia kolejnej rezerwy kryzysowej
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8690844,kowalczyk-jest-deklaracja-ke-ws-uruchomienia-kolejnej-rezerwy-kryzysowej.html](https://forsal.pl/biznes/rolnictwo/artykuly/8690844,kowalczyk-jest-deklaracja-ke-ws-uruchomienia-kolejnej-rezerwy-kryzysowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 13:02:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YQ0ktkuTURBXy83NmY4YmM5MC1lMGZkLTRkYjUtOWJkYS0xNzg2NjNhZTg1YzcuanBlZ5GTBc0BHcyg" />Jest deklaracja Komisji Europejskiej ws. uruchomienia kolejnej rezerwy kryzysowej w rolnictwie; może to oznaczać ponad 500 mln zł na wsparcie rolników - przekazał w środę minister rolnictwa Henryk Kowalczyk. Najistotniejszym zadaniem jest to, aby na żniwa nie były zapełnione magazyny - dodał.

## Budowa domu powyżej 70 m kw. będzie możliwa na podstawie tylko zgłoszenia
 - [https://forsal.pl/nieruchomosci/artykuly/8690843,budowa-domu-powyzej-70-m-kw-bedzie-mozliwa-na-podstawie-tylko-zgloszenia.html](https://forsal.pl/nieruchomosci/artykuly/8690843,budowa-domu-powyzej-70-m-kw-bedzie-mozliwa-na-podstawie-tylko-zgloszenia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 13:00:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XfUktkuTURBXy8wZGM1NDljYi0yYzY0LTQ0YWItYmMyYi0zMjVhODZkNTU5NzIuanBlZ5GTBc0BHcyg" />Budowa jednorodzinnych budynków mieszkalnych o powierzchni zabudowy powyżej i poniżej 70 m kw., będzie możliwa na podstawie jedynie zgłoszenia - zaznaczył minister rozwoju i technologii Waldemar Buda. Jego zdaniem to kolejny krok w deregulacji prawa budowlanego.

## O ile wzrośnie polskie PKB? BGK podnosi prognozę
 - [https://forsal.pl/gospodarka/pkb/artykuly/8690839,o-ile-wzrosnie-polskie-pkb-bgk-podnosi-prognoze.html](https://forsal.pl/gospodarka/pkb/artykuly/8690839,o-ile-wzrosnie-polskie-pkb-bgk-podnosi-prognoze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 12:55:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zKKktkuTURBXy8wM2I4NjcxNi03YzFkLTRiNmUtOTVhYS1mOTdjNjI1Y2ZkZTYuanBlZ5GTBc0BHcyg" />undefined

## USA nałożyły ograniczenia na 5 chińskich firm. Chodzi o prześladowania Ujgurów
 - [https://forsal.pl/swiat/usa/artykuly/8690832,usa-nalozyly-ograniczenia-na-5-chinskich-firm-chodzi-o-przesladowania-ujgurow.html](https://forsal.pl/swiat/usa/artykuly/8690832,usa-nalozyly-ograniczenia-na-5-chinskich-firm-chodzi-o-przesladowania-ujgurow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 12:49:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fhsktkuTURBXy83Yzc3ZGQ4Zi00OGU4LTQzNWYtYTdkZi04ZTYwY2JmNDlhNTguanBlZ5GTBc0BHcyg" />Amerykański rząd wpisał pięć chińskich firm na listę podmiotów podlegających poważnym ograniczeniom w handlu z USA. Przedsiębiorstwa zajmujące się m.in. produkcją kamer monitoringu znalazły się w rejestrze z powodu ich roli w prześladowaniu muzułmańskiej mniejszości Ujgurów przez władze w Pekinie.

## Budowa domów jednorodzinnych będzie łatwiejsza. Rząd przyjął projekt ustawy
 - [https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8690830,budowa-domow-jednorodzinnych-bedzie-latwiejsza-rzad-przyjal-projekt-ustawy.html](https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8690830,budowa-domow-jednorodzinnych-bedzie-latwiejsza-rzad-przyjal-projekt-ustawy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 12:45:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SivktkuTURBXy9jNjdmNWQyOS01YjE0LTQwNTYtYjQ5Yi02N2QxZGUwMzEyZjIuanBlZ5GTBc0BHcyg" />Premier Mateusz Morawiecki poinformował w środę, że rząd przyjął projekt ustawy, która ma na celu wprowadzenie &quot;jeszcze większych ułatwień&quot; w budowie domów jednorodzinnych, w procesie budowlanym. Zaznaczył, że nie będzie to dotyczyło deweloperów tylko osób indywidualnych.

## Polska ograniczy napływ ukraińskiego zboża. Premier zabrał głos
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8690827,polska-ograniczy-naplyw-ukrainskiego-zboza-premier-zabral-glos.html](https://forsal.pl/biznes/rolnictwo/artykuly/8690827,polska-ograniczy-naplyw-ukrainskiego-zboza-premier-zabral-glos.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 12:38:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ejJktkuTURBXy83MTA2YzYwZi1kNjY4LTQ2MzMtYTlhNS1mYjRhMjg2MmUyNmUuanBlZ5GTBc0BHcyg" />Wypracowanie odpowiednich zasad, które będą pozwalały na ograniczenie napływu ukraińskiego zboża do Polski ma przygotować wicepremier i minister rolnictwa Henryk Kowalczyk - poinformował w środę premier Mateusz Morawiecki na konferencji po posiedzeniu Rady Ministrów.

## Likwidacja użytkowania wieczystego. Premier: Skorzysta 450 tys. podmiotów
 - [https://forsal.pl/nieruchomosci/artykuly/8690826,likwidacja-uzytkowania-wieczystego-premier-skorzysta-450-tys-podmiotow.html](https://forsal.pl/nieruchomosci/artykuly/8690826,likwidacja-uzytkowania-wieczystego-premier-skorzysta-450-tys-podmiotow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 12:35:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/K8ektkuTURBXy81MGFhMGI1MS0yOTBmLTQxYTItYjg4ZC05MzNiOGQ3MmRkMzUuanBlZ5GTBc0BHcyg" />Umożliwimy przedsiębiorcom, spółdzielniom i wspólnotom mieszkaniowym uzyskanie na własność gruntów, które mają od wielu lat w użytkowaniu wieczystym; skorzysta na tym ok. 450 tys. podmiotów - podkreślił w środę po posiedzeniu rządu premier Mateusz Morawiecki.

## Mięso hodowane w laboratorium. Dlaczego Włochy chcą wprowadzić zakaz ws. produkcji?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8690825,mieso-hodowane-w-laboratorium-dlaczego-wlochy-chca-wprowadzic-zakaz-ws-produkcji.html](https://forsal.pl/swiat/aktualnosci/artykuly/8690825,mieso-hodowane-w-laboratorium-dlaczego-wlochy-chca-wprowadzic-zakaz-ws-produkcji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 12:24:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JhAktkuTURBXy83NzYyNzM3MC1hYTlhLTRhZjQtOTI4Mi00MzE5ZjBkZmU2OTkuanBlZ5GTBc0BHcyg" />Zakaz produkcji i sprzedaży mięsa hodowanego w laboratorium – to pomysł włoskiego rządu. W ten sposób władze chcą „chronić dziedzictwo kulinarne” – informuje Bloomberg.

## Koniec z użytkowaniem wieczystym. Grunty przejmą firmy i spółdzielnie mieszkaniowe
 - [https://forsal.pl/gospodarka/prawo/artykuly/8690803,koniec-z-uzytkowaniem-wieczystym-grunty-przejma-firmy-i-spoldzielnie-mieszkaniowe.html](https://forsal.pl/gospodarka/prawo/artykuly/8690803,koniec-z-uzytkowaniem-wieczystym-grunty-przejma-firmy-i-spoldzielnie-mieszkaniowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 11:45:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VgqktkuTURBXy8wYzM3Yzc2OC1lOGQyLTRhNDYtYTk4My0xYWRiOGMzZmRkMGEuanBlZ5GTBc0BHcyg" />Umożliwienie m.in. firmom, osobom fizycznym czy spółdzielniom mieszkaniowym uzyskania na własność gruntów, które mają w użytkowaniu wieczystym, umożliwia ustawa, której projekt przyjął rząd - wskazał w środę PAP minister rozwoju Waldemar Buda. Eliminujemy użytkowanie wieczyste w Polsce - dodał.

## USA nie będą przekazywały Rosji danych o swoich siłach jądrowych
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8690790,usa-nie-beda-przekazywaly-rosji-danych-o-swoich-silach-jadrowych.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8690790,usa-nie-beda-przekazywaly-rosji-danych-o-swoich-silach-jadrowych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 11:24:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AcJktkuTURBXy8yYmVjNGRjNi04MGJmLTQ3ODEtODFmOS02YWNjZWJiYTRlOTYuanBlZ5GTBc0BHcyg" />USA poinformowały Rosję, że nie będą już przekazywać jej kluczowych danych o swoich strategicznych siłach jądrowych; jest to rezultat decyzji Moskwy o zawieszeniu udziału w traktacie Nowy START, ograniczającym broń jądrową dalekiego zasięgu – podała w środę agencja AFP.

## Braki kadrowe w Policji. Lewica domaga się informacji
 - [https://forsal.pl/gospodarka/polityka/artykuly/8690784,braki-kadrowe-w-policji-lewica-domaga-sie-informacji.html](https://forsal.pl/gospodarka/polityka/artykuly/8690784,braki-kadrowe-w-policji-lewica-domaga-sie-informacji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 11:09:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lLWktkuTURBXy9lOTgxOGQzNC03OTQwLTRjMzktODFmZC1mNTQ1NDkwZWIwYWIuanBlZ5GTBc0BHcyg" />Szef klubu Lewicy Krzysztof Gawkowski zapowiedział w środę, że będzie wnioskował o informację szefa MSWiA Mariusza Kamińskiego ws. braków kadrowych w policji. &quot;Chcemy wiedzieć, ilu funkcjonariuszy brakuje i jakie są plany, żeby więcej ludzi przychodziło, a nie odchodziło&quot; - mówił.

## S&amp;P utrzymał rating Alior Banku na poziomie BB z perspektywą stabilną
 - [https://forsal.pl/finanse/gielda/artykuly/8690775,sp-utrzymal-rating-alior-banku-na-poziomie-bb-z-perspektywa-stabilna.html](https://forsal.pl/finanse/gielda/artykuly/8690775,sp-utrzymal-rating-alior-banku-na-poziomie-bb-z-perspektywa-stabilna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:58:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5TKktkuTURBXy9kYzNiNjk3MC03YjU1LTRlMzEtYWVjZi01MDYwNDY5OGNkOWQuanBlZ5GTBc0BHcyg" />undefined

## Lokum Deweloper uzależnia dywidendę od sytuacji rynkowej, decyzję ogłosi w maju
 - [https://forsal.pl/finanse/gielda/artykuly/8690773,lokum-deweloper-uzaleznia-dywidende-od-sytuacji-rynkowej-decyzje-oglosi-w-maju.html](https://forsal.pl/finanse/gielda/artykuly/8690773,lokum-deweloper-uzaleznia-dywidende-od-sytuacji-rynkowej-decyzje-oglosi-w-maju.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:54:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zn1ktkuTURBXy8yN2U3OTYxYS0wNWVmLTRmYzctOTgwNC1mZjkyOWJkYjkyZTkuanBlZ5GTBc0BHcyg" />undefined

## Pepees rekomenduje 0,09 zł dywidendy na akcję z zysku za 2022 i kapitału zapasowego
 - [https://forsal.pl/finanse/gielda/artykuly/8690772,pepees-rekomenduje-009-zl-dywidendy-na-akcje-z-zysku-za-2022-i-kapitalu-zapasowego.html](https://forsal.pl/finanse/gielda/artykuly/8690772,pepees-rekomenduje-009-zl-dywidendy-na-akcje-z-zysku-za-2022-i-kapitalu-zapasowego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:50:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2-9ktkuTURBXy8yODU2ZDUxZS1hZjRlLTQ5MDktODlmNC05M2Y0OGYyNWI4MGIuanBlZ5GTBc0BHcyg" />undefined

## Asbis rekomenduje 0,25 USD dywidendy na akcję, oprócz 0,2 USD zaliczki
 - [https://forsal.pl/finanse/artykuly/8690768,asbis-rekomenduje-025-usd-dywidendy-na-akcje-oprocz-02-usd-zaliczki.html](https://forsal.pl/finanse/artykuly/8690768,asbis-rekomenduje-025-usd-dywidendy-na-akcje-oprocz-02-usd-zaliczki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:47:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EFmktkuTURBXy82ZmM3ZjJkNS1lY2M4LTQ2NmItYTU5NC1kNDZhNDJkNTNjOTAuanBlZ5GTBc0BHcyg" />undefined

## Pepees miał 10,6 mln zł zysku netto, 40,72 mln zł zysku EBITDA w  2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690767,pepees-mial-106-mln-zl-zysku-netto-4072-mln-zl-zysku-ebitda-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690767,pepees-mial-106-mln-zl-zysku-netto-4072-mln-zl-zysku-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:43:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DtcktkuTURBXy84OTllYTg0Ni0zMWU2LTQwYmQtYjIxZC00NzJiOTQ4MjlmOWMuanBlZ5GTBc0BHcyg" />undefined

## Atende miało 1,32 mln zł zysku netto, 12,9 mln zł zysku EBITDA w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690766,atende-mialo-132-mln-zl-zysku-netto-129-mln-zl-zysku-ebitda-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690766,atende-mialo-132-mln-zl-zysku-netto-129-mln-zl-zysku-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:39:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yKBktkuTURBXy9lZmQ3MDc5NS0zNDk2LTQxNTYtODIyMS1lYTAxYWYyNTI0MzUuanBlZ5GTBc0BHcyg" />undefined

## Brand24 miał 1,55 mln zł zysku netto, 5,3 mln zł zysku EBITDA w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690765,brand24-mial-155-mln-zl-zysku-netto-53-mln-zl-zysku-ebitda-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690765,brand24-mial-155-mln-zl-zysku-netto-53-mln-zl-zysku-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:37:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EhBktkuTURBXy83NmQxNDRiYi05ZTE3LTQyMjQtYjllMS1kNjEzM2Q2ZmZiZmEuanBlZ5GTBc0BHcyg" />undefined

## R22 planuje kontynuację wypłat min. 30 proc. skonsolidowanego zysku na dywidendę
 - [https://forsal.pl/artykuly/8690763,r22-planuje-kontynuacje-wyplat-min-30-proc-skons-zysku-na-dywidende-ebitda-dlug-ponizej-2.html](https://forsal.pl/artykuly/8690763,r22-planuje-kontynuacje-wyplat-min-30-proc-skons-zysku-na-dywidende-ebitda-dlug-ponizej-2.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:35:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bfEktkuTURBXy81MTY0NTc4MS01MDE0LTRjYjMtOTk0MS1kYjRiNDVjN2E3MjYuanBlZ5GTBc0BHcyg" />undefined

## Vercom miał 31,42 mln zł zysku netto, ponad 55 mln zł skoryg. zysku EBITDA w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690760,vercom-mial-3142-mln-zl-zysku-netto-ponad-55-mln-zl-skoryg-zysku-ebitda-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690760,vercom-mial-3142-mln-zl-zysku-netto-ponad-55-mln-zl-skoryg-zysku-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:31:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oYVktkuTURBXy8yMDI4MDJhYy02MGFjLTQyMDYtYTlhMC0yODQ2MjI0NTNiM2YuanBlZ5GTBc0BHcyg" />undefined

## Ultimate Games miał szacunkowo 8,4 mln zł skonsolidowanej straty netto w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690758,ultimate-games-mial-szacunkowo-84-mln-zl-skonsolidowanej-straty-netto-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690758,ultimate-games-mial-szacunkowo-84-mln-zl-skonsolidowanej-straty-netto-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:28:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fOzktkuTURBXy85MjNlMTUxMy03YjVmLTRmMDEtYWQxYS1lN2IzZDQ5Nzc2OWQuanBlZ5GTBc0BHcyg" />undefined

## R22 miało 24,01 mln zł zysku netto, 100,92 mln zł zysku EBITDA w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690754,r22-mialo-2401-mln-zl-zysku-netto-10092-mln-zl-zysku-ebitda-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690754,r22-mialo-2401-mln-zl-zysku-netto-10092-mln-zl-zysku-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:24:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8dUktkuTURBXy9jOTEzYjFiZi05ZDZlLTQ1OTUtOWY4Ni02NjU4MGFkZmRmODMuanBlZ5GTBc0BHcyg" />undefined

## Drago rozpoczyna skup do 1,85 proc. akcji własnych. Cena wyniesie od 33 do 100 zł za akcję
 - [https://forsal.pl/finanse/gielda/artykuly/8690753,drago-rozpoczyna-skup-do-185-proc-akcji-wlasnych-cena-wyniesie-od-33-do-100-zl-za-akcje.html](https://forsal.pl/finanse/gielda/artykuly/8690753,drago-rozpoczyna-skup-do-185-proc-akcji-wlasnych-cena-wyniesie-od-33-do-100-zl-za-akcje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:21:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jZUktkuTURBXy81MTFhNDNjNC1kMThlLTQ5NDAtYjUyNS1hNGFiYmE0YjJlY2YuanBlZ5GTBc0BHcyg" />undefined

## Alitalia będzie musiała zwrócić 400 mln euro włoskiemu rządowi
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8690744,alitalia-bedzie-musiala-zwrocic-400-mln-euro-wloskiemu-rzadowi.html](https://forsal.pl/swiat/unia-europejska/artykuly/8690744,alitalia-bedzie-musiala-zwrocic-400-mln-euro-wloskiemu-rzadowi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 10:08:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/g6NktkuTURBXy83MGU3YTllYy03ZDJkLTQ0MjAtYWUxZS05Y2Y5ZTA2NzAwNzYuanBlZ5GTBc0BHcyg" />Włoski minister finansów Giancarlo Giorgetti oświadczył, że należało spodziewać się ogłoszonej przez Komisję Europejską opinii, że udzielona w 2019 roku pożyczka pomostowa w wysokości 400 mln euro dla ówczesnych linii Alitalia była &quot;nielegalną pomocą państwa&quot; w świetle norm UE. KE oczekuje, że państwo włoskie odzyska te pieniądze od Alitalii, czyli od linii, które już nie istnieją na rynku.

## Estonia blokuje TikToka na służbowych sprzętach urzędników
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8690729,estonia-blokuje-tiktoka-na-sluzbowych-sprzetach-urzednikow.html](https://forsal.pl/biznes/aktualnosci/artykuly/8690729,estonia-blokuje-tiktoka-na-sluzbowych-sprzetach-urzednikow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 09:40:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GuCktkuTURBXy9kMzRkMWEyMi1jOTIzLTQ3MzMtYmZkOS00YzQ0MTQxNGZhMzEuanBlZ5GTBc0BHcyg" />Aplikacja TikTok zostanie zablokowana na wszystkich urządzeniach wydawanych urzędnikom przez państwo - zapowiedział cytowany w środę przez estońskie media Kristjan Jarvan, minister przedsiębiorczości i technologii Estonii.

## Polskę czeka recesja? Wiemy, do kiedy koniunktura będzie się pogarszać
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8690721,polske-czeka-recesja-wiemy-do-kiedy-koniunktura-bedzie-sie-pogarszac.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8690721,polske-czeka-recesja-wiemy-do-kiedy-koniunktura-bedzie-sie-pogarszac.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 09:21:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5DsktkuTURBXy9iZWRiNTAxMi1hMTRhLTRlNjgtYjA2NS1iODFjYmUyYmVhYWQuanBlZ5GTBc0BHcyg" />– Spodziewamy się technicznej recesji, czyli dwóch z rzędu kwartałów spadku produktu krajowego brutto wyrównanego sezonowo – mówi Piotr Bujak, główny ekonomista PKO BP.

## Polacy podzieleni w sprawie "babciowego" [SONDAŻ]
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8690702,polacy-podzieleni-w-sprawie-babciowego-sondaz.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8690702,polacy-podzieleni-w-sprawie-babciowego-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:48:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JhyktkuTURBXy8yMDQ5ODNmYS05Y2E3LTRiNjEtYjFhZC1hNjFjMzVlYjBlMjAuanBlZ5GTBc0BHcyg" />United Surveys w najnowszym sondażu przeprowadzonym na zlecenie Wirtualnej Polski zapytał Polaków, co sądzą o &quot;babciowym&quot;, czyli 1500 zł dla kobiet chcących wrócić do pracy po urlopie macierzyńskim. 51,7 proc. badanych dobrze ocenia &quot;babciowe&quot;, a 33,8 proc. nie podoba się pomysł nowego świadczenia.

## Turcja: Pracę straciło 658 tys. osób. To skutek trzęsienia ziemi
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8690694,turcja-prace-stracilo-658-tys-osob-to-skutek-trzesienia-ziemi.html](https://forsal.pl/swiat/aktualnosci/artykuly/8690694,turcja-prace-stracilo-658-tys-osob-to-skutek-trzesienia-ziemi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:38:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/krmktkuTURBXy9kNzJjN2Q4MC01MGY5LTRkYWEtODMxNy00YWMyYTY5OWE2ZDAuanBlZ5GTBc0BHcyg" />W wyniku trzęsienia ziemi z 6 lutego 2023 roku na objętych nim obszarach Turcji pracę straciło 658 tys. osób, a fizycznemu zniszczeniu uległo 150 tys. miejsc pracy - wynika z raportu Międzynarodowej Organizacji Pracy (ILO).

## Cyfrowy Polsat miał wst. 174,5 mln zł zysku netto, 818,5 mln zł skoryg. EBITDA w IV kw.
 - [https://forsal.pl/finanse/gielda/artykuly/8690684,cyfrowy-polsat-mial-wst-1745-mln-zl-zysku-netto-8185-mln-zl-skoryg-ebitda-w-4-kw.html](https://forsal.pl/finanse/gielda/artykuly/8690684,cyfrowy-polsat-mial-wst-1745-mln-zl-zysku-netto-8185-mln-zl-skoryg-ebitda-w-4-kw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:22:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/islktktTURBXy9iZTYwYzU3YS03YzY2LTRlOTMtYmU3Mi1hYTBmODcxYTlhMGQucG5nkZMFzQEdzKA" />undefined

## Rekordowy zwrot podatku. Użytkownik Pitbota otrzyma ponad 28 tysięcy złotych
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8690683,rekordowy-zwrot-podatku-uzytkownik-pitbota-otrzyma-ponad-28-tysiecy-zlotych.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8690683,rekordowy-zwrot-podatku-uzytkownik-pitbota-otrzyma-ponad-28-tysiecy-zlotych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:22:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OwJktkuTURBXy9mNDMzMzkxZS1mZjYyLTRjODQtYTljMi00NDcxOGExMThjYWIuanBlZ5GTBc0BHcyg" />Jeden z użytkowników aplikacji Pitbot dostał po złożeniu deklaracji podatkowej wyliczenie, zgodnie z którym ma otrzymać zwrot w wysokości niemal 28 tys. 600 zł - poinformowano na stronach superbiz.se.pl.

## Lokum Deweloper miał 57,29 mln zł zysku netto, 109,8 mln zł zysku EBIT w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690682,lokum-deweloper-mial-5729-mln-zl-zysku-netto-1098-mln-zl-zysku-ebit-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690682,lokum-deweloper-mial-5729-mln-zl-zysku-netto-1098-mln-zl-zysku-ebit-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:20:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Z1ZktkuTURBXy80YTE5NGU4Yy0zN2VmLTRkYjUtODQ2Yi0wZjNlN2Q4YzI5ODMuanBlZ5GTBc0BHcyg" />undefined

## Echo Investment miało 127,15 mln zł zysku netto, 275,4 mln zł zysku EBIT w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690674,echo-investment-mialo-12715-mln-zl-zysku-netto-2754-mln-zl-zysku-ebit-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690674,echo-investment-mialo-12715-mln-zl-zysku-netto-2754-mln-zl-zysku-ebit-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:17:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pfTktkuTURBXy9hZWFkMmE2ZS1iMmZiLTQ1NGEtYTE5MS1jZWNlNGI5Nzg2YzAuanBlZ5GTBc0BHcyg" />undefined

## Arctic Paper miał 631 mln zł zysku netto, 973,97 mln zł zysku EBITDA w 2022 r.
 - [https://forsal.pl/artykuly/8690668,arctic-paper-mial-631-mln-zl-zysku-netto-97397-mln-zl-zysku-ebitda-w-2022-r.html](https://forsal.pl/artykuly/8690668,arctic-paper-mial-631-mln-zl-zysku-netto-97397-mln-zl-zysku-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:14:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hiZktkuTURBXy9hMjJmZDYwOS02Yjg2LTQ1NjgtYWUwNy1mNzMxZjQxYjRiMjUuanBlZ5GTBc0BHcyg" />undefined

## Prezydentka Tajwanu z wizytą w USA. Chiny grożą odwetem
 - [https://forsal.pl/swiat/chiny/artykuly/8690665,prezydentka-tajwanu-z-wizyta-w-usa-chiny-groza-odwetem.html](https://forsal.pl/swiat/chiny/artykuly/8690665,prezydentka-tajwanu-z-wizyta-w-usa-chiny-groza-odwetem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:13:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5CYktkuTURBXy9kZTBiNjQyMy0zZTUyLTRjOTctOTM1My1lNmU0MjE0Y2UyYTQuanBlZ5GTBc0BHcyg" />Zewnętrzna presja nie powstrzyma Tajwanu przed kontaktami ze światem – oświadczyła w środę prezydentka Caj Ing-wen przed wylotem do USA. Komunistyczne władze Chin zagroziły odwetem, jeśli spotka się tam ona ze spikerem Izby Reprezentantów Kevinem McCarthym.

## Ten Square Games miał 52,34 mln zł zysku netto, 140,85 mln zł skoryg. EBITDA w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690660,ten-square-games-mial-5234-mln-zl-zysku-netto-14085-mln-zl-skoryg-ebitda-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690660,ten-square-games-mial-5234-mln-zl-zysku-netto-14085-mln-zl-skoryg-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:11:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/34-ktkuTURBXy80ZmI5ZjBjMS0zZTc1LTRjN2QtYjJkMS00M2YzMzg4M2E3ZjUuanBlZ5GTBc0BHcyg" />undefined

## Błaszczak zatwierdził umowę na kolejne radary przeciwlotnicze Bystra
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8690659,blaszczak-zatwierdzil-umowe-na-kolejne-radary-przeciwlotnicze-bystra.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8690659,blaszczak-zatwierdzil-umowe-na-kolejne-radary-przeciwlotnicze-bystra.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:07:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/s78ktkuTURBXy8xODFkNzI0Ni0wYjYzLTQ3YjktYWE3OC0xYTljYWZhZjY0MDQuanBlZ5GTBc0BHcyg" />Szef MON Mariusz Błaszczak zatwierdził w środę umowę wykonawczą na dostawę kolejnych 22 mobilnych radarów przeciwlotniczych Bystra; wartość umowy to 1 mld 100 mln zł. Budujemy zdolności przeciwlotnicze i przeciwrakietowe Wojska Polskiego, wzmacniamy je o kolejne warstwy - podkreślił Błaszczak.

## Tauron rekomenduje niewypłacanie dywidendy z zysku za 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8690657,tauron-rekomenduje-niewyplacanie-dywidendy-z-zysku-za-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8690657,tauron-rekomenduje-niewyplacanie-dywidendy-z-zysku-za-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 08:07:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0axktkuTURBXy83ODBiZDdhYi05YTc5LTQ2MjgtOTU2Yy01ZDFhZWUxYTU5OGYuanBlZ5GTBc0BHcyg" />undefined

## Szef MEiN: Dzieci mają za dużo lekcji. Okrojona podstawa programowa od 01 września 2024
 - [https://forsal.pl/lifestyle/edukacja/artykuly/8690601,czarnek-za-duzo-lekcji-okrojona-podstawa-programowa-od-wrzesnia-2024.html](https://forsal.pl/lifestyle/edukacja/artykuly/8690601,czarnek-za-duzo-lekcji-okrojona-podstawa-programowa-od-wrzesnia-2024.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 07:20:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eVBktkuTURBXy9mODM2NWM3ZC1iY2ZiLTQ4ZWEtODkyOC04ZWY0YzY2ZjU0ZTguanBlZ5GTBc0BHcyg" />Można się pokusić o odchudzenie podstawy programowej, żeby dać więcej czasu na tzw. zajęcia miękkie, związane również z kulturą fizyczną, rekreacją. Zrobimy to tak, żeby nie zmniejszać liczby godzin dla nauczycieli - powiedział PAP szef MEiN, Przemysław Czarnek. Dodał, że efekty zobaczymy najpóźniej 1 września 2024 r.

## Trzęsienie ziemi we Włoszech
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8690597,trzesienie-ziemi-we-wloszech.html](https://forsal.pl/swiat/aktualnosci/artykuly/8690597,trzesienie-ziemi-we-wloszech.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 07:15:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sqfktkuTURBXy8zYTMyMWIzOC1kMDBmLTRmOWEtYTIyMy1jMmU5NDNlYmQ1MjUuanBlZ5GTBc0BHcyg" />Trzęsienie ziemi o magnitudzie 4,6 nawiedziło w nocy z wtorku na środę południowe Włochy - poinformował włoski Instytut Geofizyki i Wulkanologii (INGV).

## Sztuczna inteligencja zagraża dwóm trzecim wszystkich stanowisk. „Celuje” głównie w te prace umysłowe
 - [https://forsal.pl/praca/artykuly/8690591,sztuczna-inteligencja-zagraza-dwom-trzecim-wszystkich-stanowisk-oto-najbardziej-zagrozone-zawody.html](https://forsal.pl/praca/artykuly/8690591,sztuczna-inteligencja-zagraza-dwom-trzecim-wszystkich-stanowisk-oto-najbardziej-zagrozone-zawody.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 07:06:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NtUktkuTURBXy9hMTc0NGIyYi1jNjMxLTQ5MTAtODJlOC0zNGNjYjBjZDcwZTMuanBlZ5GTBc0BHcyg" />Aż dwie trzecie wszystkich stanowisk pracy może zostać w pewnym stopniu zautomatyzowana – wynika z raportu Goldman Sachsa. Analiza banku objęła europejski i amerykański rynek zatrudniania.

## USA popierają pomysł utworzenia trybunału, który osądzi Rosję
 - [https://forsal.pl/swiat/usa/artykuly/8690590,usa-popieraja-pomysl-utworzenia-trybunalu-ktory-osadzi-rosje.html](https://forsal.pl/swiat/usa/artykuly/8690590,usa-popieraja-pomysl-utworzenia-trybunalu-ktory-osadzi-rosje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 07:06:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RuBktkuTURBXy9mODYwNmFlNC1jMDkzLTQ2NDAtYjgwMS01M2VlYzkxMTEyMWQuanBlZ5GTBc0BHcyg" />Stany Zjednoczone popierają pomysł utworzenia specjalnego trybunału do osądzenia agresji Rosji przeciwko Ukrainie - oświadczyła ambasador Beth Van Schaack, przedstawicielka Departamentu Stanu USA ds. globalnego wymiaru sprawiedliwości w sprawach karnych, cytowana w środę przez agencję AFP. Zauważyła, że trybunał taki mógłby powstać nawet w ramach systemu sądownictwa Ukrainy.

## Biden: Przeniesienie rosyjskiej broni jądrowej na Białoruś budzi niepokój
 - [https://forsal.pl/swiat/usa/artykuly/8690588,biden-przeniesienie-rosyjskiej-broni-jadrowej-na-bialorus-budzi-niepokoj.html](https://forsal.pl/swiat/usa/artykuly/8690588,biden-przeniesienie-rosyjskiej-broni-jadrowej-na-bialorus-budzi-niepokoj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 07:02:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Np_ktkuTURBXy9kNzY3ZWI2YS1mOWVhLTRjZTUtYTc3YS0wYzUxYmJhZjBmNDkuanBlZ5GTBc0BHcyg" />Prezydent USA Joe Biden powiedział we wtorek, że jest zaniepokojony tym, że Rosja może wysłać taktyczną broń jądrową na Białoruś - podał Reuters.

## Przyrodnicza sensacja w podkarpackich lasach. Zaobserwowano białego jelenia
 - [https://forsal.pl/biznes/ekologia/artykuly/8690585,przyrodnicza-sensacja-w-podkarpackich-lasach-zaobserwowano-bialego-jelenia.html](https://forsal.pl/biznes/ekologia/artykuly/8690585,przyrodnicza-sensacja-w-podkarpackich-lasach-zaobserwowano-bialego-jelenia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 07:00:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-Q6ktkuTURBXy8yOWRkYmU3YS1mZWEyLTRhYjMtOGU5NC1mMGMxMGRhNjU4YzAuanBlZ5GTBc0BHcyg" />Na krótkim, 10-sekundowym filmiku widać, jak przez leśną drogę przebiega stado jeleni, zwane też przez leśników i myśliwych chmarą. Wśród sześciu osobników znalazł się jeden wyjątkowy - biały jeleń. Nagranie opublikowało Nadleśnictwo Leżajsk.

## Kolejne 5 chińskich firm z amerykańskimi sankcjami handlowymi
 - [https://forsal.pl/swiat/usa/artykuly/8690577,kolejne-5-chinskich-firm-z-amerykanskimi-sankcjami-handlowymi.html](https://forsal.pl/swiat/usa/artykuly/8690577,kolejne-5-chinskich-firm-z-amerykanskimi-sankcjami-handlowymi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:48:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AxqktkuTURBXy8zYzIwYzJhMi1iNjQxLTRmYzItYjNmOC1jMWZjOGZiYTNmYjQuanBlZ5GTBc0BHcyg" />Administracja prezydenta Joe Bidena nałożyła we wtorek nowe ograniczenia handlowe na pięć chińskich podmiotów za rzekomą pomoc w represjach Pekinu wobec muzułmańskiej grupy Ujgurów - podał Reuters.

## Spada zapas ropy w USA. Surowiec drożeje
 - [https://forsal.pl/finanse/notowania/artykuly/8690566,spada-zapas-ropy-w-usa-surowiec-drozeje.html](https://forsal.pl/finanse/notowania/artykuly/8690566,spada-zapas-ropy-w-usa-surowiec-drozeje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:40:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gZgktkuTURBXy8yMjAxMTU4My1hYWFjLTQxZmYtYTI2YS03Y2M3Y2Q2ZjgzN2YuanBlZ5GTBc0BHcyg" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną kolejny dzień. Tym razem przyczyną zwyżek notowań są informacje o dużym spadku amerykańskich zapasów ropy - informują maklerzy.

## Biden: Kryzys bankowy w USA wciąż trwa
 - [https://forsal.pl/biznes/bankowosc/artykuly/8690565,biden-kryzys-bankowy-w-usa-wciaz-trwal.html](https://forsal.pl/biznes/bankowosc/artykuly/8690565,biden-kryzys-bankowy-w-usa-wciaz-trwal.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:39:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JUAktkuTURBXy82MmNhMWRkMS00NGIxLTQ1MzQtOTI3Ni1hM2EzNDNmZTc0ZDguanBlZ5GTBc0BHcyg" />Prezydent USA ocenił we wtorek, że niepewność w sektorze bankowym wywołana upadłością Silicon Valley Bank jeszcze się nie skończyła, a jego administracja stale monitoruje sytuację. Zaznaczył jednak, że zrobił tyle, ile mógł, by uspokoić sytuację.

## Kolejne zatrzymania w śledztwie w sprawie pustych faktur VAT
 - [https://forsal.pl/gospodarka/prawo/artykuly/8690562,kolejne-zatrzymania-w-sledztwie-w-sprawie-pustych-faktur-vat.html](https://forsal.pl/gospodarka/prawo/artykuly/8690562,kolejne-zatrzymania-w-sledztwie-w-sprawie-pustych-faktur-vat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:34:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BldktkuTURBXy81YjcwMjc1MS0zY2YxLTQxY2UtOThjYi1hODAxN2FiZjc3MWEuanBlZ5GTBc0BHcyg" />Policjanci CBŚP przy wsparciu funkcjonariuszy KAS zatrzymali kolejnych 10 osób w śledztwie dotyczącym grup przestępczych, które wystawiły &quot;puste&quot; faktury VAT na 1,5 mld zł. Do tej pory zarzuty usłyszało 310 osób, w tym 44-letni Robert C., który był na liście najbardziej poszukiwanych ludzi w Europie.

## Były szef giełdy FTX oskarżony o korumpowanie chińskich urzędników
 - [https://forsal.pl/gospodarka/prawo/artykuly/8690559,byly-szef-gieldy-ftx-oskarzony-o-korumpowanie-chinskich-urzednikow.html](https://forsal.pl/gospodarka/prawo/artykuly/8690559,byly-szef-gieldy-ftx-oskarzony-o-korumpowanie-chinskich-urzednikow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:31:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MHfktkuTURBXy8xNTQ3MjY4My02YzI5LTQwNmMtOTlkYy0zZWM3ZDQ5MGMwZWEuanBlZ5GTBc0BHcyg" />Amerykańscy prokuratorzy postawili we wtorek kolejny zarzut założycielowi giełdy FTX Samowi Bankmanowi-Friedowi dotyczący spiskowania w celu przekupienia chińskich urzędników. W akcie oskarżenia zarzuca się mu przekupienie &quot;jednego lub więcej&quot; chińskich urzędników państwowych krypto walutą o wartości 40 milionów dolarów, aby odzyskać dostęp do ponad 1 miliarda dolarów znajdujących się na chińskich kontach kryptowalutowych - podał dziennik WSJ.

## Nowela ustawy o Sądzie Najwyższym. W czwartek posiedzenie komisji
 - [https://forsal.pl/gospodarka/polityka/artykuly/8690555,nowela-ustawy-o-sadzie-najwyzszym-w-czwartek-posiedzenie-komisji.html](https://forsal.pl/gospodarka/polityka/artykuly/8690555,nowela-ustawy-o-sadzie-najwyzszym-w-czwartek-posiedzenie-komisji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:26:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hgVktkuTURBXy9jOWY3NmJiYy0yMDcyLTQ4NGUtYjQ3MS0xYWEwNzZiOGIxZjYuanBlZ5GTBc0BHcyg" />W czwartek sejmowa komisja ustawodawcza ma zająć się projektem stanowiska Izby dla Trybunału Konstytucyjnego w sprawie zaskarżonych przez prezydenta Andrzeja Dudę zapisów styczniowej nowelizacji ustawy o Sądzie Najwyższym. Dotychczas do TK trafiło stanowisko szefa rządu w tej sprawie.

## Kowalczyk odpowiada na zarzuty: Ukraińskie zboże nie jest głównym powodem spadku cen
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8690551,kowalczyk-ukrainskie-zboze-nie-jest-glownym-powodem-spadku-cen.html](https://forsal.pl/biznes/rolnictwo/artykuly/8690551,kowalczyk-ukrainskie-zboze-nie-jest-glownym-powodem-spadku-cen.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:22:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/iQlktkuTURBXy80NmFhMGYzYS0wYTYzLTRkNTMtYTYyNi01YjQwMTgxNTgzZTAuanBlZ5GTBc0BHcyg" />Import zboża z Ukrainy nie jest głównym powodem spadku cen - powiedział wicepremier, minister rolnictwa Henryk Kowalczyk portalowi wpolityce.pl. Jak dodał, w czasie środowego &quot;okrągłego stołu&quot; ws. sytuacji na rynku zbóż chce przedyskutować z rolnikami potencjalną pomoc.

## Problemy z masłem. W hurcie tanieje, na półkach sklepowych drożeje
 - [https://forsal.pl/biznes/handel/artykuly/8690406,problemy-z-maslem-w-hurcie-tanieje-na-polkach-sklepowych-drozeje.html](https://forsal.pl/biznes/handel/artykuly/8690406,problemy-z-maslem-w-hurcie-tanieje-na-polkach-sklepowych-drozeje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:17:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LuBktkuTURBXy8wMDRkMzZhNy01ODk1LTQ5MGUtOTIwYy0yN2Q5ZDYwMjhmZjYuanBlZ5GTBc0BHcyg" />Ceny wyrobów mleczarskich obniżają się. Ale masła to nie dotyczy. Eksperci tłumaczą, że to efekt rosnącego popytu przed Wielkanocą

## Kryzys energetyczny we Włoszech. Rząd przeznaczy 4,9 mld euro na wsparcia dla rodzin i firm
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8690547,kryzys-energetyczny-we-wloszech-rzad-da-49-mld-euro.html](https://forsal.pl/swiat/unia-europejska/artykuly/8690547,kryzys-energetyczny-we-wloszech-rzad-da-49-mld-euro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:15:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DUzktkuTURBXy9iZGE5M2QwYi1mZjRhLTQxNDUtYjdiNi1jZGZiNWQxMjkzNGUuanBlZ5GTBc0BHcyg" />4,9 miliarda euro pomocy dla rodzin i firm w związku z wysokimi cenami energii przewiduje dekret przyjęty we wtorek przez rząd Włoch. Na tym samym posiedzeniu Rada Ministrów zaaprobowała projekt ustawy o zakazie produkcji i sprzedaży syntetycznej żywności.

## Polacy zaakceptują zakaz sprzedaży aut spalinowych? Jeśli e-paliwa będą tańsze
 - [https://forsal.pl/transport/aktualnosci/artykuly/8690546,polacy-zaakceptuja-zakaz-sprzedazy-aut-spalinowych-jesli-e-paliwa-beda-tansze.html](https://forsal.pl/transport/aktualnosci/artykuly/8690546,polacy-zaakceptuja-zakaz-sprzedazy-aut-spalinowych-jesli-e-paliwa-beda-tansze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:15:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jDLktkuTURBXy81MDU5MzRiNS1lYzNjLTQ0YWItYTQwMi01OThmYmYwN2Y1NmUuanBlZ5GTBc0BHcyg" />Propozycja z e-paliwami może sprawić, że Polacy zaakceptują zakaz sprzedaży samochodów na paliwa kopalniane pod warunkiem, że te ekologiczne będą tańsze - powiedział PAP prezes Polskiego Związku Przemysłu Motoryzacyjnego Jakub Faryś.

## Ustawa o wsparciu osób z niepełnosprawnościami do szybkiego uchwalenia
 - [https://forsal.pl/gospodarka/prawo/artykuly/8690450,ustawa-o-wsparciu-osob-z-niepelnosprawnosciami-do-szybkiego-uchwalenia.html](https://forsal.pl/gospodarka/prawo/artykuly/8690450,ustawa-o-wsparciu-osob-z-niepelnosprawnosciami-do-szybkiego-uchwalenia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:02:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5__ktkuTURBXy9hYTBmYTJkZi1mMDJjLTQzZmQtYjVmNC1jYzgwNjg0ZWFmNTguanBlZ5GTBc0BHcyg" />Jutro Stały Komitet Rady Ministrów, w najbliższy wtorek posiedzenie rządu, a potem Sejm. Paweł Wdówik, wiceszef resortu rodziny, przekonuje, że w kwestii prac nad ustawą wprowadzającą świadczenie wspierające najważniejsze jest, by dopiąć kalendarz. – To nie jest produkt finalny.

## Emerytury i renty przegoniły inflację
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8690462,emerytury-i-renty-przegonily-inflacje.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8690462,emerytury-i-renty-przegonily-inflacje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 06:00:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IttktkuTURBXy9lOGVlNjEzYS01NzE1LTQ0YWQtODI3Ny05YzBiN2Q5NmE1YmMuanBlZ5GTBc0BHcyg" />W marcu oprócz emerytur i rent z Funduszu Ubezpieczeń Społecznych zwaloryzowaliśmy emerytury pomostowe, renty socjalne, a także zasiłki i świadczenia przedemerytalne – mówi Gertruda Uścińska, prezes Zakładu Ubezpieczeń Społecznych i przedstawia dokładne wyliczenia

## KPO kością niezgody w koalicji rządowej
 - [https://forsal.pl/gospodarka/polityka/artykuly/8690446,kpo-koscia-niezgody-w-koalicji-rzadowej.html](https://forsal.pl/gospodarka/polityka/artykuly/8690446,kpo-koscia-niezgody-w-koalicji-rzadowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 05:53:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PJWktkuTURBXy9kOGJlMzkyYi1jNGUwLTQ5MzItOTdhNC0yYzczMmI3ZDdmZmUuanBlZ5GTBc0BHcyg" />Prezydent ze Zbigniewem Ziobrą kontra premier z Sejmem – tak wygląda podział w sprawie ustawy o Sądzie Najwyższym, której konstytucyjność ma zbadać trybunał

## Set-jetting – jeden z "największych trendów turystycznych" w 2023 r.
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8689354,set-jetting-jeden-z-najwiekszych-trendow-turystycznych-w-2023-r.html](https://forsal.pl/lifestyle/turystyka/artykuly/8689354,set-jetting-jeden-z-najwiekszych-trendow-turystycznych-w-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 04:50:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/o37ktkuTURBXy9lZWNkOTQ2NS0xZWM1LTRlZDItYjk4NS03N2Q2MGFkYzU3NjguanBlZ5GTBc0BHcyg" />Turyści przybywają coraz chętniej do miejsc, gdzie toczy się akcja ich ulubionych filmów i seriali. Set-jetting staje się „jednym z największych trendów turystycznych w 2023 roku” – pisze Bloomberg.

## Zadłużone samorządy i kryzys na rynku nieruchomości zmuszają Pekin do zmiany polityki gospodarczej
 - [https://forsal.pl/swiat/chiny/artykuly/8690157,zadluzone-samorzady-kryzys-na-rynku-nieruchomosci-pekin-zmiania-gospodarke.html](https://forsal.pl/swiat/chiny/artykuly/8690157,zadluzone-samorzady-kryzys-na-rynku-nieruchomosci-pekin-zmiania-gospodarke.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 04:30:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/X8_ktkuTURBXy9jOTY1NWY4MS0yMmZlLTQ4N2ItYmM4Ny1hOTk2OWY4NzhhMzkuanBlZ5GTBc0BHcyg" />Pekin narzuca zadłużonym samorządom lokalnym politykę ograniczenia ryzyka finansowego. Najwyraźniej zwiększenie przez rząd centralny transferów pieniężnych do samorządów lokalnych aż o 17,1 proc. w 2022 roku, okazało się niewystarczające.

## Lubisz słuchać bollywoodzkich hitów na Spotify? Mamy dla ciebie złą wiadomość
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8689348,lubisz-sluchac-bollywoodzkich-hitow-na-spotify-mamy-dla-ciebie-zla-wiadomosc.html](https://forsal.pl/biznes/aktualnosci/artykuly/8689348,lubisz-sluchac-bollywoodzkich-hitow-na-spotify-mamy-dla-ciebie-zla-wiadomosc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 04:10:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TxTktkuTURBXy80NDMyNjBkMi1hYWM4LTQyMzctYWIyZS1kZjM5YTcwZDU4YzAuanBlZ5GTBc0BHcyg" />„Oddajcie mi moją muzykę!”, „Natychmiast odnówcie swoją umowę ze Spotify!” – pisali na Twitterze oburzeni fani i fanki muzycznych hitów rodem z Bollywood. Ponad połowa uwielbianych, szczególnie w Indiach, utworów, zniknęła z zasobów szwedzkiego giganta streamingowego. Wszystko przez spór licencyjny z firmą Zee Music.

## Jak szybko może dziś upaść wielki bank? Witamy w erze kryzysów „made in Twitter”
 - [https://forsal.pl/biznes/bankowosc/artykuly/8690122,jak-szybko-moze-dzis-upasc-wielki-bank-witamy-w-erze-kryzysow-made-in-twitter.html](https://forsal.pl/biznes/bankowosc/artykuly/8690122,jak-szybko-moze-dzis-upasc-wielki-bank-witamy-w-erze-kryzysow-made-in-twitter.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TjqktkuTURBXy80MGI3YjA3Yi1iMTdmLTQ1NDMtOTFlZi0yOGQxOTQwZjhlZmQuanBlZ5GTBc0BHcyg" />Potencjalny kryzys bankowy będzie inny niż ten, którego doświadczyliśmy w latach 2007-2009. „To pierwszy kryzys pokolenia Twittera” – twierdzi główny ekonomista UBS Global Wealth Management Paul Donovan.

## Fundamentalna rola banków centralnych w czasach kryzysów
 - [https://forsal.pl/gospodarka/artykuly/8689679,fundamentalna-rola-bankow-centralnych-w-czasach-kryzysow.html](https://forsal.pl/gospodarka/artykuly/8689679,fundamentalna-rola-bankow-centralnych-w-czasach-kryzysow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-29 03:40:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jzkktkuTURBXy9hZmVmYWMxNS0zMjFmLTQxYWQtYjQwNy00OWVmMmMzMWFkNzYuanBlZ5GTBc0BHcyg" />Konsekwentnie realizujemy programy rozwojowe i uważnie obserwujemy to, co się dzieje w naszym kraju i jego otoczeniu. Jeżeli na horyzoncie pojawi się sytuacja kryzysowa, podejmujmy odpowiednie decyzje. To jest prosta recepta, którą ekonomista może podać – mówi prof. Cezary Kochalski, członek Rady Polityki Pieniężnej.

