# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## An Unopened 2007 iPhone Can Be Yours (for $32,000 or More)
 - [https://www.nytimes.com/2023/03/29/style/iphone-2007-auction.html](https://www.nytimes.com/2023/03/29/style/iphone-2007-auction.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-29 16:53:44+00:00

A first-generation Apple smartphone is going up for auction.

## As Washington Calls for TikTok Ban, Its Owner Begins Pushing a New App
 - [https://www.nytimes.com/2023/03/29/technology/tiktok-lemon8-content-creators.html](https://www.nytimes.com/2023/03/29/technology/tiktok-lemon8-content-creators.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-29 16:37:28+00:00

ByteDance, the Chinese company behind TikTok, is trying to woo popular social media creators to join its new app, Lemon8, before it is officially introduced this year.

## What Makes Chatbots ‘Hallucinate’ or Say the Wrong Thing?
 - [https://www.nytimes.com/2023/03/29/technology/ai-chatbots-hallucinations.html](https://www.nytimes.com/2023/03/29/technology/ai-chatbots-hallucinations.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-29 15:46:12+00:00

The curious case of the hallucinating software.

## Elon Musk and Others Call for Pause on A.I., Citing ‘Risks to Society’
 - [https://www.nytimes.com/2023/03/29/technology/ai-artificial-intelligence-musk-risks.html](https://www.nytimes.com/2023/03/29/technology/ai-artificial-intelligence-musk-risks.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-29 14:23:05+00:00

More than 1,000 tech leaders, researchers and others signed an open letter that urged a moratorium on the development of the most powerful artificial intelligence systems.

## How ChatGPT and Bard Performed as My Executive Assistants
 - [https://www.nytimes.com/2023/03/29/technology/personaltech/ai-chatgpt-google-bard-assistant.html](https://www.nytimes.com/2023/03/29/technology/personaltech/ai-chatgpt-google-bard-assistant.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-29 09:00:37+00:00

Google’s Bard chatbot fared far worse than OpenAI’s ChatGPT, but human assistants might soon be out of their jobs.

## Rift Between Gaming Giants Shows Toll of China’s Economic Crackdown
 - [https://www.nytimes.com/2023/03/29/technology/activision-netease-china-breakup.html](https://www.nytimes.com/2023/03/29/technology/activision-netease-china-breakup.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-29 09:00:26+00:00

Activision Blizzard and NetEase could not agree on a new deal to distribute video games in China, cutting millions of players from the games in January.

