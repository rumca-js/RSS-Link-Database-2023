# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Xorg Foundation Has A Serious Problem
 - [https://www.youtube.com/watch?v=aWzhrMBN9fo](https://www.youtube.com/watch?v=aWzhrMBN9fo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2023-03-29 20:00:00+00:00

Xorg is going to be with us long into the future but the xorg foundation currently has a bit of a serious problem, there are simply not enough people who want to run for the board

==========Support The Channel==========
► $100 Linode Credit: https://brodierobertson.xyz/linode
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Xorg Mailing List 1: https://lists.freedesktop.org/archives/xorg-devel/2023-March/059000.html
Xorg Mailing List 2: https://lists.freedesktop.org/archives/xorg-devel/2023-March/059001.html
Xorg Mailing List 3: https://lists.freedesktop.org/archives/xorg-devel/2023-March/059002.html
Xorg Mailing List 4: https://lists.freedesktop.org/archives/xorg-devel/2023-March/059004.html
2012 Election: https://www.phoronix.com/news/MTA3MTc
2014 Election: https://www.phoronix.com/news/MTYwODI
2017 Election: https://www.phoronix.com/news/Xorg-2017-Elections-Now

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson.xyz/discord
🎤 Matrix Space: https://brodierobertson.xyz/matrix
🐦 Twitter: https://brodierobertson.xyz/twitter
🌐 Mastodon: https://brodierobertson.xyz/mastodon
🖥️ GitHub: https://brodierobertson.xyz/github

==========Credits==========
🎨 Channel Art:
Profile Picture:
https://www.instagram.com/supercozman_draws/

#xorg #wayland #Linux #OpenSource #FOSS #LinuxDesktop

🎵 Ending music
Music from https://filmmusic.io
"Basic Implosion" by Kevin MacLeod (https://incompetech.com)
License: CC BY (http://creativecommons.org/licenses/by/4.0/)

DISCLOSURE: Wherever possible I use referral links, which means if you click one of the links in this video or description and make a purchase I may receive a small commission or other compensation.

