# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Polska psychiatria z bliska. Gdzie szukać pomocy w kryzysie psychicznym
 - [https://wydarzenia.interia.pl/kraj/news-polska-psychiatria-z-bliska-gdzie-szukac-pomocy-w-kryzysie-p,nId,6685052](https://wydarzenia.interia.pl/kraj/news-polska-psychiatria-z-bliska-gdzie-szukac-pomocy-w-kryzysie-p,nId,6685052)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-03-29 08:55:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polska-psychiatria-z-bliska-gdzie-szukac-pomocy-w-kryzysie-p,nId,6685052"><img align="left" alt="Polska psychiatria z bliska. Gdzie szukać pomocy w kryzysie psychicznym " src="https://i.iplsc.com/polska-psychiatria-z-bliska-gdzie-szukac-pomocy-w-kryzysie-p/000GYIX3IKAQSUVW-C321.jpg" /></a>Czujesz coraz większy lęk, niepokój, depresyjne myśli nie dają ci spać, nie masz siły wstać z łóżka lub przytłacza cię aktualna sytuacja życiowa? Mogą być to oznaki kryzysu psychicznego. Rosnące koszty prywatnych psychoterapii i konsultacji psychiatrycznych sprawiają, że wielu po prostu nie stać na takie usługi, ale – na szczęście – jest również szereg bezpłatnych rozwiązań i doraźnej pomocy w słabszych momentach.</p><br clear="all" />

