# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Giving Out Free Tech Tips
 - [https://www.youtube.com/watch?v=7rYyq0usslQ](https://www.youtube.com/watch?v=7rYyq0usslQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-03-29 22:00:03+00:00

#sponsored

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

## The WORST PCs Linus Tech Tips Ever Built
 - [https://www.youtube.com/watch?v=_ffH3LROFZY](https://www.youtube.com/watch?v=_ffH3LROFZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-03-29 17:31:37+00:00

Thanks Lenovo for sponsoring today's video! Check out their Lenovo Yoga Pro 9i Laptop at https://lmg.gg/Yogo9iLTT

Discuss on the forum: https://linustechtips.com/topic/1497497-the-worst-pcs-linus-tech-tips-ever-built/

Buy a Lenovo Slim 9i 14" Laptop: https://geni.us/1ZTD5a

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 lol kinda cringe
0:47 Hand-me-down PC 2002
2:26 Tyson's PC
2:54 Linus' first gaming PC
4:42 UV Paint Overload
7:39 First Surround Sound Setup
8:51 One of Linus' Dumbest Decisions
9:38 Rainbow Spaghett
10:30 Big Desk Energy
11:36 Dual Monitors
12:48 First Rattle Can Paintjob
13:09 First Water Cooled Setup
14:09 Most Expensive PC Component Purchase
14:34 First SLI Setup
14:47 First Custom Water Cooled Setup
16:20 First Chiller Test
17:42 This Was A Mistake
18:10 LAN Setup
18:43 Yvonne's Bedroom
20:05 First Water Cooled PC For NCIX Client
21:07 Swag Build
22:35 Couch Monitor
24:41 Side By Side Gaming Setup
25:46 First Wifey PC
26:17 Box Office
27:36 Back At The In-laws'
28:04 Radical Linus
28:59 Gnarly Linus
29:25 Cringe
30:01 Linus Steals From Work Too
30:20 Outro

