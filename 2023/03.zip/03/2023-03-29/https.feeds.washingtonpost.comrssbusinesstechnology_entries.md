# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Elon Musk and a handful of AI leaders ask for ‘pause’ on the tech
 - [https://www.washingtonpost.com/technology/2023/03/29/ai-letter-pause/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/03/29/ai-letter-pause/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-29 15:37:00+00:00

Twitter CEO Elon Musk, veteran AI computer scientist Yoshua Bengio and Emad Mostaque, the CEO of fast-growing startup Stability AI, all signed the letter, along with around 1,000 other members of the business, academic and tech worlds.

## Customizing some laptops can be needlessly tricky. Not this one.
 - [https://www.washingtonpost.com/technology/2023/03/29/framework-16-modular-laptop-customize/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/03/29/framework-16-modular-laptop-customize/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-03-29 06:00:42+00:00

If you buy a traditional laptop, there are limits to how you can upgrade it. A California startup is trying to change that.

