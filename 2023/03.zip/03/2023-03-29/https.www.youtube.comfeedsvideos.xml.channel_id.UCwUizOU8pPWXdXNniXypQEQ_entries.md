# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## The assault bike will destroy you!
 - [https://www.youtube.com/watch?v=ZpVVvZEzX1A](https://www.youtube.com/watch?v=ZpVVvZEzX1A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-03-29 23:18:24+00:00

#shorts

