# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## "SHUT IT DOWN!"
 - [https://www.youtube.com/watch?v=lP8f1qDh9To](https://www.youtube.com/watch?v=lP8f1qDh9To)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-03-29 17:29:36+00:00

The first 100 people to use code BRAND at the link below will get 20% off of Incogni: https://incogni.com/brand

As TikTok’s CEO is grilled in congress for allegedly spying on the US public it’s revealed that the same politicians who’ve publicly attacked the app also accept donations from TikTok executuves. This, while the CDC purchased private location data on over 55 million Americans to monitor lockdown compliance. You’ve almost got to admire the sheer nerve of them! #tiktok #censorship #congress
--------------------------------------------------------------------------------------------------------------------------
Get My New Stand Up Special 'Brandemic' NOW for a Limited Time Over on RUMBLE https://bit.ly/brandemic-rumble

OR 

Get Access Through My Community To Have It For Longer PLUS Extra Ad Free Content! https://bit.ly/brandemic-locals-trailer
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble
Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community
Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/
Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

## Gangster Government | Big Tech TAKEDOWN! - #101 - Stay Free With Russell Brand PREVIEW
 - [https://www.youtube.com/watch?v=CXS0CKxdDMs](https://www.youtube.com/watch?v=CXS0CKxdDMs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-03-29 15:32:37+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me live and exclusively over on RUMBLE:
https://bit.ly/stayfree-101-big-tech-takedown

With guest Chris Best (@cjgbest)
Chris is the co-founder and CEO of Substack: a platform that allows journalists to work independently.

--------------------------------------------------------------------------------------------------------------------------

FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand
5:00PM GMT |12:00 PM EDT | 9:00AM PDT

Get My New Stand Up Special 'Brandemic' NOW https://rumble.com/v2d09w8-brandemic.html

Join The STAY FREE Community: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/

NEW MERCH! https://stuff.russellbrand.com/

