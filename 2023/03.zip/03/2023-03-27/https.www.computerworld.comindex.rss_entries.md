# Source:ComputerWorld, URL:https://www.computerworld.com/index.rss, language:en-US

## Apple Reality tidbits continue to leak — is the product really ready?
 - [https://www.computerworld.com/article/3691893/apple-reality-tidbits-continue-to-leak-is-the-product-really-ready.html#tk.rss_all](https://www.computerworld.com/article/3691893/apple-reality-tidbits-continue-to-leak-is-the-product-really-ready.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-03-27 16:37:00+00:00

<article>
	<section class="page">
<p>Well, this is something you don't see very often: secrets about a still-unannounced product — shared only with a small, hand-picked group of senior managers — that somehow leak.</p><h2><strong>Ruining the surprise</strong></h2>
<p>That’s what’s happened regarding Apple’s most secret non-secret product, its <a href="https://www.computerworld.com/article/3688352/teams-across-all-of-apple-are-now-focused-on-mixed-reality.html">first-generation mixed-reality headset</a> destined (we think) to <a href="https://www.computerworld.com/article/3686512/apple-wants-to-build-a-new-computing-platform-with-ar.html">appear at WWDC in June and ship in quantity later this year</a>. Both <em><a href="https://www.bloomberg.com/news/newsletters/2023-03-26/apple-reality-headset-details-pro-features-top-100-meeting-watch-like-start-lfpgdgdb" rel="noopener nofollow" target="_blank">Bloomberg</a></em> and the <em><a href="https://www.nytimes.com/2023/03/26/technology/apple-augmented-reality-dissent.html" rel="noopener nofollow" target="_blank">New York Times</a></em> recently shared stories from anonymous people within Apple who appear to know a lot about the product and who may have been among a top 100 executive team who attended secret demonstrations across the last few years. (The <em>New York Times</em> story cites eight sources for its story.)</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3691893/apple-reality-tidbits-continue-to-leak-is-the-product-really-ready.html#jump">To read this article in full, please click here</a></p></section></article>

## Microsoft rearchitects Teams to make it faster and smarter
 - [https://www.computerworld.com/article/3691894/microsoft-rearchitects-teams-to-make-it-faster-and-smarter.html#tk.rss_all](https://www.computerworld.com/article/3691894/microsoft-rearchitects-teams-to-make-it-faster-and-smarter.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-03-27 15:53:00+00:00

<article>
	<section class="page">
<p>Microsoft has unveiled a new app for its collaboration platform Microsoft Teams that it said will deliver faster performance and streamline the user experience.</p><p>First launched in 2017, <a href="https://www.computerworld.com/article/3276276/microsoft-teams-its-features-how-it-compares-to-slack-and-other-rivals.html">Microsoft Teams</a> is a collaborative workspace within Microsoft 365/Office 365 that acts as a central hub for workplace conversations, collaborative teamwork, video chats and document sharing. Microsoft claims the app, which has been <a href="https://www.computerworld.com/article/3614928/why-16-is-the-new-8-for-windows-10.html">criticized for hogging resources</a>, has 280 million monthly users, and 1,900 apps that integrate directly with it.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3691894/microsoft-rearchitects-teams-to-make-it-faster-and-smarter.html#jump">To read this article in full, please click here</a></p></section></article>

## Zoom adds generative AI to Zoom IQ; partners with OpenAI
 - [https://www.computerworld.com/article/3691778/zoom-adds-generative-ai-to-zoom-iq-partners-with-openai.html#tk.rss_all](https://www.computerworld.com/article/3691778/zoom-adds-generative-ai-to-zoom-iq-partners-with-openai.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-03-27 15:46:00+00:00

<article>
	<section class="page">
<p>Video conferencing platform Zoom plans to expand its smart companion, Zoom IQ, and will work with OpenAI to bolster a more flexible approach to AI, it said Monday.</p><p>In addition to adding new features in Zoom IQ, Zoom said it will take a federated approach to AI. This approach means deploying a combination of AI models: those it has developed in house, those developed by leading AI companies such as Open AI, or, for select customers, their own models.</p><p>This approach will allow the company to make “generative AI a driving force in making our customers’ organizations more productive,” Smita Hashim, chief product officer at Zoom, said in a <a href="https://blog.zoom.us/zoom-iq-smart-companion/" rel="nofollow">blog post</a>.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3691778/zoom-adds-generative-ai-to-zoom-iq-partners-with-openai.html#jump">To read this article in full, please click here</a></p></section></article>

## Q&A: Cisco CIO Fletcher Previn on the challenges of a hybrid workplace
 - [https://www.computerworld.com/article/3691616/qa-cisco-cio-fletcher-previn-on-the-challenges-of-a-hybrid-workplace.html#tk.rss_all](https://www.computerworld.com/article/3691616/qa-cisco-cio-fletcher-previn-on-the-challenges-of-a-hybrid-workplace.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-03-27 10:00:00+00:00

<article>
	<section class="page">
<p>In April, 2021, Cisco CEO Chuck Robbins announced <a href="https://www.businessinsider.com/cisco-permanent-remote-work-for-all-workers-productivity-cost-savings-2021-7?op=1" rel="noopener nofollow" target="_blank">he would let all 75,000 employees work remotely indefinitely</a>, even after the COVID-19 pandemic ended. The company had seen no drop in productivity by allowing employees to work from home and expected to save money by not fully staffing offices. When and how often employees should come into the office would be up to their managers, who abide by a flexible hybrid policy.</p><p>But that shift brought technology challenges most companies are by now familiar with: how do you secure networks when the employee’s home is essentially a branch office? How do you create company culture from afar? And, how do you retain employees at a time when IT talent is in historically high demand.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3691616/qa-cisco-cio-fletcher-previn-on-the-challenges-of-a-hybrid-workplace.html#jump">To read this article in full, please click here</a></p></section></article>

