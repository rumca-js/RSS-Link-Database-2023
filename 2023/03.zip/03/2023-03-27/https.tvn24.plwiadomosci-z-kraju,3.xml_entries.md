# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Atak na szkołę w Nashville. Prezydent Biden wzywa do zakazu sprzedaży karabinów szturmowych
 - [https://tvn24.pl/swiat/nashville-atak-na-szkole-prezydent-usa-joe-biden-wzywa-do-zakazu-sprzedazy-karabinow-szturmowych-6864037?source=rss](https://tvn24.pl/swiat/nashville-atak-na-szkole-prezydent-usa-joe-biden-wzywa-do-zakazu-sprzedazy-karabinow-szturmowych-6864037?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 20:06:46+00:00

<img alt="Atak na szkołę w Nashville. Prezydent Biden wzywa do zakazu sprzedaży karabinów szturmowych " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3c6hp4-atak-na-szkole-w-nashville-6864049/alternates/LANDSCAPE_1280" />
    Po ataku na szkołę podstawową w Nashville w stanie Tennessee, w wyniku którego życie straciło troje uczniów i trzech pracowników, prezydent Joe Biden wezwał w poniedziałek Kongres do wprowadzenia zakazu sprzedaży karabinów szturmowych. Jak dodał, trzeba zrobić wszystko, by chronić szkoły i by nie stały się one "więzieniami".

## Na przejeździe kolejowym wyprzedził radiowóz. Był pijany i ma odebrane prawo jazdy
 - [https://tvn24.pl/tvnwarszawa/okolice/wyszkow-na-przejezdzie-kolejowym-wyprzedzil-radiowoz-byl-pijany-i-ma-zakaz-prowadzenia-aut-6863995?source=rss](https://tvn24.pl/tvnwarszawa/okolice/wyszkow-na-przejezdzie-kolejowym-wyprzedzil-radiowoz-byl-pijany-i-ma-zakaz-prowadzenia-aut-6863995?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 20:06:08+00:00

<img alt="Na przejeździe kolejowym wyprzedził radiowóz. Był pijany i ma odebrane prawo jazdy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-cutsaz-policyjny-kogut-noca-6863983/alternates/LANDSCAPE_1280" />
    Na przejeździe kolejowym rozpędzona honda wyprzedziła nieoznakowany radiowóz. Zaraz po tym manewrze kierowca został zatrzymany. Jak się okazało 30-latek był pijany i ma sądowy zakaz kierowania pojazdami. Teraz grozi mu bardzo wysoka grzywna i nawet do pięciu lat pozbawienia wolności.

## Błażej Kmieciak, szef państwowej komisji ds. pedofilii: pomyliliśmy sacrum ołtarza z profanum kurii
 - [https://tvn24.pl/polska/blazej-kmieciak-szef-panstwowej-komisji-ds-pedofilii-pomylilismy-sacrum-oltarza-z-profanum-kurii-6863846?source=rss](https://tvn24.pl/polska/blazej-kmieciak-szef-panstwowej-komisji-ds-pedofilii-pomylilismy-sacrum-oltarza-z-profanum-kurii-6863846?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 19:03:05+00:00

<img alt="Błażej Kmieciak, szef państwowej komisji ds. pedofilii: pomyliliśmy sacrum ołtarza z profanum kurii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-smelgb-27-2000-kropka-gosc-0048-6863946/alternates/LANDSCAPE_1280" />
    Dla mnie Jan Paweł II jest święty nie dlatego, że kongregacja tak orzekła, tylko dlatego, że jestem człowiekiem wierzącym, który wierzy w to głęboko, że on jest w niebie. Ale on nie jest Bogiem - powiedział w "Kropce nad i" Błażej Kmieciak, przewodniczący państwowej komisji ds. pedofilii. Ocenił, że "jeżeli nie otworzymy archiwów kościelnych", to materiały takie jak reportaż "Franciszkańska 3" - który pokazuje nieznane fakty z życia Karola Wojtyły - "mają pełne prawo powstawać".

## "Milionerzy". Kto opublikował serię karykatur Hitlera "Miłostki słodkiego Adolfa"? Pytanie za 20 tysięcy złotych
 - [https://tvn24.pl/toteraz/milionerzy-kto-opublikowal-serie-karykatur-hitlera-milostki-slodkiego-adolfa-6863392?source=rss](https://tvn24.pl/toteraz/milionerzy-kto-opublikowal-serie-karykatur-hitlera-milostki-slodkiego-adolfa-6863392?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 19:03:00+00:00

<img alt="" src="https://tvn24.pl/toteraz/cdn-zdjecie-pyd6ju-kto-opublikowal-serie-karykatur-hitlera-pytanie-w-milionerach-warte-20-tysiecy-zlotych-6863356/alternates/LANDSCAPE_1280" />
    Kto w magazynie "Ici Paris" opublikował serię karykatur Hitlera "Miłostki słodkiego Adolfa" i doczekał się sprawy w sądzie o obrazę głowy państwa? Takie pytanie usłyszał pan Bartosz Jałocha z Mielca.

## Pogoda na jutro - wtorek, 28.03. Nocą ściśnie mróz, w dzień będzie do 5 stopni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-2803-noca-scisnie-mroz-w-dzien-bedzie-do-5-stopni-6863839?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-2803-noca-scisnie-mroz-w-dzien-bedzie-do-5-stopni-6863839?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 18:02:27+00:00

<img alt="Pogoda na jutro - wtorek, 28.03. Nocą ściśnie mróz, w dzień będzie do 5 stopni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-xiq600-mrozna-noc-6508598/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. Wtorek przyniesie zmienne zachmurzenie i przelotne opady śniegu oraz deszczu. Wszędzie odczujemy zimno, a wrażenie to będzie wzmagał porywisty wiatr.  Najcieplej będzie na zachodzie kraju, gdzie temperatura maksymalna wyniesie 5 stopni Celsjusza.

## Pijana matka "opiekowała" się małym dzieckiem
 - [https://tvn24.pl/tvnwarszawa/okolice/grojec-opiekowala-sie-osiemnastomiesiecznym-synkiem-miala-ponad-17-promila-6863603?source=rss](https://tvn24.pl/tvnwarszawa/okolice/grojec-opiekowala-sie-osiemnastomiesiecznym-synkiem-miala-ponad-17-promila-6863603?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 17:19:50+00:00

<img alt="Pijana matka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9y5wvu-dziecko-lozeczko-niemowlak-zabawka-shutterstock_285189707-6805340/alternates/LANDSCAPE_1280" />
    Opiekowała się osiemnastomiesięcznym synkiem, była pijana. Policja wszczęła postępowanie. Kobiecie, która usłyszała już zarzuty, grozi do pięciu lat więzienia.

## Został ranny, gdy jechał z pomocą. Nie żyje wolontariusz z Polski
 - [https://tvn24.pl/polska/ukraina-zmarl-polski-wolontariusz-ktory-zostal-ranny-jadac-z-pomoca-humanitarna-w-okolicach-miejscowosci-czasiw-jar-6863772?source=rss](https://tvn24.pl/polska/ukraina-zmarl-polski-wolontariusz-ktory-zostal-ranny-jadac-z-pomoca-humanitarna-w-okolicach-miejscowosci-czasiw-jar-6863772?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 16:58:06+00:00

<img alt="Został ranny, gdy jechał z pomocą. Nie żyje wolontariusz z Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y4bjb4-ostrzelany-bus-6847834/alternates/LANDSCAPE_1280" />
    Działający w Ukrainie polski wolontariusz zmarł w szpitalu w wyniku odniesionych ran – poinformowała w poniedziałek inicjatywa pomocowa "Nehemiasz", z którą był związany. Mężczyzna został ranny w wyniku rosyjskiego ostrzału busa z pomocą humanitarną w okolicach miejscowości Czasiw Jar. "Marek zmarł dziś przed południem w klinice w Kijowie" - podała organizacja.

## Brooke Shields miała 10 lat, gdy musiała wystąpić w nagiej sesji. Po latach ocenia decyzje swojej matki
 - [https://tvn24.pl/kultura-i-styl/brooke-shields-miala-10-lat-gdy-musiala-wystapic-w-nagiej-sesji-po-latach-ocenia-decyzje-swojej-matki-6863620?source=rss](https://tvn24.pl/kultura-i-styl/brooke-shields-miala-10-lat-gdy-musiala-wystapic-w-nagiej-sesji-po-latach-ocenia-decyzje-swojej-matki-6863620?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 16:20:51+00:00

<img alt="Brooke Shields miała 10 lat, gdy musiała wystąpić w nagiej sesji. Po latach ocenia decyzje swojej matki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dtdci6-brooke-shields-z-matka-teri-shields-lata-80-gettyimages-686241717-6863638/alternates/LANDSCAPE_1280" />
    Brooke Shields w wywiadzie dla "The Sunday Times" zdecydowała się opowiedzieć o skomplikowanych relacjach łączących ją z matką, Teri Shields. Odniosła się m.in. do kontrowersji związanych z faktem, że jako dziecko występowała na ekranie nago, musiała też pocałować dorosłego aktora. Mówiąc o swojej matce, aktorka przyznała: - Nie wiem, dlaczego uważała, że ​​wszystko jest w porządku. Nie wiem.

## Założyciel Alibaby Jack Ma widziany w Chinach po miesiącach nieobecności
 - [https://tvn24.pl/biznes/ze-swiata/jack-ma-zalozyciel-serwisu-alibaba-pojawil-sie-po-raz-pierwszy-publicznie-od-kilku-lat-w-chinach-6863611?source=rss](https://tvn24.pl/biznes/ze-swiata/jack-ma-zalozyciel-serwisu-alibaba-pojawil-sie-po-raz-pierwszy-publicznie-od-kilku-lat-w-chinach-6863611?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 15:32:53+00:00

<img alt="Założyciel Alibaby Jack Ma widziany w Chinach po miesiącach nieobecności" src="https://tvn24.pl/najnowsze/cdn-zdjecie-05kthd-jack-ma-4920380/alternates/LANDSCAPE_1280" />
    Jack Ma, założyciel popularnego chińskiego serwisu Alibaba, w ciągu ostatnich trzech lat bardzo rzadko był widywany publicznie. Zniknął po tym, jak skrytykował politykę chińskiego regulatora finansowego w 2020 roku. Niedawno jednak był widziany w szkole, którą ufundował w Hangzhou, mieście, w którym mieści się centrala Alibaby.

## Wichury we Włoszech. Drzewa upadały na domy, słupy energetyczne się przewracały
 - [https://tvn24.pl/tvnmeteo/swiat/wichury-we-wloszech-drzewa-upadaly-na-domy-slupy-energetyczne-sie-przewracaly-6863537?source=rss](https://tvn24.pl/tvnmeteo/swiat/wichury-we-wloszech-drzewa-upadaly-na-domy-slupy-energetyczne-sie-przewracaly-6863537?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 15:00:06+00:00

<img alt="Wichury we Włoszech. Drzewa upadały na domy, słupy energetyczne się przewracały" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jsmfb9-zalamanie-pogody-we-wloszech-6863405/alternates/LANDSCAPE_1280" />
    Przez Włochy przeszły silne wichury. W gminie Cesena w regionie Emilia-Romania porywy wiatru łamały drzewa, przewracały słupy energetyczne. Strażacy interweniowali kilkadziesiąt razy. To wcale nie musi być koniec gwałtownej, niebezpiecznej aury w tym rejonie - ostrzegli meteorolodzy.

## Rządowa strona z transakcyjnymi cenami mieszkań. Nowy pomysł na walkę ze "sztucznym popytem"
 - [https://tvn24.pl/biznes/nieruchomosci/minister-waldemar-buda-zapowiada-panstwowy-portal-z-cenami-transakcyjnymi-mieszkan-6863644?source=rss](https://tvn24.pl/biznes/nieruchomosci/minister-waldemar-buda-zapowiada-panstwowy-portal-z-cenami-transakcyjnymi-mieszkan-6863644?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 14:53:50+00:00

<img alt="Rządowa strona z transakcyjnymi cenami mieszkań. Nowy pomysł na walkę ze " src="https://tvn24.pl/najnowsze/cdn-zdjecie-djajyi-nieruchomosci-bloki-osiedle-budowa-deweloperzy-6597043/alternates/LANDSCAPE_1280" />
    Z początkiem 2024 r. uruchomimy stronę internetową z przejrzystym podglądem cen transakcyjnych mieszkań z podziałem na miejscowość, dzielnicę i metraż - zapowiedział w poniedziałek w Studiu PAP minister rozwoju i technologii Waldemar Buda.

## Starówka bez reklam i potykaczy? Ma powstać park kulturowy Historycznego Centrum Warszawy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-starowka-bez-reklam-i-potykaczy-urzednicy-chca-aby-historyczne-centrum-kultury-stalo-sie-parkiem-kulturowym-6863547?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-starowka-bez-reklam-i-potykaczy-urzednicy-chca-aby-historyczne-centrum-kultury-stalo-sie-parkiem-kulturowym-6863547?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 14:05:03+00:00

<img alt="Starówka bez reklam i potykaczy? Ma powstać park kulturowy Historycznego Centrum Warszawy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-204lwn-stare-miasto-mozna-zwiedzic-z-przewodnikiem-za-darmo-we-wrzesniowe-soboty-4684118/alternates/LANDSCAPE_1280" />
    Koniec z nielegalnymi reklamami czy wieszakami z odzieżą na ozdobnych kratach kamieniczek? Urzędnicy mają pomysł na estetykę reprezentacyjnych miejsc Historycznego Centrum Warszawy.

## "Asystenci plus". Pracowali z posłanką Solidarnej Polski, poszli po wielotysięczne granty
 - [https://tvn24.pl/polska/dotacje-dla-bylych-asystentow-poslanki-marii-kurowskiej-ustalenia-gazety-wyborczej-6863435?source=rss](https://tvn24.pl/polska/dotacje-dla-bylych-asystentow-poslanki-marii-kurowskiej-ustalenia-gazety-wyborczej-6863435?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 14:04:59+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ip9885-pap_20220201_1nt-6863327/alternates/LANDSCAPE_1280" />
    Dziennikarki "Gazety Wyborczej" opisały, jak byli już asystenci posłanki Solidarnej Polski Marii Kurowskiej z Solidarnej Polski sięgnęli po granty między innymi z Narodowego Instytutu Wolności, który powstał z inicjatywy ministra Piotra Glińskiego. Według autorek asystenci od rządowych instytucji "zebrali prawie 1,3 miliona złotych" - podano.

## Powódź w Boliwii. Ewakuowano ponad 180 rodzin
 - [https://tvn24.pl/tvnmeteo/swiat/boliwia-powodzie-ewakuowano-ponad-180-rodzin-6863401?source=rss](https://tvn24.pl/tvnmeteo/swiat/boliwia-powodzie-ewakuowano-ponad-180-rodzin-6863401?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 13:55:29+00:00

<img alt="Powódź w Boliwii. Ewakuowano ponad 180 rodzin" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-r3n7pb-powodzie-boliwia-6863511/alternates/LANDSCAPE_1280" />
    Intensywne opady deszczu spowodowały, że w boliwijskim mieście Cobija wezbrała rzeka Acre. Doszło do powodzi powodujących rozległe zniszczenia. Ewakuowano ponad 180 rodzin. Ludzie zabierali tylko najpotrzebniejsze rzeczy, ratowali też zwierzęta domowe.

## Na czele Opery Wrocławskiej stanie dyrektorski duet. Ma zapewnić "utrzymanie odpowiedniej renomy"
 - [https://tvn24.pl/wroclaw/wroclaw-zarzad-wojewodztwa-wskazal-nowych-dyrektorow-opery-wroclawskiej-6863395?source=rss](https://tvn24.pl/wroclaw/wroclaw-zarzad-wojewodztwa-wskazal-nowych-dyrektorow-opery-wroclawskiej-6863395?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 13:52:22+00:00

<img alt="Na czele Opery Wrocławskiej stanie dyrektorski duet. Ma zapewnić " src="https://tvn24.pl/najnowsze/cdn-zdjecie-46ltb0-po-lewej-tomasz-janczak-po-prawej-michal-znaniecki-6863529/alternates/LANDSCAPE_1280" />
    W poniedziałek Zarząd Województwa Dolnośląskiego uchwalił zamiar powołania duetu Tomasz Janczak - Michał Znaniecki na stanowiska odpowiednio dyrektora głównego i dyrektora artystycznego Opery Wrocławskiej. Obaj mają objąć posady bez konkursu, aby szybko zagasić pożary wzniecone przez poprzednie władze.

## Georgia. Tornado przeszło przez park safari, uciekły dwa tygrysy
 - [https://tvn24.pl/tvnmeteo/swiat/gerogia-usa-2-tygrysy-wyskoczyly-z-zagrody-po-przejsciu-tornada-6863261?source=rss](https://tvn24.pl/tvnmeteo/swiat/gerogia-usa-2-tygrysy-wyskoczyly-z-zagrody-po-przejsciu-tornada-6863261?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 13:34:44+00:00

<img alt="Georgia. Tornado przeszło przez park safari, uciekły dwa tygrysy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-668c9y-tornado-w-stanie-georgia-6863542/alternates/LANDSCAPE_1280" />
    Podczas niedzielnego tornada w stanie Georgia zniszczeń doznał park safari w hrabstwie Harris. Gwałtowna pogoda naruszyła kilka wybiegów, z jednego z nich wydostały się dwa tygrysy.

## Porzucony w gdańskiej marinie jacht niszczeje od kilku lat. Został wystawiony na sprzedaż
 - [https://tvn24.pl/pomorze/gdansk-od-kilku-lat-stoi-w-marinie-i-niszczeje-remont-wyceniono-na-ponad-300-tysiecy-zlotych-6862924?source=rss](https://tvn24.pl/pomorze/gdansk-od-kilku-lat-stoi-w-marinie-i-niszczeje-remont-wyceniono-na-ponad-300-tysiecy-zlotych-6862924?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 13:31:36+00:00

<img alt="Porzucony w gdańskiej marinie jacht niszczeje od kilku lat. Został wystawiony na sprzedaż" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k8gd4b-gdanski-osrodek-sportu-wystawil-na-sprzedaz-porzucona-jednostke-6862813/alternates/LANDSCAPE_1280" />
    Chętni, którzy chcą nabyć kilkudziesięcioletni jacht marki Ocean Aleksander zacumowany od dziewięciu lat w gdańskiej marinie, tylko do wtorku mogą składać oferty do Gdańskiego Centrum Sportu. By stać się jego właścicielem trzeba będzie zapłacić ponad 60 tysięcy złotych. Co ciekawe sam remont jachtu może kosztować nawet sześciokrotność tej sumy.

## Agregat w wygłuszonym pomieszczeniu, pokoje dla pracowników. Potężna fabryka papierosów zlikwidowana
 - [https://tvn24.pl/wroclaw/boleslawiec-nielegalna-fabryka-papierosow-zlikwidowana-w-srodku-agregat-w-wygluszonym-pomieszczeniu-6863092?source=rss](https://tvn24.pl/wroclaw/boleslawiec-nielegalna-fabryka-papierosow-zlikwidowana-w-srodku-agregat-w-wygluszonym-pomieszczeniu-6863092?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 13:23:13+00:00

<img alt="Agregat w wygłuszonym pomieszczeniu, pokoje dla pracowników. Potężna fabryka papierosów zlikwidowana" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1tyzz1-nielegalna-fabryka-papierosow-pod-boleslawcem-6863065/alternates/LANDSCAPE_1280" />
    W okolicach Bolesławca na Dolnym Śląsku połączone siły CBŚP, KAS i SG zlikwidowały nielegalną fabrykę papierosów. Szacuje się, że można było tam wyprodukować około miliona sztuk na dobę. Zabezpieczono prawie 9 milionów papierosów i ponad 9,5 tony tytoniu czekającego na obróbkę. Twórcy dołożyli starań, aby skutecznie ukryć przybytek, ale ostatecznie i tak im się nie udało.

## W Nigerii rząd "w ogóle zakazał używania gotówki"? To nieprawda
 - [https://konkret24.tvn24.pl/swiat/w-nigerii-rzad-w-ogole-zakazal-uzywania-gotowki-to-nieprawda-6862258?source=rss](https://konkret24.tvn24.pl/swiat/w-nigerii-rzad-w-ogole-zakazal-uzywania-gotowki-to-nieprawda-6862258?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 13:22:43+00:00

<img alt="W Nigerii rząd " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jj1nqq-w-nigerii-rzad-w-ogole-zakazal-uzywania-gotowki-nieprawda-6862465/alternates/LANDSCAPE_1280" />
    Wiceszef partii Nowa Nadzieja poinformował, że nigeryjski rząd "w ogóle zakazał używania gotówki", co wywołało protesty w kraju. Nie jest to prawda. Wyjaśniamy, jaki był powód zamieszek i co zdecydował Bank Centralny Nigerii.

## Zaparkował przed komisariatem i odkręcił gaz. "Jego celem było zabicie jak największej liczby funkcjonariuszy policji"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-przyjechal-przedkomisariat-na-ursynowie-odkrecil-gaz-zwabil-policjantow-apelacja-6863472?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-przyjechal-przedkomisariat-na-ursynowie-odkrecil-gaz-zwabil-policjantow-apelacja-6863472?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 13:22:12+00:00

<img alt="Zaparkował przed komisariatem i odkręcił gaz. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hku3hg-komisariat-na-ursynowie-6133220/alternates/LANDSCAPE_1280" />
    W poniedziałek w Sądzie Apelacyjnym wygłoszone zostały mowy końcowe w sprawie Piotra M. Mężczyzna oskarżony jest o to, że w 2020 roku usiłował zabić policjantów poprzez eksplozję gazu przed komisariatem policji na stołecznym Ursynowie. Wyrok w tej sprawie ma zapaść w środę, 29 marca.

## Happening rolników w Szczecinie, a potem przejazd traktorów przez centrum miasta
 - [https://tvn24.pl/pomorze/happening-rolnikow-w-szczecinie-a-potem-przejazd-traktorow-przez-centrum-miasta-6863183?source=rss](https://tvn24.pl/pomorze/happening-rolnikow-w-szczecinie-a-potem-przejazd-traktorow-przez-centrum-miasta-6863183?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 13:09:30+00:00

<img alt="Happening rolników w Szczecinie, a potem przejazd traktorów przez centrum miasta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5yjseu-rolnicy-przejechali-przez-szczecin-6863503/alternates/LANDSCAPE_1280" />
    Protestujący przeciw polityce rządu rolnicy w poniedziałek zaznaczyli swoją obecność w Szczecinie. Najpierw zablokowali jezdnię obok swojego tzw. zielonego miasteczka, a potem inne miejskie ulice przejeżdżając przez nie traktorami. Mieszkańcy miasta odpowiadali na to głównie ze zrozumieniem.

## Konserwator nakazał przeprowadzenie prac w secesyjnej kamienicy. Mają zahamować proces degradacji
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-konserwator-nakazal-wlascicielowi-kamienicy-przy-gornoslaskiej-przeprowadzenie-prac-6863481?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-konserwator-nakazal-wlascicielowi-kamienicy-przy-gornoslaskiej-przeprowadzenie-prac-6863481?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 13:03:24+00:00

<img alt="Konserwator nakazał przeprowadzenie prac w secesyjnej kamienicy. Mają zahamować proces degradacji" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-f9w4za-kamienica-przy-gornoslaskiej-22-w-warszawie-6863464/alternates/LANDSCAPE_1280" />
    Mazowiecki wojewódzki konserwator zabytków nakazał przeprowadzenie prac konserwatorskich i robót budowlanych w kamienicy przy Górnośląskiej 22. Mają zahamować postępujący proces degradacji zabytku.

## Trzech zatrzymanych w sprawie śmierci 17-letniego Fabiana Zydora
 - [https://tvn24.pl/poznan/trzech-zatrzymanych-w-sprawie-smierci-17-letniego-fabiana-zydora-6863466?source=rss](https://tvn24.pl/poznan/trzech-zatrzymanych-w-sprawie-smierci-17-letniego-fabiana-zydora-6863466?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 12:45:34+00:00

<img alt="Trzech zatrzymanych w sprawie śmierci 17-letniego Fabiana Zydora" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5smo3i-zaginiony-fabian-zydor-5153248/alternates/LANDSCAPE_1280" />
    Wielkopolska policja poinformowała, że zatrzymano trzech mężczyzn podejrzanych o zamordowanie i ukrycie zwłok 17-latka, który zaginął w październiku 2016 roku w miejscowości Tarnowa koło Wrześni. Nastolatka od tamtego czasu poszukiwano, a jego losy są nieznane. Zatrzymani są mieszkańcami sąsiadującej z Tarnowem miejscowości Pyzdry.

## Na wizualizacjach było zazielenione patio z kwietnikiem, w rzeczywistości jest parking
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-bialoleka-na-wizualizacjach-bylo-zazielenione-patio-z-kwietnikiem-w-rzeczywistosci-jest-parking-6862818?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-bialoleka-na-wizualizacjach-bylo-zazielenione-patio-z-kwietnikiem-w-rzeczywistosci-jest-parking-6862818?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 12:44:31+00:00

<img alt="Na wizualizacjach było zazielenione patio z kwietnikiem, w rzeczywistości jest parking" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-y01smt-na-wizualizacjach-bylo-zazielenione-patio-z-kwietnikiem-w-rzeczywistosci-jest-parking-6863447/alternates/LANDSCAPE_1280" />
    Mieszkańcy nowego osiedla Uroki Miasta na Białołęce nie są zadowoleni z wyglądu podwórka wewnątrz bloków. Miało to być porośnięte bujną zielenią patio, a jest parking na kratce obsianej trawą. Przedstawiciel dewelopera zapewnia, że wszystko powstało zgodnie z projektem budowlanym, a na dziedzińcu były przewidziane miejsca parkingowe. Te zostaną zakryte zielenią, która jeszcze nie urosła.

## W kieszeni miał karteczkę. Pomogła mu wrócić do domu
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-dzieki-karteczce-z-kieszeni-bezpiecznie-wrocil-do-domu-6863359?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-dzieki-karteczce-z-kieszeni-bezpiecznie-wrocil-do-domu-6863359?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 12:23:32+00:00

<img alt="W kieszeni miał karteczkę. Pomogła mu wrócić do domu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-on0mfo-patrol-medyczny-straznikow-miejskich-6639563/alternates/LANDSCAPE_1280" />
    Zdezorientowany starszy mężczyzna kilka godzin siedział na murku przy ulicy Czerniakowskiej. Zajęli się nim strażnicy miejscy, a do domu bezpiecznie wrócił dzięki małej karteczce.

## Młody byk wpadł do głębokiej dziury. Na miejsce wezwano strażaków
 - [https://tvn24.pl/pomorze/radlowo-mlody-byk-wpadl-do-glebokiej-dziury-na-miejsce-wezwano-strazakow-6862629?source=rss](https://tvn24.pl/pomorze/radlowo-mlody-byk-wpadl-do-glebokiej-dziury-na-miejsce-wezwano-strazakow-6862629?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 11:58:18+00:00

<img alt="Młody byk wpadł do głębokiej dziury. Na miejsce wezwano strażaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7k7fhe-mlody-byk-wpadl-do-dziury-pomogli-strazacy-6862498/alternates/LANDSCAPE_1280" />
    Strażacy uwolnili młodego byka, który wpadł do głębokiej, prawie dwumetrowej dziury w jednym z gospodarstw w Radłowie (woj. kujawsko-pomorskie). Zwierzęciu nic poważnego się nie stało. Po podaniu środka uspokajającego przez weterynarza, wróciło do swojego naturalnego środowiska.

## Zderzenie trzech pojazdów na S8. Utworzył się długi korek
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-trzech-pojazdow-na-s8-utworzyl-sie-dlugi-korek-6863281?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-trzech-pojazdow-na-s8-utworzyl-sie-dlugi-korek-6863281?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 11:46:40+00:00

<img alt="Zderzenie trzech pojazdów na S8. Utworzył się długi korek" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-11dnv8-kolizja-na-s8-6863295/alternates/LANDSCAPE_1280" />
    Na jezdni trasy S8 w kierunku Białegostoku zderzyły się dwa auta osobowe oraz ciężarówka. Nie ma rannych, ale są utrudnienia.

## Kilkunastoosobowa grupa brutalnie pobiła dwóch Ukraińców. Jeden z nich trafił do szpitala
 - [https://tvn24.pl/lodz/lodz-kilkunastoosobowa-grupa-brutalnie-pobila-dwoch-ukraincow-powiedzial-mi-ze-nas-nienawidza-6863271?source=rss](https://tvn24.pl/lodz/lodz-kilkunastoosobowa-grupa-brutalnie-pobila-dwoch-ukraincow-powiedzial-mi-ze-nas-nienawidza-6863271?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 11:39:52+00:00

<img alt="Kilkunastoosobowa grupa brutalnie pobiła dwóch Ukraińców. Jeden z nich trafił do szpitala" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uga4y9-do-zdarzenia-doszlo-w-parku-reymonta-lodzi-6863202/alternates/LANDSCAPE_1280" />
    Policjanci z Łodzi poszukują grupy osób, która miała brutalnie pobić dwóch obywateli Ukrainy. 26 i 38-latek wracali do domu przez Park Reymonta i to właśnie tam mieli zostać zaatakowani. - Pamiętam tylko, że jeden z napastników zapytał mnie, czy jestem z Ukrainy, ja mu odpowiedziałem, że tak. Wtedy on powiedział mi, że nas nienawidzą.

## Policyjny pościg za pijanymi. Uciekali polem, a potem utknęli na skarpie
 - [https://tvn24.pl/krakow/dzialoszyce-ucieczka-przed-policja-poscig-przez-pole-uprawne-pijany-kierowca-zatrzymal-sie-na-skarpie-6862625?source=rss](https://tvn24.pl/krakow/dzialoszyce-ucieczka-przed-policja-poscig-przez-pole-uprawne-pijany-kierowca-zatrzymal-sie-na-skarpie-6862625?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 11:34:27+00:00

<img alt="Policyjny pościg za pijanymi. Uciekali polem, a potem utknęli na skarpie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-st7dyj-do-poscigu-doszlo-w-dzialoszycach-woj-swietokrzyskie-6862572/alternates/LANDSCAPE_1280" />
    W trakcie ucieczki wjechali na pole, samochód zatrzymał się na skarpie. Tak zakończył się pościg za grupą pijanych młodych ludzi w Działoszycach (woj. świętokrzyskie). Wcześniej przy jednym z zamkniętych sklepów zapewniali policjantów, że żadne z nich kierować nie będzie.

## Motocyklista uderzył w drzewo, zginął na miejscu
 - [https://tvn24.pl/krakow/boleslaw-motocyklista-uderzyl-w-drzewo-zginal-na-miejscu-policja-o-tragicznym-wypadku-6863181?source=rss](https://tvn24.pl/krakow/boleslaw-motocyklista-uderzyl-w-drzewo-zginal-na-miejscu-policja-o-tragicznym-wypadku-6863181?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 11:17:53+00:00

<img alt="Motocyklista uderzył w drzewo, zginął na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h3heqz-wypadek-motocyklisty-w-boleslawiu-woj-malopolskie-6863146/alternates/LANDSCAPE_1280" />
    Policjanci badają okoliczności tragicznego wypadku, do którego doszło w niedzielę na drodze krajowej nr 94 w Bolesławiu (woj. małopolskie). 33-letni motocyklista zginął tam po uderzeniu w przydrożne drzewo.

## Zepsuty pociąg na trasie Warszawa - Skierniewice. Pasażerowie musieli przesiąść się do innego składu
 - [https://tvn24.pl/tvnwarszawa/okolice/zepsuty-pociag-na-trasie-warszawa-skierniewice-odwolane-i-opoznione-pociagi-6863085?source=rss](https://tvn24.pl/tvnwarszawa/okolice/zepsuty-pociag-na-trasie-warszawa-skierniewice-odwolane-i-opoznione-pociagi-6863085?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 10:37:37+00:00

<img alt="Zepsuty pociąg na trasie Warszawa - Skierniewice. Pasażerowie musieli przesiąść się do innego składu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t626et-zepsuty-pociag-na-trasie-warszawa-skierniewice-zdj-ilustracyjne-6863174/alternates/LANDSCAPE_1280" />
    Koleje Mazowieckie poinformowały o utrudnieniach na trasie Warszawa - Skierniewice. Przyczyną jest zepsuty skład Polregio, który jechał w kierunku Łodzi. Pociągi w kierunku Łodzi mogą być opóźnione lub odwołane.

## Bus wiozący dzieci do szkoły zderzył się z samochodem. Jedna osoba w szpitalu
 - [https://tvn24.pl/krakow/pogorska-wola-zderzenie-busa-wiozacego-dzieci-do-szkoly-z-samochodem-osobowym-jedna-osoba-w-szpitalu-6862798?source=rss](https://tvn24.pl/krakow/pogorska-wola-zderzenie-busa-wiozacego-dzieci-do-szkoly-z-samochodem-osobowym-jedna-osoba-w-szpitalu-6862798?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 10:05:56+00:00

<img alt="Bus wiozący dzieci do szkoły zderzył się z samochodem. Jedna osoba w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vyxt7s-zderzenie-busa-szkolnego-z-samochodem-osobowym-6862831/alternates/LANDSCAPE_1280" />
    Do zderzenia busa przewożącego dzieci do szkoły i samochodu osobowego doszło w poniedziałek rano w Pogórskiej Woli niedaleko Tarnowa (woj. małopolskie). Do szpitala trafiła opiekunka. Uczniów z miejsca kolizji odebrali rodzice.

## Weszli do domu, pobili mieszkańców i ich okradli. Zostali zatrzymani
 - [https://tvn24.pl/pomorze/pruszcz-gdanski-napadli-na-dom-i-okradli-rodzine-policjanci-o-swicie-weszli-do-ich-mieszkan-i-ich-zatrzymali-6862768?source=rss](https://tvn24.pl/pomorze/pruszcz-gdanski-napadli-na-dom-i-okradli-rodzine-policjanci-o-swicie-weszli-do-ich-mieszkan-i-ich-zatrzymali-6862768?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 09:44:27+00:00

<img alt="Weszli do domu, pobili mieszkańców i ich okradli. Zostali zatrzymani " src="https://tvn24.pl/najnowsze/cdn-zdjecie-okc7hw-sprawcy-brutalnego-napadu-zostali-zatrzymani-przez-policje-6862510/alternates/LANDSCAPE_1280" />
    Policjanci z Pomorza zatrzymali dwóch mężczyzn, którzy włamali się do jednego z domów na terenie powiatu gdańskiego, pobili i okradli jego mieszkańców. Jeden z zatrzymanych jest podejrzany także o włamanie do jubilera z 2015 roku.

## Minister sugeruje "instrumenty prawne dla tych, którzy szkalują Polskę". "To pokazuje, dokąd zmierza PiS"
 - [https://tvn24.pl/polska/minister-anna-moskwa-o-odbieraniu-paszportow-krytykom-wladzy-komentarze-6862803?source=rss](https://tvn24.pl/polska/minister-anna-moskwa-o-odbieraniu-paszportow-krytykom-wladzy-komentarze-6862803?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 09:34:45+00:00

<img alt="Minister sugeruje " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gr4clj-pap_20230319_0sc-6862771/alternates/LANDSCAPE_1280" />
    Minister Anna Moskwa w trakcie spotkania z wyborcami w Kozienicach ubolewała, że rząd nie może odbierać paszportów tym, którzy w Brukseli "kłamią i działają przeciwko Polsce". - Nie ma takiego narzędzia, ono byłoby niezgodne z prawem europejskim, chociaż pewnie wielu z nas pewnie taką pokusę by miało - przyznała, informując, że zwróci się do Zbigniewa Ziobry, "żeby przemyślał jakieś instrumenty prawne dla tych, którzy szkalują Polskę". Do jej wypowiedzi odnieśli się w Sejmie politycy opozycji.

## Wydrozwierze padają przez szczep pierwotniaka, który ma potencjał do zakażania ludzi
 - [https://tvn24.pl/tvnmeteo/nauka/wydrozwierze-padaja-przez-szczep-pierwotniaka-ktory-ma-potencjal-do-zakazania-ludzi-6862775?source=rss](https://tvn24.pl/tvnmeteo/nauka/wydrozwierze-padaja-przez-szczep-pierwotniaka-ktory-ma-potencjal-do-zakazania-ludzi-6862775?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 09:23:30+00:00

<img alt="Wydrozwierze padają przez szczep pierwotniaka, który ma potencjał do zakażania ludzi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k33laf-kalany-morskie-zwane-tez-wydrozwierzami-6862782/alternates/LANDSCAPE_1280" />
    W ostatnim czasie w Kalifornii padły cztery kałany morskie, nazywane między innymi wydrozwierzami. Stało się tak z powodu rzadkiego szczepu pierwotniaka Toxoplasma gondii. I choć do tej pory nie odnotowano żadnych przypadków zakażeń u ludzi, naukowcy nie wykluczają ich w przyszłości.

## 19-latek zginął w nocy przed blokiem, prawdopodobnie od ciosu nożem w serce. Śledztwo w kierunku zabójstwa
 - [https://tvn24.pl/katowice/wodzislaw-slaski-19-latek-zginal-w-nocy-przed-blokiem-prawdopodobnie-od-ciosu-nozem-sledztwo-w-kierunku-zabojstwa-6862726?source=rss](https://tvn24.pl/katowice/wodzislaw-slaski-19-latek-zginal-w-nocy-przed-blokiem-prawdopodobnie-od-ciosu-nozem-sledztwo-w-kierunku-zabojstwa-6862726?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 09:11:57+00:00

<img alt="19-latek zginął w nocy przed blokiem, prawdopodobnie od ciosu nożem w serce. Śledztwo w kierunku zabójstwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pefq1j-policja-zdjecie-ilustracyjne-6856822/alternates/LANDSCAPE_1280" />
    Młody mężczyzna został znaleziony w nocy na ulicy przed blokiem w Wodzisławiu Śląskim. Lekarz stwierdził zgon. 19-latek zginął prawdopodobnie od ciosu nożem, który znaleziono obok ciała. Jak mówi prokurator, chwilę później policja zatrzymała 26-latka, który podejrzewany jest o zabójstwo.

## CBA w świętokrzyskim urzędzie marszałkowskim. Prokuratura: chodzi o przyznanie nienależnej dotacji
 - [https://tvn24.pl/krakow/kielce-cba-w-urzedzie-marszalkowskim-wojewodztwa-swietokrzyskiego-prokuratura-o-sledztwie-6862697?source=rss](https://tvn24.pl/krakow/kielce-cba-w-urzedzie-marszalkowskim-wojewodztwa-swietokrzyskiego-prokuratura-o-sledztwie-6862697?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 09:01:57+00:00

<img alt="CBA w świętokrzyskim urzędzie marszałkowskim. Prokuratura: chodzi o przyznanie nienależnej dotacji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fk60y8-centralne-biuro-antykorupcyjne-cba-5555557/alternates/LANDSCAPE_1280" />
    Urząd Marszałkowski Województwa Świętokrzyskiego mógł przyznać nienależnie prawie milion złotych dotacji jednej z mazowieckich film - poinformowała nas w poniedziałek Prokuratura Rejonowa w Lublinie. To na polecenie śledczych tej jednostki do urzędu w Kielcach weszli w piątek 24 marca agenci CBA. Funkcjonariusze zabezpieczyli dokumenty, które teraz będą poddawane analizie.

## Serbia może wprowadzić sankcje wobec Rosji. Szef dyplomacji podał warunki
 - [https://tvn24.pl/swiat/serbia-rosja-sankcje-na-rosje-za-wojne-w-ukrainie-minister-spraw-zagranicznych-serbii-ivica-daczic-komentuje-6862392?source=rss](https://tvn24.pl/swiat/serbia-rosja-sankcje-na-rosje-za-wojne-w-ukrainie-minister-spraw-zagranicznych-serbii-ivica-daczic-komentuje-6862392?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 08:34:09+00:00

<img alt="Serbia może wprowadzić sankcje wobec Rosji. Szef dyplomacji podał warunki" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-iwovog-wladimir-putin-6797527/alternates/LANDSCAPE_1280" />
    Serbia może wprowadzić - pod pewnymi warunkami - sankcje przeciwko Rosji za jej napaść na Ukrainę. Tak wynika z wypowiedzi ministra spraw zagranicznych Serbii Ivicy Daczicia, cytowanego w niedzielę przez telewizję N1. Szef dyplomacji zastrzegł, że sankcje mogą zostać wprowadzone, jeśli obywatele Serbii i gospodarka zaczną ponosić odczuwalne straty.

## Kolejne dni protestów we Francji. Możliwe utrudnienia dla podróżnych
 - [https://tvn24.pl/swiat/francja-utrudnienia-dla-podrozujacych-w-zwiazku-z-protestami-jakich-sie-spodziewac-6861178?source=rss](https://tvn24.pl/swiat/francja-utrudnienia-dla-podrozujacych-w-zwiazku-z-protestami-jakich-sie-spodziewac-6861178?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 07:54:40+00:00

<img alt="Kolejne dni protestów we Francji. Możliwe utrudnienia dla podróżnych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b1aei8-policja-uzyla-gazu-lzawiacego-w-paryzu-by-rozpedzic-przeciwnikow-reformy-emerytalnej-6847394/alternates/LANDSCAPE_1280" />
    Protesty we Francji mogą pokrzyżować plany podróżnym i turystom, którzy w najbliższych dniach planują odwiedzić ten kraj. Największych problemów komunikacyjnych powinny spodziewać się osoby wybierające się do Paryża. Jakie utrudnienia mogą spotkać ich w najbliższych dniach?

## Autem osobowym wjechał w tył tira. Utrudnienia na wjeździe do Warszawy
 - [https://tvn24.pl/tvnwarszawa/ulice/pruszkow-auto-najechalo-na-tira-na-a2-6862645?source=rss](https://tvn24.pl/tvnwarszawa/ulice/pruszkow-auto-najechalo-na-tira-na-a2-6862645?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 07:48:47+00:00

<img alt="Autem osobowym wjechał w tył tira. Utrudnienia na wjeździe do Warszawy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-wf7yu5-zderzenie-na-autostradzie-a2-6862660/alternates/LANDSCAPE_1280" />
    Na autostradzie A2 kierowca samochodu osobowego uderzył w tył ciężarówki. Kierujący trafił pod opiekę medyków. Na wjeździe do Warszawy utworzył się spory korek.

## Wypadek na autostradzie w Niemczech z udziałem samochodów porsche. Cztery osoby nie żyją
 - [https://tvn24.pl/swiat/niemcy-kolonia-wypadek-na-autostradzie-a3-z-udzialem-trzech-samochodow-porsche-ofiary-6862434?source=rss](https://tvn24.pl/swiat/niemcy-kolonia-wypadek-na-autostradzie-a3-z-udzialem-trzech-samochodow-porsche-ofiary-6862434?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 05:33:58+00:00

<img alt="Wypadek na autostradzie w Niemczech z udziałem samochodów porsche. Cztery osoby nie żyją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7mbf3y-w-wypadku-na-autostradzie-a3-w-niemczech-uczestniczyly-trzy-samochody-porsche-6862425/alternates/LANDSCAPE_1280" />
    Cztery osoby zginęły w niedzielę na autostradzie A3 w Niemczech. W tragicznym zdarzeniu uczestniczyły trzy samochody porsche na holenderskich tablicach rejestracyjnych.

## Statek ratujący migrantów zatrzymany. Jednostka została ufundowana przez słynnego Banksy'ego
 - [https://tvn24.pl/swiat/wlochy-statek-ratujacy-migrantow-zatrzymany-na-lampedusie-jednostka-zostala-ufundowana-przez-slynnego-banksyego-6862344?source=rss](https://tvn24.pl/swiat/wlochy-statek-ratujacy-migrantow-zatrzymany-na-lampedusie-jednostka-zostala-ufundowana-przez-slynnego-banksyego-6862344?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-03-27 04:59:03+00:00

<img alt="Statek ratujący migrantów zatrzymany. Jednostka została ufundowana przez słynnego Banksy'ego " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2lrnrp-statek-ratujacy-migrantow-finansowany-przez-slynnego-banksyego-6862347/alternates/LANDSCAPE_1280" />
    Statek ratunkowy Louise Michel, ufundowany przez brytyjskiego artystę Banksy'ego, został zatrzymany w niedzielę na włoskiej wyspie Lampedusa. Według straży przybrzeżnej jednostka nie wykonała instrukcji i nie kierowała się do portu na Sycylii po akcji ratującej migrantów.

