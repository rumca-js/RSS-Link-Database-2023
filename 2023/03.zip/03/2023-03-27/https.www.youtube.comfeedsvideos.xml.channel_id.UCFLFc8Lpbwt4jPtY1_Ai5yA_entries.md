# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## Linus and Luke Discuss the LTT Hack
 - [https://www.youtube.com/watch?v=gAZut9Oq25M](https://www.youtube.com/watch?v=gAZut9Oq25M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-03-27 22:46:48+00:00

Linus Tech Tips, TechLinked, and Tech Quickie all got hacked. Linus and Luke respond. (Sleep deprived edition. (For more information, see our video breaking down the timeline of the hack  and the method behind it step-by-step - https://www.youtube.com/watch?v=yGXaAWbzl5A )

Watch the full WAN Show: https://www.youtube.com/watch?v=lh8Zdyy3zTQ

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

