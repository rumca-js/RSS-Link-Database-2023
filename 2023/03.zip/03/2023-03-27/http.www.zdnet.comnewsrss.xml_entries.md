# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## How to build a gaming PC for $550
 - [https://www.zdnet.com/article/how-to-build-a-gaming-pc-for-550/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-build-a-gaming-pc-for-550/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 20:27:00+00:00

Prices might be on the up, but you can still build yourself a capable PC for $550.

## It's time to update all of your Apple devices again. Here's why
 - [https://www.zdnet.com/article/its-time-to-update-all-of-your-apple-devices-again-heres-why/#ftag=RSSbaffb68](https://www.zdnet.com/article/its-time-to-update-all-of-your-apple-devices-again-heres-why/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 19:57:39+00:00

Apple just released iOS 16.4 with over 30 security fixes iPhone, alongside updates for Mac, iPad and more.

## The best printers of 2023: Inkjet, photo, and laser
 - [https://www.zdnet.com/article/best-printer/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-printer/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 19:41:00+00:00

Looking for a printer for your home office? The best printers come in the form of inkjet, photo, and laser, are Bluetooth compatible, and print at high speeds.

## The best webcams of 2023
 - [https://www.zdnet.com/article/best-webcam/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-webcam/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 19:39:00+00:00

Want to upgrade your next video conference? Whether you're a working professional or creative, these are the best webcams to kick your next video into high definition.

## Are you Meta Verified? Here's what it is, how much it costs, and what perks it gets you
 - [https://www.zdnet.com/article/are-you-meta-verified-heres-what-it-is-how-much-it-costs-and-what-perks-it-gets-you/#ftag=RSSbaffb68](https://www.zdnet.com/article/are-you-meta-verified-heres-what-it-is-how-much-it-costs-and-what-perks-it-gets-you/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 19:31:47+00:00

Now you can pay for Instagram and Facebook verification, too.

## The best alarm clocks of 2023: Smart clock edition
 - [https://www.zdnet.com/home-and-office/kitchen-household/best-alarm-clock/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/kitchen-household/best-alarm-clock/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 19:16:00+00:00

Ditch your smartphone for these best alarm clocks. They've got sunrise wake-ups, guided meditations, Bluetooth connectivity, and more.

## Zoom's new AI tools will soon summarize your meetings for you
 - [https://www.zdnet.com/article/zooms-new-ai-tools-will-soon-summarize-your-meetings-for-you/#ftag=RSSbaffb68](https://www.zdnet.com/article/zooms-new-ai-tools-will-soon-summarize-your-meetings-for-you/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 18:06:55+00:00

Zoom is collaborating with OpenAI to outsource your meeting tasks to AI. Here's what you can expect.

## The best car gadgets of 2023: Expert-picked car tech
 - [https://www.zdnet.com/article/best-car-gadget/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-car-gadget/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 17:54:00+00:00

Want to give your vehicle a tech facelift, or looking for an innovative car accessory to help you in emergency situations? The best car gadgets can make the perfect passenger.

## The best home security cameras of 2023
 - [https://www.zdnet.com/home-and-office/smart-home/best-security-camera/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/best-security-camera/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 17:04:00+00:00

The best home security cameras have motion sensor detection, night vision, two-way audio, and more to secure your home from unwanted guests. Here are my top picks.

## How (and why) to subscribe to ChatGPT Plus
 - [https://www.zdnet.com/article/how-to-subscribe-to-chatgpt-plus-and-why/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-subscribe-to-chatgpt-plus-and-why/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 16:30:15+00:00

OpenAI keeps unveiling new features and rolling them out to its Plus plan subscribers. Here's what you can get with a subscription.

## Why every tinkerer needs this digital microscope for repairs
 - [https://www.zdnet.com/home-and-office/why-every-tinkerer-needs-this-digital-microscope-for-repairs/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/why-every-tinkerer-needs-this-digital-microscope-for-repairs/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 16:22:00+00:00

Electronics are getting smaller, but our vision isn't getting any better. This helps even the odds!

## Why every tinkerer needs this digital microscope for the most tedious repair jobs
 - [https://www.zdnet.com/home-and-office/why-every-tinkerer-needs-this-digital-microscope-for-the-most-tedious-repair-jobs/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/why-every-tinkerer-needs-this-digital-microscope-for-the-most-tedious-repair-jobs/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 16:22:00+00:00

Electronics are getting smaller, but our vision isn't getting any better. This helps even the odds!

## Shrink wrap tubing 101: Why you should be using this versatile repair material
 - [https://www.zdnet.com/home-and-office/shrink-wrap-tubing-101-why-you-should-be-using-this-versatile-repair-material/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/shrink-wrap-tubing-101-why-you-should-be-using-this-versatile-repair-material/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 15:13:00+00:00

Whether you're an electrician, engineer, or DIY enthusiast, shrink wrap tubing is a must-have tool in your tech repair toolkit. Here's why.

## Bodhi Linux can make an old computer feel brand new
 - [https://www.zdnet.com/article/bodhi-linux-can-make-an-old-computer-feel-brand-new/#ftag=RSSbaffb68](https://www.zdnet.com/article/bodhi-linux-can-make-an-old-computer-feel-brand-new/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 14:53:18+00:00

If you're looking for a different take on the desktop, Bodhi Linux is an option that will have you enjoying your computer again.

## Govee's new smart lights use AI to match your monitor's colors in real time
 - [https://www.zdnet.com/home-and-office/smart-home/govees-new-smart-lights-use-ai-to-match-your-monitors-colors-in-real-time/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/govees-new-smart-lights-use-ai-to-match-your-monitors-colors-in-real-time/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 14:53:07+00:00

The company also announced a new, soon-to-be Matter-compatible Neon Rope Light for desks to perfectly reinvigorate any gaming setup.

## This 6-in-1 USB-C hub exposes your worst cables from the best ones
 - [https://www.zdnet.com/article/this-6-in-1-usb-c-hub-exposes-your-worst-cables-from-the-best-ones/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-6-in-1-usb-c-hub-exposes-your-worst-cables-from-the-best-ones/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 14:32:00+00:00

The Dockcase Pro offers 6-in-1 USB-C support along with an LCD display that gives you all the insight you need into the peripherals you use.

## Bard vs. ChatGPT: Can Bard help you code?
 - [https://www.zdnet.com/article/bard-vs-chatgpt-can-bard-help-you-code/#ftag=RSSbaffb68](https://www.zdnet.com/article/bard-vs-chatgpt-can-bard-help-you-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-03-27 14:26:33+00:00

We begin our series testing Google Bard's answers against ChatGPT's answers. First, we look at whether Bard can help you code. The answer may surprise you.

