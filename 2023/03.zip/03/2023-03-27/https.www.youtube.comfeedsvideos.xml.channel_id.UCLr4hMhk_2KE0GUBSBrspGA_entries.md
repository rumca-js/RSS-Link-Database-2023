# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Czy da się rozmawiać przez słuchawki za 47 złotych?
 - [https://www.youtube.com/watch?v=7voOGBX99jw](https://www.youtube.com/watch?v=7voOGBX99jw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2023-03-27 16:16:20+00:00



