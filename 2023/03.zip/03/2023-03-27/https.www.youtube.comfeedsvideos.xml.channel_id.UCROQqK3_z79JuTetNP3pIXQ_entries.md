# Source:Captain Midnight, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCROQqK3_z79JuTetNP3pIXQ, language:en-US

## Shazam Fury of the Gods: Are Superhero Movies in Big Trouble?
 - [https://www.youtube.com/watch?v=IhTWRVUUHV4](https://www.youtube.com/watch?v=IhTWRVUUHV4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCROQqK3_z79JuTetNP3pIXQ
 - date published: 2023-03-27 21:53:07+00:00

This video is sponsored by Skillshare. The first 1,000 people to use the link will get a 1 month free trial of Skillshare: https://skl.sh/captainmidnight03234
Shazam 2 had the lowest opening box office for a DCU movie ever, should Dc and Marvel be worried? In this video, I go over why the DCEU and the MCU might be slowing down, as well as review the Zachary Levi film itself.
Music by Epidemic Sound (http://www.epidemicsound.com)
Follow me on Twitter: https://twitter.com/midnightcap
Follow me on Facebook: https://www.facebook.com/midnightcap
Special thanks to Andrew Elliott (Stalli111: https://www.youtube.com/user/Stalli111  ) for editing this video!

