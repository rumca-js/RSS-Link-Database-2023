# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## The Safest, Quickest Way to Get Hot Grease Out of a Pan
 - [https://lifehacker.com/the-safest-quickest-way-to-get-hot-grease-out-of-a-pan-1850269466](https://lifehacker.com/the-safest-quickest-way-to-get-hot-grease-out-of-a-pan-1850269466)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--UlBqUtQe--/c_fit,fl_progressive,q_80,w_636/5578568cf5fb5763cfa2755b3f6958ff.jpg" /><p>I am a bit of a <a href="https://lifehacker.com/11-delicious-ways-to-cook-with-bacon-and-its-grease-1847027941">grease hoarder</a>, a habit I come by honestly. My grandmother kept a fairly substantial crock of the bacon grease right next to the stove, and every day she would top it off with the fat that rendered out that morning’s bacon. (I’m sure the grease at the bottom of the crock was iffy, but we never made it…</p><p><a href="https://lifehacker.com/the-safest-quickest-way-to-get-hot-grease-out-of-a-pan-1850269466">Read more...</a></p>

## Make These Spanakopita Pockets for Your Next Snack Dinner
 - [https://lifehacker.com/make-these-spanakopita-pockets-for-your-next-snack-dinn-1850269433](https://lifehacker.com/make-these-spanakopita-pockets-for-your-next-snack-dinn-1850269433)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_1RCOIj---/c_fit,fl_progressive,q_80,w_636/64286ee9f284cdad3559ba02f1f87827.jpg" /><p>One of my favorite types of dinner is snack-feast dinner. My boyfriend and I will make two or three piles of different small snacks. The lineup might include gyoza, <a href="https://lifehacker.com/eat-this-ultra-creamy-baba-ganoush-dip-with-everything-1849366325">baba ganoush</a> and bread, or <a href="https://lifehacker.com/you-are-not-eating-enough-mini-meatballs-1849318923">mini meatball</a> and lettuce wraps. The point is to have small bites (and lots of ‘em) with great flavor, and medium to light prep…</p><p><a href="https://lifehacker.com/make-these-spanakopita-pockets-for-your-next-snack-dinn-1850269433">Read more...</a></p>

## Try Putting Your Clutter in ‘Purgatory’
 - [https://lifehacker.com/try-putting-your-clutter-in-purgatory-1850268872](https://lifehacker.com/try-putting-your-clutter-in-purgatory-1850268872)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 18:44:09+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--v9-ZH_PY--/c_fit,fl_progressive,q_80,w_636/6592c365435be0798b394d3ea268d22d.jpg" /><p>Getting rid of stuff can be really hard, even if you’re not exactly a hoarder. It’s so hard for so many of us, in fact, that <a href="https://www.livescience.com/22140-hoarders-brain-why-they-cant-ditch-stuff.html" rel="noopener noreferrer" target="_blank">scientists have studied why that is</a>—and how to overcome an aversion to decluttering our lives. Just in time for spring cleaning season, recent <a href="https://www.x-mol.net/paper/article/1611567652191420416" rel="noopener noreferrer" target="_blank">research published in the <em>Journal of Consumer</em>…</a></p><p><a href="https://lifehacker.com/try-putting-your-clutter-in-purgatory-1850268872">Read more...</a></p>

## Take These Steps to Heal Your Relationship With Money
 - [https://lifehacker.com/take-these-steps-to-heal-your-relationship-with-money-1850269034](https://lifehacker.com/take-these-steps-to-heal-your-relationship-with-money-1850269034)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--845nb2Xv--/c_fit,fl_progressive,q_80,w_636/fc7355da8063701be65e684fdb0b4c85.jpg" /><p>Like with yo-yo dieting <a href="https://lifehacker.com/the-biggest-mistakes-people-make-when-trying-to-eat-hea-1850089228">when you try to “eat healthier,</a>” it’s easy to find yourself trapped in a cycle of unhealthy habits with money, too. And like your relationship with dieting, your relationship with your finances runs deep—it’s never as simple as being “good” or “bad” with money. </p><p><a href="https://lifehacker.com/take-these-steps-to-heal-your-relationship-with-money-1850269034">Read more...</a></p>

## The Best New iPhone Features in iOS 16.4
 - [https://lifehacker.com/the-best-new-iphone-features-in-ios-16-4-1850268879](https://lifehacker.com/the-best-new-iphone-features-in-ios-16-4-1850268879)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--fJwIVM40--/c_fit,fl_progressive,q_80,w_636/7274a65ff2c9fca4e91edbbec6da8402.jpg" /><p>It’s been 41 days since Apple last issued a software update for your iPhone. How have you survived in the interim? (Hopefully, you updated to iOS 16.3.1 right away, since it came with <a href="https://lifehacker.com/you-should-update-your-apple-devices-right-away-1850112825">serious security patches for an actively exploited zero-day vulnerability</a>.) Thankfully, our wait is over, and it’s finally time for…</p><p><a href="https://lifehacker.com/the-best-new-iphone-features-in-ios-16-4-1850268879">Read more...</a></p>

## That Email Is Not the IRS, It’s a Scam
 - [https://lifehacker.com/that-email-is-not-the-irs-it-s-a-scam-1850268576](https://lifehacker.com/that-email-is-not-the-irs-it-s-a-scam-1850268576)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WMX6qoNa--/c_fit,fl_progressive,q_80,w_636/0a128536afe86dfbfe06725719c88558.jpg" /><p>No one wants the IRS to contact them. You hope to deal with them once a year at tax time, without worrying about audits or mistakes on your numbers. So, if one day, an email from the Internal Revenue Service shows up in your inbox, you’re bound to take it seriously. Well, don’t. In fact, you have my permission to…</p><p><a href="https://lifehacker.com/that-email-is-not-the-irs-it-s-a-scam-1850268576">Read more...</a></p>

## All the Ways You’re Risking a House Fire (Without Realizing It)
 - [https://lifehacker.com/all-the-ways-you-re-risking-a-house-fire-without-reali-1850267641](https://lifehacker.com/all-the-ways-you-re-risking-a-house-fire-without-reali-1850267641)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--xXrZXbvX--/c_fit,fl_progressive,q_80,w_636/0d0735a8dca9284cbf05f56d05842e5c.jpg" /><p>According to the National Fire Protection Associations, <a href="https://www.nfpa.org/-/media/files/news-and-research/fire-statistics-and-reports/building-and-life-safety/oshomes.pdf" rel="noopener noreferrer" target="_blank">there were 51% fewer home fires in the U.S. in 2020 than in 1980</a>. That’s encouraging, but it’s just not good enough for me<em>,</em> America—there are still an estimated 356,500 home fires per year in this country. <br /><br />I don’t want to <em>your</em> home to be burnt to a cinder, so I…</p><p><a href="https://lifehacker.com/all-the-ways-you-re-risking-a-house-fire-without-reali-1850267641">Read more...</a></p>

## You Should Use ChatGPT for These Mundane Tasks
 - [https://lifehacker.com/you-should-use-chatgpt-for-these-mundane-tasks-1850263749](https://lifehacker.com/you-should-use-chatgpt-for-these-mundane-tasks-1850263749)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--B1KyEi63--/c_fit,fl_progressive,q_80,w_636/1c4e3948bd93603f55f7e34198a599ed.jpg" /><p>It’s pretty clear by now that ChatGPT is <a href="https://lifehacker.com/chatgpt-is-the-coolest-and-most-terrifying-new-tech-o-1849874899">not good</a> at being creative, understanding a subject area, or pretty much anything else we associate with “intelligence,” artificial or otherwise. As I noticed when <a href="https://lifehacker.com/i-asked-chatgpt-for-workout-suggestions-and-wow-they-s-1850123377">I tried to use it as a personal trainer</a>:<br /></p><p><a href="https://lifehacker.com/you-should-use-chatgpt-for-these-mundane-tasks-1850263749">Read more...</a></p>

## When Decorating, Stick to the ‘Rule of Three’
 - [https://lifehacker.com/when-decorating-stick-to-the-rule-of-three-1850262726](https://lifehacker.com/when-decorating-stick-to-the-rule-of-three-1850262726)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--b5VdJP3Y--/c_fit,fl_progressive,q_80,w_636/a3932bacad33dd9c213f92a046c7fce2.jpg" /><p>After you finish spring cleaning, you might wonder what to tackle next. Now that you’ve cleaned up, reorganized, and decluttered, you might find that it’s time for a little redecorating—but where should you begin? You can start by clearing away all of the decorations currently living in your space and taking inventory…</p><p><a href="https://lifehacker.com/when-decorating-stick-to-the-rule-of-three-1850262726">Read more...</a></p>

## You Can Get Ring’s Video Doorbell for $39 Right Now
 - [https://lifehacker.com/you-can-get-ring-s-video-doorbell-for-39-right-now-1850263294](https://lifehacker.com/you-can-get-ring-s-video-doorbell-for-39-right-now-1850263294)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--cy6sskQL--/c_fit,fl_progressive,q_80,w_636/7cd4b3fa5c0b45cd7db6646629e363d6.jpg" /><p>Ring’s cheapest video doorbell just got cheaper: The Ring Video Doorbell Wired is currently 40% off, dropping from its $65 price to $39. This is the 2021 version, and as the name implies, it is wired. The Ring Video Doorbell Wired is currently on sale at <a href="https://www.amazon.com/Ring-Video-Doorbell-Wired/dp/B08CKHPP52?asc_campaign=Partner&amp;asc_refurl=https://lifehacker.com/you-can-get-ring-s-video-doorbell-for-39-right-now-1850263294&amp;asc_source=regular&amp;ref_&amp;tag=kinjalifehacker-20" target="_top">Amazon</a>, <a href="https://www.bestbuy.com/site/ring-wi-fi-video-doorbell-wired-black/6450309.p?acampID=&amp;skuId=6450309" rel="noopener noreferrer" target="_blank">BestBuy</a>, and <a href="https://www.target.com/p/ring-video-doorbell-wired/-/A-82304424?nrtv_cid=" rel="noopener noreferrer" target="_blank">Target</a>. It is at its lowest price, <a href="https://camelcamelcamel.com/product/B08CKHPP52#:~:text=Track!-,Amazon%20Price%20History,-Date%20Range" rel="noopener noreferrer" target="_blank">…</a></p><p><a href="https://lifehacker.com/you-can-get-ring-s-video-doorbell-for-39-right-now-1850263294">Read more...</a></p>

## Why Your Electrical Stuff Sometimes Stops Working Until You Push the Magic Red Button
 - [https://lifehacker.com/why-your-electrical-stuff-sometimes-stops-working-until-1850263390](https://lifehacker.com/why-your-electrical-stuff-sometimes-stops-working-until-1850263390)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--S6voELfZ--/c_fit,fl_progressive,q_80,w_636/87161c83f1943ee751892c5ad8a55e3a.jpg" /><p>I was once <em>this close</em> to buying an entirely new refrigerator when ours stopped working. As I remember it, we had a power outage during a storm, and everything except the fridge came back online just fine. We couldn’t find anything obviously wrong with the fridge or with the electrical panel in the basement. The thing…</p><p><a href="https://lifehacker.com/why-your-electrical-stuff-sometimes-stops-working-until-1850263390">Read more...</a></p>

## How to Prep Potatoes Ahead of Time Without Any Browning
 - [https://lifehacker.com/how-to-prep-potatoes-ahead-of-time-without-any-browning-1850263483](https://lifehacker.com/how-to-prep-potatoes-ahead-of-time-without-any-browning-1850263483)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--kqqz5WRl--/c_fit,fl_progressive,q_80,w_636/70ea62c54300dbe292ed9d04757b95f3.jpg" /><p>I have never worked in a professional kitchen, but I have had relations with several people who have, and I’ve enjoyed a few brief glimpses into that world. These glimpses were rendered somewhat blurry by shift drinks, but the thing that blew my mind was how much prep work it took to run a restaurant. Beyond the…</p><p><a href="https://lifehacker.com/how-to-prep-potatoes-ahead-of-time-without-any-browning-1850263483">Read more...</a></p>

## Finally, There’s an Easy Way to Reduce Background Noise on Your iPhone
 - [https://lifehacker.com/finally-there-s-an-easy-way-to-reduce-background-noise-1850262365](https://lifehacker.com/finally-there-s-an-easy-way-to-reduce-background-noise-1850262365)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--V0KjRyAA--/c_fit,fl_progressive,q_80,w_636/7e5482bf0e90a4c1c9989cdac92ce0fb.jpg" /><p>Phone calls sound like crap. They sound better than they used to, but if you need to rely on a <a href="https://en.wikipedia.org/wiki/APCO_radiotelephony_spelling_alphabet" rel="noopener noreferrer" target="_blank">special alphabet system</a> for separating B’s from D’s, it’s not looking great. A new iPhone feature aims to tackle this problem by boosting your voice and reducing background sounds. You just need to know where to find it.<br /></p><p><a href="https://lifehacker.com/finally-there-s-an-easy-way-to-reduce-background-noise-1850262365">Read more...</a></p>

## These PB&J Bars Are Next Level Baked Oats
 - [https://lifehacker.com/these-pb-j-bars-are-next-level-baked-oats-1850263076](https://lifehacker.com/these-pb-j-bars-are-next-level-baked-oats-1850263076)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-03-27 13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--NrFJDn6I--/c_fit,fl_progressive,q_80,w_636/051ba2597741ebf9a04ed8caaa6489ff.jpg" /><p><a href="https://lifehacker.com/make-this-breakfast-cake-with-bananas-and-oats-1850146730">Baked oats</a> are the breakfast cake you didn’t know you needed.  Barring a smidge of baking powder, you don’t use anything other than what you’d normally add to an average bowl of hot oatmeal. Finally, oatmeal that doesn’t totally suck. But there’s also a baked oat for those with a higher standard than “doesn’t totally…</p><p><a href="https://lifehacker.com/these-pb-j-bars-are-next-level-baked-oats-1850263076">Read more...</a></p>

