# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## How to Paint: Miniature of the Month - Dark Angels Assault Intercessor
 - [https://www.youtube.com/watch?v=1-p20tRpmNI](https://www.youtube.com/watch?v=1-p20tRpmNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-03-27 11:58:40+00:00

Learn how to paint your FREE Miniature of the Month in the colours of the Dark Angels using just 8 paints! In no time at all, your Assault Intercessor will be ready to take the fight to the foe. 

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it: http://warhammer.me/3Vkojs6

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## How to Paint: Battle Ready Necromunda - Cawdor Ridge Walkers
 - [https://www.youtube.com/watch?v=tTyypRe0z3s](https://www.youtube.com/watch?v=tTyypRe0z3s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-03-27 09:00:15+00:00

Cawdor Ridge Walkers serve as ramshackle outriders for the Redemption's wasteland crusades. 

By following this step-by-step painting guide, we'll show you how to paint both the Ridge Walker and its Way-brethren rider in just 10 paints.  

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it: http://warhammer.me/3Vkojs6

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

