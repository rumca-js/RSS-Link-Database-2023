# Source:Brad Colbow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A, language:en-US

## How is an AI doing it any different?
 - [https://www.youtube.com/watch?v=pvyADOYlxuU](https://www.youtube.com/watch?v=pvyADOYlxuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A
 - date published: 2023-03-27 13:23:23+00:00

Picasso once said “good artists borrow, great artists steal.” With the AI art debate raging the question I got the most on my previous video about the looming legal fight between copyright holders and AI companies was how is it any different if an AI finds inspiration in an artists work if human artists have worked this way for centuries. 

Check out my intro to digital art course: http://bradsartschool.com

Discounts for my Courses http://brad.site/learn/
Email Newsletter: http://brad.site/signup/

-----------------------------------------------------

Twitter: 
https://twitter.com/bradcolbow

Instagram:
https://www.instagram.com/bcolbow/

Drawing Tech Top 10 lists:
http://brad.site/

My Drawing and video gear: 
http://brad.site/mygear/

