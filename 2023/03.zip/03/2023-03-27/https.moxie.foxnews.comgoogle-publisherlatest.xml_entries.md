# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## American couple kidnapped by Haitian gang, family begs for release
 - [https://www.foxnews.com/world/american-couple-kidnapped-haitian-gang-family-begs-release](https://www.foxnews.com/world/american-couple-kidnapped-haitian-gang-family-begs-release)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 19:02:46+00:00

Relatives of Jean-Dickens and Abigail Michael Toussaint are in contact with the FBI as they publicly plead for Haitian gang members to release them.

## Louisiana police helicopter crash kills 2 officers
 - [https://www.foxnews.com/us/louisiana-police-helicopter-crash-kills-2-officers](https://www.foxnews.com/us/louisiana-police-helicopter-crash-kills-2-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 19:01:37+00:00

A Louisiana police helicopter crashed into a surgarcane field, killing two officers Sunday. The aircraft&apos;s disappearance wasn&apos;t noticed for several hours, when a search was launched.

## Sending a message: Why Congress passes bills that have little or no chance of becoming law
 - [https://www.foxnews.com/politics/sending-message-congress-passes-bills-little-chance-becoming-law](https://www.foxnews.com/politics/sending-message-congress-passes-bills-little-chance-becoming-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 19:01:18+00:00

The public often chastise Congress for passing “messaging&quot; bills and Congressional Republicans certainly got the message during the pandemic about public education.

## Nashville school shooting: Biden criticized for joking about ice cream in first statement since attack
 - [https://www.foxnews.com/media/nashville-school-shooting-biden-torched-joking-ice-cream-first-statement-attack](https://www.foxnews.com/media/nashville-school-shooting-biden-torched-joking-ice-cream-first-statement-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 19:00:42+00:00

Former Republican Gov. Chris Christie criticized President Biden for his initial response to the Nashville school shooting, which left three adults and three children dead.

## ‘Three’s Company’ star Suzanne Somers ‘would be honored’ to have Jennifer Aniston play Chrissy Snow
 - [https://www.foxnews.com/entertainment/threes-company-star-suzanne-somers-honored-jennifer-aniston-play-chrissy-snow](https://www.foxnews.com/entertainment/threes-company-star-suzanne-somers-honored-jennifer-aniston-play-chrissy-snow)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 19:00:34+00:00

&quot;Three&apos;s Company,&quot; the &apos;70s series, starred Suzanne Somers, Joyce DeWitt and John Ritter. Somers, who played Chrissy Snow, is eager for a reboot of the classic sitcom.

## Nearly half of parents with adult children help pay their offspring's bills, survey finds
 - [https://www.foxnews.com/media/nearly-half-parents-adult-children-help-pay-offsprings-bills-survey-finds](https://www.foxnews.com/media/nearly-half-parents-adult-children-help-pay-offsprings-bills-survey-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 19:00:14+00:00

A survey conducted by Savings.com found that nearly half of parents with adult-aged children help pay their bills with many of their children still living at home.

## New Mexico community to resume police services after 3 year gap
 - [https://www.foxnews.com/us/new-mexico-community-resume-police-services-3-year-gap](https://www.foxnews.com/us/new-mexico-community-resume-police-services-3-year-gap)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 19:00:07+00:00

A New Mexico community is set to have a police agency again for the first time in three years. The Questa Police Department is scheduled to reopen April 1 with four police officers.

## New investigation accounts for remains of US airman whose plane was shot down in Germany
 - [https://www.foxnews.com/us/new-investigation-accounts-remains-us-airman-whose-plane-shot-down-germany](https://www.foxnews.com/us/new-investigation-accounts-remains-us-airman-whose-plane-shot-down-germany)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:50:40+00:00

The remains of a U.S. airman whose plane was shot down during World War II have been accounted for. Investigators searched the Germany crash site and found two other sets of remains.

## Pennsylvania Sen. John Fetterman has missed an alarmingly high percentage of roll-call votes due to illness
 - [https://www.foxnews.com/politics/pennsylvania-senator-john-fetterman-missed-alarmingly-high-percentage-roll-call-votes-illness](https://www.foxnews.com/politics/pennsylvania-senator-john-fetterman-missed-alarmingly-high-percentage-roll-call-votes-illness)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:49:19+00:00

Sen. John Fetterman, D-Pa., has missed 53 of the last 64 Senate roll call votes since checking into a hospital to be treated for clinical depression in February.

## Orlando Bloom visits children affected by war in Ukraine: They 'need their childhoods back'
 - [https://www.foxnews.com/entertainment/orlando-bloom-visits-children-affected-war-ukraine-childhoods](https://www.foxnews.com/entertainment/orlando-bloom-visits-children-affected-war-ukraine-childhoods)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:48:00+00:00

Orlanda Bloom visited children and families in Ukraine as part of a trip with UNICEF to see the effect of the war with Russia on the children of the country.

## Wisconsin senior gets 10 years for 1986 killing, county's oldest unsolved case
 - [https://www.foxnews.com/us/wisconsin-senior-gets-10-years-1986-killing-countys-oldest-unsolved-case](https://www.foxnews.com/us/wisconsin-senior-gets-10-years-1986-killing-countys-oldest-unsolved-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:46:39+00:00

Lou Griffin, 67, of Racine, Wisconsin, was sentenced to ten years in prison Monday for Lisa Holstead&apos;s homicide by reckless conduct in 1986.

## New Jersey AG announces state takeover of Paterson Police Department
 - [https://www.foxnews.com/politics/new-jersey-ag-announces-state-takeover-paterson-police-department](https://www.foxnews.com/politics/new-jersey-ag-announces-state-takeover-paterson-police-department)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:45:02+00:00

Democratic New Jersey Attorney General Matt Platkin announced Monday the state takeover of the Paterson Police Department after a controversial shooting earlier this month.

## Phillies' JT Realmuto ejected from spring training game in bizarre sequences with umpire
 - [https://www.foxnews.com/sports/phillies-jt-realmuto-ejected-spring-training-game-bizarre-sequences-umpire](https://www.foxnews.com/sports/phillies-jt-realmuto-ejected-spring-training-game-bizarre-sequences-umpire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:42:24+00:00

Philadelphia Phillies catcher J.T. Realmuto was ejected from a spring training game after a bizarre interaction with the home plate umpire.

## Van crashes into northern Maine living room killing 2 people
 - [https://www.foxnews.com/us/van-crashes-northern-maine-living-room-killing-2-people](https://www.foxnews.com/us/van-crashes-northern-maine-living-room-killing-2-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:39:00+00:00

A van crashed into a northern Maine living room and killed two people Saturday evening. The vehicle spun out of control and crashed into the home killing the occupant and motorist.

## Lake Tahoe casino shooting kills 1, brings heavy police response
 - [https://www.foxnews.com/us/lake-tahoe-casino-shooting-kills-1-brings-heavy-police-response](https://www.foxnews.com/us/lake-tahoe-casino-shooting-kills-1-brings-heavy-police-response)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:37:32+00:00

A shooting in a Lake Tahoe casino killed one and brought a heavy police response. Nevada officials arrested an alleged assailant and a woman in vehicle nearby.

## Aaron Hernandez's brother arrested after allegedly throwing brick with cryptic note at ESPN HQ
 - [https://www.foxnews.com/sports/aaron-hernandezs-brother-arrested-allegedly-throwing-brick-cryptic-note-espn-hq](https://www.foxnews.com/sports/aaron-hernandezs-brother-arrested-allegedly-throwing-brick-cryptic-note-espn-hq)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:36:33+00:00

Dennis John Hernandez, the brother of Aaron Hernandez, was arrested on Thursday after allegedly throwing a brick at ESPN’s headquarters in Bristol, Connecticut, according to a report and police records.

## US lawsuit seeks to protect habitat of endangered corals
 - [https://www.foxnews.com/us/us-lawsuit-seeks-protect-habitat-endangered-corals](https://www.foxnews.com/us/us-lawsuit-seeks-protect-habitat-endangered-corals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:36:07+00:00

A U.S. lawsuit is seeking to protect the habitat of 12 endangered coral species across the Caribbean and Pacific Oceans. The lawsuit accuses the government of failing to protect corals.

## SD lawmakers fail to override Gov. Noem's cryptocurrency regulation veto
 - [https://www.foxnews.com/politics/sd-lawmakers-fail-override-gov-noems-cryptocurrency-regulation-veto](https://www.foxnews.com/politics/sd-lawmakers-fail-override-gov-noems-cryptocurrency-regulation-veto)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:34:36+00:00

The South Dakota House of Representatives failed Monday to override Republican Gov. Kristi Noem&apos;s veto of a bill aimed at regulating cryptocurrency at the state level.

## Fishermen admit to stuffing catches with fillets, lead weights to win Ohio tournament
 - [https://www.foxnews.com/us/fishermen-admit-stuffing-catches-fillets-lead-weights-win-ohio-tournament](https://www.foxnews.com/us/fishermen-admit-stuffing-catches-fillets-lead-weights-win-ohio-tournament)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:33:16+00:00

Jacob Runyan and Chase Cominsky pled guilty to claims that they cheated in an Ohio fishing tournament by stuffing walleyes with lead weights and fish fillets.

## Tennessee freeway crash kills 6 youths thrown from car
 - [https://www.foxnews.com/us/tennessee-freeway-crash-kills-6-youths-thrown-car](https://www.foxnews.com/us/tennessee-freeway-crash-kills-6-youths-thrown-car)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:31:28+00:00

A freeway crash fatally thew six youths from their vehicle early morning on Sunday. The Tennessee Highway Patrol is investigating the cause of the crash.

## Family of Kansas toddler killed by police files federal lawsuit
 - [https://www.foxnews.com/us/family-kansas-toddler-killed-police-files-federal-lawsuit](https://www.foxnews.com/us/family-kansas-toddler-killed-police-files-federal-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:30:30+00:00

The family of a two-year-old Kansas girl fatally shot by a Missouri police officer during a standoff has filed a lawsuit blaming two cities, a county, and the officer for the death.

## Nashville school shooter Audrey Hale: Who is 28-year-old transgender woman who opened fire at Covenant school
 - [https://www.foxnews.com/us/nashville-shooter-audrey-hale-transgender-woman-opened-fire-covenant-school](https://www.foxnews.com/us/nashville-shooter-audrey-hale-transgender-woman-opened-fire-covenant-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:30:25+00:00

Police dentified the shooter who opened fire on Monday morning at The Covenant School as 28-year-old Audrey Hale, a transgender woman and former student at the school.

## Gov. DeSantis signs universal school choice into law: 'Monumental day in Florida history'
 - [https://www.foxnews.com/media/gov-desantis-signs-universal-school-choice-into-law-monumental-day-in-florida-history](https://www.foxnews.com/media/gov-desantis-signs-universal-school-choice-into-law-monumental-day-in-florida-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:30:18+00:00

Florida Governor Ron DeSantis signed House Bill 1 which expands available school choice options for all 1.3 million students in Florida by eliminating financial eligibility restrictions.

## Freight train carrying iron ore derails in Mojave Desert
 - [https://www.foxnews.com/us/freight-train-carrying-iron-ore-derails-mojave-desert](https://www.foxnews.com/us/freight-train-carrying-iron-ore-derails-mojave-desert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:28:38+00:00

A freight train that was carrying iron ore derailed in the Mojave Desert on Monday. Numerous cars derailed in a remote area, but there were no injuries.

## California zoo recovers 5 of 6 birds that escaped storm-damaged aviary
 - [https://www.foxnews.com/us/california-zoo-recovers-5-6-birds-escaped-storm-damaged-aviary](https://www.foxnews.com/us/california-zoo-recovers-5-6-birds-escaped-storm-damaged-aviary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 18:25:53+00:00

California&apos;s Oakland Zoo recovered five out of the six birds that escaped the storm-damaged aviary. The crow was captured Saturday after an Oakland resident reported it was in her yard.

## Soccer star on Becky G cheating rumors: '10 minute lapse in judgment resulted in an extortion plot'
 - [https://www.foxnews.com/sports/soccer-star-on-becky-g-cheating-rumors-10-minute-lapse-judgment-resulted-extortion-plot](https://www.foxnews.com/sports/soccer-star-on-becky-g-cheating-rumors-10-minute-lapse-judgment-resulted-extortion-plot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 17:44:46+00:00

Major League Soccer player Sebastian Lletget responded to rumors he cheated on his fiancee Becky G on Monday in a lengthy statement posted to Instagram.

## Sen. Hawley calls for 'tough, tenacious' inspector general to oversee Ukraine aid
 - [https://www.foxnews.com/politics/josh-hawley-calls-tough-tenacious-inspector-general-oversee-ukraine-aid](https://www.foxnews.com/politics/josh-hawley-calls-tough-tenacious-inspector-general-oversee-ukraine-aid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 17:35:46+00:00

Sen. Josh Hawley said he hopes that appointing a watchdog to oversee U.S. aid to Ukraine should not &quot;controversial,&quot; and said he expects his proposal to get a vote in the Senate.

## Nashville shooting led to Shawn Johnson East's children's school to be put on lockdown: 'So incredibly sad'
 - [https://www.foxnews.com/sports/nashville-shooting-led-shawn-johnson-easts-childrens-school-put-lockdown-incredibly-sad](https://www.foxnews.com/sports/nashville-shooting-led-shawn-johnson-easts-childrens-school-put-lockdown-incredibly-sad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 17:31:33+00:00

Shawn Johnson East revealed on social media that her stomach dropped when she got a phone call about her children&apos;s school being on lockdown in the midst of the Nashville shooting.

## Fired NYC weatherman launches new weather subscription service after leaked nude scandal
 - [https://www.foxnews.com/media/fired-nyc-weatherman-launches-new-weather-subscription-service-leaked-nude-scandal](https://www.foxnews.com/media/fired-nyc-weatherman-launches-new-weather-subscription-service-leaked-nude-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 17:30:01+00:00

Former New York City meteorologist Erick Adame announced on his Twitter account Tuesday that he will spearheading his own streaming service after his nude image leaked.

## Trump-Manhattan DA: Grand jury wraps Monday proceedings with no vote in Trump probe
 - [https://www.foxnews.com/politics/trump-manhattan-da-grand-jury-wraps-monday-proceedings-no-vote-trump-probe](https://www.foxnews.com/politics/trump-manhattan-da-grand-jury-wraps-monday-proceedings-no-vote-trump-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 17:11:04+00:00

The Manhattan grand jury wrapped its proceedings Monday afternoon with no vote in former President Trump’s case, two sources told Fox News.

## Ohio man pleads not guilty in fiancée's 2011 homicide
 - [https://www.foxnews.com/us/ohio-man-pleads-not-guilty-fiancees-2011-homicide](https://www.foxnews.com/us/ohio-man-pleads-not-guilty-fiancees-2011-homicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 17:11:01+00:00

John Carter, 34, of Hamilton, Ohio, entered a not-guilty plea after being charged with two counts of murder in former fiancée Katelyn Markham&apos;s 2011 disappearance and death.

## Wisconsin Gov. Evers orders flags lowered for recently-identified WWII soldier killed in action
 - [https://www.foxnews.com/politics/wisconsin-gov-evers-orders-flags-lowered-recently-identified-wwii-soldier-killed-action](https://www.foxnews.com/politics/wisconsin-gov-evers-orders-flags-lowered-recently-identified-wwii-soldier-killed-action)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 17:08:58+00:00

Democratic Wisconsin Gov. Tony Evers ordered flags at half-staff Tuesday to commemorate William Simon, a recently-identified U.S. soldier who died in Germany during World War II.

## Philadelphia officials report no chemicals in water after nearby spill
 - [https://www.foxnews.com/us/philadelphia-officials-report-no-chemicals-water-nearby-spill](https://www.foxnews.com/us/philadelphia-officials-report-no-chemicals-water-nearby-spill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 17:07:44+00:00

Philadelphia health officials have yet to report any water contamination following a large chemical spill in the Delaware River that originated in neighboring Bucks County.

## California shooting at Sikh temple during religious celebration leaves two wounded: sheriff’s office
 - [https://www.foxnews.com/us/california-shooting-sikh-temple-during-religious-celebration-leaves-two-wounded-sheriffs-office](https://www.foxnews.com/us/california-shooting-sikh-temple-during-religious-celebration-leaves-two-wounded-sheriffs-office)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:57:00+00:00

Gunfire erupted during a Sikh religious celebration in Sacramento, California Sunday afternoon, leaving two people wounded, the sheriff&apos;s office said.

## Orange ladybugs and the spiritual meaning behind the insect: What to know
 - [https://www.foxnews.com/lifestyle/orange-ladybugs-spiritual-meaning-behind-insect-what-know](https://www.foxnews.com/lifestyle/orange-ladybugs-spiritual-meaning-behind-insect-what-know)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:56:47+00:00

Orange ladybugs have symbolic meanings in spiritual circles. Here&apos;s what orange ladybugs mean in various cultures and other facts about the unique bug.

## Nashville shooting: Six US faith leaders extend comfort in wake of Covenant School tragedy
 - [https://www.foxnews.com/lifestyle/nashville-shooting-us-faith-leaders-extend-comfort-wake-covenant-school-tragedy](https://www.foxnews.com/lifestyle/nashville-shooting-us-faith-leaders-extend-comfort-wake-covenant-school-tragedy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:53:42+00:00

Faith leaders react after a shooting in Nashville, Tennessee, at the Covenant School leaves three children and three staff dead. Leaders pray for our nation and warn of a decline in values.

## Blac Chyna removes 'demonic' tattoo as she regains her faith
 - [https://www.foxnews.com/entertainment/blac-chyna-removes-demonic-tattoo-regains-faith](https://www.foxnews.com/entertainment/blac-chyna-removes-demonic-tattoo-regains-faith)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:50:50+00:00

Blac Chyna has taken a big step in her move towards a faith-based life. After getting implants and fillers removed, she&apos;s now getting rid of a &quot;demonic&quot; tattoo.

## Sabres’ Ilya Lyubushkin to skip out on Pride Night warmups citing safety concerns in Russia
 - [https://www.foxnews.com/sports/sabres-ilya-lyubushkin-skip-out-pride-night-warmups-citing-safety-concerns-russia](https://www.foxnews.com/sports/sabres-ilya-lyubushkin-skip-out-pride-night-warmups-citing-safety-concerns-russia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:46:01+00:00

Buffalo Sabres defenseman Ilya Lyubushkin will not participate in the team&apos;s Pride Night warmups before Monday&apos;s game against the Canadiens, citing safety concerns in his native Russia.

## Georgia deputies shoot, wound motorcyclist after chase
 - [https://www.foxnews.com/us/georgia-deputies-shoot-wound-motorcyclist-chase](https://www.foxnews.com/us/georgia-deputies-shoot-wound-motorcyclist-chase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:41:57+00:00

Georgia deputies shot and injured a motorcyclist after a police chase early Sunday. Police tried to pull the motorcyclist over for not having a license plate.

## Lawmaker disinvited from Hawaiian parade over 'hurtful' pride flag comments
 - [https://www.foxnews.com/media/lawmaker-disinvited-hawaiian-parade-hurtful-pride-flag-comments](https://www.foxnews.com/media/lawmaker-disinvited-hawaiian-parade-hurtful-pride-flag-comments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:40:36+00:00

A Hawaiian lawmaker was disinvited from a parade honoring a Native Hawaiian leader and prince after he questioned a middle school principal’s display of a pride flag in support of LGBTQ+ people.

## Rebels kill at least 17 people in troubled eastern Congo
 - [https://www.foxnews.com/world/rebels-kill-least-17-people-troubled-eastern-congo](https://www.foxnews.com/world/rebels-kill-least-17-people-troubled-eastern-congo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:27:36+00:00

The rebels killed at least 17 people in the troubled part of eastern Congo over the weekend. The killings were tied to surging violence in an area controlled by rebel militias.

## In Maine, former Chipotle employees get $240K in alleged union-busting settlement
 - [https://www.foxnews.com/us/maine-former-chipotle-employees-get-240k-alleged-union-busting-settlement](https://www.foxnews.com/us/maine-former-chipotle-employees-get-240k-alleged-union-busting-settlement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:24:52+00:00

Chipotle has reached a $240,000 with former employees of a now-defunct Augusta, Maine; the company allegedly shuttered the location when employees tried to unionize.

## PA Gov. Shapiro orders flags to half-staff for 7 killed in chocolate factory explosion
 - [https://www.foxnews.com/us/pa-gov-shapiro-orders-flags-half-staff-7-killed-chocolate-factory-explosion](https://www.foxnews.com/us/pa-gov-shapiro-orders-flags-half-staff-7-killed-chocolate-factory-explosion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:09:07+00:00

Democratic Pennsylvania Gov. Josh Shapiro has ordered state flags to half-staff after at least seven people were killed in an explosion at West Reading&apos;s R.M. Palmer Co. plant.

## Jessie James Decker, Brittany Aldean and Jana Kramer share heartbreak over Nashville school shooting
 - [https://www.foxnews.com/entertainment/jessie-james-decker-brittany-aldean-jana-kramer-share-heartbreak-nashville-school-shooting](https://www.foxnews.com/entertainment/jessie-james-decker-brittany-aldean-jana-kramer-share-heartbreak-nashville-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:07:21+00:00

Country music stars reacted to a mass shooting Monday when a 28-year-old woman opened fire at a private Christian elementary school in Nashville.

## 2 Austrian police officers injured by climate protestors outside conference, 143 detained
 - [https://www.foxnews.com/world/2-austrian-police-officers-injured-climate-protestors-conference-143-detained](https://www.foxnews.com/world/2-austrian-police-officers-injured-climate-protestors-conference-143-detained)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:06:30+00:00

Two police officers were injured in a Monday struggle with climate protestors outside the European Gas Conference in Vienna. 143 people were detained over the incident.

## Tennessee crash kills six children; one woman critically injured
 - [https://www.foxnews.com/us/tennessee-crash-kills-children-woman-critically-injured](https://www.foxnews.com/us/tennessee-crash-kills-children-woman-critically-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:06:15+00:00

Members of the Tennessee Highway Patrol are investigating a crash that occurred on Sunday morning, killing six children between 1-18 years old.

## Only a quarter of Democrats want President Biden to run for re-election in 2024: poll
 - [https://www.foxnews.com/politics/only-quarter-democrats-want-president-biden-run-for-re-election-2024-poll](https://www.foxnews.com/politics/only-quarter-democrats-want-president-biden-run-for-re-election-2024-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:02:27+00:00

A plurality of Democrats say they want President Biden to step aside and not seek a second term in the White House next year, according to a new national survey.

## Texas Dem Rep. Sheila Jackson Lee announces run for Houston mayor
 - [https://www.foxnews.com/politics/texas-democrat-representative-sheila-jackson-lee-announces-run-houston-mayor](https://www.foxnews.com/politics/texas-democrat-representative-sheila-jackson-lee-announces-run-houston-mayor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:01:21+00:00

Democratic Texas Rep. Sheila Jackson Lee, Texas, announced she will retire from Congress, where she served for more than 28 years, and will run to be the next mayor of Houston.

## Parents of Marine killed in Kabul bombing call out Biden admin, Blinken: 'They lied'
 - [https://www.foxnews.com/media/parents-marine-killed-kabul-bombing-call-biden-admin-blinken-lied](https://www.foxnews.com/media/parents-marine-killed-kabul-bombing-call-biden-admin-blinken-lied)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 16:00:06+00:00

Parents of Staff Sgt. Darin Taylor Hoover joined &quot;America&apos;s Newsroom&quot; to react the Biden administration being pressed for providing transparency on the 2021 Afghanistan withdrawal.

## Nashville school shooting: Biden calls on reporters to focus on PTSD of students, teachers
 - [https://www.foxnews.com/politics/nashville-school-shooting-biden-calls-reporters-focus-ptsd-students-teachers](https://www.foxnews.com/politics/nashville-school-shooting-biden-calls-reporters-focus-ptsd-students-teachers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:54:42+00:00

Addressing Monday&apos;s mass shooting at the Covenant School in Nashville, President Joe Biden urged reporters to focus on the PSTD of the students and teachers who survived.

## Mississippi governor's tornado damage tour crashed by Democrat opponent: 'He should be better than this'
 - [https://www.foxnews.com/politics/mississippi-governors-tornado-damage-tour-crashed-democrat-opponent-should-be-better-than-this](https://www.foxnews.com/politics/mississippi-governors-tornado-damage-tour-crashed-democrat-opponent-should-be-better-than-this)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:50:29+00:00

GOP Mississippi Gov. Tate Reeves&apos; Democrat opponent Brandon Presley crashed an official survey of tornado damage in Rolling Fork to campaign for governor.

## Murdaugh Moselle possessions pop up on eBay with exorbitant price tags
 - [https://www.foxnews.com/us/murdaugh-moselle-possessions-pop-up-ebay-exorbitant-price-tags](https://www.foxnews.com/us/murdaugh-moselle-possessions-pop-up-ebay-exorbitant-price-tags)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:48:03+00:00

Murdaugh estate possessions that were auctioned off last week appear to be selling on eBay — including a crossbow for $21,000 and a camouflage gun case with an opening bid of $4,999.

## Liberal mainline church body urges Kentucky governor to veto bill banning trans procedures for minors
 - [https://www.foxnews.com/politics/liberal-mainline-church-body-urges-kentucky-governor-veto-bill-banning-trans-procedures-minors](https://www.foxnews.com/politics/liberal-mainline-church-body-urges-kentucky-governor-veto-bill-banning-trans-procedures-minors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:34:29+00:00

The stated clerk of the Presbyterian Church (U.S.A.) issued a statement urging Democratic Kentucky Gov. Andy Beshear to veto a bill banning transgender procedures for minors.

## Dick Van Dyke details car accident injuries, says he ‘did a face plant’ into steering wheel
 - [https://www.foxnews.com/entertainment/dick-van-dyke-car-accident-injuries-did-face-plant-steering-wheel](https://www.foxnews.com/entertainment/dick-van-dyke-car-accident-injuries-did-face-plant-steering-wheel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:23:14+00:00

Dick Van Dyke is opening up about the injuries he sustained from his car accident earlier this month. The 97-year-old entertainer showed off his lip stitches.

## Air Force says ‘inclusive and equitable culture’ part of strategy to ‘fly, fight and win’ against China
 - [https://www.foxnews.com/politics/air-force-says-inclusive-equitable-culture-part-strategy-fly-fight-win-against-china](https://www.foxnews.com/politics/air-force-says-inclusive-equitable-culture-part-strategy-fly-fight-win-against-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:19:41+00:00

A strategy released by a division of the Air Force that supports installations around the country said building an inclusive, diverse culture is a component of creating a lethal force.

## Reddit user slams slowness of fellow air passengers after plane lands: 'Absolutely clueless'
 - [https://www.foxnews.com/lifestyle/reddit-user-slams-slowness-of-fellow-air-passengers-after-plane-lands-absolutely-clueless](https://www.foxnews.com/lifestyle/reddit-user-slams-slowness-of-fellow-air-passengers-after-plane-lands-absolutely-clueless)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:19:33+00:00

A Reddit user took to the &quot;airlines&quot; subreddit to complain about the slowness of deplaning after a recent flight. Other Redditors weighed in as did other air travelers, sharing possible causes.

## FOX Corporation donates $1 million to American Red Cross to support Southern states hit by deadly tornadoes
 - [https://www.foxnews.com/media/fox-corporation-donates-1-million-american-red-cross-support-southern-states-hit-deadly-tornadoes](https://www.foxnews.com/media/fox-corporation-donates-1-million-american-red-cross-support-southern-states-hit-deadly-tornadoes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:08:37+00:00

FOX Corporation donated $1 million to the American Red Cross on Monday to help support Mississippi and other Southern states impacted by devastating tornadoes.

## Columbus Zoo regains key accreditation following inspection
 - [https://www.foxnews.com/us/columbus-zoo-regains-key-accreditation-following-inspection](https://www.foxnews.com/us/columbus-zoo-regains-key-accreditation-following-inspection)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:03:07+00:00

The Columbus Zoo and Aquarium has regained full accreditation from the prestigious Association of Zoos &amp; Aquariums following a December inspection.

## Hungarian parliament approves Finland's NATO bid
 - [https://www.foxnews.com/world/hungarian-parliament-approves-finlands-nato-bid](https://www.foxnews.com/world/hungarian-parliament-approves-finlands-nato-bid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:02:02+00:00

Hungary&apos;s parliament on Monday voted in approval of Finland&apos;s bid to join NATO, removing a key roadblock in the Baltic nation&apos;s push for membership.

## Texas softball player's slide goes viral after fooling catcher: 'I didn't think she'd fall for it'
 - [https://www.foxnews.com/media/texas-softball-player-slide-goes-viral-fooling-catcher-didnt-think-fall](https://www.foxnews.com/media/texas-softball-player-slide-goes-viral-fooling-catcher-didnt-think-fall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 15:00:04+00:00

Texas high school soft ball player Jada Walton tricked her opponent in viral footage by avoiding being tagged before home base, helping her team secure the win

## Europe's electric car mandate is getting torn up, and Ferrari is into it
 - [https://www.foxnews.com/auto/europes-electric-car-mandate-ferrari](https://www.foxnews.com/auto/europes-electric-car-mandate-ferrari)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:54:34+00:00

The European Commission has agreed to allow internal combustion engines that run on e-fuel after gasoline and diesel models are banned in 2035.

## Georgia teen hospitalized after alleged torture, hazing
 - [https://www.foxnews.com/us/georgia-teen-hospitalized-alleged-torture-hazing](https://www.foxnews.com/us/georgia-teen-hospitalized-alleged-torture-hazing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:53:19+00:00

A 19-year-old was hospitalized Tuesday after teens allegedly forced him to guzzle vodka and take drugs in a disturbing hazing incident in St. Simons Island, Georgia.

## Tennessee school shooting: What to know about Covenant School in Nashville
 - [https://www.foxnews.com/us/tennessee-school-shooting-what-know-about-covenant-school-nashville](https://www.foxnews.com/us/tennessee-school-shooting-what-know-about-covenant-school-nashville)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:47:39+00:00

The Covenant School in Nashville, where three students and three adults were killed in a Monday shooting, is a private Presbyterian school for pre-K through sixth-grade students.

## Former top Obama aide claims GOP concerns over alleged Chinese spy app is 'bad faith BS'
 - [https://www.foxnews.com/politics/former-top-obama-aide-claims-gop-concerns-over-alleged-chinese-spy-app-bad-faith-bs](https://www.foxnews.com/politics/former-top-obama-aide-claims-gop-concerns-over-alleged-chinese-spy-app-bad-faith-bs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:46:41+00:00

Dan Pfeiffer, a former senior adviser to President Obama, said Republicans are engaging in &quot;bad faith BS&quot; with their push to ban TikTok and suggested this is a trap for President Biden.

## Biden calls on Congress 'to do something,’ address gun violence after Nashville shooting, White House says
 - [https://www.foxnews.com/politics/biden-calls-congress-act-after-nashville-shooting-white-house-says](https://www.foxnews.com/politics/biden-calls-congress-act-after-nashville-shooting-white-house-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:21:25+00:00

White House Press Secretary Karine Jean-Pierre said Monday that President Biden is calling on Congress to step up and address gun violence following a deadly shooting in Tennessee.

## Supreme Court asked to rule on state law that prohibits therapists from counseling against gender transition
 - [https://www.foxnews.com/politics/supreme-court-rule-state-law-prohibits-therapists-counseling-against-gender-transition](https://www.foxnews.com/politics/supreme-court-rule-state-law-prohibits-therapists-counseling-against-gender-transition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:20:09+00:00

Alliance Defending Freedom asked the Supreme Court to hear a case brought by a therapist in Washington state challenging a law he says is unconstitutional.

## Should you wash ground beef? Expert weighs in on the viral cooking method
 - [https://www.foxnews.com/lifestyle/should-you-wash-ground-beef-expert-weighs-in-viral-cooking-method](https://www.foxnews.com/lifestyle/should-you-wash-ground-beef-expert-weighs-in-viral-cooking-method)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:18:09+00:00

Do you wash your ground beef? A registered dietician weighs in on this viral trend that exists on TikTok where viewers are wondering if they have been cooking beef wrong.

## John Kerry rushes to defense of climate activist leaders who use private jets
 - [https://www.foxnews.com/politics/john-kerry-rushes-defense-climate-activist-leaders-use-private-jets](https://www.foxnews.com/politics/john-kerry-rushes-defense-climate-activist-leaders-use-private-jets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:05:52+00:00

U.S. Climate Envoy John Kerry came to the defense of world leaders who fly on gas-guzzling private jets while simultaneously pushing policies to transition the world to green energy.

## Supreme Court dismisses case brought by parents of teen who was naked, unarmed when he was shot by OK police
 - [https://www.foxnews.com/us/supreme-court-dismisses-case-brought-parents-of-teen-naked-unarmed-shot-ok-police](https://www.foxnews.com/us/supreme-court-dismisses-case-brought-parents-of-teen-naked-unarmed-shot-ok-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:05:10+00:00

A teen was killed by Oklahoma police while he was naked and unarmed. The teen&apos;s parents brought the case to the Supreme Court, but it was dismissed.

## Human remains found by hunters in Indiana belong to 40-year-old man who went missing in 2018
 - [https://www.foxnews.com/us/human-remains-found-hunters-indiana-belonged-40-year-old-man-went-missing-2018](https://www.foxnews.com/us/human-remains-found-hunters-indiana-belonged-40-year-old-man-went-missing-2018)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:01:24+00:00

Indiana hunters found human remains on Saturday in Spencer County. The remains have been identified as a 40-year-old man who went missing in 2018.

## Colleges cashing in on lucrative DEI programs, former teacher warns: 'These are race hustlers'
 - [https://www.foxnews.com/media/colleges-cashing-lucrative-dei-programs-former-teacher-warns-race-hustlers](https://www.foxnews.com/media/colleges-cashing-lucrative-dei-programs-former-teacher-warns-race-hustlers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 14:00:43+00:00

Former California high school teacher Kali Fontanilla criticized lucrative DEI certificate programs offered at several elite U.S. colleges and universities.

## Nashville school shooting leads to heartbreaking reactions in NFL world: 'This s--- has got to stop'
 - [https://www.foxnews.com/sports/nashville-school-shooting-leads-heartbreaking-reactions-nfl-world-got-stop](https://www.foxnews.com/sports/nashville-school-shooting-leads-heartbreaking-reactions-nfl-world-got-stop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:59:31+00:00

The Tennessee Titans were among those in the NFL world to react to the deadly shooting at a Christian private school on Monday. Several people were confirmed dead.

## Broncos' Sean Payton unmoved on Jerry Jeudy, Courtland Sutton situation: 'We're not trading those two players'
 - [https://www.foxnews.com/sports/broncos-sean-payton-unmoved-jerry-jeudy-courtland-sutton-situation-not-trading-those-two-players](https://www.foxnews.com/sports/broncos-sean-payton-unmoved-jerry-jeudy-courtland-sutton-situation-not-trading-those-two-players)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:59:14+00:00

The Denver Broncos are &quot;void&quot; of draft picks this year, but head coach Sean Payton says trading receivers Jerry Jeudy and Courtland Sutton isn&apos;t an option.

## Supreme Court to decide whether disabled activist can file lawsuits against hotels she doesn't intend to visit
 - [https://www.foxnews.com/us/supreme-court-decide-whether-disabled-activist-lawsuits-against-hotels-doesnt-intend-visit](https://www.foxnews.com/us/supreme-court-decide-whether-disabled-activist-lawsuits-against-hotels-doesnt-intend-visit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:56:51+00:00

A disabled activist is looking to file disability rights lawsuits against hotels she doesn&apos;t intend to visit. The Supreme Court will decide if the activist can do so.

## Vermont investigation into man who was found dead in holding cell continues, could take months
 - [https://www.foxnews.com/us/vermont-investigation-man-found-dead-holding-cell-continues-months](https://www.foxnews.com/us/vermont-investigation-man-found-dead-holding-cell-continues-months)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:55:30+00:00

An investigation into the death of a man in a Vermont holding cell will continue. Darrell Jones was arrested on drug charges Thursday afternoon.

## Mike Trout teams with Tiger Woods for New Jersey golf course near MLB star's hometown
 - [https://www.foxnews.com/sports/mike-trout-teams-with-tiger-woods-new-jersey-golf-course-near-mlb-stars-hometown](https://www.foxnews.com/sports/mike-trout-teams-with-tiger-woods-new-jersey-golf-course-near-mlb-stars-hometown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:45:26+00:00

Mike Trout announced he is making his hopes and dreams come true. He said he partnered with Tiger Woods to begin building his golf course in southern New Jersey.

## Kansas City officers encouraged by department to meet illegal ticket quotas by targeting minorities
 - [https://www.foxnews.com/us/kansas-city-officers-encouraged-meet-illegal-ticket-quotas-targeting-minority-drivers](https://www.foxnews.com/us/kansas-city-officers-encouraged-meet-illegal-ticket-quotas-targeting-minority-drivers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:38:10+00:00

Kansas City officers were encouraged by the local police department to meet illegal ticket quotas by targeting minority drivers. A white traffic officer filed a discrimination lawsuit.

## Putin ally says Russia has 'weapons capable of destroying any adversary, including the United States'
 - [https://www.foxnews.com/world/vladimir-putin-ally-says-russia-has-weapons-capable-of-destroying-united-states](https://www.foxnews.com/world/vladimir-putin-ally-says-russia-has-weapons-capable-of-destroying-united-states)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:37:31+00:00

Russia Security Council Secretary Nikolai Patrushev said Monday that Moscow, if threatened, has &quot;modern unique weapons capable of destroying any adversary, including the United States.&quot;

## Twitter suspends 'KillerCops' account that put bounties on police officers after massive LAPD data release
 - [https://www.foxnews.com/us/twitter-suspends-killercops-account-that-put-bounties-police-officers-after-massive-lapd-data-release](https://www.foxnews.com/us/twitter-suspends-killercops-account-that-put-bounties-police-officers-after-massive-lapd-data-release)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:36:52+00:00

Twitter suspended a &quot;killer cop&quot; account that put bounties on the lives of Los Angeles police officers after photos and serial numbers were reportedly mistakenly released.

## Another powerful Pacific late-season storm approaching California
 - [https://www.foxnews.com/us/another-powerful-pacific-late-season-storm-approaching-california](https://www.foxnews.com/us/another-powerful-pacific-late-season-storm-approaching-california)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:36:21+00:00

Another powerful Pacific late-season storm is approaching California on Monday. The storm is expected to bring heavy mountain snow, rain, and wind ashore until Wednesday.

## Wisconsin Supreme Court candidate gave probation to domestic abuser who later killed two people, burned bodies
 - [https://www.foxnews.com/politics/wisconsin-supreme-court-candidate-gave-probation-domestic-abuser-who-later-killed-two-people-burned-bodies](https://www.foxnews.com/politics/wisconsin-supreme-court-candidate-gave-probation-domestic-abuser-who-later-killed-two-people-burned-bodies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:36:20+00:00

Judge Janet Protasiewicz, who is running for the Wisconsin Supreme Court, suspended a man&apos;s prison sentence before he went on to kill two people in 2019.

## Ram may trump Ford and GM with electric midsize pickup
 - [https://www.foxnews.com/auto/ram-trump-ford-gm-with-electric-midsize-pickup](https://www.foxnews.com/auto/ram-trump-ford-gm-with-electric-midsize-pickup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:34:17+00:00

Ram has shown its dealers a concept for a midsize electric pickup that could potentially follow the Ram 1500 REV full size truck into showrooms soon.

## Florida man who fled traffic stop shoots officer then himself
 - [https://www.foxnews.com/us/florida-man-fled-traffic-stop-shoots-officer-himself](https://www.foxnews.com/us/florida-man-fled-traffic-stop-shoots-officer-himself)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:33:55+00:00

A Florida man who fled from a traffic stop shot and critically injured an officer before turning the gun on himself. The man was armed with a semiautomatic rifle.

## Israel’s Netanyahu agrees to halt judicial reform for now as mass protests continue
 - [https://www.foxnews.com/world/israels-netanyahu-agrees-halt-judicial-reform-for-now-mass-protests-continue](https://www.foxnews.com/world/israels-netanyahu-agrees-halt-judicial-reform-for-now-mass-protests-continue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:33:11+00:00

Amid a general strike shutting Israel’s airport over opposition to judicial reform and expected violence, Israel’s embattled Prime Minister Benjamin Netanyahu agreed to take a time out for his legal overhaul.

## 1978 Mississippi cold case victim identified using DNA testing
 - [https://www.foxnews.com/us/1978-mississippi-cold-case-victim-identified-using-dna-testing](https://www.foxnews.com/us/1978-mississippi-cold-case-victim-identified-using-dna-testing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:32:06+00:00

A Mississippi cold case victim who was dumped at an illegal landfill has been identified using DNA testing on the remains. The body of the woman was found in 1978.

## Landslide in central Ecuador kills at least 16 people
 - [https://www.foxnews.com/world/landslide-central-ecuador-kills-least-16-people](https://www.foxnews.com/world/landslide-central-ecuador-kills-least-16-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:29:28+00:00

At least 16 people were killed and 16 others were injured in a landslide in central Ecuador. Seven people remained missing in Alausí after the landslide on Sunday.

## Shaq puts 'old dudes' on notice as he returns to the gym following hip replacement surgery
 - [https://www.foxnews.com/sports/shaq-puts-old-dudes-notice-returns-gym-following-hip-replacement-surgery](https://www.foxnews.com/sports/shaq-puts-old-dudes-notice-returns-gym-following-hip-replacement-surgery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:26:04+00:00

Shaquille O&apos;Neal was back at the gym more than a week after he posted a photo of himself from a hospital bed. He was undergoing hip replacement surgery.

## Whoopi Goldberg blows up over political correctness: 'We don't know everything you're not supposed to do!'
 - [https://www.foxnews.com/media/whoopi-goldberg-blows-political-correctness-we-dont-know-everything-youre-not-supposed-to-do](https://www.foxnews.com/media/whoopi-goldberg-blows-political-correctness-we-dont-know-everything-youre-not-supposed-to-do)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:25:08+00:00

Co-host Whoopi Goldberg blew up on Monday over political correctness and the removal of Mississippi news anchor Barbie Bassett during &quot;The View.&quot;

## Georgia judge orders Fulton County DA to respond to Trump’s motion seeking to quash grand jury report
 - [https://www.foxnews.com/politics/georgia-judge-orders-fulton-county-da-to-respond-to-trumps-motion-seeking-to-quash-grand-jury-report](https://www.foxnews.com/politics/georgia-judge-orders-fulton-county-da-to-respond-to-trumps-motion-seeking-to-quash-grand-jury-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:22:47+00:00

Former President Trump&apos;s Atlanta-based attorneys launched a broad attack against Fulton County District Attorney Fani Willis&apos; probe into alleged 2020 election interference.

## Philadelphia residents rush to stockpile bottled water: 'Water apocalypse 2023'
 - [https://www.foxnews.com/us/philadelphia-residents-rush-stockpile-bottled-water-water-apocalypse-2023](https://www.foxnews.com/us/philadelphia-residents-rush-stockpile-bottled-water-water-apocalypse-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:17:01+00:00

Philadelphia residents rushed to their local grocery stores to stock up on bottled water following an advisory issued Sunday due to a chemical spill in the Delaware River.

## Karine Jean-Pierre, liberal reporters’ hypocrisy in White House briefing room covers up this truth
 - [https://www.foxnews.com/opinion/karine-jean-pierre-liberal-reporters-hypocrisy-white-house-briefing-room-covers-truth](https://www.foxnews.com/opinion/karine-jean-pierre-liberal-reporters-hypocrisy-white-house-briefing-room-covers-truth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 13:00:07+00:00

The briefing room is usually a tank of hungry sharks for a Republican press secretary, and a classroom full of teacher&apos;s pets for a Democrat press secretary.

## Pardon sought for Black man who was executed in 1908 for a murder that is still being debated
 - [https://www.foxnews.com/us/pardon-sought-black-man-executed-1908-murder-debated](https://www.foxnews.com/us/pardon-sought-black-man-executed-1908-murder-debated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:59:33+00:00

People are seeking a pardon for Joe James, a Black man who was executed in 1908. Many argue that James did not receive a fair trial and was sentenced to death.

## Relatives of Colorado supermarket shooting victims sue gunmaker Sturm, Ruger & Co
 - [https://www.foxnews.com/us/relatives-colorado-supermarket-shooting-victims-sue-gun-maker-sturm-ruger-co](https://www.foxnews.com/us/relatives-colorado-supermarket-shooting-victims-sue-gun-maker-sturm-ruger-co)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:57:07+00:00

Gunmaker Sturm, Ruger &amp; Co. is being sued by relatives of Colorado supermarket shooting victims. The lawsuit claims the gunmaker marketed a gun in a &quot;reckless&quot; and &quot;immoral&quot; way.

## Scottish city demands to see MSNBC anchor Stephanie Ruhle's emails with Under Armour founder in legal feud
 - [https://www.foxnews.com/media/scottish-city-demands-msnbc-anchor-stephanie-ruhles-emails-with-under-armour-founder-legal-feud](https://www.foxnews.com/media/scottish-city-demands-msnbc-anchor-stephanie-ruhles-emails-with-under-armour-founder-legal-feud)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:55:59+00:00

A Scottish city council has demanded emails between MSNBC anchor Stephanie Ruhle and Under Armour founder Kevin Plank be released as part of an ongoing lawsuit.

## Kansas' Supreme Court set to review 2 unenforced abortion laws
 - [https://www.foxnews.com/politics/kansas-supreme-court-set-review-2-unenforced-abortion-laws](https://www.foxnews.com/politics/kansas-supreme-court-set-review-2-unenforced-abortion-laws)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:55:42+00:00

Kansas&apos;s Supreme Court will review two abortion lawsuits. One of the lawsuits is challenging a law banning a second-trimester abortion procedure. The other challenges a law from 2011.

## Daniel Suarez appears to purposely bump Alex Bowman on pit road after race
 - [https://www.foxnews.com/sports/daniel-suarez-appears-purposely-bump-alex-bowman-pit-road-race](https://www.foxnews.com/sports/daniel-suarez-appears-purposely-bump-alex-bowman-pit-road-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:54:27+00:00

Daniel Suarez appeared to be frustrated over what transpired before his 27th place finish in the EchoPark Automotive Grand Prix at the Circuit of Americas.

## Lebanon's caretaker prime minister reverses decision to delay the start of daylight saving
 - [https://www.foxnews.com/world/lebanons-caretaker-prime-minister-reverses-decision-delay-start-daylight-saving](https://www.foxnews.com/world/lebanons-caretaker-prime-minister-reverses-decision-delay-start-daylight-saving)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:50:49+00:00

Najib Mikati, the caretaker prime minister of Lebanon, reversed the decision to delay the start of daylight saving by a month. The decision was widely criticized by citizens.

## France's Louvre Museum closes to public as pension reform protestors block the entrance
 - [https://www.foxnews.com/world/frances-louvre-museum-closes-public-pension-reform-protestors-block-entrance](https://www.foxnews.com/world/frances-louvre-museum-closes-public-pension-reform-protestors-block-entrance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:47:51+00:00

The pension reform protests in France have led to a temporary closure of the Louvre Museum in Paris. The president of France recently raised the country&apos;s retirement age by two years.

## Anti-government protests break out in Kenya despite government's declaration that protests are illegal
 - [https://www.foxnews.com/world/anti-government-protests-break-kenya-despite-governments-declaration-protests-illegal](https://www.foxnews.com/world/anti-government-protests-break-kenya-despite-governments-declaration-protests-illegal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:46:01+00:00

Kenya&apos;s government declared that the anti-government protests that have been happening are illegal. Despite this, thousands of protestors marched in the nation&apos;s capitol on Monday.

## Mississippi news anchor pulled off air after quoting Snoop Dogg: ‘Fo shizzle’
 - [https://www.foxnews.com/media/mississippi-news-anchor-pulled-off-air-quoting-snoop-dogg-fo-shizzle](https://www.foxnews.com/media/mississippi-news-anchor-pulled-off-air-quoting-snoop-dogg-fo-shizzle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:45:11+00:00

Barbie Bassett, an anchor for WLBT in Mississippi, is reportedly no longer at the television station after quoting Snoop Dogg&apos;s phrase &quot;fo shizzle, my nizzle.&quot;

## Late Queen Elizabeth II asked Germany for 2 expensive horses when she visited the country in 1978
 - [https://www.foxnews.com/world/late-queen-elizabeth-ii-asked-germany-2-expensive-horses-visited-country-1978](https://www.foxnews.com/world/late-queen-elizabeth-ii-asked-germany-2-expensive-horses-visited-country-1978)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:44:00+00:00

A report claims that the late Queen Elizabeth II asked for two expensive horses when she visited Germany in 1978. Germany&apos;s then-president approved the gift.

## Senate rejection of Biden’s controversial nominees reveals ‘out of touch’ president, GOP says
 - [https://www.foxnews.com/politics/senate-rejection-bidens-controversial-nominees-reveals-out-touch-president-gop](https://www.foxnews.com/politics/senate-rejection-bidens-controversial-nominees-reveals-out-touch-president-gop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:43:41+00:00

Multiple GOP senators told Fox News Digital that moderates&apos; concerns about President Biden&apos;s regulatory nominees show his administration is &quot;out of touch.&quot;

## New abortion clinic opening in Maryland, just across from deeply-conservative West Virginia
 - [https://www.foxnews.com/us/new-abortion-clinic-opening-maryland-across-deeply-conservative-west-virginia](https://www.foxnews.com/us/new-abortion-clinic-opening-maryland-across-deeply-conservative-west-virginia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:40:16+00:00

The Women&apos;s Health Center of Maryland is set to open in Cumberland this year. The center will be just across from West Virginia, where abortion is banned.

## Former California Democratic mayor guilty of lewd conduct with child sentenced to 7 years in prison
 - [https://www.foxnews.com/politics/former-california-democratic-mayor-guilty-lewd-conduct-child-sentenced-7-years-prison](https://www.foxnews.com/politics/former-california-democratic-mayor-guilty-lewd-conduct-child-sentenced-7-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:40:00+00:00

Robert Jacob pleaded no contest to six felony offenses involving sexual misconduct with a minor in January and was found guilty. He began serving his prison sentence Thursday.

## Massachusetts teen dies in ‘complete freak accident’ at Pats Peak ski mountain in New Hampshire
 - [https://www.foxnews.com/us/massachusetts-teen-dies-complete-freak-accident-pats-peak-ski-mountain-new-hampshire](https://www.foxnews.com/us/massachusetts-teen-dies-complete-freak-accident-pats-peak-ski-mountain-new-hampshire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:36:28+00:00

Christopher DiPrima, 15, of Boston, died over the weekend after becoming involved in a ski accident at the Pats Peak Ski Area in New Hampshire, reports say.

## Biden vows to tank GOP effort to boost energy production
 - [https://www.foxnews.com/politics/biden-vows-tank-gop-effort-boost-energy-production](https://www.foxnews.com/politics/biden-vows-tank-gop-effort-boost-energy-production)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:26:08+00:00

President Biden vowed Monday to veto the Lower Energy Costs Act, Republicans&apos; effort to boost energy production and reduce barriers for companies to permit projects.

## NFL Network host pushes for Super Bowl schedule change: 'I want it on Saturday'
 - [https://www.foxnews.com/sports/nfl-network-host-pushes-super-bowl-schedule-change-i-want-it-saturday](https://www.foxnews.com/sports/nfl-network-host-pushes-super-bowl-schedule-change-i-want-it-saturday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:12:19+00:00

NFL Network host Kyle Brandt said Thursday that he pitched moving the Super Bowl to Saturday to Commissioner Roger Goodell.

## Former soccer player suffered 'suspected small heart attack' during half-marathon, completes race anyway
 - [https://www.foxnews.com/sports/former-soccer-player-suffered-suspected-small-heart-attack-during-half-marathon-completes-race-anyway](https://www.foxnews.com/sports/former-soccer-player-suffered-suspected-small-heart-attack-during-half-marathon-completes-race-anyway)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:08:38+00:00

Former Premier League soccer player Carlton Palmer revealed he suffered a &quot;suspected small heart attack&quot; during a half-marathon in the United Kingdom on Sunday.

## Pence set to return to Iowa as former VP appears to move closer to 2024 campaign
 - [https://www.foxnews.com/politics/pence-set-return-iowa-former-vp-appears-move-closer-2024-campaign](https://www.foxnews.com/politics/pence-set-return-iowa-former-vp-appears-move-closer-2024-campaign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:08:00+00:00

Former Vice President Mike Pence returns on Wednesday to Iowa, the state that leads off the Republican Party’s presidential nominating calendar, as he moves closer to a 2024 run

## Multiple people injured in shooting at Nashville's Covenant School; shooter dead
 - [https://www.foxnews.com/us/multiple-people-injured-shooting-nashvilles-covenant-school-shooter-dead](https://www.foxnews.com/us/multiple-people-injured-shooting-nashvilles-covenant-school-shooter-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:04:31+00:00

First responders are on the scene of an incident at a Nashville area elementary school in Tennessee on Monday. Authorities have not released any casualty numbers.

## Nashville school shooting: 6 killed including 3 students, shooter dead
 - [https://www.foxnews.com/us/nashville-school-shooting-6-killed-including-3-students-shooter-dead](https://www.foxnews.com/us/nashville-school-shooting-6-killed-including-3-students-shooter-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:04:31+00:00

Three students and three adults were fatally shot Monday at a private Christian school in Nashville, Tennessee, authorities said.

## Nashville school shooting: Three students killed, shooter dead
 - [https://www.foxnews.com/us/nashville-school-shooting-three-students-killed-shooter-dead](https://www.foxnews.com/us/nashville-school-shooting-three-students-killed-shooter-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:04:31+00:00

First responders are on the scene of an incident at Nashville&apos;s Covenant School in Tennessee on Monday. Authorities say three students and the shooter were killed.

## Fossil fuel, green energy groups team up in rare joint effort to push permitting reform
 - [https://www.foxnews.com/politics/fossil-fuel-green-energy-groups-team-up-rare-joint-effort-push-permitting-reform](https://www.foxnews.com/politics/fossil-fuel-green-energy-groups-team-up-rare-joint-effort-push-permitting-reform)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:02:29+00:00

A broad coalition of fossil fuel, clean energy and labor unions penned a letter to Congress on Monday morning, urging it to take action on permitting reform to ensure energy infrastructure development.

## Military family devastated after Marine combat veteran killed while driving Uber near Los Angeles
 - [https://www.foxnews.com/media/military-family-devastated-marine-combat-veteran-killed-driving-uber-los-angeles](https://www.foxnews.com/media/military-family-devastated-marine-combat-veteran-killed-driving-uber-los-angeles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 12:00:38+00:00

Angel Orozco detailed the &apos;heartbreaking&apos; loss of his brother, Aaron, who was a California Marine veteran shot and killed while driving for Uber last week

## Best Main Street in America 2023 announced: Is yours at the top of the list?
 - [https://www.foxnews.com/lifestyle/best-main-street-america-2023-named-yours-top-list](https://www.foxnews.com/lifestyle/best-main-street-america-2023-named-yours-top-list)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:59:55+00:00

The 2023 Great American Main Street Award has been given to three main street districts in cities across the country — see which towns made the winning list.

## CBS anchor laughs at Biden spox's excuse for his appearance on TikTok: He was 'filmed on government property!'
 - [https://www.foxnews.com/media/cbs-anchor-laughs-biden-spoxs-excuse-appearance-tiktok-filmed-government-property](https://www.foxnews.com/media/cbs-anchor-laughs-biden-spoxs-excuse-appearance-tiktok-filmed-government-property)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:56:40+00:00

John Kirby was pressed on President Biden&apos;s &quot;hypocritical&quot; appearances alongside celebrities on TikTok as Congress considers banning the Chinese-owned app in the U.S.

## Agatha Christie novels become latest classics censored to remove 'offensive' language
 - [https://www.foxnews.com/media/agatha-christie-novels-classics-censored-remove-offensive-language](https://www.foxnews.com/media/agatha-christie-novels-classics-censored-remove-offensive-language)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:49:29+00:00

British mystery author Agatha Christie&apos;s books are the latest to come under scrutiny by censors, removing references to racially insensitive descriptions or topics.

## Justine Bateman, 57, slams perception that she has an ‘old’ face: ‘My face represents who I am’
 - [https://www.foxnews.com/entertainment/family-ties-actress-justine-bateman-slams-perception-has-old-face-my-face-represents-who-i-am](https://www.foxnews.com/entertainment/family-ties-actress-justine-bateman-slams-perception-has-old-face-my-face-represents-who-i-am)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:44:26+00:00

Justine Bateman is not perturbed by aging and was perplexed to learn several years ago that her face was perceived as one that was aging.

## Virginia school district considers banning students from wearing pajamas, clothes that 'expose underwear'
 - [https://www.foxnews.com/us/virginia-school-district-considers-banning-students-wearing-pajamas-clothes-that-expose-underwear](https://www.foxnews.com/us/virginia-school-district-considers-banning-students-wearing-pajamas-clothes-that-expose-underwear)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:43:59+00:00

Fairfax County Public Schools is considering a change to its dress code that would ban pajamas and sleepwear in classrooms, as well as prohibit any clothes that &quot;expose underwear.&quot;

## Six injured after Minnesota parking lot shooting
 - [https://www.foxnews.com/us/six-injured-minnesota-parking-lot-shooting](https://www.foxnews.com/us/six-injured-minnesota-parking-lot-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:33:42+00:00

Police in Brooklyn Center, Minnesota, are investigating a shooting that left six people injured over the weekend. Police believe incident started as prearranged fight.

## Lamar Jackson reveals trade request as Ravens saga takes another twist
 - [https://www.foxnews.com/sports/lamar-jackson-reveals-trade-request-ravens-saga-takes-another-twist](https://www.foxnews.com/sports/lamar-jackson-reveals-trade-request-ravens-saga-takes-another-twist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:31:15+00:00

Lamar Jackson on Monday revealed in a series of tweets that he requested a trade from the Baltimore Ravens on March 2. The Ravens used the non-exclusive franchise tag on him.

## Florida spring break bar owner dead after alleged domestic battery incident
 - [https://www.foxnews.com/us/florida-spring-break-bar-owner-dead-alleged-domestic-battery-incident](https://www.foxnews.com/us/florida-spring-break-bar-owner-dead-alleged-domestic-battery-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:31:01+00:00

Tracey Penrod, co-owner of the Elbo Room in Fort Lauderdale, Florida, died 10 days after being in a coma following a March 14 domestic battery incident at her home.

## Ex-Tennessee cop likely facing lifetime ban from state law enforcement after sex scandal
 - [https://www.foxnews.com/us/ex-tennessee-cop-likely-facing-lifetime-ban-state-law-enforcement-sex-scandal](https://www.foxnews.com/us/ex-tennessee-cop-likely-facing-lifetime-ban-state-law-enforcement-sex-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:27:16+00:00

Former La Vergne Police Sgt. Henry &quot;Ty&quot; McGowan might never be able to work in law enforcement in the Volunteer State following the sex scandal that rocked the Tennessee department.

## College baseball coach takes soda bottle with him as he gets ejected from game
 - [https://www.foxnews.com/sports/college-baseball-coach-takes-soda-bottle-him-gets-ejected-game](https://www.foxnews.com/sports/college-baseball-coach-takes-soda-bottle-him-gets-ejected-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:13:50+00:00

Austin Peay head coach Ronald Fanning was tossed from a game against Liberty on Saturday but made sure to get all of his belongings first, including a bottle of soda.

## Trump holds double digit lead over DeSantis, far ahead of rest of the field, in early 2024 polls
 - [https://www.foxnews.com/politics/trump-holds-double-digit-lead-over-desantis-far-ahead-rest-field-early-2024-polls](https://www.foxnews.com/politics/trump-holds-double-digit-lead-over-desantis-far-ahead-rest-field-early-2024-polls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:08:57+00:00

Former President Trump remains the front-runner in the 2024 Republican presidential nomination, according to the latest national polls, topping Florida Gov. Ron DeSantis.

## 'Pregnancy nose’ has expectant moms going viral on TikTok as medical experts explain the baffling condition
 - [https://www.foxnews.com/lifestyle/pregnancy-nose-expectant-moms-viral-tiktok-medical-experts-explain-baffling-condition](https://www.foxnews.com/lifestyle/pregnancy-nose-expectant-moms-viral-tiktok-medical-experts-explain-baffling-condition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 11:00:55+00:00

While &apos;pregnancy nose&apos; trends on TikTok, health experts Dr. Lauren Demosthenes of Babyscripts and Mommy Labor Nurse founder Liesel Teen explain what causes the symptom in pregnant women.

## Fight breaks out at Texas Capitol over trans activist's viral speech comparing lawmakers to Hitler
 - [https://www.foxnews.com/media/fight-breaks-out-texas-courthouse-trans-activists-viral-speech-comparing-lawmakers-hitler](https://www.foxnews.com/media/fight-breaks-out-texas-courthouse-trans-activists-viral-speech-comparing-lawmakers-hitler)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:56:21+00:00

A transgender activist is going viral on TikTok after a fiery speech delivered in front of Texas state lawmakers turned into a physical standoff Thursday.

## Gwyneth Paltrow's accuser in ski collision expected to take the stand after star's testimony
 - [https://www.foxnews.com/entertainment/gwyneth-paltrows-accuser-ski-collision-expected-take-stand-after-stars-testimony](https://www.foxnews.com/entertainment/gwyneth-paltrows-accuser-ski-collision-expected-take-stand-after-stars-testimony)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:55:21+00:00

A man who claims he was severely injured by Gwyneth Paltrow in a 2016 ski collision is set to take the stand Monday. The actress is being sued for $300,000.

## Russia's latest nuclear threat slammed by NATO, ' closely monitoring' weapons move to Belarus
 - [https://www.foxnews.com/world/russias-latest-nuclear-threat-slammed-by-nato-closely-monitoring-weapons-move-belarus](https://www.foxnews.com/world/russias-latest-nuclear-threat-slammed-by-nato-closely-monitoring-weapons-move-belarus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:55:04+00:00

NATO clapped back at Russian President Vladimir Putin after he announced his decision to place tactical nuclear weaponry in Belarus, calling it &apos;dangerous and irresponsible.&apos;

## Tlaib bodied by Twitter over 'lies' that teenage brawl was Israeli soldiers attacking Palestinians
 - [https://www.foxnews.com/politics/tlaib-bodied-over-lies-teenage-brawl-israeli-soldiers-attacking-palestinians](https://www.foxnews.com/politics/tlaib-bodied-over-lies-teenage-brawl-israeli-soldiers-attacking-palestinians)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:53:24+00:00

Far-left Michigan Democrat Rep. Rashida Tlaib was fact-checked by Twitter when she claimed a brawl between Palestinian teenagers was the Israeli government targeting Palestinians.

## Where's all the Ukraine money going? This person can help find the truth
 - [https://www.foxnews.com/opinion/wheres-ukraine-money-person-find-truth](https://www.foxnews.com/opinion/wheres-ukraine-money-person-find-truth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:48:03+00:00

This week, the Senate will vote on my amendment to set up an inspector general to track every single taxpayer dollar going to Ukraine. Who could oppose that?

## 70-car train derails in North Dakota, spills hazardous materials: reports
 - [https://www.foxnews.com/us/70-car-train-derails-north-dakota-spills-hazardous-materials-reports](https://www.foxnews.com/us/70-car-train-derails-north-dakota-spills-hazardous-materials-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:41:46+00:00

Officials in Richland County, North Dakota, said that 31 cars attached to a 70-car train derailed near Wyndmere early Monday, with some cars leaking petroleum.

## Here's why Zane Smith's NASCAR truck caught fire during his victory burnout
 - [https://www.foxnews.com/auto/why-zane-smiths-nascar-truck-caught-fire-victory-burnout](https://www.foxnews.com/auto/why-zane-smiths-nascar-truck-caught-fire-victory-burnout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:33:39+00:00

Zane Smiths NASCAR truck caught fire after a victory burnout, which was likely caused by the tire rubber getting caught by the rain flaps the vehicle was equipped with.

## Minnesota attorney warns about 'insidious' bill for 'trans refuge,' says parental rights will be stripped
 - [https://www.foxnews.com/media/minnesota-attorney-warns-insidious-bill-trans-refuge-parental-rights-stripped](https://www.foxnews.com/media/minnesota-attorney-warns-insidious-bill-trans-refuge-parental-rights-stripped)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:28:02+00:00

Minnesota attorney Robert Roby warned that the state&apos;s &apos;trans refuge&apos; bill could allow juvenile courts to strip parents of custody for denying gender-affirming care to kids.

## Biden badgers Bibi: Netanyahu says president warned bill to reform Israel Supreme Court threatens democracy
 - [https://www.foxnews.com/politics/biden-badgers-bibi-netanyahu-says-president-warned-bill-reform-israel-supreme-court-threatens-democracy](https://www.foxnews.com/politics/biden-badgers-bibi-netanyahu-says-president-warned-bill-reform-israel-supreme-court-threatens-democracy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:19:50+00:00

Israel Prime Minister Benjamin Netanyahu said that President Biden warned him not to mess with democracy in his country after his decision to reform the judiciary.

## George Washington University narrows down choices to replace Colonials moniker
 - [https://www.foxnews.com/sports/george-washington-university-narrows-down-choices-replace-colonials-moniker](https://www.foxnews.com/sports/george-washington-university-narrows-down-choices-replace-colonials-moniker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:12:33+00:00

George Washington University narrowed its list of nickname choices to four last week and the student body, faculty and alumni will get to weigh in on the options.

## Pakistani court rules in defense of former Prime Minister Imran Kahn
 - [https://www.foxnews.com/world/pakistani-court-rules-defense-former-prime-minister-imran-kahn](https://www.foxnews.com/world/pakistani-court-rules-defense-former-prime-minister-imran-kahn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:10:43+00:00

The Islamabad High Court in Pakistan ruled in favor of former Prime Minister Imran Kahn on Monday. The former leader has 100 legal cases filed against him.

## Cash bail laws are on Wisconsin's April ballot - Here are the details
 - [https://www.foxnews.com/politics/cash-bail-laws-wisconsins-april-ballot-details](https://www.foxnews.com/politics/cash-bail-laws-wisconsins-april-ballot-details)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:09:35+00:00

Wisconsin&apos;s Supreme Court election will deal with many issues, including abortion rights and redistricting. Cash bail laws will also be at stake on April&apos;s ballot.

## 2 suspects arrested in connection with death of man whose body was found in burning Phoenix trash receptacle
 - [https://www.foxnews.com/us/2-suspects-arrested-connection-death-man-whose-body-found-burning-phoenix-trash-receptacle](https://www.foxnews.com/us/2-suspects-arrested-connection-death-man-whose-body-found-burning-phoenix-trash-receptacle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:07:27+00:00

Phoenix police arrested two suspects in connection with the death of a man whose body was found burning inside a trash receptacle. The case is being investigated as a homicide.

## Arizona authorities investigating inmate's death as a homicide
 - [https://www.foxnews.com/us/arizona-authorities-investigating-inmates-death-homicide](https://www.foxnews.com/us/arizona-authorities-investigating-inmates-death-homicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:05:38+00:00

Arizona authorities are investigating the death of an inmate at a state prison as a homicide. The staff attempted life-saving measures, but paramedics declared the inmate was dead.

## Recovery efforts continue in tornado ravaged Mississippi where at least 25 were killed
 - [https://www.foxnews.com/us/recovery-efforts-continue-tornado-ravaged-mississippi-least-25-killed](https://www.foxnews.com/us/recovery-efforts-continue-tornado-ravaged-mississippi-least-25-killed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:03:04+00:00

Parts of Mississippi were destroyed by a tornado that ripped through over half a dozen towns. The tornado killed at least 25 people. An Alabama man also died during the storm.

## New Mexican authorities continue to search for suspect in fatal shooting
 - [https://www.foxnews.com/us/new-mexico-authorities-continue-search-suspect-fatal-shooting](https://www.foxnews.com/us/new-mexico-authorities-continue-search-suspect-fatal-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:01:50+00:00

A shooter at a Farmington mall in New Mexico killed one person and injured another. What led to the shooting remains under investigation.

## Be well: Take a walk outside to boost your mental health
 - [https://www.foxnews.com/health/be-well-take-walk-outside-boost-your-mental-health](https://www.foxnews.com/health/be-well-take-walk-outside-boost-your-mental-health)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:00:34+00:00

Spending even a short time outdoors can bring numerous mental health benefits, including greater concentration, improved mood and reduced stress, a doctor told Fox News Digital.

## Brave Books’ founder touts ‘amazing’ support for Christian/conservative alternative to ‘Drag Queen Story Hour’
 - [https://www.foxnews.com/media/brave-books-founder-touts-amazing-support-christian-conservative-alternative-drag-queen-story-hour](https://www.foxnews.com/media/brave-books-founder-touts-amazing-support-christian-conservative-alternative-drag-queen-story-hour)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:00:11+00:00

&quot;Brave Books&quot; founder and CEO Trent Talbot claimed that there is a &quot;hunger&quot; for wholesome children&apos;s story hours in America to counteract Drag Queen Story Hours.

## Montana sheriff's deputy fatally shoots armed robbery suspect after pursuit, standoff
 - [https://www.foxnews.com/us/montana-sheriffs-deputy-fatally-shoots-armed-robbery-suspect-after-pursuit-standoff](https://www.foxnews.com/us/montana-sheriffs-deputy-fatally-shoots-armed-robbery-suspect-after-pursuit-standoff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:00:10+00:00

A Montana robbery suspect was fatally shot by a sheriff&apos;s deputy following a pursuit and standoff. The woman hit two vehicles while fleeing from police.

## These two major pharmacies are putting women’s lives at risk
 - [https://www.foxnews.com/opinion/these-two-major-pharmacies-putting-womens-lives-risk](https://www.foxnews.com/opinion/these-two-major-pharmacies-putting-womens-lives-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 10:00:02+00:00

Two major pharmacies are putting women’s lives at risk with abortion pill. Walgreens, CVS support controversial &apos;medicine&apos; and destroy their reputations.

## Middle school teacher fired after anti-Christian rant outside abortion clinic: 'F---ing idiots'
 - [https://www.foxnews.com/media/middle-school-teacher-fired-anti-christian-rant-abortion-clinic-f-ing-idiots](https://www.foxnews.com/media/middle-school-teacher-fired-anti-christian-rant-abortion-clinic-f-ing-idiots)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 09:44:10+00:00

A middle school French teacher was fired after a video of him was posted on social media ranting against Christians with vulgar language outside an abortion clinic.

## China influenced Utah legislation during long-running campaign: report
 - [https://www.foxnews.com/politics/china-influenced-utah-legislation-long-running-campaign-report](https://www.foxnews.com/politics/china-influenced-utah-legislation-long-running-campaign-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 09:43:16+00:00

The Associated Press is reporting that China has been running a successful influence campaign targeting lawmakers in the state of Utah.

## Six in 10 Americans don't want Trump to be president again: 2024 poll
 - [https://www.foxnews.com/politics/six-10-americans-dont-want-trump-president-again-2024-poll](https://www.foxnews.com/politics/six-10-americans-dont-want-trump-president-again-2024-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 09:35:02+00:00

A new NPR/Marist poll found that most Americans do not want former President Donald Trump to be elected in 2024, amid ongoing investigations into hush money payment allegations.

## Hundreds of banking apps at risk from the new Nexus Android trojan
 - [https://www.foxnews.com/tech/hundreds-banking-apps-risk-new-nexus-android-trojan](https://www.foxnews.com/tech/hundreds-banking-apps-risk-new-nexus-android-trojan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 09:28:03+00:00

A new online banking threat has the ability to evade security measures and steal your information. Kurt &quot;Cyberguy&quot; Knutsson tells you how you and your information can stay safe.

## Ex-MSNBC analyst Malcom Nance contributed to 'chaos' in Ukraine volunteer effort: Report
 - [https://www.foxnews.com/media/ex-msnbc-analyst-malcom-nance-contributed-chaos-ukraine-volunteer-effort-report](https://www.foxnews.com/media/ex-msnbc-analyst-malcom-nance-contributed-chaos-ukraine-volunteer-effort-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 09:27:56+00:00

Former MSNBC analyst Malcolm Nance became involved in scandal and controversy after enlisting for the war in Ukraine, New York Times reporters claimed.

## Always do this first before downloading a software update to your phone
 - [https://www.foxnews.com/tech/always-first-downloading-software-update-phone](https://www.foxnews.com/tech/always-first-downloading-software-update-phone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 09:27:01+00:00

Should you use cellular data or Wi-Fi? Kurt &quot;CyberGuy&quot; Knutsson explains which is best when you are going to update the latest software for your device.

## Democrat Schumer warns NYC 'skin-rotting zombie drug' trafficked from Mexico could make fentanyl 'seem tame'
 - [https://www.foxnews.com/politics/democrat-schumer-warns-nyc-skin-rotting-zombie-drug-trafficked-mexico-make-fentanyl-seem-tame](https://www.foxnews.com/politics/democrat-schumer-warns-nyc-skin-rotting-zombie-drug-trafficked-mexico-make-fentanyl-seem-tame)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 09:21:23+00:00

Sen. Chuck Schumer, D-N.Y., called on the DEA to send &quot;diversion control teams&quot; as the &quot;deadly, skin-rooting zombie drug&quot; xylazine mixed with fentanyl makes it way to New York City.

## Mississippi woman accused of murdering husband on Facebook Live
 - [https://www.foxnews.com/us/mississippi-woman-accused-murdering-husband-facebook-live](https://www.foxnews.com/us/mississippi-woman-accused-murdering-husband-facebook-live)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 09:13:58+00:00

The murder of a Mississippi man was reportedly caught on Facebook Live over the weekend, sheriff&apos;s deputies say. The man and his wife apparently had a history of domestic violence.

## Car goes airborne on Los Angeles freeway after tire pops off pickup truck: video
 - [https://www.foxnews.com/us/car-goes-airborne-los-angeles-freeway-tire-pops-off-pickup-truck-video](https://www.foxnews.com/us/car-goes-airborne-los-angeles-freeway-tire-pops-off-pickup-truck-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 09:08:55+00:00

Dashcam video captured the heart-pounding moment a car was launched into the air on a Los Angeles-area freeway last week after the vehicle struck a loose tire.

## Severe weather to impact Southeast following deadly tornadoes
 - [https://www.foxnews.com/us/severe-weather-impact-southeast-following-deadly-tornadoes](https://www.foxnews.com/us/severe-weather-impact-southeast-following-deadly-tornadoes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:55:47+00:00

The southeastern U.S. is facing a severe weather risk Monday following deadly tornadoes over the weekend, while another powerful storm system is coming to California.

## Canada pledges to increase Great Lakes funding following Justin Trudeau's meeting with Biden
 - [https://www.foxnews.com/world/canada-pledges-increase-great-lake-funding-following-justin-trudeaus-meeting-biden](https://www.foxnews.com/world/canada-pledges-increase-great-lake-funding-following-justin-trudeaus-meeting-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:55:43+00:00

President Joe Biden met with Canada&apos;s prime Minister Justin Trudeau last week. Trudeau pledged to increase funding to improve the water quality in the Great Lakes.

## Brooke Shields says ex Andre Agassi 'smashed all his trophies' after her 'Friends' appearance
 - [https://www.foxnews.com/entertainment/brooke-shields-ex-andre-agassi-smashed-all-his-trophies-after-friends-appearance](https://www.foxnews.com/entertainment/brooke-shields-ex-andre-agassi-smashed-all-his-trophies-after-friends-appearance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:54:03+00:00

Brooke Shields opened up about her time guest-starring on &quot;Friends&quot; in 1996, and the extreme reaction her boyfriend at the time, Andre Agassi, had because of the taping.

## Importance of traditional American values has plummeted across US, poll shows
 - [https://www.foxnews.com/politics/importance-traditional-american-values-plummeted-us-poll-shows](https://www.foxnews.com/politics/importance-traditional-american-values-plummeted-us-poll-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:52:07+00:00

Many Americans no longer hold the the values that traditionally defined American culture just two decades ago, according to new polling from the Wall St. Journal.

## Real-life Second Amendment example gains praise, Paltrow ski crash trial set to resume and more top headlines
 - [https://www.foxnews.com/us/homeowner-turns-tables-intruder-second-amendment-paltrow-ski-crash-trial-resume-fox-news-first-newsletter-march-27-2023](https://www.foxnews.com/us/homeowner-turns-tables-intruder-second-amendment-paltrow-ski-crash-trial-resume-fox-news-first-newsletter-march-27-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:48:12+00:00

Real-life Second Amendment example gains praise, Paltrow ski crash trial set to resume and more top headlines.

## California 7-year-old boy's body found in ocean days after his mother was found dead in the same area
 - [https://www.foxnews.com/us/california-7-year-old-boys-body-ocean-days-mother-found-dead-same-area](https://www.foxnews.com/us/california-7-year-old-boys-body-ocean-days-mother-found-dead-same-area)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:46:32+00:00

A 7-year-old boy and his mother went missing last week. The bodies of both the child and his mother have been found since the two went missing.

## LSU's Olivia Dunne offers three pieces of advice to student-athletes
 - [https://www.foxnews.com/sports/lsus-olivia-dunne-offers-three-pieces-advice-student-athletes](https://www.foxnews.com/sports/lsus-olivia-dunne-offers-three-pieces-advice-student-athletes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:45:22+00:00

LSU gymnast Olivia Dunne offered advice to student-athletes about maintaining balance in their lives as she gets ready for the NCAA gymnastics regionals.

## Arkansas police say 2 separate shootings in Little Rock left 2 dead, 7 injured
 - [https://www.foxnews.com/us/arkansas-police-say-2-separate-shootings-little-rock-left-2-dead-7-injured](https://www.foxnews.com/us/arkansas-police-say-2-separate-shootings-little-rock-left-2-dead-7-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:43:44+00:00

Seven people were shot in two separate shootings in Little Rock. Two people died in the shootings. Arkansas police will continue to investigate the shootings.

## Prince Harry makes court appearance in case against British tabloids
 - [https://www.foxnews.com/entertainment/prince-harry-makes-court-appearance-case-british-tabloids](https://www.foxnews.com/entertainment/prince-harry-makes-court-appearance-case-british-tabloids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:42:54+00:00

Prince Harry appeared in court on Monday morning for a hearing in the case against Associated Newspapers, a group of British tabloids accused of invasion of privacy.

## Manhattan grand jury weighing Trump charges expected to reconvene: report
 - [https://www.foxnews.com/politics/manhattan-grand-jury-weighing-trump-charges-expected-to-reconvene-report](https://www.foxnews.com/politics/manhattan-grand-jury-weighing-trump-charges-expected-to-reconvene-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:39:56+00:00

The grand jury in Manhattan is expected to reconvene on Monday to consider charges against former President Trump related to alleged hush payments.

## LAPD detective sounds alarm on 'killer cop' website: 'This is uncharted territory'
 - [https://www.foxnews.com/media/lapd-detective-sounds-alarm-killer-cop-website-uncharted-territory](https://www.foxnews.com/media/lapd-detective-sounds-alarm-killer-cop-website-uncharted-territory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:32:18+00:00

LAPD detective Jamie McBride warned the release of thousands of officers&apos; information is &apos;unchartered territory&apos; after the union sued the owner of copkiller.com

## LeBron James cryptic on foot injury, says he went to the 'LeBron James of feet' to get cleared
 - [https://www.foxnews.com/sports/lebron-james-cryptic-foot-injury-says-went-lebron-james-of-feet-get-cleared](https://www.foxnews.com/sports/lebron-james-cryptic-foot-injury-says-went-lebron-james-of-feet-get-cleared)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:19:24+00:00

LeBron James checked in with three doctors in order to get cleared to play for the rest of the 2022-23 season as the Los Angeles Lakers make a playoff push.

## Florida sets shining example on school choice. Here's how
 - [https://www.foxnews.com/opinion/florida-sets-shining-example-school-choice-heres-how](https://www.foxnews.com/opinion/florida-sets-shining-example-school-choice-heres-how)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 08:00:50+00:00

Gov. Ron DeSantis and Florida lawmakers have expanded education savings accounts, cementing the state’s status as a national leader in education freedom and choice.

## Charles Barkley gets candid on his life as he becomes a grandpa: 'I'm on the back nine'
 - [https://www.foxnews.com/sports/charles-barkley-gets-candid-his-life-he-becomes-grandpa-back-nine](https://www.foxnews.com/sports/charles-barkley-gets-candid-his-life-he-becomes-grandpa-back-nine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:45:02+00:00

Charles Barkley put the rest of his life into focus as he spoke glowingly about becoming a grandparent at age 60 in an interview on &quot;60 Minutes&quot; Sunday.

## Elizabeth Warren, 73, announces Senate re-election campaign
 - [https://www.foxnews.com/politics/elizabeth-warren-73-announces-senate-re-election-campaign](https://www.foxnews.com/politics/elizabeth-warren-73-announces-senate-re-election-campaign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:28:45+00:00

Sen. Elizabeth Warren, D-Mass., will run for re-election in 2024, the 73-year-old politician announced Monday. Warren was first elected to her office in 2012.

## Bucs' Todd Bowles optimistic about 2023 season despite missing 'aura' of Tom Brady
 - [https://www.foxnews.com/sports/bucs-todd-bowles-optimistic-2023-season-despite-missing-aura-tom-brady](https://www.foxnews.com/sports/bucs-todd-bowles-optimistic-2023-season-despite-missing-aura-tom-brady)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:23:31+00:00

Tampa Bay Buccaneers head coach Todd Bowles expressed optimism about the 2023 season but maintained the team is going to have to come together to have success.

## Mom of Navy sailor who vanished after leaving Illinois bar speaks out, says Seamus Gray search 'gut-wrenching'
 - [https://www.foxnews.com/us/mom-navy-sailor-vanished-leaving-illinois-bar-speaks-seamus-gray-search-gut-wrenching](https://www.foxnews.com/us/mom-navy-sailor-vanished-leaving-illinois-bar-speaks-seamus-gray-search-gut-wrenching)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:19:38+00:00

Kerry Gray, the mother of missing Navy sailor Seamus Gray, who last was seen leaving a bar in Waukegan, Illinois on March 18, is opening up about the search for her son.

## New Jersey sisters discover letters to their father from his best friend killed during World War II
 - [https://www.foxnews.com/lifestyle/new-jersey-sisters-discover-letters-father-his-best-friend-killed-during-world-war-ii](https://www.foxnews.com/lifestyle/new-jersey-sisters-discover-letters-father-his-best-friend-killed-during-world-war-ii)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:14:18+00:00

New Jersey sisters discover letters written to their Navy veteran father from his best friend during World War II while cleaning out their parents&apos; home following their deaths.

## F1 champion fined nearly $1 million in 'moral damages' for racist and homophobic remarks about Lewis Hamilton
 - [https://www.foxnews.com/sports/f1-champion-fined-nearly-1-million-moral-damages-racist-homophobic-remarks-lewis-hamilton](https://www.foxnews.com/sports/f1-champion-fined-nearly-1-million-moral-damages-racist-homophobic-remarks-lewis-hamilton)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:04:13+00:00

Formula One champion Nelson Piquet was fined nearly $1 million in &quot;moral damages&quot; for racist and homophobic comments directed toward Lewis Hamilton.

## State motto quiz! How much do you truly know about the United States?
 - [https://www.foxnews.com/lifestyle/state-motto-quiz-how-well-do-you-really-know-these-us-states-mottos](https://www.foxnews.com/lifestyle/state-motto-quiz-how-well-do-you-really-know-these-us-states-mottos)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:00:28+00:00

State motto quiz! How well do you know the phrase behind your beloved home state? See if you can guess the answers to questions about these great United States.

## How ambush killing of Florida Microsoft executive tore his family apart
 - [https://www.foxnews.com/us/how-ambush-killing-florida-microsoft-executive-tore-his-family-apart](https://www.foxnews.com/us/how-ambush-killing-florida-microsoft-executive-tore-his-family-apart)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:00:26+00:00

Father of four Jared Bridegan was fatally shot more than a year ago and now two men have been arrested for the shocking slaying that has deeply shaken the Jacksonville Beach community.

## Julian Assange supporters gather in London for exhibition of largest physical showing of classified docs
 - [https://www.foxnews.com/politics/julian-assange-supporters-gather-london-exhibition-largest-physical-showing-classified-docs](https://www.foxnews.com/politics/julian-assange-supporters-gather-london-exhibition-largest-physical-showing-classified-docs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:00:22+00:00

Supporters of Wikileaks founder Julian Assange viewed an art exhibition and the physical publication of top-secret government documents in London.

## Former Obama cabinet member endorses pro-police candidate: 'Best hope for a safer Chicago'
 - [https://www.foxnews.com/media/former-obama-cabinet-member-endorses-pro-police-candidate-best-hope-safer-chicago](https://www.foxnews.com/media/former-obama-cabinet-member-endorses-pro-police-candidate-best-hope-safer-chicago)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 07:00:17+00:00

Former U.S. Secretary of Education Arne Duncan endorsed Paul Vallas in the upcoming Chicago mayoral race through an opinion piece for the Chicago Tribune.

## San Francisco hits family with $1,402 fee after they built free library for neighbors: report
 - [https://www.foxnews.com/media/san-francisco-hits-family-1402-fee-built-free-library-neighbors-report](https://www.foxnews.com/media/san-francisco-hits-family-1402-fee-built-free-library-neighbors-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 06:56:01+00:00

A retired couple in San Francisco was threatened with a fine from local government officials after they built a free library and bench for neighbors.

## 'Coal miner town situation': Elon Musk's reported plan to build 'utopia' worker town fires up locals
 - [https://www.foxnews.com/us/coal-miner-town-situation-elon-musks-reported-plan-build-utopia-worker-town-fires-locals](https://www.foxnews.com/us/coal-miner-town-situation-elon-musks-reported-plan-build-utopia-worker-town-fires-locals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 06:30:35+00:00

Bastrop County residents weighed in on a report that billionaire businessman Elon Musk plans to build a live-work &apos;utopia&apos; for his staff in Central Texas.

## NHL star Ryan Reaves has wild reaction to smelling salts on bench
 - [https://www.foxnews.com/sports/nhl-star-ryan-reaves-wild-reaction-smelling-salts-bench](https://www.foxnews.com/sports/nhl-star-ryan-reaves-wild-reaction-smelling-salts-bench)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 06:23:26+00:00

Ryan Reaves went viral on Saturday night over his smelling salts mishap. The Minnesota Wild star took too big of a sniff against the Chicago Blackhawks.

## Protests in France against Macron’s pension reforms escalate as police use 4,000 nonlethal dispersion grenades
 - [https://www.foxnews.com/world/protests-france-against-macrons-pension-reforms-escalate-police-4000-nonlethal-dispersion-grenades](https://www.foxnews.com/world/protests-france-against-macrons-pension-reforms-escalate-police-4000-nonlethal-dispersion-grenades)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 06:10:05+00:00

Police officers in France fired more than 4,000 nonlethal dispersion grenades at protesters, who have called for President Macron not to lift the retirement age.

## Iowa's Caitlin Clark sets record with 41-point triple-double, hits John Cena taunt
 - [https://www.foxnews.com/sports/iowas-caitlin-clark-sets-record-41-point-triple-double-hits-john-cena-taunt](https://www.foxnews.com/sports/iowas-caitlin-clark-sets-record-41-point-triple-double-hits-john-cena-taunt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 06:04:12+00:00

Caitlin Clark scored 41 points in a historic March Madness performance for Iowa. The Hawkeyes defeated Louisville 97-83 to move onto the Final Four.

## Miley Cyrus and Dolly Parton's 'Rainbowland' nixed from Wisconsin school concert for being 'controversial'
 - [https://www.foxnews.com/media/miley-cyrus-dolly-parton-rainbowland-nixed-wisconsin-school-concert-being-controversial](https://www.foxnews.com/media/miley-cyrus-dolly-parton-rainbowland-nixed-wisconsin-school-concert-being-controversial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 06:00:57+00:00

Parents complained to officials at a Waukesha, Wisconsin school district after a student performance of Dolly Parton&apos;s duet with Miley Cyrus was nixed from a spring concert.

## California doesn't care about empowering families. My state does
 - [https://www.foxnews.com/opinion/california-doesnt-care-about-empowering-families-my-state-does](https://www.foxnews.com/opinion/california-doesnt-care-about-empowering-families-my-state-does)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 06:00:13+00:00

On March 8, Gov. Sarah Huckabee Sanders signed a law repealing our youth-permitting system, empowering more teenagers to work part-time and learn the value of holding down a job.

## Gov. Hobbs faces backlash from Arizona Republicans for 'foolish' decision to scrap border strike force
 - [https://www.foxnews.com/politics/gov-hobbs-faces-backlash-arizona-republicans-foolish-decision-scrap-border-strike-force](https://www.foxnews.com/politics/gov-hobbs-faces-backlash-arizona-republicans-foolish-decision-scrap-border-strike-force)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 05:45:45+00:00

Arizona Gov. Katie Hobbs&apos; move to end a Border Strike Force is drawing intense criticism from Republicans in the state, amid an ongoing migrant crisis at the border.

## Newsom falls silent after calls for him to take executive action on reparations
 - [https://www.foxnews.com/politics/newsom-falls-silent-after-calls-for-him-take-executive-action-reparations](https://www.foxnews.com/politics/newsom-falls-silent-after-calls-for-him-take-executive-action-reparations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 05:00:07+00:00

California Gov. Gavin Newsom is staying silent as his state considers giving hundreds of billions of dollars to Black residents in reparations.

## Students deserve to know this shocking truth about communism
 - [https://www.foxnews.com/opinion/students-deserve-know-shocking-truth-communism](https://www.foxnews.com/opinion/students-deserve-know-shocking-truth-communism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 04:00:57+00:00

The Victims of Communism Memorial Foundation (VOC) applauds the numerous state-led efforts to ensure that the truth about communism is taught in all our schools. But more needs to be done.

## Gwyneth Paltrow's biggest controversies: ski crash trial to 'starvation diet' and 'conscious uncoupling'
 - [https://www.foxnews.com/entertainment/gwyneth-paltrows-biggest-controversies-ski-crash-trial-starvation-diet-conscious-uncoupling](https://www.foxnews.com/entertainment/gwyneth-paltrows-biggest-controversies-ski-crash-trial-starvation-diet-conscious-uncoupling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 04:00:28+00:00

Gwyneth Paltrow has had more than her fair share of controversies and eyebrow-raising moments from her civil trial connected to a ski accident to her Goop company&apos;s &quot;Vagina&quot; candle.

## Brother of California murder victim speaks out against zero-dollar bail: 'My sister is ... a statistic'
 - [https://www.foxnews.com/media/brother-california-murder-victim-speaks-out-against-zero-dollar-bail-sister-statistic](https://www.foxnews.com/media/brother-california-murder-victim-speaks-out-against-zero-dollar-bail-sister-statistic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 04:00:21+00:00

A victim&apos;s family member and police sergeant react after a Yolo County, California, study found that zero-dollar bail put hundreds of criminals back on the streets.

## Israel’s president calls for halt to Netanyahu-led judicial reform as countrywide protests intensify
 - [https://www.foxnews.com/world/israels-president-calls-halt-netanyahu-judicial-reform-countrywide-protests-intensify](https://www.foxnews.com/world/israels-president-calls-halt-netanyahu-judicial-reform-countrywide-protests-intensify)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 03:52:53+00:00

Israel’s ceremonial president Isaac Herzog called for Prime Minister Benjamin Netanyahu to stop his push for judicial reforms amid protests throughout the country.

## More than 30 animals seized from Tennessee breeding mill for animal cruelty
 - [https://www.foxnews.com/us/more-than-30-animals-seized-tennessee-breeding-mill-animal-cruelty](https://www.foxnews.com/us/more-than-30-animals-seized-tennessee-breeding-mill-animal-cruelty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 02:32:55+00:00

More than 30 animals were seized from a backyard breeding mill in Tennessee, where dogs, cats and chinchillas were found living in filthy conditions.

## Everything's bigger in Texas, including school choice
 - [https://www.foxnews.com/opinion/everythings-bigger-texas-including-school-choice](https://www.foxnews.com/opinion/everythings-bigger-texas-including-school-choice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 02:00:21+00:00

Everything&apos;s bigger in Texas, including school choice. The education reform effort has huge support and Texas Gov. Abbott is wisely moving forward with it.

## China wants Taiwan for more than 'historical value,' could disrupt global power dynamic: experts
 - [https://www.foxnews.com/world/china-wants-taiwan-historical-value-disrupt-global-power-dynamic-experts](https://www.foxnews.com/world/china-wants-taiwan-historical-value-disrupt-global-power-dynamic-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 02:00:12+00:00

Taiwan currently produces around 65% of semiconductors used globally and about 90% of the advanced chips, making it the most significant producer of a vital electronic component.

## With World War II airman's remains found, relative finally 'has closure' for whole family
 - [https://www.foxnews.com/lifestyle/world-war-ii-airmans-remains-found-relative-closure-whole-family](https://www.foxnews.com/lifestyle/world-war-ii-airmans-remains-found-relative-closure-whole-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 02:00:12+00:00

A World War II airman&apos;s remains were found nearly 80 years later. Sgt. John Holoka was in a plane crash, and his family went nearly six decades without answers.

## Sarah Ferguson, once a 'black sheep,' returns to royal fold: 'She turned disappointment into dollars'
 - [https://www.foxnews.com/entertainment/sarah-ferguson-black-sheep-returns-royal-fold-turned-disappointment-dollars](https://www.foxnews.com/entertainment/sarah-ferguson-black-sheep-returns-royal-fold-turned-disappointment-dollars)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 02:00:11+00:00

Sarah Ferguson, the Duchess of York, is enjoying a comeback as an author after years of being targeted by tabloids. The mother of Princess Beatrice and Princess Eugenie has been on a media tour in the U.S.

## On this day in history, March 27, 1912, Washington, D.C., cherry trees planted, gift from people of Tokyo
 - [https://www.foxnews.com/lifestyle/this-day-history-march-27-1912-washington-dc-cherry-trees-planted](https://www.foxnews.com/lifestyle/this-day-history-march-27-1912-washington-dc-cherry-trees-planted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-03-27 00:02:49+00:00

The cherry trees of Washington, D.C. — which blossom beautifully each spring — were a gift from the people of Tokyo and were planted on this day in history, March 17, 1912.

