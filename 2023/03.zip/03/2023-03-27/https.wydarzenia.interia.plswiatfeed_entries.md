# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Ukraińscy partyzanci: Zamach na rosyjskiego oficera to my
 - [https://wydarzenia.interia.pl/zagranica/news-ukrainscy-partyzanci-zamach-na-rosyjskiego-oficera-to-my,nId,6680799](https://wydarzenia.interia.pl/zagranica/news-ukrainscy-partyzanci-zamach-na-rosyjskiego-oficera-to-my,nId,6680799)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-03-27 12:18:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ukrainscy-partyzanci-zamach-na-rosyjskiego-oficera-to-my,nId,6680799"><img align="left" alt="Ukraińscy partyzanci: Zamach na rosyjskiego oficera to my" src="https://i.iplsc.com/ukrainscy-partyzanci-zamach-na-rosyjskiego-oficera-to-my/000GY5O9224H3YL3-C321.jpg" /></a>W Mariupolu okupowanym przez Rosjan doszło do kolejnego zamachu. Tym razem za cel ataku obrano jednego z najważniejszych rosyjskich oficerów - szefa miejskiej policji Michaiła Moskwina, który został ranny. Do wybuchu doszło, gdy ten znajdował się kilka metrów od pojazdu. Atak zorganizował i przeprowadził ukraiński ruch partyzancki.</p><br clear="all" />

