# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## The RESTRICT act aims to tackle TikTok. But it’s overly-broad and has major privacy and free speech implications.
 - [https://reclaimthenet.org/estrict-act-tiktok-privacy-and-free-speech-implications](https://reclaimthenet.org/estrict-act-tiktok-privacy-and-free-speech-implications)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-03-27 18:07:40+00:00

<a href="https://reclaimthenet.org/estrict-act-tiktok-privacy-and-free-speech-implications" rel="nofollow" title="The RESTRICT act aims to tackle TikTok. But it&#8217;s overly-broad and has major privacy and free speech implications."><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/03/tiktok-bill.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>It gives the government more power over ALL forms of communication.</p>
<p>The post <a href="https://reclaimthenet.org/estrict-act-tiktok-privacy-and-free-speech-implications" rel="nofollow">The RESTRICT act aims to tackle TikTok. But it&#8217;s overly-broad and has major privacy and free speech implications.</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Texas introduces two bills aimed at forcing online age verification checks
 - [https://reclaimthenet.org/texas-bills-online-age-verification-checks](https://reclaimthenet.org/texas-bills-online-age-verification-checks)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-03-27 16:50:10+00:00

<a href="https://reclaimthenet.org/texas-bills-online-age-verification-checks" rel="nofollow" title="Texas introduces two bills aimed at forcing online age verification checks"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/03/Bryan-Huges.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>A state Senate and House bill.</p>
<p>The post <a href="https://reclaimthenet.org/texas-bills-online-age-verification-checks" rel="nofollow">Texas introduces two bills aimed at forcing online age verification checks</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Following China: JP Morgan Chase wants people to pay for goods with face scans
 - [https://reclaimthenet.org/jp-morgan-chase-wants-people-to-pay-for-goods-with-facial-scans](https://reclaimthenet.org/jp-morgan-chase-wants-people-to-pay-for-goods-with-facial-scans)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-03-27 14:46:49+00:00

<a href="https://reclaimthenet.org/jp-morgan-chase-wants-people-to-pay-for-goods-with-facial-scans" rel="nofollow" title="Following China: JP Morgan Chase wants people to pay for goods with face scans"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/03/jp-face-scan.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Or through biometric palm scans.</p>
<p>The post <a href="https://reclaimthenet.org/jp-morgan-chase-wants-people-to-pay-for-goods-with-facial-scans" rel="nofollow">Following China: JP Morgan Chase wants people to pay for goods with face scans</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

