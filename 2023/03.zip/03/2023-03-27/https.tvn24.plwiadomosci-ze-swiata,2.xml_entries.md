# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Dwaj cudzoziemcy zatrzymani. Są podejrzani o szpiegostwo za rzecz Rosji i Białorusi
 - [https://tvn24.pl/polska/dwaj-cudzoziemcy-podejrzani-o-szpiegostwo-na-rzecz-rosji-i-bialorusi-zatrzymani-6862849?source=rss](https://tvn24.pl/polska/dwaj-cudzoziemcy-podejrzani-o-szpiegostwo-na-rzecz-rosji-i-bialorusi-zatrzymani-6862849?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-03-27 09:35:19+00:00

<img alt="Dwaj cudzoziemcy zatrzymani. Są podejrzani o szpiegostwo za rzecz Rosji i Białorusi" src="https://tvn24.pl/polska/cdn-zdjecie-iavdb5-sluzba-kontrwywiadu-wojskowego-6862878/alternates/LANDSCAPE_1280" />
    Polskie służby zatrzymały kolejne dwie osoby, które są podejrzane o pracę na rzecz rosyjskiego i białoruskiego wywiadu. Jeden z mężczyzn "gromadził informacje między innymi o infrastrukturze krytycznej oraz działaniach służb odpowiedzialnych za bezpieczeństwo", a drugi prowadził "rozpoznanie obiektów istotnych dla bezpieczeństwa Rzeczypospolitej, w tym związanych z Siłami Zbrojnymi".

