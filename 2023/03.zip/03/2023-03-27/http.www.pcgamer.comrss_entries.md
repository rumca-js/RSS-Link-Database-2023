# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Diablo 4 quest designer explains how they put the RP in RPG with one simple choice
 - [https://www.pcgamer.com/diablo-4-quest-designer-explains-how-they-put-the-rp-in-rpg-with-one-simple-choice](https://www.pcgamer.com/diablo-4-quest-designer-explains-how-they-put-the-rp-in-rpg-with-one-simple-choice)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 22:55:32+00:00

Your cleansing ritual choices matter, but not for the reasons you think.

## One of John Wick 4's most exhilarating moments was inspired by a top-down indie shooter
 - [https://www.pcgamer.com/one-of-john-wick-4s-most-exhilarating-moments-was-inspired-by-a-top-down-indie-shooter](https://www.pcgamer.com/one-of-john-wick-4s-most-exhilarating-moments-was-inspired-by-a-top-down-indie-shooter)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 21:49:19+00:00

Martial arts film inspires videogame which in turn inspires martial arts film.

## This Vampire Survivors-like has convinced me that imitation isn't such a bad thing
 - [https://www.pcgamer.com/this-vampire-survivors-like-has-convinced-me-that-imitation-isnt-such-a-bad-thing](https://www.pcgamer.com/this-vampire-survivors-like-has-convinced-me-that-imitation-isnt-such-a-bad-thing)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 21:27:11+00:00

It was boneheaded of me to doubt Boneraiser Minions' roguelike chops.

## Former Sims lead says men would lie about how they played during focus groups: 'Actually, what you did is you redecorated that bathroom'
 - [https://www.pcgamer.com/former-sims-lead-says-men-would-lie-about-how-they-played-during-focus-groups-actually-what-you-did-is-you-redecorated-that-bathroom](https://www.pcgamer.com/former-sims-lead-says-men-would-lie-about-how-they-played-during-focus-groups-actually-what-you-did-is-you-redecorated-that-bathroom)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 20:44:46+00:00

Rod Humble's new life sim takes careful account of the observation that people don't always want others knowing what they do in life sims.

## The Last of Us Part 1 preloads are live on Steam
 - [https://www.pcgamer.com/the-last-of-us-part-1-preloads-are-live-on-steam](https://www.pcgamer.com/the-last-of-us-part-1-preloads-are-live-on-steam)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 20:35:00+00:00

Get a head start on a big download.

## Surprise! The hit fighting game Multiversus was only in 'open beta' and now it's shutting down until sometime next year
 - [https://www.pcgamer.com/surprise-the-hit-fighting-game-multiversus-was-only-in-open-beta-and-now-its-shutting-down-until-sometime-next-year](https://www.pcgamer.com/surprise-the-hit-fighting-game-multiversus-was-only-in-open-beta-and-now-its-shutting-down-until-sometime-next-year)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 19:37:22+00:00

Warner is now aiming for a full release in early 2024.

## One million copies and 5000 mods later, Teardown's creator is just getting started
 - [https://www.pcgamer.com/one-million-copies-and-5000-mods-later-teardowns-creator-is-just-getting-started](https://www.pcgamer.com/one-million-copies-and-5000-mods-later-teardowns-creator-is-just-getting-started)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 18:59:17+00:00

Big things are ahead for the 2022 indie gem, including multiplayer and creative mode.

## Resident Evil 4 remake has a funny Easter egg that lets you skip the first major fight
 - [https://www.pcgamer.com/resident-evil-4-remake-has-a-funny-easter-egg-that-lets-you-skip-the-first-major-fight](https://www.pcgamer.com/resident-evil-4-remake-has-a-funny-easter-egg-that-lets-you-skip-the-first-major-fight)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 18:23:33+00:00

Un clever bastardo!

## Audio-Technica ATH-M50xSTS StreamSet
 - [https://www.pcgamer.com/audio-technica-ath-m50-sts-streamset-review](https://www.pcgamer.com/audio-technica-ath-m50-sts-streamset-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 16:46:50+00:00

The all-in-one gaming headset to replace your desktop mic.

## Terra Nil review
 - [https://www.pcgamer.com/terra-nil-review](https://www.pcgamer.com/terra-nil-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 15:46:58+00:00

More solitaire than strategy, Terra Nil is still a soothing, satisfying and educational environmentalist puzzler.

## I can't wait for this ambitious, procgen Deus Ex-like to hit early access next month
 - [https://www.pcgamer.com/i-cant-wait-for-this-ambitious-procgen-deus-ex-like-to-hit-early-access-next-month](https://www.pcgamer.com/i-cant-wait-for-this-ambitious-procgen-deus-ex-like-to-hit-early-access-next-month)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 15:40:01+00:00

Shadows of Doubt is a sandbox, stealth-based "detective simulator," and it's nearly here.

## This Heroic app is miles better at being the Epic Games Launcher than the Epic Games Launcher
 - [https://www.pcgamer.com/heroic-games-launcher-vs-epic-games-launcher](https://www.pcgamer.com/heroic-games-launcher-vs-epic-games-launcher)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 15:34:16+00:00

My Steam Deck loads my Epic Games library faster than my powerful PC, and it's thanks to the Heroic Games Launcher.

## Diablo 4 rogue almost solos world boss designed for 12 players, and would have if a necromancer didn't nick in and steal the kill at 1% HP
 - [https://www.pcgamer.com/diablo-4-rogue-almost-solos-world-boss-designed-for-12-players-and-would-have-if-a-necromancer-didnt-nick-in-and-steal-the-kill-at-1-hp](https://www.pcgamer.com/diablo-4-rogue-almost-solos-world-boss-designed-for-12-players-and-would-have-if-a-necromancer-didnt-nick-in-and-steal-the-kill-at-1-hp)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 14:40:12+00:00

Now that's timing.

## Makers of one of Slay The Spire's most beloved mods announce full game
 - [https://www.pcgamer.com/makers-of-one-of-slay-the-spires-most-beloved-mods-announce-full-game](https://www.pcgamer.com/makers-of-one-of-slay-the-spires-most-beloved-mods-announce-full-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 14:24:25+00:00

Tales & Tactics is coming this year, and promises "complexity at your own pace".

## How to unlock Morbius in Marvel's Midnight Suns
 - [https://www.pcgamer.com/marvels-midnight-suns-unlock-morbius](https://www.pcgamer.com/marvels-midnight-suns-unlock-morbius)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 13:56:41+00:00

It's Morbin' time (to unlock a new hero).

## Chris Avellone accepts 'seven-figure payment' to settle libel suit with those who accused him of sexual misconduct
 - [https://www.pcgamer.com/chris-avellone-accepts-seven-figure-payment-to-settle-libel-suit-with-those-who-accused-him-of-sexual-misconduct](https://www.pcgamer.com/chris-avellone-accepts-seven-figure-payment-to-settle-libel-suit-with-those-who-accused-him-of-sexual-misconduct)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 13:10:28+00:00

"We believe that he deserves a full return to the industry and support him in those endeavors."

## Life By You says yes to sex mods and privacy, no to gender roles
 - [https://www.pcgamer.com/life-by-you-interview](https://www.pcgamer.com/life-by-you-interview)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 13:00:03+00:00

We spoke to former Sims boss Rod Humble about his new life sim, which sounds like a platform more than a game.

## Nvidia kicks crypto to the curb: 'doesn’t bring anything useful for society. AI does'
 - [https://www.pcgamer.com/nvidia-kicks-crypto-to-the-curb-doesnt-bring-anything-useful-for-society-ai-does](https://www.pcgamer.com/nvidia-kicks-crypto-to-the-curb-doesnt-bring-anything-useful-for-society-ai-does)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 11:46:47+00:00

That's surely going to ruffle some feathers.

## How to summon a golem as a necromancer in Diablo 4
 - [https://www.pcgamer.com/diablo-4-how-to-summon-golem](https://www.pcgamer.com/diablo-4-how-to-summon-golem)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 11:43:54+00:00

The quest for this skill is unlocked at level 25.

## Say goodbye to absurdly cheap Game Pass: Microsoft is killing the $1 trial
 - [https://www.pcgamer.com/say-goodbye-to-absurdly-cheap-game-pass-microsoft-is-killing-the-dollar1-trial](https://www.pcgamer.com/say-goodbye-to-absurdly-cheap-game-pass-microsoft-is-killing-the-dollar1-trial)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 11:02:15+00:00

I'd buy that for a dollar, but Phil Spencer won't let me.

## Watch this person recycle a bottle by 3D printing a Raspberry Pi case
 - [https://www.pcgamer.com/watch-this-person-recycle-a-bottle-by-3d-printing-a-raspberry-pi-case](https://www.pcgamer.com/watch-this-person-recycle-a-bottle-by-3d-printing-a-raspberry-pi-case)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 04:43:02+00:00

From drink to pi in a matter of print.

## Wordle hint and answer #646: Monday, March 27
 - [https://www.pcgamer.com/wordle-hint-answer-today-646-march-27](https://www.pcgamer.com/wordle-hint-answer-today-646-march-27)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 04:05:44+00:00

Today's Wordle: Help to solve Monday's puzzle.

## Five new Steam games you probably missed (March 27, 2023)
 - [https://www.pcgamer.com/five-new-steam-games-you-probably-missed-march-27-2023](https://www.pcgamer.com/five-new-steam-games-you-probably-missed-march-27-2023)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 00:44:38+00:00

Sorting through every new game on Steam so you don't have to.

## Be a swamp devil, cause chaos, steal stuff, in this lo-fi immersive sim
 - [https://www.pcgamer.com/be-a-swamp-devil-cause-chaos-steal-stuff-in-this-lo-fi-immersive-sim](https://www.pcgamer.com/be-a-swamp-devil-cause-chaos-steal-stuff-in-this-lo-fi-immersive-sim)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-03-27 00:36:26+00:00

Scope the free demo for indie immersive sim Brush Burial.

