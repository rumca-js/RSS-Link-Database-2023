# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## NUC 13 Pro First Look, The Fastest Ultra Small Foot Print Intel Yet! Hands On Review
 - [https://www.youtube.com/watch?v=LUWVGNqGSFM](https://www.youtube.com/watch?v=LUWVGNqGSFM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-03-27 14:06:00+00:00

In this video we take a look at the all new Intel NUC 13 Pro! Powered by a 12 Core 5GHz CPU this tiny PC has the Power for Work, Play and Media and when it comes time connecting an eGPU is super easy using Thunderbolt 4!
We do an unboxing, go over the specs, run some benchmarks and test out some PC games using the iGPU and even an RTX 3080Ti connected over thunderbolt 4!

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME 
12520 Capital Blvd Ste 401 Number 108
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#intel #nuc #etaprime
00:00 Introduction
00:32 Unboxing
01:25 Overview
02:38 Specs
03:19 Overall performance and 4K Video playback
04:40 Nuc 13 pro benchmarks
05:40 Nuc 13 pro iGPU Gaming
07:02 Nuc 13 Pro eGPU 3080Ti

