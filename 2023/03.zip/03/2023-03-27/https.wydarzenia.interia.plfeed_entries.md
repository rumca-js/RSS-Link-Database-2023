# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Media: Rosja może zdominować ukraińskie niebo. Ma 12 razy więcej samolotów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosja-moze-zdominowac-ukrainskie-niebo-ma-12-razy-wiec,nId,6681299](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosja-moze-zdominowac-ukrainskie-niebo-ma-12-razy-wiec,nId,6681299)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 20:25:34+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosja-moze-zdominowac-ukrainskie-niebo-ma-12-razy-wiec,nId,6681299"><img align="left" alt="Media: Rosja może zdominować ukraińskie niebo. Ma 12 razy więcej samolotów" src="https://i.iplsc.com/media-rosja-moze-zdominowac-ukrainskie-niebo-ma-12-razy-wiec/000GY9J9XGH3XJTJ-C321.jpg" /></a>Rosyjskie myśliwce czwartej generacji Su-35 umacniają dominację Rosji w strefie działań wojennych - przekazały media. Dodano, że to może być niepokojącym wydarzeniem dla Ukrainy i jej partnerów. Ukraiński urzędnik przekazał, że dostarczenie nowoczesnych odrzutowców i rakiet dla Kijowa wymagać będzie ogromnych nakładów finansowych.</p><br clear="all" />

## Szokujące rekolekcje w Toruniu. "Sama tego chciałaś dz***"
 - [https://wydarzenia.interia.pl/kujawsko-pomorskie/news-szokujace-rekolekcje-w-toruniu-sama-tego-chcialas-dz,nId,6681261](https://wydarzenia.interia.pl/kujawsko-pomorskie/news-szokujace-rekolekcje-w-toruniu-sama-tego-chcialas-dz,nId,6681261)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 19:54:19+00:00

<p><a href="https://wydarzenia.interia.pl/kujawsko-pomorskie/news-szokujace-rekolekcje-w-toruniu-sama-tego-chcialas-dz,nId,6681261"><img align="left" alt="Szokujące rekolekcje w Toruniu. &quot;Sama tego chciałaś dz***&quot;" src="https://i.iplsc.com/szokujace-rekolekcje-w-toruniu-sama-tego-chcialas-dz/000GY919AM768NNA-C321.jpg" /></a>&quot;Dantejskie sceny w kościele św. Maksymiliana Kolbego w Toruniu&quot; - pisze w mediach społecznościowych pan Tomasz, publikując wstrząsające wideo nagrane podczas rekolekcji młodzieży. Do materiału dotarł lokalny portal tylkotorun.pl, który podał też relacje wstrząśniętych sytuacją uczniów zgromadzonych w świątyni. Według nieoficjalnych informacji odbiorcami rekolekcji miało być docelowo nawet cztery tysiące młodych torunian.</p><br clear="all" />

## Szokujące rekolekcje w Toruniu. "Sama tego chciałaś"
 - [https://wydarzenia.interia.pl/kujawsko-pomorskie/news-szokujace-rekolekcje-w-toruniu-sama-tego-chcialas,nId,6681261](https://wydarzenia.interia.pl/kujawsko-pomorskie/news-szokujace-rekolekcje-w-toruniu-sama-tego-chcialas,nId,6681261)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 19:54:19+00:00

<p><a href="https://wydarzenia.interia.pl/kujawsko-pomorskie/news-szokujace-rekolekcje-w-toruniu-sama-tego-chcialas,nId,6681261"><img align="left" alt="Szokujące rekolekcje w Toruniu. &quot;Sama tego chciałaś&quot;" src="https://i.iplsc.com/szokujace-rekolekcje-w-toruniu-sama-tego-chcialas/000GY919AM768NNA-C321.jpg" /></a>&quot;Dantejskie sceny w kościele św. Maksymiliana Kolbego w Toruniu&quot; - pisze w mediach społecznościowych pan Tomasz, publikując wstrząsające wideo nagrane podczas rekolekcji młodzieży. Do materiału dotarł lokalny portal tylkotorun.pl, który podał też relacje wstrząśniętych sytuacją uczniów zgromadzonych w świątyni. Według nieoficjalnych informacji odbiorcami rekolekcji miało być docelowo nawet cztery tysiące młodych torunian.</p><br clear="all" />

## W Egipcie odkryto zmumifikowane głowy ponad 2 tys. zwierząt
 - [https://wydarzenia.interia.pl/zagranica/news-w-egipcie-odkryto-zmumifikowane-glowy-ponad-2-tys-zwierzat,nId,6681284](https://wydarzenia.interia.pl/zagranica/news-w-egipcie-odkryto-zmumifikowane-glowy-ponad-2-tys-zwierzat,nId,6681284)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 19:36:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-w-egipcie-odkryto-zmumifikowane-glowy-ponad-2-tys-zwierzat,nId,6681284"><img align="left" alt="W Egipcie odkryto zmumifikowane głowy ponad 2 tys. zwierząt" src="https://i.iplsc.com/w-egipcie-odkryto-zmumifikowane-glowy-ponad-2-tys-zwierzat/000GY9BCDQJLC0WK-C321.jpg" /></a>Archeolodzy w Abydos, w Egipcie znaleźli ponad 2 tys. zmumifikowanych głów baranów - przekazały media. Odkryto również zmumifikowane psy, kozy, krowy, jelenie i strusia. Znaleziska mają więcej niż 4 tys. lat.</p><br clear="all" />

## 22-latek na rowerze uzbierał jednej nocy 5 tys. zł mandatów
 - [https://wydarzenia.interia.pl/lubelskie/news-22-latek-na-rowerze-uzbieral-jednej-nocy-5-tys-zl-mandatow,nId,6681244](https://wydarzenia.interia.pl/lubelskie/news-22-latek-na-rowerze-uzbieral-jednej-nocy-5-tys-zl-mandatow,nId,6681244)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 19:26:12+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-22-latek-na-rowerze-uzbieral-jednej-nocy-5-tys-zl-mandatow,nId,6681244"><img align="left" alt="22-latek na rowerze uzbierał jednej nocy 5 tys. zł mandatów" src="https://i.iplsc.com/22-latek-na-rowerze-uzbieral-jednej-nocy-5-tys-zl-mandatow/000GY9BOGGTSI7HU-C321.jpg" /></a>22-letni mieszkaniec powiatu włodawskiego będąc pod wpływem alkoholu wsiadł na rower. Mężczyzna jednej nocy w przeciągu dwóch godzin otrzymał dwa mandaty na łączną kwotę 5 tys. złotych. Jak informuje policja, rowerzysta podczas drugiej kontroli miał większe stężenie alkoholu w wydychanym powietrzu.</p><br clear="all" />

## Polka zgodziła się na ślub. Okazało się, że wybranek miał niecne zamiary
 - [https://wydarzenia.interia.pl/kraj/news-polka-zgodzila-sie-na-slub-okazalo-sie-ze-wybranek-mial-niec,nId,6681242](https://wydarzenia.interia.pl/kraj/news-polka-zgodzila-sie-na-slub-okazalo-sie-ze-wybranek-mial-niec,nId,6681242)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 19:12:27+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polka-zgodzila-sie-na-slub-okazalo-sie-ze-wybranek-mial-niec,nId,6681242"><img align="left" alt="Polka zgodziła się na ślub. Okazało się, że wybranek miał niecne zamiary" src="https://i.iplsc.com/polka-zgodzila-sie-na-slub-okazalo-sie-ze-wybranek-mial-niec/000GY8XEYE23BAJV-C321.jpg" /></a>Polka zakochała się w Tunezyjczyku i chciała wziąć z nim ślub. Kobieta nie podejrzewała, że wybranek jej serca może mieć niecne zamiary. 32-latek został aresztowany przez Straż Graniczną z Bydgoszczy. Okazało się, że małżeństwo miało być dla niego sposobem na legalizację pobytu w naszym kraju.</p><br clear="all" />

## Pijany 49-latek chciał morsować. "Bez nas nie miałby szans"
 - [https://wydarzenia.interia.pl/pomorskie/news-pijany-49-latek-chcial-morsowac-bez-nas-nie-mialby-szans,nId,6681269](https://wydarzenia.interia.pl/pomorskie/news-pijany-49-latek-chcial-morsowac-bez-nas-nie-mialby-szans,nId,6681269)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 19:09:26+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-pijany-49-latek-chcial-morsowac-bez-nas-nie-mialby-szans,nId,6681269"><img align="left" alt="Pijany 49-latek chciał morsować. &quot;Bez nas nie miałby szans&quot; " src="https://i.iplsc.com/pijany-49-latek-chcial-morsowac-bez-nas-nie-mialby-szans/000GY9CLO6URA3N0-C321.jpg" /></a>W niedzielę podczas morsowania grupa &quot;Nordowe Morsy&quot; uratowała 49-letniego Ukraińca. Mężczyzna będąc po wpływem alkoholu wskoczył do morza. Podczas rozmowy z policjantami 49-latek przyznał, że &quot;chciał spróbować swoich sił w morsowaniu&quot;.   </p><br clear="all" />

## Śmierć polskiego wolontariusza. Dostarczał pomoc humanitarną w Ukrainie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-smierc-polskiego-wolontariusza-dostarczal-pomoc-humanitarna-,nId,6681205](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-smierc-polskiego-wolontariusza-dostarczal-pomoc-humanitarna-,nId,6681205)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 18:47:26+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-smierc-polskiego-wolontariusza-dostarczal-pomoc-humanitarna-,nId,6681205"><img align="left" alt="Śmierć polskiego wolontariusza. Dostarczał pomoc humanitarną w Ukrainie" src="https://i.iplsc.com/smierc-polskiego-wolontariusza-dostarczal-pomoc-humanitarna/000GY8I8KUOS1PIH-C321.jpg" /></a>Zmarł polski wolontariusz, który w czwartek 16 marca doznał poważnych obrażeń podczas rosyjskiego ostrzału. Pojazd polskich ochotników pomagających w Ukrainie został ostrzelany na trasie Konstantynówka-Czasiw Jar w trakcie dostarczania pomocy humanitarnej.</p><br clear="all" />

## Maszynista-przemytnik: Papierosy ukrył w silniku lokomotywy
 - [https://wydarzenia.interia.pl/lubelskie/news-maszynista-przemytnik-papierosy-ukryl-w-silniku-lokomotywy,nId,6681202](https://wydarzenia.interia.pl/lubelskie/news-maszynista-przemytnik-papierosy-ukryl-w-silniku-lokomotywy,nId,6681202)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 18:19:21+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-maszynista-przemytnik-papierosy-ukryl-w-silniku-lokomotywy,nId,6681202"><img align="left" alt="Maszynista-przemytnik: Papierosy ukrył w silniku lokomotywy " src="https://i.iplsc.com/maszynista-przemytnik-papierosy-ukryl-w-silniku-lokomotywy/000GY8IK59UJ6AUF-C321.jpg" /></a>Dwóch pracowników kolei w pociągach towarowych ukryło papierosy o wartości rynkowej 12 tys. złotych. Część przemycanego towaru schowana była w silniku lokomotywy. Przemytnicy ukarani zostali mandatami w łącznej kwocie 14,7 tys. złotych - poinformował Nadbużański Oddział Straży Granicznej w Chełmie. 

</p><br clear="all" />

## "Moja cierpliwość ma granice". Spięcie na spotkaniu z Donaldem Tuskiem
 - [https://wydarzenia.interia.pl/kraj/news-moja-cierpliwosc-ma-granice-spiecie-na-spotkaniu-z-donaldem-,nId,6680980](https://wydarzenia.interia.pl/kraj/news-moja-cierpliwosc-ma-granice-spiecie-na-spotkaniu-z-donaldem-,nId,6680980)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 18:00:00+00:00

<p>- Moja cierpliwość ma swoje granice. Rozmawiałem już z panem w Chorzowie, pojechałem do pana domu. Sprawa jest znana - powiedział wzburzony Donald Tusk, gdy na spotkaniu z mieszkańcami Strzelec Opolskich, jednemu z pytających odebrano głos. Osobą tą był kibic Ruchu Chorzów, który kolejny raz pytał o budowę stadionu dla drużyny. </p><br clear="all" />

## Zbigniew Ziobro o śledztwie ws. księdza Blachnickiego: "Mamy podejrzewanych"
 - [https://wydarzenia.interia.pl/kraj/news-zbigniew-ziobro-o-sledztwie-ws-ksiedza-blachnickiego-mamy-po,nId,6681218](https://wydarzenia.interia.pl/kraj/news-zbigniew-ziobro-o-sledztwie-ws-ksiedza-blachnickiego-mamy-po,nId,6681218)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 17:44:37+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zbigniew-ziobro-o-sledztwie-ws-ksiedza-blachnickiego-mamy-po,nId,6681218"><img align="left" alt="Zbigniew Ziobro o śledztwie ws. księdza Blachnickiego: &quot;Mamy podejrzewanych&quot;" src="https://i.iplsc.com/zbigniew-ziobro-o-sledztwie-ws-ksiedza-blachnickiego-mamy-po/000GHRP9JQ5GUW2H-C321.jpg" /></a>Minister sprawiedliwości, prokurator generalny Zbigniew Ziobro złożył wieniec przed budynkiem Aresztu Śledczego w Katowicach i wygłosił krótkie przemówienie w związku ze wznowieniem śledztwa w sprawie śmierci ks. Franciszka Blachnickiego. Prokurator generalny zapowiedział także stworzenie tablicy upamiętniającej zamordowanego kapłana oraz podkreślił, że śledztwo cały czas jest w toku. - Mamy też osoby podejrzewane o sprawstwo - przyznał minister.</p><br clear="all" />

## Netanjahu o "ekstremistycznej mniejszości" w Izraelu. Ogłosił decyzję
 - [https://wydarzenia.interia.pl/zagranica/news-netanjahu-o-ekstremistycznej-mniejszosci-w-izraelu-oglosil-d,nId,6680565](https://wydarzenia.interia.pl/zagranica/news-netanjahu-o-ekstremistycznej-mniejszosci-w-izraelu-oglosil-d,nId,6680565)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 17:21:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-netanjahu-o-ekstremistycznej-mniejszosci-w-izraelu-oglosil-d,nId,6680565"><img align="left" alt="Netanjahu o &quot;ekstremistycznej mniejszości&quot; w Izraelu. Ogłosił decyzję" src="https://i.iplsc.com/netanjahu-o-ekstremistycznej-mniejszosci-w-izraelu-oglosil-d/000GY42ZO83SQAAL-C321.jpg" /></a>- Istnieje mniejszość ekstremistyczna gotowa do podziału naszego narodu. Nie jestem gotowy na rozbiór państwa. Stoimy na groźnym rozdrożu - powiedział premier Benjamin Netanjahu w specjalnym oświadczeniu w związku z masowymi protestami w Izraelu. Zielone światło na przełożenie prac nad kontrowersyjną i wzbudzającą niepokoje społeczne reformę sądownictwa dał Itamar Ben-Gvir, minister bezpieczeństwa narodowego. Demonstranci sprzeciwiają się proponowanej przez rząd reformie sądownictwa, która zakłada zwiększenie wpływu polityków na wymiar...</p><br clear="all" />

## Bronowice: Przebijał "hurtowo" opony. Policja opublikowała nagranie
 - [https://wydarzenia.interia.pl/malopolskie/news-bronowice-przebijal-hurtowo-opony-policja-opublikowala-nagra,nId,6680999](https://wydarzenia.interia.pl/malopolskie/news-bronowice-przebijal-hurtowo-opony-policja-opublikowala-nagra,nId,6680999)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 17:15:42+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-bronowice-przebijal-hurtowo-opony-policja-opublikowala-nagra,nId,6680999"><img align="left" alt="Bronowice: Przebijał &quot;hurtowo&quot; opony. Policja opublikowała nagranie" src="https://i.iplsc.com/bronowice-przebijal-hurtowo-opony-policja-opublikowala-nagra/000GY7XA5TO0XR0P-C321.jpg" /></a>Funkcjonariusze krakowskiej policji proszą o pomoc w ustaleniu tożsamości mężczyzny, który w rejonie Bronowic przebijał opony w samochodach. W ten sposób zniszczył kilkadziesiąt aut. Do zdarzenia doszło w lutym i marcu. Mężczyzna wciąż nie został zidentyfikowany. Policja opublikowała wideo ze zdarzenia. </p><br clear="all" />

## Wierzbica koło Legionowa: Wypadek z udziałem szkolnego autokaru
 - [https://wydarzenia.interia.pl/mazowieckie/news-wierzbica-kolo-legionowa-wypadek-z-udzialem-szkolnego-autoka,nId,6681029](https://wydarzenia.interia.pl/mazowieckie/news-wierzbica-kolo-legionowa-wypadek-z-udzialem-szkolnego-autoka,nId,6681029)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 17:00:46+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-wierzbica-kolo-legionowa-wypadek-z-udzialem-szkolnego-autoka,nId,6681029"><img align="left" alt="Wierzbica koło Legionowa: Wypadek z udziałem szkolnego autokaru  " src="https://i.iplsc.com/wierzbica-kolo-legionowa-wypadek-z-udzialem-szkolnego-autoka/000GY8EJ4YIOVGJE-C321.jpg" /></a>Autobus szkolny zderzył się z samochodem osobowym. Do zdarzenia doszło w Wierzbicy koło Legionowa. - Kierowca Renault Scenic wyjeżdżając z drogi podporządkowanej nie ustąpił pierwszeństwa autobusowi szkolnemu, który rozwoził dzieci - przekazała w rozmowie z Interią oficer prasowa Komendy Powiatowej Policji w Legionowie Agata Halicka.</p><br clear="all" />

## TikTok w telefonach polskich urzędników. Jest rekomendacja
 - [https://wydarzenia.interia.pl/kraj/news-tiktok-w-telefonach-polskich-urzednikow-jest-rekomendacja,nId,6680526](https://wydarzenia.interia.pl/kraj/news-tiktok-w-telefonach-polskich-urzednikow-jest-rekomendacja,nId,6680526)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 16:37:22+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tiktok-w-telefonach-polskich-urzednikow-jest-rekomendacja,nId,6680526"><img align="left" alt="TikTok w telefonach polskich urzędników. Jest rekomendacja" src="https://i.iplsc.com/tiktok-w-telefonach-polskich-urzednikow-jest-rekomendacja/000GY3NPS2WE961O-C321.jpg" /></a>Rządowa rada ds. cyfryzacji przegłosowała uchwałę, wzywającą polskich urzędników do odinstalowania z telefonów TikToka. - Rekomendujemy, żeby na sprzętach pracowników administracji państwowej nie było zainstalowanych żadnych aplikacji społecznościowych - przekazał w rozmowie z Polsat News przewodniczący rządowej rady ds. cyfryzacji Józef Orzeł. - Chodzi o to, by nie łączyć służbowych aplikacji i narzędzi z prywatnymi - wyjaśnił.</p><br clear="all" />

## Benjamin Netanjahu "zamrozi" reformę sądownictwa. Jest zgoda koalicjanta
 - [https://wydarzenia.interia.pl/zagranica/news-benjamin-netanjahu-zamrozi-reforme-sadownictwa-jest-zgoda-ko,nId,6681038](https://wydarzenia.interia.pl/zagranica/news-benjamin-netanjahu-zamrozi-reforme-sadownictwa-jest-zgoda-ko,nId,6681038)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 16:20:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-benjamin-netanjahu-zamrozi-reforme-sadownictwa-jest-zgoda-ko,nId,6681038"><img align="left" alt="Benjamin Netanjahu &quot;zamrozi&quot; reformę sądownictwa. Jest zgoda koalicjanta" src="https://i.iplsc.com/benjamin-netanjahu-zamrozi-reforme-sadownictwa-jest-zgoda-ko/000GY80ALNGEKPVC-C321.jpg" /></a>Skrajnie prawicowa partia Żydowska Siła, wchodząca w skład ultraprawicowej i nacjonalistycznej koalicji w izraelskim rządzie, na czele którego stoi premier Benjamin Netanjahu, ogłosiła przełożenie prac nad kontrowersyjną i wzbudzającą niepokoje społeczne reformę sądownictwa na przyszły miesiąc. Jednocześnie lider partii, Itamar Ben-Gvir dał czas premierowi na realizację rządowego planu poprzez negocjacje - informuje &quot;The Times of Israel&quot;. Krajowe media sugerują, że Netanjahu będzie starał się wypracować kompromis z Knesecie konsultując się z...</p><br clear="all" />

## Przystąpienie Finlandii do NATO. Węgierski parlament zatwierdził wniosek
 - [https://wydarzenia.interia.pl/zagranica/news-przystapienie-finlandii-do-nato-wegierski-parlament-zatwierd,nId,6680889](https://wydarzenia.interia.pl/zagranica/news-przystapienie-finlandii-do-nato-wegierski-parlament-zatwierd,nId,6680889)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 16:17:28+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-przystapienie-finlandii-do-nato-wegierski-parlament-zatwierd,nId,6680889"><img align="left" alt="Przystąpienie Finlandii do NATO. Węgierski parlament zatwierdził wniosek" src="https://i.iplsc.com/przystapienie-finlandii-do-nato-wegierski-parlament-zatwierd/000GY61UTOWMD128-C321.jpg" /></a>Węgierski parlament zatwierdził wniosek Finlandii o dołączenie do NATO. Na decyzję rządu Viktora Orbana w sprawie swojego członkostwa w Sojuszu Północnoatlantyckim cały czas oczekuje Szwecja. Do rozszerzenia NATO wciąż wymagana jest jeszcze formalna zgoda Turcji.</p><br clear="all" />

## "Wall Street Journal" cytuje Morawieckiego: Obawiam się o kraje zachodnie
 - [https://wydarzenia.interia.pl/zagranica/news-wall-street-journal-cytuje-morawieckiego-obawiam-sie-o-kraje,nId,6681026](https://wydarzenia.interia.pl/zagranica/news-wall-street-journal-cytuje-morawieckiego-obawiam-sie-o-kraje,nId,6681026)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 16:15:23+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wall-street-journal-cytuje-morawieckiego-obawiam-sie-o-kraje,nId,6681026"><img align="left" alt="&quot;Wall Street Journal&quot; cytuje Morawieckiego: Obawiam się o kraje zachodnie" src="https://i.iplsc.com/wall-street-journal-cytuje-morawieckiego-obawiam-sie-o-kraje/000867I9TDEV9L7B-C321.jpg" /></a>Premier polskiego rządu Mateusz Morawiecki cytowany przez amerykański dziennik &quot;Wall Street Journal&quot; przyznaje, że w kontekście pomocy pogrążonej w wojnie Ukrainie bardziej obawia się o zachodnioeuropejskich partnerów i przyjaciół, niż o USA. Według dziennika WSJ Zachód i USA są przekonani co do słuszności działań, ale nie mają konkretnego planu, co w obliczu przewidywanej przez ekspertów wojny na wyniszczenie może okazać się niewystarczające.</p><br clear="all" />

## Strzelanina w chrześcijańskiej szkole w USA. Jest wiele ofiar
 - [https://wydarzenia.interia.pl/zagranica/news-strzelanina-w-chrzescijanskiej-szkole-w-usa-jest-wiele-ofiar,nId,6681187](https://wydarzenia.interia.pl/zagranica/news-strzelanina-w-chrzescijanskiej-szkole-w-usa-jest-wiele-ofiar,nId,6681187)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 16:13:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-strzelanina-w-chrzescijanskiej-szkole-w-usa-jest-wiele-ofiar,nId,6681187"><img align="left" alt="Strzelanina w chrześcijańskiej szkole w USA. Jest wiele ofiar" src="https://i.iplsc.com/strzelanina-w-chrzescijanskiej-szkole-w-usa-jest-wiele-ofiar/000GY8DTTSGXD391-C321.jpg" /></a>W strzelaninie w szkole w Nashville zginęło co najmniej troje dzieci - przekazały media. Straż pożarna podała, że jest wielu rannych. Napastnik został zastrzelony. W szkole przeprowadzono program szkoleniowy na wypadek strzelaniny w 2022 roku.</p><br clear="all" />

## Niedźwiedź postanowił przetestować trampolinę. Media obiegło nagranie
 - [https://wydarzenia.interia.pl/zagranica/news-niedzwiedz-postanowil-przetestowac-trampoline-media-obieglo-,nId,6681016](https://wydarzenia.interia.pl/zagranica/news-niedzwiedz-postanowil-przetestowac-trampoline-media-obieglo-,nId,6681016)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 15:56:52+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niedzwiedz-postanowil-przetestowac-trampoline-media-obieglo-,nId,6681016"><img align="left" alt="Niedźwiedź postanowił przetestować trampolinę. Media obiegło nagranie" src="https://i.iplsc.com/niedzwiedz-postanowil-przetestowac-trampoline-media-obieglo/000GY7XO7MJTJAR1-C321.jpg" /></a>Mieszkanka amerykańskiego stanu Nowy Jork zaobserwowała przed swoim domem niedźwiedzia. Media społecznościowe obiegło nagranie z wizyty drapieżnika w ogrodzie. Zaciekawione zwierzę najpierw postanowiło pobawić się piłką, a później zaczęło ciągnąć za wąż ogrodowy. Niedźwiedź przeszedł także do sprawdzenia trampoliny.</p><br clear="all" />

## Nowa Zelandia: Fale wyrzuciły na plaże but z ludzką stopą
 - [https://wydarzenia.interia.pl/zagranica/news-nowa-zelandia-fale-wyrzucily-na-plaze-but-z-ludzka-stopa,nId,6680969](https://wydarzenia.interia.pl/zagranica/news-nowa-zelandia-fale-wyrzucily-na-plaze-but-z-ludzka-stopa,nId,6680969)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 15:26:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowa-zelandia-fale-wyrzucily-na-plaze-but-z-ludzka-stopa,nId,6680969"><img align="left" alt="Nowa Zelandia: Fale wyrzuciły na plaże but z ludzką stopą" src="https://i.iplsc.com/nowa-zelandia-fale-wyrzucily-na-plaze-but-z-ludzka-stopa/000GY7E9LK4SO13F-C321.jpg" /></a>W Nowej Zelandii morze wyrzuciło na brzeg but. Ku przerażeniu okolicznych mieszkańców, w środku znajdowała się ludzka stopa. Śledztwo w sprawie znaleziska wszczęła miejscowa policja.</p><br clear="all" />

## Pierwsza rekonstrukcja krocza nową metodą w Polsce. Ginekolodzy mówią o sukcesie
 - [https://wydarzenia.interia.pl/kraj/news-pierwsza-rekonstrukcja-krocza-nowa-metoda-w-polsce-ginekolod,nId,6680970](https://wydarzenia.interia.pl/kraj/news-pierwsza-rekonstrukcja-krocza-nowa-metoda-w-polsce-ginekolod,nId,6680970)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 15:13:15+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pierwsza-rekonstrukcja-krocza-nowa-metoda-w-polsce-ginekolod,nId,6680970"><img align="left" alt="Pierwsza rekonstrukcja krocza nową metodą w Polsce. Ginekolodzy mówią o sukcesie " src="https://i.iplsc.com/pierwsza-rekonstrukcja-krocza-nowa-metoda-w-polsce-ginekolod/000GY7GCYK2IFKNI-C321.jpg" /></a>Szczecińscy ginekolodzy we współpracy z dr. Danem O’Deyem z Niemiec dokonali rekonstrukcji krocza u 38-latki. Zabieg odbył się w Samodzielnym Publicznym Szpitalu Klinicznym nr 2. Jak przyznają tamtejsi lekarze, to pierwsza taka operacja w Polsce.

</p><br clear="all" />

## Warszawa: Kobieta z dzieckiem na rękach wypadła z ósmego piętra
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-warszawa-kobieta-z-dzieckiem-na-rekach-wypadla-z-osmego-piet,nId,6680971](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-warszawa-kobieta-z-dzieckiem-na-rekach-wypadla-z-osmego-piet,nId,6680971)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 14:37:37+00:00

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-warszawa-kobieta-z-dzieckiem-na-rekach-wypadla-z-osmego-piet,nId,6680971"><img align="left" alt="Warszawa: Kobieta z dzieckiem na rękach wypadła z ósmego piętra" src="https://i.iplsc.com/warszawa-kobieta-z-dzieckiem-na-rekach-wypadla-z-osmego-piet/000D60KN9WR49Y6V-C321.jpg" /></a>W Warszawie, w dzielnicy Bemowo na ulicy Górczewskiej doszło do koszmarnego zdarzenia. Z okna na ósmym piętrze wypadła kobieta z małym dzieckiem w rękach. Osoby poszkodowane zostały przetransportowane do szpitala. Policja ustala okoliczności zdarzenia.</p><br clear="all" />

## Śmierć rosyjskiego dowódcy. Rosjanie ukrywają niewygodne fakty?
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-smierc-rosyjskiego-dowodcy-rosjanie-ukrywaja-niewygodne-fakt,nId,6680731](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-smierc-rosyjskiego-dowodcy-rosjanie-ukrywaja-niewygodne-fakt,nId,6680731)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 14:25:22+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-smierc-rosyjskiego-dowodcy-rosjanie-ukrywaja-niewygodne-fakt,nId,6680731"><img align="left" alt="Śmierć rosyjskiego dowódcy. Rosjanie ukrywają niewygodne fakty?" src="https://i.iplsc.com/smierc-rosyjskiego-dowodcy-rosjanie-ukrywaja-niewygodne-fakt/000GY5E50HFN2CKU-C321.jpg" /></a>Rosjanie starają się ukryć sposób, w jaki zmarł ich oficer Dmitrij Lissicki. O ile Siły Zbrojne Ukrainy mówią wprost, że mężczyzna został przez nich zlikwidowany, to wśród Rosjan panuje zmowa milczenia. Pojedyncze osoby wspominają o &quot;bohaterskiej śmierci&quot;, jednak brakuje spójnego przekazu. </p><br clear="all" />

## Tusk o dziadku wcielonym siłą do Wehrmachtu: Nikt nie odbierze mi prawdy
 - [https://wydarzenia.interia.pl/kraj/news-tusk-o-dziadku-wcielonym-sila-do-wehrmachtu-nikt-nie-odbierz,nId,6680871](https://wydarzenia.interia.pl/kraj/news-tusk-o-dziadku-wcielonym-sila-do-wehrmachtu-nikt-nie-odbierz,nId,6680871)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 13:40:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-o-dziadku-wcielonym-sila-do-wehrmachtu-nikt-nie-odbierz,nId,6680871"><img align="left" alt="Tusk o dziadku wcielonym siłą do Wehrmachtu: Nikt nie odbierze mi prawdy" src="https://i.iplsc.com/tusk-o-dziadku-wcielonym-sila-do-wehrmachtu-nikt-nie-odbierz/000GY62KH1N88HRC-C321.jpg" /></a>Donald Tusk złożył kwiaty w hołdzie śląskim powstańcom i opublikował nagranie, w którym nawiązał do swoich korzeni i dziadka - Józefa Tuska. Wspomniał, że dziadka aresztowało Gestapo, trafił do obozu koncentracyjnego, a następnie został &quot;siłą wcielony do Wehrmachtu&quot;. - Będę go zawsze pamiętał i nikt prawdy o moim dziadku nigdy mi nie odbierze - zapewnił Tusk.    </p><br clear="all" />

## Niespokojnie w Izraelu. Netanajahu zwrócił się do protestujących
 - [https://wydarzenia.interia.pl/zagranica/news-niespokojnie-w-izraelu-netanajahu-zwrocil-sie-do-protestujac,nId,6680869](https://wydarzenia.interia.pl/zagranica/news-niespokojnie-w-izraelu-netanajahu-zwrocil-sie-do-protestujac,nId,6680869)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 13:32:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niespokojnie-w-izraelu-netanajahu-zwrocil-sie-do-protestujac,nId,6680869"><img align="left" alt="Niespokojnie w Izraelu. Netanajahu zwrócił się do protestujących" src="https://i.iplsc.com/niespokojnie-w-izraelu-netanajahu-zwrocil-sie-do-protestujac/000GY5VK7NOIJ8GM-C321.jpg" /></a>W Izraelu - jedynym demokratycznym państwie na Bliskim Wschodzie - od 12 tygodni trwają masowe protesty przeciwko rządowym planom reformy wymiaru sprawiedliwości i ograniczenia uprawnień izraelskiego Sądu Najwyższego. Krajowe media w poniedziałek rano donosiły, że premier Benjamin Netanjahu miał ogłosić czasowe wstrzymanie prac nad forsowanymi przez niego zmianami. Do takich wniosków doszedł po spotkaniu szefów koalicji rządzącej. Wciąż jednak takiej zapowiedzi nie przedstawiono, a protesty w Izraelu przybierają na sile. Strajk głodowy...</p><br clear="all" />

## Dowódca wojsk lądowych Ukrainy w Bachmucie. Zaciekłe walki o miasto
 - [https://wydarzenia.interia.pl/zagranica/news-dowodca-wojsk-ladowych-ukrainy-w-bachmucie-zaciekle-walki-o-,nId,6680851](https://wydarzenia.interia.pl/zagranica/news-dowodca-wojsk-ladowych-ukrainy-w-bachmucie-zaciekle-walki-o-,nId,6680851)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 12:52:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-dowodca-wojsk-ladowych-ukrainy-w-bachmucie-zaciekle-walki-o-,nId,6680851"><img align="left" alt="Dowódca wojsk lądowych Ukrainy w Bachmucie. Zaciekłe walki o miasto " src="https://i.iplsc.com/dowodca-wojsk-ladowych-ukrainy-w-bachmucie-zaciekle-walki-o/000GY5XTGP5LL9HP-C321.jpg" /></a>Dowódca wojsk lądowych Sił Zbrojnych Ukrainy generał pułkownik Ołeksandr Syrski odwiedził Bachmut i miejsca najbardziej zaciętych walk. Według informacji przekazanych przez wojskowego sytuacja na froncie jest trudna, ale stabilna. - &quot;Trwa najintensywniejsza faza walk o Bachmut&quot; - cytuje generała Ukraińskie Wojskowe Centrum Mediów.</p><br clear="all" />

## Chojnice: Cieszył się prawem jazdy tylko kilka godzin
 - [https://wydarzenia.interia.pl/pomorskie/news-chojnice-cieszyl-sie-prawem-jazdy-tylko-kilka-godzin,nId,6680830](https://wydarzenia.interia.pl/pomorskie/news-chojnice-cieszyl-sie-prawem-jazdy-tylko-kilka-godzin,nId,6680830)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 12:48:49+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-chojnice-cieszyl-sie-prawem-jazdy-tylko-kilka-godzin,nId,6680830"><img align="left" alt="Chojnice: Cieszył się prawem jazdy tylko kilka godzin " src="https://i.iplsc.com/chojnice-cieszyl-sie-prawem-jazdy-tylko-kilka-godzin/000GY5NMPXHLME10-C321.jpg" /></a>Wyjątkową niefrasobliwością wykazał się 18-latek, który stracił prawo jazdy zaledwie kilka godzin po odbiorze dokumentu. Kierowca mercedesa znacznie przekroczył prędkość w terenie zabudowanym. </p><br clear="all" />

## Zaskakujące odkrycie u wybrzeży Galapagos. Znaleziono niezwykłe stworzenia
 - [https://wydarzenia.interia.pl/zagranica/news-zaskakujace-odkrycie-u-wybrzezy-galapagos-znaleziono-niezwyk,nId,6680826](https://wydarzenia.interia.pl/zagranica/news-zaskakujace-odkrycie-u-wybrzezy-galapagos-znaleziono-niezwyk,nId,6680826)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 12:28:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zaskakujace-odkrycie-u-wybrzezy-galapagos-znaleziono-niezwyk,nId,6680826"><img align="left" alt="Zaskakujące odkrycie u wybrzeży Galapagos. Znaleziono niezwykłe stworzenia" src="https://i.iplsc.com/zaskakujace-odkrycie-u-wybrzezy-galapagos-znaleziono-niezwyk/000GY5L89FCJORTS-C321.jpg" /></a>Amerykańscy biolodzy morscy natknęli się u wybrzeży Galapagos na tajemnicze stworzenia. Naukowcy opublikowali w mediach społecznościowych zdjęcia niezwykłego znaleziska. Badacze podkreślają, że trudno zidentyfikować konkretny gatunek, do którego mogą należeć nietypowe istoty.</p><br clear="all" />

## Zamach w Mariupolu. Szef rosyjskiej policji został ranny
 - [https://wydarzenia.interia.pl/zagranica/news-zamach-w-mariupolu-szef-rosyjskiej-policji-zostal-ranny,nId,6680799](https://wydarzenia.interia.pl/zagranica/news-zamach-w-mariupolu-szef-rosyjskiej-policji-zostal-ranny,nId,6680799)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 12:18:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zamach-w-mariupolu-szef-rosyjskiej-policji-zostal-ranny,nId,6680799"><img align="left" alt="Zamach w Mariupolu. Szef rosyjskiej policji został ranny" src="https://i.iplsc.com/zamach-w-mariupolu-szef-rosyjskiej-policji-zostal-ranny/000GY5O9224H3YL3-C321.jpg" /></a>W Mariupolu okupowanym przez Rosjan doszło do kolejnego zamachu. Tym razem za cel ataku obrano jednego z najważniejszych rosyjskich oficerów - szefa miejskiej policji Michaiła Moskwina, który został ranny. Do wybuchu doszło, gdy ten znajdował się kilka metrów od pojazdu. Atak zorganizował i przeprowadził ukraiński ruch partyzancki.</p><br clear="all" />

## Nieoficjalnie: Pozycja wicepremiera Henryka Kowalczyka zagrożona
 - [https://wydarzenia.interia.pl/kraj/news-nieoficjalnie-pozycja-wicepremiera-henryka-kowalczyka-zagroz,nId,6680720](https://wydarzenia.interia.pl/kraj/news-nieoficjalnie-pozycja-wicepremiera-henryka-kowalczyka-zagroz,nId,6680720)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 12:06:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nieoficjalnie-pozycja-wicepremiera-henryka-kowalczyka-zagroz,nId,6680720"><img align="left" alt="Nieoficjalnie: Pozycja wicepremiera Henryka Kowalczyka zagrożona" src="https://i.iplsc.com/nieoficjalnie-pozycja-wicepremiera-henryka-kowalczyka-zagroz/000GY5C4XFA61M1B-C321.jpg" /></a>Jak nieoficjalnie dowiedziała się Interia, pozycja wicepremiera oraz ministra rolnictwa i rozwoju wsi Henryka Kowalczyka jest zagrożona. Polityk może stracić posadę ze względu na liczne protesty rolników związane m.in. z importem ukraińskiego zboża do Polski. Wicepremier Kowalczyk ma jednak mocnych stronników. Jednym z nich jest była premier Beata Szydło i - jak słyszymy - PSL. Ci ostatni oficjalnie zaprzeczają.</p><br clear="all" />

## Burza po tekście Interii. Strzeżek: Platforma Czarnka najpewniej nigdy nie powstanie
 - [https://wydarzenia.interia.pl/kraj/news-burza-po-tekscie-interii-strzezek-platforma-czarnka-najpewni,nId,6680680](https://wydarzenia.interia.pl/kraj/news-burza-po-tekscie-interii-strzezek-platforma-czarnka-najpewni,nId,6680680)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 11:53:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burza-po-tekscie-interii-strzezek-platforma-czarnka-najpewni,nId,6680680"><img align="left" alt="Burza po tekście Interii. Strzeżek: Platforma Czarnka najpewniej nigdy nie powstanie" src="https://i.iplsc.com/burza-po-tekscie-interii-strzezek-platforma-czarnka-najpewni/000GY5GFLGJECJOR-C321.jpg" /></a>Politycy reagują na doniesienia Interii. Warta 29 mln złotych platforma MeduM, którą hucznie zapowiadał minister Czarnek, miała ruszyć 1 grudnia 2022 roku, a najpewniej nigdy nie powstanie - powiedział lider Młodej Polski Jan Strzeżek na konferencji pod Ministerstwem Edukacji i Nauki. W jego opinii działania PiS to &quot;patologia, z którą trzeba skończyć&quot;. Sprawę tego projektu finansowanego przez Narodowe Centrum Badań i Rozwoju ujawniła w poniedziałek rano Interia.</p><br clear="all" />

## Błażej Kmieciak zrezygnował z funkcji przewodniczącego Komisji ds. Pedofilii
 - [https://wydarzenia.interia.pl/kraj/news-blazej-kmieciak-zrezygnowal-z-funkcji-przewodniczacego-komis,nId,6680809](https://wydarzenia.interia.pl/kraj/news-blazej-kmieciak-zrezygnowal-z-funkcji-przewodniczacego-komis,nId,6680809)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 11:48:23+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-blazej-kmieciak-zrezygnowal-z-funkcji-przewodniczacego-komis,nId,6680809"><img align="left" alt="Błażej Kmieciak zrezygnował z funkcji przewodniczącego Komisji ds. Pedofilii" src="https://i.iplsc.com/blazej-kmieciak-zrezygnowal-z-funkcji-przewodniczacego-komis/000GY5OKIKECF7PW-C321.jpg" /></a>Błażej Kmieciak złożył rezygnację z funkcji przewodniczącego Państwowej Komisji ds. Pedofilii - przekazano na stronie Komisji. W swoim oświadczeniu Kmieciak wyjaśnił, że na stanowisku zostanie do 14 kwietnia, co jest związane z koniecznością jego udziału w &quot;standardowej kontroli Najwyższej Izby Kontroli, jaką Urząd Państwowej Komisji przechodzi w tym czasie&quot;.</p><br clear="all" />

## Premier o produkcji amunicji: Rada Ministrów przyjmie wieloletni program
 - [https://wydarzenia.interia.pl/kraj/news-premier-o-produkcji-amunicji-rada-ministrow-przyjmie-wielole,nId,6680798](https://wydarzenia.interia.pl/kraj/news-premier-o-produkcji-amunicji-rada-ministrow-przyjmie-wielole,nId,6680798)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 11:41:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-o-produkcji-amunicji-rada-ministrow-przyjmie-wielole,nId,6680798"><img align="left" alt="Premier o produkcji amunicji: Rada Ministrów przyjmie wieloletni program" src="https://i.iplsc.com/premier-o-produkcji-amunicji-rada-ministrow-przyjmie-wielole/000GY5K8I8K67FLO-C321.jpg" /></a>Rada Ministrów w ciągu kilku dni przyjmie specjalny wieloletni program, który będzie wspierał produkcję amunicji w różnych częściach kraju, w firmach prywatnych i państwowych - podkreślił premier Mateusz Morawiecki podczas konferencji w Zakładach Metalowe DEZAMET S.A., należących do Grupy Kapitałowej Polska Grupa Zbrojeniowa SA.</p><br clear="all" />

## 300 mln euro dla Polski na dozbrajanie. Morawiecki zapowiada
 - [https://wydarzenia.interia.pl/kraj/news-300-mln-euro-dla-polski-na-dozbrajanie-morawiecki-zapowiada,nId,6680776](https://wydarzenia.interia.pl/kraj/news-300-mln-euro-dla-polski-na-dozbrajanie-morawiecki-zapowiada,nId,6680776)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 11:34:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-300-mln-euro-dla-polski-na-dozbrajanie-morawiecki-zapowiada,nId,6680776"><img align="left" alt="300 mln euro dla Polski na dozbrajanie. Morawiecki zapowiada" src="https://i.iplsc.com/300-mln-euro-dla-polski-na-dozbrajanie-morawiecki-zapowiada/000867I9TDEV9L7B-C321.jpg" /></a>&quot;Wkrótce otrzymamy rekompensatę ok. 300 milionów euro, a Polska będzie największym beneficjentem unijnego funduszu na dozbrajanie&quot; - podkreślił w mediach społecznościowych Mateusz Morawiecki. Premier zaznaczył, że w miejsce broni przekazanej Ukrainie będzie można kupić &quot;nowocześniejszą broń oraz inwestować w polski przemysł zbrojeniowy&quot;. W poniedziałek Morawiecki ma złożyć wizytę w Zakładach Metalowych DEZAMET S.A.</p><br clear="all" />

## Napięcia w Izraelu. Odwołano rejsy z Lotniska Chopina
 - [https://wydarzenia.interia.pl/zagranica/news-napiecia-w-izraelu-odwolano-rejsy-z-lotniska-chopina,nId,6680711](https://wydarzenia.interia.pl/zagranica/news-napiecia-w-izraelu-odwolano-rejsy-z-lotniska-chopina,nId,6680711)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 11:16:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-napiecia-w-izraelu-odwolano-rejsy-z-lotniska-chopina,nId,6680711"><img align="left" alt="Napięcia w Izraelu. Odwołano rejsy z Lotniska Chopina" src="https://i.iplsc.com/napiecia-w-izraelu-odwolano-rejsy-z-lotniska-chopina/000GY55GWITMPM3I-C321.jpg" /></a>Z powodu demonstracji w Izraelu odwołano rejsy z Warszawy do stolicy tego kraju. W poniedziałek trwa także strajk ostrzegawczy w Niemczech. W związku z nim odwołano loty PLL LOT i Lufthansy do Niemiec. </p><br clear="all" />

## Dentysta na NFZ. Jakie zabiegi przysługują ci za darmo?
 - [https://wydarzenia.interia.pl/kraj/news-dentysta-na-nfz-jakie-zabiegi-przysluguja-ci-za-darmo,nId,6680739](https://wydarzenia.interia.pl/kraj/news-dentysta-na-nfz-jakie-zabiegi-przysluguja-ci-za-darmo,nId,6680739)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 11:09:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dentysta-na-nfz-jakie-zabiegi-przysluguja-ci-za-darmo,nId,6680739"><img align="left" alt="Dentysta na NFZ. Jakie zabiegi przysługują ci za darmo?" src="https://i.iplsc.com/dentysta-na-nfz-jakie-zabiegi-przysluguja-ci-za-darmo/0006MA9CDG7LHLJ0-C321.jpg" /></a>Regularne wizyty u dentysty zapobiegają problemom związanym z chorobami jamy ustnej. Najczęściej niestety decydujemy się na wizytę u dentysty, dopiero kiedy ból zęba staje się nieznośny. Przedstawiamy, z jakich świadczeń skorzystasz w gabinecie dentystycznym za darmo. </p><br clear="all" />

## Przełomowe badanie naukowców. Stworzyli myszy z komórek samców
 - [https://wydarzenia.interia.pl/zagranica/news-przelomowe-badanie-naukowcow-stworzyli-myszy-z-komorek-samco,nId,6680740](https://wydarzenia.interia.pl/zagranica/news-przelomowe-badanie-naukowcow-stworzyli-myszy-z-komorek-samco,nId,6680740)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 11:05:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-przelomowe-badanie-naukowcow-stworzyli-myszy-z-komorek-samco,nId,6680740"><img align="left" alt="Przełomowe badanie naukowców. Stworzyli myszy z komórek samców" src="https://i.iplsc.com/przelomowe-badanie-naukowcow-stworzyli-myszy-z-komorek-samco/000GY53DKJ2KS9XW-C321.jpg" /></a>Naukowcy przeprowadzili kolejne, nowatorskie badania. Udało się im stworzyć myszy z komórek samców. Z ich ogonów pobrano komórki skóry, które zostały przekształcone w komórki jajowe. Na świat przyszło jednak mało żywych myszy. Badacze mają jednak nadzieję, że za kilka lat będzie to również szansa na posiadanie dziecka przez ludzkie pary jednopłciowe.</p><br clear="all" />

## Miał leczyć koronawirusa. Ministerstwo zdecydowało, co z Remdesivirem
 - [https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-mial-leczyc-koronawirusa-ministerstwo-zdecydowalo-co-z-remde,nId,6680689](https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-mial-leczyc-koronawirusa-ministerstwo-zdecydowalo-co-z-remde,nId,6680689)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 10:43:43+00:00

<p><a href="https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-mial-leczyc-koronawirusa-ministerstwo-zdecydowalo-co-z-remde,nId,6680689"><img align="left" alt="Miał leczyć koronawirusa. Ministerstwo zdecydowało, co z Remdesivirem" src="https://i.iplsc.com/mial-leczyc-koronawirusa-ministerstwo-zdecydowalo-co-z-remde/000GY4ZJUYBM88HS-C321.jpg" /></a>Agencja Oceny Technologii Medycznych i Taryfikacji (AOTMiT) poddała analizie 10 międzynarodowych badań, dotyczących oceny skuteczności Remdesiviru, który miał pomagać w leczeniu zakażenia koronawirusem. Wyniki sprawiły, że resort zdrowia zdecydował, że nie będzie finansować zakupu leku ze środków publicznych. </p><br clear="all" />

## Mają cztery tygodnie letniego urlopu. W czym jeszcze tkwi sekret szczęścia Finów?
 - [https://wydarzenia.interia.pl/news-maja-cztery-tygodnie-letniego-urlopu-w-czym-jeszcze-tkwi-sek,nId,6680727](https://wydarzenia.interia.pl/news-maja-cztery-tygodnie-letniego-urlopu-w-czym-jeszcze-tkwi-sek,nId,6680727)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 10:36:01+00:00

<p><a href="https://wydarzenia.interia.pl/news-maja-cztery-tygodnie-letniego-urlopu-w-czym-jeszcze-tkwi-sek,nId,6680727"><img align="left" alt="Mają cztery tygodnie letniego urlopu. W czym jeszcze tkwi sekret szczęścia Finów?" src="https://i.iplsc.com/maja-cztery-tygodnie-letniego-urlopu-w-czym-jeszcze-tkwi-sek/000BIEACY2G49WR4-C321.jpg" /></a>Tutaj żyje się najlepiej! Finlandia już po raz szósty została uznana najszczęśliwszym krajem do życia. Co sprawia, że to właśnie w tym skandynawskim państwie ludziom wiedzie się najlepiej? Dlaczego Finowie - pomimo braku słońca w ciągu roku - czują się radośni i spełnieni? </p><br clear="all" />

## Kraków: Deweloper chce wybudować wielkie osiedle na terenie osuwiskowym
 - [https://wydarzenia.interia.pl/malopolskie/news-krakow-deweloper-chce-wybudowac-wielkie-osiedle-na-terenie-o,nId,6680657](https://wydarzenia.interia.pl/malopolskie/news-krakow-deweloper-chce-wybudowac-wielkie-osiedle-na-terenie-o,nId,6680657)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 10:04:59+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-krakow-deweloper-chce-wybudowac-wielkie-osiedle-na-terenie-o,nId,6680657"><img align="left" alt="Kraków: Deweloper chce wybudować wielkie osiedle na terenie osuwiskowym" src="https://i.iplsc.com/krakow-deweloper-chce-wybudowac-wielkie-osiedle-na-terenie-o/000GMLUH0DT2RO7X-C321.jpg" /></a>Deweloper planuje wybudować blisko 80 bloków na terenie dawnej kopalni iłów Zesławice w Krakowie. To dalekosiężne plany, ponieważ spółka musi zdobyć niezbędną dokumentację pozwalającą na rozpoczęcie prac. Dodatkowo pokopalniany obszar to teren osuwiskowy, podmokły i wymagający rekultywacji. Pomimo tego inwestor wyburzył część znajdujących się w okolicy ogródków działkowych, choć nie miał na to urzędniczej zgody. Sprawę bada nadzór budowlany. </p><br clear="all" />

## Celowo wjechał w motocyklistę i wszystko nagrał. Absurdalne tłumaczenie
 - [https://wydarzenia.interia.pl/zagranica/news-celowo-wjechal-w-motocykliste-i-wszystko-nagral-absurdalne-t,nId,6680623](https://wydarzenia.interia.pl/zagranica/news-celowo-wjechal-w-motocykliste-i-wszystko-nagral-absurdalne-t,nId,6680623)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 09:47:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-celowo-wjechal-w-motocykliste-i-wszystko-nagral-absurdalne-t,nId,6680623"><img align="left" alt="Celowo wjechał w motocyklistę i wszystko nagrał. Absurdalne tłumaczenie" src="https://i.iplsc.com/celowo-wjechal-w-motocykliste-i-wszystko-nagral-absurdalne-t/000GY4RRBT6C83U0-C321.jpg" /></a>Graham Robinson wczuł się w wyścig z motocyklistą, a chwilę potem celowo go potrącił. Na nic zdały się słowa zakłopotanego mężczyzny przed sądem, który tłumaczył się &quot;trudnym czasem w życiu&quot;. Brytyjczyk został skazany na osiem miesięcy więzienia. 
</p><br clear="all" />

## USA: Nauczycielka uwodziła nieletnich. Chciała, by wysyłali nagie zdjęcia
 - [https://wydarzenia.interia.pl/zagranica/news-usa-nauczycielka-uwodzila-nieletnich-chciala-by-wysylali-nag,nId,6680610](https://wydarzenia.interia.pl/zagranica/news-usa-nauczycielka-uwodzila-nieletnich-chciala-by-wysylali-nag,nId,6680610)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 09:34:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-nauczycielka-uwodzila-nieletnich-chciala-by-wysylali-nag,nId,6680610"><img align="left" alt="USA: Nauczycielka uwodziła nieletnich. Chciała, by wysyłali nagie zdjęcia" src="https://i.iplsc.com/usa-nauczycielka-uwodzila-nieletnich-chciala-by-wysylali-nag/000GY4QZ2PFXIP0V-C321.jpg" /></a>Nauczycielka z USA wysyłała do nieletnich uczniów wiadomości z podtekstem seksualnym. Kobieta nawiązywała z nimi kontakt poprzez media społecznościowe i wysyłała chłopcom nagie zdjęcia, a w zamian prosiła o takie same fotografie. Sprawa wyszła na jaw, gdy jedna z uczennic powiedziała o tym matce.</p><br clear="all" />

## Bus przewożący dzieci zderzył się z osobówką. Jedna osoba w szpitalu
 - [https://wydarzenia.interia.pl/malopolskie/news-bus-przewozacy-dzieci-zderzyl-sie-z-osobowka-jedna-osoba-w-s,nId,6680637](https://wydarzenia.interia.pl/malopolskie/news-bus-przewozacy-dzieci-zderzyl-sie-z-osobowka-jedna-osoba-w-s,nId,6680637)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 09:06:55+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-bus-przewozacy-dzieci-zderzyl-sie-z-osobowka-jedna-osoba-w-s,nId,6680637"><img align="left" alt="Bus przewożący dzieci zderzył się z osobówką. Jedna osoba w szpitalu" src="https://i.iplsc.com/bus-przewozacy-dzieci-zderzyl-sie-z-osobowka-jedna-osoba-w-s/000GY4P4XUJ3U1M3-C321.jpg" /></a>W poniedziałek w Pogórskiej Woli (woj. małopolskie) doszło do zderzenia busa przewożącego dzieci z samochodem osobowym. Jak ustaliła Interia, w wyniku wypadku opiekunka trafiła do szpitala.</p><br clear="all" />

## Nie żyje aktor Piotr Wysocki. Prokuratura zapowiada działania
 - [https://wydarzenia.interia.pl/lubelskie/news-nie-zyje-aktor-piotr-wysocki-prokuratura-zapowiada-dzialania,nId,6680586](https://wydarzenia.interia.pl/lubelskie/news-nie-zyje-aktor-piotr-wysocki-prokuratura-zapowiada-dzialania,nId,6680586)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 08:57:15+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-nie-zyje-aktor-piotr-wysocki-prokuratura-zapowiada-dzialania,nId,6680586"><img align="left" alt="Nie żyje aktor Piotr Wysocki. Prokuratura zapowiada działania" src="https://i.iplsc.com/nie-zyje-aktor-piotr-wysocki-prokuratura-zapowiada-dzialania/000GY4GL9K4TSI8M-C321.jpg" /></a>Piotr Wysocki nie żyje - poinformował jego syn. 87-letni aktor najprawdopodobniej zginął w tragicznych okolicznościach w pożarze domu w miejscowości Trzciniec (woj. lubelskie). W rozmowie z Interią prok. Agnieszka Kępka poinformowała o działaniu służb w sprawie.</p><br clear="all" />

## Rosyjski szpieg zatrzymany w Polsce. Służby: Ujawnił szczegóły
 - [https://wydarzenia.interia.pl/pomorskie/news-rosyjski-szpieg-zatrzymany-w-polsce-sluzby-ujawnil-szczegoly,nId,6680594](https://wydarzenia.interia.pl/pomorskie/news-rosyjski-szpieg-zatrzymany-w-polsce-sluzby-ujawnil-szczegoly,nId,6680594)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 08:31:10+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-rosyjski-szpieg-zatrzymany-w-polsce-sluzby-ujawnil-szczegoly,nId,6680594"><img align="left" alt="Rosyjski szpieg zatrzymany w Polsce. Służby: Ujawnił szczegóły " src="https://i.iplsc.com/rosyjski-szpieg-zatrzymany-w-polsce-sluzby-ujawnil-szczegoly/000GY4F4OXME6KEC-C321.jpg" /></a>Jak poinformowały służby, zatrzymano w Polsce cudzoziemca, który jest podejrzany o działalność szpiegowską na rzecz Rosji. Grozi mu do 10 lat więzienia. </p><br clear="all" />

## Wyrzucił psa i uciekł. Zwierzę uratował policjant
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-wyrzucil-psa-i-uciekl-zwierze-uratowal-policjant,nId,6680597](https://wydarzenia.interia.pl/swietokrzyskie/news-wyrzucil-psa-i-uciekl-zwierze-uratowal-policjant,nId,6680597)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 08:25:50+00:00

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-wyrzucil-psa-i-uciekl-zwierze-uratowal-policjant,nId,6680597"><img align="left" alt="Wyrzucił psa i uciekł. Zwierzę uratował policjant" src="https://i.iplsc.com/wyrzucil-psa-i-uciekl-zwierze-uratowal-policjant/000GY4GDW8FG0M4Q-C321.jpg" /></a>46-latek wyrzucił psa z samochodu i szybko odjechał. Całe zajście miało miejsce obok domu jednego ze świętokrzyskich policjantów, który szybko wybiegł z domu i nagrał uciekającego hondą mężczyznę. Funkcjonariusze dotarli do nieodpowiedzialnego właściciela i ukarali go. Uratowany pies trafił z kolei pod opiekę weterynarza.</p><br clear="all" />

## Szpiegował dla Rosji. Jest oskarżenie od amerykańskiej prokuratury
 - [https://wydarzenia.interia.pl/zagranica/news-szpiegowal-dla-rosji-jest-oskarzenie-od-amerykanskiej-prokur,nId,6680538](https://wydarzenia.interia.pl/zagranica/news-szpiegowal-dla-rosji-jest-oskarzenie-od-amerykanskiej-prokur,nId,6680538)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 08:01:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szpiegowal-dla-rosji-jest-oskarzenie-od-amerykanskiej-prokur,nId,6680538"><img align="left" alt="Szpiegował dla Rosji. Jest oskarżenie od amerykańskiej prokuratury " src="https://i.iplsc.com/szpiegowal-dla-rosji-jest-oskarzenie-od-amerykanskiej-prokur/000GY42HPVC14H57-C321.jpg" /></a>Amerykańska prokuratura zarzuca mu kradzież tożsamości, a także szpiegowanie na rzecz Rosji podczas jego pobytu w USA. Jednocześnie mężczyzna odsiaduje inny wyrok w Brazylii. Chodzi o Siergieja Czerkasowa, który zatrzymany został w zeszłym roku na terenie Holandii.</p><br clear="all" />

## Ziobryści bronią górnictwa. Woś uderza w Tuska: My te kłamstwa odkręcimy
 - [https://wydarzenia.interia.pl/slaskie/news-ziobrysci-bronia-gornictwa-wos-uderza-w-tuska-my-te-klamstwa,nId,6680572](https://wydarzenia.interia.pl/slaskie/news-ziobrysci-bronia-gornictwa-wos-uderza-w-tuska-my-te-klamstwa,nId,6680572)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 07:52:10+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-ziobrysci-bronia-gornictwa-wos-uderza-w-tuska-my-te-klamstwa,nId,6680572"><img align="left" alt="Ziobryści bronią górnictwa. Woś uderza w Tuska: My te kłamstwa odkręcimy" src="https://i.iplsc.com/ziobrysci-bronia-gornictwa-wos-uderza-w-tuska-my-te-klamstwa/000GY42ABOILFCGB-C321.jpg" /></a>Będziemy bronić górnictwa jako strategicznej gałęzi polskiego przemysłu – zadeklarował w poniedziałek w Jastrzębiu-Zdroju lider Solidarnej Polski, minister sprawiedliwości Zbigniew Ziobro. Polityk zarzucił Donaldowi Tuskowi hipokryzję - przypomniał strzały z policyjnej broni gładkolufowej, które w 2015 roku padły w kierunku protestujących górników. - Tusk nie będzie robił w ciula Ślązaków - dodał wiceminister sprawiedliwości Michał Woś. </p><br clear="all" />

## Eksplozja Nord Stream. Rosyjski dyplomata o "odszkodowaniach"
 - [https://wydarzenia.interia.pl/zagranica/news-eksplozja-nord-stream-rosyjski-dyplomata-o-odszkodowaniach,nId,6680548](https://wydarzenia.interia.pl/zagranica/news-eksplozja-nord-stream-rosyjski-dyplomata-o-odszkodowaniach,nId,6680548)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 07:27:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-eksplozja-nord-stream-rosyjski-dyplomata-o-odszkodowaniach,nId,6680548"><img align="left" alt="Eksplozja Nord Stream. Rosyjski dyplomata o &quot;odszkodowaniach&quot;" src="https://i.iplsc.com/eksplozja-nord-stream-rosyjski-dyplomata-o-odszkodowaniach/000GY3X07KBT7K9K-C321.jpg" /></a>Moskwa może domagać się odszkodowania za szkody spowodowane ubiegłorocznymi wybuchami w gazociągu Nord Stream - podała w poniedziałek agencja informacyjna RIA Novosti, powołując się na rosyjskiego dyplomatę.</p><br clear="all" />

## Miliony papierosów, o których nikt miał nie wiedzieć. CBŚP zlikwidowało fabrykę
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-miliony-papierosow-o-ktorych-nikt-mial-nie-wiedziec-cbsp-zli,nId,6680549](https://wydarzenia.interia.pl/dolnoslaskie/news-miliony-papierosow-o-ktorych-nikt-mial-nie-wiedziec-cbsp-zli,nId,6680549)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 07:19:15+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-miliony-papierosow-o-ktorych-nikt-mial-nie-wiedziec-cbsp-zli,nId,6680549"><img align="left" alt="Miliony papierosów, o których nikt miał nie wiedzieć. CBŚP zlikwidowało fabrykę" src="https://i.iplsc.com/miliony-papierosow-o-ktorych-nikt-mial-nie-wiedziec-cbsp-zli/000GY3U3OPKPT2TW-C321.jpg" /></a>Wygłuszone pomieszczenie, pokoje socjalne i agregat prądotwórczy - w taki sposób próbowano ukryć nielegalną fabrykę papierosów w powiecie bolesławieckim. Mimo starań, funkcjonariusze CBŚP wpadli na trop, odkryli wytwórnię i zatrzymali cztery osoby. Zabezpieczono miliony papierosów, tony tytoniu i półprodukty. Gdyby wyroby tytoniowe trafiły na rynek, Skarb Państwa straciłby blisko 18 mln złotych. </p><br clear="all" />

## Japonia: Mężczyźni boją się iść na tacierzyński. "Czują strach i pesymizm"
 - [https://wydarzenia.interia.pl/zagranica/news-japonia-mezczyzni-boja-sie-isc-na-tacierzynski-czuja-strach-,nId,6680517](https://wydarzenia.interia.pl/zagranica/news-japonia-mezczyzni-boja-sie-isc-na-tacierzynski-czuja-strach-,nId,6680517)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 07:05:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-japonia-mezczyzni-boja-sie-isc-na-tacierzynski-czuja-strach-,nId,6680517"><img align="left" alt="Japonia: Mężczyźni boją się iść na tacierzyński. &quot;Czują strach i pesymizm&quot;" src="https://i.iplsc.com/japonia-mezczyzni-boja-sie-isc-na-tacierzynski-czuja-strach/000GY3VJDRO7VTKB-C321.jpg" /></a>Japońscy mężczyźni boją się korzystać z urlopów ojcowskich, ponieważ obawiają się, że zostaną zdegradowani i pozbawieni możliwości zdobycia awansu w pracy. W związku z krytycznie niskim wskaźnikiem urodzeń rząd premiera Fumio Kishidy zapowiedział &quot;siedmioletni plan ostatniej szansy na odwrócenie sytuacji&quot;. Eksperci podkreślają, że polityka rządu jest słuszna, ale problem zakorzeniony jest głęboko w kulturze i obawach młodych Japończyków.</p><br clear="all" />

## Los Angeles: Pasażer chciał wyjść z samolotu. Wystrzeliła zjeżdżalnia
 - [https://wydarzenia.interia.pl/zagranica/news-los-angeles-pasazer-chcial-wyjsc-z-samolotu-wystrzelila-zjez,nId,6680508](https://wydarzenia.interia.pl/zagranica/news-los-angeles-pasazer-chcial-wyjsc-z-samolotu-wystrzelila-zjez,nId,6680508)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 06:31:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-los-angeles-pasazer-chcial-wyjsc-z-samolotu-wystrzelila-zjez,nId,6680508"><img align="left" alt="Los Angeles: Pasażer chciał wyjść z samolotu. Wystrzeliła zjeżdżalnia " src="https://i.iplsc.com/los-angeles-pasazer-chcial-wyjsc-z-samolotu-wystrzelila-zjez/000GY3MY6KFCII3U-C321.jpg" /></a>Nietypowe zdarzenie na lotnisku w USA. &quot;Lot Delta 1714 z Los Angeles do Seattle wrócił do bramki z powodu niesfornego pasażera&quot; - poinformowały w oświadczeniu linie Delta Air Lines. Mężczyzna pociągnął za klamkę drzwi awaryjnych i tym samym uruchomił zjeżdżalnię, po której następnie zjechał. Po całej sytuacji został zabrany do szpitala psychiatrycznego. </p><br clear="all" />

## Wyszedł z więzienia, zabił bezdomnego. Robert B. z wyrokiem
 - [https://wydarzenia.interia.pl/slaskie/news-wyszedl-z-wiezienia-zabil-bezdomnego-robert-b-z-wyrokiem,nId,6680505](https://wydarzenia.interia.pl/slaskie/news-wyszedl-z-wiezienia-zabil-bezdomnego-robert-b-z-wyrokiem,nId,6680505)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 06:16:50+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-wyszedl-z-wiezienia-zabil-bezdomnego-robert-b-z-wyrokiem,nId,6680505"><img align="left" alt="Wyszedł z więzienia, zabił bezdomnego. Robert B. z wyrokiem" src="https://i.iplsc.com/wyszedl-z-wiezienia-zabil-bezdomnego-robert-b-z-wyrokiem/000D1V17NILISH0J-C321.jpg" /></a>Jest prawomocny wyrok dla Roberta B., który w 2019 roku, po wyjściu z więzienia, zabił w Będzinie bezdomnego. W pierwszej instancji mężczyzna usłyszał wyrok 15 lat pozbawienia wolności. Po kasacji prokuratury Sąd Apelacyjny w Katowicach zaostrzył wyrok do 25 lat więzienia.</p><br clear="all" />

## Pogoda przyszykowała niespodziankę. Wróci śnieg, mróz i silny wiatr
 - [https://wydarzenia.interia.pl/kraj/news-pogoda-przyszykowala-niespodzianke-wroci-snieg-mroz-i-silny-,nId,6680506](https://wydarzenia.interia.pl/kraj/news-pogoda-przyszykowala-niespodzianke-wroci-snieg-mroz-i-silny-,nId,6680506)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 05:45:54+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogoda-przyszykowala-niespodzianke-wroci-snieg-mroz-i-silny-,nId,6680506"><img align="left" alt="Pogoda przyszykowała niespodziankę. Wróci śnieg, mróz i silny wiatr" src="https://i.iplsc.com/pogoda-przyszykowala-niespodzianke-wroci-snieg-mroz-i-silny/000GY3JDP977EFWC-C321.jpg" /></a>Pogoda znów nas zaskoczy. Wydawać by się mogło, że na dobre pożegnaliśmy się z zimą i możemy cieszyć się wyższymi temperaturami. Niestety, zima nie powiedziała jeszcze ostatniego słowa i czeka nas powrót opadów śniegu i śniegu z deszczem. W górach może pojawić się silny mróz, a wiatr osiągnie prędkość nawet do 120 km/h.</p><br clear="all" />

## Minister obrony z dymisją. Izrael protestuje, starcia pod domem premiera
 - [https://wydarzenia.interia.pl/zagranica/news-minister-obrony-z-dymisja-izrael-protestuje-starcia-pod-dome,nId,6680497](https://wydarzenia.interia.pl/zagranica/news-minister-obrony-z-dymisja-izrael-protestuje-starcia-pod-dome,nId,6680497)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 05:30:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-minister-obrony-z-dymisja-izrael-protestuje-starcia-pod-dome,nId,6680497"><img align="left" alt="Minister obrony z dymisją. Izrael protestuje, starcia pod domem premiera" src="https://i.iplsc.com/minister-obrony-z-dymisja-izrael-protestuje-starcia-pod-dome/000GY3J2GEPBHGW6-C321.jpg" /></a>W niedzielę wieczorem w Tel Awiwie wybuchły masowe protesty po tym, premier Benjamin Netanjahu zwolnił ministra obrony Yoava Gallanta. Minister sprzeciwiał się planowanym zmianom w sądownictwie. Rozwścieczony tłum wyszedł na ulice. Do starć z policją doszło m.in. pod domem premiera Netanjahu.</p><br clear="all" />

## Czarnek rzucił wyzwanie Netflixowi i TikTokowi. Falstart pomysłu ministra
 - [https://wydarzenia.interia.pl/kraj/news-czarnek-rzucil-wyzwanie-netflixowi-i-tiktokowi-falstart-pomy,nId,6675068](https://wydarzenia.interia.pl/kraj/news-czarnek-rzucil-wyzwanie-netflixowi-i-tiktokowi-falstart-pomy,nId,6675068)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 04:58:25+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-czarnek-rzucil-wyzwanie-netflixowi-i-tiktokowi-falstart-pomy,nId,6675068"><img align="left" alt="Czarnek rzucił wyzwanie Netflixowi i TikTokowi. Falstart pomysłu ministra" src="https://i.iplsc.com/czarnek-rzucil-wyzwanie-netflixowi-i-tiktokowi-falstart-pomy/000GXWWV35HYHJ8H-C321.jpg" /></a>MeduM, czyli platforma łącząca zalety Netflixa i TikToka, miała być hitem dla polskiej młodzieży, tymczasem już na starcie projekt notuje poważną wpadkę. W tle konkurs w Narodowego Centrum Badań i Rozwoju za 29 mln zł, wspólnik kuzyna Jarosława Kaczyńskiego i duże opóźnienia. Filmy, jeśli powstaną, najprawdopodobniej będzie można zobaczyć dopiero w przyszłym roku.</p><br clear="all" />

## Potężny wypadek w Niemczech. Trzy porsche w drzazgach, są ofiary
 - [https://wydarzenia.interia.pl/zagranica/news-potezny-wypadek-w-niemczech-trzy-porsche-w-drzazgach-sa-ofia,nId,6680501](https://wydarzenia.interia.pl/zagranica/news-potezny-wypadek-w-niemczech-trzy-porsche-w-drzazgach-sa-ofia,nId,6680501)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 04:47:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-potezny-wypadek-w-niemczech-trzy-porsche-w-drzazgach-sa-ofia,nId,6680501"><img align="left" alt="Potężny wypadek w Niemczech. Trzy porsche w drzazgach, są ofiary" src="https://i.iplsc.com/potezny-wypadek-w-niemczech-trzy-porsche-w-drzazgach-sa-ofia/000GY3IXNKXXXXVJ-C321.jpg" /></a>Tragiczny wypadek w Niemczech na autostradzie A3 w rejonie Kolonii. Jak informują lokalne media, zderzyły się tam trzy samochody porsche. W wyniku odniesionych obrażeń zginęły cztery osoby. To obywatele Holandii.</p><br clear="all" />

## Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270532](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270532)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 03:32:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270532"><img align="left" alt="Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo/000GY3FW6URB9D2A-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270624](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270624)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 03:32:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270624"><img align="left" alt="Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo/000GY3FW6URB9D2A-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270732](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270732)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 03:32:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270732"><img align="left" alt="Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo/000GY3FW6URB9D2A-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270822](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270822)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 03:32:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270822"><img align="left" alt="Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo/000GY3FW6URB9D2A-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270933](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270933)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-03-27 03:32:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/na-zywo-wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo,nzId,3971,akt,270933"><img align="left" alt="Wojna w Ukrainie. 397. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-397-dzien-inwazji-rosji-relacja-na-zywo/000GY3FW6URB9D2A-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo.</p><br clear="all" />

