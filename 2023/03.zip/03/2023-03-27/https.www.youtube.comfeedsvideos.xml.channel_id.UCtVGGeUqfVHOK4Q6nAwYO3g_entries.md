# Source:LaterClips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g, language:en-US

## Creators Should Pay Attention...
 - [https://www.youtube.com/watch?v=Gf_J2PBTcJc](https://www.youtube.com/watch?v=Gf_J2PBTcJc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 22:00:05+00:00

Clip from Lew Later (It's Getting Out of Hand...) - https://youtube.com/live/tZ3a_uukNSg

## Apple's Watch Patent Could Be a Very Bad Idea
 - [https://www.youtube.com/watch?v=GJJ88CPUbcA](https://www.youtube.com/watch?v=GJJ88CPUbcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 20:00:04+00:00

Clip from Lew Later (TikTok Wasn't Prepared) - https://youtube.com/live/QTaj-e6UNEs

## Tesla Did What Apple Couldn't Do
 - [https://www.youtube.com/watch?v=VTwET7YtV6o](https://www.youtube.com/watch?v=VTwET7YtV6o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 18:00:21+00:00

Clip from Lew Later (It's Getting Out of Hand...) - https://youtube.com/live/tZ3a_uukNSg

## Is This The 8th Wonder?
 - [https://www.youtube.com/watch?v=Lc0-9tgMl3U](https://www.youtube.com/watch?v=Lc0-9tgMl3U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 16:00:20+00:00

Clip from Lew Later (It's Getting Out of Hand...) - https://youtube.com/live/tZ3a_uukNSg

## Horrific Accident Caught on Video
 - [https://www.youtube.com/watch?v=noqN9PomZos](https://www.youtube.com/watch?v=noqN9PomZos)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 14:00:25+00:00

Clip from Lew Later (It's Getting Out of Hand...) - https://youtube.com/live/tZ3a_uukNSg

## Is Tesla Cybertruck a Truck?
 - [https://www.youtube.com/watch?v=Px-6aByAnQs](https://www.youtube.com/watch?v=Px-6aByAnQs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 12:00:29+00:00

Clip from Lew Later (This Could Be Very Good Or Very Bad...) - https://youtube.com/live/EwWnVfB6tRk

## 3D-Printing Has Reached Another Level...
 - [https://www.youtube.com/watch?v=imoCfjkMZAM](https://www.youtube.com/watch?v=imoCfjkMZAM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 12:00:27+00:00

Clip from Lew Later (It's Getting Out of Hand...) - https://youtube.com/live/tZ3a_uukNSg

## Ford's Awesome New EV is Depressing...
 - [https://www.youtube.com/watch?v=LlymIvNYAZY](https://www.youtube.com/watch?v=LlymIvNYAZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 10:00:13+00:00

Clip from Lew Later (This Could Be Very Good Or Very Bad...) - https://youtube.com/live/EwWnVfB6tRk

## Big Brands Gives AI a Try..
 - [https://www.youtube.com/watch?v=PZOTGECxHM8](https://www.youtube.com/watch?v=PZOTGECxHM8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 08:00:15+00:00

Clip from Lew Later (This Could Be Very Good Or Very Bad...) - https://youtube.com/live/EwWnVfB6tRk

## Unsettling AI-Generated Video Has People Talking...
 - [https://www.youtube.com/watch?v=GY1P5EiIKWA](https://www.youtube.com/watch?v=GY1P5EiIKWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 06:00:07+00:00

Clip from Lew Later (This Could Be Very Good Or Very Bad...) - https://youtube.com/live/EwWnVfB6tRk

## AI Can't Pull This Off...
 - [https://www.youtube.com/watch?v=cThwA3b1Twc](https://www.youtube.com/watch?v=cThwA3b1Twc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 04:00:16+00:00

Clip from Lew Later (This Could Be Very Good Or Very Bad...) - https://youtube.com/live/EwWnVfB6tRk

## Google Sent an Ominous Letter To CEO Sundar Pichai
 - [https://www.youtube.com/watch?v=JxKm8G4gu2E](https://www.youtube.com/watch?v=JxKm8G4gu2E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 02:00:09+00:00

Clip from Lew Later (Apple Should Take Note...) - https://youtube.com/live/nhIKHSuaw6I

## Look Closer at That Puddle of Water...
 - [https://www.youtube.com/watch?v=rdH1D0n6tU0](https://www.youtube.com/watch?v=rdH1D0n6tU0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-03-27 00:00:14+00:00

Clip from Lew Later (Apple Should Take Note...) - https://youtube.com/live/nhIKHSuaw6I

