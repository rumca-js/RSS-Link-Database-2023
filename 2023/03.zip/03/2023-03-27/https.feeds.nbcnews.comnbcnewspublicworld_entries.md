# Source:NBC world, URL:https://feeds.nbcnews.com/nbcnews/public/world, language:en-US

## Netanyahu: Israel ‘on a path of dangerous collision’ following mass protests
 - [https://www.nbcnews.com/video/netanyahu-says-israel-on-a-path-of-dangerous-collision-following-mass-protests-166934085904](https://www.nbcnews.com/video/netanyahu-says-israel-on-a-path-of-dangerous-collision-following-mass-protests-166934085904)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 20:18:57+00:00

In an address to the nation following widespread protests, Israeli Prime Minister Benjamin Netanyahu announced he would delay his controversial judiciary overhaul.

## Defying expectations, Cuba says their legislative elections had strong turnout
 - [https://www.nbcnews.com/news/latino/cuba-says-legislative-elections-strong-turnout-rcna76826](https://www.nbcnews.com/news/latino/cuba-says-legislative-elections-strong-turnout-rcna76826)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 19:55:15+00:00

Cuban government officials say over 75% of eligible voters cast ballots Sunday in the legislative election despite expectations of lower voter turnout.

## Netanyahu delays judiciary overhaul after mass protests
 - [https://www.nbcnews.com/now/video/netanyahu-delays-judiciary-overhaul-after-mass-protests-166922821923](https://www.nbcnews.com/now/video/netanyahu-delays-judiciary-overhaul-after-mass-protests-166922821923)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 18:52:05+00:00

Israeli Prime Minister Benjamin Netanyahu agreed to pause a plan to overhaul the country’s judicial system until the next parliament session after widespread protests and worker strikes shut the country down. NBC News’ Josh Lederman reports why Netanyahu changed course and why his critics are saying the reforms are related to his corruption charges.

## Ticketmaster Mexico avoids fines over Bad Bunny concert tickets screwup
 - [https://www.nbcnews.com/news/latino/ticketmaster-mexico-avoids-fines-bad-bunny-concert-tickets-screwup-rcna76817](https://www.nbcnews.com/news/latino/ticketmaster-mexico-avoids-fines-bad-bunny-concert-tickets-screwup-rcna76817)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 16:46:12+00:00

Ticketmaster Mexico is not paying any fines after more than 2,000 fans who bought tickets to attend Bad Bunny’s concert in Estadio Azteca in December were denied entrance.

## Evidence that Libyan EU-backed forces committed crimes against humanity, U.N.-backed probe alleges
 - [https://www.nbcnews.com/news/world/evidence-libyan-eu-backed-forces-committed-crimes-humanity-un-backed-i-rcna76791](https://www.nbcnews.com/news/world/evidence-libyan-eu-backed-forces-committed-crimes-humanity-un-backed-i-rcna76791)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 15:09:59+00:00

U.N.-backed human rights experts said Monday there is evidence that crimes against humanity have been committed against Libyans and migrants in Libya, including women being forced into sexual slavery.

## Bystanders to demonstrators: Teens tell how they joined huge French protests
 - [https://www.nbcnews.com/news/world/bystanders-demonstrators-teens-tell-joined-french-protests-rcna76761](https://www.nbcnews.com/news/world/bystanders-demonstrators-teens-tell-joined-french-protests-rcna76761)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 13:29:17+00:00

French President Emmanuel Macron ignited a firestorm of anger with unpopular pension reforms that  push the legal retirement age from 62 to 64.

## Is the David porn? Come see, Italians tell Florida parents
 - [https://www.nbcnews.com/news/world/david-porn-come-see-italians-tell-florida-parents-rcna76762](https://www.nbcnews.com/news/world/david-porn-come-see-italians-tell-florida-parents-rcna76762)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 12:41:11+00:00

The Florence museum housing Michelangelo’s Renaissance masterpiece the David has invited parents and students from a Florida charter school to visit after complaints about a lesson featuring the statue forced the principal to resign.

## Amid strained U.S. ties, China finds unlikely friend in Utah
 - [https://www.nbcnews.com/politics/politics-news/strained-us-ties-china-finds-unlikely-friend-utah-rcna76776](https://www.nbcnews.com/politics/politics-news/strained-us-ties-china-finds-unlikely-friend-utah-rcna76776)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 12:11:44+00:00

China’s campaign to win friends and influence policy has blossomed in Utah, a religious, conservative state with few obvious ties to the most powerful communist country.

## Prince Harry in surprise London appearance at high-profile privacy case
 - [https://www.nbcnews.com/news/world/prince-harry-surprise-london-privacy-case-daily-mail-associated-rcna76763](https://www.nbcnews.com/news/world/prince-harry-surprise-london-privacy-case-daily-mail-associated-rcna76763)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 10:34:04+00:00

Prince Harry arrived at the Royal Courts of Justice in London Monday for the first hearing in a high-profile privacy case against a major British newspaper group.

## Watch: Prince Harry arrives at London court for privacy case hearing
 - [https://www.nbcnews.com/video/prince-harry-arrives-at-london-court-for-privacy-case-hearing-166882373886](https://www.nbcnews.com/video/prince-harry-arrives-at-london-court-for-privacy-case-hearing-166882373886)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 10:13:55+00:00

Prince Harry arrived at a London court as the lawyer for Associated Newspapers prepared to ask a judge to toss out lawsuits by the prince, Elton John and several other celebrities who allege phone tapping and other invasions of privacy by the publisher of the Daily Mail tabloid.

## Israel in chaos as workers hold general strike over Netanyahu's judicial reforms
 - [https://www.nbcnews.com/news/world/netanyahu-israel-judicial-reforms-engulf-gallant-protests-rcna76759](https://www.nbcnews.com/news/world/netanyahu-israel-judicial-reforms-engulf-gallant-protests-rcna76759)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 09:37:26+00:00

Hundreds of thousands of Israeli stopped working on Monday to protest Prime Minister Benjamin Netanyahu's unprecedented plans to reform the country’s judicial system, paralyzing the country.

## Huge protests in Israel 'force Netanyahu to pause judicial reforms'
 - [https://www.nbcnews.com/video/huge-protests-in-israel-force-netanyahu-to-pause-judicial-reforms-166880325752](https://www.nbcnews.com/video/huge-protests-in-israel-force-netanyahu-to-pause-judicial-reforms-166880325752)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 07:16:54+00:00

Israeli Prime Minister Benjamin Netanyahu is expected to pause an overhaul of the judicial system after massive protests.

## North Korea test-fires 2 more missiles as U.S. sends carrier
 - [https://www.nbcnews.com/news/world/north-korea-test-fires-2-missiles-us-sends-carrier-rcna76755](https://www.nbcnews.com/news/world/north-korea-test-fires-2-missiles-us-sends-carrier-rcna76755)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 02:23:29+00:00

North Korea fired two short-range ballistic missiles as the United States moved an aircraft carrier strike group to neighboring waters for military exercises.

## Mass protests erupt in Israel after Netanyahu fires defense chief
 - [https://www.nbcnews.com/news/world/mass-protests-erupt-israel-netanyahu-fires-defense-chief-rcna76753](https://www.nbcnews.com/news/world/mass-protests-erupt-israel-netanyahu-fires-defense-chief-rcna76753)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-03-27 00:48:07+00:00

Tens of thousands of Israelis poured into the streets   on Sunday night  after Prime Minister Benjamin Netanyahu abruptly fired his defense minister for challenging the Israeli leader’s judicial overhaul plan.

