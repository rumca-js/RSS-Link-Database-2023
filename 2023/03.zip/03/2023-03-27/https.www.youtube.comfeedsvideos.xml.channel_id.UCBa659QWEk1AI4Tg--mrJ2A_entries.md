# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## I climbed inside a giant robotic parking garage
 - [https://www.youtube.com/watch?v=voYdl7IFZsM](https://www.youtube.com/watch?v=voYdl7IFZsM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2023-03-27 15:00:44+00:00

I was going to film a video about a robot bicycle park. And then GIKEN, the company who built it, said: you know we do this for cars as well, right? ■ More details: https://www.giken.com/en/products/automated-parking-facilities/

Local producer: Yasuharu Matsuno at Mind Architect
Camera: Julian Domanski
Editor: Michelle Martin https://twitter.com/mrsmmartin

I'm a bit worried that this comes across as an advert. It's not — I reached out to the team at GIKEN, they had no editorial control, and no money changed hands. (Although they did, of course, go through all the paperwork required to let me climb into their giant robot parking garage.) They also asked me to include this: “Eco Cycle and Eco Park are brand names of GIKEN LTD. in Japan”, which seemed a reasonable enough request.

This video has an English dub available by changing the language option on supported devices.

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

