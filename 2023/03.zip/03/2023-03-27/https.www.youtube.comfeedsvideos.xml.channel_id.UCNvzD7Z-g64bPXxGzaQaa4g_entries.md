# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW Games of April 2023
 - [https://www.youtube.com/watch?v=y1lExODpbV8](https://www.youtube.com/watch?v=y1lExODpbV8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-03-27 21:12:31+00:00

Looking for something to play this April on PC, PS5, PS4, Xbox Series X/S/One or Nintendo Switch? We’ve got you covered with this new 2023 video games with April 2023 release dates.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:11 Sherlock Holmes: The Awakened 
1:39 Ghostwire: Tokyo
2:39 Mega Man Battle Network Legacy Collection 
3:42 Meet Your Maker 
4:45 Bramble: The Mountain King 
5:35 Road 96: Mile 0  
6:39 Minecraft Legends
7:49 Horizon Forbidden West: Burning Shores  
8:47 Dead Island 2 
9:41 Star Wars Jedi: Survivor 
10:41 BONUS

#10 Sherlock Holmes: The Awakened 

Platform: PC Switch PS4 PS5 Xbox One XSX|S 

Release Date: April 11, 2023



#9 Ghostwire: Tokyo

Platform: XSX|S  

Release Date: April 12, 2023



#8 Mega Man Battle Network Legacy Collection 

Platform: - PC Switch PS4 

Release Date: April 14, 2023



#7 Meet Your Maker 

Platform: - PC PS4 PS5 Xbox One XSX|S 

Release Date: April 4, 2023



#6 Bramble: The Mountain King 

Platform:  PC PS5 XSX|S Switch

Release Date: April 27, 2023



#5 Road 96: Mile 0  

Platform:  PC PS4 PS5 Xbox One XSX|S Switch 

Release Date:  April 4, 2023



#4 Minecraft Legends

Platform: PC PS4 PS5 Xbox One XSX|S Switch

Release Date: April 18, 2023



#3 Horizon Forbidden West: Burning Shores  

Platform: PS5 

Release Date: April 19, 2023



#2 Dead Island 2 

Platform: PC PS4 PS5 Xbox One XSX|S 

Release Date: April 21, 2023



#1 Star Wars Jedi: Survivor 

Platform: PC PS5 XSX|S 

Release Date: April 28, 2023



BONUS 



Star Trek: Resurgence 

Platform: PC PS4 PS5 Xbox One XSX|S 

Release Date: April 2023, 2023



Advance Wars 1+2: Re-Boot Camp 

Platform: Switch 

Release Date: April 21, 2023



Roots of Pacha 

Platform: PC 

Release Date: April 25, 2023

