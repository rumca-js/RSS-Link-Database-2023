# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## The tech helping driverless cars see round corners
 - [https://www.bbc.co.uk/news/business-65036895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65036895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-03-27 23:13:08+00:00

A trial in London used existing street cameras to help an autonomous car navigate city streets.

## Binance accused of breaking US financial laws
 - [https://www.bbc.co.uk/news/business-65091480?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65091480?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-03-27 21:09:39+00:00

US regulators seek a ban on the crypto platform as they ramp up their regulation of the industry.

## Why fun apps are banned on French officials' phones
 - [https://www.bbc.co.uk/news/technology-65088152?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65088152?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-03-27 13:54:03+00:00

France is removing not only TikTok but all "recreational" applications from government devices.

## Jack Ma: Alibaba founder back in China after three years
 - [https://www.bbc.co.uk/news/world-asia-china-65084344?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-65084344?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-03-27 07:24:45+00:00

The 58-year-old visited a school that he founded in his hometown of Hangzhou.

## Elon Musk: Twitter says parts of source code leaked online
 - [https://www.bbc.co.uk/news/business-65084254?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65084254?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-03-27 05:07:47+00:00

Elon Musk has also reportedly indicated Twitter is now worth less than half the amount he paid for it.

