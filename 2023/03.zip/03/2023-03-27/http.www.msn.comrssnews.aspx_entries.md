# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Netanyahu Is Beholden to the Israeli Far-Right on the Judicial Overhaul Plan
 - [http://www.msn.com/en-us/news/world/netanyahu-is-beholden-to-the-israeli-far-right-on-the-judicial-overhaul-plan/ar-AA199dnd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/netanyahu-is-beholden-to-the-israeli-far-right-on-the-judicial-overhaul-plan/ar-AA199dnd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 23:09:15.470735+00:00



## Prison sentence of ‘Real Housewife’ Jen Shah reduced by one year
 - [http://www.msn.com/en-us/news/crime/prison-sentence-of-real-housewife-jen-shah-reduced-by-one-year/ar-AA198QM1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/prison-sentence-of-real-housewife-jen-shah-reduced-by-one-year/ar-AA198QM1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 23:09:15.463042+00:00



## Timeline: How the Nashville shooting at Covenant School unfolded
 - [http://www.msn.com/en-us/news/crime/timeline-how-the-nashville-shooting-at-covenant-school-unfolded/ar-AA198Slw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/timeline-how-the-nashville-shooting-at-covenant-school-unfolded/ar-AA198Slw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 23:09:15.455744+00:00



## Facial recognition used nearly 1m times by US police
 - [http://www.msn.com/en-us/news/world/facial-recognition-used-nearly-1m-times-by-us-police/ar-AA1997OM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/facial-recognition-used-nearly-1m-times-by-us-police/ar-AA1997OM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 23:09:15.448682+00:00



## TV Reporter Recalls Own School Shooting Experience at Nashville Scene
 - [http://www.msn.com/en-us/news/crime/tv-reporter-recalls-own-school-shooting-experience-at-nashville-scene/ar-AA199k9W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/tv-reporter-recalls-own-school-shooting-experience-at-nashville-scene/ar-AA199k9W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 23:09:15.440626+00:00



## House Judiciary postpones pistol brace rule markup after Nashville shooting
 - [http://www.msn.com/en-us/news/politics/house-judiciary-postpones-pistol-brace-rule-markup-after-nashville-shooting/ar-AA199k56?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-judiciary-postpones-pistol-brace-rule-markup-after-nashville-shooting/ar-AA199k56?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 23:09:15.432546+00:00



## What would it mean to treat guns the way we treat cars?
 - [http://www.msn.com/en-us/health/medical/what-would-it-mean-to-treat-guns-the-way-we-treat-cars/ar-AAY6Bve?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/medical/what-would-it-mean-to-treat-guns-the-way-we-treat-cars/ar-AAY6Bve?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 23:09:15.424143+00:00



## Orlando Bloom visits children affected by war in Ukraine: They 'need their childhoods back'
 - [http://www.msn.com/en-us/news/world/orlando-bloom-visits-children-affected-by-war-in-ukraine-they-need-their-childhoods-back/ar-AA199oNC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/orlando-bloom-visits-children-affected-by-war-in-ukraine-they-need-their-childhoods-back/ar-AA199oNC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 23:09:15.415024+00:00



## Biden: ‘We Have To Do More to Protect Our Schools’
 - [http://www.msn.com/en-us/news/us/biden-we-have-to-do-more-to-protect-our-schools/ar-AA1990u2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/biden-we-have-to-do-more-to-protect-our-schools/ar-AA1990u2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 22:09:19.640952+00:00



## Nashville school shooting victims are identified
 - [http://www.msn.com/en-us/news/crime/nashville-school-shooting-victims-are-identified/ar-AA1992X7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-school-shooting-victims-are-identified/ar-AA1992X7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 22:09:19.634057+00:00



## Police: Blood, video link doctor to lawyer's disappearance
 - [http://www.msn.com/en-us/news/crime/police-blood-video-link-doctor-to-lawyer-s-disappearance/ar-AA1992Fe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/police-blood-video-link-doctor-to-lawyer-s-disappearance/ar-AA1992Fe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 22:09:19.627052+00:00



## Nine AI Chatbots You Can Play With Right Now
 - [http://www.msn.com/en-us/news/technology/nine-ai-chatbots-you-can-play-with-right-now/ar-AA199h8I?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/nine-ai-chatbots-you-can-play-with-right-now/ar-AA199h8I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 22:09:19.619494+00:00



## At least 16 people killed in landslide in central Ecuador
 - [http://www.msn.com/en-us/news/world/at-least-16-people-killed-in-landslide-in-central-ecuador/ar-AA198XLG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/at-least-16-people-killed-in-landslide-in-central-ecuador/ar-AA198XLG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 22:09:19.612325+00:00



## Nashville police ID three 9-year-olds as victims in school shooting
 - [http://www.msn.com/en-us/news/crime/nashville-police-id-three-9-year-olds-as-victims-in-school-shooting/ar-AA1990zK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-police-id-three-9-year-olds-as-victims-in-school-shooting/ar-AA1990zK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 22:09:19.605081+00:00



## VP Harris, in Ghana, addresses human rights amid anti-LGBTQ efforts in Africa
 - [http://www.msn.com/en-us/news/politics/vp-harris-in-ghana-addresses-human-rights-amid-anti-lgbtq-efforts-in-africa/ar-AA198Irn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/vp-harris-in-ghana-addresses-human-rights-amid-anti-lgbtq-efforts-in-africa/ar-AA198Irn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 22:09:19.596987+00:00



## Putin has made so many nuclear threats since he invaded Ukraine that people are increasingly shrugging them off
 - [http://www.msn.com/en-us/news/world/putin-has-made-so-many-nuclear-threats-since-he-invaded-ukraine-that-people-are-increasingly-shrugging-them-off/ar-AA199h8p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-has-made-so-many-nuclear-threats-since-he-invaded-ukraine-that-people-are-increasingly-shrugging-them-off/ar-AA199h8p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 22:09:19.588914+00:00



## Senate Republicans Lob Newest Challenge to Biden’s Student Loan Cancellation Plan
 - [http://www.msn.com/en-us/news/politics/senate-republicans-lob-newest-challenge-to-biden-s-student-loan-cancellation-plan/ar-AA1999ia?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-republicans-lob-newest-challenge-to-biden-s-student-loan-cancellation-plan/ar-AA1999ia?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 21:09:09.796164+00:00



## Justices poised to uphold federal ban on encouraging illegal immigration
 - [http://www.msn.com/en-us/news/politics/justices-poised-to-uphold-federal-ban-on-encouraging-illegal-immigration/ar-AA1996Us?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/justices-poised-to-uphold-federal-ban-on-encouraging-illegal-immigration/ar-AA1996Us?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 21:09:09.788964+00:00



## Lawmaker disinvited from Hawaiian parade over 'hurtful' pride flag comments
 - [http://www.msn.com/en-us/news/us/lawmaker-disinvited-from-hawaiian-parade-over-hurtful-pride-flag-comments/ar-AA198XcW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/lawmaker-disinvited-from-hawaiian-parade-over-hurtful-pride-flag-comments/ar-AA198XcW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 21:09:09.780821+00:00



## Netanyahu finally went too far
 - [http://www.msn.com/en-us/news/world/netanyahu-finally-went-too-far/ar-AA198ZXF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/netanyahu-finally-went-too-far/ar-AA198ZXF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 21:09:09.773640+00:00



## Here’s what we know about the Nashville school shooting
 - [http://www.msn.com/en-us/news/politics/here-s-what-we-know-about-the-nashville-school-shooting/ar-AA1996YR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/here-s-what-we-know-about-the-nashville-school-shooting/ar-AA1996YR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 21:09:09.764528+00:00



## New Jersey AG office takes over Paterson police department after death of activist
 - [http://www.msn.com/en-us/news/crime/new-jersey-ag-office-takes-over-paterson-police-department-after-death-of-activist/ar-AA198NIw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/new-jersey-ag-office-takes-over-paterson-police-department-after-death-of-activist/ar-AA198NIw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 21:09:09.757349+00:00



## Nashville Christian school shooter appears to be a former student, police chief says
 - [http://www.msn.com/en-us/news/crime/nashville-christian-school-shooter-appears-to-be-a-former-student-police-chief-says/ar-AA198UUu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-christian-school-shooter-appears-to-be-a-former-student-police-chief-says/ar-AA198UUu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 21:09:09.749940+00:00



## After previous health crises, can Philadelphians actually trust their government over water scare?
 - [http://www.msn.com/en-us/news/us/after-previous-health-crises-can-philadelphians-actually-trust-their-government-over-water-scare/ar-AA198DQd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/after-previous-health-crises-can-philadelphians-actually-trust-their-government-over-water-scare/ar-AA198DQd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 20:09:02.248372+00:00



## Photos: Nashville church school shooting, 3 children, 3 staff killed
 - [http://www.msn.com/en-us/news/crime/photos-nashville-church-school-shooting-3-children-3-staff-killed/ar-AA198Bej?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/photos-nashville-church-school-shooting-3-children-3-staff-killed/ar-AA198Bej?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 20:09:02.239611+00:00



## Murdaugh Moselle possessions pop up on eBay with exorbitant price tags
 - [http://www.msn.com/en-us/news/crime/murdaugh-moselle-possessions-pop-up-on-ebay-with-exorbitant-price-tags/ar-AA198Nfq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/murdaugh-moselle-possessions-pop-up-on-ebay-with-exorbitant-price-tags/ar-AA198Nfq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 20:09:02.230815+00:00



## A school shooting victim's protesting parents were hauled out of Congress by Capitol police last week. Now another mass shooting has left 3 adults and 3 more children dead.
 - [http://www.msn.com/en-us/news/us/a-school-shooting-victim-s-protesting-parents-were-hauled-out-of-congress-by-capitol-police-last-week-now-another-mass-shooting-has-left-3-adults-and-3-more-children-dead/ar-AA198Ngl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-school-shooting-victim-s-protesting-parents-were-hauled-out-of-congress-by-capitol-police-last-week-now-another-mass-shooting-has-left-3-adults-and-3-more-children-dead/ar-AA198Ngl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 20:09:02.221932+00:00



## Defying expectations, Cuba says their legislative elections had strong turnout
 - [http://www.msn.com/en-us/news/world/defying-expectations-cuba-says-their-legislative-elections-had-strong-turnout/ar-AA198WSY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/defying-expectations-cuba-says-their-legislative-elections-had-strong-turnout/ar-AA198WSY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 20:09:02.213888+00:00



## Supreme Court skeptical of man who offered adult adoptions
 - [http://www.msn.com/en-us/news/politics/supreme-court-skeptical-of-man-who-offered-adult-adoptions/ar-AA198yCe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/supreme-court-skeptical-of-man-who-offered-adult-adoptions/ar-AA198yCe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 20:09:02.206266+00:00



## Political parties, imperfect as they are, remain vital to preserving democracy
 - [http://www.msn.com/en-us/news/world/political-parties-imperfect-as-they-are-remain-vital-to-preserving-democracy/ar-AA198IX5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/political-parties-imperfect-as-they-are-remain-vital-to-preserving-democracy/ar-AA198IX5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 20:09:02.195225+00:00



## Heavily armed woman kills 3 children, 3 adults at private Nashville Christian school: police
 - [http://www.msn.com/en-us/news/crime/heavily-armed-woman-kills-3-children-3-adults-at-private-nashville-christian-school-police/ar-AA198JXf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/heavily-armed-woman-kills-3-children-3-adults-at-private-nashville-christian-school-police/ar-AA198JXf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 19:09:01.214267+00:00



## Massive protests, strike erupt in Israel over court reforms
 - [http://www.msn.com/en-us/news/world/massive-protests-strike-erupt-in-israel-over-court-reforms/ar-AA198y9o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/massive-protests-strike-erupt-in-israel-over-court-reforms/ar-AA198y9o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 19:09:01.206613+00:00



## 3 children, 3 staff dead after shooting at Tennessee school, officials say
 - [http://www.msn.com/en-us/news/us/3-children-3-staff-dead-after-shooting-at-tennessee-school-officials-say/ar-AA198CmD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/3-children-3-staff-dead-after-shooting-at-tennessee-school-officials-say/ar-AA198CmD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 19:09:01.199391+00:00



## A woman shot 3 adults and 3 children at a Nashville elementary school. Experts say mass shootings are almost always carried out by men.
 - [http://www.msn.com/en-us/news/crime/a-woman-shot-3-adults-and-3-children-at-a-nashville-elementary-school-experts-say-mass-shootings-are-almost-always-carried-out-by-men/ar-AA198Z3M?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-woman-shot-3-adults-and-3-children-at-a-nashville-elementary-school-experts-say-mass-shootings-are-almost-always-carried-out-by-men/ar-AA198Z3M?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 19:09:01.192146+00:00



## Israel PM Netanyahu delays legal reforms after protests
 - [http://www.msn.com/en-us/news/world/israel-pm-netanyahu-delays-legal-reforms-after-protests/ar-AA198ROT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-pm-netanyahu-delays-legal-reforms-after-protests/ar-AA198ROT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 19:09:01.184893+00:00



## Tennessee school shooting: What to know about Covenant School in Nashville
 - [http://www.msn.com/en-us/news/us/tennessee-school-shooting-what-to-know-about-covenant-school-in-nashville/ar-AA198Glo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tennessee-school-shooting-what-to-know-about-covenant-school-in-nashville/ar-AA198Glo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 19:09:01.176642+00:00



## Netanyahu to ‘Suspend’ Judicial Overhaul as Pro-Democracy Protests Reach Crisis Levels
 - [http://www.msn.com/en-us/news/world/netanyahu-to-suspend-judicial-overhaul-as-pro-democracy-protests-reach-crisis-levels/ar-AA198yei?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/netanyahu-to-suspend-judicial-overhaul-as-pro-democracy-protests-reach-crisis-levels/ar-AA198yei?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 19:09:01.168270+00:00



## Israel’s Netanyahu agrees to halt judicial reform for now as mass protests continue
 - [http://www.msn.com/en-us/news/world/israel-s-netanyahu-agrees-to-halt-judicial-reform-for-now-as-mass-protests-continue/ar-AA198Oug?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-s-netanyahu-agrees-to-halt-judicial-reform-for-now-as-mass-protests-continue/ar-AA198Oug?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 18:09:01.918570+00:00



## What we know about the shooting at Covenant School in Nashville
 - [http://www.msn.com/en-us/news/us/what-we-know-about-the-shooting-at-covenant-school-in-nashville/ar-AA198TOu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-we-know-about-the-shooting-at-covenant-school-in-nashville/ar-AA198TOu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 18:09:01.910420+00:00



## Idris Elba says Kamala Harris would make a 'good' president: 'Of course'
 - [http://www.msn.com/en-us/news/politics/idris-elba-says-kamala-harris-would-make-a-good-president-of-course/ar-AA198Aha?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/idris-elba-says-kamala-harris-would-make-a-good-president-of-course/ar-AA198Aha?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 18:09:01.903183+00:00



## 3 children, 3 adults fatally shot at Nashville Christian school
 - [http://www.msn.com/en-us/news/us/3-children-3-adults-fatally-shot-at-nashville-christian-school/ar-AA198Ess?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/3-children-3-adults-fatally-shot-at-nashville-christian-school/ar-AA198Ess?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 18:09:01.896022+00:00



## Fed official: Regulators will ensure all deposits are 'safe'
 - [http://www.msn.com/en-us/news/politics/fed-official-regulators-will-ensure-all-deposits-are-safe/ar-AA198JCv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fed-official-regulators-will-ensure-all-deposits-are-safe/ar-AA198JCv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 18:09:01.888755+00:00



## How could a TikTok ban be enforced?
 - [http://www.msn.com/en-us/news/politics/how-could-a-tiktok-ban-be-enforced/ar-AA198AdJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/how-could-a-tiktok-ban-be-enforced/ar-AA198AdJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 18:09:01.881482+00:00



## Jobs lost as furniture firm enters administration
 - [http://www.msn.com/en-us/news/world/jobs-lost-as-furniture-firm-enters-administration/ar-AA198HIw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/jobs-lost-as-furniture-firm-enters-administration/ar-AA198HIw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 18:09:01.873785+00:00



## Nashville school shooting updates: 3 kids, 3 adults killed; female suspect dead
 - [http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-3-kids-3-adults-killed-female-suspect-dead/ar-AA198cRO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/nashville-school-shooting-updates-3-kids-3-adults-killed-female-suspect-dead/ar-AA198cRO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 18:09:01.865417+00:00



## Why Prince Harry, Elton John, and 5 Others Are Suing the Daily Mail's Publisher
 - [http://www.msn.com/en-us/news/world/why-prince-harry-elton-john-and-5-others-are-suing-the-daily-mail-s-publisher/ar-AA198lyV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/why-prince-harry-elton-john-and-5-others-are-suing-the-daily-mail-s-publisher/ar-AA198lyV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 17:08:54.463498+00:00



## Bibi’s Judicial Power Grab Frozen After Mass Israel Protests
 - [http://www.msn.com/en-us/news/world/bibi-s-judicial-power-grab-frozen-after-mass-israel-protests/ar-AA198irI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/bibi-s-judicial-power-grab-frozen-after-mass-israel-protests/ar-AA198irI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 17:08:54.456486+00:00



## Watch: Russian Strikes Hit Eastern Ukraine, Killing Two, Injuring Dozens
 - [http://www.msn.com/en-us/news/world/watch-russian-strikes-hit-eastern-ukraine-killing-two-injuring-dozens/vi-AA198l72?srcref=rss](http://www.msn.com/en-us/news/world/watch-russian-strikes-hit-eastern-ukraine-killing-two-injuring-dozens/vi-AA198l72?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 17:08:54.448780+00:00



## Daily on Energy: Battle lines reform around resolution to cancel Biden solar emergency
 - [http://www.msn.com/en-us/news/politics/daily-on-energy-battle-lines-reform-around-resolution-to-cancel-biden-solar-emergency/ar-AA198dmg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/daily-on-energy-battle-lines-reform-around-resolution-to-cancel-biden-solar-emergency/ar-AA198dmg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 17:08:54.441228+00:00



## Senate rejection of Biden’s controversial nominees reveals ‘out of touch’ president, GOP says
 - [http://www.msn.com/en-us/news/politics/senate-rejection-of-biden-s-controversial-nominees-reveals-out-of-touch-president-gop-says/ar-AA198EVz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-rejection-of-biden-s-controversial-nominees-reveals-out-of-touch-president-gop-says/ar-AA198EVz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 17:08:54.433847+00:00



## Israel delays controversial judicial reform bill until next session amid protests
 - [http://www.msn.com/en-us/news/world/israel-delays-controversial-judicial-reform-bill-until-next-session-amid-protests/ar-AA197Wf0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-delays-controversial-judicial-reform-bill-until-next-session-amid-protests/ar-AA197Wf0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 17:08:54.426789+00:00



## Shooting at Nashville Christian school leaves at least 3 children and the gunman dead, officials say
 - [http://www.msn.com/en-us/news/us/shooting-at-nashville-christian-school-leaves-at-least-3-children-and-the-gunman-dead-officials-say/ar-AA198Ess?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/shooting-at-nashville-christian-school-leaves-at-least-3-children-and-the-gunman-dead-officials-say/ar-AA198Ess?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 17:08:54.419360+00:00



## US considering more federal support for banking industry: report
 - [http://www.msn.com/en-us/news/politics/us-considering-more-federal-support-for-banking-industry-report/ar-AA198nZy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/us-considering-more-federal-support-for-banking-industry-report/ar-AA198nZy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 17:08:54.411611+00:00



## Pardon sought for Black man executed in 1908 in Illinois
 - [http://www.msn.com/en-us/news/us/pardon-sought-for-black-man-executed-in-1908-in-illinois/ar-AA198baQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/pardon-sought-for-black-man-executed-in-1908-in-illinois/ar-AA198baQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 16:09:03.419722+00:00



## Senate Democrats say abortion access for service members helps national security
 - [http://www.msn.com/en-us/news/politics/senate-democrats-say-abortion-access-for-service-members-helps-national-security/ar-AA198pJE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-democrats-say-abortion-access-for-service-members-helps-national-security/ar-AA198pJE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 16:09:03.411706+00:00



## Six injured after Minnesota parking lot shooting
 - [http://www.msn.com/en-us/news/us/six-injured-after-minnesota-parking-lot-shooting/ar-AA198mWc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/six-injured-after-minnesota-parking-lot-shooting/ar-AA198mWc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 16:09:03.403966+00:00



## Prince Harry's Tabloid Lawsuit Sparks Privacy Debate
 - [http://www.msn.com/en-us/news/world/prince-harry-s-tabloid-lawsuit-sparks-privacy-debate/ar-AA198wur?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/prince-harry-s-tabloid-lawsuit-sparks-privacy-debate/ar-AA198wur?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 16:09:03.396679+00:00



## The Medal of Honor: They did their part, now let’s do ours
 - [http://www.msn.com/en-us/news/politics/the-medal-of-honor-they-did-their-part-now-let-s-do-ours/ar-AA198hVh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-medal-of-honor-they-did-their-part-now-let-s-do-ours/ar-AA198hVh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 16:09:03.389371+00:00



## Israel's Netanyahu to delay judiciary overhaul after mass protests, coalition partner says
 - [http://www.msn.com/en-us/news/world/israel-s-netanyahu-to-delay-judiciary-overhaul-after-mass-protests-coalition-partner-says/ar-AA198DZN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-s-netanyahu-to-delay-judiciary-overhaul-after-mass-protests-coalition-partner-says/ar-AA198DZN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 16:09:03.382178+00:00



## How Policies Meant to Help Parents Hurt Families
 - [http://www.msn.com/en-us/news/us/how-policies-meant-to-help-parents-hurt-families/ar-AA198kFV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/how-policies-meant-to-help-parents-hurt-families/ar-AA198kFV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 16:09:03.374871+00:00



## Khanna's pass clarifies California Senate race — and his political future
 - [http://www.msn.com/en-us/news/politics/khanna-s-pass-clarifies-california-senate-race-and-his-political-future/ar-AA198us5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/khanna-s-pass-clarifies-california-senate-race-and-his-political-future/ar-AA198us5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 16:09:03.366661+00:00



## Nationwide Strike, Israel Protests Intensify Against Judicial Reform
 - [http://www.msn.com/en-us/news/world/nationwide-strike-israel-protests-intensify-against-judicial-reform/vi-AA198hfN?srcref=rss](http://www.msn.com/en-us/news/world/nationwide-strike-israel-protests-intensify-against-judicial-reform/vi-AA198hfN?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 15:09:06.345756+00:00



## Richard Viguerie rallies youth to take charge of conservative movement
 - [http://www.msn.com/en-us/news/politics/richard-viguerie-rallies-youth-to-take-charge-of-conservative-movement/ar-AA198eWN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/richard-viguerie-rallies-youth-to-take-charge-of-conservative-movement/ar-AA198eWN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 15:09:06.338161+00:00



## Who's who in the Gwyneth Paltrow ski crash trial
 - [http://www.msn.com/en-us/news/world/who-s-who-in-the-gwyneth-paltrow-ski-crash-trial/ar-AA198jGz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/who-s-who-in-the-gwyneth-paltrow-ski-crash-trial/ar-AA198jGz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 15:09:06.330888+00:00



## Supreme Court rejects case of Oklahoma teen killed by police
 - [http://www.msn.com/en-us/news/politics/supreme-court-rejects-case-of-oklahoma-teen-killed-by-police/ar-AA198jPv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/supreme-court-rejects-case-of-oklahoma-teen-killed-by-police/ar-AA198jPv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 15:09:06.323720+00:00



## Who Is Tomasz Kosowski? Plastic Surgeon Arrested Over Mystery Lawyer Death
 - [http://www.msn.com/en-us/news/crime/who-is-tomasz-kosowski-plastic-surgeon-arrested-over-mystery-lawyer-death/ar-AA198tCA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/who-is-tomasz-kosowski-plastic-surgeon-arrested-over-mystery-lawyer-death/ar-AA198tCA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 15:09:06.316550+00:00



## Eyes on 2024: Trump rails against “deep state” in first ’24 rally
 - [http://www.msn.com/en-us/news/politics/eyes-on-2024-trump-rails-against-deep-state-in-first-24-rally/ar-AA198tFk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/eyes-on-2024-trump-rails-against-deep-state-in-first-24-rally/ar-AA198tFk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 15:09:06.307845+00:00



## The state of America in 2023: confusion and pessimism
 - [http://www.msn.com/en-us/news/politics/the-state-of-america-in-2023-confusion-and-pessimism/ar-AA198me2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-state-of-america-in-2023-confusion-and-pessimism/ar-AA198me2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 15:09:06.299643+00:00



## Where's all the Ukraine money going? This person can help find the truth
 - [http://www.msn.com/en-us/news/world/where-s-all-the-ukraine-money-going-this-person-can-help-find-the-truth/ar-AA1988gn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/where-s-all-the-ukraine-money-going-this-person-can-help-find-the-truth/ar-AA1988gn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 15:09:06.291993+00:00



## Video Shows 200-Foot Asteroid Approaching Earth Before 'Very Close' Flyby
 - [http://www.msn.com/en-us/news/technology/video-shows-200-foot-asteroid-approaching-earth-before-very-close-flyby/ar-AA198lTs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/video-shows-200-foot-asteroid-approaching-earth-before-very-close-flyby/ar-AA198lTs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:35:37.596235+00:00



## Mexico just got slapped with rare sanctions for its failure to protect wildlife. Here’s why.
 - [http://www.msn.com/en-us/news/world/mexico-just-got-slapped-with-rare-sanctions-for-its-failure-to-protect-wildlife-here-s-why/ar-AA198bR1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/mexico-just-got-slapped-with-rare-sanctions-for-its-failure-to-protect-wildlife-here-s-why/ar-AA198bR1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:35:37.589033+00:00



## 2 shot at California Sikh temple after fight escalates, officials say
 - [http://www.msn.com/en-us/news/us/2-shot-at-california-sikh-temple-after-fight-escalates-officials-say/ar-AA198lP9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/2-shot-at-california-sikh-temple-after-fight-escalates-officials-say/ar-AA198lP9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:35:37.581919+00:00



## Renée Fleming stars as `Nixon in China' arrives in Paris
 - [http://www.msn.com/en-us/news/world/renée-fleming-stars-as-nixon-in-china-arrives-in-paris/ar-AA198oxp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/renée-fleming-stars-as-nixon-in-china-arrives-in-paris/ar-AA198oxp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:35:37.574650+00:00



## Bragg says ‘unprecedented’ GOP inquiry undermines prosecutors’ ‘legitimate work’
 - [http://www.msn.com/en-us/news/politics/bragg-says-unprecedented-gop-inquiry-undermines-prosecutors-legitimate-work/ar-AA198eRx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bragg-says-unprecedented-gop-inquiry-undermines-prosecutors-legitimate-work/ar-AA198eRx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:35:37.566574+00:00



## Disability rights activist faces Supreme Court showdown over hotel accessibility lawsuits
 - [http://www.msn.com/en-us/news/us/disability-rights-activist-faces-supreme-court-showdown-over-hotel-accessibility-lawsuits/ar-AA197Vok?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/disability-rights-activist-faces-supreme-court-showdown-over-hotel-accessibility-lawsuits/ar-AA197Vok?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:21:29.911089+00:00



## A second giant 'hole' has appeared on the sun, and it could send 1.8 million mph solar winds towards Earth
 - [http://www.msn.com/en-us/news/technology/a-second-giant-hole-has-appeared-on-the-sun-and-it-could-send-1-8-million-mph-solar-winds-towards-earth/ar-AA1987oB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/a-second-giant-hole-has-appeared-on-the-sun-and-it-could-send-1-8-million-mph-solar-winds-towards-earth/ar-AA1987oB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:21:29.900731+00:00



## Report: Queen Elizabeth II asked Germany for pricey horses
 - [http://www.msn.com/en-us/news/world/report-queen-elizabeth-ii-asked-germany-for-pricey-horses/ar-AA1983eb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/report-queen-elizabeth-ii-asked-germany-for-pricey-horses/ar-AA1983eb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:21:29.892895+00:00



## Why fun apps are banned on French officials' phones
 - [http://www.msn.com/en-us/news/world/why-fun-apps-are-banned-on-french-officials-phones/ar-AA197VG3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/why-fun-apps-are-banned-on-french-officials-phones/ar-AA197VG3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:21:29.883117+00:00



## Space wars: When science fiction becomes reality
 - [http://www.msn.com/en-us/news/politics/space-wars-when-science-fiction-becomes-reality/ar-AA1987Ge?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/space-wars-when-science-fiction-becomes-reality/ar-AA1987Ge?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:21:29.874640+00:00



## Machine-Wash Your Sheets and Bedding the Right Way With These 5 Simple Steps
 - [http://www.msn.com/en-us/news/technology/machine-wash-your-sheets-and-bedding-the-right-way-with-these-5-simple-steps/ar-AA13RNF1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/machine-wash-your-sheets-and-bedding-the-right-way-with-these-5-simple-steps/ar-AA13RNF1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:21:29.866090+00:00



## Be well: Take a walk outside to boost your mental health
 - [http://www.msn.com/en-us/health/health-news/be-well-take-a-walk-outside-to-boost-your-mental-health/ar-AA198eDe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/be-well-take-a-walk-outside-to-boost-your-mental-health/ar-AA198eDe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 14:21:29.857148+00:00



## Bodies of all 7 victims of Pennsylvania chocolate factory explosion have been found
 - [http://www.msn.com/en-us/news/crime/bodies-of-all-7-victims-of-pennsylvania-chocolate-factory-explosion-have-been-found/ar-AA197Qmm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/bodies-of-all-7-victims-of-pennsylvania-chocolate-factory-explosion-have-been-found/ar-AA197Qmm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 13:35:09.757084+00:00



## How Senate Republicans could tank Biden's student loan forgiveness program this week
 - [http://www.msn.com/en-us/news/politics/how-senate-republicans-could-tank-biden-s-student-loan-forgiveness-program-this-week/ar-AA197X21?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/how-senate-republicans-could-tank-biden-s-student-loan-forgiveness-program-this-week/ar-AA197X21?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 13:35:09.747819+00:00



## Putin snubbed Xi back after their one-sided summit with a nuclear announcement that directly undermines China
 - [http://www.msn.com/en-us/news/world/putin-snubbed-xi-back-after-their-one-sided-summit-with-a-nuclear-announcement-that-directly-undermines-china/ar-AA1984Ay?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-snubbed-xi-back-after-their-one-sided-summit-with-a-nuclear-announcement-that-directly-undermines-china/ar-AA1984Ay?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 13:35:09.739689+00:00



## Mortgage Refinance Rates for March 27, 2023: Rates Drop Off
 - [http://www.msn.com/en-us/news/technology/mortgage-refinance-rates-for-march-27-2023-rates-drop-off/ar-AA197UTS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/mortgage-refinance-rates-for-march-27-2023-rates-drop-off/ar-AA197UTS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 13:35:09.731567+00:00



## Did Edward VIII Help the Nazis Bomb Buckingham Palace?
 - [http://www.msn.com/en-us/news/world/did-edward-viii-help-the-nazis-bomb-buckingham-palace/ar-AA197NvS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/did-edward-viii-help-the-nazis-bomb-buckingham-palace/ar-AA197NvS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 13:35:09.724330+00:00



## Alibaba Co-Founder Jack Ma Visits School in China After Year Overseas
 - [http://www.msn.com/en-us/money/other/alibaba-co-founder-jack-ma-visits-school-in-china-after-year-overseas/vi-AA197QlC?srcref=rss](http://www.msn.com/en-us/money/other/alibaba-co-founder-jack-ma-visits-school-in-china-after-year-overseas/vi-AA197QlC?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 13:35:09.715815+00:00



## Kevin McCarthy says House 'will be moving forward' with TikTok legislation
 - [http://www.msn.com/en-us/news/politics/kevin-mccarthy-says-house-will-be-moving-forward-with-tiktok-legislation/ar-AA1982ri?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kevin-mccarthy-says-house-will-be-moving-forward-with-tiktok-legislation/ar-AA1982ri?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 13:35:09.708522+00:00



## Elizabeth Warren announces Senate reelection bid
 - [http://www.msn.com/en-us/news/politics/elizabeth-warren-announces-senate-reelection-bid/ar-AA1982PM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/elizabeth-warren-announces-senate-reelection-bid/ar-AA1982PM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 13:35:09.700912+00:00



## Florida inches closer to ban on ESG policies with taxpayer funds
 - [http://www.msn.com/en-us/news/politics/florida-inches-closer-to-ban-on-esg-policies-with-taxpayer-funds/ar-AA1984aT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/florida-inches-closer-to-ban-on-esg-policies-with-taxpayer-funds/ar-AA1984aT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 12:49:49.862233+00:00



## Fracking caused the biggest earthquake in Alberta's history, seismologist says
 - [http://www.msn.com/en-us/news/technology/fracking-caused-the-biggest-earthquake-in-alberta-s-history-seismologist-says/ar-AA197S4N?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/fracking-caused-the-biggest-earthquake-in-alberta-s-history-seismologist-says/ar-AA197S4N?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 12:49:49.851459+00:00



## Russian Billboards Instruct Citizens How to Prepare 'Nuclear' Survival Kits
 - [http://www.msn.com/en-us/news/world/russian-billboards-instruct-citizens-how-to-prepare-nuclear-survival-kits/ar-AA19824H?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-billboards-instruct-citizens-how-to-prepare-nuclear-survival-kits/ar-AA19824H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 12:49:49.843098+00:00



## A viral image of Pope Francis dressed in a stylish white puffer coat that fooled social media users was actually generated by AI
 - [http://www.msn.com/en-us/news/technology/a-viral-image-of-pope-francis-dressed-in-a-stylish-white-puffer-coat-that-fooled-social-media-users-was-actually-generated-by-ai/ar-AA197AuD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/a-viral-image-of-pope-francis-dressed-in-a-stylish-white-puffer-coat-that-fooled-social-media-users-was-actually-generated-by-ai/ar-AA197AuD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 12:49:49.835506+00:00



## Search for families buried in Ecuador landslide
 - [http://www.msn.com/en-us/news/world/search-for-families-buried-in-ecuador-landslide/ar-AA197WCZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/search-for-families-buried-in-ecuador-landslide/ar-AA197WCZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 12:49:49.827920+00:00



## Israeli unions launch strike, upping pressure on Netanyahu
 - [http://www.msn.com/en-us/news/world/israeli-unions-launch-strike-upping-pressure-on-netanyahu/ar-AA1984bL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israeli-unions-launch-strike-upping-pressure-on-netanyahu/ar-AA1984bL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 12:49:49.819558+00:00



## DOJ investigates deputies accused of shoving guns in mouths of 2 Black men
 - [http://www.msn.com/en-us/news/crime/doj-investigates-deputies-accused-of-shoving-guns-in-mouths-of-2-black-men/ar-AA197IDI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/doj-investigates-deputies-accused-of-shoving-guns-in-mouths-of-2-black-men/ar-AA197IDI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 12:49:49.812316+00:00



## UK pushes on with asylum law despite rights group opposition
 - [http://www.msn.com/en-us/news/world/uk-pushes-on-with-asylum-law-despite-rights-group-opposition/ar-AA197SaB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/uk-pushes-on-with-asylum-law-despite-rights-group-opposition/ar-AA197SaB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 12:49:49.804258+00:00



## Lawmakers open to Biden’s call to claw back SVB executive pay
 - [http://www.msn.com/en-us/news/politics/lawmakers-open-to-biden-s-call-to-claw-back-svb-executive-pay/ar-AA197Hx7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lawmakers-open-to-biden-s-call-to-claw-back-svb-executive-pay/ar-AA197Hx7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 11:39:09.013800+00:00



## Women Drive Wealth. So Why Is Equity Still Inequitable?
 - [http://www.msn.com/en-us/news/technology/women-drive-wealth-so-why-is-equity-still-inequitable/ar-AA197Ti1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/women-drive-wealth-so-why-is-equity-still-inequitable/ar-AA197Ti1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 11:39:09.005907+00:00



## Tigers that escaped after possible tornado recaptured in Georgia
 - [http://www.msn.com/en-us/news/politics/tigers-that-escaped-after-possible-tornado-recaptured-in-georgia/ar-AA197JvP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/tigers-that-escaped-after-possible-tornado-recaptured-in-georgia/ar-AA197JvP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 11:39:08.998675+00:00



## Elizabeth Warren running for 3rd US Senate term in 2024
 - [http://www.msn.com/en-us/news/politics/elizabeth-warren-running-for-3rd-us-senate-term-in-2024/ar-AA197zKX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/elizabeth-warren-running-for-3rd-us-senate-term-in-2024/ar-AA197zKX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 11:39:08.990491+00:00



## Video: Mississippi Tornado Survivors Dig Through Rubble, Cope with Grief
 - [http://www.msn.com/en-us/video/news/video-mississippi-tornado-survivors-dig-through-rubble-cope-with-grief/vi-AA197Rc7?srcref=rss](http://www.msn.com/en-us/video/news/video-mississippi-tornado-survivors-dig-through-rubble-cope-with-grief/vi-AA197Rc7?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 11:39:08.982457+00:00



## Farmers in Ukraine are forced to dig up land mines by hand to save their livelihoods: 'I don't have any other choice'
 - [http://www.msn.com/en-us/news/world/farmers-in-ukraine-are-forced-to-dig-up-land-mines-by-hand-to-save-their-livelihoods-i-don-t-have-any-other-choice/ar-AA197Rhi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/farmers-in-ukraine-are-forced-to-dig-up-land-mines-by-hand-to-save-their-livelihoods-i-don-t-have-any-other-choice/ar-AA197Rhi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 11:39:08.972944+00:00



## Mom of Navy sailor who vanished after leaving Illinois bar speaks out, says Seamus Gray search 'gut-wrenching'
 - [http://www.msn.com/en-us/news/us/mom-of-navy-sailor-who-vanished-after-leaving-illinois-bar-speaks-out-says-seamus-gray-search-gut-wrenching/ar-AA197vhh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/mom-of-navy-sailor-who-vanished-after-leaving-illinois-bar-speaks-out-says-seamus-gray-search-gut-wrenching/ar-AA197vhh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 11:39:08.964421+00:00



## FDA stonewalled abortion drug concerns to escape responsibility for their dangers
 - [http://www.msn.com/en-us/news/us/fda-stonewalled-abortion-drug-concerns-to-escape-responsibility-for-their-dangers/ar-AA197EVJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/fda-stonewalled-abortion-drug-concerns-to-escape-responsibility-for-their-dangers/ar-AA197EVJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 10:38:42.437895+00:00



## U.S., Mexico near deal for Mexico to crack down on fentanyl going north, U.S. to fight guns going south
 - [http://www.msn.com/en-us/news/us/u-s-mexico-near-deal-for-mexico-to-crack-down-on-fentanyl-going-north-u-s-to-fight-guns-going-south/ar-AA197xRT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/u-s-mexico-near-deal-for-mexico-to-crack-down-on-fentanyl-going-north-u-s-to-fight-guns-going-south/ar-AA197xRT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 10:38:42.429260+00:00



## Banking legislation piles up as wobbly market evolves
 - [http://www.msn.com/en-us/news/politics/banking-legislation-piles-up-as-wobbly-market-evolves/ar-AA197Gxc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/banking-legislation-piles-up-as-wobbly-market-evolves/ar-AA197Gxc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 10:38:42.421991+00:00



## Busting the myth of the cowboy — one performance at a time
 - [http://www.msn.com/en-us/news/us/busting-the-myth-of-the-cowboy-one-performance-at-a-time/ar-AA197LkW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/busting-the-myth-of-the-cowboy-one-performance-at-a-time/ar-AA197LkW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 10:38:42.412153+00:00



## Russian jets of newer generation increase 'dominance,' Ukrainian official says
 - [http://www.msn.com/en-us/news/world/russian-jets-of-newer-generation-increase-dominance-ukrainian-official-says/ar-AA197l28?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-jets-of-newer-generation-increase-dominance-ukrainian-official-says/ar-AA197l28?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 10:38:42.402360+00:00



## A laid-off Indeed.com employee went on a 'final office snack run' and filled his tote back with chips and instant noodles on his way out
 - [http://www.msn.com/en-us/news/world/a-laid-off-indeed-com-employee-went-on-a-final-office-snack-run-and-filled-his-tote-back-with-chips-and-instant-noodles-on-his-way-out/ar-AA197GFH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-laid-off-indeed-com-employee-went-on-a-final-office-snack-run-and-filled-his-tote-back-with-chips-and-instant-noodles-on-his-way-out/ar-AA197GFH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 10:38:42.395310+00:00



## Meghan Markle and Royals' Last Curtsies to Queen Shared by Fans
 - [http://www.msn.com/en-us/news/world/meghan-markle-and-royals-last-curtsies-to-queen-shared-by-fans/ar-AA197O1M?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/meghan-markle-and-royals-last-curtsies-to-queen-shared-by-fans/ar-AA197O1M?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 10:38:42.387394+00:00



## Scotland's ruling SNP picks new leader to succeed Sturgeon
 - [http://www.msn.com/en-us/news/world/scotland-s-ruling-snp-picks-new-leader-to-succeed-sturgeon/ar-AA197GOi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/scotland-s-ruling-snp-picks-new-leader-to-succeed-sturgeon/ar-AA197GOi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 10:38:42.378075+00:00



## ISIS Isn’t Dead, It’s Just Detained.
 - [http://www.msn.com/en-us/news/world/isis-isn-t-dead-it-s-just-detained/ar-AA197hFM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/isis-isn-t-dead-it-s-just-detained/ar-AA197hFM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 09:38:34.764191+00:00



## Angry protests, strikes paralyze Israel as Netanyahu resists pausing widely hated judicial reforms
 - [http://www.msn.com/en-us/news/world/angry-protests-strikes-paralyze-israel-as-netanyahu-resists-pausing-widely-hated-judicial-reforms/ar-AA197tHN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/angry-protests-strikes-paralyze-israel-as-netanyahu-resists-pausing-widely-hated-judicial-reforms/ar-AA197tHN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 09:38:34.756502+00:00



## Putin Compares New NATO Plans to 1930s Fascist Axis
 - [http://www.msn.com/en-us/news/world/putin-compares-new-nato-plans-to-1930s-fascist-axis/ar-AA197siU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-compares-new-nato-plans-to-1930s-fascist-axis/ar-AA197siU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 09:38:34.748716+00:00



## Hundreds of business groups step up campaign to ease permitting for projects
 - [http://www.msn.com/en-us/news/politics/hundreds-of-business-groups-step-up-campaign-to-ease-permitting-for-projects/ar-AA197sfR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hundreds-of-business-groups-step-up-campaign-to-ease-permitting-for-projects/ar-AA197sfR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 09:38:34.740962+00:00



## Senate Democrats ask military to protect abortion access for service members
 - [http://www.msn.com/en-us/news/politics/senate-democrats-ask-military-to-protect-abortion-access-for-service-members/ar-AA197cJa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-democrats-ask-military-to-protect-abortion-access-for-service-members/ar-AA197cJa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 09:38:34.732095+00:00



## Newsom falls silent after calls for him to take executive action on reparations
 - [http://www.msn.com/en-us/news/us/newsom-falls-silent-after-calls-for-him-to-take-executive-action-on-reparations/ar-AA1977Yo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/newsom-falls-silent-after-calls-for-him-to-take-executive-action-on-reparations/ar-AA1977Yo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 09:38:34.724494+00:00



## Prince Harry Makes Shock Court Appearance in Blockbuster Daily Mail Lawsuit
 - [http://www.msn.com/en-us/news/world/prince-harry-makes-shock-court-appearance-in-blockbuster-daily-mail-lawsuit/ar-AA197d0k?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/prince-harry-makes-shock-court-appearance-in-blockbuster-daily-mail-lawsuit/ar-AA197d0k?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 09:38:34.716441+00:00



## Privacy fears stymie government surveyors as responses dive
 - [http://www.msn.com/en-us/news/us/privacy-fears-stymie-government-surveyors-as-responses-dive/ar-AA197DZw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/privacy-fears-stymie-government-surveyors-as-responses-dive/ar-AA197DZw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 09:38:34.705480+00:00



## 2 dead, 5 injured in shootings at 2 Little Rock locations, police say
 - [http://www.msn.com/en-us/news/crime/2-dead-5-injured-in-shootings-at-2-little-rock-locations-police-say/ar-AA197a2Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/2-dead-5-injured-in-shootings-at-2-little-rock-locations-police-say/ar-AA197a2Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 08:38:38.055142+00:00



## Jerry Zezima: Little kitchen of horrors
 - [http://www.msn.com/en-us/news/us/jerry-zezima-little-kitchen-of-horrors/ar-AA197cmQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jerry-zezima-little-kitchen-of-horrors/ar-AA197cmQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 08:38:38.047513+00:00



## What Putin's Arrest Could Look Like
 - [http://www.msn.com/en-us/news/world/what-putin-s-arrest-could-look-like/ar-AA197wh4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/what-putin-s-arrest-could-look-like/ar-AA197wh4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 08:38:38.040211+00:00



## Students deserve to know this shocking truth about communism
 - [http://www.msn.com/en-us/news/world/students-deserve-to-know-this-shocking-truth-about-communism/ar-AA197jAM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/students-deserve-to-know-this-shocking-truth-about-communism/ar-AA197jAM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 08:38:38.032445+00:00



## Shark attack victim off Western Australia's Pilbara Coast bit twice near remote Montebello Islands
 - [http://www.msn.com/en-us/news/world/shark-attack-victim-off-western-australia-s-pilbara-coast-bit-twice-near-remote-montebello-islands/ar-AA197gTy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/shark-attack-victim-off-western-australia-s-pilbara-coast-bit-twice-near-remote-montebello-islands/ar-AA197gTy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 07:38:33.766914+00:00



## More than 30 animals seized from Tennessee breeding mill for animal cruelty
 - [http://www.msn.com/en-us/news/us/more-than-30-animals-seized-from-tennessee-breeding-mill-for-animal-cruelty/ar-AA196Zpu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/more-than-30-animals-seized-from-tennessee-breeding-mill-for-animal-cruelty/ar-AA196Zpu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 07:38:33.759604+00:00



## Amid strained U.S. ties, China finds unlikely friend in Utah
 - [http://www.msn.com/en-us/news/world/amid-strained-u-s-ties-china-finds-unlikely-friend-in-utah/ar-AA19733S?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/amid-strained-u-s-ties-china-finds-unlikely-friend-in-utah/ar-AA19733S?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 07:38:33.751482+00:00



## Jonathan Majors in 'Freedom' Cap As He Leaves Court on Assault Charges
 - [http://www.msn.com/en-us/news/crime/jonathan-majors-in-freedom-cap-as-he-leaves-court-on-assault-charges/ar-AA197bQF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/jonathan-majors-in-freedom-cap-as-he-leaves-court-on-assault-charges/ar-AA197bQF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 07:38:33.743559+00:00



## Alibaba's Jack Ma back in China after three years
 - [http://www.msn.com/en-us/news/world/alibaba-s-jack-ma-back-in-china-after-three-years/ar-AA197lPr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/alibaba-s-jack-ma-back-in-china-after-three-years/ar-AA197lPr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 07:38:33.724807+00:00



## Japan indicts man for killing student with thallium
 - [http://www.msn.com/en-us/news/world/japan-indicts-man-for-killing-student-with-thallium/ar-AA196MMO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/japan-indicts-man-for-killing-student-with-thallium/ar-AA196MMO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 06:38:21.574345+00:00



## First Citizens Bank to buy Silicon Valley Bank deposits and loans
 - [http://www.msn.com/en-us/news/us/first-citizens-bank-to-buy-silicon-valley-bank-deposits-and-loans/ar-AA1976gd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/first-citizens-bank-to-buy-silicon-valley-bank-deposits-and-loans/ar-AA1976gd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 06:38:21.567103+00:00



## Tokyo demands China free Japan national detained in Beijing
 - [http://www.msn.com/en-us/news/world/tokyo-demands-china-free-japan-national-detained-in-beijing/ar-AA197b8q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/tokyo-demands-china-free-japan-national-detained-in-beijing/ar-AA197b8q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 06:38:21.559761+00:00



## Everything's bigger in Texas, including school choice
 - [http://www.msn.com/en-us/news/us/everything-s-bigger-in-texas-including-school-choice/ar-AA1974Qg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/everything-s-bigger-in-texas-including-school-choice/ar-AA1974Qg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 06:38:21.552514+00:00



## Israelis Are Taking to the Streets Because Our House Is on Fire
 - [http://www.msn.com/en-us/news/world/israelis-are-taking-to-the-streets-because-our-house-is-on-fire/ar-AA197bfw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israelis-are-taking-to-the-streets-because-our-house-is-on-fire/ar-AA197bfw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 06:38:21.544256+00:00



## Corporations need a road map to come back from wokeness
 - [http://www.msn.com/en-us/news/us/corporations-need-a-road-map-to-come-back-from-wokeness/ar-AA196xI9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/corporations-need-a-road-map-to-come-back-from-wokeness/ar-AA196xI9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 05:38:31.477014+00:00



## Twitter says parts of source code leaked online
 - [http://www.msn.com/en-us/news/technology/twitter-says-parts-of-source-code-leaked-online/ar-AA196PLd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/twitter-says-parts-of-source-code-leaked-online/ar-AA196PLd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 05:38:31.468552+00:00



## Australia steps toward making big polluters reduce emissions
 - [http://www.msn.com/en-us/news/world/australia-steps-toward-making-big-polluters-reduce-emissions/ar-AA19722v?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/australia-steps-toward-making-big-polluters-reduce-emissions/ar-AA19722v?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 05:38:31.460721+00:00



## Bush, Pressley to launch Equal Rights Amendment caucus
 - [http://www.msn.com/en-us/news/politics/bush-pressley-to-launch-equal-rights-amendment-caucus/ar-AA196HMX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bush-pressley-to-launch-equal-rights-amendment-caucus/ar-AA196HMX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 04:38:40.048497+00:00



## Pennsylvania chocolate factory explosion kills seven after two more bodies found
 - [http://www.msn.com/en-us/news/crime/pennsylvania-chocolate-factory-explosion-kills-seven-after-two-more-bodies-found/ar-AA1975J6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/pennsylvania-chocolate-factory-explosion-kills-seven-after-two-more-bodies-found/ar-AA1975J6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 04:38:40.040489+00:00



## DeSantis team welcomes contrast with Trump 'chaos' candidacy
 - [http://www.msn.com/en-us/news/politics/desantis-team-welcomes-contrast-with-trump-chaos-candidacy/ar-AA196I7s?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/desantis-team-welcomes-contrast-with-trump-chaos-candidacy/ar-AA196I7s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 04:38:40.031379+00:00



## Mark Levin: 'The greatest threat we have is China- It's not Russia, it's not Iran; it's China'
 - [http://www.msn.com/en-us/news/world/mark-levin-the-greatest-threat-we-have-is-china-it-s-not-russia-it-s-not-iran-it-s-china/ar-AA196WAq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/mark-levin-the-greatest-threat-we-have-is-china-it-s-not-russia-it-s-not-iran-it-s-china/ar-AA196WAq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 03:38:35.006583+00:00



## Israel’s Netanyahu Fires Defense Minister, Sparking Mass Protests
 - [http://www.msn.com/en-us/news/world/israel-s-netanyahu-fires-defense-minister-sparking-mass-protests/vi-AA196zK8?srcref=rss](http://www.msn.com/en-us/news/world/israel-s-netanyahu-fires-defense-minister-sparking-mass-protests/vi-AA196zK8?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 02:38:25.288669+00:00



## Space race: Chinese rocket launches quadruple over decade, survey finds
 - [http://www.msn.com/en-us/news/world/space-race-chinese-rocket-launches-quadruple-over-decade-survey-finds/ar-AA196Fep?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/space-race-chinese-rocket-launches-quadruple-over-decade-survey-finds/ar-AA196Fep?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 02:38:25.280951+00:00



## Death toll in Pennsylvania chocolate factory explosion climbs to 7
 - [http://www.msn.com/en-us/news/us/death-toll-in-pennsylvania-chocolate-factory-explosion-climbs-to-7/ar-AA19581B?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/death-toll-in-pennsylvania-chocolate-factory-explosion-climbs-to-7/ar-AA19581B?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 02:38:25.273675+00:00



## How the world is responding to Putin’s threat of nukes in Belarus
 - [http://www.msn.com/en-us/news/world/how-the-world-is-responding-to-putin-s-threat-of-nukes-in-belarus/ar-AA196FsB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/how-the-world-is-responding-to-putin-s-threat-of-nukes-in-belarus/ar-AA196FsB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 02:38:25.266000+00:00



## Israel's leaders must find compromise on legislation that is tearing country apart, White House says
 - [http://www.msn.com/en-us/news/world/israel-s-leaders-must-find-compromise-on-legislation-that-is-tearing-country-apart-white-house-says/ar-AA196Gpi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-s-leaders-must-find-compromise-on-legislation-that-is-tearing-country-apart-white-house-says/ar-AA196Gpi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 01:38:28.743840+00:00



## Joe Exotic Says Presidential Run is ‘Not a Joke’ in Prison Call With Fox News
 - [http://www.msn.com/en-us/news/politics/joe-exotic-says-presidential-run-is-not-a-joke-in-prison-call-with-fox-news/ar-AA196uMD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/joe-exotic-says-presidential-run-is-not-a-joke-in-prison-call-with-fox-news/ar-AA196uMD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 01:38:28.736631+00:00



## US ‘deeply concerned’ after Netanyahu sacks Israel’s defense minister
 - [http://www.msn.com/en-us/news/politics/us-deeply-concerned-after-netanyahu-sacks-israel-s-defense-minister/ar-AA196GvX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/us-deeply-concerned-after-netanyahu-sacks-israel-s-defense-minister/ar-AA196GvX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 01:38:28.729410+00:00



## Mass Israel protests after Netanyahu sacks minister
 - [http://www.msn.com/en-us/news/world/mass-israel-protests-after-netanyahu-sacks-minister/ar-AA196ERq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/mass-israel-protests-after-netanyahu-sacks-minister/ar-AA196ERq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 01:38:28.722195+00:00



## Historic Wright Brothers airplane factory damaged in fire
 - [http://www.msn.com/en-us/news/us/historic-wright-brothers-airplane-factory-damaged-in-fire/ar-AA196GBO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/historic-wright-brothers-airplane-factory-damaged-in-fire/ar-AA196GBO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 01:38:28.714508+00:00



## Philadelphia residents clear shelves of bottled water after officials warn of chemical spill in the Delaware River
 - [http://www.msn.com/en-us/news/us/philadelphia-residents-clear-shelves-of-bottled-water-after-officials-warn-of-chemical-spill-in-the-delaware-river/ar-AA196SUO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/philadelphia-residents-clear-shelves-of-bottled-water-after-officials-warn-of-chemical-spill-in-the-delaware-river/ar-AA196SUO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 01:38:28.706913+00:00



## Six Russian naval vessels 'detected near site of Nord Stream pipeline five days before sabotage'
 - [http://www.msn.com/en-us/news/world/six-russian-naval-vessels-detected-near-site-of-nord-stream-pipeline-five-days-before-sabotage/ar-AA196pTH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/six-russian-naval-vessels-detected-near-site-of-nord-stream-pipeline-five-days-before-sabotage/ar-AA196pTH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 00:34:51.845391+00:00



## Videos Show Panicked Run on Bottled Water After Pennsylvania Chemical Spill
 - [http://www.msn.com/en-us/news/us/videos-show-panicked-run-on-bottled-water-after-pennsylvania-chemical-spill/ar-AA196EGj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/videos-show-panicked-run-on-bottled-water-after-pennsylvania-chemical-spill/ar-AA196EGj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 00:34:51.837977+00:00



## "Like a frog in boiling water": How Big Tech stole our ability to focus
 - [http://www.msn.com/en-us/news/technology/like-a-frog-in-boiling-water-how-big-tech-stole-our-ability-to-focus/ar-AA196Q5M?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/like-a-frog-in-boiling-water-how-big-tech-stole-our-ability-to-focus/ar-AA196Q5M?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 00:34:51.829858+00:00



## Biden's nominee to head the FAA makes 'remarkable' decision to withdraw his nomination: 'Decency to resign'
 - [http://www.msn.com/en-us/news/politics/biden-s-nominee-to-head-the-faa-makes-remarkable-decision-to-withdraw-his-nomination-decency-to-resign/ar-AA196kCc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-s-nominee-to-head-the-faa-makes-remarkable-decision-to-withdraw-his-nomination-decency-to-resign/ar-AA196kCc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 00:34:51.802613+00:00



## A ghost town in the world's most populated country
 - [http://www.msn.com/en-us/news/world/a-ghost-town-in-the-world-s-most-populated-country/ar-AA196pMM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-ghost-town-in-the-world-s-most-populated-country/ar-AA196pMM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 00:34:51.790805+00:00



## Fifth death confirmed in Pennsylvania chocolate factory explosion
 - [http://www.msn.com/en-us/news/us/fifth-death-confirmed-in-pennsylvania-chocolate-factory-explosion/ar-AA19581B?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/fifth-death-confirmed-in-pennsylvania-chocolate-factory-explosion/ar-AA19581B?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-03-27 00:34:51.782233+00:00



