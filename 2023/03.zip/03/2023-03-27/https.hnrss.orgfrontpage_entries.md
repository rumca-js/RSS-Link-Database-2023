# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Ask HN: Successful one-person online businesses?
 - [https://news.ycombinator.com/item?id=35333088](https://news.ycombinator.com/item?id=35333088)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 21:43:01+00:00

<p>This question was asked a few years ago (https://news.ycombinator.com/item?id=22858035) by committed, and I'm curious what it looks nowadays.<p>> How many people on hacker news are running successful online businesses on their own? What is your business and how did you get started?<p>> Defining successful as a profitable business which provides the majority of the owners income.<p>> Have any recent trends affected your business?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35333088">https://news.ycombinator.com/item?id=35333088</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

## I Would Love to Have Enough Time and Money to Go to an Office to Work All Day
 - [https://slate.com/business/2023/03/steven-rattner-new-york-times-remote-work-commute-child-care.html](https://slate.com/business/2023/03/steven-rattner-new-york-times-remote-work-commute-child-care.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 21:03:07+00:00

<p>Article URL: <a href="https://slate.com/business/2023/03/steven-rattner-new-york-times-remote-work-commute-child-care.html">https://slate.com/business/2023/03/steven-rattner-new-york-times-remote-work-commute-child-care.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35332585">https://news.ycombinator.com/item?id=35332585</a></p>
<p>Points: 57</p>
<p># Comments: 18</p>

## The Prospect of an AI Winter
 - [https://www.erichgrunewald.com/posts/the-prospect-of-an-ai-winter/](https://www.erichgrunewald.com/posts/the-prospect-of-an-ai-winter/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 21:00:39+00:00

<p>Article URL: <a href="https://www.erichgrunewald.com/posts/the-prospect-of-an-ai-winter/">https://www.erichgrunewald.com/posts/the-prospect-of-an-ai-winter/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35332537">https://news.ycombinator.com/item?id=35332537</a></p>
<p>Points: 64</p>
<p># Comments: 65</p>

## Apple Detection of Flashing Lights
 - [https://github.com/apple/VideoFlashingReduction](https://github.com/apple/VideoFlashingReduction)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 21:00:25+00:00

<p>Article URL: <a href="https://github.com/apple/VideoFlashingReduction">https://github.com/apple/VideoFlashingReduction</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35332531">https://news.ycombinator.com/item?id=35332531</a></p>
<p>Points: 28</p>
<p># Comments: 6</p>

## Sieve (YC W22) is hiring hackers to build AI infrastructure for video
 - [https://sievedata.com/about](https://sievedata.com/about)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 21:00:09+00:00

<p>Article URL: <a href="https://sievedata.com/about">https://sievedata.com/about</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35332518">https://news.ycombinator.com/item?id=35332518</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Defaulting on Single Page Applications
 - [https://www.zachleat.com/web/single-page-applications/](https://www.zachleat.com/web/single-page-applications/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 20:47:19+00:00

<p>Article URL: <a href="https://www.zachleat.com/web/single-page-applications/">https://www.zachleat.com/web/single-page-applications/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35332314">https://news.ycombinator.com/item?id=35332314</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Big tech and the pursuit of AI dominance
 - [https://www.economist.com/business/2023/03/26/big-tech-and-the-pursuit-of-ai-dominance](https://www.economist.com/business/2023/03/26/big-tech-and-the-pursuit-of-ai-dominance)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 20:31:44+00:00

<p>Article URL: <a href="https://www.economist.com/business/2023/03/26/big-tech-and-the-pursuit-of-ai-dominance">https://www.economist.com/business/2023/03/26/big-tech-and-the-pursuit-of-ai-dominance</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35332073">https://news.ycombinator.com/item?id=35332073</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Kubernetes Is Hard
 - [https://rcwz.pl/2023-03-26-kubernetes-is-hard/](https://rcwz.pl/2023-03-26-kubernetes-is-hard/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 20:19:52+00:00

<p>Article URL: <a href="https://rcwz.pl/2023-03-26-kubernetes-is-hard/">https://rcwz.pl/2023-03-26-kubernetes-is-hard/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35331887">https://news.ycombinator.com/item?id=35331887</a></p>
<p>Points: 50</p>
<p># Comments: 35</p>

## Artificial Intelligence Searches for Extraterrestrial Intelligence
 - [https://www.supercluster.com/editorial/artificial-intelligence-searches-for-extraterrestrial-intelligence/](https://www.supercluster.com/editorial/artificial-intelligence-searches-for-extraterrestrial-intelligence/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 19:43:45+00:00

<p>Article URL: <a href="https://www.supercluster.com/editorial/artificial-intelligence-searches-for-extraterrestrial-intelligence/">https://www.supercluster.com/editorial/artificial-intelligence-searches-for-extraterrestrial-intelligence/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35331372">https://news.ycombinator.com/item?id=35331372</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## The FBI’s Contract to Buy Mass Internet Data
 - [https://www.vice.com/en/article/dy3z9a/fbi-bought-netflow-data-team-cymru-contract](https://www.vice.com/en/article/dy3z9a/fbi-bought-netflow-data-team-cymru-contract)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 19:34:20+00:00

<p>Article URL: <a href="https://www.vice.com/en/article/dy3z9a/fbi-bought-netflow-data-team-cymru-contract">https://www.vice.com/en/article/dy3z9a/fbi-bought-netflow-data-team-cymru-contract</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35331237">https://news.ycombinator.com/item?id=35331237</a></p>
<p>Points: 42</p>
<p># Comments: 3</p>

## Show HN: Time-tracker that helps me with context switches and documentation
 - [https://github.com/tech-branch/tsr](https://github.com/tech-branch/tsr)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 19:34:08+00:00

<p>Hi HN!<p>I was feeling incredibly frustrated with my struggles in context-switching and writing documentation, so I decided to take action and find a solution.<p>I wrote a simple tool for Alfred and Raycast that helps me be more mindful when switching between tasks, which can even prevent some of those switches. Plus, I can jot down quick notes on each task as I go, making it easier to document everything once I’m finished.<p>This tool is really simple with only 5 commands - tsr, tsn, tsl, tsv, tse<p>tsr writes a new record<p>tsn writes a new note<p>tsl shows you the current task<p>tsv builds a static html page displaying a single timeline of the tasks and notes<p>tse opens the directory where records are stored for easy manual editing<p>TSR stores your data as simple csv files in ~/tsr, making it super easy to integrate with other tools or perform your own custom analysis and visualisation magic. The built-in tsv timeline visualisation is rather simple and doesn’t do any analysis (for now at least).<p>It depends solely on Python3 and works offline. 
I encourage you to check the python scripts to see how simple they are and potentially adapt them to your own needs.<p>Let me know what you think!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35331233">https://news.ycombinator.com/item?id=35331233</a></p>
<p>Points: 17</p>
<p># Comments: 0</p>

## Disney Layoffs 7000 People
 - [https://www.cnn.com/2023/03/27/media/disney-layoffs/index.html](https://www.cnn.com/2023/03/27/media/disney-layoffs/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 19:25:49+00:00

<p>Article URL: <a href="https://www.cnn.com/2023/03/27/media/disney-layoffs/index.html">https://www.cnn.com/2023/03/27/media/disney-layoffs/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35331154">https://news.ycombinator.com/item?id=35331154</a></p>
<p>Points: 27</p>
<p># Comments: 2</p>

## Greenland ice sheet is close to a melting point of no return
 - [https://news.agu.org/press-release/the-greenland-ice-sheet-is-close-to-a-melting-point-of-no-return/](https://news.agu.org/press-release/the-greenland-ice-sheet-is-close-to-a-melting-point-of-no-return/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 18:34:31+00:00

<p>Article URL: <a href="https://news.agu.org/press-release/the-greenland-ice-sheet-is-close-to-a-melting-point-of-no-return/">https://news.agu.org/press-release/the-greenland-ice-sheet-is-close-to-a-melting-point-of-no-return/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35330465">https://news.ycombinator.com/item?id=35330465</a></p>
<p>Points: 34</p>
<p># Comments: 11</p>

## Employees Are Feeding Sensitive Biz Data to ChatGPT, Raising Security Fears
 - [https://www.darkreading.com/risk/employees-feeding-sensitive-business-data-chatgpt-raising-security-fears](https://www.darkreading.com/risk/employees-feeding-sensitive-business-data-chatgpt-raising-security-fears)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 18:32:37+00:00

<p>Article URL: <a href="https://www.darkreading.com/risk/employees-feeding-sensitive-business-data-chatgpt-raising-security-fears">https://www.darkreading.com/risk/employees-feeding-sensitive-business-data-chatgpt-raising-security-fears</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35330438">https://news.ycombinator.com/item?id=35330438</a></p>
<p>Points: 67</p>
<p># Comments: 19</p>

## Online daters are less open-minded than their filters suggest
 - [https://www.economist.com/graphic-detail/2023/03/22/online-daters-are-less-open-minded-than-their-filters-suggest](https://www.economist.com/graphic-detail/2023/03/22/online-daters-are-less-open-minded-than-their-filters-suggest)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 18:05:29+00:00

<p>Article URL: <a href="https://www.economist.com/graphic-detail/2023/03/22/online-daters-are-less-open-minded-than-their-filters-suggest">https://www.economist.com/graphic-detail/2023/03/22/online-daters-are-less-open-minded-than-their-filters-suggest</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35330078">https://news.ycombinator.com/item?id=35330078</a></p>
<p>Points: 46</p>
<p># Comments: 45</p>

## WebKit Features in Safari 16.4
 - [https://webkit.org/blog/13966/webkit-features-in-safari-16-4/](https://webkit.org/blog/13966/webkit-features-in-safari-16-4/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 17:56:03+00:00

<p>Article URL: <a href="https://webkit.org/blog/13966/webkit-features-in-safari-16-4/">https://webkit.org/blog/13966/webkit-features-in-safari-16-4/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35329961">https://news.ycombinator.com/item?id=35329961</a></p>
<p>Points: 39</p>
<p># Comments: 11</p>

## Apple Passwords Deserve an App
 - [https://cabel.com/2023/03/27/apple-passwords-deserve-an-app/](https://cabel.com/2023/03/27/apple-passwords-deserve-an-app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 17:55:10+00:00

<p>Article URL: <a href="https://cabel.com/2023/03/27/apple-passwords-deserve-an-app/">https://cabel.com/2023/03/27/apple-passwords-deserve-an-app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35329950">https://news.ycombinator.com/item?id=35329950</a></p>
<p>Points: 148</p>
<p># Comments: 55</p>

## Smalltalk Type
 - [https://moritzfuerst.net/projects/smalltalk-type](https://moritzfuerst.net/projects/smalltalk-type)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 17:38:20+00:00

<p>Article URL: <a href="https://moritzfuerst.net/projects/smalltalk-type">https://moritzfuerst.net/projects/smalltalk-type</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35329724">https://news.ycombinator.com/item?id=35329724</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Treble.ai (YC S19) Is Hiring Spanish Speaking Engineers in NYC
 - [https://www.ycombinator.com/companies/treble-ai/jobs/tL8GeWc-full-stack-software-engineer](https://www.ycombinator.com/companies/treble-ai/jobs/tL8GeWc-full-stack-software-engineer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 17:01:04+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/treble-ai/jobs/tL8GeWc-full-stack-software-engineer">https://www.ycombinator.com/companies/treble-ai/jobs/tL8GeWc-full-stack-software-engineer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35329153">https://news.ycombinator.com/item?id=35329153</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## 5M item limit for Google Drive: File unable to generate or upload due to 403
 - [https://issuetracker.google.com/issues/268606830?pli=1](https://issuetracker.google.com/issues/268606830?pli=1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 16:59:35+00:00

<p>Article URL: <a href="https://issuetracker.google.com/issues/268606830?pli=1">https://issuetracker.google.com/issues/268606830?pli=1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35329135">https://news.ycombinator.com/item?id=35329135</a></p>
<p>Points: 50</p>
<p># Comments: 8</p>

## Rust's Golden Rule
 - [https://steveklabnik.com/writing/rusts-golden-rule](https://steveklabnik.com/writing/rusts-golden-rule)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 16:52:45+00:00

<p>Article URL: <a href="https://steveklabnik.com/writing/rusts-golden-rule">https://steveklabnik.com/writing/rusts-golden-rule</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35329038">https://news.ycombinator.com/item?id=35329038</a></p>
<p>Points: 38</p>
<p># Comments: 12</p>

## Xstate: State machines and statecharts for the modern web
 - [https://github.com/statelyai/xstate](https://github.com/statelyai/xstate)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 16:48:57+00:00

<p>Article URL: <a href="https://github.com/statelyai/xstate">https://github.com/statelyai/xstate</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35328995">https://news.ycombinator.com/item?id=35328995</a></p>
<p>Points: 36</p>
<p># Comments: 6</p>

## Soft-serve: A tasty, self-hostable Git server for the command line
 - [https://github.com/charmbracelet/soft-serve](https://github.com/charmbracelet/soft-serve)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 16:41:41+00:00

<p>Article URL: <a href="https://github.com/charmbracelet/soft-serve">https://github.com/charmbracelet/soft-serve</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35328885">https://news.ycombinator.com/item?id=35328885</a></p>
<p>Points: 27</p>
<p># Comments: 1</p>

## Launch HN: Play.ht (YC W23) – Generate and clone voices from 20 seconds of audio
 - [https://news.ycombinator.com/item?id=35328698](https://news.ycombinator.com/item?id=35328698)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 16:27:20+00:00

<p>Hey HN, we are Mahmoud and Hammad, co-founders of PlayHT (<a href="https://play.ht/">https://play.ht/</a>), a text-to-speech synthesis platform. We're building Large Language Speech Models across all languages with a focus on voice expressiveness and control.<p>Today, we are excited to share beta access to our latest model, Parrot, that is capable of cloning any voice with a few seconds of audio and generating expressive speech from text. You can try it out here: <a href="https://playground.play.ht">https://playground.play.ht</a>, and there are demo videos at <a href="https://www.youtube.com/watch?v=aL_hmxTLHiM">https://www.youtube.com/watch?v=aL_hmxTLHiM</a> and <a href="https://www.youtube.com/watch?v=fdEEoODd6Kk">https://www.youtube.com/watch?v=fdEEoODd6Kk</a>.<p>The model also captures accents well and is able to speak in all English accents. Even more interesting, it can make non-English speakers speak English while preserving their original accent. Just upload a non-English speaker clip and try it yourself.<p>Existing text to speech models either lack expressiveness, control or directability of the voice. For example, making a voice speak in a specific way, or emphasizing on a certain word or parts of the speech. Our goal is to solve these across all languages. Since the voices are built on LLMs they are able to express emotions based on the context of the text.<p>Our previous speech model, Peregrine, which we released last September, is able to laugh, scream and express other emotions: <a href="https://play.ht/blog/introducing-truly-realistic-text-to-speech-with-emotion-and-laughter/">https://play.ht/blog/introducing-truly-realistic-text-to-spe...</a>. We posted it to HN here: <a href="https://news.ycombinator.com/item?id=32945504" rel="nofollow">https://news.ycombinator.com/item?id=32945504</a>.<p>With Parrot, we've taken a slightly different approach and trained it on a much larger data set. Both Parrot and Peregrine only speak English at the moment but we are working on other languages and are seeing impressive early results that we plan to share soon.<p>Content creators of all kinds (gaming, media production, elearning) spend a lot of time and effort recording and editing high-quality audio. We solve that and make it as simple as writing and editing text. Our users range from individual creators looking to voice their videos, podcasts, etc to teams at various companies creating dynamic audio content.<p>We initially built this product for ourselves to listen to books and articles online and then found the quality of TTS is very low, so we started working on this product until, eventually we trained our own models and built a business around it. There are many robotic TTS services out there, but ours allows people to generate truly human-level expressive speech and allows anyone to clone voices instantly with strong resemblance. We initially used existing TTS models and APIs but when we started talking to our customers in gaming, media production, and others, people didn't like the monotone robotic TTS style. So we doubled down in training a new model based on the new emerging architectures using transformers and self supervised learning.<p>On our platform, we offer two types of voice cloning: high-fidelity and zero-shot. High-fidelity voice cloning requires around 20 minutes of audio data and creates an expressive voice that is more robust and captures the accent of the target voice with all its nuances. Zero-shot clones the voice with only a few seconds of audio and captures most of the accent and tone, but isn’t as nuanced because it has less data to work with. We also offer a diverse library of over a hundred voices for various use cases.<p>We offer two ways to use these models on the platform: (1) our text to voice editor, that allows users to create and manage their audio files in projects, etc.; and (2) our API - <a href="https://docs.play.ht/reference/api-getting-started">https://docs.play.ht/reference/api-getting-started</a>. The API supports streaming and polling and we are working on reducing the latency to make it real time. We have a free plan and transparent pricing available for anyone to upgrade.<p>We are thrilled to be sharing our new model, and look forward to feedback!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35328698">https://news.ycombinator.com/item?id=35328698</a></p>
<p>Points: 26</p>
<p># Comments: 15</p>

## CFTC Charges Binance Founder with Willful Evasion of Federal Law and More
 - [https://www.cftc.gov/PressRoom/PressReleases/8680-23](https://www.cftc.gov/PressRoom/PressReleases/8680-23)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 16:09:12+00:00

<p>Article URL: <a href="https://www.cftc.gov/PressRoom/PressReleases/8680-23">https://www.cftc.gov/PressRoom/PressReleases/8680-23</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35328449">https://news.ycombinator.com/item?id=35328449</a></p>
<p>Points: 40</p>
<p># Comments: 1</p>

## John Glenn’s $40 Camera Forced NASA to Rethink Space Missions
 - [https://petapixel.com/2023/03/23/how-john-glenns-40-camera-forced-nasa-to-rethink-space-missions/](https://petapixel.com/2023/03/23/how-john-glenns-40-camera-forced-nasa-to-rethink-space-missions/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 16:02:38+00:00

<p>Article URL: <a href="https://petapixel.com/2023/03/23/how-john-glenns-40-camera-forced-nasa-to-rethink-space-missions/">https://petapixel.com/2023/03/23/how-john-glenns-40-camera-forced-nasa-to-rethink-space-missions/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35328368">https://news.ycombinator.com/item?id=35328368</a></p>
<p>Points: 45</p>
<p># Comments: 8</p>

## WEKA Responds to Allegations Made by MinIO Regarding OSS Licensing
 - [https://www.weka.io/blog/file-system/weka-responds-to-unfounded-allegations-made-by-minio-regarding-open-source-licensing/](https://www.weka.io/blog/file-system/weka-responds-to-unfounded-allegations-made-by-minio-regarding-open-source-licensing/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 15:57:32+00:00

<p>Article URL: <a href="https://www.weka.io/blog/file-system/weka-responds-to-unfounded-allegations-made-by-minio-regarding-open-source-licensing/">https://www.weka.io/blog/file-system/weka-responds-to-unfounded-allegations-made-by-minio-regarding-open-source-licensing/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35328316">https://news.ycombinator.com/item?id=35328316</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## Automate your Python project with Makefile (2021)
 - [https://antonz.org/makefile-automation/](https://antonz.org/makefile-automation/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 15:50:15+00:00

<p>Article URL: <a href="https://antonz.org/makefile-automation/">https://antonz.org/makefile-automation/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35328220">https://news.ycombinator.com/item?id=35328220</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## CFTC sues Binance and CEO Changpeng Zhao [pdf]
 - [https://www.docdroid.net/60YAbCz/cftc-binance-pdf](https://www.docdroid.net/60YAbCz/cftc-binance-pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 15:31:18+00:00

<p>Article URL: <a href="https://www.docdroid.net/60YAbCz/cftc-binance-pdf">https://www.docdroid.net/60YAbCz/cftc-binance-pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35327996">https://news.ycombinator.com/item?id=35327996</a></p>
<p>Points: 263</p>
<p># Comments: 156</p>

## US CFTC Sues Binance and CEO Changpeng Zhao
 - [https://web3isgoinggreat.com/?id=cftc-sues-binance-and-ceo-changpeng-zhao](https://web3isgoinggreat.com/?id=cftc-sues-binance-and-ceo-changpeng-zhao)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 15:31:18+00:00

<p>Article URL: <a href="https://web3isgoinggreat.com/?id=cftc-sues-binance-and-ceo-changpeng-zhao">https://web3isgoinggreat.com/?id=cftc-sues-binance-and-ceo-changpeng-zhao</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35327996">https://news.ycombinator.com/item?id=35327996</a></p>
<p>Points: 28</p>
<p># Comments: 4</p>

## Docker-compose.yml as a universal infrastructure interface
 - [https://ergomake.dev/blog/docker-compose-as-a-universal-interface/](https://ergomake.dev/blog/docker-compose-as-a-universal-interface/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 15:12:52+00:00

<p>Article URL: <a href="https://ergomake.dev/blog/docker-compose-as-a-universal-interface/">https://ergomake.dev/blog/docker-compose-as-a-universal-interface/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35327743">https://news.ycombinator.com/item?id=35327743</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## Binance Sued by US Watchdog for Alleged Derivatives Rule Lapses
 - [https://www.bloomberg.com/news/articles/2023-03-27/crypto-exchange-binance-sued-by-us-cftc-for-alleged-derivatives-rule-lapses](https://www.bloomberg.com/news/articles/2023-03-27/crypto-exchange-binance-sued-by-us-cftc-for-alleged-derivatives-rule-lapses)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 15:06:24+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-03-27/crypto-exchange-binance-sued-by-us-cftc-for-alleged-derivatives-rule-lapses">https://www.bloomberg.com/news/articles/2023-03-27/crypto-exchange-binance-sued-by-us-cftc-for-alleged-derivatives-rule-lapses</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35327647">https://news.ycombinator.com/item?id=35327647</a></p>
<p>Points: 23</p>
<p># Comments: 5</p>

## The Dirty Secrets of a Smear Campaign
 - [https://www.newyorker.com/magazine/2023/04/03/the-dirty-secrets-of-a-smear-campaign](https://www.newyorker.com/magazine/2023/04/03/the-dirty-secrets-of-a-smear-campaign)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 14:48:20+00:00

<p>Article URL: <a href="https://www.newyorker.com/magazine/2023/04/03/the-dirty-secrets-of-a-smear-campaign">https://www.newyorker.com/magazine/2023/04/03/the-dirty-secrets-of-a-smear-campaign</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35327382">https://news.ycombinator.com/item?id=35327382</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## After a decade, South Dakota's Amish are moving on
 - [https://www.mitchellrepublic.com/news/south-dakota/after-a-decade-south-dakotas-amish-are-moving-on](https://www.mitchellrepublic.com/news/south-dakota/after-a-decade-south-dakotas-amish-are-moving-on)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 14:31:54+00:00

<p>Article URL: <a href="https://www.mitchellrepublic.com/news/south-dakota/after-a-decade-south-dakotas-amish-are-moving-on">https://www.mitchellrepublic.com/news/south-dakota/after-a-decade-south-dakotas-amish-are-moving-on</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35327136">https://news.ycombinator.com/item?id=35327136</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Show HN: Open AI is not Open – A browser extension
 - [https://github.com/zaporter/OpenAI-is-not-Open](https://github.com/zaporter/OpenAI-is-not-Open)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 14:29:55+00:00

<p>Article URL: <a href="https://github.com/zaporter/OpenAI-is-not-Open">https://github.com/zaporter/OpenAI-is-not-Open</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35327112">https://news.ycombinator.com/item?id=35327112</a></p>
<p>Points: 36</p>
<p># Comments: 6</p>

## Instead of Freaking Out, Try Geeking Out
 - [https://cscaz.cansurround.com/articles/45](https://cscaz.cansurround.com/articles/45)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 14:08:07+00:00

<p>Article URL: <a href="https://cscaz.cansurround.com/articles/45">https://cscaz.cansurround.com/articles/45</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35326846">https://news.ycombinator.com/item?id=35326846</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## Random Numbers in Bash
 - [https://gist.github.com/rbitr/9c68379d3e0b79c9f06eb3f867624576](https://gist.github.com/rbitr/9c68379d3e0b79c9f06eb3f867624576)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 13:49:41+00:00

<p>Article URL: <a href="https://gist.github.com/rbitr/9c68379d3e0b79c9f06eb3f867624576">https://gist.github.com/rbitr/9c68379d3e0b79c9f06eb3f867624576</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35326648">https://news.ycombinator.com/item?id=35326648</a></p>
<p>Points: 18</p>
<p># Comments: 8</p>

## A Short 100-Question Diligence Checklist
 - [https://www.thediff.co/archive/100-due-diligence-questions-checklist/](https://www.thediff.co/archive/100-due-diligence-questions-checklist/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 13:00:54+00:00

<p>Article URL: <a href="https://www.thediff.co/archive/100-due-diligence-questions-checklist/">https://www.thediff.co/archive/100-due-diligence-questions-checklist/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35326131">https://news.ycombinator.com/item?id=35326131</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## My Best Friend Died from Loneliness
 - [https://www.thefp.com/p/my-best-friend-died-from-loneliness](https://www.thefp.com/p/my-best-friend-died-from-loneliness)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 12:58:15+00:00

<p>Article URL: <a href="https://www.thefp.com/p/my-best-friend-died-from-loneliness">https://www.thefp.com/p/my-best-friend-died-from-loneliness</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35326105">https://news.ycombinator.com/item?id=35326105</a></p>
<p>Points: 29</p>
<p># Comments: 21</p>

## Benchmarking Cheap SSDs for Fun, No Profit (Be Warned)
 - [https://louwrentius.com/benchmarking-cheap-ssds-for-fun-no-profit-be-warned.html](https://louwrentius.com/benchmarking-cheap-ssds-for-fun-no-profit-be-warned.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 12:38:12+00:00

<p>Article URL: <a href="https://louwrentius.com/benchmarking-cheap-ssds-for-fun-no-profit-be-warned.html">https://louwrentius.com/benchmarking-cheap-ssds-for-fun-no-profit-be-warned.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35325883">https://news.ycombinator.com/item?id=35325883</a></p>
<p>Points: 14</p>
<p># Comments: 2</p>

## Why a European mobile operating system can’t challenge Android and iOS
 - [https://gael-duval.medium.com/why-a-european-mobile-operating-system-cant-challenge-android-and-ios-86104e97b89e](https://gael-duval.medium.com/why-a-european-mobile-operating-system-cant-challenge-android-and-ios-86104e97b89e)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 12:35:15+00:00

<p>Article URL: <a href="https://gael-duval.medium.com/why-a-european-mobile-operating-system-cant-challenge-android-and-ios-86104e97b89e">https://gael-duval.medium.com/why-a-european-mobile-operating-system-cant-challenge-android-and-ios-86104e97b89e</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35325859">https://news.ycombinator.com/item?id=35325859</a></p>
<p>Points: 65</p>
<p># Comments: 86</p>

## GitHub issue - resolved
 - [https://www.githubstatus.com/incidents/52z0j6phhnjs](https://www.githubstatus.com/incidents/52z0j6phhnjs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 12:19:30+00:00

<p>Seems like GitHub's struggling at the moment: https://downdetector.com/status/github/<p>I'm getting unicorns.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35325709">https://news.ycombinator.com/item?id=35325709</a></p>
<p>Points: 301</p>
<p># Comments: 133</p>

## GitHub's Down
 - [https://news.ycombinator.com/item?id=35325709](https://news.ycombinator.com/item?id=35325709)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 12:19:30+00:00

<p>Seems like GitHub's struggling at the moment: https://downdetector.com/status/github/<p>I'm getting unicorns.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35325709">https://news.ycombinator.com/item?id=35325709</a></p>
<p>Points: 64</p>
<p># Comments: 16</p>

## Zig and Rust
 - [https://matklad.github.io/2023/03/26/zig-and-rust.html](https://matklad.github.io/2023/03/26/zig-and-rust.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 12:02:07+00:00

<p>Article URL: <a href="https://matklad.github.io/2023/03/26/zig-and-rust.html">https://matklad.github.io/2023/03/26/zig-and-rust.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35325556">https://news.ycombinator.com/item?id=35325556</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Jsonnet – The Data Templating Language
 - [https://jsonnet.org/](https://jsonnet.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 11:52:51+00:00

<p>Article URL: <a href="https://jsonnet.org/">https://jsonnet.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35325488">https://news.ycombinator.com/item?id=35325488</a></p>
<p>Points: 14</p>
<p># Comments: 7</p>

## Top Reddit communities for Devs and ITs: from beginners to advanced
 - [https://pvs-studio.com/en/blog/posts/1040/](https://pvs-studio.com/en/blog/posts/1040/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 11:13:46+00:00

<p>Article URL: <a href="https://pvs-studio.com/en/blog/posts/1040/">https://pvs-studio.com/en/blog/posts/1040/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35325208">https://news.ycombinator.com/item?id=35325208</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## OBS Studio Lands AV1 and HEVC RTMP Streaming Support
 - [https://www.phoronix.com/news/OBS-Studio-AV1-HEVC-RTMP](https://www.phoronix.com/news/OBS-Studio-AV1-HEVC-RTMP)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 11:11:34+00:00

<p>Article URL: <a href="https://www.phoronix.com/news/OBS-Studio-AV1-HEVC-RTMP">https://www.phoronix.com/news/OBS-Studio-AV1-HEVC-RTMP</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35325193">https://news.ycombinator.com/item?id=35325193</a></p>
<p>Points: 28</p>
<p># Comments: 5</p>

## Setting up a packaging environment for Alpine Linux (introducing alpkg)
 - [https://blog.orhun.dev/alpine-packaging-setup/](https://blog.orhun.dev/alpine-packaging-setup/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 10:31:10+00:00

<p>Article URL: <a href="https://blog.orhun.dev/alpine-packaging-setup/">https://blog.orhun.dev/alpine-packaging-setup/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35324938">https://news.ycombinator.com/item?id=35324938</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Thoughts on Svelte
 - [https://tyhopp.com/notes/thoughts-on-svelte](https://tyhopp.com/notes/thoughts-on-svelte)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 08:56:56+00:00

<p>Article URL: <a href="https://tyhopp.com/notes/thoughts-on-svelte">https://tyhopp.com/notes/thoughts-on-svelte</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35324430">https://news.ycombinator.com/item?id=35324430</a></p>
<p>Points: 28</p>
<p># Comments: 3</p>

## Show HN: SlickGPT
 - [https://slickgpt.vercel.app/](https://slickgpt.vercel.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 07:42:02+00:00

<p>SlickGPT is a light-weight "use-your-own-API-key" ChatGPT client written in Svelte. It offers GPT-4 integration, a userless share feature and other superpowers.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35323960">https://news.ycombinator.com/item?id=35323960</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Morse Code Chat
 - [https://morse.halb.it/](https://morse.halb.it/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 07:28:37+00:00

<p>Article URL: <a href="https://morse.halb.it/">https://morse.halb.it/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35323872">https://news.ycombinator.com/item?id=35323872</a></p>
<p>Points: 22</p>
<p># Comments: 17</p>

## Journey Planner Challenge – You need to visit 5 tube stations
 - [https://edjefferson.com/journeyplannerchallenge/](https://edjefferson.com/journeyplannerchallenge/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 07:09:16+00:00

<p>Article URL: <a href="https://edjefferson.com/journeyplannerchallenge/">https://edjefferson.com/journeyplannerchallenge/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35323732">https://news.ycombinator.com/item?id=35323732</a></p>
<p>Points: 7</p>
<p># Comments: 6</p>

## Zig Quirks
 - [https://www.openmymind.net/Zig-Quirks/](https://www.openmymind.net/Zig-Quirks/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 06:55:11+00:00

<p>Article URL: <a href="https://www.openmymind.net/Zig-Quirks/">https://www.openmymind.net/Zig-Quirks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35323645">https://news.ycombinator.com/item?id=35323645</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Deployments Not Releases – Get Good at Delivering Software
 - [https://blog.mangoteque.com//blog/2023/03/13/deployments-not-releases/](https://blog.mangoteque.com//blog/2023/03/13/deployments-not-releases/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 06:23:26+00:00

<p>Article URL: <a href="https://blog.mangoteque.com//blog/2023/03/13/deployments-not-releases/">https://blog.mangoteque.com//blog/2023/03/13/deployments-not-releases/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35323484">https://news.ycombinator.com/item?id=35323484</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Get Off My Desktop Windows Needs to Stop Showing Tabloid News
 - [https://www.tomshardware.com/news/windows-keeps-feeding-tabloid-news](https://www.tomshardware.com/news/windows-keeps-feeding-tabloid-news)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 05:20:06+00:00

<p>Article URL: <a href="https://www.tomshardware.com/news/windows-keeps-feeding-tabloid-news">https://www.tomshardware.com/news/windows-keeps-feeding-tabloid-news</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35323121">https://news.ycombinator.com/item?id=35323121</a></p>
<p>Points: 25</p>
<p># Comments: 11</p>

## FDIC: First–Citizens Bank to Assume All Deposits and Loans of SV Bridge Bank
 - [https://www.fdic.gov/news/press-releases/2023/pr23023.html](https://www.fdic.gov/news/press-releases/2023/pr23023.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 05:13:58+00:00

<p>Article URL: <a href="https://www.fdic.gov/news/press-releases/2023/pr23023.html">https://www.fdic.gov/news/press-releases/2023/pr23023.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35323083">https://news.ycombinator.com/item?id=35323083</a></p>
<p>Points: 43</p>
<p># Comments: 11</p>

## The Vesuvius Challenge
 - [https://scrollprize.org/overview](https://scrollprize.org/overview)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 04:20:05+00:00

<p>Article URL: <a href="https://scrollprize.org/overview">https://scrollprize.org/overview</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35322809">https://news.ycombinator.com/item?id=35322809</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Scientists Finally Figure Out Why the Water Bear Is Nearly Indestructible
 - [https://www.veterinarydaily.com/2023/03/scientists-finally-figure-out-why-water.html](https://www.veterinarydaily.com/2023/03/scientists-finally-figure-out-why-water.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 03:15:47+00:00

<p>Article URL: <a href="https://www.veterinarydaily.com/2023/03/scientists-finally-figure-out-why-water.html">https://www.veterinarydaily.com/2023/03/scientists-finally-figure-out-why-water.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35322478">https://news.ycombinator.com/item?id=35322478</a></p>
<p>Points: 32</p>
<p># Comments: 14</p>

## Scientists finally figure out why the water bear is nearly indestructible (2017)
 - [https://bigthink.com/surprising-science/scientists-finally-figure-out-why-the-water-bear-is-nearly-unstoppable/](https://bigthink.com/surprising-science/scientists-finally-figure-out-why-the-water-bear-is-nearly-unstoppable/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 03:15:47+00:00

<p>Article URL: <a href="https://bigthink.com/surprising-science/scientists-finally-figure-out-why-the-water-bear-is-nearly-unstoppable/">https://bigthink.com/surprising-science/scientists-finally-figure-out-why-the-water-bear-is-nearly-unstoppable/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35322478">https://news.ycombinator.com/item?id=35322478</a></p>
<p>Points: 78</p>
<p># Comments: 37</p>

## The rise and rise of e-sports
 - [https://www.economist.com/special-report/2023/03/20/the-rise-and-rise-of-e-sports](https://www.economist.com/special-report/2023/03/20/the-rise-and-rise-of-e-sports)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 03:14:55+00:00

<p>Article URL: <a href="https://www.economist.com/special-report/2023/03/20/the-rise-and-rise-of-e-sports">https://www.economist.com/special-report/2023/03/20/the-rise-and-rise-of-e-sports</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35322473">https://news.ycombinator.com/item?id=35322473</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Where Did Writing Come From?
 - [https://www.getty.edu/news/where-did-writing-come-from/](https://www.getty.edu/news/where-did-writing-come-from/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 02:50:47+00:00

<p>Article URL: <a href="https://www.getty.edu/news/where-did-writing-come-from/">https://www.getty.edu/news/where-did-writing-come-from/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35322330">https://news.ycombinator.com/item?id=35322330</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Salve Lucrum: The Existential Threat of Greed in US Health Care
 - [https://jamanetwork.com/journals/jama/fullarticle/2801097](https://jamanetwork.com/journals/jama/fullarticle/2801097)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 02:35:14+00:00

<p>Article URL: <a href="https://jamanetwork.com/journals/jama/fullarticle/2801097">https://jamanetwork.com/journals/jama/fullarticle/2801097</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35322249">https://news.ycombinator.com/item?id=35322249</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Uber Eats' Swapped Order Problem
 - [https://blog.fahhem.com/2023/03/free-solution-uber-eats-swapped-orders/](https://blog.fahhem.com/2023/03/free-solution-uber-eats-swapped-orders/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 02:29:31+00:00

<p>Article URL: <a href="https://blog.fahhem.com/2023/03/free-solution-uber-eats-swapped-orders/">https://blog.fahhem.com/2023/03/free-solution-uber-eats-swapped-orders/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35322214">https://news.ycombinator.com/item?id=35322214</a></p>
<p>Points: 13</p>
<p># Comments: 3</p>

## The chat control proposal does not belong in democratic societies
 - [https://mullvad.net/en/chatcontrol](https://mullvad.net/en/chatcontrol)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 01:56:34+00:00

<p>Article URL: <a href="https://mullvad.net/en/chatcontrol">https://mullvad.net/en/chatcontrol</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35321994">https://news.ycombinator.com/item?id=35321994</a></p>
<p>Points: 92</p>
<p># Comments: 4</p>

## Argonaut (YC S21) Is Hiring a FullStack Engineer
 - [https://www.ycombinator.com/companies/argonaut/jobs/pJavmIJ-fullstack-engineer](https://www.ycombinator.com/companies/argonaut/jobs/pJavmIJ-fullstack-engineer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 01:00:16+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/argonaut/jobs/pJavmIJ-fullstack-engineer">https://www.ycombinator.com/companies/argonaut/jobs/pJavmIJ-fullstack-engineer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35321609">https://news.ycombinator.com/item?id=35321609</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Video Rendering with Node.js and FFmpeg
 - [https://creatomate.com/blog/video-rendering-with-nodejs-and-ffmpeg](https://creatomate.com/blog/video-rendering-with-nodejs-and-ffmpeg)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 01:00:11+00:00

<p>Article URL: <a href="https://creatomate.com/blog/video-rendering-with-nodejs-and-ffmpeg">https://creatomate.com/blog/video-rendering-with-nodejs-and-ffmpeg</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35321606">https://news.ycombinator.com/item?id=35321606</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## JSON for Linking Data
 - [https://json-ld.org](https://json-ld.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 00:46:22+00:00

<p>Article URL: <a href="https://json-ld.org">https://json-ld.org</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35321493">https://news.ycombinator.com/item?id=35321493</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## We need better support for SSH host certificates
 - [https://mjg59.dreamwidth.org/65874.html](https://mjg59.dreamwidth.org/65874.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-03-27 00:38:18+00:00

<p>Article URL: <a href="https://mjg59.dreamwidth.org/65874.html">https://mjg59.dreamwidth.org/65874.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35321418">https://news.ycombinator.com/item?id=35321418</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

