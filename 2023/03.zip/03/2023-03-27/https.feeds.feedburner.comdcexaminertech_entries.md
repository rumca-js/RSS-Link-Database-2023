# Source:Washington Examiner - Tech, URL:https://feeds.feedburner.com/dcexaminer/tech, language:en-US

## Scientists discover colossal black hole pointed toward Earth
 - [https://www.washingtonexaminer.com/policy/space/scientists-colossal-black-hole-pointed-earth](https://www.washingtonexaminer.com/policy/space/scientists-colossal-black-hole-pointed-earth)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2023-03-27 22:01:53+00:00

Scientists discovered a massive black hole pointed directly at Earth.

## US running short on critical component for key technology
 - [https://www.washingtonexaminer.com/policy/economy/us-short-component-electric-cars](https://www.washingtonexaminer.com/policy/economy/us-short-component-electric-cars)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2023-03-27 20:11:32+00:00

The United States is running low on a critical component for electric cars and other key technologies.

