# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## Why The Uncharted Movie Isn’t Really An Uncharted Movie
 - [https://www.youtube.com/watch?v=5eqD5cvVFAs](https://www.youtube.com/watch?v=5eqD5cvVFAs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-03-27 17:00:02+00:00

Uncharted is one of the best video games produced in the last 15 years.  Fans everywhere were ecstatic when news broke they were finally adapting Uncharted to the big screen.  But what we ended up getting in the Tom Holland Mark Wahlberg feature was the furthest thing from the Uncharted movie we wanted.  

Uncharted Fan film: https://www.youtube.com/watch?v=v5CZQpqF_74

#uncharted #uncharted4 #nerdstalgic 

Written by Ash MItrano
Edited by Paul Ritchey

