# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## AI is Evolving Faster Than You Think [GPT-4 and beyond]
 - [https://www.youtube.com/watch?v=DIU48QL5Cyk](https://www.youtube.com/watch?v=DIU48QL5Cyk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2023-03-27 20:49:43+00:00

In this episode, we take a deep look at the two weeks that changed the world. From GPT-4 to Google Bard, Midjourney v5 and even talk of AGI from Microsoft, it’s all right here.

Podcast: [https://youtu.be/dp_A32XkXYs](https://youtu.be/dp_A32XkXYs)

Intro Track: [https://youtu.be/IECITKmNnzM](https://youtu.be/IECITKmNnzM)

Track during Midjourney section: [https://youtu.be/N8HYLv4WZWY](https://youtu.be/N8HYLv4WZWY)

Outro Track: [https://youtu.be/8nTMej5WIOw](https://youtu.be/8nTMej5WIOw)

» ColdFusion Discord:  https://discord.gg/coldfusion
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusioncollective
» Podcast I Co-host: https://www.youtube.com/channel/UC6jKUaNXSnuW52CxexLcOJg

Producer: Dagogo Altraide

