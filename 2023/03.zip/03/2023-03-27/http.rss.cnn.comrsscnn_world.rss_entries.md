# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Elian Gonzalez's new chapter as a Cuban lawmaker
 - [https://www.cnn.com/2023/03/27/americas/elian-gonzalez-elected-cuban-lawmaker-intl/index.html](https://www.cnn.com/2023/03/27/americas/elian-gonzalez-elected-cuban-lawmaker-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-03-27 22:50:06+00:00

More than two decades after he was found clinging to an inner tube in the Straits of Florida, Elián González is taking on his most high profile role since the bitter custody battle that returned him to Cuba.

## Lebanon reverses decision on Daylight Saving, amid confusion on two different timezones
 - [https://www.cnn.com/2023/03/27/middleeast/lebanon-reverses-daylight-savings-decision-intl/index.html](https://www.cnn.com/2023/03/27/middleeast/lebanon-reverses-daylight-savings-decision-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-03-27 16:44:13+00:00

Lebanon's government has walked back a controversial decision to delay winter clock changes by a month, after last week's announcement by caretaker Prime Minister Najib Mikati sparked exasperation and confusion in a country already gripped by economic crisis.

## How the Fed's latest rate increase will affect your bank savings
 - [https://www.cnn.com/2023/03/27/success/banking-what-rising-interest-rates-mean-for-your-savings/index.html](https://www.cnn.com/2023/03/27/success/banking-what-rising-interest-rates-mean-for-your-savings/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-03-27 11:36:05+00:00

Banking has been top of mind for many people in the wake of some surprise bank failures and moves by US regulators to boost confidence in the financial system.

## Commercial real estate is in trouble. Why you should be paying attention
 - [https://www.cnn.com/2023/03/27/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2023/03/27/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-03-27 11:24:28+00:00

Economists are growing concerned about the $20 trillion commercial real estate (CRE) industry.

