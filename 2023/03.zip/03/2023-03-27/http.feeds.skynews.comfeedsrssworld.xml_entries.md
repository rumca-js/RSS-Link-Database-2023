# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Watch live: Israel protests against Netanyahu's reforms
 - [https://news.sky.com/story/watch-live-israel-protests-against-netanyahus-reforms-12843767](https://news.sky.com/story/watch-live-israel-protests-against-netanyahus-reforms-12843767)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 18:11:00+00:00

Watch live: Israel protests against Netanyahu's reforms

## Lebanon reverses controversial decision to delay clocks change
 - [https://news.sky.com/story/lebanon-time-row-government-reverses-controversial-decision-to-delay-clocks-changing-to-daylight-saving-time-12843706](https://news.sky.com/story/lebanon-time-row-government-reverses-controversial-decision-to-delay-clocks-changing-to-daylight-saving-time-12843706)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 16:19:00+00:00

Lebanon's government has reversed a controversial decision to delay the start of daylight saving time by a month.

## FIFA set to pay clubs &#163;300m for sending players to World Cup
 - [https://news.sky.com/story/fifa-set-to-pay-clubs-163300m-for-sending-players-to-world-cup-12843595](https://news.sky.com/story/fifa-set-to-pay-clubs-163300m-for-sending-players-to-world-cup-12843595)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 12:32:00+00:00

FIFA is set to pay clubs around &#163;300m for sending players to the 2026 World Cup in a huge cash uplift, Sky News understands.

## Orlando Bloom tells President Zelenskyy 'strength' of Ukrainian people is 'awe-inspiring'
 - [https://news.sky.com/story/ukraine-war-orlando-bloom-tells-president-zelenskyy-strength-of-ukrainian-people-is-awe-inspiring-12843501](https://news.sky.com/story/ukraine-war-orlando-bloom-tells-president-zelenskyy-strength-of-ukrainian-people-is-awe-inspiring-12843501)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 10:14:00+00:00

Orlando Bloom has praised the "incredible stoic nature" of the Ukrainian people as he met with President Volodymyr Zelenskyy and encouraged him to "go win" the war.

## Singer Linda Nolan reveals cancer has spread to her brain and she is preparing for 'inevitable'
 - [https://news.sky.com/story/linda-nolan-reveals-cancer-has-spread-to-her-brain-and-she-is-preparing-for-inevitable-12843434](https://news.sky.com/story/linda-nolan-reveals-cancer-has-spread-to-her-brain-and-she-is-preparing-for-inevitable-12843434)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 09:00:00+00:00

Singer Linda Nolan has revealed her cancer has spread to her brain.

## Global population could fall to six billion with 'unprecedented investment'
 - [https://news.sky.com/story/global-population-could-fall-to-six-billion-with-unprecedented-investment-in-tackling-poverty-researchers-say-12843433](https://news.sky.com/story/global-population-could-fall-to-six-billion-with-unprecedented-investment-in-tackling-poverty-researchers-say-12843433)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 08:59:00+00:00

The global population could fall to six billion by the end of the century if there is "unprecedented investment" in tackling poverty and inequality, researchers have said.

## UK and European markets calm but warning of 'slow motion' problem to come
 - [https://news.sky.com/story/financial-markets-calm-but-warning-of-problems-to-come-from-imf-12843391](https://news.sky.com/story/financial-markets-calm-but-warning-of-problems-to-come-from-imf-12843391)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 07:53:00+00:00

After a turbulent Friday and the rumbling of the worst financial crisis since 2008, the UK and European stock markets have largely calmed.

## Passenger 'opens plane door and triggers emergency slide'
 - [https://news.sky.com/story/man-opens-emergency-door-on-delta-airlines-plane-and-triggers-emergency-slide-12843367](https://news.sky.com/story/man-opens-emergency-door-on-delta-airlines-plane-and-triggers-emergency-slide-12843367)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 07:20:00+00:00

An "unruly passenger" has been detained after allegedly opening an emergency exit door on a plane, triggering the emergency slide.

## Netanyahu delays controversial overhaul of Israel's judiciary, says coalition partner
 - [https://news.sky.com/story/benjamin-netanyahu-delays-controversial-overhaul-of-israels-judiciary-says-coalition-partner-12843325](https://news.sky.com/story/benjamin-netanyahu-delays-controversial-overhaul-of-israels-judiciary-says-coalition-partner-12843325)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 05:54:00+00:00

Israeli Prime Minister Benjamin Netanyahu has delayed controversial plans to reform Israel's judiciary, his coalition partners say.

## Buyer found for Silicon Valley Bank
 - [https://news.sky.com/story/silicon-valley-bank-acquired-by-first-citizen-bank-12843319](https://news.sky.com/story/silicon-valley-bank-acquired-by-first-citizen-bank-12843319)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 05:36:00+00:00

A buyer has been found for the collapsed Silicon Valley Bank, the bank whose downfall heralded the financial unrest still being felt across the banking world.

## North Korea fires two test missiles as US deploys carrier group to South Korea for drills
 - [https://news.sky.com/story/north-korea-fires-two-test-missiles-as-us-deploys-uss-nimitz-aircraft-carrier-group-to-south-korea-for-drills-12843302](https://news.sky.com/story/north-korea-fires-two-test-missiles-as-us-deploys-uss-nimitz-aircraft-carrier-group-to-south-korea-for-drills-12843302)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 02:06:00+00:00

North Korea has fired two test missiles as its neighbour South Korea begins joint military drills with the US.

## 'Come to your senses now!' Israel's president tells Netanyahu to halt reforms as sacking sparks mass protests
 - [https://news.sky.com/story/israel-netanyahu-latest-protests-reforms-president-herzog-gallant-12843301](https://news.sky.com/story/israel-netanyahu-latest-protests-reforms-president-herzog-gallant-12843301)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 01:26:00+00:00

Israel's president has called on Prime Minister Benjamin Netanyahu to "stop the legislative process immediately" after the PM triggered widespread protests by sacking his defence minister for objecting to judicial reforms.

## US urges Israel to 'find compromise' after Netanyahu sacks defence minister, sparking mass protests
 - [https://news.sky.com/story/us-urges-israel-to-find-compromise-after-netanyahu-sacks-defence-minister-sparking-mass-protests-12843301](https://news.sky.com/story/us-urges-israel-to-find-compromise-after-netanyahu-sacks-defence-minister-sparking-mass-protests-12843301)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-03-27 01:26:00+00:00

The White House has urged Israel "to find a compromise as soon as possible" after Israeli Prime Minister Benjamin Netanyahu sacked his defence minister for objecting to judicial reforms, triggering widespread protests.

