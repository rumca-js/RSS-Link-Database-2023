# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## The Official Podcast #329: The Problem with Confrontation
 - [https://www.youtube.com/watch?v=9MKIhokoPgY](https://www.youtube.com/watch?v=9MKIhokoPgY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-03-27 16:00:09+00:00

Four close man friends gather around to talk about confrontation.

This is the Official Podcast. Every Friday. At 7pm EST. Links Below.

---

Get additional episodes and bonus content with early access:
go to https://www.PATREON.com/THEOFFICIALPODCAST

Brought to you by the following sponsors:

GET $15 OFF A TRUMAN SHAVE TRIAL SET AT HARRYS:
go to https://www.HARRYS.com/OFFICIAL

GET GODSLAP RIGHT NOW:
go to https://www.GODSLAPBOOK.com

---

Timestamps:

00:04:00 - Jackson's Confrontation
00:29:00 - Harry's, Godslap *Ads*
00:34:55 - Alien Mothership
00:44:00 - Cereal Free Speech
01:02:50 - The Whale Fatshaming
01:22:30 - Diablo 4 and Trump Arrest
---

Hosts: 

Jackson: https://twitter.com/zealotonpc 
Andrew: https://twitter.com/huggbeestv 
Charlie: https://twitter.com/moistcr1tikal 
Kaya: https://twitter.com/kayaorsan

---

The Official Podcast Links: 

SubReddit: https://reddit.com/r/theofficialpodcast 
Google Play: https://play.google.com/music/m/Iv4af6j46ldkjja7vwnvljbyiw4?t=The_Official_Podcast 
Google Podcasts: https://www.google.com/podcasts?feed=aHR0cHM6Ly9mZWVkcy5tZWdhcGhvbmUuZm0vVE9QNzc4NDYyNTk4MA%3D%3D 
Spotify: https://open.spotify.com/show/6TXzjtMTEopiGjIsCfvv6W 
iTunes: https://itunes.apple.com/au/podcast/the-official-podcast/id1186089636 
Patreon: https://www.patreon.com/theofficialpodcast
Intro by: https://www.youtube.com/c/Derpmii
Music by: https://soundcloud.com/inst1nctive
Thumbnail by: https://www.instagram.com/nook_eilyk/

## They Responded
 - [https://www.youtube.com/watch?v=IxRMuNJdpFo](https://www.youtube.com/watch?v=IxRMuNJdpFo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-03-27 01:15:00+00:00

This is the greatest response to nonsense of All Time
Merch https://moistglobal.com/
I stream every day https://www.twitch.tv/moistcr1tikal

